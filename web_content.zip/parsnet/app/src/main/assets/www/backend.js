/*
 * بک‌اند محلی PARSNET — همه‌چیز داخل همین مرورگر ذخیره می‌شود (بدون سرور).
 * رمزها به‌صورت هش‌شده (با salt) نگه‌داری می‌شوند، نه متن ساده.
 * نقش‌ها: admin (مدیر) و user (کاربر عادی) کاملاً جدا هستند.
 */
(function () {
  "use strict";

  const KEY = "parsnet_db_v3";
  const SKEY = "parsnet_session_v3";

  // حساب مدیر اولیه (فقط هش رمز اینجاست). بعد از ورود از تب «حساب» عوضش کنید.
  const DEFAULT_ADMIN = {
    username: "pn6baixx",
    salt: "c1a1bf537c0f71dc",
    hash: "6f1fb22eaf59072159d2185555ed2badc36a769b765ca592c7383b92fdbf7415"
  };

  /* ---------- Storage (localStorage with in-memory fallback) ---------- */
  const mem = {};
  function get(k, d) {
    try { const v = localStorage.getItem(k); if (v !== null) return JSON.parse(v); } catch (e) {}
    return k in mem ? mem[k] : d;
  }
  function set(k, v) {
    mem[k] = v;
    try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
  }
  function remove(k) {
    delete mem[k];
    try { localStorage.removeItem(k); } catch (e) {}
  }

  /* ---------- SHA-256 (pure JS, works on any page type) ---------- */
  const K = [], H0 = [];
  (function init() {
    const isPrime = (x) => { for (let i = 2; i * i <= x; i++) if (x % i === 0) return false; return true; };
    for (let n = 2, c = 0; c < 64; n++) {
      if (!isPrime(n)) continue;
      if (c < 8) H0[c] = Math.floor((Math.sqrt(n) % 1) * 4294967296) | 0;
      K[c] = Math.floor((Math.cbrt(n) % 1) * 4294967296) | 0;
      c++;
    }
  })();
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));
  function sha256(msg) {
    const data = new TextEncoder().encode(msg);
    const l = data.length;
    const buf = new Uint8Array(((l + 9 + 63) >> 6) << 6);
    buf.set(data); buf[l] = 0x80;
    const dv = new DataView(buf.buffer);
    dv.setUint32(buf.length - 8, Math.floor((l * 8) / 4294967296));
    dv.setUint32(buf.length - 4, (l * 8) >>> 0);
    const h = H0.slice(), w = new Array(64);
    for (let o = 0; o < buf.length; o += 64) {
      for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
      for (let i = 16; i < 64; i++) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      let a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
      for (let i = 0; i < 64; i++) {
        const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const ch = (e & f) ^ (~e & g);
        const t1 = (hh + S1 + ch + K[i] + w[i]) | 0;
        const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const maj = (a & b) ^ (a & c) ^ (b & c);
        const t2 = (S0 + maj) | 0;
        hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + b) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
      h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
    }
    return h.map((x) => (x >>> 0).toString(16).padStart(8, "0")).join("");
  }
  function hashPw(pw, salt) {
    let h = sha256(salt + ":" + pw);
    for (let i = 0; i < 3000; i++) h = sha256(h + ":" + salt + ":" + pw);
    return h;
  }
  const rnd = (n) => { const a = new Uint8Array(n); (self.crypto || window.crypto).getRandomValues(a); return Array.from(a, (x) => x.toString(16).padStart(2, "0")).join(""); };
  const uid = () => rnd(12);

  /* ---------- DB ---------- */
  function loadDb() {
    const db = get(KEY, null) || { users: [], servers: [], settings: { announcement: "به پارس‌نت خوش آمدید", ad: "" } };
    if (!db.users.some((u) => u.role === "admin")) {
      db.users.push({
        id: uid(), username: DEFAULT_ADMIN.username, key: DEFAULT_ADMIN.username.toLowerCase(),
        displayName: "", email: "", salt: DEFAULT_ADMIN.salt, hash: DEFAULT_ADMIN.hash,
        role: "admin", disabled: false, created: Date.now()
      });
      set(KEY, db);
    }
    return db;
  }
  const save = (db) => set(KEY, db);
  const pub = (u) => ({ username: u.username, role: u.role, displayName: u.displayName || u.username });

  function currentUser(db) {
    const id = get(SKEY, null);
    if (!id) return null;
    const u = db.users.find((x) => x.id === id);
    return u && !u.disabled ? u : null;
  }

  /* ---------- Validation ---------- */
  const validName = (n) => typeof n === "string" && /^[A-Za-z0-9_.-]{3,32}$/.test(n);
  const validPass = (p) => typeof p === "string" && p.length >= 6 && p.length <= 128;
  const validEmail = (e) => typeof e === "string" && e.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
  const validDisplay = (n) => typeof n === "string" && n.trim().length >= 2 && n.trim().length <= 40 && !/[\u0000-\u001f<>]/.test(n);

  /* ---------- Config links ---------- */
  function b64decode(s) {
    s = s.replace(/-/g, "+").replace(/_/g, "/");
    while (s.length % 4) s += "=";
    return decodeURIComponent(escape(atob(s)));
  }
  function parseLink(input, customName) {
    const link = String(input || "").trim();
    if (!link || link.length > 8192 || !link.includes("://")) return null;
    const scheme = link.split("://")[0].toLowerCase();
    const map = { vless: "VLESS", vmess: "VMESS", trojan: "TROJAN", ss: "SHADOWSOCKS", shadowsocks: "SHADOWSOCKS" };
    const protocol = map[scheme];
    if (!protocol) return null;
    let host = "", port = 0, name = "";
    try {
      const rest = link.slice(link.indexOf("://") + 3);
      if (protocol === "VMESS") {
        const j = JSON.parse(b64decode(rest.split("#")[0]));
        host = String(j.add || ""); port = parseInt(j.port, 10) || 0; name = String(j.ps || "");
      } else {
        if (rest.includes("#")) name = decodeURIComponent(rest.slice(rest.indexOf("#") + 1));
        let body = rest.split("#")[0].split("?")[0];
        if (protocol === "SHADOWSOCKS" && !body.includes("@")) body = b64decode(body);
        const hp = body.includes("@") ? body.slice(body.lastIndexOf("@") + 1) : body;
        const m = hp.match(/^\[?([^\]]+?)\]?:(\d+)\/?$/);
        if (m) { host = m[1]; port = parseInt(m[2], 10); } else host = hp.replace(/\/$/, "");
        if (!name) {
          const qs = link.split("?")[1];
          if (qs) name = new URLSearchParams(qs.split("#")[0]).get("remarks") || "";
        }
      }
    } catch (e) { /* keep what was parsed */ }
    const finalName = (String(customName || "").trim() || name || host || protocol).slice(0, 100);
    return { id: uid(), name: finalName, link, protocol, host: host.slice(0, 255), port, enabled: true };
  }
  function addServer(db, cfg) {
    db.servers = db.servers.filter((s) => s.link !== cfg.link);
    db.servers.unshift(cfg);
  }

  /* ---------- Login throttling (in memory) ---------- */
  let fails = [];
  function throttled() {
    const now = Date.now();
    fails = fails.filter((t) => now - t < 60000);
    return fails.length >= 5;
  }

  /* ---------- Router (same shape as a real HTTP API) ---------- */
  const R = (status, data) => ({ ok: status >= 200 && status < 300, status, data: data || {} });
  const E = (status, msg) => R(status, { error: msg });

  async function api(method, url, body) {
    body = body || {};
    const db = loadDb();

    if (url === "/api/me" && method === "GET") {
      const u = currentUser(db);
      return R(200, { user: u ? pub(u) : null, announcement: db.settings.announcement, ad: db.settings.ad });
    }

    if (url === "/api/signup" && method === "POST") {
      if (!validDisplay(body.displayName)) return E(400, "یک نام برای خودتان انتخاب کنید (۲ تا ۴۰ حرف).");
      if (!validName(body.username)) return E(400, "نام کاربری باید ۳ تا ۳۲ کاراکتر و فقط حروف انگلیسی، عدد و _ . - باشد.");
      if (!validEmail(body.email)) return E(400, "ایمیل معتبر وارد کنید.");
      if (!validPass(body.password)) return E(400, "رمز عبور باید حداقل ۶ کاراکتر باشد.");
      const key = body.username.toLowerCase(), email = body.email.trim().toLowerCase();
      if (db.users.some((u) => u.key === key)) return E(409, "این نام کاربری قبلاً ثبت شده است.");
      if (db.users.some((u) => u.email === email)) return E(409, "این ایمیل قبلاً ثبت شده است.");
      const salt = rnd(8);
      const u = { id: uid(), username: body.username, key, displayName: body.displayName.trim(), email, salt, hash: hashPw(body.password, salt), role: "user", disabled: false, created: Date.now() };
      db.users.push(u); save(db); set(SKEY, u.id);
      return R(200, { user: pub(u) });
    }

    if (url === "/api/login" && method === "POST") {
      if (throttled()) return E(429, "تعداد تلاش‌ها زیاد است؛ یک دقیقه بعد دوباره تلاش کنید.");
      const id = String(body.identifier || body.username || "").trim().toLowerCase();
      const u = id ? db.users.find((x) => x.key === id || (x.email && x.email === id)) : null;
      const ok = u ? hashPw(String(body.password || ""), u.salt) === u.hash : false;
      if (!u || !ok || u.disabled) { fails.push(Date.now()); return E(401, "نام کاربری/ایمیل یا رمز اشتباه است."); }
      set(SKEY, u.id);
      return R(200, { user: pub(u) });
    }

    if (url === "/api/logout" && method === "POST") { remove(SKEY); return R(200, { ok: true }); }

    const me = currentUser(db);
    if (!me) return E(401, "ابتدا وارد حساب کاربری شوید.");

    if (url === "/api/state" && method === "GET") {
      const list = me.role === "admin" ? db.servers : db.servers.filter((s) => s.enabled);
      return R(200, {
        user: pub(me), announcement: db.settings.announcement, ad: db.settings.ad,
        servers: list.map((s) => ({ id: s.id, name: s.name, protocol: s.protocol, host: s.host, port: s.port, link: s.link, enabled: s.enabled }))
      });
    }

    if (url === "/api/account" && method === "PUT") {
      if (hashPw(String(body.currentPassword || ""), me.salt) !== me.hash) return E(403, "رمز فعلی اشتباه است.");
      if (body.username && body.username !== me.username) {
        if (!validName(body.username)) return E(400, "نام کاربری معتبر نیست.");
        const key = body.username.toLowerCase();
        if (db.users.some((u) => u.key === key && u.id !== me.id)) return E(409, "این نام کاربری قبلاً ثبت شده است.");
        me.username = body.username; me.key = key;
      }
      if (body.password) {
        if (!validPass(body.password)) return E(400, "رمز جدید باید حداقل ۶ کاراکتر باشد.");
        me.salt = rnd(8); me.hash = hashPw(body.password, me.salt);
      }
      save(db);
      return R(200, { user: pub(me) });
    }

    if (url.startsWith("/api/admin/")) {
      if (me.role !== "admin") return E(404, "یافت نشد.");

      if (url === "/api/admin/servers" && method === "POST") {
        const cfg = parseLink(body.link, body.name);
        if (!cfg) return E(400, "لینک معتبر VLESS/VMess/Trojan/SS وارد کنید.");
        addServer(db, cfg); save(db);
        return R(200, { ok: true });
      }
      if (url === "/api/admin/servers/bulk" && method === "POST") {
        let added = 0;
        String(body.text || "").split(/\r?\n/).slice(0, 2000).forEach((l) => { const cfg = parseLink(l); if (cfg) { addServer(db, cfg); added++; } });
        save(db);
        return R(200, { added });
      }
      let m = url.match(/^\/api\/admin\/servers\/([a-f0-9]+)$/);
      if (m) {
        const s = db.servers.find((x) => x.id === m[1]);
        if (!s) return E(404, "یافت نشد.");
        if (method === "PATCH") { if (typeof body.enabled === "boolean") s.enabled = body.enabled; save(db); return R(200, { ok: true }); }
        if (method === "DELETE") { db.servers = db.servers.filter((x) => x.id !== s.id); save(db); return R(200, { ok: true }); }
      }

      if (url === "/api/admin/settings" && method === "PUT") {
        if (typeof body.announcement === "string") db.settings.announcement = body.announcement.slice(0, 300);
        if (typeof body.ad === "string") db.settings.ad = body.ad.slice(0, 500);
        save(db);
        return R(200, { ok: true });
      }

      if (url === "/api/admin/users" && method === "GET") {
        return R(200, { users: db.users.map((u) => ({ id: u.id, username: u.username, displayName: u.displayName || "", email: u.email || "", role: u.role, disabled: u.disabled, created: u.created })) });
      }
      m = url.match(/^\/api\/admin\/users\/([a-f0-9]+)$/);
      if (m) {
        const u = db.users.find((x) => x.id === m[1]);
        if (!u) return E(404, "یافت نشد.");
        if (u.role === "admin") return E(400, "حساب مدیر قابل تغییر از این بخش نیست.");
        if (method === "PATCH") { if (typeof body.disabled === "boolean") u.disabled = body.disabled; save(db); return R(200, { ok: true }); }
        if (method === "DELETE") { db.users = db.users.filter((x) => x.id !== u.id); save(db); return R(200, { ok: true }); }
      }
    }
    return E(404, "یافت نشد.");
  }

  window.ParsnetLocal = { api, _sha256: sha256, _hashPw: hashPw };
})();
