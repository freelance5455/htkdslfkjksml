# PARSNET — Android VPN app + HTML UI

این پروژه یک برنامه بومی اندروید است؛ فایل HTML داخل WebView نمایش داده می‌شود و اتصال از طریق پل JavaScript/Kotlin به `VpnService` و موتور `libbox` می‌رود. بازکردن HTML در مرورگر معمولی VPN سیستم ایجاد نمی‌کند.

## علت کار نکردن APK قبلی
APK ارسالی یک بسته WebView/Web2App بود و فایل‌های Kotlin فقط داخل `assets/web/parsnet/...` به‌صورت متن ذخیره شده بودند؛ کلاس‌های `MainActivity` و `ParsnetVpnService` و کتابخانه بومی `libbox.so` در برنامه اجرایی آن وجود نداشتند. بنابراین دکمه HTML به سرویس VPN واقعی وصل نبود.

## ساخت APK بومی
1. پوشه `PARSNET` را به‌عنوان پروژه Android در Android Studio باز کنید.
2. JDK 17 و Android SDK 35 را نصب کنید.
3. Gradle Sync را با اینترنت انجام دهید تا وابستگی `com.github.singbox-android:libbox:1.13.14` از JitPack دریافت شود.
4. `Build > Build APK(s)` را اجرا کنید.
5. خروجی `app/build/outputs/apk/debug/app-debug.apk` است.

Workflow در `.github/workflows/android-apk.yml` ساخت APK را خودکار می‌کند و وجود `lib/arm64-v8a/libbox.so` و فایل HTML را بررسی می‌کند.

## امکانات
- رابط HTML با تب‌های HOME / CONFIGS / LOGS / MORE
- افزودن دستی، کلیپ‌بورد، فایل متنی و اشتراک HTTPS
- ذخیره کانفیگ‌ها در localStorage همان نصب برنامه
- پل JavaScript به Kotlin برای اتصال و قطع اتصال
- مجوز VPN اندروید و سرویس foreground
- موتور sing-box libbox

## محدودیت و تست
این محیط Android SDK/Gradle و گوشی متصل ندارد؛ بنابراین APK جدید در اینجا کامپایل یا روی دستگاه آزمایش نشده است. پس از ساخت APK بومی، نصب و تأیید مجوز VPN، اتصال باید با یک کانفیگ معتبر و سرور در دسترس آزمایش شود. موفقیت اتصال به اعتبار کانفیگ و دسترس‌پذیری سرور نیز وابسته است.

libbox و هسته sing-box تحت GPL هستند؛ اعلان‌ها و شرایط مجوز آن‌ها را حفظ کنید.
