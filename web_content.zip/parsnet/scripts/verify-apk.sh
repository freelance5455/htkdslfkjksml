#!/usr/bin/env bash
set -euo pipefail
APK="${1:-app/build/outputs/apk/debug/app-debug.apk}"
test -f "$APK" || { echo "APK not found: $APK" >&2; exit 1; }
unzip -l "$APK" | grep -q 'lib/arm64-v8a/libbox.so' || { echo 'libbox.so is missing: not a native VPN build.' >&2; exit 2; }
unzip -l "$APK" | grep -q 'assets/www/npv.html' || { echo 'HTML UI is missing.' >&2; exit 3; }
echo 'APK contains HTML UI and arm64 libbox native engine.'
