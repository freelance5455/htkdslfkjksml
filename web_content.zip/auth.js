(() => {
  const OWNER_EMAIL = "rasyaajaa.224@gmail.com";
  const OWNER_USERNAME = "rasyaxpranzz";
  const $ = id => document.getElementById(id);
  const show = (id, yes=true) => $(id).classList.toggle("hidden", !yes);
  let auth, db, currentUser = null, currentUsername = "", isOwner = false;

  const msg = (text, bad=false) => {
    $("authMessage").textContent = text;
    $("authMessage").style.color = bad ? "#b3261e" : "";
  };
  const ownerMsg = text => $("ownerStatus").textContent = text;
  const validName = s => /^[a-zA-Z0-9_]{3,18}$/.test(s);
  const ready = () => {
    if (!window.BM_FIREBASE_CONFIG || !window.BM_FIREBASE_CONFIG.apiKey ||
        window.BM_FIREBASE_CONFIG.apiKey === "ISI_API_KEY") {
      msg("Firebase belum dikonfigurasi. Isi firebase-config.js terlebih dahulu.", true);
      return false;
    }
    if (!firebase.apps.length) firebase.initializeApp(window.BM_FIREBASE_CONFIG);
    auth = firebase.auth(); db = firebase.firestore();
    return true;
  };

  async function getPlayerSession() {
    if (auth.currentUser && auth.currentUser.isAnonymous) return auth.currentUser;
    return (await auth.signInAnonymously()).user;
  }

  async function createPlayer() {
    const username = $("usernameInput").value.trim();
    if (!validName(username)) return msg("Username 3-18 karakter: huruf, angka, atau underscore.", true);
    if (!ready()) return;
    $("playerCreateBtn").disabled = true;
    try {
      const user = await getPlayerSession(), key = username.toLowerCase();
      const nameRef = db.collection("usernames").doc(key);
      await db.runTransaction(async tx => {
        const snap = await tx.get(nameRef);
        if (snap.exists) throw new Error("Username sudah digunakan. Silakan pilih username lain.");
        tx.set(nameRef, {uid:user.uid, username, createdAt:firebase.firestore.FieldValue.serverTimestamp()});
        tx.set(db.collection("players").doc(user.uid), {
          uid:user.uid, username, usernameKey:key, bestScore:0, isBanned:false,
          createdAt:firebase.firestore.FieldValue.serverTimestamp()
        });
      });
      currentUser=user; currentUsername=username; isOwner=false; enterGame();
    } catch(e) { msg(e.message || "Gagal membuat akun. Coba lagi.", true); }
    finally { $("playerCreateBtn").disabled=false; }
  }

  async function playerLogin() {
    const username = $("usernameInput").value.trim();
    if (!validName(username)) return msg("Masukkan username yang valid.", true);
    if (!ready()) return;
    $("playerLoginBtn").disabled=true;
    try {
      const user=await getPlayerSession(), key=username.toLowerCase();
      const nameSnap=await db.collection("usernames").doc(key).get();
      if (!nameSnap.exists || nameSnap.data().uid !== user.uid)
        throw new Error("Akun ini tidak terdaftar pada perangkat ini. Gunakan perangkat saat akun dibuat.");
      const playerSnap=await db.collection("players").doc(user.uid).get();
      if (!playerSnap.exists) throw new Error("Data akun tidak ditemukan.");
      if (playerSnap.data().isBanned) throw new Error("Akun ini diblokir oleh owner.");
      currentUser=user; currentUsername=nameSnap.data().username; isOwner=false; enterGame();
    } catch(e) { msg(e.message || "Gagal masuk. Periksa koneksi.", true); }
    finally { $("playerLoginBtn").disabled=false; }
  }

  async function ownerLogin() {
    const username=$("ownerUsernameInput").value.trim();
    const password=$("ownerPasswordInput").value;
    if (username.toLowerCase() !== OWNER_USERNAME) return msg("Username owner tidak valid.", true);
    if (!password) return msg("Masukkan password owner.", true);
    if (!ready()) return;
    $("ownerLoginBtn").disabled=true;
    try {
      const result=await auth.signInWithEmailAndPassword(OWNER_EMAIL,password);
      if ((result.user.email || "").toLowerCase() !== OWNER_EMAIL) {
        await auth.signOut();
        throw new Error("Email akun owner tidak cocok.");
      }
      
      currentUser=result.user; currentUsername=OWNER_USERNAME; isOwner=true;
      enterGame();
    } catch(e) { msg("Login owner gagal: " + (e.message || "periksa password."), true); }
    finally { $("ownerLoginBtn").disabled=false; }
  }

  function enterGame() {
    show("authScreen",false);
    $("currentPlayer").textContent = isOwner ? "OWNER" : "@" + currentUsername;
    show("ownerPanelBtn",isOwner);
    $("bestScore").textContent = $("bestScore").textContent || "0";
  }

  async function submitScore(score) {
    if (!currentUser || isOwner || !db || !Number.isSafeInteger(score) || score<0) return;
    const ref=db.collection("players").doc(currentUser.uid);
    await db.runTransaction(async tx => {
      const snap=await tx.get(ref);
      if (!snap.exists || snap.data().isBanned) return;
      const old=Number(snap.data().bestScore||0);
      if (score>old) tx.update(ref,{bestScore:score,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
    });
  }

  async function loadLeaderboard() {
    $("leaderboardList").textContent="Memuat peringkat...";
    show("leaderboardModal");
    if (!db) { $("leaderboardList").textContent="Firebase belum dikonfigurasi."; return; }
    try {
      const snap=await db.collection("players").orderBy("bestScore","desc").limit(100).get();
      $("leaderboardList").innerHTML="";
      const entries=[];
      snap.forEach(doc=>{const d=doc.data(); if(!d.isBanned) entries.push(d);});
      entries.slice(0,50).forEach((d,i)=>{
        const row=document.createElement("div"); row.className="leader-row";
        const pos=document.createElement("b"); pos.textContent="#"+(i+1);
        const name=document.createElement("span"); name.textContent=d.username || "Player";
        const score=document.createElement("strong"); score.textContent=Number(d.bestScore||0).toLocaleString("id-ID");
        row.append(pos,name,score); $("leaderboardList").appendChild(row);
      });
      if (!entries.length) $("leaderboardList").textContent="Belum ada skor. Jadilah pemain pertama!";
    } catch(e) { $("leaderboardList").textContent="Gagal memuat leaderboard: "+e.message; }
  }

  async function findTarget(username) {
    const snap=await db.collection("usernames").doc(username.toLowerCase()).get();
    if (!snap.exists) throw new Error("Username tidak ditemukan.");
    return {uid:snap.data().uid, username:snap.data().username};
  }
  function ownerAuthorized() {
    return isOwner && currentUser && (currentUser.email||"").toLowerCase()===OWNER_EMAIL ;
  }
  async function giveScore() {
    if (!ownerAuthorized()) return ownerMsg("Akses ditolak.");
    const username=$("targetUsername").value.trim(), amount=Number($("targetScore").value);
    if (!validName(username) || !Number.isSafeInteger(amount) || amount<=0) return ownerMsg("Username atau jumlah skor tidak valid.");
    try {
      const target=await findTarget(username), ref=db.collection("players").doc(target.uid);
      await db.runTransaction(async tx=>{
        const snap=await tx.get(ref);
        if(!snap.exists) throw new Error("Data pemain tidak ditemukan.");
        if(snap.data().isBanned) throw new Error("Pemain sedang di-ban.");
        const total=Number(snap.data().bestScore||0)+amount;
        tx.update(ref,{bestScore:total,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
      });
      ownerMsg("Berhasil memberi "+amount.toLocaleString("id-ID")+" skor ke @"+target.username+".");
      $("targetScore").value="";
    } catch(e) { ownerMsg("Gagal: "+e.message); }
  }
  async function moderatePlayer(banned) {
    if (!ownerAuthorized()) return ownerMsg("Akses ditolak.");
    const username=$("banUsername").value.trim();
    if(!validName(username)) return ownerMsg("Masukkan username yang valid.");
    try {
      const target=await findTarget(username);
      if(target.uid===currentUser.uid) throw new Error("Owner tidak bisa memblokir dirinya sendiri.");
      await db.collection("players").doc(target.uid).update({
        isBanned:banned, updatedAt:firebase.firestore.FieldValue.serverTimestamp()
      });
      ownerMsg("@"+target.username+(banned?" berhasil di-ban.":" berhasil di-unban."));
    } catch(e) { ownerMsg("Gagal: "+e.message); }
  }

  $("playerCreateBtn").addEventListener("click",createPlayer);
  $("playerLoginBtn").addEventListener("click",playerLogin);
  $("ownerLoginBtn").addEventListener("click",ownerLogin);
  $("showOwnerLogin").addEventListener("click",()=>show("ownerLoginArea"));
  $("leaderboardBtn").addEventListener("click",loadLeaderboard);
  $("closeLeaderboard").addEventListener("click",()=>show("leaderboardModal",false));
  $("ownerPanelBtn").addEventListener("click",()=>{if(ownerAuthorized()){show("ownerModal");ownerMsg("Owner terverifikasi.");}});
  $("closeOwner").addEventListener("click",()=>show("ownerModal",false));
  $("setPlayerScoreBtn").addEventListener("click",giveScore);
  $("banPlayerBtn").addEventListener("click",()=>moderatePlayer(true));
  $("unbanPlayerBtn").addEventListener("click",()=>moderatePlayer(false));
  $("ownerLeaderboardBtn").addEventListener("click",loadLeaderboard);
  $("ownerLogoutBtn").addEventListener("click",async()=>{await auth.signOut();location.reload();});
  $("logoutBtn").addEventListener("click",async()=>{if(auth) await auth.signOut();location.reload();});

  const originalEndGame=window.endGame;
  if (typeof originalEndGame === "function") {
    window.endGame=function(){
      submitScore(Number($("score").textContent)||0).catch(()=>{});
      return originalEndGame();
    };
  }
  show("authScreen",true);
})();