/* login.html ve signup.html için ortak yardımcılar */
(function () {
  var A = window.App;
  window.addEventListener('error', function (e) { if (A && A.toast) A.toast('Beklenmeyen hata: ' + (e.message || 'bilinmiyor'), 'error'); });
  document.addEventListener('DOMContentLoaded', function () {
    var w = A.envWarning(), box = document.getElementById('env-warn');
    if (w && box) { box.textContent = w; box.classList.remove('hidden'); }
  });
  window.Auth = {
    showErr: function (id, msg) {
      var el = document.querySelector('[data-err="' + id + '"]');
      if (!el) return;
      el.textContent = msg || ''; el.classList.toggle('hidden', !msg);
    },
    bindEyes: function () {
      A.$$('[data-toggle-pass]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var input = btn.parentElement.querySelector('input');
          var show = input.type === 'password';
          input.type = show ? 'text' : 'password';
          btn.querySelector('iconify-icon').setAttribute('icon', show ? 'solar:eye-closed-linear' : 'solar:eye-linear');
        });
      });
    },
    loading: function (btn, on, text) {
      btn.disabled = on; btn.classList.toggle('opacity-70', on);
      btn.querySelector('span').textContent = on ? 'Lütfen bekle…' : text;
    },
    terms: function () {
      A.infoSheet('Kullanım Koşulları',
        '<p>BFF, arkadaşlarınla sohbet etmen ve konum paylaşman için yapılmış bir uygulamadır. Hesabını ve paylaştığın içerikleri kendin yönetirsin.</p>' +
        '<p>Başkalarını rahatsız eden, yasa dışı veya zararlı içerik paylaşmamayı kabul edersin. Konumunu yalnızca seçtiğin kişilerle ve seçtiğin süre boyunca paylaşırsın.</p>' +
        '<p>Bu sürümde veriler yalnızca bu cihazdaki tarayıcıda saklanır; bir sunucuya gönderilmez.</p>');
    },
    privacy: function () {
      A.infoSheet('Gizlilik Politikası',
        '<p>Hesap bilgilerin (ad, kullanıcı adı, e-posta) ve mesajların bu tarayıcının yerel depolamasında tutulur. Şifren düz metin olarak saklanmaz, özetlenerek (hash) kaydedilir.</p>' +
        '<p>Canlı konumun yalnızca profil ayarlarında seçtiğin gizlilik moduna göre arkadaşlarına görünür. Paylaşımı istediğin an durdurabilirsin.</p>' +
        '<p>Tarayıcı verilerini temizlediğinde bu cihazdaki tüm hesap ve mesajlar silinir.</p>');
    }
  };
})();
