
function getUsers(){return JSON.parse(localStorage.getItem('hallwayDramaUsers')||'[]')}
function saveUsers(x){localStorage.setItem('hallwayDramaUsers',JSON.stringify(x))}
const signup=document.getElementById('signupForm');
if(signup)signup.addEventListener('submit',e=>{
 e.preventDefault();
 const username=usernameEl.value.trim(),email=emailEl.value.trim().toLowerCase(),password=passwordEl.value,confirm=confirmPassword.value,code=schoolCode.value.trim(),msg=message;
 if(password!==confirm)return msg.textContent='Passwords do not match.';
 if(password.length<6)return msg.textContent='Password must be at least 6 characters.';
 if(!/^\d{5}$/.test(code))return msg.textContent='School code must be 5 digits.';
 const users=getUsers();
 if(users.some(u=>u.username.toLowerCase()===username.toLowerCase()||u.email===email))return msg.textContent='That username or email is already registered.';
 users.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),username,email,password,schoolCode:code});
 saveUsers(users);msg.textContent='Account created! Opening login...';setTimeout(()=>location.href='index.html',500);
});
const login=document.getElementById('loginForm');
if(login)login.addEventListener('submit',e=>{
 e.preventDefault();
 const identity=loginEmail.value.trim().toLowerCase(),password=loginPassword.value,msg=message;
 const u=getUsers().find(x=>(x.email===identity||x.username.toLowerCase()===identity)&&x.password===password);
 if(!u)return msg.textContent='Incorrect username/email or password.';
 localStorage.setItem('hallwayDramaCurrentUser',JSON.stringify(u));
 msg.textContent='Logged in! Opening Hallway Drama...';setTimeout(()=>location.href='app.html',150);
});
