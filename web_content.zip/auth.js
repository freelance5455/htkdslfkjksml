const SCHOOL_CODE = '21511';

function getUsers() {
  try { return JSON.parse(localStorage.getItem('hallwayDramaUsers') || '[]'); }
  catch { return []; }
}
function saveUsers(users) {
  localStorage.setItem('hallwayDramaUsers', JSON.stringify(users));
}
function makeId() {
  return (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()) + Math.random();
}

const form = document.getElementById('usernameForm');
if (form) {
  const input = document.getElementById('username');
  const passcodeInput = document.getElementById('passcode');
  const confirmInput = document.getElementById('passcodeConfirm');
  const msg = document.getElementById('message');
  const title = document.getElementById('authTitle');
  const subtitle = document.getElementById('authSubtitle');
  const submitBtn = document.getElementById('submitBtn');
  const confirmWrap = document.getElementById('confirmWrap');
  const backBtn = document.getElementById('backBtn');

  let mode = 'start';
  let pendingUser = null;

  function showMessage(text) {
    msg.textContent = text;
  }

  function resetForm() {
    mode = 'start';
    pendingUser = null;
    title.textContent = 'Hallway Drama';
    subtitle.textContent = 'Enter your username';
    input.disabled = false;
    input.value = '';
    passcodeInput.value = '';
    confirmInput.value = '';
    passcodeInput.parentElement.style.display = 'none';
    confirmWrap.style.display = 'none';
    backBtn.style.display = 'none';
    submitBtn.textContent = 'Continue';
    showMessage('');
    input.focus();
  }

  function goToPasscode(user, setup) {
    pendingUser = user;
    mode = setup ? 'setup' : 'login';
    title.textContent = setup ? 'Create your passcode' : 'Enter your passcode';
    subtitle.textContent = setup
      ? `Set a passcode for @${user.username}.`
      : `Welcome back, @${user.username}.`;
    input.disabled = true;
    passcodeInput.parentElement.style.display = 'block';
    confirmWrap.style.display = setup ? 'block' : 'none';
    backBtn.style.display = 'block';
    submitBtn.textContent = setup ? 'Create account' : 'Unlock Hallway Drama';
    passcodeInput.focus();
    showMessage(setup
      ? 'Use 4–8 numbers, like a phone passcode.'
      : 'Enter the passcode you created for this account.');
  }

  function enterApp(user) {
    localStorage.setItem('hallwayDramaCurrentUser', JSON.stringify(user));
    location.href = 'app.html';
  }

  backBtn.addEventListener('click', resetForm);

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    if (mode === 'start') {
      const username = input.value.trim();
      if (!username) return showMessage('Please enter a username.');
      if (username.length < 2) return showMessage('Username must be at least 2 characters.');

      const users = getUsers();
      const existing = users.find(u =>
        String(u.username || '').trim().toLowerCase() === username.toLowerCase()
      );

      if (existing) {
        // This is an existing account. Do NOT call it "taken" for the owner;
        // take the user to the passcode screen.
        if (!existing.passcode) {
          goToPasscode(existing, true);
        } else {
          goToPasscode(existing, false);
        }
        return;
      }

      pendingUser = {
        id: makeId(),
        username,
        schoolCode: SCHOOL_CODE
      };
      goToPasscode(pendingUser, true);
      return;
    }

    const passcode = passcodeInput.value.trim();
    if (!/^\d{4,8}$/.test(passcode)) {
      showMessage('Passcode must be 4–8 numbers.');
      passcodeInput.focus();
      return;
    }

    const users = getUsers();

    if (mode === 'setup') {
      const confirmation = confirmInput.value.trim();
      if (passcode !== confirmation) {
        showMessage('The passcodes do not match.');
        confirmInput.focus();
        return;
      }

      const idx = users.findIndex(u =>
        String(u.id || '') === String(pendingUser.id)
      );

      if (idx >= 0) {
        users[idx].passcode = passcode;
        users[idx].schoolCode = users[idx].schoolCode || SCHOOL_CODE;
        pendingUser = users[idx];
      } else {
        pendingUser.passcode = passcode;
        users.push(pendingUser);
      }

      saveUsers(users);
      enterApp(pendingUser);
      return;
    }

    // Existing account login.
    const user = users.find(u => String(u.id) === String(pendingUser.id));
    if (!user || user.passcode !== passcode) {
      showMessage('Incorrect passcode.');
      passcodeInput.select();
      return;
    }

    enterApp(user);
  });
}
