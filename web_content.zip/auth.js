const SCHOOL_CODE = '21511';

function getUsers() {
  try { return JSON.parse(localStorage.getItem('hallwayDramaUsers') || '[]'); }
  catch { return []; }
}
function saveUsers(users) {
  localStorage.setItem('hallwayDramaUsers', JSON.stringify(users));
}
function makeId() {
  return (crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now());
}

const form = document.getElementById('usernameForm');
if (form) {
  const input = document.getElementById('username');
  const msg = document.getElementById('message');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = input.value.trim();

    if (!username) {
      msg.textContent = 'Please enter a username.';
      return;
    }
    if (username.length < 2) {
      msg.textContent = 'Username must be at least 2 characters.';
      return;
    }

    const users = getUsers();
    const taken = users.some(u =>
      String(u.username || '').trim().toLowerCase() === username.toLowerCase()
    );

    if (taken) {
      msg.textContent = 'That username is already taken.';
      input.focus();
      return;
    }

    const user = {
      id: makeId(),
      username,
      schoolCode: SCHOOL_CODE
    };

    users.push(user);
    saveUsers(users);
    localStorage.setItem('hallwayDramaCurrentUser', JSON.stringify(user));
    location.href = 'app.html';
  });
}
