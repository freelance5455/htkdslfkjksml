# Giang Võ Lục — Android WebView project

Project này đóng gói game HTML GVL thành ứng dụng Android ngoại tuyến bằng WebView. Bản HTML, nhạc và bảy đoạn lồng tiếng đều nằm trong `app/src/main/assets/index.html`; game không cần quyền Internet.

## Để tạo APK

1. Dùng Android Studio trên máy tính, mở thư mục `GVL_Android_Project` (thư mục chứa `settings.gradle`).
2. Cài Android SDK Platform 36 và Android SDK Build-Tools theo lời nhắc của Android Studio.
3. Chờ Gradle Sync hoàn tất.
4. Chọn **Build > Build APK(s)**.
5. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

Hoặc, trên máy đã cài Android SDK và có kết nối mạng để tải Gradle/plugin cần thiết, chạy:

```sh
./gradlew assembleDebug
```

Trên Windows:

```bat
gradlew.bat assembleDebug
```

## Ghi chú

- Đây là mã nguồn Android sẵn để biên dịch, không phải APK đã biên dịch.
- Tệp game được đóng gói trong ứng dụng và hoạt động ngoại tuyến.
- Bản debug có ID ứng dụng `com.gvl.giangvoluc.debug`; bản release dùng `com.gvl.giangvoluc`.
- Cần kiểm tra trực tiếp trên điện thoại Android trước khi phát hành rộng rãi.
