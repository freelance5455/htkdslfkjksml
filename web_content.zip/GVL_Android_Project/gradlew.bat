@echo off
setlocal
set GRADLE_VERSION=8.13
set CACHE_ROOT=%USERPROFILE%\.gradle\gvl-wrapper
set GRADLE_HOME=%CACHE_ROOT%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%CACHE_ROOT%\gradle.zip'; Expand-Archive -Force '%CACHE_ROOT%\gradle.zip' '%CACHE_ROOT%'; Remove-Item '%CACHE_ROOT%\gradle.zip'"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
