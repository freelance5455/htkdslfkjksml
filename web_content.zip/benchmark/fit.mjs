// Turns REAL measured token counts into Protwave's factory calibration and an honest accuracy report.
// Usage: node benchmark/fit.mjs benchmark/results.csv   (writes seed_calibration.json at the project root)
// results.csv columns: prompt_id,model,openai_count,true_tokens
//   openai_count = count from OpenAI's public tokenizer page (o200k) for that exact prompt text
//   true_tokens  = the token count that model's own free counter/usage panel reports for the same text
import fs from 'node:fs';
const [,, csvPath = 'benchmark/results.csv'] = process.argv;
const prompts = Object.fromEntries(fs.readFileSync('benchmark/prompts.jsonl','utf8').trim().split('\n').map(l=>{const o=JSON.parse(l);return[o.id,o]}));
const ledger = JSON.parse(fs.readFileSync('ledger.json','utf8'));
const M = Object.fromEntries(ledger.models.map(m=>[m.n,m]));
const CJK=/[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]/g;
const bk=s=>{const n=s.length||1;if((s.match(CJK)||[]).length/n>.2)return'cjk';if((s.match(/[{}();=<>\[\]\/\\_]/g)||[]).length/n>.05)return'code';return (s.match(/\d/g)||[]).length/n>.15?'data':'prose'};
const rows=fs.readFileSync(csvPath,'utf8').trim().split('\n').slice(1).map(l=>l.split(',')).map(([id,model,o,t])=>({id,model,o:+o,t:+t})).filter(r=>r.o>0&&r.t>0&&prompts[r.id]&&M[r.model]);
const med=a=>{const s=[...a].sort((x,y)=>x-y),h=s.length>>1;return s.length%2?s[h]:(s[h-1]+s[h])/2};
const clamp=r=>Math.min(1.8,Math.max(.6,r));
for(const r of rows){r.b=bk(prompts[r.id].text);r.fam=M[r.model].fam;r.ratio=r.t/(r.o*M[r.model].f)}
const seed={},rep=[];
const group=(keyFn)=>{const g={};for(const r of rows)(g[keyFn(r)]??=[]).push(r);return g};
for(const [k,g] of Object.entries(group(r=>r.model+'|'+r.b))){const rs=g.map(x=>x.ratio),m=med(rs);seed[k]={r:clamp(m),n:Math.min(g.length,5),e:med(rs.map(x=>Math.abs(x-m)/m))}}
for(const [k,g] of Object.entries(group(r=>r.fam+'|'+r.b))){const rs=g.map(x=>x.ratio),m=med(rs);seed[k]={r:clamp(m),n:Math.min(g.length,5),e:med(rs.map(x=>Math.abs(x-m)/m))}}
// leave-one-out accuracy per model: predict each prompt from the others in its group
const byModel=group(r=>r.model);
for(const [model,g] of Object.entries(byModel)){const errs=[];for(const r of g){const others=g.filter(x=>x!==r&&x.b===r.b).map(x=>x.ratio);const pr=others.length?med(others):1;errs.push(Math.abs(Math.ceil(r.o*M[model].f*pr)-r.t)/r.t)}
let cov=null,q=null;if(errs.length>=20){let hit=0;errs.forEach((e,i)=>{const o=errs.filter((_,j)=>j!==i).sort((x,y)=>x-y),n=o.length;if(e<=o[Math.min(n-1,Math.ceil((n+1)*.95)-1)])hit++});cov=+(100*hit/errs.length).toFixed(0);q=+(100*[...errs].sort((x,y)=>x-y)[Math.min(errs.length-1,Math.ceil(errs.length*.95)-1)]).toFixed(1)}
 rep.push({model,prompts:g.length,range95_pct:q,coverage95_pct:cov,mean_accuracy_pct:+(100*(1-errs.reduce((a,b)=>a+b,0)/errs.length)).toFixed(1),within_5pct:+(100*errs.filter(e=>e<=.05).length/errs.length).toFixed(0),within_10pct:+(100*errs.filter(e=>e<=.1).length/errs.length).toFixed(0)})}
fs.writeFileSync('seed_calibration.json',JSON.stringify(seed,null,1));
console.table(rep);console.log('Wrote seed_calibration.json with',Object.keys(seed).length,'entries. Publish these accuracy numbers only with the prompt set and method.');
