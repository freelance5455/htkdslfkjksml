# Protwave benchmark kit (no API keys needed)

Goal: measure Protwave's real token-count accuracy and ship it as factory calibration.

1. `prompts.jsonl` holds 32 varied prompts (prose, code, data, CJK, other languages, agent-style). Add more: 300+ gives tighter numbers.
2. For each prompt and each model you want to cover, record two numbers:
   - `openai_count`: paste the prompt into OpenAI's public tokenizer page (o200k) and note the token count.
   - `true_tokens`: the count that model's own free counter or usage panel shows for the same text (for example the token/usage display in the vendor's chat app or playground).
3. Fill `results.csv` (see `results_template.csv`; the model name must match `ledger.json`).
4. Run `node benchmark/fit.mjs benchmark/results.csv` from the project root.
5. It writes `seed_calibration.json` (loaded automatically as factory defaults) and prints leave-one-out accuracy: the honest number to publish.

6. The report also prints `range95_pct` (the +/- range that held 95% of the time in leave-one-out testing) and `coverage95_pct` (how often held-out prompts fell inside it). Publish these, not a single accuracy number: they say how far a count can be off.
