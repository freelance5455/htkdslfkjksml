#!/bin/sh
# Sobe um servidor HTTP local só para abrir o app pelo navegador em http://localhost:8080
# (o app também funciona sem isso, abrindo o index.html direto no navegador).
echo "Abrindo o Anjo da Guarda em http://localhost:8080 ..."
echo "Pressione Ctrl+C para encerrar."
cd "$(dirname "$0")"
python3 -m http.server 8080
