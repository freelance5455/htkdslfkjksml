أيقونة التطبيق (بدون نص). الملفات:
- icon-1024.png: الأصل. adaptive-foreground/background-1024.png: للأيقونة التكيفية.
- android-res/: مجلدات mipmap جاهزة. بعد npx cap add android انسخ محتوياتها فوق android/app/src/main/res/ ،
  وضع mipmap-anydpi-v26.xml جوه mipmap-anydpi-v26/ باسم ic_launcher.xml (وكمان ic_launcher_round.xml).
- icon-192/512.png و apple-touch-icon.png و favicon-32.png للويب (متوصلين في index.html و manifest).
