QUIZ APPLICATION — MOBILE WEB APP

Files
- index.html: Complete responsive quiz application. Open it in a modern browser.

Features
- Welcome, setup, quiz, results, and history screens
- 20 multiple-choice questions across Computer Science, Artificial Intelligence,
  General Knowledge, and Android Development
- One question at a time, four options, answer selection, previous/next navigation
- Selection validation, progress indicator, automatic scoring, percentage, 60% pass mark
- Restart quiz and persistent attempt history using browser localStorage
- No external libraries or internet connection required after the file is available

Run on Android
1. Extract the ZIP file.
2. Open index.html in a browser or import it into a web-app builder that supports a multi-screen
   single-page HTML application.
3. For an APK builder, import the complete index.html file as the app's main page. Keep the
   JavaScript and CSS embedded in the file; do not copy only a section of the code.
4. History is saved in the browser/app WebView's local storage on that device. Clearing app/browser
   storage can remove saved results. This is local persistence, not cloud synchronization.

Testing checklist
- Start a quiz and try Next without choosing an option: a validation message should appear.
- Select answers, navigate Previous/Next, and check selections remain selected.
- Complete a quiz and verify correct + incorrect equals total, and percentage equals correct/total.
- Restart and confirm the new attempt starts without old selections.
- Complete another attempt and open Result history; both attempts should appear after reopening
  the same app/browser storage.

Note
This is a functional mobile-friendly web app package suitable for preview in a browser or compatible
HTML-to-APK builder. It is not a signed native Android APK and does not use a cloud database.
