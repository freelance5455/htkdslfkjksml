# WORLD QUIZ — Genişletilmiş sürüm

Mobil uyumlu HTML/CSS/JavaScript coğrafya oyunu.

## Çalıştırma
1. ZIP'i çıkarın.
2. Klasörü VS Code ile açın.
3. Live Server eklentisiyle `index.html` dosyasını çalıştırın.
4. Ülke sınırları, 3D küre ve bayraklar için internet bağlantısı gerekir.

## Özellikler
- 3D döndürülebilir dünya küresi (Globe.gl)
- Ülke sınırları, hover etiketi ve oyun sırasında hedef ülke renklendirmesi
- Bayrak bilme ve haritada ülke bulma modları
- Kolay / Orta / Uzman zorlukları, 10 soruluk turlar, süre ve puan
- Ülkeye oyun dışında tıklayınca ülke ansiklopedisi
- Günlük görevler (günlük tamamlanan tur, doğru cevap ve puan hedefleri)
- Doğru/yanlış/tur sonu ses efektleri (Web Audio API; ilk etkileşimden sonra çalışır)
- Doğru/yanlış animasyonları
- Profil, seviye/XP, başarı rozetleri ve yerel skor tablosu
- localStorage ile aynı tarayıcıda saklama
- İsteğe bağlı Firebase Firestore çevrimiçi skor tablosu

## Firebase çevrimiçi skor tablosunu etkinleştirme
Çevrimiçi tablo, kişisel Firebase projesi ve yapılandırma gerektirir; bu nedenle ZIP içinde varsayılan olarak kapalıdır.

1. https://console.firebase.google.com/ adresinde Firebase projesi oluşturun.
2. Projeye Web App ekleyin.
3. Firebase web config değerlerini `firebase-config.js` içindeki `window.WORLD_QUIZ_FIREBASE_CONFIG` nesnesine girin.
4. Firebase Console > Firestore Database bölümünden veritabanı oluşturun.
5. Koleksiyon adı uygulama tarafından `worldQuizScores` olarak oluşturulur.
6. Firestore güvenlik kurallarını düşünmeden herkese açık yazmaya açmayın. Bu örnek uygulama istemci tarafından skor gönderir; bu, kötüye kullanıma karşı güvenli değildir. Üretim ortamında Firebase Authentication + Cloud Functions/Cloud Run üzerinden sunucu tarafı puan doğrulaması ekleyin.
7. Hosting'e dağıtacaksanız Firebase Hosting veya HTTPS destekleyen başka bir statik barındırma kullanın.

## Veri kaynakları
- Globe.gl: https://globe.gl/
- GeoJSON ülke sınırları: https://github.com/datasets/geo-countries
- Bayrak görselleri: https://flagcdn.com/
- Firebase: https://firebase.google.com/

## Veri doğruluğu hakkında
GeoJSON kaynağı esas olarak sınırlar ve bazı temel idari alanları sağlar. Başkent, nüfus ve para birimi gibi tüm ansiklopedi alanları bu dosyada garanti edilmez; eksik alanlar "Bilgi yok" görünür. Bunları eksiksiz ve güncel sunmak için ayrıca güvenilir bir ülke bilgi API'si entegre edilmelidir.

## Gizlilik
Profil, oyun istatistikleri ve günlük görevler tarayıcının localStorage alanında saklanır. Tarayıcı verileri silinirse yerel kayıtlar da silinir. Firebase etkinleştirilirse gönderilen skor ve görünen oyuncu adı Firestore'a kaydedilir.
