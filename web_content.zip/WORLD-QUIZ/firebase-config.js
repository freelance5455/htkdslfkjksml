/*
  Firebase çevrimiçi skor tablosunu açmak için:
  1. https://console.firebase.google.com/ adresinde proje oluştur.
  2. Web uygulaması ekle ve Firebase yapılandırma nesnesini aşağıya yapıştır.
  3. Firestore Database oluştur.
  4. Firestore kurallarını aşağıdaki güvenli başlangıç kurallarına göre ayarla.
  5. Bu dosyayı kaydet ve sayfayı yenile.

  NOT: İstemci tarafı yazma kuralları herkese açık bırakılırsa skorlar manipüle edilebilir.
  Gerçek, kötüye kullanıma dayanıklı bir skor tablosu için sunucu doğrulaması / Cloud Functions gerekir.
*/
window.WORLD_QUIZ_FIREBASE_CONFIG = {
  // apiKey: "FIREBASE_WEB_API_KEY",
  // authDomain: "proje-adin.firebaseapp.com",
  // projectId: "proje-adin",
  // storageBucket: "proje-adin.appspot.com",
  // messagingSenderId: "SENDER_ID",
  // appId: "APP_ID"
};
