const $ = id => document.getElementById(id);
const STORAGE_KEY = "worldQuizProfile_v1";
const TOTAL_QUESTIONS = 10;
const DIFFICULTIES = {
  easy: { seconds: 90, choices: 4, points: 10 },
  medium: { seconds: 75, choices: 4, points: 15 },
  hard: { seconds: 60, choices: 6, points: 20 }
};

const defaultProfile = {
  name: "Kaşif", totalPoints: 0, gamesPlayed: 0, bestScore: 0,
  correct: 0, answered: 0, xp: 0, level: 1, badges: [],
  scores: []
};

let profile = loadProfile();
let countries = [];
let globe = null;
let currentCountry = null;
let currentMode = "flag";
let difficulty = "medium";
let roundScore = 0;
let questionIndex = 0;
let timeLeft = 0;
let timerId = null;
let gameActive = false;
let answered = false;
let questionPool = [];
let targetCountry = null;
let selectedFeature = null;
let hoverFeature = null;
let autoRotate = true;

function loadProfile() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved ? { ...defaultProfile, ...saved } : { ...defaultProfile };
  } catch {
    return { ...defaultProfile };
  }
}
function saveProfile() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[c]));
}
function countryName(feature) {
  const p = feature.properties || {};
  return p.ADMIN || p.name || p.NAME || p.SOVEREIGNT || "Bilinmeyen ülke";
}
function countryCode(feature) {
  const p = feature.properties || {};
  const code = p.ISO_A2 || p.ISO_A2_EH || p.iso_a2 || p.ISO3166_1_Alpha_2 || "";
  return /^[A-Za-z]{2}$/.test(code) && code !== "-99" ? code.toLowerCase() : "";
}
function isPlayable(feature) {
  return Boolean(countryName(feature) && countryCode(feature) && feature.geometry);
}
function shuffle(list) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

async function init() {
  renderProfile();
  renderAchievements();
  renderLeaderboard();
  bindEvents();
  try {
    const response = await fetch("https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson");
    if (!response.ok) throw new Error("Ülke verisi alınamadı.");
    const geojson = await response.json();
    countries = geojson.features.filter(isPlayable);
    if (countries.length < 100) throw new Error("Ülke verisi eksik geldi.");
    createGlobe();
    $("mapLoading").hidden = true;
    $("mapHelp").textContent = `${countries.length} ülke yüklendi. Küreyi sürükleyebilir, yakınlaştırabilir ve ülkelere dokunabilirsin.`;
    updateMapColors();
    $("startButton").disabled = false;
  } catch (error) {
    console.error(error);
    $("mapLoading").innerHTML = '<span>Harita yüklenemedi. İnternet bağlantını kontrol edip sayfayı yenile.</span>';
    $("startButton").disabled = true;
    $("feedback").textContent = "Ülke verileri yüklenemedi.";
  }
}

function createGlobe() {
  const host = $("globe");
  globe = Globe()(host)
    .width(host.clientWidth)
    .height(host.clientHeight)
    .backgroundColor("rgba(0,0,0,0)")
    .globeImageUrl("https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg")
    .showAtmosphere(true)
    .atmosphereColor("#38bdf8")
    .atmosphereAltitude(0.17)
    .polygonsData(countries)
    .polygonAltitude(d => d === targetCountry ? 0.025 : d === selectedFeature ? 0.018 : 0.006)
    .polygonCapColor(d => {
      if (d === targetCountry) return "#fbbf24";
      if (d === selectedFeature) return "#4ade80";
      if (d === hoverFeature) return "#38bdf8";
      return "#1685b8";
    })
    .polygonSideColor(() => "rgba(9,30,53,0.75)")
    .polygonStrokeColor(() => "rgba(150,220,255,0.65)")
    .polygonLabel(d => `<div style="padding:5px 8px;font:600 12px Arial;color:#fff;background:#0b1728;border:1px solid #38bdf8;border-radius:6px">${escapeHtml(countryName(d))}</div>`)
    .onPolygonHover(d => {
      hoverFeature = d || null;
      updateMapColors();
      host.style.cursor = d && currentMode === "country" && gameActive && !answered ? "pointer" : "grab";
    })
    .onPolygonClick(d => {
      if (!d) return;
      if (currentMode === "country" && gameActive && !answered) checkAnswer(d);
      else if (!gameActive) openEncyclopedia(d);
    });

  globe.controls().autoRotate = true;
  globe.controls().autoRotateSpeed = 0.35;
  globe.controls().enableDamping = true;
  globe.pointOfView({ lat: 18, lng: 8, altitude: 2.35 }, 0);

  const resizeObserver = new ResizeObserver(() => {
    if (globe) globe.width(host.clientWidth).height(host.clientHeight);
  });
  resizeObserver.observe(host);
}

function updateMapColors() {
  if (globe) globe.polygonsData([...countries]);
}

function focusCountry(feature) {
  const center = getFeatureCenter(feature);
  if (center && globe) globe.pointOfView({ lat: center.lat, lng: center.lng, altitude: 1.65 }, 850);
}
function getFeatureCenter(feature) {
  const points = [];
  function walk(coords) {
    if (!Array.isArray(coords)) return;
    if (typeof coords[0] === "number" && typeof coords[1] === "number") points.push(coords);
    else coords.forEach(walk);
  }
  walk(feature.geometry.coordinates);
  if (!points.length) return null;
  // Average a bounded sample so large polygons do not freeze the browser.
  const sample = points.length > 500 ? points.filter((_, i) => i % Math.ceil(points.length / 500) === 0) : points;
  let lat = 0, lng = 0;
  sample.forEach(p => { lng += p[0]; lat += p[1]; });
  return { lat: lat / sample.length, lng: lng / sample.length };
}

function bindEvents() {
  $("startButton").addEventListener("click", startGame);
  $("nextButton").addEventListener("click", nextQuestion);
  $("skipButton").addEventListener("click", skipQuestion);
  $("modeSelect").addEventListener("change", e => {
    currentMode = e.target.value;
    if (gameActive) finishRound("Mod değiştirildi.");
    setIdleQuestion();
  });
  $("difficultySelect").addEventListener("change", e => {
    difficulty = e.target.value;
    if (gameActive) finishRound("Zorluk değiştirildi.");
    setIdleQuestion();
  });
  $("rotateButton").addEventListener("click", () => {
    autoRotate = !autoRotate;
    if (globe) globe.controls().autoRotate = autoRotate;
    $("rotateButton").classList.toggle("active", autoRotate);
  });
  $("resetViewButton").addEventListener("click", () => {
    if (globe) globe.pointOfView({ lat: 18, lng: 8, altitude: 2.35 }, 700);
  });
  $("profileOpen").addEventListener("click", openProfile);
  $("editProfile").addEventListener("click", openProfile);
  $("closeModal").addEventListener("click", closeProfile);
  $("saveProfile").addEventListener("click", savePlayerName);
  $("profileModal").addEventListener("click", e => {
    if (e.target === $("profileModal")) closeProfile();
  });
  $("playerNameInput").addEventListener("keydown", e => {
    if (e.key === "Enter") savePlayerName();
  });
}

function setIdleQuestion() {
  $("questionKicker").textContent = "İLK ADIMINI AT";
  $("questionTitle").textContent = "Yeni bir keşfe hazır mısın?";
  $("questionDescription").textContent = currentMode === "flag"
    ? "Bayrak gösterilecek; doğru ülkeyi seçeneklerden bulacaksın."
    : "Bir ülke adı verilecek; 3D kürede doğru ülkeye dokunacaksın.";
  $("flagFrame").innerHTML = '<div class="flag-placeholder">🌐</div>';
  $("answers").innerHTML = '<div class="empty-answer">Oyunu başlattığında sorular burada görünecek.</div>';
  $("feedback").textContent = "Modunu ve zorluğunu seç, ardından oyunu başlat.";
  $("feedback").className = "feedback";
  $("nextButton").disabled = true;
  $("skipButton").disabled = true;
  $("progressText").textContent = "Hazır olduğunda başla";
  $("progressBar").style.width = "0%";
}

function startGame() {
  if (!countries.length) return;
  clearInterval(timerId);
  currentMode = $("modeSelect").value;
  difficulty = $("difficultySelect").value;
  roundScore = 0;
  questionIndex = 0;
  timeLeft = DIFFICULTIES[difficulty].seconds;
  gameActive = true;
  answered = false;
  questionPool = shuffle(countries);
  targetCountry = null;
  selectedFeature = null;
  $("roundScore").textContent = "0";
  $("timer").textContent = formatTime(timeLeft);
  $("questionCount").textContent = `0/${TOTAL_QUESTIONS}`;
  $("startButton").textContent = "Yeniden başlat ↻";
  $("nextButton").disabled = true;
  $("skipButton").disabled = false;
  $("feedback").className = "feedback";
  $("feedback").textContent = "Başarılar! Her doğru cevap puan kazandırır.";
  renderQuestion();
  timerId = setInterval(() => {
    timeLeft--;
    $("timer").textContent = formatTime(timeLeft);
    if (timeLeft <= 10) $("timer").style.color = "var(--red)";
    if (timeLeft <= 0) endGame("Süre doldu!");
  }, 1000);
}

function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
}

function renderQuestion() {
  if (!gameActive) return;
  if (questionIndex >= TOTAL_QUESTIONS) return endGame("10 soruyu tamamladın!");
  if (questionPool.length < TOTAL_QUESTIONS) questionPool = shuffle(countries);
  targetCountry = questionPool[questionIndex % questionPool.length];
  currentCountry = targetCountry;
  selectedFeature = null;
  answered = false;
  $("questionCount").textContent = `${questionIndex + 1}/${TOTAL_QUESTIONS}`;
  $("progressText").textContent = `Soru ${questionIndex + 1} / ${TOTAL_QUESTIONS}`;
  $("progressBar").style.width = `${(questionIndex / TOTAL_QUESTIONS) * 100}%`;
  $("nextButton").disabled = true;
  $("skipButton").disabled = false;
  $("feedback").className = "feedback";
  $("feedback").textContent = currentMode === "flag" ? "Bayrağı incele ve doğru cevabı seç." : "Haritada doğru ülkeye dokun.";

  if (currentMode === "flag") {
    $("questionKicker").textContent = "BAYRAĞI TANI";
    $("questionTitle").textContent = "Bu bayrak hangi ülkeye ait?";
    $("questionDescription").textContent = "Doğru ülkeyi aşağıdaki seçenekler arasından bul.";
    const code = countryCode(targetCountry);
    $("flagFrame").innerHTML = code
      ? `<img src="https://flagcdn.com/w320/${code}.png" alt="${escapeHtml(countryName(targetCountry))} bayrağı" onerror="this.parentElement.innerHTML='<div class=\\'flag-placeholder\\'>🏳️</div>'">`
      : '<div class="flag-placeholder">🏳️</div>';
    buildAnswers();
    $("mapHelp").textContent = "İstersen küreyi döndürerek bu ülkenin dünyadaki yerini de keşfedebilirsin.";
  } else {
    $("questionKicker").textContent = "ÜLKEYİ HARİTADA BUL";
    $("questionTitle").textContent = countryName(targetCountry);
    $("questionDescription").textContent = "Bu ülkeyi 3D dünya küresi üzerinde bul ve dokun.";
    $("flagFrame").innerHTML = '<div class="flag-placeholder">📍</div>';
    $("answers").innerHTML = '<div class="empty-answer">Cevabını vermek için kürede doğru ülkeye dokun.</div>';
    $("mapHelp").textContent = "Hedef ülke haritada önceden işaretlenmez. Ülkeye dokunduğunda cevabın kontrol edilir.";
    focusCountry(targetCountry);
  }
  updateMapColors();
}

function buildAnswers() {
  const count = DIFFICULTIES[difficulty].choices;
  const others = shuffle(countries.filter(c => c !== targetCountry)).slice(0, count - 1);
  const choices = shuffle([targetCountry, ...others]);
  $("answers").innerHTML = "";
  choices.forEach(feature => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer-btn";
    button.textContent = countryName(feature);
    button.addEventListener("click", () => checkAnswer(feature, button));
    $("answers").appendChild(button);
  });
}

function checkAnswer(feature, clickedButton = null) {
  if (!gameActive || answered || !targetCountry) return;
  answered = true;
  selectedFeature = feature;
  const correct = feature === targetCountry;
  const buttons = [...document.querySelectorAll(".answer-btn")];
  buttons.forEach(button => {
    button.disabled = true;
    if (button.textContent === countryName(targetCountry)) button.classList.add("correct");
  });

  if (correct) {
    const base = DIFFICULTIES[difficulty].points;
    const timeBonus = Math.min(10, Math.floor(timeLeft / 10));
    roundScore += base + timeBonus;
    profile.correct++;
    $("feedback").textContent = `✓ Doğru cevap! +${base + timeBonus} puan`;
    $("feedback").className = "feedback success";
    if (clickedButton) clickedButton.classList.add("correct");
  } else {
    $("feedback").textContent = `Bu kez olmadı. Doğru cevap: ${countryName(targetCountry)}`;
    $("feedback").className = "feedback error";
    if (clickedButton) clickedButton.classList.add("wrong");
  }
  profile.answered++;
  $("roundScore").textContent = roundScore;
  $("nextButton").disabled = false;
  $("skipButton").disabled = true;
  $("progressBar").style.width = `${((questionIndex + 1) / TOTAL_QUESTIONS) * 100}%`;
  updateMapColors();
  updateStats();
}

function nextQuestion() {
  if (!gameActive || !answered) return;
  questionIndex++;
  renderQuestion();
}
function skipQuestion() {
  if (!gameActive || answered) return;
  answered = true;
  profile.answered++;
  $("feedback").textContent = `Soru geçildi. Doğru cevap: ${countryName(targetCountry)}`;
  $("feedback").className = "feedback";
  $("nextButton").disabled = false;
  $("skipButton").disabled = true;
  document.querySelectorAll(".answer-btn").forEach(b => b.disabled = true);
  $("progressBar").style.width = `${((questionIndex + 1) / TOTAL_QUESTIONS) * 100}%`;
  updateStats();
}
function endGame(reason) {
  if (!gameActive) return;
  gameActive = false;
  clearInterval(timerId);
  profile.gamesPlayed++;
  profile.totalPoints += roundScore;
  profile.bestScore = Math.max(profile.bestScore, roundScore);
  profile.xp += roundScore;
  while (profile.xp >= profile.level * 100) {
    profile.xp -= profile.level * 100;
    profile.level++;
  }
  profile.scores.push({ name: profile.name, score: roundScore, date: new Date().toISOString() });
  profile.scores = profile.scores.sort((a,b) => b.score - a.score).slice(0, 5);
  checkAchievements();
  saveProfile();
  updateStats();
  renderProfile();
  renderAchievements();
  renderLeaderboard();
  $("questionKicker").textContent = "TUR TAMAMLANDI";
  $("questionTitle").textContent = reason;
  $("questionDescription").textContent = `Bu turda ${roundScore} puan kazandın. Yeni bir turla rekorunu geliştirebilirsin.`;
  $("flagFrame").innerHTML = '<div class="flag-placeholder">🏆</div>';
  $("answers").innerHTML = `<div class="empty-answer">Tur sonucu: ${roundScore} puan · Toplam doğru cevap: ${profile.correct}</div>`;
  $("feedback").textContent = roundScore >= 100 ? "Müthiş performans! Dünya bilgini konuşturdun." : "Güzel tur! Bir sonraki turda daha da ilerleyebilirsin.";
  $("feedback").className = "feedback success";
  $("nextButton").disabled = true;
  $("skipButton").disabled = true;
  $("progressText").textContent = "Tur tamamlandı";
  $("progressBar").style.width = "100%";
  $("startButton").textContent = "Tekrar oyna ↻";
  $("timer").style.color = "var(--gold)";
  saveProfile();
}
function finishRound(reason) {
  if (gameActive) endGame(reason);
}

function checkAchievements() {
  const rules = [
    { id:"first", icon:"🚀", title:"İlk adım", desc:"İlk oyununu tamamla", test:() => profile.gamesPlayed >= 1 },
    { id:"sharp", icon:"🎯", title:"Keskin göz", desc:"10 doğru cevap ver", test:() => profile.correct >= 10 },
    { id:"collector", icon:"⭐", title:"Puan avcısı", desc:"250 toplam puana ulaş", test:() => profile.totalPoints >= 250 },
    { id:"veteran", icon:"🧭", title:"Gezgin", desc:"5 oyun tamamla", test:() => profile.gamesPlayed >= 5 },
    { id:"master", icon:"👑", title:"Dünya ustası", desc:"Bir turda 150 puan kazan", test:() => profile.bestScore >= 150 }
  ];
  rules.forEach(r => {
    if (r.test() && !profile.badges.includes(r.id)) profile.badges.push(r.id);
  });
}
const achievementRules = [
  { id:"first", icon:"🚀", title:"İlk adım", desc:"İlk oyununu tamamla" },
  { id:"sharp", icon:"🎯", title:"Keskin göz", desc:"10 doğru cevap ver" },
  { id:"collector", icon:"⭐", title:"Puan avcısı", desc:"250 toplam puana ulaş" },
  { id:"veteran", icon:"🧭", title:"Gezgin", desc:"5 oyun tamamla" },
  { id:"master", icon:"👑", title:"Dünya ustası", desc:"Bir turda 150 puan kazan" }
];
function renderAchievements() {
  $("achievements").innerHTML = achievementRules.map(a => {
    const unlocked = profile.badges.includes(a.id);
    return `<div class="achievement ${unlocked ? "unlocked" : ""}"><div class="achievement-icon">${a.icon}</div><div><strong>${a.title}</strong><small>${a.desc}</small></div><span class="muted tiny">${unlocked ? "✓" : "KİLİTLİ"}</span></div>`;
  }).join("");
  $("badgeCount").textContent = `${profile.badges.length}/${achievementRules.length}`;
}
function renderLeaderboard() {
  if (!profile.scores.length) {
    $("leaderboard").innerHTML = '<li class="leader-empty">Henüz skor yok. İlk rekor senin olsun!</li>';
    return;
  }
  $("leaderboard").innerHTML = profile.scores.slice(0,5).map((s,i) =>
    `<li><span class="rank">#${i+1}</span><span class="leader-name">${escapeHtml(s.name)}</span><span class="leader-score">${s.score} P</span></li>`
  ).join("");
}
function updateStats() {
  $("totalPoints").textContent = profile.totalPoints.toLocaleString("tr-TR");
  $("gamesPlayed").textContent = profile.gamesPlayed;
  $("bestScore").textContent = profile.bestScore;
  $("accuracy").textContent = profile.answered ? `${Math.round(profile.correct / profile.answered * 100)}%` : "0%";
}
function renderProfile() {
  const initial = (profile.name.trim()[0] || "K").toLocaleUpperCase("tr-TR");
  $("avatar").textContent = initial;
  $("sideAvatar").textContent = initial;
  $("headerPlayer").textContent = profile.name;
  $("sidePlayerName").textContent = profile.name;
  $("playerLevel").textContent = profile.level;
  $("sidePlayerTitle").textContent = profile.level >= 5 ? "Usta kaşif" : profile.level >= 3 ? "Deneyimli kaşif" : "Yeni kaşif";
  $("xpLabel").textContent = `${profile.xp} / ${profile.level * 100} XP`;
  $("xpBar").style.width = `${Math.min(100, profile.xp / (profile.level * 100) * 100)}%`;
  $("xpHint").textContent = `Bir sonraki seviye için ${profile.level * 100 - profile.xp} XP daha kazan.`;
  updateStats();
}
function openProfile() {
  $("playerNameInput").value = profile.name;
  $("profileModal").hidden = false;
  $("playerNameInput").focus();
}
function closeProfile() { $("profileModal").hidden = true; }
function savePlayerName() {
  const name = $("playerNameInput").value.trim().slice(0,18);
  if (!name) return;
  profile.name = name;
  profile.scores = profile.scores.map(s => ({...s, name: s.name === "Kaşif" ? name : s.name}));
  saveProfile();
  renderProfile();
  renderLeaderboard();
  closeProfile();
}

$("startButton").disabled = true;
init();


// ---------- GÜNLÜK GÖREVLER ----------
const DAILY_KEY = "worldQuizDaily_v1";
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function getDailyState() {
  try {
    const saved = JSON.parse(localStorage.getItem(DAILY_KEY));
    if (saved && saved.date === todayKey()) return saved;
  } catch {}
  return { date: todayKey(), games: 0, correct: 0, points: 0 };
}
let dailyState = getDailyState();
function saveDailyState() {
  localStorage.setItem(DAILY_KEY, JSON.stringify(dailyState));
  renderDailyTasks();
}
function renderDailyTasks() {
  const tasks = [
    { title:"Bir tur tamamla", desc:"Bugün en az bir oyunu bitir.", value:dailyState.games, goal:1, unit:"/ 1" },
    { title:"5 doğru cevap bul", desc:"Bugün beş ülkeyi doğru tanı.", value:dailyState.correct, goal:5, unit:"/ 5" },
    { title:"50 puan kazan", desc:"Günlük toplam 50 puana ulaş.", value:dailyState.points, goal:50, unit:"/ 50" }
  ];
  const date = new Date();
  $("dailyDate").textContent = date.toLocaleDateString("tr-TR",{day:"2-digit",month:"short"});
  $("dailyTasks").innerHTML = tasks.map(t => {
    const v = Math.min(t.value,t.goal), done = t.value >= t.goal;
    return `<div class="daily-task"><div class="daily-task-top"><span>${done ? "✓ " : ""}${t.title}</span><span>${t.value}${t.unit}</span></div><small>${t.desc}</small><div class="daily-task-track"><i style="width:${Math.min(100,t.value/t.goal*100)}%"></i></div></div>`;
  }).join("");
}

// ---------- SES EFEKTLERİ ----------
let audioContext = null;
function playTone(kind) {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    audioContext ||= new AudioCtx();
    if (audioContext.state === "suspended") audioContext.resume();
    const now = audioContext.currentTime;
    const notes = kind === "correct" ? [660, 880] : kind === "wrong" ? [220, 165] : [523, 659, 784];
    notes.forEach((freq, i) => {
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, now + i * 0.11);
      gain.gain.exponentialRampToValueAtTime(0.11, now + i * 0.11 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.11 + 0.16);
      osc.connect(gain); gain.connect(audioContext.destination);
      osc.start(now + i * 0.11); osc.stop(now + i * 0.11 + 0.17);
    });
  } catch (e) { console.debug("Ses efekti kullanılamadı:", e); }
}

// ---------- ÜLKE ANSİKLOPEDİSİ ----------
function getFact(feature, keys) {
  const p = feature.properties || {};
  for (const key of keys) {
    const value = p[key];
    if (value !== undefined && value !== null && String(value).trim() && value !== "-99") return String(value);
  }
  return "Bilgi yok";
}
function openEncyclopedia(feature) {
  const name = countryName(feature);
  const code = countryCode(feature);
  const region = getFact(feature, ["REGION_UN","REGION","CONTINENT","SUBREGION","SUBREGION1"]);
  const capital = getFact(feature, ["CAPITAL","capital","CAPITAL_CITY"]);
  const iso = getFact(feature, ["ISO_A3","ADM0_A3","SOV_A3"]);
  const facts = [
    ["Başkent", capital],
    ["Bölge", region],
    ["Ülke kodu", code ? code.toUpperCase() : "Bilgi yok"],
    ["ISO-3 kodu", iso],
    ["Ülke adı", name],
    ["Yönetim alanı", getFact(feature, ["TYPE","ADMIN_TYPE","TYPE_EN"])]
  ];
  $("encyclopediaTitle").textContent = name;
  $("encyclopediaRegion").textContent = region;
  $("encyclopediaFlag").innerHTML = code ? `<img src="https://flagcdn.com/w160/${code}.png" alt="${escapeHtml(name)} bayrağı" onerror="this.parentElement.textContent='🌍'">` : "🌍";
  $("countryFacts").innerHTML = facts.map(([label,value]) => `<div class="fact"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join("");
  $("encyclopediaModal").hidden = false;
}
function closeEncyclopedia() { $("encyclopediaModal").hidden = true; }

// ---------- ÇEVRİMİÇİ SKOR TABLOSU (FIREBASE İSTEĞE BAĞLI) ----------
function firebaseReady() {
  return Boolean(window.WORLD_QUIZ_FIREBASE_CONFIG &&
    window.WORLD_QUIZ_FIREBASE_CONFIG.apiKey &&
    window.WORLD_QUIZ_FIREBASE_CONFIG.projectId &&
    window.firebase && firebase.apps);
}
async function submitOnlineScore(score) {
  if (!firebaseReady()) return false;
  try {
    if (!firebase.apps.length) firebase.initializeApp(window.WORLD_QUIZ_FIREBASE_CONFIG);
    const db = firebase.firestore();
    await db.collection("worldQuizScores").add({
      name: profile.name,
      score: Number(score),
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    return true;
  } catch (error) {
    console.warn("Çevrimiçi skor gönderilemedi:", error);
    return false;
  }
}
async function loadOnlineScores() {
  if (!firebaseReady()) {
    $("leaderboardStatus").textContent = "YEREL";
    $("leaderboardNote").textContent = "Çevrimiçi sıralama için firebase-config.js dosyasını yapılandır. Şimdilik yerel skorların gösteriliyor.";
    return;
  }
  try {
    if (!firebase.apps.length) firebase.initializeApp(window.WORLD_QUIZ_FIREBASE_CONFIG);
    const snapshot = await firebase.firestore().collection("worldQuizScores")
      .orderBy("score","desc").limit(10).get();
    const entries = snapshot.docs.map(doc => doc.data());
    $("leaderboardStatus").textContent = "ÇEVRİMİÇİ";
    $("leaderboardNote").textContent = "En yüksek 10 skor · Firebase";
    $("leaderboard").innerHTML = entries.length ? entries.map((s,i) =>
      `<li><span class="rank">#${i+1}</span><span class="leader-name">${escapeHtml(s.name || "Kaşif")}</span><span class="leader-score">${Number(s.score)||0} P</span></li>`
    ).join("") : '<li class="leader-empty">Henüz çevrimiçi skor yok.</li>';
  } catch (error) {
    console.warn("Çevrimiçi sıralama okunamadı:", error);
    $("leaderboardStatus").textContent = "YEREL";
    $("leaderboardNote").textContent = "Çevrimiçi tabloya erişilemedi; yerel skorlar gösteriliyor.";
  }
}

// Extend event wiring once DOM is ready (script is loaded at end of body).
$("closeEncyclopedia").addEventListener("click", closeEncyclopedia);
$("encyclopediaModal").addEventListener("click", e => {
  if (e.target === $("encyclopediaModal")) closeEncyclopedia();
});
document.addEventListener("keydown", e => {
  if (e.key === "Escape") { closeEncyclopedia(); closeProfile(); }
});

// Wrap core handlers to update daily tasks, sounds and online score.
const originalCheckAnswer = checkAnswer;
checkAnswer = function(feature, button = null) {
  const wasAnswered = answered;
  originalCheckAnswer(feature, button);
  if (!wasAnswered && answered) {
    if (feature === targetCountry) {
      dailyState.correct++;
      playTone("correct");
      $("questionCard").classList.remove("correct-pulse");
      void $("questionCard").offsetWidth;
      $("questionCard").classList.add("correct-pulse");
    } else {
      playTone("wrong");
      $("questionCard").classList.remove("wrong-shake");
      void $("questionCard").offsetWidth;
      $("questionCard").classList.add("wrong-shake");
    }
    saveDailyState();
  }
};

const originalEndGame = endGame;
endGame = function(reason) {
  if (!gameActive) return;
  dailyState.games++;
  dailyState.points += roundScore;
  saveDailyState();
  originalEndGame(reason);
  playTone("finish");
  submitOnlineScore(roundScore).then(ok => { if (ok) loadOnlineScores(); });
};

// Re-render local stats/profile after name change and start-up.
const originalRenderLeaderboard = renderLeaderboard;
renderLeaderboard = function() {
  originalRenderLeaderboard();
  loadOnlineScores();
};
renderDailyTasks();
renderAchievements();
renderLeaderboard();
