# Evermore: تغليف التطبيق

المجلد `www` هو التطبيق كاملاً (تطبيق ويب قابل للتثبيت PWA يعمل بلا اتصال بعد أول فتح).

## الطريقة 1: الأسرع (بدون برمجة)
1. ارفعي مجلد `www` على أي استضافة HTTPS مجانية: Netlify Drop (اسحبي المجلد في netlify.com/drop) أو GitHub Pages أو Cloudflare Pages.
2. افتحي الرابط في الجوال:
   - أندرويد (Chrome): القائمة ثم «تثبيت التطبيق».
   - آيفون (Safari): زر المشاركة ثم «إضافة إلى الشاشة الرئيسية».
3. لملف أندرويد جاهز (APK/AAB) للمتجر: ادخلي pwabuilder.com، ألصقي الرابط، واختاري Android.

## الطريقة 2: تطبيق أصلي بـ Capacitor
تحتاجين Node.js، وAndroid Studio لأندرويد، وXcode لآيفون (على ماك).
```
npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/filesystem @capacitor/share
npx cap add android
npx cap sync
npx cap open android      # ثم Build > Generate Signed Bundle / APK
```
للآيفون: `npm i @capacitor/ios` ثم `npx cap add ios` ثم `npx cap open ios`.
الإضافتان filesystem وshare تجعلان «حفظ كصورة» و«النسخة الاحتياطية» تعملان داخل التطبيق الأصلي.

## للعمل بلا اتصال بالكامل
- الخطوط وأداة حفظ الصور تُحمَّل أول مرة من الإنترنت ثم تُخزَّن تلقائياً.
- لتخزين أداة الصور محلياً: ضعي ملف `html2canvas.min.js` (الإصدار 1.4.1) بجانب `index.html`.

## ملاحظات
- البيانات تُحفظ في المتصفح أو التطبيق على الجهاز نفسه. للنقل من النسخة التي على claude.ai: الإعدادات ثم «نسخة احتياطية كاملة»، ثم «استعادة نسخة» داخل التطبيق الجديد.
- لتغيير معرّف التطبيق عدّلي `appId` في `capacitor.config.json` قبل النشر في المتجر.
- لم يُبنَ ملف APK هنا ولم يُجرَّب على جهاز: يلزم التوقيع والبناء عندك.
