#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p "$ROOT/www"
# كل ملفات التطبيق (الواجهة + السكربتات + البيانات + الصور + الأيقونات)
for f in index.html manifest.webmanifest wrc4.css wrc4.js wrc4-ar.js wrc4-tr.js wrc4-tr2.js i18n-en.js ux.js audio10.js ar-names.js assistant.js assistant-extra.js wrc-data.js wrc-data.json skillorder.js sitesyn.js siteeng.js sitelists.js; do
  [ -f "$ROOT/$f" ] && cp "$ROOT/$f" "$ROOT/www/"
done
for d in data img icons assets; do
  if [ -d "$ROOT/$d" ]; then rm -rf "$ROOT/www/$d"; cp -R "$ROOT/$d" "$ROOT/www/$d"; fi
done
printf 'Capacitor web assets prepared in %s/www\n' "$ROOT"
