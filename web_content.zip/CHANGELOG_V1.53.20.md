# v1.53.20 — Calendários compactos por resultados

- Os calendários independentes das Séries A, B e C agora persistem apenas clubes, temporada, rodada e placares efetivamente concluídos.
- Os 380 confrontos são reconstruídos de forma determinística ao carregar, e os resultados salvos são reaplicados à partida correta.
- Compatibilidade mantida com o formato antigo que armazenava todas as partidas.
- Objetivo: reduzir drasticamente a quota usada no `localStorage` e impedir que a criação de uma carreira nova falhe ao preparar a Série C.
- Não altera a lógica das partidas da carreira do jogador nem apaga saves/histórico.
