ZABOTKER 3D
Wannan Android Studio project ne da aka shirya domin a gina APK.
Karanta BUILD_INSTRUCTIONS_HAUSA.txt domin matakai.
Ba APK binary ba ne tukuna; sai an gina shi a Android Studio a computer.
