package com.pedrolucas.s27launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.Base64
import java.io.ByteArrayOutputStream
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        web = WebView(this)
        web.setBackgroundColor(Color.TRANSPARENT)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(LauncherBridge(), "AndroidLauncher")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class LauncherBridge {
        @JavascriptInterface
        fun getInstalledApps(): String {
            val list = JSONArray()
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
            val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            val own = packageName
            val seen = HashSet<String>()
            for (info in resolved) {
                val appPackage = info.activityInfo.packageName
                if (appPackage == own || !seen.add(appPackage)) continue
                val item = JSONObject()
                item.put("packageName", appPackage)
                item.put("label", info.loadLabel(pm).toString())
                try {
                    val drawable = info.loadIcon(pm)
                    val bitmap = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bitmap)
                    drawable.setBounds(0, 0, canvas.width, canvas.height)
                    drawable.draw(canvas)
                    val bytes = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes)
                    item.put("icon", Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP))
                    bitmap.recycle()
                } catch (_: Exception) {
                    item.put("icon", "")
                }
                list.put(item)
            }
            return list.toString()
        }

        @JavascriptInterface
        fun launchApp(packageName: String): Boolean {
            return try {
                val launch = packageManager.getLaunchIntentForPackage(packageName) ?: return false
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    override fun onBackPressed() {
        // O botão voltar retorna à tela inicial do launcher.
        web.evaluateJavascript(
            "document.getElementById('appview').classList.remove('show');document.getElementById('drawer').classList.remove('open');",
            null
        )
    }
}
