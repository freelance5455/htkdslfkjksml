# S27 Ultra Launcher — projeto Android

Este é um projeto Android nativo com interface HTML/CSS/JS embutida em WebView.

## O que já está preparado
- Atividade registrada como tela inicial Android (`MAIN` + `HOME` + `DEFAULT`).
- Nome do app: **S27 Ultra**.
- Consulta dos aplicativos com atividade de launcher instalada no aparelho.
- Abertura de aplicativos reais por pacote.
- Interface responsiva com relógio/data, busca, gaveta de aplicativos, dock, papel de parede e tema claro/escuro.
- O HTML fica em `app/src/main/assets/index.html`.

## Como compilar no celular
1. Instale **CodeAssist – Android IDE** pela Google Play Store.
2. Extraia este ZIP para uma pasta do armazenamento.
3. No CodeAssist, abra/importa um projeto existente e selecione a pasta `S27_Ultra_Launcher_Project` (a pasta que contém `settings.gradle`).
4. Aguarde a sincronização e instale os componentes de compilação que o app solicitar.
5. Use **Build/Run** para compilar e instalar o APK de teste.
6. Pressione o botão Home do Android. Escolha **S27 Ultra** e selecione **Sempre** para torná-lo o launcher padrão. Para voltar, vá às configurações do Android > Aplicativos padrão > App de início.

## Observações importantes
- A permissão `QUERY_ALL_PACKAGES` é usada para listar os apps instalados. O Google Play restringe essa permissão e exige justificativa/revisão para publicação. Para uso pessoal por instalação direta, o comportamento depende da versão e fabricante do Android.
- A tela de controle rápido é visual; um app comum não pode alterar livremente Wi-Fi, Bluetooth ou configurações protegidas do sistema.
- O projeto não foi compilado neste ambiente. A compilação final deve ser feita no AndroidIDE, com SDK e Gradle instalados.
- Este é um launcher Android real em desenvolvimento, não uma ROM Samsung e não um produto oficial da Samsung. A aparência é um conceito inspirado em um estilo premium.
