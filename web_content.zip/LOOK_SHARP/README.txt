LOOK SHARP — Starter prototype 1.1

How to use:
1. Extract the ZIP.
2. Open index.html in a modern browser (Chrome recommended).
3. Allow camera/microphone permissions when prompted. Camera and microphone generally require HTTPS or localhost.
4. Use Start/Pause/Reset, voice coach, manual rep counter, and camera preview.

Current limitations:
- Camera is preview only; automatic pose detection and rep counting are not implemented.
- Voice commands use browser speech recognition where supported; this is not a live AI conversation.
- Diet/routine content is general starter guidance, not personalised medical advice.
