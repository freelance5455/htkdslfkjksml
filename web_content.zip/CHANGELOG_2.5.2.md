# Changelog — ANONYMOUX STUDIO 2.5.2 repair candidate

- Added shared Image/Video wallet reservations with unique job references.
- Added idempotent reservation settlement and refund state transitions.
- Added administrator-configurable Image and Video credit prices.
- Added fail-closed billing when prices are not configured.
- Added persisted local job references before provider submission.
- Added conservative handling of uncertain provider outcomes.
- Added cleanup/refund paths for confirmed failed video submissions and jobs.
- Broadened image output validation to supported JPEG, PNG and WebP formats.
- Hardened HTTPS redirects against arbitrary Host headers and untrusted forwarded-protocol headers.
- Updated Flutterwave checkout redirect construction to use canonical server configuration.
- Added a clear PDO SQLite missing-extension response.
- Added billing SQL contract and source-wiring tests.
- Added upgrade, audit and security-checklist documentation.

No original application workspaces were intentionally removed.
