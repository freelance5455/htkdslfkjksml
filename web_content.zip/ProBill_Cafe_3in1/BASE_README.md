# ProBill Cafe 3.0 — Guided Setup

1. Extract ZIP and open index.html in a modern browser.
2. First launch: create a 4-digit owner PIN. Later launches use this PIN.
3. One-time setup: cafe details are all optional. Add at least one menu item to enable billing. No sample menu is preloaded.
4. Billing: choose menu items, quantities, order type and payment, then Save Bill. Each save creates a separate bill number and history entry.
5. Menu: add/edit/delete items and prices.
6. Data stays in this browser on this device. Use Settings > Backup regularly. No cloud sync.

PIN is a simple local app lock, not bank-grade security. Customer name and phone fields are intentionally absent.
