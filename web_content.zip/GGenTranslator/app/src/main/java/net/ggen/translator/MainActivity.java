package net.ggen.translator;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final int PICK = 41;
    private WebView web;
    private ValueCallback<Uri[]> pending;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { /* no browser */ }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (pending != null) pending.onReceiveValue(null);
                pending = cb;
                // Android does not know .gba/.nds/.json as types, so only filter for pictures
                boolean images = true;
                for (String t : p.getAcceptTypes()) if (!t.startsWith("image/") && !t.isEmpty()) images = false;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(images && p.getAcceptTypes().length > 0 && !p.getAcceptTypes()[0].isEmpty() ? "image/*" : "*/*");
                try { startActivityForResult(Intent.createChooser(i, "Choose a file"), PICK); }
                catch (Exception e) { pending = null; return false; }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "GGNative");
        if (saved != null) web.restoreState(saved); else web.loadUrl(HOME);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req != PICK || pending == null) { super.onActivityResult(req, res, data); return; }
        Uri[] r = null;
        if (res == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
        pending.onReceiveValue(r);
        pending = null;
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }

    private void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

    /** Methods the page calls as window.GGNative.* (they run on a background thread). */
    private class Bridge {
        private final Map<Integer, OutputStream> open = new HashMap<>();
        private final Map<Integer, String> names = new HashMap<>();
        private int next = 1;

        private File dbFile(String path) {
            File dir = new File(getFilesDir(), "autosave");
            dir.mkdirs();
            return new File(dir, path.replaceAll("[^A-Za-z0-9_.-]", "__"));
        }
        private String read(File f) throws Exception {
            try (FileInputStream in = new FileInputStream(f)) {
                byte[] b = new byte[(int) f.length()];
                int o = 0, n;
                while (o < b.length && (n = in.read(b, o, b.length - o)) > 0) o += n;
                return new String(b, 0, o, StandardCharsets.UTF_8);
            }
        }

        @JavascriptInterface
        public String dbGet(String path) {
            File f = dbFile(path);
            try { return f.exists() ? read(f) : null; } catch (Exception e) { return null; }
        }

        @JavascriptInterface
        public boolean dbSet(String path, String json) {
            File f = dbFile(path), tmp = new File(f.getPath() + ".tmp");
            try (FileOutputStream o = new FileOutputStream(tmp)) {
                o.write(json.getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) { return false; }
            return tmp.renameTo(f);
        }

        @JavascriptInterface
        public String dbList(String col) {
            StringBuilder sb = new StringBuilder("[");
            File[] fs = dbFile("x").getParentFile().listFiles();
            String pre = col + "__";
            if (fs != null) for (File f : fs) {
                if (!f.getName().startsWith(pre) || f.getName().endsWith(".tmp")) continue;
                try {
                    String s = read(f);
                    if (sb.length() > 1) sb.append(',');
                    sb.append(org.json.JSONObject.quote(s));
                } catch (Exception e) { /* skip */ }
            }
            return sb.append(']').toString();
        }

        @JavascriptInterface
        public synchronized int saveBegin(String name, String mime) {
            name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
            try {
                OutputStream o;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentResolver cr = getContentResolver();
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/G Gen Translator");
                    Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u == null) throw new Exception("no uri");
                    o = cr.openOutputStream(u);
                    names.put(next, "Downloads/G Gen Translator/" + name);
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    dir.mkdirs();
                    File f = new File(dir, name);
                    o = new FileOutputStream(f);
                    names.put(next, f.getPath());
                }
                open.put(next, o);
                return next++;
            } catch (Exception e) {
                toast("Could not save " + name + ": " + e.getMessage());
                return -1;
            }
        }

        @JavascriptInterface
        public synchronized void saveChunk(int id, String b64) {
            OutputStream o = open.get(id);
            if (o == null) return;
            try { o.write(Base64.decode(b64, Base64.DEFAULT)); }
            catch (Exception e) { toast("Saving failed: " + e.getMessage()); open.remove(id); }
        }

        @JavascriptInterface
        public synchronized void saveEnd(int id) {
            OutputStream o = open.remove(id);
            if (o == null) return;
            try { o.close(); toast("Saved to " + names.remove(id)); }
            catch (Exception e) { toast("Saving failed: " + e.getMessage()); }
        }

        @JavascriptInterface
        public void toast(String m) { MainActivity.this.toast(m); }
    }
}
