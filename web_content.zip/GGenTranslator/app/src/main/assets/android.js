/* Android app glue: autosave storage and file downloads through the native bridge (window.GGNative). */
(() => {
  const N = window.GGNative; if (!N) return;
  // --- autosave: the page's "db" (doc().get/set, collection().limit().get) stored as files in the app ---
  const snap = s => { const d = s == null ? null : JSON.parse(s); return { exists: d != null, data: () => d }; };
  const db = {
    doc: path => ({
      get: async () => snap(N.dbGet(path)),
      set: async obj => { if (!N.dbSet(path, JSON.stringify(obj))) throw { code: 'storage' }; }
    }),
    collection: col => ({ limit: () => ({ get: async () => ({ docs: JSON.parse(N.dbList(col) || '[]').map(s => snap(s)) }) }) })
  };
  window.claude = { use: async name => { if (name === 'db') return db; throw { code: 'unavailable' }; } };

  // --- downloads: remember blobs behind blob: URLs, then hand the bytes to the app in chunks ---
  const blobs = new Map(), mk = URL.createObjectURL.bind(URL);
  URL.createObjectURL = o => { const u = mk(o); if (o instanceof Blob) { blobs.set(u, o); setTimeout(() => blobs.delete(u), 120000); } return u; };
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  async function save(name, blob) {
    const id = N.saveBegin(name || 'download', blob.type || 'application/octet-stream'); if (id < 0) return;
    const CH = 768 * 1024;
    for (let o = 0; o < blob.size; o += CH) N.saveChunk(id, b64(new Uint8Array(await blob.slice(o, o + CH).arrayBuffer())));
    N.saveEnd(id);
  }
  const click = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    const h = this.href || '';
    if (this.hasAttribute('download') && (h.startsWith('blob:') || h.startsWith('data:'))) {
      const name = this.getAttribute('download') || 'download';
      const blob = blobs.get(h);
      (blob ? Promise.resolve(blob) : fetch(h).then(r => r.blob())).then(b => save(name, b)).catch(e => N.toast('Could not save ' + name));
      return;
    }
    return click.call(this);
  };
})();
