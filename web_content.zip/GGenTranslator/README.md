# G Gen Translator for Android

This is the G Gen Translator page wrapped in an Android app. In the app:
- ROM, project, image and MIDI pickers open Android's file picker.
- Built ROMs, projects, PNGs, MIDI and WAV files save to Downloads/G Gen Translator.
- Autosave is on: your work is kept inside the app between launches. Still use "Save project" now and then as a backup.
- OpenRouter translation works (needs internet). The built-in Claude engine only works on claude.ai.

## Get the APK (no computer setup needed)
1. Make a free GitHub account, then create a new **private** repository.
2. Upload everything in this folder (keep the folder structure, including `.github/workflows/build.yml`).
   On github.com: "Add file" → "Upload files", then drag the folder contents in.
3. Open the repository's **Actions** tab. The "Build APK" run starts by itself (or press "Run workflow").
4. When it finishes (about 3–5 minutes), open the run and download **G-Gen-Translator-apk** under Artifacts.
5. Unzip it on your phone and open `app-debug.apk`. Allow "Install unknown apps" for your browser/file manager when Android asks.

## Or build in Android Studio
Open this folder in Android Studio and press Run.

## Updating to a newer version of the tool
Replace `app/src/main/assets/index.html` with the new one (it must keep the `<script src="android.js"></script>` line
near the top), raise `versionCode` in `app/build.gradle`, and build again. Installing over the old app keeps your autosave.
