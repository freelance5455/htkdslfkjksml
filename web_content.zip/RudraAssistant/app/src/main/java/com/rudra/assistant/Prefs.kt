package com.rudra.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class VoiceCode(val id: String, val code: String, val file: String)

object Prefs {
    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("rudra_prefs", Context.MODE_PRIVATE)

    fun isEnabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("enabled", v).apply()
    }

    fun style(c: Context): Int = sp(c).getInt("style", 1).coerceIn(1, 3)
    fun setStyle(c: Context, v: Int) {
        sp(c).edit().putInt("style", v).apply()
    }

    fun lang(c: Context): String = sp(c).getString("lang", "en-IN") ?: "en-IN"
    fun setLang(c: Context, v: String) {
        sp(c).edit().putString("lang", v).apply()
    }

    fun codes(c: Context): List<VoiceCode> {
        val out = ArrayList<VoiceCode>()
        try {
            val arr = JSONArray(sp(c).getString("codes", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(VoiceCode(o.getString("id"), o.getString("code"), o.getString("file")))
            }
        } catch (e: Exception) {
            // ignore corrupt data
        }
        return out
    }

    fun saveCodes(c: Context, list: List<VoiceCode>) {
        val arr = JSONArray()
        for (vc in list) {
            val o = JSONObject()
            o.put("id", vc.id)
            o.put("code", vc.code)
            o.put("file", vc.file)
            arr.put(o)
        }
        sp(c).edit().putString("codes", arr.toString()).apply()
    }
}
