package com.rudra.assistant.assistant

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionSession
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import com.rudra.assistant.Commands
import com.rudra.assistant.Prefs
import com.rudra.assistant.VoiceCode
import java.io.File
import java.util.Locale

/**
 * The popup that rises from the bottom of the screen when the user presses and holds the
 * Home / centre button (the same place where Gemini / Siri appear).
 *
 *  - Assistant switch OFF in the app  -> nothing is shown at all.
 *  - Assistant switch ON              -> the chosen pill appears and the phone starts listening right away
 *                                        (no "Hey Rudra" needed).
 */
class RudraSession(private val svc: Context) : VoiceInteractionSession(svc) {

    private val handler = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var web: WebView? = null
    private var pageReady = false
    private val pendingJs = ArrayList<String>()

    private var recognizer: SpeechRecognizer? = null
    private var player: MediaPlayer? = null
    private var retries = 0
    private var active = false

    // ------------------------------------------------------------------ session lifecycle
    override fun onPrepareShow(args: Bundle?, showFlags: Int) {
        super.onPrepareShow(args, showFlags)
        // Switch OFF -> do not even create the UI.
        setUiEnabled(Prefs.isEnabled(svc))
    }

    override fun onCreateContentView(): View {
        val r = FrameLayout(svc)
        r.setBackgroundColor(Color.TRANSPARENT)

        val w = WebView(svc)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.isVerticalScrollBarEnabled = false
        w.isHorizontalScrollBarEnabled = false
        val s = w.settings
        s.javaScriptEnabled = true
        s.allowContentAccess = false
        s.blockNetworkLoads = true
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                for (c in pendingJs) view?.evaluateJavascript(c, null)
                pendingJs.clear()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
        }
        w.loadUrl("file:///android_asset/pill.html?mode=assistant")

        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340))
        lp.gravity = Gravity.BOTTOM
        r.addView(w, lp)

        // tap on the empty area = close
        r.setOnClickListener { closeSession() }

        root = r
        web = w
        return r
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        if (!Prefs.isEnabled(svc)) {
            hide()
            return
        }
        styleWindow()
        active = true
        retries = 0
        handler.removeCallbacksAndMessages(null)

        js("Rudra.setSpeaking(false);Rudra.setLevel(0);Rudra.show(" + Prefs.style(svc) + ")")

        if (svc.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Pehle Hey Rudra app kholkar mic permission do")
            handler.postDelayed({ closeSession() }, 1500)
            return
        }
        startListening()
    }

    override fun onHide() {
        super.onHide()
        active = false
        handler.removeCallbacksAndMessages(null)
        stopRecognizer()
        stopPlayer()
        js("Rudra.hide()")
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        stopRecognizer()
        stopPlayer()
        try {
            web?.destroy()
        } catch (e: Exception) {
        }
        web = null
    }

    // ------------------------------------------------------------------ helpers
    private fun dp(v: Int): Int = (v * svc.resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        try {
            Toast.makeText(svc, s, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
    }

    private fun js(code: String) {
        val w = web
        if (w != null && pageReady) w.evaluateJavascript(code, null) else pendingJs.add(code)
    }

    private fun styleWindow() {
        try {
            val win = window.window
            if (win != null) {
                win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                win.setDimAmount(0f)
                win.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                win.setGravity(Gravity.BOTTOM)
            }
        } catch (e: Throwable) {
        }
    }

    private fun closeSession() {
        if (!active) return
        active = false
        handler.removeCallbacksAndMessages(null)
        stopRecognizer()
        stopPlayer()
        js("Rudra.hide()")
        handler.postDelayed({ hide() }, 380)
    }

    private fun closeAfter(ms: Long) {
        handler.postDelayed({ active = true; closeSession() }, ms)
    }

    // ------------------------------------------------------------------ listening
    private fun createRecognizer(): SpeechRecognizer? {
        return try {
            val pm = svc.packageManager
            val list = pm.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
                .filter { it.serviceInfo.packageName != svc.packageName }
            val pick = list.firstOrNull { it.serviceInfo.packageName == "com.google.android.googlequicksearchbox" }
                ?: list.firstOrNull()
            if (pick != null) {
                SpeechRecognizer.createSpeechRecognizer(
                    svc, ComponentName(pick.serviceInfo.packageName, pick.serviceInfo.name)
                )
            } else if (SpeechRecognizer.isRecognitionAvailable(svc)) {
                SpeechRecognizer.createSpeechRecognizer(svc)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun startListening() {
        stopRecognizer()
        val r = createRecognizer()
        if (r == null) {
            toast("Speech recogniser nahi mila. Google app install/enable karo.")
            closeAfter(1200)
            return
        }
        recognizer = r
        r.setRecognitionListener(listener)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(svc))
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, svc.packageName)
        try {
            r.startListening(i)
        } catch (e: Exception) {
            toast("Mic start nahi hua")
            closeAfter(1000)
        }
    }

    private fun stopRecognizer() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            // roughly -2 dB (silence) .. 10 dB (loud) -> 0..1
            val lv = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            js("Rudra.setLevel($lv)")
        }

        override fun onError(error: Int) {
            if (!active) return
            val soft = error == SpeechRecognizer.ERROR_NO_MATCH ||
                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
            if (soft && retries < 1) {
                retries++
                handler.postDelayed({ if (active) startListening() }, 250)
            } else if (soft) {
                toast("Kuch sunai nahi diya")
                closeSession()
            } else {
                toast("Mic error ($error)")
                closeSession()
            }
        }

        override fun onResults(results: Bundle?) {
            if (!active) return
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: ArrayList<String>()
            handleSpeech(list)
        }
    }

    // ------------------------------------------------------------------ understanding the command
    private fun handleSpeech(texts: List<String>) {
        if (texts.isEmpty()) {
            closeSession()
            return
        }
        js("Rudra.setLevel(0)")

        // 1) secret code -> play its MP3
        val spoken = texts.map { Commands.normalizeCode(it) }
        for (vc in Prefs.codes(svc)) {
            val n = Commands.normalizeCode(vc.code)
            if (n.length >= 4 && spoken.any { it.contains(n) }) {
                playCode(vc)
                return
            }
        }

        // 2) call <contact>
        val callTarget = Commands.extractCallTarget(texts)
        if (callTarget != null) {
            doCall(callTarget)
            return
        }

        // 3) date / time pill
        if (Commands.wantsDate(texts)) {
            showInfoPill("date")
            return
        }
        if (Commands.wantsTime(texts)) {
            showInfoPill("time")
            return
        }

        // 4) WhatsApp / Instagram / YouTube / Facebook
        val app = Commands.findApp(texts)
        if (app != null) {
            val intent = Commands.launchIntent(svc, app)
            if (intent == null) {
                toast(app.label + " install nahi hai")
                closeAfter(900)
            } else {
                launch(intent)
                closeAfter(500)
            }
            return
        }

        // 5) "open <any installed app>"
        val pkg = Commands.findInstalledByLabel(svc, texts)
        if (pkg != null) {
            val intent = svc.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                launch(intent)
                closeAfter(500)
                return
            }
        }

        toast("Samajh nahi aaya: " + texts[0])
        closeAfter(900)
    }

    private fun showInfoPill(which: String) {
        js("Rudra.show('$which')")
        handler.postDelayed({ active = true; closeSession() }, 4500)
    }

    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startAssistantActivity(intent)
        } catch (e: Exception) {
            try {
                svc.startActivity(intent)
            } catch (e2: Exception) {
                toast("Open nahi ho paya")
            }
        }
    }

    private fun doCall(target: String) {
        val digits = target.replace(Regex("[\\s\\-()]"), "")
        var number: String? = null
        var label = target
        if (digits.length >= 3 && digits.all { it.isDigit() || it == '+' }) {
            number = digits
        } else {
            if (svc.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                toast("Contacts permission do (app me)")
                closeAfter(1200)
                return
            }
            val c = Commands.findContact(svc, target)
            if (c != null) {
                number = c.number
                label = c.name
            }
        }
        if (number == null) {
            toast("Contact nahi mila: $target")
            closeAfter(1200)
            return
        }
        val canCall = svc.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val action = if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:" + Uri.encode(number)))
        toast("Call: $label")
        launch(intent)
        closeAfter(600)
    }

    // ------------------------------------------------------------------ voice code audio
    private fun playCode(vc: VoiceCode) {
        stopRecognizer()
        val f = File(File(svc.filesDir, "codes"), vc.file)
        if (!f.exists()) {
            toast("Is code ka audio nahi mila")
            closeAfter(900)
            return
        }
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { closeSession() }
            mp.setOnErrorListener { _, _, _ ->
                closeSession()
                true
            }
            mp.prepare()
            mp.start()
            player = mp
            js("Rudra.setSpeaking(true)")
        } catch (e: Exception) {
            toast("Audio chal nahi paya")
            closeAfter(900)
        }
    }

    private fun stopPlayer() {
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        js("Rudra.setSpeaking(false)")
    }
}
