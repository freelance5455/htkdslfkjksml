package com.rudra.assistant

import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * The app password is NOT stored in the app. Only a salted PBKDF2-HMAC-SHA256 hash is,
 * so reading the APK does not reveal the password.
 */
object Auth {
    private const val ITERATIONS = 120000
    private const val SALT_HEX = "9b7a65a393dacfbe23e3e90b0223a479"
    private const val HASH_HEX = "7ca559b8ff4a01f7c7bae27a59397d8fe5211684ad0088b1636e851f98f763bf"

    fun verify(password: String): Boolean {
        return try {
            val spec = PBEKeySpec(password.toCharArray(), hex(SALT_HEX), ITERATIONS, 256)
            val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            MessageDigest.isEqual(key, hex(HASH_HEX))
        } catch (e: Exception) {
            false
        }
    }

    private fun hex(s: String): ByteArray {
        val out = ByteArray(s.length / 2)
        for (i in out.indices) {
            out[i] = s.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
        return out
    }
}

/** In-memory "is the app unlocked right now" flag. Cleared when the app leaves the screen. */
object Session {
    @Volatile
    var unlocked: Boolean = false
}
