package com.rudra.assistant

import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import java.util.Locale

class AppTarget(val label: String, val packages: List<String>, val aliases: List<String>)

/** Everything that understands what the user said. No UI in here. */
object Commands {

    // ------------------------------------------------------------------ voice codes
    private val spoken = mapOf(
        "zero" to "0", "one" to "1", "two" to "2", "three" to "3", "four" to "4",
        "five" to "5", "six" to "6", "seven" to "7", "eight" to "8", "nine" to "9",
        "शून्य" to "0", "एक" to "1", "दो" to "2", "तीन" to "3", "चार" to "4",
        "पांच" to "5", "पाँच" to "5", "छह" to "6", "छः" to "6", "सात" to "7", "आठ" to "8", "नौ" to "9",
        "hash" to "", "pound" to "", "number" to "", "code" to "", "no" to "",
        "हैश" to "", "नंबर" to "", "कोड" to ""
    )

    /** "hash 7524 G F zero" , "#7524gf0" , "7524 GF0"  ->  "7524GF0" */
    fun normalizeCode(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            if (Character.isDigit(ch)) sb.append(Character.digit(ch, 10)) else sb.append(ch)
        }
        val tokens = sb.toString().lowercase(Locale.ROOT).split(Regex("[\\s,.\\-_#]+"))
        val joined = StringBuilder()
        for (t in tokens) {
            joined.append(spoken[t] ?: t)
        }
        val out = StringBuilder()
        for (ch in joined) {
            if ((ch in 'a'..'z') || (ch in '0'..'9')) out.append(ch.uppercaseChar())
        }
        return out.toString()
    }

    // ------------------------------------------------------------------ time / date
    private val dateWords = listOf(
        "date", "tarikh", "tareekh", "dinank", "तारीख", "तारिख", "तिथि", "दिनांक", "आज की तारीख"
    )
    private val timeWords = listOf(
        "time", "samay", "samai", "waqt", "vaqt", "kitne baje", "baje",
        "टाइम", "समय", "वक्त", "वक़्त", "कितने बजे", "बजे"
    )

    private fun hasWord(text: String, w: String): Boolean {
        val l = text.lowercase(Locale.ROOT)
        val plain = w.all { it.code < 128 && it != ' ' }
        return if (plain) l.split(Regex("[\\s,.?!]+")).any { it == w } else l.contains(w)
    }

    fun wantsDate(texts: List<String>) = texts.any { t -> dateWords.any { hasWord(t, it) } }
    fun wantsTime(texts: List<String>) = texts.any { t -> timeWords.any { hasWord(t, it) } }

    // ------------------------------------------------------------------ open app
    private val apps = listOf(
        AppTarget(
            "WhatsApp", listOf("com.whatsapp", "com.whatsapp.w4b"),
            listOf("whatsapp", "whats app", "whatsap", "watsapp", "वाट्सएप", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सऐप", "व्हॉट्सएप", "व्हाट्स ऐप")
        ),
        AppTarget(
            "Instagram", listOf("com.instagram.android"),
            listOf("instagram", "insta gram", "insta", "इंस्टाग्राम", "इंस्टा", "इन्स्टाग्राम", "इंस्टाग्राम")
        ),
        AppTarget(
            "YouTube", listOf("com.google.android.youtube"),
            listOf("youtube", "you tube", "u tube", "यूट्यूब", "यू ट्यूब", "यूटयूब", "यूटूब")
        ),
        AppTarget(
            "Facebook", listOf("com.facebook.katana", "com.facebook.lite"),
            listOf("facebook", "face book", "फेसबुक", "फ़ेसबुक", "फेस बुक")
        )
    )

    fun findApp(texts: List<String>): AppTarget? {
        for (t in texts) {
            val l = t.lowercase(Locale.ROOT)
            for (a in apps) {
                if (a.aliases.any { l.contains(it) }) return a
            }
        }
        return null
    }

    /** First installed package of the target, or null. */
    fun launchIntent(ctx: Context, target: AppTarget): Intent? {
        for (p in target.packages) {
            val i = ctx.packageManager.getLaunchIntentForPackage(p)
            if (i != null) return i
        }
        return null
    }

    private val openWords = setOf(
        "open", "kholo", "khol", "kholna", "खोलो", "खोल", "खोलना", "chalu", "चालू", "start", "launch", "चलाओ", "chalao"
    )
    private val fillerWords = setOf(
        "karo", "kar", "kro", "करो", "कर", "app", "ऐप", "एप", "को", "ko", "please", "plz", "the", "my", "मेरा", "mera", "me", "मे", "में"
    )

    /** "open calculator" -> package of an installed launcher app whose label matches. */
    fun findInstalledByLabel(ctx: Context, texts: List<String>): String? {
        for (t in texts) {
            val tokens = t.lowercase(Locale.ROOT).split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (tokens.none { it in openWords }) continue
            val q = tokens.filter { it !in openWords && it !in fillerWords }.joinToString("")
                .replace(Regex("[^\\p{L}\\p{N}]"), "")
            if (q.length < 3) continue
            val pm = ctx.packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            var best: String? = null
            var bestScore = Int.MAX_VALUE
            for (ri in pm.queryIntentActivities(main, 0)) {
                val label = ri.loadLabel(pm).toString().lowercase(Locale.ROOT)
                    .replace(Regex("[^\\p{L}\\p{N}]"), "")
                if (label.isEmpty()) continue
                val score = when {
                    label == q -> 0
                    label.contains(q) || q.contains(label) -> 1
                    else -> {
                        val d = levenshtein(label, q)
                        if (d <= maxOf(1, q.length / 4)) 2 + d else Int.MAX_VALUE
                    }
                }
                if (score < bestScore) {
                    bestScore = score
                    best = ri.activityInfo.packageName
                }
            }
            if (best != null) return best
        }
        return null
    }

    // ------------------------------------------------------------------ call
    private val callWords = setOf("call", "कॉल", "काल", "phone", "फोन", "dial", "डायल")
    private val callStop = setOf(
        "call", "कॉल", "काल", "phone", "फोन", "dial", "डायल", "karo", "kar", "kro", "करो", "कर",
        "lagao", "laga", "लगाओ", "लगा", "to", "ko", "को", "please", "plz", "mujhe", "मुझे", "kijiye", "कीजिए"
    )

    /** Returns the name (or number) the user wants to call, or null if this is not a call command. */
    fun extractCallTarget(texts: List<String>): String? {
        for (t in texts) {
            val tokens = t.lowercase(Locale.ROOT).split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (tokens.none { it in callWords }) continue
            val rest = tokens.filter { it !in callStop }.joinToString(" ").trim()
            if (rest.isNotEmpty()) return rest
        }
        return null
    }

    class Contact(val name: String, val number: String)

    /** Fuzzy search in the phone's contacts. Needs READ_CONTACTS. */
    fun findContact(ctx: Context, query: String): Contact? {
        val q = query.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]"), "")
        if (q.isEmpty()) return null
        var best: Contact? = null
        var bestScore = Int.MAX_VALUE
        try {
            val cur = ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )
            cur?.use {
                while (it.moveToNext()) {
                    val name = it.getString(0) ?: continue
                    val number = it.getString(1) ?: continue
                    val n = name.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]"), "")
                    if (n.isEmpty()) continue
                    val score = when {
                        n == q -> 0
                        n.startsWith(q) || q.startsWith(n) -> 1
                        n.contains(q) || q.contains(n) -> 2
                        else -> {
                            // also compare with just the first name
                            val first = name.trim().split(Regex("\\s+"))[0].lowercase(Locale.ROOT)
                                .replace(Regex("[^\\p{L}\\p{N}]"), "")
                            val d = minOf(levenshtein(n, q), if (first.isNotEmpty()) levenshtein(first, q) else 99)
                            if (d <= maxOf(1, q.length / 4)) 3 + d else Int.MAX_VALUE
                        }
                    }
                    if (score < bestScore) {
                        bestScore = score
                        best = Contact(name, number)
                    }
                }
            }
        } catch (e: Exception) {
            return null
        }
        return best
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }
}
