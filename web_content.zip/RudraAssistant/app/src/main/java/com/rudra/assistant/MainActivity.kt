package com.rudra.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.UUID

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var switchAssistant: Switch
    private lateinit var txtState: TextView
    private lateinit var txtDefault: TextView
    private lateinit var btnDefault: Button
    private lateinit var btnPerms: Button
    private lateinit var styleList: LinearLayout
    private lateinit var codeList: LinearLayout
    private lateinit var btnAddCode: Button
    private lateinit var langGroup: RadioGroup
    private lateinit var langEn: RadioButton
    private lateinit var langHi: RadioButton
    private lateinit var btnLock: Button
    private lateinit var popupWeb: WebView

    private val styleCards = ArrayList<FrameLayout>()
    private val allWebs = ArrayList<WebView>()

    private var popupReady = false
    private var pendingIntro: (() -> Unit)? = null
    private var suppressSwitch = false
    private var keepUnlocked = false

    private var pendingUri: Uri? = null
    private var dlgFileLabel: TextView? = null
    private var player: MediaPlayer? = null

    private val perms = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CONTACTS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.unlocked) {
            startActivity(Intent(this, LockActivity::class.java))
            finish()
            return
        }
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_main)

        switchAssistant = findViewById(R.id.switchAssistant)
        txtState = findViewById(R.id.txtState)
        txtDefault = findViewById(R.id.txtDefault)
        btnDefault = findViewById(R.id.btnDefault)
        btnPerms = findViewById(R.id.btnPerms)
        styleList = findViewById(R.id.styleList)
        codeList = findViewById(R.id.codeList)
        btnAddCode = findViewById(R.id.btnAddCode)
        langGroup = findViewById(R.id.langGroup)
        langEn = findViewById(R.id.langEn)
        langHi = findViewById(R.id.langHi)
        btnLock = findViewById(R.id.btnLock)
        popupWeb = findViewById(R.id.popupWeb)

        setupWeb(popupWeb)
        popupWeb.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                popupReady = true
                pendingIntro?.invoke()
                pendingIntro = null
            }
        }
        popupWeb.loadUrl("file:///android_asset/pill.html?mode=assistant")

        // master switch (default OFF)
        suppressSwitch = true
        switchAssistant.isChecked = Prefs.isEnabled(this)
        suppressSwitch = false
        updateState()
        switchAssistant.setOnCheckedChangeListener { _, checked ->
            if (suppressSwitch) return@setOnCheckedChangeListener
            Prefs.setEnabled(this, checked)
            updateState()
            if (checked) {
                ensurePermissions()
                showIntroPills()
            }
        }

        btnDefault.setOnClickListener { openAssistantSettings() }
        btnPerms.setOnClickListener { ensurePermissions(true) }
        btnAddCode.setOnClickListener { showAddDialog() }
        btnLock.setOnClickListener {
            Session.unlocked = false
            startActivity(Intent(this, LockActivity::class.java))
            finish()
        }

        // language
        if (Prefs.lang(this) == "hi-IN") langHi.isChecked = true else langEn.isChecked = true
        langGroup.setOnCheckedChangeListener { _, id ->
            Prefs.setLang(this, if (id == R.id.langHi) "hi-IN" else "en-IN")
        }

        buildStyleCards()
        refreshCodes()
    }

    // ------------------------------------------------------------------ lifecycle / lock
    override fun onStart() {
        super.onStart()
        if (!Session.unlocked && !isFinishing) {
            startActivity(Intent(this, LockActivity::class.java))
            finish()
            return
        }
        for (w in allWebs) w.onResume()
    }

    override fun onResume() {
        super.onResume()
        keepUnlocked = false
        if (Session.unlocked) updateDefaultStatus()
    }

    override fun onStop() {
        super.onStop()
        for (w in allWebs) w.onPause()
        if (!isChangingConfigurations && !keepUnlocked) {
            Session.unlocked = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }

    // ------------------------------------------------------------------ helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun setupWeb(w: WebView) {
        w.setBackgroundColor(Color.TRANSPARENT)
        w.isVerticalScrollBarEnabled = false
        w.isHorizontalScrollBarEnabled = false
        val s = w.settings
        s.javaScriptEnabled = true
        s.allowContentAccess = false
        s.blockNetworkLoads = true
        w.webViewClient = WebViewClient()
        allWebs.add(w)
    }

    private fun updateState() {
        txtState.text = if (switchAssistant.isChecked)
            "ON · Home/center button dabake rakho aur bolo"
        else
            "OFF · abhi kuch nahi dikhega"
    }

    private fun isDefaultAssistant(): Boolean {
        return try {
            val v = Settings.Secure.getString(contentResolver, "assistant") ?: ""
            v.startsWith("$packageName/")
        } catch (e: Exception) {
            false
        }
    }

    private fun updateDefaultStatus() {
        if (isDefaultAssistant()) {
            txtDefault.text = "✅ Rudra abhi default assistant hai"
            txtDefault.setTextColor(Color.parseColor("#4ADE80"))
            btnDefault.text = "Assistant settings kholo"
        } else {
            txtDefault.text = "⚠️ Rudra abhi default assistant nahi hai. Neeche wale button se Rudra select karo, tabhi Home button dabane par ye aayega."
            txtDefault.setTextColor(Color.parseColor("#FBBF24"))
            btnDefault.text = "Rudra ko default assistant banao"
        }
    }

    private fun openAssistantSettings() {
        keepUnlocked = true
        try {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (e2: Exception) {
                toast("Settings > Apps > Default apps > Digital assistant app me jao")
            }
        }
    }

    private fun ensurePermissions(showMsg: Boolean = false) {
        val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) {
            keepUnlocked = true
            requestPermissions(need.toTypedArray(), 101)
        } else if (showMsg) {
            toast("Saari permissions mil chuki hain ✅")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Mic permission ke bina assistant sun nahi payega")
        }
    }

    // ------------------------------------------------------------------ intro pills when switched ON
    private fun popupJs(code: String) {
        popupWeb.evaluateJavascript(code, null)
    }

    private fun showIntroPills() {
        val run: () -> Unit = {
            popupWeb.visibility = View.VISIBLE
            popupJs("Rudra.show('time')")
            handler.postDelayed({ popupJs("Rudra.show('date')") }, 2600)
            handler.postDelayed({ popupJs("Rudra.hide()") }, 5200)
            handler.postDelayed({ popupWeb.visibility = View.GONE }, 5900)
        }
        if (popupReady) run() else pendingIntro = run
    }

    // ------------------------------------------------------------------ style picker
    private fun buildStyleCards() {
        styleList.removeAllViews()
        styleCards.clear()
        val names = listOf("1 · Blue Pill", "2 · Royal Gold Orb", "3 · Voice Loader")
        for (i in 1..3) {
            val card = FrameLayout(this)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170))
            lp.bottomMargin = dp(12)
            card.layoutParams = lp

            val wv = WebView(this)
            setupWeb(wv)
            wv.loadUrl("file:///android_asset/pill.html?mode=preview&style=$i")
            val wlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            wlp.setMargins(dp(8), dp(8), dp(8), dp(8))
            card.addView(wv, wlp)

            val label = TextView(this)
            label.text = names[i - 1]
            label.setTextColor(Color.parseColor("#8D93A7"))
            label.textSize = 12f
            val llp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            llp.gravity = Gravity.TOP or Gravity.START
            llp.setMargins(dp(14), dp(10), 0, 0)
            card.addView(label, llp)

            // transparent layer on top so a tap selects the style (the WebView would eat it)
            val tap = View(this)
            tap.isClickable = true
            tap.setOnClickListener {
                Prefs.setStyle(this, i)
                refreshStyleSelection()
            }
            card.addView(tap, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

            styleList.addView(card)
            styleCards.add(card)
        }
        refreshStyleSelection()
    }

    private fun refreshStyleSelection() {
        val sel = Prefs.style(this)
        for ((idx, c) in styleCards.withIndex()) {
            c.setBackgroundResource(if (idx + 1 == sel) R.drawable.bg_card_selected else R.drawable.bg_card)
        }
    }

    // ------------------------------------------------------------------ voice codes
    private fun refreshCodes() {
        codeList.removeAllViews()
        val list = Prefs.codes(this)
        if (list.isEmpty()) {
            val t = TextView(this)
            t.text = "Abhi koi code nahi hai."
            t.setTextColor(Color.parseColor("#8D93A7"))
            t.textSize = 13f
            t.setPadding(0, 0, 0, dp(10))
            codeList.addView(t)
            return
        }
        for (vc in list) codeList.addView(codeRow(vc))
    }

    private fun codeRow(vc: VoiceCode): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setBackgroundResource(R.drawable.bg_card)
        row.setPadding(dp(16), dp(12), dp(8), dp(12))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(10)
        row.layoutParams = lp

        val name = TextView(this)
        name.text = vc.code
        name.setTextColor(Color.WHITE)
        name.textSize = 16f
        name.setTypeface(name.typeface, android.graphics.Typeface.BOLD)
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val play = TextView(this)
        play.text = "▶"
        play.textSize = 20f
        play.setTextColor(Color.parseColor("#5B6CFF"))
        play.setPadding(dp(14), dp(6), dp(14), dp(6))
        play.setOnClickListener { playTest(vc) }
        row.addView(play)

        val del = TextView(this)
        del.text = "✕"
        del.textSize = 18f
        del.setTextColor(Color.parseColor("#F0453F"))
        del.setPadding(dp(14), dp(6), dp(14), dp(6))
        del.setOnClickListener { deleteCode(vc) }
        row.addView(del)
        return row
    }

    private fun playTest(vc: VoiceCode) {
        try {
            player?.release()
            val f = File(File(filesDir, "codes"), vc.file)
            if (!f.exists()) {
                toast("Audio file nahi mili")
                return
            }
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { it.release() }
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            toast("Audio chal nahi paya")
        }
    }

    private fun deleteCode(vc: VoiceCode) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Code hatana hai?")
            .setMessage(vc.code)
            .setPositiveButton("Haan, hatao") { _, _ ->
                try {
                    File(File(filesDir, "codes"), vc.file).delete()
                } catch (e: Exception) {
                }
                Prefs.saveCodes(this, Prefs.codes(this).filter { it.id != vc.id })
                refreshCodes()
            }
            .setNegativeButton("Nahi", null)
            .show()
    }

    private fun showAddDialog() {
        pendingUri = null
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(8), dp(22), 0)

        val etCode = EditText(this)
        etCode.hint = "Code, jaise #7524GF0"
        etCode.setSingleLine()
        etCode.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        etCode.setTextColor(Color.WHITE)
        etCode.setHintTextColor(Color.parseColor("#8D93A7"))
        box.addView(etCode)

        val lbl = TextView(this)
        lbl.text = "Koi audio file nahi chuni"
        lbl.setTextColor(Color.parseColor("#8D93A7"))
        lbl.textSize = 13f
        lbl.setPadding(0, dp(12), 0, dp(4))
        dlgFileLabel = lbl

        val pick = Button(this)
        pick.text = "Audio (MP3) chuno"
        pick.isAllCaps = false
        pick.setOnClickListener {
            keepUnlocked = true
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "audio/*"
            startActivityForResult(i, 201)
        }
        box.addView(pick)
        box.addView(lbl)

        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Naya voice code")
            .setView(box)
            .setPositiveButton("Save") { _, _ -> saveCode(etCode.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 201 && resultCode == RESULT_OK) {
            val u = data?.data
            pendingUri = u
            if (u != null) dlgFileLabel?.text = "✔ " + displayName(u)
        }
    }

    private fun displayName(u: Uri): String {
        try {
            contentResolver.query(u, null, null, null, null)?.use {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && it.moveToFirst()) return it.getString(idx) ?: "audio"
            }
        } catch (e: Exception) {
        }
        return "audio"
    }

    private fun saveCode(raw: String) {
        val norm = Commands.normalizeCode(raw)
        val uri = pendingUri
        if (norm.length < 4) {
            toast("Code kam se kam 4 letters/digits ka rakho")
            return
        }
        if (uri == null) {
            toast("Pehle audio file chuno, phir Save karo")
            return
        }
        if (Prefs.codes(this).any { Commands.normalizeCode(it.code) == norm }) {
            toast("Ye code pehle se hai")
            return
        }
        Thread {
            try {
                val id = UUID.randomUUID().toString()
                val dir = File(filesDir, "codes")
                dir.mkdirs()
                val out = File(dir, "$id.audio")
                contentResolver.openInputStream(uri)?.use { input ->
                    out.outputStream().use { o -> input.copyTo(o) }
                }
                val list = Prefs.codes(this).toMutableList()
                list.add(VoiceCode(id, "#$norm", "$id.audio"))
                Prefs.saveCodes(this, list)
                runOnUiThread {
                    refreshCodes()
                    toast("Code save ho gaya ✅")
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Audio save nahi ho paya") }
            }
        }.start()
    }
}
