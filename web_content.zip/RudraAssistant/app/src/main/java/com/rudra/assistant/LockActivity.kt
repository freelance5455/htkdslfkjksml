package com.rudra.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class LockActivity : Activity() {

    private lateinit var etPass: EditText
    private lateinit var txtErr: TextView
    private lateinit var btnUnlock: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // No screenshots / screen recording / recents thumbnail of this screen.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_lock)

        etPass = findViewById(R.id.etPass)
        txtErr = findViewById(R.id.txtErr)
        btnUnlock = findViewById(R.id.btnUnlock)

        btnUnlock.setOnClickListener { attempt() }
        etPass.setOnEditorActionListener { _, _, _ ->
            attempt()
            true
        }
    }

    private fun attempt() {
        val sp = getSharedPreferences("rudra_lock", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val until = sp.getLong("until", 0L)
        if (now < until) {
            txtErr.text = "Bahut galat try ho gaye. " + ((until - now) / 1000 + 1) + " second ruko."
            return
        }

        val pw = etPass.text.toString()
        if (Auth.verify(pw)) {
            sp.edit().putInt("fails", 0).putLong("until", 0L).apply()
            Session.unlocked = true
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            val fails = sp.getInt("fails", 0) + 1
            var lockUntil = 0L
            if (fails >= 5) {
                val shift = minOf(fails - 5, 6)
                lockUntil = now + 30000L * (1L shl shift)
            }
            sp.edit().putInt("fails", fails).putLong("until", lockUntil).apply()
            txtErr.text = if (lockUntil > 0L) "Galat password. Kuch der ruko." else "Galat password."
            etPass.setText("")
        }
    }
}
