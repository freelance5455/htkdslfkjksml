package com.rudra.assistant.assistant

import android.service.voice.VoiceInteractionService

/** Registers Rudra as a Digital Assistant app. All the work happens in [RudraSession]. */
class RudraInteractionService : VoiceInteractionService()
