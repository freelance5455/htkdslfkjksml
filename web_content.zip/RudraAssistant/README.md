# Hey Rudra – Voice Assistant (Android)

## APK kaise banaye (2 aasan tareeke)

### Tareeka 1 – GitHub se (computer ya Android Studio ki zaroorat nahi)
1. github.com par free account banao, **New repository** banao (Private rakh sakte ho).
2. Is zip ko khol kar andar ki saari files repository me upload karo (**Add file → Upload files**).
   `.github/workflows/build-apk.yml` file bhi upload honi chahiye (hidden folder hai). Agar upload na ho to
   **Add file → Create new file**, naam me `.github/workflows/build-apk.yml` likho aur file ka text paste karo.
3. **Actions** tab → **Build APK** → **Run workflow**. 3-5 minute me green tick aayega.
4. Us run ko kholo → neeche **Artifacts → RudraAssistant-APK** download karo → zip kholo → `app-debug.apk`.
5. APK ko phone me bhejo, install karo (Settings me "Install unknown apps" allow karna padega).

### Tareeka 2 – Android Studio
**File → Open** → ye folder chuno → Sync hone do → **Build → Build APK(s)**.

## Phone me setup (ek baar)
1. App kholo → password daalo.
2. **Permissions do** dabao (Mic, Call, Contacts → Allow).
3. **Rudra ko default assistant banao** dabao → "Digital assistant app" me **Hey Rudra** chuno.
4. Assistant switch ko **ON** karo (time aur date pill ek baar dikhengi).
5. Design chuno (1, 2 ya 3).

## Use kaise kare
Home / center button ko **dabake rakho** (gesture navigation me neeche ke corner se swipe karo).
Neeche se pill upar aayegi aur phone sunna shuru kar dega. Bolo:
- "open Instagram" / "WhatsApp kholo" / "YouTube" / "Facebook"
- "call Tushar" / "Tushar ko call karo"  (naam contacts jaisa hona chahiye)
- "time" ya "date" (ya "samay", "tarikh")
- koi code, jaise "hash 7524 G F 0" → us code ka MP3 chalega

Switch **OFF** ho to Home button dabane par kuch bhi nahi aata.

## Voice code → MP3
App me **+ Naya code add karo** → code likho (jaise `#7524GF0`) → apna MP3 chuno → Save.
Code kam se kam 4 letters/digits ka rakho. Save karne ke baad ▶ dabake test kar sakte ho.

## Safety
- Password app me plain text me nahi hai, sirf salted PBKDF2-SHA256 hash hai. 5 galat try ke baad lockout lagta hai.
- App background me jate hi dobara lock ho jata hai. Password screen ka screenshot nahi liya ja sakta.
- App ke paas INTERNET permission hi nahi hai. Sirf mic, call aur contacts permission maangta hai.
- Voice pehchan phone ka apna Google speech recogniser karta hai (ye Google ke terms par chalta hai).
- Ye personal use ke liye debug-key se sign hua hai. Play Store par dalne ke liye apni release key chahiye.
