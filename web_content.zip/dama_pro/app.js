const N=10, boardEl=document.getElementById('board');
let b=[],turn='r',selected=null,moves=[],history=[],gameOver=false;
function initial(){b=Array.from({length:N},()=>Array(N).fill(null));for(let r=0;r<4;r++)for(let c=0;c<N;c++)if((r+c)%2===1)b[r][c]={p:'b',k:false};for(let r=6;r<10;r++)for(let c=0;c<N;c++)if((r+c)%2===1)b[r][c]={p:'r',k:false};turn='r';selected=null;moves=[];history=[];gameOver=false;render()}
function clone(){return b.map(row=>row.map(x=>x?{...x}:null))}
function inside(r,c){return r>=0&&r<N&&c>=0&&c<N}
function dirs(piece){return piece.k?[[-1,-1],[-1,1],[1,-1],[1,1]]:piece.p==='r'?[[-1,-1],[-1,1]]:[[1,-1],[1,1]]}
function allMoves(forPlayer,onlyFrom=null){
 let captures=[],normal=[];
 for(let r=0;r<N;r++)for(let c=0;c<N;c++){let p=b[r][c];if(!p||p.p!==forPlayer||(onlyFrom&& (r!==onlyFrom.r||c!==onlyFrom.c)))continue;
  for(const [dr,dc] of dirs(p)){
   if(p.k){let rr=r+dr,cc=c+dc,enemy=null;while(inside(rr,cc)){if(b[rr][cc]){if(b[rr][cc].p===forPlayer||enemy)break;enemy={r:rr,c:cc};}else if(enemy)captures.push({from:{r,c},to:{r:rr,c:cc},cap:enemy});else normal.push({from:{r,c},to:{r:rr,c:cc}});rr+=dr;cc+=dc;} }
   else {let rr=r+dr,cc=c+dc;if(inside(rr,cc)&&!b[rr][cc])normal.push({from:{r,c},to:{r:rr,c:cc}});else if(inside(rr,cc)&&b[rr][cc].p!==forPlayer){let tr=rr+dr,tc=cc+dc;if(inside(tr,tc)&&!b[tr][tc])captures.push({from:{r,c},to:{r:tr,c:tc},cap:{r:rr,c:cc}})}}
  }
 }
 return captures.length?captures:normal;
}
function legalForPiece(r,c){let all=allMoves(turn);return all.filter(m=>m.from.r===r&&m.from.c===c)}
function apply(m){history.push({b:clone(),turn});let p=b[m.from.r][m.from.c];b[m.from.r][m.from.c]=null;b[m.to.r][m.to.c]=p;if(m.cap)b[m.cap.r][m.cap.c]=null;if((p.p==='r'&&m.to.r===0)||(p.p==='b'&&m.to.r===9))p.k=true;
 selected=null;moves=[];if(m.cap){let more=allMoves(turn,m.to).filter(x=>x.cap);if(more.length){selected=m.to;moves=more;render();return}}
 turn=turn==='r'?'b':'r';checkEnd();render()}
function checkEnd(){let red=0,black=0;for(const row of b)for(const p of row)if(p)p.p==='r'?red++:black++;if(!red||!black||!allMoves(turn).length){gameOver=true;document.getElementById('status').textContent=red===0?'فاز الأسود!':black===0?'فاز الأحمر!':turn==='r'?'فاز الأسود!':'فاز الأحمر!'}}
function render(){boardEl.innerHTML='';for(let r=0;r<N;r++)for(let c=0;c<N;c++){let cell=document.createElement('div');cell.className='cell '+((r+c)%2?'dark':'light');if(selected&&selected.r===r&&selected.c===c)cell.classList.add('selected');if(moves.some(m=>m.to.r===r&&m.to.c===c))cell.classList.add('target');let p=b[r][c];if(p){let el=document.createElement('div');el.className='piece '+(p.p==='r'?'red':'black')+(p.k?' king':'');cell.appendChild(el)}cell.onclick=()=>clickCell(r,c);boardEl.appendChild(cell)}
 let rc=0,bc=0;for(const row of b)for(const p of row)if(p)p.p==='r'?rc++:bc++;document.getElementById('redCount').textContent=rc;document.getElementById('blackCount').textContent=bc;if(!gameOver)document.getElementById('status').textContent=selected?'اختار الخانة المضيئة':'دور '+(turn==='r'?'الأحمر':'الأسود')}
function clickCell(r,c){if(gameOver)return;if(selected){let m=moves.find(x=>x.to.r===r&&x.to.c===c);if(m){apply(m);return}}let p=b[r][c];if(p&&p.p===turn){let ms=legalForPiece(r,c);if(ms.length){selected={r,c};moves=ms;render()}}}
document.getElementById('newGame').onclick=initial;document.getElementById('undo').onclick=()=>{let h=history.pop();if(h){b=h.b;turn=h.turn;selected=null;moves=[];gameOver=false;render()}};document.getElementById('online').onclick=()=>document.getElementById('onlineMsg').textContent='سيتم تفعيل اللعب أونلاين بعد إعداد خادم الغرف وربط رمز الاتصال. هذه النسخة تعمل حالياً محلياً.';initial();