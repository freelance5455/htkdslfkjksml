<?php
declare(strict_types=1);
http_response_code(404);
header('Cache-Control: no-store');
header('Content-Type: text/html; charset=utf-8');
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Workspace not found · ANONYMOUX STUDIO</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#08090b;color:#fff;font:16px system-ui,sans-serif}.panel{max-width:520px;margin:24px;padding:32px;border:1px solid #30352c;border-radius:20px;background:#11150f}a{color:#c7ff00}p{color:#bbb}</style></head><body><main class="panel"><small>404 / WORKSPACE REMOVED</small><h1>Shorts Studio is no longer available.</h1><p>Use Video Studio for supported video creation workflows.</p><a href="video/">Open Video Studio</a></main></body></html>