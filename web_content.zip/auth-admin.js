/* JOSTECH — COMPTES, FAVORIS, CERTIFICATS & ESPACE ADMIN (PHASE 4) */
function aEscape(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function aLoadJSON(k, f) {
  try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : f; } catch (e) { return f; }
}
function aSaveJSON(k, o) {
  try { localStorage.setItem(k, JSON.stringify(o)); } catch (e) {}
}
function simpleHash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
  }
  return "h_" + (h >>> 0).toString(16);
}

let draftQuizQuestions = [];

// 1. INITIALISATION COMPTES & CONTENUS DYNAMIQUES ADMIN
function initAuthAndDynamicContent() {
  const users = aLoadJSON("jostech_users", []);
  if (!users.some(u => u.role === "admin")) {
    users.push({
      id: "admin-1",
      name: "Mivumbi Ramazani Jos... (Admin)",
      email: "admin@jostech.edu",
      passHash: simpleHash("jostech2026"),
      role: "admin",
      createdAt: new Date().toISOString()
    });
    aSaveJSON("jostech_users", users);
  }

  // Fusionner les leçons créées par l'administrateur dans DISCIPLINES
  const customLessons = aLoadJSON("jostech_custom_lessons", []);
  if (typeof DISCIPLINES !== "undefined" && customLessons.length) {
    customLessons.forEach(item => {
      const disc = DISCIPLINES.find(d => d.id === Number(item.discId));
      if (!disc) return;
      if (!disc.levels) disc.levels = {};
      const lvl = Number(item.levelNum);
      if (!disc.levels[lvl]) {
        const labels = { 1: "Niveau 1 — Fondamental", 2: "Niveau 2 — Intermédiaire", 3: "Niveau 3 — Avancé & Universitaire" };
        disc.levels[lvl] = { label: labels[lvl] || `Niveau ${lvl}`, subtitle: "Cours publiés via l'espace administrateur.", chapters: [] };
      }
      let chap = disc.levels[lvl].chapters.find(c => c.title.toLowerCase() === item.chapterTitle.toLowerCase());
      if (!chap) {
        chap = { id: "chap-dyn-" + Date.now() + "-" + Math.floor(Math.random() * 999), title: item.chapterTitle, lessons: [] };
        disc.levels[lvl].chapters.push(chap);
      }
      if (!chap.lessons.some(l => l.id === item.lesson.id)) {
        chap.lessons.push(item.lesson);
      }
      if (disc.status === "upcoming") disc.status = "active";
    });
  }

  // Fusionner les quiz créés par l'administrateur dans QUIZZES
  const customQuizzes = aLoadJSON("jostech_custom_quizzes", []);
  if (typeof QUIZZES !== "undefined" && customQuizzes.length) {
    customQuizzes.forEach(q => {
      if (!QUIZZES.some(x => x.id === q.id)) QUIZZES.push(q);
    });
  }

  updateUserUI();
}

function getCurrentSession() { return aLoadJSON("jostech_session", null); }

function updateUserUI() {
  const sess = getCurrentSession();
  const badge = document.getElementById("topbar-user-label");
  const heroGreet = document.getElementById("hero-user-greet");
  if (badge) badge.textContent = sess ? sess.name.split(" ")[0] : "Compte";
  if (heroGreet) heroGreet.textContent = sess ? `, ${sess.name.split(" ")[0]}` : "";
}

// 2. INSCRIPTION, CONNEXION & DÉCONNEXION
function switchAuthTab(mode) {
  document.getElementById("auth-tab-login").classList.toggle("active", mode === "login");
  document.getElementById("auth-tab-register").classList.toggle("active", mode === "register");
  document.getElementById("form-login").style.display = mode === "login" ? "block" : "none";
  document.getElementById("form-register").style.display = mode === "register" ? "block" : "none";
}

function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim().toLowerCase();
  const pass = document.getElementById("login-pass").value;
  const users = aLoadJSON("jostech_users", []);
  const user = users.find(u => u.email.toLowerCase() === email && u.passHash === simpleHash(pass));
  if (!user) {
    if (typeof showToast === "function") showToast("Email ou mot de passe incorrect.");
    return;
  }
  aSaveJSON("jostech_session", { userId: user.id, name: user.name, email: user.email, role: user.role });
  updateUserUI();
  renderProfileScreen();
  if (typeof showToast === "function") showToast(`Bienvenue, ${user.name} !`);
}

function handleRegister(e) {
  e.preventDefault();
  const name = document.getElementById("reg-name").value.trim();
  const email = document.getElementById("reg-email").value.trim().toLowerCase();
  const pass = document.getElementById("reg-pass").value;
  const acceptLegal = document.getElementById("reg-legal").checked;
  if (!name || !email || pass.length < 6) {
    if (typeof showToast === "function") showToast("Nom, email et mot de passe (6+ car.) requis.");
    return;
  }
  if (!acceptLegal) {
    if (typeof showToast === "function") showToast("Veuillez accepter les CGU et la Confidentialité.");
    return;
  }
  const users = aLoadJSON("jostech_users", []);
  if (users.some(u => u.email.toLowerCase() === email)) {
    if (typeof showToast === "function") showToast("Un compte existe déjà avec cet email.");
    return;
  }
  const newUser = {
    id: "u-" + Date.now(),
    name,
    email,
    passHash: simpleHash(pass),
    role: "student",
    createdAt: new Date().toISOString()
  };
  users.push(newUser);
  aSaveJSON("jostech_users", users);
  aSaveJSON("jostech_session", { userId: newUser.id, name: newUser.name, email: newUser.email, role: "student" });
  updateUserUI();
  renderProfileScreen();
  if (typeof showToast === "function") showToast("Compte apprenant créé !");
}

function logoutUser() {
  localStorage.removeItem("jostech_session");
  updateUserUI();
  renderProfileScreen();
  if (typeof showToast === "function") showToast("Déconnexion réussie.");
}

// 3. FAVORIS
function getFavorites() { return aLoadJSON("jostech_favorites", []); }
function isLessonFavorite(lessonId) { return getFavorites().some(f => f.lessonId === lessonId); }

function toggleFavoriteLesson(disc, lvl, lesson) {
  let favs = getFavorites();
  if (favs.some(f => f.lessonId === lesson.id)) {
    favs = favs.filter(f => f.lessonId !== lesson.id);
    if (typeof showToast === "function") showToast("Retiré des favoris");
  } else {
    favs.unshift({ discId: disc.id, levelNum: lvl, lessonId: lesson.id, title: lesson.title, discTitle: disc.title });
    if (typeof showToast === "function") showToast("Ajouté aux favoris ★");
  }
  aSaveJSON("jostech_favorites", favs);
}

// 4. PROFIL & CERTIFICATS DE RÉUSSITE
function renderProfileScreen() {
  const sess = getCurrentSession();
  const authWrap = document.getElementById("auth-forms-wrap");
  const loggedWrap = document.getElementById("profile-logged-wrap");
  if (!authWrap || !loggedWrap) return;

  if (!sess) {
    authWrap.style.display = "block";
    loggedWrap.style.display = "none";
    return;
  }

  authWrap.style.display = "none";
  loggedWrap.style.display = "block";
  document.getElementById("prof-name").textContent = sess.name;
  document.getElementById("prof-email").textContent = sess.email;
  const roleBadge = document.getElementById("prof-role-badge");
  roleBadge.textContent = sess.role === "admin" ? "Administrateur" : "Apprenant Universitaire";
  roleBadge.className = sess.role === "admin" ? "pill-badge pilot" : "pill-badge";

  const adminBtn = document.getElementById("btn-open-admin");
  if (adminBtn) adminBtn.style.display = sess.role === "admin" ? "block" : "none";

  // Favoris
  const favBox = document.getElementById("profile-favorites-list");
  const favs = getFavorites();
  if (!favs.length) {
    favBox.innerHTML = `<div class="info-banner">Aucune leçon en favori. Appuyez sur ☆ dans un cours pour le garder ici.</div>`;
  } else {
    favBox.innerHTML = "";
    favs.forEach(f => {
      const row = document.createElement("div");
      row.className = "recent-item";
      row.onclick = () => openLesson(f.discId, f.levelNum, f.lessonId);
      row.innerHTML = `<div><strong>★ ${aEscape(f.title)}</strong><span>${aEscape(f.discTitle)} • Niveau ${f.levelNum}</span></div><span>Ouvrir →</span>`;
      favBox.appendChild(row);
    });
  }

  // Certificats par discipline pilote
  const certBox = document.getElementById("profile-certificates-list");
  certBox.innerHTML = "";
  const completed = typeof getCompletedLessons === "function" ? getCompletedLessons() : [];
  const hist = typeof getQuizHistory === "function" ? getQuizHistory() : [];

  if (typeof DISCIPLINES !== "undefined" && typeof QUIZZES !== "undefined") {
    DISCIPLINES.filter(d => d.status === "pilot").forEach(d => {
      const discLessons = [];
      [1, 2, 3].forEach(l => { if (d.levels && d.levels[l]) d.levels[l].chapters.forEach(c => c.lessons.forEach(ls => discLessons.push(ls.id))); });
      const doneCount = discLessons.filter(id => completed.includes(id)).length;
      const exam = QUIZZES.find(q => q.discId === d.id && q.mode === "exam");
      const bestExam = exam ? hist.filter(h => h.quizId === exam.id).sort((a, b) => b.score20 - a.score20)[0] : null;
      const unlocked = discLessons.length > 0 && doneCount === discLessons.length && bestExam && bestExam.score20 >= 10;

      const card = document.createElement("div");
      card.className = unlocked ? "cert-card unlocked" : "cert-card";
      card.innerHTML = unlocked
        ? `<div class="hero-tag">Certificat Officiel JOSTECH</div><h4 class="metallic-text">${aEscape(d.title)}</h4><p>Délivré à <strong>${aEscape(sess.name)}</strong> • Examen : <strong>${bestExam.score20}/20</strong></p>`
        : `<h4>${aEscape(d.title)}</h4><p>Conditions : ${doneCount}/${discLessons.length} leçons lues • Examen officiel : ${bestExam ? bestExam.score20 + "/20" : "non passé (≥ 10/20 requis)"}</p>`;
      certBox.appendChild(card);
    });
  }
}

// 5. ESPACE ADMINISTRATEUR DYNAMIQUE
function switchAdminTab(tabName) {
  document.querySelectorAll("#admin-tabs button").forEach(b => b.classList.toggle("active", b.dataset.adminTab === tabName));
  document.querySelectorAll(".admin-panel").forEach(p => { p.style.display = p.id === "admin-panel-" + tabName ? "block" : "none"; });
}

function renderAdminScreen() {
  const sess = getCurrentSession();
  if (!sess || sess.role !== "admin") {
    if (typeof showToast === "function") showToast("Accès réservé à l'administrateur.");
    if (typeof navigateTo === "function") navigateTo("profile");
    return;
  }

  const users = aLoadJSON("jostech_users", []);
  const reports = aLoadJSON("jostech_reports", []);
  const totalLessons = typeof getAllLessonsFlat === "function" ? getAllLessonsFlat().length : 0;
  const totalQuizzes = typeof QUIZZES !== "undefined" ? QUIZZES.length : 0;

  document.getElementById("adm-stat-users").textContent = users.length;
  document.getElementById("adm-stat-lessons").textContent = totalLessons;
  document.getElementById("adm-stat-quizzes").textContent = totalQuizzes;
  document.getElementById("adm-stat-reports").textContent = reports.length;

  // Remplir les listes déroulantes de disciplines
  if (typeof DISCIPLINES !== "undefined") {
    const opts = DISCIPLINES.map(d => `<option value="${d.id}">${d.num}. ${aEscape(d.title)}</option>`).join("");
    document.getElementById("adm-lesson-disc").innerHTML = opts;
    document.getElementById("adm-quiz-disc").innerHTML = opts;
  }

  renderDraftQuestions();
  renderAdminReportsAndUsers();
}

function handleAdminCreateLesson(e) {
  e.preventDefault();
  const discId = Number(document.getElementById("adm-lesson-disc").value);
  const levelNum = Number(document.getElementById("adm-lesson-lvl").value);
  const chapterTitle = document.getElementById("adm-lesson-chap").value.trim() || "Chapitre publié par l'Admin";
  const title = document.getElementById("adm-lesson-title").value.trim();
  const duration = document.getElementById("adm-lesson-dur").value.trim() || "25 min";
  const objText = document.getElementById("adm-lesson-obj").value.trim();
  const theoryText = document.getElementById("adm-lesson-theory").value.trim();
  const codeText = document.getElementById("adm-lesson-code").value;
  const exQ = document.getElementById("adm-lesson-exq").value.trim();
  const exS = document.getElementById("adm-lesson-exs").value.trim();

  if (!title || !theoryText) {
    if (typeof showToast === "function") showToast("Titre et contenu théorique requis.");
    return;
  }

  const sections = [{ type: "theory", title: "Exposé du cours", text: theoryText }];
  if (codeText.trim()) sections.push({ type: "code", lang: "Code / Schéma", code: codeText });

  const newLesson = {
    id: "dyn-" + Date.now(),
    title,
    duration,
    objectives: objText ? objText.split("\n").filter(Boolean) : ["Maîtriser les notions présentées dans cette leçon."],
    prerequisites: ["Suivre la progression du niveau précédent."],
    sections,
    exercises: exQ ? [{ title: "Exercice d'application", question: exQ, solution: exS || "Corrigé à compléter." }] : [],
    summary: "Leçon publiée dynamiquement depuis l'Espace Administrateur JOSTECH.",
    references: ["JOSTECH — Ressource pédagogique interne."]
  };

  const saved = aLoadJSON("jostech_custom_lessons", []);
  saved.push({ discId, levelNum, chapterTitle, lesson: newLesson });
  aSaveJSON("jostech_custom_lessons", saved);

  initAuthAndDynamicContent();
  if (typeof renderDisciplines === "function") renderDisciplines();
  if (typeof renderHomePilots === "function") renderHomePilots();
  if (typeof updateDashboardStats === "function") updateDashboardStats();

  e.target.reset();
  renderAdminScreen();
  if (typeof showToast === "function") showToast("Leçon publiée avec succès !");
}

function addDraftQuestion() {
  const qText = document.getElementById("adm-q-text").value.trim();
  const optsRaw = document.getElementById("adm-q-opts").value.trim();
  const rightIdx = Number(document.getElementById("adm-q-right").value) - 1;
  const expl = document.getElementById("adm-q-expl").value.trim() || "Voir le cours correspondant.";
  const options = optsRaw.split("\n").map(x => x.trim()).filter(Boolean);

  if (!qText || options.length < 2 || rightIdx < 0 || rightIdx >= options.length) {
    if (typeof showToast === "function") showToast("Question, 2+ options et n° de bonne réponse valides requis.");
    return;
  }
  draftQuizQuestions.push({ type: "single", q: qText, options, answer: rightIdx, explanation: expl });
  document.getElementById("adm-q-text").value = "";
  document.getElementById("adm-q-opts").value = "";
  document.getElementById("adm-q-expl").value = "";
  renderDraftQuestions();
  if (typeof showToast === "function") showToast("Question ajoutée au brouillon !");
}

function renderDraftQuestions() {
  const box = document.getElementById("adm-draft-questions");
  if (!box) return;
  box.innerHTML = draftQuizQuestions.length
    ? `<p class="section-sub">${draftQuizQuestions.length} question(s) prête(s) à publier.</p>`
    : `<p class="section-sub">Aucune question ajoutée pour le moment.</p>`;
}

function publishAdminQuiz() {
  const discId = Number(document.getElementById("adm-quiz-disc").value);
  const mode = document.getElementById("adm-quiz-mode").value;
  const title = document.getElementById("adm-quiz-title").value.trim();
  const dur = Number(document.getElementById("adm-quiz-dur").value) || 10;
  if (!title || !draftQuizQuestions.length) {
    if (typeof showToast === "function") showToast("Titre et au moins 1 question requis.");
    return;
  }
  const disc = typeof DISCIPLINES !== "undefined" ? DISCIPLINES.find(d => d.id === discId) : null;
  const newQuiz = {
    id: "qdyn-" + Date.now(),
    discId,
    mode,
    title,
    subtitle: (disc ? `${disc.num}. ${disc.title}` : "JOSTECH") + " • Publié par Admin",
    durationMin: dur,
    questions: draftQuizQuestions.slice()
  };
  const saved = aLoadJSON("jostech_custom_quizzes", []);
  saved.push(newQuiz);
  aSaveJSON("jostech_custom_quizzes", saved);
  draftQuizQuestions = [];
  document.getElementById("adm-quiz-title").value = "";
  initAuthAndDynamicContent();
  renderAdminScreen();
  if (typeof showToast === "function") showToast("Évaluation publiée dans Examens !");
}

function renderAdminReportsAndUsers() {
  const repBox = document.getElementById("adm-reports-list");
  const reports = aLoadJSON("jostech_reports", []);
  if (!reports.length) {
    repBox.innerHTML = `<div class="info-banner">Aucun signalement d'erreur en attente.</div>`;
  } else {
    repBox.innerHTML = "";
    reports.forEach((r, idx) => {
      const card = document.createElement("div");
      card.className = "lesson-box";
      card.innerHTML = `<h4>${aEscape(r.lessonId || "Leçon")}</h4><p>${aEscape(r.message)}</p>`;
      const del = document.createElement("button");
      del.className = "btn-secondary";
      del.style.marginTop = "8px";
      del.textContent = "Marquer résolu";
      del.onclick = () => {
        const next = aLoadJSON("jostech_reports", []).filter((_, i) => i !== idx);
        aSaveJSON("jostech_reports", next);
        renderAdminScreen();
      };
      card.appendChild(del);
      repBox.appendChild(card);
    });
  }

  const usersBox = document.getElementById("adm-users-list");
  const users = aLoadJSON("jostech_users", []);
  usersBox.innerHTML = users.map(u => `
    <div class="recent-item">
      <div><strong>${aEscape(u.name)}</strong><span>${aEscape(u.email)}</span></div>
      <span class="pill-badge ${u.role === "admin" ? "pilot" : ""}">${u.role}</span>
    </div>
  `).join("");
}

function exportAdminBackup() {
  const backup = {
    date: new Date().toISOString(),
    customLessons: aLoadJSON("jostech_custom_lessons", []),
    customQuizzes: aLoadJSON("jostech_custom_quizzes", []),
    reports: aLoadJSON("jostech_reports", [])
  };
  const json = JSON.stringify(backup, null, 2);
  if (typeof copyTextSafe === "function") copyTextSafe(json);
  if (typeof showToast === "function") showToast("Sauvegarde JSON copiée dans le presse-papiers !");
}

// 6. PAGES LÉGALES (CGU & CONFIDENTIALITÉ)
function openLegalModal(type) {
  const modal = document.getElementById("legal-modal");
  const title = document.getElementById("legal-title");
  const body = document.getElementById("legal-body");
  if (!modal) return;
  if (type === "cgu") {
    title.textContent = "Conditions Générales d'Utilisation (CGU)";
    body.innerHTML = "<p><strong>1. Objet :</strong> JOSTECH est une plateforme éducative dédiée aux sciences informatiques (« Apprendre, comprendre, innover »).</p><p style='margin-top:8px;'><strong>2. Propriété intellectuelle :</strong> Les contenus pédagogiques, logos et codes sources de JOSTECH sont protégés. Leur reproduction commerciale sans autorisation du promoteur (Mivumbi Ramazani Jos...) est interdite.</p><p style='margin-top:8px;'><strong>3. Règles d'usage :</strong> Les exercices de cybersécurité doivent être pratiqués exclusivement dans un cadre légal, éthique et autorisé.</p>";
  } else {
    title.textContent = "Politique de Confidentialité";
    body.innerHTML = "<p><strong>1. Données collectées :</strong> Nom, adresse e-mail, progression des cours, favoris et résultats aux évaluations (/20).</p><p style='margin-top:8px;'><strong>2. Stockage :</strong> Dans cette version locale, vos données sont conservées uniquement sur votre appareil (localStorage). Aucune donnée n'est vendue ou partagée à des tiers.</p><p style='margin-top:8px;'><strong>3. Droits :</strong> Vous pouvez réinitialiser ou supprimer vos données à tout moment depuis les Paramètres.</p>";
  }
  modal.classList.add("open");
}
function closeLegalModal() {
  const modal = document.getElementById("legal-modal");
  if (modal) modal.classList.remove("open");
}