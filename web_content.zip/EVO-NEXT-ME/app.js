const translations = {
  fa: {
    eyebrow: "نسخه جدید تو از همین‌جا شروع می‌شود",
    heroTitle: "بهترین نسخه خودت باش.",
    heroText: "هر روز یک قدم جلوتر؛ بدون توقف، بدون بهانه.",
    completedDays: "روزهای موفق",
    remainingDays: "روزهای باقی‌مانده",
    progress: "پیشرفت",
    daysUnit: "روز",
    challengeTitle: "چالش ۹۰ روزه",
    initialLabel: "چند روز را قبلاً با موفقیت گذرانده‌ای؟",
    save: "ذخیره",
    tasksTitle: "برنامه امروز",
    taskPlaceholder: "نام کار جدید...",
    add: "افزودن",
    todayProgress: "درصد انجام کارهای امروز",
    successHint: "برای ثبت یک روز موفق، باید حداقل ۸۰٪ کارها را انجام بدهی.",
    finishDay: "🏁 پایان برنامه امروز",
    dayAlreadyCounted: "امروز قبلاً ثبت شده است؛ آفرین!",
    dayNeedsTasks: "اول برای امروز چند کار اضافه کن.",
    dayNotReady: "برای ثبت روز موفق، حداقل ۸۰٪ کارها را انجام بده.",
    daySuccess: "🎉 آفرین! امروز با موفقیت ثبت شد.",
    habitsTitle: "عادت‌های روزانه",
    habitPlaceholder: "عادت جدید...",
    footer: "هر روز بهتر از دیروز.",
    quickSettings: "تنظیمات سریع"
  },
  en: {
    eyebrow: "Your new version starts here",
    heroTitle: "Become your best self.",
    heroText: "One step forward every day. No excuses.",
    completedDays: "Successful days",
    remainingDays: "Days remaining",
    progress: "Progress",
    daysUnit: "Days",
    challengeTitle: "90 Day Challenge",
    initialLabel: "How many days have you already completed?",
    save: "Save",
    tasksTitle: "Today's Tasks",
    taskPlaceholder: "New task name...",
    add: "Add",
    todayProgress: "Today's completion",
    successHint: "Complete at least 80% of your tasks to pass the day.",
    finishDay: "🏁 Finish today's plan",
    dayAlreadyCounted: "Today has already been recorded. Great job!",
    dayNeedsTasks: "Add some tasks for today first.",
    dayNotReady: "Complete at least 80% of today's tasks to pass the day.",
    daySuccess: "🎉 Great job! Today has been recorded successfully.",
    habitsTitle: "Daily Habits",
    habitPlaceholder: "New habit...",
    footer: "Better than yesterday.",
    quickSettings: "Quick Controls"
  }
};

const STORAGE_KEY = "evo-next-me-prime-v3";

const defaultData = {
  language: "fa",
  theme: "dark",
  bluetoothEnabled: false,
  initialDays: 0,
  habits: [
    { id: 1, name: "مطالعه", done: false },
    { id: 2, name: "ورزش", done: false },
    { id: 3, name: "یادگیری مهارت", done: false }
  ],
  tasksByDate: {},
  successfulDates: [],
  lastActiveDate: ""
};

let data;

try {
  data = {
    ...defaultData,
    ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}")
  };
} catch {
  data = { ...defaultData };
}

const $ = id => document.getElementById(id);

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function todayKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}

function getTodayTasks() {
  const key = todayKey();

  if (!data.tasksByDate[key]) {
    data.tasksByDate[key] = [];
  }

  return data.tasksByDate[key];
}

function translatePage() {
  const lang = data.language;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "fa" ? "rtl" : "ltr";
  document.body.dir = lang === "fa" ? "rtl" : "ltr";

  document.querySelectorAll("[data-i18n]").forEach(element => {
    const key = element.dataset.i18n;
    if (translations[lang][key]) {
      element.textContent = translations[lang][key];
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach(element => {
    const key = element.dataset.i18nPlaceholder;
    element.placeholder = translations[lang][key] || "";
  });

  $("languageButton").textContent = lang === "fa" ? "EN" : "FA";
  renderTasks();
  renderHabits();
  const finishedToday = data.successfulDates.includes(todayKey());
  $("finishDayButton").disabled = finishedToday;
  $("finishDayButton").textContent = finishedToday
    ? translations[lang].dayAlreadyCounted
    : translations[lang].finishDay;
  if (finishedToday) $("finishDayMessage").textContent = translations[lang].dayAlreadyCounted;
}

function renderTasks() {
  const list = $("taskList");
  const tasks = getTodayTasks();
  list.innerHTML = "";

  if (!tasks.length) {
    list.innerHTML = `<p class="hint">${data.language === "fa" ? "هنوز کاری اضافه نکرده‌ای." : "No tasks added yet."}</p>`;
  }

  tasks.forEach(task => {
    const item = document.createElement("div");
    item.className = "task-item";

    const main = document.createElement("div");
    main.className = "task-main";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = task.done;
    checkbox.addEventListener("change", () => {
      task.done = checkbox.checked;
      saveData();
      renderTasks();
      updateStats();
    });

    const name = document.createElement("span");
    name.className = "task-name" + (task.done ? " done" : "");
    name.textContent = task.name;

    const time = document.createElement("span");
    time.className = "task-time";
    time.textContent = task.time || "";

    main.append(checkbox, name);

    const remove = document.createElement("button");
    remove.className = "delete-button";
    remove.textContent = data.language === "fa" ? "حذف" : "Delete";
    remove.addEventListener("click", () => {
      data.tasksByDate[todayKey()] = tasks.filter(t => t.id !== task.id);
      saveData();
      renderTasks();
      updateStats();
    });

    item.append(main, time, remove);
    list.append(item);
  });

  const done = tasks.filter(task => task.done).length;
  const percent = tasks.length ? Math.round(done / tasks.length * 100) : 0;
  $("todayPercent").textContent = percent + "%";
}

function renderHabits() {
  const list = $("habitList");
  list.innerHTML = "";

  data.habits.forEach(habit => {
    const item = document.createElement("div");
    item.className = "habit-item";

    const main = document.createElement("div");
    main.className = "habit-main";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = habit.done;

    checkbox.addEventListener("change", () => {
      habit.done = checkbox.checked;
      saveData();
      renderHabits();
    });

    const name = document.createElement("span");
    name.className = "habit-name" + (habit.done ? " done" : "");
    name.textContent = habit.name;

    main.append(checkbox, name);

    const remove = document.createElement("button");
    remove.className = "delete-button";
    remove.textContent = data.language === "fa" ? "حذف" : "Delete";
    remove.addEventListener("click", () => {
      data.habits = data.habits.filter(h => h.id !== habit.id);
      saveData();
      renderHabits();
    });

    item.append(main, remove);
    list.append(item);
  });
}

function updateStats() {
  const completed = Math.min(90, data.initialDays + data.successfulDates.length);
  const remaining = Math.max(0, 90 - completed);
  const percent = Math.round(completed / 90 * 100);

  $("completedCount").textContent = completed;
  $("remainingCount").textContent = remaining;
  $("progressPercent").textContent = percent + "%";
  $("progressBar").style.width = percent + "%";
}

function addTask() {
  const name = $("taskInput").value.trim();
  const time = $("taskTime").value;

  if (!name) return;

  getTodayTasks().push({
    id: Date.now(),
    name,
    time,
    done: false
  });

  $("taskInput").value = "";
  saveData();
  renderTasks();
  updateStats();
}

function addHabit() {
  const name = $("habitInput").value.trim();
  if (!name) return;

  data.habits.push({
    id: Date.now(),
    name,
    done: false
  });

  $("habitInput").value = "";
  saveData();
  renderHabits();
}

function saveInitialDays() {
  const value = Number($("initialDays").value);

  if (!Number.isInteger(value) || value < 0 || value > 90) {
    alert(data.language === "fa" ? "عدد باید بین ۰ تا ۹۰ باشد." : "Enter a number from 0 to 90.");
    return;
  }

  data.initialDays = value;
  saveData();
  updateStats();
}

function applyTheme() {
  document.body.classList.toggle("light", data.theme === "light");
  const button = $("themeToggleButton");
  button.textContent = data.theme === "dark" ? "☼" : "☾";
  button.setAttribute("aria-label", data.language === "fa"
    ? (data.theme === "dark" ? "رفتن به حالت روشن" : "رفتن به حالت تاریک")
    : (data.theme === "dark" ? "Switch to light mode" : "Switch to dark mode"));
  document.querySelector('meta[name="theme-color"]').content = data.theme === "dark" ? "#080d18" : "#eaf0f8";
}


function checkNewDay() {
  const today = todayKey();

  if (data.lastActiveDate && data.lastActiveDate !== today) {
    const previousTasks = data.tasksByDate[data.lastActiveDate] || [];

    if (previousTasks.length) {
      const done = previousTasks.filter(task => task.done).length;
      const percent = done / previousTasks.length;

      if (percent >= 0.8 && !data.successfulDates.includes(data.lastActiveDate)) {
        data.successfulDates.push(data.lastActiveDate);
      }
    }
  }

  data.lastActiveDate = today;
  saveData();
}


function finishDay() {
  const today = todayKey();
  const tasks = getTodayTasks();
  const message = $("finishDayMessage");

  if (data.successfulDates.includes(today)) {
    message.textContent = translations[data.language].dayAlreadyCounted;
    return;
  }
  if (!tasks.length) {
    message.textContent = translations[data.language].dayNeedsTasks;
    return;
  }
  const done = tasks.filter(task => task.done).length;
  const percent = Math.round(done / tasks.length * 100);
  if (percent < 80) {
    message.textContent = translations[data.language].dayNotReady;
    return;
  }

  data.successfulDates.push(today);
  data.lastActiveDate = today;
  saveData();
  updateStats();
  message.textContent = translations[data.language].daySuccess;
  $("finishDayButton").disabled = true;
  $("finishDayButton").textContent = translations[data.language].dayAlreadyCounted;
}

function setup() {
  $("todayDate").textContent = todayKey();
  $("initialDays").value = data.initialDays;

  $("addTaskButton").addEventListener("click", addTask);
  $("addHabitButton").addEventListener("click", addHabit);
  $("saveInitialDays").addEventListener("click", saveInitialDays);
  $("finishDayButton").addEventListener("click", finishDay);

  $("taskInput").addEventListener("keydown", event => {
    if (event.key === "Enter") addTask();
  });

  $("habitInput").addEventListener("keydown", event => {
    if (event.key === "Enter") addHabit();
  });

  $("themeToggleButton").addEventListener("click", () => {
    data.theme = data.theme === "dark" ? "light" : "dark";
    saveData();
    applyTheme();
  });


  $("languageButton").addEventListener("click", () => {
    data.language = data.language === "fa" ? "en" : "fa";
    saveData();
    translatePage();
  });

  checkNewDay();
  applyTheme();
  translatePage();
  updateStats();
}

setup();