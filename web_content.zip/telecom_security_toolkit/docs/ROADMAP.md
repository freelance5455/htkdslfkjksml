# Suggested next development steps

1. Add a permission screen explaining why location is needed for cell identity APIs.
2. Add a native Bluetooth printer module for the exact printer model/protocol (SPP, BLE, or vendor SDK). Use Android's current Bluetooth runtime permissions and ask before connecting or printing.
3. Add optional public cell-database lookup using MCC/MNC + TAC + Cell ID, with clear uncertainty and privacy consent. Never label a tower's operator backhaul address as a public tower IP.
4. Add export of Nmap results and a clear authorization confirmation before each scan.
5. Add tests on the actual Android phone and printer.

Android `TelephonyManager.getAllCellInfo()` requires fine location permission and may return cached/incomplete information. See Android documentation.
