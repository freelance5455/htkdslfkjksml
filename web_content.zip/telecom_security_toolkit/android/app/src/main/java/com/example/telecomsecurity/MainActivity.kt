package com.example.telecomsecurity

import android.Manifest
import android.app.Activity
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.*
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val permissionRequest = 71

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")   // bundled UI: works fully offline
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE)
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            perms += Manifest.permission.BLUETOOTH_SCAN; perms += Manifest.permission.BLUETOOTH_CONNECT
        }
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), permissionRequest)
    }

    override fun onDestroy() { stopBle(); super.onDestroy() }

    // ---- passive BLE scanning (advertisements only; never connects to anything)
    private val bleSeen = ConcurrentHashMap<String, JSONObject>()
    private var bleCallback: ScanCallback? = null

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startBle(): String? {
        if (bleCallback != null) return null
        val needed = if (android.os.Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_SCAN
                     else Manifest.permission.ACCESS_FINE_LOCATION
        if (!has(needed)) return "Permission not granted. Allow Nearby devices / Location, then tap again."
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
            ?: return "This device has no Bluetooth."
        if (!adapter.isEnabled) return "Bluetooth is off. Turn it on."
        val scanner = adapter.bluetoothLeScanner ?: return "BLE scanner unavailable."
        val cb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                val addr = r.device.address
                bleSeen[addr] = JSONObject().put("id", addr)
                    .put("name", r.scanRecord?.deviceName ?: addr)
                    .put("rssi", r.rssi).put("t", System.currentTimeMillis())
            }
        }
        scanner.startScan(cb); bleCallback = cb
        return null
    }

    @SuppressLint("MissingPermission")
    private fun stopBle() {
        try {
            val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
            bleCallback?.let { adapter?.bluetoothLeScanner?.stopScan(it) }
        } catch (_: Exception) {}
        bleCallback = null
    }

    inner class AndroidBridge {
        @JavascriptInterface fun getCellInfo(): String {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return "Location permission not granted."
            return try {
                val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                val cells = tm.allCellInfo ?: return "Cell information unavailable on this device."
                cells.joinToString("\\n") { cell ->
                    val id = when (cell) {
                        is CellInfoLte -> "LTE CI=${cell.cellIdentity.ci}, TAC=${cell.cellIdentity.tac}, PCI=${cell.cellIdentity.pci}"
                        is CellInfoNr -> {
                            val ident = cell.cellIdentity as CellIdentityNr
                            "NR NCI=${ident.nci}, TAC=${ident.tac}, PCI=${ident.pci}"
                        }
                        is CellInfoWcdma -> "WCDMA CID=${cell.cellIdentity.cid}, LAC=${cell.cellIdentity.lac}"
                        is CellInfoGsm -> "GSM CID=${cell.cellIdentity.cid}, LAC=${cell.cellIdentity.lac}"
                        else -> cell.javaClass.simpleName
                    }
                    "${if (cell.isRegistered) "SERVING" else "NEIGHBOR"}: $id, registered=${cell.isRegistered}"
                }.ifBlank { "No cell records returned." }
            } catch (e: Exception) { "Could not read cell data: ${e.message}" }
        }

        @JavascriptInterface fun bluetoothScan(): String {
            startBle()?.let { return JSONObject().put("error", it).toString() }
            val now = System.currentTimeMillis()
            val arr = JSONArray()
            bleSeen.values.filter { now - it.getLong("t") < 30000 }.forEach { arr.put(it) }
            return JSONObject().put("devices", arr).toString()
        }

        @SuppressLint("MissingPermission")
        @Suppress("DEPRECATION")
        @JavascriptInterface fun wifiScan(): String {
            if (!has(Manifest.permission.ACCESS_FINE_LOCATION))
                return JSONObject().put("error", "Location permission not granted.").toString()
            return try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                if (!wm.isWifiEnabled) return JSONObject().put("error", "Wi-Fi is off. Turn it on.").toString()
                try { wm.startScan() } catch (_: Exception) {}   // Android throttles this; cached results are fine
                val arr = JSONArray()
                for (r in wm.scanResults) {
                    arr.put(JSONObject().put("id", r.BSSID ?: "?")
                        .put("label", if (r.SSID.isNullOrEmpty()) "(hidden)" else r.SSID)
                        .put("rssi", r.level).put("freq", r.frequency))
                }
                JSONObject().put("devices", arr).toString()
            } catch (e: Exception) {
                JSONObject().put("error", "Wi-Fi scan failed: ${e.message}. Is Location turned on?").toString()
            }
        }

        @JavascriptInterface fun bluetoothStatus(): String {
            return try {
                val adapter = BluetoothAdapter.getDefaultAdapter()
                    ?: return "This device has no Bluetooth adapter."
                if (android.os.Build.VERSION.SDK_INT >= 31 &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) return "Bluetooth Connect permission is required."
                "Bluetooth supported; enabled=${adapter.isEnabled}. Printer discovery/printing needs a printer-specific implementation."
            } catch (e: Exception) { "Bluetooth status unavailable: ${e.message}" }
        }
    }
}