// Offline radar: pure canvas, no external libraries.
(() => {
  const cv = document.getElementById("radar"), ctx = cv.getContext("2d");
  const msg = document.getElementById("radarMsg"), list = document.getElementById("radarList");
  const RED = "255,42,42", STALE_MS = 30000, SWEEP_MS = 4000;
  const blips = new Map();           // id -> blip
  let size = 300, selected = null, wifiTimer = null, demoTimer = null, btStop = null;

  // Stable pseudo-angle from the ID. Phones can't measure direction, so angle is
  // arbitrary-but-consistent; only distance (signal strength) is meaningful.
  function angleOf(id) {
    let h = 2166136261;
    for (const c of id) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
    return ((h >>> 0) / 4294967296) * Math.PI * 2;
  }
  const radiusOf = rssi => 0.08 + 0.9 * (1 - Math.min(1, Math.max(0, (rssi + 95) / 65))); // -30dBm centre, -95 edge

  function upsert(d) {
    if (typeof d.rssi !== "number") return;
    const b = blips.get(d.id) || { id: d.id, angle: angleOf(d.id), pulse: 0, lastSweep: 0 };
    Object.assign(b, { label: d.label || d.id, type: d.type, rssi: d.rssi, seen: Date.now() });
    b.r = radiusOf(d.rssi);
    blips.set(d.id, b);
  }

  function resize() {
    const dpr = window.devicePixelRatio || 1;
    size = cv.clientWidth || 300;
    cv.width = cv.height = Math.round(size * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener("resize", resize); resize();

  function draw(t) {
    const c = size / 2, R = c - 6, now = Date.now();
    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = "#050000"; ctx.fillRect(0, 0, size, size);
    ctx.lineWidth = 1; ctx.strokeStyle = `rgba(${RED},.55)`;
    for (let i = 1; i <= 4; i++) { ctx.beginPath(); ctx.arc(c, c, R * i / 4, 0, 7); ctx.stroke(); }
    ctx.beginPath(); ctx.moveTo(c - R, c); ctx.lineTo(c + R, c); ctx.moveTo(c, c - R); ctx.lineTo(c, c + R); ctx.stroke();

    const sweep = ((t % SWEEP_MS) / SWEEP_MS) * Math.PI * 2;
    for (let i = 0; i < 40; i++) {            // fading red trail behind the sweep line
      const a0 = sweep - i * 0.025, a1 = a0 - 0.025;
      ctx.beginPath(); ctx.moveTo(c, c); ctx.arc(c, c, R, a1, a0); ctx.closePath();
      ctx.fillStyle = `rgba(${RED},${0.28 * (1 - i / 40)})`; ctx.fill();
    }
    ctx.strokeStyle = `rgb(${RED})`; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(c, c); ctx.lineTo(c + R * Math.cos(sweep), c + R * Math.sin(sweep)); ctx.stroke();

    for (const [id, b] of blips) {
      if (now - b.seen > STALE_MS) { blips.delete(id); continue; }
      let diff = (sweep - b.angle) % (Math.PI * 2); if (diff < 0) diff += Math.PI * 2;
      if (diff < 0.12 && now - b.lastSweep > SWEEP_MS / 2) { b.pulse = 1; b.lastSweep = now; }
      b.pulse = Math.max(0, b.pulse - 0.012);
      const x = c + R * b.r * Math.cos(b.angle), y = c + R * b.r * Math.sin(b.angle);
      const alpha = 0.8 + 0.2 * b.pulse;
      if (b.pulse > 0) { ctx.beginPath(); ctx.arc(x, y, 5 + 12 * (1 - b.pulse), 0, 7);
        ctx.strokeStyle = `rgba(${RED},${b.pulse})`; ctx.lineWidth = 1.5; ctx.stroke(); }
      ctx.fillStyle = `rgba(255,255,255,${alpha})`;
      ctx.beginPath(); ctx.arc(x, y, 4, 0, 7); ctx.fill();
      if (b.type === "bt") { ctx.strokeStyle = `rgba(255,255,255,${alpha})`; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(x, y, 7, 0, 7); ctx.stroke(); }
      b.x = x; b.y = y;
      if (selected === id) { ctx.fillStyle = "#fff"; ctx.font = "12px system-ui";
        ctx.textAlign = x > c ? "right" : "left";
        ctx.fillText(`${b.label} ${b.rssi}dBm`, x + (x > c ? -10 : 10), y - 10); }
    }
    requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);

  cv.addEventListener("click", e => {
    const r = cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    let best = null, bd = 24;
    for (const b of blips.values()) { const d = Math.hypot(b.x - x, b.y - y); if (d < bd) { bd = d; best = b.id; } }
    selected = best;
  });

  setInterval(() => {
    const rows = [...blips.values()].sort((a, b) => b.rssi - a.rssi)
      .map(b => `${b.type === "bt" ? "◉ BT  " : "● WiFi"}  ${String(b.rssi).padStart(4)} dBm  ${b.label}`);
    list.textContent = rows.join("\n") || "No devices yet";
  }, 1000);

  async function pollWifi() {
    try {
      if (window.AndroidBridge?.wifiScan) {               // native APK path (fully offline)
        const d = JSON.parse(window.AndroidBridge.wifiScan());
        if (d.error) throw new Error(d.error);
        d.devices.forEach(x => upsert({ ...x, type: "wifi" })); msg.textContent = `Wi-Fi: ${d.devices.length} access points nearby.`;
        return;
      }
      const r = await fetch("/api/radar/wifi"), d = await r.json();
      if (!r.ok) throw new Error(d.detail || `HTTP ${r.status}`);
      d.devices.forEach(upsert); msg.textContent = `Wi-Fi: ${d.count} access points nearby.`;
    } catch (e) { msg.textContent = "Wi-Fi: " + e.message; }
  }
  document.getElementById("radarWifi").onclick = function () {
    if (wifiTimer) { clearInterval(wifiTimer); wifiTimer = null; this.textContent = "Start Wi-Fi radar"; msg.textContent = "Wi-Fi radar stopped."; return; }
    this.textContent = "Stop Wi-Fi radar"; pollWifi(); wifiTimer = setInterval(pollWifi, 10000); // Android throttles Wi-Fi scans
  };

  const btBtn = document.getElementById("radarBt");
  btBtn.onclick = async () => {
    if (btStop) { btStop(); btStop = null; btBtn.textContent = "Scan Bluetooth"; return; }
    const add = (id, name, rssi) => upsert({ id, label: name || id, rssi, type: "bt" });
    try {
      if (window.AndroidBridge?.bluetoothScan) {            // APK bridge, if present
        const poll = () => { try { const d = JSON.parse(window.AndroidBridge.bluetoothScan());
          if (d.error) msg.textContent = "Bluetooth: " + d.error; else d.devices.forEach(x => add(x.id, x.name, x.rssi)); } catch {} };
        poll(); const t = setInterval(poll, 3000); btStop = () => clearInterval(t);
      } else if (navigator.bluetooth?.requestLEScan) {      // Chrome (needs experimental flag)
        const scan = await navigator.bluetooth.requestLEScan({ acceptAllAdvertisements: true });
        const h = e => add(e.device.id, e.device.name, e.rssi);
        navigator.bluetooth.addEventListener("advertisementreceived", h);
        btStop = () => { scan.stop(); navigator.bluetooth.removeEventListener("advertisementreceived", h); };
      } else if (navigator.bluetooth?.requestDevice) {      // fallback: one device you pick
        const dev = await navigator.bluetooth.requestDevice({ acceptAllDevices: true });
        const h = e => add(dev.id, dev.name, e.rssi);
        dev.addEventListener("advertisementreceived", h); await dev.watchAdvertisements();
        btStop = () => dev.removeEventListener("advertisementreceived", h);
      } else throw new Error("Web Bluetooth not available in this browser.");
      btBtn.textContent = "Stop Bluetooth"; msg.textContent = "Bluetooth: listening for advertisements…";
    } catch (e) {
      msg.textContent = "Bluetooth: " + e.message + " — in Chrome open chrome://flags, enable 'Experimental Web Platform features', and use http://127.0.0.1:8765.";
    }
  };

  document.getElementById("radarDemo").onclick = function () {
    if (demoTimer) { clearInterval(demoTimer); demoTimer = null; this.textContent = "Demo"; return; }
    this.textContent = "Stop demo";
    const fake = Array.from({ length: 12 }, (_, i) => ({ id: "demo" + i, type: i < 7 ? "wifi" : "bt",
      label: (i < 7 ? "Demo-WiFi-" : "Demo-BT-") + i, base: -40 - i * 4.5 }));
    const tick = () => fake.forEach(f => upsert({ ...f, rssi: Math.round(f.base + (Math.random() - .5) * 6) }));
    tick(); demoTimer = setInterval(tick, 2000); msg.textContent = "Demo data (simulated).";
  };
})();
