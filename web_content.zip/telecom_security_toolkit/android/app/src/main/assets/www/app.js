async function getJSON(url, options={}) {
  if (location.protocol === "file:") throw new Error("Offline APK mode: no Python backend. Radar, cellular and Bluetooth run natively. Nmap scans need the Termux version.");
  const r = await fetch(url, options);
  const data = await r.json().catch(()=>({detail:"Invalid server response"}));
  if (!r.ok) throw new Error(data.detail || `HTTP ${r.status}`);
  return data;
}
document.getElementById("statusBtn").onclick = async () => {
  const el=document.getElementById("status"); el.textContent="Checking…";
  try { el.textContent=JSON.stringify(await getJSON("/api/status"),null,2); }
  catch(e){el.textContent=e.message;}
};
document.getElementById("scanBtn").onclick = async () => {
  const el=document.getElementById("scan"); el.textContent="Scanning…";
  try {
    const data=await getJSON("/api/scan",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({target:document.getElementById("target").value.trim()})});
    el.textContent=data.output || JSON.stringify(data,null,2);
  } catch(e){el.textContent=e.message;}
};
document.getElementById("cellBtn").onclick = () => {
  const el=document.getElementById("cell");
  if (window.AndroidBridge?.getCellInfo) el.textContent=window.AndroidBridge.getCellInfo();
  else el.textContent="Native Android cellular bridge is available only inside the APK. Grant location permission when prompted.";
};
document.getElementById("btBtn").onclick = () => {
  const el=document.getElementById("bt");
  if (window.AndroidBridge?.bluetoothStatus) el.textContent=window.AndroidBridge.bluetoothStatus();
  else el.textContent="Bluetooth bridge is available only inside the APK. Printing is not implemented in this starter.";
};
