# Telecom Security Toolkit — starter source

This ZIP is a **source-code starter kit**, not a prebuilt APK. It combines:
- Python + FastAPI local backend
- Nmap via Termux
- JavaScript dashboard
- Android Kotlin WebView shell and cellular-info bridge
- Bluetooth printer capability placeholder and implementation notes

## Safety / limitations
- Nmap scanning is restricted in the Python API to RFC1918 private IPv4 addresses and networks no larger than /24. Only scan networks/devices you own or are explicitly authorized to test.
- Android cell data is device- and carrier-dependent. Android requires runtime location permission for `TelephonyManager.getAllCellInfo()`. Results may be cached, incomplete, or unavailable.
- A cell tower does not have a single publicly discoverable “static IP”. The app reports radio identifiers (where Android exposes them), not operator infrastructure addresses. Approximate tower coordinates would require a separate lawful/public cell database lookup.
- Bluetooth printing depends on the printer protocol (classic SPP, BLE, vendor SDK, or Android print service). This starter only reports paired-device availability as a future native integration point; it does not claim to print.
- No Wi-Fi password cracking, deauthentication, interception, or carrier-network scanning is included.

## Run backend in Termux
Install Termux packages:
```bash
pkg update -y && pkg upgrade -y
pkg install python nmap -y
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Start the API:
```bash
cd telecom_security_toolkit/backend
python app.py
```
Then open `http://127.0.0.1:8765` in your Android browser.

## Android Studio project
Open the `android/` folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
The Android shell expects the Python backend to be running locally at `http://127.0.0.1:8765`. Start the backend in Termux first.
For a production APK, configure signing, app icon, privacy disclosures, runtime permission rationale, and test on the target Android version.

## Project layout
- `backend/app.py`: API and guarded Nmap scan
- `frontend/`: JavaScript dashboard
- `android/`: Kotlin Android shell and cellular info bridge

## Offline radar (red radar, white dots)
Open the dashboard and use the **Radar** panel at the top. Works with no internet; the radar is drawn on a local canvas.
- **Wi-Fi**: `pkg install termux-api`, install the **Termux:API** app (same source as Termux, e.g. F-Droid), grant it Location permission and turn Location on. Tap *Start Wi-Fi radar* (refreshes every 10 s; Android throttles Wi-Fi scans).
- **Bluetooth**: uses Web Bluetooth in Chrome at `http://127.0.0.1:8765`. Enable `chrome://flags` > *Experimental Web Platform features*, then tap *Scan Bluetooth*. Termux itself cannot scan Bluetooth without root.
- **Demo** shows simulated dots to preview the display.
- Dot distance = signal strength (centre = strong). Direction is not measurable by a phone, so each device's angle is fixed but arbitrary. Tap a dot for its name.

## Offline APK (no Termux needed for radar)
The `android/` app now bundles the UI (`app/src/main/assets/www`) and scans Wi-Fi and Bluetooth LE natively. It has **no INTERNET permission**, so it cannot send data anywhere. Nmap scans still need the Termux version.
Build a debug APK (installable, debug-signed):
- **Android Studio**: open `android/`, then Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.
- **GitHub (no PC)**: upload this whole folder (including `.github/`) to a new repo; Actions > *Build APK* > download the `app-debug.apk` artifact.
If you change `frontend/`, copy `radar.js` and `app.js` into `android/app/src/main/assets/www/` and re-copy `index.html` with `/assets/` removed from the script paths.
