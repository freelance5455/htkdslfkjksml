from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
import ipaddress, subprocess, shutil, json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
FRONTEND = BASE / "frontend"
app = FastAPI(title="Telecom Security Toolkit API", version="0.1.0")
app.mount("/assets", StaticFiles(directory=FRONTEND), name="assets")

class ScanRequest(BaseModel):
    target: str = Field(..., description="Private IPv4 address or CIDR you are authorized to scan")

def validate_private_target(value: str) -> str:
    try:
        net = ipaddress.ip_network(value, strict=False)
    except ValueError:
        raise HTTPException(400, "Enter a valid IPv4 address or CIDR.")
    if net.version != 4 or not net.is_private:
        raise HTTPException(403, "Only private IPv4 networks are allowed (RFC1918).")
    if net.num_addresses > 256:
        raise HTTPException(400, "Network is too large. Maximum allowed size is /24.")
    return str(net)

@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")

@app.get("/api/status")
def status():
    return {
        "api": "online",
        "nmap_available": shutil.which("nmap") is not None,
        "scope": "Private IPv4 only; max /24; scan only with permission"
    }

@app.post("/api/scan")
def scan(req: ScanRequest):
    target = validate_private_target(req.target)
    nmap = shutil.which("nmap")
    if not nmap:
        raise HTTPException(503, "Nmap not found. In Termux run: pkg install nmap")
    # Fixed safe options; no shell invocation and no user-controlled flags.
    try:
        result = subprocess.run(
            [nmap, "-F", "--open", target],
            capture_output=True, text=True, timeout=90, check=False
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Nmap scan timed out.")
    return {
        "target": target,
        "return_code": result.returncode,
        "output": (result.stdout + "\n" + result.stderr)[-12000:]
    }

@app.get("/api/radar/wifi")
def radar_wifi():
    """Passive, offline list of nearby Wi-Fi access points (Termux:API, no internet needed)."""
    tool = shutil.which("termux-wifi-scaninfo")
    if not tool:
        raise HTTPException(503, "termux-wifi-scaninfo not found. In Termux run: pkg install termux-api "
                                 "and install the Termux:API app.")
    try:
        r = subprocess.run([tool], capture_output=True, text=True, timeout=20, check=False)
        data = json.loads(r.stdout or "[]")
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Wi-Fi scan timed out.")
    except json.JSONDecodeError:
        raise HTTPException(502, "Unexpected output from termux-wifi-scaninfo.")
    if isinstance(data, dict):  # e.g. {"API_ERROR": "..."} when location is off / permission missing
        raise HTTPException(503, str(data.get("API_ERROR") or data)[:300]
                            + " (Turn on Location and grant it to Termux:API.)")
    aps = [{
        "id": a.get("bssid") or a.get("ssid") or "?",
        "label": a.get("ssid") or "(hidden)",
        "rssi": a.get("rssi"),
        "freq": a.get("frequency_mhz"),
        "type": "wifi",
    } for a in data if isinstance(a, dict) and isinstance(a.get("rssi"), (int, float))]
    return {"count": len(aps), "devices": aps}

@app.get("/api/cellular")
def cellular():
    return {
        "available": False,
        "message": "Cellular identifiers are read by the Android Kotlin bridge in the APK, not by this Termux server.",
        "note": "No public/static tower IP is exposed by standard Android APIs."
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8765)
