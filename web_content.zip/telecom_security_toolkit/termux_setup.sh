#!/data/data/com.termux/files/usr/bin/bash
# One-time setup (needs internet once); afterwards everything runs offline.
set -e
pkg update -y && pkg install -y python nmap termux-api
python -m pip install -r requirements.txt
echo "Also install the 'Termux:API' app (F-Droid) and grant it Location permission."
echo "Start:  cd backend && python app.py   then open http://127.0.0.1:8765"
