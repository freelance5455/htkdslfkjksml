
const API='https://api.binance.com/api/v3/';
let symbols=['BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT','LINKUSDT','DOTUSDT','LTCUSDT','ATOMUSDT'];
const DEFAULT_SYMBOLS=[...symbols];
const BUILD_ID='v44-1000-top12-btc-eth-ada-market-search-selected-coin-shadow';
let symbolCursor=0, symbolsLoaded=false, symbolsLastLoaded=0;
const SYMBOL_BATCH_SIZE=80;
const PREVIOUS_BUILD=localStorage.getItem('ct_v44_build')||'';
const BUILD_CHANGED=PREVIOUS_BUILD!==BUILD_ID;
if(BUILD_CHANGED) localStorage.setItem('ct_v44_build',BUILD_ID);
const D={capital:1000,cash:1000,dip:2.5,target:3.5,alloc:12,maxExposure:70,reserve:15,fee:.1,slip:.05,
trailActivate:5,trailDrop:1.5,trailConfirm:2,reversalDrop:2.5,reversalConfirm:2,maxPositions:6,maxPerAsset:18,minScore:62,
partialBuy:2,partialSell1:35,partialSell2:35,lookback:500,intervalMs:10000,
positions:{},trades:[],events:[],equity:1000,last:null,auto:true,startupCycles:0,candidateStreaks:{},btcBearishPct:3,marketTrendSamples:[],firstRunObservationDone:false};
let S=(JSON.parse(localStorage.getItem('ct_v44_state')||'null') || JSON.parse(localStorage.getItem('ct_v3_state')||'null'))||D;
S={...D,...S,positions:S?.positions||{},trades:Array.isArray(S?.trades)?S.trades:[],events:Array.isArray(S?.events)?S.events:[],startupCycles:Number(S?.startupCycles||0),candidateStreaks:S?.candidateStreaks||{},btcBearishPct:Number(S?.btcBearishPct??3),marketTrendSamples:Array.isArray(S?.marketTrendSamples)?S.marketTrendSamples:[],firstRunObservationDone:!!S?.firstRunObservationDone};
// Primeira abertura da app: começar sempre sem posições/compras anteriores.
// As configurações mantêm-se, mas a carteira começa limpa com os 100 USD iniciais.
const INITIAL_CLEAN_KEY='ct_v44_initial_clean_1000_done';
if(localStorage.getItem(INITIAL_CLEAN_KEY)!=='1'){
  S.positions={};
  S.trades=[];
  S.events=[];
  S.cash=1000;
  S.equity=1000;
  S.last=null;
  S.startupCycles=0;
  S.candidateStreaks={};
  S.firstRunObservationDone=false;
  S.marketTrendSamples=[];
  localStorage.setItem(INITIAL_CLEAN_KEY,'1');
  save();
}
// Na primeira abertura desta versão começa também uma nova observação de 5 minutos.
if(BUILD_CHANGED){S.firstRunObservationDone=false;S.marketTrendSamples=[];save();}
let tab='dash', market={}, candles={}, chartCandles={}, chartTF='1h', selectedSymbol=null, selectedPosition=null, marketSearch='', marketSearchOpen=false, chartViews={};
let dataStatus={}, lastDataUpdate=0;
try{const cached=JSON.parse(localStorage.getItem('ct_v44_candles')||'null');if(cached&&typeof cached==='object')candles=cached}catch(e){}
function saveCandles(){try{localStorage.setItem('ct_v44_candles',JSON.stringify(candles))}catch(e){}}
async function loadChartCandles(s,tf){
  if(!s||!['5m','15m','1h'].includes(tf))return;
  const key=s+'_'+tf;
  if(chartCandles[key]&&chartCandles[key].length>=2){render();return;}
  try{
    const limits={'5m':1000,'15m':700,'1h':168};
    const data=await jget(`klines?symbol=${s}&interval=${tf}&limit=${limits[tf]||168}`);
    if(Array.isArray(data)&&data.length>=2){chartCandles[key]=data;render();}
  }catch(e){}
}
function dataAgeText(){if(!lastDataUpdate)return 'Ainda sem atualização';const sec=Math.max(0,Math.round((Date.now()-lastDataUpdate)/1000));return sec<60?sec+'s atrás':Math.floor(sec/60)+'min atrás';}

function save(){localStorage.setItem('ct_v44_state',JSON.stringify(S)); localStorage.setItem('ct_v3_state',JSON.stringify(S))}
function logEvent(type,symbol,reason,extra={}){
  const now=Date.now(), key=type+'|'+(symbol||'')+'|'+(reason||'');
  const last=(S.events||[])[0];
  if(last&&last.key===key&&now-last.time<5*60*1000)return;
  S.events=[{time:now,type,symbol:symbol||'',reason:reason||'',key,...extra},...(S.events||[])].slice(0,250);
}
function tradeStats(){
  const sells=(S.trades||[]).filter(t=>String(t.type).toUpperCase()==='SELL');
  const profits=sells.map(t=>Number(t.profit)||0);
  const wins=profits.filter(v=>v>0), losses=profits.filter(v=>v<0);
  const realized=profits.reduce((a,v)=>a+v,0);
  const grossWin=wins.reduce((a,v)=>a+v,0), grossLoss=Math.abs(losses.reduce((a,v)=>a+v,0));
  const peak=Math.max(Number(S.capital)||100, ...(sells.length?[Number(S.capital)+profits.reduce((a,v,i)=>a+v,0)]:[]));
  return {sells,wins,losses,realized,winRate:sells.length?wins.length/sells.length*100:0,avg:sells.length?realized/sells.length:0,profitFactor:grossLoss?grossWin/grossLoss:(grossWin?Infinity:0),best:wins.length?Math.max(...wins):0,worst:losses.length?Math.min(...losses):0};
}
function eventLabel(e){const sym=String(e.symbol||'').replace('USDT','');return e.type==='BLOCK'?`⛔ ${sym}: ${e.reason}`:e.type==='BUY'?`🟢 ${sym}: entrada`:e.type==='SELL'?`🔴 ${sym}: saída`:e.reason||e.type}
function pct(x){return (x*100).toFixed(2)+'%'}
function money(x){return Number(x||0).toLocaleString('pt-PT',{style:'currency',currency:'USD',maximumFractionDigits:2})}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function jget(path){let r=await fetch(API+path);if(!r.ok)throw Error(r.status);return r.json()}
async function loadBinanceSymbols(force=false){
  if(symbolsLoaded && !force && Date.now()-symbolsLastLoaded<6*60*60*1000)return;
  try{
    const info=await jget('exchangeInfo');
    const blockedBases=/^(USDT|USDC|FDUSD|TUSD|BUSD|DAI|USDP)$/;
    const leveraged=/(UP|DOWN|BULL|BEAR)$/;
    const discovered=(info.symbols||[])
      .filter(x=>x.status==='TRADING' && x.quoteAsset==='USDT' && x.isSpotTradingAllowed!==false)
      .map(x=>x.symbol)
      .filter(s=>{const base=s.replace(/USDT$/,'');return base&&!blockedBases.test(base)&&!leveraged.test(base)});
    symbols=Array.from(new Set(['BTCUSDT',...discovered])).sort((a,b)=>a==='BTCUSDT'?-1:b==='BTCUSDT'?1:a.localeCompare(b));
    symbolsLoaded=true;symbolsLastLoaded=Date.now();symbolCursor=0;
    try{localStorage.setItem('ct_v44_symbols',JSON.stringify(symbols));localStorage.setItem('ct_v44_symbols_time',String(symbolsLastLoaded))}catch(e){}
  }catch(e){
    try{const cached=JSON.parse(localStorage.getItem('ct_v44_symbols')||'null');if(Array.isArray(cached)&&cached.length){symbols=cached;symbolsLoaded=true;symbolsLastLoaded=Number(localStorage.getItem('ct_v44_symbols_time')||0)}}catch(_e){}
  }
}
function score(c){
  let rsi=calcRSI(c.map(x=>+x[4]).slice(-120)), closes=c.map(x=>+x[4]), ema20=ema(closes,20), ema50=ema(closes,50);
  let p=+c[c.length-1][4], hi=Math.max(...c.slice(-168).map(x=>+x[2])), lo=Math.min(...c.slice(-168).map(x=>+x[3]));
  let vol=c.slice(-24).reduce((a,x)=>a+ +x[5],0)/24, volNow=+c[c.length-1][5];
  let trend=ema20>ema50?22:0, rsiPts=(rsi>=42&&rsi<=65)?18:0, above= p>ema20?12:0;
  let dipPts=p<hi*(1-S.dip/100)?12:0, volPts=volNow>=vol*.9?10:0, reboundPts=p>lo*1.03?8:0;
  let penalty=rsi>72?-18:(rsi<30?-8:0);
  let s=trend+rsiPts+above+dipPts+volPts+reboundPts+penalty;
  return {score:Math.max(0,Math.min(100,s)),rsi,ema20,ema50,hi,lo,vol,volNow,p,parts:{trend,rsi:rsiPts,above,dip:dipPts,volume:volPts,rebound:reboundPts,penalty}};
}
function entryQuality(s,c){
  const extension=((c.p-c.ema20)/c.ema20)*100;
  if(extension>4.5)return {ok:false,why:'Preço demasiado esticado acima da EMA20'};
  if(c.rsi>72)return {ok:false,why:'RSI elevado — evitar comprar no topo'};
  const v=volatility(candles[s]);
  const calm=v<=1.2;
  if(calm && c.p>c.ema20 && c.ema20>=c.ema50 && c.volNow>=c.vol*.85)
    return {ok:true,level:'calma',why:'Entrada adaptada à baixa volatilidade'};
  return {ok:true,level:'normal',why:'Entrada validada pelo timeframe 1h'};
}
function opportunityProfile(s,c){
  const q=entryQuality(s,c);
  const v=volatility(candles[s]);
  const btc=market.BTCUSDT;
  const btcStrong=btc&&btc.dataOk&&btc.p>btc.ema20&&btc.ema20>=btc.ema50&&btc.rsi>=44&&btc.rsi<=67&&btc.score>=62;
  let level='normal', min=60, need=2;
  if(q.level==='forte' && c.score>=68 && btcStrong){ level='forte'; min=68; need=1; }
  else if(v<=1.2 && q.level==='calma' && c.score>=56){ level='calma'; min=56; need=2; }
  else if(c.score>=60){ level='normal'; min=60; need=2; }
  else return {level:'aguardar',min:60,need:2,ok:false,why:'Score abaixo do nível de oportunidade'};
  return {level,min,need,ok:c.score>=min,q,vol:v};
}

function ema(a,n){let k=2/(n+1),e=a[0];for(let i=1;i<a.length;i++)e=a[i]*k+e*(1-k);return e}
function calcRSI(a,n=14){if(a.length<=n)return 50;let g=0,l=0;for(let i=a.length-n;i<a.length;i++){let d=a[i]-a[i-1];if(d>0)g+=d;else l-=d}if(!l)return 100;return 100-100/(1+g/l)}
function posValue(){return Object.entries(S.positions).reduce((a,[s,p])=>a+p.qty*(market[s]?.last||p.entry),0)}
function equity(){return S.cash+posValue()}
function exposure(){return equity()?posValue()/equity()*100:0}
function volatility(c){
  if(!c||c.length<24)return 1.5;
  const a=c.slice(-24).map(x=>(+x[2]-+x[3])/(+x[4]||1)*100);
  return a.reduce((s,v)=>s+v,0)/a.length;
}
function trailSettings(c){
  const v=volatility(c);
  // Para não deixar passar várias oscilações pequenas, o trailing adapta-se
  // também a movimentos de 1–2%, sem deixar de acompanhar subidas maiores.
  if(v<=1.0)return {activate:1.2,drop:0.55,vol:v,label:'baixa'};
  if(v<=2.0)return {activate:1.8,drop:0.7,vol:v,label:'média'};
  return {activate:2.5,drop:1.0,vol:v,label:'alta'};
}

function threshold(p){
  // Venda mínima líquida para o trailing: usa o nível de ativação da própria
  // posição, em vez do antigo alvo fixo de 3,5%. Assim, movimentos pequenos
  // podem ser realizados sem perder a proteção de taxas/slippage.
  const minNet=Math.max(0.25,Number(p.trailActivate||S.trailActivate)-0.25);
  return p.entry*(1+(minNet+(S.fee*2+S.slip*2))/100);
}
function btcMarketGate(){
  const b=market.BTCUSDT;
  if(!b||!b.dataOk)return {ok:false,reason:'A aguardar dados do BTC'};
  // O limiar é configurável em Config. e aplica-se à queda do BTC nos últimos 3 minutos.
  const bearishPct=Math.max(0.1,Number(S.btcBearishPct??3));
  const change3m=Number(b.change3m);
  const sharpDrop=Number.isFinite(change3m) && change3m<=-bearishPct;
  const bearish=sharpDrop;
  const ok=!bearish;
  return {ok,bearish,sharpDrop,bearishPct,change3m,reason:ok?'BTC sem queda acentuada':'BTC em queda acentuada'};
}
function updateMarketTrendObservation(){
  const prices={};
  let count=0;
  for(const s of symbols){
    const c=market[s];
    if(c&&c.dataOk&&Number.isFinite(Number(c.last))){prices[s]=Number(c.last);count++;}
  }
  if(count<5)return;
  const now=Date.now();
  const samples=Array.isArray(S.marketTrendSamples)?S.marketTrendSamples:[];
  samples.push({t:now,prices});
  S.marketTrendSamples=samples.filter(x=>x&&Number(x.t)>now-6*60*1000).slice(-20);
}
function marketTrendGate(){
  // A análise de 5 minutos acontece apenas na primeira utilização da app.
  // Depois de concluída, a app volta ao funcionamento normal e não repete esta espera.
  if(S.firstRunObservationDone)return {ok:true,ready:true,bearish:false,downPct:0,avg5m:0,reason:'Análise inicial concluída'};
  const samples=Array.isArray(S.marketTrendSamples)?S.marketTrendSamples:[];
  const now=Date.now(), target=now-5*60*1000;
  if(samples.length<2)return {ok:false,ready:false,reason:'A analisar tendência do mercado (5 min)'};
  let base=samples[0];
  for(const x of samples){if(Number(x.t)<=target)base=x;else break;}
  if(!base||now-Number(base.t)<5*60*1000)return {ok:false,ready:false,reason:'A analisar tendência do mercado (5 min)'};
  const changes=[];
  for(const s of symbols){
    const p0=Number(base.prices?.[s]), p1=Number(market[s]?.last);
    if(p0>0&&p1>0)changes.push((p1/p0-1)*100);
  }
  if(changes.length<5)return {ok:false,ready:false,reason:'A aguardar dados suficientes para a análise de 5 min'};
  const downPct=changes.filter(x=>x<0).length/changes.length*100;
  const avg5m=changes.reduce((a,v)=>a+v,0)/changes.length;
  return {ok:true,ready:true,bearish:downPct>=70&&avg5m<0,downPct,avg5m,reason:'Análise inicial de 5 min concluída'};
}
function marketRegime(){
  const vals=symbols.map(s=>market[s]).filter(c=>c&&c.dataOk);
  if(vals.length<5)return {bear:false,recovery:false,downPct:0,reason:'Dados de mercado insuficientes'};
  const down=vals.filter(c=>c.chg<0).length/vals.length*100;
  const avgScore=vals.reduce((a,c)=>a+c.score,0)/vals.length;
  const leaders=vals.filter(c=>(c.score>=S.minScore)&&c.p>c.ema20&&c.rsi>=40&&c.rsi<=68).length;
  const bear=down>=70 && avgScore<55;
  const recovery=!bear || leaders>=2;
  return {bear,recovery,downPct:down,avgScore,leaders,reason:bear&&!recovery?'Mercado geral em queda — a aguardar sinais de recuperação':''};
}
function netGainPct(p,price){return ((price*(1-S.slip/100)*(1-S.fee/100))/p.entry-1)*100}

function startupActive(){
  return !S.firstRunObservationDone;
}
function startupText(){
  if(!startupActive())return '';
  const samples=Array.isArray(S.marketTrendSamples)?S.marketTrendSamples:[];
  const first=Number(samples[0]?.t||Date.now());
  const elapsed=Math.max(0,Date.now()-first);
  const mins=Math.min(5,Math.floor(elapsed/60000));
  return `A analisar tendências antes da primeira compra • ${mins}/5 min`;
}
function confidenceReady(s,c){
  if(!c||!c.dataOk||startupActive())return false;
  const op=opportunityProfile(s,c);
  return op.ok && (S.candidateStreaks[s]||0)>=op.need;
}
function canBuy(s,c){
  if(!c||!c.dataOk)return {ok:false,why:'Dados históricos indisponíveis/desatualizados'};
  if(startupActive())return {ok:false,why:startupText()};
  const btc=btcMarketGate(false);
  if(!btc.ok)return {ok:false,why:'BTC: '+btc.reason};
  const trend=marketTrendGate();
  if(!trend.ok)return {ok:false,why:trend.reason};
  if(S.positions[s])return {ok:false,why:'Já existe posição'};
  if(Object.keys(S.positions).length>=S.maxPositions)return {ok:false,why:'Limite de posições'};
  if(exposure()>=S.maxExposure)return {ok:false,why:'Exposição máxima'};
  const op=opportunityProfile(s,c);
  if(!op.ok)return {ok:false,why:op.why||'Sem oportunidade suficiente'};
  if((S.candidateStreaks[s]||0)<op.need)return {ok:false,why:`A confirmar oportunidade ${op.level} (${S.candidateStreaks[s]||0}/${op.need})`};
  let budget=Math.min(S.capital*S.alloc/100,S.cash-S.capital*S.reserve/100,Math.max(0,S.capital*S.maxPerAsset/100));
  return budget>0?{ok:true,budget,level:op.level}:{ok:false,why:'Reserva/capital insuficiente'};
}
function buy(s,c,budget){
  let slip=c.p*(S.slip/100), price=c.p+slip, fee=budget*S.fee/100, spend=budget-fee, qty=spend/price;
  S.cash-=budget; const ts=trailSettings(candles[s]);
  S.positions[s]={qty,initialQty:qty,entry:price,avg:price,invested:budget,boughtAt:Date.now(),peak:price,peakProfit:0,trailArmed:false,downCount:0,score:c.score,partial:0,trailActivate:ts.activate,trailDrop:ts.drop,reversalDrop:Math.max(2,Math.min(3,ts.drop+1.5)),reversalConfirm:S.reversalConfirm,volatility:ts.vol,
    entryReason:`Oportunidade ${opportunityProfile(s,c).level}; Score ${c.score}/100; RSI ${c.rsi.toFixed(1)}; tendência EMA20/EMA50`};
  S.trades.push({time:Date.now(),type:'BUY',symbol:s,qty,price,fee,reason:S.positions[s].entryReason});
  logEvent('BUY',s,S.positions[s].entryReason,{score:c.score});
}
function sellPart(s,frac,reason){
  let p=S.positions[s],c=market[s];
  if(!p||!c||!c.dataOk)return false;
  let qty=Math.min(p.qty,p.qty*frac),price=c.last*(1-S.slip/100),gross=qty*price,fee=gross*S.fee/100;
  let cost=qty*p.entry,net=gross-fee-cost;
  if(net<=0)return false;
  S.cash+=gross-fee;p.qty-=qty;
  S.trades.push({time:Date.now(),type:'SELL',symbol:s,qty,price,fee,profit:net,reason,peak:p.peak});
  logEvent('SELL',s,reason,{profit:net});
  if(p.qty<=1e-12)delete S.positions[s];
  return true;
}
function progressiveProtection(p,peakGain){
  // Quanto maior o lucro já alcançado, menor a devolução permitida desde o pico.
  if(peakGain>=10)return {drop:.70,label:'forte'};
  if(peakGain>=7)return {drop:.90,label:'alta'};
  if(peakGain>=4)return {drop:1.10,label:'média'};
  if(peakGain>=2)return {drop:1.40,label:'inicial'};
  return null;
}
function manage(s,c){
  let p=S.positions[s];if(!p||!c||!c.dataOk)return;
  if(c.last>p.peak){p.peak=c.last;p.downCount=0;p.protectionCount=0}
  p.peakProfit=Math.max(Number(p.peakProfit||0), (Number(p.initialQty||p.qty||0)*(p.peak-p.entry)));
  let gain=(c.last/p.entry-1)*100;
  const ta=p.trailActivate||S.trailActivate, td=p.trailDrop||S.trailDrop;
  if(gain>=ta)p.trailArmed=true;
  if(p.trailArmed&&c.last<=p.peak*(1-td/100))p.downCount++;
  else if(c.last>p.peak*(1-td/100))p.downCount=0;

  const peakGain=(p.peak/p.entry-1)*100;
  const peakDrop=p.peak?((p.peak-c.last)/p.peak*100):0;
  const netNow=netGainPct(p,c.last);

  // Proteção progressiva: depois de conquistar lucro, a margem de devolução
  // diminui conforme o pico de lucro aumenta. Não espera duas leituras quando
  // a proteção já foi atingida, para reagir melhor a reversões rápidas.
  const protection=progressiveProtection(p,peakGain);
  if(protection && peakDrop>=protection.drop && netNow>0.15){
    p.protectionCount=(p.protectionCount||0)+1;
    if(p.protectionCount>=1){
      if(p.partial===0){
        if(sellPart(s,S.partialSell1/100,'Proteção progressiva: +'+peakGain.toFixed(1)+'% no pico, recuo de '+peakDrop.toFixed(1)+'%'))p.partial=1;
      }else if(p.partial===1){
        if(sellPart(s,S.partialSell2/100,'Proteção progressiva: continuação da reversão'))p.partial=2;
      }else{
        sellPart(s,1,'Proteção progressiva: saída final após reversão');
      }
      return;
    }
  }else if(!protection || peakDrop<protection.drop){
    p.protectionCount=0;
  }

  // Proteção adicional contra uma reversão maior, mantendo as taxas/slippage.
  const reversalDrop=p.reversalDrop||S.reversalDrop;
  if(peakDrop>=reversalDrop && netNow>0.15){
    p.reversalCount=(p.reversalCount||0)+1;
  }else if(peakDrop<reversalDrop){
    p.reversalCount=0;
  }
  if((p.reversalCount||0)>=1 && netNow>0.15){
    sellPart(s,1,'Proteção de lucro: reversão de '+peakDrop.toFixed(1)+'% desde o pico');
    return;
  }

  if(p.trailArmed&&p.downCount>=S.trailConfirm&&c.last>threshold(p)){
    if(p.partial===0){
      if(sellPart(s,S.partialSell1/100,'Trailing profit: 1ª realização após reversão confirmada'))p.partial=1;
    }else if(p.partial===1){
      if(sellPart(s,S.partialSell2/100,'Trailing profit: 2ª realização após reversão confirmada'))p.partial=2;
    }else{
      sellPart(s,1,'Trailing profit: saída final após reversão confirmada');
    }
  }
}

let refreshInFlight=false;
const REFRESH_INTERVAL=10000;
async function refresh(){
  if(refreshInFlight)return;
  refreshInFlight=true;
  try{
    await loadBinanceSymbols();
    // A Binance tem muitas pares USDT. Para não ultrapassar os limites públicos da API,
    // os candles de 1h são analisados em lotes rotativos; o ticker atualiza todos os pares.
    const arr=await jget('ticker/24hr');
    const ticker={};arr.forEach(x=>ticker[x.symbol]={last:+x.lastPrice,chg:+x.priceChangePercent,vol:+x.quoteVolume});
    const batch=[];
    for(let i=0;i<SYMBOL_BATCH_SIZE && symbols.length;i++){
      batch.push(symbols[(symbolCursor+i)%symbols.length]);
    }
    symbolCursor=(symbolCursor+SYMBOL_BATCH_SIZE)%Math.max(1,symbols.length);
    const priority=new Set(Object.keys(S.positions||{}));priority.add('BTCUSDT');
    for(const s of priority)if(!batch.includes(s))batch.push(s);
    const results=await Promise.all(batch.map(async s=>{
      try{
        const requests=[jget(`klines?symbol=${s}&interval=1h&limit=${S.lookback}`)];
        if(s==='BTCUSDT') requests.push(jget(`klines?symbol=${s}&interval=3m&limit=2`));
        const [c,c3]=await Promise.all(requests);
        if(!Array.isArray(c)||c.length<60)throw Error('Histórico insuficiente');
        const age=Math.max(0,Date.now()-Number(c[c.length-1][6]));
        return {s,c,c3,ok:age<=2*60*60*1000,age};
      }catch(e){return {s,c:null,ok:false,error:String(e)}}
    }));
    // Mantém os dados dos restantes pares enquanto o lote seguinte é analisado.
    for(const s of symbols){
      if(ticker[s] && !market[s])market[s]={...ticker[s],p:ticker[s].last,score:null,rsi:null,dataOk:false};
      else if(ticker[s]&&market[s])market[s]={...market[s],...ticker[s],p:ticker[s].last};
    }
    for(const r of results){
      const s=r.s,t=ticker[s];if(!t)continue;
      if(r.ok){
        candles[s]=r.c;dataStatus[s]={ok:true,age:r.age,error:''};
        const q=score(r.c);
        const change3m=(s==='BTCUSDT'&&Array.isArray(r.c3)&&r.c3.length>=1&&Number(r.c3[0][4])>0)
          ? ((t.last/Number(r.c3[0][4])-1)*100) : null;
        market[s]={...t,...q,p:t.last,dataOk:true,dataAge:r.age,change3m};
      }else{
        dataStatus[s]={ok:false,age:r.age||Infinity,error:r.error||'Dados inválidos'};
        market[s]={...t,p:t.last,score:null,rsi:null,dataOk:false};
      }
    }
    lastDataUpdate=Date.now();saveCandles();
    // Atualiza a janela de observação inicial de 5 minutos antes de avaliar compras.
    updateMarketTrendObservation();
    const initialTrend=marketTrendGate();
    if(!S.firstRunObservationDone && initialTrend.ready){
      S.firstRunObservationDone=true;
      save();
    }
    // Avalia o filtro de segurança do BTC uma vez por ciclo.
    const btcGate=btcMarketGate();
    for(const s of symbols){
      const c=market[s];if(!c||!c.dataOk)continue;
      manage(s,c);
      const op=opportunityProfile(s,c);
      const baseOk=op.ok && !S.positions[s] && Object.keys(S.positions).length<S.maxPositions && exposure()<S.maxExposure;
      if(baseOk)S.candidateStreaks[s]=(S.candidateStreaks[s]||0)+1;
      else S.candidateStreaks[s]=0;
      const b=canBuy(s,c);
      if(!b.ok && !S.positions[s] && S.auto) logEvent('BLOCK',s,b.why);
      if(S.auto&&b.ok&&confidenceReady(s,c))buy(s,c,b.budget);
    }
    S.equity=equity();S.last=Date.now();S.lastError='';save();render();
  }catch(e){S.lastError=String(e);save();render()}finally{
    refreshInFlight=false;
    if(S.auto)setTimeout(()=>refresh(),REFRESH_INTERVAL);
  }
}
function chartHTML(s){
 let c=market[s]||{}, p=S.positions[s], key=s+'_'+chartTF, arr=chartCandles[key]||candles[s]||[], q=c.parts||{};
 let v=chartViews[key]; if(!v)v=chartViews[key]={count:chartDefaultCount(chartTF),start:Math.max(0,arr.length-chartDefaultCount(chartTF)),cross:null};
 let status=p?(p.trailArmed?'Trailing armado':'A acompanhar'):'Sem posição';
 return `<tr class="chartRow"><td colspan="6"><div class="chartBox" data-chart-symbol="${s}" data-no-tab-swipe="1" data-disable-tab-swipe="1" data-swipe-threshold="0.60">
 <div class="chartHead"><div><b>${s.replace('USDT','')}/USDT</b> <span class="muted">${money(c.last||0)}</span></div><div class="tiny">${status}</div></div>
 <div class="chartTFs" role="group" aria-label="Intervalo das velas">${['5m','15m','1h'].map(tf=>`<button type="button" class="chartTF ${chartTF===tf?'active':''}" data-chart-tf="${tf}" data-chart-symbol="${s}">${tf}</button>`).join('')}<button type="button" class="chartTF" data-chart-reset="1" data-chart-symbol="${s}">24h</button><button type="button" class="chartTF" data-chart-zoom="out" data-chart-symbol="${s}" title="Afastar">−</button><button type="button" class="chartTF" data-chart-zoom="in" data-chart-symbol="${s}" title="Aproximar">+</button></div>
 <canvas class="chartCanvas" id="chart-${s}" data-chart-symbol="${s}" tabindex="0"></canvas>
 <div class="scoreWhy"><span>Trend +${q.trend||0}</span><span>RSI +${q.rsi||0}</span><span>EMA +${q.above||0}</span><span>Dip +${q.dip||0}</span><span>Volume +${q.volume||0}</span><span>Rebound +${q.rebound||0}</span>${(q.penalty||0)?`<span>Penalty ${q.penalty}</span>`:''}</div>
 <div class="chartHint">24h inicial • arraste para navegar • roda/pinça para zoom • toque no gráfico para cruzeta e OHLC • ${arr.length} velas ${chartTF}</div>
 </div></td></tr>`;
}
function dashboardTopSymbols(){
 const fixed=['BTCUSDT','ETHUSDT','ADAUSDT'];
 const ranked=typeof topSymbols==='function'?topSymbols():symbols.slice();
 const result=[];
 for(const s of fixed){ if(symbols.includes(s) && !result.includes(s)) result.push(s); }
 for(const s of ranked){ if(!result.includes(s) && result.length<12) result.push(s); }
 return result.slice(0,12);
}
function tableMarket(limit=null){
 const q=String(marketSearch||'').trim().toUpperCase().replace(/\s+/g,'');
 const aliases={BITCOIN:'BTC',ETHEREUM:'ETH',BINANCECOIN:'BNB',SOLANA:'SOL',RIPPLE:'XRP',CARDANO:'ADA',DOGECOIN:'DOGE',AVALANCHE:'AVAX',CHAINLINK:'LINK',POLKADOT:'DOT',LITECOIN:'LTC',COSMOS:'ATOM'};
 const searchKey=aliases[q]||q;
 const allSymbols=symbols.slice(); const baseSymbols=limit===12?dashboardTopSymbols():allSymbols;
 let filtered=baseSymbols.slice();
 if(q){ const exact=filtered.filter(s=>s===searchKey+'USDT'||s.replace('USDT','')===searchKey); const matches=filtered.filter(s=>s!==searchKey+'USDT'&&s.replace('USDT','')!==searchKey && (s.replace('USDT','').includes(searchKey)||s.includes(searchKey))); const rest=filtered.filter(s=>!exact.includes(s)&&!matches.includes(s)); filtered=exact.concat(matches,rest); }
 const totalLabel=limit===12?`${filtered.length} principais de ${allSymbols.length} moedas`: `${filtered.length} de ${allSymbols.length} moedas`;
 return `<div class="card"><div class="marketToolbar"><div><b>${limit===12?'Top 12 moedas':'Mercado'}</b><div class="sub">${totalLabel}</div></div>${limit===12?'':'<button type="button" class="marketSearchBtn" id="marketSearchBtn" aria-label="Procurar moeda" title="Procurar moeda">⌕</button>'}</div>
 ${limit!==12 && (marketSearchOpen||q)?`<div class="marketSearchBox"><input id="marketSearchInput" type="search" inputmode="search" autocomplete="off" placeholder="Procurar moeda (ex.: BTC, ETH)" value="${esc(marketSearch)}" aria-label="Procurar moeda"><button type="button" id="marketSearchClear" aria-label="Limpar pesquisa">×</button></div>`:''}
 <div class="scroll"><table><tr><th>Cripto</th><th>Preço</th><th>24h</th><th>Score</th><th>RSI</th><th>Ação</th></tr>${filtered.map(s=>{let c=market[s];if(!c)return `<tr class="coinRow" data-symbol="${s}"><td class="coinTap">${s}</td><td colspan=5>...</td></tr>`;let b=canBuy(s,c);let ds=c.dataOk?'<span class="good">ATUAL</span>':'<span class="bad">DADOS DESATUALIZADOS</span>';let open=selectedSymbol===s;return `<tr class="coinRow ${open?'coinSelected':''}" data-symbol="${s}" aria-selected="${open?'true':'false'}"><td class="coinTap">${s.replace('USDT','')}</td><td>${money(c.last)}</td><td class="${c.chg>=0?'good':'bad'}">${c.chg.toFixed(2)}%</td><td>${c.score==null?'—':c.score}</td><td>${c.rsi==null?'—':c.rsi.toFixed(1)}</td><td>${ds}<br>${b.ok?'<span class="good">COMPRAR</span>':(startupActive()?'':'<span class="muted">'+esc(b.why)+'</span>')}${(S.candidateStreaks[s]||0)>0?`<br><span class="tiny">confirmação ${(S.candidateStreaks[s]||0)}/2</span>`:''}</td></tr>${open?chartHTML(s):''}`}).join('') || `<tr><td colspan="6" class="muted">Nenhuma moeda encontrada.</td></tr>`}</table></div></div>`;
}
function chartDefaultCount(tf){return tf==='5m'?288:tf==='15m'?96:24}
function chartViewFor(s){const key=s+'_'+chartTF,arr=chartCandles[key]||candles[s]||[],count=chartDefaultCount(chartTF);let v=chartViews[key];if(!v)v=chartViews[key]={count,start:Math.max(0,arr.length-count),cross:null};v.count=Math.max(12,Math.min(arr.length||count,v.count||count));v.start=Math.max(0,Math.min(Math.max(0,arr.length-v.count),v.start));return {key,arr,v}}
function drawChart(s){
 const canvas=document.getElementById('chart-'+s); const {key,arr,v}=chartViewFor(s); if(!canvas||arr.length<2)return;
 const visible=arr.slice(v.start,v.start+v.count); if(visible.length<2)return;
 const rect=canvas.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1);canvas.width=Math.max(1,Math.floor(rect.width*dpr));canvas.height=Math.max(1,Math.floor(rect.height*dpr));
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,rect.width,rect.height);
 const pad={l:8,r:62,t:10,b:30},volH=42,w=rect.width-pad.l-pad.r,h=rect.height-pad.t-pad.b-volH;
 const data=visible.map(k=>({t:+k[0],o:+k[1],hi:+k[2],lo:+k[3],c:+k[4],vol:+k[5]})),closes=data.map(x=>x.c),e20=emaSeries(closes,20),e50=emaSeries(closes,50);
 let all=[];data.forEach(k=>all.push(k.hi,k.lo));const p=S.positions[s];if(p)all.push(+p.entry,+p.peak);const min=Math.min(...all),max=Math.max(...all),span=max-min||1;
 const y=val=>pad.t+h-(val-min)/span*h,x=i=>pad.l+w*(data.length===1?0:i/(data.length-1));
 ctx.font='10px system-ui';ctx.textBaseline='middle';
 ctx.strokeStyle='#203044';ctx.lineWidth=1;for(let i=0;i<5;i++){let yy=pad.t+h*i/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(pad.l+w,yy);ctx.stroke();}
 const vmax=Math.max(...data.map(d=>d.vol||0),1);const step=Math.max(2,Math.min(16,w/data.length*.72));
 data.forEach((k,i)=>{const xx=x(i),yo=y(k.o),yc=y(k.c),yh=y(k.hi),yl=y(k.lo),up=k.c>=k.o;ctx.strokeStyle=up?'#43d17b':'#ff6875';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(xx,yh);ctx.lineTo(xx,yl);ctx.stroke();ctx.fillStyle=up?'#43d17b':'#ff6875';ctx.fillRect(xx-step/2,Math.min(yo,yc),step,Math.max(1,Math.abs(yc-yo)));let vh=volH*(k.vol||0)/vmax;ctx.globalAlpha=.28;ctx.fillRect(xx-step/2,pad.t+h+volH-vh,step,vh);ctx.globalAlpha=1;});
 function line(vals,stroke,width){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.beginPath();vals.forEach((val,i)=>{if(val==null)return;const xx=x(i),yy=y(val);i?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy)});ctx.stroke()}
 line(e20,'#43d17b',1.2);line(e50,'#ffb45c',1.2);
 ctx.setLineDash([5,4]);if(p){ctx.strokeStyle='#43d17b';ctx.beginPath();ctx.moveTo(pad.l,y(p.entry));ctx.lineTo(pad.l+w,y(p.entry));ctx.stroke();ctx.strokeStyle='#ff6875';ctx.beginPath();ctx.moveTo(pad.l,y(p.peak));ctx.lineTo(pad.l+w,y(p.peak));ctx.stroke();}ctx.setLineDash([]);
 ctx.fillStyle='#93a4b8';ctx.textAlign='left';ctx.fillText('VOL',pad.l,pad.t+h+volH/2);ctx.textAlign='right';for(let i=0;i<5;i++){const val=max-span*i/4;ctx.fillText(money(val),rect.width-5,pad.t+h*i/4);}
 const fmt=d=>d.toLocaleString([], {day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});ctx.textAlign='left';ctx.textBaseline='alphabetic';ctx.fillText(fmt(new Date(data[0].t)),pad.l,rect.height-5);ctx.textAlign='right';ctx.fillText(fmt(new Date(data[data.length-1].t)),rect.width-pad.r,rect.height-5);
 if(v.cross!=null){const ci=Math.max(0,Math.min(data.length-1,v.cross)),d=data[ci],xx=x(ci),yy=y(d.c);ctx.strokeStyle='#718096';ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(xx,pad.t);ctx.lineTo(xx,pad.t+h+volH);ctx.moveTo(pad.l,yy);ctx.lineTo(pad.l+w,yy);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#dbe7f5';ctx.fillRect(Math.min(Math.max(xx-48,pad.l),pad.l+w-96),pad.t,96,32);ctx.fillStyle='#07101d';ctx.textAlign='left';ctx.textBaseline='top';ctx.fillText(`O ${money(d.o)}  H ${money(d.hi)}`,Math.min(Math.max(xx-44,pad.l+4),pad.l+w-92),pad.t+4);ctx.fillText(`L ${money(d.lo)}  C ${money(d.c)}`,Math.min(Math.max(xx-44,pad.l+4),pad.l+w-92),pad.t+17);ctx.strokeStyle='#718096';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(pad.l+w,yy);ctx.stroke();}
 canvas.dataset.chartStart=v.start;canvas.dataset.chartCount=v.count;canvas.dataset.chartKey=key;
}
function emaSeries(a,n){if(!a.length)return[];const k=2/(n+1),out=[a[0]];for(let i=1;i<a.length;i++)out.push(a[i]*k+out[i-1]*(1-k));return out}
function bindCharts(){
 if(selectedSymbol)requestAnimationFrame(()=>drawChart(selectedSymbol));
 document.querySelectorAll('.coinRow').forEach(el=>el.onclick=()=>{let s=el.dataset.symbol;selectedSymbol=selectedSymbol===s?null:s;chartTF='1h';if(selectedSymbol)loadChartCandles(selectedSymbol,chartTF);else render()});
 document.querySelectorAll('.chartTF').forEach(btn=>btn.onclick=async e=>{e.stopPropagation();const s=btn.dataset.chartSymbol;if(btn.dataset.chartReset){const {key,arr}=chartViewFor(s);chartViews[key]={count:chartDefaultCount(chartTF),start:Math.max(0,arr.length-chartDefaultCount(chartTF)),cross:null};render();return}if(btn.dataset.chartZoom){const {key,arr,v}=chartViewFor(s);const old=v.count,next=Math.max(12,Math.min(arr.length||old,Math.round(old*(btn.dataset.chartZoom==='in'?.72:1.4))));const ratio=.5,anchor=v.start+Math.round(old*ratio);v.count=next;v.start=Math.max(0,Math.min(Math.max(0,arr.length-next),anchor-Math.round(next*ratio)));drawChart(s);return}const tf=btn.dataset.chartTf;chartTF=tf;await loadChartCandles(s,tf)});
 document.querySelectorAll('.chartCanvas').forEach(canvas=>{
   const s=canvas.dataset.chartSymbol;let drag=null,pointers=new Map(),pinch=null;
   const redraw=()=>requestAnimationFrame(()=>drawChart(s));
   canvas.onpointerdown=e=>{canvas.setPointerCapture?.(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size===2){const a=[...pointers.values()];pinch={dist:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),count:chartViewFor(s).v.count};drag=null;return}drag={id:e.pointerId,x:e.clientX,start:chartViewFor(s).v.start};};
   canvas.onpointermove=e=>{if(pointers.has(e.pointerId))pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const {arr,v}=chartViewFor(s);if(pointers.size===2&&pinch){const a=[...pointers.values()];const dist=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);const next=Math.max(12,Math.min(arr.length||pinch.count,Math.round(pinch.count*pinch.dist/Math.max(1,dist))));const center=(a[0].x+a[1].x)/2;const ratio=Math.max(0,Math.min(1,(center-canvas.getBoundingClientRect().left)/Math.max(1,canvas.clientWidth)));const anchor=v.start+Math.round(v.count*ratio);v.count=next;v.start=Math.max(0,Math.min(Math.max(0,arr.length-next),anchor-Math.round(next*ratio)));redraw();return}if(drag&&drag.id===e.pointerId){const pxPerC=Math.max(2,canvas.clientWidth/Math.max(1,v.count));const delta=Math.round((drag.x-e.clientX)/pxPerC);v.start=Math.max(0,Math.min(Math.max(0,arr.length-v.count),drag.start+delta));redraw();return}const r=canvas.getBoundingClientRect(),padL=8,padR=62,w=Math.max(1,r.width-padL-padR);const idx=Math.round((e.clientX-r.left-padL)/w*(Math.max(1,v.count)-1));v.cross=Math.max(0,Math.min(v.count-1,idx));redraw();};
   canvas.onpointerup=canvas.onpointercancel=e=>{pointers.delete(e.pointerId);if(pointers.size<2)pinch=null;if(drag&&drag.id===e.pointerId)drag=null;};
   canvas.onwheel=e=>{e.preventDefault();const {arr,v}=chartViewFor(s);if(!arr.length)return;const old=v.count,next=Math.max(12,Math.min(arr.length,Math.round(old*(e.deltaY<0?.78:1.28))));const ratio=Math.max(0,Math.min(1,e.offsetX/Math.max(1,canvas.clientWidth-70)));const anchor=v.start+Math.round(old*ratio);v.count=next;v.start=Math.max(0,Math.min(Math.max(0,arr.length-next),anchor-Math.round(next*ratio)));redraw();};
   canvas.ondblclick=()=>{const {key,arr}=chartViewFor(s),count=chartDefaultCount(chartTF);chartViews[key]={count:Math.min(count,arr.length||count),start:Math.max(0,arr.length-count),cross:null};redraw();};
   canvas.onmouseleave=()=>{const {v}=chartViewFor(s);v.cross=null;redraw();};
 });
}

function openProfit(){
  return Object.entries(S.positions||{}).reduce((total,[symbol,p])=>{
    const price=Number(market[symbol]?.last||p.entry||0);
    const qty=Number(p.qty||0);
    const entry=Number(p.entry||0);
    return total + qty*(price-entry);
  },0);
}
function dashboard(){
 let ev=equity(), pl=openProfit(),good=Object.values(dataStatus).filter(x=>x.ok).length;
 let sells=S.trades.filter(t=>t.type==='SELL'), realized=sells.reduce((a,t)=>a+(t.profit||0),0), wins=sells.filter(t=>(t.profit||0)>0).length;
 let best=sells.reduce((m,t)=>Math.max(m,t.profit||0),0), open=Object.keys(S.positions).length;
 let alerts=[]; symbols.forEach(s=>{let c=market[s],p=S.positions[s];if(c?.dataOk&&c.score>=S.minScore&&!p)alerts.push(`🟢 ${s.replace('USDT','')} score ${c.score}`);if(p?.trailArmed)alerts.push(`🟠 ${s.replace('USDT','')} trailing armado`) });
 const btc=market.BTCUSDT, btcGate=btcMarketGate(), regime=marketRegime();
 return `${startupActive()?`<div class="card"><b>🔎 Preparação inicial</b><div class="sub">${startupText()}. A app ainda não compra; está a validar tendência, RSI, EMA, volume e recuperação.</div></div>`:''}
 <div class="grid">
 <div class="card"><div class="muted">Capital</div><div class="metric">${money(ev)}</div></div>
 <div class="card" id="dashboardResultCard" data-toggle-result-positions="1" style="cursor:pointer" title="Mostrar/ocultar moedas em posição"><div class="muted">Resultados</div><div class="metric ${pl>=0?'good':'bad'}">${money(pl)}</div></div>
 <div class="card"><div class="muted">Caixa</div><div class="metric">${money(S.cash)}</div></div>
 <div class="card"><div class="muted">Exposição</div><div class="metric">${exposure().toFixed(1)}%</div></div>
 </div>
 <div id="dashboardResultPositions" class="card v44-result-expanded" style="display:none;margin-top:10px">
 <div class="v44-result-title">📊 <b>Resultados</b></div>
 <div class="v44-coins-box">
   <div class="v44-coins-title">💰 <b>Lucro das posições abertas</b></div>
   <div class="v44-coins-head"><span>Moeda</span><span>Posição</span><span>Lucro atual</span></div>
   <div>${dashboardResultPositions()}</div>
 </div>
</div>
 <div class="card"><b>📊 Resumo das operações</b>
 <div class="miniGrid">
  <div class="mini" data-goto-positions="1" style="cursor:pointer" title="Ir para os detalhes das posições"><span class="muted">Posições</span><b>${open}</b></div>
  <div class="mini"><span class="muted">Lucro realizado</span><b class="good">${money(realized)}</b></div>
  <div class="mini"><span class="muted">Taxa de acerto</span><b>${sells.length?((wins/sells.length)*100).toFixed(0):'0'}%</b></div>
  <div class="mini v44-sales-click" onclick="toggleV44SalesPanel()" style="cursor:pointer" title="Mostrar moedas vendidas"><span class="muted">Vendas</span><b>${sells.length}</b></div>
  <div class="mini v44-best-sale-click" onclick="toggleV44BestSalePanel()" style="cursor:pointer" title="Mostrar a moeda da melhor venda"><span class="muted">Melhor venda</span><b class="good">${money(best)}</b></div>
  <div class="mini"><span class="muted">Atualização</span><b>${S.last?new Date(S.last).toLocaleTimeString():'—'}</b></div>
 </div>
</div>
<div id="v44SalesPanel" class="card v44-sales-panel" style="display:none">
 <div class="v44-sales-title">💰 Vendas das últimas 24h</div>
 <div class="v44-sales-head"><span>Moeda</span><span>Lucro</span></div>
 <div id="v44SalesRows"></div>
</div>
<div id="v44BestSalePanel" class="card v44-best-sale-panel" style="display:none"></div>
 <div class="card"><b>🔔 Alertas do motor</b>${alerts.length?alerts.slice(0,6).map(a=>`<div class="alert tiny">${a}</div>`).join(''):'<div class="sub" style="margin-top:7px">Nenhum sinal destacado neste momento.</div>'}</div>
 <div class="card"><b>Motor</b><div class="sub">Automático: ${S.auto?'SIM':'NÃO'} • operações bloqueadas quando os dados estão desatualizados.</div>
 <div class="actions" style="margin-top:9px"><button class="primary" onclick="S.auto=!S.auto;save();render()">${S.auto?'Parar automação':'Ligar automação'}</button><button onclick="refresh()">Atualizar agora</button></div></div>
 <h2>Principais criptomoedas</h2>${tableMarket(12)}
 <h2 id="dashPositions">Posições abertas</h2>${positions(true)}
 <div class="alert tiny">Regra principal: compra apenas após análise inicial, BTC confirmado, mercado sem bloqueio, tendência 1h e 2 confirmações consecutivas. Evita entradas demasiado esticadas. Venda apenas com lucro líquido + reversão confirmada pelo trailing.</div>`
}
function dashboardResultPositions(){
 let keys=Object.keys(S.positions||{});
 if(!keys.length)return '<div class="muted">Nenhuma posição aberta.</div>';
 let totalProfit=0;
 const rows=keys.map(s=>{
   const p=S.positions[s]||{};
   const price=Number(market[s]?.last||p.entry||0);
   const qty=Number(p.qty||0);
   const currentValue=qty*price;
   const profit=qty*(price-Number(p.entry||0));
   totalProfit+=profit;
   const cls=profit>=0?'good':'bad';
   const sign=profit>=0?'+':'';
   return `<div class="v44-result-row">
     <span class="v44-coin">${s.replace('USDT','')}</span>
     <span class="v44-buy">${money(currentValue)}</span>
     <span class="v44-pnl ${cls}">${sign}${money(profit)}</span>
   </div>`;
 }).join('');
 const totalCls=totalProfit>=0?'good':'bad', totalSign=totalProfit>=0?'+':'';
 return `${rows}<div class="v44-result-total"><span>Lucro atual total</span><b class="${totalCls}">${totalSign}${money(totalProfit)}</b></div>`;
}
function positions(protectSwipe=false){
 let keys=Object.keys(S.positions);if(!keys.length)return '<div class="card muted">Sem posições.</div>';
 const swipeAttr=(protectSwipe||tab==='positions')?' data-no-tab-swipe="1"':'';
 return `<div class="card"><div class="scroll positionsSwipeArea"${swipeAttr}><table><tr><th>Ativo</th><th>Entrada</th><th>Atual</th><th>Lucro</th><th>Pico</th><th>Trail</th></tr>${
 keys.map(s=>{let p=S.positions[s],c=market[s]||{last:p.entry},g=(c.last/p.entry-1)*100,inv=p.invested||p.qty*p.entry,open=selectedPosition===s;return `<tr class="posRow${open?' posSelected':''}" data-pos="${s}" style="cursor:pointer"><td><b>${s}</b>${open?' ▾':' ▸'}</td><td>${money(p.entry)}</td><td>${money(c.last)}</td><td class="${g>=0?'good':'bad'}">${g.toFixed(2)}%</td><td>${money(p.peak)}</td><td>${p.trailArmed?'armado '+p.downCount+'/'+S.trailConfirm:'aguarda '+(p.trailActivate||S.trailActivate)+'%'}</td></tr>${open?`<tr><td colspan="6"><div class="card" style="margin:6px 0"><b>💰 ${s}</b><div class="miniGrid"><div class="mini"><span class="muted">Dinheiro investido</span><b>${money(inv)}</b></div><div class="mini"><span class="muted">Quantidade</span><b>${p.qty.toFixed(8)}</b></div><div class="mini"><span class="muted">Valor atual</span><b>${money(p.qty*c.last)}</b></div><div class="mini"><span class="muted">Lucro atual</span><b class="${g>=0?'good':'bad'}">${money(p.qty*(c.last-p.entry))}</b></div><div class="mini"><span class="muted">Lucro máximo atingido</span><b class="${(p.peakProfit||0)>=0?'good':'bad'}">${(p.peakProfit||0)>=0?'+':''}${money(p.peakProfit||0)}</b></div></div><div class="tiny muted">Entrada: ${money(p.entry)} · Pico: ${money(p.peak)}</div></div></td></tr>`:''}`}).join('')
 }</table></div></div>`
}

function history(){
 const st=tradeStats();
 const events=(S.events||[]).slice(0,40);
 const sells=st.sells.slice().reverse();
 return `<div class="card"><b>📈 Estatísticas das operações</b><div class="miniGrid" style="margin-top:9px">
 <div class="mini"><span class="muted">Operações fechadas</span><b>${sells.length}</b></div>
 <div class="mini"><span class="muted">Taxa de acerto</span><b>${st.winRate.toFixed(1)}%</b></div>
 <div class="mini"><span class="muted">Profit factor</span><b>${Number.isFinite(st.profitFactor)?st.profitFactor.toFixed(2):'∞'}</b></div>
 <div class="mini"><span class="muted">Lucro médio</span><b class="${st.avg>=0?'good':'bad'}">${money(st.avg)}</b></div>
 <div class="mini"><span class="muted">Melhor operação</span><b class="good">${money(st.best)}</b></div>
 <div class="mini"><span class="muted">Pior operação</span><b class="bad">${money(st.worst)}</b></div></div></div>
 <div class="card"><b>🧾 Histórico de vendas</b><div class="sub" style="margin:5px 0 9px">Entradas, saídas e motivos ficam registados para perceber o comportamento da estratégia.</div>${sells.length?`<div class="scroll"><table><tr><th>Hora</th><th>Moeda</th><th>Preço</th><th>Lucro</th><th>Motivo</th></tr>${sells.map(t=>{const d=new Date(t.time);return `<tr><td>${d.toLocaleDateString('pt-PT')}<br><b>${d.toLocaleTimeString('pt-PT')}</b></td><td><b>${esc(String(t.symbol||'').replace('USDT',''))}</b></td><td>${money(t.price)}</td><td class="${(t.profit||0)>=0?'good':'bad'}">${t.profit==null?'—':money(t.profit)}</td><td>${esc(t.reason||'')}</td></tr>`}).join('')}</table></div>`:'<div class="sub">Ainda não existem vendas registadas.</div>'}</div>
 <div class="card"><b>🧠 Registo de decisões</b><div class="sub" style="margin:5px 0 9px">Últimas decisões da app, incluindo bloqueios de entrada.</div>${events.length?`<div class="scroll"><table><tr><th>Hora</th><th>Evento</th><th>Detalhe</th></tr>${events.map(e=>{const d=new Date(e.time);return `<tr><td>${d.toLocaleTimeString('pt-PT')}</td><td>${eventLabel(e)}</td><td>${esc(e.reason||'')}</td></tr>`}).join('')}</table></div>`:'<div class="sub">Ainda não há eventos.</div>'}</div>`;
}
function backtest(){
 return `<div class="card"><b>🧪 Backtest detalhado</b><p class="sub">Simula o histórico disponível com capital, alocação, reserva, taxas, slippage, score e trailing configurados atualmente. O modo live usa as regras atuais de tendência 1h, filtro BTC e regime de mercado; o backtest apresenta estes componentes separadamente quando não é possível reproduzi-los exatamente no histórico local.</p>
 <label>Ativo</label><select id="bt">${symbols.map(s=>`<option>${s}</option>`).join('')}</select>
 <div class="actions" style="margin-top:8px"><button class="primary" onclick="runBT()">Executar</button></div><div id="btout"></div></div>`
}
async function runBT(){
 let s=document.getElementById('bt').value,out=document.getElementById('btout');out.innerHTML='<p class="muted">A processar...</p>';
 try{
  let c=candles[s]||await jget(`klines?symbol=${s}&interval=1h&limit=${Math.min(S.lookback,500)}`);
  let cash=S.capital,pos=null,tr=[],equityCurve=[],peakEq=S.capital,maxDD=0,fees=0,blocked=0;
  for(let i=80;i<c.length;i++){
   let slice=c.slice(0,i+1), q=score(slice), price=+c[i][4];
   if(!pos){
    if(q.score>=S.minScore){
      let budget=Math.min(S.capital*S.alloc/100,cash-S.capital*S.reserve/100,S.capital*S.maxPerAsset/100);
      if(budget>0){const fee=budget*S.fee/100,slip=price*S.slip/100,entry=price+slip;cash-=budget;fees+=fee;pos={qty:(budget-fee)/entry,entry,peak:entry,armed:false,down:0};}
      else blocked++;
    }else blocked++;
   }else{
    if(price>pos.peak){pos.peak=price;pos.down=0}
    if((price/pos.entry-1)*100>=S.trailActivate)pos.armed=true;
    if(pos.armed&&price<=pos.peak*(1-S.trailDrop/100))pos.down++;else if(price>pos.peak*(1-S.trailDrop/100))pos.down=0;
    if(pos.armed&&pos.down>=S.trailConfirm&&price>threshold(pos)){
      let gross=pos.qty*price,fee=gross*S.fee/100,slip=gross*S.slip/100,net=gross-fee-slip;cash+=net;fees+=fee+slip;tr.push(net-pos.qty*pos.entry);pos=null;
    }
   }
   const eq=cash+(pos?pos.qty*price:0);equityCurve.push(eq);peakEq=Math.max(peakEq,eq);maxDD=Math.max(maxDD,(peakEq-eq)/peakEq*100);
  }
  if(pos){const price=+c.at(-1)[4],gross=pos.qty*price,fee=gross*S.fee/100,slip=gross*S.slip/100;cash+=gross-fee-slip;fees+=fee+slip;tr.push((gross-fee-slip)-pos.qty*pos.entry);pos=null;}
  let end=cash,wins=tr.filter(x=>x>0),losses=tr.filter(x=>x<0),realized=tr.reduce((a,v)=>a+v,0),grossWin=wins.reduce((a,v)=>a+v,0),grossLoss=Math.abs(losses.reduce((a,v)=>a+v,0)),pf=grossLoss?grossWin/grossLoss:(grossWin?Infinity:0);
  out.innerHTML=`<div class="alert"><b>Resultado simulado</b><div class="miniGrid" style="margin-top:8px"><div class="mini"><span class="muted">Capital final</span><b>${money(end)}</b></div><div class="mini"><span class="muted">Retorno</span><b class="${end>=S.capital?'good':'bad'}">${pct(end/S.capital-1)}</b></div><div class="mini"><span class="muted">Trades</span><b>${tr.length}</b></div><div class="mini"><span class="muted">Acerto</span><b>${tr.length?(wins.length/tr.length*100).toFixed(1):'0'}%</b></div><div class="mini"><span class="muted">Profit factor</span><b>${Number.isFinite(pf)?pf.toFixed(2):'∞'}</b></div><div class="mini"><span class="muted">Drawdown máx.</span><b>${maxDD.toFixed(2)}%</b></div></div><div class="tiny muted" style="margin-top:8px">Lucro líquido: ${money(realized)} · Custos simulados: ${money(fees)} · Períodos sem entrada: ${blocked}</div></div>`;
 }catch(e){out.innerHTML='<div class="alert bad">'+esc(e.message)+'</div>'}
}
function config(){
 let fields=[['capital','Capital'],['dip','Queda 24h mínima'],['target','Lucro mínimo'],['alloc','Alocação por compra'],['maxExposure','Exposição máxima'],['reserve','Reserva'],['fee','Taxa'],['slip','Slippage'],['trailActivate','Ativar trailing com lucro'],['trailDrop','Recuo desde pico'],['reversalDrop','Recuo de proteção desde pico (%)'],['reversalConfirm','Confirmações de proteção'],['trailConfirm','Confirmações'],['maxPositions','Máx. posições'],['maxPerAsset','Máx. por ativo'],['minScore','Score mínimo'],['partialSell1','1ª venda %'],['partialSell2','2ª venda %'],['lookback','Velas']];
 return `<div class="card"><b>🟠 BTC bearish (%)</b><div class="sub" style="margin:5px 0 9px">Percentagem de queda do BTC nos últimos 3 minutos que bloqueia novas compras. O valor por defeito mantém-se em 3%.</div><label>BTC bearish 3 min (%)<input data-k="btcBearishPct" type="number" min="0.1" max="50" step="0.1" value="${Math.max(0.1,Number(S.btcBearishPct??3))}"></label></div>
 <div class="card">${fields.map(([k,l])=>`<label>${l}<input data-k="${k}" type="number" step="0.1" value="${S[k]}"></label>`).join('')}
 <div class="actions" style="margin-top:10px"><button class="primary" onclick="saveCfg()">Guardar configuração</button><button onclick="exportData()">Exportar memória</button><button onclick="resetAll()">Reset</button></div></div>
 `
}
function saveCfg(){document.querySelectorAll('[data-k]').forEach(i=>S[i.dataset.k]=+i.value);save();render()}
function exportData(){let b=new Blob([JSON.stringify(S,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='cryptotrader-v4.4-memory.json';a.click()}
function resetAll(){if(confirm('Apagar posições, histórico e estado?')){localStorage.removeItem('ct_v3_state');location.reload()}}
let tabSwipeBound=false;
function bindTabSwipe(){
 if(tabSwipeBound)return;
 tabSwipeBound=true;
 let x0=0,y0=0,tracking=false,inPositionsScroll=false;
 const tabs=['dash','market','positions','history','backtest','config'];
 document.addEventListener('touchstart',e=>{
   if(!e.changedTouches.length)return;
   const t=e.changedTouches[0];
   x0=t.clientX;y0=t.clientY;
   inPositionsScroll=!!e.target.closest?.('[data-no-tab-swipe="1"]');
   tracking=true;
 },{passive:true});
 document.addEventListener('touchend',e=>{
   if(!tracking||!e.changedTouches.length)return;
   tracking=false;
   const t=e.changedTouches[0];
   const dx=t.clientX-x0,dy=t.clientY-y0;
   const horizontal=Math.abs(dx)>Math.abs(dy)*1.25;
   // Na área das moedas expostas da página Posições, a navegação entre páginas
   // só acontece com um gesto que percorra quase todo o ecrã. O scroll horizontal
   // da própria tabela continua disponível normalmente.
   const protectedArea=e.target.closest?.('[data-no-tab-swipe="1"]');
   if(e.target.closest?.('[data-disable-tab-swipe="1"]'))return;
   const threshold=protectedArea
     ? Math.max(0,window.innerWidth*(Number(protectedArea.dataset.swipeThreshold)||0.50))
     : 70;
   if(!horizontal || Math.abs(dx)<threshold)return;
   const i=tabs.indexOf(tab);
   // Navegação circular: ao chegar ao fim, continua no início, e vice-versa.
   const ni=dx<0?(i+1)%tabs.length:(i-1+tabs.length)%tabs.length;
   if(ni!==i){tab=tabs[ni];render();window.scrollTo({top:0,behavior:'smooth'});}
 });
}
function render(){
 let html=tab==='dash'?dashboard():tab==='market'?tableMarket():tab==='positions'?positions():tab==='history'?history():tab==='backtest'?backtest():config();
 document.getElementById('app').innerHTML=html;
 bindCharts();
 bindTabSwipe();
 const marketSearchBtn=document.getElementById('marketSearchBtn');
 if(marketSearchBtn){marketSearchBtn.onclick=()=>{
   marketSearchOpen=true;
   render();
   requestAnimationFrame(()=>{
     const input=document.getElementById('marketSearchInput');
     if(input){input.focus();input.select();}
   });
 };}
 const marketSearchInput=document.getElementById('marketSearchInput');
 if(marketSearchInput){
   marketSearchInput.oninput=()=>{marketSearch=marketSearchInput.value;render();requestAnimationFrame(()=>{const i=document.getElementById('marketSearchInput');if(i){i.focus();i.setSelectionRange(i.value.length,i.value.length);}});};
   marketSearchInput.onkeydown=(e)=>{if(e.key==='Escape'){marketSearch='';marketSearchOpen=false;render();}};
 }
 const marketSearchClear=document.getElementById('marketSearchClear');
 if(marketSearchClear){marketSearchClear.onclick=()=>{marketSearch='';marketSearchOpen=false;render();};}
 document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 document.querySelectorAll('[data-pos]').forEach(r=>r.onclick=()=>{selectedPosition=selectedPosition===r.dataset.pos?null:r.dataset.pos;render()});
 document.querySelectorAll('[data-goto-positions]').forEach(el=>el.onclick=()=>goToDashboardPositions());
 const resultCard=document.querySelector('[data-toggle-result-positions]');
 if(resultCard){
   resultCard.onclick=()=>{
     const box=document.getElementById('dashboardResultPositions');
     if(box)box.style.display=box.style.display==='none'?'block':'none';
   };
 }
}
function goToDashboardPositions(){
 const target=document.getElementById('dashPositions');
 if(!target)return;
 const y=target.getBoundingClientRect().top+window.pageYOffset-92;
 window.scrollTo({top:Math.max(0,y),behavior:'smooth'});
}
document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;render()});
render();refresh();
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&S.auto)refresh()});
function updateNetworkStatus(){
 const el=document.getElementById('netStatus');
 if(!el)return;
 const online=navigator.onLine;
 el.classList.toggle('online',online);
 const txt=el.querySelector('.netText');
 if(txt)txt.textContent=online?'Internet':'Sem Internet';
 el.title=online?'Ligado à Internet':'Sem ligação à Internet';
}
window.addEventListener('online',updateNetworkStatus);
window.addEventListener('offline',updateNetworkStatus);
updateNetworkStatus();

let wakeLock=null;
async function requestWakeLock(){try{if('wakeLock'in navigator)wakeLock=await navigator.wakeLock.request('screen')}catch(e){}}
document.addEventListener('pointerdown',()=>requestWakeLock(),{once:true});

