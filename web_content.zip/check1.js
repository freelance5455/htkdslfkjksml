
/* Independent To-do List module: intentionally isolated from the rest of WildNotes. */
(function () {
  'use strict';
  function initTodo() {
    const byId = id => document.getElementById(id);
    const navButton = document.querySelector('.navbtn[data-page="stickies"]');
    const page = byId('stickies');
    const form = byId('todoForm');
    const input = byId('todoInput');
    const list = byId('todoList');
    const progress = byId('todoProgress');
    const addButton = byId('addTodo');
    const clearButton = byId('clearCompletedTodos');
    if (!page || !form || !input || !list || !progress || !addButton || !clearButton) return;

    const storageKey = 'wildnotes_todo_list_v2';
    let tasks = [];
    try {
      const saved = localStorage.getItem(storageKey) || localStorage.getItem('wildnotes_todo_list_v1') || '[]';
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) tasks = parsed.filter(t => t && typeof t.text === 'string').map(t => ({
        id: String(t.id || (Date.now().toString(36) + Math.random().toString(36).slice(2))),
        text: t.text, done: Boolean(t.done)
      }));
    } catch (_) { tasks = []; }

    function save() {
      try { localStorage.setItem(storageKey, JSON.stringify(tasks)); }
      catch (_) {
        try { sessionStorage.setItem(storageKey, JSON.stringify(tasks)); }
        catch (__) { /* Keep the list usable for this session even if storage is blocked. */ }
      }
    }
    function render() {
      list.replaceChildren();
      const completed = tasks.filter(t => t.done).length;
      progress.textContent = completed + ' of ' + tasks.length + ' tasks completed';
      if (!tasks.length) {
        const empty = document.createElement('div');
        empty.className = 'todo-empty';
        empty.textContent = 'Your list is empty. Add your first task above.';
        list.append(empty);
        return;
      }
      tasks.forEach(task => {
        const row = document.createElement('div');
        row.className = 'todo-row' + (task.done ? ' done' : '');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox'; checkbox.checked = task.done;
        checkbox.setAttribute('aria-label', 'Mark task complete: ' + task.text);
        checkbox.addEventListener('change', () => { task.done = checkbox.checked; save(); render(); });
        const label = document.createElement('span');
        label.className = 'todo-label'; label.textContent = task.text;
        const edit = document.createElement('button');
        edit.type = 'button'; edit.className = 'secondary small'; edit.textContent = 'Edit';
        edit.addEventListener('click', () => {
          const updated = window.prompt('Edit task', task.text);
          if (updated !== null && updated.trim()) { task.text = updated.trim(); save(); render(); }
        });
        const remove = document.createElement('button');
        remove.type = 'button'; remove.className = 'danger small'; remove.textContent = 'Delete';
        remove.addEventListener('click', () => { tasks = tasks.filter(t => t.id !== task.id); save(); render(); });
        row.append(checkbox, label, edit, remove); list.append(row);
      });
    }
    function addTask(text) {
      const clean = String(text || '').trim();
      if (!clean) { input.focus(); return; }
      tasks.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2), text: clean, done: false });
      save(); render(); input.value = ''; input.focus();
    }
    form.addEventListener('submit', event => { event.preventDefault(); addTask(input.value); });
    addButton.addEventListener('click', () => { input.focus(); if (input.value.trim()) addTask(input.value); });
    clearButton.addEventListener('click', () => { tasks = tasks.filter(t => !t.done); save(); render(); });

    // Navigation is handled by the main WildNotes controller to avoid competing page states.
    render();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initTodo, { once: true });
  else initTodo();
})();
