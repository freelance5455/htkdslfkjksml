# Car Jam Solver – Android (WebView) project

The whole game lives in `app/src/main/assets/index.html`. This project wraps it in a fullscreen Android app.

## Way 1 – build the APK from your phone (no computer needed)
1. Create a free GitHub account and a new repository.
2. Upload ALL files/folders of this project (keep the folder structure, including the hidden `.github` folder).
3. Open the repository's **Actions** tab -> **Build APK** -> **Run workflow** (it also runs automatically on every upload).
4. When the run turns green, open it and download **CarJamSolver-APK** (a zip containing `app-debug.apk`).
5. Extract it, open `app-debug.apk` on your phone and allow "install from unknown sources".

## Way 2 – Android Studio
1. Install Android Studio, choose **Open**, and select this folder.
2. Let Gradle sync (it downloads what it needs).
3. For offline play: download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js into `app/src/main/assets/` and in `index.html` change the `<script src="https://cdnjs...three.min.js">` to `<script src="three.min.js">`.
4. **Build -> Build APK(s)**, or press Run with a phone connected.

Package name: `com.carjam.solver`. Progress is saved in the app's local storage.
