# IBS CHEANG MAJESTIC — DRA Recovery System

A starter full-stack web application based on the uploaded HTML prototype.

## Features
- Admin and Agent login with role-based API permissions
- PostgreSQL persistent storage (SQLite fallback for local evaluation)
- Customer / NPA account management
- Visit scheduling and visit-status updates
- Dashboard and date-filtered recovery reports
- Excel/CSV import and CSV export
- Responsive browser UI for desktop and mobile

## Important limitations
This is a functional starter project, not a security-audited banking product. Before real customer/loan data is entered, deploy behind HTTPS, change all secrets and default credentials, configure backups, add audit/retention policies, and obtain your organization's security/privacy approval. Do not use real customer data in a public demo. The app does not connect to any bank system, payment gateway, GPS service, or mapping provider.

## Quick start (Docker recommended)
1. Install Docker Desktop / Docker Engine and Docker Compose.
2. Copy `.env.example` to `.env`.
3. Change `SECRET_KEY`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD` in `.env`. If changing the database password, update both `POSTGRES_PASSWORD` and the password inside `DATABASE_URL` to match.
4. Run:
   ```bash
   docker compose up --build
   ```
5. Open `http://localhost:8000`.
6. Sign in using the admin credentials from `.env`. Create agent accounts in the Users page.

## Local Python setup (without Docker)
Python 3.11+ recommended.
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
By default, local mode uses SQLite at `./dra.db`. Set `DATABASE_URL` to a PostgreSQL URL for PostgreSQL.

## Excel import format
The first worksheet should have a header row. Supported columns include:
- Customer Name / Name
- Phone / Mobile
- Bank / Bank Name
- Account Reference / Account Number
- NPA Date
- Overdue Amount / Amount
- Zone (Red, Orange, Green)
- Visit Status (Pending, Scheduled, Visited, Revisit)
- Address / Area
- Notes
- Next Follow-up

Example template is included as `customer_import_template.csv`.

## API overview
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET|POST /api/customers`
- `GET|PUT|DELETE /api/customers/{id}`
- `GET|POST /api/visits`
- `PUT /api/visits/{id}`
- `GET /api/reports/summary?date=YYYY-MM-DD`
- `POST /api/import`
- `GET /api/export.csv`
- `GET|POST /api/users` (Admin only)
- `GET /health`

## Production checklist
- HTTPS/TLS termination and secure headers
- Strong unique secrets and password policy
- Configure PostgreSQL backups and restore tests
- Add audit logs and data-retention rules
- Rate-limit login and review session/token expiry
- Restrict network access and configure firewall
- Review legal basis, customer consent/notice, and organization policy
- Have an independent security review before real deployment
