@echo off
setlocal
cd /d "%~dp0"
title IBS CHEANG MAJESTIC DRA - Setup and Start

echo ======================================================
echo   IBS CHEANG MAJESTIC - DRA Recovery System
echo   First run may take a few minutes.
echo ======================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
  set "PYTHON=py -3"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    set "PYTHON=python"
  ) else (
    echo Python was not found on this computer.
    echo Please install Python 3.11 or newer from https://www.python.org/downloads/windows/
    echo During installation, tick the box: Add python.exe to PATH.
    echo Then double-click this file again.
    pause
    exit /b 1
  )
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Creating the app environment...
  %PYTHON% -m venv .venv
  if errorlevel 1 goto failed
)

echo [2/3] Installing or updating app packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed

if not exist ".env" (
  echo [3/3] Preparing local settings and database...
  > .env echo DATABASE_URL=sqlite:///./dra.db
  >> .env echo SECRET_KEY=local-only-change-before-hosting-7b5c3f9a-4d62-4d1a-9f18
  >> .env echo ADMIN_USERNAME=admin
  >> .env echo ADMIN_PASSWORD=ChangeThisAdminPassword123!
  >> .env echo ACCESS_TOKEN_MINUTES=480
) else (
  echo Existing .env settings found; leaving them unchanged.
)

echo.
echo Starting DRA application...
echo Browser address: http://127.0.0.1:8000
echo Login username: admin
echo Initial password: ChangeThisAdminPassword123!
echo IMPORTANT: Change the password before real use. Keep this window open while using the app.
echo To stop the app, close this window or press Ctrl+C.
start "DRA App" http://127.0.0.1:8000
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
if errorlevel 1 goto failed
exit /b 0

:failed
echo.
echo Setup could not finish. Check your internet connection and Python installation.
echo If port 8000 is already in use, close the other app and try again.
pause
exit /b 1
