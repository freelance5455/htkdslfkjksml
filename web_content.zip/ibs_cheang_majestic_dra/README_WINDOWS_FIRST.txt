START HERE — WINDOWS USERS

You do not need to type commands manually.
1. Extract this ZIP to a folder.
2. Install Python 3.11+ (https://www.python.org/downloads/windows/) and tick “Add python.exe to PATH”.
3. Double-click INSTALL_AND_START.bat.
4. Wait for setup; browser opens at http://127.0.0.1:8000.
5. Login: admin / ChangeThisAdminPassword123!
6. Keep the black command window open while using the app.

Read EASY_START_GUIDE.txt for more details and important security notes.
