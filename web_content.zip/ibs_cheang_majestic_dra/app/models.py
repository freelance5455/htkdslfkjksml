from sqlalchemy import String, Integer, Float, Date, DateTime, ForeignKey, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="Agent")
    active: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[object] = mapped_column(DateTime, server_default=func.now())

class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    phone: Mapped[str] = mapped_column(String(40), default="")
    bank: Mapped[str] = mapped_column(String(120), default="Unknown")
    account_ref: Mapped[str] = mapped_column(String(120), default="")
    npa_date: Mapped[object] = mapped_column(Date, nullable=True)
    amount: Mapped[float] = mapped_column(Float, default=0)
    zone: Mapped[str] = mapped_column(String(20), default="Orange")
    status: Mapped[str] = mapped_column(String(30), default="Pending")
    address: Mapped[str] = mapped_column(Text, default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    followup: Mapped[object] = mapped_column(Date, nullable=True)
    assigned_to: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[object] = mapped_column(DateTime, server_default=func.now())
    visits = relationship("Visit", back_populates="customer", cascade="all, delete-orphan")

class Visit(Base):
    __tablename__ = "visits"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id", ondelete="CASCADE"), index=True)
    visit_date: Mapped[object] = mapped_column(Date, index=True)
    status: Mapped[str] = mapped_column(String(30), default="Scheduled")
    notes: Mapped[str] = mapped_column(Text, default="")
    next_followup: Mapped[object] = mapped_column(Date, nullable=True)
    agent_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[object] = mapped_column(DateTime, server_default=func.now())
    customer = relationship("Customer", back_populates="visits")
