import os, csv, io, secrets
from datetime import date, datetime, timedelta
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Query
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from pydantic import BaseModel, Field
from openpyxl import load_workbook
from dotenv import load_dotenv
from .db import Base, engine, get_db, SessionLocal
from .models import User, Customer, Visit

load_dotenv()
SECRET_KEY = os.getenv("SECRET_KEY", "development-only-change-me")
ALGORITHM = "HS256"
TOKEN_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "480"))
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2 = OAuth2PasswordBearer(tokenUrl="/api/auth/login")
app = FastAPI(title="IBS CHEANG MAJESTIC DRA", version="1.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
Base.metadata.create_all(bind=engine)

def seed_admin():
    db = SessionLocal()
    try:
        username = os.getenv("ADMIN_USERNAME", "admin")
        password = os.getenv("ADMIN_PASSWORD", "ChangeThisAdminPassword123!")
        if not db.scalar(select(User).where(User.username == username)):
            db.add(User(username=username, password_hash=pwd.hash(password), role="Admin", active=1))
            db.commit()
    finally:
        db.close()
seed_admin()

def token_for(user):
    return jwt.encode({"sub": str(user.id), "role": user.role, "exp": datetime.utcnow()+timedelta(minutes=TOKEN_MINUTES)}, SECRET_KEY, algorithm=ALGORITHM)

def current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        uid = int(payload.get("sub", "0"))
    except (JWTError, ValueError):
        raise HTTPException(401, "Invalid or expired login token")
    user = db.get(User, uid)
    if not user or not user.active:
        raise HTTPException(401, "User is inactive")
    return user

def admin_only(user=Depends(current_user)):
    if user.role != "Admin":
        raise HTTPException(403, "Admin access required")
    return user

def parse_date(v):
    if not v or str(v).strip() in ("", "None"): return None
    if isinstance(v, datetime): return v.date()
    if isinstance(v, date): return v
    s = str(v).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y"):
        try: return datetime.strptime(s[:10], fmt).date()
        except ValueError: pass
    try:
        if isinstance(v, (int, float)):
            from openpyxl.utils.datetime import from_excel
            return from_excel(v).date()
    except Exception: pass
    return None

def customer_dict(c):
    return {"id":c.id,"name":c.name,"phone":c.phone,"bank":c.bank,"account_ref":c.account_ref,
            "npa_date":c.npa_date.isoformat() if c.npa_date else None,"amount":c.amount,"zone":c.zone,
            "status":c.status,"address":c.address,"notes":c.notes,
            "followup":c.followup.isoformat() if c.followup else None,"assigned_to":c.assigned_to}

class LoginBody(BaseModel):
    username: str
    password: str
class CustomerBody(BaseModel):
    name: str = Field(min_length=1, max_length=180)
    phone: str = ""
    bank: str = "Unknown"
    account_ref: str = ""
    npa_date: Optional[date] = None
    amount: float = Field(default=0, ge=0)
    zone: str = "Orange"
    status: str = "Pending"
    address: str = ""
    notes: str = ""
    followup: Optional[date] = None
    assigned_to: Optional[int] = None
class VisitBody(BaseModel):
    customer_id: int
    visit_date: date
    status: str = "Scheduled"
    notes: str = ""
    next_followup: Optional[date] = None
    agent_id: Optional[int] = None
class UserBody(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=10)
    role: str = "Agent"

@app.get("/", response_class=HTMLResponse)
def home():
    with open("static/index.html", encoding="utf-8") as f: return f.read()

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/api/auth/login")
def login(body: LoginBody, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == body.username))
    if not user or not user.active or not pwd.verify(body.password, user.password_hash):
        raise HTTPException(401, "Incorrect username or password")
    return {"access_token":token_for(user),"token_type":"bearer","user":{"id":user.id,"username":user.username,"role":user.role}}

@app.get("/api/auth/me")
def me(user=Depends(current_user)):
    return {"id":user.id,"username":user.username,"role":user.role}

@app.get("/api/users")
def users(db: Session=Depends(get_db), admin=Depends(admin_only)):
    return [{"id":u.id,"username":u.username,"role":u.role,"active":bool(u.active)} for u in db.scalars(select(User).order_by(User.username)).all()]

@app.post("/api/users")
def create_user(body: UserBody, db: Session=Depends(get_db), admin=Depends(admin_only)):
    if body.role not in ("Admin","Agent"): raise HTTPException(400,"Role must be Admin or Agent")
    if db.scalar(select(User).where(User.username==body.username)): raise HTTPException(409,"Username already exists")
    u=User(username=body.username,password_hash=pwd.hash(body.password),role=body.role,active=1)
    db.add(u); db.commit(); db.refresh(u)
    return {"id":u.id,"username":u.username,"role":u.role}

@app.get("/api/customers")
def list_customers(q: str="", bank: str="", zone: str="", status: str="", db: Session=Depends(get_db), user=Depends(current_user)):
    stmt=select(Customer)
    if q: stmt=stmt.where((Customer.name.ilike(f"%{q}%")) | (Customer.phone.ilike(f"%{q}%")) | (Customer.account_ref.ilike(f"%{q}%")) | (Customer.bank.ilike(f"%{q}%")))
    if bank: stmt=stmt.where(Customer.bank==bank)
    if zone: stmt=stmt.where(Customer.zone==zone)
    if status: stmt=stmt.where(Customer.status==status)
    if user.role != "Admin": stmt=stmt.where((Customer.assigned_to==user.id) | (Customer.assigned_to==None))
    return [customer_dict(c) for c in db.scalars(stmt.order_by(Customer.id.desc())).all()]

@app.post("/api/customers")
def add_customer(body: CustomerBody, db: Session=Depends(get_db), user=Depends(current_user)):
    data=body.model_dump()
    if user.role!="Admin": data["assigned_to"]=user.id
    if data["zone"] not in ("Red","Orange","Green"): raise HTTPException(400,"Invalid zone")
    if data["status"] not in ("Pending","Scheduled","Visited","Revisit"): raise HTTPException(400,"Invalid status")
    c=Customer(**data); db.add(c); db.commit(); db.refresh(c)
    return customer_dict(c)

@app.get("/api/customers/{cid}")
def get_customer(cid: int, db: Session=Depends(get_db), user=Depends(current_user)):
    c=db.get(Customer,cid)
    if not c: raise HTTPException(404,"Customer not found")
    if user.role!="Admin" and c.assigned_to not in (None,user.id): raise HTTPException(403,"Not assigned to you")
    return customer_dict(c)

@app.put("/api/customers/{cid}")
def edit_customer(cid: int, body: CustomerBody, db: Session=Depends(get_db), user=Depends(current_user)):
    c=db.get(Customer,cid)
    if not c: raise HTTPException(404,"Customer not found")
    if user.role!="Admin" and c.assigned_to not in (None,user.id): raise HTTPException(403,"Not assigned to you")
    for k,v in body.model_dump().items(): setattr(c,k,v)
    db.commit(); db.refresh(c); return customer_dict(c)

@app.delete("/api/customers/{cid}")
def delete_customer(cid: int, db: Session=Depends(get_db), admin=Depends(admin_only)):
    c=db.get(Customer,cid)
    if not c: raise HTTPException(404,"Customer not found")
    db.delete(c); db.commit(); return {"ok":True}

@app.get("/api/visits")
def visits(on_date: Optional[date]=None, db: Session=Depends(get_db), user=Depends(current_user)):
    stmt=select(Visit,Customer).join(Customer,Visit.customer_id==Customer.id)
    if on_date: stmt=stmt.where(Visit.visit_date==on_date)
    if user.role!="Admin": stmt=stmt.where((Customer.assigned_to==user.id)|(Customer.assigned_to==None))
    return [{"id":v.id,"customer_id":c.id,"customer":c.name,"address":c.address,"phone":c.phone,
             "visit_date":v.visit_date.isoformat(),"status":v.status,"notes":v.notes,
             "next_followup":v.next_followup.isoformat() if v.next_followup else None} for v,c in db.execute(stmt.order_by(Visit.visit_date)).all()]

@app.post("/api/visits")
def add_visit(body: VisitBody, db: Session=Depends(get_db), user=Depends(current_user)):
    c=db.get(Customer,body.customer_id)
    if not c: raise HTTPException(404,"Customer not found")
    if user.role!="Admin" and c.assigned_to not in (None,user.id): raise HTTPException(403,"Not assigned to you")
    v=Visit(**body.model_dump(),agent_id=user.id if user.role!="Admin" else body.agent_id)
    db.add(v); c.status=body.status; c.followup=body.next_followup; db.commit(); db.refresh(v)
    return {"id":v.id,"status":v.status}

@app.put("/api/visits/{vid}")
def update_visit(vid:int, status:str=Query(...), notes:str="", next_followup:Optional[date]=None, db:Session=Depends(get_db), user=Depends(current_user)):
    v=db.get(Visit,vid)
    if not v: raise HTTPException(404,"Visit not found")
    if user.role!="Admin" and v.customer.assigned_to not in (None,user.id): raise HTTPException(403,"Not assigned to you")
    if status not in ("Pending","Scheduled","Visited","Revisit"): raise HTTPException(400,"Invalid status")
    v.status=status; v.notes=notes; v.next_followup=next_followup; v.customer.status=status; v.customer.followup=next_followup
    db.commit(); return {"ok":True}

@app.get("/api/reports/summary")
def summary(on_date: Optional[date]=Query(None, alias="date"), db:Session=Depends(get_db), user=Depends(current_user)):
    today=on_date or date.today()
    stmt=select(Customer)
    if user.role!="Admin": stmt=stmt.where((Customer.assigned_to==user.id)|(Customer.assigned_to==None))
    cs=db.scalars(stmt).all()
    total=sum(float(c.amount or 0) for c in cs)
    vstmt=select(Visit).where(Visit.visit_date==today)
    if user.role!="Admin": vstmt=vstmt.join(Customer).where((Customer.assigned_to==user.id)|(Customer.assigned_to==None))
    vs=db.scalars(vstmt).all()
    return {"date":today.isoformat(),"accounts":len(cs),"overdue":total,"visited":sum(c.status=="Visited" for c in cs),
            "pending":sum(c.status!="Visited" for c in cs),"today_visits":len(vs),
            "completed_today":sum(v.status=="Visited" for v in vs),
            "zones":{z:sum(c.zone==z for c in cs) for z in ("Red","Orange","Green")}}

@app.post("/api/import")
async def import_customers(file: UploadFile=File(...), db:Session=Depends(get_db), user=Depends(current_user)):
    content=await file.read()
    try:
        if file.filename.lower().endswith(".csv"):
            rows=list(csv.DictReader(io.StringIO(content.decode("utf-8-sig"))))
        else:
            wb=load_workbook(io.BytesIO(content),read_only=True,data_only=True)
            ws=wb.active
            data=list(ws.iter_rows(values_only=True))
            if not data: raise ValueError("Empty workbook")
            headers=[str(x or "").strip() for x in data[0]]
            rows=[dict(zip(headers,row)) for row in data[1:]]
    except Exception as e: raise HTTPException(400,f"Could not read file: {e}")
    def norm(x): return "".join(ch.lower() for ch in str(x) if ch.isalnum())
    count=0
    for r in rows:
        rr={norm(k):v for k,v in r.items()}
        def pick(*keys):
            for k in keys:
                if k in rr and rr[k] is not None: return rr[k]
            return ""
        name=str(pick("customername","name","borrowername","customer")).strip()
        if not name: continue
        zone=str(pick("zone","riskzone","priority") or "Orange").replace(" Zone","").title()
        if zone not in ("Red","Orange","Green"): zone="Orange"
        status=str(pick("visitstatus","status","recoveryStatus".lower()) or "Pending").title()
        if status not in ("Pending","Scheduled","Visited","Revisit"): status="Pending"
        amount=str(pick("overdueamount","amount","outstandingamount","overdue") or "0").replace("₹","").replace(",","").strip()
        try: amount=float(amount or 0)
        except ValueError: amount=0
        c=Customer(name=name,phone=str(pick("phone","phonenumber","mobile","mobilenumber") or ""),
            bank=str(pick("bank","bankname","financecompany","institution") or "Unknown"),
            account_ref=str(pick("accountreference","account","accountno","accountnumber","loanaccountnumber") or ""),
            npa_date=parse_date(pick("npadate","dateofnpa","npa")),amount=max(0,amount),zone=zone,status=status,
            address=str(pick("address","customeraddress","location","area") or ""),notes=str(pick("notes","remarks","visitnotes") or ""),
            followup=parse_date(pick("nextfollowup","followup","followupdate")),assigned_to=user.id if user.role!="Admin" else None)
        db.add(c); count+=1
    if count==0: raise HTTPException(400,"No customer names found. Check the import template.")
    db.commit()
    return {"imported":count}

@app.get("/api/export.csv")
def export_csv(db:Session=Depends(get_db), user=Depends(current_user)):
    stmt=select(Customer).order_by(Customer.id)
    if user.role!="Admin": stmt=stmt.where((Customer.assigned_to==user.id)|(Customer.assigned_to==None))
    cs=db.scalars(stmt).all()
    buf=io.StringIO()
    writer=csv.writer(buf)
    writer.writerow(["Customer Name","Phone","Bank","Account Reference","NPA Date","Overdue Amount","Zone","Visit Status","Address","Notes","Next Follow-up"])
    for c in cs: writer.writerow([c.name,c.phone,c.bank,c.account_ref,c.npa_date or "",c.amount,c.zone,c.status,c.address,c.notes,c.followup or ""])
    data="\ufeff"+buf.getvalue()
    return StreamingResponse(iter([data]),media_type="text/csv; charset=utf-8",headers={"Content-Disposition":"attachment; filename=ibs-dra-customers.csv"})
