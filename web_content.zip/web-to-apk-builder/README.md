# Web-to-APK Builder Pro

**Fully unlocked • Client-side • Production-ready**

A modern web application that converts any website URL, local HTML/CSS/JS, or ZIP web bundle into a complete, ready-to-open **Android Studio / Gradle project** (ZIP).

No server required. Everything runs in your browser.

---

## Features

### Source Input (3 modes)
- **Website URL** – Wrap any live website in a native WebView
- **ZIP Upload** – Drag & drop a web project (must contain `index.html`)
- **Built-in Code Editor** – Write HTML + CSS + JS with live preview

### App Configuration
- App Name / Short Name
- Package Name (validated)
- Version Name + Version Code
- Custom App Icon → automatically generates all mipmap densities (mdpi → xxxhdpi)

### Advanced WebView Settings (all free)
- JavaScript on/off
- DOM Storage / LocalStorage
- Zoom controls & Pinch-to-zoom
- Pull-to-Refresh
- Fullscreen mode
- Hardware acceleration
- Orientation lock (portrait / landscape / sensor)
- Custom User-Agent
- Custom CSS & JavaScript injection

### Permissions
- Internet
- Camera + Microphone
- Geolocation
- Storage
- Vibration

### Splash & Offline
- Custom splash background color
- Splash duration (1–5 s)
- Optional splash logo
- Offline fallback HTML page

### Output
- Complete Android Studio project structure
- Valid `build.gradle`, `AndroidManifest.xml`, `MainActivity.java`
- Proper assets injection
- Network security config
- Ready to Sync & Run

---

## How to use

1. Open `index.html` in any modern browser (Chrome / Edge / Firefox recommended).
2. Choose source type (URL / ZIP / Editor).
3. Fill App Configuration + permissions + advanced settings.
4. Click **Generate Android Studio ZIP**.
5. Extract the downloaded ZIP.
6. Open the folder in **Android Studio**.
7. Wait for Gradle Sync → Run on device/emulator.

---

## Requirements for the generated project

- Android Studio Hedgehog (2023.1.1) or newer recommended
- JDK 17
- Min SDK 24 / Target SDK 34

---

## Project Structure (this web tool)

```
web-to-apk-builder/
├── index.html          # Main UI (Tailwind + modern dark theme)
├── app.js              # Frontend logic, tabs, validation, state
├── builder.js          # Core ZIP generation engine
├── styles.css          # Custom styles & animations
└── README.md           # This file
```

---

## Notes

- All “Pro” features are unlocked by default.
- No data is uploaded anywhere – 100% client-side (JSZip + FileSaver).
- You can later add a paywall / license check if you want to commercialize it.
- The generated `MainActivity.java` includes:
  - Full WebViewClient + WebChromeClient
  - File upload support
  - Geolocation permission handling
  - Back-button navigation
  - Splash screen transition
  - Custom CSS/JS injection
  - Offline fallback

---

## License

Free to use for personal and commercial projects.  
You own the generated Android projects completely.

---

Made with ❤️ for developers who want a fast Web → APK pipeline.
