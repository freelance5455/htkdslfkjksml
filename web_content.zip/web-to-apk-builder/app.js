/**
 * Web-to-APK Builder Pro - Frontend Logic
 * Mobile-first multi-screen navigation
 */
(function () {
  'use strict';

  const state = {
    sourceType: 'url',
    websiteUrl: 'https://example.com',
    zipFiles: null,
    zipHasIndex: false,
    editorContent: {
      html: getDefaultHtml(),
      css: getDefaultCss(),
      js: getDefaultJs()
    },
    currentEditorFile: 'html',
    iconDataUrl: null,
    splashLogoDataUrl: null,
    iconBlobs: {},
    screenHistory: ['home']
  };

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);

  document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initEditor();
    initDropZone();
    initIconHandler();
    initSplash();
    initValidation();
    initGenerate();
    initTheme();
    initExtraButtons();
    // load default editor content
    if ($('#codeEditor')) $('#codeEditor').value = state.editorContent.html;
    log('System ready. All Pro features unlocked.', 'info');
  });

  // ========== NAVIGATION ==========
  function initNavigation() {
    $$('[data-goto]').forEach(el => {
      el.addEventListener('click', () => {
        const target = el.dataset.goto;
        if (target === 'url' || target === 'zip' || target === 'editor') {
          state.sourceType = target;
        }
        showScreen(target + 'Screen');
      });
    });

    $$('[data-back]').forEach(btn => {
      btn.addEventListener('click', () => {
        state.screenHistory.pop();
        const prev = state.screenHistory[state.screenHistory.length - 1] || 'home';
        showScreen(prev === 'home' ? 'homeScreen' : prev + 'Screen', true);
      });
    });
  }

  function showScreen(id, isBack = false) {
    $$('.screen').forEach(s => s.classList.remove('active'));
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
    if (!isBack) {
      const key = id.replace('Screen', '');
      if (state.screenHistory[state.screenHistory.length - 1] !== key) {
        state.screenHistory.push(key);
      }
    }
    window.scrollTo(0, 0);
  }

  // ========== EDITOR ==========
  function initEditor() {
    const editor = $('#codeEditor');
    if (!editor) return;

    $$('.editor-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        state.editorContent[state.currentEditorFile] = editor.value;
        $$('.editor-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.currentEditorFile = btn.dataset.file;
        editor.value = state.editorContent[state.currentEditorFile];
      });
    });

    editor.addEventListener('input', () => {
      state.editorContent[state.currentEditorFile] = editor.value;
    });

    $('#previewBtn')?.addEventListener('click', () => {
      state.editorContent[state.currentEditorFile] = editor.value;
      const html = state.editorContent.html;
      const css = state.editorContent.css;
      const js = state.editorContent.js;
      const full = html.replace('</head>', `<style>${css}</style></head>`)
                       .replace('</body>', `<script>${js}<\/script></body>`);
      $('#previewFrameWrap').classList.remove('hidden');
      $('#previewFrame').srcdoc = full;
    });

    $('#resetEditorBtn')?.addEventListener('click', () => {
      state.editorContent = { html: getDefaultHtml(), css: getDefaultCss(), js: getDefaultJs() };
      editor.value = state.editorContent[state.currentEditorFile];
      log('Editor reset to sample.', 'info');
    });
  }

  function getDefaultHtml() {
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>My Web App</title>
</head>
<body>
  <div class="container">
    <h1>Welcome</h1>
    <p>This is your web content running inside a native Android WebView.</p>
    <button onclick="alert('Hello from Android!')">Test Button</button>
  </div>
</body>
</html>`;
  }

  function getDefaultCss() {
    return `* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: system-ui, -apple-system, sans-serif;
  background: linear-gradient(135deg, #0f172a, #1e293b);
  color: #e2e8f0;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}
.container { text-align: center; padding: 2rem; }
h1 { font-size: 2rem; margin-bottom: 1rem; color: #2dd4bf; }
button {
  margin-top: 1.5rem; padding: 0.75rem 1.5rem;
  background: #0d9488; color: white; border: none;
  border-radius: 0.75rem; font-size: 1rem; cursor: pointer;
}
button:active { transform: scale(0.97); }`;
  }

  function getDefaultJs() {
    return `console.log('Web-to-APK content loaded');
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM ready');
});`;
  }

  // ========== ZIP ==========
  function initDropZone() {
    const zone = $('#dropZone');
    const input = $('#zipInput');
    if (!zone || !input) return;

    zone.addEventListener('click', () => input.click());
    zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
    zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
    zone.addEventListener('drop', e => {
      e.preventDefault();
      zone.classList.remove('dragover');
      if (e.dataTransfer.files.length) handleZipFile(e.dataTransfer.files[0]);
    });
    input.addEventListener('change', () => {
      if (input.files.length) handleZipFile(input.files[0]);
    });
  }

  async function handleZipFile(file) {
    if (!file.name.toLowerCase().endsWith('.zip')) {
      log('Please select a .zip file.', 'error');
      return;
    }
    log(`Reading ZIP: ${file.name}...`, 'info');
    try {
      const zip = await JSZip.loadAsync(file);
      const files = {};
      let hasIndex = false;
      let indexPath = null;
      const promises = [];
      zip.forEach((relativePath, zipEntry) => {
        if (zipEntry.dir) return;
        promises.push(
          zipEntry.async('uint8array').then(content => {
            files[relativePath] = content;
            const lower = relativePath.toLowerCase();
            if (lower === 'index.html' || lower.endsWith('/index.html')) {
              hasIndex = true;
              indexPath = relativePath;
            }
          })
        );
      });
      await Promise.all(promises);
      state.zipFiles = files;
      state.zipHasIndex = hasIndex;
      $('#zipInfo').classList.remove('hidden');
      $('#zipFileName').textContent = file.name;
      $('#zipFileCount').textContent = `${Object.keys(files).length} files` + (hasIndex ? ` • index: ${indexPath}` : ' • ⚠ No index.html');
      if (!hasIndex) log('Warning: No index.html in ZIP.', 'warn');
      else log(`ZIP loaded (${Object.keys(files).length} files).`, 'success');
    } catch (err) {
      log('Failed to read ZIP: ' + err.message, 'error');
      state.zipFiles = null;
    }
  }

  // ========== ICON ==========
  function initIconHandler() {
    $('#iconInput')?.addEventListener('change', async e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => {
        state.iconDataUrl = ev.target.result;
        const img = new Image();
        img.onload = () => {
          const preview = $('#iconPreview');
          preview.innerHTML = '';
          const pi = document.createElement('img');
          pi.src = state.iconDataUrl;
          preview.appendChild(pi);
          generateMipmaps(img).then(blobs => {
            state.iconBlobs = blobs;
            log('Icon → mipmaps ready.', 'success');
          });
        };
        img.src = state.iconDataUrl;
      };
      reader.readAsDataURL(file);
    });
  }

  async function generateMipmaps(img) {
    const sizes = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
    const blobs = {};
    for (const [density, size] of Object.entries(sizes)) {
      const canvas = document.createElement('canvas');
      canvas.width = size; canvas.height = size;
      const ctx = canvas.getContext('2d');
      const r = size * 0.2;
      ctx.beginPath();
      ctx.moveTo(r, 0);
      ctx.arcTo(size, 0, size, size, r);
      ctx.arcTo(size, size, 0, size, r);
      ctx.arcTo(0, size, 0, 0, r);
      ctx.arcTo(0, 0, size, 0, r);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(img, 0, 0, size, size);
      blobs[density] = await new Promise(res => canvas.toBlob(res, 'image/png'));
    }
    return blobs;
  }

  // ========== SPLASH ==========
  function initSplash() {
    $('#splashDuration')?.addEventListener('input', e => {
      $('#durationLabel').textContent = e.target.value + 's';
    });
    $('#splashLogo')?.addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => {
        state.splashLogoDataUrl = ev.target.result;
        log('Splash logo loaded.', 'info');
      };
      reader.readAsDataURL(file);
    });
  }

  // ========== VALIDATION ==========
  function initValidation() {
    $('#validateUrlBtn')?.addEventListener('click', () => {
      const url = $('#websiteUrl').value.trim();
      const status = $('#urlStatus');
      if (!url) {
        status.textContent = 'Please enter a URL.';
        status.style.color = '#ef4444';
        return;
      }
      try {
        const u = new URL(url);
        if (!['http:', 'https:'].includes(u.protocol)) throw new Error();
        state.websiteUrl = url;
        status.textContent = '✓ Valid URL';
        status.style.color = '#10b981';
        log('URL validated: ' + url, 'success');
      } catch {
        status.textContent = 'Invalid URL. Use https://...';
        status.style.color = '#ef4444';
      }
    });

    $('#packageName')?.addEventListener('input', e => {
      const val = e.target.value.trim();
      const valid = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(val);
      const err = $('#pkgError');
      if (err) err.style.display = (valid || !val) ? 'none' : 'block';
    });
  }

  // ========== THEME ==========
  function initTheme() {
    $('#themeToggle')?.addEventListener('click', () => {
      document.documentElement.classList.toggle('dark');
    });
  }

  function initExtraButtons() {
    $('#howToBtn')?.addEventListener('click', () => {
      alert('How to use:\n\n1. Choose source (URL / ZIP / Editor)\n2. Fill App Name, Package, Icon\n3. Configure WebView & Permissions\n4. Click Generate ZIP\n5. Open the ZIP in Android Studio → Sync → Run');
    });
    $('#aboutBtn')?.addEventListener('click', () => {
      alert('Web-to-APK Builder Pro\n\nAll features unlocked.\n100% client-side.\nGenerates complete Android Studio project.\n\nNo server required.');
    });
  }

  // ========== LOG ==========
  window.log = function (msg, type = 'info') {
    const el = $('#buildLog');
    if (!el) return;
    const line = document.createElement('div');
    line.className = `log-${type}`;
    const time = new Date().toLocaleTimeString('en-IN', { hour12: false });
    line.textContent = `[${time}] ${msg}`;
    el.appendChild(line);
    el.scrollTop = el.scrollHeight;
  };

  // ========== GENERATE ==========
  function initGenerate() {
    $('#generateBtn')?.addEventListener('click', async () => {
      const btn = $('#generateBtn');
      btn.disabled = true;
      btn.textContent = 'Building...';

      try {
        const config = collectConfig();
        if (!config) {
          btn.disabled = false;
          btn.textContent = '📦 Generate Android Studio ZIP';
          return;
        }
        await window.Builder.generate(config, state);
      } catch (err) {
        log('Build failed: ' + err.message, 'error');
        console.error(err);
      } finally {
        btn.disabled = false;
        btn.textContent = '📦 Generate Android Studio ZIP';
      }
    });
  }

  function collectConfig() {
    const appName = $('#appName')?.value.trim() || 'My Web App';
    const shortName = $('#shortName')?.value.trim() || 'WebApp';
    const packageName = $('#packageName')?.value.trim();
    const versionName = $('#versionName')?.value.trim() || '1.0.0';
    const versionCode = parseInt($('#versionCode')?.value, 10) || 1;

    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(packageName)) {
      log('Invalid package name. Use: com.company.app', 'error');
      const err = $('#pkgError');
      if (err) err.style.display = 'block';
      showScreen('configScreen');
      return null;
    }

    if (state.sourceType === 'url') {
      const url = $('#websiteUrl')?.value.trim();
      if (!url) {
        log('Please enter a website URL.', 'error');
        showScreen('urlScreen');
        return null;
      }
      try { new URL(url); } catch {
        log('Invalid website URL.', 'error');
        showScreen('urlScreen');
        return null;
      }
      state.websiteUrl = url;
    } else if (state.sourceType === 'zip') {
      if (!state.zipFiles || !state.zipHasIndex) {
        log('Please upload a valid ZIP with index.html.', 'error');
        showScreen('zipScreen');
        return null;
      }
    } else if (state.sourceType === 'editor') {
      if ($('#codeEditor')) state.editorContent[state.currentEditorFile] = $('#codeEditor').value;
    }

    return {
      appName, shortName, packageName, versionName, versionCode,
      sourceType: state.sourceType,
      websiteUrl: state.websiteUrl,
      permissions: {
        internet: $('#permInternet')?.checked ?? true,
        camera: $('#permCamera')?.checked ?? false,
        location: $('#permLocation')?.checked ?? false,
        storage: $('#permStorage')?.checked ?? false,
        vibrate: $('#permVibrate')?.checked ?? false
      },
      jsEnabled: $('#jsEnabled')?.checked ?? true,
      domStorage: $('#domStorage')?.checked ?? true,
      zoomControls: $('#zoomControls')?.checked ?? false,
      pinchZoom: $('#pinchZoom')?.checked ?? true,
      pullRefresh: $('#pullRefresh')?.checked ?? false,
      fullscreen: $('#fullscreen')?.checked ?? false,
      hwAccel: $('#hwAccel')?.checked ?? true,
      orientation: $('#orientation')?.value || 'unspecified',
      userAgent: $('#userAgent')?.value.trim() || '',
      customCss: $('#customCss')?.value.trim() || '',
      customJs: $('#customJs')?.value.trim() || '',
      splashColor: $('#splashColor')?.value || '#0f172a',
      splashDuration: parseInt($('#splashDuration')?.value, 10) || 2,
      offlineMsg: $('#offlineMsg')?.value.trim() || 'No internet connection.'
    };
  }

  window.AppState = state;
})();
