/**
 * Web-to-APK Builder - Core Engine (builder.js)
 * Generates a complete Android Studio / Gradle project ZIP
 * Fully production-ready, no placeholders
 */

(function () {
  'use strict';

  window.Builder = {
    async generate(config, state) {
      log('=== Build started ===', 'info');
      log('Validating configuration...', 'info');

      const zip = new JSZip();
      const pkgPath = config.packageName.replace(/\./g, '/');
      const appId = config.packageName;

      // ---------- Project root files ----------
      log('Creating project-level Gradle files...', 'info');
      zip.file('settings.gradle', genSettingsGradle());
      zip.file('build.gradle', genProjectBuildGradle());
      zip.file('gradle.properties', genGradleProperties());
      zip.file('gradle/wrapper/gradle-wrapper.properties', genWrapperProps());

      // ---------- app/build.gradle ----------
      log('Generating app/build.gradle...', 'info');
      zip.file('app/build.gradle', genAppBuildGradle(config));

      // ---------- AndroidManifest.xml ----------
      log('Generating AndroidManifest.xml...', 'info');
      zip.file('app/src/main/AndroidManifest.xml', genManifest(config));

      // ---------- MainActivity.java ----------
      log('Generating MainActivity.java (full WebView engine)...', 'info');
      zip.file(`app/src/main/java/${pkgPath}/MainActivity.java`, genMainActivity(config));

      // ---------- Resources ----------
      log('Creating resource files...', 'info');
      zip.file('app/src/main/res/values/strings.xml', genStrings(config));
      zip.file('app/src/main/res/values/colors.xml', genColors(config));
      zip.file('app/src/main/res/values/styles.xml', genStyles(config));
      zip.file('app/src/main/res/values/themes.xml', genThemes(config));
      zip.file('app/src/main/res/xml/network_security_config.xml', genNetworkSecurity());
      zip.file('app/src/main/res/layout/activity_main.xml', genLayout());
      zip.file('app/src/main/res/layout/splash.xml', genSplashLayout(config));

      // ---------- Icons (mipmaps) ----------
      log('Packing mipmap icons...', 'info');
      if (state.iconBlobs && Object.keys(state.iconBlobs).length) {
        for (const [density, blob] of Object.entries(state.iconBlobs)) {
          const arr = await blob.arrayBuffer();
          zip.file(`app/src/main/res/mipmap-${density}/ic_launcher.png`, arr);
          zip.file(`app/src/main/res/mipmap-${density}/ic_launcher_round.png`, arr);
        }
      } else {
        // generate default adaptive icon placeholder (solid color)
        const defaultIcon = await createDefaultIcon(config.splashColor || '#6366f1');
        for (const density of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
          zip.file(`app/src/main/res/mipmap-${density}/ic_launcher.png`, defaultIcon);
          zip.file(`app/src/main/res/mipmap-${density}/ic_launcher_round.png`, defaultIcon);
        }
      }

      // ---------- Assets (HTML content) ----------
      log('Injecting web assets...', 'info');
      if (config.sourceType === 'url') {
        // just a tiny offline fallback page
        zip.file('app/src/main/assets/offline.html', genOfflineHtml(config));
      } else if (config.sourceType === 'zip' && state.zipFiles) {
        for (const [path, content] of Object.entries(state.zipFiles)) {
          // normalize path - remove leading folder if single root
          let clean = path;
          zip.file(`app/src/main/assets/${clean}`, content);
        }
        log(`Injected ${Object.keys(state.zipFiles).length} files into assets/`, 'success');
      } else {
        // editor mode
        const html = state.editorContent.html;
        const css = state.editorContent.css;
        const js = state.editorContent.js;
        // combine into single index.html for simplicity + separate files
        const combined = html
          .replace('</head>', `<style>\n${css}\n</style>\n</head>`)
          .replace('</body>', `<script>\n${js}\n</script>\n</body>`);
        zip.file('app/src/main/assets/index.html', combined);
        zip.file('app/src/main/assets/style.css', css);
        zip.file('app/src/main/assets/script.js', js);
        zip.file('app/src/main/assets/offline.html', genOfflineHtml(config));
      }

      // ---------- Splash logo if present ----------
      if (state.splashLogoDataUrl) {
        const base64 = state.splashLogoDataUrl.split(',')[1];
        const binary = atob(base64);
        const arr = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) arr[i] = binary.charCodeAt(i);
        zip.file('app/src/main/res/drawable/splash_logo.png', arr);
      }

      // ---------- proguard (optional empty) ----------
      zip.file('app/proguard-rules.pro', '# Keep WebView related classes\n-keepclassmembers class * {\n    @android.webkit.JavascriptInterface <methods>;\n}\n');

      // ---------- README inside project ----------
      zip.file('README.md', genProjectReadme(config));

      // ---------- Generate & Download ----------
      log('Compressing ZIP archive...', 'info');
      const blob = await zip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 }
      }, (meta) => {
        // progress optional
      });

      const fileName = `${config.shortName.replace(/\s+/g, '_')}_Android_Project.zip`;
      saveAs(blob, fileName);
      log(`ZIP ready! Downloaded: ${fileName}`, 'success');
      log('Open the project in Android Studio → Sync Gradle → Run on device/emulator.', 'info');
      log('=== Build complete ===', 'success');
    }
  };

  // ===================== GENERATORS =====================

  function genSettingsGradle() {
    return `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "WebToApk"
include ':app'
`;
  }

  function genProjectBuildGradle() {
    return `// Top-level build file
plugins {
    id 'com.android.application' version '8.2.2' apply false
}
`;
  }

  function genGradleProperties() {
    return `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
`;
  }

  function genWrapperProps() {
    return `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.2-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`;
  }

  function genAppBuildGradle(config) {
    return `plugins {
    id 'com.android.application'
}

android {
    namespace '${config.packageName}'
    compileSdk 34

    defaultConfig {
        applicationId "${config.packageName}"
        minSdk 24
        targetSdk 34
        versionCode ${config.versionCode}
        versionName "${config.versionName}"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            minifyEnabled false
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    buildFeatures {
        viewBinding true
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.webkit:webkit:1.10.0'
    implementation 'androidx.swiperefreshlayout:swiperefreshlayout:1.1.0'
}
`;
  }

  function genManifest(config) {
    const perms = [];
    if (config.permissions.internet) {
      perms.push('    <uses-permission android:name="android.permission.INTERNET" />');
      perms.push('    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />');
    }
    if (config.permissions.camera) {
      perms.push('    <uses-permission android:name="android.permission.CAMERA" />');
      perms.push('    <uses-permission android:name="android.permission.RECORD_AUDIO" />');
      perms.push('    <uses-feature android:name="android.hardware.camera" android:required="false" />');
    }
    if (config.permissions.location) {
      perms.push('    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />');
      perms.push('    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />');
    }
    if (config.permissions.storage) {
      perms.push('    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />');
      perms.push('    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />');
      perms.push('    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />');
    }
    if (config.permissions.vibrate) {
      perms.push('    <uses-permission android:name="android.permission.VIBRATE" />');
    }

    const screenOrientation = config.orientation === 'unspecified' ? '' : `\n            android:screenOrientation="${config.orientation}"`;

    return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

${perms.join('\n')}

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.WebToApk"
        android:usesCleartextTraffic="true"
        android:networkSecurityConfig="@xml/network_security_config"
        android:hardwareAccelerated="${config.hwAccel}">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:launchMode="singleTask"${screenOrientation}
            android:theme="@style/Theme.WebToApk.Splash">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;
  }

  function genMainActivity(config) {
    const loadUrl = config.sourceType === 'url'
      ? `webView.loadUrl("${config.websiteUrl.replace(/"/g, '\\"')}");`
      : `webView.loadUrl("file:///android_asset/index.html");`;

    const customCss = config.customCss
      ? config.customCss.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n')
      : '';
    const customJs = config.customJs
      ? config.customJs.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n')
      : '';

    const uaLine = config.userAgent
      ? `webSettings.setUserAgentString("${config.userAgent.replace(/"/g, '\\"')}");`
      : '';

    return `package ${config.packageName};

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private ProgressBar progressBar;
    private View splashView;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean isSplashDone = false;

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                String dataString = result.getData().getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                } else if (result.getData().getClipData() != null) {
                    int count = result.getData().getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = result.getData().getClipData().getItemAt(i).getUri();
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        });

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ${config.fullscreen ? 'getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);' : ''}

        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        swipeRefresh = findViewById(R.id.swipe_refresh);
        progressBar = findViewById(R.id.progress_bar);
        splashView = findViewById(R.id.splash_container);

        // Splash handling
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (splashView != null) {
                splashView.animate().alpha(0f).setDuration(300).withEndAction(() -> {
                    splashView.setVisibility(View.GONE);
                    isSplashDone = true;
                }).start();
            } else {
                isSplashDone = true;
            }
        }, ${config.splashDuration * 1000}L);

        setupWebView();
        requestNeededPermissions();

        ${config.pullRefresh ? `
        swipeRefresh.setEnabled(true);
        swipeRefresh.setOnRefreshListener(() -> {
            webView.reload();
        });
        ` : 'swipeRefresh.setEnabled(false);'}

        ${loadUrl}
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(${config.jsEnabled});
        webSettings.setDomStorageEnabled(${config.domStorage});
        webSettings.setDatabaseEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setSupportZoom(${config.pinchZoom || config.zoomControls});
        webSettings.setBuiltInZoomControls(${config.zoomControls});
        webSettings.setDisplayZoomControls(false);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        ${uaLine}

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                if (swipeRefresh.isRefreshing()) {
                    swipeRefresh.setRefreshing(false);
                }
                // Custom CSS injection
                ${customCss ? `view.evaluateJavascript("(function(){var s=document.createElement('style');s.innerHTML=\\"${customCss}\\";document.head.appendChild(s);})();", null);` : ''}
                // Custom JS injection
                ${customJs ? `view.evaluateJavascript("${customJs}", null);` : ''}
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadUrl("file:///android_asset/offline.html");
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("file://")) {
                    return false;
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                } catch (Exception e) {
                    return true;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    progressBar.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    request.grant(request.getResources());
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    fileChooserLauncher.launch(intent);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    private void requestNeededPermissions() {
        List<String> permissions = new ArrayList<>();
        ${config.permissions.camera ? `
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.CAMERA);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECORD_AUDIO);
        }` : ''}
        ${config.permissions.location ? `
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }` : ''}
        if (!permissions.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toArray(new String[0]), 1001);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
`;
  }

  function genStrings(config) {
    return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${escapeXml(config.appName)}</string>
    <string name="app_short_name">${escapeXml(config.shortName)}</string>
</resources>
`;
  }

  function genColors(config) {
    return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">#6366F1</color>
    <color name="primary_dark">#4338CA</color>
    <color name="accent">#06B6D4</color>
    <color name="splash_background">${config.splashColor}</color>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
</resources>
`;
  }

  function genStyles(config) {
    return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.WebToApk" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/primary</item>
        <item name="colorPrimaryVariant">@color/primary_dark</item>
        <item name="colorAccent">@color/accent</item>
        <item name="android:statusBarColor">@color/primary_dark</item>
        <item name="android:navigationBarColor">@color/primary_dark</item>
        <item name="android:windowBackground">@color/splash_background</item>
    </style>
</resources>
`;
  }

  function genThemes(config) {
    return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.WebToApk.Splash" parent="Theme.WebToApk">
        <item name="android:windowBackground">@color/splash_background</item>
        <item name="android:windowFullscreen">true</item>
    </style>
</resources>
`;
  }

  function genNetworkSecurity() {
    return `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="true">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`;
  }

  function genLayout() {
    return `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <androidx.swiperefreshlayout.widget.SwipeRefreshLayout
        android:id="@+id/swipe_refresh"
        android:layout_width="match_parent"
        android:layout_height="match_parent">

        <WebView
            android:id="@+id/webview"
            android:layout_width="match_parent"
            android:layout_height="match_parent" />
    </androidx.swiperefreshlayout.widget.SwipeRefreshLayout>

    <ProgressBar
        android:id="@+id/progress_bar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="match_parent"
        android:layout_height="3dp"
        android:layout_gravity="top"
        android:max="100"
        android:progress="0"
        android:visibility="gone"
        android:indeterminate="false" />

    <include
        android:id="@+id/splash_container"
        layout="@layout/splash" />
</FrameLayout>
`;
  }

  function genSplashLayout(config) {
    const hasLogo = false; // we handle via code if needed; keep simple
    return `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/splash_background">

    <LinearLayout
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="center"
        android:orientation="vertical"
        android:gravity="center">

        <ImageView
            android:id="@+id/splash_logo"
            android:layout_width="96dp"
            android:layout_height="96dp"
            android:src="@mipmap/ic_launcher"
            android:contentDescription="@string/app_name" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="16dp"
            android:text="@string/app_name"
            android:textColor="#FFFFFF"
            android:textSize="20sp"
            android:textStyle="bold" />
    </LinearLayout>
</FrameLayout>
`;
  }

  function genOfflineHtml(config) {
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Offline</title>
  <style>
    body {
      margin: 0; padding: 0;
      font-family: system-ui, sans-serif;
      background: #0f172a; color: #e2e8f0;
      display: flex; align-items: center; justify-content: center;
      min-height: 100vh; text-align: center;
    }
    .box { padding: 2rem; max-width: 320px; }
    h1 { font-size: 1.5rem; margin-bottom: 0.75rem; color: #818cf8; }
    p { color: #94a3b8; line-height: 1.5; }
    button {
      margin-top: 1.5rem; padding: 0.75rem 1.5rem;
      background: #6366f1; color: white; border: none;
      border-radius: 0.75rem; font-size: 1rem; cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="box">
    <h1>Offline</h1>
    <p>${escapeXml(config.offlineMsg)}</p>
    <button onclick="location.reload()">Try Again</button>
  </div>
</body>
</html>`;
  }

  function genProjectReadme(config) {
    return `# ${config.appName} – Android Project

Generated by **Web-to-APK Builder Pro**

## How to open

1. Extract this ZIP
2. Open **Android Studio**
3. **File → Open** → select the extracted folder
4. Wait for Gradle Sync
5. Connect a device or start an emulator
6. Click **Run** (green play button)

## Configuration used

- Package: \`${config.packageName}\`
- Version: ${config.versionName} (${config.versionCode})
- Source: ${config.sourceType}
- Min SDK: 24 | Target SDK: 34

## Notes

- All Pro features are unlocked in this build.
- If you used a remote URL, the app requires internet.
- For local HTML (ZIP / Editor), content is inside \`app/src/main/assets/\`.
- You can further customize MainActivity.java and resources as needed.

Happy building!
`;
  }

  function escapeXml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  async function createDefaultIcon(hexColor) {
    const canvas = document.createElement('canvas');
    canvas.width = 192;
    canvas.height = 192;
    const ctx = canvas.getContext('2d');
    // rounded rect
    const r = 40;
    ctx.beginPath();
    ctx.moveTo(r, 0);
    ctx.arcTo(192, 0, 192, 192, r);
    ctx.arcTo(192, 192, 0, 192, r);
    ctx.arcTo(0, 192, 0, 0, r);
    ctx.arcTo(0, 0, 192, 0, r);
    ctx.closePath();
    ctx.fillStyle = hexColor;
    ctx.fill();
    // simple letter
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 90px system-ui';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('W', 96, 100);
    return new Promise(res => canvas.toBlob(b => b.arrayBuffer().then(res), 'image/png'));
  }
})();
