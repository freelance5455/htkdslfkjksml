package ir.zae.supermarket

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var speech: SpeechRecognizer? = null
    private var currentMode = "sale"
    private val audioRequest = 8102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(14, 58, 49)
        window.navigationBarColor = android.graphics.Color.rgb(14, 58, 49)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                // The app uses Android SpeechRecognizer, not WebView's browser microphone.
                request.deny()
            }
        }
        web.addJavascriptInterface(VoiceBridge(), "AndroidVoice")
        web.addJavascriptInterface(StorageBridge(), "AndroidStorage")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
        }
    }

    inner class VoiceBridge {
        @JavascriptInterface fun start(mode: String) {
            runOnUiThread {
                currentMode = if (mode == "product") "product" else "sale"
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
                    sendResult(currentMode, "", true)
                    return@runOnUiThread
                }
                beginRecognition()
            }
        }
        @JavascriptInterface fun stop() { runOnUiThread { try { speech?.stopListening() } catch (_: Exception) {} } }
    }

    private fun beginRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendResult(currentMode, "", true)
            Toast.makeText(this, "سرویس تشخیص گفتار در گوشی فعال نیست", Toast.LENGTH_LONG).show()
            return
        }
        try {
            speech?.destroy()
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "اجازهٔ میکروفون داده نشده است"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "برای تشخیص گفتار فارسی اتصال اینترنت یا سرویس گفتار لازم است"
                        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "زبان فارسی در سرویس گفتار گوشی در دسترس نیست"
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "صدایی تشخیص داده نشد؛ دوباره امتحان کن"
                        else -> "تشخیص گفتار ناموفق بود؛ دوباره امتحان کن"
                    }
                    sendResult(currentMode, "", true)
                    runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show() }
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    sendResult(currentMode, text, true)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) sendResult(currentMode, text, false)
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra("android.speech.extra.DICTATION_MODE", true)
            }
            speech?.startListening(intent)
        } catch (_: Exception) {
            sendResult(currentMode, "", true)
        }
    }

    private fun sendResult(mode: String, text: String, final: Boolean) {
        val js = "window.onNativeSpeechResult && window.onNativeSpeechResult(${JSONObject.quote(mode)},${JSONObject.quote(text)},$final);"
        runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(js, null) }
    }

    inner class StorageBridge {
        @JavascriptInterface fun saveBackup(json: String) {
            try {
                val file = File(filesDir, "ZAE-Supermarket-Backup.json")
                file.writeText(json, Charsets.UTF_8)
            } catch (_: Exception) {}
        }
        @JavascriptInterface fun loadBackup(): String {
            return try { File(filesDir, "ZAE-Supermarket-Backup.json").takeIf { it.exists() }?.readText(Charsets.UTF_8) ?: "" }
            catch (_: Exception) { "" }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioRequest && grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "برای ثبت صوتی، اجازهٔ میکروفون را فعال کن", Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        try { speech?.cancel() } catch (_: Exception) {}
        super.onPause()
    }

    override fun onDestroy() {
        try { speech?.destroy() } catch (_: Exception) {}
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
