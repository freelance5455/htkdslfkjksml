  /* ---------- settings ---------- */
  var DEF = { sound: true, vib: true, supply: 'mine', names: true, decor: true, anim: 'normal', fog: false, seasons: true, ai: 'normal', boost: 2, calm: 0, nocap: false, harsh: false, noside: false, shape: 'auto', vic: 'std', np: 42, nc: 6, seed: '', mapKind: 'seed', theme: 'dark', autosave: true, speed: 'normal', real: false, rUp: true, rMan: true, rWar: true, rAtt: true, rFog: true, rDip: true, vol: 2, alarm: true, news: true, tips: true, ships: true, resicons: true, scen: 'classic', mini: true, tint: true, music: false, armyStyle: 'round', tab: 'game', uiStyle: 'classic', device: '', popK: false, gStat: true, growSp: 'slow', villSlow: true, light: 'auto', newbie: false, tutDone: false, hints: {} };
  var ST = {}, k0;
  for (k0 in DEF) ST[k0] = DEF[k0];
  try { var sv = JSON.parse(localStorage.getItem('rubezhi3.settings') || 'null'); if (sv) for (k0 in sv) if (k0 in DEF) ST[k0] = sv[k0]; } catch (e) { /* no storage */ }
  function saveSettings() { try { localStorage.setItem('rubezhi3.settings', JSON.stringify(ST)); } catch (e) { /* ignore */ } }
  /* realistic mode: master switch + separate rules, same for every country */
  function RL(k) { return !!(ST.real && ST[k]); }
  function fogOn() { return !ST.devFog && !!(ST.fog || RL('rFog')); }
  function autoDev() { try { return window.matchMedia && window.matchMedia('(pointer: coarse)').matches ? 'phone' : 'pc'; } catch (e) { return 'pc'; } }
  function applyUi() {
    var r = document.documentElement;
    var th0 = ST.theme, si0 = styId();
    for (var sj = 0; sj < STY.length; sj++) if (STY[sj][0] === si0 && STY[sj][2] !== null) th0 = STY[sj][2] ? 'dark' : 'light';
    if (th0 === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', th0);
    r.setAttribute('data-style', si0); r.classList.toggle('newbie', !!ST.newbie);
    r.setAttribute('data-device', ST.device || autoDev());
  }
  var STY = [['classic', 'Классический', null], ['brutal', 'Брутальный', null], ['neon', 'Неон', true], ['military', 'Военный', true], ['paper', 'Атлас', false], ['terminal', 'Терминал', true]];
  function styId() { for (var i = 0; i < STY.length; i++) if (STY[i][0] === ST.uiStyle) return ST.uiStyle; return 'classic'; }
  function isDark() {
    for (var si = 0; si < STY.length; si++) if (STY[si][0] === styId() && STY[si][2] !== null) return STY[si][2];
    if (ST.theme === 'dark') return true;
    if (ST.theme === 'light' || ST.theme === 'sepia') return false;
    try { return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches); } catch (e) { return true; }
  }

  /* ---------- sound ---------- */
  var AC = null;
  function tone(f, d, type, vol, delay) {
    if (!ST.sound) return;
    try {
      if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)();
      var o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime + (delay || 0);
      o.type = type || 'sine'; o.frequency.value = f;
      var vm = ST.vol === 1 ? 0.45 : ST.vol === 3 ? 1.8 : 1; g.gain.setValueAtTime(Math.min(0.5, (vol || 0.05) * vm), t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d);
    } catch (e) { /* no audio */ }
  }
  /* generative ambient music: slow pads, darker during war */
  var MU = { on: false, timer: 0, step: 0 }, MC = [[57, 64, 69, 72], [53, 60, 65, 69], [48, 55, 60, 64], [55, 62, 67, 71]], MW = [[45, 52, 57, 60], [41, 48, 53, 56], [43, 50, 55, 58], [40, 47, 52, 55]];
  function mtof(m) { return 440 * Math.pow(2, (m - 69) / 12); }
  function padTone(f, d, vol, delay) {
    try {
      var t = AC.currentTime + (delay || 0), o = AC.createOscillator(), o2 = AC.createOscillator(), g = AC.createGain();
      o.type = 'sine'; o.frequency.value = f; o2.type = 'triangle'; o2.frequency.value = f * 1.004;
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + d * 0.28); g.gain.linearRampToValueAtTime(0.0001, t + d);
      o.connect(g); o2.connect(g); g.connect(AC.destination); o.start(t); o2.start(t); o.stop(t + d + 0.1); o2.stop(t + d + 0.1);
    } catch (e) { /* ignore */ }
  }
  function musicTick() {
    if (!MU.on || !AC || document.hidden || !ST.music || !ST.sound) return;
    var war = !!(S && S.phase === 'play' && S.player >= 0 && warEnemies(S.player).length), set = war ? MW : MC, ch = set[MU.step++ % 4], vm = ST.vol === 1 ? 0.5 : ST.vol === 3 ? 1.7 : 1;
    ch.forEach(function (m, i) { padTone(mtof(m), 6.2, (war ? 0.02 : 0.016) * vm, i * 0.35); });
    if (war && MU.step % 2 === 0) { padTone(mtof(ch[0] - 12), 1.4, 0.05 * vm, 0); padTone(mtof(ch[0] - 12), 1.4, 0.04 * vm, 2.1); }
  }
  function musicSync() {
    var want = !!(ST.music && ST.sound && S && S.phase !== 'pick');
    if (want && !MU.on) {
      try { if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume(); } catch (e) { return; }
      MU.on = true; MU.step = 0; musicTick(); MU.timer = setInterval(musicTick, 5200);
    } else if (!want && MU.on) { MU.on = false; clearInterval(MU.timer); MU.timer = 0; }
    else if (want && AC && AC.state === 'suspended') { try { AC.resume(); } catch (e) { /* ignore */ } }
  }
  document.addEventListener('visibilitychange', function () { try { if (!AC) return; if (document.hidden) AC.suspend(); else if (MU.on) AC.resume(); } catch (e) { /* ignore */ } });
  var SFX = {
    click: function () { tone(520, 0.05, 'square', 0.02); },
    order: function () { tone(440, 0.06, 'triangle', 0.04); tone(587, 0.08, 'triangle', 0.04, 0.05); },
    recruit: function () { tone(440, 0.08, 'triangle', 0.05); tone(660, 0.1, 'triangle', 0.05, 0.08); },
    capture: function () { tone(392, 0.12, 'triangle', 0.06); tone(523, 0.12, 'triangle', 0.06, 0.1); tone(784, 0.22, 'triangle', 0.06, 0.2); },
    battle: function () { tone(110, 0.22, 'sawtooth', 0.045); tone(75, 0.26, 'square', 0.035, 0.05); },
    lose: function () { tone(300, 0.2, 'triangle', 0.05); tone(200, 0.3, 'triangle', 0.05, 0.18); },
    turn: function () { tone(330, 0.06, 'sine', 0.04); },
    alarm: function () { tone(560, 0.13, 'square', 0.05); tone(380, 0.13, 'square', 0.05, 0.15); tone(560, 0.13, 'square', 0.05, 0.3); tone(380, 0.2, 'square', 0.05, 0.45); }
  };
  function buzz(ms) { if (ST.vib && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) { /* ignore */ } } }
