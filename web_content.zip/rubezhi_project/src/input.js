  /* ---------- selection & orders ---------- */
  var UNDO = [];
  function undoPush(arms) { UNDO.push({ g: gen, r: S.round, s: arms.map(function (a) { return { id: a.id, route: a.route.slice(), wait: a.wait, stance: a.stance, mode: a.mode, eng: a.eng }; }) }); if (UNDO.length > 20) UNDO.shift(); }
  function undoOrder() {
    var u = UNDO.pop();
    while (u && (u.g !== gen || u.r !== S.round)) u = UNDO.pop();
    if (!u || S.busy || S.phase !== 'play') { toast('Нечего отменять.', 'warn'); return; }
    u.s.forEach(function (o) { var a = armyById(o.id); if (a) { a.route = o.route; a.wait = o.wait; a.stance = o.stance; a.mode = o.mode; a.eng = o.eng; } });
    SFX.click(); toast('Приказ отменён.', 'good'); render();
  }
  function orderMove(a, pid) {
    if (!a || a.owner !== S.player || S.busy) return;
    var p = S.provs[pid];
    if (pid === a.prov) { a.route = []; render(); return; }
    if (!canEnter(a.owner, p)) { toast('Туда нельзя: с державой ' + CNAMES[p.owner] + ' мир, проход закрыт.', 'warn'); return; }
    var r = findRoute(a, pid);
    if (!r) { toast('Маршрут не найден: путь перекрыт врагом или закрытыми границами.', 'warn'); return; }
    undoPush([a]); a.route = r; a.wait = 0; a.stance = 'atk'; SFX.order();
    render();
  }
  function selectNextIdle() {
    var list = idleArmies().sort(function (x, y) { return x.id - y.id; });
    if (!list.length) { toast('Все армии получили приказы.'); return; }
    var nx = list.filter(function (a) { return a.id > S.selA; })[0] || list[0];
    S.selA = nx.id; S.selP = nx.prov; centerOn(nx.prov); SFX.click(); render();
  }
  function toggleMulti(id) {
    var i = S.multi.indexOf(id);
    if (i >= 0) S.multi.splice(i, 1); else S.multi.push(id);
    SFX.click(); render();
  }
  function setMulti(on) {
    S.multiMode = on;
    if (on) { S.multi = S.selA >= 0 ? [S.selA] : []; S.selF = ''; } else S.multi = [];
    render();
  }
  function cycleLayer() { S.layer = S.layer === 'pol' ? 'mil' : S.layer === 'mil' ? 'sup' : S.layer === 'sup' ? 'eco' : S.layer === 'eco' ? 'nat' : S.layer === 'nat' ? 'unr' : 'pol'; if (S.layer !== 'mil') S.selF = ''; render(); }
  function mergeAt(id, only) {
    var a = armyById(id);
    if (!a) return;
    armiesAt(a.prov).filter(function (x) { return x.owner === a.owner && x !== a && (!only || only.indexOf(x.id) >= 0); }).forEach(function (b) {
      var T = a.troops + b.troops; a.org = (a.org * a.troops + b.org * b.troops) / T; a.troops = T;
      var ga = genOf(a), gb = genOf(b); if (gb && (!ga || gb.lvl > ga.lvl)) { a.gen = b.gen; b.gen = 0; }
      removeArmy(b);
    });
    a.route = []; a.eng = null; SFX.recruit(); render();
  }
  function splitDialog(a) {
    if (!a || a.owner !== S.player || S.busy || S.phase !== 'play') return;
    if (a.eng && a.route.length) { toast('Нельзя делить армию во время фронтового боя.', 'warn'); return; }
    var D = Math.floor(a.troops / 10);
    if (D < 2) { toast('Слишком мало людей для деления.', 'warn'); return; }
    var old = document.getElementById('splitDlg'); if (old) old.remove();
    var w = document.createElement('div'); w.id = 'splitDlg';
    w.style.cssText = 'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:var(--scrim);padding:16px';
    w.innerHTML = '<div style="background:var(--panel);color:var(--fg);border:1px solid var(--line2);border-radius:12px;box-shadow:var(--shadow);padding:16px;width:100%;max-width:340px;font-family:var(--font)">' +
      '<div style="font-weight:700;margin-bottom:10px">Разделить армию</div>' +
      '<div style="display:flex;justify-content:space-between;margin-bottom:6px"><span>Остаётся: <b id="spA"></b></span><span>Отделяется: <b id="spB"></b></span></div>' +
      '<input id="spR" type="range" min="1" max="' + (D - 1) + '" step="1" style="width:100%;margin:6px 0 12px">' +
      '<div class="row"><button class="btn sm" type="button" id="spHalf">½</button><button class="btn sm" type="button" id="spThird">⅓</button><button class="btn sm" type="button" id="spTwo">⅔</button><button class="btn sm" type="button" id="spOk">Разделить</button><button class="btn sm" type="button" id="spNo">Отмена</button></div></div>';
    document.body.appendChild(w);
    var r = w.querySelector('#spR');
    function upd() { w.querySelector('#spA').textContent = (D - +r.value) + ' див.'; w.querySelector('#spB').textContent = r.value + ' див.'; }
    r.value = Math.floor(D / 2); upd();
    r.addEventListener('input', upd);
    function pre(k) { r.value = clamp(Math.round(D * k), 1, D - 1); upd(); }
    w.querySelector('#spHalf').addEventListener('click', function () { pre(1 / 2); });
    w.querySelector('#spThird').addEventListener('click', function () { pre(1 / 3); });
    w.querySelector('#spTwo').addEventListener('click', function () { pre(2 / 3); });
    w.querySelector('#spNo').addEventListener('click', function () { w.remove(); });
    w.addEventListener('click', function (e) { if (e.target === w) w.remove(); });
    w.querySelector('#spOk').addEventListener('click', function () { var n = +r.value * 10; w.remove(); splitArmy(armyById(a.id), 0, n); });
  }
  function splitArmy(a, frac, cnt) {
    if (!a || a.owner !== S.player || S.busy || S.phase !== 'play') return;
    if (a.eng && a.route.length) { toast('Нельзя делить армию во время фронтового боя.', 'warn'); return; }
    var n = cnt || Math.round(a.troops * frac / 10) * 10;
    if (n < 10 || a.troops - n < 10) { toast('Слишком мало людей для деления.', 'warn'); return; }
    a.troops -= n; a.route = [];
    var b = newArmy(a.owner, a.prov, n, a.org);
    b.stance = a.stance; b.mode = a.mode; b.dug = a.dug;
    autoGen(b);
    S.selA = b.id; SFX.recruit();
    toast('Армия разделена: ' + U(a.troops) + ' и ' + U(n) + ' див.', 'good');
    saveGame(); render();
  }
  function onTap(x, y) {
    if (ANIM) { skipAnim(); return; }
    if (S.phase === 'pick') {
      var wp = pidAt((x - V.tx) / V.s, (y - V.ty) / V.s);
      if (wp >= 0 && S.provs[wp].owner >= 0) { S.pickC = S.provs[wp].owner; SFX.click(); render(); }
      return;
    }
    if (S.phase !== 'play' && S.phase !== 'over') return;
    var i, hit = null;
    for (i = 0; i < HIT.length; i++) { var h = HIT[i]; if (x >= h.x && x <= h.x + h.w && y >= h.y && y <= h.y + h.h) { hit = h; break; } }
    var cur = S.selA >= 0 ? armyById(S.selA) : null;
    if (hit && hit.fight) {
      var fa = armyById(hit.fight), fd = armyById(hit.fdef), mm = fa && fa.owner === S.player ? fa : fd && fd.owner === S.player ? fd : null;
      if (mm) { S.selA = mm.id; S.selP = mm.prov; S.selF = ''; } else { S.selA = -1; S.selP = fa ? fa.prov : -1; }
      SFX.click(); render(); return;
    }
    if (hit && hit.front) { S.selF = hit.front; S.selA = -1; S.selP = -1; SFX.click(); render(); return; }
    if (hit) {
      var ar = armyById(hit.id);
      if (S.multiMode && ar && ar.owner === S.player) { toggleMulti(ar.id); return; }
      if (ar && ar.owner === S.player) { S.selA = ar.id; S.selP = ar.prov; SFX.click(); render(); return; }
      if (ar && cur && S.phase === 'play') { orderMove(cur, ar.prov); return; }
      if (ar) { S.selA = -1; S.selP = ar.prov; render(); return; }
    }
    var pid = pidAt((x - V.tx) / V.s, (y - V.ty) / V.s);
    S.selF = '';
    if (pid < 0) { S.selA = -1; S.selP = -1; render(); return; }
    if (S.multiMode && S.phase === 'play') {
      var arms = selSet();
      if (arms.length) { var okn = groupOrder(arms, pid, S.sync !== false); SFX.order(); toast(okn ? 'Приказ получили ' + okn + ' из ' + arms.length + ' армий' + (S.sync !== false && okn > 1 ? ' (синхронно)' : '') + '.' : 'Ни одна армия не может дойти туда.', okn ? 'good' : 'warn'); S.selP = pid; render(); return; }
      S.selP = pid; render(); return;
    }
    if (cur && S.phase === 'play') {
      if (pid === cur.prov) { S.selA = -1; S.selP = pid; render(); return; }
      orderMove(cur, pid); S.selP = pid; render(); return;
    }
    S.selP = S.selP === pid ? -1 : pid; S.selA = -1; SFX.click(); render();
  }

  /* ---------- pointer / wheel ---------- */
  var ptrs = {}, nptr = 0, gest = null;
  function localXY(e) { var r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function pinchInfo() { var k = Object.keys(ptrs), a = ptrs[k[0]], b = ptrs[k[1]]; return { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2 }; }
  canvas.addEventListener('pointerdown', function (e) {
    try { canvas.setPointerCapture(e.pointerId); } catch (er) { /* ignore */ }
    var p = localXY(e);
    ptrs[e.pointerId] = { x: p.x, y: p.y }; nptr = Object.keys(ptrs).length;
    if (nptr === 1) gest = { sx: p.x, sy: p.y, tx: V.tx, ty: V.ty, moved: false, multi: false };
    else if (nptr === 2) { var pi = pinchInfo(); gest = { multi: true, moved: true, d0: pi.d, s0: V.s, wx: (pi.cx - V.tx) / V.s, wy: (pi.cy - V.ty) / V.s }; }
  });
  canvas.addEventListener('pointermove', function (e) {
    if (!ptrs[e.pointerId] || !gest) return;
    var p = localXY(e); ptrs[e.pointerId] = { x: p.x, y: p.y };
    if (nptr >= 2 && gest.multi) {
      var pi = pinchInfo();
      V.s = clamp(gest.s0 * pi.d / gest.d0, V.min, V.max); V.tx = pi.cx - gest.wx * V.s; V.ty = pi.cy - gest.wy * V.s; clampView(); draw();
    } else if (nptr === 1 && !gest.multi) {
      var dx = p.x - gest.sx, dy = p.y - gest.sy;
      if (!gest.moved && Math.hypot(dx, dy) > 6) gest.moved = true;
      if (gest.moved) { V.tx = gest.tx + dx; V.ty = gest.ty + dy; clampView(); draw(); }
    }
  });
  function endPtr(e) {
    if (!ptrs[e.pointerId]) return;
    var p = localXY(e), g = gest;
    delete ptrs[e.pointerId]; nptr = Object.keys(ptrs).length;
    if (nptr === 0) { if (g && !g.moved && !g.multi && e.type === 'pointerup') onTap(p.x, p.y); gest = null; }
    else if (nptr === 1) { var k = Object.keys(ptrs)[0]; gest = { sx: ptrs[k].x, sy: ptrs[k].y, tx: V.tx, ty: V.ty, moved: true, multi: false }; }
  }
  canvas.addEventListener('pointerup', endPtr);
  canvas.addEventListener('pointercancel', endPtr);
  canvas.addEventListener('wheel', function (e) { e.preventDefault(); var p = localXY(e); zoomAt(p.x, p.y, Math.exp(-e.deltaY * 0.0016)); }, { passive: false });

  /* ---------- fullscreen ---------- */
  function isFs() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }
  function toggleFs() {
    var el = $('app'), res;
    try {
      if (isFs()) res = (document.exitFullscreen || document.webkitExitFullscreen).call(document);
      else res = (el.requestFullscreen || el.webkitRequestFullscreen).call(el);
      if (res && res.catch) res.catch(function () { toast('Полный экран недоступен в этом окне.', 'warn'); });
    } catch (e) { toast('Полный экран недоступен в этом окне.', 'warn'); }
  }
  function fsUi() { $('bFs').innerHTML = ico(isFs() ? 'fsx' : 'fs'); setTimeout(function () { resize(); draw(); }, 80); }

  /* ---------- actions ---------- */
  function act(name, el) {
    var d = el.dataset || {};
    switch (name) {
      case 'menu': openView('menu'); break;
      case 'close': closeView(); break;
      case 'view': openView(d.v); break;
      case 'gen':
        var si = $('seedIn'); if (si) ST.seed = si.value.trim(); saveSettings();
        if (GENB) break; GENB = true; toast('Создаю карту…', 'good');
        setTimeout(function () { try { newMap(ST.seed); S.ui.view = null; fitView(); render(); SFX.click(); } finally { GENB = false; } }, 40); break;
      case 'reroll': newMap(''); fitView(); render(); break;
      case 'new': ST.seed = ''; newMap(''); fitView(); render(); break;
      case 'pick': S.pickC = +d.c; SFX.click(); render(); break;
      case 'begin': if (S.pickC >= 0) { startGame(); if (!ST.tutDone) setTimeout(function () { tutShow(0); }, 400); } break;
      case 'armyMore': S.ui.armyMore = !S.ui.armyMore; render(); break;
      case 'dipf': S.ui.dipF = d.v; renderOverlay(); break;
      case 'logf': S.ui.logF = d.v; renderOverlay(); break;
      case 'tutor': closeView(); tutShow(0); break;
      case 'end': endTurn(); break;
      case 'next': selectNextIdle(); break;
      case 'sel': var a = armyById(+d.id); if (a) { if (S.multiMode) { toggleMulti(a.id); break; } S.selA = a.id; S.selP = a.prov; S.selF = ''; S.ui.view = null; SFX.click(); render(); } break;
      case 'depot': var dpp = S.provs[S.selP >= 0 ? S.selP : (armyById(S.selA) || {}).prov]; if (dpp && canBuildDepot(dpp)) { buildDepot(dpp); SFX.recruit(); toast('Склад построен: ' + dpp.name, 'good'); saveGame(); render(); } break;
      case 'cgen': var ga = armyById(S.selA); if (ga) { cycleGen(ga); SFX.click(); render(); } break;
      case 'stance': var sa = armyById(S.selA); if (sa) { sa.stance = d.v; if (d.v !== 'atk') sa.route = []; if (d.v === 'hold') sa.dug = sa.dug || 0; render(); } break;
      case 'fallback': var fa = armyById(S.selA); if (fa) { if (!fallback(fa)) toast('Отходить некуда.', 'warn'); else SFX.order(); render(); } break;
      case 'toFront': var ta = armyById(S.selA); if (ta) { if (!reserveTarget(ta)) toast('Опасных участков не найдено.'); else SFX.order(); render(); } break;
      case 'sync': S.sync = S.sync === false; render(); break;
      case 'mstance': selSet().forEach(function (x) { x.stance = d.v; if (d.v !== 'atk') x.route = []; }); render(); break;
      case 'mstop': selSet().forEach(function (x) { x.route = []; x.wait = 0; }); render(); break;
      case 'mfall': var nfb = 0; selSet().forEach(function (x) { if (fallback(x)) nfb++; }); toast(nfb ? 'Отвод: ' + nfb + ' арм.' : 'Отходить некуда.'); render(); break;
      case 'mmerge': var ms = selSet(), seenP = {}; ms.forEach(function (x) { if (!seenP[x.prov] && armyById(x.id)) { seenP[x.prov] = 1; mergeAt(x.id, ms.filter(function (y) { return y.prov === x.prov; }).map(function (y) { return y.id; })); } }); S.multi = S.multi.filter(function (i) { return armyById(i); }); render(); break;
      case 'gsave': S.groups[d.n] = S.multi.slice(); toast('Группа ' + d.n + ' сохранена.', 'good'); render(); break;
      case 'grecall': S.multiMode = true; S.multi = (S.groups[d.n] || []).filter(function (i) { return armyById(i); }); S.selA = -1; render(); break;
      case 'front': S.selF = d.id; S.selA = -1; S.selP = -1; S.layer = 'mil'; render(); break;
      case 'fo': var ff = frontById(S.selF); if (ff) { var nn = frontOrder(ff, d.v); toast(nn ? 'Приказ получили ' + nn + ' арм.' : 'Некому отдавать приказ.', nn ? 'good' : 'warn'); SFX.order(); render(); } break;
      case 'rep': S.ui.rep = +d.id; openView('rep'); break;
      case 'selp': S.selA = -1; S.selP = +d.id; render(); break;
      case 'rebDeal': rebDeal(+d.d, d.kind); saveGame(); render(); openView('dip'); break;
      case 'recruit':
        var p = S.provs[S.selP >= 0 ? S.selP : (armyById(S.selA) || {}).prov];
        if (p && p.owner === S.player && canRecruit(p)) { var na = recruit(p); SFX.recruit(); toast('Войска набраны: ' + p.name, 'good'); hint('rec', 'новая армия стоит на месте набора. Выбери её и тапни соседнюю провинцию, чтобы идти.'); if (na) { S.selA = na.id; S.selP = p.id; } saveGame(); render(); }
        break;
      case 'blk': var ba = armyById(S.selA); if (ba && ba.owner === S.player && S.provs[ba.prov].sea && !ba.route.length) { ba.blk = !ba.blk; S.rtSig = null; if (ba.blk) { var cn = routes().filter(function (r) { return r.cutBy === ba.owner && r.pp.zones.indexOf(ba.prov) >= 0; }).length; toast(cn ? 'Блокада: перерезано путей — ' + cn + '. Недовольные державы потребуют снять её.' : 'Блокада объявлена, но чужих путей здесь нет.', cn ? 'warn' : ''); SFX.order(); } else toast('Блокада снята.'); render(); } break;
      case 'cancel': var ca = armyById(S.selA); if (ca) { ca.route = []; ca.eng = null; render(); } break;
      case 'mode': var ma_ = armyById(S.selA); if (ma_) { ma_.mode = d.v; SFX.click(); render(); } break;
      case 'mmode': selSet().forEach(function (x) { x.mode = d.v; }); SFX.click(); render(); break;
      case 'fdev': var dvp = S.provs[S.selP >= 0 ? S.selP : (armyById(S.selA) || {}).prov]; if (dvp && canDevelop(dvp)) { develop(dvp); SFX.recruit(); toast('Население растёт: ' + dvp.name, 'good'); saveGame(); render(); } break;
      case 'pol': var pp0 = S.provs[S.selP]; if (pp0 && pp0.owner === S.player && !pp0.sea) { pp0.pol = +d.v; if (pp0.pol === 3) toast('Депортация: агрессия будет быстро расти.', 'warn'); saveGame(); render(); } break;
      case 'tstart': if (techStart(S.player, d.id)) { SFX.recruit(); saveGame(); render(); renderOverlay(); } break;
      case 'trush': var ts0 = S.tech[S.player]; if (ts0.cur && S.gold[S.player] >= 15) { S.gold[S.player] -= 15; ts0.prog += 10; saveGame(); render(); renderOverlay(); } break;
      case 'evo': resolveEv(+d.i); break;
      case 'fs': toggleFs(); closeView(); break;
      case 'law': if (lawSet(S.player, +d.k, +d.v)) { saveGame(); render(); renderOverlay(); } break;
      case 'fbuild': var fbp = S.provs[S.selP >= 0 ? S.selP : (armyById(S.selA) || {}).prov]; if (fbp && canBuildFac(fbp)) { buildFac(fbp, d.t); SFX.recruit(); toast('Завод построен: ' + fbp.name, 'good'); saveGame(); render(); } break;
      case 'frepair': var frp = S.provs[S.selP >= 0 ? S.selP : (armyById(S.selA) || {}).prov]; if (frp && canRepair(frp)) { repairFac(frp); SFX.recruit(); toast('Цех восстановлен: ' + frp.name, 'good'); saveGame(); render(); } break;
      case 'met': S.ui.met = +d.v; render(); break;
      case 'cont': S.phase = 'play'; S.cont = true; S.busy = false; S.ui.view = null; toast('Игра продолжается: победа засчитана, добивай остальных.', 'good'); saveGame(); render(); break;
      case 'merge': mergeAt(S.selA); break;
      case 'undo': undoOrder(); break;
      case 'split': splitDialog(armyById(S.selA)); break;
      case 'dip': dipAct(d.k, +d.c); break;
      case 'em': emAct(d.k); break;
      case 'emoff': emOff(d.k); break;
      case 'netsel': S.ui.netC = +d.c; renderOverlay(); break;
      case 'netm': S.ui.netM = d.v; renderOverlay(); break;
      case 'netgeo': S.ui.netG = !S.ui.netG; renderOverlay(); break;
      case 'devpick': ST.device = d.v; saveSettings(); applyUi(); resize(); fitView();
        if (d.v === 'phone') { try { if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(function () { /* нужен полный экран */ }); } catch (e) { /* ignore */ } if (window.innerHeight > window.innerWidth) toast('Поверни телефон горизонтально: так удобнее.', 'good'); }
        openView('menu'); draw(); break;
      case 'hsec': clearTimeout(HST); HSN++; HST = setTimeout(function () { HSN = 0; }, 1500); if (HSN >= 5) { HSN = 0; if (!ST.codeBtn) { ST.codeBtn = true; saveSettings(); toast('Открыт раздел «Коды».', 'good'); } renderOverlay(); } break;
      case 'codego': var ci0 = $('codeIn'), cv = ci0 ? ci0.value.trim() : ''; if (cv === DEVCODE) { ST.dev = true; saveSettings(); toast('Режим разработчика включён.', 'good'); openView('dev'); } else toast('Неверный код.', 'bad'); break;
      case 'devoff': ST.dev = false; ST.devGold = false; ST.devFog = false; saveSettings(); rasterDirty = true; toast('Режим разработчика выключен.', 'good'); render(); break;
      case 'dv': devAct(d.k, d.v); break;
      case 'tog':
        if (d.k === 'noside') { togglePanel(); break; }
        ST[d.k] = !ST[d.k]; saveSettings();
        if (d.k === 'fog' || d.k === 'real' || d.k === 'rFog' || d.k === 'devFog') rasterDirty = true;
        if (d.k === 'mini') drawMini(true);
        if (d.k === 'newbie') applyUi();
        if (d.k === 'sound' && ST.sound) SFX.order();
        render(); break;
      case 'tax': if (S.phase === 'play' && !S.busy) { S.tax[S.player] = +d.v; saveGame(); render(); } break;
      case 'spyop':
        if (S.phase === 'play' && !S.busy && S.ui.spy >= 0 && !spyBlock(d.k, S.player, S.ui.spy)) {
          var sres = spyDo(S.player, S.ui.spy, d.k);
          if (sres.ok) S.xs.spyN = (S.xs.spyN || 0) + 1;
          S.ui.spyMsg = sres.msg; S.ui.spyOk = sres.ok;
          log('Разведка · ' + CNAMES[S.ui.spy] + ': ' + sres.msg, true, -1, 'dipl');
          SFX.order(); saveGame(); render();
        }
        break;
      case 'ransom':
        if (S.phase === 'play' && !S.busy && S.gold[S.player] >= 15 && pirAt(+d.z)) {
          S.gold[S.player] -= 15; S.pir = S.pir.filter(function (q) { return q.z !== +d.z; }); S.rtSig = null;
          toast('Пираты получили откуп и ушли.', 'good'); log('Откуп пиратам в зоне «' + S.provs[+d.z].name + '».', true, -1, 'sys'); saveGame(); render();
        }
        break;
      case 'daily': var dn0 = new Date(), dn1 = ('0' + dn0.getDate()).slice(-2), dn2 = ('0' + (dn0.getMonth() + 1)).slice(-2); ST.seed = 'день-' + dn0.getFullYear() + '-' + dn2 + '-' + dn1; saveSettings(); renderOverlay(); toast('Зерно дня: ' + ST.seed, 'good'); break;
      case 'stab':
        ST.tab = d.v; saveSettings(); renderOverlay();
        var sbd = $('sheet').querySelector('.sh-body'); if (sbd) sbd.scrollTop = 0;
        break;
      case 'rset':
        var kp = { np: ST.np, nc: ST.nc, seed: ST.seed, tab: ST.tab }, kk2;
        for (kk2 in DEF) ST[kk2] = DEF[kk2];
        for (kk2 in kp) ST[kk2] = kp[kk2];
        saveSettings(); applyUi(); readTheme(); rasterDirty = true; resize(); render(); toast('Настройки сброшены.', 'good'); break;
      case 'seg':
        var v = d.v; if (/^\d+$/.test(v)) v = +v; ST[d.k] = v; saveSettings();
        if (d.k === 'device') { applyUi(); resize(); fitView(); }
        if (d.k === 'theme' || d.k === 'uiStyle') { applyUi(); setTimeout(function () { readTheme(); render(); }, 30); }
        if (d.k === 'vol') SFX.order();
        if (d.k === 'light') { rasterDirty = true; drawMini(true); tradeKick(); }
        render(); break;
      case 'load': var lr = loadGame(); if (lr === true) { fitView(); S.selP = capitalOf(S.player); centerOn(S.selP, 1.4); S.ui.view = null; render(); toast('Игра загружена.', 'good'); } else toast(lr === 'old' ? 'Сохранение из старой версии: карта изменилась (моря), оно несовместимо.' : 'Не удалось загрузить сохранение.', 'bad'); break;
      case 'goto': closeView(); S.selA = -1; S.selP = +d.id; centerOn(+d.id, Math.max(V.s, 1.4)); render(); break;
    }
  }
  $('app').addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!t || t.disabled) return;
    act(t.getAttribute('data-act'), { dataset: t.dataset });
    musicSync();
  });
  $('ov').addEventListener('click', function (e) { if (e.target === $('ov')) closeView(); });
  $('bMenu').addEventListener('click', function () { openView('menu'); });
  $('bDip').addEventListener('click', function () { if (S.phase === 'play') openView('dip'); else openView('menu'); });
  $('bTech').addEventListener('click', function () { if (S.phase === 'play') openView('tech'); else openView('menu'); });
  function togglePanel() {
    var w0 = stage.clientWidth, h0 = stage.clientHeight;
    ST.noside = !ST.noside; saveSettings(); render(); resize();
    V.tx += (stage.clientWidth - w0) / 2; V.ty += (stage.clientHeight - h0) / 2; draw();
  }
  $('bPanel').addEventListener('click', togglePanel);
  $('fabEnd').addEventListener('click', function () { if (S && S.phase === 'play' && !S.busy) endTurn(); });
  $('bGen').addEventListener('click', function () { if (S.phase === 'play') openView('gen'); else openView('menu'); });
  $('bEnd').addEventListener('click', function () { if (S.phase === 'play') openView('end'); else openView('menu'); });
  $('pills').addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-go]') : null;
    if (!t || !S || S.phase !== 'play') return;
    var g = t.getAttribute('data-go');
    if (g === 'eco') { S.layer = S.layer === 'eco' ? 'pol' : 'eco'; render(); }
    else if (g === 'army') { S.selA = -1; S.selP = -1; S.multiMode = false; render(); }
    else if (g === 'end') openView('end');
  });
  $('bLog').addEventListener('click', function () { if (S.phase === 'play') openView('log'); else openView('menu'); });
  $('bFs').addEventListener('click', toggleFs);
  $('bMulti').addEventListener('click', function () { if (S.phase === 'play') setMulti(!S.multiMode); });
  $('bLay').addEventListener('click', function () { if (S.phase === 'play') cycleLayer(); });
  $('zIn').addEventListener('click', function () { zoomAt(stage.clientWidth / 2, stage.clientHeight / 2, 1.35); });
  $('zOut').addEventListener('click', function () { zoomAt(stage.clientWidth / 2, stage.clientHeight / 2, 1 / 1.35); });
  $('zFit').addEventListener('click', function () { fitView(); draw(); });
  document.addEventListener('fullscreenchange', fsUi);
  document.addEventListener('webkitfullscreenchange', fsUi);
  document.addEventListener('keydown', function (e) {
    if (!S || e.ctrlKey || e.metaKey || e.altKey) return;
    var tg = e.target && e.target.tagName;
    if (tg === 'INPUT' || tg === 'TEXTAREA') { if (e.key === 'Escape') e.target.blur(); return; }
    var k = e.key;
    if (k === 'Escape') { if (S.ui.view) closeView(); else { S.selA = -1; S.selP = -1; render(); } return; }
    if (S.ui.view) return;
    if (k === ' ' || k === 'Enter') { if (tg === 'BUTTON') return; e.preventDefault(); if (S.phase === 'play') endTurn(); }
    else if (k === 'n' || k === 'N' || k === 'т' || k === 'Т') { if (S.phase === 'play') selectNextIdle(); }
    else if (k === 'd' || k === 'D' || k === 'в' || k === 'В') { if (S.phase === 'play') openView('dip'); }
    else if (k === 'p' || k === 'P' || k === 'з' || k === 'З') { togglePanel(); }
    else if (k === 'r' || k === 'R' || k === 'к' || k === 'К') { if (S.phase === 'play') openView('tech'); }
    else if (k === 'j' || k === 'J' || k === 'о' || k === 'О') { if (S.phase === 'play') openView('log'); }
    else if (k === 'm' || k === 'M' || k === 'ь' || k === 'Ь') { if (S.phase === 'play') setMulti(!S.multiMode); }
    else if (k === 'l' || k === 'L' || k === 'д' || k === 'Д') { if (S.phase === 'play') cycleLayer(); }
    else if (k >= '1' && k <= '3') { if (S.phase === 'play' && S.groups[k]) act('grecall', { dataset: { n: k } }); }
    else if (k === 'z' || k === 'Z' || k === 'я' || k === 'Я') { if (S.phase === 'play') undoOrder(); }
    else if (k === 's' || k === 'S' || k === 'ы' || k === 'Ы') { if (S.phase === 'play') splitDialog(armyById(S.selA)); }
    else if (k === 'u' || k === 'U' || k === 'г' || k === 'Г') { var ua = armyById(S.selA); if (S.phase === 'play' && ua && ua.owner === S.player && !S.busy && armiesAt(ua.prov).some(function (x) { return x.owner === ua.owner && x !== ua; })) mergeAt(ua.id); }
    else if (k === 'f' || k === 'F' || k === 'а' || k === 'А') toggleFs();
    else if (k === '+' || k === '=') zoomAt(stage.clientWidth / 2, stage.clientHeight / 2, 1.3);
    else if (k === '-' || k === '_') zoomAt(stage.clientWidth / 2, stage.clientHeight / 2, 1 / 1.3);
    else if (k === '0') { fitView(); draw(); }
  });

  /* ---------- init ---------- */
  function init() {
    applyUi(); readTheme();
    $('mdDip').innerHTML = ico('globe'); $('mdNext').innerHTML = ico('next'); $('mdLog').innerHTML = ico('log');
    $('mdDip').addEventListener('click', function () { openView('dip'); }); $('mdNext').addEventListener('click', function () { selectNextIdle(); }); $('mdLog').addEventListener('click', function () { openView('log'); });
    $('bMenu').innerHTML = ico('menu'); $('bDip').innerHTML = ico('globe') + '<span>Дипломатия</span>'; $('bLog').innerHTML = ico('log') + '<span>Журнал</span>'; $('bTech').innerHTML = ico('flask') + '<span>Наука</span>'; $('bPanel').innerHTML = ico('panel'); $('bGen').innerHTML = ico('star') + '<span>Генералы</span>'; $('bEnd').innerHTML = ico('flag') + '<span>Итоги</span>';
    $('bMulti').innerHTML = ico('select'); $('bLay').innerHTML = ico('layers'); $('zIn').innerHTML = ico('plus'); $('zOut').innerHTML = ico('minus'); $('zFit').innerHTML = ico('fit');
    var fsOk = document.fullscreenEnabled || document.webkitFullscreenEnabled;
    if (!fsOk) $('bFs').hidden = true; else $('bFs').innerHTML = ico('fs');
    resize();
    newMap(ST.seed);
    fitView();
    S.ui.view = ST.device ? 'menu' : 'device';
    render();
    var wasLand = stage.clientWidth > stage.clientHeight;
    if (typeof ResizeObserver === 'function') new ResizeObserver(function () {
      var nl = stage.clientWidth > stage.clientHeight;
      resize();
      if (nl !== wasLand && S) { wasLand = nl; fitView(); draw(); }
    }).observe(stage);
    window.addEventListener('resize', function () { resize(); });
    try { var mq = window.matchMedia('(prefers-color-scheme: dark)'); var h = function () { if (ST.theme === 'auto') { readTheme(); render(); } }; if (mq.addEventListener) mq.addEventListener('change', h); } catch (e) { /* ignore */ }
    setInterval(function () { if (lite() && (LD.k = !LD.k)) return; if (S && !ANIM && S.phase === 'play' && !document.hidden && !S.ui.view && activeFights().length) draw(performance.now()); }, 120);
    var tries = 0;
    (function waitSize() { if (stage.clientWidth < 10 && tries++ < 30) { setTimeout(waitSize, 60); return; } resize(); fitView(); draw(); })();
  }
  init();
