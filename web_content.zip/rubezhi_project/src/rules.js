  /* ---------- rules helpers ---------- */
  function gcap(p) { return SETT[p.set].garr + (p.capital ? 40 : 0); }
  function popCap(p) { if (ST.nocap) return 1e9; return SETT[p.set].cap + (p.capital ? 30 : 0) + (p.dev || 0) * 6 + (p.civ || 0) * 2; }
  function sIdx() { return ST.seasons ? (S.round - 1) % 4 : -1; }
  function atkMult() { var s = sIdx(); return s === 1 ? 1.2 : s === 3 ? 0.9 : 1; }
  function winterDef() { return sIdx() === 3 ? 1.3 : 1; }
  function speedMult() { var s = sIdx(); return s === 3 ? 0.8 : s === 0 ? 0.9 : 1; }
  function recCostFor(n) { return sIdx() === 0 ? Math.ceil(n * 0.8) : n; }
  function fortOf(p) { return (p.capital ? 1.3 : 1) * (p.set === 2 ? 1.2 : 1); }
  function defMultP(p) { return TER[p.terrain].def * fortOf(p) * winterDef() * emDef(p.owner, true); }
  function pidAt(x, y) { x = Math.floor(x); y = Math.floor(y); if (x < 0 || y < 0 || x >= W || y >= H) return -1; return MAP.pid[y * W + x]; }
  var OC = null;
  function owned(c) {
    if (!OC || OC.p !== S.provs) { OC = { p: S.provs, a: [] }; for (var i = 0; i < NC; i++) OC.a.push([]); S.provs.forEach(function (p) { if (p.owner >= 0 && OC.a[p.owner]) OC.a[p.owner].push(p); }); }
    return OC.a[c] || [];
  }
  function pIncome(p) {
    if (!(p.sup && !(p.occ > 0)) || p.reb > 0) return 0;
    var v = Math.round(p.pop * 0.09 * (1 - (p.unr || 0) / 150) * TAXM[taxLvl(p.owner)]) + TER[p.terrain].inc + (p.capital ? 3 : 0);
    if (p.res === 0) v += 1; else if (p.res === 2) v += 4; else if (p.res === 3) v += 2;
    if (p.aut > 0) v = Math.floor(v / 2);
    return v;
  }
  function aiIncMult(c) { return c === S.player ? 1 : ({ easy: 0.8, normal: 1, hard: 1.2 }[ST.ai] || 1); }
  function income(c) { var t = 0; owned(c).forEach(function (p) { t += pIncome(p); }); return Math.round((t + tradeBonus(c) + indGold(c)) * (1 + tk(c, 'inc')) * (1 - warPen(c)) * emInc(c)); }
  function troopsOf(c) { var t = 0; S.armies.forEach(function (a) { if (a.owner === c) t += a.troops; }); return t; }
  function upkeep(c) {
    if (!RL('rUp')) return Math.floor(troopsOf(c) / 45 * (1 - tk(c, 'upk')));
    var t = 0;
    S.armies.forEach(function (a) { if (a.owner !== c) return; var q = S.provs[a.prov]; t += a.troops * (!q.sea && q.owner !== c && !isAlly(c, q.owner) ? 1.4 : 1); });
    return Math.floor(t / 45 * 2 * (1 - tk(c, 'upk')));
  }
  function warPen(c) { return RL('rWar') && S.weary ? clamp(S.weary[c] / 100 * 0.3, 0, 0.3) : 0; }
  function warAge(a, b) { var s = S.wsince && S.wsince[Math.min(a, b) + '_' + Math.max(a, b)]; return s == null ? 99 : S.round - s; }
  function warWeary() {
    if (!S.weary) { S.weary = zeros(); S.cas = zeros(); }
    for (var c = 0; c < NC; c++) {
      if (!owned(c).length) { S.weary[c] = 0; continue; }
      var prev = S.weary[c], cas = S.cas[c] || 0;
      if (warEnemies(c).length) S.weary[c] = Math.min(100, prev + 0.7 + Math.min(5, cas / 12));
      else S.weary[c] = Math.max(0, prev - 3);
      S.cas[c] = 0;
      if (!RL('rWar')) continue;
      var w = S.weary[c];
      if (w > 40) owned(c).forEach(function (q) { if ((q.unr || 0) < 60) q.unr = Math.min(60, (q.unr || 0) + (w - 40) / 25); });
      if (c === S.player) {
        if (prev < 50 && w >= 50) news('dem', 'Усталость от войны', 'Народ измотан (' + r0(w) + '%): доход падает, растёт недовольство. Подумай о мире.', 'dip');
        else if (prev < 80 && w >= 80) news('dem', 'Страна на пределе', 'Усталость от войны ' + r0(w) + '%. Доход упал, люди недовольны. Заключи мир!', 'dip');
      }
    }
  }
  function popNeed(n) { return RL('rMan') ? Math.ceil(n * 2.2) + 8 : n + 6; }
  function popCost(n) { return Math.ceil(n * (RL('rMan') ? 1.2 : 0.5)); }
  function payTroops(c) {
    var n = 0;
    S.armies.forEach(function (a) { if (a.owner === c) { a.troops = Math.max(5, a.troops - Math.ceil(a.troops * 0.08)); a.org = Math.max(8, a.org - 10); n++; } });
    if (n && c === S.player) { news('dem', 'Казна пуста', 'Войска не получают жалованье и разбегаются (−8% за ход). Подними доход или распусти часть армий.', null); log('Казна пуста: армии теряют людей из-за неуплаты.', true, -1, 'sys'); }
  }
  function popFmt(n) { n = Math.round(n); if (!ST.popK) return '' + n; if (n >= 1000) return (n / 1000).toFixed(n >= 10000 ? 0 : 1).replace('.', ',').replace(',0', '') + ' млн'; return n + 'к'; }
  var TUT = [
    ['Карта и провинции', 'Тапни провинцию — увидишь население, доход, гарнизон. Колесо или щипок меняют масштаб, перетаскивание двигает карту.', 'zFit'],
    ['Армии', 'Выбери свою армию (жетон на карте), затем тапни соседнюю провинцию — армия пойдёт туда. Чужую провинцию она начнёт осаждать.', ''],
    ['Золото и найм', 'Доход считается с провинций. В своей провинции с снабжением можно нанять войска кнопкой «Нанять» — это стоит золота.', ''],
    ['Конец хода', 'Отдав приказы, жми «Конец хода». Все державы ходят одновременно, потом бои и осады разыгрываются разом.', 'fabEnd'],
    ['Дипломатия', 'Мир, союз, торговля и война — в «Дипломатии». Союзники пускают армии через земли и делятся снабжением.', 'bDip'],
    ['Недовольство', 'Чужой народ в провинции копит недовольство. Введи политику или держи гарнизон: иначе начнётся мятеж, доход обнулится, проход закроется.', 'bLay']
  ];
  function tutStop(done) { var t = document.getElementById('tut'); if (t) t.remove(); Array.prototype.forEach.call(document.querySelectorAll('.tuthl'), function (e) { e.classList.remove('tuthl'); }); if (done) { ST.tutDone = true; saveSettings(); } }
  function tutShow(i) {
    tutStop(false);
    if (i >= TUT.length) { tutStop(true); return; }
    var st = TUT[i], w = document.createElement('div'); w.id = 'tut'; w.className = 'tut';
    w.innerHTML = '<span class="tn">Обучение ' + (i + 1) + ' / ' + TUT.length + '</span><b>' + st[0] + '</b><p>' + st[1] + '</p><div class="row"><button class="btn sm primary" type="button" id="tutNx">' + (i + 1 < TUT.length ? 'Дальше' : 'Готово') + '</button><button class="btn sm" type="button" id="tutSk">Пропустить</button></div>';
    document.body.appendChild(w);
    if (st[2]) { var el = document.getElementById(st[2]); if (el && !el.hidden) el.classList.add('tuthl'); }
    w.querySelector('#tutNx').addEventListener('click', function () { tutShow(i + 1); });
    w.querySelector('#tutSk').addEventListener('click', function () { tutStop(true); });
  }
  function lite() { return ST.light === 'on' || (ST.light === 'auto' && typeof NP !== 'undefined' && NP >= 100); }
  function shipsOn() { return ST.ships && !lite(); }
  function hint(k, text) { try { if (!ST.hints) ST.hints = {}; if (ST.hints[k] || (ST.tips === false && !ST.newbie)) return; ST.hints[k] = 1; saveSettings(); toast('Подсказка: ' + text, 'good'); } catch (e) { /* ignore */ } }
  function gl(k, n) { if (!S.glob) S.glob = { bat: 0, war: 0, hun: 0, epi: 0, uns: 0, ref: 0 }; if (n > 0) S.glob[k] = (S.glob[k] || 0) + n; }
  function popLose(p, n, k) { n = Math.min(Math.max(0, n), Math.max(0, p.pop - 2)); p.pop -= n; gl(k, n); }
  function popOf(c) { var t = 0; owned(c).forEach(function (p) { t += p.pop; }); return t; }
  function sanc(c) { return 1 - Math.min(0.25, (S.inf ? S.inf[c] : 0) / 200); }
  function netIncome(c) { return Math.floor(income(c) * (sIdx() === 2 ? 1.5 : 1) * aiIncMult(c) * sanc(c)) - upkeep(c); }
  function log(text, mine, prov, kind) { var e = { t: text, m: !!mine, r: S.round, p: prov == null ? -1 : prov, k: kind || '' }; S.chron.push(e); if (S.chron.length > 120) S.chron.shift(); return e; }
  function toastMine(msg, kind) { toast(msg, kind); }
  /* ---------- sea, industry, stats ---------- */
  function seaKey(a, b) { return a < b ? a + '_' + b : b + '_' + a; }
  function isSeaLink(a, b) { return false; }
  function linkCost(a, b) { var A = S.provs[a], B = S.provs[b]; if (!A.sea && B.sea) return 0.3; if (A.sea && !B.sea) return 0.6; return 0; }
  function seaPath(l) { if (!l.path) { var pp = new Path2D(); pp.moveTo(l.x1, l.y1); pp.quadraticCurveTo(l.cx, l.cy, l.x2, l.y2); l.path = pp; } return l.path; }
  function seaMid(l) { return [0.25 * l.x1 + 0.5 * l.cx + 0.25 * l.x2, 0.25 * l.y1 + 0.5 * l.cy + 0.25 * l.y2]; }
  function zeros() { var z = []; for (var i = 0; i < NC; i++) z.push(0); return z; }
  function initExtra() {
    S.eq = zeros().map(function () { return 40; }); S.eqD = zeros(); S.hist = [];
    S.glob = { bat: 0, war: 0, hun: 0, epi: 0, uns: 0, ref: 0 }; S.stat = { kills: zeros(), lost: zeros(), caps: zeros(), capL: zeros(), bat: zeros(), dest: zeros(), built: zeros(), dmg: zeros() };
    S.keyEv = []; S.cont = false; S.why = ''; S.ui.met = 0; S.calm = ST.calm || 0; S.inf = zeros(); S.infLvl = 0; S.just = {}; S.fabs = []; S.allyCd = 0; S.pend = null; S.bcb = {}; S.blk = {}; S.blkCd = {}; S.rt = null; S.rtSig = null; S.law = zeros().map(function () { var r = Math.random(); return [r < 0.5 ? 0 : (Math.random() < 0.5 ? 1 : 2), Math.random() < 0.5 ? 0 : (Math.random() < 0.5 ? 1 : 2), Math.random() < 0.5 ? 0 : (Math.random() < 0.5 ? 1 : 2)]; });
    S.em = zeros().map(function () { return {}; }); S.emCd = zeros().map(function () { return {}; }); S.weary = zeros(); S.cas = zeros(); S.wsince = {}; S.tax = zeros().map(function () { return 1; }); S.pir = []; S.intel = {}; S.spyCd = {}; S.xs = { spyN: 0, pirK: 0, misDone: [] }; S.lawCd = zeros().map(function () { return [0, 0, 0]; }); S.vic = ST.vic || 'std'; S.limit = 70; S.peaceRun = 0;
    S.tech = zeros().map(function () { return newTech(); });
  }

  // ---- ethnic groups, minority policy, war justification ----
  function initEth(provs) {
    provs.forEach(function (p) {
      if (p.sea) return;
      p.eth = {}; p.pol = 0; p.unr = 0;
      if (p.owner < 0) return;
      p.eth[p.owner] = 1;
      var seen = {};
      (p.lnb || []).forEach(function (n) {
        var q = provs[n];
        if (!q || q.sea || q.owner < 0 || q.owner === p.owner || seen[q.owner]) return;
        seen[q.owner] = 1;
        if (Math.random() < 0.7) p.eth[q.owner] = 0.04 + Math.random() * 0.12;
      });
      normEth(p);
    });
  }
  function normEth(p) {
    var t = 0, k;
    for (k in p.eth) { if (p.eth[k] < 0.004) delete p.eth[k]; else t += p.eth[k]; }
    if (t <= 0) { p.eth = {}; p.eth[p.owner] = 1; return; }
    for (k in p.eth) p.eth[k] /= t;
  }
  function foreignOf(p) { return p.sea || p.owner < 0 ? 0 : 1 - (p.eth[p.owner] || 0); }
  function setForeign(p, nf) {
    var o = p.owner, fo = foreignOf(p), k;
    nf = clamp(nf, 0, 1);
    if (fo <= 0.0001) { return; }
    var f = nf / fo;
    for (k in p.eth) if (+k !== o) p.eth[k] *= f;
    p.eth[o] = 1 - nf;
    normEth(p);
  }
  function ethStr(p) {
    var arr = [], k;
    for (k in p.eth) arr.push([+k, p.eth[k]]);
    arr.sort(function (a, b) { return b[1] - a[1]; });
    return arr;
  }
  function ethSave(p) { return Object.keys(p.eth || {}).map(function (k) { return k + ':' + Math.round(p.eth[k] * 1000); }).join(','); }
  function ethLoad(p, s) {
    if (!s) return;
    var e = {}, any = 0;
    String(s).split(',').forEach(function (x) { var a = x.split(':'); if (a.length === 2 && !isNaN(+a[0]) && !isNaN(+a[1])) { e[+a[0]] = +a[1] / 1000; any = 1; } });
    if (any) { p.eth = e; normEth(p); }
  }
  var POLN = ['Без политики', 'Ассимиляция', 'Репрессии', 'Депортация'];
  function rebNb(p, d) { p.nb.forEach(function (n) { var q = S.provs[n]; if (!q.sea && q.owner === p.owner) q.unr = Math.min(100, (q.unr || 0) + d); }); }
  function rebTurn(p, o, us) {
    var T = 0, here = S.armies.filter(function (a) { return a.prov === p.id && a.owner === o; });
    here.forEach(function (a) { T += a.troops; });
    if (!p.reb) {
      if (p.unr >= 90) p.crit = (p.crit || 0) + 1; else p.crit = Math.max(0, (p.crit || 0) - (p.unr < 70 ? 2 : 0.5));
      if (T > 0 && p.unr >= 50) { p.unr = Math.min(100, p.unr + 9); rebNb(p, 3); }
      if (p.crit >= rebNeed(p)) {
        p.reb = 1; p.rebAge = 0; p.crit = 0; p.rebS = Math.max(3, Math.round(p.pop * (0.1 + 0.06 * (p.set || 0)) * (p.capital ? 1.3 : 1)));
        rebNb(p, 12); if (o === us) hint('reb', 'в мятежной провинции нужно держать армию и гарнизон; выкупить мятежников можно в «Дипломатии».');
        if (o === us) news('bad', 'Мятеж в ' + p.name, 'Доход провинции обнулён, проход закрыт. Нужна армия или гарнизон — но давление на соседей растёт.');
      }
      return;
    }
    p.rebAge = (p.rebAge || 0) + 1;
    var dmg = T * 0.25 + p.garrison * 0.1;
    if (o !== us && !T) dmg += Math.max(1, p.rebS * 0.06);
    p.rebS -= dmg;
    if (T > 0) {
      var loss = Math.ceil(Math.min(T * 0.04, p.rebS * 0.15 + 1)); here.forEach(function (a) { var l = Math.min(Math.ceil(loss / here.length), a.troops - 5); if (l > 0) { a.troops -= l; gl('bat', l); } });
      p.unr = Math.min(100, p.unr + 8); rebNb(p, 4);
    } else {
      p.rebS += Math.ceil(p.rebS * 0.05); rebNb(p, p.reb === 2 ? 4 : 2);
      if (p.reb === 1 && p.rebAge >= 8) { p.reb = 2; p.rebS = Math.round(p.rebS * 2.5); if (o === us) news('bad', 'Мятеж окреп в ' + p.name, 'Слабый бунт превратился в организованное восстание.'); }
    }
    if (p.reb > 0 && !T) refugees(p, o, us);
    if (p.reb === 2 && !T && Math.random() < 0.3) {
      var tg2 = p.nb.map(function (n) { return S.provs[n]; }).filter(function (q) { return !q.sea && q.owner === o && !q.reb; });
      if (tg2.length) { var q2 = tg2[(Math.random() * tg2.length) | 0]; q2.garrison = Math.max(0, q2.garrison - Math.ceil(p.rebS * 0.1)); q2.unr = Math.min(100, (q2.unr || 0) + 8); popLose(q2, Math.ceil(q2.pop * 0.02), 'uns'); if (o === us) toast('Повстанцы из ' + p.name + ' совершили набег на ' + q2.name + '.', 'bad'); }
    }
    popLose(p, Math.ceil(p.pop * (p.reb === 2 ? 0.03 : 0.015)), 'uns');
    if (p.rebS <= 0) { p.reb = 0; p.rebS = 0; p.rebAge = 0; p.crit = 0; p.unr = 75; if (o === us) news('good', 'Мятеж подавлен', p.name + ': порядок восстановлен, но недовольство высоко.'); }
  }
  function refugees(p, o, us) {
    var n = Math.min(p.pop - 2, Math.ceil(p.pop * 0.04 * p.reb)); if (n < 1) return;
    var c = p.nb.map(function (i) { return S.provs[i]; }).filter(function (q) { return !q.sea && q.owner >= 0 && !q.reb; });
    if (!c.length) return;
    var q = c[(Math.random() * c.length) | 0];
    p.pop -= n; q.pop += n; gl('ref', n); q.unr = Math.min(100, (q.unr || 0) + (q.pop > popCap(q) ? 3 : 1));
    if (q.owner !== o) {
      if (q.owner < NC && o < NC && Math.random() < 0.25) adjOp(q.owner, o, -2);
      if (q.owner === us) toast('Беженцы из ' + p.name + ' (' + CNAMES[o] + ') нелегально хлынули в ' + q.name + ': +' + popFmt(n) + '.', 'warn');
    } else if (o === us && Math.random() < 0.3) toast('Беженцы из ' + p.name + ' осели в ' + q.name + '.', 'warn');
  }
  function rebDeal(pid, kind) {
    var p = S.provs[pid], us = S.player; if (!p || p.owner !== us || !p.reb) return;
    if (kind === 'pay') { var cost = Math.ceil(10 + p.rebS * (p.reb === 2 ? 1.5 : 1)); if (S.gold[us] < cost) { toast('Нужно ' + cost + ' зол.', 'warn'); return; } S.gold[us] -= cost; p.reb = 0; p.rebS = 0; p.rebAge = 0; p.crit = 0; p.unr = 65; toast('Мятеж в ' + p.name + ' выкуплен за ' + cost + ' зол.', 'good'); }
    else { p.reb = 0; p.rebS = 0; p.rebAge = 0; p.crit = 0; p.unr = 45; p.aut = 15; toast(p.name + ' получила автономию на 15 ходов: доход вдвое меньше.', 'good'); }
  }
  function rebNeed(p) { return 4 + 2 * (p.set || 0) + (p.capital ? 2 : 0); }
  function ethTurn() {
    var us = S.player, told = false;
    S.provs.forEach(function (p) {
      if (p.sea || p.owner < 0) return;
      var o = p.owner, fo = foreignOf(p), k, g;
      if (!p.eth || p.eth[o] === undefined && fo === 0) { p.eth = {}; p.eth[o] = 1; fo = 0; }
      if (fo > 0) {
        if (p.pol === 1) {
          if (S.gold[o] >= 3) { S.gold[o] -= 3; setForeign(p, fo - Math.min(fo, 0.06 * (1 + tk(o, 'ass')))); }
          else { p.pol = 0; if (o === us) toast('Не хватило золота: ассимиляция в ' + p.name + ' остановлена.', 'warn'); }
        } else if (p.pol === 2) {
          setForeign(p, fo - Math.min(fo, 0.012));
          var dead = Math.ceil(p.pop * fo * 0.015); popLose(p, dead, 'uns');
          S.inf[o] += 0.35;
          for (k in p.eth) { g = +k; if (g !== o && S.alive[g]) adjOp(g, o, -1); }
          if (p.eth[us] >= 0.1 && o !== us && !p.tst) { p.tst = 1; toast('В державе ' + CNAMES[o] + ' притесняют твой народ (' + p.name + '): это повод для войны.', 'warn'); }
        } else if (p.pol === 3) {
          var rm = fo * 0.2;
          popLose(p, p.pop - Math.round(p.pop * (1 - rm)), 'uns');
          setForeign(p, (fo - rm) / (1 - rm));
          S.inf[o] += 1.2;
          for (k in p.eth) { g = +k; if (g !== o && S.alive[g]) adjOp(g, o, -3); }
          if (p.eth[us] >= 0.05 && o !== us && !p.tst) { p.tst = 1; toast('Державa ' + CNAMES[o] + ' депортирует твой народ из ' + p.name + ': это повод для войны.', 'warn'); }
        } else if (fo > 0) setForeign(p, fo - Math.min(fo, 0.012));
        fo = foreignOf(p);
        if (fo < 0.02 && fo > 0) { p.eth = {}; p.eth[o] = 1; fo = 0; }
        if (fo === 0 && p.pol) { if (o === us) toast('Нацсостав выровнен: ' + p.name + ' — политика завершена.', 'good'); p.pol = 0; }
      }
      var tg = fo * 80 * (1 - tk(o, 'unr')) * (p.pol === 2 ? 0.3 : p.pol === 3 ? 0.6 : p.pol === 1 ? 0.7 : 1) + (p.pol === 3 && fo > 0 ? 15 : 0) + (fo >= 0.4 && !p.pol ? fo * 25 : 0) + emUnr(o);
      p.unr = clamp((p.unr || 0) + (tg > p.unr ? Math.min(10, tg - p.unr) : -Math.min(8, p.unr - tg)), 0, 100);
      rebTurn(p, o, us); if (p.aut > 0) { p.aut--; if (p.unr > 45) p.unr -= 2; }
      if (p.unr >= 70 && !p.reb) {
        popLose(p, Math.ceil(p.pop * 0.03), 'uns'); p.garrison = Math.floor(p.garrison * 0.9);
        if (o === us && !told) { told = true; toast('Бунт в ' + p.name + ': недовольство ' + r0(p.unr) + '%. Введи политику или снизь давление.', 'bad'); }
      }
      if (o !== us && p.pol === 0 && fo >= 0.25 && Math.random() < 0.06) {
        var t = Math.random(); p.pol = t < 0.6 ? 1 : t < 0.9 ? 2 : 3;
      }
    });
    processFabs();
  }
  function cbReason(a, b) {
    if (a === b) return null;
    var prot = false, rec = false;
    S.provs.forEach(function (p) {
      if (p.sea || p.owner !== b || !p.eth) return;
      var s = p.eth[a] || 0;
      if (s >= 0.2 && p.pol >= 2) prot = true;
      if (s >= 0.5) rec = true;
    });
    if (prot) return 'protect';
    if (rec) return 'reclaim';
    if (S.bcb && S.bcb[a + '_' + b] >= S.round) return 'blockade';
    if (S.inf[b] >= 25) return 'threat';
    if (S.just && S.just[a + '_' + b] >= S.round) return 'fab';
    return null;
  }
  function cbText(k) { return k === 'protect' ? 'защита соотечественников' : k === 'reclaim' ? 'возврат исконных земель' : k === 'threat' ? 'они угрожают миру' : k === 'fab' ? 'подготовленный повод' : k === 'blockade' ? 'блокада торговых путей' : ''; }
  function fabbing(a, b) { return S.fabs.some(function (f) { return f.a === a && f.b === b; }); }
  function startFab(a, b) {
    if (S.gold[a] < 20 || fabbing(a, b)) return false;
    S.gold[a] -= 20; S.fabs.push({ a: a, b: b, at: S.round + 3 }); return true;
  }
  function processFabs() {
    S.fabs = S.fabs.filter(function (f) {
      if (S.round < f.at) return true;
      S.just[f.a + '_' + f.b] = S.round + 12;
      if (f.a === S.player) toast('Повод против державы ' + CNAMES[f.b] + ' готов на 12 ходов.', 'good');
      return false;
    });
  }
  function ethHtml(p) {
    if (p.sea || p.owner < 0 || !p.eth) return '';
    var us = S.player, h = '', arr = ethStr(p), fo = foreignOf(p);
    h += '<div class="lblrow"><span>Народы</span><b>' + arr.map(function (e) { return CNAMES[e[0]] + ' ' + Math.round(e[1] * 100) + '%'; }).join(' · ') + '</b></div>';
    if ((p.unr || 0) > 3) h += '<div><div class="lblrow"><span>Недовольство</span><b>' + r0(p.unr) + '%</b></div><div class="bar"><i class="' + (p.unr > 60 ? 'bad' : 'warn') + '" style="width:' + r0(p.unr) + '%"></i></div></div>';
    if (p.owner === us && S.phase === 'play' && fo >= 0.02) {
      h += '<div class="lblrow"><span>Политика к меньшинствам</span><b>' + POLN[p.pol] + '</b></div><div class="seg" role="group">' + ['Нет', 'Ассим.', 'Репресс.', 'Депорт.'].map(function (n, i) { return '<button type="button" data-act="pol" data-v="' + i + '" aria-pressed="' + (p.pol === i) + '" title="' + POLN[i] + '">' + n + '</button>'; }).join('') + '</div>';
      h += '<p class="note">' + (p.pol === 1 ? 'Ассимиляция: 3 зол./ход, меньшинство мирно растворяется. Без последствий.' : p.pol === 2 ? 'Репрессии: бунты подавлены, меньшинство потихоньку тает, гибнет часть жителей. Агрессия растёт, их родина враждебна и получает повод для войны.' : p.pol === 3 ? 'Депортация: каждый ход изгоняется пятая часть меньшинства вместе с населением. Сильный рост агрессии, родина изгнанных получает повод для войны.' : 'Меньшинство медленно ассимилируется само, но даёт недовольство и уменьшает доход.') + '</p>';
    }
    return h;
  }

  // ---- technologies ----
  TECH.forEach(function (x) { x.c = Math.round(x.c * 1.6); });
  function techById(id) { for (var i = 0; i < TECH.length; i++) if (TECH[i].id === id) return TECH[i]; return null; }
  function newTech() { return { done: [], cur: '', prog: 0, bank: 0, fx: null }; }
  function tk(c, k) {
    if (!S || !S.tech || c < 0) return 0;
    var t = S.tech[c]; if (!t) return 0;
    if (!t.fx) { t.fx = {}; t.done.forEach(function (id) { var T = techById(id); if (T) for (var q in T.fx) t.fx[q] = (t.fx[q] || 0) + T.fx[q]; }); lawFx(c, t.fx); }
    return t.fx[k] || 0;
  }
  function techAvail(c) {
    var t = S.tech[c], out = [];
    for (var b = 0; b < 3; b++) {
      var nx = TECH.filter(function (x) { return x.b === b && t.done.indexOf(x.id) < 0; })[0];
      if (nx) out.push(nx);
    }
    return out;
  }
  function researchPts(c) {
    var t = 0;
    owned(c).forEach(function (p) { t += p.civ * 1.5 + p.dev * 0.5 + (p.set >= 1 ? 0.4 : 0) + (p.capital ? 1.5 : 0); });
    return Math.round((1.5 + t) * (1 + tk(c, 'res')) * (c === S.player ? 1 : aiIncMult(c)) * 10) / 10;
  }
  function techStart(c, id) {
    var t = S.tech[c], T = techById(id);
    if (!T || !techAvail(c).some(function (x) { return x.id === id; })) return false;
    if (t.cur && t.cur !== id) t.bank = Math.min(60, t.bank + Math.round(t.prog * 0.5));
    if (t.cur !== id) { t.cur = id; t.prog = t.bank; t.bank = 0; }
    return true;
  }
  function techAI(c) {
    var av = techAvail(c); if (!av.length) return;
    var war = warEnemies(c).length > 0, w = av.map(function (x) { return x.b === 0 ? (war ? 3 : 1) : x.b === 1 ? 2 : 1.5; }), s = 0, i;
    w.forEach(function (x) { s += x; });
    var r = Math.random() * s;
    for (i = 0; i < av.length; i++) { r -= w[i]; if (r <= 0) break; }
    techStart(c, av[Math.min(i, av.length - 1)].id);
  }
  function techTurn() {
    for (var c = 0; c < NC; c++) {
      if (!owned(c).length) continue;
      var t = S.tech[c], rp = researchPts(c);
      if (!t.cur && c !== S.player) techAI(c);
      if (t.cur) {
        var T = techById(t.cur); t.prog += rp;
        if (t.prog >= T.c) {
          t.bank = Math.min(60, t.bank + Math.round(t.prog - T.c)); t.prog = 0; t.done.push(T.id); t.fx = null; t.cur = '';
          if (c === S.player) { toast('Изучено: ' + T.n + ' — ' + T.d + '.', 'good'); log('Технология: ' + T.n + '.', true, -1, 'sys'); SFX.recruit(); }
          if (c !== S.player) techAI(c);
        }
      } else t.bank = Math.min(60, t.bank + rp);
    }
  }
  function techHtml() {
    var us = S.player, t = S.tech[us], rp = researchPts(us), h = '<div class="sh-body tech-b">';
    var cur = t.cur ? techById(t.cur) : null, av = techAvail(us).map(function (x) { return x.id; });
    h += '<p class="note">Очки исследований: <b>+' + r1(rp) + '</b> за ход. Их дают гражданские заводы, развитие, города и столица.' + (t.bank ? ' В запасе: ' + Math.round(t.bank) + '.' : '') + '</p>';
    if (cur) h += '<div class="dip cur"><div class="hd"><span class="nm">Сейчас: ' + cur.n + '</span><span class="chip">' + Math.floor(t.prog) + ' / ' + cur.c + '</span></div><div class="bar"><i class="acc" style="width:' + clamp(t.prog / cur.c * 100, 2, 100) + '%"></i></div><div class="row"><button class="btn sm" type="button" data-act="trush"' + (S.gold[us] < 15 ? ' disabled' : '') + '>Ускорить · 15 зол. (+10)</button></div></div>';
    else if (av.length) h += '<p class="note">Исследование не выбрано: очки копятся в запасе (до 60) и пойдут в новое.</p>';
    for (var b = 0; b < 3; b++) {
      h += '<div class="sec"><h3 class="h">' + BRN[b] + '</h3>';
      TECH.filter(function (x) { return x.b === b; }).forEach(function (T) {
        var done = t.done.indexOf(T.id) >= 0, isCur = t.cur === T.id, avl = av.indexOf(T.id) >= 0;
        h += '<div class="dip' + (isCur ? ' cur' : '') + (!done && !avl ? ' lock' : '') + '"><div class="hd"><span class="nm">' + T.n + '</span>' + (done ? '<span class="chip good">Изучено</span>' : isCur ? '<span class="chip">Идёт</span>' : avl ? '<span class="chip">' + T.c + ' оч.</span>' : '<span class="chip">Закрыто</span>') + '</div><p class="note">' + T.d + '</p>';
        if (avl && !isCur) h += '<div class="row"><button class="btn sm primary" type="button" data-act="tstart" data-id="' + T.id + '">' + (t.cur ? 'Сменить (теряется половина прогресса)' : 'Изучать') + '</button></div>';
        h += '</div>';
      });
      h += '</div>';
    }
    return h + lawHtml() + '</div>';
  }
  // ---- decisions ----
  function rndOwn(n) {
    var a = owned(S.player).filter(function (q) { return !q.sea; }), out = [];
    while (a.length && out.length < n) out.push(a.splice((Math.random() * a.length) | 0, 1)[0]);
    return out;
  }
  function otherAlive() { var o = []; for (var c = 0; c < NC; c++) if (c !== S.player && owned(c).length) o.push(c); return o; }
  var EVD = [
    { t: 'Ярмарка', d: 'Купцы просят разрешения устроить большую ярмарку в столице.', ok: function () { return true; }, o: [
      { t: 'Устроить ярмарку', c: 10, f: function () { S.gold[S.player] += 26; rndOwn(3).forEach(function (q) { q.pop = Math.min(popCap(q), q.pop + 3); }); return 'Ярмарка принесла 26 зол. и привлекла жителей.'; } },
      { t: 'Не сейчас', f: function () { return 'Купцы разочарованы.'; } }] },
    { t: 'Недовольные ветераны', d: 'Ветераны требуют платы и земли, иначе грозят беспорядками.', ok: function () { return true; }, o: [
      { t: 'Выплатить жалованье', c: 15, f: function () { owned(S.player).forEach(function (q) { q.garrison = Math.min(gcap(q), q.garrison + Math.ceil(gcap(q) * 0.3)); }); return 'Ветераны вернулись в гарнизоны.'; } },
      { t: 'Подавить силой', f: function () { S.inf[S.player] += 2; var cp = S.provs[capitalOf(S.player)]; cp.pop = Math.max(2, Math.round(cp.pop * 0.95)); return 'Порядок наведён, но агрессия растёт.'; } },
      { t: 'Отказать', f: function () { var q = rndOwn(1)[0]; if (q) q.garrison = Math.floor(q.garrison * 0.6); return 'Часть ветеранов разбрелась, гарнизон ослаб.'; } }] },
    { t: 'Беженцы', d: 'Беженцы из соседних земель просят убежища на твоей земле.', ok: function () { return true; }, o: [
      { t: 'Принять', f: function () {
        var g = otherAlive(), q = rndOwn(2);
        q.forEach(function (x) { x.pop = Math.min(popCap(x), x.pop + 8); if (g.length) { var gg = g[(Math.random() * g.length) | 0]; x.eth[gg] = (x.eth[gg] || 0) + 0.15; normEth(x); } });
        return 'Население выросло, но в ' + q.map(function (x) { return x.name; }).join(' и ') + ' появились новые народы.'; } },
      { t: 'Закрыть границу', f: function () { return 'Беженцы ушли дальше.'; } }] },
    { t: 'Изобретатель', d: 'Самоучка предлагает чертежи новых машин и просит денег на мастерскую.', ok: function () { return true; }, o: [
      { t: 'Профинансировать', c: 20, f: function () { var t = S.tech[S.player]; if (t.cur) t.prog += 18; else t.bank = Math.min(60, t.bank + 18); return 'Чертежи дали +18 очков исследований.'; } },
      { t: 'Отказать', f: function () { return 'Изобретатель уехал к соседям.'; } }] },
    { t: 'Засуха', d: 'Лето выдалось сухим, поля горят.', ok: function () { return true; }, o: [
      { t: 'Закупить зерно', c: 12, f: function () { return 'Запасы спасли урожай.'; } },
      { t: 'Переждать', f: function () { rndOwn(3).forEach(function (q) { q.pop = Math.max(2, Math.round(q.pop * 0.92)); }); return 'Голод унёс часть жителей.'; } }] },
    { t: 'Чужие агенты', d: 'Схвачены агенты державы {g}: они вынюхивали твои гарнизоны.', ok: function () { return otherAlive().some(function (g) { return S.rel[S.player][g] !== 'w'; }); }, o: [
      { t: 'Казнить показательно', f: function (pd) { adjOp(S.player, pd.g, -12); return 'Держава ' + CNAMES[pd.g] + ' в ярости.'; } },
      { t: 'Выслать тихо', f: function (pd) { adjOp(S.player, pd.g, -2); return 'Агентов выслали, скандала нет.'; } },
      { t: 'Перекупить агентов', c: 10, f: function (pd) { adjOp(S.player, pd.g, 8); return 'Агенты теперь работают на тебя, отношение к державе ' + CNAMES[pd.g] + ' улучшилось.'; } }] },
    { t: 'Слух о кладе', d: 'Пастухи рассказывают о старом кладе в горах.', ok: function () { return true; }, o: [
      { t: 'Снарядить поиски', c: 8, f: function () { if (Math.random() < 0.55) { S.gold[S.player] += 36; return 'Клад найден: +36 зол.!'; } return 'Поиски ничего не дали.'; } },
      { t: 'Не обращать внимания', f: function () { return 'Слух забылся.'; } }] },
    { t: 'Чума', d: 'В портовом городе вспыхнула чума. Больных всё больше.', ok: function () { return S.round >= 6; }, o: [
      { t: 'Объявить карантин', c: 14, f: function () { var q = rndOwn(1)[0]; if (q) q.pop = Math.max(2, q.pop - 2); return 'Карантин остановил заразу, потери невелики.'; } },
      { t: 'Не вмешиваться', f: function () { rndOwn(3).forEach(function (q) { q.pop = Math.max(2, Math.round(q.pop * 0.88)); q.unr = Math.min(60, (q.unr || 0) + 8); }); return 'Чума выкосила жителей и посеяла панику.'; } }] },
    { t: 'Землетрясение', d: 'Подземные толчки разрушили мастерские.', ok: function () { return owned(S.player).some(function (q) { return q.fac + q.civ > 0; }); }, o: [
      { t: 'Отправить помощь', c: 12, f: function () { var q = owned(S.player).filter(function (x) { return x.fac + x.civ > 0; })[0]; if (q) q.fd = Math.min(1, q.fd + 0.1); return 'Мастера быстро всё восстановили.'; } },
      { t: 'Справляться своими силами', f: function () { var l = owned(S.player).filter(function (x) { return x.fac + x.civ > 0; }); var q = l[(Math.random() * l.length) | 0]; q.fd = Math.min(1, q.fd + 0.4); q.pop = Math.max(2, q.pop - 3); return 'Цеха в ' + q.name + ' повреждены, есть жертвы.'; } }] },
    { t: 'Золотая жила', d: 'Старатели нашли признаки золота в горах.', ok: function () { return owned(S.player).some(function (q) { return q.terrain === 3; }); }, o: [
      { t: 'Организовать добычу', c: 10, f: function () { if (Math.random() < 0.6) { S.gold[S.player] += 42; return 'Жила богата: +42 зол.!'; } S.gold[S.player] += 8; return 'Золота оказалось немного: +8 зол.'; } },
      { t: 'Продать права купцам', f: function () { S.gold[S.player] += 18; return 'Купцы заплатили 18 зол.'; } }] },
    { t: 'Опытный офицер', d: 'К тебе пришёл ветеран чужих войн и просит командование.', ok: function () { return S.gens.filter(function (g) { return g.owner === S.player; }).length < 6; }, o: [
      { t: 'Взять на службу', c: 12, f: function () { var g = mkGen(S.player, 2); return 'Генерал ' + g.name + ' принят в армию.'; } },
      { t: 'Отказать', f: function () { return 'Офицер ушёл служить другим.'; } }] },
    { t: 'Торговая делегация', d: 'Купцы державы {g} предлагают выгодный договор.', ok: function () { return otherAlive().some(function (g) { return S.rel[S.player][g] !== 'w' && !S.trade[S.player][g]; }); }, o: [
      { t: 'Заключить договор', f: function (pd) { var g = pd.g; if (g < 0 || S.rel[S.player][g] === 'w') g = otherAlive().filter(function (x) { return S.rel[S.player][x] !== 'w'; })[0]; if (g == null || g < 0) return 'Купцы уехали ни с чем.'; S.trade[S.player][g] = 1; S.trade[g][S.player] = 1; S.rtSig = null; adjOp(S.player, g, 8); return 'Торговый договор с державой ' + CNAMES[g] + ' заключён.'; } },
      { t: 'Отказать', f: function () { return 'Купцы разочарованы.'; } }] },
    { t: 'Праздник урожая', d: 'Горожане просят устроить большое гулянье.', ok: function () { return true; }, o: [
      { t: 'Устроить праздник', c: 12, f: function () { owned(S.player).forEach(function (q) { q.unr = Math.max(0, (q.unr || 0) - 10); q.pop = Math.min(popCap(q), q.pop + 1); }); return 'Народ веселится, недовольство спало.'; } },
      { t: 'Не до праздников', f: function () { return 'Люди разошлись по домам.'; } }] },
    { t: 'Контрабандисты', d: 'Портовые власти поймали контрабандистов и предлагают поделить груз.', ok: function () { return owned(S.player).some(function (q) { return q.port; }); }, o: [
      { t: 'Закрыть глаза на всё', f: function () { S.gold[S.player] += 24; var cp = S.provs[capitalOf(S.player)]; cp.unr = Math.min(60, (cp.unr || 0) + 5); return 'Взятка +24 зол., но в столице шепчутся о коррупции.'; } },
      { t: 'Арестовать', c: 6, f: function () { S.gold[S.player] += 14; return 'Груз конфискован: +14 зол. чистой прибыли.'; } }] },
    { t: 'Наёмники', d: 'Отряд наёмников просит службы и обещает верность, пока платят.', ok: function () { return capitalOf(S.player) >= 0; }, o: [
      { t: 'Нанять отряд', c: 28, f: function () { newArmy(S.player, capitalOf(S.player), 60, 70); return 'Наёмники встали лагерем в столице (+6 див.).'; } },
      { t: 'Отказать', f: function () { return 'Наёмники ушли к другим.'; } }] },
    { t: 'Дары посольства', d: 'Посол державы {g} привёз богатые дары.', ok: function () { return otherAlive().some(function (g) { return S.rel[S.player][g] !== 'w'; }); }, o: [
      { t: 'Принять дары', f: function (pd) { var g = pd.g >= 0 && S.rel[S.player][pd.g] !== 'w' ? pd.g : otherAlive().filter(function (x) { return S.rel[S.player][x] !== 'w'; })[0]; S.gold[S.player] += 12; if (g != null) adjOp(S.player, g, 10); return 'Дары приняты: +12 зол., отношения теплеют.'; } },
      { t: 'Вежливо отказаться', f: function (pd) { if (pd.g >= 0) adjOp(S.player, pd.g, 3); return 'Посол остался доволен вежливостью.'; } }] },
    { t: 'Шторм на море', d: 'Твои корабли попали в сильный шторм.', ok: function () { return S.armies.some(function (a) { return a.owner === S.player && S.provs[a.prov].sea; }); }, o: [
      { t: 'Переждать', f: function () { S.armies.forEach(function (a) { if (a.owner === S.player && S.provs[a.prov].sea) a.troops = Math.max(5, a.troops - Math.ceil(a.troops * 0.12)); }); return 'Шторм потрепал морские армии (−12%).'; } },
      { t: 'Рискнуть идти дальше', f: function () { if (Math.random() < 0.5) return 'Капитаны проскочили шторм без потерь.'; S.armies.forEach(function (a) { if (a.owner === S.player && S.provs[a.prov].sea) a.troops = Math.max(5, a.troops - Math.ceil(a.troops * 0.3)); }); return 'Риск не оправдался: морские армии потеряли 30%.'; } }] }
  ];
  function maybeEvent() {
    if (S.pend || S.round < 4 || S.phase !== 'play' || Math.random() > 0.2) return;
    var ok = []; EVD.forEach(function (e, i) { if (e.ok()) ok.push(i); });
    if (!ok.length) return;
    var i = ok[(Math.random() * ok.length) | 0], g = -1, ng = otherAlive().filter(function (x) { return S.rel[S.player][x] !== 'w'; });
    if (ng.length) g = ng[(Math.random() * ng.length) | 0];
    S.pend = { e: i, g: g }; S.ui.view = 'ev';
  }
  function resolveEv(i) {
    if (!S.pend) return;
    var E = EVD[S.pend.e], o = E.o[i], us = S.player;
    if (!o) return;
    if (o.c && S.gold[us] < o.c) { toast('Не хватает золота.'); return; }
    S.gold[us] -= o.c || 0;
    var msg = o.f(S.pend); S.pend = null; S.ui.view = null;
    log(E.t + ': ' + msg, true, -1, 'sys'); toast(msg, 'good'); saveGame(); render();
  }
  function evHtml() {
    var E = EVD[S.pend.e], us = S.player;
    return head(E.t, false) + '<div class="sh-body"><p>' + E.d.replace('{g}', S.pend.g >= 0 ? CNAMES[S.pend.g] : '') + '</p><div class="evb">' + E.o.map(function (o, i) { return '<button class="btn' + (i === 0 ? ' primary' : '') + '" type="button" data-act="evo" data-i="' + i + '"' + (o.c && S.gold[us] < o.c ? ' disabled' : '') + '>' + o.t + (o.c ? ' · ' + o.c + ' зол.' : '') + '</button>'; }).join('') + '</div></div>';
  }

  // ---- laws ----
  var LAWN = ['Призыв', 'Экономика', 'Порядок'];
  var LAWS = [
    [{ n: 'Добровольный набор', d: 'Без особенностей', fx: {} },
     { n: 'Всеобщая мобилизация', d: '+5% силы армий, −6% дохода, рост населения −15%', fx: { pow: 0.05, inc: -0.06, gro: -0.15 } },
     { n: 'Профессиональная армия', d: '+8% силы армий, содержание армий +20%', fx: { pow: 0.08, upk: -0.2 } }],
    [{ n: 'Смешанная экономика', d: 'Без особенностей', fx: {} },
     { n: 'Свободная торговля', d: '+10% дохода, техники −10%', fx: { inc: 0.1, eq: -0.1 } },
     { n: 'Военная экономика', d: '+25% техники, −10% дохода', fx: { eq: 0.25, inc: -0.1 } }],
    [{ n: 'Обычный порядок', d: 'Без особенностей', fx: {} },
     { n: 'Строгий порядок', d: 'Недовольство −35%, рост населения −10%, агрессия спадает медленнее', fx: { unr: 0.35, gro: -0.1, dip: -0.3 } },
     { n: 'Открытое общество', d: 'Исследования +20%, рост +15%, недовольство +20%', fx: { res: 0.2, gro: 0.15, unr: -0.2 } }]
  ];
  function lawFx(c, fx) {
    var L = S.law && S.law[c]; if (!L) return;
    for (var k = 0; k < 3; k++) { var o = LAWS[k][L[k] || 0]; for (var q in o.fx) fx[q] = (fx[q] || 0) + o.fx[q]; }
  }
  function lawSet(c, k, v) {
    if (v === S.law[c][k]) return false;
    if (c === S.player) {
      if (S.gold[c] < 20) { toast('Смена закона стоит 20 зол.', 'warn'); return false; }
      if ((S.lawCd[c][k] || 0) > S.round) { toast('Закон менялся недавно: подожди ' + (S.lawCd[c][k] - S.round) + ' х.', 'warn'); return false; }
      S.gold[c] -= 20;
    }
    S.law[c][k] = v; S.lawCd[c][k] = S.round + 8; if (S.tech && S.tech[c]) S.tech[c].fx = null;
    if (c === S.player) { toast('Закон принят: ' + LAWS[k][v].n + '.', 'good'); log('Закон: ' + LAWS[k][v].n + '.', true, -1, 'sys'); }
    return true;
  }
  function lawAI() {
    for (var c = 0; c < NC; c++) {
      if (c === S.player || !owned(c).length || S.round % 15 !== 0 || Math.random() > 0.4) continue;
      var k = (Math.random() * 3) | 0, war = warEnemies(c).length > 0, v = (Math.random() * 3) | 0;
      if (k === 1 && war && Math.random() < 0.6) v = 2;
      S.law[c][k] = v; S.tech[c].fx = null;
    }
  }
  function lawHtml() {
    var us = S.player, L = S.law[us], h = '<div class="sec"><h3 class="h">Законы</h3><p class="note">Смена закона: 20 зол., потом 8 ходов нельзя менять тот же.</p>';
    for (var k = 0; k < 3; k++) {
      h += '<div class="dip"><div class="hd"><span class="nm">' + LAWN[k] + '</span><span class="chip">' + LAWS[k][L[k]].n + '</span></div><div class="seg" role="group">' + LAWS[k].map(function (o, i) { return '<button type="button" data-act="law" data-k="' + k + '" data-v="' + i + '" aria-pressed="' + (L[k] === i) + '" title="' + o.d + '">' + (i === 0 ? 'Обычн.' : i === 1 ? ['Мобилиз.', 'Торговля', 'Строгий'][k] : ['Профи', 'Военная', 'Открытое'][k]) + '</button>'; }).join('') + '</div><p class="note">' + LAWS[k][L[k]].d + '</p></div>';
    }
    return h + '</div>';
  }
  // ---- achievements ----
  var ACH = [
    { id: 'bat', n: 'Первая кровь', d: 'Участвуй в бою', t: function (us) { return S.stat.bat[us] >= 1; } },
    { id: 'cap10', n: 'Завоеватель', d: 'Захвати 10 провинций', t: function (us) { return S.stat.caps[us] >= 10; } },
    { id: 'sea', n: 'Мореплаватель', d: 'Выведи армию в море', t: function (us) { return S.armies.some(function (a) { return a.owner === us && S.provs[a.prov].sea; }); } },
    { id: 'ind', n: 'Промышленник', d: '8 заводов в державе', t: function (us) { return facTotal(us) >= 8; } },
    { id: 'sci6', n: 'Учёный', d: 'Изучи 6 технологий', t: function (us) { return S.tech[us].done.length >= 6; } },
    { id: 'sci12', n: 'Эпоха просвещения', d: 'Изучи все 12 технологий', t: function (us) { return S.tech[us].done.length >= 12; } },
    { id: 'ally3', n: 'Дипломат', d: '3 союзника одновременно', t: function (us) { var n = 0; for (var c = 0; c < NC; c++) if (c !== us && owned(c).length && S.rel[us][c] === 'a') n++; return n >= 3; } },
    { id: 'trade4', n: 'Торговый дом', d: '4 торговых договора', t: function (us) { var n = 0; for (var c = 0; c < NC; c++) if (c !== us && S.trade[us][c]) n++; return n >= 4; } },
    { id: 'peace', n: 'Мирное время', d: '20 ходов подряд без войн', t: function () { return S.peaceRun >= 20; } },
    { id: 'rich', n: 'Казна', d: '500 золота в казне', t: function (us) { return S.gold[us] >= 500; } },
    { id: 'army', n: 'Великая армия', d: '100 дивизий', t: function (us) { return troopsOf(us) >= 1000; } },
    { id: 'tyr', n: 'Тиран', d: 'Агрессия выше 50', t: function (us) { return S.inf[us] >= 50; } },
    { id: 'nat', n: 'Единый народ', d: '8+ провинций, везде один народ', t: function (us) { var o = owned(us); return o.length >= 8 && o.every(function (q) { return foreignOf(q) < 0.02; }); } },
    { id: 'agent', n: 'Тайный агент', d: '3 успешные операции разведки', t: function () { return (S.xs.spyN || 0) >= 3; } },
    { id: 'pirk', n: 'Гроза морей', d: 'Разгони пиратов армией', t: function () { return (S.xs.pirK || 0) >= 1; } },
    { id: 'res4', n: 'Хозяин недр', d: 'Владей всеми четырьмя ресурсами', t: function (us) { return [0, 1, 2, 3].every(function (k) { return resCount(us, k) > 0; }); } },
    { id: 'mis6', n: 'Исполнительный', d: 'Выполни 6 заданий', t: function () { return (S.xs.misDone || []).length >= 6; } },
    { id: 'win', n: 'Победитель', d: 'Выиграй партию', t: function () { return S.phase === 'over' && S.won; } }
  ];
  /* ---------- missions: three active goals with rewards ---------- */
  var MIS = [
    { id: 'army3', n: 'Три армии', d: 'Держи в строю три армии', goal: function () { return 3; }, cur: function (us) { return S.armies.filter(function (a) { return a.owner === us; }).length; }, r: { g: 12 } },
    { id: 'build2', n: 'Заводской гудок', d: 'Построй 2 цеха', goal: function () { return 2; }, cur: function (us) { return S.stat.built[us]; }, r: { g: 15, eq: 10 } },
    { id: 'trade2', n: 'Торговые связи', d: 'Заключи 2 торговых договора', goal: function () { return 2; }, cur: function (us) { var n = 0; for (var c = 0; c < NC; c++) if (c !== us && owned(c).length && S.trade[us][c]) n++; return n; }, r: { g: 20 } },
    { id: 'tech2', n: 'Первые чертежи', d: 'Изучи 2 технологии', goal: function () { return 2; }, cur: function (us) { return S.tech[us].done.length; }, r: { t: 20 } },
    { id: 'ally1', n: 'Союзник', d: 'Заключи союз', goal: function () { return 1; }, cur: function (us) { var n = 0; for (var c = 0; c < NC; c++) if (c !== us && owned(c).length && S.rel[us][c] === 'a') n++; return n; }, r: { g: 18 } },
    { id: 'res2', n: 'Богатства земли', d: 'Владей 2 провинциями с ресурсами', goal: function () { return 2; }, cur: function (us) { var n = 0; owned(us).forEach(function (q) { if (q.res >= 0) n++; }); return n; }, r: { g: 20 } },
    { id: 'sea1', n: 'Мореход', d: 'Выведи армию в море', goal: function () { return 1; }, cur: function (us) { return S.armies.some(function (a) { return a.owner === us && S.provs[a.prov].sea; }) ? 1 : 0; }, r: { g: 10 } },
    { id: 'bat5', n: 'Боевое крещение', d: 'Выдержи 5 боёв', goal: function () { return 5; }, cur: function (us) { return S.stat.bat[us]; }, r: { eq: 25 } },
    { id: 'prov', n: 'Растущая держава', d: 'Расширь владения', goal: function () { return Math.round(NP / NC * 1.5); }, cur: function (us) { return owned(us).length; }, r: { g: 28 } },
    { id: 'spy2', n: 'Тайные дела', d: '2 успешные операции разведки', goal: function () { return 2; }, cur: function () { return S.xs.spyN || 0; }, r: { g: 22 } },
    { id: 'cap3', n: 'Захватчик', d: 'Захвати 3 провинции', goal: function () { return 3; }, cur: function (us) { return S.stat.caps[us]; }, r: { g: 30 } },
    { id: 'law1', n: 'Реформа', d: 'Измени любой закон', goal: function () { return 1; }, cur: function (us) { return (S.law[us] || []).some(function (v) { return v > 0; }) ? 1 : 0; }, r: { g: 15, t: 12 } },
    { id: 'gold150', n: 'Накопления', d: 'Накопи 150 золота', goal: function () { return 150; }, cur: function (us) { return S.gold[us]; }, r: { eq: 20 } },
    { id: 'peace8', n: 'Мирная передышка', d: '8 ходов подряд без войн', goal: function () { return 8; }, cur: function () { return S.peaceRun || 0; }, r: { g: 26 } },
    { id: 'ind8', n: 'Индустриализация', d: 'Заводов в державе: 8', goal: function () { return 8; }, cur: function (us) { return facTotal(us); }, r: { g: 35, eq: 20 } },
    { id: 'tech6', n: 'Эпоха знаний', d: 'Изучи 6 технологий', goal: function () { return 6; }, cur: function (us) { return S.tech[us].done.length; }, r: { g: 40 } },
    { id: 'pir1', n: 'Чистые моря', d: 'Разгони пиратов армией', goal: function () { return 1; }, cur: function () { return S.xs.pirK || 0; }, r: { g: 25 } },
    { id: 'big', n: 'Великая держава', d: 'Захвати 40% карты', goal: function () { return Math.round(NP * 0.4); }, cur: function (us) { return owned(us).length; }, r: { g: 60, eq: 30 } }
  ];
  function misActive() {
    if (!S.xs.misDone) S.xs.misDone = [];
    return MIS.filter(function (m) { return S.xs.misDone.indexOf(m.id) < 0; }).slice(0, 3);
  }
  function rewTxt(r) { return [r.g ? '+' + r.g + ' зол.' : '', r.eq ? '+' + r.eq + ' техники' : '', r.t ? '+' + r.t + ' иссл.' : ''].filter(Boolean).join(' · '); }
  function misCheck() {
    var us = S.player;
    if (S.phase !== 'play' || !S.xs) return;
    for (var guard = 0; guard < 4; guard++) {
      var done = misActive().filter(function (m) { return m.cur(us) >= m.goal(); })[0];
      if (!done) break;
      S.xs.misDone.push(done.id);
      var r = done.r;
      if (r.g) S.gold[us] += r.g;
      if (r.eq) S.eq[us] = Math.min(eqCap(us), S.eq[us] + r.eq);
      if (r.t) { var tt = S.tech[us]; if (tt.cur) tt.prog += r.t; else tt.bank = Math.min(60, tt.bank + r.t); }
      news('good', 'Задание выполнено', done.n + ' · награда: ' + rewTxt(r), 'mis');
      log('Задание выполнено: ' + done.n + ' (' + rewTxt(r) + ').', true, -1, 'sys');
    }
  }
  function misBar(m, us) {
    var cur = Math.min(m.cur(us), m.goal()), g = m.goal();
    return '<div class="bar"><i class="acc" style="width:' + clamp(cur / g * 100, 2, 100) + '%"></i></div><span class="note">' + cur + ' / ' + g + '</span>';
  }
  function misMini() {
    var us = S.player, a = misActive();
    if (!a.length) return '';
    return '<div class="fld mmini"><span class="lbl">Задания</span>' + a.map(function (m) {
      var cur = Math.min(m.cur(us), m.goal()), g = m.goal();
      return '<button type="button" class="mrow" data-act="view" data-v="mis"><span>' + esc(m.n) + '</span><b>' + cur + '/' + g + '</b><i style="width:' + clamp(cur / g * 100, 2, 100) + '%"></i></button>';
    }).join('') + '</div>';
  }
  function misHtml() {
    var us = S.player, a = misActive(), dn = S.xs.misDone || [];
    var h = head('Задания · ' + dn.length + '/' + MIS.length, true) + '<div class="sh-body"><p class="note">Три задания активны одновременно. За выполнение даются золото, техника или очки исследований; следом открывается следующее.</p><div class="dips">';
    h += a.length ? a.map(function (m) { return '<div class="dip"><div class="hd"><span class="nm">' + esc(m.n) + '</span><span class="chip good">' + rewTxt(m.r) + '</span></div><p>' + esc(m.d) + '.</p>' + misBar(m, us) + '</div>'; }).join('') : '<p class="note">Все задания выполнены. Ты великий правитель.</p>';
    h += '</div>';
    if (dn.length) h += '<div class="sec"><h3 class="h">Выполнено</h3><p class="note">' + dn.map(function (id) { var m = MIS.filter(function (x) { return x.id === id; })[0]; return m ? esc(m.n) : ''; }).filter(Boolean).join(' · ') + '</p></div>';
    return h + '</div>';
  }
  var ACHD = {};
  try { ACHD = JSON.parse(localStorage.getItem('rubezhi3.ach') || '{}') || {}; } catch (e) { ACHD = {}; }
  function achCheck() {
    if (!S || S.player < 0) return;
    var us = S.player, got = [];
    try {
      var wars = warEnemies(us).length; S.peaceRun = wars ? 0 : (S.peaceRun || 0) + 1;
      ACH.forEach(function (a) { if (!ACHD[a.id] && a.t(us)) { ACHD[a.id] = S.round; got.push(a); } });
    } catch (e) { return; }
    if (got.length) {
      try { localStorage.setItem('rubezhi3.ach', JSON.stringify(ACHD)); } catch (e) { /* ignore */ }
      got.forEach(function (a) { toast('Достижение: ' + a.n + ' — ' + a.d + '.', 'good'); log('Достижение: ' + a.n + '.', true, -1, 'sys'); });
    }
  }
  function achHtml() {
    var n = ACH.filter(function (a) { return ACHD[a.id]; }).length;
    return head('Достижения · ' + n + '/' + ACH.length, true) + '<div class="sh-body"><div class="dips">' + ACH.map(function (a) { var d = ACHD[a.id]; return '<div class="dip' + (d ? '' : ' dead') + '"><div class="hd"><span class="nm">' + a.n + '</span>' + (d ? '<span class="chip good">Получено</span>' : '<span class="chip">Закрыто</span>') + '</div><p class="note">' + a.d + '</p></div>'; }).join('') + '</div></div>';
  }
  function calmNow() { return S.calm && (S.calm === 999 || S.round <= S.calm); }
  function keyEv(t) { S.keyEv.push({ r: S.round, t: t }); if (S.keyEv.length > 60) S.keyEv.shift(); }
  function facMax(p) { return p.set === 2 ? (p.capital ? 4 : 3) : p.set === 1 ? 2 : 0; }
  function facCost(p) { return 14 + 8 * (p.fac + p.civ); }
  function devCost(p) { return 10 + 7 * p.dev; }
  function effK(p) { if (p.occ > 0 || p.reb > 0) return 0; var k = 1 - p.fd; if (!p.sup) k *= 0.5; if (p.hot) k *= 0.5; return k; }
  function effFac(p) { return p.fac > 0 ? p.fac * effK(p) : 0; }
  function effCiv(p) { return p.civ > 0 ? p.civ * effK(p) : 0; }
  function civOut(c) { var t = 0; S.provs.forEach(function (p) { if (p.owner === c) t += effCiv(p); }); return t; }
  function indOut(c) { var t = 0; S.provs.forEach(function (p) { if (p.owner === c) t += effFac(p); }); return t; }
  function indGold(c) { return Math.round(indOut(c) + civOut(c) * 3); }
  function eqProd(c) { return Math.round((indOut(c) * 5 + resCount(c, 1) * 3) * (1 + tk(c, 'eq')) * (emOn(c, 'wecon') ? 3 : 1)); }
  function facTotal(c) { var t = 0; S.provs.forEach(function (p) { if (p.owner === c) t += p.fac + p.civ; }); return t; }
  function eqCap(c) { return 60 + 12 * facTotal(c); }
  function eqUse(c) { var t = 0; S.armies.forEach(function (a) { if (a.owner === c) t += a.fought ? Math.ceil(a.troops / 60) : Math.floor(a.troops / 500); }); return t; }
  function canBuildFac(p, c) { c = c == null ? S.player : c; return p.owner === c && p.set >= 1 && p.fac + p.civ < facMax(p) && !(p.occ > 0) && !p.besieged && S.gold[c] >= facCost(p); }
  function buildFac(p, type) { var c = p.owner; S.gold[c] -= facCost(p); if (type === 'civ') p.civ++; else p.fac++; S.stat.built[c]++; }
  function canDevelop(p, c) { c = c == null ? S.player : c; return p.owner === c && !p.sea && p.dev < 3 && p.sup && !(p.occ > 0) && !p.besieged && S.gold[c] >= devCost(p); }
  function develop(p) { S.gold[p.owner] -= devCost(p); p.dev++; p.pop = Math.min(popCap(p), p.pop + 5 + 2 * p.dev); }
  function repairCost(p) { return Math.max(2, Math.ceil(p.fd * (p.fac + p.civ) * 6)); }
  function canRepair(p, c) { c = c == null ? S.player : c; return p.owner === c && p.fac + p.civ > 0 && p.fd > 0.04 && !(p.occ > 0) && !p.besieged && S.gold[c] >= repairCost(p); }
  function repairFac(p) { S.gold[p.owner] -= repairCost(p); p.fd = 0; }
  function hurtInd(p, amt) {
    if (!(p.fac + p.civ > 0)) return;
    p.fd = clamp(p.fd + amt, 0, 0.95); p.hot = true;
    S.stat.dmg[p.owner] += amt * (p.fac + p.civ);
    if (p.owner === S.player && p.hotMsg !== S.round) { p.hotMsg = S.round; toast('Бои повредили промышленность: ' + p.name, 'warn'); }
    if (p.fd >= 0.9) {
      if (p.fac >= p.civ) p.fac--; else p.civ--;
      p.fd = (p.fac + p.civ) ? 0.4 : 0; S.stat.dest[p.owner]++;
      log('Завод в ' + p.name + ' разрушен боями.', p.owner === S.player, p.id, 'ind');
      if (p.owner === S.player) { toast('Завод разрушен: ' + p.name, 'bad'); keyEv('Разрушен завод в ' + p.name); }
    }
  }
  function recHist() {
    var row = [];
    for (var c = 0; c < NC; c++) row.push([owned(c).length, popOf(c), troopsOf(c), Math.round((indOut(c) + civOut(c)) * 10) / 10, S.gold[c]]);
    S.hist.push({ r: S.round, v: row }); if (S.hist.length > 400) S.hist.shift();
  }
  function scoreOf(c) { var st = S.stat; return Math.round(owned(c).length * 10 + popOf(c) * 0.4 + troopsOf(c) * 0.15 + (indOut(c) + civOut(c)) * 6 + st.caps[c] * 4 + st.kills[c] * 0.04 - st.lost[c] * 0.01); }
  function aiIndustry(c) {
    var best = null, bs = -1;
    S.provs.forEach(function (p) { if (p.owner === c && p.fd > 0.25 && !p.hot && canRepair(p, c) && p.fd > bs) { bs = p.fd; best = p; } });
    if (best && S.gold[c] - repairCost(best) >= 8) { repairFac(best); return; }
    var cands = S.provs.filter(function (p) { return canBuildFac(p, c) && !isFront(p, c) && S.gold[c] - facCost(p) >= 12; });
    if (cands.length) { cands.sort(function (a, b) { return (b.set - a.set) || (b.pop - a.pop); }); buildFac(cands[0], (S.eq[c] < 50 || warEnemies(c).length) && Math.random() < 0.7 ? 'mil' : 'civ'); return; }
    var dv = S.provs.filter(function (p) { return canDevelop(p, c) && S.gold[c] - devCost(p) >= 14; });
    if (dv.length && Math.random() < 0.5) develop(dv[(Math.random() * dv.length) | 0]);
  }

