  /* ---------- view ---------- */
  var canvas = $('map'), ctx = canvas.getContext('2d'), stage = $('stage');
  var world = document.createElement('canvas');
  world.width = W; world.height = H;
  var wctx = world.getContext('2d'), wimg = wctx.createImageData(W, H);
  function wantWide() { return ST.shape === 'wide' || (ST.shape !== 'tall' && stage.clientWidth > stage.clientHeight * 1.2); }
  function setWorld(np, wide) {
    var k = np >= 220 ? 2.2 : np >= 140 ? 1.7 : np >= 90 ? 1.33 : 1;
    KS = k; WIDE = !!wide;
    if (WIDE) { W = Math.round(640 * k); H = Math.round(480 * k); } else { W = Math.round(480 * k); H = Math.round(640 * k); }
    world.width = W; world.height = H; wctx = world.getContext('2d'); wimg = wctx.createImageData(W, H);
  }
  var V = { s: 1, tx: 0, ty: 0, min: 0.4, max: 5 }, DPR = 1, HIT = [], rasterDirty = true;
  var TC = { sea: '#0D2031', dark: true, acc: '#4DA6EB', fg: '#E6EDF4' };
  function cssVar(n, d) { try { var v = getComputedStyle(document.documentElement).getPropertyValue(n).trim(); return v || d; } catch (e) { return d; } }
  function readTheme() { TC = { sea: cssVar('--sea', '#0D2031'), dark: isDark(), acc: cssVar('--accent', '#4DA6EB'), fg: cssVar('--fg', '#E6EDF4') }; rasterDirty = true; }
  function hexRGB(h) { h = (h || '').trim(); if (h.charAt(0) === '#' && h.length === 7) return [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)]; return [13, 32, 49]; }
  function landBox() {
    if (MAP.__bb) return MAP.__bb;
    var pid = MAP.pid, nl = MAP.nl, x0 = W, y0 = H, x1 = 0, y1 = 0, x, y, i = 0;
    for (y = 0; y < H; y++) for (x = 0; x < W; x++, i++) { var q = pid[i]; if (q >= 0 && q < nl) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; } }
    if (x1 <= x0) { x0 = 0; y0 = 0; x1 = W; y1 = H; }
    var m = 14; MAP.__bb = { x0: Math.max(0, x0 - m), y0: Math.max(0, y0 - m), x1: Math.min(W, x1 + m), y1: Math.min(H, y1 + m) };
    return MAP.__bb;
  }
  function fitView() {
    var cw = stage.clientWidth || 360, ch = stage.clientHeight || 500, bb = landBox(), bw = bb.x1 - bb.x0, bh = bb.y1 - bb.y0;
    var top = ch < 420 ? 44 : 64;
    var s = Math.min((cw - 16) / bw, (ch - top - 8) / bh);
    V.s = Math.max(s, 0.3); V.fit = V.s; V.min = Math.max(0.25, Math.min(V.s * 0.55, 0.9)); V.max = 5;
    V.tx = cw / 2 - (bb.x0 + bb.x1) / 2 * V.s; V.ty = top + (ch - top - 8) / 2 - (bb.y0 + bb.y1) / 2 * V.s;
  }
  function clampView() {
    var cw = stage.clientWidth, ch = stage.clientHeight, mw = W * V.s, mh = H * V.s;
    V.tx = clamp(V.tx, Math.min(cw - mw, 0) - 80, Math.max(cw - mw, 0) + 80);
    V.ty = clamp(V.ty, Math.min(ch - mh, 0) - 80, Math.max(ch - mh, 0) + 80);
  }
  function zoomAt(cx, cy, f) {
    var wx = (cx - V.tx) / V.s, wy = (cy - V.ty) / V.s;
    V.s = clamp(V.s * f, V.min, V.max);
    V.tx = cx - wx * V.s; V.ty = cy - wy * V.s;
    clampView(); draw();
  }
  function centerOn(pid, scale) {
    if (!S || pid < 0) return;
    var p = S.provs[pid], cw = stage.clientWidth || 360, ch = stage.clientHeight || 500;
    if (scale) V.s = clamp(Math.max(scale, V.min), V.min, V.max);
    V.tx = cw / 2 - p.lx * V.s; V.ty = ch / 2 - p.ly * V.s;
    clampView();
  }
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    var cw = stage.clientWidth, ch = stage.clientHeight;
    canvas.width = Math.max(1, Math.round(cw * DPR)); canvas.height = Math.max(1, Math.round(ch * DPR));
    if (S) draw();
  }
  function sx(x) { return V.tx + x * V.s; }
  function sy(y) { return V.ty + y * V.s; }

  /* ---------- visibility / colours ---------- */
  function ownerOf(p) { return ANIM && ANIM.own[p.id] != null ? ANIM.own[p.id] : p.owner; }
  function friendlyTo(c, us) { return c === us || isAlly(us, c); }
  function visibleProv(p) {
    if (!fogOn() || S.phase !== 'play') return true;
    var us = S.player;
    if (friendlyTo(p.owner, us)) return true;
    if (S.intel && p.owner >= 0 && S.intel[p.owner] >= S.round) return true;
    if (p.nb.some(function (n) { return friendlyTo(S.provs[n].owner, us); })) return true;
    return S.armies.some(function (a) { return friendlyTo(a.owner, us) && (a.prov === p.id || p.nb.indexOf(a.prov) >= 0); });
  }
  var MLK = {
    brutal: { sat: 1.35, br: 1, coast: ['#000000', 3.2], inner: ['rgba(0,0,0,0.85)', 1.8], cty: 1.7, decor: 0.3, sq: true },
    neon: { sat: 1.5, br: 0.5, coast: ['#00F0FF', 2.2], inner: ['rgba(0,240,255,0.35)', 1], cty: 1.2, decor: 0.2, glow: '#00F0FF' },
    military: { sat: 0.45, br: 0.85, mix: [74, 80, 52, 0.28], coast: ['#1C2113', 2.4], inner: ['rgba(20,26,12,0.7)', 1.4, [6, 4]], cty: 1.2, decor: 0.5, sq: true },
    paper: { sat: 0.75, br: 1.08, mix: [238, 226, 196, 0.35], coast: ['#3B2E1A', 1.8], inner: ['rgba(59,46,26,0.5)', 0.9], cty: 1, decor: 0.6 },
    terminal: { mono: [92, 255, 132], br: 0.55, coast: ['#5CFF84', 1.8], inner: ['rgba(92,255,132,0.4)', 0.9], cty: 1, decor: 0.25, sq: true, glow: '#5CFF84' }
  };
  function mapLook() { return MLK[styId()] || null; }
  function mapTint(o) {
    var L = mapLook(); if (!L) return o;
    var r = o[0], g = o[1], b = o[2], y = 0.3 * r + 0.59 * g + 0.11 * b;
    if (L.mono) { r = L.mono[0] * y / 255; g = L.mono[1] * y / 255; b = L.mono[2] * y / 255; }
    else { var sa = L.sat || 1; r = y + (r - y) * sa; g = y + (g - y) * sa; b = y + (b - y) * sa; }
    var br = L.br || 1; r *= br; g *= br; b *= br;
    if (L.mix) { var m = L.mix[3]; r = r * (1 - m) + L.mix[0] * m; g = g * (1 - m) + L.mix[1] * m; b = b * (1 - m) + L.mix[2] * m; }
    return [clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)];
  }
  function landRGB(p, owner) {
    var c = COL[owner < 0 ? 7 : owner], dk = TC.dark, base = dk ? [26, 38, 50] : [238, 241, 244], mixk = dk ? 0.3 : 0.18;
    var k = 1 + (((p.id * 37) % 11) - 5) * 0.012, r = c[0] * k, g = c[1] * k, b = c[2] * k;
    r = r * (1 - mixk) + base[0] * mixk; g = g * (1 - mixk) + base[1] * mixk; b = b * (1 - mixk) + base[2] * mixk;
    if (dk) { r *= 0.9; g *= 0.9; b *= 0.9; }
    var t = p.terrain;
    if (t === 1) { r += 12; g += 12; b -= 2; }
    else if (t === 2) { r = r * 0.82 + 8; g = g * 0.86 + 20; b = b * 0.82 + 8; }
    else if (t === 3) { r = r * 0.72 + 38; g = g * 0.72 + 38; b = b * 0.72 + 40; }
    return mapTint([clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255)]);
  }

  var mapIdSeq = 0, rasterSig = '', rasterVer = 0;
  function buildRaster() {
    rasterDirty = false;
    var provs = S.provs, pid = MAP.pid, d = wimg.data, n = provs.length;
    var pr = [], pg = [], pb = [], ta = [], tr = [], tg = [], tb = [], hh = [], dim = [];
    provs.forEach(function (p, i) {
      var c = landRGB(p, ownerOf(p));
      pr[i] = c[0]; pg[i] = c[1]; pb[i] = c[2]; ta[i] = 0; tr[i] = 255; tg[i] = 255; tb[i] = 255;
      var occBy = p.occ > 0 ? p.occBy : -1;
      hh[i] = occBy >= 0 ? COL[occBy] : null;
      dim[i] = visibleProv(p) ? 1 : 0.55;
      if (S.phase === 'play' && S.layer === 'sup' && !p.sup && friendlyTo(p.owner, S.player)) dim[i] = 0.62;
    });
    function tint(i, r, g, b, a) { tr[i] = r; tg[i] = g; tb[i] = b; ta[i] = a; }
    if (S.phase === 'play' && S.layer === 'eco') provs.forEach(function (p) {
      if (p.fac + p.civ > 0) { tint(p.id, 255, 190, 60, 0.12 + 0.05 * (p.fac + p.civ)); if (p.fd > 0.05) tint(p.id, 255, 70, 50, 0.15 + 0.4 * p.fd); }
      else dim[p.id] *= 0.8;
    });
    if (S.phase === 'play' && S.layer === 'nat') provs.forEach(function (p) {
      if (p.sea || p.owner < 0) return;
      var f = foreignOf(p), u = (p.unr || 0) / 100;
      if (f > 0.03 || u > 0.03) tint(p.id, 232, 80 + Math.round(90 * (1 - u)), 56, 0.1 + 0.5 * Math.max(f * 0.8, u));
      else dim[p.id] *= 0.85;
    });
    if (S.phase === 'play' && S.layer === 'unr') provs.forEach(function (p) {
      if (p.sea || p.owner < 0) return;
      var u = (p.unr || 0) / 100;
      if (p.reb > 0) tint(p.id, 200, 20, 30, 0.45 + 0.15 * p.reb);
      else if (u > 0.05) tint(p.id, 235, 200 - Math.round(150 * u), 40, 0.12 + 0.45 * u);
      else dim[p.id] *= 0.8;
    });
    if (S.phase === 'pick' && S.pickC >= 0) provs.forEach(function (p) { if (p.owner === S.pickC) tint(p.id, 255, 255, 255, 0.26); });
    if (S.phase === 'play') {
      if (S.selP >= 0) tint(S.selP, 255, 255, 255, 0.2);
      var sa = S.selA >= 0 ? armyById(S.selA) : null;
      if (sa && sa.route.length) {
        var tp = sa.route[sa.route.length - 1];
        if (isWar(sa.owner, provs[tp].owner) || hostileAt(tp, sa.owner)) tint(tp, 255, 80, 66, 0.3); else tint(tp, 120, 255, 170, 0.24);
      }
    }
    if (!MAP.__id) MAP.__id = ++mapIdSeq;
    var sg = [MAP.__id, W, H, styId()].join(','), qq;
    for (qq = 0; qq < n; qq++) sg += '|' + pr[qq] + ',' + pg[qq] + ',' + pb[qq] + ',' + ta[qq] + ',' + tr[qq] + ',' + tg[qq] + ',' + tb[qq] + ',' + (hh[qq] ? hh[qq][0] + '.' + hh[qq][1] : '') + ',' + dim[qq];
    if (sg === rasterSig) return;
    rasterSig = sg; rasterVer++;
    var x, y, i, nl = MAP.nl, c0 = new Uint32Array(n), c1 = new Uint32Array(n), hat = new Uint8Array(n);
    function pack(r, g, b, a) { return ((a & 255) << 24 | (Math.round(b) & 255) << 16 | (Math.round(g) & 255) << 8 | (Math.round(r) & 255)) >>> 0; }
    for (qq = 0; qq < n; qq++) {
      if (qq >= nl) { var sa2 = ta[qq]; c0[qq] = sa2 > 0 ? pack(tr[qq], tg[qq], tb[qq], Math.round(255 * sa2 * 0.45)) : 0; continue; }
      var r = pr[qq], g = pg[qq], b = pb[qq], a = ta[qq], h = hh[qq], dm = dim[qq];
      if (a > 0) { r = r * (1 - a) + tr[qq] * a; g = g * (1 - a) + tg[qq] * a; b = b * (1 - a) + tb[qq] * a; }
      c0[qq] = pack(r * dm, g * dm, b * dm, 255);
      if (h) { hat[qq] = 1; c1[qq] = pack((r * 0.5 + h[0] * 0.5) * dm, (g * 0.5 + h[1] * 0.5) * dm, (b * 0.5 + h[2] * 0.5) * dm, 255); }
    }
    var d32 = wimg.__u32 || (wimg.__u32 = new Uint32Array(wimg.data.buffer)), idx = 0;
    for (y = 0; y < H; y++) {
      for (x = 0; x < W; x++, idx++) {
        var pp = pid[idx];
        if (pp < 0) d32[idx] = 0;
        else if (hat[pp] && ((x + y) % 10) < 4) d32[idx] = c1[pp];
        else d32[idx] = c0[pp];
      }
    }
    wctx.putImageData(wimg, 0, 0);
  }

  /* ---------- world layer ---------- */
  function tri(x1, y1, x2, y2, x3, y3) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.lineTo(x3, y3); ctx.closePath(); ctx.fill(); }
  function drawDecor() {
    var provs = S.provs;
    ctx.globalAlpha = (TC.dark ? 0.55 : 0.7) * (mapLook() ? mapLook().decor : 1);
    for (var p = 0; p < MAP.nl; p++) {
      if (!visibleProv(provs[p])) continue;
      var items = MAP.decor[p];
      for (var i = 0; i < items.length; i++) {
        var it = items[i], x = it.x, y = it.y, s = it.s;
        if (it.k === 0) {
          ctx.fillStyle = 'rgba(14,48,28,0.85)';
          tri(x, y - 6 * s, x + 3.6 * s, y, x - 3.6 * s, y);
          tri(x, y - 3 * s, x + 4.4 * s, y + 3 * s, x - 4.4 * s, y + 3 * s);
        } else if (it.k === 1) {
          ctx.fillStyle = 'rgba(46,52,58,0.85)';
          tri(x - 8 * s, y + 5 * s, x, y - 8 * s, x + 8 * s, y + 5 * s);
          tri(x + 3 * s, y + 5 * s, x + 8 * s, y - 3 * s, x + 13 * s, y + 5 * s);
          ctx.fillStyle = 'rgba(232,238,244,0.9)';
          tri(x - 2.6 * s, y - 3.2 * s, x, y - 8 * s, x + 2.6 * s, y - 3.2 * s);
        } else if (it.k === 2) {
          ctx.fillStyle = 'rgba(236,214,120,0.4)';
          ctx.fillRect(x - 7 * s, y - 5 * s, 14 * s, 10 * s);
          ctx.strokeStyle = 'rgba(110,86,22,0.45)'; ctx.lineWidth = 0.6;
          ctx.beginPath();
          for (var q = -3; q <= 3; q++) { ctx.moveTo(x - 7 * s, y + q * 1.4 * s); ctx.lineTo(x + 7 * s, y + q * 1.4 * s); }
          ctx.stroke();
        } else {
          ctx.strokeStyle = 'rgba(20,72,36,0.55)'; ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(x - 2 * s, y + 2 * s); ctx.lineTo(x - 3 * s, y - 2 * s);
          ctx.moveTo(x, y + 2 * s); ctx.lineTo(x, y - 3 * s);
          ctx.moveTo(x + 2 * s, y + 2 * s); ctx.lineTo(x + 3 * s, y - 2 * s);
          ctx.stroke();
        }
      }
    }
    ctx.globalAlpha = 1;
  }
  var VM = { x: 0, y: 0 };
  function drawGrid() {
    var step = 40, x0 = Math.floor((-V.tx - VM.x) / V.s / step) * step, x1 = (stage.clientWidth + VM.x - V.tx) / V.s, y0 = Math.floor((-V.ty - VM.y) / V.s / step) * step, y1 = (stage.clientHeight + VM.y - V.ty) / V.s, k;
    ctx.strokeStyle = TC.dark ? 'rgba(160,200,240,0.06)' : 'rgba(20,60,100,0.08)'; ctx.lineWidth = 1 / V.s;
    ctx.beginPath();
    for (k = x0; k <= x1; k += step) { ctx.moveTo(k, y0); ctx.lineTo(k, y1); }
    for (k = y0; k <= y1; k += step) { ctx.moveTo(x0, k); ctx.lineTo(x1, k); }
    ctx.stroke();
  }
  function relStyle(a, b) {
    var r = S.phase === 'play' ? S.rel[a][b] : 'o';
    if (r === 'w') return { cas: 'rgba(60,4,2,0.88)', cw: 5, col: '#FF4B3A', lw: 2.6, war: true };
    if (r === 'a') return { cas: 'rgba(6,44,22,0.75)', cw: 3.8, col: '#52D690', lw: 1.9 };
    return { cas: 'rgba(0,0,0,0.6)', cw: 3.4, col: '#F2F5F8', lw: 1.4 };
  }
  var HAS_ADD = typeof Path2D !== 'undefined' && typeof Path2D.prototype.addPath === 'function';
  function mkGroup(list) {
    return { l: list, p: [null, null] };
  }
  function strokeG(g) {
    if (!HAS_ADD) { g.l.forEach(function (e) { ctx.stroke(edgePath(e, LOD)); }); return; }
    var q = g.p[LOD];
    if (!q) { q = new Path2D(); g.l.forEach(function (e) { q.addPath(edgePath(e, LOD)); }); g.p[LOD] = q; }
    ctx.stroke(q);
  }
  var BG = null, BGsig = '';
  function relSig() { var h = 0, a, b; if (S.phase !== 'play') return 'p'; for (a = 0; a < NC; a++) for (b = a + 1; b < NC; b++) h = (h * 3 + (S.rel[a][b] === 'w' ? 2 : S.rel[a][b] === 'a' ? 1 : 0)) % 1000003; return h; }
  function ownSig() { var h = 7, i; for (i = 0; i < MAP.nl; i++) h = (h * 31 + ownerOf(S.provs[i]) + 2) % 1000000007; return h; }
  function borderGroups() {
    var sig = MAP.__id + ':' + ownSig() + ':' + relSig();
    if (BG && BGsig === sig) return BG;
    var E = MAP.edges, keys = Object.keys(E), i, ed, oa, ob, coast = [], inner = [], seab = [], cm = {};
    for (i = 0; i < keys.length; i++) {
      ed = E[keys[i]];
      if (ed.a < 0) { coast.push(ed); continue; }
      if (ed.a >= MAP.nl) { seab.push(ed); continue; }
      if (ed.b >= MAP.nl) { coast.push(ed); continue; }
      oa = ownerOf(S.provs[ed.a]); ob = ownerOf(S.provs[ed.b]);
      if (oa === ob) inner.push(ed);
      else { var st = relStyle(oa, ob), k = st.col + st.cas + st.cw + st.lw; (cm[k] || (cm[k] = { st: st, l: [] })).l.push(ed); }
    }
    if (!MAP.__coast || MAP.__coastN !== coast.length) { MAP.__coast = mkGroup(coast); MAP.__coastN = coast.length; MAP.__seab = mkGroup(seab); }
    var cty = Object.keys(cm).map(function (k) { return { st: cm[k].st, g: mkGroup(cm[k].l) }; });
    BG = { coast: MAP.__coast, seab: MAP.__seab, inner: mkGroup(inner), cty: cty }; BGsig = sig;
    return BG;
  }
  function drawCoastGlow() {
    var s = V.s, G = borderGroups();
    ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.setLineDash([]);
    ctx.strokeStyle = TC.dark ? 'rgba(150,200,240,0.05)' : 'rgba(40,90,140,0.05)'; ctx.lineWidth = 26 / s;
    strokeG(G.coast);
    ctx.strokeStyle = TC.dark ? 'rgba(150,200,240,0.08)' : 'rgba(40,90,140,0.08)'; ctx.lineWidth = 16 / s;
    strokeG(G.coast);
    ctx.strokeStyle = TC.dark ? 'rgba(150,200,240,0.16)' : 'rgba(40,90,140,0.16)'; ctx.lineWidth = 8 / s;
    strokeG(G.coast);
  }
  function drawBorders() {
    var E = MAP.edges, s = V.s, G = borderGroups();
    ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.setLineDash([]);
    var ML = mapLook();
    ctx.strokeStyle = ML ? ML.coast[0] : TC.dark ? 'rgba(200,225,245,0.55)' : 'rgba(20,40,60,0.7)'; ctx.lineWidth = (ML ? ML.coast[1] : 1.3) / s;
    if (ML && ML.glow) { ctx.shadowColor = ML.glow; ctx.shadowBlur = 10; }
    strokeG(G.coast);
    ctx.shadowBlur = 0; ctx.shadowColor = 'rgba(0,0,0,0)';
    ctx.strokeStyle = ML ? ML.inner[0] : 'rgba(8,14,22,0.38)'; ctx.lineWidth = (ML ? ML.inner[1] : 0.9) / s;
    if (ML && ML.inner[2]) ctx.setLineDash(ML.inner[2].map(function (v) { return v / s; }));
    strokeG(G.inner); ctx.setLineDash([]);
    ctx.strokeStyle = TC.dark ? 'rgba(150,200,240,0.22)' : 'rgba(40,90,140,0.3)'; ctx.lineWidth = 1.2 / s; ctx.setLineDash([2 / s, 7 / s]);
    strokeG(G.seab);
    ctx.setLineDash([]);
    G.cty.forEach(function (o) { if (o.st.war) { ctx.strokeStyle = 'rgba(255,60,44,0.2)'; ctx.lineWidth = 12 / s; strokeG(o.g); } });
    G.cty.forEach(function (o) { ctx.strokeStyle = o.st.cas; ctx.lineWidth = o.st.cw * (ML ? ML.cty : 1) / s; strokeG(o.g); });
    G.cty.forEach(function (o) { ctx.strokeStyle = o.st.col; ctx.lineWidth = o.st.lw * (ML ? ML.cty : 1) / s; strokeG(o.g); });
    if (S.phase === 'play' && S.layer === 'mil' && S.fronts) {
      S.fronts.forEach(function (f) {
        var col = f.ratio >= 1.3 ? 'rgba(80,220,140,0.5)' : f.ratio >= 0.8 ? 'rgba(245,190,70,0.55)' : 'rgba(240,80,66,0.6)';
        ctx.strokeStyle = col; ctx.lineWidth = (f.id === S.selF ? 12 : 8) / s;
        f.edges.forEach(function (k) { ctx.stroke(edgePath(E[k], LOD)); });
        (f.sea || []).forEach(function (k) { ctx.stroke(seaPath(MAP.sea[k])); });
      });
    }
    if (S.phase === 'play' && S.selP >= 0) {
      ctx.strokeStyle = TC.acc; ctx.lineWidth = 2.6 / s;
      (MAP.byProv[S.selP] || []).forEach(function (k) { ctx.stroke(edgePath(E[k], LOD)); });
    }
  }
  function drawSeaLinks() {
    var L = MAP.sea, keys = Object.keys(L), s = V.s;
    if (!keys.length || S.phase === 'pick' && false) return;
    ctx.lineCap = 'round';
    keys.forEach(function (k) {
      var l = L[k], oa = ownerOf(S.provs[l.a]), ob = ownerOf(S.provs[l.b]), pth = seaPath(l);
      var st = oa === ob ? null : relStyle(oa, ob), fight = S.phase === 'play' && activeFights().some(function (f) { return seaKey(f.from, f.pid) === k; });
      if (fight) return;
      ctx.setLineDash([]); ctx.strokeStyle = 'rgba(6,20,36,0.55)'; ctx.lineWidth = 3.4 / s; ctx.stroke(pth);
      ctx.setLineDash([7 / s, 5 / s]); ctx.strokeStyle = st ? st.col : 'rgba(176,222,250,0.9)'; ctx.lineWidth = 1.7 / s; ctx.stroke(pth);
    });
    ctx.setLineDash([]);
  }
  function fightPath(f) {
    var k = seaKey(f.from, f.pid);
    if (isSeaLink(f.from, f.pid)) return { path: seaPath(MAP.sea[k]), mid: seaMid(MAP.sea[k]) };
    var e = MAP.edges[k];
    if (!e) return null;
    var ln = e.lines[0];
    return { path: edgePath(e), mid: ln[(ln.length / 2) | 0] };
  }
  function drawEngagements(now) {
    var fs = activeFights();
    if (!fs.length || ANIM) return;
    var s = V.s, ph = 0.5 + 0.5 * Math.sin((now || performance.now()) / 230);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    fs.forEach(function (f) {
      var fp = fightPath(f);
      if (!fp) return;
      ctx.setLineDash([]);
      ctx.strokeStyle = 'rgba(255,40,30,' + (0.16 + 0.22 * ph) + ')'; ctx.lineWidth = (15 + 5 * ph) / s; ctx.stroke(fp.path);
      ctx.strokeStyle = 'rgba(110,6,2,0.92)'; ctx.lineWidth = 6.4 / s; ctx.stroke(fp.path);
      ctx.strokeStyle = '#FF5A44'; ctx.lineWidth = 3.6 / s; ctx.stroke(fp.path);
      ctx.strokeStyle = 'rgba(255,232,205,' + (0.45 + 0.45 * ph) + ')'; ctx.lineWidth = 1.2 / s; ctx.setLineDash([4 / s, 6 / s]); ctx.stroke(fp.path); ctx.setLineDash([]);
    });
  }
  function drawFightBadges() {
    if (ANIM) return;
    activeFights().forEach(function (f) {
      var fp = fightPath(f);
      if (!fp) return;
      var x = sx(fp.mid[0]), y = sy(fp.mid[1]), w = 62, h = 26, a = f.a, d = f.d, gr = a.mode === 'grind';
      if (x < -40 || y < -30 || x > stage.clientWidth + 40 || y > stage.clientHeight + 30) return;
      ctx.fillStyle = 'rgba(4,10,18,0.7)'; rrect(x - w / 2 - 1, y - h / 2 + 1, w + 2, h + 2, 9); ctx.fill();
      ctx.fillStyle = '#B8281C'; rrect(x - w / 2, y - h / 2, w, h, 8); ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = '#fff'; rrect(x - w / 2, y - h / 2, w, h, 8); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath();
      ctx.moveTo(x - w / 2 + 6, y - 6); ctx.lineTo(x - w / 2 + 18, y + 6); ctx.moveTo(x - w / 2 + 18, y - 6); ctx.lineTo(x - w / 2 + 6, y + 6); ctx.stroke();
      var bx = x - w / 2 + 24, bw = w - 30;
      ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(bx, y - 8, bw, 5); ctx.fillRect(bx, y + 2, bw, 5);
      ctx.fillStyle = rgb(COL[a.owner], 1.25); ctx.fillRect(bx, y - 8, bw * clamp(a.org / 100, 0, 1), 5);
      ctx.fillStyle = rgb(COL[d.owner], 1.25); ctx.fillRect(bx, y + 2, bw * clamp(d.org / 100, 0, 1), 5);
      if (gr) { ctx.fillStyle = '#FFE07A'; ctx.font = '700 8px Inter, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('износ', x, y - h / 2 - 5); }
      HIT.push({ fight: a.id, fdef: d.id, x: x - w / 2, y: y - h / 2, w: w, h: h });
    });
  }
  function drawSupply() {
    var mode = S.layer === 'sup' ? 'all' : ST.supply;
    if (mode === 'off' || S.phase !== 'play') return;
    var s = V.s, us = S.player;
    ctx.setLineDash([5 / s, 4 / s]); ctx.lineWidth = 1.6 / s; ctx.lineCap = 'butt';
    S.provs.forEach(function (p) {
      if (p.from < 0 || (mode === 'mine' && !friendlyTo(p.owner, us))) return;
      var q = S.provs[p.from], c = COL[p.owner];
      ctx.strokeStyle = 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',0.95)';
      ctx.beginPath(); ctx.moveTo(q.lx, q.ly); ctx.lineTo(p.lx, p.ly); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 0.7 / s;
      ctx.beginPath(); ctx.moveTo(q.lx, q.ly); ctx.lineTo(p.lx, p.ly); ctx.stroke(); ctx.lineWidth = 1.6 / s;
    });
    ctx.setLineDash([]); ctx.lineCap = 'round';
  }

  /* ---------- screen layer ---------- */
  var HC = {}, HCn = 0;
  function halo(txt, x, y, fs, fill, w) {
    w = w || 3; fill = fill || '#fff';
    var key = txt + '|' + fs + '|' + fill + '|' + w + '|' + DPR, sp = HC[key];
    if (!sp) {
      if (HCn > 700) { HC = {}; HCn = 0; }
      var c = document.createElement('canvas'), cx = c.getContext('2d'), font = '600 ' + fs + 'px Inter, system-ui, sans-serif';
      cx.font = font;
      var tw = cx.measureText(txt).width, pad = Math.ceil(w) + 2, sw = Math.ceil(tw + 2 * pad), sh = Math.ceil(fs * 1.5 + 2 * pad);
      c.width = Math.ceil(sw * DPR); c.height = Math.ceil(sh * DPR);
      cx.scale(DPR, DPR); cx.font = font; cx.lineWidth = w; cx.lineJoin = 'round'; cx.textAlign = 'center'; cx.textBaseline = 'middle';
      cx.strokeStyle = 'rgba(6,12,20,0.82)'; cx.fillStyle = fill;
      cx.strokeText(txt, sw / 2, sh / 2); cx.fillText(txt, sw / 2, sh / 2);
      sp = HC[key] = { c: c, w: sw, h: sh }; HCn++;
    }
    var al = ctx.textAlign, bl = ctx.textBaseline;
    var dx = al === 'center' ? -sp.w / 2 : (al === 'right' || al === 'end') ? -sp.w : 0;
    var cy = bl === 'top' ? y + fs * 0.55 : bl === 'bottom' ? y - fs * 0.5 : bl === 'middle' ? y : y - fs * 0.35;
    ctx.drawImage(sp.c, x + dx, cy - sp.h / 2, sp.w, sp.h);
  }
  function drawStar(x, y, r, col) {
    ctx.fillStyle = col; ctx.beginPath();
    for (var i = 0; i < 10; i++) { var rr2 = i % 2 ? r * 0.45 : r, an = -Math.PI / 2 + i * Math.PI / 5; ctx.lineTo(x + Math.cos(an) * rr2, y + Math.sin(an) * rr2); }
    ctx.closePath(); ctx.fill();
  }
  function drawSettle(p, x, y) {
    var o = ownerOf(p), c = COL[o], col = rgb(c, 1), r = p.set === 2 ? 7 : p.set === 1 ? 5.5 : 4;
    if (p.capital) r = 9;
    ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(6,12,20,0.85)'; ctx.fillStyle = '#F4F7FA';
    ctx.beginPath();
    if (p.set === 1 && !p.capital) ctx.rect(x - r, y - r, r * 2, r * 2); else ctx.arc(x, y, r, 0, 6.2832);
    ctx.fill(); ctx.stroke();
    if (p.set === 2 || p.capital) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r - 2.6, 0, 6.2832); ctx.fill(); }
    else { ctx.fillStyle = col; ctx.beginPath(); if (p.set === 1) ctx.rect(x - r + 2.4, y - r + 2.4, r * 2 - 4.8, r * 2 - 4.8); else ctx.arc(x, y, r - 2, 0, 6.2832); ctx.fill(); }
    if (p.capital) drawStar(x, y + 0.5, 5, '#FFE07A');
    if (p.depot) { ctx.fillStyle = '#F2C14E'; ctx.strokeStyle = 'rgba(6,12,20,0.9)'; ctx.lineWidth = 1.4; ctx.fillRect(x - r - 9, y + 1, 7, 7); ctx.strokeRect(x - r - 9, y + 1, 7, 7); ctx.beginPath(); ctx.moveTo(x - r - 9, y + 4.5); ctx.lineTo(x - r - 2, y + 4.5); ctx.stroke(); }
    if (p.res >= 0 && ST.resicons && (V.s >= 0.9 || S.layer === 'eco')) drawRes(p.res, x - r - 6, y + r + 4, S.layer === 'eco' ? 1.35 : 1);
    if (p.port) { ctx.fillStyle = '#4CC3E8'; ctx.strokeStyle = 'rgba(6,12,20,0.9)'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(x + r + 3, y + r + 1, 3.3, 0, 6.2832); ctx.fill(); ctx.stroke(); }
    if (p.fac + p.civ > 0 && S.phase !== 'pick') {
      var bad = p.fd > 0.5 ? '#EE5444' : p.fd > 0.12 ? '#E8873A' : '#F2C14E', eco = S.layer === 'eco', bw = eco ? 30 : 23, bh = eco ? 15 : 12, fx = x - r - bw + 2, fy = y - r - bh - 1;
      ctx.fillStyle = 'rgba(14,22,32,0.92)'; rrect(fx, fy, bw, bh, 3); ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = bad; rrect(fx, fy, bw, bh, 3); ctx.stroke();
      ctx.fillStyle = bad; ctx.font = '700 ' + (eco ? 11 : 9) + 'px Inter, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(p.fac + '/' + p.civ, fx + bw / 2, fy + bh / 2 + 0.5);
      if (eco && p.fd > 0.03) { ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(fx, fy + bh + 2, bw, 3); ctx.fillStyle = '#EE5444'; ctx.fillRect(fx, fy + bh + 2, bw * p.fd, 3); }
    }
    if (S.phase === 'play' && ST.supply !== 'off' && !p.sup && friendlyTo(p.owner, S.player)) {
      ctx.fillStyle = '#EE5444'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(x + r + 3, y - r - 2, 3.4, 0, 6.2832); ctx.fill(); ctx.stroke();
    }
  }
  function bar(x, y, w, h, f, col) {
    ctx.fillStyle = 'rgba(6,12,20,0.75)'; ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
    ctx.fillStyle = col; ctx.fillRect(x, y, w * clamp(f, 0, 1), h);
  }
  function drawSettlements() {
    var lab = ST.names, s = V.s;
    S.provs.forEach(function (p) {
      var x = sx(p.lx), y = sy(p.ly);
      if (x < -60 || y < -60 || x > stage.clientWidth + 60 || y > stage.clientHeight + 60) return;
      var vis = visibleProv(p);
      if (p.sea) { if (lab && s >= 0.5) { ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.globalAlpha = 0.6; halo(p.name, x, y + 26, 12, '#BFE0F7', 3); ctx.globalAlpha = 1; } return; }
      var rel = s / (V.fit || s), hv = NP >= 220 ? 1.7 : NP >= 90 ? 1.35 : 1, ht = NP >= 220 ? 1.2 : NP >= 90 ? 0.85 : 0.7, hc = NP >= 220 ? 1.05 : 0;
      if (!p.capital && S.selP !== p.id && !(p.occ > 0) && (p.set === 0 ? rel < hv : p.set === 1 ? rel < ht : rel < hc)) return;
      var scl = CK !== 1; if (scl) { ctx.save(); ctx.translate(x, y); ctx.scale(CK, CK); x = 0; y = 0; }
      drawSettle(p, x, y);
      var off = (p.capital ? 15 : p.set === 2 ? 14 : p.set === 1 ? 12 : 10), showName = lab && vis && (p.set === 2 || p.capital || (p.set === 1 && s >= 0.85) || s >= 1.35);
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      if (showName) { halo(p.name, x, y + off, 11, '#fff', 3); off += 13; }
      if (s >= 2.1 && vis) { halo('нас. ' + popFmt(p.pop), x, y + off, 10, '#C9D5E1', 2.5); off += 12; }
      if (S.phase === 'play' && vis) {
        var siege = S.armies.some(function (a) { return a.prov === p.id && isWar(a.owner, p.owner); });
        if (p.occ > 0) { bar(x - 16, y + off + 1, 32, 4, p.occ / 100, rgb(COL[p.occBy >= 0 ? p.occBy : 7], 1.15)); off += 8; }
        else if (siege) { bar(x - 16, y + off + 1, 32, 4, p.garrison / gcap(p), '#F0A53C'); off += 8; }
      }
      if (S.phase === 'play' && p.reb > 0) { halo((p.reb === 2 ? 'ВОССТАНИЕ ' : 'МЯТЕЖ ') + popFmt(p.rebS), x, y + off, 10, '#FF6A5C', 3); off += 12; }
      if (scl) ctx.restore();
    });
  }
  function routePts(a, st) {
    var pts = [], p0 = S.provs[a.prov];
    pts.push([sx(p0.lx), sy(p0.ly)]);
    a.route.forEach(function (id) { var q = S.provs[id]; pts.push([sx(q.lx), sy(q.ly)]); });
    return pts;
  }
  function drawRoutes() {
    if (S.phase !== 'play' || ANIM) return;
    S.armies.forEach(function (a) {
      if (a.owner !== S.player || !a.route.length) return;
      var sel = a.id === S.selA, pts = routePts(a), c = COL[a.owner], i;
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.setLineDash([]);
      ctx.strokeStyle = 'rgba(4,10,18,0.7)'; ctx.lineWidth = sel ? 6 : 4.4;
      ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); for (i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]); ctx.stroke();
      ctx.setLineDash([8, 6]);
      ctx.strokeStyle = sel ? '#fff' : rgb(c, 1.2); ctx.lineWidth = sel ? 3 : 2.2;
      ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); for (i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]); ctx.stroke();
      ctx.setLineDash([]);
      var l = pts[pts.length - 1], pv = pts[pts.length - 2], an = Math.atan2(l[1] - pv[1], l[0] - pv[0]), hd = sel ? 10 : 8;
      ctx.fillStyle = sel ? '#fff' : rgb(c, 1.2); ctx.strokeStyle = 'rgba(4,10,18,0.8)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(l[0] + Math.cos(an) * hd * 0.6, l[1] + Math.sin(an) * hd * 0.6);
      ctx.lineTo(l[0] + Math.cos(an + 2.5) * hd, l[1] + Math.sin(an + 2.5) * hd);
      ctx.lineTo(l[0] + Math.cos(an - 2.5) * hd, l[1] + Math.sin(an - 2.5) * hd); ctx.closePath(); ctx.stroke(); ctx.fill();
      if (sel) { ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; halo(routeTurns(a) + ' х.', l[0], l[1] - 10, 11, '#fff', 3); }
    });
  }
  var CK = 1;
  function drawCounter(x, y, ar, sel) {
    if (CK === 1) { drawCounter0(x, y, ar, sel); return; }
    ctx.save(); ctx.translate(x, y); ctx.scale(CK, CK); drawCounter0(0, 0, ar, sel); ctx.restore();
  }
  function drawCounterClassic(x, y, ar, sel) {
    var w = 44, h = 22, c = COL[ar.owner], x0 = x - w / 2, y0 = y - h / 2, orgc = ar.org > 60 ? '#7BDC8E' : ar.org > 30 ? '#F2C14E' : '#EF6B5B';
    if (sel) { ctx.fillStyle = 'rgba(255,255,255,0.25)'; rrect(x0 - 4, y0 - 4, w + 8, h + 8, 8); ctx.fill(); }
    ctx.fillStyle = 'rgba(4,10,18,0.55)'; rrect(x0 - 1, y0 + 1, w + 2, h + 2, 6); ctx.fill();
    ctx.fillStyle = rgb(c, 0.86); rrect(x0, y0, w, h, 5); ctx.fill();
    ctx.lineWidth = sel ? 2.4 : 1.4; ctx.strokeStyle = sel ? TC.acc === '#1C6DB8' ? '#fff' : '#fff' : 'rgba(255,255,255,0.85)'; rrect(x0, y0, w, h, 5); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '700 12px Inter, system-ui, sans-serif'; ctx.fillStyle = '#fff'; ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.strokeText(String(U(ar.troops)), x, y - 2); ctx.fillText(String(U(ar.troops)), x, y - 2);
    if (ar.stance === 'hold' || ar.stance === 'res' || ar.wait > 0) {
      var tg = ar.stance === 'hold' ? 'О' + (ar.dug || '') : ar.stance === 'res' ? 'Р' : '…';
      ctx.fillStyle = ar.stance === 'hold' ? '#2F6FB0' : ar.stance === 'res' ? '#7A5BB0' : '#6B7683';
      rrect(x0 - 5, y0 - 8, 20, 12, 4); ctx.fill(); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.font = '700 9px Inter, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(tg, x0 + 5, y0 - 1.5);
      ctx.font = '700 12px Inter, system-ui, sans-serif';
    }
    if (!ANIM && ar.blk && armyBlk(ar)) { ctx.fillStyle = '#C62828'; rrect(x0 + w - 17, y0 - 8, 22, 12, 4); ctx.fill(); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.stroke(); ctx.fillStyle = '#fff'; ctx.font = '700 9px Inter, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('БЛК', x0 + w - 6, y0 - 1.5); ctx.font = '700 12px Inter, system-ui, sans-serif'; }
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(x0 + 4, y0 + h - 6, w - 8, 3);
    ctx.fillStyle = orgc; ctx.fillRect(x0 + 4, y0 + h - 6, (w - 8) * clamp(ar.org / 100, 0, 1), 3);
  }

  function armyDims() {
    var st = ST.armyStyle;
    if (st === 'classic') return { sp: 48, up: 27, hx: 24, hy: 13, hw: 48, hh: 28, more: 74 };
    return { sp: 40, up: 28, hx: 20, hy: 22, hw: 40, hh: 44, more: 62 };
  }
  function genStars(g) { return g ? Math.min(5, Math.ceil(g.lvl / 2)) : 0; }
  function starPath(cx, cy, r) {
    ctx.beginPath();
    for (var i = 0; i < 10; i++) {
      var rr = i % 2 ? r * 0.45 : r, an = -Math.PI / 2 + i * Math.PI / 5;
      if (i) ctx.lineTo(cx + Math.cos(an) * rr, cy + Math.sin(an) * rr); else ctx.moveTo(cx + Math.cos(an) * rr, cy + Math.sin(an) * rr);
    }
    ctx.closePath();
  }
  function drawStars(cx, cy, g, r, gap) {
    var n = genStars(g), i, x0;
    if (!g) {
      ctx.lineWidth = 1.1; ctx.strokeStyle = 'rgba(225,232,245,0.9)'; starPath(cx, cy, r); ctx.stroke();
      return;
    }
    x0 = cx - (n - 1) * gap / 2;
    for (i = 0; i < n; i++) { starPath(x0 + i * gap, cy, r); ctx.fillStyle = '#FFD54A'; ctx.fill(); ctx.lineWidth = 0.7; ctx.strokeStyle = 'rgba(60,40,0,0.85)'; ctx.stroke(); }
  }
  function tagPill(x0, y0, w, label, fill) {
    ctx.fillStyle = fill; rrect(x0, y0, w, 12, 4); ctx.fill(); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.font = '700 9px Inter, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(label, x0 + w / 2, y0 + 6.5);
  }
  function stanceTag(ar) { return ar.stance === 'hold' ? 'О' + (ar.dug || '') : ar.stance === 'res' ? 'Р' : '…'; }
  function drawCounter0(x, y, ar, sel) {
    if (ST.armyStyle === 'classic') drawCounterClassic(x, y, ar, sel);
    else if (ST.armyStyle === 'banner') drawCounterBanner(x, y, ar, sel);
    else if (mapLook() && mapLook().sq) drawCounterSquare(x, y, ar, sel);
    else if (mapLook() && mapLook().glow) { ctx.shadowColor = mapLook().glow; ctx.shadowBlur = 12; drawCounterRound(x, y, ar, sel); ctx.shadowBlur = 0; ctx.shadowColor = 'rgba(0,0,0,0)'; }
    else drawCounterRound(x, y, ar, sel);
  }
  function drawCounterSquare(x, y, ar, sel) {
    var c = COL[ar.owner], R = 15, cx = x, cy = y - 5, g = genOf(ar), of = clamp(ar.org / 100, 0, 1), orgc = ar.org > 60 ? '#7BDC8E' : ar.org > 30 ? '#F2C14E' : '#EF6B5B', tx = String(U(ar.troops)), gl = mapLook().glow;
    if (sel) { ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fillRect(cx - R - 6, cy - R - 5, 2 * R + 12, 2 * R + 14); }
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(cx - R + 3, cy - R + 3, 2 * R, 2 * R);
    if (gl) { ctx.shadowColor = gl; ctx.shadowBlur = 10; }
    ctx.fillStyle = rgb(c, gl ? 0.7 : 1); ctx.fillRect(cx - R, cy - R, 2 * R, 2 * R);
    ctx.lineWidth = sel ? 3 : 2.2; ctx.strokeStyle = gl || '#FFFFFF'; ctx.strokeRect(cx - R, cy - R, 2 * R, 2 * R);
    ctx.shadowBlur = 0; ctx.shadowColor = 'rgba(0,0,0,0)';
    ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fillRect(cx - R, cy + R - 5, 2 * R, 5);
    ctx.fillStyle = orgc; ctx.fillRect(cx - R, cy + R - 5, 2 * R * of, 5);
    if (emAny(ar.owner)) { ctx.lineWidth = 1.4; ctx.strokeStyle = 'rgba(255,92,70,0.95)'; ctx.setLineDash([3, 2.5]); ctx.strokeRect(cx - R - 4, cy - R - 4, 2 * R + 8, 2 * R + 8); ctx.setLineDash([]); }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '800 ' + (tx.length > 3 ? 10 : tx.length > 2 ? 11 : 13) + 'px Inter, system-ui, sans-serif'; ctx.fillStyle = '#fff'; ctx.lineWidth = 2.6; ctx.strokeStyle = 'rgba(0,0,0,0.75)';
    ctx.strokeText(tx, cx, cy - 1.5); ctx.fillText(tx, cx, cy - 1.5);
    var n = g ? genStars(g) : 1, pw = Math.max(22, n * 8.4 + 8), py = cy + R + 3;
    ctx.fillStyle = g ? 'rgba(18,24,36,0.94)' : 'rgba(18,24,36,0.7)'; ctx.fillRect(cx - pw / 2, py, pw, 12.5);
    ctx.lineWidth = 1; ctx.strokeStyle = g ? 'rgba(255,213,74,0.95)' : 'rgba(210,220,235,0.55)'; ctx.strokeRect(cx - pw / 2, py, pw, 12.5);
    drawStars(cx, py + 6.4, g, 3.8, 8.4);
    if (ar.stance === 'hold' || ar.stance === 'res' || ar.wait > 0) tagPill(cx - R - 7, cy - R - 3, 20, stanceTag(ar), ar.stance === 'hold' ? '#2F6FB0' : ar.stance === 'res' ? '#7A5BB0' : '#6B7683');
  }
  function drawCounterRound(x, y, ar, sel) {
    var c = COL[ar.owner], R = 14, cx = x, cy = y - 5, g = genOf(ar), of = clamp(ar.org / 100, 0, 1), orgc = ar.org > 60 ? '#7BDC8E' : ar.org > 30 ? '#F2C14E' : '#EF6B5B', tx = String(U(ar.troops));
    if (sel) { ctx.fillStyle = 'rgba(255,255,255,0.28)'; ctx.beginPath(); ctx.arc(cx, cy + 2, R + 8, 0, 6.2832); ctx.fill(); }
    ctx.fillStyle = 'rgba(4,10,18,0.5)'; ctx.beginPath(); ctx.arc(cx + 0.5, cy + 1.5, R + 3.4, 0, 6.2832); ctx.fill();
    ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); ctx.arc(cx, cy, R + 1.2, 0, 6.2832); ctx.stroke();
    if (of > 0.01) { ctx.strokeStyle = orgc; ctx.beginPath(); ctx.arc(cx, cy, R + 1.2, -Math.PI / 2, -Math.PI / 2 + of * 6.2832); ctx.stroke(); }
    var gr = ctx.createRadialGradient(cx - 4, cy - 5, 1, cx, cy, R);
    gr.addColorStop(0, rgb(c, 1.25)); gr.addColorStop(1, rgb(c, 0.82));
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy, R - 1, 0, 6.2832); ctx.fill();
    ctx.lineWidth = sel ? 2.4 : 1.3; ctx.strokeStyle = 'rgba(255,255,255,0.92)'; ctx.beginPath(); ctx.arc(cx, cy, R - 1, 0, 6.2832); ctx.stroke();
    if (emAny(ar.owner)) { ctx.lineWidth = 1.4; ctx.strokeStyle = 'rgba(255,92,70,0.95)'; ctx.setLineDash([3, 2.5]); ctx.beginPath(); ctx.arc(cx, cy, R + 5.2, 0, 6.2832); ctx.stroke(); ctx.setLineDash([]); }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '800 ' + (tx.length > 3 ? 10 : tx.length > 2 ? 11 : 13) + 'px Inter, system-ui, sans-serif'; ctx.fillStyle = '#fff'; ctx.lineWidth = 2.6; ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.strokeText(tx, cx, cy + 0.5); ctx.fillText(tx, cx, cy + 0.5);
    // general plate
    var n = g ? genStars(g) : 1, pw = Math.max(22, n * 8.4 + 8), py = cy + R + 1;
    ctx.fillStyle = g ? 'rgba(18,24,36,0.94)' : 'rgba(18,24,36,0.7)'; rrect(cx - pw / 2, py, pw, 12.5, 6); ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = g ? 'rgba(255,213,74,0.95)' : 'rgba(210,220,235,0.55)'; rrect(cx - pw / 2, py, pw, 12.5, 6); ctx.stroke();
    drawStars(cx, py + 6.4, g, 3.8, 8.4);
    if (ar.stance === 'hold' || ar.stance === 'res' || ar.wait > 0) tagPill(cx - R - 7, cy - R - 3, 20, stanceTag(ar), ar.stance === 'hold' ? '#2F6FB0' : ar.stance === 'res' ? '#7A5BB0' : '#6B7683');
    if (!ANIM && ar.blk && armyBlk(ar)) tagPill(cx + R - 15, cy - R - 3, 24, 'БЛК', '#C62828');
  }
  function drawCounterBanner(x, y, ar, sel) {
    var c = COL[ar.owner], w = 32, h = 33, x0 = x - w / 2, y0 = y - 21, g = genOf(ar), of = clamp(ar.org / 100, 0, 1), orgc = ar.org > 60 ? '#7BDC8E' : ar.org > 30 ? '#F2C14E' : '#EF6B5B', tx = String(U(ar.troops)), em = emAny(ar.owner);
    function cloth() {
      ctx.beginPath(); ctx.moveTo(x0, y0 + 2); ctx.lineTo(x0 + w, y0 + 2); ctx.lineTo(x0 + w, y0 + h); ctx.lineTo(x0 + w / 2, y0 + h - 6); ctx.lineTo(x0, y0 + h); ctx.closePath();
    }
    if (sel) { ctx.fillStyle = 'rgba(255,255,255,0.28)'; rrect(x0 - 7, y0 - 5, w + 14, h + 12, 9); ctx.fill(); }
    ctx.save(); ctx.translate(1, 1.5); ctx.fillStyle = 'rgba(4,10,18,0.5)'; cloth(); ctx.fill(); ctx.restore();
    var gr = ctx.createLinearGradient(x0, y0, x0 + w, y0 + h);
    gr.addColorStop(0, rgb(c, 1.2)); gr.addColorStop(1, rgb(c, 0.8));
    ctx.fillStyle = gr; cloth(); ctx.fill();
    ctx.lineWidth = sel ? 2.3 : 1.3; ctx.strokeStyle = 'rgba(255,255,255,0.92)'; cloth(); ctx.stroke();
    ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.strokeStyle = em ? '#FF5C46' : '#2b2f38'; ctx.beginPath(); ctx.moveTo(x0 - 3, y0); ctx.lineTo(x0 + w + 3, y0); ctx.stroke(); ctx.lineCap = 'butt';
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(x0 + 3, y0 + 6, 3, h - 18);
    ctx.fillStyle = orgc; ctx.fillRect(x0 + 3, y0 + 6 + (h - 18) * (1 - of), 3, (h - 18) * of);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '800 ' + (tx.length > 3 ? 10 : tx.length > 2 ? 11 : 13) + 'px Inter, system-ui, sans-serif'; ctx.fillStyle = '#fff'; ctx.lineWidth = 2.6; ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.strokeText(tx, x + 2, y0 + 11.5); ctx.fillText(tx, x + 2, y0 + 11.5);
    drawStars(x + 2, y0 + 21.5, g, 3.2, 6.6);
    if (ar.stance === 'hold' || ar.stance === 'res' || ar.wait > 0) tagPill(x0 - 6, y0 - 10, 20, stanceTag(ar), ar.stance === 'hold' ? '#2F6FB0' : ar.stance === 'res' ? '#7A5BB0' : '#6B7683');
    if (!ANIM && ar.blk && armyBlk(ar)) tagPill(x0 + w - 17, y0 - 10, 24, 'БЛК', '#C62828');
  }
  function rrect(x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
  }
  function visibleArmy(a, pid) {
    if (!fogOn() || S.phase !== 'play' || friendlyTo(a.owner, S.player)) return true;
    if (S.intel && S.intel[a.owner] >= S.round) return true;
    return visibleProv(S.provs[pid]);
  }
  function drawArmies() {
    HIT = [];
    if (S.phase === 'pick') return;
    var groups = {}, list = [], AD = armyDims();
    if (ANIM) {
      Object.keys(ANIM.arms).forEach(function (k) { var ar = ANIM.arms[k]; list.push({ ar: ar, wx: ar.x, wy: ar.y, key: Math.round(ar.x) + ',' + Math.round(ar.y) }); });
    } else {
      S.armies.forEach(function (a) { var p = S.provs[a.prov]; if (visibleArmy(a, a.prov)) list.push({ ar: a, wx: p.lx, wy: p.ly, key: String(a.prov) }); });
    }
    list.forEach(function (e) { (groups[e.key] || (groups[e.key] = [])).push(e); });
    Object.keys(groups).forEach(function (k) {
      var g = groups[k], n = Math.min(g.length, 3);
      g.sort(function (a, b) { return (a.ar.owner === S.player ? 0 : 1) - (b.ar.owner === S.player ? 0 : 1) || b.ar.troops - a.ar.troops; });
      for (var i = 0; i < n; i++) {
        var e = g[i], x = sx(e.wx) + (i - (n - 1) / 2) * AD.sp * CK, y = sy(e.wy) - AD.up * CK, sel = !ANIM && (e.ar.id === S.selA || (S.multi && S.multi.indexOf(e.ar.id) >= 0));
        if (x < -50 || y < -40 || x > stage.clientWidth + 50 || y > stage.clientHeight + 40) continue;
        drawCounter(x, y, e.ar, sel);
        if (!ANIM) HIT.push({ id: e.ar.id, x: x - AD.hx * CK, y: y - AD.hy * CK, w: AD.hw * CK, h: AD.hh * CK });
      }
      if (g.length > 3) { var e0 = g[2]; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; halo('+' + (g.length - 3), sx(e0.wx) + AD.more * CK, sy(e0.wy) - AD.up * CK, 11, '#fff', 3); }
    });
  }
  function drawFronts() {
    if (S.phase !== 'play' || S.layer !== 'mil' || ANIM || !S.fronts) return;
    S.fronts.forEach(function (f) {
      if (!f.cx) return;
      var x = sx(f.cx), y = sy(f.cy), txt = '×' + (Math.round(f.ratio * 10) / 10), col = f.ratio >= 1.3 ? '#2FAE6C' : f.ratio >= 0.8 ? '#D9A12C' : '#D8483B', w = 46, h = 22;
      ctx.fillStyle = 'rgba(4,10,18,0.6)'; rrect(x - w / 2 - 1, y - h / 2 + 1, w + 2, h + 2, 8); ctx.fill();
      ctx.fillStyle = col; rrect(x - w / 2, y - h / 2, w, h, 7); ctx.fill();
      ctx.lineWidth = f.id === S.selF ? 2.6 : 1.4; ctx.strokeStyle = '#fff'; rrect(x - w / 2, y - h / 2, w, h, 7); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.font = '700 12px Inter, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(txt, x, y + 0.5);
      HIT.push({ front: f.id, x: x - w / 2, y: y - h / 2, w: w, h: h });
    });
  }
  function drawFx(now) {
    if (!ANIM) return;
    var lt = lite();
    ANIM.fx.forEach(function (f) {
      if (lt && f.k !== 'num') return;
      var t = clamp((now - f.t0) / f.d, 0, 1), x = sx(f.x), y = sy(f.y) - 6;
      if (f.k === 'clash') {
        var r = 8 + t * 22; ctx.strokeStyle = 'rgba(255,200,90,' + (1 - t) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.95 - t * 0.6) + ')'; ctx.lineWidth = 3; ctx.beginPath();
        ctx.moveTo(x - 10, y - 10); ctx.lineTo(x + 10, y + 10); ctx.moveTo(x + 10, y - 10); ctx.lineTo(x - 10, y + 10); ctx.stroke();
      } else if (f.k === 'num') {
        ctx.globalAlpha = 1 - t * t; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
        halo(f.text, x + (f.c === 'a' ? -20 : 20), y - 18 - t * 26, 13, f.c === 'a' ? '#FFD166' : '#FF8B7B', 3);
        ctx.globalAlpha = 1;
      } else if (f.k === 'pulse') {
        ctx.strokeStyle = rgb(COL[f.owner], 1.2); ctx.globalAlpha = 1 - t; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(x, y + 6, 8 + t * 40, 0, 6.2832); ctx.stroke(); ctx.globalAlpha = 1;
      }
    });
  }

  var fidSeq = 0;
  function mkSC() { return { c: document.createElement('canvas'), base: '', tx: 0, ty: 0, ok: false, timer: 0, Mx: 0, My: 0 }; }
  var SCS = [mkSC(), mkSC()];
  function paintLayer(k, ox, oy) {
    LOD = V.s < 2.2 ? 1 : 0;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (k === 0) { ctx.fillStyle = TC.sea; ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height); }
    else ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.setTransform(DPR * V.s, 0, 0, DPR * V.s, DPR * V.tx + ox, DPR * V.ty + oy);
    if (k === 0) { drawGrid(); drawCoastGlow(); return; }
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(world, 0, 0);
    if (ST.decor && V.s >= 0.75) drawDecor();
    drawBorders();
  }
  function paintLayer2Direct() {
    LOD = V.s < 2.2 ? 1 : 0;
    ctx.setTransform(DPR * V.s, 0, 0, DPR * V.s, DPR * V.tx, DPR * V.ty);
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(world, 0, 0);
    if (ST.decor && V.s >= 0.75) drawDecor();
    drawBorders();
  }
  function layerBase(k) {
    if (k === 0) return [canvas.width, canvas.height, DPR, V.s, TC.dark, TC.sea, MAP.__id, styId()].join('|');
    var fr = S.fronts && S.layer === 'mil' ? (S.fronts.__id || (S.fronts.__id = ++fidSeq)) : 0;
    return [canvas.width, canvas.height, DPR, V.s, rasterVer, ownSig(), relSig(), TC.dark, ST.decor, S.phase, S.layer === 'mil' ? 1 : 0, fr, S.selF, S.phase === 'play' ? S.selP : -1, MAP.__id, styId()].join('|');
  }
  function drawStatic(k, force) {
    var L = SCS[k], cw = canvas.width, ch = canvas.height, base = layerBase(k), Mx = Math.round(cw * 0.2), My = Math.round(ch * 0.2), dx = 0, dy = 0;
    var need = force || !L.ok || L.base !== base;
    if (!need) {
      dx = (V.tx - L.tx) * DPR; dy = (V.ty - L.ty) * DPR;
      if (Math.abs(dx) > L.Mx || Math.abs(dy) > L.My) need = true;
      else if (dx !== 0 || dy !== 0) {
        if (L.timer) clearTimeout(L.timer);
        L.timer = setTimeout(function () { L.timer = 0; if (S && !ANIM) draw(performance.now(), true); }, 130);
      }
    }
    if (need) {
      if (L.timer) { clearTimeout(L.timer); L.timer = 0; }
      var sw = cw + 2 * Mx, sh = ch + 2 * My, saved = ctx;
      if (L.c.width !== sw || L.c.height !== sh) { L.c.width = sw; L.c.height = sh; }
      ctx = L.c.getContext('2d'); VM.x = Mx / DPR; VM.y = My / DPR;
      try { paintLayer(k, Mx, My); } finally { ctx = saved; VM.x = 0; VM.y = 0; }
      L.base = base; L.tx = V.tx; L.ty = V.ty; L.ok = true; L.Mx = Mx; L.My = My; dx = 0; dy = 0;
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.drawImage(L.c, Math.round(dx) - L.Mx, Math.round(dy) - L.My);
  }
  /* ---------- minimap ---------- */
  var miniC = null, mctx = null, miniT = 0, miniTm = 0, miniDrag = false, miniDims = [1, 1];
  function drawMini(force) {
    if (!miniC) { miniC = $('mini'); mctx = miniC ? miniC.getContext('2d') : null; if (!mctx) return; bindMini(); }
    var show = !!(ST.mini && !lite() && S && MAP && !ANIM);
    miniC.hidden = !show;
    if (!show) return;
    var now = performance.now();
    if (!force && now - miniT < 120) { if (!miniTm) miniTm = setTimeout(function () { miniTm = 0; drawMini(true); }, 130); return; }
    miniT = now;
    var lg = innerWidth < 520 || innerHeight < 520 ? 84 : 120, mw, mh, dp = Math.min(DPR || 1, 2);
    if (W >= H) { mw = lg; mh = Math.round(lg * H / W); } else { mh = lg; mw = Math.round(lg * W / H); }
    if (miniC.width !== Math.round(mw * dp) || miniC.height !== Math.round(mh * dp)) { miniC.width = Math.round(mw * dp); miniC.height = Math.round(mh * dp); miniC.style.width = mw + 'px'; miniC.style.height = mh + 'px'; }
    miniDims = [mw, mh];
    mctx.setTransform(dp, 0, 0, dp, 0, 0);
    mctx.fillStyle = TC.sea; mctx.fillRect(0, 0, mw, mh);
    mctx.imageSmoothingEnabled = true; mctx.drawImage(world, 0, 0, W, H, 0, 0, mw, mh);
    var cw = stage.clientWidth, ch = stage.clientHeight, kx = mw / W, ky = mh / H;
    var x0 = clamp(-V.tx / V.s, 0, W) * kx, y0 = clamp(-V.ty / V.s, 0, H) * ky, x1 = clamp((cw - V.tx) / V.s, 0, W) * kx, y1 = clamp((ch - V.ty) / V.s, 0, H) * ky;
    mctx.lineWidth = 3; mctx.strokeStyle = 'rgba(0,0,0,0.55)'; mctx.strokeRect(x0, y0, Math.max(2, x1 - x0), Math.max(2, y1 - y0));
    mctx.lineWidth = 1.5; mctx.strokeStyle = '#fff'; mctx.strokeRect(x0, y0, Math.max(2, x1 - x0), Math.max(2, y1 - y0));
  }
  function miniGo(e) {
    var r = miniC.getBoundingClientRect(), fx = clamp((e.clientX - r.left) / r.width, 0, 1), fy = clamp((e.clientY - r.top) / r.height, 0, 1), cw = stage.clientWidth || 360, ch = stage.clientHeight || 500;
    V.tx = cw / 2 - fx * W * V.s; V.ty = ch / 2 - fy * H * V.s; clampView(); draw(); drawMini(true);
  }
  function bindMini() {
    miniC.addEventListener('pointerdown', function (e) { e.stopPropagation(); e.preventDefault(); miniDrag = true; try { miniC.setPointerCapture(e.pointerId); } catch (er) { /* ignore */ } miniGo(e); });
    miniC.addEventListener('pointermove', function (e) { if (miniDrag) miniGo(e); });
    miniC.addEventListener('pointerup', function () { miniDrag = false; });
    miniC.addEventListener('pointercancel', function () { miniDrag = false; });
  }
  var LD = { t: 0, tm: 0 }, lastSig = '', DVER = 0;
  function drawSig() { var ah = 0; S.armies.forEach(function (a) { ah = (ah * 31 + a.prov * 7 + a.troops + (a.route.length ? 1 : 0) + Math.round(a.org)) % 1000003; }); return [V.tx.toFixed(1), V.ty.toFixed(1), V.s.toFixed(3), canvas.width, canvas.height, S.round, S.selA, S.selP, S.layer, S.phase, S.ui.view ? 1 : 0, ah, DVER].join('|'); }
  function draw(now, force) {
    if (!S || !MAP) return;
    if (!ANIM && !force) {
      if (lite()) { var tn = performance.now(); if (tn - LD.t < 70) { if (!LD.tm) LD.tm = setTimeout(function () { LD.tm = 0; draw(); }, 75); return; } LD.t = tn; }
      if (now === undefined && !rasterDirty) { var sg = drawSig(); if (sg === lastSig) return; lastSig = sg; } else lastSig = '';
    }
    if (rasterDirty) buildRaster();
    var cw = stage.clientWidth, ch = stage.clientHeight;
    if (canvas.width < 2 || cw < 2) return;
    CK = Math.min(cw, ch * 1.15) < 430 ? 0.82 : 1;
    if (fogOn() && S.phase === 'play') { paintLayer(0, 0, 0); paintLayer2Direct(); }
    else { drawStatic(0, force); drawStatic(1, force); }
    ctx.setTransform(DPR * V.s, 0, 0, DPR * V.s, DPR * V.tx, DPR * V.ty);
    drawSeaLinks();
    drawTrade(now);
    drawEngagements(now);
    drawSupply();
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    drawRoutes();
    drawSettlements();
    drawArmies();
    drawFronts();
    drawFightBadges();
    drawFx(now || performance.now());
    drawShips(now); tradeKick();
    drawMini(false);
  }
