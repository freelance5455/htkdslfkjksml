  /* ---------- diplomacy ---------- */
  function isWar(a, b) { return a !== b && S.rel[a][b] === 'w'; }
  function isAlly(a, b) { return a !== b && S.rel[a][b] === 'a'; }
  function setRel(a, b, v) { S.rel[a][b] = v; S.rel[b][a] = v; }
  function adjOp(a, b, d) { var v = clamp(S.op[a][b] + d, -100, 100); S.op[a][b] = v; S.op[b][a] = v; }
  function neighborsC(c) {
    var o = {};
    S.provs.forEach(function (p) {
      if (p.owner !== c) return;
      p.nb.forEach(function (n) { var q = S.provs[n].owner; if (q !== c && q >= 0) o[q] = 1; });
      (MAP.lane[p.id] || []).forEach(function (l) { var q = S.provs[l.to].owner; if (q !== c && q >= 0) o[q] = 1; });
    });
    return Object.keys(o).map(Number).filter(function (q) { return owned(q).length > 0; });
  }
  function strength(c) { return troopsOf(c) + owned(c).length * 2; }
  /* ---------- sea trade routes & blockades ---------- */
  var TG = 5;
  function seaGrid() {
    var G = MAP.sg;
    if (G) return G;
    var gw = Math.ceil(W / TG), gh = Math.ceil(H / TG), n = gw * gh, sea = new Uint8Array(n), near = new Uint8Array(n), zone = new Int16Array(n).fill(-1), pid = MAP.pid, x, y, i;
    for (y = 0; y < gh; y++) for (x = 0; x < gw; x++) {
      var px = Math.min(W - 1, x * TG + 2), py = Math.min(H - 1, y * TG + 2), v = pid[py * W + px];
      if (v >= NP) { sea[y * gw + x] = 1; zone[y * gw + x] = v; }
    }
    for (y = 0; y < gh; y++) for (x = 0; x < gw; x++) {
      i = y * gw + x;
      if (!sea[i]) continue;
      if ((x > 0 && !sea[i - 1]) || (x < gw - 1 && !sea[i + 1]) || (y > 0 && !sea[i - gw]) || (y < gh - 1 && !sea[i + gw])) near[i] = 1;
    }
    var pc = new Int32Array(NP).fill(-1), pd = new Float32Array(NP).fill(1e12), cx = new Float32Array(NP), cy = new Float32Array(NP);
    function probe(land, xl, yl, xs, ys) {
      var gx = (xs / TG) | 0, gy = (ys / TG) | 0, best = -1, bdd = 1e9, ox, oy;
      for (oy = -1; oy <= 1; oy++) for (ox = -1; ox <= 1; ox++) {
        var qx = gx + ox, qy = gy + oy;
        if (qx < 0 || qy < 0 || qx >= gw || qy >= gh || !sea[qy * gw + qx]) continue;
        var ddx = qx * TG + 2 - xs, ddy = qy * TG + 2 - ys, dd = ddx * ddx + ddy * ddy;
        if (dd < bdd) { bdd = dd; best = qy * gw + qx; }
      }
      if (best < 0) return;
      var dl = Math.hypot(xl - MAP.lx[land], yl - MAP.ly[land]);
      if (dl < pd[land]) { pd[land] = dl; pc[land] = best; cx[land] = xl; cy[land] = yl; }
    }
    for (y = 0; y < H - 1; y++) for (x = 0; x < W - 1; x++) {
      var a = pid[y * W + x];
      if (a < 0) continue;
      var r = pid[y * W + x + 1], d = pid[(y + 1) * W + x];
      if (a < NP) { if (r >= NP) probe(a, x, y, x + 1, y); if (d >= NP) probe(a, x, y, x, y + 1); }
      else { if (r >= 0 && r < NP) probe(r, x + 1, y, x, y); if (d >= 0 && d < NP) probe(d, x, y + 1, x, y); }
    }
    G = MAP.sg = { gw: gw, gh: gh, sea: sea, near: near, zone: zone, pc: pc, cx: cx, cy: cy, rc: {} };
    return G;
  }
  function seaLos(x1, y1, x2, y2) {
    var d = Math.hypot(x2 - x1, y2 - y1), n = Math.ceil(d / 2), pid = MAP.pid, k;
    for (k = 2; k < n - 1; k++) {
      var f = k / n, xx = Math.round(x1 + (x2 - x1) * f), yy = Math.round(y1 + (y2 - y1) * f);
      if (xx < 0 || yy < 0 || xx >= W || yy >= H || pid[yy * W + xx] < NP) return false;
    }
    return true;
  }
  function gridRoute(srcs, dsts) {
    var G = seaGrid(), gw = G.gw, gh = G.gh, n = gw * gh, dist = new Float64Array(n).fill(1e9), prev = new Int32Array(n).fill(-1), hd = [], hi = [], srcProv = {}, popD = 0, popI = 0;
    function push(d, i) { var k = hd.length; hd.push(d); hi.push(i); while (k > 0) { var pr = (k - 1) >> 1; if (hd[pr] <= d) break; hd[k] = hd[pr]; hi[k] = hi[pr]; k = pr; } hd[k] = d; hi[k] = i; }
    function pop() {
      popD = hd[0]; popI = hi[0];
      var ld = hd.pop(), li = hi.pop(), n2 = hd.length;
      if (n2) { var k = 0; for (;;) { var c = 2 * k + 1; if (c >= n2) break; if (c + 1 < n2 && hd[c + 1] < hd[c]) c++; if (hd[c] >= ld) break; hd[k] = hd[c]; hi[k] = hi[c]; k = c; } hd[k] = ld; hi[k] = li; }
    }
    srcs.forEach(function (s) { if (srcProv[s.cell] === undefined) { srcProv[s.cell] = s.prov; dist[s.cell] = 0; push(0, s.cell); } });
    var found = -1;
    while (hd.length) {
      pop();
      var d0 = popD, i0 = popI;
      if (d0 > dist[i0]) continue;
      if (dsts[i0] !== undefined) { found = i0; break; }
      var x0 = i0 % gw, y0 = (i0 / gw) | 0, dx, dy;
      for (dy = -1; dy <= 1; dy++) for (dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        var nx = x0 + dx, ny = y0 + dy;
        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
        var j = ny * gw + nx;
        if (!G.sea[j]) continue;
        if (dx && dy && (!G.sea[y0 * gw + nx] || !G.sea[ny * gw + x0])) continue;
        var nd = d0 + (dx && dy ? 1.414 : 1) * (G.near[j] ? 1.9 : 1);
        if (nd < dist[j]) { dist[j] = nd; prev[j] = i0; push(nd, j); }
      }
    }
    if (found < 0) return null;
    var cells = [], c2 = found;
    while (c2 >= 0) { cells.push(c2); c2 = prev[c2]; }
    cells.reverse();
    return { cells: cells, from: srcProv[cells[0]], to: dsts[found] };
  }
  function pairPath(a, b, pa, pb) {
    var G = seaGrid(), key = a + '_' + b, sig = pa.join(',') + '|' + pb.join(','), c = G.rc[key];
    if (c && c.sig === sig) return c.r;
    var srcs = [], dsts = {}, r = null;
    pa.forEach(function (p) { if (G.pc[p] >= 0) srcs.push({ cell: G.pc[p], prov: p }); });
    pb.forEach(function (p) { if (G.pc[p] >= 0 && dsts[G.pc[p]] === undefined) dsts[G.pc[p]] = p; });
    if (srcs.length && Object.keys(dsts).length) {
      var res = gridRoute(srcs, dsts);
      if (res) {
        var pts = [[G.cx[res.from], G.cy[res.from]]], zones = [], i;
        res.cells.forEach(function (cell) {
          pts.push([(cell % G.gw) * TG + 2.5, ((cell / G.gw) | 0) * TG + 2.5]);
          var z = G.zone[cell];
          if (zones.indexOf(z) < 0) zones.push(z);
        });
        pts.push([G.cx[res.to], G.cy[res.to]]);
        var out = [pts[0]], ci = 0, last = pts.length - 1;
        while (ci < last) {
          var cj = last;
          while (cj > ci + 1 && !seaLos(pts[ci][0], pts[ci][1], pts[cj][0], pts[cj][1])) cj--;
          out.push(pts[cj]); ci = cj;
        }
        var cum = [0], len = 0;
        for (i = 1; i < out.length; i++) { len += Math.hypot(out[i][0] - out[i - 1][0], out[i][1] - out[i - 1][1]); cum.push(len); }
        r = { pts: out, cum: cum, len: Math.max(1, len), zones: zones, from: res.from, to: res.to };
      }
    }
    G.rc[key] = { sig: sig, r: r };
    return r;
  }
  function pointAt(pp, u) {
    var d = u * pp.len, c = pp.cum, i = 1;
    while (i < c.length - 1 && c[i] < d) i++;
    var x1 = pp.pts[i - 1][0], y1 = pp.pts[i - 1][1], x2 = pp.pts[i][0], y2 = pp.pts[i][1], seg = c[i] - c[i - 1] || 1, f = clamp((d - c[i - 1]) / seg, 0, 1);
    return [x1 + (x2 - x1) * f, y1 + (y2 - y1) * f, x2 - x1];
  }
  function armyBlk(a) { return !!(a.blk && S.provs[a.prov] && S.provs[a.prov].sea && !a.route.length); }
  function blockZones() {
    var o = {};
    S.armies.forEach(function (a) { if (armyBlk(a)) (o[a.prov] || (o[a.prov] = [])).push(a.owner); });
    return o;
  }
  function calcRoutes() {
    var out = [], a, b, ports = [], adj = {}, alive = [], blocks = blockZones();
    for (a = 0; a < NC; a++) { ports.push([]); alive.push(false); }
    S.provs.forEach(function (q) {
      if (q.sea || q.owner < 0) return;
      alive[q.owner] = true;
      if (q.port) ports[q.owner].push(q.id);
      q.lnb.forEach(function (n) { var o2 = S.provs[n].owner; if (o2 >= 0 && o2 !== q.owner) adj[q.owner + '_' + o2] = 1; });
    });
    for (a = 0; a < NC; a++) for (b = a + 1; b < NC; b++) {
      if (!S.trade[a][b] || !S.trade[b][a] || S.rel[a][b] === 'w' || !alive[a] || !alive[b]) continue;
      var pp = ports[a].length && ports[b].length ? pairPath(a, b, ports[a], ports[b]) : null;
      var rt = { a: a, b: b, kind: 'none', val: 0, base: 0, len: 0, pp: pp, cutBy: -1, cutZone: -1, pir: -1 };
      if (pp) {
        rt.len = pp.len; rt.base = 2 + clamp(Math.floor(pp.len / 120), 0, 2);
        for (var zi = 0; zi < pp.zones.length && rt.cutBy < 0; zi++) {
          var bl = blocks[pp.zones[zi]];
          if (!bl) continue;
          for (var bi = 0; bi < bl.length; bi++) {
            var X = bl[bi];
            if (X !== a && X !== b && !isAlly(X, a) && !isAlly(X, b)) { rt.cutBy = X; rt.cutZone = pp.zones[zi]; break; }
          }
        }
        if (rt.cutBy < 0 && S.pir && S.pir.length) for (var zp = 0; zp < pp.zones.length; zp++) if (pirAt(pp.zones[zp])) { rt.pir = pp.zones[zp]; break; }
        if (rt.cutBy < 0 && rt.pir < 0) { rt.kind = 'sea'; rt.val = rt.base; }
      }
      if (rt.kind === 'none') {
        if (adj[a + '_' + b]) { rt.kind = 'land'; rt.val = 1; if (!rt.base) rt.base = 1; }
        else if (rt.cutBy >= 0 || rt.pir >= 0) rt.kind = 'cut';
      }
      out.push(rt);
    }
    return out;
  }
  function routeSig() {
    var h = 7, a, b, i, M = 1000000007;
    for (a = 0; a < NC; a++) for (b = a + 1; b < NC; b++) h = (h * 31 + (S.trade[a][b] ? 1 : 0) + (S.rel[a][b] === 'a' ? 2 : S.rel[a][b] === 'w' ? 4 : 0)) % M;
    for (i = 0; i < NP; i++) { var q = S.provs[i]; h = (h * 31 + q.owner + 2 + (q.port ? 50 : 0)) % M; }
    S.armies.forEach(function (x) { if (armyBlk(x)) h = (h * 31 + x.prov * 11 + x.owner + 1) % M; });
    (S.pir || []).forEach(function (q) { h = (h * 31 + q.z * 7 + 3) % M; });
    return h;
  }
  function routes() {
    if (!S || !S.rel || !S.trade || !MAP || !S.provs) return [];
    var sig = routeSig();
    if (!S.rt || S.rtSig !== sig) { S.rt = calcRoutes(); S.rtSig = sig; }
    return S.rt;
  }
  function tradeBonus(c) {
    if (!S || !S.trade) return 0;
    var t = 0;
    routes().forEach(function (r) { if (r.a === c || r.b === c) t += r.val; });
    if (t > 0) t += resCount(c, 3) + netBonus(c);
    return t;
  }
  function routeOf(a, b) {
    var rs = routes();
    for (var i = 0; i < rs.length; i++) if ((rs[i].a === a && rs[i].b === b) || (rs[i].a === b && rs[i].b === a)) return rs[i];
    return null;
  }
  function tradeChip(c) {
    var us = S.player;
    if (!S.trade[us][c]) return '';
    var r = routeOf(us, c);
    if (!r) return '<span class="chip good">Торговля</span>';
    if (r.cutBy >= 0) return '<span class="chip bad">Путь перерезан · ' + CNAMES[r.cutBy] + '</span>';
    if (r.pir >= 0 && r.kind !== 'land') return '<span class="chip bad">Пираты на пути</span>';
    if (r.kind === 'sea') return '<span class="chip good">Морской путь +' + r.val + '</span>';
    if (r.kind === 'land') return '<span class="chip">По суше +1</span>';
    return '<span class="chip warn">Нет пути</span>';
  }
  function tradeHtml() {
    var us = S.player, rs = routes().filter(function (r) { return r.a === us || r.b === us; }), h = '<div class="sec"><h3 class="h">Торговые пути</h3>';
    if (!rs.length) return h + '<p class="note">Торговых договоров нет. Заключи договор: корабли пойдут по морю и будут приносить золото. Чем длиннее путь, тем больше доход, но тем легче его перерезать блокадой.</p></div>';
    h += '<p class="note">Доход от торговли: <b>+' + tradeBonus(us) + '</b> зол. в ход. Блокада морской зоны перерезает путь.' + (netBonus(us) ? ' Торговая сеть даёт из них +' + netBonus(us) + '.' : '') + '</p><dl class="kv">';
    rs.forEach(function (r) {
      var o = r.a === us ? r.b : r.a, d;
      if (r.cutBy >= 0) d = '<span class="verdict bad">перерезан блокадой · ' + CNAMES[r.cutBy] + '</span>' + (r.kind === 'land' ? ' · по суше +1' : '');
      else if (r.pir >= 0) d = '<span class="verdict bad">пираты · ' + esc(S.provs[r.pir].name) + '</span>' + (r.kind === 'land' ? ' · по суше +1' : '');
      else if (r.kind === 'sea') d = 'морем · зон ' + r.pp.zones.length + ' · +' + r.val;
      else if (r.kind === 'land') d = 'по суше · +1';
      else d = 'нет пути';
      h += '<dt>' + flagH(o) + ' ' + CNAMES[o] + '</dt><dd>' + d + '</dd>';
    });
    h += '</dl>';
    var zs = {};
    rs.forEach(function (r) { if (r.pir >= 0) zs[r.pir] = 1; });
    Object.keys(zs).forEach(function (z) { h += '<div class="row" style="margin-top:8px"><button class="btn sm" type="button" data-act="ransom" data-z="' + z + '"' + (S.gold[us] < 15 ? ' disabled' : '') + '>' + ico('anchor') + 'Откупиться от пиратов · 15 зол. (' + esc(S.provs[+z].name) + ')</button></div>'; });
    return h + '</div>';
  }
  function hurtBy(X, v) {
    return routes().some(function (r) { return r.cutBy === X && (r.a === v || r.b === v) && !isWar(v, X); });
  }
  function liftFor(X, v) {
    var zs = {}, n = 0, bz = blockZones();
    routes().forEach(function (r) {
      if (r.cutBy !== X || !(r.a === v || r.b === v)) return;
      r.pp.zones.forEach(function (z) { if (bz[z] && bz[z].indexOf(X) >= 0) zs[z] = 1; });
    });
    S.armies.forEach(function (a) { if (a.owner === X && a.blk && zs[a.prov]) { a.blk = false; n++; } });
    S.rtSig = null;
    return n;
  }
  function lostBy(X, v) {
    var t = 0;
    routes().forEach(function (r) { if (r.cutBy === X && (r.a === v || r.b === v)) t += Math.max(0, r.base - r.val); });
    return t;
  }
  function blockadeFail(c) {
    var us = S.player;
    if (!hurtBy(us, c)) return;
    adjOp(us, c, -12);
    S.bcb[c + '_' + us] = S.round + 6;
    if (!calmNow() && S.rel[us][c] === 'p' && Math.random() < 0.85) {
      declareWar(c, us);
      log('Держава ' + CNAMES[c] + ' начала войну: блокада не снята.', true, -1, 'dipl');
      for (var z = 0; z < NC; z++) if (z !== us && z !== c && owned(z).length && isAlly(c, z) && !isWar(z, us) && !isAlly(z, us) && Math.random() < 0.5) declareWar(z, us);
    } else toast('Держава ' + CNAMES[c] + ' недовольна: блокада не снята.', 'warn');
  }
  /* ---------- pirates ---------- */
  function pirAt(z) { return !!(S.pir && S.pir.some(function (q) { return q.z === z; })); }
  function pirTurn() {
    if (!S.pir) S.pir = [];
    var us = S.player, i;
    for (i = S.pir.length - 1; i >= 0; i--) {
      var q = S.pir[i], nm = S.provs[q.z].name, cl = null;
      S.armies.forEach(function (a) { if (!cl && a.prov === q.z && !a.route.length && a.troops >= 8) cl = a; });
      if (cl) {
        S.pir.splice(i, 1); S.rtSig = null; S.gold[cl.owner] += 10;
        if (cl.owner === us) { S.xs.pirK = (S.xs.pirK || 0) + 1; toast('Пираты в зоне «' + nm + '» разогнаны: добыча +10 зол.', 'good'); log('Пираты разогнаны в зоне «' + nm + '».', true, -1, 'sys'); }
      } else if (q.until <= S.round) {
        S.pir.splice(i, 1); S.rtSig = null;
        log('Пираты ушли из зоны «' + nm + '».', false, -1, 'sys');
      }
    }
    if (S.round < 5 || S.pir.length >= 2 || Math.random() > 0.11) return;
    var zc = [], mine = [];
    routes().forEach(function (r) {
      if (r.kind !== 'sea' || !r.pp) return;
      r.pp.zones.forEach(function (z) { if (!pirAt(z)) { zc.push(z); if (r.a === us || r.b === us) mine.push(z); } });
    });
    if (!zc.length) return;
    var pool = mine.length && Math.random() < 0.5 ? mine : zc, zn = pool[(Math.random() * pool.length) | 0];
    S.pir.push({ z: zn, until: S.round + 5 + ((Math.random() * 4) | 0) }); S.rtSig = null;
    var hit = routes().filter(function (r) { return r.pir === zn && (r.a === us || r.b === us); });
    if (hit.length) {
      var oc = hit[0].a === us ? hit[0].b : hit[0].a;
      news('dem', 'Пираты!', 'В зоне «' + S.provs[zn].name + '» пираты перерезали торговый путь с державой ' + CNAMES[oc] + '. Отправь армию в зону или откупись (Дипломатия).', 'dip');
      log('Пираты в зоне «' + S.provs[zn].name + '» перерезали твою торговлю.', true, -1, 'dipl');
    } else log('Пираты появились в зоне «' + S.provs[zn].name + '».', false, -1, 'sys');
  }
  function pirSprite(g, x, y, t, k) {
    g.save(); g.translate(x, y);
    var pr = 15 + Math.sin(t * 3) * 3;
    g.lineWidth = 2.2 * k; g.strokeStyle = 'rgba(214,52,40,0.85)'; g.setLineDash([5 * k, 4 * k]); g.beginPath(); g.arc(0, 0, pr * k, 0, 6.2832); g.stroke(); g.setLineDash([]);
    g.scale(k, k); g.lineJoin = 'round';
    g.fillStyle = '#1B1B22'; g.strokeStyle = 'rgba(255,255,255,0.8)'; g.lineWidth = 1.1;
    g.beginPath(); g.moveTo(-7, 1.5); g.lineTo(7, 1.5); g.lineTo(4.5, 5); g.lineTo(-4.5, 5); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = '#2A2A33';
    g.beginPath(); g.moveTo(0.8, -9); g.lineTo(0.8, 0.8); g.lineTo(6.2, 0.8); g.closePath(); g.fill(); g.stroke();
    g.beginPath(); g.moveTo(-0.8, -6.5); g.lineTo(-0.8, 0.8); g.lineTo(-5.2, 0.8); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = '#E0382B'; g.fillRect(0.4, -12, 4.6, 2.8);
    g.restore();
  }
  /* ---------- espionage ---------- */
  var SPY = [
    { k: 'intel', n: 'Разведка', c: 8, p: 0.85, d: 'Видишь все армии и земли державы 3 хода (при тумане войны) и узнаёшь её казну.' },
    { k: 'riot', n: 'Подстрекательство', c: 16, p: 0.55, d: '+25 недовольства в двух самых людных провинциях цели.' },
    { k: 'sab', n: 'Диверсия', c: 20, p: 0.5, d: 'Выводит из строя половину мощностей в самой промышленной провинции.' },
    { k: 'steal', n: 'Кража технологий', c: 24, p: 0.42, d: '+25 очков исследований. Работает, только если цель впереди по технологиям.' },
    { k: 'smear', n: 'Компромат', c: 12, p: 0.6, d: 'Остальные державы хуже относятся к цели (−10 к отношению).' }
  ];
  function spyOp(k) { return SPY.filter(function (o) { return o.k === k; })[0]; }
  function spyChance(k, c, t) {
    var q = spyOp(k).p;
    if (S.rel[c][t] === 'w') q += 0.08; else if (S.rel[c][t] === 'a') q -= 0.15;
    if (S.intel && S.intel[t] >= S.round && c === S.player) q += 0.05;
    return clamp(q, 0.1, 0.92);
  }
  function spyBlock(k, c, t) {
    if (S.gold[c] < spyOp(k).c) return 'Не хватает золота';
    if (S.spyCd && S.spyCd[c + '_' + t] > S.round) return 'Агенты отдыхают ещё ' + (S.spyCd[c + '_' + t] - S.round) + ' ход.';
    if (k === 'steal' && !(S.tech[t].done.length > S.tech[c].done.length)) return 'Цель не опережает тебя в технологиях';
    if (k === 'sab' && !owned(t).some(function (q) { return q.fac + q.civ > 0; })) return 'У цели нет цехов';
    if (k === 'intel' && !fogOn() && c === S.player) return 'Туман войны выключен, и так всё видно';
    return '';
  }
  function spyDo(c, t, k) {
    var o = spyOp(k), res = { ok: Math.random() < spyChance(k, c, t), msg: '', caught: false };
    S.gold[c] -= o.c;
    if (!S.spyCd) S.spyCd = {};
    S.spyCd[c + '_' + t] = S.round + 2;
    if (!res.ok) {
      adjOp(c, t, -25); S.inf[c] = Math.min(100, S.inf[c] + 3);
      res.msg = 'Операция «' + o.n + '» провалена: агентов схватили. Держава ' + CNAMES[t] + ' в ярости.';
      return res;
    }
    var os = owned(t), m;
    if (k === 'intel') {
      S.intel[t] = S.round + 3;
      res.msg = 'Разведка: казна ' + S.gold[t] + ' зол., войск ' + U(troopsOf(t)) + ' див., усталость от войны ' + r0(S.weary ? S.weary[t] : 0) + '%. Земли и армии видны 3 хода.';
      return res;
    }
    if (k === 'riot') {
      os.slice().sort(function (x, y) { return y.pop - x.pop; }).slice(0, 2).forEach(function (q) { q.unr = Math.min(100, (q.unr || 0) + 25); });
      m = os.slice().sort(function (x, y) { return y.pop - x.pop; }).slice(0, 2).map(function (q) { return q.name; });
      res.msg = 'Беспорядки вспыхнули в ' + m.join(' и ') + '.'; res.where = m;
    } else if (k === 'sab') {
      var bq = null; os.forEach(function (q) { if (q.fac + q.civ > 0 && (!bq || q.fac + q.civ > bq.fac + bq.civ)) bq = q; });
      bq.fd = Math.min(1, bq.fd + 0.5);
      res.msg = 'Диверсия удалась: цеха в ' + bq.name + ' выведены из строя.'; res.where = [bq.name];
    } else if (k === 'steal') {
      var tt = S.tech[c];
      if (tt.cur) tt.prog += 25; else tt.bank = Math.min(60, tt.bank + 25);
      res.msg = 'Чертежи украдены: +25 очков исследований.';
    } else {
      for (var x = 0; x < NC; x++) if (x !== c && x !== t && owned(x).length) adjOp(x, t, -10);
      res.msg = 'Компромат разослан: державу ' + CNAMES[t] + ' теперь меньше любят.';
    }
    res.caught = Math.random() < 0.25;
    if (res.caught) { adjOp(c, t, -15); S.inf[c] = Math.min(100, S.inf[c] + 2); res.msg += ' Но следы ведут к ' + CNAMES[c] + '.'; }
    return res;
  }
  function aiSpy() {
    var us = S.player;
    for (var c = 0; c < NC; c++) {
      if (c === us || !owned(c).length || S.gold[c] < 40) continue;
      var tg = [];
      for (var t = 0; t < NC; t++) if (t !== c && owned(t).length && (S.rel[c][t] === 'w' || S.op[c][t] < -20)) tg.push(t);
      if (!tg.length || Math.random() > 0.05 + (warEnemies(c).length ? 0.04 : 0)) continue;
      var tgt = tg[(Math.random() * tg.length) | 0], ks = ['riot', 'sab', 'smear'];
      if (S.tech[tgt].done.length > S.tech[c].done.length) ks.push('steal');
      var k = ks[(Math.random() * ks.length) | 0];
      if (spyBlock(k, c, tgt)) continue;
      var res = spyDo(c, tgt, k);
      if (tgt !== us) continue;
      if (!res.ok) { news('dem', 'Раскрыт шпион', 'Агенты державы ' + CNAMES[c] + ' пойманы при попытке «' + spyOp(k).n.toLowerCase() + '». Отношения испорчены.', null); log('Раскрыт шпион державы ' + CNAMES[c] + '.', true, -1, 'dipl'); }
      else if (k === 'riot' || k === 'sab') {
        news('dem', k === 'sab' ? 'Диверсия!' : 'Беспорядки!', (k === 'sab' ? 'Вражеские агенты вывели из строя цеха в ' : 'Кто-то разжигает недовольство в ') + (res.where || []).join(' и ') + '. ' + (res.caught ? 'След ведёт к державе ' + CNAMES[c] + '.' : 'Кто стоит за этим, неизвестно.'), null);
        log((k === 'sab' ? 'Диверсия' : 'Беспорядки') + ' в ' + (res.where || []).join(', ') + (res.caught ? ' · виновата держава ' + CNAMES[c] : '') + '.', true, -1, 'dipl');
      } else if (res.caught) log('Раскрыта операция «' + spyOp(k).n + '» державы ' + CNAMES[c] + '.', true, -1, 'dipl');
    }
  }
  function spyHtml() {
    var c = S.ui.spy, us = S.player;
    if (c == null || c < 0 || !owned(c).length) return head('Разведка', true, 'dip') + '<div class="sh-body"><p class="note">Цель недоступна.</p></div>';
    var h = head('Разведка · ' + CNAMES[c], true, 'dip') + '<div class="sh-body"><p class="note">В казне ' + S.gold[us] + ' зол. Провал даёт −25 к отношению, +3 агрессии. После любой операции агентам нужно 2 хода отдыха.</p>';
    if (S.ui.spyMsg) h += '<div class="verdict-big ' + (S.ui.spyOk ? 'verdict good' : 'verdict bad') + '" style="font-size:14px">' + esc(S.ui.spyMsg) + '</div>';
    h += '<div class="dips">' + SPY.map(function (o) {
      var bl = spyBlock(o.k, us, c);
      return '<div class="dip"><div class="hd"><span class="nm">' + o.n + '</span><span class="chip">шанс ' + Math.round(spyChance(o.k, us, c) * 100) + '%</span><span class="chip">' + o.c + ' зол.</span></div><p>' + o.d + '</p>' +
        '<div class="row"><button class="btn sm primary" type="button" data-act="spyop" data-k="' + o.k + '"' + (bl ? ' disabled' : '') + '>Провести</button>' + (bl ? '<span class="note" style="align-self:center">' + bl + '</span>' : '') + '</div></div>';
    }).join('') + '</div></div>';
    return h;
  }
  function blockadeTurn() {
    var us = S.player, rs = routes(), now = {}, loss = {}, zn = {}, infAdd = {};
    rs.forEach(function (r) {
      if (r.cutBy < 0) return;
      var X = r.cutBy;
      [r.a, r.b].forEach(function (v) {
        if (v === X || isWar(v, X)) return;
        var k = X + '_' + v; now[k] = 1; loss[k] = (loss[k] || 0) + Math.max(0, r.base - r.val); zn[k] = r.cutZone;
      });
    });
    Object.keys(S.blk).forEach(function (k) { if (!now[k]) delete S.blk[k]; });
    Object.keys(now).forEach(function (k) {
      var X = +k.split('_')[0], v = +k.split('_')[1];
      if (!owned(X).length || !owned(v).length) { delete S.blk[k]; return; }
      var n = S.blk[k] = (S.blk[k] || 0) + 1, zname = S.provs[zn[k]] ? S.provs[zn[k]].name : 'моря';
      adjOp(X, v, -5); S.bcb[v + '_' + X] = S.round + 8; infAdd[X] = 1;
      if (v === us) {
        if (n === 1 || n % 4 === 0) news('blk', 'Блокада!', 'Держава ' + CNAMES[X] + ' перекрыла морские пути (' + zname + '): торговля −' + loss[k] + ' зол. в ход. Можно поставить ультиматум в дипломатии.', 'dip');
        log('Блокада: ' + CNAMES[X] + ' перерезает твои торговые пути.', true, -1, 'dipl');
      } else if (X === us) {
        if (n === 1) toast('Блокада режет торговлю державы ' + CNAMES[v] + ' (−' + loss[k] + ' зол./ход). Они недовольны.', 'warn');
        if (n >= 2 && S.rel[us][v] === 'p' && !S.offers.some(function (o) { return o.from === v; }) && (S.blkCd[k] || 0) <= S.round) {
          S.offers.push({ from: v, kind: 'blockade', until: S.round + 2 });
          S.blkCd[k] = S.round + 8;
          news('ult', 'Ультиматум: блокада', 'Держава ' + CNAMES[v] + ' требует снять блокаду. Срок — 2 хода, иначе война.', 'dip');
        }
      } else if (n >= 3 && !calmNow() && S.rel[v][X] === 'p' && Math.random() < 0.3) {
        declareWar(v, X);
        log('Держава ' + CNAMES[v] + ' объявила войну из-за блокады, которую держит ' + CNAMES[X] + '.', false, -1, 'dipl');
      }
    });
    Object.keys(infAdd).forEach(function (X) { S.inf[+X] = Math.min(100, S.inf[+X] + 3); });
  }
  /* ---------- ships on the sea (own overlay canvas, cheap to redraw) ---------- */
  var shipC = null, sctx = null, TL = { on: false, last: 0 };
  function shipSprite(g, x, y, dx, col, k) {
    g.save(); g.translate(x, y); g.scale(dx < 0 ? -k : k, k); g.lineJoin = 'round';
    g.fillStyle = 'rgba(255,255,255,0.32)'; g.beginPath(); g.ellipse(0, 5.4, 8.5, 1.7, 0, 0, 6.2832); g.fill();
    g.fillStyle = rgb(col, 1); g.strokeStyle = 'rgba(6,12,20,0.9)'; g.lineWidth = 1.1;
    g.beginPath(); g.moveTo(-7, 1.5); g.lineTo(7, 1.5); g.lineTo(4.5, 5); g.lineTo(-4.5, 5); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = '#F6F1E3';
    g.beginPath(); g.moveTo(0.8, -9); g.lineTo(0.8, 0.8); g.lineTo(6.2, 0.8); g.closePath(); g.fill(); g.stroke();
    g.beginPath(); g.moveTo(-0.8, -6.5); g.lineTo(-0.8, 0.8); g.lineTo(-5.2, 0.8); g.closePath(); g.fill(); g.stroke();
    g.restore();
  }
  function drawShips(now) {
    if (!sctx) { shipC = $('ships'); sctx = shipC ? shipC.getContext('2d') : null; if (!sctx) return; }
    if (shipC.width !== canvas.width || shipC.height !== canvas.height) { shipC.width = canvas.width; shipC.height = canvas.height; }
    sctx.setTransform(1, 0, 0, 1, 0, 0); sctx.clearRect(0, 0, shipC.width, shipC.height);
    if (!S || !MAP || S.phase !== 'play' || ANIM || !shipsOn()) return;
    var rs = routes();
    if (!rs.length && !(S.pir && S.pir.length)) return;
    var t = ST.anim === 'off' ? 0 : (now || performance.now()) / 1000, k = 0.95 * CK / V.s;
    sctx.setTransform(DPR * V.s, 0, 0, DPR * V.s, DPR * V.tx, DPR * V.ty);
    (S.pir || []).forEach(function (q) { var z = S.provs[q.z]; pirSprite(sctx, z.lx, z.ly, t, k); });
    rs.forEach(function (r, ri) {
      if (r.kind !== 'sea' || !r.pp) return;
      if (fogOn() && !(friendlyTo(r.a, S.player) || friendlyTo(r.b, S.player))) return;
      var pp = r.pp, n = pp.len > 260 ? 3 : pp.len > 130 ? 2 : 1, sp = 22 / pp.len;
      for (var i = 0; i < n; i++) {
        var u = (t * sp + i / n + ri * 0.173) % 1, back = i % 2 === 1;
        if (back) u = 1 - u;
        var q = pointAt(pp, u);
        shipSprite(sctx, q[0], q[1], q[2], COL[back ? r.b : r.a], k);
      }
    });
  }
  function tradeLoop(ts) {
    if (!S || !MAP || S.phase !== 'play' || document.hidden || ST.anim === 'off' || ANIM || !shipsOn()) { TL.on = false; return; }
    if (ts - TL.last > 66) { TL.last = ts; drawShips(ts); }
    requestAnimationFrame(tradeLoop);
  }
  function tradeKick() {
    if (TL.on || typeof requestAnimationFrame !== 'function' || !S || S.phase !== 'play' || ST.anim === 'off' || ANIM || !shipsOn()) return;
    TL.on = true; requestAnimationFrame(tradeLoop);
  }
  function drawTrade(now) {
    if (S.phase !== 'play' || ANIM) return;
    var rs = routes(), s = V.s, ph = 0.5 + 0.5 * Math.sin((now || performance.now()) / 260), bz = blockZones();
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    rs.forEach(function (r) {
      if (!r.pp) return;
      if (fogOn() && !(friendlyTo(r.a, S.player) || friendlyTo(r.b, S.player))) return;
      var mine = r.a === S.player || r.b === S.player, cut = r.cutBy >= 0;
      if (r.kind !== 'sea' && !cut) return;
      ctx.beginPath();
      r.pp.pts.forEach(function (q, i) { if (i) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); });
      if (cut) { ctx.setLineDash([5 / s, 6 / s]); ctx.strokeStyle = 'rgba(255,84,64,' + (mine ? 0.9 : 0.55) + ')'; ctx.lineWidth = (mine ? 2.2 : 1.4) / s; }
      else { ctx.setLineDash([3 / s, 7 / s]); ctx.strokeStyle = mine ? 'rgba(255,224,140,0.8)' : 'rgba(255,238,200,0.3)'; ctx.lineWidth = (mine ? 1.8 : 1.2) / s; }
      ctx.stroke();
    });
    ctx.setLineDash([]);
    Object.keys(bz).forEach(function (z) {
      var p = S.provs[z];
      if (!p) return;
      ctx.strokeStyle = 'rgba(255,70,50,' + (0.55 + 0.35 * ph) + ')'; ctx.lineWidth = 2.4 / s; ctx.setLineDash([6 / s, 5 / s]);
      ctx.beginPath(); ctx.arc(p.lx, p.ly, (30 + 4 * ph) / s * CK, 0, 6.2832); ctx.stroke();
      ctx.setLineDash([]);
    });
  }
  function blkHtml(a) {
    var p = S.provs[a.prov];
    if (!p.sea || a.owner !== S.player) return '';
    var on = armyBlk(a), us = a.owner;
    var tg = routes().filter(function (r) { return r.pp && r.pp.zones.indexOf(a.prov) >= 0 && r.a !== us && r.b !== us && !isAlly(us, r.a) && !isAlly(us, r.b); });
    var h = '<div class="fld"><span class="lbl">Блокада</span>';
    if (tg.length) {
      var peace = {};
      tg.forEach(function (r) { [r.a, r.b].forEach(function (v) { if (v !== us && !isWar(v, us)) peace[v] = 1; }); });
      var pn = Object.keys(peace).map(function (v) { return CNAMES[v]; });
      h += '<small>Через эту зону идут торговые пути: ' + tg.map(function (r) { return CNAMES[r.a] + ' ↔ ' + CNAMES[r.b]; }).join(', ') + '.' + (pn.length ? ' Недовольны будут: ' + pn.join(', ') + '. Если не снять блокаду, придёт ультиматум, потом война.' : ' Все они с тобой в войне: блокада законна.') + '</small>';
    } else h += '<small>Через эту зону сейчас не идут чужие торговые пути: блокада ничего не режет.</small>';
    h += '<div class="row" style="margin-top:6px"><button class="btn sm' + (on ? ' danger' : '') + '" type="button" data-act="blk">' + ico('anchor') + (on ? 'Снять блокаду' : 'Блокада') + '</button></div></div>';
    return h;
  }
  function seaCard(p) {
    var h = seaCard0(p), ex = '';
    if (S.phase === 'play') {
      var rs = routes().filter(function (r) { return r.pp && r.pp.zones.indexOf(p.id) >= 0; }), bl = {};
      S.armies.forEach(function (a) { if (a.prov === p.id && armyBlk(a)) bl[a.owner] = 1; });
      if (rs.length) ex += '<p class="note"><b>Торговые пути через зону:</b> ' + rs.map(function (r) { return CNAMES[r.a] + ' ↔ ' + CNAMES[r.b]; }).join(', ') + '.</p>';
      if (Object.keys(bl).length) ex += '<p class="note"><span class="verdict bad">Блокада:</span> ' + Object.keys(bl).map(function (o) { return CNAMES[o]; }).join(', ') + '.</p>';
    }
    return h.replace(/<\/section>$/, ex + '</section>');
  }
  function genRel() {
    var r = [], op = [], tr = [], a, b;
    for (a = 0; a < NC; a++) {
      r.push([]); op.push([]); tr.push([]);
      for (b = 0; b < NC; b++) { r[a].push(a === b ? 'o' : 'w'); op[a].push(0); tr[a].push(0); }
    }
    S.rel = r; S.op = op; S.trade = tr;
    for (a = 0; a < NC; a++) {
      for (b = a + 1; b < NC; b++) {
        var t = Math.random(), v = ST.calm ? (t < 0.25 ? 'a' : 'p') : (t < 0.2 ? 'a' : t < 0.45 ? 'p' : 'w');
        r[a][b] = v; r[b][a] = v;
        var o = Math.round((v === 'a' ? 45 : v === 'p' ? 10 : -45) + (Math.random() - 0.5) * 30);
        op[a][b] = o; op[b][a] = o;
        if (v !== 'w' && Math.random() < 0.4) { tr[a][b] = 1; tr[b][a] = 1; }
      }
    }
    for (a = 0; a < NC; a++) {
      var nbs = neighborsC(a);
      if (!ST.calm && nbs.length && !nbs.some(function (x) { return S.rel[a][x] === 'w'; })) {
        var xx = nbs[(Math.random() * nbs.length) | 0];
        setRel(a, xx, 'w'); tr[a][xx] = 0; tr[xx][a] = 0; op[a][xx] = -40; op[xx][a] = -40;
      }
    }
    S.offers = [];
  }
  function expel(a, b) {
    S.armies.forEach(function (x) {
      var p = S.provs[x.prov];
      if (!((x.owner === a && p.owner === b) || (x.owner === b && p.owner === a))) return;
      var best = nearestFriendly(x);
      if (best >= 0) { x.prov = best; x.route = []; }
    });
    S.provs.forEach(function (q) { if ((q.owner === b && q.occBy === a) || (q.owner === a && q.occBy === b)) { q.occ = 0; q.occBy = -1; } });
  }
  function nearestFriendly(x) {
    var seen = {}, q = [x.prov]; seen[x.prov] = 1;
    while (q.length) {
      var id = q.shift(), p = S.provs[id];
      if (id !== x.prov && (p.owner === x.owner || isAlly(x.owner, p.owner))) return id;
      p.nb.forEach(function (n) { if (!seen[n]) { seen[n] = 1; q.push(n); } });
    }
    return -1;
  }
  function declareWar(a, b) {
    var prevRel = S.rel[a][b];
    if (S.calm === 999 && a === S.player) { S.calm = 0; toast('Мирный период окончен: ты начал войну.', 'warn'); }
    var cb = cbReason(a, b);
    if (S.inf) { if (prevRel === 'a') S.inf[a] += 10; else if (prevRel === 'p') S.inf[a] += cb ? 0 : 8; }
    if (!cb && prevRel === 'p') { for (var xx = 0; xx < NC; xx++) if (xx !== a && xx !== b && owned(xx).length) adjOp(xx, a, -4); }
    if (cb && S.just) delete S.just[a + '_' + b];
    if (S.bcb) delete S.bcb[a + '_' + b];
    if (a === S.player && prevRel !== 'w') toast(cb ? 'Повод для войны: ' + cbText(cb) + '.' : 'Война без повода: агрессия растёт, мир осуждает.', cb ? 'good' : 'warn');
    setRel(a, b, 'w'); (S.wsince || (S.wsince = {}))[Math.min(a, b) + '_' + Math.max(a, b)] = S.round; S.trade[a][b] = 0; S.trade[b][a] = 0; adjOp(a, b, -35);
    log(CNAMES[a] + ' объявил войну державе ' + CNAMES[b] + '.', a === S.player || b === S.player, -1, 'dipl');
    if (a === S.player || b === S.player) keyEv(CNAMES[a] + ' объявил войну державе ' + CNAMES[b]);
    if (b === S.player) news('war', 'Война!', 'Держава ' + CNAMES[a] + ' объявила тебе войну. ' + (cb ? 'Повод: ' + cbText(cb) + '.' : 'Без повода: мир осудит агрессора.'), 'dip');
  }
  function makePeace(a, b) {
    setRel(a, b, 'p'); expel(a, b); adjOp(a, b, 10);
    log('Мир между державами ' + CNAMES[a] + ' и ' + CNAMES[b] + '.', a === S.player || b === S.player, -1, 'dipl');
    if (a === S.player || b === S.player) keyEv('Мир между ' + CNAMES[a] + ' и ' + CNAMES[b]);
    S.armies.forEach(function (x) { if (x.eng && !hostileAt(x.eng.pid, x.owner)) { x.eng = null; if (x.route.length && !canEnter(x.owner, S.provs[x.route[0]])) x.route = []; } });
  }
  function offerText(o) {
    if (o.kind === 'help') return 'просит вступить в войну против державы ' + CNAMES[o.tgt];
    if (o.kind === 'tribute') return 'требует ' + o.amt + ' зол. за мир';
    if (o.kind === 'blockade') return 'ставит ультиматум: сними блокаду морских путей, иначе война';
    if (o.kind === 'ultimatum') return 'ставит ультиматум: ' + o.amt + ' зол. и конец агрессии, иначе война';
    return OFFN[o.kind];
  }
  function validOffer(o) {
    var r = S.rel[S.player][o.from];
    if (o.kind === 'help') return r === 'a' && owned(o.tgt).length > 0 && o.tgt !== S.player && S.rel[S.player][o.tgt] !== 'w';
    if (o.kind === 'tribute') return r === 'w';
    if (o.kind === 'ultimatum') return r === 'p';
    if (o.kind === 'blockade') return r === 'p' && hurtBy(S.player, o.from);
    return (o.kind === 'peace' && r === 'w') || (o.kind === 'ally' && r === 'p') || (o.kind === 'trade' && r !== 'w' && !S.trade[S.player][o.from]);
  }
  function ultimatumFail(c) {
    var us = S.player;
    adjOp(us, c, -10);
    if (!calmNow() && S.rel[us][c] === 'p' && Math.random() < 0.55) { declareWar(c, us); log('Держава ' + CNAMES[c] + ' начала войну после отвергнутого ультиматума.', true, -1, 'dipl'); }
  }
  function aiOffers() {
    var us = S.player, c;
    S.offers = S.offers.filter(function (o) {
      var keep = o.until >= S.round && owned(o.from).length > 0 && validOffer(o);
      if (!keep && o.kind === 'ultimatum' && o.until < S.round && owned(o.from).length && S.rel[us][o.from] === 'p') ultimatumFail(o.from);
      if (!keep && o.kind === 'blockade' && o.until < S.round && owned(o.from).length) blockadeFail(o.from);
      return keep;
    });
    for (c = 0; c < NC; c++) {
      if (c === us || !owned(c).length || S.offers.length >= 4 || S.offers.some(function (o) { return o.from === c; })) continue;
      var r = S.rel[us][c], kind = null, ex = {};
      if (S.inf[us] >= 25 && r === 'p' && !calmNow() && strength(c) > strength(us) * 0.8 && Math.random() < 0.15) { kind = 'ultimatum'; ex.amt = clamp(Math.round(S.gold[us] * 0.35), 10, 60); }
      else {
        if (Math.random() > 0.12) continue;
        if (r === 'w' && S.round > 6 && strength(c) > strength(us) * 1.4 && Math.random() < 0.5) { kind = 'tribute'; ex.amt = clamp(Math.round(S.gold[us] * 0.3), 8, 50); }
        else if (r === 'w' && S.round > 4 && (strength(c) < strength(us) * 1.1 || (RL('rWar') && S.weary && S.weary[c] > 60)) && (!RL('rDip') || warAge(c, us) >= 3)) kind = 'peace';
        else if (r === 'p') {
          var cw = 0; for (var q = 0; q < NC; q++) if (q !== us && q !== c && owned(q).length && isWar(us, q) && isWar(c, q)) cw++;
          if ((S.op[us][c] > 35 || cw) && S.round >= (S.allyCd || 0) && Math.random() < 0.25) { kind = 'ally'; S.allyCd = S.round + 10; }
          else if (S.op[us][c] > 10 && Math.random() < 0.5) kind = 'trade';
        }
        else if (r === 'a') {
          var foes = warEnemies(c).filter(function (x) { return x !== us && S.rel[us][x] !== 'w' && S.rel[us][x] !== 'a'; });
          if (foes.length && Math.random() < 0.5) { kind = 'help'; ex.tgt = foes[(Math.random() * foes.length) | 0]; } else kind = 'trade';
        }
        if (kind === 'trade' && S.trade[us][c]) kind = null;
      }
      if (kind) { var o = { from: c, kind: kind, until: S.round + 2 }; for (var kk in ex) o[kk] = ex[kk]; S.offers.push(o); if (kind === 'ultimatum') news('ult', 'Ультиматум!', 'Держава ' + CNAMES[c] + ' ' + offerText(o) + '. Срок — 2 хода.', 'dip'); else if (kind === 'tribute') news('dem', 'Требование!', 'Держава ' + CNAMES[c] + ' ' + offerText(o) + '. Срок — 2 хода.', 'dip'); else toast('Держава ' + CNAMES[c] + ' ' + offerText(o) + '.', 'good'); }
    }
  }
  // living world: reputation, embargoes, coalitions, allies joining wars
  function aiReact() {
    var c, x, z, us = S.player;
    for (c = 0; c < NC; c++) if (owned(c).length) S.inf[c] = Math.max(0, S.inf[c] - 1.2 * (1 + tk(c, 'dip')));
    for (c = 0; c < NC; c++) {
      var inf = S.inf[c];
      if (inf < 10 || !owned(c).length) continue;
      if (c === us) {
        var lvl = inf >= 50 ? 3 : inf >= 25 ? 2 : 1;
        if (lvl > S.infLvl) toast(lvl === 3 ? 'Тебя считают угрозой миру: готовится коалиция.' : lvl === 2 ? 'Тебя считают агрессором: торговые партнёры отворачиваются.' : 'Твоя агрессия замечена: отношения портятся.', 'warn');
        S.infLvl = lvl;
      }
      for (x = 0; x < NC; x++) {
        if (x === c || !owned(x).length || isWar(x, c)) continue;
        adjOp(c, x, -1);
        if (S.trade[c][x] && Math.random() < 0.15 + inf / 120) {
          S.trade[c][x] = 0; S.trade[x][c] = 0; adjOp(c, x, -4);
          if (c === us || x === us) { var who = c === us ? x : c; log('Держава ' + CNAMES[who] + ' разорвала торговые пути из-за агрессии' + (c === us ? ' твоей державы.' : ' державы ' + CNAMES[c] + '.'), true, -1, 'dipl'); toast('Держава ' + CNAMES[who] + ' рвёт торговые пути: агрессия.', 'bad'); }
        }
        if (inf >= 35 && x !== us && !isAlly(x, c) && !calmNow() && Math.random() < 0.04 + inf / 1500 && strength(x) > 20) {
          declareWar(x, c);
          log('Коалиция: державa ' + CNAMES[x] + ' выступает против агрессора ' + CNAMES[c] + '.', c === us, -1, 'dipl');
          if (c === us) keyEv('Против тебя выступила держава ' + CNAMES[x]);
          for (z = 0; z < NC; z++) if (z !== us && z !== c && z !== x && owned(z).length && isAlly(x, z) && !isWar(z, c) && !isAlly(z, c) && Math.random() < 0.5) declareWar(z, c);
        }
      }
    }
    if (!calmNow()) {
      for (var a = 0; a < NC; a++) {
        if (a === us || !owned(a).length) continue;
        for (var d = 0; d < NC; d++) {
          if (d === a || !isAlly(a, d) || !owned(d).length) continue;
          for (var f = 0; f < NC; f++) {
            if (f === a || f === d || !owned(f).length || !isWar(d, f) || isWar(a, f) || isAlly(a, f) || Math.random() > 0.05) continue;
            declareWar(a, f);
            log('Союзник ' + CNAMES[a] + ' вступает в войну против державы ' + CNAMES[f] + '.', d === us || f === us || a === us, -1, 'dipl');
          }
        }
      }
    }
  }
  var EVN = ['Богатый урожай', 'Неурожай', 'Эпидемия', 'Торговый караван', 'Мятеж гарнизона', 'Талантливый офицер', 'Пожар на заводе', 'Технический прорыв'];
  function rollEvents() {
    if (Math.random() > 0.25) return;
    var alive = [], c;
    for (c = 0; c < NC; c++) if (owned(c).length) alive.push(c);
    c = alive[(Math.random() * alive.length) | 0];
    var ps = owned(c), p = ps[(Math.random() * ps.length) | 0], ev = (Math.random() * 8) | 0, msg = '', tone = 'good';
    if (ev === 0) { S.gold[c] += 8; p.pop = Math.min(popCap(p), p.pop + 2); msg = 'Богатый урожай в ' + p.name + ': +8 зол.'; }
    else if (ev === 1) { S.gold[c] = Math.max(0, S.gold[c] - 5); popLose(p, 2, 'hun'); msg = 'Неурожай в ' + p.name + ': −5 зол., жители уходят.'; tone = 'bad'; }
    else if (ev === 2) { popLose(p, p.pop - Math.round(p.pop * 0.75), 'epi'); msg = 'Эпидемия в ' + p.name + ': население сократилось.'; tone = 'bad'; }
    else if (ev === 3) { S.gold[c] += 10; msg = 'Торговый караван принёс державе 10 зол.'; }
    else if (ev === 4) { p.garrison = Math.max(0, Math.round(p.garrison * 0.5)); msg = 'Мятеж гарнизона в ' + p.name + ': половина разбежалась.'; tone = 'bad'; }
    else if (ev === 5) { var g = mkGen(c, 2); msg = 'Талантливый офицер ' + g.name + ' пришёл в армию.'; }
    else if (ev === 6) { var fp = ps.filter(function (q) { return q.fac + q.civ > 0; }); if (!fp.length) return; p = fp[(Math.random() * fp.length) | 0]; p.fd = Math.min(0.8, p.fd + 0.25); msg = 'Пожар на заводе в ' + p.name + '.'; tone = 'bad'; }
    else { S.eq[c] = Math.min(eqCap(c), S.eq[c] + 15); msg = 'Технический прорыв: +15 техники.'; }
    if (c === S.player) { toast(msg, tone); log(msg, true, p.id, 'sys'); }
  }
  function dipBtns(c, full) {
    var r = S.rel[S.player][c], cool = S.dipCool[c] === S.round, h = '';
    function B(k, t, dis, cls) { return '<button class="btn sm' + (cls ? ' ' + cls : '') + '" type="button" data-act="dip" data-k="' + k + '" data-c="' + c + '"' + (dis ? ' disabled' : '') + '>' + t + '</button>'; }
    if (r === 'w') h += B('peace', 'Предложить мир', cool) + B('peacet', 'Мир с контрибуцией', cool);
    if (r === 'p') h += B('ally', 'Предложить союз', cool) + B('just', fabbing(S.player, c) ? 'Повод готовится…' : 'Найти повод · 20', fabbing(S.player, c) || !!cbReason(S.player, c) || S.gold[S.player] < 20) + B('war', 'Объявить войну', false, 'danger');
    if (r === 'p' && hurtBy(c, S.player)) h += B('blku', 'Ультиматум: снять блокаду', cool, 'danger');
    if (r === 'a') h += B('break', 'Разорвать союз', false, 'danger');
    if (full) h += B('spy', 'Разведка', false);
    if (full && r !== 'w') {
      h += B('trade', S.trade[S.player][c] ? 'Разорвать торговлю' : 'Торговый договор', !S.trade[S.player][c] && cool);
      h += B('gift', 'Подарок 10 зол.', S.gold[S.player] < 10);
    }
    return h;
  }
  function dipAct(kind, c) {
    var us = S.player;
    if (S.phase !== 'play' || S.busy || c === us || !owned(c).length) return;
    var r = S.rel[us][c], cool = S.dipCool[c] === S.round, op = S.op[us][c], msg = '', i;
    if (kind === 'spy') { S.ui.spy = c; S.ui.spyMsg = ''; S.ui.view = 'spy'; renderOverlay(); return; }
    if (kind === 'acc' || kind === 'dec') {
      var o = null;
      for (i = 0; i < S.offers.length; i++) if (S.offers[i].from === c) o = S.offers[i];
      if (!o) return;
      S.offers = S.offers.filter(function (x) { return x !== o; });
      if (kind === 'dec') { adjOp(us, c, -3); msg = 'Предложение отклонено.'; if (o.kind === 'ultimatum') { ultimatumFail(c); msg = 'Ультиматум отвергнут.'; } else if (o.kind === 'blockade') { blockadeFail(c); msg = 'Ультиматум отвергнут.'; } else if (o.kind === 'help') adjOp(us, c, -8); }
      else if (!validOffer(o)) msg = 'Предложение уже не действует.';
      else if (o.kind === 'peace') { makePeace(us, c); msg = 'Мир с державой ' + CNAMES[c] + ' заключён.'; }
      else if (o.kind === 'ally') { setRel(us, c, 'a'); adjOp(us, c, 20); log('Союз с державой ' + CNAMES[c] + ' заключён.', true, -1, 'dipl'); msg = 'Союз заключён.'; }
      else if (o.kind === 'help') { if (calmNow()) msg = 'Мирный период: война невозможна.'; else { S.just[us + '_' + o.tgt] = S.round + 1; declareWar(us, o.tgt); adjOp(us, c, 15); msg = 'Ты вступил в войну против державы ' + CNAMES[o.tgt] + '.'; } }
      else if (o.kind === 'blockade') { var nl = liftFor(us, c); adjOp(us, c, 12); S.inf[us] = Math.max(0, S.inf[us] - 5); msg = 'Блокада снята: держава ' + CNAMES[c] + ' довольна.'; }
      else if (o.kind === 'tribute' || o.kind === 'ultimatum') {
        if (S.gold[us] < o.amt) msg = 'Не хватает золота.';
        else { S.gold[us] -= o.amt; S.gold[c] += o.amt; if (o.kind === 'tribute') { makePeace(us, c); msg = 'Заплатил ' + o.amt + ' зол.: мир заключён.'; } else { S.inf[us] = Math.max(0, S.inf[us] - 10); adjOp(us, c, 10); msg = 'Заплатил ' + o.amt + ' зол.: напряжение спало.'; } }
      }
      else { S.trade[us][c] = 1; S.trade[c][us] = 1; adjOp(us, c, 8); msg = 'Торговый договор заключён: корабли пойдут по морю, доход зависит от пути.'; }
    } else if (kind === 'peacet' && r === 'w') {
      if (RL('rDip') && warAge(us, c) < 3) { toast('Война идёт слишком недолго: мир можно просить не раньше 3-го хода войны.', 'warn'); return; }
      if (cool) { toast('Они уже отвечали в этом ходу.'); return; }
      S.dipCool[c] = S.round;
      var tt = strength(c), mm = strength(us), pp = (tt < mm * 0.7 ? 0.5 : tt < mm * 0.95 ? 0.2 : 0.04) + op / 400, tr = Math.min(S.gold[c], 20);
      if (Math.random() < clamp(pp, 0.02, 0.8)) { S.gold[c] -= tr; S.gold[us] += tr; makePeace(us, c); msg = 'Мир заключён, контрибуция ' + tr + ' зол.'; }
      else { adjOp(us, c, -4); msg = 'Держава ' + CNAMES[c] + ' отвергла мир с контрибуцией.'; }
    } else if (kind === 'just' && r === 'p') {
      if (cbReason(us, c)) msg = 'Повод уже есть: ' + cbText(cbReason(us, c)) + '.';
      else if (startFab(us, c)) msg = 'Подготовка повода начата: 20 зол., готов через 3 хода и действует 12 ходов.';
      else msg = 'Не хватает золота.';
    } else if (kind === 'war' && r === 'p') {
      declareWar(us, c); msg = 'Ты объявил войну державе ' + CNAMES[c] + '.';
    } else if (kind === 'break' && r === 'a') {
      setRel(us, c, 'p'); expel(us, c); adjOp(us, c, -25); log('Ты разорвал союз с державой ' + CNAMES[c] + '.', true, -1, 'dipl'); msg = 'Союз разорван.';
    } else if (kind === 'peace' && r === 'w') {
      if (RL('rDip') && warAge(us, c) < 3) { toast('Война идёт слишком недолго: мир можно просить не раньше 3-го хода войны.', 'warn'); return; }
      if (cool) { toast('Они уже отвечали в этом ходу.'); return; }
      S.dipCool[c] = S.round;
      var ts = strength(c), ms = strength(us), p1 = (ts < ms * 0.85 ? 0.55 : ts < ms * 1.15 ? 0.3 : 0.12) + op / 300 + (RL('rWar') && S.weary ? S.weary[c] / 250 : 0);
      if (Math.random() < clamp(p1, 0.05, 0.9)) { makePeace(us, c); msg = 'Мир с державой ' + CNAMES[c] + ' заключён.'; }
      else { adjOp(us, c, -2); msg = 'Держава ' + CNAMES[c] + ' отвергла мир.'; }
    } else if (kind === 'ally' && r === 'p') {
      if (cool) { toast('Они уже отвечали в этом ходу.'); return; }
      S.dipCool[c] = S.round;
      var common = 0;
      for (i = 0; i < NC; i++) if (i !== us && i !== c && owned(i).length && isWar(us, i) && isWar(c, i)) common++;
      if (Math.random() < clamp((common ? 0.55 : 0.15) + op / 200, 0.05, 0.9)) { setRel(us, c, 'a'); adjOp(us, c, 20); log('Союз с державой ' + CNAMES[c] + ' заключён.', true, -1, 'dipl'); msg = 'Союз заключён.'; }
      else { adjOp(us, c, -2); msg = 'Держава ' + CNAMES[c] + ' отвергла союз.'; }
    } else if (kind === 'trade' && r !== 'w') {
      if (S.trade[us][c]) { S.trade[us][c] = 0; S.trade[c][us] = 0; adjOp(us, c, -8); msg = 'Торговый договор расторгнут.'; }
      else {
        if (cool) { toast('Они уже отвечали в этом ходу.'); return; }
        S.dipCool[c] = S.round;
        if (Math.random() < clamp(0.5 + op / 150 + (r === 'a' ? 0.2 : 0), 0.1, 0.95)) { S.trade[us][c] = 1; S.trade[c][us] = 1; adjOp(us, c, 8); msg = 'Торговый договор заключён: корабли пойдут по морю, доход зависит от пути.'; }
        else msg = 'Держава ' + CNAMES[c] + ' отказалась от торговли.';
      }
    } else if (kind === 'blku' && r === 'p') {
      if (!hurtBy(c, us)) msg = 'Сейчас они не блокируют твои пути.';
      else if (cool) { toast('Они уже отвечали в этом ходу.'); return; }
      else {
        S.dipCool[c] = S.round;
        var pw = clamp(0.3 + (strength(us) - strength(c)) / (strength(us) + strength(c) + 20) * 0.6 + op / 250, 0.08, 0.85);
        if (Math.random() < pw) { liftFor(c, us); adjOp(us, c, -2); msg = 'Ультиматум принят: держава ' + CNAMES[c] + ' снимает блокаду.'; }
        else { adjOp(us, c, -10); S.bcb[us + '_' + c] = S.round + 10; msg = 'Держава ' + CNAMES[c] + ' отвергла ультиматум. Теперь у тебя есть повод для войны.'; }
      }
    } else if (kind === 'gift' && r !== 'w') {
      if (S.gold[us] < 10) { toast('Не хватает золота.'); return; }
      S.gold[us] -= 10; S.gold[c] += 10; adjOp(us, c, 15); msg = 'Подарок вручён. Отношение к тебе улучшилось.';
    }
    if (msg) { S.msg = msg; toast(msg); }
    SFX.click();
    checkEnd(); if (S.phase === 'over') S.ui.view = 'end';
    saveGame(); render();
  }
  function aiDiplomacy() {
    var c, d;
    for (c = 0; c < NC; c++) {
      if (c === S.player || !owned(c).length) continue;
      var nbs = neighborsC(c);
      if (S.round >= 3 && !calmNow() && !nbs.some(function (x) { return isWar(c, x); }) && Math.random() < 0.3) {
        var cand = nbs.filter(function (x) { return S.rel[c][x] === 'p'; });
        if (cand.length) {
          cand.sort(function (x, y) { return (S.op[c][x] - S.op[c][y]) || (strength(x) - strength(y)); });
          var tg0 = cand[0];
          if (cbReason(c, tg0) || Math.random() < 0.08) declareWar(c, tg0);
          else if (Math.random() < 0.35) startFab(c, tg0);
        }
      }
    }
    for (c = 0; c < NC; c++) {
      for (d = c + 1; d < NC; d++) {
        if (c === S.player || d === S.player || !owned(c).length || !owned(d).length) continue;
        if (S.rel[c][d] === 'w' && Math.random() < 0.03) makePeace(c, d);
        else if (S.rel[c][d] === 'p' && S.op[c][d] > 10 && Math.random() < 0.04) { setRel(c, d, 'a'); log('Державы ' + CNAMES[c] + ' и ' + CNAMES[d] + ' заключили союз.', false, -1, 'dipl'); }
        else if (S.rel[c][d] !== 'w' && !S.trade[c][d] && Math.random() < 0.03) { S.trade[c][d] = 1; S.trade[d][c] = 1; }
      }
    }
  }
  function driftOp() {
    for (var a = 0; a < NC; a++) for (var b = a + 1; b < NC; b++) {
      var r = S.rel[a][b], d = r === 'a' ? 1 : r === 'w' ? -1 : (S.trade[a][b] ? 1 : 0);
      if (d) adjOp(a, b, d);
    }
  }
