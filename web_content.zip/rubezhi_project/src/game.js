  /* ---------- game flow ---------- */
  function newMap(seedStr) {
    gen++;
    NP = ST.np; NC = ST.nc;
    var seed = seedStr || Math.random().toString(36).slice(2, 8), pm1 = PRE_RX.exec(seed);
    if (!pm1 && mkUi() !== 'seed') { seed = ST.mapKind + ':' + seed; pm1 = PRE_RX.exec(seed); }
    setWorld(NP, pm1 ? PR[pm1[1]].wide : wantWide());
    var provs = buildWorld(seed); initEth(provs);
    S = { phase: 'pick', round: 1, player: -1, gold: [], provs: provs, armies: [], aid: 0, selP: -1, selA: -1, pickC: -1, busy: false, chron: [], msg: '', seed: seed, alive: [], ui: { view: null }, rel: null, op: null, trade: null, offers: [], dipCool: {}, won: false, gens: [], gid: 0, reports: [], rid: 0, multi: [], groups: {}, layer: 'pol', selF: '', multiMode: false };
    ANIM = null; initExtra();
    for (var c = 0; c < NC; c++) {
      S.gold.push(10); S.alive.push(true);
      var cp = provs.filter(function (p) { return p.owner === c && p.capital; })[0];
      newArmy(c, cp.id, 100, 80);
      var other = provs.filter(function (p) { return p.owner === c && !p.capital; });
      other.sort(function (a, b) { return b.set - a.set; });
      newArmy(c, other.length ? other[0].id : cp.id, 60, 80);
      mkGen(c, 2); mkGen(c, 1); mkGen(c, 1);
      assignGenerals(c);
    }
    genRel();
    computeSupply();
    mergeArmies();
  }

  /* start scenarios rewrite the initial diplomatic map */
  function applyScenario() {
    var sc = ST.scen || 'classic', alive = [], a, b, i;
    if (sc === 'classic') return;
    for (a = 0; a < NC; a++) if (owned(a).length) alive.push(a);
    function pair(x, y, rel, op, tr) { setRel(x, y, rel); S.op[x][y] = op; S.op[y][x] = op; S.trade[x][y] = tr ? 1 : 0; S.trade[y][x] = tr ? 1 : 0; }
    if (sc === 'peace') {
      for (i = 0; i < alive.length; i++) for (b = i + 1; b < alive.length; b++) pair(alive[i], alive[b], Math.random() < 0.15 ? 'a' : 'p', 20 + ((Math.random() * 30) | 0), Math.random() < 0.55);
      if (S.calm !== 999) S.calm = Math.max(S.calm || 0, 20);
    } else if (sc === 'chaos') {
      S.calm = 0;
      for (i = 0; i < alive.length; i++) for (b = i + 1; b < alive.length; b++) pair(alive[i], alive[b], 'p', -25, false);
      alive.forEach(function (c) { neighborsC(c).forEach(function (x) { if (x !== c && owned(x).length) pair(c, x, 'w', -50, false); }); });
    } else if (sc === 'blocs') {
      var key = WIDE ? 'lx' : 'ly', cap = alive.map(function (c) { var q = S.provs[capitalOf(c)]; return { c: c, v: q ? q[key] : 0 }; }).sort(function (x, y) { return x.v - y.v; }), half = Math.ceil(cap.length / 2), bl = {};
      cap.forEach(function (o, k) { bl[o.c] = k < half ? 0 : 1; });
      for (i = 0; i < alive.length; i++) for (b = i + 1; b < alive.length; b++) {
        var x = alive[i], y = alive[b];
        if (bl[x] === bl[y]) pair(x, y, 'a', 50, Math.random() < 0.6); else pair(x, y, 'p', -35, false);
      }
      var cross = [];
      alive.forEach(function (c) { neighborsC(c).forEach(function (x) { if (c < x && owned(x).length && bl[c] !== bl[x]) cross.push([c, x]); }); });
      if (!S.calm) cross.forEach(function (pr, k) { if (k === 0 || Math.random() < 0.5) pair(pr[0], pr[1], 'w', -55, false); });
    }
    S.offers = [];
  }
  function startGame() {
    S.player = S.pickC;
    S.phase = 'play';
    S.vic = ST.vic || 'std'; S.law[S.player] = [0, 0, 0]; if (S.tech[S.player]) S.tech[S.player].fx = null;
    var b = ST.boost, c;
    for (c = 0; c < NC; c++) {
      S.gold[c] = [10, 25, 40][b]; S.eq[c] = [30, 50, 80][b];
      S.armies.forEach(function (a) { if (a.owner === c) a.troops = Math.round(a.troops * [1, 1.3, 1.6][b]); });
      if (b === 2) {
        var cp = capitalOf(c);
        newArmy(c, cp, 60, 80); mkGen(c, 1); assignGenerals(c);
        owned(c).forEach(function (p) { p.pop = Math.min(popCap(p), Math.round(p.pop * 1.15)); });
      }
    }
    applyScenario();
    for (c = 0; c < NC; c++) genFill(c);
    S.chron = [];
    log('Ты правишь державой ' + CNAMES[S.player] + '. ' + (ST.seasons ? 'Весна, ход 1.' : 'Ход 1.'), true, -1, 'sys');
    computeSupply();
    var wars = [], allies = [];
    for (c = 0; c < NC; c++) { if (c === S.player) continue; if (S.rel[S.player][c] === 'w') wars.push(CNAMES[c]); else if (S.rel[S.player][c] === 'a') allies.push(CNAMES[c]); }
    log('Ты воюешь с: ' + (wars.join(', ') || 'никем') + '.' + (allies.length ? ' Союзники: ' + allies.join(', ') + '.' : ''), true, -1, 'sys');
    recHist();
    S.selA = -1; S.selP = capitalOf(S.player);
    centerOn(S.selP, 1.5);
    saveGame();
    render();
    toast('Стартовый бонус получили все державы.', 'good');
  }

  function hofLoad() { try { var l = JSON.parse(localStorage.getItem('rubezhi3.hof') || '[]'); return Array.isArray(l) ? l : []; } catch (e) { return []; } }
  function hofSave() {
    try {
      var l = hofLoad();
      l.unshift({ d: Date.now(), c: CNAMES[S.player], won: !!S.won, why: S.why, r: S.round, pts: scoreOf(S.player), vic: S.vic, real: !!ST.real, np: NP, nc: NC, sc: ST.scen || 'classic' });
      localStorage.setItem('rubezhi3.hof', JSON.stringify(l.slice(0, 30)));
    } catch (e) { /* ignore */ }
  }
  function hofHtml() {
    var l = hofLoad(), w = l.filter(function (x) { return x.won; }), best = l.reduce(function (m, x) { return Math.max(m, x.pts || 0); }, 0), fast = w.reduce(function (m, x) { return Math.min(m, x.r); }, 9999);
    var VN = { std: 'обычная', dom: 'господство', pts: 'по очкам' }, SN = { classic: 'классика', blocs: 'два блока', chaos: 'все против всех', peace: 'золотой век' };
    var h = head('Зал славы', true) + '<div class="sh-body">';
    if (!l.length) return h + '<p class="note">Пока нет законченных партий. Сыграй до победы или поражения, и результат появится здесь.</p></div>';
    h += '<div class="stat-grid">' + [['Партий', l.length], ['Побед', w.length], ['Лучший счёт', best], ['Быстрая победа', w.length ? fast + ' ход.' : '—']].map(function (x) { return '<div><b>' + x[1] + '</b><span>' + x[0] + '</span></div>'; }).join('') + '</div><div class="dips">';
    h += l.map(function (x) {
      var dt = new Date(x.d), ds = ('0' + dt.getDate()).slice(-2) + '.' + ('0' + (dt.getMonth() + 1)).slice(-2) + '.' + dt.getFullYear();
      return '<div class="dip"><div class="hd"><span class="nm">' + esc(x.c) + '</span><span class="chip ' + (x.won ? 'good' : 'bad') + '">' + (x.won ? 'Победа' : 'Поражение') + '</span></div><div class="sub">' + ds + ' · ходов ' + x.r + ' · очков ' + (x.pts || 0) + '</div><p>' + esc(x.why || '') + '.</p><div class="row"><span class="chip">' + (x.np || '?') + ' пров. / ' + (x.nc || '?') + ' держ.</span><span class="chip">' + (VN[x.vic] || 'обычная') + '</span><span class="chip">' + (SN[x.sc] || 'классика') + '</span>' + (x.real ? '<span class="chip warn">реализм</span>' : '') + '</div></div>';
    }).join('') + '</div></div>';
    return h;
  }
  function endGame(won, why, allied) {
    S.phase = 'over'; S.won = won; S.why = why; S.allied = !!allied;
    hofSave();
    recHist(); keyEv(won ? 'Победа: ' + why : 'Поражение: ' + why);
    achCheck();
  }
  function checkEnd() {
    if (S.phase !== 'play') return;
    var mineN = owned(S.player).length;
    if (mineN === 0) { endGame(false, 'держава ' + CNAMES[S.player] + ' потеряла все провинции'); return; }
    if (S.cont) return;
    if (S.vic === 'dom') {
      for (var dc = 0; dc < NC; dc++) if (owned(dc).length >= NP * 0.55) { endGame(dc === S.player, dc === S.player ? 'под твоей властью больше половины карты' : 'держава ' + CNAMES[dc] + ' захватила больше половины карты'); return; }
    }
    if (S.vic === 'pts' && S.round >= S.limit) {
      var best = -1, bs = -1, rk = 1, mine0 = scoreOf(S.player);
      for (var pc = 0; pc < NC; pc++) if (owned(pc).length) { var sc0 = scoreOf(pc); if (sc0 > bs) { bs = sc0; best = pc; } if (pc !== S.player && sc0 > mine0) rk++; }
      endGame(best === S.player, best === S.player ? 'по очкам ты первый за ' + S.limit + ' ходов' : 'по очкам победила держава ' + CNAMES[best] + ' (ты на ' + rk + ' месте)'); return;
    }
    var others = 0, foes = 0;
    for (var c = 0; c < NC; c++) if (c !== S.player && owned(c).length > 0) { others++; if (!isAlly(S.player, c)) foes++; }
    if (!others) endGame(true, 'все соперники повержены');
    else if (mineN >= NP * 0.75) endGame(true, 'под твоей властью три четверти карты');
    else if (!foes && S.round >= 10) endGame(true, 'все оставшиеся державы — твои союзники', true);
  }

  function nextRound() {
    S.round++;
    computeSupply();
    var c, aut = sIdx() === 2 ? 1.5 : 1;
    warWeary();
    taxTurn();
    for (c = 0; c < NC; c++) {
      if (!owned(c).length) continue;
      var raw = S.gold[c] + Math.floor(income(c) * aut * aiIncMult(c) * sanc(c)) - upkeep(c);
      if (raw < 0 && RL('rUp')) payTroops(c);
      S.gold[c] = Math.max(0, raw);
    }
    for (c = 0; c < NC; c++) {
      if (!owned(c).length) { S.eqD[c] = 0; continue; }
      var pr = eqProd(c), us2 = eqUse(c);
      S.eq[c] = clamp(S.eq[c] + pr - us2, 0, eqCap(c)); S.eqD[c] = pr - us2;
      if (c === S.player && S.eq[c] <= 0 && S.eqD[c] <= 0) toast('Техника на нуле: армии слабее, найм закрыт. Защити и почини заводы.', 'warn');
    }
    var sm = sIdx(), grow = sm === 3 ? 0.5 : sm === 0 ? 1.3 : sm === 2 ? 1.2 : 1;
    S.provs.forEach(function (p) {
      if (p.sea) return;
      if (p.sup) {
        p.pop = Math.min(popCap(p), p.pop + (emAny(p.owner) ? 0 : 1) * Math.max(1, Math.round(p.pop * TER[p.terrain].gr * grow * growMul(p) * (1 + tk(p.owner, 'gro')) * growK(p) * 0.04 * (1 + 0.2 * p.civ + 0.12 * p.dev))));
        if (p.garrison < gcap(p) && !p.besieged && !(p.occ > 0)) p.garrison = Math.min(gcap(p), p.garrison + Math.max(2, Math.round(gcap(p) * 0.12)));
      } else {
        popLose(p, Math.ceil(p.pop * 0.02), 'hun');
      }
      if (!p.besieged && p.occ > 0) { p.occ = Math.max(0, p.occ - 25); if (p.occ <= 0) p.occBy = -1; }
      if (p.fd > 0 && !p.hot && !p.besieged && !(p.occ > 0) && p.sup) p.fd = Math.max(0, p.fd - 0.07);
      p.hot = false;
      p.besieged = false;
      p.recruited = false;
    });
    ethTurn();
    emTurn();
    techTurn();
    lawAI();
    S.armies.forEach(function (a) {
      if (a.blk && (!S.provs[a.prov].sea || a.route.length)) a.blk = false;
      var lg = gsk(a, 'log');
      if (S.provs[a.prov].sea) { a.troops = Math.max(5, a.troops - Math.ceil(a.troops * (RL('rAtt') ? 0.045 : 0.03))); a.org = Math.min(100, a.org + 2); }
      else if (!armySup(a)) { a.troops = Math.max(5, a.troops - Math.ceil(a.troops * 0.06 * (RL('rAtt') ? 1.5 : 1) * (1 - 0.1 * lg) * (1 - tk(a.owner, 'att')))); a.org = Math.min(100, a.org + 3 + lg * 0.5); }
      else a.org = Math.min(100, a.org + (a.fought ? 0 : (RL('rAtt') ? 7 : 10) + lg));
      if (RL('rAtt') && !S.provs[a.prov].sea) {
        var fp = S.provs[a.prov], fl = (fp.owner !== a.owner && !isAlly(a.owner, fp.owner)) ? (sIdx() === 3 ? 0.02 : 0) + (fp.terrain === 3 ? 0.015 : 0) : 0;
        if (fl) a.troops = Math.max(5, a.troops - Math.ceil(a.troops * fl * (1 - tk(a.owner, 'att'))));
      }
      if (a.stance === 'hold' && !a.moved && !a.fought && !a.route.length) a.dug = Math.min(3, a.dug + 1);
      a.fought = false; a.moved = 0;
    });
    computeSupply();
    driftOp();
    genTurn();
    netTurn();
    aiReact();
    aiEm();
    blockadeTurn();
    pirTurn();
    aiSpy();
    rollEvents();
    aiOffers();
    for (c = 0; c < NC; c++) if (owned(c).length && S.round % 12 === 0 && S.gens.filter(function (g) { return g.owner === c; }).length < 6) { var ng = mkGen(c, 1); if (c === S.player) toast('В армию прибыл новый генерал: ' + ng.name + '.', 'good'); }
    turnAlerts();
    achCheck();
    misCheck();
    maybeEvent();
    S.busy = false; S.msg = '';
    log((ST.seasons ? SEASONS[sIdx()].n + ', ' : '') + 'ход ' + S.round + '.', false, -1, 'sys');
    recHist();
    saveGame();
    SFX.turn();
    render();
  }

  function turnAlerts() {
    var n = 0;
    S.armies.forEach(function (a) {
      if (a.owner !== S.player || n >= 2) return;
      if (encircled(a)) { n++; toast('Армия №' + a.id + ' окружена в ' + S.provs[a.prov].name + '!', 'bad'); }
      else if (!S.provs[a.prov].sea && !armySup(a) && a.troops > 20) { n++; toast('Армия №' + a.id + ' без снабжения (' + S.provs[a.prov].name + ').', 'warn'); }
    });
    var us = S.player;
    if (ST.tips && n < 1 && S.round % 4 === 2 && S.tech[us] && !S.tech[us].cur && techAvail(us).length) { n++; toast('Совет: выбери исследование (кнопка колбы или R).', 'warn'); }
    if (ST.tips && n < 1 && S.round % 3 === 0 && S.gold[us] >= 70) { n++; toast('Совет: в казне ' + S.gold[us] + ' зол. Построй завод, развей население или набери армию.', 'warn'); }
    var rb = owned(us).filter(function (q) { return (q.unr || 0) >= 50; })[0];
    if (ST.tips && n < 1 && S.round % 3 === 1 && rb) { n++; toast('Совет: растёт недовольство в ' + rb.name + '. Введи политику к меньшинствам.', 'warn'); }
  }
  /* timeline recorder: the whole turn is resolved at once, then replayed step by step */
  function newRec() {
    var r = { beats: [], cur: null };
    r.beat = function () { if (!r.cur || r.cur.mv.length || r.cur.bt.length || r.cur.rt.length || r.cur.cap.length) { r.cur = { mv: [], bt: [], rt: [], rm: [], cap: [], sg: [] }; r.beats.push(r.cur); } };
    r.mv = function (a, to) { if (!r.cur) r.beat(); r.cur.mv.push({ id: a.id, to: to }); };
    r.bt = function (info, ta, td, oa, od) {
      if (!r.cur) r.beat();
      var ids = [info.att, info.def].map(function (a) { return { id: a.id, troops: a.troops, org: Math.round(a.org) }; });
      r.cur.bt.push({ pid: info.pid, from: info.from, ids: ids, lossA: info.lossA, lossD: info.lossD, attWins: info.attWins });
      if (info.retreat != null) r.cur.rt.push({ id: (info.attWins ? info.def : info.att).id, to: info.retreat });
      else if (info.destroyed) r.cur.rm.push({ id: info.destroyed.id });
    };
    r.siege = function (pid, B, loss) { if (!r.cur) r.beat(); r.cur.sg.push({ pid: pid, loss: loss }); };
    r.cap = function (pid, nw) { if (!r.cur) r.beat(); r.cur.cap.push({ pid: pid, owner: nw }); };
    return r;
  }
  function snapshot() { return S.armies.map(function (a) { return { id: a.id, owner: a.owner, prov: a.prov, troops: a.troops, org: Math.round(a.org) }; }); }

  var animTok = 0;
  function skipAnim() { if (ANIM) { ANIM.skip = true; } }
  function playback(rec, snap, done) {
    if (ST.anim === 'off' || typeof requestAnimationFrame !== 'function' || !rec.beats.length) { done(); return; }
    var A = { arms: {}, own: {}, fx: [], skip: false }, g = gen, tok = ++animTok, fast = ST.anim === 'fast', queue = [], qi = 0, t0 = 0, cur = null;
    snap.forEach(function (s) { var p = S.provs[s.prov]; A.arms[s.id] = { id: s.id, owner: s.owner, x: p.lx, y: p.ly, troops: s.troops, org: s.org }; });
    rec.beats.forEach(function (b) {
      if (b.mv.length) queue.push({ ph: 'mv', d: fast ? 200 : 420, ev: b.mv });
      if (b.bt.length) queue.push({ ph: 'bt', d: fast ? 380 : 700, ev: b.bt });
      if (b.rt.length || b.rm.length) queue.push({ ph: 'rt', d: fast ? 200 : 380, ev: b.rt, rm: b.rm });
      if (b.sg.length) queue.push({ ph: 'sg', d: fast ? 120 : 260, ev: b.sg });
      if (b.cap.length) queue.push({ ph: 'cap', d: fast ? 200 : 420, ev: b.cap });
    });
    ANIM = A;
    function ease(t) { return t * t * (3 - 2 * t); }
    function begin(q, now) {
      t0 = now; cur = q;
      if (q.ph === 'mv' || q.ph === 'rt') {
        q.mv = [];
        q.ev.forEach(function (e) { var ar = A.arms[e.id], p = S.provs[e.to]; if (ar) q.mv.push({ ar: ar, x0: ar.x, y0: ar.y, x1: p.lx, y1: p.ly }); });
      } else if (q.ph === 'bt') {
        q.ev.forEach(function (e) {
          var p = S.provs[e.pid], fp = e.from != null ? S.provs[e.from] : null, bx = fp ? (p.lx + fp.lx) / 2 : p.lx, by = fp ? (p.ly + fp.ly) / 2 : p.ly;
          e.ids.forEach(function (s) { var ar = A.arms[s.id]; if (ar) { ar.troops = s.troops; ar.org = s.org; } });
          A.fx.push({ k: 'clash', x: bx, y: by, t0: now, d: q.d });
          A.fx.push({ k: 'num', x: bx, y: by, t0: now, d: q.d + 300, text: '−' + e.lossA, c: 'a' });
          A.fx.push({ k: 'num', x: bx, y: by, t0: now, d: q.d + 300, text: '−' + e.lossD, c: 'd' });
        });
        if (S.phase !== 'x') SFX.battle();
      } else if (q.ph === 'sg') {
        q.ev.forEach(function (e) { var p = S.provs[e.pid]; A.fx.push({ k: 'num', x: p.lx, y: p.ly, t0: now, d: q.d + 300, text: '−' + e.loss, c: 'd' }); });
      } else if (q.ph === 'cap') {
        q.ev.forEach(function (e) { var p = S.provs[e.pid]; A.own[e.pid] = e.owner; A.fx.push({ k: 'pulse', x: p.lx, y: p.ly, t0: now, d: q.d + 200, owner: e.owner }); });
        buildRaster();
      }
    }
    function finishPhase() {
      if (cur && (cur.ph === 'mv' || cur.ph === 'rt')) cur.mv.forEach(function (m) { m.ar.x = m.x1; m.ar.y = m.y1; });
      if (cur && cur.ph === 'rt' && cur.rm) cur.rm.forEach(function (e) { delete A.arms[e.id]; });
    }
    function frame(now) {
      if (g !== gen || tok !== animTok) return;
      if (A.skip) { ANIM = null; done(); return; }
      if (!cur) { if (qi >= queue.length) { ANIM = null; done(); return; } begin(queue[qi], now); }
      var t = Math.min(1, (now - t0) / cur.d);
      if (cur.ph === 'mv' || cur.ph === 'rt') {
        var e2 = ease(t);
        cur.mv.forEach(function (m) { m.ar.x = m.x0 + (m.x1 - m.x0) * e2; m.ar.y = m.y0 + (m.y1 - m.y0) * e2; });
      }
      A.fx = A.fx.filter(function (f) { return now - f.t0 < f.d; });
      draw(now);
      if (t >= 1) { finishPhase(); cur = null; qi++; }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  function endTurn() {
    if (S.phase !== 'play' || S.busy) return;
    S.busy = true; S.selA = -1; S.msg = ''; closeView(); UNDO.length = 0;
    var g = gen, c;
    aiDiplomacy();
    for (c = 0; c < NC; c++) if (c !== S.player && owned(c).length > 0) aiTurn(c);
    var snap = snapshot(), rec = newRec();
    resolveMovement(rec);
    rec.beat();
    resolveSieges(rec);
    mergeArmies();
    computeSupply();
    checkEnd();
    render();
    playback(rec, snap, function () {
      if (g !== gen) return;
      ANIM = null;
      buildRaster();
      if (S.phase === 'over') { S.busy = false; S.ui.view = 'end'; render(); return; }
      nextRound();
    });
  }

