  /* ---------- toasts / hud ---------- */
  function toast(msg, kind) {
    var box = $('toasts');
    if (!box) return;
    var d = document.createElement('div');
    d.className = 'toast' + (kind ? ' ' + kind : '');
    d.setAttribute('role', 'status');
    d.innerHTML = '<i></i><span>' + esc(msg) + '</span>';
    box.appendChild(d);
    d.addEventListener('click', function () { if (d.parentNode) d.parentNode.removeChild(d); });
    while (box.children.length > 2) box.removeChild(box.firstChild);
    setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 3600);
  }
  /* ---------- loud news banners: war, ultimatum, demands, blockade ---------- */
  function news(kind, title, text, go) {
    var box = $('news');
    if (!box || ST.news === false) toast(title + ': ' + text, kind === 'good' ? 'good' : (kind === 'blk' || kind === 'dem') ? 'warn' : 'bad');
    else {
      var d = document.createElement('div'), ms = kind === 'war' ? 16000 : kind === 'good' ? 8000 : 13000, icon = kind === 'war' ? 'sword' : kind === 'blk' ? 'anchor' : kind === 'good' ? 'check' : 'warn';
      d.className = 'nw ' + kind;
      d.setAttribute('role', 'alert');
      d.style.setProperty('--d', ms + 'ms');
      d.innerHTML = '<div class="nw-ic">' + ico(icon) + '</div><div class="nw-tx"><b>' + esc(title) + '</b><span>' + esc(text) + '</span></div>' + (go ? '<div class="nw-go">' + (go === 'mis' ? 'Задания' : 'Дипломатия') + '</div>' : '') + '<i class="nw-bar"></i>';
      var bye = function () {
        if (!d.parentNode) return;
        d.classList.add('out');
        setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); newsLayout(); }, 240);
      };
      d.addEventListener('click', function () { bye(); if (go && S && S.phase === 'play' && !S.busy) openView(go); });
      box.insertBefore(d, box.firstChild);
      var cap = (innerWidth < 700 || innerHeight < 520) ? 2 : 3;
      while (box.children.length > cap) {
        var vic = null, ci;
        for (ci = box.children.length - 1; ci > 0; ci--) if (box.children[ci].classList.contains('good')) { vic = box.children[ci]; break; }
        box.removeChild(vic || box.lastChild);
      }
      setTimeout(bye, ms);
      newsLayout();
    }
    if (kind === 'war' || kind === 'ult') { if (ST.alarm) SFX.alarm(); buzz([200, 90, 200]); } else if (kind === 'good') { SFX.capture(); buzz(60); } else { SFX.lose(); buzz(120); }
  }
  function newsLayout() {
    var box = $('news'), st = $('stage');
    if (!box || !st) return;
    var has = box.children.length > 0;
    st.classList.toggle('has-news', has);
    st.style.setProperty('--nh', (has ? box.offsetHeight : 0) + 'px');
  }
  function flagH(c) { return '<span class="flag" style="background:' + rgb(COL[c < 0 ? 7 : c], 1) + '"></span>'; }
  function r0(v) { return Math.round(v); }
  function U(t) { return Math.max(1, Math.round(t / 10)); }
  function fmtU(t) { var v = t / 10; return v >= 10 ? Math.round(v) : Math.round(v * 10) / 10; }
  function signed(v) { return (v >= 0 ? '+' : '−') + Math.abs(v); }
  function idleArmies() { return S.armies.filter(function (a) { return a.owner === S.player && !a.route.length; }); }
  function relOf(c) { return c === S.player ? 'me' : S.rel[S.player][c]; }

  function updateHud() {
    var who = $('who'), pills = $('pills'), turn = $('turn');
    if (S.phase === 'pick') {
      who.innerHTML = '<span class="nm dim">Выбор державы</span>'; pills.innerHTML = ''; stage.setAttribute('data-season', '');
      turn.innerHTML = '<span class="sd" style="background:var(--faint)"></span>Карта «' + esc(mapTitle(S.seed)) + '»<small>' + NP + ' провинций</small>';
    } else {
      var us = S.player, net = netIncome(us);
      who.innerHTML = flagH(us) + '<span class="nm">' + CNAMES[us] + '</span>';
      pills.innerHTML =
        '<div class="pill gold" data-go="eco" title="Казна и доход за ход (нажми: слой промышленности)">' + ico('coin') + '<b>' + S.gold[us] + '</b><span class="d ' + (net >= 0 ? 'pos' : 'neg') + '">' + signed(net) + '</span></div>' +
        '<div class="pill" data-go="army" title="Численность войск (нажми: список армий)">' + ico('sword') + '<b>' + U(troopsOf(us)) + '</b></div>' +
        '<div class="pill" data-go="eco" title="Запас техники и прирост за ход (промышленность)">' + ico('gear') + '<b>' + S.eq[us] + '</b><span class="d hm ' + (S.eqD[us] >= 0 ? 'pos' : 'neg') + '">' + signed(S.eqD[us]) + '</span></div>' +
        '<div class="pill" data-go="end" title="Провинций (нажми: итоги)">' + ico('flag') + '<b>' + owned(us).length + '</b><span class="d muted">/' + NP + '</span></div>';
      var si = sIdx(), dots = ['#8BD17C', '#F2C14E', '#E08A3C', '#8FC7F2'];
      stage.setAttribute('data-season', ST.tint && si >= 0 ? String(si) : '');
      turn.innerHTML = '<span class="sd" style="background:' + (si >= 0 ? dots[si] : 'var(--faint)') + '"></span>Ход ' + S.round + (S.vic === 'pts' ? '/' + S.limit : '') + (si >= 0 ? ' · ' + SEASONS[si].n : '') + (si >= 0 ? '<small>' + esc(SEASONS[si].d) + '</small>' : '');
    }
    var lay = S.layer || 'pol';
    $('bLay').innerHTML = ico('layers') + (lay !== 'pol' ? '<span class="lt">' + (lay === 'mil' ? 'Фронты' : lay === 'sup' ? 'Снабжение' : lay === 'nat' ? 'Народы' : lay === 'unr' ? 'Бунты' : 'Промышл.') + '</span>' : '');
    $('bLay').setAttribute('aria-pressed', String(lay !== 'pol'));
    $('bMulti').setAttribute('aria-pressed', String(!!S.multiMode));
    $('bMulti').innerHTML = ico('select') + (S.multiMode && S.multi.length ? '<span class="bd">' + S.multi.length + '</span>' : '');
    var n = S.phase === 'play' ? S.offers.filter(validOffer).length : 0, b = $('bDip');
    b.innerHTML = ico('globe') + '<span>Дипломатия</span>' + (n ? '<span class="bd">' + n + '</span>' : '');
    $('dock').hidden = S.phase !== 'play';
    var ns = !!ST.noside && S.phase === 'play';
    $('app').classList.toggle('noside', ns);
    $('mdock').hidden = !ns;
    var fe = $('fabEnd'); fe.hidden = !ns; if (ns) { fe.disabled = !!S.busy; fe.innerHTML = ico('sword') + (S.busy ? 'Идёт ход…' : 'Конец хода'); }
    $('bPanel').setAttribute('aria-pressed', String(!!ST.noside)); $('bPanel').hidden = S.phase !== 'play';
    var tt = S.phase === 'play' && S.tech && S.tech[S.player] && !S.tech[S.player].cur && techAvail(S.player).length;
    $('bTech').innerHTML = ico('flask') + '<span>Наука</span>' + (tt ? '<span class="bd">!</span>' : '');
  }

  /* ---------- side panel ---------- */
  function terrTxt(p) { return SETT[p.set].n + (p.capital ? ' · столица' : '') + ' · ' + TER[p.terrain].n; }
  function seaCard0(p) {
    return '<section class="card"><div class="ph"><span class="flag" style="background:#3C7FB0"></span><div><div class="title">' + esc(p.name) + '</div><div class="sub">Морская зона</div></div></div><p class="note">Армии плавают из любой береговой провинции, по морю быстрее, чем по суше. Боёв на море нет; высадка на вражеский берег на 20% слабее, а армия в море теряет по 3% в ход.</p></section>';
  }
  function provCard(p) {
    if (p.sea) return seaCard(p);
    var us = S.player, o = p.owner, rel = relOf(o), chips = '';
    chips += '<span class="chip">' + CNAMES[o] + '</span>';
    chips += rel === 'me' ? '<span class="chip good">Твоя</span>' : rel === 'w' ? '<span class="chip bad">Война</span>' : rel === 'a' ? '<span class="chip good">Союз</span>' : '<span class="chip">Мир</span>';
    chips += p.sup ? '<span class="chip good">Снабжение</span>' : '<span class="chip warn">Нет снабжения</span>';
    if (p.port) chips += '<span class="chip">Порт</span>';
    if (p.isl) chips += '<span class="chip">Остров</span>';
    if (p.hot && p.fac + p.civ) chips += '<span class="chip bad">Бои: цех стоит</span>';
    var h = '<section class="card"><div class="ph">' + flagH(o) + '<div><div class="title">' + esc(p.name) + '</div><div class="sub">' + terrTxt(p) + '</div></div></div><div class="chips">' + chips + '</div>';
    h += '<dl class="kv"><dt>Население</dt><dd>' + popFmt(p.pop) + (ST.nocap ? ' · без лимита' : ' / ' + popFmt(popCap(p))) + '</dd>' + (p.reb ? '<dt>Мятеж</dt><dd class="neg">' + (p.reb === 2 ? 'восстание' : 'слабый бунт') + ' · сила ' + popFmt(p.rebS) + '</dd>' : (p.unr >= 40 || p.crit > 0) ? '<dt>Недовольство</dt><dd>' + r0(p.unr) + '%' + (p.unr >= 90 ? ' · брожение ' + r0(p.crit) + '/' + rebNeed(p) : '') + '</dd>' : '') + '<dt>Доход</dt><dd>' + signed(pIncome(p)) + '</dd>' + (p.res >= 0 ? '<dt>Ресурс</dt><dd>' + RES[p.res].n + ' · ' + RES[p.res].s + '</dd>' : '') + '<dt>Гарнизон</dt><dd>' + p.garrison + ' / ' + gcap(p) + '</dd><dt>Заводы</dt><dd>' + (p.fac + p.civ ? 'воен. ' + p.fac + ' · гражд. ' + p.civ + ' (из ' + facMax(p) + ')' + (p.fd > 0.03 ? ' · −' + r0(p.fd * 100) + '%' : '') : p.set ? 'нет' : '—') + '</dd><dt>Развитие</dt><dd>' + p.dev + ' / 3</dd><dt>Сложность марша</dt><dd>×' + TER[p.terrain].cost + '</dd><dt>Оборона</dt><dd>×' + r1(defMultP(p)) + '</dd></dl>';
    h += ethHtml(p);
    if (p.occ > 0) h += '<div><div class="lblrow"><span>Оккупация · ' + (p.occBy >= 0 ? CNAMES[p.occBy] : '') + '</span><b>' + r0(p.occ) + '%</b></div><div class="bar"><i class="warn" style="width:' + r0(p.occ) + '%"></i></div></div>';
    if (o === us && S.phase === 'play') {
      var n = SETT[p.set].rec, cost = recCostFor(n), can = canRecruit(p), here = armiesAt(p.id).filter(mine);
      var why = p.recruited ? 'Уже набирали в этом ходу' : !p.sup ? 'Нет снабжения' : p.occ > 0 || p.besieged ? 'Провинция в осаде' : S.gold[us] < cost ? 'Не хватает золота' : S.eq[us] < n ? 'Нет техники (нужно ' + n + ')' : p.pop < popNeed(n) ? 'Мало населения' : '';
      h += '<button class="btn primary" type="button" data-act="recruit"' + (can ? '' : ' disabled') + '>' + ico('plusc') + (here.length ? 'Пополнить армию' : 'Набрать армию') + ' · +' + n + ' див. · ' + cost + ' зол.' + (RL('rMan') ? ' · −' + popCost(n) + ' нас.' : '') + '</button>';
      if (!can && why) h += '<p class="note">' + why + '.</p>';
    }
    if (o === us && S.phase === 'play' && p.set >= 1) {
      if (p.fac + p.civ < facMax(p)) h += '<div class="row"><button class="btn wide" type="button" data-act="fbuild" data-t="mil"' + (canBuildFac(p) ? '' : ' disabled') + '>' + ico('gear') + 'Воен. завод · ' + facCost(p) + '</button><button class="btn wide" type="button" data-act="fbuild" data-t="civ"' + (canBuildFac(p) ? '' : ' disabled') + '>' + ico('coin') + 'Гражд. завод · ' + facCost(p) + '</button></div>';
      if (p.fac + p.civ && p.fd > 0.04) h += '<button class="btn" type="button" data-act="frepair"' + (canRepair(p) ? '' : ' disabled') + '>' + ico('refresh') + 'Восстановить цех · ' + repairCost(p) + ' зол.</button>';
      h += '<p class="note">Военные заводы дают технику, гражданские — золото и рост населения. Бои и осады в провинции их разрушают.</p>';
    }
    if (o === us && S.phase === 'play') {
      h += '<button class="btn" type="button" data-act="fdev"' + (canDevelop(p) ? '' : ' disabled') + '>' + ico('people') + (p.dev >= 3 ? 'Развитие на максимуме' : 'Развить население · ' + devCost(p) + ' зол.') + '</button>';
      if (p.depot) h += '<p class="note">Склад: снабжает провинции вокруг (радиус 2).</p>';
      else h += '<button class="btn" type="button" data-act="depot"' + (canBuildDepot(p) ? '' : ' disabled') + '>' + ico('castle') + 'Построить склад · 12 зол.</button>';
    }
    return h + '</section>';
  }
  function armyRow(a) {
    var c = COL[a.owner], rt = a.route.length ? '→ ' + S.provs[a.route[a.route.length - 1]].name + ' · ' + routeTurns(a) + ' х.' : 'без приказа';
    return '<button class="arow" type="button" data-act="sel" data-id="' + a.id + '" aria-pressed="' + (a.id === S.selA || S.multi.indexOf(a.id) >= 0) + '"><span class="mini" style="background:' + rgb(c, 0.86) + '">' + U(a.troops) + '</span><span class="tx"><b>Армия №' + a.id + (mine(a) ? '' : ' · ' + CNAMES[a.owner]) + '</b><span>' + (mine(a) ? rt + (a.stance === 'hold' ? ' · оборона' : a.stance === 'res' ? ' · резерв' : '') + (genOf(a) ? ' · ' + esc(genOf(a).name) : '') : 'орг. ' + r0(a.org) + '%') + '</span></span><span class="bar"><i class="' + (a.org > 60 ? '' : a.org > 30 ? 'warn' : 'bad') + '" style="width:' + r0(a.org) + '%"></i></span></button>';
  }
  function armyCard(a) {
    var p = S.provs[a.prov], sup = armySup(a), h = '<section class="card"><div class="ph">' + flagH(a.owner) + '<div><div class="title">Армия №' + a.id + '</div><div class="sub">' + esc(p.name) + ' · ' + TER[p.terrain].n + '</div></div></div>';
    h += '<div class="chips">' + (sup ? '<span class="chip good">Снабжение</span>' : '<span class="chip bad">Без снабжения · −6% в ход</span>') + (a.org < 30 ? '<span class="chip warn">Истощена</span>' : '') + (encircled(a) ? '<span class="chip bad">Окружена</span>' : '') + (a.dug ? '<span class="chip good">Окопы ' + a.dug + '/3</span>' : '') + (armyBlk(a) ? '<span class="chip bad">Блокада</span>' : '') + (a.wait ? '<span class="chip">Выступит через ' + a.wait + ' х.</span>' : '') + '</div>';
    h += '<div><div class="lblrow"><span>Численность</span><b>' + a.troops + '</b></div><div class="bar"><i class="acc" style="width:' + clamp(a.troops / 3, 4, 100) + '%"></i></div></div>';
    h += '<div><div class="lblrow"><span>Организация</span><b>' + r0(a.org) + '%</b></div><div class="bar"><i class="' + (a.org > 60 ? '' : a.org > 30 ? 'warn' : 'bad') + '" style="width:' + r0(a.org) + '%"></i></div></div>';
    var fgt = a.eng && a.route.length && a.route[0] === a.eng.pid ? hostileAt(a.eng.pid, a.owner) : null;
    if (fgt) {
      h += '<div class="fbox"><div class="lblrow"><span><b>Фронтовой бой за ' + esc(S.provs[a.eng.pid].name) + '</b></span><b>ход ' + a.eng.turns + '</b></div>' +
        '<div><div class="lblrow"><span>Наша организация</span><b>' + r0(a.org) + '%</b></div><div class="bar"><i class="' + (a.org > 40 ? '' : 'warn') + '" style="width:' + r0(a.org) + '%"></i></div></div>' +
        '<div><div class="lblrow"><span>Противник · ' + U(fgt.troops) + ' див.</span><b>' + r0(fgt.org) + '%</b></div><div class="bar"><i class="bad" style="width:' + r0(fgt.org) + '%"></i></div></div>' +
        '<p class="note">Бой идёт каждый ход, пока оборона не рухнет или армия не выдохнется (орг. ниже 20%).</p></div>';
    }
    var g = genOf(a), m = '';
    m += '<div><div class="lblrow"><span>Генерал</span><b>' + (g ? esc(g.name) + ' · ур. ' + g.lvl + ' · ' + traitName(g) : 'не назначен (−8% к силе)') + '</b></div>';
    if (g) {
      m += '<div class="sk">' + SKK.filter(function (k) { return g.sk[k]; }).map(function (k) { return '<span title="' + SKD[k] + '">' + SKN[k] + '</span><i>' + new Array(g.sk[k] + 1).join('●') + '</i>'; }).join('') + '</div>';
      m += '<div class="bar" style="margin-top:6px"><i class="acc" style="width:' + clamp(g.xp / (g.lvl * 40) * 100, 2, 100) + '%"></i></div>';
      if (a.troops > cmdLimit(g)) m += '<p class="note"><span class="verdict warn">Перегруз командования:</span> генерал ведёт не более ' + U(cmdLimit(g)) + ' див. эффективно.</p>';
    }
    m += '<div class="row" style="margin-top:6px"><button class="btn sm" type="button" data-act="cgen">' + ico('refresh') + 'Сменить генерала</button></div></div>';
    m += '<div class="fld"><span class="lbl">Стойка</span><div class="seg">' + [['atk', 'Наступление'], ['hold', 'Оборона'], ['res', 'Резерв']].map(function (s) { return '<button type="button" data-act="stance" data-v="' + s[0] + '" aria-pressed="' + (a.stance === s[0]) + '">' + s[1] + '</button>'; }).join('') + '</div><small>' + (a.stance === 'hold' ? 'Окапывается: до +24% к обороне за 3 хода без боя и марша.' : a.stance === 'res' ? 'Резерв: держится в тылу, по кнопке идёт на опасный участок.' : 'Готова к маршу и осаде.') + '</small></div>';
    m += '<div class="fld"><span class="lbl">Характер боя</span><div class="seg">' + [['push', 'Натиск'], ['grind', 'Измотать']].map(function (s) { return '<button type="button" data-act="mode" data-v="' + s[0] + '" aria-pressed="' + ((a.mode || 'push') === s[0]) + '">' + s[1] + '</button>'; }).join('') + '</div><small>' + (a.mode === 'grind' ? 'Медленно изматывает врага: свои потери втрое меньше, бой тянется дольше. Армия остаётся на линии фронта.' : 'Быстрый прорыв: оборона падает скорее, но свои потери выше.') + '</small></div>';
    m += blkHtml(a);
    if (a.route.length) {
      var last = a.route[a.route.length - 1], fc = forecast(a, last);
      h += '<dl class="kv"><dt>Приказ</dt><dd>→ ' + esc(S.provs[last].name) + '</dd><dt>В пути</dt><dd>' + routeTurns(a) + ' х.</dd></dl>';
      if (fc) h += fc.kind === 'battle' ? '<p class="note">Фронтовой бой с армией ' + U(fc.enemy.troops) + ' див.: <span class="verdict ' + fc.tone + '">' + fc.label + '</span>. Бой идёт по нескольку ходов; оборона отступает, а не гибнет.</p>' : '<p class="note">Осада: гарнизон ' + fc.garrison + '. Потом оккупация провинции.</p>';
    } else h += '<p class="note">Нажми на соседнюю провинцию на карте — армия пойдёт туда по дорогам. Вражескую провинцию армия начнёт осаждать.</p>';
    h += '<div class="row">';
    if (a.route.length) h += '<button class="btn sm" type="button" data-act="cancel">' + ico('stop') + (fgt ? 'Прекратить бой' : 'Остановить') + '</button>';
    if (UNDO.length) h += '<button class="btn sm" type="button" data-act="undo">' + ico('back') + 'Отменить приказ</button>';
    if (a.troops >= 20) h += '<button class="btn sm" type="button" data-act="split">' + ico('merge') + 'Разделить</button>';
    if (!ST.newbie) h += '<button class="btn sm" type="button" data-act="armyMore" aria-pressed="' + !!S.ui.armyMore + '">' + (S.ui.armyMore ? 'Скрыть' : 'Ещё') + '</button>';
    h += '</div>';
    if (!ST.newbie && S.ui.armyMore) {
      h += m + '<div class="row">';
      h += '<button class="btn sm" type="button" data-act="fallback">' + ico('back') + 'Отвод</button>';
      if (a.stance === 'res') h += '<button class="btn sm" type="button" data-act="toFront">' + ico('sword') + 'На опасный участок</button>';
      if (armiesAt(a.prov).filter(function (x) { return x.owner === a.owner && x !== a; }).length) h += '<button class="btn sm" type="button" data-act="merge">' + ico('merge') + 'Объединить</button>';
      h += '<button class="btn sm" type="button" data-act="selp" data-id="' + a.prov + '">' + ico('pin') + 'Провинция</button></div>';
    }
    h += '</section>';
    return h;
  }
  function multiCard() {
    var arms = selSet(), T = arms.reduce(function (t, a) { return t + a.troops; }, 0), h = '<section class="card"><h3 class="h">Выбор нескольких армий</h3>';
    if (!arms.length) return h + '<p class="note">Нажимай на свои армии на карте или в списке, чтобы добавить их. Потом нажми на провинцию-цель: все пойдут туда сразу.</p></section>';
    h += '<dl class="kv"><dt>Армий</dt><dd>' + arms.length + '</dd><dt>Людей</dt><dd>' + T + '</dd><dt>Орг. в среднем</dt><dd>' + r0(arms.reduce(function (t, a) { return t + a.org; }, 0) / arms.length) + '%</dd></dl>';
    h += '<button class="row-t" type="button" data-act="sync" aria-pressed="' + (S.sync !== false) + '"><span><b>Синхронный удар</b><small>Армии подойдут к цели в один ход</small></span><i class="sw"></i></button>';
    h += '<div class="row"><button class="btn sm" type="button" data-act="mstance" data-v="atk">Наступление</button><button class="btn sm" type="button" data-act="mstance" data-v="hold">Оборона</button><button class="btn sm" type="button" data-act="mstance" data-v="res">Резерв</button><button class="btn sm" type="button" data-act="mmode" data-v="push">Натиск</button><button class="btn sm" type="button" data-act="mmode" data-v="grind">Измотать</button><button class="btn sm" type="button" data-act="mstop">' + ico('stop') + 'Стоп</button><button class="btn sm" type="button" data-act="mfall">' + ico('back') + 'Отвод</button><button class="btn sm" type="button" data-act="mmerge">' + ico('merge') + 'Объединить</button></div>';
    h += '<div><div class="lblrow"><span>Сохранить как группу</span></div><div class="seg3">' + [1, 2, 3].map(function (n) { return '<button class="gpill" type="button" data-act="gsave" data-n="' + n + '">Группа ' + n + '</button>'; }).join('') + '</div></div></section>';
    return h;
  }
  function groupsRow() {
    var ks = Object.keys(S.groups || {}).filter(function (k) { return S.groups[k].map(armyById).filter(Boolean).length; });
    if (!ks.length) return '';
    return '<div class="seg3">' + ks.map(function (k) { var n = S.groups[k].map(armyById).filter(Boolean).length; return '<button class="gpill" type="button" data-act="grecall" data-n="' + k + '">Группа ' + k + ' · ' + n + '</button>'; }).join('') + '</div>';
  }
  function frontCard(f) {
    var tone = f.ratio >= 1.3 ? 'good' : f.ratio >= 0.8 ? 'warn' : 'bad', lbl = f.ratio >= 1.3 ? 'Мы сильнее' : f.ratio >= 0.8 ? 'Равновесие' : 'Опасный участок';
    var res = S.armies.filter(function (a) { return a.owner === S.player && a.stance === 'res'; }).length;
    var h = '<section class="card"><div class="ph">' + flagH(f.enemy) + '<div><div class="title">Фронт: ' + CNAMES[f.enemy] + '</div><div class="sub">' + f.mine.length + ' своих и ' + f.theirs.length + ' вражеских провинций</div></div></div>';
    h += '<div class="chips"><span class="chip ' + tone + '">' + lbl + ' ×' + r1(f.ratio) + '</span></div>';
    h += '<dl class="kv"><dt>Наша сила</dt><dd>' + U(f.my) + '</dd><dt>Сила врага</dt><dd>' + U(f.their) + '</dd><dt>Армий на фронте</dt><dd>' + f.armies.length + '</dd><dt>Резервов в тылу</dt><dd>' + res + '</dd></dl>';
    h += '<div class="row"><button class="btn sm primary" type="button" data-act="fo" data-v="attack">' + ico('sword') + 'Наступать</button><button class="btn sm" type="button" data-act="fo" data-v="grind">' + ico('sword') + 'На износ</button><button class="btn sm" type="button" data-act="fo" data-v="hold">' + ico('shield') + 'Держать фронт</button><button class="btn sm" type="button" data-act="fo" data-v="reserve">Резервы сюда</button></div>';
    h += '<p class="note">Сила считает людей, организацию и гарнизоны. Резервом назови армию в тылу (стойка «Резерв»).</p></section>';
    return h;
  }
  function armiesListCard() {
    var mine_ = S.armies.filter(mine), idle = idleArmies().length;
    return '<section class="card"><h3 class="h">Армии · без приказа: ' + idle + '</h3>' + groupsRow() + (mine_.length ? '<div class="alist">' + mine_.map(armyRow).join('') + '</div>' : '<p class="note">Армий нет. Выбери свою провинцию и набери войска.</p>') + '</section>';
  }
  function frontsListCard() {
    var fr = S.fronts || [];
    if (!fr.length) return '';
    return '<section class="card"><h3 class="h">Фронты</h3><div class="alist">' + fr.map(function (f) {
      var col = f.ratio >= 1.3 ? '#2FAE6C' : f.ratio >= 0.8 ? '#D9A12C' : '#D8483B';
      return '<button class="arow" type="button" data-act="front" data-id="' + f.id + '"><span class="mini" style="background:' + col + '">×' + r1(f.ratio) + '</span><span class="tx"><b>' + CNAMES[f.enemy] + '</b><span>' + f.armies.length + ' арм. · ' + U(f.my) + ' против ' + U(f.their) + '</span></span></button>';
    }).join('') + '</div></section>';
  }
  function overviewCard() {
    var us = S.player, wars = [], idle = idleArmies().length;
    for (var c = 0; c < NC; c++) if (c !== us && owned(c).length && S.rel[us][c] === 'w') wars.push(CNAMES[c]);
    var h = '<section class="card"><h3 class="h">Держава</h3><dl class="kv"><dt>Провинций</dt><dd>' + owned(us).length + ' из ' + NP + '</dd><dt>Население</dt><dd>' + popOf(us) + '</dd><dt>Войска</dt><dd>' + U(troopsOf(us)) + ' див.</dd><dt>Содержание</dt><dd>−' + upkeep(us) + '</dd>' + (RL('rWar') && S.weary ? '<dt>Усталость от войны</dt><dd>' + r0(S.weary[us]) + '%</dd>' : '') + '<dt>Доход за ход</dt><dd>' + signed(netIncome(us)) + '</dd><dt>Заводов</dt><dd>' + facTotal(us) + ' · воен. ' + r1(indOut(us)) + ' · гражд. ' + r1(civOut(us)) + '</dd><dt>Техника</dt><dd>' + S.eq[us] + ' / ' + eqCap(us) + ' (' + signed(S.eqD[us]) + ')</dd><dt>Война с</dt><dd>' + esc(wars.join(', ') || 'никем') + '</dd></dl>' + taxHtml() + misMini() + '</section>';
    h += emBrief() + frontsListCard() + armiesListCard();
    h += '<div class="row"><button class="btn sm" type="button" data-act="view" data-v="gen">' + ico('star') + 'Генералы</button><button class="btn sm" type="button" data-act="view" data-v="end">' + ico('flag') + 'Итоги</button></div>';
    return h;
  }
  function renderPanel() {
    var body = $('sideBody'), foot = $('sideFoot'), h = '', f = '';
    if (S.phase === 'pick') {
      h += '<section class="card"><h3 class="h">Выбери державу</h3><div class="picks">';
      for (var c = 0; c < NC; c++) {
        var ps = owned(c);
        h += '<button class="pick" type="button" data-act="pick" data-c="' + c + '" aria-pressed="' + (S.pickC === c) + '">' + flagH(c) + '<div><b>' + CNAMES[c] + '</b><span>' + ps.length + ' пров. · ' + U(troopsOf(c)) + ' див. · ' + S.provs[capitalOf(c)].name + '</span></div></button>';
      }
      h += '</div></section><p class="note">Можно выбрать державу прямо на карте. Границы: красная — война, зелёная — союз, белая — мир.</p>';
      f = '<button class="btn" type="button" data-act="reroll">' + ico('refresh') + 'Новая карта</button><button class="btn primary lg" type="button" data-act="begin"' + (S.pickC < 0 ? ' disabled' : '') + '>Начать' + ico('next') + '</button>';
    } else if (S.phase === 'over') {
      h += '<section class="card"><h3 class="h">Итог</h3><div class="title ' + (S.won ? 'verdict good' : 'verdict bad') + '">' + (S.won ? (S.allied ? 'Победа союзом' : 'Победа') : 'Поражение') + '</div><p class="note">' + esc(S.why || '') + '. Ходов: ' + S.round + '.</p></section>';
      f = '<button class="btn" type="button" data-act="view" data-v="end">Итоги</button>' + (S.won ? '<button class="btn" type="button" data-act="cont">Продолжить</button>' : '') + '<button class="btn primary lg" type="button" data-act="new">Новая игра</button>';
    } else {
      var a = S.selA >= 0 ? armyById(S.selA) : null, fr = S.selF ? frontById(S.selF) : null;
      if (a && !a.route) a = null;
      if (S.multiMode) h += multiCard();
      else if (a) h += armyCard(a);
      var sp = a ? a.prov : S.selP;
      if (fr && !a && !S.multiMode) h += frontCard(fr);
      else if (sp >= 0 && !S.multiMode) {
        h += provCard(S.provs[sp]);
        var here = armiesAt(sp).filter(function (x) { return visibleArmy(x, sp); });
        if (here.length && !(a && here.length === 1)) h += '<section class="card"><h3 class="h">Армии в провинции</h3><div class="alist">' + here.map(armyRow).join('') + '</div></section>';
      } else if (S.multiMode) h += armiesListCard();
      else h += overviewCard();
      var idle = idleArmies().length;
      f = '<button class="btn" type="button" data-act="next" title="Следующая армия без приказа (N)"' + (idle ? '' : ' disabled') + '>' + ico('sword') + idle + '</button><button class="btn primary lg" type="button" data-act="end"' + (S.busy ? ' disabled' : '') + '>' + (S.busy ? 'Идёт ход…' : 'Конец хода') + (S.busy ? '' : ico('next')) + '</button>';
    }
    var st = body.scrollTop, key = (S.phase + ':' + S.selA + ':' + S.selP + ':' + S.selF + ':' + S.multiMode);
    body.innerHTML = h; foot.innerHTML = f;
    if (renderPanel.key === key) body.scrollTop = st; else body.scrollTop = 0;
    renderPanel.key = key;
  }
  function r1(v) { return Math.round(v * 10) / 10; }

  /* ---------- sheets ---------- */
  var DEVCODE = '1337', HSN = 0, HST = 0, GENB = false;
  function dvb(k, v, label) { return '<button class="btn sm" type="button" data-act="dv" data-k="' + k + '"' + (v != null ? ' data-v="' + v + '"' : '') + '>' + label + '</button>'; }
  function devHtml() {
    if (!ST.dev) return head('Режим разработчика', true, 'codes') + '<div class="sh-body"><p class="note">Режим выключен. Введи код в разделе «Коды».</p></div>';
    var pl = S && S.phase === 'play', us = S ? S.player : -1, sp = S && S.selP >= 0 ? S.provs[S.selP] : null, sa = S && S.selA >= 0 ? armyById(S.selA) : null;
    var h = head('Режим разработчика', true, 'codes') + '<div class="sh-body">';
    if (!pl) return h + '<p class="note">Начни игру (выбери державу), чтобы пользоваться инструментами.</p></div>';
    h += '<p class="note">Ход ' + S.round + ' · карта «' + esc(mapTitle(S.seed)) + '» · провинций ' + NP + ' · держав ' + NC + '<br>Выбрано: ' + (sp && !sp.sea ? 'провинция ' + esc(sp.name) + ' (' + (sp.owner >= 0 ? CNAMES[sp.owner] : '—') + ')' : 'провинция не выбрана') + ' · ' + (sa ? 'армия ' + U(sa.troops) + ' див.' : 'армия не выбрана') + '</p>';
    h += '<div class="sec"><h3 class="h">Золото и наука</h3><div class="row">' + dvb('gold', 100, '+100 зол.') + dvb('gold', 1000, '+1000 зол.') + dvb('gold', 10000, '+10000 зол.') + dvb('techall', null, 'Все технологии') + dvb('tech100', null, '+100 очков науки') + '</div>' + togH('devGold', 'Бесконечное золото', 'Казна всегда не меньше 99999') + '</div>';
    h += '<div class="sec"><h3 class="h">Армии (выбранная армия)</h3><div class="row">' + dvb('troops', 100, '+10 див.') + dvb('troops', 500, '+50 див.') + dvb('troops', 2000, '+200 див.') + dvb('healall', null, 'Орг. 100% всем моим') + dvb('army', 200, 'Новая армия 20 див. в провинции') + dvb('delarmy', null, 'Удалить армию') + '</div></div>';
    h += '<div class="sec"><h3 class="h">Провинции (выбранная провинция)</h3><div class="row">' + dvb('capture', null, 'Захватить') + dvb('pop', 10, 'Население +10') + dvb('garr', null, 'Гарнизон полный') + dvb('depot', null, 'Склад') + '</div><span class="lbl">Передать державе</span><div class="row">';
    for (var c = 0; c < NC; c++) if (owned(c).length) h += dvb('give', c, flagH(c) + CNAMES[c]);
    h += '</div></div>';
    h += '<div class="sec"><h3 class="h">Дипломатия</h3><div class="row">' + dvb('peace', null, 'Мир со всеми') + dvb('ally', null, 'Союз со всеми') + dvb('op', null, 'Отношения +30 со всеми') + dvb('win', null, 'Победить') + '</div></div>';
    h += '<div class="sec"><h3 class="h">Мир и правила</h3>' + togH('devFog', 'Открыть всю карту', 'Туман войны не мешает') + togH('nocap', 'Без лимита населения', 'Жители растут без предела') + togH('harsh', 'Тяжёлые потери', 'Больше гибнет солдат и мирных') + togH('seasons', 'Времена года', 'Сезоны меняют доход и марши') + togH('real', 'Реалистичный режим', 'Содержание армий, усталость, туман') + '</div>';
    return h + '</div>';
  }
  function devAct(k, v) {
    if (!S || S.phase !== 'play') { toast('Сначала начни игру.', 'warn'); return; }
    var us = S.player, sp = S.selP >= 0 ? S.provs[S.selP] : null, sa = S.selA >= 0 ? armyById(S.selA) : null, c, n = 0;
    if (sp && sp.sea) sp = null;
    switch (k) {
      case 'gold': S.gold[us] += +v; toast('+' + v + ' зол.', 'good'); break;
      case 'techall': S.tech[us].done = TECH.map(function (x) { return x.id; }); S.tech[us].cur = ''; S.tech[us].prog = 0; S.tech[us].fx = null; toast('Все технологии изучены.', 'good'); break;
      case 'tech100': var t = S.tech[us]; if (t.cur) t.prog += 100; else t.bank = Math.min(60, t.bank + 100); toast('+100 очков науки.', 'good'); break;
      case 'troops': if (!sa || sa.owner !== us) { toast('Выбери свою армию.', 'warn'); return; } sa.troops += +v; toast('Армия: ' + U(sa.troops) + ' див.', 'good'); break;
      case 'healall': S.armies.forEach(function (a) { if (a.owner === us) a.org = 100; }); toast('Организация восстановлена.', 'good'); break;
      case 'army': if (!sp || sp.owner !== us) { toast('Выбери свою провинцию.', 'warn'); return; } var na = newArmy(us, sp.id, +v, 100); autoGen(na); S.selA = na.id; toast('Армия создана.', 'good'); break;
      case 'delarmy': if (!sa || sa.owner !== us) { toast('Выбери свою армию.', 'warn'); return; } removeArmy(sa); S.selA = -1; toast('Армия удалена.', 'good'); break;
      case 'capture': if (!sp) { toast('Выбери провинцию.', 'warn'); return; } if (sp.owner !== us) captureProv(sp.id, us); break;
      case 'give': if (!sp) { toast('Выбери провинцию.', 'warn'); return; } if (sp.owner !== +v) captureProv(sp.id, +v); break;
      case 'pop': if (!sp) { toast('Выбери провинцию.', 'warn'); return; } sp.pop = Math.min(popCap(sp), sp.pop + (+v)); toast('Население: ' + popFmt(sp.pop), 'good'); break;
      case 'garr': if (!sp) { toast('Выбери провинцию.', 'warn'); return; } sp.garrison = gcap(sp); toast('Гарнизон: ' + sp.garrison, 'good'); break;
      case 'depot': if (!sp || sp.owner !== us) { toast('Выбери свою провинцию.', 'warn'); return; } sp.depot = true; toast('Склад построен.', 'good'); break;
      case 'peace': for (c = 0; c < NC; c++) if (c !== us && owned(c).length && S.rel[us][c] === 'w') { makePeace(us, c); n++; } toast(n ? 'Мир заключён: ' + n : 'Войн нет.', 'good'); break;
      case 'ally': for (c = 0; c < NC; c++) if (c !== us && owned(c).length) { if (S.rel[us][c] === 'w') makePeace(us, c); setRel(us, c, 'a'); adjOp(us, c, 20); n++; } toast('Союзы заключены: ' + n, 'good'); break;
      case 'op': for (c = 0; c < NC; c++) if (c !== us && owned(c).length) adjOp(us, c, 30); toast('Отношения улучшены.', 'good'); break;
      case 'win': endGame(true, 'код разработчика'); return;
    }
    checkEnd(); saveGame(); render();
  }
  function setHtml() {
    var TABS = [['game', 'Игра', 'sword'], ['real', 'Реализм', 'shield'], ['map', 'Карта', 'map'], ['snd', 'Звук', 'sound'], ['ui', 'Вид', 'eye']], tab = ST.tab;
    if (!TABS.some(function (t) { return t[0] === tab; })) tab = 'game';
    var h = head('Настройки', true) + '<div class="stabs" role="tablist">' + TABS.map(function (t) {
      return '<button type="button" role="tab" data-act="stab" data-v="' + t[0] + '" aria-selected="' + (tab === t[0]) + '">' + ico(t[2]) + t[1] + '</button>';
    }).join('') + '</div><div class="sh-body">';
    if (tab === 'game') {
      h += '<div class="fld"><span class="lbl">Сложность ИИ</span>' + segH('ai', [['easy', 'Лёгкая'], ['normal', 'Обычная'], ['hard', 'Сильная']], ST.ai) + '<small>Влияет на доход и расчётливость соперников.</small></div>' +
        '<div class="fld"><span class="lbl">Скорость маршей</span>' + segH('speed', [['slow', 'Медленно'], ['normal', 'Обычно'], ['fast', 'Быстро']], ST.speed) + '</div>' +
        '<div class="fld"><span class="lbl">Анимация хода</span>' + segH('anim', [['normal', 'Обычная'], ['fast', 'Быстрая'], ['off', 'Выкл']], ST.anim) + '</div>' +
        '<div class="list">' + togH('seasons', 'Времена года', 'Сезоны меняют доход, марши и силу атаки') + togH('nocap', 'Без лимита населения', 'Жители растут без предела') + togH('harsh', 'Тяжёлые потери', 'Больше гибнет солдат и мирных в боях и осадах') + togH('autosave', 'Автосохранение', 'Игра сохраняется после каждого хода') + togH('tips', 'Советы советника', 'Подсказки в начале хода') + '</div>' +
        '<p class="note">Размер карты, число держав, условие победы и мирный старт выбираются при создании новой игры.</p>';
    } else if (tab === 'real') {
      h += '<div class="realbox' + (ST.real ? ' on' : '') + '">' + togH('real', 'Реалистичный режим', 'Война дорого стоит: армии надо содержать, люди не бесконечны, а зима и чужая земля косят войска.') + '</div>' +
        '<div class="list rsub' + (ST.real ? '' : ' off') + '">' +
        togH('rUp', 'Содержание армий', 'Жалованье вдвое выше, за границей ещё дороже. Нет денег в казне — войска разбегаются.') +
        togH('rMan', 'Людские ресурсы', 'Набор и потери сильнее бьют по населению: людей не бесконечно много.') +
        togH('rWar', 'Усталость от войны', 'Долгая война и потери снижают доход и растят недовольство. Уставший враг охотнее просит мир.') +
        togH('rAtt', 'Износ армий', 'Без снабжения теряешь больше. Зима и горы на чужой земле косят солдат, организация восстанавливается медленнее.') +
        togH('rFog', 'Туман войны', 'Чужие армии видны только рядом с твоими и союзными землями.') +
        togH('rDip', 'Затяжные войны', 'Мир нельзя просить в первые 3 хода войны: ни тебе, ни ИИ.') + '</div>' +
        '<p class="note">Правила одинаковы для всех держав, включая ИИ. Менять их можно в любой момент, в том числе посреди партии.' + (ST.real ? '' : ' Включи режим, чтобы правила заработали.') + '</p>';
    } else if (tab === 'map') {
      h += '<div class="list">' + togH('names', 'Названия провинций') + togH('decor', 'Рельеф на карте', 'Леса, горы, поля') + togH('fog', 'Туман войны', RL('rFog') ? 'Сейчас туман и так включён реалистичным режимом' : 'Скрывает чужие армии вдали') + togH('ships', 'Торговые корабли', 'Анимация судов на морских путях. Выключи, если карта тормозит') + togH('resicons', 'Значки ресурсов', 'Зерно, железо, золото и пряности на карте') + togH('mini', 'Миникарта', 'Обзор всей карты в углу: тапни, чтобы перейти') + togH('tint', 'Оттенок времён года', 'Лёгкая окраска карты весной, летом, осенью и зимой') + '</div>' +
        '<div class="fld"><span class="lbl">Линии снабжения</span>' + segH('supply', [['mine', 'Свои'], ['all', 'Все'], ['off', 'Выкл']], ST.supply) + '</div>' +
        '<div class="fld"><span class="lbl">Форма новой карты</span>' + segH('shape', [['auto', 'Авто'], ['tall', 'Вертикальная'], ['wide', 'Горизонтальная']], ST.shape) + '<small>Применится к следующей новой карте.</small></div>';
    } else if (tab === 'snd') {
      h += '<div class="list">' + togH('sound', 'Звуки') + '</div>' +
        '<div class="fld"><span class="lbl">Громкость</span>' + segH('vol', [[1, 'Тихо'], [2, 'Средне'], [3, 'Громко']], ST.vol) + '</div>' +
        '<div class="list">' + togH('music', 'Музыка', 'Фоновая мелодия, мрачнее во время войны') + togH('alarm', 'Сигнал тревоги', 'Тревожный звук при объявлении войны и ультиматуме') + togH('vib', 'Вибрация', 'На телефоне при важных новостях') + '</div>';
    } else {
      h += '<div class="fld"><span class="lbl">Стиль оформления</span><div class="stylepick">' + STY.map(function (q) { return '<button class="btn" type="button" data-act="seg" data-k="uiStyle" data-v="' + q[0] + '" aria-pressed="' + (styId() === q[0]) + '">' + q[1] + '</button>'; }).join('') + '</div><small>' + (styId() === 'classic' || styId() === 'brutal' ? 'Тема ниже влияет на цвета этого стиля.' : 'У этого стиля своя палитра, тема не влияет.') + '</small></div>' +
        '<div class="fld"><span class="lbl">Тема</span>' + segH('theme', [['auto', 'Авто'], ['dark', 'Тёмная'], ['light', 'Светлая'], ['sepia', 'Пергамент']], ST.theme) + '</div>' +
        '<div class="fld"><span class="lbl">Устройство</span>' + segH('device', [['phone', 'Телефон'], ['pc', 'Компьютер']], ST.device || autoDev()) + '<small>Телефон: компактный интерфейс для горизонтального экрана. Компьютер: просторный, с подсветкой при наведении.</small></div>' +
        '<div class="fld"><span class="lbl">Вид армий</span>' + segH('armyStyle', [['round', 'Жетон'], ['banner', 'Знамя'], ['classic', 'Плашка']], ST.armyStyle) + '<small>Жетон и знамя показывают звёзды генерала (пустая звезда — генерала нет) и организацию.</small></div>' +
        '<div class="fld"><span class="lbl">Лёгкий режим графики</span>' + segH('light', [['auto', 'Авто (100+ пров.)'], ['on', 'Вкл'], ['off', 'Выкл']], ST.light) + '<small>Отключает корабли, миникарту и лишние эффекты, реже перерисовывает карту. Помогает на слабых телефонах и больших картах.</small></div>' +
        '<div class="list">' + togH('newbie', 'Режим новичка', 'Больше подсказок, скрыты сложные кнопки (наука, генералы, итоги) и расширенные настройки армии') + '</div><div class="row"><button class="btn sm" type="button" data-act="tutor">' + ico('help') + 'Показать обучение</button></div>' +
        '<div class="list">' + togH('noside', 'Скрыть боковую панель', 'Карта на весь экран; панель вернётся кнопкой на карте') + togH('news', 'Баннеры новостей', 'Крупные окна о войне, ультиматумах, требованиях и блокадах. Выкл: обычные уведомления.') + '</div>' +
        '<div class="row">' + ((document.fullscreenEnabled || document.webkitFullscreenEnabled) ? '<button class="btn sm" type="button" data-act="fs">' + ico('fs') + 'Полный экран</button>' : '') + '<button class="btn sm" type="button" data-act="rset">' + ico('refresh') + 'Сбросить настройки</button></div>';
    }
    return h + '</div>';
  }
  function segH(key, opts, cur) { return '<div class="seg" role="group">' + opts.map(function (o) { return '<button type="button" data-act="seg" data-k="' + key + '" data-v="' + o[0] + '" aria-pressed="' + (String(cur) === String(o[0])) + '">' + o[1] + '</button>'; }).join('') + '</div>'; }
  function togH(key, label, desc) { return '<button class="row-t" type="button" data-act="tog" data-k="' + key + '" aria-pressed="' + !!ST[key] + '"><span><b>' + label + '</b>' + (desc ? '<small>' + desc + '</small>' : '') + '</span><i class="sw"></i></button>'; }
  function head(t, back, to) { return '<div class="sh-head">' + (back ? '<button class="tb" type="button" data-act="view" data-v="' + (to || 'menu') + '" aria-label="Назад">' + ico('back') + '</button>' : '') + '<h2>' + t + '</h2><button class="tb" type="button" data-act="close" aria-label="Закрыть">' + ico('x') + '</button></div>'; }
  function ovHTML() {
    var v = S.ui.view, h = '', pl = S.phase === 'play';
    if (v === 'menu') {
      h = '<div class="hero"><div class="mark">РУБЕЖИ</div><div class="tag">Пошаговая стратегия: армии, снабжение, осады и дипломатия.</div><div class="ver">Версия 15 · сеть торговли, чрезвычайные меры, генералы</div></div><div class="menu">';
      h += '<button class="btn primary" type="button" data-act="close">' + ico('play') + (pl ? 'Продолжить' : 'К выбору державы') + '</button>';
      if (hasSave()) h += '<button class="btn" type="button" data-act="load">' + ico('save') + 'Загрузить сохранение</button>';
      h += '<button class="btn" type="button" data-act="view" data-v="new">' + ico('refresh') + 'Новая игра</button>';
      if (pl) h += '<button class="btn" type="button" data-act="view" data-v="dip">' + ico('globe') + 'Дипломатия и связи</button><button class="btn" type="button" data-act="view" data-v="em">' + ico('shield') + 'Чрезвычайные меры</button><button class="btn" type="button" data-act="view" data-v="log">' + ico('log') + 'Журнал и итоги</button>';
      if (pl) h += '<button class="btn" type="button" data-act="view" data-v="gen">' + ico('star') + 'Генералы</button><button class="btn" type="button" data-act="view" data-v="tech">' + ico('flask') + 'Технологии</button>';
      h += '<button class="btn" type="button" data-act="view" data-v="hof">' + ico('flag') + 'Слава и награды</button>' + ((document.fullscreenEnabled || document.webkitFullscreenEnabled) ? '<button class="btn" type="button" data-act="fs">' + ico('fs') + 'Полный экран</button>' : '') + '<button class="btn" type="button" data-act="view" data-v="set">' + ico('gear') + 'Настройки</button><button class="btn" type="button" data-act="view" data-v="help">' + ico('help') + 'Как играть</button></div>';
    } else if (v === 'new') {
      h = head('Новая игра', true) + '<div class="sh-body">' +
        '<div class="fld"><span class="lbl">Размер карты</span>' + segH('np', [[30, 'Малая'], [42, 'Средняя'], [60, 'Большая'], [100, 'Огромная'], [260, 'Гигант']], ST.np) + '</div>' +
        '<div class="fld"><span class="lbl">Форма карты</span>' + segH('shape', [['auto', 'Авто'], ['tall', 'Вертикальная'], ['wide', 'Горизонтальная']], ST.shape) + '<small>Авто подбирает форму под экран: на телефоне в ландшафте карта будет широкой.</small></div>' + '<div class="fld"><span class="lbl">Число держав</span>' + segH('nc', [[4, '4'], [6, '6'], [8, '8'], [10, '10']], ST.nc) + '</div>' +
        '<div class="fld"><span class="lbl">Стартовый бонус</span>' + segH('boost', [[0, 'Нет'], [1, 'Малый'], [2, 'Большой']], ST.boost) + '<small>Бонус получают все державы поровну.</small></div>' +
        '<div class="fld"><span class="lbl">Мирный старт</span>' + segH('calm', [[0, 'Нет'], [15, '15 ходов'], [30, '30 ходов'], [999, 'Пока не начнёшь']], ST.calm) + '<small>Никто не объявляет войн, пока идёт мирный период. «Пока не начнёшь» — до твоей первой войны.</small></div>' +
        '<div class="fld"><span class="lbl">Условие победы</span>' + segH('vic', [['std', 'Обычное'], ['dom', 'Господство 55%'], ['pts', 'По очкам · 70 ходов']], ST.vic) + '<small>Обычное: завоевание, 3/4 карты или союз. Господство: кто первым возьмёт 55% провинций (может и соперник). По очкам: итог на 70-м ходу.</small></div>' + togH('nocap', 'Без лимита населения', 'Жители растут без предела') + togH('harsh', 'Тяжёлые потери', 'Больше гибнет солдат и мирных в боях и осадах') + '<div class="fld"><span class="lbl">Сложность ИИ</span>' + segH('ai', [['easy', 'Лёгкая'], ['normal', 'Обычная'], ['hard', 'Сложная']], ST.ai) + '</div>' +
        togH('seasons', 'Времена года', 'Сезоны меняют доход, марши и силу атаки') + togH('real', 'Реалистичный режим', 'Содержание армий, усталость от войны, износ, туман. Правила — в Настройки → Реализм.') +
        '<div class="fld"><span class="lbl">Сценарий</span>' + segH('scen', [['classic', 'Классика'], ['blocs', 'Два блока'], ['chaos', 'Все против всех'], ['peace', 'Золотой век']], ST.scen) + '<small>' + ({ classic: 'Случайные союзы и войны.', blocs: 'Карта делится на два лагеря: внутри союзы, между ними вражда и пограничные войны.', chaos: 'Все соседи воюют друг с другом с первого хода.', peace: 'Все в мире, торговля процветает, первые 20 ходов без войн.' }[ST.scen] || '') + '</small></div>' +
        '<div class="fld"><span class="lbl">Тип карты</span>' + segH('mapKind', [['seed', 'По зерну'], ['europe', 'Европа'], ['asia', 'Азия'], ['world', 'Весь мир']], mkUi() === 'euhist' ? 'europe' : mkUi()) + ((mkUi() === 'europe' || mkUi() === 'euhist') ? '<span class="lbl">Режим Европы</span>' + segH('mapKind', [['europe', 'Обычный'], ['euhist', 'Исторический 1914']], mkUi()) : '') + '<small>' + (mkUi() === 'euhist' ? 'Реальные державы 1914 года на карте Европы; провинции названы по историческим областям.' : mkUi() !== 'seed' ? 'Настоящие очертания материков. Зерно меняет только границы провинций.' : 'Случайная карта по зерну.') + '</small></div>' +
        '<div class="sec"><h3 class="h">Специальные настройки</h3>' + togH('popK', 'Население в тысячах', 'Вместо 100 — «100к», большие числа — «млн»') + togH('gStat', 'Глобальные итоги', 'Сколько погибло в боях и умерло от голода, эпидемий и смут (в «Итогах»)') + '<div class="fld"><span class="lbl">Темп роста населения</span>' + segH('growSp', [['slow', 'Медленный'], ['normal', 'Как раньше'], ['fast', 'Быстрый']], ST.growSp) + '</div>' + togH('villSlow', 'Деревни растут медленно', 'Деревни набирают жителей втрое медленнее') + '</div>' +
        '<div class="fld"><span class="lbl">Зерно карты</span><input type="text" id="seedIn" maxlength="20" placeholder="Пусто — случайная" value="' + esc(ST.seed) + '" autocomplete="off"><div class="row"><button class="btn sm" type="button" data-act="daily">' + ico('cal') + 'Карта дня</button></div><small>Одно зерно — одна и та же карта. «Карта дня» одинакова у всех в этот день.</small></div></div>' +
        '<div class="sh-foot"><button class="btn" type="button" data-act="view" data-v="menu">Назад</button><button class="btn primary lg" type="button" data-act="gen">Создать карту</button></div>';
    } else if (v === 'set') {
      h = setHtml();
    } else if (v === 'dip') {
      h = head('Дипломатия', true) + '<div class="sh-body">';
      var offs = S.offers.filter(validOffer);
      if (offs.length) {
        h += '<div class="sec"><h3 class="h">Предложения</h3><div class="dips">' + offs.map(function (o) { return '<div class="dip"><div class="hd">' + flagH(o.from) + '<span class="nm">' + CNAMES[o.from] + '</span></div><p>' + offerText(o) + '.</p><div class="row"><button class="btn sm primary" type="button" data-act="dip" data-k="acc" data-c="' + o.from + '">' + (o.kind === 'blockade' ? 'Снять блокаду' : 'Принять') + '</button><button class="btn sm" type="button" data-act="dip" data-k="dec" data-c="' + o.from + '">Отклонить</button></div></div>'; }).join('') + '</div></div>';
      }
      (function () { var ni = netInfo(), ci = ni.of[S.player]; h += '<button class="btn" type="button" data-act="view" data-v="net">' + ico('globe') + 'Сеть связей и торговые сети</button>' + (ci >= 0 ? '<p class="note">Твоя торговая сеть: ' + ni.comps[ci].length + ' держ.' + (ni.bonus[S.player] ? ', бонус +' + ni.bonus[S.player] + ' зол. в ход' : ', для бонуса нужны ещё партнёры') + '.</p>' : ''); })();
      h += tradeHtml();
      h += '<div class="sec"><h3 class="h">Репутация</h3><p class="note">Агрессия: ' + r0(S.inf[S.player]) + ' · санкции −' + r0((1 - sanc(S.player)) * 100) + '% дохода. Захваты и внезапные войны её повышают, со временем она падает. При высокой агрессии торговые партнёры рвут договоры, присылают ультиматумы и собирают коалицию.</p></div>';
      var rbs = S.provs.filter(function (q) { return q.reb > 0 && q.owner >= 0; });
      if (rbs.length) {
        h += '<div class="sec"><h3 class="h">Мятежники</h3><p class="note">Анархия: повстанцы не признают власти, из мятежных земель бегут люди — в том числе через границы.</p><div class="dips">' + rbs.map(function (q) {
          var mineP = q.owner === S.player;
          return '<div class="dip"><div class="hd">' + flagH(q.owner) + '<span class="nm">' + esc(q.name) + ' · ' + (q.reb === 2 ? 'восстание' : 'слабый бунт') + '</span></div><p>Держава ' + CNAMES[q.owner] + ' · сила ' + popFmt(q.rebS) + ' · ' + q.rebAge + ' ход.</p>' + (mineP ? '<div class="row"><button class="btn sm" type="button" data-act="rebDeal" data-d="' + q.id + '" data-kind="pay">Выкупить (' + Math.ceil(10 + q.rebS * (q.reb === 2 ? 1.5 : 1)) + ' зол.)</button><button class="btn sm" type="button" data-act="rebDeal" data-d="' + q.id + '" data-kind="aut">Дать автономию</button></div>' : '') + '</div>';
        }).join('') + '</div></div>';
      }
      var dF = S.ui.dipF || 'all', nbSet = {};
      owned(S.player).forEach(function (q) { q.nb.forEach(function (n) { var z = S.provs[n]; if (z.owner >= 0 && z.owner !== S.player) nbSet[z.owner] = 1; }); });
      h += '<div class="sec"><h3 class="h">Державы</h3><div class="seg filt" role="group">' + [['all', 'Все'], ['nb', 'Соседи'], ['war', 'Война'], ['ally', 'Союз'], ['trade', 'Торговля']].map(function (x) { return '<button type="button" data-act="dipf" data-v="' + x[0] + '" aria-pressed="' + (dF === x[0]) + '">' + x[1] + '</button>'; }).join('') + '</div><div class="dips">';
      for (var c = 0; c < NC; c++) {
        if (c === S.player) continue;
        if (dF === 'nb' && !nbSet[c]) continue; if (dF === 'war' && S.rel[S.player][c] !== 'w') continue; if (dF === 'ally' && S.rel[S.player][c] !== 'a') continue; if (dF === 'trade' && !S.trade[S.player][c]) continue;
        var alive = owned(c).length > 0, r = S.rel[S.player][c], op = S.op[S.player][c];
        h += '<div class="dip' + (alive ? '' : ' dead') + '"><div class="hd">' + flagH(c) + '<span class="nm">' + CNAMES[c] + '</span><span class="chip ' + (r === 'w' ? 'bad' : r === 'a' ? 'good' : '') + '">' + RELN[r] + '</span>' + tradeChip(c) + '</div>';
        if (alive) h += '<div class="op" title="Отношение"><i style="left:' + ((op + 100) / 2) + '%"></i></div><div class="sub">Провинций ' + owned(c).length + ' · войск ' + troopsOf(c) + ' · отношение ' + signed(op) + (r === 'p' || r === 'a' ? (cbReason(S.player, c) ? ' · повод: ' + cbText(cbReason(S.player, c)) : '') : '') + '</div><div class="row">' + dipBtns(c, true) + '</div>'; else h += '<div class="sub">Держава пала.</div>';
        h += '</div>';
      }
      h += '</div></div><div class="sec"><h3 class="h">Границы на карте</h3><div class="legend"><i class="w"></i><span>Война</span><i class="a"></i><span>Союз: проход и снабжение</span><i class="p"></i><span>Мир: проход закрыт</span><i class="o"></i><span>Внутренняя граница провинций</span><i class="sea"></i><span>Граница морских зон (пунктир)</span></div></div></div>';
    } else if (v === 'net' && pl) {
      h = netHtml();
    } else if (v === 'em' && pl) {
      h = emHtml();
    } else if (v === 'spy' && pl) {
      h = spyHtml();
    } else if (v === 'hof') {
      h = hofHtml();
    } else if (v === 'mis' && pl) {
      h = misHtml();
    } else if (v === 'device') {
      h = '<div class="hero"><div class="mark">РУБЕЖИ</div><div class="tag">Где ты играешь? Подберу удобный интерфейс. Потом это можно поменять в Настройках.</div></div><div class="menu"><button class="btn primary" type="button" data-act="devpick" data-v="phone">' + ico('select') + 'Телефон (играть горизонтально)</button><button class="btn primary" type="button" data-act="devpick" data-v="pc">' + ico('fs') + 'Компьютер</button></div>';
    } else if (v === 'codes') {
      h = head('Коды', true, 'help') + '<div class="sh-body"><div class="fld"><span class="lbl">Введи код</span><input type="text" id="codeIn" maxlength="16" placeholder="Код" autocomplete="off"><div class="row"><button class="btn primary" type="button" data-act="codego">Ввести</button>' + (ST.dev ? '<button class="btn" type="button" data-act="view" data-v="dev">' + ico('gear') + 'Режим разработчика</button><button class="btn" type="button" data-act="devoff">Выключить</button>' : '') + '</div><small>' + (ST.dev ? 'Режим разработчика включён.' : 'Нужный код знаешь только ты.') + '</small></div></div>';
    } else if (v === 'dev') {
      h = devHtml();
    } else if (v === 'ach') {
      h = achHtml();
    } else if (v === 'tech' && pl) {
      h = head('Технологии и законы', true) + techHtml();
    } else if (v === 'ev' && pl && S.pend) {
      h = evHtml();
    } else if (v === 'log') {
      var lF = S.ui.logF || 'all', lg = S.chron.filter(function (e) { return lF === 'all' || (lF === 'sys' ? (e.k !== 'battle' && e.k !== 'capture' && e.k !== 'dipl') : e.k === lF); });
      h = head('Журнал', true) + '<div class="sh-body"><div class="seg filt" role="group">' + [['all', 'Все'], ['battle', 'Бои'], ['capture', 'Захваты'], ['dipl', 'Дипломатия'], ['sys', 'Прочее']].map(function (x) { return '<button type="button" data-act="logf" data-v="' + x[0] + '" aria-pressed="' + (lF === x[0]) + '">' + x[1] + '</button>'; }).join('') + '</div><ul class="logl">' + (lg.length ? lg.slice().reverse().map(function (e) {
        var inner = '<b class="tn">' + e.r + '</b><i class="dt ' + e.k + '"></i><span>' + esc(e.t) + '</span>';
        return '<li>' + (e.rep ? '<button class="lrow' + (e.m ? ' mine' : '') + '" type="button" data-act="rep" data-id="' + e.rep + '">' + inner + '</button>' : e.p >= 0 ? '<button class="lrow' + (e.m ? ' mine' : '') + '" type="button" data-act="goto" data-id="' + e.p + '">' + inner + '</button>' : '<div class="lrow' + (e.m ? ' mine' : '') + '">' + inner + '</div>') + '</li>';
      }).join('') : '<li class="note">Пока пусто.</li>') + '</ul></div>';
    } else if (v === 'gen') {
      h = head('Генералы', true) + '<div class="sh-body"><p class="note">Генерал получает опыт в боях и осадах. Каждый уровень усиливает навык. Один генерал уверенно ведёт ограниченное число людей.</p><div class="dips">';
      var gl = S.gens.filter(function (g) { return g.owner === S.player; }).sort(function (x, y) { return y.lvl - x.lvl; });
      h += gl.length ? gl.map(function (g) {
        var ar = S.armies.filter(function (x) { return x.gen === g.id; })[0];
        return '<div class="dip"><div class="hd"><span class="nm">' + esc(g.name) + '</span><span class="chip">ур. ' + g.lvl + '</span><span class="chip">' + traitName(g) + '</span></div><div class="bar"><i class="acc" style="width:' + clamp(g.xp / (g.lvl * 40) * 100, 2, 100) + '%"></i></div><div class="sk">' + SKK.map(function (k) { return '<span title="' + SKD[k] + '">' + SKN[k] + '</span><i>' + (g.sk[k] ? new Array(g.sk[k] + 1).join('●') : '–') + '</i>'; }).join('') + '</div><div class="sub">' + (ar ? 'Ведёт армию №' + ar.id + ' (' + U(ar.troops) + ' див., лимит ' + U(cmdLimit(g)) + ')' : 'В резерве. Назначь на армии кнопкой «Сменить генерала».') + '</div>' + (ar ? '<div class="row"><button class="btn sm" type="button" data-act="sel" data-id="' + ar.id + '">К армии</button></div>' : '') + '</div>';
      }).join('') : '<p class="note">Генералов нет.</p>';
      h += '</div></div>';
    } else if (v === 'rep') {
      var rp = S.reports.filter(function (x) { return x.id === S.ui.rep; })[0];
      h = head('Сводка боя', true);
      if (!rp) h += '<div class="sh-body"><p class="note">Сводка устарела и удалена.</p></div>';
      else {
        var P = S.provs[rp.pid], A = rp.att, D = rp.def, OT = { held: 'Бой продолжается', repulse: 'Атака выдохлась, наступление прекращено', win: 'Оборона прорвана', retreat: 'Оборона прорвана, противник отступил', breakout: 'Прорыв из окружения с потерями', surrender: 'Окружённая армия капитулировала', destroyed: 'Армия уничтожена' };
        h += '<div class="sh-body rep"><div><div class="title">' + esc(P.name) + '</div><div class="sub">Ход ' + rp.r + ' · ' + (rp.attWins ? 'победа нападающего' : 'атака отбита') + '</div></div>';
        h += '<table><tr><th></th><th>Атака</th><th>Оборона</th></tr><tr><td>Держава</td><td>' + CNAMES[A.owner] + '</td><td>' + CNAMES[D.owner] + '</td></tr><tr><td>Генерал</td><td>' + esc(A.gen || '—') + '</td><td>' + esc(D.gen || '—') + '</td></tr><tr><td>Людей</td><td>' + fmtU(A.t0) + ' → ' + fmtU(A.t1) + '</td><td>' + fmtU(D.t0) + ' → ' + fmtU(D.t1) + '</td></tr><tr><td>Организация</td><td>' + A.o0 + ' → ' + A.o1 + '</td><td>' + D.o0 + ' → ' + D.o1 + '</td></tr><tr><td>Фланг / окопы</td><td>' + A.flank + ' арм.</td><td>' + D.dug + ' ур.</td></tr></table>';
        h += '<div><h4>Ход боя</h4><table><tr><th>Фаза</th><th>Орг. атаки</th><th>Орг. обороны</th></tr>' + rp.rounds.map(function (r) { return '<tr><td>' + r.ph + '</td><td>' + r.oa + '</td><td>' + r.od + '</td></tr>'; }).join('') + '</table></div>';
        h += '<div><h4>Почему так</h4><p class="note">' + (rp.reasons.length ? 'Решили: ' + rp.reasons.join(', ') + '.' : 'Явного преимущества не было, всё решили выдержка и удача.') + '</p><p class="note">Рельеф ×' + r1(rp.F.terrain) + ' · укрепления ×' + r1(rp.F.fort) + ' · снабжение ×' + r1(rp.F.supply[0]) + ' / ×' + r1(rp.F.supply[1]) + ' · командование ×' + r1(rp.F.general[0]) + ' / ×' + r1(rp.F.general[1]) + ' · фланг ×' + r1(rp.F.flank) + '.</p>' + (rp.pursuit ? '<p class="note">Преследование: −' + rp.pursuit + ' человек.</p>' : '') + '<p class="note"><b>' + OT[rp.outcome] + '.</b></p></div></div>';
      }
    } else if (v === 'end') {
      var over = S.phase === 'over', cur = S.ui.met || 0, st = S.stat, us = S.player, ranks = [];
      for (var cc = 0; cc < NC; cc++) ranks.push({ c: cc, s: scoreOf(cc) });
      ranks.sort(function (x, y) { return y.s - x.s; });
      h = (over ? '<div class="sh-head"><h2>Итоги</h2></div>' : head('Итоги и статистика', true)) + '<div class="sh-body">';
      h += '<div class="sec"><div class="verdict-big ' + (over ? (S.won ? 'verdict good' : 'verdict bad') : '') + '">' + (over ? (S.won ? (S.allied ? 'Победа союзом' : 'Победа') : 'Поражение') : 'Ход ' + S.round) + '</div><p class="note">' + (over ? esc(S.why) + '. ' : 'Игра продолжается. ') + 'Держава ' + CNAMES[us] + ' · ходов сыграно: ' + S.round + '.</p></div>';
      if (ST.gStat) { var G = S.glob || {}, gT = (G.bat || 0) + (G.war || 0) + (G.hun || 0) + (G.epi || 0) + (G.uns || 0), gP = 0; S.provs.forEach(function (p) { if (!p.sea && p.owner >= 0) gP += p.pop; });
        h += '<div class="sec"><h3 class="h">Мир: глобальные итоги</h3><table class="tbl"><tr><td>Население мира</td><td>' + popFmt(gP) + '</td></tr><tr><td>Погибло в боях (солдаты)</td><td>' + popFmt(G.bat || 0) + '</td></tr><tr><td>Погибло мирных от войны и осад</td><td>' + popFmt(G.war || 0) + '</td></tr><tr><td>Умерло от голода и лишений</td><td>' + popFmt(G.hun || 0) + '</td></tr><tr><td>Умерло от эпидемий</td><td>' + popFmt(G.epi || 0) + '</td></tr><tr><td>Погибло в смутах и репрессиях</td><td>' + popFmt(G.uns || 0) + '</td></tr><tr><td>Беженцев (нелегальных)</td><td>' + popFmt(G.ref || 0) + '</td></tr><tr><td><b>Всего погибло</b></td><td><b>' + popFmt(gT) + '</b></td></tr></table></div>'; }
      h += '<div class="sec"><h3 class="h">Рейтинг держав</h3><table class="tbl"><tr><th>#</th><th>Держава</th><th>Пров.</th><th>Нас.</th><th>Войск</th><th>Пром.</th><th>Очки</th></tr>' + ranks.map(function (r, i) {
        var c = r.c, dead = !owned(c).length;
        return '<tr class="' + (c === us ? 'me' : '') + (dead ? ' dead' : '') + '"><td>' + (i + 1) + '</td><td>' + flagH(c) + CNAMES[c] + (dead ? ' ✕' : '') + '</td><td>' + owned(c).length + '</td><td>' + popFmt(popOf(c)) + '</td><td>' + U(troopsOf(c)) + '</td><td>' + r1(indOut(c) + civOut(c)) + '</td><td>' + r.s + '</td></tr>';
      }).join('') + '</table></div>';
      h += '<div class="sec"><h3 class="h">Динамика по ходам</h3><div class="seg">' + ['Провинции', 'Население', 'Войска', 'Промышл.', 'Золото'].map(function (n, i) { return '<button type="button" data-act="met" data-v="' + i + '" aria-pressed="' + (cur === i) + '">' + n + '</button>'; }).join('') + '</div>' + chartSVG(cur) + '<div class="lgd">' + ranks.map(function (r) { return '<span>' + flagH(r.c) + CNAMES[r.c] + '</span>'; }).join('') + '</div></div>';
      function pct(a, b) { if (!a) return b > 0 ? '<span class="pos">новое</span>' : '—'; var v = Math.round((b - a) / a * 100); return '<span class="' + (v >= 0 ? 'pos' : 'neg') + '">' + (v >= 0 ? '+' : '−') + Math.abs(v) + '%</span>'; }
      var h0 = S.hist.length ? S.hist[0].v : null, nowV = function (c) { return [owned(c).length, popOf(c), troopsOf(c), indOut(c) + civOut(c), S.gold[c]]; };
      if (h0) {
        h += '<div class="sec"><h3 class="h">Рост с начала игры</h3><table class="tbl"><tr><th></th><th>Держава</th><th>Пров.</th><th>Нас.</th><th>Войска</th><th>Пром.</th><th>Золото</th></tr>' + ranks.map(function (r, i) {
          var c = r.c, a0 = h0[c], b0 = nowV(c);
          return '<tr class="' + (c === us ? 'me' : '') + (!owned(c).length ? ' dead' : '') + '"><td>' + (i + 1) + '</td><td>' + flagH(c) + CNAMES[c] + '</td>' + [0, 1, 2, 3, 4].map(function (k) { return '<td>' + pct(a0[k], b0[k]) + '</td>'; }).join('') + '</tr>';
        }).join('') + '</table></div>';
      }
      h += '<div class="sec"><h3 class="h">Твоя статистика</h3><div class="stat-grid">' + [['Сражений', st.bat[us]], ['Рост провинций', h0 ? pct(h0[us][0], owned(us).length) : '—'], ['Рост населения', h0 ? pct(h0[us][1], popOf(us)) : '—'], ['Рост промышленности', h0 ? pct(h0[us][3], indOut(us) + civOut(us)) : '—'], ['Убито врагов (див.)', fmtU(st.kills[us])], ['Потеряно (див.)', fmtU(st.lost[us])], ['Взято провинций', st.caps[us]], ['Потеряно провинций', st.capL[us]], ['Заводов построено', st.built[us]], ['Заводов разрушено', st.dest[us]], ['Урон промышленности', r1(st.dmg[us])]].map(function (x) { return '<div><b>' + x[1] + '</b><span>' + x[0] + '</span></div>'; }).join('') + '</div></div>';
      h += '<div class="sec"><h3 class="h">Ключевые события</h3><ul class="logl">' + (S.keyEv.length ? S.keyEv.slice(-14).reverse().map(function (e) { return '<li><div class="lrow"><b class="tn">' + e.r + '</b><i class="dt dipl"></i><span>' + esc(e.t) + '</span></div></li>'; }).join('') : '<li class="note">Пока ничего особенного.</li>') + '</ul></div></div>';
      h += '<div class="sh-foot">' + (over ? (S.won ? '<button class="btn" type="button" data-act="cont">Продолжить игру</button>' : '') : '<button class="btn" type="button" data-act="close">К игре</button>') + (over ? '<button class="btn primary lg" type="button" data-act="new">Новая игра</button>' : '') + '</div>';
    } else if (v === 'help') {
      h = head('<span data-act="hsec">Как играть</span>', true) + '<div class="sh-body"><ol class="help">' +
        '<li><b>Приказы.</b> Нажми на свою армию, затем на любую провинцию: армия идёт по провинциям, а не свободно. Вражескую провинцию армия начинает осаждать.</li>' +
        '<li><b>Фронтовые бои.</b> Армия не заходит в провинцию с врагом, а стоит на границе и бьёт каждый ход — линия фронта горит красным. «Натиск» ломает оборону быстро, но дорого. «Измотать» — медленный бой на износ с малыми потерями. Когда оборона рушится, она отступает, а твоя армия входит. Выдохлась (орг. ниже 20%) — наступление прекращается. Остановить бой можно в любой момент.</li><li><b>Моря и острова.</b> Море поделено на огромные зоны. Армия садится на корабли в любой береговой провинции и плывёт по зонам быстрее, чем идёт по суше (приказ — нажми на берег или зону). Боёв на море нет, но высадка на вражеский берег на 20% слабее, а в море армия теряет по 3% в ход.</li><li><b>Промышленность.</b> Военные заводы дают технику, гражданские — золото и рост населения. Техника нужна для найма, без неё армии слабее. «Развить население» повышает предел и рост жителей. Бои, осады и захват в провинции с заводами их ломают; чини за золото.</li><li><b>Дипломатия.</b> Захваты и внезапные войны растят агрессию: торговые партнёры рвут договоры, соседи шлют ультиматумы и собирают коалицию. Союзники просят о помощи и сами вступают в войны. Можно заключить мир с контрибуцией.</li><li><b>Народы и меньшинства.</b> В каждой провинции есть национальный состав (например, 95% одного народа и 5% другого). Захваченные земли полны чужого народа и бунтуют. Политика: ассимиляция (платно, безвредно), репрессии (подавляют бунт, растят агрессию) или депортация (быстро, но очень громко). Угнетаемый народ даёт его родине повод для войны.</li><li><b>Повод для войны.</b> Война без повода — +8 агрессии и осуждение всех держав. Поводы: защита соотечественников, возврат исконных земель, агрессор угрожает миру или «найти повод» за 20 зол. (3 хода).</li><li><b>Режимы.</b> «Без лимита населения» и «Тяжёлые потери» включаются в настройках и новой игре.</li><li><b>Технологии (R).</b> Три ветки по четыре ступени: армия, экономика, общество. Очки исследований дают гражданские заводы, развитие, города и столица; школы ускоряют всё. Можно ускорить за золото. ИИ тоже развивается.</li><li><b>События.</b> Иногда приходит решение с выбором: ярмарка, ветераны, беженцы, чужие агенты. Закрыть окно значит отказаться. Слой «Народы» (L) подсвечивает недовольство.</li><li><b>Законы.</b> Призыв, экономика и порядок: у каждого три варианта со своими плюсами и минусами (в окне технологий). <b>Условия победы</b> выбираются в новой игре. <b>Достижения</b> есть в главном меню.</li><li><b>Телефон.</b> Игра работает и в вертикальном, и в горизонтальном режиме. Быстрые действия (дипломатия, наука, генералы, журнал, итоги) вынесены в панель с подписями. Кнопка со схемой панели (или P) прячет боковую панель: карта занимает весь экран, а «Конец хода» плавает в углу. Нажми на счётчики сверху: золото и техника открывают слой промышленности, войска показывают армии, провинции открывают итоги. «Форма карты» в новой игре подбирается под экран.</li><li><b>Тема «Пергамент»</b> в настройках.</li><li><b>Числа армий</b> показаны в дивизиях (1 див. = 10 бойцов).</li>' +
        '<li><b>Осада.</b> Сначала падает гарнизон, затем идёт оккупация. Столицу брать дольше всего.</li>' +
        '<li><b>Снабжение.</b> Города и столицы питают соседние провинции державы. Армия без снабжения теряет людей и слабее бьёт.</li>' +
        '<li><b>Найм.</b> Выбери свою провинцию со снабжением и нажми «Набрать армию». Деньги идут от населения и земель.</li>' +
        '<li><b>Фронты и группы.</b> Слой «Фронты» показывает баланс сил на каждом участке. Кнопка выбора нескольких армий позволяет вести их общим приказом, синхронно. Стойка «Оборона» окапывает армию, «Резерв» держит её в тылу.</li><li><b>Генералы и склады.</b> Генерал растёт в боях и усиливает армию. Склад (12 зол.) расширяет снабжение. Окружённая армия может прорваться или капитулировать.</li><li><b>Дипломатия.</b> Мир, союз, торговля и подарки. При мире чужие земли закрыты для прохода.</li>' +
        '<li><b>Налоги и ресурсы.</b> В панели державы выбери налоги: высокие дают золото, но злят людей и тормозят рост. Провинции с ресурсами дают бонусы: зерно ускоряет рост, железо добавляет технику, золото и пряности добавляют доход. Их значки видны на карте.</li>' +
        '<li><b>Разведка.</b> В Дипломатии у каждой державы есть кнопка «Разведка»: подстрекательство, диверсия, кража технологий, компромат и обзор армий при тумане. Провал портит отношения и растит агрессию. ИИ тоже шпионит.</li>' +
        '<li><b>Пираты.</b> Иногда пираты перерезают торговый путь в морской зоне. Отправь туда армию или откупись в Дипломатии.</li>' +
        '<li><b>Задания и зал славы.</b> В меню есть три активных задания с наградами. Все законченные партии сохраняются в зале славы. Сценарии старта и «Карта дня» выбираются в «Новая игра».</li>' +
        '<li><b>Миникарта и музыка.</b> Миникарта в углу: тапни, чтобы перейти в нужное место. Музыку и оттенок времён года можно включить в Настройках.</li>' +
        '<li><b>Реалистичный режим.</b> Включается в Настройки → Реализм. Армии стоят денег (за границей дороже), набор и потери бьют по населению, долгая война утомляет страну и режет доход, зима и горы на чужой земле косят солдат, мир нельзя просить первые 3 хода войны. Каждое правило можно отключить отдельно. Условия одинаковы для ИИ.</li>' +
        '<li><b>Торговля и блокада.</b> Торговый договор даёт золото, пока по морю ходят корабли: путь идёт через морские зоны, чем он длиннее — тем больше дохода. Выведи армию в море и нажми «Блокада»: все торговые пути через эту зону будут перерезаны. Страны, которые теряют доход, сначала злятся, потом ставят ультиматум, а если блокаду не снять — объявляют войну.</li><li><b>Сезоны.</b> Лето усиливает атаку, зима — оборону, осень даёт больше денег.</li></ol>' +
        '<li><b>Сеть связей.</b> В Дипломатии открой карту отношений: война, союзы, симпатии и торговые пути между всеми державами. Три и больше державы, связанные торговыми договорами, образуют сеть: каждый член получает золото, а отношения внутри неё растут.</li>' +
        '<li><b>Чрезвычайные меры.</b> Во время войны можно ввести военное положение, мобилизацию, выжженную землю или военную экономику. Они дают большие временные бонусы, но бьют по населению, доходу и спокойствию. ИИ тоже ими пользуется.</li>' +
        '<li><b>Генералы.</b> У каждой армии есть генерал: звёзды на жетоне показывают его уровень. Новые армии получают генерала сразу.</li>' +
        '<li><b>Деление и слияние армий.</b> «Разделить» открывает ползунок: сколько дивизий отделить (есть кнопка «Половина»). «Объединить» собирает армии одной провинции; в режиме выбора нескольких армий объединяются только выбранные. Во время фронтового боя делить нельзя.</li>' +
        '<li><b>Типы карт.</b> В «Новая игра» можно взять случайную карту по зерну или реальные очертания: Европа (в том числе исторический режим 1914), Азия, Весь мир. Размер «Гигант» — самая большая карта, строится несколько секунд.</li>' +
        '<div class="sec"><h3 class="h">Клавиши</h3><div class="keys"><kbd>Пробел</kbd><span>Конец хода</span><kbd>N</kbd><span>Следующая армия</span><kbd>D</kbd><span>Дипломатия</span><kbd>J</kbd><span>Журнал</span><kbd>+ −</kbd><span>Масштаб</span><kbd>0</kbd><span>Вся карта</span><kbd>F</kbd><span>Полный экран</span><kbd>M</kbd><span>Выбор нескольких армий</span><kbd>L</kbd><span>Слой карты</span><kbd>1 2 3</kbd><span>Группы</span><kbd>Z</kbd><span>Отменить последний приказ</span><kbd>S</kbd><span>Разделить армию</span><kbd>U</kbd><span>Объединить армии провинции</span><kbd>Esc</kbd><span>Закрыть / снять выбор</span></div></div>' + (ST.codeBtn ? '<div class="sec"><button class="btn" type="button" data-act="view" data-v="codes">' + ico('star') + 'Коды</button></div>' : '') + '</div>';
    }
    var VG = [[['dip', 'Дипломатия'], ['net', 'Связи']], [['log', 'Журнал'], ['end', 'Итоги']], [['hof', 'Зал славы'], ['ach', 'Достижения'], ['mis', 'Задания']]];
    VG.forEach(function (g) {
      if (!g.some(function (x) { return x[0] === v; })) return;
      var tabs = g.filter(function (x) { return pl || x[0] === 'hof' || x[0] === 'ach'; }), i = h.indexOf('</div>');
      if (tabs.length > 1 && i > 0) h = h.slice(0, i + 6) + '<div class="vtabs">' + segH('vtab', tabs, v).replace(/data-act="seg" data-k="vtab" /g, 'data-act="view" ') + '</div>' + h.slice(i + 6);
    });
    return h;
  }
  function chartSVG(m) {
    var Hh = S.hist;
    if (Hh.length < 2) return '<p class="note">Данных пока мало: сыграй ещё несколько ходов.</p>';
    var wv = 320, hv = 150, pl = 34, pb = 16, pt = 8, pr = 8, max = 1, c, i;
    Hh.forEach(function (e) { e.v.forEach(function (r) { if (r[m] > max) max = r[m]; }); });
    var r0v = Hh[0].r, r1v = Hh[Hh.length - 1].r, span = Math.max(1, r1v - r0v);
    function X(r) { return pl + (r - r0v) / span * (wv - pl - pr); }
    function Y(v) { return pt + (1 - v / max) * (hv - pt - pb); }
    var s = '<svg class="chart" viewBox="0 0 ' + wv + ' ' + hv + '" role="img" aria-label="График">';
    [0, 0.5, 1].forEach(function (f) { var yy = Y(max * f); s += '<line x1="' + pl + '" x2="' + (wv - pr) + '" y1="' + yy + '" y2="' + yy + '" stroke="currentColor" stroke-opacity="0.15" stroke-width="1"/><text x="' + (pl - 4) + '" y="' + (yy + 3) + '" text-anchor="end" fill="currentColor" fill-opacity="0.6" stroke="none" font-size="9">' + (m === 3 ? r1(max * f) : m === 2 ? Math.round(max * f / 10) : Math.round(max * f)) + '</text>'; });
    s += '<text x="' + pl + '" y="' + (hv - 3) + '" fill="currentColor" fill-opacity="0.6" stroke="none" font-size="9">ход ' + r0v + '</text><text x="' + (wv - pr) + '" y="' + (hv - 3) + '" text-anchor="end" fill="currentColor" fill-opacity="0.6" stroke="none" font-size="9">ход ' + r1v + '</text>';
    for (c = 0; c < NC; c++) {
      var pts = '';
      for (i = 0; i < Hh.length; i++) pts += (i ? ' ' : '') + r1(X(Hh[i].r)) + ',' + r1(Y(Hh[i].v[c][m]));
      s += '<polyline points="' + pts + '" fill="none" stroke="' + rgb(COL[c], 1.15) + '" stroke-width="' + (c === S.player ? 2.8 : 1.5) + '" stroke-linejoin="round" stroke-linecap="round"/>';
    }
    return s + '</svg>';
  }
  function renderOverlay() {
    var ov = $('ov'), v = S.ui.view;
    ov.hidden = !v;
    if (v) { var keep = $('sheet').querySelector('.sh-body'), st = keep ? keep.scrollTop : 0; $('sheet').innerHTML = ovHTML(); var nb = $('sheet').querySelector('.sh-body'); if (nb) nb.scrollTop = st; }
  }
  function openView(v) { if (!S) return; if (v === 'dip' && S.phase === 'play') hint('dip', 'у каждой державы своё отношение. Мир закрывает проход, союз открывает его, повод к войне даёт право атаковать без штрафа к репутации.'); var ch = S.ui.view !== v; S.ui.view = v; S.ui.emC = ''; renderOverlay(); if (ch) { var sb0 = $('sheet').querySelector('.sh-body'); if (sb0) sb0.scrollTop = 0; } }
  function closeView() { if (!S) return; if (S.ui.view === 'ev' && S.pend) { var li = EVD[S.pend.e].o.length - 1; S.ui.view = null; resolveEv(li); return; } S.ui.view = null; renderOverlay(); }
  function render() {
    if (!S) return;
    if (ST.dev && ST.devGold && S.phase === 'play' && S.player >= 0) S.gold[S.player] = Math.max(S.gold[S.player], 99999);
    computeFronts(); updateHud(); renderPanel(); renderOverlay();
    try { stage.classList.toggle('emg', S.phase === 'play' && emAny(S.player)); } catch (e) { /* ignore */ }
    rasterDirty = true; DVER++;
    if (!ANIM) draw();
  }
