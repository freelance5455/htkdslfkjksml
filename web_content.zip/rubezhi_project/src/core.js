  var NP = 42, NC = 6, MAP = null, S = null, gen = 0, ANIM = null;
  var $ = function (id) { return document.getElementById(id); };
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = (Math.random() * (i + 1)) | 0, t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  var R = Math.random;
  function rr(a, b) { return a + R() * (b - a); }
  function rp(arr) { return arr[(R() * arr.length) | 0]; }
  function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; var t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function hashSeed(s) { var h = 2166136261; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function rgb(c, k) { k = k || 1; return 'rgb(' + clamp(Math.round(c[0] * k), 0, 255) + ',' + clamp(Math.round(c[1] * k), 0, 255) + ',' + clamp(Math.round(c[2] * k), 0, 255) + ')'; }

  /* ---------- icons ---------- */
  var IC = {
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    fs: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    fsx: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.2 3 3.2 15 0 18M12 3c-3.2 3-3.2 15 0 18"/>',
    log: '<path d="M6 3.5h12v17H6zM9 8.5h6M9 12h6M9 15.5h3.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    fit: '<circle cx="12" cy="12" r="5"/><path d="M12 2.5v4M12 17.5v4M2.5 12h4M17.5 12h4"/>',
    coin: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5v9M9.2 10.2c0-1.1 1.2-1.8 2.8-1.8s2.8.7 2.8 1.8c0 2.800-5.600 1.400-5.600 4.200 0 1.100 1.200 1.800 2.800 1.800s2.800-.7 2.800-1.800"/>',
    people: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.500 2.700-6 6-6s6 2.500 6 6M16 5.200a3 3 0 010 5.600M18 14.400c2 .8 3 2.700 3 5.600"/>',
    sword: '<path d="M14.500 5.500L19.500 4.500 18.500 9.500 9 19l-4-4zM5 19l-2.500 2.500M7 13l4 4"/>',
    flag: '<path d="M5 21V4M5 5h12l-2.500 4 2.500 4H5"/>',
    next: '<path d="M5 12h13M12.500 6l6 6-6 6"/>',
    check: '<path d="M5 12.500l4.500 4.500L19 7.500"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.500v3M12 18.500v3M2.500 12h3M18.500 12h3M5.300 5.300l2.100 2.100M16.600 16.600l2.100 2.100M5.300 18.700l2.100-2.100M16.600 7.400l2.100-2.100"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.500 9.500a2.500 2.500 0 115 0c0 1.700-2.500 2-2.500 4M12 17h.01"/>',
    back: '<path d="M15 5l-7 7 7 7"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/>',
    pin: '<path d="M12 21s7-6.500 7-12a7 7 0 10-14 0c0 5.500 7 12 7 12z"/><circle cx="12" cy="9" r="2.500"/>',
    castle: '<path d="M4 21V8l3 2V6l3 2V4h4v4l3-2v4l3-2v13zM10 21v-5h4v5"/>',
    play: '<path d="M7 4.500l12 7.500-12 7.500z"/>',
    save: '<path d="M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6"/>',
    plusc: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
    merge: '<path d="M6 4v5c0 3 6 3 6 6v5M18 4v5c0 3-6 3-6 6"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5zM3 12.500l9 5 9-5M3 17l9 5 9-5"/>',
    select: '<rect x="4" y="4" width="16" height="16" rx="2.500"/><path d="M8.500 12l2.500 2.500 4.500-5"/>',
    star: '<path d="M12 3l2.700 5.500 6 .9-4.400 4.200 1 6-5.300-2.800-5.300 2.800 1-6L3.300 9.400l6-.9z"/>',
    flask: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3M8 14h8"/>',
    sound: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M18.500 6.500a8 8 0 0 1 0 11"/>',
    map: '<path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z"/><path d="M9 4v14M15 6v14"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    cal: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/>',
    panel: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M15 4v16"/>',
    refresh: '<path d="M20 11a8 8 0 00-14.500-4M4 4v3.500h3.500M4 13a8 8 0 0014.500 4M20 20v-3.500h-3.500"/>',
    anchor: '<circle cx="12" cy="5" r="2"/><path d="M12 7v14M8 11h8M5 14a7 7 0 0014 0"/>',
    warn: '<path d="M12 3.500l10 17.500H2z"/><path d="M12 10v5M12 18h.01"/>'
  };
  function ico(n) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + (IC[n] || '') + '</svg>'; }

