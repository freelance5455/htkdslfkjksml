  /* ---------- AI ---------- */
  function AIK() { return { easy: { min: 1.2 }, normal: { min: 0.9 }, hard: { min: 0.75 } }[ST.ai] || { min: 0.9 }; }
  function warEnemies(c) { var o = []; for (var x = 0; x < NC; x++) if (x !== c && owned(x).length && isWar(c, x)) o.push(x); return o; }
  function isFront(p, c) { return p.nb.some(function (n) { return isWar(c, S.provs[n].owner); }); }
  function threatTo(pid, c) {
    var t = 0, nb = S.provs[pid].nb;
    S.armies.forEach(function (a) { if (isWar(a.owner, c) && (a.prov === pid || nb.indexOf(a.prov) >= 0)) t += a.troops; });
    return t;
  }
  function aiTurn(c) {
    aiTax(c);
    var wars = warEnemies(c), tries = 0, reserve = 3 + Math.floor(upkeep(c) / 2), n = owned(c).length;
    while (tries++ < 3) {
      if (upkeep(c) >= income(c) * 0.55 || troopsOf(c) >= 140 + 22 * n) break;
      if (!wars.length && troopsOf(c) >= 90 + 12 * n) break;
      var cands = owned(c).filter(function (p) { return canRecruit(p, c) && S.gold[c] - recCostFor(SETT[p.set].rec) >= reserve; });
      if (!cands.length) break;
      cands.sort(function (a, b) {
        var sa = (isFront(a, c) ? 12 : 0) + threatTo(a.id, c) * 0.02 + a.set * 2 + a.pop * 0.05, sb = (isFront(b, c) ? 12 : 0) + threatTo(b.id, c) * 0.02 + b.set * 2 + b.pop * 0.05;
        return sb - sa;
      });
      recruit(cands[0]);
    }
    assignGenerals(c);
    if (S.gold[c] >= 26 && Math.random() < 0.45) aiIndustry(c);
    if (wars.length && S.gold[c] >= 40 && Math.random() < 0.5) {
      var fr = owned(c).filter(function (p) { return !p.depot && isFront(p, c) && !(p.occ > 0) && !p.besieged && p.set < 2; });
      if (fr.length) { var dp = fr[(Math.random() * fr.length) | 0]; dp.depot = true; S.gold[c] -= 12; computeSupply(); }
    }
    S.armies.filter(function (a) { return a.owner === c; }).sort(function (x, y) { return y.troops - x.troops; }).forEach(function (a) { aiArmy(a, c, wars); a.blk = !!(wars.length && S.provs[a.prov].sea && !a.route.length); });
  }
  function aiArmy(a, c, wars) {
    var p = S.provs[a.prov], k = AIK(), mineP = (p.owner === c || isAlly(c, p.owner));
    var keepE = a.eng && a.org >= 35 && a.prov === a.eng.from && hostileAt(a.eng.pid, c);
    a.route = []; a.stance = 'atk';
    if (keepE) { a.route = [a.eng.pid]; return; }
    if (p.sea && !wars.length && fallback(a)) return;
    var thr = threatTo(a.prov, c);
    if (thr > a.troops * 1.7 && !(p.capital && p.owner === c) && encircledSoon(a)) { if (fallback(a)) return; }
    if (a.org < 35 && mineP && p.sup) { a.stance = 'hold'; return; }
    if (isWar(c, p.owner) && !hostileAt(p.id, c) && threatTo(p.id, c) < a.troops * 1.3) return;
    if (!wars.length) { a.stance = 'hold'; return; }
    var dm = distMap(a.prov, c), best = -1, bs = 0, brat = 1, my = a.troops * (0.55 + 0.45 * a.org / 100);
    if (a.troops < 70) {
      var mate = null;
      S.armies.forEach(function (o) { if (o !== a && o.owner === c && o.troops > a.troops && dm.cost[o.prov] < 3.5 && (!mate || o.troops > mate.troops)) mate = o; });
      if (mate && mate.prov !== a.prov) { a.route = routeFrom(dm, a.prov, mate.prov) || []; return; }
    }
    S.provs.forEach(function (q) {
      if (q.id === a.prov || dm.cost[q.id] >= 1e9) return;
      var enemyOwned = isWar(c, q.owner), h = hostileAt(q.id, c);
      if (!enemyOwned && !h) return;
      var val = 3, defp = 0;
      if (enemyOwned) { val += 4 + (q.res >= 0 ? 3 : 0) + q.set * 3 + (q.capital ? 9 : 0) + q.pop * 0.06 + ((q.occ > 0 && q.occBy === c) ? 8 : 0); defp += q.garrison * 0.35 * defMultP(q); }
      else val += 6 + (q.res >= 0 ? 3 : 0) + q.set * 3 + (q.capital ? 8 : 0);
      if (h) defp += h.troops * (0.55 + 0.45 * h.org / 100) * TER[q.terrain].def * (enemyOwned ? fortOf(q) : 1);
      if (my < defp * k.min) return;
      var sc = val / (1 + dm.cost[q.id] * 0.8) * clamp(my / Math.max(10, defp), 0.8, 2);
      if (sc > bs) { bs = sc; best = q.id; brat = my / Math.max(10, defp); }
    });
    if (best >= 0) { a.route = routeFrom(dm, a.prov, best) || []; a.mode = brat >= 1.35 ? 'push' : 'grind'; return; }
    if (isFront(p, c) && mineP) { a.stance = 'hold'; return; }
    var tgt = -1, tc = 1e9;
    owned(c).forEach(function (q) { if (q.id !== a.prov && isFront(q, c) && dm.cost[q.id] < tc) { tc = dm.cost[q.id]; tgt = q.id; } });
    if (tgt >= 0) a.route = routeFrom(dm, a.prov, tgt) || [];
  }
  function encircledSoon(a) {
    var p = S.provs[a.prov], free = 0;
    p.nb.forEach(function (n) { var q = S.provs[n]; if (q.sea) { free += 2; return; } if ((q.owner === a.owner || isAlly(a.owner, q.owner)) && !hostileAt(n, a.owner)) free++; });
    return free <= 1;
  }
