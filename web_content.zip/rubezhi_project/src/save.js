  /* ---------- save / load ---------- */
  function saveGame() {
    if (!ST.autosave || !S || S.phase !== 'play') return;
    try {
      localStorage.setItem('rubezhi3.save', JSON.stringify({
        v: SAVE_VERSION, saveVersion: SAVE_VERSION, wide: WIDE, seed: S.seed, np: NP, nc: NC, round: S.round, player: S.player, gold: S.gold, alive: S.alive, aid: S.aid,
        provs: S.provs.map(function (p) { return [p.owner, p.terrain, p.set, p.pop, p.garrison, p.capital ? 1 : 0, Math.round(p.occ), p.occBy, p.depot ? 1 : 0, p.fac, Math.round(p.fd * 100), p.civ, p.dev, p.sea ? '' : ethSave(p), p.pol || 0, Math.round(p.unr || 0), p.reb || 0, Math.round(p.rebS || 0), p.rebAge || 0, p.crit || 0, p.aut || 0]; }),
        rel: S.rel.map(function (r) { return r.join(''); }), op: S.op.map(function (r) { return r.join(','); }), trade: S.trade.map(function (r) { return r.join(''); }),
        armies: S.armies.map(function (a) { return [a.owner, a.prov, a.troops, Math.round(a.org), a.route.join('.'), a.id, a.gen || 0, a.stance, a.dug, a.wait, a.mode, a.eng ? a.eng.pid : -1, a.eng ? a.eng.turns : 0, a.blk ? 1 : 0]; }),
        chron: S.chron.slice(-30), offers: S.offers, gens: S.gens, gid: S.gid,
        glob: S.glob, eq: S.eq, eqD: S.eqD, inf: S.inf, calm: S.calm, law: S.law, lawCd: S.lawCd, vic: S.vic, peaceRun: S.peaceRun, tech: S.tech.map(function (t) { return { done: t.done, cur: t.cur, prog: t.prog, bank: t.bank }; }), just: S.just, fabs: S.fabs, allyCd: S.allyCd, bcb: S.bcb, blk: S.blk, blkCd: S.blkCd, weary: S.weary, wsince: S.wsince, tax: S.tax, pir: S.pir, intel: S.intel, spyCd: S.spyCd, xs: S.xs, em: S.em, emCd: S.emCd, hist: S.hist.slice(-200), stat: S.stat, keyEv: S.keyEv.slice(-30), cont: S.cont
      }));
    } catch (e) { /* ignore */ }
  }
  var SAVE_VERSION = 11, SAVE_MIN = 6; // v11: saveVersion + MIG-миграции; новые миграции добавлять в MIG[<версия от>]
  var MIG = {
    10: function (d) { if (!d.glob) d.glob = { bat: 0, war: 0, hun: 0, epi: 0, uns: 0, ref: 0 }; }
  };
  function migrateSave(d) { if (!d || !(d.v >= SAVE_MIN)) return false; if (d.v > SAVE_VERSION) return false; while (d.v < SAVE_VERSION) { if (MIG[d.v]) MIG[d.v](d); d.v++; } return true; }
  function hasSave() { try { return !!localStorage.getItem('rubezhi3.save'); } catch (e) { return false; } }
  function loadGame() {
    try {
      var d = JSON.parse(localStorage.getItem('rubezhi3.save'));
      if (!d) return false;
      d.v = d.saveVersion || d.v; var v0 = d.v; if (!(d.v >= SAVE_MIN) || !migrateSave(d)) return 'old';
      gen++;
      NP = d.np; NC = d.nc; setWorld(NP, !!d.wide);
      var provs = buildWorld(d.seed, !(v0 >= 10)); initEth(provs);
      d.provs.forEach(function (r, i) { var p = provs[i]; p.owner = r[0]; p.terrain = r[1]; p.set = r[2]; p.pop = r[3]; p.garrison = r[4]; p.capital = !!r[5]; p.occ = r[6] || 0; p.occBy = r[7] === undefined ? -1 : r[7]; p.depot = !!r[8]; p.fac = r[9] || 0; p.fd = (r[10] || 0) / 100; p.civ = r[11] || 0; p.dev = r[12] || 0; if (r[13]) ethLoad(p, r[13]); else if (!p.sea) { p.eth = {}; p.eth[p.owner] = 1; } p.pol = r[14] || 0; p.unr = r[15] || 0; p.reb = r[16] || 0; p.rebS = r[17] || 0; p.rebAge = r[18] || 0; p.crit = r[19] || 0; p.aut = r[20] || 0; });
      OC = null;
      S = { phase: 'play', round: d.round, player: d.player, gold: d.gold, provs: provs, armies: [], aid: d.aid || 0, selP: -1, selA: -1, pickC: -1, busy: false, chron: d.chron || [], msg: '', seed: d.seed, alive: d.alive, ui: { view: null }, rel: null, op: null, trade: null, offers: d.offers || [], dipCool: {}, won: false, gens: d.gens || [], gid: d.gid || 0, reports: [], rid: 0, multi: [], groups: {}, layer: 'pol', selF: '', multiMode: false };
      ANIM = null; initExtra();
      if (d.eq) S.eq = d.eq; if (d.eqD) S.eqD = d.eqD; if (d.hist) S.hist = d.hist; if (d.stat) S.stat = d.stat; S.glob = d.glob || { bat: 0, war: 0, hun: 0, epi: 0, uns: 0, ref: 0 }; if (d.keyEv) S.keyEv = d.keyEv; S.cont = !!d.cont; if (d.inf) S.inf = d.inf; S.calm = d.calm || 0; if (d.tax) S.tax = d.tax; if (d.pir) S.pir = d.pir; if (d.intel) S.intel = d.intel; if (d.spyCd) S.spyCd = d.spyCd; if (d.xs) S.xs = d.xs; if (d.em) S.em = d.em; if (d.emCd) S.emCd = d.emCd; if (d.weary) S.weary = d.weary; if (d.wsince) S.wsince = d.wsince; if (d.law) S.law = d.law; if (d.lawCd) S.lawCd = d.lawCd; S.vic = d.vic || 'std'; S.peaceRun = d.peaceRun || 0; if (d.tech) S.tech = d.tech.map(function (t) { return { done: t.done || [], cur: t.cur || '', prog: t.prog || 0, bank: t.bank || 0, fx: null }; }); S.just = d.just || {}; S.fabs = d.fabs || []; S.allyCd = d.allyCd || 0; S.bcb = d.bcb || {}; S.blk = d.blk || {}; S.blkCd = d.blkCd || {};
      d.armies.forEach(function (r) { var a = newArmy(r[0], r[1], r[2], r[3]); a.route = r[4] ? r[4].split('.').map(Number) : []; if (r[5]) a.id = r[5]; a.gen = r[6] || 0; a.stance = r[7] || 'atk'; a.dug = r[8] || 0; a.wait = r[9] || 0; a.mode = r[10] || 'push'; if (r[11] >= 0 && r[11] != null) a.eng = { pid: r[11], from: a.prov, turns: r[12] || 1 }; a.blk = !!r[13]; });
      if (!d.gens) { for (var cc = 0; cc < NC; cc++) { mkGen(cc, 2); mkGen(cc, 1); assignGenerals(cc); } }
      S.aid = Math.max(S.aid, S.armies.reduce(function (m, a) { return Math.max(m, a.id); }, 0));
      S.rel = d.rel.map(function (r) { return r.split(''); }); S.op = d.op.map(function (r) { return r.split(',').map(Number); }); S.trade = d.trade.map(function (r) { return r.split('').map(Number); });
      computeSupply();
      S.selP = capitalOf(S.player);
      return true;
    } catch (e) { return false; }
  }
