  /* ---------- armies, supply, routes ---------- */
  function armyById(id) { for (var i = 0; i < S.armies.length; i++) if (S.armies[i].id === id) return S.armies[i]; return null; }
  function newArmy(owner, prov, troops, org) {
    var a = { id: ++S.aid, owner: owner, prov: prov, troops: troops, org: org == null ? 80 : org, route: [], fought: false, moved: 0, left: 0, gen: 0, stance: 'atk', dug: 0, wait: 0, mode: 'push', eng: null, rd: 0, rdw: 0 };
    S.armies.push(a);
    return a;
  }
  function armiesAt(pid) { return S.armies.filter(function (a) { return a.prov === pid; }); }
  function hostileAt(pid, who) {
    if (S.provs[pid].sea) return null;
    var best = null;
    for (var i = 0; i < S.armies.length; i++) { var a = S.armies[i]; if (a.prov === pid && isWar(a.owner, who) && (!best || a.troops > best.troops)) best = a; }
    return best;
  }
  function canEnter(who, p) { if (p.reb > 0) return p.owner === who; return p.sea || p.owner === who || isAlly(who, p.owner) || isWar(who, p.owner); }
  function terrCost(p) { return TER[p.terrain].cost; }
  function activeFights() {
    var out = [];
    if (!S || (S.phase !== 'play' && S.phase !== 'over')) return out;
    S.armies.forEach(function (a) {
      if (!a.eng || !a.route.length || a.route[0] !== a.eng.pid || a.prov !== a.eng.from) return;
      var d = hostileAt(a.eng.pid, a.owner);
      if (!d) return;
      if (fogOn() && !friendlyTo(a.owner, S.player) && !friendlyTo(d.owner, S.player) && !visibleProv(S.provs[a.prov])) return;
      out.push({ a: a, d: d, from: a.prov, pid: a.eng.pid });
    });
    return out;
  }
  function budget(a) { return (({ slow: 1.5, normal: 2, fast: 3 }[ST.speed] || 2) + (a ? gsk(a, 'spd') * 0.15 : 0)) * speedMult() * (1 + (a ? tk(a.owner, 'spd') : 0)); }

  function computeSupply() {
    var provs = S.provs, q = [];
    provs.forEach(function (p) {
      p.sup = false; p.from = -1; p.rem = -1;
      var h = p.capital ? 5 : SETT[p.set].hub;
      if (p.depot && h < 2) h = 2;
      if (h >= 0 && !(p.occ > 0)) { p.rem = h; p.sup = true; q.push(p.id); }
    });
    while (q.length) {
      var id = q.shift(), p = provs[id];
      if (p.rem < 1) continue;
      for (var i = 0; i < p.nb.length; i++) {
        var m = provs[p.nb[i]];
        var nr = p.rem - 1;
        if (m.owner === p.owner && nr >= 0 && m.rem < nr) { m.rem = nr; m.sup = true; m.from = id; q.push(m.id); }
      }
      var ln = MAP.lane[id];
      if (ln) for (var li = 0; li < ln.length; li++) { var m2 = provs[ln[li].to], nr2 = p.rem - ln[li].cost; if (m2.owner === p.owner && nr2 >= 0 && m2.rem < nr2) { m2.rem = nr2; m2.sup = true; m2.from = id; q.push(m2.id); } }
    }
  }
  function armySup(a) {
    var p = S.provs[a.prov];
    if (p.owner === a.owner || isAlly(a.owner, p.owner)) return p.sup;
    return p.nb.some(function (n) { var m = S.provs[n]; return (m.owner === a.owner || isAlly(a.owner, m.owner)) && m.sup; });
  }

  // Dijkstra over the province graph. Enemy provinces (and provinces with enemy armies) are terminal: a march stops there.
  function distMap(start, who) {
    var n = S.provs.length, cost = new Array(n).fill(1e9), prev = new Array(n).fill(-1), done = new Array(n).fill(false), i;
    cost[start] = 0;
    for (;;) {
      var u = -1, bu = 1e9;
      for (i = 0; i < n; i++) if (!done[i] && cost[i] < bu) { bu = cost[i]; u = i; }
      if (u < 0) break;
      done[u] = true;
      var pu = S.provs[u];
      if (u !== start && (isWar(who, pu.owner) || hostileAt(u, who) || pu.reb > 0)) continue;
      for (i = 0; i < pu.nb.length; i++) {
        var v = pu.nb[i], pv = S.provs[v];
        if (done[v] || !canEnter(who, pv)) continue;
        var c = bu + terrCost(pv) + linkCost(u, v) + (isWar(who, pv.owner) ? 0.3 : 0);
        if (c < cost[v]) { cost[v] = c; prev[v] = u; }
      }
    }
    return { cost: cost, prev: prev };
  }
  function routeFrom(dm, start, dest) {
    if (dm.cost[dest] >= 1e9 || dest === start) return null;
    var r = [], c = dest;
    while (c !== start && c >= 0) { r.unshift(c); c = dm.prev[c]; }
    return c === start ? r : null;
  }
  function findRoute(a, dest) { return routeFrom(distMap(a.prov, a.owner), a.prov, dest); }
  function routeTurns(a) {
    if (!a.route.length) return 0;
    var t = 0, left = budget(a), first = true, prv = a.prov;
    for (var i = 0; i < a.route.length; i++) {
      var c = terrCost(S.provs[a.route[i]]) + linkCost(prv, a.route[i]); prv = a.route[i];
      if (!first && left < 0.6 * c) { t++; left = budget(a); }
      left -= c; first = false;
    }
    return t + 1;
  }

  /* ---------- combat ---------- */
  function supplyMod(a) { return (armySup(a) ? 1 : 0.85) * (S.eq && S.eq[a.owner] <= 0 ? 0.88 : 1); }
  function sideMods(att, def, p) {
    return {
      a: atkMult() * supplyMod(att),
      d: TER[p.terrain].def * winterDef() * (p.owner === def.owner || isAlly(def.owner, p.owner) ? fortOf(p) : 1) * supplyMod(def)
    };
  }
  function power(a, mod) { return a.troops * (0.55 + 0.45 * a.org / 100) * mod * (1 + tk(a.owner, 'pow')); }
  function forecast(a, pid) {
    var p = S.provs[pid], def = hostileAt(pid, a.owner), ratio, kind, g = 0;
    if (def) {
      var m = sideMods(a, def, p);
      ratio = power(a, m.a) / Math.max(1, power(def, m.d)); kind = 'battle';
    } else if (isWar(a.owner, p.owner)) {
      kind = 'siege'; g = p.garrison; ratio = 99;
    } else { return null; }
    var v = ratio >= 1.6 ? ['Подавляющее превосходство', 'good'] : ratio >= 1.15 ? ['Преимущество', 'good'] : ratio >= 0.85 ? ['Равные силы', 'warn'] : ratio >= 0.55 ? ['Невыгодный бой', 'bad'] : ['Почти верное поражение', 'bad'];
    return { kind: kind, ratio: ratio, label: v[0], tone: v[1], garrison: g, enemy: def };
  }
  function retreatTarget(a, away, prefer) {
    var p = S.provs[a.prov], best = -1, bs = -1e9, cap = capitalOf(a.owner), cp = cap >= 0 ? S.provs[cap] : p, ap = away >= 0 ? S.provs[away] : null;
    p.lnb.forEach(function (n) {
      var q = S.provs[n];
      if (!(q.owner === a.owner || isAlly(a.owner, q.owner))) return;
      if (hostileAt(n, a.owner)) return;
      var sc = (q.sup ? 8 : 0) + (q.owner === a.owner ? 4 : 0) + (n === prefer ? 6 : 0) - Math.hypot(q.lx - cp.lx, q.ly - cp.ly) / 200 + (ap ? Math.hypot(q.lx - ap.lx, q.ly - ap.ly) / 150 : 0);
      if (sc > bs) { bs = sc; best = n; }
    });
    if (best < 0) p.nb.forEach(function (n) { if (S.provs[n].sea && n !== away && best < 0) best = n; });
    return best;
  }
  function capitalOf(c) { for (var i = 0; i < S.provs.length; i++) if (S.provs[i].owner === c && S.provs[i].capital) return i; return -1; }
  function removeArmy(a, die) { dropGen(a, die); var i = S.armies.indexOf(a); if (i >= 0) S.armies.splice(i, 1); }
  function mine(x) { return x.owner === S.player; }

  function neighborsOwnArmies(p, owner, exclude, onlyToward) {
    var n = 0;
    p.lnb.forEach(function (q) {
      S.armies.forEach(function (x) {
        if (x.prov !== q || x === exclude) return;
        if (!(x.owner === owner || isAlly(owner, x.owner))) return;
        if (onlyToward && !(x.route.length && x.route[0] === p.id)) return;
        n++;
      });
    });
    return n;
  }
  var PHASES = ['Огневой контакт', 'Натиск'];
  // One turn of a front battle. The attacker stays in its own province; the battle continues turn after turn
  // until the defender breaks (attacker advances), or the attacker runs out of steam / is stopped by the player.
  function frontRound(att, def, p, rec) {
    var from = att.prov, ld = !!S.provs[from].sea, ms = att.mode === 'grind' ? 'grind' : 'push';
    if (!att.eng || att.eng.pid !== p.id) att.eng = { pid: p.id, from: from, turns: 0 };
    att.eng.turns++;
    att.dug = 0;
    if (def.rdw === att.id && def.rd === S.round) { att.fought = true; return 'held'; }
    var first = att.eng.turns === 1;
    var t0a = att.troops, t0d = def.troops, o0a = att.org, o0d = def.org, rd, rounds = [];
    var ownP = (p.owner === def.owner || isAlly(def.owner, p.owner));
    var flank = ld ? 0 : Math.min(2, neighborsOwnArmies(p, att.owner, att, true)), supA = ld ? 0 : Math.min(2, neighborsOwnArmies(p, att.owner, att, false) - flank), supD = Math.min(2, neighborsOwnArmies(p, def.owner, def, false));
    if (supA < 0) supA = 0;
    var F = {
      troops: [t0a, t0d], org: [o0a, o0d],
      terrain: [1, TER[p.terrain].def],
      season: [atkMult(), winterDef()],
      fort: [1, (ownP ? fortOf(p) : 1) * (1 + 0.08 * def.dug)],
      supply: [supplyMod(att), supplyMod(def)],
      general: [(1 + 0.05 * gsk(att, 'atk')) * cmdMult(att), (1 + 0.05 * gsk(def, 'def')) * cmdMult(def)],
      flank: [1 + 0.1 * flank * (1 + 0.25 * gsk(att, 'enc')), 1],
      support: [1 + 0.04 * Math.max(0, supA), 1 + 0.04 * supD],
      landing: [ld ? 0.8 : 1, 1],
      em: [emAtk(att.owner), emDef(def.owner, ownP)]
    };
    var ma = F.season[0] * F.supply[0] * F.general[0] * F.flank[0] * F.support[0] * F.landing[0] * F.em[0];
    var md = F.terrain[1] * F.season[1] * F.fort[1] * F.supply[1] * F.general[1] * F.support[1] * F.em[1];
    var kD = ms === 'grind' ? 0.8 : 1.2, kA = ms === 'grind' ? 0.45 : 1.15, tlA = ms === 'grind' ? 0.5 : 1.1, tlD = ms === 'grind' ? 0.9 : 1.1;
    for (rd = 0; rd < 2; rd++) {
      var fa = power(att, ma) * rnd(0.85, 1.15), fd = power(def, md) * rnd(0.85, 1.15), ra = Math.max(0.05, fa / Math.max(1, fd));
      def.org -= clamp(9 * Math.pow(ra, 0.8), 1.5, 22) * kD; att.org -= clamp(9 * Math.pow(1 / ra, 0.8), 1.5, 22) * kA;
      def.troops = Math.max(1, def.troops - Math.max(1, Math.round(def.troops * 0.025 * clamp(ra, 0.4, 2.5) * tlD)));
      att.troops = Math.max(1, att.troops - Math.max(1, Math.round(att.troops * 0.025 * clamp(1 / ra, 0.4, 2.5) * tlA)));
      rounds.push({ ph: PHASES[rd], oa: Math.max(0, Math.round(att.org)), od: Math.max(0, Math.round(def.org)) });
    }
    att.fought = true; def.fought = true; att.rd = def.rd = S.round; att.rdw = def.id; def.rdw = att.id;
    var defBroke = def.org <= 15, attSpent = att.org <= 20;
    var win = defBroke && !(attSpent && att.org < def.org), res = win ? 'win' : attSpent ? 'repulse' : 'held';
    var lossA = t0a - att.troops, pursuit = 0, outcome = res, dest = -1, turns = att.eng.turns;
    if (win) {
      pursuit = Math.round(def.troops * (0.05 + 0.02 * gsk(att, 'spd')) * (att.stance === 'hold' ? 0.5 : 1));
      def.troops = Math.max(1, def.troops - pursuit);
      dest = retreatTarget(def, from, -1);
      outcome = dest >= 0 ? 'retreat' : 'surrender';
    }
    var lossD = t0d - def.troops;
    if (ST.harsh) { var xa = Math.round(lossA * 0.3), xd = Math.round(lossD * 0.3); att.troops = Math.max(1, att.troops - xa); def.troops = Math.max(1, def.troops - xd); lossA += xa; lossD += xd; }
    if (S.cas) { S.cas[att.owner] += lossA; S.cas[def.owner] += lossD; }
    def.org = Math.max(8, def.org); att.org = Math.max(6, att.org);
    var winnerLike = win || (res === 'held' && att.org >= def.org);
    var info = { pid: p.id, from: from, att: att, def: def, attWins: win, lossA: lossA, lossD: lossD, broke: win };
    var facs = [['численность', F.troops[0] / F.troops[1]], ['организация', F.org[0] / Math.max(1, F.org[1])], ['рельеф', 1 / F.terrain[1]], ['сезон', F.season[0] / F.season[1]], ['укрепления', 1 / F.fort[1]], ['снабжение', F.supply[0] / F.supply[1]], ['командование', F.general[0] / F.general[1]], ['фланговый удар', F.flank[0]], ['поддержка соседей', F.support[0] / F.support[1]], ['десант', F.landing[0]], ['чрезвычайные меры', F.em[0] / F.em[1]]];
    var reasons = facs.map(function (f) { return [f[0], winnerLike ? f[1] : 1 / f[1]]; }).filter(function (f) { return f[1] >= 1.05; }).sort(function (x, y) { return y[1] - x[1]; }).slice(0, 4).map(function (f) { return f[0] + ' ×' + (Math.round(f[1] * 100) / 100); });
    var mineInv = mine(att) || mine(def);
    var tag = p.name + ': фронтовой бой, ход ' + turns + ' (' + CNAMES[att.owner] + (ms === 'grind' ? ' изматывает ' : ' наступает на ') + CNAMES[def.owner] + '). Потери ' + fmtU(lossA) + ' / ' + fmtU(lossD) + ', организация ' + Math.round(att.org) + ' / ' + Math.round(def.org) + '.';
    if (win) { info.retreat = dest >= 0 ? dest : null; tag += outcome === 'surrender' ? ' Окружённая армия капитулировала.' : ' Оборона прорвана, противник отступил в ' + S.provs[dest].name + '.'; }
    else if (res === 'repulse') { tag += ' Атака выдохлась, армия прекратила наступление.'; att.route = []; att.eng = null; info.disengaged = true; if (mine(att)) toast('Атака на ' + p.name + ' выдохлась.', 'warn'); }
    if (win) {
      if (dest >= 0) { def.prov = dest; def.route = []; def.dug = 0; def.eng = null; } else { info.destroyed = def; }
    }
    var rep = { id: ++S.rid, r: S.round, pid: p.id, mode: ms, turns: turns, ld: ld, att: { owner: att.owner, id: att.id, t0: t0a, t1: att.troops, o0: Math.round(o0a), o1: Math.round(att.org), gen: (genOf(att) || {}).name || '', flank: flank }, def: { owner: def.owner, id: def.id, t0: t0d, t1: def.troops, o0: Math.round(o0d), o1: Math.round(def.org), gen: (genOf(def) || {}).name || '', dug: def.dug }, attWins: win, rounds: rounds, reasons: reasons, pursuit: pursuit, outcome: outcome, dest: dest, F: { terrain: F.terrain[1], fort: F.fort[1], supply: F.supply, general: F.general, flank: F.flank[0], support: F.support, season: F.season } };
    S.reports.push(rep); if (S.reports.length > 40) S.reports.shift();
    if (mineInv || win) { var le = log(tag, mineInv, p.id, 'battle'); le.rep = rep.id; }
    var st = S.stat;
    gl('bat', lossA + lossD); st.lost[att.owner] += lossA; st.kills[att.owner] += lossD; st.lost[def.owner] += lossD; st.kills[def.owner] += lossA;
    if (first) { st.bat[att.owner]++; st.bat[def.owner]++; }
    addXp(att, win ? 10 : 4); addXp(def, win ? 4 : 8);
    // war hurts the province: industry, population
    hurtInd(p, clamp((lossA + lossD) / 200, 0.03, 0.14));
    popLose(p, Math.ceil((lossA + lossD) / (ST.harsh ? 18 : RL('rMan') ? 40 : 80)), 'war');
    if (rec) rec.bt(info, t0a, t0d, o0a, o0d);
    if (outcome === 'surrender') removeArmy(def, true);
    if (mineInv) hint('bat', 'исход боя зависит от численности, организации, генерала, рельефа и снабжения. Следи за организацией — истощённая армия бежит.');
    if (mineInv) { SFX.battle(); if (win && mine(def)) buzz(60); }
    return res;
  }
  function nearestFriendlyAvoid(x) {
    var seen = {}, q = [x.prov]; seen[x.prov] = 1;
    while (q.length) {
      var id = q.shift(), p = S.provs[id];
      if (id !== x.prov && (p.owner === x.owner || isAlly(x.owner, p.owner)) && !hostileAt(id, x.owner)) return id;
      p.nb.forEach(function (n) { if (!seen[n]) { var pq = S.provs[n]; if (canEnter(x.owner, pq) && !hostileAt(n, x.owner) || pq.owner === x.owner) { seen[n] = 1; q.push(n); } } });
    }
    return -1;
  }

  function captureProv(pid, nw) {
    var p = S.provs[pid], old = p.owner, wasCap = p.capital;
    OC = null; p.owner = nw; p.occ = 0; p.occBy = -1; p.garrison = Math.round(gcap(p) * 0.3); popLose(p, p.pop - Math.round(p.pop * (ST.harsh ? 0.75 : 0.9)), 'war'); p.pol = 0; p.tst = 0; p.recruited = true; p.besieged = false;
    var us = S.player;
    S.stat.caps[nw]++; if (old >= 0) { S.stat.capL[old]++; S.inf[nw] += wasCap ? 4 : 1.2; }
    if (p.fac > 0) { p.fd = Math.max(p.fd, 0.35); hurtInd(p, 0.1); }
    log(CNAMES[nw] + ' занимает ' + p.name + (old >= 0 ? ' (' + CNAMES[old] + ')' : '') + '.', nw === us || old === us, pid, 'capture');
    if (nw === us) { toast('Занято: ' + p.name, 'good'); SFX.capture(); buzz(40); } else if (old === us) { toast('Потеряно: ' + p.name, 'bad'); SFX.lose(); buzz(80); }
    if (wasCap) {
      p.capital = false;
      var bonus = 8 + Math.floor(S.gold[old] / 3); S.gold[old] -= Math.floor(S.gold[old] / 3); S.gold[nw] += bonus;
      var rest = owned(old).sort(function (a, b) { return (b.set - a.set) || (b.pop - a.pop); });
      if (rest.length) { rest[0].capital = true; rest[0].pop = Math.min(popCap(rest[0]), rest[0].pop + 5); }
      S.armies.forEach(function (a) { if (a.owner === old) a.org = Math.max(5, a.org - 15); });
      log('Столица державы ' + CNAMES[old] + ' пала.', nw === us || old === us, pid, 'capture');
      keyEv('Пала столица державы ' + CNAMES[old] + ' (' + p.name + ')');
      if (old === us) toast('Твоя столица пала!', 'bad');
    }
    if (!owned(old).length) {
      S.alive[old] = false;
      S.armies = S.armies.filter(function (a) { return a.owner !== old; });
      log('Держава ' + CNAMES[old] + ' пала.', true, -1, 'capture');
      keyEv('Держава ' + CNAMES[old] + ' уничтожена');
      if (old !== us) toast('Держава ' + CNAMES[old] + ' пала.', 'warn');
    }
    computeSupply();
  }

  function advance(a, next, cost, rec) {
    var p = S.provs[next];
    a.route.shift(); a.left -= cost; a.moved++; a.dug = 0; a.eng = null;
    a.prov = next;
    if (rec) rec.mv(a, next);
    if (isWar(a.owner, p.owner)) { a.route = []; a.stopped = true; }
    if (a.org < 25 && a.route.length) { a.route = []; a.stopped = true; if (mine(a)) toast('Армия истощена и остановила марш.', 'warn'); }
  }
  function stepArmy(a, rec) {
    var next = a.route[0], p = S.provs[next], cost = terrCost(p) + linkCost(a.prov, next);
    if (a.moved > 0 && a.left < 0.6 * cost) { a.stopped = true; return false; }
    if (!canEnter(a.owner, p)) {
      a.route = []; a.stopped = true;
      if (mine(a)) toast('Путь закрыт: нет прохода в ' + p.name + '.', 'warn');
      return false;
    }
    var def = hostileAt(next, a.owner);
    if (def) {
      var res = frontRound(a, def, p, rec);
      a.stopped = true;
      if (S.armies.indexOf(a) < 0) return true;
      if (res === 'win' && !hostileAt(next, a.owner)) { if (rec) rec.beat(); advance(a, next, cost, rec); a.stopped = true; }
      return true;
    }
    a.eng = null;
    advance(a, next, cost, rec);
    return true;
  }

  function resolveMovement(rec) {
    var arms = S.armies.slice(), guard = 0, progress = true;
    arms.forEach(function (a) { a.left = budget(a); a.moved = 0; a.stopped = false; a.fought = false; if (a.wait > 0) { a.wait--; a.stopped = true; } });
    while (progress && guard++ < 14) {
      progress = false;
      var order = shuffle(arms.filter(function (a) { return S.armies.indexOf(a) >= 0 && a.route.length && !a.stopped; }));
      if (!order.length) break;
      rec.beat();
      order.forEach(function (a) {
        if (S.armies.indexOf(a) < 0 || !a.route.length || a.stopped) return;
        if (stepArmy(a, rec)) progress = true;
      });
    }
  }

  function resolveSieges(rec) {
    var by = {};
    S.armies.forEach(function (a) { (by[a.prov] || (by[a.prov] = [])).push(a); });
    S.provs.forEach(function (p) { p.besieged = false; });
    Object.keys(by).forEach(function (k) {
      var p = S.provs[+k], arms = by[k];
      var foes = arms.filter(function (a) { return isWar(a.owner, p.owner); });
      if (!foes.length) return;
      if (arms.some(function (a) { return (a.owner === p.owner || isAlly(a.owner, p.owner)) && foes.some(function (f) { return isWar(f.owner, a.owner); }); })) return;
      var tot = {};
      foes.forEach(function (a) { tot[a.owner] = (tot[a.owner] || 0) + a.troops; });
      var B = -1, bt = -1;
      Object.keys(tot).forEach(function (o) { if (tot[o] > bt) { bt = tot[o]; B = +o; } });
      var sieg = foes.filter(function (a) { return a.owner === B || isAlly(a.owner, B); });
      var T = 0; sieg.forEach(function (a) { T += a.troops; });
      p.besieged = true;
      if (ST.harsh) popLose(p, Math.ceil(p.pop * 0.03), 'war');
      if (p.occBy !== B && p.occBy >= 0) p.occ = 0;
      var dm = defMultP(p), atk = atkMult();
      if (p.garrison > 0) {
        var gb = p.garrison, loss = Math.max(2, Math.round(T * 0.25 * atk / dm));
        p.garrison = Math.max(0, p.garrison - loss);
        var attr = Math.round(gb * dm * 0.05);
        sieg.forEach(function (a) { a.troops = Math.max(1, a.troops - Math.round(attr * a.troops / T)); a.org = Math.max(10, a.org - 2); a.fought = true; });
        if (p.garrison === 0) log('Гарнизон ' + p.name + ' разбит.', B === S.player || p.owner === S.player, p.id, 'battle');
        hurtInd(p, 0.05);
        if (rec) rec.siege(p.id, B, loss);
      } else {
        var steps = [2, 2, 3][p.set] + (p.capital ? 1 : 0), f = clamp(T / 80, 0.6, 1.5);
        p.occ += 100 / steps * f * (1 + tk(B, 'sie')); p.occBy = B; hurtInd(p, 0.035);
        if (p.occ >= 100) { sieg.forEach(function (a) { addXp(a, 15); }); captureProv(p.id, B); if (rec) rec.cap(p.id, B); }
      }
    });
  }

  function mergeArmies() {
    var again = true;
    while (again) {
      again = false;
      outer: for (var i = 0; i < S.armies.length; i++) for (var j = i + 1; j < S.armies.length; j++) {
        var a = S.armies[i], b = S.armies[j];
        if (a.prov === b.prov && a.owner === b.owner && !a.route.length && !b.route.length && !(a.owner === S.player && S.phase === 'play')) {
          var T = a.troops + b.troops;
          a.org = (a.org * a.troops + b.org * b.troops) / T; a.troops = T; a.dug = Math.min(a.dug, b.dug);
          var ga = genOf(a), gb = genOf(b);
          if (gb && (!ga || gb.lvl > ga.lvl)) { a.gen = b.gen; }
          b.gen = 0;
          S.armies.splice(j, 1);
          if (S.selA === b.id) S.selA = a.id;
          again = true; break outer;
        }
      }
    }
  }

  /* ---------- recruiting ---------- */
  function canRecruit(p, c) {
    c = c == null ? S.player : c;
    var n = SETT[p.set].rec;
    return p.owner === c && p.sup && !p.recruited && !(p.occ > 0) && !p.besieged && S.gold[c] >= recCostFor(n) && p.pop >= popNeed(n) && S.eq[c] >= n;
  }
  function recruit(p) {
    var c = p.owner, n = SETT[p.set].rec, men = n * 10;
    var here = armiesAt(p.id).filter(function (a) { return a.owner === c; });
    S.gold[c] -= recCostFor(n); S.eq[c] -= n; p.pop -= popCost(n); p.recruited = true;
    if (here.length) {
      var a = here.sort(function (x, y) { return x.troops - y.troops; })[0];
      a.org = (a.org * a.troops + 55 * men) / (a.troops + men); a.troops += men;
      return a;
    }
    var na0 = newArmy(c, p.id, men, 60);
    autoGen(na0);
    return na0;
  }

  /* ---------- depots, fallback, reserves, encirclement ---------- */
  function canBuildDepot(p) { return p.owner === S.player && !p.depot && !(p.occ > 0) && !p.besieged && S.gold[S.player] >= 12; }
  function buildDepot(p) { var c = p.owner; S.gold[c] -= 12; p.depot = true; computeSupply(); }
  function fallback(a) {
    var dm = distMap(a.prov, a.owner), best = -1, bs = -1e9;
    S.provs.forEach(function (q) {
      if (q.id === a.prov || dm.cost[q.id] > 4.5) return;
      if (!(q.owner === a.owner || isAlly(a.owner, q.owner))) return;
      var sc = (q.sup ? 6 : 0) - threatTo(q.id, a.owner) / 40 - dm.cost[q.id] * 0.8;
      if (sc > bs) { bs = sc; best = q.id; }
    });
    if (best < 0) return false;
    a.route = routeFrom(dm, a.prov, best) || []; a.stance = 'atk'; a.wait = 0;
    return a.route.length > 0;
  }
  function reserveTarget(a, only) {
    var dm = distMap(a.prov, a.owner), best = -1, bs = 0;
    S.provs.forEach(function (q) {
      if (q.id === a.prov || dm.cost[q.id] > 7 || q.owner !== a.owner || (only && only.indexOf(q.id) < 0)) return;
      var thr = threatTo(q.id, a.owner);
      if (!thr && !isFront(q, a.owner)) return;
      var hold = armiesAt(q.id).filter(function (x) { return x.owner === a.owner; }).reduce(function (t, x) { return t + x.troops; }, 0);
      var sc = (thr * 1.2 - hold * 0.8 + (isFront(q, a.owner) ? 25 : 0) + q.set * 12 + (q.capital ? 30 : 0)) / (1 + dm.cost[q.id] * 0.5);
      if (sc > bs) { bs = sc; best = q.id; }
    });
    if (best < 0) return false;
    a.route = routeFrom(dm, a.prov, best) || []; a.stance = 'atk';
    return a.route.length > 0;
  }
  function encircled(a) {
    var p = S.provs[a.prov];
    if (!p.nb.length) return false;
    return p.nb.every(function (n) { var q = S.provs[n]; if (q.sea) return false; return !(q.owner === a.owner || isAlly(a.owner, q.owner)) || hostileAt(n, a.owner); }) && !(p.owner === a.owner && p.sup && p.rem >= 3);
  }

  /* ---------- emergency measures ---------- */
  var EM = [
    { k: 'mart', n: 'Военное положение', ic: 'shield', dur: 4, cd: 12, unr: 30,
      g: 'Оборона ×1.45, гарнизоны сразу восстанавливаются до максимума.',
      c: 'Население −3% в ход, рост остановлен, доход −25%, недовольство растёт до 30%.',
      pv: function (P, I) { return 'за ход ≈ −' + Math.round(P * 0.03) + ' жителей и −' + Math.round(I * 0.25) + ' зол.'; } },
    { k: 'mob', n: 'Тотальная мобилизация', ic: 'people', dur: 5, cd: 16, unr: 22,
      g: 'Сразу +40% людей и +20 организации во всех армиях, +40 техники. Атака ×1.2, оборона ×1.1.',
      c: 'Население −10% сразу и −1.5% в ход, рост остановлен, доход −20%, недовольство до 22%.',
      pv: function (P, I) { return 'сразу ≈ −' + Math.round(P * 0.1) + ' жителей, затем −' + Math.round(P * 0.015) + ' за ход, доход −' + Math.round(I * 0.2) + ' зол.'; } },
    { k: 'scorch', n: 'Выжженная земля', ic: 'warn', dur: 4, cd: 14, unr: 15,
      g: 'Оборона на своей земле ×1.25. Вражеские армии в твоих провинциях теряют 6% людей и 6 организации за ход.',
      c: 'Прифронтовые провинции теряют 7% жителей за ход и часть промышленности, доход −10%, недовольство до 15%.',
      pv: null },
    { k: 'wecon', n: 'Военная экономика', ic: 'gear', dur: 5, cd: 14, unr: 25,
      g: 'Выпуск техники ×3 и +25 сразу. Атака ×1.1.',
      c: 'Население −2% в ход, рост остановлен, доход −35%, недовольство до 25%.',
      pv: function (P, I) { return 'за ход ≈ −' + Math.round(P * 0.02) + ' жителей и −' + Math.round(I * 0.35) + ' зол.'; } }
  ];
  function emById(k) { for (var i = 0; i < EM.length; i++) if (EM[i].k === k) return EM[i]; return null; }
  function emEnsure() { if (!S.em || S.em.length !== NC || !S.emCd) { S.em = zeros().map(function () { return {}; }); S.emCd = zeros().map(function () { return {}; }); } }
  function emOn(c, k) { return !!(S && S.em && c >= 0 && S.em[c] && S.em[c][k] > 0); }
  function emAny(c) { return emOn(c, 'mart') || emOn(c, 'mob') || emOn(c, 'scorch') || emOn(c, 'wecon'); }
  function emDef(c, own) {
    if (!emAny(c)) return 1;
    var m = 1;
    if (emOn(c, 'mart')) m *= 1.45;
    if (emOn(c, 'mob')) m *= 1.1;
    if (own && emOn(c, 'scorch')) m *= 1.25;
    return m;
  }
  function emAtk(c) { if (!emAny(c)) return 1; var m = 1; if (emOn(c, 'mob')) m *= 1.2; if (emOn(c, 'wecon')) m *= 1.1; return m; }
  function emInc(c) {
    if (!emAny(c)) return 1;
    var m = 1;
    if (emOn(c, 'mart')) m *= 0.75;
    if (emOn(c, 'mob')) m *= 0.8;
    if (emOn(c, 'wecon')) m *= 0.65;
    if (emOn(c, 'scorch')) m *= 0.9;
    return m;
  }
  function emUnr(c) { if (!emAny(c)) return 0; var u = 0; EM.forEach(function (m) { if (emOn(c, m.k)) u += m.unr; }); return u; }
  function emExposed(p) {
    if (p.sea || p.owner < 0) return false;
    var o = p.owner;
    if (hostileAt(p.id, o)) return true;
    return p.nb.some(function (n) { var q = S.provs[n]; if (q.sea) return false; return (q.owner >= 0 && q.owner !== o && isWar(o, q.owner)) || !!hostileAt(n, o); });
  }
  function emStart(c, k) {
    emEnsure();
    var m = emById(k);
    if (!m || !S || S.phase !== 'play' || !owned(c).length) return { ok: false, msg: '' };
    if (!warEnemies(c).length) return { ok: false, msg: 'Чрезвычайные меры вводятся только во время войны.' };
    if (S.em[c][k] > 0) return { ok: false, msg: 'Эта мера уже действует.' };
    if (S.emCd[c][k] > 0) return { ok: false, msg: 'Мера перезаряжается: ещё ' + S.emCd[c][k] + ' ход.' };
    var ps = owned(c), men = 0;
    if (k === 'mart') ps.forEach(function (p) { p.garrison = Math.max(p.garrison, gcap(p)); p.unr = Math.min(100, (p.unr || 0) + 8); });
    else if (k === 'mob') {
      S.armies.forEach(function (a) { if (a.owner === c) { var add = Math.round(a.troops * 0.4); a.troops += add; men += add; a.org = Math.min(100, a.org + 20); } });
      S.eq[c] = Math.max(S.eq[c], Math.min(eqCap(c), S.eq[c] + 40));
      ps.forEach(function (p) { popLose(p, Math.ceil(p.pop * 0.1), 'hun'); p.unr = Math.min(100, (p.unr || 0) + 10); });
    } else if (k === 'wecon') S.eq[c] = Math.max(S.eq[c], Math.min(eqCap(c), S.eq[c] + 25));
    S.em[c][k] = m.dur; S.emCd[c][k] = m.dur + m.cd;
    if (S.weary) S.weary[c] = Math.min(100, S.weary[c] + 2);
    if (S.xs) S.xs.emN = (S.xs.emN || 0) + 1;
    return { ok: true, msg: 'Введено: «' + m.n + '» на ' + m.dur + ' хода.', men: men };
  }
  function emTurn() {
    emEnsure();
    for (var c = 0; c < NC; c++) {
      if (!owned(c).length) { S.em[c] = {}; continue; }
      (function (c) {
        var war = warEnemies(c).length > 0, em = S.em[c], cd = S.emCd[c], ps = owned(c);
        EM.forEach(function (m) {
          var k = m.k;
          if (k === 'mart' && cd.any > 0) cd.any--;
          if (cd[k] > 0) cd[k]--;
          if (!(em[k] > 0)) return;
          if (!war) { em[k] = 0; if (c === S.player) toast('Война окончена: мера «' + m.n + '» отменена.', 'good'); return; }
          if (k === 'mart') ps.forEach(function (p) { popLose(p, Math.ceil(p.pop * 0.03), 'hun'); });
          else if (k === 'mob') ps.forEach(function (p) { popLose(p, Math.ceil(p.pop * 0.015), 'hun'); });
          else if (k === 'wecon') ps.forEach(function (p) { popLose(p, Math.ceil(p.pop * 0.02), 'hun'); });
          else if (k === 'scorch') {
            ps.forEach(function (p) { if (emExposed(p)) { popLose(p, Math.ceil(p.pop * 0.07), 'war'); hurtInd(p, 0.08); } });
            S.armies.forEach(function (a) {
              var q = S.provs[a.prov];
              if (!q.sea && q.owner === c && a.owner !== c && isWar(a.owner, c)) { a.troops = Math.max(5, a.troops - Math.ceil(a.troops * 0.06)); a.org = Math.max(8, a.org - 6); }
            });
          }
          em[k]--;
          if (em[k] <= 0 && c === S.player) toast('Мера «' + m.n + '» снята. Люди приходят в себя.', 'good');
        });
      })(c);
    }
  }
  function aiEm() {
    emEnsure();
    for (var c = 0; c < NC; c++) {
      if (c === S.player || !owned(c).length) continue;
      var foes = warEnemies(c);
      if (!foes.length) continue;
      var dg = 0, cap = false, un = 0, ps = owned(c), on = 0;
      ps.forEach(function (p) { un += p.unr || 0; if (hostileAt(p.id, c) || p.occ > 0) { dg++; if (p.capital) cap = true; } });
      un /= ps.length;
      EM.forEach(function (m) { if (emOn(c, m.k)) on++; });
      if (on >= 2 || un > 38 || S.emCd[c].any > 0 || S.weary[c] > 70) continue;
      var mine = troopsOf(c), foe = 0;
      foes.forEach(function (e) { foe += troopsOf(e); });
      var bad = dg >= 2 || cap || (dg >= 1 && S.weary[c] > 55) || (dg >= 1 && foe > mine * 1.6);
      if (!bad || Math.random() > 0.35) continue;
      var pref = foe > mine * 1.3 ? ['mob', 'mart', 'scorch', 'wecon'] : cap ? ['mart', 'scorch', 'mob', 'wecon'] : dg >= 3 ? ['scorch', 'mart', 'mob', 'wecon'] : ['mart', 'wecon', 'mob', 'scorch'];
      for (var i = 0; i < pref.length; i++) {
        var r = emStart(c, pref[i]);
        if (r.ok) {
          S.emCd[c].any = 14;
          var m = emById(pref[i]), vs = isWar(c, S.player);
          log(CNAMES[c] + ' вводит чрезвычайную меру: «' + m.n + '».', vs, -1, 'dipl');
          if (vs) toast(CNAMES[c] + ' вводит «' + m.n + '»: враг стал сильнее на обороне, но страдает от этого сам.', 'warn');
          break;
        }
      }
    }
  }
  function emPreview(m) {
    var us = S.player, P = popOf(us), I = Math.max(0, income(us));
    if (m.k === 'scorch') {
      var n = 0, lost = 0;
      owned(us).forEach(function (p) { if (emExposed(p)) { n++; lost += Math.ceil(p.pop * 0.07); } }); lost = popFmt(lost);
      return n ? 'сейчас под ударом ' + n + ' пров.: ≈ −' + lost + ' жителей за ход' : 'прифронтовых провинций нет: потери были бы небольшими';
    }
    return m.pv(P, I);
  }
  function emHtml() {
    emEnsure();
    var us = S.player, war = warEnemies(us).length > 0, h = head('Чрезвычайные меры', true) + '<div class="sh-body">';
    h += '<p class="note">Меры военного времени дают большие временные бонусы, но жестоко бьют по населению, золоту и спокойствию в стране. Работают только пока идёт война. Можно ввести несколько сразу, но платить придётся за каждую.</p>';
    h += '<div class="chips"><span class="chip ' + (war ? 'warn' : '') + '">' + (war ? 'Идёт война' : 'Мир: меры недоступны') + '</span><span class="chip">Население ' + popFmt(popOf(us)) + '</span><span class="chip">Усталость ' + r0(S.weary[us] || 0) + '%</span></div>';
    EM.forEach(function (m) {
      var on = S.em[us][m.k] > 0, cd = S.emCd[us][m.k] > 0 ? S.emCd[us][m.k] : 0, conf = S.ui.emC === m.k, bt;
      if (on) bt = '<button class="btn sm danger" type="button" data-act="emoff" data-k="' + m.k + '">Отменить досрочно</button>';
      else if (cd > 0) bt = '<button class="btn sm" type="button" disabled>Перезарядка ' + cd + ' х.</button>';
      else if (!war) bt = '<button class="btn sm" type="button" disabled>Нужна война</button>';
      else if (conf) bt = '<button class="btn sm danger" type="button" data-act="em" data-k="' + m.k + '">Подтвердить: ввести</button>';
      else bt = '<button class="btn sm primary" type="button" data-act="em" data-k="' + m.k + '">Ввести</button>';
      h += '<div class="dip em' + (on ? ' on' : '') + '"><div class="hd"><span class="emic">' + ico(m.ic) + '</span><span class="nm">' + m.n + '</span>' + (on ? '<span class="chip red">Действует · ' + S.em[us][m.k] + ' х.</span>' : '<span class="chip">' + m.dur + ' х. · пауза ' + m.cd + '</span>') + '</div>' +
        '<p class="em-g"><b>Даёт:</b> ' + m.g + '</p><p class="em-c"><b>Цена:</b> ' + m.c + '</p>' +
        (on || cd > 0 || !war ? '' : '<div class="sub">Сейчас: ' + emPreview(m) + '</div>') +
        '<div class="row">' + bt + '</div></div>';
    });
    return h + '</div>';
  }
  function emBrief() {
    emEnsure();
    var us = S.player, war = warEnemies(us).length > 0, act = EM.filter(function (m) { return S.em[us][m.k] > 0; });
    if (!war && !act.length) return '';
    var h = '<section class="card"><h3 class="h">Чрезвычайные меры</h3>';
    if (act.length) h += '<div class="chips">' + act.map(function (m) { return '<span class="chip red">' + m.n + ' · ' + S.em[us][m.k] + ' х.</span>'; }).join('') + '</div>';
    else h += '<p class="note">Враг давит? Военное положение, мобилизация и другие меры дают сильные бонусы ценой людей и золота.</p>';
    return h + '<div class="row"><button class="btn sm' + (act.length ? '' : ' primary') + '" type="button" data-act="view" data-v="em">' + ico('shield') + 'Управлять мерами</button></div></section>';
  }
  function emAct(k) {
    if (!S || S.phase !== 'play' || S.busy) return;
    if (S.ui.emC !== k) { S.ui.emC = k; renderOverlay(); return; }
    S.ui.emC = '';
    var r = emStart(S.player, k);
    if (!r.ok) { if (r.msg) toast(r.msg, 'warn'); renderOverlay(); return; }
    log(r.msg, true, -1, 'sys');
    SFX.order();
    toast(r.msg + (r.men ? ' В армиях прибавилось ' + U(r.men) + ' див.' : ''), 'warn');
    saveGame(); render(); renderOverlay();
  }
  function emOff(k) {
    if (!S || S.phase !== 'play' || S.busy) return;
    emEnsure();
    var m = emById(k);
    if (!m || !(S.em[S.player][k] > 0)) return;
    S.em[S.player][k] = 0;
    toast('Мера «' + m.n + '» отменена досрочно.', 'good');
    saveGame(); render(); renderOverlay();
  }

  /* ---------- every army has a general ---------- */
  function autoGen(a) {
    if (!a || a.gen > 0) return;
    var f = freeGens(a.owner)[0];
    if (!f && S.gens.filter(function (g) { return g.owner === a.owner; }).length < 8) f = mkGen(a.owner, 1);
    if (f) a.gen = f.id;
  }
  function genFill(c) {
    if (!owned(c).length) return;
    assignGenerals(c);
    S.armies.filter(function (a) { return a.owner === c && !(a.gen > 0); }).forEach(function (a) { autoGen(a); });
  }
  function genTurn() { for (var c = 0; c < NC; c++) genFill(c); }

  /* ---------- trade networks ---------- */
  var NETC = ['#E3B341', '#4DA6EB', '#7BDC8E', '#C58AF2', '#F07F7F'];
  function netInfo() {
    var rs = routes();
    if (S._netRt === rs && S._netI) return S._netI;
    var par = [], i, alive = [], linked = {}, groups = {};
    for (i = 0; i < NC; i++) { par.push(i); alive.push(owned(i).length > 0); }
    function fd(x) { while (par[x] !== x) { par[x] = par[par[x]]; x = par[x]; } return x; }
    rs.forEach(function (r) { if (r.val > 0 && alive[r.a] && alive[r.b]) { par[fd(r.a)] = fd(r.b); linked[r.a] = 1; linked[r.b] = 1; } });
    for (i = 0; i < NC; i++) if (linked[i]) { var k = fd(i); (groups[k] || (groups[k] = [])).push(i); }
    var comps = Object.keys(groups).map(function (k2) { return groups[k2]; }).filter(function (g) { return g.length >= 2; }).sort(function (x, y) { return y.length - x.length || x[0] - y[0]; });
    var of = [], bonus = [];
    for (i = 0; i < NC; i++) { of.push(-1); bonus.push(0); }
    comps.forEach(function (g, ci) { var b = g.length >= 3 ? Math.min(8, (g.length - 2) * 2) : 0; g.forEach(function (c) { of[c] = ci; bonus[c] = b; }); });
    S._netRt = rs; S._netI = { comps: comps, of: of, bonus: bonus };
    return S._netI;
  }
  function netBonus(c) { if (!S || !S.trade || !S.rel || c < 0) return 0; return netInfo().bonus[c] || 0; }
  function netTurn() {
    if (!S.trade) return;
    var ni = netInfo(), us = S.player, i, j;
    if (S.round % 3 === 0) ni.comps.forEach(function (g) {
      if (g.length < 3) return;
      for (i = 0; i < g.length; i++) for (j = i + 1; j < g.length; j++) { var a = g[i], b = g[j]; if (S.rel[a][b] !== 'w' && S.op[a][b] < 55) adjOp(a, b, 1); }
    });
    var n = ni.of[us] >= 0 ? ni.comps[ni.of[us]].length : 0;
    if (S._netN === undefined) S._netN = n;
    else if (n !== S._netN) {
      if (n >= 3 && n > S._netN) news('good', 'Торговая сеть растёт', 'В твоей сети ' + n + ' державы: торговля даёт +' + netBonus(us) + ' зол. в ход.', 'net');
      else if (S._netN >= 3 && n < S._netN) toast('Торговая сеть распалась: в ней теперь ' + n + '.', 'warn');
      S._netN = n;
    }
  }
  function netPos(geo, al, Hh) {
    var bb = landBox(), bw = Math.max(1, bb.x1 - bb.x0), bh = Math.max(1, bb.y1 - bb.y0), pts = {}, pad = 9, it, i, j, home = [];
    al.forEach(function (c, ix) {
      var sx_ = 0, sy_ = 0, n = 0;
      S.provs.forEach(function (q) { if (!q.sea && q.owner === c) { sx_ += q.lx; sy_ += q.ly; n++; } });
      n = n || 1;
      pts[c] = [pad + clamp((sx_ / n - bb.x0) / bw, 0, 1) * (100 - 2 * pad) + (ix % 3 - 1) * 0.4, pad + clamp((sy_ / n - bb.y0) / bh, 0, 1) * (Hh - 2 * pad) + (ix % 2) * 0.4];
      home.push(pts[c].slice());
    });
    if (!geo) {
      var cxm = 0, cym = 0, ord;
      al.forEach(function (c) { cxm += pts[c][0]; cym += pts[c][1]; });
      cxm /= Math.max(1, al.length); cym /= Math.max(1, al.length);
      ord = al.slice().sort(function (a, b) { return Math.atan2(pts[a][1] - cym, pts[a][0] - cxm) - Math.atan2(pts[b][1] - cym, pts[b][0] - cxm); });
      var k0 = ord.indexOf(S.player); if (k0 > 0) ord = ord.slice(k0).concat(ord.slice(0, k0));
      var nn = ord.length, rxx = 33, ryy = Hh / 2 - 15, ring = {};
      ord.forEach(function (c, ix) { var an = -Math.PI / 2 + ix / nn * 2 * Math.PI; ring[c] = nn === 1 ? [50, Hh / 2] : [50 + rxx * Math.cos(an), Hh / 2 + ryy * Math.sin(an)]; });
      return ring;
    }
    var md = 11;
    for (it = 0; it < 90; it++) {
      for (i = 0; i < al.length; i++) for (j = i + 1; j < al.length; j++) {
        var A = pts[al[i]], B = pts[al[j]], dx = B[0] - A[0], dy = B[1] - A[1], d = Math.sqrt(dx * dx + dy * dy) || 0.01;
        if (d < md) { var f = (md - d) / 2 / d; A[0] -= dx * f; A[1] -= dy * f; B[0] += dx * f; B[1] += dy * f; }
      }
      for (i = 0; i < al.length; i++) {
        var Q = pts[al[i]];
        if (!geo) { Q[0] += (home[i][0] - Q[0]) * 0.03; Q[1] += (home[i][1] - Q[1]) * 0.03; }
        Q[0] = clamp(Q[0], pad, 100 - pad); Q[1] = clamp(Q[1], pad, Hh - pad);
      }
    }
    return pts;
  }
  function netChip(c) {
    var ni = netInfo(), i = ni.of[c];
    if (i < 0) return '';
    var n = ni.comps[i].length;
    return '<span class="chip" style="color:' + NETC[i % 5] + ';border-color:' + NETC[i % 5] + '">Сеть ' + (i + 1) + ' · ' + n + (ni.bonus[c] ? ' · +' + ni.bonus[c] : '') + '</span>';
  }
  function netHtml() {
    var us = S.player, al = [], c, d, mode = S.ui.netM || 'all', geo = !!S.ui.netG, i;
    for (c = 0; c < NC; c++) if (owned(c).length) al.push(c);
    var sel = S.ui.netC;
    if (!(sel >= 0) || !owned(sel).length) sel = us;
    var ni = netInfo(), bb = landBox(), Hh = Math.round(clamp(100 * (bb.y1 - bb.y0) / Math.max(1, bb.x1 - bb.x0), 70, 112)), P = netPos(geo, al, Hh);
    function nodeR(c0) { return 4.2 + 3 * Math.sqrt(Math.min(1, owned(c0).length / Math.max(1, NP * 0.4))); }
    var h = head('Сеть связей', true, 'dip') + '<div class="sh-body">';
    h += '<div class="seg" role="group">' + [['all', 'Всё'], ['rel', 'Отношения'], ['trade', 'Торговля']].map(function (o) { return '<button type="button" data-act="netm" data-v="' + o[0] + '" aria-pressed="' + (mode === o[0]) + '">' + o[1] + '</button>'; }).join('') + '</div>';
    var sv = '<svg class="netsvg" viewBox="0 0 100 ' + Hh + '" role="group" aria-label="Схема отношений и торговли между державами">', a, b;
    if (mode !== 'rel') ni.comps.forEach(function (g, ci) {
      if (g.length < 3) return;
      g.forEach(function (c0) { sv += '<circle cx="' + r1(P[c0][0]) + '" cy="' + r1(P[c0][1]) + '" r="' + r1(nodeR(c0) + 3.4) + '" fill="' + NETC[ci % 5] + '" stroke="none" opacity="0.22"/>'; });
    });
    for (i = 0; i < al.length; i++) for (var j = i + 1; j < al.length; j++) {
      a = al[i]; b = al[j];
      var rl = S.rel[a][b], op = S.op[a][b], A = P[a], B = P[b], touch = a === sel || b === sel, mx = (A[0] + B[0]) / 2, my = (A[1] + B[1]) / 2;
      if (mode !== 'trade') {
        if (rl === 'w') {
          sv += '<line x1="' + r1(A[0]) + '" y1="' + r1(A[1]) + '" x2="' + r1(B[0]) + '" y2="' + r1(B[1]) + '" stroke="#D8483B" stroke-width="' + (touch ? 1.5 : 1.1) + '" stroke-dasharray="2.2 1.4" stroke-linecap="round"/>';
          sv += '<text class="ex" x="' + r1(mx) + '" y="' + r1(my + 1.2) + '">✕</text>';
        } else if (rl === 'a') {
          sv += '<line x1="' + r1(A[0]) + '" y1="' + r1(A[1]) + '" x2="' + r1(B[0]) + '" y2="' + r1(B[1]) + '" stroke="#2FAE6C" stroke-width="' + (touch ? 2 : 1.5) + '" stroke-linecap="round"/>';
        } else if (touch || mode === 'rel') {
          sv += '<line x1="' + r1(A[0]) + '" y1="' + r1(A[1]) + '" x2="' + r1(B[0]) + '" y2="' + r1(B[1]) + '" stroke="' + (op >= 0 ? '#5B9BD5' : '#E08A3C') + '" stroke-width="' + r1(0.35 + Math.abs(op) / 100 * 1.1) + '" opacity="' + r1(0.35 + Math.abs(op) / 100 * 0.5) + '" stroke-linecap="round"/>';
        }
        if (touch && rl !== 'w') sv += '<text class="el" x="' + r1(mx) + '" y="' + r1(my - 0.8) + '">' + signed(r0(op)) + '</text>';
      }
      if (mode !== 'rel' && S.trade[a][b] && S.trade[b][a] && rl !== 'w') {
        var rt = routeOf(a, b), val = rt ? rt.val : 0, bad = !!rt && val === 0;
        var dx = B[0] - A[0], dy = B[1] - A[1], dl = Math.sqrt(dx * dx + dy * dy) || 1, cx = mx - dy / dl * 5, cy = my + dx / dl * 5;
        sv += '<path d="M' + r1(A[0]) + ' ' + r1(A[1]) + ' Q' + r1(cx) + ' ' + r1(cy) + ' ' + r1(B[0]) + ' ' + r1(B[1]) + '" fill="none" stroke="' + (bad ? '#D8483B' : '#E3B341') + '" stroke-width="' + (bad ? 0.7 : r1(0.6 + val * 0.4)) + '"' + (bad ? ' stroke-dasharray="1 1.2"' : '') + ' stroke-linecap="round"/>';
        var qx = (A[0] + 2 * cx + B[0]) / 4, qy = (A[1] + 2 * cy + B[1]) / 4;
        sv += '<circle cx="' + r1(qx) + '" cy="' + r1(qy) + '" r="2" fill="' + (bad ? '#D8483B' : '#E3B341') + '" stroke="#1a1408" stroke-width="0.3"/><text class="co" x="' + r1(qx) + '" y="' + r1(qy + 0.85) + '">' + (bad ? '×' : '+' + val) + '</text>';
      }
    }
    al.forEach(function (c0) {
      var q = P[c0], r = nodeR(c0), isSel = c0 === sel;
      sv += '<g class="nd" data-act="netsel" data-c="' + c0 + '" role="button" tabindex="0" aria-label="' + esc(CNAMES[c0]) + '">' +
        '<circle cx="' + r1(q[0]) + '" cy="' + r1(q[1]) + '" r="' + r1(r + 3) + '" fill="transparent" stroke="none"/>' +
        (isSel ? '<circle cx="' + r1(q[0]) + '" cy="' + r1(q[1]) + '" r="' + r1(r + 1.8) + '" fill="none" stroke="var(--accent)" stroke-width="1"/>' : '') +
        '<circle cx="' + r1(q[0]) + '" cy="' + r1(q[1]) + '" r="' + r1(r) + '" fill="' + rgb(COL[c0], 1) + '" stroke="#fff" stroke-width="' + (c0 === us ? 1.4 : 0.7) + '"/>' +
        (c0 === us ? '<text class="st" x="' + r1(q[0]) + '" y="' + r1(q[1] + 1.5) + '">★</text>' : '') +
        '<text x="' + r1(q[0]) + '" y="' + r1(q[1] + r + 3.8) + '">' + esc(CNAMES[c0]) + '</text></g>';
    });
    sv += '</svg>';
    h += '<div class="netw">' + sv + '</div>';
    h += '<div class="netleg"><span><i style="background:#D8483B"></i>война</span><span><i style="background:#2FAE6C"></i>союз</span><span><i style="background:#5B9BD5"></i>симпатия</span><span><i style="background:#E08A3C"></i>неприязнь</span><span><i style="background:#E3B341"></i>торговля</span></div>';
    h += '<button class="row-t" type="button" data-act="netgeo" aria-pressed="' + geo + '"><span><b>Как на карте</b><small>Державы стоят там же, где на карте. Иначе — разведено по схеме</small></span><i class="sw"></i></button>';
    // selected country
    var rs0 = sel !== us ? S.rel[us][sel] : '';
    h += '<div class="dip"><div class="hd">' + flagH(sel) + '<span class="nm">' + CNAMES[sel] + (sel === us ? ' (ты)' : '') + '</span>' + (sel !== us ? '<span class="chip ' + (rs0 === 'w' ? 'bad' : rs0 === 'a' ? 'good' : '') + '">' + RELN[rs0] + '</span>' + tradeChip(sel) : '') + netChip(sel) + '</div>' +
      '<div class="sub">Провинций ' + owned(sel).length + ' · войск ' + troopsOf(sel) + (sel !== us ? ' · отношение к тебе ' + signed(r0(S.op[us][sel])) : '') + '</div><div class="nlist">';
    al.forEach(function (d0) {
      if (d0 === sel) return;
      var rl = S.rel[sel][d0], op = S.op[sel][d0], tr = S.trade[sel][d0] && S.trade[d0][sel] && rl !== 'w';
      h += '<button class="nrow" type="button" data-act="netsel" data-c="' + d0 + '">' + flagH(d0) + '<b>' + CNAMES[d0] + (d0 === us ? ' (ты)' : '') + '</b><span class="chip ' + (rl === 'w' ? 'bad' : rl === 'a' ? 'good' : '') + '">' + RELN[rl] + '</span><span class="nop">' + signed(r0(op)) + '</span>' + (tr ? '<span class="chip good">◆</span>' : '') + '</button>';
    });
    h += '</div>';
    if (sel !== us) h += '<div class="row">' + dipBtns(sel, true) + '</div>';
    h += '</div>';
    // networks
    h += '<div class="sec"><h3 class="h">Торговые сети</h3>';
    if (!ni.comps.length) h += '<p class="note">Живых торговых связей нет. Торговый договор между двумя державами даёт золото; три и больше державы, связанные договорами, образуют сеть с общим бонусом.</p>';
    else {
      ni.comps.forEach(function (g, ci) {
        var bn = g.length >= 3 ? Math.min(8, (g.length - 2) * 2) : 0;
        h += '<div class="dip"><div class="hd"><span class="chip" style="color:' + NETC[ci % 5] + ';border-color:' + NETC[ci % 5] + '">Сеть ' + (ci + 1) + '</span>' + (g.indexOf(us) >= 0 ? '<span class="chip good">твоя</span>' : '') + '<span class="sub">' + g.length + ' держ.</span></div><div class="flags">' +
          g.map(function (c0) { return '<button class="fl" type="button" data-act="netsel" data-c="' + c0 + '">' + flagH(c0) + CNAMES[c0] + '</button>'; }).join('') + '</div><div class="sub">' +
          (bn ? 'Каждому члену +' + bn + ' зол. в ход, отношения внутри сети понемногу растут.' : 'Для бонуса нужны три державы в одной сети.') + '</div></div>';
      });
    }
    var broken = routes().filter(function (r) { return r.val === 0 && (r.cutBy >= 0 || r.pir >= 0 || r.kind === 'none'); });
    if (broken.length) h += '<p class="note">Не работают: ' + broken.map(function (r) { return CNAMES[r.a] + '—' + CNAMES[r.b] + (r.cutBy >= 0 ? ' (блокада ' + CNAMES[r.cutBy] + ')' : r.pir >= 0 ? ' (пираты)' : ' (нет пути)'); }).join(', ') + '.</p>';
    var sug = [];
    al.forEach(function (d0) {
      if (d0 === us || S.rel[us][d0] === 'w' || S.trade[us][d0]) return;
      var via = al.filter(function (x) { return x !== us && x !== d0 && S.trade[us][x] && S.trade[x][d0] && S.rel[x][d0] !== 'w'; }).length;
      sug.push({ d: d0, via: via, op: S.op[us][d0] });
    });
    sug.sort(function (x, y) { return y.via - x.via || y.op - x.op; });
    sug = sug.slice(0, 3);
    if (sug.length) h += '<p class="note">Расширь сеть: договор с державой, у которой уже есть общие партнёры, замыкает связи, и бонус получают все.</p><div class="row">' + sug.map(function (s) { return '<button class="btn sm" type="button" data-act="dip" data-k="trade" data-c="' + s.d + '">' + flagH(s.d) + CNAMES[s.d] + (s.via ? ' · общих ' + s.via : '') + '</button>'; }).join('') + '</div>';
    h += '</div>';
    // matrix
    h += '<div class="sec"><h3 class="h">Матрица отношений</h3><div class="mxw"><table class="mx"><thead><tr><th></th>' + al.map(function (c0) { return '<th><button class="mxb" type="button" data-act="netsel" data-c="' + c0 + '" aria-label="' + esc(CNAMES[c0]) + '">' + flagH(c0) + '</button></th>'; }).join('') + '</tr></thead><tbody>';
    al.forEach(function (a0) {
      h += '<tr><th><button class="mxb" type="button" data-act="netsel" data-c="' + a0 + '" aria-label="' + esc(CNAMES[a0]) + '">' + flagH(a0) + '</button></th>';
      al.forEach(function (b0) {
        if (a0 === b0) { h += '<td class="self">·</td>'; return; }
        var rl = S.rel[a0][b0], op = S.op[a0][b0], tr = S.trade[a0][b0] && S.trade[b0][a0] && rl !== 'w', al_ = r1(0.1 + Math.abs(op) / 100 * 0.55), bg;
        if (rl === 'w') bg = 'rgba(216,72,59,0.78)'; else if (rl === 'a') bg = 'rgba(47,174,108,0.78)'; else bg = op >= 0 ? 'rgba(91,155,213,' + al_ + ')' : 'rgba(224,138,60,' + al_ + ')';
        h += '<td class="' + (rl === 'w' || rl === 'a' ? 'hl' : '') + '" style="background:' + bg + '">' + r0(op) + (tr ? '<sup>◆</sup>' : '') + '</td>';
      });
      h += '</tr>';
    });
    h += '</tbody></table></div><p class="note">Строка — как эта держава относится к столбцу. Красное — война, зелёное — союз, синее — симпатия, оранжевое — неприязнь. ◆ — торговый договор.</p></div>';
    return h + '</div>';
  }

  /* ---------- generals ---------- */
  var GN_F = ['Ар', 'Бо', 'Ве', 'Га', 'Дор', 'Ей', 'Ка', 'Ло', 'Ми', 'Но', 'Ро', 'Са', 'Ти', 'Ус', 'Фо', 'Хе'];
  var GN_L = ['ганов', 'рисов', 'ланов', 'винов', 'мирский', 'дорин', 'сенов', 'торский', 'гарин', 'бекин'];
  var SKK = ['atk', 'def', 'log', 'spd', 'enc'];
  var SKN = { atk: 'Наступление', def: 'Оборона', log: 'Логистика', spd: 'Скорость', enc: 'Окружение' };
  var SKD = { atk: '+5% к силе атаки за уровень', def: '+5% к силе обороны за уровень', log: 'меньше потерь без снабжения, быстрее восстановление', spd: 'быстрее марш, сильнее преследование', enc: 'сильнее фланговые удары' };
  var TRAITS = [
    { k: 'atk', n: 'Штурмовик' }, { k: 'def', n: 'Оборонец' }, { k: 'log', n: 'Логист' }, { k: 'spd', n: 'Манёвренный' }, { k: 'enc', n: 'Охватчик' }
  ];
  function mkGen(owner, lvl) {
    lvl = lvl || 1;
    var t = TRAITS[(Math.random() * TRAITS.length) | 0];
    var g = { id: ++S.gid, owner: owner, name: GN_F[(Math.random() * GN_F.length) | 0] + GN_L[(Math.random() * GN_L.length) | 0], trait: t.k, lvl: lvl, xp: 0, sk: { atk: 0, def: 0, log: 0, spd: 0, enc: 0 } };
    g.sk[t.k] = 1;
    for (var i = 1; i < lvl; i++) { var k = Math.random() < 0.6 ? t.k : SKK[(Math.random() * 5) | 0]; g.sk[k] = Math.min(5, g.sk[k] + 1); }
    S.gens.push(g);
    return g;
  }
  function genById(id) { for (var i = 0; i < S.gens.length; i++) if (S.gens[i].id === id) return S.gens[i]; return null; }
  function genOf(a) { return a && a.gen > 0 ? genById(a.gen) : null; }
  function gsk(a, k) { var g = genOf(a); return g ? g.sk[k] : 0; }
  function traitName(g) { for (var i = 0; i < TRAITS.length; i++) if (TRAITS[i].k === g.trait) return TRAITS[i].n; return ''; }
  function cmdLimit(g) { return g ? 220 + g.lvl * 60 : 120; }
  // generic modifier for command quality: no general -8%, overloaded general -(excess)
  function cmdMult(a) {
    var g = genOf(a);
    if (!g) return 0.92;
    var lim = cmdLimit(g);
    return a.troops <= lim ? 1 : Math.max(0.8, 1 - (a.troops - lim) / lim * 0.25);
  }
  function addXp(a, n) {
    var g = genOf(a);
    if (!g) return;
    g.xp += n;
    while (g.lvl < 10 && g.xp >= g.lvl * 40) {
      g.xp -= g.lvl * 40; g.lvl++;
      var k = Math.random() < 0.6 ? g.trait : SKK[(Math.random() * 5) | 0];
      g.sk[k] = Math.min(5, g.sk[k] + 1);
      if (g.owner === S.player) toast('Генерал ' + g.name + ': уровень ' + g.lvl + ', ' + SKN[k] + ' +1.', 'good');
    }
  }
  function freeGens(c) {
    var used = {};
    S.armies.forEach(function (a) { if (a.gen > 0) used[a.gen] = 1; });
    return S.gens.filter(function (g) { return g.owner === c && !used[g.id]; }).sort(function (x, y) { return y.lvl - x.lvl; });
  }
  function assignGenerals(c) {
    var free = freeGens(c);
    S.armies.filter(function (a) { return a.owner === c && !(a.gen > 0); }).sort(function (x, y) { return y.troops - x.troops; }).forEach(function (a) {
      if (free.length) a.gen = free.shift().id;
    });
  }
  function cycleGen(a) {
    var cur = genOf(a), pool = freeGens(a.owner).slice();
    if (cur) pool.push(cur);
    pool.sort(function (x, y) { return x.id - y.id; });
    if (!pool.length) return 0;
    var idx = cur ? pool.indexOf(cur) : -1, nx = idx + 1;
    a.gen = nx >= pool.length ? 0 : pool[nx].id;
    return a.gen;
  }
  function dropGen(a, die) {
    if (!(a.gen > 0)) return;
    if (die) { var i = S.gens.findIndex(function (g) { return g.id === a.gen; }); if (i >= 0) S.gens.splice(i, 1); }
    a.gen = 0;
  }
  /* ---------- fronts & group orders ---------- */
  function computeFronts() {
    var fr = [], us = S.player;
    S.fronts = fr;
    if (S.phase !== 'play') return fr;
    for (var e = 0; e < NC; e++) {
      if (e === us || !S.alive[e] || !isWar(us, e)) continue;
      var mineP = S.provs.filter(function (p) { return p.owner === us && p.nb.some(function (n) { return S.provs[n].owner === e; }); }), seen = {}, k = 0;
      mineP.forEach(function (p0) {
        if (seen[p0.id]) return;
        var comp = [], q = [p0.id]; seen[p0.id] = 1;
        while (q.length) {
          var id = q.shift(); comp.push(id);
          S.provs[id].nb.forEach(function (n) { if (!seen[n] && mineP.some(function (m) { return m.id === n; })) { seen[n] = 1; q.push(n); } });
        }
        var theirs = {}, edges = [], seaL = [], mx = 0, my = 0, ne = 0;
        comp.forEach(function (id) { S.provs[id].nb.forEach(function (n) {
          if (S.provs[n].owner !== e) return;
          theirs[n] = 1;
          var key = Math.min(id, n) + '_' + Math.max(id, n);
          if (MAP.edges[key] && edges.indexOf(key) < 0) {
            edges.push(key);
            var ln = MAP.edges[key].lines[0], pt = ln[(ln.length / 2) | 0]; mx += pt[0]; my += pt[1]; ne++;
          } else if (MAP.sea[key] && seaL.indexOf(key) < 0) {
            seaL.push(key); var smd = seaMid(MAP.sea[key]); mx += smd[0]; my += smd[1]; ne++;
          }
        }); });
        var th = Object.keys(theirs).map(Number), my_ = 0, their = 0, ids = [];
        S.armies.forEach(function (a) {
          if (friendlyTo(a.owner, us) && comp.indexOf(a.prov) >= 0) { my_ += a.troops * (0.55 + 0.45 * a.org / 100); if (a.owner === us) ids.push(a.id); }
          else if (friendlyTo(a.owner, us) && comp.some(function (c) { return S.provs[c].nb.indexOf(a.prov) >= 0; })) my_ += a.troops * 0.4;
          if (a.owner === e && (th.indexOf(a.prov) >= 0 || comp.indexOf(a.prov) >= 0)) their += a.troops * (0.55 + 0.45 * a.org / 100);
        });
        th.forEach(function (id) { their += S.provs[id].garrison * 0.3; });
        comp.forEach(function (id) { my_ += S.provs[id].garrison * 0.3; });
        fr.push({ id: e + ':' + (k++), enemy: e, mine: comp, theirs: th, edges: edges, sea: seaL, my: Math.round(my_), their: Math.round(their), ratio: (my_ + 5) / (their + 5), armies: ids, cx: ne ? mx / ne : 0, cy: ne ? my / ne : 0 });
      });
    }
    return fr;
  }
  function frontById(id) { var f = S.fronts || []; for (var i = 0; i < f.length; i++) if (f[i].id === id) return f[i]; return null; }
  function selSet() {
    var ids = S.multiMode ? S.multi : (S.selA >= 0 ? [S.selA] : []);
    return ids.map(armyById).filter(function (a) { return a && a.owner === S.player; });
  }
  function groupOrder(arms, pid, sync) {
    var ok = []; undoPush(arms);
    arms.forEach(function (a) {
      a.wait = 0; a.stance = 'atk';
      if (a.prov === pid) { a.route = []; return; }
      var r = findRoute(a, pid);
      if (r) { a.route = r; ok.push(a); } else a.route = [];
    });
    if (sync && ok.length > 1) {
      var T = ok.map(routeTurns), mx = Math.max.apply(null, T);
      ok.forEach(function (a, i) { a.wait = mx - T[i]; });
    }
    return ok.length;
  }
  function frontOrder(f, kind) {
    var arms = S.armies.filter(function (a) { return a.owner === S.player && f.mine.indexOf(a.prov) >= 0; }), n = 0;
    if (kind === 'hold') { arms.forEach(function (a) { a.route = []; a.stance = 'hold'; a.wait = 0; n++; }); }
    else if (kind === 'attack' || kind === 'grind') {
      var tg = f.theirs.map(function (id) { return S.provs[id]; }).sort(function (x, y) { return (x.garrison + (hostileAt(x.id, S.player) ? hostileAt(x.id, S.player).troops : 0)) - (y.garrison + (hostileAt(y.id, S.player) ? hostileAt(y.id, S.player).troops : 0)); });
      arms.filter(function (a) { return a.org >= 40; }).forEach(function (a, i) {
        var t = tg[i % tg.length], r = t && findRoute(a, t.id);
        if (r) { a.route = r; a.stance = 'atk'; a.wait = 0; a.mode = kind === 'grind' ? 'grind' : 'push'; n++; }
      });
    } else if (kind === 'reserve') {
      S.armies.filter(function (a) { return a.owner === S.player && a.stance === 'res' && !a.route.length; }).forEach(function (a) { if (reserveTarget(a, f.mine)) n++; });
    }
    return n;
  }
