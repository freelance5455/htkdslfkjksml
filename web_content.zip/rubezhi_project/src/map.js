  /* ---------- map generation ---------- */
  function assign(sx, sy, mask, ox, oy, lab, sc) {
    var pid = new Int16Array(W * H).fill(-1), n = sx.length, byC = {}, s;
    for (s = 0; s < n; s++) (byC[sc[s]] || (byC[sc[s]] = [])).push(s);
    for (var y = 0; y < H; y++) {
      for (var x = 0; x < W; x++) {
        var i = y * W + x;
        if (!mask[i]) continue;
        var L = byC[lab[i]];
        if (!L) continue;
        var wx = x + ox[y], wy = y + oy[x], best = 1e12, bi = -1;
        for (var k = 0; k < L.length; k++) {
          s = L[k];
          var dx = wx - sx[s], dy = wy - sy[s], d = dx * dx + dy * dy;
          if (d < best) { best = d; bi = s; }
        }
        pid[i] = bi;
      }
    }
    return pid;
  }
  function paintBlob(mask, c) {
    var x0 = Math.max(0, Math.floor(c.x - c.r * 1.3)), x1 = Math.min(W - 1, Math.ceil(c.x + c.r * 1.3)), y0 = Math.max(0, Math.floor(c.y - c.r * 1.3)), y1 = Math.min(H - 1, Math.ceil(c.y + c.r * 1.3));
    for (var y = y0; y <= y1; y++) {
      for (var x = x0; x <= x1; x++) {
        var dx = x - c.x, dy = y - c.y, d2 = dx * dx + dy * dy;
        if (d2 > c.r * c.r * 1.7) continue;
        var an = Math.atan2(dy, dx), rad = c.r * (1 + 0.14 * Math.sin(3 * an + c.p1) + 0.09 * Math.sin(5 * an + c.p2) + 0.05 * Math.sin(9 * an + c.p3));
        if (d2 < rad * rad) mask[y * W + x] = 1;
      }
    }
  }
  // ports: sea links between coastal provinces of different landmasses
  function seaLinks(m) {
    var coast = [], p, q, x, y, i, j;
    for (p = 0; p < NP; p++) coast.push([]);
    for (y = 0; y < H; y++) {
      for (x = 0; x < W; x++) {
        var o = m.pid[y * W + x];
        if (o < 0) continue;
        var edge = x === 0 || y === 0 || x === W - 1 || y === H - 1 || m.pid[y * W + x - 1] < 0 || m.pid[y * W + x + 1] < 0 || m.pid[(y - 1) * W + x] < 0 || m.pid[(y + 1) * W + x] < 0;
        if (edge && (x + 2 * y) % 3 === 0) coast[o].push(x, y);
      }
    }
    function clear(x1, y1, x2, y2) {
      for (var t = 0.12; t < 0.9; t += 0.1) {
        var xx = Math.round(x1 + (x2 - x1) * t), yy = Math.round(y1 + (y2 - y1) * t);
        if (m.pid[yy * W + xx] >= 0) return false;
      }
      return true;
    }
    var cand = [];
    for (p = 0; p < NP; p++) {
      for (q = p + 1; q < NP; q++) {
        if (m.pc[p] === m.pc[q] || !coast[p].length || !coast[q].length) continue;
        if (Math.hypot(m.lx[p] - m.lx[q], m.ly[p] - m.ly[q]) > 260) continue;
        var A = coast[p], B = coast[q], bd = 1e12, bi = 0, bj = 0;
        for (i = 0; i < A.length; i += 2) for (j = 0; j < B.length; j += 2) {
          var dx = A[i] - B[j], dy = A[i + 1] - B[j + 1], d = dx * dx + dy * dy;
          if (d < bd) { bd = d; bi = i; bj = j; }
        }
        var dist = Math.sqrt(bd);
        if (dist > 175 || !clear(A[bi], A[bi + 1], B[bj], B[bj + 1])) continue;
        cand.push({ a: p, b: q, d: dist, x1: A[bi], y1: A[bi + 1], x2: B[bj], y2: B[bj + 1] });
      }
    }
    cand.sort(function (u, v) { return u.d - v.d; });
    var par = [], deg = new Array(NP).fill(0), pairN = {};
    for (i = 0; i < m.ncomp; i++) par.push(i);
    function find(a) { while (par[a] !== a) { par[a] = par[par[a]]; a = par[a]; } return a; }
    function add(c) {
      var lo = c.a, hi = c.b, x1 = c.x1, y1 = c.y1, x2 = c.x2, y2 = c.y2;
      var sg = R() < 0.5 ? -1 : 1, cx = (x1 + x2) / 2 - (y2 - y1) * 0.14 * sg, cy = (y1 + y2) / 2 + (x2 - x1) * 0.14 * sg;
      m.sea[lo + '_' + hi] = { a: lo, b: hi, x1: x1, y1: y1, x2: x2, y2: y2, cx: cx, cy: cy, path: null };
      m.nb[lo].push(hi); m.nb[hi].push(lo); deg[lo]++; deg[hi]++;
      var pk = Math.min(m.pc[lo], m.pc[hi]) + '_' + Math.max(m.pc[lo], m.pc[hi]); pairN[pk] = (pairN[pk] || 0) + 1;
    }
    var used = {};
    cand.forEach(function (c, idx) {
      var ra = find(m.pc[c.a]), rb = find(m.pc[c.b]);
      if (ra !== rb) { par[ra] = rb; add(c); used[idx] = 1; }
    });
    var root = find(0);
    for (i = 1; i < m.ncomp; i++) if (find(i) !== root) return false;
    var extra = 0;
    cand.forEach(function (c, idx) {
      if (used[idx] || extra >= m.ncomp * 2 || c.d > 110 || deg[c.a] >= 2 || deg[c.b] >= 2) return;
      var pk = Math.min(m.pc[c.a], m.pc[c.b]) + '_' + Math.max(m.pc[c.a], m.pc[c.b]);
      if ((pairN[pk] || 0) >= 2) return;
      add(c); extra++;
    });
    return true;
  }

  // keeps the largest piece of every zone with id in [lo, hi), merges the rest into neighbouring zones of the same kind
  function cleanFrags(pid, lo, hi, stk) {
    var lab = new Int32Array(W * H).fill(-1), cp = [], cz = [], nc = 0, i;
    for (i = 0; i < W * H; i++) {
      var pp = pid[i];
      if (pp < lo || pp >= hi || lab[i] >= 0) continue;
      var sp = 0, size = 0; stk[sp++] = i; lab[i] = nc;
      while (sp) {
        var j = stk[--sp]; size++;
        var jx = j % W, jy = (j / W) | 0;
        if (jx > 0 && lab[j - 1] < 0 && pid[j - 1] === pp) { lab[j - 1] = nc; stk[sp++] = j - 1; }
        if (jx < W - 1 && lab[j + 1] < 0 && pid[j + 1] === pp) { lab[j + 1] = nc; stk[sp++] = j + 1; }
        if (jy > 0 && lab[j - W] < 0 && pid[j - W] === pp) { lab[j - W] = nc; stk[sp++] = j - W; }
        if (jy < H - 1 && lab[j + W] < 0 && pid[j + W] === pp) { lab[j + W] = nc; stk[sp++] = j + W; }
      }
      cp.push(pp); cz.push(size); nc++;
    }
    var best = {};
    for (i = 0; i < nc; i++) if (best[cp[i]] === undefined || cz[i] > cz[best[cp[i]]]) best[cp[i]] = i;
    for (i = lo; i < hi; i++) if (best[i] === undefined) return false;
    var frag = new Uint8Array(W * H), any = 0;
    for (i = 0; i < W * H; i++) if (lab[i] >= 0 && best[pid[i]] !== lab[i]) { frag[i] = 1; any++; }
    var guard = 0;
    function ok(n) { return pid[n] >= lo && pid[n] < hi && !frag[n]; }
    while (any > 0 && guard++ < 120) {
      var changed = 0;
      for (i = 0; i < W * H; i++) {
        if (!frag[i]) continue;
        var fx = i % W, fy = (i / W) | 0, nbp = -1;
        if (fx > 0 && ok(i - 1)) nbp = pid[i - 1];
        else if (fx < W - 1 && ok(i + 1)) nbp = pid[i + 1];
        else if (fy > 0 && ok(i - W)) nbp = pid[i - W];
        else if (fy < H - 1 && ok(i + W)) nbp = pid[i + W];
        if (nbp >= 0) { pid[i] = nbp; frag[i] = 0; any--; changed++; }
      }
      if (!changed) break;
    }
    if (any > 0) for (i = 0; i < W * H; i++) if (frag[i]) pid[i] = -1;
    return true;
  }
  // ---- ready-made maps (real outlines, lon/lat) ----
  var PR = {
    europe: { n: 'Европа', c: [15, 51], s: [87, 42], wide: true },
    asia: { n: 'Азия', c: [92, 32], s: [144, 88], wide: true },
    euhist: { n: 'Европа 1914', c: [15, 51], s: [87, 42], wide: true, hist: true },
    america: { n: 'Америка', c: [-80, 8], s: [96, 128], wide: false },
    world: { n: 'Весь мир', c: [10, 12], s: [360, 186], wide: true }
  };
  var PRE_RX = /^(europe|euhist|asia|america|world):/, PRESET = null, HIST = false, PLAKE = null, PCACHE = {};
  function mkUi() { return PR[ST.mapKind] && ST.mapKind !== 'america' ? ST.mapKind : 'seed'; }
  function mapTitle(seed) { var m = PRE_RX.exec(String(seed)); return m ? PR[m[1]].n + ' · ' + String(seed).slice(m[0].length) : String(seed); }
  // ---- historical Europe: real powers around 1914 ----
  var HN = [
    { n: 'Франция', c: [62, 128, 190], p: [2.3, 48.9] }, { n: 'Германия', c: [118, 130, 144], p: [13.4, 52.5] },
    { n: 'Россия', c: [84, 160, 98], p: [37.6, 55.8] }, { n: 'Британия', c: [214, 92, 66], p: [-0.1, 51.5] },
    { n: 'Австро-Венгрия', c: [222, 170, 62], p: [16.4, 48.2] }, { n: 'Османская империя', c: [160, 170, 90], p: [29.0, 41.0] },
    { n: 'Испания', c: [205, 92, 142], p: [-3.7, 40.4] }, { n: 'Италия', c: [58, 170, 164], p: [12.5, 41.9] },
    { n: 'Швеция', c: [90, 110, 200], p: [18.1, 59.3] }, { n: 'Польша', c: [146, 92, 176], p: [21.0, 52.2] }
  ];
  var CN0 = CNAMES.slice(), CL0 = COL.map(function (a) { return a.slice(); });
  function setNations(h) { for (var i = 0; i < 10; i++) { CNAMES[i] = h ? HN[i].n : CN0[i]; var c = h ? HN[i].c : CL0[i]; COL[i][0] = c[0]; COL[i][1] = c[1]; COL[i][2] = c[2]; } }
  var HR = 'Париж,2.3,48.9;Нормандия,0,49.2;Бретань,-3,48;Лотарингия,6.2,48.7;Бургундия,4.8,47.2;Прованс,5.4,43.6;Лангедок,2.5,43.6;Аквитания,-0.6,44.8;Овернь,3,45.5;Лион,4.8,45.7;Шампань,4,49;Лондон,-0.1,51.5;Уэльс,-3.5,52.3;Шотландия,-4,56.5;Йоркшир,-1.2,53.9;Ирландия,-8,53.3;Мидлендс,-1.5,52.5;Корнуолл,-4.8,50.4;Кастилия,-3.7,40.4;Андалусия,-4.5,37.5;Каталония,1.5,41.7;Галисия,-8,42.8;Португалия,-8,39.5;Арагон,-1,41.6;Валенсия,-0.5,39.4;Лаций,12.5,41.9;Ломбардия,9.5,45.5;Венеция,12.3,45.5;Тоскана,11,43.4;Неаполь,14.5,40.8;Сицилия,14,37.5;Пьемонт,7.7,45;Сардиния,9,40;Бранденбург,13.4,52.5;Бавария,11.5,48.5;Саксония,13.5,51;Рейнланд,7.5,51;Восточная Пруссия,21,54.5;Ганновер,9.7,52.4;Вюртемберг,9.2,48.8;Шлезвиг,9.5,54.5;Силезия,17,51;Померания,16,54;Австрия,16.4,48.2;Венгрия,19,47.5;Богемия,14.4,50;Галиция,24,49.5;Трансильвания,24.5,46;Хорватия,16,45.5;Тироль,11.3,47;Сербия,21,44;Босния,18,44;Болгария,25,42.7;Румыния,26,44.5;Албания,20,41;Македония,22,41.5;Греция,22.5,38.5;Фракия,26.5,41.3;Константинополь,29,41;Анатолия,32.5,39.5;Сирия,36.5,35.5;Кавказ,44,42;Крым,34,45;Москва,37.6,55.8;Петербург,30.3,59.9;Смоленск,32,54.8;Киев,30.5,50.5;Новороссия,34,47;Дон,40,48;Поволжье,46,53;Архангельск,40.5,64.5;Карелия,33,62;Курляндия,24,56.8;Эстляндия,25,58.8;Литва,24,55;Белоруссия,28,53.5;Финляндия,25.5,62;Варшава,21,52.2;Краков,19.9,50;Познань,17,52.4;Стокгольм,18,59.3;Осло,10.7,60;Берген,5.3,60.4;Норрланд,17,64;Лапландия,25,67.5;Дания,10,56;Голландия,5,52.3;Фландрия,4.4,51;Швейцария,8.2,46.8;Исландия,-19,64.8;Тюрингия,11,50.9;Пфальц,8.3,49.5;Дунай,26,48'.split(';').map(function (t) { var q = t.split(','); return { n: q[0], x: +q[1], y: +q[2] }; });
  function pxLL(pr, lon, lat) { return [((lon - pr.c[0]) / pr.s[0] + 0.5) * W, (0.5 - (lat - pr.c[1]) / pr.s[1]) * H]; }
  function histCaps(m) {
    var pr = PR[PRESET], used = {}, out = [];
    for (var i = 0; i < NC; i++) {
      var t = pxLL(pr, HN[i].p[0], HN[i].p[1]), bp = -1, bd = 1e12;
      for (var p = 0; p < NP; p++) { if (used[p]) continue; var d = Math.hypot(m.lx[p] - t[0], m.ly[p] - t[1]); if (d < bd) { bd = d; bp = p; } }
      used[bp] = 1; out.push(bp);
    }
    return out;
  }
  function histNames(m, base) {
    var pr = PR[PRESET], pairs = [], i, p, out = base.slice(), uP = {}, uR = {};
    for (p = 0; p < NP; p++) for (i = 0; i < HR.length; i++) { var t = pxLL(pr, HR[i].x, HR[i].y), d = Math.hypot(m.lx[p] - t[0], m.ly[p] - t[1]); if (d < 80 * (W / 640)) pairs.push([d, p, i]); }
    pairs.sort(function (a, b) { return a[0] - b[0]; });
    pairs.forEach(function (q) { if (!uP[q[1]] && !uR[q[2]]) { uP[q[1]] = 1; uR[q[2]] = 1; out[q[1]] = HR[q[2]].n; } });
    return out;
  }
  function gp(s) { return s.split(';').map(function (t) { var q = t.split(','); return [+q[0], +q[1]]; }); }
  var GEO = {
    land: [
      // Африка + Евразия
      '-5.6,36.0;-6.5,36.9;-8.9,37.0;-9.5,38.7;-8.9,41.0;-9.3,43.0;-8.0,43.7;-4.0,43.5;-1.8,43.4;-1.2,46.0;-2.2,47.3;-4.7,48.0;-1.5,48.7;-1.5,49.7;0.2,49.4;1.6,50.9;3.5,51.4;4.5,52.5;5.0,53.2;7.0,53.5;8.5,53.8;8.7,55.0;8.1,56.6;10.6,57.7;10.3,56.0;9.8,55.0;10.0,54.6;10.8,54.0;12.0,54.2;14.0,54.0;16.5,54.5;18.5,54.8;19.5,54.4;21.0,55.2;21.0,56.5;21.8,57.5;23.5,57.0;24.3,57.2;24.5,58.3;23.5,59.0;26.0,59.5;28.0,59.5;30.0,59.9;28.5,60.5;27.0,60.4;23.0,59.8;22.2,60.4;21.4,61.5;21.5,63.0;22.5,64.0;25.0,65.0;25.4,65.7;24.2,65.8;22.0,65.6;21.0,64.5;19.0,63.2;17.4,62.4;17.2,61.0;18.5,60.0;18.9,59.4;17.5,58.7;16.6,57.5;16.4,56.3;14.2,55.4;12.9,55.4;12.4,56.8;11.9,57.8;11.2,59.0;10.6,59.8;10.2,59.0;8.8,58.3;7.0,58.0;5.6,58.7;5.1,60.5;5.2,61.5;6.0,62.5;8.0,63.4;10.5,64.5;12.5,66.0;14.0,67.5;16.0,68.5;18.5,69.8;21.0,70.2;25.0,71.1;28.0,71.1;31.0,70.3;33.0,69.4;36.0,69.0;41.0,67.2;40.0,66.3;37.5,66.0;34.5,66.5;34.5,64.5;37.0,63.8;38.0,64.9;40.5,64.8;44.0,66.0;44.0,68.0;46.0,68.0;53.0,68.8;58.0,68.9;60.0,69.9;66.0,69.5;68.5,72.5;73.0,73.0;80.5,73.5;87.0,75.0;100.0,76.5;104.0,77.7;113.0,75.8;113.5,73.5;125.0,73.5;130.0,71.0;140.0,72.5;150.0,71.5;160.0,70.0;170.0,69.8;180.0,68.9;188.0,66.5;186.0,64.7;179.5,62.5;174.0,61.5;168.0,60.0;163.5,58.5;162.5,56.5;160.5,54.5;158.5,52.5;156.7,51.0;155.7,52.5;156.0,55.0;156.5,57.0;158.5,58.5;160.5,60.5;163.0,62.0;156.0,61.0;152.0,59.5;143.0,59.3;140.0,57.0;137.0,54.5;140.5,53.0;140.0,50.0;140.5,48.0;138.0,46.0;135.5,43.5;131.0,42.5;129.7,41.0;128.0,39.5;129.4,37.0;129.3,35.5;128.5,34.8;126.5,34.4;126.5,36.0;126.7,37.7;125.0,38.0;125.2,39.5;124.4,40.0;121.3,38.9;121.5,40.7;119.5,39.8;118.0,39.2;117.8,38.5;119.0,37.2;120.7,37.8;122.5,37.3;120.8,36.2;119.2,35.0;120.8,32.5;121.9,31.4;122.0,29.7;121.0,28.0;119.7,26.0;118.0,24.5;116.5,23.0;114.2,22.3;111.0,21.4;110.5,20.3;109.5,21.5;108.0,21.6;106.5,20.3;105.8,19.0;106.5,17.5;107.5,16.0;108.8,14.0;109.3,12.0;108.5,11.0;107.0,10.4;105.2,8.6;104.8,9.6;104.0,10.3;102.5,12.2;101.0,12.7;100.9,13.5;99.9,12.0;99.2,10.0;100.3,8.5;100.5,7.5;102.0,6.0;103.4,4.0;103.5,2.7;104.2,1.4;103.5,1.3;101.3,2.8;100.4,4.5;100.3,6.3;98.5,8.0;98.3,9.5;98.7,11.0;98.0,13.0;97.7,16.5;96.0,16.5;94.5,16.0;94.3,18.5;92.5,21.0;91.8,22.3;90.5,22.5;88.5,21.8;87.0,21.4;86.9,20.2;85.0,19.3;83.0,17.5;81.5,16.0;80.3,13.0;79.8,11.0;79.3,10.0;78.2,8.5;77.5,8.1;76.5,9.0;75.8,11.5;74.8,13.0;73.5,16.0;72.8,19.0;72.6,21.0;72.0,21.2;70.3,20.8;69.0,22.3;70.0,23.0;68.5,23.5;67.0,24.5;66.5,25.3;64.0,25.3;61.5,25.1;58.5,25.6;57.3,25.8;56.4,27.2;54.5,26.5;52.5,27.3;51.0,28.8;50.2,30.0;48.8,30.0;48.0,29.5;48.5,28.0;50.2,26.5;50.5,25.3;51.5,25.9;51.5,24.0;54.0,24.2;56.0,25.6;56.4,26.4;56.8,24.5;58.8,23.5;59.8,22.4;58.6,20.5;57.7,19.0;56.5,17.8;55.2,17.0;52.2,15.8;49.0,14.2;45.0,12.8;43.5,12.7;42.8,14.5;42.7,16.5;41.0,19.0;39.1,21.5;38.5,24.0;37.0,26.0;35.0,28.0;34.9,29.5;34.3,27.8;32.6,29.9;33.5,27.5;35.5,23.5;37.2,19.5;39.0,15.5;43.0,12.5;44.5,10.5;47.0,11.2;51.2,11.8;50.8,10.0;49.0,6.5;46.0,2.0;42.0,-1.0;40.0,-3.5;39.2,-6.5;39.5,-10.5;40.5,-14.5;40.5,-16.5;37.0,-18.5;34.8,-19.8;35.5,-23.5;32.8,-25.9;32.8,-28.5;30.0,-31.0;27.0,-33.5;25.5,-34.0;22.0,-34.0;20.0,-34.8;18.4,-34.2;18.0,-31.5;16.5,-28.5;15.0,-26.5;14.5,-22.5;13.5,-20.0;11.8,-17.2;12.2,-14.0;13.5,-12.0;13.2,-9.0;12.2,-6.0;9.5,-2.0;9.3,0.5;9.8,3.5;8.5,4.5;6.0,4.3;4.5,6.0;3.4,6.4;1.0,6.1;-2.0,4.7;-4.0,5.2;-7.5,4.4;-9.5,5.5;-12.5,7.5;-13.3,9.0;-15.0,11.0;-16.7,12.5;-17.5,14.7;-16.4,19.0;-16.9,21.0;-15.0,25.5;-13.0,27.7;-10.0,29.5;-9.8,31.0;-8.5,33.2;-6.8,34.0;-5.5,35.8;-3.0,35.3;0.0,35.8;3.0,36.8;8.0,37.0;10.2,37.3;11.0,37.0;10.3,35.0;10.2,34.0;11.0,33.2;15.0,32.3;15.5,31.2;19.0,30.3;20.0,32.0;22.0,32.8;25.0,31.7;29.0,30.9;31.0,31.5;32.3,31.3;34.4,31.4;35.0,32.8;35.5,33.9;35.9,35.5;36.2,36.7;34.5,36.7;30.5,36.6;29.0,36.7;27.4,37.0;26.8,38.4;26.2,40.0;26.0,40.8;24.0,40.8;22.8,40.5;22.9,39.3;24.0,37.7;23.2,36.8;23.2,36.4;22.4,36.4;21.7,36.8;21.7,38.2;20.5,39.5;19.4,40.4;19.5,41.5;19.4,42.0;18.5,42.5;16.5,43.5;15.0,44.5;14.5,45.1;13.8,44.9;13.6,45.7;12.3,45.3;12.5,44.2;13.6,43.5;14.5,42.2;16.0,41.9;16.9,41.1;18.5,40.1;17.0,40.5;16.7,39.8;17.2,39.0;16.5,38.4;15.7,38.0;15.8,38.5;16.0,39.5;15.7,40.0;14.5,40.6;13.0,41.2;12.0,42.0;11.2,42.8;10.5,43.5;9.0,44.4;7.5,43.8;6.0,43.1;4.5,43.4;3.2,43.1;3.1,42.3;3.2,41.8;2.0,41.3;0.8,40.8;-0.3,39.5;0.0,38.7;-0.8,37.6;-2.0,36.8;-4.4,36.7;-5.4,36.1',
      // Америка
      '-168.0,65.6;-166.0,64.5;-161.0,64.4;-162.0,63.0;-165.0,62.0;-166.0,61.0;-162.0,59.5;-159.0,58.5;-157.0,58.7;-158.5,57.5;-162.0,55.5;-164.5,54.8;-159.0,56.2;-155.0,58.0;-153.5,59.0;-151.5,60.5;-150.0,61.2;-150.5,59.5;-148.0,60.2;-146.0,60.8;-141.0,59.8;-138.0,58.5;-135.0,56.5;-132.0,55.0;-130.0,54.3;-127.5,51.0;-124.8,49.0;-124.0,46.5;-124.0,43.0;-124.5,40.4;-123.0,38.0;-121.9,36.6;-120.6,34.5;-118.5,34.0;-117.1,32.5;-116.5,31.0;-114.5,28.5;-112.5,25.0;-110.5,23.0;-109.5,23.0;-111.0,25.0;-112.5,28.0;-114.8,31.5;-113.0,31.0;-112.2,29.5;-110.7,27.8;-109.2,25.5;-107.0,23.5;-105.5,22.0;-105.3,20.5;-104.0,19.0;-102.0,17.8;-99.8,16.8;-96.5,15.7;-94.5,16.2;-92.0,14.5;-90.5,13.8;-88.0,13.2;-87.5,13.0;-85.8,11.9;-85.7,10.0;-84.8,9.9;-83.5,8.5;-82.5,8.2;-80.5,7.3;-79.5,8.5;-78.2,7.6;-77.5,7.0;-77.5,4.0;-78.8,2.0;-79.0,1.5;-80.0,-0.5;-81.0,-2.2;-80.0,-3.0;-81.3,-4.6;-79.8,-6.8;-78.5,-8.5;-77.0,-12.0;-75.0,-14.5;-72.0,-17.0;-70.5,-18.5;-70.2,-23.0;-71.5,-30.0;-71.6,-33.0;-73.5,-37.0;-73.4,-40.0;-73.8,-43.5;-75.5,-47.0;-74.5,-50.5;-75.0,-52.0;-73.5,-53.5;-71.0,-54.5;-68.0,-55.0;-65.5,-54.7;-66.0,-53.3;-68.4,-52.4;-67.5,-49.5;-66.5,-47.0;-65.5,-45.0;-65.5,-42.5;-63.5,-42.5;-65.0,-41.0;-62.5,-39.5;-62.0,-38.8;-57.5,-38.0;-57.0,-36.0;-57.5,-34.8;-56.0,-34.9;-54.0,-34.8;-52.0,-32.0;-50.0,-30.0;-48.7,-28.0;-48.5,-26.0;-47.0,-24.5;-44.0,-23.0;-41.0,-22.0;-40.0,-19.5;-39.0,-17.5;-39.0,-14.0;-38.5,-13.0;-37.0,-11.0;-35.2,-9.0;-34.9,-7.5;-35.2,-5.2;-37.0,-4.8;-39.0,-3.0;-41.0,-2.8;-44.0,-2.5;-46.0,-1.0;-48.5,-0.5;-50.0,0.5;-50.5,2.0;-52.0,4.5;-54.0,5.8;-57.0,6.0;-58.5,6.8;-60.5,8.5;-62.5,10.7;-64.0,10.5;-66.5,10.6;-68.0,10.7;-70.0,12.2;-71.5,12.4;-72.0,12.0;-74.0,11.2;-75.5,10.8;-75.5,9.5;-76.5,8.5;-77.4,8.7;-77.9,9.0;-79.5,9.6;-81.5,8.8;-82.5,9.5;-83.5,10.8;-83.5,11.5;-83.3,13.0;-83.2,15.0;-84.0,15.8;-86.0,15.9;-88.0,15.8;-88.2,17.0;-87.5,18.0;-87.0,21.2;-88.0,21.5;-90.3,21.1;-90.5,20.0;-91.5,18.7;-93.5,18.3;-94.8,18.2;-96.0,19.0;-97.2,20.5;-97.5,23.0;-97.5,25.5;-97.0,27.5;-95.0,29.0;-93.5,29.7;-91.0,29.2;-89.2,29.0;-89.5,30.2;-88.0,30.3;-86.5,30.4;-85.0,29.7;-83.5,29.6;-82.8,28.5;-82.7,27.5;-82.0,26.5;-81.0,25.2;-80.5,25.0;-80.1,26.5;-80.0,27.5;-80.6,28.5;-81.4,30.0;-81.4,30.7;-80.9,32.0;-79.0,33.5;-77.5,34.5;-76.5,34.7;-75.5,35.3;-76.0,36.9;-75.8,37.5;-75.0,38.5;-74.0,39.5;-74.0,40.5;-72.0,41.0;-70.0,41.7;-70.8,42.6;-68.8,44.0;-67.0,44.8;-65.5,43.6;-61.5,45.0;-60.0,46.0;-61.5,46.5;-64.5,46.2;-65.0,47.8;-64.3,48.8;-60.0,50.2;-57.0,51.3;-55.7,52.5;-56.0,53.5;-58.0,54.5;-60.0,55.5;-61.5,56.5;-62.0,58.5;-65.0,60.0;-68.0,58.5;-70.0,60.5;-72.0,61.0;-73.0,62.0;-75.0,62.3;-78.0,62.3;-78.0,60.0;-77.5,58.5;-78.0,56.5;-79.5,54.5;-79.0,52.5;-79.8,51.5;-81.0,52.0;-82.3,53.0;-82.5,55.0;-85.0,55.3;-88.0,56.5;-92.5,57.0;-94.2,58.7;-93.5,61.0;-90.5,63.5;-87.0,64.5;-86.0,66.5;-85.0,68.5;-90.0,68.5;-95.0,68.3;-100.0,67.8;-105.0,68.0;-108.0,68.0;-115.0,67.8;-120.0,69.0;-126.0,70.0;-130.0,70.0;-135.0,69.5;-141.0,69.6;-148.0,70.3;-156.5,71.3;-161.0,70.2;-166.0,68.8;-166.5,68.0;-163.5,67.0;-162.0,66.2',
      // острова
      '-5.7,50.1;-3.5,50.3;-1.0,50.7;1.4,51.2;1.7,52.6;0.3,53.0;-0.2,54.0;-1.5,55.0;-2.0,55.8;-3.0,56.0;-1.8,57.5;-3.5,57.7;-4.2,58.6;-3.0,58.6;-5.0,58.6;-6.2,57.5;-5.8,56.0;-5.0,55.0;-3.5,54.8;-3.0,53.4;-4.5,53.3;-4.2,52.4;-5.2,51.8;-3.0,51.5;-4.5,51.2',
      '-10.0,51.8;-8.0,51.6;-6.2,52.2;-6.0,53.5;-5.6,54.5;-6.5,55.2;-8.3,55.2;-10.0,54.2;-9.8,53.3;-10.3,52.2',
      '-24.0,65.5;-22.0,66.4;-16.0,66.5;-13.5,65.0;-14.5,64.3;-18.0,63.4;-22.5,63.8',
      '12.4,38.0;15.6,38.3;15.2,36.7;13.0,37.5', '8.2,41.0;9.7,41.1;9.6,39.2;8.5,38.9', '8.6,43.0;9.5,42.8;9.3,41.4', '23.5,35.3;26.3,35.3;24.0,35.0', '32.3,35.0;34.5,35.6;34.0,34.7',
      '130.9,34.0;132.5,35.4;135.0,35.7;136.7,37.3;138.5,37.5;139.8,39.5;140.0,41.0;141.3,41.3;142.0,39.5;141.0,38.0;140.8,36.0;139.8,35.0;138.8,34.7;137.0,34.6;136.5,34.2;135.2,33.5;135.4,34.6;133.0,34.3;131.0,33.9',
      '129.7,33.2;131.8,33.6;131.5,31.5;130.5,31.0', '132.5,33.4;134.5,34.2;134.0,33.2;132.8,32.8',
      '140.0,41.5;141.0,43.2;141.6,45.4;143.5,44.2;145.5,43.3;143.2,42.0;141.0,41.8',
      '142.0,46.0;143.5,46.5;143.0,49.0;143.5,52.0;142.3,54.0;141.8,52.0;142.0,49.0',
      '120.2,22.9;121.0,25.2;121.8,25.0;121.5,23.0;120.8,21.9', '108.7,19.2;110.0,20.1;111.0,19.5;110.2,18.3;109.0,18.3',
      '79.8,9.5;81.5,8.2;81.8,7.3;80.6,6.0;79.8,6.5;79.8,8.0',
      '120.2,16.0;120.5,18.5;122.2,18.3;121.6,15.8;124.0,12.8;122.5,13.3;121.0,13.7;120.7,14.5;120.3,15.5',
      '122.0,7.0;123.5,8.5;125.5,9.7;126.5,7.5;126.0,6.0;124.5,6.4;123.5,7.5',
      '122.0,11.5;124.0,11.8;125.2,11.2;125.2,10.0;123.0,9.2;122.4,10.2',
      '109.0,1.5;111.0,2.0;113.0,3.2;115.5,5.0;117.0,6.8;119.0,5.2;118.0,4.0;118.2,1.0;117.5,-0.5;116.2,-3.0;114.5,-4.0;111.5,-3.5;110.2,-2.5;109.2,-0.8',
      '95.3,5.6;97.7,5.0;100.0,2.0;102.0,1.5;103.8,-0.5;104.7,-2.0;106.0,-3.2;105.8,-5.8;104.5,-5.9;102.3,-4.0;100.8,-2.0;99.0,0.5;97.5,2.5',
      '105.2,-6.8;106.0,-6.0;110.5,-6.9;112.7,-6.9;114.5,-7.7;114.4,-8.7;111.0,-8.3;108.0,-7.8;106.0,-7.4',
      '119.5,-3.5;119.8,0.0;120.5,1.0;124.8,1.5;125.0,1.2;122.5,0.5;121.5,-1.0;123.2,-1.5;123.0,-3.0;121.5,-4.0;122.5,-5.0;120.5,-5.5;119.4,-5.5',
      '131.0,-0.8;134.0,-0.8;135.5,-3.3;138.0,-1.6;141.0,-2.6;144.5,-3.8;147.0,-6.0;147.5,-8.0;150.0,-10.2;147.0,-10.0;144.0,-7.8;141.0,-9.1;138.0,-8.3;137.5,-5.5;134.0,-4.0;132.5,-3.0;131.5,-2.0',
      '49.3,-12.0;50.5,-15.5;49.5,-18.0;47.5,-24.5;45.0,-25.5;43.5,-22.0;44.3,-17.5;46.0,-15.7;48.0,-13.5',
      '113.5,-22.0;114.2,-26.0;115.0,-30.0;115.0,-34.2;118.0,-35.0;123.5,-34.0;126.0,-32.3;131.0,-31.5;134.0,-32.8;137.8,-33.0;138.5,-35.5;140.0,-38.0;143.5,-38.8;146.3,-39.0;148.0,-37.8;150.0,-37.2;151.3,-33.8;153.0,-30.0;153.5,-28.0;153.0,-25.5;150.5,-22.5;148.0,-20.0;146.0,-18.2;145.5,-15.0;143.5,-14.0;142.5,-10.7;141.7,-13.0;141.5,-16.0;140.0,-17.5;137.0,-16.0;135.5,-14.8;136.8,-12.2;132.5,-11.4;130.0,-13.0;129.0,-15.0;126.8,-14.0;125.0,-14.5;123.0,-16.5;121.5,-19.0;118.0,-20.5;116.0,-21.0',
      '144.7,-40.7;148.3,-40.9;148.0,-43.2;146.0,-43.6;145.2,-42.3',
      '172.7,-34.5;174.5,-36.5;175.3,-37.0;178.5,-37.7;177.0,-39.5;175.0,-41.5;174.5,-39.5;173.8,-39.2',
      '172.7,-40.5;174.2,-41.3;173.0,-43.5;171.0,-44.5;169.0,-46.5;166.5,-46.0;168.0,-44.0;171.5,-41.8',
      '-73.0,78.0;-60.0,82.0;-40.0,83.5;-20.0,82.0;-18.0,76.0;-20.0,72.0;-22.0,70.0;-25.0,68.0;-33.0,66.0;-40.0,65.0;-43.0,60.0;-44.0,60.0;-48.0,61.0;-51.0,64.0;-53.5,67.0;-55.0,70.5;-58.0,75.5;-66.0,76.0;-72.0,77.5',
      '-80.0,73.5;-68.0,70.5;-62.0,66.5;-64.5,63.5;-65.5,61.8;-72.0,63.5;-78.0,64.5;-74.0,67.0;-73.5,68.5;-77.0,70.0;-85.0,70.0',
      '-118.0,71.5;-110.0,73.0;-102.0,70.5;-105.0,68.8;-114.0,68.5;-118.0,69.5',
      '-84.9,21.9;-82.5,23.1;-79.5,22.8;-77.0,21.5;-74.2,20.2;-77.7,19.9;-79.8,21.5;-82.5,22.2',
      '-74.4,18.4;-72.7,19.9;-69.0,19.3;-68.4,18.5;-71.5,17.7',
      '-59.3,47.7;-56.0,51.5;-55.5,51.5;-52.8,48.5;-53.5,46.6;-56.0,47.5;-58.5,47.6',
      '51.5,71.0;55.0,73.5;60.0,75.5;68.0,76.8;58.0,75.0;53.0,72.0'
    ],
    lake: [
      '28.0,41.8;28.5,43.5;28.8,44.8;29.7,45.2;30.7,46.5;32.5,46.0;33.0,44.5;34.5,44.5;36.0,45.1;37.5,44.8;38.5,44.3;39.7,43.5;41.5,42.5;41.6,41.6;39.5,41.0;36.5,41.3;35.0,42.0;33.5,42.0;31.5,41.2;29.5,41.2',
      '47.0,44.5;47.0,45.5;48.0,45.8;50.0,46.8;51.5,47.0;53.0,46.5;53.0,45.0;51.0,44.5;51.0,43.0;52.8,41.8;53.0,40.5;54.0,38.5;53.8,37.0;51.0,36.7;49.5,37.5;49.0,38.5;49.5,40.0;50.2,40.4;49.0,41.5;48.5,42.0;47.5,43.0'
    ],
    strait: [[-5.6, 35.95], [43.3, 12.6], [56.5, 26.6]]
  };
  function fillPoly(buf, pts, pr, v) {
    var n = pts.length, xs = new Float64Array(n), ys = new Float64Array(n), i, j, y, miny = 1e9, maxy = -1e9;
    for (i = 0; i < n; i++) { xs[i] = ((pts[i][0] - pr.c[0]) / pr.s[0] + 0.5) * W; ys[i] = (0.5 - (pts[i][1] - pr.c[1]) / pr.s[1]) * H; if (ys[i] < miny) miny = ys[i]; if (ys[i] > maxy) maxy = ys[i]; }
    miny = Math.max(0, Math.floor(miny)); maxy = Math.min(H - 1, Math.ceil(maxy));
    for (y = miny; y <= maxy; y++) {
      var yc = y + 0.5, xi = [];
      for (i = 0, j = n - 1; i < n; j = i++) {
        if ((ys[i] <= yc && ys[j] > yc) || (ys[j] <= yc && ys[i] > yc)) xi.push(xs[i] + (yc - ys[i]) / (ys[j] - ys[i]) * (xs[j] - xs[i]));
      }
      xi.sort(function (a, b) { return a - b; });
      for (i = 0; i + 1 < xi.length; i += 2) {
        var x0 = Math.max(0, Math.ceil(xi[i] - 0.5)), x1 = Math.min(W - 1, Math.floor(xi[i + 1] - 0.5));
        for (var x = x0; x <= x1; x++) buf[y * W + x] = v;
      }
    }
  }
  function presetMask(kind) {
    var key = kind + ':' + W + 'x' + H, c = PCACHE[key];
    if (!c) {
      var pr = PR[kind], land = new Uint8Array(W * H), lake = new Uint8Array(W * H);
      GEO.land.forEach(function (s) { fillPoly(land, gp(s), pr, 1); });
      GEO.lake.forEach(function (s) { fillPoly(lake, gp(s), pr, 1); });
      for (var i = 0; i < W * H; i++) if (lake[i]) land[i] = 0;
      GEO.strait.forEach(function (q) {
        var cx = ((q[0] - pr.c[0]) / pr.s[0] + 0.5) * W, cy = (0.5 - (q[1] - pr.c[1]) / pr.s[1]) * H;
        for (var yy = Math.floor(cy - 2); yy <= Math.ceil(cy + 2); yy++) for (var xx = Math.floor(cx - 2); xx <= Math.ceil(cx + 2); xx++) if (xx >= 0 && yy >= 0 && xx < W && yy < H && (xx - cx) * (xx - cx) + (yy - cy) * (yy - cy) <= 5) land[yy * W + xx] = 0;
      });
      // water pockets cut off from the open sea count as lakes (no sea zones there)
      var wc = new Int32Array(W * H).fill(-1), wsz = [], stk2 = new Int32Array(W * H), nw = 0, best = -1, bsz = 0;
      for (i = 0; i < W * H; i++) {
        if (land[i] || wc[i] >= 0) continue;
        var sp = 0, sz = 0; stk2[sp++] = i; wc[i] = nw;
        while (sp) {
          var j = stk2[--sp], jx = j % W, jy = (j / W) | 0; sz++;
          if (jx > 0 && !land[j - 1] && wc[j - 1] < 0) { wc[j - 1] = nw; stk2[sp++] = j - 1; }
          if (jx < W - 1 && !land[j + 1] && wc[j + 1] < 0) { wc[j + 1] = nw; stk2[sp++] = j + 1; }
          if (jy > 0 && !land[j - W] && wc[j - W] < 0) { wc[j - W] = nw; stk2[sp++] = j - W; }
          if (jy < H - 1 && !land[j + W] && wc[j + W] < 0) { wc[j + W] = nw; stk2[sp++] = j + W; }
        }
        if (sz > bsz) { bsz = sz; best = nw; }
        nw++;
      }
      for (i = 0; i < W * H; i++) if (!land[i] && wc[i] !== best) lake[i] = 1;
      PCACHE = {}; c = PCACHE[key] = { land: land, lake: lake };
    }
    PLAKE = c.lake;
    return new Uint8Array(c.land);
  }
  function tryMap(lvl) {
    var K = KS, mask = new Uint8Array(W * H), main = [{ x: W / 2, y: H / 2, r: 100 * K }], i, k, x, y, ci;
    for (i = 0; i < 5; i++) {
      var b = rp(main), a = R() * 6.2832, d = b.r * 0.72;
      main.push({ x: clamp(b.x + Math.cos(a) * d, (WIDE ? 150 : 130) * K, W - (WIDE ? 150 : 130) * K), y: clamp(b.y + Math.sin(a) * d, (WIDE ? 130 : 150) * K, H - (WIDE ? 130 : 150) * K), r: (48 + R() * 28) * K });
    }
    var blobs = main.slice(), nIsl = lvl > 12 ? 0 : lvl > 6 ? 2 : (NP >= 90 ? 11 : NP >= 55 ? 6 : NP >= 40 ? 4 : 3), tries = 0, nIs = 0;
    blobs.forEach(function (c) { c.p1 = R() * 6.28; c.p2 = R() * 6.28; c.p3 = R() * 6.28; });
    while (nIs < nIsl && tries++ < 600) {
      var r = (26 + R() * 20) * K, m2 = r * 1.3 + 14, ix = m2 + R() * (W - 2 * m2), iy = m2 + R() * (H - 2 * m2), ok = true;
      for (k = 0; k < blobs.length; k++) if (Math.hypot(ix - blobs[k].x, iy - blobs[k].y) < blobs[k].r * 1.3 + r * 1.3 + 22) { ok = false; break; }
      if (ok) { blobs.push({ x: ix, y: iy, r: r, p1: R() * 6.28, p2: R() * 6.28, p3: R() * 6.28 }); nIs++; }
    }
    blobs.forEach(function (c) { paintBlob(mask, c); });
    if (PRESET) mask = presetMask(PRESET);
    // landmasses
    var cl = new Int16Array(W * H).fill(-1), sizes = [], stk = new Int32Array(W * H), nc0 = 0;
    for (i = 0; i < W * H; i++) {
      if (!mask[i] || cl[i] >= 0) continue;
      var sp = 0, size = 0; stk[sp++] = i; cl[i] = nc0;
      while (sp) {
        var j = stk[--sp]; size++;
        var jx = j % W, jy = (j / W) | 0;
        if (jx > 0 && mask[j - 1] && cl[j - 1] < 0) { cl[j - 1] = nc0; stk[sp++] = j - 1; }
        if (jx < W - 1 && mask[j + 1] && cl[j + 1] < 0) { cl[j + 1] = nc0; stk[sp++] = j + 1; }
        if (jy > 0 && mask[j - W] && cl[j - W] < 0) { cl[j - W] = nc0; stk[sp++] = j - W; }
        if (jy < H - 1 && mask[j + W] && cl[j + W] < 0) { cl[j + W] = nc0; stk[sp++] = j + W; }
      }
      sizes.push(size); nc0++;
    }
    var order = sizes.map(function (s, idx) { return idx; }).filter(function (idx) { return sizes[idx] >= (PRESET ? 110 : 300) * K * K; }).sort(function (p1, p2) { return sizes[p2] - sizes[p1]; });
    if (!order.length) return null;
    var remap = new Int16Array(nc0).fill(-1);
    order.forEach(function (idx, n) { remap[idx] = n; });
    for (i = 0; i < W * H; i++) if (cl[i] >= 0) { var rm = remap[cl[i]]; cl[i] = rm; if (rm < 0) mask[i] = 0; }
    var ncomp = order.length, csize = order.map(function (idx) { return sizes[idx]; }), total = csize.reduce(function (t0, v) { return t0 + v; }, 0);
    var cnt = [0], sum = 0;
    for (ci = 1; ci < ncomp; ci++) { var cc = clamp(Math.round(NP * csize[ci] / total), 1, PRESET ? Math.max(4, Math.ceil(NP * 0.28)) : (NP >= 90 ? 7 : 4)); cnt.push(cc); sum += cc; }
    cnt[0] = NP - sum;
    if (cnt[0] < (PRESET ? Math.max(NC + 2, NP * 0.35) : NP * 0.5)) return null;
    var pxs = [];
    for (ci = 0; ci < ncomp; ci++) pxs.push([]);
    for (i = 0; i < W * H; i++) if (cl[i] >= 0) pxs[cl[i]].push(i);
    var seeds = [], sc = [], minD0 = 46 * Math.sqrt(42 / NP) * (K > 1 ? 1.15 : 1);
    for (ci = 0; ci < ncomp; ci++) {
      var md = ci === 0 ? minD0 : minD0 * 0.72, got = 0, tr = 0, startN = seeds.length;
      while (got < cnt[ci] && tr < 30000) {
        tr++;
        var idx2 = pxs[ci][(R() * pxs[ci].length) | 0], px = idx2 % W, py = (idx2 / W) | 0, good = true;
        for (k = startN; k < seeds.length; k++) { var ddx = seeds[k][0] - px, ddy = seeds[k][1] - py; if (ddx * ddx + ddy * ddy < md * md) { good = false; break; } }
        if (good) { seeds.push([px, py]); sc.push(ci); got++; }
        if (tr % 2500 === 0) md -= 3;
      }
      if (got < cnt[ci]) return null;
    }
    var sx = new Float32Array(NP), sy = new Float32Array(NP), scA = new Int16Array(NP);
    seeds.forEach(function (s, j) { sx[j] = s[0]; sy[j] = s[1]; scA[j] = sc[j]; });
    var ox = new Float32Array(H), oy = new Float32Array(W);
    for (y = 0; y < H; y++) ox[y] = 9 * Math.sin(y * 0.045 + 1.3) + 5 * Math.sin(y * 0.11 + 0.4);
    for (x = 0; x < W; x++) oy[x] = 9 * Math.sin(x * 0.04 + 0.7) + 5 * Math.sin(x * 0.1 + 2);
    var pid, it;
    for (it = 0; it < 2; it++) {
      pid = assign(sx, sy, mask, ox, oy, cl, scA);
      var cn = new Float32Array(NP), sumx = new Float32Array(NP), sumy = new Float32Array(NP);
      for (y = 0; y < H; y += 2) {
        for (x = 0; x < W; x += 2) {
          var p0 = pid[y * W + x];
          if (p0 < 0) continue;
          cn[p0]++; sumx[p0] += x + ox[y]; sumy[p0] += y + oy[x];
        }
      }
      for (i = 0; i < NP; i++) if (cn[i] > 0) { sx[i] = sumx[i] / cn[i]; sy[i] = sumy[i] / cn[i]; }
    }
    pid = assign(sx, sy, mask, ox, oy, cl, scA);

    var lab = new Int32Array(W * H).fill(-1), compPid = [], compSize = [], nc = 0;
    for (i = 0; i < W * H; i++) {
      if (pid[i] < 0 || lab[i] >= 0) continue;
      var sp2 = 0, size2 = 0, pp = pid[i];
      stk[sp2++] = i; lab[i] = nc;
      while (sp2) {
        var j2 = stk[--sp2]; size2++;
        var kx = j2 % W, ky = (j2 / W) | 0;
        if (kx > 0 && lab[j2 - 1] < 0 && pid[j2 - 1] === pp) { lab[j2 - 1] = nc; stk[sp2++] = j2 - 1; }
        if (kx < W - 1 && lab[j2 + 1] < 0 && pid[j2 + 1] === pp) { lab[j2 + 1] = nc; stk[sp2++] = j2 + 1; }
        if (ky > 0 && lab[j2 - W] < 0 && pid[j2 - W] === pp) { lab[j2 - W] = nc; stk[sp2++] = j2 - W; }
        if (ky < H - 1 && lab[j2 + W] < 0 && pid[j2 + W] === pp) { lab[j2 + W] = nc; stk[sp2++] = j2 + W; }
      }
      compPid.push(pp); compSize.push(size2); nc++;
    }
    var bestComp = new Array(NP).fill(-1), c2;
    for (c2 = 0; c2 < nc; c2++) {
      var q = compPid[c2];
      if (bestComp[q] < 0 || compSize[c2] > compSize[bestComp[q]]) bestComp[q] = c2;
    }
    for (i = 0; i < NP; i++) if (bestComp[i] < 0) return null;
    var frag = new Uint8Array(W * H), any = 0;
    for (i = 0; i < W * H; i++) if (lab[i] >= 0 && bestComp[pid[i]] !== lab[i]) { frag[i] = 1; any++; }
    var guard = 0;
    while (any > 0 && guard++ < 80) {
      var changed = 0;
      for (i = 0; i < W * H; i++) {
        if (!frag[i]) continue;
        var fx = i % W, fy = (i / W) | 0, nbp = -1;
        if (fx > 0 && pid[i - 1] >= 0 && !frag[i - 1]) nbp = pid[i - 1];
        else if (fx < W - 1 && pid[i + 1] >= 0 && !frag[i + 1]) nbp = pid[i + 1];
        else if (fy > 0 && pid[i - W] >= 0 && !frag[i - W]) nbp = pid[i - W];
        else if (fy < H - 1 && pid[i + W] >= 0 && !frag[i + W]) nbp = pid[i + W];
        if (nbp >= 0) { pid[i] = nbp; frag[i] = 0; any--; changed++; }
      }
      if (!changed) break;
    }
    if (any > 0) for (i = 0; i < W * H; i++) if (frag[i]) pid[i] = -1;

    // ---- sea zones: big water provinces ----
    var NS = clamp(Math.round(NP / 6), 5, NP > 160 ? 8 : 16), NT = NP + NS, wat = [];
    for (i = 0; i < W * H; i++) if (pid[i] < 0) wat.push(i);
    if (wat.length < 8000) return null;
    var ssx = [], ssy = [], smd = Math.sqrt(wat.length / NS) * 0.75, trS = 0;
    while (ssx.length < NS && trS < 20000) {
      trS++;
      var wi = wat[(R() * wat.length) | 0], wx0 = wi % W, wy0 = (wi / W) | 0, gd = true;
      if (PLAKE && PLAKE[wi]) continue;
      for (k = 0; k < ssx.length; k++) { var ex0 = ssx[k] - wx0, ey0 = ssy[k] - wy0; if (ex0 * ex0 + ey0 * ey0 < smd * smd) { gd = false; break; } }
      if (gd) { ssx.push(wx0); ssy.push(wy0); }
      if (trS % 1500 === 0) smd *= 0.85;
    }
    if (ssx.length < NS) return null;
    for (i = 0; i < wat.length; i++) {
      var q0 = wat[i], qx = q0 % W, qy = (q0 / W) | 0, wxx = qx + ox[qy], wyy = qy + oy[qx], bb = 1e12, bs = 0;
      for (k = 0; k < NS; k++) { var dx2 = wxx - ssx[k], dy2 = wyy - ssy[k], dd2 = dx2 * dx2 + dy2 * dy2; if (dd2 < bb) { bb = dd2; bs = k; } }
      pid[q0] = NP + bs;
    }
    if (!cleanFrags(pid, NP, NT, stk)) return null;

    var adj = [];
    for (i = 0; i < NT; i++) adj.push({});
    for (y = 0; y < H; y++) {
      for (x = 0; x < W; x++) {
        var a0 = pid[y * W + x];
        if (a0 < 0) continue;
        if (x < W - 1) { var r0 = pid[y * W + x + 1]; if (r0 >= 0 && r0 !== a0) { adj[a0][r0] = 1; adj[r0][a0] = 1; } }
        if (y < H - 1) { var d0 = pid[(y + 1) * W + x]; if (d0 >= 0 && d0 !== a0) { adj[a0][d0] = 1; adj[d0][a0] = 1; } }
      }
    }
    var nb = adj.map(function (o) { return Object.keys(o).map(Number); }), lnb = [];
    for (i = 0; i < NP; i++) lnb.push(nb[i].filter(function (q) { return q < NP; }));
    for (ci = 0; ci < ncomp; ci++) {
      var first = -1, count = 0;
      for (i = 0; i < NP; i++) if (scA[i] === ci) { count++; if (first < 0) first = i; }
      var seen = {}, qq = [first], got2 = 0; seen[first] = 1;
      while (qq.length) { var cur = qq.pop(); got2++; for (var z = 0; z < lnb[cur].length; z++) { var n2 = lnb[cur][z]; if (!seen[n2]) { seen[n2] = 1; qq.push(n2); } } }
      if (got2 !== count) return null;
    }
    var seenS = {}, qs = [NP], cntS = 0; seenS[NP] = 1;
    while (qs.length) { var us0 = qs.pop(); cntS++; for (var z2 = 0; z2 < nb[us0].length; z2++) { var v0 = nb[us0][z2]; if (v0 >= NP && !seenS[v0]) { seenS[v0] = 1; qs.push(v0); } } }
    if (cntS !== NS) return null;
    var cs = new Float32Array(NT), mx = new Float32Array(NT), my = new Float32Array(NT);
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) { var pp2 = pid[y * W + x]; if (pp2 >= 0) { cs[pp2]++; mx[pp2] += x; my[pp2] += y; } }
    var lx = new Float32Array(NT), ly = new Float32Array(NT), bd = new Float32Array(NT).fill(1e12);
    for (i = 0; i < NT; i++) if (cs[i] > 0) { mx[i] /= cs[i]; my[i] /= cs[i]; }
    for (y = 0; y < H; y++) {
      for (x = 0; x < W; x++) {
        var p3 = pid[y * W + x];
        if (p3 < 0) continue;
        var ex = x - mx[p3], ey = y - my[p3], dd = ex * ex + ey * ey;
        if (dd < bd[p3]) { bd[p3] = dd; lx[p3] = x; ly[p3] = y; }
      }
    }
    // sea lanes: coastal provinces of different landmasses that share a sea zone (cost 2) or neighbouring zones (cost 3). Used for supply.
    var lane = [], pI;
    for (pI = 0; pI < NP; pI++) {
      var out = [], seenL = {}, z1 = nb[pI].filter(function (q) { return q >= NP; }), z2l = [];
      seenL[pI] = 1;
      z1.forEach(function (zz) { nb[zz].forEach(function (q) { if (q < NP && !seenL[q] && scA[q] !== scA[pI]) { seenL[q] = 1; out.push({ to: q, cost: 2 }); } else if (q >= NP && z1.indexOf(q) < 0 && z2l.indexOf(q) < 0) z2l.push(q); }); });
      z2l.forEach(function (zz) { nb[zz].forEach(function (q) { if (q < NP && !seenL[q] && scA[q] !== scA[pI]) { seenL[q] = 1; out.push({ to: q, cost: 3 }); } }); });
      lane.push(out);
    }
    return { pid: pid, nb: nb, lnb: lnb, lx: lx, ly: ly, decor: [], pc: scA, sea: {}, ncomp: ncomp, nl: NP, nt: NT, lane: lane };
  }
  function genMap() { for (var t = 0; t < 26; t++) { var m = tryMap(t); if (m) return m; } return null; }
  function uniqueNames(n) {
    var used = {}, out = [];
    while (out.length < n) { var nm = rp(PRE) + rp(SUF); if (!used[nm]) { used[nm] = 1; out.push(nm); } }
    return out;
  }
  // islands go whole to one country; only a few big ones are shared by 2-3
  function assignIslands(m, owner) {
    var cnt = new Array(NC).fill(0), comps = {}, p, c, i, j, q;
    for (p = 0; p < NP; p++) { if (owner[p] >= 0) cnt[owner[p]]++; else if (m.pc[p] !== 0) (comps[m.pc[p]] || (comps[m.pc[p]] = [])).push(p); }
    var ids = Object.keys(comps).map(Number);
    for (i = ids.length - 1; i > 0; i--) { j = (R() * (i + 1)) | 0; var tmp = ids[i]; ids[i] = ids[j]; ids[j] = tmp; }
    ids.forEach(function (id) {
      var list = comps[id], n = list.length, kk = 1;
      if (n >= 3 && R() < (n >= 5 ? 0.55 : n === 4 ? 0.45 : 0.3)) kk = (n >= 5 && R() < 0.4) ? 3 : 2;
      kk = Math.min(kk, NC);
      var sc = [];
      for (c = 0; c < NC; c++) {
        var md = 1e12;
        for (q = 0; q < NP; q++) {
          if (owner[q] !== c) continue;
          for (j = 0; j < n; j++) { var dx = m.lx[q] - m.lx[list[j]], dy = m.ly[q] - m.ly[list[j]], dd = dx * dx + dy * dy; if (dd < md) md = dd; }
        }
        sc.push({ c: c, s: Math.sqrt(md) * (1 + 0.07 * cnt[c]) * (0.8 + 0.4 * R()) });
      }
      sc.sort(function (a, b) { return a.s - b.s; });
      if (kk === 1) { list.forEach(function (x) { owner[x] = sc[0].c; }); cnt[sc[0].c] += n; return; }
      var seeds = [list[(R() * n) | 0]];
      while (seeds.length < kk) {
        var bi = -1, bd = -1;
        list.forEach(function (x) {
          if (seeds.indexOf(x) >= 0) return;
          var md2 = 1e12; seeds.forEach(function (s0) { md2 = Math.min(md2, Math.hypot(m.lx[x] - m.lx[s0], m.ly[x] - m.ly[s0])); });
          if (md2 > bd) { bd = md2; bi = x; }
        });
        seeds.push(bi);
      }
      seeds.forEach(function (s0, si) { owner[s0] = sc[si].c; cnt[sc[si].c]++; });
      var left2 = n - kk, g2 = 0;
      while (left2 > 0 && g2++ < 400) {
        var got = 0;
        for (var si2 = 0; si2 < kk && left2 > 0; si2++) {
          var fr = [];
          list.forEach(function (x) { if (owner[x] === sc[si2].c) m.lnb[x].forEach(function (y) { if (owner[y] < 0 && m.pc[y] === id) fr.push(y); }); });
          if (fr.length) { var pick = rp(fr); owner[pick] = sc[si2].c; cnt[sc[si2].c]++; left2--; got++; }
        }
        if (!got) break;
      }
      list.forEach(function (x) { if (owner[x] < 0) { owner[x] = sc[0].c; cnt[sc[0].c]++; } });
    });
  }
  function buildWorld(seedStr, legacy) {
    R = mulberry32(hashSeed(seedStr));
    var pm0 = PRE_RX.exec(String(seedStr)); PRESET = pm0 ? pm0[1] : null; PLAKE = null; HIST = !!(PRESET && PR[PRESET].hist); setNations(HIST);
    var m = genMap(), nf0 = 0;
    while (!m) { if (PRESET && ++nf0 > 3) { PRESET = null; PLAKE = null; HIST = false; setNations(false); } m = genMap(); }
    MAP = m;
    var caps = [], c, p, i, mainP = [];
    for (p = 0; p < NP; p++) if (m.pc[p] === 0) mainP.push(p);
    if (HIST) caps = histCaps(m); else caps.push(mainP[(R() * mainP.length) | 0]);
    while (caps.length < NC) {
      var bi = -1, bdist = -1;
      for (var mi = 0; mi < mainP.length; mi++) {
        p = mainP[mi];
        var md = 1e12;
        caps.forEach(function (cp) { var dx = m.lx[p] - m.lx[cp], dy = m.ly[p] - m.ly[cp]; md = Math.min(md, dx * dx + dy * dy); });
        if (md > bdist) { bdist = md; bi = p; }
      }
      caps.push(bi);
    }
    var owner = new Array(NP).fill(-1);
    caps.forEach(function (cp, ci) { owner[cp] = ci; });
    var left = (legacy ? NP : mainP.length) - NC, guard = 0, gmode = 0;
    while (left > 0 && guard++ < 6000) {
      var gained = 0;
      for (c = 0; c < NC && left > 0; c++) {
        var fr = [];
        for (p = 0; p < NP; p++) if (owner[p] === c) (gmode ? m.lane[p].map(function (l) { return l.to; }) : m.lnb[p]).forEach(function (q) { if (owner[q] < 0) fr.push(q); });
        if (fr.length) { owner[rp(fr)] = c; left--; gained++; }
      }
      if (!gained) { if (gmode) break; gmode = 1; }
    }
    if (!legacy) assignIslands(m, owner);
    for (p = 0; p < NP; p++) if (owner[p] < 0) { var bo = -1, bdn = 1e12; for (var q2 = 0; q2 < NP; q2++) if (owner[q2] >= 0) { var dn = Math.hypot(m.lx[p] - m.lx[q2], m.ly[p] - m.ly[q2]); if (dn < bdn) { bdn = dn; bo = owner[q2]; } } owner[p] = bo; }
    var names = uniqueNames(NP), provs = [];
    if (HIST) names = histNames(m, names);
    for (p = 0; p < NP; p++) {
      var isCap = caps.indexOf(p) >= 0, r = R(), set = isCap ? 2 : (r < 0.14 ? 2 : r < 0.45 ? 1 : 0), t = R();
      var ter = t < 0.28 ? 0 : t < 0.55 ? 1 : t < 0.8 ? 2 : 3;
      if (set >= 1 && ter >= 2) ter = R() < 0.5 ? 0 : 1;
      var pop = set === 2 ? rr(30, 50) : set === 1 ? rr(14, 24) : rr(5, 10);
      if (isCap) pop = 60;
      var pr = { id: p, name: names[p], owner: owner[p], terrain: ter, set: set, pop: Math.round(pop), capital: isCap, nb: m.nb[p], lnb: m.lnb[p], lx: m.lx[p], ly: m.ly[p], sup: true, from: -1, rem: 0, recruited: false, occ: 0, occBy: -1, besieged: false, fac: isCap ? 2 : set === 2 ? 1 : set === 1 ? (R() < 0.4 ? 1 : 0) : 0, civ: isCap ? 1 : set === 2 ? 1 : set === 1 ? (R() < 0.3 ? 1 : 0) : 0, dev: 0, pol: 0, unr: 0, eth: {}, sea: false, fd: 0, hot: false, port: m.nb[p].length > m.lnb[p].length, isl: m.pc[p] !== 0 };
      pr.garrison = gcap(pr); pr.rem = -1; pr.from = -1;
      provs.push(pr);
    }
    for (var si = NP; si < m.nt; si++) {
      provs.push({ id: si, name: SEAN[(si - NP) % SEAN.length] + ' море', owner: -2, terrain: 4, set: 0, pop: 0, capital: false, nb: m.nb[si], lnb: [], lx: m.lx[si], ly: m.ly[si], sup: false, from: -1, rem: -1, recruited: true, occ: 0, occBy: -1, besieged: false, garrison: 0, fac: 0, civ: 0, dev: 0, fd: 0, hot: false, port: false, isl: false, sea: true });
    }
    // decor
    var pix = [];
    for (p = 0; p < NP; p++) pix.push([]);
    for (i = 0; i < W * H; i++) if (m.pid[i] >= 0 && m.pid[i] < NP) pix[m.pid[i]].push(i);
    for (p = 0; p < NP; p++) {
      var arr = pix[p], n = clamp(Math.round(arr.length / 380), 4, 14), items = [], tries = 0, tr = provs[p].terrain;
      while (items.length < n && tries++ < n * 16) {
        var idx = arr[(R() * arr.length) | 0], x = idx % W, y = (idx / W) | 0;
        if (x < 7 || y < 7 || x >= W - 7 || y >= H - 7) continue;
        if (m.pid[idx - 6] !== p || m.pid[idx + 6] !== p || m.pid[idx - 6 * W] !== p || m.pid[idx + 6 * W] !== p) continue;
        if (Math.hypot(x - m.lx[p], y - m.ly[p]) < 24) continue;
        var bad = false;
        for (i = 0; i < items.length; i++) if (Math.hypot(items[i].x - x, items[i].y - y) < 13) { bad = true; break; }
        if (bad) continue;
        var q = R(), kind;
        if (tr === 2) kind = q < 0.85 ? 0 : 3;
        else if (tr === 3) kind = q < 0.8 ? 1 : 0;
        else if (tr === 1) kind = q < 0.7 ? 2 : q < 0.9 ? 3 : 0;
        else kind = q < 0.55 ? 3 : q < 0.85 ? 0 : 2;
        items.push({ x: x, y: y, k: kind, s: 0.8 + R() * 0.5 });
      }
      items.sort(function (a, b) { return a.y - b.y; });
      m.decor.push(items);
    }
    m.edges = buildEdges(m.pid);
    assignRes(provs, seedStr);
    return provs;
  }
  // resources use their own generator so old seeds and saves keep the same map
  function assignRes(provs, seedStr) {
    var rr2 = mulberry32(hashSeed(String(seedStr) + ':res'));
    provs.forEach(function (q) {
      q.res = -1;
      if (q.sea || q.capital) return;
      if (rr2() > 0.24) return;
      var t = q.terrain, w = [t === 1 ? 3.2 : t === 0 ? 1.4 : 0.6, t === 3 ? 3 : t === 2 ? 2 : 0.5, t === 3 ? 2.2 : 0.9, t === 0 ? 1.8 : t === 2 ? 1.4 : 0.8], s = w[0] + w[1] + w[2] + w[3], r = rr2() * s, k = 0;
      while (k < 3 && r > w[k]) { r -= w[k]; k++; }
      q.res = k;
    });
  }
  function resCount(c, k) { var n = 0; S.provs.forEach(function (q) { if (q.owner === c && q.res === k && q.sup && !(q.occ > 0)) n++; }); return n; }
  function drawRes(k, x, y, m) {
    var q = 4.6 * m, i;
    ctx.lineWidth = 1.3; ctx.strokeStyle = 'rgba(6,12,20,0.9)'; ctx.fillStyle = RES[k].col;
    ctx.beginPath();
    if (k === 0) ctx.ellipse(x, y, q * 0.75, q * 1.05, 0.6, 0, 6.2832);
    else if (k === 1) { for (i = 0; i < 6; i++) { var an = i * 1.0472 + 0.5236; if (i) ctx.lineTo(x + Math.cos(an) * q, y + Math.sin(an) * q); else ctx.moveTo(x + Math.cos(an) * q, y + Math.sin(an) * q); } ctx.closePath(); }
    else if (k === 2) ctx.arc(x, y, q, 0, 6.2832);
    else { ctx.moveTo(x, y - q * 1.1); ctx.lineTo(x + q * 1.05, y + q * 0.8); ctx.lineTo(x - q * 1.05, y + q * 0.8); ctx.closePath(); }
    ctx.fill(); ctx.stroke();
    if (k === 2) { ctx.fillStyle = 'rgba(120,70,0,0.85)'; ctx.beginPath(); ctx.arc(x, y, q * 0.4, 0, 6.2832); ctx.fill(); }
  }
  /* ---------- taxes ---------- */
  function taxLvl(c) { var v = S && S.tax ? S.tax[c] : 1; return v === 0 || v === 2 ? v : 1; }
  function growK(p) { return ({ slow: 0.6, normal: 1, fast: 1.3 }[ST.growSp] || 1) * (ST.villSlow && !p.set && !p.capital ? 0.35 : 1); }
  function growMul(q) { return [1.1, 1, 0.88][taxLvl(q.owner)] * (q.res === 0 ? 1.3 : 1); }
  function taxHtml() {
    var t = taxLvl(S.player);
    return '<div class="fld taxf"><span class="lbl">Налоги</span><div class="seg" role="group">' + TAXN.map(function (n, i) { return '<button type="button" data-act="tax" data-v="' + i + '" aria-pressed="' + (t === i) + '">' + n + '</button>'; }).join('') + '</div><small>' +
      ['Доход с населения −25%: люди спокойнее и быстрее растут.', 'Без особенностей.', 'Доход с населения +30%, но растёт недовольство и замедляется рост.'][t] + '</small></div>';
  }
  function taxTurn() {
    for (var c = 0; c < NC; c++) {
      var lv = taxLvl(c);
      if (lv === 1 || !owned(c).length) continue;
      owned(c).forEach(function (q) {
        if (lv === 2 && (q.unr || 0) < 55) q.unr = Math.min(55, (q.unr || 0) + 1.5);
        else if (lv === 0 && (q.unr || 0) > 0) q.unr = Math.max(0, q.unr - 1.2);
      });
    }
  }
  function aiTax(c) {
    var os = owned(c), un = 0;
    os.forEach(function (q) { un += q.unr || 0; });
    un = os.length ? un / os.length : 0;
    S.tax[c] = un > 35 ? 0 : (S.gold[c] < 40 && un < 25) ? 2 : 1;
  }
  /* ---------- borders: pixel edges -> chained, smoothed polylines ---------- */
  function chainSegs(seg) {
    var n = seg.length / 4, used = new Uint8Array(n), at = {}, i, k, out = [];
    function key(x, y) { return x * 1000 + y; }
    for (i = 0; i < n; i++) {
      var k1 = key(seg[4 * i], seg[4 * i + 1]), k2 = key(seg[4 * i + 2], seg[4 * i + 3]);
      (at[k1] || (at[k1] = [])).push(i); (at[k2] || (at[k2] = [])).push(i);
    }
    for (i = 0; i < n; i++) {
      if (used[i]) continue;
      used[i] = 1;
      var mid = [[seg[4 * i], seg[4 * i + 1]], [seg[4 * i + 2], seg[4 * i + 3]]], fw = [], bk = [];
      for (var dir = 0; dir < 2; dir++) {
        var list = dir ? bk : fw, end = dir ? mid[0] : mid[1];
        for (;;) {
          var cand = at[key(end[0], end[1])], nx = -1;
          for (k = 0; k < cand.length; k++) if (!used[cand[k]]) { nx = cand[k]; break; }
          if (nx < 0) break;
          used[nx] = 1;
          var a = [seg[4 * nx], seg[4 * nx + 1]], b = [seg[4 * nx + 2], seg[4 * nx + 3]];
          var np = (a[0] === end[0] && a[1] === end[1]) ? b : a;
          list.push(np); end = np;
        }
      }
      var pts = bk.reverse().concat(mid, fw), f = pts[0], l = pts[pts.length - 1];
      out.push({ pts: pts, closed: pts.length > 3 && f[0] === l[0] && f[1] === l[1] });
    }
    return out;
  }
  function smoothPts(pts, closed, iters) {
    var n = pts.length, it, i;
    if (closed) { pts = pts.slice(0, n - 1); n--; }
    if (n < 4) return closed ? pts.concat([pts[0]]) : pts;
    for (it = 0; it < iters; it++) {
      var q = new Array(n);
      for (i = 0; i < n; i++) {
        if (!closed && (i === 0 || i === n - 1)) { q[i] = pts[i]; continue; }
        var a = pts[(i - 1 + n) % n], p = pts[i], b = pts[(i + 1) % n];
        q[i] = [(a[0] + 2 * p[0] + b[0]) / 4, (a[1] + 2 * p[1] + b[1]) / 4];
      }
      pts = q;
    }
    if (closed) pts.push(pts[0]);
    return pts;
  }
  function buildEdges(pid) {
    var E = {}, x, y, i, a, key, e;
    function add(a2, b2, x1, y1, x2, y2) {
      var lo = a2 < b2 ? a2 : b2, hi = a2 < b2 ? b2 : a2;
      key = lo + '_' + hi;
      e = E[key] || (E[key] = { a: lo, b: hi, seg: [], lines: null, path: null });
      e.seg.push(x1, y1, x2, y2);
    }
    for (y = 0; y < H; y++) {
      for (x = 0; x < W; x++) {
        i = y * W + x; a = pid[i];
        if (a < 0) {
          if (x < W - 1 && pid[i + 1] >= 0) add(-1, pid[i + 1], x + 1, y, x + 1, y + 1);
          if (y < H - 1 && pid[i + W] >= 0) add(-1, pid[i + W], x, y + 1, x + 1, y + 1);
          continue;
        }
        if (x < W - 1 && pid[i + 1] !== a) add(a, pid[i + 1], x + 1, y, x + 1, y + 1);
        if (y < H - 1 && pid[i + W] !== a) add(a, pid[i + W], x, y + 1, x + 1, y + 1);
      }
    }
    var byProv = [];
    for (i = 0; i < MAP.nt; i++) byProv.push([]);
    Object.keys(E).forEach(function (k) {
      var ed = E[k];
      ed.lines = chainSegs(ed.seg).map(function (c) { return smoothPts(c.pts, c.closed, 5); });
      ed.seg = null;
      if (ed.a >= 0) byProv[ed.a].push(k);
      if (ed.b >= 0) byProv[ed.b].push(k);
    });
    MAP.byProv = byProv;
    return E;
  }
  var LOD = 0;
  function simp(ln, eps) {
    var n = ln.length; if (n < 4) return ln;
    var keep = new Uint8Array(n), st = [0, n - 1], i; keep[0] = 1; keep[n - 1] = 1;
    while (st.length) {
      var b = st.pop(), a = st.pop(); if (b - a < 2) continue;
      var ax = ln[a][0], ay = ln[a][1], bx = ln[b][0], by = ln[b][1], dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy, md = -1, mi = -1;
      for (i = a + 1; i < b; i++) {
        var px = ln[i][0] - ax, py = ln[i][1] - ay, d;
        if (L2 < 1e-9) d = Math.sqrt(px * px + py * py); else { var t = (px * dx + py * dy) / L2; t = t < 0 ? 0 : t > 1 ? 1 : t; var qx = px - t * dx, qy = py - t * dy; d = Math.sqrt(qx * qx + qy * qy); }
        if (d > md) { md = d; mi = i; }
      }
      if (md > eps) { keep[mi] = 1; st.push(a, mi, mi, b); }
    }
    var out = []; for (i = 0; i < n; i++) if (keep[i]) out.push(ln[i]);
    return out;
  }
  function edgePath(ed, lod) {
    if (lod) {
      if (!ed.pathS) {
        var q = new Path2D();
        ed.lines.forEach(function (l0) { var ln = simp(l0, 0.45); q.moveTo(ln[0][0], ln[0][1]); for (var i = 1; i < ln.length; i++) q.lineTo(ln[i][0], ln[i][1]); });
        ed.pathS = q;
      }
      return ed.pathS;
    }
    if (!ed.path) {
      var p = new Path2D();
      ed.lines.forEach(function (ln) {
        p.moveTo(ln[0][0], ln[0][1]);
        for (var i = 1; i < ln.length; i++) p.lineTo(ln[i][0], ln[i][1]);
      });
      ed.path = p;
    }
    return ed.path;
  }
