# HANDOFF (для следующего ИИ)

- Игра: «Рубежи», русский UI, один IIFE. Правки делай в `src/*.js` и `head.html`, затем `node build.js` → `index.html` (работает по двойному клику, ES-модулей нет: файлы делят общее замыкание).
- Порядок склейки: data, core, settings, map, rules, diplomacy, army, ai, game, save, render, ui, input (см. build.js). Не меняй порядок без причины.
- Настройки: `DEF`/`ST` в `src/settings.js` (грузятся только ключи из DEF), хранятся в localStorage `rubezhi3.settings`. Сейв — `rubezhi3.save`, версия `SAVE_VERSION` в `src/save.js`; при изменении формата добавляй `MIG[<старая версия>]` и увеличивай версию.
- Тест: копия index.html с `window.__T = {...}` перед `init();\n})();`, запуск через Python playwright (Chromium установлен). Синтаксис: вырезать `<script>` и `new Function(code)` в node.
- Недавнее: мятежи (`rebTurn`, `refugees`, `rebDeal` в rules.js), лёгкий режим (`lite()`, `drawSig` в render.js), туториал (`TUT`, `tutShow`), `hint()`.
- Проверено playwright: новая игра, туториал, «Ещё», пресеты деления, фильтры, мини-док, лёгкий режим, загрузка сейва v10. Не проверялись визуально на реальном телефоне.
