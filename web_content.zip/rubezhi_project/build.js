// Сборка: склеивает src/*.js в один IIFE и пишет index.html (один файл, открывается двойным кликом). Запуск: node build.js
const fs = require('fs');
const order = ['data', 'core', 'settings', 'map', 'rules', 'diplomacy', 'army', 'ai', 'game', 'save', 'render', 'ui', 'input'];
const body = order.map(n => fs.readFileSync(__dirname + '/src/' + n + '.js', 'utf8')).join('');
const head = fs.readFileSync(__dirname + '/head.html', 'utf8');
const out = head + "<script>\n(function () {\n'use strict';\n" + body + "})();\n</script>\n</body></html>\n";
fs.writeFileSync(__dirname + '/index.html', out);
console.log('index.html', out.length);
