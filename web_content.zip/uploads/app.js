// ==========================================
// CCSJDM STUDENT EVENT & ATTENDANCE HUB
// Comprehensive Application Logic (Mock DB + LocalStorage)
// ==========================================

// Initial Event Data (Mock Database)
let eventsData = [
    {
        id: 1,
        title: "Leadership Seminar 2026",
        date: "SEPT 15, 2026",
        time: "9:00 AM - 4:00 PM",
        venue: "Bulwagang San Jose, CCSJDM Main Campus",
        organizer: "CCSJDM Student Council",
        category: "Seminar",
        description: "Engage in academic leadership training and character development.",
        image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80",
        capacity: 50,
        registrationDeadline: "SEPT 10, 2026",
        targetAudience: "BSIT & BSCS majors, 2nd to 4th year",
        speaker: "Mr. Jose S. Dela Cruz, President, CCSJDM",
        requirements: ["Student ID", "Filled application form", "Proof of enrollment"],
        language: "Filipino & English",
        attachments: ["Seminar Outline.pdf", "Speaker Bio.pdf"],
        reminderNote: "Bring student ID at check-in. No external communication allowed."
    },
    {
        id: 2,
        title: "Freshmen Orientation",
        date: "SEPT 18, 2026",
        time: "8:00 AM - 12:00 PM",
        venue: "Main Auditorium",
        organizer: "CCSJDM Student Council",
        category: "Seminar",
        description: "Welcome event for all 1st-year students entering the campus.",
        image: "https://images.unsplash.com/photo-1523580494863-6f3031124c94?auto=format&fit=crop&w=800&q=80",
        capacity: 200,
        registrationDeadline: "SEPT 15, 2026",
        targetAudience: "All first-year students",
        speaker: "University President",
        requirements: ["Student ID", "Valid ID"],
        language: "Filipino & English",
        attachments: ["Course Catalog 2026.pdf"],
        reminderNote: "Students without registration will not be admitted."
    },
    {
        id: 3,
        title: "Cultural Night",
        date: "SEPT 22, 2026",
        time: "5:00 PM - 9:00 PM",
        venue: "Open Court",
        organizer: "Cultural Arts Group",
        category: "Culture",
        description: "Showcasing local talents, performances, and cultural heritage.",
        image: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80",
        capacity: 100,
        registrationDeadline: "SEPT 20, 2026",
        targetAudience: "All students",
        speaker: "Various performers",
        requirements: ["Open mic registration form (if performing)", "Audience ticket"],
        language: "Filipino & English",
        attachments: ["Performance Guidelines.pdf"],
        reminderNote: "Arrive 30 minutes early for seat assignment."
    },
    {
        id: 4,
        title: "Tech Workshop",
        date: "SEPT 25, 2026",
        time: "1:00 PM - 5:00 PM",
        venue: "Computer Lab 1",
        organizer: "CCS Society",
        category: "Workshop",
        description: "Hands-on web development and software basics for students.",
        image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80",
        capacity: 30,
        registrationDeadline: "SEPT 22, 2026",
        targetAudience: "BSCS & BSIT majors, 2nd to 4th year",
        speaker: "Computer Science Faculty",
        requirements: ["Laptop", "Basic programming knowledge"],
        language: "English",
        attachments: ["Workshop Syllabus.pdf"],
        reminderNote: "Please install the required software before coming."
    }
];

// Student mock data
const currentStudent = {
    id: "2026-00123",
    name: "Juan Dela Cruz",
    course: "BSIT 3A",
    year: "3rd year"
};

// LocalStorage Persistence
let registrations = [];
let customEvents = [];

if (localStorage.getItem('ccsjdm_registrations')) {
    registrations = JSON.parse(localStorage.getItem('ccsjdm_registrations'));
} else {
    // Seed initial dummy registrations
    registrations = [
        {
            id: 101,
            eventId: 1,
            eventTitle: "Leadership Seminar 2026",
            studentId: "2026-00123",
            studentName: "Juan Dela Cruz",
            studentCourse: "BSIT 3A",
            registrationDate: new Date().toISOString(),
            eventCode: "LS-2026-001",
            qrCode: "https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=LS-2026-001",
            attendanceStatus: "Not Yet Checked In",
            checkInTime: null,
            checkInMethod: null
        },
        {
            id: 102,
            eventId: 2,
            eventTitle: "Freshmen Orientation",
            studentId: "2026-00456",
            studentName: "Maria Santos",
            studentCourse: "BSCS 1B",
            registrationDate: new Date().toISOString(),
            eventCode: "FS-2026-001",
            qrCode: "https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=FS-2026-001",
            attendanceStatus: "Attended",
            checkInTime: new Date(Date.now() - 3600000).toISOString(),
            checkInMethod: "QR Scan"
        }
    ];
    localStorage.setItem('ccsjdm_registrations', JSON.stringify(registrations));
}

if (localStorage.getItem('ccsjdm_custom_events')) {
    customEvents = JSON.parse(localStorage.getItem('ccsjdm_custom_events'));
    eventsData = [...eventsData, ...customEvents];
}

function saveData() {
    localStorage.setItem('ccsjdm_registrations', JSON.stringify(registrations));
    localStorage.setItem('ccsjdm_custom_events', JSON.stringify(customEvents));
}

// Generate Event Code
function generateEventCode(eventId, participantIndex) {
    const prefixes = ['LS', 'FS', 'CN', 'TW', 'EV'];
    const prefix = prefixes[eventId - 1] || 'EV';
    const year = new Date().getFullYear();
    const index = String(participantIndex + 1).padStart(3, '0');
    return `${prefix}-${year}-${index}`;
}

// Notification Toast
function showNotification(message, type = 'info') {
    const existing = document.querySelector('.notification-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = `notification-toast ${type}`;
    toast.textContent = message;

    Object.assign(toast.style, {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        padding: '12px 20px',
        borderRadius: '8px',
        color: '#fff',
        zIndex: '9999',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        fontSize: '0.9rem',
        fontWeight: '600',
        transition: 'opacity 0.3s ease'
    });

    if (type === 'success') toast.style.backgroundColor = '#2e7d32';
    else if (type === 'error') toast.style.backgroundColor = '#c62828';
    else if (type === 'warning') toast.style.backgroundColor = '#ed6c02';
    else toast.style.backgroundColor = '#1976d2';

    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ==========================================
// 1. HOME / EVENT DIRECTORY (index.html)
// ==========================================
function initHomePage() {
    const eventsGrid = document.getElementById("eventsGrid");
    const searchInput = document.getElementById("searchInput");
    const searchBtn = document.getElementById("searchBtn");
    const categoryChips = document.querySelectorAll(".chip");
    const dateFilter = document.getElementById("dateFilter");
    const orgFilter = document.getElementById("orgFilter");

    if (!eventsGrid) return;

    function renderCards(events) {
        eventsGrid.innerHTML = "";
        if (events.length === 0) {
            eventsGrid.innerHTML = `<p class="no-events">No events found matching your search.</p>`;
            return;
        }

        events.forEach(event => {
            const registeredCount = registrations.filter(r => r.eventId === event.id).length;
            const isFull = registeredCount >= event.capacity;
            const isRegistered = registrations.some(r => r.eventId === event.id && r.studentId === currentStudent.id);

            const card = document.createElement("div");
            card.classList.add("event-card");
            card.innerHTML = `
                <img src="${event.image}" alt="${event.title}">
                <div class="card-body">
                    <span class="event-category-badge ${event.category.toLowerCase()}">${event.category}</span>
                    <h3 class="card-title">${event.title}</h3>
                    <p class="card-info"><strong>📅 Date:</strong> ${event.date}</p>
                    <p class="card-info"><strong>🕐 Time:</strong> ${event.time}</p>
                    <p class="card-info"><strong>📍 Venue:</strong> ${event.venue}</p>
                    <p class="card-info"><strong>🏛️ Organizer:</strong> ${event.organizer}</p>
                    <p class="card-desc">${event.description}</p>
                    <div class="card-footer-info">
                        <span class="slots-badge ${isFull ? 'full' : 'available'}">${registeredCount}/${event.capacity} Slots</span>
                    </div>
                    <a href="event-details.html?id=${event.id}" class="btn-register ${isRegistered ? 'btn-success' : ''}">
                        ${isRegistered ? '✓ Registered' : isFull ? 'Full (Waitlist)' : 'View & Register'}
                    </a>
                </div>
            `;
            eventsGrid.appendChild(card);
        });
    }

    function filterAndRender() {
        let filtered = [...eventsData];
        const query = searchInput ? searchInput.value.toLowerCase() : '';
        const activeChip = document.querySelector('.chip.active');
        const category = activeChip ? activeChip.getAttribute('data-category') : 'all';
        const orgVal = orgFilter ? orgFilter.value : 'all';

        if (query) {
            filtered = filtered.filter(e =>
                e.title.toLowerCase().includes(query) ||
                e.description.toLowerCase().includes(query) ||
                e.organizer.toLowerCase().includes(query) ||
                e.venue.toLowerCase().includes(query)
            );
        }

        if (category !== 'all') {
            filtered = filtered.filter(e => e.category === category);
        }

        if (orgVal !== 'all') {
            filtered = filtered.filter(e => e.organizer.includes(orgVal));
        }

        renderCards(filtered);
    }

    if (searchInput) searchInput.addEventListener('input', filterAndRender);
    if (searchBtn) searchBtn.addEventListener('click', filterAndRender);
    if (dateFilter) dateFilter.addEventListener('change', filterAndRender);
    if (orgFilter) orgFilter.addEventListener('change', filterAndRender);

    categoryChips.forEach(chip => {
        chip.addEventListener('click', () => {
            categoryChips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            filterAndRender();
        });
    });

    renderCards(eventsData);
}

// ==========================================
// 2. EVENT DETAILS & REGISTRATION (event-details.html)
// ==========================================
function initEventDetailsPage() {
    const container = document.getElementById('eventDetailsContainer');
    if (!container) return;

    const urlParams = new URLSearchParams(window.location.search);
    const eventId = parseInt(urlParams.get('id'));
    const event = eventsData.find(e => e.id === eventId);

    if (!event) {
        container.innerHTML = `<div class="error-state"><h3>Event not found.</h3><a href="index.html" class="btn-primary">Back to Home</a></div>`;
        return;
    }

    const registeredCount = registrations.filter(r => r.eventId === eventId).length;
    const isRegistered = registrations.some(r => r.eventId === eventId && r.studentId === currentStudent.id);
    const myReg = registrations.find(r => r.eventId === eventId && r.studentId === currentStudent.id);

    container.innerHTML = `
        <div class="event-detail-card">
            <img src="${event.image}" alt="${event.title}" class="event-detail-image">
            <div class="event-detail-content">
                <div class="event-meta-top">
                    <span class="event-category-badge ${event.category.toLowerCase()}">${event.category}</span>
                    <span class="slots-indicator">👥 ${registeredCount} / ${event.capacity} Slots Filled</span>
                </div>
                <h1 class="event-title">${event.title}</h1>
                <p class="event-organizer-big">Organized by <strong>${event.organizer}</strong></p>

                <div class="event-details-grid">
                    <div class="detail-item">
                        <span class="detail-icon">📅</span>
                        <div><h3>Date</h3><p>${event.date}</p></div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">🕐</span>
                        <div><h3>Time</h3><p>${event.time}</p></div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">📍</span>
                        <div><h3>Venue</h3><p>${event.venue}</p></div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">🎯</span>
                        <div><h3>Target Audience</h3><p>${event.targetAudience || 'All Students'}</p></div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">🎤</span>
                        <div><h3>Speaker</h3><p>${event.speaker || 'TBA'}</p></div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">⏳</span>
                        <div><h3>Registration Deadline</h3><p>${event.registrationDeadline}</p></div>
                    </div>
                </div>

                <div class="section-divider"></div>
                <h2>Tungkol sa Event na Ito</h2>
                <p class="event-description-full">${event.description}</p>

                <div class="section-divider"></div>
                <h2>Mga Kailangan (Requirements)</h2>
                <ul class="requirements-list">
                    ${(event.requirements || ["Student ID"]).map(req => `<li>✓ ${req}</li>`).join('')}
                </ul>

                ${event.reminderNote ? `
                <div class="reminder-box">
                    <h4>⚠️ Mahalagang Paalala</h4>
                    <p>${event.reminderNote}</p>
                </div>
                ` : ''}

                <div class="section-divider"></div>
                <div class="event-action-footer">
                    ${isRegistered ? `
                        <div class="registered-success-box">
                            <h3>✅ You are registered for this event!</h3>
                            <p>Your Event Code: <code class="highlight-code">${myReg.eventCode}</code></p>
                            <a href="my-events.html" class="btn-secondary">View in My Schedule</a>
                        </div>
                    ` : `
                        <button class="btn-register-large" id="confirmRegisterBtn">
                            📝 Register Now
                        </button>
                    `}
                </div>
            </div>
        </div>
    `;

    const regBtn = document.getElementById('confirmRegisterBtn');
    if (regBtn) {
        regBtn.addEventListener('click', () => {
            // Register student
            const participantIndex = registrations.filter(r => r.eventId === eventId).length;
            const eventCode = generateEventCode(eventId, participantIndex);

            const newReg = {
                id: Date.now(),
                eventId: eventId,
                eventTitle: event.title,
                studentId: currentStudent.id,
                studentName: currentStudent.name,
                studentCourse: currentStudent.course,
                registrationDate: new Date().toISOString(),
                eventCode: eventCode,
                qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(eventCode)}`,
                attendanceStatus: "Not Yet Checked In",
                checkInTime: null,
                checkInMethod: null
            };

            registrations.push(newReg);
            saveData();

            // Show success modal
            showModalSuccess(event.title, eventCode);
            setTimeout(() => {
                location.reload();
            }, 2500);
        });
    }
}

function showModalSuccess(eventTitle, eventCode) {
    const modal = document.getElementById('successModal');
    const msg = document.getElementById('successMessage');
    const code = document.getElementById('assignedEventCode');
    if (modal && msg && code) {
        msg.textContent = `Successfully registered for "${eventTitle}".`;
        code.textContent = eventCode;
        modal.hidden = false;
    }
    const closeBtn = document.getElementById('closeModalBtn');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.hidden = true;
        });
    }
}

// ==========================================
// 3. MY SCHEDULE & ATTENDANCE (my-events.html)
// ==========================================
function initMyEventsPage() {
    const regGrid = document.getElementById('myRegisteredGrid');
    const tbody = document.getElementById('attendanceHistoryBody');
    const regCount = document.getElementById('regCount');
    const histCount = document.getElementById('histCount');

    if (!regGrid || !tbody) return;

    const myRegs = registrations.filter(r => r.studentId === currentStudent.id);
    regCount.textContent = myRegs.length;
    histCount.textContent = myRegs.length;

    // Render Registered Cards
    if (myRegs.length === 0) {
        regGrid.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">📅</div>
                <h3>You have no registered events.</h3>
                <p>Browse the Home page and register for upcoming events.</p>
                <a href="index.html" class="btn-primary">View Events</a>
            </div>
        `;
    } else {
        regGrid.innerHTML = "";
        myRegs.forEach(reg => {
            const event = eventsData.find(e => e.id === reg.eventId);
            if (!event) return;

            const card = document.createElement('div');
            card.className = 'event-card';
            card.innerHTML = `
                <div class="card-body">
                    <span class="event-code-badge">Code: <strong>${reg.eventCode}</strong></span>
                    <h3 class="card-title">${event.title}</h3>
                    <p class="card-info"><strong>📅 Date:</strong> ${event.date} | ${event.time}</p>
                    <p class="card-info"><strong>📍 Venue:</strong> ${event.venue}</p>
                    <div class="status-pill ${reg.attendanceStatus === 'Attended' ? 'attended' : reg.attendanceStatus === 'Late' ? 'late' : 'pending'}">
                        ${reg.attendanceStatus === 'Attended' ? '✅ Attended' : reg.attendanceStatus === 'Late' ? '⏰ Late' : '⏳ Pending Check-in'}
                    </div>
                    <div class="qr-container-mini">
                        <img src="${reg.qrCode}" alt="QR Code">
                        <span class="qr-hint">Scan at Front Desk</span>
                    </div>
                    <div class="card-actions-row">
                        <a href="event-details.html?id=${event.id}" class="btn-secondary btn-sm">Detalye</a>
                        <button class="btn-danger-outline btn-sm" onclick="cancelStudentRegistration(${reg.id})">Cancel</button>
                    </div>
                </div>
            `;
            regGrid.appendChild(card);
        });
    }

    // Render Attendance History Table
    if (myRegs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center">No attendance history yet.</td></tr>`;
    } else {
        tbody.innerHTML = "";
        myRegs.forEach(reg => {
            const event = eventsData.find(e => e.id === reg.eventId);
            if (!event) return;

            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${event.title}</strong></td>
                <td>${event.date}</td>
                <td>${event.venue}</td>
                <td><code>${reg.eventCode}</code></td>
                <td>
                    <span class="status-pill ${reg.attendanceStatus === 'Attended' ? 'attended' : reg.attendanceStatus === 'Late' ? 'late' : 'pending'}">
                        ${reg.attendanceStatus}
                    </span>
                    ${reg.checkInTime ? `<br><small>Oras: ${new Date(reg.checkInTime).toLocaleTimeString()}</small>` : ''}
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    // Tabs functionality
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(`${btn.dataset.tab}Tab`).classList.add('active');
        });
    });
}

window.cancelStudentRegistration = function(regId) {
    if (confirm("Sigurado ka bang gusto mong kanselahin ang registration na ito?")) {
        registrations = registrations.filter(r => r.id !== regId);
        saveData();
        showNotification("Matagumpay na nakansela ang registration.", "success");
        initMyEventsPage();
    }
};

// ==========================================
// OFFICER LOGIN
// ==========================================
window.openLoginModal = function() {
    document.getElementById('loginModal').hidden = false;
};

window.logoutOfficer = function() {
    localStorage.removeItem('ccsjdm_officer_logged_in');
    location.reload();
};

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('loginUsername').value;
            const password = document.getElementById('loginPassword').value;

            if (username === 'host' && password === 'schedule') {
                localStorage.setItem('ccsjdm_officer_logged_in', 'true');
                document.getElementById('loginModal').hidden = true;
                location.reload();
            } else {
                showNotification("Invalid username or password.", "error");
            }
        });
    }

    const cancelLoginModal = document.getElementById('cancelLoginModal');
    if (cancelLoginModal) {
        cancelLoginModal.addEventListener('click', () => {
            document.getElementById('loginModal').hidden = true;
        });
    }
});

// ==========================================
// 4. OFFICER DASHBOARD (officer.html)
// ==========================================
function initOfficerPage() {
    const isLoggedIn = localStorage.getItem('ccsjdm_officer_logged_in');
    if (!isLoggedIn) {
        const main = document.getElementById('officerMain');
        if (main) main.hidden = true;
        document.getElementById('loginModal').hidden = false;
        // Hide login button when already showing modal
        const btn = document.getElementById('loginBtn');
        if (btn) btn.hidden = true;
        return;
    }
    const main = document.getElementById('officerMain');
    if (main) main.hidden = false;
    const btn = document.getElementById('loginBtn');
    if (btn) btn.hidden = true;

    const eventsTbody = document.getElementById('officerEventsTableBody');
    const regTbody = document.getElementById('registrantsTableBody');
    const eventFilterSelect = document.getElementById('eventFilterSelect');
    const createModal = document.getElementById('createEventModal');
    const openModalBtn = document.getElementById('openCreateEventModal');
    const closeModalBtn = document.getElementById('closeCreateModal');
    const cancelModalBtn = document.getElementById('cancelCreateModal');
    const createForm = document.getElementById('createEventForm');

    if (!eventsTbody) return;

    // Render Stats
    document.getElementById('totalEventsCount').textContent = eventsData.length;
    document.getElementById('totalRegistrantsCount').textContent = registrations.length;
    const attendedCount = registrations.filter(r => r.attendanceStatus === 'Attended' || r.attendanceStatus === 'Late').length;
    document.getElementById('totalAttendeesCount').textContent = attendedCount;
    const rate = registrations.length > 0 ? Math.round((attendedCount / registrations.length) * 100) : 0;
    document.getElementById('attendanceRate').textContent = `${rate}%`;

    // Populate Event Filter Dropdown
    eventFilterSelect.innerHTML = `<option value="all">Lahat ng Event (${registrations.length} registrants)</option>`;
    eventsData.forEach(ev => {
        const count = registrations.filter(r => r.eventId === ev.id).length;
        eventFilterSelect.innerHTML += `<option value="${ev.id}">${ev.title} (${count} registrants)</option>`;
    });

    // Render Officer Events Table
    function renderOfficerEvents() {
        eventsTbody.innerHTML = "";
        eventsData.forEach(ev => {
            const regCount = registrations.filter(r => r.eventId === ev.id).length;
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${ev.title}</strong><br><small>${ev.category} • ${ev.organizer}</small></td>
                <td>${ev.date}<br>${ev.time}</td>
                <td>${ev.venue}</td>
                <td>${regCount} / ${ev.capacity} slots</td>
                <td><span class="status-pill active">Published</span></td>
                <td>
                    <a href="checkin.html?event=${ev.id}" class="btn-primary btn-sm">Check-in Desk</a>
                </td>
            `;
            eventsTbody.appendChild(row);
        });
    }

    // Render Registrants Table
    function renderRegistrants(filterEventId = 'all') {
        regTbody.innerHTML = "";
        let filtered = registrations;
        if (filterEventId !== 'all') {
            filtered = registrations.filter(r => r.eventId == filterEventId);
        }

        if (filtered.length === 0) {
            regTbody.innerHTML = `<tr><td colspan="7" class="text-center">Walang registrants sa event na ito.</td></tr>`;
            return;
        }

        filtered.forEach(reg => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${reg.studentName}</strong></td>
                <td>${reg.studentId}</td>
                <td>${reg.studentCourse || 'BSIT 3A'}</td>
                <td>${reg.eventTitle}</td>
                <td><code>${reg.eventCode}</code></td>
                <td><span class="status-pill ${reg.attendanceStatus === 'Attended' ? 'attended' : reg.attendanceStatus === 'Late' ? 'late' : 'pending'}">${reg.attendanceStatus}</span></td>
                <td>
                    <select onchange="updateAttendanceStatus(${reg.id}, this.value)" class="status-select">
                        <option value="Not Yet Checked In" ${reg.attendanceStatus === 'Not Yet Checked In' ? 'selected' : ''}>Pending</option>
                        <option value="Attended" ${reg.attendanceStatus === 'Attended' ? 'selected' : ''}>Attended</option>
                        <option value="Late" ${reg.attendanceStatus === 'Late' ? 'selected' : ''}>Late</option>
                        <option value="Absent" ${reg.attendanceStatus === 'Absent' ? 'selected' : ''}>Absent</option>
                        <option value="Excused" ${reg.attendanceStatus === 'Excused' ? 'selected' : ''}>Excused</option>
                    </select>
                </td>
            `;
            regTbody.appendChild(row);
        });
    }

    renderOfficerEvents();
    renderRegistrants('all');

    eventFilterSelect.addEventListener('change', (e) => {
        renderRegistrants(e.target.value);
    });

    // Create Event Modal Triggers
    if (openModalBtn) openModalBtn.addEventListener('click', () => createModal.hidden = false);
    if (closeModalBtn) closeModalBtn.addEventListener('click', () => createModal.hidden = true);
    if (cancelModalBtn) cancelModalBtn.addEventListener('click', () => createModal.hidden = true);

    if (createForm) {
        createForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const newEv = {
                id: eventsData.length + 1,
                title: document.getElementById('newEventTitle').value,
                category: document.getElementById('newEventCategory').value,
                date: document.getElementById('newEventDate').value,
                time: document.getElementById('newEventTime').value,
                venue: document.getElementById('newEventVenue').value,
                organizer: document.getElementById('newEventOrganizer').value,
                capacity: parseInt(document.getElementById('newEventCapacity').value),
                registrationDeadline: document.getElementById('newEventDeadline').value,
                description: document.getElementById('newEventDesc').value,
                speaker: document.getElementById('newEventSpeaker').value || 'TBA',
                image: "https://images.unsplash.com/photo-1515187029135-18ee286d815b?auto=format&fit=crop&w=800&q=80",
                requirements: ["Student ID", "Event Registration Confirmation"],
                reminderNote: "Please arrive 15 minutes before schedule."
            };

            customEvents.push(newEv);
            eventsData.push(newEv);
            saveData();

            createModal.hidden = true;
            createForm.reset();
            showNotification("Matagumpay na nagawa ang bagong event!", "success");
            initOfficerPage();
        });
    }
}

window.updateAttendanceStatus = function(regId, newStatus) {
    const reg = registrations.find(r => r.id === regId);
    if (reg) {
        reg.attendanceStatus = newStatus;
        if (newStatus === 'Attended' || newStatus === 'Late') {
            reg.checkInTime = new Date().toISOString();
            reg.checkInMethod = 'Manual Officer Update';
        }
        saveData();
        showNotification(`Updated ${reg.studentName}'s status to "${newStatus}".`, "success");
        initOfficerPage();
    }
};

// ==========================================
// 5. CHECK-IN DESK (checkin.html)
// ==========================================
function initCheckinPage() {
    const eventSelect = document.getElementById('checkinEventSelect');
    const codeForm = document.getElementById('codeCheckinForm');
    const codeInput = document.getElementById('eventCodeInput');
    const simulateBtn = document.getElementById('simulateQrScanBtn');
    const manualInput = document.getElementById('manualSearchInput');
    const manualResults = document.getElementById('manualResultsContainer');
    const attendeesTbody = document.getElementById('eventAttendeesTableBody');
    const feedbackBox = document.getElementById('checkinFeedbackBox');

    if (!eventSelect) return;

    // Check-in mode tabs (Event Code / QR vs Manual Search)
    const tabButtons = document.querySelectorAll('.checkin-tab-btn');
    const codeModeContent = document.getElementById('codeModeContent');
    const manualModeContent = document.getElementById('manualModeContent');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const mode = btn.dataset.mode;
            tabButtons.forEach(b => {
                const isActive = b === btn;
                b.classList.toggle('active', isActive);
                b.setAttribute('aria-selected', String(isActive));
            });
            if (codeModeContent) codeModeContent.hidden = mode !== 'code';
            if (manualModeContent) manualModeContent.hidden = mode !== 'manual';
            if (mode === 'manual' && manualInput) manualInput.focus();
            if (mode === 'code' && codeInput) codeInput.focus();
        });
    });

    // Populate Event Selector
    eventSelect.innerHTML = "";
    eventsData.forEach(ev => {
        eventSelect.innerHTML += `<option value="${ev.id}">${ev.title} (${ev.venue})</option>`;
    });

    const urlParams = new URLSearchParams(window.location.search);
    const preselectEvent = urlParams.get('event');
    if (preselectEvent) {
        eventSelect.value = preselectEvent;
    }

    function updateCheckinDashboard() {
        const selectedEventId = parseInt(eventSelect.value);
        const eventRegs = registrations.filter(r => r.eventId === selectedEventId);

        const totalReg = eventRegs.length;
        const totalAtt = eventRegs.filter(r => r.attendanceStatus === 'Attended').length;
        const totalLate = eventRegs.filter(r => r.attendanceStatus === 'Late').length;
        const totalAbs = totalReg - totalAtt - totalLate;

        document.getElementById('statRegistered').textContent = totalReg;
        document.getElementById('statAttended').textContent = totalAtt;
        document.getElementById('statLate').textContent = totalLate;
        document.getElementById('statAbsent').textContent = totalAbs >= 0 ? totalAbs : 0;

        const pct = totalReg > 0 ? Math.round(((totalAtt + totalLate) / totalReg) * 100) : 0;
        document.getElementById('attendanceProgressBar').style.width = `${pct}%`;
        document.getElementById('attendancePercentText').textContent = `${pct}%`;

        // Render attendees table
        attendeesTbody.innerHTML = "";
        if (eventRegs.length === 0) {
            attendeesTbody.innerHTML = `<tr><td colspan="7" class="text-center">Walang registrants sa event na ito.</td></tr>`;
            return;
        }

        eventRegs.forEach(reg => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${reg.studentName}</strong></td>
                <td>${reg.studentId}</td>
                <td>${reg.studentCourse || 'BSIT 3A'}</td>
                <td><code>${reg.eventCode}</code></td>
                <td><span class="status-pill ${reg.attendanceStatus === 'Attended' ? 'attended' : reg.attendanceStatus === 'Late' ? 'late' : 'pending'}">${reg.attendanceStatus}</span></td>
                <td>${reg.checkInTime ? new Date(reg.checkInTime).toLocaleTimeString() : '---'}</td>
                <td>
                    <div class="table-action-btns">
                        <button class="btn-success btn-xs" onclick="setAttendance(${reg.id}, 'Attended', 'Manual')">✓ Attended</button>
                        <button class="btn-warning btn-xs" onclick="setAttendance(${reg.id}, 'Late', 'Manual')">⏰ Late</button>
                        <button class="btn-danger btn-xs" onclick="setAttendance(${reg.id}, 'Absent', 'Manual')">❌ Absent</button>
                    </div>
                </td>
            `;
            attendeesTbody.appendChild(row);
        });
    }

    eventSelect.addEventListener('change', updateCheckinDashboard);

    // Code Check-in Submission
    if (codeForm) {
        codeForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const code = codeInput.value.trim().toUpperCase();
            processCheckinByCode(code);
            codeInput.value = "";
        });
    }

    // Simulate QR Scan
    if (simulateBtn) {
        simulateBtn.addEventListener('click', () => {
            const selectedEventId = parseInt(eventSelect.value);
            const pendingRegs = registrations.filter(r => r.eventId === selectedEventId && r.attendanceStatus === 'Not Yet Checked In');
            if (pendingRegs.length === 0) {
                showNotification("Lahat ng registrants ay naka-check in na!", "warning");
                return;
            }
            const randomReg = pendingRegs[Math.floor(Math.random() * pendingRegs.length)];
            processCheckinByCode(randomReg.eventCode);
        });
    }

    function processCheckinByCode(code) {
        const reg = registrations.find(r => r.eventCode.toUpperCase() === code);
        if (!reg) {
            showNotification(`"Event Code not found" for "${code}". Please try again.`, "error");
            return;
        }

        // Guard: the code must belong to the event currently selected at the desk
        const selectedEventId = parseInt(eventSelect.value);
        if (reg.eventId !== selectedEventId) {
            const otherEvent = eventsData.find(e => e.id === reg.eventId);
            showNotification(`This code is for "${otherEvent ? otherEvent.title : 'another event'}", not the selected event.`, "error");
            showFeedbackBox(false, reg, `Wrong event: ${otherEvent ? otherEvent.title : 'unknown'}`);
            return;
        }

        // Guard: any status other than the pending state is an existing attendance decision
        if (reg.attendanceStatus !== 'Not Yet Checked In') {
            const when = reg.checkInTime ? new Date(reg.checkInTime).toLocaleTimeString() : '';
            showNotification(`Warning: ${reg.studentName} already has a recorded status of "${reg.attendanceStatus}"${when ? ` at ${when}` : ''}.`, "warning");
            showFeedbackBox(false, reg, `Status already recorded: ${reg.attendanceStatus}`);
            return;
        }

        reg.attendanceStatus = 'Attended';
        reg.checkInTime = new Date().toISOString();
        reg.checkInMethod = 'Event Code / QR';
        saveData();

        showNotification(`${reg.studentName} checked in successfully!`, "success");
        showFeedbackBox(true, reg, "Attended");
        updateCheckinDashboard();
    }

    function showFeedbackBox(isSuccess, reg, statusText) {
        if (!feedbackBox) return;
        feedbackBox.hidden = false;
        document.getElementById('feedbackIcon').textContent = isSuccess ? '✅' : '⚠️';
        document.getElementById('feedbackTitle').textContent = isSuccess ? 'Check-in Successful!' : 'Check-in Warning';
        document.getElementById('feedbackText').textContent = `${reg.studentName} (${reg.studentId}) - ${reg.eventTitle} [${statusText}]`;
        document.getElementById('feedbackTime').textContent = new Date().toLocaleTimeString();
    }

    // Manual Search Input
    if (manualInput) {
        manualInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            const selectedEventId = parseInt(eventSelect.value);
            const eventRegs = registrations.filter(r => r.eventId === selectedEventId);

            if (!query) {
                manualResults.innerHTML = "";
                return;
            }

            const matched = eventRegs.filter(r => r.studentName.toLowerCase().includes(query) || r.studentId.includes(query));
            manualResults.innerHTML = "";

            if (matched.length === 0) {
                manualResults.innerHTML = `<div class="search-result-item">No student found.</div>`;
                return;
            }

            matched.forEach(m => {
                const div = document.createElement('div');
                div.className = 'search-result-item';
                div.innerHTML = `
                    <div>
                        <strong>${m.studentName}</strong> (${m.studentId})<br>
                        <small>Code: ${m.eventCode} • Status: ${m.attendanceStatus}</small>
                    </div>
                    <button class="btn-primary btn-xs" onclick="processCheckinByCodeExternal('${m.eventCode}')">Check-in</button>
                `;
                manualResults.appendChild(div);
            });
        });
    }

    window.processCheckinByCodeExternal = function(code) {
        processCheckinByCode(code);
        if (manualInput) manualInput.value = "";
        if (manualResults) manualResults.innerHTML = "";
    };

    window.setAttendance = function(regId, status, method) {
        const reg = registrations.find(r => r.id === regId);
        if (reg) {
            reg.attendanceStatus = status;
            reg.checkInTime = new Date().toISOString();
            reg.checkInMethod = method;
            saveData();
            showNotification(`Updated ${reg.studentName}'s attendance to "${status}".`, "success");
            updateCheckinDashboard();
        }
    };

    // Walk-in modal handling
    const walkinModal = document.getElementById('walkinModal');
    const openWalkinBtn = document.getElementById('openWalkinModalBtn');
    const closeWalkinBtn = document.getElementById('closeWalkinModal');
    const cancelWalkinBtn = document.getElementById('cancelWalkinModal');
    const walkinForm = document.getElementById('walkinForm');

    if (openWalkinBtn) openWalkinBtn.addEventListener('click', () => walkinModal.hidden = false);
    if (closeWalkinBtn) closeWalkinBtn.addEventListener('click', () => walkinModal.hidden = true);
    if (cancelWalkinBtn) cancelWalkinBtn.addEventListener('click', () => walkinModal.hidden = true);

    if (walkinForm) {
        walkinForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const selectedEventId = parseInt(eventSelect.value);
            const event = eventsData.find(e => e.id === selectedEventId);

            const name = document.getElementById('walkinName').value;
            const studentId = document.getElementById('walkinId').value;
            const course = document.getElementById('walkinCourse').value;

            const code = `WI-${selectedEventId}-${Math.floor(100 + Math.random() * 900)}`;

            const walkinReg = {
                id: Date.now(),
                eventId: selectedEventId,
                eventTitle: event ? event.title : "School Event",
                studentId: studentId,
                studentName: name,
                studentCourse: course,
                registrationDate: new Date().toISOString(),
                eventCode: code,
                qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(code)}`,
                attendanceStatus: "Attended",
                checkInTime: new Date().toISOString(),
                checkInMethod: "Walk-in Desk"
            };

            registrations.push(walkinReg);
            saveData();

            walkinModal.hidden = true;
            walkinForm.reset();
            showNotification(`Matagumpay na na-idagdag at na-check in si ${name} bilang Walk-in!`, "success");
            updateCheckinDashboard();
        });
    }

    updateCheckinDashboard();
}

// ==========================================
// MOBILE NAVBAR TOGGLE & PAGE ROUTER
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');

    if (navToggle && navLinks) {
        navToggle.setAttribute('aria-expanded', 'false');
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('show');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });
    }

    // Router based on pathname
    const path = window.location.pathname;
    if (path.includes('event-details.html')) {
        initEventDetailsPage();
    } else if (path.includes('my-events.html')) {
        initMyEventsPage();
    } else if (path.includes('officer.html')) {
        initOfficerPage();
    } else if (path.includes('checkin.html')) {
        initCheckinPage();
    } else {
        initHomePage();
    }
});
