# CCSJDM STUDENT SERVICES QUEUE AND APPOINTMENT HUB
## Concept Document

---

## I. VISION STATEMENT

The CCSJDM Student Services Queue and Appointment Hub is a web-based system that will help students of the City College of San Jose del Monte (and the future Pamantasan ng San Jose del Monte) get services from school offices more easily.

Its goal is to reduce long lines, confusion about required documents, repeated trips back to the office, and the time wasted by students and staff. Instead of lining up right away without knowing whether their requirements are complete or whether the office is open, students will first see the correct process, schedule an appointment or get a queue number, and track the status of their concern or request.

### A. Goal

Make students' access to school services more organized, clear, and fast.

### B. Mission

Provide a simple, accessible, and easy-to-use digital platform where students can find the right office, learn the requirements, get an appointment or queue slot, and receive clear updates about their request.

### C. Vision

Build a campus service experience where students are no longer confused about where to go, what to bring, and what to do next.

### D. Core Values

1. **Clarity**
   Clearly shows which office to go to, what the requirements are, and what the next step is.

2. **Simplicity**
   Getting information, an appointment, or a queue number should not be complicated.

3. **Efficiency**
   Helps reduce unnecessary waiting in line and back-and-forth trips to campus offices.

4. **Accessibility**
   Students must be able to use it on a cellphone, tablet, or computer, regardless of their level of technical experience.

5. **Orderliness and Accuracy**
   Queue status, appointment details, office, schedule, and requirements must be clear and easy to review.

### E. Commitment

The system commits to guiding students from choosing a service to receiving the result of their request, through clear instructions, status updates, and next-step notifications.

---

## II. USER EXPERIENCE CONCEPT

### A. Student Feelings

Students should feel that they are:
- Informed about the process
- Organized
- Calm
- In control of their request
- Not lost
- Respected in terms of their time

The system should reduce feelings of:
- Confusion
- Worry about whether requirements are complete
- Exhaustion from long lines
- Uncertainty about where to go
- Being late or not being served

### B. Student Actions

The student's main actions are:
- Log in using a school account or demo account
- Choose the office or service needed
- Read the service details, schedule, and requirements
- Upload or prepare required documents, if needed
- Book an appointment
- Get a digital queue number if walk-in service is available
- View queue position and estimated service time
- View or cancel an appointment if necessary
- Track the status of a request
- Receive notifications about schedule, missing requirements, or completion
- Give feedback after the service

### C. Student Goals

The system should answer questions such as:
- Which office should I go to?
- What do I need to bring?
- Is the office open today?
- Do I need to make an appointment?
- What is my queue number, and what is my position?
- Are my requirements complete?
- Has my request been processed?
- What should I do next?

### D. User Experience Statement

The CCSJDM Student Services Queue and Appointment Hub should make students feel prepared, informed, and in control of the process through clear guidance, digital appointment and queue management, and immediate feedback about their request.

---

## III. PRODUCT / SYSTEM CONCEPT

The CCSJDM Student Services Queue and Appointment Hub is a web application that will serve as a centralized service guide, appointment platform, and digital queueing system for school offices.

It will not immediately replace the entire student portal or all actual school processes. Instead, it focuses on the problem of getting services from campus offices: knowing the requirements, booking a schedule, queueing, and tracking requests.

### A. Product Type

Web Application / Student Service Management System

### B. Platform

Responsive website that can be used on cellphones, tablets, and desktop browsers.

### C. Primary Purpose

Help students book appointments, get queue numbers, learn the requirements, and track their school-service requests.

### D. Unique Value

It combines a service directory, requirements guide, appointment booking, live queue status, and request tracking into one clear process.

Instead of asking around, lining up without certainty, or returning because they didn't bring everything needed, students will see the correct information before going to the office.

---

## IV. TARGET USERS

### A. Primary Users: Students

1. **New students**
   May need help with requirements, registration concerns, and understanding school processes.

2. **Current students**
   May be requesting documents, grades-related assistance, scholarship concerns, a guidance appointment, library service, or IT support.

3. **Transferees or returning students**
   May have more documents, verification steps, or enrollment-related concerns.

### B. Secondary Users: School Staff

- Registrar personnel
- Cashier or accounting staff
- Scholarship / financial assistance office staff
- Guidance office staff
- Library staff
- IT support staff
- Student affairs staff
- Authorized office administrator

### C. User Characteristics

Students mostly use cellphones, and their familiarity with online systems varies. They need short and clear instructions, easy forms, and visible status updates.

### D. User Needs

Students need:
- The correct office for their concern
- A complete list of requirements
- Office schedule and availability
- Clear appointment or queue details
- An easy way to find out the status of their request
- Notifications if a document is missing or the schedule changes
- One clear next action

### E. Possible User Problems

Students may not know:
- Which office to go to
- What documents are needed
- When the service is available
- Whether an appointment is required
- How many people are ahead of them in line
- Whether their request is complete or has been processed

Example of what the system should provide:

> "Next Step: Upload or bring a photocopy of your valid ID before your appointment with the Registrar at 10:30 AM."

The system should not only display a list of requirements; it should also tell the student exactly what to do next.

---

## V. USER GOALS AND TASKS

| User Goal | User Task | UI Support |
|---|---|---|
| Start a service request | Log in and choose an office or service | Login screen, service categories, and service search bar |
| Know the requirements | View service details and checklist | Requirements checklist, file/document guide, and office instructions |
| Get service without wasting time | Book an appointment or get a queue number | Available date/time slots, digital queue ticket, and estimated waiting time |
| See the progress of a request | View request status | Status tracker with states such as Submitted, Waiting, Serving, Under Review, Completed, or Needs Action |
| Fix incorrect information or missing documents | Edit the request or upload the missing document | Edit controls, clear error message, and resubmission option |
| Know what to do next | Read an update or notification | Next-step card, notification panel, and confirmation message |

---

## VI. INFORMATION ARCHITECTURE

### A. Main Parts of the System

**1. Home / Landing Page**
- Explanation of what the system is
- Quick access to appointments, queue, and service directory
- Important announcements

**2. Login / Student Profile**
- Student account login
- Basic profile and contact information
- List of active and past requests

**3. Service Directory**
- List of school offices and services
- Search and filters
- Office schedule, location, and requirements

**4. Service Details**
- Description of the service
- Requirements checklist
- Processing time
- Appointment requirement
- Queue availability

**5. Appointment Booking**
- Calendar
- Available dates and time slots
- Appointment confirmation
- Reschedule or cancel option

**6. Digital Queue**
- Queue number
- Current serving number
- Number of people ahead
- Estimated waiting time
- Status such as Waiting, Called, Serving, Missed, or Completed

**7. Request Tracking**
- Request timeline
- Missing requirements
- Staff note or next step
- Completion status

**8. Notifications**
- Appointment reminders
- Queue updates
- Requirement alerts
- Request completion notices

**9. Staff / Admin Dashboard**
- List of the day's appointments and queue
- Service request management
- Status update controls
- Office notices
- Simple report on the number of requests

### B. Navigation Structure

**For Students:**
Home → Login → Dashboard → Choose Service → Service Details → Appointment or Queue → Confirmation → Request Tracking

**For Staff:**
Login → Staff Dashboard → Choose Service / Queue → View Student → Update Status → Mark as Completed or Needs Action

---

## VII. UI COMPONENTS

### A. Navigation Components
- Top navigation bar
- Sidebar for the dashboard
- Breadcrumbs
- Back button
- Tabs for Appointments, Queue, Requests, and Notifications

### B. Input Components
- Text fields
- Dropdown menu for office and service type
- Search field
- Date picker
- Time-slot buttons
- Checkboxes for requirements
- File upload field for documents that need to be submitted
- Text area for concerns or notes

### C. Information Components
- Service cards
- Office information card
- Requirements checklist
- Appointment summary card
- Queue ticket card
- Queue number display
- Estimated wait-time display
- Request status tracker
- Student profile card
- Notification list

### D. Action Components
- Book Appointment
- Get Queue Number
- Continue
- Back
- Save Draft
- Submit Request
- Reschedule
- Cancel Appointment
- Edit Details
- Upload Requirement
- Confirm

### E. Feedback Components
- Success message: "Your appointment was successfully booked."
- Queue confirmation: "Your queue number is R-023."
- Warning message: "One required document is missing."
- Error message: "Please choose an available time first."
- Loading indicator while the request is being processed
- Empty state when there is no active appointment or request yet
- Confirmation dialog before canceling or submitting

---

## VIII. VISUAL DESIGN DIRECTION

The visual design should convey trust, professionalism, clarity, and order. Because students' time and personal information are important, the interface should not be overly colorful or filled with unnecessary decoration.

### A. Color
- **Primary Color:** for navigation, main buttons, and important links
- **Success Color:** for completed requests, confirmed appointments, and available status
- **Warning Color:** for pending requirements, upcoming appointments, or important reminders
- **Error Color:** for invalid forms, cancelled requests, or missing requirements
- **Neutral Colors:** for backgrounds, cards, labels, and secondary information

### B. Typography

There must be a clear hierarchy for:
- Page title
- Section heading
- Office/service name
- Form label
- Requirement instruction
- Queue number
- Status label
- Error message
- Button label

### C. Shapes and Layout
- Simple cards
- Slightly rounded inputs and buttons
- Consistent spacing
- Clear borders
- Large, easy-to-read queue number
- One main action per screen

### D. Icons

Icons may be used alongside text:
- Calendar for appointments
- Queue/ticket icon for the digital queue
- Document icon for requirements
- Bell for notifications
- Check for completed
- Warning icon for pending or missing requirements
- Building/office icon for the service directory

### E. Layout Priority

On every service screen, the following should be easy to see:

Service / Office → Requirements → Available Schedule or Queue → Main Action → Confirmation or Status

---

## IX. INTERACTION DESIGN

### A. Appointment Booking Flow

Choose Service
→ View Requirements
→ Choose Date
→ Choose an Available Time
→ Review Appointment
→ Confirm
→ Receive Appointment Reference and Reminder

If there is no available time slot, the system must clearly say that the schedule is full and offer other available dates or another option.

### B. Digital Queue Flow

Choose Service
→ Check if the queue is open
→ Get a Queue Number
→ See the current serving number
→ See the number of people ahead and the estimated wait time
→ Receive an "Your turn is coming up" notification
→ Get called / served
→ See completion or next action

Getting a queue number should never simply fail. If the queue is closed or full, the system must explain why and say when the student can come back or book an appointment.

### C. Requirement Validation Flow

Fill out a Request
→ Click Continue
→ System checks Required Fields and Requirements
→ If something is missing: Highlight the field or requirement
→ Show a clear instruction
→ Student corrects or uploads the missing item
→ Submit again

### D. Staff Queue Management Flow

Staff Login
→ Choose Office or Service
→ View the List of Waiting Students
→ Click the Next Queue Number
→ Mark as Serving
→ Mark as Completed, Needs Action, or Missed
→ Send an update to the student

### E. Possible Statuses

**Appointment:**
- Confirmed
- Upcoming
- Checked In
- Completed
- Cancelled
- Rescheduled
- Missed

**Queue:**
- Queue Open
- Waiting
- Almost Your Turn
- Called
- Serving
- Completed
- Missed
- Queue Closed

**Request:**
- Draft
- Submitted
- Under Review
- Needs Action
- Processing
- Completed
- Rejected / Cancelled

---

## X. USABILITY AND ACCESSIBILITY

### A. Usability
- Instructions must be clear at every step.
- Important appointment, queue, or request status should always be visible.
- Button behavior and labels should be consistent across all pages.
- Forms must validate before submitting.
- It should be easy for students to go back and correct information.
- There should be a clear next action after every update.
- It must be mobile-friendly, since many students use cellphones.

### B. Accessibility
- Use readable fonts and sufficiently large text.
- Maintain sufficient contrast between text and background.
- Do not rely on color alone to show status; add text or an icon as well.
- Use clear labels for forms.
- It must be usable with keyboard navigation.
- Inputs and buttons must have visible focus states.
- Icons must have text alternatives or labels.
- Error messages must be clear and specific.
- Avoid overly long or complicated instructions.

---

## XI. COMPETITIVE ANALYSIS

The concept may be compared with online appointment systems, queueing systems, student portals, and service-request tools used by schools, clinics, banks, and government offices.

The purpose of the analysis is not to copy other systems. It is to identify which features are effective and how to make the system better suited to the actual needs of CCSJDM students and offices.

Opportunities for improvement:
- One clear service directory instead of scattered information
- Requirement checklist before getting a queue number or appointment
- A clear "next step" instead of a simple status only
- Mobile-first interface
- Lightweight and easy for students to understand
- Simple staff dashboard that is not complicated to use
- Combining appointments and walk-in queue in a single system

---

## SCOPE FOR THE SCHOOL PROJECT / PROTOTYPE

To keep the project from becoming too large, only 3 to 4 sample services may be chosen at first:

1. **Registrar** – request for a school document or record
2. **Guidance Office** – counseling appointment
3. **Scholarship / Financial Assistance Office** – scholarship concern
4. **IT Support** – account, Wi-Fi, or technical concern

In the HTML, CSS, and JavaScript mockup, fictional/sample data and localStorage may be used. There is no need to use real personal data, real student accounts, or real school records.

Main screens that can be built in the prototype:
- Landing page
- Student dashboard
- Service directory
- Service details / requirements page
- Appointment booking page
- Digital queue ticket page
- Request status tracker
- Staff dashboard mockup
- Notification page

**Core value proposition:**

> "Clearer service, shorter lines, and students who know what to do next."
