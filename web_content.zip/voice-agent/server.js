// SUNO AI Voice Agent - Backend server (zero external dependencies, Node 18+)
// Serves the PWA and provides API proxies: LLM providers, web search, URL fetch, GitHub repo analysis.
import './lib/env.js';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chatWithProvider } from './lib/llm.js';
import { webSearch, fetchUrlText } from './lib/search.js';
import { analyzeRepo } from './lib/github.js';
import * as devices from './lib/devices.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, 'public');

const PORT = process.env.PORT || 3000;
const SERVER_LLM = { provider: process.env.SERVER_PROVIDER || '', apiKey: process.env.SERVER_API_KEY || '', model: process.env.SERVER_MODEL || '', baseUrl: process.env.SERVER_BASE_URL || '' };
if (SERVER_LLM.provider && SERVER_LLM.apiKey) console.log(`  Server brain: ${SERVER_LLM.provider} (${SERVER_LLM.model || 'default model'})`);

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json', '.woff2': 'font/woff2'
};

function send(res, status, body, type = 'application/json; charset=utf-8') {
  const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': type,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Cache-Control': 'no-store'
  });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', c => { raw += c; if (raw.length > 5e6) req.destroy(); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

const routes = {
  'POST /api/chat': async (body) => {
    let { provider = 'demo', model, apiKey, messages = [], system = '', temperature = 0.7, maxTokens = 1024, baseUrl } = body;
    if (provider === 'server' || (provider === 'demo' && SERVER_LLM.apiKey)) {
      if (!SERVER_LLM.apiKey) throw new Error('Server par koi key configure nahi hai (.env mein SERVER_API_KEY daalo).');
      provider = SERVER_LLM.provider; apiKey = SERVER_LLM.apiKey; model = SERVER_LLM.model || undefined; baseUrl = SERVER_LLM.baseUrl || undefined;
    }
    const text = await chatWithProvider({ provider, model, apiKey, messages, system, temperature, maxTokens, baseUrl });
    return { text };
  },
  'GET /api/config': async () => ({ serverBrain: !!(SERVER_LLM.provider && SERVER_LLM.apiKey), provider: SERVER_LLM.provider, model: SERVER_LLM.model, deviceToken: devices.DEVICE_TOKEN, phoneConnected: devices.isConnected() }),
  'POST /api/search': async (body) => ({ results: await webSearch(body.query || '', body.limit || 6) }),
  'POST /api/fetch': async (body) => ({ text: await fetchUrlText(body.url || '', body.maxChars || 8000) }),
  'POST /api/github': async (body) => analyzeRepo(body.url || '', body.token || ''),
  'GET /api/health': async () => ({ ok: true, time: new Date().toISOString() }),
  // ---- Phone bridge (Android companion) ----
  'POST /api/device/run': async (body) => { const res = await devices.runOnPhone(body.action, body.args || {}, body.timeoutMs || 35000); return res; },
  'GET /api/device/status': async () => devices.status(),
  'GET /api/device/poll': async (_b, url) => devices.poll(url.searchParams.get('token'), { model: url.searchParams.get('model') || '', sdk: url.searchParams.get('sdk') || '' }, Number(url.searchParams.get('timeout')) || 25000),
  'POST /api/device/result': async (body) => devices.postResult(body.token, body.id, body.ok, body.result)
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === 'OPTIONS') return send(res, 204, '');

  const key = `${req.method} ${url.pathname}`;
  if (routes[key]) {
    try {
      const body = req.method === 'POST' ? await readBody(req) : {};
      const out = await routes[key](body, url);
      return send(res, 200, out);
    } catch (e) {
      console.error(`[${key}]`, e.message);
      return send(res, 500, { error: e.message || 'Server error' });
    }
  }

  // Static files
  let filePath = path.join(PUBLIC_DIR, decodeURIComponent(url.pathname));
  if (!filePath.startsWith(PUBLIC_DIR)) return send(res, 403, 'Forbidden', 'text/plain');
  if (url.pathname === '/' || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(PUBLIC_DIR, 'index.html');
  }
  const ext = path.extname(filePath).toLowerCase();
  const stream = fs.createReadStream(filePath);
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=3600' });
  stream.pipe(res);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  SUNO AI Voice Agent running at http://0.0.0.0:${PORT}`);
  console.log(`  Phone bridge token: ${devices.DEVICE_TOKEN}  (Android app mein ye daalo)\n`);
});
