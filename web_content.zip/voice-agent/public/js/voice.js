// Voice I/O: Speech-to-text (Web Speech API) + Text-to-speech (speechSynthesis)
import { state, emit } from './store.js';

const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
export const sttSupported = !!SR;
export const ttsSupported = 'speechSynthesis' in window;

let rec = null;
let listening = false;
let onResultCb = null;
let stopRequested = false;

export function isListening() { return listening; }

export function startListening(onResult, { continuous = false } = {}) {
  if (!SR) { emit('toast', 'Is browser mein voice input nahi hai. Chrome use karo.'); return false; }
  if (listening) return true;
  stopSpeaking();
  onResultCb = onResult;
  stopRequested = false;
  rec = new SR();
  rec.lang = state.settings.sttLang || 'hi-IN';
  rec.continuous = continuous;
  rec.interimResults = true;
  rec.maxAlternatives = 1;

  let finalText = '';
  rec.onstart = () => { listening = true; emit('listening', true); };
  rec.onresult = (e) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const t = e.results[i][0].transcript;
      if (e.results[i].isFinal) finalText += t + ' '; else interim += t;
    }
    emit('interim', (finalText + interim).trim());
    if (!continuous && finalText.trim()) { rec.stop(); }
  };
  rec.onerror = (e) => {
    if (e.error === 'not-allowed') emit('toast', 'Microphone permission do (browser settings).');
    else if (e.error !== 'no-speech' && e.error !== 'aborted') emit('toast', 'Voice error: ' + e.error);
  };
  rec.onend = () => {
    listening = false; emit('listening', false);
    const text = finalText.trim();
    finalText = '';
    if (text && onResultCb) onResultCb(text);
    // hands-free: restart after processing unless stopped
    if (continuous && !stopRequested && state.settings.handsFree) {
      setTimeout(() => { if (!listening && !speaking && state.settings.handsFree) startListening(onResultCb, { continuous: true }); }, 400);
    }
  };
  try { rec.start(); } catch (e) { console.warn(e); return false; }
  return true;
}

export function stopListening() {
  stopRequested = true;
  if (rec) { try { rec.stop(); } catch { /* ignore */ } }
}

// ---------------- TTS ----------------
let speaking = false;
let voices = [];
function loadVoices() { voices = speechSynthesis.getVoices(); emit('voices', voices); }
if (ttsSupported) { loadVoices(); speechSynthesis.onvoiceschanged = loadVoices; }

export function getVoices() { return voices; }

function pickVoice(text) {
  const pref = state.settings.ttsVoice;
  if (pref) { const v = voices.find(v => v.name === pref); if (v) return v; }
  const hasDevanagari = /[\u0900-\u097F]/.test(text);
  const wantHindi = hasDevanagari || state.settings.replyStyle !== 'english';
  const order = wantHindi ? ['hi-IN', 'hi', 'en-IN', 'en'] : ['en-IN', 'en-US', 'en-GB', 'en', 'hi-IN'];
  for (const lang of order) {
    const v = voices.find(v => v.lang.replace('_', '-').toLowerCase().startsWith(lang.toLowerCase()) && /google|natural|neural|online/i.test(v.name))
      || voices.find(v => v.lang.replace('_', '-').toLowerCase().startsWith(lang.toLowerCase()));
    if (v) return v;
  }
  return voices[0];
}

function cleanForSpeech(text) {
  return text
    .replace(/```[\s\S]*?```/g, ' code block. ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[*_#>|]/g, ' ')
    .replace(/\[(.*?)\]\((.*?)\)/g, '$1')
    .replace(/https?:\/\/\S+/g, ' link ')
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '')
    .replace(/\s+/g, ' ').trim();
}

export function speak(text, { onEnd } = {}) {
  if (!ttsSupported || !text) { onEnd && onEnd(); return; }
  stopSpeaking();
  const clean = cleanForSpeech(text);
  if (!clean) { onEnd && onEnd(); return; }
  // Chunk long text (Android TTS cuts off long utterances)
  const chunks = clean.match(/[^.!?।\n]+[.!?।\n]*/g) || [clean];
  const voice = pickVoice(clean);
  speaking = true; emit('speaking', true);
  let i = 0;
  const next = () => {
    if (i >= chunks.length || !speaking) { speaking = false; emit('speaking', false); onEnd && onEnd(); return; }
    const u = new SpeechSynthesisUtterance(chunks[i++].trim());
    if (voice) { u.voice = voice; u.lang = voice.lang; }
    u.rate = state.settings.ttsRate || 1;
    u.onend = next;
    u.onerror = next;
    speechSynthesis.speak(u);
  };
  next();
}

export function stopSpeaking() {
  if (!ttsSupported) return;
  speaking = false;
  speechSynthesis.cancel();
  emit('speaking', false);
}
export function isSpeaking() { return speaking; }
