// SUNO app controller: UI wiring, chat flow, voice, sheets, settings.
import { state, save, on, emit, addMemory, pushChat, resetAll, uid } from './store.js';
import { startListening, stopListening, isListening, speak, stopSpeaking, getVoices, sttSupported, ttsSupported } from './voice.js';
import { runAgentTurn, hasLLM, setServerBrain, serverBrain, setPhoneConnected } from './brain.js';
import { ensureBuiltinAgents, activeAgent, setActiveAgent, createAgent, updateAgent, deleteAgent, retryTask, deleteTask } from './agents.js';
import { learnRepo } from './github.js';

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const esc = (s = '') => s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// tiny markdown: code blocks, inline code, bold, links, line breaks
function md(text = '') {
  let h = esc(text);
  h = h.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, l, c) => `<pre><code>${c.trim()}</code></pre>`);
  h = h.replace(/`([^`\n]+)`/g, '<code>$1</code>');
  h = h.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
  h = h.replace(/(https?:\/\/[^\s<)]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
  return h;
}

let busy = false;
let toastT = null;
function toast(msg, ms = 2600) { const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, ms); }
on('toast', toast);

// ---------------- Navigation ----------------
function showView(name) {
  $$('.view').forEach(v => v.classList.toggle('active', v.dataset.view === name));
  $$('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.nav === name));
  $('#composer').hidden = name !== 'chat';
  if (name === 'chat') scrollBottom();
}
$$('.nav-btn').forEach(b => b.onclick = () => showView(b.dataset.nav));
$$('.tab').forEach(t => t.onclick = () => {
  $$('.tab').forEach(x => x.classList.toggle('active', x === t));
  $$('.tabpane').forEach(p => p.classList.toggle('active', p.dataset.pane === t.dataset.tab));
});

// ---------------- Chat rendering ----------------
const messagesEl = $('#messages');
function scrollBottom() { requestAnimationFrame(() => { messagesEl.scrollTop = messagesEl.scrollHeight; }); }

function renderChat() {
  const ag = activeAgent();
  const chat = state.chats[ag.id] || [];
  messagesEl.innerHTML = '';
  if (!chat.length) {
    const sug = ['Aaj ki top news batao', 'Researcher ko task do: best budget phone under 15000', 'Yaad rakho meri gaadi ka number DL 8C 1234', 'Naya agent banao jo mere emails likhe', '15% of 2400 kitna hota hai', 'Python chalao: print(sum(range(101)))'];
    messagesEl.innerHTML = `<div class="empty"><div class="big">${ag.emoji}</div><b>${esc(ag.name)}</b><div class="hint">${esc(ag.description)}</div>
      <div class="chips">${sug.map(s => `<button class="chip" data-s="${esc(s)}">${esc(s)}</button>`).join('')}</div></div>`;
    $$('.empty .chip').forEach(c => c.onclick = () => sendMessage(c.dataset.s));
    return;
  }
  for (const m of chat) appendMsg(m, false);
  scrollBottom();
}
function appendMsg(m, scroll = true) {
  const el = document.createElement('div');
  el.className = 'msg ' + m.role;
  if (m.role === 'assistant') {
    el.innerHTML = `<button class="speak-btn" title="Sunao"><svg><use href="#i-speaker"/></svg></button>${md(m.content)}${m.meta?.tools?.length ? `<span class="meta">🔧 ${m.meta.tools.join(', ')}</span>` : ''}`;
    el.querySelector('.speak-btn').onclick = () => speak(m.content);
  } else el.innerHTML = md(m.content);
  messagesEl.querySelector('.empty')?.remove();
  messagesEl.appendChild(el);
  if (scroll) scrollBottom();
  return el;
}
function addChip(text, cls = 'running') { const c = document.createElement('div'); c.className = 'tool-chip ' + cls; c.textContent = text; messagesEl.appendChild(c); scrollBottom(); return c; }
function typing(show) {
  messagesEl.querySelector('.typing')?.remove();
  if (show) { const t = document.createElement('div'); t.className = 'typing'; t.innerHTML = '<i></i><i></i><i></i>'; messagesEl.appendChild(t); scrollBottom(); }
}

// ---------------- Send / respond ----------------
async function sendMessage(text) {
  text = (text || '').trim();
  if (!text || busy) return;
  busy = true;
  const ag = activeAgent();
  $('#input').value = ''; autosize();
  pushChat(ag.id, { role: 'user', content: text });
  appendMsg({ role: 'user', content: text });
  typing(true);
  const history = (state.chats[ag.id] || []).filter(m => m.role !== 'system');
  let chip = null;
  try {
    const res = await runAgentTurn(ag, history, (step) => {
      if (step.type === 'tool') { typing(false); chip = addChip(`${step.name} ${summarizeArgs(step.args)}`); }
      if (step.type === 'result' && chip) { chip.className = 'tool-chip done'; chip = null; typing(true); }
      if (step.type === 'thinking') typing(true);
    });
    typing(false);
    const reply = res.text || '(khali jawab)';
    const meta = { tools: res.toolsUsed.map(t => t.name), demo: !!res.demo };
    pushChat(ag.id, { role: 'assistant', content: reply, meta });
    appendMsg({ role: 'assistant', content: reply, meta });
    if (state.settings.autoSpeak) speak(reply, { onEnd: () => { if (state.settings.handsFree) startVoice(true); } });
    else if (state.settings.handsFree) startVoice(true);
  } catch (e) {
    typing(false);
    const err = 'Error: ' + e.message + (/key/i.test(e.message) ? ' — Settings mein provider/key check karo.' : '');
    appendMsg({ role: 'system', content: err });
    toast(e.message, 4000);
  }
  busy = false;
}
function summarizeArgs(a = {}) { const v = Object.values(a)[0]; return v ? '· ' + String(v).slice(0, 40) : ''; }

$('#btnSend').onclick = () => sendMessage($('#input').value);
$('#input').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !('ontouchstart' in window)) { e.preventDefault(); sendMessage($('#input').value); } });
function autosize() { const i = $('#input'); i.style.height = 'auto'; i.style.height = Math.min(i.scrollHeight, 120) + 'px'; }
$('#input').addEventListener('input', autosize);
$('#btnNewChat').onclick = () => { const ag = activeAgent(); if (confirm(`${ag.name} ka chat clear karein?`)) { state.chats[ag.id] = []; save(); renderChat(); } };

// ---------------- Voice ----------------
const orbWrap = $('#orbWrap'), orb = $('#orb'), orbStatus = $('#orbStatus'), interimEl = $('#interim'), micBtn = $('#btnMic');
function startVoice(continuous = false) {
  if (busy && !continuous) return;
  const ok = startListening((text) => { hideOrb(); sendMessage(text); }, { continuous: continuous || state.settings.handsFree });
  if (ok) showOrb();
}
function showOrb() { orbWrap.classList.add('show'); orb.classList.remove('speaking'); orbStatus.textContent = 'Bolo, main sun raha hoon…'; interimEl.textContent = ''; }
function hideOrb() { orbWrap.classList.remove('show'); interimEl.textContent = ''; }
micBtn.onclick = () => { if (isListening()) { stopListening(); hideOrb(); } else startVoice(); };
orbWrap.onclick = () => { stopListening(); stopSpeaking(); hideOrb(); };
on('listening', (v) => { micBtn.classList.toggle('on', v); if (!v && !state.settings.handsFree) hideOrb(); });
on('interim', (t) => { interimEl.textContent = t; });
on('speaking', (v) => { if (v) { orb.classList.add('speaking'); } else { orb.classList.remove('speaking'); } });
if (!sttSupported) micBtn.title = 'Voice input not supported in this browser';

// ---------------- Agents view ----------------
function renderAgents() {
  const ag = activeAgent();
  $('#agentEmoji').textContent = ag.emoji; $('#agentName').textContent = ag.name;
  $('#agentList').innerHTML = state.agents.map(a => `
    <div class="item ${a.id === ag.id ? 'active' : ''}" data-id="${a.id}">
      <div class="ico">${a.emoji}</div>
      <div class="body"><div class="title">${esc(a.name)} ${a.source === 'github' ? '<span class="tag github">GitHub</span>' : ''}${a.builtin ? '<span class="tag">Built-in</span>' : ''}</div>
        <div class="desc">${esc(a.description)}</div>${a.repoUrl ? `<div class="muted"><a href="${a.repoUrl}" target="_blank">${a.repoUrl.replace('https://github.com/', '')}</a></div>` : ''}</div>
      <div class="actions"><button class="btn tiny" data-act="chat">Chat</button><button class="btn tiny ghost" data-act="edit">Edit</button><button class="btn tiny ghost" data-act="task">Task</button></div>
    </div>`).join('');
  $$('#agentList .item').forEach(it => {
    const id = it.dataset.id;
    it.querySelector('[data-act=chat]').onclick = () => { setActiveAgent(id); showView('chat'); };
    it.querySelector('[data-act=edit]').onclick = () => openAgentEditor(id);
    it.querySelector('[data-act=task]').onclick = async () => { const t = prompt('Is agent ko kya kaam dena hai?'); if (t) { const { delegateTask } = await import('./agents.js'); delegateTask(id, t); showView('tasks'); } };
  });
}
on('agents', () => { renderAgents(); renderChat(); });

let editingId = null;
function openAgentEditor(id) {
  editingId = id; const a = id ? state.agents.find(x => x.id === id) : null;
  $('#agentSheetTitle').textContent = a ? `Edit: ${a.name}` : 'Naya Agent';
  $('#aEmoji').value = a?.emoji || '🤖'; $('#aName').value = a?.name || ''; $('#aDesc').value = a?.description || ''; $('#aPrompt').value = a?.systemPrompt || '';
  $('#aDelete').hidden = !a || a.builtin;
  $('#agentSheet').hidden = false;
}
$('#btnAddAgent').onclick = () => openAgentEditor(null);
$('#aCancel').onclick = () => $('#agentSheet').hidden = true;
$('#aSave').onclick = () => {
  const d = { emoji: $('#aEmoji').value || '🤖', name: $('#aName').value.trim() || 'Agent', description: $('#aDesc').value.trim(), systemPrompt: $('#aPrompt').value.trim() };
  if (editingId) updateAgent(editingId, d); else createAgent({ ...d, source: 'user' });
  $('#agentSheet').hidden = true;
};
$('#aDelete').onclick = () => { if (confirm('Agent delete karein?')) { deleteAgent(editingId); $('#agentSheet').hidden = true; } };

// agent picker (header pill)
$('#agentPill').onclick = () => {
  $('#pickList').innerHTML = state.agents.map(a => `<div class="item ${a.id === state.activeAgentId ? 'active' : ''}" data-id="${a.id}"><div class="ico">${a.emoji}</div><div class="body"><div class="title">${esc(a.name)}</div><div class="desc">${esc(a.description)}</div></div></div>`).join('');
  $$('#pickList .item').forEach(it => it.onclick = () => { setActiveAgent(it.dataset.id); $('#pickSheet').hidden = true; showView('chat'); });
  $('#pickSheet').hidden = false;
};
$$('.sheet-backdrop').forEach(b => b.addEventListener('click', (e) => { if (e.target === b) b.hidden = true; }));

// ---------------- Tasks view ----------------
function renderTasks() {
  const running = state.tasks.filter(t => t.status === 'running' || t.status === 'queued').length;
  const badge = $('#taskBadge'); badge.hidden = !running; badge.textContent = running;
  $('#taskList').innerHTML = state.tasks.length ? state.tasks.map(t => `
    <div class="item" data-id="${t.id}">
      <div class="ico">${t.agentEmoji || '🤖'}</div>
      <div class="body">
        <div class="title">${esc(t.title)} <span class="tag ${t.status}">${t.status}</span></div>
        <div class="muted">${esc(t.agentName)} · ${new Date(t.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</div>
        ${t.steps.length ? `<div class="steps">${t.steps.map(s => esc(s.text)).join('<br>')}</div>` : ''}
        ${t.result ? `<div class="result">${md(t.result)}</div>` : ''}
        <div class="row gap" style="margin-top:8px">${t.result ? `<button class="btn tiny ghost" data-act="speak">🔊 Sunao</button><button class="btn tiny ghost" data-act="copy">Copy</button>` : ''}${t.status === 'failed' || t.status === 'done' ? `<button class="btn tiny ghost" data-act="retry">Retry</button>` : ''}<button class="btn tiny ghost" data-act="del">✕</button></div>
      </div></div>`).join('') : '<div class="empty"><div class="big">⚡</div><b>Abhi koi task nahi</b><div class="hint">Chat mein bolo: "Coder ko task do: ek todo app ka code likho"</div></div>';
  $$('#taskList .item').forEach(it => {
    const id = it.dataset.id; const t = state.tasks.find(x => x.id === id);
    it.querySelector('[data-act=speak]')?.addEventListener('click', () => speak(t.result));
    it.querySelector('[data-act=copy]')?.addEventListener('click', () => { navigator.clipboard?.writeText(t.result); toast('Copied'); });
    it.querySelector('[data-act=retry]')?.addEventListener('click', () => retryTask(id));
    it.querySelector('[data-act=del]')?.addEventListener('click', () => deleteTask(id));
  });
}
on('tasks', renderTasks);
on('taskDone', (t) => {
  toast(`${t.agentEmoji} ${t.agentName}: task ${t.status === 'done' ? 'poora' : 'fail'} — Tasks tab dekho`);
  if (state.settings.autoSpeak && t.status === 'done') speak(`${t.agentName} ka task poora ho gaya. ${t.result.slice(0, 200)}`);
  notify(`${t.agentName}: task ${t.status}`, t.result.slice(0, 120));
});
$('#btnClearTasks').onclick = () => { state.tasks = state.tasks.filter(t => t.status === 'running' || t.status === 'queued'); save(); renderTasks(); };

// ---------------- Memory / knowledge / notes ----------------
function renderMemory() {
  $('#memList').innerHTML = state.memory.map(m => `<div class="item"><div class="ico">🧠</div><div class="body"><div class="desc" style="color:var(--text)">${esc(m.text)}</div><div class="muted">${new Date(m.ts).toLocaleString('en-IN')}</div></div><button class="btn tiny ghost" data-id="${m.id}">✕</button></div>`).join('') || '<div class="hint">Abhi memory khali hai. Chat mein bolo: "Yaad rakho ..."</div>';
  $$('#memList [data-id]').forEach(b => b.onclick = () => { state.memory = state.memory.filter(m => m.id !== b.dataset.id); save(); renderMemory(); });
  $('#knowList').innerHTML = state.knowledge.map(k => `<div class="item"><div class="ico">${k.kind === 'agent-repo' ? '🧩' : '📚'}</div><div class="body"><div class="title">${esc(k.title)} <span class="tag ${k.kind === 'agent-repo' ? 'github' : ''}">${k.kind === 'agent-repo' ? 'agent' : 'skill'}</span></div><div class="desc">${esc(k.summary)}</div><div class="muted"><a href="${k.source}" target="_blank">${esc(k.source)}</a> · ${(k.content || '').length.toLocaleString()} chars</div></div><button class="btn tiny ghost" data-id="${k.id}">✕</button></div>`).join('') || '<div class="hint">Neeche GitHub button dabao aur koi repo link paste karo.</div>';
  $$('#knowList [data-id]').forEach(b => b.onclick = () => { state.knowledge = state.knowledge.filter(k => k.id !== b.dataset.id); save(); renderMemory(); });
  $('#noteList').innerHTML = state.notes.map(n => `<div class="item"><div class="ico">📝</div><div class="body"><div class="desc" style="color:var(--text)">${esc(n.text)}</div></div><button class="btn tiny ghost" data-id="${n.id}">✓</button></div>`).join('') || '<div class="hint">Koi note nahi.</div>';
  $$('#noteList [data-id]').forEach(b => b.onclick = () => { state.notes = state.notes.filter(n => n.id !== b.dataset.id); save(); renderMemory(); });
  $('#remList').innerHTML = state.reminders.filter(r => !r.done).map(r => `<div class="item"><div class="ico">⏰</div><div class="body"><div class="desc" style="color:var(--text)">${esc(r.text)}</div><div class="muted">${new Date(r.at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</div></div></div>`).join('') || '<div class="hint">Koi reminder nahi.</div>';
}
on('memory', renderMemory); on('knowledge', renderMemory); on('notes', renderMemory); on('reminders', renderMemory);
$('#memForm').onsubmit = (e) => { e.preventDefault(); const v = $('#memInput').value.trim(); if (v) { addMemory(v, ['manual']); $('#memInput').value = ''; } };
$('#noteForm').onsubmit = (e) => { e.preventDefault(); const v = $('#noteInput').value.trim(); if (v) { state.notes.unshift({ id: uid(), text: v, ts: Date.now() }); save(); $('#noteInput').value = ''; renderMemory(); } };

// reminders ticker
function notify(title, body) { if ('Notification' in window && Notification.permission === 'granted') { try { new Notification(title, { body, icon: '/icons/icon-192.png' }); } catch { /* ignore */ } } }
setInterval(() => {
  const now = Date.now();
  for (const r of state.reminders) {
    if (!r.done && r.at <= now) { r.done = true; save(); toast('⏰ ' + r.text, 6000); speak('Reminder: ' + r.text); notify('⏰ Reminder', r.text); if (navigator.vibrate) navigator.vibrate([200, 100, 200]); renderMemory(); }
  }
}, 5000);

// ---------------- GitHub sheet ----------------
$('#btnGithub').onclick = async () => {
  $('#ghSheet').hidden = false; $('#ghProgress').hidden = true; $('#ghUrl').value = '';
  try { const clip = await navigator.clipboard?.readText(); if (clip && /github\.com\/[\w.-]+\/[\w.-]+/.test(clip)) $('#ghUrl').value = clip.trim(); } catch { /* no clipboard permission */ }
  setTimeout(() => $('#ghUrl').focus(), 100);
};
$('#ghCancel').onclick = () => $('#ghSheet').hidden = true;
$('#ghGo').onclick = async () => {
  const url = $('#ghUrl').value.trim(); if (!url) return;
  const p = $('#ghProgress'); p.hidden = false; p.className = 'gh-progress'; p.textContent = 'Shuru…'; $('#ghGo').disabled = true;
  try {
    const r = await learnRepo(url, { onProgress: (t) => { p.textContent = t; } });
    p.className = 'gh-progress ok'; p.textContent = r.mode === 'agent' ? `✅ Naya agent bana: ${r.agent.emoji} ${r.agent.name}` : `✅ Seekh liya: ${r.knowledge.title}`;
    const ag = activeAgent();
    pushChat(ag.id, { role: 'system', content: `[GitHub] ${url}` });
    pushChat(ag.id, { role: 'assistant', content: r.summaryForModel, meta: { tools: ['learn_github_repo'] } });
    renderChat();
    if (state.settings.autoSpeak) speak(r.mode === 'agent' ? `Repo analyze ho gaya. Ye agent project hai, maine ${r.agent.name} naam ka naya agent bana diya.` : `Repo analyze ho gaya. Maine isse apni knowledge mein add kar liya, ab main iske baare mein jaanta hoon.`);
    setTimeout(() => { $('#ghSheet').hidden = true; if (r.mode === 'agent') { setActiveAgent(r.agent.id); } showView('chat'); }, 1200);
  } catch (e) { p.className = 'gh-progress err'; p.textContent = '❌ ' + e.message; }
  $('#ghGo').disabled = false;
};

// ---------------- Settings ----------------
const KEY_HELP = {
  server: 'Server (.env) mein pehle se key configured hai — kuch nahi karna. Apni alag key chahiye to doosra provider chuno.',
  demo: 'Bina key ke basic kaam: voice, time, calculator, web search, GitHub analysis, memory, notes. Full intelligence ke liye koi bhi FREE provider chuno.',
  gemini: 'FREE key: aistudio.google.com → "Get API key". Default model: gemini-flash-lite-latest.',
  groq: 'FREE key: console.groq.com → API Keys. Bahut fast. Default: llama-3.3-70b-versatile.',
  openrouter: 'openrouter.ai → Keys. Free models ke liye model naam ":free" wala do.',
  openai: 'platform.openai.com → API keys. Default: gpt-4o-mini.',
  anthropic: 'console.anthropic.com → API keys. Default: claude-3-5-haiku-latest.',
  ollama: 'PC par Ollama chalao: OLLAMA_ORIGINS=* ollama serve. Base URL: http://<pc-ip>:11434 (server se reachable hona chahiye).',
  custom: 'Koi bhi OpenAI-compatible endpoint (LM Studio, Together, DeepSeek, etc.). Base URL /v1 tak do.'
};
function loadSettingsUI() {
  const s = state.settings;
  $('#sProvider').value = s.provider; $('#sApiKey').value = s.apiKey; $('#sModel').value = s.model; $('#sBaseUrl').value = s.baseUrl;
  $('#sSttLang').value = s.sttLang; $('#sReplyStyle').value = s.replyStyle; $('#sTtsRate').value = s.ttsRate; $('#rateVal').textContent = s.ttsRate + 'x';
  $('#sAutoSpeak').checked = s.autoSpeak; $('#sHandsFree').checked = s.handsFree; $('#sUserName').value = s.userName; $('#sGithubToken').value = s.githubToken; $('#sMaxSteps').value = s.maxToolSteps;
  $('#baseUrlRow').hidden = !(s.provider === 'ollama' || s.provider === 'custom');
  $('#keyHelp').textContent = KEY_HELP[s.provider] || '';
  const badge = $('#modeBadge'); badge.innerHTML = '<i></i>' + (hasLLM() ? (s.provider === 'server' ? (serverBrain?.provider || 'server').toUpperCase() : s.provider.toUpperCase()) : 'DEMO'); badge.classList.toggle('live', hasLLM());
  fillVoices();
}
function fillVoices() {
  const sel = $('#sTtsVoice'); const cur = state.settings.ttsVoice;
  const vs = getVoices().filter(v => /^(hi|en)/i.test(v.lang));
  sel.innerHTML = '<option value="">Auto (Hindi pehle)</option>' + vs.map(v => `<option value="${esc(v.name)}" ${v.name === cur ? 'selected' : ''}>${esc(v.name)} (${v.lang})</option>`).join('');
}
on('voices', fillVoices);
function bind(id, key, type = 'value') {
  $(id).addEventListener(type === 'checked' ? 'change' : 'input', (e) => {
    state.settings[key] = type === 'checked' ? e.target.checked : (e.target.type === 'number' || e.target.type === 'range' ? Number(e.target.value) : e.target.value);
    save(); loadSettingsUI();
  });
}
bind('#sProvider', 'provider'); bind('#sApiKey', 'apiKey'); bind('#sModel', 'model'); bind('#sBaseUrl', 'baseUrl'); bind('#sSttLang', 'sttLang'); bind('#sReplyStyle', 'replyStyle');
bind('#sTtsVoice', 'ttsVoice'); bind('#sTtsRate', 'ttsRate'); bind('#sAutoSpeak', 'autoSpeak', 'checked'); bind('#sHandsFree', 'handsFree', 'checked'); bind('#sUserName', 'userName'); bind('#sGithubToken', 'githubToken'); bind('#sMaxSteps', 'maxToolSteps');
$('#btnTestLLM').onclick = async () => {
  const out = $('#llmTestOut'); out.textContent = 'Testing…';
  try {
    const s = state.settings;
    const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ provider: s.provider, model: s.model || undefined, apiKey: s.apiKey, baseUrl: s.baseUrl, system: 'Reply in 5 words.', messages: [{ role: 'user', content: 'Say hello in Hinglish' }], maxTokens: 30 }) });
    const d = await r.json();
    out.textContent = d.error ? '❌ ' + (d.error === 'DEMO_MODE' ? 'Demo mode — koi provider chuno' : d.error) : '✅ ' + d.text;
  } catch (e) { out.textContent = '❌ ' + e.message; }
};
$('#btnExport').onclick = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' })); a.download = 'suno-backup.json'; a.click(); };
$('#importFile').onchange = async (e) => { const f = e.target.files[0]; if (!f) return; try { const d = JSON.parse(await f.text()); Object.assign(state, d); save(); location.reload(); } catch { toast('Invalid backup file'); } };
$('#btnReset').onclick = () => { if (confirm('Sab data delete ho jayega. Pakka?')) resetAll(); };

// ---------------- Phone bridge status ----------------
async function refreshBridge() {
  try {
    const d = await (await fetch('/api/device/status')).json();
    setPhoneConnected(d.connected);
    const el = $('#bridgeStatus'); el.textContent = d.connected ? `● Connected ${d.device?.model ? '· ' + d.device.model : ''}` : '○ Not connected';
    el.className = 'tag ' + (d.connected ? 'done' : 'failed');
    $('#bridgeUrl').value = location.origin; $('#bridgeToken').value = d.token || '';
  } catch { /* offline */ }
}
$('#btnBridgeRefresh').onclick = refreshBridge;
setInterval(refreshBridge, 15000);

// ---------------- PWA install ----------------
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredPrompt = e; $('#btnInstall').hidden = false; });
$('#btnInstall').onclick = async () => { if (!deferredPrompt) return; deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt = null; $('#btnInstall').hidden = true; };
if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('/sw.js').catch(() => {});

// ---------------- Boot ----------------
ensureBuiltinAgents();
try {
  const cfg = await (await fetch('/api/config')).json();
  setServerBrain(cfg); setPhoneConnected(cfg.phoneConnected);
  if (cfg.serverBrain && state.settings.provider === 'demo') { state.settings.provider = 'server'; save(); }
  if (!cfg.serverBrain && state.settings.provider === 'server') { state.settings.provider = 'demo'; save(); }
} catch { /* offline */ }
loadSettingsUI();
renderAgents(); renderChat(); renderTasks(); renderMemory(); refreshBridge();
showView('chat');
if (!hasLLM() && !sessionStorage.getItem('demoHint')) { sessionStorage.setItem('demoHint', '1'); setTimeout(() => toast('Demo mode: Settings → free Gemini/Groq key daalo to SUNO poora smart ho jayega', 5000), 800); }
