// Persistent state (localStorage). Everything the app remembers lives here.
const KEY = 'suno_state_v1';

const DEFAULT_SETTINGS = {
  provider: 'demo',          // demo | gemini | openai | anthropic | groq | openrouter | ollama | custom
  model: '',
  apiKey: '',
  baseUrl: '',
  githubToken: '',
  userName: 'Boss',
  sttLang: 'hi-IN',
  replyStyle: 'hinglish',    // hinglish | hindi | english
  autoSpeak: true,
  handsFree: false,
  wakeWord: '',
  ttsRate: 1.0,
  ttsVoice: '',
  maxToolSteps: 10
};

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

function load() {
  try {
    const s = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (s) { s.settings = { ...DEFAULT_SETTINGS, ...(s.settings || {}) }; return s; }
  } catch { /* ignore */ }
  return {
    settings: { ...DEFAULT_SETTINGS },
    agents: [],           // {id, name, emoji, description, systemPrompt, tools:[], knowledgeIds:[], source, builtin, createdAt}
    activeAgentId: 'suno',
    chats: {},            // agentId -> [{role, content, ts, meta}]
    memory: [],           // {id, text, tags, ts}
    knowledge: [],        // {id, title, source, summary, content, ts}
    tasks: [],            // {id, title, agentId, status, steps:[], result, createdAt, finishedAt}
    reminders: [],        // {id, text, at, done}
    notes: []             // {id, text, ts}
  };
}

export const state = load();

let saveTimer = null;
export function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      // keep chats bounded
      for (const k of Object.keys(state.chats)) if (state.chats[k].length > 200) state.chats[k] = state.chats[k].slice(-200);
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch (e) { console.warn('save failed', e); }
  }, 150);
}

export function resetAll() { localStorage.removeItem(KEY); location.reload(); }

// ---- tiny event bus ----
const listeners = {};
export function on(evt, fn) { (listeners[evt] ||= []).push(fn); }
export function emit(evt, data) { (listeners[evt] || []).forEach(fn => { try { fn(data); } catch (e) { console.error(e); } }); }

// ---- memory helpers ----
export function addMemory(text, tags = []) {
  const m = { id: uid(), text: text.trim(), tags, ts: Date.now() };
  state.memory.unshift(m); save(); emit('memory'); return m;
}
export function searchMemory(query, limit = 6) {
  const q = (query || '').toLowerCase().split(/\W+/).filter(w => w.length > 2);
  const scored = state.memory.map(m => {
    const t = m.text.toLowerCase();
    let s = 0; q.forEach(w => { if (t.includes(w)) s += 2; });
    s += Math.max(0, 1 - (Date.now() - m.ts) / (30 * 864e5)); // recency
    return [s, m];
  }).filter(([s]) => s > 0.5).sort((a, b) => b[0] - a[0]).slice(0, limit).map(([, m]) => m);
  return scored;
}

export function addKnowledge(k) {
  const item = { id: uid(), ts: Date.now(), ...k };
  state.knowledge.unshift(item); save(); emit('knowledge'); return item;
}
export function searchKnowledge(query, limit = 3) {
  const q = (query || '').toLowerCase().split(/\W+/).filter(w => w.length > 2);
  return state.knowledge.map(k => {
    const t = (k.title + ' ' + k.summary + ' ' + (k.content || '').slice(0, 5000)).toLowerCase();
    let s = 0; q.forEach(w => { if (t.includes(w)) s += 1; });
    return [s, k];
  }).filter(([s]) => s > 0).sort((a, b) => b[0] - a[0]).slice(0, limit).map(([, k]) => k);
}

export function pushChat(agentId, msg) {
  (state.chats[agentId] ||= []).push({ ts: Date.now(), ...msg });
  save(); emit('chat', { agentId, msg });
}
