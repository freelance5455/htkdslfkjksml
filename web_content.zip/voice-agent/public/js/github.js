// GitHub repo -> Agent (if agent project) or Knowledge/Skill (otherwise)
import { state, addKnowledge, emit } from './store.js';
import { hasLLM } from './brain.js';
import { createAgent } from './agents.js';

async function analyze(url) {
  const r = await fetch('/api/github', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url, token: state.settings.githubToken }) });
  const d = await r.json();
  if (!r.ok || d.error) throw new Error(d.error || 'GitHub analyze failed');
  return d;
}

async function llmJSON(system, user) {
  const s = state.settings;
  const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ provider: s.provider, model: s.model || undefined, apiKey: s.apiKey, baseUrl: s.baseUrl, system, messages: [{ role: 'user', content: user }], temperature: 0.3, maxTokens: 1200 }) });
  const d = await r.json();
  if (!r.ok || d.error) throw new Error(d.error);
  const m = d.text.match(/\{[\s\S]*\}/);
  return m ? JSON.parse(m[0]) : null;
}

function heuristicSummary(a) {
  const paras = (a.readme || '')
    .replace(/<[^>]+>/g, ' ').replace(/!\[.*?\]\(.*?\)/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/^#.*$/gm, '').replace(/^\s*[-*|>].*$/gm, '')
    .split(/\n\s*\n/).map(s => s.replace(/\s+/g, ' ').trim());
  const prose = paras.find(s => s.length > 80 && (s.match(/[.!?।]/g) || []).length >= 1 && !/[·•|]\s*\w+\s*[·•|]/.test(s) && (s.match(/https?:\/\//g) || []).length < 2 && s.split(' ').length > 12);
  const desc = (a.description || '').trim();
  const out = desc.length > 40 ? desc + (prose ? ' — ' + prose : '') : (prose || desc || 'No description');
  return out.slice(0, 400);
}

function repoContext(a) {
  return `Repo: ${a.fullName}\nDescription: ${a.description}\nLanguage: ${a.language} (${a.languages.join(', ')})\nStars: ${a.stars}\nTopics: ${a.topics.join(', ')}\nStructure: ${a.structure}\n\n# README\n${a.readme.slice(0, 9000)}\n\n# Key files\n${a.keyFiles.map(k => `## ${k.path}\n${k.content.slice(0, 2500)}`).join('\n\n')}`;
}

/**
 * Learn a GitHub repo: returns {mode:'agent'|'knowledge', agent?, knowledge, analysis, summaryForModel}
 */
export async function learnRepo(url, { onProgress = () => {} } = {}) {
  onProgress('GitHub se repo fetch ho raha hai…');
  const a = await analyze(url);
  onProgress(`${a.fullName} mila — ${a.fileCount} files, ${a.stars}⭐. Analyze kar raha hoon…`);

  const content = repoContext(a);
  let summary = heuristicSummary(a);
  let persona = null;

  if (hasLLM()) {
    try {
      onProgress('AI repo ko samajh raha hai…');
      const out = await llmJSON(
        'You analyze GitHub repos. Reply ONLY with JSON.',
        `Analyze this repo and reply with JSON:\n{"summary":"3-4 line Hinglish summary of what it does and how to use it","isAgent":true/false (is this an AI agent/assistant/bot/LLM-tool project?),"agentName":"short name","emoji":"one emoji","persona":"If isAgent: a detailed system prompt (Hinglish ok) that makes an AI behave like this repo's agent — its purpose, capabilities, style, workflow, tools it would use. Else: empty string","skills":["3-6 short skill/knowledge bullets learned from this repo"]}\n\n${content.slice(0, 14000)}`
      );
      if (out) { summary = out.summary || summary; persona = out; }
    } catch (e) { console.warn('LLM repo analysis failed, using heuristics', e.message); }
  }

  const isAgent = persona ? !!persona.isAgent : a.isAgent;

  // Always store as knowledge (so SUNO gets smarter either way)
  const knowledge = addKnowledge({
    title: a.fullName, source: a.url, kind: isAgent ? 'agent-repo' : 'skill',
    summary: summary + (persona?.skills?.length ? '\nSkills: ' + persona.skills.join('; ') : ''),
    content, meta: { stars: a.stars, language: a.language, topics: a.topics, agentScore: a.agentScore }
  });

  let agent = null;
  if (isAgent) {
    const name = persona?.agentName || a.repo.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    const systemPrompt = persona?.persona || `Tum "${name}" ho — GitHub repo ${a.fullName} par based agent. Repo ka purpose: ${summary}\n\nIs repo ke README aur code ke hisaab se behave karo: jo capabilities repo describe karta hai, wahi tum user ke liye tools ke saath karo. Repo details chahiye ho to knowledge_search("${a.fullName}") use karo.\n\nRepo README (short):\n${a.readme.slice(0, 3000)}`;
    agent = createAgent({ name, emoji: persona?.emoji || '🧩', description: summary.slice(0, 140), systemPrompt, tools: [], knowledgeIds: [knowledge.id], source: 'github', repoUrl: a.url });
  }
  emit('knowledge');

  const summaryForModel = isAgent
    ? `✅ Repo ${a.fullName} analyze ho gaya — ye ek AI AGENT project hai (score ${a.agentScore}). Maine naya agent banaya: ${agent.emoji} ${agent.name}. Summary: ${summary}\nAb Agents tab se ise select karke baat kar sakte ho, ya "delegate_task" se kaam de sakte ho.`
    : `✅ Repo ${a.fullName} analyze ho gaya — ye agent project nahi hai, isliye maine ise apni knowledge/skill mein add kar liya (ab main iske baare mein jaanta hoon). Summary: ${summary}${persona?.skills ? '\nSeekha: ' + persona.skills.join('; ') : ''}`;

  return { mode: isAgent ? 'agent' : 'knowledge', agent, knowledge, analysis: a, summaryForModel };
}
