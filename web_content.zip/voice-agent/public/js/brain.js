// The "brain": builds prompts, talks to the LLM (via server), runs the tool loop. Falls back to Demo Brain without API key.
import { state, searchMemory, emit } from './store.js';
import { toolsDescription, runTool, TOOLS } from './tools.js';

export let serverPhone = false;
export function setPhoneConnected(v) { serverPhone = !!v; }
export let serverBrain = null; // {provider, model} if server has a pre-configured key
export function setServerBrain(cfg) { serverBrain = cfg && cfg.serverBrain ? cfg : null; }
export function hasLLM() {
  const s = state.settings;
  if (s.provider === 'server') return !!serverBrain;
  if (s.provider === 'demo') return false;
  return !!(s.apiKey || s.provider === 'ollama');
}

const STYLE = {
  hinglish: 'Hinglish mein baat karo (Hindi + English mix, Roman/Latin script), jaise dost baat karta hai. Natural, short, warm.',
  hindi: 'शुद्ध हिंदी में (देवनागरी लिपि) जवाब दो। सरल और स्पष्ट।',
  english: 'Reply in clear, friendly English.'
};

export function buildSystemPrompt(agent) {
  const s = state.settings;
  const mem = state.memory.slice(0, 15).map(m => '- ' + m.text).join('\n');
  const know = state.knowledge.slice(0, 10).map(k => `- ${k.title}: ${k.summary.slice(0, 160)}`).join('\n');
  const agents = state.agents.filter(a => a.id !== agent.id).map(a => `- ${a.emoji} ${a.name} (id: ${a.id}): ${a.description}`).join('\n');
  const tools = agent.tools && agent.tools.length ? agent.tools : Object.keys(TOOLS);

  return `${agent.systemPrompt}

# Baat karne ka style
${STYLE[s.replyStyle] || STYLE.hinglish}
User ka naam: ${s.userName}. Ye ek VOICE assistant hai — jawab bolne layak rakho: chhote paragraphs, no long markdown tables. Zaroori ho to hi lists.
Aaj: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'full', timeStyle: 'short' })} (India).

# Tools (jab zaroorat ho tab use karo)
Tool call karne ke liye EXACTLY ye format likho ("name" aur "args" dono zaroori hain):
<tool>{"name":"tool_name","args":{...}}</tool>
Examples:
<tool>{"name":"web_search","args":{"query":"Delhi AQI today"}}</tool>
<tool>{"name":"run_python","args":{"code":"print(sum(range(10)))"}}</tool>
<tool>{"name":"delegate_task","args":{"agent":"researcher","task":"..."}}</tool>
Ek baar mein ek tool. Tool ka result milne ke baad final jawab do (result ko user-friendly summarize karo — search results ko padh ke jawab do, "fetch nahi ho pa raha" mat bolo agar results aaye hain). Agar tool ki zaroorat nahi to seedha jawab do.
Available tools:
${toolsDescription(tools)}

# Rules
- Jo user bole wo karo. Kaam bada ho to sub-agent ko delegate_task karo ya khud tools se karo.
- Latest info / facts ke liye web_search zaroor karo, guess mat karo.
- User ki personal baatein (naam, pasand, plans) remember tool se save karo.
- Jab seekhe hue repo/knowledge ke baare mein poocha jaye to knowledge_search use karo.
- GitHub link dikhe to learn_github_repo call karo.
- Phone ke kaam (call, SMS, WhatsApp, app kholna, location, share) ke liye open_app/make_call/send_sms/whatsapp_message/get_location/share_text use karo — bas bolo mat, karo.
- POORA phone control (screen padhna, tap, type, settings, direct call/SMS, volume, torch, notifications padhna) ke liye "phone" tool use karo${serverPhone ? ' (Android companion CONNECTED hai ✅ — freely use karo)' : ' (abhi companion app connected NAHI hai — pehle browser wale tools try karo, warna user ko batao ki SUNO Android app start kare)'}.
- Phone tool se multi-step kaam karte waqt: pehle open_app, phir wait 1500, phir read_screen, phir tap_text/type. Aankh band karke tap mat karo — screen padho.${serverPhone ? `
- Companion connected hai, isliye: contact ke NAAM se message/call ("Mummy ko message karo") = phone tool se app ke andar jao (open_app whatsapp → read_screen → tap_text Mummy → type → tap_text Send → read_screen se confirm). whatsapp_message/make_call/send_sms browser tools sirf tab jab user ne NUMBER diya ho. Kaam poora hone tak steps karte raho, beech mein user se mat poochho.` : ''}

# Long-term memory (user ke baare mein)
${mem || '(abhi khali)'}

# Seekhi hui knowledge / skills
${know || '(abhi kuch nahi seekha)'}

# Doosre agents (delegate ke liye)
${agents || '(koi nahi)'}`;
}

function lenientJSON(s) {
  const tries = [s, s.replace(/\r?\n/g, '\\n'), s.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']')];
  for (const t of tries) { try { return JSON.parse(t); } catch { /* next */ } }
  // last resort: extract "name" and biggest string fields via regex
  const name = s.match(/"name"\s*:\s*"([\w_]+)"/)?.[1];
  const args = {};
  for (const m of s.matchAll(/"(\w+)"\s*:\s*"((?:[^"\\]|\\.)*)"/g)) if (m[1] !== 'name') args[m[1]] = m[2].replace(/\\n/g, '\n').replace(/\\"/g, '"');
  return name || Object.keys(args).length ? { name, args } : null;
}

function inferToolName(args) {
  const k = Object.keys(args);
  if (k.includes('code')) return /\bconsole\.|=>|\bconst\b|\blet\b|;\s*$/m.test(args.code) && !/\bprint\(|\bdef\b|\bimport\b/.test(args.code) ? 'run_js' : 'run_python';
  if (k.includes('agent') && k.includes('task')) return 'delegate_task';
  if (k.includes('query')) return 'web_search';
  if (k.includes('url')) return /github\.com\//.test(args.url) ? 'learn_github_repo' : 'fetch_url';
  if (k.includes('expression')) return 'calculator';
  if (k.includes('minutes')) return 'set_reminder';
  if (k.includes('systemPrompt') || (k.includes('name') && k.includes('description'))) return 'create_agent';
  if (k.includes('text')) return 'remember';
  return null;
}

// Extract a balanced {...} JSON object starting at/after index `from` (string-aware)
function extractJSON(text, from) {
  const start = text.indexOf('{', from);
  if (start < 0) return null;
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < text.length; i++) {
    const c = text[i];
    if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; continue; }
    if (c === '"') inStr = true;
    else if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) return { json: text.slice(start, i + 1), end: i + 1 }; }
  }
  return { json: text.slice(start), end: text.length }; // unterminated — let lenient parser try
}

function parseToolCall(text) {
  let idx = text.search(/<tool>/i);
  let jsonStr = null, rawEnd = 0, rawStart = 0;
  if (idx >= 0) {
    const ex = extractJSON(text, idx); if (!ex) return null;
    jsonStr = ex.json; rawStart = idx;
    const close = text.slice(ex.end).match(/^\s*<\/\w+>/); rawEnd = ex.end + (close ? close[0].length : 0);
  } else {
    const m = text.match(/```(?:json|tool)?\s*(\{\s*"(?:name|tool)"\s*:\s*"[\w_]+"[\s\S]*?\})\s*```/);
    if (!m) return null;
    jsonStr = m[1]; rawStart = m.index; rawEnd = m.index + m[0].length;
  }
  const obj = lenientJSON(jsonStr);
  if (!obj) return null;
  const mRaw = [text.slice(rawStart, rawEnd)];
  let name = obj.name || obj.tool || obj.function;
  let args = obj.args || obj.arguments || obj.parameters || obj.input;
  if (!args) { args = { ...obj }; delete args.name; delete args.tool; delete args.function; }
  if (name && !TOOLS[name]) { const alt = name.toLowerCase().replace(/[^a-z_]/g, ''); name = TOOLS[alt] ? alt : (Object.keys(TOOLS).find(t => alt.includes(t) || t.includes(alt)) || name); }
  if (!name || !TOOLS[name]) name = inferToolName(args) || name;
  if (!name || !TOOLS[name]) return null;
  return { name, args, raw: mRaw[0] };
}

async function callLLM(system, messages) {
  const s = state.settings;
  const r = await fetch('/api/chat', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ provider: s.provider, model: s.model || undefined, apiKey: s.apiKey, baseUrl: s.baseUrl, system, messages, maxTokens: 1500 })
  });
  const d = await r.json();
  if (!r.ok || d.error) throw new Error(d.error || 'LLM error');
  return d.text || '';
}

/**
 * Run one agent turn with tool loop.
 * @param agent agent object
 * @param history [{role, content}] (already includes latest user message)
 * @param onStep callback({type:'tool'|'result'|'thinking', ...}) for live UI updates
 */
export async function runAgentTurn(agent, history, onStep = () => {}) {
  if (!hasLLM()) return demoBrain(agent, history, onStep);

  const system = buildSystemPrompt(agent);
  const msgs = history.slice(-24).map(m => ({ role: m.role, content: m.content }));
  const maxSteps = state.settings.maxToolSteps || 6;
  const toolsUsed = [];

  for (let step = 0; step < maxSteps; step++) {
    onStep({ type: 'thinking' });
    let text = await callLLM(system, msgs);
    const call = parseToolCall(text);
    if (!call) return { text: text.trim(), toolsUsed };

    onStep({ type: 'tool', name: call.name, args: call.args });
    const result = await runTool(call.name, call.args, { agent });
    toolsUsed.push({ name: call.name, args: call.args, result });
    onStep({ type: 'result', name: call.name, result });

    const pre = text.replace(call.raw, '').trim();
    msgs.push({ role: 'assistant', content: (pre ? pre + '\n' : '') + call.raw });
    msgs.push({ role: 'user', content: `[TOOL RESULT: ${call.name}]\n${result}\n\n(Ab is result ke basis par user ko final jawab do, ya zaroorat ho to agla tool call karo.)` });
  }
  const final = await callLLM(system, [...msgs, { role: 'user', content: 'Ab tool use mat karo — jo pata chala uska final jawab do.' }]);
  return { text: final.replace(/<tool>[\s\S]*?<\/tool>/g, '').trim(), toolsUsed };
}

// ---------------- DEMO BRAIN (no API key) ----------------
// Rule-based, but wired to all the real tools so the app is useful even without an LLM.
async function demoBrain(agent, history, onStep) {
  const last = history[history.length - 1]?.content || '';
  const t = last.replace(/^\[BACKGROUND TASK\][^\n]*\n+/i, '').trim();
  const l = t.toLowerCase();
  const toolsUsed = [];
  const use = async (name, args) => { onStep({ type: 'tool', name, args }); const r = await runTool(name, args, { agent }); toolsUsed.push({ name, args, result: r }); onStep({ type: 'result', name, result: r }); return r; };
  const reply = (text) => ({ text, toolsUsed, demo: true });

  // GitHub link
  const gh = t.match(/https?:\/\/github\.com\/[\w.-]+\/[\w.-]+/i);
  if (gh) { const r = await use('learn_github_repo', { url: gh[0] }); return reply(r); }

  // Greetings
  if (/^(hi|hello|hey|namaste|namaskar|suno|hello ji|hii+|yo)\b/.test(l) || /kaise ho|kya haal/.test(l)) {
    return reply(`Namaste ${state.settings.userName}! Main ${agent.name} hoon. Bolo kya karna hai? (Demo mode chal raha hai — Settings mein free Gemini/Groq key daalo to main poori tarah smart ho jaunga.)`);
  }
  if (/\b(time|samay|baje|date|tarikh|aaj kya din|din hai)\b/.test(l)) { const r = await use('datetime', {}); return reply('Abhi hai: ' + r); }

  // Memory
  let m = t.match(/(?:yaad rakh(?:o|na|lo)|remember(?: that)?|note kar(?:o|lo)|save kar(?:o|lo))\s*(?:ki|that|:)?\s*(.+)/i);
  if (m) { const r = await use('remember', { text: m[1] }); return reply(r); }
  if (/kya yaad hai|what do you remember|meri memory|memory dikhao|yaad hai\?/.test(l)) { const r = await use('recall', { query: t }); return reply('Mujhe ye yaad hai:\n' + r); }

  // Notes / reminders
  m = t.match(/(?:note|todo)\s*(?:banao|likho|add|karo)?\s*[:\-]?\s*(.+)/i);
  if (m && /^(note|todo)/i.test(l)) { const r = await use('add_note', { text: m[1] }); return reply(r); }
  if (/notes? dikhao|list notes|mere notes/.test(l)) { const r = await use('list_notes', {}); return reply(r); }
  m = t.match(/(\d+)\s*(?:min|minute|minat)/i);
  if (/remind|yaad dila|reminder|alarm/.test(l) && m) { const what = t.replace(/.*?(?:ki|that|to)\s+/i, '').replace(/\d+\s*(?:min|minute|minat).*/i, '').trim() || t; const r = await use('set_reminder', { text: what, minutes: Number(m[1]) }); return reply(r); }

  // Agents / tasks
  if (/agents? (?:dikhao|list|kaun|batao)|list agents|kitne agent/.test(l)) { const r = await use('list_agents', {}); return reply('Ye agents hain:\n' + r); }
  m = t.match(/(?:naya|new)?\s*agent\s*(?:banao|create|bana do)\s*(?:jo|for|named|naam)?\s*(.+)/i);
  if (m) { const desc = m[1]; const name = desc.split(/\s+/).slice(0, 2).map(w => w[0].toUpperCase() + w.slice(1)).join(' ') + ' Agent'; const r = await use('create_agent', { name, emoji: '🛠️', description: desc, systemPrompt: `Tum ${name} ho. Tumhara kaam: ${desc}. Tools use karke kaam poora karo aur clear result do.` }); return reply(r); }
  if (/task status|tasks? dikhao|kaam ka status|kya chal raha/.test(l)) { const r = await use('task_status', {}); return reply(r); }
  m = t.match(/(.+?)\s*(?:agent|ko)\s*(?:ko\s*)?(?:task|kaam)\s*(?:do|de do|assign)\s*[:\-]?\s*(.+)/i);
  if (m) { const r = await use('delegate_task', { agent: m[1].trim(), task: m[2].trim() }); return reply(r); }

  // Phone actions
  m = t.match(/(?:call|phone)\s*(?:karo|lagao|kar)?\s*(\+?[\d\s-]{7,})/i) || t.match(/(\+?[\d\s-]{7,})\s*(?:pe|par|ko)\s*(?:call|phone)/i);
  if (m) return reply(await use('make_call', { number: m[1] }));
  m = t.match(/whatsapp\s*(?:pe|par)?\s*(\+?[\d\s-]{7,})\s*(?:ko|pe|par)?\s*(?:message|msg|bhejo|likho)?\s*[:\-]?\s*(.*)/i);
  if (m) return reply(await use('whatsapp_message', { number: m[1], message: m[2] || '' }));
  if (/meri location|where am i|main kahan hoon|location batao/.test(l)) return reply(await use('get_location', {}));
  m = t.match(/(youtube|whatsapp|maps?|gmail|instagram|facebook|spotify|chrome|playstore|play store|camera|settings?|calendar|contacts?|paytm|phonepe|gpay|amazon|flipkart|zomato|swiggy|uber|ola)\s*(?:pe|par|mein|me)?\s*(.*?)\s*(?:kholo|open|chalao|dikhao|search|lagao)/i);
  if (m) return reply(await use('open_app', { app: m[1].replace(/\s/g, '').replace(/^maps?$/, 'maps').replace(/^settings?$/, 'settings').replace(/^contacts?$/, 'contacts'), query: m[2] }));
  // Open apps
  if (/youtube (?:pe|par|kholo|open)|youtube kholo/.test(l)) { const q = t.replace(/.*youtube (?:pe|par|kholo|open)/i, '').replace(/(search|kholo|karo|dikhao|chalao)/gi, '').trim(); const r = await use('open_url', { url: q ? 'https://www.youtube.com/results?search_query=' + encodeURIComponent(q) : 'https://youtube.com' }); return reply(r); }
  if (/whatsapp kholo|open whatsapp/.test(l)) { return reply(await use('open_url', { url: 'https://wa.me/' })); }
  if (/maps? (?:kholo|open|pe|par)/.test(l)) { const q = t.replace(/.*maps? (?:kholo|open|pe|par)/i, '').trim(); return reply(await use('open_url', { url: 'https://www.google.com/maps/search/' + encodeURIComponent(q || '') })); }
  const anyUrl = t.match(/https?:\/\/\S+/);
  if (anyUrl && /kholo|open/.test(l)) return reply(await use('open_url', { url: anyUrl[0] }));
  if (anyUrl && /padho|read|summar|kya hai/.test(l)) { const r = await use('fetch_url', { url: anyUrl[0] }); return reply('Page ka content:\n' + r.slice(0, 1200) + (r.length > 1200 ? '…' : '')); }

  // Calculator
  if (/^[\d\s+\-*/().%^×÷]+$/.test(t) || /calculate|kitna hota hai|kitne hote|\bplus\b|\bminus\b|\binto\b|\bdivide|\bguna\b|\bjod\b/.test(l)) {
    let expr = t.replace(/calculate|kitna hota hai|kitne hote hain|hai|hota|kya/gi, '').replace(/plus|jod/gi, '+').replace(/minus|ghata/gi, '-').replace(/into|guna|times|x/gi, '*').replace(/divide(?:d)? by|bhaag/gi, '/').replace(/(\d+)\s*(?:%|percent|pratishat) of (\d+)/i, '($2*$1/100)').trim();
    if (/[\d]/.test(expr)) { const r = await use('calculator', { expression: expr }); if (!r.startsWith('Tool error')) return reply(r); }
  }

  // Code
  m = t.match(/(?:run|chalao|execute)\s*(?:this|ye|yeh)?\s*(?:js|javascript)\s*[:\-]?\s*([\s\S]+)/i);
  if (m) return reply('Output:\n' + await use('run_js', { code: m[1] }));
  m = t.match(/(?:run|chalao|execute)\s*(?:this|ye|yeh)?\s*(?:python|py)\s*[:\-]?\s*([\s\S]+)/i);
  if (m) return reply('Output:\n' + await use('run_python', { code: m[1] }));

  // Knowledge
  const ks = state.knowledge.length ? state.knowledge.filter(k => l.includes(k.title.toLowerCase().split('/').pop())) : [];
  if (ks.length) { const r = await use('knowledge_search', { query: t }); return reply(r.slice(0, 1500)); }

  // Default: web search for questions
  if (t.length > 3) {
    const q = t.replace(/\b(search|dhoondo|dhundo|google|karo|batao|kya hai|kaun hai|about|ke baare mein|please|plz)\b/gi, ' ').replace(/\s+/g, ' ').trim() || t;
    const r = await use('web_search', { query: q });
    if (!r.startsWith('Koi result') && !r.startsWith('Tool error')) {
      const first = r.split('\n').filter(x => x.trim() && !x.trim().startsWith('http')).slice(0, 4).join('\n');
      return reply(`Maine "${q}" search kiya. Ye mila:\n${first}\n\n(Demo mode: poora jawab samajh kar dene ke liye Settings mein API key daalo — Gemini/Groq free hain.)`);
    }
  }
  return reply('Demo mode mein main ye samajh nahi paya. Settings mein free Gemini ya Groq key daalo, phir main sab kuch samjhunga aur karunga. 🙂');
}
