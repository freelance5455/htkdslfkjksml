// Agent registry + background task runner (sub-agents)
import { state, save, emit, uid } from './store.js';
import { runAgentTurn } from './brain.js';

export const BUILTIN_AGENTS = [
  {
    id: 'suno', name: 'SUNO', emoji: '🎙️', builtin: true, source: 'builtin',
    description: 'Main voice assistant — sab kuch sunta hai, karta hai, aur doosre agents ko manage karta hai.',
    systemPrompt: `Tum SUNO ho — user ka personal AI voice agent aur orchestrator. Tum user ki har baat maante ho aur kaam karke dikhate ho. Tumhare paas tools hain, sub-agents hain, memory hai, aur tum GitHub repos se naye skills/agents seekh sakte ho. Confident, helpful, thoda friendly. Kaam pehle, baatein baad mein. Agar kaam multi-step ya lamba hai to relevant agent ko delegate karo aur user ko bata do.`,
    tools: []
  },
  {
    id: 'researcher', name: 'Researcher', emoji: '🔎', builtin: true, source: 'builtin',
    description: 'Internet research, comparison, fact-check, summaries.',
    systemPrompt: `Tum Researcher agent ho. Kisi bhi topic par web_search aur fetch_url se deep research karo, multiple sources check karo, aur ek clear structured summary do with key points aur sources. Guess mat karo — verify karo.`,
    tools: ['web_search', 'fetch_url', 'knowledge_search', 'remember', 'recall', 'calculator', 'datetime']
  },
  {
    id: 'coder', name: 'Coder', emoji: '💻', builtin: true, source: 'builtin',
    description: 'Code likhna, run karna, debug karna, GitHub repos samajhna.',
    systemPrompt: `Tum Coder agent ho — expert software engineer. Code likho, run_js/run_python se test karo, bugs fix karo, aur repos explain karo. Code hamesha code block mein do. Output verify karke hi final jawab do.`,
    tools: ['run_js', 'run_python', 'learn_github_repo', 'knowledge_search', 'fetch_url', 'web_search', 'calculator']
  },
  {
    id: 'planner', name: 'Planner', emoji: '🗓️', builtin: true, source: 'builtin',
    description: 'Plans, todo lists, reminders, schedules, step-by-step breakdown.',
    systemPrompt: `Tum Planner agent ho. Bade goals ko chhote actionable steps mein todo, notes/reminders set karo, aur realistic plan banao. Concise aur practical raho.`,
    tools: ['add_note', 'list_notes', 'set_reminder', 'datetime', 'remember', 'recall', 'web_search', 'delegate_task', 'list_agents']
  }
];

export function ensureBuiltinAgents() {
  for (const b of BUILTIN_AGENTS) {
    if (!state.agents.find(a => a.id === b.id)) state.agents.push({ ...b, createdAt: Date.now() });
  }
  if (!state.agents.find(a => a.id === state.activeAgentId)) state.activeAgentId = 'suno';
  save();
}

export function getAgent(idOrName) {
  if (!idOrName) return null;
  const q = String(idOrName).toLowerCase().trim();
  return state.agents.find(a => a.id === q) || state.agents.find(a => a.name.toLowerCase() === q) || state.agents.find(a => a.name.toLowerCase().includes(q) || q.includes(a.name.toLowerCase())) || null;
}
export function activeAgent() { return state.agents.find(a => a.id === state.activeAgentId) || state.agents[0]; }
export function setActiveAgent(id) { state.activeAgentId = id; save(); emit('agents'); }

export function createAgent({ name, emoji = '🤖', description = '', systemPrompt = '', tools = [], knowledgeIds = [], source = 'user', repoUrl = null }) {
  const id = (name || 'agent').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24) + '-' + uid().slice(0, 4);
  const agent = { id, name: name || 'Agent', emoji, description, systemPrompt: systemPrompt || `Tum ${name} ho. ${description}`, tools, knowledgeIds, source, repoUrl, createdAt: Date.now() };
  state.agents.push(agent); save(); emit('agents'); emit('toast', `${emoji} ${name} agent ban gaya`);
  return agent;
}
export function updateAgent(id, patch) { const a = state.agents.find(x => x.id === id); if (a) { Object.assign(a, patch); save(); emit('agents'); } return a; }
export function deleteAgent(id) {
  const a = state.agents.find(x => x.id === id);
  if (!a || a.builtin) return false;
  state.agents = state.agents.filter(x => x.id !== id);
  delete state.chats[id];
  if (state.activeAgentId === id) state.activeAgentId = 'suno';
  save(); emit('agents'); return true;
}

// ---------------- Background tasks ----------------
const running = new Set();

export function delegateTask(agentRef, task) {
  const agent = getAgent(agentRef) || getAgent('suno');
  const t = { id: uid(), title: task.slice(0, 80), task, agentId: agent.id, agentName: agent.name, agentEmoji: agent.emoji, status: 'queued', steps: [], result: '', createdAt: Date.now(), finishedAt: null };
  state.tasks.unshift(t); save(); emit('tasks');
  setTimeout(() => runTask(t.id), 50);
  return t;
}

export async function runTask(taskId) {
  const t = state.tasks.find(x => x.id === taskId);
  if (!t || running.has(taskId)) return;
  const agent = state.agents.find(a => a.id === t.agentId) || activeAgent();
  running.add(taskId);
  t.status = 'running'; t.steps.push({ ts: Date.now(), text: `${agent.emoji} ${agent.name} ne kaam shuru kiya` }); save(); emit('tasks');
  try {
    const history = [{ role: 'user', content: `[BACKGROUND TASK] Ye kaam poora karo aur end mein ek clear final report do:\n\n${t.task}` }];
    const res = await runAgentTurn(agent, history, (step) => {
      if (step.type === 'tool') t.steps.push({ ts: Date.now(), text: `🔧 ${step.name}(${JSON.stringify(step.args).slice(0, 120)})` });
      if (step.type === 'result') t.steps.push({ ts: Date.now(), text: `↩︎ ${String(step.result).slice(0, 200)}` });
      save(); emit('tasks');
    });
    t.result = res.text; t.status = 'done';
  } catch (e) {
    t.result = 'Error: ' + e.message; t.status = 'failed';
  }
  t.finishedAt = Date.now(); running.delete(taskId); save(); emit('tasks');
  emit('taskDone', t);
}

export function retryTask(id) { const t = state.tasks.find(x => x.id === id); if (t) { t.status = 'queued'; t.steps = []; t.result = ''; save(); runTask(id); } }
export function deleteTask(id) { state.tasks = state.tasks.filter(x => x.id !== id); save(); emit('tasks'); }
