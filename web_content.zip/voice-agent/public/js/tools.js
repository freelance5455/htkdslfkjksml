// Tools the agents can call. Each tool: {name, description, args, run(args, ctx)}
import { state, save, emit, uid, addMemory, searchMemory, searchKnowledge } from './store.js';

async function api(path, body) {
  const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const d = await r.json();
  if (!r.ok || d.error) throw new Error(d.error || 'API error');
  return d;
}

// ---- sandboxed JS runner (Web Worker) ----
function runJS(code, timeoutMs = 5000) {
  return new Promise((resolve) => {
    const src = `
      const logs=[]; const console={log:(...a)=>logs.push(a.map(x=>typeof x==='object'?JSON.stringify(x):String(x)).join(' ')),error:(...a)=>logs.push('ERR: '+a.join(' '))};
      self.onmessage=async(e)=>{ let result; try{ result = await (new Function('console', 'return (async()=>{'+e.data+'\\n})()'))(console); }catch(err){ logs.push('Error: '+err.message); }
        self.postMessage({logs, result: result===undefined?undefined:(typeof result==='object'?JSON.stringify(result):String(result))}); };`;
    const blob = new Blob([src], { type: 'application/javascript' });
    const w = new Worker(URL.createObjectURL(blob));
    const t = setTimeout(() => { w.terminate(); resolve({ logs: ['Timeout: code took too long'], result: undefined }); }, timeoutMs);
    w.onmessage = (e) => { clearTimeout(t); w.terminate(); resolve(e.data); };
    w.onerror = (e) => { clearTimeout(t); w.terminate(); resolve({ logs: ['Error: ' + e.message], result: undefined }); };
    w.postMessage(code);
  });
}

// ---- Python via Pyodide (lazy, CDN) ----
let pyodideP = null;
async function runPython(code) {
  if (!pyodideP) {
    emit('toast', 'Python engine load ho raha hai (pehli baar ~10MB)...');
    pyodideP = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js';
      s.onload = () => window.loadPyodide().then(resolve, reject);
      s.onerror = () => reject(new Error('Pyodide load failed (internet chahiye)'));
      document.head.appendChild(s);
    });
  }
  const py = await pyodideP;
  let out = '';
  py.setStdout({ batched: (s) => { out += s + '\n'; } });
  py.setStderr({ batched: (s) => { out += 'ERR: ' + s + '\n'; } });
  try {
    const result = await py.runPythonAsync(code);
    return { logs: out.trim().split('\n').filter(Boolean), result: result === undefined ? undefined : String(result) };
  } catch (e) { return { logs: [out, 'Error: ' + e.message].filter(Boolean), result: undefined }; }
}

// ---- Safe calculator ----
function calc(expr) {
  const clean = String(expr).replace(/\^/g, '**').replace(/×/g, '*').replace(/÷/g, '/').replace(/[^0-9+\-*/().%\s,a-zA-Z]/g, '');
  const allowed = { sqrt: Math.sqrt, pow: Math.pow, abs: Math.abs, round: Math.round, floor: Math.floor, ceil: Math.ceil, sin: Math.sin, cos: Math.cos, tan: Math.tan, log: Math.log, log10: Math.log10, pi: Math.PI, e: Math.E, min: Math.min, max: Math.max };
  const body = clean.replace(/[a-zA-Z_]+/g, (w) => { if (!(w in allowed)) throw new Error('Unknown symbol: ' + w); return 'm.' + w; });
  // eslint-disable-next-line no-new-func
  const v = new Function('m', 'return (' + body + ')')(allowed);
  if (typeof v !== 'number' || !isFinite(v)) throw new Error('Invalid expression');
  return Math.round(v * 1e10) / 1e10;
}

export const TOOLS = {
  web_search: {
    description: 'Internet par search karo. Latest news, facts, prices, kuch bhi.',
    args: { query: 'search query' },
    async run({ query }) {
      const { results } = await api('/api/search', { query, limit: 6 });
      if (!results.length) return 'Koi result nahi mila.';
      return results.map((r, i) => `${i + 1}. ${r.title}\n   ${r.snippet}\n   ${r.url}`).join('\n');
    }
  },
  fetch_url: {
    description: 'Kisi webpage ka text content padho (URL do).',
    args: { url: 'https://...' },
    async run({ url }) { const { text } = await api('/api/fetch', { url, maxChars: 6000 }); return text || '(empty page)'; }
  },
  learn_github_repo: {
    description: 'GitHub repo analyze karo. Agar agent project hai to naya agent banao, warna knowledge/skill ke roop mein seekho.',
    args: { url: 'https://github.com/owner/repo' },
    async run({ url }, ctx) { const { learnRepo } = await import('./github.js'); const r = await learnRepo(url, ctx); return r.summaryForModel; }
  },
  calculator: {
    description: 'Math calculation karo (expression do). e.g. 15% of 2400 => 2400*0.15',
    args: { expression: '2+2*10' },
    async run({ expression }) { return `${expression} = ${calc(expression)}`; }
  },
  datetime: {
    description: 'Abhi ka date/time (India) batao.',
    args: {},
    async run() { return new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'full', timeStyle: 'short' }); }
  },
  remember: {
    description: 'User ki koi baat long-term memory mein save karo (preference, fact, naam, etc.).',
    args: { text: 'fact to remember' },
    async run({ text }) { addMemory(text, ['user']); return 'Yaad rakh liya: ' + text; }
  },
  recall: {
    description: 'Memory mein se related baatein dhoondo.',
    args: { query: 'kya dhoondna hai' },
    async run({ query }) { const m = searchMemory(query, 8); return m.length ? m.map(x => `- ${x.text} (${new Date(x.ts).toLocaleDateString('en-IN')})`).join('\n') : 'Memory mein kuch nahi mila.'; }
  },
  knowledge_search: {
    description: 'Seekhe hue GitHub repos / documents (knowledge base) mein dhoondo aur unka content padho.',
    args: { query: 'topic ya repo naam' },
    async run({ query }) {
      const ks = searchKnowledge(query, 2);
      if (!ks.length) return 'Knowledge base mein kuch relevant nahi.';
      return ks.map(k => `## ${k.title} (${k.source})\n${k.summary}\n\n${(k.content || '').slice(0, 5000)}`).join('\n\n---\n\n');
    }
  },
  run_js: {
    description: 'JavaScript code run karo (sandbox). console.log ya return se output do. Calculations, data processing, logic ke liye.',
    args: { code: 'return 1+1' },
    async run({ code }) { const r = await runJS(code); return [...(r.logs || []), r.result !== undefined ? 'Result: ' + r.result : ''].filter(Boolean).join('\n') || '(no output)'; }
  },
  run_python: {
    description: 'Python code run karo (browser mein Pyodide). print() se output do.',
    args: { code: 'print(2**10)' },
    async run({ code }) { const r = await runPython(code); return [...(r.logs || []), r.result !== undefined ? 'Result: ' + r.result : ''].filter(Boolean).join('\n') || '(no output)'; }
  },
  create_agent: {
    description: 'Naya specialised sub-agent banao jo specific kaam kare.',
    args: { name: 'Agent naam', emoji: '🤖', description: 'ek line mein kaam', systemPrompt: 'detailed instructions/persona' },
    async run(a) { const { createAgent } = await import('./agents.js'); const ag = createAgent({ ...a, source: 'created-by-ai' }); return `Agent "${ag.name}" ban gaya (id: ${ag.id}). Ab delegate_task se kaam de sakte ho.`; }
  },
  list_agents: {
    description: 'Saare available agents ki list.',
    args: {},
    async run() { return state.agents.map(a => `- ${a.emoji} ${a.name} (id: ${a.id}): ${a.description}`).join('\n'); }
  },
  delegate_task: {
    description: 'Kisi agent ko background task do. Wo khud kaam karke result Tasks tab mein dega. Bade/multi-step kaam ke liye use karo.',
    args: { agent: 'agent id ya naam', task: 'kaam ka pura detail' },
    async run({ agent, task }) { const { delegateTask } = await import('./agents.js'); const t = delegateTask(agent, task); return `Task "${t.title}" agent ${t.agentName} ko de diya (task id: ${t.id}). Background mein chal raha hai; result Tasks tab mein aayega.`; }
  },
  task_status: {
    description: 'Background tasks ka status aur results dekho.',
    args: {},
    async run() { return state.tasks.slice(0, 10).map(t => `- [${t.status}] ${t.title} (${t.agentName})${t.result ? ': ' + t.result.slice(0, 300) : ''}`).join('\n') || 'Koi task nahi.'; }
  },
  add_note: {
    description: 'Note / todo save karo.',
    args: { text: 'note text' },
    async run({ text }) { state.notes.unshift({ id: uid(), text, ts: Date.now() }); save(); emit('notes'); return 'Note saved.'; }
  },
  list_notes: {
    description: 'Saare notes/todos dikhao.',
    args: {},
    async run() { return state.notes.map((n, i) => `${i + 1}. ${n.text}`).join('\n') || 'Koi note nahi.'; }
  },
  set_reminder: {
    description: 'Reminder set karo (minutes baad). App khuli honi chahiye.',
    args: { text: 'kya yaad dilana hai', minutes: 10 },
    async run({ text, minutes }) {
      const at = Date.now() + Number(minutes) * 60000;
      state.reminders.push({ id: uid(), text, at, done: false }); save(); emit('reminders');
      if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
      return `Reminder set: "${text}" — ${new Date(at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })} par.`;
    }
  },
  open_url: {
    description: 'User ke phone par koi link/app kholo (YouTube, Maps, WhatsApp, website).',
    args: { url: 'https://...' },
    async run({ url }) { window.open(url, '_blank'); return 'Khol diya: ' + url; }
  },
  open_app: {
    description: 'Phone ki app kholo: youtube, whatsapp, maps, gmail, instagram, facebook, spotify, chrome, playstore, camera, settings, calendar, phone, contacts, paytm, phonepe, gpay, amazon, flipkart, zomato, swiggy, uber, ola. Optional query (jaise youtube pe kya search karna hai).',
    args: { app: 'youtube', query: 'optional search/text' },
    async run({ app, query = '' }) {
      const q = encodeURIComponent(query);
      const A = {
        youtube: q ? `https://www.youtube.com/results?search_query=${q}` : 'https://youtube.com', whatsapp: q ? `https://wa.me/?text=${q}` : 'https://wa.me/',
        maps: `https://www.google.com/maps/search/${q}`, gmail: 'https://mail.google.com', instagram: 'https://instagram.com', facebook: 'https://facebook.com',
        spotify: q ? `https://open.spotify.com/search/${q}` : 'https://open.spotify.com', chrome: q ? `https://www.google.com/search?q=${q}` : 'https://google.com',
        playstore: q ? `https://play.google.com/store/search?q=${q}` : 'https://play.google.com', amazon: `https://www.amazon.in/s?k=${q}`, flipkart: `https://www.flipkart.com/search?q=${q}`,
        zomato: 'https://www.zomato.com', swiggy: 'https://www.swiggy.com', uber: 'https://m.uber.com', ola: 'https://book.olacabs.com',
        paytm: 'https://paytm.com', phonepe: 'https://www.phonepe.com', gpay: 'https://pay.google.com', calendar: 'https://calendar.google.com',
        camera: 'intent://#Intent;action=android.media.action.IMAGE_CAPTURE;end', settings: 'intent://#Intent;action=android.settings.SETTINGS;end',
        phone: 'tel:', contacts: 'content://contacts/people/', translate: `https://translate.google.com/?text=${q}`
      };
      const key = String(app).toLowerCase().replace(/\s+/g, '');
      const url = A[key]; if (!url) return `App "${app}" ki mapping nahi hai. open_url se direct link try karo.`;
      if (/^(intent|tel|content):/.test(url)) window.location.href = url; else window.open(url, '_blank');
      return `${app} khol raha hoon${query ? ' — ' + query : ''}.`;
    }
  },
  make_call: {
    description: 'Phone call lagao (dialer kholta hai number ke saath).',
    args: { number: '+919999999999' },
    async run({ number }) { window.location.href = 'tel:' + String(number).replace(/[^\d+]/g, ''); return `Call laga raha hoon: ${number}`; }
  },
  send_sms: {
    description: 'SMS app kholo number aur message ke saath.',
    args: { number: '+919999999999', message: 'text' },
    async run({ number, message = '' }) { window.location.href = `sms:${String(number).replace(/[^\d+]/g, '')}?body=${encodeURIComponent(message)}`; return `SMS ready: ${number} → "${message}"`; }
  },
  whatsapp_message: {
    description: 'WhatsApp par kisi number ko message bhejo (WhatsApp khulta hai message type hua).',
    args: { number: '919999999999 (country code ke saath, + nahi)', message: 'text' },
    async run({ number, message = '' }) { const n = String(number).replace(/\D/g, ''); window.open(`https://wa.me/${n}?text=${encodeURIComponent(message)}`, '_blank'); return `WhatsApp khol diya: ${n} → "${message}"`; }
  },
  get_location: {
    description: 'User ki current GPS location (lat, lng) lo.',
    args: {},
    async run() {
      return new Promise((resolve) => {
        if (!navigator.geolocation) return resolve('Location supported nahi.');
        navigator.geolocation.getCurrentPosition(
          (p) => resolve(`Lat ${p.coords.latitude.toFixed(5)}, Lng ${p.coords.longitude.toFixed(5)} (±${Math.round(p.coords.accuracy)}m). Maps: https://www.google.com/maps?q=${p.coords.latitude},${p.coords.longitude}`),
          (e) => resolve('Location error: ' + e.message + ' (permission do)'), { enableHighAccuracy: true, timeout: 10000 });
      });
    }
  },
  share_text: {
    description: 'Phone ka share sheet kholo — text/link kisi bhi app mein bhejo.',
    args: { text: 'share karne wala text', title: 'optional' },
    async run({ text, title = 'SUNO' }) { if (navigator.share) { try { await navigator.share({ title, text }); return 'Share sheet khola.'; } catch { return 'Share cancel hua.'; } } await navigator.clipboard?.writeText(text); return 'Share supported nahi — clipboard mein copy kar diya.'; }
  },
  copy_to_clipboard: {
    description: 'Text clipboard mein copy karo.',
    args: { text: '...' },
    async run({ text }) { await navigator.clipboard?.writeText(text); return 'Copy ho gaya.'; }
  },
  phone: {
    description: `POORA PHONE CONTROL (SUNO Android companion app ke through). action + args do. Actions:
 open_app{name} | current_app | read_screen (screen ka text + clickable items) | tap_text{text} | tap{x,y} | long_press{x,y} | type{text} (focused field mein) | clear_text | swipe{direction:up/down/left/right} | scroll{direction} | back | home | recents | notifications | quick_settings | lock | screenshot | wait{ms}
 call{number} (direct call) | end_call | sms{number,message} (direct send) | read_sms{limit} | read_notifications | contacts_search{name}
 volume{level:0-100,stream:music/ring/alarm} | mute | media{action:play/pause/next/previous} | flashlight{on:true/false} | brightness{level:0-100} | wifi_panel | bluetooth_panel | open_settings{page:wifi/bluetooth/display/sound/apps/location/battery/date} | battery | alarm{hour,minute,message} | timer{seconds,message} | open_url{url} | apps_list
Multi-step kaam: open_app → wait 1500 → read_screen → tap_text/type → read_screen (verify). Har step ke baad screen padh ke aage badho.`,
    args: { action: 'read_screen', args: {} },
    async run({ action, args = {}, ...rest }) {
      const a = { ...(typeof args === 'object' && args ? args : {}), ...rest };
      const r = await fetch('/api/device/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, args: a }) });
      const d = await r.json();
      if (!r.ok || d.error) throw new Error(d.error || 'bridge error');
      return (d.ok ? '✅ ' : '❌ ') + (d.result || action + ' done');
    }
  },
  vibrate: {
    description: 'Phone vibrate karo (ms).',
    args: { ms: 300 },
    async run({ ms = 300 }) { navigator.vibrate?.(Number(ms)); return 'Vibrate kiya.'; }
  }
};

export function toolsDescription(names) {
  return names.filter(n => TOOLS[n]).map(n => `- ${n}(${JSON.stringify(TOOLS[n].args)}): ${TOOLS[n].description}`).join('\n');
}

export async function runTool(name, args = {}, ctx = {}) {
  const t = TOOLS[name];
  if (!t) return `Unknown tool: ${name}`;
  try { const out = await t.run(args || {}, ctx); return String(out).slice(0, 12000); }
  catch (e) { return `Tool error (${name}): ${e.message}`; }
}

export const ALL_TOOL_NAMES = Object.keys(TOOLS);
