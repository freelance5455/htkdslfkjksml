package com.suno.agent

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps a small buffer of recent notifications so SUNO can "read" them. */
class NotifListener : NotificationListenerService() {
    companion object {
        @Volatile private var instance: NotifListener? = null
        private val recent = ArrayDeque<String>()
        fun isRunning() = instance != null
        fun dump(): String {
            val live = try { instance?.activeNotifications?.mapNotNull { format(it) } } catch (e: Exception) { null }
            val lines = (live ?: emptyList()).takeLast(15).ifEmpty { recent.toList().takeLast(15) }
            return if (lines.isEmpty()) (if (instance == null) "Notification access ON nahi hai (SUNO Companion → button 2)" else "Koi notification nahi") else lines.joinToString("\n")
        }
        private fun format(sbn: StatusBarNotification): String? {
            val e = sbn.notification.extras
            val title = e.getCharSequence("android.title")?.toString().orEmpty()
            val text = (e.getCharSequence("android.bigText") ?: e.getCharSequence("android.text"))?.toString().orEmpty()
            if (title.isBlank() && text.isBlank()) return null
            val app = sbn.packageName.substringAfterLast('.')
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(sbn.postTime))
            return "- [$app $time] $title: ${text.take(160)}"
        }
    }
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        format(sbn)?.let { synchronized(recent) { recent.addLast(it); while (recent.size > 50) recent.removeFirst() } }
    }
}
