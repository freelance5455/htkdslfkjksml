package com.suno.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The "eyes and hands" of SUNO on the phone.
 * Reads the screen tree, finds elements by text, taps, types, swipes, performs global actions.
 */
class SunoAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: SunoAccessibilityService? = null
        private const val TAG = "SunoA11y"
        fun isRunning() = instance != null
    }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this; Log.i(TAG, "connected") }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* we pull state on demand */ }
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    // ---------- Screen reading ----------

    fun currentPackage(): String = rootInActiveWindow?.packageName?.toString() ?: "unknown"

    /** Human/LLM readable dump of what is on screen. */
    fun readScreen(maxItems: Int = 120): String {
        val root = rootInActiveWindow ?: return "Screen padh nahi paya (koi active window nahi / lock screen?)."
        val sb = StringBuilder()
        sb.append("App: ").append(root.packageName).append('\n')
        val items = ArrayList<String>()
        walk(root, 0) { node, depth ->
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val hint = if (android.os.Build.VERSION.SDK_INT >= 26) node.hintText?.toString()?.trim().orEmpty() else ""
            val label = when {
                text.isNotEmpty() -> text
                desc.isNotEmpty() -> desc
                hint.isNotEmpty() -> "[hint: $hint]"
                else -> ""
            }
            val cls = node.className?.toString()?.substringAfterLast('.') ?: ""
            val editable = node.isEditable || cls.contains("EditText")
            if (label.isNotEmpty() || node.isClickable || editable) {
                val r = Rect(); node.getBoundsInScreen(r)
                val flags = buildString {
                    if (node.isClickable) append(" clickable")
                    if (editable) append(" editable")
                    if (node.isChecked) append(" checked")
                    if (node.isFocused) append(" focused")
                    if (node.isScrollable) append(" scrollable")
                }
                if (label.isNotEmpty() || node.isClickable || editable) {
                    items.add("- \"${label.take(80)}\" ($cls$flags) @(${r.centerX()},${r.centerY()})")
                }
            }
            items.size < maxItems
        }
        sb.append(items.joinToString("\n"))
        if (items.size >= maxItems) sb.append("\n… (aur bhi items hain, scroll karo)")
        return sb.toString()
    }

    private fun walk(node: AccessibilityNodeInfo?, depth: Int, visit: (AccessibilityNodeInfo, Int) -> Boolean): Boolean {
        if (node == null || depth > 40) return true
        if (!visit(node, depth)) return false
        for (i in 0 until node.childCount) {
            if (!walk(node.getChild(i), depth + 1, visit)) return false
        }
        return true
    }

    // ---------- Finding ----------

    fun findByText(query: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val q = query.trim().lowercase()
        // 1) exact API search
        root.findAccessibilityNodeInfosByText(query)?.firstOrNull { it != null }?.let { return it }
        // 2) fuzzy: text / contentDescription / hint contains
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        walk(root, 0) { n, _ ->
            val cands = listOfNotNull(n.text?.toString(), n.contentDescription?.toString(),
                if (android.os.Build.VERSION.SDK_INT >= 26) n.hintText?.toString() else null)
            for (c in cands) {
                val cl = c.trim().lowercase()
                val score = when {
                    cl == q -> 100
                    cl.startsWith(q) -> 80
                    cl.contains(q) -> 60
                    q.split(" ").all { cl.contains(it) } -> 40
                    else -> 0
                }
                if (score > bestScore) { bestScore = score; best = n }
            }
            true
        }
        return best
    }

    private fun clickableAncestor(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var n = node; var hops = 0
        while (n != null && hops < 6) { if (n.isClickable) return n; n = n.parent; hops++ }
        return null
    }

    // ---------- Actions ----------

    fun clickText(text: String): String {
        val node = findByText(text) ?: return "\"$text\" screen par nahi mila. read_screen karke sahi text lo."
        val target = clickableAncestor(node)
        if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Tapped: \"$text\""
        val r = Rect(); node.getBoundsInScreen(r)
        return if (tap(r.centerX().toFloat(), r.centerY().toFloat())) "Tapped (gesture): \"$text\" @(${r.centerX()},${r.centerY()})" else "Tap fail: \"$text\""
    }

    fun tap(x: Float, y: Float, durationMs: Long = 60): Boolean = gesture(Path().apply { moveTo(x, y) }, durationMs)

    fun longPress(x: Float, y: Float): Boolean = gesture(Path().apply { moveTo(x, y) }, 700)

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300): Boolean =
        gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, durationMs)

    fun swipeDirection(direction: String): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        val ok = when (direction.lowercase()) {
            "up" -> swipe(w / 2, h * 0.75f, w / 2, h * 0.25f)
            "down" -> swipe(w / 2, h * 0.25f, w / 2, h * 0.75f)
            "left" -> swipe(w * 0.85f, h / 2, w * 0.15f, h / 2)
            "right" -> swipe(w * 0.15f, h / 2, w * 0.85f, h / 2)
            else -> false
        }
        return if (ok) "Swiped $direction" else "Swipe fail"
    }

    fun scroll(direction: String): String {
        val root = rootInActiveWindow ?: return "No window"
        var scrollable: AccessibilityNodeInfo? = null
        walk(root, 0) { n, _ -> if (n.isScrollable) { scrollable = n; false } else true }
        val action = if (direction.lowercase() in listOf("down", "forward", "next")) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (scrollable?.performAction(action) == true) return "Scrolled $direction"
        return swipeDirection(if (action == AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) "up" else "down")
    }

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val g = GestureDescription.Builder().addStroke(stroke).build()
        val latch = CountDownLatch(1); var ok = false
        val dispatched = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gd: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(gd: GestureDescription?) { ok = false; latch.countDown() }
        }, null)
        if (!dispatched) return false
        latch.await(2, TimeUnit.SECONDS)
        return ok
    }

    /** Type into focused field, or into a field matching [fieldHint]. */
    fun typeText(text: String, fieldHint: String? = null, append: Boolean = false): String {
        val root = rootInActiveWindow ?: return "No window"
        var field: AccessibilityNodeInfo? = null
        if (!fieldHint.isNullOrBlank()) field = findByText(fieldHint)
        if (field == null) field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (field == null) walk(root, 0) { n, _ -> if (n.isEditable) { field = n; false } else true }
        val f = field ?: return "Koi text field nahi mila. Pehle field par tap karo."
        if (!f.isFocused) f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val existing = if (append) f.text?.toString().orEmpty() else ""
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, existing + text) }
        if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return "Typed: \"$text\""
        // fallback: clipboard paste
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("suno", text))
        return if (f.performAction(AccessibilityNodeInfo.ACTION_PASTE)) "Pasted: \"$text\"" else "Type fail"
    }

    fun clearText(): String {
        val root = rootInActiveWindow ?: return "No window"
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "Koi focused field nahi"
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "") }
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Cleared" else "Clear fail"
    }

    fun global(name: String): String {
        val id = when (name.lowercase()) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "power" -> GLOBAL_ACTION_POWER_DIALOG
            "lock" -> if (android.os.Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return "Lock needs Android 9+"
            "screenshot" -> if (android.os.Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return "Screenshot needs Android 9+"
            else -> return "Unknown global action: $name"
        }
        return if (performGlobalAction(id)) "Done: $name" else "Fail: $name"
    }
}
