package com.suno.agent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Foreground service: long-polls the SUNO server for commands, executes them, posts results.
 * Zero websockets needed -> works behind any HTTPS host (Render/Railway/etc.).
 */
class BridgeService : Service() {

    companion object {
        const val CHANNEL = "suno_bridge"
        @Volatile var running = false
        @Volatile var lastStatus = "idle"
        @Volatile var lastLog = ""
        private const val TAG = "SunoBridge"

        fun start(ctx: Context) {
            val i = Intent(ctx, BridgeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, BridgeService::class.java)) }
        fun log(s: String) { Log.i(TAG, s); lastLog = (s + "\n" + lastLog).take(3000) }
    }

    private var worker: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(40, TimeUnit.SECONDS).writeTimeout(15, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
    private val json = "application/json; charset=utf-8".toMediaType()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1, buildNotification("Connecting…"))
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "suno:bridge").apply { acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (worker?.isAlive != true) {
            running = true
            worker = Thread { loop() }.apply { isDaemon = true; start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        try { wakeLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun loop() {
        val executor = ActionExecutor(this)
        var backoff = 2000L
        while (running) {
            val base = Prefs.serverUrl(this); val token = Prefs.token(this)
            if (base.isBlank() || token.isBlank()) { setStatus("Server URL / token set karo"); Thread.sleep(3000); continue }
            try {
                val url = "$base/api/device/poll?token=$token&timeout=25000&model=${java.net.URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")}&sdk=${Build.VERSION.SDK_INT}"
                val resp = client.newCall(Request.Builder().url(url).get().build()).execute()
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) { setStatus("Server error ${resp.code}: ${body.take(80)}"); Thread.sleep(backoff); backoff = (backoff * 2).coerceAtMost(30000); continue }
                backoff = 2000
                setStatus("Connected ✓ (waiting for commands)")
                val cmds = JSONObject(body).optJSONArray("commands") ?: continue
                for (i in 0 until cmds.length()) {
                    val c = cmds.getJSONObject(i)
                    val action = c.optString("action"); val args = c.optJSONObject("args") ?: JSONObject()
                    log("▶ $action ${args.toString().take(100)}")
                    val r = executor.execute(action, args)
                    log("${if (r.ok) "✓" else "✗"} ${r.text.take(140)}")
                    val payload = JSONObject().put("token", token).put("id", c.optString("id")).put("ok", r.ok).put("result", r.text).toString()
                    try { client.newCall(Request.Builder().url("$base/api/device/result").post(payload.toRequestBody(json)).build()).execute().close() } catch (e: Exception) { log("result post fail: ${e.message}") }
                }
            } catch (e: InterruptedException) { return }
            catch (e: Exception) {
                setStatus("Offline: ${e.javaClass.simpleName} ${e.message?.take(60)}")
                try { Thread.sleep(backoff) } catch (_: InterruptedException) { return }
                backoff = (backoff * 2).coerceAtMost(30000)
            }
        }
    }

    private fun setStatus(s: String) {
        if (s != lastStatus) { lastStatus = s; log(s) }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification(s))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "SUNO Bridge", NotificationManager.IMPORTANCE_LOW).apply { description = "SUNO phone control connection" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle("SUNO Companion").setContentText(text)
            .setOngoing(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_LOW).build()
    }
}
