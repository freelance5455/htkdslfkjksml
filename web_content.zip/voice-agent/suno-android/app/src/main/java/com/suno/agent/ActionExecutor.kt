package com.suno.agent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Executes one command from the SUNO brain and returns a text result. */
class ActionExecutor(private val ctx: Context) {

    data class Result(val ok: Boolean, val text: String)

    private val a11y get() = SunoAccessibilityService.instance

    fun execute(action: String, args: JSONObject): Result = try {
        val out = when (action.lowercase().replace('-', '_')) {
            // ---- screen / accessibility ----
            "read_screen", "screen" -> needA11y { it.readScreen(args.optInt("max", 120)) }
            "current_app" -> needA11y { "Current app: " + it.currentPackage() }
            "tap_text", "click", "click_text" -> needA11y { it.clickText(args.optString("text")) }
            "tap" -> needA11y { if (it.tap(args.optDouble("x").toFloat(), args.optDouble("y").toFloat())) "Tapped (${args.optInt("x")},${args.optInt("y")})" else "Tap fail" }
            "long_press" -> needA11y { if (it.longPress(args.optDouble("x").toFloat(), args.optDouble("y").toFloat())) "Long pressed" else "Fail" }
            "type", "type_text", "input" -> needA11y { it.typeText(args.optString("text"), args.optString("field", null), args.optBoolean("append", false)) }
            "clear_text" -> needA11y { it.clearText() }
            "swipe" -> needA11y {
                if (args.has("x1")) { if (it.swipe(args.optDouble("x1").toFloat(), args.optDouble("y1").toFloat(), args.optDouble("x2").toFloat(), args.optDouble("y2").toFloat())) "Swiped" else "Swipe fail" }
                else it.swipeDirection(args.optString("direction", "up"))
            }
            "scroll" -> needA11y { it.scroll(args.optString("direction", "down")) }
            "back", "home", "recents", "notifications", "quick_settings", "lock", "screenshot", "power" -> needA11y { it.global(action) }
            "wait", "sleep" -> { Thread.sleep(args.optLong("ms", 1000).coerceIn(0, 10000)); "Waited" }

            // ---- apps ----
            "open_app", "launch" -> openApp(args.optString("name", args.optString("package")))
            "apps_list" -> installedApps()
            "open_url" -> { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(args.optString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Opened URL" }
            "open_settings" -> openSettings(args.optString("page", ""))
            "wifi_panel" -> { ctx.startActivity(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "WiFi panel khola (toggle tap karo ya bolo: tap_text Wi-Fi)" }
            "bluetooth_panel" -> { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Bluetooth settings khole" }

            // ---- telephony ----
            "call" -> call(args.optString("number"))
            "end_call" -> needA11y { it.global("back"); "End-call: phone app mein 'End' par tap_text karo" }
            "sms", "send_sms" -> sendSms(args.optString("number"), args.optString("message"))
            "read_sms" -> readSms(args.optInt("limit", 5))
            "contacts_search", "find_contact" -> findContact(args.optString("name"))
            "read_notifications", "notifications_read" -> NotifListener.dump()

            // ---- media / hardware ----
            "volume" -> setVolume(args.optInt("level", 50), args.optString("stream", "music"))
            "mute" -> setVolume(0, args.optString("stream", "music"))
            "media" -> media(args.optString("action", "play"))
            "flashlight", "torch" -> torch(args.optBoolean("on", true))
            "brightness" -> brightness(args.optInt("level", 50))
            "battery" -> battery()
            "alarm" -> { ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, args.optInt("hour", 7)).putExtra(AlarmClock.EXTRA_MINUTES, args.optInt("minute", 0)).putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("message", "SUNO")).putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Alarm set ${args.optInt("hour")}:${String.format("%02d", args.optInt("minute"))}" }
            "timer" -> { ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, args.optInt("seconds", 60)).putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("message", "SUNO")).putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Timer set ${args.optInt("seconds")}s" }
            "device_info" -> "Model: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), a11y=${SunoAccessibilityService.isRunning()}, notifListener=${NotifListener.isRunning()}"
            "ping" -> "pong"
            else -> return Result(false, "Unknown action: $action")
        }
        Result(true, out)
    } catch (e: SecurityException) {
        Result(false, "Permission nahi hai (${e.message}). SUNO Companion app mein permissions do.")
    } catch (e: Exception) {
        Result(false, "Error: ${e.javaClass.simpleName}: ${e.message}")
    }

    private inline fun needA11y(block: (SunoAccessibilityService) -> String): String =
        a11y?.let(block) ?: "Accessibility Service ON nahi hai. SUNO Companion → 'Accessibility Service ON karo'."

    // ---------- helpers ----------

    private fun has(perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    private fun openApp(query: String): String {
        if (query.isBlank()) return "App ka naam do"
        val pm = ctx.packageManager
        // direct package?
        pm.getLaunchIntentForPackage(query)?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Opened $query" }
        val q = query.lowercase().trim()
        val aliases = mapOf(
            "whatsapp" to "com.whatsapp", "youtube" to "com.google.android.youtube", "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps", "google maps" to "com.google.android.apps.maps", "instagram" to "com.instagram.android", "facebook" to "com.facebook.katana",
            "telegram" to "org.telegram.messenger", "paytm" to "net.one97.paytm", "phonepe" to "com.phonepe.app", "gpay" to "com.google.android.apps.nbu.paisa.user", "google pay" to "com.google.android.apps.nbu.paisa.user",
            "amazon" to "in.amazon.mShop.android.shopping", "flipkart" to "com.flipkart.android", "zomato" to "com.application.zomato", "swiggy" to "in.swiggy.android",
            "spotify" to "com.spotify.music", "camera" to "com.android.camera", "settings" to "com.android.settings", "play store" to "com.android.vending", "playstore" to "com.android.vending",
            "photos" to "com.google.android.apps.photos", "gallery" to "com.google.android.apps.photos", "calculator" to "com.google.android.calculator", "clock" to "com.google.android.deskclock",
            "calendar" to "com.google.android.calendar", "contacts" to "com.google.android.contacts", "phone" to "com.google.android.dialer", "dialer" to "com.google.android.dialer", "messages" to "com.google.android.apps.messaging", "sms" to "com.google.android.apps.messaging",
            "uber" to "com.ubercab", "ola" to "com.olacabs.customer", "hotstar" to "in.startv.hotstar", "netflix" to "com.netflix.mediaclient", "jiocinema" to "com.jio.media.ondemand", "snapchat" to "com.snapchat.android", "truecaller" to "com.truecaller"
        )
        aliases[q]?.let { pkg -> pm.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Opened $query" } }
        // fuzzy by label
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val match = apps.map { it to it.loadLabel(pm).toString() }
            .sortedBy { (_, label) -> val l = label.lowercase(); when { l == q -> 0; l.startsWith(q) -> 1; l.contains(q) -> 2; q.contains(l) && l.length > 3 -> 3; else -> 9 } }
            .firstOrNull { (_, label) -> val l = label.lowercase(); l == q || l.startsWith(q) || l.contains(q) || (q.contains(l) && l.length > 3) }
            ?: return "App \"$query\" nahi mili. apps_list se naam dekho."
        val intent = pm.getLaunchIntentForPackage(match.first.activityInfo.packageName) ?: return "Launch intent nahi mila"
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened ${match.second}"
    }

    private fun installedApps(): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0).map { it.loadLabel(pm).toString() }.distinct().sorted().joinToString(", ")
    }

    private fun openSettings(page: String): String {
        val action = when (page.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS; "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS; "apps" -> Settings.ACTION_APPLICATION_SETTINGS; "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS; "date" -> Settings.ACTION_DATE_SETTINGS; "data" -> Settings.ACTION_DATA_ROAMING_SETTINGS
            "hotspot" -> "android.settings.TETHER_SETTINGS"; "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS; "notifications" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Settings khole: ${page.ifBlank { "main" }}"
    }

    private fun call(number: String): String {
        if (number.isBlank()) return "Number do"
        val uri = Uri.parse("tel:" + number.filter { it.isDigit() || it == '+' })
        return if (has(Manifest.permission.CALL_PHONE)) { ctx.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Calling $number" }
        else { ctx.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Dialer khola (CALL_PHONE permission do direct call ke liye)" }
    }

    private fun sendSms(number: String, message: String): String {
        if (number.isBlank() || message.isBlank()) return "number aur message dono do"
        if (!has(Manifest.permission.SEND_SMS)) return "SEND_SMS permission nahi hai"
        val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
        val parts = sm.divideMessage(message)
        sm.sendMultipartTextMessage(number, null, parts, null, null)
        return "SMS bhej diya: $number"
    }

    private fun readSms(limit: Int): String {
        if (!has(Manifest.permission.READ_SMS)) return "READ_SMS permission nahi hai"
        val sb = StringBuilder()
        ctx.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"), null, null, "date DESC")?.use { c ->
            var n = 0; val fmt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
            while (c.moveToNext() && n < limit) { sb.append("- ${c.getString(0)} (${fmt.format(Date(c.getLong(2)))}): ${c.getString(1).take(200)}\n"); n++ }
        }
        return sb.ifEmpty { "Koi SMS nahi" }.toString()
    }

    private fun findContact(name: String): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return "READ_CONTACTS permission nahi hai"
        val sb = StringBuilder()
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { c ->
            var n = 0
            while (c.moveToNext() && n < 8) { sb.append("- ${c.getString(0)}: ${c.getString(1)}\n"); n++ }
        }
        return sb.ifEmpty { "\"$name\" naam ka contact nahi mila" }.toString()
    }

    private fun setVolume(level: Int, stream: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val s = when (stream.lowercase()) { "ring" -> AudioManager.STREAM_RING; "alarm" -> AudioManager.STREAM_ALARM; "notification" -> AudioManager.STREAM_NOTIFICATION; "call" -> AudioManager.STREAM_VOICE_CALL; else -> AudioManager.STREAM_MUSIC }
        val max = am.getStreamMaxVolume(s)
        val v = (level.coerceIn(0, 100) * max / 100.0).toInt()
        am.setStreamVolume(s, v, AudioManager.FLAG_SHOW_UI)
        return "$stream volume = $level%"
    }

    private fun media(action: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val key = when (action.lowercase()) { "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE; "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous", "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; "stop" -> KeyEvent.KEYCODE_MEDIA_STOP; "toggle" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE; else -> KeyEvent.KEYCODE_MEDIA_PLAY }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return "Media: $action"
    }

    private fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return "Flash nahi hai"
        cm.setTorchMode(id, on)
        return "Torch ${if (on) "ON" else "OFF"}"
    }

    private fun brightness(level: Int): String {
        if (!Settings.System.canWrite(ctx)) return "'Modify system settings' permission do (SUNO Companion → button 4)"
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (level.coerceIn(0, 100) * 255 / 100))
        return "Brightness = $level%"
    }

    private fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Battery $pct%${if (charging) " (charging)" else ""}"
    }
}
