package com.suno.agent

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var log: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val url = findViewById<EditText>(R.id.serverUrl)
        val token = findViewById<EditText>(R.id.token)
        status = findViewById(R.id.status)
        log = findViewById(R.id.log)
        url.setText(Prefs.serverUrl(this)); token.setText(Prefs.token(this))

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            val u = url.text.toString().trim(); val t = token.text.toString().trim()
            if (!u.startsWith("http")) { toast("Server URL https:// se shuru hona chahiye"); return@setOnClickListener }
            if (t.isBlank()) { toast("Token daalo (PWA Settings → Phone Bridge)"); return@setOnClickListener }
            Prefs.save(this, u, t, true)
            if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            BridgeService.start(this); toast("Bridge started")
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener { Prefs.save(this, url.text.toString(), token.text.toString(), false); BridgeService.stop(this); toast("Stopped") }
        findViewById<Button>(R.id.btnAccess).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); toast("List mein 'SUNO Phone Control' dhoondo → ON") }
        findViewById<Button>(R.id.btnNotif).setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        findViewById<Button>(R.id.btnPerms).setOnClickListener {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS, Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA), 1)
        }
        findViewById<Button>(R.id.btnWriteSettings).setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            @SuppressLint("BatteryLife") val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")); startActivity(i)
        }
        if (Prefs.enabled(this)) BridgeService.start(this)
        tick()
    }

    private fun tick() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val a11y = SunoAccessibilityService.isRunning(); val notif = NotifListener.isRunning()
        status.text = "Bridge: ${BridgeService.lastStatus}\n" +
            "Accessibility: ${if (a11y) "ON ✓" else "OFF ✗ (button 1)"}\n" +
            "Notification access: ${if (notif) "ON ✓" else "OFF"}\n" +
            "Modify settings: ${if (Settings.System.canWrite(this)) "ON ✓" else "OFF"}\n" +
            "Battery optimization ignored: ${if (pm.isIgnoringBatteryOptimizations(packageName)) "YES ✓" else "NO"}"
        log.text = BridgeService.lastLog
        handler.postDelayed({ tick() }, 1500)
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
