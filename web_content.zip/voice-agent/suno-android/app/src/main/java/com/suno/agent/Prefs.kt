package com.suno.agent

import android.content.Context

object Prefs {
    private const val NAME = "suno"
    fun serverUrl(ctx: Context): String = ctx.getSharedPreferences(NAME, 0).getString("url", "") ?: ""
    fun token(ctx: Context): String = ctx.getSharedPreferences(NAME, 0).getString("token", "") ?: ""
    fun enabled(ctx: Context): Boolean = ctx.getSharedPreferences(NAME, 0).getBoolean("enabled", false)
    fun save(ctx: Context, url: String, token: String, enabled: Boolean) {
        ctx.getSharedPreferences(NAME, 0).edit().putString("url", url.trimEnd('/')).putString("token", token.trim()).putBoolean("enabled", enabled).apply()
    }
}
