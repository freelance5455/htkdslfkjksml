# 📱 SUNO Companion (Android) — poora phone control

Ye chhoti native app SUNO AI ko aapke phone ki **aankhein aur haath** deti hai:
screen padhna, tap, type, swipe, apps kholna, direct call/SMS, notifications padhna, volume/torch/brightness, alarm, settings.

SUNO server se commands aati hain (long-poll, HTTPS) → Accessibility Service execute karta hai → result wapas SUNO ko.

## Build (Android Studio)
1. Android Studio (Hedgehog ya naya) kholo → **Open** → `suno-android` folder.
2. Gradle sync hone do (pehli baar 2-5 min). Agar "Gradle wrapper" poochhe → *Use default gradle wrapper* / *OK*.
3. Phone USB se connect karo (Developer options → USB debugging ON) → **Run ▶** .
   Ya **Build → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk` phone mein bhej ke install karo.

## Setup (phone par, ek baar)
1. App kholo → **Server URL** (PWA Settings → Phone Bridge se copy) + **Pairing token** → *Save & Start bridge*
2. Button 1: **Accessibility Service ON** → list mein "SUNO Phone Control" → ON → Allow  ⚠️ *zaroori*
3. Button 2: Notification access → SUNO → ON (notifications padhne ke liye)
4. Button 3: Call / SMS / Contacts / Camera permissions → Allow
5. Button 4: Modify system settings (brightness) → Allow
6. Button 5: Battery optimization → *Don't optimize* (background mein connected rahe)
7. Xiaomi/Oppo/Vivo/Realme: Settings → Apps → SUNO Companion → **Autostart ON** + battery "No restrictions"

PWA Settings → Phone Bridge mein **● Connected** dikhna chahiye.

## Bol ke try karo (PWA / SUNO mein)
- "Screen padho" / "Abhi kaunsi app khuli hai"
- "WhatsApp kholo, Mummy ko message karo good night" (SUNO: open_app → read_screen → tap_text Mummy → type → tap_text Send)
- "Torch on karo" · "Volume 30 karo" · "Brightness full karo" · "Battery kitni hai"
- "Meri notifications padho" · "Last 5 SMS padho" · "Rahul ka number dhoondo"
- "9876543210 pe call lagao" (direct call) · "Kal subah 6 baje alarm lagao"
- "Back jao" · "Home jao" · "Neeche scroll karo" · "Screenshot lo" · "Phone lock karo"

## Security
- Sirf aapke server (URL) se aaye commands chalte hain, aur token match hona zaroori hai.
- Server public ho to token strong rakho (`.env` → `DEVICE_TOKEN`), aur server URL kisi ko mat do.
- Accessibility Service bahut powerful hai — app sirf apne phone par install karo.

## Actions reference (SUNO ke `phone` tool ke liye)
`read_screen, current_app, tap_text{text}, tap{x,y}, long_press{x,y}, type{text,field?}, clear_text, swipe{direction|x1,y1,x2,y2}, scroll{direction}, back, home, recents, notifications, quick_settings, lock, screenshot, power, wait{ms},
open_app{name}, apps_list, open_url{url}, open_settings{page}, wifi_panel, bluetooth_panel,
call{number}, sms{number,message}, read_sms{limit}, contacts_search{name}, read_notifications,
volume{level,stream}, mute, media{action}, flashlight{on}, brightness{level}, battery, alarm{hour,minute,message}, timer{seconds,message}, device_info, ping`
