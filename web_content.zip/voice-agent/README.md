# 🎙️ SUNO — AI Voice Agent (Hinglish)

Ek personal AI voice agent jo aapki baat sunta hai, kaam karta hai, sub-agents ko kaam deta hai, yaad rakhta hai,
aur **GitHub repo link paste karte hi** ya to naya agent ban jata hai ya us repo se aur smart ho jata hai.

Mobile-first **PWA** — Android Chrome mein "Add to Home screen" karo, app ki tarah chalegi.

## ✨ Features

| Feature | Kya karta hai |
|---|---|
| 🎤 Voice in/out | Hindi/Hinglish/English bolo, jawab bol ke sunata hai. Hands-free mode bhi. |
| 🧠 Pluggable brain | Gemini (free), Groq (free), OpenRouter, OpenAI, Claude, Ollama (local), custom. Bina key **Demo Brain**. |
| 🔧 Tools | Web search, webpage padhna, calculator, JS/Python run, notes, reminders, date-time |
| 📱 Phone control (browser) | Apps kholna (YouTube, Maps, WhatsApp, Paytm, Zomato…), call lagana, SMS, WhatsApp message, GPS location, share sheet, clipboard, vibrate |
| 🤖 **POORA phone control** | `suno-android/` companion app (Accessibility Service): screen padhna, tap, type, swipe, apps ke andar kaam, direct call/SMS, notifications/SMS padhna, volume, torch, brightness, alarm, settings — AI khud multi-step karta hai |
| 🤖 Sub-agents | SUNO (orchestrator), Researcher, Coder, Planner + apne banao. "X ko task do: ..." bolo → background mein kaam. |
| ⚡ Tasks tab | Har background task ke steps + result live dikhte hain, bol ke bhi sunata hai |
| 🐙 GitHub → Agent | Repo link paste karo → agent project hai to **naya agent**, warna **knowledge/skill** ban jata hai |
| 🧠 Memory | Long-term memory ("yaad rakho...") + knowledge base + notes, sab phone mein saved |
| 📲 PWA | Offline shell, home-screen icon, install prompt |

## 🚀 Chalane ka tareeka

```bash
cd voice-agent
npm start          # http://localhost:3000  (koi dependency install nahi karni — pure Node 18+)
```

### Phone par test karna
1. PC aur phone same WiFi par hon.
2. PC ka IP nikalo (`ipconfig` / `ip a`) → phone ke Chrome mein `http://<pc-ip>:3000` kholo.
3. ⚠️ **Mic sirf HTTPS (ya localhost) par chalta hai.** LAN IP par mic ke liye:
   - Chrome → `chrome://flags/#unsafe-treat-insecure-origin-as-secure` mein `http://<pc-ip>:3000` daalo, ya
   - Neeche wala free deploy karo (HTTPS mil jayega).

### Free HTTPS deploy (recommended)
Koi bhi Node host chalega — **Render**, **Railway**, **Fly.io**, **Glitch**:
- Build command: *(kuch nahi)* · Start command: `node server.js` · Node 18+
- Deploy hone ke baad phone Chrome mein URL kholo → menu → **"Add to Home screen"** → app ready.

### APK banana (Play Store style)
PWA ko APK mein wrap karo: <https://www.pwabuilder.com> → apna HTTPS URL do → Android package download.

## 🔑 API key — do tareeke

**A) Server key (`.env`) — sabse aasaan, abhi configured hai:**
```
SERVER_PROVIDER=gemini
SERVER_API_KEY=<aapki key>
SERVER_MODEL=gemini-flash-lite-latest
```
App khulte hi automatically "Server key" mode mein chalti hai (badge: GEMINI). Deploy karte waqt ye 3 values host ke *Environment Variables* mein daal do.
Gemini free-tier quota khatam ho to app khud agle model par fallback karti hai (`flash-lite` → `3.1-flash-lite` → `flash` → `gemma-4`).

**B) Apni key phone mein:** Settings → Provider chuno → key paste. Ye sirf aapke phone mein save hoti hai.

### Free key kahan se
- **Gemini**: <https://aistudio.google.com> → *Get API key* → Settings mein provider "Gemini" + key paste → *Test connection*
- **Groq** (bahut fast): <https://console.groq.com> → *API Keys*

Bina key Demo Brain chalta hai (voice, search, calculator, memory, GitHub analysis, tasks) — lekin *samajhdaari* key se aati hai.

## 🗣️ Bol ke try karo
- "Aaj ki top news batao"
- "Yaad rakho meri gaadi ka number DL 8C 1234" → "Kya yaad hai?"
- "Researcher ko task do: best budget phone under 15000"
- "Naya agent banao jo mere emails likhe"
- "Python chalao: print(sum(range(101)))"
- "10 minute baad yaad dilana paani peena"
- "YouTube pe lofi songs chalao"
- "9876543210 pe WhatsApp message bhejo: kal milte hain"
- "Mummy ko call lagao" (number bolo) · "Meri location batao" · "Zomato kholo"

## 🤖 Poora phone control (Android companion)
`suno-android/` folder = native Kotlin app. Android Studio mein kholo → Run → phone par install.
App mein Server URL + Pairing token daalo (PWA Settings → Phone Bridge), Accessibility ON karo → PWA mein **● Connected**.
Phir bolo: *"WhatsApp kholo aur Mummy ko good night bhejo"* → SUNO khud: open_app → read_screen → tap Mummy → type → Send.
Poori guide: `suno-android/README.md`. Token `.env` mein `DEVICE_TOKEN` se set hota hai.

## 🧩 Structure
```
server.js          # zero-dep Node server: static PWA + /api/chat /api/search /api/fetch /api/github
lib/llm.js         # provider adapter (OpenAI/Gemini/Anthropic/Groq/OpenRouter/Ollama/custom)
lib/search.js      # DuckDuckGo search + URL reader
lib/github.js      # repo fetch + agent detection score
lib/devices.js     # phone bridge: command queue for Android companion
suno-android/      # native Android companion (Kotlin, Accessibility Service)
public/js/app.js   # UI controller
public/js/brain.js # prompt builder, tool loop, Demo Brain
public/js/tools.js # all tools
public/js/agents.js# agent registry + background task runner
public/js/github.js# repo -> agent / knowledge
public/js/voice.js # STT + TTS
public/js/store.js # localStorage state
```

## 🔒 Privacy
API key aur saara data sirf aapke phone (localStorage) mein rehta hai; server sirf request forward karta hai, kuch store nahi karta.
