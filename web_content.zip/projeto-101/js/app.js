// ==================== CONSTANTS ====================
const PROJECT_START = new Date(2026, 8, 21); // 21/09/2026
const PROJECT_END = new Date(2026, 11, 30);  // 30/12/2026
const TOTAL_DAYS = 101;

const DEFAULT_WORKOUTS = {
  1: { // Monday
    id: 'muay_mon', name: 'Muay Thai', type: 'muay', icon: '🥊',
    exercises: [
      { id: 'm1', name: 'Aquecimento / Sombra', sets: 3, reps: '3 min', load: 0, rest: 60 },
      { id: 'm2', name: 'Técnica de socos', sets: 4, reps: '2 min', load: 0, rest: 60 },
      { id: 'm3', name: 'Chutes (roundhouse)', sets: 4, reps: '2 min', load: 0, rest: 60 },
      { id: 'm4', name: 'Joelhadas', sets: 3, reps: '1.5 min', load: 0, rest: 60 },
      { id: 'm5', name: 'Clinches / Pad work', sets: 3, reps: '2 min', load: 0, rest: 90 }
    ]
  },
  2: { // Tuesday
    id: 'superior', name: 'Superior', type: 'superior', icon: '💪',
    exercises: [
      { id: 's1', name: 'Flexão com mochila', sets: 4, reps: '8–15', load: 0, rest: 90 },
      { id: 's2', name: 'Remada curvada com mochila', sets: 4, reps: '8–15', load: 0, rest: 90 },
      { id: 's3', name: 'Remada unilateral com mochila', sets: 3, reps: '10–15', load: 0, rest: 75 },
      { id: 's4', name: 'Pike push-up', sets: 3, reps: '6–12', load: 0, rest: 75 },
      { id: 's5', name: 'Flexão fechada', sets: 3, reps: '8–15', load: 0, rest: 60 },
      { id: 's6', name: 'Rosca com mochila', sets: 3, reps: '10–15', load: 0, rest: 60 }
    ]
  },
  3: { // Wednesday
    id: 'muay_wed', name: 'Muay Thai', type: 'muay', icon: '🥊',
    exercises: [
      { id: 'm1', name: 'Aquecimento / Sombra', sets: 3, reps: '3 min', load: 0, rest: 60 },
      { id: 'm2', name: 'Técnica de socos', sets: 4, reps: '2 min', load: 0, rest: 60 },
      { id: 'm3', name: 'Chutes (roundhouse)', sets: 4, reps: '2 min', load: 0, rest: 60 },
      { id: 'm4', name: 'Joelhadas', sets: 3, reps: '1.5 min', load: 0, rest: 60 },
      { id: 'm5', name: 'Clinches / Pad work', sets: 3, reps: '2 min', load: 0, rest: 90 }
    ]
  },
  4: { // Thursday
    id: 'inferior', name: 'Inferior + Core', type: 'inferior', icon: '🦵',
    exercises: [
      { id: 'i1', name: 'Agachamento com mochila', sets: 4, reps: '10–15', load: 0, rest: 90 },
      { id: 'i2', name: 'Afundo búlgaro', sets: 3, reps: '8–12 cada perna', load: 0, rest: 90 },
      { id: 'i3', name: 'Stiff com mochila', sets: 3, reps: '10–15', load: 0, rest: 75 },
      { id: 'i4', name: 'Elevação pélvica com mochila', sets: 3, reps: '10–15', load: 0, rest: 60 },
      { id: 'i5', name: 'Panturrilha unilateral', sets: 4, reps: '12–20', load: 0, rest: 45 },
      { id: 'i6', name: 'Elevação de pernas', sets: 3, reps: '10–15', load: 0, rest: 45 },
      { id: 'i7', name: 'Prancha', sets: 3, reps: '30–60 segundos', load: 0, rest: 45 }
    ]
  },
  5: { // Friday
    id: 'muay_fri', name: 'Muay Thai', type: 'muay', icon: '🥊',
    exercises: [
      { id: 'm1', name: 'Aquecimento / Sombra', sets: 3, reps: '3 min', load: 0, rest: 60 },
      { id: 'm2', name: 'Técnica de socos', sets: 4, reps: '2 min', load: 0, rest: 60 },
      { id: 'm3', name: 'Chutes (roundhouse)', sets: 4, reps: '2 min', load: 0, rest: 60 },
      { id: 'm4', name: 'Joelhadas', sets: 3, reps: '1.5 min', load: 0, rest: 60 },
      { id: 'm5', name: 'Clinches / Pad work', sets: 3, reps: '2 min', load: 0, rest: 90 }
    ]
  },
  6: { // Saturday
    id: 'recovery', name: 'Recuperação / Atividade leve', type: 'recovery', icon: '🧘',
    exercises: [
      { id: 'r1', name: 'Caminhada leve', sets: 1, reps: '20–40 min', load: 0, rest: 0 },
      { id: 'r2', name: 'Alongamento geral', sets: 1, reps: '10–15 min', load: 0, rest: 0 },
      { id: 'r3', name: 'Mobilidade de quadril', sets: 2, reps: '8–10', load: 0, rest: 30 }
    ]
  },
  0: { // Sunday
    id: 'rest', name: 'Descanso / Recuperação', type: 'rest', icon: '😴',
    exercises: [
      { id: 'd1', name: 'Descanso ativo (opcional)', sets: 1, reps: 'livre', load: 0, rest: 0 }
    ]
  }
};

const POSTURE_EXERCISES = [
  { id: 'p1', name: 'Chin tuck', instruction: 'Recolha o queixo suavemente, mantendo o olhar para frente.', sets: 3, reps: '10–12', rest: 30 },
  { id: 'p2', name: 'Retração escapular', instruction: 'Aproxime as escápulas como se apertasse um lápis entre elas.', sets: 3, reps: '12–15', rest: 30 },
  { id: 'p3', name: 'Crucifixo inverso', instruction: 'Braços abertos, leve as mãos para trás com controle.', sets: 3, reps: '10–12', rest: 45 },
  { id: 'p4', name: 'Alongamento peitoral na parede', instruction: 'Antebraço na parede, gire o tronco suavemente.', sets: 2, reps: '30–45s cada lado', rest: 20 }
];

const DAY_NAMES = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
const MOTIVATIONS = [
  'Um dia de cada vez. Foque no próximo hábito.',
  'Consistência supera intensidade.',
  'Hoje conta. Faça o que puder.',
  'Pequenos passos, grandes mudanças.',
  'Disciplina é liberdade a longo prazo.',
  'Mostre para você mesmo que é possível.',
  'O progresso é a soma dos dias.',
  'Não precisa ser perfeito. Precisa ser constante.'
];

// ==================== STATE ====================
let S = {
  profile: { name: '' },
  settings: { restDefault: 90, sound: true, notif: false },
  workouts: null,          // custom overrides
  daily: {},               // { '2026-09-21': { habits:{}, water:0, sleep:0, posture:false, workout:false, notes:'' } }
  sessions: [],            // completed sessions
  active: null,            // current workout session in progress
  rest: { remaining:0, interval:null, paused:false, isFocus:false },
  logPending: null,
  editBuffer: null,
  sessionFilter: 'all'
};

// ==================== STORAGE ====================
function load() {
  try {
    const raw = localStorage.getItem('projeto101_v1');
    if (raw) {
      const d = JSON.parse(raw);
      S.profile = d.profile || S.profile;
      S.settings = d.settings || S.settings;
      S.workouts = d.workouts || null;
      S.daily = d.daily || {};
      S.sessions = d.sessions || [];
    }
  } catch(e) {}
  if (!S.workouts) S.workouts = structuredClone(DEFAULT_WORKOUTS);
}

function save() {
  localStorage.setItem('projeto101_v1', JSON.stringify({
    profile: S.profile,
    settings: S.settings,
    workouts: S.workouts,
    daily: S.daily,
    sessions: S.sessions
  }));
}

// ==================== DATE HELPERS ====================
function todayKey() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}

function keyFromDate(d) {
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}

function dayNumber(date) {
  const d = date ? new Date(date) : new Date();
  d.setHours(12,0,0,0);
  const start = new Date(PROJECT_START); start.setHours(12,0,0,0);
  const diff = Math.floor((d - start) / 86400000) + 1;
  return Math.max(1, Math.min(TOTAL_DAYS, diff));
}

function dateFromDayNum(n) {
  const d = new Date(PROJECT_START);
  d.setDate(d.getDate() + (n - 1));
  return d;
}

function ensureDay(key) {
  if (!S.daily[key]) {
    S.daily[key] = {
      habits: {
        skincare_clean: false, skincare_moist: false, skincare_spf: false,
        food_meals: false, food_veggies: false, food_protein: false, food_less_processed: false,
        posture: false, workout: false
      },
      water: 0,
      sleep: 0,
      notes: ''
    };
  }
  return S.daily[key];
}

function isDayComplete(key) {
  const day = S.daily[key];
  if (!day) return false;
  const h = day.habits;
  const checks = [
    h.skincare_clean && h.skincare_moist && h.skincare_spf,
    day.water >= 2000,
    day.sleep >= 7.5,
    h.food_meals && h.food_veggies && h.food_protein,
    h.posture,
    h.workout
  ];
  return checks.filter(Boolean).length >= 4; // soft complete = at least 4 categories
}

function isDayPartial(key) {
  const day = S.daily[key];
  if (!day) return false;
  if (isDayComplete(key)) return false;
  const h = day.habits;
  return day.water > 0 || day.sleep > 0 || Object.values(h).some(Boolean);
}

// ==================== NAV ====================
function navTo(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById('screen-' + name);
  if (el) el.classList.add('active');

  document.querySelectorAll('.nav-item, .side-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.screen === name);
  });

  if (name === 'home') renderHome();
  if (name === 'workouts') renderWorkouts();
  if (name === 'posture') renderPosture();
  if (name === 'habits') renderHabits();
  if (name === 'sessions') renderSessions();
  if (name === 'stats') renderStats();
  if (name === 'settings') renderSettings();
}

// ==================== HOME ====================
function renderHome() {
  const today = new Date();
  const num = dayNumber(today);
  const key = todayKey();
  ensureDay(key);

  document.getElementById('day-label').textContent = 'Dia ' + num + ' de 101';
  document.getElementById('today-date').textContent = formatDateShort(today);

  // countdown
  const end = new Date(PROJECT_END); end.setHours(23,59,59);
  const left = Math.max(0, Math.ceil((end - today) / 86400000));
  document.getElementById('countdown').textContent = left + ' dias restantes';

  // progress
  let completedDays = 0;
  for (let i = 1; i <= TOTAL_DAYS; i++) {
    const d = dateFromDayNum(i);
    if (isDayComplete(keyFromDate(d))) completedDays++;
  }
  const pct = Math.round((completedDays / TOTAL_DAYS) * 100);
  document.getElementById('progress-pct').textContent = pct + '%';
  const ring = document.getElementById('progress-ring');
  const offset = 264 - (264 * pct / 100);
  ring.style.strokeDashoffset = offset;

  // stats
  document.getElementById('stat-days').textContent = completedDays;
  document.getElementById('stat-sessions').textContent = S.sessions.length;
  let habitCount = 0;
  Object.values(S.daily).forEach(d => {
    habitCount += Object.values(d.habits || {}).filter(Boolean).length;
  });
  document.getElementById('stat-habits').textContent = habitCount;

  // streak
  let streak = 0;
  for (let i = num; i >= 1; i--) {
    const d = dateFromDayNum(i);
    if (isDayComplete(keyFromDate(d))) streak++;
    else if (i < num) break;
  }
  document.getElementById('stat-streak').textContent = streak;

  // motivation
  document.getElementById('motivation').textContent = MOTIVATIONS[num % MOTIVATIONS.length];

  // checklist
  renderTodayChecklist(key);

  // calendar
  renderCalendar();
}

function renderTodayChecklist(key) {
  const day = ensureDay(key);
  const items = [
    { id: 'workout', label: '🏋️ Treino do dia', key: 'workout' },
    { id: 'posture', label: '🧍 Rotina de postura', key: 'posture' },
    { id: 'skincare', label: '🧴 Skin Care (completo)', key: null, check: () => day.habits.skincare_clean && day.habits.skincare_moist && day.habits.skincare_spf },
    { id: 'water', label: '💧 Água — 2 L', key: null, check: () => day.water >= 2000 },
    { id: 'sleep', label: '😴 Sono — 8 h', key: null, check: () => day.sleep >= 7.5 },
    { id: 'food', label: '🥗 Alimentação saudável', key: null, check: () => day.habits.food_meals && day.habits.food_veggies && day.habits.food_protein }
  ];

  const cont = document.getElementById('today-checklist');
  cont.innerHTML = '';
  items.forEach(it => {
    let done = false;
    if (it.key) done = !!day.habits[it.key];
    else if (it.check) done = it.check();

    const el = document.createElement('div');
    el.className = 'check-item' + (done ? ' done' : '');
    el.innerHTML = '<div class="check-box"></div><span class="check-label">' + it.label + '</span>';
    el.onclick = () => {
      if (it.key) {
        day.habits[it.key] = !day.habits[it.key];
        save();
        renderTodayChecklist(key);
        updateDayStatus(key);
      } else {
        // go to habits screen for detailed
        navTo('habits');
      }
    };
    cont.appendChild(el);
  });
  updateDayStatus(key);
}

function updateDayStatus(key) {
  const el = document.getElementById('day-status');
  if (isDayComplete(key)) el.textContent = '✓ Dia concluído';
  else if (isDayPartial(key)) el.textContent = '◐ Em andamento';
  else el.textContent = '';
}

function renderCalendar() {
  const cont = document.getElementById('calendar');
  cont.innerHTML = '';
  // labels
  ['D','S','T','Q','Q','S','S'].forEach(l => {
    const lb = document.createElement('div');
    lb.className = 'cal-label';
    lb.textContent = l;
    cont.appendChild(lb);
  });

  // pad start
  const first = new Date(PROJECT_START);
  const startPad = first.getDay();
  for (let i = 0; i < startPad; i++) {
    const e = document.createElement('div');
    cont.appendChild(e);
  }

  const today = new Date(); today.setHours(12,0,0,0);
  for (let i = 1; i <= TOTAL_DAYS; i++) {
    const d = dateFromDayNum(i);
    const key = keyFromDate(d);
    const cell = document.createElement('div');
    cell.className = 'cal-day';
    if (keyFromDate(today) === key) cell.classList.add('today');
    if (isDayComplete(key)) cell.classList.add('full');
    else if (isDayPartial(key)) cell.classList.add('partial');
    cell.innerHTML = '<span>' + d.getDate() + '</span><div class="dot"></div>';
    cell.onclick = () => openDayDetail(i);
    cont.appendChild(cell);
  }
}

function openDayDetail(num) {
  const d = dateFromDayNum(num);
  const key = keyFromDate(d);
  const day = ensureDay(key);
  document.getElementById('day-overlay-title').textContent = 'Dia ' + num + ' — ' + formatDateShort(d);
  const body = document.getElementById('day-overlay-body');
  body.innerHTML =
    '<div class="checklist">' +
    makeCheck('Treino do dia', day.habits.workout, () => { day.habits.workout = !day.habits.workout; save(); openDayDetail(num); }) +
    makeCheck('Rotina de postura', day.habits.posture, () => { day.habits.posture = !day.habits.posture; save(); openDayDetail(num); }) +
    makeCheck('Skin Care completo', day.habits.skincare_clean && day.habits.skincare_moist && day.habits.skincare_spf, null) +
    '<div class="check-item"><span class="check-label">💧 Água: ' + day.water + ' / 2000 ml</span></div>' +
    '<div class="check-item"><span class="check-label">😴 Sono: ' + (day.sleep || 0) + ' h</span></div>' +
    makeCheck('Alimentação', day.habits.food_meals && day.habits.food_veggies, null) +
    '</div>';
  document.getElementById('day-overlay').classList.remove('hidden');
}

function makeCheck(label, done, onClick) {
  return '<div class="check-item ' + (done?'done':'') + '" ' + (onClick ? 'onclick="void(0)"' : '') + '>' +
    '<div class="check-box"></div><span class="check-label">' + label + '</span></div>';
}

function closeDayOverlay() {
  document.getElementById('day-overlay').classList.add('hidden');
  renderHome();
}

function formatDateShort(d) {
  return String(d.getDate()).padStart(2,'0') + '/' + String(d.getMonth()+1).padStart(2,'0') + '/' + d.getFullYear();
}

// ==================== WORKOUTS ====================
function renderWorkouts() {
  const grid = document.getElementById('week-grid');
  grid.innerHTML = '';
  document.getElementById('workout-detail').classList.add('hidden');

  [1,2,3,4,5,6,0].forEach(dow => {
    const w = S.workouts[dow] || DEFAULT_WORKOUTS[dow];
    const card = document.createElement('div');
    card.className = 'day-card-w';
    card.innerHTML =
      '<div class="day-name">' + DAY_NAMES[dow].toUpperCase() + '</div>' +
      '<div class="day-focus">' + w.icon + ' ' + w.name + '</div>' +
      '<div class="day-meta">' + w.exercises.length + ' exercícios</div>';
    card.onclick = () => startWorkout(dow);
    grid.appendChild(card);
  });
}

function startWorkout(dow) {
  const w = structuredClone(S.workouts[dow] || DEFAULT_WORKOUTS[dow]);
  S.active = {
    dow,
    workoutId: w.id,
    name: w.name,
    type: w.type,
    icon: w.icon,
    exercises: w.exercises.map(ex => ({
      ...ex,
      setsData: Array(ex.sets).fill(null).map(() => ({ done: false, reps: 0, load: 0 }))
    })),
    startedAt: Date.now()
  };
  document.getElementById('active-title').textContent = w.icon + ' ' + w.name;
  document.getElementById('active-sub').textContent = DAY_NAMES[dow];
  renderActiveExercises();
  navTo('active');
}

function renderActiveExercises() {
  const cont = document.getElementById('active-exercises');
  cont.innerHTML = '';
  let allDone = true;
  S.active.exercises.forEach((ex, ei) => {
    const doneCount = ex.setsData.filter(s => s.done).length;
    if (doneCount < ex.sets) allDone = false;
    const card = document.createElement('div');
    card.className = 'ex-card' + (doneCount >= ex.sets ? ' done' : '');
    let setsHtml = '';
    ex.setsData.forEach((s, si) => {
      setsHtml +=
        '<div class="set-row ' + (s.done?'done':'') + '" onclick="toggleSet(' + ei + ',' + si + ')">' +
          '<div class="set-check"></div>' +
          '<span class="set-info">Série ' + (si+1) + '</span>' +
          (s.done && (s.reps || s.load) ? '<span class="set-log">' + (s.reps||'') + (s.load?' @'+s.load+'kg':'') + '</span>' : '') +
        '</div>';
    });
    card.innerHTML =
      '<div class="ex-head">' +
        '<div><div class="ex-name">' + ex.name + '</div>' +
        '<div class="ex-meta">' + ex.sets + ' × ' + ex.reps + (ex.load ? ' • ' + ex.load + 'kg' : '') + ' • descanso ' + (ex.rest||S.settings.restDefault) + 's</div></div>' +
        '<span class="ex-prog">' + doneCount + '/' + ex.sets + '</span>' +
      '</div><div class="sets">' + setsHtml + '</div>';
    cont.appendChild(card);
  });
  document.getElementById('btn-finish-session').disabled = !allDone;
}

function toggleSet(ei, si) {
  const ex = S.active.exercises[ei];
  const s = ex.setsData[si];
  if (s.done) {
    s.done = false; s.reps = 0; s.load = 0;
    renderActiveExercises();
    return;
  }
  // open log
  S.logPending = { ei, si };
  document.getElementById('log-title').textContent = 'Série ' + (si+1);
  document.getElementById('log-ex').textContent = ex.name;
  document.getElementById('log-reps').value = 10;
  document.getElementById('log-load').value = ex.load || 0;
  document.getElementById('log-overlay').classList.remove('hidden');
}

function stepLog(field, delta) {
  const el = document.getElementById('log-' + field);
  let v = parseFloat(el.value) || 0;
  v = Math.max(0, v + delta);
  if (field === 'reps') v = Math.min(50, Math.round(v));
  if (field === 'load') v = Math.min(100, Math.round(v*2)/2);
  el.value = v;
}

function closeLog(withData) {
  document.getElementById('log-overlay').classList.add('hidden');
  if (!S.logPending) return;
  const { ei, si } = S.logPending;
  const ex = S.active.exercises[ei];
  const s = ex.setsData[si];
  s.done = true;
  if (withData) {
    s.reps = parseInt(document.getElementById('log-reps').value) || 0;
    s.load = parseFloat(document.getElementById('log-load').value) || 0;
  }
  S.logPending = null;
  renderActiveExercises();
  // start rest
  const restSec = ex.rest || S.settings.restDefault;
  if (restSec > 0) startRest(restSec);
}

function startRest(seconds) {
  if (S.rest.interval) return;
  S.rest.remaining = seconds;
  S.rest.paused = false;
  document.getElementById('rest-timer').textContent = formatTime(seconds);
  document.getElementById('btn-rest-pause').textContent = 'Pausar';
  document.getElementById('rest-overlay').classList.remove('hidden');

  S.rest.interval = setInterval(() => {
    if (S.rest.paused) return;
    S.rest.remaining--;
    document.getElementById('rest-timer').textContent = formatTime(Math.max(0, S.rest.remaining));
    if (S.rest.remaining <= 0) {
      clearInterval(S.rest.interval);
      S.rest.interval = null;
      document.getElementById('rest-timer').textContent = 'PRONTO!';
      if (S.settings.sound && navigator.vibrate) navigator.vibrate([200,100,200]);
      setTimeout(() => {
        document.getElementById('rest-overlay').classList.add('hidden');
      }, 1200);
    }
  }, 1000);
}

function formatTime(sec) {
  const m = Math.floor(sec/60);
  const s = sec % 60;
  return String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
}

function toggleRestPause() {
  S.rest.paused = !S.rest.paused;
  document.getElementById('btn-rest-pause').textContent = S.rest.paused ? 'Continuar' : 'Pausar';
}

function adjRest(delta) {
  S.rest.remaining = Math.max(0, S.rest.remaining + delta);
  document.getElementById('rest-timer').textContent = formatTime(S.rest.remaining);
}

function skipRest() {
  if (S.rest.interval) { clearInterval(S.rest.interval); S.rest.interval = null; }
  document.getElementById('rest-overlay').classList.add('hidden');
}

function finishSession() {
  if (!S.active) return;
  const duration = Math.round((Date.now() - S.active.startedAt) / 60000);
  const setsDone = S.active.exercises.reduce((a,ex) => a + ex.setsData.filter(s=>s.done).length, 0);
  const session = {
    id: 'ses_' + Date.now(),
    date: todayKey(),
    name: S.active.name,
    type: S.active.type,
    icon: S.active.icon,
    exercises: S.active.exercises,
    setsDone,
    duration,
    notes: ''
  };
  S.sessions.unshift(session);

  // mark workout habit
  const day = ensureDay(todayKey());
  day.habits.workout = true;
  save();

  S.active = null;
  alert('Sessão salva! ✓');
  navTo('sessions');
}

function exitWorkout() {
  if (S.active && !confirm('Sair sem finalizar a sessão?')) return;
  if (S.rest.interval) { clearInterval(S.rest.interval); S.rest.interval = null; }
  document.getElementById('rest-overlay').classList.add('hidden');
  S.active = null;
  navTo('workouts');
}

// ==================== EDIT ====================
function openEditWorkout() {
  if (!S.active) return;
  S.editBuffer = structuredClone(S.active.exercises);
  renderEditList();
  document.getElementById('edit-overlay').classList.remove('hidden');
}

function renderEditList() {
  const list = document.getElementById('edit-list');
  list.innerHTML = '';
  S.editBuffer.forEach((ex, i) => {
    const item = document.createElement('div');
    item.className = 'edit-item';
    item.innerHTML =
      '<input value="' + ex.name + '" onchange="S.editBuffer['+i+'].name=this.value">' +
      '<div class="row">' +
        '<input type="number" value="' + ex.sets + '" min="1" max="10" onchange="S.editBuffer['+i+'].sets=+this.value" placeholder="Séries">' +
        '<input value="' + ex.reps + '" onchange="S.editBuffer['+i+'].reps=this.value" placeholder="Reps">' +
        '<input type="number" value="' + (ex.rest||90) + '" onchange="S.editBuffer['+i+'].rest=+this.value" placeholder="Descanso">' +
      '</div>' +
      '<div class="edit-actions">' +
        '<button onclick="moveEdit('+i+',-1)">↑</button>' +
        '<button onclick="moveEdit('+i+',1)">↓</button>' +
        '<button onclick="dupEdit('+i+')">Duplicar</button>' +
        '<button onclick="delEdit('+i+')">Remover</button>' +
      '</div>';
    list.appendChild(item);
  });
}

function moveEdit(i, d) {
  const n = i + d;
  if (n < 0 || n >= S.editBuffer.length) return;
  const t = S.editBuffer[i]; S.editBuffer[i] = S.editBuffer[n]; S.editBuffer[n] = t;
  renderEditList();
}
function dupEdit(i) {
  const copy = structuredClone(S.editBuffer[i]);
  copy.id = 'ex_' + Date.now();
  S.editBuffer.splice(i+1, 0, copy);
  renderEditList();
}
function delEdit(i) {
  S.editBuffer.splice(i, 1);
  renderEditList();
}
function addCustomExercise() {
  S.editBuffer.push({ id: 'ex_'+Date.now(), name: 'Novo exercício', sets: 3, reps: '8–12', load: 0, rest: 90, setsData: [] });
  renderEditList();
}
function restoreOriginal() {
  if (!confirm('Restaurar treino original?')) return;
  const orig = DEFAULT_WORKOUTS[S.active.dow];
  S.editBuffer = structuredClone(orig.exercises);
  renderEditList();
}
function saveEdit() {
  // update active + persistent
  S.active.exercises = S.editBuffer.map(ex => ({
    ...ex,
    setsData: Array(ex.sets).fill(null).map((_,i) => (ex.setsData && ex.setsData[i]) || { done:false, reps:0, load:0 })
  }));
  S.workouts[S.active.dow].exercises = S.editBuffer.map(({setsData, ...rest}) => rest);
  save();
  closeEdit();
  renderActiveExercises();
}
function closeEdit() {
  document.getElementById('edit-overlay').classList.add('hidden');
  S.editBuffer = null;
}

// ==================== POSTURE ====================
function renderPosture() {
  const cont = document.getElementById('posture-list');
  cont.innerHTML = '';
  POSTURE_EXERCISES.forEach(ex => {
    const card = document.createElement('div');
    card.className = 'ex-card';
    card.innerHTML =
      '<div class="ex-name">' + ex.name + '</div>' +
      '<div class="ex-meta">' + ex.sets + ' × ' + ex.reps + ' • ' + ex.instruction + '</div>';
    cont.appendChild(card);
  });
}

function startPostureSession() {
  S.active = {
    dow: -1,
    workoutId: 'posture',
    name: 'Rotina de Postura',
    type: 'posture',
    icon: '🧍',
    exercises: POSTURE_EXERCISES.map(ex => ({
      ...ex,
      setsData: Array(ex.sets).fill(null).map(() => ({ done:false, reps:0, load:0 }))
    })),
    startedAt: Date.now()
  };
  document.getElementById('active-title').textContent = '🧍 Rotina de Postura';
  document.getElementById('active-sub').textContent = 'Mobilidade';
  renderActiveExercises();
  navTo('active');
}

// ==================== HABITS ====================
function renderHabits() {
  const key = todayKey();
  const day = ensureDay(key);
  const cont = document.getElementById('habits-content');

  cont.innerHTML =
    // Skin care
    '<div class="card habit-section"><h3>🧴 Skin Care</h3>' +
    habitCheck('Limpeza facial', day.habits.skincare_clean, () => { day.habits.skincare_clean=!day.habits.skincare_clean; save(); renderHabits(); }) +
    habitCheck('Hidratante facial', day.habits.skincare_moist, () => { day.habits.skincare_moist=!day.habits.skincare_moist; save(); renderHabits(); }) +
    habitCheck('Protetor solar', day.habits.skincare_spf, () => { day.habits.skincare_spf=!day.habits.skincare_spf; save(); renderHabits(); }) +
    '</div>' +

    // Water
    '<div class="card habit-section"><h3>💧 Hidratação — Meta 2 L</h3>' +
    '<div style="font-size:1.3rem;font-weight:800;color:var(--purple2)">' + day.water + ' ml / 2000 ml</div>' +
    '<div class="water-bar"><div class="water-fill" style="width:' + Math.min(100, day.water/20) + '%"></div></div>' +
    (day.water >= 2000 ? '<p style="color:var(--success);font-weight:600;margin-top:8px">Meta de água concluída ✓</p>' : '') +
    '<div class="water-btns">' +
      '<button onclick="addWater(250)">+250 ml</button>' +
      '<button onclick="addWater(500)">+500 ml</button>' +
      '<button onclick="addWater(750)">+750 ml</button>' +
      '<button onclick="addWaterCustom()">Outro</button>' +
    '</div></div>' +

    // Sleep
    '<div class="card habit-section"><h3>😴 Sono — Meta 8 h</h3>' +
    '<div style="font-size:1.3rem;font-weight:800;color:var(--purple2)">' + (day.sleep||0) + ' h / 8 h</div>' +
    '<div class="water-bar"><div class="water-fill" style="width:' + Math.min(100, (day.sleep||0)/8*100) + '%"></div></div>' +
    '<div class="water-btns">' +
      '<button onclick="setSleep(6)">6h</button>' +
      '<button onclick="setSleep(7)">7h</button>' +
      '<button onclick="setSleep(7.5)">7h30</button>' +
      '<button onclick="setSleep(8)">8h</button>' +
      '<button onclick="setSleep(9)">9h</button>' +
    '</div></div>' +

    // Food
    '<div class="card habit-section"><h3>🥗 Alimentação</h3>' +
    habitCheck('Fiz refeições completas', day.habits.food_meals, () => { day.habits.food_meals=!day.habits.food_meals; save(); renderHabits(); }) +
    habitCheck('Comi frutas/vegetais', day.habits.food_veggies, () => { day.habits.food_veggies=!day.habits.food_veggies; save(); renderHabits(); }) +
    habitCheck('Consumi fontes de proteína', day.habits.food_protein, () => { day.habits.food_protein=!day.habits.food_protein; save(); renderHabits(); }) +
    habitCheck('Reduzi ultraprocessados', day.habits.food_less_processed, () => { day.habits.food_less_processed=!day.habits.food_less_processed; save(); renderHabits(); }) +
    '</div>' +

    // Posture
    '<div class="card habit-section"><h3>🧍 Postura</h3>' +
    habitCheck('Fiz minha rotina de postura', day.habits.posture, () => { day.habits.posture=!day.habits.posture; save(); renderHabits(); }) +
    '</div>';
}

function habitCheck(label, done, fn) {
  return '<div class="check-item ' + (done?'done':'') + '" onclick="('+fn.toString()+')()">' +
    '<div class="check-box"></div><span class="check-label">' + label + '</span></div>';
}

function addWater(ml) {
  const day = ensureDay(todayKey());
  day.water = Math.min(4000, day.water + ml);
  save();
  renderHabits();
}
function addWaterCustom() {
  const v = prompt('Quantidade em ml:', '300');
  if (v) addWater(parseInt(v) || 0);
}
function setSleep(h) {
  const day = ensureDay(todayKey());
  day.sleep = h;
  save();
  renderHabits();
}

// ==================== SESSIONS ====================
function renderSessions() {
  const list = document.getElementById('sessions-list');
  const filter = S.sessionFilter;
  let items = S.sessions;
  if (filter !== 'all') items = items.filter(s => s.type === filter);

  if (items.length === 0) {
    list.innerHTML = '<p style="text-align:center;color:var(--muted);padding:40px 0">Nenhuma sessão registrada ainda.</p>';
    return;
  }
  list.innerHTML = '';
  items.forEach(s => {
    const el = document.createElement('div');
    el.className = 'session-item';
    el.innerHTML =
      '<div><div class="session-date">' + formatDateShort(new Date(s.date+'T12:00:00')) + '</div>' +
      '<div class="session-name">' + s.icon + ' ' + s.name + '</div></div>' +
      '<div class="session-badge">Concluído</div>';
    el.onclick = () => showSessionDetail(s);
    list.appendChild(el);
  });
}

function filterSessions(f) {
  S.sessionFilter = f;
  document.querySelectorAll('#session-filters .chip').forEach(c => {
    c.classList.toggle('active', c.dataset.filter === f);
  });
  renderSessions();
}

function showSessionDetail(s) {
  let html = '<h3 style="color:var(--text);margin-bottom:8px">' + s.icon + ' ' + s.name + '</h3>';
  html += '<p style="color:var(--muted);margin-bottom:16px">' + formatDateShort(new Date(s.date+'T12:00:00')) + ' • ' + s.duration + ' min • ' + s.setsDone + ' séries</p>';
  s.exercises.forEach(ex => {
    const done = (ex.setsData||[]).filter(x=>x.done).length;
    html += '<div class="ex-card" style="margin-bottom:8px"><div class="ex-name">' + ex.name + '</div>';
    html += '<div class="ex-meta">' + done + '/' + ex.sets + ' séries</div>';
    (ex.setsData||[]).forEach((set,i) => {
      if (set.done) html += '<div class="set-log">S' + (i+1) + ': ' + (set.reps||'-') + (set.load?' @'+set.load+'kg':'') + '</div>';
    });
    html += '</div>';
  });
  document.getElementById('session-detail-body').innerHTML = html;
  document.getElementById('session-detail-overlay').classList.remove('hidden');
}

function closeSessionDetail() {
  document.getElementById('session-detail-overlay').classList.add('hidden');
}

// ==================== STATS ====================
function renderStats() {
  let completedDays = 0, waterDays = 0, sleepDays = 0, skinDays = 0, postureSessions = 0;
  Object.entries(S.daily).forEach(([k,d]) => {
    if (isDayComplete(k)) completedDays++;
    if (d.water >= 2000) waterDays++;
    if (d.sleep >= 7.5) sleepDays++;
    if (d.habits && d.habits.skincare_clean && d.habits.skincare_moist && d.habits.skincare_spf) skinDays++;
  });
  postureSessions = S.sessions.filter(s => s.type === 'posture').length;
  const trainSessions = S.sessions.filter(s => s.type !== 'posture' && s.type !== 'rest').length;

  const cont = document.getElementById('stats-content');
  cont.innerHTML =
    '<div class="stat-grid">' +
      '<div class="stat-box"><div class="num">' + dayNumber() + '/101</div><div class="lbl">Dia atual</div></div>' +
      '<div class="stat-box"><div class="num">' + completedDays + '</div><div class="lbl">Dias completos</div></div>' +
      '<div class="stat-box"><div class="num">' + trainSessions + '</div><div class="lbl">Treinos</div></div>' +
      '<div class="stat-box"><div class="num">' + postureSessions + '</div><div class="lbl">Sessões postura</div></div>' +
      '<div class="stat-box"><div class="num">' + skinDays + '</div><div class="lbl">Dias skin care</div></div>' +
      '<div class="stat-box"><div class="num">' + waterDays + '</div><div class="lbl">Dias meta água</div></div>' +
      '<div class="stat-box"><div class="num">' + sleepDays + '</div><div class="lbl">Dias 8h sono</div></div>' +
      '<div class="stat-box"><div class="num">' + S.sessions.length + '</div><div class="lbl">Total sessões</div></div>' +
    '</div>' +
    '<div class="card"><p style="color:var(--muted);font-size:0.85rem">Progresso baseado em consistência, hábitos e sessões — sem métricas de peso ou aparência.</p></div>';
}

// ==================== SETTINGS ====================
function renderSettings() {
  const cont = document.getElementById('settings-content');
  cont.innerHTML =
    '<div class="setting-group"><h3>Perfil</h3>' +
    '<div class="setting-row"><label>Nome / apelido</label>' +
    '<input style="background:var(--elevated);border:1px solid var(--border);border-radius:8px;padding:8px 12px;color:var(--text);width:140px" value="' + (S.profile.name||'') + '" onchange="S.profile.name=this.value;save()"></div></div>' +

    '<div class="setting-group"><h3>Descanso padrão</h3>' +
    '<div class="rest-presets">' +
      [30,45,60,90,120].map(s =>
        '<button class="' + (S.settings.restDefault===s?'active':'') + '" onclick="S.settings.restDefault='+s+';save();renderSettings()">' + s + 's</button>'
      ).join('') +
    '</div></div>' +

    '<div class="setting-group"><h3>Preferências</h3>' +
    '<div class="setting-row"><label>Som / vibração do cronômetro</label>' +
    '<div class="toggle ' + (S.settings.sound?'on':'') + '" onclick="S.settings.sound=!S.settings.sound;save();renderSettings()"></div></div>' +
    '<div class="setting-row"><label>Tema</label><span style="color:var(--purple2)">Preto + Roxo</span></div>' +
    '</div>' +

    '<div class="setting-group"><h3>Dados</h3>' +
    '<button class="btn-ghost full" style="width:100%;margin-bottom:8px" onclick="if(confirm(\'Limpar todas as sessões?\')){S.sessions=[];save();alert(\'Sessões limpas\')}">Limpar sessões</button>' +
    '<button class="btn-ghost full" style="width:100%;color:var(--danger);border-color:rgba(239,68,68,0.4)" onclick="if(confirm(\'Resetar TODOS os dados do projeto?\')){localStorage.removeItem(\'projeto101_v1\');location.reload()}">Resetar app</button>' +
    '</div>' +

    '<div class="card" style="text-align:center;margin-top:20px">' +
    '<p style="font-weight:700;color:var(--purple2)">PROJETO 101</p>' +
    '<p style="font-size:0.8rem;color:var(--muted);margin-top:4px">21/09/2026 — 30/12/2026</p>' +
    '</div>';
}

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', () => {
  load();
  renderHome();
});
