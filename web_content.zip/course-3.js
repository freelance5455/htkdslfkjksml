/* JOSTECH — MANUEL 03 : DÉVELOPPEMENT WEB ET MOBILE */
registerDisciplineLevels(3, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "HTML5 sémantique, Modèle de Boîte CSS3, Flexbox et conception Mobile-First.",
    chapters: [{
      id: "web-1-1",
      title: "Chapitre 1 : Fondamentaux du Web (HTML5 & CSS3)",
      lessons: [
        {
          id: "web-1-1-1",
          title: "Leçon 1 : HTML5 Sémantique et Structure d'un Document",
          duration: "25 min",
          objectives: [
            "Comprendre la séparation des rôles : HTML (structure), CSS (style), JS (logique).",
            "Utiliser correctement les balises sémantiques (<header>, <nav>, <main>, <article>, <footer>).",
            "Mesurer l'impact de la sémantique sur l'accessibilité et le référencement (SEO)."
          ],
          prerequisites: ["Notions de fichiers et d'arborescence informatique."],
          sections: [
            {
              type: "definition",
              term: "HTML5 (HyperText Markup Language)",
              text: "HTML n'est pas un langage de programmation (il ne fait ni boucles ni calculs), mais un langage de balisage structurel. Il décrit le sens logique de chaque morceau de contenu d'une page Web pour le navigateur."
            },
            {
              type: "theory",
              title: "1. Pourquoi la sémantique est-elle exigée à l'université ?",
              text: "Un débutant met des balises <div> partout. Un ingénieur Web utilise des balises sémantiques qui expriment clairement le rôle de chaque zone.\n\nCela apporte deux avantages majeurs : les moteurs de recherche (Google) comprennent immédiatement le sujet principal de votre site (meilleur référencement SEO), et les lecteurs d'écran utilisés par les personnes malvoyantes peuvent naviguer directement vers le menu ou l'article principal."
            },
            {
              type: "table",
              title: "Balises sémantiques essentielles",
              headers: ["Balise", "Signification et usage"],
              rows: [
                ["<header>", "En-tête du site ou d'une section (logo, titre, barre de navigation)."],
                ["<nav>", "Zone regroupant les liens de navigation principaux."],
                ["<main>", "Contenu principal et unique de la page."],
                ["<article>", "Contenu autonome et réutilisable (ex: une leçon JOSTECH, un article)."],
                ["<footer>", "Pied de page (mentions légales, auteur, copyright)."]
              ]
            },
            {
              type: "code",
              lang: "HTML5 — Squelette professionnel",
              code: [
                "<!DOCTYPE html>",
                "<html lang='fr'>",
                "<head>",
                "  <meta charset='UTF-8'>",
                "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>",
                "  <title>Cours JOSTECH</title>",
                "</head>",
                "<body>",
                "  <header><h1>JOSTECH</h1></header>",
                "  <main>",
                "    <article>",
                "      <h2>Introduction au Web</h2>",
                "      <p>Apprendre, comprendre, innover.</p>",
                "    </article>",
                "  </main>",
                "  <footer><p>© JOSTECH Université Numérique</p></footer>",
                "</body>",
                "</html>"
              ].join("\n")
            }
          ],
          exercise: {
            question: "1) À quoi sert la balise <meta name='viewport' content='width=device-width, initial-scale=1.0'> ?\n2) Pourquoi ne doit-on jamais utiliser des balises <h1> uniquement pour grossir du texte ?",
            solution: "1) Elle indique au navigateur mobile d'adapter la largeur de la page à l'écran réel du smartphone (sinon le site apparaît minuscule et dézoomé).\n2) Parce que <h1> définit le titre principal hiérarchique du document pour l'accessibilité et Google ; pour grossir un texte ordinaire, on utilise CSS (font-size)."
          },
          summary: "HTML5 structure sémantiquement l'information. Un document propre sépare strictement le sens (HTML) de la mise en forme (CSS).",
          references: ["W3C — HTML5 Specification.", "MDN Web Docs — Éléments HTML sémantiques."]
        },
        {
          id: "web-1-1-2",
          title: "Leçon 2 : Box Model CSS3, Flexbox et Design Mobile-First",
          duration: "25 min",
          objectives: [
            "Maîtriser les 4 couches du Modèle de Boîte (content, padding, border, margin).",
            "Comprendre l'utilité de box-sizing: border-box.",
            "Aligner des composants proprement avec Flexbox."
          ],
          prerequisites: ["Leçon 1 — HTML5."],
          sections: [
            {
              type: "theory",
              title: "1. Tout élément HTML est un rectangle (Box Model)",
              text: "En CSS, chaque balise génère une boîte rectangulaire composée de 4 couches concentriques : le contenu au centre (content), la marge intérieure (padding), la bordure (border) et la marge extérieure qui la sépare des voisines (margin).\n\nPar défaut, si vous fixez width: 100% plus un padding de 20px, la boîte déborde de l'écran ! C'est pourquoi tout projet professionnel commence par * { box-sizing: border-box; } afin que le padding reste inclus à l'intérieur de la largeur."
            },
            {
              type: "definition",
              term: "Approche Mobile-First et Flexbox",
              text: "Mobile-First consiste à concevoir d'abord l'interface pour les petits écrans de smartphones (colonne simple, boutons faciles à toucher), puis à enrichir la grille sur tablette et PC via des @media queries.\nFlexbox (display: flex) permet d'aligner facilement des éléments horizontalement ou verticalement sans calculs complexes."
            },
            {
              type: "code",
              lang: "CSS3 — Carte responsive moderne",
              code: [
                "* { box-sizing: border-box; }",
                "",
                ".barre-haut {",
                "  display: flex;",
                "  justify-content: space-between; /* Espace entre gauche et droite */",
                "  align-items: center;            /* Centrage vertical */",
                "  padding: 12px 16px;",
                "  border-bottom: 1px solid #2b3445;",
                "}",
                "",
                "@media (min-width: 768px) {",
                "  .grille-cours { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }",
                "}"
              ].join("\n")
            }
          ],
          exercise: {
            question: "Une carte possède width: 300px, padding: 20px (gauche et droite), border: 2px et box-sizing: border-box. Quelle est sa largeur totale réelle à l'écran ?",
            solution: "Grâce à box-sizing: border-box, la largeur totale reste exactement 300px (le padding et la bordure sont absorbés vers l'intérieur)."
          },
          summary: "Maîtriser box-sizing: border-box, le Box Model et Flexbox/Grid permet de créer des interfaces élégantes sur Android comme sur grand écran.",
          references: ["MDN Web Docs — CSS Layout & Flexbox."]
        }
      ]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "JavaScript moderne, manipulation du DOM, requêtes asynchrones et sécurité Front-end.",
    chapters: [{
      id: "web-2-1",
      title: "Chapitre 2 : JavaScript Interactif, DOM et Sécurité XSS",
      lessons: [{
        id: "web-2-1-1",
        title: "Leçon 1 : Manipulation du DOM, Fetch et Protection XSS",
        duration: "25 min",
        objectives: [
          "Sélectionner et modifier dynamiquement des nœuds du DOM.",
          "Comprendre la programmation asynchrone avec fetch() et async/await.",
          "Prévenir les failles de sécurité XSS côté client."
        ],
        prerequisites: ["Niveau 1 Web et bases d'algorithmique."],
        sections: [
          {
            type: "definition",
            term: "DOM (Document Object Model)",
            text: "Lorsque le navigateur lit votre fichier HTML, il construit en RAM une arborescence d'objets appelée DOM. JavaScript peut lire, modifier ou créer de nouvelles balises dans cet arbre en temps réel sans recharger la page."
          },
          {
            type: "theory",
            title: "1. Asynchronisme et API Fetch",
            text: "Quand une application Web demande des cours ou des notes à un serveur distant, la réponse prend parfois 200 millisecondes. Pour ne pas geler tout l'écran pendant l'attente, JavaScript utilise des fonctions asynchrones (async / await) avec fetch(), qui attendent la réponse en arrière-plan."
          },
          {
            type: "code",
            lang: "JavaScript — Événements et Fetch",
            code: [
              "const btn = document.querySelector('#btn-charger');",
              "const zone = document.querySelector('#resultat');",
              "",
              "btn.addEventListener('click', async () => {",
              "  zone.textContent = 'Chargement en cours...';",
              "  try {",
              "    const reponse = await fetch('https://api.exemple.org/cours');",
              "    const donnees = await reponse.json();",
              "    zone.textContent = donnees.titre;",
              "  } catch (err) {",
              "    zone.textContent = 'Mode hors ligne actif.';",
              "  }",
              "});"
            ].join("\n")
          },
          {
            type: "example",
            title: "Sécurité : Faille XSS (Cross-Site Scripting)",
            text: "Si un étudiant inscrit son nom comme '<script>volerCompte()</script>' et que votre code écrit element.innerHTML = nom, le navigateur exécutera le code pirate ! En utilisant toujours element.textContent = nom (ou une fonction d'échappement comme escapeHtml), les caractères < et > sont affichés comme du simple texte inoffensif."
          }
        ],
        exercise: {
          question: "Pourquoi encadre-t-on toujours un appel await fetch(...) par un bloc try { ... } catch (err) { ... } sur mobile ?",
          solution: "Parce que sur smartphone, la connexion Internet peut couper à tout moment. Le bloc catch intercepte l'erreur réseau proprement pour afficher un message clair (ou basculer hors ligne) au lieu de faire planter l'application."
        },
        summary: "JavaScript anime le DOM, communique en asynchrone avec les serveurs via fetch()/JSON et doit toujours neutraliser les entrées utilisateurs (textContent) contre les attaques XSS.",
        references: ["Haverbeke, M. — Eloquent JavaScript (4th Ed.)."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Architecture Client-Serveur, API REST, JWT et Applications Multiplateformes (PWA).",
    chapters: [{
      id: "web-3-1",
      title: "Chapitre 3 : API REST, Authentification et PWA",
      lessons: [{
        id: "web-3-1-1",
        title: "Leçon 1 : Principes des API REST et Architecture PWA",
        duration: "30 min",
        objectives: [
          "Maîtriser les méthodes HTTP et les codes de réponse normalisés.",
          "Comprendre l'authentification sans état par jetons (JWT).",
          "Concevoir une Progressive Web App (PWA) fonctionnant sur Web et Android."
        ],
        prerequisites: ["JavaScript intermédiaire (fetch et JSON)."],
        sections: [
          {
            type: "theory",
            title: "1. Architecture REST (Representational State Transfer)",
            text: "Définie par Roy Fielding en 2000, l'architecture REST sépare totalement l'interface (Front-end Web ou Mobile) de la base de données (Back-end). Les deux dialoguent via HTTP/HTTPS en s'échangeant des données légères au format JSON. Grâce à cette séparation, un même serveur alimente simultanément votre site Web, votre app Android et votre app iOS."
          },
          {
            type: "table",
            title: "Standard HTTP d'une API REST",
            headers: ["Verbe HTTP", "Opération CRUD", "Codes de réponse courants"],
            rows: [
              ["GET", "Read (Lire une ressource)", "200 OK | 404 Not Found"],
              ["POST", "Create (Créer / Envoyer)", "201 Created | 400 Bad Request"],
              ["PUT / PATCH", "Update (Mettre à jour)", "200 OK | 403 Forbidden"],
              ["DELETE", "Delete (Supprimer)", "204 No Content | 401 Unauthorized"]
            ]
          },
          {
            type: "definition",
            term: "PWA (Progressive Web App) et Service Worker",
            text: "Une PWA réunit trois technologies clés :\n1) HTTPS obligatoire pour la sécurité.\n2) Un fichier manifest.json décrivant le nom, l'icône et les couleurs de l'app pour l'installation sur l'écran d'accueil Android/iOS.\n3) Un Service Worker : un script tournant en arrière-plan qui intercepte les requêtes réseau, met les cours en cache et permet de continuer à étudier même sans connexion Internet !"
          },
          {
            type: "example",
            title: "Étude de cas : Écosystème JOSTECH",
            text: "JOSTECH adopte exactement cette architecture : une interface légère optimisée mobile, un stockage local pour la lecture hors ligne, et (en Phase 4) une API REST sécurisée (Supabase/PostgreSQL) pour synchroniser les comptes apprenants, les notes sur 20 et l'administration dynamique des cours."
          }
        ],
        exercise: {
          question: "Lors d'un examen officiel JOSTECH, un étudiant non connecté tente d'envoyer une requête POST /api/examens. Un autre étudiant connecté tente d'envoyer DELETE /api/cours/1 (action réservée à l'admin).\nQuels codes HTTP exacts le serveur doit-il renvoyer à chacun ?",
          solution: "1) À l'étudiant non connecté : 401 Unauthorized (authentification requise).\n2) À l'étudiant connecté mais sans droits d'administrateur : 403 Forbidden (permissions insuffisantes)."
        },
        summary: "Les API REST découplent proprement l'interface des données en JSON, et les PWA transforment une base Web unique en véritable application mobile installable et résiliente hors ligne.",
        references: [
          "Fielding, R. (2000) — Architectural Styles and the Design of Network-based Software Architectures.",
          "Google Web.dev — Progressive Web Apps Architecture."
        ]
      }]
    }]
  }
});