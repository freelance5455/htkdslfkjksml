AVRIX Shopping App — Starter Prototype

WHAT IS INCLUDED
- Responsive shopping storefront inspired by common marketplace layouts
- Product search and category filters
- Sample products
- Add to cart and demo checkout
- Local admin form to add products

IMPORTANT LIMITATIONS
This is a front-end prototype, not a live marketplace or installable APK.
Products and cart are saved only in the browser on the same device.
Demo checkout does NOT send orders to you, process payments, or securely store customer details.
Do not use it to collect real customer data.

HOW TO PREVIEW ON ANDROID
1. Extract AVRIX_App.zip.
2. Open index.html in Chrome (or upload the folder to a static website host).
3. To make a real APK, this project needs an Android wrapper (such as Capacitor), Android build tools, app signing, and testing.
4. Before real sales, add a secure backend, product image storage, order notifications, privacy policy, and safe handling of customer information.

Brand: AVRIX
Tagline: YOUR SHOPPING WORLD
