APK বানানোর নিয়ম (কম্পিউটারে কিছু install করা লাগবে না):
1. github.com এ একটা নতুন repository খুলুন।
2. এই ফোল্ডারের সব ফাইল (লুকানো .github ফোল্ডারসহ) repository তে upload করুন।
3. Actions ট্যাবে গিয়ে "Build APK" শেষ হওয়া পর্যন্ত ২-৫ মিনিট অপেক্ষা করুন।
4. শেষ হলে ওই run খুলে নিচে Artifacts থেকে baby-feed-reminder-apk ডাউনলোড করুন, zip খুললে app-debug.apk পাবেন।
5. ফোনে APK install করুন (Unknown sources allow করতে হবে), তারপর notification ও exact alarm permission দিন।
