// ينسخ ملفات الويب فقط إلى مجلد www الذي يقرأه Capacitor
const fs=require('fs'),path=require('path');
const out=path.join(__dirname,'..','www');fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out,{recursive:true});
for(const f of ['index.html','manifest.webmanifest','service-worker.js'])fs.copyFileSync(path.join(__dirname,'..',f),path.join(out,f));
fs.cpSync(path.join(__dirname,'..','assets'),path.join(out,'assets'),{recursive:true});
console.log('www ready');
