/* classes.js — المدارس (معلومات) والفصول وروابط واتساب + نقل الحصص + كشف التعارض */
'use strict';
let clsSch=null;
const clsOf=(sid,name)=>D.classes.find(c=>c.school===sid&&c.name===name);
function vCls(){const sid=(clsSch&&sOf(clsSch))?clsSch:curSchool(),s=sOf(sid),list=D.classes.filter(c=>c.school===sid).sort((a,b)=>a.name.localeCompare(b.name,'ar'));
 const fromTT=[...new Set(D.lessons.filter(l=>l.school===sid).map(lab).filter(Boolean))].filter(n=>!clsOf(sid,n));
 return backBtn()+`<h2 class="pane-title">المدارس والفصول</h2>
${multi()?`<div class="chips" style="margin-bottom:12px">${D.schools.map(x=>`<button class="chip ${x.id===sid?'on':''}" onclick="clsSch='${x.id}';render()">${esc(x.name)}</button>`).join('')}</div>`:''}
<div class="card"><h3>معلومات «${esc(s.name)}»</h3><div class="form"><label class="f">العنوان (اختياري)<input value="${esc(s.addr||'')}" onchange="setSchInfo('${sid}','addr',this.value)"></label><label class="f">ملاحظات / هاتف الإدارة<input value="${esc(s.info||'')}" onchange="setSchInfo('${sid}','info',this.value)"></label></div>
<label class="switch"><span><b>مدرسة افتراضية عند فتح التطبيق</b></span><input type="checkbox" ${D.set.defSchool===sid?'checked':''} onchange="setDefSchool('${sid}',this.checked)"><span class="tg"></span></label></div>
<div class="card"><div class="bar" style="justify-content:space-between"><h3 style="margin:0">الفصول والمجموعات (${list.length})</h3><button class="btn sm" onclick="openCls('${sid}')">${ic('plus',16)} فصل</button></div>
${fromTT.length?`<div style="margin-top:10px"><small>أسماء ظهرت في جدولك ولم تُضف كفصول:</small><div class="chips" style="margin-top:6px">${fromTT.map(n=>`<button class="chip" onclick="addClsQuick('${sid}',${JSON.stringify(n).replace(/"/g,'&quot;')})">+ ${esc(n)}</button>`).join('')}</div></div>`:''}
${list.map(c=>{const ok=waLink(c.wa);return `<div class="irow" style="margin-top:12px;align-items:flex-start"><span class="sicon">${ic('school',20)}</span><div style="flex:1"><b>${esc(c.name)}</b>${c.rate!==undefined&&c.rate!==''&&c.rate!==null?` <small>· سعر الحصة ${money(c.rate)}</small>`:''}<br>${c.wa?(ok?tag('رابط واتساب صحيح','var(--ok)'):tag('رابط غير مألوف','var(--warn)')):'<small>بدون رابط واتساب</small>'}${c.note?`<br><small>${esc(c.note)}</small>`:''}</div>${c.wa?`<button class="iconbtn sm" onclick="openWa('${c.id}')" aria-label="فتح واتساب">${ic('whats',20)}</button>`:''}<button class="iconbtn sm" onclick="openCls('${sid}','${c.id}')" aria-label="تعديل">${ic('edit',18)}</button></div>`}).join('')||'<p class="mu" style="margin-top:10px">لا فصول بعد. أضف فصلاً لتربط به رابط واتساب وسعراً خاصاً إن لزم.</p>'}</div>
<small class="mu" style="display:block;line-height:1.9">يُربط الفصل بالحصص عبر الاسم نفسه الذي تكتبه في خانة «الصف / الشعبة» في الجدول (مثال: 7/أ). لا يرسل التطبيق شيئاً إلى المجموعة تلقائياً؛ يفتح واتساب وتؤكد المشاركة بنفسك.</small>`}
EXT.views.cls=vCls;
function setSchInfo(id,k,v){const s=sOf(id);if(s){s[k]=v.trim();save()}}
function setDefSchool(id,on){if(on)D.set.defSchool=id;else delete D.set.defSchool;save();render()}
function addClsQuick(sid,n){D.classes.push({id:uid(),school:sid,name:n,wa:'',rate:'',note:''});save();render()}
function openCls(sid,id){const ex=id&&D.classes.find(x=>x.id===id);M={type:'cls',id:ex?ex.id:null,c:ex?{...ex}:{school:sid,name:'',wa:'',rate:'',note:''}};drawM()}
EXT.sheets.cls=function(){const c=M.c,bad=c.wa&&!waLink(c.wa);return sheetHead(M.id?'تعديل فصل':'فصل جديد',esc(sch(c.school).name))+
`<label class="f" style="margin-top:12px">اسم الفصل / المجموعة<input value="${esc(c.name)}" placeholder="مثال: 7/أ" oninput="M.c.name=this.value"></label>
<label class="f">رابط مجموعة واتساب (اختياري)<input type="url" inputmode="url" dir="ltr" value="${esc(c.wa)}" placeholder="https://chat.whatsapp.com/..." oninput="M.c.wa=this.value.trim()" onchange="drawM()"></label>
${bad?'<small style="color:var(--warn)">الرابط لا يطابق الصيغة المعتادة (https://chat.whatsapp.com/…). يمكنك حفظه إن كنت متأكداً منه.</small>':''}
<label class="f">سعر خاص لحصة هذا الفصل (اختياري)<input type="number" inputmode="decimal" value="${c.rate===undefined||c.rate===null?'':c.rate}" oninput="M.c.rate=this.value"></label>
<label class="f">ملاحظات<input value="${esc(c.note||'')}" oninput="M.c.note=this.value"></label>
<div class="actions"><button class="btn" onclick="saveCls()">حفظ</button><button class="btn ghost" onclick="closeM()">إلغاء</button>${M.id?`<button class="btn ghost danger" onclick="delCls('${M.id}')">${ic('trash',20)} حذف</button>`:''}</div>`};
function saveCls(){const c=M.c,n=(c.name||'').trim();if(!n)return toast('اكتب اسم الفصل');
 if(D.classes.some(x=>x.school===c.school&&x.name===n&&x.id!==M.id))return toast('يوجد فصل بهذا الاسم في المدرسة نفسها');
 const o={...c,name:n,rate:c.rate===''||c.rate===undefined?'':+c.rate||0};
 if(M.id){const i=D.classes.findIndex(x=>x.id===M.id);D.classes[i]={...D.classes[i],...o}}else{o.id=uid();D.classes.push(o)}
 M=null;save();drawM();render();toast('تم حفظ الفصل')}
function delCls(id){const c=D.classes.find(x=>x.id===id);ask('حذف الفصل «'+(c?c.name:'')+'»؟ لن تُحذف حصصك المرتبطة به.','حذف الفصل',()=>{D.classes=D.classes.filter(x=>x.id!==id);save();render()})}
function openWa(id){const c=D.classes.find(x=>x.id===id);if(!c||!c.wa)return;if(!/^https?:\/\//i.test(c.wa))return toast('الرابط غير صالح');openExternal(c.wa)}

/* ---- نقل / مبادلة حصة + كشف تعارض الأوقات بين المدارس ---- */
const _cellSheet0=window.cellSheet;
window.cellSheet=function(){let h=_cellSheet0();if(M.id){M.mvd=M.mvd===undefined?M.day:M.mvd;M.mvp=M.mvp||M.p;const P=D.periods[M.sid];
  h=h.replace('<div class="actions">',`<div class="lbl">نقل هذه الحصة إلى (إن كانت الخانة مشغولة تُبدَّل الحصتان)</div><div class="irow"><select onchange="M.mvd=+this.value">${DAYS.map((d,i)=>`<option value="${i}" ${M.mvd===i?'selected':''}>${d}</option>`).join('')}</select><select onchange="M.mvp=+this.value">${P.map((p,i)=>`<option value="${i+1}" ${M.mvp===i+1?'selected':''}>الحصة ${i+1}</option>`).join('')}</select><button class="btn ghost sm" onclick="moveLesson()">نقل</button></div><div class="actions">`)}return h};
function moveLesson(){const a=D.lessons.find(x=>x.id===M.id);if(!a)return;const d=M.mvd,p=M.mvp,P=D.periods[a.school][p-1];if(!P)return;
 if(d===a.day&&p===a.p)return toast('هذه هي الخانة الحالية نفسها');
 const b=D.lessons.find(x=>x.school===a.school&&x.day===d&&x.p===p&&x.id!==a.id),od=a.day,op=a.p,O=D.periods[a.school][op-1];
 a.day=d;a.p=p;a.start=P.start;a.end=P.end;a.shift=P.start<'12:00'?'m':'e';
 if(b){b.day=od;b.p=op;b.start=O.start;b.end=O.end;b.shift=O.start<'12:00'?'m':'e'}
 audit('move:'+a.id);M=null;save();drawM();render();toast(b?'تم تبديل الحصتين':'تم نقل الحصة')}
function lessonConflicts(sid,days,p){const P=D.periods[sid][p-1],out=[];if(!P)return out;
 days.forEach(d=>D.lessons.forEach(l=>{if(l.school!==sid&&l.day===d&&P.start<l.end&&l.start<P.end)out.push(`${DAYS[d]}: ${sub(l.subject).name} (${sch(l.school).name}) ${fmt(l.start)}-${fmt(l.end)}`)}));return out}
const _saveCell0=window.saveCell;
window.saveCell=function(){if(!M.subject)return _saveCell0();const cf=lessonConflicts(M.sid,[...M.days],M.p);
 if(cf.length){const saved=M;ask('تعارض زمني مع حصص في مدرسة أخرى:\n'+cf.join('\n'),'حفظ رغم التعارض',()=>{M=saved;_saveCell0()});return}
 _saveCell0()};
document.addEventListener('DOMContentLoaded',()=>{});
EXT.boot=EXT.boot||[];EXT.boot.push(()=>{if(D.set.defSchool&&sOf(D.set.defSchool))filt=D.set.defSchool});
