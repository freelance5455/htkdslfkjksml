/* assistant.js — المساعد الذكي: محلي قائم على قواعد واستعلامات على بياناتك، مع واجهة اختيارية لمزوّد خارجي */
'use strict';
const nrm=s=>normDigits(String(s)).replace(/[ً-ٟـ]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').toLowerCase();
const AI_CHAT=[];
const AI_Q=['ما حصصي غدًا؟','ما الحصة التالية؟','ما المهام والامتحانات القادمة؟','ما الواجبات المتأخرة؟','ماذا يجب أن أدرّس هذا الأسبوع؟','ما المواد التي تأخرت في المقرر؟','كم حصة أعطيتها هذا الشهر؟','كم مستحقاتي لكل مدرسة؟','لخص مهام الأسبوع','ما المواعيد التي تتعارض؟'];
const addDays=(n)=>{const d=new Date();d.setDate(d.getDate()+n);return d};
const lessonLine=l=>`• ${fmt(l.start)}–${fmt(l.end)} · ${sub(l.subject).name}${lab(l)?' ('+lab(l)+')':''}${multi()?' — '+sch(l.school).name:''}`;
function aiLessons(d,name){const ds=ymd(d),L=dayLessons(ds).filter(l=>filt==='all'||l.school===filt);
 if(vacOn(ds)&&!L.length)return `${name} (${fd(d)}) عطلة/إجازة مسجّلة، ولا حصص.`;
 if(!L.length)return `لا توجد حصص في جدولك ${name} (${fd(d)}).`;
 return `حصص ${name} — ${fd(d)} (${L.length}):\n`+L.map(lessonLine).join('\n')+(vacOn(ds)?'\nملاحظة: هذا اليوم معلَّم كعطلة/إجازة في إعداداتك.':'')}
function aiNext(){const n=nextUp(),c=currentLesson();let t='';if(c)t+=`الحصة الجارية الآن: ${sub(c.subject).name}${lab(c)?' ('+lab(c)+')':''} حتى ${fmt(c.end)}.\n`;
 if(n)t+=`الحصة القادمة: ${sub(n.l.subject).name}${lab(n.l)?' ('+lab(n.l)+')':''} — ${fd(n.s)} الساعة ${fmt(n.l.start)} (${relTxt(n.s-new Date())})${multi()?' في '+sch(n.l.school).name:''}.`;else if(!c)t+='لا توجد حصص قادمة في جدولك. أضف حصصك أولاً.';return t.trim()}
function evLine(x){const T=EV_TYPES[x.e.type]||EV_TYPES.other;return `• ${T.n}: ${evTitle(x.e)} — ${fd(x.ds)}${x.e.time?' '+fmt(x.e.time):''} (${relTxt(x.st-Date.now())})${x.e.subject?' · '+sub(x.e.subject).name:''}`}
function upcoming(limitDays){const now=Date.now();return D.events.filter(isUp).map(e=>{const ds=nextOcc(e);return{e,ds,st:evStart(e,ds).getTime()}}).filter(x=>!limitDays||x.st-now<limitDays*864e5).sort((a,b)=>a.st-b.st)}
function aiTasks(onlyExam){let L=upcoming();if(onlyExam)L=L.filter(x=>['exam','quiz','oral'].includes(x.e.type));
 return L.length?`القادمة (${L.length}):\n`+L.slice(0,12).map(evLine).join('\n')+(L.length>12?`\n… و${L.length-12} أخرى`:''):'لا توجد مهام أو امتحانات قادمة مسجّلة.'}
function aiLate(){const L=D.events.filter(isLate);let t=L.length?`متأخرة (${L.length}):\n`+L.map(e=>`• ${(EV_TYPES[e.type]||EV_TYPES.other).n}: ${evTitle(e)} — كان موعدها ${fd(e.date)}${e.subject?' · '+sub(e.subject).name:''}`).join('\n'):'لا توجد مهام أو واجبات متأخرة.';return t}
function aiWeekPlan(){const cw=curWeekNo();if(!cw)return 'لم تحدّد بداية العام الدراسي، لذا لا أعرف رقم الأسبوع الحالي. حدّدها من «المقرر والخطة الأسبوعية».';
 const L=D.cur.filter(it=>+it.week===cw&&(filt==='all'||it.school===filt));const wr=weekRange(cw);
 return L.length?`خطة الأسبوع ${cw} (${fd(wr[0])} – ${fd(wr[1])}):\n`+L.map(it=>`• ${sub(it.subject).name}${it.cls?' ('+it.cls+')':''}: ${it.title||it.topics}${it.hw?' — واجب: '+it.hw:''} [${CUR_ST[it.status||'todo']}]`).join('\n'):`لا توجد دروس مخططة للأسبوع ${cw}. أضفها من «المقرر والخطة الأسبوعية».`}
function aiCurLate(){const cw=curWeekNo();if(!cw)return 'لم تحدّد بداية العام الدراسي لأقارن بالخطة.';const L=curLate();if(!L.length)return `لا دروس متأخرة عن الخطة حتى الأسبوع ${cw}.`;
 const by={};L.forEach(it=>{const k=sub(it.subject).name+(it.cls?' ('+it.cls+')':'');(by[k]=by[k]||[]).push(it.week)});
 return `متأخر عن الخطة (الأسبوع الحالي ${cw}):\n`+Object.entries(by).map(([k,w])=>`• ${k}: ${w.length} درس (أسابيع ${w.sort((a,b)=>a-b).join('، ')})`).join('\n')}
function aiCount(q){let a,b,name;const n=new Date();
 if(/اليوم/.test(q)){a=b=ymd(n);name='اليوم'}else if(/الاسبوع/.test(q)){a=ymd(weekStart(n));const e=weekStart(n);e.setDate(e.getDate()+6);b=ymd(e);name='هذا الأسبوع'}else{a=ymd(new Date(n.getFullYear(),n.getMonth(),1));b=ymd(new Date(n.getFullYear(),n.getMonth()+1,0));name='هذا الشهر ('+MON[n.getMonth()]+')'}
 const r=dueBetween(a,b,filt),un=r.by.a+r.by.e+r.by.n+r.by.o;
 return `${name}: أعطيت ${r.by.g} حصة (منها ${r.makeup} تعويضية/إضافية)، غير معطاة ${un}، ملغاة من المدرسة ${r.by.c}.\nالمحتسبة للأجر: ${r.cnt}.`}
function aiMoney(){const n=new Date(),a=ymd(new Date(n.getFullYear(),n.getMonth(),1)),b=ymd(new Date(n.getFullYear(),n.getMonth()+1,0)),cur=D.set.cur||'';
 const lines=D.schools.map(s=>{const m=dueBetween(a,b,s.id),all=dueBetween('','',s.id),paid=payRows('','',s.id).reduce((x,p)=>x+(+p.amount||0),0);return `• ${s.name}: هذا الشهر ${money(m.due)} ${cur} (${m.cnt} حصة) · الإجمالي ${money(all.due)} · المقبوض ${money(paid)} · المتبقي ${money(all.due-paid)}`});
 const tot=D.schools.reduce((x,s)=>x+dueBetween('','',s.id).due,0),tp=payRows('','','all').reduce((x,p)=>x+(+p.amount||0),0);
 const noRate=D.schools.filter(s=>!rateOf(s.id)).map(s=>s.name);
 return `المستحقات (من الحصص المعطاة فعلياً فقط):\n`+lines.join('\n')+`\nالمجموع: مستحق ${money(tot)} · مقبوض ${money(tp)} · متبقٍ ${money(tot-tp)} ${cur}`+(noRate.length?`\nتنبيه: لم تحدّد سعر الحصة لـ: ${noRate.join('، ')}.`:'')}
function aiWeekSummary(){const r=upcoming(7),cw=curWeekNo(),n=new Date(),ws=weekStart(n),we=new Date(ws);we.setDate(we.getDate()+6);
 let t=`ملخص ${fd(ws)} – ${fd(we)}:\n`;t+=r.length?`المهام والمواعيد خلال 7 أيام (${r.length}):\n`+r.map(evLine).join('\n'):'لا مهام خلال 7 أيام.';const lt=D.events.filter(isLate);if(lt.length)t+=`\nمتأخرة: ${lt.length}.`;
 if(cw){const k=D.cur.filter(it=>+it.week===cw).length;t+=`\nدروس الخطة لهذا الأسبوع: ${k}.`}return t}
function aiConflicts(){const out=[];
 for(let d=0;d<5;d++){const L=D.lessons.filter(l=>l.day===d);for(let i=0;i<L.length;i++)for(let j=i+1;j<L.length;j++){const a=L[i],b=L[j];if(a.school!==b.school&&a.start<b.end&&b.start<a.end)out.push(`• ${DAYS[d]}: ${sub(a.subject).name} (${sch(a.school).name} ${fmt(a.start)}–${fmt(a.end)}) ⟷ ${sub(b.subject).name} (${sch(b.school).name} ${fmt(b.start)}–${fmt(b.end)})`)}}
 const up=upcoming(60);for(let i=0;i<up.length;i++)for(let j=i+1;j<up.length;j++){const a=up[i],b=up[j];if(a.ds===b.ds&&a.e.time&&b.e.time&&Math.abs(toMin(a.e.time)-toMin(b.e.time))<60)out.push(`• ${fd(a.ds)}: «${evTitle(a.e)}» (${fmt(a.e.time)}) و«${evTitle(b.e)}» (${fmt(b.e.time)}) متقاربان`)}
 up.forEach(x=>{if(!x.e.time)return;const dow=new Date(x.ds+'T00:00').getDay();D.lessons.filter(l=>l.day===dow&&!vacOn(x.ds)&&toMin(x.e.time)>=toMin(l.start)&&toMin(x.e.time)<toMin(l.end)).forEach(l=>out.push(`• ${fd(x.ds)}: «${evTitle(x.e)}» (${fmt(x.e.time)}) يقع أثناء حصة ${sub(l.subject).name} (${fmt(l.start)}–${fmt(l.end)})`))});
 return out.length?`تعارضات مكتشفة (${out.length}):\n`+out.join('\n'):'لم أجد تعارضات بين مدارسك أو مواعيدك القادمة (60 يوماً).'}
function aiLocal(raw){const q=nrm(raw);
 if(/تعارض|تتعارض|تداخل/.test(q))return aiConflicts();
 if(/مستحق|اجر|راتب|فلوس|مبلغ|دفع|متبقي/.test(q))return aiMoney();
 if(/كم.*حصه|عدد.*حصص|اعطيت/.test(q))return aiCount(q);
 if(/مواد.*(تاخر|متاخر)|تاخر.*(مقرر|خطه|منهج)|متاخر.*(مقرر|خطه)/.test(q))return aiCurLate();
 if(/ماذا.*(ادرس|اعلم)|ادرس.*الاسبوع|خطه.*الاسبوع|درس.*الاسبوع/.test(q))return aiWeekPlan();
 if(/لخص|ملخص/.test(q))return aiWeekSummary();
 if(/واجب.*متاخر|متاخر|فاتني|فات موعد/.test(q))return aiLate();
 if(/امتحان|اختبار|مهام|مهمه|مواعيد|موعد|قادم.*(مهام|امتحان)/.test(q)&&!/حصه|حصص/.test(q))return aiTasks(/امتحان|اختبار/.test(q)&&!/مهام|مواعيد/.test(q));
 if(/تاليه|التاليه|القادمه|القادمة|التالي|الجاريه|الان/.test(q)&&/حصه/.test(q))return aiNext();
 if(/حصص|حصه|جدول/.test(q)){const days=['الاحد','الاثنين','الثلاثاء','الاربعاء','الخميس'];
  if(/بعد غد/.test(q))return aiLessons(addDays(2),'بعد غد');if(/غدا|بكره|بكرا/.test(q))return aiLessons(addDays(1),'غداً');if(/اليوم/.test(q))return aiLessons(new Date(),'اليوم');
  for(let i=0;i<5;i++)if(q.includes(days[i])){const n=new Date(),k=(i-n.getDay()+7)%7,d=addDays(k);return aiLessons(d,(k===0?'اليوم ':'')+'يوم '+WD[i])}
  return aiLessons(new Date(),'اليوم')}
 if(/غدا/.test(q))return aiLessons(addDays(1),'غداً');
 return null}
const AI_HELP='لم أفهم السؤال. أستطيع الإجابة من بياناتك المحفوظة عن: حصص اليوم/غداً/يوم معيّن، الحصة التالية، المهام والامتحانات القادمة، المتأخر، خطة الأسبوع والمقرر المتأخر، عدد الحصص المعطاة، المستحقات لكل مدرسة، التعارضات. جرّب الأسئلة المقترحة أعلاه.';
function aiKey(){try{return localStorage.getItem('tt_ai_key')||''}catch(e){return''}}
async function aiExternal(q,localAns){const a=D.set.ai;if(!a.on||!a.url||!aiKey())return null;
 const ctx=`التاريخ: ${fd(new Date())}. حصص اليوم: ${dayLessons(ymd(new Date())).length}. مهام قادمة: ${upcoming(14).length}.`+(localAns?`\nإجابة محلية مبنية على بيانات المعلم:\n${localAns}`:'');
 const r=await fetch(a.url,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+aiKey()},body:JSON.stringify({model:a.model||undefined,messages:[{role:'system',content:'أنت مساعد لمعلم. أجب بالعربية بإيجاز اعتماداً على السياق المعطى فقط ولا تخترع بيانات.'},{role:'user',content:ctx+'\n\nالسؤال: '+q}]})});
 if(!r.ok)throw new Error('HTTP '+r.status);const j=await r.json();return j&&j.choices&&j.choices[0]&&j.choices[0].message&&j.choices[0].message.content||null}
async function aiAsk(q){q=(q||'').trim();if(!q)return;AI_CHAT.push({r:'u',t:q});let ans=null;
 try{ans=aiLocal(q)}catch(e){console.error(e);ans='حدث خطأ أثناء تحليل بياناتك: '+e.message}
 if(D.set.ai.on&&D.set.ai.url&&aiKey()){if(!D.set.ai.consent){AI_CHAT.push({r:'a',t:'المساعد الخارجي مفعّل لكن لم تؤكد الموافقة على إرسال ملخص الأسئلة والبيانات إلى المزوّد. أكّد من الإعدادات أسفل الصفحة.'});render();return}
  AI_CHAT.push({r:'a',t:ans||AI_HELP,loc:true});render();try{const x=await aiExternal(q,ans);if(x)AI_CHAT.push({r:'a',t:'المساعد الخارجي:\n'+x})}catch(e){AI_CHAT.push({r:'a',t:'تعذر الاتصال بالمساعد الخارجي ('+e.message+'). الإجابة المحلية أعلاه تبقى صحيحة.'})}render();return}
 AI_CHAT.push({r:'a',t:ans||AI_HELP});render();setTimeout(()=>{const m=$('#main');m.scrollTop=m.scrollHeight},30)}
function vAi(){const a=D.set.ai;
 return backBtn()+`<h2 class="pane-title">المساعد الذكي</h2>${schoolSwitch()}
<p class="mu" style="margin-bottom:10px;line-height:1.9">يجيب من بياناتك المحفوظة على هذا الجهاز فقط، ولا يخترع معلومات. إن لم تتوفر بيانات يوضّح ذلك.</p>
<div class="chips" style="margin-bottom:12px">${AI_Q.map((q,i)=>`<button class="chip" style="font-size:.85rem;min-height:38px" onclick="aiAsk(AI_Q[${i}])">${esc(q)}</button>`).join('')}</div>
<div class="chat">${AI_CHAT.map(m=>`<div class="msg ${m.r}">${esc(m.t)}</div>`).join('')||'<div class="msg a">اسألني عن حصصك ومهامك ومستحقاتك.</div>'}</div>
<div class="irow"><input id="ai_q" placeholder="اكتب سؤالك…" onkeydown="if(event.key==='Enter')aiSend()"><button class="btn" onclick="aiSend()">إرسال</button></div>
${AI_CHAT.length?`<button class="btn ghost sm" onclick="AI_CHAT.length=0;render()">مسح المحادثة</button>`:''}
<details class="card" style="margin-top:14px"><summary>مساعد خارجي اختياري (متقدّم)</summary><div style="margin-top:12px"><p class="mu" style="font-size:.88rem;line-height:1.9">معطّل افتراضياً حمايةً للخصوصية. عند التفعيل يُرسل سؤالك مع ملخص مختصر وإجابة التطبيق المحلية إلى العنوان الذي تحدده (واجهة متوافقة مع OpenAI). لا يُضمَّن أي مفتاح في الكود؛ يُحفظ مفتاحك في هذا الجهاز فقط ولا يدخل في النسخ الاحتياطي.</p>
<label class="switch"><b>تفعيل المساعد الخارجي</b><input type="checkbox" ${a.on?'checked':''} onchange="aiCfg('on',this.checked)"><span class="tg"></span></label>
<label class="f">عنوان الخدمة (https://…/v1/chat/completions)<input dir="ltr" value="${esc(a.url)}" onchange="aiCfg('url',this.value.trim())"></label><label class="f">اسم النموذج (اختياري)<input dir="ltr" value="${esc(a.model)}" onchange="aiCfg('model',this.value.trim())"></label>
<label class="f">مفتاح API (يبقى على هذا الجهاز)<input type="password" dir="ltr" value="${aiKey()?'••••••••':''}" onchange="aiSetKey(this.value)"></label>
<label class="switch"><b>أوافق على إرسال الأسئلة وملخص بياناتي إلى هذه الخدمة</b><input type="checkbox" ${a.consent?'checked':''} onchange="aiCfg('consent',this.checked)"><span class="tg"></span></label></div></details>`}
EXT.views.ai=vAi;
function aiSend(){const e=$('#ai_q');if(e&&e.value.trim()){const v=e.value;e.value='';aiAsk(v)}}
function aiCfg(k,v){D.set.ai[k]=v;save();render()}
function aiSetKey(v){if(v==='••••••••')return;try{if(v)localStorage.setItem('tt_ai_key',v);else localStorage.removeItem('tt_ai_key')}catch(e){}toast(v?'تم حفظ المفتاح على هذا الجهاز':'تم حذف المفتاح')}
