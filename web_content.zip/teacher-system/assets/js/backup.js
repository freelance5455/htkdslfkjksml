/* backup.js — نسخ احتياطي كامل (JSON منظّم + الصور)، تحقق، ملخص، دمج/استبدال، نسخة تلقائية قبل الاستعادة */
'use strict';
const APP_ID='teacher-smart-system',SCHEMA=2;
const COLS=[['schools','المدارس'],['subjects','المواد'],['lessons','الحصص'],['classes','الفصول'],['events','المهام والمواعيد'],['pay','الدفعات'],['cur','دروس المقرر'],['cal','التقويم'],['docs','المستندات والسبورات']];
const b2d=b=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=no;r.readAsDataURL(b)});
async function bkCollectFiles(kinds){const out={};try{const all=(await idbAll())||[];for(const f of all){if(!kinds.includes(f.kind)||!f.blob)continue;out[f.id]={kind:f.kind,name:f.name||'',mime:f.blob.type,d:await b2d(f.blob)}}}catch(e){console.error(e)}return out}
async function bkBuild(opt){const o=Object.assign({img:true,media:false},opt),kinds=[];if(o.img)kinds.push('img');if(o.media)kinds.push('sound','font');
 const files=kinds.length?await bkCollectFiles(kinds):{};return {app:APP_ID,schema:SCHEMA,created:new Date().toISOString(),counts:Object.fromEntries(COLS.map(([k])=>[k,(D[k]||[]).length])),data:D,files}}
async function expBackup(opt){try{toast('جارٍ تجهيز النسخة…');const o=await bkBuild(opt||{img:$('#bk_img')?$('#bk_img').checked:true,media:$('#bk_media')?$('#bk_media').checked:false});
 const txt=JSON.stringify(o);dlFile('timetable_backup_'+ymd(new Date())+'.json',txt,'application/json');D.set.lastBackup=Date.now();save();toast('تم تنزيل النسخة ('+(txt.length/1048576).toFixed(1)+' م.ب)');render()}catch(e){console.error(e);toast('تعذر إنشاء النسخة (الذاكرة؟). جرّب بدون الصور.')}}
function expReports(){dlJson('reports_'+ymd(new Date()),{app:APP_ID,schema:SCHEMA,kind:'reports',created:new Date().toISOString(),log:D.log,pay:D.pay,rates:{default:D.set.rate,schools:D.schools.map(s=>({id:s.id,name:s.name,rate:s.rate})),subjects:D.subjects.map(s=>({id:s.id,name:s.name,rate:s.rate})),classes:D.classes.map(c=>({school:c.school,name:c.name,rate:c.rate}))}})}
/* ---- التحقق ---- */
function bkParse(text){let o;try{o=JSON.parse(text)}catch(e){return{err:'الملف ليس JSON صالحاً (قد يكون تالفاً أو غير مكتمل).'}}
 if(!o||typeof o!=='object')return{err:'محتوى الملف غير مفهوم.'};
 if(o.kind==='reports')return{err:'هذا ملف تقارير وليس نسخة احتياطية كاملة.'};
 let data,files={},ver;
 if(o.app===APP_ID&&o.data){ver=o.schema;data=o.data;files=o.files||{}}
 else if(Array.isArray(o.lessons)&&Array.isArray(o.schools)){ver=1;data=o}  // نسخة قديمة (v5)
 else return{err:'ليست نسخة احتياطية من هذا التطبيق.'};
 if(typeof ver!=='number'||ver<1)return{err:'إصدار النسخة غير معروف.'};
 if(ver>SCHEMA)return{err:'النسخة أُنشئت بإصدار أحدث من التطبيق (مخطط '+ver+'). حدّث التطبيق أولاً.'};
 for(const k of ['schools','subjects','lessons']){if(!Array.isArray(data[k]))return{err:'النسخة ناقصة: «'+k+'» غير موجود.'}}
 if(!data.schools.length)return{err:'النسخة لا تحتوي أي مدرسة.'};
 for(const l of data.lessons){if(!l||typeof l.day!=='number'||l.day<0||l.day>6||!l.school){return{err:'النسخة تحتوي حصصاً بصيغة غير صالحة.'}}}
 if(data.log&&(typeof data.log!=='object'||Array.isArray(data.log)))return{err:'سجل الحصص بصيغة غير صالحة.'};
 return{data,files,ver,created:o.created||''}}
function bkCounts(data){return Object.fromEntries(COLS.map(([k])=>[k,Array.isArray(data[k])?data[k].length:0]))}
function bkNewCounts(data){const out={};COLS.forEach(([k])=>{const have=new Set((D[k]||[]).map(x=>x.id));out[k]=(Array.isArray(data[k])?data[k]:[]).filter(x=>x&&x.id&&!have.has(x.id)).length});
 let nl=0,tot=0;Object.entries(data.log||{}).forEach(([ds,day])=>Object.entries(day).forEach(([id])=>{tot++;if(!(D.log[ds]&&D.log[ds][id]))nl++}));out.log=nl;out.logTot=tot;return out}
/* ---- نسخة تلقائية قبل الاستعادة ---- */
function bkSnapshot(){const s=JSON.stringify({app:APP_ID,schema:SCHEMA,created:new Date().toISOString(),data:D,files:{}});
 try{localStorage.setItem('tt_autobackup',s);return true}catch(e){try{dlFile('auto_backup_before_restore_'+ymd(new Date())+'.json',s,'application/json');return true}catch(e2){return false}}}
function bkHasSnap(){try{return !!localStorage.getItem('tt_autobackup')}catch(e){return false}}
function bkRestoreSnap(){ask('استرجاع النسخة التلقائية التي أُخذت قبل آخر استعادة؟ ستُستبدل بياناتك الحالية.','استرجاع',()=>{try{const o=bkParse(localStorage.getItem('tt_autobackup'));if(o.err)return toast(o.err);D=o.data;norm();save();applyLook();render();toast('تم استرجاع النسخة التلقائية')}catch(e){toast('تعذر الاسترجاع')}})}
/* ---- الاستيراد ---- */
function impFile(inp){const f=inp.files&&inp.files[0];inp.value='';if(!f)return;if(f.size>200*1048576)return toast('الملف كبير جداً');const r=new FileReader();r.onload=()=>impText(String(r.result),f.name);r.onerror=()=>toast('تعذرت قراءة الملف');r.readAsText(f)}
function impText(text,name){const p=bkParse(text);if(p.err)return toast(p.err,null,true);M={type:'bkimp',p,mode:'merge',name:name||'من النص'};drawM()}
EXT.sheets.bkimp=function(){const p=M.p,inc=bkCounts(p.data),nw=bkNewCounts(p.data),cur=bkCounts(D),nf=Object.keys(p.files||{}).length,incLog=nw.logTot;
 return sheetHead('مراجعة النسخة قبل التنفيذ',esc(M.name)+(p.created?' · أُنشئت '+esc(String(p.created).slice(0,10)):'')+' · مخطط '+p.ver)+
`<div class="tw"><table class="rep-t"><tr><th>البيان</th><th>حالياً</th><th>في النسخة</th><th>جديد (يُضاف عند الدمج)</th></tr>${COLS.map(([k,n])=>`<tr><td>${n}</td><td>${cur[k]}</td><td>${inc[k]}</td><td>${nw[k]}</td></tr>`).join('')}<tr><td>سجلات الحصص</td><td>${Object.values(D.log).reduce((a,d)=>a+Object.keys(d).length,0)}</td><td>${incLog}</td><td>${nw.log}</td></tr><tr><td>ملفات (صور/أصوات)</td><td>—</td><td>${nf}</td><td>—</td></tr></table></div>
<div class="lbl">طريقة التنفيذ</div><div class="seg" style="display:flex"><button style="flex:1" class="${M.mode==='merge'?'on':''}" onclick="M.mode='merge';drawM()">دمج (يحتفظ ببياناتك)</button><button style="flex:1" class="${M.mode==='replace'?'on':''}" onclick="M.mode='replace';drawM()">استبدال كامل</button></div>
<p class="mu" style="margin-top:10px;line-height:1.9;font-size:.9rem">${M.mode==='merge'?'الدمج يضيف العناصر غير الموجودة فقط (حسب المعرّف الفريد) ولا يكرّر ولا يستبدل ما لديك. الحصص المتعارضة في الخانة نفسها تُتجاهل، وإعداداتك الحالية تبقى.':'الاستبدال يمحو بياناتك الحالية ويضع محتوى النسخة. تُحفظ نسخة تلقائية من بياناتك الحالية قبل التنفيذ (بلا صور) ويمكنك استرجاعها من صفحة النسخ الاحتياطي.'}</p>
<div class="actions"><button class="btn ${M.mode==='replace'?'danger':''}" onclick="bkApply()">${M.mode==='merge'?'دمج الآن':'استبدال الآن'}</button><button class="btn ghost" onclick="closeM()">إلغاء</button></div>`};
async function bkApply(){const m=M,p=m.p;M=null;drawM();
 if(!bkSnapshot()){toast('تعذر حفظ نسخة تلقائية، أُلغيت العملية حمايةً لبياناتك');return}
 const backup=JSON.parse(JSON.stringify(D));let nf=0;
 try{
  if(m.mode==='replace'){const nd=JSON.parse(JSON.stringify(p.data));D=nd;norm()}
  else{const inc=JSON.parse(JSON.stringify(p.data)),stats={};
   COLS.forEach(([k])=>{const have=new Set((D[k]||[]).map(x=>x.id));let n=0;(inc[k]||[]).forEach(x=>{if(!x||!x.id||have.has(x.id))return;
     if(k==='lessons'&&D.lessons.some(l=>l.school===x.school&&l.day===x.day&&l.p===x.p)){stats.skipLessons=(stats.skipLessons||0)+1;return}
     if(k==='pay'&&D.pay.some(q=>q.date===x.date&&+q.amount===+x.amount&&q.school===x.school&&q.method===x.method&&q.note===x.note)){return}
     D[k].push(x);n++});stats[k]=n});
   Object.entries(inc.periods||{}).forEach(([sid,per])=>{if(!D.periods[sid])D.periods[sid]=per});
   Object.entries(inc.log||{}).forEach(([ds,day])=>Object.entries(day).forEach(([id,r])=>{D.log[ds]=D.log[ds]||{};if(!D.log[ds][id])D.log[ds][id]=r}));
   const from=inc.set&&inc.set.logFrom;if(from&&(!D.set.logFrom||from<D.set.logFrom))D.set.logFrom=from;
   norm();m.stats=stats}
  for(const[id,f]of Object.entries(p.files||{})){try{const have=await idbGet(id);if(have&&m.mode==='merge')continue;const blob=await (await fetch(f.d)).blob();await idbPut({id,kind:f.kind,name:f.name,blob});nf++}catch(e){console.error(e)}}
  await loadFiles();save();audit('restore:'+m.mode);applyLook();render();
  toast(m.mode==='merge'?'تم الدمج بنجاح'+(m.stats&&m.stats.skipLessons?` (تجوهلت ${m.stats.skipLessons} حصة متعارضة)`:''):'تم استبدال البيانات بنجاح')}
 catch(e){console.error(e);D=backup;norm();save();render();toast('فشل التنفيذ؛ أُعيدت بياناتك كما كانت',null,true)}}
function paneBackup(){const last=D.set.lastBackup,days=last?Math.floor((Date.now()-last)/864e5):null;
 return `<h2 class="pane-title">النسخ الاحتياطي والاستعادة</h2>
<div class="card"><p class="mu" style="margin-bottom:12px;line-height:1.9">بياناتك محفوظة على هذا الجهاز فقط. حذف بيانات المتصفح/التطبيق أو إعادة تثبيته أو تغيير الهاتف قد يفقدها نهائياً ما لم تحتفظ بنسخة احتياطية.${last?`<br><b>آخر نسخة: قبل ${days===0?'اليوم':days+' يوماً'}</b>`:'<br><b style="color:var(--warn)">لم تأخذ نسخة احتياطية بعد.</b>'}</p>
<label class="switch"><b>تضمين الصور (المستندات والسبورات)</b><input type="checkbox" id="bk_img" checked><span class="tg"></span></label>
<label class="switch"><span><b>تضمين الأصوات والخطوط المرفوعة</b><br><small>قد يكبّر الملف كثيراً</small></span><input type="checkbox" id="bk_media"><span class="tg"></span></label>
<div class="bar" style="margin-top:12px"><button class="btn" onclick="expBackup()">${ic('down',20)} تنزيل نسخة احتياطية</button><button class="btn ghost" onclick="$('#bkfile').click()">${ic('upl',20)} استيراد من ملف</button></div><input type="file" id="bkfile" accept=".json,application/json" hidden onchange="impFile(this)"></div>
<div class="card"><h3>إدارة النسخ</h3><div class="bar"><button class="btn ghost sm" onclick="expReports()">${ic('chart',16)} تصدير السجلات والدفعات فقط (JSON)</button>${bkHasSnap()?`<button class="btn ghost sm" onclick="bkRestoreSnap()">${ic('undo',16)} استرجاع النسخة التلقائية الأخيرة</button>`:''}</div>
<small style="display:block;margin-top:8px">قبل كل استبدال/دمج تُحفظ نسخة تلقائية من بياناتك الحالية. لا يُمسح شيء قبل التحقق من صحة الملف.</small></div>
<div class="card"><details><summary style="cursor:pointer;font-weight:800">النسخ واللصق كنص (بديل)</summary><textarea id="bk" rows="5" style="margin-top:12px" placeholder="الصق هنا نص النسخة للاستيراد"></textarea><div class="bar" style="margin-top:10px"><button class="btn ghost sm" onclick="$('#bk').value=JSON.stringify({app:APP_ID,schema:SCHEMA,created:new Date().toISOString(),data:D,files:{}})">عرض بياناتي (بدون صور)</button><button class="btn ghost sm" onclick="impText($('#bk').value)">استيراد من الحقل</button></div></details></div>
<div class="card"><h3 style="color:var(--no)">منطقة الخطر</h3><p class="mu" style="margin-bottom:12px">حذف جميع البيانات: الجداول والحضور والدفعات والمستندات والإعدادات.</p><button class="btn ghost danger" onclick="resetAll()">${ic('trash',20)} حذف كل البيانات</button></div>`}
function resetAll(){ask('سيتم حذف كل بياناتك نهائياً (بما فيها الصور) من هذا الجهاز. تُحفظ نسخة تلقائية نصية أولاً. تأكد من تنزيل نسخة كاملة قبل المتابعة.','حذف كل شيء',async()=>{bkSnapshot();try{for(const f of ((await idbAll())||[]))await idbDel(f.id)}catch(e){}FILES=[];try{localStorage.removeItem(KEY)}catch(e){}D=null;norm();filt='all';sset=null;save();applyLook();render();toast('تم حذف البيانات')})}
