/* ext-core.js — أدوات مشتركة: تصدير (PNG/JPG/PDF/CSV)، طباعة، مشاركة، العطلة وساعات الهدوء */
'use strict';
Object.assign(I,{
 money:'<rect x="3" y="6" width="18" height="12" rx="2.5"/><circle cx="12" cy="12" r="2.6"/><path d="M6.5 9.5v.01M17.5 14.5v.01"/>',
 board:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21l2-4M16 21l-2-4M7 9l3 3 4-5 3 3"/>',
 whats:'<path d="M4 20l1.3-4.2A8 8 0 1 1 8.4 18.8z"/><path d="M9 9c.3 2.6 2.4 4.7 5.3 5.6l1.3-1.3-1.9-1-.9.8c-.9-.4-1.7-1.200-2.100-2.100l.8-.9-1-1.900z"/>',
 robot:'<rect x="4" y="8" width="16" height="11" rx="3"/><path d="M12 8V4M9 13v1M15 13v1M9 17h6"/><circle cx="12" cy="3.500" r="1"/>',
 cam:'<path d="M4 8h3l1.500-2.500h7L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.500"/>',
 pen:'<path d="M4 20l1-4L16.500 4.500a2.100 2.100 0 0 1 3 3L8 19z"/><path d="M14.500 6.500l3 3"/>',
 undo:'<path d="M9 7L4 12l5 5M4 12h11a5 5 0 0 1 0 10h-2"/>',
 redo:'<path d="M15 7l5 5-5 5M20 12H9a5 5 0 0 0 0 10h2"/>',
 share:'<circle cx="18" cy="5.500" r="2.500"/><circle cx="6" cy="12" r="2.500"/><circle cx="18" cy="18.500" r="2.500"/><path d="M8.300 10.800l7.400-4M8.300 13.200l7.400 4"/>',
 search:'<circle cx="11" cy="11" r="6.500"/><path d="M16 16l4.500 4.500"/>',
 alert:'<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>',
 eraser:'<path d="M4 16l9-10 7 6-6 8H8z"/><path d="M8 20h12"/>',
 text:'<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
 rot:'<path d="M20 12a8 8 0 1 1-3-6.200M20 4v5h-5"/>',
 star:'<path d="M12 3l2.800 5.800 6.200.9-4.500 4.400 1.100 6.200L12 17.300 6.400 20.300l1.100-6.200L3 9.700l6.200-.9z"/>'
});

/* ---------- أدوات صغيرة ---------- */
const backBtn=()=>`<button class="back" onclick="go('set')">${ic('prev',18)} المزيد</button>`;
const csvQ=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
function dlCsv(name,rows){dlFile(name+'.csv','﻿'+rows.map(r=>r.map(csvQ).join(',')).join('\r\n'),'text/csv;charset=utf-8');toast('تم تنزيل ملف CSV (يفتح في Excel)')}
function dlJson(name,obj){dlFile(name+'.json',JSON.stringify(obj,null,1),'application/json');toast('تم تنزيل ملف JSON')}
const clip=s=>{try{return navigator.clipboard.writeText(s).then(()=>toast('تم النسخ'),()=>toast('تعذر النسخ'))}catch(e){toast('تعذر النسخ')}};
const todayStr=()=>ymd(new Date());
const inRange=(ds,a,b)=>(!a||ds>=a)&&(!b||ds<=b);
const weekStart=(d=new Date())=>{const x=new Date(d.getFullYear(),d.getMonth(),d.getDate());x.setDate(x.getDate()-((x.getDay()+(7-(D.set.weekStart||0)))%7));return x};
const sOf=id=>D.schools.find(x=>x.id===id);
const tag=(t,c)=>`<span class="tag"${c?` style="background:color-mix(in srgb,${c} 15%,var(--card));color:${c}"`:''}>${esc(t)}</span>`;
function audit(what){try{D.audit.push({t:Date.now(),w:what});if(D.audit.length>300)D.audit.splice(0,D.audit.length-300)}catch(e){}}

/* ---------- الطباعة (تطبع منطقة مخصصة فقط) ---------- */
(function(){const st=document.createElement('style');
 st.textContent='#printarea{display:none}@media print{body.printing>*:not(#printarea){display:none!important}body.printing{display:block!important;height:auto!important;overflow:visible!important;background:#fff!important}body.printing #printarea{display:block;direction:rtl;color:#111;background:#fff;padding:12mm;font-size:13px}#printarea table{width:100%;border-collapse:collapse}#printarea th,#printarea td{border:1px solid #999;padding:5px 7px;text-align:right}#printarea .board{background:#fff!important;border:0}@page{size:A4;margin:8mm}}';
 document.head.appendChild(st);const st2=document.createElement('style');st2.textContent='.sheet p{white-space:pre-line}';document.head.appendChild(st2);const pa=document.createElement('div');pa.id='printarea';document.body.appendChild(pa)})();
function printBlock(html,title){const pa=$('#printarea');pa.innerHTML=`<h1 style="margin:0 0 4px;font-size:22px">${esc(title||'')}</h1><div style="color:#555;margin-bottom:12px">${esc(D.set.teacher||'')} · تاريخ الطباعة: ${fd(new Date())}</div>`+html;
 document.body.classList.add('printing');const done=()=>{document.body.classList.remove('printing');pa.innerHTML='';removeEventListener('afterprint',done)};addEventListener('afterprint',done);
 setTimeout(()=>{try{window.print()}catch(e){toast('الطباعة غير متاحة هنا؛ استخدم تصدير PDF');done()}},80)}

/* ---------- تحويل HTML إلى صورة/PDF (بدون مكتبات خارجية) ---------- */
async function htmlToCanvas(inner,W){
 const wrap=document.createElement('div');wrap.setAttribute('dir','rtl');
 wrap.setAttribute('style','--bg:#fff;--card:#fff;--tx:#101a2e;--mu:#506078;--bd:#d8e0ee;--pr:#2150e0;--pr2:#0f9d96;--ok:#0d7a52;--no:#c4263a;--warn:#b45309;--soft:#eef2fd;width:'+W+'px;background:#fff;color:#101a2e;font:22px "Noto Sans Arabic",Tahoma,Arial,sans-serif;padding:30px;box-sizing:border-box');
 const st=document.createElement('style');st.textContent=document.querySelector('style').textContent;wrap.appendChild(st);
 const box=document.createElement('div');box.innerHTML=inner;wrap.appendChild(box);
 const probe=wrap.cloneNode(true);probe.style.cssText+=';position:fixed;left:-99999px;top:0';document.body.appendChild(probe);
 const H=Math.ceil(probe.getBoundingClientRect().height);probe.remove();
 const svg='<svg xmlns="http://www.w3.org/2000/svg" width="'+W+'" height="'+H+'"><foreignObject x="0" y="0" width="'+W+'" height="'+H+'">'+new XMLSerializer().serializeToString(wrap)+'</foreignObject></svg>';
 const img=new Image();await new Promise((ok,no)=>{img.onload=ok;img.onerror=no;img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)});
 const sc=Math.min(2,Math.sqrt(16e6/(W*H))),cv=document.createElement('canvas');cv.width=Math.round(W*sc);cv.height=Math.round(H*sc);
 const cx=cv.getContext('2d');cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height);cx.drawImage(img,0,0,cv.width,cv.height);return cv}
const blobOf=(cv,type,q)=>new Promise(r=>cv.toBlob(r,type,q));
function dlBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),6000)}
async function exportImage(inner,name,W,type){try{const cv=await htmlToCanvas(inner,W||1100),png=type==='png',b=await blobOf(cv,png?'image/png':'image/jpeg',.93);if(!b)throw 0;dlBlob(b,name+(png?'.png':'.jpg'));toast('تم حفظ الصورة')}catch(e){toast('تعذر تصدير الصورة على هذا المتصفح')}}
/* PDF بسيط: كل صفحة صورة JPEG (يحفظ العربية والاتجاه كما تظهر تماماً؛ النص غير قابل للتحديد) */
async function buildPdf(cv){
 const PW=595,PH=842,pages=[];
 if(Array.isArray(cv)){for(const c of cv){const b=await blobOf(c,'image/jpeg',.9);pages.push({w:c.width,h:c.height,d:new Uint8Array(await b.arrayBuffer())})}}
 else{const sliceH=Math.floor(cv.width*PH/PW);
 for(let y=0;y<cv.height;y+=sliceH){const h=Math.min(sliceH,cv.height-y),c=document.createElement('canvas');c.width=cv.width;c.height=sliceH;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(cv,0,y,cv.width,h,0,0,cv.width,h);
  const b=await blobOf(c,'image/jpeg',.9);pages.push({w:c.width,h:c.height,d:new Uint8Array(await b.arrayBuffer())})}}
 const enc=new TextEncoder(),parts=[],offs=[];let len=0;const put=u=>{const a=typeof u==='string'?enc.encode(u):u;parts.push(a);len+=a.length};
 const n=pages.length,obj=(i,body)=>{offs[i]=len;put(i+' 0 obj\n');put(body);put('\nendobj\n')};
 put('%PDF-1.4\n');
 obj(1,'<</Type/Catalog/Pages 2 0 R>>');
 obj(2,'<</Type/Pages/Count '+n+'/Kids['+pages.map((_,i)=>(3+i*3)+' 0 R').join(' ')+']>>');
 pages.forEach((p,i)=>{const pg=3+i*3,ct=pg+1,im=pg+2,s='q '+PW+' 0 0 '+PH+' 0 0 cm /Im0 Do Q';
  obj(pg,'<</Type/Page/Parent 2 0 R/MediaBox[0 0 '+PW+' '+PH+']/Resources<</XObject<</Im0 '+im+' 0 R>>>>/Contents '+ct+' 0 R>>');
  obj(ct,'<</Length '+s.length+'>>\nstream\n'+s+'\nendstream');
  offs[im]=len;put(im+' 0 obj\n<</Type/XObject/Subtype/Image/Width '+p.w+'/Height '+p.h+'/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length '+p.d.length+'>>\nstream\n');put(p.d);put('\nendstream\nendobj\n')});
 const total=3+n*3,xr=len;put('xref\n0 '+total+'\n0000000000 65535 f \n');
 for(let i=1;i<total;i++)put(String(offs[i]).padStart(10,'0')+' 00000 n \n');
 put('trailer\n<</Size '+total+'/Root 1 0 R>>\nstartxref\n'+xr+'\n%%EOF');
 return new Blob(parts,{type:'application/pdf'})}
async function exportPdf(inner,name,W){try{toast('جارٍ إنشاء PDF…');const b=await buildPdf(await htmlToCanvas(inner,W||1100));dlBlob(b,name+'.pdf');toast('تم إنشاء ملف PDF')}catch(e){console.error(e);toast('تعذر إنشاء PDF على هذا المتصفح؛ جرّب الطباعة ثم «حفظ كـ PDF»')}}
const expHead2=(t,s)=>expHead(t,s||'');
function exportBar(getHtml,getTitle,name,csv){return `<div class="bar noprint" style="margin:10px 0">${csv?`<button class="btn ghost sm" onclick="(${csv})()">${ic('down',16)} CSV</button>`:''}<button class="btn ghost sm" onclick="exportPdf(${getHtml}(),'${name}')">${ic('file',16)} PDF</button><button class="btn ghost sm" onclick="exportImage(${getHtml}(),'${name}',1100,'jpg')">${ic('image',16)} JPG</button><button class="btn ghost sm" onclick="exportImage(${getHtml}(),'${name}',1100,'png')">PNG</button><button class="btn ghost sm" onclick="printBlock(${getHtml}(),${getTitle}())">${ic('print',16)} طباعة</button></div>`}

/* ---------- المشاركة (Web Share + بدائل) ---------- */
async function shareAny({blob,file,text,title}){
 try{const f=file||(blob?new File([blob],'share',{type:blob.type}):null);
  if(f&&navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],title:title||'',text:text||''});return true}
  if(!f&&navigator.share){await navigator.share({title:title||'',text:text||''});return true}}catch(e){if(e&&e.name==='AbortError')return false}
 if(file||blob)dlBlob(file||blob,(file&&file.name)||'share');
 if(text)clip(text);
 toast('المشاركة المباشرة غير مدعومة هنا؛ نُزّل الملف / نُسخ النص. افتح واتساب وأرفقه بنفسك.');return false}
const waLink=u=>{u=String(u||'').trim();return /^https:\/\/(chat\.whatsapp\.com\/[A-Za-z0-9]{10,}|wa\.me\/[0-9+]{6,}.*|api\.whatsapp\.com\/.+)$/i.test(u)};
function openExternal(u){try{if(window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.Browser){Capacitor.Plugins.Browser.open({url:u});return}}catch(e){}window.open(u,'_blank','noopener')}

/* ---------- وضع العطلة وساعات الهدوء ---------- */
EXT.panes.quiet=function(){const s=D.set,q=s.quiet,v=s.vac;
 const sw=(on,fn,t,sub)=>`<label class="switch"><span><b>${t}</b>${sub?`<br><small>${sub}</small>`:''}</span><input type="checkbox" ${on?'checked':''} onchange="${fn}(this.checked)"><span class="tg"></span></label>`;
 return `<h2 class="pane-title">العطلة وساعات الهدوء</h2>
<div class="card"><h3>وضع العطلة</h3>${sw(v.on,'setVacOn','إيقاف تنبيهات الحصص المجدولة','تستمر تنبيهات المواعيد والمهام. اترك التاريخين فارغين ليبقى الوضع مفعّلاً حتى تُلغيه.')}
<div class="form"><label class="f">من تاريخ<input type="date" value="${esc(v.from||'')}" onchange="setVac('from',this.value)"></label><label class="f">إلى تاريخ<input type="date" value="${esc(v.to||'')}" onchange="setVac('to',this.value)"></label></div>
<small>تُستثنى تلقائياً أيام العطل والإجازات المؤكدة في «التقويم المدرسي». أيام الجمعة والسبت خارج الجدول أصلاً.</small></div>
<div class="card"><h3>الكتم وساعات الهدوء</h3>${sw(s.mute,'setMute','كتم كل الأصوات','تظهر التنبيهات نصاً فقط بلا صوت أو اهتزاز')}
${sw(q.on,'setQuietOn','تفعيل ساعات الهدوء','لا صوت ولا اهتزاز في هذه الفترة')}
<div class="form"><label class="f">من<input type="time" value="${esc(q.from)}" onchange="setQuiet('from',this.value)"></label><label class="f">إلى<input type="time" value="${esc(q.to)}" onchange="setQuiet('to',this.value)"></label></div></div>
<div class="card"><h3>تنبيهات إضافية</h3>${sw(s.atStart,'setAtStart','تنبيه عند بداية الحصة')}</div>`};
function setVacOn(v){D.set.vac.on=v;save();render()}
function setVac(k,v){D.set.vac[k]=v;save()}
function setMute(v){D.set.mute=v;save()}
function setQuietOn(v){D.set.quiet.on=v;save()}
function setQuiet(k,v){D.set.quiet[k]=v||D.set.quiet[k];save()}
function setAtStart(v){D.set.atStart=v;save()}

/* ---------- أقسام صفحة «المزيد» ---------- */
EXT.sections=()=>[['fin','money','المالية والدفعات',''],['rep','chart','تقرير الحصص الشهري',''],['cls','whats','الفصول وروابط واتساب',D.classes.length||''],['cur','book','المقرر والخطة الأسبوعية',''],['cal','cal','التقويم المدرسي',D.cal.length||''],['board','pen','السبورة الرقمية',''],['docs','cam','المستندات والصور',D.docs.length||''],['ai','robot','المساعد الذكي','']];
const _vRep0=vRep;EXT.views.rep=()=>backBtn()+_vRep0();
