/* curriculum.js — المقرر والخطة الأسبوعية + إعدادات المواد */
'use strict';
const CUR_ST={todo:'لم يبدأ',prog:'جارٍ',done:'منجز'};
let cf={subject:'',cls:'',week:'',q:''};
function parseCsv(t){t=String(t).replace(/^﻿/,'');const rows=[];let r=[],f='',q=false;
 for(let i=0;i<t.length;i++){const c=t[i];
  if(q){if(c==='"'){if(t[i+1]==='"'){f+='"';i++}else q=false}else f+=c}
  else if(c==='"')q=true;else if(c===','||c==='\t'||c===';'){r.push(f);f=''}
  else if(c==='\n'||c==='\r'){if(c==='\r'&&t[i+1]==='\n')i++;r.push(f);f='';if(r.some(x=>x.trim()))rows.push(r);r=[]}
  else f+=c}
 r.push(f);if(r.some(x=>x.trim()))rows.push(r);return rows}
function curWeekNo(ds){const ys=D.set.yearStart;if(!ys)return null;const a=new Date(ys+'T00:00'),b=new Date((ds||ymd(new Date()))+'T00:00');if(isNaN(a)||isNaN(b))return null;return Math.floor((b-a)/(7*864e5))+1}
function weekRange(n){const ys=D.set.yearStart;if(!ys)return null;const a=new Date(ys+'T00:00');a.setDate(a.getDate()+7*(n-1));const b=new Date(a);b.setDate(b.getDate()+6);return[ymd(a),ymd(b)]}
function givenInWeek(it){const wr=weekRange(+it.week);if(!wr)return null;let n=0;
 Object.keys(D.log).forEach(ds=>{if(ds<wr[0]||ds>wr[1])return;Object.values(D.log[ds]).forEach(r=>{if(r.s==='g'&&r.su===it.subject&&(!it.cls||r.lb===it.cls)&&(!it.school||r.sc===it.school))n++})});return n}
function weeklyQuota(it){const l=D.lessons.filter(x=>x.school===it.school&&x.subject===it.subject&&(!it.cls||lab(x)===it.cls)).length;const s=D.subjects.find(x=>x.id===it.subject);return (s&&+s.perWeek)||l||0}
function curLate(){const cw=curWeekNo();if(!cw)return[];return D.cur.filter(it=>(filt==='all'||it.school===filt)&&+it.week<cw&&it.status!=='done')}
function curFiltered(){const q=cf.q.trim();return D.cur.filter(it=>(filt==='all'||it.school===filt)&&(!cf.subject||it.subject===cf.subject)&&(!cf.cls||it.cls===cf.cls)&&(!cf.week||+it.week===+cf.week)&&(!q||[it.title,it.topics,it.goals,it.hw,it.note].join(' ').includes(q))).sort((a,b)=>(+a.week-+b.week)||(a.subject>b.subject?1:-1))}
function vCur(){const L=curFiltered(),cw=curWeekNo(),late=new Set(curLate().map(x=>x.id)),tot=D.cur.filter(it=>filt==='all'||it.school===filt),dn=tot.filter(x=>x.status==='done').length;
 const classes=[...new Set(D.cur.map(x=>x.cls).filter(Boolean))];
 const groups={};tot.forEach(it=>{const k=it.subject+'|'+(it.cls||'');groups[k]=groups[k]||{sub:it.subject,cls:it.cls,n:0,d:0};groups[k].n++;if(it.status==='done')groups[k].d++});
 return backBtn()+`<h2 class="pane-title">المقرر والخطة الأسبوعية</h2>${schoolSwitch()}
<div class="card"><div class="form"><label class="f">بداية العام الدراسي (لحساب رقم الأسبوع)<input type="date" value="${esc(D.set.yearStart||'')}" onchange="setOpt('yearStart',this.value);render()"></label><label class="f">عدد أسابيع العام<input type="number" inputmode="numeric" value="${D.set.yearWeeks||36}" onchange="setOpt('yearWeeks',Math.max(1,Math.min(60,+this.value||36)));render()"></label></div>
${cw?`<small>الأسبوع الحالي: <b>${cw}</b> ${weekRange(cw)?'('+fd(weekRange(cw)[0])+' – '+fd(weekRange(cw)[1])+')':''}</small>`:'<small style="color:var(--warn)">حدّد بداية العام لتظهر أرقام الأسابيع وينبّهك التطبيق عند التأخر عن الخطة.</small>'}</div>
<div class="stats three"><div class="stat"><b>${tot.length}</b><span>دروس مخططة</span></div><div class="stat"><b style="color:var(--ok)">${dn}</b><span>منجزة</span></div><div class="stat"><b style="color:var(--no)">${late.size}</b><span>متأخرة</span></div></div>
${Object.values(groups).length?`<div class="card"><h3>نسبة التقدم</h3>${Object.values(groups).map(g=>{const pc=Math.round(g.d*100/g.n);return `<div style="margin-bottom:10px"><div class="bar" style="justify-content:space-between"><b>${esc(sub(g.sub).name)}${g.cls?' · '+esc(g.cls):''}</b><small>${g.d}/${g.n} (${pc}%)</small></div><div class="pbar"><i style="width:${pc}%"></i></div></div>`}).join('')}</div>`:''}
<div class="bar" style="margin-bottom:12px"><button class="btn" style="flex:1" onclick="openCur()">${ic('plus',20)} درس / أسبوع</button><button class="btn ghost" onclick="$('#curfile').click()">${ic('upl',20)} استيراد</button></div><input type="file" id="curfile" accept=".csv,.txt,.tsv,text/plain,text/csv" hidden onchange="curImport(this)">
<details class="card" style="padding:12px"><summary>بحث وتصفية</summary><div style="margin-top:12px"><input placeholder="بحث في العنوان والموضوعات…" value="${esc(cf.q)}" onchange="cf.q=this.value;render()"><div class="form" style="margin-top:10px"><select onchange="cf.subject=this.value;render()"><option value="">كل المواد</option>${D.subjects.map(s=>`<option value="${s.id}" ${cf.subject===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select><select onchange="cf.cls=this.value;render()"><option value="">كل الفصول</option>${classes.map(c=>`<option ${cf.cls===c?'selected':''}>${esc(c)}</option>`).join('')}</select><input type="number" inputmode="numeric" placeholder="رقم الأسبوع" value="${esc(cf.week)}" onchange="cf.week=this.value;render()"></div><button class="btn ghost sm" style="margin-top:10px" onclick="cf={subject:'',cls:'',week:'',q:''};render()">مسح</button></div></details>
${L.map(it=>{const g=givenInWeek(it),qt=weeklyQuota(it),wr=weekRange(+it.week),isl=late.has(it.id);return `<div class="card ev" style="border-inline-start:6px solid ${sub(it.subject).color}"><div class="bar" style="justify-content:space-between"><span class="bar">${tag('الأسبوع '+it.week)}${tag(sub(it.subject).name,sub(it.subject).color)}${it.cls?tag(it.cls):''}</span><span class="badge ${it.status==='done'?'ok':isl?'no':''}">${isl?'متأخر':CUR_ST[it.status||'todo']}</span></div>
<h3>${esc(it.title||'بدون عنوان')}</h3>${wr?`<small>${fd(wr[0])} – ${fd(wr[1])}</small>`:''}
${it.topics?`<p style="margin:6px 0"><b>الموضوعات:</b> ${esc(it.topics)}</p>`:''}${it.goals?`<p style="margin:6px 0"><b>الأهداف:</b> ${esc(it.goals)}</p>`:''}${it.hw?`<p style="margin:6px 0"><b>الواجبات:</b> ${esc(it.hw)}</p>`:''}${it.note?`<p class="mu" style="margin:6px 0">${esc(it.note)}</p>`:''}
${g!==null?`<small>الحصص المعطاة فعلياً لهذه المادة${it.cls?'/الفصل':''} في هذا الأسبوع: <b>${g}</b>${qt?' من '+qt:''}</small>`:''}
<div class="bar" style="margin-top:10px"><button class="btn ghost sm" onclick="curToggle('${it.id}')">${ic('check',16)} ${it.status==='done'?'إلغاء الإنجاز':'تم الإنجاز'}</button><button class="btn ghost sm" onclick="openCur('${it.id}')">${ic('edit',16)} تعديل</button><button class="btn ghost sm" onclick="openCurCopy('${it.id}')">${ic('copy',16)} نسخ لأسبوع</button></div></div>`}).join('')||`<div class="card empty">${ic('book',40)}<p>لا دروس مخططة${tot.length?' ضمن التصفية':''}.<br>أضف درساً أو استورد خطتك من ملف CSV/TXT.</p></div>`}
${exportBar('curHtml','curTitle','curriculum','curCsv')}<div class="bar noprint"><button class="btn ghost sm" onclick="dlJson('curriculum',curFiltered())">${ic('down',16)} JSON</button></div>`}
EXT.views.cur=vCur;
function curTitle(){return 'المقرر والخطة الأسبوعية'}
function curHtml(){const L=curFiltered();return `<div style="font-size:22px;font-weight:900">المقرر والخطة الأسبوعية</div><div style="color:#506078;margin-bottom:12px">${esc(D.set.teacher||'')}${filt!=='all'?' · '+esc(sch(filt).name):''}</div><table><tr><th>الأسبوع</th><th>المادة</th><th>الفصل</th><th>العنوان</th><th>الموضوعات</th><th>الأهداف</th><th>الواجبات</th><th>الحالة</th></tr>${L.map(it=>`<tr><td>${it.week}</td><td>${esc(sub(it.subject).name)}</td><td>${esc(it.cls||'')}</td><td>${esc(it.title||'')}</td><td>${esc(it.topics||'')}</td><td>${esc(it.goals||'')}</td><td>${esc(it.hw||'')}</td><td>${CUR_ST[it.status||'todo']}</td></tr>`).join('')}</table>`}
function curCsv(){dlCsv('curriculum',[['الأسبوع','المادة','الفصل','العنوان','الموضوعات','الأهداف','الواجبات','ملاحظات','الحالة'],...curFiltered().map(it=>[it.week,sub(it.subject).name,it.cls,it.title,it.topics,it.goals,it.hw,it.note,CUR_ST[it.status||'todo']])])}
function curToggle(id){const it=D.cur.find(x=>x.id===id);if(!it)return;it.status=it.status==='done'?'todo':'done';it.doneDate=it.status==='done'?ymd(new Date()):'';audit('cur:'+id);save();render()}
function openCur(id){const ex=id&&D.cur.find(x=>x.id===id),cw=curWeekNo()||1;
 M={type:'cur',id:ex?ex.id:null,c:ex?{...ex}:{school:curSchool(),subject:(D.last&&D.subjects.some(s=>s.id===D.last.subject)?D.last.subject:'')||(D.subjects[0]||{}).id||'',cls:'',week:cf.week||cw,title:'',topics:'',goals:'',hw:'',note:'',status:'todo'}};drawM()}
EXT.sheets.cur=function(){const c=M.c,labs=[...new Set([...D.classes.filter(x=>x.school===c.school).map(x=>x.name),...D.lessons.filter(l=>l.school===c.school).map(lab)].filter(Boolean))];
 return sheetHead(M.id?'تعديل درس':'درس جديد')+
`<div class="lbl">المادة</div><div class="chips">${D.subjects.map(s=>`<button class="chip ${c.subject===s.id?'on':''}" onclick="M.c.subject='${s.id}';drawM()">${esc(s.name)}</button>`).join('')||'<small>أضف مادة أولاً من «المواد»</small>'}</div>
${multi()?`<div class="lbl">المدرسة</div><select onchange="M.c.school=this.value;drawM()">${D.schools.map(s=>`<option value="${s.id}" ${c.school===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:''}
<div class="form" style="margin-top:12px"><label class="f">رقم الأسبوع<input type="number" inputmode="numeric" value="${esc(c.week)}" oninput="M.c.week=this.value"></label><label class="f">الفصل (اختياري)<input value="${esc(c.cls||'')}" oninput="M.c.cls=this.value"></label></div>
${labs.length?`<div class="chips" style="margin-bottom:10px">${labs.slice(0,12).map(n=>`<button class="chip" onclick="M.c.cls=${JSON.stringify(n).replace(/"/g,'&quot;')};drawM()">${esc(n)}</button>`).join('')}</div>`:''}
<label class="f">عنوان الدرس<input value="${esc(c.title)}" oninput="M.c.title=this.value"></label>
<label class="f">الموضوعات<textarea rows="2" oninput="M.c.topics=this.value">${esc(c.topics)}</textarea></label>
<label class="f">الأهداف<textarea rows="2" oninput="M.c.goals=this.value">${esc(c.goals)}</textarea></label>
<label class="f">الواجبات<textarea rows="2" oninput="M.c.hw=this.value">${esc(c.hw)}</textarea></label>
<label class="f">ملاحظات المعلم<textarea rows="2" oninput="M.c.note=this.value">${esc(c.note)}</textarea></label>
<div class="lbl">حالة الإنجاز</div><div class="chips">${Object.keys(CUR_ST).map(k=>`<button class="chip ${c.status===k?'on':''}" onclick="M.c.status='${k}';drawM()">${CUR_ST[k]}</button>`).join('')}</div>
<div class="actions"><button class="btn" onclick="saveCur()">حفظ</button><button class="btn ghost" onclick="closeM()">إلغاء</button>${M.id?`<button class="btn ghost danger" onclick="delCur('${M.id}')">${ic('trash',20)} حذف</button>`:''}</div>`};
function saveCur(){const c=M.c;if(!c.subject)return toast('اختر المادة');const w=Math.round(+c.week);if(!(w>=1&&w<=80))return toast('رقم الأسبوع بين 1 و 80');if(!(c.title||'').trim()&&!(c.topics||'').trim())return toast('اكتب عنوان الدرس أو موضوعاته');
 const o={...c,week:w,cls:(c.cls||'').trim(),title:c.title.trim(),doneDate:c.status==='done'?(c.doneDate||ymd(new Date())):''};
 if(M.id){const i=D.cur.findIndex(x=>x.id===M.id);D.cur[i]={...D.cur[i],...o}}else{o.id=uid();D.cur.push(o)}
 D.last=Object.assign(D.last||{},{subject:c.subject});M=null;save();drawM();render();toast('تم حفظ الدرس')}
function delCur(id){const it=D.cur.find(x=>x.id===id);D.cur=D.cur.filter(x=>x.id!==id);M=null;save();drawM();render();toast('تم الحذف',{label:'تراجع',fn:()=>{D.cur.push(it);save();render()}})}
function openCurCopy(id){const it=D.cur.find(x=>x.id===id);if(!it)return;M={type:'curcopy',id,to:(+it.week||1)+1,all:false};drawM()}
EXT.sheets.curcopy=function(){const it=D.cur.find(x=>x.id===M.id);return sheetHead('نسخ خطة أسبوع',`الأسبوع ${it.week} — ${esc(sub(it.subject).name)}`)+
`<label class="f" style="margin-top:12px">إلى الأسبوع رقم<input type="number" inputmode="numeric" value="${M.to}" oninput="M.to=+this.value"></label>
<label class="switch"><b>نسخ كل دروس هذا الأسبوع (المادة والفصل نفسهما)</b><input type="checkbox" ${M.all?'checked':''} onchange="M.all=this.checked"><span class="tg"></span></label>
<small>تُنسخ كغير منجزة ويمكنك تعديلها بعد ذلك.</small><div class="actions"><button class="btn" onclick="doCurCopy()">نسخ</button><button class="btn ghost" onclick="closeM()">إلغاء</button></div>`};
function doCurCopy(){const it=D.cur.find(x=>x.id===M.id),w=Math.round(M.to);if(!(w>=1&&w<=80))return toast('رقم أسبوع غير صالح');
 const src=M.all?D.cur.filter(x=>x.week===it.week&&x.subject===it.subject&&x.cls===it.cls&&x.school===it.school):[it];
 src.forEach(x=>D.cur.push({...x,id:uid(),week:w,status:'todo',doneDate:''}));M=null;save();drawM();render();toast('تم نسخ '+src.length+' عنصر إلى الأسبوع '+w)}
/* ---- استيراد (مراجعة قبل الحفظ) ---- */
function curImport(inp){const f=inp.files&&inp.files[0];inp.value='';if(!f)return;if(f.size>2*1048576)return toast('الملف كبير (الحد 2 ميغابايت)');
 const r=new FileReader();r.onload=()=>{let rows=parseCsv(String(r.result));if(!rows.length)return toast('الملف فارغ أو غير مقروء');
  const hd=rows[0].map(x=>x.trim());const isH=/أسبوع|week/i.test(hd[0]||'');if(isH)rows=rows.slice(1);
  const items=rows.map(x=>({week:parseInt(x[0],10),title:(x[1]||'').trim(),topics:(x[2]||'').trim(),goals:(x[3]||'').trim(),hw:(x[4]||'').trim(),note:(x[5]||'').trim()})).filter(x=>x.week>=1&&x.week<=80&&(x.title||x.topics));
  if(!items.length)return toast('لم أجد صفوفاً صالحة. الأعمدة: الأسبوع، العنوان، الموضوعات، الأهداف، الواجبات، ملاحظات');
  M={type:'curimp',items,subject:(D.subjects[0]||{}).id||'',cls:'',school:curSchool(),src:f.name};drawM()};
 r.onerror=()=>toast('تعذرت قراءة الملف');r.readAsText(f,'utf-8')}
EXT.sheets.curimp=function(){return sheetHead('مراجعة الاستيراد',esc(M.src)+' — '+M.items.length+' صف')+
`<p class="mu" style="margin:8px 0;line-height:1.9">راجع الصفوف قبل الحفظ، ولا تعتمد المحتوى دون تدقيق. اختر المادة التي ستُسند إليها.</p>
<div class="chips">${D.subjects.map(s=>`<button class="chip ${M.subject===s.id?'on':''}" onclick="M.subject='${s.id}';drawM()">${esc(s.name)}</button>`).join('')||'<small>أضف مادة أولاً</small>'}</div>
<label class="f" style="margin-top:10px">الفصل (اختياري)<input value="${esc(M.cls)}" oninput="M.cls=this.value"></label>
<div class="tw" style="max-height:240px;overflow:auto"><table class="rep-t"><tr><th>أسبوع</th><th>العنوان</th><th>الموضوعات</th></tr>${M.items.slice(0,40).map(x=>`<tr><td>${x.week}</td><td>${esc(x.title)}</td><td>${esc(x.topics)}</td></tr>`).join('')}</table></div>${M.items.length>40?`<small>…و ${M.items.length-40} صف آخر</small>`:''}
<div class="actions"><button class="btn" onclick="doCurImp()">حفظ ${M.items.length} درساً</button><button class="btn ghost" onclick="closeM()">إلغاء</button></div>`};
function doCurImp(){if(!M.subject)return toast('اختر المادة');let n=0;M.items.forEach(x=>{if(D.cur.some(c=>c.school===M.school&&c.subject===M.subject&&c.cls===M.cls.trim()&&+c.week===x.week&&c.title===x.title))return;D.cur.push({id:uid(),school:M.school,subject:M.subject,cls:M.cls.trim(),status:'todo',...x});n++});
 D.imports.push({id:uid(),t:Date.now(),kind:'curriculum',src:M.src,n});M=null;save();drawM();render();toast('تمت إضافة '+n+' درساً (المكرر تُجوهل)')}

/* ---- المواد: الرمز والمرحلة والحصص الأسبوعية والسعر ---- */
function paneSubjects(){return `<h2 class="pane-title">المواد والمقررات</h2><div class="card"><p class="mu" style="margin-bottom:14px">لكل مادة لون افتراضي (يمكن تغيير لون كل حصة من الجدول) ورمز ومرحلة وعدد حصص أسبوعياً. تُدرَّس المادة نفسها في أي عدد من الفصول بإسنادها في الجدول.</p>${D.subjects.map(s=>`<div class="card" style="box-shadow:none;padding:12px"><div class="irow"><input type="color" value="${esc(s.color)}" onchange="colS('${s.id}',this.value)" aria-label="لون المادة"><input value="${esc(s.name)}" onchange="renSub('${s.id}',this.value)" aria-label="اسم المادة"><button class="iconbtn sm" onclick="delSub('${s.id}')" aria-label="حذف المادة">${ic('trash',20)}</button></div>
<div class="form"><label class="f">الرمز<input value="${esc(s.code||'')}" onchange="setSubF('${s.id}','code',this.value)"></label><label class="f">المرحلة<input value="${esc(s.stage||'')}" onchange="setSubF('${s.id}','stage',this.value)"></label><label class="f">حصص أسبوعياً<input type="number" inputmode="numeric" value="${s.perWeek||''}" onchange="setSubF('${s.id}','perWeek',+this.value||0)"></label></div>
<small>الفصول المرتبطة: ${[...new Set(D.lessons.filter(l=>l.subject===s.id).map(lab).filter(Boolean))].map(esc).join('، ')||'—'} · الحصص في الجدول: ${D.lessons.filter(l=>l.subject===s.id).length}</small></div>`).join('')||'<p class="mu">لا توجد مواد بعد.</p>'}<div class="irow" style="margin-top:14px"><input type="color" id="n_col" value="${PAL[D.subjects.length%PAL.length]}"><input id="n_sub" placeholder="اسم مادة جديدة"><button class="btn" onclick="addSub()">${ic('plus',20)}</button></div></div>`}
function setSubF(id,k,v){const s=D.subjects.find(x=>x.id===id);if(s){s[k]=typeof v==='string'?v.trim():v;save()}}
