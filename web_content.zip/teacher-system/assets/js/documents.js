/* documents.js — المستندات وصور السبورة: كاميرا/معرض، تحرير، تصنيف، مشاركة، PDF (IndexedDB محلياً) */
'use strict';
const IMGU={};
async function imgPut(blob){const id='i_'+uid();await idbPut({id,kind:'img',name:'',blob,size:blob.size});return id}
async function imgBlob(id){const r=await idbGet(id);return r&&r.blob}
async function imgUrl(id){if(IMGU[id])return IMGU[id];const b=await imgBlob(id);if(!b)return'';IMGU[id]=URL.createObjectURL(b);return IMGU[id]}
async function imgReplace(id,blob){await idbPut({id,kind:'img',name:'',blob,size:blob.size});if(IMGU[id]){URL.revokeObjectURL(IMGU[id]);delete IMGU[id]}}
async function imgDel(id){try{await idbDel(id)}catch(e){}if(IMGU[id]){URL.revokeObjectURL(IMGU[id]);delete IMGU[id]}}
EXT.loadThumbs=async()=>{const els=[...document.querySelectorAll('[data-iid]')];for(const el of els){const u=await imgUrl(el.dataset.iid);if(u&&el.isConnected)el.src=u}};
EXT.after.push(()=>EXT.loadThumbs());
const loadImg=src=>new Promise((ok,no)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=no;i.src=src});
/* تصغير + ضغط أي صورة قبل الحفظ */
async function shrink(file,maxW=1800,q=.85){const u=URL.createObjectURL(file);try{const im=await loadImg(u),sc=Math.min(1,maxW/Math.max(im.naturalWidth,im.naturalHeight)),cv=document.createElement('canvas');cv.width=Math.round(im.naturalWidth*sc);cv.height=Math.round(im.naturalHeight*sc);const x=cv.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,cv.width,cv.height);x.drawImage(im,0,0,cv.width,cv.height);return await blobOf(cv,'image/jpeg',q)}finally{URL.revokeObjectURL(u)}}
let docQ={q:'',school:'',cls:'',subject:'',kind:''};
let storeInfo='';
async function estimateStore(){try{if(navigator.storage&&navigator.storage.estimate){const e=await navigator.storage.estimate();storeInfo=`المساحة المستخدمة ${(e.usage/1048576).toFixed(1)} م.ب من ~${Math.round(e.quota/1048576)} م.ب`+(e.usage/e.quota>.8?' — اقتربت من الامتلاء!':'');const el=$('#storeinfo');if(el)el.textContent=storeInfo}}catch(e){}}
EXT.after.push(()=>{if(view==='docs')estimateStore()});
function docList(){const q=docQ.q.trim();return D.docs.filter(d=>(!docQ.school||d.school===docQ.school)&&(!docQ.cls||d.cls===docQ.cls)&&(!docQ.subject||d.subject===docQ.subject)&&(!docQ.kind||d.kind===docQ.kind)&&(!q||[d.title,d.desc,(d.tags||[]).join(' ')].join(' ').includes(q))).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||(b.created||0)-(a.created||0))}
function vDocs(){const L=docList(),classes=[...new Set(D.docs.map(d=>d.cls).filter(Boolean))];
 return backBtn()+`<h2 class="pane-title">المستندات والصور</h2>
<div class="card" style="padding:12px"><small>الصور محفوظة على هذا الجهاز فقط ولا تُرفع إلى أي خدمة خارجية. عند حذف بيانات التطبيق أو المتصفح تُفقد ما لم تأخذ نسخة احتياطية (تتضمن الصور). <span id="storeinfo">${esc(storeInfo)}</span></small></div>
<div class="row2" style="margin-bottom:12px"><button class="btn" onclick="$('#cam').click()">${ic('cam',20)} التقاط صورة</button><button class="btn ghost" onclick="$('#gal').click()">${ic('image',20)} من المعرض</button></div>
<input type="file" id="cam" accept="image/*" capture="environment" hidden onchange="docAdd(this)"><input type="file" id="gal" accept="image/*" multiple hidden onchange="docAdd(this)">
<details class="card" style="padding:12px"><summary>بحث وتصنيف</summary><div style="margin-top:12px"><input placeholder="بحث بالعنوان أو الوصف أو الكلمات المفتاحية…" value="${esc(docQ.q)}" onchange="docQ.q=this.value;render()"><div class="form" style="margin-top:10px">${multi()?`<select onchange="docQ.school=this.value;render()"><option value="">كل المدارس</option>${D.schools.map(s=>`<option value="${s.id}" ${docQ.school===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:''}<select onchange="docQ.cls=this.value;render()"><option value="">كل الفصول</option>${classes.map(c=>`<option ${docQ.cls===c?'selected':''}>${esc(c)}</option>`).join('')}</select><select onchange="docQ.subject=this.value;render()"><option value="">كل المواد</option>${D.subjects.map(s=>`<option value="${s.id}" ${docQ.subject===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select><select onchange="docQ.kind=this.value;render()"><option value="">مستندات وسبورات</option><option value="doc" ${docQ.kind==='doc'?'selected':''}>مستندات</option><option value="board" ${docQ.kind==='board'?'selected':''}>سبورات</option></select></div></div></details>
<div class="grid2">${L.map(d=>`<button class="card" style="padding:8px;margin:0;text-align:right" onclick="openDoc('${d.id}')">${d.pages&&d.pages[0]?`<img class="thumb" data-iid="${d.pages[0]}" alt="">`:'<div class="thumb"></div>'}<b style="display:block;margin-top:6px">${esc(d.title||'بدون عنوان')}</b><small>${d.kind==='board'?'سبورة · ':''}${(d.pages||[]).length} صفحة · ${fd(d.date||ymd(new Date(d.created||Date.now())))}</small></button>`).join('')}</div>
${L.length?'':`<div class="card empty">${ic('cam',40)}<p>لا مستندات${D.docs.length?' ضمن التصفية':' بعد'}.<br>صوّر السبورة أو ورقة، أو اختر صورة من المعرض.</p></div>`}`}
EXT.views.docs=vDocs;
async function docAdd(inp,toDoc){const fs=[...(inp.files||[])];inp.value='';if(!fs.length)return;const ids=[];
 try{for(const f of fs){if(!/^image\//.test(f.type)&&!/\.(jpe?g|png|webp|heic)$/i.test(f.name)){toast('«'+f.name+'» ليست صورة');continue}ids.push(await imgPut(await shrink(f)))}}
 catch(e){toast('تعذّر حفظ الصورة (المساحة ممتلئة أو الصيغة غير مدعومة)');for(const i of ids)await imgDel(i);return}
 if(!ids.length)return;
 if(toDoc&&M&&M.type==='doc'){M.d.pages.push(...ids);M.newImgs.push(...ids);drawM();return}
 M={type:'doc',id:null,newImgs:[...ids],d:{kind:'doc',title:'',desc:'',tags:'',school:curSchool(),cls:'',subject:'',date:ymd(new Date()),pages:ids}};drawM()}
function openDoc(id){const d=D.docs.find(x=>x.id===id);if(!d)return;M={type:'doc',id,newImgs:[],d:{...d,pages:[...d.pages],tags:(d.tags||[]).join('، ')}};drawM()}
EXT.sheets.doc=function(){const d=M.d,labs=[...new Set([...D.classes.filter(c=>c.school===d.school).map(c=>c.name),...D.lessons.filter(l=>l.school===d.school).map(lab)].filter(Boolean))];
 return sheetHead(M.id?'تفاصيل المستند':'مستند جديد',d.kind==='board'?'سبورة':'')+
`<div class="grid2" style="margin:10px 0">${d.pages.map((p,i)=>`<div><img class="thumb" data-iid="${p}" alt="" onclick="openPrev('${p}')"><div class="bar" style="margin-top:4px;gap:4px"><button class="iconbtn sm" style="width:34px;height:34px" onclick="openImgEd('${p}')" aria-label="تحرير">${ic('edit',16)}</button><button class="iconbtn sm" style="width:34px;height:34px" onclick="rotPage('${p}')" aria-label="تدوير">${ic('rot',16)}</button><button class="iconbtn sm" style="width:34px;height:34px" onclick="delPage(${i})" aria-label="حذف الصفحة">${ic('trash',16)}</button></div></div>`).join('')}</div>
<button class="btn ghost sm" onclick="$('#cam2').click()">${ic('cam',16)} صفحة بالكاميرا</button> <button class="btn ghost sm" onclick="$('#gal2').click()">${ic('plus',16)} من المعرض</button>
<input type="file" id="cam2" accept="image/*" capture="environment" hidden onchange="docAdd(this,1)"><input type="file" id="gal2" accept="image/*" multiple hidden onchange="docAdd(this,1)">
<label class="f" style="margin-top:12px">العنوان<input value="${esc(d.title)}" oninput="M.d.title=this.value"></label>
<label class="f">الوصف<textarea rows="2" oninput="M.d.desc=this.value">${esc(d.desc)}</textarea></label>
<label class="f">كلمات مفتاحية (افصل بفاصلة)<input value="${esc(d.tags)}" oninput="M.d.tags=this.value"></label>
<div class="form">${multi()?`<label class="f">المدرسة<select onchange="M.d.school=this.value;drawM()">${D.schools.map(s=>`<option value="${s.id}" ${d.school===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select></label>`:''}<label class="f">التاريخ<input type="date" value="${esc(d.date)}" onchange="M.d.date=this.value"></label></div>
<div class="lbl">الفصل</div><input value="${esc(d.cls||'')}" placeholder="مثال: 7/أ" oninput="M.d.cls=this.value">${labs.length?`<div class="chips" style="margin-top:8px">${labs.slice(0,12).map(n=>`<button class="chip ${d.cls===n?'on':''}" onclick="M.d.cls=${JSON.stringify(n).replace(/"/g,'&quot;')};drawM()">${esc(n)}</button>`).join('')}</div>`:''}
<div class="lbl">المادة</div><div class="chips"><button class="chip ${!d.subject?'on':''}" onclick="M.d.subject='';drawM()">بدون</button>${D.subjects.map(s=>`<button class="chip ${d.subject===s.id?'on':''}" onclick="M.d.subject='${s.id}';drawM()">${esc(s.name)}</button>`).join('')}</div>
<div class="bar" style="margin-top:14px"><button class="btn ghost sm" onclick="shareDoc()">${ic('share',16)} مشاركة</button><button class="btn ghost sm" onclick="docPdf()">${ic('file',16)} PDF</button><button class="btn ghost sm" onclick="docDownload()">${ic('down',16)} تنزيل الصور</button>${clsOf(d.school,(d.cls||'').trim())&&clsOf(d.school,(d.cls||'').trim()).wa?`<button class="btn ghost sm" onclick="openWa('${clsOf(d.school,d.cls.trim()).id}')">${ic('whats',16)} مجموعة الفصل</button>`:''}</div>
<small style="display:block;margin-top:8px">لا يرسل التطبيق شيئاً تلقائياً: تُفتح نافذة المشاركة أو يُنزَّل الملف، وتؤكد الإرسال بنفسك داخل واتساب.</small>
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACw=" style="display:none" onload="EXT.loadThumbs()">
<div class="actions"><button class="btn" onclick="saveDoc()">حفظ</button><button class="btn ghost" onclick="cancelDoc()">إلغاء</button>${M.id?`<button class="btn ghost danger" onclick="delDoc('${M.id}')">${ic('trash',20)} حذف</button>`:''}</div>`};
async function saveDoc(){const d=M.d;if(!d.pages.length)return toast('لا توجد صفحات');
 const o={...d,title:(d.title||'').trim()||('مستند '+fd(d.date||new Date())),tags:String(d.tags||'').split(/[,،]/).map(x=>x.trim()).filter(Boolean),cls:(d.cls||'').trim()};
 if(M.id){const i=D.docs.findIndex(x=>x.id===M.id);const old=D.docs[i];(old.pages||[]).filter(p=>!o.pages.includes(p)).forEach(imgDel);D.docs[i]={...old,...o}}else{o.id=uid();o.created=Date.now();D.docs.push(o)}
 M=null;save();drawM();render();toast('تم حفظ المستند')}
async function cancelDoc(){if(M.newImgs&&M.newImgs.length&&!M.id){for(const i of M.newImgs)await imgDel(i)}else if(M.id){for(const i of M.newImgs.filter(p=>!(D.docs.find(x=>x.id===M.id).pages||[]).includes(p)))await imgDel(i)}closeM()}
async function delPage(i){const p=M.d.pages[i];M.d.pages.splice(i,1);M.pendDel=(M.pendDel||[]);if(M.newImgs.includes(p)){await imgDel(p);M.newImgs=M.newImgs.filter(x=>x!==p)}drawM()}
function delDoc(id){const d=D.docs.find(x=>x.id===id);ask('حذف المستند «'+(d&&d.title||'')+'» وصوره نهائياً؟','حذف',async()=>{for(const p of (d.pages||[]))await imgDel(p);D.docs=D.docs.filter(x=>x.id!==id);save();render();toast('تم الحذف')})}
async function rotPage(id){const b=await imgBlob(id);if(!b)return;const u=URL.createObjectURL(b);const im=await loadImg(u);const cv=document.createElement('canvas');cv.width=im.naturalHeight;cv.height=im.naturalWidth;const x=cv.getContext('2d');x.translate(cv.width/2,cv.height/2);x.rotate(Math.PI/2);x.drawImage(im,-im.naturalWidth/2,-im.naturalHeight/2);URL.revokeObjectURL(u);await imgReplace(id,await blobOf(cv,'image/jpeg',.88));drawM()}
/* معاينة */
function openPrev(id){M={type:'prev',id,z:1,back:M};drawM()}
EXT.sheets.prev=function(){return sheetHead('معاينة')+`<div style="overflow:auto;max-height:68vh;border-radius:12px"><img data-iid="${M.id}" alt="" style="width:${M.z*100}%;display:block"></div><div class="bar" style="margin-top:10px"><button class="btn ghost sm" onclick="M.z=Math.max(1,M.z-.5);drawM()">${ic('minus',16)}</button><button class="btn ghost sm" onclick="M.z=Math.min(4,M.z+.5);drawM()">${ic('plus',16)}</button><button class="btn ghost sm" onclick="M=M.back;drawM()">رجوع</button></div><img src="data:image/gif;base64,R0lGODlhAQABAAAAACw=" style="display:none" onload="EXT.loadThumbs()">`};
/* تحرير صورة: قص، تدوير، إضاءة، تباين، نص */
async function openImgEd(id){const b=await imgBlob(id);if(!b)return toast('الصورة غير موجودة');const src=URL.createObjectURL(b);const im=await loadImg(src);
 M={type:'imged',id,im,src,back:M,rot:0,t:0,b:0,l:0,r:0,br:100,ct:100,txt:''};drawM()}
EXT.sheets.imged=function(){const m=M,sl=(k,t,min,max,st)=>`<label class="f"><span class="rng"><span>${t}</span><b id="e_${k}">${m[k]}</b></span><input type="range" min="${min}" max="${max}" step="${st}" value="${m[k]}" oninput="M.${k}=+this.value;$('#e_${k}').textContent=this.value;edPrev()"></label>`;
 return sheetHead('تحرير الصورة')+`<canvas id="ed_cv" style="width:100%;max-height:44vh;object-fit:contain;border:1px solid var(--bd);border-radius:12px;background:#eee"></canvas>
<div class="bar" style="margin:10px 0"><button class="btn ghost sm" onclick="M.rot=(M.rot+90)%360;edPrev()">${ic('rot',16)} تدوير 90°</button><button class="btn ghost sm" onclick="Object.assign(M,{t:0,b:0,l:0,r:0,br:100,ct:100,rot:0});drawM()">إعادة</button></div>
${sl('t','قص من الأعلى %',0,45,1)}${sl('b','قص من الأسفل %',0,45,1)}${sl('l','قص من اليسار %',0,45,1)}${sl('r','قص من اليمين %',0,45,1)}${sl('br','الإضاءة %',50,160,1)}${sl('ct','التباين %',50,180,1)}
<label class="f">نص / ملاحظة على الصورة (اختياري)<input value="${esc(m.txt)}" oninput="M.txt=this.value;edPrev()"></label>
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACw=" style="display:none" onload="edPrev()">
<div class="actions"><button class="btn" onclick="edApply()">تطبيق</button><button class="btn ghost" onclick="edCancel()">إلغاء</button></div>`};
function edRender(maxW){const m=M,sw=m.im.naturalWidth,sh=m.im.naturalHeight,cvs=document.createElement('canvas'),rot=m.rot%180!==0,W=rot?sh:sw,H=rot?sw:sh;
 const t=document.createElement('canvas');t.width=W;t.height=H;const x=t.getContext('2d');x.save();x.translate(W/2,H/2);x.rotate(m.rot*Math.PI/180);x.filter=`brightness(${m.br}%) contrast(${m.ct}%)`;x.drawImage(m.im,-sw/2,-sh/2);x.restore();
 const cx=Math.round(W*m.l/100),cy=Math.round(H*m.t/100),cw=Math.max(8,Math.round(W*(100-m.l-m.r)/100)),ch=Math.max(8,Math.round(H*(100-m.t-m.b)/100));
 const sc=Math.min(1,(maxW||1800)/Math.max(cw,ch));cvs.width=Math.round(cw*sc);cvs.height=Math.round(ch*sc);const y=cvs.getContext('2d');y.drawImage(t,cx,cy,cw,ch,0,0,cvs.width,cvs.height);
 if(m.txt){const fs=Math.max(16,Math.round(cvs.height*.045));y.font='bold '+fs+'px "Noto Sans Arabic",Tahoma,sans-serif';y.textAlign='center';y.fillStyle='rgba(0,0,0,.55)';y.fillRect(0,cvs.height-fs*1.8,cvs.width,fs*1.8);y.fillStyle='#fff';y.fillText(m.txt,cvs.width/2,cvs.height-fs*.55)}return cvs}
function edPrev(){const c=$('#ed_cv');if(!c||!M||M.type!=='imged')return;const r=edRender(900);c.width=r.width;c.height=r.height;c.getContext('2d').drawImage(r,0,0)}
async function edApply(){const b=await blobOf(edRender(1800),'image/jpeg',.88);await imgReplace(M.id,b);URL.revokeObjectURL(M.src);const back=M.back;M=back;drawM();toast('تم تطبيق التعديل')}
function edCancel(){URL.revokeObjectURL(M.src);M=M.back;drawM()}
/* مشاركة / PDF / تنزيل */
async function docFiles(){const out=[];for(const p of M.d.pages){const b=await imgBlob(p);if(b)out.push(new File([b],(M.d.title||'doc').replace(/[^\w؀-ۿ]+/g,'_')+'_'+(out.length+1)+'.jpg',{type:'image/jpeg'}))}return out}
async function docPdfBlob(){const files=await docFiles();const pages=[];for(const f of files){const im=await loadImg(URL.createObjectURL(f)),cv=document.createElement('canvas');cv.width=1240;cv.height=1754;const x=cv.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,1240,1754);const sc=Math.min(1240/im.naturalWidth,1754/im.naturalHeight);const w=im.naturalWidth*sc,h=im.naturalHeight*sc;x.drawImage(im,(1240-w)/2,(1754-h)/2,w,h);pages.push(cv)}return buildPdf(pages)}
async function docPdf(){try{toast('جارٍ إنشاء PDF…');dlBlob(await docPdfBlob(),((M.d.title||'document').replace(/[^\w؀-ۿ]+/g,'_'))+'.pdf');toast('تم إنشاء PDF')}catch(e){toast('تعذر إنشاء PDF')}}
async function docDownload(){const fs=await docFiles();fs.forEach((f,i)=>setTimeout(()=>dlBlob(f,f.name),i*300));toast('تم تنزيل '+fs.length+' صورة')}
async function shareDoc(){const files=await docFiles(),text=[M.d.title,M.d.desc].filter(Boolean).join('\n');
 if(files.length===1)return shareAny({file:files[0],text,title:M.d.title});
 try{const pdf=new File([await docPdfBlob()],(M.d.title||'document')+'.pdf',{type:'application/pdf'});return shareAny({file:pdf,text,title:M.d.title})}catch(e){return shareAny({text,title:M.d.title})}}
