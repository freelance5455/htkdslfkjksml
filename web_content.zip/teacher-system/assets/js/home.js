/* home.js — الرئيسية */
'use strict';
function schoolSwitch(){if(!multi())return '';const sid=filt==='all'?'all':filt;
 return `<div class="chips" style="margin-bottom:12px"><button class="chip ${sid==='all'?'on':''}" onclick="filt='all';render()">كل المدارس</button>${D.schools.map(s=>`<button class="chip ${sid===s.id?'on':''}" onclick="filt='${s.id}';render()">${esc(s.name)}</button>`).join('')}</div>`}
function vHome(){
 const now=new Date(),td=ymd(now),L=dayLessons(td).filter(l=>filt==='all'||l.school===filt),hol=vacOn(td);
 const given=L.filter(l=>(getRec(td,l.id)||{}).s==='g').length+Object.values(D.log[td]||{}).filter(r=>r.x).length;
 const nx=nextUp(),cur=currentLesson();
 const wk=weekStart(now),we=new Date(wk);we.setDate(we.getDate()+6);
 const mS=new Date(now.getFullYear(),now.getMonth(),1),mE=new Date(now.getFullYear(),now.getMonth()+1,0);
 const fW=dueBetween(ymd(wk),ymd(we),filt),fM=dueBetween(ymd(mS),ymd(mE),filt),cur$=D.set.cur||'';
 const up=D.events.filter(isUp).map(e=>{const ds=nextOcc(e);return{e,ds,st:evStart(e,ds).getTime()}}).sort((a,b)=>a.st-b.st);
 const late=D.events.filter(e=>!e.done&&e.status!=='canc'&&(!e.rep||e.rep==='none')&&evEnd(e,e.date)<Date.now());
 const pend=pendingToday(),miss=missingList().reduce((a,x)=>a+x.n,0);
 const lateCur=(window.curLate?curLate():[]);
 const alerts=[];
 if(pend)alerts.push(['warn',`${pend} حصة انتهت اليوم ولم تُسجَّل`,"go('log')"]);
 if(miss)alerts.push(['warn',`${miss} حصة سابقة غير مسجّلة (لا تدخل في الأجر)`,"go('log')"]);
 if(late.length)alerts.push(['no',`${late.length} مهمة/موعد متأخر`,"remFlt='late';go('rem')"]);
 if(lateCur.length)alerts.push(['warn',`${lateCur.length} درس متأخر عن خطة المقرر`,"go('cur')"]);
 const soon=up.filter(x=>x.st-Date.now()<864e5&&x.st>Date.now());
 soon.slice(0,3).forEach(x=>alerts.push(['',`${evTitle(x.e)} — ${relTxt(x.st-Date.now())}`,"go('rem')"]));
 const nxTxt=nx?`${sub(nx.l.subject).name}${lab(nx.l)?' · '+lab(nx.l):''}`:'';
 const nxWhen=nx?(ymd(nx.s)===td?'اليوم':fd(nx.s))+' · '+fmt(nx.l.start)+' ('+relTxt(nx.s-now)+')':'';
 return `<div class="shero"><h2>${esc(D.set.teacher?'أهلاً '+D.set.teacher:'منظومة المعلم الذكية')}</h2><p>${fd(now)}${hol?' · عطلة / إيقاف تنبيهات الحصص':''}</p></div>
${schoolSwitch()}
<div class="stats three"><div class="stat"><b>${L.length}</b><span>حصص اليوم</span></div><div class="stat"><b style="color:var(--ok)">${given}</b><span>أُعطيت</span></div><div class="stat"><b style="color:var(--warn)">${pend}</b><span>بانتظار التسجيل</span></div></div>
<div class="card"><h3>${cur?'الحصة الحالية':'الحصة القادمة'}</h3>${cur?`<div style="font-size:1.2rem;font-weight:900;color:${colOf(cur)}">${esc(sub(cur.subject).name)}${lab(cur)?' · '+esc(lab(cur)):''}</div><div class="mu">حتى ${fmt(cur.end)}${multi()?' · '+esc(sch(cur.school).name):''}</div>`:nx?`<div style="font-size:1.2rem;font-weight:900">${esc(nxTxt)}</div><div class="mu">${nxWhen}${multi()?' · '+esc(sch(nx.l.school).name):''}</div>`:'<p class="mu">لا توجد حصص قادمة في الجدول. أضف حصصك من تبويب «الجدول».</p>'}</div>
${alerts.length?`<div class="card"><h3>تنبيهات</h3>${alerts.map(([c,t,a])=>`<button class="srow" style="min-height:48px;padding:8px 4px" onclick="${a}"><span class="badge ${c}">${ic(c?'alert':'bell',14)}</span><span class="sname" style="font-size:.92rem;font-weight:800">${esc(t)}</span><span class="sarrow">${ic('next',18)}</span></button>`).join('')}</div>`:''}
<div class="card"><h3>المستحقات (من الحصص المعطاة فعلياً)</h3><div class="stats" style="margin:0"><div class="stat"><b style="font-size:1.35rem">${money(fW.due)}</b><span>هذا الأسبوع · ${fW.cnt} حصة</span></div><div class="stat"><b style="font-size:1.35rem">${money(fM.due)}</b><span>هذا الشهر · ${fM.cnt} حصة</span></div></div><small>العملة: ${esc(cur$)}. التفاصيل والدفعات في «المالية».</small></div>
<div class="card"><h3>المهام والامتحانات القريبة</h3>${up.length?up.slice(0,5).map(x=>{const T=EV_TYPES[x.e.type]||EV_TYPES.other;return `<div class="irow" style="margin-bottom:8px"><span class="badge" style="background:color-mix(in srgb,${T.c} 14%,var(--card));color:${T.c}">${T.n}</span><b style="flex:1">${esc(evTitle(x.e))}</b><small>${x.ds===td?'اليوم':fd(x.ds)}</small></div>`}).join(''):'<p class="mu">لا مهام قادمة.</p>'}<button class="btn ghost sm" style="margin-top:6px" onclick="go('rem')">كل المهام</button></div>
<div class="card"><h3>اختصارات</h3><div class="row2"><button class="btn ghost" onclick="go('table');setTimeout(()=>{if(!editMode)toggleEditMode()},30)">${ic('plus',18)} حصة</button><button class="btn ghost" onclick="go('rem');openEv()">${ic('plus',18)} مهمة</button><button class="btn ghost" onclick="go('set');openPane('subjects')">${ic('plus',18)} مادة</button><button class="btn ghost" onclick="go('set');openPane('schools')">${ic('plus',18)} مدرسة</button></div></div>`}
EXT.views.home=vHome;
