/* finance.js — المستحقات والدفعات والتقارير حسب نطاق زمني */
'use strict';
let finP='month',finFrom='',finTo='',finSch='all',finGrp='school';
const PAY_M=['نقداً','تحويل بنكي','شيك','محفظة إلكترونية','أخرى'];
function logRows(from,to,school){const out=[];Object.keys(D.log).sort().forEach(ds=>{if(!inRange(ds,from,to))return;Object.entries(D.log[ds]).forEach(([id,r])=>{if(!r.s)return;if(school&&school!=='all'&&r.sc!==school)return;out.push({ds,id,...r})})});return out}
function dueBetween(from,to,school){const rows=logRows(from,to,school);let due=0,cnt=0;const by={g:0,a:0,e:0,c:0,n:0,o:0};
 rows.forEach(r=>{by[r.s]=(by[r.s]||0)+1;if(countsPaid(r)){cnt++;due+=rateFor(r)}});
 return{due,cnt,by,rows,makeup:rows.filter(r=>r.x).length}}
function schedCount(from,to,school){let n=0;const a=new Date((from||ymd(new Date()))+'T00:00'),b=new Date(Math.min(new Date((to||ymd(new Date()))+'T00:00').getTime(),new Date().setHours(0,0,0,0)));
 if(isNaN(a)||isNaN(b))return 0;for(let d=new Date(a),i=0;d<=b&&i<800;d.setDate(d.getDate()+1),i++){const ds=ymd(d);if(vacOn(ds)&&!Object.keys(D.log[ds]||{}).length)continue;n+=dayLessons(ds).filter(l=>!school||school==='all'||l.school===school).length}return n}
const payRows=(from,to,school)=>D.pay.filter(p=>inRange(p.date,from,to)&&(!school||school==='all'||p.school===school)).sort((a,b)=>b.date.localeCompare(a.date)||(b.created||0)-(a.created||0));
function finRange(){const n=new Date(),t=ymd(n);
 if(finP==='day')return[t,t,'اليوم '+fd(n)];
 if(finP==='week'){const a=weekStart(n),b=new Date(a);b.setDate(b.getDate()+6);return[ymd(a),ymd(b),'الأسبوع '+fd(a)+' – '+fd(b)]}
 if(finP==='month'){const a=new Date(n.getFullYear(),n.getMonth(),1),b=new Date(n.getFullYear(),n.getMonth()+1,0);return[ymd(a),ymd(b),MON[n.getMonth()]+' '+n.getFullYear()]}
 if(finP==='all')return['','','كل الفترات'];
 const a=finFrom||t,b=finTo||t;return[a,b,fd(a)+' – '+fd(b)]}
function finCalc(){const[from,to,label]=finRange(),sc=finSch,r=dueBetween(from,to,sc),pays=payRows(from,to,sc);
 const received=pays.reduce((a,p)=>a+(+p.amount||0),0);
 const cumDue=dueBetween('',to,sc).due,cumPaid=payRows('',to,sc).reduce((a,p)=>a+(+p.amount||0),0);
 const sched=schedCount(from||D.set.logFrom||'',to||ymd(new Date()),sc);
 const groups={};r.rows.forEach(x=>{if(!countsPaid(x))return;const rt=rateFor(x),key=finGrp==='subject'?(x.sn||'—'):finGrp==='class'?((x.lb||'—')+(multi()?' · '+(x.scn||''):'')):(x.scn||'—');
  const k=key+'|'+rt;groups[k]=groups[k]||{k:key,rt,n:0,sum:0};groups[k].n++;groups[k].sum+=rt});
 return{from,to,label,r,pays,received,cumDue,cumPaid,remain:cumDue-cumPaid,sched,groups:Object.values(groups).sort((a,b)=>b.sum-a.sum)}}
function finHtml(c){c=c||finCalc();const cur=D.set.cur||'',gl={school:'المدرسة',subject:'المادة',class:'الفصل'}[finGrp];
 return `<div style="font-size:22px;font-weight:900">التقرير المالي — ${esc(c.label)}</div><div style="margin:4px 0 14px;color:#506078">${esc(D.set.teacher||'')}${finSch!=='all'?' · '+esc(sch(finSch).name):''}</div>
<table><tr><th>المستحق (الفترة)</th><th>المقبوض (الفترة)</th><th>المتبقي التراكمي</th></tr><tr><td>${money(c.r.due)} ${esc(cur)}</td><td>${money(c.received)} ${esc(cur)}</td><td>${money(c.remain)} ${esc(cur)}</td></tr></table>
<p style="margin:12px 0 4px"><b>معادلة الحساب:</b> الأجر المستحق = مجموع (عدد الحصص المحتسبة × سعر الحصة). المتبقي = المستحق التراكمي − المقبوض التراكمي.</p>
<p style="margin:0 0 10px">الحالات المحتسبة: ${paidNames()}.</p>
<table><tr><th>المجدولة</th><th>أُعطيت</th><th>غياب المعلم</th><th>بعذر</th><th>لم تُعطَ</th><th>ملغاة</th><th>أخرى</th><th>تعويضية</th></tr><tr><td>${c.sched}</td><td>${c.r.by.g}</td><td>${c.r.by.a}</td><td>${c.r.by.e}</td><td>${c.r.by.n}</td><td>${c.r.by.c}</td><td>${c.r.by.o}</td><td>${c.r.makeup}</td></tr></table>
<h3 style="margin:14px 0 6px">حسب ${gl}</h3><table><tr><th>${gl}</th><th>عدد الحصص</th><th>السعر</th><th>المبلغ</th></tr>${c.groups.map(g=>`<tr><td>${esc(g.k)}</td><td>${g.n}</td><td>${money(g.rt)}</td><td>${money(g.sum)}</td></tr>`).join('')||'<tr><td colspan="4">لا حصص محتسبة</td></tr>'}</table>
<h3 style="margin:14px 0 6px">الدفعات</h3><table><tr><th>التاريخ</th><th>القيمة</th><th>الطريقة</th><th>المدرسة</th><th>ملاحظة</th></tr>${c.pays.map(p=>`<tr><td>${fd(p.date)}</td><td>${money(p.amount)}</td><td>${esc(p.method||'')}</td><td>${esc(sOf(p.school)?sOf(p.school).name:'—')}</td><td>${esc(p.note||'')}</td></tr>`).join('')||'<tr><td colspan="5">لا دفعات</td></tr>'}</table>
<h3 style="margin:14px 0 6px">تفاصيل الحصص (${c.r.rows.length})</h3><table><tr><th>التاريخ</th><th>المدرسة</th><th>المادة</th><th>الصف</th><th>الحالة</th><th>محتسبة</th><th>المبلغ</th></tr>${c.r.rows.map(x=>`<tr><td>${fd(x.ds)}</td><td>${esc(x.scn||'')}</td><td>${esc(x.sn||'')}${x.x?' (تعويضية)':''}</td><td>${esc(x.lb||'')}</td><td>${ST[x.s].n}${x.r?' — '+esc(x.r):''}</td><td>${countsPaid(x)?'نعم':'لا'}</td><td>${countsPaid(x)?money(rateFor(x)):'0'}</td></tr>`).join('')}</table>`}
function finTitle(){return 'التقرير المالي — '+finCalc().label}
function finCsv(){const c=finCalc(),cur=D.set.cur||'';const rows=[['التقرير المالي',c.label,D.set.teacher||''],[],['المستحق',c.r.due,cur],['المقبوض',c.received,cur],['المتبقي التراكمي',c.remain,cur],[],['التاريخ','المدرسة','المادة','الصف','الحالة','السبب','محتسبة','السعر','المبلغ']];
 c.r.rows.forEach(x=>{const p=countsPaid(x);rows.push([x.ds,x.scn,x.sn+(x.x?' (تعويضية)':''),x.lb,STN[x.s],x.r,p?'نعم':'لا',p?rateFor(x):0,p?rateFor(x):0])});
 rows.push([],['الدفعات'],['التاريخ','القيمة','الطريقة','المدرسة','ملاحظة']);c.pays.forEach(p=>rows.push([p.date,p.amount,p.method,sOf(p.school)?sOf(p.school).name:'',p.note]));
 dlCsv('finance_'+(c.from||'all')+'_'+(c.to||'all'),rows)}
function vFin(){const c=finCalc(),cur=D.set.cur||'',P=D.set.paid;
 const pbtn=(k,t)=>`<button style="flex:1;padding:8px 4px" class="${finP===k?'on':''}" onclick="finP='${k}';render()">${t}</button>`;
 return backBtn()+`<h2 class="pane-title">المالية والدفعات</h2>
<div class="seg" style="display:flex;margin-bottom:10px">${pbtn('day','اليوم')}${pbtn('week','الأسبوع')}${pbtn('month','الشهر')}${pbtn('custom','مخصص')}${pbtn('all','الكل')}</div>
${finP==='custom'?`<div class="form"><label class="f">من<input type="date" value="${esc(finFrom)}" onchange="finFrom=this.value;render()"></label><label class="f">إلى<input type="date" value="${esc(finTo)}" onchange="finTo=this.value;render()"></label></div>`:''}
${multi()?`<div class="chips" style="margin-bottom:12px"><button class="chip ${finSch==='all'?'on':''}" onclick="finSch='all';render()">كل المدارس</button>${D.schools.map(s=>`<button class="chip ${finSch===s.id?'on':''}" onclick="finSch='${s.id}';render()">${esc(s.name)}</button>`).join('')}</div>`:''}
<div class="mu" style="margin-bottom:8px;font-weight:800">${esc(c.label)}</div>
<div class="stats three"><div class="stat"><b style="font-size:1.3rem;color:var(--pr)">${money(c.r.due)}</b><span>المستحق</span></div><div class="stat"><b style="font-size:1.3rem;color:var(--ok)">${money(c.received)}</b><span>المقبوض</span></div><div class="stat"><b style="font-size:1.3rem;color:${c.remain>0?'var(--warn)':'var(--ok)'}">${money(c.remain)}</b><span>${c.remain<0?'زيادة مقبوضة':'المتبقي'}</span></div></div>
<small style="display:block;margin:-4px 0 12px">العملة: ${esc(cur)} · المتبقي تراكمي حتى نهاية الفترة (المستحق منذ البداية − كل الدفعات حتى ذلك التاريخ).</small>
<div class="card"><h3>معادلة الحساب</h3><p style="line-height:2">المستحق = مجموع (الحصص المحتسبة × سعر الحصة)<br>الحصص المحتسبة: <b>${paidNames()}</b><br>${c.r.cnt} حصة محتسبة ⇒ <b>${money(c.r.due)} ${esc(cur)}</b></p>
<div class="stats six" style="margin:8px 0 0"><div class="stat"><b>${c.sched}</b><span>مجدولة</span></div><div class="stat"><b style="color:var(--ok)">${c.r.by.g}</b><span>أُعطيت</span></div><div class="stat"><b style="color:var(--no)">${c.r.by.a+c.r.by.e+c.r.by.n+c.r.by.o}</b><span>غير معطاة</span></div><div class="stat"><b>${c.r.by.c}</b><span>ملغاة</span></div><div class="stat"><b>${c.r.makeup}</b><span>تعويضية</span></div><div class="stat"><b style="color:var(--pr)">${c.r.cnt}</b><span>محتسبة</span></div></div></div>
<div class="card"><div class="bar" style="justify-content:space-between"><h3 style="margin:0">التفصيل</h3><div class="seg">${[['school','مدرسة'],['subject','مادة'],['class','فصل']].map(([k,t])=>`<button class="${finGrp===k?'on':''}" onclick="finGrp='${k}';render()">${t}</button>`).join('')}</div></div>
<div class="tw"><table class="rep-t"><tr><th>${{school:'المدرسة',subject:'المادة',class:'الفصل'}[finGrp]}</th><th>الحصص</th><th>السعر</th><th>المبلغ</th></tr>${c.groups.map(g=>`<tr><td>${esc(g.k)}</td><td>${g.n}</td><td>${money(g.rt)}</td><td>${money(g.sum)}</td></tr>`).join('')||'<tr><td colspan="4" class="mu">لا حصص محتسبة في هذه الفترة. سجّل حصصك من تبويب «السجل».</td></tr>'}</table></div></div>
<div class="card"><div class="bar" style="justify-content:space-between"><h3 style="margin:0">الدفعات المقبوضة (${c.pays.length})</h3><button class="btn sm" onclick="openPay()">${ic('plus',16)} دفعة</button></div>
${c.pays.map(p=>`<div class="irow" style="margin-top:10px;align-items:flex-start"><span class="sicon">${ic('money',20)}</span><div style="flex:1"><b>${money(p.amount)} ${esc(cur)}</b> <small>· ${esc(p.method||'')}</small><br><small>${fd(p.date)}${multi()&&sOf(p.school)?' · '+esc(sOf(p.school).name):''}${p.note?' · '+esc(p.note):''}</small></div><button class="iconbtn sm" onclick="openPay('${p.id}')" aria-label="تعديل">${ic('edit',18)}</button></div>`).join('')||'<p class="mu" style="margin-top:8px">لا دفعات في هذه الفترة.</p>'}</div>
${exportBar('finHtml','finTitle','finance_report','finCsv')}
<details class="card" ${''}><summary>الأسعار وقواعد الاحتساب</summary><div style="margin-top:12px">
<label class="f">سعر الحصة الافتراضي (${esc(cur)})<input type="number" inputmode="decimal" value="${D.set.rate||''}" placeholder="0" onchange="setOpt('rate',+this.value||0);render()"></label>
<label class="f">العملة<input value="${esc(cur)}" onchange="setOpt('cur',this.value.trim());render()"></label>
${D.schools.map(s=>`<label class="f">سعر الحصة في «${esc(s.name)}» (فارغ = الافتراضي)<input type="number" inputmode="decimal" value="${s.rate!==undefined&&s.rate!==null?s.rate:''}" onchange="setSchRate('${s.id}',this.value)"></label>`).join('')}
${D.subjects.length?`<div class="lbl">سعر خاص بمادة (يتقدم على سعر المدرسة)</div>${D.subjects.map(s=>`<label class="f">${esc(s.name)}<input type="number" inputmode="decimal" value="${s.rate!==undefined&&s.rate!==null?s.rate:''}" placeholder="بدون" onchange="setSubRate('${s.id}',this.value)"></label>`).join('')}`:''}
<small>سعر الفصل (من «الفصول وروابط واتساب») يتقدم على سعر المادة ثم المدرسة.</small>
<div class="lbl">الحالات التي تُحتسب في الأجر</div>${['g','a','e','n','c','o'].map(k=>`<label class="switch"><b>${STN[k]}</b><input type="checkbox" ${P[k]?'checked':''} onchange="setPaid('${k}',this.checked)"><span class="tg"></span></label>`).join('')}
<small>الافتراضي: «أعطيت الحصة» فقط. الحصة التعويضية المرتبطة بحصة أصلية محتسبة لا تُحتسب مرتين.</small></div></details>`}
EXT.views.fin=vFin;
function setSubRate(id,v){const s=D.subjects.find(x=>x.id===id);if(!s)return;if(v===''||v===null)delete s.rate;else s.rate=+v||0;audit('rate:'+id);save();render()}
/* ----- نافذة الدفعة ----- */
function openPay(id){const ex=id&&D.pay.find(x=>x.id===id);M={type:'pay',id:ex?ex.id:null,p:ex?{...ex}:{date:ymd(new Date()),amount:'',method:PAY_M[0],note:'',school:finSch!=='all'?finSch:curSchool()}};drawM()}
EXT.sheets.pay=function(){const p=M.p;return sheetHead(M.id?'تعديل دفعة':'تسجيل دفعة')+
`<div class="form" style="margin-top:10px"><label class="f">القيمة (${esc(D.set.cur||'')})<input type="number" inputmode="decimal" id="p_amt" value="${esc(p.amount)}" oninput="M.p.amount=this.value"></label><label class="f">التاريخ<input type="date" value="${esc(p.date)}" onchange="M.p.date=this.value"></label></div>
${multi()?`<div class="lbl">المدرسة</div><select onchange="M.p.school=this.value">${D.schools.map(s=>`<option value="${s.id}" ${p.school===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:''}
<div class="lbl">طريقة الدفع</div><div class="chips">${PAY_M.map(m=>`<button class="chip ${p.method===m?'on':''}" onclick="M.p.method='${m}';drawM()">${m}</button>`).join('')}</div>
<div class="lbl">ملاحظات</div><input value="${esc(p.note)}" oninput="M.p.note=this.value">
<div class="actions"><button class="btn" onclick="savePay()">حفظ</button><button class="btn ghost" onclick="closeM()">إلغاء</button>${M.id?`<button class="btn ghost danger" onclick="delPay('${M.id}')">${ic('trash',20)} حذف</button>`:''}</div>`};
function savePay(){const p=M.p,a=+p.amount;if(!(a>0))return toast('اكتب قيمة صحيحة أكبر من صفر');if(!p.date)return toast('اختر التاريخ');
 if(!M.id){const dup=D.pay.find(x=>x.date===p.date&&+x.amount===a&&x.school===p.school&&x.method===p.method&&x.note===p.note&&Date.now()-(x.created||0)<5000);if(dup)return closeM()}
 const o={...p,amount:a,school:p.school||curSchool()};
 if(M.id){const i=D.pay.findIndex(x=>x.id===M.id);if(i>=0)D.pay[i]={...D.pay[i],...o,modified:Date.now()};audit('pay-edit:'+M.id)}else{o.id=uid();o.created=Date.now();D.pay.push(o);audit('pay-add:'+o.id)}
 M=null;save();drawM();render();toast('تم حفظ الدفعة')}
function delPay(id){const p=D.pay.find(x=>x.id===id);if(!p)return closeM();D.pay=D.pay.filter(x=>x.id!==id);audit('pay-del:'+id);M=null;save();drawM();render();toast('تم حذف الدفعة',{label:'تراجع',fn:()=>{D.pay.push(p);save();render()}})}
