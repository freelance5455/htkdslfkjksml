/* notifications.js — جسر Capacitor: إشعارات أندرويد المحلية المجدولة، زر الرجوع، حالة التطبيق، PWA */
'use strict';
const nativeLN=()=>{try{return window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform()&&Capacitor.Plugins&&Capacitor.Plugins.LocalNotifications||null}catch(e){return null}};
const hid=s=>{let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return Math.abs(h)%2147483000+1};
function nativeBuild(){const now=new Date(),out=[],hz=new Date(now);hz.setDate(hz.getDate()+14);const push=(key,t,title,body)=>{if(t>now.getTime()+3000)out.push({t,id:hid(key),title,body})};
 for(let k=0;k<14;k++){const d=new Date(now);d.setDate(d.getDate()+k);const ds=ymd(d);if(vacOn(ds))continue;
  D.lessons.filter(l=>l.day===d.getDay()).forEach(l=>{const nm=`${sub(l.subject).name}${lab(l)?' ('+lab(l)+')':''} — ${sch(l.school).name}`,s=at(d,l.start).getTime(),e=at(d,l.end).getTime();
   if(D.set.pre>0)push(`L|${ds}|${l.id}|s`,s-D.set.pre*6e4,'حصة قادمة',`ستبدأ حصة ${nm} الساعة ${fmt(l.start)}`);
   if(D.set.atStart)push(`L|${ds}|${l.id}|b`,s,'بدأت الحصة',`بدأت الآن حصة ${nm}`);
   if(D.set.preEnd>0)push(`L|${ds}|${l.id}|e`,e-D.set.preEnd*6e4,'قرب نهاية الحصة',`ستنتهي حصة ${nm} الساعة ${fmt(l.end)}`)})}
 D.events.filter(e=>!e.done&&e.status!=='canc').forEach(e=>{const T=EV_TYPES[e.type]||EV_TYPES.other;
  evOccs(e,now,hz).forEach(ds=>{const st=evStart(e,ds).getTime();(e.rem||[]).forEach(m=>push(`E|${ds}|${e.id}|${m}`,st-m*6e4,T.n,`${evTitle(e)} — ${fd(ds)}${e.time?' '+fmt(e.time):''}`))});
  if(e.snz)push(`Z|${e.id}|${e.snz}`,e.snz,'تذكير مؤجّل',evTitle(e))});
 return out.sort((a,b)=>a.t-b.t).slice(0,450).map(o=>({id:o.id,title:o.title,body:o.body,channelId:'tt',schedule:{at:new Date(o.t),allowWhileIdle:true}}))}
let _ns=null;
window.nativeSync=function(){const LN=nativeLN();if(!LN)return;clearTimeout(_ns);_ns=setTimeout(async()=>{try{const p=await LN.checkPermissions();if(p.display!=='granted')return;
 try{await LN.createChannel({id:'tt',name:'تنبيهات الحصص والمهام',importance:5,visibility:1,vibration:true})}catch(e){}
 const pend=await LN.getPending();if(pend.notifications&&pend.notifications.length)await LN.cancel({notifications:pend.notifications});
 const list=nativeBuild();if(list.length)await LN.schedule({notifications:list});window.__nativeCount=list.length}catch(e){console.warn('native notifications',e)}},1500)};
const _askNotif0=window.askNotif;
window.askNotif=function(){const LN=nativeLN();if(!LN)return _askNotif0();beep();LN.requestPermissions().then(r=>{toast(r.display==='granted'?'تم السماح بالإشعارات؛ تُجدوَل تلقائياً للأسبوعين القادمين':'لم يُسمح بالإشعارات. فعّلها من إعدادات النظام للتطبيق.');nativeSync()}).catch(()=>toast('تعذر طلب الإذن'))};
EXT.boot=EXT.boot||[];
EXT.boot.push(()=>{
 /* زر الرجوع وحالة التطبيق */
 try{const A=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.App;if(A){
  A.addListener('backButton',()=>{if(M)return closeM();if(sset)return closePane();if(view!=='home')return go('home');A.exitApp()});
  A.addListener('appStateChange',s=>{if(s.isActive){tick();nativeSync()}})}}catch(e){}
 if(nativeLN())nativeSync();
 /* PWA */
 try{if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol))navigator.serviceWorker.register('service-worker.js').catch(()=>{})}catch(e){}
});
