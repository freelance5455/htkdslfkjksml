/* calendar.js — التقويم المدرسي واستيراد الخطة الدراسية (TXT/CSV/PDF) */
'use strict';
const CAL_T={start:['بداية العام','#1e9e5a'],end:['نهاية العام','#455a64'],study:['فترة دراسة','#2150e0'],exam:['امتحانات','#c4263a'],final:['اختبارات نهائية','#8e44ad'],holiday:['عطلة رسمية','#b45309'],break:['إجازة','#0f9d96'],other:['أخرى','#506078']};
let calY=new Date().getFullYear(),calM=new Date().getMonth(),calSel=null;
const dateOverlap=(c,ds)=>ds>=c.from&&ds<=(c.to||c.from);
function calMonthGo(n){const d=new Date(calY,calM+n,1);calY=d.getFullYear();calM=d.getMonth();calSel=null;render()}
function vCal(){const first=new Date(calY,calM,1),days=new Date(calY,calM+1,0).getDate(),lead=first.getDay(),td=ymd(new Date());
 const ms=ymd(first),me=ymd(new Date(calY,calM,days)),items=D.cal.filter(c=>c.from<=me&&(c.to||c.from)>=ms).sort((a,b)=>a.from.localeCompare(b.from));
 const evs={};D.events.filter(e=>!e.done).forEach(e=>evOccs(e,first,new Date(calY,calM,days)).forEach(ds=>{(evs[ds]=evs[ds]||[]).push(e)}));
 let cells='';for(let i=0;i<lead;i++)cells+='<div></div>';
 for(let d=1;d<=days;d++){const ds=ymd(new Date(calY,calM,d)),cs=D.cal.filter(c=>c.confirmed!==false&&dateOverlap(c,ds)),hasE=!!evs[ds],hol=cs.some(c=>c.type==='holiday'||c.type==='break'),wk=new Date(calY,calM,d).getDay()>=5;
  cells+=`<button onclick="calSel='${ds}';render()" style="min-height:48px;border-radius:12px;border:1.5px solid ${ds===td?'var(--pr)':'var(--bd)'};background:${calSel===ds?'var(--soft)':hol?'color-mix(in srgb,var(--warn) 12%,var(--card))':'var(--card)'};font-weight:800;opacity:${wk?.55:1};padding:2px"><div>${d}</div><div style="display:flex;gap:2px;justify-content:center;min-height:8px">${cs.slice(0,3).map(c=>`<i style="width:7px;height:7px;border-radius:50%;background:${CAL_T[c.type][1]}"></i>`).join('')}${hasE?'<i style="width:7px;height:7px;border-radius:2px;background:var(--tx)"></i>':''}</div></button>`}
 const sel=calSel,selC=sel?D.cal.filter(c=>dateOverlap(c,sel)):[],selE=sel?(evs[sel]||[]):[];
 return backBtn()+`<h2 class="pane-title">التقويم المدرسي</h2>
<div class="datebar"><button class="iconbtn" onclick="calMonthGo(-1)" aria-label="الشهر السابق">${ic('prev')}</button><div class="mid"><b>${MON[calM]} ${calY}</b></div><button class="iconbtn" onclick="calMonthGo(1)" aria-label="الشهر التالي">${ic('next')}</button></div>
<div class="card" style="padding:10px"><div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;direction:rtl;text-align:center"><small>أحد</small><small>اثنين</small><small>ثلاثاء</small><small>أربعاء</small><small>خميس</small><small>جمعة</small><small>سبت</small>${cells}</div>
<div class="chips" style="margin-top:10px">${Object.entries(CAL_T).map(([k,[n,c]])=>`<span class="tag" style="background:color-mix(in srgb,${c} 15%,var(--card));color:${c}">${n}</span>`).join('')}<span class="tag">▪ مهمة/موعد</span></div></div>
${sel?`<div class="card"><h3>${fd(sel)}</h3>${selC.map(c=>calItem(c)).join('')}${selE.map(e=>`<div class="irow"><span class="badge">${(EV_TYPES[e.type]||EV_TYPES.other).n}</span><b style="flex:1">${esc(evTitle(e))}</b><small>${e.time?fmt(e.time):''}</small></div>`).join('')}${!selC.length&&!selE.length?'<p class="mu">لا أحداث في هذا اليوم.</p>':''}<button class="btn ghost sm" onclick="openCal(null,'${sel}')">${ic('plus',16)} حدث في هذا اليوم</button></div>`:''}
<div class="bar" style="margin-bottom:12px"><button class="btn" style="flex:1" onclick="openCal()">${ic('plus',20)} حدث جديد</button><button class="btn ghost" onclick="$('#calfile').click()">${ic('upl',20)} استيراد خطة</button></div><input type="file" id="calfile" accept=".pdf,.txt,.csv,text/plain,text/csv,application/pdf" hidden onchange="calImport(this)">
<div class="card"><h3>أحداث ${MON[calM]} (${items.length})</h3>${items.map(calItem).join('')||'<p class="mu">لا أحداث. أضف يدوياً أو استورد خطة دراسية.</p>'}</div>
<small class="mu" style="display:block;line-height:1.9">العطل والإجازات «المؤكدة» توقف تنبيهات حصص الجدول في تلك الأيام تلقائياً (تبقى تنبيهات المهام). الخطة المستوردة لا تُعتمد إلا بعد مراجعتك.</small>`}
function calItem(c){const [n,col]=CAL_T[c.type]||CAL_T.other;return `<div class="irow" style="align-items:flex-start;margin:10px 0"><span class="sicon" style="color:${col}">${ic('cal',20)}</span><div style="flex:1"><b>${esc(c.title||n)}</b> ${tag(n,col)}${c.confirmed===false?tag('غير مؤكد','var(--warn)'):''}<br><small>${fd(c.from)}${c.to&&c.to!==c.from?' – '+fd(c.to):''}${c.note?' · '+esc(c.note):''}${c.source?' · المصدر: '+esc(c.source):''}</small></div><button class="iconbtn sm" onclick="openCal('${c.id}')" aria-label="تعديل">${ic('edit',18)}</button></div>`}
EXT.views.cal=vCal;
function openCal(id,ds){const ex=id&&D.cal.find(x=>x.id===id);M={type:'cal',id:ex?ex.id:null,c:ex?{...ex}:{type:'holiday',title:'',from:ds||ymd(new Date()),to:'',note:'',confirmed:true}};drawM()}
EXT.sheets.cal=function(){const c=M.c;return sheetHead(M.id?'تعديل حدث':'حدث تقويمي')+
`<div class="lbl">النوع</div><div class="chips">${Object.entries(CAL_T).map(([k,[n]])=>`<button class="chip ${c.type===k?'on':''}" onclick="M.c.type='${k}';drawM()">${n}</button>`).join('')}</div>
<label class="f" style="margin-top:12px">العنوان<input value="${esc(c.title)}" oninput="M.c.title=this.value"></label>
<div class="form"><label class="f">من<input type="date" value="${esc(c.from)}" onchange="M.c.from=this.value"></label><label class="f">إلى (اختياري)<input type="date" value="${esc(c.to||'')}" onchange="M.c.to=this.value"></label></div>
<label class="f">ملاحظات<input value="${esc(c.note||'')}" oninput="M.c.note=this.value"></label>
<label class="switch"><span><b>مؤكد</b><br><small>العطل غير المؤكدة لا توقف التنبيهات</small></span><input type="checkbox" ${c.confirmed!==false?'checked':''} onchange="M.c.confirmed=this.checked"><span class="tg"></span></label>
<div class="actions"><button class="btn" onclick="saveCal()">حفظ</button><button class="btn ghost" onclick="closeM()">إلغاء</button>${M.id?`<button class="btn ghost danger" onclick="delCal('${M.id}')">${ic('trash',20)} حذف</button>`:''}</div>`};
function saveCal(){const c=M.c;if(!c.from)return toast('اختر تاريخ البداية');if(c.to&&c.to<c.from)return toast('تاريخ النهاية قبل البداية');
 const o={...c,to:c.to||'',title:(c.title||'').trim()};if(M.id){const i=D.cal.findIndex(x=>x.id===M.id);D.cal[i]={...D.cal[i],...o}}else{o.id=uid();D.cal.push(o)}
 if(o.type==='start'&&!D.set.yearStart)D.set.yearStart=o.from;
 audit('cal:'+(o.id||M.id));M=null;save();drawM();render();toast('تم الحفظ')}
function delCal(id){const c=D.cal.find(x=>x.id===id);D.cal=D.cal.filter(x=>x.id!==id);M=null;save();drawM();render();toast('تم الحذف',{label:'تراجع',fn:()=>{D.cal.push(c);save();render()}})}

/* ---------- الاستيراد ---------- */
const AR_DIG='٠١٢٣٤٥٦٧٨٩',PE_DIG='۰۱۲۳۴۵۶۷۸۹';
const normDigits=s=>String(s).replace(/[٠-٩]/g,c=>AR_DIG.indexOf(c)).replace(/[۰-۹]/g,c=>PE_DIG.indexOf(c));
function calGuessType(t){if(/بداية\s*(العام|الدراسة)|بدء\s*(العام|الدراسة)|start/i.test(t))return'start';if(/نهاية\s*(العام|الدراسة)|end of/i.test(t))return'end';if(/نهائي|final/i.test(t))return'final';if(/امتحان|اختبار|exam/i.test(t))return'exam';if(/عطلة|يوم وطني|عيد|holiday/i.test(t))return'holiday';if(/إجازة|اجازة|break|vacation/i.test(t))return'break';if(/دراسة|فصل دراسي|semester|term/i.test(t))return'study';return'other'}
function calParseText(text,src){const out=[];const re=/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})|(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/g;const p2=n=>String(n).padStart(2,'0');
 normDigits(text).split(/\r?\n/).forEach(line=>{if(!line.trim())return;const ds=[];let m;re.lastIndex=0;
  while((m=re.exec(line))){const y=m[1]?+m[1]:+m[6],mo=m[1]?+m[2]:+m[5],d=m[1]?+m[3]:+m[4];if(mo>=1&&mo<=12&&d>=1&&d<=31&&y>=2000&&y<=2100)ds.push(`${y}-${p2(mo)}-${p2(d)}`)}
  if(!ds.length)return;const title=line.replace(re,' ').replace(/(من|إلى|الى|حتى|to|from)/gi,' ').replace(/[,;\t|–—-]+/g,' ').replace(/\s+/g,' ').trim();
  const a=ds[0],b=ds[1]&&ds[1]>=a?ds[1]:'';out.push({id:uid(),type:calGuessType(line),title:title.slice(0,80),from:a,to:b,note:'',confirmed:true,source:src,imported:Date.now(),pick:true})});return out}
function calImport(inp){const f=inp.files&&inp.files[0];inp.value='';if(!f)return;if(f.size>15*1048576)return toast('الملف كبير (الحد 15 ميغابايت)');
 if(/\.pdf$/i.test(f.name)||f.type==='application/pdf')return calImportPdf(f);
 const r=new FileReader();r.onload=()=>{M={type:'calimp',src:f.name,text:String(r.result),items:null};drawM()};r.onerror=()=>toast('تعذرت قراءة الملف');r.readAsText(f,'utf-8')}
function loadScript(u){return new Promise((ok,no)=>{const s=document.createElement('script');s.src=u;s.onload=ok;s.onerror=()=>no(new Error('load'));document.head.appendChild(s)})}
async function pdfText(file){if(!window.pdfjsLib){await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js');pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'}
 const doc=await pdfjsLib.getDocument({data:await file.arrayBuffer()}).promise,out=[];
 for(let i=1;i<=Math.min(doc.numPages,40);i++){const pg=await doc.getPage(i),tc=await pg.getTextContent();let y=null,line='';
  tc.items.forEach(it=>{const yy=it.transform[5];if(y!==null&&Math.abs(yy-y)>4){out.push(line);line=''}y=yy;line+=it.str+' '});out.push(line)}
 return out.join('\n')}
async function calImportPdf(f){toast('جارٍ قراءة PDF…');
 try{const t=await pdfText(f);if(t.replace(/\s/g,'').length<20){M={type:'calimp',src:f.name,text:'',items:null,scanned:true,file:f};drawM();return toast('لا يوجد نص قابل للاستخراج؛ قد يكون الملف ممسوحاً ضوئياً')}
  M={type:'calimp',src:f.name,text:t,items:null};drawM()}
 catch(e){M={type:'calimp',src:f.name,text:'',items:null,fail:true};drawM();toast('تعذر قراءة PDF (يحتاج إنترنتاً لتحميل المكتبة أول مرة). يمكنك لصق النص أو إدخال المواعيد يدوياً.')}}
async function calOcr(){const f=M.file;if(!f)return;toast('جارٍ OCR… قد يستغرق دقائق ويحتاج إنترنتاً');
 try{if(!window.Tesseract)await loadScript('https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js');
  if(!window.pdfjsLib){await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js');pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'}
  const doc=await pdfjsLib.getDocument({data:await f.arrayBuffer()}).promise;let all='';
  for(let i=1;i<=Math.min(doc.numPages,6);i++){const pg=await doc.getPage(i),vp=pg.getViewport({scale:2}),cv=document.createElement('canvas');cv.width=vp.width;cv.height=vp.height;await pg.render({canvasContext:cv.getContext('2d'),viewport:vp}).promise;
   const r=await Tesseract.recognize(cv,'ara+eng');all+=r.data.text+'\n'}
  M.text=all;M.scanned=false;drawM()}catch(e){toast('تعذر تشغيل OCR. أدخل المواعيد يدوياً أو الصق النص.')}}
EXT.sheets.calimp=function(){const m=M;
 if(!m.items)return sheetHead('استيراد خطة دراسية',esc(m.src))+(m.scanned?`<p class="mu" style="line-height:1.9">الملف يبدو ممسوحاً ضوئياً. يمكنك تجربة OCR (اختياري، يحتاج إنترنتاً وقد تكون الدقة ضعيفة)، أو لصق النص يدوياً.</p><button class="btn ghost block" onclick="calOcr()">تجربة OCR</button>`:'')+(m.fail?'<p class="mu">تعذر الاستخراج تلقائياً. الصق النص أدناه أو أضف الأحداث يدوياً.</p>':'')+
 `<div class="lbl">النص المستخرج (عدّله إن لزم؛ سطر لكل حدث وفيه تاريخ أو تاريخان)</div><textarea rows="9" dir="auto" oninput="M.text=this.value" placeholder="مثال:\nعطلة اليوم الوطني 2026-12-24\nامتحانات نصف العام 2027-01-10 إلى 2027-01-20">${esc(m.text)}</textarea>
<small>الصيغ المدعومة: 2026-12-24 أو 24/12/2026. الأرقام العربية الهندية تُحوَّل تلقائياً.</small>
<div class="actions"><button class="btn" onclick="calParseGo()">تحليل التواريخ</button><button class="btn ghost" onclick="closeM()">إلغاء</button></div>`;
 return sheetHead('مراجعة الأحداث المستخرجة',esc(m.src)+' — '+m.items.length)+`<p class="mu" style="line-height:1.9;margin:8px 0">لن يُحفظ شيء قبل موافقتك. ألغِ تحديد ما لا تريده، ثم راجع التواريخ والأنواع.</p>
${m.items.map((c,i)=>`<div class="card" style="box-shadow:none;padding:10px"><label class="switch"><b style="font-size:.92rem">${esc(c.title||'(بلا عنوان)')}</b><input type="checkbox" ${c.pick?'checked':''} onchange="M.items[${i}].pick=this.checked"><span class="tg"></span></label>
<div class="irow" style="margin:6px 0 0"><input type="date" value="${c.from}" onchange="M.items[${i}].from=this.value"><input type="date" value="${c.to||''}" onchange="M.items[${i}].to=this.value"></div>
<select style="margin-top:6px" onchange="M.items[${i}].type=this.value">${Object.entries(CAL_T).map(([k,[n]])=>`<option value="${k}" ${c.type===k?'selected':''}>${n}</option>`).join('')}</select></div>`).join('')||'<p class="mu">لم أجد أي تاريخ في النص.</p>'}
<div class="actions"><button class="btn" ${m.items.some(x=>x.pick)?'':'disabled style="opacity:.5"'} onclick="calSaveImp()">حفظ المحدد</button><button class="btn ghost" onclick="M.items=null;drawM()">رجوع للنص</button></div>`};
function calParseGo(){M.items=calParseText(M.text,M.src);if(!M.items.length)toast('لم أجد تواريخ؛ تأكد من الصيغة أو أدخل الأحداث يدوياً');drawM()}
function calSaveImp(){let n=0;M.items.filter(x=>x.pick).forEach(x=>{if(!x.from)return;if(D.cal.some(c=>c.type===x.type&&c.from===x.from&&(c.to||'')===(x.to||'')&&c.title===x.title))return;const o={...x};delete o.pick;D.cal.push(o);n++;if(o.type==='start'&&!D.set.yearStart)D.set.yearStart=o.from});
 D.imports.push({id:uid(),t:Date.now(),kind:'calendar',src:M.src,n});M=null;save();drawM();render();toast('تمت إضافة '+n+' حدثاً (المكرر تُجوهل)')}
