/* tasks.js — المهام والامتحانات: فلاتر، ترتيب، حالات، تأجيل التنبيه */
'use strict';
let tf={period:'all',type:'',school:'',subject:'',status:'',sort:'date'};
const prioRank={h:0,m:1,l:2};
const isLate=e=>!e.done&&e.status!=='canc'&&(!e.rep||e.rep==='none')&&evEnd(e,e.date)<Date.now();
function inPeriod(ds,p){if(p==='all')return true;const n=new Date(),t=ymd(n);if(p==='today')return ds===t;
 if(p==='week'){const a=weekStart(n),b=new Date(a);b.setDate(b.getDate()+6);return ds>=ymd(a)&&ds<=ymd(b)}
 if(p==='month')return ds.slice(0,7)===t.slice(0,7);return true}
function setTf(k,v){tf[k]=v;render()}
function vRem(){
 const now=Date.now(),td=ymd(new Date());
 let L=D.events.map(e=>{const ds=nextOcc(e);return{e,ds,st:evStart(e,ds).getTime()}});
 const all=L;
 const flt=x=>{const e=x.e;return (!tf.type||e.type===tf.type)&&(!tf.school||e.school===tf.school)&&(!tf.subject||e.subject===tf.subject)&&(!tf.status||(e.status||'new')===tf.status)&&inPeriod(x.ds,tf.period)};
 L=L.filter(flt);
 const up=L.filter(x=>isUp(x.e)&&!isLate(x.e)),late=L.filter(x=>isLate(x.e)),past=L.filter(x=>!isUp(x.e)&&!isLate(x.e));
 const srt=a=>a.sort((x,y)=>tf.sort==='prio'?((prioRank[x.e.prio||'m']-prioRank[y.e.prio||'m'])||(x.st-y.st)):(x.st-y.st));
 srt(up);srt(late);past.sort((a,b)=>b.st-a.st);
 const show=remFlt==='up'?up:remFlt==='late'?late:remFlt==='past'?past:[...late,...up,...past];
 const tm=new Date();tm.setDate(tm.getDate()+1);const tmr=ymd(tm);
 const card=({e,ds,st})=>{const T=EV_TYPES[e.type]||EV_TYPES.other,up1=isUp(e),lt=isLate(e),when=ds===td?'اليوم':ds===tmr?'غداً':fd(ds),pr=e.prio||'m',sts=e.status||'new';
  return `<div class="card ev ${up1||lt?'':'done'}" style="border-inline-start:6px solid ${pr==='h'?'var(--no)':T.c}">
<div class="bar" style="justify-content:space-between"><span class="badge" style="background:color-mix(in srgb,${T.c} 14%,var(--card));color:${T.c}">${ic(T.i,14)} ${T.n}</span><span class="bar">${pr==='h'?'<span class="badge no">مهم</span>':''}<span class="badge ${sts==='done'?'ok':sts==='canc'?'no':sts==='post'?'warn':''}">${EV_STATUS[sts]}</span>${lt?'<span class="badge no">متأخرة</span>':up1?`<span class="badge ${st-now<864e5?'warn':''}">${relTxt(st-now)}</span>`:''}</span></div>
<h3>${esc(evTitle(e))}</h3>
<div class="mu" style="font-size:.9rem">${when} · ${e.time?fmt(e.time):'طوال اليوم'}${e.rep&&e.rep!=='none'?' · '+REP_NAMES[e.rep]:''}${e.subject?' · '+esc(sub(e.subject).name):''}${e.lbl?' · '+esc(e.lbl):''}${e.school&&multi()?' · '+esc(sch(e.school).name):''}</div>
<div class="meta">${(e.rem||[]).length?(e.rem||[]).map(m=>`<span class="badge">${ic('bell',13)} ${remTxt(m)}</span>`).join(''):'<span class="badge">بدون تذكير</span>'}${e.snz&&e.snz>now?`<span class="badge warn">مؤجّل التنبيه إلى ${fmt(fromMin(new Date(e.snz).getHours()*60+new Date(e.snz).getMinutes()))}</span>`:''}</div>
${e.note?`<p class="mu" style="font-size:.9rem;margin-bottom:8px">${esc(e.note)}</p>`:''}
<div class="bar"><button class="btn ghost sm" onclick="togDone('${e.id}')">${ic('check',16)} ${e.done?'إلغاء التم':'تم'}</button><button class="btn ghost sm" onclick="openSnz('${e.id}')">${ic('clock',16)} تأجيل</button><button class="btn ghost sm" onclick="openEv('${e.id}')">${ic('edit',16)} تعديل</button><button class="btn ghost sm" onclick="icsOne('${e.id}')">${ic('cal',16)} للتقويم</button></div></div>`};
 const nToday=all.filter(x=>isUp(x.e)&&x.ds===td).length,nLate=all.filter(x=>isLate(x.e)).length,n7=all.filter(x=>isUp(x.e)&&x.st-now<7*864e5).length;
 const selT=`<select onchange="setTf('type',this.value)"><option value="">كل الأنواع</option>${Object.keys(EV_TYPES).map(k=>`<option value="${k}" ${tf.type===k?'selected':''}>${EV_TYPES[k].n}</option>`).join('')}</select>`;
 const selS=`<select onchange="setTf('status',this.value)"><option value="">كل الحالات</option>${Object.keys(EV_STATUS).map(k=>`<option value="${k}" ${tf.status===k?'selected':''}>${EV_STATUS[k]}</option>`).join('')}</select>`;
 const selSub=`<select onchange="setTf('subject',this.value)"><option value="">كل المواد</option>${D.subjects.map(s=>`<option value="${s.id}" ${tf.subject===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`;
 const selSch=multi()?`<select onchange="setTf('school',this.value)"><option value="">كل المدارس</option>${D.schools.map(s=>`<option value="${s.id}" ${tf.school===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:'';
 return `<h2 class="pane-title">المهام والامتحانات</h2>
<div class="bar" style="margin-bottom:14px"><button class="btn" style="flex:1" onclick="openEv()">${ic('plus',20)} مهمة / موعد جديد</button><button class="btn ghost" onclick="openIcs()">${ic('cal',20)}</button></div>
<div class="stats three"><div class="stat"><b>${nToday}</b><span>اليوم</span></div><div class="stat"><b style="color:var(--no)">${nLate}</b><span>متأخرة</span></div><div class="stat"><b>${n7}</b><span>خلال 7 أيام</span></div></div>
<div class="seg" style="display:flex;margin-bottom:12px">${[['up','القادمة'],['late','المتأخرة'],['past','المنتهية'],['all','الكل']].map(([k,t])=>`<button style="flex:1;padding:8px 4px" class="${remFlt===k?'on':''}" onclick="remFlt='${k}';render()">${t}</button>`).join('')}</div>
<details class="card" style="padding:12px"><summary>تصفية وترتيب${tf.type||tf.status||tf.subject||tf.school||tf.period!=='all'?' (مفعّلة)':''}</summary><div style="margin-top:12px"><div class="seg" style="display:flex;margin-bottom:10px">${[['all','الكل'],['today','اليوم'],['week','الأسبوع'],['month','الشهر']].map(([k,t])=>`<button style="flex:1;padding:8px 4px" class="${tf.period===k?'on':''}" onclick="setTf('period','${k}')">${t}</button>`).join('')}</div>
<div class="form">${selT}${selS}${selSub}${selSch}</div><div class="seg" style="display:flex;margin-top:10px"><button style="flex:1" class="${tf.sort==='date'?'on':''}" onclick="setTf('sort','date')">حسب قرب الموعد</button><button style="flex:1" class="${tf.sort==='prio'?'on':''}" onclick="setTf('sort','prio')">حسب الأهمية</button></div>
<button class="btn ghost sm" style="margin-top:10px" onclick="tf={period:'all',type:'',school:'',subject:'',status:'',sort:'date'};render()">مسح التصفية</button></div></details>
${show.length?show.map(card).join(''):`<div class="card empty">${ic('bell',40)}<p>لا توجد عناصر هنا.<br>أضف امتحاناً أو واجباً أو اجتماعاً وسيذكّرك التطبيق به.</p></div>`}
<p class="mu" style="font-size:.82rem;line-height:1.8">التنبيهات داخل التطبيق تعمل والصفحة مفتوحة. في نسخة APK تُجدوَل إشعارات أندرويد المحلية فتصل والتطبيق مغلقاً.</p>`}
EXT.views.rem=vRem;

/* تأجيل التنبيه */
EXT.sheets.snz=function(){const e=D.events.find(x=>x.id===M.id);if(!e)return sheetHead('تأجيل')+'<p>غير موجود</p>';
 const opts=[[10,'بعد 10 دقائق'],[60,'بعد ساعة'],[180,'بعد 3 ساعات'],[1440,'غداً في نفس الوقت']];
 return sheetHead('تأجيل التنبيه',esc(evTitle(e)))+`<div class="chips" style="margin:12px 0">${opts.map(([m,t])=>`<button class="chip" onclick="doSnz(${m})">${t}</button>`).join('')}</div>
<div class="lbl">أو حدّد وقتاً جديداً</div><div class="irow"><input type="datetime-local" id="snz_at"><button class="btn" onclick="doSnzAt()">تأجيل</button></div>
<div class="actions"><button class="btn ghost" onclick="closeM()">إلغاء</button></div>`};
function openSnz(id){M={type:'snz',id};drawM()}
function doSnz(min){const e=D.events.find(x=>x.id===M.id);if(!e)return;e.snz=Date.now()+min*6e4;audit('snooze:'+e.id);M=null;save();drawM();render();toast('سيُذكّرك التطبيق '+relTxt(min*6e4))}
function doSnzAt(){const v=$('#snz_at').value;if(!v)return toast('اختر التاريخ والوقت');const t=new Date(v).getTime();if(!(t>Date.now()))return toast('اختر وقتاً في المستقبل');
 const e=D.events.find(x=>x.id===M.id);e.snz=t;M=null;save();drawM();render();toast('تم تأجيل التنبيه')}
const _tickEv0=window.tickEvents;
window.tickEvents=function(now){_tickEv0(now);let ch=false;
 D.events.forEach(e=>{if(e.snz&&now.getTime()>=e.snz){const T=EV_TYPES[e.type]||EV_TYPES.other,loop=e.loop==='on'?true:e.loop==='off'?false:!!D.set.loopEv;
  delete e.snz;ch=true;if(!e.done&&e.status!=='canc')notify(`تذكير مؤجّل — ${T.n}: ${evTitle(e)}`,{sound:e.snd&&e.snd!=='def'?e.snd:D.set.evTone,loop})}});if(ch)save()};
