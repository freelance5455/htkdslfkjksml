/* board.js — السبورة الرقمية (Canvas): قلم، ممحاة، ألوان، أحجام، تراجع/إعادة، نص، حفظ PNG */
'use strict';
const BD={strokes:[],redo:[],bg:null,bgc:'#ffffff',tool:'pen',color:'#111111',size:4,mode:'',text:'',W:1200,H:800,layer:null,cur:null,title:''};
const BD_COL=['#111111','#e74c3c','#2f6fed','#1e9e5a','#d97706','#8e44ad','#ffffff'];
function bdDrawStroke(x,s){x.save();
 if(s.tool==='text'){x.globalCompositeOperation='source-over';x.fillStyle=s.color;x.font='bold '+(s.size*5)+'px "Noto Sans Arabic",Tahoma,Arial,sans-serif';x.textBaseline='top';x.direction='rtl';x.textAlign='right';s.text.split('\n').forEach((ln,i)=>x.fillText(ln,s.x,s.y+i*s.size*6.4));x.restore();return}
 x.globalCompositeOperation=s.tool==='eraser'?'destination-out':'source-over';x.strokeStyle=s.color;x.fillStyle=s.color;x.lineWidth=s.size*(s.tool==='eraser'?4:1.4);x.lineCap='round';x.lineJoin='round';
 const p=s.pts;if(p.length===1){x.beginPath();x.arc(p[0][0],p[0][1],x.lineWidth/2,0,7);x.fill()}else{x.beginPath();x.moveTo(p[0][0],p[0][1]);for(let i=1;i<p.length;i++)x.lineTo(p[i][0],p[i][1]);x.stroke()}x.restore()}
function bdRebuild(){const l=BD.layer;l.getContext('2d').clearRect(0,0,BD.W,BD.H);BD.strokes.forEach(s=>bdDrawStroke(l.getContext('2d'),s))}
function bdPaint(){const c=$('#bd_cv');if(!c)return;const x=c.getContext('2d');x.fillStyle=BD.bgc;x.fillRect(0,0,BD.W,BD.H);if(BD.bg){const sc=Math.min(BD.W/BD.bg.naturalWidth,BD.H/BD.bg.naturalHeight),w=BD.bg.naturalWidth*sc,h=BD.bg.naturalHeight*sc;x.drawImage(BD.bg,(BD.W-w)/2,(BD.H-h)/2,w,h)}x.drawImage(BD.layer,0,0);if(BD.cur&&BD.cur.tool!=='text'){}}
function bdInit(){const c=$('#bd_cv');if(!c)return;c.width=BD.W;c.height=BD.H;if(!BD.layer){BD.layer=document.createElement('canvas');BD.layer.width=BD.W;BD.layer.height=BD.H}bdRebuild();bdPaint();
 const pos=e=>{const r=c.getBoundingClientRect();return[(e.clientX-r.left)*BD.W/r.width,(e.clientY-r.top)*BD.H/r.height]};
 c.onpointerdown=e=>{e.preventDefault();const[x,y]=pos(e);
  if(BD.mode==='text'&&BD.text){BD.strokes.push({tool:'text',x,y,text:BD.text,color:BD.color,size:BD.size});BD.redo=[];BD.mode='';BD.text='';bdRebuild();bdPaint();bdUi();return}
  c.setPointerCapture(e.pointerId);BD.cur={tool:BD.tool,color:BD.color,size:BD.size,pts:[[x,y]]};bdDrawStroke(BD.layer.getContext('2d'),BD.cur);bdPaint()};
 c.onpointermove=e=>{if(!BD.cur)return;e.preventDefault();const[x,y]=pos(e),p=BD.cur.pts,l=p[p.length-1];if(Math.hypot(x-l[0],y-l[1])<1.5)return;p.push([x,y]);const g=BD.layer.getContext('2d');bdDrawStroke(g,{...BD.cur,pts:[l,[x,y]]});bdPaint()};
 const end=e=>{if(!BD.cur)return;BD.strokes.push(BD.cur);BD.cur=null;BD.redo=[];bdUi()};c.onpointerup=end;c.onpointercancel=end}
function bdUi(){const u=$('#bd_undo'),r=$('#bd_redo');if(u)u.disabled=!BD.strokes.length;if(r)r.disabled=!BD.redo.length}
function bdUndo(){if(!BD.strokes.length)return;BD.redo.push(BD.strokes.pop());bdRebuild();bdPaint();bdUi()}
function bdRedo(){if(!BD.redo.length)return;BD.strokes.push(BD.redo.pop());bdRebuild();bdPaint();bdUi()}
function bdClear(){if(!BD.strokes.length&&!BD.bg)return;ask('مسح السبورة بالكامل؟','مسح الكل',()=>{BD.strokes=[];BD.redo=[];BD.bg=null;render()})}
function bdSet(k,v){BD[k]=v;if(k==='tool'&&v!=='text')BD.mode='';render()}
function bdBg(c){BD.bgc=c;if(c==='#1f4d36'&&BD.color==='#111111')BD.color='#ffffff';if(c==='#ffffff'&&BD.color==='#ffffff')BD.color='#111111';render()}
function bdOpenText(){M={type:'bdtext',t:BD.text||''};drawM()}
EXT.sheets.bdtext=function(){return sheetHead('إدراج نص')+`<textarea rows="3" dir="auto" id="bd_t" style="margin-top:10px" oninput="M.t=this.value" placeholder="اكتب النص ثم اضغط موضعه على السبورة">${esc(M.t)}</textarea><small>يُستعمل اللون والحجم المحددان حالياً.</small><div class="actions"><button class="btn" onclick="bdTextGo()">إدراج</button><button class="btn ghost" onclick="closeM()">إلغاء</button></div>`};
function bdTextGo(){if(!(M.t||'').trim())return toast('اكتب النص أولاً');BD.text=M.t.trim();BD.mode='text';M=null;drawM();render();toast('اضغط على السبورة لتحديد مكان النص')}
function bdExport(){const c=document.createElement('canvas');c.width=BD.W;c.height=BD.H;const x=c.getContext('2d');x.fillStyle=BD.bgc;x.fillRect(0,0,BD.W,BD.H);if(BD.bg){const sc=Math.min(BD.W/BD.bg.naturalWidth,BD.H/BD.bg.naturalHeight),w=BD.bg.naturalWidth*sc,h=BD.bg.naturalHeight*sc;x.drawImage(BD.bg,(BD.W-w)/2,(BD.H-h)/2,w,h)}x.drawImage(BD.layer,0,0);return c}
async function bdSave(){if(!BD.strokes.length&&!BD.bg)return toast('السبورة فارغة');
 try{const b=await blobOf(bdExport(),'image/png'),id=await imgPut(b);const t=(BD.title||'').trim()||('سبورة '+fd(new Date()));
  D.docs.push({id:uid(),kind:'board',title:t,desc:'',tags:['سبورة'],school:curSchool(),cls:'',subject:'',date:ymd(new Date()),pages:[id],created:Date.now()});save();toast('تم حفظ السبورة كصورة في «المستندات»');render()}catch(e){toast('تعذر الحفظ (المساحة ممتلئة؟)')}}
function bdDownload(){blobOf(bdExport(),'image/png').then(b=>{dlBlob(b,'board_'+ymd(new Date())+'.png');toast('تم تنزيل PNG')})}
async function bdShare(){const b=await blobOf(bdExport(),'image/png');shareAny({file:new File([b],'board.png',{type:'image/png'}),title:BD.title||'السبورة'})}
async function bdLoad(id){const d=D.docs.find(x=>x.id===id);if(!d||!d.pages[0])return;const u=await imgUrl(d.pages[0]);BD.bg=await loadImg(u);BD.strokes=[];BD.redo=[];BD.title=d.title;render();toast('تم فتح السبورة المحفوظة للتعديل (تُحفظ كنسخة جديدة)')}
function vBoard(){const boards=D.docs.filter(d=>d.kind==='board').sort((a,b)=>(b.created||0)-(a.created||0)).slice(0,12);
 return backBtn()+`<h2 class="pane-title">السبورة الرقمية</h2>
<canvas id="bd_cv" class="bd" width="1200" height="800" aria-label="السبورة" style="${BD.bgc==='#ffffff'?'':'background:'+BD.bgc}"></canvas>
<div class="bar" style="margin:10px 0">${[['pen','pen','قلم'],['eraser','eraser','ممحاة']].map(([k,i,n])=>`<button class="chip ${BD.tool===k&&BD.mode!=='text'?'on':''}" onclick="bdSet('tool','${k}')">${n}</button>`).join('')}<button class="chip ${BD.mode==='text'?'on':''}" onclick="bdOpenText()">${ic('text',16)} نص</button><button class="iconbtn sm" id="bd_undo" onclick="bdUndo()" ${BD.strokes.length?'':'disabled style="opacity:.4"'} aria-label="تراجع">${ic('undo',18)}</button><button class="iconbtn sm" id="bd_redo" onclick="bdRedo()" ${BD.redo.length?'':'disabled style="opacity:.4"'} aria-label="إعادة">${ic('redo',18)}</button><button class="iconbtn sm" onclick="bdClear()" aria-label="مسح الكل">${ic('trash',18)}</button></div>
<div class="bar" style="margin-bottom:10px">${BD_COL.map(c=>`<button class="sw" style="background:${c};width:38px;height:38px;${BD.color===c?'border-color:var(--pr)':'border-color:var(--bd)'}" onclick="bdSet('color','${c}')" aria-label="لون"></button>`).join('')}<input type="color" value="${BD.color}" onchange="bdSet('color',this.value)" aria-label="لون مخصص"></div>
<label class="f"><span class="rng"><span>حجم القلم</span><b>${BD.size}</b></span><input type="range" min="1" max="24" value="${BD.size}" oninput="BD.size=+this.value;this.previousElementSibling.lastElementChild.textContent=this.value"></label>
<div class="seg" style="display:flex;margin-bottom:10px"><button style="flex:1" class="${BD.bgc==='#ffffff'?'on':''}" onclick="bdBg('#ffffff')">خلفية بيضاء</button><button style="flex:1" class="${BD.bgc==='#1f4d36'?'on':''}" onclick="bdBg('#1f4d36')">سبورة خضراء</button></div>
<input placeholder="عنوان السبورة (اختياري)" value="${esc(BD.title)}" oninput="BD.title=this.value" style="margin-bottom:10px">
<div class="bar"><button class="btn" onclick="bdSave()">${ic('check',18)} حفظ</button><button class="btn ghost" onclick="bdDownload()">${ic('down',18)} PNG</button><button class="btn ghost" onclick="bdShare()">${ic('share',18)} مشاركة</button></div>
${boards.length?`<div class="card" style="margin-top:14px"><h3>سبورات محفوظة</h3><div class="grid2">${boards.map(d=>`<button class="card" style="padding:8px;margin:0;text-align:right" onclick="bdLoad('${d.id}')"><img class="thumb" data-iid="${d.pages[0]}" alt=""><small style="display:block;margin-top:4px">${esc(d.title)}</small></button>`).join('')}</div></div>`:''}
<small class="mu" style="display:block;margin-top:10px">الرسم الحالي يبقى محفوظاً في الذاكرة أثناء التنقل بين الصفحات، لكنه يُفقد عند إغلاق التطبيق ما لم تضغط «حفظ».</small>`}
EXT.views.board=vBoard;
EXT.after.push(()=>{if(view==='board')bdInit()});
