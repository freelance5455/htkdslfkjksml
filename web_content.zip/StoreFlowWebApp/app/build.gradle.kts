plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.storeflow.downloader"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.storeflow.downloader"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
