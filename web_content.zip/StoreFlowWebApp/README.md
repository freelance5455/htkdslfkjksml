# StoreFlow Android WebView wrapper

This Android project packages the exact StoreFlow HTML website as a local asset inside an Android app. The app opens offline UI from `app/src/main/assets/index.html`; the website's current extraction status remains a prototype (it does not yet return real package download URLs). WebView downloads are routed to Android DownloadManager.


## Build APK
Open this folder in Android Studio, let Gradle sync, then choose **Build > Build APK(s)**. Output is typically `app/build/outputs/apk/debug/app-debug.apk`.

Requirements: Android Studio, Android SDK Platform 35, Java 17+.
