# Como transformar o GG Touch Free Fire em APK

O projeto já está configurado com **Capacitor** (`capacitor.config.json`) e a pasta
`android/` já existe, com ícone e permissão de vibração. Falta só compilar.

- **ID do app:** `com.ggtouch.freefire`
- **Nome:** GG Touch FF
- **Requisito:** Java 21 (JDK) para compilar

---

## Opção A — Android Studio (mais fácil)

1. Instale o [Android Studio](https://developer.android.com/studio) (ele já traz o JDK e o SDK).
2. Na pasta do projeto, rode:
   ```bash
   npm install
   npm run build
   npx cap sync android
   npx cap open android
   ```
3. No Android Studio, aguarde o Gradle sincronizar e vá em
   **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
4. Clique em **locate** no aviso que aparece. O arquivo é:
   `android/app/build/outputs/apk/debug/app-debug.apk`
5. Passe o APK para o celular e instale (ative "Instalar apps desconhecidos").

## Opção B — Só terminal

Com JDK 21 e Android SDK instalados (`ANDROID_HOME` configurado):

```bash
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

O APK sai em `android/app/build/outputs/apk/debug/app-debug.apk`.

## Opção C — Na nuvem, sem instalar nada (GitHub Actions)

1. Crie um repositório no GitHub e envie este projeto.
2. Abra a aba **Actions ▸ Gerar APK ▸ Run workflow**
   (o arquivo `.github/workflows/build-apk.yml` já está pronto).
3. Quando terminar (uns 4–6 min), baixe o APK em **Artifacts ▸ gg-touch-freefire-apk**.

---

## Depois de mudar o app

Sempre que alterar o código, repita:

```bash
npm run build
npx cap sync android
```

e gere o APK de novo.

## APK assinado (para publicar na Play Store)

O `app-debug.apk` serve para uso pessoal. Para publicar:

1. No Android Studio: **Build ▸ Generate Signed Bundle / APK**.
2. Crie uma *keystore* e **guarde-a e a senha em local seguro**. Sem elas você não consegue atualizar o app.
3. Escolha **Android App Bundle (.aab)**, que é o formato exigido pela Play Store.

## Observações

- O botão **Baixar arquivo** (Perfis) pode não funcionar dentro do WebView do Android.
  Use **Copiar JSON** para fazer backup.
- Os perfis ficam salvos no `localStorage` do app. Desinstalar apaga tudo, então exporte antes.
- O app **não injeta toque dentro do Free Fire**. Ele calcula e simula a sensibilidade, e você
  copia os números para as configurações do jogo.
