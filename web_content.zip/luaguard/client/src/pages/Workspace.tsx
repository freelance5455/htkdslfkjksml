import { useParams } from "wouter";
import { ArrowLeft, LockKeyhole } from "lucide-react";
import AdminMenu from "@/components/AdminMenu";
import { trpc } from "@/lib/trpc";
import { CodeWorkspace } from "@/pages/Home";

export default function Workspace() {
  const { mode = "protect" } = useParams<{ mode: string }>();
  const safeMode = mode === "share" ? "share" : "protect";
  const status = trpc.admin.status.useQuery(undefined, { staleTime: 2_000 });

  return (
    <div className="min-h-screen bg-[#080a0e] text-white">
      <div className="pointer-events-none fixed inset-0 -z-0 opacity-60 [background-image:linear-gradient(rgba(255,255,255,0.028)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.028)_1px,transparent_1px)] [background-size:64px_64px]" />
      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-5 py-6 sm:px-8"><a href="/" className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#d7ff72] font-mono text-sm font-black text-[#11130e]">LG</span><span className="text-sm font-bold tracking-[0.14em] text-white">LUAGUARD<span className="text-[#d7ff72]">/</span></span></a><AdminMenu /></header>
      <main className="relative z-10 mx-auto max-w-6xl px-5 pb-20 pt-8 sm:px-8 sm:pt-14">
        {status.isLoading ? <div className="mx-auto max-w-5xl rounded-[28px] border border-white/10 bg-[#11131a] p-10 text-center text-sm text-white/50">Checking admin session...</div> : status.data?.authenticated ? <CodeWorkspace mode={safeMode} onClose={() => window.location.assign("/")} /> : <div className="mx-auto max-w-xl rounded-[28px] border border-white/10 bg-[#11131a] p-8 text-center shadow-[0_24px_80px_rgba(0,0,0,0.3)] sm:p-12"><span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#d7ff72]/10 text-[#d7ff72]"><LockKeyhole size={25} /></span><h1 className="mt-6 text-3xl font-semibold tracking-[-0.05em] text-white">Admin access required</h1><p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-white/45">Open the three-line menu, enter the server-side access key, then return here to use this private workspace.</p><div className="mt-7 flex items-center justify-center gap-3"><a href="/" className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-4 py-3 text-sm font-semibold text-white/70 hover:border-white/25 hover:text-white"><ArrowLeft size={16} /> Back home</a><span className="text-xs text-white/30">Use the menu above</span></div></div>}
      </main>
    </div>
  );
}
