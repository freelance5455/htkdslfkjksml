import { useEffect, useState } from "react";
import { ArrowLeft, ExternalLink, LockKeyhole, ShieldAlert } from "lucide-react";
import AdminMenu from "@/components/AdminMenu";
import { trpc } from "@/lib/trpc";

const COMMUNITY_URL = "https://tasu-community.tasuhub.workers.dev/";

export default function PublicShare() {
  const { data: status } = trpc.admin.status.useQuery(undefined, { staleTime: 2_000 });
  const publicName = window.location.pathname.split("/").filter(Boolean).pop() || "unknown";
  const [content, setContent] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!status?.authenticated) return;
    let cancelled = false;
    setLoading(true);
    fetch(`/raw/${encodeURIComponent(publicName)}`, { credentials: "include" })
      .then(async response => { if (!response.ok) throw new Error(await response.text()); return response.text(); })
      .then(value => { if (!cancelled) setContent(value); })
      .catch(reason => { if (!cancelled) setError(reason instanceof Error ? reason.message : "Unable to load code"); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [publicName, status?.authenticated]);

  return (
    <div className="min-h-screen bg-[#080a0e] text-white">
      <div className="pointer-events-none fixed inset-0 -z-0 opacity-60 [background-image:linear-gradient(rgba(255,255,255,0.028)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.028)_1px,transparent_1px)] [background-size:64px_64px]" />
      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-5 py-6 sm:px-8"><a href="/" className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#d7ff72] font-mono text-sm font-black text-[#11130e]">LG</span><span className="text-sm font-bold tracking-[0.14em] text-white">LUAGUARD<span className="text-[#d7ff72]">/</span></span></a><AdminMenu /></header>
      <main className="relative z-10 mx-auto max-w-6xl px-5 pb-20 pt-14 sm:px-8 sm:pt-24">
        {status?.authenticated ? <section className="mx-auto max-w-5xl rounded-[28px] border border-[#d7ff72]/20 bg-[#0e1117] p-5 shadow-[0_24px_80px_rgba(0,0,0,0.3)] sm:p-8"><div className="flex items-start justify-between gap-4 border-b border-white/[0.08] pb-6"><div><div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-[#d7ff72]"><span className="h-1.5 w-1.5 rounded-full bg-[#d7ff72]" /> Admin preview</div><h1 className="mt-3 text-3xl font-semibold tracking-[-0.05em] text-white">{publicName}</h1><p className="mt-2 text-sm text-white/40">Private content preview · plain text delivery</p></div><a href="/" className="rounded-lg p-2 text-white/40 hover:bg-white/[0.06] hover:text-white" aria-label="Back home"><ArrowLeft size={18} /></a></div><div className="mt-6 overflow-auto rounded-2xl border border-white/[0.08] bg-[#090b10] p-5"><pre className="whitespace-pre-wrap font-mono text-[13px] leading-6 text-[#d9e2cf]">{loading ? "Loading protected text..." : error || content}</pre></div></section> : <section className="mx-auto max-w-xl text-center"><span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-red-300/20 bg-red-300/[0.06] text-red-200"><ShieldAlert size={27} /></span><p className="mt-7 text-[11px] uppercase tracking-[0.2em] text-white/35">Protected delivery</p><h1 className="mt-4 text-4xl font-semibold tracking-[-0.06em] text-white">Browser access restricted.</h1><p className="mx-auto mt-4 max-w-md text-sm leading-7 text-white/45">This resource is available only to an authorized LuaGuard session or its private loader token. Use the menu to unlock admin access, or join the community for updates.</p><div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row"><a href={COMMUNITY_URL} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-[#d7ff72] px-5 py-3 text-sm font-semibold text-[#10130e] hover:bg-[#e5ffae]"><ExternalLink size={16} /> Join Community</a><a href="/" className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-5 py-3 text-sm font-semibold text-white/70 hover:border-white/25 hover:text-white"><LockKeyhole size={16} /> Admin menu</a></div></section>}
      </main>
    </div>
  );
}
