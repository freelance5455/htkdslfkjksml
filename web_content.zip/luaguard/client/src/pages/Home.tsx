import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  Check,
  Clipboard,
  Code2,
  ExternalLink,
  FileCode2,
  FileText,
  Link2,
  LockKeyhole,
  ShieldCheck,
  Sparkles,
  Upload,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import AdminMenu from "@/components/AdminMenu";
import { trpc } from "@/lib/trpc";

const COMMUNITY_URL = "https://tasu-community.tasuhub.workers.dev/";
const MAX_CODE_BYTES = 500_000;

type Mode = "protect" | "share";
type ShareResult = { filename: string; publicName: string; url: string; loaderSnippet: string };

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function readFile(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("Unable to read this file"));
    reader.readAsText(file);
  });
}

function copyText(text: string, label: string) {
  navigator.clipboard.writeText(text).then(() => toast.success(`${label} copied`), () => toast.error("Clipboard access was denied"));
}

function FeatureCard({ icon, index, title, description, accent, onClick }: { icon: React.ReactNode; index: string; title: string; description: string; accent: string; onClick: () => void }) {
  return <button type="button" onClick={onClick} className="group relative min-h-[190px] overflow-hidden rounded-[24px] border border-white/[0.08] bg-[#11131a]/80 p-6 text-left transition-all duration-200 hover:-translate-y-1 hover:border-white/20 hover:bg-[#171a23] active:scale-[0.98]"><div className={`absolute -right-10 -top-10 h-28 w-28 rounded-full blur-3xl opacity-20 ${accent}`} /><div className="relative flex h-full flex-col justify-between gap-8"><div className="flex items-center justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.05] text-[#d7ff72]">{icon}</span><span className="font-mono text-[11px] tracking-[0.24em] text-white/35">{index}</span></div><div><h3 className="text-lg font-semibold tracking-[-0.02em] text-white">{title}</h3><p className="mt-2 max-w-[230px] text-sm leading-6 text-white/45">{description}</p></div></div></button>;
}

export function CodeWorkspace({ mode, onClose }: { mode: Mode; onClose: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [filename, setFilename] = useState("");
  const [publicName, setPublicName] = useState("");
  const [content, setContent] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [result, setResult] = useState<ShareResult | null>(null);
  const [safePackage, setSafePackage] = useState("");
  const [downloadHref, setDownloadHref] = useState("");
  const shareMutation = trpc.sharing.create.useMutation({ onSuccess: data => { setResult(data); toast.success("Private link created"); }, onError: error => toast.error(error.message || "Unable to create link") });

  useEffect(() => {
    if (!safePackage) { setDownloadHref(""); return; }
    const href = URL.createObjectURL(new Blob([safePackage], { type: "text/plain" }));
    setDownloadHref(href);
    return () => URL.revokeObjectURL(href);
  }, [safePackage]);

  const acceptFile = async (file?: File) => {
    if (!file) return;
    if (!/\.(lua|txt)$/i.test(file.name)) { toast.error("Only .lua and .txt files are supported"); return; }
    if (file.size > MAX_CODE_BYTES) { toast.error("File exceeds the 500 KB limit"); return; }
    try { const nextContent = await readFile(file); setSelectedFile(file); setFilename(file.name); setContent(nextContent); setResult(null); setSafePackage(""); toast.success(`${file.name} loaded`); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Unable to read this file"); }
  };

  const handleSubmit = () => {
    if (!content.trim()) { toast.error("Paste code or upload a file first"); return; }
    if (mode === "protect") {
      setSafePackage(`-- LuaGuard safe package\n-- Compatibility-first delivery; no hidden VM or anti-analysis logic.\n\n${content}`);
      toast.success("Safe package is ready to download");
      return;
    }
    if (!/^[A-Za-z0-9_-]{2,64}$/.test(publicName.trim())) { toast.error("Choose a public name using letters, numbers, hyphens, or underscores"); return; }
    shareMutation.mutate({ filename: filename || "luaguard-script.lua", content, publicName: publicName.trim() });
  };

  return <section className="animate-in relative mx-auto mt-8 max-w-5xl rounded-[28px] border border-[#d7ff72]/20 bg-[#0e1117] p-5 shadow-[0_24px_80px_rgba(0,0,0,0.3)] duration-300 sm:p-8"><div className="absolute inset-x-10 top-0 h-px bg-gradient-to-r from-transparent via-[#d7ff72] to-transparent opacity-80" /><div className="flex flex-col justify-between gap-5 border-b border-white/[0.08] pb-6 sm:flex-row sm:items-start"><div><div className="mb-3 flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.2em] text-[#d7ff72]"><span className="h-1.5 w-1.5 rounded-full bg-[#d7ff72] shadow-[0_0_14px_#d7ff72]" />Workspace / {mode === "protect" ? "Safe package" : "Private link"}</div><h2 className="text-2xl font-semibold tracking-[-0.04em] text-white sm:text-3xl">{mode === "protect" ? "Prepare a safe Lua package" : "Create a private code link"}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-white/45">{mode === "protect" ? "Keep the original code intact so supported clients can run it smoothly. LuaGuard does not add hidden VM code, junk code, or anti-analysis logic." : "Store your code as plain text for a compatible client loader. Only authorized admin sessions and the private token can read the content."}</p></div><button type="button" onClick={onClose} className="self-start rounded-full p-2 text-white/40 transition-colors hover:bg-white/[0.06] hover:text-white" aria-label="Close workspace"><X size={20} /></button></div><div className="mt-7 grid gap-6 lg:grid-cols-[1.2fr_0.8fr]"><div><div className="group relative flex min-h-[330px] cursor-text flex-col overflow-hidden rounded-[22px] border border-dashed border-white/15 bg-[#090b10] transition-colors hover:border-[#d7ff72]/50" onClick={() => inputRef.current?.click()} onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); void acceptFile(event.dataTransfer.files[0]); }}><div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-3 text-[11px] font-mono text-white/35"><span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-red-400/80" /><span className="h-2 w-2 rounded-full bg-yellow-300/80" /><span className="h-2 w-2 rounded-full bg-green-300/80" /></span><span>{filename || "untitled.lua"}</span><span>{content ? formatBytes(new Blob([content]).size) : "0 B"}</span></div><textarea value={content} onChange={event => { setContent(event.target.value); setSelectedFile(null); setSafePackage(""); if (!filename) setFilename("untitled.lua"); }} onClick={event => event.stopPropagation()} placeholder="-- Paste Lua code here...\n-- or drop a .lua / .txt file" className="min-h-[280px] flex-1 resize-none bg-transparent px-5 py-5 font-mono text-[13px] leading-6 text-[#d9e2cf] outline-none placeholder:text-white/20" spellCheck={false} /><input ref={inputRef} type="file" accept=".lua,.txt,text/plain" className="hidden" onChange={event => void acceptFile(event.target.files?.[0])} />{!content && <div className="pointer-events-none absolute inset-x-0 bottom-8 flex flex-col items-center gap-3 text-white/30"><div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.04] text-[#d7ff72]"><Upload size={20} /></div><span className="text-xs">Click to choose a file or drop it here</span></div>}</div><div className="mt-3 flex items-center justify-between gap-3 text-xs text-white/35"><span className="flex items-center gap-2"><FileCode2 size={14} className="text-[#d7ff72]" />{selectedFile ? selectedFile.name : "Only .lua and .txt"}</span><button type="button" onClick={() => inputRef.current?.click()} className="font-medium text-[#d7ff72] hover:text-white">Choose file</button></div></div><aside className="flex flex-col rounded-[22px] border border-white/[0.08] bg-white/[0.025] p-5"><div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#d7ff72]/10 text-[#d7ff72]"><ShieldCheck size={19} /></span><div><p className="text-sm font-semibold text-white">{mode === "protect" ? "Safe delivery" : "Private sharing"}</p><p className="text-xs text-white/35">Admin session only</p></div></div>{mode === "share" && <div className="mt-6"><label htmlFor="public-name" className="mb-2 block text-[11px] uppercase tracking-[0.16em] text-white/35">Public name</label><input id="public-name" value={publicName} onChange={event => setPublicName(event.target.value)} placeholder="my-script" className="w-full rounded-xl border border-white/10 bg-black/20 px-3 py-3 font-mono text-sm text-white outline-none placeholder:text-white/25 focus:border-[#d7ff72]/50" /><p className="mt-2 text-[11px] leading-5 text-white/30">Your page will be /TasuMoin/{publicName || "your-name"}</p></div>}<div className="my-6 space-y-4 text-sm">{(mode === "protect" ? ["Keep client compatibility intact", "Validate extension and file size", "No hidden or game-breaking logic"] : ["Custom /TasuMoin/ public name", "Plain-text loader delivery", "500 KB limit per link"]).map(item => <div key={item} className="flex gap-3 text-white/55"><Check size={16} className="mt-0.5 shrink-0 text-[#d7ff72]" /><span>{item}</span></div>)}</div><div className="mt-auto"><button type="button" onClick={handleSubmit} disabled={shareMutation.isPending} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#d7ff72] px-4 py-3.5 text-sm font-semibold text-[#10130e] transition-all hover:bg-[#e5ffae] active:scale-[0.98] disabled:cursor-wait disabled:opacity-50">{shareMutation.isPending ? "Creating link..." : mode === "protect" ? <><LockKeyhole size={16} /> Prepare safe package</> : <><Link2 size={16} /> Create private link</>}</button><p className="mt-3 text-center text-[11px] leading-5 text-white/25">Use this tool only for code you own or are authorized to share.</p></div></aside></div>{mode === "protect" && content && <div className="mt-6 rounded-2xl border border-[#d7ff72]/15 bg-[#d7ff72]/[0.04] p-4 text-sm text-white/55"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-start gap-3"><Sparkles size={17} className="mt-0.5 shrink-0 text-[#d7ff72]" /><p><span className="font-medium text-white">Preview ready.</span> The safe package preserves the original script and adds only a transparent header.</p></div>{safePackage && <a href={downloadHref} download={filename || "luaguard-safe.lua"} className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg border border-[#d7ff72]/30 px-3 py-2 text-xs font-semibold text-[#d7ff72] transition-colors hover:bg-[#d7ff72]/10"><ArrowUpRight size={14} /> Download package</a>}</div></div>}{result && <div className="mt-6 rounded-2xl border border-[#d7ff72]/20 bg-[#d7ff72]/[0.05] p-5"><div className="flex items-start justify-between gap-4"><div><p className="text-sm font-semibold text-white">Private link is ready</p><p className="mt-1 text-xs text-white/40">{result.filename} · /TasuMoin/{result.publicName}</p></div><span className="rounded-full border border-[#d7ff72]/25 px-2.5 py-1 text-[10px] uppercase tracking-wider text-[#d7ff72]">Live</span></div><div className="mt-4 grid gap-3"><div className="flex items-center gap-3 rounded-xl border border-white/[0.08] bg-black/20 p-3"><code className="min-w-0 flex-1 truncate font-mono text-xs text-white/70">{result.url}</code><button type="button" onClick={() => copyText(result.url, "Link")} className="rounded-lg p-2 text-white/45 hover:bg-white/10 hover:text-white" aria-label="Copy link"><Clipboard size={16} /></button></div><div className="flex items-start gap-3 rounded-xl border border-white/[0.08] bg-black/20 p-3"><code className="min-w-0 flex-1 break-all font-mono text-xs leading-5 text-[#d7ff72]">{result.loaderSnippet}</code><button type="button" onClick={() => copyText(result.loaderSnippet, "Loader snippet")} className="rounded-lg p-2 text-white/45 hover:bg-white/10 hover:text-white" aria-label="Copy loader"><Clipboard size={16} /></button></div></div></div>}</section>;
}

export default function Home() {
  return <div className="min-h-screen overflow-x-hidden bg-[#080a0e] text-white"><div className="pointer-events-none fixed inset-0 -z-0 opacity-60 [background-image:linear-gradient(rgba(255,255,255,0.028)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.028)_1px,transparent_1px)] [background-size:64px_64px]" /><div className="pointer-events-none fixed left-1/2 top-[-18rem] -z-0 h-[38rem] w-[38rem] -translate-x-1/2 rounded-full bg-[#d7ff72]/[0.08] blur-[120px]" /><header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-5 py-6 sm:px-8"><a href="/" className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#d7ff72] font-mono text-sm font-black text-[#11130e]">LG</span><span className="text-sm font-bold tracking-[0.14em] text-white">LUAGUARD<span className="text-[#d7ff72]">/</span></span></a><div className="hidden items-center gap-6 text-xs text-white/40 sm:flex"><span className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#d7ff72] shadow-[0_0_10px_#d7ff72]" />System operational</span><span>v1.1.0</span></div><AdminMenu /></header><main className="relative z-10 mx-auto max-w-6xl px-5 pb-20 pt-12 sm:px-8 sm:pt-20"><section className="mx-auto max-w-3xl text-center"><div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#d7ff72]/20 bg-[#d7ff72]/[0.06] px-3 py-1.5 text-[10px] font-medium uppercase tracking-[0.2em] text-[#d7ff72]"><Zap size={12} />Private code utility</div><h1 className="text-balance text-5xl font-semibold tracking-[-0.07em] text-white sm:text-7xl">Package Lua.<br /><span className="text-[#d7ff72]">Share clean.</span></h1><p className="mx-auto mt-6 max-w-xl text-base leading-7 text-white/45 sm:text-lg">A lightweight, admin-gated workspace for preparing and distributing Lua/TXT code with compatibility and transparent access controls.</p></section><section className="mx-auto mt-14 grid max-w-5xl gap-3 sm:grid-cols-2 lg:grid-cols-4"><FeatureCard index="01" icon={<LockKeyhole size={20} />} title="Safe package" description="Prepare a downloadable package without hidden VM or junk logic." accent="bg-[#d7ff72]" onClick={() => window.location.assign("/workspace/protect")} /><FeatureCard index="02" icon={<ExternalLink size={20} />} title="Join Community" description="Open the community for updates, support, and announcements." accent="bg-[#77a7ff]" onClick={() => window.open(COMMUNITY_URL, "_blank", "noopener,noreferrer")} /><FeatureCard index="03" icon={<Link2 size={20} />} title="Private link" description="Create a named /TasuMoin/ page and a copyable loader snippet." accent="bg-[#d7ff72]" onClick={() => window.location.assign("/workspace/share")} /><FeatureCard index="04" icon={<FileText size={20} />} title="How it works" description="A short guide to the private workspace and public access rules." accent="bg-[#c792ea]" onClick={() => document.getElementById("guide")?.scrollIntoView({ behavior: "smooth" })} /></section><section id="guide" className="mx-auto mt-24 grid max-w-5xl gap-10 border-t border-white/[0.08] pt-10 sm:grid-cols-[0.8fr_1.2fr] sm:pt-14"><div><p className="text-[11px] uppercase tracking-[0.2em] text-[#d7ff72]">How it works</p><h2 className="mt-4 max-w-sm text-3xl font-semibold tracking-[-0.05em] text-white">A private workspace for clean delivery.</h2></div><div className="grid gap-6 sm:grid-cols-3">{[{ n: "01", title: "Unlock", body: "Use the three-line admin menu to open private tools." }, { n: "02", title: "Prepare", body: "Paste code or choose a .lua/.txt file and validate it." }, { n: "03", title: "Deliver", body: "Download a safe package or create a named private link." }].map(item => <div key={item.n} className="border-l border-white/10 pl-4"><span className="font-mono text-xs text-[#d7ff72]">{item.n}</span><h3 className="mt-3 font-semibold text-white">{item.title}</h3><p className="mt-2 text-sm leading-6 text-white/40">{item.body}</p></div>)}</div></section><section className="mx-auto mt-16 max-w-5xl rounded-2xl border border-white/[0.08] bg-white/[0.025] p-5 text-xs leading-6 text-white/35 sm:p-6"><div className="flex gap-3"><Code2 size={16} className="mt-1 shrink-0 text-[#d7ff72]" /><p><span className="font-medium text-white/65">Security note:</span> The admin key is checked server-side and stored in an HttpOnly session. Public visitors see only the community CTA; IP addresses and geolocation are not exposed in the UI.</p></div></section></main><footer className="relative z-10 mx-auto flex max-w-6xl flex-col gap-3 border-t border-white/[0.08] px-5 py-8 text-xs text-white/30 sm:flex-row sm:items-center sm:justify-between sm:px-8"><span>© 2026 LuaGuard. Built for clean delivery.</span><span className="flex items-center gap-2"><FileText size={13} />.lua / .txt only</span></footer></div>;
}
