import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import HomeLanding from "./pages/HomeLanding";
import PublicShare from "./pages/PublicShare";
import Workspace from "./pages/Workspace";

function Router() {
  return <Switch><Route path="/" component={HomeLanding} /><Route path="/workspace/:mode" component={Workspace} /><Route path="/TasuMoin/:publicName" component={PublicShare} /><Route path="/404" component={NotFound} /><Route component={NotFound} /></Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><Toaster theme="dark" /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
