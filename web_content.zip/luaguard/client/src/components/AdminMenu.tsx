import { useEffect, useState } from "react";
import { Check, KeyRound, LockKeyhole, Menu, Shield, Unlock, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function AdminMenu() {
  const [open, setOpen] = useState(false);
  const [key, setKey] = useState("");
  const status = trpc.admin.status.useQuery(undefined, { staleTime: 15_000 });
  const utils = trpc.useUtils();
  const unlock = trpc.admin.unlock.useMutation({
    onSuccess: async () => {
      setKey("");
      await utils.admin.status.invalidate();
      toast.success("Admin access granted");
    },
    onError: error => toast.error(error.message || "Invalid admin key"),
  });
  const lock = trpc.admin.lock.useMutation({
    onSuccess: async () => {
      await utils.admin.status.invalidate();
      toast.success("Admin session locked");
    },
  });

  useEffect(() => {
    document.body.classList.toggle("admin-active", Boolean(status.data?.authenticated));
    return () => document.body.classList.remove("admin-active");
  }, [status.data?.authenticated]);

  return (
    <div className="relative z-[100]">
      <button type="button" aria-label="Open admin console" onClick={() => setOpen(value => !value)} className={`flex h-10 w-10 items-center justify-center rounded-xl border bg-white/[0.03] transition-colors hover:text-white ${status.data?.authenticated ? "border-[#f4c430]/70 text-[#f4c430] shadow-[0_0_22px_rgba(244,196,48,0.18)]" : "border-white/10 text-white/60 hover:border-white/25"}`}>
        {open ? <X size={18} /> : <Menu size={18} />}
      </button>
      {open && (
        <div className="absolute right-0 top-12 z-[110] w-[min(320px,calc(100vw-2rem))] rounded-2xl border border-white/10 bg-[#11131a] p-4 shadow-[0_20px_70px_rgba(0,0,0,0.55)]">
          <div className="flex items-start gap-3 border-b border-white/[0.08] pb-4"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#d7ff72]/10 text-[#d7ff72]"><Shield size={17} /></span><div><p className="text-sm font-semibold text-white">Admin console</p><p className="mt-1 text-xs leading-5 text-white/40">Private server-side access. The key never enters the client bundle.</p></div></div>
          {status.data?.authenticated ? (
            <div className="pt-4"><div className="flex items-center gap-2 text-xs text-[#d7ff72]"><Check size={15} /> Admin session active</div><button type="button" onClick={() => lock.mutate()} className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg border border-white/10 px-3 py-2.5 text-xs font-semibold text-white/70 hover:border-white/25 hover:text-white"><LockKeyhole size={14} /> Lock console</button></div>
          ) : (
            <form className="pt-4" onSubmit={event => { event.preventDefault(); unlock.mutate({ key }); }}><label className="mb-2 block text-[11px] uppercase tracking-[0.16em] text-white/35" htmlFor="admin-key">Access key</label><div className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/20 px-3"><KeyRound size={15} className="shrink-0 text-white/35" /><input id="admin-key" type="password" value={key} onChange={event => setKey(event.target.value)} placeholder="Enter admin key" className="min-w-0 flex-1 bg-transparent py-3 text-sm text-white outline-none placeholder:text-white/25" autoComplete="current-password" /></div><button type="submit" disabled={!key || unlock.isPending} className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg bg-[#d7ff72] px-3 py-2.5 text-xs font-semibold text-[#10130e] hover:bg-[#e5ffae] disabled:cursor-not-allowed disabled:opacity-50"><Unlock size={14} /> {unlock.isPending ? "Checking..." : "Unlock admin"}</button></form>
          )}
        </div>
      )}
    </div>
  );
}
