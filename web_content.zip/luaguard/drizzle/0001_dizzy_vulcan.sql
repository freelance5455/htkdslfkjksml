CREATE TABLE `code_links` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(32) NOT NULL,
	`filename` varchar(255) NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`mimeType` varchar(100) NOT NULL DEFAULT 'text/plain',
	`sizeBytes` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `code_links_id` PRIMARY KEY(`id`),
	CONSTRAINT `code_links_slug_unique` UNIQUE(`slug`)
);
