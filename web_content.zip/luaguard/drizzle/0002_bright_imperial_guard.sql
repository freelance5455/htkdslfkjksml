ALTER TABLE `code_links` ADD `publicName` varchar(120) NOT NULL;--> statement-breakpoint
ALTER TABLE `code_links` ADD `accessTokenHash` varchar(64) NOT NULL;--> statement-breakpoint
ALTER TABLE `code_links` ADD CONSTRAINT `code_links_publicName_unique` UNIQUE(`publicName`);