# LuaGuard Web Export

This archive contains the LuaGuard full-stack web project.

## Included

The project includes the React/Vite frontend, Express/tRPC backend, Drizzle schema and migrations, protected admin session flow, `.lua`/`.txt` upload workspace, named `/TasuMoin/<name>` pages, and plain-text loader delivery.

## Local development

1. Install Node.js 22 and pnpm.
2. Run `pnpm install`.
3. Configure the project environment variables used by the WebDev template, including `DATABASE_URL`, `JWT_SECRET`, `BUILT_IN_FORGE_API_URL`, `BUILT_IN_FORGE_API_KEY`, and `ADMIN_ACCESS_KEY`.
4. Run `pnpm db:push` if the database is available.
5. Run `pnpm dev`.

The admin key must remain server-side. Do not place `ADMIN_ACCESS_KEY` in Vite client variables or frontend code.

## Validation

- `pnpm check`
- `pnpm test`
- `pnpm build`

The public page intentionally shows only Join Community to unauthenticated visitors. Private tools require the server-side admin session.
