import { createHmac, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";
import { ENV } from "./_core/env";

export const ADMIN_COOKIE = "luaguard_admin";
const MAX_AGE_SECONDS = 60 * 60 * 24 * 7;

function secret() {
  return process.env.ADMIN_ACCESS_KEY || "";
}

function signature(payload: string) {
  return createHmac("sha256", ENV.cookieSecret || "luaguard-cookie-fallback").update(`${payload}.${secret()}`).digest("hex");
}

export function isAdminKeyConfigured() {
  return secret().length >= 12;
}

export function verifyAdminKey(input: string) {
  const configured = secret();
  if (!isAdminKeyConfigured() || !input || input.length !== configured.length) return false;
  return timingSafeEqual(Buffer.from(input), Buffer.from(configured));
}

export function issueAdminSession(res: Response) {
  const expires = Math.floor(Date.now() / 1000) + MAX_AGE_SECONDS;
  const payload = String(expires);
  res.cookie(ADMIN_COOKIE, `${payload}.${signature(payload)}`, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    maxAge: MAX_AGE_SECONDS * 1000,
    path: "/",
  });
}

export function clearAdminSession(res: Response) {
  res.clearCookie(ADMIN_COOKIE, { httpOnly: true, secure: true, sameSite: "lax", path: "/" });
}

export function hasAdminSession(req: Request) {
  const raw = req.headers.cookie
    ?.split(";")
    .map(value => value.trim())
    .find(value => value.startsWith(`${ADMIN_COOKIE}=`))
    ?.slice(ADMIN_COOKIE.length + 1);
  if (typeof raw !== "string") return false;
  const [expires, provided] = raw.split(".");
  if (!expires || !provided || Number(expires) < Math.floor(Date.now() / 1000)) return false;
  const expected = signature(expires);
  if (provided.length !== expected.length) return false;
  return timingSafeEqual(Buffer.from(provided), Buffer.from(expected));
}
