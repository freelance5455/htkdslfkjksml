import { describe, expect, it } from "vitest";
import { isAdminKeyConfigured, verifyAdminKey } from "./adminAuth";

describe("adminAuth", () => {
  it("validates the configured server-side admin key", () => {
    expect(isAdminKeyConfigured()).toBe(true);
    expect(verifyAdminKey("Key_TgAwntD6921")).toBe(true);
    expect(verifyAdminKey("wrong-key")).toBe(false);
  });
});
