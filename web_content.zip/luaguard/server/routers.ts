import { createHash, randomBytes } from "node:crypto";
import { nanoid } from "nanoid";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { createCodeLink } from "./db";
import { hasAdminSession, issueAdminSession, verifyAdminKey, clearAdminSession, isAdminKeyConfigured } from "./adminAuth";
import { storagePut } from "./storage";

const MAX_CODE_BYTES = 500_000;
const fileNameSchema = z.string().trim().min(1).max(255).refine(name => /\.(lua|txt)$/i.test(name), "Only .lua and .txt files are supported");
const publicNameSchema = z.string().trim().min(2).max(64).regex(/^[A-Za-z0-9_-]+$/, "Use letters, numbers, hyphens, or underscores only");

function safeFileName(name: string) { return name.replace(/[^a-zA-Z0-9._-]/g, "_"); }
function requireAdmin(ctx: { req: Parameters<typeof hasAdminSession>[0] }) {
  if (!hasAdminSession(ctx.req)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Admin access required" });
}
function originFor(req: { get: (name: string) => string | undefined; protocol: string }) {
  const protocol = req.get("x-forwarded-proto")?.split(",")[0] || req.protocol;
  const host = req.get("x-forwarded-host") || req.get("host") || "localhost";
  return `${protocol}://${host}`;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  admin: router({
    status: publicProcedure.query(({ ctx }) => ({ authenticated: hasAdminSession(ctx.req), configured: isAdminKeyConfigured() })),
    unlock: publicProcedure.input(z.object({ key: z.string().min(1).max(120) })).mutation(({ input, ctx }) => {
      if (!verifyAdminKey(input.key)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid admin key" });
      issueAdminSession(ctx.res);
      return { authenticated: true } as const;
    }),
    lock: publicProcedure.mutation(({ ctx }) => { clearAdminSession(ctx.res); return { authenticated: false } as const; }),
  }),
  sharing: router({
    create: publicProcedure
      .input(z.object({ filename: fileNameSchema, content: z.string().min(1).max(MAX_CODE_BYTES), publicName: publicNameSchema }))
      .mutation(async ({ input, ctx }) => {
        requireAdmin(ctx);
        const sizeBytes = Buffer.byteLength(input.content, "utf8");
        if (sizeBytes > MAX_CODE_BYTES) throw new TRPCError({ code: "BAD_REQUEST", message: "Code is larger than the 500 KB limit" });

        const slug = nanoid(10);
        const accessToken = randomBytes(24).toString("base64url");
        const accessTokenHash = createHash("sha256").update(accessToken).digest("hex");
        const filename = safeFileName(input.filename);
        const stored = await storagePut(`luaguard/${slug}-${filename}`, Buffer.from(input.content, "utf8"), "text/plain; charset=utf-8");
        await createCodeLink({ slug, publicName: input.publicName, filename, fileKey: stored.key, accessTokenHash, mimeType: "text/plain", sizeBytes });

        const origin = originFor(ctx.req);
        const publicUrl = `${origin}/TasuMoin/${input.publicName}`;
        const rawUrl = `${origin}/raw/${input.publicName}?access=${accessToken}`;
        return { slug, publicName: input.publicName, filename, url: publicUrl, loaderSnippet: `loadstring(game:HttpGet("${rawUrl}"))()` };
      }),
  }),
});

export type AppRouter = typeof appRouter;
