import "dotenv/config";
import express from "express";
import { createHash, timingSafeEqual } from "node:crypto";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { getCodeLinkByPublicName } from "../db";
import { storageGetSignedUrl } from "../storage";
import { hasAdminSession } from "../adminAuth";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => server.close(() => resolve(true)));
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) if (await isPortAvailable(port)) return port;
  throw new Error(`No available port found starting from ${startPort}`);
}

function tokenMatches(token: string, expectedHash: string) {
  if (!token || token.length > 200) return false;
  const actual = createHash("sha256").update(token).digest("hex");
  if (actual.length !== expectedHash.length) return false;
  return timingSafeEqual(Buffer.from(actual), Buffer.from(expectedHash));
}

function registerRawCodeRoute(app: express.Express) {
  app.get("/raw/:publicName", async (req, res) => {
    try {
      const publicName = String(req.params.publicName || "");
      if (!/^[A-Za-z0-9_-]{2,64}$/.test(publicName)) return res.status(404).type("text/plain").send("Not found");
      const record = await getCodeLinkByPublicName(publicName);
      const access = typeof req.query.access === "string" ? req.query.access : "";
      const authorized = hasAdminSession(req) || tokenMatches(access, record?.accessTokenHash || "");
      if (!record || !authorized) {
        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        res.setHeader("X-Content-Type-Options", "nosniff");
        return res.status(403).send("Access denied. Open this link from an authorized loader.");
      }

      const signedUrl = await storageGetSignedUrl(record.fileKey);
      const upstream = await fetch(signedUrl);
      if (!upstream.ok) return res.status(502).type("text/plain").send("Source temporarily unavailable");
      const content = await upstream.text();
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Content-Disposition", `inline; filename="${record.filename}"`);
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Cache-Control", "private, max-age=60");
      return res.status(200).send(content);
    } catch (error) {
      console.error("[RawCode] Failed to serve code:", error);
      return res.status(500).type("text/plain").send("Unable to serve this code");
    }
  });
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  registerRawCodeRoute(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server);
  else serveStatic(app);

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  server.listen(port, () => console.log(`Server running on http://localhost:${port}/`));
}

startServer().catch(console.error);
