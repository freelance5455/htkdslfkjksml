import { beforeEach, describe, expect, it, vi } from "vitest";

const { storagePutMock, createCodeLinkMock } = vi.hoisted(() => ({
  storagePutMock: vi.fn(),
  createCodeLinkMock: vi.fn(),
}));

vi.mock("./storage", () => ({ storagePut: storagePutMock }));
vi.mock("./db", () => ({ createCodeLink: createCodeLinkMock }));
vi.mock("./adminAuth", () => ({
  hasAdminSession: () => true,
  issueAdminSession: vi.fn(),
  verifyAdminKey: vi.fn(),
  clearAdminSession: vi.fn(),
  isAdminKeyConfigured: () => true,
}));

import { appRouter } from "./routers";

type RequestLike = {
  protocol: string;
  get: (name: string) => string | undefined;
};

function createCaller() {
  const req: RequestLike = {
    protocol: "https",
    get: name => name.toLowerCase() === "host" ? "luaguard.example" : undefined,
  };
  return appRouter.createCaller({
    user: null,
    req: req as never,
    res: {} as never,
  });
}

describe("sharing.create", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    storagePutMock.mockResolvedValue({ key: "luaguard/test.lua_hash", url: "/manus-storage/test" });
    createCodeLinkMock.mockResolvedValue({ id: 1, slug: "abc1234567" });
  });

  it("stores plain text and returns a raw URL plus loader snippet", async () => {
    const result = await createCaller().sharing.create({
      filename: "hello.lua",
      content: "print('hello')",
      publicName: "hello-script",
    });

    expect(storagePutMock).toHaveBeenCalledWith(
      expect.stringMatching(/^luaguard\//),
      expect.any(Buffer),
      "text/plain; charset=utf-8",
    );
    expect(createCodeLinkMock).toHaveBeenCalledWith(expect.objectContaining({
      filename: "hello.lua",
      publicName: "hello-script",
      mimeType: "text/plain",
      sizeBytes: 14,
    }));
    expect(result.url).toBe("https://luaguard.example/TasuMoin/hello-script");
    expect(result.loaderSnippet).toContain("loadstring(game:HttpGet(");
  });

  it("rejects unsupported extensions", async () => {
    await expect(createCaller().sharing.create({
      filename: "payload.js",
      content: "alert(1)",
    })).rejects.toThrow();
    expect(storagePutMock).not.toHaveBeenCalled();
  });

  it("rejects content over the 500 KB limit", async () => {
    await expect(createCaller().sharing.create({
      filename: "large.lua",
      content: "x".repeat(500_001),
    })).rejects.toThrow();
    expect(storagePutMock).not.toHaveBeenCalled();
  });
});
