import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { codeLinks, InsertCodeLink, InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];
  textFields.forEach(field => {
    const value = user[field];
    if (value !== undefined) { values[field] = value ?? null; updateSet[field] = value ?? null; }
  });
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function createCodeLink(input: InsertCodeLink) {
  const db = await getDb();
  if (!db) throw new Error("Database is not configured");
  await db.insert(codeLinks).values(input);
  const result = await db.select().from(codeLinks).where(eq(codeLinks.slug, input.slug)).limit(1);
  return result[0];
}

export async function getCodeLinkBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(codeLinks).where(eq(codeLinks.slug, slug)).limit(1);
  return result[0];
}

export async function getCodeLinkByPublicName(publicName: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(codeLinks).where(eq(codeLinks.publicName, publicName)).limit(1);
  return result[0];
}
