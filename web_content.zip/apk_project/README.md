# PKG-TEST 통합일지 Android APK 프로젝트

현재 사용 중인 `통합일지39.html`을 Android WebView 앱으로 포장한 프로젝트입니다.

## 빌드
1. Android Studio에서 이 폴더를 엽니다.
2. Gradle Sync가 끝날 때까지 기다립니다.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`를 선택합니다.
4. 생성된 APK를 Android 휴대폰에 설치합니다.

## 주의
- Firebase 실시간 공유를 사용하므로 앱 사용 시 인터넷 연결이 필요합니다.
- XLS/XLSX/CSV 업로드, 사진 선택 등 웹 파일 입력 기능을 Android 파일 선택기로 연결합니다.
- 원본 HTML의 Firebase 설정 및 기능은 수정하지 않았습니다.
