# Google backup (Gmail) setup: one time, about 10 minutes

The app saves a backup of the user's records to a **private app folder in their own Google Drive**
(no one else can see it, and it does not appear in their normal Drive files).
Restoring on a new phone brings everything back. Backups need internet and the app opened from its https link.

You (the app owner) do this once. Users then only tap "Back up now" and choose their Gmail account.

1. Go to https://console.cloud.google.com and sign in. Create a project (e.g. "Voucher Desk").
2. APIs & Services > Library > search "Google Drive API" > Enable.
3. APIs & Services > OAuth consent screen (or "Google Auth Platform"):
   - User type: External. App name: Voucher Desk. Support email: your Gmail.
   - Scopes: add `.../auth/drive.appdata` (this scope is non-sensitive, so no Google review is needed).
   - Publishing status: click "Publish app" (In production). If you leave it in Testing, add each user's Gmail as a test user, and sign-in expires every 7 days.
4. APIs & Services > Credentials > Create credentials > OAuth client ID > Web application.
   - Authorized JavaScript origins: the exact address where the app is hosted, e.g. `https://voucher-desk.netlify.app` (no trailing slash, no path).
   - Create, then copy the Client ID (looks like 123456-abc.apps.googleusercontent.com). It is not a secret.
5. Give the Client ID to the app, either way:
   - In the app: Profile > Open cloud backup > paste it under "Google client ID" > Save client ID (per phone), or
   - Edit `config.js` once, put the ID between the quotes, and redeploy (all phones get it).
6. Each user: Profile > Open cloud backup > enter their Gmail > Save Gmail > Back up now. Choose that Google account and allow access.

## How it behaves
- After the first sign-in, changes are backed up automatically about 20 seconds after you stop typing, whenever the phone is online. If Google needs the user to sign in again (about hourly), the home screen shows "Changes not backed up · tap to back up".
- New phone: install the app, then on the login screen tap "Restore from Google Drive", choose the Gmail account, then log in with the old username and password.
- Restore merges the backup into the phone (it never wipes existing data). A row deleted on one phone can come back if an older backup is restored.
- "Email a backup to my Gmail" works with no setup: on a phone it opens the share sheet (pick Gmail) with the backup file attached. On a computer it downloads the file and opens a draft to your Gmail.
- Backups are not encrypted by the app; they sit in the user's own Google account protected by Google sign-in. Password hashes are inside the backup.
