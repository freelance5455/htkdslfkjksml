# HANIMEX Supabase backend

Project ref: `tysaigoafdsjztsbjuso`.

`hanimex-care-admin` is deployed as version 4 with JWT verification enabled. It permits only an active admin profile to create staff accounts, change staff passwords, toggle active state, and edit permissions. The service-role key remains server-side.

The unified app uses existing customer-care tables and the new `hanimex_internal_messages` table. The SQL migration files record the chat table, active-member RLS policies, Realtime publication membership, and admin username assignment already applied to the hosted project.
