import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.119.0";
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
Deno.serve(async(req:Request)=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 if(req.method!=="POST") return reply({error:"Method not allowed"},405);
 try{
  const url=Deno.env.get("SUPABASE_URL")!;
  const serviceKey=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const token=(req.headers.get("Authorization")||"").replace(/^Bearer\s+/i,"");
  if(!token) return reply({error:"Authentication required"},401);
  const verifier=createClient(url,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:`Bearer ${token}`}},auth:{persistSession:false,autoRefreshToken:false}});
  const {data:{user},error:authError}=await verifier.auth.getUser(token);
  if(authError||!user) return reply({error:"Invalid session"},401);
  const admin=createClient(url,serviceKey,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:profile,error:profileError}=await admin.from("hanimex_profiles").select("role,is_active").eq("user_id",user.id).maybeSingle();
  if(profileError||profile?.role!=="admin"||profile?.is_active!==true) return reply({error:"Admin permission required"},403);
  const body=await req.json(); const action=String(body.action||"");
  if(action==="create_user"){
   const username=String(body.username||"").trim().toLowerCase(), displayName=String(body.display_name||"").trim(), password=String(body.password||""), department=String(body.department_id||"support"), phone=String(body.phone||"").trim();
   const permissions=body.permissions&&typeof body.permissions==="object"?body.permissions:{};
   const allowedDepartments=["support","delivery","maintenance","satisfaction"];
   if(!allowedDepartments.includes(department)) return reply({error:"قسم غير صالح"},400);
   if(!/^[a-z0-9._-]{3,32}$/.test(username)) return reply({error:"اسم المستخدم من 3 إلى 32 حرفاً إنجليزياً أو أرقاماً"},400);
   if(displayName.length<2||password.length<8) return reply({error:"أدخل الاسم وكلمة مرور 8 أحرف على الأقل"},400);
   const {data:exists}=await admin.from("hanimex_profiles").select("user_id").ilike("username",username).maybeSingle();
   if(exists) return reply({error:"اسم المستخدم مستخدم بالفعل"},409);
   const {data:created,error:createError}=await admin.auth.admin.createUser({email:`${username}@hanimex-login.com`,password,email_confirm:true,user_metadata:{name:displayName,hanimex_username:username}});
   if(createError||!created.user) return reply({error:createError?.message||"تعذر إنشاء المستخدم"},400);
   const {error:updateError}=await admin.from("hanimex_profiles").update({username,display_name:displayName,department_id:department,permissions,phone,role:"staff",is_active:true,must_change_password:false}).eq("user_id",created.user.id);
   if(updateError){
    // Roll back the Auth user if the staff profile could not be provisioned.
    await admin.auth.admin.deleteUser(created.user.id);
    return reply({error:"تم إلغاء إنشاء الحساب بسبب تعذر حفظ ملف الموظف: "+updateError.message},500);
   }
   return reply({success:true,user_id:created.user.id,username});
  }
  if(action==="set_password"){
   const userId=String(body.user_id||""),password=String(body.password||"");
   if(!userId||password.length<8) return reply({error:"كلمة المرور يجب ألا تقل عن 8 أحرف"},400);
   const {error}=await admin.auth.admin.updateUserById(userId,{password});
   if(error) return reply({error:error.message},400);
   return reply({success:true});
  }
  if(action==="set_active"){
   const userId=String(body.user_id||""); if(!userId||userId===user.id) return reply({error:"لا يمكن إيقاف حساب المدير الحالي"},400);
   const {error}=await admin.from("hanimex_profiles").update({is_active:!!body.is_active}).eq("user_id",userId);
   if(error) return reply({error:error.message},400);
   return reply({success:true});
  }
  if(action==="update_permissions"){
   const userId=String(body.user_id||"");
   const permissions=body.permissions&&typeof body.permissions==="object"?body.permissions:{};
   const department=String(body.department_id||"support");
   if(!userId||userId===user.id) return reply({error:"لا يمكن تعديل صلاحيات المدير الحالي"},400);
   const allowedDepartments=["support","delivery","maintenance","satisfaction"];
   if(!allowedDepartments.includes(department)) return reply({error:"قسم غير صالح"},400);
   const clean:Record<string,boolean>={};
   for(const key of ["tickets.read","tickets.create","tickets.update","delivery.access","maintenance.access","satisfaction.access","reports.read"]) clean[key]=permissions[key]===true;
   const {error}=await admin.from("hanimex_profiles").update({permissions:clean,department_id:department}).eq("user_id",userId);
   if(error) return reply({error:error.message},400);
   return reply({success:true});
  }
  return reply({error:"Unknown action"},400);
 }catch(error){return reply({error:error instanceof Error?error.message:"Unexpected error"},500);}
});
