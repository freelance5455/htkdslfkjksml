-- Applied to Supabase project tysaigoafdsjztsbjuso.
create table if not exists public.hanimex_internal_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  message text not null check (char_length(message) between 1 and 4000),
  created_at timestamptz not null default now()
);
alter table public.hanimex_internal_messages enable row level security;
grant select, insert on public.hanimex_internal_messages to authenticated;
drop policy if exists "hanimex chat members read" on public.hanimex_internal_messages;
drop policy if exists "hanimex chat active members read" on public.hanimex_internal_messages;
create policy "hanimex chat active members read"
on public.hanimex_internal_messages for select to authenticated
using (exists (select 1 from public.hanimex_profiles p where p.user_id=(select auth.uid()) and p.is_active=true));
drop policy if exists "hanimex chat sender insert" on public.hanimex_internal_messages;
drop policy if exists "hanimex chat active sender insert" on public.hanimex_internal_messages;
create policy "hanimex chat active sender insert"
on public.hanimex_internal_messages for insert to authenticated
with check (sender_id=(select auth.uid()) and exists (select 1 from public.hanimex_profiles p where p.user_id=(select auth.uid()) and p.is_active=true));
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='hanimex_internal_messages') then
    alter publication supabase_realtime add table public.hanimex_internal_messages;
  end if;
end $$;
update public.hanimex_profiles set username='admin',display_name=coalesce(nullif(display_name,''),'مدير النظام') where role='admin' and (username is null or username='');
