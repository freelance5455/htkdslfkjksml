-- Applied to Supabase project tysaigoafdsjztsbjuso.
drop policy if exists "hanimex chat members read" on public.hanimex_internal_messages;
drop policy if exists "hanimex chat active members read" on public.hanimex_internal_messages;
create policy "hanimex chat active members read" on public.hanimex_internal_messages
for select to authenticated using (exists (select 1 from public.hanimex_profiles p where p.user_id=(select auth.uid()) and p.is_active=true));
drop policy if exists "hanimex chat sender insert" on public.hanimex_internal_messages;
drop policy if exists "hanimex chat active sender insert" on public.hanimex_internal_messages;
create policy "hanimex chat active sender insert" on public.hanimex_internal_messages
for insert to authenticated with check (sender_id=(select auth.uid()) and exists (select 1 from public.hanimex_profiles p where p.user_id=(select auth.uid()) and p.is_active=true));
