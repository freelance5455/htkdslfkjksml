# WONDER SHIFT — couche de synchronisation additive V11

- Conservation du fonctionnement local-first V10.
- Synchronisation automatique au retour en ligne et après chargement, sans bloquer l'application.
- Enregistrement de l'appareil et de la version client.
- File `syncQueue` enrichie et marquage des éléments synchronisés.
- Synchronisation des services, tâches, stock, règles de stock, opérations, caisse, notifications, demandes, audit et paramètres.
- Pull cloud -> local avec recalcul local des données dérivées.
- Détection des conflits côté API et endpoints de consultation/résolution.
- Health-check de l'API.
- Indicateur de synchronisation dans l'interface.
- Service worker porté en cache V11 pour éviter de servir les anciens fichiers.

Aucune authentification locale, aucun calcul métier local et aucun écran métier existant n'est remplacé par l'API.
