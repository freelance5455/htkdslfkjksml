# WONDER SHIFT — Local-first V2 de travail

Base conservée : WONDER_SHIFT_SUPABASE_V1_FULL.zip

## Changements
- Authentification locale IndexedDB : identifiant ou e-mail + mot de passe hashé.
- Rôles : Agent, Administrateur, Développeur.
- Suppression/correction : demande locale avec motif obligatoire.
- Validation locale par Administrateur/Développeur.
- Suppression approuvée : opération exclue des totaux et effets caisse/stock neutralisés.
- Stock : mouvements liés aux opérations et recalculés depuis les mouvements actifs.
- Consommation automatique : architecture `stockRules` liée à une tâche.
- Dashboard : filtre personnalisé réellement appliqué et opérations supprimées exclues.
- Rapports : Agent limité à Jour/Semaine ; Admin/Développeur disposent des périodes étendues.
- Verrouillage : fermeture correcte de la session locale.
- Synchronisation cloud : volontairement mise en attente pour la prochaine étape Supabase.
- Écran de connexion : les identifiants/mots de passe ne sont pas affichés.

## Vérifications effectuées
- Syntaxe JavaScript : OK avec `node --check` sur tous les fichiers JS.
- Serveur HTTP local : OK.
- Pages HTML principales accessibles : OK.
- Tests navigateur interactifs : non exécutés dans cet environnement (outil navigateur non disponible).
