#!/bin/bash
set -e

# Store the absolute path of the workspace root
APP_ROOT=$(pwd)

echo "=== Building React/TypeScript application ==="
npm run build

echo "=== Preparing temporary packaging folders ==="
TEMP_DIR=$(mktemp -d)
mkdir -p "$TEMP_DIR/control"
mkdir -p "$TEMP_DIR/data/usr/palm/applications/com.hebrew.calendar"

# Copy build files to the webos app directory
cp -r dist/* "$TEMP_DIR/data/usr/palm/applications/com.hebrew.calendar/"

# Create appinfo.json for webOS
cat << 'EOF' > "$TEMP_DIR/data/usr/palm/applications/com.hebrew.calendar/appinfo.json"
{
  "id": "com.hebrew.calendar",
  "version": "1.0.0",
  "vendor": "Hebrew Calendar",
  "type": "web",
  "main": "index.html",
  "title": "Hebrew Calendar & Daily Verse",
  "icon": "icon.png",
  "largeIcon": "largeIcon.png"
}
EOF

# Use index.html or another generic asset as icon placeholder if needed (or create blank)
# To avoid errors, create empty/mock icon files
touch "$TEMP_DIR/data/usr/palm/applications/com.hebrew.calendar/icon.png"
touch "$TEMP_DIR/data/usr/palm/applications/com.hebrew.calendar/largeIcon.png"

# Create Debian control file
cat << 'EOF' > "$TEMP_DIR/control/control"
Package: com.hebrew.calendar
Version: 1.0.0
Description: Hebrew Calendar and Daily Verse webOS application.
Section: misc
Priority: optional
Architecture: all
Maintainer: Hebrew Calendar App
Source: webos
EOF

# Create debian-binary file
echo "2.0" > "$TEMP_DIR/debian-binary"

echo "=== Creating control.tar.gz ==="
cd "$TEMP_DIR/control"
tar -czf ../control.tar.gz .

echo "=== Creating data.tar.gz ==="
cd "$TEMP_DIR/data"
tar -czf ../data.tar.gz .

echo "=== Assembling IPK package with JS-based ar ==="
cd "$TEMP_DIR"
node "$APP_ROOT/ar.cjs" debian-binary control.tar.gz data.tar.gz "$APP_ROOT/hebrew-calendar_1.0.0_all.ipk"

echo "=== Package created successfully: hebrew-calendar_1.0.0_all.ipk ==="
cd "$APP_ROOT"
rm -rf "$TEMP_DIR"
