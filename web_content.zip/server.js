// Class 10 Super Study App - secure local backend for Gemini AI
// Requires Node.js 18+ (built-in fetch). Keep your API key in the environment, never in HTML.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const HTML_FILE = path.join(__dirname, 'class10_super_study_app_ai.html');

const server = http.createServer(async (req, res) => {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer'
  };
  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    try {
      res.writeHead(200, {'Content-Type':'text/html; charset=utf-8', 'X-Content-Type-Options':'nosniff'});
      fs.createReadStream(HTML_FILE).pipe(res);
    } catch {
      res.writeHead(500, headers); res.end(JSON.stringify({error:'Could not load the HTML app.'}));
    }
    return;
  }

  if (req.method === 'POST' && req.url === '/api/ai') {
    if (!API_KEY) {
      res.writeHead(503, headers);
      res.end(JSON.stringify({error:'Gemini API key is not set. Set GEMINI_API_KEY in your terminal and restart the server.'}));
      return;
    }
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 100_000) req.destroy();
    });
    req.on('end', async () => {
      try {
        const body = JSON.parse(raw || '{}');
        const prompt = String(body.prompt || '').trim().slice(0, 8000);
        if (!prompt) {
          res.writeHead(400, headers); res.end(JSON.stringify({error:'Please provide a question or topic.'})); return;
        }
        const subject = String(body.subject || 'General').slice(0, 80);
        const language = String(body.language || 'simple Hinglish').slice(0, 80);
        const modes = {
          doubt: 'Answer the student question step by step. Show working for calculations.',
          explain: 'Explain the topic simply with an example and a short recap.',
          notes: 'Create concise, well-organized revision notes with headings and key points.',
          quiz: 'Create exactly 5 useful multiple-choice questions, four options each, and give the correct answer with a brief explanation after each question.'
        };
        const mode = modes[body.mode] || modes.doubt;
        const history = Array.isArray(body.history) ? body.history.slice(-8) : [];
        const contents = [];
        for (const item of history) {
          if (!item || !['user','model'].includes(item.role) || typeof item.text !== 'string') continue;
          contents.push({role:item.role, parts:[{text:item.text.slice(0,5000)}]});
        }
        contents.push({role:'user', parts:[{text:
          `You are a helpful Class 10 study tutor. Subject: ${subject}. Reply in ${language}. ${mode}\n` +
          `Be age-appropriate, clear, encouraging, and honest when unsure. Do not claim generated questions are official CBSE questions. ` +
          `Student request: ${prompt}`
        }]});
        const apiRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(API_KEY)}`, {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({
            contents,
            generationConfig:{temperature:0.5, maxOutputTokens:1800}
          })
        });
        const data = await apiRes.json().catch(() => ({}));
        if (!apiRes.ok) {
          const msg = data?.error?.message || `Gemini API returned HTTP ${apiRes.status}`;
          res.writeHead(apiRes.status === 429 ? 429 : 502, headers);
          res.end(JSON.stringify({error:msg}));
          return;
        }
        const answer = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('\n').trim();
        if (!answer) {
          res.writeHead(502, headers); res.end(JSON.stringify({error:'No text answer received. Try again.'})); return;
        }
        res.writeHead(200, headers);
        res.end(JSON.stringify({answer}));
      } catch (err) {
        res.writeHead(400, headers);
        res.end(JSON.stringify({error:'Invalid request or AI connection error: ' + String(err.message || err).slice(0,180)}));
      }
    });
    return;
  }

  res.writeHead(404, headers); res.end(JSON.stringify({error:'Not found'}));
});

server.listen(PORT, () => {
  console.log(`Study Hub AI running at http://localhost:${PORT}`);
  if (!API_KEY) console.log('Set GEMINI_API_KEY in your terminal before using the AI Tutor.');
});
