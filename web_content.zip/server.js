const express=require("express"),multer=require("multer"),path=require("path"),fs=require("fs"),os=require("os"),crypto=require("crypto"),unzipper=require("unzipper");
const app=express(),PORT=process.env.PORT||3000;
const upload=multer({dest:path.join(os.tmpdir(),"html-apk-uploads"),limits:{fileSize:50*1024*1024}});
app.use(express.static(path.join(__dirname,"public")));
app.get("/api/health",(_q,s)=>s.json({ok:true,builderConfigured:false,message:"Dashboard ready; a real Android build backend is not configured."}));
app.post("/api/validate-zip",upload.single("websiteZip"),async(req,res)=>{
 if(!req.file)return res.status(400).json({error:"براہ کرم ZIP فائل منتخب کریں۔"});
 const dir=path.join(os.tmpdir(),"html-apk-check-"+crypto.randomUUID());
 try{fs.mkdirSync(dir,{recursive:true});await fs.createReadStream(req.file.path).pipe(unzipper.Extract({path:dir})).promise();
 const found=fs.existsSync(path.join(dir,"index.html"))||fs.existsSync(path.join(dir,"www","index.html"));
 res.json({ok:found,message:found?"index.html مل گئی۔ بنیادی جانچ کامیاب ہے۔":"ZIP میں index.html نہیں ملی۔ اسے root یا www فولڈر میں رکھیں۔"});
 }catch(e){res.status(400).json({error:"ZIP نہیں کھل سکی۔ درست ZIP فائل اپ لوڈ کریں۔"});}
 finally{try{fs.rmSync(dir,{recursive:true,force:true})}catch{}try{fs.unlinkSync(req.file.path)}catch{}}
});
app.post("/api/build",upload.single("websiteZip"),(req,res)=>{
 if(req.file)try{fs.unlinkSync(req.file.path)}catch{}
 res.status(503).json({needsBackend:true,error:"اصل APK build backend ابھی منسلک نہیں۔ یہ starter خود سے APK compile نہیں کرتا۔"});
});
app.get("/api/download/:id",(_q,s)=>s.status(404).json({error:"کوئی حقیقی APK دستیاب نہیں۔ پہلے build backend configure کریں۔"}));
app.listen(PORT,()=>console.log("Converter running on port "+PORT));
