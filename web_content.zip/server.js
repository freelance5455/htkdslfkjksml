// Servidor LAN sem bibliotecas externas.
// Um telemóvel pode executar este servidor pelo Termux.
// O navegador dos outros telemóveis abre http://IP_DO_HOST:8080
const http=require("http"), crypto=require("crypto"), fs=require("fs"), path=require("path");

const PORT=8080, ROOT=__dirname, clients=new Map(); let nextId=1;

function frame(data){
  const b=Buffer.from(data), n=b.length;
  if(n<126)return Buffer.concat([Buffer.from([0x81,n]),b]);
  if(n<65536){const h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(n,2);return Buffer.concat([h,b]);}
  const h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(n),2);return Buffer.concat([h,b]);
}
function unframe(buf){
  if(buf.length<2)return null;
  const fin=buf[0]&128, opcode=buf[0]&15, masked=buf[1]&128; let len=buf[1]&127,p=2;
  if(opcode===8)return {close:true};
  if(!fin)return null;
  if(len===126){if(buf.length<4)return null;len=buf.readUInt16BE(2);p=4}
  else if(len===127){if(buf.length<10)return null;len=Number(buf.readBigUInt64BE(2));p=10}
  if(masked){if(buf.length<p+4+len)return null;const key=buf.subarray(p,p+4);p+=4;const out=Buffer.alloc(len);for(let i=0;i<len;i++)out[i]=buf[p+i]^key[i%4];return {text:out.toString()}}
  return {text:buf.subarray(p,p+len).toString()};
}
function broadcast(){
  const players={}; for(const [id,c] of clients)players[id]=c.state;
  const msg=frame(JSON.stringify({t:"players",players}));
  for(const c of clients.values())if(c.socket.readyState===1)c.socket.write(msg);
}
function serve(req,res){
  let u=decodeURIComponent(req.url.split("?")[0]); if(u==="/")u="/index.html";
  const safe=path.normalize(u).replace(/^(\.\.[\/\\])+/, "");
  const file=path.join(ROOT,safe);
  fs.readFile(file,(e,d)=>{if(e){res.writeHead(404);return res.end("Not found")}const ext=path.extname(file);const types={".html":"text/html",".js":"text/javascript",".css":"text/css"};res.writeHead(200,{"Content-Type":types[ext]||"application/octet-stream","Cache-Control":"no-store"});res.end(d)});
}
const server=http.createServer(serve);
server.on("upgrade",(req,socket)=>{
  if(req.headers.upgrade?.toLowerCase()!=="websocket"){socket.destroy();return}
  const key=req.headers["sec-websocket-key"],accept=crypto.createHash("sha1").update(key+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").digest("base64");
  socket.write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: "+accept+"\r\n\r\n");
  const id="P"+nextId++; const client={id,socket,state:{id,x:760,y:790,a:0,hp:100,car:false}};clients.set(id,client);
  socket.write(frame(JSON.stringify({t:"welcome",id,count:clients.size})));broadcast();
  let pending=Buffer.alloc(0);
  socket.on("data",chunk=>{pending=Buffer.concat([pending,chunk]);while(true){const m=unframe(pending);if(!m)break;let consumed=pending.length; // frame parser consumes whole available frame
      // Calculate exact frame length to preserve multiple frames.
      let p=2,l=pending[1]&127;if(l===126)p+=2;else if(l===127)p+=8;if(pending[1]&128)p+=4;let total=p+l;if(l===126)total=p+0+(pending.readUInt16BE(2));else if(l===127)total=p+Number(pending.readBigUInt64BE(2));if(pending.length<total)break;pending=pending.subarray(total);
      if(m.close){socket.end();return}try{const x=JSON.parse(m.text);if(x.t==="state"){client.state={id,x:x.x,y:x.y,a:x.a,hp:x.hp,car:!!x.car};broadcast()}}catch(_){}}
  });
  socket.on("close",()=>{clients.delete(id);broadcast()});socket.on("error",()=>{clients.delete(id);});
});
server.listen(PORT,"0.0.0.0",()=>console.log("Moz City LAN server em http://0.0.0.0:"+PORT));
