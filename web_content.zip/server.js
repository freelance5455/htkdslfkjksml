// AlarmSimulator Ukraine — тестовый сервер. Требуется Node.js 18+.
// Перед запуском задайте ADMIN_TOKEN в переменных окружения.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PORT = Number(process.env.PORT || 8787);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const ROOT = __dirname;
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map(s=>s.trim()).filter(Boolean);
if (ADMIN_TOKEN.length < 24) {
  console.error('ОШИБКА: задайте ADMIN_TOKEN длиной минимум 24 символа. Не встраивайте его в клиент.');
  process.exit(1);
}
let active = [], history = [], updatedAt = new Date().toISOString();
const mime = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8', '.txt':'text/plain; charset=utf-8' };
const requestCounts = new Map();
function send(res, status, data, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer'});
  res.end(status === 204 ? '' : type.startsWith('application/json') ? JSON.stringify(data) : data);
}
function allowedRate(ip) {
  const now = Date.now(), old = requestCounts.get(ip);
  if (!old || now - old.start > 60000) { requestCounts.set(ip, {start:now,count:1}); return true; }
  old.count++; return old.count <= 180;
}
function readBody(req) { return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>10000){reject(new Error('Занадто великий запит'));req.destroy();}});req.on('end',()=>{try{resolve(s?JSON.parse(s):{});}catch{reject(new Error('Некоректний JSON'));}});}); }
function isAdmin(req) { const h=req.headers.authorization||''; const expected=Buffer.from('Bearer '+ADMIN_TOKEN); const actual=Buffer.from(h); return actual.length===expected.length && crypto.timingSafeEqual(actual,expected); }
const stamp = () => new Date().toLocaleString('uk-UA');
const server = http.createServer(async (req,res) => {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.includes(origin)) { res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Vary', 'Origin'); res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization'); res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'); }
  if (req.method === 'OPTIONS') { if (!origin || !ALLOWED_ORIGINS.includes(origin)) return send(res, 403, {error:'Origin not allowed'}); res.writeHead(204); return res.end(); }
  const ip = req.socket.remoteAddress || 'unknown';
  if (!allowedRate(ip)) return send(res,429,{error:'Забагато запитів. Спробуйте пізніше.'});
  const u = new URL(req.url,'http://localhost');
  if (req.method==='GET' && u.pathname==='/api/state') {
    const district=(u.searchParams.get('district')||'').trim().toLocaleLowerCase('uk-UA');
    const matches=e=>!district||e.district.toLocaleLowerCase('uk-UA')===district;
    return send(res,200,{active:active.filter(matches),history:history.filter(matches).slice(-50).reverse(),updatedAt,serverTime:Date.now()});
  }
  if (req.method==='POST' && u.pathname.startsWith('/api/admin/')) {
    if (!isAdmin(req)) return send(res,401,{error:'Невірний токен адміністратора.'});
    let b; try { b=await readBody(req); } catch(e) { return send(res,400,{error:e.message}); }
    if (u.pathname==='/api/admin/login') return send(res,200,{ok:true});
    if (u.pathname==='/api/admin/event') {
      const title=String(b.title||'').trim().slice(0,120), district=String(b.district||'').trim().slice(0,100);
      if(!title||!district) return send(res,400,{error:'Виберіть тип події та район.'});
      if(active.some(e=>e.title===title&&e.district.toLocaleLowerCase('uk-UA')===district.toLocaleLowerCase('uk-UA'))) return send(res,409,{error:'Ця тестова подія вже активна в районі.'});
      const e={id:crypto.randomBytes(8).toString('hex'),title,district,time:stamp(),active:true}; active.push(e);history.push({...e});updatedAt=new Date().toISOString();
      return send(res,200,{ok:true,message:'Тестову подію передано клієнтам району: '+district+'.'});
    }
    if (u.pathname==='/api/admin/clear') {
      const district=String(b.district||'').trim();if(!district)return send(res,400,{error:'Укажіть район.'});
      const removed=active.filter(e=>e.district.toLocaleLowerCase('uk-UA')===district.toLocaleLowerCase('uk-UA'));active=active.filter(e=>e.district.toLocaleLowerCase('uk-UA')!==district.toLocaleLowerCase('uk-UA'));
      for(const e of removed)history.push({...e,id:crypto.randomBytes(8).toString('hex'),active:false,time:stamp(),title:'Відбій: '+e.title});updatedAt=new Date().toISOString();return send(res,200,{ok:true,message:'Тестовий відбій передано. Знято подій: '+removed.length});
    }
    return send(res,404,{error:'Не знайдено'});
  }
  let p=u.pathname==='/'?'/index.html':u.pathname;if(p==='/admin')p='/admin.html';
  const file=path.resolve(ROOT,'.'+p);if(!file.startsWith(ROOT+path.sep))return send(res,403,{error:'Forbidden'});
  fs.readFile(file,(err,data)=>err?send(res,404,{error:'Файл не знайдено'}):send(res,200,data,mime[path.extname(file)]||'application/octet-stream'));
});
server.listen(PORT,'0.0.0.0',()=>console.log(`AlarmSimulator TEST server on port ${PORT}\nAdmin: http://localhost:${PORT}/admin\nSet a private ADMIN_TOKEN; test events only.`));
