require("dotenv").config();
const express = require("express");
const OpenAI = require("openai");
const multer = require("multer");
const { evaluate } = require("mathjs");
const path = require("path");

const app = express();
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

async function askAI(instructions, input) {
  const r = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5.6",
    instructions, input
  });
  return r.output_text;
}

app.post("/api/ask", async (req, res) => {
  try {
    const { question, subject="Mathematics", level="Secondary", mode="Step-by-step", history=[] } = req.body;
    if (typeof question !== "string" || !question.trim() || question.length > 5000)
      return res.status(400).json({error:"Enter a question under 5000 characters."});
    const instructions = `You are TK Assist, a careful Maths and Physics tutor.
Subject: ${subject}; level: ${level}; mode: ${mode}.
Explain calculations step by step, define formulas and symbols, check units and arithmetic.
Adapt to the student's level. If information is missing or unreadable, say so.
Do not claim certainty when unsure. Use readable plain text.`;
    const safe = Array.isArray(history) ? history.filter(m =>
      m && ["user","assistant"].includes(m.role) && typeof m.content==="string"
    ).slice(-8).map(m=>({role:m.role,content:m.content.slice(0,3000)})) : [];
    res.json({answer: await askAI(instructions,[...safe,{role:"user",content:question}])});
  } catch(e) { console.error(e); res.status(500).json({error:"AI service unavailable. Check your API key and model."}); }
});

const upload = multer({storage:multer.memoryStorage(),limits:{fileSize:8*1024*1024},
  fileFilter:(req,file,cb)=>cb(null,["image/jpeg","image/png","image/webp"].includes(file.mimetype))});

app.post("/api/image",upload.single("image"),async(req,res)=>{
  try {
    if(!req.file) return res.status(400).json({error:"Upload a JPG, PNG or WebP image."});
    const dataUrl=`data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
    const task=String(req.body.task||"Read and solve this question step by step.");
    const answer=await askAI("You are TK Assist, a careful Maths and Physics tutor. Read the image accurately. Never invent unreadable text; state uncertainty. "+task,
      [{role:"user",content:[{type:"input_text",text:task},{type:"input_image",image_url:dataUrl,detail:"high"}]}]);
    res.json({answer});
  } catch(e){console.error(e);res.status(500).json({error:"Could not process image."});}
});

app.post("/api/calculate",(req,res)=>{
  try {
    const x=req.body.expression;
    if(typeof x!=="string"||!x.trim()||x.length>200) return res.status(400).json({error:"Enter a short expression."});
    const result=evaluate(x,{pi:Math.PI,e:Math.E});
    if(typeof result!=="number"||!Number.isFinite(result)) return res.status(400).json({error:"Expression must return one finite number."});
    res.json({result});
  } catch(e){res.status(400).json({error:"Invalid expression."});}
});

app.post("/api/exam",async(req,res)=>{
  try{
    const {subject,level,count}=req.body, n=Number(count);
    if(!["Mathematics","Physics"].includes(subject)||!["Primary","Secondary","Advanced","University"].includes(level)||![5,10,15].includes(n))
      return res.status(400).json({error:"Invalid exam settings."});
    const raw=await askAI(`Create exactly ${n} original ${subject} multiple-choice questions for ${level}.
Return ONLY JSON: {"questions":[{"question":"...","options":["A","B","C","D"],"correctIndex":0,"explanation":"..."}]}.
Ensure each has one correct option and verify the answer key.`, "Generate the exam.");
    const parsed=JSON.parse(raw.replace(/^```(?:json)?\s*/i,"").replace(/\s*```$/,""));
    if(!Array.isArray(parsed.questions)||parsed.questions.length!==n||parsed.questions.some(q=>typeof q.question!=="string"||!Array.isArray(q.options)||q.options.length!==4||!Number.isInteger(q.correctIndex)||q.correctIndex<0||q.correctIndex>3))
      throw new Error("Bad exam format");
    // Keep key server-side; send only questions/options to browser.
    const id=require("crypto").randomUUID();
    exams.set(id,parsed.questions);
    res.json({id,questions:parsed.questions.map(({question,options})=>({question,options}))});
  }catch(e){console.error(e);res.status(500).json({error:"Could not generate exam."});}
});
const exams=new Map();
app.post("/api/mark-exam",async(req,res)=>{
  const {id,answers}=req.body, qs=exams.get(id);
  if(!qs||!Array.isArray(answers)||answers.length!==qs.length) return res.status(400).json({error:"Invalid or expired exam."});
  let score=0;
  const feedback=qs.map((q,i)=>{
    const correct=String(answers[i])===String(q.correctIndex);
    if(correct) score++;
    return `${i+1}. ${correct?"Correct":"Not quite"} — Correct answer: ${q.options[q.correctIndex]}. ${q.explanation||""}`;
  }).join("\n\n");
  exams.delete(id);
  res.json({feedback:`Score: ${score}/${qs.length}\n\n${feedback}`});
});
app.post("/api/check",async(req,res)=>{
  try{
    const {question,working}=req.body;
    if(typeof question!=="string"||typeof working!=="string"||!question.trim()||!working.trim()||question.length>5000||working.length>10000)
      return res.status(400).json({error:"Enter the question and your working."});
    const answer=await askAI("Check student Maths/Physics work carefully. Identify correct steps, first error, explain correction, and assess final answer. Acknowledge valid alternative methods; state uncertainty.",
      `QUESTION:\n${question}\n\nSTUDENT WORK:\n${working}`);
    res.json({answer});
  }catch(e){console.error(e);res.status(500).json({error:"Could not check working."});}
});
app.listen(process.env.PORT||3000,()=>console.log("TK Assist running on http://localhost:"+(process.env.PORT||3000)));
