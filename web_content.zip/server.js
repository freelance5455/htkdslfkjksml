'use strict';
// Midoo AI secure backend. Requires Node.js 18+ and an OpenAI-compatible API key.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const PORT = Number(process.env.PORT || 3000);
const API_KEY = (process.env.AI_API_KEY || '').trim();
const AI_BASE_URL = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
const AI_MODEL = (process.env.AI_MODEL || 'gpt-4o-mini').trim();
const ROOT = __dirname;
const MAX_BODY = 1024 * 1024;
const MIME = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8','.ico':'image/x-icon','.svg':'image/svg+xml'};
function json(res, status, obj) {
  if (res.headersSent) return;
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '', tooLarge = false;
    req.on('data', chunk => {
      raw += chunk;
      if (Buffer.byteLength(raw) > MAX_BODY) { tooLarge = true; reject(Object.assign(new Error('Request body is too large.'), {status:413})); req.destroy(); }
    });
    req.on('end', () => { if (!tooLarge) resolve(raw); });
    req.on('error', reject);
  });
}
const server = http.createServer(async (req, res) => {
  const pathname = new URL(req.url || '/', 'http://localhost').pathname;
  if (req.method === 'GET' && pathname === '/api/health') {
    return json(res, 200, {ok:true, service:'Midoo AI', aiConfigured:Boolean(API_KEY), model:AI_MODEL, message:API_KEY ? 'AI provider key is configured.' : 'Website is running; configure AI_API_KEY to enable AI replies.'});
  }
  if (req.method === 'POST' && pathname === '/api/chat') {
    if (!API_KEY) return json(res, 503, {error:'Midoo AI website is running, but AI_API_KEY is not configured on the server. Add your provider key in hosting environment variables.'});
    let body;
    try { body = JSON.parse(await readBody(req) || '{}'); }
    catch (e) { return json(res, e.status || 400, {error:e.status === 413 ? e.message : 'Invalid JSON request body.'}); }
    if (!Array.isArray(body.messages) || !body.messages.length) return json(res, 400, {error:'messages must be a non-empty array'});
    const messages = body.messages.filter(m => m && ['system','user','assistant'].includes(m.role) && typeof m.content === 'string' && m.content.trim()).slice(-22);
    if (!messages.length || !messages.some(m => m.role === 'user')) return json(res, 400, {error:'At least one user message is required.'});
    try {
      const upstream = await fetch(`${AI_BASE_URL}/chat/completions`, {
        method:'POST',
        headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},
        body:JSON.stringify({model:AI_MODEL,messages,temperature:0.7}),
        signal:AbortSignal.timeout(60000)
      });
      const data = await upstream.json().catch(() => ({}));
      if (!upstream.ok) {
        const msg = data && data.error && typeof data.error.message === 'string' ? data.error.message : `AI provider returned HTTP ${upstream.status}`;
        return json(res, upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502, {error:msg});
      }
      const reply = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
      if (typeof reply !== 'string' || !reply.trim()) return json(res, 502, {error:'AI provider returned no text response.'});
      return json(res, 200, {reply});
    } catch (e) {
      const timeout = e && (e.name === 'TimeoutError' || e.name === 'AbortError');
      return json(res, timeout ? 504 : 502, {error:timeout ? 'The AI provider took too long to respond. Please try again.' : 'Could not connect to the AI provider. Check the server network and provider settings.'});
    }
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, {'Allow':'GET, HEAD, POST'}); return res.end('Method Not Allowed'); }
  let relative = pathname === '/' ? 'index.html' : decodeURIComponent(pathname).replace(/^\/+/, '');
  const file = path.resolve(ROOT, relative);
  if (file !== ROOT && !file.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, {'Content-Type':'text/plain; charset=utf-8','X-Content-Type-Options':'nosniff'}); return res.end('File not found'); }
    res.writeHead(200, {'Content-Type':MIME[path.extname(file).toLowerCase()] || 'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':path.extname(file)==='.html'?'no-cache':'public, max-age=3600'});
    if (req.method === 'HEAD') return res.end();
    res.end(data);
  });
});
server.listen(PORT, '0.0.0.0', () => console.log(`Midoo AI listening on port ${PORT}. AI configured: ${Boolean(API_KEY)}`));
