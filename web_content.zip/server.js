const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.DEFAULT_APP_PORT || 3000;

function findFile(reqPath) {
  if (reqPath === '/' || reqPath === '') reqPath = '/index.html';
  const dirs = [
    path.join(__dirname, 'public'),
    path.join(__dirname, 'app/src/main/assets'),
    __dirname
  ];
  for (const d of dirs) {
    const candidate = path.join(d, reqPath);
    if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
      return candidate;
    }
  }
  // Fallback to index.html
  for (const d of dirs) {
    const fallback = path.join(d, 'index.html');
    if (fs.existsSync(fallback)) return fallback;
  }
  return null;
}

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.zip': 'application/zip',
  '.txt': 'text/plain; charset=utf-8'
};

const server = http.createServer((req, res) => {
  let reqPath = req.url.split('?')[0];

  if (reqPath === '/download-zip' || reqPath === '/download') {
    const zipPath = path.join(__dirname, 'public/website_source_code.zip');
    if (fs.existsSync(zipPath)) {
      res.writeHead(200, {
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="website_source_code.zip"',
        'Cache-Control': 'no-cache'
      });
      fs.createReadStream(zipPath).pipe(res);
      return;
    }
  }

  if (reqPath === '/download-html') {
    const htmlPath = path.join(__dirname, 'public/index.html');
    if (fs.existsSync(htmlPath)) {
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': 'attachment; filename="invoice_stock_system.html"',
        'Cache-Control': 'no-cache'
      });
      fs.createReadStream(htmlPath).pipe(res);
      return;
    }
  }

  const targetFile = findFile(reqPath);
  if (!targetFile) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('404 Not Found');
    return;
  }

  const ext = path.extname(targetFile).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(targetFile, (err, content) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Server Error: ' + err.message);
      return;
    }
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Access-Control-Allow-Origin': '*'
    });
    res.end(content);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Web server listening on 0.0.0.0:${PORT}`);
});
