const http=require('http'),fs=require('fs'),crypto=require('crypto');
const PORT=process.env.PORT||3000,FILE=process.env.DATA_FILE||'data.json';
const OWNER=process.env.OWNER_CODE_HASH||'__OWNER__';
const UPU=process.env.UPSTASH_REDIS_REST_URL,UPT=process.env.UPSTASH_REDIS_REST_TOKEN;
let DB={users:{},teams:{},tokens:{},news:[],market:[]};
async function upCmd(c){const r=await fetch(UPU,{method:'POST',headers:{Authorization:'Bearer '+UPT,'Content-Type':'application/json'},body:JSON.stringify(c)});return r.json()}
async function loadDB(){if(UPU){try{const r=await upCmd(['GET','mxblade_db']);if(r&&r.result)DB=JSON.parse(r.result)}catch(e){console.log('upstash load failed',e.message)}console.log('db: upstash',Object.keys(DB.users).length,'users')}else{try{DB=JSON.parse(fs.readFileSync(FILE,'utf8'))}catch(e){}console.log('db: file',Object.keys(DB.users).length,'users')}}
let dirty=0;const persist=()=>{dirty=1};
setInterval(()=>{if(dirty){dirty=0;try{if(UPU){upCmd(['SET','mxblade_db',JSON.stringify(DB)]).catch(e=>console.log('upstash save failed',e.message))}else{fs.writeFileSync(FILE+'.tmp',JSON.stringify(DB));fs.renameSync(FILE+'.tmp',FILE)}}catch(e){console.log('save error',e.message)}}},3000);
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const eq=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length==y.length&&crypto.timingSafeEqual(x,y)};
const now=()=>Date.now();const hits=new Map();
function limited(k,max,win){const t=now(),a=(hits.get(k)||[]).filter(x=>t-x<win);a.push(t);hits.set(k,a);return a.length>max}
setInterval(()=>{const t=now();for(const[k,a]of hits)if(!a.length||t-a[a.length-1]>3600000)hits.delete(k);for(const h of Object.keys(DB.tokens||{}))if(DB.tokens[h].exp<t)delete DB.tokens[h]},600000);
const fails=new Map(),ofail=new Map();
const key=n=>Object.keys(DB.users).find(u=>u.toLowerCase()==String(n||'').toLowerCase());
const isOn=u=>now()-(u.seen||0)<40000;
const pw=(p,s)=>crypto.scryptSync(String(p||''),s,32).toString('hex');
const ownerOk=c=>eq(sha('sbowner|'+String(c||'')),OWNER);
function ownerGate(n,code){if(!code)return false;const f=ofail.get(n)||{c:0,u:0};if(f.u>now())return false;if(ownerOk(code)){ofail.delete(n);return true}f.c++;if(f.c>=5){f.u=now()+1800000;f.c=0}ofail.set(n,f);return false}
const mk=n=>{DB.tokens=DB.tokens||{};const t=crypto.randomBytes(24).toString('hex');DB.tokens[sha(t)]={n,exp:now()+30*864e5};const mine=Object.keys(DB.tokens).filter(h=>DB.tokens[h].n==n).sort((a,b)=>DB.tokens[a].exp-DB.tokens[b].exp);while(mine.length>5)delete DB.tokens[mine.shift()];persist();return t};
const push=(to,msg)=>{const u=DB.users[to];if(!u)return false;u.inbox=u.inbox||[];if(u.inbox.length>200)u.inbox.shift();u.inbox.push(msg);persist();return true};
const ops={
register(b,ip){if(limited('reg:'+ip,10,3600000))return{err:'rate'};const n=String(b.name||'').trim();if(!/^[\w\u0600-\u06FF]{6,16}$/.test(n))return{err:'bad_name'};if(key(n))return{err:'taken'};if(String(b.pass||'').length<6||String(b.pass).length>64)return{err:'bad_pass'};if(String(b.pass).toLowerCase()==n.toLowerCase())return{err:'same'};const salt=crypto.randomBytes(8).toString('hex');DB.users[n]={salt,hash:pw(b.pass,salt),data:b.data||null,inbox:[],mx:0,seen:now(),team:null};persist();return{token:mk(n),name:n,data:DB.users[n].data,mx:0,team:null,admin:false}},
login(b,ip){const ln=String(b.name||'').toLowerCase().slice(0,32),f=fails.get(ln)||{n:0,u:0};if(f.u>now())return{err:'locked',wait:Math.ceil((f.u-now())/1000)};if(limited('lg:'+ip,30,600000))return{err:'rate'};const k=key(b.name),u=k&&DB.users[k],h=pw(b.pass,u?u.salt:'0000000000000000');if(!u||!eq(h,u.hash)){f.n++;if(f.n>=5){f.u=now()+900000;f.n=0}fails.set(ln,f);return{err:'bad_login'}}fails.delete(ln);u.seen=now();persist();return{token:mk(k),name:k,data:u.data,mx:u.mx||0,team:u.team,admin:!!u.admin}},
};
const utc=d=>new Date(d).toISOString().slice(0,10);
const canPost=(n,b)=>!!(DB.users[n].admin||ownerGate(n,b.code));
const authed={
news(n){return{news:(DB.news||[]).slice(-40).reverse()}},
newsadd(n,b){if(!canPost(n,b))return{err:'denied'};const title=String(b.title||'').slice(0,60),text=String(b.text||'').slice(0,800),img=b.img?String(b.img):'';if(!text&&!img)return{err:'empty'};if(img&&(img.length>280000||!/^data:image\/(png|jpeg|webp);base64,/.test(img)))return{err:'bad_img'};DB.news=DB.news||[];DB.news.push({id:now()+'-'+Math.random().toString(36).slice(2,6),title,text,img,by:n,ts:now()});if(DB.news.length>60)DB.news.shift();persist();return{ok:1}},
newsdel(n,b){if(!canPost(n,b))return{err:'denied'};DB.news=(DB.news||[]).filter(x=>x.id!==String(b.id));persist();return{ok:1}},
dailycheck(n){const u=DB.users[n],today=utc(now()),yest=utc(now()-864e5),d=u.daily||{last:'',streak:0};if(d.last===today)return{claimed:0,streak:d.streak};const streak=d.last===yest?d.streak+1:1;u.daily={last:today,streak};u.inbox=u.inbox||[];u.inbox.push({t:'gift',from:'مكافأة يومية',g:{k:'m',v:500},ts:now()});let mx=0;if(streak%7===0){u.mx=(u.mx||0)+5;mx=5}persist();return{claimed:1,streak,mx}},
marketlist(n){return{items:(DB.market||[]).slice(-200)}},
marketsell(n,b){DB.market=DB.market||[];const kind=String(b.kind),v=kind==='up'?String(b.v):+b.v,price=Math.floor(+b.price);if(!['sw','ch','ar','wg','up'].includes(kind)||!(price>=1&&price<=1e6))return{err:'bad'};if(DB.market.filter(x=>x.seller===n).length>=10)return{err:'limit'};const d=DB.users[n].data||{};let ok=false;if(kind==='sw')ok=Array.isArray(d.sw)&&d.sw.includes(v)&&v!==d.es;else if(kind==='ch')ok=Array.isArray(d.ch)&&d.ch.includes(v)&&v!==d.ec;else if(kind==='ar')ok=Array.isArray(d.ao)&&d.ao.includes(v)&&v!==d.ar;else if(kind==='wg')ok=Array.isArray(d.wo)&&d.wo.includes(v)&&v!==d.wg;else if(kind==='up')ok=!!(d.upg&&d.upg[v]&&d.upg[v].own&&d.upg[v].on<0);if(!ok)return{err:'not_owned'};if(kind==='sw')d.sw=d.sw.filter(x=>x!==v);else if(kind==='ch')d.ch=d.ch.filter(x=>x!==v);else if(kind==='ar')d.ao=d.ao.filter(x=>x!==v);else if(kind==='wg')d.wo=d.wo.filter(x=>x!==v);else d.upg[v].own=0;DB.market.push({id:now()+'-'+Math.random().toString(36).slice(2,6),seller:n,kind,v,price,ts:now()});persist();return{ok:1}},
marketcancel(n,b){const i=(DB.market||[]).findIndex(x=>x.id===String(b.id)&&x.seller===n);if(i<0)return{err:'no_listing'};const L=DB.market[i],d=DB.users[n].data||{};if(L.kind==='sw'){d.sw=[...(d.sw||[]),L.v]}else if(L.kind==='ch'){d.ch=[...(d.ch||[]),L.v]}else if(L.kind==='ar'){d.ao=[...(d.ao||[]),L.v]}else if(L.kind==='wg'){d.wo=[...(d.wo||[]),L.v]}else{d.upg=d.upg||{};d.upg[L.v]={own:1,on:-1}}DB.users[n].data=d;DB.market.splice(i,1);persist();return{ok:1}},
marketbuy(n,b){const i=(DB.market||[]).findIndex(x=>x.id===String(b.id));if(i<0)return{err:'no_listing'};const L=DB.market[i];if(L.seller===n)return{err:'own'};const buyer=DB.users[n];if((buyer.mx||0)<L.price)return{err:'no_funds'};const seller=DB.users[L.seller];if(!seller)return{err:'no_user'};buyer.mx-=L.price;seller.mx=(seller.mx||0)+L.price;DB.market.splice(i,1);buyer.inbox=buyer.inbox||[];buyer.inbox.push({t:'gift',from:L.seller,g:{k:L.kind,v:L.v},ts:now()});seller.inbox=seller.inbox||[];seller.inbox.push({t:'mxrecv',from:'السوق: '+n,n:L.price,ts:now()});persist();return{ok:1,mx:buyer.mx}},
profile(n,b){const k=key(b.name);if(!k)return{exists:0};const d=DB.users[k].data||{};return{exists:1,name:k,ach:(d.ach||[]).length,level:d.u||1}},

save(n,b){const d=b.data;if(!d||typeof d!='object'||JSON.stringify(d).length>300000)return{err:'bad'};if(limited('sv:'+n,60,60000))return{err:'rate'};d.m=Math.min(Math.max(0,+d.m||0),1e15);d.u=Math.min(100,Math.max(1,Math.floor(+d.u||1)));delete d.mx;delete d.adm;for(const k of['sw','ch','ao','wo'])if(Array.isArray(d[k]))d[k]=d[k].filter(x=>Number.isInteger(x)&&x>=0&&x<200).slice(0,100);if(Array.isArray(d.inbox))d.inbox=d.inbox.slice(-200);DB.users[n].data=d;persist();return{ok:1}},
logout(n,b){delete DB.tokens[sha(String(b.token||''))];persist();return{ok:1}},
hb(n){const u=DB.users[n];u.seen=now();const inbox=u.inbox||[];u.inbox=[];if(inbox.length)persist();return{ok:1,inbox,mx:u.mx||0,team:u.team,admin:!!u.admin}},
send(n,b){if(limited('snd:'+n,40,60000))return{err:'rate'};const to=key(b.to);if(!to||to==n)return{err:'no_user'};const m=b.msg||{};m.from=n;m.ts=now();if(JSON.stringify(m).length>5000)return{err:'big'};push(to,m);return{ok:1}},
who(n,b){const k=key(b.name);return k?{exists:1,online:isOn(DB.users[k]),name:k}:{exists:0}},
mxsend(n,b){if(limited('mx:'+n,20,60000))return{err:'rate'};const to=key(b.to),a=Math.floor(+b.n);if(!to||to==n)return{err:'no_user'};if(!(a>0)||a>(DB.users[n].mx||0))return{err:'no_funds'};DB.users[n].mx-=a;DB.users[to].mx=(DB.users[to].mx||0)+a;push(to,{t:'mxrecv',from:n,n:a,ts:now()});persist();return{ok:1,mx:DB.users[n].mx}},
mxspend(n,b){const a=Math.floor(+b.n);if(!(a>0)||a>(DB.users[n].mx||0))return{err:'no_funds',mx:DB.users[n].mx||0};DB.users[n].mx-=a;persist();return{ok:1,mx:DB.users[n].mx}},
mxset(n,b){if(!ownerGate(n,b.code))return{err:'denied'};const a=Math.max(0,Math.min(9e15,Math.floor(+b.n)||0));DB.users[n].mx=a;persist();return{ok:1,mx:a}},
adminadd(n,b){if(!ownerGate(n,b.code))return{err:'denied'};const k=key(b.name);if(!k)return{err:'no_user'};DB.users[k].admin=1;persist();return{ok:1,name:k}},
adminremove(n,b){if(!ownerGate(n,b.code))return{err:'denied'};const k=key(b.name);if(!k)return{err:'no_user'};DB.users[k].admin=0;persist();return{ok:1}},
adminlist(n,b){if(!ownerGate(n,b.code)&&!DB.users[n].admin)return{err:'denied'};return{admins:Object.keys(DB.users).filter(x=>DB.users[x].admin)}},
giveall(n,b){const u=DB.users[n];if(!ownerGate(n,b.code)&&!u.admin)return{err:'denied'};const t0=now();if(t0-(u.lastGive||0)<5000)return{err:'wait'};const kind=String(b.kind),a=Math.floor(+b.n)||0;if((kind=='mx'||kind=='m')&&!(a>0&&a<=1e12))return{err:'bad'};if(!['mx','m','sw','ar','wg','ch','up'].includes(kind))return{err:'bad'};u.lastGive=t0;let c=0;for(const nm of Object.keys(DB.users)){const t=DB.users[nm];if(!isOn(t))continue;if(kind=='mx'){t.mx=(t.mx||0)+a;push(nm,{t:'mxrecv',from:n,n:a,ts:t0})}else if(kind=='m')push(nm,{t:'gift',from:n,g:{k:'m',v:a},ts:t0});else push(nm,{t:'gift',from:n,g:{k:kind,v:b.v},ts:t0});c++}persist();return{ok:1,count:c}},
teamcreate(n,b){const t=String(b.name||'').trim();if(!/^[\w\u0600-\u06FF]{3,16}$/.test(t))return{err:'bad_name'};if(DB.users[n].team)return{err:'in_team'};if(Object.keys(DB.teams).some(x=>x.toLowerCase()==t.toLowerCase()))return{err:'taken'};DB.teams[t]={leader:n,members:[n],inv:[]};DB.users[n].team=t;persist();return{ok:1,team:t}},
teaminvite(n,b){const u=DB.users[n],t=u.team&&DB.teams[u.team];if(!t)return{err:'no_team'};const to=key(b.to);if(!to||to==n)return{err:'no_user'};if(DB.users[to].team)return{err:'has_team'};if(t.members.length>=30)return{err:'full'};if(!t.inv.includes(to))t.inv.push(to);push(to,{t:'tinv',team:u.team,from:n,ts:now()});persist();return{ok:1}},
teamjoin(n,b){const u=DB.users[n];if(u.team)return{err:'in_team'};const tn=Object.keys(DB.teams).find(x=>x==b.team),t=DB.teams[tn];if(!t||!t.inv.includes(n))return{err:'no_invite'};t.inv=t.inv.filter(x=>x!=n);t.members.push(n);u.team=tn;persist();return{ok:1,team:tn}},
teamleave(n){const u=DB.users[n],t=u.team&&DB.teams[u.team];if(!t)return{err:'no_team'};t.members=t.members.filter(x=>x!=n);if(!t.members.length)delete DB.teams[u.team];else if(t.leader==n)t.leader=t.members[0];u.team=null;persist();return{ok:1}},
teaminfo(n){const u=DB.users[n],t=u.team&&DB.teams[u.team];if(!t)return{team:null};return{team:u.team,leader:t.leader,members:t.members.map(m=>({name:m,online:DB.users[m]?isOn(DB.users[m]):false}))}}
};
const srv=http.createServer((req,res)=>{
if(req.method=='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,GET,OPTIONS'});return res.end()}
if(req.method=='GET'){res.writeHead(200,{'Content-Type':'text/plain','Access-Control-Allow-Origin':'*'});return res.end('MX Blade server OK')}
const ip=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0].trim();if(limited('ip:'+ip,240,60000))return send(res,{err:'rate'},429);
let body='';req.on('data',d=>{body+=d;if(body.length>300000)req.destroy()});
req.on('end',()=>{let b;try{b=JSON.parse(body||'{}')}catch(e){return send(res,{err:'bad_json'},400)}
try{if(ops[b.op])return send(res,ops[b.op](b,ip));const rec=DB.tokens&&DB.tokens[sha(String(b.token||''))],n=rec&&rec.exp>now()?rec.n:null;if(!n||!DB.users[n])return send(res,{err:'auth'},401);if(!authed[b.op])return send(res,{err:'bad_op'},400);send(res,authed[b.op](n,b,ip))}catch(e){send(res,{err:'server'},500)}})
});
function send(res,o,c=200){res.writeHead(c,{'X-Content-Type-Options':'nosniff','Cache-Control':'no-store','Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,GET,OPTIONS'});res.end(JSON.stringify(o))}
loadDB().then(()=>srv.listen(PORT,()=>console.log('MX Blade server on port',PORT)));
