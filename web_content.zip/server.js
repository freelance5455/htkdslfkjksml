'use strict';
// Super Football Arena - سيرفر محلي بدون أي مكتبات خارجية (Node.js فقط)
const http=require('http'),crypto=require('crypto'),fs=require('fs'),os=require('os'),path=require('path');
const PORT=+process.env.PORT||3000,W=50,H=30,GW=8,PR=2.2,BR=1.2;
const cl=(v,a,b)=>Math.max(a,Math.min(b,v)),f2=v=>Math.round(v*100)/100;
const ips=()=>{const o=[];for(const a of Object.values(os.networkInterfaces()))for(const i of a)if(i.family==='IPv4'&&!i.internal)o.push(i.address);return o};
const srv=http.createServer((q,r)=>{try{const h=fs.readFileSync(path.join(__dirname,'index.html'));r.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});r.end(h)}catch(e){r.writeHead(500);r.end('index.html missing')}});

/* ---------- WebSocket يدوي ---------- */
srv.on('upgrade',(q,s)=>{
  const k=q.headers['sec-websocket-key'];if(!k){s.destroy();return}
  s.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+crypto.createHash('sha1').update(k+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64')+'\r\n\r\n');
  const c={s,buf:Buffer.alloc(0),slot:-1,tok:''};s.setNoDelay(true);
  s.on('data',d=>{c.buf=Buffer.concat([c.buf,d]);frames(c)});
  s.on('close',()=>drop(c));s.on('error',()=>{});
});
function frames(c){for(;;){const b=c.buf;if(b.length<2)return;let l=b[1]&127,o=2;
  if(l===126){if(b.length<4)return;l=b.readUInt16BE(2);o=4}else if(l===127){c.s.destroy();return}
  const m=(b[1]&128)?4:0;if(b.length<o+m+l)return;
  const mk=b.slice(o,o+m),p=Buffer.from(b.slice(o+m,o+m+l));if(m)for(let i=0;i<l;i++)p[i]^=mk[i&3];
  c.buf=b.slice(o+m+l);const op=b[0]&15;
  if(op===8){c.s.end();return}if(op===9){send(c,p,10);continue}
  if(op===1){try{msg(c,JSON.parse(p.toString()))}catch(e){}}}}
function send(c,d,op){if(c.s.destroyed)return;const p=Buffer.isBuffer(d)?d:Buffer.from(d),n=p.length;
  const h=n<126?Buffer.from([128|(op||1),n]):Buffer.from([128|(op||1),126,n>>8,n&255]);c.s.write(Buffer.concat([h,p]))}
const err=(c,m)=>send(c,JSON.stringify({t:'err',m}));

/* ---------- الغرفة واللعبة ---------- */
let R=null;
const mkp=i=>({x:i?25:-25,z:0,vx:0,vz:0,ix:0,iz:0,run:0,k:0,pp:0,cd:0,spd:0,sh:0,mag:0,fire:0});
const newRoom=m=>{const d=[1,3,5].includes(+m.dur)?+m.dur:3;return{dur:d,t:d*60,st:'wait',tm:0,paused:true,c:[null,null],tok:[null,null],nm:['',''],co:['#e53935','#1e88e5'],pw:[1,1],p:[mkp(0),mkp(1)],b:{x:0,z:0,vx:0,vz:0},sc:[0,0],fr:0,fl:0,ev:[]}};
const resetPos=r=>{r.p=[mkp(0),mkp(1)];r.b={x:0,z:0,vx:0,vz:0};r.fr=0;r.fl=0};
function attach(c,i,m){const r=R;r.c[i]=c;r.tok[i]=c.tok;c.slot=i;
  r.nm[i]=String(m.name||'لاعب').slice(0,12);if(/^#[0-9a-f]{6}$/i.test(m.col))r.co[i]=m.col;r.pw[i]=cl(+m.pw||1,1,5);
  if(r.co[0]===r.co[1])r.co[1]=r.co[0]==='#1e88e5'?'#e53935':'#1e88e5';
  send(c,JSON.stringify({t:'you',i,ips:ips(),port:PORT}));
  if(r.c[0]&&r.c[1]&&r.st==='wait'){r.st='count';r.tm=3}}
function msg(c,m){
  if(m.t==='hi'){c.tok=String(m.tok||'');
    if(R){const i=R.tok.indexOf(c.tok);if(i>=0){if(R.c[i]&&R.c[i]!==c){R.c[i].slot=-1;R.c[i].s.destroy()}return attach(c,i,m)}}
    const live=R&&(R.c[0]||R.c[1]);
    if(m.role==='create'){if(live)return err(c,'الغرفة مشغولة بمباراة جارية');R=newRoom(m);return attach(c,0,m)}
    if(m.role==='join'){if(!R||!R.tok[0])return err(c,'لا توجد غرفة. اطلب من صديقك إنشاء غرفة أولاً');if(R.tok[1])return err(c,'الغرفة ممتلئة');return attach(c,1,m)}
    return}
  if(!R||c.slot<0)return;const q=R.p[c.slot];
  if(m.t==='in'){q.ix=cl(+m.x||0,-1,1);q.iz=cl(+m.z||0,-1,1);q.run=m.r?1:0;if(m.k)q.k=m.k|0;if(m.p)q.pp=1}
  else if(m.t==='re'&&R.st==='end'){R.sc=[0,0];R.t=R.dur*60;resetPos(R);R.st='count';R.tm=3}
}
function drop(c){if(R&&c.slot>=0&&R.c[c.slot]===c)R.c[c.slot]=null}

function tick(){const r=R;if(!r)return;const dt=1/60;
  r.paused=!(r.c[0]&&r.c[1]);if(r.paused||r.st==='wait'||r.st==='end')return;   // انقطع أحد اللاعبين: المباراة متوقفة
  if(r.st==='count'||r.st==='goal'){r.tm-=dt;if(r.tm<=0){if(r.st==='goal'){resetPos(r);r.st='count';r.tm=1.5}else{r.st='play';r.ev.push('w')}}return}
  r.t-=dt;if(r.t<=0){r.t=0;r.st='end';r.ev.push('w');return}
  const b=r.b;
  r.p.forEach((q,i)=>{
    const sp=(q.run?15:10)*(q.spd>0?1.7:1),a=Math.min(1,10*dt);
    q.vx+=(q.ix*sp-q.vx)*a;q.vz+=(q.iz*sp-q.vz)*a;
    q.x=cl(q.x+q.vx*dt,-W+PR,W-PR);q.z=cl(q.z+q.vz*dt,-H+PR,H-PR);
    for(const k of['cd','spd','sh','mag'])if(q[k]>0)q[k]-=dt;
    if(q.pp){q.pp=0;if(q.cd<=0){q.cd=10;const w=r.pw[i];
      if(w===1)q.fire=1;else if(w===2)q.spd=4;else if(w===3)r.fr=2;else if(w===4)q.sh=5;else q.mag=3;r.ev.push('p')}}
  });
  if(r.fr>0){r.fr-=dt;b.vx=b.vz=0}
  else{
    for(const q of r.p)if(q.mag>0){const dx=q.x-b.x,dz=q.z-b.z,d=Math.hypot(dx,dz)||1;if(d<30){b.vx+=dx/d*45*dt;b.vz+=dz/d*45*dt}}
    b.x+=b.vx*dt;b.z+=b.vz*dt;const f=Math.pow(.5,dt);b.vx*=f;b.vz*=f;
  }
  if(Math.hypot(b.vx,b.vz)<12)r.fl=0;
  if(Math.abs(b.z)>H-BR){b.z=Math.sign(b.z)*(H-BR);b.vz*=-.8}
  if(Math.abs(b.x)>W-BR){
    const side=b.x<0?0:1,sx=Math.sign(b.x);
    if(Math.abs(b.z)<GW){
      if(r.p[side].sh>0){b.x=sx*(W-BR);b.vx*=-1.1}                    // درع المرمى
      else if(Math.abs(b.x)>W+1){r.sc[1-side]++;r.st='goal';r.tm=2.2;r.fl=0;r.ev.push('g');return}
    }else{b.x=sx*(W-BR);b.vx*=-.8}
  }
  r.p.forEach(q=>{
    const dx=b.x-q.x,dz=b.z-q.z,d=Math.hypot(dx,dz)||.01,m=PR+BR,nx=dx/d,nz=dz/d;
    if(r.fr<=0&&d<m){b.x=q.x+nx*m;b.z=q.z+nz*m;b.vx=q.vx*1.2+nx*6;b.vz=q.vz*1.2+nz*6}
    if(q.k&&d<m+1.8){
      let p=q.k===1?36:20,ux=nx,uz=nz;const il=Math.hypot(q.ix,q.iz);
      if(il>.2){ux=nx*.5+q.ix/il*.5;uz=nz*.5+q.iz/il*.5;const l=Math.hypot(ux,uz)||1;ux/=l;uz/=l}
      if(q.fire&&q.k===1){p*=1.7;q.fire=0;r.fl=1}
      r.fr=0;b.vx=ux*p;b.vz=uz*p;r.ev.push('k');
    }
    q.k=0;
  });
}
function bc(){const r=R;if(!r)return;const b=r.b;
  const s=JSON.stringify({t:'s',st:r.st,pa:r.paused?1:0,tm:Math.round(r.tm*10)/10,tl:Math.ceil(r.t),sc:r.sc,nm:r.nm,co:r.co,dur:r.dur,
    b:[f2(b.x),f2(b.z),f2(b.vx),f2(b.vz),r.fr>0?1:0,r.fl],
    p:r.p.map(q=>[f2(q.x),f2(q.z),Math.ceil(Math.max(0,q.cd)),q.spd>0?1:0,q.sh>0?1:0,q.mag>0?1:0,q.fire]),ev:r.ev});
  r.ev=[];for(const c of r.c)if(c)send(c,s)}
let n=0;setInterval(()=>{tick();if(++n%2===0)bc()},1000/60);   // فيزياء 60Hz، إرسال 30Hz

srv.listen(PORT,'0.0.0.0',()=>{
  console.log('\n⚽ Super Football Arena شغّال');
  console.log('المضيف: افتح  http://localhost:'+PORT);
  console.log('الصديق: افتح أحد هذه الروابط من جواله (نفس الواي فاي):');
  ips().forEach(i=>console.log('   http://'+i+':'+PORT));console.log('');
});
