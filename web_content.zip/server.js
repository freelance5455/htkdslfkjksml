const express = require('express');
const ftp = require('basic-ftp');
const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });
const PORT = Number(process.env.PORT || 3210);
const sessions = new Map();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function cleanRemote(p = '/') {
  const bits = String(p).replace(/\\/g, '/').split('/').filter(x => x && x !== '.');
  if (bits.some(x => x === '..')) throw new Error('Caminho FTP inválido.');
  return '/' + bits.join('/');
}
async function withFtp(session, job) {
  if (!session) throw new Error('Sessão expirada. Conecte novamente.');
  const client = new ftp.Client(9000);
  client.ftp.verbose = false;
  try {
    await client.access({ host: session.host, port: session.port, user: session.user, password: session.password, secure: false });
    return await job(client);
  } finally { client.close(); }
}
function safeError(e) { return e && e.message ? e.message : 'Falha na operação FTP.'; }

app.post('/api/connect', async (req, res) => {
  const { host, port = 21, user = 'xbox', password = '' } = req.body || {};
  if (!host) return res.status(400).json({ error: 'Informe o IP do Xbox.' });
  const config = { host: String(host).trim(), port: Number(port) || 21, user: String(user), password: String(password) };
  try {
    await withFtp(config, async c => { await c.list('/'); });
    const id = crypto.randomUUID(); sessions.set(id, config);
    res.json({ id, host: config.host, port: config.port });
  } catch (e) { res.status(502).json({ error: `Não consegui conectar: ${safeError(e)}` }); }
});
app.post('/api/disconnect', (req, res) => { sessions.delete(req.body?.id); res.json({ ok: true }); });
app.get('/api/list', async (req, res) => {
  try {
    const session = sessions.get(req.query.id);
    const dir = cleanRemote(req.query.path || '/');
    const entries = await withFtp(session, async c => (await c.list(dir)).map(item => ({
      name: item.name, type: item.isDirectory ? 'dir' : 'file', size: item.size || 0,
      modified: item.modifiedAt ? item.modifiedAt.toISOString() : null
    })).filter(x => x.name !== '.' && x.name !== '..'));
    res.json({ path: dir, entries });
  } catch (e) { res.status(400).json({ error: safeError(e) }); }
});
app.get('/api/scan', async (req, res) => {
  try {
    const session = sessions.get(req.query.id), start = cleanRemote(req.query.path || '/');
    const results = []; let visited = 0;
    async function walk(dir, depth) {
      if (depth > 5 || visited >= 900) return;
      let items;
      try { items = await withFtp(session, c => c.list(dir)); } catch { return; }
      visited += items.length;
      const hasXex = items.some(x => !x.isDirectory && /^default\.xex$/i.test(x.name));
      if (hasXex) results.push({ name: path.posix.basename(dir) || dir, path: dir, xex: cleanRemote(dir + '/default.xex') });
      if (depth < 5) {
        for (const item of items) {
          if (item.isDirectory && !/^\.|\$/.test(item.name)) {
            await walk(cleanRemote(dir + '/' + item.name), depth + 1);
            if (visited >= 900) break;
          }
        }
      }
    }
    await walk(start, 0);
    res.json({ games: results, scanned: visited, truncated: visited >= 900 });
  } catch (e) { res.status(400).json({ error: safeError(e) }); }
});
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    const session = sessions.get(req.body.id);
    if (!req.file) return res.status(400).json({ error: 'Escolha uma imagem.' });
    const remote = cleanRemote(req.body.remotePath || '/');
    const name = path.posix.basename(remote);
    if (!/^[\w .()\-]+\.(jpe?g|png|webp)$/i.test(name)) return res.status(400).json({ error: 'Use um destino com nome .jpg, .png ou .webp.' });
    await withFtp(session, async c => {
      const temp = path.join(__dirname, `.upload-${crypto.randomUUID()}`);
      try { fs.writeFileSync(temp, req.file.buffer); await c.uploadFrom(temp, remote); }
      finally { try { fs.unlinkSync(temp); } catch {} }
    });
    res.json({ ok: true, path: remote });
  } catch (e) { res.status(400).json({ error: safeError(e) }); }
});
app.get('/api/health', (_, res) => res.json({ ok: true }));
app.listen(PORT, '127.0.0.1', () => console.log(`Aurora Manager em http://127.0.0.1:${PORT}`));
