const express = require('express');
const path = require('path');
const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_KEY = process.env.ADMIN_KEY;
if (!ADMIN_KEY) { console.error('Set ADMIN_KEY to a long private value before starting.'); process.exit(1); }
app.use(express.json({limit:'16kb'}));
app.use(express.static(path.join(__dirname,'public')));
let latest = {id:'initial',kind:'none',name:'',msg:'Немає активних тестових подій',time:new Date().toISOString()};
const clients = new Set();
function publish(){const line='data: '+JSON.stringify(latest)+'\n\n'; for(const res of clients){try{res.write(line)}catch(_){clients.delete(res)}}}
app.get('/events',(req,res)=>{res.set({'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});res.flushHeaders?.();clients.add(res);res.write('data: '+JSON.stringify(latest)+'\n\n');req.on('close',()=>clients.delete(res));});
app.get('/api/status',(_req,res)=>res.json({ok:true,connectedClients:clients.size}));
app.post('/api/send',(req,res)=>{if(req.get('x-admin-key')!==ADMIN_KEY)return res.status(401).json({ok:false,error:'Неверный ключ администратора'});const {kind,name,msg}=req.body||{};if(!kind||!name)return res.status(400).json({ok:false,error:'Нужно выбрать событие и область'});latest={id:Date.now().toString(),kind:String(kind).slice(0,100),name:String(name).slice(0,100),msg:String(msg||'Тестовое сообщение симулятора').slice(0,500),time:new Date().toISOString()};publish();res.json({ok:true,event:latest,connectedClients:clients.size});});
app.get('/health',(_req,res)=>res.json({ok:true,service:'fictional-alert-simulator'}));
app.listen(PORT,()=>console.log('Simulator server listening on '+PORT));
