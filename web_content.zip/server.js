require('dotenv').config();
const express=require('express');
const helmet=require('helmet');
const cors=require('cors');
const rateLimit=require('express-rate-limit');
const admin=require('firebase-admin');
const path=require('path');
const crypto=require('crypto');
const {z}=require('zod');
const {createClient}=require('@supabase/supabase-js');
const {searchWeb}=require('./src/search');
const {answerWithModel}=require('./src/model');

const app=express();
const PORT=Number(process.env.PORT||3000);
const supabase=createClient(process.env.SUPABASE_URL||'',process.env.SUPABASE_SERVICE_ROLE_KEY||'',{
  auth:{persistSession:false,autoRefreshToken:false}
});
let firebaseReady=false;
try {
 const file=process.env.FIREBASE_SERVICE_ACCOUNT;
 if(file) { admin.initializeApp({credential:admin.credential.cert(require(path.resolve(file)))}); firebaseReady=true; }
} catch(e) { console.error('Firebase Admin não inicializado:',e.message); }

const allowedOrigins=[process.env.APP_ORIGIN||'http://localhost:3000',process.env.CHROME_EXTENSION_ORIGIN].filter(Boolean);
app.use(cors({origin:(origin,cb)=>{
 if(!origin || allowedOrigins.includes(origin)) return cb(null,true);
 return cb(new Error('Origem não autorizada pelo CORS.'));
},methods:['GET','POST','DELETE','OPTIONS'],allowedHeaders:['Content-Type','Authorization','X-Chrome-Bridge-Token']}));
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'2mb'}));
app.use(express.static(path.join(__dirname,'public')));
app.use('/api/',rateLimit({windowMs:60000,limit:Number(process.env.RATE_LIMIT_PER_MINUTE||90),standardHeaders:true,legacyHeaders:false}));
const text=(v,n=10000)=>typeof v==='string'?v.trim().slice(0,n):'';
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');

async function verifyFirebase(req,res,next) {
 const h=req.headers.authorization||'';
 if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Sessão ausente. Entre novamente.'});
 if(!firebaseReady) {
  if(process.env.NODE_ENV==='production') return res.status(503).json({error:'Firebase Admin não configurado no servidor.'});
  req.uid='local-development-user'; return next();
 }
 try { const decoded=await admin.auth().verifyIdToken(h.slice(7)); req.uid=decoded.uid; next(); }
 catch { return res.status(401).json({error:'Token Firebase inválido ou expirado.'}); }
}
async function verifyChrome(req,res,next) {
 const token=req.headers['x-chrome-bridge-token'];
 if(!token) return res.status(401).json({error:'Extensão não pareada. Gere um código no site.'});
 const {data,error}=await supabase.from('chrome_tokens').select('id,owner_uid,expires_at').eq('token_hash',hash(token)).maybeSingle();
 if(error||!data||new Date(data.expires_at)<new Date()) return res.status(401).json({error:'Conexão Chrome expirada. Faça o pareamento novamente.'});
 req.uid=data.owner_uid; req.chromeTokenId=data.id; next();
}
function supaReady(res) {
 if(!process.env.SUPABASE_URL||!process.env.SUPABASE_SERVICE_ROLE_KEY) { res.status(503).json({error:'Configure SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY no servidor.'}); return false; }
 return true;
}
async function storeMessage(uid,role,content) {
 const {error}=await supabase.from('conversations').insert({owner_uid:uid,role,content});
 if(error) throw error;
}
async function retrieveKnowledge(uid,query,limit=6) {
 const {data,error}=await supabase.rpc('search_knowledge',{query_text:query,match_owner:uid,result_limit:limit});
 if(error) { console.error('Busca na base:',error.message); return []; }
 return data||[];
}
app.get('/health',async(req,res)=>{
 const configured=!!(process.env.SUPABASE_URL&&process.env.SUPABASE_SERVICE_ROLE_KEY);
 let dbStatus='not-configured';
 if(configured) { const {error}=await supabase.from('knowledge_documents').select('id',{head:true,count:'exact'}); dbStatus=error?'error':'connected'; }
 res.json({ok:true,name:'Universal AI',version:'2.0.0',firebaseAdmin:firebaseReady,supabase:dbStatus,modelConfigured:!!(process.env.AI_BASE_URL&&process.env.AI_API_KEY&&process.env.AI_MODEL),searchConfigured:!!process.env.BRAVE_SEARCH_API_KEY});
});
app.get('/api/me',verifyFirebase,(req,res)=>res.json({uid:req.uid}));

app.post('/api/chat',verifyFirebase,async(req,res)=>{
 if(!supaReady(res)) return;
 const schema=z.object({message:z.string().trim().min(1).max(8000),useWeb:z.boolean().optional()});
 const parsed=schema.safeParse(req.body);
 if(!parsed.success) return res.status(400).json({error:'Mensagem inválida.'});
 const message=parsed.data.message;
 try {
  await storeMessage(req.uid,'user',message);
  const docs=await retrieveKnowledge(req.uid,message,6);
  let web=[];
  if(parsed.data.useWeb===true) web=await searchWeb(message);
  const recent=await supabase.from('conversations').select('role,content').eq('owner_uid',req.uid).order('created_at',{ascending:false}).limit(12);
  const history=(recent.data||[]).reverse();
  const reply=await answerWithModel({message,history,documents:docs,web});
  await storeMessage(req.uid,'assistant',reply);
  res.json({reply,knowledgeMatches:docs.length,webSources:web.map(x=>({title:x.title,url:x.url}))});
 } catch(e) { console.error('Chat error:',e); res.status(500).json({error:'Erro ao processar conversa. Verifique Supabase e configuração do modelo.'}); }
});

app.get('/api/history',verifyFirebase,async(req,res)=>{
 if(!supaReady(res)) return;
 const {data,error}=await supabase.from('conversations').select('role,content,created_at').eq('owner_uid',req.uid).order('created_at',{ascending:true}).limit(100);
 if(error) return res.status(500).json({error:'Não foi possível carregar histórico.'});
 res.json({messages:data||[]});
});
app.delete('/api/history',verifyFirebase,async(req,res)=>{
 if(!supaReady(res)) return;
 const {error}=await supabase.from('conversations').delete().eq('owner_uid',req.uid);
 if(error) return res.status(500).json({error:'Falha ao limpar histórico.'});
 res.json({ok:true});
});

app.get('/api/knowledge',verifyFirebase,async(req,res)=>{
 if(!supaReady(res)) return;
 const {data,error}=await supabase.from('knowledge_documents').select('id,title,source,tags,created_at').or(`owner_uid.eq.${req.uid},owner_uid.is.null`).order('created_at',{ascending:false}).limit(300);
 if(error) return res.status(500).json({error:'Falha ao listar documentos.'});
 res.json({documents:data||[]});
});
app.post('/api/knowledge',verifyFirebase,async(req,res)=>{
 if(!supaReady(res)) return;
 const schema=z.object({title:z.string().trim().min(1).max(180),content:z.string().trim().min(1).max(Number(process.env.MAX_DOCUMENT_CHARS||500000)),source:z.string().max(500).optional(),tags:z.string().max(500).optional()});
 const p=schema.safeParse(req.body); if(!p.success) return res.status(400).json({error:'Título ou conteúdo inválido.'});
 const {data,error}=await supabase.from('knowledge_documents').insert({owner_uid:req.uid,...p.data}).select('id').single();
 if(error) return res.status(500).json({error:'Falha ao salvar documento.'});
 res.status(201).json({ok:true,id:data.id});
});
app.delete('/api/knowledge/:id',verifyFirebase,async(req,res)=>{
 if(!supaReady(res)) return;
 const {error}=await supabase.from('knowledge_documents').delete().eq('id',req.params.id).eq('owner_uid',req.uid);
 if(error) return res.status(500).json({error:'Falha ao excluir documento.'});
 res.json({ok:true});
});

app.get('/api/search',verifyFirebase,async(req,res)=>{
 const q=text(req.query.q,300); if(!q) return res.status(400).json({error:'Informe uma pesquisa.'});
 try { const result=await searchWeb(q); res.json({source:process.env.BRAVE_SEARCH_API_KEY?'Brave Search':'DuckDuckGo Instant Answer',results:result,note:process.env.BRAVE_SEARCH_API_KEY?undefined:'Configure Brave Search para resultados mais completos.'}); }
 catch(e) { res.status(502).json({error:'Pesquisa indisponível: '+e.message}); }
});

app.post('/api/chrome/pair-code',verifyFirebase,async(req,res)=>{
 if(!supaReady(res)) return;
 const code=crypto.randomInt(100000,999999).toString();
 const expires=new Date(Date.now()+Number(process.env.PAIR_CODE_TTL_SECONDS||300)*1000).toISOString();
 const {error}=await supabase.from('chrome_pair_codes').insert({owner_uid:req.uid,code_hash:hash(code),expires_at:expires});
 if(error) return res.status(500).json({error:'Não foi possível gerar o código.'});
 res.json({code,expiresAt:expires});
});
app.post('/api/chrome/pair',async(req,res)=>{
 if(!supaReady(res)) return;
 const code=text(req.body.code,6);
 if(!/^\d{6}$/.test(code)) return res.status(400).json({error:'Código de pareamento inválido.'});
 const {data,error}=await supabase.from('chrome_pair_codes').select('id,owner_uid,expires_at').eq('code_hash',hash(code)).is('used_at',null).maybeSingle();
 if(error||!data||new Date(data.expires_at)<new Date()) return res.status(401).json({error:'Código incorreto, usado ou expirado.'});
 const token=crypto.randomBytes(32).toString('base64url');
 const expiry=new Date(Date.now()+Number(process.env.CHROME_TOKEN_TTL_DAYS||90)*86400000).toISOString();
 const {error:insertError}=await supabase.from('chrome_tokens').insert({owner_uid:data.owner_uid,token_hash:hash(token),expires_at:expiry});
 if(insertError) return res.status(500).json({error:'Não foi possível concluir o pareamento.'});
 await supabase.from('chrome_pair_codes').update({used_at:new Date().toISOString()}).eq('id',data.id);
 res.json({ok:true,token,expiresAt:expiry});
});
app.post('/api/chrome/clip',verifyChrome,async(req,res)=>{
 if(!supaReady(res)) return;
 const schema=z.object({title:z.string().trim().min(1).max(250),url:z.string().url().max(2000),content:z.string().trim().min(1).max(Number(process.env.MAX_CLIP_CHARS||120000))});
 const p=schema.safeParse(req.body); if(!p.success) return res.status(400).json({error:'Página ou conteúdo inválido.'});
 if(!/^https?:$/.test(new URL(p.data.url).protocol)) return res.status(400).json({error:'Somente páginas HTTP/HTTPS.'});
 const {data,error}=await supabase.from('knowledge_documents').insert({owner_uid:req.uid,title:p.data.title,content:p.data.content,source:p.data.url,tags:'chrome-clip'}).select('id').single();
 if(error) return res.status(500).json({error:'Falha ao adicionar à base de conhecimento.'});
 res.status(201).json({ok:true,id:data.id,message:'Página salva na sua base de conhecimento.'});
});
app.post('/api/chrome/revoke',verifyFirebase,async(req,res)=>{
 if(!supaReady(res)) return;
 const {error}=await supabase.from('chrome_tokens').delete().eq('owner_uid',req.uid);
 if(error) return res.status(500).json({error:'Falha ao revogar conexões.'});
 res.json({ok:true});
});

app.listen(PORT,()=>console.log(`Universal AI 2.0 em http://localhost:${PORT}`));
