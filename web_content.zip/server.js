import express from "express";
import cors from "cors";
import crypto from "crypto";
import fs from "fs";
import path from "path";

const app = express();
app.use(cors());
app.use(express.json({limit:"1mb"}));
const PORT = Number(process.env.PORT || 8080);
const NOVA_API_KEY = process.env.NOVA_API_KEY || "";
const AI_BASE_URL = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/,'');
const AI_API_KEY = process.env.AI_API_KEY || "";
const AI_MODEL = process.env.AI_MODEL || "";
// Universal provider registry. Credentials stay on the server, never in the APK.
const PROVIDERS = [
 {id:"openai", name:"OpenAI", type:"openai", baseUrl:process.env.OPENAI_BASE_URL||"https://api.openai.com/v1", key:process.env.OPENAI_API_KEY||"", model:process.env.OPENAI_MODEL||""},
 {id:"anthropic", name:"Anthropic", type:"anthropic", baseUrl:process.env.ANTHROPIC_BASE_URL||"https://api.anthropic.com", key:process.env.ANTHROPIC_API_KEY||"", model:process.env.ANTHROPIC_MODEL||""},
 {id:"google", name:"Google AI", type:"google", baseUrl:process.env.GOOGLE_BASE_URL||"https://generativelanguage.googleapis.com/v1beta", key:process.env.GOOGLE_API_KEY||"", model:process.env.GOOGLE_MODEL||""},
 {id:"custom", name:"Custom OpenAI-compatible", type:"openai", baseUrl:AI_BASE_URL, key:AI_API_KEY, model:AI_MODEL}
];
function providerStatus(){return PROVIDERS.map(p=>({id:p.id,name:p.name,type:p.type,configured:Boolean(p.key&&p.model),model:p.model||null}));}
function providerFor(id){return PROVIDERS.find(p=>p.id===id)||null;}
async function callProvider(p,messages){
 if(!p||!p.key||!p.model) throw new Error("provider_not_configured");
 if(p.type==="anthropic"){
   const r=await fetch(`${p.baseUrl.replace(/\/+$/,'')}/v1/messages`,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":p.key,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:p.model,max_tokens:1200,system:messages.find(x=>x.role==="system")?.content||"",messages:messages.filter(x=>x.role!=="system").map(x=>({role:x.role,content:x.content}))})});
   const d=await r.json(); if(!r.ok) throw new Error("provider_error"); return d?.content?.map(x=>x.text||"").join("\n")||"";
 }
 if(p.type==="google"){
   const prompt=messages.map(x=>`${x.role}: ${x.content}`).join("\n");
   const r=await fetch(`${p.baseUrl.replace(/\/+$/,'')}/models/${encodeURIComponent(p.model)}:generateContent?key=${encodeURIComponent(p.key)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{role:"user",parts:[{text:prompt}]}]})});
   const d=await r.json(); if(!r.ok) throw new Error("provider_error"); return d?.candidates?.[0]?.content?.parts?.map(x=>x.text||"").join("\n")||"";
 }
 const r=await fetch(`${p.baseUrl.replace(/\/+$/,'')}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${p.key}`},body:JSON.stringify({model:p.model,messages,temperature:0.2})});
 const d=await r.json(); if(!r.ok) throw new Error("provider_error"); return d?.choices?.[0]?.message?.content||"";
}
const AUDIT_FILE = process.env.AUDIT_FILE || path.join(process.cwd(),"nova-audit.jsonl");
const tools = [
 {id:"nova-core",name:"Nova Core",risk:"low",enabled:true,approved:true,capabilities:["plan","reason"]},
 {id:"ai-monitor",name:"AI Monitor",risk:"low",enabled:true,approved:true,capabilities:["monitor","classify"]},
 {id:"ai-provider",name:"AI Provider",risk:"medium",enabled:Boolean(AI_API_KEY&&AI_MODEL),approved:Boolean(AI_API_KEY&&AI_MODEL),capabilities:["chat"]},
 {id:"web-research",name:"External Research",risk:"medium",enabled:false,approved:false,capabilities:["network","research"]},
 {id:"messaging",name:"External Messaging",risk:"high",enabled:false,approved:false,capabilities:["network","message"]},
 {id:"actions",name:"External Actions",risk:"high",enabled:false,approved:false,capabilities:["network","execute"]}
];
const blocked = [/اختراق|تهكير|سرقة|احتيال|تزوير|إيذاء|قتل|تفجير|سلاح|برمجية\s*خبيثة|malware|ransomware|phishing/i];
function authorized(req){ if(!NOVA_API_KEY) return true; return req.headers.authorization===`Bearer ${NOVA_API_KEY}`; }
function audit(event,data={}){const row={time:new Date().toISOString(),id:crypto.randomUUID(),event,...data};try{fs.appendFileSync(AUDIT_FILE,JSON.stringify(row)+"\n")}catch{};console.log(JSON.stringify(row));}
function riskOf(text=""){ if(blocked.some(r=>r.test(text))) return "high"; if(/أرسل|بريد|واتساب|احجز|اشتر|غيّر|احذف|نفذ|شغّل|افتح|رسالة|شراء|حجز/i.test(text)) return "medium"; return "low"; }
function intentOf(text=""){if(/مهمة|مهام|نظم|تنظيم|خطة|يومي/i.test(text))return"tasks";if(/خبر|أخبار|تطور|جديد|نموذج|أداة|ai|ذكاء اصطناعي/i.test(text))return"monitor";if(/ابحث|بحث|معلومة|قارن|تحقق/i.test(text))return"research";if(/أرسل|رسالة|بريد|واتساب|تواصل/i.test(text))return"message";if(/نفذ|شغل|افتح|احجز|اشتر|غيّر|غير|احذف/i.test(text))return"action";return"chat";}
function decide(message){const risk=riskOf(message), intent=intentOf(message);let tool="nova-core";if(intent==="monitor")tool="ai-monitor";if(intent==="research")tool="web-research";if(intent==="message")tool="messaging";if(intent==="action")tool="actions";const t=tools.find(x=>x.id===tool);const blockedByPolicy=risk==="high";const needsApproval=!blockedByPolicy && (risk!=="low" || tool!=="nova-core");const allowed=Boolean(t?.enabled&&t?.approved)&&!blockedByPolicy;return {intent,risk,tool,toolName:t?.name||tool,allowed,needsApproval,blockedByPolicy,reason:blockedByPolicy?"policy_high_risk":!t?.approved?"tool_not_approved":!t?.enabled?"tool_disabled":needsApproval?"human_approval_required":"safe_local_operation"};}
app.get("/health",(req,res)=>res.json({ok:true,service:"Nova Gateway",version:"2.0.0",mode:"manager"}));
app.use("/api",(req,res,next)=>authorized(req)?next():res.status(401).json({error:"غير مصرح"}));
app.get("/api/config",(req,res)=>res.json({name:"Nova Gateway",version:"3.0.0",mode:"universal-ai-manager",policy:"guardian-manager-v3",humanApproval:true,tools,providers:providerStatus()}));
app.get("/api/providers",(req,res)=>res.json({ok:true,providers:providerStatus()}));
app.get("/api/tools",(req,res)=>res.json({tools}));
app.post("/api/decide",(req,res)=>{const message=String(req.body?.message||"").trim();if(!message)return res.status(400).json({error:"الرسالة فارغة"});const decision=decide(message);audit("decision",{message,risk:decision.risk,intent:decision.intent,tool:decision.tool,status:decision.blockedByPolicy?"blocked":decision.needsApproval?"approval_required":decision.allowed?"allowed":"not_allowed"});res.json({ok:true,decision});});
app.post("/api/chat",async(req,res)=>{const message=String(req.body?.message||"").trim();if(!message)return res.status(400).json({error:"الرسالة فارغة"});const d=decide(message);if(d.blockedByPolicy)return res.status(403).json({ok:false,blocked:true,risk:d.risk,decision:d,message:"🛡️ Nova منعت الطلب وفق سياسة السلامة. أستطيع المساعدة في بديل آمن أو وقائي."});if(d.needsApproval)return res.json({ok:true,mode:"manager",approvalRequired:true,decision:d,message:`👤 Nova حللت الطلب. الأداة المقترحة: ${d.toolName}. مستوى المخاطر: ${d.risk}. أحتاج موافقتك قبل أي تنفيذ خارجي.`});
const requestedProvider=String(req.body?.provider||"").trim();
const preferred=providerFor(requestedProvider)||providerFor(process.env.NOVA_DEFAULT_PROVIDER||"")||providerFor("custom");
const available=PROVIDERS.filter(p=>p.key&&p.model);
if(!available.length)return res.json({ok:true,mode:"local-manager",decision:d,message:"🧠 Nova حللت الطلب محليًا. لا يوجد مزود AI مهيأ بعد. أضف مفاتيح المزود على الخادم فقط."});
const ordered=[preferred,...available.filter(p=>p.id!==preferred?.id)];
const messages=[{role:"system",content:"أنت Nova، المدير الأعلى لمنظومة AI. حلل الطلب، اختر أفضل أسلوب، لا تنفذ إجراءً خارجياً حساساً دون موافقة بشرية، ولا تكشف الأسرار أو مفاتيح الاتصال."},{role:"user",content:message}];
for(const p of ordered){try{const answer=await callProvider(p,messages); if(answer)return res.json({ok:true,mode:"universal-manager",provider:p.id,providerName:p.name,decision:d,answer});}catch(e){audit("provider_failure",{provider:p.id,message:e.message});}}
return res.status(502).json({error:"تعذر الحصول على رد من مزودي AI المهيئين",decision:d});
});
app.post("/api/approve",(req,res)=>{const id=String(req.body?.requestId||crypto.randomUUID());const approved=req.body?.approved===true;const message=String(req.body?.message||"");audit("approval",{requestId:id,approved,message});res.json({ok:true,requestId:id,approved,status:approved?"approved":"rejected"});});
app.get("/api/news",(req,res)=>res.json({ok:true,sources:[{name:"OpenAI",url:"https://openai.com/news/"},{name:"Google DeepMind",url:"https://deepmind.google/discover/blog/"},{name:"Anthropic",url:"https://www.anthropic.com/news"},{name:"Meta AI",url:"https://ai.meta.com/blog/"}],items:[],note:"مصادر رسمية مسجلة. التجميع الحي يحتاج مهمة مجدولة/موصلات مصادر مفعلة."}));
app.post("/api/action",(req,res)=>{const action=String(req.body?.action||"");const d=decide(action);audit("action_attempt",{action,risk:d.risk,tool:d.tool});if(d.blockedByPolicy)return res.status(403).json({ok:false,blocked:true,decision:d});return res.status(202).json({ok:true,queued:true,approvalRequired:true,decision:d,message:"تمت إضافة العملية إلى مسار الحوكمة؛ لا يوجد تنفيذ خارجي تلقائي في هذه النسخة."});});
app.listen(PORT,()=>console.log(`Nova Gateway v2 listening on ${PORT}`));
