'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { AccessToken, RoomServiceClient } = require('livekit-server-sdk');

const { LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET, JWT_SECRET } = process.env;
const PROD = process.env.NODE_ENV === 'production';
const MAX_PLAYERS = 8;

if (!LIVEKIT_URL || !LIVEKIT_API_KEY || !LIVEKIT_API_SECRET || !JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('Missing env vars. Need LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET and JWT_SECRET (32+ chars).');
  process.exit(1);
}
const svc = new RoomServiceClient(LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET);

/* ---------- tiny JSON user store (swap for a real DB in production) ---------- */
const DB = path.join(__dirname, 'data', 'users.json');
fs.mkdirSync(path.dirname(DB), { recursive: true });
let users = {};
try { users = JSON.parse(fs.readFileSync(DB, 'utf8')); } catch (e) { /* first run */ }
const save = () => { fs.writeFileSync(DB + '.tmp', JSON.stringify(users)); fs.renameSync(DB + '.tmp', DB); };

const EMOJI = ['🦊','🐼','🐯','🦁','🐸','🐵','🦄','🐲','🤖','👾','🎮','🚀'];
const hashPw = (pw, salt) => crypto.scryptSync(pw, Buffer.from(salt, 'hex'), 64);
const pub = (u) => ({ id: u.id, username: u.username, avatar: u.avatar });
const sign = (u) => jwt.sign({ sub: u.id }, JWT_SECRET, { algorithm: 'HS256', expiresIn: '7d' });
const byId = (id) => Object.values(users).find((u) => u.id === id);

/* ---------- app ---------- */
const app = express();
app.disable('x-powered-by');
if (PROD) {
  app.set('trust proxy', 1);
  app.use((req, res, next) => (req.secure ? next() : res.redirect(301, 'https://' + req.headers.host + req.originalUrl)));
}
app.use(helmet({
  hsts: { maxAge: 31536000, includeSubDomains: true },
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'"],
    imgSrc: ["'self'", 'data:', 'blob:'],
    mediaSrc: ["'self'", 'blob:', 'mediastream:'],
    connectSrc: ["'self'", 'wss:', 'https:'],   // wss: = LiveKit signalling
    workerSrc: ["'self'", 'blob:'],
    upgradeInsecureRequests: PROD ? [] : null
  } }
}));
app.use(express.json({ limit: '2kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/vendor/livekit-client.umd.js', (req, res) =>
  res.sendFile(path.join(__dirname, 'node_modules/livekit-client/dist/livekit-client.umd.js')));
app.get('/healthz', (req, res) => res.send('ok'));

const lim = (windowMs, max) => rateLimit({ windowMs, max, standardHeaders: true, legacyHeaders: false, message: { error: 'rate_limited' } });
app.use('/api', lim(60_000, 120));
const authLimit = lim(60_000, 10);
const joinLimit = lim(60_000, 15);   // slows down room-code guessing

const h = (fn) => (req, res) => fn(req, res).catch((e) => { console.error(e); res.status(500).json({ error: 'generic' }); });

function auth(req, res, next) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  try {
    const p = jwt.verify(m && m[1], JWT_SECRET, { algorithms: ['HS256'] });
    const u = byId(p.sub);
    if (!u) throw new Error('no user');
    req.user = u;
    next();
  } catch (e) { res.status(401).json({ error: 'unauthorized' }); }
}

/* ---------- auth & profile ---------- */
const validUser = (s) => typeof s === 'string' && /^[A-Za-z0-9_]{3,16}$/.test(s);
const validPw = (s) => typeof s === 'string' && s.length >= 8 && s.length <= 72;

app.post('/api/register', authLimit, h(async (req, res) => {
  const { username, password } = req.body || {};
  if (!validUser(username) || !validPw(password)) return res.status(400).json({ error: 'invalid_input' });
  const key = username.toLowerCase();
  if (users[key]) return res.status(409).json({ error: 'username_taken' });
  const salt = crypto.randomBytes(16).toString('hex');
  const u = {
    id: crypto.randomUUID(), username, salt, hash: hashPw(password, salt).toString('hex'),
    avatar: { emoji: EMOJI[crypto.randomInt(EMOJI.length)], color: '#7c3aed' }
  };
  users[key] = u; save();
  res.json({ token: sign(u), user: pub(u) });
}));

app.post('/api/login', authLimit, h(async (req, res) => {
  const { username, password } = req.body || {};
  const u = validUser(username) && typeof password === 'string' ? users[username.toLowerCase()] : null;
  const ok = u && crypto.timingSafeEqual(hashPw(password, u.salt), Buffer.from(u.hash, 'hex'));
  if (!ok) return res.status(401).json({ error: 'bad_credentials' });
  res.json({ token: sign(u), user: pub(u) });
}));

app.get('/api/me', auth, (req, res) => res.json({ user: pub(req.user) }));

app.put('/api/me', auth, h(async (req, res) => {
  const { emoji, color } = req.body || {};
  if (!EMOJI.includes(emoji) || !/^#[0-9a-fA-F]{6}$/.test(color || '')) return res.status(400).json({ error: 'invalid_input' });
  req.user.avatar = { emoji, color }; save();
  res.json({ user: pub(req.user) });
}));

/* ---------- rooms & LiveKit tokens ---------- */
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newCode = () => Array.from({ length: 6 }, () => ALPHA[crypto.randomInt(ALPHA.length)]).join('');
const findRoom = async (code) => (await svc.listRooms([code]))[0];

// The token is scoped to ONE room, tied to the authenticated user, and short-lived.
async function liveKitToken(user, code) {
  const at = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
    identity: user.id, name: user.username, metadata: JSON.stringify(user.avatar), ttl: '2h'
  });
  at.addGrant({ roomJoin: true, room: code, canPublish: true, canSubscribe: true, canPublishData: false });
  return at.toJwt();
}

app.post('/api/rooms', auth, joinLimit, h(async (req, res) => {
  let code;
  for (let i = 0; i < 5; i++) { const c = newCode(); if (!(await findRoom(c))) { code = c; break; } }
  if (!code) return res.status(503).json({ error: 'generic' });
  await svc.createRoom({ name: code, maxParticipants: MAX_PLAYERS, emptyTimeout: 300, metadata: JSON.stringify({ host: req.user.id }) });
  res.json({ code, url: LIVEKIT_URL, token: await liveKitToken(req.user, code) });
}));

app.post('/api/rooms/join', auth, joinLimit, h(async (req, res) => {
  const code = String((req.body || {}).code || '').trim().toUpperCase();
  if (!/^[A-Z2-9]{6}$/.test(code)) return res.status(400).json({ error: 'invalid_input' });
  const room = await findRoom(code);                       // room must exist (created by our server)
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  if (room.numParticipants >= MAX_PLAYERS) return res.status(409).json({ error: 'room_full' });
  res.json({ code, url: LIVEKIT_URL, token: await liveKitToken(req.user, code) });
}));

app.listen(process.env.PORT || 3000, () => console.log('PlayMitra running on port ' + (process.env.PORT || 3000)));
