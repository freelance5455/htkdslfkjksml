'use strict';
// Kartino offline server — pure Node.js + JSON file storage (no npm packages needed)
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
const DATA = path.join(ROOT, 'data');
const RECEIPTS = path.join(DATA, 'receipts');
const DBFILE = path.join(DATA, 'db.json');
const PORT = Number(process.env.PORT) || 8080;
const ADMIN_USER = (process.env.ADMIN_USERNAME || 'mahdi689').toLowerCase();
const ADMIN_PASS = process.env.ADMIN_PASSWORD || 'kartinoasmin';

fs.mkdirSync(RECEIPTS, { recursive: true });

const fresh = () => ({
  users: {},
  payments: {},
  friendRequests: {},
  rooms: {},
  games: [],
  audit: [],
  blog: { updatedAt: Date.now(), content: null },
});

let db;
try {
  db = JSON.parse(fs.readFileSync(DBFILE, 'utf8'));
} catch {
  db = fresh();
}
for (const k of Object.keys(fresh())) {
  if (db[k] === undefined) db[k] = fresh()[k];
}

function save() {
  const tmp = DBFILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DBFILE);
}

function audit(action, username, actor, details = {}) {
  db.audit = db.audit || [];
  db.audit.push({ id: id(), action, username, actor, details, at: Date.now() });
  if (db.audit.length > 1000) db.audit = db.audit.slice(-1000);
}

const sessions = new Map();
const attempts = new Map();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.webmanifest': 'application/manifest+json',
  '.json': 'application/json',
  '.zip': 'application/zip',
  '.txt': 'text/plain; charset=utf-8',
};

const send = (res, status, obj, headers = {}) => {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(JSON.stringify(obj));
};

const safeUser = (u) => ({
  username: u.username,
  uid: u.uid,
  role: u.role || 'user',
  subscriptionUntil: u.subscriptionUntil || 0,
  createdAt: u.createdAt,
  stats: u.stats || { games: 0, wins: 0, losses: 0, onlineGames: 0, friendsGames: 0, botGames: 0 },
  lastLogin: u.loginHistory?.[u.loginHistory.length - 1] || null,
  loginCount: u.loginHistory?.length || 0,
});

const hash = (p, s) => crypto.scryptSync(p, s, 64).toString('hex');
const uid = () => String(10000 + crypto.randomInt(90000));
const id = () => crypto.randomBytes(16).toString('hex');

function tokenUser(req) {
  const c = (req.headers.cookie || '').split(';').map((x) => x.trim()).find((x) => x.startsWith('kt_session='));
  if (!c) return null;
  const t = decodeURIComponent(c.slice(11));
  const s = sessions.get(t);
  if (!s || s.exp < Date.now()) {
    sessions.delete(t);
    return null;
  }
  return db.users[s.username] || null;
}

function requireUser(req, res) {
  const u = tokenUser(req);
  if (!u) {
    send(res, 401, { error: 'برای ادامه وارد حساب شو' });
    return null;
  }
  return u;
}

function requireAdmin(req, res) {
  const u = requireUser(req, res);
  if (!u) return null;
  if (u.role !== 'admin') {
    send(res, 403, { error: 'دسترسی مدیر لازم است' });
    return null;
  }
  return u;
}

function body(req, limit = 5 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let b = '';
    req.on('data', (c) => {
      b += c;
      if (b.length > limit) {
        reject(Object.assign(new Error('حجم درخواست زیاد است'), { status: 413 }));
        req.destroy();
      }
    });
    req.on('end', () => {
      try {
        resolve(b ? JSON.parse(b) : {});
      } catch {
        reject(Object.assign(new Error('درخواست نامعتبر است'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

function cookie(res, t) {
  res.setHeader(
    'Set-Cookie',
    `kt_session=${encodeURIComponent(t)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800${
      process.env.NODE_ENV === 'production' ? '; Secure' : ''
    }`
  );
}

function ensureAdmin() {
  if (!ADMIN_PASS) return;
  const old = db.users[ADMIN_USER];
  if (!old) {
    const salt = crypto.randomBytes(16).toString('hex');
    db.users[ADMIN_USER] = {
      username: ADMIN_USER,
      salt,
      hash: hash(ADMIN_PASS, salt),
      uid: '11111',
      role: 'admin',
      createdAt: Date.now(),
      subscriptionUntil: 0,
      stats: { games: 0, wins: 0, losses: 0, onlineGames: 0, friendsGames: 0, botGames: 0 },
      loginHistory: [],
    };
    save();
  } else {
    old.role = 'admin';
    const salt = crypto.randomBytes(16).toString('hex');
    old.salt = salt;
    old.hash = hash(ADMIN_PASS, salt);
    save();
  }
}

ensureAdmin();

async function api(req, res, url) {
  const method = req.method;
  const p = url.pathname;

  if (p === '/api/health' && method === 'GET') {
    return send(res, 200, { ok: true, service: 'kartino', storage: 'json', time: Date.now() });
  }

  if (p === '/api/register' && method === 'POST') {
    const b = await body(req);
    const u = String(b.username || '').trim().toLowerCase();
    const pw = String(b.password || '');
    if (!/^[a-z0-9_]{3,16}$/.test(u)) {
      return send(res, 400, { error: 'نام کاربری باید ۳ تا ۱۶ حرف انگلیسی، عدد یا _ باشد' });
    }
    if (pw.length < 10) {
      return send(res, 400, { error: 'رمز عبور باید حداقل ۱۰ کاراکتر باشد' });
    }
    if (u === ADMIN_USER || db.users[u]) {
      return send(res, 409, { error: 'این نام کاربری قبلاً گرفته شده است' });
    }
    const salt = crypto.randomBytes(16).toString('hex');
    db.users[u] = {
      username: u,
      salt,
      hash: hash(pw, salt),
      uid: uid(),
      role: 'user',
      createdAt: Date.now(),
      subscriptionUntil: 0,
      stats: { games: 0, wins: 0, losses: 0, onlineGames: 0, friendsGames: 0, botGames: 0 },
      loginHistory: [Date.now()],
    };
    audit('registered', u, u);
    save();
    const t = id();
    sessions.set(t, { username: u, exp: Date.now() + 7 * 864e5 });
    cookie(res, t);
    return send(res, 201, { user: safeUser(db.users[u]) });
  }

  if (p === '/api/login' && method === 'POST') {
    const b = await body(req);
    const u = String(b.username || '').trim().toLowerCase();
    const pw = String(b.password || '');
    const now = Date.now();
    const a = attempts.get(u) || { n: 0, until: 0 };
    if (a.until > now) {
      return send(res, 429, { error: 'تلاش‌های زیاد؛ کمی بعد دوباره امتحان کن' });
    }
    const user = db.users[u];
    let ok = false;
    if (user) {
      try {
        ok = crypto.timingSafeEqual(
          Buffer.from(hash(pw, user.salt), 'hex'),
          Buffer.from(user.hash, 'hex')
        );
      } catch {
        ok = false;
      }
    }
    if (!ok) {
      a.n++;
      if (a.n >= 6) {
        a.n = 0;
        a.until = now + 60000;
      }
      attempts.set(u, a);
      return send(res, 401, { error: 'نام کاربری یا رمز عبور اشتباه است' });
    }
    attempts.delete(u);
    user.loginHistory = user.loginHistory || [];
    user.loginHistory.push(now);
    if (user.loginHistory.length > 200) user.loginHistory = user.loginHistory.slice(-200);
    audit('login', u, u);
    save();
    const t = id();
    sessions.set(t, { username: u, exp: now + 7 * 864e5 });
    cookie(res, t);
    return send(res, 200, { user: safeUser(user) });
  }

  if (p === '/api/logout' && method === 'POST') {
    const c = (req.headers.cookie || '').split(';').map((x) => x.trim()).find((x) => x.startsWith('kt_session='));
    if (c) sessions.delete(decodeURIComponent(c.slice(11)));
    return send(res, 200, { ok: true }, {
      'Set-Cookie': 'kt_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0',
    });
  }

  if (p === '/api/me' && method === 'GET') {
    const me = requireUser(req, res);
    if (!me) return;
    return send(res, 200, { user: safeUser(me) });
  }

  if (p === '/api/users/search' && method === 'GET') {
    const me = requireUser(req, res);
    if (!me) return;
    const q = String(url.searchParams.get('q') || '').trim().toLowerCase();
    if (q.length < 2) return send(res, 200, { users: [] });
    const users = Object.values(db.users)
      .filter((x) => x.username !== me.username && x.username.includes(q))
      .slice(0, 20)
      .map((x) => ({ username: x.username, uid: x.uid, role: x.role }));
    return send(res, 200, { users });
  }

  if (p === '/api/friends/request' && method === 'POST') {
    const me = requireUser(req, res);
    if (!me) return;
    const b = await body(req);
    const to = String(b.to || '').trim().toLowerCase();
    const target = db.users[to];
    if (!target || to === me.username) return send(res, 404, { error: 'کاربر پیدا نشد' });
    const exists = Object.values(db.friendRequests).find(
      (x) => x.from === me.username && x.to === to && x.status === 'pending'
    );
    if (exists) return send(res, 200, { request: exists });
    const r = { id: id(), from: me.username, to, status: 'pending', createdAt: Date.now() };
    db.friendRequests[r.id] = r;
    save();
    return send(res, 201, { request: r });
  }

  if (p === '/api/friends/requests' && method === 'GET') {
    const me = requireUser(req, res);
    if (!me) return;
    const all = Object.values(db.friendRequests);
    return send(res, 200, {
      incoming: all.filter((x) => x.to === me.username && x.status === 'pending'),
      outgoing: all.filter((x) => x.from === me.username && x.status === 'pending'),
      accepted: all
        .filter((x) => x.status === 'accepted' && (x.from === me.username || x.to === me.username))
        .map((x) => (x.from === me.username ? x.to : x.from)),
    });
  }

  let m = p.match(/^\/api\/friends\/requests\/([a-f0-9]+)\/accept$/);
  if (m && method === 'POST') {
    const me = requireUser(req, res);
    if (!me) return;
    const r = db.friendRequests[m[1]];
    if (!r || r.to !== me.username || r.status !== 'pending') {
      return send(res, 404, { error: 'درخواست معتبر نیست' });
    }
    r.status = 'accepted';
    r.acceptedAt = Date.now();
    save();
    return send(res, 200, { request: r });
  }

  if (p === '/api/rooms' && method === 'POST') {
    const me = requireUser(req, res);
    if (!me) return;
    const b = await body(req);
    const friends = Array.isArray(b.friends)
      ? b.friends.map((x) => String(x).toLowerCase()).slice(0, 3)
      : [];
    for (const f of friends) {
      const ok = Object.values(db.friendRequests).some(
        (r) => r.status === 'accepted' &&
          ((r.from === me.username && r.to === f) || (r.to === me.username && r.from === f))
      );
      if (!ok) return send(res, 403, { error: `ارتباط دوستی با ${f} تأیید نشده است` });
    }
    const room = {
      id: id(),
      host: me.username,
      players: [
        { username: me.username, seat: 0 },
        ...friends.map((username, i) => ({ username, seat: i + 1 })),
      ],
      bots: Math.max(0, 3 - friends.length),
      status: 'waiting',
      skin: b.skin || {},
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    db.rooms[room.id] = room;
    save();
    return send(res, 201, { room });
  }

  m = p.match(/^\/api\/rooms\/([a-f0-9]+)$/);
  if (m && method === 'GET') {
    const me = requireUser(req, res);
    if (!me) return;
    const room = db.rooms[m[1]];
    if (!room || !room.players.some((x) => x.username === me.username)) {
      return send(res, 404, { error: 'میز پیدا نشد' });
    }
    return send(res, 200, { room });
  }

  m = p.match(/^\/api\/rooms\/([a-f0-9]+)\/leave$/);
  if (m && method === 'POST') {
    const me = requireUser(req, res);
    if (!me) return;
    const room = db.rooms[m[1]];
    if (!room) return send(res, 404, { error: 'میز پیدا نشد' });
    room.players = room.players.filter((x) => x.username !== me.username);
    room.updatedAt = Date.now();
    if (!room.players.length) delete db.rooms[m[1]];
    else db.rooms[m[1]] = room;
    save();
    return send(res, 200, { ok: true });
  }

  if (p === '/api/payments' && method === 'POST') {
    const me = requireUser(req, res);
    if (!me) return;
    const b = await body(req, 6 * 1024 * 1024);
    const plan = String(b.plan || '');
    if (!['m1', 'm2', 'y1'].includes(plan)) {
      return send(res, 400, { error: 'پلن نامعتبر است' });
    }
    const dataUrl = String(b.receipt || '');
    const mm = dataUrl.match(/^data:image\/(png|jpe?g|webp);base64,(.+)$/i);
    if (!mm) return send(res, 400, { error: 'تصویر رسید معتبر نیست' });
    const buf = Buffer.from(mm[2], 'base64');
    if (buf.length > 5 * 1024 * 1024) {
      return send(res, 413, { error: 'حجم تصویر زیاد است' });
    }
    const rid = id();
    const ext = mm[1].toLowerCase() === 'jpeg' ? 'jpg' : mm[1].toLowerCase();
    const file = path.join(RECEIPTS, rid + '.' + ext);
    fs.writeFileSync(file, buf, { mode: 0o600 });
    db.payments[rid] = {
      id: rid,
      username: me.username,
      plan,
      receipt: path.basename(file),
      status: 'pending',
      createdAt: Date.now(),
    };
    save();
    return send(res, 201, {
      payment: { id: rid, status: 'pending' },
      message: 'رسید ثبت شد؛ تا ۱۲ ساعت آینده بررسی می‌شود.',
    });
  }

  if (p === '/api/blog' && method === 'GET') {
    return send(res, 200, { post: db.blog.content || null });
  }

  if (p === '/api/admin/blog' && method === 'PUT') {
    if (!requireAdmin(req, res)) return;
    const b = await body(req);
    const title = String(b.title || '').trim();
    const content = String(b.content || '').trim();
    if (title.length < 3 || title.length > 120 || content.length < 10 || content.length > 12000) {
      return send(res, 400, { error: 'عنوان یا متن بلاگ معتبر نیست' });
    }
    db.blog.content = {
      title,
      content,
      updatedAt: Date.now(),
      updatedBy: ADMIN_USER,
    };
    save();
    return send(res, 200, { post: db.blog.content });
  }

  if (p === '/api/admin/payments' && method === 'GET') {
    if (!requireAdmin(req, res)) return;
    return send(res, 200, {
      payments: Object.values(db.payments)
        .sort((a, b) => b.createdAt - a.createdAt)
        .map((x) => ({ ...x, receiptUrl: '/api/admin/payments/' + x.id + '/receipt' })),
    });
  }

  m = p.match(/^\/api\/admin\/payments\/([a-f0-9]+)\/receipt$/);
  if (m && method === 'GET') {
    if (!requireAdmin(req, res)) return;
    const x = db.payments[m[1]];
    if (!x) return send(res, 404, { error: 'رسید پیدا نشد' });
    const f = path.join(RECEIPTS, x.receipt);
    if (!fs.existsSync(f)) return send(res, 404, { error: 'فایل رسید موجود نیست' });
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(f)] || 'application/octet-stream',
      'Cache-Control': 'private, no-store',
    });
    return fs.createReadStream(f).pipe(res);
  }

  m = p.match(/^\/api\/admin\/payments\/([a-f0-9]+)$/);
  if (m && method === 'PATCH') {
    const admin = requireAdmin(req, res);
    if (!admin) return;
    const b = await body(req);
    const x = db.payments[m[1]];
    if (!x) return send(res, 404, { error: 'تراکنش پیدا نشد' });
    if (x.status !== 'pending') {
      return send(res, 409, { error: 'این درخواست قبلاً بررسی شده' });
    }
    x.status = b.approve ? 'approved' : 'rejected';
    x.reviewedAt = Date.now();
    x.reviewedBy = admin.username;
    audit(b.approve ? 'payment_approved' : 'payment_rejected', x.username, admin.username, {
      paymentId: x.id,
      plan: x.plan,
    });
    if (b.approve) {
      const days = { m1: 30, m2: 90, y1: 365 }[x.plan];
      if (db.users[x.username]) {
        db.users[x.username].subscriptionUntil =
          Math.max(Date.now(), db.users[x.username].subscriptionUntil || 0) + days * 864e5;
      }
    }
    save();
    return send(res, 200, { payment: x });
  }

  m = p.match(/^\/api\/admin\/users\/([a-z0-9_]{3,16})\/role$/);
  if (m && method === 'PATCH') {
    const admin = requireAdmin(req, res);
    if (!admin) return;
    const target = db.users[m[1]];
    if (!target) return send(res, 404, { error: 'کاربر پیدا نشد' });
    if (target.username === ADMIN_USER) {
      return send(res, 403, { error: 'نقش مدیر اصلی قابل تغییر نیست' });
    }
    const b = await body(req);
    target.role = b.role === 'admin' ? 'admin' : 'user';
    audit('role_changed', target.username, admin.username, { role: target.role });
    save();
    return send(res, 200, { user: safeUser(target) });
  }

  if (p === '/api/admin/dashboard' && method === 'GET') {
    if (!requireAdmin(req, res)) return;
    const us = Object.values(db.users);
    return send(res, 200, {
      users: us.length,
      games: db.games.length,
      pendingPayments: Object.values(db.payments).filter((x) => x.status === 'pending').length,
      audit: (db.audit || []).slice(-200).reverse(),
      payments: Object.values(db.payments)
        .sort((a, b) => b.createdAt - a.createdAt)
        .slice(0, 50),
      recentUsers: us
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
        .slice(0, 30)
        .map(safeUser),
    });
  }

  if (p === '/api/me/username' && method === 'PATCH') {
    const me = requireUser(req, res);
    if (!me) return;
    const b = await body(req);
    const nu = String(b.username || '').trim().toLowerCase();
    if (!/^[a-z0-9_]{3,16}$/.test(nu)) {
      return send(res, 400, { error: 'نام کاربری معتبر نیست' });
    }
    if (nu === ADMIN_USER || db.users[nu]) {
      return send(res, 409, { error: 'این نام کاربری قبلاً گرفته شده است' });
    }
    const old = me.username;
    delete db.users[old];
    me.username = nu;
    db.users[nu] = me;
    for (const [t, v] of sessions) {
      if (v.username === old) v.username = nu;
    }
    audit('username_changed', nu, old, { previousUsername: old });
    save();
    return send(res, 200, { user: safeUser(me) });
  }

  if (p === '/api/usage' && method === 'GET') {
    const me = requireUser(req, res);
    if (!me) return;
    const records = db.games.filter((x) => x.username === me.username);
    return send(res, 200, {
      role: me.role,
      subscriptionUntil: me.subscriptionUntil || 0,
      bot: records.filter((x) => x.mode === 'bot').length,
      friends: records.filter((x) => x.mode === 'friends').length,
      online: records.filter((x) => x.mode === 'online').length,
    });
  }

  if (p === '/api/stats/game' && method === 'POST') {
    const me = requireUser(req, res);
    if (!me) return;
    const b = await body(req);
    const mode = ['bot', 'online', 'friends'].includes(b.mode) ? b.mode : 'bot';
    const won = !!b.won;
    me.stats = me.stats || { games: 0, wins: 0, losses: 0, onlineGames: 0, friendsGames: 0, botGames: 0 };
    me.stats.games++;
    me.stats[won ? 'wins' : 'losses']++;
    me.stats[mode + 'Games']++;
    db.games.push({
      id: id(),
      username: me.username,
      mode,
      won,
      startedAt: Number(b.startedAt) || Date.now(),
      endedAt: Date.now(),
    });
    save();
    return send(res, 200, { stats: me.stats });
  }

  return send(res, 404, { error: 'مسیر API پیدا نشد' });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);

    let p = decodeURIComponent(url.pathname);
    if (p === '/') p = '/index.html';
    const f = path.resolve(ROOT, '.' + p);
    if (!f.startsWith(ROOT + path.sep) && f !== ROOT) {
      return send(res, 403, { error: 'Forbidden' });
    }
    if (f.startsWith(DATA + path.sep) || /\.(py|bat|sh)$|server\.js$/.test(f)) {
      return send(res, 403, { error: 'Forbidden' });
    }
    fs.readFile(f, (e, b) => {
      if (e) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('Not found');
      }
      const ext = path.extname(f);
      const h = {
        'Content-Type': MIME[ext] || 'application/octet-stream',
        'Cache-Control':
          ext === '.html' || f.endsWith('sw.js') ? 'no-cache' : 'public, max-age=86400',
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'strict-origin-when-cross-origin',
        'X-Frame-Options': 'DENY',
      };
      if (ext === '.zip') {
        h['Content-Disposition'] = 'attachment; filename="Kartino-App.zip"';
      }
      res.writeHead(200, h);
      res.end(b);
    });
  } catch (e) {
    send(res, e.status || 500, { error: e.message || 'خطای داخلی سرور' });
  }
});

server.listen(PORT, () => {
  console.log('');
  console.log('  Kartino server is running');
  console.log('  Address : http://localhost:' + PORT);
  console.log('  Admin   : mahdi689');
  console.log('  Storage : data/db.json  (inside project)');
  console.log('');
});
