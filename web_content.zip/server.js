const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" },
  pingInterval: 25000,
  pingTimeout: 20000
});
const PORT = process.env.PORT || 3000;
const rooms = new Map();

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, name: "Turbo Road Racing Server" }));
app.get("/", (_req, res) => res.sendFile(require("path").join(__dirname, "public", "index.html")));

function roomPlayers(room) {
  const ids = rooms.get(room) || new Set();
  return [...ids].map(id => {
    const s = io.sockets.sockets.get(id);
    return s && s.data.racer ? { id, ...s.data.racer } : null;
  }).filter(Boolean);
}
io.on("connection", socket => {
  socket.on("joinRoom", ({ room, name } = {}) => {
    room = String(room || "TURBO1").toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 12) || "TURBO1";
    name = String(name || "Racer").replace(/[<>]/g, "").slice(0, 16) || "Racer";
    if (socket.data.room) socket.leave(socket.data.room);
    socket.data.room = room;
    socket.data.racer = { name, x: 0.5, y: 0.72, speed: 0, dist: 0, color: "#ff3f83" };
    if (!rooms.has(room)) rooms.set(room, new Set());
    rooms.get(room).add(socket.id);
    socket.join(room);
    socket.emit("players", roomPlayers(room));
    socket.to(room).emit("playerJoined", { id: socket.id, name });
    io.to(room).emit("players", roomPlayers(room));
  });
  socket.on("state", state => {
    const room = socket.data.room;
    if (!room || !socket.data.racer || !state || typeof state !== "object") return;
    const clamp = (n, min, max) => Math.max(min, Math.min(max, Number(n) || 0));
    socket.data.racer = {
      name: String(state.name || socket.data.racer.name).replace(/[<>]/g, "").slice(0, 16),
      x: clamp(state.x, 0, 1), y: clamp(state.y, 0, 1),
      speed: clamp(state.speed, 0, 600), dist: clamp(state.dist, 0, 1e7),
      color: /^#[0-9a-f]{6}$/i.test(state.color) ? state.color : "#ff3f83"
    };
    socket.to(room).emit("players", roomPlayers(room));
  });
  socket.on("disconnect", () => {
    const room = socket.data.room;
    if (room && rooms.has(room)) {
      rooms.get(room).delete(socket.id);
      if (!rooms.get(room).size) rooms.delete(room);
      io.to(room).emit("players", roomPlayers(room));
    }
  });
});
server.listen(PORT, "0.0.0.0", () => console.log(`Turbo Road server listening on ${PORT}`));
