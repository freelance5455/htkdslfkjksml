require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const User = require('./models/User');
const Video = require('./models/Video');

const app = express();
const PORT = Number(process.env.PORT) || 5000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('Set JWT_SECRET to a random value of at least 32 characters in .env');
  process.exit(1);
}

app.use(cors({
  origin: process.env.CLIENT_ORIGIN || 'http://localhost:5000'
}));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/', rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 100,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Çok fazla istek gönderdiniz. Lütfen daha sonra tekrar deneyin.' }
}));

const badWords = ['küfür1', 'argo2'];
function filterComment(req, res, next) {
  if (typeof req.body.text !== 'string') return res.status(400).json({ error: 'Yorum metni gerekli.' });
  let text = req.body.text.trim();
  if (!text || text.length > 1000) return res.status(400).json({ error: 'Yorum 1-1000 karakter olmalı.' });
  if (/https?:\\/\\//i.test(text)) return res.status(400).json({ error: 'Yorumlarda harici link paylaşımı yasaktır.' });
  for (const word of badWords) {
    if (word) text = text.replace(new RegExp(word.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&'), 'gi'), '***');
  }
  req.body.text = text;
  next();
}

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Giriş gerekli.' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Oturum geçersiz veya süresi dolmuş.' });
  }
}
function adminOnly(req, res, next) {
  if (!['admin', 'super_admin'].includes(req.user.role)) return res.status(403).json({ error: 'Admin yetkisi gerekli.' });
  next();
}

app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (typeof username !== 'string' || typeof email !== 'string' ||
        typeof password !== 'string' || password.length < 10) {
      return res.status(400).json({ error: 'Kullanıcı adı, e-posta ve en az 10 karakterli parola gerekli.' });
    }
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ username, email, password: passwordHash });
    return res.status(201).json({ success: true, user: { id: user.id, username: user.username } });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ error: 'Kullanıcı adı veya e-posta zaten kullanılıyor.' });
    return res.status(500).json({ error: 'Kayıt işlemi tamamlanamadı.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username }).select('+password');
    if (!user || !(await bcrypt.compare(String(password || ''), user.password))) {
      return res.status(401).json({ error: 'Kullanıcı adı veya parola hatalı.' });
    }
    const token = jwt.sign(
      { sub: user.id, role: user.role, username: user.username },
      JWT_SECRET,
      { expiresIn: '2h', issuer: 'savetube' }
    );
    return res.json({ success: true, token, user: { id: user.id, username: user.username, role: user.role } });
  } catch {
    return res.status(500).json({ error: 'Giriş yapılamadı.' });
  }
});

app.get('/api/videos', async (req, res) => {
  try {
    const type = ['video', 'shorts'].includes(req.query.type) ? req.query.type : undefined;
    const filter = type ? { type } : {};
    const videos = await Video.find(filter)
      .sort({ createdAt: -1 }).limit(50)
      .populate('uploader', 'username avatar isVerified');
    res.json({ videos });
  } catch {
    res.status(500).json({ error: 'Videolar yüklenemedi.' });
  }
});

app.post('/api/videos', auth, async (req, res) => {
  try {
    const { title, description = '', videoUrl, thumbnailUrl = '', type = 'video', duration } = req.body;
    if (typeof title !== 'string' || !title.trim() || typeof videoUrl !== 'string' ||
        !['video', 'shorts'].includes(type) || !Number.isFinite(Number(duration)) || Number(duration) < 0) {
      return res.status(400).json({ error: 'Başlık, video URL, geçerli tür ve süre gerekli.' });
    }
    const video = await Video.create({
      title: title.trim(), description, videoUrl, thumbnailUrl, type,
      duration: Number(duration), uploader: req.user.sub
    });
    await User.findByIdAndUpdate(req.user.sub, { lastUploadDate: new Date() });
    res.status(201).json({ success: true, video });
  } catch {
    res.status(500).json({ error: 'Video oluşturulamadı.' });
  }
});

// Public metrics are incremented by real interactions; there is no fake-engagement injector.
app.post('/api/videos/:id/view', async (req, res) => {
  try {
    const video = await Video.findByIdAndUpdate(req.params.id, { $inc: { viewsCount: 1 } }, { new: true });
    if (!video) return res.status(404).json({ error: 'Video bulunamadı.' });
    res.json({ viewsCount: video.viewsCount });
  } catch {
    res.status(400).json({ error: 'Video ID geçersiz.' });
  }
});

// Admin moderation example: list users. Promote trusted admins manually in the database.
app.get('/api/admin/users', auth, adminOnly, async (req, res) => {
  const users = await User.find().select('username email role isVerified createdAt').limit(100);
  res.json({ users });
});

app.post('/api/comments/filter-preview', filterComment, (req, res) => {
  res.json({ text: req.body.text });
});

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'SAVETUBE' }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Beklenmeyen sunucu hatası.' });
});

mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/savetube')
  .then(() => {
    app.listen(PORT, () => console.log(`SAVETUBE sunucusu http://localhost:${PORT} adresinde çalışıyor.`));
  })
  .catch(err => {
    console.error('MongoDB bağlantısı kurulamadı:', err.message);
    process.exit(1);
  });
