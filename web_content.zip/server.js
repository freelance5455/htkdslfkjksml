const express = require('express');
const multer = require('multer');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
const PORT = 3000;

// ===== DATABASE =====
const DB_PATH = path.join(__dirname, 'database.json');

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = {
      users: [
        {
          id: 1,
          username: 'owner',
          password: bcrypt.hashSync('owner123', 10),
          role: 'owner',
          createdAt: new Date().toISOString()
        }
      ],
      photos: []
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

let db = loadDB();

// ===== UPLOAD =====
const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    cb(null, `photo_${Date.now()}_${Math.floor(Math.random() * 1000)}.png`);
  }
});
const upload = multer({ storage });

// ===== MIDDLEWARE =====
app.use(express.static('public'));
app.use(express.json());
app.use(session({
  secret: 'photobooth-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 }
}));

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'Unauthorized' });
  next();
}
function requireOwner(req, res, next) {
  if (!req.session.user || req.session.user.role !== 'owner') {
    return res.status(403).json({ error: 'Forbidden: Owner only' });
  }
  next();
}

// ===== AUTH =====
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.users.find(u => u.username === username);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Username atau password salah' });
  }
  req.session.user = { id: user.id, username: user.username, role: user.role };
  res.json({ success: true, user: req.session.user });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/me', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not logged in' });
  res.json(req.session.user);
});

// ===== PHOTO =====
app.post('/api/upload', requireAuth, upload.single('photo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const photo = {
    id: Date.now(),
    filename: req.file.filename,
    url: `/uploads/${req.file.filename}`,
    ownerId: req.session.user.id,
    ownerName: req.session.user.username,
    uploadedAt: new Date().toISOString()
  };
  db.photos.push(photo);
  saveDB(db);
  res.json({ success: true, photo });
});

app.get('/api/my-photos', requireAuth, (req, res) => {
  const myPhotos = db.photos
    .filter(p => p.ownerId === req.session.user.id)
    .sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
  res.json(myPhotos);
});

app.get('/api/all-photos', requireOwner, (req, res) => {
  const all = db.photos.sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
  res.json(all);
});

app.delete('/api/photos/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id);
  const idx = db.photos.findIndex(p => p.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Foto tidak ditemukan' });
  const photo = db.photos[idx];
  if (req.session.user.role !== 'owner' && photo.ownerId !== req.session.user.id) {
    return res.status(403).json({ error: 'Tidak punya akses' });
  }
  const filePath = path.join(uploadDir, photo.filename);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  db.photos.splice(idx, 1);
  saveDB(db);
  res.json({ success: true });
});

// ===== MANAGE USERS (OWNER) =====
app.get('/api/users', requireOwner, (req, res) => {
  res.json(db.users.map(u => ({
    id: u.id, username: u.username, role: u.role, createdAt: u.createdAt
  })));
});

app.post('/api/users', requireOwner, (req, res) => {
  const { username, password, role } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Username dan password wajib diisi' });
  if (username.length < 3 || username.length > 20) return res.status(400).json({ error: 'Username harus 3-20 karakter' });
  if (!/^[a-zA-Z0-9_]+$/.test(username)) return res.status(400).json({ error: 'Username hanya boleh huruf, angka, underscore' });
  if (password.length < 6) return res.status(400).json({ error: 'Password minimal 6 karakter' });
  if (db.users.find(u => u.username.toLowerCase() === username.toLowerCase())) {
    return res.status(400).json({ error: 'Username sudah dipakai' });
  }
  const newUser = {
    id: Date.now(),
    username: username.trim(),
    password: bcrypt.hashSync(password, 10),
    role: role === 'owner' ? 'owner' : 'member',
    createdAt: new Date().toISOString()
  };
  db.users.push(newUser);
  saveDB(db);
  res.json({ success: true, user: { id: newUser.id, username: newUser.username, role: newUser.role } });
});

app.delete('/api/users/:id', requireOwner, (req, res) => {
  const id = parseInt(req.params.id);
  if (id === req.session.user.id) return res.status(400).json({ error: 'Tidak bisa hapus akun sendiri' });
  const idx = db.users.findIndex(u => u.id === id);
  if (idx === -1) return res.status(404).json({ error: 'User tidak ditemukan' });
  const userPhotos = db.photos.filter(p => p.ownerId === id);
  userPhotos.forEach(p => {
    const fp = path.join(uploadDir, p.filename);
    if (fs.existsSync(fp)) fs.unlinkSync(fp);
  });
  db.photos = db.photos.filter(p => p.ownerId !== id);
  db.users.splice(idx, 1);
  saveDB(db);
  res.json({ success: true });
});

// ===== SERVER INFO (OWNER) =====
app.get('/api/server-info', requireOwner, (req, res) => {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push({ interface: name, ip: iface.address });
      }
    }
  }
  res.json({
    hostname: os.hostname(),
    platform: os.platform(),
    port: PORT,
    addresses,
    uptime: process.uptime(),
    memory: {
      total: (os.totalmem() / 1024 / 1024 / 1024).toFixed(2) + ' GB',
      free: (os.freemem() / 1024 / 1024 / 1024).toFixed(2) + ' GB'
    },
    totalUsers: db.users.length,
    totalPhotos: db.photos.length
  });
});

// ===== PAGE PROTECTION =====
app.get('/owner.html', (req, res, next) => {
  if (!req.session.user || req.session.user.role !== 'owner') return res.redirect('/login.html');
  next();
});
app.get('/member.html', (req, res, next) => {
  if (!req.session.user) return res.redirect('/login.html');
  if (req.session.user.role === 'owner') return res.redirect('/owner.html');
  next();
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n📸 Photo Booth Server v3.0`);
  console.log(`🌐 Local: http://localhost:${PORT}`);
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        console.log(`📡 Network: http://${iface.address}:${PORT}`);
      }
    }
  }
  console.log(`\n👑 Login Default: ferdi / ferdi123`);
  console.log(`⚠️  Member dibuat manual oleh Owner.\n`);
});