import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';

const app = express();
app.use(express.json({limit:'1mb'}));
app.use(express.static('.'));

const client = new OpenAI({apiKey: process.env.OPENAI_API_KEY});
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';

app.post('/api/chat', async (req,res)=>{
  try{
    const {message, language='ku', bot_id='qurani-piroz'} = req.body || {};
    if(!message) return res.status(400).json({error:'message is required'});
    const lang = language==='ar'?'Arabic':language==='en'?'English':language==='badini'?'Kurdish Badini':'Kurdish Sorani';
    const response = await client.responses.create({
      model: MODEL,
      store: false,
      instructions:
        `You are Qurani Piroz Islamic assistant, bot id ${bot_id}. Answer in ${lang}. `+
        `Give respectful general Islamic information. For specific fatwas, tell the user to consult a trusted qualified scholar. `+
        `Do not invent Quran verses or hadith references. When citing scripture, clearly distinguish exact quotations from explanations.`,
      input: message
    });
    res.json({answer: response.output_text || 'No answer returned.'});
  }catch(e){
    console.error(e);
    res.status(500).json({error:'Chat backend error. Check OPENAI_API_KEY and server logs.'});
  }
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Qurani Piroz running on http://localhost:${port}`));
