
const WebSocket = require("ws");
const server = new WebSocket.Server({port:8080});
const users = new Map();
const requests = new Map();
const friends = new Map();
const invites = new Map();
function send(ws,obj){if(ws&&ws.readyState===1)ws.send(JSON.stringify(obj))}
function listFriends(user){
  return [...(friends.get(user)||[])].map(name=>({username:name,online:users.has(name)}));
}
function refresh(user){
  const ws=users.get(user);
  if(!ws)return;
  const req=[...(requests.get(user)||[])];
  const inv=[...(invites.get(user)||[])];
  send(ws,{type:"friends",friends:listFriends(user),requests:req,invites:inv});
}
function addFriend(a,b){
  if(!friends.has(a))friends.set(a,new Set());
  if(!friends.has(b))friends.set(b,new Set());
  friends.get(a).add(b);friends.get(b).add(a);
}
server.on("connection",ws=>{
  ws.user=null;
  ws.on("message",raw=>{
    let m;try{m=JSON.parse(raw)}catch{return}
    if(m.type==="login"){
      ws.user=String(m.username||"").trim();
      if(!ws.user)return;
      users.set(ws.user,ws);refresh(ws.user);
      for(const u of users.keys())refresh(u);
      return;
    }
    const u=ws.user;if(!u)return;
    if(m.type==="friend_request"){
      const to=String(m.to||"").trim();
      if(!to||to===u)return;
      if(!requests.has(to))requests.set(to,[]);
      if(!requests.get(to).includes(u))requests.get(to).push(u);
      if(users.has(to))send(users.get(to),{type:"friend_request",from:u});
      refresh(u);if(users.has(to))refresh(to);
    }
    if(m.type==="friend_accept"){
      const from=String(m.from||"");
      const arr=requests.get(u)||[];
      requests.set(u,arr.filter(x=>x!==from));
      addFriend(u,from);
      if(users.has(from))send(users.get(from),{type:"friend_accepted",from:u});
      refresh(u);if(users.has(from))refresh(from);
    }
    if(m.type==="invite"){
      const to=String(m.to||"");
      if(users.has(to)){
        const id=Date.now()+"_"+Math.random().toString(36).slice(2);
        if(!invites.has(to))invites.set(to,[]);
        invites.get(to).push({id,from:u});
        send(users.get(to),{type:"invite",id,from:u});
      }
    }
    if(m.type==="invite_accept"){
      const id=String(m.id||"");
      let owner=null;
      for(const [name,arr] of invites)if(arr.some(x=>x.id===id))owner=name;
      if(owner&&users.has(owner)){
        send(users.get(owner),{type:"invite_accepted",from:u});
        send(ws,{type:"invite_accepted",from:owner});
        // A real shared room can be started by the host after acceptance.
      }
    }
    if(m.type==="chat"){
      for(const name of friends.get(u)||[])if(users.has(name))send(users.get(name),{type:"chat",from:u,message:String(m.message||"").slice(0,200)});
    }
  });
  ws.on("close",()=>{
    if(ws.user){users.delete(ws.user);for(const u of users.keys())refresh(u)}
  });
});
console.log("Maze Adventure server running on ws://localhost:8080");
