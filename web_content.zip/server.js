import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.disable('x-powered-by');
app.use(express.json({ limit: '12mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function aiClient() {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'add_your_key_here') {
    const e = new Error('Setup needed: configure GEMINI_API_KEY in your server-side .env or Secrets settings.');
    e.status = 503;
    throw e;
  }
  return new GoogleGenAI({ apiKey: key });
}
function errorMessage(e) {
  const msg = String(e?.message || '');
  if (/quota|billing|rate.?limit|model|permission|not found|api.?key|unauthorized/i.test(msg)) return msg.slice(0, 260);
  return 'The AI provider could not finish this request. Check server logs, model access, and usage limits.';
}
function validateImage(data, mimeType) {
  if (!data || data.length > 9_500_000) throw Object.assign(new Error('Choose an image smaller than about 7 MB.'), {status:400});
  if (!['image/jpeg','image/png','image/webp'].includes(mimeType)) throw Object.assign(new Error('Please use a JPG, PNG, or WebP image.'), {status:400});
}
function inputWithOptionalImage(prompt, imageData, mimeType) {
  if (!imageData) return prompt;
  validateImage(imageData, mimeType);
  return [
    { type: 'image', data: imageData, mime_type: mimeType },
    { type: 'text', text: prompt }
  ];
}
app.get('/api/health', (_req,res) => res.json({
  ok:true,
  app:'AI & AK',
  imageConfigured:Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'add_your_key_here'),
  videoConfigured:Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'add_your_key_here')
}));

// Text-to-image, image editing, and character-sheet creation all use the real image model.
app.post('/api/image', async (req,res) => {
  try {
    const prompt = String(req.body?.prompt || '').trim();
    const kind = String(req.body?.kind || 'photo');
    const aspectRatio = String(req.body?.aspectRatio || '1:1');
    const imageData = req.body?.imageData ? String(req.body.imageData) : '';
    const mimeType = String(req.body?.mimeType || '');
    if (prompt.length < 3 || prompt.length > 1800) return res.status(400).json({error:'Prompt must be between 3 and 1800 characters.'});
    if (!['1:1','3:2','2:3','16:9','9:16'].includes(aspectRatio)) return res.status(400).json({error:'Unsupported aspect ratio.'});
    if (kind === 'edit' && !imageData) return res.status(400).json({error:'Upload a photo to edit first.'});
    const stylePrompt = kind === 'character'
      ? `Create a professional character sheet, no text or labels, multiple clear angles and close-up detail views, consistent character design, clean studio layout. ${prompt}`
      : kind === 'edit'
      ? `Edit the uploaded image according to these instructions while preserving the main subject where possible. ${prompt}`
      : `Create a high-quality original image. ${prompt}`;
    const ai = aiClient();
    const result = await ai.interactions.create({
      model: process.env.GEMINI_IMAGE_MODEL || 'gemini-nano-banana-2.1',
      input: inputWithOptionalImage(stylePrompt, imageData, mimeType),
      response_format: { type: 'image', aspect_ratio: aspectRatio }
    });
    const image = result?.output_image;
    if (!image?.data) return res.status(502).json({error:'The image model returned no image. Check model access or try again.'});
    res.json({ok:true, mimeType:image.mime_type || 'image/png', data:image.data, kind});
  } catch(e) {
    console.error('Image request failed:', errorMessage(e));
    res.status(e.status || 502).json({error:errorMessage(e)});
  }
});

// Text-to-video and photo-to-video use the video-capable Interactions API.
app.post('/api/video', async (req,res) => {
  try {
    const prompt = String(req.body?.prompt || '').trim();
    const kind = String(req.body?.kind || 'text-video');
    const imageData = req.body?.imageData ? String(req.body.imageData) : '';
    const mimeType = String(req.body?.mimeType || '');
    const aspectRatio = String(req.body?.aspectRatio || '9:16');
    if (prompt.length < 3 || prompt.length > 1200) return res.status(400).json({error:'Prompt must be between 3 and 1200 characters.'});
    if (!['9:16','16:9'].includes(aspectRatio)) return res.status(400).json({error:'Choose portrait or landscape.'});
    if (kind === 'photo-video' && !imageData) return res.status(400).json({error:'Upload a photo to animate first.'});
    const videoPrompt = kind === 'photo-video'
      ? `Animate the provided image into a short cinematic video. Preserve the main subject. Motion instructions: ${prompt}`
      : `Generate a short high-quality video. ${prompt}`;
    const ai = aiClient();
    const result = await ai.interactions.create({
      model: process.env.GEMINI_VIDEO_MODEL || 'gemini-omni-1.1-flash',
      input: inputWithOptionalImage(videoPrompt, imageData, mimeType),
      response_format: { type: 'video', aspect_ratio: aspectRatio }
    });
    const video = result?.output_video;
    if (!video?.data) return res.status(502).json({error:'The video model did not return a video. Check account model access and try again.'});
    res.json({ok:true, mimeType:video.mime_type || 'video/mp4', data:video.data, kind});
  } catch(e) {
    console.error('Video request failed:', errorMessage(e));
    res.status(e.status || 502).json({error:errorMessage(e)});
  }
});

app.listen(PORT, () => {
  console.log(`AI & AK ready on port ${PORT}`);
  if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'add_your_key_here') {
    console.log('Real AI is not active yet: configure GEMINI_API_KEY server-side.');
  }
});