const express = require('express');
const puppeteer = require('puppeteer');
const fetch = require('node-fetch');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const OLLAMA_URL = 'http://localhost:11434';
const MODEL = 'qwen2.5:7b';
const PORT = 3000;

// ─── Fungsi: Cek apakah pertanyaan butuh browsing ───────────────────────────
function needsBrowsing(question) {
  const triggers = [
    // berita & kejadian
    /hari ini|sekarang|terbaru|terkini|hari ini|minggu ini|bulan ini|tahun ini/i,
    /berita|news|update|info terbaru|kabar/i,
    /2024|2025|2026/i,
    // harga & produk
    /harga|price|berapa harga|beli dimana|jual|toko/i,
    /cuaca|weather|suhu|temperatur/i,
    // pertanyaan faktual spesifik
    /siapa presiden|siapa pm|siapa ceo|siapa ketua/i,
    /kapan rilis|kapan keluar|kapan diluncurkan/i,
    /film apa yang|lagu apa|aplikasi terbaru/i,
    // eksplisit
    /cari|search|google|browsing|cek di internet/i,
  ];
  return triggers.some(r => r.test(question));
}

// ─── Fungsi: Scraping Google ─────────────────────────────────────────────────
async function searchGoogle(query) {
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--window-size=1280,800'
      ]
    });

    const page = await browser.newPage();
    await page.setUserAgent(
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    );
    await page.setViewport({ width: 1280, height: 800 });

    // Buka Google
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}&hl=id&gl=id&num=5`;
    await page.goto(searchUrl, { waitUntil: 'domcontentloaded', timeout: 15000 });

    // Ambil hasil pencarian
    const results = await page.evaluate(() => {
      const items = [];

      // Featured snippet / answer box
      const answerBox = document.querySelector('.hgKElc, .LGOjhe, .kno-rdesc span, [data-attrid="wa:/description"]');
      if (answerBox) {
        items.push({ type: 'answer', text: answerBox.innerText.trim().slice(0, 500) });
      }

      // Knowledge panel
      const kpDesc = document.querySelector('.kno-rdesc span, .wwUB2c');
      if (kpDesc && !answerBox) {
        items.push({ type: 'knowledge', text: kpDesc.innerText.trim().slice(0, 400) });
      }

      // Hasil organik
      const organic = document.querySelectorAll('div[data-sokoban-container], .g, .tF2Cxc');
      let count = 0;
      for (const el of organic) {
        if (count >= 5) break;
        const titleEl = el.querySelector('h3');
        const snippetEl = el.querySelector('.VwiC3b, .yXK7lf, .s3v9rd');
        const linkEl = el.querySelector('a[href]');
        if (titleEl && snippetEl) {
          items.push({
            type: 'result',
            title: titleEl.innerText.trim(),
            snippet: snippetEl.innerText.trim().slice(0, 300),
            url: linkEl ? linkEl.href : ''
          });
          count++;
        }
      }

      return items;
    });

    await browser.close();
    return results;

  } catch (err) {
    if (browser) await browser.close().catch(() => {});
    console.error('[Google] Error:', err.message);
    return [];
  }
}

// ─── Fungsi: Format hasil Google untuk konteks AI ────────────────────────────
function formatSearchContext(results, query) {
  if (!results.length) return '';

  let ctx = `=== Hasil pencarian Google untuk: "${query}" ===\n\n`;

  for (const r of results) {
    if (r.type === 'answer') {
      ctx += `[Jawaban Langsung]\n${r.text}\n\n`;
    } else if (r.type === 'knowledge') {
      ctx += `[Info Utama]\n${r.text}\n\n`;
    } else if (r.type === 'result') {
      ctx += `[${r.title}]\n${r.snippet}\n`;
      if (r.url) ctx += `Sumber: ${r.url}\n`;
      ctx += '\n';
    }
  }

  return ctx;
}

// ─── Fungsi: Tanya ke Ollama ─────────────────────────────────────────────────
async function askOllama(question, context = '', history = []) {
  const systemPrompt = `Kamu adalah AI asisten cerdas bernama "ASION AI" yang berbicara dalam Bahasa Indonesia.
${context ? 'Kamu memiliki akses ke informasi terbaru dari internet melalui browsing Google.' : ''}
Berikan jawaban yang jelas, akurat, dan mudah dipahami.
Jika ada data dari internet, gunakan itu untuk menjawab dengan tepat.
Jawab secara natural, tidak perlu menyebut "sebagai AI" berulang kali.`;

  const messages = [];

  // Riwayat chat
  for (const h of history.slice(-6)) {
    messages.push({ role: h.role, content: h.content });
  }

  // Pertanyaan baru dengan konteks
  const userContent = context
    ? `${context}\nBerdasarkan informasi di atas, jawab pertanyaan ini:\n${question}`
    : question;

  messages.push({ role: 'user', content: userContent });

  const res = await fetch(`${OLLAMA_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: MODEL,
      messages: [{ role: 'system', content: systemPrompt }, ...messages],
      stream: false,
      options: { temperature: 0.7, num_ctx: 4096 }
    })
  });

  if (!res.ok) throw new Error(`Ollama error: ${res.status}`);
  const data = await res.json();
  return data.message?.content || 'Maaf, tidak ada respons.';
}

// ─── Endpoint: Cek status Ollama ─────────────────────────────────────────────
app.get('/api/status', async (req, res) => {
  try {
    const r = await fetch(`${OLLAMA_URL}/api/tags`);
    const data = await r.json();
    const models = data.models?.map(m => m.name) || [];
    const hasModel = models.some(m => m.includes('qwen2.5'));
    res.json({ ollama: true, models, hasModel, model: MODEL });
  } catch {
    res.json({ ollama: false, models: [], hasModel: false });
  }
});

// ─── Endpoint: Chat utama ────────────────────────────────────────────────────
app.post('/api/chat', async (req, res) => {
  const { message, history = [] } = req.body;
  if (!message) return res.status(400).json({ error: 'Pesan kosong' });

  try {
    let searchResults = [];
    let usedBrowsing = false;
    let searchQuery = message;

    // Tentukan apakah perlu browsing
    const shouldBrowse = needsBrowsing(message);

    if (shouldBrowse) {
      console.log(`[Browsing] Mencari: "${searchQuery}"`);
      searchResults = await searchGoogle(searchQuery);
      usedBrowsing = searchResults.length > 0;
      console.log(`[Browsing] Dapat ${searchResults.length} hasil`);
    }

    const context = usedBrowsing ? formatSearchContext(searchResults, searchQuery) : '';
    const answer = await askOllama(message, context, history);

    res.json({
      answer,
      usedBrowsing,
      searchCount: searchResults.length,
      query: usedBrowsing ? searchQuery : null
    });

  } catch (err) {
    console.error('[Chat] Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─── Endpoint: Paksa browsing ─────────────────────────────────────────────────
app.post('/api/search', async (req, res) => {
  const { query, question } = req.body;
  if (!query) return res.status(400).json({ error: 'Query kosong' });

  try {
    console.log(`[Force Search] "${query}"`);
    const searchResults = await searchGoogle(query);
    const context = formatSearchContext(searchResults, query);
    const answer = await askOllama(question || query, context, []);

    res.json({
      answer,
      usedBrowsing: true,
      searchCount: searchResults.length,
      query
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`\n🤖 ASION AI Server berjalan di http://localhost:${PORT}`);
  console.log(`📡 Ollama: ${OLLAMA_URL}`);
  console.log(`🧠 Model: ${MODEL}`);
  console.log(`🌐 Browser: Puppeteer (Google Search)\n`);
});
