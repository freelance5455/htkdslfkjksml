const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const sharp = require('sharp');
const { execFile } = require('child_process');
const fs = require('fs'), path = require('path'), os = require('os');

const TEMPLATE = '/opt/template';
const app = express();
const upload = multer({ dest: os.tmpdir(), limits: { fileSize: 25 * 1024 * 1024, files: 2 } });

app.get('/', (_, res) => res.sendFile(path.join(__dirname, 'apktap.html')));

const run = (cmd, args, cwd) => new Promise((ok, no) =>
  execFile(cmd, args, { cwd, maxBuffer: 1 << 26, timeout: 600000 },
    (e, so, se) => e ? no(new Error(se || so || e.message)) : ok(so)));

const esc = s => s.replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": "\\'" }[c]));

const DENS = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };

async function build(files, name) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'job-'));
  try {
    fs.cpSync(TEMPLATE, dir, { recursive: true });

    // 1. Веб-файлдар
    const www = path.join(dir, 'www');
    fs.rmSync(www, { recursive: true, force: true });
    fs.mkdirSync(www);
    const f = files.html[0];
    if (/\.zip$/i.test(f.originalname)) new AdmZip(f.path).extractAllTo(www, true);
    else fs.copyFileSync(f.path, path.join(www, 'index.html'));
    if (!fs.existsSync(path.join(www, 'index.html'))) throw new Error('ZIP ішінде index.html жоқ');

    // 2. Қолданба аты және ID
    const appDir = path.join(dir, 'android', 'app');
    const sp = path.join(appDir, 'src/main/res/values/strings.xml');
    fs.writeFileSync(sp, fs.readFileSync(sp, 'utf8')
      .replace(/(<string name="app_name">).*?(<\/string>)/, (m, a, b) => a + esc(name) + b)
      .replace(/(<string name="title_activity_main">).*?(<\/string>)/, (m, a, b) => a + esc(name) + b));
    const gp = path.join(appDir, 'build.gradle');
    fs.writeFileSync(gp, fs.readFileSync(gp, 'utf8')
      .replace(/applicationId "[^"]+"/, 'applicationId "com.apktap.a' + Date.now().toString(36) + '"'));

    // 3. Белгіше
    if (files.icon) {
      const res = path.join(appDir, 'src/main/res');
      fs.rmSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true, force: true });
      for (const [d, px] of Object.entries(DENS)) {
        const out = path.join(res, 'mipmap-' + d);
        fs.mkdirSync(out, { recursive: true });
        for (const n of ['ic_launcher.png', 'ic_launcher_round.png'])
          await sharp(files.icon[0].path).resize(px, px, { fit: 'cover' }).png().toFile(path.join(out, n));
      }
    }

    // 4. Құрастыру
    await run('npx', ['cap', 'copy', 'android'], dir);
    await run('./gradlew', ['assembleDebug', '--no-daemon', '-q'], path.join(dir, 'android'));
    return fs.readFileSync(path.join(appDir, 'build/outputs/apk/debug/app-debug.apk'));
  } finally {
    fs.rm(dir, { recursive: true, force: true }, () => {});
  }
}

let queue = Promise.resolve(); // бір мезгілде бір құрастыру
app.post('/api/build', upload.fields([{ name: 'html', maxCount: 1 }, { name: 'icon', maxCount: 1 }]), (req, res) => {
  const files = req.files || {};
  const name = String(req.body.name || '').trim().slice(0, 30);
  const cleanup = () => Object.values(files).flat().forEach(f => fs.rm(f.path, () => {}));
  if (!files.html || name.length < 2) { cleanup(); return res.status(400).json({ error: 'Файл немесе ат жоқ' }); }
  queue = queue
    .then(() => build(files, name))
    .then(buf => res.type('application/vnd.android.package-archive').send(buf))
    .catch(e => { console.error(e); res.status(500).json({ error: 'Құрастыру қатесі' }); })
    .finally(cleanup);
});

app.listen(process.env.PORT || 3000, () => console.log('ApkTap дайын'));
