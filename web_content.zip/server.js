const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const PORT = process.env.PORT || 8080;
const server = http.createServer((req,res)=>{
  const file=path.join(__dirname,'index.html');
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});
  fs.createReadStream(file).pipe(res);
});
const wss = new WebSocket.Server({server});
const rooms=new Map();
function send(ws,obj){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj))}
function remove(ws,notify=true){
 const r=ws.room;if(!r)return;
 const list=rooms.get(r)||[];
 const remaining=list.filter(x=>x!==ws);
 if(notify)remaining.forEach(x=>send(x,{type:'peer-left'}));
 if(remaining.length)rooms.set(r,remaining);else rooms.delete(r);
 ws.room=null;
}
wss.on('connection',ws=>{
 ws.on('message',raw=>{
  let m;try{m=JSON.parse(raw)}catch{return}
  if(m.type==='join'){
   const room=String(m.room||'').trim();if(!room||room.length>32){send(ws,{type:'error',message:'رمز غير صالح'});return}
   const list=rooms.get(room)||[];
   if(list.length>=2){send(ws,{type:'full'});return}
   ws.room=room;list.push(ws);rooms.set(room,list);
   send(ws,{type:'joined',count:list.length,initiator:list.length===1});
   if(list.length===2){send(list[0],{type:'peer-joined'});send(list[1],{type:'peer-joined'})}
   return;
  }
  if(!ws.room)return;
  const peers=rooms.get(ws.room)||[];
  peers.forEach(peer=>{if(peer!==ws)send(peer,m)});
  if(m.type==='leave')remove(ws);
 });
 ws.on('close',()=>remove(ws));
 ws.on('error',()=>remove(ws));
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Wasal signaling server on port ${PORT}`));
