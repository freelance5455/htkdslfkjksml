const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (req, res) => {
  res.json({
    name: "JoelPanel",
    online: true,
    features: ["Aimbot", "Fly Mode", "Speed", "ESP", "Bypass"]
  });
});

app.post("/api/session", (req, res) => {
  res.json({ok: true, message: "JoelPanel session started"});
});

app.listen(PORT, () => console.log(`JoelPanel running on http://localhost:${PORT}`));