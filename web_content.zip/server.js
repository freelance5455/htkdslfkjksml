const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENROUTER_API_KEY;
const MODEL = process.env.OPENROUTER_MODEL || "openrouter/free";

app.use(cors());
app.use(express.json({ limit: "12mb" }));

function contentFromRequest(message, image) {
  const text = String(message || "").trim();
  if (!image) return text;
  return [
    { type: "text", text: text || "Analisis gambar ini." },
    { type: "image_url", image_url: { url: image } }
  ];
}

app.get("/", (req, res) => res.json({ ok: true, service: "Fanci AI" }));
app.get("/health", (req, res) => res.json({ ok: true }));

app.post("/chat", async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).json({ error: "OPENROUTER_API_KEY belum disetel di Railway." });

    const message = String(req.body?.message || "").trim();
    const image = typeof req.body?.image === "string" ? req.body.image : null;
    const history = Array.isArray(req.body?.history) ? req.body.history : [];

    if (!message && !image) return res.status(400).json({ error: "message atau image diperlukan." });

    const safeHistory = history
      .filter(x => x && (x.role === "user" || x.role === "assistant") && typeof x.content === "string")
      .slice(-20)
      .map(x => ({ role: x.role, content: x.content }));

    const current = {
      role: "user",
      content: contentFromRequest(message, image)
    };

    const body = {
      model: MODEL,
      messages: [...safeHistory, current],
      temperature: 0.7
    };

    const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://fanci-ai-production.up.railway.app",
        "X-Title": "Fanci AI"
      },
      body: JSON.stringify(body)
    });

    const data = await r.json();

    if (!r.ok) {
      const detail = data?.error?.message || "OpenRouter request gagal.";
      return res.status(r.status).json({ error: detail });
    }

    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return res.status(502).json({ error: "Model tidak mengembalikan teks." });
    }

    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Terjadi kesalahan pada server Fanci AI." });
  }
});

app.listen(PORT, () => console.log(`Fanci AI server listening on ${PORT}`));
