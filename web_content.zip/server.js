const http=require("http"),fs=require("fs"),path=require("path");
const WebSocket=require("ws");
const PORT=3000,ROOT=path.join(__dirname,"client");
const W=3600,H=2200,MAX_PLAYERS=2,FOOD_COUNT=180,TICK=50;
const COLORS=["#20c997","#ff5d73"];
let players=[],food=[],running=false,gameOver=false;

function rand(a,b){return a+Math.random()*(b-a)}
function makeFood(){let types=[["#64e572",2],["#3fa9ff",5],["#ff4d6d",10],["#ffffff",25]],t=types[Math.floor(Math.random()*types.length)];return{x:rand(50,W-50),y:rand(50,H-50),r:4+t[1]*.08,v:t[1],color:t[0]}}
function resetFood(){food=[];for(let i=0;i<FOOD_COUNT;i++)food.push(makeFood())}
function newPlayer(id,name,i){let x=700+i*2200,y=H/2;return{id,name:(name||("Player "+(i+1))).slice(0,12),color:COLORS[i],body:Array.from({length:22},(_,n)=>({x:x-n*14,y})),angle:i?Math.PI:0,score:22,alive:true,boost:false}}
function broadcast(o){let s=JSON.stringify(o);players.forEach(p=>p.ws&&p.ws.readyState===1&&p.ws.send(s))}
function publicState(){return{type:"state",world:{w:W,h:H},players:players.map(p=>({id:p.id,name:p.name,color:p.color,body:p.body,score:Math.floor(p.score),alive:p.alive})),food}}
function startGame(){if(players.length===2&&!running){running=true;gameOver=false;resetFood();players.forEach((p,i)=>{let q=newPlayer(p.id,p.name,i);q.ws=p.ws;players[i]=q})}}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function update(){
 if(!running)return;
 for(const p of players){
  if(!p.alive)continue;
  let speed=p.boost&&p.score>30?4.8:2.8;
  let h=p.body[0];
  let da=Math.atan2(Math.sin(p.angle-p.targetAngle),Math.cos(p.angle-p.targetAngle));p.angle+=Math.max(-.12,Math.min(.12,da));
  let nx=h.x+Math.cos(p.angle)*speed*5,ny=h.y+Math.sin(p.angle)*speed*5;
  p.body.unshift({x:nx,y:ny});let desired=22+Math.floor(p.score/2);
  if(p.boost&&p.score>0)p.score-=.07;
  while(p.body.length>desired)p.body.pop();
  if(nx<0||ny<0||nx>W||ny>H){p.alive=false}
 }
 // Food
 for(const p of players){if(!p.alive)continue;let h=p.body[0];for(let i=food.length-1;i>=0;i--){if(dist(h,food[i])<p.body[0]?18:18){p.score+=food[i].v;food[i]=makeFood()}}}
 // Head/body collisions
 for(const p of players){if(!p.alive)continue;let h=p.body[0];for(const q of players){if(p===q||!q.alive)continue;for(let i=2;i<q.body.length;i++){if(dist(h,q.body[i])<14){p.alive=false;break}}}}
 // head-to-head: higher score survives, equal = both die
 if(players.length===2&&players[0].alive&&players[1].alive&&dist(players[0].body[0],players[1].body[0])<22){
   if(Math.abs(players[0].score-players[1].score)<1){players[0].alive=players[1].alive=false}
   else if(players[0].score>players[1].score)players[1].alive=false;else players[0].alive=false;
 }
 if(players.some(p=>!p.alive)){
   running=false;let alive=players.filter(p=>p.alive),winnerId=alive.length===1?alive[0].id:null;
   broadcast({type:"result",winnerId,message:winnerId?"The surviving snake wins!":"Both snakes were eliminated.",scores:players.map(p=>p.name+" "+Math.floor(p.score)).join("  •  ")});
 }
 broadcast(publicState());
}
setInterval(update,TICK);

const server=http.createServer((req,res)=>{
 let u=req.url.split("?")[0];if(u==="/")u="/index.html";let file=path.join(ROOT,u);
 if(!file.startsWith(ROOT)||!fs.existsSync(file)){res.writeHead(404);return res.end("Not found")}
 let ext=path.extname(file),types={".html":"text/html",".js":"text/javascript",".css":"text/css"};res.writeHead(200,{"Content-Type":types[ext]||"application/octet-stream"});fs.createReadStream(file).pipe(res)
});
const wss=new WebSocket.Server({server});
wss.on("connection",ws=>{
 let id=Math.random().toString(36).slice(2,9);
 ws.send(JSON.stringify({type:"welcome",id,world:{w:W,h:H}}));
 ws.on("message",raw=>{let m;try{m=JSON.parse(raw)}catch{return}
   if(m.type==="join"){
    if(players.length>=2){ws.send(JSON.stringify({type:"error",message:"Room is full (2 players maximum)."}));return}
    let p={id,name:String(m.name||"Player").slice(0,12),ws,targetAngle:players.length?Math.PI:0,angle:players.length?Math.PI:0,score:22,alive:true,body:[]};
    players.push(p);ws.playerId=id;ws.send(JSON.stringify({type:"waiting"}));if(players.length===2)startGame();
   }
   if(m.type==="input"){let p=players.find(x=>x.id===ws.playerId);if(p&&Number.isFinite(m.angle)){p.targetAngle=m.angle;p.boost=!!m.boost}}
   if(m.type==="restart"&&players.length===2){startGame()}
 });
 ws.on("close",()=>{let i=players.findIndex(p=>p.id===id);if(i>=0)players.splice(i,1);running=false;gameOver=false});
});
server.listen(PORT,"0.0.0.0",()=>console.log(`NovaSnake LAN running on http://0.0.0.0:${PORT}`));
