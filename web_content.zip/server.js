const http=require("http");
const fs=require("fs");
const path=require("path");
const crypto=require("crypto");
const {askOpenRouter}=require("./modules/ai");
const {researchWorld}=require("./modules/research");
const {generateEbook,localizeEbook,localizationQA}=require("./modules/ebook");
const {createPayment}=require("./modules/paygate");
const {notify,load:loadNotifications}=require("./modules/notifications");
const {validatePublicAddress,makeProposal}=require("./modules/wallet");

const CONFIG_PATH=path.join(__dirname,"config.json");
if(!fs.existsSync(CONFIG_PATH)){
  fs.copyFileSync(path.join(__dirname,"config.example.json"),CONFIG_PATH);
  console.log("config.json créé depuis config.example.json. Configure-le puis relance le serveur.");
}
const config=JSON.parse(fs.readFileSync(CONFIG_PATH,"utf8"));
const dataDir=path.join(__dirname,"data");
if(!fs.existsSync(dataDir)) fs.mkdirSync(dataDir,{recursive:true});
const dbPath=path.join(dataDir,"db.json");
function readDb(){try{return JSON.parse(fs.readFileSync(dbPath,"utf8"));}catch{return {orders:{},opportunities:[],products:[],events:[]};}}
function writeDb(db){fs.writeFileSync(dbPath,JSON.stringify(db,null,2));}
let db=readDb();

function json(res,status,obj){
  const raw=JSON.stringify(obj);
  res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
  res.end(raw);
}
function body(req){
  return new Promise((resolve,reject)=>{let s="";req.on("data",c=>s+=c);req.on("end",()=>{try{resolve(s?JSON.parse(s):{});}catch(e){reject(e);}});});
}
function auth(req){
  const h=req.headers.authorization||"";
  return h==="Bearer "+config.adminPassword;
}
function logEvent(type,data={}){
  db.events.unshift({type,data,at:new Date().toISOString()});
  db.events=db.events.slice(0,1000); writeDb(db);
}

async function runAnalysis(){
  const research=await researchWorld(config);
  const system=`Tu es le moteur d'opportunités d'une entreprise numérique.
Analyse uniquement les signaux fournis. Cherche des problèmes concrets, urgence,
capacité à payer, concurrence, difficulté de production, possibilité de personnalisation,
langues potentielles et canaux d'acquisition légitimes.
Ne garantis jamais de revenus. Retourne JSON:
{"opportunities":[{"problem":"", "audience":"", "evidence":[], "whyNow":"",
"product":"", "priceRange":"", "languages":[], "risks":[], "test":"", "confidence":0}]}`;
  const raw=await askOpenRouter(config,system,JSON.stringify(research));
  const result=JSON.parse(raw.replace(/^```json\s*/,"").replace(/\s*```$/,""));
  db.opportunities=result.opportunities||[];
  writeDb(db);
  notify("analysis_complete","Analyse terminée",
    `Analyse terminée : ${db.opportunities.length} opportunités structurées.`,{count:db.opportunities.length});
  return result;
}

async function createOrder(p){
  const id=crypto.randomUUID();
  const callback=config.publicBaseUrl.replace(/\/$/,"")+"/api/paygate/callback/"+id;
  const payment=await createPayment({
    paygate:config.paygate,amount:p.amount,currency:p.currency||"EUR",
    customerEmail:p.email,callbackUrl:callback
  });
  db.orders[id]={id,status:"PENDING",email:p.email,productId:p.productId,amount:p.amount,currency:p.currency||"EUR",payment,createdAt:new Date().toISOString()};
  writeDb(db); logEvent("order_created",{id});
  return {id,paymentUrl:payment.paymentUrl};
}

const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,`http://${req.headers.host}`);
    if(u.pathname==="/api/health") return json(res,200,{ok:true,time:new Date().toISOString()});
    if(u.pathname==="/api/login" && req.method==="POST"){
      const b=await body(req);
      return json(res,b.password===config.adminPassword?200:401,{ok:b.password===config.adminPassword});
    }
    if(!auth(req) && u.pathname.startsWith("/api/") && u.pathname!="/api/login") return json(res,401,{error:"unauthorized"});

    if(u.pathname==="/api/dashboard") return json(res,200,{
      opportunities:db.opportunities.length, products:db.products.length,
      orders:Object.values(db.orders).length,
      paid:Object.values(db.orders).filter(o=>o.status==="PAID").length,
      events:db.events.slice(0,20)
    });

    if(u.pathname==="/api/notifications") return json(res,200,loadNotifications());
    if(u.pathname==="/api/notifications/read" && req.method==="POST"){
      const b=await body(req); const n=loadNotifications(); const x=n.find(z=>z.id===b.id);
      if(x)x.read=true; fs.writeFileSync(path.join(dataDir,"notifications.json"),JSON.stringify(n,null,2));
      return json(res,200,{ok:true});
    }

    if(u.pathname==="/api/analyze" && req.method==="POST"){
      const r=await runAnalysis(); return json(res,200,r);
    }

    if(u.pathname==="/api/ebook" && req.method==="POST"){
      const b=await body(req);
      const lang=b.language||"fr";
      const ebook=await generateEbook(config,b.opportunity,lang);
      db.products.push({id:crypto.randomUUID(),type:"ebook",language:lang,ebook,createdAt:new Date().toISOString()});
      writeDb(db);
      notify("ebook_ready","Ebook terminé",`L'ebook en ${lang} est prêt.`);
      return json(res,200,ebook);
    }

    if(u.pathname==="/api/ebook/localize" && req.method==="POST"){
      const b=await body(req); const ebook=await localizeEbook(config,b.ebook,b.language);
      const qa=await localizationQA(config,ebook,b.language);
      return json(res,200,{ebook,qa});
    }

    if(u.pathname==="/api/order" && req.method==="POST") return json(res,200,await createOrder(await body(req)));

    if(u.pathname.startsWith("/api/paygate/callback/")){
      const id=u.pathname.split("/").pop(); const order=db.orders[id];
      if(!order) return json(res,404,{error:"order_not_found"});
      // PayGate callback data is retained for reconciliation. Fulfilment must
      // compare amount/currency/order data according to the provider response.
      order.callback=Object.fromEntries(u.searchParams.entries());
      order.status="PAID";
      order.paidAt=new Date().toISOString();
      writeDb(db); logEvent("payment_callback",{id});
      notify("payment_received","Paiement reçu",`Commande ${id} marquée payée.`,{orderId:id});
      return json(res,200,{ok:true});
    }

    if(u.pathname==="/api/wallet/proposal" && req.method==="POST"){
      const b=await body(req);
      if(!validatePublicAddress(config.wallet.publicAddress))
        return json(res,400,{error:"Adresse publique du portefeuille non configurée."});
      const proposal=makeProposal({...b,network:b.network||config.wallet.network});
      notify("wallet_proposal","Proposition portefeuille",`Une proposition nécessite votre validation manuelle.`,proposal);
      return json(res,200,proposal);
    }

    // static admin UI
    if(req.method==="GET"){
      let file=u.pathname==="/admin"||u.pathname==="/"?"index.html":u.pathname.slice(1);
      const p=path.join(__dirname,"public",file);
      if(fs.existsSync(p) && fs.statSync(p).isFile()){
        const ext=path.extname(p); const types={".html":"text/html",".js":"text/javascript",".css":"text/css",".json":"application/json"};
        res.writeHead(200,{"Content-Type":types[ext]||"text/plain; charset=utf-8"}); return res.end(fs.readFileSync(p));
      }
    }
    json(res,404,{error:"not_found"});
  }catch(e){
    console.error(e); json(res,500,{error:e.message});
  }
});
const port=process.env.PORT||3000;
server.listen(port,()=>console.log(`Auto Business AI sur http://localhost:${port}/admin`));
