// Optional OAuth2 PKCE backend for Deriv.
// Install: npm i express express-session
// Run: DERIV_CLIENT_ID=... DERIV_REDIRECT_URI=http://localhost:3000/auth/callback node server.js
const express=require("express");
const session=require("express-session");
const crypto=require("crypto");
const path=require("path");
const app=express();

const CLIENT_ID=process.env.DERIV_CLIENT_ID;
const REDIRECT_URI=process.env.DERIV_REDIRECT_URI || "http://localhost:3000/auth/callback";
if(!CLIENT_ID) console.warn("Set DERIV_CLIENT_ID before using OAuth.");

app.use(session({secret:process.env.SESSION_SECRET||crypto.randomBytes(32).toString("hex"),resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax",secure:false}}));
app.use(express.static(path.join(__dirname,"public")));

function b64url(buf){return buf.toString("base64").replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");}
app.get("/auth/login",(req,res)=>{
  const verifier=b64url(crypto.randomBytes(48));
  const challenge=b64url(crypto.createHash("sha256").update(verifier).digest());
  const state=b64url(crypto.randomBytes(24));
  req.session.pkce={verifier,state};
  const u=new URL("https://auth.deriv.com/oauth2/auth");
  u.searchParams.set("response_type","code");
  u.searchParams.set("client_id",CLIENT_ID);
  u.searchParams.set("redirect_uri",REDIRECT_URI);
  u.searchParams.set("scope","trade");
  u.searchParams.set("state",state);
  u.searchParams.set("code_challenge",challenge);
  u.searchParams.set("code_challenge_method","S256");
  res.redirect(u.toString());
});
app.get("/auth/callback",async(req,res)=>{
  try{
    if(req.query.error) return res.status(400).send(req.query.error_description||req.query.error);
    if(!req.session.pkce || req.query.state!==req.session.pkce.state) return res.status(400).send("Invalid OAuth state");
    const body=new URLSearchParams({grant_type:"authorization_code",client_id:CLIENT_ID,code:req.query.code,code_verifier:req.session.pkce.verifier,redirect_uri:REDIRECT_URI});
    const r=await fetch("https://auth.deriv.com/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
    const token=await r.json();
    if(!r.ok) return res.status(r.status).json(token);
    req.session.access_token=token.access_token;
    delete req.session.pkce;
    res.redirect("/?oauth=ok");
  }catch(e){res.status(500).send("OAuth callback failed");}
});
app.get("/auth/status",(req,res)=>res.json({authenticated:!!req.session.access_token}));
app.get("/auth/logout",(req,res)=>req.session.destroy(()=>res.redirect("/")));
app.listen(process.env.PORT||3000,()=>console.log("http://localhost:"+ (process.env.PORT||3000)));
