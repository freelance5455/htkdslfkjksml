import express from "express";
import crypto from "node:crypto";
const app=express(); app.use(express.json());
const PORT=process.env.PORT||3000;
const ADMIN_TOKEN=process.env.ADMIN_TOKEN||"CHANGE_ME_BEFORE_DEPLOYMENT";
const keys=new Map([
["KEY-7F2A-91KD",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-18PX-4QWE",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-3LMN-8R2V",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-5TGH-2YUI",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-9ZXC-6VBN",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-4JKL-7MNB",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-2QAZ-8WSX",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-6EDC-1RFV",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-0POI-5UYT",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["KEY-8HGF-3DSA",{tier:"normal",active:true,maxDevices:1,devices:new Set()}],
["PREM-ALPHA-001",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREM-ALPHA-002",{tier:"premium",active:true,maxDevices:1,devices:new Set()}],
["PREM-ALPHA-003",{tier:"premium",active:true,maxDevices:1,devices:new Set()}]
]);
const hash=v=>crypto.createHash("sha256").update(String(v)).digest("hex");
const admin=(req,res,next)=>req.headers.authorization===`Bearer ${ADMIN_TOKEN}`?next():res.status(401).json({ok:false,error:"unauthorized"});
app.get("/health",(q,r)=>r.json({ok:true,service:"ff-panel-key-api"}));
app.post("/api/key/activate",(req,res)=>{const key=String(req.body?.key||"").trim().toUpperCase(),token=req.body?.deviceToken;if(!key||typeof token!=="string")return res.status(400).json({ok:false,error:"missing_parameters"});const k=keys.get(key);if(!k||!k.active)return res.status(403).json({ok:false,error:"invalid_or_disabled_key"});const d=hash(token);if(k.devices.has(d))return res.json({ok:true,tier:k.tier,message:"already_bound"});if(k.devices.size>=k.maxDevices)return res.status(409).json({ok:false,error:"device_limit_reached"});k.devices.add(d);res.json({ok:true,tier:k.tier,message:"activated"})});
app.get("/api/key/status",(req,res)=>{const k=keys.get(String(req.query.key||"").trim().toUpperCase());if(!k)return res.status(404).json({ok:false,error:"key_not_found"});res.json({ok:true,tier:k.tier,active:k.active,devicesUsed:k.devices.size,devicesAllowed:k.maxDevices})});
app.post("/api/admin/revoke-device",admin,(req,res)=>{const k=keys.get(String(req.body?.key||"").trim().toUpperCase());if(!k)return res.status(404).json({ok:false,error:"key_not_found"});k.devices.delete(hash(req.body?.deviceToken||""));res.json({ok:true,message:"device_unbound"})});
app.post("/api/admin/disable-key",admin,(req,res)=>{const k=keys.get(String(req.body?.key||"").trim().toUpperCase());if(!k)return res.status(404).json({ok:false,error:"key_not_found"});k.active=false;res.json({ok:true,message:"key_disabled"})});
app.listen(PORT,()=>console.log(`FF Panel API listening on :${PORT}`));