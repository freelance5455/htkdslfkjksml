import express from "express";
import dotenv from "dotenv";
import OpenAI, { toFile } from "openai";

dotenv.config();
const app = express();
app.use(express.json({ limit: "35mb" }));
app.use(express.static("public"));

function getClient() {
  const key = process.env.OPENAI_API_KEY;
  if (!key || key.includes("PASTE_YOUR")) return null;
  return new OpenAI({ apiKey: key });
}
function needClient(res) {
  const client = getClient();
  if (!client) {
    res.status(503).json({ error: "سرور هنوز تنظیم نشده است. کلید API را در تنظیمات محرمانهٔ سرور وارد کنید." });
    return null;
  }
  return client;
}

app.get("/api/health", (_req, res) => {
  res.json({ app: "MOJAHID AI", status: "ok", aiConfigured: Boolean(getClient()) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const client = needClient(res);
    if (!client) return;
    const { message = "", imageDataUrls = [], history = [], webSearch = true } = req.body ?? {};
    const images = Array.isArray(imageDataUrls) ? imageDataUrls.slice(0, 6) : [];
    if (!message.trim() && images.length === 0) return res.status(400).json({ error: "پیام یا عکس/ویدیو بفرست." });

    const content = [];
    if (message.trim()) content.push({ type: "input_text", text: message.trim() });
    for (const dataUrl of images) {
      if (typeof dataUrl === "string" && /^data:image\/(png|jpeg|webp);base64,/.test(dataUrl)) {
        content.push({ type: "input_image", image_url: dataUrl, detail: "high" });
      }
    }

    const input = [];
    if (Array.isArray(history)) {
      for (const item of history.slice(-10)) {
        if ((item.role === "user" || item.role === "assistant") && typeof item.content === "string") {
          input.push({ role: item.role, content: item.content.slice(0, 5000) });
        }
      }
    }
    input.push({ role: "user", content });

    const params = {
      model: process.env.OPENAI_TEXT_MODEL || "gpt-6-astra",
      input
    };
    if (webSearch) params.tools = [{ type: "web_search" }];

    const response = await client.responses.create(params);
    res.json({ reply: response.output_text || "پاسخی دریافت نشد." });
  } catch (err) {
    console.error("chat error:", err?.message || err);
    res.status(500).json({ error: "پاسخ دریافت نشد. کلید API، دسترسی مدل و اعتبار حساب را بررسی کنید." });
  }
});

app.post("/api/image", async (req, res) => {
  try {
    const client = needClient(res);
    if (!client) return;
    const { prompt } = req.body ?? {};
    if (!prompt?.trim()) return res.status(400).json({ error: "توضیح عکس را بنویس." });
    const result = await client.images.generate({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare",
      prompt: prompt.trim(), size: "1024x1024", quality: "medium", n: 1
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) return res.status(502).json({ error: "مدل تصویر خروجی نداد." });
    res.json({ imageDataUrl: `data:image/png;base64,${b64}` });
  } catch (err) {
    console.error("image error:", err?.message || err);
    res.status(500).json({ error: "ساخت عکس ناموفق بود. دسترسی مدل تصویر و اعتبار API را بررسی کنید." });
  }
});

app.post("/api/edit-image", async (req, res) => {
  try {
    const client = needClient(res);
    if (!client) return;
    const { prompt, imageDataUrl } = req.body ?? {};
    if (!prompt?.trim() || !imageDataUrl) return res.status(400).json({ error: "عکس و توضیح تغییر را وارد کنید." });
    const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(imageDataUrl);
    if (!match) return res.status(400).json({ error: "فرمت عکس باید PNG، JPEG یا WEBP باشد." });
    const buffer = Buffer.from(match[2], "base64");
    if (buffer.length > 8 * 1024 * 1024) return res.status(413).json({ error: "عکس باید کمتر از ۸ مگابایت باشد." });
    const ext = match[1] === "image/jpeg" ? "jpg" : match[1].split("/")[1];
    const upload = await toFile(buffer, `upload.${ext}`, { type: match[1] });
    const result = await client.images.edit({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare",
      image: upload, prompt: prompt.trim(), size: "1024x1024", quality: "medium", n: 1
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) return res.status(502).json({ error: "مدل تصویر ویرایش‌شده‌ای برنگرداند." });
    res.json({ imageDataUrl: `data:image/png;base64,${b64}` });
  } catch (err) {
    console.error("edit error:", err?.message || err);
    res.status(500).json({ error: "ویرایش عکس انجام نشد. دسترسی مدل تصویر و اعتبار API را بررسی کنید." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`MOJAHID AI listening on ${port}`));