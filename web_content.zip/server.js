require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const API_KEY = process.env.AI_API_KEY;
const BASE_URL = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
const MODEL = process.env.AI_MODEL || "gpt-4o-mini";

const SYSTEM_PROMPT = `You are Nova AI, a helpful assistant. Answer clearly, preferably in the user's language (Hindi/Hinglish if they use it). Help with learning, general questions, safe coding, HTML games and websites. For code-generation requests, follow the requested format and produce complete, runnable examples where practical. Follow age-appropriate safety: do not provide instructions that facilitate violence, weapons, self-harm, illegal activity, dangerous substances, or evading safety protections. If a request is unsafe, briefly refuse and offer a safe alternative. Do not claim to browse the live web; tell the user when you cannot verify current information.`;

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Message is required." });
    if (message.length > 12000) return res.status(413).json({ error: "Message is too long (12,000 characters maximum)." });
    if (!API_KEY) return res.status(503).json({ error: "AI_API_KEY is not configured on the server. Add it to your .env file." });

    const response = await fetch(`${BASE_URL}/chat/completions`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: message }
        ],
        temperature: 0.7
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const detail = data?.error?.message || `AI provider returned HTTP ${response.status}`;
      return res.status(502).json({ error: detail });
    }
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) return res.status(502).json({ error: "The AI provider returned an empty response." });
    res.json({ reply: reply.trim() });
  } catch (err) {
    console.error("Nova API error:", err);
    res.status(500).json({ error: "Server error. Check server logs and provider settings." });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true, configured: Boolean(API_KEY), model: MODEL }));
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Nova AI running at http://localhost:${port}`));
