import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";
dotenv.config();
const app = express();
const port = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "30kb" }));
app.use(express.static(__dirname));
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
app.post("/api/ask", async (req, res) => {
  try {
    const subject = String(req.body?.subject || "सामान्य").slice(0, 80);
    const question = String(req.body?.question || "").trim().slice(0, 4000);
    if (!question) return res.status(400).json({ error: "सवाल लिखें।" });
    if (!client) return res.status(503).json({ error: "AI सेटअप पूरा नहीं है। सर्वर पर OPENAI_API_KEY जोड़ें।" });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions: `तुम 10th Study ऐप के धैर्यवान कक्षा 10 शिक्षक हो। विषय: ${subject}। विद्यार्थी को सरल हिंदी में, चरण-दर-चरण और उम्र के अनुकूल समझाओ। जरूरत पर उदाहरण, सूत्र, परिभाषा और परीक्षा में लिखने योग्य उत्तर दो। यदि प्रश्न पाठ्यक्रम से बाहर हो तो स्पष्ट कहो।`,
      input: question,
      max_output_tokens: 900
    });
    res.json({ answer: response.output_text || "माफ़ करना, इस बार जवाब नहीं बन पाया। फिर कोशिश करो।" });
  } catch (error) {
    console.error("AI request failed:", error?.message || error);
    res.status(500).json({ error: "अभी AI जवाब नहीं दे पाया। थोड़ी देर बाद कोशिश करें।" });
  }
});
app.get("/api/health", (_req, res) => res.json({ ok: true, aiConfigured: Boolean(client) }));
app.listen(port, () => console.log(`10th Study चल रहा है: http://localhost:${port}`));
