const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({
    users: [],
    roles: [],
    badges: [],
    socialLinks: [],
    animes: [],
    mangas: [],
    episodes: [],
    chapters: [],
    comments: [],
    connections: [],
    restrictedConnectionUsers: [],
    settings: {
      version: "1.2.0",
      primaryColor: "#367dff",
      backgroundColor: "#0d0d0f",
      cardColor: "#17171a",
      textColor: "#f4f4f5",
      homeIcon: ""
    }
  }, null, 2));
}

function db() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}
function id(prefix) {
  return prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function publicUser(u) {
  return {
    id: u.id,
    nick: u.nick,
    permanentNick: u.permanentNick,
    email: u.email,
    role: u.role,
    profilePhoto: u.profilePhoto || "",
    banner: u.banner || "",
    bio: u.bio || "",
    createdAt: u.createdAt
  };
}

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "animeapp-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 7 * 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function requireLogin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Faça login." });
  next();
}
function requireOwner(req, res, next) {
  const data = db();
  const u = data.users.find(x => x.id === req.session.userId);
  if (!u || u.role !== "owner") return res.status(403).json({ error: "Acesso somente do dono." });
  req.currentUser = u;
  next();
}

app.post("/api/register", async (req, res) => {
  const { nick, permanentNick, email, password } = req.body;
  if (!nick || !permanentNick || !email || !password) return res.status(400).json({ error: "Preencha todos os campos." });

  const data = db();
  if (data.users.some(u => u.email.toLowerCase() === email.toLowerCase()))
    return res.status(409).json({ error: "Email já cadastrado." });
  if (data.users.some(u => u.permanentNick.toLowerCase() === permanentNick.toLowerCase()))
    return res.status(409).json({ error: "Nick permanente já está em uso." });

  const first = data.users.length === 0;
  const user = {
    id: id("usr"),
    nick,
    permanentNick,
    email,
    passwordHash: await bcrypt.hash(password, 12),
    role: first ? "owner" : "member",
    profilePhoto: "",
    banner: "",
    bio: "",
    createdAt: new Date().toISOString()
  };
  data.users.push(user);
  save(data);
  req.session.userId = user.id;
  res.json({ user: publicUser(user), owner: first });
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const data = db();
  const user = data.users.find(u => u.email.toLowerCase() === String(email || "").toLowerCase());
  if (!user || !(await bcrypt.compare(password || "", user.passwordHash)))
    return res.status(401).json({ error: "Email ou senha incorretos." });
  req.session.userId = user.id;
  res.json({ user: publicUser(user) });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", requireLogin, (req, res) => {
  const data = db();
  const u = data.users.find(x => x.id === req.session.userId);
  if (!u) return res.status(401).json({ error: "Sessão inválida." });
  res.json({ user: publicUser(u), owner: u.role === "owner" });
});

/*
  PAINEL DO DONO
  - Lista todas as contas.
  - Nunca envia passwordHash para o navegador.
  - O dono pode redefinir senha, email, nick e nick permanente.
*/
app.get("/api/admin/users", requireOwner, (req, res) => {
  const data = db();
  res.json({
    users: data.users.map(publicUser),
    securityNote: "Senhas não são exibidas. O dono pode redefinir uma senha através do formulário de alteração."
  });
});

app.patch("/api/admin/users/:userId", requireOwner, async (req, res) => {
  const data = db();
  const target = data.users.find(u => u.id === req.params.userId);
  if (!target) return res.status(404).json({ error: "Conta não encontrada." });

  const { nick, permanentNick, email, password } = req.body;
  const changes = { nick, permanentNick, email, password };

  if (![nick, permanentNick, email, password].some(v => v !== undefined && String(v).trim() !== "")) {
    return res.status(400).json({ error: "Altere pelo menos um campo para salvar." });
  }

  if (permanentNick && data.users.some(u => u.id !== target.id && u.permanentNick.toLowerCase() === permanentNick.toLowerCase()))
    return res.status(409).json({ error: "Nick permanente já está em uso." });

  if (email && data.users.some(u => u.id !== target.id && u.email.toLowerCase() === email.toLowerCase()))
    return res.status(409).json({ error: "Email já está em uso." });

  if (nick) target.nick = nick.trim();
  if (permanentNick) target.permanentNick = permanentNick.trim();
  if (email) target.email = email.trim();
  if (password) target.passwordHash = await bcrypt.hash(password, 12);

  save(data);
  res.json({ user: publicUser(target), message: "Conta atualizada." });
});

app.patch("/api/me/profile", requireLogin, (req, res) => {
  const data = db();
  const u = data.users.find(x => x.id === req.session.userId);
  if (!u) return res.status(401).json({ error: "Conta não encontrada." });
  const { nick, bio, profilePhoto, banner } = req.body;
  if (nick !== undefined) u.nick = String(nick).slice(0, 40);
  if (bio !== undefined) u.bio = String(bio).slice(0, 100);
  if (profilePhoto !== undefined) u.profilePhoto = String(profilePhoto);
  if (banner !== undefined) u.banner = String(banner);
  save(data);
  res.json({ user: publicUser(u) });
});



app.get("/api/connections", requireLogin, (req, res) => {
  const data = db();
  const restricted = new Set(data.restrictedConnectionUsers || []);
  res.json({
    connections: (data.connections || []).filter(c => !restricted.has(c.userId))
  });
});

app.post("/api/connections", requireLogin, (req, res) => {
  const data = db();
  const user = data.users.find(u => u.id === req.session.userId);
  if (!user) return res.status(401).json({ error: "Conta não encontrada." });
  if ((data.restrictedConnectionUsers || []).includes(user.id))
    return res.status(403).json({ error: "Você está proibido de publicar conexões." });

  const { image, url } = req.body;
  if (!image || !url) return res.status(400).json({ error: "Foto e link são obrigatórios." });
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: "Use um link começando com http:// ou https://." });

  data.connections = (data.connections || []).filter(c => c.userId !== user.id);
  data.connections.push({
    id: "conn_" + Date.now().toString(36) + Math.random().toString(36).slice(2,7),
    userId: user.id,
    nick: user.nick,
    image,
    url,
    createdAt: new Date().toISOString()
  });
  save(data);
  res.json({ ok: true });
});

app.delete("/api/connections", requireLogin, (req, res) => {
  const data = db();
  data.connections = (data.connections || []).filter(c => c.userId !== req.session.userId);
  save(data);
  res.json({ ok: true });
});

app.get("/api/admin/connections", requireOwner, (req, res) => {
  const data = db();
  const restricted = new Set(data.restrictedConnectionUsers || []);
  res.json({
    connections: (data.connections || []).map(c => ({...c, restricted: restricted.has(c.userId)})),
    restrictedUsers: data.users.filter(u => restricted.has(u.id)).map(publicUser)
  });
});

app.post("/api/admin/connections/:userId/restrict", requireOwner, (req, res) => {
  const data = db();
  if (!data.restrictedConnectionUsers) data.restrictedConnectionUsers = [];
  if (!data.restrictedConnectionUsers.includes(req.params.userId))
    data.restrictedConnectionUsers.push(req.params.userId);
  data.connections = (data.connections || []).filter(c => c.userId !== req.params.userId);
  save(data);
  res.json({ ok: true, message: "Links do usuário proibidos e removidos." });
});

app.post("/api/admin/connections/:userId/unrestrict", requireOwner, (req, res) => {
  const data = db();
  data.restrictedConnectionUsers = (data.restrictedConnectionUsers || []).filter(id => id !== req.params.userId);
  save(data);
  res.json({ ok: true, message: "Restrição retirada." });
});

app.get("/api/settings", (req, res) => {
  const data = db();
  const defaults = {
    primaryColor: "#367dff",
    backgroundColor: "#0d0d0f",
    cardColor: "#17171a",
    textColor: "#f4f4f5",
    homeIcon: ""
  };
  res.json({ settings: { ...defaults, ...(data.settings || {}) } });
});

app.patch("/api/admin/settings", requireOwner, (req, res) => {
  const data = db();
  const allowed = ["primaryColor", "backgroundColor", "cardColor", "textColor", "homeIcon"];

  if (!data.settings) data.settings = { version: "1.2.0" };

  for (const key of allowed) {
    if (req.body[key] !== undefined) {
      const value = String(req.body[key]).trim();

      if (key !== "homeIcon" && value.length > 80) {
        return res.status(400).json({ error: "Nome/código de cor muito grande." });
      }

      if (key === "homeIcon" && value.length > 3_000_000) {
        return res.status(400).json({ error: "Ícone muito grande. Use uma imagem menor." });
      }

      data.settings[key] = value;
    }
  }

  data.settings.version = "1.2.0";
  save(data);
  res.json({ settings: data.settings, message: "Personalização salva." });
});

app.get("/api/admin/export-users", requireOwner, (req, res) => {
  const data = db();
  res.json({
    users: data.users.map(u => ({
      id: u.id,
      nick: u.nick,
      permanentNick: u.permanentNick,
      email: u.email,
      role: u.role,
      createdAt: u.createdAt
    }))
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`AnimeApp REAL v1.1 rodando em http://localhost:${PORT}`));
