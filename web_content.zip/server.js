/**
 * CHAUFALAND - Backend Server Completo
 * Express + Socket.io (WebRTC Signaling) + Exaroton API/WebSocket + Minecraft Bedrock WebSocket Bridge
 */

const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const { Server } = require('socket.io');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 3000;
const ADMIN_SECRET = 'JuancitoChen23';

// Configuración en memoria (se actualiza desde el Panel Admin)
let config = {
  activeServerType: 'exaroton', // 'exaroton' | 'aternos'
  exarotonApiToken: process.env.EXAROTON_TOKEN || '',
  exarotonServerId: process.env.EXAROTON_SERVER_ID || '',
  aternosServerIp: process.env.ATERNOS_IP || 'chaufaland.aternos.me',
  bedrockWsPort: 3000
};

// Estado en memoria de jugadores en Minecraft Bedrock (desde Addon)
const bedrockPlayers = new Map();

// Canales de Voz Disponibles
const VOICE_CHANNELS = [
  { id: 'general', name: 'General / Spawn', icon: 'home' },
  { id: 'afk', name: 'AFK / Ausente', icon: 'bed' },
  { id: 'cueva', name: 'Cueva & Minería', icon: 'pickaxe' },
  { id: 'base', name: 'Base Principal', icon: 'shield' },
  { id: 'nether', name: 'Expedición Nether', icon: 'flame' }
];

// Usuarios en canales de voz: socketId -> { gamerTag, channelId, isMuted, isSpeaking, socketId }
const voiceUsers = new Map();

// Caché de estado del servidor
let cachedServerStatus = {
  online: false,
  statusText: 'Desconocido',
  host: '',
  port: 19132,
  tps: 20.0,
  ramUsed: '0 MB',
  ramLimit: '0 MB',
  cpuPercent: 0,
  playersCount: 0,
  maxPlayers: 20,
  playerList: [],
  motd: 'Servidor Oficial CHAUFALAND',
  lastUpdated: Date.now()
};

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Middleware de verificación de clave de Creador/Admin
function requireAdminAuth(req, res, next) {
  const authHeader = req.headers['authorization'];
  const pass = req.headers['x-admin-password'] || (authHeader ? authHeader.replace('Bearer ', '') : null);
  if (pass === ADMIN_SECRET) {
    return next();
  }
  return res.status(403).json({ success: false, error: 'Acceso denegado: Clave secreta inválida.' });
}

/* ========================================================
   RUTAS DE API DEL PANEL DE ADMINISTRACIÓN
   ======================================================== */

// Validar clave secreta
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_SECRET) {
    return res.json({ success: true, message: 'Autenticación exitosa en CHAUFALAND' });
  }
  return res.status(401).json({ success: false, message: 'Clave incorrecta' });
});

// Obtener configuración actual
app.get('/api/admin/config', requireAdminAuth, (req, res) => {
  // Mascarar parte del token por seguridad visual
  const maskedToken = config.exarotonApiToken 
    ? config.exarotonApiToken.slice(0, 6) + '...' + config.exarotonApiToken.slice(-4) 
    : '';
  
  res.json({
    success: true,
    config: {
      ...config,
      exarotonApiTokenMasked: maskedToken
    }
  });
});

// Guardar configuración en tiempo real
app.post('/api/admin/config', requireAdminAuth, (req, res) => {
  const { exarotonApiToken, exarotonServerId, activeServerType, aternosServerIp, bedrockWsPort } = req.body;
  
  if (exarotonApiToken !== undefined && !exarotonApiToken.includes('...')) {
    config.exarotonApiToken = exarotonApiToken.trim();
  }
  if (exarotonServerId !== undefined) config.exarotonServerId = exarotonServerId.trim();
  if (activeServerType !== undefined) config.activeServerType = activeServerType;
  if (aternosServerIp !== undefined) config.aternosServerIp = aternosServerIp.trim();
  if (bedrockWsPort !== undefined) config.bedrockWsPort = Number(bedrockWsPort);

  // Reiniciar WebSocket de Exaroton si cambiaron las credenciales
  setupExarotonWebSocket();
  
  // Notificar actualización a clientes
  io.emit('server-config-updated', {
    activeServerType: config.activeServerType,
    aternosServerIp: config.aternosServerIp
  });

  return res.json({ success: true, message: 'Configuración de CHAUFALAND actualizada con éxito', config });
});

/* ========================================================
   ACCIONES DE CONTROL DEL SERVIDOR (EXAROTON)
   ======================================================== */

async function callExarotonApi(endpoint, method = 'GET', body = null) {
  if (!config.exarotonApiToken || !config.exarotonServerId) {
    throw new Error('API Token o Server ID de Exaroton no configurados en el panel admin.');
  }

  const url = `https://api.exaroton.com/v1/servers/${config.exarotonServerId}${endpoint}`;
  const options = {
    method,
    headers: {
      'Authorization': `Bearer ${config.exarotonApiToken}`,
      'Content-Type': 'application/json'
    }
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || `Error HTTP ${response.status}`);
  }
  return data;
}

// Iniciar Servidor
app.post('/api/server/start', requireAdminAuth, async (req, res) => {
  try {
    const result = await callExarotonApi('/start', 'POST');
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Detener Servidor
app.post('/api/server/stop', requireAdminAuth, async (req, res) => {
  try {
    const result = await callExarotonApi('/stop', 'POST');
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Reiniciar Servidor
app.post('/api/server/restart', requireAdminAuth, async (req, res) => {
  try {
    const result = await callExarotonApi('/restart', 'POST');
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Enviar comando a la consola
app.post('/api/server/command', requireAdminAuth, async (req, res) => {
  try {
    const { command } = req.body;
    if (!command) return res.status(400).json({ success: false, error: 'Comando requerido' });
    const result = await callExarotonApi('/command', 'POST', { command });
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Obtener logs recientes
app.get('/api/server/logs', requireAdminAuth, async (req, res) => {
  try {
    const result = await callExarotonApi('/logs');
    res.json({ success: true, logs: result.data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/* ========================================================
   ESTADO DEL SERVIDOR EN TIEMPO REAL (EXAROTON O ATERNOS)
   ======================================================== */

async function fetchAternosPublicStatus() {
  try {
    const targetIp = config.aternosServerIp || 'chaufaland.aternos.me';
    const res = await fetch(`https://api.mcsrvstat.us/2/${encodeURIComponent(targetIp)}`);
    if (!res.ok) throw new Error('Respuesta no válida de mcsrvstat');
    const data = await res.json();
    
    cachedServerStatus = {
      online: data.online === true,
      statusText: data.online ? 'En Línea' : 'Apagado',
      host: targetIp,
      port: data.port || 19132,
      tps: data.online ? 20.0 : 0.0,
      ramUsed: data.online ? '1.2 GB' : '0 MB',
      ramLimit: '2.0 GB',
      cpuPercent: data.online ? 15 : 0,
      playersCount: (data.players && data.players.online) ? data.players.online : 0,
      maxPlayers: (data.players && data.players.max) ? data.players.max : 20,
      playerList: (data.players && data.players.list) ? data.players.list : [],
      motd: (data.motd && data.motd.clean && data.motd.clean.length) ? data.motd.clean.join(' ') : 'CHAUFALAND Minecraft Server',
      lastUpdated: Date.now()
    };

    io.emit('server-status-update', cachedServerStatus);
  } catch (error) {
    console.error('[mcsrvstat error]:', error.message);
  }
}

let exarotonWs = null;
function setupExarotonWebSocket() {
  if (exarotonWs) {
    try { exarotonWs.close(); } catch (e) {}
    exarotonWs = null;
  }

  if (config.activeServerType !== 'exaroton' || !config.exarotonApiToken || !config.exarotonServerId) {
    return;
  }

  const wsUrl = `wss://api.exaroton.com/v1/servers/${config.exarotonServerId}/websocket`;
  console.log(`[Exaroton WS] Conectando a ${wsUrl}...`);
  
  try {
    exarotonWs = new WebSocket(wsUrl, {
      headers: {
        'Authorization': `Bearer ${config.exarotonApiToken}`
      }
    });

    exarotonWs.on('open', () => {
      console.log('[Exaroton WS] Conectado exitosamente en tiempo real a Exaroton.');
      // Suscribirse a canales de Exaroton
      const subscribeMsg = JSON.stringify({
        stream: 'start',
        type: 'stats'
      });
      exarotonWs.send(subscribeMsg);
    });

    exarotonWs.on('message', (raw) => {
      try {
        const payload = JSON.parse(raw.toString());
        if (payload.type === 'stats') {
          cachedServerStatus.ramUsed = `${(payload.data.memory.usage / (1024 * 1024)).toFixed(1)} MB`;
          cachedServerStatus.ramLimit = `${(payload.data.memory.limit / (1024 * 1024)).toFixed(1)} MB`;
          cachedServerStatus.cpuPercent = Math.round(payload.data.cpu.usage);
          cachedServerStatus.tps = payload.data.tps ? parseFloat(payload.data.tps.toFixed(1)) : 20.0;
        } else if (payload.type === 'status') {
          cachedServerStatus.online = payload.data.status === 1;
          const statusMap = { 0: 'Apagado', 1: 'En Línea', 2: 'Iniciando', 3: 'Deteniendo', 4: 'Reiniciando', 5: 'Guardando', 6: 'Cargando', 7: 'Crasheado', 8: 'Pendiente' };
          cachedServerStatus.statusText = statusMap[payload.data.status] || 'Desconocido';
        } else if (payload.type === 'line') {
          // Línea de consola en tiempo real
          io.emit('console-log', payload.data);
        }
        cachedServerStatus.lastUpdated = Date.now();
        io.emit('server-status-update', cachedServerStatus);
      } catch (e) {
        // Ignorar errores de parseo
      }
    });

    exarotonWs.on('error', (err) => {
      console.warn('[Exaroton WS Error]:', err.message);
    });

    exarotonWs.on('close', () => {
      console.log('[Exaroton WS] Desconectado. Reintentando en 10s...');
      setTimeout(() => {
        if (config.activeServerType === 'exaroton') setupExarotonWebSocket();
      }, 10000);
    });
  } catch (err) {
    console.error('[Exaroton WS Init Error]:', err.message);
  }
}

// Polling recurrente de estado
setInterval(() => {
  if (config.activeServerType === 'exaroton' && config.exarotonApiToken && config.exarotonServerId) {
    callExarotonApi('')
      .then(res => {
        const s = res.data;
        const statusMap = { 0: 'Apagado', 1: 'En Línea', 2: 'Iniciando', 3: 'Deteniendo', 4: 'Reiniciando', 5: 'Guardando', 6: 'Cargando', 7: 'Crasheado', 8: 'Pendiente' };
        cachedServerStatus.online = s.status === 1;
        cachedServerStatus.statusText = statusMap[s.status] || 'Desconocido';
        cachedServerStatus.host = s.address || `${s.name}.exaroton.me`;
        cachedServerStatus.port = s.port || 19132;
        cachedServerStatus.playersCount = s.players ? s.players.count : 0;
        cachedServerStatus.maxPlayers = s.players ? s.players.max : 20;
        cachedServerStatus.playerList = s.players ? s.players.list : [];
        cachedServerStatus.motd = s.motd || 'CHAUFALAND Servidor Exaroton';
        cachedServerStatus.lastUpdated = Date.now();
        io.emit('server-status-update', cachedServerStatus);
      })
      .catch(err => {
        // En caso de fallo o cuota, se mantiene el último estado conocido
      });
  } else {
    fetchAternosPublicStatus();
  }
}, 8000);

// Endpoint público para obtener estado actual del servidor
app.get('/api/server/status', (req, res) => {
  res.json({
    success: true,
    data: cachedServerStatus,
    activeType: config.activeServerType,
    channels: VOICE_CHANNELS,
    bedrockPlayers: Array.from(bedrockPlayers.values())
  });
});

/* ========================================================
   PUENTE WEBSOCKET CON MINECRAFT BEDROCK ADDON
   ======================================================== */

// WebSocket Server dedicado para el Addon Bedrock en la ruta /bedrock-ws
const wssBedrock = new WebSocket.Server({ noServer: true });

wssBedrock.on('connection', (ws) => {
  console.log('[Bedrock Bridge] Addon de Minecraft Bedrock conectado.');

  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message.toString());
      
      switch (data.event) {
        case 'player_join':
          bedrockPlayers.set(data.gamerTag, {
            gamerTag: data.gamerTag,
            dimension: data.dimension || 'overworld',
            x: Math.round(data.x || 0),
            y: Math.round(data.y || 0),
            z: Math.round(data.z || 0),
            health: data.health || 20,
            connectedAt: Date.now()
          });
          console.log(`[Bedrock] Jugador ${data.gamerTag} entró.`);
          io.emit('bedrock-player-join', data);
          break;

        case 'player_leave':
          bedrockPlayers.delete(data.gamerTag);
          console.log(`[Bedrock] Jugador ${data.gamerTag} salió.`);
          io.emit('bedrock-player-leave', { gamerTag: data.gamerTag });
          break;

        case 'player_telemetry':
        case 'player_move':
          if (bedrockPlayers.has(data.gamerTag)) {
            const current = bedrockPlayers.get(data.gamerTag);
            current.dimension = data.dimension || current.dimension;
            current.x = Math.round(data.x);
            current.y = Math.round(data.y);
            current.z = Math.round(data.z);
            current.health = data.health !== undefined ? data.health : current.health;
            current.lastPing = Date.now();
          } else {
            bedrockPlayers.set(data.gamerTag, {
              gamerTag: data.gamerTag,
              dimension: data.dimension || 'overworld',
              x: Math.round(data.x || 0),
              y: Math.round(data.y || 0),
              z: Math.round(data.z || 0),
              health: data.health || 20,
              lastPing: Date.now()
            });
          }
          io.emit('bedrock-telemetry-update', {
            gamerTag: data.gamerTag,
            dimension: data.dimension,
            x: Math.round(data.x),
            y: Math.round(data.y),
            z: Math.round(data.z),
            health: data.health
          });
          break;

        case 'chat_message':
          io.emit('minecraft-chat', {
            sender: data.gamerTag,
            message: data.message,
            timestamp: Date.now()
          });
          break;

        default:
          break;
      }
    } catch (err) {
      console.error('[Bedrock WS parse error]:', err.message);
    }
  });

  ws.on('close', () => {
    console.log('[Bedrock Bridge] Addon de Minecraft Bedrock desconectado.');
  });
});

// Manejar upgrade HTTP a WebSocket para /bedrock-ws
server.on('upgrade', (request, socket, head) => {
  const pathname = request.url ? request.url.split('?')[0] : '';
  if (pathname === '/bedrock-ws') {
    wssBedrock.handleUpgrade(request, socket, head, (ws) => {
      wssBedrock.emit('connection', ws, request);
    });
  }
});

/* ========================================================
   SEÑALIZACIÓN WEBRTC Y CHAT DE VOZ ESTILO DISCORD (SOCKET.IO)
   ======================================================== */

io.on('connection', (socket) => {
  console.log(`[Socket.io] Cliente web/móvil conectado: ${socket.id}`);

  // Enviar estado inicial
  socket.emit('init-state', {
    serverStatus: cachedServerStatus,
    activeType: config.activeServerType,
    channels: VOICE_CHANNELS,
    voiceUsers: Array.from(voiceUsers.values()),
    bedrockPlayers: Array.from(bedrockPlayers.values())
  });

  // Unirse a un canal de voz
  socket.handleVoiceJoin = ({ gamerTag, channelId }) => {
    if (!gamerTag || !channelId) return;

    // Si ya estaba en otro canal, avisar a los demás
    if (voiceUsers.has(socket.id)) {
      const prev = voiceUsers.get(socket.id);
      socket.to(prev.channelId).emit('user-left-channel', { socketId: socket.id, gamerTag: prev.gamerTag });
      socket.leave(prev.channelId);
    }

    const userData = {
      socketId: socket.id,
      gamerTag,
      channelId,
      isMuted: false,
      isSpeaking: false,
      avatarUrl: `https://minotar.net/avatar/${encodeURIComponent(gamerTag)}/64.png`,
      joinedAt: Date.now()
    };

    voiceUsers.set(socket.id, userData);
    socket.join(channelId);

    // Obtener pares existentes en ese canal para WebRTC mesh
    const peersInChannel = Array.from(voiceUsers.values()).filter(
      u => u.channelId === channelId && u.socketId !== socket.id
    );

    // Notificar al usuario quiénes están en el canal
    socket.emit('channel-peers', {
      channelId,
      peers: peersInChannel
    });

    // Notificar a los demás del canal que alguien nuevo entró
    socket.to(channelId).emit('user-joined-channel', userData);

    // Actualizar lista global de voz
    io.emit('voice-users-updated', Array.from(voiceUsers.values()));
    console.log(`[Voice] ${gamerTag} entró al canal '${channelId}'`);
  };

  socket.on('join-voice-channel', socket.handleVoiceJoin);

  // Salir de canal de voz
  socket.on('leave-voice-channel', () => {
    if (voiceUsers.has(socket.id)) {
      const user = voiceUsers.get(socket.id);
      socket.to(user.channelId).emit('user-left-channel', { socketId: socket.id, gamerTag: user.gamerTag });
      socket.leave(user.channelId);
      voiceUsers.delete(socket.id);
      io.emit('voice-users-updated', Array.from(voiceUsers.values()));
      console.log(`[Voice] ${user.gamerTag} abandonó el canal de voz.`);
    }
  });

  // WebRTC Signaling: Enviar Oferta (SDP Offer)
  socket.on('webrtc-offer', ({ targetSocketId, offer }) => {
    io.to(targetSocketId).emit('webrtc-offer', {
      senderSocketId: socket.id,
      offer
    });
  });

  // WebRTC Signaling: Enviar Respuesta (SDP Answer)
  socket.on('webrtc-answer', ({ targetSocketId, answer }) => {
    io.to(targetSocketId).emit('webrtc-answer', {
      senderSocketId: socket.id,
      answer
    });
  });

  // WebRTC Signaling: Enviar Candidato ICE
  socket.on('webrtc-ice-candidate', ({ targetSocketId, candidate }) => {
    io.to(targetSocketId).emit('webrtc-ice-candidate', {
      senderSocketId: socket.id,
      candidate
    });
  });

  // Estado de micrófono (Mute/Unmute)
  socket.on('toggle-mute', ({ isMuted }) => {
    if (voiceUsers.has(socket.id)) {
      const user = voiceUsers.get(socket.id);
      user.isMuted = isMuted;
      io.to(user.channelId).emit('user-mute-state', {
        socketId: socket.id,
        isMuted
      });
    }
  });

  // Indicador de voz activa (hablando)
  socket.on('speaking-state', ({ isSpeaking }) => {
    if (voiceUsers.has(socket.id)) {
      const user = voiceUsers.get(socket.id);
      user.isSpeaking = isSpeaking;
      socket.to(user.channelId).emit('user-speaking-state', {
        socketId: socket.id,
        isSpeaking
      });
    }
  });

  // Desconexión
  socket.on('disconnect', () => {
    if (voiceUsers.has(socket.id)) {
      const user = voiceUsers.get(socket.id);
      socket.to(user.channelId).emit('user-left-channel', { socketId: socket.id, gamerTag: user.gamerTag });
      voiceUsers.delete(socket.id);
      io.emit('voice-users-updated', Array.from(voiceUsers.values()));
    }
    console.log(`[Socket.io] Desconectado: ${socket.id}`);
  });
});

// Iniciar servidor HTTP
server.listen(PORT, () => {
  console.log(`=================================================`);
  console.log(`🌲 CHAUFALAND - Servidor Iniciado en Puerto ${PORT}`);
  console.log(`🎮 Web App: http://localhost:${PORT}`);
  console.log(`🔌 Bedrock WS Bridge: ws://localhost:${PORT}/bedrock-ws`);
  console.log(`🔑 Clave de Creador/Admin: ${ADMIN_SECRET}`);
  console.log(`=================================================`);
  setupExarotonWebSocket();
});
