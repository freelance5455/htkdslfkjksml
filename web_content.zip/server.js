const express=require("express");
const cors=require("cors");
const multer=require("multer");
const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");
const {fal}=require("@fal-ai/client");
require("dotenv").config();

const app=express(), PORT=process.env.PORT||3000;
const MODEL=process.env.FAL_VIDEO_MODEL||"fal-ai/kling-video/v2.6/pro/image-to-video";
const UP=path.join(__dirname,"uploads"), OUT=path.join(__dirname,"outputs");
fs.mkdirSync(UP,{recursive:true}); fs.mkdirSync(OUT,{recursive:true});
app.use(cors()); app.use(express.json({limit:"5mb"}));
app.use(express.static(path.join(__dirname,"public")));
app.use("/uploads",express.static(UP)); app.use("/outputs",express.static(OUT));

const storage=multer.diskStorage({
 destination:(_,__,cb)=>cb(null,UP),
 filename:(_,f,cb)=>cb(null,Date.now()+"-"+f.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"))
});
const upload=multer({storage,limits:{fileSize:15*1024*1024},
 fileFilter:(_,f,cb)=>/^image\/(jpeg|png|webp|jpg)$/.test(f.mimetype)?cb(null,true):cb(new Error("Use JPG, PNG or WEBP."))
});

function url(req,name){return `${req.headers["x-forwarded-proto"]||req.protocol}://${req.get("host")}/uploads/${encodeURIComponent(name)}`}

function scenes(story,n){
 const a=story.replace(/\s+/g," ").trim().match(/[^.!?]+[.!?]+|[^.!?]+$/g)||[];
 let out=[],cur="";
 for(const s of a){if(cur&&(cur+" "+s).length>280){out.push(cur.trim());cur=s}else cur+=(cur?" ":"")+s}
 if(cur)out.push(cur.trim());
 return out.slice(0,n).map((description,i)=>({id:i+1,title:`Scene ${i+1}`,description,duration:5,
 motion:"Natural realistic movement, subtle cinematic camera movement"}));
}
app.get("/api/health",(_,r)=>r.json({ok:true,app:"Kedrick AI",model:MODEL,falConfigured:!!process.env.FAL_KEY}));
app.post("/api/upload-character",upload.single("character"),(req,r)=>{
 if(!req.file)return r.status(400).json({error:"No image uploaded."});
 r.json({fileName:req.file.filename,url:url(req,req.file.filename)});
});
app.post("/api/plan",(req,r)=>{
 const story=String(req.body.story||"").trim();
 if(!story)return r.status(400).json({error:"Write a story first."});
 r.json({scenes:scenes(story,Math.min(Math.max(+req.body.maxScenes||6,1),12))});
});
app.post("/api/generate-scene",async(req,r)=>{
 try{
  if(!process.env.FAL_KEY)throw Error("FAL_KEY is missing on the server.");
  fal.config({credentials:process.env.FAL_KEY});
  const {imageUrl,scene,characterNames=[],duration="5"}=req.body;
  if(!imageUrl||!scene)throw Error("Character image and scene are required.");
  const names=characterNames.length?`Characters: ${characterNames.join(", ")}. `:"";
  const prompt=names+`${scene.description}. ${scene.motion||""}. Preserve identity, face, clothing and proportions from the reference image. Realistic cinematic lighting and natural movement.`;
  const result=await fal.subscribe(MODEL,{input:{prompt,start_image_url:imageUrl,duration:String(duration),generate_audio:false},logs:false});
  const video=result?.data?.video?.url;
  if(!video)throw Error("No video URL was returned.");
  r.json({ok:true,videoUrl:video});
 }catch(e){r.status(500).json({error:e.message||"Generation failed."})}
});
function download(u,d){return new Promise((ok,no)=>{
 const h=require(u.startsWith("https")?"https":"http"),f=fs.createWriteStream(d);
 h.get(u,x=>{if(x.statusCode>=300&&x.statusCode<400&&x.headers.location){f.close();fs.unlink(d,()=>{});return download(x.headers.location,d).then(ok).catch(no)}
 if(x.statusCode!==200){f.close();fs.unlink(d,()=>{});return no(Error("Download HTTP "+x.statusCode))}
 x.pipe(f);f.on("finish",()=>f.close(ok))}).on("error",e=>{f.close();fs.unlink(d,()=>{});no(e)})
})}
function ff(args){return new Promise((ok,no)=>{const p=spawn(require("ffmpeg-static"),args);let e="";p.stderr.on("data",d=>e+=d);p.on("close",c=>c?no(Error(e||"ffmpeg failed")):ok())})}
app.post("/api/merge",async(req,r)=>{
 try{
  if(!Array.isArray(req.body.videoUrls)||!req.body.videoUrls.length)throw Error("No videos supplied.");
  const dir=path.join(OUT,"job-"+Date.now());fs.mkdirSync(dir,{recursive:true});let files=[];
  for(let i=0;i<req.body.videoUrls.length;i++){let f=path.join(dir,`scene-${i+1}.mp4`);await download(req.body.videoUrls[i],f);files.push(f)}
  let list=path.join(dir,"list.txt");fs.writeFileSync(list,files.map(f=>`file '${f.replace(/'/g,"'\\''")}'`).join("\n"));
  let final=path.join(dir,"kedrick-ai-final.mp4");await ff(["-y","-f","concat","-safe","0","-i",list,"-c","copy",final]);
  r.json({ok:true,videoUrl:`/outputs/${path.basename(dir)}/kedrick-ai-final.mp4`});
 }catch(e){r.status(500).json({error:e.message||"Merge failed."})}
});
app.use((e,_,r,__)=>r.status(400).json({error:e.message||"Request failed."}));
app.listen(PORT,()=>console.log("Kedrick AI running on "+PORT));
