'use strict';
const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const vm = require('vm');
const { spawnSync } = require('child_process');
const PROJECT_ROOT = __dirname;
const app = express();
app.disable('x-powered-by');
// Render terminates TLS at its trusted proxy; use the client IP for basic abuse throttling.
app.set('trust proxy', 1);
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), geolocation=(), payment=()');
  next();
});
app.use(express.json({ limit: '64kb' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Nova', version: 'phone-manager-v13', time: new Date().toISOString() }));

// Small in-memory rate limiter to reduce accidental/public API abuse. Resets on restart.
const rateBuckets = new Map();
function rateLimit({windowMs=60_000, max=20, keyPrefix='api'}={}) {
  return (req, res, next) => {
    const now=Date.now(), key=`${keyPrefix}:${req.ip || req.socket.remoteAddress || 'unknown'}`;
    let bucket=rateBuckets.get(key);
    if (!bucket || now >= bucket.resetAt) bucket={count:0, resetAt:now+windowMs};
    bucket.count++; rateBuckets.set(key,bucket);
    if (rateBuckets.size > 5000) for (const [k,v] of rateBuckets) if (now >= v.resetAt) rateBuckets.delete(k);
    res.setHeader('RateLimit-Limit', String(max));
    res.setHeader('RateLimit-Remaining', String(Math.max(0,max-bucket.count)));
    res.setHeader('RateLimit-Reset', String(Math.ceil(bucket.resetAt/1000)));
    if (bucket.count > max) return res.status(429).json({error:'طلبات كثيرة خلال وقت قصير. انتظر دقيقة ثم أعد المحاولة.', code:'RATE_LIMITED'});
    next();
  };
}
const auditLog = [];
function recordAction(action, status, detail='') {
  auditLog.unshift({ id: crypto.randomUUID(), action, status, detail: String(detail).slice(0, 240), time: new Date().toISOString() });
  if (auditLog.length > 100) auditLog.length = 100;
}
// Provider registry: discover supported services from server-side environment variables.
// Keys remain server-only. Providers are tried in priority order; failures fall through.
const PROVIDER_DEFS = [
  {id:'gemini',name:'Google Gemini',key:'GEMINI_API_KEY',modelEnv:'GEMINI_MODEL',defaultModel:'gemini-2.5-flash',kind:'gemini'},
  {id:'openai',name:'OpenAI',key:'OPENAI_API_KEY',modelEnv:'OPENAI_MODEL',defaultModel:'gpt-4o-mini',baseEnv:'OPENAI_BASE_URL',defaultBase:'https://api.openai.com/v1',kind:'openai'},
  {id:'openrouter',name:'OpenRouter',key:'OPENROUTER_API_KEY',modelEnv:'OPENROUTER_MODEL',defaultModel:'openai/gpt-4o-mini',baseEnv:'OPENROUTER_BASE_URL',defaultBase:'https://openrouter.ai/api/v1',kind:'openai'},
  {id:'groq',name:'Groq',key:'GROQ_API_KEY',modelEnv:'GROQ_MODEL',defaultModel:'llama-3.3-70b-versatile',baseEnv:'GROQ_BASE_URL',defaultBase:'https://api.groq.com/openai/v1',kind:'openai'},
  {id:'together',name:'Together AI',key:'TOGETHER_API_KEY',modelEnv:'TOGETHER_MODEL',defaultModel:'meta-llama/Llama-3.3-70B-Instruct-Turbo',baseEnv:'TOGETHER_BASE_URL',defaultBase:'https://api.together.xyz/v1',kind:'openai'},
  {id:'deepseek',name:'DeepSeek',key:'DEEPSEEK_API_KEY',modelEnv:'DEEPSEEK_MODEL',defaultModel:'deepseek-chat',baseEnv:'DEEPSEEK_BASE_URL',defaultBase:'https://api.deepseek.com/v1',kind:'openai'},
  {id:'mistral',name:'Mistral AI',key:'MISTRAL_API_KEY',modelEnv:'MISTRAL_MODEL',defaultModel:'mistral-small-latest',baseEnv:'MISTRAL_BASE_URL',defaultBase:'https://api.mistral.ai/v1',kind:'openai'},
  {id:'xai',name:'xAI Grok',key:'XAI_API_KEY',modelEnv:'XAI_MODEL',defaultModel:'grok-3-mini',baseEnv:'XAI_BASE_URL',defaultBase:'https://api.x.ai/v1',kind:'openai'},
  {id:'fireworks',name:'Fireworks AI',key:'FIREWORKS_API_KEY',modelEnv:'FIREWORKS_MODEL',defaultModel:'accounts/fireworks/models/llama-v3p3-70b-instruct',baseEnv:'FIREWORKS_BASE_URL',defaultBase:'https://api.fireworks.ai/inference/v1',kind:'openai'},
  {id:'anthropic',name:'Anthropic Claude',key:'ANTHROPIC_API_KEY',modelEnv:'ANTHROPIC_MODEL',defaultModel:'claude-3-5-haiku-latest',kind:'anthropic'}
];
function discoverProviders() {
  return PROVIDER_DEFS.filter(p => Boolean(process.env[p.key]?.trim())).map(p => ({...p, model:process.env[p.modelEnv]?.trim() || p.defaultModel, base:p.kind==='openai' ? (process.env[p.baseEnv]?.trim() || p.defaultBase).replace(/\/$/,'') : undefined}));
}
function configuredProvider() {
  const p=discoverProviders()[0];
  return p ? {provider:p.name, model:p.model, id:p.id} : {provider:null,model:null,id:null};
}
async function askProvider(provider, {system, messages, maxTokens=1200, temperature=0.35, timeout=45000}) {
  const signal=AbortSignal.timeout(timeout);
  if(provider.kind==='gemini') {
    const contents=messages.map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:m.content}]}));
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(provider.model)}:generateContent`,{method:'POST',signal,headers:{'x-goog-api-key':process.env[provider.key],'Content-Type':'application/json'},body:JSON.stringify({systemInstruction:{parts:[{text:system}]},contents,generationConfig:{temperature,maxOutputTokens:maxTokens}})});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw Object.assign(new Error('provider rejected request'),{status:r.status,provider:provider.name});
    const text=data?.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('').trim();
    if(!text) throw Object.assign(new Error('empty provider response'),{status:502,provider:provider.name});
    return text;
  }
  if(provider.kind==='anthropic') {
    const userMessages=messages.filter(m=>m.role!=='system').map(m=>({role:m.role==='assistant'?'assistant':'user',content:m.content}));
    const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',signal,headers:{'x-api-key':process.env[provider.key],'anthropic-version':'2023-06-01','content-type':'application/json'},body:JSON.stringify({model:provider.model,system,messages:userMessages,max_tokens:maxTokens,temperature})});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw Object.assign(new Error('provider rejected request'),{status:r.status,provider:provider.name});
    const text=(data?.content||[]).map(x=>x.text||'').join('').trim();
    if(!text) throw Object.assign(new Error('empty provider response'),{status:502,provider:provider.name});
    return text;
  }
  const r=await fetch(`${provider.base}/chat/completions`,{method:'POST',signal,headers:{Authorization:`Bearer ${process.env[provider.key]}`,'Content-Type':'application/json'},body:JSON.stringify({model:provider.model,messages:[{role:'system',content:system},...messages],temperature,max_tokens:maxTokens})});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw Object.assign(new Error('provider rejected request'),{status:r.status,provider:provider.name});
  const text=data?.choices?.[0]?.message?.content?.trim();
  if(!text) throw Object.assign(new Error('empty provider response'),{status:502,provider:provider.name});
  return text;
}
async function askAvailableProviders(options) {
  const providers=discoverProviders();
  if(!providers.length) throw Object.assign(new Error('no providers configured'),{code:'AI_NOT_CONFIGURED'});
  const failures=[];
  for(const provider of providers) {
    try { const reply=await askProvider(provider,options); return {reply,provider:provider.name,model:provider.model,failedOver:failures.length,failures}; }
    catch(e) { failures.push({provider:provider.name,status:Number(e.status)||0}); recordAction('مزود AI '+provider.name,'failed',`HTTP ${Number(e.status)||0}`); }
  }
  throw Object.assign(new Error('all providers failed'),{code:'AI_PROVIDERS_FAILED',failures});
}
// Discovery is automatic; actual paid inference is performed only when a user asks Nova,
// avoiding background token charges each time the app is opened.
app.get('/api/manager/providers', (_req,res)=>{
  const found=discoverProviders();
  res.json({ok:true,discovered:found.map(p=>({id:p.id,name:p.name,model:p.model,kind:p.kind,status:'configured'})),count:found.length,automaticRouting:true,failover:true,checkedAt:new Date().toISOString(),message:found.length?'تم اكتشاف الخدمات التي أُعدّت مفاتيحها على الخادم. سيختار Nova أول مزود ويجرب التالي تلقائيًا عند فشل السابق.':'لم يُكتشف أي مزود؛ أضف مفتاح خدمة واحدة أو أكثر إلى Environment على الخادم. لا يمكن اكتشاف حسابات غير مفوضة أو خدمات لا تملك مفاتيحها.'});
});
// Test every configured provider only when explicitly requested; each test may use provider quota.
app.post('/api/manager/provider-check', rateLimit({windowMs:60_000,max:3,keyPrefix:'provider-check'}), async (_req,res)=>{
  const providers=discoverProviders();
  if(!providers.length){recordAction('اكتشاف مزودي AI','needs-configuration','لا توجد مفاتيح');return res.status(503).json({ok:false,code:'AI_NOT_CONFIGURED',message:'لم يُضبط أي مفتاح لخدمات الذكاء الاصطناعي في Environment على الخادم.'});}
  const results=[];
  for(const provider of providers){
    try{const reply=await askProvider(provider,{system:'Reply with OK only.',messages:[{role:'user',content:'Reply with the single word OK.'}],maxTokens:8,temperature:0,timeout:12000});results.push({id:provider.id,name:provider.name,model:provider.model,ok:Boolean(reply),message:'استجاب المزود لطلب الاختبار.'});}
    catch(e){results.push({id:provider.id,name:provider.name,model:provider.model,ok:false,status:Number(e.status)||0,message:e.name==='TimeoutError'?'انتهت مهلة الاتصال.':'لم ينجح الاتصال؛ راجع المفتاح والنموذج والحصة.'});}
  }
  const ok=results.some(x=>x.ok);recordAction('اختبار خدمات AI',ok?'completed':'failed',`${results.filter(x=>x.ok).length}/${results.length} providers responding`);
  res.status(ok?200:502).json({ok,results,message:ok?'تم اختبار الخدمات المضبوطة. سيستخدم Nova التوجيه التلقائي والتبديل الاحتياطي.':'لم يستجب أي مزود مضبوط. تحقق من المفاتيح والنماذج والحصص.'});
});

app.get('/api/status', (_req, res) => {
  const {provider,model}=configuredProvider();
  res.json({ server: true, aiConfigured: Boolean(provider), provider, model, aiProviders: discoverProviders().map(p=>({id:p.id,name:p.name,model:p.model})), aiProviderCount: discoverProviders().length, automaticProviderRouting: true, providerFailover: true, features: { chat: Boolean(provider), news: true, taskManager: 'local-device', managerOrchestration: true, codeInspection: true, automaticExecution: 'allowlisted-and-permissioned' }, time: new Date().toISOString() });
});

// Automatically verify existing GitHub and Render credentials when the app opens.
// This does not create a connection or deploy anything; initial credentials must be
// configured once in the server's private Environment settings.
app.get('/api/integrations/status', rateLimit({windowMs:60_000,max:12,keyPrefix:'integration-status'}), async (_req,res)=>{
  const ghConfigured=Boolean(process.env.GITHUB_TOKEN&&process.env.GITHUB_OWNER&&process.env.GITHUB_REPO);
  const renderConfigured=Boolean(process.env.RENDER_API_KEY&&process.env.RENDER_SERVICE_ID);
  const result={github:{configured:ghConfigured,connected:false,status:'needs-setup',message:'يلزم إعداد صلاحيات GitHub مرة واحدة في إعدادات الخادم.'},render:{configured:renderConfigured,connected:false,status:'needs-setup',message:'يلزم إعداد مفتاح Render ومعرّف الخدمة مرة واحدة في إعدادات الخادم.'},checkedAt:new Date().toISOString()};
  if(ghConfigured){
    try{
      const r=await fetch(`https://api.github.com/repos/${encodeURIComponent(process.env.GITHUB_OWNER)}/${encodeURIComponent(process.env.GITHUB_REPO)}`,{headers:{Authorization:`Bearer ${process.env.GITHUB_TOKEN}`,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'Nova-Integration-Check'},signal:AbortSignal.timeout(10000)});
      result.github.connected=r.ok;result.github.status=r.ok?'connected':r.status===401||r.status===403?'auth-error':'unavailable';result.github.message=r.ok?'تم التحقق من الوصول إلى مستودع GitHub.':r.status===401||r.status===403?'رفض GitHub الرمز أو الصلاحيات. راجع إعدادات الخادم.':'تعذر الوصول إلى المستودع المحدد؛ تحقق من الاسم والصلاحيات.';
    }catch(e){result.github.status='network-error';result.github.message=e.name==='TimeoutError'?'انتهت مهلة فحص GitHub.':'تعذر الاتصال بـ GitHub من الخادم.';}
  }
  if(renderConfigured){
    try{
      const r=await fetch(`https://api.render.com/v1/services/${encodeURIComponent(process.env.RENDER_SERVICE_ID)}`,{headers:{Authorization:`Bearer ${process.env.RENDER_API_KEY}`,'Accept':'application/json'},signal:AbortSignal.timeout(10000)});
      result.render.connected=r.ok;result.render.status=r.ok?'connected':r.status===401||r.status===403?'auth-error':'unavailable';result.render.message=r.ok?'تم التحقق من الوصول إلى خدمة Render.':r.status===401||r.status===403?'رفض Render المفتاح أو الصلاحيات. راجع إعدادات الخادم.':'لم يتم العثور على خدمة Render المحددة أو تعذر الوصول إليها.';
    }catch(e){result.render.status='network-error';result.render.message=e.name==='TimeoutError'?'انتهت مهلة فحص Render.':'تعذر الاتصال بـ Render من الخادم.';}
  }
  recordAction('فحص اتصال GitHub وRender',result.github.connected&&result.render.connected?'connected':'checked',`GitHub: ${result.github.status}; Render: ${result.render.status}`);
  res.json(result);
});

// Explicit tool registry: Nova may only claim capabilities listed here as available.
app.get('/api/tools', (_req,res) => {
  const {provider,model}=configuredProvider();
  res.json({ tools:[
    {id:'ai_chat',name:'اكتشاف خدمات الذكاء الاصطناعي والتوجيه التلقائي',available:discoverProviders().length>0,mode:'multi-provider-cloud',detail:discoverProviders().length ? `${discoverProviders().length} خدمة مضبوطة؛ تبديل احتياطي تلقائي عند الفشل` : 'أضف مفاتيح الخدمات المدعومة إلى Environment على الخادم'},
    {id:'news_feed',name:'جلب أخبار الذكاء الاصطناعي',available:true,mode:'read-only',detail:'مصادر RSS عامة عبر الخادم'},
    {id:'project_inspection',name:'فحص ملفات المشروع',available:true,mode:'read-only',detail:'فحص ملفات JavaScript والإعدادات الموجودة فقط'},
    {id:'local_tasks',name:'إدارة المهام',available:true,mode:'device-local',detail:'تُنفذ داخل المتصفح على جهاز المستخدم'},
    {id:'github_render_deploy',name:'مزامنة GitHub وطلب نشر Render',available:Boolean(process.env.NOVA_CONTROL_TOKEN&&process.env.GITHUB_TOKEN&&process.env.GITHUB_OWNER&&process.env.GITHUB_REPO&&process.env.RENDER_API_KEY&&process.env.RENDER_SERVICE_ID),mode:'external-write',detail:'ينفذ تلقائيًا عند الدخول بعد إعداد رمز التحكم والصلاحيات؛ يرفع الملفات المحددة المتغيرة فقط ولا يكرر النشر إذا لم توجد تغييرات'}
  ], generatedAt:new Date().toISOString() });
});
app.get('/api/manager/logs', (_req,res)=>res.json({logs:auditLog.slice(0,30)}));
app.post('/api/manager/plan', rateLimit({windowMs:60_000,max:12,keyPrefix:'plan'}), async (req,res)=>{
  const goal=typeof req.body?.goal==='string'?req.body.goal.trim().slice(0,4000):'';
  const tasks=Array.isArray(req.body?.tasks)?req.body.tasks.slice(0,30).map(t=>({text:String(t?.text||'').slice(0,240),done:Boolean(t?.done)})):[];
  if(!goal)return res.status(400).json({error:'اكتب الهدف الذي تريد التخطيط له.'});
  const {provider,model}=configuredProvider();
  if(!provider)return res.status(503).json({error:'لا يمكن إعداد خطة ذكية قبل ضبط مفتاح AI على الخادم.',code:'AI_NOT_CONFIGURED'});
  const system='أنت Nova، المدير التنفيذي للمستخدم. ضع خطة عملية باللغة العربية وبخطوات مرقمة، مع ترتيب الأولويات والوقت التقريبي ومعايير نجاح قابلة للفحص. فرّق بوضوح بين (أ) ما تستطيع Nova فعله بالأدوات الموصولة فعلًا، (ب) ما يحتاج موافقة أو إعدادًا خارجيًا. لا تدّع تنفيذ أي خطوة. لا تطلب أسرارًا. أدوات Nova الحالية: محادثة AI إن كان المفتاح مضبوطًا، جلب أخبار RSS، فحص ملفات المشروع ووجود الإعدادات، وإدارة مهام محلية داخل المتصفح. ربط GitHub/Render متاح فقط عند ضبط كل الرموز والصلاحيات، ولا ينفذ إلا بأمر منفصل. أخرج خطة لا تتجاوز 8 خطوات.';
  const prompt='هدف المستخدم: '+goal+'\nالمهام الحالية (قد تكون فارغة):\n'+(tasks.length?tasks.map((t,i)=>`${i+1}. [${t.done?'مكتملة':'غير مكتملة'}] ${t.text}`).join('\n'):'لا توجد مهام مسجلة');
  try{
    const routed=await askAvailableProviders({system,messages:[{role:'user',content:prompt}],temperature:0.25,maxTokens:1800,timeout:45000});
    const plan=routed.reply;
    if(!plan)return res.status(502).json({error:'وصل رد فارغ عند إعداد الخطة.'});
    recordAction('تخطيط المدير','completed',goal.slice(0,100));
    res.json({plan,provider:routed.provider,model:routed.model,failedOver:routed.failedOver,time:new Date().toISOString(),execution:'planning-only'});
  }catch(e){recordAction('تخطيط المدير','failed',e.name||'network error');res.status(502).json({error:e.name==='TimeoutError'?'تأخر إعداد الخطة. حاول مرة أخرى.':'تعذر الاتصال بمزود الذكاء الاصطناعي لإعداد الخطة.'});}
});
app.post('/api/manager/inspect', rateLimit({windowMs:60_000,max:10,keyPrefix:'inspect'}), (_req,res)=>{
  const checks=[];
  const required=['server.js','package.json','public/index.html','public/sw.js','render.yaml'];
  for(const rel of required){const full=path.join(PROJECT_ROOT,rel);checks.push({name:rel,ok:fs.existsSync(full),detail:fs.existsSync(full)?'الملف موجود':'الملف مفقود'});}
  let pkg={};try{pkg=JSON.parse(fs.readFileSync(path.join(PROJECT_ROOT,'package.json'),'utf8'));checks.push({name:'package.json syntax',ok:true,detail:'JSON صالح'});}catch{checks.push({name:'package.json syntax',ok:false,detail:'صيغة JSON غير صالحة'});}
  for(const rel of ['server.js','public/sw.js']){const checked=spawnSync(process.execPath,['--check',path.join(PROJECT_ROOT,rel)],{encoding:'utf8',timeout:8000});checks.push({name:'Syntax: '+rel,ok:checked.status===0,detail:checked.status===0?'صياغة JavaScript سليمة':String(checked.stderr||checked.error?.message||'فشل الفحص').slice(0,180)});}
  try{const html=fs.readFileSync(path.join(PROJECT_ROOT,'public/index.html'),'utf8');const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];if(!scripts.length)throw new Error('لا يوجد سكربت واجهة');for(const match of scripts)new vm.Script(match[1]);checks.push({name:'Syntax: inline UI',ok:true,detail:'صياغة JavaScript للواجهة سليمة'});}catch(e){checks.push({name:'Syntax: inline UI',ok:false,detail:String(e.message||e).slice(0,180)});}
  const {provider,model}=configuredProvider();
  checks.push({name:'AI provider',ok:Boolean(provider),detail:provider?`${provider} · ${model}`:'لم يتم ضبط مفتاح مزود AI'});
  checks.push({name:'GitHub + Render',ok:Boolean(process.env.NOVA_CONTROL_TOKEN&&process.env.GITHUB_TOKEN&&process.env.GITHUB_OWNER&&process.env.GITHUB_REPO&&process.env.RENDER_API_KEY&&process.env.RENDER_SERVICE_ID),detail:'فحص وجود متغيرات الربط فقط؛ لم يتم اختبار صلاحيتها'});
  checks.push({name:'npm dependencies',ok:Boolean(pkg.dependencies&&pkg.dependencies.express),detail:'express معلن في package.json؛ يلزم npm install على الخادم'});
  const result={ok:checks.every(x=>x.ok),checks,warning:'الفحص يشمل صياغة JavaScript ووجود الإعدادات، لكنه لا يثبت صلاحية مفاتيح API أو اكتمال اتصال الخدمات الخارجية.'};
  recordAction('فحص المشروع',result.ok?'completed':'needs-attention',checks.filter(x=>!x.ok).map(x=>x.name).join(', ')||'تم فحص الملفات والإعدادات');
  res.json(result);
});

function cleanXml(s) {
  return String(s || '').replace(/<!\[CDATA\[|\]\]>/g, '').replace(/<[^>]*>/g, ' ')
    .replace(/&amp;/g, '&').replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/\s+/g, ' ').trim();
}
app.get('/api/news', async (_req, res) => {
  const feeds = [
    'https://techcrunch.com/category/artificial-intelligence/feed/',
    'https://www.technologyreview.com/topic/artificial-intelligence/feed/'
  ];
  try {
    const settled = await Promise.allSettled(feeds.map(async url => {
      const r = await fetch(url, { signal: AbortSignal.timeout(8000), headers: { 'User-Agent': 'NovaAssistant/2.0 (+RSS reader)' } });
      if (!r.ok) throw new Error('feed unavailable');
      const xml = await r.text();
      return [...xml.matchAll(/<item\b[\s\S]*?<\/item>/gi)].slice(0, 10).map(m => {
        const part = m[0];
        const pick = tag => cleanXml((part.match(new RegExp('<' + tag + '(?:\\s[^>]*)?>([\\s\\S]*?)<\\/' + tag + '>', 'i')) || [, ''])[1]);
        const link = cleanXml((part.match(/<link>([\s\S]*?)<\/link>/i) || [, ''])[1]);
        return { title: pick('title'), link, date: pick('pubDate'), source: new URL(url).hostname };
      }).filter(n => n.title && /^https:\/\//i.test(n.link));
    }));
    const news = settled.flatMap(x => x.status === 'fulfilled' ? x.value : []).slice(0, 15);
    res.setHeader('Cache-Control', 'public, max-age=600');
    recordAction('جلب الأخبار',news.length?'completed':'empty',`${news.length} خبر`);
    res.json({ news, updatedAt: new Date().toISOString(), note: news.length ? '' : 'لم تتوفر الأخبار من المصادر الآن. حاول لاحقًا.' });
  } catch (_e) { recordAction('جلب الأخبار','failed','تعذر الاتصال بمصادر RSS'); res.json({ news: [], updatedAt: new Date().toISOString(), note: 'تعذر جلب الأخبار حاليًا؛ تحقق من اتصال الخادم بالإنترنت.' }); }
});



// Self-link endpoints. Secrets are read only from server environment variables.
const LINK_FILES = [
  'README_AR_FULL.md', 'README_AR_START_HERE.md', 'server.js', 'package.json', 'render.yaml',
  '.env.example', 'public/index.html', 'public/manifest.webmanifest', 'public/sw.js', 'public/icon.svg'
];
function secretMatches(given, expected) {
  if (typeof given !== 'string' || typeof expected !== 'string' || !given || !expected) return false;
  const a = Buffer.from(given); const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
async function githubRequest(url, token, options={}) {
  return fetch(url, { ...options, signal: AbortSignal.timeout(15000), headers: {
    'Authorization': `Bearer ${token}`, 'Accept': 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'Nova-SelfLink',
    ...(options.headers || {})
  }});
}
app.get('/api/link/status', (_req, res) => {
  res.json({
    controlConfigured: Boolean(process.env.NOVA_CONTROL_TOKEN),
    githubConfigured: Boolean(process.env.GITHUB_TOKEN && process.env.GITHUB_OWNER && process.env.GITHUB_REPO),
    renderConfigured: Boolean(process.env.RENDER_API_KEY && process.env.RENDER_SERVICE_ID),
    instructions: 'للتنفيذ الذاتي، اضبط الأسرار في إعدادات Environment على الخادم فقط.'
  });
});
app.post('/api/link/execute', rateLimit({windowMs:60_000,max:3,keyPrefix:'link'}), async (req, res) => {
  if (!secretMatches(req.headers.authorization?.replace(/^Bearer\s+/i, ''), process.env.NOVA_CONTROL_TOKEN)) {
    return res.status(401).json({ ok:false, error:'رمز التحكم غير صحيح أو لم يُضبط على الخادم. لا تضع الأسرار في مستودع GitHub.' });
  }
  const missing = [];
  for (const [key, value] of Object.entries({
    GITHUB_TOKEN: process.env.GITHUB_TOKEN, GITHUB_OWNER: process.env.GITHUB_OWNER,
    GITHUB_REPO: process.env.GITHUB_REPO, RENDER_API_KEY: process.env.RENDER_API_KEY,
    RENDER_SERVICE_ID: process.env.RENDER_SERVICE_ID
  })) if (!value) missing.push(key);
  if (missing.length) return res.status(503).json({ ok:false, stage:'configuration', missing, error:'لم يكتمل الإعداد الأولي. أضف المتغيرات المذكورة في Environment على الخادم ثم أعد الأمر somr.' });
  const owner=process.env.GITHUB_OWNER.trim(), repo=process.env.GITHUB_REPO.trim();
  const token=process.env.GITHUB_TOKEN.trim(), branch=process.env.GITHUB_BRANCH?.trim();
  if (!/^[A-Za-z0-9_.-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(repo)) return res.status(400).json({ok:false,error:'اسم مالك المستودع أو المستودع غير صالح.'});
  const apiBase=`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
  try {
    const repoRes=await githubRequest(apiBase,token);
    if(!repoRes.ok) return res.status(502).json({ok:false,stage:'github',error:repoRes.status===401||repoRes.status===403?'تعذر التفويض إلى GitHub؛ تحقق من صلاحيات الرمز.':'تعذر العثور على المستودع المحدد أو الوصول إليه.'});
    const repoInfo=await repoRes.json();
    const targetBranch=branch || repoInfo.default_branch || undefined;
    const pushed=[], skipped=[];
    for(const rel of LINK_FILES){
      const contentPath=rel.split('/').map(encodeURIComponent).join('/');
      let existing=await githubRequest(`${apiBase}/contents/${contentPath}${targetBranch?'?ref='+encodeURIComponent(targetBranch):''}`,token);
      const local=fs.readFileSync(path.join(PROJECT_ROOT,rel));
      let body={message:`Nova self-link: sync ${rel}`,content:local.toString('base64')};
      if(existing.ok){
        const old=await existing.json();
        const oldText=Buffer.from(String(old.content||'').replace(/\n/g,''),'base64');
        if(oldText.equals(local)){skipped.push(rel);continue;}
        // Update only the explicit allowlist above, using GitHub's SHA precondition.
        body.sha=old.sha;
      } else if(existing.status!==404) {
        return res.status(502).json({ok:false,stage:'github',error:`تعذر فحص الملف ${rel} في GitHub.`,pushed,skipped});
      }
      if(targetBranch) body.branch=targetBranch;
      const put=await githubRequest(`${apiBase}/contents/${contentPath}`,token,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      if(!put.ok){const err=await put.json().catch(()=>({}));return res.status(502).json({ok:false,stage:'github',error:`تعذر رفع ${rel}. تحقق من صلاحية Contents: write في رمز GitHub.`,detail:String(err.message||'').slice(0,160),pushed,skipped});}
      pushed.push(rel);
    }
    const serviceId=process.env.RENDER_SERVICE_ID.trim();
    // A visit with no repository changes must not cause an unnecessary deployment.
    if (pushed.length === 0) {
      recordAction('مزامنة GitHub وRender','no-changes',`${owner}/${repo}`);
      return res.json({ok:true,stage:'no-changes',owner,repo,branch:targetBranch||repoInfo.default_branch||'default branch',pushed,skipped,deployId:null,message:'تمت مزامنة الفحص: كل الملفات المحددة مطابقة بالفعل في GitHub، لذلك لم يُطلب نشر جديد على Render.'});
    }
    const renderCheck=await fetch(`https://api.render.com/v1/services/${encodeURIComponent(serviceId)}`,{headers:{Authorization:`Bearer ${process.env.RENDER_API_KEY.trim()}`,Accept:'application/json'},signal:AbortSignal.timeout(15000)});
    if(!renderCheck.ok) return res.status(502).json({ok:false,stage:'render-check',pushed,skipped,error:'تم رفع الملفات إلى GitHub، لكن تعذر التحقق من خدمة Render. راجع RENDER_API_KEY وRENDER_SERVICE_ID.'});
    const deploy=await fetch(`https://api.render.com/v1/services/${encodeURIComponent(serviceId)}/deploys`,{method:'POST',headers:{Authorization:`Bearer ${process.env.RENDER_API_KEY.trim()}`,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({clearCache:'do_not_clear'}),signal:AbortSignal.timeout(15000)});
    if(!deploy.ok) return res.status(502).json({ok:false,stage:'render-deploy',pushed,skipped,error:'رُفعت الملفات إلى GitHub، لكن Render لم يقبل بدء النشر. تحقق من ربط الخدمة بالمستودع وصلاحيات مفتاح Render.'});
    const deployInfo=await deploy.json().catch(()=>({}));
    recordAction('مزامنة GitHub وطلب نشر Render','requested',`${owner}/${repo}`);
    return res.json({ok:true,stage:'deploy-requested',owner,repo,branch:targetBranch||repoInfo.default_branch||'default branch',pushed,skipped,deployId:deployInfo.id||deployInfo.deploy?.id||null,message:'تم رفع الملفات المتغيرة إلى GitHub وطلب بدء نشر Render. الطلب أُرسل، لكن يجب فحص حالة النشر للتأكد من اكتماله.'});
  } catch(e) {
    console.error('Self-link failed:',e.name);
    return res.status(502).json({ok:false,stage:'network',error:'تعذر إكمال الربط بسبب خطأ اتصال. لم يُكشف أي مفتاح. تحقق من اتصال الخادم ثم أعد الأمر.'});
  }
});

app.post('/api/chat', rateLimit({windowMs:60_000,max:20,keyPrefix:'chat'}), async (req, res) => {
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-10).filter(m => m && ['user','assistant'].includes(m.role) && typeof m.content === 'string').map(m => ({ role: m.role, content: m.content.slice(0, 4000) })) : [];
  if (!message) return res.status(400).json({ error: 'اكتب أمرًا أو سؤالًا أولًا.' });
  if (message.length > 8000) return res.status(413).json({ error: 'الرسالة طويلة جدًا؛ اختصرها ثم حاول مجددًا.' });
  const system = `أنت Nova، مدير شخصي ذكي يتحدث العربية ويعمل بمنهج تنفيذي. إذا بدأ نص طلب المستخدم بالبادئة السرية somr أو «سومر»، فاعتبره تفويضًا لمحاولة تنفيذ المطلوب مباشرةً ضمن الأدوات والصلاحيات المتاحة. إذا لم يبدأ بها، يمكنك تقدير الأنسب. هذه البادئة لا تمنح صلاحيات تقنية غير موجودة ولا تلغي متطلبات الأمان. نفّذ فقط ما تتيحه الأدوات الموصولة فعلًا. لا تدّعِ أنك دخلت حسابًا أو عدّلت مستودعًا أو نشرت خدمة أو تحكمت بالهاتف إذا لم يحدث ذلك. إذا لم تتوفر أداة لتنفيذ جزء، اشرح ما الذي يحتاج إلى إعداد واقترح أقصر مسار عملي. لا تطلب مفاتيح API أو كلمات مرور داخل الدردشة، ولا تكشف الأسرار. اجعل الرد عمليًا ومناسبًا لمستخدم يعتمد على هاتف Android فقط. لا تعرض البادئة السرية في الواجهة.`;
  if (!discoverProviders().length) return res.status(503).json({ error: 'لم تُفعّل المحادثة الذكية بعد. أضف مفتاحًا واحدًا أو أكثر للخدمات المدعومة في Environment على الخادم، ولا تضع المفاتيح في الدردشة أو الواجهة.', code: 'AI_NOT_CONFIGURED' });
  try {
    const routed=await askAvailableProviders({system,messages:[...history,{role:'user',content:message}],temperature:0.35,maxTokens:2048,timeout:45000});
    recordAction('محادثة AI','completed',`${routed.provider}; failover=${routed.failedOver}`);
    res.json({ reply:routed.reply, model:routed.model, provider:routed.provider, failedOver:routed.failedOver, time:new Date().toISOString() });
  } catch (e) {
    recordAction('محادثة AI','failed',e.name || 'network error');
    console.error('AI request failed:', e.name);
    res.status(502).json({ error: e.name === 'TimeoutError' ? 'استغرق الرد وقتًا طويلًا. حاول مرة أخرى.' : 'تعذر الاتصال بمزود الذكاء الاصطناعي. تحقق من إعدادات الخادم والإنترنت.' });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof SyntaxError && 'body' in err) return res.status(400).json({ error: 'صيغة الطلب غير صحيحة.' });
  console.error('Server error:', err.message);
  res.status(500).json({ error: 'حدث خطأ داخلي. حاول مرة أخرى.' });
});
const port = process.env.PORT || 3000;
app.listen(port, '0.0.0.0', () => console.log(`Nova listening on ${port}`));
