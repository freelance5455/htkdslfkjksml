
require("dotenv").config();

const express = require("express");
const path = require("path");

const app = express();

app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

function validTikTokUrl(value) {
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();

    return url.protocol === "https:" &&
      (host === "tiktok.com" || host.endsWith(".tiktok.com"));
  } catch {
    return false;
  }
}

app.post("/api/download", async (req, res) => {
  try {
    const { url } = req.body || {};

    if (!validTikTokUrl(url)) {
      return res.status(400).json({
        error: "Link TikTok tidak valid."
      });
    }

    if (!process.env.API_KEY || !process.env.API_ENDPOINT) {
      return res.status(503).json({
        error: "API belum dikonfigurasi."
      });
    }

    const response = await fetch(process.env.API_ENDPOINT, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        service: "tiktok",
        url: url,
        max_results: 1
      }),
      signal: AbortSignal.timeout(130000)
    });

    const data = await response.json();

    if (!response.ok || !data.ok) {
      return res.status(502).json({
        error: data.message ||
          data.code ||
          "Gagal mengambil video."
      });
    }

    const video = data.items?.find(
      item => item.type === "video"
    );

    if (!video || !video.url) {
      return res.status(404).json({
        error: "Video tidak ditemukan atau tidak tersedia."
      });
    }

    const mediaUrl = new URL(video.url);

    if (mediaUrl.protocol !== "https:") {
      return res.status(502).json({
        error: "URL video tidak aman."
      });
    }

    res.json({
      download_url: mediaUrl.href,
      preview_url: mediaUrl.href,
      author: data.metadata?.author || "TikTok Creator",
      title: data.metadata?.title || "TikTok Video",
      credits_used: data.credits_used
    });

  } catch (error) {
    console.error(error.message);

    res.status(500).json({
      error: "Server bermasalah atau API mengalami timeout."
    });
  }
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, "0.0.0.0", () => {
  console.log(`TikSave aktif di port ${PORT}`);
});
