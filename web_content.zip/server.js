require("dotenv").config();
const express = require("express");
const path = require("path");
const OpenAI = require("openai");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({limit:"32kb"}));
// Allow the packaged APK/WebView to call the backend.
app.use((req,res,next)=>{
  res.setHeader("Access-Control-Allow-Origin","*");
  res.setHeader("Access-Control-Allow-Headers","Content-Type, x-admin-password");
  res.setHeader("Access-Control-Allow-Methods","GET,POST,DELETE,OPTIONS");
  if(req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.use(express.static(path.join(__dirname,"public")));

const DATA_FILE = path.join(__dirname, "studyhub-data.json");
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-me-now";
function loadData(){
  try { return JSON.parse(fs.readFileSync(DATA_FILE,"utf8")); }
  catch { return {notes:[], videos:[], quizzes:[]}; }
}
function saveData(data){ fs.writeFileSync(DATA_FILE, JSON.stringify(data,null,2)); }
function adminOK(req){ return req.headers["x-admin-password"] === ADMIN_PASSWORD; }
if(!fs.existsSync(DATA_FILE)) saveData({notes:[], videos:[], quizzes:[]});

app.get("/api/content",(req,res)=>res.json(loadData()));
app.post("/api/admin/login",(req,res)=>{
  if(req.body?.password === ADMIN_PASSWORD) return res.json({ok:true});
  res.status(401).json({error:"Invalid admin password."});
});
app.post("/api/admin/content",(req,res)=>{
  if(!adminOK(req)) return res.status(401).json({error:"Admin authorization required."});
  const {type,title,description,url,subject,content,questions} = req.body || {};
  if(!["notes","videos","quizzes"].includes(type) || !String(title||"").trim()) return res.status(400).json({error:"Type and title are required."});
  const data=loadData(); const item={id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),title:String(title).trim(),description:String(description||"").trim(),subject:String(subject||"").trim(),url:String(url||"").trim(),content:String(content||"").trim(),questions:Array.isArray(questions)?questions:[],createdAt:new Date().toISOString()};
  data[type].push(item); saveData(data); res.json({ok:true,item});
});
app.delete("/api/admin/content/:type/:id",(req,res)=>{
  if(!adminOK(req)) return res.status(401).json({error:"Admin authorization required."});
  const data=loadData(), type=req.params.type; if(!data[type]) return res.status(400).json({error:"Invalid type."});
  data[type]=data[type].filter(x=>x.id!==req.params.id); saveData(data); res.json({ok:true});
});

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({apiKey: process.env.OPENAI_API_KEY})
  : null;

app.post("/api/ask", async (req,res)=>{
  try{
    const question = typeof req.body?.question === "string"
      ? req.body.question.trim()
      : "";

    if(!question) return res.status(400).json({error:"Question is required."});
    if(question.length > 4000)
      return res.status(400).json({error:"Question is too long."});

    if(!client)
      return res.status(500).json({error:"OPENAI_API_KEY is not configured on the server."});

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-mini",
      instructions:
        "You are StudyHub's educational assistant. Answer clearly and safely for school and competitive-exam students. " +
        "Prefer Hindi when the question is Hindi/Hinglish, otherwise answer in the user's language. " +
        "Explain concepts step by step when useful. Do not claim a generated question is an authentic PYQ unless verified. " +
        "Keep answers age-appropriate.",
      input: question
    });

    res.json({answer: response.output_text || "No answer received."});
  }catch(err){
    console.error(err);
    res.status(500).json({error:"AI request failed. Check your API key, model access, and server logs."});
  }
});

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));

app.get("/*splat",(req,res)=>{
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`StudyHub running at http://localhost:${PORT}`));
