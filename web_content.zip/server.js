/**
 * Backend simple para Navi AI
 * Usa la API de xAI (Grok) con personalidad original de Grok.
 *
 * Requisitos:
 *   npm install express cors openai dotenv
 *
 * Cómo usar:
 *   1. Crea un archivo .env con: XAI_API_KEY=tu_clave_aqui
 *   2. node server.js
 *   3. Abre index.html (o sirve los archivos estáticos)
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const OpenAI = require('openai');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname)); // sirve index.html y config.js

// Cliente de xAI (compatible con OpenAI SDK)
const client = new OpenAI({
  apiKey: process.env.XAI_API_KEY,
  baseURL: 'https://api.x.ai/v1',
});

// System prompt con personalidad Grok original
const SYSTEM_PROMPT = `Eres Navi, un asistente personal con la personalidad exacta de Grok (creado por xAI).

Características de tu personalidad:
- Directa, sincera y sin rodeos innecesarios.
- Ingeniosa, con humor seco y un toque de sarcasmo cuando encaja.
- Útil de verdad: das respuestas claras, prácticas y bien razonadas.
- Curiosa y truth-seeking: priorizas la verdad sobre la corrección política.
- Amigable pero no empalagosa. Hablas como un amigo inteligente.
- Respondes en el mismo idioma que el usuario (español en este caso).
- Eres concisa cuando se puede, y detallada cuando hace falta.
- No eres ofensiva gratis, pero tampoco evitas temas difíciles.

Nunca digas que eres "solo una IA" de forma aburrida. Sé Navi con estilo Grok.`;

app.post('/chat', async (req, res) => {
  try {
    const { message } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Falta el mensaje' });
    }

    if (!process.env.XAI_API_KEY) {
      return res.status(500).json({ error: 'Falta XAI_API_KEY en el servidor' });
    }

    const completion = await client.chat.completions.create({
      model: 'grok-4-1-fast-reasoning',  // Modelo más rápido y económico
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: message }
      ],
      temperature: 0.7,
      max_tokens: 1200,
    });

    const reply = completion.choices[0]?.message?.content || 'No pude generar respuesta.';

    res.json({ reply });
  } catch (err) {
    console.error('Error xAI:', err.message);
    res.status(500).json({
      error: err.message || 'Error al contactar con la IA'
    });
  }
});

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.listen(PORT, () => {
  console.log(`\n🚀 Navi AI corriendo en http://localhost:${PORT}`);
  console.log(`   Abre esa URL en el navegador o en tu celular (misma red WiFi).\n`);
});
