/**
 * RAYNOX AI — Production Full-Stack Backend Server (server.js)
 *
 * Features:
 * 1. Serves the static Raynox AI frontend (index.html, style.css, script.js, manifest.json, icon.png).
 * 2. Reads GEMINI_API_KEY strictly from server-side environment variables (process.env.GEMINI_API_KEY or .env).
 * 3. Provides real health check endpoint: GET /api/health (verifies key & live Google Gemini connectivity).
 * 4. Provides real AI chat endpoint: POST /api/chat (supports multi-turn conversation history & model fallback).
 * 5. Provides real SSE streaming chat endpoint: POST /api/chat/stream.
 * 6. Full CORS support for standalone WebViews / HTML-to-APK apps, input validation, and IP rate limiting.
 */

const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { URL } = require("node:url");

// Load .env file into process.env if present
function loadDotEnv() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  try {
    const content = fs.readFileSync(envPath, "utf8");
    for (const rawLine of content.split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith("#")) continue;
      const eqIdx = line.indexOf("=");
      if (eqIdx === -1) continue;
      const key = line.slice(0, eqIdx).trim();
      let val = line.slice(eqIdx + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      if (key && process.env[key] === undefined) {
        process.env[key] = val;
      }
    }
  } catch (err) {
    console.warn("[Raynox Backend] Warning reading .env:", err.message);
  }
}

loadDotEnv();

const PORT = parseInt(process.env.PORT || "3000", 10);
const DEFAULT_MODEL = process.env.GEMINI_MODEL || "gemini-3.5-flash";
const FALLBACK_MODEL = "gemini-3.5-flash-lite";
const GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models";
const MAX_BODY_BYTES = 2 * 1024 * 1024; // 2 MB limit
const MAX_MESSAGE_CHARS = 8000;
const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX_REQUESTS = 40;

// In-memory IP rate limiter
const rateLimitMap = new Map();

function checkRateLimit(ip) {
  const now = Date.now();
  const record = rateLimitMap.get(ip);
  if (!record || now - record.windowStart > RATE_LIMIT_WINDOW_MS) {
    rateLimitMap.set(ip, { windowStart: now, count: 1 });
    return true;
  }
  if (record.count >= RATE_LIMIT_MAX_REQUESTS) {
    return false;
  }
  record.count += 1;
  return true;
}

function getServerApiKey() {
  const key = (process.env.GEMINI_API_KEY || "").trim();
  if (!key || key === "MY_GEMINI_API_KEY" || key === "YOUR_GEMINI_API_KEY") {
    return "";
  }
  return key;
}

function setCorsHeaders(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, Accept");
  res.setHeader("Access-Control-Max-Age", "86400");
}

function sendJson(res, statusCode, payload) {
  setCorsHeaders(res);
  res.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

function verifyBearerAuth(req) {
  const requiredToken = (process.env.BACKEND_AUTH_TOKEN || "").trim();
  if (!requiredToken) return { ok: true };
  const authHeader = req.headers["authorization"] || "";
  if (!authHeader.startsWith("Bearer ")) {
    return { ok: false, error: "Authorization Bearer token is required by this server." };
  }
  const provided = authHeader.slice(7).trim();
  if (provided !== requiredToken) {
    return { ok: false, error: "Invalid Bearer token." };
  }
  return { ok: true };
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    let bytes = 0;
    req.on("data", (chunk) => {
      bytes += chunk.length;
      if (bytes > MAX_BODY_BYTES) {
        reject(new Error("Request payload too large (exceeds 2MB limit)."));
        req.destroy();
        return;
      }
      body += chunk.toString("utf8");
    });
    req.on("end", () => {
      if (!body.trim()) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch (e) {
        reject(new Error("Invalid JSON request body."));
      }
    });
    req.on("error", reject);
  });
}

function getIstTemporalHeader() {
  const now = new Date();
  const optionsTime = { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false };
  const optionsDate = { timeZone: "Asia/Kolkata", weekday: "long", day: "2-digit", month: "long", year: "numeric" };
  const timeStr = new Intl.DateTimeFormat("en-IN", optionsTime).format(now);
  const dateStr = new Intl.DateTimeFormat("en-IN", optionsDate).format(now);

  return `[CURRENT TEMPORAL CONTEXT - LIVE ASIA/KOLKATA (IST)]
• Current Date: ${dateStr}
• Current Time: ${timeStr} IST
• Time Zone: Asia/Kolkata (UTC+05:30)
• Always answer time & date questions accurately using this live context.`;
}

function buildSystemInstruction(userName, customInstructions) {
  const lines = [
    "You are RAYNOX AI, a helpful, intelligent, friendly, and professional personal AI assistant.",
    "Your identity is RAYNOX AI. Respond naturally and confidently, with clear and useful explanations.",
    "Never unnecessarily mention internal model providers, model names, API vendors, backend infrastructure, or implementation details.",
    "If asked who you are, introduce yourself as RAYNOX AI.",
    "If asked which AI provider or model powers you, answer truthfully without pretending that your underlying technology is something else.",
    "Never claim to have capabilities, permissions, live information, or device access that you do not actually possess.",
    "Answer the user's actual question directly. Do not insert irrelevant branding or repetitive introductions into every response.",
    "",
    getIstTemporalHeader(),
    "",
    "Guidelines:",
    "- Fluently respond in Hindi, Hinglish, or English matching the user's language and tone.",
    "- For date/calendar questions (Aaj, Kal, Parson), provide the exact date and day from the temporal header above.",
    "- Format answers cleanly with Markdown headings, bullet points, and code blocks when helpful."
  ];
  if (userName && typeof userName === "string" && userName.trim()) {
    lines.push(`- User's Name: ${userName.trim()}`);
  }
  if (customInstructions && typeof customInstructions === "string" && customInstructions.trim()) {
    lines.push(`- User Custom Preferences: ${customInstructions.trim()}`);
  }
  return { parts: [{ text: lines.join("\n") }] };
}

function buildGeminiContents(history, message, attachment) {
  const contents = [];
  if (Array.isArray(history)) {
    const recent = history.slice(-20);
    for (const item of recent) {
      if (!item || typeof item.content !== "string" || !item.content.trim()) continue;
      if (item.isError) continue;
      const role = item.role === "user" ? "user" : "model";
      contents.push({
        role,
        parts: [{ text: item.content.trim().slice(0, MAX_MESSAGE_CHARS) }]
      });
    }
  }

  const userParts = [];
  if (attachment && typeof attachment === "object" && attachment.data && attachment.mimeType) {
    userParts.push({
      inlineData: {
        mimeType: String(attachment.mimeType),
        data: String(attachment.data)
      }
    });
  }
  if (message && typeof message === "string" && message.trim()) {
    userParts.push({ text: message.trim().slice(0, MAX_MESSAGE_CHARS) });
  }

  if (userParts.length > 0) {
    const last = contents[contents.length - 1];
    // Avoid duplicating the user message if the frontend already appended it to history
    if (
      !last ||
      last.role !== "user" ||
      last.parts?.[0]?.text !== (message || "").trim() ||
      userParts.length > 1
    ) {
      contents.push({ role: "user", parts: userParts });
    }
  }

  return contents;
}

// --- GET /api/health ---
async function handleHealthCheck(req, res, parsedUrl) {
  const auth = verifyBearerAuth(req);
  if (!auth.ok) {
    return sendJson(res, 401, { ok: false, status: "not_connected", error: auth.error });
  }

  const apiKey = getServerApiKey();
  if (!apiKey) {
    return sendJson(res, 503, {
      ok: false,
      status: "not_connected",
      error: "GEMINI_API_KEY is not configured on the backend server. Set GEMINI_API_KEY in .env or server environment variables."
    });
  }

  const model = parsedUrl.searchParams.get("model") || DEFAULT_MODEL;
  const startMs = Date.now();

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    const verifyUrl = `${GEMINI_BASE_URL}/${encodeURIComponent(model)}?key=${encodeURIComponent(apiKey)}`;
    const response = await fetch(verifyUrl, {
      method: "GET",
      signal: controller.signal
    });
    clearTimeout(timeout);

    const latencyMs = Date.now() - startMs;

    if (!response.ok) {
      let errDetail = `HTTP ${response.status}`;
      try {
        const errJson = await response.json();
        if (errJson?.error?.message) errDetail = errJson.error.message;
      } catch (_) {}

      return sendJson(res, 502, {
        ok: false,
        status: "not_connected",
        error: `Gemini API verification failed: ${errDetail}`,
        latencyMs
      });
    }

    return sendJson(res, 200, {
      ok: true,
      status: "connected",
      provider: "Google Gemini",
      model,
      latencyMs,
      authRequired: Boolean((process.env.BACKEND_AUTH_TOKEN || "").trim()),
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    const isTimeout = err.name === "AbortError";
    return sendJson(res, 504, {
      ok: false,
      status: "not_connected",
      error: isTimeout
        ? "Timed out while verifying connection to Google Gemini API."
        : `Backend could not reach Google Gemini API: ${err.message}`
    });
  }
}

// --- POST /api/chat ---
async function handleChat(req, res) {
  const auth = verifyBearerAuth(req);
  if (!auth.ok) {
    return sendJson(res, 401, { ok: false, error: auth.error });
  }

  const apiKey = getServerApiKey();
  if (!apiKey) {
    return sendJson(res, 503, {
      ok: false,
      error: "Backend GEMINI_API_KEY is missing. Please configure GEMINI_API_KEY on the server."
    });
  }

  let body;
  try {
    body = await readJsonBody(req);
  } catch (err) {
    return sendJson(res, 400, { ok: false, error: err.message });
  }

  const message = typeof body.message === "string" ? body.message.trim() : "";
  const history = Array.isArray(body.history) ? body.history : [];
  const attachment = body.attachment || null;

  if (!message && !attachment) {
    return sendJson(res, 400, { ok: false, error: "Message cannot be empty." });
  }
  if (message.length > MAX_MESSAGE_CHARS) {
    return sendJson(res, 400, {
      ok: false,
      error: `Message is too long (${message.length} chars). Maximum allowed is ${MAX_MESSAGE_CHARS} characters.`
    });
  }

  const contents = buildGeminiContents(history, message, attachment);
  if (contents.length === 0) {
    return sendJson(res, 400, { ok: false, error: "No valid conversation content provided." });
  }

  const requestedModel = typeof body.model === "string" && body.model.trim() ? body.model.trim() : DEFAULT_MODEL;
  const modelsToTry = requestedModel === FALLBACK_MODEL
    ? [FALLBACK_MODEL, DEFAULT_MODEL]
    : [requestedModel, FALLBACK_MODEL];

  const geminiPayload = {
    contents,
    systemInstruction: buildSystemInstruction(body.userName, body.customInstructions),
    generationConfig: {
      temperature: 0.7,
      topP: 0.95,
      topK: 40
    }
  };

  let lastError = "AI service failed to generate a response.";
  let lastStatus = 502;

  for (const activeModel of modelsToTry) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 55000);

      const endpoint = `${GEMINI_BASE_URL}/${encodeURIComponent(activeModel)}:generateContent?key=${encodeURIComponent(apiKey)}`;
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(geminiPayload),
        signal: controller.signal
      });
      clearTimeout(timeout);

      if (!response.ok) {
        lastStatus = response.status;
        try {
          const errData = await response.json();
          lastError = errData?.error?.message || `Gemini API returned HTTP ${response.status}`;
        } catch (_) {
          lastError = `Gemini API returned HTTP ${response.status}`;
        }
        continue; // Try fallback model
      }

      const data = await response.json();
      const replyText = (data?.candidates?.[0]?.content?.parts || [])
        .map((p) => p.text || "")
        .join("")
        .trim();

      if (replyText) {
        return sendJson(res, 200, {
          ok: true,
          reply: replyText,
          model: activeModel
        });
      } else {
        lastError = "AI returned an empty response.";
      }
    } catch (err) {
      lastError = err.name === "AbortError"
        ? "AI request timed out on the server."
        : `Network error calling AI provider: ${err.message}`;
    }
  }

  return sendJson(res, lastStatus >= 400 && lastStatus < 600 ? lastStatus : 502, {
    ok: false,
    error: lastError
  });
}

// --- POST /api/chat/stream (Server-Sent Events) ---
async function handleChatStream(req, res) {
  const auth = verifyBearerAuth(req);
  if (!auth.ok) {
    return sendJson(res, 401, { ok: false, error: auth.error });
  }

  const apiKey = getServerApiKey();
  if (!apiKey) {
    return sendJson(res, 503, {
      ok: false,
      error: "Backend GEMINI_API_KEY is missing. Please configure GEMINI_API_KEY on the server."
    });
  }

  let body;
  try {
    body = await readJsonBody(req);
  } catch (err) {
    return sendJson(res, 400, { ok: false, error: err.message });
  }

  const message = typeof body.message === "string" ? body.message.trim() : "";
  const history = Array.isArray(body.history) ? body.history : [];
  const attachment = body.attachment || null;

  if (!message && !attachment) {
    return sendJson(res, 400, { ok: false, error: "Message cannot be empty." });
  }

  const contents = buildGeminiContents(history, message, attachment);
  const requestedModel = typeof body.model === "string" && body.model.trim() ? body.model.trim() : DEFAULT_MODEL;
  const modelsToTry = requestedModel === FALLBACK_MODEL
    ? [FALLBACK_MODEL, DEFAULT_MODEL]
    : [requestedModel, FALLBACK_MODEL];

  const geminiPayload = {
    contents,
    systemInstruction: buildSystemInstruction(body.userName, body.customInstructions),
    generationConfig: {
      temperature: 0.7,
      topP: 0.95,
      topK: 40
    }
  };

  for (const activeModel of modelsToTry) {
    try {
      const endpoint = `${GEMINI_BASE_URL}/${encodeURIComponent(activeModel)}:streamGenerateContent?alt=sse&key=${encodeURIComponent(apiKey)}`;
      const upstream = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(geminiPayload)
      });

      if (!upstream.ok) {
        if (activeModel !== modelsToTry[modelsToTry.length - 1]) continue;
        let errMsg = `Gemini API returned HTTP ${upstream.status}`;
        try {
          const errJson = await upstream.json();
          if (errJson?.error?.message) errMsg = errJson.error.message;
        } catch (_) {}
        return sendJson(res, upstream.status, { ok: false, error: errMsg });
      }

      setCorsHeaders(res);
      res.writeHead(200, {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        "Connection": "keep-alive"
      });

      const reader = upstream.body.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(Buffer.from(value));
      }
      res.write("data: [DONE]\n\n");
      res.end();
      return;
    } catch (err) {
      if (activeModel === modelsToTry[modelsToTry.length - 1]) {
        if (!res.headersSent) {
          return sendJson(res, 502, { ok: false, error: `Streaming error: ${err.message}` });
        }
        res.end();
        return;
      }
    }
  }
}

// --- Static File Server ---
const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".zip": "application/zip",
  ".md": "text/markdown; charset=utf-8"
};

function serveStaticFile(req, res, pathname) {
  let safePath = pathname === "/" ? "/index.html" : pathname;
  safePath = path.normalize(safePath).replace(/^(\.\.(\/|\\|$))+/, "");
  const fullPath = path.join(__dirname, safePath);

  // Prevent serving hidden files like .env
  const baseName = path.basename(fullPath);
  if (baseName.startsWith(".")) {
    return sendJson(res, 403, { ok: false, error: "Forbidden" });
  }

  if (!fs.existsSync(fullPath) || fs.statSync(fullPath).isDirectory()) {
    return sendJson(res, 404, { ok: false, error: `Not found: ${pathname}` });
  }

  const ext = path.extname(fullPath).toLowerCase();
  const contentType = MIME_TYPES[ext] || "application/octet-stream";
  setCorsHeaders(res);
  res.writeHead(200, { "Content-Type": contentType });
  fs.createReadStream(fullPath).pipe(res);
}

// --- Main HTTP Request Handler (Supports Node HTTP Server & Serverless Platforms) ---
async function requestHandler(req, res) {
  try {
    setCorsHeaders(res);

    if (req.method === "OPTIONS") {
      res.writeHead(204);
      res.end();
      return;
    }

    const clientIp = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "unknown";
    const parsedUrl = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
    const pathname = parsedUrl.pathname;

    if (pathname.startsWith("/api/") || pathname === "/health") {
      if (!checkRateLimit(clientIp)) {
        return sendJson(res, 429, {
          ok: false,
          error: "Rate limit exceeded (max 40 requests/minute). Please wait a moment and try again."
        });
      }
    }

    if ((pathname === "/api/health" || pathname === "/health") && req.method === "GET") {
      return await handleHealthCheck(req, res, parsedUrl);
    }

    if (pathname === "/api/chat" && req.method === "POST") {
      return await handleChat(req, res);
    }

    if (pathname === "/api/chat/stream" && req.method === "POST") {
      return await handleChatStream(req, res);
    }

    if (req.method === "GET" || req.method === "HEAD") {
      return serveStaticFile(req, res, pathname);
    }

    return sendJson(res, 405, { ok: false, error: `Method ${req.method} not allowed on ${pathname}` });
  } catch (err) {
    console.error("[Raynox Backend] Unhandled error:", err);
    if (!res.headersSent) {
      sendJson(res, 500, { ok: false, error: "Internal server error." });
    }
  }
}

const server = http.createServer(requestHandler);

if (require.main === module) {
  let activePort = parseInt(process.env.RAYNOX_PORT || process.env.PORT || "3000", 10);
  server.on("error", (err) => {
    if (err.code === "EADDRINUSE" && activePort !== 3000) {
      console.warn(`[Raynox Backend] Port ${activePort} is in use, falling back to port 3000...`);
      activePort = 3000;
      server.listen(activePort, "0.0.0.0");
    } else {
      console.error("[Raynox Backend] Server error:", err.message);
    }
  });
  server.listen(activePort, "0.0.0.0", () => {
    const hasKey = Boolean(getServerApiKey());
    console.log("====================================================");
    console.log(`RAYNOX AI Backend Server running on http://localhost:${activePort}`);
    console.log(`Health Check : http://localhost:${activePort}/api/health`);
    console.log(`Chat API     : http://localhost:${activePort}/api/chat`);
    console.log(`GEMINI_API_KEY configured: ${hasKey ? "YES (Ready)" : "NO (Set GEMINI_API_KEY in .env)"}`);
    console.log("====================================================");
  });
}

module.exports = requestHandler;
module.exports.server = server;

