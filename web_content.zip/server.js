// AlarmSimulator Ukraine — сервер для тестирования.
// Перед запуском измените ADMIN_TOKEN на свой секретный токен.
// Не используйте этот демонстрационный сервер как production-сервис без HTTPS,
// постоянного хранилища, ограничений доступа и дополнительной защиты.
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = Number(process.env.PORT || 8787);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'CHANGE_ME_AlarmSim_2026';
const ROOT = __dirname;
let active = [];
let history = [];
let updatedAt = new Date().toISOString();
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8'};
function send(res, status, data, type='application/json; charset=utf-8') {res.writeHead(status, {'Content-Type':type,'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Cache-Control':'no-store'});res.end(type.startsWith('application/json')?JSON.stringify(data):data);}
function readBody(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>100000)reject(new Error('Body too large'));});req.on('end',()=>{try{resolve(s?JSON.parse(s):{});}catch(e){reject(new Error('Invalid JSON'));}});});}
function authorized(req){return req.headers.authorization === 'Bearer '+ADMIN_TOKEN && ADMIN_TOKEN !== 'CHANGE_ME_AlarmSim_2026';}
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS'){send(res,204,{});return;}
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET' && url.pathname==='/api/state'){send(res,200,{active,history:history.slice(-50).reverse(),updatedAt});return;}
 if(req.method==='POST' && url.pathname.startsWith('/api/admin/')){
   if(!authorized(req)){send(res,401,{error:'Неверный токен или замените токен по умолчанию в server.js'});return;}
   try{
    const body=await readBody(req);
    if(url.pathname==='/api/admin/login'){send(res,200,{ok:true});return;}
    if(url.pathname==='/api/admin/event'){
      const title=String(body.title||'').trim().slice(0,100);if(!title){send(res,400,{error:'Не указано название события'});return;}
      const existing=active.find(e=>e.title===title);
      if(existing){active=active.filter(e=>e.title!==title);history.push({title,active:false,time:new Date().toLocaleString('uk-UA')});}
      else {const e={title,time:new Date().toLocaleString('uk-UA')};active.push(e);history.push({title,active:true,time:e.time});}
      updatedAt=new Date().toISOString();send(res,200,{ok:true,message:existing?'Тестовое событие снято.':'Тестовое событие включено.'});return;
    }
    if(url.pathname==='/api/admin/clear'){for(const e of active)history.push({title:e.title,active:false,time:new Date().toLocaleString('uk-UA')});active=[];updatedAt=new Date().toISOString();send(res,200,{ok:true});return;}
    send(res,404,{error:'Не найдено'});return;
   }catch(e){send(res,400,{error:e.message});return;}
 }
 let p=url.pathname==='/'?'/index.html':url.pathname;
 if(p==='/admin')p='/admin.html';
 const file=path.resolve(ROOT,'.'+p);
 if(!file.startsWith(ROOT+path.sep)){send(res,403,{error:'Forbidden'});return;}
 fs.readFile(file,(err,data)=>{if(err){send(res,404,{error:'Файл не найден'});return;}send(res,200,data,mime[path.extname(file)]||'application/octet-stream');});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`AlarmSimulator server listening on port ${PORT}\nClient: http://localhost:${PORT}\nAdmin:  http://localhost:${PORT}/admin\nSet a private ADMIN_TOKEN before use.`));
