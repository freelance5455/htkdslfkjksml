/*
 * R2 GAMES WORLD SERVER V11
 * Server-authoritative multiplayer backend.
 *
 * Design goals:
 *  - The server owns room state, ready state, match state and rewards.
 *  - The browser is a renderer/input client, not the source of truth.
 *  - Room codes are exactly 8 alphanumeric characters.
 *  - Player IDs are exactly 16 decimal digits.
 *  - The same synchronization engine powers Rooms, Quick Match and Tournaments.
 *  - All six R2 games are registered in the game registry.
 *  - Guess The Player has a server-side five-round state machine.
 *  - Rewards are idempotent and persisted.
 *  - Disconnect/reconnect is handled by playerId, not only socket id.
 *
 * Production note:
 *  This build uses a durable JSON store for compatibility with the existing
 *  project. For multiple Node instances, point DATA_DIR at shared storage or
 *  migrate the repository layer to PostgreSQL/Redis. The authoritative game
 *  protocol itself is deliberately independent of that storage choice.
 */

'use strict';

const express = require('express');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const fs = require('fs');
const { Server } = require('socket.io');

const APP_VERSION = '27.0.0-major-update';
const PORT = Number(process.env.PORT) || 3000;
const HOST = '0.0.0.0';
const ROOM_TTL_MS = 6 * 60 * 60 * 1000;
const DISCONNECT_GRACE_MS = 5 * 60 * 1000;
const QUICK_MATCH_TTL_MS = 90 * 1000;
const MAX_ROOM_PLAYERS = 2;
const MAX_ACTIVE_ROOMS = Number(process.env.MAX_ACTIVE_ROOMS || 50000);
const MAX_TOURNAMENTS = Number(process.env.MAX_TOURNAMENTS || 10000);
const MAX_PLAYERS_PER_SERVER_SNAPSHOT = Number(process.env.MAX_PLAYERS_PER_SERVER_SNAPSHOT || 250000);
const MAX_NAME = 40;
const MAX_EVENT_BYTES = 32 * 1024;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'r2-data.json');
const PUBLIC_DIR = fs.existsSync(path.join(__dirname, 'public'))
  ? path.join(__dirname, 'public')
  : __dirname;

fs.mkdirSync(DATA_DIR, { recursive: true });

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, methods: ['GET', 'POST'] },
  maxHttpBufferSize: MAX_EVENT_BYTES,
  pingInterval: 25000,
  pingTimeout: 20000,
  transports: ['websocket', 'polling'],
  allowUpgrades: true
});

app.disable('x-powered-by');
const httpRate = new Map();
app.use((req,res,next)=>{
  const key = `${req.ip || 'unknown'}:${req.path.startsWith('/api/') ? 'api' : 'web'}`;
  const nowMs = now(); const rec = httpRate.get(key) || { start: nowMs, count: 0 };
  if (nowMs - rec.start > 10000) { rec.start = nowMs; rec.count = 0; }
  rec.count += 1; httpRate.set(key, rec);
  const limit = req.path.startsWith('/api/') ? 180 : 300;
  if (rec.count > limit) return res.status(429).json({ error: 'طلبات كثيرة، حاول بعد ثوانٍ' });
  next();
});
app.use((req,res,next)=>{ if(req.path==='/'||req.path.endsWith('.html')||req.path.endsWith('.js')) res.set('Cache-Control','no-store, max-age=0'); next(); });
app.use(express.json({ limit: '256kb' }));
app.use(express.static(PUBLIC_DIR, { index: 'index.html', maxAge: 0, etag: true }));

/* -------------------------------------------------------------------------- */
/* DATA LAYER                                                                 */
/* -------------------------------------------------------------------------- */

const EMPTY_DB = {
  version: 11,
  players: {},
  rooms: {},
  tournaments: {},
  usedTournamentCodes: {},
  rewardClaims: {},
  stats: { games: 0, rooms: 0, quickMatches: 0, tournamentMatches: 0 }
};

let db = loadDb();
let saveTimer = null;
let saveRunning = false;
let saveQueued = false;
let lastPersistAt = 0;
const SAVE_DEBOUNCE_MS = 1200;

function clone(value) { return JSON.parse(JSON.stringify(value)); }

function loadDb() {
  if (!fs.existsSync(DB_FILE)) return clone(EMPTY_DB);
  try {
    const raw = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return {
      ...clone(EMPTY_DB), ...raw,
      players: raw.players || {}, rooms: raw.rooms || {}, tournaments: raw.tournaments || {},
      usedTournamentCodes: raw.usedTournamentCodes || {}, rewardClaims: raw.rewardClaims || {},
      stats: { ...EMPTY_DB.stats, ...(raw.stats || {}) }
    };
  } catch (error) {
    console.error('[DB] load failed:', error.message);
    return clone(EMPTY_DB);
  }
}

/*
 * JSON remains the compatibility store, but writes are now non-blocking and
 * coalesced. No request/socket handler performs synchronous disk writes.
 * This prevents a large snapshot from freezing room creation or polling.
 */
async function flushDbAsync() {
  if (saveRunning) { saveQueued = true; return; }
  saveRunning = true;
  try {
    const snapshot = JSON.stringify(db);
    const tmp = DB_FILE + '.tmp';
    await fs.promises.writeFile(tmp, snapshot, 'utf8');
    await fs.promises.rename(tmp, DB_FILE);
    lastPersistAt = now();
  } catch (error) {
    console.error('[DB] async save failed:', error.message);
  } finally {
    saveRunning = false;
    if (saveQueued) { saveQueued = false; scheduleDbSave(); }
  }
}
function scheduleDbSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { saveTimer = null; flushDbAsync(); }, SAVE_DEBOUNCE_MS);
  if (saveTimer.unref) saveTimer.unref();
}
function saveDb() { scheduleDbSave(); }

/* -------------------------------------------------------------------------- */
/* SECURITY / NORMALIZATION                                                   */
/* -------------------------------------------------------------------------- */

const ROOM_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const GAME_NAMES = ['auction', 'five', 'deal', 'blind', 'guess', 'hidden'];
const GAME_LABELS = {
  auction: 'المزاد برو ماكس',
  five: 'الملعب الخماسي',
  deal: 'DEAL OR NO DEAL',
  blind: 'المزاد الأعمى',
  guess: 'تخمين اللاعب',
  hidden: 'اللاعب الخفي'
};
const TOURNAMENT_SIZES = [16, 32, 64, 128];

function clean(value) {
  return String(value == null ? '' : value).trim().toUpperCase();
}

function safeName(value) {
  const text = String(value || 'لاعب').trim().replace(/[<>]/g, '');
  return text.slice(0, MAX_NAME) || 'لاعب';
}

function validGame(value) {
  const game = String(value || '').trim().toLowerCase();
  return GAME_NAMES.includes(game) ? game : 'auction';
}

function validPlayerId(value) {
  return /^\d{16}$/.test(String(value || ''));
}

function randomPlayerId() {
  let id = '';
  while (id.length < 16) {
    id += crypto.randomInt(0, 100000000).toString().padStart(8, '0');
  }
  return id.slice(0, 16);
}

function newUniquePlayerId() {
  let id;
  do id = randomPlayerId(); while (db.players[id]);
  return id;
}

function randomCode(length = 8) {
  let value = '';
  for (let i = 0; i < length; i += 1) {
    value += ROOM_CHARS[crypto.randomInt(0, ROOM_CHARS.length)];
  }
  return value;
}

function newRoomCode() {
  let code;
  do code = randomCode(8); while (rooms.has(code));
  return code;
}

function newTournamentInviteCode() {
  let code;
  do code = randomCode(8); while (db.usedTournamentCodes[code]);
  return code;
}

function now() {
  return Date.now();
}

function isPlainObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

function limitedObject(value, maxKeys = 40) {
  if (!isPlainObject(value)) return {};
  const entries = Object.entries(value).slice(0, maxKeys);
  return Object.fromEntries(entries);
}

/* -------------------------------------------------------------------------- */
/* PLAYER REPOSITORY                                                          */
/* -------------------------------------------------------------------------- */

function createPlayer(id, name) {
  return {
    id,
    name: safeName(name),
    xb: 0,
    points: 0,
    coins: 0,
    freeDrafts: 0,
    level: 1,
    // Competitive ranking is server-owned. Everyone starts at rank 10.
    ranked: { rank: 10, winsAtRank: 0, wins: 0, losses: 0, draws: 0, matches: 0 },
    xp: 0,
    friends: [],
    incomingRequests: [],
    outgoingRequests: [],
    matchRequests: [],
    completedGames: {},
    rewardClaims: {},
    stats: {
      gamesPlayed: 0,
      gamesWon: 0,
      gamesDrawn: 0,
      gamesLost: 0,
      guessCorrect: 0,
      tournamentsWon: 0,
      tournamentMatches: 0
    },
    createdAt: now(),
    updatedAt: now()
  };
}

function ensurePlayer(id, name) {
  let playerId = String(id || '');
  if (!validPlayerId(playerId)) playerId = newUniquePlayerId();
  if (!db.players[playerId]) db.players[playerId] = createPlayer(playerId, name);
  if (name) db.players[playerId].name = safeName(name);
  db.players[playerId].updatedAt = now();
  return db.players[playerId];
}

function publicPlayer(player) {
  if (!player) return null;
  return {
    id: player.id,
    name: player.name,
    xb: player.xb || 0,
    points: player.points || 0,
    coins: player.coins || 0,
    level: player.level || 1,
    xp: player.xp || 0,
    freeDrafts: player.freeDrafts || 0,
    ownedPlayers: (player.ownedPlayers || []).slice(-200),
    friends: (player.friends || []).length,
    matchRequests: (player.matchRequests || []).filter(x => Number(x.expiresAt||0) > now()).length,
    online: onlinePlayers.has(player.id),
    ranked: {
      rank: Math.min(10, Math.max(1, Number(player.ranked?.rank || 10))),
      winsAtRank: Math.max(0, Number(player.ranked?.winsAtRank || 0)),
      wins: Math.max(0, Number(player.ranked?.wins || 0)),
      losses: Math.max(0, Number(player.ranked?.losses || 0)),
      draws: Math.max(0, Number(player.ranked?.draws || 0)),
      matches: Math.max(0, Number(player.ranked?.matches || 0)),
      winsRequired: Number(player.ranked?.rank || 10) === 10 ? 3 : 6
    },
    stats: { ...(player.stats || {}) }
  };
}

function playerById(id) {
  return db.players[String(id || '')] || null;
}


function rankedWinsRequired(rank) {
  return Number(rank) === 10 ? 3 : 6;
}
function normalizeRanked(player) {
  player.ranked = player.ranked || {};
  player.ranked.rank = Math.min(10, Math.max(1, Number(player.ranked.rank || 10)));
  player.ranked.winsAtRank = Math.max(0, Number(player.ranked.winsAtRank || 0));
  player.ranked.wins = Math.max(0, Number(player.ranked.wins || 0));
  player.ranked.losses = Math.max(0, Number(player.ranked.losses || 0));
  player.ranked.draws = Math.max(0, Number(player.ranked.draws || 0));
  player.ranked.matches = Math.max(0, Number(player.ranked.matches || 0));
  return player.ranked;
}
function rankedPublic(player) {
  const r = normalizeRanked(player);
  return { rank:r.rank, winsAtRank:r.winsAtRank, wins:r.wins, losses:r.losses, draws:r.draws, matches:r.matches, winsRequired:rankedWinsRequired(r.rank) };
}
function recordRankedResult(room, winnerId, draw) {
  if (!room?.ranked) return;
  for (const participant of room.players) {
    const player = playerById(participant.playerId);
    if (!player) continue;
    const r = normalizeRanked(player);
    r.matches += 1;
    if (draw || !winnerId) {
      r.draws += 1;
    } else if (player.id === String(winnerId)) {
      r.wins += 1;
      r.winsAtRank += 1;
      if (r.rank > 1 && r.winsAtRank >= rankedWinsRequired(r.rank)) {
        r.rank -= 1;
        r.winsAtRank = 0;
        const divisionReward = Number(DIVISION_REWARDS[r.rank] || 0);
        if (divisionReward > 0) {
          player.rewardClaims = player.rewardClaims || {};
          const key = `division_${r.rank}_v1`;
          if (!player.rewardClaims[key]) {
            player.rewardClaims[key] = now();
            updatePlayerResources(player, { xb: divisionReward });
          }
        }
        emitToPlayer(player.id, 'ranked:promotion', { rank:r.rank, reward:divisionReward, player:publicPlayer(player) });
      }
    } else {
      r.losses += 1;
    }
    player.updatedAt = now();
    emitToPlayer(player.id, 'ranked:update', { ranked:rankedPublic(player), player:publicPlayer(player) });
  }
  saveDb();
}
function rankedScore(player) {
  const r = normalizeRanked(player);
  return (11 - r.rank) * 100000 + r.winsAtRank * 1000 + r.wins;
}

function updatePlayerResources(player, reward) {
  player.xb = Math.max(0, Number(player.xb || 0) + Number(reward.xb || 0));
  player.points = Math.max(0, Number(player.points || 0) + Number(reward.points || 0));
  player.coins = Math.max(0, Number(player.coins || 0) + Number(reward.coins || 0));
  player.xp = Math.max(0, Number(player.xp || 0) + Number(reward.xp || 0));
  player.freeDrafts = Math.max(0, Number(player.freeDrafts || 0) + Number(reward.freeDrafts || 0));
  const oldLevel = Math.max(1, Number(player.level || 1));
  const newLevel = Math.min(1000, Math.floor(player.xb / 100) + 1);
  player.level = newLevel;
  if (newLevel > oldLevel) {
    player.points += (newLevel - oldLevel) * 1000;
    player.coins += (newLevel - oldLevel) * 1000;
  }
  player.updatedAt = now();
}

function claimReward(playerId, claimKey, reward) {
  const player = playerById(playerId);
  if (!player) return { ok: false, error: 'اللاعب غير موجود' };
  const key = String(claimKey || '').slice(0, 160);
  if (!key) return { ok: false, error: 'معرف المكافأة غير صالح' };
  player.rewardClaims = player.rewardClaims || {};
  if (player.rewardClaims[key]) {
    return { ok: true, duplicate: true, reward: { ...reward }, player: publicPlayer(player) };
  }
  player.rewardClaims[key] = now();
  db.rewardClaims[key] = { playerId, at: now() };
  updatePlayerResources(player, reward);
  saveDb();
  return { ok: true, duplicate: false, reward: { ...reward }, player: publicPlayer(player) };
}

/* -------------------------------------------------------------------------- */
/* PRESENCE                                                                    */
/* -------------------------------------------------------------------------- */

const onlinePlayers = new Map();
const playerSockets = new Map();

function addPresence(socket, player) {
  socket.data.playerId = player.id;
  socket.data.name = player.name;
  onlinePlayers.set(player.id, { socketId: socket.id, since: now() });
  playerSockets.set(player.id, socket.id);
}

function socketForPlayer(playerId) {
  const socketId = playerSockets.get(playerId);
  return socketId ? io.sockets.sockets.get(socketId) : null;
}

function emitToPlayer(playerId, event, payload) {
  const socket = socketForPlayer(playerId);
  if (socket) socket.emit(event, payload);
}

function removePresence(socket) {
  const playerId = socket.data.playerId;
  if (!playerId) return;
  if (playerSockets.get(playerId) === socket.id) playerSockets.delete(playerId);
  if (onlinePlayers.get(playerId)?.socketId === socket.id) onlinePlayers.delete(playerId);
}

/* -------------------------------------------------------------------------- */
/* ROOM ENGINE                                                                 */
/* -------------------------------------------------------------------------- */

const rooms = new Map();
const quickQueue = new Map(); // game -> [{playerId, game, createdAt}]
const rankedQueue = new Map(); // game -> [{playerId, game, rank, createdAt}]
function roomSnapshot(room){return clone({...room,players:room.players.map(p=>({...p,socketId:null}))});}
function persistRoom(room){if(!room)return;db.rooms=db.rooms||{};db.rooms[room.code]=roomSnapshot(room);saveDb();}
function deletePersistedRoom(code){if(db.rooms&&db.rooms[code]){delete db.rooms[code];saveDb();}}
function hydrateRooms(){for(const [code,raw] of Object.entries(db.rooms||{})){if(!/^[A-Z0-9]{8}$/.test(code))continue;if(!raw||now()-Number(raw.lastActivity||raw.createdAt||0)>ROOM_TTL_MS){delete db.rooms[code];continue;}raw.players=Array.isArray(raw.players)?raw.players.slice(0,MAX_ROOM_PLAYERS):[];raw.players.forEach(p=>{p.socketId=null;p.disconnectedAt=p.disconnectedAt||now();});raw.state=raw.state||{version:1,started:false,ended:false,turn:null,revision:0,data:{}};raw.events=Array.isArray(raw.events)?raw.events.slice(-100):[];rooms.set(code,raw);}}


function makeRoomPlayer(socket, player, role) {
  return {
    socketId: socket ? socket.id : null,
    playerId: player.id,
    name: player.name,
    role,
    ready: false,
    connectedAt: now(),
    disconnectedAt: null,
    sessionToken: crypto.randomBytes(12).toString('hex')
  };
}

function createRoom(game, password, hostSocket, hostPlayer, options = {}) {
  if (rooms.size >= MAX_ACTIVE_ROOMS) throw new Error('السيرفر وصل للحد المؤقت للغرف النشطة، حاول بعد قليل');
  const code = newRoomCode();
  const room = {
    code,
    game: validGame(game),
    name: safeName(options.name || 'غرفة R2'),
    isPrivate: options.isPrivate !== false,
    password: String(password || '').slice(0, 64),
    createdAt: now(),
    updatedAt: now(),
    status: 'waiting',
    players: [makeRoomPlayer(hostSocket, hostPlayer, 'host')],
    state: {
      version: 1,
      started: false,
      ended: false,
      turn: null,
      revision: 0,
      data: {}
    },
    events: [],
    lastActivity: now(),
    tournament: null,
    quickMatch: false,
    ranked: false
  };
  rooms.set(code, room);
  db.stats.rooms = (db.stats.rooms || 0) + 1;
  persistRoom(room);
  saveDb();
  return room;
}

function roomPublic(room) {
  return {
    code: room.code,
    name: room.name || 'غرفة R2',
    isPrivate: room.isPrivate !== false,
    game: room.game,
    gameLabel: GAME_LABELS[room.game],
    status: room.status,
    players: room.players.map((player) => ({
      id: player.playerId,
      name: player.name,
      role: player.role,
      ready: !!player.ready,
      connected: !!player.socketId
    })),
    playerCount: room.players.length,
    readyCount: room.players.filter((p) => p.ready).length,
    maxPlayers: MAX_ROOM_PLAYERS,
    passwordProtected: !!room.password,
    createdAt: room.createdAt,
    revision: room.state.revision,
    started: !!room.state.started,
    ended: !!room.state.ended,
    tournamentId: room.tournament?.id || null,
    quickMatch: !!room.quickMatch,
    ranked: !!room.ranked
  };
}

function publicOpenRooms() {
  return Array.from(rooms.values()).filter(r => r.isPrivate === false && r.players.length < MAX_ROOM_PLAYERS && !r.state.started)
    .map(room => ({ code: room.code, name: room.name || 'غرفة R2', game: room.game, gameLabel: GAME_LABELS[room.game], playerCount: room.players.length, maxPlayers: MAX_ROOM_PLAYERS, createdAt: room.createdAt }));
}

function findRoom(code) {
  const value = clean(code);
  if (!/^[A-Z0-9]{8}$/.test(value)) return null;
  return rooms.get(value);
}

function playerInRoom(room, playerId) {
  return room.players.find((p) => p.playerId === playerId) || null;
}

function socketInRoom(room, socketId) {
  return room.players.find((p) => p.socketId === socketId) || null;
}

hydrateRooms();

function roomForSocket(socket) {
  for (const room of rooms.values()) {
    if (room.players.some((p) => p.socketId === socket.id)) return room;
  }
  return null;
}

function broadcastRoom(room, event = 'room:state') {
  io.to(room.code).emit(event, roomPublic(room));
}

function requireRoomPlayer(socket, room, playerId) {
  if (!room) return { ok: false, error: 'الغرفة غير موجودة' };
  let player = socketInRoom(room, socket.id);
  // Mobile browsers can reconnect with a new socket.id between the room screen
  // and the first game action. Re-bind by the durable 16-digit player ID so a
  // healthy room is never reported as disconnected merely because the socket
  // was upgraded/reconnected.
  if (!player && playerId) {
    const durable = playerInRoom(room, String(playerId));
    if (durable) {
      durable.socketId = socket.id;
      durable.disconnectedAt = null;
      socket.data.playerId = durable.playerId;
      socket.data.name = durable.name;
      socket.join(room.code);
      player = durable;
      room.updatedAt = now();
      room.lastActivity = now();
      persistRoom(room);
    }
  }
  if (!player) return { ok: false, error: 'أنت لست داخل هذه الغرفة' };
  return { ok: true, player };
}

function joinRoomSocket(socket, room, player, password) {
  if (!room) return { ok: false, error: 'كود الغرفة غير موجود' };
  if (room.password && String(password || '') !== room.password) {
    return { ok: false, error: 'كلمة السر غير صحيحة' };
  }
  const existing = playerInRoom(room, player.id);
  if (existing) {
    existing.socketId = socket.id;
    existing.disconnectedAt = null;
    existing.connectedAt = now();
    socket.join(room.code);
    room.updatedAt = now();
    room.lastActivity = now();
    persistRoom(room);
    return { ok: true, reconnected: true };
  }
  if (room.players.length >= MAX_ROOM_PLAYERS) {
    return { ok: false, error: 'الغرفة ممتلئة' };
  }
  room.players.push(makeRoomPlayer(socket, player, 'guest'));
  room.status = 'connected';
  room.updatedAt = now();
  room.lastActivity = now();
  socket.join(room.code);
  persistRoom(room);
  return { ok: true, reconnected: false };
}


function initOnlineGameState(room) {
  room.state.data = room.state.data || {};
  if (room.game === 'auction' || room.game === 'five') {
    if (!room.state.data.auction) initAuthoritativeAuction(room, room.game === 'auction' ? 100 : 50);
    return;
  }
  if (room.game === 'guess') {
    if (!room.state.data.guess) newGuessState(room);
    return;
  }
  const catalog = SHARED_PLAYER_CATALOG.length ? SHARED_PLAYER_CATALOG : DRAFT_POOL;
  const shuffled = [...catalog].sort(() => Math.random() - 0.5);
  if (room.game === 'deal') {
    room.state.data.deal = { round: 0, total: 6, boxes: shuffled.slice(0, 24), chosen: {}, scores: Object.fromEntries(room.players.map(p => [p.playerId, 0])) };
    room.state.turn = room.players[0]?.playerId || null;
  } else if (room.game === 'blind') {
    room.state.data.blind = { round: 0, total: 6, cards: shuffled.slice(0, 6), bids: {}, scores: Object.fromEntries(room.players.map(p => [p.playerId, 0])), budgetByPlayer: Object.fromEntries(room.players.map(p => [p.playerId, 100])) };
    room.state.turn = null;
  } else if (room.game === 'hidden') {
    room.state.data.hidden = { round: 0, total: 6, visible: shuffled.slice(0, 6), secret: shuffled.slice(6, 12), choices: {}, scores: Object.fromEntries(room.players.map(p => [p.playerId, 0])) };
    room.state.turn = null;
  }
}

function onlinePublicState(room) {
  const d = room.state.data || {};
  if (room.game === 'guess') return { game: 'guess', guess: publicGuessState(room), turn: room.state.turn, revision: room.state.revision };
  if (room.game === 'auction' || room.game === 'five') return { game: room.game, auction: safeAuctionResult(d.auction || {}), currentBid: d.auction?.currentBid || 10, turn: room.state.turn, revision: room.state.revision };
  if (room.game === 'deal') {
    const x=d.deal||{}; const boxCount=4;
    return { game:'deal', round:x.round+1,total:x.total,turn:room.state.turn,scores:x.scores||{},opened:!!x.opened,revealed:x.revealed||null,boxCount,revision:room.state.revision };
  }
  if (room.game === 'blind') { const x=d.blind||{}; return { game:'blind',round:x.round+1,total:x.total,turn:room.state.turn,currentCard:x.cards?.[x.round]||null,bids:x.bids||{},scores:x.scores||{},budgetByPlayer:x.budgetByPlayer||{},revision:room.state.revision}; }
  if (room.game === 'hidden') { const x=d.hidden||{}; return { game:'hidden',round:x.round+1,total:x.total,turn:room.state.turn,visible:x.visible?.[x.round]||null,secretAvailable:true,choices:x.choices||{},scores:x.scores||{},revision:room.state.revision}; }
  return {game:room.game,turn:room.state.turn,revision:room.state.revision};
}

function maybeStartRoom(room) {
  if (room.players.length !== 2) return false;
  if (!room.players.every((p) => p.ready)) return false;
  if (room.state.started) return true;
  room.status = 'playing';
  room.state.started = true;
  room.state.ended = false;
  room.state.revision += 1;
  room.state.turn = room.players[0].playerId;
  initOnlineGameState(room);
  room.state.revision += 1;
  persistRoom(room);
  room.lastActivity = now();
  room.events.push({ type: 'game:start', at: now() });
  io.to(room.code).emit('game:start', {
    room: roomPublic(room),
    game: room.game,
    state: clone(room.state)
  });
  broadcastRoom(room);
  return true;
}

function markReady(room, socket) {
  const p = socketInRoom(room, socket.id);
  if (!p) return { ok: false, error: 'أنت لست داخل الغرفة' };
  if (room.players.length !== 2) return { ok: false, error: 'انتظر اللاعب الثاني' };
  if (room.state.started) return { ok: false, error: 'المباراة بدأت بالفعل' };
  p.ready = true;
  room.status = 'ready';
  room.updatedAt = now();
  room.lastActivity = now();
  room.state.revision += 1;
  broadcastRoom(room, 'room:ready-state');
  io.to(room.code).emit('room:connected', roomPublic(room));
  maybeStartRoom(room);
  return { ok: true, room: roomPublic(room) };
}

function leaveRoomSocket(socket) {
  const room = roomForSocket(socket);
  if (!room) return;
  const p = socketInRoom(room, socket.id);
  if (!p) return;
  p.socketId = null;
  p.disconnectedAt = now();
  p.ready = false;
  room.status = room.state.started ? 'reconnecting' : (room.players.length === 1 ? 'waiting' : 'connected');
  room.updatedAt = now();
  room.lastActivity = now();
  broadcastRoom(room, 'room:player-left');
  setTimeout(() => cleanupDisconnectedRoom(room.code), DISCONNECT_GRACE_MS);
}

function cleanupDisconnectedRoom(code) {
  const room = rooms.get(code);
  if (!room) return;
  const live = room.players.some((p) => p.socketId);
  if (live) return;
  const recent = room.players.some((p) => p.disconnectedAt && now() - p.disconnectedAt < DISCONNECT_GRACE_MS);
  if (recent) return;
  rooms.delete(code);
  deletePersistedRoom(code);
}

function serverGameEvent(room, socket, type, data) {
  if (!room.state.started || room.state.ended) {
    return { ok: false, error: 'المباراة ليست قيد التشغيل' };
  }
  const sender = socketInRoom(room, socket.id);
  if (!sender) return { ok: false, error: 'لاعب غير مصرح' };
  if (room.state.turn && room.state.turn !== sender.playerId && isTurnBoundEvent(type)) {
    return { ok: false, error: 'ليس دورك الآن' };
  }
  const cleanType = String(type || 'move').slice(0, 60);
  const payload = limitedObject(data, 60);
  const allowed = {
    auction: ['auction:bid','auction:surrender','turn:end','match:end'],
    five: ['auction:bid','auction:surrender','turn:end','match:end'],
    deal: ['deal:open','turn:end','match:end'],
    blind: ['blind:bid','turn:end','match:end'],
    hidden: ['hidden:choose','turn:end','match:end'],
    guess: ['guess:answer','turn:end','match:end']
  };
  if (!(allowed[room.game] || []).includes(cleanType)) {
    return { ok:false, error:'حركة غير مسموحة لهذه اللعبة' };
  }
  const before = JSON.stringify(room.state);
  const event = {
    id: crypto.randomBytes(8).toString('hex'),
    seq: room.state.revision + 1,
    type: cleanType,
    by: sender.playerId,
    at: now(),
    data: payload
  };
  applyAuthoritativeEvent(room, event);
  const after = JSON.stringify(room.state);
  if (before === after && !['chat','ping','state:request'].includes(cleanType)) {
    return { ok:false, error:'الحركة مرفوضة أو غيرت حالة المباراة' };
  }
  room.state.revision += 1;
  event.seq = room.state.revision;
  room.events.push(event);
  if (room.events.length > 100) room.events.shift();
  room.updatedAt = now();
  room.lastActivity = now();
  persistRoom(room);
  io.to(room.code).emit('game:event', event);
  io.to(room.code).emit('game:sync', {
    revision: room.state.revision,
    state: clone(room.state)
  });
  return { ok: true, event, state: clone(room.state) };
}

function isTurnBoundEvent(type) {
  return !['chat', 'ping', 'state:request', 'guess:answer'].includes(String(type || ''));
}

function initAuthoritativeAuction(room, budget) {
  const cards = [];
  const positions = GAME_POSITIONS[room.game] || GAME_POSITIONS.auction;
  const deck = ensureRoomDeck(room);
  const used = {};
  for (const pos of positions) {
    const list = deck[pos] || [];
    const idx = used[pos] || 0;
    const card = list[idx % Math.max(1, list.length)];
    if (card) cards.push(clone(card));
    used[pos] = idx + 1;
  }
  room.state.data.auction = {
    budget: Number(budget), budgetByPlayer: Object.fromEntries(room.players.map(p => [p.playerId, Number(budget)])),
    cards, round: 0, currentBid: 10, bids: 0, lastAction: null, activePlayerId: room.players[0]?.playerId || null,
    setup: Object.fromEntries(room.players.map(p => [p.playerId, true]))
  };
  room.state.turn = room.players[0]?.playerId || null;
  room.state.revision += 1;
  room.lastActivity = now();
  persistRoom(room);
}

function safeAuctionResult(a){
  return { round:a.round, cards:a.cards, budgetByPlayer:a.budgetByPlayer, squads:a.squads||{}, lastAction:a.lastAction };
}

function applyAuthoritativeEvent(room, event) {
  const state = room.state.data || (room.state.data = {});
  if (room.game === 'auction' || room.game === 'five') {
    state.auction = state.auction || { currentBid: 10, round: 0, bids: 0, lastAction: null };
    if (event.type === 'auction:bid') {
      const amount = Number(event.data?.amount);
      const budget = Number(state.auction.budgetByPlayer?.[event.by] ?? 0);
      if (!Number.isFinite(amount) || amount <= Number(state.auction.currentBid || 10)) return;
      if (!Number.isFinite(budget) || amount > budget) return;
      state.auction.currentBid = amount;
      state.auction.bids += 1;
      state.auction.lastAction = `${event.by} bid ${amount}`;
      const next = room.players.find(p => p.playerId !== event.by);
      room.state.turn = next ? next.playerId : event.by;
      state.auction.activePlayerId = room.state.turn;
    } else if (event.type === 'auction:surrender') {
      const winner = room.players.find(p => p.playerId !== event.by);
      const card = state.auction.cards?.[state.auction.round];
      const price = Number(state.auction.currentBid || 10);
      if (winner && card) {
        state.auction.budgetByPlayer[winner.playerId] = Math.max(0, Number(state.auction.budgetByPlayer[winner.playerId] || 0) - price);
        state.auction.squads = state.auction.squads || Object.fromEntries(room.players.map(p => [p.playerId, []]));
        state.auction.squads[winner.playerId] = state.auction.squads[winner.playerId] || [];
        if (!state.auction.squads[winner.playerId].some(x => x.name === card.name)) state.auction.squads[winner.playerId].push(card);
      }
      state.auction.lastAction = `🏆 ${winner?.name || 'اللاعب الآخر'} فاز بـ ${card?.name || 'اللاعب'} مقابل ${price}`;
      state.auction.round += 1;
      state.auction.currentBid = 10;
      state.auction.bids = 0;
      const nextRoundPlayer = room.players[state.auction.round % room.players.length];
      room.state.turn = nextRoundPlayer?.playerId || null;
      state.auction.activePlayerId = room.state.turn;
      if (state.auction.round >= state.auction.cards.length) {
        const scores = room.players.map(p => ({ id:p.playerId, count:(state.auction.squads?.[p.playerId]||[]).length }));
        const max = Math.max(...scores.map(x=>x.count));
        const winners = scores.filter(x=>x.count===max);
        finalizeRoom(room, { winnerId:winners.length===1?winners[0].id:null, draw:winners.length!==1, auction:safeAuctionResult(state.auction) });
      }
    }
  }
  if (room.game === 'deal') {
    const d=state.deal || (state.deal={round:0,total:6,boxes:[],scores:{}});
    if(event.type==='deal:open') {
      const box=Math.max(0,Math.min(3,Number(event.data?.box||0)));
      if(d.opened) return;
      const card=d.boxes[(d.round*4)+box] || d.boxes[d.round] || null;
      d.revealed=card; d.opened=true;
      d.scores[event.by]=(d.scores[event.by]||0)+(Number(card?.rating||0)>80?1:0);
      setTimeout(()=>advanceSimpleOnlineRoom(room.code,'deal'),900);
    }
  } else if (room.game === 'blind') {
    const d=state.blind || {};
    if(event.type==='blind:bid') {
      const amount=Math.floor(Number(event.data?.amount));
      if(!Number.isFinite(amount)||amount<0||amount>(d.budgetByPlayer?.[event.by]||0)||d.bids?.[event.by]!=null) return;
      d.bids[event.by]=amount;
      const ids=room.players.map(p=>p.playerId);
      if(ids.every(id=>d.bids[id]!=null)) {
        const a=d.bids[ids[0]], b=d.bids[ids[1]], winner=a===b?null:(a>b?ids[0]:ids[1]);
        if(winner) { d.budgetByPlayer[winner]-=d.bids[winner]; d.scores[winner]=(d.scores[winner]||0)+1; }
        d.winner=winner; d.opened=true;
        setTimeout(()=>advanceSimpleOnlineRoom(room.code,'blind'),900);
      }
    }
  } else if (room.game === 'hidden') {
    const d=state.hidden || {};
    if(event.type==='hidden:choose') {
      if(d.choices?.[event.by]!=null) return;
      const pick=String(event.data?.pick)==='secret'?'secret':'visible';
      d.choices[event.by]=pick;
      if(room.players.every(p=>d.choices[p.playerId]!=null)) {
        for(const p of room.players) if(d.choices[p.playerId]==='secret') d.scores[p.playerId]=(d.scores[p.playerId]||0)+1;
        d.opened=true;
        setTimeout(()=>advanceSimpleOnlineRoom(room.code,'hidden'),900);
      }
    }
  }
  if (room.game === 'guess') {
    applyGuessEvent(room, event);
    return;
  }
  if (event.type === 'turn:end') {
    const next = room.players.find((p) => p.playerId !== event.by);
    room.state.turn = next ? next.playerId : event.by;
  }
  if (event.type === 'match:end') {
    room.state.ended = true;
    room.status = 'finished';
  }
  state.lastEvent = event.type;
}


function advanceSimpleOnlineRoom(code, game) {
  const room=rooms.get(code); if(!room || room.state.ended || room.game!==game) return;
  const d=room.state.data[game]; if(!d) return;
  if(d.round >= d.total-1) {
    const ids=room.players.map(p=>p.playerId); const a=d.scores?.[ids[0]]||0,b=d.scores?.[ids[1]]||0;
    const winnerId=a===b?null:(a>b?ids[0]:ids[1]); finalizeRoom(room,{winnerId,draw:a===b,score:{[ids[0]]:a,[ids[1]]:b},game}); return;
  }
  d.round += 1; d.opened=false; d.revealed=null; d.winner=null; d.bids={}; d.choices={};
  room.state.turn=(game==='blind'||game==='hidden')?null:room.players[d.round%room.players.length]?.playerId||null;
  room.state.revision += 1; persistRoom(room);
  io.to(room.code).emit('game:sync',{revision:room.state.revision,state:clone(room.state)});
}

/* -------------------------------------------------------------------------- */
/* GUESS THE PLAYER — SERVER AUTHORITATIVE                                   */
/* -------------------------------------------------------------------------- */

const GUESS_PLAYERS = [
  ['كريستيانو رونالدو', ['سبورتينغ لشبونة', 'مانشستر يونايتد', 'ريال مدريد', 'يوفنتوس', 'النصر']],
  ['ليونيل ميسي', ['برشلونة', 'باريس سان جيرمان', 'إنتر ميامي']],
  ['نيمار', ['سانتوس', 'برشلونة', 'باريس سان جيرمان', 'الهلال']],
  ['كيليان مبابي', ['موناكو', 'باريس سان جيرمان', 'ريال مدريد']],
  ['محمد صلاح', ['المقاولون', 'بازل', 'تشيلسي', 'فيورنتينا', 'روما', 'ليفربول']],
  ['زلاتان إبراهيموفيتش', ['مالمو', 'أياكس', 'يوفنتوس', 'إنتر', 'برشلونة', 'ميلان', 'باريس سان جيرمان', 'مانشستر يونايتد']],
  ['لوكا مودريتش', ['دينامو زغرب', 'توتنهام', 'ريال مدريد']],
  ['روبرت ليفاندوفسكي', ['بوروسيا دورتموند', 'بايرن ميونخ', 'برشلونة']],
  ['إيرلينغ هالاند', ['مولده', 'سالزبورغ', 'بوروسيا دورتموند', 'مانشستر سيتي']],
  ['كريم بنزيما', ['ليون', 'ريال مدريد', 'الاتحاد']],
  ['سيرجيو راموس', ['إشبيلية', 'ريال مدريد', 'باريس سان جيرمان', 'مونتيري']],
  ['رونالدينيو', ['غريميو', 'باريس سان جيرمان', 'برشلونة', 'ميلان']],
  ['رونالدو نازاريو', ['كروزيرو', 'آيندهوفن', 'برشلونة', 'إنتر', 'ريال مدريد', 'ميلان']],
  ['تييري هنري', ['موناكو', 'يوفنتوس', 'أرسنال', 'برشلونة']],
  ['ديفيد بيكهام', ['مانشستر يونايتد', 'ريال مدريد', 'ميلان', 'لوس أنجلوس غالاكسي', 'باريس سان جيرمان']],
  ['واين روني', ['إيفرتون', 'مانشستر يونايتد', 'دي سي يونايتد', 'ديربي']],
  ['لويس سواريز', ['ناسيونال', 'أياكس', 'ليفربول', 'برشلونة', 'أتلتيكو مدريد', 'إنتر ميامي']],
  ['ريكاردو كاكا', ['ساو باولو', 'ميلان', 'ريال مدريد', 'أورلاندو']],
  ['آريين روبن', ['غرونينغن', 'آيندهوفن', 'تشيلسي', 'ريال مدريد', 'بايرن']],
  ['مانويل نوير', ['شالكه', 'بايرن ميونخ']],
  ['جانلويجي بوفون', ['بارما', 'يوفنتوس', 'باريس سان جيرمان']],
  ['إيكر كاسياس', ['ريال مدريد', 'بورتو']],
  ['بيبي', ['ماريتيمو', 'بورتو', 'ريال مدريد', 'بشكتاش']],
  ['فيرجيل فان دايك', ['غرونينغن', 'سيلتيك', 'ساوثهامبتون', 'ليفربول']],
  ['كيفن دي بروين', ['جينك', 'تشيلسي', 'فيردر بريمن', 'فولفسبورغ', 'مانشستر سيتي']],
  ['جود بيلينغهام', ['برمنغهام', 'بوروسيا دورتموند', 'ريال مدريد']],
  ['فينيسيوس جونيور', ['فلامنغو', 'ريال مدريد']],
  ['رودري', ['فياريال', 'أتلتيكو مدريد', 'مانشستر سيتي']],
  ['برونو فيرنانديز', ['نوفارا', 'أودينيزي', 'سامبدوريا', 'سبورتينغ', 'مانشستر يونايتد']],
  ['سون هيونغ مين', ['هامبورغ', 'باير ليفركوزن', 'توتنهام']],
  ['ساديو ماني', ['ميتز', 'سالزبورغ', 'ساوثهامبتون', 'ليفربول', 'بايرن', 'النصر']],
  ['رافائيل لياو', ['سبورتينغ', 'ليل', 'ميلان']],
  ['فيكتور أوسيمين', ['فولفسبورغ', 'شارلروا', 'ليل', 'نابولي', 'غلطة سراي']],
  ['لوتارو مارتينيز', ['راسينغ', 'إنتر']],
  ['إيدين هازارد', ['ليل', 'تشيلسي', 'ريال مدريد']],
  ['غاريث بيل', ['ساوثهامبتون', 'توتنهام', 'ريال مدريد', 'لوس أنجلوس']],
  ['مارسيلو', ['فلومينينسي', 'ريال مدريد', 'أولمبياكوس']],
  ['روبرتو كارلوس', ['بالميراس', 'إنتر', 'ريال مدريد', 'فنربخشة', 'كورينثيانز']],
  ['ديدييه دروغبا', ['لو مان', 'غانغان', 'مارسيليا', 'تشيلسي', 'غلطة سراي']],
  ['يايا توريه', ['بيفيرين', 'ميتاليورغ', 'أولمبياكوس', 'موناكو', 'برشلونة', 'مانشستر سيتي']],
  ['صامويل إيتو', ['ريال مدريد', 'مايوركا', 'برشلونة', 'إنتر', 'أنجي', 'تشيلسي']],
  ['داني ألفيش', ['باهيا', 'إشبيلية', 'برشلونة', 'يوفنتوس', 'باريس سان جيرمان']],
  ['جورج بست', ['مانشستر يونايتد', 'فولهام', 'لوس أنجلوس أزتيكس']]
];

function normalizeGuess(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/[^\p{L}\p{N} ]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function newGuessState(room) {
  const shuffled = [...GUESS_PLAYERS].sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, 5);
  room.state.data.guess = {
    round: 1,
    turnIndex: 0,
    score: {},
    selected: selected.map((p) => ({ name: p[0], clubs: p[1] })),
    answered: false,
    finished: false,
    used: selected.map((p) => p[0])
  };
  for (const p of room.players) room.state.data.guess.score[p.playerId] = 0;
}

function publicGuessState(room) {
  const g = room.state.data.guess;
  if (!g) return null;
  const current = g.selected[g.round - 1];
  return {
    round: g.round,
    totalRounds: 5,
    turnPlayerId: room.players[g.turnIndex]?.playerId || null,
    score: { ...g.score },
    clubs: current ? current.clubs : [],
    finished: !!g.finished
  };
}

function applyGuessEvent(room, event) {
  const state = room.state.data;
  if (!state.guess) newGuessState(room);
  const g = state.guess;
  if (event.type === 'guess:start') {
    newGuessState(room);
    room.state.turn = room.players[0]?.playerId || null;
    return;
  }
  if (event.type !== 'guess:answer') return;
  if (g.finished || g.answered) return;
  const active = room.players[g.turnIndex];
  if (!active || active.playerId !== event.by) return;
  const answer = normalizeGuess(event.data?.answer);
  const current = g.selected[g.round - 1];
  if (!answer || !current) return;
  const correct = normalizeGuess(current.name);
  const ok = answer === correct || answer.includes(correct) || correct.includes(answer);
  if (ok) {
    g.score[event.by] = (g.score[event.by] || 0) + 1;
    const player = playerById(event.by);
    if (player) {
      player.stats.guessCorrect = (player.stats.guessCorrect || 0) + 1;
      advanceDaily(player, 'guess', 1);
    }
  }
  g.answered = true;
  room.state.revision += 1;
  io.to(room.code).emit('guess:result', {
    round: g.round,
    playerId: event.by,
    correct: ok,
    answer: current.name,
    score: { ...g.score }
  });
  setTimeout(() => advanceGuess(room.code), 1200);
}

function advanceGuess(code) {
  const room = rooms.get(code);
  if (!room || room.game !== 'guess') return;
  const g = room.state.data.guess;
  if (!g || !g.answered || g.finished) return;

  // Each round has exactly two turns: player A then player B.
  // After B answers, increment the round once (not twice).
  if (g.turnIndex < room.players.length - 1) {
    g.turnIndex += 1;
  } else if (g.round >= 5) {
    g.finished = true;
    room.state.ended = true;
    room.status = 'finished';
    room.state.revision += 1;
    io.to(room.code).emit('guess:finished', {
      score: { ...g.score },
      room: roomPublic(room)
    });
    const ids = room.players.map((p) => p.playerId);
    const a = g.score[ids[0]] || 0;
    const b = g.score[ids[1]] || 0;
    const winnerId = a === b ? null : (a > b ? ids[0] : ids[1]);
    recordGameCompletion(room, 'guess', winnerId, a === b);
    recordRankedResult(room, winnerId, a === b);
    persistRoom(room);
    io.to(room.code).emit('game:finished', {
      room: roomPublic(room),
      result: { winnerId, draw: a === b, score: { [ids[0]]: a, [ids[1]]: b } },
      state: clone(room.state)
    });
    return;
  } else {
    g.round += 1;
    g.turnIndex = 0;
  }

  g.answered = false;
  room.state.turn = room.players[g.turnIndex]?.playerId || null;
  room.state.revision += 1;
  io.to(room.code).emit('guess:state', publicGuessState(room));
}


/* -------------------------------------------------------------------------- */
/* GAME COMPLETION / REWARDS                                                  */
/* -------------------------------------------------------------------------- */

const STANDARD_GAME_REWARD = { xb: 15, points: 600, coins: 1000, xp: 15 };

function recordGameCompletion(room, game, winnerId = null, draw = false) {
  const matchKey = `${room.code}:${room.state.revision}:${game}`;
  for (const participant of room.players) {
    const player = playerById(participant.playerId);
    if (!player) continue;
    player.stats.gamesPlayed = (player.stats.gamesPlayed || 0) + 1;
    if (winnerId && participant.playerId === winnerId) player.stats.gamesWon = (player.stats.gamesWon || 0) + 1;
    else if (winnerId && participant.playerId !== winnerId) player.stats.gamesLost = (player.stats.gamesLost || 0) + 1;
    else if (draw) player.stats.gamesDrawn = (player.stats.gamesDrawn || 0) + 1;
    const result = claimReward(player.id, `${matchKey}:${player.id}`, STANDARD_GAME_REWARD);
    advanceDaily(player, 'game', 1);
    if (winnerId === participant.playerId) advanceDaily(player, 'win', 1);
    emitToPlayer(player.id, 'game:reward', {
      playerId: player.id,
      claimKey: `${matchKey}:${player.id}`,
      reward: result.reward,
      player: result.player
    });
  }
  db.stats.games = (db.stats.games || 0) + 1;
  saveDb();
}

function finalizeRoom(room, result = {}) {
  if (room.state.ended) return;
  room.state.ended = true;
  room.status = 'finished';
  room.state.revision += 1;
  room.state.data.result = limitedObject(result, 30);
  const winnerId = result.winnerId || null;
  const draw = !!result.draw;
  recordGameCompletion(room, room.game, winnerId, draw);
  recordRankedResult(room, winnerId, draw);
  // Tournament rooms advance the official bracket from the authoritative room result.
  if (room.tournament?.id && room.tournament?.matchId && !draw && winnerId) {
    const tournament = db.tournaments[room.tournament.id];
    if (tournament) {
      const tr = tournamentMatchResult(tournament, room.tournament.matchId, String(winnerId), result.score || null);
      if (tr.ok) {
        room.state.data.tournamentAdvanced = true;
        autoOpenTournamentMatches(tournament);
        io.emit('tournament:update', tournamentPublic(tournament));
      }
    }
  }
  persistRoom(room);
  io.to(room.code).emit('game:finished', {
    room: roomPublic(room),
    result: room.state.data.result,
    state: clone(room.state)
  });
}

/* -------------------------------------------------------------------------- */
/* MATCH RESULT HELPERS                                                       */
/* -------------------------------------------------------------------------- */

const RESULT_POOL = [
  [1, 0], [1, 1], [3, 2], [2, 2], [2, 1], [0, 1], [1, 2], [2, 3],
  [3, 1], [0, 0], [3, 3], [4, 2], [2, 0], [0, 2], [4, 1], [1, 3]
];

function randomMatchScore() {
  const score = RESULT_POOL[crypto.randomInt(0, RESULT_POOL.length)];
  return { home: score[0], away: score[1] };
}

/* -------------------------------------------------------------------------- */
/* QUICK MATCH                                                                */
/* -------------------------------------------------------------------------- */

function quickKey(game) {
  return validGame(game);
}

function removeQuickEntry(playerId) {
  for (const [key, list] of quickQueue) {
    const next = (list || []).filter(e => e.playerId !== playerId);
    if (next.length) quickQueue.set(key, next); else quickQueue.delete(key);
  }
}

function tryQuickMatch(entry) {
  const key = quickKey(entry.game);
  const list = quickQueue.get(key) || [];
  while (list.length) {
    const waiting = list.shift();
    if (!waiting || waiting.playerId === entry.playerId) continue;
    if (now() - waiting.createdAt > QUICK_MATCH_TTL_MS) continue;
    const aSocket = socketForPlayer(waiting.playerId);
    const bSocket = socketForPlayer(entry.playerId);
    if (!aSocket || !bSocket) continue;
    quickQueue.set(key, list);
    const aPlayer = playerById(waiting.playerId);
    const bPlayer = playerById(entry.playerId);
    if (!aPlayer || !bPlayer) continue;
    const room = createRoom(key, '', aSocket, aPlayer);
  room.quickMatch = true;
  joinRoomSocket(bSocket, room, bPlayer, '');
  aSocket.join(room.code);
  bSocket.join(room.code);
  room.status = 'connected';
  room.players.forEach(p => { p.ready = true; });
  room.state.revision += 1;
  db.stats.quickMatches = (db.stats.quickMatches || 0) + 1;
  saveDb();
  persistRoom(room);
  maybeStartRoom(room);
  io.to(room.code).emit('quick:matched', {
    room: roomPublic(room),
    game: room.game
  });
  io.to(room.code).emit('room:connected', roomPublic(room));
    return room;
  }
  quickQueue.set(key, list);
  return null;
}

/* -------------------------------------------------------------------------- */
/* COMPETITIVE RANKED MATCHMAKING                                             */
/* -------------------------------------------------------------------------- */

const RANKED_QUEUE_TTL_MS = 120000;
const RANKED_EXPAND_AFTER_MS = 10000;

function rankedQueueKey(game) { return validGame(game); }
function removeRankedEntry(playerId) {
  for (const [key, list] of rankedQueue) {
    const next = (list || []).filter(e => e.playerId !== playerId);
    if (next.length) rankedQueue.set(key, next); else rankedQueue.delete(key);
  }
}
function tryRankedMatch(entry) {
  const key = rankedQueueKey(entry.game);
  const list = rankedQueue.get(key) || [];
  const nowMs = now();
  let candidateIndex = -1;
  let bestDistance = Infinity;
  for (let i=0;i<list.length;i++) {
    const w=list[i];
    if (!w || w.playerId===entry.playerId || nowMs-w.createdAt>RANKED_QUEUE_TTL_MS) continue;
    const waitingRank = Number(w.rank||10), myRank=Number(entry.rank||10);
    const waitingLong = nowMs-w.createdAt >= RANKED_EXPAND_AFTER_MS;
    const entryLong = nowMs-entry.createdAt >= RANKED_EXPAND_AFTER_MS;
    const allowed = waitingLong || entryLong ? Math.abs(waitingRank-myRank)<=2 : waitingRank===myRank;
    if (!allowed) continue;
    const distance=Math.abs(waitingRank-myRank);
    if (distance<bestDistance) { bestDistance=distance; candidateIndex=i; }
  }
  if (candidateIndex<0) {
    rankedQueue.set(key,list.filter(e=>e && nowMs-e.createdAt<=RANKED_QUEUE_TTL_MS));
    return null;
  }
  const waiting=list.splice(candidateIndex,1)[0];
  rankedQueue.set(key,list);
  const aSocket=socketForPlayer(waiting.playerId), bSocket=socketForPlayer(entry.playerId);
  const aPlayer=playerById(waiting.playerId), bPlayer=playerById(entry.playerId);
  if(!aSocket||!bSocket||!aPlayer||!bPlayer) return null;
  const room=createRoom(key,'',aSocket,aPlayer);
  room.ranked=true;
  room.rankedMatch={createdAt:now(), ranks:{[aPlayer.id]:Number(waiting.rank||10),[bPlayer.id]:Number(entry.rank||10)}};
  joinRoomSocket(bSocket,room,bPlayer,'');
  aSocket.join(room.code); bSocket.join(room.code);
  room.status='connected';
  room.players.forEach(p=>p.ready=true);
  room.state.revision+=1;
  persistRoom(room); saveDb();
  maybeStartRoom(room);
  io.to(room.code).emit('ranked:matched',{room:roomPublic(room),game:room.game});
  return rooms.get(value) || null;
}

/* -------------------------------------------------------------------------- */
/* FRIENDS                                                                    */
/* -------------------------------------------------------------------------- */

function addFriendRequest(fromId, toId) {
  const from = playerById(String(fromId || '').trim());
  const to = playerById(String(toId || '').trim());
  if (!from || !to) return { ok: false, error: 'ID غير موجود' };
  if (from.id === to.id) return { ok: false, error: 'لا يمكنك إضافة نفسك' };
  from.friends = from.friends || [];
  to.friends = to.friends || [];
  if (from.friends.includes(to.id)) return { ok: false, error: 'الصديق موجود بالفعل' };
  if ((to.incomingRequests || []).includes(from.id)) return { ok: false, error: 'تم إرسال الطلب بالفعل' };
  if ((from.outgoingRequests || []).includes(to.id)) return { ok: false, error: 'تم إرسال الطلب بالفعل' };
  to.incomingRequests = to.incomingRequests || [];
  from.outgoingRequests = from.outgoingRequests || [];
  to.incomingRequests.push(from.id);
  from.outgoingRequests.push(to.id);
  saveDb();
  emitToPlayer(to.id, 'friends:request', { from: publicPlayer(from) });
  return { ok: true };
}

function acceptFriendRequest(playerId, friendId) {
  const player = playerById(playerId);
  const friend = playerById(friendId);
  if (!player || !friend) return { ok: false, error: 'ID غير موجود' };
  player.incomingRequests = (player.incomingRequests || []).filter((id) => id !== friend.id);
  friend.outgoingRequests = (friend.outgoingRequests || []).filter((id) => id !== player.id);
  player.friends = player.friends || [];
  friend.friends = friend.friends || [];
  if (!player.friends.includes(friend.id)) player.friends.push(friend.id);
  if (!friend.friends.includes(player.id)) friend.friends.push(player.id);
  saveDb();
  emitToPlayer(friend.id, 'friends:accepted', { friend: publicPlayer(player) });
  return { ok: true, friend: publicPlayer(friend) };
}

function rejectFriendRequest(playerId, friendId) {
  const player = playerById(playerId);
  const friend = playerById(friendId);
  if (!player || !friend) return { ok: false, error: 'ID غير موجود' };
  player.incomingRequests = (player.incomingRequests || []).filter((id) => id !== friend.id);
  friend.outgoingRequests = (friend.outgoingRequests || []).filter((id) => id !== player.id);
  saveDb();
  return { ok: true };
}

function friendsPublic(player) {
  return (player.friends || [])
    .map((id) => playerById(id))
    .filter(Boolean)
    .map(publicPlayer);
}

/* -------------------------------------------------------------------------- */
/* TOURNAMENT ENGINE                                                          */
/* -------------------------------------------------------------------------- */

function tournamentPublic(t, viewerId = '') {
  return {
    id: t.id,
    name: t.name,
    game: t.game,
    gameLabel: GAME_LABELS[t.game] || t.game,
    size: t.size,
    players: t.players.length,
    playersList: t.players.map((p) => ({ id: p.id, name: p.name })),
    status: t.status,
    createdAt: t.createdAt,
    joinCodesRemaining: (t.codes || []).filter((c) => !db.usedTournamentCodes[c]).length,
    codes: String(viewerId) === String(t.hostId || '') ? (t.codes || []).filter((c) => !db.usedTournamentCodes[c]) : undefined,
    bracket: t.bracket || [],
    champion: t.champion || null,
    isPrivate: !!t.isPrivate,
    currentRound: t.currentRound || 0
  };
}

function createTournament(name, game, size, host) {
  const id = 'T' + now().toString(36).toUpperCase() + crypto.randomBytes(3).toString('hex').toUpperCase();
  const codes = [];
  while (codes.length < size - 1) codes.push(newTournamentInviteCode());
  const tournament = {
    id,
    name: safeName(name || 'بطولة R2'),
    game: validGame(game),
    size,
    codes,
    hostId: host.id,
    players: [{ id: host.id, name: host.name }],
    status: 'open',
    createdAt: now(),
    updatedAt: now(),
    currentRound: 0,
    bracket: [],
    champion: null,
    isPrivate: false,
    rooms: {}
  };
  db.tournaments[id] = tournament;
  saveDb();
  return tournament;
}

function shufflePlayers(players) {
  const arr = [...players];
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = crypto.randomInt(0, i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function buildTournamentBracket(t) {
  const players = shufflePlayers(t.players);
  const matches = [];
  for (let i = 0; i < players.length; i += 2) {
    const a = players[i];
    const b = players[i + 1] || null;
    matches.push({
      id: `R1-${String(i / 2 + 1).padStart(2, '0')}`,
      round: 1,
      a,
      b,
      status: b ? 'pending' : 'bye',
      winner: b ? null : a,
      score: null,
      roomCode: null
    });
  }
  t.bracket = [matches];
  t.currentRound = 1;
  t.status = 'playing';
  t.updatedAt = now();
  resolveByes(t);
  saveDb();
  return t;
}

function resolveByes(t) {
  const round = t.bracket[t.bracket.length - 1];
  for (const match of round) {
    if (match.status === 'bye' && match.winner) match.status = 'done';
  }
  if (round.every((m) => m.status === 'done')) advanceTournamentRound(t);
}

function advanceTournamentRound(t) {
  const last = t.bracket[t.bracket.length - 1];
  if (!last || last.some((m) => m.status !== 'done')) return;
  if (last.length === 1) {
    t.champion = last[0].winner;
    t.status = 'finished';
    t.currentRound = last[0].round;
    const champion = playerById(t.champion?.id);
    if (champion) champion.stats.tournamentsWon = (champion.stats.tournamentsWon || 0) + 1;
    saveDb();
    io.emit('tournament:update', tournamentPublic(t));
    return;
  }
  const next = [];
  for (let i = 0; i < last.length; i += 2) {
    const a = last[i].winner;
    const b = last[i + 1]?.winner || null;
    next.push({
      id: `R${last[0].round + 1}-${String(i / 2 + 1).padStart(2, '0')}`,
      round: last[0].round + 1,
      a,
      b,
      status: b ? 'pending' : 'bye',
      winner: b ? null : a,
      score: null,
      roomCode: null
    });
  }
  t.bracket.push(next);
  t.currentRound = next[0].round;
  t.updatedAt = now();
  resolveByes(t);
  saveDb();
  io.emit('tournament:update', tournamentPublic(t));
}

function tournamentMatchResult(t, matchId, winnerId, score) {
  const match = t.bracket.flat().find((m) => m.id === matchId);
  if (!match) return { ok: false, error: 'المباراة غير موجودة' };
  if (match.status === 'done') return { ok: false, error: 'تم تسجيل النتيجة بالفعل' };
  if (![match.a?.id, match.b?.id].includes(winnerId)) return { ok: false, error: 'الفائز غير صالح' };
  match.winner = match.a.id === winnerId ? match.a : match.b;
  match.score = score || null;
  match.status = 'done';
  db.stats.tournamentMatches = (db.stats.tournamentMatches || 0) + 1;
  for (const p of [match.a, match.b]) {
    if (!p) continue;
    const player = playerById(p.id);
    if (player) player.stats.tournamentMatches = (player.stats.tournamentMatches || 0) + 1;
  }
  advanceTournamentRound(t);
  saveDb();
  return { ok: true, tournament: tournamentPublic(t) };
}

function startTournamentMatchRoom(t, match) {
  if (!match || !match.a || !match.b || match.status !== 'pending') return null;
  const aSocket = socketForPlayer(match.a.id);
  const bSocket = socketForPlayer(match.b.id);
  if (!aSocket || !bSocket) return null;
  const a = playerById(match.a.id);
  const b = playerById(match.b.id);
  const room = createRoom(t.game, '', aSocket, a);
  room.quickMatch = false;
  room.tournament = { id: t.id, matchId: match.id };
  joinRoomSocket(bSocket, room, b, '');
  aSocket.join(room.code);
  bSocket.join(room.code);
  room.status = 'connected';
  match.roomCode = room.code;
  t.rooms[match.id] = room.code;
  t.updatedAt = now();
  // Tournament matches auto-start as soon as both qualified players are connected.
  room.players.forEach(p => { p.ready = true; });
  maybeStartRoom(room);
  saveDb();
  io.to(room.code).emit('tournament:match-ready', {
    tournamentId: t.id,
    matchId: match.id,
    room: roomPublic(room)
  });
  return room;
}

function autoOpenTournamentMatches(t) {
  const current = t.bracket[t.bracket.length - 1] || [];
  for (const match of current) {
    if (match.status === 'pending' && !match.roomCode) startTournamentMatchRoom(t, match);
  }
}

/* -------------------------------------------------------------------------- */
/* DAILY / INBOX / DRAFT / REWARD SERVICES                                    */
/* -------------------------------------------------------------------------- */

const DAILY_TASK_TEMPLATES = [
  { id: 'play1', name: 'العب مباراة واحدة', target: 1 },
  { id: 'play3', name: 'العب 3 مباريات', target: 3 },
  { id: 'win1', name: 'حقق فوزًا واحدًا', target: 1 },
  { id: 'guess2', name: 'أجب إجابتين صحيحتين في تخمين اللاعب', target: 2 },
  { id: 'hard5', name: 'أنهِ 5 مباريات اليوم', target: 5 }
];
const DAILY_FIXED_REWARD = { xb: 30, points: 0, coins: 0, xp: 0 };
const DIVISION_REWARDS = { 9:45, 8:60, 7:83, 6:100, 5:124, 4:150, 3:179, 2:200, 1:250 };

const SHARED_PLAYER_CATALOG = (() => {
  try {
    const file = path.join(PUBLIC_DIR, 'players.json');
    if (fs.existsSync(file)) {
      const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
      return Object.values(parsed).flat().filter(p => p && p.name && p.pos && Number.isFinite(Number(p.rating)));
    }
  } catch (e) { console.warn('[CATALOG] players.json unavailable:', e.message); }
  return [];
})();

const DRAFT_POOL = [
  {
    "name": "ايميليانو مارنيتنيز",
    "pos": "GK",
    "rating": 98,
    "type": "حدث CHAMPIONS"
  },
  {
    "name": "مانويل نوير",
    "pos": "GK",
    "rating": 99,
    "type": "حالي"
  },
  {
    "name": "مارك اندريه تير شتيغين",
    "pos": "GK",
    "rating": 98,
    "type": "حالي"
  },
  {
    "name": "روبرت سانشيز",
    "pos": "GK",
    "rating": 84,
    "type": "حالي"
  },
  {
    "name": "اليكس ميريت",
    "pos": "GK",
    "rating": 80,
    "type": "حالي"
  },
  {
    "name": "ليف ياشين",
    "pos": "GK",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "جانلويجى بوفون",
    "pos": "GK",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "ايكر كاسياس",
    "pos": "GK",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "بيتر تشيك",
    "pos": "GK",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "بيتر شمايكل",
    "pos": "GK",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "إدوين فاندار سار",
    "pos": "GK",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "ديفيد دى خيا",
    "pos": "GK",
    "rating": 98,
    "type": "حالي"
  },
  {
    "name": "تيبوا كورتوا",
    "pos": "GK",
    "rating": 98,
    "type": "حالي"
  },
  {
    "name": "اليسون بيكر",
    "pos": "GK",
    "rating": 97,
    "type": "حالي"
  },
  {
    "name": "ديدا",
    "pos": "GK",
    "rating": 97,
    "type": "أيكونز ICON"
  },
  {
    "name": "إديرسون",
    "pos": "GK",
    "rating": 95,
    "type": "حالي"
  },
  {
    "name": "جانلويجى دوناروما",
    "pos": "GK",
    "rating": 94,
    "type": "حالي"
  },
  {
    "name": "ديفيد رايا",
    "pos": "GK",
    "rating": 94,
    "type": "حالي"
  },
  {
    "name": "عصام الحضرى",
    "pos": "GK",
    "rating": 93,
    "type": "أيكونز ICON"
  },
  {
    "name": "محمد الشناوى",
    "pos": "GK",
    "rating": 89,
    "type": "حالي"
  },
  {
    "name": "مصطفى شوبير",
    "pos": "GK",
    "rating": 87,
    "type": "حالي"
  },
  {
    "name": "أحمد الشناوى",
    "pos": "GK",
    "rating": 82,
    "type": "حالي"
  },
  {
    "name": "اندريه اونانا",
    "pos": "GK",
    "rating": 79,
    "type": "حالي"
  },
  {
    "name": "أشلى كول",
    "pos": "LB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "ثيو هيرناندز",
    "pos": "LB",
    "rating": 92,
    "type": "حالي"
  },
  {
    "name": "ألفونسو ديفيز",
    "pos": "LB",
    "rating": 92,
    "type": "حالي"
  },
  {
    "name": "ديماركو",
    "pos": "LB",
    "rating": 92,
    "type": "حالي"
  },
  {
    "name": "بالدى",
    "pos": "LB",
    "rating": 86,
    "type": "حالي"
  },
  {
    "name": "ميندى",
    "pos": "LB",
    "rating": 82,
    "type": "حالي"
  },
  {
    "name": "روبيرتو كارلوس",
    "pos": "LB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "مارسيلو",
    "pos": "LB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "فيليب لام",
    "pos": "LB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "زامبيروتا",
    "pos": "LB",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "نونو مينديش",
    "pos": "LB",
    "rating": 95,
    "type": "حالي"
  },
  {
    "name": "مارك كوكوريا",
    "pos": "LB",
    "rating": 95,
    "type": "حالي"
  },
  {
    "name": "أحمد فتوح",
    "pos": "LB",
    "rating": 83,
    "type": "حالي"
  },
  {
    "name": "هاتو",
    "pos": "LB",
    "rating": 78,
    "type": "حالي"
  },
  {
    "name": "سيرجيو راموس",
    "pos": "CB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "اليساندرو نيستا",
    "pos": "CB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "رونالد كومان",
    "pos": "CB",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "روبن دياس",
    "pos": "CB",
    "rating": 90,
    "type": "حالي"
  },
  {
    "name": "رونالد اراوخو",
    "pos": "CB",
    "rating": 84,
    "type": "حالي"
  },
  {
    "name": "باولو مالدينى",
    "pos": "CB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "فيرجيل فان دايك",
    "pos": "CB",
    "rating": 99,
    "type": "حالي"
  },
  {
    "name": "فرانز بيكنباور",
    "pos": "CB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "فرانكو باريزى",
    "pos": "CB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "فابيو كانفارو",
    "pos": "CB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "كيلينى",
    "pos": "CB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "بوبى مور",
    "pos": "CB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "ريو فيرديناند",
    "pos": "CB",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "جون تيرى",
    "pos": "CB",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "جابريال مجاليش",
    "pos": "CB",
    "rating": 95,
    "type": "حالي"
  },
  {
    "name": "ويليان ساليبا",
    "pos": "CB",
    "rating": 94,
    "type": "حالي"
  },
  {
    "name": "دين هاوسين",
    "pos": "CB",
    "rating": 93,
    "type": "حالي"
  },
  {
    "name": "ابراهيما كوناتى",
    "pos": "CB",
    "rating": 92,
    "type": "حالي"
  },
  {
    "name": "ماركينيوس",
    "pos": "CB",
    "rating": 93,
    "type": "حالي"
  },
  {
    "name": "وائل جمعة",
    "pos": "CB",
    "rating": 93,
    "type": "أيكونز ICON"
  },
  {
    "name": "إبراهيم حسن",
    "pos": "CB",
    "rating": 93,
    "type": "أيكونز ICON"
  },
  {
    "name": "ياسر ابراهيم",
    "pos": "CB",
    "rating": 84,
    "type": "حالي"
  },
  {
    "name": "رامى رابيعا",
    "pos": "CB",
    "rating": 83,
    "type": "حالي"
  },
  {
    "name": "إريك داير",
    "pos": "CB",
    "rating": 80,
    "type": "حالي"
  },
  {
    "name": "هارى ماجواير",
    "pos": "CB",
    "rating": 78,
    "type": "حالي"
  },
  {
    "name": "كارلوس البيرتو",
    "pos": "RB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "ليليان تورام",
    "pos": "RB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "غارى نيفيل",
    "pos": "RB",
    "rating": 97,
    "type": "أيكونز ICON"
  },
  {
    "name": "أشرف حكيمى",
    "pos": "RB",
    "rating": 95,
    "type": "حالي"
  },
  {
    "name": "كافو",
    "pos": "RB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "زانيتى",
    "pos": "RB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "دانيل كارفاخال",
    "pos": "RB",
    "rating": 99,
    "type": "حالي"
  },
  {
    "name": "دانى الفيس",
    "pos": "RB",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "ارنولد",
    "pos": "RB",
    "rating": 95,
    "type": "حالي"
  },
  {
    "name": "نصير مازراوى",
    "pos": "RB",
    "rating": 85,
    "type": "حالي"
  },
  {
    "name": "محمد هانى",
    "pos": "RB",
    "rating": 83,
    "type": "حالي"
  },
  {
    "name": "ديجو دالوت",
    "pos": "RB",
    "rating": 80,
    "type": "حالي"
  },
  {
    "name": "فرانك لامبارد",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "استيفين جيرارد",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "اندريا بيرلو",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "بول سكولز",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "كاى جوندوجان",
    "pos": "CM",
    "rating": 91,
    "type": "حالي"
  },
  {
    "name": "كارلوس سولير",
    "pos": "CM",
    "rating": 80,
    "type": "حالي"
  },
  {
    "name": "زين الدين زيدان",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "رود خوليت",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "لوثار ماتيوس",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "باتريك فييرا",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "تونى كروس",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "اندريس انيستا",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "لوكا مودريتش",
    "pos": "CM",
    "rating": 99,
    "type": "حالي"
  },
  {
    "name": "اتشافى هيرناندز",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "اتشابى الونسو",
    "pos": "CM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "مايكل بالاك",
    "pos": "CM",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "كلارنس سيدروف",
    "pos": "CM",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "فرانك رايكارد",
    "pos": "CM",
    "rating": 98,
    "type": "أيكونز ICON"
  },
  {
    "name": "جود بيلنجهام",
    "pos": "CM",
    "rating": 96,
    "type": "حالي"
  },
  {
    "name": "بيدرى",
    "pos": "CM",
    "rating": 96,
    "type": "حالي"
  },
  {
    "name": "بيرناندو سيلفا",
    "pos": "CM",
    "rating": 94,
    "type": "حالي"
  },
  {
    "name": "الخطيب",
    "pos": "CM",
    "rating": 94,
    "type": "أيكونز ICON"
  },
  {
    "name": "جافى",
    "pos": "CM",
    "rating": 92,
    "type": "حالي"
  },
  {
    "name": "إمام عاشور",
    "pos": "CM",
    "rating": 87,
    "type": "حالي"
  },
  {
    "name": "يوهان كرويف",
    "pos": "CAM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "كاكا",
    "pos": "CAM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "ديجو مارادونا",
    "pos": "CAM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "زيكو",
    "pos": "CAM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "روبيرت باجيو",
    "pos": "CAM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "ميشيل بلاتينى",
    "pos": "CAM",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "جورجى هاجى",
    "pos": "CAM",
    "rating": 97,
    "type": "أيكونز ICON"
  },
  {
    "name": "كيفين دى بروين",
    "pos": "CAM",
    "rating": 97,
    "type": "حالي"
  },
  {
    "name": "فلوريان فيرتز",
    "pos": "CAM",
    "rating": 95,
    "type": "حالي"
  },
  {
    "name": "جمال موسيالا",
    "pos": "CAM",
    "rating": 94,
    "type": "حالي"
  },
  {
    "name": "ايسكو",
    "pos": "CAM",
    "rating": 91,
    "type": "حالي"
  },
  {
    "name": "فيليبى كوتينيو",
    "pos": "CAM",
    "rating": 90,
    "type": "حالي"
  },
  {
    "name": "ديلى الى",
    "pos": "CAM",
    "rating": 81,
    "type": "حالي"
  },
  {
    "name": "لينغارد",
    "pos": "CAM",
    "rating": 79,
    "type": "حالي"
  },
  {
    "name": "ديسير دوى",
    "pos": "RW",
    "rating": 100,
    "type": "حدث CHAMPIONS"
  },
  {
    "name": "ليونيل ميسي",
    "pos": "RW",
    "rating": 99,
    "type": "حالي"
  },
  {
    "name": "لويس فيجو",
    "pos": "RW",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "جورج بيست",
    "pos": "RW",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "محمد صلاح",
    "pos": "RW",
    "rating": 99,
    "type": "حالي"
  },
  {
    "name": "جارينشيا",
    "pos": "RW",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "جارزينيو",
    "pos": "RW",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "بوكايو ساكا",
    "pos": "RW",
    "rating": 85,
    "type": "حالي"
  },
  {
    "name": "لامين يامال",
    "pos": "RW",
    "rating": 87,
    "type": "حالي"
  },
  {
    "name": "عثمان ديمبيلى",
    "pos": "RW",
    "rating": 87,
    "type": "حالي"
  },
  {
    "name": "مايكل اوليسي",
    "pos": "RW",
    "rating": 87,
    "type": "حالي"
  },
  {
    "name": "أنتونى",
    "pos": "RW",
    "rating": 83,
    "type": "حالي"
  },
  {
    "name": "سيرج غنابرى",
    "pos": "RW",
    "rating": 82,
    "type": "حالي"
  },
  {
    "name": "سانشو",
    "pos": "RW",
    "rating": 80,
    "type": "حالي"
  },
  {
    "name": "كفارتسخيليا",
    "pos": "LW",
    "rating": 100,
    "type": "حدث CHAMPIONS"
  },
  {
    "name": "كريستيانو رونالدو",
    "pos": "LW",
    "rating": 99,
    "type": "حالي"
  },
  {
    "name": "نيمار",
    "pos": "LW",
    "rating": 99,
    "type": "حالي"
  },
  {
    "name": "رونالدينيو",
    "pos": "LW",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "ريفالدو",
    "pos": "LW",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "هازارد",
    "pos": "LW",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "فينيسيوس جونيور",
    "pos": "LW",
    "rating": 96,
    "type": "حالي"
  },
  {
    "name": "ماركوس راشفورد",
    "pos": "LW",
    "rating": 82,
    "type": "حالي"
  },
  {
    "name": "انسوا فاتى",
    "pos": "LW",
    "rating": 80,
    "type": "حالي"
  },
  {
    "name": "رحيم سترلينح",
    "pos": "LW",
    "rating": 80,
    "type": "حالي"
  },
  {
    "name": "رونالدو الظاهرة",
    "pos": "ST",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "فان باستين",
    "pos": "ST",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "غيرد مولر",
    "pos": "ST",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "اوزيبيو",
    "pos": "ST",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "تييرى هنرى",
    "pos": "ST",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "كريم بنزيما",
    "pos": "ST",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "زلاتان ابراهيموفيتش",
    "pos": "ST",
    "rating": 99,
    "type": "أيكونز ICON"
  },
  {
    "name": "كيليان امبابى",
    "pos": "ST",
    "rating": 98,
    "type": "حالي"
  },
  {
    "name": "هارى كين",
    "pos": "ST",
    "rating": 97,
    "type": "حالي"
  },
  {
    "name": "فيكتور جيوكيريس",
    "pos": "ST",
    "rating": 95,
    "type": "حالي"
  },
  {
    "name": "لوكاكو",
    "pos": "ST",
    "rating": 84,
    "type": "حالي"
  },
  {
    "name": "الفارو موراتا",
    "pos": "ST",
    "rating": 82,
    "type": "حالي"
  }
];
function dayKey() {
  const d = new Date(Date.now() + 3 * 60 * 60 * 1000);
  return d.toISOString().slice(0, 10);
}

const DAILY_REWARD_POOLS = {
  easy: [
    { xb: 10, points: 250, coins: 250, xp: 10 },
    { xb: 12, points: 300, coins: 300, xp: 12 },
    { xb: 15, points: 350, coins: 350, xp: 15 }
  ],
  medium: [
    { xb: 20, points: 450, coins: 600, xp: 18 },
    { xb: 25, points: 600, coins: 750, xp: 20 },
    { xb: 30, points: 700, coins: 900, xp: 25 }
  ],
  hard: [
    { xb: 40, points: 800, coins: 1200, xp: 30 },
    { xb: 50, points: 1000, coins: 1500, xp: 35 },
    { xb: 60, points: 1250, coins: 1800, xp: 40 }
  ]
};
function randomReward(level) {
  const pool = DAILY_REWARD_POOLS[level] || DAILY_REWARD_POOLS.easy;
  return clone(pool[crypto.randomInt(0, pool.length)]);
}
function getDaily(player) {
  const key = dayKey();
  if (!player.daily || player.daily.date !== key) {
    player.daily = { date: key, tasks: DAILY_TASK_TEMPLATES.map((t, i) => ({
      ...clone(t), progress: 0, claimed: false, difficulty: i < 2 ? 'easy' : (i < 4 ? 'medium' : 'hard'), reward: { ...DAILY_FIXED_REWARD }
    })) };
    player.updatedAt = now();
    saveDb();
  }
  return player.daily;
}

function dailyPublic(player) {
  const daily = getDaily(player);
  return { date: daily.date, tasks: daily.tasks.map(t => ({ id:t.id, name:t.name, target:t.target, progress:Math.min(t.target,t.progress||0), claimed:!!t.claimed, difficulty:t.difficulty || 'متوسط', reward:t.reward })) };
}

function advanceDaily(player, event, amount = 1) {
  const daily = getDaily(player);
  for (const task of daily.tasks) {
    const hit = (task.id === 'play1' && event === 'game') ||
      (task.id === 'play3' && event === 'game') ||
      (task.id === 'win1' && event === 'win') ||
      (task.id === 'guess2' && event === 'guess') ||
      (task.id === 'hard5' && event === 'game');
    if (hit && !task.claimed) task.progress = Math.min(task.target, (task.progress || 0) + amount);
  }
}

function claimDailyTask(player, taskId) {
  const daily = getDaily(player);
  const task = daily.tasks.find(t => t.id === taskId);
  if (!task) return { ok:false, error:'المهمة غير موجودة' };
  if (task.claimed) return { ok:false, error:'المكافأة مستلمة بالفعل' };
  if ((task.progress || 0) < task.target) return { ok:false, error:'المهمة لم تكتمل بعد' };
  task.claimed = true;
  updatePlayerResources(player, task.reward);
  saveDb();
  return { ok:true, task, player:publicPlayer(player), daily:dailyPublic(player) };
}

function draftCandidates(player, count = 1) {
  player.ownedPlayers = player.ownedPlayers || [];
  const owned = new Set(player.ownedPlayers.map(x => x.name));
  const catalog = SHARED_PLAYER_CATALOG.length ? SHARED_PLAYER_CATALOG : DRAFT_POOL;
  const available = catalog.filter(p => !owned.has(p.name));
  const pool = [...available];
  for (let i=pool.length-1;i>0;i--) { const j=crypto.randomInt(0,i+1); [pool[i],pool[j]]=[pool[j],pool[i]]; }
  return pool.slice(0, Math.max(1, Math.min(10,count)));
}

function claimWelcome(player) {
  player.rewardClaims = player.rewardClaims || {};
  if (player.rewardClaims.welcome_v1) return { ok:true, duplicate:true, player:publicPlayer(player) };
  player.rewardClaims.welcome_v1 = now();
  player.points = Math.max(0, Number(player.points || 0)) + 3000;
  player.freeDrafts = Math.max(0, Number(player.freeDrafts || 0)) + 1;
  saveDb();
  return { ok:true, duplicate:false, reward:{ points:3000, freeDrafts:1 }, player:publicPlayer(player) };
}

function completeGameForPlayer(player, game, claimKey, result = {}) {
  const key = `single:${player.id}:${String(claimKey || (game + ':' + now())).slice(0,120)}`;
  const score = result.score && Number.isInteger(result.score.home) && Number.isInteger(result.score.away)
    ? { home: result.score.home, away: result.score.away } : randomMatchScore();
  let winnerId = null;
  if (score.home !== score.away) winnerId = score.home > score.away ? player.id : null;
  const reward = claimReward(player.id, key, STANDARD_GAME_REWARD);
  if (!reward.duplicate) {
    player.stats.gamesPlayed = (player.stats.gamesPlayed || 0) + 1;
    if (winnerId) player.stats.gamesWon = (player.stats.gamesWon || 0) + 1;
    else if (score.home === score.away) player.stats.gamesDrawn = (player.stats.gamesDrawn || 0) + 1;
    else player.stats.gamesLost = (player.stats.gamesLost || 0) + 1;
    advanceDaily(player, 'game', 1);
    if (winnerId) advanceDaily(player, 'win', 1);
  }
  return { ok:true, duplicate:!!reward.duplicate, reward:reward.reward, player:publicPlayer(player), score, stats:player.stats, matchSummary:{ captain:null, wildcard:null } };
}

app.post('/api/player/single-complete', (req,res) => {
  const player=playerById(String(req.body?.playerId||''));
  if(!player)return res.status(404).json({ok:false,error:'اللاعب غير موجود'});
  const result=completeGameForPlayer(player,validGame(req.body?.game),req.body?.claimKey,req.body?.result||{});
  res.status(200).json(result);
});

/* -------------------------------------------------------------------------- */
/* SERVER AUTHORITATIVE EVENTS                                               */
/* -------------------------------------------------------------------------- */

const EVENT_REWARDS = {
  1: { xb: 150, points: 3000, coins: 500, freeDrafts: 1 },
  2: { xb: 200, points: 4500, coins: 6000, freeDrafts: 2 }
};
const EVENT_LENGTHS = { 1: 5, 2: 7 };
function ensureEvents(player) {
  const key = dayKey();
  if (!player.events || player.events.date !== key) {
    player.events = { date: key, weeks: {}, claimed: {} };
    for (const week of [1,2]) {
      const count = EVENT_LENGTHS[week];
      player.events.weeks[week] = { games: Array.from({length: count}, (_, i) => ({ id: i + 1, game: GAME_NAMES[(i + week) % GAME_NAMES.length], done: false })), done: 0 };
      player.events.claimed[week] = false;
    }
    saveDb();
  }
  return player.events;
}
function eventsPublic(player) {
  const e = ensureEvents(player);
  return clone(e);
}
function claimEventProgress(player, week) {
  const e = ensureEvents(player);
  const w = e.weeks[String(week)] || e.weeks[week];
  if (!w || w.done >= w.games.length) return { ok:false, error:'الأسبوع مكتمل بالفعل' };
  const item = w.games[w.done];
  item.done = true; w.done += 1;
  // Completing an event match only advances the event. Rewards are claimed later.
  advanceDaily(player, 'game', 1);
  if (w.done >= w.games.length) saveDb();
  saveDb();
  return { ok:true, events:eventsPublic(player), player:publicPlayer(player), progress:w.done, total:w.games.length };
}
function claimEventFinal(player, week) {
  const e = ensureEvents(player); const w=e.weeks[String(week)]||e.weeks[week];
  if(!w || w.done<w.games.length)return {ok:false,error:'أكمل كل مباريات الأسبوع أولًا'};
  if(e.claimed[String(week)]||e.claimed[week])return {ok:false,error:'تم استلام مكافأة الأسبوع بالفعل'};
  const reward=EVENT_REWARDS[week];
  updatePlayerResources(player,reward);
  e.claimed[week]=true; saveDb();
  return {ok:true,reward,events:eventsPublic(player),player:publicPlayer(player)};
}

/* -------------------------------------------------------------------------- */
/* AUTHORITATIVE GAME CATALOG / DECKS                                        */
/* -------------------------------------------------------------------------- */
const GAME_POSITIONS = {
  auction: ['GK','LB','CB','CB','RB','CM','CM','CAM','RW','LW','ST'],
  five: ['GK','CB','CM','CAM','ST'],
  blind: ['GK','LB','CB','CB','RB','CM','CM','CAM','RW','LW','ST'],
  deal: ['GK','LB','CB','CB','RB','CM','CM','CAM','RW','LW','ST'],
  hidden: ['GK','LB','CB','CB','RB','CM','CM','CAM','RW','LW','ST']
};
function buildAuthoritativeDeck(game, count = 4) {
  const catalog = SHARED_PLAYER_CATALOG.length ? SHARED_PLAYER_CATALOG : DRAFT_POOL;
  const byPos = {};
  for (const p of catalog) (byPos[p.pos] ||= []).push(p);
  const positions = GAME_POSITIONS[validGame(game)] || GAME_POSITIONS.auction;
  const deck = {};
  for (const pos of new Set(positions)) {
    const pool = [...(byPos[pos] || [])];
    for (let i = pool.length - 1; i > 0; i--) { const j = crypto.randomInt(0, i + 1); [pool[i], pool[j]] = [pool[j], pool[i]]; }
    deck[pos] = pool.slice(0, Math.max(2, count)).map(p => clone(p));
  }
  return deck;
}
function ensureRoomDeck(room) {
  room.state.data = room.state.data || {};
  if (!room.state.data.authoritativeDeck) {
    room.state.data.authoritativeDeck = buildAuthoritativeDeck(room.game, 6);
    room.state.revision += 1;
    persistRoom(room);
  }
  return room.state.data.authoritativeDeck;
}

/* -------------------------------------------------------------------------- */
/* HTTP API                                                                   */
/* -------------------------------------------------------------------------- */

app.post('/api/player/name', (req,res)=>{
  const player=playerById(String(req.body?.playerId||''));
  if(!player)return res.status(404).json({ok:false,error:'اللاعب غير موجود'});
  const name=safeName(req.body?.name);
  if(!name || name==='لاعب')return res.status(400).json({ok:false,error:'اكتب اسمًا صالحًا'});
  player.name=name; player.updatedAt=now();
  for(const r of rooms.values()){
    const member=r.players.find(p=>p.playerId===player.id);
    if(member){ member.name=name; member.updatedAt=now(); broadcastRoom(r,'room:players'); }
  }
  saveDb();
  res.json({ok:true,player:publicPlayer(player)});
});

app.get('/api/leaderboard', (req,res)=>{
  const limit=Math.min(100,Math.max(1,Number(req.query.limit||50)));
  const players=Object.values(db.players||{}).map(p=>publicPlayer(p))
    .sort((a,b)=>Number(b.xb||0)-Number(a.xb||0))
    .slice(0,limit)
    .map((p,i)=>({...p,position:i+1}));
  res.set('Cache-Control','no-store').json({ok:true,leaderboard:players});
});

app.get('/api/ranked/:id', (req,res)=>{
  const player=playerById(req.params.id);
  if(!player)return res.status(404).json({ok:false,error:'اللاعب غير موجود'});
  res.json({ok:true,ranked:rankedPublic(player)});
});

app.get('/api/health', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({
    ok: true,
    version: APP_VERSION,
    server: 'R2 GAMES WORLD SERVER',
    authoritative: true,
    persistence: { type: 'json-snapshot', async: true, lastPersistAt },
    rooms: rooms.size,
    quickQueue: quickQueue.size,
    tournaments: Object.keys(db.tournaments).length,
    activeRooms: rooms.size,
    onlinePlayers: onlinePlayers.size,
    memory: { rss: process.memoryUsage().rss, heapUsed: process.memoryUsage().heapUsed },
    limits: { maxActiveRooms: MAX_ACTIVE_ROOMS, maxTournaments: MAX_TOURNAMENTS, maxPlayersSnapshot: MAX_PLAYERS_PER_SERVER_SNAPSHOT },
    players: Object.keys(db.players).length,
    catalogPlayers: SHARED_PLAYER_CATALOG.length || DRAFT_POOL.length,
    online: onlinePlayers.size,
    uptime: Math.round(process.uptime()),
    time: now()
  });
});

app.get('/api/config', (req, res) => {
  res.json({
    ok: true,
    version: APP_VERSION,
    games: GAME_NAMES.map((id) => ({ id, name: GAME_LABELS[id] })),
    tournamentSizes: TOURNAMENT_SIZES,
    roomCodeLength: 8,
    playerIdLength: 16,
    multiplayer: true,
    serverAuthoritative: true
  });
});

app.get('/api/rooms/:code/game/deck', (req, res) => {
  const room = findRoom(req.params.code);
  if (!room) return res.status(404).json({ error: 'كود الغرفة غير موجود' });
  if (!playerInRoom(room, String(req.query.playerId || ''))) return res.status(403).json({ error: 'اللاعب ليس داخل الغرفة' });
  const deck = ensureRoomDeck(room);
  res.set('Cache-Control', 'no-store').json({ ok: true, game: room.game, revision: room.state.revision, deck });
});

app.post('/api/player/init', (req, res) => {
  const player = ensurePlayer(req.body?.playerId, req.body?.name);
  res.json({ ok: true, player: publicPlayer(player) });
});

app.post('/api/player/welcome', (req, res) => {
  const player = ensurePlayer(req.body?.playerId, req.body?.name);
  const result = claimWelcome(player);
  res.json(result);
});

app.get('/api/daily/:id', (req, res) => {
  const player = playerById(req.params.id);
  if (!player) return res.status(404).json({ error:'اللاعب غير موجود' });
  res.json({ ok:true, daily:dailyPublic(player) });
});

app.post('/api/daily/claim', (req, res) => {
  const player = playerById(String(req.body?.playerId || ''));
  if (!player) return res.status(404).json({ error:'اللاعب غير موجود' });
  const result = claimDailyTask(player, String(req.body?.taskId || ''));
  res.status(result.ok ? 200 : 400).json(result);
});

app.get('/api/events/:id', (req, res) => {
  const player=playerById(req.params.id); if(!player)return res.status(404).json({error:'اللاعب غير موجود'});
  res.json({ok:true,events:eventsPublic(player)});
});
app.post('/api/events/progress', (req,res)=>{
  const player=playerById(String(req.body?.playerId||'')); if(!player)return res.status(404).json({error:'اللاعب غير موجود'});
  const result=claimEventProgress(player,Number(req.body?.week)); res.status(result.ok?200:400).json(result);
});
app.post('/api/events/claim', (req,res)=>{
  const player=playerById(String(req.body?.playerId||'')); if(!player)return res.status(404).json({error:'اللاعب غير موجود'});
  const result=claimEventFinal(player,Number(req.body?.week)); res.status(result.ok?200:400).json(result);
});

app.get('/api/match-requests/:id', (req,res)=>{
  const player=playerById(req.params.id);
  if(!player)return res.status(404).json({error:'اللاعب غير موجود'});
  const requests=(player.matchRequests||[]).filter(x=>Number(x.expiresAt||0)>now()).map(x=>({...x,from:publicPlayer(playerById(x.fromId))})).filter(x=>x.from);
  player.matchRequests=requests.map(x=>({id:x.id,fromId:x.fromId,game:x.game,createdAt:x.createdAt,expiresAt:x.expiresAt}));
  res.json({ok:true,requests});
});

app.get('/api/inbox/:id', (req, res) => {
  const player = playerById(req.params.id);
  if (!player) return res.status(404).json({ error:'اللاعب غير موجود' });
  const matchRequests=(player.matchRequests||[]).filter(x=>Number(x.expiresAt||0)>now()).map(x=>({...x,from:publicPlayer(playerById(x.fromId))})).filter(x=>x.from);
  res.json({ ok:true, incomingRequests:(player.incomingRequests||[]).map(playerById).filter(Boolean).map(publicPlayer), matchRequests, welcomeAvailable:!player.rewardClaims?.welcome_v1 });
});

app.post('/api/draft/open-free', (req, res) => {
  const player = playerById(String(req.body?.playerId || ''));
  if (!player) return res.status(404).json({ error:'اللاعب غير موجود' });
  if ((player.freeDrafts || 0) < 1) return res.status(400).json({ error:'لا يوجد Draft مجاني' });
  const cards = draftCandidates(player, 3);
  if (!cards.length) return res.status(400).json({ error:'لا يوجد لاعب جديد متاح بدون تكرار' });
  player.pendingDraft = { id: crypto.randomBytes(10).toString('hex'), choices: cards, createdAt: now(), expiresAt: now() + 5 * 60 * 1000, free: true };
  saveDb();
  res.json({ ok:true, draftId: player.pendingDraft.id, choices: cards, player:publicPlayer(player) });
});

app.post('/api/draft/open-free/claim', (req, res) => {
  const player = playerById(String(req.body?.playerId || ''));
  if (!player) return res.status(404).json({ error:'اللاعب غير موجود' });
  const pending = player.pendingDraft;
  if (!pending || pending.id !== String(req.body?.draftId || '')) return res.status(400).json({ error:'الدرافت غير صالح أو انتهت صلاحيته' });
  if (pending.expiresAt && pending.expiresAt < now()) { delete player.pendingDraft; saveDb(); return res.status(400).json({ error:'انتهت صلاحية الـDraft، افتحه مرة أخرى' }); }
  if ((player.freeDrafts || 0) < 1) return res.status(400).json({ error:'لا يوجد Draft مجاني' });
  const index = Number.isInteger(Number(req.body?.index)) ? Number(req.body.index) : 0;
  const choice = pending.choices[Math.max(0, Math.min(pending.choices.length - 1, index))];
  if (!choice) return res.status(400).json({ error:'اللاعب المختار غير موجود' });
  player.ownedPlayers = player.ownedPlayers || [];
  if (player.ownedPlayers.some(x => x.name === choice.name)) return res.status(409).json({ error:'هذا اللاعب موجود بالفعل' });
  player.freeDrafts -= 1;
  player.ownedPlayers.push(choice);
  delete player.pendingDraft;
  player.updatedAt = now();
  saveDb();
  res.json({ ok:true, card:choice, player:publicPlayer(player) });
});

app.post('/api/draft/open-paid', (req, res) => {
  const player = playerById(String(req.body?.playerId || ''));
  const count = Number(req.body?.count || 1);
  const prices = { 1: 2000, 5: 9750, 10: 17500 };
  if (!player) return res.status(404).json({ error:'اللاعب غير موجود' });
  if (!prices[count]) return res.status(400).json({ error:'حجم Draft غير صالح' });
  const price = prices[count];
  if (Number(player.points || 0) < price) return res.status(400).json({ error:'POINTS لا تكفي لهذا الـDraft' });
  const choices = draftCandidates(player, count === 1 ? 3 : count);
  if (choices.length < (count === 1 ? 3 : count)) return res.status(400).json({ error:'لا يوجد عدد كافٍ من اللاعبين الجدد بدون تكرار' });
  player.pendingDraft = { id: crypto.randomBytes(10).toString('hex'), choices, count, price, free:false, createdAt:now(), expiresAt:now()+5*60*1000 };
  saveDb();
  res.json({ ok:true, draftId:player.pendingDraft.id, price, count, choices, player:publicPlayer(player) });
});

app.post('/api/draft/open-paid/claim', (req,res)=>{
  const player=playerById(String(req.body?.playerId||''));
  if(!player)return res.status(404).json({error:'اللاعب غير موجود'});
  const pending=player.pendingDraft;
  if(!pending || pending.free || pending.id!==String(req.body?.draftId||''))return res.status(400).json({error:'الدرافت غير صالح أو انتهت صلاحيته'});
  if(pending.expiresAt && pending.expiresAt<now()){delete player.pendingDraft;saveDb();return res.status(400).json({error:'انتهت صلاحية الـDraft، افتحه مرة أخرى'});}
  if(Number(player.points||0)<Number(pending.price||0))return res.status(400).json({error:'POINTS لا تكفي لهذا الـDraft'});
  const idx=Math.max(0,Math.min(pending.choices.length-1,Number(req.body?.index||0)));
  const choice=pending.choices[idx]; if(!choice)return res.status(400).json({error:'اللاعب المختار غير موجود'});
  player.ownedPlayers=player.ownedPlayers||[];
  if(player.ownedPlayers.some(x=>x.name===choice.name))return res.status(409).json({error:'هذا اللاعب موجود بالفعل'});
  player.points-=Number(pending.price||0);
  player.ownedPlayers.push(choice);
  delete player.pendingDraft; player.updatedAt=now(); saveDb();
  res.json({ok:true,price:Number(pending.price||0),card:choice,player:publicPlayer(player)});
});

function marketPrice(p){
  const rating=Number(p.rating||0);
  const base=Math.max(25000, Math.round(Math.pow(Math.max(1,rating-55),2.15)*180));
  return Math.min(1000000, Math.max(25000, Math.round(base/1000)*1000));
}
app.get('/api/market/:id', (req,res)=>{
  const player=playerById(req.params.id); if(!player)return res.status(404).json({error:'اللاعب غير موجود'});
  const owned=new Set((player.ownedPlayers||[]).map(x=>x.name));
  const catalog=SHARED_PLAYER_CATALOG.length?SHARED_PLAYER_CATALOG:DRAFT_POOL;
  const list=catalog.filter(p=>!owned.has(p.name)).slice(0,200).map(p=>({...p,price:marketPrice(p)}));
  res.json({ok:true,players:list,player:publicPlayer(player)});
});
app.post('/api/market/buy',(req,res)=>{
  const player=playerById(String(req.body?.playerId||'')); if(!player)return res.status(404).json({error:'اللاعب غير موجود'});
  const name=String(req.body?.playerName||''); const catalog=SHARED_PLAYER_CATALOG.length?SHARED_PLAYER_CATALOG:DRAFT_POOL;
  const card=catalog.find(p=>p.name===name); if(!card)return res.status(404).json({error:'اللاعب غير موجود في السوق'});
  player.ownedPlayers=player.ownedPlayers||[]; if(player.ownedPlayers.some(x=>x.name===name))return res.status(409).json({error:'هذا اللاعب موجود بالفعل'});
  const price=marketPrice(card); if(Number(player.coins||0)<price)return res.status(400).json({error:'MARKET COINS لا تكفي'});
  player.coins-=price; player.ownedPlayers.push(clone(card)); player.updatedAt=now(); saveDb();
  res.json({ok:true,price,card,player:publicPlayer(player)});
});

app.post('/api/game/complete', (req, res) => {
  const player = playerById(String(req.body?.playerId || ''));
  if (!player) return res.status(404).json({ error:'اللاعب غير موجود' });
  const result = completeGameForPlayer(player, validGame(req.body?.game), req.body?.claimKey, req.body?.result || {});
  saveDb();
  res.json(result);
});

app.get('/api/player/:id', (req, res) => {
  const player = playerById(req.params.id);
  if (!player) return res.status(404).json({ error: 'اللاعب غير موجود' });
  return res.json({ ok: true, player: publicPlayer(player) });
});

app.post('/api/player/profile', (req, res) => {
  const player = ensurePlayer(req.body?.playerId, req.body?.name);
  if (req.body?.name) player.name = safeName(req.body.name);
  if (typeof req.body?.avatar === 'string') player.avatar = req.body.avatar.slice(0, 2_000_000);
  saveDb();
  res.json({ ok: true, player: publicPlayer(player) });
});

app.post('/api/friends/add', (req, res) => {
  const player = ensurePlayer(req.body?.playerId, req.body?.name);
  const result = addFriendRequest(player.id, req.body?.friendId);
  res.status(result.ok ? 200 : 400).json(result);
});

app.post('/api/friends/accept', (req, res) => {
  const result = acceptFriendRequest(String(req.body?.playerId || ''), String(req.body?.friendId || ''));
  res.status(result.ok ? 200 : 400).json(result);
});

app.post('/api/friends/reject', (req, res) => {
  const result = rejectFriendRequest(String(req.body?.playerId || ''), String(req.body?.friendId || ''));
  res.status(result.ok ? 200 : 400).json(result);
});

app.get('/api/friends/:id', (req, res) => {
  const player = playerById(req.params.id);
  if (!player) return res.status(404).json({ error: 'اللاعب غير موجود' });
  res.json({
    ok: true,
    friends: friendsPublic(player),
    incomingRequests: (player.incomingRequests || []).map(playerById).filter(Boolean).map(publicPlayer),
    outgoingRequests: (player.outgoingRequests || []).map(playerById).filter(Boolean).map(publicPlayer)
  });
});

app.get('/api/rankings', (req, res) => {
  const players = Object.values(db.players)
    .sort((a, b) => (b.xb || 0) - (a.xb || 0))
    .slice(0, 100)
    .map(publicPlayer);
  res.json({ ok: true, players });
});

app.post('/api/rooms', (req, res) => {
  const game = validGame(req.body?.game);
  const player = ensurePlayer(req.body?.playerId, req.body?.name);
  const room = createRoom(game, req.body?.password, null, player, { name: req.body?.name, isPrivate: req.body?.isPrivate !== false });
  res.status(201).json({ ok: true, ...roomPublic(room) });
});

app.get('/api/rooms', (req,res) => res.json({ok:true, rooms:publicOpenRooms()}));

app.get('/api/rooms/:code', (req, res) => {
  const room = findRoom(req.params.code);
  if (!room) return res.status(404).json({ error: 'كود الغرفة غير موجود' });
  return res.json({ ok: true, ...roomPublic(room) });
});

app.post('/api/rooms/:code/join', (req, res) => {
  const room = findRoom(req.params.code);
  if (!room) return res.status(404).json({ error: 'كود الغرفة غير موجود' });
  const player = ensurePlayer(req.body?.playerId, req.body?.name);
  const fakeSocket = { id: null, join: () => {} };
  const result = joinRoomSocket(fakeSocket, room, player, req.body?.password);
  if (!result.ok) return res.status(400).json(result);
  room.updatedAt = now();
  saveDb();
  return res.json({ ok: true, ...roomPublic(room) });
});

app.post('/api/rooms/:code/play-now', (req, res) => {
  const room = findRoom(req.params.code);
  if (!room) return res.status(404).json({ error: 'الغرفة غير موجودة' });
  const player = playerInRoom(room, String(req.body?.playerId || ''));
  if (!player) return res.status(403).json({ error: 'اللاعب ليس داخل الغرفة' });
  if (room.players.length !== 2) return res.status(409).json({ error: 'انتظر اللاعب الثاني' });
  player.ready = true;
  room.status = 'ready';
  maybeStartRoom(room);
  saveDb();
  res.json({ ok: true, room: roomPublic(room) });
});

app.post('/api/quick-match/cancel', (req, res) => {
  removeQuickEntry(String(req.body?.playerId || ''));
  res.json({ ok: true });
});

app.post('/api/tournaments', (req, res) => {
  if (Object.keys(db.tournaments).length >= MAX_TOURNAMENTS) return res.status(503).json({ error: 'السيرفر ممتلئ مؤقتًا بالبطولات النشطة' });
  const size = Number(req.body?.size);
  if (!TOURNAMENT_SIZES.includes(size)) return res.status(400).json({ error: 'حجم بطولة غير صحيح' });
  const host = ensurePlayer(req.body?.playerId, req.body?.hostName || req.body?.name);
  const tournament = createTournament(req.body?.name, req.body?.game, size, host);
  tournament.isPrivate = !!req.body?.isPrivate;
  tournament.updatedAt = now();
  flushDbAsync();
  res.status(201).json({ ok: true, tournament: tournamentPublic(tournament, host.id), codes: tournament.codes });
});

app.post('/api/tournaments/join', (req, res) => {
  const code = clean(req.body?.code);
  const tournament = Object.values(db.tournaments).find((t) => t.codes.includes(code));
  if (!tournament) return res.status(404).json({ error: 'كود البطولة غير صحيح' });
  if (db.usedTournamentCodes[code]) return res.status(409).json({ error: 'الكود مستخدم بالفعل' });
  if (tournament.status !== 'open') return res.status(409).json({ error: 'البطولة اكتملت أو بدأت' });
  if (tournament.players.length >= tournament.size) return res.status(409).json({ error: 'البطولة ممتلئة' });
  const player = ensurePlayer(req.body?.playerId, req.body?.playerName || req.body?.name);
  if (tournament.players.some((p) => p.id === player.id)) return res.status(409).json({ error: 'أنت مسجل بالفعل' });
  db.usedTournamentCodes[code] = { tournamentId: tournament.id, playerId: player.id, usedAt: now() };
  tournament.players.push({ id: player.id, name: player.name });
  tournament.updatedAt = now();
  if (tournament.players.length === tournament.size) {
    buildTournamentBracket(tournament);
    autoOpenTournamentMatches(tournament);
  }
  saveDb();
  io.emit('tournament:update', tournamentPublic(tournament));
  res.json({ ok: true, tournament: tournamentPublic(tournament) });
});

app.get('/api/tournaments', (req, res) => {
  const viewerId = String(req.query?.playerId || '');
  const list = Object.values(db.tournaments).filter(t => !t.isPrivate || String(t.hostId || '') === viewerId)
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 100)
    .map(t => tournamentPublic(t, viewerId));
  res.json({ ok: true, tournaments: list });
});

app.get('/api/tournaments/:id', (req, res) => {
  const tournament = db.tournaments[req.params.id];
  if (!tournament) return res.status(404).json({ error: 'البطولة غير موجودة' });
  return res.json({ ok: true, tournament: tournamentPublic(tournament) });
});

app.post('/api/tournaments/:id/match/:matchId/result', (req, res) => {
  const tournament = db.tournaments[req.params.id];
  if (!tournament) return res.status(404).json({ error: 'البطولة غير موجودة' });
  const actorId = String(req.body?.playerId || '');
  const match = tournament.bracket.flat().find(m => m.id === req.params.matchId);
  if (!match) return res.status(404).json({ error: 'المباراة غير موجودة' });
  if (![match.a?.id, match.b?.id].includes(actorId)) return res.status(403).json({ error: 'أنت لست طرفًا في هذه المباراة' });
  const winnerId = String(req.body?.winnerId || '');
  if (![match.a?.id, match.b?.id].includes(winnerId)) return res.status(400).json({ error: 'الفائز غير صالح' });
  const result = tournamentMatchResult(tournament, req.params.matchId, winnerId, req.body?.score || null);
  if (!result.ok) return res.status(400).json(result);
  io.emit('tournament:update', tournamentPublic(tournament));
  autoOpenTournamentMatches(tournament);
  res.json(result);
});

/* -------------------------------------------------------------------------- */
/* NEWS ENGINE                                                                */
/* -------------------------------------------------------------------------- */

function decodeXml(value = '') {
  return String(value)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

function parseRss(xml, sourceName) {
  return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map((match) => {
    const block = match[1];
    const get = (tag) => {
      const found = block.match(new RegExp(`<${tag}(?: [^>]*)?>([\\s\\S]*?)<\\/${tag}>`, 'i'));
      return found ? decodeXml(found[1].trim()) : '';
    };
    return {
      title: get('title'),
      link: get('link'),
      source: sourceName || get('source'),
      publishedAt: get('pubDate'),
      description: get('description')
    };
  }).filter((item) => item.title && item.link);
}

const NEWS_SOURCES = [
  { name: 'FilGoal', query: 'site:filgoal.com football', direct: 'https://www.filgoal.com/home/rss' },
  { name: 'YallaKora', query: 'site:yallakora.com كرة القدم' },
  { name: 'GOAL', query: 'site:goal.com football' },
  { name: 'ESPN FC', query: 'site:espn.com/soccer football' },
  { name: 'Sky Sports Football', query: 'site:skysports.com/football football' },
  { name: 'FourFourTwo', query: 'site:fourfourtwo.com football' },
  { name: 'Kicker', query: 'site:kicker.de fußball' },
  { name: 'Marca', query: 'site:marca.com fútbol' },
  { name: 'L’Équipe', query: 'site:lequipe.fr football' }
];

function newsUrl(query) { const q=String(query||'')+' when:1d'; return 'https://news.google.com/rss/search?q='+encodeURIComponent(q)+'&hl=ar&gl=EG&ceid=EG:ar'; }

async function fetchNewsSource(source) {
  try {
    const target = source.direct || newsUrl(source.query);
    const response = await fetch(target, {
      headers: { 'user-agent': 'R2-GAMES-News/11.0' },
      signal: AbortSignal.timeout(8000)
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const xml = await response.text();
    return parseRss(xml, source.name).slice(0, 8);
  } catch (error) {
    console.warn('[NEWS]', source.name, error.message);
    return [];
  }
}

const translationCache = new Map();

async function translateToArabic(text) {
  const value = String(text || '').trim();
  if (!value || (/^[\u0600-\u06FF\s\d.,!?()\-]+$/.test(value))) return value;
  if (translationCache.has(value)) return translationCache.get(value);
  try {
    const url = 'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(value) + '&langpair=auto|ar';
    const response = await fetch(url, { signal: AbortSignal.timeout(3500), headers: { 'user-agent': 'R2-GAMES-News/11.1' } });
    if (!response.ok) return value;
    const json = await response.json();
    const translated = json?.responseData?.translatedText || value;
    translationCache.set(value, translated);
    if (translationCache.size > 1000) translationCache.delete(translationCache.keys().next().value);
    return translated;
  } catch (_) { return value; }
}

async function mapLimit(items, limit, worker) {
  const out = new Array(items.length);
  let cursor = 0;
  async function runner() {
    while (true) {
      const i = cursor++;
      if (i >= items.length) return;
      try { out[i] = await worker(items[i], i); } catch (_) { out[i] = items[i]; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, runner));
  return out;
}

async function buildNews() {
  const buckets = await Promise.all(NEWS_SOURCES.map(fetchNewsSource));
  const all = buckets.flat();
  const seen = new Set();
  const unique = all.filter((item) => {
    const key = (item.title || '').toLowerCase().replace(/\s+/g, ' ').trim();
    if (!key || seen.has(key)) return false;
    seen.add(key); return true;
  }).slice(0, 45);
  // Translate in parallel so one slow translation service cannot freeze /api/news.
  return mapLimit(unique, 8, async (item) => ({
    ...item,
    originalTitle: item.title,
    title: await translateToArabic(item.title),
    language: /[\u0600-\u06FF]/.test(item.title) ? 'ar' : 'auto'
  }));
}

let newsCache = { items: [], updatedAt: 0, refreshing: false, lastError: null };

function refreshNewsInBackground() {
  if (newsCache.refreshing) return;
  newsCache.refreshing = true;
  buildNews().then((items) => {
    if (items.length) newsCache = { items, updatedAt: now(), refreshing: false, lastError: null };
    else newsCache.refreshing = false;
  }).catch((error) => {
    newsCache.refreshing = false;
    newsCache.lastError = error.message;
    console.warn('[NEWS] refresh failed:', error.message);
  });
}

app.get('/api/news', (req, res) => {
  const stale = !newsCache.items.length || now() - newsCache.updatedAt > 10 * 60 * 1000;
  if (stale) refreshNewsInBackground();
  res.set('Cache-Control', 'no-store');
  res.json({
    ok: true,
    ready: newsCache.items.length > 0,
    refreshing: newsCache.refreshing,
    items: newsCache.items,
    updatedAt: newsCache.updatedAt,
    sources: NEWS_SOURCES.map((s) => s.name)
  });
});

app.post('/api/news/refresh', (req, res) => {
  refreshNewsInBackground();
  res.json({ ok: true, refreshing: true, items: newsCache.items, updatedAt: newsCache.updatedAt });
});

// Warm the cache without making the first browser request wait for external sites.
setTimeout(refreshNewsInBackground, 500);

/* -------------------------------------------------------------------------- */
/* SOCKET PROTOCOL                                                            */
/* -------------------------------------------------------------------------- */

const socketRate = new Map();

function allowSocketEvent(socket, key, limit = 60, windowMs = 10000) {
  const mapKey = socket.id + ':' + key;
  const record = socketRate.get(mapKey) || { start: now(), count: 0 };
  if (now() - record.start >= windowMs) {
    record.start = now();
    record.count = 0;
  }
  record.count += 1;
  socketRate.set(mapKey, record);
  return record.count <= limit;
}

function ack(cb, payload) {
  if (typeof cb === 'function') cb(payload);
}

io.on('connection', (socket) => {
  socket.on('identify', (data = {}, cb = () => {}) => {
    if (!allowSocketEvent(socket, 'identify', 10, 10000)) return ack(cb, { ok: false, error: 'طلبات كثيرة' });
    const player = ensurePlayer(data.playerId, data.name);
    addPresence(socket, player);
    // Restore any room belonging to this player after a refresh/reconnect.
    for (const room of rooms.values()) {
      const member = playerInRoom(room, player.id);
      if (member) {
        member.socketId = socket.id;
        member.disconnectedAt = null;
        socket.join(room.code);
        socket.emit('room:restored', { room: roomPublic(room), state: clone(room.state) });
        break;
      }
    }
    for (const t of Object.values(db.tournaments)) if (t.status === 'playing') autoOpenTournamentMatches(t);
    ack(cb, { ok: true, player: publicPlayer(player), daily: dailyPublic(player) });
    socket.emit('player:data', publicPlayer(player));
  });

  socket.on('room:create', (data = {}, cb = () => {}) => {
    if (!allowSocketEvent(socket, 'room-create', 10, 10000)) return ack(cb, { ok: false, error: 'طلبات كثيرة' });
    const player = ensurePlayer(data.playerId || socket.data.playerId, data.hostName || socket.data.name || data.name);
    addPresence(socket, player);
    const room = createRoom(data.game, data.password, socket, player, { name: data.roomName || data.name, isPrivate: data.isPrivate !== false });
    socket.join(room.code);
    ack(cb, { ok: true, ...roomPublic(room) });
  });

  socket.on('room:join', (data = {}, cb = () => {}) => {
    if (!allowSocketEvent(socket, 'room-join', 20, 10000)) return ack(cb, { ok: false, error: 'طلبات كثيرة' });
    const room = findRoom(data.code);
    if (!room) return ack(cb, { ok: false, error: 'كود الغرفة غير موجود أو انتهت صلاحيته' });
    const player = ensurePlayer(data.playerId || socket.data.playerId, data.name || socket.data.name);
    addPresence(socket, player);
    const result = joinRoomSocket(socket, room, player, data.password);
    if (!result.ok) return ack(cb, result);
    socket.join(room.code);
    room.state.revision += 1;
    saveDb();
    broadcastRoom(room, 'room:players');
    io.to(room.code).emit('room:connected', roomPublic(room));
    ack(cb, { ok: true, reconnected: result.reconnected, ...roomPublic(room) });
  });

  socket.on('room:play-now', (data = {}, cb = () => {}) => {
    if (!allowSocketEvent(socket, 'play-now', 10, 10000)) return ack(cb, { ok: false, error: 'طلبات كثيرة' });
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    const result = markReady(room, socket);
    ack(cb, result);
  });

  socket.on('room:state-request', (data = {}, cb = () => {}) => {
    const room = findRoom(data.code);
    if (!room) return ack(cb, { ok:false, error:'الغرفة غير موجودة أو انتهت صلاحيتها' });
    const pid = String(data.playerId || socket.data.playerId || '');
    // Re-bind the socket by durable playerId before checking socket membership.
    // This fixes the false "أنت لست داخل الغرفة" after mobile reconnects.
    const existing = playerInRoom(room, pid);
    if (existing) {
      existing.socketId = socket.id;
      existing.disconnectedAt = null;
      socket.data.playerId = pid;
      socket.join(room.code);
      room.updatedAt = now(); room.lastActivity = now();
      persistRoom(room);
      io.to(room.code).emit('room:restored', { room: roomPublic(room), state: clone(room.state) });
      return ack(cb, { ok:true, room:roomPublic(room), state:clone(room.state), restored:true });
    }
    return ack(cb, { ok:false, error:'أنت لست داخل هذه الغرفة' });
  });

  socket.on('game:deck', (data = {}, cb = () => {}) => {
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    ack(cb, { ok: true, game: room.game, revision: room.state.revision, deck: ensureRoomDeck(room) });
  });

  socket.on('auction:setup', (data = {}, cb = () => {}) => {
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    if (!['auction','five'].includes(room.game)) return ack(cb, {ok:false,error:'هذه ليست لعبة مزاد'});
    room.state.data.auctionSetup = room.state.data.auctionSetup || {};
    const budget = Number(data.budget);
    if (!Number.isFinite(budget) || budget <= 0) return ack(cb,{ok:false,error:'الميزانية غير صحيحة'});
    room.state.data.auctionSetup[check.player.playerId] = budget;
    const values = Object.values(room.state.data.auctionSetup);
    if (room.players.length === 2 && values.length === 2) {
      if (Number(values[0]) !== Number(values[1])) return ack(cb,{ok:false,error:'يجب أن يختار اللاعبان نفس الميزانية'});
      const chosenBudget = Number(values[0]);
      // IMPORTANT: once an authoritative auction exists, NEVER regenerate it.
      // The previous implementation rebuilt the deck when the second player
      // confirmed the setup, which made the two clients see different auctions.
      const existing = room.state.data.auction;
      if (!existing) initAuthoritativeAuction(room, chosenBudget);
      else if (Number(existing.budget) !== chosenBudget) return ack(cb,{ok:false,error:'إعداد المزاد مثبت بالفعل'});
      io.to(room.code).emit('auction:start', { room: roomPublic(room), auction: clone(room.state.data.auction) });
    } else {
      room.state.revision += 1; persistRoom(room);
    }
    ack(cb,{ok:true,waiting:values.length<2,auction:room.state.data.auction||null});
  });

  socket.on('game:event', (data = {}, cb = () => {}) => {
    if (!allowSocketEvent(socket, 'game-event', 120, 10000)) return ack(cb, { ok: false, error: 'سرعة إرسال عالية' });
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    const result = serverGameEvent(room, socket, data.type, data.data);
    ack(cb, result);
  });

  socket.on('game:complete', (data = {}, cb = () => {}) => {
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    if (!room.state.ended) finalizeRoom(room, { winnerId: data.winnerId || null, draw: !!data.draw });
    ack(cb, { ok: true, state: clone(room.state) });
  });

  socket.on('match:score-request', (data = {}, cb = () => {}) => {
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    const score = randomMatchScore();
    room.state.data.score = score;
    room.state.revision += 1;
    const winner = score.home === score.away ? null : (score.home > score.away ? room.players[0].playerId : room.players[1].playerId);
    finalizeRoom(room, { score, winnerId: winner, draw: score.home === score.away });
    ack(cb, { ok: true, score, state: clone(room.state) });
  });

  socket.on('guess:start', (data = {}, cb = () => {}) => {
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    if (room.game !== 'guess') return ack(cb, { ok: false, error: 'هذه ليست لعبة تخمين اللاعب' });
    newGuessState(room);
    room.state.turn = room.players[0]?.playerId || null;
    room.state.revision += 1;
    io.to(room.code).emit('guess:state', publicGuessState(room));
    ack(cb, { ok: true, guess: publicGuessState(room) });
  });

  socket.on('guess:answer', (data = {}, cb = () => {}) => {
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    if (room.game !== 'guess') return ack(cb, { ok: false, error: 'هذه ليست لعبة تخمين اللاعب' });
    const result = serverGameEvent(room, socket, 'guess:answer', { answer: String(data.answer || '').slice(0, 120) });
    ack(cb, result);
  });

  socket.on('ranked:search', (data = {}, cb = () => {}) => {
    if (!allowSocketEvent(socket,'ranked-search',8,10000)) return ack(cb,{ok:false,error:'طلبات كثيرة'});
    const player=playerById(String(socket.data.playerId||''));
    if(!player)return ack(cb,{ok:false,error:'يجب تسجيل الاتصال أولًا'});
    normalizeRanked(player);
    const game=validGame(data.game);
    removeRankedEntry(player.id);
    const entry={playerId:player.id,game,rank:player.ranked.rank,createdAt:now()};
    const room=tryRankedMatch(entry);
    if(room){
      ack(cb,{ok:true,matched:true,room:roomPublic(room),ranked:rankedPublic(player)});
      return;
    }
    const key=rankedQueueKey(game), list=rankedQueue.get(key)||[];
    list.push(entry); rankedQueue.set(key,list);
    ack(cb,{ok:true,matched:false,queued:true,game,ranked:rankedPublic(player)});
    socket.emit('ranked:waiting',{game,ranked:rankedPublic(player)});
  });

  socket.on('ranked:cancel',(data={},cb=()=>{})=>{
    const id=String(socket.data.playerId||'');
    removeRankedEntry(id);
    ack(cb,{ok:true});
  });

  socket.on('quick:join', (data = {}, cb = () => {}) => {
    if (!allowSocketEvent(socket, 'quick-join', 10, 10000)) return ack(cb, { ok: false, error: 'طلبات كثيرة' });
    const player = ensurePlayer(data.playerId || socket.data.playerId, data.name || socket.data.name);
    addPresence(socket, player);
    removeQuickEntry(player.id);
    const entry = { playerId: player.id, game: validGame(data.game), createdAt: now() };
    const room = tryQuickMatch(entry);
    if (room) {
      ack(cb, { ok: true, matched: true, room: roomPublic(room) });
      return;
    }
    const qk = quickKey(entry.game);
    const qlist = quickQueue.get(qk) || [];
    qlist.push(entry);
    quickQueue.set(qk, qlist);
    ack(cb, { ok: true, matched: false, queued: true, game: entry.game });
    socket.emit('quick:waiting', { game: entry.game });
  });

  socket.on('quick:cancel', (data = {}, cb = () => {}) => {
    const playerId = String(data.playerId || socket.data.playerId || '');
    removeQuickEntry(playerId);
    ack(cb, { ok: true });
  });

  socket.on('quick:invite', (data = {}, cb = () => {}) => {
    const fromId = String(socket.data.playerId || data.playerId || '');
    const from = playerById(fromId);
    const to = playerById(String(data.friendId || ''));
    if (!from || !to) return ack(cb, { ok: false, error: 'صديق غير صالح' });
    if (!(from.friends || []).includes(to.id)) return ack(cb, { ok: false, error: 'اللاعب ليس في قائمة الأصدقاء' });
    const game = validGame(data.game);
    to.matchRequests = Array.isArray(to.matchRequests) ? to.matchRequests : [];
    // Do not create duplicate invitations.
    to.matchRequests = to.matchRequests.filter(x => !(x.fromId === from.id && x.game === game && now() - Number(x.createdAt||0) < 120000));
    const request = { id: crypto.randomBytes(10).toString('hex'), fromId: from.id, game, createdAt: now(), expiresAt: now()+120000 };
    to.matchRequests.push(request);
    to.updatedAt = now();
    saveDb();
    const target = socketForPlayer(to.id);
    if (target) target.emit('match:request', { id:request.id, from:publicPlayer(from), game });
    ack(cb, { ok: true, request: { id:request.id, game } });
  });

  socket.on('quick:accept', (data = {}, cb = () => {}) => {
    const from = playerById(String(data.fromId || ''));
    const actorId = String(socket.data.playerId || '');
    if (!actorId) return ack(cb, { ok: false, error: 'يجب تسجيل الاتصال أولًا' });
    const player = playerById(actorId);
    if (!player) return ack(cb, { ok: false, error: 'اللاعب غير موجود' });
    if (!from) return ack(cb, { ok: false, error: 'الدعوة انتهت' });
    player.matchRequests = (player.matchRequests || []).filter(x => !(x.fromId === from.id && (!data.requestId || x.id === data.requestId)));
    const fromSocket = socketForPlayer(from.id);
    if (!fromSocket) return ack(cb, { ok: false, error: 'الصديق غير متصل' });
    const game = validGame(data.game);
    const room = createRoom(game, '', fromSocket, from);
    room.quickMatch = true;
    joinRoomSocket(socket, room, player, '');
    fromSocket.join(room.code);
    socket.join(room.code);
    room.status = 'connected';
    // Quick Match is the no-code version: acceptance is the confirmation,
    // so both players are marked ready and the same authoritative start is
    // broadcast to both sockets.
    room.players.forEach(p => { p.ready = true; });
    room.state.revision += 1;
    persistRoom(room);
    saveDb();
    io.to(room.code).emit('quick:matched', { room: roomPublic(room), game: room.game });
    io.to(room.code).emit('room:connected', roomPublic(room));
    maybeStartRoom(room);
    ack(cb, { ok: true, room: roomPublic(room), started: !!room.state.started });
  });

  socket.on('friends:add', (data = {}, cb = () => {}) => {
    const actorId = String(socket.data.playerId || '');
    const player = playerById(actorId);
    if (!player) return ack(cb, { ok:false, error:'يجب تسجيل الاتصال أولًا' });
    const result = addFriendRequest(player.id, data.friendId);
    ack(cb, result);
  });

  socket.on('friends:accept', (data = {}, cb = () => {}) => {
    const result = acceptFriendRequest(String(socket.data.playerId || ''), String(data.friendId || ''));
    ack(cb, result);
  });

  socket.on('friends:reject', (data = {}, cb = () => {}) => {
    const result = rejectFriendRequest(String(socket.data.playerId || ''), String(data.friendId || ''));
    ack(cb, result);
  });

  socket.on('friends:list', (data = {}, cb = () => {}) => {
    const player = playerById(String(data.playerId || socket.data.playerId || ''));
    if (!player) return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    ack(cb,{ok:true,friends:friendsPublic(player),incomingRequests:(player.incomingRequests||[]).map(playerById).filter(Boolean).map(publicPlayer),outgoingRequests:(player.outgoingRequests||[]).map(playerById).filter(Boolean).map(publicPlayer)});
  });

  socket.on('inbox:get', (data = {}, cb = () => {}) => {
    const player = playerById(String(data.playerId || socket.data.playerId || ''));
    if (!player) return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    const matchRequests=(player.matchRequests||[]).filter(x=>Number(x.expiresAt||0)>now()).map(x=>({...x,from:publicPlayer(playerById(x.fromId))})).filter(x=>x.from);
    ack(cb,{ok:true,incomingRequests:(player.incomingRequests||[]).map(playerById).filter(Boolean).map(publicPlayer),matchRequests,welcomeAvailable:!player.rewardClaims?.welcome_v1});
  });

  socket.on('daily:get', (data = {}, cb = () => {}) => {
    const player = playerById(String(data.playerId || socket.data.playerId || ''));
    if (!player) return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    ack(cb,{ok:true,daily:dailyPublic(player)});
  });

  socket.on('daily:claim', (data = {}, cb = () => {}) => {
    const player = playerById(String(data.playerId || socket.data.playerId || ''));
    if (!player) return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    const result=claimDailyTask(player,String(data.taskId||''));
    ack(cb,result);
  });

  socket.on('welcome:claim', (data = {}, cb = () => {}) => {
    const player=playerById(String(data.playerId||socket.data.playerId||''));
    if(!player)return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    ack(cb,claimWelcome(player));
  });

  socket.on('draft:open-free', (data = {}, cb = () => {}) => {
    const player=playerById(String(data.playerId||socket.data.playerId||''));
    if(!player)return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    if((player.freeDrafts||0)<1)return ack(cb,{ok:false,error:'لا يوجد Draft مجاني'});
    const cards=draftCandidates(player,3);
    if(!cards.length)return ack(cb,{ok:false,error:'لا يوجد لاعب جديد بدون تكرار'});
    player.pendingDraft = { id: crypto.randomBytes(10).toString('hex'), choices: cards, createdAt: now(), expiresAt: now()+5*60*1000 };
    saveDb();
    ack(cb,{ok:true,draftId:player.pendingDraft.id,choices:cards,player:publicPlayer(player)});
  });

  socket.on('draft:claim-free', (data = {}, cb = () => {}) => {
    const player=playerById(String(data.playerId||socket.data.playerId||''));
    if(!player)return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    const pending=player.pendingDraft;
    if(pending && pending.expiresAt && pending.expiresAt<now()){delete player.pendingDraft;return ack(cb,{ok:false,error:'انتهت صلاحية الـDraft، افتحه مرة أخرى'});}
    if(!pending || pending.id!==String(data.draftId||''))return ack(cb,{ok:false,error:'الدرافت غير صالح أو انتهت صلاحيته'});
    const choice=pending.choices.find(c=>c.name===String(data.playerName||''));
    if(!choice)return ack(cb,{ok:false,error:'اللاعب المختار غير موجود'});
    if((player.freeDrafts||0)<1)return ack(cb,{ok:false,error:'لا يوجد Draft مجاني'});
    player.freeDrafts-=1;
    player.ownedPlayers=player.ownedPlayers||[];
    if(player.ownedPlayers.some(x=>x.name===choice.name))return ack(cb,{ok:false,error:'هذا اللاعب موجود بالفعل'});
    player.ownedPlayers.push(choice);
    delete player.pendingDraft;
    saveDb();
    ack(cb,{ok:true,card:choice,player:publicPlayer(player)});
  });

  socket.on('draft:open-paid', (data = {}, cb = () => {}) => {
    const player=playerById(String(data.playerId||socket.data.playerId||''));
    const count=Number(data.count||1); const prices={1:2000,5:9750,10:17500};
    if(!player)return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    if(!prices[count])return ack(cb,{ok:false,error:'حجم Draft غير صالح'});
    const price=prices[count];
    if(Number(player.points||0)<price)return ack(cb,{ok:false,error:'POINTS لا تكفي لهذا الـDraft'});
    const choices=draftCandidates(player,count===1?3:count);
    if(choices.length<(count===1?3:count))return ack(cb,{ok:false,error:'لا يوجد عدد كافٍ من اللاعبين الجدد بدون تكرار'});
    player.pendingDraft={id:crypto.randomBytes(10).toString('hex'),choices,count,price,free:false,createdAt:now(),expiresAt:now()+5*60*1000}; saveDb();
    ack(cb,{ok:true,draftId:player.pendingDraft.id,price,count,choices,player:publicPlayer(player)});
  });

  socket.on('draft:claim-paid', (data = {}, cb = () => {}) => {
    const player=playerById(String(data.playerId||socket.data.playerId||''));
    if(!player)return ack(cb,{ok:false,error:'اللاعب غير موجود'}); const pending=player.pendingDraft;
    if(!pending||pending.free||pending.id!==String(data.draftId||''))return ack(cb,{ok:false,error:'الدرافت غير صالح أو انتهت صلاحيته'});
    if(pending.expiresAt&&pending.expiresAt<now()){delete player.pendingDraft;saveDb();return ack(cb,{ok:false,error:'انتهت صلاحية الـDraft'});}
    if(Number(player.points||0)<Number(pending.price||0))return ack(cb,{ok:false,error:'POINTS لا تكفي لهذا الـDraft'});
    const idx=Math.max(0,Math.min(pending.choices.length-1,Number(data.index||0))); const choice=pending.choices[idx];
    if(!choice)return ack(cb,{ok:false,error:'اللاعب المختار غير موجود'}); player.ownedPlayers=player.ownedPlayers||[];
    if(player.ownedPlayers.some(x=>x.name===choice.name))return ack(cb,{ok:false,error:'هذا اللاعب موجود بالفعل'});
    player.points-=Number(pending.price||0); player.ownedPlayers.push(choice); delete player.pendingDraft; player.updatedAt=now(); saveDb();
    ack(cb,{ok:true,price:Number(pending.price||0),card:choice,player:publicPlayer(player)});
  });

  socket.on('game:single-complete', (data = {}, cb = () => {}) => {
    const player=playerById(String(data.playerId||socket.data.playerId||''));
    if(!player)return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    ack(cb,completeGameForPlayer(player,validGame(data.game),data.claimKey,data.result||{}));
  });

  socket.on('game:four-teams-complete', (data = {}, cb = () => {}) => {
    const player=playerById(String(data.playerId||socket.data.playerId||''));
    if(!player)return ack(cb,{ok:false,error:'اللاعب غير موجود'});
    const key=`four-teams:${player.id}:${String(data.claimKey||now()).slice(0,120)}`;
    const reward=claimReward(player.id,key,{xb:10});
    if(!reward.duplicate) advanceDaily(player,'game',1);
    ack(cb,{ok:true,duplicate:reward.duplicate,reward:reward.reward,player:publicPlayer(player)});
  });

  socket.on('player:avatar-save', (data={}, cb=()=>{}) => {
    const player = playerById(String(socket.data.playerId || ''));
    if (!player) return ack(cb,{ok:false,error:'يجب تسجيل الاتصال أولًا'});
    if (typeof data.avatar !== 'string' || data.avatar.length > 2_000_000) return ack(cb,{ok:false,error:'صورة غير صالحة أو كبيرة جدًا'});
    player.avatar = data.avatar; player.updatedAt = now(); saveDb();
    ack(cb,{ok:true,player:publicPlayer(player)});
  });

  socket.on('player:name-save',(data={},cb=()=>{})=>{
    const id=String(socket.data.playerId||'');
    const player=playerById(id);
    if(!player)return ack(cb,{ok:false,error:'يجب تسجيل الاتصال أولًا'});
    const name=safeName(data.name);
    if(!name || name==='لاعب')return ack(cb,{ok:false,error:'اكتب اسمًا صالحًا'});
    player.name=name; player.updatedAt=now(); socket.data.name=name;
    for(const r of rooms.values()){
      const member=r.players.find(p=>p.playerId===id);
      if(member){member.name=name; broadcastRoom(r,'room:players');}
    }
    saveDb();
    ack(cb,{ok:true,player:publicPlayer(player)});
  });

  socket.on('ranked:get',(data={},cb=()=>{})=>{
    const id=String(socket.data.playerId||'');
    const player=playerById(id);
    if(!player)return ack(cb,{ok:false,error:'يجب تسجيل الاتصال أولًا'});
    ack(cb,{ok:true,ranked:rankedPublic(player)});
  });

  socket.on('leaderboard:get',(data={},cb=()=>{})=>{
    const limit=Math.min(100,Math.max(1,Number(data.limit||50)));
    const leaderboard=Object.values(db.players||{}).map(publicPlayer)
      .sort((a,b)=>Number(b.xb||0)-Number(a.xb||0)).slice(0,limit)
      .map((p,i)=>({...p,position:i+1}));
    ack(cb,{ok:true,leaderboard});
  });

  socket.on('player:sync', (data = {}, cb = () => {}) => {
    const player = ensurePlayer(data.playerId || socket.data.playerId, data.name || socket.data.name);
    addPresence(socket, player);
    ack(cb, { ok: true, player: publicPlayer(player) });
  });

  socket.on('rooms:list', (data={}, cb=()=>{}) => {
    ack(cb, { ok: true, rooms: publicOpenRooms() });
  });

  socket.on('room:kick', (data={}, cb=()=>{}) => {
    const room = findRoom(data.code);
    const check = requireRoomPlayer(socket, room, data.playerId || socket.data.playerId);
    if (!check.ok) return ack(cb, check);
    if (check.player.role !== 'host') return ack(cb, {ok:false,error:'صاحب الغرفة فقط يستطيع الطرد'});
    const targetId = String(data.targetId || '');
    const target = playerInRoom(room, targetId);
    if (!target || target.role === 'host') return ack(cb, {ok:false,error:'اللاعب المطلوب غير موجود'});
    const targetSocket = target.socketId ? io.sockets.sockets.get(target.socketId) : null;
    if (targetSocket) { targetSocket.leave(room.code); targetSocket.emit('room:kicked', {code: room.code}); }
    room.players = room.players.filter(p => p.playerId !== targetId);
    room.status = 'waiting'; room.updatedAt = now(); room.lastActivity = now();
    persistRoom(room); broadcastRoom(room, 'room:player-left');
    ack(cb, {ok:true, room:roomPublic(room)});
  });

  socket.on('room:leave', (data={},cb=()=>{})=>{
    const room=findRoom(data.code); if(!room)return ack(cb,{ok:true});
    const check=requireRoomPlayer(socket,room,data.playerId||socket.data.playerId); if(!check.ok)return ack(cb,check);
    if(room.state.started) return ack(cb,{ok:false,error:'المباراة بدأت بالفعل؛ استخدم إعادة الاتصال للعودة'});
    room.players=room.players.filter(p=>p.playerId!==check.player.playerId);
    socket.leave(room.code); room.status=room.players.length?'waiting':'waiting'; room.updatedAt=now(); room.lastActivity=now();
    if(room.players.length===0){rooms.delete(room.code);deletePersistedRoom(room.code);} else {room.players[0].role='host';room.players[0].ready=false;persistRoom(room);broadcastRoom(room,'room:player-left');}
    ack(cb,{ok:true,left:true});
  });

  socket.on('disconnect', () => {
    const room = roomForSocket(socket);
    if (room) leaveRoomSocket(socket);
    removePresence(socket);
    socketRate.delete(socket.id);
  });
});

/* -------------------------------------------------------------------------- */
/* PERIODIC MAINTENANCE                                                       */
/* -------------------------------------------------------------------------- */

setInterval(() => {
  const rankedCutoff = now() - RANKED_QUEUE_TTL_MS;
  for (const [key,list] of rankedQueue) {
    const next=(list||[]).filter(e=>e && Number(e.createdAt||0)>rankedCutoff && !!socketForPlayer(e.playerId));
    if(next.length) rankedQueue.set(key,next); else rankedQueue.delete(key);
  }
  const cutoff = now() - ROOM_TTL_MS;
  for (const [code, room] of rooms) {
    const stale = Number(room.lastActivity || room.updatedAt || room.createdAt || 0) < cutoff;
    if (stale && (!room.state?.started || room.state?.ended)) { rooms.delete(code); deletePersistedRoom(code); }
  }
  // Keep invitation indexes bounded.
  const inviteCutoff = now() - 7 * 24 * 60 * 60 * 1000;
  for (const [code, rec] of Object.entries(db.usedTournamentCodes || {})) if (Number(rec.usedAt || 0) < inviteCutoff) delete db.usedTournamentCodes[code];
  saveDb();
}, 60 * 1000);

setInterval(() => {
  const cutoff = now() - QUICK_MATCH_TTL_MS;
  for (const [game, entry] of quickQueue) {
    if (entry.createdAt < cutoff) {
      quickQueue.delete(game);
      emitToPlayer(entry.playerId, 'quick:expired', { game });
    }
  }
}, 15 * 1000);

setInterval(() => {
  refreshNewsInBackground();
}, 10 * 60 * 1000);

setInterval(() => {
  saveDb();
}, 30 * 1000);

/* -------------------------------------------------------------------------- */
/* ERROR HANDLING                                                             */
/* -------------------------------------------------------------------------- */

app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'NOT FOUND', path: req.path });
  }
  const index = path.join(PUBLIC_DIR, 'index.html');
  if (fs.existsSync(index)) return res.sendFile(index);
  return res.status(404).send('<h2>R2 GAMES: index.html not found</h2>');
});

app.use((error, req, res, next) => {
  console.error('[HTTP]', error.stack || error.message || error);
  if (res.headersSent) return next(error);
  res.status(500).json({ error: 'خطأ داخلي في السيرفر' });
});

process.on('SIGTERM', async () => {
  clearTimeout(saveTimer);
  await flushDbAsync();
  server.close(() => process.exit(0));
});

process.on('SIGINT', async () => {
  clearTimeout(saveTimer);
  await flushDbAsync();
  server.close(() => process.exit(0));
});

/* -------------------------------------------------------------------------- */
/* STARTUP                                                                    */
/* -------------------------------------------------------------------------- */

// Memory hygiene: remove expired queues, socket rate buckets, translation cache and stale drafts.
setInterval(() => {
  const cutoff = now() - QUICK_MATCH_TTL_MS;
  for (const [game, list] of quickQueue) {
    const fresh = (list || []).filter(x => x && x.createdAt >= cutoff && socketForPlayer(x.playerId));
    if (fresh.length) quickQueue.set(game, fresh); else quickQueue.delete(game);
  }
  const rateCutoff = now() - 60000;
  for (const [key, rec] of httpRate) if (!rec || rec.start < rateCutoff) httpRate.delete(key);
  for (const [key, rec] of socketRate) if (!rec || rec.start < rateCutoff) socketRate.delete(key);
  const newsCutoff = now() - 30 * 60 * 1000;
  for (const player of Object.values(db.players)) {
    if (player.pendingDraft && now() - player.pendingDraft.createdAt > 15 * 60 * 1000) delete player.pendingDraft;
  }
  if (translationCache.size > 500) {
    while (translationCache.size > 350) translationCache.delete(translationCache.keys().next().value);
  }
}, 30000).unref?.();

server.listen(PORT, HOST, () => {
  console.log('==================================================');
  console.log('R2 GAMES WORLD SERVER ' + APP_VERSION);
  console.log('Authoritative Multiplayer: ON');
  console.log('Games: ' + GAME_NAMES.join(', '));
  console.log('Room code: 8 alphanumeric characters');
  console.log('Player ID: 16 decimal digits');
  console.log('Tournament sizes: ' + TOURNAMENT_SIZES.join(', '));
  console.log('Quick Match: ON');
  console.log('Friends: ON');
  console.log('News engine: ON');
  console.log('Listening on ' + HOST + ':' + PORT);
  console.log('==================================================');
});

/* -------------------------------------------------------------------------- */
/* DOCUMENTATION / PROTOCOL CONTRACT                                          */
/* -------------------------------------------------------------------------- */

/*
01. room:create      create a two-player authoritative room.
02. room:join        join or reconnect by 8-character room code.
03. room:play-now    explicit readiness signal from each player.
04. game:start       emitted only when both players are ready.
05. game:event       validated server-side before broadcast.
06. game:sync        authoritative revision/state snapshot.
07. game:complete    idempotent completion and reward claim.
08. guess:start      initializes five unique rounds.
09. guess:answer     server checks the answer and awards the point.
10. guess:state      sends the current round/turn/score.
11. guess:finished   sends the final five-round score.
12. quick:join       pairs players without a room code.
13. quick:invite     invites an existing friend.
14. quick:accept     converts the invitation into a live room.
15. friends:add      sends a real friend request.
16. friends:accept   establishes a two-way friendship.
17. friends:reject   removes a pending request.
18. tournament:*     controls bracket lifecycle.
19. match:score-request produces varied server-side scores.
20. player:sync      restores server resources/profile.

The important rule is simple:
The client may REQUEST an action, but the server DECIDES whether the action
is legal and then publishes the resulting authoritative state.
*/

/*
Compatibility aliases intentionally live here so older frontend versions can
be upgraded without changing the visual design. They do not make the client
authoritative; they only preserve event names used by previous R2 builds.
*/

/*
Room lifecycle:
WAITING -> CONNECTED -> READY -> PLAYING -> FINISHED
                       \-> RECONNECTING -> PLAYING

Quick Match lifecycle:
QUEUE -> MATCHED -> CONNECTED -> READY -> PLAYING

Tournament lifecycle:
OPEN -> FULL -> PLAYING -> ROUND_ADVANCE -> FINISHED

Guess lifecycle:
ROUND 1 -> player A -> player B -> ROUND 2 -> ... -> ROUND 5 -> FINISHED
*/

/*
Reward contract:
A reward must always have a deterministic claim key. If the same completion
arrives twice because of reconnect/retry, claimReward returns duplicate=true
and does not add the currency twice.
*/

/*
Security contract:
- IDs are validated as 16 decimal digits.
- Room codes are normalized and validated by lookup.
- Game names are restricted to the six registered games.
- Socket events are rate limited.
- Event payloads are bounded and copied into server state.
- Turn-bound events are rejected when sent out of turn.
- Tournament winners must be one of the actual match participants.
*/

/*
Scaling contract:
This single-process edition is intentionally cleanly separated into:
  repository -> presence -> rooms -> game state -> tournament -> news.
For horizontal scaling, replace the Map/JSON adapters with Redis/PostgreSQL
and configure Socket.IO's Redis adapter. No game rule API needs to change.
*/

/*
News contract:
The server aggregates FilGoal, YallaKora and several major international
football publications through Google News RSS search feeds, deduplicates
headlines, and attempts Arabic translation for non-Arabic headlines. The
original source link remains available to the frontend.
*/

/*
This final block deliberately contains no client-side game logic. The client
should remain responsible for rendering, animation, input controls and the
existing R2 visual experience. The server is responsible for identity,
rooms, readiness, synchronization, validation, outcomes and persistence.
*/


process.on('SIGTERM', async () => { clearTimeout(saveTimer); await flushDbAsync(); server.close(() => process.exit(0)); });
process.on('SIGINT', async () => { clearTimeout(saveTimer); await flushDbAsync(); server.close(() => process.exit(0)); });


// V28 Four Teams: auction resolution announcement helper.
function showFourTeamAuctionResult(winnerName, auctionPlayerName, freeAwards) {
  const esc = v => String(v ?? '').replace(/[&<>"]/g, c =>
    ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const rows = (Array.isArray(freeAwards) ? freeAwards : []).map(a =>
    `<div>الفريق <b>${esc(a.team)}</b> حصل على اللاعب <b>${esc(a.player)}</b> مجانًا</div>`
  ).join('');
  const el = document.createElement('div');
  el.innerHTML =
    `<div><b>🏆 فاز فريق ${esc(winnerName)} وحصل على اللاعب ${esc(auctionPlayerName)}</b></div>` + rows;
  Object.assign(el.style, {
    position:'fixed', left:'50%', top:'50%', transform:'translate(-50%,-50%)',
    zIndex:999999, width:'min(92vw,560px)', padding:'18px',
    borderRadius:'16px', background:'#111827', color:'#fff',
    fontSize:'16px', lineHeight:'1.8', textAlign:'center',
    boxShadow:'0 15px 45px rgba(0,0,0,.45)'
  });
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 6000);
}
