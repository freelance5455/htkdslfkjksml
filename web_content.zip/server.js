// Çöl Arenası — persistence API and authoritative room simulation.
// Visitor content is always attributed to the trusted Websim user id.
export const schema = `
  CREATE TABLE IF NOT EXISTS profiles (
    user_id TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    username_key TEXT NOT NULL UNIQUE,
    avatar_url TEXT,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS progress (
    user_id TEXT PRIMARY KEY,
    level INTEGER NOT NULL DEFAULT 1,
    best_level INTEGER NOT NULL DEFAULT 1,
    coins INTEGER NOT NULL DEFAULT 280,
    wins INTEGER NOT NULL DEFAULT 0,
    updated_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS friendships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    friend_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at INTEGER NOT NULL,
    UNIQUE(user_id, friend_id)
  );
  CREATE INDEX IF NOT EXISTS friendships_friend ON friendships(friend_id, status);
  CREATE TABLE IF NOT EXISTS invites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    receiver_id TEXT NOT NULL,
    room_code TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    seen INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS invites_receiver ON invites(receiver_id, seen, created_at);
  CREATE TABLE IF NOT EXISTS rooms (
    code TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    host_username TEXT NOT NULL,
    mode TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS rooms_status ON rooms(status, updated_at);
`;

const json = (body, status = 200) => Response.json(body, { status });
const now = () => Date.now();
const cleanUsername = (value) => String(value ?? "").trim().replace(/^@/, "");
const usernameKey = (value) => cleanUsername(value).toLocaleLowerCase("en-US");
const validUsername = (name) => /^[a-zA-Z0-9_]{3,20}$/.test(name);

function identity(request) {
  return {
    id: request.headers.get("x-websim-user-id"),
    websimName: request.headers.get("x-websim-username"),
    kind: request.headers.get("x-websim-user-is-anonymous") === "true" ? "anonymous" : "user",
  };
}

function requireUser(request) {
  const user = identity(request);
  if (!user.id || user.kind !== "user") throw Object.assign(new Error("Bu özellik için Websim hesabınla giriş yap."), { status: 401 });
  return user;
}

async function profileFor(env, userId) {
  return env.DB.prepare("SELECT user_id, username, avatar_url FROM profiles WHERE user_id = ?").bind(userId).first();
}

async function requireProfile(env, user) {
  const profile = await profileFor(env, user.id);
  if (!profile) throw Object.assign(new Error("Önce kullanıcı adını seçip profilini oluştur."), { status: 409, code: "PROFILE_REQUIRED" });
  return profile;
}

async function readJson(request) {
  try {
    return await request.json();
  } catch {
    throw Object.assign(new Error("Geçersiz istek verisi."), { status: 400 });
  }
}

function makeRoomCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  return Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join("");
}

async function route(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  if (method === "GET" && path === "/api/status" && !env?.DB) {
    return json({ database: false, signedIn: Boolean(identity(request).id), profile: null }, 503);
  }
  if (!env?.DB) return json({ error: "Veri tabanı bağlantısı hazır değil.", code: "DATABASE_UNAVAILABLE" }, 503);

  if (method === "GET" && path === "/api/status") {
    const user = identity(request);
    let profile = null;
    if (user.id && user.kind === "user") profile = await profileFor(env, user.id);
    return json({ database: true, signedIn: Boolean(user.id && user.kind === "user"), profile });
  }

  if (method === "GET" && path === "/api/profile") {
    const user = requireUser(request);
    return json({ profile: await profileFor(env, user.id) });
  }

  if (method === "POST" && path === "/api/profile") {
    const user = requireUser(request);
    const body = await readJson(request);
    const username = cleanUsername(body.username);
    if (!validUsername(username)) return json({ error: "Kullanıcı adı 3–20 karakter olmalı; harf, sayı ve alt çizgi kullan." }, 400);
    const avatarUrl = body.avatarUrl == null ? null : String(body.avatarUrl).slice(0, 1600);
    if (avatarUrl && !/^https:\/\//i.test(avatarUrl)) return json({ error: "Profil görseli geçersiz." }, 400);
    const timestamp = now();
    try {
      await env.DB.prepare(
        "INSERT INTO profiles (user_id, username, username_key, avatar_url, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?) " +
        "ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, username_key = excluded.username_key, avatar_url = excluded.avatar_url, updated_at = excluded.updated_at"
      ).bind(user.id, username, usernameKey(username), avatarUrl, timestamp, timestamp).run();
    } catch {
      return json({ error: "Bu kullanıcı adı başka bir savaşçı tarafından alınmış." }, 409);
    }
    await env.DB.prepare(
      "INSERT OR IGNORE INTO progress (user_id, level, best_level, coins, wins, updated_at) VALUES (?, 1, 1, 280, 0, ?)"
    ).bind(user.id, timestamp).run();
    return json({ profile: await profileFor(env, user.id) });
  }

  if (method === "GET" && path === "/api/progress") {
    const user = requireUser(request);
    await requireProfile(env, user);
    const progress = await env.DB.prepare("SELECT level, best_level AS bestLevel, coins, wins FROM progress WHERE user_id = ?").bind(user.id).first();
    return json({ progress: progress ?? { level: 1, bestLevel: 1, coins: 280, wins: 0 } });
  }

  if (method === "POST" && path === "/api/progress") {
    const user = requireUser(request);
    await requireProfile(env, user);
    const body = await readJson(request);
    const level = Math.max(1, Math.min(12, Math.floor(Number(body.level) || 1)));
    const bestLevel = Math.max(level, Math.min(12, Math.floor(Number(body.bestLevel) || level)));
    const coins = Math.max(0, Math.min(999999, Math.floor(Number(body.coins) || 0)));
    const wins = Math.max(0, Math.min(100000, Math.floor(Number(body.wins) || 0)));
    await env.DB.prepare(
      "INSERT INTO progress (user_id, level, best_level, coins, wins, updated_at) VALUES (?, ?, ?, ?, ?, ?) " +
      "ON CONFLICT(user_id) DO UPDATE SET level = MAX(progress.level, excluded.level), best_level = MAX(progress.best_level, excluded.best_level), coins = excluded.coins, wins = MAX(progress.wins, excluded.wins), updated_at = excluded.updated_at"
    ).bind(user.id, level, bestLevel, coins, wins, now()).run();
    return json({ ok: true });
  }

  if (method === "GET" && path === "/api/friends") {
    const user = requireUser(request);
    await requireProfile(env, user);
    const { results } = await env.DB.prepare(
      "SELECT f.user_id AS requester_id, f.friend_id, f.status, f.created_at, " +
      "p.username, p.avatar_url FROM friendships f " +
      "LEFT JOIN profiles p ON p.user_id = CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END " +
      "WHERE f.user_id = ? OR f.friend_id = ? ORDER BY f.created_at DESC LIMIT 100"
    ).bind(user.id, user.id, user.id).all();
    const friends = results.filter((row) => row.status === "accepted");
    const incoming = results.filter((row) => row.status === "pending" && row.friend_id === user.id);
    const outgoing = results.filter((row) => row.status === "pending" && row.requester_id === user.id);
    return json({ friends, incoming, outgoing });
  }

  if (method === "POST" && path === "/api/friends") {
    const user = requireUser(request);
    const profile = await requireProfile(env, user);
    const body = await readJson(request);
    const username = cleanUsername(body.username);
    if (!validUsername(username)) return json({ error: "Geçerli bir kullanıcı adı yaz." }, 400);
    const target = await env.DB.prepare("SELECT user_id, username FROM profiles WHERE username_key = ?").bind(usernameKey(username)).first();
    if (!target) return json({ error: "Bu kullanıcı adı bulunamadı." }, 404);
    if (target.user_id === user.id) return json({ error: "Kendine arkadaşlık isteği gönderemezsin." }, 400);
    const existing = await env.DB.prepare(
      "SELECT status FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?) LIMIT 1"
    ).bind(user.id, target.user_id, target.user_id, user.id).first();
    if (existing?.status === "accepted") return json({ error: "Bu savaşçı zaten arkadaş listende." }, 409);
    if (existing?.status === "pending") return json({ error: "Bu kişiyle bekleyen bir arkadaşlık isteği var." }, 409);
    await env.DB.prepare("INSERT INTO friendships (user_id, friend_id, status, created_at) VALUES (?, ?, 'pending', ?)")
      .bind(user.id, target.user_id, now()).run();
    return json({ ok: true, username: profile.username, target: target.username });
  }

  if (method === "POST" && path === "/api/friends/accept") {
    const user = requireUser(request);
    const body = await readJson(request);
    const friendId = String(body.friendId ?? "").slice(0, 200);
    if (!friendId || friendId === user.id) return json({ error: "Arkadaşlık isteği geçersiz." }, 400);
    const result = await env.DB.prepare(
      "UPDATE friendships SET status = 'accepted' WHERE user_id = ? AND friend_id = ? AND status = 'pending'"
    ).bind(friendId, user.id).run();
    if (!result.meta?.changes) return json({ error: "Bekleyen istek bulunamadı." }, 404);
    return json({ ok: true });
  }

  if (method === "POST" && path === "/api/rooms") {
    const user = requireUser(request);
    const profile = await requireProfile(env, user);
    const body = await readJson(request);
    const mode = body.mode === "trio" ? "trio" : "duel";
    let code = "";
    for (let attempt = 0; attempt < 5; attempt++) {
      code = makeRoomCode();
      try {
        await env.DB.prepare("INSERT INTO rooms (code, user_id, host_username, mode, status, created_at, updated_at) VALUES (?, ?, ?, ?, 'open', ?, ?)")
          .bind(code, user.id, profile.username, mode, now(), now()).run();
        break;
      } catch {
        code = "";
      }
    }
    if (!code) return json({ error: "Oda kodu oluşturulamadı. Tekrar dene." }, 500);
    return json({ code, mode, maxPlayers: mode === "trio" ? 3 : 2 });
  }

  if (method === "POST" && path === "/api/rooms/join") {
    const user = requireUser(request);
    await requireProfile(env, user);
    const body = await readJson(request);
    const code = String(body.code ?? "").replace(/[^a-z0-9]/gi, "").toUpperCase().slice(0, 6);
    if (code.length !== 6) return json({ error: "Altı haneli oda kodunu yaz." }, 400);
    const room = await env.DB.prepare("SELECT code, mode, status FROM rooms WHERE code = ?").bind(code).first();
    if (!room) return json({ error: "Bu oda kodu bulunamadı." }, 404);
    return json({ code: room.code, mode: room.mode, status: room.status, maxPlayers: room.mode === "trio" ? 3 : 2 });
  }

  if (method === "POST" && path === "/api/invites") {
    const user = requireUser(request);
    const profile = await requireProfile(env, user);
    const body = await readJson(request);
    const username = cleanUsername(body.username);
    const code = String(body.code ?? "").replace(/[^a-z0-9]/gi, "").toUpperCase().slice(0, 6);
    const target = await env.DB.prepare("SELECT user_id, username FROM profiles WHERE username_key = ?").bind(usernameKey(username)).first();
    if (!target) return json({ error: "Bu kullanıcı adı bulunamadı." }, 404);
    if (target.user_id === user.id) return json({ error: "Kendine davet gönderemezsin." }, 400);
    const room = await env.DB.prepare("SELECT code FROM rooms WHERE code = ?").bind(code).first();
    if (!room) return json({ error: "Oda bulunamadı." }, 404);
    await env.DB.prepare("INSERT INTO invites (user_id, receiver_id, room_code, created_at) VALUES (?, ?, ?, ?)")
      .bind(user.id, target.user_id, code, now()).run();
    return json({ ok: true, from: profile.username, target: target.username, code });
  }

  if (method === "GET" && path === "/api/invites") {
    const user = requireUser(request);
    await requireProfile(env, user);
    const { results } = await env.DB.prepare(
      "SELECT i.id, i.room_code, i.created_at, p.username, p.avatar_url FROM invites i " +
      "LEFT JOIN profiles p ON p.user_id = i.user_id WHERE i.receiver_id = ? ORDER BY i.created_at DESC LIMIT 30"
    ).bind(user.id).all();
    return json({ invites: results });
  }

  return json({ error: "Bulunamadı." }, 404);
}

export default {
  async fetch(request, env) {
    try {
      return await route(request, env);
    } catch (error) {
      console.error("api", error?.stack ?? error);
      return json({ error: error.message ?? "Sunucu hatası.", code: error.code ?? "server" }, error.status ?? 500);
    }
  },
};

const liveMatches = new Map();
const connectionMatch = new Map();
const MOVE_LIMIT = 130;
const HIT_RANGE = 110;

function cleanLivePlayer(conn) {
  return {
    id: conn.id,
    userId: conn.userId,
    username: conn.arenaProfile?.username ?? conn.username ?? "Savaşçı",
    avatarUrl: conn.arenaProfile?.avatar_url ?? null,
    team: conn.arenaTeam ?? "blue",
    x: conn.arenaX ?? 150,
    hp: conn.arenaHp ?? 100,
    kills: conn.arenaKills ?? 0,
  };
}

function lobbyState(match) {
  return {
    type: "lobby",
    ok: true,
    code: match.code,
    mode: match.mode,
    maxPlayers: match.maxPlayers,
    hostId: match.hostId,
    started: match.started,
    players: [...match.players.values()].map(cleanLivePlayer),
  };
}

function assignTeam(match) {
  const players = [...match.players.values()];
  if (match.mode === "trio") {
    const blues = players.filter((conn) => conn.arenaTeam === "blue").length;
    return blues < 2 ? "blue" : "red";
  }
  return players.length === 0 ? "blue" : "red";
}

function broadcastMatch(_room, match, event, except = []) {
  const excluded = new Set(except);
  for (const [id, conn] of match.players) {
    if (!excluded.has(id)) conn.send(event);
  }
}

export const room = {
  tickMs: 100,
  async onConnect(conn) {
    conn.send({ type: "welcome", id: conn.id, userId: conn.userId, username: conn.username });
  },

  async onMessage(conn, raw, room, env) {
    let message;
    try { message = typeof raw === "string" ? JSON.parse(raw) : raw; } catch { return; }
    if (!message || typeof message.type !== "string") return;

    if (message.type === "enter") {
      if (conn.identity !== "user" || !conn.userId) {
        conn.send({ type: "lobby", ok: false, error: "Çok oyunculu oyun için giriş yapmalısın." });
        return;
      }
      const code = String(message.code ?? "").replace(/[^a-z0-9]/gi, "").toUpperCase().slice(0, 6);
      if (code.length !== 6) {
        conn.send({ type: "lobby", ok: false, error: "Oda kodu geçersiz." });
        return;
      }
      const storedRoom = await env.DB.prepare("SELECT code, user_id, mode, host_username, status FROM rooms WHERE code = ?").bind(code).first();
      if (!storedRoom) {
        conn.send({ type: "lobby", ok: false, error: "Bu oda kodu bulunamadı." });
        return;
      }
      const profile = await profileFor(env, conn.userId);
      if (!profile) {
        conn.send({ type: "lobby", ok: false, error: "Önce profilini oluştur." });
        return;
      }
      let match = liveMatches.get(code);
      if (!match) {
        match = {
          code, mode: storedRoom.mode, maxPlayers: storedRoom.mode === "trio" ? 3 : 2,
          hostId: storedRoom.user_id, players: new Map(), started: false,
          lastSnapshot: "",
        };
        liveMatches.set(code, match);
      }
      const sameAccount = [...match.players.values()].find((player) => player.userId === conn.userId);
      if (sameAccount) {
        match.players.delete(sameAccount.id);
        connectionMatch.delete(sameAccount.id);
      }
      if (!match.players.has(conn.id) && match.players.size >= match.maxPlayers) {
        conn.send({ type: "lobby", ok: false, error: "Bu oda dolu." });
        return;
      }
      if (match.started) {
        conn.send({ type: "lobby", ok: false, error: "Bu maç başladı; sonraki maçta tekrar katılabilirsin." });
        return;
      }
      if (![...match.players.values()].some((player) => player.userId === match.hostId)) match.hostId = conn.userId;
      conn.arenaProfile = profile;
      conn.arenaTeam = assignTeam(match);
      conn.arenaX = conn.arenaTeam === "blue" ? 170 : 1110;
      conn.arenaHp = 100;
      conn.arenaKills = 0;
      conn.arenaLastMove = 0;
      conn.arenaLastAttack = 0;
      conn.arenaVoice = false;
      match.players.set(conn.id, conn);
      connectionMatch.set(conn.id, code);
      conn.send({ ...lobbyState(match), type: "joined", selfId: conn.id });
      broadcastMatch(room, match, { type: "player-joined", player: cleanLivePlayer(conn) }, [conn.id]);
      broadcastMatch(room, match, lobbyState(match), [conn.id]);
      return;
    }

    const code = connectionMatch.get(conn.id);
    const match = code ? liveMatches.get(code) : null;
    if (!match || !match.players.has(conn.id)) return;
    const me = match.players.get(conn.id);

    if (message.type === "move" && match.started) {
      const x = Number(message.x);
      const timestamp = Date.now();
      if (!Number.isFinite(x) || timestamp - me.arenaLastMove < 70 || Math.abs(x - me.arenaX) > MOVE_LIMIT) return;
      me.arenaX = Math.max(88, Math.min(1192, x));
      me.arenaLastMove = timestamp;
      return;
    }

    if (message.type === "attack" && match.started) {
      if (Date.now() - me.arenaLastAttack < 430) return;
      const target = match.players.get(String(message.target ?? ""));
      if (!target || target.arenaTeam === me.arenaTeam || target.arenaHp <= 0 || Math.abs(target.arenaX - me.arenaX) > HIT_RANGE) return;
      me.arenaLastAttack = Date.now();
      target.arenaHp = Math.max(0, target.arenaHp - 24);
      let winner = null;
      if (target.arenaHp <= 0) {
        me.arenaKills++;
        const remaining = [...match.players.values()].some((player) => player.arenaTeam === target.arenaTeam && player.arenaHp > 0);
        if (!remaining) winner = me.arenaTeam;
      }
      broadcastMatch(room, match, {
        type: "combat-hit", attacker: me.id, target: target.id, hp: target.arenaHp,
        kills: me.arenaKills, winner,
      });
      if (winner) {
        match.started = false;
        await env.DB.prepare("UPDATE rooms SET status = 'finished', updated_at = ? WHERE code = ?")
          .bind(Date.now(), match.code).run();
      }
      return;
    }

    if (message.type === "start") {
      if (me.userId !== match.hostId) {
        conn.send({ type: "notice", text: "Savaşı yalnızca oda kurucusu başlatabilir." });
        return;
      }
      if (match.players.size < 2) {
        conn.send({ type: "notice", text: "Savaşa başlamak için en az iki savaşçı gerekli." });
        return;
      }
      for (const player of match.players.values()) {
        player.arenaHp = 100;
        player.arenaX = player.arenaTeam === "blue" ? 170 : 1110;
      }
      match.started = true;
      await env.DB.prepare("UPDATE rooms SET status = 'playing', updated_at = ? WHERE code = ?")
        .bind(Date.now(), match.code).run();
      broadcastMatch(room, match, {
        type: "game-start",
        code: match.code,
        hostId: match.hostId,
        players: [...match.players.values()].map(cleanLivePlayer),
      });
      return;
    }

    if (message.type === "chat") {
      const text = room.censor(String(message.text ?? "")).trim().slice(0, 200);
      if (text) broadcastMatch(room, match, { type: "chat", from: me.username, text, at: Date.now() });
      return;
    }

    if (message.type === "voice-ready") {
      me.arenaVoice = Boolean(message.enabled);
      if (me.arenaVoice) {
        for (const [peerId, peer] of match.players) {
          if (peerId !== conn.id && peer.arenaVoice) {
            conn.send({ type: "voice-ready", id: peerId, enabled: true });
          }
        }
      }
      broadcastMatch(room, match, { type: "voice-ready", id: conn.id, enabled: me.arenaVoice }, [conn.id]);
      return;
    }

    if (message.type === "voice-signal") {
      const peerId = String(message.to ?? "");
      const peer = match.players.get(peerId);
      if (!peer || !message.signal || JSON.stringify(message.signal).length > 20000) return;
      peer.send({ type: "voice-signal", from: conn.id, signal: message.signal });
    }
  },

  async onTick(room) {
    for (const match of liveMatches.values()) {
      if (!match.started || !match.players.size) continue;
      const players = [...match.players.values()].map((conn) => ({
        id: conn.id, x: Math.round(conn.arenaX), hp: conn.arenaHp,
      }));
      const snapshot = JSON.stringify(players);
      if (snapshot === match.lastSnapshot) continue;
      match.lastSnapshot = snapshot;
      broadcastMatch(room, match, { type: "snapshot", t: Date.now(), players });
    }
  },

  async onClose(conn, room, env) {
    const code = connectionMatch.get(conn.id);
    connectionMatch.delete(conn.id);
    if (!code) return;
    const match = liveMatches.get(code);
    if (!match) return;
    broadcastMatch(room, match, { type: "voice-ready", id: conn.id, enabled: false }, [conn.id]);
    match.players.delete(conn.id);
    if (match.players.size) {
      if (![...match.players.values()].some((player) => player.userId === match.hostId)) {
        match.hostId = [...match.players.values()][0].userId;
      }
      if (match.started) {
        const remainingTeams = new Set([...match.players.values()].filter((player) => player.arenaHp > 0).map((player) => player.arenaTeam));
        if (remainingTeams.size === 1) {
          const [winner] = remainingTeams;
          match.started = false;
          broadcastMatch(room, match, { type: "match-ended", winner });
          await env.DB.prepare("UPDATE rooms SET status = 'finished', updated_at = ? WHERE code = ?")
            .bind(Date.now(), match.code).run();
        }
      }
      broadcastMatch(room, match, { type: "player-left", id: conn.id });
      broadcastMatch(room, match, lobbyState(match));
    } else {
      match.started = false;
      match.lastSnapshot = "";
    }
  },
};
