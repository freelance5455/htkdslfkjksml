// Bolemo World HTTP + WebSocket server
const http=require('http'),fs=require('fs'),path=require('path'),WebSocket=require('ws');
const PORT=process.env.PORT||8080;
const server=http.createServer((req,res)=>{
 const pathname=(req.url||'/').split('?')[0];
 if(pathname==='/'||pathname==='/index.html'){
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache'});
  fs.createReadStream(path.join(__dirname,'index.html')).pipe(res);
 }else{res.writeHead(404);res.end('Not found')}
});
const wss=new WebSocket.Server({server}),players={};
function broadcast(data){const msg=JSON.stringify(data);wss.clients.forEach(c=>{if(c.readyState===WebSocket.OPEN)c.send(msg)})}
wss.on('connection',socket=>{let id=null;
 socket.on('message',raw=>{let d;try{d=JSON.parse(raw)}catch{return}
  if(d.type==='join'){id=String(d.id||Math.random());players[id]={name:String(d.name||'Player').slice(0,20),x:Number(d.x)||0,z:Number(d.z)||0};broadcast({type:'state',players});return}
  if(!id||!players[id])return;
  if(d.type==='move'){players[id].x=Math.max(-22,Math.min(22,Number(d.x)||0));players[id].z=Math.max(-25,Math.min(25,Number(d.z)||0));broadcast({type:'state',players})}
  if(d.type==='chat')broadcast({type:'chat',name:String(d.name||players[id].name).slice(0,20),text:String(d.text||'').slice(0,180)})
 });
 socket.on('close',()=>{if(id){delete players[id];broadcast({type:'state',players})}});
});
server.listen(PORT,()=>console.log('Bolemo World server listening on '+PORT));
