import express from "express";

const app = express();
app.use(express.json({ limit: "20kb" }));
app.use(express.static("public"));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/chat", async (req, res) => {
  const message = req.body?.message;
  if (typeof message !== "string" || !message.trim() || message.length > 4000) {
    return res.status(400).json({ error: "कृपया 1 से 4000 अक्षरों का सवाल लिखें।" });
  }

  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    return res.status(503).json({ error: "AI key अभी सेट नहीं है। सर्वर के Environment Variables में GEMINI_API_KEY जोड़ें।" });
  }

  try {
    const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": key
        },
        body: JSON.stringify({
          system_instruction: {
            parts: [{ text: "आप एक मददगार AI सहायक हैं। उपयोगकर्ता की भाषा में सरल और उपयोगी जवाब दें।" }]
          },
          contents: [{ role: "user", parts: [{ text: message.trim() }] }],
          generationConfig: { maxOutputTokens: 800 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      console.error("Gemini API error status:", response.status);
      return res.status(502).json({ error: "AI सेवा से जवाब नहीं मिला। API key, मॉडल और मुफ्त quota जाँचें।" });
    }

    const reply = data?.candidates?.[0]?.content?.parts
      ?.map(part => part.text || "")
      .join("")
      .trim();

    res.json({ reply: reply || "माफ़ कीजिए, अभी जवाब नहीं मिला।" });
  } catch (err) {
    console.error("Request failed:", err?.name || "unknown");
    res.status(500).json({ error: "इंटरनेट या AI सर्वर में समस्या है। थोड़ी देर बाद कोशिश करें।" });
  }
});

const port = Number(process.env.PORT) || 10000;
app.listen(port, "0.0.0.0", () => console.log(`AI chat listening on ${port}`));
