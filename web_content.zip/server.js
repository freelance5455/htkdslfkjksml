const express = require("express");
const http = require("http");
const WebSocket = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static("public"));
app.get("/", (req, res) => res.sendFile(__dirname + "/public/index.html"));

const players = new Map();
let nextId = 1;

wss.on("connection", ws => {
  const id = String(nextId++);
  const player = { id, x: 0, z: 0, rot: 0, vehicle: false, name: "Jogador " + id };
  players.set(id, { ws, ...player });

  ws.send(JSON.stringify({ type: "welcome", id, players: [...players.values()].map(p => ({...p, ws: undefined})) }));

  ws.on("message", raw => {
    try {
      const msg = JSON.parse(raw);
      const p = players.get(id);
      if (!p) return;
      if (msg.type === "state") {
        p.x = Number(msg.x) || 0;
        p.z = Number(msg.z) || 0;
        p.rot = Number(msg.rot) || 0;
        p.vehicle = !!msg.vehicle;
        p.name = String(msg.name || p.name).slice(0, 20);
      }
      if (msg.type === "chat") {
        const text = String(msg.text || "").slice(0, 160);
        broadcast({ type: "chat", id, name: p.name, text });
      }
    } catch {}
  });

  ws.on("close", () => {
    players.delete(id);
    broadcast({ type: "leave", id });
  });
});

function broadcast(obj, except) {
  const s = JSON.stringify(obj);
  for (const [id, p] of players) {
    if (id !== except && p.ws.readyState === WebSocket.OPEN) p.ws.send(s);
  }
}

setInterval(() => {
  broadcast({
    type: "players",
    players: [...players.values()].map(p => ({
      id: p.id, x: p.x, z: p.z, rot: p.rot, vehicle: p.vehicle, name: p.name
    }))
  });
}, 80);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Vida Urbana RP rodando em http://localhost:${PORT}`));
