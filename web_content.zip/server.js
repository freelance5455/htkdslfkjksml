const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, "public");
const players = new Map();
const WORLD = { width: 2200, height: 1400 };
const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
  const requested = urlPath === "/" ? "/index.html" : urlPath;
  const file = path.normalize(path.join(ROOT, requested));
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(file);
    const type = ext === ".html" ? "text/html; charset=utf-8" :
      ext === ".js" ? "text/javascript; charset=utf-8" :
      ext === ".css" ? "text/css; charset=utf-8" : "application/octet-stream";
    res.writeHead(200, { "Content-Type": type, "Cache-Control": "no-store" });
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });
const names = ["MUBASHIR", "BLAZE", "NOVA", "SHADOW", "ACE", "TIGER", "ROCKET"];
const weapons = {
  pistol: { damage: 22, cooldown: 350, speed: 850, spread: 0.035, count: 1 },
  rifle: { damage: 13, cooldown: 115, speed: 1050, spread: 0.055, count: 1 },
  shotgun: { damage: 10, cooldown: 650, speed: 700, spread: 0.34, count: 7 }
};
function safeSend(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function rand(min, max) { return Math.random() * (max - min) + min; }
function snapshot() {
  return { type: "state", world: WORLD, players: [...players.values()].map(p => ({
    id:p.id, name:p.name, x:p.x, y:p.y, angle:p.angle, hp:p.hp, weapon:p.weapon,
    score:p.score, color:p.color, alive:p.alive
  })) };
}
wss.on("connection", ws => {
  const id = Math.random().toString(36).slice(2, 10);
  const p = {
    id, ws, name: names[Math.floor(Math.random()*names.length)],
    x: rand(120, WORLD.width-120), y: rand(120, WORLD.height-120),
    angle: 0, hp: 100, score: 0, weapon: "rifle", color: ["#56e0ff","#ffcc4d","#ff668f","#a78bfa","#6dff9b"][Math.floor(Math.random()*5)],
    alive: true, input: { up:false, down:false, left:false, right:false }, lastShot: 0,
    respawnAt: 0
  };
  players.set(id, p);
  safeSend(ws, { type:"welcome", id, name:p.name });
  ws.on("message", raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === "input") {
      p.input = {
        up:!!msg.up, down:!!msg.down, left:!!msg.left, right:!!msg.right
      };
      if (Number.isFinite(msg.angle)) p.angle = msg.angle;
      if (weapons[msg.weapon]) p.weapon = msg.weapon;
      if (msg.shoot) shoot(p);
    }
    if (msg.type === "name" && typeof msg.name === "string") {
      p.name = msg.name.replace(/[^a-zA-Z0-9 _-]/g, "").slice(0,14) || "PLAYER";
    }
  });
  ws.on("close", () => players.delete(id));
  ws.on("error", () => players.delete(id));
});
function shoot(p) {
  const w = weapons[p.weapon], now = Date.now();
  if (!p.alive || now - p.lastShot < w.cooldown) return;
  p.lastShot = now;
  for (let i=0;i<w.count;i++) {
    const angle = p.angle + (Math.random()-.5)*w.spread;
    const dx = Math.cos(angle), dy = Math.sin(angle);
    // Server-authoritative hitscan ray; nearest target on the firing line wins.
    let target = null, best = 470;
    for (const q of players.values()) {
      if (q.id === p.id || !q.alive) continue;
      const vx=q.x-p.x, vy=q.y-p.y, along=vx*dx+vy*dy;
      if (along < 12 || along > best) continue;
      const perpendicular=Math.abs(vx*dy-vy*dx);
      if (perpendicular < 24) { best=along; target=q; }
    }
    if (target) {
      target.hp -= w.damage;
      if (target.hp <= 0) {
        target.hp=0; target.alive=false; target.respawnAt=now+2200;
        p.score += 1;
      }
    }
  }
}
setInterval(() => {
  const dt = 1/30;
  for (const p of players.values()) {
    if (!p.alive) {
      if (Date.now() >= p.respawnAt) {
        p.alive=true; p.hp=100; p.x=rand(100,WORLD.width-100); p.y=rand(100,WORLD.height-100);
      }
      continue;
    }
    let vx=(p.input.right?1:0)-(p.input.left?1:0);
    let vy=(p.input.down?1:0)-(p.input.up?1:0);
    const len=Math.hypot(vx,vy)||1;
    p.x=Math.max(35,Math.min(WORLD.width-35,p.x+vx/len*255*dt));
    p.y=Math.max(35,Math.min(WORLD.height-35,p.y+vy/len*255*dt));
  }
  const state=JSON.stringify(snapshot());
  for (const p of players.values()) if (p.ws.readyState===WebSocket.OPEN) p.ws.send(state);
}, 1000/30);

server.listen(PORT, () => console.log(`Mubashir Bumraaa multiplayer running on port ${PORT}`));
