// VICE CITY server: accounts, player IDs, ID search, cloud saves, wallet (coins/diamonds), rare shop.
// Zero dependencies (Node 18+). Run: node server.js   Env: PORT, DATA_DIR (use a persistent disk!)
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000;
const DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const FILE = path.join(DIR, 'db.json');
fs.mkdirSync(DIR, { recursive: true });
let db = { players: {}, names: {}, tok: {} };
try { db = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch (e) {}
let dirty = false;
const flush = () => { if (!dirty) return; dirty = false; fs.writeFileSync(FILE + '.tmp', JSON.stringify(db)); fs.renameSync(FILE + '.tmp', FILE); };
setInterval(flush, 2000);
['SIGTERM', 'SIGINT'].forEach(s => process.on(s, () => { flush(); process.exit(0); }));

// Server-side prices (diamonds). The client only displays these.
const CATALOG = { cars: { phantom: 300, hellfire: 500, aurora: 800 }, chars: { ghost: 150, ninja: 200, gold: 300, royal: 600 } };
// [coins per event, daily cap, cooldown seconds]
const EARN = { mission: [40, 400, 5], pickup: [2, 100, 3], mpwin: [100, 500, 30], mpplay: [20, 200, 30], daily: [50, 50, 0] };
const RATE = 10; // 100 coins = 10 diamonds

const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString('hex');
const today = () => new Date().toISOString().slice(0, 10);
const wallet = p => ({ coins: p.coins, diamonds: p.diamonds, owned: p.owned, char: p.char, cat: CATALOG });
const pub = p => ({ id: p.id, name: p.name, joined: p.created, char: p.char, cars: p.owned.filter(k => CATALOG.cars[k]).length, missions: ((p.save && p.save.S && p.save.S.done) || []).length });
const fail = (code, msg) => Object.assign(new Error(msg), { code });
const hits = {};
function limit(ip, max) { const m = Math.floor(Date.now() / 60000), k = ip + m; hits[k] = (hits[k] || 0) + 1; if (hits[k] > max) throw fail(429, 'Too many attempts, wait a minute'); }
function newId() { let id; do { id = String(100000000 + crypto.randomInt(900000000)); } while (db.players[id]); return id; }
function issue(p) { const t = crypto.randomBytes(32).toString('hex'); db.tok[sha(t)] = p.id; dirty = true; return t; }
function auth(req) {
  const id = db.tok[sha(String(req.headers['x-player-token'] || ''))];
  if (!id || !db.players[id]) throw fail(401, 'Session expired, please log in again');
  return db.players[id];
}

const routes = {
  'POST /api/register': (req, b, ip) => {
    limit(ip, 10);
    const u = String(b.username || '').toLowerCase(), name = String(b.name || b.username || '').trim();
    if (!/^[a-z0-9_]{3,16}$/.test(u)) throw fail(400, 'Username: 3-16 letters, numbers or _');
    if (String(b.password || '').length < 6) throw fail(400, 'Password must be at least 6 characters');
    if (!/^[A-Za-z0-9 ]{2,16}$/.test(name)) throw fail(400, 'Name: 2-16 letters or numbers');
    if (db.names[u]) throw fail(409, 'Username already taken');
    const salt = crypto.randomBytes(16).toString('hex'), id = newId();
    const p = db.players[id] = { id, username: u, name, salt, pw: hashPw(b.password, salt), created: today(), coins: 0, diamonds: 0, owned: [], char: 'street', earn: { day: today(), tot: {}, last: {} }, save: null };
    db.names[u] = id;
    return { id, name, token: issue(p), wallet: wallet(p) };
  },
  'POST /api/login': (req, b, ip) => {
    limit(ip, 20);
    const p = db.players[db.names[String(b.username || '').toLowerCase()]];
    if (!p || !crypto.timingSafeEqual(Buffer.from(hashPw(String(b.password || ''), p.salt)), Buffer.from(p.pw))) throw fail(401, 'Wrong username or password');
    return { id: p.id, name: p.name, token: issue(p), wallet: wallet(p) };
  },
  'GET /api/me': req => { const p = auth(req); return { id: p.id, name: p.name, wallet: wallet(p) }; },
  'POST /api/earn': (req, b) => {
    const p = auth(req), r = EARN[b.src];
    if (!r) throw fail(400, 'Unknown source');
    const e = p.earn; if (e.day !== today()) { e.day = today(); e.tot = {}; e.last = {}; }
    const now = Date.now(), t = e.tot[b.src] || 0;
    if (now - (e.last[b.src] || 0) < r[2] * 1000 || t >= r[1]) return { gain: 0, wallet: wallet(p) };
    const gain = Math.min(r[0], r[1] - t);
    e.tot[b.src] = t + gain; e.last[b.src] = now; p.coins += gain; dirty = true;
    return { gain, wallet: wallet(p) };
  },
  'POST /api/exchange': (req, b) => {
    const p = auth(req), n = Math.floor(Number(b.coins));
    if (!(n >= 100) || n % 100) throw fail(400, 'Exchange in multiples of 100 coins');
    if (p.coins < n) throw fail(400, 'Not enough coins');
    p.coins -= n; p.diamonds += n / 100 * RATE; dirty = true;
    return { diamonds: n / 100 * RATE, wallet: wallet(p) };
  },
  'POST /api/buy': (req, b) => {
    const p = auth(req), k = String(b.item), price = CATALOG.cars[k] || CATALOG.chars[k];
    if (!price) throw fail(400, 'Unknown item');
    if (p.owned.includes(k)) throw fail(400, 'Already owned');
    if (p.diamonds < price) throw fail(400, 'Need ' + price + ' diamonds');
    p.diamonds -= price; p.owned.push(k); dirty = true;
    return { wallet: wallet(p) };
  },
  'POST /api/equip': (req, b) => {
    const p = auth(req), k = String(b.char);
    if (k !== 'street' && !(CATALOG.chars[k] && p.owned.includes(k))) throw fail(400, 'You do not own that character');
    p.char = k; dirty = true;
    return { wallet: wallet(p) };
  }
};

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x'), ip = req.socket.remoteAddress || '';
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-player-token');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  const send = (c, o) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (!url.pathname.startsWith('/api/')) {
    fs.readFile(path.join(__dirname, 'public', 'index.html'), (e, d) => { res.writeHead(e ? 404 : 200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(e ? 'Not found' : d); });
    return;
  }
  let body = '';
  req.on('data', c => { body += c; if (body.length > 400000) req.destroy(); });
  req.on('end', () => {
    try {
      const b = body ? JSON.parse(body) : {}, key = req.method + ' ' + url.pathname;
      let m;
      if (routes[key]) return send(200, routes[key](req, b, ip));
      if ((m = url.pathname.match(/^\/api\/players\/(\d{1,12})$/)) && req.method === 'GET') { // ID search
        auth(req);
        const p = db.players[m[1]]; if (!p) throw fail(404, 'No player with that ID');
        return send(200, pub(p));
      }
      if ((m = url.pathname.match(/^\/api\/saves\/(\d+)$/))) {
        const p = auth(req); if (p.id !== m[1]) throw fail(403, 'Not your save');
        if (req.method === 'GET') return send(200, { data: p.save });
        if (req.method === 'PUT') { p.save = b.data; dirty = true; return send(200, { ok: 1 }); }
      }
      throw fail(404, 'Not found');
    } catch (e) { send(e.code || 400, { error: e.code ? e.message : 'Bad request' }); }
  });
}).listen(PORT, () => console.log('Vice City server on :' + PORT));
