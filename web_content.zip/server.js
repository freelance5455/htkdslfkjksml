// KenZz Nokos demo backend — Node.js 20+
const express=require('express'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const app=express(),PORT=process.env.PORT||3000,DB=path.join(__dirname,'data.json');
app.use(express.json({limit:'3mb'}));app.use(express.static(path.join(__dirname,'public')));
const seed={users:[],deposits:[],orders:[],products:[
{id:'wa-blue',name:'Nokos WhatsApp • Paket klaim verifikasi',category:'WHATSAPP',price:50000,description:'Nomor untuk penggunaan sah. Centang biru resmi tidak dijamin dan hanya diputuskan Meta.'},
{id:'wa-basic',name:'Nokos WhatsApp biasa',category:'WHATSAPP',price:1000,description:'Nomor virtual; ketersediaan mengikuti stok pemasok.'},
{id:'other',name:'Nokos layanan lain',category:'LAINNYA',price:1500,description:'Pilihan nomor untuk layanan yang didukung pemasok.'}
]};
if(!fs.existsSync(DB))fs.writeFileSync(DB,JSON.stringify(seed,null,2));
const db=()=>JSON.parse(fs.readFileSync(DB,'utf8')),save=d=>fs.writeFileSync(DB,JSON.stringify(d,null,2));
const hash=(p,s)=>crypto.scryptSync(p,s,64).toString('hex');
function auth(req,res,next){let t=(req.headers.authorization||'').replace('Bearer ','');let d=db(),u=d.users.find(x=>x.token===t);if(!u)return res.status(401).json({error:'Silakan login kembali'});req.user=u;next()}
app.post('/api/register',(req,res)=>{let {email,password,name}=req.body||{};if(!email||!password||password.length<6||!name)return res.status(400).json({error:'Nama, email, dan password minimal 6 karakter wajib diisi'});let d=db();if(d.users.some(x=>x.email===email.toLowerCase()))return res.status(409).json({error:'Email sudah terdaftar'});let salt=crypto.randomBytes(16).toString('hex'),u={id:crypto.randomUUID(),email:email.toLowerCase(),name:String(name).slice(0,40),salt,pass:hash(password,salt),token:crypto.randomBytes(32).toString('hex'),balance:0,avatar:''};d.users.push(u);save(d);res.json({token:u.token})});
app.post('/api/login',(req,res)=>{let {email,password}=req.body||{},d=db(),u=d.users.find(x=>x.email===String(email||'').toLowerCase());if(!u||hash(password||'',u.salt)!==u.pass)return res.status(401).json({error:'Email atau password salah'});u.token=crypto.randomBytes(32).toString('hex');save(d);res.json({token:u.token})});
app.get('/api/me',auth,(req,res)=>res.json({user:{name:req.user.name,email:req.user.email,balance:req.user.balance,avatar:req.user.avatar}}));
app.get('/api/products',(req,res)=>res.json(db().products));
app.get('/api/orders',auth,(req,res)=>res.json(db().orders.filter(x=>x.userId===req.user.id).reverse()));
app.post('/api/orders',auth,(req,res)=>{let d=db(),p=d.products.find(x=>x.id===req.body.productId);if(!p)return res.status(404).json({error:'Produk tidak ditemukan'});if(!req.body.country)return res.status(400).json({error:'Pilih negara terlebih dahulu'});if(req.user.balance<p.price)return res.status(400).json({error:'Saldo tidak cukup. Silakan deposit terlebih dahulu.'});req.user.balance-=p.price;let o={id:crypto.randomUUID(),userId:req.user.id,productName:p.name+' • '+String(req.body.country).slice(0,80),country:String(req.body.country).slice(0,80),price:p.price,status:'MENUNGGU ADMIN',createdAt:new Date().toISOString()};d.orders.push(o);save(d);res.json(o)});
app.get('/api/deposits',auth,(req,res)=>res.json(db().deposits.filter(x=>x.userId===req.user.id).reverse()));
app.post('/api/deposits',auth,(req,res)=>{let {amount,method,note}=req.body||{};amount=Number(amount);if(!Number.isInteger(amount)||amount<1000||amount>100000000)return res.status(400).json({error:'Nominal deposit tidak valid'});let d=db(),x={id:crypto.randomUUID(),userId:req.user.id,amount,method:String(method||'').slice(0,40),note:String(note||'').slice(0,160),status:'MENUNGGU VERIFIKASI',createdAt:new Date().toISOString()};d.deposits.push(x);save(d);res.json(x)});
app.put('/api/profile',auth,(req,res)=>{let {name,avatar}=req.body||{};if(name)req.user.name=String(name).slice(0,40);if(avatar!==undefined){if(typeof avatar!=='string'||avatar.length>2100000)return res.status(400).json({error:'Foto tidak valid atau terlalu besar'});req.user.avatar=avatar}save(db());res.json({user:{name:req.user.name,email:req.user.email,balance:req.user.balance,avatar:req.user.avatar}})});
app.get('/api/health',(req,res)=>res.json({ok:true,service:'KenZz Nokos'}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`KenZz Nokos berjalan di http://localhost:${PORT}`));