'use strict';
// Dino Defense - tiny Node.js server (no dependencies)
// Serves the game and stores save data + leaderboard as JSON files.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const SAVE_FILE = path.join(ROOT, 'save.json');
const LB_FILE = path.join(ROOT, 'leaderboard.json');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return fallback; }
}

function sendJSON(res, code, data) {
  res.writeHead(code, { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}

function readBody(req, limit = 100 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

const num = (v, min, max) => Math.min(max, Math.max(min, Number(v) || 0));

function cleanVal(v, depth) {
  if (typeof v === 'number') return Number.isFinite(v) ? Math.max(-1e12, Math.min(1e12, v)) : 0;
  if (typeof v === 'boolean') return v;
  if (Array.isArray(v) && depth < 2) return v.slice(0, 60).map((x) => cleanVal(x, depth + 1)).filter((x) => x !== undefined);
  if (v && typeof v === 'object' && depth < 2) {
    const o = {};
    Object.keys(v).slice(0, 40).forEach((k) => { if (/^[a-zA-Z0-9_]{1,24}$/.test(k)) { const c = cleanVal(v[k], depth + 1); if (c !== undefined) o[k] = c; } });
    return o;
  }
  return undefined;
}

function cleanSave(d) {
  const out = {
    zone: num(d.zone, 1, 100), money: num(d.money, 0, 1e12), gems: num(d.gems, 0, 1e12),
    best: num(d.best, 1, 100), ts: num(d.ts, 0, 1e15), inf: !!d.inf
  };
  out.snap = d.snap && typeof d.snap === 'object' ? cleanVal(d.snap, 0) : null;
  return out;
}

async function handleApi(req, res, url) {
  try {
    if (url.pathname === '/api/save') {
      if (req.method === 'GET') return sendJSON(res, 200, readJSON(SAVE_FILE, {}));
      if (req.method === 'POST') {
        const data = cleanSave(JSON.parse(await readBody(req)));
        fs.writeFileSync(SAVE_FILE, JSON.stringify(data));
        return sendJSON(res, 200, { ok: true });
      }
    }
    if (url.pathname === '/api/leaderboard') {
      if (req.method === 'GET') return sendJSON(res, 200, readJSON(LB_FILE, []).slice(0, 10));
      if (req.method === 'POST') {
        const b = JSON.parse(await readBody(req));
        const entry = {
          name: String(b.name || 'player').slice(0, 20),
          zone: num(b.zone, 0, 100),
          kills: num(b.kills, 0, 1e7),
          at: Date.now()
        };
        const list = readJSON(LB_FILE, []);
        list.push(entry);
        list.sort((a, c) => c.zone - a.zone || c.kills - a.kills);
        fs.writeFileSync(LB_FILE, JSON.stringify(list.slice(0, 50)));
        return sendJSON(res, 200, { ok: true });
      }
    }
    sendJSON(res, 404, { error: 'not found' });
  } catch (e) {
    sendJSON(res, 400, { error: 'bad request' });
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) return handleApi(req, res, url);

  let rel = decodeURIComponent(url.pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(ROOT, rel));
  const blocked = ['server.js', 'save.json', 'leaderboard.json', 'package.json'];
  if (!file.startsWith(ROOT) || blocked.includes(path.basename(file))) {
    res.writeHead(403); return res.end('Forbidden');
  }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
    res.end(buf);
  });
});

server.listen(PORT, () => {
  console.log('Dino Defense running -> http://localhost:' + PORT);
});
