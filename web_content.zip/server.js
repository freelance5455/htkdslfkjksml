const express = require('express'), helmet = require('helmet'), rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs'), crypto = require('crypto'), path = require('path'), db = require('./db');
const { checkPass } = require('./lib/policy'), totp = require('./lib/totp');
const PROD = process.env.NODE_ENV === 'production', TYPES = ['user', 'email', 'domain', 'ip', 'phone', 'name', 'img', 'url', 'hash', 'crypto', 'asn', 'cve'];
const app = express(); app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"], imgSrc: ["'self'", 'data:'],
  connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"], baseUri: ["'none'"], formAction: ["'self'"],
  upgradeInsecureRequests: PROD ? [] : null } }, referrerPolicy: { policy: 'no-referrer' } }));
app.use((req, res, next) => { res.set('Permissions-Policy', 'geolocation=(), microphone=(), camera=(), payment=()'); next(); });
app.get('/healthz', (req, res) => res.json({ ok: 1 }));
app.use(express.json({ limit: '32kb' }));
// CSRF: cookies are SameSite=Strict + every non-GET request must carry this custom header
app.use((req, res, next) => (req.method !== 'GET' && req.get('X-Requested-With') !== 'fetch') ? res.status(403).json({ e: 'forbidden' }) : next());
const rl = (windowMs, max, e) => rateLimit({ windowMs, max, standardHeaders: true, legacyHeaders: false, message: { e } });
app.use('/api', rl(60e3, +process.env.RL_API_MAX || 120, 'too many requests'), (req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
const sensitive = rl(15 * 60e3, +process.env.RL_SENSITIVE_MAX || 10, 'too many attempts');

const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const log = (u, a) => db.prepare('INSERT INTO audit_log(username,action) VALUES(?,?)').run(u || '-', String(a).slice(0, 200));
const USER = /^[\w.-]{3,24}$/, DUMMY = bcrypt.hashSync('x', 12), TTL = 12 * 3600e3;
const cookieOpts = { httpOnly: true, sameSite: 'strict', secure: PROD, path: '/' };
const getSid = req => { const m = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith('sid=')); return m ? decodeURIComponent(m.slice(4)) : null; };
const getUser = id => db.prepare('SELECT * FROM users WHERE id=?').get(id);

// قفل مؤقت حسب اسم المستخدم (يشمل الأسماء غير الموجودة): 5 محاولات فاشلة / 15 دقيقة
const FAIL_WINDOW = 15 * 60e3, FAIL_MAX = +process.env.FAIL_MAX || 5, fails = new Map();
const fkey = n => String(n == null ? '' : n).toLowerCase().slice(0, 24);
const recentFails = k => { const a = (fails.get(k) || []).filter(t => Date.now() - t < FAIL_WINDOW); a.length ? fails.set(k, a) : fails.delete(k); return a; };
const locked = k => recentFails(k).length >= FAIL_MAX;
const addFail = k => { const a = recentFails(k); a.push(Date.now()); fails.set(k, a); };

function auth(req, res, next) {
  const t = getSid(req);
  if (t) {
    const u = db.prepare('SELECT u.id,u.username,u.role,u.totp_on FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?').get(sha(t), Date.now());
    if (u) { req.user = u; return next(); }
  }
  res.status(401).json({ e: 'unauthorized' });
}
const admin = (req, res, next) => req.user.role === 'admin' ? next() : res.status(403).json({ e: 'forbidden' });

// رمز TOTP أو رمز استرجاع (يُستهلك)
function check2fa(u, code) {
  code = String(code == null ? '' : code).trim().replace(/[\s-]/g, '').toLowerCase();
  if (/^\d{6}$/.test(code)) {
    const s = totp.verify(u.totp_secret, code, { last: u.totp_last });
    if (!s) return false;
    db.prepare('UPDATE users SET totp_last=? WHERE id=?').run(s, u.id); return true;
  }
  if (!/^[0-9a-f]{10}$/.test(code)) return false;
  const list = JSON.parse(u.recovery || '[]'), i = list.indexOf(sha(code));
  if (i < 0) return false;
  list.splice(i, 1); db.prepare('UPDATE users SET recovery=? WHERE id=?').run(JSON.stringify(list), u.id);
  log(u.username, 'recovery code used (' + list.length + ' left)'); return true;
}

app.post('/api/login', rl(15 * 60e3, +process.env.RL_LOGIN_MAX || 10, 'too many attempts'), (req, res) => {
  const { n, p, c } = req.body || {}, k = fkey(n);
  if (locked(k)) { log(null, 'locked login: ' + k); return res.status(429).json({ e: 'too many attempts' }); }
  const u = typeof n === 'string' ? db.prepare('SELECT * FROM users WHERE username=?').get(n) : null;
  const ok = bcrypt.compareSync(typeof p === 'string' ? p : '', u ? u.pass_hash : DUMMY) && u;
  if (!ok) { addFail(k); log(null, 'failed login: ' + String(n).slice(0, 24)); return res.status(401).json({ e: 'invalid credentials' }); }
  if (u.totp_on) {
    if (c == null || String(c).trim() === '') return res.json({ need2fa: 1 });
    if (!check2fa(u, c)) { addFail(k); log(u.username, 'failed 2fa'); return res.status(401).json({ e: 'invalid credentials' }); }
  }
  db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now());
  const t = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(sha(t), u.id, Date.now() + TTL);
  res.cookie('sid', t, { ...cookieOpts, maxAge: TTL }); log(u.username, 'login');
  res.json({ n: u.username, r: u.role, f: !!u.totp_on });
});
app.post('/api/logout', auth, (req, res) => {
  db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(getSid(req)));
  res.clearCookie('sid', cookieOpts); log(req.user.username, 'logout'); res.json({ ok: 1 });
});
app.get('/api/me', auth, (req, res) => res.json({ n: req.user.username, r: req.user.role, f: !!req.user.totp_on }));
app.get('/api/tools', auth, (req, res) => res.json(db.prepare('SELECT id,type,name,url,descr FROM custom_tools ORDER BY id').all()));

// ---- سجل البحث (لكل مستخدم) ----
const LOG_VALUES = process.env.LOG_SEARCH_VALUES !== '0';
app.post('/api/search', auth, (req, res) => {
  const { t, v } = req.body || {};
  if (!TYPES.includes(t) || typeof v !== 'string' || !v.trim() || v.length > 200) return res.status(400).json({ e: 'invalid search' });
  const val = v.trim(), uid = req.user.id, last = db.prepare('SELECT type,value FROM searches WHERE user_id=? ORDER BY id DESC LIMIT 1').get(uid);
  if (!last || last.type !== t || last.value !== val) {
    db.prepare('INSERT INTO searches(user_id,type,value) VALUES(?,?,?)').run(uid, t, val);
    db.prepare('DELETE FROM searches WHERE user_id=? AND id <= (SELECT MAX(id) FROM searches WHERE user_id=?) - 1000').run(uid, uid);
  }
  log(req.user.username, LOG_VALUES ? 'search ' + t + ': ' + val.slice(0, 60) : 'search ' + t); res.json({ ok: 1 });
});
app.get('/api/history', auth, (req, res) => res.json(db.prepare('SELECT type,value,MAX(id) m FROM searches WHERE user_id=? GROUP BY type,value ORDER BY m DESC LIMIT 30').all(req.user.id).map(({ type, value }) => ({ type, value }))));
app.delete('/api/history', auth, (req, res) => { db.prepare('DELETE FROM searches WHERE user_id=?').run(req.user.id); res.json({ ok: 1 }); });

// ---- الحالات (Cases): خاصة بكل مستخدم، حتى الأدمن ما يشوف حالات غيره ----
const C = express.Router(); C.use(auth); app.use('/api/cases', C);
const txt = (v, max) => typeof v === 'string' ? v.trim().slice(0, max) : '';
const ownCase = req => db.prepare('SELECT * FROM cases WHERE id=? AND user_id=?').get(+req.params.id || 0, req.user.id);
const touch = id => db.prepare('UPDATE cases SET updated_at=CURRENT_TIMESTAMP WHERE id=?').run(id);
C.get('/', (req, res) => res.json(db.prepare('SELECT c.id,c.title,c.target,c.status,c.created_at,c.updated_at,(SELECT COUNT(*) FROM case_items i WHERE i.case_id=c.id) n FROM cases c WHERE c.user_id=? ORDER BY c.updated_at DESC, c.id DESC').all(req.user.id)));
C.post('/', (req, res) => {
  const title = txt((req.body || {}).title, 80), target = txt((req.body || {}).target, 120);
  if (!title) return res.status(400).json({ e: 'title required' });
  if (db.prepare('SELECT COUNT(*) c FROM cases WHERE user_id=?').get(req.user.id).c >= 200) return res.status(400).json({ e: 'case limit reached (200)' });
  const r = db.prepare('INSERT INTO cases(user_id,title,target) VALUES(?,?,?)').run(req.user.id, title, target);
  res.json({ id: Number(r.lastInsertRowid) });
});
C.get('/:id', (req, res) => {
  const c = ownCase(req); if (!c) return res.status(404).json({ e: 'not found' });
  res.json({ case: { id: c.id, title: c.title, target: c.target, status: c.status, created_at: c.created_at, updated_at: c.updated_at },
    items: db.prepare('SELECT id,kind,type,value,text,created_at FROM case_items WHERE case_id=? ORDER BY id').all(c.id) });
});
C.put('/:id', (req, res) => {
  const c = ownCase(req); if (!c) return res.status(404).json({ e: 'not found' });
  const b = req.body || {}, title = b.title === undefined ? c.title : txt(b.title, 80), target = b.target === undefined ? c.target : txt(b.target, 120), status = b.status === undefined ? c.status : b.status;
  if (!title || !['open', 'closed'].includes(status)) return res.status(400).json({ e: 'invalid data' });
  db.prepare('UPDATE cases SET title=?,target=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(title, target, status, c.id); res.json({ ok: 1 });
});
C.delete('/:id', (req, res) => { const c = ownCase(req); if (!c) return res.status(404).json({ e: 'not found' }); db.prepare('DELETE FROM cases WHERE id=?').run(c.id); res.json({ ok: 1 }); });
C.post('/:id/items', (req, res) => {
  const c = ownCase(req); if (!c) return res.status(404).json({ e: 'not found' });
  const { kind, type } = req.body || {}; let value = '', text = '', t = '';
  if (kind === 'search') { t = type; value = txt(req.body.value, 200); if (!TYPES.includes(t) || !value) return res.status(400).json({ e: 'invalid search item' }); }
  else if (kind === 'note') { text = txt(req.body.text, 5000); if (!text) return res.status(400).json({ e: 'empty note' }); }
  else if (kind === 'link') { value = txt(req.body.value, 500); text = txt(req.body.text, 120); if (!/^https?:\/\/[^\s]+$/.test(value)) return res.status(400).json({ e: 'link must be http(s)' }); }
  else return res.status(400).json({ e: 'invalid kind' });
  if (db.prepare('SELECT COUNT(*) c FROM case_items WHERE case_id=?').get(c.id).c >= 500) return res.status(400).json({ e: 'item limit reached (500)' });
  const r = db.prepare('INSERT INTO case_items(case_id,kind,type,value,text) VALUES(?,?,?,?,?)').run(c.id, kind, t, value, text); touch(c.id);
  res.json({ id: Number(r.lastInsertRowid) });
});
C.delete('/:id/items/:iid', (req, res) => {
  const c = ownCase(req); if (!c) return res.status(404).json({ e: 'not found' });
  const r = db.prepare('DELETE FROM case_items WHERE id=? AND case_id=?').run(+req.params.iid || 0, c.id);
  if (!r.changes) return res.status(404).json({ e: 'not found' }); touch(c.id); res.json({ ok: 1 });
});
app.post('/api/me/password', auth, sensitive, (req, res) => {
  const { o, p } = req.body || {}, u = getUser(req.user.id);
  if (!bcrypt.compareSync(String(o || ''), u.pass_hash)) return res.status(400).json({ e: 'wrong current password' });
  const pe = checkPass(p, u.username); if (pe) return res.status(400).json({ e: pe });
  db.prepare('UPDATE users SET pass_hash=? WHERE id=?').run(bcrypt.hashSync(p, 12), u.id);
  db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash<>?').run(u.id, sha(getSid(req)));
  log(u.username, 'password changed'); res.json({ ok: 1 });
});

// ---- 2FA (TOTP) ----
app.post('/api/me/2fa/setup', auth, (req, res) => {
  const u = getUser(req.user.id);
  if (u.totp_on) return res.status(400).json({ e: '2fa already enabled' });
  const s = totp.newSecret();
  db.prepare('UPDATE users SET totp_secret=?, totp_last=0 WHERE id=?').run(s, u.id);
  res.json({ secret: s, uri: totp.uri(s, u.username) });
});
app.post('/api/me/2fa/enable', auth, sensitive, (req, res) => {
  const u = getUser(req.user.id);
  if (u.totp_on || !u.totp_secret) return res.status(400).json({ e: 'run setup first' });
  const s = totp.verify(u.totp_secret, String((req.body || {}).c || '').trim());
  if (!s) return res.status(400).json({ e: 'invalid code' });
  const codes = Array.from({ length: 8 }, () => { const h = crypto.randomBytes(5).toString('hex'); return h.slice(0, 5) + '-' + h.slice(5); });
  db.prepare('UPDATE users SET totp_on=1, totp_last=?, recovery=? WHERE id=?').run(s, JSON.stringify(codes.map(x => sha(x.replace('-', '')))), u.id);
  log(u.username, '2fa enabled'); res.json({ codes });
});
app.post('/api/me/2fa/disable', auth, sensitive, (req, res) => {
  const { p, c } = req.body || {}, u = getUser(req.user.id);
  if (!u.totp_on) return res.status(400).json({ e: '2fa not enabled' });
  if (!bcrypt.compareSync(String(p || ''), u.pass_hash)) return res.status(400).json({ e: 'wrong password' });
  if (!check2fa(u, c)) return res.status(400).json({ e: 'invalid code' });
  db.prepare("UPDATE users SET totp_on=0, totp_secret=NULL, totp_last=0, recovery='[]' WHERE id=?").run(u.id);
  log(u.username, '2fa disabled'); res.json({ ok: 1 });
});

// ---- admin ----
const A = express.Router(); A.use(auth, admin); app.use('/api/admin', A);
A.get('/users', (req, res) => res.json(db.prepare('SELECT id,username,role,created_at,totp_on FROM users ORDER BY id').all()));
A.post('/users', (req, res) => {
  const { n, p, r } = req.body || {};
  if (typeof n !== 'string' || !USER.test(n)) return res.status(400).json({ e: 'invalid username' });
  const pe = checkPass(p, n); if (pe) return res.status(400).json({ e: pe });
  if (!['admin', 'user'].includes(r)) return res.status(400).json({ e: 'invalid role' });
  try { db.prepare('INSERT INTO users(username,pass_hash,role) VALUES(?,?,?)').run(n, bcrypt.hashSync(p, 12), r); }
  catch (e) { return res.status(409).json({ e: 'username exists' }); }
  log(req.user.username, 'add user ' + n); res.json({ ok: 1 });
});
A.post('/users/:id/reset2fa', (req, res) => {
  const id = +req.params.id || 0, t = getUser(id);
  if (!t) return res.status(404).json({ e: 'not found' });
  db.prepare("UPDATE users SET totp_on=0, totp_secret=NULL, totp_last=0, recovery='[]' WHERE id=?").run(id);
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
  log(req.user.username, 'reset 2fa ' + t.username); res.json({ ok: 1 });
});
A.delete('/users/:id', (req, res) => {
  const id = +req.params.id || 0, t = getUser(id);
  if (!t) return res.status(404).json({ e: 'not found' });
  if (id === req.user.id) return res.status(400).json({ e: 'cannot delete yourself' });
  if (t.role === 'admin' && db.prepare("SELECT COUNT(*) c FROM users WHERE role='admin'").get().c < 2) return res.status(400).json({ e: 'last admin' });
  db.prepare('DELETE FROM users WHERE id=?').run(id); log(req.user.username, 'del user ' + t.username); res.json({ ok: 1 });
});
A.post('/tools', (req, res) => {
  const { type, name, url, descr } = req.body || {};
  if (!TYPES.includes(type) || typeof name !== 'string' || !name.trim() || name.length > 40) return res.status(400).json({ e: 'invalid type/name' });
  if (typeof url !== 'string' || url.length > 500 || !/^https?:\/\/[^\s]+\{q\}/.test(url)) return res.status(400).json({ e: 'url must be http(s) and contain {q}' });
  db.prepare('INSERT INTO custom_tools(type,name,url,descr) VALUES(?,?,?,?)').run(type, name.trim(), url, String(descr || '').slice(0, 120));
  log(req.user.username, 'add tool ' + name.slice(0, 40)); res.json({ ok: 1 });
});
A.delete('/tools/:id', (req, res) => { const id = +req.params.id || 0; db.prepare('DELETE FROM custom_tools WHERE id=?').run(id); log(req.user.username, 'del tool #' + id); res.json({ ok: 1 }); });
A.get('/log', (req, res) => res.json(db.prepare('SELECT ts,username,action FROM audit_log ORDER BY id DESC LIMIT 200').all()));
A.delete('/log', (req, res) => { db.prepare('DELETE FROM audit_log').run(); log(req.user.username, 'log cleared'); res.json({ ok: 1 }); });
A.get('/export', (req, res) => {
  res.setHeader('Content-Disposition', 'attachment; filename="osint-backup.json"');
  res.json({ users: db.prepare('SELECT username,role,created_at,totp_on FROM users').all(), tools: db.prepare('SELECT type,name,url,descr FROM custom_tools').all(), log: db.prepare('SELECT ts,username,action FROM audit_log').all() });
});

app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', (req, res) => res.status(404).json({ e: 'not found' }));
app.use((err, req, res, next) => {
  const s = err && err.status >= 400 && err.status < 500 ? err.status : 500;
  if (s === 500) console.error(err && err.stack || err);
  if (res.headersSent) return next(err);
  res.status(s).json({ e: s === 413 ? 'payload too large' : s === 500 ? 'server error' : 'bad request' });
});

// تنظيف دوري: الجلسات المنتهية + سقف لسجل النشاط (آخر 5000 سطر)
setInterval(() => {
  try { db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now()); db.prepare('DELETE FROM audit_log WHERE id <= (SELECT MAX(id) FROM audit_log) - 5000').run(); } catch (e) {}
}, 3600e3).unref();

// first admin: ADMIN_USER (+ ADMIN_PASS اختياري: لو فاضي يتولّد باسورد عشوائي ويُطبع مرة وحدة) أو `npm run create-admin`
if (!db.prepare('SELECT 1 FROM users LIMIT 1').get()) {
  const { ADMIN_USER: n } = process.env; let p = process.env.ADMIN_PASS, gen = false;
  if (USER.test(n || '')) {
    if (!p) { do { p = crypto.randomBytes(12).toString('base64url'); } while (checkPass(p, n)); gen = true; }
    const pe = checkPass(p, n);
    if (pe) console.log('ADMIN_PASS rejected: ' + pe);
    else {
      db.prepare("INSERT INTO users(username,pass_hash,role) VALUES(?,?, 'admin')").run(n, bcrypt.hashSync(p, 12));
      console.log('Admin created: ' + n);
      if (gen) console.log('GENERATED ADMIN PASSWORD (shown once, change it after first login): ' + p);
    }
  } else console.log('No users yet. Run: npm run create-admin -- <username> <password>  (or set ADMIN_USER in .env)');
}
app.listen(process.env.PORT || 3000, () => console.log('OSINT Hub on :' + (process.env.PORT || 3000)));
