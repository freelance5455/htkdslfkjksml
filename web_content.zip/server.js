require('dotenv').config();
const express = require('express');
const path = require('path');
const app = express();
app.use(express.json({limit:'12mb'}));
app.use(express.static(path.join(__dirname,'public')));
const PORT = process.env.PORT || 3000;
app.get('/api/health',(req,res)=>res.json({ok:true,configured:!!process.env.AI_API_KEY}));
app.post('/api/chat',async(req,res)=>{
  try{
    const {message='',image=null,history=[],model='gpt-4o-mini',language='ps'}=req.body||{};
    if(!process.env.AI_API_KEY) return res.status(503).json({error:'د سرور مدیر باید AI_API_KEY په .env فایل کې تنظیم کړي.'});
    if(!message && !image) return res.status(400).json({error:'پوښتنه یا عکس اړین دی.'});
    const base=(process.env.AI_BASE_URL||'https://api.openai.com/v1').replace(/\/+$/,'');
    const userContent=[];
    if(message) userContent.push({type:'text',text:message});
    if(image){
      if(typeof image!=='string'||!image.startsWith('data:image/')) return res.status(400).json({error:'د عکس بڼه ناسمه ده.'});
      userContent.push({type:'image_url',image_url:{url:image}});
    }
    const safeHistory=Array.isArray(history)?history.slice(-12).filter(x=>x&&['user','assistant'].includes(x.role)&&typeof x.content==='string').map(x=>({role:x.role,content:x.content})): [];
    const system=language==='ps'?'ته ZAKI AI یې، یو مهربان، دقیق او ګټور مرستیال. په روانه پښتو ځواب ورکړه، مګر که کاروونکی بله ژبه وغواړي هماغه وکاروه. د روغتیا، قانون او خوندیتوب په موضوعاتو کې احتیاط او روښانه محدودیتونه بیان کړه.':'You are ZAKI AI, a helpful and accurate assistant. Reply in the language used by the user.';
    const response=await fetch(base+'/chat/completions',{method:'POST',headers:{'Authorization':'Bearer '+process.env.AI_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({model,messages:[{role:'system',content:system},...safeHistory,{role:'user',content:image?userContent:message}],temperature:0.7})});
    const data=await response.json();
    if(!response.ok) return res.status(response.status).json({error:data.error?.message||'AI provider request failed.'});
    res.json({answer:data.choices?.[0]?.message?.content||'ځواب ترلاسه نه شو.'});
  }catch(e){console.error(e);res.status(500).json({error:'د سرور داخلي ستونزه.'});}
});
app.listen(PORT,()=>console.log(`ZAKI AI running at http://localhost:${PORT}`));
