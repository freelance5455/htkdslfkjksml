const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");
const ADMIN_KEY = process.env.ADMIN_KEY || "change-this-admin-key";
const PAYMENT_MODE = process.env.PAYMENT_MODE || "demo";

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, "[]", "utf8");

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

const products = [
  { id: "ph-001", name: "Android Smartphone", category: "Phones", price: 450000, stock: 12, emoji: "📱", description: "Everyday smartphone for calls, apps and social media." },
  { id: "ph-002", name: "Wireless Earbuds", category: "Audio", price: 65000, stock: 25, emoji: "🎧", description: "Compact wireless earbuds for music and calls." },
  { id: "ph-003", name: "USB-C Fast Charger", category: "Accessories", price: 35000, stock: 30, emoji: "🔌", description: "USB-C wall charger. Check device compatibility before use." },
  { id: "ph-004", name: "Power Bank 20,000mAh", category: "Accessories", price: 85000, stock: 18, emoji: "🔋", description: "Portable charging for compatible phones and devices." },
  { id: "ph-005", name: "Bluetooth Speaker", category: "Audio", price: 95000, stock: 14, emoji: "🔊", description: "Portable speaker for home or outdoor listening." },
  { id: "ph-006", name: "Laptop", category: "Computers", price: 1250000, stock: 5, emoji: "💻", description: "General-purpose laptop for study and office work." },
  { id: "ph-007", name: "Wireless Mouse", category: "Computers", price: 45000, stock: 20, emoji: "🖱️", description: "Wireless mouse for laptops and desktop computers." },
  { id: "ph-008", name: "Phone Protective Case", category: "Accessories", price: 20000, stock: 40, emoji: "📦", description: "Protective case. Confirm your phone model before ordering." }
];

function readOrders() {
  try { return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8")); }
  catch { return []; }
}
function writeOrders(orders) {
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), "utf8");
}
function adminOnly(req, res, next) {
  const provided = req.get("x-admin-key") || "";
  if (!process.env.ADMIN_KEY || provided !== ADMIN_KEY) {
    return res.status(401).json({ error: "Unauthorized. Set ADMIN_KEY in your environment and enter it in the admin panel." });
  }
  next();
}
function ugx(amount) {
  return Math.round(Number(amount) || 0);
}

app.get("/api/products", (_req, res) => res.json(products));

app.post("/api/orders", (req, res) => {
  const body = req.body || {};
  const customer = body.customer || {};
  const items = Array.isArray(body.items) ? body.items : [];
  const allowedPayments = ["cash", "mtn_demo", "airtel_demo"];
  if (!String(customer.name || "").trim() || !String(customer.phone || "").trim() ||
      !String(customer.address || "").trim() || items.length < 1 ||
      !allowedPayments.includes(body.paymentMethod)) {
    return res.status(400).json({ error: "Please provide your name, phone, delivery address, cart items and a valid payment option." });
  }
  if (String(customer.name).length > 100 || String(customer.phone).length > 30 ||
      String(customer.address).length > 500) {
    return res.status(400).json({ error: "One or more fields are too long." });
  }

  const cleanItems = [];
  for (const item of items) {
    const product = products.find(p => p.id === String(item.id));
    const quantity = Number(item.quantity);
    if (!product || !Number.isInteger(quantity) || quantity < 1 || quantity > 20) {
      return res.status(400).json({ error: "A cart item is invalid. Refresh the shop and try again." });
    }
    if (quantity > product.stock) {
      return res.status(400).json({ error: `${product.name} has only ${product.stock} item(s) in demo stock.` });
    }
    cleanItems.push({ id: product.id, name: product.name, price: product.price, quantity, lineTotal: product.price * quantity });
  }
  const total = cleanItems.reduce((sum, item) => sum + item.lineTotal, 0);
  const order = {
    id: "UG-" + crypto.randomBytes(4).toString("hex").toUpperCase(),
    createdAt: new Date().toISOString(),
    customer: {
      name: String(customer.name).trim(),
      phone: String(customer.phone).trim(),
      address: String(customer.address).trim()
    },
    items: cleanItems,
    total,
    currency: "UGX",
    paymentMethod: body.paymentMethod,
    paymentStatus: body.paymentMethod === "cash" ? "PAY_ON_DELIVERY" : "DEMO_NOT_PAID",
    orderStatus: "NEW",
    paymentMode: PAYMENT_MODE
  };
  const orders = readOrders();
  orders.unshift(order);
  writeOrders(orders);
  res.status(201).json({
    message: body.paymentMethod === "cash"
      ? "Demo order saved. Payment is due on delivery."
      : "Demo order saved only. No MTN MoMo/Airtel Money payment was requested or collected.",
    order: { id: order.id, total: order.total, paymentStatus: order.paymentStatus, orderStatus: order.orderStatus },
    paymentMode: PAYMENT_MODE
  });
});

app.get("/api/admin/orders", adminOnly, (_req, res) => {
  res.json(readOrders());
});

app.patch("/api/admin/orders/:id", adminOnly, (req, res) => {
  const validStatuses = ["NEW", "CONFIRMED", "PACKING", "OUT_FOR_DELIVERY", "COMPLETED", "CANCELLED"];
  const status = String((req.body || {}).orderStatus || "");
  if (!validStatuses.includes(status)) return res.status(400).json({ error: "Invalid order status." });
  const orders = readOrders();
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  order.orderStatus = status;
  writeOrders(orders);
  res.json({ message: "Order status updated.", order });
});

app.get("/api/health", (_req, res) => res.json({ ok: true, paymentMode: PAYMENT_MODE }));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`UG Electronics Shop running on http://localhost:${PORT}`);
  console.log(`Payment mode: ${PAYMENT_MODE}. Mobile-money payments are NOT live in this starter project.`);
});
