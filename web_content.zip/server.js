import express from "express";

const app = express();
const PORT = process.env.PORT || 3000;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6";

app.use(express.static("public"));
app.use(express.json({ limit: "2mb" }));

function extractVideoId(input = "") {
  const patterns = [
    /(?:youtube\.com\/watch\?.*v=)([A-Za-z0-9_-]{11})/,
    /youtu\.be\/([A-Za-z0-9_-]{11})/,
    /youtube\.com\/(?:shorts|embed|live)\/([A-Za-z0-9_-]{11})/,
    /^([A-Za-z0-9_-]{11})$/
  ];
  for (const re of patterns) {
    const match = input.trim().match(re);
    if (match) return match[1];
  }
  return null;
}

function cleanJson(text) {
  const stripped = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = stripped.indexOf("{");
  const end = stripped.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("AI ne valid JSON return nahi kiya.");
  return JSON.parse(stripped.slice(start, end + 1));
}

app.post("/api/analyze", async (req, res) => {
  try {
    if (!ANTHROPIC_API_KEY) {
      return res.status(503).json({
        error: "Server par ANTHROPIC_API_KEY set nahi hai. README mein setup dekhein."
      });
    }

    const videoId = extractVideoId(req.body?.url || "");
    if (!videoId) return res.status(400).json({ error: "Valid YouTube URL ya 11-character video ID dein." });

    const language = req.body.language || "Roman Urdu";
    const tone = req.body.tone || "Engaging";
    const format = req.body.format || "Auto detect";
    const thumbUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;

    let imageResponse = await fetch(thumbUrl);
    if (!imageResponse.ok) {
      imageResponse = await fetch(`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`);
    }
    if (!imageResponse.ok) throw new Error("YouTube thumbnail load nahi ho saka. Video public hona chahiye.");

    const contentType = imageResponse.headers.get("content-type") || "image/jpeg";
    const bytes = Buffer.from(await imageResponse.arrayBuffer());
    if (!contentType.startsWith("image/")) throw new Error("YouTube ne valid image return nahi ki.");

    const prompt = `You are an experienced YouTube packaging and SEO strategist.
Analyze the supplied YouTube thumbnail image. Do not claim to know the video's full content from its thumbnail alone.
Language: ${language}
Tone: ${tone}
Video format: ${format}

Return ONLY valid JSON with exactly these keys:
{
 "title": "One compelling, accurate title, ideally under 60 characters",
 "description": "Useful YouTube description around 120-200 words. Include a strong first two lines, accurate context based only on visible thumbnail clues, a natural CTA, and relevant keywords. Do not invent video facts.",
 "tags": ["15-20 relevant tags, no #"],
 "hashtags": ["3-5 relevant hashtags, each starting with #"],
 "category": "Best-fit YouTube category",
 "category_emoji": "one emoji",
 "thumbnail_score": 0,
 "thumbnail_score_reason": "Brief explanation of visual clarity, contrast, focal point, text readability and curiosity. Be fair; do not pretend to measure actual CTR.",
 "seo_score": 0,
 "seo_score_reason": "Brief explanation of title, description, keyword relevance and metadata completeness. This is an estimated content-quality score, not an official YouTube score.",
 "improvements": ["5 specific, practical improvements to the thumbnail or metadata"],
 "keyword_focus": ["3-5 main keyword phrases"],
 "title_alternatives": ["2 alternative accurate titles"]
}
Scores must be integers 0-100. Never guarantee views, ranking, virality, or CTR. If thumbnail has no readable topic clues, state uncertainty and keep suggestions general.`;

    const apiResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1800,
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: contentType, data: bytes.toString("base64") } },
            { type: "text", text: prompt }
          ]
        }]
      })
    });

    const payload = await apiResponse.json();
    if (!apiResponse.ok) {
      const message = payload?.error?.message || `AI API error ${apiResponse.status}`;
      return res.status(apiResponse.status).json({ error: message });
    }

    const rawText = (payload.content || []).filter(x => x.type === "text").map(x => x.text).join("\n");
    const result = cleanJson(rawText);

    result.thumbnail_score = Math.max(0, Math.min(100, Number(result.thumbnail_score) || 0));
    result.seo_score = Math.max(0, Math.min(100, Number(result.seo_score) || 0));
    result.tags = Array.isArray(result.tags) ? result.tags.slice(0, 20) : [];
    result.hashtags = Array.isArray(result.hashtags) ? result.hashtags.slice(0, 8) : [];
    result.improvements = Array.isArray(result.improvements) ? result.improvements.slice(0, 8) : [];
    result.keyword_focus = Array.isArray(result.keyword_focus) ? result.keyword_focus.slice(0, 8) : [];
    result.title_alternatives = Array.isArray(result.title_alternatives) ? result.title_alternatives.slice(0, 4) : [];
    result.video_id = videoId;
    result.thumbnail_url = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || "Unexpected server error." });
  }
});

app.listen(PORT, () => console.log(`YouTube SEO Studio running at http://localhost:${PORT}`));
