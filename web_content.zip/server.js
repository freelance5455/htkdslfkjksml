const express=require('express'),helmet=require('helmet'),path=require('path');
const app=express(),PORT=process.env.PORT||3000;
app.use(helmet({contentSecurityPolicy:false}));app.use(express.json({limit:'1mb'}));app.use(express.static(path.join(__dirname,'public')));
app.post('/api/chat',async(req,res)=>{try{
const key=process.env.OPENAI_API_KEY||req.get('x-openai-api-key');
if(!key||!key.startsWith('sk-'))return res.status(400).json({error:'Settings-ல் சரியான OpenAI API Key கொடுக்கவும்.'});
if(!Array.isArray(req.body.messages)||!req.body.messages.length)return res.status(400).json({error:'Message கிடைக்கவில்லை.'});
const input=req.body.messages.slice(-20).map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content||'').slice(0,8000)}));
const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',input})});
const d=await r.json();if(!r.ok)return res.status(r.status).json({error:d.error?.message||'OpenAI API request தோல்வியடைந்தது.'});
const reply=(d.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('\\n');
res.json({reply:reply||'பதில் கிடைக்கவில்லை.'});
}catch(e){res.status(500).json({error:'Server பிழை. Backend சரியாக இயங்குகிறதா என்று பார்க்கவும்.'});}});
app.get('/health',(_,res)=>res.json({ok:true}));app.listen(PORT,()=>console.log('PRAGA AI server running on '+PORT));