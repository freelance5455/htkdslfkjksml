const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Database setup (SQLite)
const dbPath = path.join(__dirname, 'orders.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        db.run(`CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT NOT NULL,
            client_contact TEXT NOT NULL,
            service_type TEXT NOT NULL,
            file_link TEXT,
            budget REAL DEFAULT 0,
            deadline TEXT,
            instructions TEXT,
            payment_status TEXT DEFAULT 'Pending Payment',
            transaction_id TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`, (err) => {
            if (err) {
                console.error('Error creating orders table:', err.message);
            } else {
                // Check if empty, insert demo orders if first run
                db.get("SELECT COUNT(*) AS count FROM orders", (err, row) => {
                    if (!err && row && row.count === 0) {
                        const demoStmt = db.prepare(`INSERT INTO orders 
                            (client_name, client_contact, service_type, file_link, budget, deadline, instructions, payment_status, transaction_id) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
                        demoStmt.run('Aman Sharma', '9876543210', 'Reel / Short Editing', 'https://drive.google.com/drive/folders/sample1', 2500, '2026-09-02', 'High-energy fast-paced captions, sound effects, and color grading', 'Paid via UPI', 'TXN9847281');
                        demoStmt.run('Priya Patel', '9123456780', 'Video Editing', 'https://drive.google.com/drive/folders/sample2', 6500, '2026-09-05', 'YouTube 4K vlog cinematic edit with smooth transitions & B-roll', 'In Progress', 'TXN1128392');
                        demoStmt.run('Rohit Verma', '8018948884', 'Logo Designing', 'https://drive.google.com/drive/folders/sample3', 1800, '2026-09-01', 'Futuristic 3D cyber neon logo for tech channel', 'Completed', 'TXN7738291');
                        demoStmt.finalize();
                        console.log('Sample studio orders initialized.');
                    }
                });
            }
        });
    }
});

// Config values
let studioConfig = {
    upi_id: process.env.UPI_ID || '8018948884@paytm',
    merchant_name: 'Edito X AI Studio',
    telegram_bot_token: process.env.TELEGRAM_BOT_TOKEN || '',
    telegram_chat_id: process.env.TELEGRAM_CHAT_ID || ''
};

// Telegram alert helper
async function sendTelegramAlert(order) {
    if (!studioConfig.telegram_bot_token || !studioConfig.telegram_chat_id) {
        console.log('Telegram Bot Token or Chat ID not configured. Skipping alert.');
        return;
    }

    const message = `🚀 *NEW EDITO X STUDIO ORDER RECEIVED!*
━━━━━━━━━━━━━━━━━━━━
🆔 *Order ID:* #${order.id}
👤 *Client:* ${order.client_name}
📞 *Contact:* ${order.client_contact}
🎬 *Service:* ${order.service_type}
💰 *Budget:* ₹${order.budget}
📅 *Deadline:* ${order.deadline || 'Standard (2-3 days)'}
💳 *Payment Status:* ${order.payment_status}
📁 *Assets Link:* ${order.file_link || 'Not provided'}
📝 *Instructions:* ${order.instructions || 'Standard production'}
━━━━━━━━━━━━━━━━━━━━
⚡ *Edito X Production Pipeline*`;

    const url = `https://api.telegram.org/bot${studioConfig.telegram_bot_token}/sendMessage`;
    try {
        await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: studioConfig.telegram_chat_id,
                text: message,
                parse_mode: 'Markdown'
            })
        });
        console.log(`Telegram alert sent for Order #${order.id}`);
    } catch (err) {
        console.error('Failed to send Telegram alert:', err.message);
    }
}

// Routes
// 1. Get Studio Config (UPI & Merchant)
app.get('/api/config', (req, res) => {
    res.json({
        upi_id: studioConfig.upi_id,
        merchant_name: studioConfig.merchant_name,
        has_telegram: !!(studioConfig.telegram_bot_token && studioConfig.telegram_chat_id)
    });
});

// Update Config
app.post('/api/config', (req, res) => {
    const { upi_id, telegram_bot_token, telegram_chat_id } = req.body;
    if (upi_id) studioConfig.upi_id = upi_id.trim();
    if (telegram_bot_token !== undefined) studioConfig.telegram_bot_token = telegram_bot_token.trim();
    if (telegram_chat_id !== undefined) studioConfig.telegram_chat_id = telegram_chat_id.trim();

    res.json({ success: true, message: 'Settings updated successfully', config: studioConfig });
});

// 2. Place New Order
app.post('/api/orders', (req, res) => {
    const {
        client_name,
        client_contact,
        service_type,
        file_link,
        budget,
        deadline,
        instructions,
        transaction_id
    } = req.body;

    if (!client_name || !client_contact || !service_type) {
        return res.status(400).json({ error: 'Client name, contact, and service type are required.' });
    }

    const budgetVal = parseFloat(budget) || 0;
    const initialStatus = transaction_id ? 'Paid via UPI' : 'Pending Payment';

    const sql = `INSERT INTO orders 
        (client_name, client_contact, service_type, file_link, budget, deadline, instructions, payment_status, transaction_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.run(sql, [
        client_name.trim(),
        client_contact.trim(),
        service_type.trim(),
        (file_link || '').trim(),
        budgetVal,
        (deadline || '').trim(),
        (instructions || '').trim(),
        initialStatus,
        (transaction_id || '').trim()
    ], function (err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const newOrder = {
            id: this.lastID,
            client_name,
            client_contact,
            service_type,
            file_link,
            budget: budgetVal,
            deadline,
            instructions,
            payment_status: initialStatus,
            transaction_id
        };

        // Send async Telegram notification
        sendTelegramAlert(newOrder);

        // Generate dynamic UPI intent link
        const upiLink = `upi://pay?pa=${encodeURIComponent(studioConfig.upi_id)}&pn=${encodeURIComponent(studioConfig.merchant_name)}&am=${budgetVal}&tn=${encodeURIComponent(`Order #${newOrder.id} - ${service_type}`)}&cu=INR`;

        res.status(201).json({
            success: true,
            message: 'Order placed successfully!',
            order: newOrder,
            upi_link: upiLink
        });
    });
});

// 3. Get All Orders (Admin)
app.get('/api/orders', (req, res) => {
    const { status, service, search } = req.query;
    let query = 'SELECT * FROM orders WHERE 1=1';
    const params = [];

    if (status && status !== 'All') {
        query += ' AND payment_status = ?';
        params.push(status);
    }
    if (service && service !== 'All') {
        query += ' AND service_type = ?';
        params.push(service);
    }
    if (search && search.trim() !== '') {
        query += ' AND (client_name LIKE ? OR client_contact LIKE ? OR id LIKE ? OR instructions LIKE ?)';
        const s = `%${search.trim()}%`;
        params.push(s, s, s, s);
    }

    query += ' ORDER BY id DESC';

    db.all(query, params, (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ orders: rows });
    });
});

// 4. Update Order Status
app.patch('/api/orders/:id/status', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    if (!status) {
        return res.status(400).json({ error: 'Status is required' });
    }

    db.run('UPDATE orders SET payment_status = ? WHERE id = ?', [status, id], function (err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Order not found' });
        }
        res.json({ success: true, message: `Order #${id} status updated to ${status}` });
    });
});

// 5. Delete Order
app.delete('/api/orders/:id', (req, res) => {
    const { id } = req.params;
    db.run('DELETE FROM orders WHERE id = ?', [id], function (err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Order not found' });
        }
        res.json({ success: true, message: `Order #${id} deleted` });
    });
});

// 6. Track Single Order by ID or Phone
app.get('/api/track/:query', (req, res) => {
    const q = req.params.query.trim().replace('#', '');
    const sql = 'SELECT * FROM orders WHERE id = ? OR client_contact = ? ORDER BY id DESC LIMIT 1';
    db.get(sql, [q, q], (err, row) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (!row) {
            return res.status(404).json({ error: 'Order not found' });
        }
        res.json({ order: row });
    });
});

// 7. Studio Dashboard Metrics
app.get('/api/stats', (req, res) => {
    const sql = `SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN payment_status != 'Cancelled' THEN budget ELSE 0 END) as total_revenue,
        SUM(CASE WHEN payment_status = 'Pending Payment' THEN 1 ELSE 0 END) as pending_payments,
        SUM(CASE WHEN payment_status = 'In Progress' THEN 1 ELSE 0 END) as in_progress,
        SUM(CASE WHEN payment_status = 'Completed' OR payment_status = 'Delivered' THEN 1 ELSE 0 END) as completed_orders
    FROM orders`;

    db.get(sql, (err, row) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({
            stats: {
                totalOrders: row.total_orders || 0,
                totalRevenue: row.total_revenue || 0,
                pendingPayments: row.pending_payments || 0,
                inProgress: row.in_progress || 0,
                completedOrders: row.completed_orders || 0
            }
        });
    });
});

// Fallback to index.html
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🎬 EDITO X AI Studio Server running on http://0.0.0.0:${PORT}`);
});
