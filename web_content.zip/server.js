/**
 * MTX - Centralized Cloud Media Server & Distribution Portal
 * Features:
 * - Shared Cloud Videos & Photos REST API (/api/videos, /api/photos)
 * - Dark User Application, Face Verification & Approval Engine (/api/dark-users/*)
 * - Media Upload Endpoint with chunked binary / base64 support (/api/upload)
 * - HTTP 206 Partial Content / Range support for smooth video streaming
 * - Direct APK & Web Source Download Portal
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const VIDEOS_FILE = path.join(__dirname, 'videos.json');
const PHOTOS_FILE = path.join(__dirname, 'photos.json');
const DARK_USERS_FILE = path.join(__dirname, 'dark_users.json');
const USERS_FILE = path.join(__dirname, 'users.json');
const APK_PATH = path.join(__dirname, 'MTX.apk');
const APK_FALLBACK = path.join(__dirname, 'XVDO.apk');
const ZIP_PATH = path.join(__dirname, 'mtx-app-source.zip');
const ZIP_FALLBACK = path.join(__dirname, 'xvdo-app-source.zip');
const SQL_PATH = path.join(__dirname, 'database.sql');

if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// No built-in demo or sample content: only admin uploaded items appear
const DEFAULT_VIDEOS = [];
const DEFAULT_PHOTOS = [];

// Initialize JSON files as empty arrays if missing
function initData() {
  if (!fs.existsSync(VIDEOS_FILE)) {
    fs.writeFileSync(VIDEOS_FILE, JSON.stringify([], null, 2));
  }
  if (!fs.existsSync(PHOTOS_FILE)) {
    fs.writeFileSync(PHOTOS_FILE, JSON.stringify([], null, 2));
  }
  if (!fs.existsSync(DARK_USERS_FILE)) {
    fs.writeFileSync(DARK_USERS_FILE, JSON.stringify([], null, 2));
  }
  if (!fs.existsSync(USERS_FILE)) {
    fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2));
  }
}
initData();

function getVideos() {
  try {
    return JSON.parse(fs.readFileSync(VIDEOS_FILE, 'utf8'));
  } catch (e) {
    return [];
  }
}

function saveVideos(list) {
  try {
    fs.writeFileSync(VIDEOS_FILE, JSON.stringify(list, null, 2));
  } catch (e) {
    console.error("Failed to save videos:", e);
  }
}

function getPhotos() {
  try {
    return JSON.parse(fs.readFileSync(PHOTOS_FILE, 'utf8'));
  } catch (e) {
    return [];
  }
}

function savePhotos(list) {
  try {
    fs.writeFileSync(PHOTOS_FILE, JSON.stringify(list, null, 2));
  } catch (e) {
    console.error("Failed to save photos:", e);
  }
}

function getDarkUsers() {
  try {
    return JSON.parse(fs.readFileSync(DARK_USERS_FILE, 'utf8'));
  } catch (e) {
    return [];
  }
}

function saveDarkUsers(list) {
  try {
    fs.writeFileSync(DARK_USERS_FILE, JSON.stringify(list, null, 2));
  } catch (e) {
    console.error("Failed to save dark users:", e);
  }
}

function getUsers() {
  try {
    return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
  } catch (e) {
    return [];
  }
}

function saveUsers(list) {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(list, null, 2));
  } catch (e) {
    console.error("Failed to save users:", e);
  }
}

function getApkFile() {
  if (fs.existsSync(APK_PATH)) return APK_PATH;
  if (fs.existsSync(APK_FALLBACK)) return APK_FALLBACK;
  return null;
}

function getZipFile() {
  if (fs.existsSync(ZIP_PATH)) return ZIP_PATH;
  if (fs.existsSync(ZIP_FALLBACK)) return ZIP_FALLBACK;
  return null;
}

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range, Authorization, X-File-Name');
}

const server = http.createServer((req, res) => {
  setCors(res);

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const [rawUrl, queryString] = req.url.split('?');
  const url = rawUrl;
  const queryParams = new URLSearchParams(queryString || '');

  // 1. Static Uploads Streaming (supports HTTP 206 Partial Content for smooth video playback)
  if (url.startsWith('/uploads/')) {
    const filename = path.basename(url);
    const filePath = path.join(UPLOAD_DIR, filename);

    if (!fs.existsSync(filePath)) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'File not found' }));
      return;
    }

    const stat = fs.statSync(filePath);
    const totalSize = stat.size;
    const ext = path.extname(filename).toLowerCase();
    const mimeTypes = {
      '.mp4': 'video/mp4',
      '.mkv': 'video/x-matroska',
      '.webm': 'video/webm',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.webp': 'image/webp',
      '.gif': 'image/gif'
    };
    const contentType = mimeTypes[ext] || 'application/octet-stream';

    // Handle HEAD requests from Android MediaPlayer without sending body bytes
    if (req.method === 'HEAD') {
      res.writeHead(200, {
        'Content-Length': totalSize,
        'Content-Type': contentType,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'public, max-age=86400'
      });
      res.end();
      return;
    }

    const range = req.headers.range;
    if (range) {
      const parts = range.replace(/bytes=/, "").split("-");
      let start = parseInt(parts[0], 10);
      let end = parts[1] ? parseInt(parts[1], 10) : totalSize - 1;

      if (isNaN(start) || start < 0) start = 0;
      if (isNaN(end) || end >= totalSize) end = totalSize - 1;

      if (start >= totalSize) {
        res.writeHead(416, {
          'Content-Range': `bytes */${totalSize}`,
          'Accept-Ranges': 'bytes'
        });
        res.end();
        return;
      }

      const chunkSize = (end - start) + 1;
      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${totalSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=86400'
      });
      const stream = fs.createReadStream(filePath, { start, end });
      stream.on('error', (err) => {
        if (!res.headersSent) res.writeHead(500);
        res.end();
      });
      stream.pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': totalSize,
        'Content-Type': contentType,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'public, max-age=86400'
      });
      const stream = fs.createReadStream(filePath);
      stream.on('error', (err) => {
        if (!res.headersSent) res.writeHead(500);
        res.end();
      });
      stream.pipe(res);
    }
    return;
  }

  // 2. Direct APK Download (MTX.apk)
  if (url === '/MTX.apk' || url === '/mtx.apk' || url === '/XVDO.apk' || url === '/xvdo.apk' || url === '/download/apk' || url === '/app-debug.apk') {
    const file = getApkFile();
    if (file) {
      const stat = fs.statSync(file);
      res.writeHead(200, {
        'Content-Type': 'application/vnd.android.package-archive',
        'Content-Disposition': 'attachment; filename="MTX.apk"',
        'Content-Length': stat.size,
        'Cache-Control': 'no-cache'
      });
      fs.createReadStream(file).pipe(res);
      return;
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('APK build not found.');
      return;
    }
  }

  // 3. Direct ZIP Download
  if (url === '/mtx-app-source.zip' || url === '/xvdo-app-source.zip' || url === '/download/zip') {
    const file = getZipFile();
    if (file) {
      const stat = fs.statSync(file);
      res.writeHead(200, {
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="mtx-app-source.zip"',
        'Content-Length': stat.size,
        'Cache-Control': 'no-cache'
      });
      fs.createReadStream(file).pipe(res);
      return;
    }
  }

  // 4. Direct SQL Download
  if (url === '/database.sql' || url === '/download/sql') {
    if (fs.existsSync(SQL_PATH)) {
      const stat = fs.statSync(SQL_PATH);
      res.writeHead(200, {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': 'attachment; filename="database.sql"',
        'Content-Length': stat.size
      });
      fs.createReadStream(SQL_PATH).pipe(res);
      return;
    }
  }

  // 5. REST API: GET /api/videos
  if (url === '/api/videos' && req.method === 'GET') {
    const videos = getVideos();
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(videos));
    return;
  }

  // 6. REST API: POST /api/videos
  if (url === '/api/videos' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const newVideo = JSON.parse(body);
        if (!newVideo.title || !newVideo.videoUri) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Missing title or videoUri' }));
          return;
        }

        const videos = getVideos();
        // Strict normalization
        newVideo.isDark = (newVideo.isDark === true || newVideo.isDark === 'true' || newVideo.isDark === 1);
        if (newVideo.isPublished === undefined) newVideo.isPublished = true;
        if (!newVideo.id) newVideo.id = Date.now();

        const existingIndex = videos.findIndex(v => v.id === newVideo.id);
        if (existingIndex !== -1) {
          videos[existingIndex] = { ...videos[existingIndex], ...newVideo };
        } else {
          videos.unshift(newVideo);
        }
        saveVideos(videos);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, video: newVideo, total: videos.length }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
      }
    });
    return;
  }

  // 7. REST API: DELETE /api/videos/:id
  if (url.startsWith('/api/videos/') && req.method === 'DELETE') {
    const videoId = parseInt(url.split('/')[3], 10);
    const videos = getVideos();
    const filtered = videos.filter(v => v.id !== videoId);
    saveVideos(filtered);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true, remaining: filtered.length }));
    return;
  }

  // 8. REST API: POST /api/videos/:id/toggle-publish
  if (url.startsWith('/api/videos/') && url.endsWith('/toggle-publish') && req.method === 'POST') {
    const videoId = parseInt(url.split('/')[3], 10);
    const videos = getVideos();
    const idx = videos.findIndex(v => v.id === videoId);
    if (idx !== -1) {
      videos[idx].isPublished = !videos[idx].isPublished;
      saveVideos(videos);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, video: videos[idx] }));
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Video not found' }));
    }
    return;
  }

  // 9. REST API: GET /api/photos
  if (url === '/api/photos' && req.method === 'GET') {
    const photos = getPhotos();
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(photos));
    return;
  }

  // 10. REST API: POST /api/photos
  if (url === '/api/photos' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const newPhoto = JSON.parse(body);
        if (!newPhoto.title || !newPhoto.imageUri) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Missing title or imageUri' }));
          return;
        }

        const photos = getPhotos();
        newPhoto.isDark = (newPhoto.isDark === true || newPhoto.isDark === 'true' || newPhoto.isDark === 1);
        if (newPhoto.isPublished === undefined) newPhoto.isPublished = true;
        if (!newPhoto.id) newPhoto.id = Date.now();

        const existingIndex = photos.findIndex(p => p.id === newPhoto.id);
        if (existingIndex !== -1) {
          photos[existingIndex] = { ...photos[existingIndex], ...newPhoto };
        } else {
          photos.unshift(newPhoto);
        }
        savePhotos(photos);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, photo: newPhoto, total: photos.length }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
      }
    });
    return;
  }

  // 11. REST API: DELETE /api/photos/:id
  if (url.startsWith('/api/photos/') && req.method === 'DELETE') {
    const photoId = parseInt(url.split('/')[3], 10);
    const photos = getPhotos();
    const filtered = photos.filter(p => p.id !== photoId);
    savePhotos(filtered);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true, remaining: filtered.length }));
    return;
  }

  // 12. REST API: POST /api/photos/:id/like
  if (url.startsWith('/api/photos/') && url.endsWith('/like') && req.method === 'POST') {
    const photoId = parseInt(url.split('/')[3], 10);
    const photos = getPhotos();
    const idx = photos.findIndex(p => p.id === photoId);
    if (idx !== -1) {
      photos[idx].likes = (photos[idx].likes || 0) + 1;
      savePhotos(photos);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, likes: photos[idx].likes }));
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Photo not found' }));
    }
    return;
  }

  // ========================================================
  // DARK USER SYSTEM: Application, Face Verification & Approvals
  // ========================================================

  // 13. REST API: POST /api/dark-users/apply (User submits face photo application)
  if (url === '/api/dark-users/apply' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const payload = JSON.parse(body);
        if (!payload.userId || !payload.facePhotoUri) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Missing userId or facePhotoUri' }));
          return;
        }

        const darkUsers = getDarkUsers();
        const existingIdx = darkUsers.findIndex(u => u.userId === payload.userId);
        const application = {
          userId: payload.userId,
          userName: payload.userName || 'Anonymous User',
          facePhotoUri: payload.facePhotoUri,
          status: 'pending',
          appliedAt: new Date().toISOString()
        };

        if (existingIdx !== -1) {
          if (darkUsers[existingIdx].status === 'approved') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, application: darkUsers[existingIdx], alreadyApproved: true }));
            return;
          }
          darkUsers[existingIdx] = application;
        } else {
          darkUsers.unshift(application);
        }

        saveDarkUsers(darkUsers);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, application }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
      }
    });
    return;
  }

  // 14. REST API: GET /api/dark-users/status?userId=...
  if (url === '/api/dark-users/status' && req.method === 'GET') {
    const userId = queryParams.get('userId');
    if (!userId) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Missing userId query param' }));
      return;
    }
    const darkUsers = getDarkUsers();
    const user = darkUsers.find(u => u.userId === userId);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      userId,
      isApproved: user?.status === 'approved',
      status: user ? user.status : 'not_applied',
      application: user || null
    }));
    return;
  }

  // 15. REST API: GET /api/dark-users/list (For admin panel)
  if (url === '/api/dark-users/list' && req.method === 'GET') {
    const darkUsers = getDarkUsers();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(darkUsers));
    return;
  }

  // 16. REST API: POST /api/dark-users/approve (Admin approves face photo)
  if (url === '/api/dark-users/approve' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { userId } = JSON.parse(body);
        const darkUsers = getDarkUsers();
        const user = darkUsers.find(u => u.userId === userId);
        if (user) {
          user.status = 'approved';
          user.approvedAt = new Date().toISOString();
          saveDarkUsers(darkUsers);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, user }));
        } else {
          const newUser = {
            userId,
            userName: 'Approved Member',
            facePhotoUri: '',
            status: 'approved',
            appliedAt: new Date().toISOString(),
            approvedAt: new Date().toISOString()
          };
          darkUsers.unshift(newUser);
          saveDarkUsers(darkUsers);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, user: newUser }));
        }
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
      }
    });
    return;
  }

  // 17. REST API: POST /api/dark-users/reject (Admin rejects)
  if (url === '/api/dark-users/reject' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { userId } = JSON.parse(body);
        const darkUsers = getDarkUsers();
        const user = darkUsers.find(u => u.userId === userId);
        if (user) {
          user.status = 'rejected';
          saveDarkUsers(darkUsers);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, user }));
        } else {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'User application not found' }));
        }
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
      }
    });
    return;
  }

  // 17B. REST API: POST /api/dark-users/remove (or /api/dark-users/revoke - Admin can remove dark user at any time!)
  if ((url === '/api/dark-users/remove' || url === '/api/dark-users/revoke') && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { userId } = JSON.parse(body);
        const darkUsers = getDarkUsers();
        const user = darkUsers.find(u => u.userId === userId);
        if (user) {
          user.status = 'revoked';
          user.revokedAt = new Date().toISOString();
          saveDarkUsers(darkUsers);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, message: 'User removed from Dark Site', user }));
        } else {
          darkUsers.unshift({
            userId,
            userName: 'Revoked User',
            facePhotoUri: '',
            status: 'revoked',
            appliedAt: new Date().toISOString(),
            revokedAt: new Date().toISOString()
          });
          saveDarkUsers(darkUsers);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, message: 'User access revoked' }));
        }
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
      }
    });
    return;
  }

  // 17C. REST API: POST /api/users/register (Register normal downloader device & new member)
  if (url === '/api/users/register' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const payload = JSON.parse(body);
        if (payload.userId) {
          const users = getUsers();
          const existingIdx = users.findIndex(u => u.userId === payload.userId);
          const nowStr = new Date().toISOString();
          const userData = {
            userId: payload.userId,
            userName: payload.userName || ('Member_' + payload.userId.slice(-4)),
            deviceModel: payload.deviceModel || 'Android Device',
            joinedAt: (existingIdx !== -1 && users[existingIdx].joinedAt) ? users[existingIdx].joinedAt : (payload.joinedAt || nowStr),
            lastSeen: 'Active now',
            status: 'active'
          };
          if (existingIdx !== -1) {
            users[existingIdx] = { ...users[existingIdx], ...userData };
          } else {
            users.unshift(userData);
          }
          saveUsers(users);
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON' }));
      }
    });
    return;
  }

  // 17D. REST API: GET /api/users/all (Fetch lists of normal & dark users for admin section)
  if (url === '/api/users/all' && req.method === 'GET') {
    const normalUsers = getUsers();
    const darkUsers = getDarkUsers();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      normalUsers,
      approvedDarkUsers: darkUsers.filter(u => u.status === 'approved'),
      pendingDarkUsers: darkUsers.filter(u => u.status === 'pending'),
      allDarkApplications: darkUsers
    }));
    return;
  }

  // 18A. Chunked media upload. Each request stays small enough for cloud proxy limits.
  if (url === '/api/upload/chunk' && req.method === 'POST') {
    const uploadId = String(req.headers['x-upload-id'] || '');
    const chunkIndex = Number.parseInt(req.headers['x-chunk-index'], 10);
    const chunkCount = Number.parseInt(req.headers['x-chunk-count'], 10);
    const rawName = String(req.headers['x-file-name'] || `media_${Date.now()}`);
    const declaredLength = Number.parseInt(req.headers['content-length'] || '0', 10);
    const cleanName = path.basename(rawName).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 120);

    if (!/^[a-f0-9-]{16,64}$/i.test(uploadId) || !Number.isInteger(chunkIndex) ||
        !Number.isInteger(chunkCount) || chunkCount < 1 || chunkCount > 10000 ||
        chunkIndex < 0 || chunkIndex >= chunkCount || declaredLength > 5 * 1024 * 1024) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Invalid chunk upload metadata' }));
      return;
    }

    const chunkDir = path.join(UPLOAD_DIR, '.chunks', uploadId);
    fs.mkdirSync(chunkDir, { recursive: true });
    const chunkPath = path.join(chunkDir, `${chunkIndex}.part`);
    const chunkWriter = fs.createWriteStream(chunkPath);
    req.pipe(chunkWriter);

    chunkWriter.on('error', (err) => {
      console.error('Chunk write failed:', err);
      if (!res.headersSent) res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unable to store upload chunk' }));
    });

    chunkWriter.on('finish', async () => {
      if (chunkIndex !== chunkCount - 1) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, received: chunkIndex + 1, total: chunkCount }));
        return;
      }

      // Final chunk: verify all parts, then assemble in order without loading the whole video into RAM.
      const finalName = `${Date.now()}_${uploadId.slice(0, 8)}_${cleanName}`;
      const finalPath = path.join(UPLOAD_DIR, finalName);
      const output = fs.createWriteStream(finalPath);
      try {
        for (let i = 0; i < chunkCount; i++) {
          const partPath = path.join(chunkDir, `${i}.part`);
          if (!fs.existsSync(partPath)) throw new Error(`Missing chunk ${i}`);
          const source = fs.createReadStream(partPath);
          await new Promise((resolve, reject) => {
            source.on('error', reject);
            source.on('end', resolve);
            source.pipe(output, { end: false });
          });
        }
        await new Promise((resolve, reject) => {
          output.on('error', reject);
          output.end(resolve);
        });
        fs.rmSync(chunkDir, { recursive: true, force: true });
        const host = req.headers['x-forwarded-host'] || req.headers.host || 'ais-pre-favujoqaycbqytu7c7peu4-51913299496.asia-east1.run.app';
        const proto = req.headers['x-forwarded-proto'] || 'https';
        const relativeUrl = `/uploads/${finalName}`;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, filename: finalName, url: `${proto}://${host}${relativeUrl}`, relativeUrl, complete: true }));
      } catch (err) {
        output.destroy();
        fs.rmSync(finalPath, { force: true });
        console.error('Chunk assembly failed:', err);
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message || 'Unable to assemble upload' }));
      }
    });
    return;
  }

  // 18. REST API: POST /api/upload (Binary / Base64 upload for videos, photos & face selfies)
  if (url === '/api/upload' && req.method === 'POST') {
    const contentType = req.headers['content-type'] || '';

    // A. Base64 JSON payload
    if (contentType.includes('application/json')) {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          const rawName = parsed.filename || `media_${Date.now()}`;
          const cleanName = path.basename(rawName).replace(/[^a-zA-Z0-9._-]/g, '_');
          const finalName = `${Date.now()}_${cleanName}`;
          const destPath = path.join(UPLOAD_DIR, finalName);

          const buffer = Buffer.from(parsed.base64, 'base64');
          fs.writeFileSync(destPath, buffer);

          const host = req.headers['x-forwarded-host'] || req.headers.host || 'ais-pre-favujoqaycbqytu7c7peu4-51913299496.asia-east1.run.app';
          const proto = req.headers['x-forwarded-proto'] || 'https';
          const publicUrl = `${proto}://${host}/uploads/${finalName}`;
          const relativeUrl = `/uploads/${finalName}`;

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            success: true,
            filename: finalName,
            url: publicUrl,
            relativeUrl: relativeUrl,
            size: buffer.length
          }));
        } catch (e) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Failed to process base64 upload: ' + e.message }));
        }
      });
      return;
    }

    // B. Direct Binary Stream Upload
    const rawFileName = req.headers['x-file-name'] || `media_${Date.now()}.mp4`;
    const cleanFileName = path.basename(rawFileName).replace(/[^a-zA-Z0-9._-]/g, '_');
    const finalFileName = `${Date.now()}_${cleanFileName}`;
    const destFilePath = path.join(UPLOAD_DIR, finalFileName);
    const writeStream = fs.createWriteStream(destFilePath);

    req.pipe(writeStream);

    writeStream.on('finish', () => {
      const host = req.headers['x-forwarded-host'] || req.headers.host || 'ais-pre-favujoqaycbqytu7c7peu4-51913299496.asia-east1.run.app';
      const proto = req.headers['x-forwarded-proto'] || 'https';
      const publicUrl = `${proto}://${host}/uploads/${finalFileName}`;
      const relativeUrl = `/uploads/${finalFileName}`;

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        filename: finalFileName,
        url: publicUrl,
        relativeUrl: relativeUrl
      }));
    });

    writeStream.on('error', (err) => {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'File write error: ' + err.message }));
    });
    return;
  }

  // 19. API Status Health Check
  if (url === '/api/status') {
    const videos = getVideos();
    const photos = getPhotos();
    const darkUsers = getDarkUsers();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'online',
      platform: 'MTX Cloud Sync & Dark Zone Engine',
      videoCount: videos.length,
      photoCount: photos.length,
      darkUserCount: darkUsers.length,
      appVersionCode: 2,
      appVersionName: '1.1',
      updateAvailable: true,
      apkUrl: 'https://ais-dev-favujoqaycbqytu7c7peu4-51913299496.asia-east1.run.app/MTX.apk',
      updateNotes: 'New MTX streaming engine with high-speed video playback and dark site access.',
      timestamp: Date.now()
    }));
    return;
  }

  // 19B. App Version & Update Check Endpoint (/api/version)
  if (url === '/api/version' || url === '/api/app-version') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({
      versionCode: 2,
      versionName: '1.1',
      minSupportedVersion: 1,
      apkUrl: 'https://ais-dev-favujoqaycbqytu7c7peu4-51913299496.asia-east1.run.app/MTX.apk',
      updateTitle: 'New MTX Update Available',
      updateNotes: 'A newer version of MTX is available with enhanced video streaming, dark site features, and performance improvements.',
      forceUpdate: false,
      timestamp: Date.now()
    }));
    return;
  }

  // 20. Portal Landing Page
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MTX - Direct Download Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { background: #0B0E14; color: #F8FAFC; font-family: system-ui, -apple-system, sans-serif; }
        .gradient-btn { background: linear-gradient(135deg, #2563EB 0%, #7C3AED 100%); }
        .gradient-btn:hover { background: linear-gradient(135deg, #1D4ED8 0%, #6D28D9 100%); transform: translateY(-2px); }
        .gradient-text { background: linear-gradient(135deg, #60A5FA 0%, #C084FC 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    </style>
</head>
<body class="min-h-screen flex flex-col justify-between p-4 sm:p-8">

    <div class="max-w-4xl mx-auto w-full my-auto space-y-8">
        <!-- Brand Header -->
        <div class="text-center space-y-3">
            <div class="w-16 h-16 rounded-2xl gradient-btn flex items-center justify-center text-white text-2xl mx-auto shadow-2xl shadow-indigo-500/40">
                <i class="fa-solid fa-play ml-1"></i>
            </div>
            <h1 class="text-3xl sm:text-5xl font-black text-white tracking-tight">
                M<span class="gradient-text">TX</span> Streaming Platform
            </h1>
            <p class="text-sm sm:text-base text-slate-400 max-w-xl mx-auto">
                Next-generation mobile streaming app with Dark User Face Verification, YouTube-style player, and cloud synchronization.
            </p>
        </div>

        <!-- Download Cards Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

            <!-- Card 1: Direct APK Download -->
            <div class="bg-[#151A24] border border-[#252D3D] rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden group">
                <div class="absolute -top-16 -right-16 w-36 h-36 bg-blue-600/20 rounded-full blur-2xl pointer-events-none"></div>

                <div class="space-y-4 relative z-10">
                    <div class="flex items-center justify-between">
                        <span class="px-3 py-1 rounded-full text-xs font-bold uppercase bg-blue-500/15 text-blue-400 border border-blue-500/30">
                            Android App
                        </span>
                        <span class="text-xs text-slate-400 font-mono">v1.2 &bull; Universal APK</span>
                    </div>

                    <h2 class="text-2xl font-bold text-white flex items-center gap-2">
                        <i class="fa-brands fa-android text-emerald-400"></i> Direct APK
                    </h2>

                    <p class="text-xs text-slate-400 leading-relaxed">
                        Download and install the native MTX Android streaming application. Includes YouTube-style fullscreen player, photo gallery, Dark User zone with face verification, and cloud synchronization.
                    </p>

                    <div class="p-3 rounded-xl bg-[#0B0E14] border border-[#252D3D] text-[11px] text-slate-400 space-y-1">
                        <div>&bull; App Name: <strong>MTX</strong></div>
                        <div>&bull; Dark User Zone: <strong>Live Camera Face Verification</strong></div>
                        <div>&bull; Cloud Sync: <strong>Enabled (/api/videos, /api/photos, /api/dark-users)</strong></div>
                    </div>
                </div>

                <div class="pt-6 relative z-10">
                    <a href="/MTX.apk" download="MTX.apk" class="w-full py-4 px-6 rounded-2xl text-white font-bold text-sm gradient-btn shadow-xl shadow-blue-500/25 flex items-center justify-center gap-2 transition-transform">
                        <i class="fa-solid fa-download text-sm"></i>
                        <span>Download Direct APK (MTX.apk)</span>
                    </a>
                </div>
            </div>

            <!-- Card 2: Full PHP Source Code & MySQL -->
            <div class="bg-[#151A24] border border-[#252D3D] rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden group">
                <div class="absolute -top-16 -right-16 w-36 h-36 bg-purple-600/20 rounded-full blur-2xl pointer-events-none"></div>

                <div class="space-y-4 relative z-10">
                    <div class="flex items-center justify-between">
                        <span class="px-3 py-1 rounded-full text-xs font-bold uppercase bg-purple-500/15 text-purple-400 border border-purple-500/30">
                            PHP Web Source
                        </span>
                        <span class="text-xs text-slate-400 font-mono">Full ZIP Archive</span>
                    </div>

                    <h2 class="text-2xl font-bold text-white flex items-center gap-2">
                        <i class="fa-brands fa-php text-purple-400"></i> PHP 8+ Web App
                    </h2>

                    <p class="text-xs text-slate-400 leading-relaxed">
                        Complete web project ready for shared hosting (cPanel, DirectAdmin, XAMPP). Includes full admin portal, video player, user authentication, and MySQL schema.
                    </p>

                    <div class="p-3 rounded-xl bg-[#0B0E14] border border-[#252D3D] text-[11px] text-slate-400 space-y-1">
                        <div>&bull; Full administrative dashboard & media manager</div>
                        <div>&bull; Dark User approval management</div>
                    </div>
                </div>

                <div class="pt-6 relative z-10 space-y-2">
                    <a href="/mtx-app-source.zip" download="mtx-app-source.zip" class="w-full py-3.5 px-6 rounded-2xl text-white font-bold text-xs bg-purple-600 hover:bg-purple-700 shadow-lg shadow-purple-600/25 flex items-center justify-center gap-2 transition">
                        <i class="fa-solid fa-file-zipper"></i>
                        <span>Download Complete Source (.zip)</span>
                    </a>
                    <a href="/database.sql" download="database.sql" class="w-full py-2.5 px-4 rounded-xl text-slate-300 hover:text-white font-semibold text-xs bg-[#0E131E] border border-[#252D3D] flex items-center justify-center gap-2 transition">
                        <i class="fa-solid fa-database text-purple-400"></i>
                        <span>Download MySQL database.sql</span>
                    </a>
                </div>
            </div>

        </div>
    </div>

    <!-- Footer -->
    <div class="text-center text-xs text-slate-500 py-4">
        &copy; ${new Date().getFullYear()} MTX &bull; Next-Gen Streaming Platform
    </div>

</body>
</html>`);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('MTX distribution server with Dark Zone Engine active on port ' + PORT);
});
