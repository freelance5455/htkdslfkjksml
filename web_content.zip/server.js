const http=require("http"),fs=require("fs"),path=require("path");
const KEY=process.env.ANTHROPIC_API_KEY,PORT=process.env.PORT||3000;
const LIMIT=Number(process.env.HOURLY_LIMIT||20),hits=new Map();
function ok(ip){const n=Date.now(),a=(hits.get(ip)||[]).filter(t=>n-t<36e5);if(a.length>=LIMIT)return false;a.push(n);hits.set(ip,a);return true}
http.createServer(async(req,res)=>{
 const send=(c,o)=>{res.writeHead(c,{"Content-Type":"application/json"});res.end(JSON.stringify(o))};
 if(req.method==="POST"&&req.url==="/api/generate"){
  const ip=(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"").split(",")[0];
  if(!ok(ip))return send(429,{error:"وصلت الحد المسموح بالساعة، جرّب بعد شوي."});
  let body="";for await(const c of req){body+=c;if(body.length>25e6)return send(413,{error:"الصور كبيرة."})}
  try{
   const {prompt,images}=JSON.parse(body);
   const content=[...(images||[]).slice(0,10).map(d=>({type:"image",source:{type:"base64",media_type:"image/jpeg",data:d}})),{type:"text",text:String(prompt).slice(0,4000)}];
   const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"x-api-key":KEY,"anthropic-version":"2023-06-01","content-type":"application/json"},body:JSON.stringify({model:"claude-sonnet-5-5",max_tokens:4000,messages:[{role:"user",content}]})});
   const j=await r.json();if(!r.ok)return send(502,{error:"خطأ من الخدمة."});
   const t=j.content.map(x=>x.text||"").join(""),m=t.match(/\{[\s\S]*\}/);
   send(200,JSON.parse(m[0]));
  }catch(e){send(500,{error:"ما كدرت أطلع أسئلة، جرّب صورة أوضح."})}
  return}
 res.writeHead(200,{"Content-Type":"text/html; charset=utf-8"});res.end(fs.readFileSync(path.join(__dirname,"public","index.html")));
}).listen(PORT);
