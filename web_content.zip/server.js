const express=require("express");
const path=require("path");
const app=express();
const PORT=process.env.PORT||3000;

app.use(express.json({limit:"50kb"}));
app.use(express.static(path.join(__dirname)));

app.get("/api/health",(req,res)=>res.json({ok:true,app:"Smart Switch",version:"1.6"}));

app.get("*",(req,res)=>{
  if(req.path.startsWith("/api/")) return res.status(404).json({ok:false});
  res.sendFile(path.join(__dirname,"index.html"));
});

app.listen(PORT,()=>console.log(`Smart Switch v1.6 running on port ${PORT}`));