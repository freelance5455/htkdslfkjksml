require("dotenv").config();
const express=require("express"),session=require("express-session"),bcrypt=require("bcryptjs");
const Database=require("better-sqlite3"),OpenAI=require("openai"),path=require("path");
const app=express(),db=new Database("coyote.db");
db.exec(`CREATE TABLE IF NOT EXISTS users(
id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,
password_hash TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)`);
const ai=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null;
app.use(express.json());app.use(express.urlencoded({extended:true}));
app.use(session({secret:process.env.SESSION_SECRET||"change-me",resave:false,saveUninitialized:false,
cookie:{httpOnly:true,sameSite:"lax",maxAge:604800000}}));
app.use(express.static(path.join(__dirname,"public")));
const auth=(req,res,next)=>req.session.userId?next():res.status(401).json({error:"Connexion requise."});
app.post("/api/register",async(req,res)=>{try{
let n=String(req.body.name||"").trim(),e=String(req.body.email||"").trim().toLowerCase(),p=String(req.body.password||"");
if(n.length<2)return res.status(400).json({error:"Nom trop court."});
if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(e))return res.status(400).json({error:"Email invalide."});
if(p.length<6)return res.status(400).json({error:"Mot de passe: 6 caractères minimum."});
if(db.prepare("SELECT id FROM users WHERE email=?").get(e))return res.status(409).json({error:"Email déjà inscrit."});
let h=await bcrypt.hash(p,12),r=db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(n,e,h);
req.session.userId=r.lastInsertRowid;res.json({ok:true,user:{name:n,email:e}});
}catch(x){res.status(500).json({error:"Erreur serveur."})}});
app.post("/api/login",async(req,res)=>{try{
let e=String(req.body.email||"").trim().toLowerCase(),p=String(req.body.password||"");
let u=db.prepare("SELECT * FROM users WHERE email=?").get(e);
if(!u||!(await bcrypt.compare(p,u.password_hash)))return res.status(401).json({error:"Email ou mot de passe incorrect."});
req.session.userId=u.id;res.json({ok:true,user:{name:u.name,email:u.email}});
}catch(x){res.status(500).json({error:"Erreur serveur."})}});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>{if(!req.session.userId)return res.json({loggedIn:false});
let u=db.prepare("SELECT name,email FROM users WHERE id=?").get(req.session.userId);res.json({loggedIn:true,user:u})});
app.post("/api/ai",auth,async(req,res)=>{try{
if(!ai)return res.status(503).json({error:"Ajoute OPENAI_API_KEY dans .env."});
let message=String(req.body.message||"").trim();if(!message)return res.status(400).json({error:"Message vide."});
let r=await ai.responses.create({model:process.env.OPENAI_MODEL||"gpt-5.6-luna",
instructions:"Tu es Coyote AI. Réponds en français par défaut, clairement et utilement. Pour les informations actuelles, utilise la recherche web.",
tools:[{type:"web_search"}],input:message});
res.json({ok:true,answer:r.output_text||"Aucune réponse."});
}catch(x){console.error(x);res.status(500).json({error:"Impossible de contacter Coyote AI."})}});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("Coyote lancé"));
