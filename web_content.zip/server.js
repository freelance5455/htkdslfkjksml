const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, "public")));

const users = new Map(); // fakeNumber -> {fakeNumber,name,socketId,online}
const messages = new Map(); // conversation key -> messages[]

function key(a,b){ return [a,b].sort().join(":"); }

function makeNumber(){
  let n;
  do n = "010" + Math.floor(1000000 + Math.random()*9000000);
  while(users.has(n));
  return n;
}

io.on("connection", socket => {
  socket.on("register", ({name, fakeNumber}, cb) => {
    if(!fakeNumber) fakeNumber = makeNumber();
    if(users.has(fakeNumber) && users.get(fakeNumber).socketId !== socket.id){
      return cb?.({ok:false,error:"الرقم الوهمي مستخدم بالفعل"});
    }
    const user = {fakeNumber, name:(name||"مستخدم").slice(0,30), socketId:socket.id, online:true};
    users.set(fakeNumber,user);
    socket.data.fakeNumber=fakeNumber;
    cb?.({ok:true,user});
    io.emit("users", [...users.values()].map(({socketId,...u})=>u));
  });

  socket.on("send_message", ({to,text}, cb) => {
    const from=socket.data.fakeNumber;
    if(!from || !to || !text?.trim()) return cb?.({ok:false,error:"بيانات ناقصة"});
    const recipient=users.get(to);
    const msg={
      id:Date.now()+"-"+Math.random().toString(16).slice(2),
      from,to,text:text.trim().slice(0,2000),
      time:new Date().toISOString(),
      status: recipient?.online ? "delivered" : "sent"
    };
    const k=key(from,to);
    if(!messages.has(k)) messages.set(k,[]);
    messages.get(k).push(msg);
    if(recipient?.socketId){
      io.to(recipient.socketId).emit("message",msg);
    }
    socket.emit("message",msg);
    cb?.({ok:true,msg});
  });

  socket.on("get_history", ({withUser}, cb) => {
    const me=socket.data.fakeNumber;
    cb?.({ok:true,messages:messages.get(key(me,withUser))||[]});
  });

  socket.on("typing", ({to}) => {
    const r=users.get(to);
    if(r?.socketId) io.to(r.socketId).emit("typing",{from:socket.data.fakeNumber});
  });

  socket.on("disconnect", () => {
    const n=socket.data.fakeNumber;
    if(n && users.has(n)){
      users.get(n).online=false;
      io.emit("users", [...users.values()].map(({socketId,...u})=>u));
    }
  });
});

const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`Abou Ezz Chat running on http://localhost:${PORT}`));
