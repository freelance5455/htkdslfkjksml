const RESTOCK_MS = 5 * 60 * 1000;
const WEATHER_MS = 20 * 1000;
const LIMITED_SEEDS_UNTIL = Date.UTC(2026,10,23,17,30,34,125);
const LIMITED_SEED_IDS = new Set(['starlit-seed','moonberry','rainbow-orchid','snowglobe-camellia','frostmoon-berry','jinglebell-jasmine','winter-solstice-rose','aurora-giftbud','sugarplum-orchid','comet-cocoa-pod']);
const NEW_RARITY_SEED_IDS = new Set([
  'astral-berry','stardew-tulip','comet-cactus','nebula-melon',
  'seraphic-rose','halo-lily','heavenly-peony','cherub-fruit',
  'timebloom','dream-orchid','crystal-cosmos','void-lotus',
  'multiverse-mango','eternal-fern','reality-root','cosmic-apple',
  'infinite-orchid','endless-sunfruit','boundless-bloom','omega-seed'
]);
export const schema = `
  CREATE TABLE IF NOT EXISTS little_garden_room_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    state_json TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  );
`;
const SEED_STOCK = {
  carrot:8,tomato:6,sunflower:4,strawberry:5,tulip:6,pumpkin:3,lettuce:7,radish:7,
  corn:5,peas:5,lavender:4,blueberry:4,chili:4,eggplant:3,daisy:4,pineapple:3,
  rose:3,waterlily:3,dragonfruit:2,moonflower:2,bonsai:2,'ghost-orchid':2,
  starfruit:2,'golden-apple':2,mandrake:2,cosmos:1,'rainbow-bloom':1,
  cucumber:7,onion:7,'bell-pepper':6,garlic:6,mint:5,kiwi:4,marigold:4,watercress:5,
  hibiscus:4,peony:3,chrysanthemum:4,bluebell:3,jasmine:3,magnolia:3,snapdragon:2,'blue-orchid':3,
  'sapphire-bloom':2,'ember-lily':2,'silver-vine':2,'crystal-rose':2,'phoenix-flower':2,'stardust-fern':2,
  'phantom-bellflower':2,'dragon-bloom':2,elderroot:2,'amber-orchid':2,'fossil-moss':2,'primordial-fruit':2,
  'galaxy-orchid':1,'comet-lily':1,'nebula-rose':1,'starlight-vine':1,'prism-poppy':1,'spectrum-fern':1,
  'aurora-orchid':1,'infinity-bloom':1,'starlit-seed':2,'moonberry':2,'rainbow-orchid':2,
  'astral-berry':3,'stardew-tulip':3,'comet-cactus':2,'nebula-melon':2,
  'seraphic-rose':3,'halo-lily':2,'heavenly-peony':2,'cherub-fruit':2,
  'timebloom':2,'dream-orchid':2,'crystal-cosmos':2,'void-lotus':1,
  'multiverse-mango':2,'eternal-fern':2,'reality-root':1,'cosmic-apple':1,
  'infinite-orchid':1,'endless-sunfruit':1,'boundless-bloom':1,'omega-seed':1,
  'chive':7,
  'pink-radish':6,
  'sugar-snap-pea':7,
  'golden-beet':6,
  'basil-bush':7,
  'baby-turnip':6,
  'blue-carrot':7,
  'honey-clover':5,
  'cinnamon-basil':4,
  'lemon-balm':5,
  'dewdrop-dill':4,
  'cloverbell':5,
  'peach-thyme':4,
  'amber-sage':5,
  'frosted-pansy':4,
  'coral-dahlia':3,
  'velvet-iris':4,
  'silver-thyme':3,
  'cranberry-fern':4,
  'twilight-poppy':3,
  'glacier-bluebell':4,
  'sunset-snapdragon':3,
  'glimmering-lotus':2,
  'opal-marigold':3,
  'velvet-camellia':2,
  'crown-lily':3,
  'firefly-hibiscus':2,
  'pearl-peony':3,
  'solar-lotus':2,
  'gilded-magnolia':1,
  'thunder-orchid':2,
  'ruby-wisteria':1,
  'cinder-tulip':2,
  'stormglass-rose':1,
  'dawnfire-bloom':2,
  'eclipse-bellflower':2,
  'wyrmroot':1,
  'phantom-dahlia':2,
  'starforge-fern':1,
  'ashen-moonflower':2,
  'whispering-yew':1,
  'nightfire-poppy':2,
  'amberwood-tree':2,
  'fossil-orchid':1,
  'titans-pomegranate':2,
  'elderbloom-mushroom':1,
  'primordial-lotus':2,
  'suncore-fruit':1,
  'stoneheart-succulent':2,
  'pulsar-blossom':1,
  'lunar-crown':1,
  'solaris-lily':1,
  'quasar-fruit':1,
  'andromeda-vine':1,
  'stellar-chrysanthemum':1,
  'aurora-flame-lily':1,
  'kaleidoscope-iris':1,
  'chromatic-lotus':1,
  'spectrum-starfruit':1,
  'opaline-rainbow-rose':1,
  'prismfire-orchid':1,
  'mirage-poppy':1,
  'iridescent-sunseed':1,
  'snowglobe-camellia':1,
  'frostmoon-berry':1,
  'jinglebell-jasmine':1,
  'winter-solstice-rose':1,
  'aurora-giftbud':1,
  'sugarplum-orchid':1,
  'comet-cocoa-pod':1,
  'astral-lotus':2,
  'supernova-sunflower':1,
  'moonquake-berry':2,
  'pulsar-pear':1,
  'orbiting-orchid':2,
  'startrail-melon':1,
  'empyrean-bloom':2,
  'gracewing-lily':1,
  'seraphim-crown':2,
  'celestial-nectar':1,
  'dawn-halo-rose':2,
  'blessed-magnolia':1,
  'eonflower':2,
  'dreamweavers-bloom':1,
  'evernow-orchid':2,
  'chrono-lily':1,
  'paradox-peony':2,
  'afterlight-lotus':1,
  'omniverse-orchid':1,
  'reality-weavers-bloom':1,
  'infinite-worlds-fruit':1,
  'worldtree-blossom':1,
  'cosmic-gate-seed':1,
  'manyworlds-mango':1,
  'infinity-fern':1,
  'eternal-sunflower':1,
  'boundless-lotus':1,
  'omega-blossom':1,
  'limitless-berry':1,
  'endless-cosmos':1
};
const GEAR_STOCK = {'watering-can':6,'hand-trowel':5,'garden-gloves':5,'pruning-shears':4,'compost-bag':4,'sun-hat':3,'rain-boots':3,'glass-cloche':2,'moon-lantern':2,'garden-sprinkler':4,'copper-sprinkler':3,'rainbow-sprinkler':2,'garden-divider':3};
const WEATHER_NAMES = new Set([
  'Aurora Rain','Starfall Shower','Moonbow Mist','Meteor Pollen','Comet Winds',
  'Crystal Hail','Solar Flare','Nebula Drizzle','Void Eclipse','Rainbow Monsoon',
  'Firefly Blizzard','Frostfire Snow','Singing Thunder','Jade Fog','Mushroom Moonfall',
  'Cosmic Dew','Glasswing Gale','Dreamseed Storm','Tidal Skyfall','Pink Comet Bloom',
  'Emerald Aurora','Amber Rain','Silverwind Bloom','Petal Cyclone','Honeydew Haze',
  'Thunder Blossom','Crystal Aurora','Sapphire Rain','Cinderfall','Cloudberry Shower',
  'Prismatic Gale','Lavender Mist','Gilded Sunshower','Frostpetal Flurry','Mothlight Night',
  'Echoing Rain','Verdant Comet','Orchid Tempest','Glittering Tide','Dewdrop Parade',
  'Wildflower Whirl','Pearl Fog','Citrine Hail','Starlight Monsoon','Rosegold Breeze',
  'Mosslight Drizzle','Firework Bloom','Velvet Moonrise','Dragonfly Squall','Rainbow Petalfall'
]);
let latestRestock = null;
let latestSeedRestocks = {};
let latestGearRestock = null;
let latestGearItems = {};
let latestWeather = null;
let sharedBeds = null;
let restorePromise = null;
let persistenceQueue = Promise.resolve();

function newStock() {
  const now=Date.now();
  return Object.fromEntries(Object.entries(SEED_STOCK).map(([id,amount])=>[
    id,LIMITED_SEED_IDS.has(id)&&now>=LIMITED_SEEDS_UNTIL?0:Math.max(1,amount-Math.floor(Math.random()*3))
  ]));
}
function newGearStock() {
  return Object.fromEntries(Object.entries(GEAR_STOCK).map(([id,amount])=>[id,Math.max(1,amount-Math.floor(Math.random()*3))]));
}
async function restoreRoomState(env) {
  if (!restorePromise) {
    restorePromise=(async()=>{
      try {
        const row=await env.DB.prepare("SELECT state_json FROM little_garden_room_state WHERE id = 1").first();
        if (!row?.state_json) return;
        const saved=JSON.parse(row.state_json);
        latestRestock=saved.latestRestock||null;
        latestSeedRestocks=saved.latestSeedRestocks||{};
        latestGearRestock=saved.latestGearRestock||null;
        latestGearItems=saved.latestGearItems||{};
        latestWeather=saved.latestWeather||null;
        sharedBeds=Array.isArray(saved.sharedBeds)?cleanGardenBeds(saved.sharedBeds):null;
      } catch (error) { console.error("Could not restore shared garden restocks",error); }
    })();
  }
  await restorePromise;
}
function persistRoomState(env) {
  const snapshot=JSON.stringify({latestRestock,latestSeedRestocks,latestGearRestock,latestGearItems,latestWeather,sharedBeds});
  persistenceQueue=persistenceQueue.then(()=>env.DB.prepare(
    "INSERT INTO little_garden_room_state (id,state_json,updated_at) VALUES (1,?,?) ON CONFLICT(id) DO UPDATE SET state_json=excluded.state_json,updated_at=excluded.updated_at"
  ).bind(snapshot,Date.now()).run()).catch(error=>{console.error("Could not persist shared garden restocks",error);});
  return persistenceQueue;
}
function parseMessage(message) {
  try { return typeof message==='string' ? JSON.parse(message) : message; }
  catch { return null; }
}
function cleanGardenBed(input) {
  if (!input||typeof input!=='object'||typeof input.id!=='string'||!Object.hasOwn(SEED_STOCK,input.id)) return null;
  const now=Date.now();
  const growMs=Math.max(1000,Math.min(86400000,Number(input.growMs)||45000));
  const plantedAt=Number.isFinite(input.plantedAt)?Math.min(now,Math.max(now-86400000,input.plantedAt)):now;
  const readyAt=Number.isFinite(input.readyAt)?Math.max(plantedAt,Math.min(plantedAt+86400000,input.readyAt)):plantedAt+growMs;
  const bed={id:input.id,plantedAt,growMs,readyAt,sharedGrowth:true};
  if (Number.isFinite(input.x)) bed.x=Math.max(3,Math.min(97,input.x));
  if (Number.isFinite(input.y)) bed.y=Math.max(3,Math.min(97,input.y));
  if (input.locked) bed.locked=true;
  if (Number.isFinite(input.instantGrownAt)) {bed.instantGrownAt=now;bed.readyAt=now;}
  if (Array.isArray(input.mutations)) {
    bed.mutations=input.mutations.slice(0,8).filter(m=>m&&typeof m.name==='string').map(m=>({
      name:m.name.replace(/[^a-zA-Z0-9 -]/g,'').slice(0,60),
      icon:typeof m.icon==='string'?m.icon.slice(0,8):'',
      event:typeof m.event==='string'?m.event.replace(/[^a-zA-Z0-9 -]/g,'').slice(0,60):''
    })).filter(m=>m.name);
  }
  return bed;
}
function cleanGardenBeds(input) {
  const length=Math.max(16,Math.min(256,Math.ceil(input.length/16)*16));
  return Array.from({length},(_,index)=>cleanGardenBed(input[index]));
}
function ensureSharedBeds() {
  if (!Array.isArray(sharedBeds)) sharedBeds=Array(16).fill(null);
}

export const room = {
  tickMs:250,
  async onMessage(conn,message,room,env) {
    const input=parseMessage(message);
    if (!input||typeof input.type!=='string') return;
    if (input.type.startsWith('garden-')) {
      await restoreRoomState(env);
      const now=Date.now();
      if (input.type==='garden-join') {
        if (!Array.isArray(sharedBeds)) {
          sharedBeds=cleanGardenBeds(Array.isArray(input.initialBeds)?input.initialBeds:[]);
          await persistRoomState(env);
        }
        room.broadcast({type:'garden-state',beds:sharedBeds});
        return;
      }
      if (!Array.isArray(sharedBeds)) {conn.send({type:'garden-state-required'});return;}
      if (input.type==='garden-plant') {
        const index=Number(input.index), bed=cleanGardenBed(input.bed);
        if (!Number.isInteger(index)||index<0||index>=sharedBeds.length||!bed) return;
        if (sharedBeds[index]) {conn.send({type:'garden-action-rejected',action:'plant',index,seedId:bed.id,bed:sharedBeds[index]});return;}
        bed.plantedAt=now;bed.readyAt=Number.isFinite(input.bed.growMs)?now+bed.growMs:now+45000;
        sharedBeds[index]=bed;
        await persistRoomState(env);
        room.broadcast({type:'garden-bed-update',index,bed,by:conn.username||''});
        return;
      }
      if (input.type==='garden-bed-update') {
        const index=Number(input.index), bed=cleanGardenBed(input.bed);
        if (!Number.isInteger(index)||index<0||index>=sharedBeds.length||!bed||!sharedBeds[index]||bed.id!==sharedBeds[index].id) return;
        sharedBeds[index]=bed;
        await persistRoomState(env);
        room.broadcast({type:'garden-bed-update',index,bed,by:conn.username||''});
        return;
      }
      if (input.type==='garden-bed-updates'&&Array.isArray(input.beds)) {
        let changed=false;
        for (const item of input.beds.slice(0,256)) {
          const index=Number(item?.index), bed=cleanGardenBed(item?.bed);
          if (Number.isInteger(index)&&index>=0&&index<sharedBeds.length&&bed&&sharedBeds[index]&&bed.id===sharedBeds[index].id) {sharedBeds[index]=bed;changed=true;}
        }
        if (changed) {await persistRoomState(env);room.broadcast({type:'garden-state',beds:sharedBeds});}
        return;
      }
      if (input.type==='garden-harvest') {
        const index=Number(input.index), bed=sharedBeds[index];
        if (!Number.isInteger(index)||index<0||!bed||bed.locked||Date.now()<bed.readyAt) {
          conn.send({type:'garden-action-rejected',action:'harvest',index,bed:bed||null});return;
        }
        sharedBeds[index]=null;
        await persistRoomState(env);
        room.broadcast({type:'garden-bed-cleared',index,by:conn.username||''});
        conn.send({type:'garden-harvest-success',index,bed});
        return;
      }
      if (input.type==='garden-expand') {
        const requested=Math.max(16,Math.min(256,Math.ceil((Number(input.length)||16)/16)*16));
        if (requested>sharedBeds.length) {
          while(sharedBeds.length<requested) sharedBeds.push(null);
          await persistRoomState(env);
          room.broadcast({type:'garden-state',beds:sharedBeds});
        }
        return;
      }
      return;
    }
    if (!conn.isOwner) return;
    await restoreRoomState(env);
    const now=Date.now();
    if (input.type==='admin-restock-bulk') {
      const seedStocks=newStock(), gearStocks=newGearStock();
      latestRestock={stocks:seedStocks,at:now,by:conn.username||''};
      latestSeedRestocks={};
      latestGearRestock={stocks:gearStocks,at:now,by:conn.username||''};
      latestGearItems={};
      await persistRoomState(env);
      room.broadcast({type:'manual-bulk-restock',seedStocks,gearStocks,remainingMs:RESTOCK_MS,by:conn.username||''});
      return;
    }
    if (input.type==='admin-restock') {
      const stocks=newStock();
      latestRestock={stocks,at:now,by:conn.username||''};
      latestSeedRestocks={};
      await persistRoomState(env);
      room.broadcast({type:'manual-restock',stocks,remainingMs:RESTOCK_MS,by:latestRestock.by});
      return;
    }
    if (input.type==='admin-restock-new-seeds') {
      const ids=[...NEW_RARITY_SEED_IDS].filter(id=>Object.hasOwn(SEED_STOCK,id));
      const stocks=Object.fromEntries(ids.map(id=>[id,SEED_STOCK[id]]));
      for (const id of ids) latestSeedRestocks[id]={stock:stocks[id],at:now,by:conn.username||''};
      if (latestRestock && now-latestRestock.at<RESTOCK_MS) {
        for (const id of ids) latestRestock.stocks[id]=stocks[id];
      }
      await persistRoomState(env);
      room.broadcast({type:'manual-seed-restock',stocks,by:conn.username||''});
      return;
    }
    if (input.type==='admin-restock-seeds' && Array.isArray(input.ids)) {
      const ids=[...new Set(input.ids)].filter(id=>typeof id==='string'&&Object.hasOwn(SEED_STOCK,id)&&(!LIMITED_SEED_IDS.has(id)||now<LIMITED_SEEDS_UNTIL)).slice(0,Object.keys(SEED_STOCK).length);
      if (!ids.length) return;
      const stocks=Object.fromEntries(ids.map(id=>[id,SEED_STOCK[id]]));
      for (const id of ids) latestSeedRestocks[id]={stock:stocks[id],at:now,by:conn.username||''};
      if (latestRestock && now-latestRestock.at<RESTOCK_MS) {
        for (const id of ids) latestRestock.stocks[id]=stocks[id];
      }
      await persistRoomState(env);
      room.broadcast({type:'manual-seed-restock',stocks,by:conn.username||''});
      return;
    }
    if (input.type==='admin-restock-gear') {
      const stocks=newGearStock();
      latestGearRestock={stocks,at:now,by:conn.username||''};
      latestGearItems={};
      await persistRoomState(env);
      room.broadcast({type:'manual-gear-restock',stocks,remainingMs:RESTOCK_MS,by:latestGearRestock.by});
      return;
    }
    if (input.type==='admin-restock-gear-items' && Array.isArray(input.ids)) {
      const ids=[...new Set(input.ids)].filter(id=>typeof id==='string'&&Object.hasOwn(GEAR_STOCK,id)).slice(0,Object.keys(GEAR_STOCK).length);
      if (!ids.length) return;
      const stocks=Object.fromEntries(ids.map(id=>[id,GEAR_STOCK[id]]));
      for (const id of ids) latestGearItems[id]={stock:stocks[id],at:now,by:conn.username||''};
      if (latestGearRestock && now-latestGearRestock.at<RESTOCK_MS) {
        for (const id of ids) latestGearRestock.stocks[id]=stocks[id];
      }
      await persistRoomState(env);
      room.broadcast({type:'manual-gear-item-restock',stocks,remainingMs:RESTOCK_MS,by:conn.username||''});
      return;
    }
    if (input.type==='admin-weather') {
      const requested=Array.isArray(input.names)?input.names:input.name?[input.name]:[];
      const names=[...new Set(requested)].filter(name=>typeof name==='string'&&WEATHER_NAMES.has(name)).slice(0,WEATHER_NAMES.size);
      if (!names.length) return;
      latestWeather={names,at:now,by:conn.username||''};
      await persistRoomState(env);
      room.broadcast({type:'weather-start',names,remainingMs:WEATHER_MS,by:latestWeather.by});
    }
  },
  onWarning(room,warning) {
    return {seedRestocks:Object.keys(latestSeedRestocks).length,gearRestocks:Object.keys(latestGearItems).length,plantedBeds:Array.isArray(sharedBeds)?sharedBeds.filter(Boolean).length:0,hasGarden:Array.isArray(sharedBeds),hasFullSeedRestock:!!latestRestock,hasFullGearRestock:!!latestGearRestock,hasWeather:!!latestWeather};
  }
};

export default {
  async fetch(request,env) {
    const url=new URL(request.url);
    if (request.method==='GET'&&url.pathname==='/api/garden-restocks') {
      try {
        const row=await env.DB.prepare("SELECT state_json FROM little_garden_room_state WHERE id = 1").first();
        return Response.json(row?.state_json?JSON.parse(row.state_json):{});
      } catch (error) {
        console.error("Could not read shared garden restocks",error);
        return Response.json({error:"Shared restocks are temporarily unavailable"},{status:503});
      }
    }
    return new Response('Not found',{status:404});
  }
};
