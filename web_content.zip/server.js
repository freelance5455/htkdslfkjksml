export const schema =   "CREATE TABLE IF NOT EXISTS drawings (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, username TEXT NOT NULL, title TEXT NOT NULL, image_url TEXT NOT NULL, created_at TEXT NOT NULL);\nCREATE INDEX IF NOT EXISTS drawings_recent ON drawings (created_at DESC);";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== "/api/drawings") return new Response("Not found", { status: 404 });

    if (request.method === "GET") {
      const { results } = await env.DB
        .prepare("SELECT id, username, title, image_url, created_at FROM drawings ORDER BY id DESC LIMIT 60")
        .all();
      return Response.json(results);
    }

    if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });
    const userId = request.headers.get("x-websim-user-id");
    if (!userId) return Response.json({ error: "Sign in to publish drawings." }, { status: 401 });

    let body;
    try { body = await request.json(); }
    catch { return Response.json({ error: "Invalid drawing data." }, { status: 400 }); }
    const title = typeof body.title === "string" ? body.title.trim().slice(0, 32) : "";
    const imageUrl = typeof body.image_url === "string" ? body.image_url : "";
    let parsedUrl;
    try { parsedUrl = new URL(imageUrl); }
    catch { return Response.json({ error: "The drawing image is not valid." }, { status: 400 }); }
    if (!title) return Response.json({ error: "Give your drawing a name first." }, { status: 400 });
    if (parsedUrl.protocol !== "https:" || imageUrl.length > 2048) return Response.json({ error: "The drawing image URL is not valid." }, { status: 400 });

    const username = request.headers.get("x-websim-username") || "Websim player";
    const createdAt = new Date().toISOString();
    const { meta } = await env.DB
      .prepare("INSERT INTO drawings (user_id, username, title, image_url, created_at) VALUES (?, ?, ?, ?, ?)")
      .bind(userId, username, title, imageUrl, createdAt)
      .run();
    return Response.json({ drawing: { id: meta.last_row_id, username, title, image_url: imageUrl, created_at: createdAt } }, { status: 201 });
  },
};
