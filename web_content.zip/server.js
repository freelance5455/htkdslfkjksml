require("dotenv").config();
const express=require("express"),path=require("path");
const app=express(); app.use(express.json({limit:"1mb"})); app.use(express.static(path.join(__dirname,"public")));
app.post("/api/generate",async(req,res)=>{try{
 const prompt=String(req.body?.prompt||"").trim(); if(!prompt)return res.status(400).json({error:"Please describe your app or game."});
 if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:"AI is not connected yet. Set OPENAI_API_KEY in the server .env file."});
 const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Authorization":"Bearer "+process.env.OPENAI_API_KEY,"Content-Type":"application/json"},body:JSON.stringify({
  model:"gpt-4.1-mini",
  instructions:`You are BuildMate QuickBuild, a multilingual coding assistant. Understand Roman Urdu/Vinglish, Urdu, Hindi and English; reply in the user's language/script.
IMPORTANT PRODUCT GOAL: deliver a tiny, working MVP/prototype that a beginner could assemble in about 2–5 minutes, when the request is simple enough. Prioritize one-file HTML/CSS/JavaScript apps or tiny 2D browser games, minimal dependencies, and a clear run/test step. Keep scope small; do not pretend a complex app or 3D game can be fully completed in 2–5 minutes.
For each request: briefly state what the quick MVP will include and what is out of scope, then provide complete starter code and filenames. For complex requests, make a small prototype first and list later upgrades. Never claim code was executed, tested, packaged, or built unless it was. Do not generate malware, credential theft, game cheats, or anti-cheat bypasses. Explain if server/API/build tools are required.`,
  input:prompt
 })});
 const d=await r.json(); if(!r.ok)return res.status(r.status).json({error:d?.error?.message||"AI request failed"});
 const answer=(d.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==="output_text").map(x=>x.text).join("\n");
 res.json({answer:answer||"No response text returned."});
}catch(e){res.status(500).json({error:"Server error. Check setup and try again."})}});
app.listen(Number(process.env.PORT||3000),()=>console.log("BuildMate QuickBuild running"));
