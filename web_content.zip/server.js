const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const players = new Map();
app.use('/node_modules', express.static(path.join(__dirname, 'node_modules')));\napp.use(express.static(path.join(__dirname, 'public')));
io.on('connection', socket => {
  players.set(socket.id, {id:socket.id,x:0,z:0,rot:0});
  socket.on('drive', data => {
    const p=players.get(socket.id); if(!p) return;
    p.x=Number(data.x)||0; p.z=Number(data.z)||0; p.rot=Number(data.rot)||0;
  });
  socket.on('disconnect',()=>players.delete(socket.id));
});
setInterval(()=>io.emit('state',{players:[...players.values()]}),50);
const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`CM28CAR running at http://localhost:${PORT}`));
