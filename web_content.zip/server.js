const express=require("express");
const path=require("path");
const app=express();
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

app.post("/api/chat",async(req,res)=>{
 const message=String(req.body?.message||"").trim();
 if(!message)return res.status(400).json({error:"Empty message"});
 const key=process.env.OPENAI_API_KEY;
 if(!key)return res.status(500).json({error:"OPENAI_API_KEY is not configured on the server."});
 try{
   const r=await fetch("https://api.openai.com/v1/responses",{
     method:"POST",
     headers:{"Content-Type":"application/json","Authorization":"Bearer "+key},
     body:JSON.stringify({
       model:process.env.OPENAI_MODEL||"gpt-5.4-mini",
       input:[{role:"system",content:"You are NeonAI, a helpful AI assistant. Answer clearly and naturally."},{role:"user",content:message}]
     })
   });
   const d=await r.json();
   if(!r.ok) return res.status(r.status).json({error:d.error?.message||"AI request failed"});
   const reply=d.output_text || (d.output||[]).flatMap(x=>x.content||[]).map(x=>x.text||"").join("") || "No response.";
   res.json({reply});
 }catch(e){res.status(500).json({error:"Could not reach the AI service: "+e.message})}
});
const port=process.env.PORT||3000;
app.listen(port,()=>console.log("NeonAI: http://localhost:"+port));
