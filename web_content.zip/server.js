const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || crypto.randomBytes(12).toString('hex');
const DB_FILE = path.join(__dirname, 'data.json');
const PUB = path.join(__dirname, 'public');
const DAY = 864e5;

// Paket: tambah paket baru di sini
const PLANS = {
  '1bulan': { name: '1 Bulan', price: 49000, days: 30 },
  '1tahun': { name: '1 Tahun', price: 72000, days: 365 }
};

const H = {
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer'
};
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png' };

let db = { users: {}, sessions: {}, orders: [], trials: [] };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; } catch {}
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(db));

// Pembatasan permintaan: maks. 40 permintaan per 10 detik per IP
const hits = new Map();
setInterval(() => hits.clear(), 60000).unref();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter(t => now - t < 10000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > 40;
}

const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) =>
  salt + ':' + crypto.scryptSync(pw, salt, 64).toString('hex');
const check = (pw, stored) => {
  const a = Buffer.from(hash(pw, stored.split(':')[0])), b = Buffer.from(stored);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};
// Gmail: titik dan +tambahan diabaikan agar tidak bisa dapat trial dua kali
const normEmail = e => {
  let [u, d] = e.toLowerCase().split('@');
  if (d === 'gmail.com' || d === 'googlemail.com') u = u.replace(/\./g, '').split('+')[0];
  return u + '@' + d;
};
const user = n => (Object.hasOwn(db.users, n) ? db.users[n] : null);
const sid = req => (/sid=([a-f0-9]{64})/.exec(req.headers.cookie || '') || [])[1];
const getUser = req => { const s = db.sessions[sid(req)]; return s && s.exp > Date.now() ? user(s.user) : null; };
const active = u => u.expires > Date.now();
const view = u => ({
  user: u.name, plan: u.plan, expires: u.expires, active: active(u),
  trialAvailable: !active(u) && !db.trials.includes(u.email),
  orders: db.orders.filter(o => o.user === u.name).slice(-5)
});
const body = req => new Promise(ok => {
  let s = '';
  req.on('data', c => { s += c; if (s.length > 1e5) req.destroy(); });
  req.on('end', () => { try { ok(JSON.parse(s || '{}') || {}); } catch { ok({}); } });
  req.on('close', () => ok({}));
  req.on('error', () => ok({}));
});

async function api(req, res, url) {
  const send = (c, o) => { res.writeHead(c, { ...H, 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  const p = url.pathname, m = req.method;
  const me = getUser(req);
  const admin = req.headers['x-admin-key'] === ADMIN_KEY;

  if (p === '/api/me') return send(200, { ...(me ? view(me) : { user: null }), plans: PLANS });

  if (p === '/api/register' && m === 'POST') {
    const b = await body(req);
    const name = String(b.username || '').toLowerCase();
    const pw = String(b.password || ''), mail = String(b.email || '').trim();
    if (!/^(?!__proto__$)[a-z0-9_]{3,20}$/.test(name)) return send(400, { error: 'Nama pengguna 3-20 karakter: huruf, angka, atau _' });
    if (pw.length < 8) return send(400, { error: 'Kata sandi minimal 8 karakter' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) return send(400, { error: 'Email tidak valid' });
    const ne = normEmail(mail);
    if (user(name) || Object.values(db.users).some(x => x.email === ne)) return send(409, { error: 'Nama pengguna atau email sudah dipakai' });
    db.users[name] = { name, email: ne, hash: hash(pw), plan: null, expires: 0 };
    save();
    return send(200, { ok: true });
  }

  if (p === '/api/login' && m === 'POST') {
    const b = await body(req);
    const u = user(String(b.username || '').toLowerCase());
    if (!u || !check(String(b.password || ''), u.hash)) return send(401, { error: 'Nama pengguna atau kata sandi salah' });
    const t = crypto.randomBytes(32).toString('hex');
    db.sessions[t] = { user: u.name, exp: Date.now() + 7 * DAY };
    save();
    res.setHeader('Set-Cookie', `sid=${t}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=604800`);
    return send(200, { ok: true });
  }

  if (p === '/api/logout') {
    const t = sid(req);
    if (t) { delete db.sessions[t]; save(); }
    res.setHeader('Set-Cookie', 'sid=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0');
    return send(200, { ok: true });
  }

  // Trial 1 bulan: hanya sekali per email (berlaku juga untuk akun baru)
  if (p === '/api/trial' && m === 'POST') {
    if (!me) return send(401, { error: 'Masuk dulu' });
    if (active(me)) return send(400, { error: 'Paketmu masih aktif' });
    if (db.trials.includes(me.email)) return send(403, { error: 'Percobaan gratis hanya bisa dipakai sekali' });
    db.trials.push(me.email);
    Object.assign(me, { plan: 'trial', expires: Date.now() + 30 * DAY });
    save();
    return send(200, { ok: true });
  }

  // Pembayaran QR GoPay: pesanan menunggu konfirmasi admin
  if (p === '/api/order' && m === 'POST') {
    if (!me) return send(401, { error: 'Masuk dulu' });
    const b = await body(req);
    const plan = String(b.plan || ''), ref = String(b.ref || '').trim().slice(0, 40);
    if (!Object.hasOwn(PLANS, plan)) return send(400, { error: 'Paket tidak valid' });
    if (ref.length < 4) return send(400, { error: 'Isi kode/ID transaksi GoPay' });
    if (db.orders.some(o => o.ref === ref)) return send(409, { error: 'Kode transaksi ini sudah pernah dipakai' });
    db.orders.push({ id: crypto.randomBytes(4).toString('hex'), user: me.name, plan, ref, status: 'menunggu', at: Date.now() });
    save();
    return send(200, { ok: true });
  }

  if (p === '/api/admin/orders' && m === 'GET') return admin ? send(200, db.orders) : send(403, { error: 'Ditolak' });

  if (p === '/api/admin/approve' && m === 'POST') {
    if (!admin) return send(403, { error: 'Ditolak' });
    const { id } = await body(req);
    const o = db.orders.find(x => x.id === id && x.status === 'menunggu');
    if (!o) return send(404, { error: 'Pesanan tidak ditemukan' });
    const u = user(o.user);
    u.plan = o.plan;
    u.expires = Math.max(Date.now(), u.expires) + PLANS[o.plan].days * DAY;
    o.status = 'lunas';
    save();
    return send(200, { ok: true });
  }

  send(404, { error: 'Tidak ditemukan' });
}

function file(p, res) {
  const f = path.join(PUB, p === '/' ? 'index.html' : p);
  if (!f.startsWith(PUB + path.sep) || !fs.existsSync(f) || !fs.statSync(f).isFile()) {
    res.writeHead(404, H); return res.end('Tidak ditemukan');
  }
  res.writeHead(200, { ...H, 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
}

async function handle(req, res) {
  // Di belakang reverse proxy, set TRUST_PROXY=1 agar IP asli yang dihitung
  const ip = process.env.TRUST_PROXY ? (req.headers['x-forwarded-for'] || '').split(',')[0].trim() : req.socket.remoteAddress;
  if (limited(ip)) { res.writeHead(429, H); return res.end('Terlalu banyak permintaan'); }
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname.startsWith('/api/')) await api(req, res, url);
    else file(url.pathname, res);
  } catch {
    if (!res.headersSent) { res.writeHead(500, { ...H, 'Content-Type': 'application/json' }); res.end('{"error":"Kesalahan server"}'); }
  }
}

const tls = process.env.CERT_FILE && process.env.KEY_FILE;
(tls
  ? https.createServer({ cert: fs.readFileSync(process.env.CERT_FILE), key: fs.readFileSync(process.env.KEY_FILE) }, handle)
  : http.createServer(handle)
).listen(PORT, () => {
  console.log(`GSK Web jalan di port ${PORT} (${tls ? 'HTTPS' : 'HTTP - pasang HTTPS di depan'})`);
  if (!process.env.ADMIN_KEY) console.log('ADMIN_KEY sementara:', ADMIN_KEY);
});
