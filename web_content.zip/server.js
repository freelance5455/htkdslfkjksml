const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const app = express();
const upload = multer({ dest: 'uploads/' });
const PORT = 3000;

app.use(express.static('public'));
app.use('/output', express.static('output'));

['uploads', 'work', 'output'].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

function buildApk({ sourcePath, originalName, iconPath, appName, packageId, outApkPath }) {
    const logs = [];
    const buildId = 'build_' + Date.now();
    const workDir = path.resolve('work', buildId);
    const assetsDir = path.join(workDir, 'assets', 'www');
    const resDir = path.join(workDir, 'res');
    const drawableDir = path.join(resDir, 'drawable');
    const srcDir = path.join(workDir, 'src', ...packageId.split('.'));
    const objDir = path.join(workDir, 'obj');
    const binDir = path.join(workDir, 'bin');

    [assetsDir, drawableDir, srcDir, objDir, binDir].forEach(d => fs.mkdirSync(d, { recursive: true }));

    // 1. Extraction HTML ou ZIP
    if (originalName.toLowerCase().endsWith('.zip')) {
        logs.push('Extraction de l\'archive ZIP...');
        const zip = new AdmZip(sourcePath);
        zip.extractAllTo(assetsDir, true);
    } else {
        logs.push('Copie du fichier HTML vers assets/www/index.html...');
        fs.copyFileSync(sourcePath, path.join(assetsDir, 'index.html'));
    }

    // 2. Icône par défaut ou personnalisée
    const iconDest = path.join(drawableDir, 'icon.png');
    if (iconPath && fs.existsSync(iconPath)) {
        fs.copyFileSync(iconPath, iconDest);
    } else {
        // Icône PNG 1x1 verte valide minimale si aucune image fournie
        const minimalPng = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');
        fs.writeFileSync(iconDest, minimalPng);
    }

    // 3. AndroidManifest.xml avec permissions de stockage et internet
    const manifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${packageId}"
    android:versionCode="1"
    android:versionName="1.0">
    <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="33" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <application android:label="${appName.replace(/"/g, '')}" android:icon="@drawable/icon" android:usesCleartextTraffic="true">
        <activity android:name=".MainActivity" android:exported="true" android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;
    fs.writeFileSync(path.join(workDir, 'AndroidManifest.xml'), manifest);

    // 4. MainActivity.java avec support complet <input type="file"> (onShowFileChooser) et téléchargements Blob/Data
    const mainActivity = `package ${packageId};

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.view.Window;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        webView.addJavascriptInterface(new BlobBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());

        // Support natif des boutons <input type="file"> dans Android WebView
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(Intent.createChooser(intent, "Choisir un fichier (.html / .zip)"), FILE_CHOOSER_CODE);
                return true;
            }
        });

        // Support des téléchargements blob: et data:
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                if (url.startsWith("blob:")) {
                    String js = "javascript:(function(){var xhr=new XMLHttpRequest();xhr.open('GET','" + url + "',true);xhr.responseType='blob';xhr.onload=function(){if(this.status===200){var r=new FileReader();r.readAsDataURL(this.response);r.onloadend=function(){AndroidBridge.saveBase64('download_apkforge.bin',r.result);};}};xhr.send();})();";
                    webView.loadUrl(js);
                } else if (url.startsWith("data:")) {
                    new BlobBridge().saveBase64("download_apkforge.sh", url);
                }
            }
        });

        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_CODE && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{ data.getData() };
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public class BlobBridge {
        @JavascriptInterface
        public void saveFile(String fileName, String content) {
            try {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File file = new File(dir, fileName);
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(content.getBytes("UTF-8"));
                fos.close();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Enregistré dans Téléchargements : " + fileName, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Erreur sauvegarde : " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void saveBase64(String fileName, String dataUrl) {
            try {
                String base64Data = dataUrl.substring(dataUrl.indexOf(",") + 1);
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File file = new File(dir, fileName);
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(bytes);
                fos.close();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Téléchargé : " + fileName, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Erreur : " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
`;
    fs.writeFileSync(path.join(srcDir, 'MainActivity.java'), mainActivity);

    const androidJar = path.resolve('android.jar');
    if (!fs.existsSync(androidJar)) {
        throw new Error('Fichier android.jar introuvable. Lancez ./install.sh dans Termux.');
    }

    logs.push('Génération des ressources Android (aapt)...');
    execSync(`aapt package -f -m -J "${path.join(workDir, 'src')}" -M "${path.join(workDir, 'AndroidManifest.xml')}" -S "${resDir}" -I "${androidJar}"`);

    logs.push('Compilation Java (ecj)...');
    execSync(`ecj -d "${objDir}" -classpath "${androidJar}" -sourcepath "${path.join(workDir, 'src')}" "${path.join(srcDir, 'MainActivity.java')}"`);

    logs.push('Conversion Dalvik DEX (dx)...');
    execSync(`dx --dex --output="${path.join(binDir, 'classes.dex')}" "${objDir}"`);

    logs.push('Empaquetage des assets et ressources...');
    const unsignedApk = path.join(binDir, 'app.unsigned.apk');
    execSync(`aapt package -f -M "${path.join(workDir, 'AndroidManifest.xml')}" -S "${resDir}" -A "${path.join(workDir, 'assets')}" -I "${androidJar}" -F "${unsignedApk}"`);

    logs.push('Injection de classes.dex...');
    execSync(`cd "${binDir}" && aapt add app.unsigned.apk classes.dex`);

    logs.push('Signature cryptographique de l\'APK (apksigner)...');
    const keystore = path.resolve('debug.keystore');
    if (!fs.existsSync(keystore)) {
        execSync(`keytool -genkey -v -keystore "${keystore}" -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=APKForge,O=Android,C=FR"`);
    }
    execSync(`apksigner sign --ks "${keystore}" --ks-pass pass:android --key-pass pass:android --out "${outApkPath}" "${unsignedApk}"`);

    return logs;
}

app.post('/build', upload.fields([{ name: 'sourceFile', maxCount: 1 }, { name: 'iconFile', maxCount: 1 }]), (req, res) => {
    try {
        const src = req.files['sourceFile']?.[0];
        if (!src) return res.status(400).json({ success: false, error: 'Aucun fichier source reçu.' });

        const icon = req.files['iconFile']?.[0];
        const appName = req.body.appName || 'APKForge App';
        const packageId = req.body.packageId || 'com.apkforge.app';
        const outName = `apkforge_${Date.now()}.apk`;
        const outPath = path.resolve('output', outName);

        const logs = buildApk({
            sourcePath: src.path,
            originalName: src.originalname,
            iconPath: icon ? icon.path : null,
            appName,
            packageId,
            outApkPath: outPath
        });

        res.json({ success: true, downloadUrl: `/output/${outName}`, logs });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

if (require.main === module) {
    app.listen(PORT, () => {
        console.log(`APKForge Mobile prêt sur http://localhost:${PORT}`);
    });
}

module.exports = { buildApk };
