"use strict";
/*
 * PARSNET backend — بدون نیاز به نصب هیچ پکیجی (فقط Node 16+)
 *   node server.js
 *
 * - حساب مدیر و کاربران عادی کاملاً جدا هستند (نقش admin / user روی سرور بررسی می‌شود)
 * - رمزها با scrypt هش می‌شوند؛ نشست‌ها با کوکی HttpOnly
 * - هیچ بخشی از پنل مدیریت برای کاربر عادی ارسال یا قابل فراخوانی نیست
 *
 * متغیرهای محیطی (اختیاری):
 *   PORT=3000  HOST=127.0.0.1  ADMIN_USER=...  ADMIN_PASS=...  COOKIE_SECURE=1  TRUST_PROXY=1
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "127.0.0.1";
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, "data.json");
const SESSION_MS = 30 * 24 * 3600 * 1000;
const STATIC = {
  "/": ["index.html", "text/html; charset=utf-8"],
  "/index.html": ["index.html", "text/html; charset=utf-8"],
  "/style.css": ["style.css", "text/css; charset=utf-8"],
  "/script.js": ["script.js", "application/javascript; charset=utf-8"]
};

/* ---------------- Storage ---------------- */
function emptyDb() {
  return { users: [], servers: [], sessions: [], settings: { announcement: "به پارس‌نت خوش آمدید", ad: "" } };
}
function load() {
  try { return Object.assign(emptyDb(), JSON.parse(fs.readFileSync(DATA_FILE, "utf8"))); }
  catch (e) { return emptyDb(); }
}
let db = load();
function persist() {
  const tmp = DATA_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
  fs.renameSync(tmp, DATA_FILE);
}
const uid = () => crypto.randomBytes(12).toString("hex");
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");

/* ---------------- Passwords ---------------- */
function hashPw(pw) {
  const salt = crypto.randomBytes(16);
  return salt.toString("hex") + ":" + crypto.scryptSync(pw, salt, 64).toString("hex");
}
function checkPw(pw, stored) {
  try {
    const [s, h] = stored.split(":");
    const x = crypto.scryptSync(pw, Buffer.from(s, "hex"), 64);
    return crypto.timingSafeEqual(x, Buffer.from(h, "hex"));
  } catch (e) { return false; }
}
const DUMMY_HASH = hashPw("dummy-password-for-timing");

/* ---------------- Seed admin (first run only) ---------------- */
if (!db.users.some((u) => u.role === "admin")) {
  const name = process.env.ADMIN_USER || "pn6baixx";
  const pass = process.env.ADMIN_PASS || "UMOHxDRLK39I";
  db.users.push({ id: uid(), username: name, key: name.toLowerCase(), pass: hashPw(pass), role: "admin", disabled: false, created: Date.now() });
  persist();
  console.log("حساب مدیر ساخته شد. بعد از اولین ورود، نام کاربری و رمز را از پنل تغییر دهید.");
}

/* ---------------- Helpers ---------------- */
const rate = new Map();
function allow(ip, bucket, max, windowMs) {
  const k = bucket + ":" + ip, now = Date.now();
  let r = rate.get(k);
  if (!r || r.reset < now) { r = { n: 0, reset: now + windowMs }; rate.set(k, r); }
  r.n++;
  return r.n <= max;
}
setInterval(() => { const now = Date.now(); for (const [k, r] of rate) if (r.reset < now) rate.delete(k); }, 60000).unref();

function clientIp(req) {
  if (process.env.TRUST_PROXY) {
    const f = req.headers["x-forwarded-for"];
    if (f) return String(f).split(",")[0].trim();
  }
  return req.socket.remoteAddress || "?";
}

function send(res, code, body, headers) {
  res.writeHead(code, Object.assign({
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": "default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'; frame-ancestors 'none'"
  }, headers));
  res.end(body);
}
function json(res, code, obj, headers) {
  send(res, code, JSON.stringify(obj), Object.assign({ "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }, headers));
}
const fail = (res, code, msg) => json(res, code, { error: msg });

function readBody(req, limit = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", (c) => { size += c.length; if (size > limit) { reject(new Error("big")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {}); } catch (e) { reject(new Error("bad")); } });
    req.on("error", reject);
  });
}

function cookieOf(req, name) {
  const c = req.headers.cookie || "";
  for (const part of c.split(";")) {
    const i = part.indexOf("=");
    if (i > 0 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return "";
}
function setCookie(req, token, maxAgeSec) {
  const secure = process.env.COOKIE_SECURE || req.headers["x-forwarded-proto"] === "https" ? "; Secure" : "";
  return `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAgeSec}${secure}`;
}

function newSession(userId) {
  const now = Date.now();
  db.sessions = db.sessions.filter((s) => s.exp > now);
  const token = crypto.randomBytes(32).toString("hex");
  db.sessions.push({ h: sha(token), uid: userId, exp: now + SESSION_MS });
  persist();
  return token;
}
function currentUser(req) {
  const t = cookieOf(req, "sid");
  if (!t) return null;
  const h = sha(t), now = Date.now();
  const s = db.sessions.find((x) => x.h === h && x.exp > now);
  if (!s) return null;
  const u = db.users.find((x) => x.id === s.uid);
  return u && !u.disabled ? u : null;
}
const pub = (u) => ({ username: u.username, role: u.role, displayName: u.displayName || u.username });

function validName(n) { return typeof n === "string" && /^[A-Za-z0-9_.-]{3,32}$/.test(n); }
function validEmail(e) { return typeof e === "string" && e.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e); }
function validDisplay(n) { return typeof n === "string" && n.trim().length >= 2 && n.trim().length <= 40 && !/[\u0000-\u001f<>]/.test(n); }
function validPass(p) { return typeof p === "string" && p.length >= 6 && p.length <= 128; }

/* ---------------- Config links ---------------- */
function parseLink(input, customName) {
  const link = String(input || "").trim();
  if (!link || link.length > 8192 || !link.includes("://")) return null;
  const scheme = link.split("://")[0].toLowerCase();
  const map = { vless: "VLESS", vmess: "VMESS", trojan: "TROJAN", ss: "SHADOWSOCKS", shadowsocks: "SHADOWSOCKS" };
  const protocol = map[scheme];
  if (!protocol) return null;
  let host = "", port = 0, name = "";
  try {
    const rest = link.slice(link.indexOf("://") + 3);
    if (protocol === "VMESS") {
      const j = JSON.parse(Buffer.from(rest.split("#")[0], "base64").toString("utf8"));
      host = String(j.add || ""); port = parseInt(j.port, 10) || 0; name = String(j.ps || "");
    } else {
      if (rest.includes("#")) name = decodeURIComponent(rest.slice(rest.indexOf("#") + 1));
      let body = rest.split("#")[0].split("?")[0];
      if (protocol === "SHADOWSOCKS" && !body.includes("@")) body = Buffer.from(body, "base64").toString("utf8");
      const hp = body.includes("@") ? body.slice(body.lastIndexOf("@") + 1) : body;
      const m = hp.match(/^\[?([^\]]+?)\]?:(\d+)\/?$/);
      if (m) { host = m[1]; port = parseInt(m[2], 10); } else host = hp.replace(/\/$/, "");
      if (!name) {
        const qs = link.split("?")[1];
        if (qs) name = new URLSearchParams(qs.split("#")[0]).get("remarks") || "";
      }
    }
  } catch (e) { /* keep what was parsed */ }
  const finalName = (String(customName || "").trim() || name || host || protocol).slice(0, 100);
  return { id: uid(), name: finalName, link, protocol, host: host.slice(0, 255), port, enabled: true };
}
function addServer(cfg) {
  db.servers = db.servers.filter((s) => s.link !== cfg.link);
  db.servers.unshift(cfg);
}

/* ---------------- API ---------------- */
async function api(req, res, p) {
  const method = req.method;
  if (method !== "GET" && req.headers["x-parsnet"] !== "1") return fail(res, 403, "درخواست نامعتبر است.");
  const ip = clientIp(req);
  let body = {};
  if (method !== "GET" && method !== "DELETE") {
    try { body = await readBody(req); } catch (e) { return fail(res, 400, "درخواست نامعتبر است."); }
  }

  /* --- public --- */
  if (p === "/api/me" && method === "GET") {
    const u = currentUser(req);
    return json(res, 200, { user: u ? pub(u) : null, announcement: db.settings.announcement, ad: db.settings.ad });
  }

  if (p === "/api/signup" && method === "POST") {
    if (!allow(ip, "signup", 10, 3600 * 1000)) return fail(res, 429, "تعداد درخواست‌ها زیاد است؛ بعداً دوباره تلاش کنید.");
    if (!validDisplay(body.displayName)) return fail(res, 400, "یک نام برای خودتان انتخاب کنید (۲ تا ۴۰ حرف).");
    if (!validName(body.username)) return fail(res, 400, "نام کاربری باید ۳ تا ۳۲ کاراکتر و فقط حروف انگلیسی، عدد و _ . - باشد.");
    if (!validEmail(body.email)) return fail(res, 400, "ایمیل معتبر وارد کنید.");
    if (!validPass(body.password)) return fail(res, 400, "رمز عبور باید حداقل ۶ کاراکتر باشد.");
    const key = body.username.toLowerCase();
    const email = body.email.trim().toLowerCase();
    if (db.users.some((u) => u.key === key)) return fail(res, 409, "این نام کاربری قبلاً ثبت شده است.");
    if (db.users.some((u) => u.email === email)) return fail(res, 409, "این ایمیل قبلاً ثبت شده است.");
    const u = { id: uid(), username: body.username, key, displayName: body.displayName.trim(), email, pass: hashPw(body.password), role: "user", disabled: false, created: Date.now() };
    db.users.push(u);
    const token = newSession(u.id);
    return json(res, 200, { user: pub(u) }, { "Set-Cookie": setCookie(req, token, SESSION_MS / 1000) });
  }

  if (p === "/api/login" && method === "POST") {
    if (!allow(ip, "login", 20, 15 * 60 * 1000)) return fail(res, 429, "تعداد تلاش‌ها زیاد است؛ چند دقیقه بعد دوباره تلاش کنید.");
    const id = String(body.identifier || body.username || "").trim().toLowerCase();
    const u = id ? db.users.find((x) => x.key === id || (x.email && x.email === id)) : null;
    const ok = checkPw(String(body.password || ""), u ? u.pass : DUMMY_HASH);
    if (!u || !ok || u.disabled) return fail(res, 401, "نام کاربری/ایمیل یا رمز اشتباه است.");
    const token = newSession(u.id);
    return json(res, 200, { user: pub(u) }, { "Set-Cookie": setCookie(req, token, SESSION_MS / 1000) });
  }

  if (p === "/api/logout" && method === "POST") {
    const t = cookieOf(req, "sid");
    if (t) { const h = sha(t); db.sessions = db.sessions.filter((s) => s.h !== h); persist(); }
    return json(res, 200, { ok: true }, { "Set-Cookie": setCookie(req, "", 0) });
  }

  /* --- authenticated --- */
  const me = currentUser(req);
  if (!me) return fail(res, 401, "ابتدا وارد حساب کاربری شوید.");

  if (p === "/api/state" && method === "GET") {
    const list = me.role === "admin" ? db.servers : db.servers.filter((s) => s.enabled);
    return json(res, 200, {
      user: pub(me), announcement: db.settings.announcement, ad: db.settings.ad,
      servers: list.map((s) => ({ id: s.id, name: s.name, protocol: s.protocol, host: s.host, port: s.port, link: s.link, enabled: s.enabled }))
    });
  }

  if (p === "/api/account" && method === "PUT") {
    if (!allow(ip, "acct", 10, 15 * 60 * 1000)) return fail(res, 429, "تعداد تلاش‌ها زیاد است.");
    if (!checkPw(String(body.currentPassword || ""), me.pass)) return fail(res, 403, "رمز فعلی اشتباه است.");
    if (body.username !== undefined && body.username !== "" && body.username !== me.username) {
      if (!validName(body.username)) return fail(res, 400, "نام کاربری معتبر نیست.");
      const key = body.username.toLowerCase();
      if (db.users.some((u) => u.key === key && u.id !== me.id)) return fail(res, 409, "این نام کاربری قبلاً ثبت شده است.");
      me.username = body.username; me.key = key;
    }
    if (body.password) {
      if (!validPass(body.password)) return fail(res, 400, "رمز جدید باید حداقل ۶ کاراکتر باشد.");
      me.pass = hashPw(body.password);
    }
    persist();
    return json(res, 200, { user: pub(me) });
  }

  /* --- admin only --- */
  if (p.startsWith("/api/admin/")) {
    if (me.role !== "admin") return fail(res, 404, "یافت نشد.");

    if (p === "/api/admin/servers" && method === "POST") {
      const cfg = parseLink(body.link, body.name);
      if (!cfg) return fail(res, 400, "لینک معتبر VLESS/VMess/Trojan/SS وارد کنید.");
      addServer(cfg); persist();
      return json(res, 200, { ok: true });
    }
    if (p === "/api/admin/servers/bulk" && method === "POST") {
      const lines = String(body.text || "").split(/\r?\n/).slice(0, 2000);
      let added = 0;
      for (const l of lines) { const cfg = parseLink(l); if (cfg) { addServer(cfg); added++; } }
      persist();
      return json(res, 200, { added });
    }
    let m = p.match(/^\/api\/admin\/servers\/([a-f0-9]+)$/);
    if (m) {
      const s = db.servers.find((x) => x.id === m[1]);
      if (!s) return fail(res, 404, "یافت نشد.");
      if (method === "PATCH") { if (typeof body.enabled === "boolean") s.enabled = body.enabled; persist(); return json(res, 200, { ok: true }); }
      if (method === "DELETE") { db.servers = db.servers.filter((x) => x.id !== s.id); persist(); return json(res, 200, { ok: true }); }
    }

    if (p === "/api/admin/settings" && method === "PUT") {
      if (typeof body.announcement === "string") db.settings.announcement = body.announcement.slice(0, 300);
      if (typeof body.ad === "string") db.settings.ad = body.ad.slice(0, 500);
      persist();
      return json(res, 200, { ok: true });
    }

    if (p === "/api/admin/users" && method === "GET") {
      return json(res, 200, { users: db.users.map((u) => ({ id: u.id, username: u.username, displayName: u.displayName || "", email: u.email || "", role: u.role, disabled: u.disabled, created: u.created })) });
    }
    m = p.match(/^\/api\/admin\/users\/([a-f0-9]+)$/);
    if (m) {
      const u = db.users.find((x) => x.id === m[1]);
      if (!u) return fail(res, 404, "یافت نشد.");
      if (u.role === "admin") return fail(res, 400, "حساب مدیر قابل تغییر از این بخش نیست.");
      if (method === "PATCH") { if (typeof body.disabled === "boolean") u.disabled = body.disabled; persist(); return json(res, 200, { ok: true }); }
      if (method === "DELETE") {
        db.users = db.users.filter((x) => x.id !== u.id);
        db.sessions = db.sessions.filter((s) => s.uid !== u.id);
        persist();
        return json(res, 200, { ok: true });
      }
    }
  }

  return fail(res, 404, "یافت نشد.");
}

/* ---------------- HTTP ---------------- */
const server = http.createServer(async (req, res) => {
  try {
    const p = new URL(req.url, "http://localhost").pathname;
    if (p.startsWith("/api/")) return await api(req, res, p);
    const f = STATIC[p];
    if (!f || (req.method !== "GET" && req.method !== "HEAD")) return send(res, 404, "Not found", { "Content-Type": "text/plain; charset=utf-8" });
    const data = fs.readFileSync(path.join(__dirname, f[0]));
    return send(res, 200, req.method === "HEAD" ? "" : data, { "Content-Type": f[1], "Cache-Control": "no-cache" });
  } catch (e) {
    console.error(e);
    try { json(res, 500, { error: "خطای داخلی سرور." }); } catch (_) {}
  }
});

server.listen(PORT, HOST, () => console.log(`PARSNET: http://${HOST === "0.0.0.0" ? "localhost" : HOST}:${PORT}`));
