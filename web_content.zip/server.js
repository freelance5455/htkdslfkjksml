import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
const port = process.env.PORT || 3000;
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(cors());
app.use(express.json({limit:"1mb"}));
app.use(express.static("public"));

app.post("/api/generate", async (req,res)=>{
  try {
    const { prompt, style="Cinematográfico", format="9:16" } = req.body;
    if (!prompt?.trim()) return res.status(400).json({error:"Digite uma descrição."});

    const finalPrompt = `Create a premium smartphone wallpaper. ${prompt.trim()}.
Style: ${style}. Composition: ${format === "9:16" ? "vertical portrait 9:16" : format === "16:9" ? "wide landscape 16:9" : "square 1:1"}.
No UI, no borders, no watermark, visually striking, high detail, clean composition, suitable as a wallpaper.`;

    const result = await client.images.generate({
      model: process.env.IMAGE_MODEL || "gpt-image-2",
      prompt: finalPrompt,
      size: format === "9:16" ? "1024x1536" : format === "16:9" ? "1536x1024" : "1024x1024"
    });

    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error("A API não retornou uma imagem.");
    res.json({ image:`data:image/png;base64,${b64}` });
  } catch (e) {
    console.error(e);
    res.status(500).json({error:e?.message || "Erro ao gerar imagem."});
  }
});

app.listen(port,()=>console.log(`WallAI rodando em http://localhost:${port}`));
