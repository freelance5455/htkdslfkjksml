require("dotenv").config();
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");

const app = express();
const db = new Database("profe_larry.sqlite");
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-me";

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS progress (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  subject TEXT,
  lesson TEXT,
  score INTEGER DEFAULT 0,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const lessonBank = {
  matematicas: {
    title: "Matemáticas",
    lessons: [
      { id:"m1", title:"Sumar sin miedo", text:"Sumar significa juntar cantidades. Si tienes 2 manzanas y recibes 3 más, juntas 2 + 3 y obtienes 5.", quiz:[
        ["¿Cuánto es 2 + 3?", ["4","5","6"], 1],
        ["¿Qué hacemos al sumar?", ["Juntamos cantidades","Quitamos cantidades","Dormimos"], 0]
      ]},
      { id:"m2", title:"Fracciones fáciles", text:"Una fracción representa partes de un todo. En 1/2, el 1 indica cuántas partes tomamos y el 2 en cuántas partes iguales dividimos el todo.", quiz:[
        ["En 1/2, ¿qué indica el 2?", ["Las partes que tomamos","En cuántas partes iguales dividimos","El resultado"], 1]
      ]}
    ]
  },
  ciencias: {
    title:"Ciencias",
    lessons:[
      { id:"c1", title:"¿Qué es la materia?", text:"La materia es todo aquello que tiene masa y ocupa un lugar. El agua, el aire, una piedra y tu cuaderno son ejemplos.", quiz:[
        ["¿Cuál es un ejemplo de materia?", ["El aire","Un pensamiento","Un número"], 0]
      ]}
    ]
  },
  ingles: {
    title:"Inglés",
    lessons:[
      { id:"i1", title:"Saludos básicos", text:"Hello significa hola. Good morning significa buenos días. Goodbye significa adiós. Puedes empezar con frases cortas y repetirlas en voz alta.", quiz:[
        ["¿Qué significa Hello?", ["Adiós","Hola","Gracias"], 1]
      ]}
    ]
  },
  espanol: {
    title:"Español",
    lessons:[
      { id:"e1", title:"Idea principal", text:"La idea principal es lo más importante que un texto quiere comunicar. Para encontrarla, pregunta: ¿de qué trata principalmente?", quiz:[
        ["¿Qué buscamos para encontrar la idea principal?", ["Lo menos importante","El tema principal","Una palabra al azar"], 1]
      ]}
    ]
  },
  historia: {
    title:"Historia",
    lessons:[
      { id:"h1", title:"Pensar como historiador", text:"La historia estudia hechos del pasado usando fuentes. Una fuente puede ser un documento, una fotografía, un objeto o un testimonio.", quiz:[
        ["¿Cuál puede ser una fuente histórica?", ["Una fotografía","Una adivinanza sin contexto","Un sueño"], 0]
      ]}
    ]
  },
  tecnologia: {
    title:"Tecnología",
    lessons:[
      { id:"t1", title:"¿Qué es un algoritmo?", text:"Un algoritmo es una serie ordenada de pasos para resolver una tarea o problema. Una receta de cocina es un ejemplo sencillo.", quiz:[
        ["¿Qué describe mejor un algoritmo?", ["Pasos ordenados para resolver algo","Un dibujo","Una contraseña"], 0]
      ]}
    ]
  }
};

app.get("/api/health", (_,res)=>res.json({ok:true, app:"PROFE LARRY IA"}));
app.get("/api/offline-content", (_,res)=>res.json(lessonBank));

app.post("/api/tutor", async (req,res)=>{
  const { message, level="normal", mode="adulto" } = req.body || {};
  if (!message) return res.status(400).json({error:"Escribe una pregunta."});

  // Fallback seguro: si no hay proveedor de IA configurado, responde con una guía útil.
  // En producción, conectar aquí el proveedor de IA usando la clave SOLO en el servidor.
  if (!process.env.AI_API_KEY || !process.env.AI_BASE_URL || !process.env.AI_MODEL) {
    return res.json({
      answer: `Soy Profe Larry. Vamos paso a paso. Me preguntaste: "${message}".\n\nPrimero, dime qué parte ya entiendes y qué parte te parece difícil. Luego te lo explicaré con ejemplos y ejercicios, adaptándome a tu nivel (${level}) y a tu modo (${mode}).`,
      offlineFallback:true
    });
  }

  try {
    const r = await fetch(process.env.AI_BASE_URL, {
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        "Authorization":`Bearer ${process.env.AI_API_KEY}`
      },
      body:JSON.stringify({
        model:process.env.AI_MODEL,
        messages:[
          {role:"system",content:"Eres Profe Larry IA, un tutor paciente. Explica en español claro, paso a paso, con ejemplos. Adapta profundidad al nivel solicitado y nunca humilles al estudiante."},
          {role:"user",content:`Modo: ${mode}. Nivel de explicación: ${level}. Pregunta: ${message}`}
        ]
      })
    });
    const data = await r.json();
    const answer = data.choices?.[0]?.message?.content || "No pude generar una respuesta.";
    res.json({answer, offlineFallback:false});
  } catch(e) {
    res.status(503).json({error:"No hay conexión con el tutor avanzado.", offlineFallback:true});
  }
});

app.listen(PORT,()=>console.log(`PROFE LARRY IA en http://localhost:${PORT}`));
