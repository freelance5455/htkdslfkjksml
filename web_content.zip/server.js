/**
 * CHAUFALAND - Servidor Backend Completo
 * Express + Socket.io (WebRTC Signaling & Voice Channels)
 * WebSocket Server Bridge para Addon Minecraft Bedrock (@minecraft/server-net)
 * Conexión WebSocket y API REST oficial de Exaroton
 * Creado por: JuancitoChen23
 */

require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const { Server: SocketIOServer } = require('socket.io');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);

// Configuración inicial en memoria (modificable desde el Panel Admin con clave JuancitoChen23)
const config = {
  adminSecret: process.env.ADMIN_SECRET || 'JuancitoChen23',
  serverType: process.env.SERVER_TYPE || 'exaroton', // 'exaroton' | 'aternos'
  exarotonToken: process.env.EXAROTON_TOKEN || '',
  exarotonServerId: process.env.EXAROTON_SERVER_ID || '',
  secondaryServerIp: process.env.SECONDARY_SERVER_IP || 'chaufaland.aternos.me:19132',
  isSecondaryBedrock: true,
  port: process.env.PORT || 3000
};

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// ==========================================
// SOCKET.IO: CANALES DE VOZ Y WEBRTC
// ==========================================
const io = new SocketIOServer(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Canales predeterminados de Chaufaland
const VOICE_CHANNELS = [
  'General / Spawn',
  'AFK / Ausente',
  'Cueva & Minería',
  'Base Principal',
  'Expedición Nether'
];

// Estado de usuarios en canales de voz: { socketId: { gamerTag, channel, isMuted, isSpeaking } }
const voiceUsers = new Map();

// Estado de jugadores de Minecraft Bedrock recibidos desde el Addon
const bedrockPlayers = new Map(); // gamertag -> { gamertag, x, y, z, dimension, health, lastSeen }

io.on('connection', (socket) => {
  console.log(`[Socket.io] Nuevo cliente conectado: ${socket.id}`);

  // Enviar lista inicial de canales y usuarios conectados
  socket.emit('channels-list', VOICE_CHANNELS);
  socket.emit('voice-state-sync', Array.from(voiceUsers.values()));
  socket.emit('bedrock-telemetry-sync', Array.from(bedrockPlayers.values()));

  // Unirse a un canal de voz
  socket.on('join-channel', ({ gamerTag, channel }) => {
    if (!gamerTag || !channel) return;

    // Si ya estaba en otro canal, remover y notificar
    const prev = voiceUsers.get(socket.id);
    if (prev && prev.channel) {
      socket.leave(prev.channel);
      io.to(prev.channel).emit('user-left-channel', { socketId: socket.id, gamerTag: prev.gamerTag });
    }

    const userData = {
      socketId: socket.id,
      gamerTag: gamerTag.trim(),
      channel,
      isMuted: false,
      isSpeaking: false,
      joinedAt: Date.now()
    };

    voiceUsers.set(socket.id, userData);
    socket.join(channel);

    console.log(`[Voz] ${userData.gamerTag} se unió al canal "${channel}"`);

    // Notificar a todos en el canal
    socket.to(channel).emit('user-joined-channel', userData);
    // Notificar a todos los clientes la actualización del estado general
    io.emit('voice-state-sync', Array.from(voiceUsers.values()));
  });

  // Salir de un canal de voz
  socket.on('leave-channel', () => {
    const user = voiceUsers.get(socket.id);
    if (user) {
      socket.leave(user.channel);
      socket.to(user.channel).emit('user-left-channel', { socketId: socket.id, gamerTag: user.gamerTag });
      voiceUsers.delete(socket.id);
      io.emit('voice-state-sync', Array.from(voiceUsers.values()));
      console.log(`[Voz] ${user.gamerTag} abandonó el canal "${user.channel}"`);
    }
  });

  // Actualizar estado de silencio (Mute)
  socket.on('update-mute', ({ isMuted }) => {
    const user = voiceUsers.get(socket.id);
    if (user) {
      user.isMuted = !!isMuted;
      io.to(user.channel).emit('user-mute-changed', { socketId: socket.id, isMuted: user.isMuted });
      io.emit('voice-state-sync', Array.from(voiceUsers.values()));
    }
  });

  // Actualizar indicador de habla activa
  socket.on('speaking-state', ({ isSpeaking }) => {
    const user = voiceUsers.get(socket.id);
    if (user) {
      user.isSpeaking = !!isSpeaking;
      socket.to(user.channel).emit('user-speaking-changed', { socketId: socket.id, isSpeaking: user.isSpeaking });
    }
  });

  // Señalización WebRTC Peer-to-Peer
  socket.on('webrtc-offer', ({ targetSocketId, sdp }) => {
    io.to(targetSocketId).emit('webrtc-offer', {
      senderSocketId: socket.id,
      sdp
    });
  });

  socket.on('webrtc-answer', ({ targetSocketId, sdp }) => {
    io.to(targetSocketId).emit('webrtc-answer', {
      senderSocketId: socket.id,
      sdp
    });
  });

  socket.on('webrtc-ice-candidate', ({ targetSocketId, candidate }) => {
    io.to(targetSocketId).emit('webrtc-ice-candidate', {
      senderSocketId: socket.id,
      candidate
    });
  });

  // Desconexión
  socket.on('disconnect', () => {
    const user = voiceUsers.get(socket.id);
    if (user) {
      socket.to(user.channel).emit('user-left-channel', { socketId: socket.id, gamerTag: user.gamerTag });
      voiceUsers.delete(socket.id);
      io.emit('voice-state-sync', Array.from(voiceUsers.values()));
    }
    console.log(`[Socket.io] Cliente desconectado: ${socket.id}`);
  });
});

// ==========================================
// WEBSOCKET BRIDGE PARA ADDON MINECRAFT BEDROCK
// ==========================================
const wssBedrock = new WebSocket.Server({ noServer: true });

wssBedrock.on('connection', (ws, req) => {
  console.log(`[Bedrock Addon] Servidor Minecraft conectado desde: ${req.socket.remoteAddress}`);

  ws.on('message', (raw) => {
    try {
      const data = JSON.parse(raw.toString());
      // data format:
      // { type: 'telemetry_batch', players: [ { gamertag, x, y, z, dimension, health } ] }
      // o { type: 'player_join', gamertag, dimension, x, y, z }
      // o { type: 'player_leave', gamertag }

      if (data.type === 'telemetry_batch' && Array.isArray(data.players)) {
        data.players.forEach((p) => {
          if (p.gamertag) {
            bedrockPlayers.set(p.gamertag, {
              gamertag: p.gamertag,
              x: Math.round(p.x * 10) / 10,
              y: Math.round(p.y * 10) / 10,
              z: Math.round(p.z * 10) / 10,
              dimension: p.dimension || 'overworld',
              health: p.health || 20,
              lastSeen: Date.now()
            });
          }
        });
        io.emit('bedrock-telemetry-sync', Array.from(bedrockPlayers.values()));
      } else if (data.type === 'player_join') {
        bedrockPlayers.set(data.gamertag, {
          gamertag: data.gamertag,
          x: Math.round((data.x || 0) * 10) / 10,
          y: Math.round((data.y || 0) * 10) / 10,
          z: Math.round((data.z || 0) * 10) / 10,
          dimension: data.dimension || 'overworld',
          health: data.health || 20,
          lastSeen: Date.now()
        });
        io.emit('bedrock-player-joined', data);
        io.emit('bedrock-telemetry-sync', Array.from(bedrockPlayers.values()));
      } else if (data.type === 'player_leave') {
        bedrockPlayers.delete(data.gamertag);
        io.emit('bedrock-player-left', data);
        io.emit('bedrock-telemetry-sync', Array.from(bedrockPlayers.values()));
      }
    } catch (err) {
      console.error('[Bedrock Addon] Error procesando payload:', err.message);
    }
  });

  ws.on('close', () => {
    console.log('[Bedrock Addon] Conexión cerrada');
  });

  ws.send(JSON.stringify({ status: 'connected', server: 'CHAUFALAND_BRIDGE' }));
});

// Limpieza de jugadores desconectados cada 30 segundos
setInterval(() => {
  const now = Date.now();
  let modified = false;
  for (const [tag, p] of bedrockPlayers.entries()) {
    if (now - p.lastSeen > 35000) {
      bedrockPlayers.delete(tag);
      modified = true;
    }
  }
  if (modified) {
    io.emit('bedrock-telemetry-sync', Array.from(bedrockPlayers.values()));
  }
}, 10000);

// Upgrade HTTP para soportar WebSocket en /ws/minecraft
server.on('upgrade', (request, socket, head) => {
  const pathname = new URL(request.url, `http://${request.headers.host}`).pathname;
  if (pathname === '/ws/minecraft' || pathname === '/ws-addon') {
    wssBedrock.handleUpgrade(request, socket, head, (ws) => {
      wssBedrock.emit('connection', ws, request);
    });
  }
});

// ==========================================
// EXAROTON WEBSOCKET CLIENT & STREAM
// ==========================================
let exarotonWsClient = null;
let lastExarotonStatus = null;

function connectExarotonWebSocket() {
  if (!config.exarotonToken || !config.exarotonServerId) {
    return;
  }

  if (exarotonWsClient) {
    try {
      exarotonWsClient.terminate();
    } catch (e) {}
    exarotonWsClient = null;
  }

  const url = `wss://ws.exaroton.com/v1/servers/${config.exarotonServerId}/websocket`;
  console.log(`[Exaroton WS] Conectando a ${url}...`);

  try {
    exarotonWsClient = new WebSocket(url, {
      headers: {
        Authorization: `Bearer ${config.exarotonToken}`
      }
    });

    exarotonWsClient.on('open', () => {
      console.log('[Exaroton WS] Conexión establecida con Exaroton');
      // Suscribirse a los streams de consola y estado
      exarotonWsClient.send(JSON.stringify({
        stream: 'console',
        type: 'start'
      }));
      exarotonWsClient.send(JSON.stringify({
        stream: 'tick',
        type: 'start'
      }));
      exarotonWsClient.send(JSON.stringify({
        stream: 'stats',
        type: 'start'
      }));
    });

    exarotonWsClient.on('message', (msg) => {
      try {
        const payload = JSON.parse(msg.toString());
        // Reenviar a clientes web por Socket.io
        if (payload.stream === 'console') {
          io.emit('exaroton-console-line', payload.data);
        } else if (payload.stream === 'tick') {
          io.emit('exaroton-tick', payload.data);
        } else if (payload.stream === 'stats') {
          io.emit('exaroton-stats', payload.data);
        } else if (payload.type === 'status') {
          lastExarotonStatus = payload.data;
          io.emit('exaroton-status-update', payload.data);
        }
      } catch (e) {
        // Formato raw
        io.emit('exaroton-console-line', msg.toString());
      }
    });

    exarotonWsClient.on('error', (err) => {
      console.error('[Exaroton WS] Error:', err.message);
    });

    exarotonWsClient.on('close', () => {
      console.log('[Exaroton WS] Conexión cerrada. Reintentando en 10s...');
      setTimeout(() => {
        if (config.serverType === 'exaroton' && config.exarotonToken) {
          connectExarotonWebSocket();
        }
      }, 10000);
    });
  } catch (err) {
    console.error('[Exaroton WS] Fallo inicializando cliente WS:', err.message);
  }
}

// Iniciar conexión inicial si hay credenciales
if (config.exarotonToken && config.exarotonServerId) {
  connectExarotonWebSocket();
}

// ==========================================
// REST API ENDPOINTS
// ==========================================

// 1. Estado de Configuración Pública
app.get('/api/config/public', (req, res) => {
  res.json({
    serverType: config.serverType,
    secondaryServerIp: config.secondaryServerIp,
    isSecondaryBedrock: config.isSecondaryBedrock,
    hasExarotonConfigured: !!(config.exarotonToken && config.exarotonServerId),
    exarotonServerId: config.exarotonServerId ? `${config.exarotonServerId.substring(0, 4)}***` : ''
  });
});

// 2. Telemetría de Jugadores Bedrock
app.get('/api/minecraft/players', (req, res) => {
  res.json({
    count: bedrockPlayers.size,
    players: Array.from(bedrockPlayers.values())
  });
});

app.post('/api/minecraft/telemetry', (req, res) => {
  const data = req.body;
  if (!data) return res.status(400).json({ error: 'Payload vacío' });

  if (data.type === 'telemetry_batch' && Array.isArray(data.players)) {
    data.players.forEach((p) => {
      if (p.gamertag) {
        bedrockPlayers.set(p.gamertag, {
          gamertag: p.gamertag,
          x: Math.round(p.x * 10) / 10,
          y: Math.round(p.y * 10) / 10,
          z: Math.round(p.z * 10) / 10,
          dimension: p.dimension || 'overworld',
          health: p.health || 20,
          lastSeen: Date.now()
        });
      }
    });
    io.emit('bedrock-telemetry-sync', Array.from(bedrockPlayers.values()));
  } else if (data.type === 'player_join') {
    bedrockPlayers.set(data.gamertag, {
      gamertag: data.gamertag,
      x: Math.round((data.x || 0) * 10) / 10,
      y: Math.round((data.y || 0) * 10) / 10,
      z: Math.round((data.z || 0) * 10) / 10,
      dimension: data.dimension || 'overworld',
      health: data.health || 20,
      lastSeen: Date.now()
    });
    io.emit('bedrock-player-joined', data);
    io.emit('bedrock-telemetry-sync', Array.from(bedrockPlayers.values()));
  } else if (data.type === 'player_leave') {
    bedrockPlayers.delete(data.gamertag);
    io.emit('bedrock-player-left', data);
    io.emit('bedrock-telemetry-sync', Array.from(bedrockPlayers.values()));
  }

  res.json({ success: true, count: bedrockPlayers.size });
});

// 3. Consulta de Exaroton Status vía REST API oficial
app.get('/api/exaroton/status', async (req, res) => {
  if (!config.exarotonToken || !config.exarotonServerId) {
    return res.status(400).json({
      error: 'Token o Server ID de Exaroton no configurados en el Panel Admin'
    });
  }

  try {
    const response = await fetch(`https://api.exaroton.com/v1/servers/${config.exarotonServerId}`, {
      headers: {
        Authorization: `Bearer ${config.exarotonToken}`
      }
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ error: `Exaroton API error: ${errText}` });
    }

    const json = await response.json();
    res.json(json);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Acciones de Control Exaroton (Start / Stop / Restart)
app.post('/api/exaroton/action', async (req, res) => {
  const { action } = req.body; // 'start', 'stop', 'restart'
  if (!['start', 'stop', 'restart'].includes(action)) {
    return res.status(400).json({ error: 'Acción no válida' });
  }

  if (!config.exarotonToken || !config.exarotonServerId) {
    return res.status(400).json({ error: 'Exaroton no configurado' });
  }

  try {
    const response = await fetch(`https://api.exaroton.com/v1/servers/${config.exarotonServerId}/${action}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${config.exarotonToken}`
      }
    });

    const json = await response.json();
    res.json(json);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Enviar comando a la consola de Exaroton
app.post('/api/exaroton/command', async (req, res) => {
  const { command } = req.body;
  if (!command) {
    return res.status(400).json({ error: 'Comando requerido' });
  }

  try {
    const response = await fetch(`https://api.exaroton.com/v1/servers/${config.exarotonServerId}/command`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${config.exarotonToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ command })
    });

    const json = await response.json();
    res.json(json);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Obtener Logs de Exaroton
app.get('/api/exaroton/logs', async (req, res) => {
  try {
    const response = await fetch(`https://api.exaroton.com/v1/servers/${config.exarotonServerId}/logs`, {
      headers: {
        Authorization: `Bearer ${config.exarotonToken}`
      }
    });

    const json = await response.json();
    res.json(json);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Servidor Secundario / Aternos (mcsrvstat.us API en tiempo real)
app.get('/api/secondary/status', async (req, res) => {
  const targetIp = req.query.ip || config.secondaryServerIp;
  const isBedrock = req.query.bedrock !== undefined ? req.query.bedrock === 'true' : config.isSecondaryBedrock;

  if (!targetIp) {
    return res.status(400).json({ error: 'IP de servidor secundario no especificada' });
  }

  try {
    const endpoint = isBedrock
      ? `https://api.mcsrvstat.us/bedrock/2/${encodeURIComponent(targetIp)}`
      : `https://api.mcsrvstat.us/2/${encodeURIComponent(targetIp)}`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);

    const response = await fetch(endpoint, { signal: controller.signal });
    clearTimeout(timeout);

    if (!response.ok) {
      return res.status(response.status).json({ error: 'Fallo al consultar mcsrvstat.us' });
    }

    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: `Error conectando a mcsrvstat: ${err.message}` });
  }
});

// 8. Panel de Administración (Protegido por JuancitoChen23)
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  if (password === config.adminSecret) {
    res.json({
      success: true,
      message: 'Acceso autorizado al Panel Admin de CHAUFALAND',
      config: {
        serverType: config.serverType,
        exarotonToken: config.exarotonToken,
        exarotonServerId: config.exarotonServerId,
        secondaryServerIp: config.secondaryServerIp,
        isSecondaryBedrock: config.isSecondaryBedrock
      }
    });
  } else {
    res.status(401).json({ success: false, error: 'Contraseña incorrecta' });
  }
});

app.post('/api/admin/update', (req, res) => {
  const { password, serverType, exarotonToken, exarotonServerId, secondaryServerIp, isSecondaryBedrock } = req.body;

  if (password !== config.adminSecret) {
    return res.status(401).json({ success: false, error: 'Acceso no autorizado' });
  }

  if (serverType) config.serverType = serverType;
  if (exarotonToken !== undefined) config.exarotonToken = exarotonToken.trim();
  if (exarotonServerId !== undefined) config.exarotonServerId = exarotonServerId.trim();
  if (secondaryServerIp !== undefined) config.secondaryServerIp = secondaryServerIp.trim();
  if (isSecondaryBedrock !== undefined) config.isSecondaryBedrock = !!isSecondaryBedrock;

  console.log('[Admin] Configuración actualizada por el administrador');

  // Reconectar Exaroton si cambiaron credenciales
  if (config.serverType === 'exaroton' && config.exarotonToken && config.exarotonServerId) {
    connectExarotonWebSocket();
  }

  res.json({
    success: true,
    message: 'Configuración guardada correctamente',
    config: {
      serverType: config.serverType,
      exarotonToken: config.exarotonToken,
      exarotonServerId: config.exarotonServerId,
      secondaryServerIp: config.secondaryServerIp,
      isSecondaryBedrock: config.isSecondaryBedrock
    }
  });
});

// Iniciar servidor
server.listen(config.port, () => {
  console.log('====================================================');
  console.log(` ⛏️  CHAUFALAND Servidor de Voz y Control Iniciado`);
  console.log(` 🌐 Web & API: http://localhost:${config.port}`);
  console.log(` 🔌 WebSocket Bedrock Bridge: ws://localhost:${config.port}/ws/minecraft`);
  console.log(` 🔑 Clave secreta Admin: ${config.adminSecret}`);
  console.log('====================================================');
});
