import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-5.5";

app.disable("x-powered-by");
app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY), model: MODEL });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "The server owner has not configured OPENAI_API_KEY yet." });
    }
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Please enter a message." });
    if (message.length > 6000) return res.status(413).json({ error: "Message is too long. Please shorten it." });

    const language = req.body?.language === "ha" ? "Hausa" : "English";
    const history = Array.isArray(req.body?.history) ? req.body.history : [];
    const safeHistory = history.slice(-20).filter(m =>
      m && ["user", "assistant"].includes(m.role) &&
      typeof m.content === "string" && m.content.length <= 6000
    );
    const input = [
      ...safeHistory.map(m => ({ role: m.role, content: m.content })),
      { role: "user", content: message }
    ];
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY, timeout: 60000, maxRetries: 1 });
    const response = await client.responses.create({
      model: MODEL,
      instructions: [
        "You are Mataimaki Assistant, a friendly, capable general-purpose AI assistant.",
        "Answer the user's latest message in its language; support English and natural Hausa.",
        "Be accurate, clear, helpful, and honest when uncertain. Use context from the conversation.",
        "Use step-by-step instructions when useful. Never ask for passwords, PINs, or card details.",
        "Do not claim to have performed an action you did not perform."
      ].join(" "),
      input,
      max_output_tokens: 1200
    });
    const reply = (response.output_text || "").trim();
    if (!reply) return res.status(502).json({ error: "The AI returned no text. Please try again." });
    res.json({ reply });
  } catch (err) {
    console.error("AI request failed:", err?.status || "", err?.message || err);
    const status = err?.status === 401 ? 502 : 502;
    let message = "The AI service request failed. Check the API key, model name, internet connection, and API account access.";
    if (err?.status === 401) message = "The API key was rejected. The server owner should check it in the hosting environment.";
    if (err?.status === 429) message = "The AI API limit or available balance may have been reached. Check the API account usage and billing.";
    res.status(status).json({ error: message });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Mataimaki Assistant listening on port ${PORT}`));
