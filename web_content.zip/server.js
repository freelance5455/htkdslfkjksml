import express from "express";

const app = express();
const PORT = process.env.PORT || 3000;
const OLLAMA_API_KEY = process.env.OLLAMA_API_KEY;

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

app.post("/api/chat", async (req, res) => {
  if (!OLLAMA_API_KEY) {
    return res.status(500).json({ error: "Серверде OLLAMA_API_KEY орнатылмаған." });
  }

  const { messages, model = "gemma4:31b" } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "messages массиві қажет." });
  }

  try {
    const upstream = await fetch("https://ollama.com/api/chat", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OLLAMA_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ model, messages, stream: false })
    });

    const raw = await upstream.text();
    res.status(upstream.status);
    res.type("application/json").send(raw);
  } catch (error) {
    res.status(502).json({ error: "Ollama серверіне қосылу сәтсіз: " + error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Mini GPT: http://localhost:${PORT}`);
});
