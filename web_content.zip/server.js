const express = require("express");
const dotenv = require("dotenv");
const path = require("path");
const { GoogleGenerativeAI } = require("@google/generative-ai");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
    console.error("ERROR: GEMINI_API_KEY is missing from .env");
    process.exit(1);
}

const genAI = new GoogleGenerativeAI(apiKey);

const SYSTEM_PROMPT = `
You are MineAI, a specialized AI assistant focused exclusively on Minecraft.

Your expertise includes:

- Minecraft Java Edition
- Minecraft Bedrock Edition
- Minecraft commands
- Minecraft mechanics
- Blocks
- Items
- Crafting
- Enchantments
- Potions
- Mobs
- Villagers
- Biomes
- Structures
- Redstone
- Farms
- Survival
- Building
- Minecraft servers
- Paper
- Spigot
- Bukkit
- Skript
- Plugins
- Datapacks
- Resource packs
- Mods

IMPORTANT RULES:

1. Only answer questions related to Minecraft.

2. If the user asks something unrelated to Minecraft,
   politely explain that MineAI specializes in Minecraft.

3. Never invent Minecraft commands, items, blocks, mechanics,
   plugin features, or game features.

4. If Java Edition and Bedrock Edition behave differently,
   clearly explain the difference.

5. If the Minecraft version matters, mention the version
   or ask the user which version they are using.

6. When providing commands, configuration, Skript,
   datapacks, or other code, use Markdown code blocks.

7. Explain what commands or code do.

8. For Paper, Spigot, Bukkit, Skript, plugins, and mods,
   remember that syntax and features can depend on the version.

9. Do not claim to be an official Minecraft or Mojang service.

10. Keep answers useful, clear, and reasonably concise.

11. If the user asks for a Minecraft build, farm, command,
    plugin, Skript, or configuration, provide practical steps.

12. If you are uncertain about a Minecraft-specific fact,
    clearly say that the information may depend on the version
    instead of confidently inventing an answer.
`;


app.use(express.json({
    limit: "1mb"
}));

app.use(express.static(
    path.join(__dirname, "public")
));


app.post("/api/chat", async (req, res) => {

    try {

        const messages = req.body.messages;

        if (!Array.isArray(messages) || messages.length === 0) {

            return res.status(400).json({
                error: "No messages were provided."
            });

        }


        const cleanedMessages = messages
            .filter(message =>
                message &&
                typeof message.text === "string" &&
                message.text.trim().length > 0
            )
            .map(message => ({
                role:
                    message.role === "model"
                        ? "model"
                        : "user",

                parts: [
                    {
                        text: message.text.trim()
                    }
                ]
            }));


        if (cleanedMessages.length === 0) {

            return res.status(400).json({
                error: "The message is empty."
            });

        }


        const lastMessage =
            cleanedMessages[cleanedMessages.length - 1];


        const history =
            cleanedMessages.slice(0, -1);


        const model =
            genAI.getGenerativeModel({

                model: "gemini-2.5-flash",

                systemInstruction: SYSTEM_PROMPT,

                generationConfig: {
                    temperature: 0.35,
                    topP: 0.9,
                    maxOutputTokens: 2048
                }

            });


        const chat =
            model.startChat({
                history
            });


        const result =
            await chat.sendMessage(
                lastMessage.parts[0].text
            );


        const response =
            result.response;


        const reply =
            response.text();


        if (!reply) {

            return res.status(500).json({
                error: "Gemini returned an empty response."
            });

        }


        res.json({
            reply
        });


    } catch (error) {

        console.error("Gemini error:");
        console.error(error);


        let message =
            "Gemini could not process the request.";


        if (
            error &&
            typeof error.message === "string"
        ) {

            message = error.message;

        }


        res.status(500).json({
            error: message
        });

    }

});


app.get("*", (req, res) => {

    res.sendFile(
        path.join(
            __dirname,
            "public",
            "index.html"
        )
    );

});


app.listen(PORT, () => {

    console.log("");
    console.log("================================");
    console.log("        MineAI is running");
    console.log("================================");
    console.log("");
    console.log(`Local: http://localhost:${PORT}`);
    console.log("");
});

