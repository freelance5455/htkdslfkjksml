import express from "express";
import dotenv from "dotenv";
import rateLimit from "express-rate-limit";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY;

app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 25 }));

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: "API Key belum dipasang di server." });
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    const history = Array.isArray(req.body?.history) ? req.body.history : [];
    if (!message) return res.status(400).json({ error: "Pesan masih kosong." });
    if (message.length > 6000) return res.status(413).json({ error: "Pesan terlalu panjang." });

    const safeHistory = history.slice(-10).filter(m =>
      m && ["user", "assistant"].includes(m.role) &&
      typeof m.content === "string" && m.content.length <= 6000
    );
    const input = [
      ...safeHistory.map(m => ({ role: m.role, content: m.content })),
      { role: "user", content: message }
    ];

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions: "Kamu adalah NexusAI, asisten AI yang ramah, jelas, dan aman. Balas dalam bahasa pengguna. Gunakan bahasa Indonesia jika pengguna memakai bahasa Indonesia.",
        input,
        max_output_tokens: 1200
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: data?.error?.message || "Layanan AI gagal merespons." });
    }
    const answer = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n").trim();
    res.json({ answer: answer || "AI belum memberikan jawaban. Coba lagi." });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Server bermasalah. Coba lagi nanti." });
  }
});

app.listen(PORT, "0.0.0.0", () => console.log(`NexusAI aktif di port ${PORT}`));
