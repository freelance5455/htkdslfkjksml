import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import rateLimit from "express-rate-limit";
dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
if (!process.env.OPENAI_API_KEY) {
  console.error("ERRO: configure OPENAI_API_KEY nas variáveis de ambiente.");
}
app.use(cors({
  origin: process.env.ALLOWED_ORIGIN ? process.env.ALLOWED_ORIGIN.split(",").map(x => x.trim()) : true
}));
app.use(express.json({ limit: "20kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));

app.get("/health", (_req, res) => res.json({ status: "ok", service: "CYBERGUARD AI" }));

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Envie uma pergunta." });
    if (message.length > 4000) return res.status(413).json({ error: "A mensagem excede 4.000 caracteres." });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "A API ainda não foi configurada no servidor." });

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "Você é a Cyber AI, assistente educativa de cibersegurança. Responda em português claro. Ajude com defesa, privacidade, prevenção de golpes, análise educativa de mensagens e segurança de sistemas autorizados. Não instrua invasão, roubo de credenciais, malware, evasão ou acesso não autorizado. Nunca afirme que um link, arquivo ou dispositivo foi realmente verificado se isso não ocorreu. Avise que análises textuais são indicativas e que o usuário não deve compartilhar senhas, códigos ou dados pessoais.",
        input: message,
        max_output_tokens: 700
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("OpenAI API error:", data?.error?.message || upstream.status);
      return res.status(502).json({ error: "A IA não respondeu. Verifique a configuração e os limites da API." });
    }
    const reply = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n").trim();
    return res.json({ reply: reply || "Não consegui gerar uma resposta. Tente novamente." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Erro interno no servidor." });
  }
});

app.listen(port, () => console.log(`CYBERGUARD AI backend ativo na porta ${port}`));
