require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/search", async (req, res) => {
  const query = String(req.body?.query || "").trim();
  if (!query) return res.status(400).json({ error: "Please enter something to search." });
  if (!process.env.GOOGLE_API_KEY || !process.env.GOOGLE_CX || !process.env.GEMINI_API_KEY) {
    return res.status(503).json({
      error: "App setup is incomplete. Add Google API key, Search Engine ID, and Gemini API key in the .env file."
    });
  }

  try {
    const googleUrl = new URL("https://www.googleapis.com/customsearch/v1");
    googleUrl.search = new URLSearchParams({
      key: process.env.GOOGLE_API_KEY,
      cx: process.env.GOOGLE_CX,
      q: query,
      num: "8"
    }).toString();

    const googleResponse = await fetch(googleUrl);
    const googleData = await googleResponse.json();
    if (!googleResponse.ok) {
      throw new Error(googleData.error?.message || "Google search request failed.");
    }

    const results = (googleData.items || []).map((item, index) => ({
      number: index + 1,
      title: item.title || "Untitled",
      link: item.link,
      snippet: item.snippet || ""
    }));

    const context = results.map(r =>
      `[${r.number}] ${r.title}\nURL: ${r.link}\nDetails: ${r.snippet}`
    ).join("\n\n");

    const prompt = `You are a helpful search assistant. Answer the user's question using the Google search results below. Be clear and useful. If the results do not provide enough information, say so instead of inventing facts. Mention source numbers like [1] near relevant claims. Answer in the same language as the user's question.\n\nUser question: ${query}\n\nGoogle search results:\n${context || "No results were found."}`;

    const aiResponse = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(process.env.GEMINI_API_KEY),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.3, maxOutputTokens: 1200 }
        })
      }
    );
    const aiData = await aiResponse.json();
    if (!aiResponse.ok) {
      throw new Error(aiData.error?.message || "AI answer request failed.");
    }

    const answer = aiData.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("\n").trim()
      || "I could not generate an answer. Please try another search.";

    res.json({ query, answer, results });
  } catch (error) {
    res.status(500).json({ error: error.message || "Something went wrong." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Duniya Search is running at http://localhost:${port}`));