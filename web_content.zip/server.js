
const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(__dirname));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "home.html"));
});

const players = {};

io.on("connection", (socket) => {
  players[socket.id] = {
    x: 0, y: 0, z: 5,
    rotation: 0,
    name: "Player"
  };

  socket.emit("players:init", players);
  socket.broadcast.emit("player:join", {
    id: socket.id,
    player: players[socket.id]
  });

  socket.on("player:move", (data) => {
    if (!data || !players[socket.id]) return;

    const x = Number(data.x);
    const y = Number(data.y);
    const z = Number(data.z);
    const rotation = Number(data.rotation);

    if (![x, y, z, rotation].every(Number.isFinite)) return;

    players[socket.id] = {
      x: Math.max(-100, Math.min(100, x)),
      y: Math.max(0, Math.min(20, y)),
      z: Math.max(-100, Math.min(100, z)),
      rotation,
      name: "Player"
    };

    socket.broadcast.emit("player:move", {
      id: socket.id,
      player: players[socket.id]
    });
  });

  socket.on("chat:send", (message) => {
    if (typeof message !== "string") return;

    const text = message.trim().slice(0, 120);
    if (!text) return;

    io.emit("chat:message", {
      name: "Player",
      text
    });
  });

  socket.on("disconnect", () => {
    delete players[socket.id];
    io.emit("player:leave", socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, "0.0.0.0", () => {
  console.log("Zyvo server running on port " + PORT);
});
