const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;

function fetchText(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; NUBEX-AI-Sales/21.0; +https://nubexsupplies.com)"
      }
    }, res => {
      let data = "";
      res.setEncoding("utf8");
      res.on("data", c => data += c);
      res.on("end", () => res.statusCode >= 200 && res.statusCode < 400
        ? resolve(data) : reject(new Error("Search provider HTTP " + res.statusCode)));
    });
    req.on("error", reject);
    req.setTimeout(12000, () => { req.destroy(); reject(new Error("Search timeout")); });
  });
}

function stripTags(s) {
  return s.replace(/<[^>]*>/g, " ")
    .replace(/&amp;/g, "&").replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/\s+/g, " ").trim();
}

function decodeHtml(s) {
  return stripTags(String(s || ""))
    .replace(/&#x2F;/gi, "/")
    .replace(/&#x3A;/gi, ":")
    .replace(/&#x26;/gi, "&")
    .replace(/&nbsp;/gi, " ");
}

function parseDDG(html) {
  const out = [];
  // DuckDuckGo HTML has changed its markup several times. Extract result links
  // first, then use the surrounding result block for title/snippet.
  const linkRe = /<a[^>]+class=["'][^"']*result__a[^"']*["'][^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = linkRe.exec(html)) && out.length < 20) {
    let url = m[1];
    if (url.startsWith("//")) url = "https:" + url;
    const title = decodeHtml(m[2]);
    const block = html.slice(Math.max(0, m.index - 200), Math.min(html.length, linkRe.lastIndex + 1800));
    const sm = block.match(/class=["'][^"']*result__snippet[^"']*["'][^>]*>([\s\S]*?)<\/(?:a|div)>/i);
    const snippet = sm ? decodeHtml(sm[1]) : "";
    if (url && title && !/duckduckgo\.com\/y\?/i.test(url)) {
      out.push({title, url, snippet});
    }
  }
  return out;
}

function parseBing(html) {
  const out = [];
  const linkRe = /<li[^>]+class=["'][^"']*b_algo[^"']*["'][\s\S]*?<h2[^>]*>\s*<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<p[^>]*>([\s\S]*?)<\/p>)?/gi;
  let m;
  while ((m = linkRe.exec(html)) && out.length < 20) {
    const url = m[1], title = decodeHtml(m[2]), snippet = decodeHtml(m[3] || "");
    if (url && title) out.push({title, url, snippet});
  }
  return out;
}

function parseGenericSearch(html) {
  const out = [];
  const re = /<a[^>]+href=["'](https?:\/\/[^"'<> ]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) && out.length < 30) {
    const url = m[1];
    const title = decodeHtml(m[2]);
    if (!title || title.length < 3) continue;
    if (/duckduckgo\.com|bing\.com|google\.com|javascript:/i.test(url)) continue;
    out.push({title, url, snippet:""});
  }
  return out;
}

async function webSearch(q) {
  const ddg = "https://html.duckduckgo.com/html/?q=" + encodeURIComponent(q);
  try {
    const html = await fetchText(ddg);
    let results = parseDDG(html);
    if (!results.length) results = parseGenericSearch(html);
    if (results.length) return {provider:"DuckDuckGo", results};
  } catch {}
  const bing = "https://www.bing.com/search?q=" + encodeURIComponent(q);
  const html = await fetchText(bing);
  let results = parseBing(html);
  if (!results.length) results = parseGenericSearch(html);
  return {provider:"Bing", results};
}

function isUsefulLead(r) {
  const t = (r.title + " " + r.snippet + " " + r.url).toLowerCase();
  const bad = [
    "wikipedia", "krieg", "conflict", "news", "weather", "map", "government",
    "embassy", "un.org", "reliefweb", "britannica", "generic", "jobs", "vacancy",
    "hotel", "flight", "travel", "university", "school", "hospital", "bank"
  ];
  if (bad.some(k => t.includes(k))) return false;
  const food = /food|factory|manufacturer|manufactur|juice|beverage|dairy|sauce|ketchup|tomato paste|ice cream|biscuit|bakery|chocolate|confection|tahini|jam|pasta|flour|snack|milk|yogurt|مطبخ|غذ|مصنع|عصائر|مشروبات|ألبان|صلصة|كاتشب|حلويات|بسكويت|شوكولاتة|مربى|طحينة|مكرونة|دقيق|آيس كريم/.test(t);
  const sudan = /sudan|khartoum|omdurman|bahri|soba|port sudan|السودان|الخرطوم|بحري|أم درمان|بورتسودان/.test(t);
  return food && sudan;
}

function score(r, product, sector) {
  const t = (r.title + " " + r.snippet + " " + r.url).toLowerCase();
  let s = 25;
  const keys = [
    ["sauce",22],["ketchup",20],["tomato",18],["juice",17],["beverage",14],
    ["dairy",16],["ice cream",16],["bakery",13],["biscuit",13],["chocolate",13],
    ["confection",13],["tahini",12],["jam",12],["pasta",10],["flour",10],
    ["food",9],["factory",9],["manufactur",9],["sudan",10],["khartoum",7],
    ["omdurman",7],["bahri",7],["port sudan",7],
    ["مصنع",12],["غذ",10],["عصائر",14],["مشروبات",12],["ألبان",14],["صلصة",18],
    ["كاتشب",18],["حلويات",14],["بسكويت",13],["شوكولاتة",13],["مربى",12],["طحينة",12]
  ];
  for (const [k,v] of keys) if (t.includes(k)) s += v;
  if (/cmc|carboxy|cellulose/.test(product.toLowerCase()) && /sauce|juice|dairy|ice cream|bakery|biscuit|food|ketchup|jam|confection|مصنع|صلصة|عصائر|ألبان/.test(t)) s += 15;
  if (sector && t.includes(sector.toLowerCase())) s += 5;
  return Math.min(99,s);
}

const CURATED_LEADS = [
  {title:"Saeed Food Factory", url:"https://www.saeedgroup.com/businesses", snippet:"Tomato paste, juices and jams manufacturer in Sudan."},
  {title:"Moawia Elberier Food & Beverage Group", url:"https://moawiaelberier.com/en/food-and-beverage-group/", snippet:"Sudanese food and beverage group: dairy, juices, tomato paste, biscuits and confectionery."},
  {title:"DAL Food", url:"https://www.dalgroup.com/contact/", snippet:"Major Sudanese food group with dairy, flour, pasta and beverage businesses."},
  {title:"Al Wabil", url:"https://www.alwabill.com/", snippet:"Sudanese food manufacturer: water, juices, biscuits, cakes, chocolate, ketchup and other FMCG."},
  {title:"Abu Harira", url:"https://abuharira.com/", snippet:"Sudanese food group producing tahini, sweets and juices."},
  {title:"Arcad Foods", url:"https://madeinsudan.org/food-beverages/", snippet:"Packaged food producer including peanut butter and jams."},
  {title:"Elnasr Industrial Trading Co.", url:"https://elnasrltd.com/ar/من-نحن/", snippet:"Sudanese food and ingredient-related industrial/trading company."},
  {title:"مصنع قصر الغذاء", url:"https://scia-sudan.com/IndustrialDirectory/Details/9b24fd33-43bd-4b48-8765-7f73f68e4d09", snippet:"Sauces and ketchup manufacturer listed in Sudan Industrial Chambers directory."},
  {title:"مصنع الندى", url:"https://scia-sudan.com/IndustrialDirectory/Details/9b24fd33-43bd-4b48-8765-7f73f68e4d09", snippet:"Sauces, ketchup and hot pepper manufacturer listed in Sudan Industrial Chambers directory."},
  {title:"مصنع نايس للآيسكريم", url:"https://scia-sudan.com/IndustrialDirectory/Details/9b24fd33-43bd-4b48-8765-7f73f68e4d09", snippet:"Ice cream manufacturer listed in Sudan Industrial Chambers food directory."},
  {title:"مصنع هوب للحلويات والشوكولاتة", url:"https://scia-sudan.com/IndustrialDirectory/Details/9b24fd33-43bd-4b48-8765-7f73f68e4d09", snippet:"Sweets and chocolate manufacturer listed in Sudan Industrial Chambers food directory."},
  {title:"مصنع نايل فود", url:"https://scia-sudan.com/IndustrialDirectory/Details/9b24fd33-43bd-4b48-8765-7f73f68e4d09", snippet:"Sweets, biscuits and pastries manufacturer listed in Sudan Industrial Chambers directory."}
];


function normalizePhone(raw) {
  let x=String(raw||'').replace(/[^\d+]/g,'');
  if(/^0\d{9}$/.test(x)) x='+249'+x.slice(1);
  return x;
}

// Contacts explicitly verified from the companies' own public websites.
// Search-engine snippets are NEVER allowed to override these values.
const VERIFIED_CONTACTS = [
  {names:['DAL Food','DAL Group'], phone:'+249185444130', email:'info@dalgroup.com', source:'https://www.dalgroup.com/contact/'},
  {names:['Saeed Food Factory','مصنع سعيد للمواد الغذائية','Saeed Food'], phone:'+249185314319', email:'info@saeedgroup.com', source:'https://www.saeedgroup.com/contacts'},
  {names:['Moawia Elberier Food & Beverage Group','مجموعة معاوية البرير','Moawia Elberier'], phone:'+249912323700', email:'info@moawiaelberier.com', source:'https://moawiaelberier.com/en/food-and-beverage-group/'},
  {names:['Al Wabil','مصنع الوابل'], phone:'+249912319085', email:'elbaraa@alwabill.com', source:'https://www.alwabill.com/'},
  {names:['Abu Harira','أبو حريرة'], phone:'+249912335219', email:'info@abuharira.com', source:'https://abuharira.com/contact-us/'},
  {names:['Arcad Foods','Arcad Food'], phone:'+249906006900', email:'info@arcadfood.com', source:'https://madeinsudan.org/food-beverages/'},
  {names:['Elnasr Industrial Trading','Elnasr Industrial Trading Co.'], phone:'+249185310705', email:'sales@elnasrltd.com', source:'https://elnasrltd.com/ar/من-نحن/'}
];

function verifiedContactFor(name) {
  const n=String(name||'').toLowerCase();
  return VERIFIED_CONTACTS.find(x=>x.names.some(k=>n===k.toLowerCase() || n.includes(k.toLowerCase()) || k.toLowerCase().includes(n))) || null;
}

function extractContacts(text) {
  const raw = String(text || '');
  const emails = [...raw.matchAll(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig)].map(m=>m[0]);
  const phones = [...raw.matchAll(/(?:\+249\s?\d{2,3}[\s-]?\d{3}[\s-]?\d{3,4}|0\d{9})/g)].map(m=>normalizePhone(m[0]));
  return {email:[...new Set(emails)].slice(0,3), phone:[...new Set(phones)].slice(0,3)};
}

async function fetchPageContacts(url){
  if(!url || !/^https?:\/\//i.test(url)) return {phone:'',email:'',website:'',contactStatus:'unverified'};
  try{
    const html=await fetchText(url);
    const text=decodeHtml(html.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' '));
    const c=extractContacts(text);
    return {phone:c.phone[0]||'',email:c.email[0]||'',website:url,contactStatus:(c.phone.length||c.email.length)?'verified':'unverified'};
  }catch{return {phone:'',email:'',website:url,contactStatus:'unverified'};}
}

function cleanContact(x) {
  const c=extractContacts((x.title||'')+' '+(x.snippet||'')+' '+(x.url||''));
  return {...x, email:c.email[0]||'', phone:c.phone[0]||'', contactStatus:'unverified'};
}

function officialDomainLooksRelevant(url,name){
  try{
    const host=new URL(url).hostname.toLowerCase().replace(/^www\./,'');
    if(/facebook|linkedin|instagram|youtube|directory|madeinsudan|scia-sudan|google|bing|duckduckgo/.test(host)) return false;
    const tokens=String(name||'').toLowerCase().split(/[^a-z0-9\u0600-\u06ff]+/).filter(t=>t.length>=4);
    return tokens.some(t=>host.includes(t));
  }catch{return false;}
}

async function enrichLead(lead) {
  const name = String(lead.title||'').replace(/\s+/g,' ').trim();
  const verified = verifiedContactFor(name);
  if(verified){
    return {...lead,phone:verified.phone,email:verified.email,website:verified.source,contactSource:verified.source,contactProvider:'official company website',contactStatus:'verified'};
  }
  const queries = [
    `"${name}" Sudan official website`,
    `"${name}" Sudan contact phone email`
  ];
  const found=[];
  for (const q of queries) {
    try {
      const x=await webSearch(q);
      for (const r of x.results) found.push({...r,provider:x.provider});
    } catch {}
  }
  const official = found.find(r => officialDomainLooksRelevant(r.url,name));
  const page=await fetchPageContacts(official ? official.url : lead.url);
  // Important: contact numbers/emails from search snippets are not treated as verified.
  return {
    ...lead,
    phone: page.phone || '',
    email: page.email || '',
    website: official ? official.url : (page.website||''),
    contactSource: page.phone||page.email ? (official ? official.url : (page.website||lead.url)) : '',
    contactProvider: page.phone||page.email ? 'official company website' : '',
    contactStatus: page.phone||page.email ? 'verified' : 'unverified'
  };
}

async function enrichLeads(leads) {
  const top = leads.slice(0,10);
  const enriched = await Promise.all(top.map(enrichLead));
  const byTitle=new Map(enriched.map(x=>[x.title,x]));
  return leads.map(x=>byTitle.get(x.title)||x);
}

async function runAgent(body) {
  const product = body.product || "EAGLE CMC FH5000";
  const sector = body.sector || "مصانع الأغذية والمشروبات";
  const queries = [
    `Sudan CMC food factory sauce juice dairy manufacturer contact`,
    `Sudan food factory ketchup tomato paste juice dairy biscuit chocolate`,
    `site:scia-sudan.com/IndustrialDirectory/Details Sudan food factory sauce ketchup juice dairy`,
    `Sudan food manufacturer "contact" Khartoum Omdurman`
  ];
  const all = [];
  const seen = new Set();
  for (const q of queries) {
    try {
      const x = await webSearch(q);
      for (const r of x.results) {
        const key = r.url.split("#")[0];
        if (!seen.has(key) && isUsefulLead(r)) { seen.add(key); all.push({...r, provider:x.provider}); }
      }
    } catch {}
  }
  if (!all.length) {
    for (const r of CURATED_LEADS) {
      const key = r.url + "|" + r.title;
      if (!seen.has(key)) {
        seen.add(key);
        all.push({...r, provider:"NUBEX curated directory"});
      }
    }
  }
  const ranked = all.map(r => ({...r, score:score(r,product,sector)}))
    .sort((a,b)=>b.score-a.score).slice(0,20);
  return {ok:true, product, sector, searched:queries.length, count:ranked.length, results:ranked, fallback: all.some(r=>r.provider==="NUBEX curated directory")};
}

function send(res, code, data, type="application/json") {
  res.writeHead(code, {"Content-Type": type, "Access-Control-Allow-Origin":"*"});
  res.end(type==="application/json" ? JSON.stringify(data) : data);
}

const server = http.createServer(async (req,res)=>{
  try {
    if (req.method==="OPTIONS") return send(res,204,{});
    if (req.url==="/health") return send(res,200,{ok:true,version:"25",agent:"live-search-contact-verification"});
    if (req.method==="POST" && req.url==="/api/enrich") {
      let raw=""; req.on("data",c=>raw+=c);
      req.on("end",async()=>{
        try {
          const body=JSON.parse(raw||"{}");
          const leads=Array.isArray(body.leads)?body.leads.slice(0,12):[];
          const out=await enrichLeads(leads);
          send(res,200,{ok:true,results:out});
        } catch(e){ send(res,500,{ok:false,error:e.message}); }
      });
      return;
    }
    if (req.method==="POST" && req.url==="/api/agent") {
      let raw=""; req.on("data",c=>raw+=c);
      req.on("end",async()=>{
        try { const body=JSON.parse(raw||"{}"); send(res,200,await runAgent(body)); }
        catch(e){ send(res,500,{ok:false,error:e.message}); }
      });
      return;
    }
    let p = new URL(req.url, `http://${req.headers.host}`).pathname;
    if (p==="/") p="/index.html";
    const file=path.join(ROOT,p.replace(/^\/+/,""));
    if (!file.startsWith(ROOT) || !fs.existsSync(file)) return send(res,404,{error:"Not found"});
    const ext=path.extname(file);
    const types={".html":"text/html; charset=utf-8",".js":"application/javascript",".css":"text/css",".json":"application/json",".svg":"image/svg+xml",".png":"image/png"};
    send(res,200,fs.readFileSync(file),types[ext]||"application/octet-stream");
  } catch(e){ send(res,500,{error:e.message}); }
});
server.listen(PORT,()=>console.log(`NUBEX AI v25 listening on ${PORT}`));
