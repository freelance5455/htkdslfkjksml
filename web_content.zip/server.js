// ============================================
// GERÇEK KRİPTO TRADING BOT - BACKEND (Node.js)
// ============================================
// npm install express cors axios dotenv ws

const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// ============================================
// BINANCE API CONFIGURATION
// ============================================
const BINANCE_API = 'https://api.binance.com/api/v3';
const BINANCE_WS = 'wss://stream.binance.com:9443/ws';

// API Keys (İÇİ ASLA EXPOSE ETMEYIN - .env dosyasından yükle)
const API_KEY = process.env.BINANCE_API_KEY;
const API_SECRET = process.env.BINANCE_API_SECRET;

// ============================================
// TİCARET VERİTABANI (In-Memory, üretim için DB kullan)
// ============================================
const tradingState = {
    balance: 1000,
    openPositions: [],
    closedTrades: [],
    totalTrades: 0
};

// ============================================
// BINANCE API ENDPOINTS
// ============================================

// 1. Gerçek Fiyat Alma
app.get('/api/price/:symbol', async (req, res) => {
    try {
        const { symbol } = req.params;
        const response = await axios.get(`${BINANCE_API}/ticker/price`, {
            params: { symbol: symbol.toUpperCase() }
        });
        res.json({
            success: true,
            symbol: response.data.symbol,
            price: parseFloat(response.data.price),
            timestamp: Date.now()
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// 2. 24 Saatlik Veriler
app.get('/api/ticker24h/:symbol', async (req, res) => {
    try {
        const { symbol } = req.params;
        const response = await axios.get(`${BINANCE_API}/ticker/24hr`, {
            params: { symbol: symbol.toUpperCase() }
        });
        res.json({
            success: true,
            symbol: response.data.symbol,
            price: parseFloat(response.data.lastPrice),
            priceChange: parseFloat(response.data.priceChange),
            priceChangePercent: parseFloat(response.data.priceChangePercent),
            highPrice: parseFloat(response.data.highPrice),
            lowPrice: parseFloat(response.data.lowPrice),
            volume: parseFloat(response.data.volume)
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// 3. Mum Verileri (Klines) - Grafik için
app.get('/api/klines/:symbol', async (req, res) => {
    try {
        const { symbol } = req.params;
        const { interval = '1h', limit = 30 } = req.query;

        const response = await axios.get(`${BINANCE_API}/klines`, {
            params: {
                symbol: symbol.toUpperCase(),
                interval: interval,
                limit: limit
            }
        });

        const klines = response.data.map(candle => ({
            time: new Date(candle[0]),
            open: parseFloat(candle[1]),
            high: parseFloat(candle[2]),
            low: parseFloat(candle[3]),
            close: parseFloat(candle[4]),
            volume: parseFloat(candle[7])
        }));

        res.json({ success: true, klines });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============================================
// TİCARET ENDPOINTS
// ============================================

// Bot Status
app.get('/api/bot/status', (req, res) => {
    const totalPnL = tradingState.openPositions.reduce((sum, pos) => sum + pos.pnl, 0);
    
    res.json({
        success: true,
        balance: tradingState.balance,
        totalPnL: totalPnL,
        openPositions: tradingState.openPositions.length,
        closedTrades: tradingState.closedTrades.length,
        totalTrades: tradingState.totalTrades
    });
});

// Açık Pozisyonlar
app.get('/api/bot/positions', (req, res) => {
    res.json({
        success: true,
        positions: tradingState.openPositions
    });
});

// Pozisyon Açma (BUY)
app.post('/api/bot/open-position', async (req, res) => {
    try {
        const { symbol, quantity } = req.body;

        if (!symbol || !quantity) {
            return res.status(400).json({ success: false, error: 'Missing symbol or quantity' });
        }

        // Gerçek fiyat al
        const priceRes = await axios.get(`${BINANCE_API}/ticker/price`, {
            params: { symbol: symbol.toUpperCase() }
        });

        const entryPrice = parseFloat(priceRes.data.price);
        const cost = entryPrice * quantity;

        if (cost > tradingState.balance) {
            return res.status(400).json({ success: false, error: 'Insufficient balance' });
        }

        const newPosition = {
            id: Date.now(),
            symbol: symbol.toUpperCase(),
            quantity: quantity,
            entryPrice: entryPrice,
            currentPrice: entryPrice,
            pnl: 0,
            openTime: new Date(),
            status: 'OPEN'
        };

        tradingState.openPositions.push(newPosition);
        tradingState.balance -= cost;

        res.json({
            success: true,
            message: `Position opened: ${symbol} x ${quantity} @ $${entryPrice.toFixed(2)}`,
            position: newPosition,
            newBalance: tradingState.balance
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Pozisyon Kapatma (SELL)
app.post('/api/bot/close-position', async (req, res) => {
    try {
        const { positionId } = req.body;

        const posIndex = tradingState.openPositions.findIndex(p => p.id == positionId);
        if (posIndex === -1) {
            return res.status(404).json({ success: false, error: 'Position not found' });
        }

        const position = tradingState.openPositions[posIndex];

        // Kapanış fiyatını al
        const priceRes = await axios.get(`${BINANCE_API}/ticker/price`, {
            params: { symbol: position.symbol }
        });

        const exitPrice = parseFloat(priceRes.data.price);
        const pnl = (exitPrice - position.entryPrice) * position.quantity;

        position.exitPrice = exitPrice;
        position.pnl = pnl;
        position.closeTime = new Date();
        position.status = 'CLOSED';

        tradingState.balance += (position.quantity * exitPrice);
        tradingState.closedTrades.push(position);
        tradingState.openPositions.splice(posIndex, 1);
        tradingState.totalTrades++;

        res.json({
            success: true,
            message: `Position closed: ${position.symbol} PnL: $${pnl.toFixed(2)}`,
            position: position,
            newBalance: tradingState.balance
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============================================
// OTOMATİK TİCARET MANTIGI (Basit örnek)
// ============================================

async function runAutoTrading() {
    try {
        const coins = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT'];

        for (const coin of coins) {
            // Mevcut fiyat
            const priceRes = await axios.get(`${BINANCE_API}/ticker/price`, {
                params: { symbol: coin }
            });
            const currentPrice = parseFloat(priceRes.data.price);

            // Açık pozisyonları kontrol et
            const openPos = tradingState.openPositions.find(p => p.symbol === coin);

            if (openPos) {
                openPos.currentPrice = currentPrice;
                openPos.pnl = (currentPrice - openPos.entryPrice) * openPos.quantity;

                // Stop-Loss: -2%
                const stopLossPercent = ((currentPrice - openPos.entryPrice) / openPos.entryPrice) * 100;
                if (stopLossPercent <= -2) {
                    console.log(`🛡️ STOP LOSS: ${coin} kapalı`);
                    // Position kapatma kodu
                }

                // Take Profit: +5%
                if (stopLossPercent >= 5) {
                    console.log(`💰 TAKE PROFIT: ${coin} kapalı`);
                    // Position kapatma kodu
                }
            } else if (Math.random() > 0.7) { // %30 şansla pozisyon aç
                console.log(`📈 Yeni pozisyon: ${coin} @ $${currentPrice}`);
                // Pozisyon açma kodu
            }
        }
    } catch (error) {
        console.error('Auto trading error:', error.message);
    }
}

// Her 5 saniyede çalıştır
setInterval(runAutoTrading, 5000);

// ============================================
// SERVER BAŞLAT
// ============================================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Trading Bot Server çalışıyor: http://localhost:${PORT}`);
    console.log(`📊 Binance API Bağlantısı: ${BINANCE_API}`);
});
