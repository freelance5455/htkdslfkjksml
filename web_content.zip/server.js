import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(express.json({ limit: "15mb" }));
app.use(express.static("public"));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY.includes("PASTE_")) {
      return res.status(500).json({ error: "ابتدا کلید API را در فایل .env تنظیم کنید." });
    }

    const { message, imageDataUrl } = req.body ?? {};
    if (!message && !imageDataUrl) {
      return res.status(400).json({ error: "پیام یا عکس بفرستید." });
    }

    const content = [];
    if (message) content.push({ type: "input_text", text: message });
    if (imageDataUrl) {
      content.push({ type: "input_image", image_url: imageDataUrl });
    }

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1",
      input: [{ role: "user", content }]
    });

    res.json({ reply: response.output_text || "پاسخی دریافت نشد." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "ارتباط با هوش مصنوعی ناموفق بود. تنظیمات API و اینترنت را بررسی کنید." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`MOJAHID AI running on port ${port}`));