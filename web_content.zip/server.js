const path = require("path");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");

const PORT = process.env.PORT || 3000;
const GROUP_PASSWORD = process.env.NEXORA_PASSWORD || "Nexa2026";

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, "public")));

const users = new Map(); // socket.id -> {name, id}
const history = [];
const MAX_HISTORY = 100;

function publicUsers() {
  return [...users.values()].map(u => ({id:u.id, name:u.name}));
}

io.on("connection", socket => {
  socket.on("join", ({name,password}, reply) => {
    name = String(name || "").trim().slice(0,20);
    if (!name) return reply?.({ok:false,error:"Enter a username."});
    if (password !== GROUP_PASSWORD) return reply?.({ok:false,error:"Wrong group password."});

    users.set(socket.id,{id:socket.id,name});
    socket.join("nexora");
    reply?.({ok:true, me:{id:socket.id,name}, history});
    io.to("nexora").emit("users", publicUsers());
    socket.to("nexora").emit("system", `${name} joined NEXORA.`);
  });

  socket.on("chat", text => {
    const user = users.get(socket.id);
    if (!user || typeof text !== "string") return;
    text = text.trim().slice(0,500);
    if (!text) return;
    const msg = {id:Date.now()+"-"+Math.random().toString(36).slice(2),name:user.name,text,time:Date.now()};
    history.push(msg);
    if (history.length > MAX_HISTORY) history.shift();
    io.to("nexora").emit("chat",msg);
  });

  socket.on("typing", value => {
    const user=users.get(socket.id);
    if (user) socket.to("nexora").emit("typing",{name:user.name,typing:!!value});
  });

  // WebRTC signaling. Media stays peer-to-peer; the server only relays signaling messages.
  socket.on("webrtc:offer", ({to,offer}) => {
    if (users.has(socket.id) && users.has(to)) io.to(to).emit("webrtc:offer",{from:socket.id,offer});
  });
  socket.on("webrtc:answer", ({to,answer}) => {
    if (users.has(socket.id) && users.has(to)) io.to(to).emit("webrtc:answer",{from:socket.id,answer});
  });
  socket.on("webrtc:ice", ({to,candidate}) => {
    if (users.has(socket.id) && users.has(to)) io.to(to).emit("webrtc:ice",{from:socket.id,candidate});
  });
  socket.on("call:request", ({to,video}) => {
    const user=users.get(socket.id);
    if (user && users.has(to)) io.to(to).emit("call:request",{from:socket.id,name:user.name,video:!!video});
  });
  socket.on("call:hangup", ({to}) => {
    if (users.has(to)) io.to(to).emit("call:hangup",{from:socket.id});
  });

  socket.on("disconnect", () => {
    const user=users.get(socket.id);
    users.delete(socket.id);
    if (user) {
      io.to("nexora").emit("users", publicUsers());
      socket.to("nexora").emit("system", `${user.name} left NEXORA.`);
      socket.to("nexora").emit("call:hangup",{from:socket.id});
    }
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`NEXORA running on http://localhost:${PORT}`);
});
