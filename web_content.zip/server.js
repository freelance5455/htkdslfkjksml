const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 3000;
const players = new Map();
const rooms = new Map();
app.use(express.static(__dirname));
app.get('/health', (_req, res) => res.json({ ok: true, players: players.size, rooms: rooms.size }));
function roomPlayers(code) { return Array.from(players.values()).filter(p => p.room === code); }
function publishRoom(code) { if (!code) return; const list = roomPlayers(code); io.to(code).emit('players', list); io.to(code).emit('roomInfo', { code, count: list.length }); }
function makeCode() { const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let code; do { code = Array.from({length:6}, () => chars[Math.floor(Math.random()*chars.length)]).join(''); } while (rooms.has(code)); return code; }
function leaveRoom(socket) { const old = players.get(socket.id); if (!old || !old.room) return; const code = old.room; socket.leave(code); players.delete(socket.id); if (rooms.has(code)) { rooms.get(code).delete(socket.id); if (!rooms.get(code).size) rooms.delete(code); } publishRoom(code); }
io.on('connection', socket => {
  socket.on('createRoom', () => {
    leaveRoom(socket); const code = makeCode(); rooms.set(code, new Set([socket.id])); socket.join(code);
    players.set(socket.id, { id: socket.id, name: 'Oyuncu', color: 0x11d6ef, x: 0, y: 0, z: 0, rotation: 0, room: code });
    socket.emit('roomJoined', { code, count: 1 }); publishRoom(code);
  });
  socket.on('joinRoom', raw => {
    const code = String(raw || '').trim().toUpperCase();
    if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code) || !rooms.has(code)) { socket.emit('roomError', 'Bu oda kodu bulunamadı. Kod doğru mu?'); return; }
    if (rooms.get(code).size >= 8) { socket.emit('roomError', 'Bu oda dolu (en fazla 8 oyuncu).'); return; }
    leaveRoom(socket); socket.join(code); rooms.get(code).add(socket.id);
    players.set(socket.id, { id: socket.id, name: 'Oyuncu', color: 0x11d6ef, x: 0, y: 0, z: 0, rotation: 0, room: code });
    socket.emit('roomJoined', { code, count: rooms.get(code).size }); publishRoom(code);
  });
  socket.on('joinGame', data => {
    const p = players.get(socket.id); if (!p) return;
    const color = Number(data && data.color); p.color = Number.isFinite(color) ? color : p.color; const rawName = String(data && data.name || '').trim(); if (rawName) p.name = rawName.slice(0,16); p.model = ['sahin','toros','bus','accent','togg','mercedes','bmw','bugatti','tank','motorcycle','minibus','tractor','truck','pickup'].includes(data && data.model) ? data.model : 'sahin'; publishRoom(p.room);
  });
  socket.on('playerState', data => {
    const p = players.get(socket.id); if (!p || !data || typeof data !== 'object') return;
    const num = n => Number.isFinite(Number(n)) ? Math.max(-500, Math.min(500, Number(n))) : 0;
    p.x = num(data.x); p.y = Math.max(0, Math.min(300, num(data.y))); p.z = num(data.z); p.rotation = num(data.rotation); p.color = num(data.color) || p.color; if (['sahin','toros','bus','accent','togg','mercedes','bmw','bugatti','tank','motorcycle','minibus','tractor','truck','pickup'].includes(data.model)) p.model = data.model; const rawName = String(data.name || '').trim(); if (rawName) p.name = rawName.slice(0,16);
    publishRoom(p.room);
  });
  socket.on('disconnect', () => leaveRoom(socket));
});
server.listen(PORT, '0.0.0.0', () => console.log(`TOFAS PVP server listening on ${PORT}`));
