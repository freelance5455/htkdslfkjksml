#!/usr/bin/env python3
import os,json,secrets,base64
from datetime import datetime
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
BASE=Path(__file__).resolve().parent
DATA=BASE/'tracker_data.json'
HOST='127.0.0.1'; PORT=int(os.environ.get('SGX_TRACKER_PORT','8765'))
PASSWORD=os.environ.get('SGX_TRACKER_PASSWORD','')
if len(PASSWORD)<12: raise SystemExit('Set SGX_TRACKER_PASSWORD to a new password of at least 12 characters.')
DEFAULT={'guild_id':'','guild_name':'','accounts':[],'snapshots':[]}
def load():
    try: return {**DEFAULT,**json.loads(DATA.read_text('utf-8'))}
    except Exception: return dict(DEFAULT)
def save(d):
    t=DATA.with_suffix('.tmp'); t.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8'); os.replace(t,DATA)
    try: os.chmod(DATA,0o600)
    except OSError: pass
class H(BaseHTTPRequestHandler):
    server_version='LocalGuildTracker/1.0'
    def log_message(self,*a): pass
    def auth(self):
        try:
            scheme,token=self.headers.get('Authorization','').split(' ',1)
            _,pw=base64.b64decode(token).decode().split(':',1)
            return scheme.lower()=='basic' and secrets.compare_digest(pw,PASSWORD)
        except Exception: return False
    def sendj(self,code,obj,ctype='application/json; charset=utf-8'):
        b=obj if isinstance(obj,bytes) else json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(b)
    def readj(self):
        n=min(int(self.headers.get('Content-Length','0')),10000); return json.loads(self.rfile.read(n) or b'{}')
    def do_GET(self):
        if not self.auth():
            self.send_response(401); self.send_header('WWW-Authenticate','Basic realm="Guild Tracker"'); self.end_headers(); return
        p=self.path.split('?',1)[0]
        if p=='/': return self.sendj(200,(BASE/'index.html').read_bytes(),'text/html; charset=utf-8')
        if p=='/api/data':
            d=load(); return self.sendj(200,{k:d[k] for k in ('guild_id','guild_name','accounts','snapshots')})
        self.sendj(404,{'error':'Not found'})
    def do_POST(self):
        if not self.auth(): return self.sendj(401,{'error':'Authentication required'})
        try: b=self.readj()
        except Exception: return self.sendj(400,{'error':'Invalid JSON'})
        d=load(); p=self.path.split('?',1)[0]
        if p=='/api/guild':
            gid=str(b.get('guild_id','')).strip()
            if gid and not gid.isdigit(): return self.sendj(400,{'error':'Guild ID must be numeric'})
            d['guild_id']=gid[:32]; d['guild_name']=str(b.get('guild_name','')).strip()[:80]; save(d); return self.sendj(200,{'ok':True})
        if p=='/api/accounts':
            uid=str(b.get('uid','')).strip()
            if not uid.isdigit() or len(uid)>24: return self.sendj(400,{'error':'Enter numeric UID only'})
            if any(a['uid']==uid for a in d['accounts']): return self.sendj(409,{'error':'UID already exists'})
            if len(d['accounts'])>=100: return self.sendj(400,{'error':'Maximum 100 UIDs'})
            d['accounts'].append({'uid':uid,'label':str(b.get('label','')).strip()[:80]}); save(d); return self.sendj(200,{'ok':True})
        if p=='/api/snapshot':
            try: xp=int(b.get('xp'))
            except Exception: return self.sendj(400,{'error':'EXP must be numeric'})
            if xp<0 or xp>10**12: return self.sendj(400,{'error':'EXP out of range'})
            d['snapshots'].append({'xp':xp,'time':datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')}); d['snapshots']=d['snapshots'][-200:]; save(d); return self.sendj(200,{'ok':True})
        self.sendj(404,{'error':'Not found'})
    def do_DELETE(self):
        if not self.auth(): return self.sendj(401,{'error':'Authentication required'})
        try: b=self.readj()
        except Exception: return self.sendj(400,{'error':'Invalid JSON'})
        if self.path.split('?',1)[0]!='/api/accounts': return self.sendj(404,{'error':'Not found'})
        uid=str(b.get('uid','')); d=load(); n=len(d['accounts']); d['accounts']=[a for a in d['accounts'] if a['uid']!=uid]
        if n==len(d['accounts']): return self.sendj(404,{'error':'UID not found'})
        save(d); self.sendj(200,{'ok':True})
if __name__=='__main__':
    print(f'Guild EXP Tracker: http://{HOST}:{PORT}')
    print('Browser login username: admin; password: SGX_TRACKER_PASSWORD')
    ThreadingHTTPServer((HOST,PORT),H).serve_forever()
