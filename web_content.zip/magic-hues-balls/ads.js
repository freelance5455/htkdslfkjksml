/* ============ Magic Hues Balls · ads.js · ANÚNCIOS (Google AdMob) ============
   1) Cole seus 3 IDs de anúncio (banner, intersticial, recompensado) + o ID do app abaixo (já estão os seus).
   2) CUIDADO: não clique nos seus próprios anúncios reais (o AdMob pode banir a conta). Para testar, use os IDs de teste do Google.
   3) No navegador os anúncios são simulados. Os reais só aparecem dentro do app Android (veja LEIA-ME.txt). */
const AD_CONFIG={
 appId:'COLOQUE-AQUI-O-ID-DO-APP', // ca-app-pub-3454219603574077~XXXXXXXXXX (o ID do app, com ~, fica em AdMob > Apps > Configurações do app; vai no AndroidManifest)
 bannerId:'ca-app-pub-3454219603574077/7374944512',       // Banner
 interstitialId:'ca-app-pub-3454219603574077/1001107853', // Intersticial
 rewardedId:'ca-app-pub-3454219603574077/9546967239',     // Recompensado
 interCooldownMs:30000 // mínimo de 30s entre intersticiais (não irrita o jogador)
};
const AdBridge=(function(){
 const cap=()=>window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.AdMob; // plugin @capacitor-community/admob
 const wv=()=>window.AndroidAds; // alternativa: ponte nativa própria (veja LEIA-ME.txt)
 let lastInter=0,ready=false;
 async function init(){if(ready)return;try{const a=cap();if(a){await a.initialize({initializeForTesting:AD_CONFIG.interstitialId.indexOf('3940256099942544')>-1});ready=true}}catch(e){}}
 document.addEventListener('DOMContentLoaded',init);
 return{
  native:()=>!!(cap()||wv()),
  canInter:()=>Date.now()-lastInter>=AD_CONFIG.interCooldownMs,
  async showInter(){lastInter=Date.now();try{const a=cap();if(a){await init();await a.prepareInterstitial({adId:AD_CONFIG.interstitialId});await a.showInterstitial();return true}
   if(wv()&&wv().showInterstitial){wv().showInterstitial(AD_CONFIG.interstitialId);return true}}catch(e){}return false},
  async showReward(){try{const a=cap();if(a){await init();await a.prepareRewardVideoAd({adId:AD_CONFIG.rewardedId});const r=await a.showRewardVideoAd();return !!r}
   if(wv()&&wv().showRewarded)return await new Promise(res=>{window.onRewardResult=ok=>res(!!ok);wv().showRewarded(AD_CONFIG.rewardedId)})}catch(e){}return false}
 }})();

// 🪧 BANNER: fica só nos menus/mapa e some durante a partida (evita toque sem querer, que o AdMob pune).
(function(){
 let on=false,sim=null;
 function simBar(){if(sim)return sim;sim=document.createElement('div');sim.textContent='📢 BANNER (simulação — o real aparece no app Android)';sim.style.cssText='position:fixed;left:0;right:0;bottom:0;height:40px;display:none;align-items:center;justify-content:center;background:#222;color:#bbb;font:600 11px system-ui;z-index:50;border-top:1px solid #555';document.body.appendChild(sim);return sim}
 async function setBanner(v){if(v===on)return;on=v;try{const a=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.AdMob;
  if(a){if(v)await a.showBanner({adId:AD_CONFIG.bannerId,adSize:'ADAPTIVE_BANNER',position:'BOTTOM_CENTER',margin:0});else await a.removeBanner()}
  else if(window.AndroidAds&&window.AndroidAds.showBanner){v?window.AndroidAds.showBanner(AD_CONFIG.bannerId):window.AndroidAds.hideBanner&&window.AndroidAds.hideBanner()}
  else simBar().style.display=v?'flex':'none'}catch(e){}}
 setInterval(()=>{try{const playing=typeof state!=='undefined'&&(state=='play'||state=='load');const off=typeof sv!=='undefined'&&sv.noads;setBanner(!playing&&!off)}catch(e){}},700);
})();
