/* ============ Magic Hues Balls · ads.js · ANÚNCIOS (Google AdMob) ============
   1) Cole seus IDs abaixo (os que estão aí são os IDs DE TESTE oficiais do Google — pode testar à vontade).
   2) Troque pelos seus IDs reais só na hora de publicar.
   3) No navegador os anúncios são simulados. Os reais só aparecem dentro do app Android (veja LEIA-ME.txt). */
const AD_CONFIG={
 appId:'ca-app-pub-3940256099942544~3347511713',          // ID do app (teste)  → troque por ca-app-pub-XXXX~YYYY
 interstitialId:'ca-app-pub-3940256099942544/1033173712', // Intersticial (teste) → troque pelo seu
 rewardedId:'ca-app-pub-3940256099942544/5224354917',     // Recompensado (teste) → troque pelo seu
 interCooldownMs:30000 // mínimo de 30s entre intersticiais (não irrita o jogador)
};
const AdBridge=(function(){
 const cap=()=>window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.AdMob; // plugin @capacitor-community/admob
 const wv=()=>window.AndroidAds; // alternativa: ponte nativa própria (veja LEIA-ME.txt)
 let lastInter=0,ready=false;
 async function init(){if(ready)return;try{const a=cap();if(a){await a.initialize({initializeForTesting:AD_CONFIG.interstitialId.indexOf('3940256099942544')>-1});ready=true}}catch(e){}}
 document.addEventListener('DOMContentLoaded',init);
 return{
  native:()=>!!(cap()||wv()),
  canInter:()=>Date.now()-lastInter>=AD_CONFIG.interCooldownMs,
  async showInter(){lastInter=Date.now();try{const a=cap();if(a){await init();await a.prepareInterstitial({adId:AD_CONFIG.interstitialId});await a.showInterstitial();return true}
   if(wv()&&wv().showInterstitial){wv().showInterstitial(AD_CONFIG.interstitialId);return true}}catch(e){}return false},
  async showReward(){try{const a=cap();if(a){await init();await a.prepareRewardVideoAd({adId:AD_CONFIG.rewardedId});const r=await a.showRewardVideoAd();return !!r}
   if(wv()&&wv().showRewarded)return await new Promise(res=>{window.onRewardResult=ok=>res(!!ok);wv().showRewarded(AD_CONFIG.rewardedId)})}catch(e){}return false}
 }})();
