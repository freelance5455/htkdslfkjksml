let cv=document.getElementById('c'),g=cv.getContext('2d');
cv.width=720;cv.height=1280;g.scale(2,2);
const W=360,H=640,R=16,RH=R*1.732,TOP=44,COLS=11,LIM=16,CX=W/2,CY=592,ROWS=LIM+3,MAXLV=300,isElite=l=>(l-1)%20>=15,isBoss=l=>l%20==0,tierOf=l=>l<=60?0:l<=100?1:2 /* 0=normal (etapas 1-3), 1=meio-difícil (etapas 4-5), 2=difícil (etapas 6-7) */;
const COL=[['#ff4d6d','#a3123a'],['#3ea6ff','#0b4fa8'],['#3ddc84','#0f7a41'],['#ffd23f','#b07a00'],['#a66bff','#4b1fa8'],['#9aa3b5','#3b4254'],['#fff3b0','#ff7ab6'],['#555a6b','#161824']];
let boss=null,streak=0,lvStreak=0,mode='map',tLeft=0,lastT=Date.now(),rngS=0,dsc=0,bar=0,shk=0,dropY=0,rec=0,flash=0,pv=false,bl=[],rg=[],ft=[],shots=0,missLim=6,lvScore=0,goal=300,grid,off=0,state='start',score=0,level=1,best=0,cur=0,nxt=0,ang=Math.PI/2,aim=false,shot=null,miss=0,parts=[],fall=[],ncol=4,tick=0;
try{best=+localStorage.getItem('bc_best')||0}catch(e){}
// =====================  INFORMAÇÕES DO APP (troque antes de publicar)  =====================
const APP={version:'1.5.0',name:'Magic Hues Balls',
 rateUrl:'https://play.google.com/store/apps/details?id=COLOQUE.SEU.PACOTE.AQUI', // link do jogo na Play Store (avaliação)
 privacyUrl:'https://SEU-SITE.com/privacidade',termsUrl:'https://SEU-SITE.com/termos',email:'suporte@SEU-SITE.com'};
var Bus=null;var Lumi=null;let sv={un:1,st:{},snd:1,mus:1,vib:1,gd:1,df:1,coins:60,lives:5,nx:0,noads:0,iw:1,ib:1,il:3,dl:'',ds:0,pu:{},bm:{},mp:{},mc:{},mday:'',dw:'',skin:0,sk:{0:1},lum:1,mas:'flora',stat:{},ach:{},achSeen:0,tut:0,rated:0,rsn:0,rm:0,gq:'auto',_v:2};
let saveNote='';
(function loadSave(){ // lê o salvamento principal; se estiver corrompido, usa o backup automático; se não houver nada, começa do zero
 const ok=o=>o&&typeof o=='object'&&typeof o.coins=='number'&&typeof o.un=='number';let d=null;
 for(const k of['bc_sv','bc_sv_bak']){try{const raw=localStorage.getItem(k);if(!raw)continue;const o=JSON.parse(raw);if(ok(o)){d=o;if(k=='bc_sv_bak')saveNote='Progresso restaurado do backup 💾';break}}catch(e){}}
 if(d)Object.assign(sv,d);
 sv.stat=Object.assign({shots:0,pops:0,falls:0,wins:0,losses:0,stars3:0,playMs:0,bestStreak:0,modes:0,buys:0,hitShots:0,bosses:0},sv.stat||{});sv.ach=sv.ach||{};sv._v=2; // migração de versões antigas
 if(sv.st[140]&&sv.un<=140)sv.un=141;if(sv.st[200]&&sv.un<=200)sv.un=201;sv.coins=Math.max(0,Math.min(sv.coins|0,9999999));sv.lives=Math.max(0,Math.min(sv.lives|0,5)); // trava de segurança contra valores absurdos
})();
const $=id=>document.getElementById(id);
const jg=new Map(),bok=Array.from({length:9},(_,i)=>({x:Math.random()*W,y:Math.random()*H,r:40+Math.random()*60,v:.1+Math.random()*.25,s:Math.random()*6,k:['255,77,109','62,166,255','61,220,132','255,210,63','166,107,255'][i%5]}));
const stars=Array.from({length:40},()=>({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1.4+.3,s:Math.random()*6}));
const par=r=>(r+off)&1;
const P=(r,c)=>({x:4+R+c*2*R+par(r)*R,y:TOP+R+r*RH});
const ok=(r,c)=>r>=0&&r<ROWS&&c>=0&&c<COLS-par(r);
const at=(r,c)=>ok(r,c)?grid[r][c]:-1;
function nb(r,c){const q=par(r)?[c,c+1]:[c-1,c];const a=[[r,c-1],[r,c+1]];for(const d of[-1,1])for(const k of q)a.push([r+d,k]);return a.filter(([a,b])=>ok(a,b))}
function present(){const s=new Set();grid.forEach(r=>r.forEach(v=>{if(v>=0&&v<5)s.add(v)}));return[...s]}
function pick(){const p=present();return p.length?p[Math.random()*p.length|0]:Math.random()*ncol|0}
function rowFill(row,r){for(let c=0;c<COLS-par(r);c++)row[c]=((isElite(level)||tierOf(level)==2)&&Math.random()<.1)?5:Math.random()*ncol|0}
function newLevel(){
 off=0;grid=Array.from({length:ROWS},()=>Array(COLS).fill(-1));
 const MP=mode!='map'?MODEP[mode]:null,el=!MP&&isElite(level),tr=MP?0:tierOf(level),rows=MP?MP.rows:Math.min(Math.min(4+Math.floor(level/4),10)+(el?2:0)+(tr?1:0),11+(tr==2?1:0)),rd=mode=='daily'?seedRand:Math.random;ncol=MP?MP.nc:(el||level>=10?5:level<3?3:4);if(mode=='daily'){rngS=0;for(const ch of today())rngS=(rngS*31+ch.charCodeAt(0))|0}
 for(let r=0;r<rows;r++)for(let c=0;c<COLS-par(r);c++)grid[r][c]=(c>0&&rd()<.4)?grid[r][c-1]:rd()*ncol|0;
 {const sp=MP?(MP.stone||0):(el?.05+.02*((level-1)%20-15):0)+(tr==1?.03:tr==2?(level>200?.09:.06):0);if(sp>0)for(let r=1;r<rows-1;r++)for(let c=0;c<COLS-par(r);c++)if(rd()<sp)grid[r][c]=5}
 miss=0;streak=0;lvStreak=0;shot=null;parts=[];fall=[];lvScore=0;shots=0;goal=MP?MP.goal:Math.min(1900,Math.round(Math.min(200+35*level,1400)*(el?1.2:1)*(tr==1?1.1:tr==2?1.2:1)));missLim=MP?MP.miss:Math.max(el||tr==2?2:3,[8,6,4][sv.df]-Math.floor(level/15)-(el?1:0)-(tr==2?1:0));boss=(!MP&&isBoss(level))?mkBoss(level):null;cur=pick();nxt=pick();ang=Math.PI/2;state='play';
}

function show(id){$(id).classList.remove('hide');if(id=='ovEnd'&&Bus)Bus.emit('lose');if(Lumi)Lumi.onShow(id)}
function add(n){score+=n;lvScore+=n}
function saveBest(){if(score>best){best=score;try{localStorage.setItem('bc_best',best)}catch(e){}}}
const OVS=['ovStart','ovShop','ovLives','ovDaily','ovAd','ovSet','ovHow','ovPause','ovWin','ovEnd','ovMode','ovMiss','ovSkin','ovRec','ovTuto','ovRate','ovAch','ovBackup','ovAbout'];
const hideAll=()=>OVS.forEach(i=>$(i).classList.add('hide'));
const go=id=>{hideAll();show(id)};
let lastBak=0;
const store=()=>{try{sv._v=2;const j=JSON.stringify(sv);localStorage.setItem('bc_sv',j);const n=Date.now();if(n-lastBak>20000){localStorage.setItem('bc_sv_bak',j);lastBak=n}}catch(e){}}; // salva e, a cada 20 s, guarda uma cópia de segurança
document.addEventListener('visibilitychange',()=>{if(document.hidden){lastBak=0;store()}});if(window.addEventListener)window.addEventListener('pagehide',()=>{lastBak=0;store()}); // salva ao sair do app
const vib=n=>{if(sv.vib&&navigator.vibrate)navigator.vibrate(n)};
let ac;
// =====================================================================================
// 🔊 EFEITOS SONOROS — todos gerados pelo código (Web Audio API). Não existe nenhum arquivo MP3.
// Cada som é uma lista de "notas". Cada nota é:  [frequência_Hz, duração_s, tipo_de_onda, volume, frequência_final_Hz]
//   • tipo_de_onda: 'sine' = suave e redondo • 'triangle' = suave e brilhante • 'square' = som de videogame • 'sawtooth' = áspero/triste
//   • frequência_final (opcional): faz a nota DESLIZAR, subindo ou descendo (tipo "piuuu" ou "buuum")
// Para tocar um som, chame:  sfx('nome')   (ou sfx('nome', 1.2) para deixá-lo mais agudo)
// =====================================================================================
const SFX={
 // 🎯 Disparo: "piu" curtinho que sobe de tom quando o canhão atira a bolinha.
 shoot:[[260,.09,'triangle',.10,520]],
 // 💥 Parede: "tóc" grave e seco que cai rápido de tom quando a bolinha bate na parede e volta.
 wall:[[330,.07,'square',.06,170]],
 // 🔔 Acerto: sininho (nota + harmônico agudo) quando a bolinha encosta nas outras e gruda.
 hit:[[880,.16,'sine',.12],[1320,.12,'sine',.05]],
 // 🫧 Estouro: "blup" que sobe de tom. Fica mais agudo quanto maior o grupo estourado (use o 2º parâmetro).
 pop:[[420,.07,'sine',.12,900]],
 // ✨ Pontos: "ding-ding-ding-dinnng" brilhante e subindo, tocado logo depois do estouro quando você ganha pontos.
 points:[[1047,.07,'triangle',.08],[1319,.07,'triangle',.08],[1568,.07,'triangle',.08],[2093,.15,'sine',.09]],
 // 🍂 Queda: brilho suave que desce, quando bolinhas soltas caem (pontos extras).
 fall:[[1250,.28,'sine',.06,520]],
 // 🎉 Vitória: três notas alegres subindo (Dó-Mi-Sol), como uma pequena fanfarra.
 win:[[523,.12,'sine',.12],[659,.12,'sine',.12],[784,.22,'sine',.12]],
 // 😢 Perdeu vida/jogo: "wah-wah-waaah" triste, três notas descendo com som áspero.
 lose:[[392,.22,'sawtooth',.09,370],[349,.22,'sawtooth',.09,330],[294,.5,'sawtooth',.09,200]],
 // 🚫 Não pode: "bip" curto e grave (ex.: sem moedas, fase bloqueada).
 no:[[150,.08,'square',.10]]
};
function sfx(k,pitch){if(!sv.snd)return;try{
 ac=ac||new(window.AudioContext||window.webkitAudioContext)();if(ac.state=='suspended')ac.resume();
 const T=SFX[k];if(!T)return;let t=ac.currentTime;const p=(pitch||1)*(1+(Math.random()-.5)*.04); // leve variação de tom, para não soar repetitivo
 T.forEach(([f,d,ty,v,f2])=>{const o=ac.createOscillator(),gn=ac.createGain();o.type=ty;o.frequency.setValueAtTime(f*p,t);
  if(f2)o.frequency.exponentialRampToValueAtTime(f2*p,t+d);          // desliza até a frequência final
  gn.gain.setValueAtTime(v||.12,t);gn.gain.exponentialRampToValueAtTime(.001,t+d); // volume começa e some suavemente
  o.connect(gn);gn.connect(ac.destination);o.start(t);o.stop(t+d);t+=d*.8})}catch(e){}}

// =====================================================================================
// 🎶 MÚSICA DE FUNDO — composta por mim, 100% original, gerada pelo código (sem MP3).
// Alegre e saltitante: tom de Dó maior, 112 batidas por minuto, loop de 8 compassos que se repete sem parar.
// Quatro "instrumentos" tocam juntos:
//   • MELODIA  (onda 'triangle')  → MEL: a notinha de cada passo (0 = silêncio). Números são notas MIDI (60 = Dó central).
//   • BAIXO    (onda 'sine')      → BAS: a nota grave de cada compasso (Dó, Sol, Lá, Fá, Dó, Sol, Fá, Dó).
//   • ACORDES  (onda 'triangle')  → CH: duas notas suaves tocadas nas batidas fracas, dando o balanço.
//   • CHIADO   (ruído agudo)      → "chimbal" leve nos tempos ímpares, que dá o ritmo animado.
// Na 2ª metade do loop entra também um "eco" agudo da melodia, para a música ficar ainda mais festiva.
// A música começa no primeiro toque do jogador (os navegadores só liberam som depois de um toque).
// =====================================================================================
const MEL=[76,0,79,76,74,0,72,0, 74,0,79,74,71,0,74,0, 72,0,76,72,69,0,72,76, 77,0,74,72,69,0,72,0, 79,0,76,79,84,0,79,76, 74,76,79,0,74,71,0,67, 72,0,77,76,74,72,0,69, 72,0,76,0,79,0,0,0];
const BAS=[48,43,45,41,48,43,41,48],CH=[[64,67],[59,62],[60,64],[57,60],[64,67],[59,62],[57,60],[64,67]];
const SD=60/112/2;let mg=null,mt=null,mNext=0,mStep=0,mNoise=null;
function mNote(m,t,d,ty,v){const o=ac.createOscillator(),q=ac.createGain();o.type=ty;o.frequency.value=440*2**((m-69)/12);q.gain.setValueAtTime(.0001,t);q.gain.exponentialRampToValueAtTime(v,t+.015);q.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(q);q.connect(mg);o.start(t);o.stop(t+d+.02)}
function mHat(t){if(!mNoise){mNoise=ac.createBuffer(1,ac.sampleRate*.05,ac.sampleRate);const d=mNoise.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1}
 const o=ac.createBufferSource(),f=ac.createBiquadFilter(),q=ac.createGain();o.buffer=mNoise;f.type='highpass';f.frequency.value=7000;q.gain.setValueAtTime(.03,t);q.gain.exponentialRampToValueAtTime(.001,t+.04);o.connect(f);f.connect(q);q.connect(mg);o.start(t)}
function mPlay(s,t){const b=s>>3,k=s&7,m=MEL[s];
 if(m)mNote(m,t,SD*1.7,'triangle',.09);          // melodia
 if(m&&s>=32)mNote(m+12,t+SD*.5,SD*.5,'sine',.025); // eco agudo (2ª metade do loop)
 if(k==0||k==4)mNote(BAS[b],t,SD*1.8,'sine',.16);
 if(k==2||k==6)CH[b].forEach(x=>mNote(x,t,SD*.8,'triangle',.035));
 if(k&1)mHat(t)}
function mSched(){if(!ac)return;while(mNext<ac.currentTime+.25){mPlay(mStep,mNext);mNext+=SD;mStep=(mStep+1)%64}}
function startMusic(){if(!sv.mus||mt)return;try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();if(ac.state=='suspended')ac.resume();
 if(!mg){mg=ac.createGain();mg.gain.value=.8;mg.connect(ac.destination)}mNext=ac.currentTime+.1;mt=setInterval(mSched,50)}catch(e){}}
function stopMusic(){clearInterval(mt);mt=null}
document.addEventListener('pointerdown',startMusic);
document.addEventListener('visibilitychange',()=>{document.hidden?(stopMusic(),state=='play'&&pause()):startMusic()});
$('tMus').onclick=()=>{sv.mus^=1;store();refSet();sv.mus?startMusic():stopMusic()};
let adN=0,pendL=0,spc=0;
function startLevel(l){if(!sv.tut){showTuto(l);return} /* 1ª vez: mostra o tutorial */ tickLives();if(sv.lives<=0){openLives(l);return}const go2=()=>{mode='map';level=l;score=0;spc=0;newLevel();hideAll();showLoad(l)};adN++;if(adN>1)Ads.inter(go2);else go2()} // intersticial entre uma fase e outra (não na 1ª abertura)
function pause(){if(state!='play')return;refreshSndLbl();state='pause';aim=false;go('ovPause')}
function refreshMenu(){refreshTop();const t=Object.values(sv.st).reduce((a,b)=>a+b,0);$('stBest').innerHTML='★ '+t+'/'+MAXLV*3+'<small>Recorde '+best+'</small>';$('bPlay').textContent='Jogar fase '+sv.un;refreshPills()}
function menu(){state='menu';grid=null;shot=null;fall=[];parts=[];refreshMenu();buildLv();go('ovStart')}
let mapSeen=0;
var nodeSvg=null; // posição (no desenho do mapa) da fase atual
// onde a fase atual está na TELA agora (considera a rolagem do mapa); a mascote usa isso para pousar ao lado da fase
function nodePos(){const m=$('lvMap');if(!nodeSvg||!m)return null;const k=m.clientWidth/320;return{x:nodeSvg.x*k,y:nodeSvg.y*k-m.scrollTop}}
// ===== CHEFÕES: a última fase de cada mundo (20, 40, 60...) é uma luta. Estourar e derrubar bolinhas tira vida do chefe; ele ataca a cada poucos tiros.
const BOSSES=[{n:'Rei Caranguejo',e:'🦀',k:'row'},{n:'Cogumelo Gigante',e:'🍄',k:'heal'},{n:'Alien Estelar',e:'👽',k:'row'},{n:'Golem de Cristal',e:'🗿',k:'heal'},{n:'Rei Tempestade',e:'⚡',k:'row'},{n:'Dragão de Lava',e:'🐉',k:'heal'},{n:'Olho das Sombras',e:'👁️',k:'row'},{n:'Bolo Monstro',e:'🎂',k:'heal'},{n:'Yeti Furioso',e:'⛄',k:'row'},{n:'Unicórnio Real',e:'🦄',k:'heal'},{n:'Escorpião Faraó',e:'🦂',k:'row'},{n:'Gorila Ancestral',e:'🦍',k:'heal'},{n:'Robô Orbital',e:'🤖',k:'row'},{n:'Lula Abissal',e:'🦑',k:'heal'},{n:'Dragão Cósmico',e:'🐲',k:'heal'}];
function mkBoss(l){const w=Math.min(14,l/20-1),mx=40+w*7+(l>200?10:0);return Object.assign({},BOSSES[w],{hp:mx,max:mx,sh:0,every:5-(w/5|0),hit:0})}
function bossHit(p,n){if(!boss||boss.hp<=0)return;const d=p+n*2;boss.hp=Math.max(0,boss.hp-d);boss.hit=14;ftx(CX,TOP+70,'-'+d+' ❤️','#ff6b6b',18);if(boss.hp<=0)ftx(CX,TOP+110,'DERROTADO! 👑','#ffd23f',26)}
function bossAtk(){const row=Array(COLS).fill(-1);grid.unshift(row);grid.pop();off^=1;rowFill(row,0);for(let c=0;c<COLS-par(0);c++)if(Math.random()<.22)row[c]=5;dropY=RH;shk=8;jg.clear();ftx(CX,TOP+100,boss.e+' Ataque!','#ff6b6b',22);if(boss.k=='heal'){const h=Math.min(boss.max-boss.hp,6);if(h>0){boss.hp+=h;ftx(CX,TOP+130,'+'+h+' ❤️ cura','#6ee7a0',16)}}sfx('no');vib(40)}
function buildLv(){const el=$('lvMap'),N=MAXLV,SP=74,NW=Math.ceil(N/20),GAP=60,Ht=N*SP+340+(NW-1)*GAP,X=i=>160+Math.sin((i-1)*.9)*85,Y=i=>Ht-190-(i-1)*SP-Math.floor((i-1)/20)*GAP,rn=k=>{const v=Math.sin(k*127.1)*43758.5453;return v-Math.floor(v)};
 const B=[Ht];for(let w=1;w<NW;w++)B.push((Y(w*20+1)+Y(w*20))/2);B.push(0);
 const seg=i=>{const h=(Y(i-1)-Y(i))/2;return'C'+X(i-1)+' '+(Y(i-1)-h)+' '+X(i)+' '+(Y(i)+h)+' '+X(i)+' '+Y(i)};
 const path=k=>{let d='M'+X(1)+' '+Y(1);for(let i=2;i<=k;i++)d+=' '+seg(i);return d};
 const an=(t,v,d,b)=>'<animateTransform attributeName="transform" type="'+t+'" values="'+v+'" dur="'+d.toFixed(1)+'s" begin="-'+b.toFixed(1)+'s" repeatCount="indefinite"/>';
 const am=(a,v,d,b)=>'<animate attributeName="'+a+'" values="'+v+'" dur="'+d.toFixed(1)+'s" begin="-'+b.toFixed(1)+'s" repeatCount="indefinite"/>';
 // ===== ETAPAS (mundos) do mapa: cada uma tem nome, cores, cenário animado e uma faixa de dificuldade =====
 const WORLDS=[ // t: 0 = normal, 1 = meio-difícil, 2 = difícil  |  fx = tipo de efeito animado do cenário
  {n:'🌊 MUNDO 1 · LAGOA DOCE',t:0,g:['#1f7ae0','#2b1a7a'],fx:'bub',em:['🐠','🐟','🐚','🌴','🦀','🐙']},
  {n:'🍄 MUNDO 2 · FLORESTA NEON',t:0,g:['#12a36b','#0b3b3a'],fx:'fly',em:['🍄','🌲','🌳','🦋','🌸','🐛']},
  {n:'🌌 MUNDO 3 · CUME DAS ESTRELAS',t:0,g:['#5a1fa8','#0b0620'],fx:'star',em:['⭐','🪐','🌙','✨','☄️','🛸']},
  {n:'💎 MUNDO 4 · CAVERNAS DE CRISTAL',t:1,g:['#14808f','#0a2a45'],fx:'crys',em:['💎','🔷','🦇','🍄','🕯️','⛏️']},
  {n:'⛈️ MUNDO 5 · ILHAS TEMPESTADE',t:1,g:['#5f7396','#1b2240'],fx:'rain',em:['⛈️','🌩️','🏝️','🐚','🌊','⚓']},
  {n:'🌋 MUNDO 6 · VULCÃO NEON',t:2,g:['#e0582a','#35091a'],fx:'ember',em:['🌋','🔥','💥','🪨','🦎','☄️']},
  {n:'👁️ MUNDO 7 · ABISMO DAS SOMBRAS',t:2,g:['#4a1f8e','#04010f'],fx:'wisp',em:['🌑','👻','🦇','🕸️','🔮','💀']},
  {n:'🍭 MUNDO 8 · REINO DOS DOCES',t:2,g:['#ff7ab6','#5a1a6a'],fx:'bub',em:['🍭','🍬','🧁','🍩','🍪','🎂']},
  {n:'❄️ MUNDO 9 · PICO GELADO',t:2,g:['#7fd4ff','#12255a'],fx:'crys',em:['❄️','⛄','🐧','🧊','🎿','🦌']},
  {n:'🌈 MUNDO 10 · CASTELO ARCO-ÍRIS',t:2,g:['#ffb347','#3a1a7a'],fx:'star',em:['🏰','🌈','🦄','👑','✨','🎆']},
  {n:'🏜️ MUNDO 11 · DESERTO DOURADO',t:2,g:['#e8b04a','#4a2a10'],fx:'ember',em:['🏜️','🌵','🐪','🦂','🏺','☀️']},
  {n:'🌴 MUNDO 12 · SELVA PERDIDA',t:2,g:['#2fbf4a','#0a3a1a'],fx:'fly',em:['🌴','🦜','🐒','🐍','🌺','🦎']},
  {n:'🚀 MUNDO 13 · ESTAÇÃO ESPACIAL',t:2,g:['#3a5fd0','#05061a'],fx:'star',em:['🚀','🛰️','👽','🌍','🌠','🛸']},
  {n:'🐋 MUNDO 14 · REINO SUBMARINO',t:2,g:['#0aa5c8','#06204a'],fx:'bub',em:['🐋','🦈','🐙','🪸','🐡','🧜']},
  {n:'🔮 MUNDO 15 · TRONO CÓSMICO',t:2,g:['#b43cff','#10042a'],fx:'wisp',em:['🔮','🌟','👑','🪄','💫','🌌']}],
  TIERS=['DIFICULDADE: NORMAL 🟢','DIFICULDADE: MEIO-DIFÍCIL 🔶','DIFICULDADE: DIFÍCIL 🔴'],TC=['#9ff0b5','#ffc46b','#ff8a8a'],CNT={bub:16,fly:22,star:70,crys:26,rain:26,ember:34,wisp:18};
 let o='<svg viewBox="0 0 320 '+Ht+'" xmlns="http://www.w3.org/2000/svg"><defs>'+WORLDS.map((c,w)=>'<linearGradient id="g'+w+'" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="'+c.g[0]+'"/><stop offset="1" stop-color="'+c.g[1]+'"/></linearGradient>').join('')+'<radialGradient id="gs"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient><radialGradient id="wg"><stop offset="0" stop-color="#e3ccff" stop-opacity=".9"/><stop offset="1" stop-color="#b58cff" stop-opacity="0"/></radialGradient><radialGradient id="gd" cx=".35" cy=".3"><stop offset="0" stop-color="#fff6c4"/><stop offset=".5" stop-color="#ffd23f"/><stop offset="1" stop-color="#d98a00"/></radialGradient><radialGradient id="ge" cx=".35" cy=".3"><stop offset="0" stop-color="#ffd1a8"/><stop offset=".5" stop-color="#ff6b35"/><stop offset="1" stop-color="#a31515"/></radialGradient><radialGradient id="gc" cx=".35" cy=".3"><stop offset="0" stop-color="#fffdf2"/><stop offset=".55" stop-color="#ffe08a"/><stop offset="1" stop-color="#f2a93a"/></radialGradient></defs>';
 for(let w=0;w<NW;w++){const WD=WORLDS[w],fx=WD.fx,y1=B[w+1],y2=B[w],h=y2-y1;
  o+='<rect x="0" y="'+y1+'" width="320" height="'+h+'" fill="url(#g'+w+')"/>';
  {const rg=(yb,am,col,op,sd)=>{const p=[];for(let k=0;k<=8;k++)p.push([k*40,yb-am*(.3+.7*rn(sd+k*3.7+w*9))]);let d='M0 '+yb+' L'+p[0][0]+' '+p[0][1].toFixed(0);for(let k=1;k<=8;k++){const a=p[k-1],b=p[k];d+=' Q'+a[0]+' '+a[1].toFixed(0)+' '+((a[0]+b[0])/2)+' '+((a[1]+b[1])/2).toFixed(0)}return'<path d="'+d+' L320 '+yb+' Z" fill="'+col+'" opacity="'+op+'"/>'},sx=(60+rn(w*5+1)*200).toFixed(0);
   o+='<circle cx="'+sx+'" cy="'+(y1+100)+'" r="80" fill="url(#gs)" opacity=".45"/><circle cx="'+sx+'" cy="'+(y1+100)+'" r="20" fill="#fff" opacity=".8"/>';
   for(let yy=y2-30;yy>y1+150;yy-=240)o+=rg(yy,120,WD.g[1],.5,yy)+rg(yy+40,80,WD.g[0],.4,yy+7)+rg(yy+70,50,'#000',.2,yy+3)}
  {const a=w*20+16,b=w*20+20,ya=Y(b)-37,yb=Y(a)+37;o+='<rect x="0" y="'+ya+'" width="320" height="'+(yb-ya)+'" fill="rgba(255,70,30,.14)"/><rect x="4" y="'+(yb-22)+'" width="82" height="18" rx="9" fill="rgba(120,10,10,.75)"/><text x="45" y="'+(yb-9)+'" text-anchor="middle" font-size="10" font-weight="800" fill="#ffb199">🔥 ZONA ELITE</text>'}
  for(let j=0;j<CNT[fx];j++){const r1=rn(j+w*77),r2=rn(j*3+w*31+5),r3=rn(j*7+w*13+2),y=y1+30+r2*(h-60),x=r1*320,X0=x.toFixed(0),Y0=y.toFixed(0);
   if(fx=='star')o+='<circle cx="'+X0+'" cy="'+Y0+'" r="'+(.8+r3*1.6).toFixed(1)+'" fill="#fff">'+am('opacity','.15;1;.15',2+r3*3,r1*5)+'</circle>';
   else if(fx=='fly')o+='<circle cx="'+X0+'" cy="'+Y0+'" r="2.2" fill="#fff3a0">'+am('cx',X0+';'+(x+14).toFixed(0)+';'+(x-9).toFixed(0)+';'+X0,5+r3*3,r1*6)+am('cy',Y0+';'+(y-12).toFixed(0)+';'+(y+8).toFixed(0)+';'+Y0,6+r2*3,r3*6)+am('opacity','.1;1;.1',2+r3*2,r2*4)+'</circle>';
   else if(fx=='bub'||fx=='ember'){const cy=(y1+h*.4+r2*h*.55).toFixed(0),em=fx=='ember';o+='<circle cx="'+X0+'" cy="'+cy+'" r="'+(2+r3*(em?2:4)).toFixed(1)+'" '+(em?'fill="#ffb347"':'fill="none" stroke="rgba(255,255,255,.55)" stroke-width="1.5"')+'>'+am('cy',cy+';'+(cy-(em?200:160)),(em?4:7)+r3*5,r1*10)+am('opacity',em?'0;1;0':'0;.9;0',(em?4:7)+r3*5,r1*10)+'</circle>'}
   else if(fx=='crys'){const sz=(3+r3*4).toFixed(1);o+='<polygon points="'+X0+','+(y-sz)+' '+(x+sz*.6).toFixed(1)+','+Y0+' '+X0+','+(y+ +sz).toFixed(1)+' '+(x-sz*.6).toFixed(1)+','+Y0+'" fill="#aef3ff">'+am('opacity','.2;1;.2',2+r3*3,r1*5)+'</polygon>'}
   else if(fx=='rain')o+='<line x1="'+X0+'" y1="'+Y0+'" x2="'+(x-4).toFixed(0)+'" y2="'+(y+14).toFixed(0)+'" stroke="#cfe3ff" stroke-width="1.4" opacity=".55">'+am('opacity','.2;.7;.2',.9+r3*.8,r1*2)+an('translate','0 0;-16 110',.9+r3*.8,r1*2)+'</line>';
   else o+='<circle cx="'+X0+'" cy="'+Y0+'" r="'+(6+r3*7).toFixed(0)+'" fill="url(#wg)">'+am('cx',X0+';'+(x+18).toFixed(0)+';'+(x-12).toFixed(0)+';'+X0,7+r3*4,r1*8)+am('cy',Y0+';'+(y-20).toFixed(0)+';'+(y+12).toFixed(0)+';'+Y0,8+r2*4,r3*8)+am('opacity','.2;.9;.2',3+r3*3,r2*5)+'</circle>'}
  if(fx=='star')for(let j=0;j<4;j++){const r1=rn(j*9+3),y=y1+60+r1*(h-160);o+='<g><line x1="0" y1="0" x2="-34" y2="-17" stroke="#fff" stroke-width="2.2" stroke-linecap="round" opacity=".85"/><circle r="2.6" fill="#fff"/>'+an('translate','380 '+y.toFixed(0)+';-60 '+(y+150).toFixed(0),5+j*1.5,r1*6)+'</g>'}
  if(fx=='bub'||fx=='fly'||fx=='rain')for(let j=0;j<(fx=='rain'?4:5);j++){const r1=rn(j*5+w*19+4),y=y1+50+r1*(h-100);o+='<g transform="translate(0 '+y.toFixed(0)+')"><g fill="'+(fx=='rain'?'#1a2240':'#fff')+'" opacity="'+(fx=='rain'?.45:.2)+'"><ellipse rx="26" ry="9"/><ellipse cx="-14" cy="-6" rx="14" ry="9"/><ellipse cx="12" cy="-8" rx="16" ry="10"/>'+an('translate','-70 0;400 0',45+r1*40,r1*40)+'</g></g>'}
  if(fx=='rain')o+='<rect x="0" y="'+y1+'" width="320" height="'+h+'" fill="#fff" opacity="0">'+am('opacity','0;0;0;.3;0;.2;0;0;0;0',7,rn(w)*7)+'</rect>';
  for(let j=0;j<(w<3?18:12);j++){const r1=rn(j*5+w*9+1),r2=rn(j*11+w*17+3),r3=rn(j*13+w+7),em=WD.em[j%6],x=r1<.75?(r2<.5?14+r3*34:272+r3*34):60+r3*200,y=y1+34+r2*(h-68),fl=['🦋','🛸','🐠','🐟','🦇','👻'].includes(em);
   o+='<g transform="translate('+x.toFixed(0)+' '+y.toFixed(0)+')"><text text-anchor="middle" font-size="'+(16+r3*10).toFixed(0)+'" opacity=".92">'+em+(fl?an('translate','0 0;16 -10;-8 -18;0 0',5+r1*3,r2*6):em=='🪐'?an('rotate','-12;12;-12',6,r1*5):an('translate','0 0;0 -5;0 0',2.5+r1*2,r2*3))+'</text></g>'}
  const bc=w?B[w]:Y(1)+62;
  o+='<rect x="45" y="'+(bc-18)+'" width="230" height="36" rx="12" fill="rgba(20,8,50,.74)" stroke="#ffd23f" stroke-width="1.5"/><text x="160" y="'+(bc-3)+'" text-anchor="middle" font-size="12" font-weight="800" fill="#fff">'+WD.n+'</text><text x="160" y="'+(bc+11)+'" text-anchor="middle" font-size="9.5" font-weight="800" fill="'+TC[WD.t]+'">'+TIERS[WD.t]+'</text>';
  if(w){let d='M0 '+B[w];for(let k=0;k<8;k++)d+=k?' t40 0':' q20 -10 40 0';o+='<path d="'+d+'" fill="none" stroke="rgba(255,255,255,.35)" stroke-width="3"/>'}}
 o+='<path d="'+path(N)+'" fill="none" stroke="rgba(0,0,0,.3)" stroke-width="17" stroke-linecap="round"/><path d="'+path(N)+'" fill="none" stroke="rgba(255,230,160,.22)" stroke-width="11" stroke-linecap="round"/><path d="'+path(N)+'" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="2.5" stroke-linecap="round" stroke-dasharray="1 12"/>';
 const cu=Math.min(sv.un,N);
 o+='<path d="'+path(cu)+'" fill="none" stroke="#ffd23f" stroke-width="6" stroke-linecap="round" opacity=".9"/><path d="'+path(cu)+'" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-dasharray="2 12" opacity=".9">'+am('stroke-dashoffset','0;-28',1,0)+'</path>';
 for(let i=1;i<=N;i++){const x=X(i),y=Y(i),st=sv.st[i]||0,lk=i>sv.un,cr=!lk&&!st,sp=i%5==0,el=isElite(i),tr=tierOf(i),rr=sp?27:22,dl=Math.min(.7,Math.abs(i-sv.un)*.035).toFixed(2);
  o+='<g class="nd" data-n="'+i+'" style="cursor:pointer;animation-delay:'+dl+'s"><ellipse cx="'+x+'" cy="'+(y+rr*.85)+'" rx="'+(rr*1.0)+'" ry="'+(rr*.42)+'" fill="rgba(0,0,0,.42)"/>';
  if(cr)o+='<circle cx="'+x+'" cy="'+y+'" r="'+rr+'" fill="none" stroke="#fff" stroke-width="3">'+am('r',rr+';'+(rr+11)+';'+rr,1.4,0)+am('opacity','.8;0;.8',1.4,0)+'</circle>';
  if(sp){let pt='';for(let k=0;k<12;k++){const a=k*Math.PI/6,q=k%2?rr-2:rr+7;pt+=(x+Math.cos(a)*q).toFixed(1)+','+(y+Math.sin(a)*q).toFixed(1)+' '}
   o+='<polygon points="'+pt+'" fill="'+(lk?'#3a2f66':cr?'url(#gc)':el?'url(#ge)':'url(#gd)')+'" stroke="'+(lk?(el?'#7a3a3a':tr==2?'#8a3a3a':tr==1?'#9a6a2a':'#5a4a96'):el?'#ff6b35':'#fff')+'" stroke-width="3" stroke-linejoin="round">'+(lk?'':'<animateTransform attributeName="transform" type="rotate" from="0 '+x+' '+y+'" to="360 '+x+' '+y+'" dur="16s" repeatCount="indefinite"/>')+'</polygon>';
   o+='<text x="'+x+'" y="'+(y-rr-10)+'" text-anchor="middle" font-size="'+(i==N?24:17)+'">'+(i==N?'🏆':i%20==0?BOSSES[i/20-1].e:'🎁')+an('translate','0 0;0 -4;0 0',1.6,0)+'</text>'}
  else o+='<circle cx="'+x+'" cy="'+y+'" r="22" fill="'+(lk?'#3a2f66':cr?'url(#gc)':el?'url(#ge)':'url(#gd)')+'" stroke="'+(lk?(el?'#7a3a3a':tr==2?'#8a3a3a':tr==1?'#9a6a2a':'#5a4a96'):el?'#ff6b35':'#fff')+'" stroke-width="3"/>';
  o+='<ellipse cx="'+x+'" cy="'+(y-rr*.45)+'" rx="'+(rr*.62)+'" ry="'+(rr*.32)+'" fill="#fff" opacity="'+(lk?.14:.4)+'"/>';o+=lk?'<text x="'+x+'" y="'+(y+6)+'" text-anchor="middle" font-size="16">🔒</text>':'<text x="'+x+'" y="'+(y+7)+'" text-anchor="middle" font-size="19" font-weight="900" fill="#2a1060">'+i+'</text>';
  if(!lk&&tr&&!el)o+='<circle cx="'+x+'" cy="'+y+'" r="'+(rr+4)+'" fill="none" stroke="'+(tr==2?'#ff6b6b':'#ffb347')+'" stroke-width="2" opacity=".85"/>';
  if(!lk)for(let k=0;k<3;k++)o+='<text x="'+(x-13+k*13)+'" y="'+(y+rr+16)+'" text-anchor="middle" font-size="13" fill="'+(st>k?'#ffd23f':'rgba(255,255,255,.28)')+'">★'+(st>k?am('opacity','1;.55;1',2,k*.5+i%3*.3):'')+'</text>';
  if(el&&!sp)o+='<text x="'+(x+16)+'" y="'+(y-14)+'" font-size="13" text-anchor="middle">🔥'+an('translate','0 0;0 -3;0 0',1.2,i%4*.3)+'</text>';
  o+='</g>'}
 nodeSvg=(sv.un<=N&&!(sv.st[sv.un]||0))?{x:X(sv.un),y:Y(sv.un)}:null; // posição da fase atual: é aqui que a fadinha pousa
 mapSeen=sv.un;
 el.innerHTML=o+'</svg>';if(Q<2||RMOD){try{const sv_=el.querySelector('svg');sv_&&sv_.pauseAnimations&&sv_.pauseAnimations()}catch(e){}}
 el.onclick=e=>{const g=e.target.closest&&e.target.closest('.nd');if(!g)return;const i=+g.getAttribute('data-n'),lk=i>sv.un;g.classList.remove('tap','shk');void g.getBoundingClientRect();g.classList.add(lk?'shk':'tap');if(lk){sfx('no');vib(30)}else{sfx('pop');setTimeout(()=>startLevel(i),200)}};
 setTimeout(()=>{el.scrollTop=Math.max(0,Y(Math.min(sv.un,N))*el.clientWidth/320-el.clientHeight/2)},40)}
function refSet(){$('tLum').textContent='Mascote fadinha: '+(sv.lum?'ligada':'desligada');$('tMas').textContent='Mascote: '+(sv.mas=='flora'?'Flora, a fada das flores 🌸':'Lumina, a fada brincalhona ✨');$('tSnd').textContent='Efeitos: '+(sv.snd?'ligados':'desligados');$('tMus').textContent='Música: '+(sv.mus?'ligada':'desligada');$('tVib').textContent='Vibração: '+(sv.vib?'ligada':'desligada');$('tGd').textContent='Mira guiada: '+(sv.gd?'ligada':'desligada');$('tDf').textContent='Dificuldade: '+['Fácil','Normal','Difícil'][sv.df];$('tRst').textContent='Apagar progresso';$('tGq').textContent='Gráficos: '+({auto:'Automático','2':'Alto','1':'Médio','0':'Baixo'}[String(sv.gq)]||'Automático');$('tRm').textContent='Reduzir movimento: '+(sv.rm?'ligado':'desligado')}
function winFx(){trk('win',1);const cl=!present().length,st=cl||shots<=goal/20?3:shots<=goal/12?2:1;const first=!(sv.st[level]||0),gain=first?15+st*10+(isElite(level)?30:0)+tierOf(level)*10+(boss?50:0):5;const cb=Math.min(10,lvStreak);sv.coins+=gain+cb;if(st>(sv.st[level]||0))sv.st[level]=st;if(level<MAXLV&&sv.un<=level)sv.un=level+1;store();saveBest();if(Lumi)Lumi.stars=st;if(Bus){Bus.emit('win',st);if(boss)Bus.emit('boss')}$('winStars').textContent='★'.repeat(st)+'☆'.repeat(3-st);$('winTxt').textContent=score+' pontos • +'+(gain+cb)+' 🪙'+(cb?' (combo +'+cb+')':'');$('bNext').style.display=level>=MAXLV?'none':'';sfx('win');vib([40,30,40]);window._gain=gain+cb;const bd=$('bDbl');if(bd){bd.style.display='';bd.disabled=false}}
$('bDbl').onclick=function(){this.disabled=true;Ads.reward(()=>{sv.coins+=window._gain||0;store();refreshTop();this.style.display='none';toast('+'+(window._gain||0)+' 🪙 bônus!')},'ovWin')};
$('bPlay').onclick=()=>startLevel(sv.un);
$('bSet').onclick=()=>{refSet();go('ovSet')};
$('bHow').onclick=()=>go('ovHow');
document.querySelectorAll('.mn').forEach(b=>b.onclick=menu);
$('bRes').onclick=()=>{state='play';hideAll()};
$('bRst').onclick=$('bRep').onclick=$('bAgain').onclick=()=>mode=='map'?startLevel(level):startMode(mode);
$('bNext').onclick=()=>startLevel(level+1);
$('tSnd').onclick=()=>{sv.snd^=1;store();refSet();sfx('pop')};
$('tVib').onclick=()=>{sv.vib^=1;store();refSet();vib(40)};
$('tGd').onclick=()=>{sv.gd^=1;store();refSet()};
$('tDf').onclick=()=>{sv.df=(sv.df+1)%3;store();refSet()};
let rc=0;$('tRst').onclick=function(){if(!rc){rc=1;this.textContent='Toque de novo para confirmar';setTimeout(()=>{rc=0;refSet()},3000)}else{rc=0;sv.un=1;sv.st={};store();try{localStorage.removeItem('bc_best')}catch(e){}best=0;refSet()}};


(function(){const sp=$('ovSplash'),fill=$('spFill'),tx=$('spTxt');
 for(let i=0;i<18;i++){const b=document.createElement('span'),c=COL[i%5],z=18+Math.random()*34;b.className='fb';b.style.cssText='left:'+Math.random()*92+'%;width:'+z+'px;height:'+z+'px;--c:'+c[0]+';--d:'+c[1]+';animation-duration:'+(4+Math.random()*4)+'s;animation-delay:-'+Math.random()*6+'s';sp.appendChild(b)}
 let p=0,done=false;const iv=setInterval(()=>{p=Math.min(100,p+1+Math.random()*3);fill.style.width=p+'%';tx.textContent='Carregando… '+(p|0)+'%';if(p>=100){clearInterval(iv);done=true;tx.textContent='Toque para começar';tx.classList.add('blink')}},60);
 sp.addEventListener('pointerdown',()=>{if(!done)return;sp.style.opacity=0;sp.style.pointerEvents='none';setTimeout(()=>sp.remove(),450)});
})();

const pt=e=>{const b=cv.getBoundingClientRect();return{x:(e.clientX-b.left)/b.width*W,y:(e.clientY-b.top)/b.height*H}};
function setAng(p){const dx=p.x-CX,dy=CY-p.y;let a=Math.atan2(dy,dx);if(dy<0)a=dx>0?.17:Math.PI-.17;ang=Math.max(.17,Math.min(Math.PI-.17,a))}
cv.addEventListener('pointerdown',e=>{if(state!='play')return;const p=pt(e);if(p.y<TOP&&p.x>W-92&&p.x<=W-56){toggleSnd();return}if(p.y<TOP&&p.x>W-56){pause();return}if(shot)return;if(p.y>508&&p.y<548&&(Math.hypot(p.x-30,p.y-528)<22||Math.hypot(p.x-72,p.y-528)<22)){useBoost(Math.hypot(p.x-30,p.y-528)<22?6:7);return}if(p.x<95&&p.y>CY-30){[cur,nxt]=[nxt,cur];return}aim=true;cv.setPointerCapture(e.pointerId);setAng(p)});
cv.addEventListener('pointermove',e=>{if(aim)setAng(pt(e))});
cv.addEventListener('pointerup',()=>{if(aim){aim=false;fire()}});
cv.addEventListener('pointercancel',()=>{aim=false});
function fire(){if(shot||state!='play')return;shots++;sfx('shoot');if(Bus)Bus.emit('shot');const S=13;const sc=spc;spc=0;if(sc){const k=sc==6?'iw':'ib';sv[k]=Math.max(0,sv[k]-1);store()}shot={x:CX+Math.cos(ang)*30,y:CY-Math.sin(ang)*30,vx:Math.cos(ang)*S,vy:-Math.sin(ang)*S,c:sc||cur}}

function hit(x,y){for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){if(grid[r][c]<0)continue;const p=P(r,c),dx=p.x-x,dy=p.y-y;if(dx*dx+dy*dy<(R*1.75)**2)return true}return false}
function flood(r,c,test){const seen=new Set([r*COLS+c]),q=[[r,c]],out=[];while(q.length){const[a,b]=q.pop();out.push([a,b]);for(const[x,y]of nb(a,b)){const k=x*COLS+y;if(!seen.has(k)&&test(grid[x][y])){seen.add(k);q.push([x,y])}}}return out}
function burst(r,c){const p=P(r,c);for(let i=0;i<9;i++){const a=Math.random()*6.28,s=1+Math.random()*3;parts.push({x:p.x,y:p.y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-1,l:30,c:grid[r][c]})}}
function land(){sfx('hit'); // 🔔 a bolinha acertou e vai grudar

 let br=0,bc=0,bd=1e9;
 for(let r=0;r<ROWS;r++)for(let c=0;c<COLS-par(r);c++){if(grid[r][c]>=0)continue;const p=P(r,c),d=(p.x-shot.x)**2+(p.y-shot.y)**2;if(d<bd){bd=d;br=r;bc=c}}
 const wasSp=shot.c>=6,bomb=shot.c==7;
 if(shot.c==6){const cn={};for(const[a,b]of nb(br,bc)){const v=grid[a][b];if(v>=0&&v<5)cn[v]=(cn[v]||0)+1}const ks=Object.keys(cn).sort((x,y)=>cn[y]-cn[x]);shot.c=ks.length?+ks[0]:pick()}
 grid[br][bc]=shot.c;shot=null;jiggle(br,bc);
 const col=grid[br][bc];let grp=flood(br,bc,v=>v==col);let pops=0;
 if(bomb){const bp=P(br,bc);grp=[];for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)if(grid[r][c]>=0){const q=P(r,c);if((q.x-bp.x)**2+(q.y-bp.y)**2<(R*4.3)**2)grp.push([r,c])}}
 if(grp.length>=3||bomb){if(bomb){shk=9;ftx(CX,TOP+150,'BOOM! 💣','#ff8a3d',24)}
  const pc=P(br,bc),dd=q=>{const A=P(q[0],q[1]);return(A.x-pc.x)**2+(A.y-pc.y)**2};grp.sort((u,v)=>dd(u)-dd(v));let sx=0,sy=0;grp.forEach(([a,b],i)=>{const q=P(a,b);sx+=q.x;sy+=q.y;bl.push({x:q.x,y:q.y,c:grid[a][b],t:Math.round(-i*1.3)-1});grid[a][b]=-1});pops=grp.length;add(pops*10);trk('pop',pops);if(Bus)Bus.emit('pops',pops);ftx(sx/pops,sy/pops,'+'+pops*10,'#ffd23f',17);shk=Math.max(shk,Math.min(6,pops/2));
  const att=new Set(),q=[];
  for(let c=0;c<COLS;c++)if(grid[0][c]>=0){att.add(c);q.push([0,c])}
  while(q.length){const[a,b]=q.pop();for(const[x,y]of nb(a,b)){const k=x*COLS+y;if(grid[x][y]>=0&&!att.has(k)){att.add(k);q.push([x,y])}}}
  let n=0,fx=0,fy=0;
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)if(grid[r][c]>=0&&!att.has(r*COLS+c)){const p=P(r,c);fall.push({x:p.x,y:p.y,vx:(Math.random()-.5)*3,vy:-2,c:grid[r][c]});grid[r][c]=-1;n++;fx+=p.x;fy+=p.y}
  bossHit(pops,n);add(n*20);trk('fall',n);if(Bus&&n)Bus.emit('falls',n);if(n)setTimeout(()=>sfx('fall'),230); // 🍂 bolinhas soltas caindo
  if(n)ftx(fx/n,fy/n+22,'Queda! +'+n*20,'#3ddc84',15);if(pops>=6||n>=4)ftx(CX,TOP+190,pops>=6&&n>=4?'COMBO!':pops>=6?'Incrível!':'Chuva de bolinhas!','#fff',26);
 }
 if(pops){miss=0;streak++;lvStreak=Math.max(lvStreak,streak);if(Bus)Bus.emit('streak',streak);if(streak>=3)ftx(CX,TOP+110,'COMBO x'+streak+'!','#ff9ff3',20);sfx('pop',1+Math.min(pops,10)*.05+Math.min(streak,8)*.03);setTimeout(()=>sfx('points'),110);vib(25); // 🫧 estouro + ✨ pontos
  if(mode=='time'&&pops>=5){const b=Math.min(6,pops-3);tLeft+=b;ftx(CX,TOP+120,'+'+b+'s ⏱️','#6ee7ff',20)}}else{miss++;streak=0}
 if(mode=='inf')missLim=Math.max(2,6-Math.floor(score/1200));if(miss>=missLim){miss=0;const row=Array(COLS).fill(-1);grid.unshift(row);grid.pop();off^=1;rowFill(row,0);dropY=RH;shk=6;jg.clear()}
 saveBest();
 if(boss&&boss.hp>0&&++boss.sh>=boss.every){boss.sh=0;bossAtk()}if(mode!='map'&&mode!='daily'&&!present().length)refillRows();
 if(!present().length||(boss?boss.hp<=0:lvScore>=goal)){state='won';$('winTitle').textContent=boss?(boss.hp<=0?'Chefão derrotado! 👑':'Tabuleiro limpo! 🎉'):lvScore>=goal?'Meta atingida! 🎯':'Tabuleiro limpo! 🎉';score+=100*level;(mode=='daily'?dailyWin():winFx());celebrate();setTimeout(()=>show('ovWin'),700);return}
 for(let r=LIM;r<ROWS;r++)if(grid[r].some(v=>v>=0)){if(mode=='zen'){zenRelief();break}state='over';if(mode=='map'){loseLife();$('endTitle').textContent='Fim de Jogo';$('endLife').textContent='❤️ Vidas restantes: '+sv.lives+'/5';$('endBest').textContent='Recorde: '+best}else modeEnd();meltAll();sfx('lose');vib([60,40,60]);$('endScore').textContent=score;setTimeout(()=>show('ovEnd'),900);return}
 if(!wasSp){cur=nxt;nxt=pick()}if(!present().includes(cur))cur=pick();
}
function popFx(o){for(let i=0,n=Math.ceil(10*QP());i<n;i++){const a=Math.random()*6.28,s=1+Math.random()*3;parts.push({x:o.x,y:o.y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-1.2,l:34,m:34,r:2+Math.random()*2.5,c:o.c})}
 for(let i=0;i<4;i++){const a=Math.random()*6.28;parts.push({x:o.x,y:o.y,vx:Math.cos(a)*2.5,vy:Math.sin(a)*2.5,l:18,m:18,r:1.6,c:-1,gv:0})}rg.push({x:o.x,y:o.y,t:0,c:o.c})}
function ftx(x,y,s,col,z){ft.push({x:Math.max(45,Math.min(W-45,x)),y,s,col,z,t:0})}
function jiggle(r,c){const p=P(r,c);jg.set(r*COLS+c,{t:18,sc:1.35,dx:0,dy:0});rg.push({x:p.x,y:p.y,t:0,c:grid[r][c]});
 for(const[a,b]of nb(r,c)){if(grid[a][b]<0)continue;const q=P(a,b),dx=q.x-p.x,dy=q.y-p.y,d=Math.hypot(dx,dy)||1;jg.set(a*COLS+b,{t:18,sc:1,dx:dx/d*4,dy:dy/d*4})}}
function celebrate(){shk=5;for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)if(grid[r][c]>=0){const p=P(r,c);bl.push({x:p.x,y:p.y,c:grid[r][c],t:-Math.round(r*3+c*.8)-1});grid[r][c]=-1}
 for(let i=0,n=Math.ceil(70*QP());i<n;i++)parts.push({x:Math.random()*W,y:-10-Math.random()*120,vx:(Math.random()-.5)*2.5,vy:1+Math.random()*2,l:150,m:150,r:2+Math.random()*3,c:i%5,gv:.03})}
function meltAll(){shk=9;for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)if(grid[r][c]>=0){const p=P(r,c);fall.push({x:p.x,y:p.y,vx:(Math.random()-.5)*4,vy:-3-Math.random()*4,c:grid[r][c]});grid[r][c]=-1}}
function update(){
 tick++;if(state=='play')sv.stat.playMs+=1000/60; // tempo de jogo (estatística)
 {const n=Date.now(),dt=(n-lastT)/1000;lastT=n;if(mode=='time'&&state=='play'&&dt<1){tLeft-=dt;if(tLeft<=0){tLeft=0;timeUp()}}}
 if(state=='play'&&shot){for(let i=0;i<3&&shot;i++){shot.x+=shot.vx/3;shot.y+=shot.vy/3;
  if(shot.x<4+R){shot.x=4+R;shot.vx*=-1;sfx('wall')}if(shot.x>W-4-R){shot.x=W-4-R;shot.vx*=-1;sfx('wall')} // 💥 bateu na parede
  if(shot.y<=TOP+R||hit(shot.x,shot.y)){if(shot.y<TOP+R)shot.y=TOP+R;land()}}}
 parts.forEach(p=>{p.x+=p.vx;p.y+=p.vy;p.vy+=(p.gv===undefined?.15:p.gv);p.l--});parts=parts.filter(p=>p.l>0);
 fall.forEach(f=>{f.vy+=.5;f.x+=f.vx;f.y+=f.vy;if(Q>0&&tick%(Q>=2?2:4)==0)parts.push({x:f.x,y:f.y,vx:0,vy:0,l:14,m:14,r:4,c:f.c,gv:0,a:.5})});fall=fall.filter(f=>f.y<H+30);
 bl.forEach(o=>{o.t++;if(o.t==0)popFx(o)});bl=bl.filter(o=>o.t<12);
 rg.forEach(o=>o.t++);rg=rg.filter(o=>o.t<14);ft.forEach(o=>o.t++);ft=ft.filter(o=>o.t<55);
 jg.forEach((v,k)=>{if(--v.t<=0)jg.delete(k)});shk*=.88;dropY*=.8;rec*=.8;if(flash>0)flash--;
 if(shot&&!pv){rec=9;flash=7;for(let i=0;i<7;i++){const a=ang+(Math.random()-.5)*.8,s=2+Math.random()*3;parts.push({x:CX+Math.cos(a)*50,y:CY-Math.sin(a)*50,vx:Math.cos(a)*s,vy:-Math.sin(a)*s,l:14,m:14,r:2,c:-1,gv:.05})}}pv=!!shot;
 if(shot&&Q>0)parts.push({x:shot.x,y:shot.y,vx:0,vy:0,l:10,m:10,r:R*.5,c:shot.c,gv:0,a:.3});
}
function poly(x,y,rr,n,rot){g.beginPath();for(let i=0;i<n;i++){const t=rot+i*6.283/n;g.lineTo(x+Math.cos(t)*rr,y+Math.sin(t)*rr)}g.closePath();g.fill()}
const SPR={};
function ball(x,y,c,r=R,a=1){const k=c+'_'+sv.skin;let s=SPR[k];if(!s){s=document.createElement('canvas');s.width=s.height=64;const og=g;g=s.getContext('2d');g.scale(2,2);ball0(16,16,c,R,1);g=og;SPR[k]=s}g.globalAlpha=a;g.drawImage(s,x-r,y-r,r*2,r*2);g.globalAlpha=1}
function ball0(x,y,c,r=R,a=1){
 g.globalAlpha=a;const gr=g.createRadialGradient(x-r*.35,y-r*.4,r*.1,x,y,r);
 gr.addColorStop(0,'#fff');gr.addColorStop(.22,COL[c][0]);gr.addColorStop(1,COL[c][1]);
 g.fillStyle=gr;g.beginPath();g.arc(x,y,r-1,0,7);g.fill();if(sv.skin&&c<5)skinFx(x,y,c,r);
 g.fillStyle='rgba(255,255,255,.16)';g.beginPath();g.ellipse(x+r*.12,y+r*.52,r*.5,r*.22,0,0,7);g.fill();
 g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=1.5;g.beginPath();g.arc(x,y,r-1,0,7);g.stroke();
 g.strokeStyle='rgba(0,0,0,.18)';g.lineWidth=1;g.beginPath();g.arc(x,y,r-2.6,.2,2.9);g.stroke();
 if(r>=R*.8){if(c>5){g.font=(r*1.1)+'px serif';g.textAlign='center';g.fillStyle='#fff';g.fillText(c==6?'🌈':'💣',x,y+r*.38)}else if(c<5){g.fillStyle='rgba(255,255,255,.3)';poly(x,y+1,r*.32,[3,4,5,6,8][c],-1.57)}else{g.strokeStyle='rgba(0,0,0,.4)';g.lineWidth=1.5;g.beginPath();g.moveTo(x-r*.45,y-r*.1);g.lineTo(x-r*.05,y+r*.12);g.lineTo(x+r*.1,y-r*.3);g.moveTo(x-r*.05,y+r*.12);g.lineTo(x+r*.3,y+r*.45);g.stroke()}}
 g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.ellipse(x-r*.3,y-r*.42,r*.28,r*.15,-.6,0,7);g.fill();
 g.beginPath();g.arc(x+r*.38,y-r*.2,r*.07,0,7);g.fill();g.globalAlpha=1}
function txt(t,x,y,s,al,col){g.font='800 '+s+'px system-ui,sans-serif';g.textAlign=al;g.fillStyle=col||'#fff';g.fillText(t,x,y)}
function draw(){g.save();if(shk>.3&&!RMOD)g.translate((Math.random()-.5)*shk,(Math.random()-.5)*shk);draw0();g.restore()}
const WBGT=['#1d4f9e','#1c7a56','#4a1f8e','#136a78','#4a5a80','#8a3a20','#35146e','#8a3a78','#3a7ab0','#7a4a8a'];
function draw0(){
 const bg=g.createLinearGradient(0,0,0,H);bg.addColorStop(0,mode=='map'?WBGT[Math.min(9,(level-1)/20|0)]:'#2a1060');bg.addColorStop(1,'#0b0620');g.fillStyle=bg;g.fillRect(0,0,W,H);
 stars.forEach(s=>{g.fillStyle='rgba(255,255,255,'+(.3+.3*Math.sin(tick/30+s.s))+')';g.beginPath();g.arc(s.x,s.y,s.r,0,7);g.fill()});
 if(Q>0)bok.forEach(b=>{b.y-=b.v;if(b.y<-60)b.y=H+60;const bx=b.x+Math.sin(tick/90+b.s)*12,gr=g.createRadialGradient(bx,b.y,0,bx,b.y,b.r);gr.addColorStop(0,'rgba('+b.k+',.16)');gr.addColorStop(1,'rgba('+b.k+',0)');g.fillStyle=gr;g.beginPath();g.arc(bx,b.y,b.r,0,7);g.fill()});
 const gl=g.createRadialGradient(CX,CY,10,CX,CY,170);gl.addColorStop(0,'rgba(150,100,255,.25)');gl.addColorStop(1,'rgba(150,100,255,0)');g.fillStyle=gl;g.fillRect(0,CY-170,W,340);
 g.fillStyle='rgba(0,0,0,.35)';g.fillRect(0,0,W,TOP-4);
 dsc+=(score-dsc)*.15;txt('PONTOS '+Math.round(dsc),10,27,15,'left','#ffd23f');txt((mode=='map'?(boss?boss.e+' '+boss.n+' • ':'')+'NÍVEL '+level+(isElite(level)?' 🔥':'')+(tierOf(level)==1?' 🔶':tierOf(level)==2?' 🔴':'')+(boss?'':' • META '+goal):modeHud()),CX,27,12,'center');g.fillStyle='#fff';g.fillRect(W-30,14,5,16);g.fillRect(W-20,14,5,16);
 { // 🔊/🔇 botão de LIGAR/DESLIGAR o som (toque nele durante o jogo)
  const on=sv.snd||sv.mus,cx=W-72,cy=24;g.fillStyle='rgba(255,255,255,.92)';g.beginPath();g.arc(cx,cy,15,0,7);g.fill();
  g.fillStyle='#5b3fb0';g.beginPath();g.moveTo(cx-8,cy-3);g.lineTo(cx-4,cy-3);g.lineTo(cx+1,cy-7);g.lineTo(cx+1,cy+7);g.lineTo(cx-4,cy+3);g.lineTo(cx-8,cy+3);g.closePath();g.fill();
  g.strokeStyle=on?'#5b3fb0':'#e0245e';g.lineWidth=2;g.lineCap='round';g.beginPath();
  if(on){g.arc(cx+1,cy,5,-.9,.9);g.moveTo(cx+9.5,cy-6);g.arc(cx+1,cy,9.5,-.55,.55)}else{g.moveTo(cx+5,cy-4);g.lineTo(cx+11,cy+4);g.moveTo(cx+11,cy-4);g.lineTo(cx+5,cy+4)}
  g.stroke()}
 bar+=((mode=='time'?Math.min(1,tLeft/75):(boss?boss.hp/boss.max:Math.min(1,lvScore/goal)))-bar)*.12;g.fillStyle='rgba(255,255,255,.15)';g.beginPath();g.roundRect(10,33,W-20,6,3);g.fill();if(bar>.01){const b3=g.createLinearGradient(10,0,W-10,0);b3.addColorStop(0,boss?'#ff2e63':'#ff4d6d');b3.addColorStop(.5,boss?'#ff6b35':'#ffd23f');b3.addColorStop(1,boss?'#ffb347':'#3ddc84');g.fillStyle=b3;g.beginPath();g.roundRect(10,33,(W-20)*bar,6,3);g.fill()}
 if(!grid)return;
 if(boss){if(boss.hit>0)boss.hit--;g.save();g.globalAlpha=boss.hp>0?.2+(boss.hit>0?.25:0):0;g.font=(140+boss.hit*2)+'px serif';g.textAlign='center';g.textBaseline='middle';g.fillText(boss.e,CX+(boss.hit>0?Math.sin(tick)*5:0),TOP+185+Math.sin(tick/25)*8);g.restore()}const ly=TOP+LIM*RH;g.strokeStyle='rgba(255,77,109,'+(.35+.25*Math.sin(tick/10))+')';g.setLineDash([6,6]);g.beginPath();g.moveTo(0,ly);g.lineTo(W,ly);g.stroke();g.setLineDash([]);
 g.save();g.beginPath();g.rect(0,TOP-4,W,H);g.clip();
 for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)if(grid[r][c]>=0){const p=P(r,c),j=jg.get(r*COLS+c);let jx=0,jy=0,sc=1;if(j){const a=j.t/18;sc=1+(j.sc-1)*a*Math.cos((1-a)*8);jx=j.dx*Math.sin(a*Math.PI);jy=j.dy*Math.sin(a*Math.PI)}ball(p.x+jx,p.y+jy-dropY,grid[r][c],R*sc*(1+.025*Math.sin(tick/20+r*.7+c*1.1)))}
 g.restore();
 fall.forEach(f=>ball(f.x,f.y,f.c));
 bl.forEach(o=>{if(o.t<0)ball(o.x,o.y,o.c);else{const k=o.t/12;ball(o.x,o.y,o.c,R*(1+k*.55),1-k)}});
 rg.forEach(o=>{const k=o.t/14;g.globalAlpha=1-k;g.strokeStyle=o.c<0?'#fff':COL[o.c][0];g.lineWidth=3*(1-k)+.5;g.beginPath();g.arc(o.x,o.y,R*.6+k*R*1.6,0,7);g.stroke();g.globalAlpha=1});
 parts.forEach(p=>{g.globalAlpha=(p.l/(p.m||30))*(p.a||1);g.fillStyle=p.c<0?'#fff':COL[p.c][0];g.beginPath();g.arc(p.x,p.y,p.r||3,0,7);g.fill();g.globalAlpha=1});
 ft.forEach(o=>{const k=o.t/55,sc=o.t<8?.6+o.t*.05:1;g.save();g.translate(o.x,o.y-o.t*.7);g.scale(sc,sc);g.globalAlpha=Math.min(1,2-2*k);g.font='900 '+o.z+'px system-ui,sans-serif';g.textAlign='center';g.lineWidth=4;g.strokeStyle='rgba(20,5,50,.85)';g.strokeText(o.s,0,0);g.fillStyle=o.col;g.fillText(o.s,0,0);g.restore();g.globalAlpha=1});
 if(sv.gd&&state=='play'&&!shot){
  let x=CX,y=CY,dx=Math.cos(ang)*9,dy=-Math.sin(ang)*9;
  for(let i=0;i<46;i++){x+=dx;y+=dy;if(x<4+R||x>W-4-R)dx*=-1;if(y<TOP+R||hit(x,y))break;if(i>3){g.fillStyle='rgba(255,255,255,'+(aim?.75:.3)+')';g.beginPath();g.arc(x,y,2+Math.sin(tick/5-i*.6)*.9,0,7);g.fill()}}
  g.strokeStyle='rgba(255,255,255,'+(aim?.5:.2)+')';g.lineWidth=2;g.setLineDash([4,4]);g.beginPath();g.arc(x,y,R-1,0,7);g.stroke();g.setLineDash([]);
 }
 g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(CX,CY+30,44,9,0,0,7);g.fill();
 for(const sx of[-1,1]){g.fillStyle='#2b1a66';g.beginPath();g.arc(CX+sx*30,CY+14,15,0,7);g.fill();g.strokeStyle='#b9a0ff';g.lineWidth=3;g.stroke();g.save();g.translate(CX+sx*30,CY+14);g.rotate(sx*ang*2);g.strokeStyle='#8f6dff';g.lineWidth=2;for(let i=0;i<4;i++){g.rotate(Math.PI/4);g.beginPath();g.moveTo(-12,0);g.lineTo(12,0);g.stroke()}g.restore()}
 g.fillStyle='#3a2480';g.beginPath();g.roundRect(CX-34,CY+4,68,22,10);g.fill();g.strokeStyle='#b9a0ff';g.lineWidth=2;g.stroke();
 g.save();g.translate(CX,CY);g.rotate(Math.PI/2-ang);
 const bg2=g.createLinearGradient(-12,0,12,0);bg2.addColorStop(0,'#4a2fa0');bg2.addColorStop(.45,'#c9b5ff');bg2.addColorStop(1,'#4a2fa0');
 g.fillStyle=bg2;g.beginPath();g.roundRect(-11,-46+rec,22,46,6);g.fill();
 g.fillStyle='#ffd23f';g.fillRect(-12,-30+rec,24,4);g.fillRect(-12,-16+rec,24,3);
 g.fillStyle='#6a4bd0';g.beginPath();g.roundRect(-15,-52+rec,30,12,5);g.fill();g.strokeStyle='#d8caff';g.lineWidth=2;g.stroke();
 if(flash>0){const fg=g.createRadialGradient(0,-58,2,0,-58,28);fg.addColorStop(0,'rgba(255,255,255,.95)');fg.addColorStop(1,'rgba(255,210,63,0)');g.fillStyle=fg;g.beginPath();g.arc(0,-58,28,0,7);g.fill()}
 g.restore();
 g.fillStyle='#3a2480';g.beginPath();g.arc(CX,CY,24,0,7);g.fill();g.strokeStyle='#b9a0ff';g.lineWidth=3;g.stroke();
 g.fillStyle=COL[spc||cur][0];g.globalAlpha=.5+.25*Math.sin(tick/10);g.beginPath();g.arc(CX,CY,20,0,7);g.fill();g.globalAlpha=1;
 if((state=='play'||state=='pause')&&!shot||state=='won')ball(CX,CY,spc||cur,R);
 if(shot)ball(shot.x,shot.y,shot.c);
 g.fillStyle='rgba(255,255,255,.08)';g.beginPath();g.roundRect(8,CY-26,76,58,14);g.fill();
 txt('PRÓXIMA ⇄',46,CY-12,10,'center','#b9a8ff');ball(46,CY+13,nxt,13);
 for(let i=0;i<missLim;i++){g.fillStyle=i<miss?'#ff4d6d':'rgba(255,255,255,.2)';g.beginPath();g.arc(W-14-(missLim-1-i)*13,CY+10,4,0,7);g.fill()}
 txt('TETO DESCE',W-52,CY-8,10,'center','#b9a8ff');
 [[30,6,'🌈','iw'],[72,7,'💣','ib']].forEach(([x,t,e,k])=>{const on=spc==t;g.fillStyle=on?'rgba(255,210,63,.35)':'rgba(255,255,255,.12)';g.beginPath();g.arc(x,528,18,0,7);g.fill();g.strokeStyle=on?'#ffd23f':'rgba(255,255,255,.35)';g.lineWidth=2;g.stroke();g.font='18px serif';g.textAlign='center';g.fillStyle='#fff';g.fillText(e,x,535);g.fillStyle=sv[k]?'#ffd23f':'#ff4d6d';g.beginPath();g.arc(x+13,516,8,0,7);g.fill();g.fillStyle='#1a0b3d';g.font='800 10px system-ui';g.fillText(sv[k],x+13,520)});
}
// ---- Papel de parede animado da loja (muda de cor conforme a aba, parallax com a rolagem e chuva de moedas nas compras)
const RM=typeof matchMedia=='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches;
const bgC=$('shopBg'),bgX=bgC.getContext('2d'),shopEl=$('ovShop'),R1=(a,b)=>a+Math.random()*(b-a);
const PAL={hot:[26,11,74,74,20,112,58,26,42,160,80,255,255,90,170,255,170,60],coin:[40,20,5,110,60,10,60,30,5,255,200,60,255,140,40,255,235,140],item:[5,25,60,10,70,100,10,40,50,60,200,255,60,255,190,120,140,255],wheel:[50,5,70,120,15,110,60,10,50,255,80,200,255,200,60,100,120,255]};
let bgCur=PAL.hot.slice(),bgT=0,bgBoost=0,bgW=0,bgH=0,bgExtra=[],bgStar=null;
const bgCoins=Array.from({length:22},()=>({x:R1(0,1),y:R1(0,1),v:R1(.0006,.0016),s:R1(7,15),p:R1(0,6.28),w:R1(.02,.06),sw:R1(0,6.28)}));
const bgGems=Array.from({length:9},(_,i)=>({e:['💎','🎁','⭐','🎈','🪙','👑','🍀','🎯','🏆'][i],x:R1(.05,.95),y:R1(0,1),v:R1(.0002,.0005),s:R1(20,32),p:R1(0,6.28)}));
const bgSpk=Array.from({length:36},()=>({x:R1(0,1),y:R1(0,1),s:R1(2,6),p:R1(0,6.28),w:R1(.03,.09)}));
const bgBub=Array.from({length:12},()=>({x:R1(0,1),y:R1(0,1),r:R1(5,16),v:R1(.0003,.0009),p:R1(0,6.28)}));
function bgCoin(g,x,y,s,flip){const rx=s*Math.abs(flip)+1,cg=g.createLinearGradient(x-rx,y,x+rx,y);cg.addColorStop(0,'#fff3a8');cg.addColorStop(.5,'#ffc400');cg.addColorStop(1,'#b87800');
 g.globalAlpha=.88;g.fillStyle=cg;g.beginPath();g.ellipse(x,y,rx,s,0,0,7);g.fill();g.strokeStyle='#8a5a00';g.lineWidth=1;g.stroke();
 if(Math.abs(flip)>.45){g.strokeStyle='rgba(138,90,0,.6)';g.beginPath();g.ellipse(x,y,rx*.62,s*.62,0,0,7);g.stroke();g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.ellipse(x-rx*.3,y-s*.35,rx*.18,s*.12,-.6,0,7);g.fill()}g.globalAlpha=1}
function shopBg(){if(shopEl.classList.contains('hide'))return;if(Q<2&&(bgSk=(bgSk+1)%(Q?2:4)))return;
 const dpr=Math.min(window.devicePixelRatio||1,1.5),w=shopEl.clientWidth,h=shopEl.clientHeight;if(!w||!h)return;
 if(bgW!=w||bgH!=h){bgW=w;bgH=h;bgC.width=w*dpr;bgC.height=h*dpr}
 const g=bgX;g.setTransform(dpr,0,0,dpr,0,0);if(!RM)bgT++;const t=bgT,wrap=v=>((v%h)+h)%h,sc=$('shopList').scrollTop||0;
 const tg=PAL[shopTab]||PAL.hot;for(let i=0;i<18;i++)bgCur[i]+=(tg[i]-bgCur[i])*.05;
 const C=(i,a)=>'rgba('+(bgCur[i]|0)+','+(bgCur[i+1]|0)+','+(bgCur[i+2]|0)+','+(a===undefined?1:a)+')';
 const gr=g.createLinearGradient(0,0,0,h);gr.addColorStop(0,C(0));gr.addColorStop(.55,C(3));gr.addColorStop(1,C(6));g.fillStyle=gr;g.fillRect(0,0,w,h);
 for(let k=0;k<3;k++){const bx=w*(.5+.4*Math.sin(t/200+k*2.1)),by=h*(.3+.25*Math.cos(t/170+k*1.7)),b=g.createRadialGradient(bx,by,0,bx,by,w*.8);b.addColorStop(0,C(9+k*3,.38));b.addColorStop(1,C(9+k*3,0));g.fillStyle=b;g.fillRect(0,0,w,h)}
 g.save();g.translate(w/2,h*.12);g.rotate(t/600);for(let k=0;k<14;k++){g.rotate(Math.PI/7);g.fillStyle='rgba(255,240,180,'+(.05+.025*Math.sin(t/40+k))+')';g.beginPath();g.moveTo(0,0);g.lineTo(-30,h*1.3);g.lineTo(30,h*1.3);g.closePath();g.fill()}g.restore();
 for(let k=0;k<3;k++){const gy=h-30-k*14+Math.sin(t/60+k)*2,gg=g.createLinearGradient(0,gy-40,0,h);gg.addColorStop(0,'rgba(255,214,90,'+(.42-k*.1)+')');gg.addColorStop(1,'rgba(160,80,10,.1)');g.fillStyle=gg;g.beginPath();g.ellipse(w*(.25+k*.3),h+10,w*.5,70+k*6,0,Math.PI,2*Math.PI);g.fill()}
 bgBub.forEach(b=>{b.y-=b.v;if(b.y<-.05){b.y=1.05;b.x=Math.random()}const x=(b.x+Math.sin(t/50+b.p)*.02)*w,y=wrap(b.y*h-sc*.1);g.strokeStyle='hsla('+((t*2+b.p*60)%360)+',90%,75%,.55)';g.lineWidth=1.5;g.beginPath();g.arc(x,y,b.r,0,7);g.stroke();g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.arc(x-b.r*.35,y-b.r*.35,b.r*.18,0,7);g.fill()});
 bgSpk.forEach(k=>{const r=k.s*(.5+.5*Math.sin(t*k.w+k.p));if(r<.4)return;const x=k.x*w,y=wrap(k.y*h-sc*.2);g.fillStyle='rgba(255,255,220,.85)';g.beginPath();g.moveTo(x,y-2*r);g.lineTo(x+.4*r,y-.4*r);g.lineTo(x+2*r,y);g.lineTo(x+.4*r,y+.4*r);g.lineTo(x,y+2*r);g.lineTo(x-.4*r,y+.4*r);g.lineTo(x-2*r,y);g.lineTo(x-.4*r,y-.4*r);g.closePath();g.fill()});
 bgGems.forEach(m=>{m.y-=m.v;if(m.y<-.1){m.y=1.1;m.x=R1(.05,.95)}g.save();g.translate(m.x*w+Math.sin(t/60+m.p)*10,wrap(m.y*h-sc*.35));g.rotate(Math.sin(t/40+m.p)*.3);g.globalAlpha=.55;g.font=m.s+'px serif';g.textAlign='center';g.fillText(m.e,0,0);g.restore()});
 bgCoins.forEach(c=>{c.y+=c.v*(1+bgBoost/30);if(c.y>1.05){c.y=-.05;c.x=Math.random()}bgCoin(g,(c.x+Math.sin(t*.02+c.sw)*.03)*w,wrap(c.y*h-sc*.15),c.s,Math.cos(t*c.w+c.p))});
 if(bgBoost>0){bgBoost--;for(let k=0;k<2;k++)bgExtra.push({x:Math.random(),y:-.05,v:R1(.008,.016),s:R1(8,16),p:Math.random()*6.28,w:R1(.1,.2)})}
 bgExtra.forEach(c=>{c.y+=c.v;bgCoin(g,c.x*w,c.y*h,c.s,Math.cos(t*c.w+c.p))});bgExtra=bgExtra.filter(c=>c.y<1.1);
 if(!bgStar&&Math.random()<.004)bgStar={x:R1(.3,1),y:R1(0,.35),l:0};
 if(bgStar){bgStar.l+=.025;const hx=bgStar.x*w-bgStar.l*w*.9,hy=bgStar.y*h+bgStar.l*h*.45,sg=g.createLinearGradient(hx,hy,hx+70,hy-32);sg.addColorStop(0,'rgba(255,255,255,.95)');sg.addColorStop(1,'rgba(255,255,255,0)');g.strokeStyle=sg;g.lineWidth=2.5;g.lineCap='round';g.beginPath();g.moveTo(hx,hy);g.lineTo(hx+70,hy-32);g.stroke();if(bgStar.l>1)bgStar=null}
 const vg=g.createRadialGradient(w/2,h/2,h*.25,w/2,h/2,h*.75);vg.addColorStop(0,'rgba(5,0,20,0)');vg.addColorStop(1,'rgba(5,0,20,.55)');g.fillStyle=vg;g.fillRect(0,0,w,h)}
// ===== LAÇO PRINCIPAL =====
// A lógica do jogo roda em PASSO FIXO (60 atualizações por segundo), igual em qualquer celular (60, 90 ou 120 Hz).
// Um medidor de FPS reduz os efeitos sozinho (modo "Automático") se o aparelho estiver lento.
const STEP=1000/60;let accT=0,lastF=0,fpsEma=16.7,lowN=0,Q=2,bgSk=0,RMOD=false;
function QP(){return[.3,.65,1][Q]*(RMOD?.4:1)} // multiplicador de partículas por qualidade
function perf(dt){fpsEma+=(Math.min(dt,100)-fpsEma)*.05;if(sv.gq=='auto'&&Q>0&&(state=='play'||state=='menu')){if(fpsEma>27)lowN++;else lowN=Math.max(0,lowN-2);if(lowN>150){lowN=0;Q--;sv.qa=Q;store();toast('Modo econômico ativado 🔋')}}}
(function loop(now){const dt=Math.min(100,(now-lastF)||STEP);lastF=now;accT+=dt;let n=0;while(accT>=STEP&&n<5){update();accT-=STEP;n++}if(n==5)accT=0;draw();shopBg();perf(dt);requestAnimationFrame(loop)})(0);
(function(){const L=$('ovLoad'),bx=$('lbub'),C=[['#ff4d6d','#a3123a'],['#3ea6ff','#0b4fa8'],['#3ddc84','#0f7a41'],['#ffd23f','#b07a00'],['#a66bff','#4b1fa8']];
for(let i=0;i<18;i++){const d=document.createElement('span'),c=C[i%5],z=18+Math.random()*34;d.className='dot fb';d.style.cssText='--c:'+c[0]+';--d:'+c[1]+';width:'+z+'px;height:'+z+'px;left:'+Math.random()*92+'%;animation-duration:'+(5+Math.random()*5)+'s;animation-delay:-'+Math.random()*8+'s';bx.appendChild(d)}
let p=0;const bar=$('lfill'),tx=$('ltxt'),iv=setInterval(()=>{p=Math.min(100,p+1+Math.random()*3);bar.style.width=p+'%';tx.textContent='Carregando... '+Math.floor(p)+'%';if(p>=100){clearInterval(iv);tx.textContent='Toque para começar';L.classList.add('ready')}},60);
L.onclick=()=>{if(!L.classList.contains('ready'))return;L.classList.add('out');startMusic();setTimeout(()=>L.classList.add('hide'),400)}})();
let lvIv=null;
(function(){const bx=$('lvbub'),C=[['#ff4d6d','#a3123a'],['#3ea6ff','#0b4fa8'],['#3ddc84','#0f7a41'],['#ffd23f','#b07a00'],['#a66bff','#4b1fa8']];
for(let i=0;i<14;i++){const d=document.createElement('span'),c=C[i%5],z=18+Math.random()*34;d.className='dot fb';d.style.cssText='--c:'+c[0]+';--d:'+c[1]+';width:'+z+'px;height:'+z+'px;left:'+Math.random()*92+'%;animation-duration:'+(5+Math.random()*5)+'s;animation-delay:-'+Math.random()*8+'s';bx.appendChild(d)}})();
function showLoad(l){state='load';aim=false;if(Lumi)Lumi.tip(tipFor(l));const L=$('ovLoadLv'),f=$('lvFill'),tx=$('lvTxt');
 $('lvTitle').textContent='Fase '+l+(isElite(l)?' 🔥':'')+(mode=='map'&&tierOf(l)==1?' 🔶':mode=='map'&&tierOf(l)==2?' 🔴':'');
 $('lvRules').innerHTML=['🎯 Faça <b>'+goal+' pontos</b> (barra amarela) ou limpe todas as bolinhas','🫧 Junte <b>3 ou mais</b> da mesma cor para estourar; grupos soltos caem e valem mais','⚠️ A cada <b>'+missLim+' tiros</b> sem estourar, o teto desce','❌ Se as bolinhas passarem da <b>linha vermelha</b>, você perde','⭐ Use poucos tiros para ganhar 3 estrelas'].map(t=>'<li>'+t+'</li>').join('');
 if(isElite(l))$('lvRules').insertAdjacentHTML('afterbegin','<li>🔥 <b>FASE ELITE!</b> Mais fileiras, bolinhas de <b>pedra</b> 🪨 (só caem quando ficam soltas) e o teto desce mais rápido</li>');
 if(mode=='map'&&tierOf(l)==1)$('lvRules').insertAdjacentHTML('afterbegin','<li>🔶 <b>Etapa MEIO-DIFÍCIL:</b> mais fileiras, algumas pedras e metas maiores</li>');
 if(mode=='map'&&tierOf(l)==2)$('lvRules').insertAdjacentHTML('afterbegin','<li>🔴 <b>Etapa DIFÍCIL:</b> muitas pedras, o teto desce rápido e a meta é alta!</li>');
 if(mode=='map'&&boss)$('lvRules').insertAdjacentHTML('afterbegin','<li>👹 <b>CHEFÃO '+boss.n+'!</b> Estoure e derrube bolinhas para tirar a vida dele ('+boss.hp+' ❤️). A cada <b>'+boss.every+' tiros</b> ele ataca'+(boss.k=='heal'?' e se cura':'')+'!</li>');L.classList.remove('hide','out');f.style.width='0';tx.textContent='Carregando... 0%';let p=0;clearInterval(lvIv);
 lvIv=setInterval(()=>{p=Math.min(100,p+1+Math.random()*2);f.style.width=p+'%';tx.textContent='Carregando... '+Math.floor(p)+'%';
  if(p>=100){clearInterval(lvIv);L.classList.add('out');setTimeout(()=>{L.classList.add('hide');state='play'},350)}},60)}

// ===== ECONOMIA: vidas, moedas, loja, anúncios (compras e anúncios SIMULADOS em TEST_MODE) =====
const TEST_MODE=true; // ⚠️ coloque false quando ligar a cobrança real do Google Play e o AdMob
const REG=20*60*1000;
const PROD=[{id:'coins_500',e:'🪙',n:'500 moedas',pr:'R$ 4,99',coins:500},{id:'coins_1500',e:'💰',n:'1.500 moedas',d:'Mais popular',pr:'R$ 9,99',coins:1500},{id:'coins_4000',e:'🏦',n:'4.000 moedas',d:'Melhor valor',pr:'R$ 19,99',coins:4000},{id:'no_ads',e:'🚫',n:'Remover anúncios',d:'Compra única',pr:'R$ 14,99',noads:1,once:1},{id:'premium',e:'👑',n:'Pacote Premium',d:'Sem anúncios + 2.000 🪙 + 5 🌈 + 5 💣',pr:'R$ 24,99',coins:2000,iw:5,ib:5,noads:1,once:1}];
const ITEMS=[{k:'life',e:'❤️',n:'+1 vida',c:50},{k:'full',e:'💖',n:'Encher as vidas',c:200},{k:'iw',e:'🌈',n:'3 Coringas',d:'Vira a cor das vizinhas',c:90},{k:'ib',e:'💣',n:'3 Bombas',d:'Explode as bolinhas em volta',c:120},{k:'il',e:'🔦',n:'3 Miras Laser',d:'Guia longo com rebotes durante a fase',c:80}];
const Billing={async buy(id){if(TEST_MODE)return confirm('MODO TESTE — nenhuma cobrança real.\nSimular a compra?');if(window.PlayBilling&&PlayBilling.buy)return await PlayBilling.buy(id);alert('Compras ainda não configuradas neste app.');return false},
 async restore(){if(!TEST_MODE&&window.PlayBilling&&PlayBilling.restore)return await PlayBilling.restore();return Object.keys(sv.pu)}};
// 📺 Camada de anúncios: usa o AdMob de verdade (via ads.js) quando o app roda dentro do Android; no navegador mostra anúncio SIMULADO.
const Ads={inter(next){if(sv.noads||!AdBridge.canInter())return next();AdBridge.native()?AdBridge.showInter().then(()=>next()):adShow(3,false,next)},
 reward(cb,back){if(!AdBridge.native())return adShow(5,true,cb,back);AdBridge.showReward().then(ok=>{if(back)go(back);if(ok)cb&&cb();else toast('Anúncio indisponível agora. Tente de novo 📺')})}};
function adShow(sec,rw,cb,back){go('ovAd');let t=sec;const b=$('adBtn');b.disabled=true;b.textContent='Aguarde '+t+'s';$('adTxt').textContent=rw?'Assista até o fim para ganhar a recompensa':'Anúncio';
 const iv=setInterval(()=>{t--;if(t>0){b.textContent='Aguarde '+t+'s';return}clearInterval(iv);b.disabled=false;b.textContent=rw?'Receber recompensa 🎁':'Continuar ▶'},1000);
 b.onclick=()=>{if(back)go(back);cb&&cb()}}
function toast(t){const e=$('toast');e.textContent=t;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),1800)}
const fmt=ms=>{const x=Math.max(0,Math.ceil(ms/1000));return Math.floor(x/60)+':'+String(x%60).padStart(2,'0')};
function tickLives(){const n=Date.now();if(sv.lives<5&&!sv.nx)sv.nx=n+REG;if(sv.lives<5&&n>=sv.nx){const g=1+Math.floor((n-sv.nx)/REG);sv.lives=Math.min(5,sv.lives+g);sv.nx=sv.lives<5?sv.nx+g*REG:0;store()}if(sv.lives>=5)sv.nx=0}
function loseLife(){tickLives();if(sv.lives<=0)return;sv.lives--;if(!sv.nx)sv.nx=Date.now()+REG;store();refreshTop()}
function giveLife(n){sv.lives=Math.min(5,sv.lives+n);if(sv.lives>=5)sv.nx=0;store();refreshTop()}
function spend(n){if(sv.coins<n){sfx('no');toast('Moedas insuficientes 🪙');return false}sv.coins-=n;store();refreshTop();if(Bus)Bus.emit('spend',n);return true}
const today=()=>{const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()};
const yest=()=>{const d=new Date(Date.now()-864e5);return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()};
const dailyAvail=()=>sv.dl!==today();
const DAILY=[20,30,40,50,70,90,150];
function dayIdx(){return sv.dl===yest()?sv.ds%7:sv.dl===today()?(sv.ds-1+7)%7:0}
function openDaily(){const di=dayIdx(),got=!dailyAvail();$('dGrid').innerHTML=DAILY.map((c,i)=>'<div class="dc '+(i<di||(got&&i==di)?'done':i==di?'now':'')+'"><span>Dia '+(i+1)+'</span><span>'+(i==6?'🎁':'🪙')+' '+c+'</span></div>').join('');$('bClaim').disabled=got;$('bClaim').textContent=got?'Volte amanhã!':'Resgatar +'+DAILY[di]+' 🪙';go('ovDaily')}
function claimDaily(){if(!dailyAvail())return;const di=dayIdx();sv.coins+=DAILY[di];if(di==6){sv.iw++;sv.ib++;sv.il=(sv.il||0)+1;toast('Dia 7! +🌈 +💣 +🔦')}sv.ds=di+1;sv.dl=today();store();sfx('win');refreshTop();openDaily()}
function openLives(l){pendL=l||0;go('ovLives');updLives()}
function updLives(){$('lvInfo').textContent='Próxima vida em '+fmt(sv.nx-Date.now())+' • você tem '+sv.coins+' 🪙'}
function refreshTop(){tickLives();$('chLife').innerHTML='❤️ '+sv.lives+'/5'+(sv.lives<5&&sv.nx?'<small>+1 em '+fmt(sv.nx-Date.now())+'</small>':'');$('chCoin').innerHTML='🪙 '+sv.coins;$('dBadge').style.display=dailyAvail()?'block':'none';
 if(!$('ovLives').classList.contains('hide')){if(sv.lives>0&&pendL){startLevel(pendL)}else updLives()}if(!$('ovShop').classList.contains('hide')&&!balT)balUpd()}
function useBoost(t){const k=t==6?'iw':'ib';if(spc==t){spc=0;sfx('no');return}if(!sv[k]){sfx('no');toast('Sem '+(t==6?'coringa':'bomba')+'! Compre na loja 🛒');return}spc=t;sfx('pop')}
let shopTab='hot',wheelRot=0,spinning=false,balV=0,balT=null;
const own=p=>p.once&&sv.pu[p.id];
const buyBtn=p=>'<button class="buy real" data-p="'+p.id+'"'+(own(p)?' disabled':'')+'>'+(own(p)?'✔ Comprado':p.pr)+'</button>';
const DEALS=[{n:'Kit Poderes',e:'⚡',d:'5 🌈 Coringas + 5 💣 Bombas',c:240,w:350,iw:5,ib:5},{n:'Kit Bombardeiro',e:'💥',d:'8 💣 Bombas',c:200,w:320,ib:8},{n:'Kit Arco-íris',e:'🌈',d:'8 🌈 Coringas',c:170,w:240,iw:8},{n:'Vida Dupla',e:'💖',d:'Vidas cheias + 3 🌈 + 3 💣',c:300,w:410,life:5,iw:3,ib:3}];
const deal=()=>{const d=new Date();return DEALS[(d.getFullYear()*372+d.getMonth()*31+d.getDate())%DEALS.length]};
const PR=[{e:'🪙',s:'20',t:'20 moedas',coins:20},{e:'💣',s:'1',t:'1 bomba',ib:1},{e:'🪙',s:'50',t:'50 moedas',coins:50},{e:'🌈',s:'1',t:'1 coringa',iw:1},{e:'🔦',s:'2',t:'2 miras laser',il:2},{e:'❤️',s:'1',t:'1 vida',life:1},{e:'💰',s:'100',t:'100 moedas',coins:100},{e:'🌈',s:'2',t:'2 coringas',iw:2}];
function wheelSvg(){const cl=['#ff4d6d','#3ea6ff','#3ddc84','#ffd23f','#a66bff','#ff8a3d','#2ec4b6','#f15bb5'],P=(a,r)=>(130+r*Math.sin(a)).toFixed(1)+' '+(130-r*Math.cos(a)).toFixed(1);
 let o='<svg id="wheel" viewBox="0 0 260 260" style="transform:rotate('+wheelRot+'deg)"><circle cx="130" cy="130" r="127" fill="#1a0b3d" stroke="#ffd23f" stroke-width="6"/>';
 PR.forEach((p,i)=>{const a1=i*Math.PI/4,a2=(i+1)*Math.PI/4;o+='<path d="M130 130 L'+P(a1,118)+' A118 118 0 0 1 '+P(a2,118)+' Z" fill="'+cl[i]+'" stroke="#fff" stroke-width="2"/><g transform="rotate('+(i*45+22.5)+' 130 130)"><text x="130" y="52" text-anchor="middle" font-size="26">'+p.e+'</text><text x="130" y="74" text-anchor="middle" font-size="14" font-weight="900" fill="#fff" stroke="#1a0b3d" stroke-width="3" paint-order="stroke">'+p.s+'</text></g>'});
 return o+'<circle cx="130" cy="130" r="22" fill="#ffd23f" stroke="#fff" stroke-width="4"/><text x="130" y="138" text-anchor="middle" font-size="22">🎡</text></svg>'}
const spinBtns=()=>sv.sp!==today()?'<button class="buy big" data-k="spin">GIRAR GRÁTIS 🎡</button><small>1 giro grátis por dia</small>':'<button class="buy big" data-k="spinad">GIRAR 📺 (anúncio)</button><small>O giro grátis volta amanhã</small>';
function buildShop(){
 let h=TEST_MODE?'<div class="sec" style="color:#ff8a3d">⚠️ MODO TESTE: compras e anúncios simulados</div>':'';
 const pr=PROD.find(p=>p.id=='premium'),nr=PROD.find(p=>p.id=='no_ads'),dl=deal(),dd=sv.dd===today();
 if(shopTab=='hot'){
  h+='<div class="hero"><span class="rib">MELHOR OFERTA</span><h3>👑 Pacote Premium</h3><div class="items"><span class="bobE">🚫</span><span class="bobE" style="animation-delay:.2s">🪙</span><span class="bobE" style="animation-delay:.4s">🌈</span><span class="bobE" style="animation-delay:.6s">💣</span></div><small>Sem anúncios para sempre + 2.000 🪙 + 5 🌈 + 5 💣</small>'+buyBtn(pr)+'</div>';
  h+='<div class="card deal"><span class="bdg">OFERTA DO DIA</span><div class="ce bobE">'+dl.e+'</div><div class="ct"><b>'+dl.n+'</b><small>'+dl.d+'</small><small>Normal: <s>'+dl.w+' 🪙</s> • acaba em <span id="dealCd"></span></small></div><button class="buy" data-k="deal"'+(dd?' disabled':'')+'>'+(dd?'Esgotado':dl.c+' 🪙')+'</button></div>';
  h+='<div class="card"><div class="ce bobE">📺</div><div class="ct"><b>Ganhe 25 🪙</b><small>Assista a um anúncio</small></div><button class="buy" data-k="adc">Assistir</button></div>';
  h+='<div class="card"><div class="ce bobE">🚫</div><div class="ct"><b>Remover anúncios</b><small>Compra única</small></div>'+buyBtn(nr)+'</div>';
  h+='<button class="btn2" data-k="rest" style="margin-top:4px">Restaurar compras</button>'}
 else if(shopTab=='coin'){
  h+='<div class="sec">PACOTES DE MOEDAS</div>'+PROD.filter(p=>p.coins&&!p.noads).map((p,i)=>'<div class="card">'+(p.d?'<span class="bdg">'+p.d.toUpperCase()+'</span>':'')+'<div class="ce bobE" style="font-size:'+(26+i*7)+'px;animation-delay:'+i*.3+'s">'+p.e+'</div><div class="ct"><b>'+p.n+'</b><small>Use na loja, nos poderes e nas vidas</small></div>'+buyBtn(p)+'</div>').join('')+'<button class="btn2" data-k="rest" style="margin-top:4px">Restaurar compras</button>'}
 else if(shopTab=='item'){
  h+='<div class="sec">VIDAS E PODERES (PAGOS COM MOEDAS)</div>'+ITEMS.map(i=>{const q=i.k=='iw'?'Você tem: '+sv.iw:i.k=='ib'?'Você tem: '+sv.ib:i.k=='il'?'Você tem: '+sv.il:'Vidas: '+sv.lives+'/5';return'<div class="card"><div class="ce bobE">'+i.e+'</div><div class="ct"><b>'+i.n+'</b>'+(i.d?'<small>'+i.d+'</small>':'')+'<small style="color:#ffd23f">'+q+'</small></div><button class="buy" data-k="'+i.k+'">'+i.c+' 🪙</button></div>'}).join('')}
 else{
  wheelRot%=360;h+='<div class="sec" style="text-align:center">🎡 ROLETA DA SORTE</div><div class="wheelBox"><span class="ptr">🔻</span>'+wheelSvg()+'</div><div id="spinBtns">'+spinBtns()+'</div>'}
 $('shopList').innerHTML=h;document.querySelectorAll('#shopTabs button').forEach(b=>b.classList.toggle('on',b.dataset.t==shopTab));refreshTop();balUpd()}
function openShop(t){shopTab=typeof t=='string'?t:'hot';buildShop();go('ovShop')}
function balUpd(){const e=$('shopBal');clearInterval(balT);balT=null;
 const draw=()=>{e.innerHTML='<span class="pill">🪙 '+Math.round(balV)+'</span><span class="pill">❤️ '+sv.lives+'/5</span>';const c=$('dealCd');if(c){const n=new Date(),x=Math.max(0,Math.floor((new Date(n.getFullYear(),n.getMonth(),n.getDate()+1)-n)/1000));c.textContent=Math.floor(x/3600)+':'+String(Math.floor(x%3600/60)).padStart(2,'0')+':'+String(x%60).padStart(2,'0')}};
 if(sv.coins>balV&&balV>0){e.classList.remove('bump');void e.offsetWidth;e.classList.add('bump')}
 balT=setInterval(()=>{balV+=(sv.coins-balV)*.25;if(Math.abs(sv.coins-balV)<1){balV=sv.coins;clearInterval(balT);balT=null}draw()},30);draw()}
function burstFx(em){bgBoost=90;const o=$('ovShop');for(let i=0;i<16;i++){const s=document.createElement('span');s.className='fx';s.textContent=em;s.style.cssText='--dx:'+((Math.random()-.5)*320|0)+'px;--dy:'+(-(60+Math.random()*240)|0)+'px;left:50%;top:62%;font-size:'+(16+Math.random()*18|0)+'px';o.appendChild(s);setTimeout(()=>s.remove(),1300)}}
function dealBuy(){const d=deal();if(sv.dd===today()){toast('Oferta já comprada hoje');return}if(!spend(d.c))return;sv.iw+=d.iw||0;sv.ib+=d.ib||0;if(d.life)giveLife(d.life);sv.dd=today();store();sfx('win');vib([40,30,40]);burstFx('✨');toast('Oferta adquirida! 🎉');buildShop()}
function prize(p){sv.coins+=p.coins||0;sv.iw+=p.iw||0;sv.ib+=p.ib||0;sv.il=(sv.il||0)+(p.il||0);if(p.life)giveLife(p.life);store();sfx('win');vib([40,30,40]);burstFx(p.e);toast('Você ganhou: '+p.t+' '+p.e);balUpd();const b=$('spinBtns');if(b)b.innerHTML=spinBtns()}
function spinGo(ad){if(spinning)return;if(!ad&&sv.sp===today()){toast('A roleta grátis de hoje já foi usada');return}
 const run=()=>{if(!ad){sv.sp=today();store()}const i=Math.random()*PR.length|0;wheelRot=Math.ceil(wheelRot/360)*360+1800+((360-(i*45+22.5))%360)+(Math.random()-.5)*28;spinning=true;$('wheel').style.transform='rotate('+wheelRot+'deg)';sfx('pop');setTimeout(()=>{spinning=false;prize(PR[i])},4300)};
 if(ad)Ads.reward(run,'ovShop');else run()}
function grant(p){sv.coins+=p.coins||0;sv.iw+=p.iw||0;sv.ib+=p.ib||0;if(p.noads)sv.noads=1;if(p.once)sv.pu[p.id]=1;store();sfx('win');vib([40,30,40]);toast('Compra concluída! ✔');burstFx(p.coins?'🪙':'🎁');buildShop()}
async function shopClick(e){const b=e.target.closest&&e.target.closest('button');if(!b)return;const k=b.getAttribute('data-k'),pid=b.getAttribute('data-p');
 if(k=='deal'){dealBuy();return}if(k=='spin'||k=='spinad'){spinGo(k=='spinad');return}
 if(pid){const p=PROD.find(x=>x.id==pid);if(await Billing.buy(pid))grant(p);return}
 if(k=='adc'){Ads.reward(()=>{sv.coins+=25;store();burstFx('🪙');toast('+25 🪙');buildShop()},'ovShop');return}
 if(k=='rest'){const l=await Billing.restore();l.forEach(id=>{const p=PROD.find(x=>x.id==id);if(p&&p.noads)sv.noads=1});store();toast('Compras restauradas ✔');buildShop();return}
 const it=ITEMS.find(x=>x.k==k);if(!it)return;if(k=='life'&&sv.lives>=5){toast('Vidas já estão cheias ❤️');return}
 if(!spend(it.c))return;if(k=='life')giveLife(1);else if(k=='full')giveLife(5);else{sv[k]+=3;store()}sfx('pop');burstFx('✨');toast('Comprado! ✔');buildShop()}
$('shopList').onclick=shopClick;
$('bShop').onclick=$('chCoin').onclick=openShop;$('bDaily').onclick=openDaily;$('bClaim').onclick=claimDaily;$('chLife').onclick=()=>{if(sv.lives<5)openLives(0);else toast('Vidas cheias ❤️❤️❤️❤️❤️')};
$('bLifeCoin').onclick=()=>{if(spend(50)){giveLife(1);if(pendL)startLevel(pendL);else go('ovStart')}};
$('bLifeAd').onclick=()=>Ads.reward(()=>{giveLife(1);toast('+1 ❤️');if(pendL)startLevel(pendL);else go('ovStart')},'ovLives');
$('bLifeShop').onclick=()=>openShop('item');
$('shopTabs').onclick=e=>{const b=e.target.closest&&e.target.closest('button');if(!b)return;shopTab=b.dataset.t;sfx('pop');buildShop()};
// ====== MODOS DE JOGO, MISSÕES DIÁRIAS, ESTILOS E RECORDES ======
const MODEP={inf:{rows:5,nc:4,goal:1e9,miss:6},time:{rows:6,nc:4,goal:1e9,miss:6},zen:{rows:5,nc:4,goal:1e9,miss:8},daily:{rows:8,nc:5,goal:900,miss:4,stone:.08}};
const MODES={inf:{e:'♾️',n:'Modo Infinito',d:['Sem meta: aguente o máximo que conseguir','O teto desce cada vez mais rápido conforme você pontua','Limpou tudo? Ganhe bônus e novas fileiras'],r:'Ganhe moedas pela pontuação (até 80 🪙)'},
 time:{e:'⏱️',n:'Relâmpago',d:['Você tem 75 segundos','Estoure 5 ou mais de uma vez para ganhar tempo extra','Faça o máximo de pontos!'],r:'Ganhe moedas pela pontuação (até 80 🪙)'},
 zen:{e:'🧘',n:'Modo Zen',d:['Sem vidas, sem pressão e sem fim','Se as bolinhas descerem demais, as de baixo estouram sozinhas','Perfeito para relaxar'],r:'Sem recompensas, só diversão'},
 daily:{e:'📅',n:'Desafio Diário',d:['Um tabuleiro novo por dia, o mesmo para todos','Meta: 900 pontos, 5 cores e bolinhas de pedra','O teto desce a cada 4 erros'],r:'Recompensa: 100 🪙 na 1ª vitória do dia'}};
function seedRand(){rngS=rngS+0x6D2B79F5|0;let t=Math.imul(rngS^rngS>>>15,1|rngS);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}
function modeHud(){return mode=='inf'?'♾️ INFINITO':mode=='time'?'⏱️ '+Math.ceil(tLeft)+'s':mode=='zen'?'🧘 ZEN':'📅 DESAFIO • META '+goal}
function openMode(m){const M=MODES[m];$('mmE').textContent=M.e;$('mmN').textContent=M.n;$('mmD').innerHTML=M.d.map(t=>'<li>'+t+'</li>').join('');$('mmR').textContent=M.r;
 $('mmB').textContent=m=='zen'?'':m=='daily'?(sv.dw===today()?'Hoje: concluído ✔':'Hoje: ainda não concluído'):'🏆 Seu recorde: '+(sv.bm[m]||0);$('mmGo').onclick=()=>{sfx('pop');startMode(m)};go('ovMode')}
function startMode(m){mode=m;level=1;score=0;spc=0;tLeft=75;lastT=Date.now();newLevel();hideAll();showLoad(1);$('lvTitle').textContent=MODES[m].e+' '+MODES[m].n;$('lvRules').innerHTML=MODES[m].d.map(t=>'<li>'+t+'</li>').join('')}
function refillRows(){for(let k=0;k<4;k++){const row=Array(COLS).fill(-1);grid.unshift(row);grid.pop();off^=1;rowFill(row,0)}dropY=RH*3;shk=5;add(300);ftx(CX,TOP+150,'TABULEIRO LIMPO! +300','#ffd23f',20);sfx('win')}
function zenRelief(){let i=0;for(let r=LIM-5;r<ROWS;r++)for(let c=0;c<COLS;c++)if(grid[r][c]>=0){const p=P(r,c);bl.push({x:p.x,y:p.y,c:grid[r][c],t:-(i++>>1)-1});grid[r][c]=-1}ftx(CX,TOP+150,'Respire fundo… 🧘','#9ef0c0',20);shk=3}
function timeUp(){if(state!='play')return;state='over';modeEnd();meltAll();sfx('lose');vib([60,40,60]);$('endScore').textContent=score;setTimeout(()=>show('ovEnd'),900)}
function modeEnd(){if(Bus)Bus.emit('mode');const g=mode=='daily'?0:Math.min(80,Math.floor(score/150)),nb=score>(sv.bm[mode]||0);sv.coins+=g;if(nb)sv.bm[mode]=score;store();trk('mode',1);
 $('endTitle').textContent=mode=='time'?'Tempo esgotado! ⏱️':'Fim de jogo';$('endLife').textContent=(g?'+'+g+' 🪙':'')+(nb&&mode!='daily'?' • NOVO RECORDE! 🏆':'');$('endBest').textContent=mode=='daily'?'Tente de novo!':'Recorde: '+sv.bm[mode]}
function dailyWin(){const first=sv.dw!==today(),gain=first?100:20;sv.coins+=gain;sv.dw=today();store();trk('win',1);trk('mode',1);if(Lumi)Lumi.stars=2;if(Bus)Bus.emit('win',2);$('winStars').textContent='📅';$('winTxt').textContent=score+' pontos • +'+gain+' 🪙';$('bNext').style.display='none';sfx('win');vib([40,30,40])}
// missões
const MIS=[{id:'pop',e:'🫧',t:'Estourar bolinhas',n:60,r:30},{id:'fall',e:'🍂',t:'Derrubar bolinhas soltas',n:25,r:30},{id:'win',e:'🏆',t:'Vencer fases',n:2,r:40},{id:'mode',e:'🎮',t:'Jogar partidas nos modos especiais',n:2,r:40}];
const claimable=x=>(sv.mp[x.id]||0)>=x.n&&!sv.mc[x.id];
function mDay(){if(sv.mday!==today()){sv.mday=today();sv.mp={};sv.mc={}}}
function trk(k,n){if(!n)return;mDay();const x=MIS.find(m=>m.id==k),b=sv.mp[k]||0;sv.mp[k]=b+n;if(x&&b<x.n&&sv.mp[k]>=x.n){ftx(CX,TOP+90,'🏅 Missão cumprida!','#ffd23f',18);store()}}
function openMiss(){mDay();$('missList').innerHTML=MIS.map(x=>{const p=Math.min(x.n,sv.mp[x.id]||0),c=sv.mc[x.id],ok=p>=x.n;return'<div class="card"><div class="ce">'+x.e+'</div><div class="ct"><b>'+x.t+'</b><div class="pbar"><i style="width:'+(p/x.n*100)+'%"></i></div><small>'+p+'/'+x.n+' • +'+x.r+' 🪙</small></div>'+(c?'<button class="buy" disabled>✔</button>':ok?'<button class="buy real" data-mi="'+x.id+'">Coletar</button>':'<button class="buy" disabled>'+p+'/'+x.n+'</button>')+'</div>'}).join('')+'<div class="sec" style="text-align:center">'+(sv.mc.all?'🎁 Bônus do dia recebido!':'🎁 Complete as 4 missões: +1 🌈 +1 💣')+'</div>';go('ovMiss')}
function claimMis(id){const x=MIS.find(m=>m.id==id);if(!x||!claimable(x))return;sv.mc[id]=1;sv.coins+=x.r;if(MIS.every(m=>sv.mc[m.id])&&!sv.mc.all){sv.mc.all=1;sv.iw++;sv.ib++;toast('Bônus: +1 🌈 +1 💣')}else toast('+'+x.r+' 🪙');store();sfx('win');vib([30,20,30]);refreshTop();openMiss()}
// estilos
const SKINS=[{n:'Vidro',e:'🫧',d:'O clássico brilhante',c:0},{n:'Neon',e:'🌃',d:'Núcleo escuro e anel de luz',c:150},{n:'Doce',e:'🍬',d:'Listras de bala colorida',c:200},{n:'Gemas',e:'💎',d:'Facetas de pedra preciosa',c:250}];
function openSkin(){$('skinList').innerHTML=SKINS.map((k,i)=>{const own=sv.sk[i],on=sv.skin==i;return'<div class="card'+(on?' deal':'')+'">'+(on?'<span class="bdg">EM USO</span>':'')+'<div class="ce bobE">'+k.e+'</div><div class="ct"><b>'+k.n+'</b><small>'+k.d+'</small></div><button class="buy'+(own&&!on?' real':'')+'" data-sk="'+i+'"'+(on?' disabled':'')+'>'+(on?'✔':own?'Usar':k.c+' 🪙')+'</button></div>'}).join('');go('ovSkin')}
function pickSkin(i){const k=SKINS[i];if(!k)return;if(!sv.sk[i]){if(!spend(k.c))return;sv.sk[i]=1;sfx('win')}sv.skin=i;store();sfx('pop');openSkin()}
function skinFx(x,y,c,r){const k=sv.skin;g.save();
 if(k==1){g.fillStyle='rgba(8,4,30,.62)';g.beginPath();g.arc(x,y,r-4,0,7);g.fill();g.strokeStyle=COL[c][0];g.lineWidth=2.5;g.beginPath();g.arc(x,y,r-2.5,0,7);g.stroke();g.globalAlpha*=.35;g.lineWidth=6;g.beginPath();g.arc(x,y,r-4,0,7);g.stroke()}
 else if(k==2){g.beginPath();g.arc(x,y,r-1,0,7);g.clip();g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=r*.28;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(x-r+i*r*.6,y+r);g.lineTo(x+r+i*r*.6,y-r);g.stroke()}}
 else if(k==3){g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=1;g.beginPath();for(let i=0;i<6;i++){const a=i*Math.PI/3+.5;g.moveTo(x,y);g.lineTo(x+Math.cos(a)*(r-1),y+Math.sin(a)*(r-1))}g.stroke();g.beginPath();for(let i=0;i<6;i++){const a=i*Math.PI/3+.5;g.lineTo(x+Math.cos(a)*r*.55,y+Math.sin(a)*r*.55)}g.closePath();g.stroke();g.fillStyle='rgba(255,255,255,.15)';g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(.5)*(r-1),y+Math.sin(.5)*(r-1));g.lineTo(x+Math.cos(.5+Math.PI/3)*(r-1),y+Math.sin(.5+Math.PI/3)*(r-1));g.closePath();g.fill()}
 g.restore()}
// recordes, som rápido, convite
function openRec(){const t=Object.values(sv.st).reduce((a,b)=>a+b,0),B=sv.bm,rows=[['🗺️','Fases concluídas',Math.min(MAXLV,sv.un-1+(sv.st[MAXLV]?1:0))+'/'+MAXLV],['⭐','Estrelas',t+'/'+MAXLV*3],['♾️','Recorde Infinito',B.inf||0],['⏱️','Recorde Relâmpago',B.time||0],['🧘','Melhor no Zen',B.zen||0],['📅','Desafio de hoje',sv.dw===today()?'Concluído ✔':'Pendente'],['🏆','Melhor pontuação (fases)',best],['🪙','Moedas',sv.coins],['🎯','Tiros dados / precisão',ST().shots+' / '+(ST().shots?Math.round(100*(ST().hitShots||0)/ST().shots):0)+'%'],['🫧','Bolinhas estouradas',ST().pops],['🍂','Bolinhas derrubadas',ST().falls],['🏁','Vitórias / derrotas',ST().wins+' / '+ST().losses],['🔥','Maior combo',ST().bestStreak],['⏱️','Tempo de jogo',Math.floor(ST().playMs/60000)+' min'],['🏅','Conquistas',Object.keys(sv.ach).length+'/'+ACH.length]];
 $('recList').innerHTML=rows.map(r=>'<div class="card"><div class="ce">'+r[0]+'</div><div class="ct"><b>'+r[1]+'</b></div><b style="color:#ffd23f">'+r[2]+'</b></div>').join('');go('ovRec')}
function toggleSnd(){const on=sv.snd||sv.mus;sv.snd=on?0:1;sv.mus=on?0:1;store();if(on)stopMusic();else startMusic();refreshPills();toast(on?'Som desligado 🔇':'Som ligado 🔊')}
function share(){const t='Estou jogando Magic Hues Balls! Já estou na fase '+Math.min(sv.un,MAXLV)+' 🎯 Venha jogar também!';
 if(navigator.share)navigator.share({title:'Magic Hues Balls',text:t,url:location.href}).catch(()=>{});else if(navigator.clipboard)navigator.clipboard.writeText(t+' '+location.href).then(()=>toast('Convite copiado! 📋'));else toast('Compartilhar indisponível aqui')}
function refreshSndLbl(){const b=$('bSndP');if(b)b.textContent=(sv.snd||sv.mus)?'🔊 Som: ligado':'🔇 Som: desligado'}
function refreshPills(){refreshSndLbl();mDay();$('acBadge').style.display=Object.keys(sv.ach).length>sv.achSeen?'block':'none';$('msBadge').style.display=MIS.some(claimable)?'block':'none';$('dcBadge').style.display=sv.dw!==today()?'block':'none';$('pSnd').textContent=(sv.snd||sv.mus)?'🔊 Som':'🔇 Som'}
$('pills').onclick=e=>{const b=e.target.closest&&e.target.closest('button');if(!b)return;sfx('pop');const m=b.getAttribute('data-m'),a=b.getAttribute('data-a');if(m)openMode(m);else if(a=='miss')openMiss();else if(a=='ach')openAch();else if(a=='skin')openSkin();else if(a=='rec')openRec();else if(a=='snd')toggleSnd();else if(a=='share')share()};
$('missList').onclick=e=>{const b=e.target.closest&&e.target.closest('button');const id=b&&b.getAttribute('data-mi');if(id)claimMis(id)};
$('skinList').onclick=e=>{const b=e.target.closest&&e.target.closest('button');if(!b||b.disabled)return;pickSkin(+b.getAttribute('data-sk'))};
// ====== LUMINA, a fadinha mascote ======
function tipFor(l){const F=sv.mas=='flora';
 const T=F?{inf:'Quanto mais longe, mais flores! ♾️🌼',time:'O tempo voa, mas você é mais rápido! ⏱️🌸',zen:'Respira fundo... cheira uma flor. 🌷',daily:'Desafio do dia! O jardim torce por você! 🌻'}:{inf:'Quanto mais longe, melhor! ♾️',time:'O relógio corre, mas você consegue! ⏱️',zen:'Sem pressa, respira fundo. 🧘',daily:'Desafio do dia! Eu torço por você! 🌟'};
 if(mode!='map')return T[mode];if(isElite(l))return Math.random()<.5?(F?'Cuidado: pedras no canteiro! 🪨':'Cuidado com as pedras! 🪨'):'O teto desce rápido, atenção! ⏳';
 if(tierOf(l)==1&&Math.random()<.5)return F?'Agora o jardim fica mais difícil! 🔶🌺':'Agora fica mais difícil, mas você consegue! 🔶';if(tierOf(l)==2&&Math.random()<.5)return F?'Fase difícil! Eu acredito em você! 🔴🌹':'Fase difícil! Eu acredito em você! 🔴💪';
 const A=F?['Olha lá, preste atenção! 🌼','Junte 3 da mesma cor, como pétalas! 🌈','Mire com calma, flor por flor. 🌸','Derrube os grupos soltos! 🍃','Use os poderes sem medo! 💣']:['Olha lá, preste atenção! 👀','Junte 3 da mesma cor! 🌈','Mire com calma. 🌸','Derrube os grupos soltos! 🍃','Use os poderes sem medo! 💣'];return l==1?A[1]:A[Math.random()*A.length|0]}
Lumi=(()=>{
 const box=$('box'),el=$('lum'),bd=$('lumB'),bub=$('lumBub'),pet=$('lumPet'),R=(a,b)=>a+Math.random()*(b-a),vis=id=>{const e=$(id);return !!e&&!e.classList.contains('hide')};
 let sg=$('lumSvg');
 const ZN={menu:[[.02,.1,.22,.7],[.85,.93,.22,.7]],other:[[.02,.08,.3,.7],[.88,.95,.3,.7]],play:[[.74,.93,.84,.94]],tip:[[.38,.62,.15,.2]],ev:[[.32,.68,.06,.1]]};
 const PHR={ // 💬 frases de cada mascote (curtas e carinhosas)
  lumina:{welcome:'Oi, que bom te ver! 🌼',idle:'Ei, ainda tá aí? 😊',win3:'Perfeito! Três estrelas! ⭐',win:['Uau, você é incrível! ✨','Eu sabia que conseguia! 🌟','Que mágica linda! 🎉'],lose:['Não desista, estou com você! 💫','Quase! Tenta de novo! 💛','Errar faz parte. Vamos lá! 🍃'],lives:'Descansa um pouquinho, eu espero. 🌙',gift:'Trouxe um presente pra você! 🎁',back:'Oi! Voltei! 🌼'},
  flora:{welcome:'Bom dia, jardim! Oi! 🌷',idle:'Psiu... o jardim te espera! 🌻',win3:'Três pétalas de ouro! 🏵️',win:['Você floresceu! Que lindo! 🌸','O jardim inteiro está aplaudindo! 🌼','Cada fase, uma flor nova! 🌺'],lose:['Toda florzinha se levanta de novo! 🌷','O sol volta amanhã, vamos tentar! 🌞','Sem pressa, as flores crescem devagar. 🍃'],lives:'Hora de regar as energias. 💧',gift:'Colhi um presente pra você! 💐',back:'Voltei do jardim! 🌷'}
 },P=()=>PHR[sv.mas]||PHR.lumina;
 const MSVG={lumina:typeof bd.innerHTML=='string'?bd.innerHTML:'',flora:"<svg id=\"lumSvg\" class=\"fk\" data-e=\"happy\" viewBox=\"0 0 120 120\" xmlns=\"http://www.w3.org/2000/svg\"><defs><linearGradient id=\"fkWing\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#ffd6ec\"/><stop offset=\".35\" stop-color=\"#e2c9ff\"/><stop offset=\".7\" stop-color=\"#bfeaff\"/><stop offset=\"1\" stop-color=\"#fff3b8\"/><animateTransform attributeName=\"gradientTransform\" type=\"rotate\" from=\"0 .5 .5\" to=\"360 .5 .5\" dur=\"7s\" repeatCount=\"indefinite\"/></linearGradient><radialGradient id=\"fkSkin\" cx=\".4\" cy=\".35\" r=\".78\"><stop offset=\"0\" stop-color=\"#ffe6d0\"/><stop offset=\".6\" stop-color=\"#f2c59d\"/><stop offset=\"1\" stop-color=\"#d9a073\"/></radialGradient><linearGradient id=\"fkHair\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#c9814f\"/><stop offset=\".5\" stop-color=\"#8b4f32\"/><stop offset=\"1\" stop-color=\"#5a2e1c\"/></linearGradient><linearGradient id=\"fkDress\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#ffc2d6\"/><stop offset=\".6\" stop-color=\"#ff8fb3\"/><stop offset=\"1\" stop-color=\"#f0648f\"/></linearGradient><linearGradient id=\"fkPetal\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#fff8fb\"/><stop offset=\"1\" stop-color=\"#ffcfe1\"/></linearGradient><radialGradient id=\"fkIris\" cx=\".5\" cy=\".4\" r=\".6\"><stop offset=\"0\" stop-color=\"#c08a55\"/><stop offset=\".6\" stop-color=\"#6e4122\"/><stop offset=\"1\" stop-color=\"#2f1a0d\"/></radialGradient><radialGradient id=\"fkAura\"><stop offset=\"0\" stop-color=\"#fff0f8\" stop-opacity=\".7\"/><stop offset=\".6\" stop-color=\"#ffd0ea\" stop-opacity=\".25\"/><stop offset=\"1\" stop-color=\"#ffd0ea\" stop-opacity=\"0\"/></radialGradient><radialGradient id=\"fkBlush\"><stop offset=\"0\" stop-color=\"#ff7fa0\" stop-opacity=\".7\"/><stop offset=\"1\" stop-color=\"#ff7fa0\" stop-opacity=\"0\"/></radialGradient><radialGradient id=\"fkGlow\"><stop offset=\"0\" stop-color=\"#fffbd0\"/><stop offset=\"1\" stop-color=\"#ffd23a\" stop-opacity=\"0\"/></radialGradient></defs><circle cx=\"60\" cy=\"62\" r=\"58\" fill=\"url(#fkAura)\"><animate attributeName=\"r\" values=\"54;59;54\" dur=\"3.2s\" repeatCount=\"indefinite\"/></circle><g><animateTransform attributeName=\"transform\" type=\"rotate\" from=\"0 60 62\" to=\"360 60 62\" dur=\"10s\" repeatCount=\"indefinite\"/><g transform=\"rotate(0 60 62)\"><g transform=\"translate(112 62)\"><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(72 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(144 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(216 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(288 0 0)\"/><circle cx=\"0\" cy=\"0\" r=\"0.88\" fill=\"#ffd23a\"/><circle cx=\"-0.26\" cy=\"-0.26\" r=\"0.31\" fill=\"#fff\" opacity=\".7\"/></g></g><g transform=\"rotate(90 60 62)\"><g transform=\"translate(112 62)\"><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(72 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(144 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(216 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(288 0 0)\"/><circle cx=\"0\" cy=\"0\" r=\"0.88\" fill=\"#ffd23a\"/><circle cx=\"-0.26\" cy=\"-0.26\" r=\"0.31\" fill=\"#fff\" opacity=\".7\"/></g></g><g transform=\"rotate(180 60 62)\"><g transform=\"translate(112 62)\"><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(72 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(144 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(216 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(288 0 0)\"/><circle cx=\"0\" cy=\"0\" r=\"0.88\" fill=\"#ffd23a\"/><circle cx=\"-0.26\" cy=\"-0.26\" r=\"0.31\" fill=\"#fff\" opacity=\".7\"/></g></g><g transform=\"rotate(270 60 62)\"><g transform=\"translate(112 62)\"><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(72 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(144 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(216 0 0)\"/><ellipse cx=\"0\" cy=\"-1.61\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(288 0 0)\"/><circle cx=\"0\" cy=\"0\" r=\"0.88\" fill=\"#ffd23a\"/><circle cx=\"-0.26\" cy=\"-0.26\" r=\"0.31\" fill=\"#fff\" opacity=\".7\"/></g></g></g><g class=\"wl\"><path d=\"M56 70C40 62 16 48 10 30C20 19 43 27 54 48C57 56 57 63 56 70Z\" fill=\"url(#fkWing)\" fill-opacity=\".78\" stroke=\"#fff\" stroke-width=\".9\"/><path d=\"M56 70C42 60 24 46 18 32C28 28 42 36 52 52C56 58 57 64 56 70Z\" fill=\"#fff\" opacity=\".22\"/><path d=\"M56 70C40 56 26 42 12 30M56 70C44 58 38 44 30 26M56 70C46 62 40 54 36 44M24 42C30 44 40 54 48 62\" stroke=\"#fff\" stroke-opacity=\".6\" stroke-width=\".6\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M56 74C42 76 24 86 20 98C32 104 48 92 56 80Z\" fill=\"url(#fkWing)\" fill-opacity=\".78\" stroke=\"#fff\" stroke-width=\".9\"/><path d=\"M56 74C44 78 32 86 26 96\" stroke=\"#fff\" stroke-opacity=\".6\" stroke-width=\".6\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M54 78C46 80 38 86 34 92\" stroke=\"#fff\" stroke-opacity=\".5\" stroke-width=\".5\" fill=\"none\"/><path d=\"M12 25L12.84 27.16L15 28L12.84 28.84L12 31L11.16 28.84L9 28L11.16 27.16Z\" fill=\"#fff\"><animate attributeName=\"opacity\" values=\"0;1;0\" dur=\"2.4s\" begin=\"-0s\" repeatCount=\"indefinite\"/></path><path d=\"M22 94.6L22.67 96.33L24.4 97L22.67 97.67L22 99.4L21.33 97.67L19.6 97L21.33 96.33Z\" fill=\"#fff\"><animate attributeName=\"opacity\" values=\"0;1;0\" dur=\"3s\" begin=\"-1.1s\" repeatCount=\"indefinite\"/></path></g><g class=\"wr\"><g transform=\"translate(120 0) scale(-1 1)\"><path d=\"M56 70C40 62 16 48 10 30C20 19 43 27 54 48C57 56 57 63 56 70Z\" fill=\"url(#fkWing)\" fill-opacity=\".78\" stroke=\"#fff\" stroke-width=\".9\"/><path d=\"M56 70C42 60 24 46 18 32C28 28 42 36 52 52C56 58 57 64 56 70Z\" fill=\"#fff\" opacity=\".22\"/><path d=\"M56 70C40 56 26 42 12 30M56 70C44 58 38 44 30 26M56 70C46 62 40 54 36 44M24 42C30 44 40 54 48 62\" stroke=\"#fff\" stroke-opacity=\".6\" stroke-width=\".6\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M56 74C42 76 24 86 20 98C32 104 48 92 56 80Z\" fill=\"url(#fkWing)\" fill-opacity=\".78\" stroke=\"#fff\" stroke-width=\".9\"/><path d=\"M56 74C44 78 32 86 26 96\" stroke=\"#fff\" stroke-opacity=\".6\" stroke-width=\".6\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M54 78C46 80 38 86 34 92\" stroke=\"#fff\" stroke-opacity=\".5\" stroke-width=\".5\" fill=\"none\"/><path d=\"M12 25L12.84 27.16L15 28L12.84 28.84L12 31L11.16 28.84L9 28L11.16 27.16Z\" fill=\"#fff\"><animate attributeName=\"opacity\" values=\"0;1;0\" dur=\"2.4s\" begin=\"-0s\" repeatCount=\"indefinite\"/></path><path d=\"M22 94.6L22.67 96.33L24.4 97L22.67 97.67L22 99.4L21.33 97.67L19.6 97L21.33 96.33Z\" fill=\"#fff\"><animate attributeName=\"opacity\" values=\"0;1;0\" dur=\"3s\" begin=\"-1.1s\" repeatCount=\"indefinite\"/></path></g></g><g class=\"dr\"><path d=\"M47 66C37 78 33 92 41 101C47 91 49 79 53 69Z\" fill=\"#f0648f\"/><path d=\"M73 66C83 78 87 92 79 101C73 91 71 79 67 69Z\" fill=\"#f0648f\"/><path d=\"M48 64Q60 60 72 64C80 76 80 94 72 102Q66 96 60 104Q54 96 48 102C40 94 40 76 48 64Z\" fill=\"url(#fkDress)\" stroke=\"#e5568a\" stroke-width=\".9\" stroke-linejoin=\"round\"/><path d=\"M52 70Q60 64 68 70C70 82 68 94 60 100C52 94 50 82 52 70Z\" fill=\"url(#fkPetal)\"/><path d=\"M60 68L60 98M56 72C56 82 57 90 60 98M64 72C64 82 63 90 60 98\" stroke=\"#f6a6c4\" stroke-width=\".55\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M44 86Q47 96 52 101M76 86Q73 96 68 101\" stroke=\"#fff\" stroke-opacity=\".5\" stroke-width=\".9\" fill=\"none\" stroke-linecap=\"round\"/></g><path d=\"M50 62Q60 58 70 62L68 72Q60 76 52 72Z\" fill=\"#ffd8e6\" stroke=\"#f3a2bf\" stroke-width=\".8\"/><path d=\"M48 63 Q51.5 59.8 55 63 Q51.5 66.2 48 63Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".3\" transform=\"rotate(-35 48 63)\"/><path d=\"M72 63 Q75.5 59.8 79 63 Q75.5 66.2 72 63Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".3\" transform=\"rotate(215 72 63)\"/><path d=\"M49 70Q60 77 71 70\" stroke=\"#5fbf7e\" stroke-width=\"2.6\" fill=\"none\" stroke-linecap=\"round\"/><ellipse cx=\"60\" cy=\"72.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 60 74)\"/><ellipse cx=\"60\" cy=\"72.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(60 60 74)\"/><ellipse cx=\"60\" cy=\"72.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(120 60 74)\"/><ellipse cx=\"60\" cy=\"72.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(180 60 74)\"/><ellipse cx=\"60\" cy=\"72.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(240 60 74)\"/><ellipse cx=\"60\" cy=\"72.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(300 60 74)\"/><circle cx=\"60\" cy=\"74\" r=\"0.88\" fill=\"#ffd23a\"/><circle cx=\"59.74\" cy=\"73.74\" r=\"0.31\" fill=\"#fff\" opacity=\".7\"/><path d=\"M55 101L54 109M65 101L66 109\" stroke=\"#eab894\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M49 111Q54 106 59 111Q54 115 49 111Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".5\"/><path d=\"M61 111Q66 106 71 111Q66 115 61 111Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".5\"/><path d=\"M56 56L56 64Q60 67 64 64L64 56Z\" fill=\"url(#fkSkin)\"/><path d=\"M56 62Q60 65 64 62\" stroke=\"#d49a70\" stroke-width=\".7\" fill=\"none\" opacity=\".6\"/><g class=\"ad\"><path d=\"M51 66C47 72 45 80 45 87\" stroke=\"#eab894\" stroke-width=\"3.6\" fill=\"none\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"88\" r=\"2.5\" fill=\"#f2c59d\"/></g><g class=\"au\"><path d=\"M51 66C45 62 41 56 40 50\" stroke=\"#eab894\" stroke-width=\"3.6\" fill=\"none\" stroke-linecap=\"round\"/><circle cx=\"40\" cy=\"48.5\" r=\"2.5\" fill=\"#f2c59d\"/></g><path d=\"M69 66C75 70 79 76 81 83\" stroke=\"#eab894\" stroke-width=\"3.6\" fill=\"none\" stroke-linecap=\"round\"/><circle cx=\"82\" cy=\"84\" r=\"2.6\" fill=\"#f2c59d\"/><path d=\"M82 86L94 62\" stroke=\"#a37a4a\" stroke-width=\"1.8\" stroke-linecap=\"round\"/><circle cx=\"95\" cy=\"58\" r=\"9\" fill=\"url(#fkGlow)\"><animate attributeName=\"r\" values=\"7;10;7\" dur=\"1.8s\" repeatCount=\"indefinite\"/></circle><ellipse cx=\"95\" cy=\"55.52\" rx=\"1.20\" ry=\"2.48\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 95 58)\"/><ellipse cx=\"95\" cy=\"55.52\" rx=\"1.20\" ry=\"2.48\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(60 95 58)\"/><ellipse cx=\"95\" cy=\"55.52\" rx=\"1.20\" ry=\"2.48\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(120 95 58)\"/><ellipse cx=\"95\" cy=\"55.52\" rx=\"1.20\" ry=\"2.48\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(180 95 58)\"/><ellipse cx=\"95\" cy=\"55.52\" rx=\"1.20\" ry=\"2.48\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(240 95 58)\"/><ellipse cx=\"95\" cy=\"55.52\" rx=\"1.20\" ry=\"2.48\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(300 95 58)\"/><circle cx=\"95\" cy=\"58\" r=\"1.36\" fill=\"#ffd23a\"/><circle cx=\"94.60\" cy=\"57.60\" r=\"0.48\" fill=\"#fff\" opacity=\".7\"/><circle cx=\"97\" cy=\"49\" r=\"1.2\" fill=\"#fff\"><animate attributeName=\"cy\" values=\"52;42\" dur=\"1.6s\" repeatCount=\"indefinite\"/><animate attributeName=\"opacity\" values=\"1;0\" dur=\"1.6s\" repeatCount=\"indefinite\"/></circle><circle cx=\"91\" cy=\"50\" r=\"1\" fill=\"#ffe27a\"><animate attributeName=\"cy\" values=\"52;44\" dur=\"2.1s\" begin=\"-.8s\" repeatCount=\"indefinite\"/><animate attributeName=\"opacity\" values=\"1;0\" dur=\"2.1s\" begin=\"-.8s\" repeatCount=\"indefinite\"/></circle><path d=\"M60 22C40 22 32 38 35 54C36 66 42 76 54 80C46 71 45 61 47 52L73 52C75 61 74 71 66 80C78 76 84 66 85 54C88 38 80 22 60 22Z\" fill=\"url(#fkHair)\"/><g class=\"hs\"><path d=\"M40 58C36 66 37 75 43 80C41 73 43 66 45 60Z\" fill=\"url(#fkHair)\"/><path d=\"M80 58C84 66 83 75 77 80C79 73 77 66 75 60Z\" fill=\"url(#fkHair)\"/><path d=\"M38 60C37 67 39 74 42 79M82 60C83 67 81 74 78 79\" stroke=\"#d9935f\" stroke-opacity=\".6\" stroke-width=\".7\" fill=\"none\" stroke-linecap=\"round\"/></g><path d=\"M42 36C38 48 40 64 48 74M78 36C82 48 80 64 72 74M50 26C42 32 40 40 40 46\" stroke=\"#d9935f\" stroke-opacity=\".55\" stroke-width=\".8\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M44.500 46L38 42L43 52Z\" fill=\"url(#fkSkin)\"/><path d=\"M75.500 46L82 42L77 52Z\" fill=\"url(#fkSkin)\"/><ellipse cx=\"60\" cy=\"46\" rx=\"16\" ry=\"17.5\" fill=\"url(#fkSkin)\"/><path d=\"M46 52Q60 67 74 52Q70 63 60 64Q50 63 46 52Z\" fill=\"#d49a70\" opacity=\".22\"/><path d=\"M43 40C44 28 54 24 60 25C68 24 76 30 77 40C72 33 66 32 60 35C54 32 47 34 43 40Z\" fill=\"url(#fkHair)\"/><path d=\"M47 34C52 28 58 27 62 28M66 29C70 30 74 33 75 37\" stroke=\"#e0a070\" stroke-opacity=\".6\" stroke-width=\".7\" fill=\"none\" stroke-linecap=\"round\"/><circle cx=\"49\" cy=\"53\" r=\"5.6\" fill=\"url(#fkBlush)\"/><circle cx=\"71\" cy=\"53\" r=\"5.6\" fill=\"url(#fkBlush)\"/><g fill=\"#b9754d\" opacity=\".55\"><circle cx=\"55.6\" cy=\"51\" r=\".5\"/><circle cx=\"57.4\" cy=\"52\" r=\".45\"/><circle cx=\"64.4\" cy=\"52\" r=\".45\"/><circle cx=\"66.2\" cy=\"51\" r=\".5\"/><circle cx=\"60\" cy=\"52.6\" r=\".4\"/></g><path d=\"M49 41.200Q53 38.800 57 40.200M63 40.200Q67 38.800 71 41.200\" stroke=\"#6e3f22\" stroke-width=\"1\" fill=\"none\" stroke-linecap=\"round\"/><g class=\"bw\"><path d=\"M48.500 39.500L57 41.800M71.500 39.500L63 41.800\" stroke=\"#6e3f22\" stroke-width=\"1.1\" stroke-linecap=\"round\"/></g><g class=\"eo\"><g class=\"eL\"><ellipse cx=\"53\" cy=\"46\" rx=\"4.4\" ry=\"4.9\" fill=\"#fff\"/><path d=\"M48.600 44.300Q53 40.600 57.400 44.300Q53 42.800 48.600 44.300Z\" fill=\"#a98ac9\" opacity=\".4\"/></g><g class=\"eR\"><ellipse cx=\"67\" cy=\"46\" rx=\"4.4\" ry=\"4.9\" fill=\"#fff\"/><path d=\"M62.600 44.300Q67 40.600 71.400 44.300Q67 42.800 62.600 44.300Z\" fill=\"#a98ac9\" opacity=\".4\"/></g><g class=\"pu\"><circle cx=\"53\" cy=\"46.300\" r=\"3.4\" fill=\"url(#fkIris)\"/><circle cx=\"67\" cy=\"46.300\" r=\"3.4\" fill=\"url(#fkIris)\"/><circle cx=\"53\" cy=\"46.300\" r=\"1.5\" fill=\"#1b0f08\"/><circle cx=\"67\" cy=\"46.300\" r=\"1.5\" fill=\"#1b0f08\"/><circle cx=\"51.800\" cy=\"44.800\" r=\"1.2\" fill=\"#fff\"/><circle cx=\"65.800\" cy=\"44.800\" r=\"1.2\" fill=\"#fff\"/><circle cx=\"54.400\" cy=\"47.800\" r=\".6\" fill=\"#fff\" opacity=\".8\"/><circle cx=\"68.400\" cy=\"47.800\" r=\".6\" fill=\"#fff\" opacity=\".8\"/></g><path d=\"M48.300 44.800Q53 40.200 57.700 44.800M48.300 44.800L46.600 43.200M62.300 44.800Q67 40.200 71.700 44.800M71.700 44.800L73.400 43.200\" stroke=\"#2f1a0d\" stroke-width=\"1.5\" fill=\"none\" stroke-linecap=\"round\"/></g><g class=\"ec\"><path class=\"ecL\" d=\"M48.600 46.500Q53 50 57.400 46.500\" stroke=\"#2f1a0d\" stroke-width=\"1.4\" fill=\"none\" stroke-linecap=\"round\"/><path class=\"ecR\" d=\"M62.600 46.500Q67 50 71.400 46.500\" stroke=\"#2f1a0d\" stroke-width=\"1.4\" fill=\"none\" stroke-linecap=\"round\"/></g><path d=\"M60 49.200Q61.400 51 60 51.800\" stroke=\"#c98a66\" stroke-width=\".9\" fill=\"none\" stroke-linecap=\"round\"/><circle cx=\"59.300\" cy=\"50.200\" r=\".5\" fill=\"#fff\" opacity=\".6\"/><g class=\"ms\"><path d=\"M55 56Q60 60.600 65 56\" stroke=\"#b5435d\" stroke-width=\"1.1\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M56.200 56.600Q60 59.400 63.800 56.600Q60 58 56.200 56.600Z\" fill=\"#e0607e\"/></g><g class=\"mo\"><path d=\"M55 56Q60 67 65 56Z\" fill=\"#a8334f\"/><path d=\"M56 56.200L64 56.200Q60 58 56 56.200Z\" fill=\"#fff\"/><ellipse cx=\"60\" cy=\"61.200\" rx=\"3\" ry=\"1.700\" fill=\"#ff8aa5\"/></g><path d=\"M41 36 Q44.0 33.1 47 36 Q44.0 38.9 41 36Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".3\" transform=\"rotate(150 41 36)\"/><path d=\"M79 36 Q82.0 33.1 85 36 Q82.0 38.9 79 36Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".3\" transform=\"rotate(30 79 36)\"/><path d=\"M48 29 Q50.5 26.4 53 29 Q50.5 31.6 48 29Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".3\" transform=\"rotate(200 48 29)\"/><path d=\"M72 29 Q74.5 26.4 77 29 Q74.5 31.6 72 29Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".3\" transform=\"rotate(-20 72 29)\"/><path d=\"M56 25 Q58.5 22.6 61 25 Q58.5 27.4 56 25Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".3\" transform=\"rotate(160 56 25)\"/><path d=\"M64 25 Q66.5 22.6 69 25 Q66.5 27.4 64 25Z\" fill=\"#58b878\" stroke=\"#3f9a5e\" stroke-width=\".3\" transform=\"rotate(20 64 25)\"/><ellipse cx=\"44\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 44 33)\"/><ellipse cx=\"44\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(45 44 33)\"/><ellipse cx=\"44\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(90 44 33)\"/><ellipse cx=\"44\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(135 44 33)\"/><ellipse cx=\"44\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(180 44 33)\"/><ellipse cx=\"44\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(225 44 33)\"/><ellipse cx=\"44\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(270 44 33)\"/><ellipse cx=\"44\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(315 44 33)\"/><circle cx=\"44\" cy=\"33\" r=\"1.43\" fill=\"#ffd23a\"/><circle cx=\"43.58\" cy=\"32.58\" r=\"0.50\" fill=\"#fff\" opacity=\".7\"/><circle cx=\"51.5\" cy=\"27.5\" r=\"4.4\" fill=\"#ff6f9c\"/><circle cx=\"51.5\" cy=\"27.5\" r=\"3.17\" fill=\"#e83e7a\" opacity=\".55\"/><path d=\"M48.86 27.5 Q51.5 23.54 54.14 27.5 Q51.5 30.58 48.86 27.5Z\" fill=\"#ff6f9c\" stroke=\"#e83e7a\" stroke-width=\".35\"/><path d=\"M50.18 27.5 Q51.5 25.30 52.82 27.5\" stroke=\"#e83e7a\" stroke-width=\".4\" fill=\"none\"/><circle cx=\"50.18\" cy=\"25.96\" r=\"0.88\" fill=\"#fff\" opacity=\".45\"/><ellipse cx=\"60\" cy=\"22.89\" rx=\"1.02\" ry=\"2.11\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 60 25)\"/><ellipse cx=\"60\" cy=\"22.89\" rx=\"1.02\" ry=\"2.11\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(45 60 25)\"/><ellipse cx=\"60\" cy=\"22.89\" rx=\"1.02\" ry=\"2.11\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(90 60 25)\"/><ellipse cx=\"60\" cy=\"22.89\" rx=\"1.02\" ry=\"2.11\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(135 60 25)\"/><ellipse cx=\"60\" cy=\"22.89\" rx=\"1.02\" ry=\"2.11\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(180 60 25)\"/><ellipse cx=\"60\" cy=\"22.89\" rx=\"1.02\" ry=\"2.11\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(225 60 25)\"/><ellipse cx=\"60\" cy=\"22.89\" rx=\"1.02\" ry=\"2.11\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(270 60 25)\"/><ellipse cx=\"60\" cy=\"22.89\" rx=\"1.02\" ry=\"2.11\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(315 60 25)\"/><circle cx=\"60\" cy=\"25\" r=\"1.16\" fill=\"#ffd23a\"/><circle cx=\"59.66\" cy=\"24.66\" r=\"0.41\" fill=\"#fff\" opacity=\".7\"/><circle cx=\"68.5\" cy=\"27.5\" r=\"4.4\" fill=\"#c9a4ff\"/><circle cx=\"68.5\" cy=\"27.5\" r=\"3.17\" fill=\"#8e63e0\" opacity=\".55\"/><path d=\"M65.86 27.5 Q68.5 23.54 71.14 27.5 Q68.5 30.58 65.86 27.5Z\" fill=\"#c9a4ff\" stroke=\"#8e63e0\" stroke-width=\".35\"/><path d=\"M67.18 27.5 Q68.5 25.30 69.82 27.5\" stroke=\"#8e63e0\" stroke-width=\".4\" fill=\"none\"/><circle cx=\"67.18\" cy=\"25.96\" r=\"0.88\" fill=\"#fff\" opacity=\".45\"/><ellipse cx=\"76\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#ffe9a8\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 76 33)\"/><ellipse cx=\"76\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#ffe9a8\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(45 76 33)\"/><ellipse cx=\"76\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#ffe9a8\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(90 76 33)\"/><ellipse cx=\"76\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#ffe9a8\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(135 76 33)\"/><ellipse cx=\"76\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#ffe9a8\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(180 76 33)\"/><ellipse cx=\"76\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#ffe9a8\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(225 76 33)\"/><ellipse cx=\"76\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#ffe9a8\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(270 76 33)\"/><ellipse cx=\"76\" cy=\"30.40\" rx=\"1.26\" ry=\"2.60\" fill=\"#ffe9a8\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(315 76 33)\"/><circle cx=\"76\" cy=\"33\" r=\"1.43\" fill=\"#ff9a3c\"/><circle cx=\"75.58\" cy=\"32.58\" r=\"0.50\" fill=\"#fff\" opacity=\".7\"/><ellipse cx=\"40\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 40 41)\"/><ellipse cx=\"40\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(60 40 41)\"/><ellipse cx=\"40\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(120 40 41)\"/><ellipse cx=\"40\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(180 40 41)\"/><ellipse cx=\"40\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(240 40 41)\"/><ellipse cx=\"40\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(300 40 41)\"/><circle cx=\"40\" cy=\"41\" r=\"0.88\" fill=\"#ffd23a\"/><circle cx=\"39.74\" cy=\"40.74\" r=\"0.31\" fill=\"#fff\" opacity=\".7\"/><ellipse cx=\"80\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(0 80 41)\"/><ellipse cx=\"80\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(60 80 41)\"/><ellipse cx=\"80\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(120 80 41)\"/><ellipse cx=\"80\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(180 80 41)\"/><ellipse cx=\"80\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(240 80 41)\"/><ellipse cx=\"80\" cy=\"39.39\" rx=\"0.78\" ry=\"1.61\" fill=\"#fff\" stroke=\"#e4d6e8\" stroke-width=\".25\" transform=\"rotate(300 80 41)\"/><circle cx=\"80\" cy=\"41\" r=\"0.88\" fill=\"#ffd23a\"/><circle cx=\"79.74\" cy=\"40.74\" r=\"0.31\" fill=\"#fff\" opacity=\".7\"/><path d=\"M60 16.4L60.73 18.27L62.6 19L60.73 19.73L60 21.6L59.27 19.73L57.4 19L59.27 18.27Z\" fill=\"#fff\"><animate attributeName=\"opacity\" values=\"0;1;0\" dur=\"2.2s\" begin=\"-0.4s\" repeatCount=\"indefinite\"/></path><path d=\"M46 22L46.56 23.44L48 24L46.56 24.56L46 26L45.44 24.56L44 24L45.44 23.44Z\" fill=\"#fff\"><animate attributeName=\"opacity\" values=\"0;1;0\" dur=\"2.8s\" begin=\"-1.3s\" repeatCount=\"indefinite\"/></path><path d=\"M74 22L74.56 23.44L76 24L74.56 24.56L74 26L73.44 24.56L72 24L73.44 23.44Z\" fill=\"#fff\"><animate attributeName=\"opacity\" values=\"0;1;0\" dur=\"2.6s\" begin=\"-0.9s\" repeatCount=\"indefinite\"/></path></svg>"};
 function skin(id){if(!MSVG[id]||!MSVG.lumina)id='lumina';if(id!='lumina'||bd.innerHTML!==MSVG.lumina)bd.innerHTML=MSVG[id];sg=$('lumSvg');sg.dataset.e='happy';el.classList.toggle('mflora',id=='flora')}
 let x=-90,y=320,px=.9,py=.4,zone='',t=0,face=1,last=0,nextPick=0,cd=0,exprT=0,spk=0,petal=null,idleAt=Date.now(),idleSaid=false,welcomed=false,stars=3,sleepy=false,S=64;
 function ctx(){if(!sv.lum||vis('ovSplash')||vis('ovLoad'))return'off';if(state=='load')return'tip';if(state=='play')return'play';
  if(vis('ovWin')||vis('ovEnd')||vis('ovLives')||vis('ovDaily'))return'ev';return vis('ovStart')?'menu':'other'}
 function pick(z){const Z=ZN[z],a=Z[Math.random()*Z.length|0];px=R(a[0],a[1]);py=R(a[2],a[3])}
 function expr(e,ms){sg.dataset.e=e;exprT=ms?Date.now()+ms:0}
 function say(txt,ms,force,e){if(!sv.lum)return;const n=Date.now();if(!force&&n<cd)return;cd=n+20000;bub.textContent=txt;el.classList.add('say');clearTimeout(say.t);say.t=setTimeout(()=>el.classList.remove('say'),ms||3200);if(e)expr(e,ms||3200)}
 function spark(ox,oy,dx,dy,em){const i=document.createElement('i');i.className='lsp'+(sv.mas=='flora'?' pk':'')+(em?' pe':'');if(em)i.textContent=em;i.style.left=ox+'px';i.style.top=oy+'px';i.style.setProperty&&i.style.setProperty('--dx',dx+'px');i.style.setProperty&&i.style.setProperty('--dy',dy+'px');box.appendChild(i);setTimeout(()=>i.remove&&i.remove(),950)}
 function burst(n){for(let k=0;k<n;k++){const a=Math.random()*6.28,d=R(30,80),em=sv.mas=='flora'&&Math.random()<.6?['🌸','🌷','🌼','💮'][Math.random()*4|0]:'';spark(x,y,Math.cos(a)*d,Math.sin(a)*d,em)}} // 🌸 a Flora solta pétalas e flores nas comemorações
 function spin(){sg.classList.remove('spin');void sg.getBoundingClientRect();sg.classList.add('spin');setTimeout(()=>sg.classList.remove('spin'),850)}
 function startPetal(W,H,now){const Z=ZN[zone]||ZN.menu,a=Z[Math.random()*Z.length|0],fromTop=Math.random()<.5;petal={t0:now,x0:R(a[0],a[1])*W,y0:(fromTop?a[2]-.12:a[3]+.1)*H,x1:R(a[0],a[1])*W,y1:(fromTop?a[3]+.1:a[2]-.12)*H};{const E=sv.mas=='flora'?['🌸','🌷','🌼','🦋']:['🌸','🦋'];pet.textContent=E[Math.random()*E.length|0]}pet.style.display='block'}
 function step(now){const W=box.clientWidth,H=box.clientHeight;if(!W)return;const dt=Math.min(.05,(now-last)/1000||.016);last=now;t+=dt;
  const c=ctx();if(c=='off'){el.style.display='none';pet.style.display='none';return}el.style.display='block';
  if(!welcomed){welcomed=true;say(P().welcome,3200,true,'cheer')}
  if(c!=zone){zone=c;pick(c);nextPick=now+R(6000,10000);if(petal&&c!='menu'&&c!='other'){petal=null;pet.style.display='none'}}
  const nowMs=Date.now();if(exprT&&nowMs>exprT){exprT=0;sg.dataset.e=sleepy?'sleepy':'happy'}
  if((c=='menu'||c=='other')&&nowMs-idleAt>30000&&!idleSaid){idleSaid=true;sleepy=true;expr('sleepy');say(P().idle,3500,true)}
  let tx=px*W,ty=py*H,perch=false,psd=1;
   if(c=='menu'){const np=nodePos();if(np&&np.y>150&&np.y<H-112){perch=true;psd=1;tx=np.x;ty=np.y-62;if(petal){petal=null;pet.style.display='none'}}} // 🧚 paira bem em cima da fase atual (no lugar da antiga bolinha vermelha)
  if(petal){const u=(now-petal.t0)/3600;if(u>=1){petal=null;pet.style.display='none';nextPick=now+R(5000,9000);expr('happy')}else{const pxp=petal.x0+(petal.x1-petal.x0)*u+Math.sin(u*14)*14,pyp=petal.y0+(petal.y1-petal.y0)*u;pet.style.transform='translate('+pxp+'px,'+pyp+'px) rotate('+(u*360)+'deg)';tx=pxp;ty=pyp+18;if(Math.hypot(tx-x,ty-y)<70&&!exprT&&!sleepy)expr('curious',900)}}
  else if(!perch&&now>nextPick){if((c=='menu'||c=='other')&&!sleepy&&Math.random()<.45)startPetal(W,H,now);else pick(c);nextPick=now+R(6000,10000)}
  const k=1-Math.exp(-dt*1.8),sz=Math.max(70,Math.min(100,W*.25))*(c=='play'?.52:c=='other'?.7:1);S=sz;
  tx+=Math.sin(t*.8)*(c=='play'?4:perch?5:12);ty+=Math.cos(t*1.1)*(c=='play'?3:perch?4:8)+Math.sin(t*(sleepy?1.2:2.6))*(sleepy?2:5);
  tx=Math.max(sz/2+4,Math.min(W-sz/2-4,tx));ty=Math.max(sz/2+4,Math.min(H-sz/2-4,ty));
  if(Math.abs(tx-x)>14)face=tx>x?1:-1;else if(perch)face=psd>0?-1:1;x+=(tx-x)*k;y+=(ty-y)*k; // parada ao lado da fase, olha para ela
   
  el.style.width=el.style.height=sz+'px';el.style.opacity=c=='play'?.6:c=='other'?.8:.97;
  el.style.transform='translate3d('+(x-sz/2).toFixed(1)+'px,'+(y-sz/2).toFixed(1)+'px,0)';bd.style.transform='scaleX('+face+')';
  el.classList.toggle('below',y<150);el.classList.toggle('bubL',x<100);el.classList.toggle('bubR',x>W-100);
  spk-=dt;if(spk<=0&&!sleepy){spk=(c=='play'?.3:.1)*(Q>=2?1:Q==1?2:4);spark(x-face*sz*.25+R(-4,4),y+sz*.25,R(-14,14),R(8,26))}}
 document.addEventListener('pointerdown',()=>{idleAt=Date.now();idleSaid=false;if(sleepy){sleepy=false;expr('happy')}});
 (function loop(now){try{step(now||0)}catch(e){}requestAnimationFrame(loop)})(0);
 skin(sv.mas);
 return{say,burst,spin,step,ph:P,setMas(id){skin(id);say(P().back,2800,true,'cheer');spin();burst(14)},
  tip(txt){say(txt,3600,true,'happy')},
  win(n){say(n>=3?P().win3:P().win[Math.random()*P().win.length|0],4200,true,'cheer');spin();burst(18)},
  lose(){say(P().lose[Math.random()*P().lose.length|0],4200,true,'sad')},
  onShow(id){if(id=='ovWin')this.win(stars);else if(id=='ovEnd')this.lose();else if(id=='ovLives')say(P().lives,4200,true,'sad');else if(id=='ovDaily'){say(P().gift,3800,true,'cheer');spin()}},
  get stars(){return stars},set stars(v){stars=v},info:()=>({x,y,zone,e:sg.dataset.e,size:S})}})();
$('bSndP').onclick=()=>toggleSnd();
$('tLum').onclick=()=>{sv.lum^=1;store();refSet();sfx('pop');if(sv.lum)Lumi.say(Lumi.ph().back,2600,true,'cheer')};
$('tMas').onclick=()=>{sv.mas=sv.mas=='flora'?'lumina':'flora';sv.lum=1;store();Lumi.setMas(sv.mas);refSet();sfx('pop')};
// ====================== SISTEMAS PROFISSIONAIS ======================
// ---- Qualidade gráfica e movimento reduzido
function applyQ(){Q=sv.gq=='auto'?(sv.qa===undefined?2:+sv.qa):+sv.gq}
function applyRM(){RMOD=!!sv.rm||!!(typeof matchMedia=='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches);$('box').classList.toggle('rm',RMOD)}
// ---- Tratamento de erros: o jogo nunca fica "travado em branco"; depois de 3 erros oferece reiniciar
let errN=0;function onErr(m){errN++;try{localStorage.setItem('bc_err',String(m).slice(0,300))}catch(e){}if(errN==3)$('ovErr').classList.remove('hide')}
if(window.addEventListener){window.addEventListener('error',e=>onErr(e.message||'erro'));window.addEventListener('unhandledrejection',e=>onErr((e.reason&&e.reason.message)||'promessa'))}
$('erRe').onclick=()=>{try{location.reload()}catch(e){}};$('erGo').onclick=()=>{errN=0;$('ovErr').classList.add('hide')};
// ---- Barramento de eventos: o jogo "avisa" o que acontece e cada sistema (estatísticas, conquistas, avaliação) escuta sozinho
Bus={h:{},on(e,f){(this.h[e]=this.h[e]||[]).push(f)},emit(e,d){for(const f of this.h[e]||[])try{f(d)}catch(x){}}};
const ST=()=>sv.stat,isVis=id=>!$(id).classList.contains('hide');
Bus.on('shot',()=>{ST().shots++});
Bus.on('pops',n=>{ST().pops+=n;achCheck()});
Bus.on('falls',n=>{ST().falls+=n});
Bus.on('streak',n=>{ST().hitShots=(ST().hitShots||0)+1;if(n>ST().bestStreak)ST().bestStreak=n;achCheck()});
Bus.on('win',st=>{ST().wins++;if(st>=3)ST().stars3++;achCheck();maybeRate()});
Bus.on('lose',()=>{ST().losses++});
Bus.on('boss',()=>{ST().bosses=(ST().bosses||0)+1;achCheck()});
Bus.on('spend',()=>{ST().buys++;achCheck()});
Bus.on('mode',()=>{ST().modes++;achCheck()});
// ---- Conquistas (cada uma dá moedas ao ser desbloqueada)
const ACH=[
 {id:'a1',e:'🫧',n:'Primeira bolha',d:'Estoure sua primeira bolinha',t:1,r:10,v:()=>ST().pops},
 {id:'a2',e:'💥',n:'Estourador',d:'Estoure 100 bolinhas',t:100,r:20,v:()=>ST().pops},
 {id:'a3',e:'🌈',n:'Mestre das bolhas',d:'Estoure 1.000 bolinhas',t:1000,r:60,v:()=>ST().pops},
 {id:'a4',e:'👑',n:'Lenda das bolhas',d:'Estoure 5.000 bolinhas',t:5000,r:150,v:()=>ST().pops},
 {id:'a5',e:'🍂',n:'Chuva de bolinhas',d:'Derrube 50 bolinhas soltas',t:50,r:30,v:()=>ST().falls},
 {id:'a6',e:'🧭',n:'Aventureiro',d:'Vença 5 fases',t:5,r:25,v:()=>ST().wins},
 {id:'a7',e:'🛡️',n:'Veterano',d:'Vença 25 fases',t:25,r:80,v:()=>ST().wins},
 {id:'a8',e:'🏆',n:'Campeão',d:'Vença 100 fases',t:100,r:200,v:()=>ST().wins},
 {id:'a9',e:'⭐',n:'Perfeccionista',d:'Ganhe 3 estrelas em 10 fases',t:10,r:50,v:()=>ST().stars3},
 {id:'a10',e:'🔥',n:'Combo x5',d:'Faça 5 acertos seguidos',t:5,r:30,v:()=>ST().bestStreak},
 {id:'a11',e:'⚡',n:'Combo x10',d:'Faça 10 acertos seguidos',t:10,r:80,v:()=>ST().bestStreak},
 {id:'a12',e:'🗺️',n:'Explorador',d:'Chegue à fase 30',t:30,r:50,v:()=>sv.un},
 {id:'a13',e:'🌋',n:'Desbravador',d:'Chegue à fase 70',t:70,r:100,v:()=>sv.un},
 {id:'a14',e:'🎮',n:'Experimentador',d:'Jogue 5 partidas nos modos especiais',t:5,r:40,v:()=>ST().modes},
 {id:'a15',e:'🎯',n:'Mira afiada',d:'Dê 500 tiros',t:500,r:30,v:()=>ST().shots},
 {id:'a16',e:'⏳',n:'Dedicado',d:'Jogue por 1 hora',t:60,r:60,v:()=>Math.floor(ST().playMs/60000)},
 {id:'a17',e:'💰',n:'Tesouro',d:'Junte 1.000 moedas',t:1000,r:50,v:()=>sv.coins},
 {id:'a18',e:'🛍️',n:'Comprador',d:'Faça 5 compras com moedas',t:5,r:30,v:()=>ST().buys},
 {id:'a19',e:'👹',n:'Caçador de chefões',d:'Derrote 1 chefão',t:1,r:40,v:()=>ST().bosses},
 {id:'a20',e:'🗡️',n:'Domador de chefões',d:'Derrote 5 chefões',t:5,r:120,v:()=>ST().bosses},
 {id:'a21',e:'🐲',n:'Rei dos chefões',d:'Derrote 15 chefões',t:15,r:300,v:()=>ST().bosses},
 {id:'a22',e:'🌌',n:'Além do 200',d:'Chegue à fase 200',t:200,r:150,v:()=>sv.un},
 {id:'a23',e:'🏰',n:'Mestre supremo',d:'Chegue à fase 300',t:300,r:300,v:()=>sv.un}];
const achQ=[];let achBusy=false;
function achCheck(){for(const a of ACH){if(!sv.ach[a.id]&&a.v()>=a.t){sv.ach[a.id]=Date.now();sv.coins+=a.r;achQ.push(a);store()}}if(achQ.length&&!achBusy)nextBn()}
function nextBn(){const a=achQ.shift();if(!a){achBusy=false;return}achBusy=true;const b=$('achBn');b.innerHTML='<span style="font-size:28px">'+a.e+'</span><div><b>Conquista desbloqueada!</b><br><small>'+a.n+' • +'+a.r+' 🪙</small></div>';b.classList.add('on');sfx('win');vib([30,20,30]);refreshTop();if(Lumi)Lumi.say('Nova conquista! '+a.e,3000,true,'cheer');setTimeout(()=>{b.classList.remove('on');setTimeout(nextBn,500)},3200)}
function openAch(){sv.achSeen=Object.keys(sv.ach).length;store();$('achSum').textContent='Desbloqueadas: '+sv.achSeen+'/'+ACH.length;
 $('achList').innerHTML=ACH.map(a=>{const v=Math.min(a.t,a.v()),ok=sv.ach[a.id];return'<div class="card"><div class="ce">'+a.e+'</div><div class="ct"><b>'+a.n+'</b><small>'+a.d+'</small><div class="pbar"><i style="width:'+(v/a.t*100)+'%"></i></div></div><b style="color:'+(ok?'#6ee7a0':'#ffd23f')+'">'+(ok?'✔':v.toLocaleString('pt-BR')+'/'+a.t.toLocaleString('pt-BR'))+'</b></div>'}).join('');go('ovAch');refreshPills()}
// ---- Tutorial da primeira partida
const TUTO=[{e:'👆',t:'Mire',d:'Toque na tela e arraste para mirar. A linha pontilhada mostra o caminho da bolinha!'},{e:'🎯',t:'Atire',d:'Solte o dedo para atirar. A bolinha quica nas paredes.'},{e:'🌈',t:'Combine',d:'Junte 3 ou mais bolinhas da mesma cor para estourar. Grupos soltos caem!'},{e:'🔁',t:'Troque',d:'Toque na bolinha do canto esquerdo para trocar de cor e use os poderes 💣 e 🌈.'},{e:'🧚',t:'Fadinha',d:'Eu vou te dar uma dica antes de cada fase. Vamos jogar!'}];
let tuI=0,tuL=1;
function tutoRender(){const T=TUTO[tuI];$('tuE').textContent=T.e;$('tuT').textContent=T.t;$('tuD').textContent=T.d;$('tuDots').innerHTML=TUTO.map((x,i)=>'<i class="'+(i==tuI?'on':'')+'"></i>').join('');$('tuNext').textContent=tuI==TUTO.length-1?'Vamos jogar! 🎮':'Próximo'}
function showTuto(l){tuI=0;tuL=l;tutoRender();go('ovTuto')}
function tutoDone(){sv.tut=1;store();startLevel(tuL)}
$('tuNext').onclick=()=>{sfx('pop');if(tuI>=TUTO.length-1)tutoDone();else{tuI++;tutoRender()}};$('tuSkip').onclick=tutoDone;
// ---- Pedido de avaliação (aparece com jeitinho depois de algumas vitórias; nunca insiste)
let rtS=0;
function openLink(u){try{window.open(u,'_blank')}catch(e){try{location.href=u}catch(x){}}}
function maybeRate(){if(sv.rated)return;const w=ST().wins;if(w<3)return;if(sv.rsn&&w-sv.rsn<12)return;setTimeout(()=>{if(isVis('ovWin'))openRate()},2200)}
function openRate(){rtS=0;$('rMsg').textContent='';$('rGo').style.display='none';document.querySelectorAll('#rStars button').forEach(b=>b.classList.remove('on'));hideAll();$('ovRate').classList.remove('hide')}
function rtClose(){hideAll();$('ovWin').classList.remove('hide')}
$('rStars').onclick=e=>{const b=e.target.closest&&e.target.closest('button');if(!b)return;rtS=+b.getAttribute('data-s');document.querySelectorAll('#rStars button').forEach(x=>x.classList.toggle('on',+x.getAttribute('data-s')<=rtS));sfx('pop');const g=$('rGo');g.style.display='';if(rtS>=4){$('rMsg').textContent='Que bom! Uma avaliação na loja ajuda muito 💛';g.textContent='⭐ Avaliar na loja'}else{$('rMsg').textContent='Obrigado! Conta pra gente como melhorar 💬';g.textContent='✉️ Enviar sugestão'}};
$('rGo').onclick=()=>{sv.rated=1;store();openLink(rtS>=4?APP.rateUrl:'mailto:'+APP.email+'?subject='+encodeURIComponent('Sugestão - '+APP.name));rtClose()};
$('rLater').onclick=()=>{sv.rsn=ST().wins;store();rtClose()};
// ---- Backup do progresso (código com verificação, para guardar ou trocar de aparelho)
function hashS(j){let h=5381;for(let i=0;i<j.length;i++)h=((h<<5)+h+j.charCodeAt(i))|0;return(h>>>0).toString(36)}
function mkCode(){const j=JSON.stringify(sv);return'BC1.'+btoa(unescape(encodeURIComponent(j)))+'.'+hashS(j)}
function readCode(c){try{const p=String(c).trim().split('.');if(p[0]!='BC1'||p.length!=3)return null;const j=decodeURIComponent(escape(atob(p[1])));if(hashS(j)!=p[2])return null;const o=JSON.parse(j);return(typeof o.coins=='number'&&typeof o.un=='number')?o:null}catch(e){return null}}
function openBackup(){$('bkTxt').value=mkCode();$('bkMsg').textContent='';go('ovBackup')}
$('bkCopy').onclick=()=>{const t=$('bkTxt');t.value=mkCode();t.select&&t.select();let ok=false;try{if(navigator.clipboard){navigator.clipboard.writeText(t.value);ok=true}else ok=document.execCommand('copy')}catch(e){}$('bkMsg').textContent=ok?'Código copiado! ✅':'Selecione e copie o código acima.'};
$('bkRest').onclick=()=>{const o=readCode($('bkTxt').value);if(!o){$('bkMsg').textContent='Código inválido ❌ (confira se copiou tudo)';sfx('no');return}Object.assign(sv,o);sv.stat=Object.assign({shots:0,pops:0,falls:0,wins:0,losses:0,stars3:0,playMs:0,bestStreak:0,modes:0,buys:0,hitShots:0,bosses:0},sv.stat||{});sv.ach=sv.ach||{};store();refreshTop();refreshMenu();$('bkMsg').textContent='Progresso restaurado! ✅';sfx('win')};
$('bkBack').onclick=()=>{refSet();go('ovSet')};
// ---- Sobre / privacidade / configurações novas
function openAbout(){$('abT').textContent=APP.name;$('abV').textContent='Versão '+APP.version;go('ovAbout')}
$('abPriv').onclick=()=>openLink(APP.privacyUrl);$('abTerms').onclick=()=>openLink(APP.termsUrl);$('abMail').onclick=()=>openLink('mailto:'+APP.email);$('abBack').onclick=()=>{refSet();go('ovSet')};
$('tGq').onclick=()=>{const o=['auto','2','1','0'];sv.gq=o[(o.indexOf(String(sv.gq))+1)%4];if(sv.gq=='auto')sv.qa=undefined;applyQ();store();refSet();sfx('pop');toast('Gráficos: '+$('tGq').textContent.replace('Gráficos: ',''))};
$('tRm').onclick=()=>{sv.rm=sv.rm?0:1;applyRM();store();refSet();sfx('pop')};
$('tBk').onclick=openBackup;$('tAb').onclick=openAbout;
applyQ();applyRM();
document.querySelectorAll('button').forEach(b=>{const t=(b.textContent||'').trim();if(t&&!b.getAttribute('aria-label'))b.setAttribute('aria-label',t)}); // leitores de tela (TalkBack)
if(saveNote)setTimeout(()=>toast(saveNote),1500);
setInterval(refreshTop,1000);setInterval(achCheck,5000);
refreshMenu();buildLv();
// ===== v1.3.1 · Arte e botões profissionais: ilustrações em SVG (sem arquivos externos) + toque com ondinha =====
(function(){
 const enc=s=>'data:image/svg+xml;utf8,'+encodeURIComponent(s),
 CS=[['#ff4d6d','#a3123a'],['#3ea6ff','#0b4fa8'],['#3ddc84','#0f7a41'],['#ffd23f','#b07a00'],['#a66bff','#4b1fa8']],
 gd=(id,a,b)=>`<radialGradient id="${id}" cx=".35" cy=".3" r=".85"><stop offset="0" stop-color="#fff"/><stop offset=".25" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></radialGradient>`,
 B=(x,y,r,i)=>`<circle cx="${x}" cy="${y+3}" r="${r}" fill="rgba(0,0,0,.28)"/><circle cx="${x}" cy="${y}" r="${r}" fill="url(#b${i})" stroke="rgba(255,255,255,.6)" stroke-width="1.2"/><ellipse cx="${x-r*.3}" cy="${y-r*.42}" rx="${r*.42}" ry="${r*.24}" fill="#fff" opacity=".8"/><circle cx="${x+r*.38}" cy="${y+r*.4}" r="${r*.12}" fill="#fff" opacity=".45"/>`,
 SP=(x,y,s,d)=>`<path transform="translate(${x} ${y}) scale(${s})" d="M0-9Q1-1 9 0Q1 1 0 9Q-1 1-9 0Q-1-1 0-9Z" fill="#fff"><animate attributeName="opacity" values="1;.15;1" dur="${d}s" repeatCount="indefinite"/></path>`;
 let lg='';const rw=[5,4,3,2,1],ys=[26,55,84,113,142];
 rw.forEach((n,r)=>{for(let k=0;k<n;k++){lg+=B(110+(k-(n-1)/2)*34,ys[r],16.5,r==4?3:(r*2+k*3)%5)}});
 const LOGO=enc(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 180"><defs>${CS.map((c,i)=>gd('b'+i,c[0],c[1])).join('')}<radialGradient id="gl"><stop offset="0" stop-color="#b58cff" stop-opacity=".55"/><stop offset="1" stop-color="#b58cff" stop-opacity="0"/></radialGradient></defs><ellipse cx="110" cy="90" rx="108" ry="88" fill="url(#gl)"/>${lg}${SP(18,32,1.1,2.1)}${SP(204,58,.9,1.7)}${SP(26,128,.8,2.6)}${SP(196,140,1.2,1.9)}</svg>`),
 rays=Array.from({length:12},(_,i)=>`<path d="M60 60L${60+Math.cos(i*.5236-.12)*70} ${60+Math.sin(i*.5236-.12)*70}L${60+Math.cos(i*.5236+.12)*70} ${60+Math.sin(i*.5236+.12)*70}Z" fill="#ffe27a" opacity=".28"/>`).join(''),
 TROPHY=enc(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 124"><defs><linearGradient id="g1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff3a8"/><stop offset=".5" stop-color="#ffc61a"/><stop offset="1" stop-color="#d98a00"/></linearGradient><linearGradient id="g2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#4b1fa8"/></linearGradient></defs><g><animateTransform attributeName="transform" type="rotate" from="0 60 60" to="360 60 60" dur="18s" repeatCount="indefinite"/>${rays}</g><path d="M32 30H17c0 17 7 27 19 31M88 30h15c0 17-7 27-19 31" fill="none" stroke="url(#g1)" stroke-width="6" stroke-linecap="round"/><path d="M31 18h58v24c0 23-13 36-29 38-16-2-29-15-29-38z" fill="url(#g1)" stroke="#fff6c9" stroke-width="2"/><path d="M38 24v18c0 14 5 24 12 29" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" opacity=".5"/><polygon points="60,32 65,44 78,44 68,52 72,64 60,57 48,64 52,52 42,44 55,44" fill="#fff" opacity=".92"/><rect x="53" y="80" width="14" height="16" fill="url(#g1)"/><rect x="38" y="95" width="44" height="11" rx="4" fill="url(#g2)" stroke="#fff6c9" stroke-width="1.5"/><rect x="30" y="106" width="60" height="11" rx="5" fill="url(#g2)" stroke="#fff6c9" stroke-width="1.5"/>${SP(18,16,1.1,1.8)}${SP(104,22,.9,2.2)}${SP(100,92,.8,1.5)}</svg>`),
 SAD=enc(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 124"><defs>${gd('s0','#8fb8ff','#27458a')}</defs><ellipse cx="60" cy="116" rx="34" ry="6" fill="rgba(0,0,0,.35)"/><circle cx="60" cy="60" r="46" fill="url(#s0)" stroke="rgba(255,255,255,.5)" stroke-width="2"/><ellipse cx="44" cy="34" rx="16" ry="8" fill="#fff" opacity=".6"/><ellipse cx="45" cy="60" rx="6" ry="8" fill="#1a0b3d"/><ellipse cx="75" cy="60" rx="6" ry="8" fill="#1a0b3d"/><circle cx="47" cy="57" r="2.2" fill="#fff"/><circle cx="77" cy="57" r="2.2" fill="#fff"/><path d="M36 48l16 4M84 48l-16 4" stroke="#1a0b3d" stroke-width="3.5" stroke-linecap="round"/><path d="M45 86Q60 74 75 86" fill="none" stroke="#1a0b3d" stroke-width="4" stroke-linecap="round"/><path d="M84 70q5 8 0 12q-5-4 0-12z" fill="#bfe6ff"><animateTransform attributeName="transform" type="translate" values="0 0;0 14;0 0" dur="1.6s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0;1" dur="1.6s" repeatCount="indefinite"/></path></svg>`),
 HEART=enc(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 112"><defs>${gd('h0','#ff8aa0','#a3123a')}</defs><ellipse cx="60" cy="106" rx="30" ry="5" fill="rgba(0,0,0,.35)"/><path d="M60 102C14 68 6 44 6 30 6 16 17 6 31 6c11 0 23 6 29 16C66 12 78 6 89 6c14 0 25 10 25 24 0 14-8 38-54 72z" fill="url(#h0)" stroke="rgba(255,255,255,.55)" stroke-width="2"/><ellipse cx="34" cy="26" rx="14" ry="8" fill="#fff" opacity=".6" transform="rotate(-30 34 26)"/><path d="M60 22L51 44L69 56L57 80" fill="none" stroke="#2a0614" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`);
 const img=(src,cls)=>'<img class="art '+(cls||'')+'" alt="" draggable="false" src="'+src+'">',$$=id=>document.getElementById(id);
 try{
  const sp=$$('ovSplash'),rw0=sp&&sp.querySelector('.row');if(rw0)rw0.outerHTML=img(LOGO,'logo');
  const lc=$$('ovLoad').querySelector('.lc');if(lc)lc.insertAdjacentHTML('afterbegin',img(LOGO,'logo sm'));
  const tb=$$('ovStart').querySelector('.topbar');if(tb)tb.insertAdjacentHTML('afterbegin','<img class="mini" alt="" draggable="false" src="'+LOGO+'">');
  $$('ovWin').insertAdjacentHTML('afterbegin',img(TROPHY));
  $$('ovEnd').insertAdjacentHTML('afterbegin',img(SAD));
  $$('ovLives').insertAdjacentHTML('afterbegin',img(HEART,'sm'));
 }catch(e){}
 document.addEventListener('pointerdown',e=>{const b=e.target.closest&&e.target.closest('.btn,.btn2,.buy');if(!b||b.disabled)return;const r=b.getBoundingClientRect(),d=Math.max(r.width,r.height)*2.2,s=document.createElement('span');s.className='rip';s.style.cssText='width:'+d+'px;height:'+d+'px;left:'+(e.clientX-r.left-d/2)+'px;top:'+(e.clientY-r.top-d/2)+'px';b.appendChild(s);setTimeout(()=>s.remove(),600)},true);
})();

// ===== v1.4.0 · 🔦 MIRA LASER: poder novo. Toque no botão 🔦 (ao lado de 🌈 e 💣) para ligar até o fim da fase. =====
(function(){
 let LZ=false;const BX=114,BY=528;
 const _nl=newLevel;newLevel=function(){LZ=false;return _nl.apply(this,arguments)};
 const _d0=draw0;
 draw0=function(){
  _d0();
  try{
   // botão 🔦
   g.fillStyle=LZ?'rgba(255,210,63,.35)':'rgba(255,255,255,.12)';g.beginPath();g.arc(BX,BY,18,0,7);g.fill();g.strokeStyle=LZ?'#ffd23f':'rgba(255,255,255,.35)';g.lineWidth=2;g.stroke();
   g.font='18px serif';g.textAlign='center';g.fillStyle='#fff';g.fillText('🔦',BX,BY+7);
   g.fillStyle=sv.il?'#ffd23f':'#ff4d6d';g.beginPath();g.arc(BX+13,BY-12,8,0,7);g.fill();g.fillStyle='#1a0b3d';g.font='800 10px system-ui';g.fillText(sv.il||0,BX+13,BY-8);
   // laser
   if(LZ&&state=='play'&&!shot){
    const col=COL[spc||cur][0];let x=CX,y=CY,dx=Math.cos(ang)*4,dy=-Math.sin(ang)*4,pts=[[x,y]],bounces=0,end=false;
    for(let i=0;i<260&&!end;i++){x+=dx;y+=dy;
     if(x<4+R||x>W-4-R){dx*=-1;x=Math.max(4+R,Math.min(W-4-R,x));bounces++;pts.push([x,y])}
     if(y<TOP+R||hit(x,y))end=true}
    pts.push([x,y]);
    g.save();g.lineCap='round';g.lineJoin='round';g.shadowColor=col;g.shadowBlur=RMOD?0:12;
    g.strokeStyle=col;g.globalAlpha=.35;g.lineWidth=7;g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke();
    g.globalAlpha=.95;g.strokeStyle='#fff';g.lineWidth=2;g.setLineDash([10,6]);g.lineDashOffset=-tick*.8;g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke();g.setLineDash([]);
    g.globalAlpha=.9;g.fillStyle=col;g.beginPath();g.arc(x,y,R*.55+Math.sin(tick/6)*1.5,0,7);g.fill();g.restore()}
  }catch(e){}
 };
 cv.addEventListener('pointerdown',e=>{
  if(state!='play'||shot)return;const p=pt(e);
  if(p.y>508&&p.y<548&&Math.hypot(p.x-BX,p.y-BY)<22){
   e.stopImmediatePropagation();
   if(LZ){LZ=false;sfx('no');return}
   if(!(sv.il>0)){sfx('no');toast('Sem mira laser! Compre na loja 🛒');return}
   sv.il--;LZ=true;store();sfx('pop');ftx(CX,TOP+150,'🔦 MIRA LASER LIGADA','#ffd23f',18)}
 },true);
 // revisa o "Como jogar" e a loja ao abrir
 document.title='Magic Hues Balls';
})();
// ===== v1.5.0 · ❄️ CONGELAR: poder novo. Segura o teto (não desce) pelos próximos 3 tiros. Começa com 3; sem estoque, custa 60 🪙. =====
(function(){
 if(typeof sv.iz!='number')sv.iz=3;
 let FZ=0;const FX=156,FY=528;
 const _nl2=newLevel;newLevel=function(){FZ=0;return _nl2.apply(this,arguments)};
 const _fr=fire;fire=function(){const was=shot;_fr.apply(this,arguments);if(!was&&shot&&FZ>0)FZ--};
 const _d1=draw0;
 draw0=function(){
  _d1();
  try{
   if(FZ>0&&state=='play')miss=0; // enquanto congelado, o contador de erros não avança
   g.fillStyle=FZ>0?'rgba(110,231,255,.35)':'rgba(255,255,255,.12)';g.beginPath();g.arc(FX,FY,18,0,7);g.fill();
   g.strokeStyle=FZ>0?'#6ee7ff':'rgba(255,255,255,.35)';g.lineWidth=2;g.stroke();
   g.font='18px serif';g.textAlign='center';g.fillStyle='#fff';g.fillText('❄️',FX,FY+7);
   g.fillStyle=FZ>0?'#6ee7ff':(sv.iz>0?'#ffd23f':'#ff4d6d');g.beginPath();g.arc(FX+13,FY-12,8,0,7);g.fill();
   g.fillStyle='#1a0b3d';g.font='800 10px system-ui';g.fillText(FZ>0?Math.max(0,FZ-1):(sv.iz||0),FX+13,FY-8);
  }catch(e){}
 };
 cv.addEventListener('pointerdown',e=>{
  if(state!='play'||shot)return;const p=pt(e);
  if(p.y>508&&p.y<548&&Math.hypot(p.x-FX,p.y-FY)<22){
   e.stopImmediatePropagation();
   if(FZ>0){sfx('no');return}
   if(sv.iz>0)sv.iz--;else if(!spend(60))return;
   FZ=4;miss=0;store();sfx('pop');vib(25);ftx(CX,TOP+150,'❄️ TETO CONGELADO · 3 TIROS','#6ee7ff',18)}
 },true);
})();
