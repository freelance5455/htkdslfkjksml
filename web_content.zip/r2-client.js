/* R2 GAMES V22 - SCALE CLIENT / SERVER AUTHORITATIVE BRIDGE */
(() => {
  'use strict';
  const ID_RE=/^\d{16}$/; const CODE_RE=/^[A-Z0-9]{8}$/;
  const $=id=>document.getElementById(id);
  const toast=m=>{if(window.showToast)try{return window.showToast(m)}catch(_){} alert(m)};
  let me=null,socket=null,room=null,onlineGame=null;
  const gameLabels={auction:'المزاد برو ماكس',five:'الملعب الخماسي',deal:'DEAL OR NO DEAL',blind:'المزاد الأعمى',guess:'تخمين اللاعب',hidden:'اللاعب الخفي'};
  const gameKeys=['auction','five','deal','blind','guess','hidden'];
  const api=async(url,opt={})=>{const r=await fetch(url,{...opt,headers:{'Content-Type':'application/json',...(opt.headers||{})},cache:'no-store'});let d={};try{d=await r.json()}catch(_){}if(!r.ok||d.ok===false)throw Error(d.error||`HTTP ${r.status}`);return d};
  const load=()=>{try{return JSON.parse(localStorage.getItem('r2_v22_player')||'{}')}catch(_){return {}}};
  const save=()=>{if(me)localStorage.setItem('r2_v22_player',JSON.stringify(me))};
  async function ensurePlayer(){const o=load();const d=await api('/api/player/init',{method:'POST',body:JSON.stringify({playerId:ID_RE.test(String(o.id||''))?o.id:undefined,name:o.name||'R2 PLAYER'})});me=d.player;save();return me}
  function connect(){if(socket&&socket.connected)return socket;socket=io({transports:['websocket','polling'],reconnection:true,reconnectionAttempts:Infinity,reconnectionDelay:500,reconnectionDelayMax:5000});
    socket.on('connect',()=>{if(!me)return;socket.emit('identify',{playerId:me.id,name:me.name},()=>{});if(room?.code)socket.emit('room:state-request',{code:room.code,playerId:me.id},r=>{if(r?.ok){room=r.room;renderRoom();if(r.state?.started)startOnline(room.game,r.state)}})});
    socket.on('connect_error',()=>setStatus('🟠 إعادة الاتصال بالسيرفر...'));socket.on('disconnect',()=>setStatus('🟠 انقطع الاتصال — إعادة المحاولة...'));
    socket.on('room:connected',r=>{room=r;renderRoom()});socket.on('room:players',r=>{room=r;renderRoom()});socket.on('room:ready-state',r=>{room=r;renderRoom()});socket.on('room:restored',x=>{room=x.room;renderRoom();if(x.state?.started)startOnline(room.game,x.state)});
    socket.on('room:player-left',r=>{room=r;renderRoom()});socket.on('game:start',x=>{room=x.room;renderRoom();startOnline(x.game,x.state)});socket.on('game:sync',x=>renderOnlineState(x.state));
    socket.on('game:finished',x=>{room=x.room||room;renderRoom();renderFinished(x)});
    socket.on('friends:request',()=>{loadSocial();toast('📩 وصلك طلب صداقة جديد')});socket.on('friends:accepted',()=>{loadSocial();toast('🤝 تم قبول طلب الصداقة')});socket.on('match:request',x=>handleMatchRequest(x));socket.on('quick:matched',x=>{room=x.room;renderRoom();if(x.room?.state?.started)startOnline(x.game,x.room.state)});
    socket.on('ranked:waiting',x=>{const st=$('r2-ranked-status');if(st)st.textContent=`🔎 جاري البحث عن خصم للرانك ${x.ranked?.rank??''}...`;const s=$('r2-ranked-search'),c=$('r2-ranked-cancel');if(s)s.style.display='none';if(c)c.style.display='block'});
    socket.on('ranked:matched',x=>{room=x.room;const st=$('r2-ranked-status');if(st)st.textContent='⚡ تم إيجاد الخصم — المباراة تبدأ الآن';if(x.room?.state?.started)startOnline(x.game,x.room.state);renderRoom()});
    socket.on('ranked:promotion',x=>{toast(`🔥 مبروك! صعدت إلى الرانك ${x.rank}`);refreshR2Ranked()});
    socket.on('ranked:update',x=>{refreshR2Ranked()});
    socket.on('tournament:update',()=>loadTournamentList());socket.on('tournament:match-ready',x=>{toast(`🏆 مباراة البطولة جاهزة: ${gameLabels[x.room?.game]||''}`);room=x.room;renderRoom()});
    return socket}
  const waitSocket=(ms=9000)=>{connect();return new Promise((res,rej)=>{if(socket.connected)return res();const t=setTimeout(()=>rej(Error('السيرفر لم يستجب')),ms);socket.once('connect',()=>{clearTimeout(t);res()})})};
  const emit=(e,d)=>new Promise((res,rej)=>{if(!socket?.connected)return rej(Error('غير متصل بالسيرفر'));socket.emit(e,d,x=>x?.ok?res(x):rej(Error(x?.error||'تعذر تنفيذ الطلب')))})
  function setStatus(t){const e=$('room-status');if(e)e.textContent=t}
  function roomPanel(){let e=$('r2-room-panel');if(!e){e=document.createElement('div');e.id='r2-room-panel';e.className='r2-card';e.style.cssText='margin:12px 0;text-align:center;position:relative;z-index:9999';($('room-box')||document.body).appendChild(e)}return e}
  function renderRoom(){
    if(!room)return;
    const p=room.players||[],connected=p.filter(x=>x.connected).length,mine=p.find(x=>x.id===me?.id);
    setStatus(`🟢 ${connected}/2 متصل — ${room.started?'المباراة بدأت':p.length===2?'جاهز للعب — اضغط العب الآن':'في انتظار اللاعب الثاني'}`);
    const e=roomPanel();
    if(room.started){
      e.innerHTML=`<div style="font-size:1.1rem"><b>🎮 ${gameLabels[room.game]||room.game}</b><br>الغرفة ${room.code}<br>المباراة تعمل من السيرفر.</div>`;
      return;
    }
    const rows=p.map(x=>`<div style="padding:7px;border-bottom:1px solid rgba(255,255,255,.08)">${esc(x.name)} ${x.ready?'✅ جاهز':'⏳'} ${x.connected?'🟢':'🔴'}</div>`).join('')||'لا يوجد لاعبون';
    e.innerHTML=`<div style="font-size:1.1rem">🏠 ${esc(room.name||'غرفة R2')}<br>🔐 كود الغرفة: <b>${room.isPrivate===false?'عامة':room.code}</b></div>${rows}
      ${mine?.role==='host'&&p.some(x=>x.role!=='host')?`<button id="r2-kick-player" class="btn btn-secondary" style="margin-top:8px;width:100%">🚫 طرد اللاعب</button>`:''}${p.length===2?`<button id="r2-play-now-clean" class="btn" style="margin-top:10px;width:100%" ${mine?.ready?'disabled':''}>${mine?.ready?'✅ تم الضغط':'🎮 العب الآن'}</button>`:''}
      <button id="r2-leave-room" class="btn btn-secondary" style="margin-top:8px;width:100%">🚪 خروج من الغرفة</button>`;
    const kb=$('r2-kick-player');if(kb)kb.onclick=async()=>{const target=(room.players||[]).find(x=>x.role!=='host');if(!target)return;try{const x=await emit('room:kick',{code:room.code,targetId:target.id});room=x.room;renderRoom()}catch(err){toast(err.message)}};
    const b=$('r2-play-now-clean');
    if(b)b.onclick=async()=>{try{const x=await emit('room:play-now',{code:room.code});room=x.room;renderRoom()}catch(err){toast(err.message)}};
    const lb=$('r2-leave-room');
    if(lb)lb.onclick=async()=>{try{await emit('room:leave',{code:room.code});room=null;const panel=$('r2-room-panel');if(panel)panel.remove();setStatus('⚪ خرجت من الغرفة');toast('🚪 تم الخروج من الغرفة')}catch(err){toast(err.message)}};
  }
  async function createRoom(){try{await ensurePlayer();await waitSocket();const game=String($('r2-room-game')?.value||window.__r2SelectedOnlineGame||'auction');const roomName=String($('r2-room-name')?.value||'غرفة R2').trim();const isPrivate=String($('r2-room-visibility')?.value||'private')==='private';const x=await emit('room:create',{game,playerId:me.id,hostName:me.name,roomName,isPrivate,name:roomName});room=x;renderRoom();if($('generated-code'))$('generated-code').textContent=x.code;toast(`✅ غرفة ${gameLabels[x.game]} — شارك الكود`)}catch(e){toast(e.message)}}
  async function joinRoom(){try{const code=String($('join-code-input')?.value||'').trim().toUpperCase();if(!CODE_RE.test(code))return toast('كود الغرفة يجب أن يكون 8 حروف/أرقام');await ensurePlayer();await waitSocket();const x=await emit('room:join',{code,playerId:me.id,name:me.name,password:String($('join-password-input')?.value||'')});room=x;renderRoom();toast('✅ تم الاتصال بالغرفة. انتظر زر العب الآن')}catch(e){toast(e.message)}}
  async function loadPublicRooms(){try{await ensurePlayer();await waitSocket();const d=await emit('rooms:list',{});let box=$('r2-public-rooms-list');if(box)box.innerHTML=(d.rooms||[]).map(r=>`<div class="r2-card"><b>🏠 ${esc(r.name)}</b><br>${esc(gameLabels[r.game]||r.game)} — ${r.playerCount}/${r.maxPlayers}<button class="btn" style="width:100%;margin-top:6px" onclick="R2.joinPublicRoom('${r.code}')">دخول الغرفة</button></div>`).join('')||'لا توجد غرف عامة مفتوحة.'}catch(e){toast(e.message)}}
  async function joinPublicRoom(code){try{await ensurePlayer();await waitSocket();const x=await emit('room:join',{code,playerId:me.id,name:me.name});room=x;renderRoom();toast('✅ دخلت الغرفة العامة')}catch(e){toast(e.message)}}
  function startOnline(game,state){onlineGame=game;window.__r2OnlineGame=game;renderOnlineGame(game,state||{});}
  async function onlineEvent(type,data={}){try{const x=await emit('game:event',{code:room?.code,type,data});renderOnlineGame(onlineGame,x.state);return x}catch(e){toast(e.message);return null}}
  function renderOnlineGame(game,state){
    let e=$('r2-online-game');if(!e){e=document.createElement('div');e.id='r2-online-game';e.className='r2-card';e.style.cssText='position:fixed;inset:4%;z-index:100000;overflow:auto;background:#0b1020;border:1px solid rgba(255,215,0,.3);padding:18px';document.body.appendChild(e)}
    e.style.display='block'; const d=state.data||{}; const my=me?.id; const turn=state.turn; const mineTurn=turn===my;
    const head=`<h2>🎮 ${gameLabels[game]||game}</h2><div style="margin-bottom:10px">🌐 <b>Server Authoritative</b> — Revision ${state.revision||0}</div><div style="padding:8px;border-radius:10px;background:rgba(255,255,255,.05);margin-bottom:12px">${mineTurn?'🟢 دورك الآن':'🔴 دور الخصم'} — ${esc((room?.players||[]).find(x=>x.id===turn)?.name||'')}</div>`;
    let body='';
    if(game==='auction'||game==='five'){
      const a=d.auction||{};const card=a.cards?.[a.round];const budgets=a.budgetByPlayer||{};const squads=a.squads||{};
      body=`<div class="r2-card"><h3>⚽ اللاعب الحالي</h3><div style="font-size:1.4rem"><b>${esc(card?.name||'جاري التحضير')}</b> — ${esc(card?.pos||'')}</div><p>💰 السعر الحالي: <b>${Number(a.currentBid||10)}</b></p><p>💳 ${Number(budgets[my]||0)} ميزانية</p><p>الجولة ${Number(a.round||0)+1} / ${a.cards?.length||0}</p></div>
      <div class="r2-row"><input id="r2-online-bid" class="r2-input" type="number" min="11" placeholder="قيمة المزايدة"><button class="btn" id="r2-online-bid-btn" ${mineTurn?'':'disabled'}>💰 مزايدة</button><button class="btn btn-secondary" id="r2-online-pass" ${mineTurn?'':'disabled'}>🏳️ استسلام</button></div>
      <div class="r2-card"><b>التشكيلات:</b>${(room?.players||[]).map(p=>`<div>${esc(p.name)}: ${(squads[p.id]||[]).map(x=>esc(x.name)).join('، ')||'—'}</div>`).join('')}</div>`;
      setTimeout(()=>{$('r2-online-bid-btn')?.addEventListener('click',()=>onlineEvent('auction:bid',{amount:Number($('r2-online-bid')?.value||0)}));$('r2-online-pass')?.addEventListener('click',()=>onlineEvent('auction:surrender',{}));},0);
    } else if(game==='guess'){
      const g=d.guess||{};body=`<div class="r2-card"><h3>🕵️ الجولة ${g.round||1} / 5</h3><p>🏟️ الأندية: <b>${(g.clubs||[]).map(esc).join(' ← ')}</b></p><p>النتيجة: ${(room?.players||[]).map(p=>`${esc(p.name)} ${g.score?.[p.id]||0}`).join(' — ')}</p></div><input id="r2-online-answer" class="r2-input" placeholder="اسم اللاعب بالعربي" ${mineTurn?'':'disabled'}><button class="btn" id="r2-online-answer-btn" ${mineTurn?'':'disabled'}>إجابة</button>`;
      setTimeout(()=>{$('r2-online-answer-btn')?.addEventListener('click',()=>onlineEvent('guess:answer',{answer:$('r2-online-answer')?.value||''}));},0);
    } else if(game==='deal'){
      const x=d.deal||{};body=`<div class="r2-card"><h3>💼 الجولة ${Number(x.round||0)+1} / ${x.total||6}</h3><p>اختار صندوقًا. السيرفر هو الذي يحدد اللاعب/القيمة.</p><div class="r2-row">${[0,1,2,3].map(i=>`<button class="btn r2-deal-box" data-box="${i}" ${mineTurn&&!x.opened?'':'disabled'}>📦 صندوق ${i+1}</button>`).join('')}</div><p>${x.revealed?`🎁 تم الكشف: <b>${esc(x.revealed.name)}</b> — ${x.revealed.rating||0}`:''}</p></div>`;
      setTimeout(()=>document.querySelectorAll('.r2-deal-box').forEach(b=>b.onclick=()=>onlineEvent('deal:open',{box:Number(b.dataset.box)})),0);
    } else if(game==='blind'){
      const x=d.blind||{};body=`<div class="r2-card"><h3>🙈 الجولة ${Number(x.round||0)+1} / ${x.total||6}</h3><p>بطاقة: <b>${esc(x.currentCard?.name||'—')}</b></p><p>ميزانيتك: ${Number(x.budgetByPlayer?.[my]||0)}</p><input id="r2-blind-bid" class="r2-input" type="number" min="0" placeholder="مزايدتك" ${mineTurn?'':'disabled'}><button id="r2-blind-btn" class="btn" ${mineTurn?'':'disabled'}>إرسال المزايدة</button><p>${x.winner?`🏆 الفائز: ${esc((room.players||[]).find(p=>p.id===x.winner)?.name||'')}`:''}</p></div>`;
      setTimeout(()=>$('r2-blind-btn')?.addEventListener('click',()=>onlineEvent('blind:bid',{amount:Number($('r2-blind-bid')?.value||0)})),0);
    } else if(game==='hidden'){
      const x=d.hidden||{};body=`<div class="r2-card"><h3>🕶️ الجولة ${Number(x.round||0)+1} / ${x.total||6}</h3><p>اللاعب الظاهر: <b>${esc(x.visible?.name||'—')}</b> — ${x.visible?.rating||0}</p><p>اللاعب الخفي غير مكشوف.</p><div class="r2-row"><button id="r2-hidden-visible" class="btn" ${mineTurn?'':'disabled'}>⚽ أختار الظاهر</button><button id="r2-hidden-secret" class="btn" ${mineTurn?'':'disabled'}>🕶️ أختار الخفي</button></div></div>`;
      setTimeout(()=>{$('r2-hidden-visible')?.addEventListener('click',()=>onlineEvent('hidden:choose',{pick:'visible'}));$('r2-hidden-secret')?.addEventListener('click',()=>onlineEvent('hidden:choose',{pick:'secret'}));},0);
    }
    e.innerHTML=head+body+`<button id="r2-online-exit" class="btn btn-secondary" style="margin-top:15px">🚪 مغادرة الشاشة</button>`;
    $('r2-online-exit')?.addEventListener('click',async()=>{try{if(room?.code)await emit('room:leave',{code:room.code});}catch(_){} room=null;onlineGame=null;e.remove();const panel=$('r2-room-panel');if(panel)panel.remove();setStatus('⚪ خرجت من المباراة/الغرفة');});
  }
  function renderOnlineState(state){if(onlineGame)renderOnlineGame(onlineGame,state||{})}
  function renderFinished(x){renderOnlineGame(room?.game||onlineGame,{...(x.state||{}),ended:true})}
  async function sendFriendRequest(){try{await ensurePlayer();await waitSocket();const id=String($('friend-id-input')?.value||'').replace(/\D/g,'');if(!/^\d{16}$/.test(id))return toast('اكتب ID مكونًا من 16 رقمًا');const r=await emit('friends:add',{playerId:me.id,friendId:id});if(!r?.ok)throw new Error(r?.error||'تعذر إرسال الطلب');toast('✅ تم إرسال طلب الصداقة');if($('friend-id-input'))$('friend-id-input').value='';}catch(e){toast(e.message)}}
  async function loadSocial(){try{await ensurePlayer();await waitSocket();const f=await emit('friends:list',{playerId:me.id});const box=$('friends-list');if(box)box.innerHTML=(f.friends||[]).map(x=>`<div class="r2-card">👤 <b>${esc(x.name)}</b><br>ID: ${x.id}<br>${x.online?'🟢 متصل':'⚪ غير متصل'}</div>`).join('')||'لا يوجد أصدقاء حاليًا.';const inbox=await emit('inbox:get',{playerId:me.id});const ib=$('inbox-messages');if(ib)ib.innerHTML=[...(inbox.incomingRequests||[]).map(x=>`<div class="r2-card">📩 طلب صداقة من <b>${esc(x.name)}</b><br>ID: ${x.id}<div style="margin-top:8px"><button class="btn" onclick="window.__acceptFriend('${x.id}')">قبول</button><button class="btn btn-danger" onclick="window.__rejectFriend('${x.id}')">رفض</button></div></div>`),...(inbox.matchRequests||[]).map(x=>`<div class="r2-card">⚡ طلب مباراة من <b>${esc(x.from?.name||'صديق')}</b><br>${gameLabels[x.game]||x.game}<div style="margin-top:8px"><button class="btn" onclick="window.__acceptMatch('${esc(x.id)}','${esc(x.fromId)}','${esc(x.game)}')">قبول المباراة</button></div></div>`)].join('')||'📭 البريد الوارد فارغ.'}catch(e){console.warn(e);}}
  async function acceptFriend(id){try{await emit('friends:accept',{playerId:me.id,friendId:id});loadSocial()}catch(e){toast(e.message)}}async function rejectFriend(id){try{await emit('friends:reject',{playerId:me.id,friendId:id});loadSocial()}catch(e){toast(e.message)}}
  async function quickMatch(){try{await ensurePlayer();const f=await emit('friends:list',{playerId:me.id});const friends=f.friends||[];if(!friends.length)return toast('أضف صديقًا أولًا');const pick=prompt(friends.map((x,i)=>`${i+1}) ${x.name} — ${x.id}`).join('\n'));const x=friends[Number(pick)-1];if(!x)return;const game=prompt('اكتب: auction / five / deal / blind / guess / hidden','auction');if(!gameKeys.includes(game))return toast('اسم لعبة غير صحيح');await waitSocket();await emit('quick:invite',{playerId:me.id,friendId:x.id,game});toast('📨 تم إرسال طلب المباراة')}catch(e){toast(e.message)}}
  async function handleMatchRequest(x){const ok=confirm(`⚡ ${x.from?.name||'صديق'} دعاك لمباراة ${gameLabels[x.game]||x.game}\nهل تقبل؟`);if(!ok)return;try{const r=await emit('quick:accept',{requestId:x.id,fromId:x.from.id,playerId:me.id,name:me.name,game:x.game});room=r.room;renderRoom();if(r.started)startOnline(x.game,r.room.state)}catch(e){toast(e.message)}}
  async function createTournament(){try{await ensurePlayer();const size=Number($('r2-tournament-size')?.value||16);const gm=String($('r2-tournament-game')?.value||'auction');const map={'المزاد برو ماكس':'auction','الملعب الخماسي':'five','DEAL OR NO DEAL':'deal','المزاد الأعمى':'blind','تخمين اللاعب':'guess','اللاعب الخفي':'hidden'};const game=map[gm]||gm;const d=await api('/api/tournaments',{method:'POST',body:JSON.stringify({name:$('r2-tournament-name')?.value||'بطولة R2',size,game,playerId:me.id,isPrivate:!!$('r2-tournament-private')?.checked})});renderTournament(d.tournament,d.codes);loadTournamentList()}catch(e){toast(e.message)}}
  async function joinTournament(){try{await ensurePlayer();const d=await api('/api/tournaments/join',{method:'POST',body:JSON.stringify({code:String($('r2-tournament-code')?.value||'').trim().toUpperCase(),playerId:me.id})});renderTournament(d.tournament);loadTournamentList()}catch(e){toast(e.message)}}
  async function loadTournamentList(){try{const d=await api('/api/tournaments?playerId='+encodeURIComponent(me?.id||''));const e=$('r2-tournament-info');if(e)e.innerHTML=(d.tournaments||[]).slice(0,20).map(t=>`<div class="r2-card"><b>🏆 ${esc(t.name)}</b><br>${gameLabels[t.game]||t.game} — ${t.players}/${t.size}<br>الحالة: ${t.status}<br>أكواد متبقية: ${t.joinCodesRemaining}</div>`).join('')||'لا توجد بطولات.'}catch(_) {}}
  function renderTournament(t,codes){const e=$('r2-tournament-info');if(!e)return;const arr=Array.isArray(codes)?codes:[];e.innerHTML=`<div class="r2-card"><b>🏆 ${esc(t.name)}</b><br>اللاعبون: ${t.players}/${t.size}<br>${t.isPrivate?'🔒 بطولة خاصة — لا تظهر للناس':'🌍 بطولة عامة'}<br><b>أكواد الدعوة (${arr.length||t.joinCodesRemaining}):</b><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:6px;margin-top:8px">${arr.map((c,i)=>`<span class="r2-card" style="margin:0;text-align:center;cursor:pointer" onclick="navigator.clipboard?.writeText('${c}');this.style.outline='2px solid var(--gold-primary)'">${i+1}. <b>${c}</b></span>`).join('')||'<span>الأكواد محفوظة على السيرفر؛ أعد فتح البطولة من حساب المنشئ لعرضها.</span>'}</div></div>`}
  function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
  async function saveR2Name(){
    const input=$('r2-name-setting');
    const name=String(input?.value||'').trim();
    if(!name)return toast('اكتب اسمك أولًا');
    try{
      await ensurePlayer(); await waitSocket();
      const r=await emit('player:name-save',{name});
      me=r.player; save();
      const s=$('r2-name-status'); if(s)s.textContent='✅ تم حفظ الاسم على السيرفر: '+me.name;
      toast('✅ تم حفظ الاسم على السيرفر');
      const profileName=$('r2-v22-name'); if(profileName)profileName.textContent=me.name;
      if(window.closeModal)window.closeModal('settingsModal');
    }catch(e){toast(e.message)}
  }

  async function openR2Leaderboard(){
    const modal=$('r2-leaderboard-modal'); if(modal)modal.style.display='block';
    const box=$('r2-leaderboard-list'); if(box)box.innerHTML='جارٍ تحميل لوحة الصدارة...';
    try{
      await ensurePlayer(); await waitSocket();
      const d=await emit('leaderboard:get',{limit:50});
      if(box)box.innerHTML=(d.leaderboard||[]).map(x=>{
        const mine=x.id===me.id;
        const medal=x.position===1?'🥇':x.position===2?'🥈':x.position===3?'🥉':'#'+x.position;
        return `<div class="r2-card" style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin:7px 0;${mine?'outline:2px solid var(--gold-primary)':''}">
          <span style="min-width:45px">${medal}</span><span style="flex:1;text-align:right"><b>${esc(x.name)}</b><br><small>ID: ${x.id}</small></span><b>${Number(x.xb||0).toLocaleString()} XB</b>
        </div>`;
      }).join('')||'لا يوجد لاعبين بعد.';
    }catch(e){if(box)box.textContent=e.message}
  }
  function closeR2Leaderboard(){const m=$('r2-leaderboard-modal');if(m)m.style.display='none'}

  async function refreshR2Ranked(){
    try{
      await ensurePlayer(); await waitSocket();
      const d=await emit('ranked:get',{playerId:me.id});
      const r=d.ranked;
      const box=$('r2-ranked-info');
      if(box)box.innerHTML=`<div style="font-size:1.35rem">🏅 الرانك <b>${r.rank}</b></div>
        <div style="margin-top:7px">الانتصارات في الرانك: <b>${r.winsAtRank}/${r.winsRequired}</b></div>
        <div style="margin-top:7px">إجمالي المباريات: ${r.matches} — فوز ${r.wins} — خسارة ${r.losses} — تعادل ${r.draws}</div>`;
    }catch(e){const b=$('r2-ranked-info');if(b)b.textContent=e.message}
  }
  async function openR2Ranked(){
    const m=$('r2-ranked-modal');if(m)m.style.display='block';
    const st=$('r2-ranked-status');if(st)st.textContent='';
    const c=$('r2-ranked-cancel');if(c)c.style.display='none';
    const s=$('r2-ranked-search');if(s){s.style.display='block';s.disabled=false}
    await refreshR2Ranked();
  }
  function closeR2Ranked(){const m=$('r2-ranked-modal');if(m)m.style.display='none';cancelR2Ranked(true)}
  async function searchR2Ranked(silent=false){
    try{
      await ensurePlayer();await waitSocket();
      const game=String($('r2-ranked-game')?.value||'auction');
      const d=await emit('ranked:search',{game});
      const st=$('r2-ranked-status'),s=$('r2-ranked-search'),c=$('r2-ranked-cancel');
      if(d.matched){ room=d.room;renderRoom();if(st)st.textContent='⚡ تم إيجاد خصم — المباراة تبدأ الآن'; if(d.room.state?.started)startOnline(game,d.room.state); return; }
      if(st)st.textContent=`🔎 جاري البحث عن خصم قريب من الرانك ${d.ranked.rank}...`;
      if(s)s.style.display='none';if(c)c.style.display='block';
    }catch(e){if(!silent)toast(e.message)}
  }
  async function cancelR2Ranked(silent=false){
    try{if(socket?.connected)await emit('ranked:cancel',{});}catch(e){if(!silent)toast(e.message)}
    const s=$('r2-ranked-search'),c=$('r2-ranked-cancel'),st=$('r2-ranked-status');
    if(s)s.style.display='block';if(c)c.style.display='none';if(st)st.textContent='تم إلغاء البحث';
  }


  async function refreshR2Daily(){
    const box=$('r2-daily-list'); if(box)box.textContent='جارٍ تحميل المهام...';
    try{const d=await emit('daily:get',{});const tasks=d.daily?.tasks||[];
      if(box)box.innerHTML=tasks.map(t=>{const done=Number(t.progress)>=Number(t.target);return `<div class="r2-card" style="margin:10px 0"><b>${esc(t.name)}</b><br><span>التقدم: ${t.progress}/${t.target}</span><br><span>الجائزة: <b>30 XB</b></span><br>${t.claimed?'<span style="color:#5fda8b">✅ تم استلام الجائزة</span>':done?`<button class="btn" style="margin-top:8px" onclick="claimR2Daily('${t.id}')">🎁 المطالبة بالجائزة</button>`:'<span style="color:#aaa">⏳ أكمل المهمة لفتح الجائزة</span>'}</div>`}).join('')||'لا توجد مهام';
    }catch(e){if(box)box.textContent=e.message}
  }
  async function claimR2Daily(id){try{await emit('daily:claim',{taskId:id});toast('🎁 تمت إضافة 30 XB إلى حسابك');await ensurePlayer();refreshR2Daily()}catch(e){toast(e.message)}}
  function openR2Daily(){const m=$('r2-daily-modal');if(m)m.style.display='block';refreshR2Daily()}
  function closeR2Daily(){const m=$('r2-daily-modal');if(m)m.style.display='none'}
  // Compatibility: Ultimate Team is intentionally removed from the platform UI in V22.1.
  window.R2=window.R2||{};window.R2.completeGame=async(game='auction',result={})=>{try{await ensurePlayer();return await emit('game:single-complete',{playerId:me.id,game,claimKey:`${game}:${Date.now()}:${Math.random()}`,result})}catch(_){return null}};
  window.R2.completeFourTeams=async(result={})=>{try{await ensurePlayer();const r=await emit('game:four-teams-complete',{playerId:me.id,claimKey:`four-teams:${Date.now()}:${Math.random()}`,result});if(r?.reward)toast(`🎁 حصلت على ${r.reward.xb||0} XB`);return r}catch(_){return null}};
  window.openR2Profile=async()=>{try{await ensurePlayer();let m=$('r2-profile-v22');if(!m){m=document.createElement('div');m.id='r2-profile-v22';m.className='modal';m.style.display='block';m.innerHTML='<div class="modal-content" style="max-width:520px;text-align:center"><span class="close">&times;</span><h2>👤 البروفايل</h2><img id="r2-v22-avatar" style="width:100px;height:100px;object-fit:cover;border-radius:50%;display:none;margin:10px auto"><p>الاسم: <b id="r2-v22-name"></b></p><p style="font-size:1.4rem;letter-spacing:2px">ID: <b id="r2-v22-id"></b></p></div>';document.body.appendChild(m);m.querySelector('.close').onclick=()=>m.remove()}$('r2-v22-name').textContent=me.name;$('r2-v22-id').textContent=me.id;const av=$('r2-v22-avatar');if(av){av.src=me.avatar||'';av.style.display=me.avatar?'block':'none'}}catch(e){toast(e.message)}};
  async function saveAvatar(dataUrl){await ensurePlayer();const x=await emit('player:avatar-save',{avatar:dataUrl});me=x.player;save();toast('🖼️ تم حفظ صورة البروفايل');}
  window.createRoom=createRoom;window.generateNewRoomCode=createRoom;window.connectRoom=joinRoom;window.saveR2Name=saveR2Name;window.R2.saveAvatar=saveAvatar;window.openR2Leaderboard=openR2Leaderboard;window.closeR2Leaderboard=closeR2Leaderboard;window.openR2Ranked=openR2Ranked;window.openR2Daily=openR2Daily;window.closeR2Daily=closeR2Daily;window.claimR2Daily=claimR2Daily;window.closeR2Ranked=closeR2Ranked;window.searchR2Ranked=searchR2Ranked;window.cancelR2Ranked=cancelR2Ranked;window.sendFriendRequest=sendFriendRequest;window.quickMatch=quickMatch;window.__acceptFriend=acceptFriend;window.__rejectFriend=rejectFriend;window.__acceptMatch=async(id,from,game)=>{try{const r=await emit('quick:accept',{requestId:id,fromId:from,playerId:me.id,name:me.name,game});room=r.room;renderRoom()}catch(e){toast(e.message)}};
  window.R2.createTournament=createTournament;window.R2.joinTournament=joinTournament;
  // Opening social/tournament modals refreshes from the server, never localStorage.
  const oldOpen=window.openModal;window.openModal=function(id){if(oldOpen)oldOpen(id);if(id==='friendsModal'||id==='inboxModal')loadSocial();if(id==='tournamentModal')loadTournamentList();if(id==='settingsModal'){ensurePlayer().then(()=>{const n=$('r2-name-setting');if(n)n.value=me.name||''})}};
  // No room "continue/select game" control: room game is chosen only by the host before creation through a programmatic selection.
  window.__r2SelectOnlineGame=g=>{if(gameKeys.includes(g))window.__r2SelectedOnlineGame=g};
  // AI reliability patch: all six games must have an AI opponent in AI mode.
  function aiMode(){try{return typeof selectedMode!=='undefined'&&selectedMode==='ai'}catch(_){return false}}
  function aiPatch(){
    const origGuess=window.startGuessPlayerGame; if(origGuess)window.startGuessPlayerGame=function(){origGuess();if(aiMode())setTimeout(()=>{if(typeof guessTurn!=='undefined'&&guessTurn===2){const i=$('guess-answer');if(i){i.value=guessCurrent?.[0]||'';window.submitGuess?.()}}},700)};
    const origRenderGuess=window.renderGuessTurn; if(origRenderGuess)window.renderGuessTurn=function(){origRenderGuess();if(aiMode()&&typeof guessTurn!=='undefined'&&guessTurn===2)setTimeout(()=>{const i=$('guess-answer');if(i){i.value=guessCurrent?.[0]||'';window.submitGuess?.()}},700)};
    const origHidden=window.startHiddenPlayerGame; if(origHidden)window.startHiddenPlayerGame=function(){origHidden();if(aiMode())setTimeout(()=>{if(typeof hiddenTurn!=='undefined'&&hiddenTurn===2)window.chooseHidden?.(Number(hiddenVisible?.rating||0)<Number(hiddenSecret?.rating||0))},900)};
    const origRenderHidden=window.renderHiddenTurn; if(origRenderHidden)window.renderHiddenTurn=function(){origRenderHidden();if(aiMode()&&typeof hiddenTurn!=='undefined'&&hiddenTurn===2)setTimeout(()=>window.chooseHidden?.(Number(hiddenVisible?.rating||0)<Number(hiddenSecret?.rating||0)),800)};
    const origBlind=window.startBlindAuctionGame; if(origBlind)window.startBlindAuctionGame=function(){origBlind();if(aiMode())setTimeout(()=>{if(typeof blindEnterBid==='function')blindEnterBid(2)},900)};
    const origLoadDeal=window.setupDealStage; if(origLoadDeal)window.setupDealStage=function(){origLoadDeal();if(aiMode())setTimeout(()=>{const boxes=document.querySelectorAll('#p2-deal-boxes .box');if(boxes[0]&&!document.querySelector('#p2-deal-boxes .opened'))window.openDealBox?.(2,0,boxes[0])},850)};
  }
  async function boot(){try{await ensurePlayer();connect();loadSocial();loadTournamentList()}catch(e){console.warn('[R2 V22.1]',e.message)}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{aiPatch();boot()});else{aiPatch();boot()}
})();
