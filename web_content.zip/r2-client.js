/* R2 GAMES V22 - SCALE CLIENT / SERVER AUTHORITATIVE BRIDGE */
(() => {
  'use strict';
  const ID_RE=/^\d{16}$/; const CODE_RE=/^[A-Z0-9]{8}$/;
  const $=id=>document.getElementById(id);
  const toast=m=>{if(window.showToast)try{return window.showToast(m)}catch(_){} alert(m)};
  let me=null,socket=null,room=null,onlineGame=null,onlineLastState=null,identityAckSocketId=null,identifyingSocketId=null,identityPromise=null;
  let cachedFriends=[],outgoingInvite=null,outgoingInviteTimer=null;
  const chatState={mode:null,friendId:null,friendName:'',messages:[],opened:false,unreadRoom:0,unreadFriend:0};
  const gameLabels={auction:'المزاد برو ماكس',five:'الملعب الخماسي',deal:'DEAL OR NO DEAL',blind:'المزاد الأعمى',guess:'تخمين اللاعب',hidden:'اللاعب الخفي',four:'🏟️ ٤ فرق'};
  const gameKeys=['auction','five','deal','blind','guess','hidden','four'];
  const api=async(url,opt={})=>{const r=await fetch(url,{...opt,headers:{'Content-Type':'application/json',...(opt.headers||{})},cache:'no-store'});let d={};try{d=await r.json()}catch(_){}if(!r.ok||d.ok===false)throw Error(d.error||`HTTP ${r.status}`);return d};
  const load=()=>{try{return JSON.parse(localStorage.getItem('r2_v22_player')||'{}')}catch(_){return {}}};
  const save=()=>{if(me)localStorage.setItem('r2_v22_player',JSON.stringify(me))};
  async function ensurePlayer(){const o=load();const d=await api('/api/player/init',{method:'POST',body:JSON.stringify({playerId:ID_RE.test(String(o.id||''))?o.id:undefined,name:o.name||'R2 PLAYER'})});me=d.player;save();return me}
  function connect(){if(socket)return socket;socket=io({transports:['websocket','polling'],reconnection:true,reconnectionAttempts:Infinity,reconnectionDelay:500,reconnectionDelayMax:5000});
    socket.on('connect',()=>{identityAckSocketId=null;identifyingSocketId=null;identityPromise=null;if(!me)return;ensureIdentified().then(()=>{if(room?.code)socket.emit('room:state-request',{code:room.code,playerId:me.id},x=>{if(x?.ok){room=x.room;renderRoom();if(x.state?.started)startOnline(room.game,x.state)}})}).catch(e=>console.warn('[R2 identify]',e.message));});
    socket.on('connect_error',()=>setStatus('🟠 إعادة الاتصال بالسيرفر...'));socket.on('disconnect',()=>{identityAckSocketId=null;identifyingSocketId=null;identityPromise=null;setStatus('🟠 انقطع الاتصال — إعادة المحاولة...')});
    socket.on('room:connected',r=>{room=r;renderRoom()});socket.on('room:players',r=>{room=r;renderRoom()});socket.on('room:ready-state',r=>{room=r;renderRoom()});socket.on('room:restored',x=>{room=x.room;onlineLastState=x.state||onlineLastState;renderRoom();if(x.state?.started)startOnline(room.game,x.state)});
    socket.on('room:player-left',r=>{room=r;renderRoom()});socket.on('game:start',x=>{room=x.room;onlineLastState=x.state||onlineLastState;renderRoom();startOnline(x.game,x.state)});socket.on('game:sync',x=>{onlineLastState=x.state||onlineLastState;renderOnlineState(x.state)});
    socket.on('game:finished',x=>{const wasVisible=!!$('r2-online-game');room=x.room||room;onlineLastState=x.state||onlineLastState;renderRoom();if(wasVisible)renderFinished(x);else toast('🏁 انتهت المباراة. تقدر ترجع للغرفة من لوحة R2 أو تبدأ مباراة جديدة.');});
    socket.on('friends:request',()=>{loadSocial();toast('📩 وصلك طلب صداقة جديد')});
    socket.on('friends:accepted',()=>{loadSocial();toast('🤝 تم قبول طلب الصداقة')});
    socket.on('match:request',x=>{loadSocial();toast(`📬 طلب مباراة من ${x.from?.name||'صديق'} وصل للبريد الوارد`)});
    socket.on('match:request-cancelled',()=>loadSocial());
    socket.on('match:sent',x=>{outgoingInvite={id:x.id,toId:x.to?.id,friendName:x.to?.name||'صديق',game:x.game};showMatchWaiting(outgoingInvite)});
    socket.on('match:accepted',x=>{hideMatchWaiting();toast('✅ صديقك قبل المباراة؛ جاري تجهيز الغرفة')});
    socket.on('quick:matched',x=>{hideMatchWaiting();room=x.room;if(!chatState.mode||chatState.mode==='room')chatState.mode='room';renderRoom();if(x.state?.started)onlineLastState=x.state;renderChatDock()});
    socket.on('quick:expired',()=>{const st=$('r2-ranked-status');if(st)st.textContent='انتهى وقت البحث عن خصم. جرّب مرة أخرى.';toast('انتهى وقت انتظار الخصم؛ جرّب البحث مرة أخرى')});
    socket.on('room:chat:message',handleRoomChatMessage);
    socket.on('friends:chat:message',handleFriendChatMessage);
    socket.on('ranked:waiting',x=>{const st=$('r2-ranked-status');if(st)st.textContent=`🔎 جاري البحث عن خصم للرانك ${x.ranked?.rank??''}...`;const s=$('r2-ranked-search'),c=$('r2-ranked-cancel');if(s)s.style.display='none';if(c)c.style.display='block'});
    socket.on('ranked:matched',x=>{room=x.room;const st=$('r2-ranked-status');if(st)st.textContent='⚡ تم إيجاد الخصم — المباراة تبدأ الآن';if(x.room?.state?.started)startOnline(x.game,x.room.state);renderRoom()});
    socket.on('ranked:promotion',x=>{toast(`🔥 مبروك! صعدت إلى الرانك ${x.rank}`);refreshR2Ranked()});
    socket.on('ranked:update',x=>{refreshR2Ranked()});
    socket.on('tournament:update',()=>loadTournamentList());socket.on('tournament:match-ready',x=>{toast(`🏆 مباراة البطولة جاهزة: ${gameLabels[x.room?.game]||''}`);room=x.room;renderRoom()});
    return socket}
  function ensureIdentified(ms=9000){
    if(!socket?.connected)return Promise.reject(Error('الاتصال بالسيرفر غير متاح'));
    if(!me?.id)return Promise.reject(Error('بيانات اللاعب غير جاهزة'));
    if(identityAckSocketId===socket.id)return Promise.resolve(socket);
    if(identifyingSocketId===socket.id&&identityPromise)return identityPromise;
    identifyingSocketId=socket.id;
    identityPromise=new Promise((resolve,reject)=>{const timer=setTimeout(()=>{if(identifyingSocketId===socket.id){identifyingSocketId=null;identityPromise=null;}reject(Error('السيرفر لم يستجب لتسجيل الاتصال'))},ms);socket.emit('identify',{playerId:me.id,name:me.name},r=>{clearTimeout(timer);if(r?.ok){identityAckSocketId=socket.id;resolve(socket)}else reject(Error(r?.error||'تعذر تسجيل اللاعب بالسيرفر'))})});
    identityPromise.catch(()=>{if(identifyingSocketId===socket.id){identifyingSocketId=null;identityPromise=null}});
    return identityPromise;
  }
  const waitSocket=(ms=9000)=>{connect();return new Promise((resolve,reject)=>{let done=false;const timer=setTimeout(()=>{if(done)return;done=true;reject(Error('السيرفر لم يستجب'))},ms);const ready=()=>{if(done||!socket?.connected)return;ensureIdentified(ms).then(()=>{if(done)return;done=true;clearTimeout(timer);resolve(socket)}).catch(e=>{if(done)return;done=true;clearTimeout(timer);reject(e)})};if(socket.connected)ready();else socket.once('connect',ready)})};
  const emit=(e,d)=>new Promise((res,rej)=>{if(!socket?.connected)return rej(Error('غير متصل بالسيرفر'));socket.emit(e,d,x=>x?.ok?res(x):rej(Error(x?.error||'تعذر تنفيذ الطلب')))})
  function setStatus(t){const e=$('room-status');if(e)e.textContent=t}
  function playerCardImage(p){return String(p?.avatar||('/api/player-image?name='+encodeURIComponent(p?.name||'Player')));}
  function roomPanel(){let e=$('r2-room-panel');if(!e){e=document.createElement('div');e.id='r2-room-panel';e.className='r2-card';e.style.cssText='margin:12px 0;text-align:center;position:relative;z-index:9999';($('room-box')||document.body).appendChild(e)}return e}
  function renderRoom(){
    if(!room){renderChatDock();return;}
    if(!chatState.mode)chatState.mode='room';
    const p=room.players||[],connected=p.filter(x=>x.connected).length,mine=p.find(x=>x.id===me?.id),max=Number(room.maxPlayers||2);
    setStatus(`🟢 ${connected}/${max} متصل — ${room.started?'المباراة بدأت':p.length===max?`كل الفرق دخلت — كل لاعب لازم يضغط العب الآن (${room.readyCount||0}/${max})`:`في انتظار اللاعبين (${p.length}/${max})`}`);
    const e=roomPanel();
    if(room.started && room.ended){
      e.innerHTML=`<div style="font-size:1.1rem"><b>🏁 انتهت المباراة</b><br>${gameLabels[room.game]||room.game}<br>الغرفة ${room.code}</div><button id="r2-leave-finished-room" class="btn btn-secondary" style="margin-top:10px;width:100%">🚪 إنهاء الجلسة والخروج</button><button class="btn" style="margin-top:8px;width:100%" onclick="R2.openRoomChat()">💬 عرض دردشة المباراة</button>`;
      $('r2-leave-finished-room').onclick=async()=>{try{await emit('room:leave',{code:room.code,playerId:me.id});room=null;onlineGame=null;onlineLastState=null;if(chatState.mode==='room'){chatState.mode=null;chatState.messages=[];chatState.opened=false;}e.remove();setStatus('⚪ خرجت من الغرفة');renderChatDock();}catch(err){toast(err.message)}};
      renderChatDock();return;
    }
    if(room.started){
      e.innerHTML=`<div style="font-size:1.1rem"><b>🎮 ${gameLabels[room.game]||room.game}</b><br>الغرفة ${room.code}<br>المباراة ما زالت شغالة على السيرفر.</div><button id="r2-return-match" class="btn" style="margin-top:10px;width:100%">⚽ الرجوع للمباراة</button><button class="btn btn-secondary" style="margin-top:8px;width:100%" onclick="R2.openRoomChat()">💬 دردشة المباراة</button>`;
      $('r2-return-match').onclick=()=>reopenOnlineGame();
      renderChatDock();return;
    }
    const invite=(room.game==='four'&&Array.isArray(room.inviteCodes))?`<div style="margin:10px 0;padding:10px;border:1px solid rgba(255,215,0,.25);border-radius:10px"><b>🔑 أكواد دخول الفرق الثلاثة:</b><br>${room.inviteCodes.map((c,i)=>`الفريق ${i+1}: <b>${c}</b>`).join('<br>')}</div>`:'';
    const rows=p.map(x=>`<div style="padding:7px;border-bottom:1px solid rgba(255,255,255,.08);display:flex;gap:8px;align-items:center"><img src="${x.avatar||''}" onerror="this.style.display='none'" style="width:34px;height:34px;border-radius:50%;object-fit:cover"><span>${esc(x.name)} ${x.ready?'✅ جاهز':'⏳'} ${x.connected?'🟢':'🔴'}</span></div>`).join('')||'لا يوجد لاعبون';
    e.innerHTML=`<div style="font-size:1.1rem">🏠 ${esc(room.name||'غرفة R2')}<br>🔐 كود الغرفة: <b>${room.isPrivate===false?'عامة':room.code}</b></div>${invite}${rows}
      ${mine?.role==='host'&&p.some(x=>x.role!=='host')?`<button id="r2-kick-player" class="btn btn-secondary" style="margin-top:8px;width:100%">🚫 طرد اللاعب</button>`:''}${p.length===max?`<button id="r2-play-now-clean" class="btn" style="margin-top:10px;width:100%" ${mine?.ready?'disabled':''}>${mine?.ready?'✅ تم الضغط':'🎮 العب الآن'}</button>`:''}
      <button id="r2-leave-room" class="btn btn-secondary" style="margin-top:8px;width:100%">🚪 خروج من الغرفة</button>`;
    const kb=$('r2-kick-player');if(kb)kb.onclick=async()=>{const target=(room.players||[]).find(x=>x.role!=='host');if(!target)return;try{const x=await emit('room:kick',{code:room.code,targetId:target.id});room=x.room;renderRoom()}catch(err){toast(err.message)}};
    const b=$('r2-play-now-clean');
    if(b)b.onclick=async()=>{try{const x=await emit('room:play-now',{code:room.code});room=x.room;renderRoom()}catch(err){toast(err.message)}};
    const lb=$('r2-leave-room');
    if(lb)lb.onclick=async()=>{try{await emit('room:leave',{code:room.code});room=null;onlineGame=null;if(chatState.mode==='room'){chatState.mode=null;chatState.messages=[];chatState.opened=false;}const panel=$('r2-room-panel');if(panel)panel.remove();setStatus('⚪ خرجت من الغرفة');renderChatDock();toast('🚪 تم الخروج من الغرفة')}catch(err){toast(err.message)}};
    renderChatDock();
  }
  async function createRoom(){try{await ensurePlayer();await waitSocket();const game=String($('r2-room-game')?.value||window.__r2SelectedOnlineGame||'auction');const roomName=String($('r2-room-name')?.value||'غرفة R2').trim();const isPrivate=String($('r2-room-visibility')?.value||'private')==='private';const auctionVariant=String(document.getElementById('r2-room-auction-variant')?.value||window.__r2OnlineAuctionVariant||'classic');const fourGame=String(document.getElementById('r2-room-four-game')?.value||'auction');const x=await emit('room:create',{game,playerId:me.id,hostName:me.name,roomName,isPrivate,name:roomName,auctionVariant,fourGame});room=x;renderRoom();if($('generated-code'))$('generated-code').textContent=x.code;toast(`✅ غرفة ${gameLabels[x.game]} — شارك الكود`)}catch(e){toast(e.message)}}
  async function joinRoom(){try{const code=String($('join-code-input')?.value||'').trim().toUpperCase();if(!CODE_RE.test(code))return toast('كود الغرفة يجب أن يكون 8 حروف/أرقام');await ensurePlayer();await waitSocket();const x=await emit('room:join',{code,playerId:me.id,name:me.name,password:String($('join-password-input')?.value||'')});room=x;renderRoom();toast('✅ تم الاتصال بالغرفة. انتظر زر العب الآن')}catch(e){toast(e.message)}}
  async function loadPublicRooms(){try{await ensurePlayer();await waitSocket();const d=await emit('rooms:list',{});let box=$('r2-public-rooms-list');if(box)box.innerHTML=(d.rooms||[]).map(r=>`<div class="r2-card"><b>🏠 ${esc(r.name)}</b><br>${esc(gameLabels[r.game]||r.game)} — ${r.playerCount}/${r.maxPlayers}<button class="btn" style="width:100%;margin-top:6px" onclick="R2.joinPublicRoom('${r.code}')">دخول الغرفة</button></div>`).join('')||'لا توجد غرف عامة مفتوحة.'}catch(e){toast(e.message)}}
  async function joinPublicRoom(code){try{await ensurePlayer();await waitSocket();const x=await emit('room:join',{code,playerId:me.id,name:me.name});room=x;renderRoom();toast('✅ دخلت الغرفة العامة')}catch(e){toast(e.message)}}
  setInterval(()=>{const list=$('r2-public-rooms-list');const modal=list?.closest('.modal');if(document.visibilityState==='visible'&&list&&modal&&getComputedStyle(modal).display!=='none')loadPublicRooms().catch(()=>{})}, 10000);
  function startOnline(game,state){onlineGame=game;onlineLastState=state||onlineLastState;window.__r2OnlineGame=game;if(room?.code&&!chatState.mode)chatState.mode='room';renderOnlineGame(game,onlineLastState||{});renderChatDock();}
  function reopenOnlineGame(){if(!room?.code||!room.started||room.ended)return toast('المباراة غير متاحة للعودة');startOnline(room.game,onlineLastState||{});}
  async function onlineEvent(type,data={}){try{const expectedRevision=Number(room?.state?.revision);const x=await emit('game:event',{code:room?.code,type,data:{...data,expectedRevision:Number.isInteger(expectedRevision)?expectedRevision:undefined}});if(x?.state)room.state=x.state;renderOnlineGame(onlineGame,x.state);return x}catch(e){toast(e.message);return null}}
  function renderOnlineGame(game,state){
    let e=$('r2-online-game');if(!e){e=document.createElement('div');e.id='r2-online-game';e.className='r2-card';e.style.cssText='position:fixed;inset:4%;z-index:100000;overflow:auto;background:#0b1020;border:1px solid rgba(255,215,0,.3);padding:18px';document.body.appendChild(e)}
    e.style.display='block'; const d=state.data||{}; const my=me?.id; const turn=state.turn; const mineTurn=turn===my;
    const head=`<h2>🎮 ${gameLabels[game]||game}</h2><div style="margin-bottom:10px">🌐 <b>Server Authoritative</b> — Revision ${state.revision||0}</div><div style="padding:8px;border-radius:10px;background:rgba(255,255,255,.05);margin-bottom:12px">${mineTurn?'🟢 دورك الآن':'🔴 دور الخصم'} — ${esc((room?.players||[]).find(x=>x.id===turn)?.name||'')}</div>`;
    let body='';
    if(game==='four'){
      const f=d.four||state.data?.four||{}; const players=room?.players||[]; const card=f.cards?.[f.round];
      const teamCards=players.map(p=>{const sq=f.squads?.[p.id]||[];return `<div class="r2-card" style="margin:6px 0"><b>${esc(p.name)}</b> — 💰 ${Number(f.budgetByPlayer?.[p.id]||0)}M$ — 👥 ${sq.length}<br><small>${sq.map(x=>esc(x.name)).join(' • ')||'لاعبون لم يصلوا بعد'}</small></div>`}).join('');
      if(f.finished){
        const mineSq=f.squads?.[my]||[]; const used=f.cardsUsed?.[my]||{}; const protectedName=f.protections?.[my]||'';
        const others=players.filter(p=>p.id!==my).map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
        body=`<div class="r2-card"><h3>🏁 انتهى المزاد — مرحلة Wild Card والكروت</h3>${teamCards}<hr><h3>🃏 Wild Card</h3><select id="r2-four-wild" style="width:100%;padding:8px">${mineSq.map(x=>`<option>${esc(x.name)}</option>`).join('')}</select><button class="btn" style="width:100%;margin-top:6px" ${f.wildcardUsed?.[my]?'disabled':''} onclick="R2.fourWildcard(document.getElementById('r2-four-wild').value)">${f.wildcardUsed?.[my]?'✅ تم استخدام Wild Card':'🃏 استخدام Wild Card'}</button><hr><h3>💳 الكروت</h3><select id="r2-four-card-player" style="width:100%;padding:8px">${mineSq.map(x=>`<option>${esc(x.name)}</option>`).join('')}</select><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:6px"><button class="btn" ${used.norisk?'disabled':''} onclick="R2.fourCard('norisk',document.getElementById('r2-four-card-player').value)">🚫 60M</button><button class="btn" ${used.protect?'disabled':''} onclick="R2.fourCard('protect',document.getElementById('r2-four-card-player').value)">🛡️ 75M</button></div><label style="display:block;margin-top:8px">اختار فريق الخصم:</label><select id="r2-four-steal-team" style="width:100%;padding:8px;margin-top:6px"><option value="">— اختار الفريق أولًا —</option>${others}</select><label style="display:block;margin-top:8px">تشكيلة الخصم:</label><select id="r2-four-steal-player" disabled style="width:100%;padding:8px;margin-top:6px"><option value="">اختار فريق الخصم أولًا</option></select><button class="btn btn-danger" style="width:100%;margin-top:6px" ${used.steal?'disabled':''} onclick="R2.fourCard('steal',document.getElementById('r2-four-card-player').value,document.getElementById('r2-four-steal-team').value,document.getElementById('r2-four-steal-player').value)">🕵️ السرقة — 127M</button>${protectedName?`<p>🛡️ اللاعب المحمي: <b>${esc(protectedName)}</b></p>`:''}<hr><h3>👑 الكابتن</h3><select id="r2-four-cap" style="width:100%;padding:8px">${mineSq.map(x=>`<option>${esc(x.name)}</option>`).join('')}</select><button class="btn" style="width:100%;margin-top:6px" onclick="R2.fourCaptain(document.getElementById('r2-four-cap').value)">اختيار الكابتن</button><button class="btn" style="width:100%;margin-top:6px" onclick="R2.fourCoach()">🎩 اختيار مدرب عشوائي</button><p style="margin-top:8px">الكابتن الحالي: <b>${esc(f.captains?.[my]||'—')}</b> — المدرب: <b>${esc(f.coaches?.[my]?.[0]||'—')}</b></p></div>`;
      setTimeout(()=>{
        const teamSel=document.getElementById('r2-four-steal-team');
        const playerSel=document.getElementById('r2-four-steal-player');
        if(teamSel&&playerSel){
          teamSel.onchange=()=>{
            const targetId=teamSel.value;
            const squad=f.squads?.[targetId]||[];
            playerSel.disabled=!targetId;
            playerSel.innerHTML=targetId ? (squad.map(x=>`<option value="${esc(x.name)}">${esc(x.name)} — ${esc(x.pos||x.position||'')}</option>`).join('')||'<option value="">لا يوجد لاعبون</option>') : '<option value="">اختار فريق الخصم أولًا</option>';
          };
        }
      },0);
      }else{
        const myActive=(f.active||[]).includes(my); const myTurn=turn===my;
        body=`<div class="r2-card"><h3>${f.fourGame==='five'?'⚽ ٤ فرق — الملعب الخماسي':'🔨 مزاد ٤ فرق'} — ${esc(f.variant||'classic')}</h3><div style="text-align:center"><img src="${playerCardImage(card)}" onerror="this.src='/api/player-image?name=Football%20Player'" style="width:110px;height:110px;border-radius:50%;object-fit:cover;border:2px solid var(--gold-primary)"><div style="font-size:1.35rem"><b>${esc(card?.name||'جاري التحضير')}</b> — ${card?.rating||''} — ${card?.pos||''}</div></div><div style="text-align:center;margin:10px">💰 أعلى مزايدة: <b>${Number(f.currentBid||0)}M$</b><br>🏆 المتصدر: <b>${esc(players.find(p=>p.id===f.leader)?.name||'لا يوجد')}</b><br>📱 الدور: <b>${esc(players.find(p=>p.id===turn)?.name||'')}</b></div><div style="display:grid;grid-template-columns:repeat(2,1fr);gap:7px"><button class="btn" ${!myTurn||!myActive?'disabled':''} onclick="R2.fourBid(1)">+1M</button><button class="btn" ${!myTurn||!myActive?'disabled':''} onclick="R2.fourBid(5)">+5M</button><button class="btn" ${!myTurn||!myActive?'disabled':''} onclick="R2.fourBid(10)">+10M</button><button class="btn btn-danger" ${!myTurn||!myActive?'disabled':''} onclick="R2.fourWithdraw()">انسحاب من اللاعب</button></div><div style="display:flex;gap:6px;margin-top:8px"><input id="r2-four-custom" type="number" min="1" placeholder="زيادة مكتوبة" style="flex:1;padding:8px"><button class="btn" ${!myTurn||!myActive?'disabled':''} onclick="R2.fourCustom()">مزايدة</button></div></div>${teamCards}`;
      }
      e.innerHTML=head+body; return;
    }
    if(game==='auction'||game==='five'){
      const a=d.auction||{};const card=a.cards?.[a.round];const budgets=a.budgetByPlayer||{};const squads=a.squads||{};
      body=`<div class="r2-card"><h3>⚽ اللاعب الحالي</h3><div style="text-align:center"><img src="${playerCardImage(card)}" onerror="this.src='/api/player-image?name=Football%20Player'" style="width:105px;height:105px;border-radius:50%;object-fit:cover;border:2px solid var(--gold-primary)"><div style="font-size:1.4rem"><b>${esc(card?.name||'جاري التحضير')}</b> — ${esc(card?.pos||'')}</div></div><p>💰 السعر الحالي: <b>${Number(a.currentBid||10)}</b></p><p>💳 ${Number(budgets[my]||0)} ميزانية</p><p>الجولة ${Number(a.round||0)+1} / ${a.cards?.length||0}</p></div>
      <div class="r2-row"><input id="r2-online-bid" class="r2-input" type="number" min="11" placeholder="قيمة المزايدة"><button class="btn" id="r2-online-bid-btn" ${mineTurn?'':'disabled'}>💰 مزايدة</button><button class="btn btn-secondary" id="r2-online-pass" ${mineTurn?'':'disabled'}>🏳️ استسلام</button></div>
      <div class="r2-card"><b>التشكيلات:</b>${(room?.players||[]).map(p=>`<div>${esc(p.name)}: ${(squads[p.id]||[]).map(x=>esc(x.name)).join('، ')||'—'}</div>`).join('')}</div>`;
      setTimeout(()=>{$('r2-online-bid-btn')?.addEventListener('click',()=>onlineEvent('auction:bid',{amount:Number($('r2-online-bid')?.value||0)}));$('r2-online-pass')?.addEventListener('click',()=>onlineEvent('auction:surrender',{}));},0);
    } else if(game==='guess'){
      const g=d.guess||{};body=`<div class="r2-card"><h3>🕵️ الجولة ${g.round||1} / 5</h3><p>🏟️ الأندية: <b>${(g.clubs||[]).map(esc).join(' ← ')}</b></p><p>النتيجة: ${(room?.players||[]).map(p=>`${esc(p.name)} ${g.score?.[p.id]||0}`).join(' — ')}</p></div><input id="r2-online-answer" class="r2-input" placeholder="اسم اللاعب بالعربي" ${mineTurn?'':'disabled'}><button class="btn" id="r2-online-answer-btn" ${mineTurn?'':'disabled'}>إجابة</button>`;
      setTimeout(()=>{$('r2-online-answer-btn')?.addEventListener('click',()=>onlineEvent('guess:answer',{answer:$('r2-online-answer')?.value||''}));},0);
    } else if(game==='deal'){
      const x=d.deal||{};body=`<div class="r2-card"><h3>💼 الجولة ${Number(x.round||0)+1} / ${x.total||6}</h3><p>اختار صندوقًا. السيرفر هو الذي يحدد اللاعب/القيمة.</p><div class="r2-row">${[0,1,2,3].map(i=>`<button class="btn r2-deal-box" data-box="${i}" ${mineTurn&&!x.opened?'':'disabled'}>📦 صندوق ${i+1}</button>`).join('')}</div><p>${x.revealed?`🎁 تم الكشف: <b>${esc(x.revealed.name)}</b> — ${x.revealed.rating||0}`:''}</p></div>`;
      setTimeout(()=>document.querySelectorAll('.r2-deal-box').forEach(b=>b.onclick=()=>onlineEvent('deal:open',{box:Number(b.dataset.box)})),0);
    } else if(game==='blind'){
      const x=d.blind||{};body=`<div class="r2-card"><h3>🙈 الجولة ${Number(x.round||0)+1} / ${x.total||6}</h3><p>بطاقة: <b>${esc(x.currentCard?.name||'—')}</b></p><p>ميزانيتك: ${Number(x.budgetByPlayer?.[my]||0)}</p><input id="r2-blind-bid" class="r2-input" type="number" min="0" placeholder="مزايدتك" ${mineTurn?'':'disabled'}><button id="r2-blind-btn" class="btn" ${mineTurn?'':'disabled'}>إرسال المزايدة</button><p>${x.winner?`🏆 الفائز: ${esc((room.players||[]).find(p=>p.id===x.winner)?.name||'')}`:''}</p></div>`;
      setTimeout(()=>$('r2-blind-btn')?.addEventListener('click',()=>onlineEvent('blind:bid',{amount:Number($('r2-blind-bid')?.value||0)})),0);
    } else if(game==='hidden'){
      const x=d.hidden||{};body=`<div class="r2-card"><h3>🕶️ الجولة ${Number(x.round||0)+1} / ${x.total||6}</h3><p>اللاعب الظاهر: <b>${esc(x.visible?.name||'—')}</b> — ${x.visible?.rating||0}</p><p>اللاعب الخفي غير مكشوف.</p><div class="r2-row"><button id="r2-hidden-visible" class="btn" ${mineTurn?'':'disabled'}>⚽ أختار الظاهر</button><button id="r2-hidden-secret" class="btn" ${mineTurn?'':'disabled'}>🕶️ أختار الخفي</button></div></div>`;
      setTimeout(()=>{$('r2-hidden-visible')?.addEventListener('click',()=>onlineEvent('hidden:choose',{pick:'visible'}));$('r2-hidden-secret')?.addEventListener('click',()=>onlineEvent('hidden:choose',{pick:'secret'}));},0);
    }
    e.innerHTML=head+body+`<button id="r2-online-exit" class="btn btn-secondary" style="margin-top:15px">🚪 مغادرة الشاشة</button>`;
    $('r2-online-exit')?.addEventListener('click',async()=>{if(room?.code&&!room.ended){onlineGame=null;e.remove();renderRoom();toast('تم إخفاء شاشة المباراة فقط؛ تقدر ترجع لها من لوحة الغرفة.');renderChatDock();return;}try{if(room?.code)await emit('room:leave',{code:room.code,playerId:me.id});}catch(err){toast(err.message);return;}room=null;onlineGame=null;onlineLastState=null;if(chatState.mode==='room'){chatState.mode=null;chatState.messages=[];chatState.opened=false;}e.remove();const panel=$('r2-room-panel');if(panel)panel.remove();setStatus('⚪ خرجت من المباراة/الغرفة');renderChatDock();});
  }
  function renderOnlineState(state){if(onlineGame)renderOnlineGame(onlineGame,state||{})}
  function renderFinished(x){renderOnlineGame(room?.game||onlineGame,{...(x.state||{}),ended:true})}
  async function sendFriendRequest(){try{await ensurePlayer();await waitSocket();const id=String($('friend-id-input')?.value||'').replace(/\D/g,'');if(!/^\d{16}$/.test(id))return toast('اكتب ID مكونًا من 16 رقمًا');const r=await emit('friends:add',{playerId:me.id,friendId:id});if(!r?.ok)throw new Error(r?.error||'تعذر إرسال الطلب');toast('✅ تم إرسال طلب الصداقة');if($('friend-id-input'))$('friend-id-input').value='';}catch(e){toast(e.message)}}
  async function loadSocial(){try{await ensurePlayer();await waitSocket();const f=await emit('friends:list',{playerId:me.id});cachedFriends=f.friends||[];const box=$('friends-list');if(box){box.innerHTML=cachedFriends.map(x=>`<div class="r2-card" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><img src="${esc(x.avatar||'')}" onerror="this.style.display='none'" style="width:46px;height:46px;border-radius:50%;object-fit:cover"><div style="flex:1;min-width:150px">👤 <b>${esc(x.name)}</b><br>ID: ${x.id}<br>${x.online?'🟢 متصل':'⚪ غير متصل'}</div><button class="btn btn-secondary" data-chat-friend="${x.id}">💬 مراسلة</button></div>`).join('')||'لا يوجد أصدقاء حاليًا.';box.querySelectorAll('[data-chat-friend]').forEach(b=>b.addEventListener('click',()=>openFriendChat(b.dataset.chatFriend)));}const inbox=await emit('inbox:get',{playerId:me.id});const ib=$('inbox-messages');if(ib)ib.innerHTML=[...(inbox.incomingRequests||[]).map(x=>`<div class="r2-card">📩 طلب صداقة من <b>${esc(x.name)}</b><br>ID: ${x.id}<div style="margin-top:8px"><button class="btn" onclick="window.__acceptFriend('${x.id}')">قبول</button><button class="btn btn-danger" onclick="window.__rejectFriend('${x.id}')">رفض</button></div></div>`),...(inbox.matchRequests||[]).map(x=>`<div class="r2-card">⚡ طلب مباراة من <b>${esc(x.from?.name||'صديق')}</b><br>${gameLabels[x.game]||x.game}<div style="margin-top:8px"><button class="btn" onclick="window.__acceptMatch('${esc(x.id)}','${esc(x.fromId)}','${esc(x.game)}')">قبول المباراة</button><button class="btn btn-secondary" onclick="window.__declineMatch('${esc(x.id)}')">رفض</button></div></div>`)].join('')||'📭 البريد الوارد فارغ.'}catch(e){console.warn(e);}}
  async function acceptFriend(id){try{await emit('friends:accept',{playerId:me.id,friendId:id});loadSocial()}catch(e){toast(e.message)}}async function rejectFriend(id){try{await emit('friends:reject',{playerId:me.id,friendId:id});loadSocial()}catch(e){toast(e.message)}}

  function quickMatchDialog(friends){
    let m=$('r2-quick-match-modal');if(m)m.remove();m=document.createElement('div');m.id='r2-quick-match-modal';m.style.cssText='position:fixed;inset:0;z-index:100020;background:rgba(0,0,0,.78);display:flex;align-items:center;justify-content:center;padding:14px';
    const options=friends.map(x=>`<option value="${x.id}">${esc(x.name)} — ${x.id}</option>`).join('');
    m.innerHTML=`<div class="r2-card" style="width:min(460px,100%);padding:20px;background:#111827;border:1px solid rgba(255,215,0,.5);border-radius:16px"><h3 style="margin-top:0">⚡ تحدي صديق</h3><label style="display:block;margin:12px 0 5px">اختار صديقك</label><select id="r2-quick-friend" style="width:100%;padding:12px;border-radius:9px">${options}</select><label style="display:block;margin:12px 0 5px">هنلعب إيه؟</label><select id="r2-quick-game" style="width:100%;padding:12px;border-radius:9px">${['auction','five','deal','blind','guess','hidden'].map(g=>`<option value="${g}">${gameLabels[g]}</option>`).join('')}</select><button id="r2-quick-send" class="btn" style="width:100%;margin-top:16px">📨 إرسال طلب المباراة</button><button id="r2-quick-close" class="btn btn-secondary" style="width:100%;margin-top:8px">إلغاء</button><p style="font-size:12px;color:#bbb;margin-bottom:0">الطلب هيوصل لصديقك في البريد الوارد، وهتفضل منتظر لحد ما يقبله.</p></div>`;
    document.body.appendChild(m);m.querySelector('#r2-quick-close').onclick=()=>m.remove();m.addEventListener('click',e=>{if(e.target===m)m.remove()});m.querySelector('#r2-quick-send').onclick=async()=>{const friendId=m.querySelector('#r2-quick-friend').value,game=m.querySelector('#r2-quick-game').value,friend=friends.find(x=>x.id===friendId);try{m.querySelector('#r2-quick-send').disabled=true;await waitSocket();const r=await emit('quick:invite',{friendId,game});outgoingInvite={id:r.request.id,toId:friendId,friendName:friend?.name||'صديق',game,expiresAt:r.request.expiresAt};m.remove();showMatchWaiting(outgoingInvite);toast('📨 تم إرسال الدعوة — في انتظار قبول صديقك');}catch(e){m.querySelector('#r2-quick-send').disabled=false;toast(e.message)}};
  }
  async function quickMatch(){try{await ensurePlayer();await waitSocket();const f=await emit('friends:list',{playerId:me.id});cachedFriends=f.friends||[];if(!cachedFriends.length)return toast('أضف صديقًا واقبل طلب الصداقة أولًا');quickMatchDialog(cachedFriends)}catch(e){toast(e.message)}}
  async function acceptMatch(id,from,game){try{await ensurePlayer();await waitSocket();const r=await emit('quick:accept',{requestId:id,fromId:from,playerId:me.id,name:me.name,game});room=r.room;if(!chatState.mode||chatState.mode==='room')chatState.mode='room';renderRoom();if(r.started)startOnline(game||room.game,r.state||room.state);renderChatDock();loadSocial();toast('✅ تم قبول المباراة')}catch(e){toast(e.message)}}
  async function declineMatch(id){try{await waitSocket();await emit('quick:decline',{requestId:id});loadSocial();toast('تم رفض طلب المباراة')}catch(e){toast(e.message)}}

  async function createTournament(){try{await ensurePlayer();const size=Number($('r2-tournament-size')?.value||16);const gm=String($('r2-tournament-game')?.value||'auction');const map={'المزاد برو ماكس':'auction','الملعب الخماسي':'five','DEAL OR NO DEAL':'deal','المزاد الأعمى':'blind','تخمين اللاعب':'guess','اللاعب الخفي':'hidden'};const game=map[gm]||gm;const d=await api('/api/tournaments',{method:'POST',body:JSON.stringify({name:$('r2-tournament-name')?.value||'بطولة R2',size,game,playerId:me.id,isPrivate:!!$('r2-tournament-private')?.checked})});renderTournament(d.tournament,d.codes);loadTournamentList()}catch(e){toast(e.message)}}
  async function joinTournament(){try{await ensurePlayer();const d=await api('/api/tournaments/join',{method:'POST',body:JSON.stringify({code:String($('r2-tournament-code')?.value||'').trim().toUpperCase(),playerId:me.id})});renderTournament(d.tournament);loadTournamentList()}catch(e){toast(e.message)}}
  async function loadTournamentList(){try{const d=await api('/api/tournaments?playerId='+encodeURIComponent(me?.id||''));const e=$('r2-tournament-info');if(e)e.innerHTML=(d.tournaments||[]).slice(0,20).map(t=>`<div class="r2-card"><b>🏆 ${esc(t.name)}</b><br>${gameLabels[t.game]||t.game} — ${t.players}/${t.size}<br>الحالة: ${t.status}<br>أكواد متبقية: ${t.joinCodesRemaining}</div>`).join('')||'لا توجد بطولات.'}catch(_) {}}
  function renderTournament(t,codes){const e=$('r2-tournament-info');if(!e)return;const arr=Array.isArray(codes)?codes:[];e.innerHTML=`<div class="r2-card"><b>🏆 ${esc(t.name)}</b><br>اللاعبون: ${t.players}/${t.size}<br>${t.isPrivate?'🔒 بطولة خاصة — لا تظهر للناس':'🌍 بطولة عامة'}<br><b>أكواد الدعوة (${arr.length||t.joinCodesRemaining}):</b><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:6px;margin-top:8px">${arr.map((c,i)=>`<span class="r2-card" style="margin:0;text-align:center;cursor:pointer" onclick="navigator.clipboard?.writeText('${c}');this.style.outline='2px solid var(--gold-primary)'">${i+1}. <b>${c}</b></span>`).join('')||'<span>الأكواد محفوظة على السيرفر؛ أعد فتح البطولة من حساب المنشئ لعرضها.</span>'}</div></div>`}
  function ensureChatUI(){
    let root=$('r2-chat-dock');if(root)return root;
    root=document.createElement('div');root.id='r2-chat-dock';root.style.cssText='position:fixed;right:12px;bottom:12px;z-index:100015;font-family:inherit;direction:rtl;display:none';
    root.innerHTML=`<button id="r2-chat-launcher" class="btn" style="min-width:150px;box-shadow:0 6px 22px #0008">💬 الدردشة</button><section id="r2-chat-window" style="display:none;flex-direction:column;width:min(360px,calc(100vw - 24px));height:min(440px,65vh);margin-bottom:8px;background:#0b1220;border:1px solid rgba(255,215,0,.45);border-radius:14px;overflow:hidden;box-shadow:0 12px 35px #000a"><header style="display:flex;align-items:center;justify-content:space-between;gap:6px;padding:10px;background:#151f31;border-bottom:1px solid #ffffff20"><b id="r2-chat-title">💬 الدردشة</b><div style="display:flex;gap:5px"><button id="r2-chat-switch" class="btn btn-secondary" style="padding:4px 7px;display:none">المباراة</button><button id="r2-chat-min" class="btn btn-secondary" style="padding:4px 8px">—</button></div></header><div id="r2-chat-messages" style="flex:1;overflow:auto;padding:10px;display:flex;flex-direction:column;gap:8px"></div><form id="r2-chat-form" style="display:flex;gap:6px;padding:9px;border-top:1px solid #ffffff20;background:#101827"><input id="r2-chat-input" maxlength="300" autocomplete="off" placeholder="اكتب رسالتك..." style="min-width:0;flex:1;padding:10px;border-radius:9px;border:1px solid #ffffff30;background:#090f1a;color:white"><button class="btn" type="submit" style="padding:8px 12px">إرسال</button></form></section>`;
    document.body.appendChild(root);
    root.querySelector('#r2-chat-launcher').onclick=()=>{chatState.opened=!chatState.opened;if(chatState.opened)openCurrentChat().catch(e=>toast(e.message));else renderChatDock()};
    root.querySelector('#r2-chat-min').onclick=()=>{chatState.opened=false;renderChatDock()};
    root.querySelector('#r2-chat-switch').onclick=()=>{if(room?.code)openRoomChat();};
    root.querySelector('#r2-chat-form').addEventListener('submit',async e=>{e.preventDefault();const input=$('r2-chat-input'),text=String(input?.value||'').trim();if(!text)return;try{await waitSocket();if(chatState.mode==='room'){if(!room?.code)throw Error('أنت لست داخل غرفة');await emit('room:chat:send',{code:room.code,playerId:me.id,text});}else if(chatState.mode==='friend'){if(!chatState.friendId)throw Error('اختار صديقًا للمراسلة');await emit('friends:chat:send',{friendId:chatState.friendId,playerId:me.id,text});}else throw Error('افتح دردشة غرفة أو صديق أولًا');input.value='';input.focus()}catch(err){toast(err.message)}});
    return root;
  }
  function renderChatDock(){
    const root=ensureChatUI();const hasRoom=!!room?.code;const canShow=hasRoom||chatState.mode==='friend';root.style.display=canShow?'block':'none';
    const launcher=$('r2-chat-launcher'),win=$('r2-chat-window'),title=$('r2-chat-title'),sw=$('r2-chat-switch');if(!launcher||!win)return;
    const unread=Number(chatState.unreadRoom||0)+Number(chatState.unreadFriend||0);
    launcher.textContent=(chatState.opened?'إخفاء الدردشة':'💬 '+(chatState.mode==='friend'?`مراسلة ${chatState.friendName||'صديق'}`:'دردشة المباراة')+(unread?` (${unread})`:''));
    win.style.display=chatState.opened?'flex':'none';title.textContent=chatState.mode==='friend'?`💬 ${chatState.friendName||'مراسلة صديق'}`:'💬 دردشة المباراة';
    sw.style.display=(hasRoom&&chatState.mode==='friend')?'inline-block':'none';sw.textContent='دردشة المباراة';
    if(!chatState.opened)return;
    const box=$('r2-chat-messages');if(!box)return;const oldScroll=box.scrollTop,wasBottom=box.scrollHeight-box.scrollTop-box.clientHeight<40;
    box.innerHTML=(chatState.messages||[]).map(m=>{const sender=String(m.senderId||m.fromId||''),mine=sender===String(me?.id||''),name=m.senderName||(mine?me?.name:chatState.friendName)||'لاعب',time=new Date(Number(m.timestamp||Date.now())).toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'});return `<div data-message-id="${esc(m.id||'')}" style="align-self:${mine?'flex-start':'flex-end'};max-width:88%;min-width:60px;padding:8px 10px;border-radius:${mine?'12px 12px 3px 12px':'12px 12px 12px 3px'};background:${mine?'#124e43':'#243149'};border:1px solid #ffffff12;overflow-wrap:anywhere"><div style="font-size:11px;color:#e5c76d;margin-bottom:3px">${esc(name)}</div><div style="white-space:pre-wrap">${esc(m.text)}</div><div style="text-align:left;font-size:10px;color:#b8c1ce;margin-top:4px">${esc(time)}</div></div>`}).join('')||'<div style="text-align:center;color:#aab4c5;margin:auto">مفيش رسائل لسه. ابدأ الكلام 👋</div>';
    box.scrollTop=wasBottom?box.scrollHeight:oldScroll;
  }
  async function openCurrentChat(){if(chatState.mode==='friend'&&chatState.friendId)return openFriendChat(chatState.friendId);if(room?.code)return openRoomChat();toast('افتح غرفة أونلاين أو اختار صديقًا للمراسلة')}
  async function openRoomChat(){if(!room?.code)return toast('أنت مش داخل غرفة أونلاين');await ensurePlayer();await waitSocket();chatState.mode='room';chatState.friendId=null;chatState.friendName='';chatState.opened=true;chatState.unreadRoom=0;const r=await emit('room:chat:history',{code:room.code,playerId:me.id});chatState.messages=r.messages||[];renderChatDock();setTimeout(()=>$('r2-chat-input')?.focus(),30)}
  async function openFriendChat(friendId){try{await ensurePlayer();await waitSocket();const f=cachedFriends.find(x=>x.id===String(friendId))||null;if(!f)throw Error('الصديق مش موجود في قائمتك؛ حدّث قائمة الأصدقاء');chatState.mode='friend';chatState.friendId=f.id;chatState.friendName=f.name;chatState.opened=true;chatState.unreadFriend=0;const r=await emit('friends:chat:history',{friendId:f.id,playerId:me.id});chatState.messages=r.messages||[];renderChatDock();setTimeout(()=>$('r2-chat-input')?.focus(),30)}catch(e){toast(e.message)}}
  function addChatMessage(message){if(!message?.id)return;chatState.messages=chatState.messages||[];if(chatState.messages.some(x=>x.id===message.id))return;chatState.messages.push(message);chatState.messages=chatState.messages.slice(-100);renderChatDock()}
  function handleRoomChatMessage(message){if(!room?.code||message.code!==room.code)return;if(chatState.mode==='room'&&chatState.opened){addChatMessage(message);chatState.unreadRoom=0}else{chatState.unreadRoom++;renderChatDock()}}
  function handleFriendChatMessage(message){if(!me)return;const other=String(message.fromId)===String(me.id)?String(message.toId):String(message.fromId);if(chatState.mode==='friend'&&chatState.friendId===other&&chatState.opened){addChatMessage(message);chatState.unreadFriend=0}else if(String(message.fromId)!==String(me.id)){chatState.unreadFriend++;renderChatDock();toast(`💬 رسالة جديدة من ${message.senderName||'صديق'}`)}}
  function showMatchWaiting(invite){outgoingInvite=invite||outgoingInvite;if(!outgoingInvite?.id)return;if(outgoingInviteTimer)clearTimeout(outgoingInviteTimer);if(outgoingInvite.expiresAt){const id=outgoingInvite.id;outgoingInviteTimer=setTimeout(()=>{if(outgoingInvite?.id===id){hideMatchWaiting();toast('انتهت مهلة طلب المباراة؛ ابعت دعوة جديدة')}} ,Math.max(0,Number(outgoingInvite.expiresAt)-Date.now()))}let box=$('r2-match-wait-panel');if(!box){box=document.createElement('div');box.id='r2-match-wait-panel';box.style.cssText='position:fixed;inset:0;z-index:100030;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(0,0,0,.76)';document.body.appendChild(box)}box.innerHTML=`<div class="r2-card" style="width:min(420px,100%);padding:22px;text-align:center;background:#111827;border:1px solid rgba(255,215,0,.5);border-radius:16px"><div style="font-size:38px">⚽</div><h3>في انتظار قبول المباراة</h3><p>تم إرسال طلب إلى <b>${esc(outgoingInvite.friendName||'صديقك')}</b></p><p>${esc(gameLabels[outgoingInvite.game]||outgoingInvite.game)}</p><p style="color:#c2c9d3">أول ما صديقك يقبل الطلب في البريد الوارد، هتدخلوا نفس الغرفة الأونلاين تلقائيًا.</p><button id="r2-match-cancel" class="btn btn-secondary" style="width:100%">إلغاء طلب المباراة</button></div>`;box.querySelector('#r2-match-cancel').onclick=async()=>{try{await waitSocket();await emit('quick:cancel-invite',{requestId:outgoingInvite.id});hideMatchWaiting();toast('تم إلغاء طلب المباراة')}catch(e){toast(e.message)}};}
  function hideMatchWaiting(){if(outgoingInviteTimer)clearTimeout(outgoingInviteTimer);outgoingInviteTimer=null;const b=$('r2-match-wait-panel');if(b)b.remove();outgoingInvite=null}

  function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
  async function saveR2Name(){
    const input=$('r2-name-setting');
    const name=String(input?.value||'').trim();
    if(!name)return toast('اكتب اسمك أولًا');
    try{
      await ensurePlayer(); await waitSocket();
      const r=await emit('player:name-save',{name});
      me=r.player; save();
      const s=$('r2-name-status'); if(s)s.textContent='✅ تم حفظ الاسم على السيرفر: '+me.name;
      toast('✅ تم حفظ الاسم على السيرفر');
      const profileName=$('r2-v22-name'); if(profileName)profileName.textContent=me.name;
      if(window.closeModal)window.closeModal('settingsModal');
    }catch(e){toast(e.message)}
  }

  async function openR2Leaderboard(){
    const modal=$('r2-leaderboard-modal'); if(modal)modal.style.display='block';
    const box=$('r2-leaderboard-list'); if(box)box.innerHTML='جارٍ تحميل لوحة الصدارة...';
    try{
      await ensurePlayer(); await waitSocket();
      const d=await emit('leaderboard:get',{limit:50});
      if(box)box.innerHTML=(d.leaderboard||[]).map(x=>{
        const mine=x.id===me.id;
        const medal=x.position===1?'🥇':x.position===2?'🥈':x.position===3?'🥉':'#'+x.position;
        return `<div class="r2-card" style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin:7px 0;${mine?'outline:2px solid var(--gold-primary)':''}">
          <span style="min-width:45px">${medal}</span><span style="flex:1;text-align:right"><b>${esc(x.name)}</b><br><small>ID: ${x.id}</small></span><b>${Number(x.xb||0).toLocaleString()} XB</b>
        </div>`;
      }).join('')||'لا يوجد لاعبين بعد.';
    }catch(e){if(box)box.textContent=e.message}
  }
  function closeR2Leaderboard(){const m=$('r2-leaderboard-modal');if(m)m.style.display='none'}

  async function refreshR2Ranked(){
    try{
      await ensurePlayer(); await waitSocket();
      const d=await emit('ranked:get',{playerId:me.id});
      const r=d.ranked;
      const box=$('r2-ranked-info');
      if(box)box.innerHTML=`<div style="font-size:1.35rem">🏅 الرانك <b>${r.rank}</b></div>
        <div style="margin-top:7px">الانتصارات في الرانك: <b>${r.winsAtRank}/${r.winsRequired}</b></div>
        <div style="margin-top:7px">إجمالي المباريات: ${r.matches} — فوز ${r.wins} — خسارة ${r.losses} — تعادل ${r.draws}</div>`;
    }catch(e){const b=$('r2-ranked-info');if(b)b.textContent=e.message}
  }
  async function openR2Ranked(){
    const m=$('r2-ranked-modal');if(m)m.style.display='block';
    const st=$('r2-ranked-status');if(st)st.textContent='';
    const c=$('r2-ranked-cancel');if(c)c.style.display='none';
    const s=$('r2-ranked-search');if(s){s.style.display='block';s.disabled=false}
    await refreshR2Ranked();
  }
  function closeR2Ranked(){const m=$('r2-ranked-modal');if(m)m.style.display='none';cancelR2Ranked(true)}
  async function searchR2Ranked(silent=false){
    try{
      await ensurePlayer();await waitSocket();
      const game=String($('r2-ranked-game')?.value||'auction');
      const d=await emit('ranked:search',{game});
      const st=$('r2-ranked-status'),s=$('r2-ranked-search'),c=$('r2-ranked-cancel');
      if(d.matched){ room=d.room;renderRoom();if(st)st.textContent='⚡ تم إيجاد خصم — المباراة تبدأ الآن'; if(d.room.state?.started)startOnline(game,d.room.state); return; }
      if(st)st.textContent=`🔎 جاري البحث عن خصم قريب من الرانك ${d.ranked.rank}...`;
      if(s)s.style.display='none';if(c)c.style.display='block';
    }catch(e){if(!silent)toast(e.message)}
  }
  async function cancelR2Ranked(silent=false){
    try{if(socket?.connected)await emit('ranked:cancel',{});}catch(e){if(!silent)toast(e.message)}
    const s=$('r2-ranked-search'),c=$('r2-ranked-cancel'),st=$('r2-ranked-status');
    if(s)s.style.display='block';if(c)c.style.display='none';if(st)st.textContent='تم إلغاء البحث';
  }


  async function refreshR2Daily(){
    const box=$('r2-daily-list'); if(box)box.textContent='جارٍ تحميل المهام...';
    try{const d=await emit('daily:get',{});const tasks=d.daily?.tasks||[];
      if(box)box.innerHTML=tasks.map(t=>{const done=Number(t.progress)>=Number(t.target);return `<div class="r2-card" style="margin:10px 0"><b>${esc(t.name)}</b><br><span>التقدم: ${t.progress}/${t.target}</span><br><span>الجائزة: <b>30 XB</b></span><br>${t.claimed?'<span style="color:#5fda8b">✅ تم استلام الجائزة</span>':done?`<button class="btn" style="margin-top:8px" onclick="claimR2Daily('${t.id}')">🎁 المطالبة بالجائزة</button>`:'<span style="color:#aaa">⏳ أكمل المهمة لفتح الجائزة</span>'}</div>`}).join('')||'لا توجد مهام';
    }catch(e){if(box)box.textContent=e.message}
  }
  async function claimR2Daily(id){try{await emit('daily:claim',{taskId:id});toast('🎁 تمت إضافة 30 XB إلى حسابك');await ensurePlayer();refreshR2Daily()}catch(e){toast(e.message)}}
  function openR2Daily(){const m=$('r2-daily-modal');if(m)m.style.display='block';refreshR2Daily()}
  function closeR2Daily(){const m=$('r2-daily-modal');if(m)m.style.display='none'}
  // Compatibility: Ultimate Team is intentionally removed from the platform UI in V22.1.
  window.R2=window.R2||{};window.R2.completeGame=async(game='auction',result={})=>{try{await ensurePlayer();return await emit('game:single-complete',{playerId:me.id,game,claimKey:`${game}:${Date.now()}:${Math.random()}`,result})}catch(_){return null}};
  window.R2.completeFourTeams=async(result={})=>{try{await ensurePlayer();const r=await emit('game:four-teams-complete',{playerId:me.id,claimKey:`four-teams:${Date.now()}:${Math.random()}`,result});if(r?.reward)toast(`🎁 حصلت على ${r.reward.xb||0} XB`);return r}catch(_){return null}};
  window.openR2Profile=async()=>{try{await ensurePlayer();let m=$('r2-profile-v22');if(!m){m=document.createElement('div');m.id='r2-profile-v22';m.className='modal';m.style.display='block';m.innerHTML='<div class="modal-content" style="max-width:520px;text-align:center"><span class="close">&times;</span><h2>👤 البروفايل</h2><img id="r2-v22-avatar" style="width:100px;height:100px;object-fit:cover;border-radius:50%;display:none;margin:10px auto"><p>الاسم: <b id="r2-v22-name"></b></p><p style="font-size:1.4rem;letter-spacing:2px">ID: <b id="r2-v22-id"></b></p></div>';document.body.appendChild(m);m.querySelector('.close').onclick=()=>m.remove()}$('r2-v22-name').textContent=me.name;$('r2-v22-id').textContent=me.id;const av=$('r2-v22-avatar');if(av){av.src=me.avatar||'';av.style.display=me.avatar?'block':'none'}}catch(e){toast(e.message)}};
  async function saveAvatar(dataUrl){await ensurePlayer();const x=await emit('player:avatar-save',{avatar:dataUrl});me=x.player;save();toast('🖼️ تم حفظ صورة البروفايل');}
  window.createRoom=createRoom;window.generateNewRoomCode=createRoom;window.connectRoom=joinRoom;window.saveR2Name=saveR2Name;window.R2.saveAvatar=saveAvatar;window.openR2Leaderboard=openR2Leaderboard;window.closeR2Leaderboard=closeR2Leaderboard;window.openR2Ranked=openR2Ranked;window.openR2Daily=openR2Daily;window.closeR2Daily=closeR2Daily;window.claimR2Daily=claimR2Daily;window.closeR2Ranked=closeR2Ranked;window.searchR2Ranked=searchR2Ranked;window.cancelR2Ranked=cancelR2Ranked;window.sendFriendRequest=sendFriendRequest;window.quickMatch=quickMatch;window.__acceptFriend=acceptFriend;window.__rejectFriend=rejectFriend;window.__acceptMatch=acceptMatch;window.__declineMatch=declineMatch;window.R2.openRoomChat=openRoomChat;window.R2.openFriendChat=openFriendChat;window.R2.reopenOnlineGame=reopenOnlineGame;
  window.R2.fourBid=fourBid;window.R2.fourCustom=fourCustom;window.R2.fourWithdraw=fourWithdraw;window.R2.fourCard=fourCard;window.R2.fourWildcard=fourWildcard;window.R2.fourCaptain=fourCaptain;window.R2.fourCoach=fourCoach;
  window.R2.createTournament=createTournament;
  const fourBid=(inc)=>onlineEvent('four:bid',{amount:Number((room?.state?.data?.four?.currentBid||0))+Number(inc),increment:Number(inc)});
  const fourCustom=()=>{const n=Number($('r2-four-custom')?.value);if(!Number.isFinite(n)||n<=0)return toast('اكتب زيادة صحيحة');return onlineEvent('four:bid',{amount:Number(room?.state?.data?.four?.currentBid||0)+n,increment:n});};
  const fourWithdraw=()=>onlineEvent('four:withdraw',{});
  const fourCard=(kind,player,targetId,targetPlayer)=>onlineEvent('four:card',{kind,player,targetId,targetPlayer});
  const fourWildcard=(player)=>onlineEvent('four:wildcard',{player});
  const fourCaptain=(player)=>onlineEvent('four:captain',{player});
  const fourCoach=()=>onlineEvent('four:coach',{});
window.R2.joinTournament=joinTournament;
  // Opening social/tournament modals refreshes from the server, never localStorage.
  const oldOpen=window.openModal;window.openModal=function(id){if(oldOpen)oldOpen(id);if(id==='friendsModal'||id==='inboxModal')loadSocial();if(id==='tournamentModal')loadTournamentList();if(id==='settingsModal'){ensurePlayer().then(()=>{const n=$('r2-name-setting');if(n)n.value=me.name||''})}};
  // No room "continue/select game" control: room game is chosen only by the host before creation through a programmatic selection.
  window.__r2SelectOnlineGame=g=>{if(gameKeys.includes(g))window.__r2SelectedOnlineGame=g};
  window.__r2SetOnlineAuctionVariant=v=>{window.__r2OnlineAuctionVariant=String(v||'classic')};
  // AI reliability patch: all six games must have an AI opponent in AI mode.
  function aiMode(){try{return typeof selectedMode!=='undefined'&&selectedMode==='ai'}catch(_){return false}}
  function aiPatch(){
    const origGuess=window.startGuessPlayerGame; if(origGuess)window.startGuessPlayerGame=function(){origGuess();if(aiMode())setTimeout(()=>{if(typeof guessTurn!=='undefined'&&guessTurn===2){const i=$('guess-answer');if(i){i.value=guessCurrent?.[0]||'';window.submitGuess?.()}}},700)};
    const origRenderGuess=window.renderGuessTurn; if(origRenderGuess)window.renderGuessTurn=function(){origRenderGuess();if(aiMode()&&typeof guessTurn!=='undefined'&&guessTurn===2)setTimeout(()=>{const i=$('guess-answer');if(i){i.value=guessCurrent?.[0]||'';window.submitGuess?.()}},700)};
    const origHidden=window.startHiddenPlayerGame; if(origHidden)window.startHiddenPlayerGame=function(){origHidden();if(aiMode())setTimeout(()=>{if(typeof hiddenTurn!=='undefined'&&hiddenTurn===2)window.chooseHidden?.(Number(hiddenVisible?.rating||0)<Number(hiddenSecret?.rating||0))},900)};
    const origRenderHidden=window.renderHiddenTurn; if(origRenderHidden)window.renderHiddenTurn=function(){origRenderHidden();if(aiMode()&&typeof hiddenTurn!=='undefined'&&hiddenTurn===2)setTimeout(()=>window.chooseHidden?.(Number(hiddenVisible?.rating||0)<Number(hiddenSecret?.rating||0)),800)};
    const origBlind=window.startBlindAuctionGame; if(origBlind)window.startBlindAuctionGame=function(){origBlind();if(aiMode())setTimeout(()=>{if(typeof blindEnterBid==='function')blindEnterBid(2)},900)};
    const origLoadDeal=window.setupDealStage; if(origLoadDeal)window.setupDealStage=function(){origLoadDeal();if(aiMode())setTimeout(()=>{const boxes=document.querySelectorAll('#p2-deal-boxes .box');if(boxes[0]&&!document.querySelector('#p2-deal-boxes .opened'))window.openDealBox?.(2,0,boxes[0])},850)};
  }
  async function boot(){try{await ensurePlayer();connect();ensureChatUI();loadSocial();loadTournamentList()}catch(e){console.warn('[R2 V32]',e.message)}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{aiPatch();boot()});else{aiPatch();boot()}
})();
