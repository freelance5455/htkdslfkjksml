AGASZ SEMTUR — NEON HORIZON EDITION

Cara menggunakan:
1. Ekstrak file ZIP.
2. Buka folder agasz_semtur_public.
3. Buka index.html menggunakan Chrome atau browser modern.

Fitur:
- Dashboard saldo, pemasukan, dan pengeluaran.
- Grafik arus kas 6 bulan.
- Tambah, filter, dan hapus transaksi.
- Tabungan, setor/tarik, dan target tabungan.
- Tema gelap dan terang (pilihan tema tersimpan).
- Data disimpan lokal di browser perangkat.

Catatan: Data tersimpan pada browser/perangkat yang digunakan. Tidak memerlukan server.
