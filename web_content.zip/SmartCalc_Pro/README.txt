SMARTCALC PRO
============
1. ZIP extract करें.
2. index.html को Chrome या किसी browser में खोलें.
3. Calculator, Discount और GST बिना internet के काम करते हैं.
4. Currency converter में अनुमानित rates पहले से हैं; "Get latest exchange rates" के लिए internet चाहिए.
5. GST calculation में GST extra या GST included चुनें. Same-state sale में CGST+SGST और inter-state में IGST दिखेगा.

यह एक browser-based calculator है, Android APK नहीं. फोन में इसे Chrome से खोलकर Add to Home screen कर सकते हैं.
Currency conversion अनुमानित है; बैंक/वास्तविक भुगतान के लिए आधिकारिक दर जाँचें.
