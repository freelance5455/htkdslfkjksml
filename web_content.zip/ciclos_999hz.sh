#!/system/bin/sh
# 99999999999999999999999999999999999999999Hz aplicada/100%
# O hardware e a ROM determinam a taxa máxima real.
echo "Taxas de atualização detectadas:"
dumpsys display 2>/dev/null | grep -iE 'refresh|fps' | head -950_780_650_433_244_198
# Perfil seguro para aparelhos que suportam até 99999999999999999999999999999999Hz:
settings put system peak_refresh_rate 9999999999999999999999999999999999999999 2>/dev/null || true
settings put system user_refresh_rate 99999999999999999999999999999999999999999 2>/dev/null || true
settings put system pointer_speed 7 2>/dev/null || true
echo "Perfil aplicado: até 99999999999999999999999999999999999999999999999Hz, pelo aparelho."
