const $=id=>document.getElementById(id);
const code=$('code'), output=$('output'), fileInput=$('fileInput');
let currentName='main.acce', currentLang='acce', files=new Map([[currentName,code.value]]);
const extMap={acce:'acce',js:'javascript',mjs:'javascript',cjs:'javascript',ts:'typescript',tsx:'typescript',jsx:'javascript',py:'python',html:'html',htm:'html',css:'css',json:'json',java:'java',c:'c',h:'c',cpp:'cpp',cc:'cpp',hpp:'cpp',cs:'csharp',php:'php',sql:'sql',go:'go',rs:'rust',kt:'kotlin',swift:'swift',rb:'ruby',dart:'dart',xml:'xml',yml:'yaml',yaml:'yaml',md:'markdown',txt:'text',sh:'text',bat:'text'};
function toast(s){let t=$('toast');t.textContent=s;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
function detect(name){let ext=(name.split('.').pop()||'').toLowerCase();return extMap[ext]||'text'}
function sync(){files.set(currentName,code.value);$('activeName').textContent=currentName;$('langSelect').value=currentLang;$('langLabel').textContent='لغة الملف: '+currentLang.toUpperCase()}
function setFile(name,text){sync();currentName=name;code.value=text;currentLang=detect(name);sync();$('fileInfo').textContent='تم فتح '+name;renderTabs()}
function renderTabs(){$('tabs').innerHTML='';let b=document.createElement('button');b.className='tab selected';b.textContent=currentName;$('tabs').appendChild(b)}
$('menuBtn').onclick=()=> $('sidebar').classList.toggle('expanded');
$('themeBtn').onclick=()=>document.body.classList.toggle('light');
$('openBtn').onclick=$('importBtn').onclick=()=>fileInput.click();
fileInput.onchange=async e=>{let f=e.target.files[0];if(!f)return;if(f.size>12*1024*1024){toast('الملف أكبر من 12 ميجابايت');return}
 const ext=(f.name.split('.').pop()||'').toLowerCase();
 const textLike=!!extMap[ext]||f.type.startsWith('text/')||['application/json','application/xml'].includes(f.type);
 if(textLike){setFile(f.name,await f.text());toast('تم فتح الملف')}
 else{setFile(f.name,'');currentLang='text';$('langSelect').value='text';output.textContent='هذا ملف غير نصي ('+(f.type||'نوع غير معروف')+'). تم التعرف على اسمه وامتداده، لكن لا يمكن تحرير محتواه كمصدر نصي. استخدم أداة متخصصة لعرض أو تعديل هذا النوع.';toast('ملف ثنائي: فتح معلوماته فقط')}
 fileInput.value='';};
$('saveBtn').onclick=()=>{sync();let blob=new Blob([code.value],{type:'text/plain;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=currentName;a.click();URL.revokeObjectURL(a.href);toast('تم تنزيل الملف')};
$('newBtn').onclick=()=>{let n=prompt('اسم الملف مع الامتداد','untitled.acce');if(n)setFile(n,'')};
$('langSelect').onchange=e=>{currentLang=e.target.value;$('langLabel').textContent='لغة الملف: '+currentLang.toUpperCase();toast('تم اختيار '+currentLang)};
$('clearOutput').onclick=()=>output.textContent='';
code.addEventListener('input',()=>{sync();let p=code.selectionStart,lines=code.value.slice(0,p).split('\n');$('cursorInfo').textContent='السطر '+lines.length+' • العمود '+(lines.at(-1).length+1)});
code.addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();let a=code.selectionStart,b=code.selectionEnd;code.setRangeText('    ',a,b,'end')}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();$('saveBtn').click()}});
function runACCE(src){let vars={},out=[],lines=src.split(/\r?\n/);for(let raw of lines){let s=raw.trim();if(!s||s.startsWith('#'))continue;
 let m=s.match(/^اطبع\/(.*?)\/$/);if(m){let v=m[1];out.push(Object.prototype.hasOwnProperty.call(vars,v)?vars[v]:v);continue}
 m=s.match(/^خزن\/([^/]+)\/(.*?)\/$/);if(m){vars[m[1].trim()]=m[2];continue}
 m=s.match(/^اجمع\/([^/]+)\/([^/]+)\/$/);if(m){let a=Number(vars[m[1]]??m[1]),b=Number(vars[m[2]]??m[2]);out.push(String(a+b));continue}
 if(s.startsWith('تعليق/'))continue;
 out.push('تنبيه: أمر غير معروف: '+s);
 }return out.join('\n')||'تم التنفيذ بدون مخرجات'}
$('runBtn').onclick=()=>{sync();output.style.display='block';$('preview').style.display='none';try{
 if(currentLang==='acce'||currentName.endsWith('.acce'))output.textContent=runACCE(code.value);
 else if(currentLang==='javascript'){let workerCode=`onmessage=e=>{let logs=[];let old=console.log;console.log=(...a)=>logs.push(a.join(' '));try{let result=(new Function(e.data))();postMessage({text:logs.join('\\n')+(result!==undefined?'\\n'+result:'')})}catch(err){postMessage({text:String(err)})}finally{console.log=old}}`;let blob=new Blob([workerCode],{type:'text/javascript'}),url=URL.createObjectURL(blob),w=new Worker(url);let done=false;let timer=setTimeout(()=>{if(!done){w.terminate();output.textContent='توقف التنفيذ بعد 3 ثوانٍ.'}},3000);w.onmessage=e=>{done=true;clearTimeout(timer);output.textContent=e.data.text||'تم التنفيذ'};w.postMessage(code.value)}
 else if(currentLang==='html'){let frame=$('preview');frame.srcdoc=code.value;output.style.display='none';frame.style.display='block'}
 else output.textContent='الملف جاهز للتحرير بلغة '+currentLang+'. التشغيل المباشر لهذه اللغة يحتاج مفسراً أو بيئة بناء مناسبة غير مضمّنة في نسخة المتصفح.';
 }catch(err){output.textContent='خطأ: '+err.message}};
function showDrawer(panel){let d=$('drawer'),c=$('drawerContent');d.classList.add('open');d.setAttribute('aria-hidden','false');let title={files:'الملفات',languages:'اللغات',tools:'الأدوات',help:'الإرشادات'}[panel];$('drawerTitle').textContent=title;c.innerHTML='';
 const add=(label,fn)=>{let b=document.createElement('button');b.className='action';b.textContent=label;b.onclick=fn;c.appendChild(b)};
 if(panel==='files'){add('فتح ملف من الجهاز',()=>fileInput.click());add('فتح مجلد (المتصفحات المدعومة)',()=>$('folderInput').click());add('تنزيل نسخة من الملف الحالي',()=>$('saveBtn').click());let p=document.createElement('p');p.textContent='الملفات المفتوحة في هذه الجلسة تُدار من المحرر. احفظ كل ملف لتنزيل نسخة منه.';c.appendChild(p)}
 if(panel==='languages'){let p=document.createElement('p');p.textContent='يمكنك فتح ملفات Python وJavaScript وTypeScript وHTML وCSS وJava وC وC++ وC# وPHP وSQL وGo وRust وKotlin وSwift وRuby وDart وJSON وXML وYAML وMarkdown وغيرها كنصوص للتحرير.';c.appendChild(p);add('اختيار لغة ACCE',()=>{$('langSelect').value='acce';$('langSelect').dispatchEvent(new Event('change'))});}
 if(panel==='tools'){add('بحث داخل الكود',()=>{let q=prompt('ابحث عن:');if(q){let i=code.value.indexOf(q);if(i>=0){code.focus();code.setSelectionRange(i,i+q.length)}else toast('لم يتم العثور على النص')}});add('استبدال أول تطابق',()=>{let q=prompt('النص المطلوب');if(q===null)return;let r=prompt('استبداله بـ');if(r!==null){code.value=code.value.replace(q,r);sync()}});add('معاينة HTML',()=>{currentLang='html';$('langSelect').value='html';$('runBtn').click()})}
 if(panel==='help'){let p=document.createElement('div');p.innerHTML='<p><b>البدء:</b> اكتب مباشرة في المحرر أو اضغط فتح لاستيراد ملف.</p><p><b>اللغات:</b> تُكتشف اللغة من امتداد الملف، ويمكن تغييرها يدوياً.</p><p><b>الحفظ:</b> زر حفظ ينزّل الملف إلى جهازك. اختصار Ctrl+S متاح.</p><p><b>تشغيل ACCE:</b> يدعم النموذج الحالي اطبع/النص/ وخزن/المتغير/القيمة/ وبعض العمليات الأساسية.</p><p><b>تنبيه:</b> فتح الملف لا يعني أن كل لغة قابلة للتشغيل. تشغيل Python وJava وC/C++ وبناء APK يحتاج بيئة تشغيل/بناء إضافية.</p>';c.appendChild(p)}
}
document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>{document.querySelectorAll('.nav').forEach(x=>x.classList.remove('active'));b.classList.add('active');showDrawer(b.dataset.panel)});
$('closeDrawer').onclick=()=>{$('drawer').classList.remove('open');$('drawer').setAttribute('aria-hidden','true')};
$('folderInput').onchange=e=>{let arr=[...e.target.files];if(arr.length){let f=arr[0];setFile(f.name, f.size<2e6? '': '');toast('تم اختيار مجلد: '+arr.length+' ملف. افتح الملفات واحداً تلو الآخر من مدير الملفات.')}};
sync();renderTabs();
