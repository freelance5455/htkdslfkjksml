@echo off
title VidTube - allow phone access (Windows Firewall)
rem Opens the VidTube server ports (4000-4010) in the Windows Firewall so a phone on your Wi-Fi can connect.
rem To undo later:  netsh advfirewall firewall delete rule name="VidTube server"

net session >nul 2>&1
if errorlevel 1 (
  echo Windows will now ask for permission to change the firewall. Click Yes.
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

netsh advfirewall firewall delete rule name="VidTube server" >nul 2>&1
netsh advfirewall firewall add rule name="VidTube server" dir=in action=allow protocol=TCP localport=4000-4010 profile=any
echo.
if errorlevel 1 (echo  Something went wrong. Try right-click on this file, then Run as administrator.) else (echo  Done. Your phone can now reach the VidTube server on this Wi-Fi.)
echo.
pause
