@echo off
title VidTube - connect phone by USB
rem Lets a phone that is plugged in with a USB cable reach the VidTube server on this computer.
rem No Wi-Fi and no Windows Firewall settings needed. Run it once each time you plug the phone in.
set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not exist "%ADB%" set "ADB=adb"
"%ADB%" reverse tcp:4000 tcp:4000
if errorlevel 1 (
  echo.
  echo  Could not run adb. Check that the phone is plugged in, USB debugging is ON,
  echo  and you tapped "Allow" on the phone's popup. Then run this file again.
  echo.
  pause
  exit /b 1
)
echo.
echo  Done. Start the VidTube server, then open the app: it finds the server by itself.
echo.
pause
