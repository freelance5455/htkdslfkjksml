@echo off
setlocal
rem VidTube Gradle launcher: uses the exact Gradle version this project needs (downloaded once).
set VERSION=8.11.1
set "SCRIPT_DIR=%~dp0"
if not "%GRADLE_USER_HOME%"=="" (set "GH=%GRADLE_USER_HOME%") else (set "GH=%USERPROFILE%\.gradle")
set "INSTALL=%GH%\vidtube-gradle\gradle-%VERSION%"
where java >nul 2>nul
if errorlevel 1 (
  echo Java 17 or newer is required. Install a JDK, or use the one bundled with Android Studio.
  exit /b 1
)
if exist "%INSTALL%\bin\gradle.bat" goto run
if not exist "%GH%\vidtube-gradle" mkdir "%GH%\vidtube-gradle"
echo Downloading Gradle %VERSION% (one time)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%GH%\vidtube-gradle\gradle-%VERSION%-bin.zip'; Expand-Archive -Path '%GH%\vidtube-gradle\gradle-%VERSION%-bin.zip' -DestinationPath '%GH%\vidtube-gradle' -Force; Remove-Item '%GH%\vidtube-gradle\gradle-%VERSION%-bin.zip'"
if errorlevel 1 exit /b 1
:run
call "%INSTALL%\bin\gradle.bat" -p "%SCRIPT_DIR%." %*
exit /b %ERRORLEVEL%
