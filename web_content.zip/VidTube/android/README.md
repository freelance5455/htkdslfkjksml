# VidTube Android app

Open this folder in **Android Studio Meerkat (2024.3.1 Patch 1) or newer** and press **Run ▶**.
Full instructions (server, phone, troubleshooting, Google Play): see `../README.md`.

- The screens live in `app/src/main/assets/` (a copy of `../server/public/`).
- Server address: emulator default `http://10.0.2.2:4000`; real phone: set `vidtube.serverUrl` in `gradle.properties` or type it in the app (Sign in → Server address).
- Release builds only talk to **https** servers (set `vidtube.releaseServerUrl`).
- Command line (optional): `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`). It downloads Gradle 8.11.1 once. Needs JDK 17 or 21 and the Android SDK (`ANDROID_HOME`).

Note: the app targets Android 16 (API 36), which Google Play requires today. Android 17 (API 37) adds a "local network" permission
for apps that talk to servers on your Wi-Fi; apps targeting API 36 keep that access automatically. If you ever raise `targetSdk` to 37,
add the `ACCESS_LOCAL_NETWORK` permission for testing against a computer on your Wi-Fi (not needed for an https server on the internet).
