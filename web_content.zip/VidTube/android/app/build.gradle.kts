import java.util.Properties

plugins { id("com.android.application") }

// Where the app looks for the VidTube server the first time it starts (see gradle.properties).
fun quoted(value: String): String = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
val debugServerUrl: String = (findProperty("vidtube.serverUrl") as String?)?.trim().orEmpty()
val releaseServerUrl: String = (findProperty("vidtube.releaseServerUrl") as String?)?.trim().orEmpty()

// Release signing. Create keystore.properties next to settings.gradle.kts (see README.md, step "Sign").
// Without it the release build is UNSIGNED, which Android refuses to install and Google Play refuses to accept.
val keystoreProperties = Properties().apply {
    val file = rootProject.file("keystore.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}

android {
    namespace = "app.vidtube"
    compileSdk = 36
    buildFeatures { buildConfig = true }
    defaultConfig {
        // Change this to your own permanent Play Store application ID before the FIRST upload (it can never change later).
        applicationId = "app.vidtube"
        minSdk = 26
        targetSdk = 36
        versionCode = 5
        versionName = "2.0.0"
    }
    signingConfigs {
        if (keystoreProperties.containsKey("storeFile")) {
            create("release") {
                storeFile = rootProject.file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        debug {
            // Allows HTTP only in debug builds for local API testing on a LAN/emulator.
            manifestPlaceholders["usesCleartextTraffic"] = "true"
            buildConfigField("String", "DEFAULT_SERVER_URL", quoted(debugServerUrl))
        }
        release {
            // Keep minification off: @JavascriptInterface methods would need keep rules.
            isMinifyEnabled = false
            // Release builds must use HTTPS for the API server.
            manifestPlaceholders["usesCleartextTraffic"] = "false"
            buildConfigField("String", "DEFAULT_SERVER_URL", quoted(releaseServerUrl))
            signingConfig = signingConfigs.findByName("release")
        }
    }
    lint {
        // Lint downloads extra artifacts; do not let that block a release build on an offline machine.
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.activity:activity:1.10.1")
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.webkit:webkit:1.13.0")
}
