/* VidTube API integration. Keeps the bundled demo usable until an API server is configured. */
'use strict';

(() => {
  const API_URL_KEY = 'vidtube_api_url_v1';
  const TOKEN_KEY = 'vidtube_access_token_v1';
  // Where is the VidTube server?
  //  - Page opened from the server itself (browser, or installed from the browser): that same address.
  //  - Inside the Android app: the address saved in the app, otherwise the default built into the app.
  const IN_ANDROID_APP = typeof window.Android === 'object' || location.hostname === 'appassets.androidplatform.net';
  const SERVED_BY_SERVER = /^https?:$/.test(location.protocol) && !IN_ANDROID_APP;
  function builtInServerUrl() {
    try { if (window.Android && typeof Android.getServerUrl === 'function') return String(Android.getServerUrl() || ''); } catch (_) {}
    return '';
  }
  let apiBase = (SERVED_BY_SERVER ? location.origin : (localStorage.getItem(API_URL_KEY) || builtInServerUrl())).replace(/\/$/, '');
  function readToken() {
    try { if (window.Android && typeof Android.getAuthToken === 'function') return Android.getAuthToken() || ''; } catch (_) {}
    return localStorage.getItem(TOKEN_KEY) || '';
  }
  function storeToken(token) {
    accessToken = token || '';
    try { if (window.Android && typeof Android.setAuthToken === 'function' && Android.setAuthToken(accessToken)) { localStorage.removeItem(TOKEN_KEY); return; } } catch (_) {}
    if (accessToken) localStorage.setItem(TOKEN_KEY, accessToken); else localStorage.removeItem(TOKEN_KEY);
  }
  function clearToken() {
    accessToken = '';
    try { if (window.Android && typeof Android.clearAuthToken === 'function') Android.clearAuthToken(); } catch (_) {}
    localStorage.removeItem(TOKEN_KEY);
  }
  let accessToken = readToken();
  let currentUser = null;
  let currentChannel = null;
  let remoteMode = false;
  let channelIds = Object.create(null);
  let viewTimer = null;
  let loading = false;
  const LISTS_KEY = 'vidtube_lists_v1'; // history, playlists and notes are kept by server video id
  const knownCats = new Set();
  let saved = { hist: [], pls: {}, notes: {} };
  try { saved = Object.assign(saved, JSON.parse(localStorage.getItem(LISTS_KEY)) || {}); } catch (_) {}
  let storageInfo = null;
  let blocked = [];

  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[ch]);

  function absoluteApiUrl(path) {
    return `${apiBase}${path.startsWith('/') ? path : `/${path}`}`;
  }

  function unreachableMessage() {
    return SERVED_BY_SERVER
      ? 'Cannot reach the VidTube server. Is it still running?'
      : `Cannot reach the server at ${apiBase}. Check the address, make sure the server is running, and that your phone and computer are on the same Wi-Fi.`;
  }

  async function apiFetch(path, options = {}) {
    if (!apiBase) throw new Error('Set your VidTube API server URL first.');
    const headers = new Headers(options.headers || {});
    if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`);
    let body = options.body;
    if (body && !(body instanceof FormData) && !(body instanceof Blob) && typeof body !== 'string') {
      headers.set('Content-Type', 'application/json');
      body = JSON.stringify(body);
    }
    let response;
    try { response = await fetch(absoluteApiUrl(path), { ...options, headers, body }); }
    catch (_) { throw new Error(unreachableMessage()); }
    if (response.status === 204) return null;
    let payload;
    try { payload = await response.json(); } catch (_) { payload = null; }
    if (!response.ok) {
      const message = payload?.error?.message || `Request failed (${response.status}).`;
      const error = new Error(message);
      error.status = response.status;
      error.code = payload?.error?.code || 'REQUEST_FAILED';
      throw error;
    }
    return payload?.data ?? payload;
  }

  function mapVideo(video, index) {
    const channel = video.channel || {};
    const owner = video.owner || {};
    const channelName = channel.name || channel.display_name || 'VidTube creator';
    channelIds[channelName] = channel.id;
    const created = Date.parse(video.created_at || '') || Date.now();
    const ageDays = Math.max(0, (Date.now() - created) / 86_400_000);
    return {
      id: index,
      apiId: video.id,
      t: video.title || 'Untitled video',
      c: channelName,
      cat: video.category || 'Other',
      d: Number(video.duration_seconds) || 0,
      w: Number(video.view_count) || 0,
      a: ageDays,
      e: '▶',
      h: Math.abs(hashString(video.id || video.title || String(index))) % 360,
      vis: video.visibility || 'public',
      live: false,
      src: video.stream_url ? (video.stream_url.startsWith('http') ? video.stream_url : absoluteApiUrl(video.stream_url)) : '',
      ownerId: owner.id || null,
      ownerUsername: owner.username || '',
      channelId: channel.id || null,
      likeCount: Number(video.like_count) || 0,
      dislikeCount: Number(video.dislike_count) || 0,
      commentCount: Number(video.comment_count) || 0,
      img: video.thumbnail_url ? (video.thumbnail_url.startsWith('http') ? video.thumbnail_url : absoluteApiUrl(video.thumbnail_url)) : '',
      description: video.description || '',
      channelSubscriberCount: Number(channel.subscriber_count) || 0,
      userLike: Number(video.user_like) || 0
    };
  }

  function hashString(value) {
    let hash = 7;
    for (const character of String(value)) hash = (Math.imul(hash, 31) + character.charCodeAt(0)) | 0;
    return hash;
  }

  // The page addresses videos by array index, so index-keyed lists are translated through server ids
  // whenever the list is replaced; otherwise history/playlists would point at the wrong videos.
  function captureSaved() {
    const loaded = new Set(V.map((video) => video.apiId).filter(Boolean));
    const apiOf = (index) => V[index]?.apiId;
    const merge = (current, previous) => [...new Set([...(current || []).map(apiOf).filter(Boolean), ...(previous || []).filter((id) => !loaded.has(id))])];
    saved.hist = merge(S.hist, saved.hist).slice(0, 50);
    const pls = {};
    for (const name of new Set([...Object.keys(S.pls || {}), ...Object.keys(saved.pls)])) pls[name] = merge(S.pls?.[name], saved.pls[name]);
    saved.pls = pls;
    const notes = {};
    for (const [id, list] of Object.entries(saved.notes)) if (!loaded.has(id)) notes[id] = list;
    for (const [index, list] of Object.entries(S.notes || {})) { const id = apiOf(Number(index)); if (id && list.length) notes[id] = list; }
    saved.notes = notes;
    try { localStorage.setItem(LISTS_KEY, JSON.stringify(saved)); } catch (_) {}
  }

  function applySaved() {
    const index = new Map(V.map((video, i) => [video.apiId, i]));
    const toIndexes = (ids) => (ids || []).map((id) => index.get(id)).filter((i) => i !== undefined);
    S.hist = toIndexes(saved.hist);
    S.pls = { 'Watch Later': [] };
    for (const [name, ids] of Object.entries(saved.pls)) S.pls[name] = toIndexes(ids);
    S.notes = {};
    for (const [id, list] of Object.entries(saved.notes)) if (index.has(id)) S.notes[index.get(id)] = list;
  }

  function replaceVideos(videos) {
    const mapped = (videos || []).map((video, index) => mapVideo(video, index));
    mapped.forEach((video) => knownCats.add(video.cat));
    S.likes = {};
    mapped.forEach((video, index) => { if (video.userLike) S.likes[index] = video.userLike; });
    captureSaved();
    V.splice(0, V.length, ...mapped);
    S.vw = {};
    applySaved();
    return mapped;
  }

  // Lists always include the signed-in user's own videos (private/unlisted ones are only served by /me/videos).
  async function fetchVideos(path) {
    const listed = (await apiFetch(path)) || [];
    if (!currentUser) return listed;
    const owned = (await apiFetch('/api/v1/me/videos')) || [];
    const known = new Set(listed.map((video) => video.id));
    return listed.concat(owned.filter((video) => !known.has(video.id)));
  }

  async function reloadVideos() {
    replaceVideos(await fetchVideos('/api/v1/videos?limit=50&sort=newest'));
  }

  async function loadMissingLibraryVideos() {
    const loaded = new Set(V.map((video) => video.apiId));
    const wanted = [...new Set([...saved.hist, ...Object.values(saved.pls).flat()])].filter((id) => !loaded.has(id)).slice(0, 20);
    const gone = new Set();
    let added = 0;
    for (const id of wanted) {
      try {
        const mapped = mapVideo(await apiFetch(`/api/v1/videos/${encodeURIComponent(id)}`), V.length);
        knownCats.add(mapped.cat);
        V.push(mapped);
        added += 1;
      } catch (error) { if (error.status === 404) gone.add(id); }
    }
    if (gone.size) {
      saved.hist = saved.hist.filter((id) => !gone.has(id));
      for (const name of Object.keys(saved.pls)) saved.pls[name] = saved.pls[name].filter((id) => !gone.has(id));
    }
    if (added || gone.size) applySaved();
  }

  function formatBytes(bytes) {
    const value = Number(bytes) || 0;
    return value >= 1048576 ? `${(value / 1048576).toFixed(1)} MB` : value >= 1024 ? `${(value / 1024).toFixed(1)} KB` : `${value} B`;
  }

  function storageMeter() {
    if (!storageInfo) return '<span class="mu">Checking storage…</span>';
    const pct = Math.min(100, Math.round((storageInfo.used_bytes / storageInfo.limit_bytes) * 100));
    return `<strong>Storage: ${formatBytes(storageInfo.used_bytes)} of ${formatBytes(storageInfo.limit_bytes)} used</strong><div class="pb"><i style="width:${pct}%"></i></div><span class="mu">Maximum ${formatBytes(storageInfo.max_upload_bytes)} per video.</span>`;
  }

  async function loadStorage() {
    try { storageInfo = await apiFetch('/api/v1/me/storage'); } catch (_) { return; }
    const box = $('#storageBox');
    if (box) box.innerHTML = storageMeter();
  }

  window.vtAfterSave = () => { if (remoteMode) captureSaved(); };

  function applyIdentity(user, channel) {
    currentUser = user || null;
    currentChannel = channel || null;
    S.role = !currentUser ? 'v' : currentUser.role === 'admin' ? 'a' : 'c';
    S.subs = {};
    blocked = [];
    channelIds = Object.create(null);
    refreshAccountButton();
    tabs();
  }

  function refreshAccountButton() {
    const button = $('#accountButton');
    if (!button) return;
    button.textContent = currentUser ? (currentUser.display_name || currentUser.username || 'Account') : 'Sign in';
    button.title = currentUser ? `Signed in as ${currentUser.email}` : 'Configure VidTube server or sign in';
  }

  async function loadSubscriptions() {
    if (!currentUser) return;
    const subscriptions = await apiFetch('/api/v1/me/subscriptions');
    for (const channel of subscriptions || []) {
      const name = channel.display_name || channel.username || 'Channel';
      S.subs[name] = 0;
      channelIds[name] = channel.id;
    }
  }

  async function refreshRemote(showMessage = false) {
    if (!apiBase) {
      remoteMode = false;
      applyIdentity(null, null);
      tabs();
      if (showMessage) toast('Server URL saved. Connect to a running VidTube API server.');
      return;
    }
    if (loading) return;
    loading = true;
    try {
      let identity = null;
      if (accessToken) {
        try { identity = await apiFetch('/api/v1/auth/me'); }
        catch (error) {
          if (error.status === 401) {
            clearToken();
          } else throw error;
        }
      }
      applyIdentity(identity?.user || null, identity?.channel || null);
      replaceVideos(await fetchVideos('/api/v1/videos?limit=50&sort=newest'));
      remoteMode = true;
      if (currentUser) {
        try { await loadSubscriptions(); } catch (error) { console.warn('Could not load subscriptions:', error); }
        await loadBlocks();
      }
      tabs();
      if (location.hash.startsWith('#watch-') && !V[Number(location.hash.slice(7))]) location.hash = '#home';
      route();
      if (showMessage) toast(`Connected. ${V.length} videos loaded.`);
    } catch (error) {
      remoteMode = false;
      console.error('VidTube API connection failed:', error);
      toast(`Server connection failed: ${error.message}`);
    } finally {
      loading = false;
    }
  }

  async function loadFeed(options = {}) {
    if (!remoteMode) return;
    const params = new URLSearchParams({ limit: '50', sort: options.sort || 'newest' });
    if (options.query) params.set('q', options.query);
    if (options.category && options.category !== 'All' && options.category !== 'Trending') params.set('category', options.category);
    replaceVideos(await fetchVideos(`/api/v1/videos?${params.toString()}`));
  }

  function formatRelative(dateValue) {
    const time = Date.parse(dateValue || '') || Date.now();
    const days = Math.max(0, (Date.now() - time) / 86_400_000);
    if (days < 1) return 'today';
    if (days < 2) return 'yesterday';
    if (days < 7) return `${Math.floor(days)} days ago`;
    if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
    if (days < 365) return `${Math.floor(days / 30)} months ago`;
    return `${Math.floor(days / 365)} years ago`;
  }

  function accountPanel() {
    let panel = $('#acc-overlay');
    if (panel) panel.remove();
    {
      document.body.insertAdjacentHTML('beforeend', `
        <div id="acc-overlay" role="dialog" aria-modal="true" aria-label="VidTube account and server settings">
          <section id="acc-card">
            <div class="r" style="justify-content:space-between"><h2 style="margin:0">VidTube account</h2><button data-a="closeAccount" aria-label="Close">✕</button></div>
${SERVED_BY_SERVER ? `
            <p class="api-note">Connected to this VidTube server (${escapeHtml(location.host)}).</p>
            <div class="r"><button data-a="closeAccount">Close</button></div>` : `
            <p class="api-note">Enter the address of your VidTube server. Start the server on your computer (double-click <b>start-windows.bat</b>) and type the address it prints, for example <b>http://192.168.1.23:4000</b>. Android emulator: <b>http://10.0.2.2:4000</b>.</p>
            <label for="apiUrl">Server address</label>
            <input id="apiUrl" class="t" type="url" placeholder="http://192.168.1.23:4000" value="${escapeHtml(apiBase)}" autocomplete="url">
            <div class="r"><button class="on" data-a="apiSave">Save &amp; connect</button><button data-a="closeAccount">Close</button></div>`}
            <div style="height:1px;background:var(--ln);margin:16px 0"></div>
            <div class="r" style="justify-content:space-between"><strong>${currentUser ? `Signed in: ${escapeHtml(currentUser.display_name || currentUser.username)}` : 'Sign in or create an account'}</strong>${currentUser ? '<span class="r"><button data-a="logout">Sign out</button><button data-a="deleteAccount">Delete account</button></span>' : ''}</div>
            <label for="authMode">Action</label>
            <select id="authMode"><option value="login">Sign in</option><option value="register">Create account</option></select>
            <label for="authEmail">Email</label><input id="authEmail" class="t" type="email" autocomplete="email" placeholder="you@example.com">
            <label for="authUsername">Username (new accounts)</label><input id="authUsername" class="t" maxlength="24" autocomplete="username" placeholder="your_username">
            <label for="authName">Display name (new accounts)</label><input id="authName" class="t" maxlength="40" placeholder="Your channel name">
            <label for="adminSetupToken">Admin setup code (only for initial administrator)</label><input id="adminSetupToken" class="t" type="password" autocomplete="off" placeholder="Optional setup code" disabled>
            <label for="authPassword">Password (minimum 10 characters for new accounts)</label><input id="authPassword" class="t" type="password" autocomplete="current-password" placeholder="Password">
            <label class="r" style="gap:8px;align-items:flex-start;margin-top:8px"><input id="authTerms" type="checkbox" style="margin-top:3px"><span class="api-note" style="margin:0">To create an account, I agree to the <a href="${escapeHtml(legalUrl('terms'))}" target="_blank" rel="noopener">Terms of Use</a> and <a href="${escapeHtml(legalUrl('privacy'))}" target="_blank" rel="noopener">Privacy Policy</a>.</span></label>
            <button class="on" style="width:100%;margin-top:6px" data-a="authSubmit">Continue</button>
            <p class="api-note">To delete your account, type your password above and tap Delete account. Your channel, videos and comments are removed permanently. <a href="${escapeHtml(legalUrl('delete-account'))}" target="_blank" rel="noopener">More about deletion</a></p>
            ${currentUser ? '<div id="blockedBox"></div>' : ''}
            <p class="api-note">Use a strong, unique password. VidTube sends your password only to your own VidTube server.</p>
          </section>
        </div>`);
      panel = $('#acc-overlay');
      panel.addEventListener('click', (event) => { if (event.target === panel) panel.classList.remove('open'); });
    }
    if ($('#apiUrl')) $('#apiUrl').value = apiBase;
    $('#acc-overlay').classList.add('open');
    renderBlocked();
  }
  function legalUrl(page) { return apiBase ? `${apiBase}/legal/${page}` : '#'; }

  async function authenticate() {
    if (!apiBase) throw new Error('Save your server address first (Account > Server address).');
    const mode = $('#authMode').value;
    const email = $('#authEmail').value.trim();
    const password = $('#authPassword').value;
    let result;
    if (mode === 'register') {
      if (!$('#authTerms').checked) throw new Error('Please accept the Terms of Use and Privacy Policy to create an account.');
      result = await apiFetch('/api/v1/auth/register', {
        method: 'POST',
        body: {
          acceptTerms: true,
          email,
          password,
          username: $('#authUsername').value.trim(),
          displayName: $('#authName').value.trim(),
          adminSetupToken: $('#adminSetupToken').value
        }
      });
    } else {
      result = await apiFetch('/api/v1/auth/login', { method: 'POST', body: { email, password } });
    }
    storeToken(result.token);
    $('#authPassword').value = '';
    if ($('#adminSetupToken')) $('#adminSetupToken').value = '';
    $('#acc-overlay').classList.remove('open');
    await refreshRemote(true);
    toast(`Welcome to VidTube, ${result.user.display_name || result.user.username}.`);
  }

  function ensureSignedIn() {
    if (currentUser) return true;
    toast('Sign in to use this feature.');
    accountPanel();
    return false;
  }

  function updateLikeButtons(video) {
    if (!video || !$('#lb') || !$('#db')) return;
    const selected = Number(S.likes[CUR]) || 0;
    $('#lb').textContent = `👍 ${formatCount(video.likeCount ?? (typeof lk === 'function' ? lk(video) : 0))}`;
    $('#db').textContent = `👎 ${formatCount(video.dislikeCount ?? 0)}`;
    $('#lb').classList.toggle('on', selected === 1);
    $('#db').classList.toggle('on', selected === -1);
  }

  function formatCount(number) {
    const value = Number(number) || 0;
    return value >= 1_000_000 ? `${(value / 1_000_000).toFixed(1)}M` : value >= 1_000 ? `${(value / 1_000).toFixed(1)}K` : String(value);
  }

  function relativeDate(dateValue) {
    if (!dateValue) return 'just now';
    return formatRelative(dateValue);
  }

  function showComments(rows) {
    CM = {};
    const items = (rows || []).map((row) => ({
      i: row.id,
      parentId: row.parent_id,
      u: row.user?.display_name || row.user?.username || 'User',
      uid: row.user?.id || null,
      t: row.body,
      l: 0,
      r: [],
      n: relativeDate(row.created_at)
    }));
    const lookup = new Map(items.map((item) => [item.i, item]));
    const roots = [];
    for (const item of items) {
      if (item.parentId && lookup.has(item.parentId)) lookup.get(item.parentId).r.push(item);
      else roots.push(item);
    }
    let sorted = roots.slice();
    if (CS === 'new') sorted.reverse();
    for (const comment of sorted) CM[comment.i] = { u: comment.u, t: comment.t };
    const count = items.length;
    if ($('#cn')) $('#cn').textContent = `${count} Comments`;
    if ($('#cl')) $('#cl').innerHTML = sorted.map((comment) => renderRemoteComment(comment)).join('');
  }

  function ownDelete(item, own = false) {
    if (!currentUser || item.uid !== currentUser.id) return '';
    const link = `<a data-a="cdel" data-i="${escapeHtml(item.i)}">Delete</a>`;
    return own ? `<div class="mu">${link}</div>` : ` · ${link}`;
  }

  function blockLink(item) {
    return currentUser && item.uid && item.uid !== currentUser.id
      ? ` · <a data-a="block" data-uid="${escapeHtml(item.uid)}" data-n="${escapeHtml(item.u)}">🚫 Block</a>` : '';
  }

  function replyActions(reply) {
    if (currentUser && reply.uid === currentUser.id) return ownDelete(reply, true);
    return `<div class="mu"><a data-a="flag" data-i="${escapeHtml(reply.i)}">⚑ Report</a>${blockLink(reply)}</div>`;
  }

  function renderRemoteComment(comment) {
    const replies = (comment.r || []).map((reply) => {
      CM[reply.i] = { u: reply.u, t: reply.t };
      return `<div class="cm" style="margin-left:28px">${av(reply.u)}<div style="flex:1"><strong>${escapeHtml(reply.u)}</strong> <span class="mu">${escapeHtml(reply.n)}</span><div>${escapeHtml(reply.t)}</div>${replyActions(reply)}</div></div>`;
    }).join('');
    return `<div class="cm">${av(comment.u)}<div style="flex:1"><strong>${escapeHtml(comment.u)}</strong> <span class="mu">${escapeHtml(comment.n)}</span><div>${escapeHtml(comment.t)}</div><div class="mu"><a data-a="rep" data-i="${escapeHtml(comment.i)}" data-u="${escapeHtml(comment.u)}">Reply</a> · <a data-a="flag" data-i="${escapeHtml(comment.i)}">⚑ Report</a>${blockLink(comment)}${ownDelete(comment)}</div><div id="rs-${escapeHtml(comment.i)}"></div>${replies}</div></div>`;
  }

  async function loadComments(videoIndex) {
    const video = V[videoIndex];
    if (!video?.apiId || !remoteMode) return;
    try {
      const rows = await apiFetch(`/api/v1/videos/${encodeURIComponent(video.apiId)}/comments`);
      if (view === 'watch' && V[CUR]?.apiId === video.apiId) showComments(rows);
    } catch (error) {
      if ($('#cl')) $('#cl').innerHTML = `<p class="mu">Comments could not be loaded: ${escapeHtml(error.message)}</p>`;
    }
  }

  function renderStudio() {
    const mine = V.filter((video) => video.ownerId === currentUser?.id && !video.del);
    const videos = mine.map((video) => `
      <div class="k r" style="margin-bottom:8px;flex-wrap:wrap">
        <div style="flex:1;min-width:130px"><b>${escapeHtml(video.t)}</b><div class="mu">${escapeHtml(video.vis)} · ${formatCount(video.w)} views</div></div>
        <select data-a="visibility" data-id="${video.id}">${['public', 'unlisted', 'private'].map((value) => `<option value="${value}"${value === video.vis ? ' selected' : ''}>${value}</option>`).join('')}</select>
        <button data-a="go" data-id="${video.id}" aria-label="Watch">▶</button>
        <button data-a="del" data-id="${video.id}" aria-label="Delete">🗑</button>
      </div>`).join('');
    return `
      <h2>Creator Studio</h2>
      <div class="kp">
        <div class="k">Your videos<b>${mine.length}</b></div>
        <div class="k">Total views<b>${formatCount(mine.reduce((sum, video) => sum + video.w, 0))}</b></div>
        <div class="k">Channel subscribers<b>${formatCount(mine[0]?.channelSubscriberCount || 0)}</b></div>
      </div>
      <h2>Upload a video</h2>
      <div class="k" id="storageBox" style="margin-bottom:8px">${storageMeter()}</div>
      <div class="k">
        <label for="fl">Video file</label><input type="file" id="fl" accept="video/mp4,video/webm,video/quicktime,video/x-matroska,video/3gpp,video/*">
        <div class="r" style="margin-top:8px;flex-wrap:wrap"><input id="ut" class="t" maxlength="120" placeholder="Video title" style="flex:1;min-width:160px"><select id="uv"><option value="public">Public</option><option value="unlisted">Unlisted</option><option value="private">Private</option></select></div>
        <input id="ud" class="t" maxlength="5000" placeholder="Description (optional)" style="width:100%;margin-top:8px">
        <div class="r" style="margin-top:8px"><select id="uc"><option>Coding</option><option>Education</option><option>Entertainment</option><option>Gaming</option><option>Music</option><option>News</option><option>Science</option><option>Sports</option><option>Technology</option><option>Travel</option><option>Vlogs</option><option>Other</option></select><button class="on" data-a="up">Upload &amp; publish</button></div>
        <p id="us" class="mu" aria-live="polite">Your original video file will be uploaded to your VidTube server. Maximum size depends on the server configuration.</p>
      </div>
      <h2>Your content</h2>${videos || '<p class="mu">You have not uploaded any videos yet.</p>'}`;
  }

  function reportRow(report) {
    const id = escapeHtml(report.id);
    const subject = report.type === 'video' ? `Video “${escapeHtml(report.title)}” by <b>${escapeHtml(report.author_username)}</b>`
      : report.type === 'channel' ? `Channel “${escapeHtml(report.title)}” (<b>${escapeHtml(report.author_username)}</b>)`
      : `<b>${escapeHtml(report.author_username)}</b>: ${escapeHtml(report.body)}`;
    const actions = [
      `<button data-a="reportStatus" data-id="${id}" data-status="reviewed">Mark reviewed</button>`,
      `<button data-a="reportStatus" data-id="${id}" data-status="dismissed">Dismiss</button>`
    ];
    if (report.type === 'video' && report.video_id) actions.push(`<button data-a="adminRemoveVideo" data-id="${escapeHtml(report.video_id)}">Remove video</button>`);
    if (report.target_user_id) actions.push(`<button data-a="adminRemoveUser" data-id="${escapeHtml(report.target_user_id)}" data-n="${escapeHtml(report.author_username)}">Remove account</button>`);
    return `
        <div class="k" style="margin-bottom:8px">${subject}
          <div class="mu">${escapeHtml(report.type)} report by ${escapeHtml(report.reporter_username)} · ${escapeHtml(report.reason || 'No reason provided')}</div>
          <div class="r" style="margin-top:8px;flex-wrap:wrap">${actions.join('')}</div>
        </div>`;
  }

  async function loadAdminReports() {
    const target = $('#reportList');
    if (!target) return;
    try {
      const reports = await apiFetch('/api/v1/admin/reports');
      target.innerHTML = reports.length ? reports.map(reportRow).join('') : '<p class="mu">No open reports.</p>';
    } catch (error) {
      target.textContent = error.message;
    }
  }

  // Replace demo role switching with server-authorised account roles.
  tabs = function tabsWithAccount() {
    const entries = [['home', '🏠 Home'], ['subs', '📺 Subscriptions'], ['library', '📚 Library']];
    if (!remoteMode) entries.splice(1, 0, ['shorts', '⚡ Shorts']);
    if (currentUser) entries.push(['studio', '🎬 Studio']);
    if (currentUser?.role === 'admin') entries.push(['admin', '🛡 Admin']);
    $('#tabs').innerHTML = entries.map(([name, label]) => `<button data-a="nav" data-v="${name}">${label}</button>`).join('');
    refreshAccountButton();
  };

  R.studio = () => {
    if (!currentUser) return '<p class="mu">Sign in to open Creator Studio.</p>';
    setTimeout(loadStorage, 0);
    return renderStudio();
  };
  const originalHome = R.home;
  R.home = function homeWithKnownCategories() {
    const html = originalHome();
    if (!remoteMode || knownCats.size === 0) return html;
    const chips = ['All', 'Trending', ...knownCats].map((name) => `<button data-a=cat data-v="${escapeHtml(name)}"${name === cat ? ' class=on' : ''}>${escapeHtml(name)}</button>`).join('');
    return html.replace(/^<div class=ch>[\s\S]*?<\/div>/, `<div class=ch>${chips}</div>`);
  };
  R.admin = () => '<h2>Moderation dashboard</h2><p class="mu">Reports are stored by the backend and can only be reviewed by an administrator.</p><div id="reportList"><p class="mu">Loading reports…</p></div>';
  initAd = function initAdminDashboard() { loadAdminReports(); };

  A.account = accountPanel;
  A.closeAccount = () => $('#acc-overlay')?.classList.remove('open');
  A.apiSave = async () => {
    const value = $('#apiUrl').value.trim().replace(/\/$/, '');
    if (!value) { toast('Enter the server address.'); return; }
    let parsed;
    try { parsed = new URL(value); } catch (_) { toast('Enter a valid URL including https:// or http://.'); return; }
    const localHttp = parsed.protocol === 'http:' && (/^(localhost$|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(parsed.hostname) || /\.local$/.test(parsed.hostname));
    if (parsed.protocol !== 'https:' && !localHttp) { toast('Use https:// for a public server. Plain http:// only works for a computer on your own Wi-Fi (like http://192.168.1.23:4000).'); return; }
    if (!['http:', 'https:'].includes(parsed.protocol)) { toast('Unsupported server URL protocol.'); return; }
    if (value !== apiBase) { clearToken(); applyIdentity(null, null); storageInfo = null; }
    apiBase = value;
    localStorage.setItem(API_URL_KEY, apiBase);
    await refreshRemote(true);
  };
  A.authSubmit = async () => {
    try { await authenticate(); }
    catch (error) { toast(error.message); }
  };
  A.logout = async () => {
    clearToken();
    applyIdentity(null, null);
    await refreshRemote(true);
    $('#acc-overlay')?.classList.remove('open');
  };
  A.nav = async (event) => {
    const destination = event.dataset.v;
    if (destination === 'studio' && !ensureSignedIn()) return;
    if (destination === 'admin' && currentUser?.role !== 'admin') { toast('Administrator permission is required.'); return; }
    if (remoteMode && destination === 'home') {
      cat = 'All'; Q = ''; $('#q').value = '';
      try { await loadFeed({ sort: 'newest' }); } catch (error) { toast(error.message); }
    }
    if (remoteMode && destination === 'subs' && currentUser) {
      try {
        replaceVideos(await fetchVideos('/api/v1/me/feed'));
      } catch (error) { toast(error.message); }
    }
    if (remoteMode && destination === 'library') await loadMissingLibraryVideos().catch(() => {});
    go(destination);
  };
  const originalClearHistory = A.hc;
  A.hc = (element) => { saved.hist = []; originalClearHistory(element); };

  A.search = async () => {
    Q = $('#q').value.trim();
    if (Q) { S.sh = [Q, ...S.sh.filter((item) => item !== Q)].slice(0, 8); save(); dl(); }
    if (remoteMode) {
      try { await loadFeed({ query: Q }); } catch (error) { toast(error.message); }
    }
    go('search');
  };
  A.cat = async (event) => {
    cat = event.dataset.v;
    if (remoteMode) {
      try { await loadFeed({ category: cat, sort: cat === 'Trending' ? 'trending' : 'newest' }); }
      catch (error) { toast(error.message); }
    }
    route();
  };
  A.sub = async (event) => {
    if (!remoteMode) {
      const name = event.dataset.c;
      S.subs[name] == null ? S.subs[name] = 0 : delete S.subs[name];
      save(); upsub(name); return;
    }
    if (!ensureSignedIn()) return;
    const channelName = event.dataset.c;
    const watching = V[CUR];
    const channelId = (watching && watching.c === channelName && watching.channelId) || channelIds[channelName] || V.find((video) => video.c === channelName)?.channelId;
    if (!channelId) { toast('Channel information is not available.'); return; }
    try {
      if (S.subs[channelName] == null) {
        await apiFetch(`/api/v1/channels/${encodeURIComponent(channelId)}/subscribe`, { method: 'POST' });
        S.subs[channelName] = 0;
      } else {
        await apiFetch(`/api/v1/channels/${encodeURIComponent(channelId)}/subscribe`, { method: 'DELETE' });
        delete S.subs[channelName];
      }
      const channelInfo = await apiFetch(`/api/v1/channels/${encodeURIComponent(channelId)}`);
      V.filter((item) => item.channelId === channelId).forEach((item) => { item.channelSubscriberCount = Number(channelInfo.subscriber_count) || 0; });
      save(); upsub(channelName);
    } catch (error) { toast(error.message); }
  };

  A.like = async () => {
    const video = V[CUR];
    if (!video?.apiId || !remoteMode) { S.likes[CUR] = S.likes[CUR] === 1 ? 0 : 1; save(); updateLikeButtons(P.v); return; }
    if (!ensureSignedIn()) return;
    const value = S.likes[CUR] === 1 ? 0 : 1;
    try {
      const result = await apiFetch(`/api/v1/videos/${encodeURIComponent(video.apiId)}/like`, { method: 'POST', body: { value } });
      S.likes[CUR] = result.value;
      video.likeCount = result.like_count;
      video.dislikeCount = result.dislike_count;
      save(); updateLikeButtons(video);
    } catch (error) { toast(error.message); }
  };
  A.dis = async () => {
    const video = V[CUR];
    if (!video?.apiId || !remoteMode) { S.likes[CUR] = S.likes[CUR] === -1 ? 0 : -1; save(); updateLikeButtons(P.v); return; }
    if (!ensureSignedIn()) return;
    const value = S.likes[CUR] === -1 ? 0 : -1;
    try {
      const result = await apiFetch(`/api/v1/videos/${encodeURIComponent(video.apiId)}/like`, { method: 'POST', body: { value } });
      S.likes[CUR] = result.value;
      video.likeCount = result.like_count;
      video.dislikeCount = result.dislike_count;
      save(); updateLikeButtons(video);
    } catch (error) { toast(error.message); }
  };
  upL = function updateRemoteLikeUi() { updateLikeButtons(P.v); };
  const originalUpsub = upsub;
  upsub = function updateSubscriptionUi(channelName) {
    if (!remoteMode) return originalUpsub(channelName);
    $$('.sbs').forEach((button) => { if (button.dataset.c === channelName) button.textContent = S.subs[channelName] == null ? 'Subscribe' : 'Subscribed ✓'; });
    if (view === 'watch') {
      const video = V[CUR];
      if (video?.c === channelName) {
        $('#sb').innerHTML = subBtn(channelName);
        $('#sn').textContent = `${formatCount(video.channelSubscriberCount || 0)} subscribers`;
      }
    } else if (view !== 'shorts') route();
  };

  cmts = async function loadRemoteComments(id) {
    if (remoteMode && V[id]?.apiId) { await loadComments(id); return; }
    CM = {};
    let comments = seedC(id).concat(S.cm[id] || []).filter((comment) => !S.rm[comment.i]);
    comments = CS === 'new' ? comments.slice().reverse() : comments.sort((a, b) => (b.p || 0) - (a.p || 0) || cl(b) - cl(a));
    if ($('#cn')) $('#cn').textContent = `${comments.length} Comments`;
    if ($('#cl')) $('#cl').innerHTML = comments.map((comment) => cm(comment)).join('');
  };

  A.cmt = async () => {
    const input = $('#ci');
    const body = input?.value.trim();
    if (!body) return;
    const video = V[CUR];
    if (remoteMode && video?.apiId) {
      if (!ensureSignedIn()) return;
      try {
        await apiFetch(`/api/v1/videos/${encodeURIComponent(video.apiId)}/comments`, { method: 'POST', body: { body } });
        input.value = '';
        await loadComments(CUR);
      } catch (error) { toast(error.message); }
      return;
    }
    (S.cm[CUR] = S.cm[CUR] || []).push({ i: `u${Date.now()}`, u: 'You', t: body, l: 0, r: [], n: 'just now' });
    input.value = ''; save(); cmts(CUR);
  };
  A.rsend = async (event) => {
    const input = $(`#ri-${event.dataset.i}`);
    const body = input?.value.trim();
    if (!body) return;
    const video = V[CUR];
    if (remoteMode && video?.apiId) {
      if (!ensureSignedIn()) return;
      try {
        await apiFetch(`/api/v1/videos/${encodeURIComponent(video.apiId)}/comments`, { method: 'POST', body: { body, parentId: event.dataset.i } });
        await loadComments(CUR);
      } catch (error) { toast(error.message); }
      return;
    }
    (S.rp[event.dataset.i] = S.rp[event.dataset.i] || []).push({ i: `r${Date.now()}`, u: 'You', t: body, l: 0, n: 'just now' });
    save(); cmts(CUR);
  };
  A.flag = async (event) => {
    const video = V[CUR];
    if (remoteMode && video?.apiId) {
      if (!ensureSignedIn()) return;
      try {
        await apiFetch(`/api/v1/comments/${encodeURIComponent(event.dataset.i)}/report`, { method: 'POST', body: { reason: 'Reported from VidTube app' } });
        toast('Report submitted. Thank you.');
      } catch (error) { toast(error.message); }
      return;
    }
    toast('Sign in and connect to the server to report this comment.');
  };

  // Reads the video in a hidden <video> element: its length and one frame to use as the thumbnail.
  function probeVideo(file) {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(file);
      const el = document.createElement('video');
      el.muted = true; el.playsInline = true; el.preload = 'auto';
      let finished = false;
      let duration = 0;
      const finish = (thumb) => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        el.removeAttribute('src');
        try { el.load(); } catch (_) {}
        URL.revokeObjectURL(url);
        resolve({ duration: Number.isFinite(duration) ? duration : 0, thumb: thumb || null });
      };
      const timer = setTimeout(() => { if (!duration && Number.isFinite(el.duration)) duration = el.duration; finish(null); }, 8000);
      el.onloadedmetadata = () => {
        duration = el.duration;
        try { el.currentTime = Math.min(1, (Number.isFinite(duration) && duration > 0 ? duration : 2) / 3); } catch (_) { finish(null); }
      };
      el.onseeked = () => {
        try {
          const w = el.videoWidth, h = el.videoHeight;
          if (!w || !h) { finish(null); return; }
          const scale = Math.min(1, 640 / w);
          const canvas = document.createElement('canvas');
          canvas.width = Math.round(w * scale); canvas.height = Math.round(h * scale);
          canvas.getContext('2d').drawImage(el, 0, 0, canvas.width, canvas.height);
          canvas.toBlob((blob) => finish(blob), 'image/jpeg', 0.8);
        } catch (_) { finish(null); }
      };
      el.onerror = () => finish(null);
      el.src = url;
    });
  }

  // Sends the video file as the request body (so the browser can report progress).
  function uploadWithProgress(path, file, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', absoluteApiUrl(path));
      if (accessToken) xhr.setRequestHeader('Authorization', `Bearer ${accessToken}`);
      xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
      xhr.upload.onprogress = (event) => { if (event.lengthComputable) onProgress(event.loaded / event.total); };
      xhr.onerror = () => reject(new Error(unreachableMessage()));
      xhr.onabort = () => reject(new Error('Upload cancelled.'));
      xhr.onload = () => {
        let payload = null;
        try { payload = JSON.parse(xhr.responseText); } catch (_) {}
        if (xhr.status >= 200 && xhr.status < 300) { resolve(payload?.data ?? payload); return; }
        const error = new Error(payload?.error?.message || `Upload failed (${xhr.status}).`);
        error.status = xhr.status;
        reject(error);
      };
      xhr.send(file);
    });
  }

  let uploading = false;
  A.up = async () => {
    if (!ensureSignedIn()) return;
    if (uploading) { toast('An upload is already running.'); return; }
    const file = $('#fl')?.files?.[0];
    const status = $('#us');
    if (!file) { toast('Choose a video file first.'); return; }
    if (!storageInfo) await loadStorage();
    if (storageInfo && file.size > storageInfo.max_upload_bytes) {
      toast(`That video is ${formatBytes(file.size)}. The limit is ${formatBytes(storageInfo.max_upload_bytes)} per video.`);
      return;
    }
    if (storageInfo && file.size > storageInfo.remaining_bytes) {
      toast(`Not enough storage: ${formatBytes(storageInfo.remaining_bytes)} left of ${formatBytes(storageInfo.limit_bytes)}. Delete a video first.`);
      return;
    }
    uploading = true;
    try {
      if (status) status.textContent = 'Reading your video…';
      const info = await probeVideo(file);
      const query = new URLSearchParams({
        title: $('#ut').value.trim() || file.name.replace(/\.[^.]+$/, ''),
        description: $('#ud').value.trim(),
        category: $('#uc').value,
        visibility: $('#uv').value,
        duration: String(info.duration),
        filename: file.name
      });
      if (status) status.textContent = 'Uploading… 0%';
      const created = await uploadWithProgress(`/api/v1/videos/upload?${query}`, file, (fraction) => {
        if (status) status.textContent = `Uploading… ${Math.round(fraction * 100)}%`;
      });
      if (info.thumb && created?.id) {
        try { await apiFetch(`/api/v1/videos/${encodeURIComponent(created.id)}/thumbnail`, { method: 'PUT', body: info.thumb, headers: { 'Content-Type': 'image/jpeg' } }); }
        catch (error) { console.warn('Thumbnail was not saved:', error); }
      }
      try { await reloadVideos(); } catch (error) { console.warn('Could not refresh videos after upload:', error); }
      await loadStorage().catch(() => {});
      route(); // redraws the Studio page, so the message is written afterwards
      const done = $('#us');
      if (done) done.textContent = 'Upload complete. Your video is available on VidTube.';
      toast('Video uploaded successfully.');
    } catch (error) {
      if (error.status === 401) { clearToken(); applyIdentity(null, null); }
      if (status) status.textContent = `Upload failed: ${error.message}`;
      toast(error.message);
    } finally {
      uploading = false;
    }
  };
  A.del = async (event) => {
    const video = V[Number(event.dataset.id)];
    if (!video) return;
    if (!remoteMode || !video.apiId) { video.del = true; route(); return; }
    if (!confirm('Permanently delete this video from the server?')) return;
    try {
      await apiFetch(`/api/v1/videos/${encodeURIComponent(video.apiId)}`, { method: 'DELETE' });
      video.del = true;
      try { await reloadVideos(); } catch (_) { /* the list refreshes on the next load */ }
      toast('Video deleted.'); route();
    } catch (error) { toast(error.message); }
  };
  A.visibility = async (event) => {
    const video = V[Number(event.dataset.id)];
    if (!video?.apiId) return;
    try {
      const updated = await apiFetch(`/api/v1/videos/${encodeURIComponent(video.apiId)}`, { method: 'PATCH', body: { visibility: event.value } });
      video.vis = event.value;
      if (updated?.stream_url) video.src = updated.stream_url.startsWith('http') ? updated.stream_url : absoluteApiUrl(updated.stream_url);
      toast('Video visibility updated.');
    } catch (error) { toast(error.message); route(); }
  };
  A.cdel = async (event) => {
    if (!confirm('Delete this comment?')) return;
    try {
      await apiFetch(`/api/v1/comments/${encodeURIComponent(event.dataset.i)}`, { method: 'DELETE' });
      await loadComments(CUR);
    } catch (error) { toast(error.message); }
  };
  A.deleteAccount = async () => {
    const password = $('#authPassword')?.value || '';
    if (!password) { toast('Type your password in the Password field first, then tap Delete account.'); return; }
    if (!confirm('Permanently delete your account, channel, videos and comments? This cannot be undone.')) return;
    try {
      await apiFetch('/api/v1/auth/account', { method: 'DELETE', body: { password } });
      clearToken();
      applyIdentity(null, null);
      $('#acc-overlay')?.classList.remove('open');
      await refreshRemote(false);
      toast('Your account was deleted.');
    } catch (error) { toast(error.message); }
  };
  async function loadBlocks() {
    if (!currentUser) { blocked = []; return; }
    try { blocked = (await apiFetch('/api/v1/me/blocks')) || []; } catch (error) { console.warn('Could not load blocked users:', error); }
  }

  function renderBlocked() {
    const box = $('#blockedBox');
    if (!box) return;
    box.innerHTML = blocked.length
      ? `<strong>Blocked users</strong>${blocked.map((user) => `<div class="r" style="justify-content:space-between;margin-top:6px"><span>${escapeHtml(user.display_name || user.username)}</span><button data-a="unblock" data-id="${escapeHtml(user.id)}" data-n="${escapeHtml(user.display_name || user.username)}">Unblock</button></div>`).join('')}`
      : '<p class="api-note">You have not blocked anyone.</p>';
  }

  async function blockUser(userId, name) {
    if (!remoteMode || !userId) { toast('Connect to the server and sign in to block users.'); return; }
    if (!ensureSignedIn()) return;
    if (userId === currentUser.id) { toast('You cannot block yourself.'); return; }
    if (!confirm(`Block ${name}? Their videos and comments will be hidden from you. You can undo this in your account panel.`)) return;
    try { await apiFetch(`/api/v1/users/${encodeURIComponent(userId)}/block`, { method: 'POST' }); } catch (error) { toast(error.message); return; }
    await loadBlocks();
    const watchingTheirVideo = view === 'watch' && V[CUR]?.ownerId === userId;
    V.forEach((video) => { if (video.ownerId === userId) video.del = true; });
    toast(`${name} is blocked.`);
    if (watchingTheirVideo) go('home');
    else if (view === 'watch') await loadComments(CUR);
    else route();
  }

  async function sendReport(path, what) {
    if (!ensureSignedIn()) return;
    if (!confirm(`Report this ${what} as inappropriate? Moderators will review it.`)) return;
    try {
      await apiFetch(path, { method: 'POST', body: { reason: 'Reported from VidTube app' } });
      toast('Report submitted. Thank you.');
    } catch (error) { toast(error.message); }
  }

  const isOwn = (ownerId) => Boolean(currentUser && ownerId && ownerId === currentUser.id);

  A.safety = () => {
    const video = V[CUR];
    if (!remoteMode || !video?.apiId) { toast('Connect to the server and sign in to report or block.'); return; }
    const box = $('#sv');
    box.hidden = false;
    box.innerHTML = '<button data-a="rv">Report video</button><button data-a="rc">Report channel</button><button data-a="bu">Block creator</button><button data-a="safetyClose">Cancel</button>';
  };
  A.safetyClose = () => { $('#sv').hidden = true; };
  A.rv = async () => {
    const video = V[CUR];
    $('#sv').hidden = true;
    if (!video?.apiId) return;
    if (isOwn(video.ownerId)) { toast('You cannot report your own video.'); return; }
    await sendReport(`/api/v1/videos/${encodeURIComponent(video.apiId)}/report`, 'video');
  };
  A.rc = async () => {
    const video = V[CUR];
    $('#sv').hidden = true;
    if (!video?.channelId) return;
    if (isOwn(video.ownerId)) { toast('You cannot report your own channel.'); return; }
    await sendReport(`/api/v1/channels/${encodeURIComponent(video.channelId)}/report`, 'channel');
  };
  A.bu = async () => {
    const video = V[CUR];
    $('#sv').hidden = true;
    await blockUser(video?.ownerId, video?.c || 'this creator');
  };
  A.block = (event) => blockUser(event.dataset.uid, event.dataset.n || 'this user');
  A.unblock = async (event) => {
    try { await apiFetch(`/api/v1/users/${encodeURIComponent(event.dataset.id)}/block`, { method: 'DELETE' }); } catch (error) { toast(error.message); return; }
    await loadBlocks();
    renderBlocked();
    toast(`${event.dataset.n || 'User'} is unblocked.`);
    if (view !== 'watch') {
      try { await reloadVideos(); } catch (_) { /* refreshes on the next load */ }
      route();
    }
  };
  A.adminRemoveVideo = async (event) => {
    if (!confirm('Permanently remove this video?')) return;
    try {
      await apiFetch(`/api/v1/videos/${encodeURIComponent(event.dataset.id)}`, { method: 'DELETE' });
      toast('Video removed.');
      await loadAdminReports();
    } catch (error) { toast(error.message); }
  };
  A.adminRemoveUser = async (event) => {
    if (!confirm(`Permanently remove ${event.dataset.n || 'this user'} and all their videos, comments and files?`)) return;
    try {
      await apiFetch(`/api/v1/admin/users/${encodeURIComponent(event.dataset.id)}`, { method: 'DELETE' });
      toast('Account removed.');
      await loadAdminReports();
    } catch (error) { toast(error.message); }
  };
  A.reportStatus = async (event) => {
    try {
      await apiFetch(`/api/v1/admin/reports/${encodeURIComponent(event.dataset.id)}`, { method: 'PATCH', body: { status: event.dataset.status } });
      await loadAdminReports();
    } catch (error) { toast(error.message); }
  };

  const originalInitW = initW;
  initW = function initWatchWithApi(video) {
    originalInitW(video);
    if (remoteMode && video.apiId && $('#sn')) $('#sn').textContent = `${formatCount(video.channelSubscriberCount || 0)} subscribers`;
    if (viewTimer) clearInterval(viewTimer);
    if (remoteMode && video.apiId) {
      let recorded = false;
      viewTimer = setInterval(async () => {
        if (recorded || P.v !== video || !P.p || P.t < 5) return;
        recorded = true;
        clearInterval(viewTimer);
        try {
          const result = await apiFetch(`/api/v1/videos/${encodeURIComponent(video.apiId)}/view`, { method: 'POST' });
          video.w = Number(result.view_count) || video.w;
        } catch (error) { console.debug('View count was not updated:', error.message); }
      }, 2000);
    }
  };
  const originalStop = stop;
  stop = function stopWatchWithApi() {
    if (viewTimer) clearInterval(viewTimer);
    viewTimer = null;
    originalStop();
  };

  document.addEventListener('change', (event) => {
    if (event.target.matches('[data-a="visibility"]')) A.visibility(event.target);
    if (event.target.matches('#authMode')) {
      const isRegister = event.target.value === 'register';
      $('#authUsername').disabled = !isRegister;
      $('#authName').disabled = !isRegister;
      $('#adminSetupToken').disabled = !isRegister;
      $('#authPassword').autocomplete = isRegister ? 'new-password' : 'current-password';
    }
  });

  // Bring the API connection panel into the UI and establish the configured server session.
  tabs();
  refreshAccountButton();
  if (apiBase) refreshRemote(false).catch((error) => console.warn('VidTube bootstrap failed:', error));
  else {
    remoteMode = false;
    toast('Demo mode. Open Sign in to connect your backend.');
  }
})();
