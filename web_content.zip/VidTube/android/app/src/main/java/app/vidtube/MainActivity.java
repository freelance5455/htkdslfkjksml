package app.vidtube;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends ComponentActivity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String TOKEN_PREFS = "vidtube_secure_prefs";
    private static final String TOKEN_KEY = "access_token_encrypted";
    private static final String KEY_ALIAS = "vidtube_access_token_key_v1";
    private FrameLayout root;
    private WebView web;
    private View custom;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> pending;
    private ActivityResultLauncher<Intent> picker;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        EdgeToEdge.enable(this);
        root = new FrameLayout(this);
        web = new WebView(this);
        web.setBackgroundColor(0);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, w) -> {
            Insets i = w.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout()
                    | WindowInsetsCompat.Type.ime());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        picker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (pending != null) {
                pending.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData()));
                pending = null;
            }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(BuildConfig.DEBUG
                ? WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                : WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(), "Android");

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // The WebView renderer was killed (usually low memory). Rebuild the screen instead of crashing the app.
                runOnUiThread(MainActivity.this::recreate);
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (pending != null) pending.onReceiveValue(null);
                pending = cb;
                try {
                    picker.launch(params.createIntent());
                } catch (ActivityNotFoundException e) {
                    pending = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (custom != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                custom = view;
                customCb = cb;
                ((ViewGroup) getWindow().getDecorView()).addView(view, new FrameLayout.LayoutParams(-1, -1));
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), view);
                c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsetsCompat.Type.systemBars());
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (custom != null) hideCustom();
                else if (web.canGoBack()) web.goBack();
                else finish();
            }
        });

        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    private void hideCustom() {
        if (custom == null) return;
        ((ViewGroup) getWindow().getDecorView()).removeView(custom);
        custom = null;
        WindowCompat.getInsetsController(getWindow(), root).show(WindowInsetsCompat.Type.systemBars());
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    private SecretKey getOrCreateTokenKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) {
            return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    private SharedPreferences tokenPreferences() {
        return getSharedPreferences(TOKEN_PREFS, MODE_PRIVATE);
    }

    private String readEncryptedToken() {
        try {
            String stored = tokenPreferences().getString(TOKEN_KEY, "");
            if (stored.isEmpty()) return "";
            String[] parts = stored.split(":", 2);
            if (parts.length != 2) throw new IllegalStateException("Invalid encrypted token format");
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] encrypted = Base64.decode(parts[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateTokenKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception e) {
            tokenPreferences().edit().remove(TOKEN_KEY).apply();
            return "";
        }
    }

    private boolean writeEncryptedToken(String token) {
        if (token == null || token.isEmpty()) {
            clearEncryptedToken();
            return true;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateTokenKey());
            byte[] encrypted = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
            String value = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":"
                    + Base64.encodeToString(encrypted, Base64.NO_WRAP);
            tokenPreferences().edit().putString(TOKEN_KEY, value).apply();
            return true;
        } catch (Exception e) {
            tokenPreferences().edit().remove(TOKEN_KEY).apply();
            return false;
        }
    }

    private void clearEncryptedToken() {
        tokenPreferences().edit().remove(TOKEN_KEY).apply();
    }

    public final class Bridge {
        @JavascriptInterface
        public String getServerUrl() {
            return BuildConfig.DEFAULT_SERVER_URL;
        }

        @JavascriptInterface
        public String getAuthToken() {
            return readEncryptedToken();
        }

        @JavascriptInterface
        public boolean setAuthToken(final String token) {
            return writeEncryptedToken(token);
        }

        @JavascriptInterface
        public void clearAuthToken() {
            clearEncryptedToken();
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, null));
            });
        }

        @JavascriptInterface
        public void bars(final boolean dark) {
            runOnUiThread(() -> {
                root.setBackgroundColor(dark ? 0xFF0F0F0F : 0xFFFFFFFF);
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), root);
                c.setAppearanceLightStatusBars(!dark);
                c.setAppearanceLightNavigationBars(!dark);
            });
        }
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (pending != null) {
            pending.onReceiveValue(null);
            pending = null;
        }
        root.removeAllViews();
        web.destroy();
        super.onDestroy();
    }
}
