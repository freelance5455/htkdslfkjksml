#!/usr/bin/env sh
# Lets a phone plugged in by USB reach the VidTube server on this computer (no Wi-Fi needed).
ADB="$HOME/Android/Sdk/platform-tools/adb"
[ -x "$ADB" ] || ADB="$HOME/Library/Android/sdk/platform-tools/adb"
[ -x "$ADB" ] || ADB="adb"
"$ADB" reverse tcp:4000 tcp:4000 && echo "Done. Start the VidTube server, then open the app: it finds the server by itself."
