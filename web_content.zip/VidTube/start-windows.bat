@echo off
title VidTube server
cd /d "%~dp0server"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed yet. It is free and takes about 2 minutes:
  echo    1. Open https://nodejs.org
  echo    2. Click the green "LTS" download button and install it ^(keep all the default options^)
  echo    3. Double-click this file again
  echo.
  start "" https://nodejs.org
  pause
  exit /b 1
)

node server.js
echo.
echo  VidTube stopped. If you did not expect this, read the message above.
pause
