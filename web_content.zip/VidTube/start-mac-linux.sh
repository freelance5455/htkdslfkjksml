#!/usr/bin/env sh
# Starts the VidTube server. Run:  sh start-mac-linux.sh
cd "$(dirname "$0")/server" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo " Node.js is not installed yet. Download the LTS version from https://nodejs.org, install it, then run this again."
  echo ""
  exit 1
fi
exec node server.js
