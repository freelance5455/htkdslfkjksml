# VidTube

A YouTube-style video app that you run yourself: watch, upload, like, comment, subscribe, search, a creator Studio and moderation tools.

- `server/`  the VidTube server **and** the website. The only thing to install is Node.js.
- `android/` the Android Studio project: the same screens inside a real Android app.

## 1. Start it (about 2 minutes)

1. **Unzip** this folder first (right-click → *Extract All*). Do not run it from inside the zip.
2. Install **Node.js** (the green **LTS** button on https://nodejs.org). Once only.
3. Start the server:
   - **Windows:** double-click `start-windows.bat`
   - **Mac / Linux:** run `sh start-mac-linux.sh`
4. Open **http://localhost:4000** in your browser.

No Docker, no database to install, no `npm install`. Your accounts and videos are saved in `server/data/`.

- The **first account you create becomes the administrator** (it gets a 🛡 Admin tab with the moderation screen).
- Two small sample videos come with a new server so you can see playback working. To remove them: stop the server and run `node remove-samples.js` inside the `server` folder. To start without them, create `server/.env` containing `SEED_DEMO=0` before the first start.
- Videos can be up to **50 MB** each, with **50 MB** per account (change in `server/.env`, see `server/.env.example`).

## 2. Use it on your phone (same Wi-Fi)

The server prints `On your phone (same Wi-Fi), open this address in Chrome:` followed by an address like `http://192.168.1.23:4000`. Open exactly that address in Chrome on your phone.

- Windows may ask *"Allow Node.js to communicate on these networks?"*: tick **Private networks** and click **Allow**.
- Many college Wi-Fi networks block phone-to-computer traffic. If the page will not open, turn on your phone's **hotspot**, connect the computer to it, and use the new address the server prints.
- Chrome menu → **Add to Home screen** puts it on your home screen. (The full "Install app" mode needs an https address, see *Going public*.)

## 3. The Android app (Android Studio)

1. Install **Android Studio Meerkat (2024.3.1 Patch 1) or newer**: https://developer.android.com/studio. Keep **JDK 17 or 21** (the one inside Android Studio is fine).
2. **File → Open** and choose the `android` folder. The first Gradle sync downloads the build tools (internet needed, about 1 GB, 5–15 minutes). Accept "Install missing SDK Platform 36" if it asks.
3. Start the server (step 1) and press the green **Run ▶** button.
   - **Emulator:** works as is (it reaches your computer at `http://10.0.2.2:4000`).
   - **Real phone:** tap **Sign in → Server address**, type the address the server printed (`http://192.168.x.x:4000`) and tap **Save & connect**. To bake it in, set `vidtube.serverUrl=` in `android/gradle.properties`.

## If something does not work

| You see | Do this |
|---|---|
| `'node' is not recognized` | Install Node.js LTS, close the black window and double-click the start file again. |
| *"needs Node.js 22.13 or newer"* | Install the current LTS from https://nodejs.org. |
| *Port 4000 is busy* | Nothing to do: the server picks the next free port and prints it. |
| Phone cannot open the address | Same Wi-Fi? Click **Allow** in the Windows firewall box. On college Wi-Fi use your phone hotspot. |
| App says *Cannot reach the server* | Server still running? Right address? Emulator uses `http://10.0.2.2:4000`. |
| Android Studio says the Gradle plugin is incompatible | Update Android Studio (Help → Check for Updates). Needs Meerkat 2024.3.1 Patch 1 or newer. |
| Gradle sync fails with a red error | Copy the **first red line** and send it to me. |

## Settings (all optional)

Copy `server/.env.example` to `server/.env` and change what you need: `PORT`, `MAX_UPLOAD_BYTES`, `STORAGE_QUOTA_BYTES`, `SEED_DEMO`, and for a public server `NODE_ENV`, `JWT_SECRET`, `OPERATOR_NAME`, `CONTACT_EMAIL`.

## Tests

`cd server` then `npm test`. Runs 36 checks against a real server (accounts, uploads, streaming and seeking, limits, privacy, moderation, restart safety). Nothing to install.

## Going public / Google Play (later)

1. Put the server on a machine that is always on, **behind https** (Caddy, nginx or Cloudflare), with a disk that is kept between restarts. Back up `server/data/`. Set `NODE_ENV=production`, `JWT_SECRET` (32+ random characters), `OPERATOR_NAME`, `CONTACT_EMAIL`, and `TRUST_PROXY=1` behind a proxy. In production nobody becomes admin automatically: set `BOOTSTRAP_ADMIN_EMAIL` and `BOOTSTRAP_ADMIN_TOKEN`, register with that email, and enter the code in the *Admin setup code* box.
2. In `android/gradle.properties` set `vidtube.releaseServerUrl=https://your-address`. Choose your permanent `applicationId` in `android/app/build.gradle.kts` before the first upload (it can never change later) and raise `versionCode` for every upload.
3. Create a signing key **once and back it up**: `keytool -genkeypair -v -keystore vidtube-release.jks -alias vidtube -keyalg RSA -keysize 2048 -validity 10000`. Create `android/keystore.properties` with `storeFile`, `storePassword`, `keyAlias`, `keyPassword`. Then run `./gradlew bundleRelease` in `android/` (Windows: `gradlew.bat bundleRelease`) and upload `app/build/outputs/bundle/release/app-release.aab`.
4. Google Play pages: your server serves `/legal/privacy`, `/legal/terms` and `/legal/delete-account`. They are templates, not legal advice. Have them reviewed. Play expects real moderation of reports. New apps and updates must target API 36 (already set).
