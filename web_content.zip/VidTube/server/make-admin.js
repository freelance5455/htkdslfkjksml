'use strict';
// Makes an existing account an administrator (gives it the Admin / moderation tab).
//   node make-admin.js you@example.com
const database = require('./src/db');

const email = String(process.argv[2] || '').trim().toLowerCase();
if (!email) {
  console.log('Usage: node make-admin.js your-email@example.com');
  process.exit(1);
}
const result = database.run("UPDATE users SET role = 'admin' WHERE email = ?", email);
console.log(result.changes ? `${email} is now an administrator. Sign out and in again in the app.` : `No account with the email ${email}. Create the account in the app first, then run this again.`);
database.close();
