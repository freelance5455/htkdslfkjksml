'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { startServer, request, register, upload, fakeVideo } = require('./helpers');

const REAL_VIDEO = fs.readFileSync(path.join(__dirname, 'fixtures', 'sample.webm'));
const REAL_VIDEO_2 = fs.readFileSync(path.join(__dirname, 'fixtures', 'sample2.webm'));
const JPEG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(200, 1)]);

describe('VidTube server', () => {
  let server;
  let base;
  let admin;
  let alice;
  let bob;
  let videoId;

  before(async () => {
    server = await startServer({ STORAGE_QUOTA_BYTES: String(400 * 1024), MAX_UPLOAD_BYTES: String(300 * 1024) });
    base = server.base;
  });
  after(async () => { await server.stop(); });

  describe('basics', () => {
    it('answers the health check with security headers', async () => {
      const res = await request(base, 'GET', '/health');
      assert.equal(res.status, 200);
      assert.equal(res.json.status, 'ok');
      assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    });

    it('returns JSON 404s for unknown API routes and bad ids', async () => {
      const unknown = await request(base, 'GET', '/api/v1/nope');
      assert.equal(unknown.status, 404);
      assert.equal(unknown.json.error.code, 'NOT_FOUND');
      const badId = await request(base, 'GET', '/api/v1/videos/not-a-uuid');
      assert.equal(badId.status, 404);
    });

    it('rejects malformed JSON with a clear error', async () => {
      const res = await request(base, 'POST', '/api/v1/auth/login', { body: '{oops', headers: { 'Content-Type': 'application/json' } });
      assert.equal(res.status, 400);
      assert.equal(res.json.error.code, 'INVALID_JSON');
    });

    it('answers CORS preflight for the Android app origin', async () => {
      const res = await request(base, 'OPTIONS', '/api/v1/auth/login', { headers: { Origin: 'https://appassets.androidplatform.net', 'Access-Control-Request-Method': 'POST' } });
      assert.equal(res.status, 204);
      assert.ok(res.headers.get('access-control-allow-headers').includes('Authorization'));
      assert.ok(res.headers.get('access-control-allow-origin'));
    });

    it('serves the legal pages', async () => {
      for (const page of ['terms', 'privacy', 'delete-account']) {
        const res = await request(base, 'GET', `/legal/${page}`);
        assert.equal(res.status, 200, page);
        assert.ok(res.buffer.toString().includes('<html'), page);
      }
      assert.equal((await request(base, 'GET', '/legal/unknown')).status, 404);
    });

    it('serves the web app and does not leak server files', async () => {
      const home = await request(base, 'GET', '/');
      assert.equal(home.status, 200);
      assert.ok(home.buffer.toString().includes('VidTube'));
      assert.ok(home.headers.get('content-security-policy'));
      for (const attempt of ['/src/config.js', '/../src/config.js', '/..%2fsrc%2fconfig.js', '/%2e%2e/server.js', '/data/vidtube.sqlite', '/package.json']) {
        const res = await request(base, 'GET', attempt);
        assert.equal(res.status, 404, attempt);
      }
    });
  });

  describe('accounts', () => {
    it('explains validation problems in plain words', async () => {
      const short = await request(base, 'POST', '/api/v1/auth/register', { json: { email: 'a@b.co', username: 'okname', displayName: 'Ok', password: 'short', acceptTerms: true } });
      assert.equal(short.status, 400);
      assert.match(short.json.error.message, /Password must be at least 10 characters/);
      const noTerms = await request(base, 'POST', '/api/v1/auth/register', { json: { email: 'a@b.co', username: 'okname', displayName: 'Ok', password: 'long-enough-pass' } });
      assert.equal(noTerms.status, 400);
      assert.match(noTerms.json.error.message, /Terms/);
      const badEmail = await request(base, 'POST', '/api/v1/auth/register', { json: { email: 'nope', username: 'okname', displayName: 'Ok', password: 'long-enough-pass', acceptTerms: true } });
      assert.match(badEmail.json.error.message, /valid email/);
    });

    it('the first account becomes administrator, later ones do not', async () => {
      admin = await register(base);
      alice = await register(base);
      bob = await register(base);
      assert.equal(admin.user.role, 'admin');
      assert.equal(alice.user.role, 'user');
      assert.ok(alice.channel.id);
      assert.equal(typeof admin.token, 'string');
    });

    it('rejects duplicate emails and usernames', async () => {
      const dup = await request(base, 'POST', '/api/v1/auth/register', { json: { ...alice.input } });
      assert.equal(dup.status, 409);
      const dupName = await request(base, 'POST', '/api/v1/auth/register', { json: { ...alice.input, email: 'other@example.com', username: alice.input.username.toUpperCase() } });
      assert.equal(dupName.status, 409);
    });

    it('logs in with the right password only', async () => {
      const ok = await request(base, 'POST', '/api/v1/auth/login', { json: { email: alice.input.email.toUpperCase(), password: alice.input.password } });
      assert.equal(ok.status, 200);
      assert.equal(ok.json.data.user.username, alice.input.username.toLowerCase());
      const bad = await request(base, 'POST', '/api/v1/auth/login', { json: { email: alice.input.email, password: 'wrong-password-1' } });
      assert.equal(bad.status, 401);
      const unknown = await request(base, 'POST', '/api/v1/auth/login', { json: { email: 'nobody@example.com', password: 'wrong-password-1' } });
      assert.equal(unknown.status, 401);
    });

    it('requires a token for /auth/me and updates the profile', async () => {
      assert.equal((await request(base, 'GET', '/api/v1/auth/me')).status, 401);
      assert.equal((await request(base, 'GET', '/api/v1/auth/me', { token: 'garbage.token.value' })).status, 401);
      const me = await request(base, 'GET', '/api/v1/auth/me', { token: alice.token });
      assert.equal(me.json.data.user.id, alice.user.id);
      const patch = await request(base, 'PATCH', '/api/v1/auth/profile', { token: alice.token, json: { displayName: 'Alice Cooper', description: 'Hello channel' } });
      assert.equal(patch.status, 200);
      const again = await request(base, 'GET', '/api/v1/auth/me', { token: alice.token });
      assert.equal(again.json.data.user.display_name, 'Alice Cooper');
      assert.equal(again.json.data.channel.description, 'Hello channel');
    });
  });

  describe('uploads and streaming', () => {
    it('refuses uploads without sign-in, wrong types and fake videos', async () => {
      assert.equal((await upload(base, null, REAL_VIDEO)).status, 401);
      const text = await upload(base, alice.token, Buffer.from('hello'), {}, { 'Content-Type': 'text/plain' });
      assert.equal(text.status, 415);
      const fake = await upload(base, alice.token, Buffer.from('<html><script>alert(1)</script></html> padding padding'), {}, { 'Content-Type': 'video/mp4' });
      assert.equal(fake.status, 415);
      const noTitle = await upload(base, alice.token, REAL_VIDEO, { title: '' });
      assert.equal(noTitle.status, 400);
      assert.equal((await upload(base, alice.token, Buffer.alloc(0))).status, 400);
      assert.deepEqual(fs.readdirSync(server.uploadDir).filter((f) => f.startsWith('.incoming-')), []);
    });

    it('stores a real video and lists it', async () => {
      const res = await upload(base, alice.token, REAL_VIDEO, { title: 'Learn <b>React</b>' });
      assert.equal(res.status, 201, res.buffer.toString());
      videoId = res.json.data.id;
      assert.equal(res.json.data.title, 'Learn <b>React</b>');
      assert.equal(res.json.data.mime_type, 'video/webm');
      assert.equal(res.json.data.file_size, REAL_VIDEO.length);
      assert.equal(res.json.data.channel.id, alice.channel.id);
      const list = await request(base, 'GET', '/api/v1/videos');
      assert.equal(list.json.data.length, 1);
      assert.equal(list.json.data[0].id, videoId);
      const one = await request(base, 'GET', `/api/v1/videos/${videoId}`);
      assert.equal(one.json.data.stream_url, `/api/v1/videos/${videoId}/stream`);
    });

    it('streams the whole file, ranges and HEAD requests', async () => {
      const full = await request(base, 'GET', `/api/v1/videos/${videoId}/stream`);
      assert.equal(full.status, 200);
      assert.equal(full.headers.get('accept-ranges'), 'bytes');
      assert.equal(full.headers.get('content-type'), 'video/webm');
      assert.ok(full.buffer.equals(REAL_VIDEO));
      const part = await request(base, 'GET', `/api/v1/videos/${videoId}/stream`, { headers: { Range: 'bytes=100-199' } });
      assert.equal(part.status, 206);
      assert.equal(part.headers.get('content-range'), `bytes 100-199/${REAL_VIDEO.length}`);
      assert.ok(part.buffer.equals(REAL_VIDEO.subarray(100, 200)));
      const tail = await request(base, 'GET', `/api/v1/videos/${videoId}/stream`, { headers: { Range: 'bytes=-50' } });
      assert.equal(tail.status, 206);
      assert.ok(tail.buffer.equals(REAL_VIDEO.subarray(REAL_VIDEO.length - 50)));
      const open = await request(base, 'GET', `/api/v1/videos/${videoId}/stream`, { headers: { Range: `bytes=${REAL_VIDEO.length - 10}-` } });
      assert.equal(open.status, 206);
      const bad = await request(base, 'GET', `/api/v1/videos/${videoId}/stream`, { headers: { Range: `bytes=${REAL_VIDEO.length + 5}-` } });
      assert.equal(bad.status, 416);
      const head = await request(base, 'HEAD', `/api/v1/videos/${videoId}/stream`);
      assert.equal(head.status, 200);
      assert.equal(Number(head.headers.get('content-length')), REAL_VIDEO.length);
    });

    it('enforces the per-video size limit before reading the body', async () => {
      const res = await upload(base, alice.token, fakeVideo(320 * 1024));
      assert.equal(res.status, 413);
      assert.equal(res.json.error.code, 'LIMIT_FILE_SIZE');
    });

    it('enforces the storage quota and reports usage', async () => {
      const second = await upload(base, alice.token, fakeVideo(250 * 1024), { title: 'Second' });
      assert.equal(second.status, 201);
      const third = await upload(base, alice.token, fakeVideo(100 * 1024), { title: 'Third' });
      assert.equal(third.status, 413);
      assert.equal(third.json.error.code, 'STORAGE_QUOTA_EXCEEDED');
      const storage = await request(base, 'GET', '/api/v1/me/storage', { token: alice.token });
      assert.equal(storage.json.data.limit_bytes, 400 * 1024);
      assert.equal(storage.json.data.used_bytes, REAL_VIDEO.length + 250 * 1024);
      assert.deepEqual(fs.readdirSync(server.uploadDir).filter((f) => f.startsWith('.incoming-')), []);
      const mine = await request(base, 'GET', '/api/v1/me/videos', { token: alice.token });
      const secondVideo = mine.json.data.find((v) => v.title === 'Second');
      const del = await request(base, 'DELETE', `/api/v1/videos/${secondVideo.id}`, { token: alice.token });
      assert.equal(del.status, 204);
      assert.equal((await request(base, 'GET', `/api/v1/videos/${secondVideo.id}`)).status, 404);
    });

    it('accepts a thumbnail from the owner only', async () => {
      assert.equal((await request(base, 'PUT', `/api/v1/videos/${videoId}/thumbnail`, { token: bob.token, body: JPEG, headers: { 'Content-Type': 'image/jpeg' } })).status, 404);
      assert.equal((await request(base, 'PUT', `/api/v1/videos/${videoId}/thumbnail`, { token: alice.token, body: Buffer.from('not an image at all'), headers: { 'Content-Type': 'image/jpeg' } })).status, 415);
      assert.equal((await request(base, 'PUT', `/api/v1/videos/${videoId}/thumbnail`, { token: alice.token, body: Buffer.alloc(600 * 1024, 1), headers: { 'Content-Type': 'image/jpeg' } })).status, 413);
      const ok = await request(base, 'PUT', `/api/v1/videos/${videoId}/thumbnail`, { token: alice.token, body: JPEG, headers: { 'Content-Type': 'image/jpeg' } });
      assert.equal(ok.status, 200);
      const video = await request(base, 'GET', `/api/v1/videos/${videoId}`);
      assert.equal(video.json.data.thumbnail_url, `/api/v1/videos/${videoId}/thumbnail`);
      const image = await request(base, 'GET', video.json.data.thumbnail_url);
      assert.equal(image.status, 200);
      assert.equal(image.headers.get('content-type'), 'image/jpeg');
      assert.ok(image.buffer.equals(JPEG));
    });
  });

  describe('visibility', () => {
    let privateId;
    let unlistedId;
    it('keeps private videos away from other people and lists unlisted ones only by link', async () => {
      const priv = await upload(base, bob.token, REAL_VIDEO_2, { title: 'Private one', visibility: 'private' });
      assert.equal(priv.status, 201);
      privateId = priv.json.data.id;
      assert.match(priv.json.data.stream_url, /\?ticket=/);
      const unl = await upload(base, bob.token, REAL_VIDEO_2, { title: 'Unlisted one', visibility: 'unlisted' });
      unlistedId = unl.json.data.id;
      const list = await request(base, 'GET', '/api/v1/videos', { token: alice.token });
      assert.deepEqual(list.json.data.map((v) => v.title).sort(), ['Learn <b>React</b>']);
      assert.equal((await request(base, 'GET', `/api/v1/videos/${privateId}`)).status, 404);
      assert.equal((await request(base, 'GET', `/api/v1/videos/${privateId}`, { token: alice.token })).status, 404);
      assert.equal((await request(base, 'GET', `/api/v1/videos/${privateId}`, { token: bob.token })).status, 200);
      assert.equal((await request(base, 'GET', `/api/v1/videos/${unlistedId}`)).status, 200);
    });

    it('streams private videos only with the owner token or a valid ticket', async () => {
      assert.equal((await request(base, 'GET', `/api/v1/videos/${privateId}/stream`)).status, 404);
      const mine = await request(base, 'GET', '/api/v1/me/videos', { token: bob.token });
      const entry = mine.json.data.find((v) => v.id === privateId);
      const ok = await request(base, 'GET', entry.stream_url);
      assert.equal(ok.status, 200);
      assert.ok(ok.buffer.equals(REAL_VIDEO_2));
      assert.equal((await request(base, 'GET', `/api/v1/videos/${privateId}/stream?ticket=abc.def.ghi`)).status, 404);
      const aliceTicket = (await request(base, 'GET', '/api/v1/me/videos', { token: alice.token })).json.data[0].stream_url.split('ticket=')[1];
      assert.equal(aliceTicket, undefined);
    });

    it('lets the owner change visibility and edit details', async () => {
      const patch = await request(base, 'PATCH', `/api/v1/videos/${privateId}`, { token: bob.token, json: { visibility: 'public', title: 'Now public', category: 'Music' } });
      assert.equal(patch.status, 200);
      assert.equal(patch.json.data.visibility, 'public');
      assert.equal((await request(base, 'GET', `/api/v1/videos/${privateId}`)).status, 200);
      assert.equal((await request(base, 'PATCH', `/api/v1/videos/${privateId}`, { token: alice.token, json: { title: 'Hacked' } })).status, 404);
      assert.equal((await request(base, 'PATCH', `/api/v1/videos/${privateId}`, { token: bob.token, json: {} })).status, 400);
    });
  });

  describe('views, likes, search', () => {
    it('counts one view per visitor per day', async () => {
      const first = await request(base, 'POST', `/api/v1/videos/${videoId}/view`, { token: bob.token, json: {} });
      assert.equal(first.json.data.view_count, 1);
      const again = await request(base, 'POST', `/api/v1/videos/${videoId}/view`, { token: bob.token, json: {} });
      assert.equal(again.json.data.view_count, 1);
      const anon = await request(base, 'POST', `/api/v1/videos/${videoId}/view`, { json: {} });
      assert.equal(anon.json.data.view_count, 2);
    });

    it('likes, dislikes and clears votes', async () => {
      assert.equal((await request(base, 'POST', `/api/v1/videos/${videoId}/like`, { json: { value: 1 } })).status, 401);
      const like = await request(base, 'POST', `/api/v1/videos/${videoId}/like`, { token: bob.token, json: { value: 1 } });
      assert.deepEqual([like.json.data.like_count, like.json.data.dislike_count], [1, 0]);
      const swap = await request(base, 'POST', `/api/v1/videos/${videoId}/like`, { token: bob.token, json: { value: -1 } });
      assert.deepEqual([swap.json.data.like_count, swap.json.data.dislike_count], [0, 1]);
      const seen = await request(base, 'GET', `/api/v1/videos/${videoId}`, { token: bob.token });
      assert.equal(seen.json.data.user_like, -1);
      const clear = await request(base, 'POST', `/api/v1/videos/${videoId}/like`, { token: bob.token, json: { value: 0 } });
      assert.deepEqual([clear.json.data.like_count, clear.json.data.dislike_count], [0, 0]);
      assert.equal((await request(base, 'POST', `/api/v1/videos/${videoId}/like`, { token: bob.token, json: { value: 5 } })).status, 400);
    });

    it('searches titles safely and filters by category', async () => {
      const found = await request(base, 'GET', '/api/v1/videos?q=react');
      assert.equal(found.json.data.length, 1);
      assert.equal((await request(base, 'GET', '/api/v1/videos?q=zzz')).json.data.length, 0);
      assert.equal((await request(base, 'GET', '/api/v1/videos?q=%25')).json.data.length, 0);
      assert.equal((await request(base, 'GET', "/api/v1/videos?q=' OR 1=1 --")).json.data.length, 0);
      assert.equal((await request(base, 'GET', '/api/v1/videos?category=Coding')).json.data.length, 1);
      assert.equal((await request(base, 'GET', '/api/v1/videos?category=Music')).json.data.length, 1);
      assert.equal((await request(base, 'GET', '/api/v1/videos?sort=trending')).status, 200);
      assert.equal((await request(base, 'GET', '/api/v1/videos?limit=1')).json.data.length, 1);
    });
  });

  describe('comments, reports, blocking', () => {
    let commentId;
    it('posts, replies and lists comments', async () => {
      assert.equal((await request(base, 'POST', `/api/v1/videos/${videoId}/comments`, { json: { body: 'hi' } })).status, 401);
      assert.equal((await request(base, 'POST', `/api/v1/videos/${videoId}/comments`, { token: bob.token, json: { body: '   ' } })).status, 400);
      const c = await request(base, 'POST', `/api/v1/videos/${videoId}/comments`, { token: bob.token, json: { body: 'Great video <3' } });
      assert.equal(c.status, 201);
      commentId = c.json.data.id;
      const reply = await request(base, 'POST', `/api/v1/videos/${videoId}/comments`, { token: alice.token, json: { body: 'Thanks!', parentId: commentId } });
      assert.equal(reply.status, 201);
      const list = await request(base, 'GET', `/api/v1/videos/${videoId}/comments`);
      assert.equal(list.json.data.length, 2);
      assert.equal(list.json.data[1].parent_id, commentId);
      assert.equal(list.json.data[0].user.username, bob.input.username.toLowerCase());
      const wrongParent = await request(base, 'POST', `/api/v1/videos/${videoId}/comments`, { token: alice.token, json: { body: 'x', parentId: '00000000-0000-4000-8000-000000000000' } });
      assert.equal(wrongParent.status, 400);
      assert.equal(wrongParent.json.error.code, 'INVALID_PARENT_COMMENT');
      const video = await request(base, 'GET', `/api/v1/videos/${videoId}`);
      assert.equal(video.json.data.comment_count, 2);
    });

    it('lets only the author, the channel owner or an admin delete a comment', async () => {
      const mallory = await register(base);
      assert.equal((await request(base, 'DELETE', `/api/v1/comments/${commentId}`, { token: mallory.token })).status, 404);
      const extra = await request(base, 'POST', `/api/v1/videos/${videoId}/comments`, { token: bob.token, json: { body: 'to be removed by the channel owner' } });
      assert.equal((await request(base, 'DELETE', `/api/v1/comments/${extra.json.data.id}`, { token: alice.token })).status, 204);
    });

    it('reports content and lets the administrator review it', async () => {
      assert.equal((await request(base, 'POST', `/api/v1/comments/${commentId}/report`, { token: alice.token, json: { reason: 'spam' } })).status, 201);
      assert.equal((await request(base, 'POST', `/api/v1/comments/${commentId}/report`, { token: alice.token, json: { reason: 'spam again' } })).status, 201);
      assert.equal((await request(base, 'POST', `/api/v1/videos/${videoId}/report`, { token: alice.token, json: { reason: 'own' } })).status, 400);
      const rv = await request(base, 'POST', `/api/v1/videos/${videoId}/report`, { token: bob.token, json: { reason: 'misleading' } });
      assert.equal(rv.status, 201);
      assert.equal((await request(base, 'POST', `/api/v1/channels/${alice.channel.id}/report`, { token: bob.token, json: { reason: 'bad channel' } })).status, 201);
      assert.equal((await request(base, 'GET', '/api/v1/admin/reports', { token: alice.token })).status, 403);
      const reports = await request(base, 'GET', '/api/v1/admin/reports', { token: admin.token });
      assert.equal(reports.status, 200);
      assert.deepEqual(reports.json.data.map((r) => r.type).sort(), ['channel', 'comment', 'video']);
      const first = reports.json.data[0];
      assert.equal((await request(base, 'PATCH', `/api/v1/admin/reports/${first.id}`, { token: admin.token, json: { status: 'dismissed' } })).status, 200);
      const after = await request(base, 'GET', '/api/v1/admin/reports', { token: admin.token });
      assert.equal(after.json.data.length, 2);
      assert.equal((await request(base, 'PATCH', `/api/v1/admin/reports/${first.id}`, { token: admin.token, json: { status: 'nope' } })).status, 400);
    });

    it('hides comments from blocked people', async () => {
      assert.equal((await request(base, 'POST', `/api/v1/users/${alice.user.id}/block`, { token: alice.token })).status, 400);
      assert.equal((await request(base, 'POST', `/api/v1/users/${bob.user.id}/block`, { token: alice.token })).status, 200);
      const list = await request(base, 'GET', `/api/v1/videos/${videoId}/comments`, { token: alice.token });
      assert.ok(list.json.data.every((c) => c.user.id !== bob.user.id));
      const blocks = await request(base, 'GET', '/api/v1/me/blocks', { token: alice.token });
      assert.equal(blocks.json.data.length, 1);
      const feed = await request(base, 'GET', '/api/v1/videos', { token: alice.token });
      assert.ok(feed.json.data.every((v) => v.owner.id !== bob.user.id));
      assert.equal((await request(base, 'DELETE', `/api/v1/users/${bob.user.id}/block`, { token: alice.token })).status, 200);
      assert.equal((await request(base, 'GET', '/api/v1/me/blocks', { token: alice.token })).json.data.length, 0);
    });
  });

  describe('subscriptions', () => {
    it('subscribes, builds the feed and unsubscribes', async () => {
      assert.equal((await request(base, 'POST', `/api/v1/channels/${bob.channel.id}/subscribe`, { token: bob.token })).status, 400);
      assert.equal((await request(base, 'POST', `/api/v1/channels/${alice.channel.id}/subscribe`, { token: bob.token })).status, 200);
      assert.equal((await request(base, 'POST', `/api/v1/channels/${alice.channel.id}/subscribe`, { token: bob.token })).status, 200);
      const channel = await request(base, 'GET', `/api/v1/channels/${alice.channel.id}`);
      assert.equal(channel.json.data.subscriber_count, 1);
      assert.equal(channel.json.data.video_count, 1);
      const subs = await request(base, 'GET', '/api/v1/me/subscriptions', { token: bob.token });
      assert.equal(subs.json.data.length, 1);
      const feed = await request(base, 'GET', '/api/v1/me/feed', { token: bob.token });
      assert.equal(feed.json.data.length, 1);
      assert.equal(feed.json.data[0].channel.subscriber_count, 1);
      assert.equal((await request(base, 'DELETE', `/api/v1/channels/${alice.channel.id}/subscribe`, { token: bob.token })).status, 200);
      assert.equal((await request(base, 'GET', '/api/v1/me/feed', { token: bob.token })).json.data.length, 0);
    });
  });

  describe('deleting things', () => {
    it('removes files when a video is deleted and blocks non-owners', async () => {
      const up = await upload(base, bob.token, fakeVideo(20 * 1024), { title: 'Disposable' });
      const id = up.json.data.id;
      const before = fs.readdirSync(server.uploadDir).length;
      assert.equal((await request(base, 'DELETE', `/api/v1/videos/${id}`, { token: alice.token })).status, 404);
      assert.equal((await request(base, 'DELETE', `/api/v1/videos/${id}`, { token: bob.token })).status, 204);
      assert.equal(fs.readdirSync(server.uploadDir).length, before - 1);
    });

    it('deletes an account with its videos, and the old token stops working', async () => {
      const temp = await register(base);
      const up = await upload(base, temp.token, fakeVideo(20 * 1024), { title: 'Will vanish' });
      assert.equal(up.status, 201);
      const filesBefore = fs.readdirSync(server.uploadDir).length;
      assert.equal((await request(base, 'DELETE', '/api/v1/auth/account', { token: temp.token, json: { password: 'wrong-password-1' } })).status, 401);
      assert.equal((await request(base, 'DELETE', '/api/v1/auth/account', { token: temp.token, json: { password: temp.input.password } })).status, 204);
      assert.equal(fs.readdirSync(server.uploadDir).length, filesBefore - 1);
      assert.equal((await request(base, 'GET', '/api/v1/auth/me', { token: temp.token })).status, 401);
      assert.equal((await request(base, 'GET', `/api/v1/videos/${up.json.data.id}`)).status, 404);
    });

    it('lets an administrator remove a regular user but not another admin', async () => {
      const victim = await register(base);
      assert.equal((await request(base, 'DELETE', `/api/v1/admin/users/${victim.user.id}`, { token: alice.token })).status, 403);
      assert.equal((await request(base, 'DELETE', `/api/v1/admin/users/${admin.user.id}`, { token: admin.token })).status, 400);
      assert.equal((await request(base, 'DELETE', `/api/v1/admin/users/${victim.user.id}`, { token: admin.token })).status, 204);
      assert.equal((await request(base, 'GET', '/api/v1/auth/me', { token: victim.token })).status, 401);
    });
  });
});

describe('VidTube sample content', () => {
  it('starts a brand-new server with two playable sample videos and keeps the first real account as admin', async () => {
    const server = await startServer({ SEED_DEMO: '1' });
    try {
      const list = await request(server.base, 'GET', '/api/v1/videos');
      assert.deepEqual(list.json.data.map((v) => v.title), ['Welcome to VidTube', 'How uploading works']);
      for (const video of list.json.data) {
        assert.ok(video.thumbnail_url, 'has a thumbnail');
        assert.equal((await request(server.base, 'GET', video.thumbnail_url)).headers.get('content-type'), 'image/jpeg');
        const stream = await request(server.base, 'GET', video.stream_url);
        assert.equal(stream.status, 200);
        assert.equal(stream.buffer.subarray(0, 4).toString('hex'), '1a45dfa3');
      }
      const first = await register(server.base);
      assert.equal(first.user.role, 'admin');
      const reserved = await request(server.base, 'POST', '/api/v1/auth/register', { json: { email: 'x@vidtube.local', username: 'sneaky_one', displayName: 'Sneaky', password: 'long-enough-pass', acceptTerms: true } });
      assert.equal(reserved.status, 400);
      // the administrator can remove the sample videos
      const sample = list.json.data[0];
      assert.equal((await request(server.base, 'DELETE', `/api/v1/videos/${sample.id}`, { token: first.token })).status, 204);
      assert.equal((await request(server.base, 'GET', '/api/v1/videos')).json.data.length, 1);
    } finally { await server.stop(); }
  });
  it('does not add samples to a server that already has accounts', async () => {
    const first = await startServer({ SEED_DEMO: '0' });
    await register(first.base);
    await first.stop({ keepData: true });
    const second = await startServer({ SEED_DEMO: '1' }, { reuseDir: first.dataDir });
    try { assert.equal((await request(second.base, 'GET', '/api/v1/videos')).json.data.length, 0); } finally { await second.stop(); }
  });
});

describe('VidTube server limits', () => {
  it('rate-limits repeated sign-in attempts', async () => {
    const server = await startServer({ AUTH_RATE_LIMIT: '4' });
    try {
      const statuses = [];
      for (let i = 0; i < 6; i += 1) {
        statuses.push((await request(server.base, 'POST', '/api/v1/auth/login', { json: { email: 'nobody@example.com', password: 'wrong-password-1' } })).status);
      }
      assert.deepEqual(statuses, [401, 401, 401, 401, 429, 429]);
    } finally { await server.stop(); }
  });

  it('does not make anyone an admin automatically in production mode, but supports the setup code', async () => {
    const server = await startServer({ NODE_ENV: 'production', JWT_SECRET: 'x'.repeat(40), BOOTSTRAP_ADMIN_EMAIL: 'boss@example.com', BOOTSTRAP_ADMIN_TOKEN: 'setup-code-123456' });
    try {
      const first = await register(server.base);
      assert.equal(first.user.role, 'user');
      const wrong = await register(server.base, { email: 'boss@example.com', adminSetupToken: 'wrong' });
      assert.equal(wrong.user.role, 'user');
      const boss = await register(server.base, { email: 'boss2@example.com' });
      assert.equal(boss.user.role, 'user');
    } finally { await server.stop(); }
    const second = await startServer({ NODE_ENV: 'production', JWT_SECRET: 'x'.repeat(40), BOOTSTRAP_ADMIN_EMAIL: 'boss@example.com', BOOTSTRAP_ADMIN_TOKEN: 'setup-code-123456' });
    try {
      const boss = await register(second.base, { email: 'boss@example.com', adminSetupToken: 'setup-code-123456' });
      assert.equal(boss.user.role, 'admin');
    } finally { await second.stop(); }
  });

  it('keeps accounts, logins and videos after a restart', async () => {
    const first = await startServer();
    const user = await register(first.base);
    const up = await upload(first.base, user.token, REAL_VIDEO, { title: 'Survives restarts' });
    assert.equal(up.status, 201);
    await first.stop({ keepData: true });
    const second = await startServer({}, { reuseDir: first.dataDir });
    try {
      const me = await request(second.base, 'GET', '/api/v1/auth/me', { token: user.token });
      assert.equal(me.status, 200, 'the old login token still works (same secret)');
      const list = await request(second.base, 'GET', '/api/v1/videos');
      assert.equal(list.json.data[0].title, 'Survives restarts');
      const stream = await request(second.base, 'GET', list.json.data[0].stream_url);
      assert.ok(stream.buffer.equals(REAL_VIDEO));
    } finally {
      await second.stop();
    }
  });
});
