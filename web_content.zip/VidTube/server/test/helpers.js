'use strict';
// Test helpers: start a real VidTube server in a temp folder and talk to it over HTTP.

const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const SERVER_DIR = path.resolve(__dirname, '..');

async function startServer(extraEnv = {}, { reuseDir } = {}) {
  const dataDir = reuseDir || fs.mkdtempSync(path.join(os.tmpdir(), 'vidtube-test-'));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['server.js'], {
    cwd: SERVER_DIR,
    env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', DATA_DIR: dataDir, NODE_ENV: 'development', SEED_DEMO: '0', ...extraEnv },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  const base = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Server did not start in time. Output so far:\n${output}`)), 15000);
    const onData = (chunk) => {
      output += chunk.toString();
      const match = /On this computer:\s+(http:\/\/localhost:\d+)/.exec(output);
      if (match) { clearTimeout(timer); resolve(match[1]); }
    };
    child.stdout.on('data', onData);
    child.stderr.on('data', (chunk) => { output += chunk.toString(); });
    child.on('exit', (code) => { clearTimeout(timer); reject(new Error(`Server exited early (${code}). Output:\n${output}`)); });
  });
  return {
    base,
    dataDir,
    uploadDir: path.join(dataDir, 'uploads'),
    log: () => output,
    async stop({ keepData = false } = {}) {
      child.kill('SIGTERM');
      await new Promise((resolve) => { child.once('exit', resolve); setTimeout(resolve, 3000); });
      if (!keepData) fs.rmSync(dataDir, { recursive: true, force: true });
    }
  };
}

async function request(base, method, url, { token, json, body, headers = {} } = {}) {
  const init = { method, headers: { ...headers } };
  if (token) init.headers.Authorization = `Bearer ${token}`;
  if (json !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(json); }
  if (body !== undefined) init.body = body;
  const res = await fetch(base + url, init);
  const buffer = Buffer.from(await res.arrayBuffer());
  let parsed = null;
  if ((res.headers.get('content-type') || '').includes('application/json') && buffer.length) parsed = JSON.parse(buffer.toString('utf8'));
  return { status: res.status, headers: res.headers, buffer, json: parsed };
}

let counter = 0;
async function register(base, overrides = {}) {
  counter += 1;
  const n = `${Date.now().toString(36)}${counter}`;
  const input = {
    email: `user${n}@example.com`, username: `user_${n}`, displayName: `User ${n}`,
    password: 'a-long-password-123', acceptTerms: true, ...overrides
  };
  const res = await request(base, 'POST', '/api/v1/auth/register', { json: input });
  if (res.status !== 201) throw new Error(`register failed: ${res.status} ${res.buffer.toString()}`);
  return { ...res.json.data, input };
}

const fakeVideo = (size) => {
  const buffer = Buffer.alloc(size, 7);
  Buffer.from([0x1a, 0x45, 0xdf, 0xa3]).copy(buffer, 0);
  return buffer;
};

async function upload(base, token, buffer, fields = {}, headers = {}) {
  const query = new URLSearchParams({ title: 'My test video', description: 'About it', category: 'Coding', visibility: 'public', duration: '4', filename: 'clip.webm', ...fields });
  return request(base, 'POST', `/api/v1/videos/upload?${query}`, { token, body: buffer, headers: { 'Content-Type': 'video/webm', ...headers } });
}

module.exports = { startServer, request, register, upload, fakeVideo, SERVER_DIR };
