'use strict';
// Removes the two sample videos (and their "VidTube Team" account) that come with a new server.
//   node remove-samples.js      (stop the server first)
const database = require('./src/db');
const { removeUserAccount } = require('./src/app');

(async () => {
  const team = database.get("SELECT id FROM users WHERE email = 'team@vidtube.local'");
  if (!team) console.log('There are no sample videos to remove.');
  else { await removeUserAccount(team.id); console.log('The sample videos were removed.'); }
  database.close();
})();
