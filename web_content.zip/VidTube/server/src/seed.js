'use strict';
// First start only: puts two small sample videos on an empty server so the app is not blank.
// Delete them any time (sign in as the administrator and use the Studio tab). Turn off with SEED_DEMO=0.

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const config = require('./config');
const { get, run, transaction } = require('./db');
const auth = require('./auth');

const SAMPLES = [
  // The first one inserted is the oldest, so it shows up last in the "newest" list.
  { file: 'uploading.webm', thumb: 'uploading.jpg', title: 'How uploading works', category: 'Tutorials', duration: 3, views: 3,
    description: 'Open Studio, choose a video file, add a title and tap Upload. A picture from your video is used as the thumbnail.' },
  { file: 'welcome.webm', thumb: 'welcome.jpg', title: 'Welcome to VidTube', category: 'Tech', duration: 4, views: 7,
    description: 'A short sample clip that comes with VidTube so you can see streaming work. Create an account to like, comment, subscribe and upload your own videos.' }
];

async function seedDemoContent() {
  if (!config.seedDemo) return;
  if (get('SELECT COUNT(*) AS n FROM users').n > 0 || get('SELECT COUNT(*) AS n FROM videos').n > 0) return;
  const dir = path.join(config.root, 'samples');
  if (!SAMPLES.every((s) => fs.existsSync(path.join(dir, s.file)) && fs.existsSync(path.join(dir, s.thumb)))) return;

  const passwordHash = await auth.hashPassword(crypto.randomBytes(24).toString('hex')); // nobody signs in as this account
  const userId = crypto.randomUUID();
  const channelId = crypto.randomUUID();
  const copied = SAMPLES.map((sample) => {
    const storageKey = `${crypto.randomUUID()}.webm`;
    const thumbKey = `thumb-${crypto.randomUUID()}.jpg`;
    fs.copyFileSync(path.join(dir, sample.file), path.join(config.uploadDir, storageKey));
    fs.copyFileSync(path.join(dir, sample.thumb), path.join(config.uploadDir, thumbKey));
    return { ...sample, storageKey, thumbKey, size: fs.statSync(path.join(dir, sample.file)).size };
  });
  transaction(() => {
    run('INSERT INTO users (id, email, username, display_name, password_hash, role, terms_accepted_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      userId, 'team@vidtube.local', 'vidtube_team', 'VidTube Team', passwordHash, 'user', new Date().toISOString());
    run('INSERT INTO channels (id, user_id, handle, display_name, description) VALUES (?, ?, ?, ?, ?)',
      channelId, userId, 'vidtube_team', 'VidTube Team', 'Sample videos that come with your VidTube server.');
    for (const sample of copied) {
      run(`INSERT INTO videos (id, channel_id, title, description, category, visibility, duration_seconds, original_filename, storage_key, thumb_key, mime_type, file_size, status, view_count)
           VALUES (?, ?, ?, ?, ?, 'public', ?, ?, ?, ?, 'video/webm', ?, 'ready', ?)`,
      crypto.randomUUID(), channelId, sample.title, sample.description, sample.category, sample.duration, sample.file, sample.storageKey, sample.thumbKey, sample.size, sample.views);
    }
  });
}

module.exports = { seedDemoContent };
