'use strict';
// Helpers for video and thumbnail files.

const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { HttpError } = require('./http');

const VIDEO_MIME_TYPES = new Set([
  'video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska',
  'video/3gpp', 'video/ogg', 'application/octet-stream'
]);
const VIDEO_EXTENSIONS = new Set(['.mp4', '.m4v', '.webm', '.mov', '.mkv', '.3gp', '.ogv']);
const MIME_BY_EXTENSION = { '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.mkv': 'video/x-matroska', '.3gp': 'video/3gpp', '.ogv': 'video/ogg' };

function safeExtension(filename) {
  const ext = path.extname(filename || '').toLowerCase();
  return VIDEO_EXTENSIONS.has(ext) ? ext : '.video';
}

const makeStorageName = (originalName) => `${crypto.randomUUID()}${safeExtension(originalName)}`;

function normalizedVideoMime(mimeType, originalName) {
  const clean = String(mimeType || '').split(';')[0].trim().toLowerCase();
  if (clean === 'video/x-m4v') return 'video/mp4';
  if (clean && clean !== 'application/octet-stream') return VIDEO_MIME_TYPES.has(clean) ? clean : null;
  return MIME_BY_EXTENSION[safeExtension(originalName)] || null;
}

// Cheap check that the first bytes really belong to a video container (MP4/MOV/3GP, WebM/MKV or Ogg).
function looksLikeVideo(head) {
  if (!head || head.length < 12) return false;
  if (head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3) return true; // WebM / Matroska
  if (head.toString('latin1', 0, 4) === 'OggS') return true;
  const box = head.toString('latin1', 4, 8);
  return ['ftyp', 'moov', 'mdat', 'free', 'skip', 'wide', 'pnot'].includes(box);
}

// Returns the file extension for JPEG/PNG/WebP data, or null.
function imageKind(head) {
  if (!head || head.length < 12) return null;
  if (head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff) return { ext: '.jpg', mime: 'image/jpeg' };
  if (head.toString('latin1', 1, 4) === 'PNG' && head[0] === 0x89) return { ext: '.png', mime: 'image/png' };
  if (head.toString('latin1', 0, 4) === 'RIFF' && head.toString('latin1', 8, 12) === 'WEBP') return { ext: '.webp', mime: 'image/webp' };
  return null;
}

function parseByteRange(header, fileSize) {
  if (!header) return null;
  const match = /^bytes=(\d*)-(\d*)$/.exec(String(header).trim());
  if (!match || (!match[1] && !match[2])) return { invalid: true };
  let start;
  let end;
  if (!match[1]) {
    const suffixLength = Number(match[2]);
    if (!Number.isSafeInteger(suffixLength) || suffixLength <= 0) return { invalid: true };
    start = Math.max(0, fileSize - suffixLength);
    end = fileSize - 1;
  } else {
    start = Number(match[1]);
    end = match[2] ? Number(match[2]) : fileSize - 1;
  }
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= fileSize || end < start) return { invalid: true };
  return { start, end: Math.min(end, fileSize - 1) };
}

function resolveStoragePath(root, storageKey) {
  const resolvedRoot = path.resolve(root);
  const resolvedFile = path.resolve(resolvedRoot, storageKey);
  if (!resolvedFile.startsWith(`${resolvedRoot}${path.sep}`)) throw new HttpError(400, 'INVALID_STORAGE_KEY', 'Invalid media storage key.');
  return resolvedFile;
}

async function removeFile(filePath) {
  if (!filePath) return;
  try { await fs.promises.unlink(filePath); } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

async function readHead(filePath, bytes = 16) {
  const handle = await fs.promises.open(filePath, 'r');
  try {
    const buffer = Buffer.alloc(bytes);
    const { bytesRead } = await handle.read(buffer, 0, bytes, 0);
    return buffer.subarray(0, bytesRead);
  } finally {
    await handle.close();
  }
}

module.exports = { VIDEO_MIME_TYPES, VIDEO_EXTENSIONS, safeExtension, makeStorageName, normalizedVideoMime, looksLikeVideo, imageKind, parseByteRange, resolveStoragePath, removeFile, readHead };
