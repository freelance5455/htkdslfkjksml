'use strict';
// Small input checks (no libraries). Each function returns clean values or throws a 400 with a clear message.

const { HttpError } = require('./http');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isUuid = (value) => typeof value === 'string' && UUID.test(value);

class Problems {
  constructor() { this.list = []; }
  add(field, message) { this.list.push({ field, message }); }
  done(clean) {
    if (!this.list.length) return clean;
    throw new HttpError(400, 'VALIDATION_ERROR', this.list[0].message, this.list);
  }
}

function text(problems, input, field, { label, min = 0, max, optional = false, fallback = '', pattern, patternMessage, lower = false, trim = true }) {
  let value = input[field];
  if (value === undefined || value === null || value === '') {
    if (optional) return fallback;
    problems.add(field, `${label} is required.`);
    return '';
  }
  if (typeof value !== 'string') { problems.add(field, `${label} must be text.`); return ''; }
  if (trim) value = value.trim();
  if (value.length < min) { problems.add(field, min === 1 ? `${label} is required.` : `${label} must be at least ${min} characters.`); return ''; }
  if (max && value.length > max) { problems.add(field, `${label} must be at most ${max} characters.`); return ''; }
  if (pattern && !pattern.test(value)) { problems.add(field, patternMessage || `${label} is not valid.`); return ''; }
  return lower ? value.toLowerCase() : value;
}

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const VISIBILITY = ['public', 'unlisted', 'private'];

function email(problems, input, field = 'email') {
  return text(problems, input, field, { label: 'Email', min: 1, max: 254, pattern: EMAIL, patternMessage: 'Enter a valid email address.', lower: true });
}

function register(body) {
  const p = new Problems();
  const clean = {
    email: email(p, body),
    username: text(p, body, 'username', { label: 'Username', min: 3, max: 24, pattern: /^[a-zA-Z0-9_]+$/, patternMessage: 'Username can use letters, numbers and underscores only.' }),
    displayName: text(p, body, 'displayName', { label: 'Display name', min: 2, max: 40 }),
    password: text(p, body, 'password', { label: 'Password', min: 10, max: 128, trim: false }),
    adminSetupToken: text(p, body, 'adminSetupToken', { label: 'Admin setup code', max: 256, optional: true })
  };
  if (clean.email.endsWith('@vidtube.local')) p.add('email', 'That email address is reserved. Use your own email.');
  if (body.acceptTerms !== true) p.add('acceptTerms', 'You must accept the Terms of Use and Privacy Policy to create an account.');
  return p.done(clean);
}

function login(body) {
  const p = new Problems();
  return p.done({ email: email(p, body), password: text(p, body, 'password', { label: 'Password', min: 1, max: 128, trim: false }) });
}

function profile(body) {
  const p = new Problems();
  const clean = {};
  if (body.displayName !== undefined) clean.displayName = text(p, body, 'displayName', { label: 'Display name', min: 2, max: 40 });
  if (body.description !== undefined) clean.description = text(p, body, 'description', { label: 'Description', max: 500, optional: true });
  if (!Object.keys(clean).length) p.add('body', 'Provide at least one field to update.');
  return p.done(clean);
}

function visibility(p, input, optional) {
  const value = input.visibility;
  if (value === undefined || value === null || value === '') return optional ? undefined : 'public';
  if (!VISIBILITY.includes(value)) { p.add('visibility', 'Visibility must be public, unlisted or private.'); return 'public'; }
  return value;
}

// Fields come from the upload URL's query string (all strings).
function videoUpload(input) {
  const p = new Problems();
  const duration = input.duration === undefined || input.duration === '' ? 0 : Number(input.duration);
  if (!Number.isFinite(duration) || duration < 0 || duration > 86_400) p.add('duration', 'Duration is not valid.');
  return p.done({
    title: text(p, input, 'title', { label: 'Title', min: 1, max: 120 }),
    description: text(p, input, 'description', { label: 'Description', max: 5000, optional: true }),
    category: text(p, input, 'category', { label: 'Category', min: 1, max: 40, optional: true, fallback: 'Other' }),
    visibility: visibility(p, input, false),
    duration: Number.isFinite(duration) ? duration : 0
  });
}

function videoPatch(body) {
  const p = new Problems();
  const clean = {};
  if (body.title !== undefined) clean.title = text(p, body, 'title', { label: 'Title', min: 1, max: 120 });
  if (body.description !== undefined) clean.description = text(p, body, 'description', { label: 'Description', max: 5000, optional: true });
  if (body.category !== undefined) clean.category = text(p, body, 'category', { label: 'Category', min: 1, max: 40 });
  if (body.visibility !== undefined) clean.visibility = visibility(p, body, true);
  if (!Object.keys(clean).length) p.add('body', 'Provide at least one field to update.');
  return p.done(clean);
}

function comment(body) {
  const p = new Problems();
  const clean = { body: text(p, body, 'body', { label: 'Comment', min: 1, max: 1000 }), parentId: null };
  if (body.parentId !== undefined && body.parentId !== null) {
    if (isUuid(body.parentId)) clean.parentId = body.parentId; else p.add('parentId', 'The reply target is not valid.');
  }
  return p.done(clean);
}

function like(body) {
  const p = new Problems();
  if (![-1, 0, 1].includes(body.value)) p.add('value', 'Value must be -1, 0 or 1.');
  return p.done({ value: body.value });
}

function report(body) {
  const p = new Problems();
  return p.done({ reason: text(p, body, 'reason', { label: 'Reason', max: 300, optional: true }) });
}

function reportStatus(body) {
  const p = new Problems();
  if (!['reviewed', 'dismissed'].includes(body.status)) p.add('status', 'Status must be reviewed or dismissed.');
  return p.done({ status: body.status });
}

function deleteAccount(body) {
  const p = new Problems();
  return p.done({ password: text(p, body, 'password', { label: 'Password', min: 1, max: 128, trim: false }) });
}

module.exports = { isUuid, register, login, profile, videoUpload, videoPatch, comment, like, report, reportStatus, deleteAccount };
