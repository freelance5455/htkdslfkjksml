'use strict';
// All settings in one place. Nothing here is required: VidTube runs with zero configuration.

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');

// Minimal .env reader (so no "dotenv" package is needed). Real environment variables win.
function loadEnvFile(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch (_) { return; }
  for (const line of text.split(/\r?\n/)) {
    if (/^\s*#/.test(line)) continue;
    const m = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (!m) continue;
    let value = m[2];
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = value;
  }
}
loadEnvFile(path.join(ROOT, '.env'));

const env = process.env;
const MB = 1024 * 1024;
const nodeEnv = env.NODE_ENV || 'development';
const isProduction = nodeEnv === 'production';

function positiveInt(name, fallback, max = Number.MAX_SAFE_INTEGER) {
  const raw = env[name];
  const value = raw === undefined || raw === '' ? fallback : Number(raw);
  if (!Number.isSafeInteger(value) || value < 1 || value > max) throw new Error(`${name} must be a whole number between 1 and ${max}.`);
  return value;
}
function flag(name, fallback) {
  const raw = (env[name] || '').trim().toLowerCase();
  if (!raw) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(raw);
}
function durationSeconds(text, fallback) {
  const m = /^(\d+)\s*([smhd]?)$/.exec(String(text || '').trim());
  if (!m) return fallback;
  return Number(m[1]) * ({ s: 1, m: 60, h: 3600, d: 86400 }[m[2] || 's']);
}

const dataDir = path.resolve(ROOT, env.DATA_DIR || 'data');
const uploadDir = path.resolve(ROOT, env.UPLOAD_DIR || path.join(dataDir, 'uploads'));
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

// The signing secret is created once and kept in the data folder, so logins survive restarts.
function loadSecret() {
  if (env.JWT_SECRET) {
    if (isProduction && env.JWT_SECRET.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters in production.');
    return env.JWT_SECRET;
  }
  const file = path.join(dataDir, 'jwt-secret.txt');
  try {
    const existing = fs.readFileSync(file, 'utf8').trim();
    if (existing.length >= 32) return existing;
  } catch (_) { /* create below */ }
  const secret = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(file, secret, { mode: 0o600 });
  return secret;
}

const config = {
  root: ROOT,
  publicDir: path.join(ROOT, 'public'),
  nodeEnv,
  isProduction,
  port: positiveInt('PORT', 4000, 65535),
  host: env.HOST || '0.0.0.0',
  dataDir,
  uploadDir,
  dbFile: path.join(dataDir, 'vidtube.sqlite'),
  jwtSecret: loadSecret(),
  jwtExpiresInSeconds: durationSeconds(env.JWT_EXPIRES_IN, 7 * 86400),
  maxUploadBytes: positiveInt('MAX_UPLOAD_BYTES', 50 * MB),
  storageQuotaBytes: positiveInt('STORAGE_QUOTA_BYTES', 50 * MB),
  maxThumbnailBytes: 512 * 1024,
  authRateLimit: positiveInt('AUTH_RATE_LIMIT', 30),
  apiRateLimit: positiveInt('API_RATE_LIMIT', 900),
  corsOrigins: (env.CORS_ORIGIN || '*').split(',').map((v) => v.trim()).filter(Boolean),
  trustProxy: (env.TRUST_PROXY || '0').trim().toLowerCase(),
  bootstrapAdminEmail: (env.BOOTSTRAP_ADMIN_EMAIL || '').trim().toLowerCase(),
  bootstrapAdminToken: env.BOOTSTRAP_ADMIN_TOKEN || '',
  // On your own computer the first account you create becomes the administrator (moderation screen).
  // Switched off automatically in production; set FIRST_USER_IS_ADMIN=1 to force it on.
  firstUserIsAdmin: flag('FIRST_USER_IS_ADMIN', !isProduction),
  // Two small sample videos on a brand-new server (development default; switch with SEED_DEMO=0 or 1).
  seedDemo: flag('SEED_DEMO', !isProduction),
  operatorName: (env.OPERATOR_NAME || 'the VidTube operator').trim(),
  contactEmail: (env.CONTACT_EMAIL || '').trim()
};

module.exports = config;
