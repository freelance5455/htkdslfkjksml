'use strict';

function remainingBytes(used, limit) {
  return Math.max(0, Number(limit) - Number(used));
}

function fitsQuota(used, incoming, limit) {
  return Number.isFinite(incoming) && incoming > 0 && Number(used) + incoming <= Number(limit);
}

// Cheap early rejection from the Content-Length header (multipart framing adds a little overhead).
function declaredUploadTooLarge(contentLength, remaining, slack = 64 * 1024) {
  return Number.isFinite(contentLength) && contentLength - slack > remaining;
}

function formatBytes(bytes) {
  const value = Number(bytes) || 0;
  if (value >= 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  if (value >= 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${value} B`;
}

module.exports = { remainingBytes, fitsQuota, declaredUploadTooLarge, formatBytes };
