'use strict';
// Starting-point Terms of Use, Privacy Policy and account-deletion pages, served at /legal/*.
// They describe what THIS software does. They are not legal advice: have them reviewed for your
// jurisdiction, edit the wording to match how you really operate, and keep the date below current.

const config = require('./config');

const UPDATED = '7 November 2026';
const esc = (value) => String(value).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function contact() {
  return config.contactEmail ? `<a href="mailto:${esc(config.contactEmail)}">${esc(config.contactEmail)}</a>` : '<em>(the operator has not set CONTACT_EMAIL yet)</em>';
}

function page(title, body) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} – VidTube</title><style>body{font:16px/1.55 system-ui,sans-serif;max-width:720px;margin:0 auto;padding:20px;color:#1b1b1f}h1{font-size:26px;margin-bottom:4px}h2{font-size:19px;margin-top:26px}a{color:#0b57d0}.u{color:#555;font-size:14px}</style></head><body><h1>${esc(title)}</h1><p class="u">Last updated: ${UPDATED}</p>${body}</body></html>`;
}

function terms() {
  const op = esc(config.operatorName);
  return page('Terms of Use', `
<p>These terms apply to the VidTube app and service operated by ${op} (“we”, “us”). By creating an account or using the service you agree to them.</p>
<h2>Your account</h2><p>Give accurate information, keep your password secret and tell us if you think someone else has used your account. You must be at least 13 years old, or older if the law where you live requires it. You are responsible for everything done through your account.</p>
<h2>Your content</h2><p>You keep ownership of what you upload and post. You give us permission to store, copy, stream and display it as needed to run the service (for example to show your public videos and comments to other people). Only upload or post content you have the right to share.</p>
<h2>What is not allowed</h2><ul>
<li>Anything illegal, or content that sexualises or endangers minors (we report this to the authorities).</li>
<li>Pornography or sexually explicit material.</li>
<li>Harassment, bullying, threats, hate speech or discrimination.</li>
<li>Graphic violence, or content that encourages self-harm, dangerous acts or terrorism.</li>
<li>Spam, scams, malware, or attempts to disrupt or break into the service.</li>
<li>Content that infringes copyright, trademarks or privacy, or that impersonates someone else.</li>
</ul>
<h2>Reporting, blocking and moderation</h2><p>You can report videos, channels and comments inside the app and block any user so you no longer see their videos or comments. We review reports and may remove content or suspend or delete accounts that break these terms, with or without notice.</p>
<h2>Storage limits</h2><p>Uploads are limited in size and each account has a total storage allowance, shown in Creator Studio. We may remove content that exceeds the limits.</p>
<h2>Ending your account</h2><p>You can delete your account at any time in the app (see the <a href="/legal/delete-account">account deletion page</a>). We may suspend or remove accounts that break these terms.</p>
<h2>Disclaimer</h2><p>The service is provided “as is”. To the extent the law allows, we are not liable for losses caused by using or being unable to use the service, or by content posted by users.</p>
<h2>Changes and contact</h2><p>We may update these terms; continued use after a change means you accept it. Questions or complaints: ${contact()}.</p>`);
}

function privacy() {
  const op = esc(config.operatorName);
  return page('Privacy Policy', `
<p>This policy explains what personal data the VidTube app and service, operated by ${op}, collects and how it is used. Contact: ${contact()}.</p>
<h2>What we collect</h2><ul>
<li><b>Account data:</b> email address, username, display name, and your password stored only as a salted one-way hash. We also record when you accepted the Terms of Use.</li>
<li><b>Content you create:</b> videos you upload (with title, description, category and visibility), comments, likes and dislikes, subscriptions, reports you send and the users you block.</li>
<li><b>Technical data:</b> your IP address and device/browser identifier are processed to protect the service (rate limiting). For people who are not signed in, a one-way hash of them is stored so a video view is counted once per day; signed-in views are counted per account.</li>
<li><b>On your device:</b> the app stores your sign-in token (encrypted with the Android Keystore) and the server address you entered.</li>
</ul>
<p>The app does not contain advertising or analytics software, and we do not sell personal data.</p>
<h2>How we use it</h2><p>To run your account, store and stream your videos, show your public content, enforce storage limits and the Terms of Use, moderate reports and keep the service secure.</p>
<h2>What other people can see</h2><p>Public videos, your display name, channel name and comments are visible to everyone. Unlisted videos are viewable by anyone who has the link. Private videos are visible only to you. Your email address is never shown to other users.</p>
<h2>Sharing</h2><p>We share data only with the hosting providers that run the service for us, and with authorities when the law requires it.</p>
<h2>Retention and deletion</h2><p>We keep your data while your account exists. You can delete your account in the app at any time; this permanently removes your account, channel, videos and their files, comments, likes, subscriptions and blocks. Backups, if any, are overwritten on their normal schedule. See the <a href="/legal/delete-account">account deletion page</a>.</p>
<h2>Security</h2><p>Data is sent over HTTPS when the server is deployed with HTTPS, and passwords are hashed. No system is perfectly secure, so please use a strong, unique password.</p>
<h2>Children</h2><p>The service is not directed to children under 13 and we do not knowingly collect their data. If you believe a child has an account, contact us and we will delete it.</p>
<h2>Your rights</h2><p>You can change your display name in the app, delete your account, and ask us for a copy of your data or a correction by writing to ${contact()}.</p>
<h2>Changes</h2><p>If we change this policy we will update the date above.</p>`);
}

function deleteAccount() {
  return page('Delete your account', `
<p>You can permanently delete your VidTube account and its data yourself:</p>
<ol><li>Open the VidTube app and tap the account button.</li><li>Sign in, then type your password in the <b>Password</b> field.</li><li>Tap <b>Delete account</b> and confirm.</li></ol>
<p><b>What is deleted:</b> your account, channel, uploaded videos and their files, comments, likes, subscriptions, reports you sent and users you blocked.</p>
<p><b>What is kept:</b> nothing that identifies you, except backups, if any, which are overwritten on their normal schedule.</p>
<p>If you can no longer open the app, email ${contact()} from the address registered on the account and ask us to delete it. We will verify the request and delete the account promptly.</p>`);
}

module.exports = { terms, privacy, deleteAccount };
