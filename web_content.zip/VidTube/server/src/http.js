'use strict';
// Tiny web framework (routing, JSON bodies, CORS, rate limits, static files) built on Node's own http module.

const fs = require('node:fs');
const path = require('node:path');
const config = require('./config');

class HttpError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

const notFoundError = () => new HttpError(404, 'NOT_FOUND', 'The requested resource was not found.');

// ---------- responses ----------
function sendJson(res, status, body) {
  const text = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(text),
    'Cache-Control': 'no-store'
  });
  res.end(text);
}

function sendError(res, error) {
  let status = 500;
  let body = { error: { code: 'INTERNAL_ERROR', message: 'Something went wrong. Please try again.' } };
  if (error instanceof HttpError) {
    status = error.status;
    body = { error: { code: error.code, message: error.message } };
    if (error.details) body.error.details = error.details;
  } else if (error && /UNIQUE constraint failed/i.test(String(error.message))) {
    status = 409;
    body = { error: { code: 'ALREADY_EXISTS', message: 'That email, username or channel handle is already in use.' } };
  } else {
    console.error('Unhandled request error:', error && error.stack ? error.stack : error);
  }
  if (res.headersSent) { res.destroy(); return; }
  sendJson(res, status, body);
}

// ---------- request bodies ----------
function readBuffer(req, limit, tooLarge) {
  return new Promise((resolve, reject) => {
    const overflow = () => (tooLarge ? tooLarge() : new HttpError(413, 'PAYLOAD_TOO_LARGE', 'The request body is too large.'));
    const declared = Number(req.headers['content-length']);
    if (Number.isFinite(declared) && declared > limit) { reject(overflow()); return; }
    const chunks = [];
    let size = 0;
    let failed = false;
    req.on('data', (chunk) => {
      if (failed) return;
      size += chunk.length;
      if (size > limit) { failed = true; chunks.length = 0; reject(overflow()); return; }
      chunks.push(chunk);
    });
    req.on('error', (error) => { if (!failed) { failed = true; reject(error); } });
    req.on('aborted', () => { if (!failed) { failed = true; reject(new HttpError(400, 'REQUEST_ABORTED', 'The request was cancelled.')); } });
    req.on('end', () => { if (!failed) resolve(Buffer.concat(chunks)); });
  });
}

async function readJsonBody(req, limit = 2 * 1024 * 1024) {
  const text = (await readBuffer(req, limit)).toString('utf8').trim();
  if (!text) return {};
  try {
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('not an object');
    return parsed;
  } catch (_) {
    throw new HttpError(400, 'INVALID_JSON', 'The request body is not valid JSON.');
  }
}

// ---------- router ----------
class Router {
  constructor() { this.routes = []; }

  add(method, pattern, ...handlers) {
    this.routes.push({ method, parts: pattern.split('/').filter(Boolean), handlers });
  }

  find(method, pathname) {
    const wanted = method === 'HEAD' ? 'GET' : method;
    const segments = pathname.split('/').filter(Boolean);
    for (const route of this.routes) {
      if (route.method !== wanted || route.parts.length !== segments.length) continue;
      const params = {};
      let ok = true;
      for (let i = 0; i < segments.length && ok; i += 1) {
        const part = route.parts[i];
        if (part.startsWith(':')) {
          try { params[part.slice(1)] = decodeURIComponent(segments[i]); } catch (_) { ok = false; }
        } else if (part !== segments[i]) {
          ok = false;
        }
      }
      if (ok) return { route, params };
    }
    return null;
  }
}

// ---------- client address and rate limiting ----------
function clientIp(req) {
  const direct = String(req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  const mode = config.trustProxy;
  if (mode === '0' || mode === 'false' || mode === '') return direct;
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',').map((v) => v.trim()).filter(Boolean);
  if (!forwarded.length) return direct;
  if (mode === 'true') return forwarded[0];
  const hops = Number(mode);
  if (Number.isInteger(hops) && hops > 0) return forwarded[Math.max(0, forwarded.length - hops)];
  return direct;
}

function rateLimiter({ windowMs, limit, message, skip }) {
  const hits = new Map();
  const timer = setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of hits) if (entry.resetAt <= now) hits.delete(key);
  }, Math.min(windowMs, 60_000));
  timer.unref();
  return (req, res) => {
    if (skip && skip(req)) return;
    const key = clientIp(req);
    const now = Date.now();
    let entry = hits.get(key);
    if (!entry || entry.resetAt <= now) { entry = { count: 0, resetAt: now + windowMs }; hits.set(key, entry); }
    entry.count += 1;
    if (entry.count > limit) {
      res.setHeader('Retry-After', String(Math.max(1, Math.ceil((entry.resetAt - now) / 1000))));
      throw new HttpError(429, 'RATE_LIMITED', message || 'Too many requests. Please slow down and try again shortly.');
    }
  };
}

// ---------- security headers and CORS ----------
const PAGE_CSP = [
  "default-src 'self'", "script-src 'self' 'unsafe-inline'", "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:", "media-src 'self' blob:", "font-src 'self' data:", "connect-src 'self'",
  "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'self'", "worker-src 'self'", "manifest-src 'self'"
].join('; ');

function setSecurityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
}

// Returns true when the request may proceed. Adds CORS headers for allowed browser origins.
function applyCors(req, res) {
  const origin = req.headers.origin;
  if (!origin) return true;
  const wildcard = config.corsOrigins.includes('*');
  let sameHost = false;
  try { sameHost = new URL(origin).host === req.headers.host; } catch (_) { /* invalid origin header */ }
  if (!wildcard && !sameHost && !config.corsOrigins.includes(origin)) return false;
  res.setHeader('Access-Control-Allow-Origin', wildcard ? '*' : origin);
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Expose-Headers', 'Accept-Ranges, Content-Length, Content-Range');
  return true;
}

function answerPreflight(req, res) {
  res.writeHead(204, {
    'Access-Control-Allow-Methods': 'GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, Range',
    'Access-Control-Max-Age': '600',
    ...(req.headers['access-control-request-private-network'] ? { 'Access-Control-Allow-Private-Network': 'true' } : {}),
    'Content-Length': '0'
  });
  res.end();
}

// ---------- static files (the web app) ----------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.webp': 'image/webp', '.txt': 'text/plain; charset=utf-8'
};

async function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') throw notFoundError();
  let relative;
  try { relative = decodeURIComponent(pathname === '/' ? '/index.html' : pathname); } catch (_) { throw notFoundError(); }
  if (relative.includes('\0')) throw notFoundError();
  const root = path.resolve(config.publicDir);
  const file = path.resolve(root, `.${relative}`);
  if (file !== root && !file.startsWith(root + path.sep)) throw notFoundError();
  let stat;
  try { stat = await fs.promises.stat(file); } catch (_) { throw notFoundError(); }
  if (!stat.isFile()) throw notFoundError();
  const ext = path.extname(file).toLowerCase();
  const type = MIME[ext] || 'application/octet-stream';
  const etag = `W/"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
  const headers = {
    'Content-Type': type,
    'Content-Length': stat.size,
    ETag: etag,
    // Pages and scripts are always re-checked so an updated server never serves a stale app.
    'Cache-Control': ['.html', '.js', '.webmanifest'].includes(ext) ? 'no-cache' : 'public, max-age=86400'
  };
  if (ext === '.html') headers['Content-Security-Policy'] = PAGE_CSP;
  if (path.basename(file) === 'sw.js') headers['Service-Worker-Allowed'] = '/';
  if (req.headers['if-none-match'] === etag) { res.writeHead(304, { ETag: etag, 'Cache-Control': headers['Cache-Control'] }); res.end(); return; }
  res.writeHead(200, headers);
  if (req.method === 'HEAD') { res.end(); return; }
  fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
}

module.exports = {
  HttpError, notFoundError, sendJson, sendError, readBuffer, readJsonBody, Router, clientIp, rateLimiter,
  setSecurityHeaders, applyCors, answerPreflight, serveStatic
};
