'use strict';
// Passwords (scrypt) and login tokens (HS256 JWT) using only Node's built-in crypto.

const crypto = require('node:crypto');
const config = require('./config');

const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64 };

function scrypt(password, salt, params) {
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, params.keylen, { N: params.N, r: params.r, p: params.p, maxmem: 64 * 1024 * 1024 }, (error, key) => (error ? reject(error) : resolve(key)));
  });
}

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password.normalize('NFKC'), salt, SCRYPT);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${key.toString('base64')}`;
}

async function verifyPassword(password, stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const params = { N: Number(parts[1]), r: Number(parts[2]), p: Number(parts[3]), keylen: 64 };
  if (![params.N, params.r, params.p].every(Number.isSafeInteger)) return false;
  const salt = Buffer.from(parts[4], 'base64');
  const expected = Buffer.from(parts[5], 'base64');
  const actual = await scrypt(String(password).normalize('NFKC'), salt, { ...params, keylen: expected.length });
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

const b64url = (input) => Buffer.from(input).toString('base64url');

function sign(payload) {
  const head = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64url(JSON.stringify(payload));
  const sig = crypto.createHmac('sha256', config.jwtSecret).update(`${head}.${body}`).digest('base64url');
  return `${head}.${body}.${sig}`;
}

function verify(token, { audience, issuer }) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) return null;
  let header;
  let claims;
  try {
    header = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
    claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
  } catch (_) { return null; }
  if (!header || header.alg !== 'HS256') return null;
  const expected = crypto.createHmac('sha256', config.jwtSecret).update(`${parts[0]}.${parts[1]}`).digest();
  const given = Buffer.from(parts[2], 'base64url');
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;
  const now = Math.floor(Date.now() / 1000);
  if (!claims || typeof claims.exp !== 'number' || claims.exp <= now) return null;
  if (claims.iss !== issuer || claims.aud !== audience) return null;
  return claims;
}

function signAccessToken(user) {
  const now = Math.floor(Date.now() / 1000);
  return sign({ sub: user.id, role: user.role, username: user.username, iss: 'vidtube-api', aud: 'vidtube-app', iat: now, exp: now + config.jwtExpiresInSeconds });
}
const verifyAccessToken = (token) => verify(token, { issuer: 'vidtube-api', audience: 'vidtube-app' });

// Short-lived link for playing a private video (a <video> tag cannot send an Authorization header).
function createMediaTicket(videoId, ownerId) {
  const now = Math.floor(Date.now() / 1000);
  return sign({ sub: ownerId, videoId, iss: 'vidtube-api', aud: 'vidtube-media', iat: now, exp: now + 2 * 3600 });
}
function verifyMediaTicket(ticket, videoId, ownerId) {
  const claims = verify(ticket, { issuer: 'vidtube-api', audience: 'vidtube-media' });
  return Boolean(claims && claims.sub === ownerId && claims.videoId === videoId);
}

function safeEquals(provided, expected) {
  if (!provided || !expected) return false;
  const left = Buffer.from(String(provided));
  const right = Buffer.from(String(expected));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

module.exports = { hashPassword, verifyPassword, signAccessToken, verifyAccessToken, createMediaTicket, verifyMediaTicket, safeEquals };
