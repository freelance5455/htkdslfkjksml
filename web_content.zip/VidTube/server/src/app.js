'use strict';
// VidTube API + web app. Routes keep the same URLs and JSON shapes the app already uses.

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Transform } = require('node:stream');
const { pipeline } = require('node:stream/promises');
const config = require('./config');
const { get, all, run, transaction, NOW } = require('./db');
const {
  HttpError, notFoundError, sendJson, sendError, readBuffer, readJsonBody, Router, clientIp, rateLimiter,
  setSecurityHeaders, applyCors, answerPreflight, serveStatic
} = require('./http');
const auth = require('./auth');
const v = require('./validate');
const legal = require('./legal');
const media = require('./media');
const { remainingBytes, fitsQuota, formatBytes } = require('./storage');

const router = new Router();
const route = (method, pattern, ...handlers) => router.add(method, pattern, ...handlers);

// ------------------------------------------------------------------ middleware
const apiLimiter = rateLimiter({
  windowMs: 60_000,
  limit: config.apiRateLimit,
  skip: (req) => req.path.endsWith('/stream') || req.path.endsWith('/thumbnail')
});
const authLimiter = rateLimiter({ windowMs: 15 * 60_000, limit: config.authRateLimit, message: 'Too many sign-in attempts. Try again in a few minutes.' });

const json = async (req) => { req.body = await readJsonBody(req); };

function bearerToken(req) {
  const match = /^Bearer\s+(.+)$/i.exec(req.headers.authorization || '');
  return match ? match[1].trim() : null;
}

// The account is looked up on every request, so deleted accounts and role changes take effect immediately.
function userFromToken(token) {
  const claims = auth.verifyAccessToken(token);
  if (!claims) return null;
  const row = get('SELECT id, username, role FROM users WHERE id = ?', claims.sub);
  return row ? { id: row.id, username: row.username, role: row.role } : null;
}
function requireAuth(req) {
  const token = bearerToken(req);
  if (!token) throw new HttpError(401, 'AUTH_REQUIRED', 'Please sign in to continue.');
  const user = userFromToken(token);
  if (!user) throw new HttpError(401, 'INVALID_TOKEN', 'Your session has expired. Please sign in again.');
  req.user = user;
}
function optionalAuth(req) {
  const token = bearerToken(req);
  const user = token ? userFromToken(token) : null;
  if (user) req.user = user;
}
function requireAdmin(req) {
  if (!req.user || req.user.role !== 'admin') throw new HttpError(403, 'FORBIDDEN', 'Administrator permission is required.');
}

// ------------------------------------------------------------------ helpers
const uuid = () => crypto.randomUUID();
const qs = (req, name, fallback = '') => (req.query.has(name) ? req.query.get(name) : fallback);
const toInt = (value, fallback) => { const n = Number.parseInt(value, 10); return Number.isFinite(n) ? n : fallback; };

function publicUser(row) {
  return { id: row.id, email: row.email, username: row.username, display_name: row.display_name, role: row.role, created_at: row.created_at };
}

function channelHandle(input) {
  const base = String(input).toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 18) || 'creator';
  return `${base}_${crypto.randomBytes(3).toString('hex')}`;
}

function quotaError(used) {
  return new HttpError(413, 'STORAGE_QUOTA_EXCEEDED', `Storage limit reached: ${formatBytes(used)} of ${formatBytes(config.storageQuotaBytes)} used. Delete a video or choose a smaller file.`);
}
const tooLargeError = () => new HttpError(413, 'LIMIT_FILE_SIZE', `Video exceeds the upload size limit of ${formatBytes(config.maxUploadBytes)}.`);

function storageUsed(userId) {
  return Number(get(
    'SELECT COALESCE(SUM(v.file_size), 0) AS used FROM videos v JOIN channels c ON c.id = v.channel_id WHERE c.user_id = ?', userId
  ).used);
}

const VIDEO_SELECT = `
SELECT v.id, v.channel_id, v.title, v.description, v.category, v.visibility, v.duration_seconds, v.original_filename,
       v.storage_key, v.thumb_key, v.mime_type, v.file_size, v.status, v.view_count, v.created_at, v.updated_at,
       c.display_name AS channel_name, c.handle AS channel_handle, c.user_id AS owner_id, u.username AS owner_username,
       (SELECT COUNT(*) FROM video_likes vl WHERE vl.video_id = v.id AND vl.value = 1) AS like_count,
       (SELECT COUNT(*) FROM video_likes vl WHERE vl.video_id = v.id AND vl.value = -1) AS dislike_count,
       (SELECT COUNT(*) FROM comments cm WHERE cm.video_id = v.id) AS comment_count,
       (SELECT COUNT(*) FROM subscriptions s WHERE s.channel_id = c.id) AS subscriber_count,
       COALESCE((SELECT vl.value FROM video_likes vl WHERE vl.video_id = v.id AND vl.user_id = ?), 0) AS user_like
FROM videos v
JOIN channels c ON c.id = v.channel_id
JOIN users u ON u.id = c.user_id`;
// The first "?" in VIDEO_SELECT is always the viewer's user id (or null).

function serialiseVideo(row, req, withTicket = false) {
  // A <video> tag cannot send an Authorization header, so the owner's private videos carry a short-lived ticket.
  let suffix = '';
  if (withTicket && req.user && row.owner_id === req.user.id && row.visibility === 'private') {
    suffix = `?ticket=${encodeURIComponent(auth.createMediaTicket(row.id, row.owner_id))}`;
  }
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    category: row.category,
    visibility: row.visibility,
    duration_seconds: Number(row.duration_seconds),
    original_filename: row.original_filename,
    mime_type: row.mime_type,
    file_size: Number(row.file_size),
    status: row.status,
    view_count: Number(row.view_count),
    like_count: Number(row.like_count || 0),
    dislike_count: Number(row.dislike_count || 0),
    comment_count: Number(row.comment_count || 0),
    created_at: row.created_at,
    updated_at: row.updated_at,
    channel: { id: row.channel_id, name: row.channel_name, handle: row.channel_handle, subscriber_count: Number(row.subscriber_count || 0) },
    owner: { id: row.owner_id, username: row.owner_username },
    stream_url: `/api/v1/videos/${row.id}/stream${suffix}`,
    thumbnail_url: row.thumb_key ? `/api/v1/videos/${row.id}/thumbnail${suffix}` : null,
    user_like: Number(row.user_like) || 0
  };
}

const getVideo = (id, viewerId = null) => get(`${VIDEO_SELECT} WHERE v.id = ?`, viewerId, id);

function canViewVideo(video, user) {
  if (!video || video.status !== 'ready') return false;
  if (video.visibility === 'public' || video.visibility === 'unlisted') return true;
  return Boolean(user && user.id === video.owner_id);
}

async function removeMedia(...keys) {
  for (const key of keys) {
    if (!key) continue;
    try { await media.removeFile(media.resolveStoragePath(config.uploadDir, key)); } catch (error) { console.error('Could not remove file:', error.message); }
  }
}

async function removeUserAccount(userId) {
  const files = all('SELECT v.storage_key, v.thumb_key FROM videos v JOIN channels c ON c.id = v.channel_id WHERE c.user_id = ?', userId);
  run('DELETE FROM users WHERE id = ?', userId);
  for (const row of files) await removeMedia(row.storage_key, row.thumb_key);
}

// ------------------------------------------------------------------ health + legal
route('GET', '/health', (_req, res) => {
  get('SELECT 1 AS ok');
  sendJson(res, 200, { status: 'ok', service: 'vidtube-api', database: 'connected', timestamp: new Date().toISOString() });
});

route('GET', '/legal/:page', (req, res) => {
  const pages = { terms: legal.terms, privacy: legal.privacy, 'delete-account': legal.deleteAccount };
  const render = Object.hasOwn(pages, req.params.page) ? pages[req.params.page] : null;
  if (!render) throw notFoundError();
  const html = render();
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': Buffer.byteLength(html), 'Cache-Control': 'public, max-age=3600' });
  res.end(req.method === 'HEAD' ? undefined : html);
});

// ------------------------------------------------------------------ accounts
route('POST', '/api/v1/auth/register', authLimiter, json, async (req, res) => {
  const input = v.register(req.body);
  const username = input.username.toLowerCase();
  if (get('SELECT 1 AS found FROM users WHERE email = ? OR username = ?', input.email, username)) {
    throw new HttpError(409, 'ALREADY_EXISTS', 'That email or username is already in use.');
  }
  const passwordHash = await auth.hashPassword(input.password);
  const byToken = Boolean(config.bootstrapAdminEmail && input.email === config.bootstrapAdminEmail && auth.safeEquals(input.adminSetupToken, config.bootstrapAdminToken));
  const created = transaction(() => {
    const first = get("SELECT COUNT(*) AS n FROM users WHERE email NOT LIKE '%@vidtube.local'").n === 0;
    const role = byToken || (config.firstUserIsAdmin && first) ? 'admin' : 'user';
    const userId = uuid();
    run('INSERT INTO users (id, email, username, display_name, password_hash, role, terms_accepted_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      userId, input.email, username, input.displayName, passwordHash, role, new Date().toISOString());
    const channelId = uuid();
    run('INSERT INTO channels (id, user_id, handle, display_name) VALUES (?, ?, ?, ?)', channelId, userId, channelHandle(input.username), input.displayName);
    return {
      user: get('SELECT id, email, username, display_name, role, created_at FROM users WHERE id = ?', userId),
      channel: get('SELECT id, handle, display_name, description FROM channels WHERE id = ?', channelId)
    };
  });
  sendJson(res, 201, { data: { token: auth.signAccessToken(created.user), user: publicUser(created.user), channel: created.channel } });
});

// Used to make "unknown email" take as long as "wrong password".
const DUMMY_HASH = 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==';

route('POST', '/api/v1/auth/login', authLimiter, json, async (req, res) => {
  const input = v.login(req.body);
  const user = get('SELECT id, email, username, display_name, password_hash, role, created_at FROM users WHERE email = ?', input.email);
  const ok = await auth.verifyPassword(input.password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) throw new HttpError(401, 'INVALID_CREDENTIALS', 'Email or password is incorrect.');
  const channel = get('SELECT id, handle, display_name, description FROM channels WHERE user_id = ?', user.id) || null;
  sendJson(res, 200, { data: { token: auth.signAccessToken(user), user: publicUser(user), channel } });
});

route('GET', '/api/v1/auth/me', requireAuth, (req, res) => {
  const row = get(
    `SELECT u.id, u.email, u.username, u.display_name, u.role, u.created_at, c.id AS channel_id, c.handle, c.description
     FROM users u LEFT JOIN channels c ON c.user_id = u.id WHERE u.id = ?`, req.user.id
  );
  if (!row) throw new HttpError(401, 'USER_NOT_FOUND', 'This account no longer exists.');
  sendJson(res, 200, { data: { user: publicUser(row), channel: row.channel_id ? { id: row.channel_id, handle: row.handle, description: row.description, display_name: row.display_name } : null } });
});

route('PATCH', '/api/v1/auth/profile', requireAuth, json, (req, res) => {
  const input = v.profile(req.body);
  transaction(() => {
    if (input.displayName) {
      run(`UPDATE users SET display_name = ?, updated_at = ${NOW} WHERE id = ?`, input.displayName, req.user.id);
      run(`UPDATE channels SET display_name = ?, updated_at = ${NOW} WHERE user_id = ?`, input.displayName, req.user.id);
    }
    if (input.description !== undefined) run(`UPDATE channels SET description = ?, updated_at = ${NOW} WHERE user_id = ?`, input.description, req.user.id);
  });
  sendJson(res, 200, { data: { user: publicUser(get('SELECT id, email, username, display_name, role, created_at FROM users WHERE id = ?', req.user.id)) } });
});

route('DELETE', '/api/v1/auth/account', requireAuth, json, async (req, res) => {
  const { password } = v.deleteAccount(req.body);
  const found = get('SELECT password_hash FROM users WHERE id = ?', req.user.id);
  if (!found) throw new HttpError(401, 'USER_NOT_FOUND', 'This account no longer exists.');
  if (!(await auth.verifyPassword(password, found.password_hash))) throw new HttpError(401, 'INVALID_CREDENTIALS', 'Password is incorrect.');
  await removeUserAccount(req.user.id);
  res.writeHead(204); res.end();
});

// ------------------------------------------------------------------ videos: browse
route('GET', '/api/v1/videos', optionalAuth, (req, res) => {
  const q = String(qs(req, 'q')).trim().slice(0, 100);
  const category = String(qs(req, 'category')).trim().slice(0, 40);
  const sort = String(qs(req, 'sort', 'newest'));
  const page = Math.max(1, Math.min(10_000, toInt(qs(req, 'page', '1'), 1)));
  const limit = Math.max(1, Math.min(50, toInt(qs(req, 'limit', '24'), 24)));
  const where = ["v.visibility = 'public'", "v.status = 'ready'"];
  const params = [req.user ? req.user.id : null];
  if (q) {
    const like = `%${q.replace(/[\\%_]/g, '\\$&')}%`;
    where.push("(v.title LIKE ? ESCAPE '\\' OR v.description LIKE ? ESCAPE '\\' OR c.display_name LIKE ? ESCAPE '\\')");
    params.push(like, like, like);
  }
  if (category && category !== 'All') { where.push('v.category = ?'); params.push(category); }
  if (req.user) {
    where.push('NOT EXISTS (SELECT 1 FROM user_blocks ub WHERE ub.blocker_id = ? AND ub.blocked_id = c.user_id)');
    params.push(req.user.id);
  }
  const order = sort === 'popular' ? 'v.view_count DESC, v.created_at DESC'
    : sort === 'trending' ? '(v.view_count + (SELECT COUNT(*) FROM video_likes vl WHERE vl.video_id = v.id AND vl.value = 1) * 10) DESC, v.created_at DESC'
      : 'v.created_at DESC, v.rowid DESC';
  params.push(limit, (page - 1) * limit);
  const rows = all(`${VIDEO_SELECT} WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT ? OFFSET ?`, ...params);
  sendJson(res, 200, { data: rows.map((row) => serialiseVideo(row, req)), pagination: { page, limit, has_more: rows.length === limit } });
});

route('GET', '/api/v1/me/videos', requireAuth, (req, res) => {
  const rows = all(`${VIDEO_SELECT} WHERE c.user_id = ? ORDER BY v.created_at DESC, v.rowid DESC LIMIT 100`, req.user.id, req.user.id);
  sendJson(res, 200, { data: rows.map((row) => serialiseVideo(row, req, true)) });
});

route('GET', '/api/v1/videos/:id', optionalAuth, (req, res) => {
  const row = getVideo(req.params.id, req.user ? req.user.id : null);
  if (!canViewVideo(row, req.user)) throw notFoundError();
  sendJson(res, 200, { data: serialiseVideo(row, req, true) });
});

// ------------------------------------------------------------------ videos: upload
// The video file is sent as the raw request body; title etc. travel in the query string.
route('POST', '/api/v1/videos/upload', requireAuth, async (req, res) => {
  const fields = v.videoUpload(Object.fromEntries(req.query));
  const filename = path.basename(String(qs(req, 'filename', 'video')).replace(/[\\/]+/g, '/')).slice(0, 200) || 'video';
  const mimeType = media.normalizedVideoMime(req.headers['content-type'], filename);
  if (!mimeType) throw new HttpError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Choose a supported video file (MP4, WebM, MOV, MKV or 3GP).');

  const used = storageUsed(req.user.id);
  const remaining = remainingBytes(used, config.storageQuotaBytes);
  const limit = Math.min(config.maxUploadBytes, remaining);
  const declared = Number(req.headers['content-length']);
  // Reject early (before reading the body) when the declared size cannot fit.
  if (Number.isFinite(declared)) {
    if (declared === 0) throw new HttpError(400, 'EMPTY_FILE', 'The selected video file is empty.');
    if (declared > config.maxUploadBytes) throw tooLargeError();
    if (declared > remaining) throw quotaError(used);
  } else if (remaining <= 0) {
    throw quotaError(used);
  }

  const tempPath = path.join(config.uploadDir, `.incoming-${uuid()}`);
  const counter = new Transform({
    transform(chunk, _encoding, callback) {
      this.seen = (this.seen || 0) + chunk.length;
      if (this.seen > limit) callback(this.seen > config.maxUploadBytes ? tooLargeError() : quotaError(used));
      else callback(null, chunk);
    }
  });
  try {
    await pipeline(req, counter, fs.createWriteStream(tempPath, { flags: 'wx', mode: 0o600 }));
  } catch (error) {
    await media.removeFile(tempPath).catch(() => {});
    if (error && (error.code === 'ERR_STREAM_PREMATURE_CLOSE' || req.destroyed)) return; // the client cancelled the upload
    throw error;
  }

  let size;
  try {
    size = (await fs.promises.stat(tempPath)).size;
    if (size === 0) throw new HttpError(400, 'EMPTY_FILE', 'The selected video file is empty.');
    if (!media.looksLikeVideo(await media.readHead(tempPath))) throw new HttpError(415, 'UNSUPPORTED_MEDIA_TYPE', 'That file does not look like a supported video (MP4, WebM, MOV, MKV or 3GP).');
  } catch (error) {
    await media.removeFile(tempPath).catch(() => {});
    throw error;
  }

  const storageKey = media.makeStorageName(filename);
  const finalPath = path.join(config.uploadDir, storageKey);
  try {
    await fs.promises.rename(tempPath, finalPath);
    const videoId = transaction(() => {
      const channel = get('SELECT id FROM channels WHERE user_id = ?', req.user.id);
      if (!channel) throw new HttpError(400, 'NO_CHANNEL', 'This account has no channel.');
      const nowUsed = storageUsed(req.user.id);
      if (!fitsQuota(nowUsed, size, config.storageQuotaBytes)) throw quotaError(nowUsed);
      const id = uuid();
      run(`INSERT INTO videos (id, channel_id, title, description, category, visibility, duration_seconds, original_filename, storage_key, mime_type, file_size, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ready')`,
      id, channel.id, fields.title, fields.description, fields.category, fields.visibility, fields.duration, filename, storageKey, mimeType, size);
      return id;
    });
    sendJson(res, 201, { data: serialiseVideo(getVideo(videoId, req.user.id), req, true) });
  } catch (error) {
    await media.removeFile(finalPath).catch(() => {});
    await media.removeFile(tempPath).catch(() => {});
    throw error;
  }
});

// Optional picture shown on the video card. The app sends a frame it captured from the video.
route('PUT', '/api/v1/videos/:id/thumbnail', requireAuth, async (req, res) => {
  const owned = get(
    'SELECT v.id, v.thumb_key FROM videos v JOIN channels c ON c.id = v.channel_id WHERE v.id = ? AND (c.user_id = ? OR ? = 1)',
    req.params.id, req.user.id, req.user.role === 'admin' ? 1 : 0
  );
  if (!owned) throw notFoundError();
  const body = await readBuffer(req, config.maxThumbnailBytes, () => new HttpError(413, 'PAYLOAD_TOO_LARGE', 'The thumbnail is too large (limit 512 KB).'));
  const kind = media.imageKind(body);
  if (!kind) throw new HttpError(415, 'UNSUPPORTED_MEDIA_TYPE', 'The thumbnail must be a JPEG, PNG or WebP image.');
  const key = `thumb-${uuid()}${kind.ext}`;
  await fs.promises.writeFile(path.join(config.uploadDir, key), body, { mode: 0o600 });
  run(`UPDATE videos SET thumb_key = ?, updated_at = ${NOW} WHERE id = ?`, key, owned.id);
  await removeMedia(owned.thumb_key);
  sendJson(res, 200, { data: { thumbnail_url: `/api/v1/videos/${owned.id}/thumbnail` } });
});

route('GET', '/api/v1/videos/:id/thumbnail', optionalAuth, async (req, res) => {
  const video = getVideo(req.params.id, null);
  if (!video || video.status !== 'ready' || !video.thumb_key) throw notFoundError();
  let allowed = video.visibility !== 'private' || Boolean(req.user && req.user.id === video.owner_id);
  const ticket = qs(req, 'ticket');
  if (!allowed && ticket) allowed = auth.verifyMediaTicket(String(ticket), video.id, video.owner_id);
  if (!allowed) throw notFoundError();
  const file = media.resolveStoragePath(config.uploadDir, video.thumb_key);
  let stat;
  try { stat = await fs.promises.stat(file); } catch (_) { throw notFoundError(); }
  const mime = { '.jpg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp' }[path.extname(file)] || 'application/octet-stream';
  res.writeHead(200, { 'Content-Type': mime, 'Content-Length': stat.size, 'Cache-Control': video.visibility === 'public' ? 'public, max-age=300' : 'private, no-store' });
  if (req.method === 'HEAD') { res.end(); return; }
  await pipeline(fs.createReadStream(file), res).catch(() => {});
});

// ------------------------------------------------------------------ videos: edit, delete, stream
route('PATCH', '/api/v1/videos/:id', requireAuth, json, (req, res) => {
  const input = v.videoPatch(req.body);
  const allowed = get('SELECT v.id FROM videos v JOIN channels c ON c.id = v.channel_id WHERE v.id = ? AND (c.user_id = ? OR ? = 1)', req.params.id, req.user.id, req.user.role === 'admin' ? 1 : 0);
  if (!allowed) throw notFoundError();
  const columns = { title: 'title', description: 'description', category: 'category', visibility: 'visibility' };
  const fields = Object.keys(input);
  run(`UPDATE videos SET ${fields.map((f) => `${columns[f]} = ?`).join(', ')}, updated_at = ${NOW} WHERE id = ?`, ...fields.map((f) => input[f]), req.params.id);
  sendJson(res, 200, { data: serialiseVideo(getVideo(req.params.id, req.user.id), req, true) });
});

route('DELETE', '/api/v1/videos/:id', requireAuth, async (req, res) => {
  const found = get('SELECT v.id, v.storage_key, v.thumb_key FROM videos v JOIN channels c ON c.id = v.channel_id WHERE v.id = ? AND (c.user_id = ? OR ? = 1)', req.params.id, req.user.id, req.user.role === 'admin' ? 1 : 0);
  if (!found) throw notFoundError();
  run('DELETE FROM videos WHERE id = ?', found.id);
  await removeMedia(found.storage_key, found.thumb_key);
  res.writeHead(204); res.end();
});

route('GET', '/api/v1/videos/:id/stream', optionalAuth, async (req, res) => {
  const video = getVideo(req.params.id, null);
  if (!video || video.status !== 'ready') throw notFoundError();
  let allowed = video.visibility === 'public' || video.visibility === 'unlisted';
  if (!allowed && req.user && req.user.id === video.owner_id) allowed = true;
  const ticket = qs(req, 'ticket');
  if (!allowed && ticket) allowed = auth.verifyMediaTicket(String(ticket), video.id, video.owner_id);
  if (!allowed) throw notFoundError();
  const filePath = media.resolveStoragePath(config.uploadDir, video.storage_key);
  let stat;
  try { stat = await fs.promises.stat(filePath); } catch (_) { throw notFoundError(); }
  const range = media.parseByteRange(req.headers.range, stat.size);
  const base = {
    'Content-Type': video.mime_type,
    'Accept-Ranges': 'bytes',
    'Content-Disposition': 'inline',
    'Cache-Control': video.visibility === 'public' ? 'public, max-age=300' : 'private, no-store'
  };
  if (range && range.invalid) {
    res.writeHead(416, { ...base, 'Content-Range': `bytes */${stat.size}`, 'Content-Length': 0 });
    res.end();
    return;
  }
  if (range) res.writeHead(206, { ...base, 'Content-Range': `bytes ${range.start}-${range.end}/${stat.size}`, 'Content-Length': range.end - range.start + 1 });
  else res.writeHead(200, { ...base, 'Content-Length': stat.size });
  if (req.method === 'HEAD') { res.end(); return; }
  // pipeline() closes the file when the player aborts the request (every seek).
  await pipeline(fs.createReadStream(filePath, range ? { start: range.start, end: range.end } : undefined), res).catch(() => {});
});

route('POST', '/api/v1/videos/:id/view', optionalAuth, json, (req, res) => {
  const video = getVideo(req.params.id, null);
  if (!canViewVideo(video, req.user)) throw notFoundError();
  const visitor = req.user
    ? `user:${req.user.id}`
    : `anon:${crypto.createHash('sha256').update(`${clientIp(req)}|${req.headers['user-agent'] || ''}`).digest('hex')}`;
  const count = transaction(() => {
    const inserted = run('INSERT OR IGNORE INTO video_views (video_id, visitor_key) VALUES (?, ?)', video.id, visitor);
    if (inserted.changes > 0) run(`UPDATE videos SET view_count = view_count + 1, updated_at = ${NOW} WHERE id = ?`, video.id);
    return Number(get('SELECT view_count FROM videos WHERE id = ?', video.id).view_count);
  });
  sendJson(res, 200, { data: { view_count: count } });
});

route('POST', '/api/v1/videos/:id/like', requireAuth, json, (req, res) => {
  const { value } = v.like(req.body);
  const video = getVideo(req.params.id, null);
  if (!canViewVideo(video, req.user)) throw notFoundError();
  if (value === 0) run('DELETE FROM video_likes WHERE user_id = ? AND video_id = ?', req.user.id, video.id);
  else run(`INSERT INTO video_likes (user_id, video_id, value) VALUES (?, ?, ?)
            ON CONFLICT (user_id, video_id) DO UPDATE SET value = excluded.value, created_at = ${NOW}`, req.user.id, video.id, value);
  const counts = get('SELECT COALESCE(SUM(value = 1), 0) AS likes, COALESCE(SUM(value = -1), 0) AS dislikes FROM video_likes WHERE video_id = ?', video.id);
  sendJson(res, 200, { data: { value, like_count: Number(counts.likes), dislike_count: Number(counts.dislikes) } });
});

// ------------------------------------------------------------------ comments
route('GET', '/api/v1/videos/:id/comments', optionalAuth, (req, res) => {
  const video = getVideo(req.params.id, null);
  if (!canViewVideo(video, req.user)) throw notFoundError();
  const limit = Math.max(1, Math.min(100, toInt(qs(req, 'limit', '50'), 50)));
  const rows = all(
    `SELECT cm.id, cm.video_id, cm.parent_id, cm.body, cm.created_at, u.id AS user_id, u.username, u.display_name
     FROM comments cm JOIN users u ON u.id = cm.user_id
     WHERE cm.video_id = ?
       AND NOT EXISTS (SELECT 1 FROM user_blocks ub WHERE ub.blocker_id = ? AND ub.blocked_id = cm.user_id)
     ORDER BY cm.created_at ASC, cm.rowid ASC LIMIT ?`, video.id, req.user ? req.user.id : null, limit
  );
  sendJson(res, 200, { data: rows.map((r) => ({ id: r.id, video_id: r.video_id, parent_id: r.parent_id, body: r.body, created_at: r.created_at, user: { id: r.user_id, username: r.username, display_name: r.display_name } })) });
});

route('POST', '/api/v1/videos/:id/comments', requireAuth, json, (req, res) => {
  const input = v.comment(req.body);
  const video = getVideo(req.params.id, null);
  if (!canViewVideo(video, req.user)) throw notFoundError();
  if (input.parentId && !get('SELECT id FROM comments WHERE id = ? AND video_id = ?', input.parentId, video.id)) {
    throw new HttpError(400, 'INVALID_PARENT_COMMENT', 'The reply target does not belong to this video.');
  }
  const id = uuid();
  run('INSERT INTO comments (id, video_id, user_id, parent_id, body) VALUES (?, ?, ?, ?, ?)', id, video.id, req.user.id, input.parentId, input.body);
  const row = get('SELECT id, video_id, parent_id, body, created_at FROM comments WHERE id = ?', id);
  sendJson(res, 201, { data: { ...row, user: { id: req.user.id, username: req.user.username } } });
});

route('DELETE', '/api/v1/comments/:id', requireAuth, (req, res) => {
  const found = get(
    `SELECT cm.id FROM comments cm JOIN videos v ON v.id = cm.video_id JOIN channels c ON c.id = v.channel_id
     WHERE cm.id = ? AND (cm.user_id = ? OR c.user_id = ? OR ? = 1)`, req.params.id, req.user.id, req.user.id, req.user.role === 'admin' ? 1 : 0
  );
  if (!found) throw notFoundError();
  run('DELETE FROM comments WHERE id = ?', found.id);
  res.writeHead(204); res.end();
});

// ------------------------------------------------------------------ reports and blocking
route('POST', '/api/v1/comments/:id/report', requireAuth, json, (req, res) => {
  const { reason } = v.report(req.body);
  const target = get('SELECT video_id FROM comments WHERE id = ?', req.params.id);
  if (!target || !canViewVideo(getVideo(target.video_id, null), req.user)) throw notFoundError();
  const id = uuid();
  run(`INSERT INTO comment_reports (id, comment_id, reporter_id, reason) VALUES (?, ?, ?, ?)
       ON CONFLICT (comment_id, reporter_id) DO UPDATE SET reason = excluded.reason, status = 'open'`, id, req.params.id, req.user.id, reason);
  const saved = get('SELECT id FROM comment_reports WHERE comment_id = ? AND reporter_id = ?', req.params.id, req.user.id);
  sendJson(res, 201, { data: { report_id: saved.id, status: 'open' } });
});

function insertContentReport(kind, targetId, reporterId, reason) {
  run(`INSERT INTO content_reports (id, kind, target_id, reporter_id, reason) VALUES (?, ?, ?, ?, ?)
       ON CONFLICT (kind, target_id, reporter_id) DO UPDATE SET reason = excluded.reason, status = 'open'`, uuid(), kind, targetId, reporterId, reason);
  return get('SELECT id FROM content_reports WHERE kind = ? AND target_id = ? AND reporter_id = ?', kind, targetId, reporterId).id;
}

route('POST', '/api/v1/videos/:id/report', requireAuth, json, (req, res) => {
  const { reason } = v.report(req.body);
  const video = getVideo(req.params.id, null);
  if (!canViewVideo(video, req.user)) throw notFoundError();
  if (video.owner_id === req.user.id) throw new HttpError(400, 'OWN_CONTENT', 'You cannot report your own video.');
  sendJson(res, 201, { data: { report_id: insertContentReport('video', video.id, req.user.id, reason), status: 'open' } });
});

route('POST', '/api/v1/channels/:id/report', requireAuth, json, (req, res) => {
  const { reason } = v.report(req.body);
  const channel = get('SELECT id, user_id FROM channels WHERE id = ?', req.params.id);
  if (!channel) throw notFoundError();
  if (channel.user_id === req.user.id) throw new HttpError(400, 'OWN_CONTENT', 'You cannot report your own channel.');
  sendJson(res, 201, { data: { report_id: insertContentReport('channel', channel.id, req.user.id, reason), status: 'open' } });
});

route('POST', '/api/v1/users/:id/block', requireAuth, (req, res) => {
  if (req.params.id === req.user.id) throw new HttpError(400, 'SELF_BLOCK', 'You cannot block yourself.');
  if (!get('SELECT id FROM users WHERE id = ?', req.params.id)) throw notFoundError();
  run('INSERT OR IGNORE INTO user_blocks (blocker_id, blocked_id) VALUES (?, ?)', req.user.id, req.params.id);
  sendJson(res, 200, { data: { blocked: true } });
});

route('DELETE', '/api/v1/users/:id/block', requireAuth, (req, res) => {
  run('DELETE FROM user_blocks WHERE blocker_id = ? AND blocked_id = ?', req.user.id, req.params.id);
  sendJson(res, 200, { data: { blocked: false } });
});

route('GET', '/api/v1/me/blocks', requireAuth, (req, res) => {
  sendJson(res, 200, {
    data: all('SELECT u.id, u.username, u.display_name FROM user_blocks b JOIN users u ON u.id = b.blocked_id WHERE b.blocker_id = ? ORDER BY b.created_at DESC', req.user.id)
  });
});

// ------------------------------------------------------------------ channels and subscriptions
route('POST', '/api/v1/channels/:id/subscribe', requireAuth, (req, res) => {
  const channel = get('SELECT id, user_id FROM channels WHERE id = ?', req.params.id);
  if (!channel) throw notFoundError();
  if (channel.user_id === req.user.id) throw new HttpError(400, 'SELF_SUBSCRIBE', 'You cannot subscribe to your own channel.');
  run('INSERT OR IGNORE INTO subscriptions (subscriber_id, channel_id) VALUES (?, ?)', req.user.id, channel.id);
  sendJson(res, 200, { data: { subscribed: true } });
});

route('DELETE', '/api/v1/channels/:id/subscribe', requireAuth, (req, res) => {
  run('DELETE FROM subscriptions WHERE subscriber_id = ? AND channel_id = ?', req.user.id, req.params.id);
  sendJson(res, 200, { data: { subscribed: false } });
});

route('GET', '/api/v1/me/subscriptions', requireAuth, (req, res) => {
  sendJson(res, 200, {
    data: all(
      `SELECT c.id, c.handle, c.display_name, c.description, c.user_id, u.username,
              (SELECT COUNT(*) FROM subscriptions s2 WHERE s2.channel_id = c.id) AS subscriber_count
       FROM subscriptions s JOIN channels c ON c.id = s.channel_id JOIN users u ON u.id = c.user_id
       WHERE s.subscriber_id = ? ORDER BY s.created_at DESC`, req.user.id
    )
  });
});

route('GET', '/api/v1/me/feed', requireAuth, (req, res) => {
  const rows = all(
    `${VIDEO_SELECT} JOIN subscriptions s ON s.channel_id = c.id
     WHERE s.subscriber_id = ? AND v.visibility = 'public' AND v.status = 'ready'
       AND NOT EXISTS (SELECT 1 FROM user_blocks ub WHERE ub.blocker_id = ? AND ub.blocked_id = c.user_id)
     ORDER BY v.created_at DESC, v.rowid DESC LIMIT 50`, req.user.id, req.user.id, req.user.id
  );
  sendJson(res, 200, { data: rows.map((row) => serialiseVideo(row, req)) });
});

route('GET', '/api/v1/channels/:id', optionalAuth, (req, res) => {
  const row = get(
    `SELECT c.id, c.handle, c.display_name, c.description, c.created_at, u.id AS user_id, u.username,
            (SELECT COUNT(*) FROM subscriptions s WHERE s.channel_id = c.id) AS subscriber_count,
            (SELECT COUNT(*) FROM videos v WHERE v.channel_id = c.id AND v.visibility = 'public' AND v.status = 'ready') AS video_count
     FROM channels c JOIN users u ON u.id = c.user_id WHERE c.id = ?`, req.params.id
  );
  if (!row) throw notFoundError();
  sendJson(res, 200, { data: row });
});

route('GET', '/api/v1/me/storage', requireAuth, (req, res) => {
  const used = storageUsed(req.user.id);
  sendJson(res, 200, { data: { used_bytes: used, limit_bytes: config.storageQuotaBytes, remaining_bytes: remainingBytes(used, config.storageQuotaBytes), max_upload_bytes: config.maxUploadBytes } });
});

// ------------------------------------------------------------------ administrators
route('GET', '/api/v1/admin/reports', requireAuth, requireAdmin, (_req, res) => {
  const comments = all(
    `SELECT r.id, r.reason, r.status, r.created_at, cm.body, reporter.username AS reporter_username,
            author.username AS author_username, author.id AS target_user_id, cm.id AS comment_id, cm.video_id
     FROM comment_reports r JOIN comments cm ON cm.id = r.comment_id
     JOIN users reporter ON reporter.id = r.reporter_id JOIN users author ON author.id = cm.user_id
     WHERE r.status = 'open' ORDER BY r.created_at ASC LIMIT 100`
  );
  const content = all(
    `SELECT r.id, r.kind, r.reason, r.status, r.created_at, reporter.username AS reporter_username,
            v.id AS video_id, v.title, ch.id AS channel_id, ch.display_name AS channel_name,
            owner.id AS target_user_id, owner.username AS author_username
     FROM content_reports r JOIN users reporter ON reporter.id = r.reporter_id
     LEFT JOIN videos v ON r.kind = 'video' AND v.id = r.target_id
     LEFT JOIN channels ch ON ch.id = CASE WHEN r.kind = 'channel' THEN r.target_id ELSE v.channel_id END
     LEFT JOIN users owner ON owner.id = ch.user_id
     WHERE r.status = 'open' AND ch.id IS NOT NULL AND (r.kind = 'channel' OR v.id IS NOT NULL)
     ORDER BY r.created_at ASC LIMIT 100`
  );
  const items = [
    ...comments.map((row) => ({ ...row, type: 'comment' })),
    ...content.map((row) => ({
      id: row.id, type: row.kind, reason: row.reason, status: row.status, created_at: row.created_at,
      reporter_username: row.reporter_username, author_username: row.author_username, target_user_id: row.target_user_id,
      video_id: row.kind === 'video' ? row.video_id : null, channel_id: row.channel_id,
      title: row.kind === 'video' ? row.title : row.channel_name
    }))
  ].sort((x, y) => new Date(x.created_at) - new Date(y.created_at)).slice(0, 100);
  sendJson(res, 200, { data: items });
});

route('PATCH', '/api/v1/admin/reports/:id', requireAuth, requireAdmin, json, (req, res) => {
  const { status } = v.reportStatus(req.body);
  let result = run('UPDATE comment_reports SET status = ? WHERE id = ?', status, req.params.id);
  if (!result.changes) result = run('UPDATE content_reports SET status = ? WHERE id = ?', status, req.params.id);
  if (!result.changes) throw notFoundError();
  sendJson(res, 200, { data: { id: req.params.id, status } });
});

route('DELETE', '/api/v1/admin/users/:id', requireAuth, requireAdmin, async (req, res) => {
  if (req.params.id === req.user.id) throw new HttpError(400, 'SELF_REMOVE', 'Use "Delete account" to remove your own account.');
  const target = get('SELECT role FROM users WHERE id = ?', req.params.id);
  if (!target) throw notFoundError();
  if (target.role === 'admin') throw new HttpError(400, 'CANNOT_REMOVE_ADMIN', 'Administrator accounts cannot be removed from the moderation screen.');
  await removeUserAccount(req.params.id);
  res.writeHead(204); res.end();
});

// ------------------------------------------------------------------ request entry point
const API_ID_PATTERN = (value) => v.isUuid(value);

async function handle(req, res) {
  let url;
  try { url = new URL(req.url, 'http://localhost'); } catch (_) { res.writeHead(400); res.end(); return; }
  req.path = url.pathname;
  req.query = url.searchParams;
  req.params = {};
  req.body = {};
  req.user = null;
  setSecurityHeaders(res);

  const isApi = req.path.startsWith('/api/') || req.path === '/health';
  const corsAllowed = applyCors(req, res);
  try {
    if (req.method === 'OPTIONS') {
      if (!corsAllowed) throw new HttpError(403, 'CORS_ORIGIN_DENIED', 'This app origin is not allowed by the API.');
      answerPreflight(req, res);
      return;
    }
    if (isApi && !corsAllowed) throw new HttpError(403, 'CORS_ORIGIN_DENIED', 'This app origin is not allowed by the API.');

    if (isApi || req.path.startsWith('/legal/')) {
      if (req.path.startsWith('/api/')) apiLimiter(req, res);
      const match = router.find(req.method, req.path);
      if (!match) throw notFoundError();
      for (const [name, value] of Object.entries(match.params)) {
        if (name === 'id' && !API_ID_PATTERN(value)) throw notFoundError();
      }
      req.params = match.params;
      for (const handler of match.route.handlers) {
        await handler(req, res);
        if (res.writableEnded || res.destroyed) break;
      }
      return;
    }
    await serveStatic(req, res, req.path);
  } catch (error) {
    sendError(res, error);
  }
}

module.exports = { handle, removeUserAccount };
