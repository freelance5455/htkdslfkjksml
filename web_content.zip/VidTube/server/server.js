'use strict';
// VidTube server entry point.  Start it with:  node server.js   (or double-click start-windows.bat)

const major = Number(process.versions.node.split('.')[0]);
const minor = Number(process.versions.node.split('.')[1]);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`\nVidTube needs Node.js 22.13 or newer, but this computer has ${process.version}.`);
  console.error('Download the current LTS version from https://nodejs.org, install it, then start VidTube again.\n');
  process.exit(1);
}

const http = require('node:http');
const os = require('node:os');
const config = require('./src/config');
const database = require('./src/db');
const { handle } = require('./src/app');
const { seedDemoContent } = require('./src/seed');

const server = http.createServer((req, res) => {
  handle(req, res).catch((error) => {
    console.error('Fatal request error:', error);
    try { res.destroy(); } catch (_) { /* already closed */ }
  });
});
// Large uploads on slow phone connections can take a while.
server.requestTimeout = 30 * 60 * 1000;
server.headersTimeout = 65_000;
server.keepAliveTimeout = 5_000;

function lanAddresses() {
  // Skip virtual adapters (WSL, VirtualBox, Docker, VPNs...) so the address printed here is the one a phone can reach.
  const virtual = /vethernet|virtualbox|vmware|vmnet|wsl|docker|veth|br-|utun|tailscale|zerotier|bluetooth|loopback/i;
  const found = [];
  for (const [name, addresses] of Object.entries(os.networkInterfaces())) {
    if (virtual.test(name)) continue;
    for (const a of addresses || []) if ((a.family === 'IPv4' || a.family === 4) && !a.internal) found.push({ name, address: a.address });
  }
  const rank = (a) => (/^192\.168\./.test(a.address) ? 0 : /^10\./.test(a.address) ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(a.address) ? 2 : 3);
  return found.sort((x, y) => rank(x) - rank(y));
}

function banner(port) {
  const lines = ['', '  \u2705  VidTube is running!', '', `  On this computer:   http://localhost:${port}`];
  const lan = lanAddresses();
  if (lan.length) {
    lines.push('', '  On your phone (same Wi-Fi), open this address in Chrome:');
    for (const item of lan) lines.push(`      http://${item.address}:${port}      (${item.name})`);
    lines.push('', `  Android Studio app: type ${`http://${lan[0].address}:${port}`} under Sign in > Server address`);
  }
  lines.push('', `  Your videos and accounts are saved in: ${config.dataDir}`);
  if (config.firstUserIsAdmin) lines.push('  The FIRST account you create becomes the administrator (it gets the Admin tab).');
  lines.push('  Press Ctrl+C to stop.', '');
  console.log(lines.join('\n'));
}

function listen(port, attemptsLeft) {
  const onError = (error) => {
    if (error.code === 'EADDRINUSE' && attemptsLeft > 0) {
      console.log(`Port ${port} is busy, trying ${port + 1}...`);
      listen(port + 1, attemptsLeft - 1);
      return;
    }
    console.error(`\nCould not start the server: ${error.message}\n`);
    process.exit(1);
  };
  server.once('error', onError);
  server.listen(port, config.host, () => {
    server.removeListener('error', onError);
    banner(port);
    if (config.isProduction && !config.contactEmail) console.warn('Tip: set CONTACT_EMAIL in .env; it is shown on the Terms and Privacy pages.');
  });
}
seedDemoContent()
  .catch((error) => console.warn('Could not add the sample videos:', error.message))
  .finally(() => listen(config.port, 10));

let stopping = false;
function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  console.log(`\n${signal} received, stopping VidTube...`);
  const force = setTimeout(() => process.exit(1), 8000);
  force.unref();
  server.close(() => { database.close(); process.exit(0); });
  if (server.closeIdleConnections) server.closeIdleConnections();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
