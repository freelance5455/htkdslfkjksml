PROJETO ANDROID - CONTROLE FINANCEIRO

Este projeto transforma o arquivo HTML em um aplicativo Android usando WebView.

COMO GERAR O APK:
1. Instale o Android Studio no computador.
2. Extraia este arquivo ZIP.
3. Abra a pasta ControleFinanceiroAndroid no Android Studio.
4. Aguarde o Gradle sincronizar e baixar as dependências.
5. Vá em Build > Build APK(s).
6. O APK será gerado em:
   app/build/outputs/apk/debug/app-debug.apk

IMPORTANTE:
O HTML está incluído em:
app/src/main/assets/index.html

O aplicativo funciona offline para os recursos que já estão incluídos no HTML.
