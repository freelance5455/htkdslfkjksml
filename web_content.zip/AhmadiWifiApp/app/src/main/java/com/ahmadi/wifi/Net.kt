package com.ahmadi.wifi

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.Inet4Address

object Net {

    /** Returns the IPv4 default gateway of the connected Wi-Fi network (the MikroTik router), or null. */
    @Suppress("DEPRECATION")
    fun wifiGateway(ctx: Context): String? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue
            val lp = cm.getLinkProperties(n) ?: continue
            for (r in lp.routes) {
                val gw = r.gateway
                if (r.isDefaultRoute && gw is Inet4Address) return gw.hostAddress
            }
        }
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val g = wm?.dhcpInfo?.gateway ?: 0
        if (g != 0) {
            return "${g and 0xff}.${(g shr 8) and 0xff}.${(g shr 16) and 0xff}.${(g shr 24) and 0xff}"
        }
        return null
    }
}
