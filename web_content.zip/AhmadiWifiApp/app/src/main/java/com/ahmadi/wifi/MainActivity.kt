package com.ahmadi.wifi

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    companion object {
        private const val ASSET = "file:///android_asset/www/"
        private const val OFFLINE = ASSET + "offline.html"
        private val OFFLINE_PAGES = setOf("offline.html", "paket.html", "about.html", "contact.html", "faq.html")
        private val NET_ERRORS = setOf(
            WebViewClient.ERROR_HOST_LOOKUP, WebViewClient.ERROR_CONNECT,
            WebViewClient.ERROR_TIMEOUT, WebViewClient.ERROR_IO
        )
        private const val LOAD_TIMEOUT_MS = 15000L
    }

    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var cm: ConnectivityManager

    private val ui = Handler(Looper.getMainLooper())
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var started = false
    private var currentHost: String? = null
    private var pendingRemote = false
    private var clearHistoryAfterLoad = false

    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    private val watchdog = Runnable {
        if (pendingRemote && web.progress < 100) {
            web.stopLoading()
            showOffline()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<FrameLayout>(R.id.root)
        web = findViewById(R.id.webview)
        swipe = findViewById(R.id.swipe)
        progress = findViewById(R.id.progress)
        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        setupWebView()

        swipe.setColorSchemeResources(R.color.brand_blue)
        swipe.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        swipe.setOnRefreshListener {
            if (web.url == OFFLINE) loadHotspot() else web.reload()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        bindToWifiThenLoad()
    }

    // ---------------------------------------------------------------- network

    /**
     * Android sends app traffic over mobile data when the Wi-Fi has no internet (captive portal).
     * Binding the process to the Wi-Fi network makes the router's login page reachable.
     */
    private fun bindToWifiThenLoad() {
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cm.bindProcessToNetwork(network)
                ui.post {
                    if (!started) {
                        started = true
                        loadHotspot()
                    } else if (web.url == OFFLINE) {
                        loadHotspot()
                    }
                }
            }

            override fun onLost(network: Network) {
                cm.bindProcessToNetwork(null)
            }
        }
        netCb = cb
        try {
            cm.requestNetwork(req, cb)
        } catch (e: Exception) {
            // ignore: we still try to load below
        }
        ui.postDelayed({
            if (!started) {
                started = true
                loadHotspot()
            }
        }, 2500)
    }

    private fun hotspotHost(): String? {
        val custom = prefs.getString("host", "")?.trim().orEmpty()
        return if (custom.isNotEmpty()) custom else Net.wifiGateway(this)
    }

    private fun loadHotspot() {
        val host = hotspotHost()
        if (host == null) {
            showOffline()
            return
        }
        currentHost = host
        web.loadUrl("http://$host/login")
    }

    private fun loadStatus() {
        val host = currentHost ?: hotspotHost()
        if (host == null) showOffline() else web.loadUrl("http://$host/status")
    }

    private fun showOffline() {
        ui.removeCallbacks(watchdog)
        pendingRemote = false
        clearHistoryAfterLoad = true
        web.loadUrl(OFFLINE)
    }

    // ---------------------------------------------------------------- webview

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false      // file:///android_asset stays available
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            userAgentString = "$userAgentString AhmadiWifiApp/1.0"
        }
        web.overScrollMode = View.OVER_SCROLL_NEVER

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                handleUrl(request)

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                ui.removeCallbacks(watchdog)
                pendingRemote = url != null && !url.startsWith(ASSET)
                if (pendingRemote) ui.postDelayed(watchdog, LOAD_TIMEOUT_MS)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                ui.removeCallbacks(watchdog)
                pendingRemote = false
                swipe.isRefreshing = false
                if (clearHistoryAfterLoad && url != null && url.startsWith(ASSET)) {
                    clearHistoryAfterLoad = false
                    view.clearHistory()
                }
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame &&
                    !request.url.toString().startsWith(ASSET) &&
                    error.errorCode in NET_ERRORS
                ) {
                    ui.post { showOffline() }
                }
            }
        }
    }

    /** Returns true when the app handled the URL itself (WebView must not load it). */
    private fun handleUrl(request: WebResourceRequest): Boolean {
        val uri = request.url
        val url = uri.toString()
        return when (uri.scheme) {
            "ahmadi" -> {
                when (uri.host) {
                    "retry" -> loadHotspot()
                    "settings" -> showHostDialog()
                }
                true
            }
            "file" -> {
                if (!url.startsWith(ASSET)) {
                    true
                } else if ((uri.lastPathSegment ?: "") !in OFFLINE_PAGES) {
                    // bundled pages link to login.html / status.html etc. -> use the real router page
                    loadHotspot()
                    true
                } else false
            }
            "http", "https" -> {
                val host = uri.host.orEmpty()
                val routerHost = currentHost?.substringBefore(':').orEmpty()
                when {
                    host.equals(routerHost, ignoreCase = true) -> false
                    // after login the router redirects to the original site: stay in the app, show status
                    !request.hasGesture() || request.isRedirect -> {
                        loadStatus()
                        true
                    }
                    else -> {
                        openExternal(uri)
                        true
                    }
                }
            }
            "intent" -> true
            else -> {
                openExternal(uri) // tel:, mailto:, whatsapp:, ...
                true
            }
        }
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showHostDialog() {
        val et = EditText(this).apply {
            hint = "192.168.88.1"
            setText(prefs.getString("host", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.router_title)
            .setMessage(R.string.router_msg)
            .setView(box)
            .setPositiveButton(R.string.save) { _, _ ->
                val v = et.text.toString().trim()
                    .removePrefix("http://").removePrefix("https://")
                    .substringBefore('/')
                prefs.edit().putString("host", v).apply()
                loadHotspot()
            }
            .setNeutralButton(R.string.auto) { _, _ ->
                prefs.edit().remove("host").apply()
                loadHotspot()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // -------------------------------------------------------------- lifecycle

    override fun onResume() {
        super.onResume()
        if (started && web.url == OFFLINE && hotspotHost() != null) loadHotspot()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        netCb?.let {
            try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {}
        }
        cm.bindProcessToNetwork(null)
        web.destroy()
        super.onDestroy()
    }
}
