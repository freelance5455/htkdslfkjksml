# احمدي وای فای — انډرایډ اپلیکیشن

د ستاسو د MikroTik هاټ سپاټ ډیزاین (v7 White) لپاره انډرایډ اپ.

## اپ څه کوي
- د Wi-Fi gateway (روټر IP) اتومات پیژني او `http://<روټر>/login` پرانیزي.
- اپ د Wi-Fi شبکې سره تړي، نو که Wi-Fi انټرنټ نه لري هم د لاګ این پاڼه کار کوي (د موبایل ډیټا مخه نیسي).
- که روټر ونه موندل شي، آفلاین پاڼه ښيي (پکیجونه، اړیکه، مرسته پرته له انټرنټ).
- د `tel:` او WhatsApp لینکونه بهر په فون/واټساپ کې پرانیزي.
- «د روټر پته» تڼۍ: که روټر IP د 192.168.88.1 نه جلا وي، لاسي یې ټاکلی شئ.
- Pull-to-refresh، د شاته تڼۍ، د پرمختګ کرښه.

## جوړول (APK)
**لاره ۱ — Android Studio (JDK 17):** پروژه Open کړئ → Sync → `Build > Build APK(s)`.
APK: `app/build/outputs/apk/debug/app-debug.apk`

**لاره ۲ — GitHub Actions:** پروژه GitHub ته پورته کړئ؛ په `Actions` کې APK جوړېږي (`.github/workflows/android.yml`).

## د ډیزاین بدلول
د لاګ این/سټیټس پاڼې روټر ورکوي (هلته بدلون راشي، اپ کې هم راځي).
د آفلاین پاڼو کاپي په `app/src/main/assets/www/` کې دي — که پکیج/اړیکې پاڼې بدلې کړئ، دلته هم کاپي یې کړئ.

## Play Store
`app/build.gradle.kts` کې `targetSdk` د Google اوسني شرط ته لوړ کړئ، او Release د خپل keystore سره sign کړئ.

---
**English:** Android WebView wrapper for the Ahmadi WiFi MikroTik hotspot theme. Opens `http://<wifi-gateway>/login`, binds traffic to Wi-Fi so the captive portal works, includes an offline fallback with bundled pages.
