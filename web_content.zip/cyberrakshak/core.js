export const MAX_URL_LENGTH = 2048;
export const MAX_PASSWORD_LENGTH = 128;

const COMMON_PASSWORDS = new Set([
  'password', 'password1', '123456', '12345678', '123456789', 'qwerty', 'qwerty123',
  'letmein', 'admin', 'welcome', 'iloveyou', 'nepal123', 'password123', 'abc123'
]);
const SHORTENERS = new Set([
  'bit.ly', 't.co', 'tinyurl.com', 'tiny.cc', 'is.gd', 'cutt.ly', 'rb.gy',
  'rebrand.ly', 'shorturl.at', 'ow.ly', 'buff.ly', 'lnkd.in', 'bit.do'
]);
const SUSPICIOUS_TERMS = /(?:login|log-in|verify|verification|urgent|suspend(?:ed)?|wallet|banking|otp|password|reset|claim|refund|reward|prize|gift|kyc|update-account|confirm-account)/i;
const EXPLICIT_SCHEME = /^[a-z][a-z\d+.-]*:/i;
const HTTP_SCHEME = /^https?:\/\//i;

function hasRepeatedRun(value, min = 4) {
  return new RegExp(`(.)\\1{${min - 1},}`, 'i').test(value);
}
function hasSimpleSequence(value) {
  const s = value.toLowerCase();
  return ['1234', '2345', '3456', '4567', '5678', '6789', 'abcd', 'bcde', 'cdef', 'qwer', 'asdf', 'zxcv'].some(part => s.includes(part));
}

/** Analyze a user-provided sample password only in the caller's process memory. */
export function analyzePassword(input) {
  const value = String(input ?? '');
  const length = [...value].length;
  if (length === 0) return { status: 'empty', label: 'Nothing to check', score: 0, findings: ['Enter an invented sample only; never use a password you currently use.'] };
  if (length > MAX_PASSWORD_LENGTH) return { status: 'too-long', label: 'Sample is too long', score: 0, findings: [`This checker accepts up to ${MAX_PASSWORD_LENGTH} characters; no result was calculated.`] };

  const findings = [];
  const lower = value.toLowerCase();
  const classes = [/[a-z]/.test(value), /[A-Z]/.test(value), /\d/.test(value), /[^A-Za-z0-9]/.test(value)].filter(Boolean).length;
  const uniqueRatio = new Set([...value]).size / length;
  const common = COMMON_PASSWORDS.has(lower) || /^(?:password|qwerty|welcome|nepal|admin)[!@#$%^&*\d]*$/i.test(value);
  const repeated = hasRepeatedRun(value) || new Set(value).size <= Math.min(3, length);
  const sequence = hasSimpleSequence(value);
  let score = 0;
  if (length >= 16) score += 3;
  else if (length >= 12) score += 2;
  else if (length >= 8) score += 1;
  if (classes >= 3) score += 2;
  else if (classes >= 2) score += 1;
  if (uniqueRatio >= 0.72) score += 1;
  if (common) score -= 4;
  if (repeated) score -= 2;
  if (sequence) score -= 1;
  score = Math.max(0, Math.min(6, score));

  if (common) findings.push('This resembles a common or easily guessed example pattern.');
  if (length < 12) findings.push('It is shorter than the 12-character baseline this tool recommends.');
  else if (length < 16) findings.push('Longer unique passphrases can be easier to remember and harder to guess.');
  if (classes < 3) findings.push('It uses few character types; length and uniqueness matter more than forced complexity.');
  if (repeated) findings.push('Repeated characters or a very small set of characters make patterns easier to guess.');
  if (sequence) findings.push('A familiar sequence was detected.');
  if (findings.length === 0) findings.push('No simple weakness pattern was detected by these limited checks.');

  let status = 'weak';
  let label = 'Needs improvement';
  if (score >= 5) { status = 'stronger'; label = 'Stronger-looking sample'; }
  else if (score >= 3) { status = 'moderate'; label = 'Mixed signals'; }
  return { status, label, score, length, findings, recommendation: 'For real accounts, use a long, unique password or passphrase, keep one password per account, and consider a reputable password manager.' };
}

function isIPv4(hostname) {
  if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(hostname)) return false;
  return hostname.split('.').every(part => Number(part) <= 255);
}

/** Inspect URL text without opening it, resolving DNS, or making network requests. */
export function analyzeUrl(input) {
  const raw = String(input ?? '');
  const value = raw.trim();
  if (!value) return { status: 'empty', label: 'Nothing to inspect', flags: [], findings: ['Paste text only if you already have a suspicious link. Do not open it to obtain one.'] };
  if (value.length > MAX_URL_LENGTH) return { status: 'too-long', label: 'Input exceeds the limit', flags: [], findings: [`Maximum length is ${MAX_URL_LENGTH} characters. The text was not parsed.`] };
  if (/[\u0000-\u001f\u007f]/.test(value)) return { status: 'invalid', label: 'Cannot parse this text as a web link', flags: [], findings: ['Control characters are not accepted. No link was opened.'] };
  if (/\s/.test(value)) return { status: 'invalid', label: 'Cannot parse this text as a web link', flags: [], findings: ['Whitespace inside a web address is ambiguous. No link was opened.'] };

  let candidate = value;
  let assumedHttps = false;
  if (!EXPLICIT_SCHEME.test(value)) {
    if (/\s/.test(value) || !value.includes('.')) return { status: 'invalid', label: 'Cannot parse this text as a web link', flags: [], findings: ['Enter a web address such as example.com or https://example.com. No link was opened.'] };
    candidate = `https://${value}`;
    assumedHttps = true;
  } else if (!HTTP_SCHEME.test(value)) {
    return { status: 'unsupported', label: 'Unsupported link type', flags: [], findings: ['Only http and https web-address text is checked. This text was not executed or opened.'] };
  }

  let parsed;
  try { parsed = new URL(candidate); }
  catch { return { status: 'invalid', label: 'Cannot parse this text as a web link', flags: [], findings: ['The address format could not be parsed. No link was opened.'] }; }
  if (!['http:', 'https:'].includes(parsed.protocol) || !parsed.hostname) {
    return { status: 'invalid', label: 'Cannot parse this text as a web link', flags: [], findings: ['A web host could not be identified. No link was opened.'] };
  }

  const host = parsed.hostname.toLowerCase().replace(/\.$/, '');
  const flags = [];
  if (assumedHttps) flags.push('No scheme was supplied; https was assumed for text parsing only.');
  if (parsed.protocol === 'http:') flags.push('The address uses unencrypted http rather than https. This alone does not prove fraud.');
  if (parsed.username || parsed.password || /https?:\/\/[^/\s]*@/i.test(value)) flags.push('The address includes user-information before the host, which can make the real destination misleading.');
  if (host.startsWith('xn--') || host.split('.').some(label => label.startsWith('xn--'))) flags.push('The host contains a punycode label; visually similar characters may be involved.');
  if (isIPv4(host) || host.startsWith('[') && host.endsWith(']')) flags.push('The host is an IP address rather than a familiar domain name.');
  if (SHORTENERS.has(host)) flags.push('This appears to use a known URL-shortening domain; the final destination is unknown because redirects are not followed.');
  const labels = host.split('.').filter(Boolean);
  if (labels.length >= 5) flags.push('The hostname has many subdomain parts; check the registered domain carefully.');
  if (SUSPICIOUS_TERMS.test(`${parsed.pathname} ${parsed.search}`)) flags.push('The path or query includes words commonly used in account, payment, or urgency lures.');
  if (/[\u200B-\u200F\u2060\uFEFF]/.test(value)) flags.push('The text includes an invisible formatting character.');
  if (!flags.some(flag => flag.includes('encrypted http')) && parsed.protocol === 'https:' && flags.length === 0) {
    // Deliberately no "safe" inference: this is only a transparent summary of inspected patterns.
  }

  let status = 'no-obvious-pattern';
  let label = 'No listed warning pattern matched';
  if (flags.some(flag => flag.includes('user-information') || flag.includes('punycode') || flag.includes('IP address') || flag.includes('invisible'))) {
    status = 'caution'; label = 'Warning signs found';
  } else if (flags.length > 0) { status = 'review'; label = 'Review carefully'; }
  const findings = flags.length ? flags : ['No listed pattern matched. This does not show that the destination is genuine, current, or free of threats.'];
  return { status, label, flags, findings, parsedScheme: parsed.protocol, hostname: host, assumedHttps, unknowns: ['Ownership and reputation were not checked.', 'The page content, redirects, downloads, and malware were not checked.', 'A convincing or compromised legitimate domain can still be dangerous.'] };
}
