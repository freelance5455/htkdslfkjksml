# Educational Sources

Reviewed on 10 October 2026 for this build. Use the official pages directly for current instructions; operational details can change.

1. **Nepal Police Cyber Bureau — Report a cybercrime**  
   https://cyberbureau.nepalpolice.gov.np/report-cyber-crime/  
   The official page lists complaint form downloads, attachments (including relevant URLs/screenshots and identity-document copy), submission through local police or the Bureau office, and email submission where in-person submission is not possible. The app links to the page but does not collect or submit a complaint.

2. **Nepal Police Cyber Bureau — Contact**  
   https://cyberbureau.nepalpolice.gov.np/about-us/contact-us/  
   Official contact details and follow-up extensions. The app links to the page instead of copying mutable phone numbers into the interface.

3. **U.S. Cybersecurity and Infrastructure Security Agency (CISA) — Recognize and Report Phishing**  
   https://www.cisa.gov/secure-our-world/recognize-and-report-phishing  
   Used for general phishing warning signs and the recommendation to resist clicking and verify independently. CISA's guidance is general education and is not Nepal-specific reporting advice.

Nepali wording in the app is a plain-language educational translation and should receive review by a qualified native Nepali cybersecurity educator before institutional or official use.
