# CyberRakshak Test Report

**Test date:** 10 October 2026  
**Build:** 1.0.0 static app  
**Environment:** Node.js 24.19.0, Chromium-based in-app browser, Python localhost static server. No Android handset was available.

## Results

| Test area | Result | Evidence and limits |
|---|---|---|
| Core automated tests | **23 passed, 0 failed** | `npm test`; 17 analyzer edge cases plus 6 static security checks. |
| JavaScript syntax | **Passed** | `node --check app.js`, `core.js`, and `sw.js`. |
| Empty and malformed input | **Passed** | Empty password/URL returns no conclusion; malformed HTTP, unsupported `javascript:`/`data:` schemes, control characters, embedded whitespace, and HTML-like input are rejected without execution. |
| Oversized input | **Passed** | Passwords beyond 128 code points and URL text beyond 2,048 characters are not analyzed. |
| URL warning patterns | **Passed** | Tests cover HTTP transport, known shortener, userinfo, punycode, IP host, lure terms, and bare-host HTTPS assumption. No redirects or requests were made. |
| Privacy/security regression checks | **Passed** | Static tests find no direct network APIs or HTML parsing sinks in app/analyzer code; report source excludes raw input; CSP and same-origin service-worker guard present. |
| Browser page load | **Passed** | Local page title `CyberRakshak — Stay safer online`; local HTTP returned 200. This was not a public deployment. |
| Browser URL interaction | **Passed** | `https://bit.ly/example` displayed the shortener warning and stated that destination/redirects were unknown. |
| HTML-like URL interaction | **Passed** | `<img src=x onerror=alert(1)>` produced the invalid-address result; no injected image/script text or dialog was observed. |
| Quiz flow | **Passed** | Incorrect answer displayed feedback; answer remained after reload; remaining scenarios advanced to a final 4/5 score. Test progress was reset afterward. |
| Checklist persistence | **Passed** | A checked item remained checked after reload; test progress was reset afterward. |
| Report button | **Passed with scope limit** | Clicking the download button produced the in-app “Report downloaded” status. Source regression checks verify raw password and URL fields are excluded. The browser's resulting download file was not independently inspected. |
| Password form interaction | **Not entered in browser automation** | The browser blocks automation from filling password-type fields. No password was typed. The pure analyzer function was covered by unit tests using invented test strings; the visible form itself was not browser-filled. |
| Android/offline/PWA | **Not fully tested** | Responsive CSS and service-worker code were reviewed; no real Android device or offline-network toggle test was available. Install prompt and offline reload are not claimed as verified. |

The first test run included one **test-fixture expectation error**: a sample string has 45 code points, not 46. The assertion was corrected; the final run passed all 23 tests. This was a test-data correction, not a change to the analyzer result.

## Automated cases covered

The test suite checks empty values; common, repetitive, sequenced, Unicode, and longer password samples; configured length limits; malformed and unsupported schemes; bare domains; HTTP; shorteners; userinfo; punycode; IP hosts; lure-language paths; HTML-like input; control characters; embedded whitespace; token-like query text disclosure; outbound API absence; HTML-sink absence; CSP directives; storage key scope; report data minimization; and service-worker same-origin handling.

## What this report does not establish

It is not a penetration test, independent security audit, production hosting verification, Android compatibility certification, accessibility certification, phishing-detection efficacy evaluation, or test of any real password or URL reputation. The app's pattern results must not be interpreted as proof of safety.
