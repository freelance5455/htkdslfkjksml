# CyberRakshak Security Review

**Review date:** 10 October 2026  
**Scope:** Static frontend files in this repository; review is limited to the implemented product and listed tests, not a formal audit.

## Security-sensitive design decisions

- Password and URL checks are implemented as pure client-side functions in `core.js`. No fetch/XHR/WebSocket/beacon code, API, external script, remote font, or analytics is used.
- `index.html` includes a restrictive Content Security Policy meta tag, including `connect-src 'none'`, plus `object-src 'none'`, `base-uri 'none'`, and `form-action 'none'`. This is defense in depth; configure real HTTP headers at the chosen host.
- User-supplied URL text is parsed using the built-in `URL` parser after scheme validation and length/control-character limits. It is never assigned to `href`, `src`, an iframe, or an HTML sink, and never automatically opened.
- User-provided values and quiz/checklist copy are rendered through `textContent`, `createElement`, and text nodes. User text is not interpolated into `innerHTML`.
- No password or URL value is placed in local storage, cookies, URL parameters, console output, reports, or logs by the app. Input fields are cleared when the user selects Clear and on page hide.
- Only checklist booleans and quiz answer indexes are persisted in local storage. Invalid saved data is ignored.
- Reports omit password sample and raw URL/domain. They state what was and was not checked.
- External official guidance uses fixed URLs and `target="_blank" rel="noopener noreferrer"`. The app does not navigate to user-submitted addresses.
- The service worker caches only same-origin static files and does not cache submitted text or external pages.

## Verified checks

See `docs/TEST_REPORT.md` and `tests/core.test.js` for executable test details. Tests include empty/malformed/unsupported and long inputs, HTML-like text, userinfo, punycode, IP literal, shortener, lure words, and disclosure checks for token-like text.

## Residual risks and limitations

- The heuristics are not comprehensive. Attackers can evade patterns; legitimate links can trigger warnings. A low-warning/no-pattern result must not be described as safe.
- The app cannot detect compromised legitimate sites, malicious content, harmful downloads, phishing delivered through apps, or device compromise.
- A local browser tool still depends on the integrity of the delivered app files and browser/device. A compromised hosting account or modified static files can change app behavior.
- Browser storage may be cleared, unavailable, or included in device backups; checklist/quiz progress is not encrypted or synced.
- CSP meta directives are not equivalent to response headers. The deployment provider may add its own headers or modify delivery behavior.
- Service-worker caching can leave an older static version available until update/activation succeeds. There is no automatic update banner.
- Security and translation content have not received an independent audit or local-language review.
- The product is not a substitute for official incident response, bank support, law enforcement, or qualified security advice.

## Overall assessment

The implementation is appropriate as an educational prototype/static utility with clear limitations. It is **not production-certified** and should not be represented as antivirus, an account-protection service, or proof of link/password safety.
