import { analyzePassword, analyzeUrl } from './core.js';

const CHECKLIST_KEY = 'cyberrakshak.checklist.v1';
const QUIZ_KEY = 'cyberrakshak.quiz.v1';
const checklist = [
  { title: 'Use a different password for every important account', detail: 'Start with email and financial accounts; consider a reputable password manager.' },
  { title: 'Turn on multi-factor authentication where available', detail: 'Prefer an authenticator app or passkey when the service supports it.' },
  { title: 'Keep Android, apps, and your browser updated', detail: 'Install updates from your device settings and official app store.' },
  { title: 'Secure the phone with a screen lock', detail: 'Use a strong PIN or passphrase; protect recovery options too.' },
  { title: 'Back up important files and check that recovery works', detail: 'Keep a copy you can access if your phone is lost or damaged.' },
  { title: 'Verify money requests through a separate trusted channel', detail: 'Check the recipient and amount before sending; do not rely on a message link.' }
];
const questions = [
  {
    question: 'A text says your bank account will be frozen in 10 minutes unless you verify it through a link. What is the safest next step?',
    nepali: '“१० मिनेटभित्र पुष्टि नगरे खाता बन्द हुन्छ” भन्दै बैंकको लिंक आयो। सुरक्षित कदम के हो?',
    options: ['Tap quickly so the account stays open / खाता जोगाउन तुरुन्तै थिच्ने', 'Open the bank’s official app yourself or call a trusted number / आधिकारिक एप आफैँ खोल्ने वा चिनेको नम्बरमा फोन गर्ने', 'Reply asking whether it is real / साँचो हो कि होइन भनेर जवाफ दिने'],
    correct: 1,
    explanation: 'Urgency is a pressure tactic. Verify independently using the official app or a number you already trust; do not use the message link.',
    explanationNe: 'हतार गराउने भाषा दबाब सिर्जना गर्ने तरिका हो। सन्देशको लिंक होइन, आधिकारिक एप वा पहिलेबाटै विश्वास गरेको नम्बर प्रयोग गर्नुहोस्।'
  },
  {
    question: 'Someone claiming to be support asks you to read out a one-time code. What should you do?',
    nepali: 'सहयोगकर्मी हुँ भन्ने व्यक्तिले OTP पढेर सुनाउन भन्यो भने के गर्नुहुन्छ?',
    options: ['Share it if they know your name / नाम थाहा भएकाले दिनु', 'Share only the first half / आधा मात्र दिनु', 'Do not share it; end the contact and verify through the official service / नदिनु; सम्पर्क बन्द गरी आधिकारिक सेवाबाट पुष्टि गर्नु'],
    correct: 2,
    explanation: 'An OTP can authorize access or a transaction. Never share it with a person who contacts you; a familiar name or caller ID proves nothing.',
    explanationNe: 'OTP ले खाता पहुँच वा कारोबार स्वीकृत गर्न सक्छ। आफैँ सम्पर्क गर्ने व्यक्तिलाई नदिनुहोस्; नाम वा नम्बर देखिनुले परिचय प्रमाणित गर्दैन।'
  },
  {
    question: 'A social post promises a large prize but asks for a small “release fee” to a personal wallet. What is the best response?',
    nepali: 'ठूलो पुरस्कार दिने पोस्टले व्यक्तिगत वालेटमा “रिलिज शुल्क” माग्यो भने के गर्नुहुन्छ?',
    options: ['Pay a small amount first / थोरै रकम पहिले पठाउने', 'Pause, do not pay, and verify the offer from the organizer’s official site / रोकिने, पैसा नपठाउने र आयोजकको आधिकारिक साइटबाट पुष्टि गर्ने', 'Send your ID to reserve the prize / पुरस्कार रोक्न परिचयपत्र पठाउने'],
    correct: 1,
    explanation: 'Unexpected prizes and advance-fee requests are warning signs. Do not send money or identity documents until independently verified.',
    explanationNe: 'अप्रत्याशित पुरस्कार र पहिले पैसा माग्नु चेतावनी संकेत हुन्। छुट्टै पुष्टि नगरी पैसा वा परिचयपत्र नपठाउनुहोस्।'
  },
  {
    question: 'A friend’s account messages you asking for urgent money. Which action helps confirm it is really your friend?',
    nepali: 'साथीको खाताबाट तुरुन्त पैसा मागियो। साथी नै हो भनेर कसरी पुष्टि गर्नुहुन्छ?',
    options: ['Call the friend using the number already saved on your phone / फोनमा पहिलेबाट सुरक्षित नम्बरमा फोन गर्ने', 'Reply in the same chat and trust the answer / त्यही च्याटमा सोधेर जवाफ पत्याउने', 'Send a small test payment / जाँचका लागि थोरै पैसा पठाउने'],
    correct: 0,
    explanation: 'Accounts can be taken over. Contact your friend through a separate, previously known channel before sending money.',
    explanationNe: 'खाता अरूले चलाएको हुन सक्छ। पैसा पठाउनुअघि पहिलेदेखि थाहा भएको अर्को माध्यमबाट साथीलाई सम्पर्क गर्नुहोस्।'
  },
  {
    question: 'A link checker finds no obvious warning pattern. What does that mean?',
    nepali: 'लिंक जाँचले स्पष्ट चेतावनी संकेत भेटेन भने त्यसको अर्थ के हो?',
    options: ['The link is safe to open / लिंक खोल्न सुरक्षित छ', 'It is guaranteed to belong to the organization shown / देखाइएको संस्थाकै हो भन्ने ग्यारेन्टी भयो', 'Only that these limited patterns did not match; the link is still unverified / यति मात्र कि सीमित ढाँचाहरू भेटिएनन्; लिंक अझै अपुष्ट छ'],
    correct: 2,
    explanation: 'A pattern check cannot verify ownership, reputation, page content, redirects, or malware. No warning is not a safety verdict.',
    explanationNe: 'ढाँचा जाँचले स्वामित्व, प्रतिष्ठा, पृष्ठको सामग्री, रिडाइरेक्ट वा मालवेयर प्रमाणित गर्दैन। चेतावनी नदेखिनु सुरक्षित भएको प्रमाण होइन।'
  }
];

const $ = id => document.getElementById(id);
const passwordInput = $('password-input');
const urlInput = $('url-input');
let passwordSession = null;
let urlSession = null;
let checklistState = loadChecklist();
let quizState = loadQuiz();

function safeStorageGet(key) {
  try { return localStorage.getItem(key); } catch { return null; }
}
function safeStorageSet(key, value) {
  try { localStorage.setItem(key, value); return true; } catch { return false; }
}
function loadChecklist() {
  try {
    const parsed = JSON.parse(safeStorageGet(CHECKLIST_KEY) || 'null');
    if (Array.isArray(parsed) && parsed.length === checklist.length && parsed.every(value => typeof value === 'boolean')) return parsed;
  } catch { /* Invalid or unavailable storage starts empty. */ }
  return checklist.map(() => false);
}
function loadQuiz() {
  const fresh = { current: 0, answers: questions.map(() => null) };
  try {
    const parsed = JSON.parse(safeStorageGet(QUIZ_KEY) || 'null');
    if (!parsed || !Array.isArray(parsed.answers) || parsed.answers.length !== questions.length) return fresh;
    if (!parsed.answers.every((answer, index) => answer === null || (Number.isInteger(answer) && answer >= 0 && answer < questions[index].options.length))) return fresh;
    const current = Number.isInteger(parsed.current) && parsed.current >= 0 && parsed.current <= questions.length ? parsed.current : 0;
    return { current, answers: parsed.answers };
  } catch { return fresh; }
}
function saveQuiz() {
  safeStorageSet(QUIZ_KEY, JSON.stringify(quizState));
}
function quizScore() {
  return quizState.answers.reduce((score, answer, index) => score + (answer === questions[index].correct ? 1 : 0), 0);
}
function createEl(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function setResult(container, title, summary, findings, severity = 'neutral', caveat = '') {
  container.replaceChildren();
  container.classList.remove('hidden', 'severity-caution', 'severity-alert', 'severity-unknown');
  if (severity === 'caution') container.classList.add('severity-caution');
  else if (severity === 'alert') container.classList.add('severity-alert');
  else if (severity === 'unknown') container.classList.add('severity-unknown');
  const heading = createEl('p', 'result-title');
  heading.append(createEl('span', 'result-symbol', severity === 'alert' || severity === 'caution' ? '!' : severity === 'unknown' ? '?' : '✓'));
  heading.append(createEl('span', '', title));
  container.append(heading, createEl('p', 'result-summary', summary));
  if (findings?.length) {
    const list = createEl('ul', 'result-list');
    findings.forEach(finding => list.append(createEl('li', '', finding)));
    container.append(list);
  }
  if (caveat) container.append(createEl('p', 'result-caveat', caveat));
}
function renderPasswordResult(result) {
  const severity = result.status === 'weak' || result.status === 'too-long' ? 'alert' : result.status === 'moderate' ? 'caution' : result.status === 'empty' ? 'unknown' : 'neutral';
  const summary = result.status === 'empty' || result.status === 'too-long'
    ? 'No password strength conclusion was made.'
    : `Local pattern estimate based on length, character variety, repetition, sequences, and a small built-in common-pattern list. Result: ${result.label.toLowerCase()}.`;
  setResult($('password-result'), result.label, summary, result.findings, severity, 'This is not a breach check, password manager audit, or guarantee. Never use an existing password as a test sample.');
  passwordSession = { status: result.status, label: result.label, findings: result.findings.slice(), checked: result.status !== 'empty' && result.status !== 'too-long' };
}
function renderUrlResult(result) {
  const severity = result.status === 'caution' ? 'alert' : result.status === 'review' ? 'caution' : ['invalid', 'unsupported', 'too-long', 'empty'].includes(result.status) ? 'unknown' : 'neutral';
  const summary = result.status === 'no-obvious-pattern'
    ? 'No listed warning pattern matched. This does not establish that the link is safe or genuine.'
    : ['empty', 'invalid', 'unsupported', 'too-long'].includes(result.status)
      ? 'No safety conclusion was made; the text was not opened.'
      : 'This is a text-only pattern review. The destination was not opened and its reputation was not checked.';
  setResult($('url-result'), result.label, summary, result.findings, severity, 'Unknown: domain ownership, reputation, redirects, page behavior, downloads, and malware were not checked.');
  urlSession = { status: result.status, label: result.label, findings: result.findings.slice(), checked: !['empty', 'invalid', 'unsupported', 'too-long'].includes(result.status) };
}

$('analyze-password').addEventListener('click', () => renderPasswordResult(analyzePassword(passwordInput.value)));
passwordInput.addEventListener('input', () => {
  passwordSession = null;
  $('password-result').classList.add('hidden');
});
$('toggle-password').addEventListener('click', () => {
  const reveal = passwordInput.type === 'password';
  passwordInput.type = reveal ? 'text' : 'password';
  $('toggle-password').textContent = reveal ? 'Hide' : 'Show';
  $('toggle-password').setAttribute('aria-label', reveal ? 'Hide sample password' : 'Show sample password');
  $('toggle-password').setAttribute('aria-pressed', String(reveal));
});
$('clear-password').addEventListener('click', () => {
  passwordInput.value = '';
  passwordSession = null;
  $('password-result').replaceChildren();
  $('password-result').classList.add('hidden');
  passwordInput.focus();
});
$('analyze-url').addEventListener('click', () => renderUrlResult(analyzeUrl(urlInput.value)));
urlInput.addEventListener('input', () => {
  urlSession = null;
  $('url-result').classList.add('hidden');
});
$('clear-url').addEventListener('click', () => {
  urlInput.value = '';
  urlSession = null;
  $('url-result').replaceChildren();
  $('url-result').classList.add('hidden');
  urlInput.focus();
});

function renderChecklist() {
  const list = $('checklist-items');
  list.replaceChildren();
  checklist.forEach((item, index) => {
    const row = createEl('li', 'checklist-item');
    const label = createEl('label');
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = checklistState[index];
    input.setAttribute('aria-label', item.title);
    input.addEventListener('change', () => {
      checklistState[index] = input.checked;
      safeStorageSet(CHECKLIST_KEY, JSON.stringify(checklistState));
      updateChecklistSummary();
    });
    const text = createEl('span', '', item.title);
    text.append(createEl('small', '', item.detail));
    label.append(input, text);
    row.append(label);
    list.append(row);
  });
  updateChecklistSummary();
}
function updateChecklistSummary() {
  const done = checklistState.filter(Boolean).length;
  const percent = Math.round(done / checklist.length * 100);
  $('checklist-progress-text').textContent = `${done} of ${checklist.length} complete`;
  $('checklist-percent').textContent = `${percent}%`;
  document.querySelector('.progress-ring').setAttribute('aria-label', `Checklist progress ${percent} percent`);
  const next = checklist.findIndex((_, index) => !checklistState[index]);
  $('recommendation-title').textContent = next === -1 ? 'Keep your good habits current' : 'A good next step';
  $('recommendation-copy').textContent = next === -1 ? 'Your checklist is complete. Revisit it after changing devices, accounts, or recovery options.' : `${checklist[next].title}. ${checklist[next].detail}`;
}
$('reset-checklist').addEventListener('click', () => {
  checklistState = checklist.map(() => false);
  safeStorageSet(CHECKLIST_KEY, JSON.stringify(checklistState));
  renderChecklist();
});

function renderQuiz() {
  const content = $('quiz-content');
  const feedback = $('quiz-feedback');
  const nextButton = $('quiz-next');
  content.replaceChildren();
  feedback.replaceChildren();
  feedback.classList.add('hidden');
  feedback.classList.remove('is-wrong');
  if (quizState.current >= questions.length) {
    $('quiz-counter').textContent = `Complete · ${quizScore()} / ${questions.length}`;
    content.append(createEl('p', 'quiz-question', `You scored ${quizScore()} out of ${questions.length}. Review the explanations, then try again whenever you like.`));
    content.append(createEl('p', 'quiz-nepali', `तपाईंको अंक ${quizScore()} / ${questions.length}। उत्तरका कारणहरू फेरि पढ्नुहोस्।`));
    nextButton.disabled = true;
    nextButton.textContent = 'Quiz complete';
    $('quiz-saved-note').textContent = 'Your answers and score are saved on this device only.';
    return;
  }

  const index = quizState.current;
  const question = questions[index];
  const selected = quizState.answers[index];
  $('quiz-counter').textContent = `Question ${index + 1} of ${questions.length}`;
  content.append(createEl('p', 'quiz-question', question.question));
  content.append(createEl('p', 'quiz-nepali', question.nepali));
  const options = createEl('div', 'quiz-options');
  options.setAttribute('role', 'group');
  options.setAttribute('aria-label', `Answer choices for question ${index + 1}`);
  question.options.forEach((option, optionIndex) => {
    const button = createEl('button', 'quiz-option', option);
    button.type = 'button';
    button.disabled = selected !== null;
    if (selected !== null && optionIndex === question.correct) button.classList.add('is-correct');
    if (selected !== null && optionIndex === selected && selected !== question.correct) button.classList.add('is-wrong');
    button.addEventListener('click', () => {
      if (quizState.answers[index] !== null) return;
      quizState.answers[index] = optionIndex;
      saveQuiz();
      renderQuiz();
    });
    options.append(button);
  });
  content.append(options);

  if (selected !== null) {
    feedback.classList.remove('hidden');
    if (selected !== question.correct) feedback.classList.add('is-wrong');
    feedback.append(createEl('strong', '', selected === question.correct ? 'Correct. ' : 'Good try. '));
    feedback.append(document.createTextNode(`${question.explanation} `));
    feedback.append(createEl('span', '', question.explanationNe));
  }
  nextButton.disabled = selected === null;
  nextButton.textContent = index === questions.length - 1 ? 'See score' : 'Next question';
  $('quiz-saved-note').textContent = 'Quiz answers and progress are saved on this device only.';
}
$('quiz-next').addEventListener('click', () => {
  if (quizState.current >= questions.length || quizState.answers[quizState.current] === null) return;
  quizState.current += 1;
  saveQuiz();
  renderQuiz();
});
$('quiz-restart').addEventListener('click', () => {
  quizState = { current: 0, answers: questions.map(() => null) };
  saveQuiz();
  renderQuiz();
});

function buildReport() {
  const timestamp = new Date().toLocaleString();
  const completed = checklistState.filter(Boolean).length;
  const lines = [
    'CYBERRAKSHAK — LOCAL SESSION REPORT',
    `Generated on this device: ${timestamp}`,
    '',
    'PRIVACY',
    'This report does not include the password sample or submitted URL text/domain.',
    'Password and URL checks run locally in the current browser tab; neither is stored or sent by the app.',
    'Checklist and quiz answer progress are stored in this browser’s local storage on this device.',
    '',
    'PASSWORD PATTERN CHECK',
    passwordSession?.checked ? `Result label: ${passwordSession.label}` : 'Status: no password sample was analyzed in this session.',
    passwordSession?.checked ? `What was checked: length, character variety, repeated patterns, simple sequences, and a small common-pattern list. Findings: ${passwordSession.findings.join(' ')}` : 'Unknown: no sample was checked; breach status and account reuse are not checked by this app.',
    'Limit: this is a local heuristic, not a password audit, breach lookup, or guarantee.',
    '',
    'URL TEXT PATTERN CHECK',
    urlSession?.checked ? `Result label: ${urlSession.label}` : 'Status: no valid web-address text was analyzed in this session.',
    urlSession?.checked ? `Pattern observations: ${urlSession.findings.join(' ')}` : 'Unknown: domain ownership, reputation, redirects, page behavior, and malware are not checked.',
    'Limit: the app never opens submitted links; no warning pattern is not evidence that a link is safe.',
    '',
    'PERSONAL CHECKLIST',
    `${completed} of ${checklist.length} self-reported items marked complete. This is not a scan of the phone or accounts.`,
    '',
    'EDUCATION QUIZ',
    `${quizState.answers.filter(answer => answer !== null).length} of ${questions.length} answered; current score ${quizScore()} / ${questions.length}.`,
    '',
    'IMPORTANT UNKNOWNS',
    '- No whole-device scan, antivirus scan, network inspection, DNS/reputation lookup, or breach check was performed.',
    '- The report is educational and does not certify account, link, or device safety.',
    '- For a suspected incident, verify independently and use official service or Nepal Police Cyber Bureau channels.'
  ];
  return lines.join('\n');
}
$('download-report').addEventListener('click', () => {
  const blob = new Blob([buildReport()], { type: 'text/plain;charset=utf-8' });
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = objectUrl;
  link.download = `cyberrakshak-report-${new Date().toISOString().slice(0, 10)}.txt`;
  link.hidden = true;
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  $('report-status').textContent = 'Report downloaded. Review it before sharing; it contains local assessment summaries.';
});

renderChecklist();
renderQuiz();
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  navigator.serviceWorker.register('./sw.js').catch(() => { /* App works without offline caching. */ });
}
window.addEventListener('pagehide', () => {
  passwordInput.value = '';
  urlInput.value = '';
});
