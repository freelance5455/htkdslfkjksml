import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const app = read('../app.js');
const core = read('../core.js');
const html = read('../index.html');
const worker = read('../sw.js');

test('app and analyzers contain no direct network APIs', () => {
  const source = `${app}\n${core}`;
  assert.doesNotMatch(source, /\bfetch\s*\(|XMLHttpRequest|\bWebSocket\s*\(|sendBeacon/);
});
test('user-provided text is not inserted with an HTML parsing sink', () => {
  const source = `${app}\n${core}`;
  assert.doesNotMatch(source, /\.innerHTML\s*=|insertAdjacentHTML\s*\(/);
});
test('CSP forbids app network connections and embeds', () => {
  assert.match(html, /connect-src 'none'/);
  assert.match(html, /object-src 'none'/);
  assert.match(html, /base-uri 'none'/);
});
test('local storage keys are scoped only to checklist and quiz state', () => {
  assert.match(app, /cyberrakshak\.checklist\.v1/);
  assert.match(app, /cyberrakshak\.quiz\.v1/);
  assert.doesNotMatch(app, /localStorage\.setItem\s*\(\s*['"](?:password|url|input)/i);
});
test('report code excludes raw password and URL input values', () => {
  const report = app.slice(app.indexOf('function buildReport()'), app.indexOf("$('download-report')"));
  assert.doesNotMatch(report, /passwordInput\.value|urlInput\.value/);
  assert.match(report, /does not include the password sample or submitted URL text\/domain/);
});
test('service worker does not intercept cross-origin requests', () => {
  assert.match(worker, /if\s*\(url\.origin\s*!==\s*self\.location\.origin\)\s*return/);
});
