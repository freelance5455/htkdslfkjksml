import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzePassword, analyzeUrl, MAX_URL_LENGTH, MAX_PASSWORD_LENGTH } from '../core.js';

test('password analyzer handles empty input without inventing a result', () => {
  const result = analyzePassword('');
  assert.equal(result.status, 'empty');
  assert.equal(result.score, 0);
});
test('password analyzer recognizes common and repetitive patterns', () => {
  assert.equal(analyzePassword('password123').status, 'weak');
  assert.equal(analyzePassword('aaaaaaaaaaaa').status, 'weak');
  assert.ok(analyzePassword('qwerty12345').findings.some(finding => /sequence/i.test(finding)));
});
test('long varied invented sample gets a stronger-looking heuristic label', () => {
  const result = analyzePassword('Saffron-Clouds-Drift-Above-Quiet-Mountains-47');
  assert.equal(result.status, 'stronger');
  assert.equal(result.length, 45);
});
test('password inputs above the supported limit are not analyzed', () => {
  const result = analyzePassword('x'.repeat(MAX_PASSWORD_LENGTH + 1));
  assert.equal(result.status, 'too-long');
  assert.equal(result.score, 0);
});
test('Unicode password length is counted by code point', () => {
  const result = analyzePassword('क'.repeat(12) + 'A1!');
  assert.equal(result.length, 15);
  assert.notEqual(result.status, 'empty');
});
test('URL analyzer handles empty input and does not return a safe verdict', () => {
  assert.equal(analyzeUrl('  ').status, 'empty');
  const result = analyzeUrl('https://example.com');
  assert.equal(result.status, 'no-obvious-pattern');
  assert.doesNotMatch(result.label, /safe|trusted/i);
  assert.match(result.findings[0], /does not show/i);
});
test('URL analyzer catches malformed and unsupported schemes without execution', () => {
  assert.equal(analyzeUrl('http://').status, 'invalid');
  assert.equal(analyzeUrl('javascript:alert(1)').status, 'unsupported');
  assert.equal(analyzeUrl('data:text/html,<script>alert(1)</script>').status, 'unsupported');
});
test('URL analyzer accepts a bare host but states that https was assumed', () => {
  const result = analyzeUrl('example.com/path');
  assert.equal(result.assumedHttps, true);
  assert.ok(result.findings.some(finding => /https was assumed/i.test(finding)));
});
test('URL analyzer detects a plain HTTP transport caution', () => {
  const result = analyzeUrl('http://example.com/');
  assert.ok(result.findings.some(finding => /unencrypted http/i.test(finding)));
  assert.notEqual(result.status, 'no-obvious-pattern');
});
test('URL analyzer flags a known shortener but does not resolve its redirect', () => {
  const result = analyzeUrl('https://bit.ly/example');
  assert.ok(result.findings.some(finding => /shortening domain/i.test(finding)));
  assert.ok(result.unknowns.some(finding => /redirects/i.test(finding)));
});
test('URL analyzer detects userinfo and punycode host patterns', () => {
  assert.ok(analyzeUrl('https://trusted.example@evil.example/').findings.some(finding => /user-information/i.test(finding)));
  assert.ok(analyzeUrl('https://xn--80ak6aa92e.com/').findings.some(finding => /punycode/i.test(finding)));
});
test('URL analyzer detects IP hosts and lure language in path/query', () => {
  assert.ok(analyzeUrl('http://192.0.2.1/verify').findings.some(finding => /IP address/i.test(finding)));
  assert.ok(analyzeUrl('https://example.com/urgent-login').findings.some(finding => /commonly used/i.test(finding)));
});
test('very long URL text is rejected before parsing', () => {
  const result = analyzeUrl('https://example.com/' + 'a'.repeat(MAX_URL_LENGTH));
  assert.equal(result.status, 'too-long');
  assert.equal(result.hostname, undefined);
});
test('unsafe HTML-like text is treated only as invalid URL text', () => {
  const result = analyzeUrl('<img src=x onerror=alert(1)>');
  assert.equal(result.status, 'invalid');
  assert.equal(result.hostname, undefined);
  assert.equal(result.findings.some(finding => /<img/i.test(finding)), false);
});
test('embedded control characters are rejected', () => {
  assert.equal(analyzeUrl('https://example.com/\u0000x').status, 'invalid');
});
test('embedded whitespace in a URL is rejected instead of normalized', () => {
  assert.equal(analyzeUrl('https://example.com/path with space').status, 'invalid');
});
test('private token-like query text is never copied into analyzer findings', () => {
  const secret = 'dont-log-this-unique-token';
  const result = analyzeUrl(`https://example.com/?access_token=${secret}`);
  assert.equal(JSON.stringify(result).includes(secret), false);
});
