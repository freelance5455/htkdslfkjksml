# CyberRakshak Limitations

CyberRakshak is an educational helper, **not a security certification or incident-response service**.

## Not implemented

- No malware scanning, antivirus, device inventory, vulnerability scan, network monitoring, or account inspection.
- No URL reputation/blacklist query, DNS lookup, redirect expansion, webpage fetch, sandboxing, TLS certificate validation, or content inspection.
- No password breach database lookup, strength standard certification, account reuse detection, password-manager integration, or secure password vault.
- No automated Nepal Police complaint submission or financial institution contact.
- No user accounts, cloud synchronization, multi-device progress, telemetry, or administrative console.

## How to interpret results

- A password label is a simple heuristic based on length, character variety, repeated characters, sequences, and a small set of common patterns. It can miss common or compromised passwords and can mis-rank unusual passphrases.
- A URL warning is a pattern, not proof of malicious intent. A link with no listed warning pattern can still be fraudulent or compromised. A warning can also be a false positive.
- An HTTPS prefix only describes encrypted transport to some host; it does not prove that the host is legitimate.
- The checklist is self-reported. It does not verify whether a setting is enabled or whether backups work.
- Quiz answers measure familiarity with these examples, not real-world readiness.
- Offline caching depends on a secure origin (HTTPS or localhost), browser support, storage availability, and successful first load. It is not guaranteed in file:// mode.

## Not yet production-ready

- No independent security audit, penetration test, formal threat model, or third-party accessibility audit has been completed.
- Educational copy and Nepali translations need review by local cybersecurity educators and native-language reviewers.
- Pattern rules and common-password examples need a documented maintenance process and adversarial test corpus.
- Hosting headers (including a strict HTTP Content-Security-Policy header, HSTS, and MIME/security headers) depend on the chosen host. The bundled meta policy is a defense-in-depth measure, not a substitute for server headers.
- No version/update notification or feedback/reporting workflow is included.
