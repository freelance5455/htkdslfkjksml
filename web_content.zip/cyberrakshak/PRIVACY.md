# CyberRakshak Privacy Notice

**Last updated: 10 October 2026**

CyberRakshak is a static educational web app. It has no account system, analytics, advertising, backend API, or third-party JavaScript.

## What stays on your device

- Password sample text is processed in the currently open browser tab only. It is not sent by the app and is not written to local storage. The app displays a reminder to use an invented sample, never an active password.
- URL text is parsed in the currently open browser tab only. CyberRakshak never opens the submitted URL, follows redirects, makes a reputation query, or saves the text.
- Checklist selections and quiz answer indexes are saved in this browser's local storage so progress can persist on this device. They contain no password or submitted URL.
- A report is composed locally and downloaded only when you tap the download button. It excludes the password sample and raw URL/domain but may include check labels, pattern observations, checklist completion, quiz score, and the time it was created. Review it before sharing.

## Network behavior

The app's Content Security Policy sets `connect-src 'none'`, and its JavaScript contains no network request code. A same-origin service worker may cache the app's static files for offline use when served from HTTPS or localhost. External guidance pages are opened only after you choose a clearly labeled link; those sites then apply their own privacy policies.

Your browser, Android operating system, hosting provider, or network may maintain its own logs or backups. CyberRakshak cannot control those platform-level records.

## Clearing local progress

Use **Reset checklist** to clear checklist choices. Use **Start over** in the quiz to reset quiz answers. You can clear all site data for CyberRakshak in your browser's site settings to remove both stored values. Closing the tab clears password and URL input fields.

## Safety reminder

Do not enter real passwords, OTPs, PINs, banking credentials, or private tokens. Do not paste a link containing personal or one-time access tokens. The password check is only a local heuristic; the URL check is only a local pattern review.
