# CyberRakshak

A mobile-first, static cybersecurity learning app with local-only password and URL pattern checks, Nepali/English scam lessons and quiz, a personal checklist, and downloadable session reports.

## What works

- **Password sample check:** browser-only heuristic. Use an invented sample; do not enter a password you currently use. The sample is not saved or sent.
- **Suspicious URL text check:** pattern analysis only. It never opens the submitted text or follows redirects. A clear result is **not** a safety verdict.
- **Nepali/English learning and quiz:** five fictional scam scenarios with explanations.
- **Checklist:** six self-reported actions saved in this browser's local storage.
- **Report:** downloads a local `.txt` summary of what was checked and what remains unknown; excludes the password sample and raw URL/domain.
- **Installable static site:** a same-origin service worker caches app files when served on HTTPS or localhost. No external libraries, fonts, analytics, or APIs.

See [PRIVACY.md](./PRIVACY.md) and [LIMITATIONS.md](./LIMITATIONS.md) before use.

## Android: quickest safe way to use it

The app is designed for Android Chrome on an HTTPS site. This task did not publish it, because no hosting account was authorized. To use it now, publish the folder using the free steps below, then:

1. Open the published HTTPS address in Chrome on your Android phone.
2. Wait for the first load to finish while online. The app files can then be cached for offline use; offline behavior depends on browser storage and service-worker support.
3. Optional: in Chrome, open the menu and choose **Install app** or **Add to Home screen** if offered.
4. Use the link checker only for text you already have. It does not open the link. Never enter an active password—use only an invented example in the password tool.
5. To erase checklist/quiz progress, reset them inside the app or clear the site's data in Chrome settings.

Opening `index.html` directly from the Android Files app (`file://`) may not load JavaScript modules or allow offline installation. Use an HTTPS host or a local development server instead.

## Publish free using GitHub Pages (manual, no secrets in this app)

You need a free GitHub account and must choose a repository you control. GitHub will host the static files; this app has no server-side component.

1. On your phone or computer, sign in to GitHub and create a **new public repository** (for example, `cyberrakshak`). Do not upload passwords, keys, personal test inputs, or private user data.
2. From the repository page, use **Add file → Upload files**. Upload the contents of this folder (including `index.html`, `core.js`, `app.js`, `styles.css`, `sw.js`, `manifest.webmanifest`, `assets/`, `PRIVACY.md`, and `LIMITATIONS.md`). Keep the folder structure intact and commit the upload.
3. In the repository, open **Settings → Pages**. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Wait for GitHub Pages to finish. GitHub shows the published HTTPS URL under **Settings → Pages**. Open it and test the password checker with an invented sample, URL checker with a harmless example such as `https://example.com`, quiz, checklist persistence, and report download.
5. If you later make updates, upload/commit the changed files. Check the live URL after every change.

GitHub's interface and free-tier terms may change. Publishing makes source and documentation public. Do not include secrets or real credentials. If you prefer another provider, Cloudflare Pages and Netlify also have free static hosting options but require your own account and acceptance of their terms. No provider account was used or created for this task.

## Run locally for development

From this folder:

```sh
python3 -m http.server 8000
```

Open `http://localhost:8000` in a desktop browser. Service workers work on localhost. The core unit tests need Node.js 18 or later:

```sh
node --test tests/core.test.js
```

## Project files

- `index.html` — accessible app structure and source links
- `styles.css` — responsive interface and reduced-motion styling
- `app.js` — app interactions, local persistence, quiz, and report export
- `core.js` — pure, testable password and URL pattern analysis
- `sw.js` / `manifest.webmanifest` — optional same-origin offline cache / install metadata
- `tests/core.test.js` — automated edge-case tests
- `docs/TEST_REPORT.md` — test results and test scope
- `docs/SECURITY_REVIEW.md` — security decisions and residual risks
- `docs/UNFINISHED_WORK.md` — work required before production use

## Educational sources

- [Nepal Police Cyber Bureau: report a cybercrime](https://cyberbureau.nepalpolice.gov.np/report-cyber-crime/)
- [Nepal Police Cyber Bureau: official contact page](https://cyberbureau.nepalpolice.gov.np/about-us/contact-us/)
- [CISA: Recognize and Report Phishing](https://www.cisa.gov/secure-our-world/recognize-and-report-phishing)

The linked pages are external and are opened only when selected. Verify current reporting details on the official site.
