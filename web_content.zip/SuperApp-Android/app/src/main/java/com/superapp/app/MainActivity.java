package com.superapp.app;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    static final String HOST = "appassets.androidplatform.net";
    static final String START = "https://" + HOST + "/assets/index.html";

    private WebView web;
    private SpeechRecognizer sr;
    private PermissionRequest pendingWebPerm;
    private GeolocationPermissions.Callback geoCb;
    private String geoOrigin;
    private boolean startAfterPerm = false;
    private String pendingLang = "ar-EG";
    private String lastUrl = "";
    private long lastTime = 0;
    private ActivityResultLauncher<String[]> permLauncher;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        permLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), res -> {
            boolean audio = has(Manifest.permission.RECORD_AUDIO);
            boolean loc = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (pendingWebPerm != null) {
                if (audio) pendingWebPerm.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                else pendingWebPerm.deny();
                pendingWebPerm = null;
            }
            if (geoCb != null) { geoCb.invoke(geoOrigin, loc, false); geoCb = null; }
            if (startAfterPerm) {
                startAfterPerm = false;
                if (audio) startSR(pendingLang); else js("error", "not-allowed", false);
            }
        });

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, i) -> {
            Insets bars = i.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            Insets ime = i.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });
        WindowInsetsControllerCompat ctl = new WindowInsetsControllerCompat(getWindow(), root);
        ctl.setAppearanceLightStatusBars(false);
        ctl.setAppearanceLightNavigationBars(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return handleUrl(r.getUrl().toString());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    boolean ours = req.getOrigin() != null && HOST.equals(req.getOrigin().getHost());
                    boolean audio = false;
                    for (String r : req.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
                    if (!ours || !audio) { req.deny(); return; }
                    if (has(Manifest.permission.RECORD_AUDIO)) {
                        req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingWebPerm = req;
                        permLauncher.launch(new String[]{Manifest.permission.RECORD_AUDIO});
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    cb.invoke(origin, true, false);
                } else {
                    geoCb = cb; geoOrigin = origin;
                    permLauncher.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
                }
            }

            /* window.open(...) → يُفتح خارجيًا (متصفح أو تطبيق) */
            @Override
            public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message resultMsg) {
                final WebView tmp = new WebView(MainActivity.this);
                final boolean[] done = {false};
                tmp.setWebViewClient(new WebViewClient() {
                    private void go(WebView w, String u) {
                        if (done[0] || u == null || u.equals("about:blank")) return;
                        done[0] = true;
                        handleUrl(u);
                        w.stopLoading();
                        w.post(w::destroy);
                    }
                    @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r) { go(w, r.getUrl().toString()); return true; }
                    @Override public void onPageStarted(WebView w, String u, Bitmap f) { go(w, u); }
                });
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                String closer = "(function(){var d=document.querySelector('#dr.open');if(d){d.classList.remove('open');return 1}"
                        + "var o=document.querySelector('#cms.on');if(o){o.click();return 1}"
                        + "var ov=document.querySelector('.ovl.on,.ovl.open');if(ov){var x=document.getElementById('xo');if(x){x.click();return 1}}return 0})()";
                web.evaluateJavascript(closer, v -> {
                    if ("1".equals(v)) return;
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                });
            }
        });

        if (b == null) web.loadUrl(START); else web.restoreState(b);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    protected void onDestroy() {
        if (sr != null) { sr.destroy(); sr = null; }
        web.destroy();
        super.onDestroy();
    }

    private boolean has(String p) { return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED; }

    /* ===== فتح الروابط: ما كان داخل التطبيق يبقى، وكل شيء آخر يُسلَّم لنظام أندرويد ===== */
    private boolean handleUrl(String url) {
        if (url == null) return true;
        if (url.startsWith("https://" + HOST)) return false;
        long now = System.currentTimeMillis();
        if (url.equals(lastUrl) && now - lastTime < 1500) return true; // منع الفتح المزدوج
        lastUrl = url; lastTime = now;
        try {
            if (url.startsWith("intent:")) {
                Intent in = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                in.addCategory(Intent.CATEGORY_BROWSABLE);
                in.setComponent(null);
                in.setSelector(null);
                try {
                    startActivity(in);
                } catch (ActivityNotFoundException e) {
                    String fb = in.getStringExtra("browser_fallback_url");
                    if (fb != null) open(fb);
                    else if (in.getPackage() != null) open("market://details?id=" + in.getPackage());
                    else toast("التطبيق غير مثبّت");
                }
            } else {
                open(url);
            }
        } catch (Exception e) {
            toast("تعذّر الفتح");
        }
        return true;
    }

    private void open(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            toast("لا يوجد تطبيق لفتح هذا الرابط");
        }
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    /* ===== الأوامر الصوتية: SpeechRecognizer الأصلي (WebView لا يدعم Web Speech) ===== */
    private void js(final String type, final String a, final boolean b) {
        final String call = "window.__saSR&&window.__saSR(" + JSONObject.quote(type) + "," + JSONObject.quote(a == null ? "" : a) + "," + b + ")";
        web.post(() -> web.evaluateJavascript(call, null));
    }

    private void startSR(String lang) {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            pendingLang = lang; startAfterPerm = true;
            permLauncher.launch(new String[]{Manifest.permission.RECORD_AUDIO});
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("error", "service-not-allowed", false); js("end", "", false); return; }
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle p) { js("start", "", false); }
                @Override public void onPartialResults(Bundle p) { String t = first(p); if (t != null) js("result", t, false); }
                @Override public void onResults(Bundle p) { String t = first(p); if (t != null) js("result", t, true); js("end", "", false); }
                @Override public void onError(int e) {
                    String code = (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) ? "no-speech"
                            : e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ? "not-allowed"
                            : (e == SpeechRecognizer.ERROR_NETWORK || e == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) ? "network" : "aborted";
                    js("error", code, false); js("end", "", false);
                }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float v) {}
                @Override public void onBufferReceived(byte[] bf) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onEvent(int i, Bundle p) {}
                private String first(Bundle p) {
                    ArrayList<String> l = p == null ? null : p.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    return (l == null || l.isEmpty()) ? null : l.get(0);
                }
            });
        }
        Intent in = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        in.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        in.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        in.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        sr.startListening(in);
    }

    private class Bridge {
        @JavascriptInterface public void startListening(final String lang) { runOnUiThread(() -> startSR(lang == null ? "ar-EG" : lang)); }
        @JavascriptInterface public void stopListening() { runOnUiThread(() -> { if (sr != null) sr.stopListening(); }); }
        @JavascriptInterface public boolean available() { return SpeechRecognizer.isRecognitionAvailable(MainActivity.this); }
    }
}
