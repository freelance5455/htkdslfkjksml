RAZAN Pharmacy Android project

Build APK:
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

The existing HTML app is packaged at app/src/main/assets/index.html.
Data stored by the HTML app uses WebView local storage on this device.
Cloud sync requiring the original Claude-hosted runtime is not available in a standalone APK unless separately integrated.
