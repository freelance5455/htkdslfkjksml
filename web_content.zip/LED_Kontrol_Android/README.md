# LED Kontrol — Native BLE V3

Bu sürüm Web Bluetooth kullanmaz. ELK-BLEDOM bağlantısı Android'in native BluetoothGatt API'si ile yapılır.

## Önemli
Android Studio'da **Clean Project** ardından **Rebuild Project** yapıp yeni APK'yı kurun. Eski APK'nın üzerine sadece asset/HTML kopyalamayın.

## V3 düzeltmeleri
- WebView içine AndroidBle köprüsü yüklenmeden sayfa kullanılmıyor.
- Köprü `native-ble-2` sürümüyle doğrulanıyor.
- Sayfa açıldığında bridge handshake yapılıyor.
- Web Bluetooth fallback yok.
- Android BLE tarama ve GATT bağlantısı korunuyor.
- FFF0/FFF3 ve FFE5/FFE9 yazma kanalları korunuyor.
- RECORD_AUDIO WebView izni korunuyor.
