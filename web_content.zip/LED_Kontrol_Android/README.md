# LED Kontrol ELK-BLEDOM - Android Native BLE

Bu proje mevcut V7 HTML arayüzünü Android WebView içinde korur ve Web Bluetooth yerine Android'in native BLE/GATT API'sini kullanır.

## Özellikler
- ELK-BLEDOM tarama
- FFF0/FFF3 ve FFE5/FFE9 yazma kanalı desteği
- Android 12+ BLUETOOTH_SCAN / CONNECT izinleri
- Eski Android sürümlerinde gerekli konum izni
- WebView mikrofon izni köprüsü
- Mevcut HTML renk/efekt/mikrofon arayüzü korunur

## Android Studio
1. ZIP'i açın.
2. Android Studio > Open ile `LED_Kontrol_Android` klasörünü açın.
3. Gradle senkronizasyonunu tamamlayın.
4. Telefonda Bluetooth'u açın ve uygulamaya Bluetooth izni verin.
5. Uygulamayı çalıştırın.

Not: YouTube Music sekme-sesi yakalama, Android/WebView ve uygulama tarafından verilen medya yakalama izinlerine bağlıdır. Native BLE artık Web Bluetooth'a bağlı değildir.
