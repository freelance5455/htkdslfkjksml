package com.ledkontrol.elkbledom;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import android.webkit.WebResourceResponse;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BLE = 501;
    private static final int REQ_AUDIO = 502;
    private static final int REQ_ENABLE_BT = 503;
    private static final UUID SVC_FFF0 = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb");
    private static final UUID CH_FFF3 = UUID.fromString("0000fff3-0000-1000-8000-00805f9b34fb");
    private static final UUID SVC_FFE5 = UUID.fromString("0000ffe5-0000-1000-8000-00805f9b34fb");
    private static final UUID CH_FFE9 = UUID.fromString("0000ffe9-0000-1000-8000-00805f9b34fb");

    private WebView web;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic writeChar;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean scanning = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        BluetoothManager bm = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm.getAdapter();
        setupWeb();
    }

    private void setupWeb() {
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return loader.shouldInterceptRequest(android.net.Uri.parse(url));
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Bridge is installed before loadUrl; verify it from inside the page.
                view.evaluateJavascript("(function(){try{return typeof window.AndroidBle + '|' + (window.AndroidBle ? AndroidBle.version() : 'missing')}catch(e){return 'error:'+e}})()", value -> {
                    String v = value == null ? "" : value;
                    if (v.contains("object|native-ble-2")) {
                        runJs("window.nativeAndroidReady && window.nativeAndroidReady('native-ble-2')");
                    } else {
                        runJs("window.nativeBleError && window.nativeBleError('Native Android BLE köprüsü WebView'a yüklenemedi. Uygulama sürümünü tamamen kapatıp yeniden açın.')");
                    }
                });
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean audioGranted = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                    if (audioGranted) request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    else { pendingPermissionRequest = request; requestAudioPermission(); }
                });
            }
        });
        web.addJavascriptInterface(new AndroidBleBridge(), "AndroidBle");
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        setContentView(web);
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private PermissionRequest pendingPermissionRequest;

    private void requestAudioPermission() {
        if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
    }

    private boolean hasBlePermission() {
        if (Build.VERSION.SDK_INT >= 31)
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBlePermission() {
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BLE);
        else if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BLE);
        else startScan();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ENABLE_BT) {
            if (adapter != null && adapter.isEnabled()) startScan();
            else jsError("Bluetooth açılmadı.");
        }
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQ_BLE) {
            if (hasBlePermission()) startScan(); else jsError("Bluetooth izni verilmedi.");
        } else if (req == REQ_AUDIO && pendingPermissionRequest != null) {
            boolean ok = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            PermissionRequest r = pendingPermissionRequest; pendingPermissionRequest = null;
            if (ok) r.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE}); else r.deny();
        }
    }

    private void startScan() {
        if (adapter == null || !adapter.isEnabled()) {
            try { startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT); } catch(Exception e) { jsError("Bluetooth kapalı."); }
            return;
        }
        if (!hasBlePermission()) { requestBlePermission(); return; }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { jsError("BLE tarayıcısı kullanılamıyor."); return; }
        if (scanning) return;
        scanning = true;
        scanner.startScan(scanCallback);
        handler.postDelayed(() -> stopScan(), 12000);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String name = null;
            try { name = d.getName(); } catch(SecurityException ignored) {}
            if (name == null && result.getScanRecord() != null) name = result.getScanRecord().getDeviceName();
            if (name != null && name.toUpperCase().startsWith("ELK-BLEDOM")) {
                stopScan();
                String address = d.getAddress();
                final String n = name;
                runJs("window.nativeBleFound(" + q(n) + "," + q(address) + ")");
            }
        }
        @Override public void onScanFailed(int errorCode) { scanning = false; jsError("BLE tarama hatası: " + errorCode); }
    };

    private void stopScan() {
        if (!scanning || scanner == null) return;
        try { scanner.stopScan(scanCallback); } catch(SecurityException ignored) {}
        scanning = false;
    }

    private void connect(String address) {
        if (!hasBlePermission()) { requestBlePermission(); return; }
        try {
            BluetoothDevice d = adapter.getRemoteDevice(address);
            if (gatt != null) { try { gatt.disconnect(); gatt.close(); } catch(Exception ignored) {} }
            writeChar = null;
            gatt = d.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch(Exception e) { jsError("Bağlantı başlatılamadı: " + e.getMessage()); }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothGatt.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                gatt = g;
                runJs("window.nativeBleConnecting && window.nativeBleConnecting()");
                try { g.discoverServices(); } catch(Exception e) { jsError("Servisler okunamadı."); }
            } else if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                writeChar = null;
                runJs("window.nativeBleDisconnected && window.nativeBleDisconnected()");
                try { g.close(); } catch(Exception ignored) {}
                if (gatt == g) gatt = null;
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) { jsError("BLE servisleri bulunamadı."); return; }
            BluetoothGattCharacteristic found = findWritable(g.getService(SVC_FFF0), CH_FFF3);
            String svc = SVC_FFF0.toString(), ch = CH_FFF3.toString();
            if (found == null) { found = findWritable(g.getService(SVC_FFE5), CH_FFE9); svc = SVC_FFE5.toString(); ch = CH_FFE9.toString(); }
            if (found == null) { jsError("ELK-BLEDOM yazma kanalı bulunamadı (FFF3/FFE9)."); return; }
            writeChar = found;
            if ((found.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) found.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
            else found.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            runJs("window.nativeBleConnected(" + q(svc) + "," + q(ch) + ")");
        }
    };

    private BluetoothGattCharacteristic findWritable(BluetoothGattService svc, UUID preferred) {
        if (svc == null) return null;
        BluetoothGattCharacteristic c = svc.getCharacteristic(preferred);
        if (c != null && (c.getProperties() & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) return c;
        for (BluetoothGattCharacteristic x : svc.getCharacteristics()) {
            if ((x.getProperties() & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) return x;
        }
        return null;
    }

    private void writeHex(String hex) {
        if (gatt == null || writeChar == null) { jsError("ELK-BLEDOM bağlı değil."); return; }
        try {
            byte[] b = new byte[hex.length()/2];
            for (int i=0;i<b.length;i++) b[i]=(byte)Integer.parseInt(hex.substring(i*2,i*2+2),16);
            writeChar.setValue(b);
            boolean ok = gatt.writeCharacteristic(writeChar);
            if (!ok) handler.postDelayed(() -> writeHex(hex), 8);
        } catch(Exception e) { jsError("BLE yazma hatası: " + e.getMessage()); }
    }

    private void disconnect() {
        stopScan();
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch(Exception ignored) {}
        gatt = null; writeChar = null;
        runJs("window.nativeBleDisconnected && window.nativeBleDisconnected()");
    }

    private void runJs(String js) { runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); }); }
    private void jsError(String msg) { runJs("window.nativeBleError && window.nativeBleError(" + q(msg) + ")"); }
    private static String q(String s) { return org.json.JSONObject.quote(s == null ? "" : s); }

    public final class AndroidBleBridge {
        @JavascriptInterface public final void scan() { runOnUiThread(() -> { if (!hasBlePermission()) requestBlePermission(); else startScan(); }); }
        @JavascriptInterface public final void connect(String address) { runOnUiThread(() -> MainActivity.this.connect(address)); }
        @JavascriptInterface public final void disconnect() { runOnUiThread(MainActivity.this::disconnect); }
        @JavascriptInterface public final boolean isReady() { return gatt != null && writeChar != null; }
        @JavascriptInterface public final String version() { return "native-ble-2"; }
        @JavascriptInterface public final void write(String hex) { runOnUiThread(() -> writeHex(hex)); }
    }

    @Override protected void onDestroy() {
        stopScan();
        try { if (gatt != null) gatt.close(); } catch(Exception ignored) {}
        gatt = null; writeChar = null;
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
