// ============================================================
// Zlez.Id - WhatsApp Bot Backend + Global Chat (REAL)
// ============================================================
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const QRCode = require('qrcode');
const path = require('path');
const fs = require('fs');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  Browsers,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const P = require('pino');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// ============================================================
// GLOBAL CHAT STORAGE
// ============================================================
const CHAT_FILE = path.join(__dirname, 'chat_history.json');
const MAX_MESSAGES = 200; // simpan max 200 pesan terakhir
let chatMessages = [];

// Load history dari file
try {
  if (fs.existsSync(CHAT_FILE)) {
    chatMessages = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
    console.log(`💬 Load ${chatMessages.length} pesan chat dari history`);
  }
} catch (e) {
  console.warn('Gagal load chat history:', e.message);
}

function saveChatHistory() {
  try {
    fs.writeFileSync(CHAT_FILE, JSON.stringify(chatMessages.slice(-MAX_MESSAGES)));
  } catch (e) {
    console.warn('Gagal simpan chat:', e.message);
  }
}

// Online users tracking
const onlineUsers = new Map(); // socketId -> { username, color, joinedAt }

// ============================================================
// WHATSAPP BOT
// ============================================================
let sock = null;
let isConnected = false;
let currentQR = null;
let currentPairingCode = null;

async function connectToWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info');
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    browser: Browsers.macOS('Safari'),
    logger: P({ level: 'silent' }),
    markOnlineOnConnect: false,
    syncFullHistory: false,
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      currentQR = qr;
      try {
        const qrDataURL = await QRCode.toDataURL(qr, {
          width: 280,
          margin: 1,
          color: { dark: '#000000', light: '#ffffff' },
        });
        io.emit('qr_update', { qr: qrDataURL });
      } catch (err) {
        console.error('QR error:', err);
      }
    }

    if (connection === 'open') {
      console.log('✅ WhatsApp terhubung!');
      isConnected = true;
      currentQR = null;
      currentPairingCode = null;
      io.emit('connection_status', { status: 'connected' });
    }

    if (connection === 'close') {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log('❌ Disconnect:', statusCode);
      isConnected = false;
      io.emit('connection_status', { status: 'disconnected' });
      if (shouldReconnect) connectToWhatsApp();
    }
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;
    const text = msg.message.conversation ||
                 msg.message.extendedTextMessage?.text || '';
    console.log('📩 WA masuk:', text);
    if (text.toLowerCase() === 'ping') {
      await sock.sendMessage(msg.key.remoteJid, { text: 'pong! 🏓' });
    }
  });

  return sock;
}

// ============================================================
// SOCKET.IO
// ============================================================
io.on('connection', (socket) => {
  console.log('🔌 Client terhubung:', socket.id);

  // ---- WA status ----
  socket.emit('connection_status', {
    status: isConnected ? 'connected' : 'disconnected',
  });
  if (currentQR) {
    QRCode.toDataURL(currentQR, { width: 280, margin: 1 }).then((url) => {
      socket.emit('qr_update', { qr: url });
    });
  }

  // ============================================================
  // GLOBAL CHAT - JOIN
  // ============================================================
  socket.on('chat_join', ({ username }) => {
    const colors = ['#4facfe', '#a855f7', '#ec4899', '#f97316', '#25D366', '#facc15', '#06b6d4'];
    const color = colors[Math.floor(Math.random() * colors.length)];
    onlineUsers.set(socket.id, {
      username: username || 'Anonim',
      color,
      joinedAt: Date.now(),
    });

    // Kirim history ke user baru
    socket.emit('chat_history', {
      messages: chatMessages.slice(-50),
      onlineCount: onlineUsers.size,
    });

    // Broadcast sistem message
    const sysMsg = {
      type: 'system',
      text: `👋 ${username} bergabung ke chat`,
      ts: Date.now(),
    };
    io.emit('chat_system', sysMsg);
    broadcastOnline();

    console.log(`💬 ${username} join chat (${onlineUsers.size} online)`);
  });

  // ============================================================
  // GLOBAL CHAT - KIRIM PESAN
  // ============================================================
  socket.on('chat_send', ({ text }) => {
    const user = onlineUsers.get(socket.id);
    if (!user || !text) return;

    const trimmed = String(text).trim().slice(0, 500); // max 500 char
    if (!trimmed) return;

    const msg = {
      type: 'user',
      id: Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      username: user.username,
      color: user.color,
      text: trimmed,
      ts: Date.now(),
    };

    chatMessages.push(msg);
    if (chatMessages.length > MAX_MESSAGES) {
      chatMessages = chatMessages.slice(-MAX_MESSAGES);
    }
    saveChatHistory();

    io.emit('chat_message', msg);
  });

  // ============================================================
  // GLOBAL CHAT - TYPING
  // ============================================================
  socket.on('chat_typing', () => {
    const user = onlineUsers.get(socket.id);
    if (!user) return;
    socket.broadcast.emit('chat_typing', { username: user.username });
  });

  // ============================================================
  // PAIRING CODE
  // ============================================================
  socket.on('request_pairing_code', async ({ phoneNumber }) => {
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    if (cleanNumber.length < 10) {
      socket.emit('pairing_error', { message: 'Nomor tidak valid' });
      return;
    }
    try {
      if (!sock) return socket.emit('pairing_error', { message: 'Bot belum siap' });
      if (sock.authState.creds.registered) {
        return socket.emit('pairing_error', { message: 'Sudah terdaftar' });
      }
      const code = await sock.requestPairingCode(cleanNumber);
      currentPairingCode = code;
      socket.emit('pairing_code', { code: code.match(/.{1,4}/g).join('-') });
    } catch (err) {
      socket.emit('pairing_error', { message: err.message });
    }
  });

  socket.on('check_status', () => {
    socket.emit('connection_status', {
      status: isConnected ? 'connected' : 'disconnected',
    });
  });

  // ============================================================
  // DISCONNECT
  // ============================================================
  socket.on('disconnect', () => {
    const user = onlineUsers.get(socket.id);
    if (user) {
      const sysMsg = {
        type: 'system',
        text: `👋 ${user.username} keluar dari chat`,
        ts: Date.now(),
      };
      io.emit('chat_system', sysMsg);
      onlineUsers.delete(socket.id);
      broadcastOnline();
    }
    console.log('🔌 Client disconnect:', socket.id);
  });
});

function broadcastOnline() {
  io.emit('chat_online', {
    count: onlineUsers.size,
    users: Array.from(onlineUsers.values()).map(u => ({
      username: u.username,
      color: u.color,
    })),
  });
}

// ============================================================
// START
// ============================================================
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Zlez.Id server: http://localhost:${PORT}`);
  console.log(`🌐 Browser: macOS Safari`);
  console.log(`💬 Global Chat: AKTIF`);
  connectToWhatsApp();
});