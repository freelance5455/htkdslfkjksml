/* Karen's PromoTrack v7: quick scan, daily overview, emergency external backup. */
'use strict';
function v7DailySummary(){
  const el=$('v7SummaryBody');if(!el)return;
  const today=localDate();
  const sold=sales().filter(t=>t.date===today);
  const total=sold.reduce((sum,t)=>sum+net(t),0);
  const qty=sold.reduce((sum,t)=>sum+Number(t.qty||0),0);
  const threshold=Number(db.settings?.low??5);
  const low=db.products.filter(p=>stock(p.sku)<=threshold).length;
  const soon=(db.promos||[]).filter(p=>p.end>=today&&p.end<=new Date(Date.now()+7*86400000).toISOString().slice(0,10)).length;
  el.innerHTML='<div class="stats"><div class="tile"><span>Sales today</span><b>'+money(total)+'</b></div><div class="tile"><span>Units sold</span><b>'+qty+'</b></div><div class="tile"><span>Low stock products</span><b>'+low+'</b></div><div class="tile"><span>Promos ending in 7 days</span><b>'+soon+'</b></div></div><p class="muted tiny">Based on saved transactions and promo dates. Profit is not shown because complete product cost data may be missing.</p>';
}
function v7EmergencyBackup(){
  try{
    const payload={...db,backupMeta:{app:'Karens PromoTrack',version:'7.0',exportedAt:new Date().toISOString()}};
    const json=JSON.stringify(payload,null,2);
    if(window.AndroidBridge?.shareBackup){AndroidBridge.shareBackup(json);alert('Choose Google Drive or another external location in the share menu. Confirm the file exists there; sharing alone is not a verified backup.');}
    else {download('karens-promotrack-emergency-'+localDate()+'.json',json,'application/json');alert('Backup download requested. Move the file outside app storage and verify it opens.');}
  }catch(e){alert('Emergency backup failed: '+e.message)}
}
const v7PreviousRender=render;
render=function(){v7PreviousRender();v7DailySummary()};
v7DailySummary();
