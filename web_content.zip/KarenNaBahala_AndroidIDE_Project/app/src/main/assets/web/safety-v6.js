// Karen's PromoTrack v6 safety additions. Offline; no automatic Google Drive integration.
'use strict';
(function(){
const byId=id=>document.getElementById(id);
const setupKey='kpt-v6-setup-completed';
const setModal=(id,show)=>byId(id)?.classList.toggle('visible',!!show);
window.kptCompleteSetup=function(){
 const low=Number(byId('kptLow').value),pin=byId('kptFirstPin').value;
 if(!Number.isInteger(low)||low<0||low>100000)return alert('Enter a valid low-stock threshold.');
 if(pin&&!/^\d{4,8}$/.test(pin))return alert('PIN must be 4–8 digits.');
 if(!byId('kptBackupAck').checked)return alert('Please acknowledge external backup requirements.');
 try{
  db.settings=db.settings||{};db.settings.low=low;
  db.settings.businessName=byId('kptBusiness').value.trim()||"Karen's PromoTrack";
  if(pin)localStorage.setItem('kpt-pin',pin);
  save();localStorage.setItem(setupKey,new Date().toISOString());
  setModal('kptSetup',false);
  if(pin)byId('lockOverlay')?.classList.add('show');
  alert('Setup complete. Save a JSON backup to Google Drive or another external location.');
 }catch(e){alert('Setup could not be saved: '+e.message)}
};
window.kptOpenRecovery=function(message){
 byId('kptRecoveryMsg').textContent=message||'Choose a JSON backup exported from Karen\'s PromoTrack. It will be validated and previewed before replacement.';
 setModal('kptRecovery',true);
};
window.kptCloseRecovery=function(){setModal('kptRecovery',false)};
window.kptRecoverFile=async function(e){
 if(!e.target.files?.length)return;
 if(typeof restoreJSON!=='function')return alert('Restore handler unavailable.');
 // Reuse existing validated preview and double-confirmation restore flow.
 await restoreJSON(e);
};
window.kptCreateSafetyBackup=function(){
 if(typeof exportJSON!=='function')return alert('Backup exporter unavailable.');
 exportJSON();
 alert('Backup download requested. Confirm the file exists outside the app before making risky changes.');
};
function externalBackupWarning(){
 const stamp=localStorage.getItem('kpt-external-backup-confirmed');
 const old=!stamp||!Number.isFinite(Date.parse(stamp))||Date.now()-Date.parse(stamp)>7*86400000;
 if(byId('kptBackupWarning'))byId('kptBackupWarning').textContent=old?'Backup reminder: Save a recent copy to Drive or Files.':'External backup recently confirmed by you.';
}
// Guard CSV imports and restores: user must deliberately confirm external backup.
function guardRisk(label){
 if(!confirm(label+' may change existing data. Do you have a verified backup saved OUTSIDE this app?'))return false;
 if(!confirm('Continue '+label+'? This action may be difficult to undo.'))return false;
 return true;
}
if(typeof importProductsCSV==='function'){
 const original=importProductsCSV;
 window.importProductsCSV=function(event){if(!guardRisk('CSV import')){event.target.value='';return;}return original(event)};
}
if(typeof restoreJSON==='function'){
 const original=restoreJSON;
 window.restoreJSON=function(event){if(!guardRisk('Backup restore')){event.target.value='';return;}return original(event)};
}
// Protect future bulk delete hooks, if the function is present in a later version.
if(typeof window.bulkDeleteProducts==='function'){
 const original=window.bulkDeleteProducts;
 window.bulkDeleteProducts=function(...args){if(guardRisk('Bulk delete'))return original(...args)};
}
try{
 const raw=localStorage.getItem('karens-promotrack-v1');
 if(raw){const data=JSON.parse(raw);if(!data||!Array.isArray(data.products)||!Array.isArray(data.transactions)){
  kptOpenRecovery('Saved data looks invalid. Do not uninstall or clear app data. Select a known-good external JSON backup for a validated restore.');
 }}
}catch(e){kptOpenRecovery('Saved data cannot be parsed. Do not uninstall or clear app data. Select an external JSON backup for recovery.');}
if(!localStorage.getItem(setupKey)){
 byId('kptLow').value=String(db.settings?.low??5);
 byId('kptBusiness').value=db.settings?.businessName||"Karen's PromoTrack";
 setModal('kptSetup',true);
}
externalBackupWarning();
})();
