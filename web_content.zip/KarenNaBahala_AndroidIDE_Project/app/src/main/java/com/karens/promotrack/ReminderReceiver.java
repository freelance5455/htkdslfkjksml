package com.karens.promotrack;
import android.app.*;
import android.content.*;
import android.os.Build;
public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context,Intent intent){
  if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,"promo_reminders"):new Notification.Builder(context);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Karen's PromoTrack").setContentText("Review low stock, expiring items and promo schedules.").setAutoCancel(true);
  ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(201,b.build());
 }
}
