package com.karens.promotrack;

import android.app.*;
import android.os.*;
import android.content.*;
import android.webkit.*;
import android.print.*;
import android.net.Uri;
import androidx.core.content.FileProvider;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private static final int EXPORT_BACKUP_REQUEST = 721;
    private String pendingBackupJson;
    private File backupDir(){File f=new File(getExternalFilesDir(null),"backups");f.mkdirs();return f;}
    private File writeBackup(String data) throws Exception {
        File f=new File(backupDir(),"promotrack-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date())+".json");
        try(FileOutputStream out=new FileOutputStream(f)){out.write(data.getBytes("UTF-8"));}
        File[] files=backupDir().listFiles();if(files!=null && files.length>30){Arrays.sort(files,Comparator.comparingLong(File::lastModified));for(int i=0;i<files.length-30;i++)files[i].delete();}return f;
    }
    private void notifyUser(String message){runOnUiThread(()-> android.widget.Toast.makeText(this,message,android.widget.Toast.LENGTH_LONG).show());}
    @Override public void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);
        web=new WebView(this);setContentView(web);WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public void printReport(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);pm.print("Karen's PromoTrack Report",web.createPrintDocumentAdapter("PromoTrack Report"),new PrintAttributes.Builder().build());});}
            @JavascriptInterface public void scanBarcode(){runOnUiThread(()->{IntentIntegrator scanner=new IntentIntegrator(MainActivity.this);scanner.setPrompt("Scan product barcode");scanner.setBeepEnabled(false);scanner.setOrientationLocked(false);scanner.initiateScan();});}
            @JavascriptInterface public void autoBackup(String data){try{File f=new File(backupDir(),"latest.json");try(FileOutputStream out=new FileOutputStream(f)){out.write(data.getBytes("UTF-8"));}}catch(Exception e){notifyUser("Local backup failed: "+e.getMessage());}}
            @JavascriptInterface public void backupNow(String data){try{File f=writeBackup(data);notifyUser("Backup saved: "+f.getName());}catch(Exception e){notifyUser("Backup failed: "+e.getMessage());}}
            @JavascriptInterface public void exportBackup(String data){runOnUiThread(()->{
                pendingBackupJson=data;
                Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                create.addCategory(Intent.CATEGORY_OPENABLE);
                create.setType("application/json");
                create.putExtra(Intent.EXTRA_TITLE,"KarensPromoTracker-backup-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date())+".json");
                try{startActivityForResult(create,EXPORT_BACKUP_REQUEST);}catch(Exception e){notifyUser("Cannot open save location: "+e.getMessage());}
            });}
            @JavascriptInterface public void shareBackup(String data){try{File f=writeBackup(data);Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".provider",f);Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/json");send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);runOnUiThread(()->startActivity(Intent.createChooser(send,"Save backup to Google Drive")));}catch(Exception e){notifyUser("Sharing failed: "+e.getMessage());}}
        },"AndroidBridge");
        web.loadUrl("file:///android_asset/web/index.html");
        if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=new NotificationChannel("promo_reminders","Promo reminders",NotificationManager.IMPORTANCE_DEFAULT);getSystemService(NotificationManager.class).createNotificationChannel(channel);}
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=getPackageManager().PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);
        scheduleReminder();
    }
    private void scheduleReminder(){Intent intent=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,200,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Calendar next=Calendar.getInstance();next.set(Calendar.HOUR_OF_DAY,9);next.set(Calendar.MINUTE,0);next.set(Calendar.SECOND,0);if(next.getTimeInMillis()<=System.currentTimeMillis())next.add(Calendar.DAY_OF_YEAR,1);((AlarmManager)getSystemService(ALARM_SERVICE)).setInexactRepeating(AlarmManager.RTC_WAKEUP,next.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==EXPORT_BACKUP_REQUEST){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingBackupJson!=null){
                try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new IOException("Cannot write selected file");
                    out.write(pendingBackupJson.getBytes("UTF-8"));out.flush();
                    notifyUser("Backup file saved. Keep it outside this app.");
                    final String savedAt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date());
                    runOnUiThread(()->web.evaluateJavascript("window.kptOnExternalFileSaved && window.kptOnExternalFileSaved("+org.json.JSONObject.quote(savedAt)+")",null));
                }catch(Exception e){notifyUser("Export failed: "+e.getMessage());}
            }
            pendingBackupJson=null;return;
        }
        IntentResult result=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);if(result!=null && result.getContents()!=null){String encoded=org.json.JSONObject.quote(result.getContents());web.evaluateJavascript("window.onBarcodeScanned("+encoded+")",null);}}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
