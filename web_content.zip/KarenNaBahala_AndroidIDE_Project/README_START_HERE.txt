KAREN'S PROMOTRACK v6 — ANDROID IDE SOURCE PROJECT

Karen’s PromoTrack v5 — Android IDE SOURCE PROJECT

OPEN: Extract ZIP, then open KarensPromoTrack_AndroidIDE_Project in Android IDE.
Requires Gradle dependency downloads on first build; APK was NOT compiled or device-tested here.

IMPLEMENTED IN SOURCE (not device verified):
- Existing v4 inventory, sales, promo and reporting features preserved.
- Sale quantity checks against available stock; negative-stock damaged adjustments blocked.
- Basic data-integrity diagnostics: duplicate SKU/transaction IDs, invalid quantities, missing SKUs and negative stock.
- Audit trail viewer (existing timestamped events), local-storage test, backup/camera bridge presence checks.
- Data safety JSON snapshot export, external backup-age warning.
- Settings save now preserves custom reminderDays and other existing settings.
- Schema version metadata for future migration, without destructive rewriting.
- Existing transaction Recycle Bin and restore, CSV export, backup and restore functions retained.

PRESENT BUT UNTESTED ON DEVICE:
- Barcode camera scanner (ZXing dependency); Android notification permission and daily reminder.
- WebView JSON export/restore, CSV and Android PDF print/receipt.
- Local app-specific backup and sharing through Android share sheet.
- Old app data retention on in-place update requires SAME package name and signing key.

NOT IMPLEMENTED / NOT VERIFIED:
- Unattended, verified Google Drive automatic cloud backup. Current feature is MANUAL share to Drive only.
- Secure encrypted PIN or biometric storage. Existing PIN is stored in localStorage and is not secure.
- Transaction correction with immutable journal: current Recycle Bin restores deleted transactions, not a complete correction ledger.
- Full rollback-capable schema migration, guaranteed update safety, or automatic restore after uninstall.
- Reliable storage-capacity detection, per-promo background alarms, and full end-to-end recovery testing.

SAFETY: Back up to an external location and VERIFY that file before uninstalling/updating. Local backups in app-specific storage may be deleted on uninstall. Do not replace your current app until an install and restore test succeeds. Restore backups use the original JSON export, not the safety-snapshot wrapper.


V6 NEW SOURCE IMPLEMENTATIONS (NOT DEVICE-TESTED):
- First-time setup wizard for display name, PHP currency display, stock threshold, optional PIN and external-backup acknowledgement.
- Emergency recovery entry point in Settings; opens file picker and reuses existing JSON validation, preview and confirmation flow.
- Backup-before-risky-action confirmation prompts for CSV import and JSON restore; one-click JSON export request in Settings.
- External backup reminder based on MANUALLY confirmed timestamp, not a cloud verification.

IMPORTANT LIMITATIONS:
- Backup prompt does not guarantee a completed backup; user MUST verify the exported file externally.
- Emergency recovery requires an existing valid external backup. Cannot recover cleared app storage without one.
- First-time PIN is stored as plaintext in WebView localStorage; not suitable for high-security use.
- Google Drive automatic cloud backup remains NOT IMPLEMENTED.
- Existing v5 functionality remains unverified on an Android device. No APK was compiled here.
- Existing saved records may be lost if package ID/signing key changes or app is uninstalled. Do not uninstall current app before testing.


VERSION 7 ADDITIONS
- Fast barcode checkout: scanner selects existing SKU in the sale form; user must review and save sale.
- Daily dashboard summary: today's sales and units, low-stock count, expiring promos.
- One-tap emergency external backup: Android share sheet or JSON download; user MUST verify destination file.

NOT VERIFIED: Gradle build, device camera, WebView downloads, notifications, restore, backup integrity.
NOT IMPLEMENTED: unattended verified Google Drive cloud backup, automatic per-promo notifications, full encrypted storage.
Do not uninstall prior app or clear its storage before confirming an external backup and successful restore.


V10 BACKUP EXPORT UPDATE:
- Native Android Storage Access Framework exportBackup(JSON) added. This can save a backup outside app-specific storage (including to a connected Drive document provider, if available).
- ZXing barcode Gradle dependency and Android camera/notification permissions were already in the project; not newly implemented here.
- Android notification permission is requested on Android 13+; user must allow it.
- This is NOT unattended automatic Google Drive backup. That requires a separate Google sign-in/Drive API integration and a real-device test.
- Build/device tests have NOT been run.


ANDROID UI AND BACKUP UPDATE
- Corporate header typography enlarged and centered.
- Removed developer-facing version labels and verbose technical notices from Settings.
- Backup status remains honest: app-specific backups can be lost on uninstall.
- Android Save As reports success only after document output stream write succeeds.
- This is NOT automatic Google Drive backup, and no cloud file is independently verified.
- Build and device behavior remain untested; retain external backups before updating.
