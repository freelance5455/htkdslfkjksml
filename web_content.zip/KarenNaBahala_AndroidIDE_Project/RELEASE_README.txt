KarenNaBahala! — Android IDE source project

Open this project in Android IDE and build the APK.
The app starts with no sample products or transactions.
Before installing over an existing version, export a JSON backup.
Do not uninstall the existing app before backing up its data.
Google Drive backups are manual; verify your exported file.
This source ZIP has not been tested on a physical Android device.
