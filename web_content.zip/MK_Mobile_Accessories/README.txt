MK MOBILE ACCESSORIES — Offline HTML App

CONTENTS
- index.html: complete mobile-friendly shop management app.

FEATURES
- Product and stock management
- Billing / sales history
- Customer udhar (credit) balances and payment collection
- Expense cash book
- Dashboard and backup import/export
- Works offline after the file is opened; data is stored in that browser's local storage.

IMPORTANT
This is a starter app. Data is stored locally in the browser/WebView on the device. Clearing app/browser data may erase it, so export backups regularly. It does not automatically sync between devices.

BUILD AN ANDROID APK
Option A — Android Studio:
1. Create a new Android Studio project using an Empty Views Activity.
2. Add a WebView to the activity layout.
3. Copy index.html into app/src/main/assets/index.html.
4. Configure the WebView to enable JavaScript and load:
   webView.getSettings().setJavaScriptEnabled(true);
   webView.loadUrl("file:///android_asset/index.html");
5. Build > Build APK(s). Test the APK on your phone.

Option B — a WebView app builder:
1. Create a new WebView / HTML app.
2. Import or paste index.html as the local start page.
3. Enable JavaScript and offline/local file access if the builder asks.
4. Build/export APK.

No internet connection is required for the app itself. Keep a backup of your data.
