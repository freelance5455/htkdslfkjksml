V90 Android deployment/testing notes

1. Replace the USER website index.html with V90.
2. Keep the same Firebase project/config used by V89.
3. Keep the existing Firebase Rules/functions used for balance settlement.
4. Do not clear app/browser site storage during normal testing; LOCAL auth + the small profile cache are used for fast auto-login.
5. For a clean test account, clear site data only after recording the account credentials.
