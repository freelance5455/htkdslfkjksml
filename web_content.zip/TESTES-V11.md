# Verificações v11

| Verificação | Resultado |
|---|---|
| Sintaxe do script principal | PASSOU (`node --check`) |
| Sintaxe do script de inicialização/áudio | PASSOU (`node --check`) |
| Cópias root, `web/` e `www/` do HTML | PASSOU: iguais |
| Terreno global 10.000×10.000 removido | PASSOU |
| Mudanças periódicas abruptas de luz/fog removidas | PASSOU |
| Sombras em tempo real permanecem desativadas em todos os modos de qualidade | PASSOU |
| Movimento do jogador usa colisão de parede | PASSOU |
| Casas incluem footprint sólido e dimensões maiores | PASSOU |
| Variação de tamanho e equipamento assimétrico em NPCs | PASSOU |
| Variação por arquétipo em monstros e animais | PASSOU |
| Cache Service Worker renovado para v11 | PASSOU |
| Caminhos relativos de assets/manifest mantidos em `web/` e `www/` | PASSOU |

Estes são testes estáticos e de sintaxe. Não equivalem a executar o jogo dentro do aplicativo HTML to APK ou num dispositivo Android real.
