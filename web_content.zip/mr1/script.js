/* ===== متجر mr.love - نسخة سحابية مشتركة ===== */
// كل المنتجات والصور تُحفظ في Firebase وتظهر لجميع المستخدمين فوراً
// ⚠️ الخطوة الوحيدة المطلوبة منك: ضع بيانات مشروعك في CONFIG بالأسفل
//    الشرح الكامل خطوة بخطوة في ملف: تعليمات-الإعداد.txt
const CONFIG = {
  apiKey: "الصق_المفتاح_هنا",
  authDomain: "mrlove-7ffde.firebaseapp.com",
  databaseURL: "https://mrlove-7ffde-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "mrlove-7ffde"
};
const CATS = ['مكياجات','جزادين','شناتي رجالي','عطورات','الساعات','الاكسسوارات','الشامبو','العناية بالبشرة','العروض والتنزيلات'];
const WHATSAPP = '963954391446';

let isAdmin = false;
let editId = null;
let currentCat = 'الكل';
let products = [];
let db = null;
let cloudReady = false;

// ----- التخزين المحلي (نسخة احتياطية عند انقطاع النت) -----
function load(key, def){ try{ return JSON.parse(localStorage.getItem(key)) || def; }catch(e){ return def; } }
function saveLocal(key, val){ localStorage.setItem(key, JSON.stringify(val)); }

let creds = load('shop_creds', {user:'admin', pass:'1234'});

// ----- الاتصال بـ Firebase -----
async function initCloud(){
  const configured = !CONFIG.apiKey.includes('ضع_هنا');
  if(!configured){
    console.warn('Firebase غير مُعدّ بعد — يعمل التطبيق بالوضع المحلي');
    products = load('shop_products', []);
    renderProducts();
    return;
  }
  try{
    await loadScript('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
    await loadScript('https://www.gstatic.com/firebasejs/9.23.0/firebase-database-compat.js');
    firebase.initializeApp(CONFIG);
    db = firebase.database();
    cloudReady = true;
    // الاستماع المباشر: أي تعديل منك يظهر فوراً عند كل الزبائن
    db.ref('products').on('value', snap => {
      const val = snap.val();
      products = val ? Object.keys(val).map(k => ({...val[k], id: k})) : [];
      products.sort((a,b) => (b.ts||0) - (a.ts||0));
      saveLocal('shop_products', products);
      renderProducts();
      if(isAdmin) renderAdminList();
    });
  }catch(e){
    console.error('فشل الاتصال بالسحابة:', e);
    products = load('shop_products', []);
    renderProducts();
  }
}
function loadScript(src){
  return new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.onload = res; s.onerror = rej;
    document.head.appendChild(s);
  });
}

// ----- بناء الأقسام -----
function buildCats(){
  const bar = document.getElementById('catsBar');
  bar.innerHTML = '';
  ['الكل', ...CATS].forEach(c => {
    const b = document.createElement('button');
    b.className = 'cat-btn' + (c === currentCat ? ' active' : '');
    b.textContent = c;
    b.onclick = () => { currentCat = c; buildCats(); renderProducts(); };
    bar.appendChild(b);
  });
  const sel = document.getElementById('pCat');
  sel.innerHTML = CATS.map(c => `<option value="${c}">${c}</option>`).join('');
}

// ----- عرض المنتجات -----
function renderProducts(){
  const grid = document.getElementById('productsGrid');
  const q = document.getElementById('searchInput').value.trim();
  let list = products.filter(p =>
    (currentCat === 'الكل' || p.cat === currentCat) &&
    (!q || p.name.includes(q)));
  if(!list.length){
    grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:#777;padding:40px">لا توجد منتجات بعد أو جارٍ التحميل...</p>';
    return;
  }
  grid.innerHTML = list.map(p => `
    <div class="card">
      <img src="${p.img || ''}" onerror="this.style.display='none'" alt="${p.name}">
      <div class="info">
        <div class="name">${p.name}</div>
        <div class="cat">${p.cat}</div>
        <div class="price">${p.price} ل.س</div>
        <a class="order-btn" target="_blank"
           href="https://wa.me/${WHATSAPP}?text=${encodeURIComponent('مرحباً، أريد طلب: ' + p.name + ' - السعر: ' + p.price + ' ل.س')}">
           <i class="fab fa-whatsapp"></i> اطلب الآن</a>
      </div>
    </div>`).join('');
}

// ----- النوافذ المنبثقة -----
function openPopup(id){ document.getElementById(id).classList.add('show'); }
function closePopup(id){ document.getElementById(id).classList.remove('show'); }
// إغلاق القائمة عند الضغط خارجها
document.querySelectorAll('.overlay').forEach(o => {
  o.addEventListener('click', e => { if(e.target === o) o.classList.remove('show'); });
});

// ----- تسجيل دخول المشرف -----
document.getElementById('adminBtn').onclick = () => {
  if(isAdmin) openPopup('adminOverlay');
  else openPopup('loginOverlay');
};
function adminLogin(){
  const u = document.getElementById('adminUser').value;
  const p = document.getElementById('adminPass').value;
  if(u === creds.user && p === creds.pass){
    isAdmin = true;
    closePopup('loginOverlay');
    openPopup('adminOverlay');
    renderAdminList();
  } else alert('بيانات الدخول غير صحيحة!');
}
function adminLogout(){ isAdmin = false; closePopup('adminOverlay'); }

// ----- الصور: ضغط تلقائي ثم حفظ Base64 في السحابة -----
document.getElementById('pImg').addEventListener('change', function(){
  const f = this.files[0];
  if(!f) return;
  const r = new FileReader();
  r.onload = e => {
    compressImage(e.target.result, 400, data => {
      document.getElementById('imgPreview').src = data;
      document.getElementById('imgPreview').style.display = 'block';
      document.getElementById('imgPreview').dataset.b64 = data;
    });
  };
  r.readAsDataURL(f);
});

function compressImage(dataUrl, maxW, cb){
  const img = new Image();
  img.onload = () => {
    const scale = Math.min(1, maxW / img.width);
    const c = document.createElement('canvas');
    c.width = img.width * scale; c.height = img.height * scale;
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    cb(c.toDataURL('image/jpeg', 0.7));
  };
  img.src = dataUrl;
}

// ----- حفظ المنتج في السحابة (يراه الجميع) -----
function saveProduct(){
  if(!cloudReady){ alert('⚠️ يجب إعداد Firebase أولاً — راجع ملف تعليمات-الإعداد.txt'); return; }
  const name = document.getElementById('pName').value.trim();
  const price = document.getElementById('pPrice').value.trim();
  const cat = document.getElementById('pCat').value;
  const img = document.getElementById('imgPreview').dataset.b64 || '';
  if(!name || !price){ alert('أدخل اسم المنتج والسعر'); return; }

  if(editId){
    const updates = { name, price, cat };
    if(img) updates.img = img;
    db.ref('products/' + editId).update(updates);
    editId = null;
  } else {
    db.ref('products').push({ name, price, cat, img, ts: Date.now() });
  }
  document.getElementById('pName').value = '';
  document.getElementById('pPrice').value = '';
  const prev = document.getElementById('imgPreview');
  prev.style.display = 'none'; delete prev.dataset.b64;
  document.getElementById('pImg').value = '';
}

function renderAdminList(){
  const el = document.getElementById('adminList');
  el.innerHTML = products.map(p => `
    <div class="admin-item">
      <img src="${p.img || ''}" onerror="this.style.display='none'">
      <div class="grow">${p.name}<br><small style="color:#d40000">${p.cat} - ${p.price} ل.س</small></div>
      <button class="del-btn" onclick="editProduct('${p.id}')">تعديل</button>
      <button class="del-btn" onclick="deleteProduct('${p.id}')">حذف</button>
    </div>`).join('') || '<p style="color:#777;font-size:.8rem">لا منتجات</p>';
}

function editProduct(id){
  const p = products.find(x => x.id === id);
  document.getElementById('pName').value = p.name;
  document.getElementById('pPrice').value = p.price;
  document.getElementById('pCat').value = p.cat;
  if(p.img){
    const prev = document.getElementById('imgPreview');
    prev.src = p.img; prev.style.display = 'block'; prev.dataset.b64 = p.img;
  }
  editId = id;
}

function deleteProduct(id){
  if(!confirm('حذف هذا المنتج نهائياً عند الجميع؟')) return;
  db.ref('products/' + id).remove();
}

// ----- تغيير بيانات المشرف -----
function changeCredentials(){
  const u = document.getElementById('newUser').value.trim();
  const p = document.getElementById('newPass').value.trim();
  if(!u || !p){ alert('أدخل اسم المستخدم وكلمة المرور الجديدة'); return; }
  creds = {user: u, pass: p};
  saveLocal('shop_creds', creds);
  if(cloudReady) db.ref('credentials').set(creds);
  alert('تم تحديث بيانات الدخول ✅');
  document.getElementById('newUser').value = '';
  document.getElementById('newPass').value = '';
}

// ----- البحث المباشر -----
document.getElementById('searchInput').addEventListener('input', renderProducts);

// ----- تشغيل -----
buildCats();
initCloud();
// مزامنة بيانات المشرف من السحابة
setTimeout(() => {
  if(db) db.ref('credentials').once('value').then(s => {
    if(s.val()){ creds = s.val(); saveLocal('shop_creds', creds); }
  });
}, 3000);