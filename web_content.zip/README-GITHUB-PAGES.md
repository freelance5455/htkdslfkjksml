# Dominó Score — PWA

## Publicar en GitHub Pages

1. Sube **todos los archivos y carpetas** de esta carpeta al repositorio.
2. Asegúrate de que `index.html` quede en la raíz del repositorio (o en la carpeta `/docs` si configuras Pages para `/docs`).
3. En GitHub: **Settings → Pages → Deploy from a branch**.
4. Selecciona la rama, normalmente `main`, y la carpeta `/ (root)`.
5. Guarda y abre la URL que GitHub Pages te proporcione.

La aplicación incluye:
- `index.html`
- `manifest.webmanifest`
- `sw.js`
- iconos PWA de 192×192 y 512×512
- funcionamiento offline después de la primera carga

El código original de la aplicación se conserva dentro de `index.html`.
