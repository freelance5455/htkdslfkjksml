# Cleared: medicine check for athletes (Android via Capacitor)

Vite + vanilla JS port of the Claude artifact prototype. Demo data only; not medical advice.

## Requirements
- Node.js 20 or newer
- Android Studio (recent version) with an Android SDK installed
- A phone with USB debugging, or an Android emulator

## Build an APK
1. `npm install`
2. `npm run dev` (optional: test in your browser first)
3. `npm run build`
4. `npx cap add android`  (once)
5. Allow the camera button to open the camera. Run:
   `sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application#' android/app/src/main/AndroidManifest.xml`
   (or add those two lines above `<application>` by hand)
6. `npx cap sync android`
7. `npx cap open android`, wait for Gradle sync, then
   Build > Build Bundle(s) / APK(s) > Build APK(s)
8. The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.
   Install it with `adb install app-debug.apk` or copy it to your phone.

After any code change: `npm run sync`, then rebuild in Android Studio.

## Before publishing to Google Play
- Change `appId` in `capacitor.config.json` to your own reverse-domain id (it cannot change later).
- Create an app icon and splash screen (`npm i -D @capacitor/assets`).
- Build a signed release (Build > Generate Signed Bundle / APK).

## What depended on the Claude Artifact environment
| Item | In the artifact | Outside Claude |
|---|---|---|
| Hosting and login | Private claude.ai link | App is bundled in the APK; no Claude account needed |
| Theme | Viewer could set `data-theme` | Only the phone's dark mode applies (`prefers-color-scheme`) |
| Fonts | Google Fonts allowed by the page's CSP | Still loaded online; offline it falls back to system fonts. For offline, install `@fontsource/bricolage-grotesque` and import it |
| Camera button | File input with `capture` | Needs the CAMERA permission (step 5). For real photo capture, use `@capacitor/camera` |
| Inline `onclick` | Global scripts | Handlers exposed on `window` in `src/main.js` |
| Data | In memory only | Still in memory: history resets when the app closes. Add storage or a backend |

## Still prototype-only
Sign-in accepts any input, the six-medicine list is demo data, photo reading is simulated, and doctor names and reply times are placeholders. A real product needs authentication, a licensed medicine database, doctor accounts, and secure storage for athlete data.
