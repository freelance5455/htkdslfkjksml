import './style.css';
import { App } from '@capacitor/app';

var MEDS={
paracetamol:{n:"Paracetamol",s:"g",why:"Not on the prohibited list.",alt:""},
ibuprofen:{n:"Ibuprofen",s:"g",why:"Not on the prohibited list.",alt:""},
pseudoephedrine:{n:"Pseudoephedrine (many cold and flu tablets)",s:"a",why:"Restricted in competition above a urine limit, so the dose and timing matter.",alt:"Saline nasal spray or a paracetamol-only product, if the doctor agrees."},
salbutamol:{n:"Salbutamol (Ventolin inhaler)",s:"a",why:"Allowed by inhaler within dose limits. The doctor logs each dose.",alt:""},
terbutaline:{n:"Terbutaline (Bricanyl inhaler)",s:"r",why:"Prohibited. A therapeutic use exemption (TUE) would be needed.",alt:"Ask the doctor about permitted inhalers or a TUE application."},
prednisolone:{n:"Prednisolone (oral steroid)",s:"r",why:"Oral steroids are prohibited in competition. A TUE may apply.",alt:"The doctor will advise on alternatives or a TUE."}};
var ALIAS={panadol:"paracetamol",tylenol:"paracetamol",advil:"ibuprofen",brufen:"ibuprofen",nurofen:"ibuprofen",sudafed:"pseudoephedrine",ventolin:"salbutamol",bricanyl:"terbutaline"};
var LABEL={g:"Clear",a:"Doctor review",r:"Do not take"};
var SIGN={g:"Checked against the demo list.",a:"Sent to Dr. Demo. A reply is due within 2 hours (placeholder).",r:"Do not take it. Dr. Demo has been notified (placeholder)."};
var S={screen:"home",tab:"check",hist:[],cur:null,busy:false,sent:false,plan:null};
var app=document.getElementById("app");
function stat(){var h=S.hist[0];return h?'<span class="chip '+h.s+'">Last check: '+({g:"clear",a:"in review",r:"do not take"})[h.s]+'</span>':'<span class="chip m">No checks yet</span>'}
function ind(m){S.mode=m;go("main","check")}
function esc(t){return String(t).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function go(s,t){S.screen=s;if(t)S.tab=t;S.sent=false;render();window.scrollTo(0,0)}
var LOGO='<svg width="56" height="56" viewBox="0 0 44 44" aria-hidden="true"><path d="M22 3l16 6v11c0 10-7 18-16 21C13 38 6 30 6 20V9z" fill="#fff"/><path d="M14 22l6 6 11-12" fill="none" stroke="var(--p)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function back(to){return '<button class="back" onclick="go(\''+to+'\')">← Back</button>'}
function dock(items){return '<nav class="dock"><div>'+items.map(function(i){return '<button class="'+(S.tab===i[0]?'on':'')+'" onclick="go(\''+i[2]+'\',\''+i[0]+'\')">'+i[1]+'</button>'}).join("")+'</div></nav>'}
var ADOCK=[["check","<i>✓</i>Check","main"],["hist","<i>▤</i>Passport","hist"],["help","<i>✉</i>Doctor","help"],["plan","<i>⌂</i>Plan","aplan"]];
var CDOCK=[["squad","<i>◉</i>Squad","squad"],["plan","<i>▤</i>Plan","plans"]];
function lookup(q){
 var k=q.toLowerCase().trim();if(!k)return;
 var key=MEDS[k]?k:ALIAS[k];
 if(!key){for(var m in MEDS){if(k.indexOf(m)>-1||m.indexOf(k)>-1){key=m;break}}}
 var r=key?MEDS[key]:{n:q.trim(),s:"a",why:"This medicine isn’t in the demo list, so a doctor needs to check it.",alt:"The doctor will suggest a safe alternative if one is needed."};
 show(r)}
function show(r){S.cur=r;S.hist.unshift({n:r.n,s:r.s,t:new Date().toLocaleDateString()});go("result","check")}
function search(){lookup(document.getElementById("q").value)}
function photo(inp){
 if(!inp.files||!inp.files.length)return;
 S.busy=true;render();
 setTimeout(function(){S.busy=false;show(MEDS.terbutaline)},1300)}
function sendHelp(){S.sent=true;render()}
function pick(p){S.plan=p;go("squad","squad")}
var SCR={
home:function(){return '<div class="hero">'+LOGO+'<h1>Cleared</h1><p>Every medicine checked by a doctor before it’s taken.</p></div><ul class="trust"><li>A doctor signs off every check</li><li>Works for medicines bought abroad</li><li>Coaches see status, never diagnoses</li></ul><button class="btn" onclick="go(\'ath\')">I’m an athlete<small>Check a medicine</small></button><button class="btn alt" onclick="go(\'acad\')">I’m an academy<small>Manage your squad and plan</small></button><p class="note">Prototype with demo data. Not medical advice.</p>'},
ath:function(){return back("home")+'<h2>Athletes</h2><p class="mut">Choose how you’ll sign in.</p><button class="btn" onclick="go(\'alogin\')">Through my academy<small>Use the code your academy gave you</small></button><button class="btn alt" onclick="go(\'ilogin\')">Individual<small>Sign up on your own</small></button>'},
alogin:function(){return back("ath")+'<h2>Sign in</h2><p class="mut">Use your academy login.</p><input aria-label="Academy code" placeholder="Academy code"><input aria-label="Password" type="password" placeholder="Password"><button class="btn" onclick="ind(\'acad\')">Sign in</button><button class="btn alt" onclick="ind(\'acad\')">Create account</button><p class="note">Demo: any input works.</p>'},
ilogin:function(){return back("ath")+'<h2>Individual sign-in</h2><p class="mut">Check medicines on your own. Plan price will be set after the pilot.</p><input aria-label="Email" type="email" placeholder="Email"><input aria-label="Password" type="password" placeholder="Password"><label class="mut" style="display:flex;gap:10px;align-items:flex-start;margin:8px 0"><input type="checkbox" style="width:auto;margin:3px 0 0"> I’m under 18 and my parent or guardian agrees to this.</label><button class="btn" onclick="ind(\'ind\')">Sign in</button><button class="btn alt" onclick="ind(\'ind\')">Create account</button><p class="note">Demo: any input works.</p>'},
acad:function(){return back("home")+'<h2>Academy</h2><p class="mut">Sign in or create your academy account.</p><input aria-label="Login" placeholder="Login"><input aria-label="Password" type="password" placeholder="Password"><button class="btn" onclick="go(\'squad\',\'squad\')">Sign in</button><button class="btn alt" onclick="go(\'plans\',\'plan\')">Make an account</button>'},
plans:function(){var P=[["Youth team","1 team"],["Academy","Up to 5 teams"],["Full club","6 or more teams"]];return (S.screen==="plans"&&S.tab==="plan"&&S.plan===null?back("acad"):"")+'<h2>Choose a plan</h2><p class="mut">Unlimited checks, doctor sign-off and the medicine passport are included. Prices will be set after the pilot. First season is free for pilot academies.</p>'+P.map(function(p){return '<div class="card"><h3>'+p[0]+'</h3><p class="mut">'+p[1]+'</p><button class="btn" onclick="pick(\''+p[0]+'\')">Select'+(S.plan===p[0]?' (current)':'')+'</button></div>'}).join("")+dock(CDOCK)},
squad:function(){var Q=[["Player 3","g"],["Player 7","a"],["Player 9","g"],["Player 11","r"],["Player 14","g"],["Player 18","a"]];return '<h2>Squad</h2><p class="mut">Plan: '+esc(S.plan||"Not chosen yet")+'. Coaches see status only, never diagnoses.</p><div class="stats"><div><b>3</b>Cleared</div><div><b>2</b>In review</div><div><b>1</b>Do not take</div></div><div class="card">'+Q.map(function(p){return '<div class="item" style="cursor:default"><span class="av">'+p[0].split(" ")[1]+'</span><span style="flex:1;margin-left:10px">'+p[0]+'</span><span class="chip '+p[1]+'">'+(p[1]==="g"?"Cleared":p[1]==="a"?"Pending review":"Do not take")+'</span></div>'}).join("")+'</div><button class="btn alt">Add players<small>Parent consent required for under 18s</small></button>'+dock(CDOCK)},
main:function(){return '<div class="hello">'+stat()+'<h2>Hi, athlete</h2><p class="mut" style="margin:0">'+S.hist.length+' medicine'+(S.hist.length===1?'':'s')+' in your passport</p></div><h3>Check a medicine</h3><p class="mut">Type a name, or photograph the box or label.</p>'+(S.busy?'<div class="card"><span class="spin"></span>Reading the label…</div>':'<div class="row"><input id="q" aria-label="Medicine name" placeholder="e.g. Bricanyl, Sudafed" onkeydown="if(event.key===\'Enter\')search()"><button class="ico" aria-label="Search by photo" onclick="document.getElementById(\'f\').click()">📷</button></div><input id="f" type="file" accept="image/*" capture="environment" hidden onchange="photo(this)"><button class="btn" onclick="search()">Check</button><div class="quick">'+['Panadol','Sudafed','Ventolin','Bricanyl'].map(function(x){return '<button class="qc" onclick="lookup(\''+x+'\')">'+x+'</button>'}).join("")+'</div>')+'<h3 style="margin-top:22px">Previously viewed</h3>'+histList(3)+'<p class="note">Photo reading is simulated here and always returns one sample result.</p>'+dock(ADOCK)},
result:function(){var r=S.cur;return back("main")+'<div class="light '+r.s+'"><div class="big">'+({g:"✓",a:"!",r:"✕"})[r.s]+'</div><p style="margin:0;opacity:.9">'+esc(r.n)+'</p><h2>'+LABEL[r.s]+'</h2></div><div class="kv"><b>Why</b>'+esc(r.why)+'</div>'+(r.alt?'<div class="kv"><b>Safer option</b>'+esc(r.alt)+'</div>':'')+'<div class="kv"><b>Doctor sign-off</b>'+esc(SIGN[r.s])+'</div><button class="btn" onclick="go(\'help\',\'help\')">Ask a doctor about this</button><p class="note">Demo data only. Not medical advice.</p>'+dock(ADOCK)},
hist:function(){return '<h2>My medicines</h2><p class="mut">Your medicine passport: everything checked, in one place.</p><div class="card">'+histList(50)+'</div>'+dock(ADOCK)},
help:function(){return '<h2>Ask a doctor</h2>'+(S.sent?'<div class="card"><span class="chip g">Sent</span><p style="margin-top:8px">Your question has gone to the doctor. You’ll get a reply here.</p></div>':'<p class="mut">Describe your symptoms or the medicine you were offered.</p><textarea rows="5" aria-label="Your question" placeholder="What do you need help with?"></textarea><button class="btn" onclick="sendHelp()">Send to doctor</button><button class="btn alt">Start a TUE request<small>For medicines that are prohibited but needed</small></button>')+dock(ADOCK)},
aplan:function(){return (S.mode==="ind"?'<h2>Individual plan</h2><div class="card"><h3>Pilot season</h3><p class="mut">Free during the pilot. Includes unlimited checks, doctor sign-off and your medicine passport. Price will be set after the pilot.</p></div><div class="card"><h3>Join your academy</h3><p class="mut">Enter your academy code to share your cleared status with your coach.</p><input aria-label="Academy code" placeholder="Academy code"><button class="btn alt">Link to academy</button></div>':'<h2>Academy plan</h2><div class="card"><h3>Pilot season</h3><p class="mut">Free for your academy. Includes unlimited checks, doctor sign-off and the medicine passport.</p></div>')+dock(ADOCK)}};
function histList(n){if(!S.hist.length)return '<p class="mut">Nothing yet. Your checks will appear here.</p>';return '<div>'+S.hist.slice(0,n).map(function(h){return '<div class="item" onclick="lookup(\''+esc(h.n).replace(/'/g,"")+'\')"><span>'+esc(h.n)+'<br><span class="mut">'+h.t+'</span></span><span class="chip '+h.s+'">'+LABEL[h.s]+'</span></div>'}).join("")+'</div>'}
function render(){app.innerHTML=SCR[S.screen]()}
render();

// ---- Vite/Capacitor additions ----
// Inline onclick handlers need globals; ES modules are scoped, so expose them.
// Android back button: keep a simple screen history instead of closing the app.
var navStack=[];
var _go=go;
go=function(s,t){if(S.screen!==s)navStack.push([S.screen,S.tab]);_go(s,t)};
Object.assign(window,{go:go,search:search,photo:photo,sendHelp:sendHelp,pick:pick,lookup:lookup,ind:ind});
try{App.addListener('backButton',function(){var p=navStack.pop();if(p){S.screen=p[0];S.tab=p[1];S.sent=false;render()}else{App.exitApp()}})}catch(e){}
