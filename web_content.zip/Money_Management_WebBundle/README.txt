Money Management - HTML to APK bundle

Entry file: index.html
Suggested app name: Money Management
App icon: app-icon.png (also upload this separately if the builder asks for an icon)

This bundle contains the standalone web app. Use a reputable HTML/ZIP-to-APK builder on your Android phone to compile an installable APK. Review permissions before installing any APK.
