let targetDeviceMAC = null;

function sendMessage() {
    let inputField = document.getElementById("msg-input");
    let text = inputField.value.trim();

    if (text === "" || !targetDeviceMAC) return;

    let chatBox = document.getElementById("chat-box");
    chatBox.innerHTML += `<div class="message sent"><p>${text}</p></div>`;

    chatBox.scrollTop = chatBox.scrollHeight;
    inputField.value = ""; // Clear out text field

    sendBluetoothPayload(targetDeviceMAC, text);
}

function selectChatTarget(name, mac) {
    targetDeviceMAC = mac;

    document.getElementById("current-chat-title").innerText = name;
    document.getElementById("current-chat-status").innerText = "Connected via Bluetooth";

    document.getElementById("msg-input").disabled = false;
    document.getElementById("send-btn").disabled = false;
    document.getElementById("msg-input").placeholder = "Message " + name + "...";
}

function display_discovered_device(deviceName, deviceMAC) {
    let list = document.getElementById("device-list");

    if (list.querySelector('.searching-text')) {
        list.innerHTML = '';
    }

    if (!document.getElementById(deviceMAC)) {
        list.innerHTML += `
            <div class="device-card" id="${deviceMAC}" onclick="selectChatTarget('${deviceName}', '${deviceMAC}')">
                <div class="avatar-icon">📱</div>
                <div class="device-details">
                    <h4>${deviceName}</h4>
                    <p>ID: ${deviceMAC}</p>
                </div>
            </div>
        `;
    }
}

function saveOfflineMessage(sender, text) {
    let chatHistory = JSON.parse(localStorage.getItem("whatsapp_history")) || [];

    let newMessage = {
        id: Date.now(),
        sender: sender,
        message_text: text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    chatHistory.push(newMessage);
    localStorage.setItem("whatsapp_history", JSON.stringify(chatHistory));
    console.log(`Saved locally: [${sender}]: ${text}`);
}

function loadChatHistory() {
    let chatBox = document.getElementById("chat-box");
    let chatHistory = JSON.parse(localStorage.getItem("whatsapp_history")) || [];

    if (chatHistory.length > 0) {
        chatBox.innerHTML = "";
    }

    chatHistory.forEach(msg => {
        let bubbleType = (msg.sender === "Me") ? "sent" : "received";
        chatBox.innerHTML += `
            <div class="message ${bubbleType}">
                <p>${msg.message_text}</p>
            </div>
        `;
    });

    chatBox.scrollTop = chatBox.scrollHeight;
}

async function scanAndConnectNearbyDevices() {
    try {
        console.log("Initializing offline connection protocols...");
        const device = await navigator.bluetooth.requestDevice({
            acceptAllDevices: true
        });
        console.log("Device discovered: " + device.name);
        display_discovered_device(device.name, device.id);
    } catch (error) {
        console.log("Scanning engine paused: " + error);

        display_discovered_device("Mock Friend Phone", "AA:BB:CC:DD:EE:FF");
    }
}

function sendBluetoothPayload(targetID, textText) {
    console.log(`Blasting wireless packet to client [${targetID}]: "${textText}"`);
    saveOfflineMessage("Me", textText);
}

window.addEventListener("DOMContentLoaded", () => {
    loadChatHistory();

    setInterval(scanAndConnectNearbyDevices, 6000);
});
