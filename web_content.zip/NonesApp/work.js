let peer = null;
let currentConnection = null;

const peerScript = document.createElement('script');
peerScript.src = 'https://unpkg.com';
document.head.appendChild(peerScript);

peerScript.onload = () => {
    initLocalNetwork();
};

function initLocalNetwork() {
    const localRandomNumber = Math.floor(1000 + Math.random() * 9000);
    const myOfflineID = "user-" + localRandomNumber;
    
    peer = new Peer(myOfflineID);

    peer.on('open', (id) => {
        console.log('Wireless Node Online. Local ID: ' + id);
        document.getElementById("current-chat-status").innerText = "Your Offline ID: " + id;
    });

    peer.on('connection', (conn) => {
        currentConnection = conn;
        setupConnectionListeners();
        document.getElementById("current-chat-title").innerText = "Nearby Friend";
    });
}

function connectToFriend(friendID) {
    if (!peer || !friendID.trim()) return;
    
    document.getElementById("current-chat-status").innerText = "Connecting to " + friendID.trim() + "...";
    currentConnection = peer.connect(friendID.trim());
    
    setupConnectionListeners();
}

function setupConnectionListeners() {
    currentConnection.on('open', () => {
        document.getElementById("current-chat-title").innerText = "Connected Phone";
        document.getElementById("current-chat-status").innerText = "Connected via Local Wi-Fi / Hotspot";
        
        document.getElementById("msg-input").disabled = false;
        document.getElementById("send-btn").disabled = false;
        document.getElementById("msg-input").placeholder = "Type an offline message...";
    });

    currentConnection.on('data', (data) => {
        displayReceivedMessage(data);
    });
}

function sendMessage() {
    let inputField = document.getElementById("msg-input");
    let text = inputField.value.trim();
    
    if (text === "" || !currentConnection) return;

    let chatBox = document.getElementById("chat-box");
    chatBox.innerHTML += `<div class="message sent"><p>${text}</p></div>`;
    chatBox.scrollTop = chatBox.scrollHeight;
    inputField.value = "";

    currentConnection.send(text);
    saveOfflineMessage("Me", text);
}

function displayReceivedMessage(text) {
    let chatBox = document.getElementById("chat-box");
    chatBox.innerHTML += `<div class="message received"><p>${text}</p></div>`;
    chatBox.scrollTop = chatBox.scrollHeight;
    saveOfflineMessage("Friend", text);
}

function saveOfflineMessage(sender, text) {
    let chatHistory = JSON.parse(localStorage.getItem("whatsapp_history")) || [];
    chatHistory.push({ sender: sender, message_text: text, id: Date.now() });
    localStorage.setItem("whatsapp_history", JSON.stringify(chatHistory));
}

function loadChatHistory() {
    let chatBox = document.getElementById("chat-box");
    let chatHistory = JSON.parse(localStorage.getItem("whatsapp_history")) || [];
    
    if (chatHistory.length > 0) {
        chatBox.innerHTML = "";
        chatHistory.forEach(msg => {
            let bubbleType = (msg.sender === "Me") ? "sent" : "received";
            chatBox.innerHTML += `<div class="message ${bubbleType}"><p>${msg.message_text}</p></div>`;
        });
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

window.addEventListener("DOMContentLoaded", () => {
    loadChatHistory();
});
