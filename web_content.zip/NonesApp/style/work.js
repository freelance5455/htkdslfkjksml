async function triggerPython() {
    let response;
    response = await eel.process_data()();
    document.getElementById("output-box").innerHTML = response;
}
        let targetDeviceMAC = null;

        eel.expose(display_discovered_device);
        function display_discovered_device(deviceName, deviceMAC) {
            let list = document.getElementById("device-list");

            if(list.querySelector('.searching-text')) {
                list.innerHTML = '';
            }

            if (!document.getElementById(deviceMAC)) {
                list.innerHTML += `
                    <div class="device-card" id="${deviceMAC}" onclick="selectChatTarget('${deviceName}', '${deviceMAC}')">
                        <div class="avatar-icon">📱</div>
                        <div class="device-details">
                            <h4>${deviceName}</h4>
                            <p>ID: ${deviceMAC}</p>
                        </div>
                    </div>
                `;
            }
        }

        function selectChatTarget(name, mac) {
            targetDeviceMAC = mac;

            document.getElementById("current-chat-title").innerText = name;
            document.getElementById("current-chat-status").innerText = "Connected via Bluetooth";

            document.getElementById("msg-input").disabled = false;
            document.getElementById("send-btn").disabled = false;
            document.getElementById("msg-input").placeholder = "Message " + name + "...";
        }

        async function sendMessage() {
            let inputField = document.getElementById("msg-input");
            let text = inputField.value.trim();
            if (text === "" || !targetDeviceMAC) return;

            let chatBox = document.getElementById("chat-box");
            chatBox.innerHTML += `<div class="message sent"><p>${text}</p></div>`;

            chatBox.scrollTop = chatBox.scrollHeight;
            inputField.va

            await eel.send_bluetooth_message(targetDeviceMAC, text)();
        }