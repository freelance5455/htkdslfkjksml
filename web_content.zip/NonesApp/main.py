import eel
import asyncio
import threading
from bleak import BleakScanner

eel.init('style')


def start_bluetooth_loop():
    """Initializes the background event loop for Bluetooth tasks."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(scan_bluetooth_devices())


async def scan_bluetooth_devices():
    """Continuously scans for nearby Bluetooth devices and feeds them to the UI."""
    print("Bluetooth scanner loop active...")
    while True:
        try:
            devices = await BleakScanner.discover(timeout=4.0)
            for device in devices:
                if device.name:
                    eel.display_discovered_device(device.name, device.address)
        except Exception as e:
            print(f"Scanning error: {e}")

        await asyncio.sleep(2)


@eel.expose
def send_bluetooth_message(mac_address, message_text):
    """Triggered directly when a user presses send inside the chat layout interface."""
    print(f"Routing transmission payload to targeted client: [{mac_address}]")
    print(f"Payload body: '{message_text}'")

    return "Payload Processed"

threading.Thread(target=start_bluetooth_loop, daemon=True).start()

eel.start('index.html', size=(380, 764))