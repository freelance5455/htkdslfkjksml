# V61 — Excel WebView file-input fallback

V60 showed “Android file picker is unavailable in this app build” when the JavaScript bridge was not present. V61 restores the standard HTML file-input path as a fallback.

Choose File now uses AndroidDPM.pickImportFile() when the native bridge exists; otherwise it programmatically opens the hidden HTML file input. In the Android app, MainActivity’s WebChromeClient handles that input. In a browser/web build, the browser handles it normally.

Version 2.27 / versionCode 31.
