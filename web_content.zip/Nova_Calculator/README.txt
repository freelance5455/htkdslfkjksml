Nova Calculator — Android/browser-ready project
=================================================

Files
- index.html: complete responsive calculator app. Open this file in a modern browser to test.
- README.txt: these instructions.

Features
- Full-screen responsive design for Android phones and desktop
- Standard arithmetic, parentheses, decimal, percent, sign toggle, backspace and clear
- Scientific mode: sin/cos/tan (degrees), square root, square, log, ln, pi, factorial and reciprocal
- Memory: MC, MR, M+, M-
- Recent calculation history and clear-history control
- Dark/light theme and copy-result button
- Keyboard support on devices with a keyboard
- No account, internet connection, API key, or server required

Important
This ZIP is a browser-based app project, not an APK file. To make an APK, import the project into a suitable Android wrapper/build service or Android IDE. Test on the target phone before publishing.
