ZEYD'S ULTIMATE APP - ANDROID PROJECT (WITH ZEYD'S WEB)

This Android Studio project contains the app plus the new Zeyd's Web page.
Zeyd's Web lets the user search Google or enter a website, then choose an
installed Android browser: Chrome, Firefox, Edge, Samsung Internet, Brave,
Opera, or Android's browser chooser. Safari is shown as an Apple-only option
because Safari is not available on Android.

BUILD A NEW APK:
1. Install Android Studio on a computer.
2. Open this extracted project folder in Android Studio.
3. Let Gradle sync and install Android SDK platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the new APK location, usually:
   app/build/outputs/apk/debug/app-debug.apk

The original APK is not modified by this source-project package. Rebuild the
APK in Android Studio to get an installable APK with Zeyd's Web included.
