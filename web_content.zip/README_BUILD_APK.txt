RV Venture AI — Android APK source package

This package contains the working prototype wrapped in an Android WebView project.
To produce an installable APK:
1. Open the android_project folder in Android Studio.
2. Let Gradle sync.
3. Choose Build > Build APK(s).
4. Install the generated APK on your Android phone.

The current prototype stores data locally on the device. Real AI/API and cloud database integration still need to be connected.
