// TV EN VIVO: módulo independiente de Películas
let allLiveChannels = [];
let filteredLiveChannels = [];
let activeLiveCategory = 'all';
let liveFullscreenButton = null;

function initLive() {
  $('liveSearch').addEventListener('input', filterLiveChannels);

  $('liveBackButton').addEventListener('click', () => {
    closeLivePlayer();
    $('liveScreen').style.display = 'none';
    $('catalogScreen').style.display = 'block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  $('closeLivePlayer').addEventListener('click', closeLivePlayer);
  $('livePlayerModal').addEventListener('click', e => {
    if (e.target === $('livePlayerModal')) closeLivePlayer();
  });

  installLiveFullscreenControl();

  document.addEventListener('fullscreenchange', updateLiveFullscreenState);
  document.addEventListener('webkitfullscreenchange', updateLiveFullscreenState);
}

function installLiveFullscreenControl() {
  const video = $('liveVideo');
  const box = document.querySelector('.live-player-box');
  if (!video || !box) return;

  // Botón central superpuesto al cuadro del video.
  // Al tocarlo se pone en fullscreen el modal completo, no solo el elemento video.
  liveFullscreenButton = document.getElementById('liveFullscreenTap');
  if (!liveFullscreenButton) {
    liveFullscreenButton = document.createElement('button');
    liveFullscreenButton.id = 'liveFullscreenTap';
    liveFullscreenButton.type = 'button';
    liveFullscreenButton.setAttribute('aria-label', 'Ampliar video a pantalla completa');
    liveFullscreenButton.title = 'Pantalla completa';
    liveFullscreenButton.innerHTML = '<span aria-hidden="true">⛶</span>';
    box.appendChild(liveFullscreenButton);
  }

  liveFullscreenButton.addEventListener('click', enterLiveFullscreen);

  // También permite tocar directamente el área de imagen.
  video.addEventListener('click', enterLiveFullscreen);
}

function updateLiveFullscreenState() {
  const fullscreen = document.fullscreenElement === $('livePlayerModal') ||
    document.webkitFullscreenElement === $('livePlayerModal');
  if (liveFullscreenButton) {
    liveFullscreenButton.style.display = fullscreen ? 'none' : 'flex';
  }
}

function enterLiveFullscreen() {
  const modal = $('livePlayerModal');

  // IMPORTANTE: llamar requestFullscreen directamente desde el toque,
  // sin await previo ni temporizadores, para conservar la activación del usuario.
  try {
    let result;
    if (modal.requestFullscreen) {
      result = modal.requestFullscreen({ navigationUI: 'hide' });
    } else if (modal.webkitRequestFullscreen) {
      result = modal.webkitRequestFullscreen();
    } else {
      message('livePlayerMessage',
        'Este navegador no permite pantalla completa. Abre PERCIA IPTV en Chrome.',
        'error');
      return;
    }

    if (result && typeof result.then === 'function') {
      result.then(() => {
        if (liveFullscreenButton) liveFullscreenButton.style.display = 'none';
        try {
          if (screen.orientation && screen.orientation.lock) {
            screen.orientation.lock('landscape').catch(() => {});
          }
        } catch (_) {}
      }).catch(error => {
        console.warn('No se pudo activar pantalla completa:', error);
        message('livePlayerMessage',
          'El navegador no permitió pantalla completa. Prueba tocar el botón central otra vez.',
          'error');
      });
    }
  } catch (error) {
    console.warn('Fullscreen:', error);
    message('livePlayerMessage', 'No se pudo activar pantalla completa en este navegador.', 'error');
  }
}

async function openLive() {
  $('catalogScreen').style.display = 'none';
  $('liveScreen').style.display = 'block';
  $('liveSearch').value = '';
  $('liveGrid').replaceChildren();
  $('liveCategories').replaceChildren();
  await loadLiveCategories();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function loadLiveCategories() {
  if (!activeProfile) return;
  message('liveMessage', 'Cargando categorías de TV EN VIVO...', 'info');
  try {
    const data = await fetchJson(apiUrl(activeProfile, { action: 'get_live_categories' }));
    if (!Array.isArray(data)) throw new Error('Respuesta de categorías no válida.');
    renderLiveCategories(data);
    await loadLiveChannels('all');
  } catch (error) {
    message('liveMessage', 'Error al cargar TV EN VIVO: ' + error.message, 'error');
  }
}

function renderLiveCategories(categories) {
  const box = $('liveCategories');
  box.replaceChildren();
  addLiveCategory('Todas', 'all');
  categories.forEach(c => addLiveCategory(c.category_name || 'Sin nombre', String(c.category_id)));
}

function addLiveCategory(name, id) {
  const b = document.createElement('button');
  b.className = 'category-chip' + (id === 'all' ? ' active' : '');
  b.textContent = name;
  b.addEventListener('click', () => {
    document.querySelectorAll('#liveCategories .category-chip').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    activeLiveCategory = id;
    loadLiveChannels(id);
  });
  $('liveCategories').appendChild(b);
}

async function loadLiveChannels(categoryId) {
  if (!activeProfile) return;
  activeLiveCategory = categoryId;
  $('liveGrid').replaceChildren();
  message('liveMessage', 'Cargando canales...', 'info');
  try {
    const extra = { action: 'get_live_streams' };
    if (categoryId !== 'all') extra.category_id = categoryId;
    const data = await fetchJson(apiUrl(activeProfile, extra));
    if (!Array.isArray(data)) throw new Error('Respuesta de canales no válida.');
    allLiveChannels = data;
    filterLiveChannels();
    message('liveMessage', data.length ? 'Canales cargados.' : 'No hay canales en esta categoría.', data.length ? 'success' : 'info');
  } catch (error) {
    message('liveMessage', 'Error al cargar canales: ' + error.message, 'error');
  }
}

function filterLiveChannels() {
  const q = $('liveSearch').value.trim().toLowerCase();
  filteredLiveChannels = allLiveChannels.filter(c => String(c.name || '').toLowerCase().includes(q));
  renderLiveChannels();
}

function renderLiveChannels() {
  const grid = $('liveGrid');
  grid.replaceChildren();
  $('liveCount').textContent = filteredLiveChannels.length + ' canales';

  filteredLiveChannels.forEach(channel => {
    const card = document.createElement('button');
    card.className = 'live-card';
    if (channel.stream_icon) {
      const img = document.createElement('img');
      img.src = channel.stream_icon;
      img.alt = '';
      img.loading = 'lazy';
      img.onerror = () => img.remove();
      card.appendChild(img);
    }
    const name = document.createElement('span');
    name.textContent = channel.name || 'Canal';
    card.appendChild(name);
    card.addEventListener('click', () => playLiveChannel(channel));
    grid.appendChild(card);
  });

  if (!filteredLiveChannels.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    empty.textContent = 'No hay canales para mostrar';
    grid.appendChild(empty);
  }
}

function playLiveChannel(channel) {
  const url = activeProfile.server.replace(/\/+$/, '') +
    '/live/' + encodeURIComponent(activeProfile.username) +
    '/' + encodeURIComponent(activeProfile.password) +
    '/' + encodeURIComponent(channel.stream_id) + '.m3u8';

  $('livePlayerTitle').textContent = channel.name || 'TV EN VIVO';
  $('livePlayerModal').style.display = 'flex';
  hideMessage('livePlayerMessage');

  const video = $('liveVideo');
  video.pause();
  video.removeAttribute('src');
  video.load();

  if (window.liveHls) {
    window.liveHls.destroy();
    window.liveHls = null;
  }

  if (window.Hls && Hls.isSupported()) {
    const hls = new Hls({ enableWorker: true });
    window.liveHls = hls;
    hls.loadSource(url);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      video.play().catch(() => message('livePlayerMessage', 'Pulsa reproducir para iniciar el canal.', 'info'));
    });
    hls.on(Hls.Events.ERROR, (_, data) => {
      if (data.fatal) {
        message('livePlayerMessage', 'No se pudo reproducir este canal. Comprueba la señal o el formato del servidor.', 'error');
      }
    });
  } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = url;
    video.play().catch(() => message('livePlayerMessage', 'Pulsa reproducir para iniciar el canal.', 'info'));
  } else {
    message('livePlayerMessage', 'Este navegador no admite HLS. Prueba abrirlo en un navegador compatible.', 'error');
  }
}

function closeLivePlayer() {
  const video = $('liveVideo');
  video.pause();
  video.removeAttribute('src');
  video.load();

  if (window.liveHls) {
    window.liveHls.destroy();
    window.liveHls = null;
  }

  $('livePlayerModal').style.display = 'none';
  hideMessage('livePlayerMessage');

  try {
    if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock();
  } catch (_) {}

  if (document.fullscreenElement && document.exitFullscreen) {
    document.exitFullscreen().catch(() => {});
  } else if (document.webkitFullscreenElement && document.webkitExitFullscreen) {
    document.webkitExitFullscreen();
  }

  if (liveFullscreenButton) liveFullscreenButton.style.display = 'flex';
}
