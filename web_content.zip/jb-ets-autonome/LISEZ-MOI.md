# JB ets : version autonome (Drive + Agenda)

Contenu : index.html (l'application), manifest.webmanifest, sw.js (ouverture hors ligne), icônes.
Non testé sur un appareil. Aucun fichier APK n'est fourni : il se génère à l'étape 4.

## 1. Google Cloud (une fois, gratuit, ~10 min, sur ordinateur)
1. console.cloud.google.com : créer un projet « JB ets ».
2. Menu « API et services » > Bibliothèque : activer **Google Drive API** et **Google Calendar API**.
3. « Écran de consentement OAuth » : type Externe, nom JB ets, votre e-mail. Ajoutez votre adresse Gmail dans « Utilisateurs de test ». Laissez en mode Test (usage personnel).
4. « Identifiants » > Créer des identifiants > **ID client OAuth**, type **Application Web**. Dans « Origines JavaScript autorisées », mettez l'adresse https de l'étape 2 (ex. https://jb-ets.netlify.app), sans slash final.
5. Copiez l'ID client (finit par .apps.googleusercontent.com). Ce n'est pas un secret.
Droits demandés : drive.file (uniquement les fichiers créés par l'application) et calendar.events.

## 2. Héberger les fichiers en https (obligatoire pour Google)
Netlify Drop (app.netlify.com/drop) : glissez le dossier. Autres choix gratuits : GitHub Pages, Cloudflare Pages. Notez l'adresse obtenue et faites l'étape 1.4 avec elle.

## 3. Sur le téléphone (Chrome)
Ouvrez l'adresse, menu ⋮ > **Installer l'application**. Vous obtenez une icône et une fenêtre sans barre Chrome (c'est une application Android installée, sans compiler d'APK).
Dans l'app : Plus > Réglages > « ID client Google » (collez l'ID), « Se connecter à Google », puis activez « Agenda » et « Sauvegarde Drive ».
Documents : ouvrez un rapport, un devis, une facture ou une fiche fluides, puis « ☁ Envoyer sur Drive ». Dossiers créés : JB ets > Rapports, Factures, Devis, Fluides.

## 4. Si vous voulez un vrai fichier APK
Allez sur pwabuilder.com, saisissez l'adresse https, choisissez Android, téléchargez le paquet. Suivez ses instructions pour la signature et le fichier .well-known/assetlinks.json à héberger. Installez l'APK en autorisant les sources inconnues.
Pourquoi pas Capacitor/WebView : Google refuse la connexion OAuth dans une WebView intégrée. PWABuilder/Chrome contourne ce blocage.

## Limites à connaître
- Le PDF est une capture de la page (bibliothèque html2pdf chargée avec le réseau). S'il échoue, un fichier HTML est enregistré à la place.
- L'envoi vers Drive se fait par bouton. Seule la sauvegarde JSON est automatique.
- Le jeton Google dure environ 1 heure : une fenêtre Google peut se rouvrir pour reconnecter.
- Mode Test Google : écran « application non vérifiée » à accepter une fois.
- Données stockées sur le téléphone (navigateur) : activez la sauvegarde Drive.
- Les données de la version Claude ne passent pas automatiquement : utilisez Sauvegarde (copier) puis Restaurer.
- Cerfa : fiche de préparation uniquement, voir l'écran « Préparer le Cerfa ».
