जीव विज्ञान साथी — Android APK build project

यह Android Studio project है। इसमें आपके हिंदी biology app का HTML prototype WebView में चलता है। Notes, MCQ quiz, progress, NCERT link और demo admin panel शामिल हैं।

सीमा: इस वातावरण में Android SDK/Gradle मौजूद नहीं है, इसलिए यहाँ APK को compile करके सीधे देना संभव नहीं हुआ। यह प्रोजेक्ट APK बनाने के लिए तैयार किया गया है।

सबसे आसान तरीका (कंप्यूटर पर):
1. ZIP extract करें।
2. Android Studio खोलें > Open > इस project folder को चुनें।
3. Gradle sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s)।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगी।

वैकल्पिक GitHub Actions:
- इस ZIP को अपने GitHub repository में upload करें।
- Actions tab खोलकर "Build Android APK" workflow चलाएँ।
- Workflow सफल होने पर "Jeev-Vigyan-Saathi-APK" artifact डाउनलोड करें।

ध्यान दें:
- यह debug APK होगी, Play Store रिलीज़ के लिए signed release build अलग से चाहिए।
- Admin panel demo है; secure admin login/cloud database अभी नहीं है।
- नोट्स/प्रगति डिवाइस के local storage में सेव होते हैं।
