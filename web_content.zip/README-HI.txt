MY UDHAR BOOK — Mobile Demo ZIP

1. ZIP Extract करें।
2. index.html को Android Chrome में खोलें।
3. चाहें तो Chrome menu से Add to Home screen चुनें।

डेमो सुविधाएँ: ग्राहक खाता, मोबाइल नंबर, कुल उधार/जमा/बाकी, लेन-देन हिस्ट्री,
इनवॉइस में सामान का नाम, क्वांटिटी, रेट, टोटल, जमा और उधार एंट्री, ग्राहक विवरण edit,
WhatsApp/कॉल लिंक और Print/PDF।

ध्यान दें: यह frontend demo है। डेटा इसी ब्राउज़र में local storage में सेव होता है।
वास्तविक login, online server/database, Google Drive backup/sync, दूसरे फोन पर restore,
multi-user, automated SMS/WhatsApp और production GST accounting अभी शामिल नहीं हैं।
दिखाए गए ग्राहक/बिल sample data हैं।
