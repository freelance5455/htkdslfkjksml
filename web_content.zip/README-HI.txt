MY UDHAR BOOK — Dashboard Demo

इस ZIP में शामिल:
- आधुनिक Hindi/English Dashboard UI
- ग्राहक, सप्लायर, उधार, जमा और बिल के quick-action demo forms
- कुल ग्राहक/सप्लायर, उधार, जमा और बाकी राशि के dashboard cards
- हाल की लेन-देन, आज की बिक्री/वसूली और reminder panels
- Search bar और mobile responsive layout

चलाने का तरीका:
1. ZIP को मोबाइल में डाउनलोड करके Extract करें।
2. index.html को Chrome में खोलें।
3. इंटरनेट के बिना भी यह static demo खुल सकता है।

महत्वपूर्ण सीमा:
यह केवल frontend/demo है। इसमें अभी वास्तविक database/server, secure login,
Google Drive automatic sync, दूसरे मोबाइल पर restore, multi-user permissions,
WhatsApp/SMS automation, live accounting calculations और वास्तविक invoice/stock
management connected नहीं हैं। Google Drive + Hard Disk वाला banner अभी design preview है,
वास्तविक backup status नहीं। Production में इस्तेमाल करने से पहले backend और security
जोड़ना आवश्यक है।
