नवयुवा दुर्गा पूजा समिति — HTML app ZIP

फ़ाइलें:
- index.html: मोबाइल-फ्रेंडली ऐप UI और लोकल डेमो लॉजिक
- durga-cover.jpg: अपलोड किए गए रेफरेंस से काटी गई माँ दुर्गा कवर इमेज
- firestore.rules: सुरक्षित default-deny starter rules

चलाने का तरीका:
1. ZIP extract करें या ऐसे HTML-to-APK builder में ZIP upload करें जो index.html को entry page मानता हो।
2. ऐप को पहली बार खोलकर Admin Login चुनें।
3. Admin ID: 7905106011
   Password: Gyan@123
4. Admin से Create User में यूज़र ID और password बनाएं।
5. यूज़र User Login टैब से लॉगिन करे।

महत्वपूर्ण सीमाएँ:
- यह build localStorage demo है; डेटा केवल उसी browser/app installation में रहता है। अलग-अलग फोन पर sync नहीं होता।
- Login credentials इस demo में client-side हैं; इसे सार्वजनिक/वास्तविक इस्तेमाल के लिए सुरक्षित authentication न मानें।
- Firestore rules जानबूझकर deny-all हैं; Firebase जोड़ने के बाद UID आधारित authentication और rules बनाना होगा।
- Save PDF / Print browser की print dialog खोलता है। Android WebView/बिल्डर के अनुसार print support अलग हो सकता है।
- WhatsApp बटन रसीद का टेक्स्ट शेयर करता है; यह अपने-आप PDF attachment नहीं भेजता। PDF भेजने के लिए पहले PDF save करें और WhatsApp में attach करें।
- इस ZIP को वास्तविक Android APK में compile या सभी उपकरणों पर test नहीं किया गया है।
