# PS5 Mobile (fan-made mini-game launcher)

This is an Android Studio project for an offline, PS5-inspired dashboard with three playable mini-games:

- Neon Runner
- Memory Match
- Block Smash

It is **not** a PlayStation product, does not emulate a PS5, and does not run PS5 games. It uses original interface styling and simple original mini-games.

## Build an APK

1. Install Android Studio (current stable version) on a computer.
2. Open this `PS5Mobile` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. You may need to allow installation from the file manager you use.

Minimum Android version: Android 6.0 (API 23).
