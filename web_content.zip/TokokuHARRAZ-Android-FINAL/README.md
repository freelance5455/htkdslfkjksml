# Tokoku HARRAZ — Android Final Project

Project Android Studio untuk Tokoku HARRAZ.

## Fitur final
- Produk: barcode/SKU, harga beli/HPP, harga jual, stok, kategori, foto produk.
- Kasir: scan barcode untuk memasukkan produk ke troli.
- Kamera: scan barcode, foto produk, foto logo warung.
- Thermal: Bluetooth ESC/POS dan USB OTG, 58/80 mm, test print, preview/cetak.
- Screenshot preview struk/laporan.
- Riwayat transaksi dan laporan terhubung ke database aplikasi yang sama.
- Backup lengkap JSON.
- Backup Excel-compatible `.xls` yang dapat dibuka di Microsoft Excel/LibreOffice; berisi sheet/tabel Produk, Penjualan, Pelanggan, Supplier, Karyawan, Pengeluaran, HutangPiutang, Diskon, LaciKas, Antrian, Meja serta blok DATABASE_JSON untuk restore.
- Restore dari backup lengkap maupun file Excel backup yang dibuat aplikasi.

## Membuka di Android Studio
1. Ekstrak ZIP.
2. Android Studio > Open > pilih folder `TokokuHARRAZ-Android`.
3. Pastikan Android SDK Platform 35 tersedia.
4. Gradle Sync akan mengambil Android Gradle Plugin dan ML Kit Barcode Scanning.
5. Build > Build APK(s).

## Catatan printer
Bluetooth thermal harus sudah dipasangkan di Android. Implementasi Bluetooth menggunakan ESC/POS SPP; implementasi USB memakai USB Host/bulk endpoint dan bergantung pada kompatibilitas printer.

## Catatan barcode
Barcode menggunakan kamera Android dan ML Kit Barcode Scanning. Kamera meminta izin hanya saat fitur kamera dipakai.

## Catatan pindah HP
Untuk pindah HP, buat Backup Excel atau Backup Lengkap di HP lama, salin file ke HP baru, install aplikasi, lalu Restore. Data yang belum pernah dibackup di HP yang rusak tidak dapat dipulihkan.
