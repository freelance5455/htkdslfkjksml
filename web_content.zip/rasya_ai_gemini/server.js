import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

if (!process.env.GEMINI_API_KEY) {
  console.error('GEMINI_API_KEY belum diatur. Isi file .env terlebih dahulu.');
  process.exit(1);
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/chat', async (req, res) => {
  try {
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    const previousInteractionId = typeof req.body?.previousInteractionId === 'string'
      ? req.body.previousInteractionId : undefined;

    if (!message) return res.status(400).json({ error: 'Pesan tidak boleh kosong.' });
    if (message.length > 8000) return res.status(413).json({ error: 'Pesan terlalu panjang (maksimal 8.000 karakter).' });

    const interaction = await ai.interactions.create({
      model: process.env.GEMINI_MODEL || 'gemini-4-hydrogen',
      input: message,
      ...(previousInteractionId ? { previous_interaction_id: previousInteractionId } : {})
    });

    res.json({
      reply: interaction.output_text || 'Model tidak mengirim teks jawaban.',
      interactionId: interaction.id
    });
  } catch (error) {
    console.error('Gemini API error:', error?.message || error);
    res.status(500).json({ error: 'Gemini API gagal memproses pesan. Periksa konfigurasi key, model, dan kuota di AI Studio.' });
  }
});

app.listen(PORT, () => {
  console.log(`Rasya AI berjalan di http://localhost:${PORT}`);
});
