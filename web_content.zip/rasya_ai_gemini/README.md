# Rasya AI — Gemini API Prototype

Prototype chat web dengan backend Node.js. API key disimpan di server dalam `.env`, bukan di HTML.

## Persiapan
- Install Node.js versi 20 atau lebih baru.
- Buat API key baru di Google AI Studio: https://aistudio.google.com/api-keys
- Karena key yang sebelumnya dikirim ke chat sudah terekspos, nonaktifkan/revoke key lama dan gunakan key pengganti. Jangan kirim key baru ke chat atau menaruhnya di `public/index.html`.

## Menjalankan di komputer
1. Ekstrak ZIP ini.
2. Buka terminal di folder project.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Buka `.env`, ganti nilai `GEMINI_API_KEY` dengan key pengganti milikmu.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000`.

## Catatan
- Chat memakai Gemini Interactions API dan menyambungkan konteks percakapan dengan `previous_interaction_id`.
- Model default dapat diganti melalui `GEMINI_MODEL` di `.env` jika model tersebut tidak tersedia di project AI Studio kamu.
- Penggunaan API mengikuti kuota dan ketentuan akun Google AI Studio. Periksa dashboard Usage sebelum dipakai.
- Jangan deploy server dengan `.env` atau API key di repositori publik.
