package com.cxzbot.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 7001;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(7,19,38));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(36, 56, 36, 36);
        page.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView logo = new TextView(this);
        logo.setText("◈  CXZBOT");
        logo.setTextColor(Color.rgb(48,205,255));
        logo.setTextSize(32);
        logo.setGravity(Gravity.CENTER);
        page.addView(logo);

        TextView subtitle = new TextView(this);
        subtitle.setText("AI SCREEN ASSISTANT\nBaca teks yang terlihat di layar dengan izinmu.");
        subtitle.setTextColor(Color.WHITE);
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0,24,0,40);
        page.addView(subtitle);

        Button overlay = new Button(this);
        overlay.setText("1. Izinkan jendela mengambang");
        page.addView(overlay);
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                subtitle.setText("Izin overlay aktif. Lanjutkan dengan tombol mulai.");
            }
        });

        Button start = new Button(this);
        start.setText("2. Mulai CXZBOT");
        page.addView(start);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                subtitle.setText("Aktifkan izin jendela mengambang terlebih dahulu.");
                return;
            }
            MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mgr.createScreenCaptureIntent(), CAPTURE_REQUEST);
        });

        TextView note = new TextView(this);
        note.setText("\nPrivasi: Android akan menampilkan persetujuan berbagi layar. CXZBOT tidak boleh merekam diam-diam. Matikan layanan dari tombol STOP pada jendela bot.");
        note.setTextColor(Color.rgb(165,184,210));
        note.setTextSize(13);
        note.setPadding(0,28,0,0);
        page.addView(note);

        setContentView(page);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAPTURE_REQUEST && resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, ScreenReaderService.class);
            service.putExtra("resultCode", resultCode);
            service.putExtra("projectionData", data);
            startForegroundService(service);
            finish();
        }
    }
}
