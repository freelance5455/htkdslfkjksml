package com.cxzbot.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public class ScreenReaderService extends Service {
    private WindowManager wm;
    private View panel;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private boolean busy = false;
    private int width, height, density;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(11, new Notification.Builder(this, "cxzbot")
            .setContentTitle("CXZBOT aktif").setContentText("Berbagi layar berjalan atas izinmu.")
            .setSmallIcon(android.R.drawable.ic_menu_view).build());
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        int code = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data = intent.getParcelableExtra("projectionData");
        if (data == null || code != Activity.RESULT_OK) { stopSelf(); return START_NOT_STICKY; }
        DisplayMetrics m = getResources().getDisplayMetrics();
        width = m.widthPixels; height = m.heightPixels; density = m.densityDpi;
        projection = ((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE))
            .getMediaProjection(code, data);
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("CXZBOT-screen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
        showPanel();
        return START_NOT_STICKY;
    }

    private void showPanel() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18,14,18,14);
        box.setBackgroundColor(Color.rgb(10,25,48));
        TextView title = new TextView(this);
        title.setText("◈ CXZBOT  •  LIVE");
        title.setTextColor(Color.rgb(55,210,255));
        title.setTextSize(16);
        box.addView(title);
        TextView result = new TextView(this);
        result.setText("Tekan SCAN untuk membaca teks yang terlihat.");
        result.setTextColor(Color.WHITE);
        result.setTextSize(13);
        result.setPadding(0,12,0,12);
        box.addView(result);
        Button scan = new Button(this); scan.setText("SCAN LAYAR");
        box.addView(scan);
        Button stop = new Button(this); stop.setText("STOP / MATIKAN");
        box.addView(stop);
        scan.setOnClickListener(v -> captureAndRead(result));
        stop.setOnClickListener(v -> stopSelf());

        final WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            Math.min(width - 40, (int)(280*density/160f)),
            WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END; p.x = 12; p.y = 140;
        box.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY;
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY(); startX=p.x; startY=p.y; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    p.x=startX+(int)(downX-e.getRawX()); p.y=startY+(int)(e.getRawY()-downY);
                    wm.updateViewLayout(box,p); return true;
                }
                return false;
            }
        });
        panel = box;
        wm.addView(panel,p);
    }

    private void captureAndRead(TextView output) {
        if (busy || reader == null) return;
        busy = true; output.setText("Membaca layar…");
        reader.setOnImageAvailableListener(r -> {
            Image image = r.acquireLatestImage();
            if (image == null) { busy=false; return; }
            Bitmap bitmap = imageToBitmap(image);
            image.close();
            if (bitmap == null) { busy=false; output.setText("Gagal membaca layar."); return; }
            InputImage input = InputImage.fromBitmap(bitmap,0);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(input)
                .addOnSuccessListener(text -> output.setText(text.getText().isEmpty() ?
                    "Tidak menemukan teks yang terbaca." : text.getText()))
                .addOnFailureListener(err -> output.setText("Pemindaian gagal. Coba lagi."))
                .addOnCompleteListener(task -> { busy=false; reader.setOnImageAvailableListener(null,null); });
        }, null);
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;
        java.nio.ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride(), rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * width;
        Bitmap bmp = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
        bmp.copyPixelsFromBuffer(buffer);
        return Bitmap.createBitmap(bmp,0,0,width,height);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("cxzbot","CXZBOT",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        if (wm != null && panel != null) try { wm.removeView(panel); } catch(Exception ignored) {}
        if (display != null) display.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
