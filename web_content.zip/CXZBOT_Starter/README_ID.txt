CXZBOT STARTER — PROTOTIPE ANDROID

Isi:
- Tampilan awal HTML futuristik.
- Proyek Android Kotlin/Java untuk izin overlay.
- Jendela mengambang yang bisa digeser.
- Persetujuan screen capture Android.
- OCR lokal memakai Google ML Kit untuk membaca teks yang terlihat di layar.

PENTING:
1. Ini adalah SOURCE PROJECT, bukan APK siap pasang.
2. Belum ada mesin AI yang menghasilkan jawaban. OCR hanya mengekstrak teks layar.
3. Untuk jawaban AI perlu backend/API yang aman. Jangan menaruh API key rahasia di HTML atau APK.
4. Android akan selalu meminta izin berbagi layar. Jangan gunakan untuk menangkap layar orang lain tanpa izin.
5. Prototype ini belum mengimplementasikan pengubahan ukuran jendela dengan handle khusus; ukuran awal mengikuti layar.

Build:
- Buka folder proyek di Android Studio pada komputer.
- Gunakan JDK 17 dan Android SDK 35.
- Sync Gradle, lalu Build > Build APK(s).
- Uji pada Android 11+.

Catatan pengembangan:
- Sebelum rilis, tambahkan tombol resize, penanganan rotasi layar, notifikasi stop, dan backend AI.
- Gunakan hanya pada tugas/latihan yang memang boleh dibantu AI; jangan dipakai untuk menipu tes IQ atau penilaian yang harus dikerjakan mandiri.
