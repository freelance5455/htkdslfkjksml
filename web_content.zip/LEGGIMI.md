# ILZ holder – pacchetto app

Contenuto
- www/            app completa (PWA): index.html, manifest, service worker, icone
- package.json, capacitor.config.json   progetto per creare l'app nativa Android/iOS

## Strada A – Installarla subito come app (PWA)
1. Copia il contenuto di www/ in Home Assistant: /config/www/ilz/  (crea la cartella www e riavvia HA la prima volta).
2. Apri dal telefono https://TUO-INDIRIZZO/local/ilz/index.html
   (serve https: Nabu Casa, oppure un tuo dominio con reverse proxy; con http compare solo "aggiungi a Home").
3. iPhone: Safari > Condividi > Aggiungi a schermata Home. Android: Chrome > Installa app.
4. Nell'app: ⋮ > Impostazioni > URL di HA, token, gateway.

## Strada B – App nativa (APK / iOS) con Capacitor
Requisiti: Node.js 18+, Android Studio (per Android) oppure Mac con Xcode (per iOS).
    npm install
    npx cap add android      # e/o: npx cap add ios
    npm run android          # apre Android Studio: Build > Build APK
    npm run ios              # apre Xcode: Product > Archive
La configurazione permette già connessioni http verso Home Assistant in rete locale.
Su iOS aggiungi in Info.plist: NSAppTransportSecurity > NSAllowsLocalNetworking = YES.
Per pubblicare sugli store servono gli account sviluppatore (Google Play 25 $ una tantum, Apple 99 $/anno).

## Alternativa senza programmare
Con la PWA online su https, pwabuilder.com genera i pacchetti Android/iOS partendo dall'URL.
