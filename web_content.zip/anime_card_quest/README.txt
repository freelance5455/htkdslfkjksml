ANIME CARD QUEST

To play on Android:
1. Extract anime_card_quest.zip using Files / File Manager.
2. Tap index.html and open it with Chrome.
3. The game runs offline after opening and saves progress in that browser.

This is a fan-made mini game, not an official One Piece, Naruto, or Black Clover product.
