GEOLINIX v1.3 — REVENUE ENGINE
Based on the v1.2 dynamic lobby.

NEW
- Business Hub opens from the Business navigation item and Business cards.
- Business profile draft form with local-device saving.
- Draft subscription plan selector (K0 / K150 / K300 monthly assumptions).
- Revenue scenario calculator showing monthly and weekly gross estimates.
- Explicit preview labels and honest notices for features not yet connected.

ANDROID PREVIEW
1. Extract this ZIP.
2. Open index.html in Chrome.

IMPORTANT LIMITATIONS
This is a front-end prototype, not an APK or production service. Business drafts are stored only in the current browser on this device; they are not uploaded or published. Plan selections are previews only. No real subscriptions, customer accounts, public business listings, advertising delivery, analytics, payment processing or payouts are connected. The revenue calculator shows hypothetical gross revenue, not actual earnings or profit. Prices are unvalidated planning assumptions.

NEXT ENGINEERING STAGES
1. Secure backend and account/authentication architecture.
2. Business listing database and moderation.
3. Subscription entitlements and provider-hosted checkout with an approved payment provider.
4. Auditable revenue and payout reporting.
5. Business analytics and promotion delivery.
