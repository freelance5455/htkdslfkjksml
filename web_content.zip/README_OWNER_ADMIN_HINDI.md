Growth Saller — Owner Order Panel Update

Owner email allowlist: ranveerjaiswal282@gmail.com

Added:
- Owner panel is shown only when this exact email is signed in and its Firebase email is verified.
- Backend adminUpdateOrder checks the exact verified owner email; regular users cannot update order statuses through the callable function.
- New orders save the customer's email in userEmail.
- Owner order list includes customer email, order ID, service, quantity, total, payment status, creation time, and Pending / Processing / Completed / Cancelled status control.
- Status changes are saved through the trusted Cloud Function; customer sees updated status in My Orders after refreshing.

Important setup:
1. Upload/deploy the updated functions folder using Firebase CLI (functions dependencies must be installed).
2. Deploy Firestore rules and hosting files.
3. Owner must sign in with ranveerjaiswal282@gmail.com and verify that email in Firebase Authentication. Do not share password or OTP.
4. This ZIP is source code, not a compiled APK. Firebase project config, active service records, and deployment are still required. Existing older orders may not have userEmail saved, so they will show Email unavailable.
5. Email notification delivery is not included in this update; this panel provides the order list inside the app.
