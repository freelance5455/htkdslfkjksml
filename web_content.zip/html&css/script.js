
const display = document.getElementById("display");
const buttons = document.querySelector(".buttons");

const angleMode = document.getElementById("angleMode");
const themeToggle = document.getElementById("themeToggle");
const historyToggle = document.getElementById("historyToggle");
const historyPanel = document.getElementById("historyPanel");
const historyList = document.getElementById("historyList");
const clearHistory = document.getElementById("clearHistory");

let expression = "";
let angleUnit = "DEG";
let history = [];

function updateDisplay() {
  display.value = expression || "0";
}

function safeCalculate(input) {
  if (!input || input.length > 100) {
    throw new Error("ورودی نامعتبر");
  }

  if (!/^[0-9+\-*/().\sA-Za-z]+$/.test(input)) {
    throw new Error("کاراکتر نامعتبر");
  }

  const names = input.match(/[A-Za-z]+/g) || [];
  const allowed = ["sin", "cos", "tan", "sqrt"];

  if (names.some(name => !allowed.includes(name))) {
    throw new Error("تابع نامعتبر");
  }

  const code = input.replace(
    /\b(sin|cos|tan|sqrt)\s*\(/g,
    (match, fn) => {
      if (fn === "sqrt") {
        return "Math.sqrt(";
      }

      if (angleUnit === "DEG") {
        return "Math." + fn + "((Math.PI / 180) * ";
      }

      return "Math." + fn + "(";
    }
  );

  const result = Function(
    '"use strict"; return (' + code + ')'
  )();

  if (typeof result !== "number" || !Number.isFinite(result)) {
    throw new Error("نتیجه نامعتبر");
  }

  return Number(result.toPrecision(12));
}

function renderHistory() {
  historyList.replaceChildren();

  history.slice().reverse().forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${item.expression} = ${item.result}`;
    historyList.appendChild(li);
  });
}

function calculate() {
  try {
    const original = expression;
    const result = safeCalculate(original);

    history.push({
      expression: original,
      result: result
    });

    if (history.length > 20) {
      history.shift();
    }

    renderHistory();
    expression = String(result);
    updateDisplay();
  } catch (error) {
    console.error(error);
    display.value = "خطا";
    expression = "";
  }
}

buttons.addEventListener("click", event => {
  const button = event.target.closest("button");
  if (!button) return;

  const value = button.dataset.value;
  const action = button.dataset.action;

  if (action === "clear") {
    expression = "";
    updateDisplay();
    return;
  }

  if (action === "delete") {
    expression = expression.slice(0, -1);
    updateDisplay();
    return;
  }

  if (action === "calculate") {
    calculate();
    return;
  }

  if (value !== undefined && expression.length < 100) {
    expression += value;
    updateDisplay();
  }
});

angleMode.addEventListener("click", () => {
  angleUnit = angleUnit === "DEG" ? "RAD" : "DEG";
  angleMode.textContent = angleUnit;
});

themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("light");
});

historyToggle.addEventListener("click", () => {
  historyPanel.hidden = !historyPanel.hidden;
});

clearHistory.addEventListener("click", () => {
  history = [];
  renderHistory();
});

updateDisplay();




if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js")
      .then(() => {
        console.log("آماده برای اجرای آفلاین");
      })
      .catch(error => {
        console.error("خطا در ثبت Service Worker:", error);
      });
  });
}
