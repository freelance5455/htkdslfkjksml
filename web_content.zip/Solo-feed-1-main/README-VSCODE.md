# Solo Feed — تشغيل في VSCode

## المتطلبات
- Node.js 18 أو أحدث (https://nodejs.org)
- VSCode

## الخطوات
1. فك ضغط هذا الملف في مجلد، ثم افتح المجلد في VSCode:
   File > Open Folder...
2. افتح التيرمينال داخل VSCode (Ctrl + `) ثم:
   ```bash
   npm install
   npm run dev
   ```
3. افتح الرابط الذي يظهر (عادة http://localhost:5173)

## ملاحظات مهمة
- هذا هو مشروع Vite الأصلي (React + TS + Tailwind + Dexie).
- ملفات Perchance (main.pjs و index.html الجذرية و src/app المنقولة) غير موجودة هنا لأنها خاصة بمعاينة Perchance فقط — لا تحتاجها محلياً.
- ميزة AI (generateText) تعمل فقط داخل Perchance. محلياً ستظهر رسالة "Not available" وهذا طبيعي — باقي التطبيق يعمل كاملاً (Feed / Sections / Archive / Settings / Export...).
- للبناء للإنتاج:
  ```bash
  npm run build
  npm run preview
  ```
