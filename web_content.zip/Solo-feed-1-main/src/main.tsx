import React from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";
import { ErrorBoundary } from "./components/ErrorBoundary";
import "./index.css";
import { db } from "./db/db";

declare global {
  interface Window {
    __sf?: unknown;
  }
}

// Debug handle for development only. In production/preview builds
// import.meta.env.DEV is falsy, so the full database is never exposed to
// page scripts (third-party CDN code, extensions, injected snippets).
if ((import.meta as unknown as { env?: Record<string, unknown> }).env?.DEV) {
  window.__sf = { db };
}

// Register the PWA service worker only in real builds (Vite defines
// import.meta.env). In other runtimes this branch is skipped entirely.
if ((import.meta as unknown as { env?: Record<string, string> }).env?.MODE !== undefined) {
  import("./pwa").catch(() => {
    // PWA registration is best-effort; the app works fully without it.
  });
}

const el = document.getElementById("sf-root") ?? document.getElementById("root");
if (el) {
  createRoot(el).render(
    <React.StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </React.StrictMode>
  );
  requestAnimationFrame(() =>
    requestAnimationFrame(() => document.getElementById("sf-splash")?.remove())
  );
} else {
  console.error("SoloFeed: no root element found.");
}
