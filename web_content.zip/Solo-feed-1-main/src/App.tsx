import { useEffect, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { DatabaseZap, Heart, Plus } from "lucide-react";
import { db, seedIfEmpty } from "./db/db";
import { useLiveQuery } from "./hooks";
import { Feed } from "./components/Feed";
import { AiChat, type AiChatContext } from "./components/AiChat";
import { CaptureModal } from "./components/CaptureModal";
import { PostDetail } from "./components/PostDetail";
import { Settings } from "./components/Settings";
import { BottomNav } from "./components/BottomNav";
import { Studio } from "./components/Studio";
import { Notifications, useActivity } from "./components/Notifications";

export type Tab = "feed" | "insights" | "studio";

export function App() {
  const [tab, setTab] = useState<Tab>("feed");
  const [detailId, setDetailId] = useState<string | null>(null);
  const [captureOpen, setCaptureOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [aiContext, setAiContext] = useState<AiChatContext | null>(null);
  const [feedKey, setFeedKey] = useState(0);
  const [notifOpen, setNotifOpen] = useState(false);
  const [dbBlocked, setDbBlocked] = useState(false);
  const activity = useActivity();
  const activeCount = useLiveQuery(
    () => db.posts.where("status").equals("active").count(),
    []
  );

  useEffect(() => {
    // If the local database cannot be opened within 12s it is almost
    // always locked by another open tab (IndexedDB allows only one
    // version upgrade at a time). Show a recovery screen instead of an
    // endless skeleton — no data is lost, the other tab just needs closing.
    let alive = true;
    const timer = window.setTimeout(() => {
      if (alive) setDbBlocked(true);
    }, 12000);
    seedIfEmpty()
      .then(() => {
        if (alive) {
          window.clearTimeout(timer);
          setDbBlocked(false);
        }
      })
      .catch((e) => {
        console.error("SoloFeed seed failed:", e);
        if (alive) {
          window.clearTimeout(timer);
          setDbBlocked(true);
        }
      });
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, []);

  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric"
  });

  function openInsights(ctx: AiChatContext | null) {
    setAiContext(ctx);
    setDetailId(null);
    setTab("insights");
  }

  return (
    <div className="min-h-screen bg-void font-sans text-cream">
      <header className="sticky top-0 z-30 border-b border-white/10 bg-void/90 backdrop-blur">
        <div className="mx-auto flex max-w-xl items-center gap-1 px-4 pb-1 pt-2">
          <button
            onClick={() => setCaptureOpen(true)}
            aria-label="Create a new post"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-cream transition active:scale-90"
          >
            <Plus size={27} strokeWidth={1.8} />
          </button>
          <div className="min-w-0 flex-1 text-center">
            <h1 className="ig-wordmark">Solo Feed</h1>
            <p className="-mt-0.5 truncate text-[10px] tracking-wide text-mist">
              {today}
              {typeof activeCount === "number" ? " · " + activeCount + " active" : ""}
            </p>
          </div>
          <button
            onClick={() => {
              setNotifOpen(true);
              setDetailId(null);
            }}
            aria-label="Activity and reminders"
            className={
              "relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition active:scale-90 " +
              (notifOpen ? "text-clay" : "text-cream")
            }
          >
            <Heart size={24} strokeWidth={1.8} fill={notifOpen ? "currentColor" : "none"} />
            {activity.loaded && activity.count > 0 && !notifOpen && (
              <span className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full border-2 border-void bg-clay" />
            )}
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-xl px-4 pb-36 pt-4">
        {dbBlocked ? (
          <div className="mt-10 flex flex-col items-center gap-3 px-6 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gold/15 text-gold">
              <DatabaseZap size={26} />
            </span>
            <p className="font-semibold text-cream">Your sanctuary is locked</p>
            <p className="max-w-sm text-sm leading-relaxed text-mist">
              Another open tab is holding the local database. Close any other
              Solo Feed tabs, then try again — nothing is lost.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="mt-1 rounded-full bg-solo px-5 py-2.5 text-sm font-bold text-white shadow-[0_8px_20px_rgba(79,70,229,0.4)] active:scale-95"
            >
              Try again
            </button>
          </div>
        ) : (
          <>
            {tab === "feed" && <Feed rotation={feedKey} onOpen={setDetailId} onCapture={() => setCaptureOpen(true)} />}
            {tab === "insights" && (
              <AiChat context={aiContext} onClearContext={() => setAiContext(null)} />
            )}
            {tab === "studio" && <Studio onOpen={setDetailId} />}
          </>
        )}
      </main>

      <BottomNav
        tab={tab}
        onTab={(t) => {
          if (t === "feed") {
            // Rotate the post order ONLY when re-pressing Feed while
            // already on it. Coming back from another tab keeps the
            // current order — otherwise the list would reshuffle on
            // every return for no visible reason.
            if (tab === "feed") setFeedKey((k) => k + 1);
            try {
              window.scrollTo({ top: 0, behavior: "smooth" });
            } catch {
              window.scrollTo(0, 0);
            }
          }
          if (t === "studio") {
            try {
              window.scrollTo({ top: 0, behavior: "smooth" });
            } catch {
              window.scrollTo(0, 0);
            }
          }
          setTab(t);
          setDetailId(null);
        }}
        onSettings={() => {
          setSettingsOpen(true);
          setDetailId(null);
        }}
        settingsActive={settingsOpen}
      />

      <AnimatePresence>
        {captureOpen && <CaptureModal key="capture" onClose={() => setCaptureOpen(false)} />}
        {detailId && (
          <PostDetail
            key={"detail-" + detailId}
            postId={detailId}
            onBack={() => setDetailId(null)}
            onAskAi={(postId, excerpt) => openInsights({ postId, excerpt })}
          />
        )}
        {settingsOpen && (
          <Settings
            key="settings"
            onClose={() => setSettingsOpen(false)}
            onOpenPost={(id) => setDetailId(id)}
          />
        )}
        {notifOpen && (
          <Notifications
            key="notifications"
            onBack={() => setNotifOpen(false)}
            onOpen={(id) => {
              setNotifOpen(false);
              setDetailId(id);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
