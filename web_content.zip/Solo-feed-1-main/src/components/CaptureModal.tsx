import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ImagePlus, Loader2, X } from "lucide-react";
import imageCompression from "browser-image-compression";
import { addPost } from "../db/db";
import { SlideEditor, compressPhoto, type DraftSlide } from "./SlideEditor";
import { TagSuggest } from "./TagSuggest";

interface Props {
  onClose: () => void;
}

export function CaptureModal({ onClose }: Props) {
  const [text, setText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [extras, setExtras] = useState<DraftSlide[]>([]);
  const [preview, setPreview] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    taRef.current?.focus();
  }, []);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const canPost =
    (text.trim().length > 0 ||
      file !== null ||
      extras.some((d) => d.text.trim().length > 0 || d.file !== null)) &&
    !saving;

  async function handlePost() {
    if (!canPost) return;
    setSaving(true);
    setError(null);
    try {
      let blob: Blob | null = null;
      if (file) blob = await compressPhoto(file);
      const slides = [];
      for (const d of extras) {
        const t = d.text.slice(0, 5000);
        const b = d.file ? await compressPhoto(d.file) : null;
        if (!t.trim() && !b) continue;
        slides.push({ text: t, mediaBlob: b });
      }
      await addPost(text, blob, slides);
      onClose();
    } catch (e) {
      console.error("SoloFeed capture failed:", e);
      setError("Could not save. Please try again.");
      setSaving(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-label="Capture a new post"
    >
      <button
        aria-label="Close capture"
        onClick={onClose}
        className="absolute inset-0 h-full w-full cursor-default"
      />
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "tween", duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className="absolute inset-x-0 bottom-0 mx-auto w-full max-w-xl rounded-t-3xl border-t border-white/10 bg-card p-4 pb-[max(1.5rem,env(safe-area-inset-bottom))]"
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-base font-bold text-cream">New post</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-mist active:scale-95"
          >
            <X size={18} />
          </button>
        </div>

        <textarea
          ref={taRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={5}
          placeholder="What is alive in your mind right now? Add #tags to find it later."
          className="w-full resize-none rounded-2xl border border-white/10 bg-void p-3.5 text-[15px] leading-relaxed text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none"
        />

        <TagSuggest
          text={text}
          extraTexts={extras.map((d) => d.text)}
          onInsert={setText}
        />

        <SlideEditor value={extras} onChange={setExtras} />

        {preview && (
          <div className="relative mt-3">
            <img
              src={preview}
              alt="Attachment preview"
              className="max-h-48 w-full rounded-xl object-cover"
            />
            <button
              onClick={() => {
                setFile(null);
                if (fileRef.current) fileRef.current.value = "";
              }}
              aria-label="Remove photo"
              className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/70 text-white active:scale-95"
            >
              <X size={16} />
            </button>
          </div>
        )}

        {error && <p className="mt-2 text-sm text-clay">{error}</p>}

        <div className="mt-3 flex items-center gap-2">
          <button
            onClick={() => fileRef.current?.click()}
            aria-label="Attach a photo"
            className="flex h-12 w-12 items-center justify-center rounded-full border border-white/10 bg-void text-mist active:scale-95"
          >
            <ImagePlus size={20} />
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0] ?? null;
              setFile(f);
            }}
          />
          <button
            onClick={handlePost}
            disabled={!canPost}
            className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-solo text-[15px] font-bold text-white shadow-[0_8px_20px_rgba(79,70,229,0.4)] transition active:scale-[0.98] disabled:opacity-40 disabled:shadow-none"
          >
            {saving && <Loader2 size={17} className="animate-spin" />}
            {saving ? "Saving" : "Post to my feed"}
          </button>
        </div>
        <p className="mt-2 text-center text-xs text-mist">
          Private by design — stored only on this device.
        </p>
      </motion.div>
    </motion.div>
  );
}
