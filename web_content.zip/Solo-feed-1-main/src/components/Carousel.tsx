import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Heart } from "lucide-react";
import type { Slide } from "../db/db";

interface Props {
  /** Main post photo (slide zero). Kept separate so legacy posts render as-is. */
  mainUrl: string | null;
  slides: Slide[];
  burst: boolean;
  onDoubleTap: () => void;
}

interface Page {
  url: string | null;
  text: string;
}

/**
 * Instagram-style infinite carousel: swipe/dots/counter, wraps around.
 * Swipe is implemented with manual pointer handlers (NOT framer drag)
 * because this carousel nests inside PostCard's swipe-to-archive drag —
 * a native bubble-phase stopPropagation on pointerdown keeps archive
 * gestures starting here from ever reaching the card.
 */
export function Carousel({ mainUrl, slides, burst, onDoubleTap }: Props) {
  const [slideUrls, setSlideUrls] = useState<Array<string | null>>([]);
  const [index, setIndex] = useState(0);
  const [dragX, setDragX] = useState<number | null>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const gesture = useRef<{ startX: number; id: number } | null>(null);

  const pages: Page[] = [];
  if (mainUrl) pages.push({ url: mainUrl, text: "" });
  // slideUrls lags one render behind slides (effect above); missing entries
  // resolve to null and fill in once the object URLs are created.
  slides.forEach((s, i) => {
    pages.push({ url: slideUrls[i] ?? null, text: s.text || "" });
  });
  const n = pages.length;
  const safeIndex = n === 0 ? 0 : ((index % n) + n) % n;

  function go(d: number) {
    if (n <= 1) return;
    setDragX(null);
    gesture.current = null;
    setIndex((idx) => (((idx + d) % n) + n) % n);
  }

  useEffect(() => {
    const urls = slides.map((s) => {
      try {
        return s.mediaBlob ? URL.createObjectURL(s.mediaBlob) : null;
      } catch {
        return null;
      }
    });
    setSlideUrls(urls);
    return () => {
      for (const u of urls) {
        if (u) {
          try {
            URL.revokeObjectURL(u);
          } catch {
            // ignore
          }
        }
      }
    };
  }, [slides]);

  // Swipe gestures live here as NATIVE listeners (not React synthetic
  // ones): the pointerdown stop below blocks the event from bubbling to
  // PostCard's swipe-to-archive drag, and that same stop would also kill
  // React synthetic handlers on this track — native listeners on the track
  // itself still run (same-node listeners are unaffected by stopPropagation).
  useEffect(() => {
    const track = trackRef.current;
    if (!track || n <= 1) return;
    const start = (e: PointerEvent) => {
      if (e.pointerType === "mouse" && e.button !== 0) return;
      gesture.current = { startX: e.clientX, id: e.pointerId };
      setDragX(0);
      e.stopPropagation();
    };
    const move = (e: PointerEvent) => {
      const g = gesture.current;
      if (!g || e.pointerId !== g.id) return;
      setDragX(e.clientX - g.startX);
    };
    const end = (e: PointerEvent) => {
      const g = gesture.current;
      if (!g || e.pointerId !== g.id) return;
      const dx = e.clientX - g.startX;
      gesture.current = null;
      setDragX(null);
      if (dx <= -60) go(1);
      else if (dx >= 60) go(-1);
    };
    track.addEventListener("pointerdown", start);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
    window.addEventListener("pointercancel", end);
    return () => {
      track.removeEventListener("pointerdown", start);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", end);
      window.removeEventListener("pointercancel", end);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [n, mainUrl, slides]);

  if (n === 0) return null;

  const burstOverlay = burst ? (
    <span className="pointer-events-none absolute inset-0 flex items-center justify-center">
      <Heart
        size={92}
        fill="white"
        className="ig-burst text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.6)]"
      />
    </span>
  ) : null;

  // Single photo, no extra pages: identical to the legacy rendering.
  if (n === 1 && !pages[0].text) {
    return (
      <div
        className="relative"
        style={{ marginLeft: -16, marginRight: -16 }}
        onDoubleClick={onDoubleTap}
      >
        {pages[0].url && (
          <img
            src={pages[0].url}
            alt="Memory attached to this post"
            loading="lazy"
            className="block max-h-[520px] w-full select-none object-cover"
            draggable={false}
          />
        )}
        {burstOverlay}
      </div>
    );
  }

  return (
    <div className="relative" style={{ marginLeft: -16, marginRight: -16 }}>
      <div className="overflow-hidden" style={{ touchAction: "pan-y" }}>
        <div
          ref={trackRef}
          className="flex"
          style={{
            transform: `translateX(calc(${-safeIndex * 100}% + ${dragX ?? 0}px))`,
            transition: dragX !== null ? "none" : "transform 0.25s ease-out"
          }}
        >
          {pages.map((p, i) => (
            <div
              key={i}
              className="w-full shrink-0 select-none"
              onDoubleClick={onDoubleTap}
            >
              {p.url && (
                <img
                  src={p.url}
                  alt={"Page " + (i + 1) + " of " + n}
                  loading="lazy"
                  className="block max-h-[520px] w-full select-none object-cover"
                  draggable={false}
                />
              )}
              {p.text && (
                <div className="px-8 py-8">
                  <p className="whitespace-pre-wrap text-[15px] leading-relaxed text-cream">
                    {p.text}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      {burstOverlay}
      {n > 1 && (
        <span className="absolute right-2 top-2 rounded-full bg-black/60 px-2.5 py-1 text-[11px] font-bold text-white">
          {safeIndex + 1}/{n}
        </span>
      )}
      {n > 1 && (
        <>
          <button
            onClick={() => go(-1)}
            aria-label="Previous page"
            className="absolute left-1 top-1/2 hidden h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-black/50 text-white active:scale-95 sm:flex"
          >
            <ChevronLeft size={18} />
          </button>
          <button
            onClick={() => go(1)}
            aria-label="Next page"
            className="absolute right-1 top-1/2 hidden h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-black/50 text-white active:scale-95 sm:flex"
          >
            <ChevronRight size={18} />
          </button>
          <div className="flex items-center justify-center gap-1.5 py-2">
            {pages.map((_, i) => (
              <button
                key={i}
                onClick={() => {
                  setDragX(null);
                  gesture.current = null;
                  setIndex(i);
                }}
                aria-label={"Go to page " + (i + 1)}
                className={
                  "h-1.5 rounded-full transition-all " +
                  (i === safeIndex ? "w-4 bg-solosoft" : "w-1.5 bg-white/25")
                }
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
