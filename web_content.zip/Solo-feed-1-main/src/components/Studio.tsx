import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Bell,
  BellOff,
  BookmarkPlus,
  Check,
  Loader2,
  Network,
  Pencil,
  Plus,
  Sparkles,
  Trash2,
  User,
  X
} from "lucide-react";
import {
  addAiPost,
  addPost,
  creatorTag,
  db,
  DEFAULT_AI_CREATORS,
  deleteAiPost,
  markAiPostSaved,
  replaceAiCreators,
  seedAiCreatorsIfEmpty,
  setCreatorMuted,
  touchCreatorSeen,
  type AiCreator
} from "../db/db";
import { useLiveQuery } from "../hooks";
import { GraphView } from "./GraphView";
import { timeAgo } from "../lib/time";
import { isAiAvailable, isAiEnabled } from "../lib/ai";
import {
  generateCreatorPost,
  loadInterests,
  proposeTeam,
  saveInterests,
  SUGGESTED_INTERESTS
} from "../lib/creators";

type SubTab = "ai" | "graph";

interface StudioProps {
  onOpen: (id: string) => void;
  initial?: SubTab;
}

export function Studio({ onOpen, initial }: StudioProps) {
  const [sub, setSub] = useState<SubTab>(initial ?? "ai");
  return (
    <div>
      <div className="mb-3 grid grid-cols-2 gap-1 rounded-full bg-card p-1">
        <button
          onClick={() => setSub("ai")}
          className={
            "flex items-center justify-center gap-1.5 rounded-full px-3 py-2 text-xs font-bold transition " +
            (sub === "ai" ? "bg-solo text-white" : "text-mist")
          }
        >
          <Sparkles size={15} />
          AI Studio
        </button>
        <button
          onClick={() => setSub("graph")}
          className={
            "flex items-center justify-center gap-1.5 rounded-full px-3 py-2 text-xs font-bold transition " +
            (sub === "graph" ? "bg-solo text-white" : "text-mist")
          }
        >
          <Network size={15} />
          Graph view
        </button>
      </div>

      {sub === "ai" ? <AiStudio /> : <GraphView onOpen={onOpen} />}
    </div>
  );
}

// ---------------------------------------------------------------------------
// AI Studio: a team of specialized creator personas.
// ---------------------------------------------------------------------------

function AiStudio() {
  const creators = useLiveQuery(() => db.aiCreators.orderBy("createdAt").toArray(), []);
  const aiPosts = useLiveQuery(() => db.aiPosts.orderBy("createdAt").reverse().toArray(), []);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [interests, setInterests] = useState<string[]>(() => loadInterests());

  useEffect(() => {
    seedAiCreatorsIfEmpty().catch((e) => console.error("AI seed failed:", e));
  }, []);

  const counts = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of aiPosts ?? []) m.set(p.creatorId, (m.get(p.creatorId) ?? 0) + 1);
    return m;
  }, [aiPosts]);

  const unread = useMemo(() => {
    const byCreator = new Map<string, AiCreator>();
    for (const c of creators ?? []) byCreator.set(c.id, c);
    const m = new Map<string, number>();
    for (const p of aiPosts ?? []) {
      const c = byCreator.get(p.creatorId);
      if (c && p.createdAt > (c.lastSeen ?? 0)) m.set(p.creatorId, (m.get(p.creatorId) ?? 0) + 1);
    }
    return m;
  }, [aiPosts, creators]);

  if (creators === undefined || aiPosts === undefined) {
    return (
      <div className="grid grid-cols-3 gap-x-2 gap-y-5" aria-label="Loading creators">
        {Array.from({ length: 9 }).map((_, i) => (
          <div key={i} className="flex flex-col items-center gap-2">
            <div className="h-[72px] w-[72px] animate-pulse rounded-full bg-card" />
            <div className="h-3 w-14 animate-pulse rounded-full bg-card" />
          </div>
        ))}
      </div>
    );
  }

  const detail = creators.find((c) => c.id === detailId) ?? null;

  return (
    <div>
      <div className="mb-3 flex items-center gap-2">
        <p className="min-w-0 flex-1 truncate text-xs text-mist">
          {interests.length > 0 ? interests.slice(0, 4).join(" · ") : "Pick what you love"}
        </p>
        <button
          onClick={() => setEditorOpen(true)}
          className="inline-flex shrink-0 items-center gap-1 rounded-full bg-white/5 px-3 py-1.5 text-xs font-bold text-cream active:scale-95"
        >
          <Pencil size={13} />
          Interests
        </button>
      </div>

      <div className="grid grid-cols-3 gap-x-2 gap-y-5">
        <button onClick={() => setEditorOpen(true)} className="flex min-w-0 flex-col items-center active:scale-95">
          <span className="block rounded-full border-2 border-[#2f9bff] p-[2.5px]">
            <span className="flex h-[68px] w-[68px] items-center justify-center rounded-full bg-[#e8e8ec]">
              <User size={34} strokeWidth={1.4} className="text-[#1c1c22]" />
            </span>
          </span>
          <span className="mt-1.5 block px-0.5 text-center text-[13px] font-medium leading-tight text-cream">
            Me
          </span>
        </button>

        {creators.map((c) => (
          <button
            key={c.id}
            onClick={() => setDetailId(c.id)}
            aria-label={"Open creator " + c.name}
            className="relative flex min-w-0 flex-col items-center active:scale-95"
          >
            <span
              className="block rounded-full border-2 p-[2.5px]"
              style={{ borderColor: c.muted ? "#3a3a40" : "#2f9bff" }}
            >
              <span
                className="flex h-[68px] w-[68px] items-center justify-center rounded-full text-[30px]"
                style={{ backgroundColor: (c.color ?? "#4F46E5") + "26" }}
              >
                {c.emoji || "✨"}
              </span>
            </span>
            {(unread.get(c.id) ?? 0) > 0 && !c.muted && (
              <span className="absolute right-3 top-0 flex h-5 min-w-[20px] items-center justify-center rounded-full border-2 border-void bg-[#2f9bff] px-1 text-[10px] font-bold text-white">
                {unread.get(c.id)}
              </span>
            )}
            <span
              className={
                "mt-1.5 block max-w-full truncate px-0.5 text-center text-[13px] font-medium leading-tight " +
                (c.muted ? "text-mist/50" : "text-cream")
              }
            >
              {c.name}
            </span>
            {(counts.get(c.id) ?? 0) > 0 && (
              <span className="block text-center text-[11px] leading-tight text-mist">
                {counts.get(c.id)} {counts.get(c.id) === 1 ? "post" : "posts"}
              </span>
            )}
          </button>
        ))}
      </div>

      {creators.length === 0 && (
        <div className="mt-4 rounded-2xl border border-dashed border-white/15 bg-card/50 p-5 text-center">
          <p className="text-sm font-semibold text-cream">No creators yet</p>
          <p className="mx-auto mt-1 max-w-xs text-xs leading-relaxed text-mist">
            Tell the studio what you love and it will assemble your team.
          </p>
          <button
            onClick={() => setEditorOpen(true)}
            className="mt-3 rounded-full bg-solo px-5 py-2.5 text-sm font-bold text-white active:scale-95"
          >
            Choose interests
          </button>
        </div>
      )}

      {detail && (
        <CreatorDetail
          key={detail.id}
          creator={detail}
          posts={(aiPosts ?? []).filter((p) => p.creatorId === detail.id)}
          interests={interests}
          onBack={() => setDetailId(null)}
        />
      )}
      {editorOpen && (
        <InterestsEditor
          interests={interests}
          onSave={(list) => {
            setInterests(list);
            saveInterests(list);
          }}
          onClose={() => setEditorOpen(false)}
        />
      )}
    </div>
  );
}

function CreatorDetail({
  creator,
  posts,
  interests,
  onBack
}: {
  creator: AiCreator;
  posts: Array<{ id: string; content: string; createdAt: number; savedToFeed: boolean }>;
  interests: string[];
  onBack: () => void;
}) {
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const aliveRef = useRef(true);
  useEffect(() => {
    aliveRef.current = true;
    touchCreatorSeen(creator.id).catch(() => {});
    return () => {
      aliveRef.current = false;
    };
  }, [creator.id]);

  async function generate() {
    if (generating) return;
    if (!isAiEnabled()) {
      setError("Private AI is off — switch it on in Settings.");
      return;
    }
    if (!isAiAvailable()) {
      setError("No AI provider is ready — pick one in Settings.");
      return;
    }
    setGenerating(true);
    setError(null);
    try {
      const text = await generateCreatorPost(
        { name: creator.name, topic: creator.topic, prompt: creator.prompt },
        interests
      );
      await addAiPost(creator.id, text);
    } catch (e) {
      console.error("Creator post failed:", e);
      if (aliveRef.current)
        setError(e instanceof Error ? e.message : "Could not create right now. Try again.");
    } finally {
      if (aliveRef.current) setGenerating(false);
    }
  }

  async function saveToFeed(postId: string, content: string) {
    try {
      const tag = creatorTag(creator.topic);
      const hasTag = /#[\p{L}\p{N}_]+/u.test(content);
      await addPost(hasTag ? content : content + "\n#" + tag, null);
      await markAiPostSaved(postId);
    } catch (e) {
      console.error("Save to feed failed:", e);
      setError("Could not save to feed. Try again.");
    }
  }

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-50 bg-void"
      role="dialog"
      aria-modal="true"
      aria-label={"Creator " + creator.name}
    >
      <div className="mx-auto flex h-full max-w-xl flex-col">
        <div className="flex items-center gap-2 border-b border-white/10 px-2 py-2">
          <button
            onClick={onBack}
            aria-label="Back"
            className="flex h-10 w-10 items-center justify-center rounded-full text-cream active:scale-95"
          >
            <X size={20} />
          </button>
          <span
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-[22px]"
            style={{ backgroundColor: (creator.color ?? "#4F46E5") + "26" }}
          >
            {creator.emoji || "✨"}
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[15px] font-bold text-cream">{creator.name}</span>
            <span className="block truncate text-[11px] text-mist">
              {creator.topic} · {posts.length} {posts.length === 1 ? "post" : "posts"}
            </span>
          </span>
          <button
            onClick={() => void setCreatorMuted(creator.id, !creator.muted)}
            aria-label={creator.muted ? "Unmute creator" : "Mute creator"}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-mist active:scale-95"
          >
            {creator.muted ? <BellOff size={17} /> : <Bell size={17} />}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-4 pb-16 pt-4">
          <button
            onClick={() => void generate()}
            disabled={generating}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-solo py-3 text-sm font-bold text-white shadow-[0_8px_20px_rgba(79,70,229,0.4)] active:scale-[0.98] disabled:opacity-60"
          >
            {generating ? <Loader2 size={17} className="animate-spin" /> : <Sparkles size={17} />}
            {generating ? "Creating…" : "Create a new " + creator.name + " post"}
          </button>
          {generating && (
            <p className="mt-2 text-center text-xs text-mist">
              {creator.name} is writing in {creator.topic}…
            </p>
          )}
          {error && (
            <p className="mt-2 rounded-2xl border border-clay/40 bg-clay/10 p-3 text-sm text-cream">
              {error}
            </p>
          )}

          {posts.length === 0 && !generating ? (
            <div className="mt-6 px-4 text-center">
              <p className="text-sm font-semibold text-cream">Nothing here yet</p>
              <p className="mx-auto mt-1 max-w-xs text-xs leading-relaxed text-mist">
                {creator.name} writes specialized posts in {creator.topic}. Tap create
                above for the first one.
              </p>
            </div>
          ) : (
            <div className="mt-4 flex flex-col gap-3">
              {posts.map((p) => (
                <div key={p.id} className="rounded-2xl border border-white/10 bg-card p-4">
                  <p className="whitespace-pre-wrap text-[15px] leading-relaxed text-cream">
                    {p.content}
                  </p>
                  <p className="mt-1.5 text-[11px] text-mist">{timeAgo(p.createdAt)}</p>
                  <div className="mt-2.5 flex items-center gap-2">
                    {p.savedToFeed ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-white/5 px-3.5 py-2 text-xs font-bold text-mist">
                        <Check size={14} />
                        In your feed
                      </span>
                    ) : (
                      <button
                        onClick={() => void saveToFeed(p.id, p.content)}
                        className="inline-flex items-center gap-1 rounded-full bg-solo/15 px-3.5 py-2 text-xs font-bold text-solosoft active:scale-95"
                      >
                        <BookmarkPlus size={14} />
                        Save to feed
                      </button>
                    )}
                    <span className="flex-1" />
                    <button
                      onClick={() => void deleteAiPost(p.id)}
                      aria-label="Delete this post"
                      className="flex h-8 w-8 items-center justify-center rounded-full text-mist active:scale-95"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function InterestsEditor({
  interests,
  onSave,
  onClose
}: {
  interests: string[];
  onSave: (list: string[]) => void;
  onClose: () => void;
}) {
  const [draft, setDraft] = useState(interests);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState<"team" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);

  function addInterest(raw: string) {
    const t = raw.trim().slice(0, 30);
    if (!t) return;
    if (draft.some((d) => d.toLowerCase() === t.toLowerCase())) return;
    if (draft.length >= 12) return;
    setDraft([...draft, t]);
    setInput("");
  }

  function save() {
    onSave(draft);
    onClose();
  }

  async function buildTeam() {
    if (busy) return;
    if (draft.length === 0) {
      setError("Add at least one interest first.");
      return;
    }
    if (!isAiEnabled()) {
      setError("Private AI is off — switch it on in Settings to auto-build the team.");
      return;
    }
    if (!isAiAvailable()) {
      setError("No AI provider is ready — pick one in Settings first.");
      return;
    }
    setBusy("team");
    setError(null);
    setDone(null);
    try {
      const seeds = await proposeTeam(draft, Math.min(12, Math.max(4, draft.length + 2)));
      await replaceAiCreators(seeds);
      setDone(seeds.length + " creators ready — meet your team.");
    } catch (e) {
      console.error("Team build failed:", e);
      setError(e instanceof Error ? e.message : "Could not build the team right now. Try again.");
    } finally {
      setBusy(null);
    }
  }

  async function restoreDefaults() {
    try {
      await replaceAiCreators(DEFAULT_AI_CREATORS);
      setDone("Default team restored.");
      setError(null);
    } catch (e) {
      console.error("Restore failed:", e);
      setError("Could not restore. Try again.");
    }
  }

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-50 bg-void"
      role="dialog"
      aria-modal="true"
      aria-label="Edit interests"
    >
      <div className="mx-auto flex h-full max-w-xl flex-col">
        <div className="flex items-center gap-1 border-b border-white/10 px-2 py-2">
          <button
            onClick={onClose}
            aria-label="Back"
            className="flex h-10 w-10 items-center justify-center rounded-full text-cream active:scale-95"
          >
            <X size={20} />
          </button>
          <span className="text-sm font-bold text-cream">Your interests</span>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <p className="text-sm leading-relaxed text-mist">
            Creators are born from what you love — philosophy, business, books,
            sports, law and more.
          </p>
          <div className="mt-3 flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addInterest(input);
                }
              }}
              placeholder="Add an interest…"
              aria-label="Add an interest"
              className="h-11 flex-1 rounded-full border border-white/10 bg-card px-4 text-[15px] text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none"
            />
            <button
              onClick={() => addInterest(input)}
              aria-label="Add interest"
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-solo text-white active:scale-95"
            >
              <Plus size={19} />
            </button>
          </div>

          {draft.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {draft.map((t) => (
                <span
                  key={t}
                  className="inline-flex items-center gap-1.5 rounded-full bg-solo/15 py-1.5 pl-3.5 pr-2 text-sm font-semibold text-cream"
                >
                  {t}
                  <button
                    onClick={() => setDraft(draft.filter((d) => d !== t))}
                    aria-label={"Remove " + t}
                    className="flex h-6 w-6 items-center justify-center rounded-full text-mist active:scale-95"
                  >
                    <X size={13} />
                  </button>
                </span>
              ))}
            </div>
          )}

          <p className="mb-2 mt-4 text-xs font-bold uppercase tracking-wider text-mist">
            Suggestions
          </p>
          <div className="flex flex-wrap gap-2">
            {SUGGESTED_INTERESTS.filter(
              (s) => !draft.some((d) => d.toLowerCase() === s)
            ).map((s) => (
              <button
                key={s}
                onClick={() => addInterest(s)}
                className="rounded-full border border-white/10 bg-card px-3.5 py-1.5 text-sm text-cream active:scale-95"
              >
                + {s}
              </button>
            ))}
          </div>

          {error && (
            <p className="mt-3 rounded-2xl border border-clay/40 bg-clay/10 p-3 text-sm text-cream">
              {error}
            </p>
          )}
          {done && (
            <p className="mt-3 rounded-2xl border border-white/10 bg-card p-3 text-center text-sm text-cream">
              {done}
            </p>
          )}

          <button
            onClick={() => void buildTeam()}
            disabled={busy !== null}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-solo py-3 text-sm font-bold text-white shadow-[0_8px_20px_rgba(79,70,229,0.4)] active:scale-[0.98] disabled:opacity-60"
          >
            {busy === "team" ? <Loader2 size={17} className="animate-spin" /> : <Sparkles size={17} />}
            {busy === "team" ? "Assembling your team…" : "Build my team with AI"}
          </button>
          <div className="mt-2 flex gap-2">
            <button
              onClick={save}
              className="flex h-11 flex-1 items-center justify-center rounded-full border border-white/10 bg-card text-sm font-bold text-cream active:scale-[0.98]"
            >
              Save interests
            </button>
            <button
              onClick={() => void restoreDefaults()}
              className="flex h-11 flex-1 items-center justify-center rounded-full border border-white/10 bg-card text-sm font-bold text-mist active:scale-[0.98]"
            >
              Restore defaults
            </button>
          </div>
          <p className="mt-2 text-center text-[11px] text-mist">
            AI team uses your interests + recent feed tone. Works offline with the
            default team.
          </p>
        </div>
      </div>
    </motion.div>
  );
}

