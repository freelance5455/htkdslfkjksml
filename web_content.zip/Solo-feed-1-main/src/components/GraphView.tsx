import { useEffect, useMemo, useRef, useState } from "react";
import {
  Clock3,
  FileText,
  Hash,
  Maximize,
  Network,
  RotateCcw,
  ZoomIn,
  ZoomOut
} from "lucide-react";
import { db, hasPhoto, type Post } from "../db/db";
import { useLiveQuery } from "../hooks";
import { sectionColor } from "./Sections";
import { timeAgo } from "../lib/time";

type Mode = "force" | "timeline";

interface GNode {
  key: string;
  kind: "tag" | "post";
  label: string;
  color: string;
  r: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  post?: Post;
  tag?: string;
  count?: number;
}

interface GEdge {
  a: number;
  b: number;
}

function excerptOf(p: Post): string {
  const t = p.content.trim().replace(/\s+/g, " ");
  return t.length > 90 ? t.slice(0, 90) + "…" : t || "Untitled";
}

function postColor(p: Post): string {
  return p.tags.length > 0 ? sectionColor(p.tags[0]) : "#6d6d75";
}

function fmtMonth(t: number): string {
  try {
    return new Date(t).toLocaleDateString("en-US", {
      month: "short",
      year: "numeric"
    });
  } catch {
    return "";
  }
}

function pill(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export function GraphView({ onOpen }: { onOpen: (id: string) => void }) {
  const posts = useLiveQuery(
    () =>
      db.posts
        .where("status")
        .equals("active")
        .toArray()
        .then((rows) => rows.sort((a, b) => b.updatedAt - a.updatedAt)),
    []
  );

  const [mode, setMode] = useState<Mode>("force");
  const [filterTag, setFilterTag] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [layoutSeed, setLayoutSeed] = useState(0);

  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const viewRef = useRef({ x: 0, y: 0, z: 1 });
  const sizeRef = useRef({ w: 300, h: 420 });
  const nodesRef = useRef<GNode[]>([]);
  const edgesRef = useRef<GEdge[]>([]);
  const neighRef = useRef<Map<string, Set<string>>>(new Map());
  const metaRef = useRef<{ minT: number; maxT: number }>({ minT: 0, maxT: 0 });
  const simRef = useRef<number>(0);
  const energyRef = useRef(1);
  const dragRef = useRef<{
    pointerId: number;
    mode: "pan" | "node";
    nodeIdx: number;
    startX: number;
    startY: number;
    moved: boolean;
    viewX: number;
    viewY: number;
  } | null>(null);
  const pinchRef = useRef<Map<number, { x: number; y: number }>>(new Map());
  const pinchDistRef = useRef<number>(0);

  // Mirrors so stable canvas listeners always see fresh state.
  const modeRef = useRef<Mode>(mode);
  modeRef.current = mode;
  const filterRef = useRef<string | null>(filterTag);
  filterRef.current = filterTag;
  const selectedRef = useRef<string | null>(selected);
  selectedRef.current = selected;

  const built = useMemo(() => {
    const all = posts ?? [];
    const tagMap = new Map<string, { count: number; lastActive: number }>();
    for (const p of all) {
      for (const t of p.tags) {
        const e = tagMap.get(t) ?? { count: 0, lastActive: 0 };
        e.count++;
        if (p.updatedAt > e.lastActive) e.lastActive = p.updatedAt;
        tagMap.set(t, e);
      }
    }
    const nodes: GNode[] = [];
    const idxByKey = new Map<string, number>();
    const R = Math.max(120, Math.sqrt(all.length + tagMap.size) * 46);
    let i = 0;
    for (const [tag, info] of tagMap) {
      const ang = (i / Math.max(1, tagMap.size)) * Math.PI * 2;
      const key = "tag:" + tag;
      idxByKey.set(key, nodes.length);
      nodes.push({
        key,
        kind: "tag",
        label: "#" + tag,
        color: sectionColor(tag),
        r: 16 + Math.min(12, info.count * 2),
        x: Math.cos(ang) * R * 0.55,
        y: Math.sin(ang) * R * 0.55,
        vx: 0,
        vy: 0,
        tag,
        count: info.count
      });
      i++;
    }
    all.forEach((p, pi) => {
      const ang = (pi / Math.max(1, all.length)) * Math.PI * 2 + 0.6;
      const key = "post:" + p.id;
      idxByKey.set(key, nodes.length);
      nodes.push({
        key,
        kind: "post",
        label: excerptOf(p),
        color: postColor(p),
        r: 7 + Math.min(6, p.updateCount),
        x: Math.cos(ang) * R,
        y: Math.sin(ang) * R,
        vx: 0,
        vy: 0,
        post: p
      });
    });
    const edges: GEdge[] = [];
    for (const p of all) {
      const pi = idxByKey.get("post:" + p.id);
      if (pi === undefined) continue;
      if (p.tags.length === 0) continue;
      for (const t of p.tags) {
        const ti = idxByKey.get("tag:" + t);
        if (ti === undefined) continue;
        edges.push({ a: pi, b: ti });
      }
    }
    const tags = [...tagMap.entries()]
      .sort((a, b) => b[1].count - a[1].count || a[0].localeCompare(b[0]))
      .map(([t]) => t);
    let minT = 0;
    let maxT = 0;
    if (all.length > 0) {
      minT = all[0].updatedAt;
      maxT = all[0].updatedAt;
      for (const p of all) {
        if (p.updatedAt < minT) minT = p.updatedAt;
        if (p.updatedAt > maxT) maxT = p.updatedAt;
      }
    }
    return { nodes, edges, postCount: all.length, tagCount: tagMap.size, tags, minT, maxT };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [posts, layoutSeed]);

  // Position nodes for the active mode. Timeline spreads posts along a
  // time axis (old → new) and settles overlaps with a short synchronous
  // relaxation pass — no perpetual simulation needed there.
  const layout = useMemo(() => {
    const nodes = built.nodes.map((n) => ({ ...n, vx: 0, vy: 0 }));
    if (mode === "timeline" && nodes.length > 0) {
      const postIdx: number[] = [];
      const tagIdx: number[] = [];
      nodes.forEach((n, i) => (n.kind === "post" ? postIdx.push(i) : tagIdx.push(i)));
      const span = Math.max(1, built.maxT - built.minT);
      const spreadX = Math.max(340, postIdx.length * 52);
      const byKey = new Map(nodes.map((n, i) => [n.key, i]));
      postIdx.forEach((ni, k) => {
        const p = nodes[ni].post!;
        const frac = span > 0 ? (p.updatedAt - built.minT) / span : 0.5;
        nodes[ni].x = -spreadX / 2 + frac * spreadX;
        nodes[ni].y = ((((k * 0.61803398875) % 1) + 1) % 1 - 0.5) * 300;
      });
      // Tags start at their members' centroid.
      for (const ti of tagIdx) {
        const tag = nodes[ti].tag ?? "";
        let sx = 0;
        let sy = 0;
        let n = 0;
        for (const pi of postIdx) {
          if (nodes[pi].post!.tags.includes(tag)) {
            sx += nodes[pi].x;
            sy += nodes[pi].y;
            n++;
          }
        }
        if (n > 0) {
          nodes[ti].x = sx / n;
          nodes[ti].y = sy / n - 46;
        }
      }
      const iters = nodes.length > 500 ? 30 : 70;
      for (let k = 0; k < iters; k++) {
        for (let a = 0; a < nodes.length; a++) {
          for (let b = a + 1; b < nodes.length; b++) {
            const na = nodes[a];
            const nb = nodes[b];
            let dx = na.x - nb.x;
            let dy = na.y - nb.y;
            let d2 = dx * dx + dy * dy;
            if (d2 < 1) {
              dx = (k % 2 === 0 ? 1 : -1) * (1 + ((a * 7 + b * 13 + k) % 5));
              dy = (k % 2 === 0 ? -1 : 1) * (1 + ((a * 11 + b * 5 + k) % 5));
              d2 = dx * dx + dy * dy;
            }
            if (d2 > 25600) continue;
            const d = Math.sqrt(d2);
            const f = Math.min(3, 1500 / d2);
            na.x += (dx / d) * f * 0.5;
            na.y += (dy / d) * f * 0.5;
            nb.x -= (dx / d) * f * 0.5;
            nb.y -= (dy / d) * f * 0.5;
          }
        }
        for (const e of built.edges) {
          const a = byKey.get(built.nodes[e.a]?.key ?? "");
          const b = byKey.get(built.nodes[e.b]?.key ?? "");
          if (a === undefined || b === undefined) continue;
          const na = nodes[a];
          const nb = nodes[b];
          const dx = nb.x - na.x;
          const dy = nb.y - na.y;
          const d = Math.sqrt(dx * dx + dy * dy) || 1;
          const f = (d - 78) * 0.02;
          na.x += (dx / d) * f;
          na.y += (dy / d) * f;
          nb.x -= (dx / d) * f;
          nb.y -= (dy / d) * f;
        }
      }
    }
    return { nodes, edges: built.edges };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [built, mode]);

  function isHidden(n: GNode): boolean {
    const f = filterRef.current;
    if (!f) return false;
    if (n.kind === "tag") return n.tag !== f;
    return !(n.post!.tags.includes(f));
  }

  function draw() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const { w, h } = sizeRef.current;
    const v = viewRef.current;
    const nodes = nodesRef.current;
    const edges = edgesRef.current;
    const sel = selectedRef.current;
    const neigh = sel ? (neighRef.current.get(sel) ?? new Set<string>()) : null;

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#121212";
    ctx.fillRect(0, 0, w, h);
    // Dotted background grid.
    ctx.fillStyle = "rgba(255,255,255,0.06)";
    const gap = 26;
    const ox = w / 2 + v.x;
    const oy = h / 2 + v.y;
    const startX = Math.floor((0 - ox) / gap) * gap;
    const startY = Math.floor((0 - oy) / gap) * gap;
    for (let gx = startX; gx < w - ox + w; gx += gap) {
      for (let gy = startY; gy < h - oy + h; gy += gap) {
        const sx = ox + gx;
        const sy = oy + gy;
        if (sx < 0 || sy < 0 || sx > w || sy > h) continue;
        ctx.fillRect(sx, sy, 1.4, 1.4);
      }
    }

    const cx = w / 2 + v.x;
    const cy = h / 2 + v.y;
    const z = v.z;

    // Timeline axis: old → new.
    if (modeRef.current === "timeline" && metaRef.current.maxT > metaRef.current.minT) {
      ctx.strokeStyle = "rgba(255,255,255,0.10)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(10, cy);
      ctx.lineTo(w - 10, cy);
      ctx.stroke();
      ctx.lineWidth = 1;
      ctx.fillStyle = "rgba(160,160,160,0.9)";
      ctx.font = "600 10px Inter, system-ui, sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(fmtMonth(metaRef.current.minT), 12, h - 10);
      ctx.textAlign = "right";
      ctx.fillText(fmtMonth(metaRef.current.maxT), w - 12, h - 10);
    }

    const nodeByIdx = nodes;
    for (const e of edges) {
      const a = nodeByIdx[e.a];
      const b = nodeByIdx[e.b];
      if (!a || !b || isHidden(a) || isHidden(b)) continue;
      const touchesSel =
        sel && (a.key === sel || b.key === sel);
      if (sel && !touchesSel) {
        ctx.strokeStyle = "rgba(165,180,252,0.07)";
        ctx.lineWidth = 1;
      } else if (touchesSel) {
        ctx.strokeStyle = "rgba(165,180,252,0.85)";
        ctx.lineWidth = 1.8;
      } else {
        ctx.strokeStyle = "rgba(165,180,252,0.28)";
        ctx.lineWidth = 1;
      }
      ctx.beginPath();
      ctx.moveTo(cx + a.x * z, cy + a.y * z);
      ctx.lineTo(cx + b.x * z, cy + b.y * z);
      ctx.stroke();
    }
    ctx.lineWidth = 1;

    for (const n of nodes) {
      if (isHidden(n)) continue;
      const sx = cx + n.x * z;
      const sy = cy + n.y * z;
      if (sx < -60 || sy < -60 || sx > w + 60 || sy > h + 60) continue;
      const focused = !sel || sel === n.key || (neigh?.has(n.key) ?? false);
      ctx.globalAlpha = focused ? 1 : 0.2;
      const r = Math.max(2, n.r * (n.kind === "tag" ? Math.sqrt(z) : z));
      const isSel = sel === n.key;

      if (n.kind === "tag") {
        // Soft glow + gradient disc + section letter.
        const glow = ctx.createRadialGradient(sx, sy, 1, sx, sy, r * 1.9);
        glow.addColorStop(0, n.color + "66");
        glow.addColorStop(1, n.color + "00");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(sx, sy, r * 1.9, 0, Math.PI * 2);
        ctx.fill();
        const g = ctx.createRadialGradient(sx - r * 0.3, sy - r * 0.3, 1, sx, sy, r);
        g.addColorStop(0, n.color);
        g.addColorStop(1, n.color + "88");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(sx, sy, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.95)";
        ctx.font = "bold " + Math.max(10, Math.round(r * 0.62)) + "px Inter, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText((n.tag ?? "#").slice(0, 1).toUpperCase(), sx, sy + 1);
        ctx.textBaseline = "alphabetic";
        // Label pill under the disc.
        const label = (n.tag ?? "").slice(0, 16);
        ctx.font = "600 11px Inter, system-ui, sans-serif";
        const tw = ctx.measureText(label).width;
        const pw = tw + 14;
        const ph = 18;
        pill(ctx, sx - pw / 2, sy + r + 5, pw, ph, 9);
        ctx.fillStyle = "rgba(10,10,12,0.78)";
        ctx.fill();
        ctx.strokeStyle = n.color + "88";
        ctx.stroke();
        ctx.fillStyle = "#F5F5F5";
        ctx.textAlign = "center";
        ctx.fillText(label, sx, sy + r + 5 + 13);
        if (isSel) {
          ctx.strokeStyle = "#fff";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(sx, sy, r + 5, 0, Math.PI * 2);
          ctx.stroke();
          ctx.lineWidth = 1;
        }
      } else {
        ctx.fillStyle = n.color;
        ctx.beginPath();
        ctx.arc(sx, sy, Math.max(3, r * 0.85), 0, Math.PI * 2);
        ctx.fill();
        // Media posts get a gold ring; updated ("alive") posts a dashed halo.
        if (n.post && hasPhoto(n.post)) {
          ctx.strokeStyle = "rgba(201,168,106,0.95)";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(sx, sy, Math.max(3, r * 0.85) + 3, 0, Math.PI * 2);
          ctx.stroke();
          ctx.lineWidth = 1;
        }
        if ((n.post?.updateCount ?? 0) > 0) {
          ctx.strokeStyle = "rgba(255,255,255,0.55)";
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          ctx.arc(sx, sy, Math.max(3, r * 0.85) + (n.post && hasPhoto(n.post) ? 6 : 3), 0, Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);
        }
        if (isSel) {
          ctx.strokeStyle = "#fff";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(sx, sy, Math.max(3, r * 0.85) + 8, 0, Math.PI * 2);
          ctx.stroke();
          ctx.lineWidth = 1;
        }
        // Excerpt pill for focused posts (selected, neighbours, or zoomed).
        if (focused && (isSel || (neigh?.has(n.key) ?? false) || z > 1.35)) {
          const short =
            n.label.length > 26 ? n.label.slice(0, 26) + "…" : n.label;
          ctx.font = "500 10.5px Inter, system-ui, sans-serif";
          const tw = ctx.measureText(short).width;
          const pw = Math.min(tw + 14, w - 16);
          const ph = 18;
          const px = Math.min(Math.max(sx - pw / 2, 8), w - pw - 8);
          pill(ctx, px, sy - r - 26, pw, ph, 9);
          ctx.fillStyle = "rgba(10,10,12,0.82)";
          ctx.fill();
          ctx.fillStyle = "#F5F5F5";
          ctx.textAlign = "center";
          const fit =
            short.length > 30 ? short.slice(0, 30) + "…" : short;
          ctx.fillText(fit, px + pw / 2, sy - r - 26 + 13);
        }
      }
      ctx.globalAlpha = 1;
    }
  }

  const drawRef = useRef(draw);
  drawRef.current = draw;
  function requestDraw() {
    drawRef.current();
  }

  function kick() {
    if (modeRef.current === "timeline") {
      requestDraw();
      return;
    }
    if (!simRef.current) {
      simRef.current = 1;
      requestAnimationFrame(step);
    } else {
      requestDraw();
    }
  }
  const kickRef = useRef(kick);
  kickRef.current = kick;

  function step() {
    const nodes = nodesRef.current;
    const edges = edgesRef.current;
    const kRep = 2600;
    for (let a = 0; a < nodes.length; a++) {
      const na = nodes[a];
      if (isHidden(na)) continue;
      for (let b = a + 1; b < nodes.length; b++) {
        const nb = nodes[b];
        if (isHidden(nb)) continue;
        let dx = na.x - nb.x;
        let dy = na.y - nb.y;
        let d2 = dx * dx + dy * dy;
        if (d2 < 1) {
          dx = (Math.random() - 0.5) * 2;
          dy = (Math.random() - 0.5) * 2;
          d2 = dx * dx + dy * dy + 1;
        }
        if (d2 > 90000) continue;
        const d = Math.sqrt(d2);
        const f = Math.min(2.2, kRep / d2);
        const ux = dx / d;
        const uy = dy / d;
        na.vx += ux * f * 0.5;
        na.vy += uy * f * 0.5;
        nb.vx -= ux * f * 0.5;
        nb.vy -= uy * f * 0.5;
      }
    }
    for (const e of edges) {
      const na = nodes[e.a];
      const nb = nodes[e.b];
      if (!na || !nb || isHidden(na) || isHidden(nb)) continue;
      const dx = nb.x - na.x;
      const dy = nb.y - na.y;
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      const rest = 64;
      const f = (d - rest) * 0.012;
      const ux = dx / d;
      const uy = dy / d;
      na.vx += ux * f;
      na.vy += uy * f;
      nb.vx -= ux * f;
      nb.vy -= uy * f;
    }
    let eSum = 0;
    for (const n of nodes) {
      if (isHidden(n)) continue;
      n.vx += -n.x * 0.004;
      n.vy += -n.y * 0.004;
      n.vx *= 0.86;
      n.vy *= 0.86;
      n.x += n.vx;
      n.y += n.vy;
      eSum += Math.abs(n.vx) + Math.abs(n.vy);
    }
    energyRef.current = eSum;
    requestDraw();
    if (eSum > 0.35 || dragRef.current) {
      requestAnimationFrame(step);
    } else {
      simRef.current = 0;
    }
  }

  // Load freshly laid-out nodes; preserve a still-valid selection.
  useEffect(() => {
    nodesRef.current = layout.nodes.map((n) => ({ ...n }));
    edgesRef.current = layout.edges;
    metaRef.current = { minT: built.minT, maxT: built.maxT };
    const m = new Map<string, Set<string>>();
    for (const n of layout.nodes) m.set(n.key, new Set());
    const byIdx = layout.nodes;
    for (const e of layout.edges) {
      const a = byIdx[e.a]?.key;
      const b = byIdx[e.b]?.key;
      if (!a || !b) continue;
      m.get(a)?.add(b);
      m.get(b)?.add(a);
    }
    neighRef.current = m;
    const stillThere =
      selectedRef.current && m.has(selectedRef.current)
        ? selectedRef.current
        : null;
    selectedRef.current = stillThere;
    setSelected(stillThere);
    kickRef.current();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [layout]);

  // Canvas setup: sizing + pan/zoom/drag/tap gestures. Mounted once.
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;

    function resize() {
      const rect = wrap!.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = Math.max(200, rect.width);
      const h = 420;
      sizeRef.current = { w, h };
      canvas!.width = Math.round(w * dpr);
      canvas!.height = Math.round(h * dpr);
      canvas!.style.width = w + "px";
      canvas!.style.height = h + "px";
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      requestDraw();
    }
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    const kickTimer = window.setInterval(() => {
      if (
        modeRef.current === "force" &&
        energyRef.current > 0.35 &&
        !simRef.current
      ) {
        kickRef.current();
      }
    }, 1200);

    function requestDraw() {
      drawRef.current();
    }

    function toWorld(sx: number, sy: number) {
      const rect = canvas!.getBoundingClientRect();
      const v = viewRef.current;
      return {
        x: (sx - rect.left - rect.width / 2 - v.x) / v.z,
        y: (sy - rect.top - rect.height / 2 - v.y) / v.z
      };
    }

    function hitNode(wx: number, wy: number): number {
      const nodes = nodesRef.current;
      const v = viewRef.current;
      let best = -1;
      let bestD = 1e9;
      for (let idx = 0; idx < nodes.length; idx++) {
        const n = nodes[idx];
        if (isHidden(n)) continue;
        const dx = n.x - wx;
        const dy = n.y - wy;
        const d = Math.sqrt(dx * dx + dy * dy);
        const tol = n.r / Math.max(0.5, v.z) + 10;
        if (d <= tol && d < bestD) {
          best = idx;
          bestD = d;
        }
      }
      return best;
    }

    function isHidden(n: GNode): boolean {
      const f = filterRef.current;
      if (!f) return false;
      if (n.kind === "tag") return n.tag !== f;
      return !(n.post!.tags.includes(f));
    }

    function onPointerDown(e: PointerEvent) {
      try {
        (e.target as Element).setPointerCapture?.(e.pointerId);
      } catch {
        // Synthetic/dispatched pointer events have no active pointer.
      }
      pinchRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pinchRef.current.size === 2) {
        const pts = [...pinchRef.current.values()];
        pinchDistRef.current = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        dragRef.current = null;
        return;
      }
      const wpt = toWorld(e.clientX, e.clientY);
      const hit = hitNode(wpt.x, wpt.y);
      dragRef.current = {
        pointerId: e.pointerId,
        mode: hit >= 0 ? "node" : "pan",
        nodeIdx: hit,
        startX: e.clientX,
        startY: e.clientY,
        moved: false,
        viewX: viewRef.current.x,
        viewY: viewRef.current.y
      };
    }

    function onPointerMove(e: PointerEvent) {
      if (pinchRef.current.has(e.pointerId)) {
        pinchRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
      }
      if (pinchRef.current.size === 2) {
        const pts = [...pinchRef.current.values()];
        const d = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        const prev = pinchDistRef.current || d;
        if (prev > 0) {
          const v = viewRef.current;
          viewRef.current = {
            ...v,
            z: Math.min(2.5, Math.max(0.35, v.z * (d / prev)))
          };
          kickRef.current();
        }
        pinchDistRef.current = d;
        return;
      }
      const dr = dragRef.current;
      if (!dr || e.pointerId !== dr.pointerId) return;
      const dx = e.clientX - dr.startX;
      const dy = e.clientY - dr.startY;
      if (Math.abs(dx) + Math.abs(dy) > 6) dr.moved = true;
      if (dr.mode === "pan") {
        viewRef.current = {
          ...viewRef.current,
          x: dr.viewX + dx,
          y: dr.viewY + dy
        };
        kickRef.current();
      } else if (dr.nodeIdx >= 0) {
        const wpt = toWorld(e.clientX, e.clientY);
        const n = nodesRef.current[dr.nodeIdx];
        if (n) {
          n.x = wpt.x;
          n.y = wpt.y;
          n.vx = 0;
          n.vy = 0;
          kickRef.current();
        }
      }
    }

    function onPointerUp(e: PointerEvent) {
      pinchRef.current.delete(e.pointerId);
      const dr = dragRef.current;
      if (dr && e.pointerId === dr.pointerId) {
        if (!dr.moved) {
          if (dr.mode === "node" && dr.nodeIdx >= 0) {
            const n = nodesRef.current[dr.nodeIdx];
            if (n) {
              const next = selectedRef.current === n.key ? null : n.key;
              selectedRef.current = next;
              setSelected(next);
            }
          } else {
            selectedRef.current = null;
            setSelected(null);
          }
          kickRef.current();
        }
        dragRef.current = null;
        kickRef.current();
      }
    }

    function onWheel(e: WheelEvent) {
      e.preventDefault();
      const rect = canvas!.getBoundingClientRect();
      const v = viewRef.current;
      const nz = Math.min(2.5, Math.max(0.35, v.z * (e.deltaY < 0 ? 1.12 : 0.89)));
      // Zoom toward the cursor so exploration feels anchored.
      const mx = e.clientX - rect.left - rect.width / 2;
      const my = e.clientY - rect.top - rect.height / 2;
      const wx = (mx - v.x) / v.z;
      const wy = (my - v.y) / v.z;
      viewRef.current = { x: mx - wx * nz, y: my - wy * nz, z: nz };
      kickRef.current();
    }

    canvas.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    window.addEventListener("pointercancel", onPointerUp);
    canvas.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(kickTimer);
      simRef.current = 0;
      ro.disconnect();
      canvas.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
      canvas.removeEventListener("wheel", onWheel);
    };
    // Re-runs once the live query resolves: the first paint renders only
    // the skeleton (no canvas yet), so a mount-only effect would see null
    // refs and never size the canvas.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [posts === undefined]);

  function zoom(f: number) {
    const v = viewRef.current;
    viewRef.current = {
      ...v,
      z: Math.min(2.5, Math.max(0.35, v.z * f))
    };
    kick();
  }

  function fitView() {
    const visible = nodesRef.current.filter((n) => !isHidden(n));
    const list = visible.length > 0 ? visible : nodesRef.current;
    if (list.length === 0) return;
    let minX = 1e9;
    let maxX = -1e9;
    let minY = 1e9;
    let maxY = -1e9;
    for (const n of list) {
      if (n.x < minX) minX = n.x;
      if (n.x > maxX) maxX = n.x;
      if (n.y < minY) minY = n.y;
      if (n.y > maxY) maxY = n.y;
    }
    const { w, h } = sizeRef.current;
    const bw = Math.max(120, maxX - minX + 140);
    const bh = Math.max(120, maxY - minY + 140);
    const z = Math.min(2.2, Math.max(0.35, Math.min(w / bw, h / bh)));
    viewRef.current = {
      x: (-(minX + maxX) / 2) * z,
      y: (-(minY + maxY) / 2) * z,
      z
    };
    kick();
  }

  function reshuffle() {
    selectedRef.current = null;
    setSelected(null);
    viewRef.current = { x: 0, y: 0, z: 1 };
    setLayoutSeed((s) => s + 1);
  }

  if (posts === undefined) {
    return <div className="h-[420px] animate-pulse rounded-2xl bg-card" />;
  }

  const all = posts ?? [];
  const selNode = nodesRef.current.find((n) => n.key === selected) ?? null;
  const selPostsForTag = selNode?.kind === "tag"
    ? all.filter((p) => p.tags.includes(selNode.tag ?? "")).slice(0, 3)
    : [];
  const visiblePosts = filterTag
    ? all.filter((p) => p.tags.includes(filterTag)).length
    : all.length;

  return (
    <div>
      <p className="mb-2 text-xs text-mist">
        {built.postCount} {built.postCount === 1 ? "post" : "posts"} ·{" "}
        {built.tagCount} {built.tagCount === 1 ? "section" : "sections"}
        {filterTag ? " · showing " + visiblePosts + " in #" + filterTag : " · drag to explore"}
      </p>

      <div className="mb-2 flex items-center gap-2">
        <div className="grid flex-1 grid-cols-2 gap-1 rounded-full bg-card p-1">
          <button
            onClick={() => setMode("force")}
            className={
              "flex items-center justify-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition " +
              (mode === "force" ? "bg-solo text-white" : "text-mist")
            }
          >
            <Network size={13} />
            Force
          </button>
          <button
            onClick={() => setMode("timeline")}
            className={
              "flex items-center justify-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition " +
              (mode === "timeline" ? "bg-solo text-white" : "text-mist")
            }
          >
            <Clock3 size={13} />
            Timeline
          </button>
        </div>
        <button
          onClick={fitView}
          aria-label="Fit graph to view"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-card text-cream active:scale-95"
        >
          <Maximize size={16} />
        </button>
        <button
          onClick={reshuffle}
          aria-label="Reshuffle graph layout"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-card text-cream active:scale-95"
        >
          <RotateCcw size={16} />
        </button>
      </div>

      {built.tags.length > 0 && (
        <div className="no-scrollbar -mx-4 mb-2 flex gap-1.5 overflow-x-auto overflow-y-hidden px-4 pb-1">
          <button
            onClick={() => setFilterTag(null)}
            className={
              "shrink-0 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-bold transition " +
              (filterTag === null ? "bg-cream text-void" : "bg-card text-mist")
            }
          >
            All
          </button>
          {built.tags.slice(0, 8).map((t) => (
            <button
              key={t}
              onClick={() => setFilterTag((f) => (f === t ? null : t))}
              className={
                "shrink-0 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-bold transition " +
                (filterTag === t ? "text-white" : "bg-card text-mist")
              }
              style={filterTag === t ? { backgroundColor: sectionColor(t) } : undefined}
            >
              #{t}
            </button>
          ))}
        </div>
      )}

      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-void">
        <div ref={wrapRef}>
          <canvas
            ref={canvasRef}
            style={{ touchAction: "none", display: "block", width: "100%" }}
          />
        </div>
        <div className="absolute right-2 top-2 flex flex-col gap-1.5">
          <button
            onClick={() => zoom(1.2)}
            aria-label="Zoom in"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-card/90 text-cream active:scale-95"
          >
            <ZoomIn size={17} />
          </button>
          <button
            onClick={() => zoom(0.85)}
            aria-label="Zoom out"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-card/90 text-cream active:scale-95"
          >
            <ZoomOut size={17} />
          </button>
        </div>
        {all.length === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 p-6 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-solo/15 text-solosoft">
              <Network size={22} />
            </span>
            <p className="text-sm font-semibold text-cream">
              Your graph grows with you
            </p>
            <p className="max-w-xs text-xs leading-relaxed text-mist">
              Capture posts with #tags and watch sections and memories connect
              here.
            </p>
          </div>
        )}
        {selNode && (
          <div className="absolute inset-x-2 bottom-2 rounded-2xl border border-white/10 bg-card/95 p-3 backdrop-blur">
            {selNode.kind === "post" && selNode.post ? (
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/5 text-mist">
                  <FileText size={17} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold text-cream">
                    {excerptOf(selNode.post)}
                  </span>
                  <span className="block text-xs text-mist">
                    {selNode.post.updateCount}{" "}
                    {selNode.post.updateCount === 1 ? "update" : "updates"} ·{" "}
                    {timeAgo(selNode.post.updatedAt)}
                  </span>
                </span>
                <button
                  onClick={() => onOpen(selNode.post!.id)}
                  className="shrink-0 whitespace-nowrap rounded-full bg-solo px-4 py-2 text-xs font-bold text-white active:scale-95"
                >
                  Open
                </button>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-2.5">
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-sm font-bold"
                    style={{
                      backgroundColor: (selNode.color ?? "#4F46E5") + "22",
                      color: selNode.color
                    }}
                  >
                    <Hash size={16} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold text-cream">
                      #{selNode.tag}
                    </span>
                    <span className="block text-xs text-mist">
                      {selNode.count ?? 0}{" "}
                      {(selNode.count ?? 0) === 1 ? "post" : "posts"} in this
                      section
                    </span>
                  </span>
                </div>
                {selPostsForTag.length > 0 && (
                  <div className="mt-2 flex flex-col gap-1.5">
                    {selPostsForTag.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => onOpen(p.id)}
                        className="truncate rounded-xl bg-void/60 px-3 py-2 text-left text-xs text-cream active:scale-[0.99]"
                      >
                        {excerptOf(p)}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-mist">
        <span className="flex items-center gap-1">
          <span className="h-2.5 w-2.5 rounded-full bg-solo" /> section
        </span>
        <span className="flex items-center gap-1">
          <span className="h-2 w-2 rounded-full bg-[#6d6d75]" /> post
        </span>
        <span className="flex items-center gap-1">
          <span className="h-2 w-2 rounded-full border border-gold bg-transparent" />{" "}
          photo
        </span>
        <span className="flex items-center gap-1">
          <span className="h-2 w-2 rounded-full border border-dashed border-white/70 bg-transparent" />{" "}
          alive
        </span>
      </div>
    </div>
  );
}
