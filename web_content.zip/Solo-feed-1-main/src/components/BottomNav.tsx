import { Layers, Newspaper, Settings as SettingsIcon, Sparkles } from "lucide-react";
import type { Tab } from "../App";

interface Props {
  tab: Tab;
  onTab: (t: Tab) => void;
  onSettings: () => void;
  settingsActive: boolean;
}

export function BottomNav({ tab, onTab, onSettings, settingsActive }: Props) {
  const item = (active: boolean) =>
    "flex flex-1 flex-col items-center gap-1 py-1 text-[11px] font-bold transition active:scale-95 " +
    (active ? "text-solosoft" : "text-mist");

  const studioActive = tab === "studio";

  return (
    <nav
      aria-label="Primary"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-card"
    >
      <div className="mx-auto grid max-w-xl grid-cols-4 items-center px-4 pb-[max(0.6rem,env(safe-area-inset-bottom))] pt-2">
        <button onClick={() => onTab("feed")} className={item(tab === "feed")}>
          <Newspaper size={22} />
          Feed
        </button>
        <button onClick={() => onTab("insights")} className={item(tab === "insights")}>
          <Sparkles size={22} />
          Insights
        </button>
        <button onClick={() => onTab("studio")} className={item(studioActive)}>
          <Layers size={22} />
          Studio
        </button>
        <button onClick={onSettings} className={item(settingsActive)}>
          <SettingsIcon size={22} />
          Settings
        </button>
      </div>
    </nav>
  );
}
