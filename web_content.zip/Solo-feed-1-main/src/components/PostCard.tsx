import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue } from "framer-motion";
import {
  BadgeCheck,
  Bookmark,
  Check,
  Heart,
  MessageCircle,
  MoreHorizontal,
  Pencil,
  Send
} from "lucide-react";
import { setPostStatus, updatePostContent, getSlides, type Post } from "../db/db";
import { Carousel } from "./Carousel";
import { TagSuggest } from "./TagSuggest";
import { fullDate, timeAgo } from "../lib/time";

interface Props {
  post: Post;
  onOpen: () => void;
}

function loadLiked(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem("sf-liked");
    return raw ? (JSON.parse(raw) as Record<string, boolean>) : {};
  } catch {
    return {};
  }
}

export function PostCard({ post, onOpen }: Props) {
  const x = useMotionValue(0);
  const suppressClick = useRef(false);
  const menuRef = useRef<HTMLSpanElement>(null);
  const [imgUrl, setImgUrl] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [liked, setLiked] = useState(() => !!loadLiked()[post.id]);
  const [burst, setBurst] = useState(false);
  const [shareMsg, setShareMsg] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [editDraft, setEditDraft] = useState("");
  const [saving, setSaving] = useState(false);
  const [undoArmed, setUndoArmed] = useState(false);
  const undoTimer = useRef<number | null>(null);

  useEffect(() => {
    if (!post.mediaBlob) {
      setImgUrl(null);
      return;
    }
    const url = URL.createObjectURL(post.mediaBlob);
    setImgUrl(url);
    return () => {
      URL.revokeObjectURL(url);
    };
  }, [post.mediaBlob]);

  // Swipe-to-archive commits after a short undo window. If the card
  // unmounts while undo is still armed (e.g. the user navigates away),
  // the archive commits on the way out — the swipe was intentional.
  useEffect(() => {
    return () => {
      if (undoTimer.current) {
        window.clearTimeout(undoTimer.current);
        undoTimer.current = null;
        void setPostStatus(post.id, "archived");
      }
    };
  }, [post.id]);
  // The ⋯ menu closes on any outside tap. A window listener is used instead
  // of a fixed full-screen backdrop because this card lives inside a
  // transformed (drag/layout-animated) ancestor, which would trap a `fixed`
  // backdrop to the card's own box so outside taps never reached it.
  useEffect(() => {
    if (!menuOpen) return;
    const close = (e: PointerEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false);
    };
    window.addEventListener("pointerdown", close);
    return () => window.removeEventListener("pointerdown", close);
  }, [menuOpen]);

  const stamp = timeAgo(post.updatedAt);
  const fresh = Date.now() - post.updatedAt < 48 * 3600 * 1000;

  function persistLiked(next: boolean) {
    setLiked(next);
    try {
      const map = loadLiked();
      if (next) map[post.id] = true;
      else delete map[post.id];
      localStorage.setItem("sf-liked", JSON.stringify(map));
    } catch {
      // private likes are best-effort
    }
  }

  function armUndoArchive() {
    if (undoArmed) return;
    x.set(0);
    setUndoArmed(true);
    if (undoTimer.current) window.clearTimeout(undoTimer.current);
    undoTimer.current = window.setTimeout(() => {
      undoTimer.current = null;
      setUndoArmed(false);
      void setPostStatus(post.id, "archived");
    }, 6000);
  }

  function cancelUndoArchive() {
    if (undoTimer.current) {
      window.clearTimeout(undoTimer.current);
      undoTimer.current = null;
    }
    setUndoArmed(false);
    x.set(0);
  }

  function doubleTapLike() {    if (!liked) persistLiked(true);
    setBurst(false);
    requestAnimationFrame(() => requestAnimationFrame(() => setBurst(true)));
    window.setTimeout(() => setBurst(false), 900);
  }

  function flashShare(msg: string) {
    setShareMsg(msg);
    window.setTimeout(() => setShareMsg((v) => (v === msg ? null : v)), 2400);
  }

  async function share() {
    const text = post.content || "A memory from my Solo Feed";
    // 1. Native share sheet (phones, real user gesture).
    try {
      const nav = navigator as Navigator & { share?: (d: { text: string }) => Promise<void> };
      if (typeof nav.share === "function") {
        await nav.share({ text });
        return;
      }
      throw new Error("no-share");
    } catch {
      // fall through to copy fallbacks below
    }
    // 2. Modern clipboard API.
    try {
      await navigator.clipboard.writeText(text);
      flashShare("Copied to clipboard");
      return;
    } catch {
      // fall through to the legacy path
    }
    // 3. Legacy textarea copy for older webviews / blocked permissions.
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      flashShare(ok ? "Copied to clipboard" : "Couldn't copy on this device");
    } catch {
      flashShare("Couldn't copy on this device");
    }
  }

  async function saveEdit() {
    const t = editDraft.trim();
    if (!t || saving) return;
    setSaving(true);
    try {
      await updatePostContent(post.id, t);
      setEditing(false);
    } finally {
      setSaving(false);
    }
  }

  const actionBtn =
    "flex h-10 w-10 items-center justify-center rounded-full text-cream transition active:scale-90";

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ x: 320, opacity: 0, transition: { duration: 0.28 } }}
      transition={{ duration: 0.3 }}
      className="relative overflow-hidden"
    >
      <motion.article
        drag={editing ? false : "x"}
        style={{ x }}
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.55}
        onDragStart={() => {
          suppressClick.current = true;
        }}
        onDragEnd={(_e, info) => {
          if (info.offset.x > 110 || info.velocity.x > 650) {
            armUndoArchive();
          }
          window.setTimeout(() => {
            suppressClick.current = false;
          }, 80);
        }}
        whileTap={{ cursor: "grabbing" }}
        className="relative bg-void text-left"
      >
        {undoArmed ? (
          <div className="flex items-center gap-3 px-4 py-5">
            <span className="min-w-0 flex-1 truncate text-sm text-mist">
              Archiving this post…
            </span>
            <button
              onClick={cancelUndoArchive}
              className="shrink-0 whitespace-nowrap rounded-full bg-gold/15 px-4 py-2 text-xs font-bold text-gold active:scale-95"
            >
              Undo
            </button>
          </div>
        ) : (
          <>
        <div className="flex items-center gap-3 px-4 py-3">
          <button
            onClick={() => {
              if (!suppressClick.current) onOpen();
            }}
            aria-label="Open post"
            className="shrink-0 active:scale-95"
          >
            <span
              className={
                "block rounded-full p-[2.5px] " + (imgUrl && fresh ? "ig-ring" : "ig-ring-seen")
              }
            >
              <span className="block overflow-hidden rounded-full border-2 border-void">
                {imgUrl ? (
                  <img src={imgUrl} alt="" aria-hidden className="h-9 w-9 object-cover" />
                ) : (
                  <span className="ig-wordmark flex h-9 w-9 items-center justify-center bg-card text-[22px]">
                    S
                  </span>
                )}
              </span>
            </span>
          </button>
          <button
            onClick={() => {
              if (!suppressClick.current) onOpen();
            }}
            className="min-w-0 flex-1 text-left"
          >
            <span className="flex items-center gap-1 text-sm font-semibold text-cream">
              you
              <BadgeCheck size={14} className="shrink-0 text-solosoft" />
              <span className="truncate font-normal text-mist">· {stamp}</span>
            </span>
            <span className="block truncate text-xs text-mist">
              {post.updateCount > 0
                ? post.updateCount + (post.updateCount === 1 ? " update" : " updates")
                : "Original entry"}
            </span>
          </button>
          <span ref={menuRef} className="relative shrink-0">
            <button
              onClick={() => setMenuOpen((v) => !v)}
              aria-label="Post options"
              aria-expanded={menuOpen}
              className="flex h-9 w-9 items-center justify-center rounded-full text-cream active:scale-90"
            >
              <MoreHorizontal size={20} />
            </button>
            {menuOpen && (
                <span className="absolute right-0 top-10 z-20 w-40 overflow-hidden rounded-xl border border-white/10 bg-card shadow-[0_12px_32px_rgba(0,0,0,0.5)]">
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onOpen();
                    }}
                    className="block w-full px-4 py-2.5 text-left text-sm text-cream active:bg-white/5"
                  >
                    Open
                  </button>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setEditDraft(post.content);
                      setEditing(true);
                    }}
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm font-semibold text-cream active:bg-white/5"
                  >
                    <Pencil size={15} />
                    Edit
                  </button>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      void setPostStatus(post.id, "archived");
                    }}
                    className="block w-full px-4 py-2.5 text-left text-sm text-clay active:bg-white/5"
                  >
                    Archive
                  </button>
                </span>
            )}
          </span>
        </div>

        <Carousel
          mainUrl={imgUrl}
          slides={getSlides(post)}
          burst={burst}
          onDoubleTap={doubleTapLike}
        />

        <div className="px-4 pb-1 pt-3">
          {post.updateCount > 0 && (
            <button onClick={onOpen} className="mb-1 block text-sm font-semibold text-cream">
              {post.updateCount} {post.updateCount === 1 ? "update" : "updates"}
            </button>
          )}
          {editing ? (
            <div className="rounded-2xl border border-solo/30 bg-card p-3">
              <textarea
                value={editDraft}
                onChange={(e) => setEditDraft(e.target.value)}
                rows={4}
                autoFocus
                aria-label="Edit post text"
                className="w-full resize-y rounded-xl border border-white/10 bg-void p-3 text-[14px] leading-relaxed text-cream focus:border-solo focus:outline-none"
              />
              <TagSuggest text={editDraft} onInsert={setEditDraft} />
              <div className="mt-2 flex items-center justify-end gap-2">
                <button
                  onClick={() => setEditing(false)}
                  className="rounded-full bg-white/5 px-4 py-2 text-xs font-bold text-mist active:scale-95"
                >
                  Cancel
                </button>
                <button
                  onClick={() => void saveEdit()}
                  disabled={editDraft.trim().length === 0 || saving}
                  className="rounded-full bg-solo px-4 py-2 text-xs font-bold text-white active:scale-95 disabled:opacity-40"
                >
                  {saving ? "Saving…" : "Save"}
                </button>
              </div>
            </div>
          ) : (
          <button onClick={onOpen} className="block w-full text-left">
            <span className="whitespace-pre-wrap text-[14px] leading-relaxed text-cream">
              <span className="font-semibold">you </span>
              {post.content}
            </span>
          </button>
          )}
          <p className="mt-1.5 text-[11px] uppercase tracking-wide text-mist">
            {stamp} · {fullDate(post.updatedAt)}
          </p>
        </div>

        <div className="flex items-center gap-0.5 px-2 pb-3 pt-1">
          <button onClick={() => persistLiked(!liked)} aria-label="Like privately" className={actionBtn}>
            <Heart
              size={25}
              strokeWidth={1.8}
              fill={liked ? "#E07A5F" : "none"}
              className={liked ? "text-clay" : undefined}
            />
          </button>
          <button onClick={onOpen} aria-label="Open updates" className={actionBtn}>
            <MessageCircle size={25} strokeWidth={1.8} />
          </button>
          <button onClick={() => void share()} aria-label="Share post text" className={actionBtn}>
            {shareMsg === "Copied to clipboard" ? <Check size={25} strokeWidth={2} className="text-solosoft" /> : <Send size={25} strokeWidth={1.8} />}
          </button>
          <span className="flex-1" />
          <button
            onClick={() => void setPostStatus(post.id, "archived")}
            aria-label="Archive post"
            className={actionBtn}
          >
            <Bookmark size={25} strokeWidth={1.8} />
          </button>
        </div>
        {shareMsg && <p className="px-4 pb-4 text-xs font-semibold text-solosoft">{shareMsg}</p>}
          </>
        )}
      </motion.article>
    </motion.div>
  );
}
