import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Archive,
  ChevronLeft,
  Loader2,
  Pencil,
  RotateCcw,
  Send,
  Sparkles,
  Trash2
} from "lucide-react";
import { addUpdate, db, deletePost, getSlides, setPostStatus, updatePostFull } from "../db/db";
import { Carousel } from "./Carousel";
import { SlideEditor, compressPhoto, newDraftSlide, type DraftSlide } from "./SlideEditor";
import { TagSuggest } from "./TagSuggest";
import { useLiveQuery } from "../hooks";
import { fullDate } from "../lib/time";

interface Props {
  postId: string;
  onBack: () => void;
  onAskAi: (postId: string, excerpt: string) => void;
}

export function PostDetail({ postId, onBack, onAskAi }: Props) {
  const post = useLiveQuery(() => db.posts.get(postId), [postId]);
  const updates = useLiveQuery(
    () => db.updates.where("postId").equals(postId).sortBy("createdAt"),
    [postId]
  );
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [imgUrl, setImgUrl] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [editDraft, setEditDraft] = useState("");
  const [editSlides, setEditSlides] = useState<DraftSlide[]>([]);
  const [editSaving, setEditSaving] = useState(false);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  useEffect(() => {
    if (!post?.mediaBlob) {
      setImgUrl(null);
      return;
    }
    const url = URL.createObjectURL(post.mediaBlob);
    setImgUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [post?.mediaBlob]);

  useEffect(() => {
    if (!confirmDelete) return;
    const t = window.setTimeout(() => setConfirmDelete(false), 3200);
    return () => window.clearTimeout(t);
  }, [confirmDelete]);

  async function send() {
    const t = draft.trim();
    if (!t || sending) return;
    setSending(true);
    try {
      await addUpdate(postId, t);
      setDraft("");
    } finally {
      setSending(false);
    }
  }

  async function saveEdit() {
    const t = editDraft.trim();
    if (!t || editSaving) return;
    setEditSaving(true);
    try {
      const slides = [];
      for (const d of editSlides) {
        const b = d.file ? await compressPhoto(d.file) : d.keep;
        const txt = d.text.slice(0, 5000);
        if (!txt.trim() && !b) continue;
        slides.push({ text: txt, mediaBlob: b });
      }
      await updatePostFull(postId, t, slides);
      setEditing(false);
    } finally {
      setEditSaving(false);
    }
  }

  const shell = (inner: React.ReactNode) => (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-50 bg-void"
    >
      <div className="mx-auto flex h-full max-w-xl flex-col">{inner}</div>
    </motion.div>
  );

  if (post === undefined || updates === undefined) {
    return shell(
      <>
        <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
          <div className="h-9 w-9 animate-pulse rounded-full bg-card" />
          <div className="h-5 w-32 animate-pulse rounded bg-card" />
        </div>
        <div className="flex flex-col gap-3 p-4">
          <div className="h-40 animate-pulse rounded-2xl bg-card" />
          <div className="h-20 animate-pulse rounded-2xl bg-card" />
        </div>
      </>
    );
  }

  if (post === null) {
    return shell(
      <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center">
        <p className="font-semibold text-cream">This post is gone.</p>
        <p className="text-sm text-mist">It may have been deleted.</p>
        <button
          onClick={onBack}
          className="mt-1 rounded-full bg-solo px-5 py-2.5 text-sm font-bold text-white"
        >
          Back to feed
        </button>
      </div>
    );
  }

  const archived = post.status === "archived";

  return shell(
    <>
      <div className="flex items-center gap-1 border-b border-white/10 px-2 py-2">
        <button
          onClick={onBack}
          aria-label="Back"
          className="flex h-10 w-10 items-center justify-center rounded-full text-cream active:scale-95"
        >
          <ChevronLeft size={22} />
        </button>
        <span className="text-sm font-bold text-cream">
          {archived ? "Archived memory" : "Living post"}
        </span>
        <span className="flex-1" />
        {archived ? (
          <button
            onClick={() => {
              void setPostStatus(postId, "active").then(onBack);
            }}
            className="mr-1 inline-flex items-center gap-1.5 rounded-full bg-gold/15 px-3.5 py-2 text-xs font-bold text-gold active:scale-95"
          >
            <RotateCcw size={14} />
            Restore
          </button>
        ) : (
          <button
            onClick={() => {
              void setPostStatus(postId, "archived").then(onBack);
            }}
            aria-label="Archive this post"
            className="mr-1 inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3.5 py-2 text-xs font-bold text-mist active:scale-95"
          >
            <Archive size={14} />
            Archive
          </button>
        )}
        <button
          onClick={() => {
            if (confirmDelete) {
              void deletePost(postId).then(onBack);
            } else {
              setConfirmDelete(true);
            }
          }}
          aria-label={confirmDelete ? "Tap again to confirm delete" : "Delete this post"}
          className={
            "mr-2 inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold active:scale-95 " +
            (confirmDelete ? "bg-clay/20 text-clay" : "bg-white/5 text-mist")
          }
        >
          <Trash2 size={14} />
          {confirmDelete ? "Sure?" : "Delete"}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="rounded-2xl border border-white/10 bg-card p-4">
          {editing ? (
            <>
              <textarea
                value={editDraft}
                onChange={(e) => setEditDraft(e.target.value)}
                rows={5}
                autoFocus
                aria-label="Edit post text"
                className="w-full resize-y rounded-xl border border-white/10 bg-void p-3 text-[16px] leading-relaxed text-cream focus:border-solo focus:outline-none"
              />
              <TagSuggest text={editDraft} extraTexts={editSlides.map((d) => d.text)} onInsert={setEditDraft} />
              <SlideEditor value={editSlides} onChange={setEditSlides} />
              <div className="mt-2 flex items-center justify-end gap-2">
                <button
                  onClick={() => setEditing(false)}
                  className="rounded-full bg-white/5 px-4 py-2 text-xs font-bold text-mist active:scale-95"
                >
                  Cancel
                </button>
                <button
                  onClick={() => void saveEdit()}
                  disabled={editDraft.trim().length === 0 || editSaving}
                  className="rounded-full bg-solo px-4 py-2 text-xs font-bold text-white active:scale-95 disabled:opacity-40"
                >
                  {editSaving ? "Saving…" : "Save"}
                </button>
              </div>
            </>
          ) : (
            <>
              <p className="whitespace-pre-wrap text-[16px] leading-relaxed text-cream">
                {post.content}
              </p>
              {!archived && (
                <button
                  onClick={() => {
                    setEditDraft(post.content);
                    setEditSlides(
                      getSlides(post).map((s) => newDraftSlide(s.text, s.mediaBlob))
                    );
                    setEditing(true);
                  }}
                  className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3.5 py-2 text-xs font-bold text-cream active:scale-95"
                >
                  <Pencil size={14} />
                  Edit post
                </button>
              )}
            </>
          )}
          <Carousel
            mainUrl={imgUrl}
            slides={getSlides(post)}
            burst={false}
            onDoubleTap={() => {}}
          />
          <p className="mt-3 text-xs text-mist">Started {fullDate(post.createdAt)}</p>
        </div>

        {!archived && (
          <button
            onClick={() =>
              onAskAi(
                post.id,
                post.content.trim().replace(/\s+/g, " ").slice(0, 36) || "untitled"
              )
            }
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-solo/30 bg-solo/10 py-2.5 text-sm font-bold text-solosoft transition active:scale-[0.99]"
          >
            <Sparkles size={16} />
            Ask AI about this post
          </button>
        )}

        <div className="mb-2 mt-6 flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-clay" />
          <h3 className="text-sm font-bold text-cream">
            Journey · {updates.length} {updates.length === 1 ? "update" : "updates"}
          </h3>
        </div>

        <div className="ml-1 border-l-2 border-white/10 pl-4">
          {updates.length === 0 && (
            <p className="pb-2 text-sm leading-relaxed text-mist">
              No updates yet. When this idea moves, add a note below and watch
              it return to the top of your feed.
            </p>
          )}
          {updates.map((u) => (
            <div key={u.id} className="relative pb-3">
              <span className="absolute -left-[23px] top-3 h-2.5 w-2.5 rounded-full border-2 border-void bg-solo" />
              <div className="rounded-2xl rounded-tl-md border border-white/5 bg-white/[0.04] p-3">
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-cream">
                  {u.content}
                </p>
                <p className="mt-1.5 text-xs text-mist">{fullDate(u.createdAt)}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="h-2" />
      </div>

      {!archived && (
        <div className="border-t border-white/10 bg-void p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          <div className="flex items-center gap-2">
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
              placeholder="Add an update — how did this evolve?"
              aria-label="Add an update"
              className="h-12 flex-1 rounded-full border border-white/10 bg-card px-4 text-[15px] text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none"
            />
            <button
              onClick={() => void send()}
              disabled={draft.trim().length === 0 || sending}
              aria-label="Send update"
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-solo text-white shadow-[0_8px_20px_rgba(79,70,229,0.4)] transition active:scale-95 disabled:opacity-40 disabled:shadow-none"
            >
              {sending ? <Loader2 size={19} className="animate-spin" /> : <Send size={19} />}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
