import { Component, type ReactNode } from "react";
import { db } from "../db/db";

interface Props {
  children: ReactNode;
}

interface State {
  message: string | null;
  exporting: boolean;
  exported: boolean;
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error("read failed"));
    fr.readAsDataURL(blob);
  });
}

/** Standalone backup download — works even when the rest of the UI crashed. */
async function exportBackup(): Promise<void> {
  const [posts, updates, threads, messages, covers, aiCreators, aiPosts] =
    await Promise.all([
      db.posts.toArray(),
      db.updates.toArray(),
      db.threads.toArray(),
      db.messages.toArray(),
      db.sectionCovers.toArray(),
      db.aiCreators.toArray(),
      db.aiPosts.toArray()
    ]);
  const serialisedPosts = await Promise.all(
    posts.map(async (p) => ({
      ...p,
      mediaBlob: p.mediaBlob instanceof Blob ? await blobToDataUrl(p.mediaBlob) : null
    }))
  );
  const serialisedCovers = await Promise.all(
    covers.map(async (c) => ({
      ...c,
      coverBlob: c.coverBlob instanceof Blob ? await blobToDataUrl(c.coverBlob) : null
    }))
  );
  const payload = JSON.stringify({
    app: "solo-feed",
    version: 1,
    exportedAt: Date.now(),
    posts: serialisedPosts,
    updates,
    threads,
    messages,
    sectionCovers: serialisedCovers,
    aiCreators,
    aiPosts
  });
  const url = URL.createObjectURL(new Blob([payload], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "solo-feed-backup-" + new Date().toISOString().slice(0, 10) + ".json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/**
 * Last-resort crash screen. If anything in the tree throws during render,
 * the user gets an Arabic explanation plus recovery actions instead of a
 * blank page. Data stays untouched in IndexedDB.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { message: null, exporting: false, exported: false };

  static getDerivedStateFromError(e: unknown): Partial<State> {
    return { message: e instanceof Error ? e.message : "خطأ غير معروف" };
  }

  componentDidCatch(e: unknown): void {
    console.error("SoloFeed crashed:", e);
  }

  private async handleExport(): Promise<void> {
    if (this.state.exporting) return;
    this.setState({ exporting: true });
    try {
      await exportBackup();
      this.setState({ exported: true });
    } catch (e) {
      console.error("SoloFeed crash-export failed:", e);
    } finally {
      this.setState({ exporting: false });
    }
  }

  render(): ReactNode {
    if (!this.state.message) return this.props.children;
    return (
      <div
        dir="rtl"
        className="flex min-h-screen flex-col items-center gap-3 bg-void px-6 py-16 text-center"
      >
        <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-clay/15 text-[26px]">
          🛟
        </span>
        <h1 className="text-lg font-bold text-cream">حدث خطأ غير متوقع</h1>
        <p className="max-w-sm text-sm leading-relaxed text-mist">
          لا تقلق — بياناتك محفوظة على جهازك ولم يضع منها شيء. حدّث الصفحة
          للمتابعة، أو نزّل نسخة احتياطية أولًا للاطمئنان.
        </p>
        <button
          onClick={() => window.location.reload()}
          className="mt-1 w-full max-w-xs rounded-full bg-solo py-3 text-sm font-bold text-white active:scale-[0.98]"
        >
          إعادة تحميل التطبيق
        </button>
        <button
          onClick={() => void this.handleExport()}
          disabled={this.state.exporting}
          className="w-full max-w-xs rounded-full border border-white/10 bg-card py-3 text-sm font-bold text-cream active:scale-[0.98] disabled:opacity-50"
        >
          {this.state.exporting
            ? "جارٍ تجهيز النسخة…"
            : this.state.exported
              ? "تم تنزيل النسخة ✓"
              : "تنزيل نسخة احتياطية"}
        </button>
      </div>
    );
  }
}
