import { useMemo } from "react";
import { Check, Hash } from "lucide-react";
import { db, extractTags } from "../db/db";
import { useLiveQuery } from "../hooks";
import { sectionColor } from "./Sections";

/**
 * Appends `#tag` to the draft (no-op if the draft already has it).
 * Exported so every editor inserts tags exactly the same way.
 */
export function insertTag(text: string, tag: string): string {
  const t = tag.toLowerCase();
  if (extractTags(text).includes(t)) return text;
  const base = text.replace(/\s+$/u, "");
  return (base.length === 0 ? "" : base + " ") + "#" + t + " ";
}

interface Props {
  /** Current draft text — used to preview which sections it will land in. */
  text: string;
  /** Extra carousel page texts — their #tags count too. */
  extraTexts?: string[];
  /** Called with the new draft when the user taps a section chip. */
  onInsert: (next: string) => void;
}

/**
 * Section picker shown under every text editor (new post + both edit boxes).
 * - "Will be filed under" previews the draft's #tags live (new ones badged).
 * - Existing sections appear as tappable chips — one tap inserts the #tag.
 */
export function TagSuggest({ text, extraTexts, onInsert }: Props) {
  // Active posts only: archived posts' tags have no visible section, so
  // suggesting them would file the draft into a circle that doesn't exist.
  const posts = useLiveQuery(
    () => db.posts.where("status").equals("active").toArray(),
    []
  );

  const existing = useMemo(() => {
    const counts = new Map<string, number>();
    for (const p of posts ?? []) {
      for (const t of p.tags) counts.set(t, (counts.get(t) ?? 0) + 1);
    }
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, 12);
  }, [posts]);

  const draftTags = useMemo(
    () => extractTags([text, ...(extraTexts ?? [])].join("\n")),
    [text, extraTexts]
  );
  const known = useMemo(() => new Set(existing.map(([t]) => t)), [existing]);

  return (
    <div className="mt-3 rounded-2xl border border-white/10 bg-void/60 p-3">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-[11px] font-bold uppercase tracking-wider text-mist">
          Will be filed under:
        </span>
        {draftTags.length === 0 ? (
          <span className="text-xs text-mist">
            no section yet — pick one below or type #tag
          </span>
        ) : (
          draftTags.map((t) => (
            <span
              key={t}
              className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-bold text-white"
              style={{ backgroundColor: sectionColor(t) + "33", color: sectionColor(t) }}
            >
              <Hash size={12} />#{t}
              {!known.has(t) && (
                <span className="rounded-full bg-white/15 px-1.5 text-[10px] font-bold">
                  new
                </span>
              )}
            </span>
          ))
        )}
      </div>

      {existing.length > 0 && (
        <>
          <p className="mb-1.5 mt-2.5 text-[11px] font-bold uppercase tracking-wider text-mist">
            Your sections — tap to add:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {existing.map(([tag, count]) => {
              const active = draftTags.includes(tag);
              const color = sectionColor(tag);
              return (
                <button
                  key={tag}
                  onClick={() => {
                    if (!active) onInsert(insertTag(text, tag));
                  }}
                  disabled={active}
                  aria-label={active ? tag + " already added" : "Add to section " + tag}
                  className="inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-bold transition active:scale-95 disabled:opacity-70"
                  style={
                    active
                      ? { borderColor: color, backgroundColor: color + "26", color }
                      : { borderColor: "rgba(255,255,255,0.12)", color: "#EDE9E4" }
                  }
                >
                  {active ? <Check size={12} /> : <Hash size={12} />}
                  {tag}
                  <span className="font-normal opacity-70">· {count}</span>
                </button>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
