import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  CalendarDays,
  History,
  Loader2,
  MoonStar,
  Plus,
  Sparkles,
  Sprout
} from "lucide-react";
import { addPost, db } from "../db/db";
import { useLiveQuery } from "../hooks";
import { usePrefs } from "../lib/prefs";
import { PostCard } from "./PostCard";
import { SectionsRow, SectionDetail, buildSections } from "./Sections";
import {
  pickResurface,
  staleNudges,
  type Nudge,
  type Resurfaced
} from "../lib/suggest";
import {
  aiContextSize,
  buildDigest,
  isAiAvailable,
  isAiEnabled,
  loadCachedIdeas,
  saveCachedIdeas,
  suggestIdeas
} from "../lib/ai";

interface Props {
  rotation: number;
  onOpen: (id: string) => void;
  onCapture: () => void;
}

function ReasonIcon({ reason }: { reason: Resurfaced["reason"] }) {
  const cls = "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ";
  if (reason === "onthisday")
    return (
      <span className={cls + "bg-gold/15 text-gold"}>
        <CalendarDays size={18} />
      </span>
    );
  if (reason === "forgotten")
    return (
      <span className={cls + "bg-clay/15 text-clay"}>
        <History size={18} />
      </span>
    );
  if (reason === "quiet")
    return (
      <span className={cls + "bg-solo/15 text-solosoft"}>
        <Sprout size={18} />
      </span>
    );
  return (
    <span className={cls + "bg-white/5 text-mist"}>
      <MoonStar size={18} />
    </span>
  );
}

export function ResurfaceCard({ item, onOpen }: { item: Resurfaced; onOpen: () => void }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, transition: { duration: 0.2 } }}
      className="relative overflow-hidden rounded-2xl border border-solo/25 bg-gradient-to-br from-solo/15 via-card to-card p-4"
    >
      <div className="flex items-center gap-2.5">
        <ReasonIcon reason={item.reason} />
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-solosoft">
            {item.label}
          </p>
          <p className="truncate text-xs text-mist">{item.detail}</p>
        </div>
      </div>
      <button onClick={onOpen} className="mt-2.5 block w-full text-left active:scale-[0.99]">
        <p className="line-clamp-3 whitespace-pre-wrap text-[15px] leading-relaxed text-cream">
          {item.post.content}
        </p>
        <span className="mt-1.5 inline-block text-xs font-bold text-solosoft">
          Revisit →
        </span>
      </button>
    </motion.div>
  );
}

export function NudgeCard({ nudge, onOpen }: { nudge: Nudge; onOpen: () => void }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, transition: { duration: 0.2 } }}
      className="flex items-center gap-3 rounded-2xl border border-clay/25 bg-clay/[0.07] p-4"
    >
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-semibold text-cream">
          {nudge.post.content.trim().replace(/\s+/g, " ").slice(0, 60) || "Untitled"}
        </span>
        <span className="block text-xs text-mist">
          Quiet for {nudge.daysStale} days — send it a sign of life
        </span>
      </span>
      <button
        onClick={onOpen}
        className="shrink-0 whitespace-nowrap rounded-full bg-clay/20 px-4 py-2 text-xs font-bold text-clay active:scale-95"
      >
        Check in
      </button>
    </motion.div>
  );
}

function IdeasCard() {
  const [ideas, setIdeas] = useState<string[] | null>(() => loadCachedIdeas());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedIdx, setSavedIdx] = useState<number | null>(null);

  async function generate() {
    if (loading) return;
    if (!isAiEnabled()) {
      setError("Private AI is off — switch it on in Settings.");
      return;
    }
    if (!isAiAvailable()) {
      setError("No AI provider is ready — pick one in Settings.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const digest = await buildDigest(aiContextSize());
      const fresh = await suggestIdeas(digest);
      if (fresh.length === 0) throw new Error("empty");
      saveCachedIdeas(fresh);
      setIdeas(fresh);
    } catch (e) {
      console.error("SoloFeed ideas failed:", e);
      setError("Could not dream up ideas right now. Try again.");
    } finally {
      setLoading(false);
    }
  }

  async function saveIdea(text: string, idx: number) {
    try {
      await addPost(text, null);
      setSavedIdx(idx);
      window.setTimeout(() => setSavedIdx((v) => (v === idx ? null : v)), 2500);
    } catch (e) {
      console.error("SoloFeed save idea failed:", e);
    }
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, transition: { duration: 0.2 } }}
      className="rounded-2xl border border-gold/25 bg-gradient-to-br from-gold/10 via-card to-card p-4"
    >
      <div className="flex items-center gap-2.5">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gold/15 text-gold">
          <Sparkles size={18} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-bold uppercase tracking-wider text-gold">
            Fresh angles
          </p>
          <p className="truncate text-xs text-mist">Dreamed up from your own feed</p>
        </div>
        <button
          onClick={() => void generate()}
          disabled={loading}
          className="shrink-0 whitespace-nowrap rounded-full bg-gold/15 px-4 py-2 text-xs font-bold text-gold active:scale-95 disabled:opacity-50"
        >
          {loading ? "Dreaming…" : ideas ? "Refresh" : "Dream up"}
        </button>
      </div>
      {loading && (
        <div className="mt-3 flex items-center gap-2 text-sm text-mist">
          <Loader2 size={15} className="animate-spin" />
          Reading your feed for inspiration…
        </div>
      )}
      {error && <p className="mt-2 text-sm text-clay">{error}</p>}
      {ideas && !loading && (
        <div className="mt-3 flex flex-col gap-2">
          {ideas.map((idea, i) => (
            <div key={i} className="flex items-center gap-2 rounded-xl bg-void/60 p-2.5">
              <p className="min-w-0 flex-1 text-sm leading-relaxed text-cream">{idea}</p>
              <button
                onClick={() => void saveIdea(idea, i)}
                className="shrink-0 whitespace-nowrap rounded-full bg-solo px-3 py-1.5 text-xs font-bold text-white active:scale-95"
              >
                {savedIdx === i ? "Saved ✓" : "Capture"}
              </button>
            </div>
          ))}
          <p className="text-[11px] text-mist">Ideas refresh daily · cached on this device</p>
        </div>
      )}
    </motion.div>
  );
}

export function Feed({ rotation, onOpen, onCapture }: Props) {
  const posts = useLiveQuery(
    () =>
      db.posts
        .where("status")
        .equals("active")
        .toArray()
        .then((rows) => rows.sort((a, b) => b.updatedAt - a.updatedAt)),
    []
  );
  const prefs = usePrefs();
  const mode = prefs.feedMode;
  const [sectionTag, setSectionTag] = useState<string | null>(null);

  const now = Date.now();
  const all = posts ?? [];

  const sections = useMemo(() => buildSections(all), [posts]);

  // Deterministic daily seed: suggestions rotate once a day, never at random.
  const daySeed = useMemo(() => {
    const d = new Date();
    return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
  }, []);

  const resurfaced = useMemo(
    () => (prefs.showSuggestions ? pickResurface(all, now, daySeed + ":" + rotation, 3) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [posts, prefs.showSuggestions, daySeed, rotation]
  );
  const nudges = useMemo(
    () => (prefs.showSuggestions ? staleNudges(all, now, 2) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [posts, prefs.showSuggestions]
  );

  // Each Feed-tab press bumps `rotation`: the post list itself cycles
  // Latest → Oldest → Most alive → Quietest, so the framed posts really
  // change on every press. Deterministic, zero randomness.
  const ORDER_LABEL = {
    latest: "Latest first",
    oldest: "Oldest first",
    alive: "Most alive first",
    quiet: "Quietest first"
  } as const;
  const ORDER_KEYS = ["latest", "oldest", "alive", "quiet"] as const;
  const order = ORDER_KEYS[((rotation % ORDER_KEYS.length) + ORDER_KEYS.length) % ORDER_KEYS.length];

  const visible = useMemo(() => {
    const arr = [...all];
    if (order === "oldest") arr.sort((a, b) => a.createdAt - b.createdAt);
    else if (order === "alive")
      arr.sort((a, b) => b.updateCount - a.updateCount || b.updatedAt - a.updatedAt);
    else if (order === "quiet") arr.sort((a, b) => a.updatedAt - b.updatedAt);
    return arr;
  }, [posts, order]);

  if (posts === undefined) {
    return (
      <div className="flex flex-col gap-3" aria-label="Loading feed">
        {[0, 1, 2].map((i) => (
          <div key={i} className="h-36 animate-pulse rounded-2xl bg-card" />
        ))}
      </div>
    );
  }

  const suggestions: Array<{ kind: "resurface" | "nudge" | "ideas"; item: Resurfaced | Nudge | null }> = [
    ...resurfaced.map((r) => ({ kind: "resurface" as const, item: r as Resurfaced | Nudge | null })),
    ...nudges.map((n) => ({ kind: "nudge" as const, item: n as Resurfaced | Nudge | null })),
    { kind: "ideas" as const, item: null }
  ];

  // Spread suggestion slots through the list (every 3rd post, round-robin).
  const slots = new Map<number, (typeof suggestions)[number]>();
  all.forEach((_, i) => {
    if (suggestions.length > 0 && (i + 1) % 3 === 0) {
      slots.set(i, suggestions[(Math.floor((i + 1) / 3) - 1) % suggestions.length]);
    }
  });
  const ideasInserted = [...slots.values()].some((s) => s.kind === "ideas");

  return (
    <div>
      {prefs.showSections && (
        <SectionsRow sections={sections} order={prefs.sectionOrder} onOpen={setSectionTag} />
      )}

      {all.length === 0 ? (
        <EmptyState onCapture={onCapture} />
      ) : (
        <>
          <p className="mb-2 pt-1 text-xs text-mist">
            {ORDER_LABEL[order]} · ↻ Feed
          </p>
          <motion.div layout className="flex flex-col gap-8">
          <AnimatePresence initial={false}>
            {visible.map((p, i) => (
              <motion.div layout key={"wrap-" + p.id} className="flex flex-col gap-3">
                <PostCard post={p} onOpen={() => onOpen(p.id)} />
                {mode === "smart" && prefs.showSuggestions && slots.has(i) && (
                  <SuggestionSlot suggestion={slots.get(i)!} onOpen={onOpen} />
                )}
              </motion.div>
            ))}
          </AnimatePresence>
          {mode === "smart" && prefs.showSuggestions && !ideasInserted && <IdeasCard />}
          {mode === "smart" && prefs.showSuggestions && all.length < 3 && (
            <div className="flex flex-col gap-3">
              {suggestions.slice(0, 2).map((s, idx) => (
                <SuggestionSlot key={"extra-" + idx} suggestion={s} onOpen={onOpen} />
              ))}
            </div>
          )}
        </motion.div>
        </>
      )}

      <AnimatePresence>
        {sectionTag && (
          <SectionDetail
            key={"section-" + sectionTag}
            tag={sectionTag}
            posts={all}
            onBack={() => setSectionTag(null)}
            onOpen={onOpen}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function SuggestionSlot({
  suggestion,
  onOpen
}: {
  suggestion: { kind: "resurface" | "nudge" | "ideas"; item: Resurfaced | Nudge | null };
  onOpen: (id: string) => void;
}) {
  if (suggestion.kind === "resurface" && suggestion.item && "post" in suggestion.item) {
    const r = suggestion.item as Resurfaced;
    return <ResurfaceCard item={r} onOpen={() => onOpen(r.post.id)} />;
  }
  if (suggestion.kind === "nudge" && suggestion.item && "daysStale" in suggestion.item) {
    const n = suggestion.item as Nudge;
    return <NudgeCard nudge={n} onOpen={() => onOpen(n.post.id)} />;
  }
  return <IdeasCard />;
}

function EmptyState({ onCapture }: { onCapture: () => void }) {
  return (
    <div className="mt-6 flex flex-col items-center gap-3 px-6 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-solo/15 text-solosoft">
        <Sprout size={26} />
      </span>
      <p className="font-semibold text-cream">Your sanctuary is empty</p>
      <p className="text-sm leading-relaxed text-mist">
        Capture your first thought — it takes three seconds, and it is only
        ever for you.
      </p>
      <button
        onClick={onCapture}
        className="mt-1 inline-flex items-center gap-2 rounded-full bg-solo px-5 py-2.5 text-sm font-bold text-white shadow-[0_8px_20px_rgba(79,70,229,0.4)] active:scale-95"
      >
        <Plus size={17} />
        New post
      </button>
    </div>
  );
}
