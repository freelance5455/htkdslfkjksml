import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { History, Plus, Send, ShieldCheck, Sparkles, Trash2, X } from "lucide-react";
import { db, uid, type ChatMessage } from "../db/db";
import { useLiveQuery } from "../hooks";
import {
  AI_SUGGESTIONS,
  aiContextSize,
  askAiStream,
  buildDigest,
  buildPostContext,
  isAiAvailable,
  isAiEnabled
} from "../lib/ai";
import { timeAgo } from "../lib/time";

export interface AiChatContext {
  postId: string;
  excerpt: string;
}

interface Props {
  context: AiChatContext | null;
  onClearContext: () => void;
}

type Scope = "recent" | "post" | "none";

function titleFor(text: string): string {
  const t = text.trim().replace(/\s+/g, " ");
  return t.length > 42 ? t.slice(0, 42) + "…" : t || "New reflection";
}

export function AiChat({ context, onClearContext }: Props) {
  const [threadId, setThreadId] = useState<string | null>(null);
  const [scope, setScope] = useState<Scope>(context ? "post" : "recent");
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [streamText, setStreamText] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const stopRef = useRef<(() => void) | null>(null);
  const aliveRef = useRef(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  const threads = useLiveQuery(
    () => db.threads.orderBy("updatedAt").reverse().toArray(),
    []
  );
  const messages = useLiveQuery<ChatMessage[]>(
    () =>
      threadId
        ? db.messages.where("threadId").equals(threadId).sortBy("createdAt")
        : Promise.resolve([]),
    [threadId]
  );

  useEffect(() => {
    aliveRef.current = true;
    return () => {
      aliveRef.current = false;
      stopRef.current?.();
    };
  }, []);

  useEffect(() => {
    if (context) setScope("post");
  }, [context]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, streamText, streaming, threadId]);

  async function ensureThread(firstText: string): Promise<string> {
    if (threadId) {
      await db.threads.update(threadId, { updatedAt: Date.now() });
      return threadId;
    }
    const now = Date.now();
    const id = uid();
    await db.threads.add({ id, title: titleFor(firstText), createdAt: now, updatedAt: now });
    if (aliveRef.current) setThreadId(id);
    return id;
  }

  async function send(raw: string) {
    const task = raw.trim();
    if (!task || streaming) return;
    if (!isAiEnabled()) {
      setError("Private AI is turned off. Switch it on in Settings to reflect with your feed.");
      return;
    }
    if (!isAiAvailable()) {
      setError("No AI provider is ready — pick one in Settings → Private AI.");
      return;
    }
    setError(null);
    setInput("");
    setStreaming(true);
    setStreamText("");
    let acc = "";
    try {
      const tid = await ensureThread(task);
      await db.messages.add({
        id: uid(),
        threadId: tid,
        role: "user",
        content: task,
        createdAt: Date.now()
      });
      let digest = "";
      if (scope === "recent") digest = await buildDigest(aiContextSize());
      else if (scope === "post" && context) digest = await buildPostContext(context.postId);
      const handle = askAiStream(task, digest, (chunk) => {
        if (!aliveRef.current) return;
        acc += chunk;
        setStreamText(acc);
      });
      stopRef.current = handle.stop;
      const full = (await handle.promise).trim();
      const finalText = full || acc.trim();
      if (aliveRef.current && finalText) {
        await db.messages.add({
          id: uid(),
          threadId: tid,
          role: "assistant",
          content: finalText,
          createdAt: Date.now()
        });
        await db.threads.update(tid, { updatedAt: Date.now() });
      }
    } catch (e) {
      console.error("SoloFeed AI error:", e);
      if (aliveRef.current) {
        const partial = acc.trim();
        if (partial) {
          try {
            const tid = threadId ?? (await ensureThread(task));
            await db.messages.add({
              id: uid(),
              threadId: tid,
              role: "assistant",
              content: partial,
              createdAt: Date.now()
            });
          } catch {
            // storage failure — surface the message below instead
          }
        }
        setError("The reflection was interrupted. Your words are safe — try again.");
      }
    } finally {
      stopRef.current = null;
      if (aliveRef.current) {
        setStreaming(false);
        setStreamText("");
      }
    }
  }

  function stop() {
    stopRef.current?.();
  }

  function newChat() {
    stopRef.current?.();
    setThreadId(null);
    setStreamText("");
    setStreaming(false);
    setError(null);
    setHistoryOpen(false);
  }

  const available = isAiAvailable() && isAiEnabled();
  const activeThread = threads?.find((t) => t.id === threadId) ?? null;
  const list: ChatMessage[] = messages ?? [];

  return (
    <div className="flex flex-col" style={{ height: "calc(100dvh - 225px)", minHeight: "320px" }}>
      <div className="mb-3 flex items-center gap-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-solo/15 text-solosoft">
          <Sparkles size={18} />
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="truncate text-[15px] font-bold text-cream">
            {activeThread ? activeThread.title : "New reflection"}
          </h2>
          <p className="truncate text-xs text-mist">
            Private AI · reads only what you attach
          </p>
        </div>
        <button
          onClick={() => setHistoryOpen((v) => !v)}
          aria-label="Chat history"
          className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-mist active:scale-95"
        >
          <History size={17} />
        </button>
        <button
          onClick={newChat}
          aria-label="Start a new chat"
          className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-mist active:scale-95"
        >
          <Plus size={18} />
        </button>
      </div>

      <div className="mb-3 flex gap-2">
        <button
          onClick={() => setScope("recent")}
          className={
            "shrink-0 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold transition " +
            (scope === "recent" ? "bg-solo text-white" : "border border-white/10 bg-card text-mist")
          }
        >
          Recent feed
        </button>
        {context && (
          <button
            onClick={() => setScope("post")}
            className={
              "min-w-0 flex-1 truncate rounded-full px-3 py-1.5 text-xs font-semibold transition " +
              (scope === "post" ? "bg-solo text-white" : "border border-white/10 bg-card text-mist")
            }
          >
            This post: {context.excerpt}
          </button>
        )}
        <button
          onClick={() => {
            setScope("none");
            onClearContext();
          }}
          className={
            "shrink-0 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold transition " +
            (scope === "none" ? "bg-solo text-white" : "border border-white/10 bg-card text-mist")
          }
        >
          No context
        </button>
      </div>

      <div className="relative flex-1">
        <div ref={scrollRef} className="absolute inset-0 overflow-y-auto pb-2">
          {!available && (
            <div className="rounded-2xl border border-white/10 bg-card p-4 text-sm leading-relaxed text-mist">
              <p className="font-semibold text-cream">Private AI is off</p>
              <p className="mt-1">
                Turn it on in Settings to reflect on your feed. AI only ever
                reads the context you attach to a message — nothing else.
              </p>
            </div>
          )}

          {available && list.length === 0 && !streaming && (
            <div className="flex flex-col gap-2">
              <div className="rounded-2xl border border-white/10 bg-card p-4">
                <p className="text-sm font-semibold text-cream">Ask your past self anything</p>
                <p className="mt-1 text-sm leading-relaxed text-mist">
                  {scope === "post" && context
                    ? "This post and its whole journey are attached."
                    : scope === "recent"
                      ? "Your recent posts are attached as context."
                      : "No context attached — answers come from your words alone."}
                </p>
              </div>
              {AI_SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => void send(s)}
                  className="rounded-2xl border border-white/10 bg-card p-3 text-left text-sm font-medium text-cream transition active:scale-[0.99]"
                >
                  {s}
                </button>
              ))}
            </div>
          )}

          {list.map((m) => (
            <div key={m.id} className={"mb-2.5 flex " + (m.role === "user" ? "justify-end" : "justify-start")}>
              <div
                className={
                  "max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed " +
                  (m.role === "user"
                    ? "rounded-br-md bg-solo text-white"
                    : "rounded-bl-md border border-white/5 bg-white/[0.05] text-cream")
                }
              >
                <p className="whitespace-pre-wrap">{m.content}</p>
                <p className={"mt-1 text-[11px] " + (m.role === "user" ? "text-white/60" : "text-mist")}>
                  {timeAgo(m.createdAt)}
                </p>
              </div>
            </div>
          ))}

          {streaming && (
            <div className="mb-2.5 flex justify-start">
              <div className="max-w-[85%] rounded-2xl rounded-bl-md border border-white/5 bg-white/[0.05] px-3.5 py-2.5 text-sm leading-relaxed text-cream">
                {streamText ? (
                  <p className="whitespace-pre-wrap">{streamText}</p>
                ) : (
                  <span className="inline-flex items-center gap-1.5 py-1" aria-label="Thinking">
                    {[0, 1, 2].map((i) => (
                      <motion.span
                        key={i}
                        className="h-2 w-2 rounded-full bg-solosoft"
                        animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.1, 0.8] }}
                        transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.18 }}
                      />
                    ))}
                  </span>
                )}
              </div>
            </div>
          )}

          {error && (
            <p className="mb-2 rounded-2xl border border-clay/40 bg-clay/10 p-3 text-sm text-cream">
              {error}
            </p>
          )}
        </div>

        <AnimatePresence>
          {historyOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
              className="absolute inset-x-0 top-0 z-10 max-h-64 overflow-y-auto rounded-2xl border border-white/10 bg-card p-2 shadow-[0_16px_40px_rgba(0,0,0,0.5)]"
            >
              <div className="flex items-center justify-between px-2 py-1">
                <span className="text-xs font-bold uppercase tracking-wider text-mist">Past reflections</span>
                <button
                  onClick={() => setHistoryOpen(false)}
                  aria-label="Close history"
                  className="flex h-7 w-7 items-center justify-center rounded-full text-mist"
                >
                  <X size={15} />
                </button>
              </div>
              {(threads ?? []).length === 0 && (
                <p className="px-2 py-3 text-sm text-mist">No past reflections yet.</p>
              )}
              {(threads ?? []).map((t) => (
                <div
                  key={t.id}
                  className={
                    "flex items-center gap-1 rounded-xl px-2 py-2 " +
                    (t.id === threadId ? "bg-solo/15" : "")
                  }
                >
                  <button
                    onClick={() => {
                      stopRef.current?.();
                      setThreadId(t.id);
                      setStreaming(false);
                      setStreamText("");
                      setError(null);
                      setHistoryOpen(false);
                    }}
                    className="min-w-0 flex-1 text-left"
                  >
                    <span className="block truncate text-sm font-semibold text-cream">{t.title}</span>
                    <span className="block text-xs text-mist">{timeAgo(t.updatedAt)}</span>
                  </button>
                  <button
                    onClick={() => void deleteThread(t.id)}
                    aria-label={"Delete " + t.title}
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-mist active:scale-95"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-2 flex items-center gap-2">
        {streaming ? (
          <button
            onClick={stop}
            className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-clay/50 bg-clay/10 text-sm font-bold text-clay active:scale-[0.98]"
          >
            <X size={17} />
            Stop
          </button>
        ) : (
          <>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send(input);
                }
              }}
              placeholder={available ? "Reflect with your feed…" : "Private AI is off"}
              aria-label="Chat with private AI"
              disabled={!available}
              className="h-12 flex-1 rounded-full border border-white/10 bg-card px-4 text-[15px] text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none disabled:opacity-50"
            />
            <button
              onClick={() => void send(input)}
              disabled={!available || input.trim().length === 0}
              aria-label="Send message"
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-solo text-white shadow-[0_8px_20px_rgba(79,70,229,0.4)] transition active:scale-95 disabled:opacity-40 disabled:shadow-none"
            >
              <Send size={19} />
            </button>
          </>
        )}
      </div>
      <p className="mt-1.5 flex items-center justify-center gap-1 text-center text-[11px] text-mist">
        <ShieldCheck size={12} />
        Only attached context is sent · chats stay on this device
      </p>
    </div>
  );

  async function deleteThread(id: string) {
    await db.transaction("rw", db.threads, db.messages, async () => {
      await db.messages.where("threadId").equals(id).delete();
      await db.threads.delete(id);
    });
    if (threadId === id) {
      stopRef.current?.();
      if (aliveRef.current) {
        setThreadId(null);
        setStreaming(false);
        setStreamText("");
      }
    }
  }
}
