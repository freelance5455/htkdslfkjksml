import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Award,
  Brain,
  ChevronLeft,
  Cpu,
  Database,
  Download,
  Eye,
  EyeOff,
  FlaskConical,
  Hash,
  KeyRound,
  Loader2,
  Newspaper,
  Plus,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload
} from "lucide-react";
import { db, extractAllTags } from "../db/db";
import { useLiveQuery } from "../hooks";
import { aiContextSize, isAiAvailable, isAiEnabled, setAiContextSize, setAiEnabled } from "../lib/ai";
import {
  allProviders,
  deleteCustom,
  getActiveId,
  getDef,
  getState,
  isProviderReady,
  newCustomId,
  providerMissing,
  saveCustom,
  setActiveId,
  setState as setProviderState,
  testProvider,
  type ProviderDef
} from "../lib/providers";
import {
  loadPrefs,
  savePrefs,
  type FeedMode,
  type FeedPrefs,
  type SectionOrder
} from "../lib/prefs";
import { Archive } from "./Archive";

interface Props {
  onClose: () => void;
  onOpenPost: (id: string) => void;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-5">
      <h3 className="mb-2 whitespace-nowrap text-xs font-bold uppercase tracking-wider text-mist">
        {title}
      </h3>
      <div className="overflow-hidden rounded-2xl border border-white/10 bg-card">
        {children}
      </div>
    </section>
  );
}

function Row({
  children,
  last
}: {
  children: React.ReactNode;
  last?: boolean;
}) {
  return (
    <div className={"flex items-center gap-3 p-4 " + (last ? "" : "border-b border-white/5")}>
      {children}
    </div>
  );
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error("read failed"));
    fr.readAsDataURL(blob);
  });
}

/**
 * Removes every app-owned localStorage entry (likes, prefs, interests, AI
 * settings/keys, daily idea caches). Database tables are cleared separately
 * by eraseAll — without this, an "erase everything" would silently keep
 * likes, settings and API keys behind.
 */
function clearLocalData(): void {
  try {
    const doomed: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith("sf-")) {
        doomed.push(k);
      }
    }
    for (const k of doomed) localStorage.removeItem(k);
  } catch {
    // storage unavailable — nothing to clean
  }
}

function Toggle({ on, onFlip, label }: { on: boolean; onFlip: () => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onFlip}
      className={"relative h-7 w-12 shrink-0 rounded-full transition " + (on ? "bg-solo" : "bg-white/10")}
    >
      <span
        className={
          "absolute top-1 h-5 w-5 rounded-full bg-white transition-all " + (on ? "left-6" : "left-1")
        }
      />
    </button>
  );
}

function ProviderDot({ ready }: { ready: boolean }) {
  return (
    <span
      className={"h-2.5 w-2.5 shrink-0 rounded-full " + (ready ? "bg-emerald-400" : "bg-amber-400")}
    />
  );
}

function ProviderSettings() {
  const [list, setList] = useState<ProviderDef[]>(() => allProviders());
  const [active, setActive] = useState<string>(() => getActiveId());
  const [editing, setEditing] = useState<string | "new" | null>(null);
  const [name, setName] = useState("");
  const [baseUrl, setBaseUrl] = useState("");
  const [model, setModel] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testMsg, setTestMsg] = useState<{ ok: boolean; text: string } | null>(null);

  function refresh() {
    setList(allProviders());
    setActive(getActiveId());
  }

  function pick(id: string) {
    setActiveId(id);
    setActive(id);
  }

  function startEdit(id: string | "new") {
    if (id === "new") {
      setName("");
      setBaseUrl("https://");
      setModel("");
      setApiKey("");
    } else {
      const def = getDef(id);
      const st = getState(id);
      setName(def.name);
      setBaseUrl(st.baseUrl);
      setModel(st.model);
      setApiKey(st.apiKey);
    }
    setTestMsg(null);
    setShowKey(false);
    setEditing(id);
  }

  function persistDraft(id: string): boolean {
    if (!/^https?:\/\//i.test(baseUrl.trim())) {
      setTestMsg({ ok: false, text: "Enter a valid http(s) base URL." });
      return false;
    }
    setProviderState(id, {
      model: model.trim(),
      apiKey: apiKey.trim(),
      baseUrl: baseUrl.trim()
    });
    return true;
  }

  function saveEdit() {
    if (editing === "new") {
      if (!name.trim()) {
        setTestMsg({ ok: false, text: "Give the provider a name." });
        return;
      }
      const id = newCustomId();
      saveCustom({
        id,
        name: name.trim().slice(0, 40),
        baseUrl: baseUrl.trim(),
        defaultModel: model.trim()
      });
      if (!persistDraft(id)) return;
      setEditing(null);
      refresh();
    } else if (editing) {
      if (!persistDraft(editing)) return;
      setEditing(null);
      refresh();
    }
  }

  async function runTest() {
    if (testing) return;
    let id = editing;
    // A brand-new provider must exist before it can be tested.
    if (id === "new") {
      if (!name.trim()) {
        setTestMsg({ ok: false, text: "Give the provider a name first." });
        return;
      }
      id = newCustomId();
      saveCustom({
        id,
        name: name.trim().slice(0, 40),
        baseUrl: baseUrl.trim(),
        defaultModel: model.trim()
      });
      if (!persistDraft(id)) return;
      setEditing(id);
      refresh();
    }
    if (!id || id === "new") return;
    setTesting(true);
    setTestMsg(null);
    try {
      const reply = await testProvider(id);
      setTestMsg({ ok: true, text: "Connected ✓ " + reply });
    } catch (e) {
      setTestMsg({
        ok: false,
        text: e instanceof Error ? e.message : "Connection failed."
      });
    } finally {
      setTesting(false);
    }
  }

  if (editing) {
    const isNew = editing === "new";
    const def = isNew ? null : getDef(editing);
    return (
      <div>
        <div className="mb-4 rounded-2xl border border-white/10 bg-card p-4">
          <p className="text-sm font-bold text-cream">
            {isNew ? "New custom provider" : def?.name}
          </p>
          <p className="mt-0.5 text-xs leading-relaxed text-mist">
            {isNew
              ? "Any OpenAI-compatible chat API works — cloud or self-hosted."
              : (def?.note ?? "Keys stay on this device and are never backed up.")}
          </p>

          {isNew && (
            <label className="mt-3 block">
              <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-mist">
                Name
              </span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="My provider"
                aria-label="Provider name"
                className="h-11 w-full rounded-xl border border-white/10 bg-void px-3.5 text-[15px] text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none"
              />
            </label>
          )}

          {(!def || def.kind === "openai") && (
            <label className="mt-3 block">
              <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-mist">
                Base URL
              </span>
              <input
                value={baseUrl}
                onChange={(e) => setBaseUrl(e.target.value)}
                placeholder="https://api.example.com/v1"
                aria-label="API base URL"
                inputMode="url"
                className="h-11 w-full rounded-xl border border-white/10 bg-void px-3.5 font-mono text-[13px] text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none"
              />
            </label>
          )}

          {(!def || def.kind === "openai") && (
            <div className="mt-3">
              <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-mist">
                Model
              </span>
              <input
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder={def?.defaultModel || "model-name"}
                aria-label="Model name"
                className="h-11 w-full rounded-xl border border-white/10 bg-void px-3.5 font-mono text-[13px] text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none"
              />
              {def && def.models.length > 1 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {def.models.map((m) => (
                    <button
                      key={m}
                      onClick={() => setModel(m)}
                      className={
                        "rounded-full px-3 py-1 text-xs font-bold transition " +
                        (model === m ? "bg-solo text-white" : "bg-white/5 text-mist")
                      }
                    >
                      {m}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {(!def || def.needsKey) && (
            <label className="mt-3 block">
              <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-mist">
                API key
              </span>
              <span className="relative block">
                <KeyRound
                  size={15}
                  className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-mist"
                />
                <input
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  type={showKey ? "text" : "password"}
                  placeholder="sk-…"
                  aria-label="API key"
                  autoComplete="off"
                  className="h-11 w-full rounded-xl border border-white/10 bg-void pl-10 pr-11 font-mono text-[13px] text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none"
                />
                <button
                  onClick={() => setShowKey((v) => !v)}
                  aria-label={showKey ? "Hide API key" : "Show API key"}
                  className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-mist active:scale-95"
                >
                  {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </span>
              {def?.keyHint ? (
                <span className="mt-1 block text-xs text-mist">{def.keyHint}</span>
              ) : null}
            </label>
          )}

          {testMsg && (
            <p
              className={
                "mt-3 rounded-xl border p-3 text-sm leading-relaxed " +
                (testMsg.ok
                  ? "border-emerald-400/30 bg-emerald-400/10 text-cream"
                  : "border-clay/40 bg-clay/10 text-cream")
              }
            >
              {testMsg.text}
            </p>
          )}

          <div className="mt-3 flex gap-2">
            <button
              onClick={() => void runTest()}
              disabled={testing}
              className="inline-flex h-11 flex-1 items-center justify-center gap-1.5 rounded-full border border-white/10 bg-white/5 text-sm font-bold text-cream active:scale-[0.98] disabled:opacity-60"
            >
              {testing ? <Loader2 size={16} className="animate-spin" /> : <FlaskConical size={16} />}
              {testing ? "Testing…" : "Test connection"}
            </button>
            <button
              onClick={saveEdit}
              className="h-11 flex-1 rounded-full bg-solo text-sm font-bold text-white active:scale-[0.98]"
            >
              Save
            </button>
          </div>
          {def?.custom && (
            <button
              onClick={() => {
                deleteCustom(def.id);
                setEditing(null);
                refresh();
              }}
              className="mt-2 inline-flex h-10 w-full items-center justify-center gap-1.5 rounded-full text-xs font-bold text-clay active:scale-[0.98]"
            >
              <Trash2 size={14} />
              Delete this provider
            </button>
          )}
        </div>
        <button
          onClick={() => {
            setEditing(null);
            refresh();
          }}
          className="h-11 w-full rounded-full border border-white/10 bg-card text-sm font-bold text-mist active:scale-[0.98]"
        >
          Back to providers
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-4 rounded-2xl border border-white/10 bg-card p-4">
        <p className="text-sm font-bold text-cream">How AI answers you</p>
        <p className="mt-0.5 text-xs leading-relaxed text-mist">
          Solo uses the built-in AI. Or bring any key — your data goes only to
          the provider you pick, keys never leave this device.
        </p>
      </div>
      <div className="overflow-hidden rounded-2xl border border-white/10 bg-card">
        {list.map((p, i) => {
          const ready = providerMissing(p.id) === null;
          const isActive = p.id === active;
          const st = p.kind === "openai" ? getState(p.id) : null;
          return (
            <div
              key={p.id}
              className={
                "flex items-center gap-3 p-4 " +
                (i === list.length - 1 ? "" : "border-b border-white/5")
              }
            >
              <button
                onClick={() => pick(p.id)}
                aria-label={"Use " + p.name}
                className={
                  "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition " +
                  (isActive ? "border-solo" : "border-white/20")
                }
              >
                {isActive && <span className="h-2.5 w-2.5 rounded-full bg-solo" />}
              </button>
              <button onClick={() => pick(p.id)} className="min-w-0 flex-1 text-left">
                <span className="flex items-center gap-2 text-sm font-semibold text-cream">
                  {p.name}
                  <ProviderDot ready={ready} />
                </span>
                <span className="block truncate text-xs text-mist">
                  {p.kind === "perchance"
                    ? "Built-in · no setup"
                    : (st?.model || p.defaultModel) +
                      (p.needsKey ? (st?.apiKey ? " · key set" : " · key missing") : " · no key needed")}
                </span>
              </button>
              <button
                onClick={() => startEdit(p.id)}
                className="shrink-0 whitespace-nowrap rounded-full bg-white/5 px-3.5 py-1.5 text-xs font-bold text-cream active:scale-95"
              >
                {p.kind === "perchance" ? "Info" : ready ? "Edit" : "Setup"}
              </button>
            </div>
          );
        })}
      </div>
      <button
        onClick={() => startEdit("new")}
        className="mt-3 inline-flex h-11 w-full items-center justify-center gap-1.5 rounded-full border border-dashed border-white/15 bg-card/50 text-sm font-bold text-cream active:scale-[0.99]"
      >
        <Plus size={16} />
        Add a custom provider
      </button>
    </div>
  );
}

export function Settings({ onClose, onOpenPost }: Props) {
  const [aiOn, setAiOn] = useState(isAiEnabled());
  const [ctxSize, setCtxSize] = useState(aiContextSize());
  const [storage, setStorage] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [confirmErase, setConfirmErase] = useState(false);
  const [eraseFinal, setEraseFinal] = useState(false);
  const [feed, setFeed] = useState<FeedPrefs>(() => loadPrefs());
  const [museumOpen, setMuseumOpen] = useState(false);
  const [providerOpen, setProviderOpen] = useState(false);
  const archivedCount = useLiveQuery(() => db.posts.where("status").equals("archived").count(), []);

  function updateFeed(patch: Partial<FeedPrefs>) {
    setFeed((prev) => {
      const next = { ...prev, ...patch };
      savePrefs(next);
      return next;
    });
  }

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const est = await navigator.storage?.estimate?.();
        if (alive && est && typeof est.usage === "number") {
          const mb = est.usage / 1048576;
          setStorage(mb < 0.1 ? "under 0.1 MB" : mb.toFixed(1) + " MB");
        } else if (alive) {
          setStorage("unknown");
        }
      } catch {
        if (alive) setStorage("unknown");
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (!confirmErase && !eraseFinal) return;
    const t = window.setTimeout(() => {
      setConfirmErase(false);
      setEraseFinal(false);
    }, 8000);
    return () => window.clearTimeout(t);
  }, [confirmErase, eraseFinal]);

  async function exportAll() {
    setBusy("export");
    setStatus(null);
    try {
      const [posts, updates, threads, messages, covers, aiCreators, aiPosts] = await Promise.all([
        db.posts.toArray(),
        db.updates.toArray(),
        db.threads.toArray(),
        db.messages.toArray(),
        db.sectionCovers.toArray(),
        db.aiCreators.toArray(),
        db.aiPosts.toArray()
      ]);
      const serialisedPosts = await Promise.all(
        posts.map(async (p) => ({
          ...p,
          mediaBlob:
            p.mediaBlob instanceof Blob ? await blobToDataUrl(p.mediaBlob) : null,
          slides: await Promise.all(
            (Array.isArray(p.slides) ? p.slides : []).map(async (s) => ({
              text: typeof s.text === "string" ? s.text.slice(0, 5000) : "",
              mediaBlob:
                s.mediaBlob instanceof Blob ? await blobToDataUrl(s.mediaBlob) : null
            }))
          )
        }))
      );
      const serialisedCovers = await Promise.all(
        covers.map(async (c) => ({
          ...c,
          coverBlob:
            c.coverBlob instanceof Blob ? await blobToDataUrl(c.coverBlob) : null
        }))
      );
      const payload = JSON.stringify({
        app: "solo-feed",
        version: 2,
        exportedAt: Date.now(),
        posts: serialisedPosts,
        updates,
        threads,
        messages,
        sectionCovers: serialisedCovers,
        aiCreators,
        aiPosts
      });
      const url = URL.createObjectURL(new Blob([payload], { type: "application/json" }));
      const a = document.createElement("a");
      const stamp = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = "solo-feed-backup-" + stamp + ".json";
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 5000);
      setStatus("Backup downloaded — keep it somewhere safe.");
    } catch (e) {
      console.error("SoloFeed export failed:", e);
      setStatus("Export failed. Please try again.");
    } finally {
      setBusy(null);
    }
  }

  async function importAll(file: File) {
    setBusy("import");
    setStatus(null);
    try {
      const data = JSON.parse(await file.text()) as {
        posts?: Array<Record<string, unknown>>;
        updates?: Array<Record<string, unknown>>;
        threads?: Array<Record<string, unknown>>;
        messages?: Array<Record<string, unknown>>;
        sectionCovers?: Array<Record<string, unknown>>;
        aiCreators?: Array<Record<string, unknown>>;
        aiPosts?: Array<Record<string, unknown>>;
      };
      let added = 0;
      await db.transaction("rw", [db.posts, db.updates, db.threads, db.messages, db.sectionCovers, db.aiCreators, db.aiPosts], async () => {
        for (const raw of data.posts ?? []) {
          if (typeof raw.id !== "string" || typeof raw.content !== "string") continue;
          let media: Blob | null = null;
          if (typeof raw.mediaBlob === "string" && raw.mediaBlob.startsWith("data:")) {
            try {
              media = await (await fetch(raw.mediaBlob)).blob();
            } catch {
              media = null;
            }
          }
          // Tags are re-extracted from the content (not trusted from the
          // file) so sections always match what's actually written.
          const clean = raw.content.slice(0, 20000);
          const slides: Array<{ text: string; mediaBlob: Blob | null }> = [];
          if (Array.isArray(raw.slides)) {
            for (const s of raw.slides.slice(0, 9)) {
              if (!s || typeof s !== "object") continue;
              const rec = s as Record<string, unknown>;
              let sm: Blob | null = null;
              if (typeof rec.mediaBlob === "string" && rec.mediaBlob.startsWith("data:")) {
                try {
                  sm = await (await fetch(rec.mediaBlob)).blob();
                } catch {
                  sm = null;
                }
              }
              const st = typeof rec.text === "string" ? rec.text.slice(0, 5000) : "";
              if (!st.trim() && !sm) continue;
              slides.push({ text: st, mediaBlob: sm });
            }
          }
          await db.posts.put({
            id: raw.id,
            content: clean,
            status: raw.status === "archived" ? "archived" : "active",
            tags: extractAllTags(clean, slides),
            createdAt: typeof raw.createdAt === "number" ? raw.createdAt : Date.now(),
            updatedAt: typeof raw.updatedAt === "number" ? raw.updatedAt : Date.now(),
            updateCount: typeof raw.updateCount === "number" ? raw.updateCount : 0,
            mediaBlob: media,
            slides
          });
          added++;
        }
        for (const raw of data.updates ?? []) {
          if (typeof raw.id !== "string" || typeof raw.postId !== "string" || typeof raw.content !== "string") continue;
          await db.updates.put({
            id: raw.id,
            postId: raw.postId,
            content: raw.content.slice(0, 20000),
            createdAt: typeof raw.createdAt === "number" ? raw.createdAt : Date.now()
          });
        }
        for (const raw of data.threads ?? []) {
          if (typeof raw.id !== "string") continue;
          await db.threads.put({
            id: raw.id,
            title: typeof raw.title === "string" ? raw.title.slice(0, 120) : "Imported reflection",
            createdAt: typeof raw.createdAt === "number" ? raw.createdAt : Date.now(),
            updatedAt: typeof raw.updatedAt === "number" ? raw.updatedAt : Date.now()
          });
        }
        for (const raw of data.messages ?? []) {
          if (typeof raw.id !== "string" || typeof raw.threadId !== "string" || typeof raw.content !== "string") continue;
          await db.messages.put({
            id: raw.id,
            threadId: raw.threadId,
            role: raw.role === "assistant" ? "assistant" : "user",
            content: raw.content.slice(0, 40000),
            createdAt: typeof raw.createdAt === "number" ? raw.createdAt : Date.now()
          });
        }
        for (const raw of data.sectionCovers ?? []) {
          if (typeof raw.tag !== "string") continue;
          let cover: Blob | null = null;
          if (typeof raw.coverBlob === "string" && raw.coverBlob.startsWith("data:")) {
            try {
              cover = await (await fetch(raw.coverBlob)).blob();
            } catch {
              cover = null;
            }
          }
          if (!cover) continue;
          await db.sectionCovers.put({
            tag: raw.tag.toLowerCase().slice(0, 60),
            coverBlob: cover,
            updatedAt: typeof raw.updatedAt === "number" ? raw.updatedAt : Date.now()
          });
        }
        for (const raw of data.aiCreators ?? []) {
          if (typeof raw.id !== "string" || typeof raw.name !== "string") continue;
          await db.aiCreators.put({
            id: raw.id,
            name: String(raw.name).slice(0, 24),
            topic: typeof raw.topic === "string" ? String(raw.topic).slice(0, 60) : "ideas",
            emoji: typeof raw.emoji === "string" ? String(raw.emoji).slice(0, 8) : "✨",
            color:
              typeof raw.color === "string" && /^#[0-9a-fA-F]{6}$/.test(raw.color)
                ? raw.color
                : "#4F46E5",
            prompt:
              typeof raw.prompt === "string"
                ? String(raw.prompt).slice(0, 800)
                : "You create short inspiring posts.",
            muted: raw.muted === true,
            lastSeen: typeof raw.lastSeen === "number" ? raw.lastSeen : 0,
            createdAt: typeof raw.createdAt === "number" ? raw.createdAt : Date.now(),
            updatedAt: typeof raw.updatedAt === "number" ? raw.updatedAt : Date.now()
          });
        }
        for (const raw of data.aiPosts ?? []) {
          if (
            typeof raw.id !== "string" ||
            typeof raw.creatorId !== "string" ||
            typeof raw.content !== "string"
          )
            continue;
          await db.aiPosts.put({
            id: raw.id,
            creatorId: raw.creatorId,
            content: String(raw.content).slice(0, 4000),
            createdAt: typeof raw.createdAt === "number" ? raw.createdAt : Date.now(),
            savedToFeed: raw.savedToFeed === true
          });
        }
      });
      setStatus(added + (added === 1 ? " post" : " posts") + " restored from backup.");
    } catch (e) {
      console.error("SoloFeed import failed:", e);
      setStatus("That file could not be imported. Is it a Solo Feed backup?");
    } finally {
      setBusy(null);
    }
  }

  async function eraseAll() {
    setBusy("erase");
    setStatus(null);
    try {
      await db.transaction("rw", [db.posts, db.updates, db.threads, db.messages, db.sectionCovers, db.aiCreators, db.aiPosts], async () => {
        await db.messages.clear();
        await db.threads.clear();
        await db.updates.clear();
        await db.posts.clear();
        await db.sectionCovers.clear();
        await db.aiPosts.clear();
        await db.aiCreators.clear();
      });
      // Wipe device-local leftovers too (likes, prefs, interests, AI keys):
      // otherwise "erase everything" would secretly keep them behind.
      clearLocalData();
      // No reseed here: "erase everything" must leave a truly empty
      // sanctuary (the friendly EmptyState), not two demo posts.
      setStatus("Everything erased. A fresh sanctuary awaits.");
    } catch (e) {
      console.error("SoloFeed erase failed:", e);
      setStatus("Erase failed. Please try again.");
    } finally {
      setBusy(null);
      setConfirmErase(false);
      setEraseFinal(false);
    }
  }

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-50 bg-void"
      role="dialog"
      aria-modal="true"
      aria-label="Settings"
    >
      <div className="mx-auto flex h-full max-w-xl flex-col">
        <div className="flex items-center gap-1 border-b border-white/10 px-2 py-2">
          <button
            onClick={() => {
              if (providerOpen) setProviderOpen(false);
              else if (museumOpen) setMuseumOpen(false);
              else onClose();
            }}
            aria-label="Back"
            className="flex h-10 w-10 items-center justify-center rounded-full text-cream active:scale-95"
          >
            <ChevronLeft size={22} />
          </button>
          <span className="text-sm font-bold text-cream">
            {providerOpen ? "AI provider" : museumOpen ? "Archive" : "Settings"}
          </span>
        </div>

        {providerOpen ? (
          <div className="flex-1 overflow-y-auto p-4">
            <ProviderSettings />
          </div>
        ) : museumOpen ? (
          <div className="flex-1 overflow-y-auto p-4">
            <Archive onOpen={onOpenPost} />
          </div>
        ) : (
        <div className="flex-1 overflow-y-auto p-4">
          <Section title="Private AI">
            <Row>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-solo/15 text-solosoft">
                <Brain size={19} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Reflection companion</span>
                <span className="block text-xs leading-relaxed text-mist">
                  {isAiAvailable()
                    ? "Reads only the context you attach to each message."
                    : "Not set up yet — pick a provider below."}
                </span>
              </span>
              <button
                role="switch"
                aria-checked={aiOn}
                aria-label="Toggle private AI"
                onClick={() => {
                  const next = !aiOn;
                  setAiOn(next);
                  setAiEnabled(next);
                }}
                className={
                  "relative h-7 w-12 shrink-0 rounded-full transition " +
                  (aiOn ? "bg-solo" : "bg-white/10")
                }
              >
                <span
                  className={
                    "absolute top-1 h-5 w-5 rounded-full bg-white transition-all " +
                    (aiOn ? "left-6" : "left-1")
                  }
                />
              </button>
            </Row>
            <Row>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-solo/15 text-solosoft">
                <Cpu size={19} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2 text-sm font-semibold text-cream">
                  {(() => {
                    const id = getActiveId();
                    const def = getDef(id);
                    return (
                      <>
                        {def.name}
                        <ProviderDot ready={providerMissing(id) === null} />
                      </>
                    );
                  })()}
                </span>
                <span className="block truncate text-xs text-mist">
                  {(() => {
                    const id = getActiveId();
                    const def = getDef(id);
                    if (def.kind === "perchance") return "Built-in · tap Change to use your own key";
                    const st = getState(id);
                    return (st.model || def.defaultModel) + " · tap Change to switch";
                  })()}
                </span>
              </span>
              <button
                onClick={() => setProviderOpen(true)}
                className="shrink-0 whitespace-nowrap rounded-full bg-solo/15 px-4 py-2 text-xs font-bold text-solosoft active:scale-95"
              >
                Change
              </button>
            </Row>
            <Row last>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Feed context size</span>
                <span className="block text-xs text-mist">How many recent posts AI may read.</span>
              </span>
              <span className="flex shrink-0 gap-1">
                {[5, 15, 30].map((n) => (
                  <button
                    key={n}
                    onClick={() => {
                      setCtxSize(n);
                      setAiContextSize(n);
                    }}
                    className={
                      "rounded-full px-3 py-1.5 text-xs font-bold transition " +
                      (ctxSize === n ? "bg-solo text-white" : "bg-white/5 text-mist")
                    }
                  >
                    {n}
                  </button>
                ))}
              </span>
            </Row>
          </Section>

          <Section title="Feed & sections">
            <Row>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-solo/15 text-solosoft">
                <Newspaper size={19} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Feed mode</span>
                <span className="block text-xs text-mist">
                  {feed.feedMode === "smart"
                    ? "Alive: sections, prompts and resurfaced memories."
                    : "Calm: everything in chronological order."}
                </span>
              </span>
              <span className="flex shrink-0 gap-1 rounded-full bg-white/5 p-1">
                {(["smart", "latest"] as const).map((m: FeedMode) => (
                  <button
                    key={m}
                    onClick={() => updateFeed({ feedMode: m })}
                    className={
                      "rounded-full px-3 py-1.5 text-xs font-bold transition " +
                      (feed.feedMode === m ? "bg-solo text-white" : "text-mist")
                    }
                  >
                    {m === "smart" ? "For you" : "Latest"}
                  </button>
                ))}
              </span>
            </Row>
            <Row>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-clay/15 text-clay">
                <Hash size={19} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Life sections</span>
                <span className="block text-xs leading-relaxed text-mist">
                  Circles built from your #tags — #books, #work, #daily.
                </span>
              </span>
              <Toggle
                on={feed.showSections}
                onFlip={() => updateFeed({ showSections: !feed.showSections })}
                label="Toggle life sections"
              />
            </Row>
            {feed.showSections && (
              <Row>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-semibold text-cream">Section order</span>
                  <span className="block text-xs text-mist">
                    Positions follow this rule — most recent first by default.
                  </span>
                </span>
                <span className="flex shrink-0 flex-col gap-1">
                  {(
                    [
                      ["recent", "Recent activity"],
                      ["count", "Most posts"],
                      ["alpha", "A–Z"]
                    ] as Array<[SectionOrder, string]>
                  ).map(([v, label]) => (
                    <button
                      key={v}
                      onClick={() => updateFeed({ sectionOrder: v })}
                      className={
                        "whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-bold transition " +
                        (feed.sectionOrder === v ? "bg-solo text-white" : "bg-white/5 text-mist")
                      }
                    >
                      {label}
                    </button>
                  ))}
                </span>
              </Row>
            )}
            <Row last>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/5 text-mist">
                <Sparkles size={19} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Smart suggestions</span>
                <span className="block text-xs text-mist">
                  Resurfaced memories, check-ins and fresh angles.
                </span>
              </span>
              <Toggle
                on={feed.showSuggestions}
                onFlip={() => updateFeed({ showSuggestions: !feed.showSuggestions })}
                label="Toggle smart suggestions"
              />
            </Row>
          </Section>

          <Section title="Museum">
            <Row last>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gold/15 text-gold">
                <Award size={19} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Archive</span>
                <span className="block text-xs text-mist">
                  {typeof archivedCount === "number"
                    ? archivedCount === 0
                      ? "No preserved memories yet"
                      : archivedCount + (archivedCount === 1 ? " memory preserved" : " memories preserved")
                    : "Your preserved memories"}
                </span>
              </span>
              <button
                onClick={() => setMuseumOpen(true)}
                className="shrink-0 whitespace-nowrap rounded-full bg-gold/15 px-4 py-2 text-xs font-bold text-gold active:scale-95"
              >
                Open
              </button>
            </Row>
          </Section>

          <Section title="Data & privacy">
            <Row>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/5 text-mist">
                <Database size={19} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">On this device</span>
                <span className="block text-xs text-mist">
                  {storage === null ? "Measuring…" : storage + " used · never uploaded"}
                </span>
              </span>
            </Row>
            <Row>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Export backup</span>
                <span className="block text-xs text-mist">Posts, chats and AI studio as JSON.</span>
              </span>
              <button
                onClick={() => void exportAll()}
                disabled={busy !== null}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-white/5 px-4 py-2 text-xs font-bold text-cream active:scale-95 disabled:opacity-50"
              >
                {busy === "export" ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
                Export
              </button>
            </Row>
            <Row last>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Import backup</span>
                <span className="block text-xs text-mist">Restore from a Solo Feed file.</span>
              </span>
              <label className="inline-flex shrink-0 cursor-pointer items-center gap-1.5 rounded-full bg-white/5 px-4 py-2 text-xs font-bold text-cream active:scale-95">
                {busy === "import" ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
                Import
                <input
                  type="file"
                  accept="application/json,.json"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    e.target.value = "";
                    if (f) void importAll(f);
                  }}
                />
              </label>
            </Row>
          </Section>

          <Section title="About">
            <Row last>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/5 text-mist">
                <ShieldCheck size={19} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Solo Feed 1.0 · local-first</span>
                <span className="block text-xs leading-relaxed text-mist">
                  Your attention belongs to you. Everything lives in this
                  browser's private database — AI features only send what you
                  explicitly attach.
                </span>
              </span>
            </Row>
          </Section>

          <Section title="Danger zone">
            <Row last={!(confirmErase || eraseFinal)}>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-cream">Erase everything</span>
                <span className="block text-xs text-mist">Posts, updates and chats. Cannot be undone.</span>
              </span>
              <button
                onClick={() => {
                  if (confirmErase || eraseFinal) {
                    setConfirmErase(false);
                    setEraseFinal(false);
                  } else {
                    setConfirmErase(true);
                  }
                }}
                disabled={busy !== null}
                className={
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold active:scale-95 disabled:opacity-50 " +
                  (confirmErase || eraseFinal ? "bg-clay/20 text-clay" : "bg-white/5 text-mist")
                }
              >
                {busy === "erase" ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                {confirmErase || eraseFinal ? "Close" : "Erase"}
              </button>
            </Row>
            {confirmErase && !eraseFinal && (
              <div className="border-t border-clay/30 bg-clay/[0.06] p-4">
                <p className="text-sm font-semibold text-cream">This cannot be undone.</p>
                <p className="mt-1 text-xs leading-relaxed text-mist">
                  Erasing removes posts, updates, chats, section photos and the
                  AI studio from this device. Download a backup first so you can
                  change your mind later.
                </p>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => void exportAll()}
                    disabled={busy !== null}
                    className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-full bg-white/5 text-xs font-bold text-cream active:scale-[0.98] disabled:opacity-50"
                  >
                    {busy === "export" ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
                    Export backup first
                  </button>
                  <button
                    onClick={() => setEraseFinal(true)}
                    disabled={busy !== null}
                    className="h-10 flex-1 rounded-full bg-clay/20 text-xs font-bold text-clay active:scale-[0.98] disabled:opacity-50"
                  >
                    I understand, continue
                  </button>
                </div>
              </div>
            )}
            {eraseFinal && (
              <div className="border-t border-clay/40 bg-clay/10 p-4">
                <p className="text-sm font-semibold text-clay">
                  Last chance — erase everything forever?
                </p>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => void eraseAll()}
                    disabled={busy !== null}
                    className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-full bg-clay text-xs font-bold text-white active:scale-[0.98] disabled:opacity-50"
                  >
                    {busy === "erase" ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    Yes, erase everything
                  </button>
                  <button
                    onClick={() => {
                      setConfirmErase(false);
                      setEraseFinal(false);
                    }}
                    disabled={busy !== null}
                    className="h-10 flex-1 rounded-full bg-white/5 text-xs font-bold text-cream active:scale-[0.98] disabled:opacity-50"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </Section>

          {status && (
            <p className="mb-4 rounded-2xl border border-white/10 bg-card p-3 text-center text-sm text-cream">
              {status}
            </p>
          )}
        </div>
        )}
      </div>
    </motion.div>
  );
}
