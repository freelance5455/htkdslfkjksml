import { useEffect, useRef, useState } from "react";
import {
  ChevronDown,
  ChevronUp,
  ImagePlus,
  Plus,
  Trash2,
  X
} from "lucide-react";
import imageCompression from "browser-image-compression";
import { MAX_SLIDES } from "../db/db";

/** Compresses a user-picked photo (shared by capture + edit flows). */
export async function compressPhoto(f: File): Promise<Blob> {
  try {
    return (await imageCompression(f, {
      maxSizeMB: 1,
      maxWidthOrHeight: 1600,
      useWebWorker: true
    })) as Blob;
  } catch {
    return f;
  }
}

/** One in-progress carousel page: typed text + newly picked file and/or kept blob. */
export interface DraftSlide {
  key: string;
  text: string;
  file: File | null;
  keep: Blob | null;
}

let keyCounter = 0;

export function newDraftSlide(text = "", keep: Blob | null = null): DraftSlide {
  keyCounter += 1;
  return {
    key: "slide-" + Date.now().toString(36) + "-" + keyCounter,
    text,
    file: null,
    keep
  };
}

interface Props {
  value: DraftSlide[];
  onChange: (next: DraftSlide[]) => void;
}

/**
 * Shared multi-page composer: text + optional photo per extra page, with
 * add/remove/reorder. Previews are owned here (created from files/kept
 * blobs, revoked on replace/remove/unmount) so parents only handle data.
 */
export function SlideEditor({ value, onChange }: Props) {
  const [urls, setUrls] = useState<Map<string, string>>(new Map());
  const urlsRef = useRef(urls);
  urlsRef.current = urls;

  useEffect(() => {
    const cache = new Map(urlsRef.current);
    let changed = false;
    const alive = new Set<string>();
    for (const d of value) {
      const src: Blob | null = d.file ?? d.keep;
      const stamp = d.file
        ? "f" + d.file.name + "-" + d.file.size + "-" + d.file.lastModified
        : "k";
      const id = d.key + ":" + stamp;
      alive.add(id);
      if (src && !cache.has(id)) {
        try {
          cache.set(id, URL.createObjectURL(src));
          changed = true;
        } catch {
          // unreadable blob — page still saves its text
        }
      }
    }
    for (const [id, u] of cache) {
      if (!alive.has(id)) {
        try {
          URL.revokeObjectURL(u);
        } catch {
          // ignore
        }
        cache.delete(id);
        changed = true;
      }
    }
    if (changed) setUrls(new Map(cache));
  }, [value]);

  useEffect(
    () => () => {
      for (const u of urlsRef.current.values()) {
        try {
          URL.revokeObjectURL(u);
        } catch {
          // ignore
        }
      }
    },
    []
  );

  function urlFor(d: DraftSlide): string | null {
    const stamp = d.file
      ? "f" + d.file.name + "-" + d.file.size + "-" + d.file.lastModified
      : "k";
    return urls.get(d.key + ":" + stamp) ?? null;
  }

  function patch(i: number, p: Partial<DraftSlide>) {
    onChange(value.map((d, j) => (j === i ? { ...d, ...p } : d)));
  }

  function move(i: number, dir: -1 | 1) {
    const j = i + dir;
    if (j < 0 || j >= value.length) return;
    const next = [...value];
    const t = next[i];
    next[i] = next[j];
    next[j] = t;
    onChange(next);
  }

  function remove(i: number) {
    onChange(value.filter((_, j) => j !== i));
  }

  return (
    <div className="mt-3 flex flex-col gap-2">
      {value.map((d, i) => {
        const preview = urlFor(d);
        return (
          <div
            key={d.key}
            className="rounded-2xl border border-white/10 bg-void/60 p-3"
          >
            <div className="mb-2 flex items-center gap-1">
              <span className="min-w-0 flex-1 text-[11px] font-bold uppercase tracking-wider text-mist">
                Page {i + 2}
              </span>
              <button
                onClick={() => move(i, -1)}
                disabled={i === 0}
                aria-label="Move page earlier"
                className="flex h-7 w-7 items-center justify-center rounded-full text-mist active:scale-95 disabled:opacity-30"
              >
                <ChevronUp size={15} />
              </button>
              <button
                onClick={() => move(i, 1)}
                disabled={i === value.length - 1}
                aria-label="Move page later"
                className="flex h-7 w-7 items-center justify-center rounded-full text-mist active:scale-95 disabled:opacity-30"
              >
                <ChevronDown size={15} />
              </button>
              <button
                onClick={() => remove(i)}
                aria-label="Remove page"
                className="flex h-7 w-7 items-center justify-center rounded-full text-mist active:scale-95"
              >
                <X size={15} />
              </button>
            </div>
            <textarea
              value={d.text}
              onChange={(e) => patch(i, { text: e.target.value })}
              rows={2}
              placeholder="Page text (optional)…"
              aria-label={"Page " + (i + 2) + " text"}
              className="w-full resize-none rounded-xl border border-white/10 bg-void p-3 text-[14px] leading-relaxed text-cream placeholder:text-mist/70 focus:border-solo focus:outline-none"
            />
            {preview ? (
              <div className="relative mt-2">
                <img
                  src={preview}
                  alt={"Page " + (i + 2) + " photo"}
                  className="max-h-36 w-full rounded-xl object-cover"
                />
                <button
                  onClick={() => patch(i, { file: null, keep: null })}
                  aria-label="Remove page photo"
                  className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/70 text-white active:scale-95"
                >
                  <X size={16} />
                </button>
              </div>
            ) : (
              <label className="mt-2 inline-flex cursor-pointer items-center gap-1.5 rounded-full border border-white/10 bg-void px-3.5 py-2 text-xs font-bold text-mist active:scale-95">
                <ImagePlus size={15} />
                Add photo
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0] ?? null;
                    e.target.value = "";
                    if (f) patch(i, { file: f, keep: null });
                  }}
                />
              </label>
            )}
          </div>
        );
      })}
      {value.length < MAX_SLIDES && (
        <button
          onClick={() => onChange([...value, newDraftSlide()])}
          className="inline-flex h-11 w-full items-center justify-center gap-1.5 rounded-2xl border border-dashed border-white/15 bg-card/50 text-sm font-bold text-cream active:scale-[0.99]"
        >
          <Plus size={16} />
          Add page ({value.length + 1}/{MAX_SLIDES + 1} total)
        </button>
      )}
    </div>
  );
}
