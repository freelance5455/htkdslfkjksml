import { useMemo } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BellOff, ChevronLeft } from "lucide-react";
import { db } from "../db/db";
import { useLiveQuery } from "../hooks";
import { pickResurface, staleNudges } from "../lib/suggest";
import { NudgeCard, ResurfaceCard } from "./Feed";

function daySeed(): string {
  const d = new Date();
  return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
}

export function useActivity() {
  const posts = useLiveQuery(
    () =>
      db.posts
        .where("status")
        .equals("active")
        .toArray()
        .then((rows) => rows.sort((a, b) => b.updatedAt - a.updatedAt)),
    []
  );
  const now = Date.now();
  const all = posts ?? [];
  const resurfaced = useMemo(
    () => pickResurface(all, now, daySeed() + ":activity", 5),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [posts]
  );
  const nudges = useMemo(
    () => staleNudges(all, now, 5),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [posts]
  );
  return {
    loaded: posts !== undefined,
    resurfaced,
    nudges,
    count: resurfaced.length + nudges.length
  };
}

export function Notifications({
  onOpen,
  onBack
}: {
  onOpen: (id: string) => void;
  onBack: () => void;
}) {
  const { loaded, resurfaced, nudges, count } = useActivity();

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-50 bg-void"
      role="dialog"
      aria-modal="true"
      aria-label="Activity and reminders"
    >
      <div className="mx-auto flex h-full max-w-xl flex-col">
        <div className="flex items-center gap-1 border-b border-white/10 px-2 py-2">
          <button
            onClick={onBack}
            aria-label="Back to feed"
            className="flex h-10 w-10 items-center justify-center rounded-full text-cream active:scale-95"
          >
            <ChevronLeft size={22} />
          </button>
          <span className="min-w-0 flex-1">
            <span className="block text-[15px] font-bold text-cream">Activity</span>
            <span className="block truncate text-[11px] text-mist">
              {count === 0 ? "memories and reminders live here" : count + (count === 1 ? " reminder" : " reminders")}
            </span>
          </span>
        </div>

        <div className="flex-1 overflow-y-auto px-4 pb-16 pt-4">
          {!loaded ? (
            <div className="flex flex-col gap-3" aria-label="Loading activity">
              {[0, 1].map((i) => (
                <div key={i} className="h-28 animate-pulse rounded-2xl bg-card" />
              ))}
            </div>
          ) : count === 0 ? (
            <div className="mt-10 flex flex-col items-center gap-3 px-6 text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-solo/15 text-solosoft">
                <BellOff size={26} />
              </span>
              <p className="font-semibold text-cream">All quiet</p>
              <p className="text-sm leading-relaxed text-mist">
                Old memories worth revisiting and posts waiting for a check-in
                will knock here.
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              <AnimatePresence initial={false}>
                {resurfaced.map((r) => (
                  <ResurfaceCard key={"r-" + r.post.id} item={r} onOpen={() => onOpen(r.post.id)} />
                ))}
                {nudges
                  .filter((n) => !resurfaced.some((r) => r.post.id === n.post.id))
                  .map((n) => (
                    <NudgeCard key={"n-" + n.post.id} nudge={n} onOpen={() => onOpen(n.post.id)} />
                  ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
