import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Camera,
  ChevronLeft,
  Hash,
  Image as ImageIcon,
  Loader2,
  MessageCircle,
  Trash2
} from "lucide-react";
import imageCompression from "browser-image-compression";
import { db, hasPhoto, removeSectionCover, setSectionCover, type Post } from "../db/db";
import { useLiveQuery } from "../hooks";
import type { SectionOrder } from "../lib/prefs";
import { fullDate, timeAgo } from "../lib/time";
import { PostCard } from "./PostCard";

export interface Section {
  tag: string;
  count: number;
  updates: number;
  photos: number;
  lastActive: number;
}

export function buildSections(posts: Post[]): Section[] {
  const map = new Map<string, Section>();
  for (const p of posts) {
    for (const t of p.tags) {
      const s = map.get(t) ?? { tag: t, count: 0, updates: 0, photos: 0, lastActive: 0 };
      s.count++;
      s.updates += p.updateCount;
      if (hasPhoto(p)) s.photos++;
      if (p.updatedAt > s.lastActive) s.lastActive = p.updatedAt;
      map.set(t, s);
    }
  }
  return [...map.values()];
}

export function sortSections(sections: Section[], order: SectionOrder): Section[] {
  const arr = [...sections];
  if (order === "count") arr.sort((a, b) => b.count - a.count || b.lastActive - a.lastActive);
  else if (order === "alpha") arr.sort((a, b) => a.tag.localeCompare(b.tag));
  else arr.sort((a, b) => b.lastActive - a.lastActive);
  return arr;
}

const PALETTE = ["#4F46E5", "#E07A5F", "#C9A86A", "#2AA198", "#EE2A7B", "#7C6FF0"];

export function sectionColor(tag: string): string {
  let h = 0;
  for (let i = 0; i < tag.length; i++) h = (h * 31 + tag.charCodeAt(i)) >>> 0;
  return PALETTE[h % PALETTE.length];
}

/** Reactive map of tag -> object URL for custom section covers. */
export function useSectionCoverUrls(): Map<string, string> {
  const rows = useLiveQuery(() => db.sectionCovers.toArray(), []);
  const [urls, setUrls] = useState<Map<string, string>>(() => new Map());
  useEffect(() => {
    const m = new Map<string, string>();
    for (const r of rows ?? []) {
      if (r.coverBlob) {
        try {
          m.set(r.tag, URL.createObjectURL(r.coverBlob));
        } catch {
          // ignore unreadable blob
        }
      }
    }
    setUrls(m);
    return () => {
      for (const u of m.values()) {
        try {
          URL.revokeObjectURL(u);
        } catch {
          // ignore
        }
      }
    };
  }, [rows]);
  return urls;
}

function SectionCircle({
  section,
  coverUrl,
  onOpen
}: {
  section: Section;
  coverUrl?: string | null;
  onOpen: () => void;
}) {
  const color = sectionColor(section.tag);
  const fresh = Date.now() - section.lastActive < 48 * 3600 * 1000;
  const letter = section.tag.slice(0, 1).toUpperCase();
  return (
    <button
      onClick={onOpen}
      aria-label={"Open section " + section.tag}
      className="w-[76px] shrink-0 snap-start active:scale-95"
    >
      <span className="relative mx-auto block w-[72px]">
        {/* Outer story ring: gradient when fresh, flat dark when seen. */}
        <span className={"block rounded-full p-[3px] " + (fresh ? "ig-ring" : "ig-ring-seen")}>
          {/* Opaque void gap — keeps the ring perfectly concentric and stops
              any gradient bleed into the content below. */}
          <span className="block rounded-full bg-void p-[2px]">
            {/* Opaque content disc: cover photo or solid card + letter. */}
            <span className="relative flex h-[60px] w-[60px] items-center justify-center overflow-hidden rounded-full bg-card">
              {coverUrl ? (
                <img
                  src={coverUrl}
                  alt=""
                  draggable={false}
                  className="h-full w-full object-cover"
                />
              ) : (
                <span className="text-[26px] font-bold leading-none" style={{ color }}>
                  {letter}
                </span>
              )}
            </span>
          </span>
        </span>
        {/* Count badge sits on the ring edge; thin void border blends with
            the page background instead of punching a hole in the ring. */}
        <span
          className="absolute -bottom-1 right-0 flex h-6 min-w-[24px] items-center justify-center rounded-full border-2 border-void px-1.5 text-[11px] font-bold text-white shadow-[0_2px_8px_rgba(0,0,0,0.5)]"
          style={{ backgroundColor: color }}
        >
          {section.count}
        </span>
      </span>
      <span className="mt-1.5 block truncate text-center text-[12px] font-semibold leading-tight text-cream">
        {section.tag}
      </span>
      <span className="block truncate text-center text-[11px] leading-tight text-mist">
        {timeAgo(section.lastActive).replace(" ago", "").replace("just now", "now")}
      </span>
    </button>
  );
}

export function SectionsRow({
  sections,
  order,
  onOpen
}: {
  sections: Section[];
  order: SectionOrder;
  onOpen: (tag: string) => void;
}) {
  const sorted = useMemo(() => sortSections(sections, order), [sections, order]);
  const coverUrls = useSectionCoverUrls();
  if (sorted.length === 0) {
    return (
      <div className="mb-4 rounded-2xl border border-dashed border-white/15 bg-card/50 p-4">
        <p className="flex items-center gap-2 text-sm font-semibold text-cream">
          <Hash size={15} className="text-solosoft" />
          Your life, in sections
        </p>
        <p className="mt-1 text-[13px] leading-relaxed text-mist">
          Tag a post with #books, #work or #daily — a living section appears
          here and stays ordered by what you touch most.
        </p>
      </div>
    );
  }
  return (
    <div className="mb-3">
      <div className="no-scrollbar -mx-4 flex snap-x gap-2.5 overflow-x-auto overflow-y-hidden px-4 pb-2 pt-1.5">
        {sorted.slice(0, 20).map((s) => (
          <SectionCircle
            key={s.tag}
            section={s}
            coverUrl={coverUrls.get(s.tag) ?? null}
            onOpen={() => onOpen(s.tag)}
          />
        ))}
      </div>
    </div>
  );
}

function SectionCoverEditor({ tag }: { tag: string }) {
  const key = tag.toLowerCase();
  const row = useLiveQuery(() => db.sectionCovers.get(key), [key]);
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!row?.coverBlob) {
      setPreview(null);
      return;
    }
    let url: string | null = null;
    try {
      url = URL.createObjectURL(row.coverBlob);
      setPreview(url);
    } catch {
      setPreview(null);
    }
    return () => {
      if (url) {
        try {
          URL.revokeObjectURL(url);
        } catch {
          // ignore
        }
      }
    };
  }, [row]);

  async function handleFile(f: File | null) {
    if (!f || busy) return;
    setBusy(true);
    setError(null);
    try {
      let blob: Blob;
      try {
        blob = (await imageCompression(f, {
          maxSizeMB: 0.5,
          maxWidthOrHeight: 512,
          useWebWorker: true
        })) as Blob;
      } catch {
        blob = f;
      }
      await setSectionCover(key, blob);
    } catch (e) {
      console.error("SoloFeed section cover failed:", e);
      setError("Could not save that photo. Try a smaller image.");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function handleRemove() {
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      await removeSectionCover(key);
    } catch (e) {
      console.error("SoloFeed remove cover failed:", e);
      setError("Could not remove the photo. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mb-4 flex items-center gap-3 rounded-2xl border border-white/10 bg-card p-3">
      <span className="relative block h-14 w-14 shrink-0 overflow-hidden rounded-full bg-void">
        {preview ? (
          <img src={preview} alt="" className="h-full w-full object-cover" />
        ) : (
          <span
            className="flex h-full w-full items-center justify-center text-[22px] font-bold"
            style={{ color: sectionColor(key) }}
          >
            {key.slice(0, 1).toUpperCase()}
          </span>
        )}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-semibold text-cream">Section photo</span>
        <span className="block text-xs leading-relaxed text-mist">
          {preview ? "Shown on the circle for #" + tag + "." : "Pick a photo for the #" + tag + " circle."}
        </span>
        {error && <span className="mt-0.5 block text-xs text-clay">{error}</span>}
      </span>
      <span className="flex shrink-0 items-center gap-1.5">
        {preview && (
          <button
            onClick={() => void handleRemove()}
            disabled={busy}
            aria-label="Remove section photo"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-mist active:scale-95 disabled:opacity-50"
          >
            <Trash2 size={16} />
          </button>
        )}
        <button
          onClick={() => fileRef.current?.click()}
          disabled={busy}
          className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full bg-solo px-3.5 py-2 text-xs font-bold text-white active:scale-95 disabled:opacity-50"
        >
          {busy ? <Loader2 size={14} className="animate-spin" /> : <Camera size={14} />}
          {preview ? "Change" : "Add photo"}
        </button>
      </span>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0] ?? null;
          void handleFile(f);
        }}
      />
    </div>
  );
}

export function SectionDetail({
  tag,
  posts,
  onBack,
  onOpen
}: {
  tag: string;
  posts: Post[];
  onBack: () => void;
  onOpen: (id: string) => void;
}) {
  const color = sectionColor(tag);
  const key = tag.toLowerCase();
  const coverRow = useLiveQuery(() => db.sectionCovers.get(key), [key]);
  const [coverUrl, setCoverUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!coverRow?.coverBlob) {
      setCoverUrl(null);
      return;
    }
    let url: string | null = null;
    try {
      url = URL.createObjectURL(coverRow.coverBlob);
      setCoverUrl(url);
    } catch {
      setCoverUrl(null);
    }
    return () => {
      if (url) {
        try {
          URL.revokeObjectURL(url);
        } catch {
          // ignore
        }
      }
    };
  }, [coverRow]);
  const mine = useMemo(
    () =>
      posts
        .filter((p) => p.tags.includes(tag))
        .sort((a, b) => b.updatedAt - a.updatedAt),
    [posts, tag]
  );
  const updates = mine.reduce((n, p) => n + p.updateCount, 0);
  const photos = mine.filter((p) => p.mediaBlob).length;
  const lastActive = mine.reduce((m, p) => Math.max(m, p.updatedAt), 0);

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-50 bg-void"
      role="dialog"
      aria-modal="true"
      aria-label={"Section " + tag}
    >
      <div className="mx-auto flex h-full max-w-xl flex-col">
        <div className="flex items-center gap-2 border-b border-white/10 px-2 py-2">
          <button
            onClick={onBack}
            aria-label="Back to feed"
            className="flex h-10 w-10 items-center justify-center rounded-full text-cream active:scale-95"
          >
            <ChevronLeft size={22} />
          </button>
          <span className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-card">
            {coverUrl ? (
              <img src={coverUrl} alt="" className="h-full w-full object-cover" />
            ) : (
              <span className="text-[18px] font-bold" style={{ color }}>
                {tag.slice(0, 1).toUpperCase()}
              </span>
            )}
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[15px] font-bold text-cream">{tag}</span>
            <span className="block truncate text-[11px] text-mist">
              {mine.length} {mine.length === 1 ? "post" : "posts"} · {updates}{" "}
              {updates === 1 ? "update" : "updates"}
              {photos > 0 ? " · " + photos + " photos" : ""}
            </span>
          </span>
        </div>
        <div className="flex-1 overflow-y-auto px-4 pb-16 pt-4">
          <SectionCoverEditor tag={tag} />
          {lastActive > 0 && (
            <p className="mb-3 flex items-center gap-2 text-[11px] uppercase tracking-wide text-mist">
              <MessageCircle size={12} />
              Last active {timeAgo(lastActive)} · {fullDate(lastActive)}
            </p>
          )}
          {mine.length === 0 ? (
            <p className="mt-8 text-center text-sm text-mist">
              Nothing here yet — capture something with #{tag}.
            </p>
          ) : (
            <div className="flex flex-col gap-8">
              {mine.map((p) => (
                <PostCard key={p.id} post={p} onOpen={() => onOpen(p.id)} />
              ))}
            </div>
          )}
          {photos > 0 && (
            <p className="mt-4 flex items-center gap-1.5 text-xs text-mist">
              <ImageIcon size={13} />
              {photos} {photos === 1 ? "memory" : "memories"} with photos in this section
            </p>
          )}
        </div>
      </div>
    </motion.div>
  );
}
