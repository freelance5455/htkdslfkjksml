import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Award, Image as ImageIcon, MessageCircle, RotateCcw, Trash2 } from "lucide-react";
import { db, deletePost, getSlides, setPostStatus, type Post } from "../db/db";
import { useLiveQuery } from "../hooks";
import { timeAgo } from "../lib/time";

interface Props {
  onOpen: (id: string) => void;
}

function ArchiveRow({ post, onOpen }: { post: Post; onOpen: () => void }) {
  const [confirm, setConfirm] = useState(false);
  const [imgUrl, setImgUrl] = useState<string | null>(null);
  const slides = getSlides(post);
  const hasPhoto = !!post.mediaBlob || slides.some((s) => s.mediaBlob);

  useEffect(() => {
    if (!post.mediaBlob) return;
    const url = URL.createObjectURL(post.mediaBlob);
    setImgUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [post.mediaBlob]);

  useEffect(() => {
    if (!confirm) return;
    const t = window.setTimeout(() => setConfirm(false), 3200);
    return () => window.clearTimeout(t);
  }, [confirm]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97, transition: { duration: 0.2 } }}
      className="overflow-hidden rounded-2xl border border-gold/25 bg-card"
    >
      <button onClick={onOpen} className="block w-full p-4 text-left">
        <div className="flex items-center gap-2 text-gold">
          <Award size={15} />
          <span className="whitespace-nowrap text-xs font-bold uppercase tracking-wider">
            Archived · {timeAgo(post.updatedAt)}
          </span>
        </div>
        <p className="mt-2 line-clamp-3 whitespace-pre-wrap text-[15px] leading-relaxed text-cream">
          {post.content}
        </p>
        {imgUrl && (
          <img
            src={imgUrl}
            alt="Archived memory photo"
            loading="lazy"
            className="mt-3 h-32 w-full rounded-xl object-cover"
          />
        )}
        <div className="mt-2.5 flex items-center gap-3 text-xs text-mist">
          {post.updateCount > 0 && (
            <span className="inline-flex items-center gap-1">
              <MessageCircle size={13} />
              {post.updateCount} {post.updateCount === 1 ? "update" : "updates"}
            </span>
          )}
          {hasPhoto && (
            <span className="inline-flex items-center gap-1">
              <ImageIcon size={13} />
              photo
            </span>
          )}
          {slides.length > 0 && (
            <span className="text-solosoft">
              +{slides.length} {slides.length === 1 ? "page" : "pages"}
            </span>
          )}
          {post.tags.slice(0, 3).map((t) => (
            <span key={t} className="text-solosoft">
              #{t}
            </span>
          ))}
        </div>
      </button>
      <div className="flex gap-2 border-t border-white/5 p-2.5">
        <button
          onClick={() => void setPostStatus(post.id, "active")}
          className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gold/10 py-2 text-xs font-bold text-gold active:scale-[0.98]"
        >
          <RotateCcw size={13} />
          Restore to feed
        </button>
        <button
          onClick={() => {
            if (confirm) void deletePost(post.id);
            else setConfirm(true);
          }}
          className={
            "inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-bold active:scale-[0.98] " +
            (confirm ? "bg-clay/20 text-clay" : "bg-white/5 text-mist")
          }
        >
          <Trash2 size={13} />
          {confirm ? "Tap again to delete" : "Delete forever"}
        </button>
      </div>
    </motion.div>
  );
}

export function Archive({ onOpen }: Props) {
  const posts = useLiveQuery(
    () =>
      db.posts
        .where("status")
        .equals("archived")
        .toArray()
        .then((rows) => rows.sort((a, b) => b.updatedAt - a.updatedAt)),
    []
  );

  if (posts === undefined) {
    return (
      <div className="flex flex-col gap-3" aria-label="Loading archive">
        {[0, 1].map((i) => (
          <div key={i} className="h-40 animate-pulse rounded-2xl bg-card" />
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="mb-4 rounded-2xl border border-gold/25 bg-gradient-to-br from-gold/10 to-transparent p-4">
        <div className="flex items-center gap-2 text-gold">
          <Award size={17} />
          <h2 className="whitespace-nowrap text-sm font-bold uppercase tracking-wider">Your museum</h2>
        </div>
        <p className="mt-1.5 text-sm leading-relaxed text-mist">
          {posts.length === 0
            ? "Completed ideas, reached goals and precious memories will rest here."
            : posts.length === 1
              ? "One memory preserved. Look how far it came."
              : posts.length + " memories preserved. Look how far they came."}
        </p>
      </div>

      {posts.length === 0 ? (
        <div className="mt-6 flex flex-col items-center gap-2 px-6 text-center">
          <p className="font-semibold text-cream">Nothing archived yet</p>
          <p className="text-sm leading-relaxed text-mist">
            Swipe any feed card to the right — or archive it from its detail
            view — and it will be honored here.
          </p>
        </div>
      ) : (
        <motion.div layout className="flex flex-col gap-3">
          <AnimatePresence initial={false}>
            {posts.map((p) => (
              <ArchiveRow key={p.id} post={p} onOpen={() => onOpen(p.id)} />
            ))}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}
