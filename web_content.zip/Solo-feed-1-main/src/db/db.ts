import Dexie, { type Table } from "dexie";

export type PostStatus = "active" | "archived";

export interface Post {
  id: string;
  content: string;
  status: PostStatus;
  tags: string[];
  createdAt: number;
  updatedAt: number;
  updateCount: number;
  mediaBlob: Blob | null;
  /** Extra carousel pages beyond the main content/photo (max 9). */
  slides: Slide[];
}

/** One carousel page: optional text and/or optional photo. */
export interface Slide {
  text: string;
  mediaBlob: Blob | null;
}

/** Max extra slides per post (main content/photo + 9 = 10 pages max). */
export const MAX_SLIDES = 9;

/** Runtime-safe slides (old records predate the field). */
export function getSlides(post: Post): Slide[] {
  return Array.isArray(post.slides) ? post.slides : [];
}

/** Sanitizes user slides: trims, caps text length, drops empties, caps count. */
export function cleanSlides(raw: Slide[]): Slide[] {
  const out: Slide[] = [];
  for (const s of raw) {
    const text = (s.text || "").slice(0, 5000);
    const mediaBlob = s.mediaBlob instanceof Blob ? s.mediaBlob : null;
    if (!text.trim() && !mediaBlob) continue;
    out.push({ text, mediaBlob });
    if (out.length >= MAX_SLIDES) break;
  }
  return out;
}

/** Tags come from the main content AND every slide's text. */
export function extractAllTags(content: string, slides: Slide[]): string[] {
  const joined = [content, ...slides.map((s) => s.text)].join("\n");
  return extractTags(joined);
}

/** True when the post holds any photo (main or slides). */
export function hasPhoto(post: Post): boolean {
  return !!post.mediaBlob || getSlides(post).some((s) => !!s.mediaBlob);
}

/** All readable text: main content + every slide (for AI context/search). */
export function allText(post: Post): string {
  return [post.content, ...getSlides(post).map((s) => s.text)].join("\n");
}

export interface PostUpdate {
  id: string;
  postId: string;
  content: string;
  createdAt: number;
}

export type ChatRole = "user" | "assistant";

export interface ChatThread {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
}

export interface ChatMessage {
  id: string;
  threadId: string;
  role: ChatRole;
  content: string;
  createdAt: number;
}

export interface SectionCover {
  tag: string;
  coverBlob: Blob | null;
  updatedAt: number;
}

export interface AiCreator {
  id: string;
  name: string;
  topic: string;
  emoji: string;
  color: string;
  prompt: string;
  muted: boolean;
  lastSeen: number;
  createdAt: number;
  updatedAt: number;
}

export interface AiPost {
  id: string;
  creatorId: string;
  content: string;
  createdAt: number;
  savedToFeed: boolean;
}

class SoloFeedDB extends Dexie {
  posts!: Table<Post, string>;
  updates!: Table<PostUpdate, string>;
  threads!: Table<ChatThread, string>;
  messages!: Table<ChatMessage, string>;
  sectionCovers!: Table<SectionCover, string>;
  aiCreators!: Table<AiCreator, string>;
  aiPosts!: Table<AiPost, string>;

  constructor() {
    super("solofeed-db");
    this.version(1).stores({
      posts: "&id, status, updatedAt, createdAt, *tags",
      updates: "&id, postId, createdAt"
    });
    // Version 2 adds private AI chat history. Existing posts/updates are
    // untouched by the upgrade.
    this.version(2).stores({
      posts: "&id, status, updatedAt, createdAt, *tags",
      updates: "&id, postId, createdAt",
      threads: "&id, updatedAt, createdAt",
      messages: "&id, threadId, createdAt"
    });
    // Version 3 adds per-section cover images. Everything else untouched.
    this.version(3).stores({
      posts: "&id, status, updatedAt, createdAt, *tags",
      updates: "&id, postId, createdAt",
      threads: "&id, updatedAt, createdAt",
      messages: "&id, threadId, createdAt",
      sectionCovers: "&tag"
    });
    // Version 4 adds the AI Studio: specialized creator personas + the
    // posts they generate. The main feed is untouched by the upgrade.
    this.version(4).stores({
      posts: "&id, status, updatedAt, createdAt, *tags",
      updates: "&id, postId, createdAt",
      threads: "&id, updatedAt, createdAt",
      messages: "&id, threadId, createdAt",
      sectionCovers: "&tag",
      aiCreators: "&id, updatedAt, createdAt",
      aiPosts: "&id, creatorId, createdAt"
    });
    // Version 5 adds carousel slides (extra pages per post). No indexed
    // field changes — old records simply read back with `slides` missing,
    // which getSlides() normalizes to [].
    this.version(5).stores({
      posts: "&id, status, updatedAt, createdAt, *tags",
      updates: "&id, postId, createdAt",
      threads: "&id, updatedAt, createdAt",
      messages: "&id, threadId, createdAt",
      sectionCovers: "&tag",
      aiCreators: "&id, updatedAt, createdAt",
      aiPosts: "&id, creatorId, createdAt"
    });
  }
}

export const db = new SoloFeedDB();

export function uid(): string {
  try {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return crypto.randomUUID();
    }
  } catch {
    // fall through to manual id
  }
  return (
    "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10)
  );
}

const TAG_RE = /#([\p{L}\p{N}_]+)/gu;

export function extractTags(content: string): string[] {
  const found = new Set<string>();
  TAG_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = TAG_RE.exec(content)) !== null) {
    found.add(m[1].toLowerCase());
    if (found.size >= 12) break;
  }
  return [...found];
}

export async function addPost(
  content: string,
  mediaBlob: Blob | null,
  slides: Slide[] = []
): Promise<string> {
  const text = content.trim();
  const clean = cleanSlides(slides);
  if (!text && !mediaBlob && clean.length === 0) throw new Error("Empty post");
  const now = Date.now();
  const id = uid();
  await db.posts.add({
    id,
    content: text,
    status: "active",
    tags: extractAllTags(text, clean),
    createdAt: now,
    updatedAt: now,
    updateCount: 0,
    mediaBlob,
    slides: clean
  });
  return id;
}

/**
 * CRITICAL LOGIC — the Living Post mechanism.
 * Adds the update AND resurrects the parent post: bumps updatedAt to now
 * (so it returns to the top of the Active Feed) and increments updateCount.
 * Done in a single read-write transaction so the two writes stay consistent.
 */
export async function addUpdate(postId: string, content: string): Promise<void> {
  const text = content.trim();
  if (!text) return;
  const now = Date.now();
  await db.transaction("rw", db.posts, db.updates, async () => {
    const post = await db.posts.get(postId);
    if (!post || post.status !== "active") return;
    await db.updates.add({ id: uid(), postId, content: text, createdAt: now });
    await db.posts.update(postId, {
      updatedAt: now,
      updateCount: (post.updateCount || 0) + 1
    });
  });
}

export async function setPostStatus(id: string, status: PostStatus): Promise<void> {
  await db.posts.update(id, { status, updatedAt: Date.now() });
}

export async function updatePostContent(id: string, content: string): Promise<void> {
  const text = content.trim();
  if (!text) return;
  const post = await db.posts.get(id);
  if (!post) return;
  await db.posts.update(id, {
    content: text,
    tags: extractAllTags(text, getSlides(post)),
    updatedAt: Date.now()
  });
}

/** Full edit: main content + carousel slides, tags rebuilt from all text. */
export async function updatePostFull(
  id: string,
  content: string,
  slides: Slide[]
): Promise<void> {
  const text = content.trim();
  const clean = cleanSlides(slides);
  if (!text && clean.length === 0) return;
  const post = await db.posts.get(id);
  if (!post) return;
  await db.posts.update(id, {
    content: text,
    slides: clean,
    tags: extractAllTags(text, clean),
    updatedAt: Date.now()
  });
}

export async function deletePost(id: string): Promise<void> {
  await db.transaction("rw", db.posts, db.updates, async () => {
    await db.updates.where("postId").equals(id).delete();
    await db.posts.delete(id);
  });
}

export async function setSectionCover(tag: string, coverBlob: Blob | null): Promise<void> {
  const key = tag.toLowerCase();
  if (!coverBlob) {
    await db.sectionCovers.delete(key);
    return;
  }
  await db.sectionCovers.put({ tag: key, coverBlob, updatedAt: Date.now() });
}

export async function removeSectionCover(tag: string): Promise<void> {
  await db.sectionCovers.delete(tag.toLowerCase());
}

let seeding: Promise<void> | null = null;

export function seedIfEmpty(): Promise<void> {
  // Guarded against concurrent calls (e.g. StrictMode double-effects in
  // dev): two overlapping runs could both see count 0 and seed twice.
  if (!seeding) {
    seeding = (async () => {
      const count = await db.posts.count();
      if (count > 0) return;
      const now = Date.now();
      const welcomeId = uid();
      const ideaId = uid();
      await db.posts.bulkAdd([
        {
          id: welcomeId,
          content:
            "Welcome to Solo Feed — your private feed. Capture anything in seconds, add updates as it grows, and archive it when it shines. Open this post and add your first update. #start",
          status: "active",
          tags: ["start"],
          createdAt: now - 86400000,
          updatedAt: now - 3600000,
          updateCount: 1,
          mediaBlob: null,
          slides: []
        },
        {
          id: ideaId,
          content: "An idea I refuse to lose: a rooftop garden with morning coffee and slow weekends. #ideas",
          status: "active",
          tags: ["ideas"],
          createdAt: now - 7200000,
          updatedAt: now - 7200000,
          updateCount: 0,
          mediaBlob: null,
          slides: []
        }
      ]);
      await db.updates.add({
        id: uid(),
        postId: welcomeId,
        content: "Day 1: planted the first seed — this very post.",
        createdAt: now - 3600000
      });
    })().finally(() => {
      seeding = null;
    });
  }
  return seeding;
}

// ---------------------------------------------------------------------------
// AI Studio: specialized creator personas + their generated posts.
// ---------------------------------------------------------------------------

export interface AiCreatorSeed {
  name: string;
  topic: string;
  emoji: string;
  color: string;
  prompt: string;
}

export const DEFAULT_AI_CREATORS: AiCreatorSeed[] = [
  {
    name: "Reflectr",
    topic: "book reviews & notes",
    emoji: "🪞",
    color: "#4F46E5",
    prompt:
      "You review books and long reads. Turn one key idea from a great book into a short practical note with a quote-like line and one action."
  },
  {
    name: "Optimist",
    topic: "motivation",
    emoji: "🌻",
    color: "#E8A13D",
    prompt:
      "You reframe hard days with warm optimism. Give one encouraging reframe plus one tiny doable step, never toxic positivity."
  },
  {
    name: "Philosopher",
    topic: "philosophy",
    emoji: "🦊",
    color: "#E07A5F",
    prompt:
      "You think like a philosopher. Take one everyday moment and reveal the deeper question inside it, ending with a question to ponder."
  },
  {
    name: "Comedian",
    topic: "humor",
    emoji: "🎩",
    color: "#7C6FF0",
    prompt:
      "You find the funny side of ordinary life. Write a short witty observation with a punchy last line. Kind humor, never mean."
  },
  {
    name: "Realist",
    topic: "practical realism",
    emoji: "🐭",
    color: "#8b8b93",
    prompt:
      "You are brutally practical. Cut through excuses with plain facts and give the single most realistic next step."
  },
  {
    name: "Skeptic",
    topic: "critical thinking",
    emoji: "🦝",
    color: "#6d6d75",
    prompt:
      "You question claims like a scientist. Take a popular belief, show what is weak about it, and what would actually prove it."
  },
  {
    name: "Analyst",
    topic: "business & money",
    emoji: "🦉",
    color: "#2AA198",
    prompt:
      "You analyze business and money. Explain one money or business idea simply, with numbers when useful and one takeaway."
  },
  {
    name: "Dreamer",
    topic: "creativity & ideas",
    emoji: "🐿️",
    color: "#C9A86A",
    prompt:
      "You dream up possibilities. Offer one vivid future idea or creative scenario and why it is worth imagining today."
  },
  {
    name: "Contrarian",
    topic: "debate",
    emoji: "🦛",
    color: "#EE2A7B",
    prompt:
      "You argue the other side. Take a common opinion, steelman the opposite view in a few sharp lines, then land a fair verdict."
  },
  {
    name: "Explorer",
    topic: "sports & adventure",
    emoji: "🧭",
    color: "#3D9BE8",
    prompt:
      "You live for movement and adventure. Give one sports, outdoors or energy idea with a concrete mini-challenge for today."
  },
  {
    name: "Listener",
    topic: "law & wise advice",
    emoji: "👂",
    color: "#9A8C6B",
    prompt:
      "You give careful, wise counsel like a trusted advisor. Explain one right, rule or life principle simply, with its limits noted."
  }
];

let aiSeeding: Promise<void> | null = null;

/** Seeds the default creator team once. Never wipes user teams. */
export function seedAiCreatorsIfEmpty(): Promise<void> {
  if (!aiSeeding) {
    aiSeeding = (async () => {
      const count = await db.aiCreators.count();
      if (count > 0) return;
      const now = Date.now();
      await db.aiCreators.bulkAdd(
        DEFAULT_AI_CREATORS.map((c, i) => ({
          id: uid(),
          name: c.name,
          topic: c.topic,
          emoji: c.emoji,
          color: c.color,
          prompt: c.prompt,
          muted: false,
          lastSeen: 0,
          createdAt: now + i,
          updatedAt: now + i
        }))
      );
    })().finally(() => {
      aiSeeding = null;
    });
  }
  return aiSeeding;
}

/** Replaces the whole team (used by AI team generation + restore). */
export async function replaceAiCreators(seeds: AiCreatorSeed[]): Promise<void> {
  const now = Date.now();
  await db.transaction("rw", db.aiCreators, db.aiPosts, async () => {
    await db.aiPosts.clear();
    await db.aiCreators.clear();
    await db.aiCreators.bulkAdd(
      seeds.slice(0, 12).map((c, i) => ({
        id: uid(),
        name: c.name.slice(0, 24) || "Creator",
        topic: c.topic.slice(0, 60) || "ideas",
        emoji: c.emoji.slice(0, 8) || "✨",
        color: /^#[0-9a-fA-F]{6}$/.test(c.color) ? c.color : "#4F46E5",
        prompt: c.prompt.slice(0, 800) || "You create short inspiring posts.",
        muted: false,
        lastSeen: 0,
        createdAt: now + i,
        updatedAt: now + i
      }))
    );
  });
}

export async function addAiPost(creatorId: string, content: string): Promise<string> {
  const text = content.trim();
  if (!text) throw new Error("Empty AI post");
  const id = uid();
  await db.aiPosts.add({
    id,
    creatorId,
    content: text.slice(0, 4000),
    createdAt: Date.now(),
    savedToFeed: false
  });
  return id;
}

export async function deleteAiPost(id: string): Promise<void> {
  await db.aiPosts.delete(id);
}

export async function markAiPostSaved(id: string): Promise<void> {
  await db.aiPosts.update(id, { savedToFeed: true });
}

export async function setCreatorMuted(id: string, muted: boolean): Promise<void> {
  await db.aiCreators.update(id, { muted, updatedAt: Date.now() });
}

export async function touchCreatorSeen(id: string): Promise<void> {
  await db.aiCreators.update(id, { lastSeen: Date.now() });
}

/** Slugifies a topic for the #tag appended when saving AI posts to feed. */
export function creatorTag(topic: string): string {
  const s = topic
    .toLowerCase()
    .replace(/[^a-z\u00c0-\u024f\u0370-\u03ff\u0400-\u04ff\u0600-\u06ff\w]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 24);
  return s || "ai";
}
