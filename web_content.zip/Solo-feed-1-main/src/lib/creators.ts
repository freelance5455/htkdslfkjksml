import { buildDigest } from "./ai";
import { generateOneShot } from "./providers";
import type { AiCreatorSeed } from "../db/db";

const KEY = "sf-studio-interests";

export const SUGGESTED_INTERESTS = [
  "philosophy",
  "business",
  "money",
  "books",
  "sports",
  "law",
  "technology",
  "psychology",
  "history",
  "humor"
];

export function loadInterests(): string[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return ["philosophy", "business", "books", "sports"];
    const arr = JSON.parse(raw) as unknown;
    if (Array.isArray(arr)) {
      return arr
        .filter((x): x is string => typeof x === "string")
        .map((x) => x.trim().slice(0, 30))
        .filter((x) => x.length > 0)
        .slice(0, 12);
    }
    return [];
  } catch {
    return ["philosophy", "business", "books", "sports"];
  }
}

export function saveInterests(list: string[]): void {
  try {
    localStorage.setItem(
      KEY,
      JSON.stringify(
        list
          .map((x) => x.trim().slice(0, 30))
          .filter((x) => x.length > 0)
          .slice(0, 12)
      )
    );
  } catch {
    // private mode — interests simply won't persist
  }
}

/**
 * Asks the AI to design a team of specialized content creators from the
 * user's interests. Returns seeds ready for replaceAiCreators().
 */
export async function proposeTeam(
  interests: string[],
  count = 8
): Promise<AiCreatorSeed[]> {
  const digest = await buildDigest(8).catch(() => "(no feed yet)");
  const n = Math.min(12, Math.max(3, count));
  const instruction =
    `You design a team of AI content creators for a private journaling app.\n\n` +
    `USER INTERESTS: ${interests.join(", ") || "general ideas"}\n\n` +
    `USER FEED (for tone, newest last):\n${digest}\n\n` +
    `TASK: Propose exactly ${n} specialized creators, one per interest area. ` +
    `Reply with ONLY a JSON array, no prose, no code fences. Each item: ` +
    `{"name": "short catchy name (1 word, max 12 chars)", ` +
    `"topic": "the field, e.g. philosophy", ` +
    `"emoji": "one single emoji", ` +
    `"color": "one hex color like #4F46E5", ` +
    `"prompt": "2-sentence persona instruction for writing posts in its field"}. ` +
    `Names must be unique. Keep prompts concrete and kind.`;
  const text = await generateOneShot(instruction);
  const parsed = parseTeamJson(text);
  if (parsed.length === 0) throw new Error("empty team");
  return parsed.slice(0, n);
}

function parseTeamJson(text: string): AiCreatorSeed[] {
  try {
    const cleaned = text
      .replace(/```json\s*/gi, "")
      .replace(/```\s*/g, "")
      .trim();
    const start = cleaned.indexOf("[");
    const end = cleaned.lastIndexOf("]");
    if (start < 0 || end <= start) return [];
    const arr = JSON.parse(cleaned.slice(start, end + 1)) as unknown;
    if (!Array.isArray(arr)) return [];
    const out: AiCreatorSeed[] = [];
    for (const raw of arr) {
      if (!raw || typeof raw !== "object") continue;
      const o = raw as Record<string, unknown>;
      const name = String(o.name ?? "").trim().slice(0, 24);
      const topic = String(o.topic ?? "").trim().slice(0, 60);
      const emoji = String(o.emoji ?? "").trim().slice(0, 8);
      const color = String(o.color ?? "").trim();
      const prompt = String(o.prompt ?? "").trim().slice(0, 800);
      if (!name || !topic || !prompt) continue;
      out.push({
        name,
        topic,
        emoji: emoji || "✨",
        color: /^#[0-9a-fA-F]{6}$/.test(color) ? color : "#4F46E5",
        prompt
      });
      if (out.length >= 12) break;
    }
    return out;
  } catch {
    return [];
  }
}

/** Generates one specialized post for a creator, in the user's language. */
export async function generateCreatorPost(
  creator: { name: string; topic: string; prompt: string },
  interests: string[]
): Promise<string> {
  const digest = await buildDigest(8).catch(() => "(no feed yet)");
  const instruction =
    `You are ${creator.name}, a specialized creator in ${creator.topic} inside the user's private journaling app.\n` +
    `PERSONA: ${creator.prompt}\n\n` +
    `USER INTERESTS: ${interests.join(", ") || "general ideas"}\n\n` +
    `USER FEED (for tone, newest last):\n${digest}\n\n` +
    `TASK: Write ONE short post in your field (2-6 sentences, under 600 characters). ` +
    `Make it concrete and original — a thought, mini-story, tip or question, not generic advice. ` +
    `Match the user's language (if interests or feed are Arabic, write Arabic). ` +
    `Output ONLY the post text, no hashtags, no quotes, no preamble.`;
  const text = await generateOneShot(instruction);
  const clean = text.trim().replace(/^["'«»]+|["'«»]+$/g, "").trim();
  if (clean.length < 10) throw new Error("empty post");
  return clean.slice(0, 2000);
}
