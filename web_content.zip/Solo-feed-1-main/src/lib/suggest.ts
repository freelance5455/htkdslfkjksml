import type { Post } from "../db/db";

export type ResurfaceReason = "forgotten" | "onthisday" | "quiet" | "lucky";

export interface Resurfaced {
  post: Post;
  reason: ResurfaceReason;
  label: string;
  detail: string;
}

export interface Nudge {
  post: Post;
  daysStale: number;
}

export function hashSeed(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(a: number): () => number {
  let t = a >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

const DAY = 86400000;

function sameMonthDay(a: number, b: number): boolean {
  const x = new Date(a);
  const y = new Date(b);
  return x.getMonth() === y.getMonth() && x.getDate() === y.getDate();
}

/**
 * Picks a small rotating set of posts worth resurfacing. Deterministic per
 * (day, shuffleCounter) so the feed feels fresh on every visit but stable
 * while scrolling. Never picks posts touched in the last 48h — those already
 * live at the top of the chronological list.
 */
export function pickResurface(
  posts: Post[],
  now: number,
  seedKey: string,
  n = 3
): Resurfaced[] {
  const dayKey = new Date(now).toISOString().slice(0, 10);
  const rand = mulberry32(hashSeed(dayKey + ":" + seedKey));
  const pool = posts.filter((p) => now - p.updatedAt > 2 * DAY);
  if (pool.length === 0) return [];

  const scored = pool.map((p) => {
    const ageDays = (now - p.createdAt) / DAY;
    const staleDays = (now - p.updatedAt) / DAY;
    const onDay = sameMonthDay(p.createdAt, now) && ageDays > 300;
    let score = Math.min(staleDays / 30, 2) + Math.min(ageDays / 120, 1.5);
    if (p.mediaBlob) score += 0.6;
    if (p.updateCount === 0) score += 0.4;
    if (onDay) score += 2.5;
    score *= 0.6 + rand() * 0.8;
    return { p, score, onDay, staleDays };
  });
  scored.sort((a, b) => b.score - a.score);

  const picked: Resurfaced[] = [];
  const used = new Set<string>();
  for (const s of scored) {
    if (picked.length >= n) break;
    if (used.has(s.p.id)) continue;
    used.add(s.p.id);
    const days = Math.max(2, Math.round(s.staleDays));
    if (s.onDay) {
      const years = new Date(now).getFullYear() - new Date(s.p.createdAt).getFullYear();
      picked.push({
        post: s.p,
        reason: "onthisday",
        label: "On this day",
        detail: years >= 1 ? `Started ${years} ${years === 1 ? "year" : "years"} ago today` : "Started on this very date"
      });
    } else if (s.staleDays >= 14) {
      picked.push({
        post: s.p,
        reason: "forgotten",
        label: "Forgotten gem",
        detail: `Quiet for ${days} days — still matters`
      });
    } else if (s.p.updateCount === 0) {
      picked.push({
        post: s.p,
        reason: "quiet",
        label: "Never took off",
        detail: "No updates yet — give it a first breath"
      });
    } else {
      picked.push({
        post: s.p,
        reason: "lucky",
        label: "Worth a revisit",
        detail: `Last touched ${days} days ago`
      });
    }
  }
  return picked;
}

/** Active posts untouched for 7+ days, oldest first — gentle check-in nudges. */
export function staleNudges(posts: Post[], now: number, n = 2): Nudge[] {
  return posts
    .filter((p) => now - p.updatedAt >= 7 * DAY)
    .sort((a, b) => a.updatedAt - b.updatedAt)
    .slice(0, n)
    .map((p) => ({ post: p, daysStale: Math.max(7, Math.round((now - p.updatedAt) / DAY)) }));
}


export const PROMPT_DECK = [
  "What is one small thing that made today better?",
  "Describe a problem you are avoiding in one honest sentence.",
  "What would you attempt if nobody could see you fail?",
  "Write the advice you most need to hear right now.",
  "Which idea of yours deserves ten more minutes today?",
  "What did you change your mind about recently?",
  "Capture a sound, smell or texture from this moment.",
  "What are you carrying that is not yours to hold?",
  "Sketch your ideal ordinary Tuesday.",
  "What made you laugh this week? Preserve it.",
  "Name one thing you know now that last year's you didn't.",
  "If this week had a title, what would it be?"
];

export function dailyPrompt(now: Date): string {
  const start = Date.UTC(now.getFullYear(), 0, 0);
  const dayOfYear = Math.floor((now.getTime() - start) / DAY);
  return PROMPT_DECK[dayOfYear % PROMPT_DECK.length];
}

export function greeting(now: Date): string {
  const h = now.getHours();
  if (h < 5) return "Still up";
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  if (h < 22) return "Good evening";
  return "Late night";
}
