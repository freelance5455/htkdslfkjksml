export type ProviderKind = "perchance" | "openai";

export interface ProviderDef {
  id: string;
  name: string;
  kind: ProviderKind;
  baseUrl: string;
  defaultModel: string;
  models: string[];
  needsKey: boolean;
  keyHint: string;
  note?: string;
  custom?: boolean;
}

/**
 * Popular providers with OpenAI-compatible chat APIs, plus local servers.
 * The built-in Solo provider uses the Perchance AI plugin (no key).
 */
export const PRESETS: ProviderDef[] = [
  {
    id: "perchance",
    name: "Solo · built-in",
    kind: "perchance",
    baseUrl: "",
    defaultModel: "",
    models: [],
    needsKey: false,
    keyHint: "",
    note: "Uses the built-in Perchance AI. No key, nothing to configure."
  },
  {
    id: "openai",
    name: "OpenAI",
    kind: "openai",
    baseUrl: "https://api.openai.com/v1",
    defaultModel: "gpt-4o-mini",
    models: ["gpt-4o-mini", "gpt-4o", "gpt-4.1-mini", "o4-mini"],
    needsKey: true,
    keyHint: "Get a key at platform.openai.com → API keys."
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    kind: "openai",
    baseUrl: "https://api.deepseek.com/v1",
    defaultModel: "deepseek-chat",
    models: ["deepseek-chat", "deepseek-reasoner"],
    needsKey: true,
    keyHint: "Get a key at platform.deepseek.com → API keys."
  },
  {
    id: "groq",
    name: "Groq",
    kind: "openai",
    baseUrl: "https://api.groq.com/openai/v1",
    defaultModel: "llama-3.3-70b-versatile",
    models: [
      "llama-3.3-70b-versatile",
      "llama-3.1-8b-instant",
      "mixtral-8x7b-32768"
    ],
    needsKey: true,
    keyHint: "Get a key at console.groq.com → API Keys."
  },
  {
    id: "openrouter",
    name: "OpenRouter",
    kind: "openai",
    baseUrl: "https://openrouter.ai/api/v1",
    defaultModel: "openai/gpt-4o-mini",
    models: [
      "openai/gpt-4o-mini",
      "anthropic/claude-3.5-haiku",
      "google/gemini-flash-1.5",
      "meta-llama/llama-3.3-70b-instruct"
    ],
    needsKey: true,
    keyHint: "Get a key at openrouter.ai → Keys. One key, hundreds of models."
  },
  {
    id: "together",
    name: "Together",
    kind: "openai",
    baseUrl: "https://api.together.xyz/v1",
    defaultModel: "meta-llama/Llama-3.3-70B-Instruct-Turbo",
    models: [
      "meta-llama/Llama-3.3-70B-Instruct-Turbo",
      "mistralai/Mixtral-8x7B-Instruct-v0.1",
      "Qwen/Qwen2.5-72B-Instruct-Turbo"
    ],
    needsKey: true,
    keyHint: "Get a key at api.together.ai → Settings."
  },
  {
    id: "xai",
    name: "xAI",
    kind: "openai",
    baseUrl: "https://api.x.ai/v1",
    defaultModel: "grok-3-mini",
    models: ["grok-3-mini", "grok-3", "grok-2-1212"],
    needsKey: true,
    keyHint: "Get a key at console.x.ai."
  },
  {
    id: "mistral",
    name: "Mistral",
    kind: "openai",
    baseUrl: "https://api.mistral.ai/v1",
    defaultModel: "mistral-small-latest",
    models: [
      "mistral-small-latest",
      "mistral-medium-latest",
      "mistral-large-latest"
    ],
    needsKey: true,
    keyHint: "Get a key at console.mistral.ai → API keys."
  },
  {
    id: "gemini",
    name: "Google",
    kind: "openai",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai/",
    defaultModel: "gemini-2.0-flash",
    models: ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro"],
    needsKey: true,
    keyHint: "Get a key at aistudio.google.com → Get API key."
  },
  {
    id: "ollama",
    name: "Ollama · local",
    kind: "openai",
    baseUrl: "http://localhost:11434/v1",
    defaultModel: "llama3.1",
    models: ["llama3.1", "mistral", "qwen2.5", "gemma2"],
    needsKey: false,
    keyHint: "",
    note: "Runs on your own computer — free and fully private. Start it with `ollama serve`, and allow browser access via OLLAMA_ORIGINS."
  },
  {
    id: "lmstudio",
    name: "LM Studio · local",
    kind: "openai",
    baseUrl: "http://localhost:1234/v1",
    defaultModel: "local-model",
    models: ["local-model"],
    needsKey: false,
    keyHint: "",
    note: "Runs on your own computer. In LM Studio, load a model and start the local server, then type the exact model name here."
  }
];

export interface CustomDef {
  id: string;
  name: string;
  baseUrl: string;
  defaultModel: string;
}

const ACTIVE_KEY = "sf-ai-provider-active";
const CUSTOMS_KEY = "sf-ai-provider-customs";
const stateKey = (id: string) => "sf-ai-provider-state:" + id;

export interface ProviderState {
  model: string;
  apiKey: string;
  baseUrl: string;
}

export function getCustoms(): CustomDef[] {
  try {
    const raw = localStorage.getItem(CUSTOMS_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as unknown;
    if (!Array.isArray(arr)) return [];
    return arr
      .filter(
        (c): c is CustomDef =>
          !!c &&
          typeof c === "object" &&
          typeof (c as CustomDef).id === "string" &&
          typeof (c as CustomDef).name === "string" &&
          typeof (c as CustomDef).baseUrl === "string"
      )
      .map((c) => ({
        id: c.id,
        name: c.name.slice(0, 40),
        baseUrl: c.baseUrl.slice(0, 200),
        defaultModel: (c.defaultModel || "").slice(0, 120)
      }));
  } catch {
    return [];
  }
}

function storeCustoms(list: CustomDef[]): void {
  try {
    localStorage.setItem(CUSTOMS_KEY, JSON.stringify(list));
  } catch {
    // private mode — customs simply won't persist
  }
}

export function saveCustom(def: CustomDef): void {
  const list = getCustoms();
  const i = list.findIndex((c) => c.id === def.id);
  if (i >= 0) list[i] = def;
  else list.push(def);
  storeCustoms(list.slice(0, 20));
}

export function deleteCustom(id: string): void {
  storeCustoms(getCustoms().filter((c) => c.id !== id));
  try {
    localStorage.removeItem(stateKey(id));
  } catch {
    // ignore
  }
  if (getActiveId() === id) setActiveId("perchance");
}

export function newCustomId(): string {
  return (
    "custom-" +
    Date.now().toString(36) +
    "-" +
    Math.random().toString(36).slice(2, 7)
  );
}

export function allProviders(): ProviderDef[] {
  return [
    ...PRESETS,
    ...getCustoms().map(
      (c): ProviderDef => ({
        id: c.id,
        name: c.name,
        kind: "openai",
        baseUrl: c.baseUrl,
        defaultModel: c.defaultModel,
        models: c.defaultModel ? [c.defaultModel] : [],
        needsKey: true,
        keyHint: "",
        custom: true
      })
    )
  ];
}

export function getDef(id: string): ProviderDef {
  return allProviders().find((p) => p.id === id) ?? PRESETS[0];
}

export function getActiveId(): string {
  try {
    const id = localStorage.getItem(ACTIVE_KEY);
    if (id && allProviders().some((p) => p.id === id)) return id;
    return "perchance";
  } catch {
    return "perchance";
  }
}

export function setActiveId(id: string): void {
  try {
    localStorage.setItem(ACTIVE_KEY, id);
  } catch {
    // ignore
  }
}

export function getState(id: string): ProviderState {
  const def = getDef(id);
  const fallback: ProviderState = {
    model: def.defaultModel,
    apiKey: "",
    baseUrl: def.baseUrl
  };
  try {
    const raw = localStorage.getItem(stateKey(id));
    if (!raw) return fallback;
    const s = JSON.parse(raw) as Partial<ProviderState>;
    return {
      model:
        typeof s.model === "string" && s.model.trim()
          ? s.model.slice(0, 120)
          : fallback.model,
      apiKey: typeof s.apiKey === "string" ? s.apiKey.slice(0, 500) : "",
      baseUrl:
        typeof s.baseUrl === "string" && s.baseUrl.trim()
          ? s.baseUrl.slice(0, 200)
          : fallback.baseUrl
    };
  } catch {
    return fallback;
  }
}

export function setState(id: string, patch: Partial<ProviderState>): void {
  const cur = getState(id);
  try {
    localStorage.setItem(
      stateKey(id),
      JSON.stringify({
        model: (patch.model ?? cur.model).slice(0, 120),
        apiKey: (patch.apiKey ?? cur.apiKey).slice(0, 500),
        baseUrl: (patch.baseUrl ?? cur.baseUrl).slice(0, 200)
      })
    );
  } catch {
    // private mode — settings simply won't persist
  }
}

/** What's missing before this provider can be used (null = ready). */
export function providerMissing(id: string): string | null {
  const def = getDef(id);
  if (def.kind === "perchance") {
    return getRoot() ? null : "Built-in AI is not available in this build.";
  }
  const s = getState(id);
  if (!/^https?:\/\//i.test(s.baseUrl.trim())) return "Add the API base URL.";
  if (!s.model.trim()) return "Pick a model.";
  if (def.needsKey && !s.apiKey.trim()) return "Add your API key.";
  return null;
}

export function isProviderReady(id?: string): boolean {
  try {
    return providerMissing(id ?? getActiveId()) === null;
  } catch {
    return false;
  }
}

function getRoot(): {
  generateText?: (opts: { instruction: string }) => Promise<string>;
} | null {
  try {
    const r = (globalThis as Record<string, unknown>).root as
      | { generateText?: (opts: { instruction: string }) => Promise<string> }
      | undefined;
    if (r && typeof r.generateText === "function") return r;
    return null;
  } catch {
    return null;
  }
}

function friendlyHttp(status: number, detail: string): string {
  if (status === 401 || status === 403)
    return "The API key was rejected (401). Check the key and try again.";
  if (status === 404)
    return "Not found (404) — check the base URL and the model name.";
  if (status === 429)
    return "Rate limited (429). Wait a moment and try again.";
  if (status >= 500)
    return "The provider errored (" + status + "). Try again shortly.";
  return (
    "Request failed (" + status + ")." + (detail ? " " + detail : "")
  );
}

async function completeOpenAI(
  def: ProviderDef,
  s: ProviderState,
  instruction: string,
  signal?: AbortSignal
): Promise<string> {
  const url = s.baseUrl.trim().replace(/\/+$/, "") + "/chat/completions";
  const headers: Record<string, string> = {
    "Content-Type": "application/json"
  };
  if (s.apiKey.trim()) headers["Authorization"] = "Bearer " + s.apiKey.trim();
  if (def.id === "openrouter") {
    try {
      headers["HTTP-Referer"] = window.location.origin;
    } catch {
      // ignore
    }
    headers["X-Title"] = "Solo Feed";
  }
  // 30s ceiling so a hanging server (or wrong URL) fails fast with a clear
  // message instead of spinning forever. Linked to the caller's signal so
  // the Stop button keeps working.
  const ctrl = new AbortController();
  let timedOut = false;
  const timer = window.setTimeout(() => {
    timedOut = true;
    ctrl.abort();
  }, 30000);
  if (signal) {
    if (signal.aborted) ctrl.abort();
    else signal.addEventListener("abort", () => ctrl.abort(), { once: true });
  }
  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers,
      signal: ctrl.signal,
      body: JSON.stringify({
        model: s.model.trim(),
        messages: [{ role: "user", content: instruction }],
        temperature: 0.7,
        max_tokens: 1200
      })
    });
  } catch (e) {
    if (timedOut) {
      throw new Error(
        "The server took too long (30s) — check the base URL and model name, then try again."
      );
    }
    if ((e as Error)?.name === "AbortError") throw e;
    throw new Error(
      "Could not reach the server. Check the URL, your connection, and CORS (local servers must allow browser access)."
    );
  } finally {
    window.clearTimeout(timer);
  }
  if (!res.ok) {
    let detail = "";
    try {
      detail = (await res.text()).slice(0, 200);
    } catch {
      detail = "";
    }
    throw new Error(friendlyHttp(res.status, detail));
  }
  let data: {
    choices?: Array<{ message?: { content?: unknown } }>;
  };
  try {
    data = (await res.json()) as typeof data;
  } catch {
    throw new Error("The server answered in an unexpected format.");
  }
  const text = data?.choices?.[0]?.message?.content;
  if (typeof text !== "string" || !text.trim())
    throw new Error("The model returned an empty reply.");
  return text.trim();
}

/** One full completion through the ACTIVE provider (no streaming). */
export async function generateOneShot(
  instruction: string,
  signal?: AbortSignal
): Promise<string> {
  const id = getActiveId();
  const def = getDef(id);
  if (def.kind === "perchance") {
    const r = getRoot();
    if (!r || !r.generateText) throw new Error("AI unavailable");
    return await r.generateText({ instruction });
  }
  return completeOpenAI(def, getState(id), instruction, signal);
}

/** Sends a tiny probe through a provider and returns the reply (or throws). */
export async function testProvider(id: string): Promise<string> {
  const def = getDef(id);
  if (def.kind === "perchance") {
    if (!getRoot()) throw new Error("Built-in AI is not available in this build.");
    return "Built-in AI is ready.";
  }
  const out = await completeOpenAI(
    def,
    getState(id),
    "Reply with exactly: ok",
    undefined
  );
  return out.length > 120 ? out.slice(0, 120) + "…" : out;
}
