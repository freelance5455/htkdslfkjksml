import { useEffect, useState } from "react";

export type FeedMode = "smart" | "latest";
export type SectionOrder = "recent" | "count" | "alpha";

export interface FeedPrefs {
  feedMode: FeedMode;
  showSections: boolean;
  sectionOrder: SectionOrder;
  showSuggestions: boolean;
}

const KEY = "sf-feed-prefs";

const DEFAULTS: FeedPrefs = {
  feedMode: "smart",
  showSections: true,
  sectionOrder: "recent",
  showSuggestions: true
};

function migrateMode(): FeedMode {
  try {
    if (localStorage.getItem(KEY)) return loadPrefs().feedMode;
    return localStorage.getItem("sf-feed-mode") === "latest" ? "latest" : "smart";
  } catch {
    return "smart";
  }
}

export function loadPrefs(): FeedPrefs {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS, feedMode: migrateMode() };
    const p = JSON.parse(raw) as Partial<FeedPrefs>;
    return {
      feedMode: p.feedMode === "latest" ? "latest" : "smart",
      showSections: p.showSections !== false,
      sectionOrder: p.sectionOrder === "count" || p.sectionOrder === "alpha" ? p.sectionOrder : "recent",
      showSuggestions: p.showSuggestions !== false
    };
  } catch {
    return { ...DEFAULTS };
  }
}

export function savePrefs(next: FeedPrefs): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    // prefs are best-effort
  }
  try {
    window.dispatchEvent(new CustomEvent("sf-prefs"));
  } catch {
    // ignore
  }
}

export function usePrefs(): FeedPrefs {
  const [prefs, setPrefs] = useState<FeedPrefs>(loadPrefs);
  useEffect(() => {
    const refresh = () => setPrefs(loadPrefs());
    window.addEventListener("sf-prefs", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("sf-prefs", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);
  return prefs;
}
