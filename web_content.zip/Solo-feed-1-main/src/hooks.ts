import { useEffect, useState, type DependencyList } from "react";
import { liveQuery } from "dexie";

/**
 * Minimal live-query hook over Dexie. Subscribes to the querier with
 * Dexie's liveQuery (reactive IndexedDB) and re-renders on every change.
 * Returns undefined while the first result is loading.
 */
export function useLiveQuery<T>(querier: () => Promise<T>, deps: DependencyList = []): T | undefined {
  const [value, setValue] = useState<T | undefined>(undefined);

  useEffect(() => {
    let alive = true;
    const subscription = liveQuery(querier).subscribe({
      next: (v) => {
        if (alive) setValue(v);
      },
      error: (err) => {
        console.error("SoloFeed live query error:", err);
      }
    });
    return () => {
      alive = false;
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return value;
}
