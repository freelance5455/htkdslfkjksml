/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        void: "#121212",
        card: "#1E1E1E",
        mist: "#A0A0A0",
        cream: "#F5F5F5",
        solo: "#4F46E5",
        solosoft: "#A5B4FC",
        clay: "#E07A5F",
        gold: "#C9A86A"
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "-apple-system", "sans-serif"]
      }
    }
  },
  plugins: []
};
