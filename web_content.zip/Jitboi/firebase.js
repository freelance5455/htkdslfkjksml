// =====================================================================
// Jitboi — firebase.js
// একমাত্র জায়গা যেখানে Firebase initialize হয়। অন্য সব ফাইল এখান থেকে import করে।
// Firebase JS SDK 12.6.0 (CDN, কোনো build tool লাগে না)
// =====================================================================
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  runTransaction,
  onSnapshot,
  writeBatch,
  increment,
  getCountFromServer
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

export const firebaseConfig = {
  apiKey: "AIzaSyBHq21bQQIYlUZkhBDj9TMY5lwMoaUmurU",
  authDomain: "jitboi.firebaseapp.com",
  projectId: "jitboi",
  storageBucket: "jitboi.firebasestorage.app",
  messagingSenderId: "151764070849",
  appId: "1:151764070849:web:82becb8c0bd0a6c1fabf40",
  measurementId: "G-TP5Z8SCF0X"
};

// শুধু UI নিয়ন্ত্রণের জন্য। আসল সুরক্ষা firestore.rules এ আছে (একই UID সেখানেও দেওয়া আছে)।
export const ADMIN_UID = "laA14CRV9JeV0iVb4J0ESohrTvQ2";

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// ডিফল্ট: লগইন সেশন ব্রাউজারে সংরক্ষিত থাকে
setPersistence(auth, browserLocalPersistence).catch(() => {});

export {
  // Auth
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  // Firestore
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  runTransaction,
  onSnapshot,
  writeBatch,
  increment,
  getCountFromServer
};
