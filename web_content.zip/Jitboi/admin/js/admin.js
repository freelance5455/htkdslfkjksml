// =====================================================================
// Jitboi Admin — admin/js/admin.js
// শেল, অ্যাডমিন গার্ড ও শেয়ার্ড হেল্পার।
// গুরুত্বপূর্ণ: UID যাচাই শুধু UI নিয়ন্ত্রণের জন্য। আসল সুরক্ষা firestore.rules এ।
// =====================================================================
import {
  auth, db, onAuthStateChanged,
  collection, doc, addDoc, setDoc, writeBatch, serverTimestamp
} from '../../firebase.js';
import { $, esc, icon, loaderHtml, loadSettings, errMsg, revId, logout } from '../../js/ui.js';
import { getAccess } from '../../js/access.js';

export const ANAV = [
  ['index.html', 'dashboard', 'ড্যাশবোর্ড', 'grid', null],
  ['tournaments.html', 'tournaments', 'টুর্নামেন্ট', 'trophy', 'tournaments'],
  ['users.html', 'users', 'ইউজার', 'users', 'users'],
  ['deposits.html', 'deposits', 'ডিপোজিট', 'down', 'deposits'],
  ['withdrawals.html', 'withdrawals', 'উইথড্র', 'up', 'withdrawals'],
  ['results.html', 'results', 'ফলাফল', 'award', 'results'],
  ['notifications.html', 'notifications', 'নোটিফিকেশন', 'bell', 'notifications'],
  ['settings.html', 'settings', 'সেটিংস', 'settings', 'settings'],
  ['staff.html', 'staff', 'স্টাফ', 'shield', 'OWNER']
];

const never = () => new Promise(() => {});

function deny(html) {
  document.body.innerHTML = `<div class="blocked"><div class="box"><img src="../assets/icon-192.png" alt="">${html}</div></div><div id="toasts"></div>`;
}

export let access = { owner: false, staff: false, perms: {} };
export const can = (p) => access.owner || !!access.perms[p];

export async function adminBoot(key, title) {
  // যাচাই হওয়া মালিক/স্টাফ না হওয়া পর্যন্ত কিছুই রেন্ডার হয় না (প্যানেলের অস্তিত্বও প্রকাশ পায় না)
  const user = await new Promise((res) => { const un = onAuthStateChanged(auth, (u) => { un(); res(u); }); });
  if (user) access = await getAccess(user.uid);
  if (!user || !access.staff) {
    document.title = '404';
    document.body.className = '';
    document.body.innerHTML = '<div style="font-family:system-ui,sans-serif;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;background:#fff;color:#334155;padding:24px"><div style="font-size:64px;font-weight:700;color:#16a34a">404</div><p style="margin:8px 0 20px">পেজটি খুঁজে পাওয়া যায়নি।</p><a href="../index.html" style="background:#16a34a;color:#fff;padding:12px 22px;border-radius:12px;text-decoration:none;font-weight:600">হোমে ফিরুন</a></div>';
    return never();
  }
  document.body.classList.add('admin');
  document.title = `${title} • Jitboi`;
  const top = $('#topbar');
  top.className = 'topbar';
  top.innerHTML = `<a class="brand" href="index.html"><img src="../assets/icon-192.png" alt="">JITBOI</a><span class="tag">${access.owner ? 'OWNER' : 'STAFF'}</span><div class="spacer"></div>
    <button class="icon-btn" id="aOut" title="লগআউট" aria-label="লগআউট">${icon('logout')}</button>`;
  $('#aOut').addEventListener('click', logout);
  const nav = $('#anav');
  nav.className = 'anav';
  nav.innerHTML = ANAV.filter(([, , , , p]) => !p || (p === 'OWNER' ? access.owner : can(p)))
    .map(([href, k, label, ic]) => `<a href="${href}" class="${k === key ? 'active' : ''}">${icon(ic, 'sm')}<span>${label}</span></a>`).join('');
  const need = ANAV.find((x) => x[1] === key)?.[4];
  if (need && (need === 'OWNER' ? !access.owner : !can(need))) {
    $('#view').innerHTML = `<div class="empty"><div class="ei">${icon('lock', 'lg')}</div><h3>এই কাজের অনুমতি নেই</h3><p>মালিকের কাছে এই পারমিশন চান।</p><div class="mt"><a class="btn" href="index.html">ড্যাশবোর্ড</a></div></div>`;
    return never();
  }
  $('#view').innerHTML = loaderHtml();
  const settings = await loadSettings();
  return { user, settings, view: $('#view'), access };
}

export function setView(html) { const v = $('#view'); v.innerHTML = html; return v; }
export function pageHead(title, sub = '') { return `<div class="page-head"><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}</div>`; }
export function failView(e) {
  setView(`<div class="empty"><div class="ei">${icon('alert', 'lg')}</div><h3>লোড করা যায়নি</h3><p>${esc(errMsg(e))}</p><div class="mt"><button class="btn" onclick="location.reload()">আবার চেষ্টা করুন</button></div></div>`);
}

// অ্যাডমিন অ্যাকশন লগ
export async function logAdmin(action, details = {}) {
  try { await addDoc(collection(db, 'admin_logs'), { adminId: auth.currentUser ? auth.currentUser.uid : '', action, details, createdAt: serverTimestamp() }); } catch { /* লগ ব্যর্থ হলে মূল কাজ থামে না */ }
}

// নতুন-আগে ক্রমে নোটিফিকেশন ডক রেফারেন্স
export const notifRef = () => doc(db, 'notifications', revId());
export const notifData = (userId, title, message) => ({ userId, title, message, read: false, createdAt: serverTimestamp() });

export async function notifyOne(userId, title, message) {
  await setDoc(notifRef(), notifData(userId, title, message));
}
export async function notifyMany(userIds, title, message) {
  const ids = Array.from(new Set(userIds));
  for (let i = 0; i < ids.length; i += 400) {
    const b = writeBatch(db);
    ids.slice(i, i + 400).forEach((u) => b.set(notifRef(), notifData(u, title, message)));
    await b.commit();
  }
  return ids.length;
}
