// =====================================================================
// Jitboi Admin — admin/js/admin-functions.js
// data-page = dashboard | tournaments | users | deposits | withdrawals | results | notifications | settings
//
// সব টাকা-সংক্রান্ত কাজ Firestore Transaction এ হয় এবং স্ট্যাটাস গার্ড দিয়ে ডুপ্লিকেট প্রসেসিং রোধ করা হয়।
// =====================================================================
import {
  auth, db, collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, query, where, orderBy, limit,
  serverTimestamp, runTransaction, writeBatch, increment, getCountFromServer
} from '../../firebase.js';
import {
  $, $$, esc, bn, taka, icon, emptyState, fmtTs, fmtMatch, toast, errMsg, AppError, withLock, openModal, confirmDialog,
  badge, DSTATUS, PSTATUS, tBadge, TSTATUS, GAMES, gameList, safeUrl, initials, winRate, tsToDate
} from '../../js/ui.js';
import {
  adminBoot, setView, pageHead, failView, logAdmin, notifRef, notifData, notifyOne, notifyMany, can, access
} from './admin.js';

const page = document.body.dataset.page;
import { getAccess, PERMS, ALL_PERMS } from '../../js/access.js';
const cnt = async (q) => (await getCountFromServer(q)).data().count;
const ts = (d) => tsToDate(d)?.getTime() || 0;
const pidOf = (tid, uid) => `${tid}_${uid}`;

// =====================================================================
// ড্যাশবোর্ড
// =====================================================================
async function dashboard() {
  await adminBoot('dashboard', 'অ্যাডমিন ড্যাশবোর্ড');
  try {
    const T = collection(db, 'tournaments');
    const g = (perm, q) => (!perm || can(perm) ? cnt(q).catch(() => null) : Promise.resolve(null));
    const [users, tours, active, pd, pw, done, pend] = await Promise.all([
      g('users', collection(db, 'users')),
      cnt(T).catch(() => null),
      cnt(query(T, where('status', 'in', ['upcoming', 'registration_open', 'full', 'live']))).catch(() => null),
      g('deposits', query(collection(db, 'deposits'), where('status', '==', 'pending'))),
      g('withdrawals', query(collection(db, 'withdrawals'), where('status', '==', 'pending'))),
      cnt(query(T, where('status', '==', 'completed'))).catch(() => null),
      g('tournaments', query(collection(db, 'tournament_players'), where('status', '==', 'pending_payment')))
    ]);
    const stat = (label, v, href, hot) => `<a class="stat" href="${href}" style="color:inherit"><div class="label">${label}</div><div class="value ${hot && v > 0 ? 'accent' : ''}">${v === null ? '—' : bn(v)}</div></a>`;
    setView(`${pageHead('ড্যাশবোর্ড', 'প্ল্যাটফর্মের বর্তমান অবস্থা')}
      <div class="grid three">
        ${stat('মোট ইউজার', users, 'users.html')}
        ${stat('মোট টুর্নামেন্ট', tours, 'tournaments.html')}
        ${stat('সক্রিয় টুর্নামেন্ট', active, 'tournaments.html')}
        ${stat('পেন্ডিং ডিপোজিট', pd, 'deposits.html', true)}
        ${stat('পেন্ডিং উইথড্র', pw, 'withdrawals.html', true)}
        ${stat('সমাপ্ত ম্যাচ', done, 'results.html')}
      </div>
      ${pend ? `<div class="notice warn mt">${icon('alert')}<div>${bn(pend)} টি পেইড রেজিস্ট্রেশনের এন্ট্রি ফি যাচাই বাকি আছে। <a href="tournaments.html">টুর্নামেন্টে গিয়ে অংশগ্রহণকারী দেখুন</a>।</div></div>` : ''}
      <div class="section-head"><h2>দ্রুত কাজ</h2></div>
      <div class="menu">
        ${can('tournaments') ? `<a href="tournaments.html">${icon('plus')}<span>নতুন টুর্নামেন্ট তৈরি</span>${icon('chevron', 'chev')}</a>` : ''}
        ${can('deposits') ? `<a href="deposits.html">${icon('down')}<span>ডিপোজিট যাচাই</span>${icon('chevron', 'chev')}</a>` : ''}
        ${can('withdrawals') ? `<a href="withdrawals.html">${icon('up')}<span>উইথড্র প্রসেস</span>${icon('chevron', 'chev')}</a>` : ''}
        ${can('results') ? `<a href="results.html">${icon('award')}<span>ফলাফল প্রকাশ</span>${icon('chevron', 'chev')}</a>` : ''}
        ${can('notifications') ? `<a href="notifications.html">${icon('bell')}<span>নোটিফিকেশন পাঠান</span>${icon('chevron', 'chev')}</a>` : ''}
        ${access.owner ? `<a href="staff.html">${icon('shield')}<span>স্টাফ ও পারমিশন</span>${icon('chevron', 'chev')}</a>` : ''}
      </div>`);
  } catch (e) { failView(e); }
}

// =====================================================================
// টুর্নামেন্ট ম্যানেজমেন্ট
// =====================================================================
async function tournamentsPage() {
  const { settings } = await adminBoot('tournaments', 'টুর্নামেন্ট ম্যানেজমেন্ট');
  const games = gameList(settings);
  let all = [];
  let filter = 'all';

  async function load() {
    const snap = await getDocs(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc'), limit(100)));
    all = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  }

  function render() {
    const list = all.filter((t) => filter === 'all' || t.status === filter);
    const filters = [['all', 'সব'], ...Object.entries(TSTATUS).map(([k, v]) => [k, v[0]])];
    setView(`${pageHead('টুর্নামেন্ট', 'তৈরি, সম্পাদনা ও পরিচালনা')}
      <div class="toolbar"><button class="btn" id="newT">${icon('plus', 'sm')} নতুন টুর্নামেন্ট</button></div>
      <div class="chips mb" id="flt">${filters.map(([k, l]) => `<span class="chip ${filter === k ? 'active' : ''}" data-f="${k}">${l}</span>`).join('')}</div>
      ${list.length ? list.map((t) => `
        <div class="acard" data-id="${esc(t.id)}">
          <div class="head"><div><div class="title">${esc(t.title)}</div><div class="small muted">${esc(t.game)} • ${esc(t.mode || '')} • ${esc(fmtMatch(t))}</div></div>${tBadge(t.status)}</div>
          <div class="row wrap small muted" style="margin-top:8px;gap:14px">
            <span>এন্ট্রি: <b style="color:var(--text)">${t.entryFee > 0 ? taka(t.entryFee) : 'ফ্রি'}</b></span>
            <span>প্রাইজ: <b style="color:var(--accent)">${taka(t.prizePool)}</b></span>
            <span>স্লট: <b style="color:var(--text)">${bn(t.joinedPlayers || 0)}/${bn(t.maxPlayers)}</b></span>
            <span>রুম: <b style="color:var(--text)">${t.roomReleased ? 'প্রকাশিত' : 'অপ্রকাশিত'}</b></span>
          </div>
          <div class="arow">${actionButtons(t)}</div>
        </div>`).join('') : emptyState('কোনো টুর্নামেন্ট নেই', 'উপরের বাটন দিয়ে প্রথম টুর্নামেন্ট তৈরি করুন।', 'trophy')}`);
    $('#newT').addEventListener('click', () => openForm());
    $$('#flt [data-f]').forEach((c) => c.addEventListener('click', () => { filter = c.dataset.f; render(); }));
    $$('.acard [data-act]').forEach((b) => b.addEventListener('click', () => onAction(b.dataset.act, b.closest('.acard').dataset.id, b)));
  }

  function actionButtons(t) {
    const b = (act, label, cls = 'ghost') => `<button class="btn sm ${cls}" data-act="${act}">${label}</button>`;
    const s = t.status;
    const out = [b('players', 'অংশগ্রহণকারী')];
    if (!['completed', 'cancelled'].includes(s)) out.push(b('edit', 'এডিট'));
    if (s === 'upcoming' || s === 'full') out.push(b('open', 'রেজিস্ট্রেশন চালু', ''));
    if (s === 'registration_open') out.push(b('close', 'রেজিস্ট্রেশন বন্ধ', 'warn'));
    if (['upcoming', 'registration_open', 'full'].includes(s)) out.push(b('live', 'লাইভ করুন', ''));
    if (s === 'live') out.push(b('complete', 'সমাপ্ত করুন', ''));
    if (!['completed', 'cancelled'].includes(s)) out.push(b('room', t.roomReleased ? 'রুম তথ্য আপডেট' : 'রুম তথ্য প্রকাশ'));
    if (!['completed', 'cancelled'].includes(s)) out.push(b('cancel', 'বাতিল', 'danger'));
    if (s !== 'live') out.push(b('delete', 'ডিলিট', 'danger'));
    return out.join('');
  }

  async function setStatus(t, status, extra = {}) {
    await updateDoc(doc(db, 'tournaments', t.id), { status, updatedAt: serverTimestamp(), ...extra });
    await logAdmin('tournament_status', { id: t.id, from: t.status, to: status });
  }

  async function onAction(act, id, btn) {
    const t = all.find((x) => x.id === id);
    if (!t) return;
    try {
      if (act === 'edit') return openForm(t);
      if (act === 'players') return openPlayers(t);
      if (act === 'room') return openRoom(t);
      if (act === 'open') {
        if ((t.joinedPlayers || 0) >= t.maxPlayers) throw new AppError('সব স্লট পূর্ণ। আগে সর্বোচ্চ প্লেয়ার সংখ্যা বাড়ান।');
        await withLock(btn, () => setStatus(t, 'registration_open'));
        toast('রেজিস্ট্রেশন চালু হয়েছে।');
      } else if (act === 'close') {
        if (!(await confirmDialog('রেজিস্ট্রেশন বন্ধ করবেন?'))) return;
        await withLock(btn, () => setStatus(t, (t.joinedPlayers || 0) >= t.maxPlayers ? 'full' : 'upcoming'));
        toast('রেজিস্ট্রেশন বন্ধ হয়েছে।');
      } else if (act === 'live') {
        if (!(await confirmDialog('টুর্নামেন্ট লাইভ করবেন? এরপর নতুন রেজিস্ট্রেশন নেওয়া যাবে না।'))) return;
        await withLock(btn, () => setStatus(t, 'live'));
        toast('টুর্নামেন্ট লাইভ।');
      } else if (act === 'complete') {
        if (!(await confirmDialog('টুর্নামেন্ট সমাপ্ত চিহ্নিত করবেন? ফলাফল "ফলাফল" পেজ থেকে প্রকাশ করুন।'))) return;
        await withLock(btn, () => setStatus(t, 'completed'));
        toast('টুর্নামেন্ট সমাপ্ত।');
      } else if (act === 'cancel') {
        await cancelTournament(t, btn);
      } else if (act === 'delete') {
        await deleteTournament(t, btn);
      }
      await load(); render();
    } catch (e) { toast(errMsg(e), 'err'); }
  }

  // ---- বাতিল (ফি ফেরতসহ)
  async function cancelTournament(t, btn) {
    if (!(await confirmDialog(`"${t.title}" বাতিল করবেন? এটি ফেরানো যায় না।`, { danger: true, okText: 'বাতিল করুন' }))) return;
    await withLock(btn, async () => {
      await setStatus(t, 'cancelled');
      const ps = await getDocs(query(collection(db, 'tournament_players'), where('tournamentId', '==', t.id)));
      const paid = ps.docs.filter((d) => d.data().feeCharged && !d.data().refunded);
      let refunded = 0;
      if (paid.length && (await confirmDialog(`${bn(paid.length)} জনের এন্ট্রি ফি কাটা হয়েছে। সবাইকে এখনই ওয়ালেটে ফেরত দেবেন?`, { okText: 'ফেরত দিন', cancelText: 'পরে' }))) {
        for (const d of paid) {
          try { await refundParticipant(t, d.id); refunded++; } catch (e) { toast(errMsg(e), 'err'); }
        }
      }
      // অনিষ্পন্ন পেইড অনুরোধ বাতিল
      for (const d of ps.docs.filter((x) => x.data().status === 'pending_payment')) {
        await updateDoc(d.ref, { status: 'rejected', reviewedAt: serverTimestamp() });
      }
      await notifyMany(ps.docs.map((d) => d.data().userId), 'টুর্নামেন্ট বাতিল', `"${t.title}" বাতিল করা হয়েছে।${refunded ? ' আপনার এন্ট্রি ফি ওয়ালেটে ফেরত দেওয়া হয়েছে।' : ''}`);
      await logAdmin('tournament_cancel', { id: t.id, refunded });
    });
    toast('টুর্নামেন্ট বাতিল হয়েছে।');
  }

  async function refundParticipant(t, pid) {
    await runTransaction(db, async (tx) => {
      const pRef = doc(db, 'tournament_players', pid);
      const pS = await tx.get(pRef);
      if (!pS.exists() || !pS.data().feeCharged || pS.data().refunded) throw new AppError('ইতোমধ্যে ফেরত দেওয়া হয়েছে।');
      const p = pS.data();
      const uRef = doc(db, 'users', p.userId);
      const uS = await tx.get(uRef);
      const trRef = doc(db, 'transactions', `refund_${pid}`);
      const trS = await tx.get(trRef);
      if (trS.exists()) throw new AppError('রিফান্ড আগেই প্রসেস হয়েছে।');
      tx.update(uRef, { balance: Number(uS.data().balance || 0) + Number(p.entryFee) });
      tx.update(pRef, { refunded: true, status: 'rejected' });
      tx.set(trRef, { userId: p.userId, type: 'refund', amount: Number(p.entryFee), status: 'completed', tournamentId: t.id, note: t.title, createdAt: serverTimestamp() });
    });
  }

  async function deleteTournament(t, btn) {
    const ps = await getDocs(query(collection(db, 'tournament_players'), where('tournamentId', '==', t.id), limit(1)));
    if (!ps.empty) throw new AppError('এই টুর্নামেন্টে অংশগ্রহণকারী আছে, তাই ডিলিট করা যাবে না। বরং "বাতিল" করুন।');
    if (!(await confirmDialog(`"${t.title}" স্থায়ীভাবে ডিলিট করবেন?`, { danger: true, okText: 'ডিলিট' }))) return;
    await withLock(btn, async () => {
      try { await deleteDoc(doc(db, 'tournaments', t.id, 'private', 'room')); } catch { /* নেই */ }
      await deleteDoc(doc(db, 'tournaments', t.id));
      await logAdmin('tournament_delete', { id: t.id, title: t.title });
    });
    toast('টুর্নামেন্ট ডিলিট হয়েছে।');
  }

  // ---- তৈরি / এডিট ফর্ম
  function parsePrizes(text) {
    const out = [];
    for (const line of text.split('\n').map((l) => l.trim()).filter(Boolean)) {
      const m = line.match(/^(\d+)\s*[:=\-]\s*(\d+(?:\.\d+)?)$/);
      if (!m) throw new AppError(`প্রাইজ লাইন সঠিক নয়: "${line}" (ফরম্যাট: ১:৩০০)`);
      out.push({ position: Number(m[1]), amount: Number(m[2]) });
    }
    return out.sort((a, b) => a.position - b.position);
  }

  function openForm(t = null) {
    const edit = !!t;
    const v = (k, d = '') => esc(t && t[k] !== undefined ? t[k] : d);
    const prizeText = edit && Array.isArray(t.prizes) ? t.prizes.map((p) => `${p.position}:${p.amount}`).join('\n') : '';
    const gameOpts = Array.from(new Set([...games, ...(t ? [t.game] : [])]));
    openModal(`
      <h3>${edit ? 'টুর্নামেন্ট এডিট' : 'নতুন টুর্নামেন্ট'}</h3>
      <div id="terr" class="form-error hidden"></div>
      <form id="tform" novalidate>
        <div class="field"><label>টুর্নামেন্টের নাম</label><input class="input" id="fTitle" maxlength="80" value="${v('title')}"></div>
        <div class="grid2">
          <div class="field"><label>গেম</label><select class="input" id="fGame">${gameOpts.map((g) => `<option ${t && t.game === g ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select></div>
          <div class="field"><label>মোড</label><input class="input" id="fMode" list="modes" maxlength="30" value="${v('mode', 'Solo')}"><datalist id="modes"><option>Solo</option><option>Duo</option><option>Squad</option><option>1v1</option></datalist></div>
          <div class="field"><label>এন্ট্রি ফি (৳) — ফ্রি হলে ০</label><input class="input" id="fFee" type="number" min="0" step="1" inputmode="numeric" value="${v('entryFee', 0)}"></div>
          <div class="field"><label>প্রাইজ পুল (৳)</label><input class="input" id="fPrize" type="number" min="0" step="1" inputmode="numeric" value="${v('prizePool', 0)}"></div>
          <div class="field"><label>পার কিল প্রাইজ (৳, না থাকলে ০)</label><input class="input" id="fKill" type="number" min="0" step="1" inputmode="numeric" value="${v('perKill', 0)}"></div>
          <div class="field"><label>ভার্সন</label><select class="input" id="fVer"><option value="" ${!t || !t.version ? 'selected' : ''}>—</option><option ${t && t.version === 'TPP' ? 'selected' : ''}>TPP</option><option ${t && t.version === 'FPP' ? 'selected' : ''}>FPP</option></select></div>
          <div class="field"><label>ম্যাপ (ঐচ্ছিক)</label><input class="input" id="fMap" list="maps" maxlength="30" value="${v('map')}"><datalist id="maps"><option>Bermuda</option><option>Purgatory</option><option>Kalahari</option><option>Alpine</option><option>Erangel</option><option>Miramar</option><option>Sanhok</option></datalist></div>
          <div class="field"><label>সর্বোচ্চ প্লেয়ার</label><input class="input" id="fMax" type="number" min="2" max="1000" step="1" inputmode="numeric" value="${v('maxPlayers', 48)}"></div>
          ${edit ? '' : `<div class="field"><label>শুরুর স্ট্যাটাস</label><select class="input" id="fStatus"><option value="upcoming">আসন্ন (রেজিস্ট্রেশন বন্ধ)</option><option value="registration_open">রেজিস্ট্রেশন চালু</option></select></div>`}
          <div class="field"><label>ম্যাচের তারিখ</label><input class="input" id="fDate" type="date" value="${v('matchDate')}"></div>
          <div class="field"><label>ম্যাচের সময়</label><input class="input" id="fTime" type="time" value="${v('matchTime', '20:00')}"></div>
        </div>
        <div class="field"><label>ছবির লিংক (ঐচ্ছিক, https://...)</label><input class="input" id="fImg" type="url" value="${v('imageUrl')}"></div>
        <div class="field"><label>বিবরণ</label><textarea class="input" id="fDesc" maxlength="1500">${v('description')}</textarea></div>
        <div class="field"><label>নিয়মাবলী (প্রতি লাইনে একটি; ফাঁকা রাখলে ডিফল্ট দেখাবে)</label><textarea class="input" id="fRules" maxlength="2500">${v('rules')}</textarea></div>
        <div class="field"><label>প্রাইজ বণ্টন (প্রতি লাইনে "স্থান:টাকা", যেমন ১:৩০০)</label><textarea class="input" id="fPrizes" placeholder="1:300&#10;2:150&#10;3:50">${esc(prizeText)}</textarea></div>
        <label class="check" style="margin-bottom:14px"><input type="checkbox" id="fFeat" ${t && t.featured ? 'checked' : ''}> হোমে ফিচার্ড হিসেবে দেখান</label>
        <div class="actions"><button type="button" class="btn ghost" data-x>বাতিল</button><button class="btn" id="fSave" type="submit">${edit ? 'সংরক্ষণ' : 'তৈরি করুন'}</button></div>
      </form>`, {
      onMount: (m, close) => {
        m.querySelector('[data-x]').addEventListener('click', close);
        m.querySelector('#tform').addEventListener('submit', async (e) => {
          e.preventDefault();
          const g = (id) => m.querySelector(id);
          const err = (msg) => { const b = g('#terr'); b.textContent = msg; b.classList.remove('hidden'); b.scrollIntoView({ block: 'center' }); };
          const title = g('#fTitle').value.trim();
          const entryFee = Number(g('#fFee').value);
          const prizePool = Number(g('#fPrize').value);
          const maxPlayers = Number(g('#fMax').value);
          const perKill = Number(g('#fKill').value || 0);
          const matchDate = g('#fDate').value;
          const matchTime = g('#fTime').value;
          const imageUrl = g('#fImg').value.trim();
          if (title.length < 3) return err('টুর্নামেন্টের নাম কমপক্ষে ৩ অক্ষর হতে হবে।');
          if (!Number.isInteger(entryFee) || entryFee < 0) return err('এন্ট্রি ফি সঠিক নয়।');
          if (!Number.isFinite(prizePool) || prizePool < 0) return err('প্রাইজ পুল সঠিক নয়।');
          if (!Number.isFinite(perKill) || perKill < 0) return err('পার কিল প্রাইজ সঠিক নয়।');
          if (!Number.isInteger(maxPlayers) || maxPlayers < 2 || maxPlayers > 1000) return err('সর্বোচ্চ প্লেয়ার ২–১০০০ এর মধ্যে হতে হবে।');
          if (edit && maxPlayers < (t.joinedPlayers || 0)) return err('সর্বোচ্চ প্লেয়ার বর্তমান যোগদানকারীর চেয়ে কম হতে পারে না।');
          if (!matchDate) return err('ম্যাচের তারিখ দিন।');
          if (!matchTime) return err('ম্যাচের সময় দিন।');
          if (imageUrl && !safeUrl(imageUrl)) return err('ছবির লিংক সঠিক নয় (https:// দিয়ে শুরু হতে হবে)।');
          let prizes;
          try { prizes = parsePrizes(g('#fPrizes').value); } catch (ex) { return err(errMsg(ex)); }
          if (prizes.reduce((s, p) => s + p.amount, 0) > prizePool) return err('প্রাইজ বণ্টনের মোট টাকা প্রাইজ পুলের চেয়ে বেশি।');
          const data = {
            title, game: g('#fGame').value, mode: g('#fMode').value.trim() || 'Solo', perKill, version: g('#fVer').value, map: g('#fMap').value.trim(),
            entryFee, prizePool, maxPlayers, matchDate, matchTime,
            description: g('#fDesc').value.trim(), imageUrl, rules: g('#fRules').value.trim(), prizes,
            featured: g('#fFeat').checked, updatedAt: serverTimestamp()
          };
          await withLock(g('#fSave'), async () => {
            try {
              if (edit) {
                if (entryFee !== t.entryFee && (t.joinedPlayers || 0) > 0) return err('অংশগ্রহণকারী থাকলে এন্ট্রি ফি বদলানো যাবে না।');
                await updateDoc(doc(db, 'tournaments', t.id), data);
                await logAdmin('tournament_edit', { id: t.id });
              } else {
                const ref = doc(collection(db, 'tournaments'));
                await setDoc(ref, {
                  ...data, status: g('#fStatus').value, joinedPlayers: 0, roomReleased: false,
                  resultsPublished: false, results: [], createdAt: serverTimestamp()
                });
                await logAdmin('tournament_create', { id: ref.id, title });
              }
              close(); toast(edit ? 'টুর্নামেন্ট আপডেট হয়েছে।' : 'টুর্নামেন্ট তৈরি হয়েছে।');
              await load(); render();
            } catch (ex) { err(errMsg(ex)); }
          });
        });
      }
    });
  }

  // ---- রুম তথ্য প্রকাশ (আলাদা private ডকুমেন্টে)
  async function openRoom(t) {
    let cur = {};
    try { const s = await getDoc(doc(db, 'tournaments', t.id, 'private', 'room')); if (s.exists()) cur = s.data(); } catch { /* নেই */ }
    openModal(`<h3>রুম তথ্য</h3><p class="muted small mb">শুধু নিশ্চিত রেজিস্টার্ড খেলোয়াড়রা প্রকাশের পর এটি দেখতে পাবে।</p>
      <div id="rerr" class="form-error hidden"></div>
      <form id="rform" novalidate>
        <div class="field"><label>রুম আইডি</label><input class="input" id="rId" maxlength="40" value="${esc(cur.roomId || '')}"></div>
        <div class="field"><label>রুম পাসওয়ার্ড</label><input class="input" id="rPw" maxlength="40" value="${esc(cur.roomPassword || '')}"></div>
        <div class="actions">${t.roomReleased ? '<button type="button" class="btn danger" id="rHide">লুকান</button>' : '<button type="button" class="btn ghost" data-x>বাতিল</button>'}<button class="btn" id="rSave" type="submit">প্রকাশ করুন</button></div>
      </form>`, {
      onMount: (m, close) => {
        const x = m.querySelector('[data-x]'); if (x) x.addEventListener('click', close);
        const hide = m.querySelector('#rHide');
        if (hide) hide.addEventListener('click', () => withLock(hide, async () => {
          try {
            await setDoc(doc(db, 'tournaments', t.id, 'private', 'room'), { released: false, updatedAt: serverTimestamp() }, { merge: true });
            await updateDoc(doc(db, 'tournaments', t.id), { roomReleased: false, updatedAt: serverTimestamp() });
            await logAdmin('room_hide', { id: t.id });
            close(); toast('রুম তথ্য লুকানো হয়েছে।'); await load(); render();
          } catch (ex) { toast(errMsg(ex), 'err'); }
        }));
        m.querySelector('#rform').addEventListener('submit', async (e) => {
          e.preventDefault();
          const roomId = m.querySelector('#rId').value.trim();
          const roomPassword = m.querySelector('#rPw').value.trim();
          if (!roomId) { const b = m.querySelector('#rerr'); b.textContent = 'রুম আইডি দিন।'; b.classList.remove('hidden'); return; }
          await withLock(m.querySelector('#rSave'), async () => {
            try {
              await setDoc(doc(db, 'tournaments', t.id, 'private', 'room'), { roomId, roomPassword, released: true, updatedAt: serverTimestamp() });
              await updateDoc(doc(db, 'tournaments', t.id), { roomReleased: true, updatedAt: serverTimestamp() });
              const ps = await getDocs(query(collection(db, 'tournament_players'), where('tournamentId', '==', t.id)));
              const uids = ps.docs.filter((d) => d.data().status === 'registered').map((d) => d.data().userId);
              if (!t.roomReleased) await notifyMany(uids, 'রুম আইডি প্রকাশিত', `"${t.title}" এর রুম আইডি ও পাসওয়ার্ড "আমার গেম" পেজে দেখুন।`);
              await logAdmin('room_release', { id: t.id });
              close(); toast('রুম তথ্য প্রকাশিত হয়েছে।'); await load(); render();
            } catch (ex) { const b = m.querySelector('#rerr'); b.textContent = errMsg(ex); b.classList.remove('hidden'); }
          });
        });
      }
    });
  }

  // ---- অংশগ্রহণকারী
  async function openPlayers(t) {
    const close = openModal(`<h3>অংশগ্রহণকারী</h3><div id="plist"><div class="loader"><span class="spin"></span></div></div><div class="actions"><button class="btn ghost" data-x>বন্ধ করুন</button></div>`, {
      onMount: (m, cl) => m.querySelector('[data-x]').addEventListener('click', cl)
    });
    async function paint() {
      const box = $('#plist');
      if (!box) return;
      try {
        const snap = await getDocs(query(collection(db, 'tournament_players'), where('tournamentId', '==', t.id)));
        const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => ts(a.joinedAt) - ts(b.joinedAt));
        box.innerHTML = rows.length ? `<p class="small muted mb">মোট ${bn(rows.length)} জন (নিশ্চিত: ${bn(rows.filter((r) => r.status === 'registered').length)})</p><div class="list">${rows.map((p) => `
          <div class="item" style="align-items:flex-start"><div class="grow">
            <div class="t">${esc(p.playerName)} ${badge(PSTATUS, p.status)}</div>
            <div class="s">গেম ID: <span class="mono">${esc(p.playerId)}</span>${p.teamName ? ' • টিম: ' + esc(p.teamName) : ''}</div>
            <div class="s">অ্যাকাউন্ট: ${esc(p.userName || '')} • ${esc(fmtTs(p.joinedAt))}</div>
            ${p.status === 'pending_payment' ? `<div class="arow" style="margin-top:8px"><button class="btn sm" data-ok="${esc(p.id)}">ফি কেটে নিশ্চিত করুন (${taka(p.entryFee)})</button><button class="btn sm danger" data-no="${esc(p.id)}">বাতিল</button></div>` : ''}
          </div></div>`).join('')}</div>` : emptyState('এখনো কেউ যোগ দেয়নি', '', 'users');
        $$('[data-ok]', box).forEach((b) => b.addEventListener('click', () => confirmPaid(b, b.dataset.ok)));
        $$('[data-no]', box).forEach((b) => b.addEventListener('click', () => rejectPending(b, b.dataset.no)));
      } catch (e) { box.innerHTML = `<div class="form-error">${esc(errMsg(e))}</div>`; }
    }
    async function confirmPaid(btn, pid) {
      if (!(await confirmDialog('ইউজারের ওয়ালেট থেকে এন্ট্রি ফি কেটে রেজিস্ট্রেশন নিশ্চিত করবেন?', { okText: 'নিশ্চিত করুন' }))) return;
      await withLock(btn, async () => {
        try {
          await runTransaction(db, async (tx) => {
            const tRef = doc(db, 'tournaments', t.id);
            const pRef = doc(db, 'tournament_players', pid);
            const [tS, pS] = await Promise.all([tx.get(tRef), tx.get(pRef)]);
            if (!pS.exists() || pS.data().status !== 'pending_payment') throw new AppError('এই অনুরোধটি ইতোমধ্যে প্রসেস হয়েছে।');
            const cur = tS.data(); const p = pS.data();
            if (['completed', 'cancelled'].includes(cur.status)) throw new AppError('টুর্নামেন্টটি আর সক্রিয় নেই।');
            const joined = cur.joinedPlayers || 0;
            if (joined >= cur.maxPlayers) throw new AppError('সব স্লট পূর্ণ।');
            const uRef = doc(db, 'users', p.userId);
            const uS = await tx.get(uRef);
            const bal = Number(uS.data().balance || 0);
            const winBal = Number(uS.data().winBalance || 0);
            const fee = Number(p.entryFee || 0);
            if (bal + winBal < fee) throw new AppError('ইউজারের পর্যাপ্ত ব্যালেন্স নেই।');
            const fromDeposit = Math.min(bal, fee);
            const n = joined + 1;
            tx.update(uRef, { balance: bal - fromDeposit, winBalance: winBal - (fee - fromDeposit) });
            tx.update(pRef, { status: 'registered', feeCharged: true, confirmedAt: serverTimestamp() });
            tx.update(tRef, { joinedPlayers: n, ...(n >= cur.maxPlayers && cur.status === 'registration_open' ? { status: 'full' } : {}) });
            tx.set(doc(db, 'transactions', `entry_${pid}`), { userId: p.userId, type: 'entry', amount: fee, status: 'completed', tournamentId: t.id, note: cur.title, createdAt: serverTimestamp() });
            tx.set(notifRef(), notifData(p.userId, 'রেজিস্ট্রেশন নিশ্চিত', `"${cur.title}" এ আপনার রেজিস্ট্রেশন নিশ্চিত হয়েছে। এন্ট্রি ফি ${taka(fee)} কাটা হয়েছে।`));
          });
          await logAdmin('entry_confirm', { tournamentId: t.id, pid });
          toast('রেজিস্ট্রেশন নিশ্চিত হয়েছে।');
          await load(); await paint();
        } catch (e) { toast(errMsg(e), 'err'); }
      });
    }
    async function rejectPending(btn, pid) {
      if (!(await confirmDialog('এই রেজিস্ট্রেশন অনুরোধ বাতিল করবেন?', { danger: true }))) return;
      await withLock(btn, async () => {
        try {
          await runTransaction(db, async (tx) => {
            const pRef = doc(db, 'tournament_players', pid);
            const pS = await tx.get(pRef);
            if (!pS.exists() || pS.data().status !== 'pending_payment') throw new AppError('এই অনুরোধটি ইতোমধ্যে প্রসেস হয়েছে।');
            tx.update(pRef, { status: 'rejected', reviewedAt: serverTimestamp() });
            tx.set(notifRef(), notifData(pS.data().userId, 'রেজিস্ট্রেশন বাতিল', `"${t.title}" এ আপনার রেজিস্ট্রেশন অনুরোধ গৃহীত হয়নি।`));
          });
          toast('অনুরোধ বাতিল হয়েছে।'); await paint();
        } catch (e) { toast(errMsg(e), 'err'); }
      });
    }
    void close;
    paint();
  }

  try { await load(); render(); } catch (e) { failView(e); }
}

// =====================================================================
// ইউজার ম্যানেজমেন্ট
// =====================================================================
async function usersPage() {
  await adminBoot('users', 'ইউজার ম্যানেজমেন্ট');
  try {
    let users = [];
    const snap = await getDocs(query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(300)));
    users = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    let q = '';

    function render() {
      const s = q.trim().toLowerCase();
      const list = s ? users.filter((u) => `${u.name} ${u.email} ${u.id}`.toLowerCase().includes(s)) : users;
      setView(`${pageHead('ইউজার', `মোট ${bn(users.length)} জন (সর্বশেষ ৩০০ জন দেখানো হচ্ছে)`)}
        <div class="toolbar"><input class="input" id="q" placeholder="নাম, ইমেইল বা UID দিয়ে খুঁজুন" value="${esc(q)}"></div>
        ${list.length ? `<div class="table-wrap"><table class="tbl"><thead><tr><th>নাম</th><th>ইমেইল</th><th>ডিপোজিট</th><th>উইনিং</th><th>ম্যাচ/জয়</th><th>স্ট্যাটাস</th><th></th></tr></thead><tbody>
          ${list.map((u) => `<tr><td>${esc(u.name)}</td><td class="small">${esc(u.email)}</td><td class="num">${taka(u.balance)}</td><td class="num">${taka(u.winBalance || 0)}</td><td>${bn(u.totalMatches || 0)}/${bn(u.totalWins || 0)}</td>
          <td><span class="badge ${u.status === 'active' ? 'green' : 'red'}">${u.status === 'active' ? 'সক্রিয়' : 'স্থগিত'}</span></td>
          <td><button class="btn sm ghost" data-view="${esc(u.id)}">দেখুন</button></td></tr>`).join('')}</tbody></table></div>` : emptyState('কোনো ইউজার পাওয়া যায়নি', '', 'users')}`);
      const qi = $('#q');
      qi.addEventListener('input', () => { q = qi.value; const pos = qi.selectionStart; render(); const n = $('#q'); n.focus(); n.setSelectionRange(pos, pos); });
      $$('[data-view]').forEach((b) => b.addEventListener('click', () => openUser(b.dataset.view)));
    }

    function openBonus(u) {
      openModal(`<h3>বোনাস দিন — ${esc(u.name)}</h3><p class="muted small mb">ডিপোজিট ওয়ালেটে যোগ হবে এবং লেনদেনে "বোনাস" হিসেবে দেখাবে (যেমন রেফার বোনাস)।</p>
        <div id="berr" class="form-error hidden"></div>
        <form id="bform" novalidate><div class="field"><label>টাকার পরিমাণ (৳)</label><input class="input" id="bAmt" type="number" min="1" max="5000" step="1" inputmode="numeric"></div>
        <div class="field"><label>কারণ / নোট</label><input class="input" id="bNote" maxlength="80" value="রেফার বোনাস"></div>
        <div class="actions"><button type="button" class="btn ghost" data-x>বাতিল</button><button class="btn" id="bOk" type="submit">বোনাস দিন</button></div></form>`, {
        onMount: (m, close) => {
          m.querySelector('[data-x]').addEventListener('click', close);
          m.querySelector('#bform').addEventListener('submit', async (e) => {
            e.preventDefault();
            const amt = Number(m.querySelector('#bAmt').value); const note = m.querySelector('#bNote').value.trim() || 'বোনাস';
            const err = (t) => { const b = m.querySelector('#berr'); b.textContent = t; b.classList.remove('hidden'); };
            if (!Number.isInteger(amt) || amt < 1 || amt > 5000) return err('১ থেকে ৫০০০ এর মধ্যে সঠিক পরিমাণ দিন।');
            await withLock(m.querySelector('#bOk'), async () => {
              try {
                await runTransaction(db, async (tx) => {
                  const uRef = doc(db, 'users', u.id); const uS = await tx.get(uRef);
                  if (!uS.exists()) throw new AppError('ইউজার পাওয়া যায়নি।');
                  tx.update(uRef, { balance: Number(uS.data().balance || 0) + amt });
                  tx.set(doc(collection(db, 'transactions')), { userId: u.id, type: 'bonus', amount: amt, status: 'completed', note, createdAt: serverTimestamp() });
                  tx.set(notifRef(), notifData(u.id, 'বোনাস পেয়েছেন', `আপনার ওয়ালেটে ${taka(amt)} বোনাস যোগ হয়েছে। (${note})`));
                });
                u.balance = Number(u.balance || 0) + amt;
                await logAdmin('bonus', { uid: u.id, amt, note });
                close(); toast('বোনাস দেওয়া হয়েছে।'); render();
              } catch (ex) { err(errMsg(ex)); }
            });
          });
        }
      });
    }

    async function openUser(uid) {
      const u = users.find((x) => x.id === uid);
      if (!u) return;
      openModal(`<h3>${esc(u.name)}</h3><div id="ubody"><div class="loader"><span class="spin"></span></div></div>`, {
        onMount: async (m, close) => {
          try {
            const [d, w] = await Promise.all([
              getDocs(query(collection(db, 'deposits'), where('userId', '==', uid))),
              getDocs(query(collection(db, 'withdrawals'), where('userId', '==', uid)))
            ]);
            const sum = (snap, st) => snap.docs.map((x) => x.data()).filter((x) => x.status === st).reduce((a, x) => a + Number(x.amount || 0), 0);
            const isAdminUser = (await getAccess(uid)).staff;
            m.querySelector('#ubody').innerHTML = `
              <div class="card flat">
                <div class="kv"><span class="k">ইমেইল</span><span class="v small">${esc(u.email)}</span></div>
                <div class="kv"><span class="k">UID</span><span class="v mono" style="font-size:11px">${esc(u.id)}</span></div>
                <div class="kv"><span class="k">স্ট্যাটাস</span><span class="v">${u.status === 'active' ? 'সক্রিয়' : 'স্থগিত'}</span></div>
                <div class="kv"><span class="k">রেজিস্ট্রেশন</span><span class="v">${esc(fmtTs(u.createdAt))}</span></div>
                <div class="kv"><span class="k">রেফার কোড</span><span class="v mono">${esc(u.referralCode || '—')}</span></div>
                ${u.referredBy ? `<div class="kv"><span class="k">রেফার করেছেন (কোড)</span><span class="v mono">${esc(u.referredBy)}</span></div>` : ''}
                <div class="kv"><span class="k">ডিপোজিট ওয়ালেট</span><span class="v">${taka(u.balance)}</span></div>
                <div class="kv"><span class="k">উইনিং ওয়ালেট</span><span class="v">${taka(u.winBalance || 0)}</span></div>
                <div class="kv"><span class="k">গেম নাম / UID</span><span class="v">${esc(u.gameName || '—')} / ${esc(u.gameId || '—')}</span></div>
                <div class="kv"><span class="k">মোট ডিপোজিট (অনুমোদিত)</span><span class="v">${taka(sum(d, 'approved'))}</span></div>
                <div class="kv"><span class="k">মোট উইথড্র (পরিশোধিত)</span><span class="v">${taka(sum(w, 'paid'))}</span></div>
                <div class="kv"><span class="k">ম্যাচ / জয় / উইন%</span><span class="v">${bn(u.totalMatches || 0)} / ${bn(u.totalWins || 0)} / ${bn(winRate(u.totalWins || 0, u.totalMatches || 0))}%</span></div>
              </div>
              <div class="actions"><button class="btn ghost" data-x>বন্ধ করুন</button>
              ${isAdminUser ? '' : '<button class="btn ghost" id="bonus">বোনাস দিন</button>'}
              ${isAdminUser ? '' : u.status === 'active' ? '<button class="btn danger" id="susp">স্থগিত করুন</button>' : '<button class="btn" id="react">সক্রিয় করুন</button>'}</div>`;
            const bb = m.querySelector('#bonus');
            if (bb) bb.addEventListener('click', () => { close(); openBonus(u); });
            m.querySelector('[data-x]').addEventListener('click', close);
            const set = (status) => async (e) => {
              const btn = e.currentTarget;
              const label = status === 'suspended' ? 'স্থগিত' : 'সক্রিয়';
              if (!(await confirmDialog(`${u.name} কে ${label} করবেন?`, { danger: status === 'suspended' }))) return;
              await withLock(btn, async () => {
                try {
                  await updateDoc(doc(db, 'users', uid), { status });
                  await logAdmin('user_status', { uid, status });
                  u.status = status; close(); toast(`ইউজার ${label} হয়েছে।`); render();
                } catch (ex) { toast(errMsg(ex), 'err'); }
              });
            };
            const s1 = m.querySelector('#susp'); if (s1) s1.addEventListener('click', set('suspended'));
            const s2 = m.querySelector('#react'); if (s2) s2.addEventListener('click', set('active'));
          } catch (e) { m.querySelector('#ubody').innerHTML = `<div class="form-error">${esc(errMsg(e))}</div>`; }
        }
      });
    }
    render();
  } catch (e) { failView(e); }
}

// =====================================================================
// ডিপোজিট ম্যানেজমেন্ট
// =====================================================================
function reasonDialog(title, label) {
  return new Promise((resolve) => {
    openModal(`<h3>${esc(title)}</h3><div class="field"><label>${esc(label)}</label><textarea class="input" id="rsn" maxlength="200"></textarea></div>
      <div class="actions"><button class="btn ghost" data-x>বাতিল</button><button class="btn danger" id="rok">নিশ্চিত</button></div>`, {
      onMount: (m, close) => {
        m.querySelector('[data-x]').addEventListener('click', () => { close(); resolve(null); });
        m.querySelector('#rok').addEventListener('click', () => { const v = m.querySelector('#rsn').value.trim(); close(); resolve(v); });
      }
    });
  });
}

async function depositsPage() {
  await adminBoot('deposits', 'ডিপোজিট ম্যানেজমেন্ট');
  let rows = []; let tab = 'pending';
  async function load() {
    const snap = await getDocs(query(collection(db, 'deposits'), orderBy('createdAt', 'desc'), limit(200)));
    rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  }
  const names = {};
  async function nameOf(uid) {
    if (names[uid] !== undefined) return names[uid];
    try { const s = await getDoc(doc(db, 'users', uid)); names[uid] = s.exists() ? `${s.data().name} (${s.data().email})` : uid; } catch { names[uid] = uid; }
    return names[uid];
  }

  async function render() {
    const list = rows.filter((r) => tab === 'all' || r.status === tab);
    await Promise.all(list.map((r) => nameOf(r.userId)));
    const dupTrx = (r) => rows.some((o) => o.id !== r.id && o.transactionId === r.transactionId);
    setView(`${pageHead('ডিপোজিট রিকোয়েস্ট', 'bKash/Nagad/Rocket অ্যাপে নিজে পেমেন্ট যাচাই করে তবেই অনুমোদন দিন')}
      <div class="tabs mb" id="tabs">${[['pending', 'পেন্ডিং'], ['approved', 'অনুমোদিত'], ['rejected', 'বাতিল'], ['all', 'সব']].map(([k, l]) => `<button class="tab ${tab === k ? 'active' : ''}" data-tab="${k}">${l}</button>`).join('')}</div>
      ${list.length ? list.map((r) => `<div class="acard" data-id="${esc(r.id)}">
        <div class="head"><div><div class="title num" style="font-size:20px">${taka(r.amount)} <span style="font-family:var(--font);font-size:14px;font-weight:500">• ${esc(r.method)}</span></div>
          <div class="small muted">${esc(names[r.userId])}</div></div>${badge(DSTATUS, r.status)}</div>
        <div class="kv"><span class="k">সেন্ডার নম্বর</span><span class="v mono">${esc(r.senderNumber)}</span></div>
        <div class="kv"><span class="k">ট্রানজেকশন আইডি</span><span class="v mono">${esc(r.transactionId)}</span></div>
        <div class="kv"><span class="k">সময়</span><span class="v">${esc(fmtTs(r.createdAt))}</span></div>
        ${dupTrx(r) ? `<div class="notice warn mt-s">${icon('alert')}<div>এই ট্রানজেকশন আইডি আরেকটি রিকোয়েস্টেও আছে — সতর্ক থাকুন।</div></div>` : ''}
        ${r.adminNote ? `<div class="small" style="color:var(--danger);margin-top:6px">নোট: ${esc(r.adminNote)}</div>` : ''}
        ${r.status === 'pending' ? `<div class="arow"><button class="btn sm" data-ok>যাচাই করেছি — অনুমোদন</button><button class="btn sm danger" data-no>বাতিল</button></div>` : ''}
      </div>`).join('') : emptyState('কিছু নেই', 'এই ট্যাবে কোনো রিকোয়েস্ট নেই।', 'down')}`);
    $$('#tabs [data-tab]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; render(); }));
    $$('.acard [data-ok]').forEach((b) => b.addEventListener('click', () => approve(b, b.closest('.acard').dataset.id)));
    $$('.acard [data-no]').forEach((b) => b.addEventListener('click', () => reject(b, b.closest('.acard').dataset.id)));
  }

  async function approve(btn, id) {
    const r = rows.find((x) => x.id === id);
    if (!(await confirmDialog(`${r.method} অ্যাপে TrxID ${r.transactionId} দিয়ে ${taka(r.amount)} প্রাপ্তি নিজে যাচাই করেছেন? অনুমোদন দিলে ইউজারের ব্যালেন্সে যোগ হবে।`, { title: 'ডিপোজিট অনুমোদন', okText: 'অনুমোদন দিন' }))) return;
    await withLock(btn, async () => {
      try {
        await runTransaction(db, async (tx) => {
          const dRef = doc(db, 'deposits', id);
          const dS = await tx.get(dRef);
          if (!dS.exists() || dS.data().status !== 'pending') throw new AppError('এই রিকোয়েস্ট ইতোমধ্যে প্রসেস হয়েছে।');
          const d = dS.data();
          const uRef = doc(db, 'users', d.userId);
          const uS = await tx.get(uRef);
          if (!uS.exists()) throw new AppError('ইউজার পাওয়া যায়নি।');
          const trRef = doc(db, 'transactions', `dep_${id}`);
          if ((await tx.get(trRef)).exists()) throw new AppError('এই ডিপোজিট আগেই ক্রেডিট হয়েছে।');
          tx.update(uRef, { balance: Number(uS.data().balance || 0) + Number(d.amount) });
          tx.update(dRef, { status: 'approved', reviewedBy: auth.currentUser.uid, reviewedAt: serverTimestamp() });
          tx.set(trRef, { userId: d.userId, type: 'deposit', amount: Number(d.amount), status: 'completed', refId: id, note: `${d.method} • ${d.transactionId}`, createdAt: serverTimestamp() });
          tx.set(notifRef(), notifData(d.userId, 'ডিপোজিট অনুমোদিত', `আপনার ${taka(d.amount)} ডিপোজিট অনুমোদিত হয়েছে এবং ব্যালেন্সে যোগ হয়েছে।`));
        });
        await logAdmin('deposit_approve', { id });
        toast('ডিপোজিট অনুমোদিত হয়েছে।');
        await load(); await render();
      } catch (e) { toast(errMsg(e), 'err'); }
    });
  }

  async function reject(btn, id) {
    const note = await reasonDialog('ডিপোজিট বাতিল', 'কারণ (ইউজার দেখতে পাবে, ঐচ্ছিক)');
    if (note === null) return;
    await withLock(btn, async () => {
      try {
        await runTransaction(db, async (tx) => {
          const dRef = doc(db, 'deposits', id);
          const dS = await tx.get(dRef);
          if (!dS.exists() || dS.data().status !== 'pending') throw new AppError('এই রিকোয়েস্ট ইতোমধ্যে প্রসেস হয়েছে।');
          tx.update(dRef, { status: 'rejected', adminNote: note, reviewedBy: auth.currentUser.uid, reviewedAt: serverTimestamp() });
          tx.set(notifRef(), notifData(dS.data().userId, 'ডিপোজিট বাতিল', `আপনার ${taka(dS.data().amount)} ডিপোজিট রিকোয়েস্ট গৃহীত হয়নি।${note ? ' কারণ: ' + note : ''}`));
        });
        await logAdmin('deposit_reject', { id });
        toast('ডিপোজিট বাতিল হয়েছে।');
        await load(); await render();
      } catch (e) { toast(errMsg(e), 'err'); }
    });
  }
  try { await load(); await render(); } catch (e) { failView(e); }
}

// =====================================================================
// উইথড্র ম্যানেজমেন্ট
// pending → approved (ব্যালেন্স কাটা) → paid (প্রকৃত পেমেন্টের পর রেফারেন্সসহ)
// =====================================================================
async function withdrawalsPage() {
  await adminBoot('withdrawals', 'উইথড্র ম্যানেজমেন্ট');
  let rows = []; let tab = 'pending';
  const names = {};
  async function load() {
    const snap = await getDocs(query(collection(db, 'withdrawals'), orderBy('createdAt', 'desc'), limit(200)));
    rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  }
  async function nameOf(uid) {
    if (names[uid] !== undefined) return names[uid];
    try { const s = await getDoc(doc(db, 'users', uid)); names[uid] = s.exists() ? { t: `${s.data().name} (${s.data().email})`, bal: s.data().winBalance || 0 } : { t: uid, bal: 0 }; } catch { names[uid] = { t: uid, bal: 0 }; }
    return names[uid];
  }
  async function render() {
    const list = rows.filter((r) => tab === 'all' || r.status === tab);
    await Promise.all(list.map((r) => nameOf(r.userId)));
    setView(`${pageHead('উইথড্র রিকোয়েস্ট', 'অনুমোদনে ব্যালেন্স কাটে; প্রকৃত পেমেন্ট পাঠানোর পরই "পরিশোধিত" চিহ্নিত করুন')}
      <div class="tabs mb" id="tabs">${[['pending', 'পেন্ডিং'], ['approved', 'অনুমোদিত'], ['paid', 'পরিশোধিত'], ['rejected', 'বাতিল'], ['all', 'সব']].map(([k, l]) => `<button class="tab ${tab === k ? 'active' : ''}" data-tab="${k}">${l}</button>`).join('')}</div>
      ${list.length ? list.map((r) => `<div class="acard" data-id="${esc(r.id)}">
        <div class="head"><div><div class="title num" style="font-size:20px">${taka(r.amount)} <span style="font-family:var(--font);font-size:14px;font-weight:500">• ${esc(r.method)}</span></div>
          <div class="small muted">${esc(names[r.userId].t)} • উইনিং ওয়ালেট ${taka(names[r.userId].bal)}</div></div>${badge(DSTATUS, r.status)}</div>
        <div class="kv"><span class="k">পাঠাতে হবে</span><span class="v mono">${esc(r.accountNumber)}</span></div>
        <div class="kv"><span class="k">অ্যাকাউন্ট নাম</span><span class="v">${esc(r.accountName)}</span></div>
        <div class="kv"><span class="k">সময়</span><span class="v">${esc(fmtTs(r.createdAt))}</span></div>
        ${r.payoutReference ? `<div class="kv"><span class="k">পেমেন্ট রেফারেন্স</span><span class="v mono">${esc(r.payoutReference)}</span></div>` : ''}
        ${r.adminNote ? `<div class="small" style="color:var(--danger);margin-top:6px">নোট: ${esc(r.adminNote)}</div>` : ''}
        ${r.status === 'pending' && Number(names[r.userId].bal) < Number(r.amount) ? `<div class="notice danger mt-s">${icon('alert')}<div>ইউজারের উইনিং ওয়ালেট রিকোয়েস্টের চেয়ে কম।</div></div>` : ''}
        <div class="arow">
          ${r.status === 'pending' ? '<button class="btn sm" data-a="approve">অনুমোদন (ব্যালেন্স কাটবে)</button><button class="btn sm danger" data-a="reject">বাতিল</button>' : ''}
          ${r.status === 'approved' ? '<button class="btn sm" data-a="paid">পেমেন্ট সম্পন্ন — পরিশোধিত</button><button class="btn sm warn" data-a="refund">বাতিল ও ফেরত</button>' : ''}
        </div></div>`).join('') : emptyState('কিছু নেই', 'এই ট্যাবে কোনো রিকোয়েস্ট নেই।', 'up')}`);
    $$('#tabs [data-tab]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; render(); }));
    $$('.acard [data-a]').forEach((b) => b.addEventListener('click', () => act(b.dataset.a, b, b.closest('.acard').dataset.id)));
  }

  async function act(kind, btn, id) {
    const r = rows.find((x) => x.id === id);
    try {
      if (kind === 'approve') {
        if (!(await confirmDialog(`${taka(r.amount)} অনুমোদন করলে ইউজারের ব্যালেন্স থেকে এখনই কাটা হবে। এরপর ${r.method} ${r.accountNumber} নম্বরে টাকা পাঠিয়ে "পরিশোধিত" করুন।`, { okText: 'অনুমোদন' }))) return;
        await withLock(btn, () => runTransaction(db, async (tx) => {
          const wRef = doc(db, 'withdrawals', id);
          const wS = await tx.get(wRef);
          if (!wS.exists() || wS.data().status !== 'pending') throw new AppError('এই রিকোয়েস্ট ইতোমধ্যে প্রসেস হয়েছে।');
          const w = wS.data();
          const uRef = doc(db, 'users', w.userId);
          const uS = await tx.get(uRef);
          const bal = Number(uS.data().winBalance || 0);
          if (bal < Number(w.amount)) throw new AppError('ইউজারের উইনিং ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই।');
          const trRef = doc(db, 'transactions', `wd_${id}`);
          if ((await tx.get(trRef)).exists()) throw new AppError('এই উইথড্র আগেই ডেবিট হয়েছে।');
          tx.update(uRef, { winBalance: bal - Number(w.amount) });
          tx.update(wRef, { status: 'approved', reviewedBy: auth.currentUser.uid, reviewedAt: serverTimestamp() });
          tx.set(trRef, { userId: w.userId, type: 'withdrawal', amount: Number(w.amount), status: 'approved', refId: id, note: `${w.method} • ${w.accountNumber}`, createdAt: serverTimestamp() });
          tx.set(notifRef(), notifData(w.userId, 'উইথড্র অনুমোদিত', `আপনার ${taka(w.amount)} উইথড্র অনুমোদিত হয়েছে (উইনিং ওয়ালেট থেকে কাটা হয়েছে)। শীঘ্রই পেমেন্ট পাঠানো হবে।`));
        }));
        await logAdmin('withdraw_approve', { id }); toast('উইথড্র অনুমোদিত হয়েছে।');
      } else if (kind === 'reject') {
        const note = await reasonDialog('উইথড্র বাতিল', 'কারণ (ঐচ্ছিক)');
        if (note === null) return;
        await withLock(btn, () => runTransaction(db, async (tx) => {
          const wRef = doc(db, 'withdrawals', id);
          const wS = await tx.get(wRef);
          if (!wS.exists() || wS.data().status !== 'pending') throw new AppError('এই রিকোয়েস্ট ইতোমধ্যে প্রসেস হয়েছে।');
          tx.update(wRef, { status: 'rejected', adminNote: note, reviewedBy: auth.currentUser.uid, reviewedAt: serverTimestamp() });
          tx.set(notifRef(), notifData(wS.data().userId, 'উইথড্র বাতিল', `আপনার ${taka(wS.data().amount)} উইথড্র রিকোয়েস্ট গৃহীত হয়নি।${note ? ' কারণ: ' + note : ''}`));
        }));
        await logAdmin('withdraw_reject', { id }); toast('উইথড্র বাতিল হয়েছে।');
      } else if (kind === 'paid') {
        const ref = await new Promise((resolve) => openModal(`<h3>পেমেন্ট রেফারেন্স</h3><p class="muted small mb">${r.method} এ ${taka(r.amount)} (${esc(r.accountNumber)}) সত্যিই পাঠানো হয়েছে? পাঠানোর TrxID লিখুন।</p>
          <div id="perr" class="form-error hidden"></div><div class="field"><label>পেমেন্ট TrxID / রেফারেন্স</label><input class="input" id="pref" maxlength="40"></div>
          <div class="actions"><button class="btn ghost" data-x>বাতিল</button><button class="btn" id="pok">পরিশোধিত চিহ্নিত করুন</button></div>`, {
          onMount: (m, close) => {
            m.querySelector('[data-x]').addEventListener('click', () => { close(); resolve(null); });
            m.querySelector('#pok').addEventListener('click', () => {
              const v = m.querySelector('#pref').value.trim();
              if (v.length < 4) { const b = m.querySelector('#perr'); b.textContent = 'সঠিক রেফারেন্স লিখুন (কমপক্ষে ৪ অক্ষর)।'; b.classList.remove('hidden'); return; }
              close(); resolve(v);
            });
          }
        }));
        if (!ref) return;
        await withLock(btn, () => runTransaction(db, async (tx) => {
          const wRef = doc(db, 'withdrawals', id);
          const wS = await tx.get(wRef);
          if (!wS.exists() || wS.data().status !== 'approved') throw new AppError('এই রিকোয়েস্ট পরিশোধের উপযোগী নয় বা আগেই পরিশোধিত।');
          const trRef = doc(db, 'transactions', `wd_${id}`);
          tx.update(wRef, { status: 'paid', payoutReference: ref, paidAt: serverTimestamp() });
          tx.update(trRef, { status: 'completed' });
          tx.set(notifRef(), notifData(wS.data().userId, 'উইথড্র পরিশোধিত', `আপনার ${taka(wS.data().amount)} ${wS.data().method} এ পাঠানো হয়েছে। রেফারেন্স: ${ref}`));
        }));
        await logAdmin('withdraw_paid', { id, ref }); toast('পরিশোধিত চিহ্নিত হয়েছে।');
      } else if (kind === 'refund') {
        const note = await reasonDialog('বাতিল ও ফেরত', 'কারণ (ঐচ্ছিক)');
        if (note === null) return;
        await withLock(btn, () => runTransaction(db, async (tx) => {
          const wRef = doc(db, 'withdrawals', id);
          const wS = await tx.get(wRef);
          if (!wS.exists() || wS.data().status !== 'approved') throw new AppError('এই রিকোয়েস্ট ফেরতযোগ্য নয়।');
          const w = wS.data();
          const uRef = doc(db, 'users', w.userId);
          const uS = await tx.get(uRef);
          const rRef = doc(db, 'transactions', `wdr_${id}`);
          if ((await tx.get(rRef)).exists()) throw new AppError('ইতোমধ্যে ফেরত হয়েছে।');
          tx.update(uRef, { winBalance: Number(uS.data().winBalance || 0) + Number(w.amount) });
          tx.update(wRef, { status: 'rejected', adminNote: note || 'পেমেন্ট সম্ভব হয়নি', reviewedAt: serverTimestamp() });
          tx.update(doc(db, 'transactions', `wd_${id}`), { status: 'refunded' });
          tx.set(rRef, { userId: w.userId, type: 'refund', amount: Number(w.amount), status: 'completed', refId: id, note: 'উইথড্র ফেরত', createdAt: serverTimestamp() });
          tx.set(notifRef(), notifData(w.userId, 'উইথড্র ফেরত', `আপনার ${taka(w.amount)} উইথড্র সম্পন্ন করা যায়নি; টাকা ওয়ালেটে ফেরত দেওয়া হয়েছে।`));
        }));
        await logAdmin('withdraw_refund', { id }); toast('ফেরত দেওয়া হয়েছে।');
      }
      await load(); await render();
    } catch (e) { toast(errMsg(e), 'err'); }
  }
  try { await load(); await render(); } catch (e) { failView(e); }
}

// =====================================================================
// ফলাফল ম্যানেজমেন্ট
// ধাপ ১: টুর্নামেন্ট ডকে ফলাফল সেভ (এক ট্রানজেকশনে, ডাবল-পাবলিশ গার্ডসহ)
// ধাপ ২: প্রতি অংশগ্রহণকারীর জন্য ব্যাচে stats + প্রাইজ + লিডারবোর্ড + নোটিফিকেশন
//        resultApplied মার্কারের কারণে ব্যর্থ হলে আবার চালালে শুধু বাকিগুলো হয় (ডাবল পেআউট নয়)
// =====================================================================
async function resultsPage() {
  await adminBoot('results', 'ফলাফল ম্যানেজমেন্ট');
  try {
    const snap = await getDocs(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc'), limit(100)));
    const ts_ = snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((t) => t.status !== 'cancelled');
    const sel = new URLSearchParams(location.search).get('id') || '';
    setView(`${pageHead('ফলাফল', 'যাচাইকৃত ফলাফল প্রকাশ করলে প্রাইজ ওয়ালেটে যোগ হয় ও লিডারবোর্ড আপডেট হয়')}
      <div class="field"><label>টুর্নামেন্ট বেছে নিন</label><select class="input" id="tsel"><option value="">— বেছে নিন —</option>
        ${ts_.map((t) => `<option value="${esc(t.id)}" ${t.id === sel ? 'selected' : ''}>${esc(t.title)} (${esc((TSTATUS[t.status] || [t.status])[0])})${t.resultsPublished ? ' ✓' : ''}</option>`).join('')}</select></div>
      <div id="rbody">${emptyState('একটি টুর্নামেন্ট বেছে নিন', 'অংশগ্রহণকারীদের তালিকা এখানে দেখা যাবে।', 'award')}</div>`);
    $('#tsel').addEventListener('change', (e) => load(e.target.value));
    if (sel) load(sel);

    async function load(id) {
      const box = $('#rbody');
      if (!id) { box.innerHTML = emptyState('একটি টুর্নামেন্ট বেছে নিন', '', 'award'); return; }
      box.innerHTML = '<div class="loader"><span class="spin"></span></div>';
      try {
        const [tS, pSnap] = await Promise.all([
          getDoc(doc(db, 'tournaments', id)),
          getDocs(query(collection(db, 'tournament_players'), where('tournamentId', '==', id)))
        ]);
        const t = { id: tS.id, ...tS.data() };
        const parts = pSnap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((p) => p.status === 'registered').sort((a, b) => ts(a.joinedAt) - ts(b.joinedAt));

        if (t.resultsPublished) {
          const res = [...(t.results || [])].sort((a, b) => a.position - b.position);
          const unapplied = parts.filter((p) => !p.resultApplied).length;
          box.innerHTML = `<div class="notice">${icon('check')}<div>এই টুর্নামেন্টের ফলাফল প্রকাশিত হয়েছে।</div></div>
            <div class="list mt">${res.map((r) => `<div class="item"><div class="rank ${r.position <= 3 ? 'r' + r.position : ''}">${bn(r.position)}</div><div class="grow"><div class="t">${esc(r.playerName)}</div><div class="s mono">${esc(r.playerId)}${r.kills ? ' • ' + bn(r.kills) + ' কিল' : ''}</div></div><div class="amt">${r.prize ? taka(r.prize) : '—'}</div></div>`).join('')}</div>
            ${unapplied ? `<div class="notice warn mt">${icon('alert')}<div>${bn(unapplied)} জনের প্রাইজ/স্ট্যাটস আপডেট বাকি আছে (আগের চেষ্টা ব্যর্থ হয়েছিল)।</div></div><div class="mt"><button class="btn block" id="retry">বাকিগুলো আবার প্রসেস করুন</button></div>` : ''}`;
          const rb = $('#retry');
          if (rb) rb.addEventListener('click', () => withLock(rb, async () => {
            try { await applyResults(t, parts); toast('সব আপডেট সম্পন্ন।'); load(id); } catch (e) { toast(errMsg(e), 'err'); }
          }));
          return;
        }
        if (!parts.length) { box.innerHTML = emptyState('নিশ্চিত অংশগ্রহণকারী নেই', 'এই টুর্নামেন্টে এখনো কোনো নিশ্চিত রেজিস্ট্রেশন নেই।', 'users'); return; }

        box.innerHTML = `<div class="card">
          <div class="row between"><div><div class="card-title" style="margin:0">${esc(t.title)}</div><div class="small muted">প্রাইজ পুল ${taka(t.prizePool)} • ${bn(parts.length)} জন নিশ্চিত</div></div>${tBadge(t.status)}</div>
          ${t.status !== 'live' && t.status !== 'completed' ? `<div class="notice warn mt-s">${icon('info')}<div>টুর্নামেন্ট এখনো লাইভ/সমাপ্ত নয়। ম্যাচ শেষ হলে ফলাফল দিন।</div></div>` : ''}
          <div class="small muted" style="margin:14px 0 4px">শুধু যাদের স্থান দেবেন তারাই ফলাফলে আসবে। ১ নম্বর স্থান = বিজয়ী (জয় +১)। প্রাইজ = র‍্যাঙ্ক প্রাইজ + কিল × পার কিল (${taka(t.perKill || 0)}); চাইলে বদলাতে পারেন।</div>
          <div class="res-row small muted"><span>প্লেয়ার</span><span>স্থান</span><span>কিল</span><span>প্রাইজ ৳</span></div>
          ${parts.map((p) => `<div class="res-row" data-uid="${esc(p.userId)}"><div><div style="font-weight:600">${esc(p.playerName)}</div><div class="small muted mono">${esc(p.playerId)}</div></div>
            <input class="input" type="number" min="1" step="1" inputmode="numeric" data-pos><input class="input" type="number" min="0" step="1" inputmode="numeric" data-kills><input class="input" type="number" min="0" step="1" inputmode="numeric" data-prize></div>`).join('')}
          <div id="rerr" class="form-error hidden mt"></div>
          <label class="check mt"><input type="checkbox" id="rconf"> আমি ম্যাচের ফলাফল যাচাই করেছি এবং এটি চূড়ান্ত।</label>
          <button class="btn block mt" id="pub">ফলাফল প্রকাশ করুন</button></div>`;

        const rankPrize = (pos) => { const x = (t.prizes || []).find((q) => Number(q.position) === pos); return x ? Number(x.amount) : 0; };
        $$('.res-row[data-uid]').forEach((r) => {
          const pos = r.querySelector('[data-pos]'), kills = r.querySelector('[data-kills]'), prize = r.querySelector('[data-prize]');
          prize.addEventListener('input', () => { prize.dataset.manual = '1'; });
          const auto = () => {
            if (prize.dataset.manual) return;
            const p = Number(pos.value), k = Number(kills.value || 0);
            prize.value = pos.value === '' && kills.value === '' ? '' : String(rankPrize(p) + k * Number(t.perKill || 0));
          };
          pos.addEventListener('input', auto); kills.addEventListener('input', auto);
        });

        $('#pub').addEventListener('click', (e) => {
          const pubBtn = e.currentTarget;
          const err = (m) => { const b = $('#rerr'); b.textContent = m; b.classList.remove('hidden'); b.scrollIntoView({ block: 'center', behavior: 'smooth' }); };
          $('#rerr').classList.add('hidden');
          const rows = $$('.res-row[data-uid]').map((r) => {
            const p = parts.find((x) => x.userId === r.dataset.uid);
            const pos = r.querySelector('[data-pos]').value.trim();
            const prize = r.querySelector('[data-prize]').value.trim();
            const kills = r.querySelector('[data-kills]').value.trim();
            return { p, pos, prize, kills };
          }).filter((r) => r.pos !== '' || r.prize !== '' || r.kills !== '');
          if (!rows.length) return err('কমপক্ষে একজনের স্থান দিন।');
          const results = [];
          const used = new Set();
          for (const r of rows) {
            const pos = Number(r.pos); const prize = r.prize === '' ? 0 : Number(r.prize);
            if (r.pos === '') return err(`"${r.p.playerName}" এর স্থান দিন (প্রাইজ দিলে স্থানও লাগবে)।`);
            if (!Number.isInteger(pos) || pos < 1) return err('স্থান ১ বা তার বেশি পূর্ণ সংখ্যা হতে হবে।');
            if (used.has(pos)) return err(`${bn(pos)} নম্বর স্থান একাধিকবার দেওয়া হয়েছে।`);
            if (!Number.isFinite(prize) || prize < 0) return err('প্রাইজের পরিমাণ সঠিক নয়।');
            const kills = r.kills === '' ? 0 : Number(r.kills);
            if (!Number.isInteger(kills) || kills < 0) return err('কিল সংখ্যা সঠিক নয়।');
            used.add(pos);
            results.push({ position: pos, userId: r.p.userId, playerName: r.p.playerName, playerId: r.p.playerId, kills, prize });
          }
          if (!used.has(1)) return err('১ নম্বর স্থান (বিজয়ী) অবশ্যই দিতে হবে।');
          const total = results.reduce((s, r) => s + r.prize, 0);
          if (!$('#rconf').checked) return err('যাচাইয়ের নিশ্চিতকরণ টিক দিন।');
          confirmDialog(`ফলাফল প্রকাশ করলে মোট ${taka(total)} প্রাইজ ইউজারদের উইনিং ওয়ালেটে যোগ হবে।${total > Number(t.prizePool) ? ` সতর্কতা: এটি প্রাইজ পুল (${taka(t.prizePool)}) এর চেয়ে বেশি।` : ''} এটি ফেরানো যাবে না। এগিয়ে যাবেন?`, { title: 'ফলাফল প্রকাশ', okText: 'প্রকাশ করুন' }).then((ok) => {
            if (!ok) return;
            withLock(pubBtn, async () => {
              try {
                await runTransaction(db, async (tx) => {
                  const ref = doc(db, 'tournaments', t.id);
                  const s = await tx.get(ref);
                  if (s.data().resultsPublished) throw new AppError('এই টুর্নামেন্টের ফলাফল ইতোমধ্যে প্রকাশিত।');
                  tx.update(ref, { results, resultsPublished: true, resultsApplied: false, status: 'completed', resultsPublishedAt: serverTimestamp(), updatedAt: serverTimestamp() });
                });
                await logAdmin('results_publish', { id: t.id, total });
                const fresh = { ...t, results, resultsPublished: true };
                await applyResults(fresh, parts);
                toast('ফলাফল প্রকাশিত হয়েছে এবং সবাইকে জানানো হয়েছে।');
              } catch (ex) {
                toast(errMsg(ex) + ' — প্রয়োজনে পেজ রিফ্রেশ করে "বাকিগুলো আবার প্রসেস" চালান।', 'err');
              }
              load(t.id);
            });
          });
        });
      } catch (e) { box.innerHTML = `<div class="form-error">${esc(errMsg(e))}</div>`; }
    }

    async function applyResults(t, parts) {
      const byUid = {}; (t.results || []).forEach((r) => { byUid[r.userId] = r; });
      const todo = parts.filter((p) => !p.resultApplied);
      for (let i = 0; i < todo.length; i += 100) {
        const b = writeBatch(db);
        todo.slice(i, i + 100).forEach((p) => {
          const r = byUid[p.userId];
          const win = r && r.position === 1 ? 1 : 0;
          const prize = r ? Number(r.prize || 0) : 0;
          b.update(doc(db, 'users', p.userId), { totalMatches: increment(1), ...(win ? { totalWins: increment(1) } : {}), ...(prize > 0 ? { winBalance: increment(prize) } : {}) });
          b.set(doc(db, 'leaderboard', p.userId), { name: p.userName || p.playerName, totalMatches: increment(1), totalWins: increment(win), updatedAt: serverTimestamp() }, { merge: true });
          if (prize > 0) b.set(doc(db, 'transactions', `prize_${t.id}_${p.userId}`), { userId: p.userId, type: 'prize', amount: prize, status: 'completed', tournamentId: t.id, note: `${t.title} • ${r.position} নং স্থান${r.kills ? ' • ' + r.kills + ' কিল' : ''}`, createdAt: serverTimestamp() });
          b.update(doc(db, 'tournament_players', p.id), { resultApplied: true, position: r ? r.position : null, kills: r ? (r.kills || 0) : 0, prize });
          b.set(notifRef(), notifData(p.userId, 'ফলাফল প্রকাশিত',
            r ? `"${t.title}" এ আপনি ${r.position} নং স্থান পেয়েছেন।${r.kills ? ' কিল ' + r.kills + 'টি।' : ''}${prize > 0 ? ' প্রাইজ ' + taka(prize) + ' উইনিং ওয়ালেটে যোগ হয়েছে।' : ''}` : `"${t.title}" এর ফলাফল প্রকাশিত হয়েছে। অংশ নেওয়ার জন্য ধন্যবাদ।`));
        });
        await b.commit();
      }
      await updateDoc(doc(db, 'tournaments', t.id), { resultsApplied: true });
    }
  } catch (e) { failView(e); }
}

// =====================================================================
// নোটিফিকেশন
// =====================================================================
async function notificationsPage() {
  await adminBoot('notifications', 'নোটিফিকেশন');
  try {
    const tsnap = await getDocs(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc'), limit(50)));
    const tours = tsnap.docs.map((d) => ({ id: d.id, ...d.data() }));

    async function history() {
      const s = await getDocs(query(collection(db, 'notifications'), limit(25)));
      const items = s.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => ts(b.createdAt) - ts(a.createdAt));
      return items.length ? `<div class="list">${items.map((n) => `<div class="item"><div class="ico">${icon('bell')}</div><div class="grow"><div class="t">${esc(n.title)} <span class="badge">${n.userId === 'all' ? 'সবাইকে' : 'ব্যক্তিগত'}</span></div><div class="s">${esc(n.message)}</div><div class="s">${esc(fmtTs(n.createdAt))}</div></div></div>`).join('')}</div>` : emptyState('এখনো কিছু পাঠানো হয়নি', '', 'bell');
    }

    setView(`${pageHead('নোটিফিকেশন পাঠান', 'ইন-অ্যাপ নোটিফিকেশন (ফোনে পুশ নয়)')}
      <form class="card" id="nform" novalidate>
        <div class="field"><label>কাকে পাঠাবেন</label><select class="input" id="nTarget"><option value="all">সব ইউজার</option><option value="users">নির্দিষ্ট ইউজার (ইমেইল)</option><option value="tournament">টুর্নামেন্টের অংশগ্রহণকারী</option></select></div>
        <div class="field hidden" id="fEmails"><label>ইমেইল (কমা বা নতুন লাইনে আলাদা)</label><textarea class="input" id="nEmails" placeholder="a@example.com, b@example.com"></textarea></div>
        <div class="field hidden" id="fTour"><label>টুর্নামেন্ট</label><select class="input" id="nTour">${tours.map((t) => `<option value="${esc(t.id)}">${esc(t.title)}</option>`).join('')}</select></div>
        <div class="field"><label>শিরোনাম</label><input class="input" id="nTitle" maxlength="80"></div>
        <div class="field"><label>বার্তা</label><textarea class="input" id="nMsg" maxlength="400"></textarea></div>
        <div id="nerr" class="form-error hidden"></div>
        <button class="btn block" id="nSend" type="submit">${icon('send', 'sm')} পাঠান</button>
      </form>
      <div class="section-head"><h2>সাম্প্রতিক নোটিফিকেশন</h2></div><div id="hist"><div class="loader"><span class="spin"></span></div></div>`);

    $('#nTarget').addEventListener('change', (e) => {
      $('#fEmails').classList.toggle('hidden', e.target.value !== 'users');
      $('#fTour').classList.toggle('hidden', e.target.value !== 'tournament');
    });
    $('#hist').innerHTML = await history();

    $('#nform').addEventListener('submit', async (e) => {
      e.preventDefault();
      const err = (m) => { const b = $('#nerr'); b.textContent = m; b.classList.remove('hidden'); };
      $('#nerr').classList.add('hidden');
      const target = $('#nTarget').value;
      const title = $('#nTitle').value.trim(); const message = $('#nMsg').value.trim();
      if (title.length < 2) return err('শিরোনাম দিন।');
      if (message.length < 2) return err('বার্তা লিখুন।');
      await withLock($('#nSend'), async () => {
        try {
          let sent = 0;
          if (target === 'all') {
            if (!(await confirmDialog('সব ইউজারকে এই নোটিফিকেশন পাঠাবেন?'))) return;
            await setDoc(notifRef(), notifData('all', title, message)); sent = -1;
          } else if (target === 'users') {
            const emails = Array.from(new Set($('#nEmails').value.split(/[\s,;]+/).map((x) => x.trim().toLowerCase()).filter(Boolean)));
            if (!emails.length) return err('অন্তত একটি ইমেইল দিন।');
            if (emails.length > 50) return err('একবারে সর্বোচ্চ ৫০টি ইমেইল।');
            const uids = []; const missing = [];
            for (const em of emails) {
              const s = await getDocs(query(collection(db, 'users'), where('email', '==', em), limit(1)));
              if (s.empty) missing.push(em); else uids.push(s.docs[0].id);
            }
            if (missing.length) return err(`এই ইমেইলে ইউজার নেই: ${missing.join(', ')}`);
            sent = await notifyMany(uids, title, message);
          } else {
            const tid = $('#nTour').value;
            if (!tid) return err('টুর্নামেন্ট বেছে নিন।');
            const ps = await getDocs(query(collection(db, 'tournament_players'), where('tournamentId', '==', tid)));
            const uids = ps.docs.filter((d) => d.data().status === 'registered').map((d) => d.data().userId);
            if (!uids.length) return err('এই টুর্নামেন্টে নিশ্চিত অংশগ্রহণকারী নেই।');
            sent = await notifyMany(uids, title, message);
          }
          await logAdmin('notify', { target, title });
          toast(sent === -1 ? 'সব ইউজারকে নোটিফিকেশন পাঠানো হয়েছে।' : `${bn(sent)} জনকে নোটিফিকেশন পাঠানো হয়েছে।`);
          $('#nTitle').value = ''; $('#nMsg').value = '';
          $('#hist').innerHTML = await history();
        } catch (ex) { err(errMsg(ex)); }
      });
    });
  } catch (e) { failView(e); }
}

// =====================================================================
// সেটিংস
// =====================================================================
async function settingsPage() {
  const { settings } = await adminBoot('settings', 'সেটিংস');
  const s = settings;
  setView(`${pageHead('অ্যাপ সেটিংস', 'পরিবর্তন সঙ্গে সঙ্গে ইউজার অ্যাপে কার্যকর হয়')}
    <form id="sform" novalidate>
      <div class="card"><div class="card-title">সাধারণ</div>
        <div class="field"><label>অ্যাপের নাম</label><input class="input" id="sName" maxlength="40" value="${esc(s.appName)}"></div>
        <div class="field"><label>হোমের নোটিশ (স্ক্রলিং ঘোষণা, ঐচ্ছিক)</label><input class="input" id="sNotice" maxlength="200" value="${esc(s.notice || '')}"></div>
        <div class="field"><label>গেমের তালিকা (কমা দিয়ে আলাদা)</label><input class="input" id="sGames" value="${esc(gameList(s).join(', '))}"><span class="hint">নতুন গেম যোগ করতে এখানে নাম লিখুন।</span></div>
        <div class="switch"><div><div style="font-weight:600">মেইনটেনেন্স মোড</div><div class="small muted">চালু করলে অ্যাডমিন ছাড়া কেউ অ্যাপ ব্যবহার করতে পারবে না।</div></div><input type="checkbox" id="sMaint" ${s.maintenanceMode ? 'checked' : ''}></div>
      </div>
      <div class="card mt"><div class="card-title">হোম ব্যানার (স্লাইডার)</div>
        <div class="field"><label>প্রতি লাইনে একটি: শিরোনাম | ছবির লিংক (ঐচ্ছিক) | উপশিরোনাম (ঐচ্ছিক) | লিংক (ঐচ্ছিক)</label>
          <textarea class="input" id="sBanners" maxlength="1500" placeholder="শুক্রবার নাইট কাপ | https://.../banner.jpg | প্রাইজ পুল ৫০০ টাকা | tournaments.html">${esc((s.banners || []).map((b) => [b.title || '', b.imageUrl || '', b.subtitle || '', b.link || ''].join(' | ').replace(/( \| )+$/, '')).join('\n'))}</textarea>
          <span class="hint">ফাঁকা রাখলে ডিফল্ট ব্যানার দেখাবে। সর্বোচ্চ ৬টি।</span></div></div>
      <div class="card mt"><div class="card-title">সোশ্যাল লিংক (ইউজার অ্যাপে দেখাবে)</div>
        <div class="field"><label>Telegram</label><input class="input" id="sTg" type="url" maxlength="200" value="${esc(s.telegramUrl || '')}"></div>
        <div class="field"><label>WhatsApp গ্রুপ</label><input class="input" id="sWag" type="url" maxlength="200" value="${esc(s.whatsappUrl || '')}"></div>
        <div class="field"><label>YouTube</label><input class="input" id="sYt" type="url" maxlength="200" value="${esc(s.youtubeUrl || '')}"></div>
        <div class="field"><label>Facebook</label><input class="input" id="sFb" type="url" maxlength="200" value="${esc(s.facebookUrl || '')}"></div></div>
      <div class="card mt"><div class="card-title">সাপোর্ট যোগাযোগ</div>
        <div class="field"><label>ফোন</label><input class="input" id="sPhone" type="tel" maxlength="20" value="${esc(s.supportPhone)}"></div>
        <div class="field"><label>WhatsApp নম্বর</label><input class="input" id="sWa" type="tel" maxlength="20" value="${esc(s.supportWhatsapp)}"></div>
        <div class="field"><label>ইমেইল</label><input class="input" id="sMail" type="email" maxlength="80" value="${esc(s.supportEmail)}"></div>
      </div>
      <div class="card mt"><div class="card-title">পেমেন্ট</div>
        <div class="field"><label>bKash নম্বর</label><input class="input" id="sBk" type="tel" maxlength="20" value="${esc(s.bkashNumber)}"></div>
        <div class="field"><label>Nagad নম্বর</label><input class="input" id="sNg" type="tel" maxlength="20" value="${esc(s.nagadNumber)}"></div>
        <div class="field"><label>Rocket নম্বর</label><input class="input" id="sRk" type="tel" maxlength="20" value="${esc(s.rocketNumber)}"></div>
        <div class="field"><label>পেমেন্ট নির্দেশনা (ডিপোজিট পেজে দেখাবে)</label><textarea class="input" id="sInst" maxlength="600">${esc(s.paymentInstructions)}</textarea></div>
        <div class="grid2">
          <div class="field"><label>ন্যূনতম ডিপোজিট (৳)</label><input class="input" id="sMinD" type="number" min="1" step="1" value="${esc(s.minDeposit)}"></div>
          <div class="field"><label>ন্যূনতম উইথড্র (৳)</label><input class="input" id="sMinW" type="number" min="1" step="1" value="${esc(s.minWithdraw)}"></div>
        </div>
      </div>
      <div id="serr" class="form-error hidden mt"></div>
      <button class="btn block mt" id="sSave" type="submit">সংরক্ষণ করুন</button>
    </form>`);
  $('#sform').addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = (m) => { const b = $('#serr'); b.textContent = m; b.classList.remove('hidden'); b.scrollIntoView({ block: 'center' }); };
    $('#serr').classList.add('hidden');
    const minDeposit = Number($('#sMinD').value); const minWithdraw = Number($('#sMinW').value);
    if (!Number.isInteger(minDeposit) || minDeposit < 1) return err('ন্যূনতম ডিপোজিট সঠিক নয়।');
    if (!Number.isInteger(minWithdraw) || minWithdraw < 1) return err('ন্যূনতম উইথড্র সঠিক নয়।');
    const appName = $('#sName').value.trim();
    if (!appName) return err('অ্যাপের নাম দিন।');
    const games = Array.from(new Set($('#sGames').value.split(',').map((x) => x.trim()).filter(Boolean)));
    if (!games.length) return err('কমপক্ষে একটি গেম রাখুন।');
    const mail = $('#sMail').value.trim();
    if (mail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) return err('সাপোর্ট ইমেইল সঠিক নয়।');
    const maintenanceMode = $('#sMaint').checked;
    const urls = { telegramUrl: $('#sTg').value.trim(), whatsappUrl: $('#sWag').value.trim(), youtubeUrl: $('#sYt').value.trim(), facebookUrl: $('#sFb').value.trim() };
    for (const [k, v] of Object.entries(urls)) if (v && !safeUrl(v)) return err('সোশ্যাল লিংক https:// দিয়ে শুরু হতে হবে।');
    const banners = $('#sBanners').value.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 6).map((l) => {
      const [title = '', imageUrl = '', subtitle = '', link = ''] = l.split('|').map((x) => x.trim());
      return { title, imageUrl: imageUrl && safeUrl(imageUrl) ? imageUrl : '', subtitle, link };
    });
    if (maintenanceMode && !(await confirmDialog('মেইনটেনেন্স মোড চালু করলে সাধারণ ইউজাররা অ্যাপে ঢুকতে পারবে না। চালু করবেন?'))) return;
    await withLock($('#sSave'), async () => {
      try {
        await setDoc(doc(db, 'settings', 'app'), {
          appName, games, maintenanceMode, minDeposit, minWithdraw, banners, notice: $('#sNotice').value.trim(), ...urls,
          supportPhone: $('#sPhone').value.trim(), supportWhatsapp: $('#sWa').value.trim(), supportEmail: mail,
          bkashNumber: $('#sBk').value.trim(), nagadNumber: $('#sNg').value.trim(), rocketNumber: $('#sRk').value.trim(),
          paymentInstructions: $('#sInst').value.trim(), updatedAt: serverTimestamp()
        }, { merge: true });
        await logAdmin('settings_update', { maintenanceMode });
        toast('সেটিংস সংরক্ষিত হয়েছে।');
      } catch (ex) { err(errMsg(ex)); }
    });
  });
}

// =====================================================================
// স্টাফ ও পারমিশন (শুধু মালিক)
// =====================================================================
async function staffPage() {
  const { user } = await adminBoot('staff', 'স্টাফ ও পারমিশন');
  const permBoxes = (cur = {}) => PERMS.map(([k, l]) => `<label class="check" style="align-items:flex-start;margin:8px 0"><input type="checkbox" data-perm="${k}" ${cur[k] ? 'checked' : ''}> <span><b>${esc(k)}</b><br><span class="small muted">${esc(l)}</span></span></label>`).join('');
  const readPerms = (m) => Object.fromEntries([...m.querySelectorAll('[data-perm]')].map((c) => [c.dataset.perm, c.checked]));
  const findUser = async (emailRaw) => {
    const email = emailRaw.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new AppError('সঠিক ইমেইল লিখুন।');
    const snap = await getDocs(query(collection(db, 'users'), where('email', '==', email), limit(1)));
    if (snap.empty) throw new AppError('এই ইমেইলে কোনো অ্যাকাউন্ট নেই। আগে তাকে অ্যাপে রেজিস্টার করতে বলুন।');
    return { id: snap.docs[0].id, ...snap.docs[0].data() };
  };

  async function render() {
    try {
      const [snap, ow] = await Promise.all([getDocs(collection(db, 'staff')), getDoc(doc(db, 'users', user.uid))]);
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setView(`${pageHead('স্টাফ ও পারমিশন', 'কে কোন কাজ করতে পারবে তা এখান থেকে ঠিক করুন')}
        <div class="card"><div class="row between"><div><div class="small muted">মালিক (আপনি)</div><b>${esc(ow.exists() ? ow.data().name : 'Owner')}</b><div class="small muted">${esc(user.email || '')}</div></div><span class="badge green">সব অনুমতি</span></div></div>
        <div class="row between mt"><div class="section-head" style="margin:0"><h2>স্টাফ (${bn(list.length)})</h2></div><button class="btn sm" id="addS">${icon('plus', 'sm')} স্টাফ যোগ</button></div>
        <div class="list mt-s" id="slist">${list.length ? list.map((x) => `
          <div class="card mt-s"><div class="row between"><div><b>${esc(x.name || '—')}</b><div class="small muted">${esc(x.email || '')}</div></div><span class="badge ${x.active ? 'green' : 'red'}">${x.active ? 'সক্রিয়' : 'বন্ধ'}</span></div>
            <div class="small mt-s">${PERMS.filter(([k]) => (x.perms || {})[k]).map(([k]) => `<span class="badge blue" style="margin:2px">${esc(k)}</span>`).join('') || '<span class="muted">কোনো অনুমতি নেই</span>'}</div>
            <div class="row mt-s" style="gap:8px"><button class="btn sm ghost" data-edit="${esc(x.id)}">পারমিশন বদলান</button><button class="btn sm danger" data-rm="${esc(x.id)}">সরিয়ে দিন</button></div></div>`).join('') : '<div class="muted small">এখনো কোনো স্টাফ নেই।</div>'}</div>
        <div class="card mt" style="border-color:var(--danger)"><div class="card-title" style="color:var(--danger)">মালিকানা হস্তান্তর</div>
          <p class="small muted">অন্য কাউকে পুরো মালিক বানাতে পারেন। হস্তান্তরের পর সে স্টাফ-ম্যানেজমেন্টসহ সবকিছুর নিয়ন্ত্রণ পাবে এবং আপনি সাধারণ স্টাফ হয়ে যাবেন (ফেরত নিতে তার অনুমতি লাগবে)।</p>
          <button class="btn danger" id="xfer">মালিকানা হস্তান্তর করুন</button></div>`);
      const byId = Object.fromEntries(list.map((x) => [x.id, x]));

      $('#addS').addEventListener('click', () => openModal(`<h3>স্টাফ যোগ করুন</h3><p class="small muted mb">যাকে যোগ করবেন তাকে আগে অ্যাপে রেজিস্টার করতে হবে।</p><div id="serr" class="form-error hidden"></div>
        <form id="sform" novalidate><div class="field"><label>তার ইমেইল</label><input class="input" id="sMail" type="email" inputmode="email" autocomplete="off"></div>
        <div class="card-title" style="margin-top:8px">পারমিশন</div>${permBoxes({})}
        <div class="actions"><button type="button" class="btn ghost" data-x>বাতিল</button><button class="btn" id="sOk" type="submit">যোগ করুন</button></div></form>`, {
        onMount: (m, close) => {
          m.querySelector('[data-x]').addEventListener('click', close);
          m.querySelector('#sform').addEventListener('submit', async (e) => {
            e.preventDefault();
            const err = (t) => { const b = m.querySelector('#serr'); b.textContent = t; b.classList.remove('hidden'); };
            await withLock(m.querySelector('#sOk'), async () => {
              try {
                const u = await findUser(m.querySelector('#sMail').value);
                if (u.id === user.uid) throw new AppError('আপনি নিজেই মালিক।');
                await setDoc(doc(db, 'staff', u.id), { uid: u.id, name: u.name || '', email: u.email, active: true, perms: readPerms(m), addedBy: user.uid, createdAt: serverTimestamp() });
                await logAdmin('staff_add', { uid: u.id });
                close(); toast('স্টাফ যোগ হয়েছে। তিনি আবার লগইন করলে প্যানেল পাবেন।'); render();
              } catch (ex) { err(errMsg(ex)); }
            });
          });
        }
      }));

      $('#slist').addEventListener('click', async (e) => {
        const ed = e.target.closest('[data-edit]'), rm = e.target.closest('[data-rm]');
        if (ed) {
          const x = byId[ed.dataset.edit];
          openModal(`<h3>${esc(x.name)} — পারমিশন</h3><div id="eerr" class="form-error hidden"></div>
            <label class="check"><input type="checkbox" id="eAct" ${x.active ? 'checked' : ''}> সক্রিয় (বন্ধ করলে প্যানেলে ঢুকতে পারবে না)</label>
            <div class="card-title" style="margin-top:10px">পারমিশন</div>${permBoxes(x.perms)}
            <div class="actions"><button type="button" class="btn ghost" data-x>বাতিল</button><button class="btn" id="eOk">সংরক্ষণ</button></div>`, {
            onMount: (m, close) => {
              m.querySelector('[data-x]').addEventListener('click', close);
              m.querySelector('#eOk').addEventListener('click', async (ev) => {
                const btn = ev.currentTarget;
                await withLock(btn, async () => {
                  try {
                    await updateDoc(doc(db, 'staff', x.id), { perms: readPerms(m), active: m.querySelector('#eAct').checked, updatedAt: serverTimestamp() });
                    await logAdmin('staff_update', { uid: x.id });
                    close(); toast('সংরক্ষিত হয়েছে।'); render();
                  } catch (ex) { const b = m.querySelector('#eerr'); b.textContent = errMsg(ex); b.classList.remove('hidden'); }
                });
              });
            }
          });
        } else if (rm) {
          const x = byId[rm.dataset.rm];
          const btn = rm;
          if (!(await confirmDialog(`${x.name} কে স্টাফ থেকে সরিয়ে দেবেন?`, { title: 'স্টাফ সরান', okText: 'সরিয়ে দিন', danger: true }))) return;
          await withLock(btn, async () => {
            try { await deleteDoc(doc(db, 'staff', x.id)); await logAdmin('staff_remove', { uid: x.id }); toast('সরানো হয়েছে।'); render(); }
            catch (ex) { toast(errMsg(ex), 'err'); }
          });
        }
      });

      $('#xfer').addEventListener('click', () => openModal(`<h3>মালিকানা হস্তান্তর</h3>
        <div class="notice warn mb">${icon('alert')}<div>এটি ফেরানো যাবে না। নতুন মালিক চাইলে আপনাকেও সরিয়ে দিতে পারবে।</div></div><div id="xerr" class="form-error hidden"></div>
        <form id="xform" novalidate><div class="field"><label>নতুন মালিকের ইমেইল (রেজিস্টার্ড হতে হবে)</label><input class="input" id="xMail" type="email" inputmode="email" autocomplete="off"></div>
        <div class="field"><label>নিশ্চিত করতে লিখুন: হস্তান্তর</label><input class="input" id="xConf" autocomplete="off"></div>
        <div class="actions"><button type="button" class="btn ghost" data-x>বাতিল</button><button class="btn danger" id="xOk" type="submit">হস্তান্তর করুন</button></div></form>`, {
        onMount: (m, close) => {
          m.querySelector('[data-x]').addEventListener('click', close);
          m.querySelector('#xform').addEventListener('submit', async (e) => {
            e.preventDefault();
            const err = (t) => { const b = m.querySelector('#xerr'); b.textContent = t; b.classList.remove('hidden'); };
            if (m.querySelector('#xConf').value.trim() !== 'হস্তান্তর') return err('নিশ্চিত করতে "হস্তান্তর" লিখুন।');
            await withLock(m.querySelector('#xOk'), async () => {
              try {
                const u = await findUser(m.querySelector('#xMail').value);
                if (u.id === user.uid) throw new AppError('আপনি ইতোমধ্যে মালিক।');
                const b = writeBatch(db);
                b.set(doc(db, 'config', 'owner'), { uid: u.id, name: u.name || '', email: u.email, previousOwner: user.uid, updatedAt: serverTimestamp() });
                b.delete(doc(db, 'staff', u.id));
                // আগের মালিক সাধারণ স্টাফ হিসেবে থাকেন (স্টাফ-ম্যানেজমেন্ট ছাড়া)
                b.set(doc(db, 'staff', user.uid), { uid: user.uid, name: ow.exists() ? ow.data().name : '', email: user.email || '', active: true, perms: ALL_PERMS, addedBy: u.id, createdAt: serverTimestamp() });
                b.set(doc(collection(db, 'admin_logs')), { adminId: user.uid, action: 'ownership_transfer', details: { to: u.id }, createdAt: serverTimestamp() });
                await b.commit();
                close(); toast('মালিকানা হস্তান্তর হয়েছে।'); setTimeout(() => location.replace('index.html'), 900);
              } catch (ex) { err(errMsg(ex)); }
            });
          });
        }
      }));
    } catch (e) { failView(e); }
  }
  render();
}

const pages = { staff: staffPage, dashboard, tournaments: tournamentsPage, users: usersPage, deposits: depositsPage, withdrawals: withdrawalsPage, results: resultsPage, notifications: notificationsPage, settings: settingsPage };
if (pages[page]) pages[page]();
