// =====================================================================
// Jitboi — js/auth.js  (login / register / forgot-password)
// =====================================================================
import {
  auth, db,
  createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail,
  updateProfile, onAuthStateChanged, setPersistence, browserLocalPersistence, browserSessionPersistence,
  doc, setDoc, serverTimestamp
} from '../firebase.js';
import { $, errMsg, icon, withLock } from './ui.js';
import { getAccess } from './access.js';

const page = document.body.dataset.page;
let registering = false;

function showMsg(kind, text) {
  const box = $('#msg');
  box.className = kind === 'ok' ? 'form-ok' : 'form-error';
  box.textContent = text;
  box.classList.remove('hidden');
}
const clearMsg = () => $('#msg').classList.add('hidden');
const validEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);

function nextUrl() {
  const n = new URLSearchParams(location.search).get('next');
  // শুধু একই সাইটের সাধারণ ফাইলনামে রিডাইরেক্ট (open-redirect রোধ)
  if (n && /^[a-z0-9\-]+\.html(\?[\w=&%\-]*)?$/i.test(n)) return n;
  return 'index.html';
}
// মালিক/স্টাফ হলে সরাসরি তাদের প্যানেলে; সাধারণ ইউজার কোনো লিংক/বাটন দেখে না
async function landing(uid) {
  try { if ((await getAccess(uid)).staff) return 'admin/index.html'; } catch { /* সাধারণ ইউজার */ }
  return nextUrl();
}

// পাসওয়ার্ড দেখা/লুকানো
document.querySelectorAll('.pw button').forEach((b) => {
  b.innerHTML = icon('eye');
  b.addEventListener('click', () => {
    const i = b.parentElement.querySelector('input');
    i.type = i.type === 'password' ? 'text' : 'password';
  });
});

// রেফার লিংক (?ref=CODE) থেকে কোড আগে থেকে বসানো
if (page === 'register') { const r = new URLSearchParams(location.search).get('ref'); if (r) $('#ref').value = r.toUpperCase().slice(0, 12); }

// ইতোমধ্যে লগইন থাকলে সরাসরি অ্যাপে (রেজিস্ট্রেশন চলাকালীন নয়)
if (page !== 'forgot') {
  onAuthStateChanged(auth, (u) => { if (u && !registering) landing(u.uid).then((x) => location.replace(x)); });
}

// ---------------------------------------------------------------- Login
if (page === 'login') {
  $('#form').addEventListener('submit', async (e) => {
    e.preventDefault();
    clearMsg();
    const email = $('#email').value.trim();
    const password = $('#password').value;
    if (!validEmail(email)) return showMsg('err', 'সঠিক ইমেইল ঠিকানা লিখুন।');
    if (!password) return showMsg('err', 'পাসওয়ার্ড লিখুন।');
    await withLock($('#submit'), async () => {
      try {
        await setPersistence(auth, $('#remember').checked ? browserLocalPersistence : browserSessionPersistence);
        const cr = await signInWithEmailAndPassword(auth, email, password);
        location.replace(await landing(cr.user.uid));
      } catch (err) {
        showMsg('err', errMsg(err));
      }
    });
  });
}

// ---------------------------------------------------------------- Register
if (page === 'register') {
  $('#form').addEventListener('submit', async (e) => {
    e.preventDefault();
    clearMsg();
    const name = $('#name').value.trim().replace(/\s+/g, ' ');
    const email = $('#email').value.trim();
    const password = $('#password').value;
    const confirm = $('#confirm').value;
    if (name.length < 2 || name.length > 50) return showMsg('err', 'পুরো নাম ২ থেকে ৫০ অক্ষরের মধ্যে লিখুন।');
    if (!validEmail(email)) return showMsg('err', 'সঠিক ইমেইল ঠিকানা লিখুন।');
    if (password.length < 6) return showMsg('err', 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
    if (password !== confirm) return showMsg('err', 'পাসওয়ার্ড দুটি মিলছে না।');
    const refRaw = ($('#ref').value || '').trim().toUpperCase();
    if (refRaw && !/^[A-Z0-9]{4,12}$/.test(refRaw)) return showMsg('err', 'রেফার কোড সঠিক নয় (শুধু ইংরেজি অক্ষর ও সংখ্যা)।');
    if (!$('#terms').checked) return showMsg('err', 'শর্তাবলীতে সম্মত হতে হবে।');

    await withLock($('#submit'), async () => {
      registering = true;
      try {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        const user = cred.user;
        try { await updateProfile(user, { displayName: name }); } catch { /* গুরুত্বপূর্ণ নয় */ }
        // Auth UID-ই ডকুমেন্ট ID; role সবসময় "user" — Firestore Rules-ও এটি বাধ্যতামূলক করে
        const code = user.uid.slice(0, 6).toUpperCase();
        const profile = {
          uid: user.uid,
          name,
          email: user.email,
          role: 'user',
          status: 'active',
          balance: 0,
          winBalance: 0,
          totalMatches: 0,
          totalWins: 0,
          referralCode: code,
          createdAt: serverTimestamp()
        };
        if (refRaw && refRaw !== code) profile.referredBy = refRaw;
        await setDoc(doc(db, 'users', user.uid), profile);
        showMsg('ok', 'আপনার অ্যাকাউন্ট তৈরি হয়েছে।');
        setTimeout(() => location.replace('index.html'), 700);
      } catch (err) {
        // Auth অ্যাকাউন্ট তৈরি হয়ে গেলে প্রোফাইল ডক পরের লগইনে স্বয়ংক্রিয়ভাবে তৈরি হবে
        if (auth.currentUser) {
          showMsg('ok', 'অ্যাকাউন্ট তৈরি হয়েছে। প্রোফাইল সেটআপ চলছে...');
          setTimeout(() => location.replace('index.html'), 900);
        } else {
          registering = false;
          showMsg('err', errMsg(err));
        }
      }
    });
  });
}

// ---------------------------------------------------------------- Forgot password
if (page === 'forgot') {
  $('#form').addEventListener('submit', async (e) => {
    e.preventDefault();
    clearMsg();
    const email = $('#email').value.trim();
    if (!validEmail(email)) return showMsg('err', 'সঠিক ইমেইল ঠিকানা লিখুন।');
    await withLock($('#submit'), async () => {
      try {
        await sendPasswordResetEmail(auth, email);
        showMsg('ok', 'পাসওয়ার্ড রিসেট লিংক পাঠানো হয়েছে। ইনবক্স (এবং স্প্যাম ফোল্ডার) দেখুন।');
      } catch (err) {
        // ইউজার আছে কি নেই তা প্রকাশ না করার জন্য user-not-found আলাদা করে দেখানো হয় না
        if (err.code === 'auth/user-not-found') showMsg('ok', 'ইমেইলটি নিবন্ধিত থাকলে রিসেট লিংক পাঠানো হয়েছে।');
        else showMsg('err', errMsg(err));
      }
    });
  });
}
