// =====================================================================
// Jitboi — js/tournaments.js
//   data-page="tournaments" → ম্যাচ তালিকা
//   data-page="details"     → ম্যাচ বিস্তারিত + জয়েন
//   data-page="mine"        → আমার গেম
// =====================================================================
import {
  db, collection, doc, getDoc, getDocs, query, where, orderBy, limit,
  runTransaction, serverTimestamp, updateDoc
} from '../firebase.js';
import {
  $, $$, boot, esc, bn, taka, icon, emptyState, tournamentCard, tournamentBucket, fmtMatch,
  setView, showError, toast, errMsg, AppError, withLock, openModal, gameList, gameMeta, walletTotal,
  safeUrl, tBadge, badge, PSTATUS, qs, copyText, cdTs
} from './ui.js';

const page = document.body.dataset.page;

const DEFAULT_RULES = [
  'ম্যাচ শুরুর আগে রুম আইডি ও পাসওয়ার্ড দিয়ে সময়মতো রুমে জয়েন করুন। দেরিতে এলে এন্ট্রি ফি ফেরত হবে না।',
  'রেজিস্ট্রেশনের সময় সঠিক গেমের নাম ও UID দিন। ভুল তথ্যের দায় খেলোয়াড়ের।',
  'হ্যাক, ইমুলেটর, স্ক্রিপ্ট বা কোনো অনৈতিক সফটওয়্যার ব্যবহার করলে স্থায়ীভাবে নিষিদ্ধ ও প্রাইজ বাতিল হবে।',
  'রুম আইডি ও পাসওয়ার্ড অন্য কাউকে শেয়ার করবেন না।',
  'কিল ও র‍্যাঙ্ক অ্যাডমিন যাচাই করে ফলাফল প্রকাশ করবেন। অ্যাডমিনের সিদ্ধান্তই চূড়ান্ত।'
];

// প্রকাশিত রুম তথ্য — Firestore Rules শুধু নিশ্চিত অংশগ্রহণকারীকে (এবং প্রকাশের পর) পড়তে দেয়
export async function loadRoom(tid) {
  try {
    const s = await getDoc(doc(db, 'tournaments', tid, 'private', 'room'));
    if (s.exists() && s.data().released) return s.data();
  } catch { /* অনুমতি নেই / প্রকাশিত হয়নি */ }
  return null;
}

function roomBox(room) {
  return `<div class="room-box mt-s">
    <div class="kv"><span class="k">রুম আইডি</span><span class="v num">${esc(room.roomId || '—')} ${room.roomId ? `<span class="copy" data-copy="${esc(room.roomId)}">${icon('copy', 'sm')}</span>` : ''}</span></div>
    <div class="kv"><span class="k">রুম পাসওয়ার্ড</span><span class="v num">${esc(room.roomPassword || '—')} ${room.roomPassword ? `<span class="copy" data-copy="${esc(room.roomPassword)}">${icon('copy', 'sm')}</span>` : ''}</span></div>
  </div>`;
}
document.addEventListener('click', (e) => {
  const c = e.target.closest('[data-copy]');
  if (c) copyText(c.dataset.copy);
});

// ---------------------------------------------------------------- তালিকা
async function listPage() {
  const { settings } = await boot({ nav: 'tournaments' });
  try {
    const snap = await getDocs(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc'), limit(100)));
    const all = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    const games = Array.from(new Set([...gameList(settings), ...all.map((t) => t.game).filter(Boolean)]));
    let game = qs('game') || 'all';
    let tab = ['open', 'live', 'upcoming', 'done', 'all'].includes(qs('tab')) ? qs('tab') : 'open';
    let mode = 'all';

    const tabs = [['open', 'চালু'], ['live', 'লাইভ'], ['upcoming', 'আসন্ন'], ['done', 'সমাপ্ত'], ['all', 'সব']];
    const match = (t) => {
      if (game !== 'all' && t.game !== game) return false;
      if (mode !== 'all' && (t.mode || '').toLowerCase() !== mode.toLowerCase()) return false;
      if (tab === 'open') return t.status === 'registration_open';
      if (tab === 'live') return t.status === 'live';
      if (tab === 'upcoming') return t.status === 'upcoming' || t.status === 'full';
      if (tab === 'done') return t.status === 'completed' || t.status === 'cancelled';
      return true;
    };
    const modes = Array.from(new Set(all.map((t) => t.mode).filter(Boolean)));
    const count = (k) => { const old = tab; tab = k; const n = all.filter(match).length; tab = old; return n; };

    function render() {
      const list = all.filter(match);
      setView(`
        <div class="page-head"><h1>ম্যাচ ও টুর্নামেন্ট</h1><p>গেম বেছে নিয়ে জয়েন করুন</p></div>
        <div class="chips" id="chips"><span class="chip ${game === 'all' ? 'active' : ''}" data-game="all">সব গেম</span>${games.map((g) => `<span class="chip ${game === g ? 'active' : ''}" data-game="${esc(g)}">${esc(g)}</span>`).join('')}</div>
        <div class="tabs mt-s" id="tabs">${tabs.map(([k, l]) => `<button class="tab ${tab === k ? 'active' : ''}" data-tab="${k}">${l} <small>(${bn(count(k))})</small></button>`).join('')}</div>
        ${modes.length > 1 ? `<div class="chips mt-s" id="modes"><span class="chip ${mode === 'all' ? 'active' : ''}" data-mode="all">সব মোড</span>${modes.map((m) => `<span class="chip ${mode === m ? 'active' : ''}" data-mode="${esc(m)}">${esc(m)}</span>`).join('')}</div>` : ''}
        <div class="mt">${list.length
          ? `<div class="grid auto">${list.map((t) => tournamentCard(t)).join('')}</div>`
          : emptyState(all.length ? 'এই ফিল্টারে কোনো ম্যাচ নেই' : 'এখনো কোনো ম্যাচ নেই', all.length ? 'অন্য ট্যাব বা গেম বেছে দেখুন।' : 'নতুন ম্যাচ যোগ হলে এখানে দেখতে পাবেন।', 'trophy')}</div>`);
      $$('#tabs [data-tab]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; render(); }));
      $$('#chips [data-game]').forEach((b) => b.addEventListener('click', () => { game = b.dataset.game; render(); }));
      $$('#modes [data-mode]').forEach((b) => b.addEventListener('click', () => { mode = b.dataset.mode; render(); }));
    }
    render();
  } catch (e) { showError(e); }
}

// ---------------------------------------------------------------- বিস্তারিত
async function detailsPage() {
  const ctx = await boot({ title: 'ম্যাচ বিস্তারিত', back: true, backHref: 'tournaments.html', nav: 'tournaments' });
  const { user, profile } = ctx;
  const id = qs('id');
  if (!id) return setView(emptyState('ম্যাচ পাওয়া যায়নি', '', 'trophy', '<a class="btn" href="tournaments.html">তালিকায় ফিরুন</a>'));

  async function render() {
    try {
      const [tSnap, pSnap] = await Promise.all([
        getDoc(doc(db, 'tournaments', id)),
        getDoc(doc(db, 'tournament_players', `${id}_${user.uid}`))
      ]);
      if (!tSnap.exists()) return setView(emptyState('ম্যাচ পাওয়া যায়নি', 'এটি মুছে ফেলা হয়ে থাকতে পারে।', 'trophy', '<a class="btn" href="tournaments.html">তালিকায় ফিরুন</a>'));
      const t = { id: tSnap.id, ...tSnap.data() };
      const part = pSnap.exists() ? pSnap.data() : null;
      const max = Number(t.maxPlayers || 0), joined = Number(t.joinedPlayers || 0);
      const full = joined >= max;
      const canJoin = !part && t.status === 'registration_open' && !full;
      const img = safeUrl(t.imageUrl);
      const gm = gameMeta(t.game);
      const activeStatus = ['registration_open', 'full', 'live', 'upcoming'].includes(t.status);
      const room = part && part.status === 'registered' && t.roomReleased && activeStatus ? await loadRoom(id) : null;
      const perKill = Number(t.perKill || 0);

      const prizes = Array.isArray(t.prizes) ? t.prizes : [];
      const rules = (t.rules || '').trim() ? t.rules.trim().split('\n').filter(Boolean) : DEFAULT_RULES;
      const results = t.resultsPublished && Array.isArray(t.results) ? [...t.results].sort((a, b) => (a.position || 99) - (b.position || 99)) : [];
      const pct = max > 0 ? Math.min(100, Math.round((joined / max) * 100)) : 0;
      const showTimer = ['registration_open', 'upcoming', 'full'].includes(t.status) && cdTs(t) > Date.now();

      let action = '';
      if (part) {
        const [lbl, cls] = PSTATUS[part.status] || [part.status, ''];
        action = `<div class="card"><div class="notice ${part.status === 'registered' ? 'ok' : 'warn'}">${icon(part.status === 'registered' ? 'check' : 'clock')}<div>${part.status === 'registered'
          ? 'আপনার টুর্নামেন্টে যোগদান সফল হয়েছে।'
          : part.status === 'pending_payment'
            ? `আপনার জয়েন অনুরোধ জমা আছে। অ্যাডমিন ওয়ালেট যাচাই করে এন্ট্রি ফি (${taka(part.entryFee)}) কেটে নিশ্চিত করবেন। ফি এখনো কাটা হয়নি।`
            : 'আপনার রেজিস্ট্রেশন বাতিল করা হয়েছে।'}</div></div>
          <div class="kv"><span class="k">স্ট্যাটাস</span><span class="v"><span class="badge ${cls}">${esc(lbl)}</span></span></div>
          <div class="kv"><span class="k">গেমের নাম</span><span class="v">${esc(part.playerName)}</span></div>
          <div class="kv"><span class="k">গেম UID</span><span class="v">${esc(part.playerId)}</span></div>
          ${room ? `<div class="section-head" style="margin:14px 0 4px"><h2>রুম তথ্য</h2></div>${roomBox(room)}` : (part.status === 'registered' && activeStatus ? `<p class="small muted mt-s">${icon('lock', 'sm')} রুম আইডি ও পাসওয়ার্ড ম্যাচের আগে অ্যাডমিন প্রকাশ করবেন।</p>` : '')}</div>`;
      } else if (canJoin) {
        action = `<div class="sticky-join"><button class="btn block" id="joinBtn" style="height:52px;font-size:16px">${icon('gamepad', 'sm')} জয়েন করুন ${t.entryFee > 0 ? '• ' + taka(t.entryFee) : '• ফ্রি'}</button></div>`;
      } else {
        action = `<button class="btn block ghost" disabled>${t.status === 'cancelled' ? 'ম্যাচ বাতিল' : t.status === 'completed' ? 'ম্যাচ সমাপ্ত' : t.status === 'live' ? 'ম্যাচ চলছে — রেজিস্ট্রেশন বন্ধ' : full || t.status === 'full' ? 'স্লট পূর্ণ' : 'রেজিস্ট্রেশন এখনো শুরু হয়নি'}</button>`;
      }

      setView(`
        <div class="td-cover" style="background:${gm.grad}" data-mark="${esc(gm.mark)}">${img ? `<img src="${esc(img)}" alt="" onerror="this.remove()">` : ''}
          <div><div class="row wrap" style="gap:6px">${tBadge(t.status)}<span class="tag">${esc(t.game)}</span><span class="tag">${esc(t.mode || '')}</span>${t.version ? `<span class="tag">${esc(t.version)}</span>` : ''}${t.map ? `<span class="tag">${esc(t.map)}</span>` : ''}</div><h1>${esc(t.title)}</h1></div></div>

        ${showTimer ? `<div class="cdbox" data-cdbox data-ts="${cdTs(t)}"><div><b>০০</b><span>দিন</span></div><div><b>০০</b><span>ঘণ্টা</span></div><div><b>০০</b><span>মিনিট</span></div><div><b>০০</b><span>সেকেন্ড</span></div></div>` : ''}

        <div class="grid three mt">
          <div class="stat"><div class="label">এন্ট্রি ফি</div><div class="value">${t.entryFee > 0 ? taka(t.entryFee) : 'ফ্রি'}</div></div>
          <div class="stat"><div class="label">প্রাইজ পুল</div><div class="value accent">${taka(t.prizePool)}</div></div>
          <div class="stat"><div class="label">${perKill > 0 ? 'পার কিল' : 'মোড'}</div><div class="value">${perKill > 0 ? taka(perKill) : esc(t.mode || '—')}</div></div>
        </div>

        <div class="card mt">
          <div class="row between small muted" style="margin-bottom:6px"><span>${bn(joined)}/${bn(max)} জন যোগ দিয়েছেন</span><span>${max - joined > 0 ? bn(max - joined) + ' স্লট বাকি' : 'স্লট পূর্ণ'}</span></div>
          <div class="progress"><i style="width:${pct}%"></i></div>
          <div class="kv mt-s"><span class="k">গেম</span><span class="v">${esc(t.game)}</span></div>
          <div class="kv"><span class="k">মোড</span><span class="v">${esc(t.mode || '—')}</span></div>
          ${t.version ? `<div class="kv"><span class="k">ভার্সন</span><span class="v">${esc(t.version)}</span></div>` : ''}
          ${t.map ? `<div class="kv"><span class="k">ম্যাপ</span><span class="v">${esc(t.map)}</span></div>` : ''}
          <div class="kv"><span class="k">ম্যাচের সময়</span><span class="v">${esc(fmtMatch(t))}</span></div>
          <div class="kv"><span class="k">রেজিস্ট্রেশন</span><span class="v">${t.status === 'registration_open' ? (full ? 'পূর্ণ' : 'চালু আছে') : t.status === 'upcoming' ? 'এখনো শুরু হয়নি' : 'বন্ধ'}</span></div>
        </div>

        <div class="mt">${action}</div>

        ${t.description ? `<div class="section-head"><h2>বিবরণ</h2></div><div class="card"><p class="pre">${esc(t.description)}</p></div>` : ''}

        <div class="section-head"><h2>প্রাইজ বণ্টন</h2></div>
        <div class="card">${prizes.length || perKill > 0
          ? `${prizes.map((p) => `<div class="prize-row"><div class="rank ${p.position <= 3 ? 'r' + p.position : ''}">${bn(p.position)}</div><div class="grow">${bn(p.position)} নং স্থান</div><div class="num" style="color:var(--accent-2);font-size:18px">${taka(p.amount)}</div></div>`).join('')}
             ${perKill > 0 ? `<div class="prize-row"><div class="rank" style="background:var(--danger-soft);color:var(--danger)">${icon('target', 'sm')}</div><div class="grow">প্রতি কিলে</div><div class="num" style="color:var(--accent-2);font-size:18px">${taka(perKill)}</div></div>` : ''}`
          : `<p class="muted">মোট প্রাইজ পুল ${taka(t.prizePool)}। বিস্তারিত বণ্টন অ্যাডমিন ঘোষণা করবেন।</p>`}</div>

        ${results.length ? `<div class="section-head"><h2>চূড়ান্ত ফলাফল</h2></div><div class="list">${results.map((r) => `<div class="item"><div class="rank ${r.position <= 3 ? 'r' + r.position : ''}">${bn(r.position)}</div><div class="grow"><div class="t">${esc(r.playerName)}</div><div class="s">${r.kills ? bn(r.kills) + ' কিল' : 'র‍্যাঙ্ক ' + bn(r.position)}</div></div><div class="num" style="color:var(--accent-2);font-size:17px">${r.prize ? taka(r.prize) : '—'}</div></div>`).join('')}</div>` : ''}

        <div class="section-head"><h2>নিয়মাবলী</h2></div>
        <div class="card"><ol style="margin:0;padding-left:20px;color:var(--muted);display:flex;flex-direction:column;gap:8px">${rules.map((r) => `<li>${esc(r)}</li>`).join('')}</ol></div>`);

      const jb = $('#joinBtn');
      if (jb) jb.addEventListener('click', () => openJoin(t));
    } catch (e) { showError(e); }
  }

  function openJoin(t) {
    const fee = Number(t.entryFee || 0);
    const total = walletTotal(profile);
    if (fee > 0 && total < fee) {
      openModal(`<h3>পর্যাপ্ত ব্যালেন্স নেই</h3><p class="muted">আপনার পর্যাপ্ত ব্যালেন্স নেই। এন্ট্রি ফি ${taka(fee)}, আপনার মোট ব্যালেন্স ${taka(total)}। আগে ওয়ালেটে টাকা যোগ করুন।</p>
        <div class="actions"><button class="btn ghost" data-x>বন্ধ করুন</button><a class="btn" href="deposit.html">টাকা যোগ করুন</a></div>`,
        { onMount: (m, close) => m.querySelector('[data-x]').addEventListener('click', close) });
      return;
    }
    openModal(`
      <h3>ম্যাচে জয়েন করুন</h3>
      <p class="muted small" style="margin-bottom:14px">${esc(t.title)}</p>
      ${fee > 0 ? `<div class="notice warn mb">${icon('info')}<div>এন্ট্রি ফি ${taka(fee)}। অ্যাডমিন আপনার ওয়ালেট যাচাই করে ফি কেটে নেওয়ার পর জয়েন নিশ্চিত হবে। যাচাইয়ের আগে এটি শুধু একটি অনুরোধ।</div></div>` : ''}
      <div id="jerr" class="form-error hidden"></div>
      <form id="jform" novalidate>
        <div class="field"><label>গেমের নাম (In-game Name)</label><input class="input" id="jName" maxlength="30" placeholder="গেমে আপনার নাম" autocomplete="off" value="${esc(profile.gameName || '')}"></div>
        <div class="field"><label>গেম UID / প্লেয়ার আইডি</label><input class="input" id="jPid" maxlength="30" placeholder="যেমন: 1234567890" autocomplete="off" inputmode="text" value="${esc(profile.gameId || '')}"></div>
        <div class="field"><label>টিমের নাম (ঐচ্ছিক)</label><input class="input" id="jTeam" maxlength="30" placeholder="টিমের নাম" autocomplete="off"></div>
        <label class="check mb"><input type="checkbox" id="jAgree"> আমি নিয়মাবলী পড়েছি এবং কোনো হ্যাক/চিট ব্যবহার করব না।</label>
        <div class="actions"><button type="button" class="btn ghost" data-x>বাতিল</button><button class="btn" id="jSubmit" type="submit">নিশ্চিত করুন</button></div>
      </form>`, {
      onMount: (m, close) => {
        m.querySelector('[data-x]').addEventListener('click', close);
        m.querySelector('#jform').addEventListener('submit', async (e) => {
          e.preventDefault();
          const err = (msg) => { const b = m.querySelector('#jerr'); b.textContent = msg; b.classList.remove('hidden'); };
          const playerName = m.querySelector('#jName').value.trim();
          const playerId = m.querySelector('#jPid').value.trim();
          const teamName = m.querySelector('#jTeam').value.trim();
          if (playerName.length < 2 || playerName.length > 30) return err('গেমের নাম ২ থেকে ৩০ অক্ষরের হতে হবে।');
          if (playerId.length < 3 || playerId.length > 30 || /\s/.test(playerId)) return err('সঠিক গেম UID লিখুন (স্পেস ছাড়া, ৩–৩০ অক্ষর)।');
          if (!m.querySelector('#jAgree').checked) return err('নিয়মাবলীতে সম্মত হতে টিক দিন।');
          await withLock(m.querySelector('#jSubmit'), async () => {
            try {
              const status = await joinTournament(t.id, user, profile, { playerName, playerId, teamName });
              // পরেরবার অটো-ফিলের জন্য সংরক্ষণ (শুধু নিরাপদ ফিল্ড)
              if (profile.gameName !== playerName || profile.gameId !== playerId) {
                try { await updateDoc(doc(db, 'users', user.uid), { gameName: playerName, gameId: playerId }); profile.gameName = playerName; profile.gameId = playerId; } catch { /* ignore */ }
              }
              close();
              toast(status === 'registered' ? 'আপনার টুর্নামেন্টে যোগদান সফল হয়েছে।' : 'আপনার জয়েন অনুরোধ জমা হয়েছে। অ্যাডমিন ফি যাচাই করবেন।');
              render();
            } catch (ex) {
              err(errMsg(ex));
            }
          });
        });
      }
    });
  }

  render();
}

// জয়েন লজিক — Firestore Transaction (ডুপ্লিকেট ও স্লট রেস কন্ডিশন ঠেকায়)
async function joinTournament(tid, user, profile, form) {
  const tRef = doc(db, 'tournaments', tid);
  const pRef = doc(db, 'tournament_players', `${tid}_${user.uid}`); // নির্ধারিত ID = একজন একবারই
  return runTransaction(db, async (tx) => {
    const [tSnap, pSnap] = await Promise.all([tx.get(tRef), tx.get(pRef)]);
    if (!tSnap.exists()) throw new AppError('ম্যাচটি পাওয়া যায়নি।');
    if (pSnap.exists()) throw new AppError('এই টুর্নামেন্টে ইতোমধ্যে যোগ দিয়েছেন।');
    const t = tSnap.data();
    if (t.status !== 'registration_open') throw new AppError('এই ম্যাচের রেজিস্ট্রেশন এখন বন্ধ।');
    const joined = t.joinedPlayers || 0;
    if (joined >= t.maxPlayers) throw new AppError('দুঃখিত, ম্যাচের সব স্লট পূর্ণ হয়ে গেছে।');
    const fee = Number(t.entryFee || 0);
    const base = {
      tournamentId: tid,
      userId: user.uid,
      userName: profile.name,
      playerName: form.playerName,
      playerId: form.playerId,
      teamName: form.teamName || '',
      entryFee: fee,
      joinedAt: serverTimestamp()
    };
    if (fee === 0) {
      tx.set(pRef, { ...base, status: 'registered' });
      const n = joined + 1;
      tx.update(tRef, n >= t.maxPlayers ? { joinedPlayers: n, status: 'full' } : { joinedPlayers: n });
      return 'registered';
    }
    // পেইড: শুধু অনুরোধ — টাকা কাটা/স্লট গণনা হয় অ্যাডমিন যাচাইয়ের পর
    tx.set(pRef, { ...base, status: 'pending_payment' });
    return 'pending_payment';
  });
}

// ---------------------------------------------------------------- আমার গেম
async function minePage() {
  const { user } = await boot({ nav: 'mygames' });
  let tab = 'upcoming';
  try {
    const ps = await getDocs(query(collection(db, 'tournament_players'), where('userId', '==', user.uid)));
    const parts = ps.docs.map((d) => ({ id: d.id, ...d.data() }));
    const ids = Array.from(new Set(parts.map((p) => p.tournamentId)));
    const snaps = await Promise.all(ids.map((i) => getDoc(doc(db, 'tournaments', i)).catch(() => null)));
    const tmap = {};
    snaps.forEach((s) => { if (s && s.exists()) tmap[s.id] = { id: s.id, ...s.data() }; });

    const rows = parts.filter((p) => tmap[p.tournamentId]).map((p) => ({ p, t: tmap[p.tournamentId] }))
      .sort((a, b) => (a.t.matchDate + (a.t.matchTime || '')).localeCompare(b.t.matchDate + (b.t.matchTime || '')));

    const roomMap = {};
    await Promise.all(rows.filter(({ p, t }) => p.status === 'registered' && t.roomReleased && tournamentBucket(t) !== 'completed')
      .map(async ({ t }) => { roomMap[t.id] = await loadRoom(t.id); }));

    function render() {
      const list = rows.filter(({ t }) => tournamentBucket(t) === tab);
      const counts = { upcoming: 0, live: 0, completed: 0 };
      rows.forEach(({ t }) => counts[tournamentBucket(t)]++);
      setView(`
        <div class="page-head"><h1>আমার গেম</h1><p>আপনি যে ম্যাচগুলোতে যোগ দিয়েছেন</p></div>
        <div class="tabs" id="tabs">${[['upcoming', 'আসন্ন'], ['live', 'লাইভ'], ['completed', 'সমাপ্ত']].map(([k, l]) => `<button class="tab ${tab === k ? 'active' : ''}" data-tab="${k}">${l} (${bn(counts[k])})</button>`).join('')}</div>
        <div class="list mt">${list.length ? list.map(({ p, t }) => {
          const room = roomMap[t.id];
          const gm = gameMeta(t.game);
          const mine = Array.isArray(t.results) ? t.results.find((r) => r.userId === user.uid) : null;
          return `<div class="card">
            <a href="tournament-details.html?id=${encodeURIComponent(t.id)}" style="color:inherit;display:flex;gap:12px;align-items:center">
              <span class="gtile"><span class="gi" style="background:${gm.grad};width:48px;height:48px;border-radius:14px;font-size:14px">${esc(gm.mark)}</span></span>
              <div class="grow"><div style="font-weight:600;font-size:16px">${esc(t.title)}</div><div class="small muted">${esc(t.game)} • ${esc(t.mode || '')} • ${esc(fmtMatch(t))}</div></div>${tBadge(t.status)}</a>
            <div class="row between mt-s"><span class="small muted">আপনার রেজিস্ট্রেশন</span>${badge(PSTATUS, p.status)}</div>
            ${p.status === 'registered' && tournamentBucket(t) !== 'completed'
              ? (room ? roomBox(room) : `<p class="small muted mt-s">${icon('lock', 'sm')} রুম আইডি ও পাসওয়ার্ড এখনো প্রকাশিত হয়নি।</p>`)
              : ''}
            ${p.status === 'registered' && tournamentBucket(t) === 'completed' && t.resultsPublished
              ? `<div class="notice ok mt-s">${icon('award')}<div>${mine ? `আপনার স্থান ${bn(mine.position)}${mine.kills ? ' • ' + bn(mine.kills) + ' কিল' : ''}${mine.prize ? ' • প্রাইজ ' + taka(mine.prize) : ''}` : 'ফলাফল প্রকাশিত হয়েছে।'}</div></div>` : ''}
            ${p.status === 'pending_payment' ? `<p class="small mt-s" style="color:var(--warn)">অ্যাডমিন এন্ট্রি ফি যাচাই করা পর্যন্ত জয়েন নিশ্চিত নয়।</p>` : ''}
          </div>`;
        }).join('') : emptyState('এখানে কিছু নেই', tab === 'upcoming' ? 'কোনো ম্যাচে জয়েন করলে এখানে দেখা যাবে।' : 'এই তালিকায় এখনো কোনো ম্যাচ নেই।', 'gamepad', tab === 'upcoming' ? '<a class="btn" href="tournaments.html">ম্যাচ দেখুন</a>' : '')}</div>`);
      $$('#tabs [data-tab]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; render(); }));
    }
    render();
  } catch (e) { showError(e); }
}

if (page === 'tournaments') listPage();
else if (page === 'details') detailsPage();
else if (page === 'mine') minePage();
