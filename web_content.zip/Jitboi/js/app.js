// =====================================================================
// Jitboi — js/app.js  (হোম, লিডারবোর্ড, হেল্প)
// =====================================================================
import { db, collection, query, where, orderBy, limit, getDocs } from '../firebase.js';
import {
  $, $$, boot, esc, bn, taka, icon, emptyState, tournamentCard, tournamentBucket, fmtMatch,
  loadNotifications, setView, showError, winRate, safeUrl, tBadge, walletTotal, gameList, gameMeta, initials
} from './ui.js';

const page = document.body.dataset.page;

const section = (title, link, body) => `
  <div class="section-head"><h2>${esc(title)}</h2>${link ? `<a href="${link[0]}">${esc(link[1])}</a>` : ''}</div>${body}`;

async function fetchTournaments() {
  const snap = await getDocs(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc'), limit(100)));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

function buildSlides(settings, featured) {
  const custom = Array.isArray(settings.banners) ? settings.banners.filter((b) => b && (b.title || b.imageUrl)) : [];
  if (custom.length) {
    return custom.slice(0, 6).map((b, i) => {
      const img = safeUrl(b.imageUrl);
      const link = safeUrl(b.link) || (b.link && /^[a-z0-9\-]+\.html/i.test(b.link) ? b.link : '');
      return `<div class="slide g${i % 3}" ${img ? `style="background-image:url('${esc(img)}')"` : ''}>
        ${b.subtitle ? `<div class="sk">${esc(b.subtitle)}</div>` : ''}<h2>${esc(b.title || '')}</h2>
        ${link ? `<a class="btn" href="${esc(link)}">বিস্তারিত</a>` : ''}</div>`;
    });
  }
  const out = [`<div class="slide g0"><div class="sk">বাংলাদেশের গেমিং টুর্নামেন্ট</div><h2>খেলুন, জিতুন, উইথড্র করুন</h2><p>Free Fire, PUBG, eFootball ও Ludo টুর্নামেন্টে যোগ দিন।</p><a class="btn" href="tournaments.html">ম্যাচ দেখুন</a></div>`];
  if (featured) out.push(`<div class="slide g1"><div class="sk">${esc(featured.game)} • ${esc(featured.mode || '')}</div><h2>${esc(featured.title)}</h2><p>প্রাইজ পুল ${taka(featured.prizePool)}${featured.perKill > 0 ? ' • পার কিল ' + taka(featured.perKill) : ''}</p><a class="btn" href="tournament-details.html?id=${encodeURIComponent(featured.id)}">জয়েন করুন</a></div>`);
  out.push(`<div class="slide g2"><div class="sk">ওয়ালেট</div><h2>ডিপোজিট করুন bKash / Nagad / Rocket এ</h2><p>অ্যাডমিন যাচাই করার পর ব্যালেন্সে যোগ হবে।</p><a class="btn" href="deposit.html">টাকা যোগ করুন</a></div>`);
  return out;
}

function mountSlider() {
  const sl = $('.slider');
  if (!sl) return;
  const track = $('.slides', sl); const n = track.children.length; const dots = $$('.dots i', sl);
  let i = 0;
  const go = (k) => { i = (k + n) % n; track.style.transform = `translateX(-${i * 100}%)`; dots.forEach((d, x) => d.classList.toggle('on', x === i)); };
  dots.forEach((d, x) => d.addEventListener('click', () => go(x)));
  if (n > 1) setInterval(() => go(i + 1), 4500);
  let sx = null;
  sl.addEventListener('touchstart', (e) => { sx = e.touches[0].clientX; }, { passive: true });
  sl.addEventListener('touchend', (e) => { if (sx === null) return; const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 40) go(i + (dx < 0 ? 1 : -1)); sx = null; });
  go(0);
}

// ---------------------------------------------------------------- Home
async function home() {
  const splash = $('#splash');
  const started = Date.now();
  const hideSplash = () => {
    if (!splash) return;
    const wait = Math.max(0, 900 - (Date.now() - started));
    setTimeout(() => { splash.classList.add('out'); setTimeout(() => splash.remove(), 600); }, wait);
  };

  const { user, profile, settings } = await boot({ nav: 'home' });
  try {
    const [tournaments, mine, notifs] = await Promise.all([
      fetchTournaments(),
      getDocs(query(collection(db, 'tournament_players'), where('userId', '==', user.uid))),
      loadNotifications(user.uid, 10).catch(() => [])
    ]);
    const joined = mine.docs.filter((d) => d.data().status === 'registered').length;
    const deposit = Number(profile.balance || 0), win = Number(profile.winBalance || 0);

    const featured = tournaments.find((t) => t.featured && ['registration_open', 'live', 'upcoming'].includes(t.status)) || tournaments.find((t) => t.status === 'registration_open');
    const live = tournaments.filter((t) => t.status === 'live');
    const open = tournaments
      .filter((t) => ['registration_open', 'upcoming', 'full'].includes(t.status))
      .sort((a, b) => (a.matchDate + (a.matchTime || '')).localeCompare(b.matchDate + (b.matchTime || '')))
      .slice(0, 8);
    const results = tournaments.filter((t) => t.resultsPublished && Array.isArray(t.results) && t.results.length).slice(0, 5);
    const slides = buildSlides(settings, featured);
    const games = gameList(settings);

    let html = '';
    if (settings.notice && settings.notice.trim()) {
      html += `<div class="marquee">${icon('speaker')}<div class="track"><span>${esc(settings.notice)}</span></div></div><div class="mt-s"></div>`;
    }
    html += `<div class="slider"><div class="slides">${slides.join('')}</div><div class="dots">${slides.map(() => '<i></i>').join('')}</div></div>`;

    html += `<div class="wcard mt">
        <div class="l">মোট ব্যালেন্স</div><div class="big">${taka(deposit + win)}</div>
        <div class="split"><div><span class="l">ডিপোজিট ওয়ালেট</span><b>${taka(deposit)}</b></div><div><span class="l">উইনিং ওয়ালেট</span><b>${taka(win)}</b></div></div>
        <div class="acts"><a class="btn" href="deposit.html">${icon('plus', 'sm')} অ্যাড মানি</a><a class="btn alt" href="withdraw.html">${icon('up', 'sm')} উইথড্র</a></div>
      </div>`;

    html += section('গেম বেছে নিন', ['tournaments.html', 'সব ম্যাচ'],
      `<div class="games">${games.map((g) => { const m = gameMeta(g); return `<a class="gtile" href="tournaments.html?game=${encodeURIComponent(g)}"><span class="gi" style="background:${m.grad}">${esc(m.mark)}</span><span>${esc(g)}</span></a>`; }).join('')}</div>`);

    html += `<div class="stat-row mt"><div class="stat"><div class="label">যোগদান</div><div class="value">${bn(joined)}</div></div>
      <div class="stat"><div class="label">ম্যাচ খেলেছেন</div><div class="value">${bn(profile.totalMatches || 0)}</div></div>
      <div class="stat"><div class="label">জয়</div><div class="value accent">${bn(profile.totalWins || 0)}</div></div></div>`;

    if (live.length) html += section('লাইভ ম্যাচ', ['tournaments.html?tab=live', 'সব দেখুন'], `<div class="h-scroll">${live.map((t) => tournamentCard(t)).join('')}</div>`);

    html += section('আসন্ন ম্যাচ', ['tournaments.html', 'সব দেখুন'],
      open.length ? `<div class="h-scroll">${open.map((t) => tournamentCard(t)).join('')}</div>`
        : emptyState('এখনো কোনো ম্যাচ নেই', 'নতুন ম্যাচ যোগ হলে এখানে দেখতে পাবেন।', 'trophy'));

    html += section('সাম্প্রতিক ফলাফল', ['leaderboard.html', 'লিডারবোর্ড'],
      results.length
        ? `<div class="list">${results.map((t) => {
            const w = [...t.results].sort((a, b) => (a.position || 99) - (b.position || 99))[0];
            return `<a class="result-card" href="tournament-details.html?id=${encodeURIComponent(t.id)}">
              <div class="row between"><div><div style="font-weight:600">${esc(t.title)}</div><div class="small muted">${esc(t.game)} • ${esc(fmtMatch(t))}</div></div>${icon('chevron')}</div>
              <div class="win"><div class="rank r1">${bn(w.position || 1)}</div><div class="grow"><div style="font-weight:600">${esc(w.playerName || 'বিজয়ী')}</div><div class="small muted">চ্যাম্পিয়ন${w.kills ? ' • ' + bn(w.kills) + ' কিল' : ''}</div></div><div class="num" style="color:var(--accent-2);font-size:18px">${taka(w.prize || 0)}</div></div></a>`;
          }).join('')}</div>`
        : emptyState('এখনো কোনো ফলাফল প্রকাশিত হয়নি', 'ম্যাচ শেষ হলে অ্যাডমিন ফলাফল প্রকাশ করবেন।', 'award'));

    if (notifs.length) {
      html += section('সর্বশেষ নোটিফিকেশন', ['notifications.html', 'সব দেখুন'],
        `<div class="list">${notifs.slice(0, 3).map((n) => `<div class="item ${n.isRead ? '' : 'unread'}"><div class="ico green">${icon('bell')}</div><div class="grow"><div class="t">${esc(n.title)}</div><div class="s">${esc(n.message)}</div></div></div>`).join('')}</div>`);
    }

    setView(html);
    mountSlider();
  } catch (e) {
    showError(e);
  } finally {
    hideSplash();
  }
}

// ---------------------------------------------------------------- Leaderboard
async function leaderboard() {
  const { user } = await boot({ title: 'লিডারবোর্ড', back: true, backHref: 'index.html' });
  try {
    const snap = await getDocs(query(collection(db, 'leaderboard'), orderBy('totalWins', 'desc'), limit(50)));
    const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
      .sort((a, b) => (b.totalWins || 0) - (a.totalWins || 0) || winRate(b.totalWins, b.totalMatches) - winRate(a.totalWins, a.totalMatches));
    const head = '<div class="page-head"><h1>লিডারবোর্ড</h1><p>অ্যাডমিন-যাচাইকৃত জয়ের ভিত্তিতে র‍্যাঙ্কিং</p></div>';
    if (!rows.length) return setView(head + emptyState('লিডারবোর্ড এখনো খালি', 'প্রথম ফলাফল প্রকাশিত হলে সেরা খেলোয়াড়দের নাম এখানে আসবে।', 'award'));
    const top = rows.slice(0, 3);
    const order = top.length === 3 ? [1, 0, 2] : top.map((_, i) => i);
    const podium = `<div class="podium">${order.map((i) => { const r = top[i]; return `<div class="p ${i === 0 ? 'first' : ''}"><div class="rank r${i + 1}" style="margin:0 auto">${bn(i + 1)}</div><div class="nm">${esc(r.name || 'প্লেয়ার')}</div><div class="w">${bn(r.totalWins || 0)} জয়</div></div>`; }).join('')}</div>`;
    setView(`${head}${podium}
      <div class="lb-head"><span>র‍্যাঙ্ক</span><span>প্লেয়ার</span><span>জয়</span><span>ম্যাচ</span><span>উইন%</span></div>
      ${rows.map((r, i) => `<div class="lb-row ${r.id === user.uid ? 'me' : ''}">
        <div class="rank ${i < 3 ? 'r' + (i + 1) : ''}">${bn(i + 1)}</div>
        <div class="nm">${esc(r.name || 'প্লেয়ার')}${r.id === user.uid ? ' <span class="badge green">আপনি</span>' : ''}</div>
        <div class="c" style="color:var(--accent-2)">${bn(r.totalWins || 0)}</div>
        <div class="c">${bn(r.totalMatches || 0)}</div>
        <div class="c">${bn(winRate(r.totalWins || 0, r.totalMatches || 0))}%</div></div>`).join('')}`);
  } catch (e) { showError(e); }
}

// ---------------------------------------------------------------- Help
async function help() {
  const { settings } = await boot({ title: 'সাহায্য ও সাপোর্ট', back: true, backHref: 'profile.html' });
  const faqs = [
    ['কীভাবে ম্যাচে জয়েন করব?', 'টুর্নামেন্ট পেজ থেকে ম্যাচ বেছে "জয়েন করুন" চাপুন। আপনার গেমের নাম ও UID দিন। ফ্রি ম্যাচে সঙ্গে সঙ্গে জয়েন হয়। এন্ট্রি ফি থাকলে অ্যাডমিন আপনার ওয়ালেট যাচাই করে ফি কেটে জয়েন নিশ্চিত করেন।'],
    ['ডিপোজিট ও উইনিং ওয়ালেট কী?', 'ডিপোজিট ওয়ালেটে আপনার যোগ করা টাকা থাকে। ম্যাচ জিতলে প্রাইজ উইনিং ওয়ালেটে যায়। এন্ট্রি ফি প্রথমে ডিপোজিট ওয়ালেট থেকে, না থাকলে উইনিং ওয়ালেট থেকে কাটা হয়। উইথড্র শুধু উইনিং ওয়ালেট থেকে করা যায়।'],
    ['টাকা যোগ করতে কত সময় লাগে?', 'আপনি bKash/Nagad/Rocket এ "সেন্ড মানি" করে ট্রানজেকশন আইডি জমা দেবেন। অ্যাডমিন নিজে পেমেন্ট যাচাই করে অনুমোদন দেন। এটি স্বয়ংক্রিয় নয়, তাই কিছুটা সময় লাগতে পারে।'],
    ['উইথড্র কীভাবে কাজ করে?', 'উইথড্র রিকোয়েস্ট জমা দিলে অ্যাডমিন যাচাই করে অনুমোদন দেন, তখন উইনিং ওয়ালেট থেকে টাকা কাটা হয়। এরপর আপনার নম্বরে টাকা পাঠিয়ে "পরিশোধিত" চিহ্নিত করা হয়।'],
    ['রুম আইডি ও পাসওয়ার্ড কোথায় পাব?', '"আমার গেম" পেজে। ম্যাচের আগে অ্যাডমিন প্রকাশ করলে শুধু নিশ্চিত রেজিস্টার্ড খেলোয়াড়রাই তা দেখতে পাবেন। কাউকে শেয়ার করবেন না।'],
    ['পার কিল প্রাইজ কীভাবে দেওয়া হয়?', 'ম্যাচ শেষে অ্যাডমিন আপনার কিল সংখ্যা যাচাই করে র‍্যাঙ্ক প্রাইজের সঙ্গে পার কিল প্রাইজ যোগ করে ফলাফল প্রকাশ করেন। প্রাইজ উইনিং ওয়ালেটে যোগ হয়।'],
    ['হ্যাক বা চিটিং করলে কী হবে?', 'ইমুলেটর/হ্যাক/স্ক্রিপ্ট ধরা পড়লে অ্যাকাউন্ট স্থায়ীভাবে স্থগিত ও প্রাইজ বাতিল হবে।'],
    ['পাসওয়ার্ড ভুলে গেলে?', 'লগইন পেজে "পাসওয়ার্ড ভুলে গেছেন?" চেপে ইমেইল দিন, রিসেট লিংক পাবেন।']
  ];
  const contacts = [];
  if (settings.supportPhone) contacts.push(`<a class="item" href="tel:${esc(settings.supportPhone)}"><div class="ico green">${icon('phone')}</div><div class="grow"><div class="t">ফোন</div><div class="s">${esc(bn(settings.supportPhone))}</div></div>${icon('chevron')}</a>`);
  if (settings.supportWhatsapp) contacts.push(`<a class="item" href="https://wa.me/${esc(String(settings.supportWhatsapp).replace(/\D/g, ''))}" target="_blank" rel="noopener"><div class="ico green">${icon('send')}</div><div class="grow"><div class="t">WhatsApp</div><div class="s">${esc(bn(settings.supportWhatsapp))}</div></div>${icon('chevron')}</a>`);
  if (settings.supportEmail) contacts.push(`<a class="item" href="mailto:${esc(settings.supportEmail)}"><div class="ico green">${icon('mail')}</div><div class="grow"><div class="t">ইমেইল</div><div class="s">${esc(settings.supportEmail)}</div></div>${icon('chevron')}</a>`);
  const soc = [['telegramUrl', 'tg', 'Telegram'], ['whatsappUrl', 'wa', 'WhatsApp গ্রুপ'], ['youtubeUrl', 'yt', 'YouTube'], ['facebookUrl', 'fb', 'Facebook']]
    .filter(([k]) => safeUrl(settings[k])).map(([k, c, l]) => `<a class="${c}" href="${esc(safeUrl(settings[k]))}" target="_blank" rel="noopener">${esc(l)}</a>`);

  setView(`<div class="page-head"><h1>সাহায্য ও সাপোর্ট</h1><p>সাধারণ প্রশ্নের উত্তর ও যোগাযোগ</p></div>
    ${soc.length ? `<div class="social">${soc.join('')}</div>` : ''}
    <div class="section-head"><h2>যোগাযোগ</h2></div>
    ${contacts.length ? `<div class="list">${contacts.join('')}</div>` : emptyState('সাপোর্ট তথ্য এখনো যোগ করা হয়নি', 'যোগাযোগের তথ্য যোগ হলে এখানে দেখা যাবে।', 'help')}
    <div class="section-head"><h2>সাধারণ প্রশ্ন</h2></div>
    <div class="list">${faqs.map(([q, a]) => `<details class="faq"><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}</div>`);
}

if (page === 'home') home();
else if (page === 'leaderboard') leaderboard();
else if (page === 'help') help();
