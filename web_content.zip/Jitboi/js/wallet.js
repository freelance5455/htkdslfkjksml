// =====================================================================
// Jitboi — js/wallet.js
//   data-page = wallet | deposit | withdraw | transactions
//
// নিরাপত্তা: এই ফাইল কখনোই balance লেখে না। ডিপোজিট/উইথড্র শুধু "অনুরোধ" (pending)।
// ব্যালেন্স পরিবর্তন করতে পারে কেবল অ্যাডমিন (Firestore Rules দ্বারা বাধ্যতামূলক)।
// =====================================================================
import {
  db, collection, doc, addDoc, getDocs, query, where, serverTimestamp
} from '../firebase.js';
import {
  $, $$, boot, esc, bn, taka, icon, emptyState, fmtTs, setView, showError, toast, errMsg,
  withLock, confirmDialog, badge, DSTATUS, METHODS, TX_TYPES, tsToDate, copyText, walletTotal
} from './ui.js';

const page = document.body.dataset.page;
const BD_PHONE = /^01[3-9]\d{8}$/;

async function fetchMine(col, uid) {
  const snap = await getDocs(query(collection(db, col), where('userId', '==', uid)));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }))
    .sort((a, b) => (tsToDate(b.createdAt)?.getTime() || Date.now() + 1000) - (tsToDate(a.createdAt)?.getTime() || Date.now() + 1000));
}
const sum = (arr, f) => arr.filter(f).reduce((s, x) => s + Number(x.amount || 0), 0);

function depositRow(d) {
  return `<div class="item"><div class="ico green">${icon('down')}</div>
    <div class="grow"><div class="t">ডিপোজিট • ${esc(d.method)}</div>
      <div class="s">${esc(fmtTs(d.createdAt))} • TrxID: ${esc(d.transactionId)}</div>
      ${d.status === 'rejected' && d.adminNote ? `<div class="s" style="color:var(--danger)">কারণ: ${esc(d.adminNote)}</div>` : ''}
      <div class="s">রিকোয়েস্ট ID: ${esc(d.id)}</div></div>
    <div style="text-align:right"><div class="amt">${taka(d.amount)}</div>${badge(DSTATUS, d.status)}</div></div>`;
}
function withdrawalRow(w) {
  return `<div class="item"><div class="ico red">${icon('up')}</div>
    <div class="grow"><div class="t">উইথড্র • ${esc(w.method)}</div>
      <div class="s">${esc(fmtTs(w.createdAt))} • ${esc(w.accountNumber)}</div>
      ${w.status === 'paid' && w.payoutReference ? `<div class="s">পেমেন্ট রেফারেন্স: ${esc(w.payoutReference)}</div>` : ''}
      ${w.status === 'rejected' && w.adminNote ? `<div class="s" style="color:var(--danger)">কারণ: ${esc(w.adminNote)}</div>` : ''}
      ${w.status === 'approved' ? '<div class="s" style="color:var(--warn)">অনুমোদিত — পেমেন্ট প্রক্রিয়াধীন</div>' : ''}
      <div class="s">রিকোয়েস্ট ID: ${esc(w.id)}</div></div>
    <div style="text-align:right"><div class="amt">${taka(w.amount)}</div>${badge(DSTATUS, w.status)}</div></div>`;
}
function txRow(t) {
  const [label, ic, color, sign] = TX_TYPES[t.type] || [t.type, 'swap', '', 1];
  return `<div class="item"><div class="ico ${color}">${icon(ic)}</div>
    <div class="grow"><div class="t">${esc(label)}</div>
      <div class="s">${esc(fmtTs(t.createdAt))}${t.note ? ' • ' + esc(t.note) : ''}</div>
      <div class="s">ID: ${esc(t.id)}</div></div>
    <div style="text-align:right"><div class="amt ${sign > 0 ? 'plus' : 'minus'}">${sign > 0 ? '+' : '−'}${taka(t.amount)}</div>${badge(DSTATUS, t.status)}</div></div>`;
}

// ---------------------------------------------------------------- ওয়ালেট
async function walletPage() {
  const { user, profile } = await boot({ nav: 'wallet' });
  try {
    const [deps, wds, txs] = await Promise.all([fetchMine('deposits', user.uid), fetchMine('withdrawals', user.uid), fetchMine('transactions', user.uid)]);
    const totalDep = sum(deps, (d) => d.status === 'approved');
    const totalWd = sum(wds, (w) => w.status === 'paid');
    const pendDep = sum(deps, (d) => d.status === 'pending');
    const pendWd = sum(wds, (w) => w.status === 'pending' || w.status === 'approved');
    const dep = Number(profile.balance || 0), win = Number(profile.winBalance || 0);
    setView(`
      <div class="wcard">
        <div class="l">মোট ব্যালেন্স</div><div class="big">${taka(dep + win)}</div>
        <div class="split"><div><span class="l">ডিপোজিট ওয়ালেট</span><b>${taka(dep)}</b></div><div><span class="l">উইনিং ওয়ালেট</span><b>${taka(win)}</b></div></div>
        <div class="acts"><a class="btn" href="deposit.html">${icon('plus', 'sm')} অ্যাড মানি</a><a class="btn alt" href="withdraw.html">${icon('up', 'sm')} উইথড্র</a></div>
      </div>
      <div class="grid two mt">
        <div class="stat"><div class="label">মোট ডিপোজিট</div><div class="value">${taka(totalDep)}</div></div>
        <div class="stat"><div class="label">মোট উইথড্র</div><div class="value">${taka(totalWd)}</div></div>
        <div class="stat"><div class="label">পেন্ডিং ডিপোজিট</div><div class="value" style="color:var(--warn)">${taka(pendDep)}</div></div>
        <div class="stat"><div class="label">পেন্ডিং উইথড্র</div><div class="value" style="color:var(--warn)">${taka(pendWd)}</div></div>
      </div>
      <div class="notice mt">${icon('info')}<div>ডিপোজিট ওয়ালেটে আপনার যোগ করা টাকা থাকে, ম্যাচ জিতলে প্রাইজ উইনিং ওয়ালেটে যায়। উইথড্র শুধু উইনিং ওয়ালেট থেকে। অ্যাডমিন যাচাই করার আগে কোনো রিকোয়েস্ট ব্যালেন্সে প্রতিফলিত হয় না।</div></div>
      <div class="section-head"><h2>সাম্প্রতিক লেনদেন</h2><a href="transactions.html">সব দেখুন</a></div>
      ${txs.length ? `<div class="list">${txs.slice(0, 5).map(txRow).join('')}</div>` : emptyState('এখনো কোনো লেনদেন নেই', 'ডিপোজিট অনুমোদিত হলে এখানে দেখা যাবে।', 'wallet')}
      <div class="mt"><a class="btn ghost block" href="transactions.html">${icon('list', 'sm')} লেনদেনের ইতিহাস</a></div>`);
  } catch (e) { showError(e); }
}

// ---------------------------------------------------------------- ডিপোজিট
async function depositPage() {
  const { user, settings } = await boot({ title: 'টাকা যোগ করুন', back: true, backHref: 'wallet.html', nav: 'wallet' });
  try {
    let deps = await fetchMine('deposits', user.uid);
    let method = 'bKash';
    const min = Number(settings.minDeposit || 0);
    const numbers = { bKash: settings.bkashNumber, Nagad: settings.nagadNumber, Rocket: settings.rocketNumber };

    function render(success = null) {
      const num = numbers[method];
      setView(`
        <div class="page-head"><h1>টাকা যোগ করুন</h1><p>ন্যূনতম ${taka(min)} • অ্যাডমিন ম্যানুয়ালি যাচাই করে অনুমোদন দেবেন</p></div>
        ${success ? `<div class="card" style="border-color:var(--accent)"><div class="row">${icon('check', 'lg')}<div><div style="font-weight:600">আপনার পেমেন্ট রিকোয়েস্ট জমা হয়েছে।</div><div class="small muted">অ্যাডমিন যাচাই করার পর ব্যালেন্স যোগ হবে।</div></div></div>
          <div class="kv mt-s"><span class="k">রিকোয়েস্ট ID</span><span class="v">${esc(success)} <span class="copy" data-copy="${esc(success)}">${icon('copy', 'sm')}</span></span></div>
          <div class="kv"><span class="k">স্ট্যাটাস</span><span class="v">${badge(DSTATUS, 'pending')}</span></div></div><div class="mt"></div>` : ''}
        <div class="methods" id="methods">${METHODS.map((m) => `<div class="method ${m === 'bKash' ? 'bk' : m === 'Nagad' ? 'ng' : 'rk'} ${method === m ? 'active' : ''}" data-m="${m}">${m}</div>`).join('')}</div>
        <div class="pay-box">
          <div class="small muted">${esc(method)} নম্বরে "সেন্ড মানি" করুন:</div>
          ${num ? `<div class="num row" style="margin:4px 0">${esc(bn(num))} <span class="copy" data-copy="${esc(num)}">${icon('copy', 'sm')}</span></div>` : `<div class="small" style="color:var(--warn);margin:6px 0">${esc(method)} নম্বর এখনো সেট করা হয়নি। অ্যাডমিনের সাথে যোগাযোগ করুন।</div>`}
          ${settings.paymentInstructions ? `<p class="pre small" style="margin-top:8px">${esc(settings.paymentInstructions)}</p>` : '<p class="small muted">টাকা পাঠানোর পর নিচের ফর্মে আপনার নম্বর ও ট্রানজেকশন আইডি দিন।</p>'}
        </div>
        <div id="ferr" class="form-error hidden"></div>
        <form id="dform" class="card" novalidate>
          <div class="field"><label>টাকার পরিমাণ (৳)</label><input class="input" id="amount" type="number" inputmode="numeric" min="${min}" step="1" placeholder="যেমন: ১০০">
            <div class="chips" id="qa" style="margin-top:6px">${[50, 100, 200, 500, 1000].filter((n) => n >= min).map((n) => `<span class="chip" data-a="${n}">${taka(n)}</span>`).join('')}</div></div>
          <div class="field"><label>যে নম্বর থেকে পাঠিয়েছেন</label><input class="input" id="sender" type="tel" inputmode="numeric" maxlength="11" placeholder="01XXXXXXXXX"></div>
          <div class="field"><label>ট্রানজেকশন আইডি (TrxID)</label><input class="input" id="trx" maxlength="30" autocapitalize="characters" placeholder="যেমন: 8N7A6D5EDQ"></div>
          <button class="btn block" id="dsubmit" type="submit">রিকোয়েস্ট জমা দিন</button>
        </form>
        <div class="section-head"><h2>আমার ডিপোজিট রিকোয়েস্ট</h2></div>
        ${deps.length ? `<div class="list">${deps.map(depositRow).join('')}</div>` : emptyState('কোনো রিকোয়েস্ট নেই', '', 'wallet')}`);

      $$('#methods [data-m]').forEach((b) => b.addEventListener('click', () => { method = b.dataset.m; render(); }));
      $$('#qa [data-a]').forEach((c) => c.addEventListener('click', () => { $('#amount').value = c.dataset.a; }));
      $('#dform').addEventListener('submit', onSubmit);
    }

    async function onSubmit(e) {
      e.preventDefault();
      const err = (m) => { const b = $('#ferr'); b.textContent = m; b.classList.remove('hidden'); b.scrollIntoView({ behavior: 'smooth', block: 'center' }); };
      $('#ferr').classList.add('hidden');
      const amount = Number($('#amount').value);
      const sender = $('#sender').value.trim();
      const trx = $('#trx').value.trim().toUpperCase();
      if (!Number.isInteger(amount) || amount <= 0) return err('সঠিক টাকার পরিমাণ লিখুন (পূর্ণ সংখ্যা)।');
      if (amount < min) return err(`ন্যূনতম ডিপোজিট ${taka(min)}।`);
      if (amount > 100000) return err('একবারে সর্বোচ্চ ' + taka(100000) + ' জমা দেওয়া যাবে।');
      if (!BD_PHONE.test(sender)) return err('সঠিক মোবাইল নম্বর লিখুন (যেমন 017XXXXXXXX)।');
      if (!/^[A-Z0-9]{6,30}$/.test(trx)) return err('ট্রানজেকশন আইডি ৬–৩০ অক্ষরের (ইংরেজি অক্ষর/সংখ্যা) হতে হবে।');
      if (deps.some((d) => d.transactionId === trx)) return err('এই ট্রানজেকশন আইডি দিয়ে আপনি ইতোমধ্যে রিকোয়েস্ট জমা দিয়েছেন।');
      const ok = await confirmDialog(`${method} এ ${taka(amount)} পাঠিয়েছেন এবং তথ্য সঠিক? ভুল বা ভুয়া তথ্য দিলে অ্যাকাউন্ট স্থগিত হতে পারে।`, { title: 'রিকোয়েস্ট জমা দিন', okText: 'জমা দিন' });
      if (!ok) return;
      await withLock($('#dsubmit'), async () => {
        try {
          const ref = await addDoc(collection(db, 'deposits'), {
            userId: user.uid, amount, method, senderNumber: sender, transactionId: trx, status: 'pending', createdAt: serverTimestamp()
          });
          deps = await fetchMine('deposits', user.uid);
          toast('আপনার পেমেন্ট রিকোয়েস্ট জমা হয়েছে।');
          render(ref.id);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } catch (ex) { err(errMsg(ex)); }
      });
    }
    render();
  } catch (e) { showError(e); }
}

document.addEventListener('click', (e) => {
  const c = e.target.closest('[data-copy]');
  if (c) copyText(c.dataset.copy);
});

// ---------------------------------------------------------------- উইথড্র
async function withdrawPage() {
  const { user, profile, settings } = await boot({ title: 'উইথড্র', back: true, backHref: 'wallet.html', nav: 'wallet' });
  try {
    let wds = await fetchMine('withdrawals', user.uid);
    let method = 'bKash';
    const min = Number(settings.minWithdraw || 0);
    const balance = Number(profile.winBalance || 0);
    const reserved = () => sum(wds, (w) => w.status === 'pending');
    const available = () => Math.max(0, balance - reserved());

    function render(success = null) {
      setView(`
        <div class="page-head"><h1>উইথড্র</h1><p>ন্যূনতম ${taka(min)} • অ্যাডমিন যাচাই করে পেমেন্ট পাঠাবেন</p></div>
        <div class="grid two">
          <div class="stat"><div class="label">উইনিং ওয়ালেট</div><div class="value">${taka(balance)}</div></div>
          <div class="stat"><div class="label">উইথড্র করা যাবে</div><div class="value accent">${taka(available())}</div></div>
        </div>
        ${success ? `<div class="card mt" style="border-color:var(--accent)"><div style="font-weight:600">আপনার উইথড্র রিকোয়েস্ট জমা হয়েছে।</div>
          <div class="kv mt-s"><span class="k">রিকোয়েস্ট ID</span><span class="v">${esc(success)}</span></div>
          <div class="kv"><span class="k">স্ট্যাটাস</span><span class="v">${badge(DSTATUS, 'pending')}</span></div>
          <p class="small muted">অনুমোদনের সময় আপনার উইনিং ওয়ালেট থেকে টাকা কাটা হবে। পেমেন্ট পাঠানোর পর স্ট্যাটাস "পরিশোধিত" হবে।</p></div>` : ''}
        <div class="notice mt">${icon('info')}<div>উইথড্র শুধু উইনিং ওয়ালেট (ম্যাচ জেতা প্রাইজ) থেকে করা যায়। রিকোয়েস্ট অ্যাডমিন ম্যানুয়ালি যাচাই ও প্রসেস করেন।</div></div>
        <div id="ferr" class="form-error hidden mt"></div>
        <form id="wform" class="card mt" novalidate>
          <div class="methods" id="methods">${METHODS.map((m) => `<div class="method ${m === 'bKash' ? 'bk' : m === 'Nagad' ? 'ng' : 'rk'} ${method === m ? 'active' : ''}" data-m="${m}">${m}</div>`).join('')}</div>
          <div class="field"><label>টাকার পরিমাণ (৳)</label><input class="input" id="amount" type="number" inputmode="numeric" min="${min}" step="1" placeholder="যেমন: ১০০"></div>
          <div class="field"><label>${esc(method)} অ্যাকাউন্ট নম্বর</label><input class="input" id="acc" type="tel" inputmode="numeric" maxlength="11" placeholder="01XXXXXXXXX"></div>
          <div class="field"><label>অ্যাকাউন্ট হোল্ডারের নাম</label><input class="input" id="accName" maxlength="60" placeholder="নাম"></div>
          <button class="btn block" id="wsubmit" type="submit">রিকোয়েস্ট জমা দিন</button>
        </form>
        <div class="section-head"><h2>আমার উইথড্র রিকোয়েস্ট</h2></div>
        ${wds.length ? `<div class="list">${wds.map(withdrawalRow).join('')}</div>` : emptyState('কোনো রিকোয়েস্ট নেই', '', 'wallet')}`);
      $$('#methods [data-m]').forEach((b) => b.addEventListener('click', () => { method = b.dataset.m; render(); }));
      $('#wform').addEventListener('submit', onSubmit);
    }

    async function onSubmit(e) {
      e.preventDefault();
      const err = (m) => { const b = $('#ferr'); b.textContent = m; b.classList.remove('hidden'); b.scrollIntoView({ behavior: 'smooth', block: 'center' }); };
      $('#ferr').classList.add('hidden');
      const amount = Number($('#amount').value);
      const acc = $('#acc').value.trim();
      const accName = $('#accName').value.trim().replace(/\s+/g, ' ');
      if (!Number.isInteger(amount) || amount <= 0) return err('সঠিক টাকার পরিমাণ লিখুন (পূর্ণ সংখ্যা)।');
      if (amount < min) return err(`ন্যূনতম উইথড্র ${taka(min)}।`);
      if (amount > available()) return err('আপনার পর্যাপ্ত ব্যালেন্স নেই।');
      if (!BD_PHONE.test(acc)) return err('সঠিক মোবাইল অ্যাকাউন্ট নম্বর লিখুন (যেমন 017XXXXXXXX)।');
      if (accName.length < 2 || accName.length > 60) return err('অ্যাকাউন্ট হোল্ডারের নাম লিখুন।');
      const ok = await confirmDialog(`${taka(amount)} ${method} (${acc}) নম্বরে উইথড্র করতে চান?`, { title: 'উইথড্র নিশ্চিত করুন', okText: 'জমা দিন' });
      if (!ok) return;
      await withLock($('#wsubmit'), async () => {
        try {
          const ref = await addDoc(collection(db, 'withdrawals'), {
            userId: user.uid, amount, method, accountNumber: acc, accountName: accName, status: 'pending', createdAt: serverTimestamp()
          });
          wds = await fetchMine('withdrawals', user.uid);
          toast('আপনার উইথড্র রিকোয়েস্ট জমা হয়েছে।');
          render(ref.id);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } catch (ex) { err(errMsg(ex)); }
      });
    }
    render();
  } catch (e) { showError(e); }
}

// ---------------------------------------------------------------- লেনদেনের ইতিহাস
async function transactionsPage() {
  const { user } = await boot({ title: 'লেনদেনের ইতিহাস', back: true, backHref: 'wallet.html', nav: 'wallet' });
  try {
    const [txs, deps, wds] = await Promise.all([fetchMine('transactions', user.uid), fetchMine('deposits', user.uid), fetchMine('withdrawals', user.uid)]);
    let tab = 'tx';
    const data = { tx: [txs, txRow, 'এখনো কোনো লেনদেন নেই'], dep: [deps, depositRow, 'কোনো ডিপোজিট রিকোয়েস্ট নেই'], wd: [wds, withdrawalRow, 'কোনো উইথড্র রিকোয়েস্ট নেই'] };
    function render() {
      const [list, row, emptyText] = data[tab];
      setView(`<div class="page-head"><h1>লেনদেনের ইতিহাস</h1><p>শুধু আপনার নিজের রেকর্ড দেখা যায়</p></div>
        <div class="tabs" id="tabs">${[['tx', 'লেনদেন'], ['dep', 'ডিপোজিট'], ['wd', 'উইথড্র']].map(([k, l]) => `<button class="tab ${tab === k ? 'active' : ''}" data-tab="${k}">${l}</button>`).join('')}</div>
        <div class="mt">${list.length ? `<div class="list">${list.map(row).join('')}</div>` : emptyState(emptyText, '', 'list')}</div>`);
      $$('#tabs [data-tab]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; render(); }));
    }
    render();
  } catch (e) { showError(e); }
}

if (page === 'wallet') walletPage();
else if (page === 'deposit') depositPage();
else if (page === 'withdraw') withdrawPage();
else if (page === 'transactions') transactionsPage();
