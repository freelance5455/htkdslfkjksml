// =====================================================================
// Jitboi — js/profile.js   (data-page = profile | settings)
// ইউজার শুধু নিজের name / gameName / gameId বদলাতে পারে।
// role / balance / winBalance / wins / status Firestore Rules দ্বারা সুরক্ষিত।
// (এই অ্যাপে অ্যাডমিন প্যানেলের কোনো লিংক বা উল্লেখ নেই।)
// =====================================================================
import { auth, db, doc, updateDoc, updateProfile, sendPasswordResetEmail } from '../firebase.js';
import {
  $, boot, esc, bn, taka, icon, fmtTs, setView, showError, toast, errMsg, withLock, openModal,
  confirmDialog, initials, winRate, logout, copyText, safeUrl
} from './ui.js';

const page = document.body.dataset.page;

async function profilePage() {
  const { user, profile, settings } = await boot({ nav: 'profile' });
  try {
    const rate = winRate(profile.totalWins || 0, profile.totalMatches || 0);
    const code = profile.referralCode || user.uid.slice(0, 6).toUpperCase();
    const shareUrl = new URL('register.html?ref=' + code, location.href).href;
    const dep = Number(profile.balance || 0), win = Number(profile.winBalance || 0);
    const soc = [['telegramUrl', 'tg', 'Telegram'], ['whatsappUrl', 'wa', 'WhatsApp গ্রুপ'], ['youtubeUrl', 'yt', 'YouTube'], ['facebookUrl', 'fb', 'Facebook']]
      .filter(([k]) => safeUrl(settings[k])).map(([k, c, l]) => `<a class="${c}" href="${esc(safeUrl(settings[k]))}" target="_blank" rel="noopener">${esc(l)}</a>`);

    setView(`
      <div class="profile-hero">
        <div class="avatar">${esc(initials(profile.name))}</div>
        <h1 style="font-size:22px">${esc(profile.name)}</h1>
        <div class="em">${esc(profile.email)}</div>
        <div class="mt-s"><span class="badge ${profile.status === 'active' ? 'green' : 'red'}" style="background:rgba(255,255,255,.9)">${profile.status === 'active' ? 'অ্যাকাউন্ট সক্রিয়' : 'স্থগিত'}</span></div>
      </div>

      <div class="stat-row mt">
        <div class="stat"><div class="label">ম্যাচ</div><div class="value">${bn(profile.totalMatches || 0)}</div></div>
        <div class="stat"><div class="label">জয়</div><div class="value accent">${bn(profile.totalWins || 0)}</div></div>
        <div class="stat"><div class="label">উইন রেট</div><div class="value">${bn(rate)}%</div></div>
      </div>

      <div class="card mt">
        <div class="row between"><div class="card-title" style="margin:0">গেম প্রোফাইল</div><button class="btn sm ghost" id="editBtn">${icon('edit', 'sm')} এডিট</button></div>
        <div class="kv mt-s"><span class="k">গেমের নাম</span><span class="v">${esc(profile.gameName || '—')}</span></div>
        <div class="kv"><span class="k">গেম UID</span><span class="v">${esc(profile.gameId || '—')}</span></div>
        <div class="kv"><span class="k">ডিপোজিট ওয়ালেট</span><span class="v">${taka(dep)}</span></div>
        <div class="kv"><span class="k">উইনিং ওয়ালেট</span><span class="v">${taka(win)}</span></div>
        <div class="kv"><span class="k">যোগদানের তারিখ</span><span class="v">${esc(fmtTs(profile.createdAt, false))}</span></div>
      </div>

      <div class="refer mt">
        <div style="font-weight:600;font-size:16px">${icon('gift', 'sm')} বন্ধুকে রেফার করুন</div>
        <p class="small muted" style="margin-top:2px">বন্ধু আপনার কোড দিয়ে রেজিস্টার করলে অ্যাডমিন যাচাই করে বোনাস দিতে পারেন।</p>
        <div class="code"><span>${esc(code)}</span><span class="copy" id="cpCode" aria-label="কপি">${icon('copy')}</span></div>
        <button class="btn block" id="shareBtn">${icon('share', 'sm')} শেয়ার করুন</button>
      </div>

      ${soc.length ? `<div class="section-head"><h2>আমাদের সাথে থাকুন</h2></div><div class="social">${soc.join('')}</div>` : ''}

      <div class="section-head"><h2>মেনু</h2></div>
      <div class="menu">
        <a href="transactions.html">${icon('list')}<span>লেনদেনের ইতিহাস</span>${icon('chevron', 'chev')}</a>
        <a href="leaderboard.html">${icon('award')}<span>লিডারবোর্ড</span>${icon('chevron', 'chev')}</a>
        <a href="notifications.html">${icon('bell')}<span>নোটিফিকেশন</span>${icon('chevron', 'chev')}</a>
        <a href="settings.html">${icon('settings')}<span>সেটিংস</span>${icon('chevron', 'chev')}</a>
        <a href="help.html">${icon('help')}<span>সাহায্য ও সাপোর্ট</span>${icon('chevron', 'chev')}</a>
        <button id="outBtn" style="color:var(--danger)">${icon('logout')}<span>লগআউট</span></button>
      </div>`);

    $('#cpCode').addEventListener('click', () => copyText(code));
    $('#shareBtn').addEventListener('click', async () => {
      const text = `Jitboi তে গেমিং টুর্নামেন্ট খেলুন! আমার রেফার কোড: ${code}\n${shareUrl}`;
      try {
        if (navigator.share) await navigator.share({ title: 'Jitboi', text, url: shareUrl });
        else await copyText(text);
      } catch { /* ব্যবহারকারী বাতিল করেছেন */ }
    });
    $('#outBtn').addEventListener('click', async () => {
      if (await confirmDialog('আপনি কি লগআউট করতে চান?', { title: 'লগআউট', okText: 'লগআউট', danger: true })) logout();
    });
    $('#editBtn').addEventListener('click', () => {
      openModal(`<h3>প্রোফাইল এডিট</h3><div id="perr" class="form-error hidden"></div>
        <form id="pform" novalidate>
          <div class="field"><label>পুরো নাম</label><input class="input" id="pname" maxlength="50" value="${esc(profile.name)}"></div>
          <div class="field"><label>গেমের নাম (ডিফল্ট)</label><input class="input" id="pgname" maxlength="30" value="${esc(profile.gameName || '')}"></div>
          <div class="field"><label>গেম UID (ডিফল্ট)</label><input class="input" id="pgid" maxlength="30" value="${esc(profile.gameId || '')}"><span class="hint">ম্যাচে জয়েনের সময় অটো-ফিল হবে।</span></div>
          <div class="actions"><button type="button" class="btn ghost" data-x>বাতিল</button><button class="btn" id="psave" type="submit">সংরক্ষণ</button></div></form>`, {
        onMount: (m, close) => {
          m.querySelector('[data-x]').addEventListener('click', close);
          m.querySelector('#pform').addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = m.querySelector('#pname').value.trim().replace(/\s+/g, ' ');
            const gameName = m.querySelector('#pgname').value.trim();
            const gameId = m.querySelector('#pgid').value.trim();
            const err = (t) => { const b = m.querySelector('#perr'); b.textContent = t; b.classList.remove('hidden'); };
            if (name.length < 2 || name.length > 50) return err('নাম ২ থেকে ৫০ অক্ষরের মধ্যে হতে হবে।');
            if (gameName.length > 30 || gameId.length > 30 || /\s/.test(gameId)) return err('গেমের নাম/UID সঠিক নয় (UID তে স্পেস থাকবে না)।');
            await withLock(m.querySelector('#psave'), async () => {
              try {
                await updateDoc(doc(db, 'users', user.uid), { name, gameName, gameId }); // শুধু নিরাপদ ফিল্ড
                try { await updateProfile(auth.currentUser, { displayName: name }); } catch { /* ignore */ }
                close(); toast('প্রোফাইল আপডেট হয়েছে।'); setTimeout(() => location.reload(), 500);
              } catch (ex) { err(errMsg(ex)); }
            });
          });
        }
      });
    });
  } catch (e) { showError(e); }
}

async function settingsPage() {
  const { user, profile, settings } = await boot({ title: 'সেটিংস', back: true, backHref: 'profile.html', nav: 'profile' });
  try {
    setView(`
      <div class="page-head"><h1>সেটিংস</h1><p>অ্যাকাউন্ট ও নিরাপত্তা</p></div>
      <div class="card">
        <div class="kv"><span class="k">নাম</span><span class="v">${esc(profile.name)}</span></div>
        <div class="kv"><span class="k">ইমেইল</span><span class="v">${esc(profile.email)}</span></div>
        <div class="kv"><span class="k">রেফার কোড</span><span class="v num">${esc(profile.referralCode || user.uid.slice(0, 6).toUpperCase())}</span></div>
      </div>
      <div class="section-head"><h2>নিরাপত্তা</h2></div>
      <div class="menu">
        <button id="pwBtn">${icon('lock')}<span>পাসওয়ার্ড রিসেট লিংক পাঠান</span>${icon('chevron', 'chev')}</button>
      </div>
      <div class="section-head"><h2>অ্যাপ সম্পর্কে</h2></div>
      <div class="card">
        <div class="kv"><span class="k">অ্যাপ</span><span class="v">${esc(settings.appName || 'Jitboi')}</span></div>
        <div class="kv"><span class="k">ভার্সন</span><span class="v">2.0.0</span></div>
        <div class="kv"><span class="k">মুদ্রা</span><span class="v">বাংলাদেশি টাকা (৳ BDT)</span></div>
      </div>
      <div class="menu mt">
        <a href="help.html">${icon('help')}<span>সাহায্য ও সাপোর্ট</span>${icon('chevron', 'chev')}</a>
        <button id="outBtn" style="color:var(--danger)">${icon('logout')}<span>লগআউট</span></button>
      </div>`);
    $('#pwBtn').addEventListener('click', (e) => withLock(e.currentTarget, async () => {
      try { await sendPasswordResetEmail(auth, profile.email); toast('পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে।'); }
      catch (ex) { toast(errMsg(ex), 'err'); }
    }));
    $('#outBtn').addEventListener('click', async () => {
      if (await confirmDialog('আপনি কি লগআউট করতে চান?', { title: 'লগআউট', okText: 'লগআউট', danger: true })) logout();
    });
  } catch (e) { showError(e); }
}

if (page === 'profile') profilePage();
else if (page === 'settings') settingsPage();
