// =====================================================================
// Jitboi — js/ui.js
// শেয়ার্ড হেল্পার: শেল (topbar + bottom nav), auth guard, toast, dialog, ফরম্যাটার
// ইউজার অ্যাপ ও অ্যাডমিন প্যানেল দুটোই এটি ব্যবহার করে।
// =====================================================================
import {
  auth, db, ADMIN_UID,
  onAuthStateChanged, signOut,
  doc, getDoc, setDoc, serverTimestamp,
  collection, query, where, getDocs, limit
} from '../firebase.js';

export const GAMES = ['Free Fire', 'PUBG Mobile', 'eFootball', 'Ludo', 'Other'];
export const METHODS = ['bKash', 'Nagad', 'Rocket'];

export const DEFAULT_SETTINGS = {
  appName: 'Jitboi',
  supportPhone: '',
  supportEmail: '',
  supportWhatsapp: '',
  paymentInstructions: '',
  bkashNumber: '',
  nagadNumber: '',
  rocketNumber: '',
  minDeposit: 20,
  minWithdraw: 50,
  maintenanceMode: false,
  games: GAMES,
  notice: '',
  banners: [],
  telegramUrl: '',
  whatsappUrl: '',
  youtubeUrl: '',
  facebookUrl: ''
};

// ---------------------------------------------------------------- DOM helpers
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function safeUrl(u) {
  try {
    const x = new URL(String(u || ''));
    return x.protocol === 'https:' || x.protocol === 'http:' ? x.href : '';
  } catch { return ''; }
}

// ---------------------------------------------------------------- Bengali formatters
const BN = '০১২৩৪৫৬৭৮৯';
export const bn = (v) => String(v ?? '').replace(/\d/g, (d) => BN[d]);
export const taka = (n) => '৳' + bn(Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 }));

export function tsToDate(ts) {
  if (!ts) return null;
  if (typeof ts.toDate === 'function') return ts.toDate();
  const d = new Date(ts);
  return isNaN(d) ? null : d;
}
export function fmtTs(ts, withTime = true) {
  const d = tsToDate(ts);
  if (!d) return '—';
  const opts = { day: 'numeric', month: 'short', year: 'numeric' };
  if (withTime) Object.assign(opts, { hour: 'numeric', minute: '2-digit', hour12: true });
  try { return d.toLocaleString('bn-BD', opts); } catch { return d.toLocaleString(); }
}
export function matchDateObj(t) {
  if (!t || !t.matchDate) return null;
  const d = new Date(`${t.matchDate}T${t.matchTime || '00:00'}:00`);
  return isNaN(d) ? null : d;
}
export function fmtMatch(t) {
  const d = matchDateObj(t);
  if (!d) return '—';
  try {
    return d.toLocaleString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true });
  } catch { return `${t.matchDate} ${t.matchTime || ''}`; }
}
export const initials = (name) => (String(name || '?').trim().split(/\s+/).slice(0, 2).map((s) => s[0]).join('') || '?').toUpperCase();
export const winRate = (wins, matches) => (matches > 0 ? Math.round((wins / matches) * 100) : 0);


// ---------------------------------------------------------------- Game look & countdown
export const GAME_META = {
  'Free Fire': { mark: 'FF', grad: 'linear-gradient(135deg,#ff8a2a,#d9480f)', color: '#e8590c' },
  'PUBG Mobile': { mark: 'PUBG', grad: 'linear-gradient(135deg,#f5b301,#a16207)', color: '#c58a00' },
  'eFootball': { mark: 'eF', grad: 'linear-gradient(135deg,#2f7bff,#1b3fa0)', color: '#2563eb' },
  'Ludo': { mark: 'LUDO', grad: 'linear-gradient(135deg,#ef4444,#b91c1c)', color: '#dc2626' },
  'Other': { mark: 'GAME', grad: 'linear-gradient(135deg,#16a34a,#0a6b31)', color: '#16a34a' }
};
const EXTRA_GRADS = ['linear-gradient(135deg,#8b5cf6,#5b21b6)', 'linear-gradient(135deg,#06b6d4,#0e7490)', 'linear-gradient(135deg,#ec4899,#9d174d)', 'linear-gradient(135deg,#14b8a6,#0f766e)'];
export function gameMeta(g) {
  if (GAME_META[g]) return GAME_META[g];
  const name = String(g || 'Game');
  let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return { mark: name.replace(/\s+/g, '').slice(0, 4).toUpperCase(), grad: EXTRA_GRADS[h % EXTRA_GRADS.length], color: '#16a34a' };
}
export const walletTotal = (p) => Number(p?.balance || 0) + Number(p?.winBalance || 0);

const pad2 = (n) => String(n).padStart(2, '0');
export function cdParts(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return { d: Math.floor(s / 86400), h: Math.floor((s % 86400) / 3600), m: Math.floor((s % 3600) / 60), s: s % 60 };
}
function cdLabel(ts, status) {
  if (status === 'live') return 'চলছে';
  if (status === 'completed') return 'সমাপ্ত';
  if (status === 'cancelled') return 'বাতিল';
  const ms = ts - Date.now();
  if (!ts) return '';
  if (ms <= 0) return 'শীঘ্রই শুরু';
  const c = cdParts(ms);
  return (c.d ? bn(c.d) + ' দিন ' : '') + bn(pad2(c.h)) + ':' + bn(pad2(c.m)) + ':' + bn(pad2(c.s));
}
let cdTimer = null;
export function startCountdowns() {
  if (cdTimer) clearInterval(cdTimer);
  const tick = () => {
    document.querySelectorAll('[data-cd]').forEach((el) => { el.textContent = cdLabel(Number(el.dataset.ts), el.dataset.st); });
    document.querySelectorAll('[data-cdbox]').forEach((el) => {
      const ms = Number(el.dataset.ts) - Date.now();
      const c = cdParts(ms);
      const vals = [c.d, c.h, c.m, c.s];
      el.querySelectorAll('b').forEach((b, i) => { b.textContent = bn(pad2(vals[i])); });
    });
  };
  tick();
  if (document.querySelector('[data-cd],[data-cdbox]')) cdTimer = setInterval(tick, 1000);
}
export function cdTs(t) { const d = matchDateObj(t); return d ? d.getTime() : 0; }

// ---------------------------------------------------------------- Icons
const ICONS = {
  home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  trophy: '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>',
  speaker: '<path d="M3 11v2a1 1 0 0 0 1 1h3l5 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M16 8.5a5 5 0 0 1 0 7"/><path d="M19 5a9 9 0 0 1 0 14"/>',
  target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
  map: '<polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  award: '<circle cx="12" cy="8" r="6"/><path d="M15.48 12.89L17 22l-5-3-5 3 1.52-9.11"/>',
  gamepad: '<line x1="6" y1="12" x2="10" y2="12"/><line x1="8" y1="10" x2="8" y2="14"/><line x1="15" y1="13" x2="15.01" y2="13"/><line x1="18" y1="11" x2="18.01" y2="11"/><rect x="2" y="6" width="20" height="12" rx="2"/>',
  wallet: '<path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4"/><path d="M4 6v12c0 1.1.9 2 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  minus: '<line x1="5" y1="12" x2="19" y2="12"/>',
  back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  settings: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  alert: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  chevron: '<polyline points="9 18 15 12 9 6"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
  mail: '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
  refresh: '<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
  down: '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>',
  up: '<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>',
  gift: '<polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>',
  menu: '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
  swap: '<polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>'
};
export function icon(name, cls = '') {
  return `<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.info}</svg>`;
}

// ---------------------------------------------------------------- Errors (Bengali)
export class AppError extends Error {
  constructor(msg) { super(msg); this.appMsg = msg; }
}
export function errMsg(e) {
  if (!e) return 'কিছু ভুল হয়েছে। আবার চেষ্টা করুন।';
  if (e.appMsg) return e.appMsg;
  const c = e.code || '';
  const map = {
    'auth/email-already-in-use': 'এই ইমেইল দিয়ে ইতোমধ্যে অ্যাকাউন্ট আছে।',
    'auth/invalid-email': 'ইমেইল ঠিকানাটি সঠিক নয়।',
    'auth/weak-password': 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।',
    'auth/invalid-credential': 'ইমেইল বা পাসওয়ার্ড ভুল।',
    'auth/wrong-password': 'ইমেইল বা পাসওয়ার্ড ভুল।',
    'auth/user-not-found': 'এই ইমেইলে কোনো অ্যাকাউন্ট পাওয়া যায়নি।',
    'auth/user-disabled': 'এই অ্যাকাউন্টটি নিষ্ক্রিয় করা হয়েছে।',
    'auth/too-many-requests': 'অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।',
    'auth/network-request-failed': 'ইন্টারনেট সংযোগ নেই। সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।',
    'auth/missing-password': 'পাসওয়ার্ড লিখুন।',
    'auth/operation-not-allowed': 'Firebase এ Email/Password লগইন চালু করা নেই। (Authentication → Sign-in method)',
    'unavailable': 'ইন্টারনেট সংযোগ নেই বা সার্ভার ব্যস্ত। আবার চেষ্টা করুন।',
    'permission-denied': 'আপনার এই কাজটি করার অনুমতি নেই। (Firestore Rules পরীক্ষা করুন)',
    'failed-precondition': 'ডাটাবেস কনফিগারেশন সমস্যা। (Index দরকার হতে পারে — কনসোল লগ দেখুন)',
    'not-found': 'ডেটা পাওয়া যায়নি।',
    'resource-exhausted': 'আজকের ফ্রি কোটা শেষ হয়েছে। পরে আবার চেষ্টা করুন।'
  };
  return map[c] || (e.message && !/^Firebase|^FirebaseError/.test(e.message) ? e.message : 'কিছু ভুল হয়েছে। আবার চেষ্টা করুন।');
}

// ---------------------------------------------------------------- Toast / dialogs
export function toast(msg, type = 'ok') {
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `${icon(type === 'ok' ? 'check' : 'alert')}<div>${esc(msg)}</div>`;
  box.appendChild(el);
  setTimeout(() => el.remove(), type === 'ok' ? 3500 : 5500);
}

export function openModal(html, { onMount } = {}) {
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
  const close = () => bg.remove();
  bg.addEventListener('mousedown', (e) => { if (e.target === bg) close(); });
  document.body.appendChild(bg);
  if (onMount) onMount($('.modal', bg), close);
  return close;
}

export function confirmDialog(message, { title = 'নিশ্চিত করুন', okText = 'হ্যাঁ, নিশ্চিত', cancelText = 'বাতিল', danger = false } = {}) {
  return new Promise((resolve) => {
    const close = openModal(
      `<h3>${esc(title)}</h3><p class="muted">${esc(message)}</p>
       <div class="actions"><button class="btn ghost" data-r="0">${esc(cancelText)}</button>
       <button class="btn ${danger ? 'danger' : ''}" data-r="1">${esc(okText)}</button></div>`,
      {
        onMount: (m, cl) => {
          m.addEventListener('click', (e) => {
            const b = e.target.closest('[data-r]');
            if (!b) return;
            cl();
            resolve(b.dataset.r === '1');
          });
        }
      }
    );
    void close;
  });
}

// ডুপ্লিকেট সাবমিট ঠেকাতে বাটন লক করে
export async function withLock(btn, fn) {
  if (!btn || btn.dataset.busy === '1') return;
  btn.dataset.busy = '1';
  const html = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<span class="spin"></span>';
  try { return await fn(); }
  finally { btn.dataset.busy = ''; btn.disabled = false; btn.innerHTML = html; }
}

export async function copyText(text) {
  try { await navigator.clipboard.writeText(String(text)); toast('কপি হয়েছে।'); }
  catch {
    const t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select();
    try { document.execCommand('copy'); toast('কপি হয়েছে।'); } catch { toast('কপি করা যায়নি।', 'err'); }
    t.remove();
  }
}

// ---------------------------------------------------------------- Status labels
export const TSTATUS = {
  upcoming: ['আসন্ন', 'blue'],
  registration_open: ['রেজিস্ট্রেশন চালু', 'green'],
  full: ['পূর্ণ', 'yellow'],
  live: ['লাইভ', 'red live'],
  completed: ['সমাপ্ত', ''],
  cancelled: ['বাতিল', 'red']
};
export const PSTATUS = {
  registered: ['নিশ্চিত', 'green'],
  pending_payment: ['ফি যাচাই অপেক্ষমাণ', 'yellow'],
  rejected: ['বাতিল', 'red']
};
export const DSTATUS = {
  pending: ['অপেক্ষমাণ', 'yellow'],
  approved: ['অনুমোদিত', 'green'],
  rejected: ['বাতিল', 'red'],
  paid: ['পরিশোধিত', 'green'],
  processing: ['প্রক্রিয়াধীন', 'yellow'],
  completed: ['সম্পন্ন', 'green'],
  refunded: ['ফেরত', 'blue']
};
export function badge(map, key) {
  const [label, cls] = map[key] || [key || '—', ''];
  return `<span class="badge ${cls}">${esc(label)}</span>`;
}
export const tBadge = (s) => badge(TSTATUS, s);

export const TX_TYPES = {
  deposit: ['ডিপোজিট', 'down', 'green', 1],
  withdrawal: ['উইথড্র', 'up', 'red', -1],
  entry: ['টুর্নামেন্ট এন্ট্রি', 'gamepad', 'red', -1],
  prize: ['টুর্নামেন্ট প্রাইজ', 'gift', 'green', 1],
  refund: ['রিফান্ড', 'refresh', 'yellow', 1],
  bonus: ['বোনাস', 'gift', 'green', 1]
};

export function tournamentBucket(t) {
  if (t.status === 'live') return 'live';
  if (t.status === 'completed' || t.status === 'cancelled') return 'completed';
  return 'upcoming';
}

export function emptyState(title, text = '', ic = 'trophy', actionHtml = '') {
  return `<div class="empty"><div class="ei">${icon(ic, 'lg')}</div><h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${actionHtml ? `<div class="mt">${actionHtml}</div>` : ''}</div>`;
}
export const loaderHtml = (text = 'লোড হচ্ছে...') => `<div class="loader"><span class="spin"></span><span>${esc(text)}</span></div>`;

export function tournamentCard(t, hrefBase = 'tournament-details.html') {
  const gm = gameMeta(t.game);
  const max = Number(t.maxPlayers || 0), joined = Number(t.joinedPlayers || 0);
  const pct = max > 0 ? Math.min(100, Math.round((joined / max) * 100)) : 0;
  const img = safeUrl(t.imageUrl);
  const left = Math.max(0, max - joined);
  let cta = 'দেখুন';
  if (t.status === 'registration_open') cta = left > 0 ? 'জয়েন করুন' : 'পূর্ণ';
  else if (t.status === 'completed') cta = 'ফলাফল';
  else if (t.status === 'full') cta = 'পূর্ণ';
  const tags = [t.mode, t.version, t.map].filter(Boolean).map((x) => `<span class="tag">${esc(x)}</span>`).join('');
  const perKill = Number(t.perKill || 0);
  return `<a class="mcard" href="${hrefBase}?id=${encodeURIComponent(t.id)}">
    <div class="cover" style="background:${gm.grad}" data-mark="${esc(gm.mark)}">${img ? `<img src="${esc(img)}" alt="" loading="lazy" onerror="this.remove()">` : ''}
      <div class="tags">${tags}</div><span class="st">${tBadge(t.status)}</span>
      <span class="game">${esc(t.game)}</span></div>
    <div class="body">
      <h3>${esc(t.title)}</h3>
      <div class="meta">
        <div><div class="k">এন্ট্রি ফি</div><div class="v">${t.entryFee > 0 ? taka(t.entryFee) : 'ফ্রি'}</div></div>
        <div><div class="k">প্রাইজ পুল</div><div class="v accent">${taka(t.prizePool)}</div></div>
        <div><div class="k">${perKill > 0 ? 'পার কিল' : 'মোড'}</div><div class="v">${perKill > 0 ? taka(perKill) : esc(t.mode || '—')}</div></div>
      </div>
      <div class="when"><span>${icon('calendar', 'sm')} ${esc(fmtMatch(t))}</span><span class="cd" data-cd data-ts="${cdTs(t)}" data-st="${esc(t.status)}"></span></div>
      <div class="foot"><div class="prog"><div class="row between small muted" style="margin-bottom:5px"><span>${bn(joined)}/${bn(max)} জন</span><span>${left > 0 ? bn(left) + ' স্লট বাকি' : 'স্লট পূর্ণ'}</span></div><div class="progress"><i style="width:${pct}%"></i></div></div>
      <span class="btn ${t.status === 'registration_open' && left > 0 ? '' : 'ghost'}">${cta}</span></div>
    </div></a>`;
}

// ---------------------------------------------------------------- Settings / user doc
export async function loadSettings() {
  try {
    const s = await getDoc(doc(db, 'settings', 'app'));
    return { ...DEFAULT_SETTINGS, ...(s.exists() ? s.data() : {}) };
  } catch { return { ...DEFAULT_SETTINGS }; }
}
export function gameList(settings) {
  const g = Array.isArray(settings?.games) && settings.games.length ? settings.games : GAMES;
  return g;
}

export async function ensureUserDoc(user) {
  const ref = doc(db, 'users', user.uid);
  const snap = await getDoc(ref);
  if (snap.exists()) return { uid: user.uid, ...snap.data() };
  // সেলফ-হিল: Auth অ্যাকাউন্ট আছে কিন্তু প্রোফাইল ডক নেই — সবসময় role "user" দিয়ে তৈরি হয়
  const data = {
    uid: user.uid,
    name: (user.displayName || (user.email || 'Player').split('@')[0]).slice(0, 50),
    email: user.email,
    role: 'user',
    status: 'active',
    balance: 0,
    winBalance: 0,
    totalMatches: 0,
    totalWins: 0,
    referralCode: user.uid.slice(0, 6).toUpperCase(),
    createdAt: serverTimestamp()
  };
  await setDoc(ref, data);
  const again = await getDoc(ref);
  return { uid: user.uid, ...again.data() };
}

export async function logout() {
  try { await signOut(auth); } catch { /* ignore */ }
  location.href = (location.pathname.includes('/admin/') ? '../' : '') + 'login.html';
}

// ---------------------------------------------------------------- Notifications (shared by badge + page)
const readKey = (uid) => `jitboi_read_${uid}`;
export function localReadSet(uid) {
  try { return new Set(JSON.parse(localStorage.getItem(readKey(uid)) || '[]')); } catch { return new Set(); }
}
export function saveLocalRead(uid, set) {
  try { localStorage.setItem(readKey(uid), JSON.stringify(Array.from(set).slice(-300))); } catch { /* ignore */ }
}
// নোটিফিকেশন ডক ID (অ্যাডমিন তৈরি করে) নতুন-আগে ক্রমে সাজানো — তাই ইনডেক্স ছাড়াই limit() কাজ করে
export async function loadNotifications(uid, max = 50) {
  const col = collection(db, 'notifications');
  const [mine, all] = await Promise.all([
    getDocs(query(col, where('userId', '==', uid), limit(max))),
    getDocs(query(col, where('userId', '==', 'all'), limit(max)))
  ]);
  const seen = localReadSet(uid);
  const items = [];
  mine.forEach((d) => items.push({ id: d.id, ...d.data(), broadcast: false, isRead: !!d.data().read }));
  all.forEach((d) => items.push({ id: d.id, ...d.data(), broadcast: true, isRead: seen.has(d.id) }));
  items.sort((a, b) => (tsToDate(b.createdAt)?.getTime() || 0) - (tsToDate(a.createdAt)?.getTime() || 0));
  return items;
}
// নতুন-আগে ক্রমের ডক ID
export function revId(prefix = '') {
  return String(9999999999999 - Date.now()).padStart(13, '0') + '_' + Math.random().toString(36).slice(2, 8) + (prefix ? '_' + prefix : '');
}

// ---------------------------------------------------------------- Shell
const NAV = [
  ['index.html', 'home', 'হোম', 'home'],
  ['tournaments.html', 'tournaments', 'টুর্নামেন্ট', 'trophy'],
  ['my-tournaments.html', 'mygames', 'আমার গেম', 'gamepad'],
  ['wallet.html', 'wallet', 'ওয়ালেট', 'wallet'],
  ['profile.html', 'profile', 'প্রোফাইল', 'user']
];

export function mountShell({ title = '', nav = null, back = false, backHref = '' } = {}) {
  const top = $('#topbar');
  const bnav = $('#bottomnav');
  if (top) {
    top.className = 'topbar';
    top.innerHTML = `
      ${back ? `<a class="icon-btn" id="backBtn" href="${esc(backHref || '#')}" aria-label="পিছনে">${icon('back')}</a><div class="title">${esc(title)}</div>`
             : `<a class="brand" href="index.html"><img src="assets/icon-192.png" alt="">JITBOI</a>`}
      <div class="spacer"></div>
      <a class="chip-wallet hidden" id="walletChip" href="wallet.html" aria-label="ওয়ালেট">${icon('wallet')}<span id="walletChipV"></span></a>
      <a class="icon-btn" href="notifications.html" aria-label="নোটিফিকেশন">${icon('bell')}<span class="dot hidden" id="notifDot">0</span></a>`;
    const bb = $('#backBtn');
    if (bb && !backHref) bb.addEventListener('click', (e) => { e.preventDefault(); if (history.length > 1) history.back(); else location.href = 'index.html'; });
  }
  if (bnav) {
    bnav.className = 'bottomnav';
    bnav.innerHTML = NAV.map(([href, key, label, ic]) => `<a href="${href}" class="${nav === key ? 'active' : ''}"><span class="pill">${icon(ic)}</span><span>${label}</span></a>`).join('');
  }
  if (title) document.title = `${title} • Jitboi`;
}

function blockScreen(html) {
  document.body.innerHTML = `<div class="blocked"><div class="box">${html}</div></div><div id="toasts"></div>`;
}

const never = () => new Promise(() => {});

export async function boot(opts = {}) {
  mountShell(opts);
  const view = $('#view');
  if (view && !opts.keepView) view.innerHTML = loaderHtml();

  const user = await new Promise((resolve) => {
    const un = onAuthStateChanged(auth, (u) => { un(); resolve(u); });
  });
  if (!user) {
    const here = location.pathname.split('/').pop() || 'index.html';
    location.replace(`login.html?next=${encodeURIComponent(here + location.search)}`);
    return never();
  }

  let profile, settings;
  try {
    [profile, settings] = await Promise.all([ensureUserDoc(user), loadSettings()]);
  } catch (e) {
    if (view) view.innerHTML = `<div class="empty"><div class="ei">${icon('alert', 'lg')}</div><h3>লোড করা যায়নি</h3><p>${esc(errMsg(e))}</p><div class="mt"><button class="btn" onclick="location.reload()">আবার চেষ্টা করুন</button></div></div>`;
    return never();
  }

  if (profile.status === 'suspended') {
    blockScreen(`<img src="assets/icon-192.png" alt=""><h2>অ্যাকাউন্ট স্থগিত</h2><p class="muted mt-s">আপনার অ্যাকাউন্টটি সাময়িকভাবে স্থগিত করা হয়েছে। বিস্তারিত জানতে সাপোর্টে যোগাযোগ করুন${settings.supportPhone ? ': ' + esc(bn(settings.supportPhone)) : ''}।</p><button class="btn mt" id="blkOut">লগআউট</button>`);
    $('#blkOut').addEventListener('click', logout);
    return never();
  }
  if (settings.maintenanceMode) {
    blockScreen(`<img src="assets/icon-192.png" alt=""><h2>রক্ষণাবেক্ষণ চলছে</h2><p class="muted mt-s">অ্যাপটি এখন রক্ষণাবেক্ষণের কাজে আছে। কিছুক্ষণ পর আবার চেষ্টা করুন।</p><button class="btn mt" onclick="location.reload()">রিফ্রেশ</button> <button class="btn ghost mt" id="blkOut">লগআউট</button>`);
    $('#blkOut').addEventListener('click', logout);
    return never();
  }

  const chip = $('#walletChip');
  if (chip) { $('#walletChipV').textContent = taka(walletTotal(profile)); chip.classList.remove('hidden'); }

  // নোটিফিকেশন ব্যাজ (ব্যাকগ্রাউন্ডে)
  if (!opts.skipBadge) {
    loadNotifications(user.uid).then((list) => {
      const n = list.filter((x) => !x.isRead).length;
      const dot = $('#notifDot');
      if (dot && n > 0) { dot.textContent = bn(n > 9 ? '9+' : n); dot.classList.remove('hidden'); }
    }).catch(() => {});
  }
  return { user, profile, settings, view };
}

export function setView(html) {
  const v = $('#view');
  if (v) v.innerHTML = html;
  startCountdowns();
  return v;
}
export function showError(e, retryable = true) {
  setView(`<div class="empty"><div class="ei">${icon('alert', 'lg')}</div><h3>সমস্যা হয়েছে</h3><p>${esc(errMsg(e))}</p>${retryable ? '<div class="mt"><button class="btn" onclick="location.reload()">আবার চেষ্টা করুন</button></div>' : ''}</div>`);
}

export const qs = (k) => new URLSearchParams(location.search).get(k);
export { ADMIN_UID };
