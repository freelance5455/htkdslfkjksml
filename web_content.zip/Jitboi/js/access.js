// =====================================================================
// Jitboi — js/access.js
// কে মালিক/স্টাফ এবং কার কী পারমিশন — শুধু UI নিয়ন্ত্রণের জন্য।
// আসল সুরক্ষা firestore.rules এ (একই নিয়ম সেখানে বাধ্যতামূলক)।
//   config/owner  : { uid }  — বর্তমান মালিক (না থাকলে firebase.js এর ADMIN_UID)
//   staff/{uid}   : { active, perms:{...} }
// =====================================================================
import { db, ADMIN_UID, doc, getDoc } from '../firebase.js';

export const PERMS = [
  ['tournaments', 'টুর্নামেন্ট তৈরি/এডিট, রুম প্রকাশ, পেইড জয়েন যাচাই'],
  ['results', 'ফলাফল ও প্রাইজ প্রকাশ'],
  ['deposits', 'ডিপোজিট অনুমোদন/বাতিল'],
  ['withdrawals', 'উইথড্র প্রসেস'],
  ['users', 'ইউজার দেখা, স্থগিত/সক্রিয়, বোনাস দেওয়া'],
  ['notifications', 'নোটিফিকেশন পাঠানো'],
  ['settings', 'অ্যাপ সেটিংস (নম্বর, ব্যানার, নোটিশ)']
];
export const ALL_PERMS = Object.fromEntries(PERMS.map(([k]) => [k, true]));

export async function getAccess(uid) {
  let ownerUid = ADMIN_UID;
  try { const c = await getDoc(doc(db, 'config', 'owner')); if (c.exists() && c.data().uid) ownerUid = c.data().uid; } catch { /* ডিফল্ট */ }
  if (uid === ownerUid) return { owner: true, staff: true, perms: ALL_PERMS, ownerUid };
  try {
    const s = await getDoc(doc(db, 'staff', uid));
    if (s.exists() && s.data().active !== false) return { owner: false, staff: true, perms: s.data().perms || {}, ownerUid };
  } catch { /* স্টাফ নয় */ }
  return { owner: false, staff: false, perms: {}, ownerUid };
}
