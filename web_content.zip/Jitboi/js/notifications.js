// =====================================================================
// Jitboi — js/notifications.js
// ইন-অ্যাপ নোটিফিকেশন। (পুশ নোটিফিকেশন নয় — তার জন্য Firebase Cloud Messaging সেটআপ লাগবে।)
// - ব্যক্তিগত নোটিফিকেশন: Firestore এ read=true হিসেবে আপডেট হয় (Rules শুধু এই ফিল্ড অনুমতি দেয়)
// - ব্রডকাস্ট (userId="all"): শেয়ার্ড ডক, তাই "পড়া" অবস্থা এই ডিভাইসের localStorage এ থাকে
// =====================================================================
import { db, doc, updateDoc, writeBatch } from '../firebase.js';
import {
  $, $$, boot, esc, icon, emptyState, fmtTs, setView, showError, toast, errMsg, withLock,
  loadNotifications, localReadSet, saveLocalRead
} from './ui.js';

const { user } = await boot({ title: 'নোটিফিকেশন', back: true, backHref: 'index.html', skipBadge: true });

try {
  let items = await loadNotifications(user.uid, 50);

  function render() {
    const unread = items.filter((n) => !n.isRead).length;
    setView(`
      <div class="row between"><div class="page-head" style="margin:0"><h1>নোটিফিকেশন</h1><p>${unread ? `${unread.toLocaleString('bn-BD')} টি অপঠিত` : 'সবগুলো পড়া হয়েছে'}</p></div>
        ${unread ? '<button class="btn sm ghost" id="readAll">সব পড়া হয়েছে</button>' : ''}</div>
      <div class="list mt">${items.length ? items.map((n) => `
        <div class="item ${n.isRead ? '' : 'unread'}" data-id="${esc(n.id)}" style="cursor:pointer">
          <div class="ico ${n.isRead ? '' : 'green'}">${icon('bell')}</div>
          <div class="grow"><div class="t">${esc(n.title)}</div><div class="s" style="color:var(--text);opacity:.85">${esc(n.message)}</div><div class="s">${esc(fmtTs(n.createdAt))}</div></div>
          ${n.isRead ? '' : '<span class="badge green">নতুন</span>'}
        </div>`).join('')
        : emptyState('কোনো নোটিফিকেশন নেই', 'টুর্নামেন্ট, ডিপোজিট বা উইথড্র আপডেট হলে এখানে জানানো হবে।', 'bell')}</div>
      <p class="small muted center mt">এগুলো অ্যাপের ভেতরের নোটিফিকেশন। ফোনে পুশ নোটিফিকেশন চালু নেই।</p>`);

    $$('.item[data-id]').forEach((el) => el.addEventListener('click', () => markOne(el.dataset.id)));
    const ra = $('#readAll');
    if (ra) ra.addEventListener('click', () => withLock(ra, markAll));
  }

  async function markOne(id) {
    const n = items.find((x) => x.id === id);
    if (!n || n.isRead) return;
    try {
      if (n.broadcast) {
        const s = localReadSet(user.uid); s.add(id); saveLocalRead(user.uid, s);
      } else {
        await updateDoc(doc(db, 'notifications', id), { read: true });
      }
      n.isRead = true;
      render();
    } catch (e) { toast(errMsg(e), 'err'); }
  }

  async function markAll() {
    try {
      const own = items.filter((n) => !n.broadcast && !n.isRead);
      for (let i = 0; i < own.length; i += 400) {
        const b = writeBatch(db);
        own.slice(i, i + 400).forEach((n) => b.update(doc(db, 'notifications', n.id), { read: true }));
        await b.commit();
      }
      const s = localReadSet(user.uid);
      items.filter((n) => n.broadcast).forEach((n) => s.add(n.id));
      saveLocalRead(user.uid, s);
      items.forEach((n) => { n.isRead = true; });
      render();
    } catch (e) { toast(errMsg(e), 'err'); }
  }

  render();
} catch (e) { showError(e); }
