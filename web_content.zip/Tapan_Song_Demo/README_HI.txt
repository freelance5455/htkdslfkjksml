Tapan Song Demo — Android मोबाइल के लिए

1. ZIP को Extract करें।
2. index.html को मोबाइल के ब्राउज़र/HTML preview ऐप में खोलें।
3. गाना जोड़ें दबाकर फोन की audio फ़ाइल चुनें।
4. खोजें, चलाएँ, पसंदीदा बनाएं और Admin Panel देखें।

सीमाएँ: यह स्थानीय डेमो है; ऑनलाइन स्टोरेज, Google Login और सुरक्षित Admin login शामिल नहीं हैं। APK बनाने के लिए इन फ़ाइलों को Android WebView wrapper या किसी भरोसेमंद HTML-to-APK बिल्ड सेवा में पैकेज करना होगा।