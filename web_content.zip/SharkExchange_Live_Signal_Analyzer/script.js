"use strict";
const $ = id => document.getElementById(id);
const API = "https://api.sharkexchange.in";
const WS = "https://fawss.sharkexchange.in/";
const FRAMES = ["3m","5m","15m"];
const state = { socket:null, pair:"BTCINR", priceType:"MARK_PRICE", price:null, ticker:null, candles:{}, analysis:{}, lastSignal:"WAIT", refreshBusy:false };
const fmt = n => Number.isFinite(Number(n)) ? Number(n).toLocaleString("en-IN",{maximumFractionDigits:8}) : "—";
const ist = d => new Intl.DateTimeFormat("en-IN",{timeZone:"Asia/Kolkata",dateStyle:"medium",timeStyle:"medium"}).format(d || new Date());

function setConnection(text, cls=""){ $("connection").textContent=text; $("connection").className="pill "+cls; }
function setStatus(text){ $("dataStatus").textContent=text; $("updated").textContent=ist(new Date()); }
function unwrapArray(payload){
  if(Array.isArray(payload)) return payload;
  if(payload && Array.isArray(payload.data)) return payload.data;
  if(payload && payload.data && Array.isArray(payload.data.data)) return payload.data.data;
  if(payload && Array.isArray(payload.result)) return payload.result;
  return [];
}
function normalizeCandle(c){
  if(Array.isArray(c)) return {time:+c[0],open:+c[1],high:+c[2],low:+c[3],close:+c[4],volume:+c[5]};
  return {time:+(c.startTime??c.openTime??c.t??c.time),open:+(c.open??c.o),high:+(c.high??c.h),low:+(c.low??c.l),close:+(c.close??c.c),volume:+(c.volume??c.v??0)};
}
async function fetchCandles(frame){
  const url = `${API}/v1/market/klines?priceType=${encodeURIComponent(state.priceType)}`;
  const body = {pair:state.pair,interval:frame,limit:250};
  const response = await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),cache:"no-store"});
  if(!response.ok) throw new Error(`Klines ${frame}: HTTP ${response.status}`);
  const raw = unwrapArray(await response.json());
  const list = raw.map(normalizeCandle).filter(c=>Number.isFinite(c.close)&&c.close>0&&Number.isFinite(c.time)).sort((a,b)=>a.time-b.time);
  if(list.length < 35) throw new Error(`${frame}: only ${list.length} valid candles received`);
  state.candles[frame]=list;
}
async function fetchTicker(){
  const r=await fetch(`${API}/v1/market/ticker24Hr/${encodeURIComponent(state.pair)}`,{cache:"no-store"});
  if(!r.ok) throw new Error(`Ticker HTTP ${r.status}`);
  const data=await r.json(); state.ticker=data?.data??data;
  const t=state.ticker;
  const change=Number(t.P??t.priceChangePercent);
  $("change").textContent=Number.isFinite(change)?`${change>=0?"+":""}${change.toFixed(2)}%`:"—";
  $("change").className="metric "+(change>0?"trend-up":change<0?"trend-down":"");
  $("highlow").textContent=`${fmt(t.h??t.highPrice)} / ${fmt(t.l??t.lowPrice)}`;
  const p=Number(t.c??t.lastPrice??t.close);
  if(Number.isFinite(p)&&p>0){state.price=p;renderPrice();}
}
function renderPrice(){
  $("price").textContent=fmt(state.price);
  $("priceTime").textContent=`${state.pair} • ${ist(new Date())}`;
}
function ema(values,period){
  if(values.length<period) return NaN;
  const k=2/(period+1); let e=values.slice(0,period).reduce((a,b)=>a+b,0)/period;
  for(let i=period;i<values.length;i++) e=values[i]*k+e*(1-k);
  return e;
}
function rsi(values,period=14){
  if(values.length<=period) return NaN;
  let gain=0,loss=0;
  for(let i=1;i<=period;i++){const d=values[i]-values[i-1]; if(d>0)gain+=d;else loss-=d;}
  let ag=gain/period,al=loss/period;
  for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];ag=(ag*(period-1)+Math.max(d,0))/period;al=(al*(period-1)+Math.max(-d,0))/period;}
  if(al===0)return 100; return 100-(100/(1+ag/al));
}
function macd(values){
  // MACD line = EMA12 - EMA26; signal line is EMA9 of the MACD series.
  const k12=2/13,k26=2/27; let e12=values[0],e26=values[0],series=[];
  for(let i=1;i<values.length;i++){e12=values[i]*k12+e12*(1-k12);e26=values[i]*k26+e26*(1-k26);series.push(e12-e26);}
  const line=series.at(-1), signal=ema(series,9);
  return {line,signal,hist:line-signal};
}
function atr(candles,period=14){
  const trs=[];
  for(let i=1;i<candles.length;i++){const c=candles[i],p=candles[i-1];trs.push(Math.max(c.high-c.low,Math.abs(c.high-p.close),Math.abs(c.low-p.close)));}
  if(trs.length<period)return NaN;
  return trs.slice(-period).reduce((a,b)=>a+b,0)/period;
}
function analyze(frame){
  const cs=state.candles[frame], closes=cs.map(c=>c.close), vols=cs.map(c=>c.volume);
  const e9=ema(closes,9),e21=ema(closes,21),e34=ema(closes,34),r=rsi(closes),m=macd(closes),a=atr(cs);
  const vAvg=vols.slice(-21,-1).reduce((x,y)=>x+y,0)/Math.max(1,vols.slice(-21,-1).length), vNow=vols.at(-1);
  const volume=vNow>vAvg*1.15?"High":vNow<vAvg*.75?"Low":"Normal";
  let score=0; if(e9>e21)score++;else score--; if(closes.at(-1)>e34)score++;else score--;
  if(m.hist>0)score++;else score--; if(r>=52)score++;else if(r<=48)score--;
  const trend=score>=2?"BUY":score<=-2?"SELL":"NEUTRAL";
  return {frame,close:closes.at(-1),e9,e21,e34,rsi:r,macd:m.hist,atr:a,atrPct:a/closes.at(-1)*100,volume,trend,score,latest:cs.at(-1)};
}
function renderRows(){
  const rows=FRAMES.map(f=>state.analysis[f]).filter(Boolean);
  $("analysisRows").innerHTML=rows.map(a=>`<tr><td><b>${a.frame}</b></td><td class="${a.trend==='BUY'?'trend-up':a.trend==='SELL'?'trend-down':'trend-neutral'}">${a.trend}</td><td>${fmt(a.e9)} / ${fmt(a.e21)}</td><td>${Number.isFinite(a.rsi)?a.rsi.toFixed(1):"—"}</td><td>${fmt(a.macd)}</td><td>${a.volume}</td><td>${Number.isFinite(a.atrPct)?a.atrPct.toFixed(3)+"%":"—"}</td></tr>`).join("")||'<tr><td colspan="7">No analysis available yet.</td></tr>';
}
function buildFinalSignal(){
  const a3=state.analysis["3m"],a5=state.analysis["5m"],a15=state.analysis["15m"];
  if(!a3||!a5||!a15){showWait("Not enough candle data yet. Need valid 3m, 5m and 15m candles.");return;}
  let signal="WAIT",reason="Timeframes do not agree strongly enough.";
  if(a5.trend===a15.trend && ["BUY","SELL"].includes(a5.trend)){
    if(a3.trend===a5.trend){signal=a5.trend;reason=`${a5.frame} and ${a15.frame} agree ${signal}; ${a3.frame} confirms. EMA, RSI and MACD contribute to the trend score.`;}
    else {reason=`${a5.frame} and ${a15.frame} agree ${a5.trend}, but ${a3.frame} does not confirm. Waiting for alignment.`;}
  } else {reason="5m and 15m trends must agree. Wait for clearer alignment.";}
  $("signalBadge").textContent=signal;$("signalBadge").className=`signal ${signal.toLowerCase()}`;
  $("signalReason").textContent=reason;
  const price=state.price??a5.close, risk=a5.atr;
  $("entry").textContent=fmt(price);
  $("target").textContent=signal==="BUY"&&Number.isFinite(risk)?fmt(price+1.5*risk):signal==="SELL"&&Number.isFinite(risk)?fmt(price-1.5*risk):"—";
  $("stop").textContent=signal==="BUY"&&Number.isFinite(risk)?fmt(price-risk):signal==="SELL"&&Number.isFinite(risk)?fmt(price+risk):"—";
  $("signalTime").textContent=ist(new Date());
  $("indicatorNotes").textContent=`3m: ${a3.trend} (RSI ${a3.rsi.toFixed(1)}); 5m: ${a5.trend} (RSI ${a5.rsi.toFixed(1)}); 15m: ${a15.trend} (RSI ${a15.rsi.toFixed(1)}). Relative volume: ${a5.volume} on 5m. ATR-based levels are estimates and are shown only when a directional signal is confirmed.`;
  state.lastSignal=signal;
}
function showWait(reason){$("signalBadge").textContent="WAIT";$("signalBadge").className="signal wait";$("signalReason").textContent=reason;$("entry").textContent=fmt(state.price);$("target").textContent="—";$("stop").textContent="—";$("signalTime").textContent=ist(new Date());}
async function refreshAll(){
  if(state.refreshBusy)return; state.refreshBusy=true; setStatus("Fetching candles…");
  try{
    await fetchTicker().catch(e=>console.warn(e));
    const results=await Promise.allSettled(FRAMES.map(fetchCandles));
    const failures=results.filter(r=>r.status==="rejected");
    for(const f of FRAMES){if(state.candles[f]?.length>=35)state.analysis[f]=analyze(f);}
    renderRows();buildFinalSignal();
    if(failures.length){setStatus("Partial data");const msg=failures.map(x=>x.reason?.message||"API error").join(" • ");$("dataStatus").title=msg;}
    else setStatus("Live • analysis ready");
    if(state.price==null){const a=state.candles["5m"]?.at(-1);if(a){state.price=a.close;renderPrice();}}
  }catch(e){console.error(e);setStatus("Market data error");$("dataStatus").title=e.message;showWait(`Market data error: ${e.message}. Check connection, pair name and Shark API status.`);}
  finally{state.refreshBusy=false;}
}
function connectSocket(){
  if(state.socket){state.socket.disconnect();state.socket=null;}
  if(typeof io!=="function"){setConnection("Socket.IO library unavailable","error");return;}
  const socket=io(WS,{transports:["websocket","polling"],reconnection:true,timeout:12000});state.socket=socket;
  socket.on("connect",()=>{setConnection("Connected","online");const p=state.pair.toLowerCase();socket.emit("subscribe",{params:[`${p}@markPrice`,`${p}@ticker`,...FRAMES.map(f=>`${p}@kline_${f}`)]});});
  socket.on("disconnect",()=>setConnection("Disconnected","error"));
  socket.on("connect_error",e=>{setConnection("Socket reconnecting","error");console.warn("Socket.IO",e.message);});
  socket.on("markPriceUpdate",d=>{const x=d?.data??d;const p=Number(x?.p??x?.price??x?.markPrice??x?.c);if(Number.isFinite(p)&&p>0){state.price=p;renderPrice();}});
  socket.on("24hrTicker",d=>{const x=d?.data??d;state.ticker=x;const p=Number(x?.c??x?.lastPrice);if(Number.isFinite(p)&&p>0){state.price=p;renderPrice();}const ch=Number(x?.P);if(Number.isFinite(ch)){$("change").textContent=`${ch>=0?"+":""}${ch.toFixed(2)}%`;$("change").className="metric "+(ch>0?"trend-up":ch<0?"trend-down":"");}$("highlow").textContent=`${fmt(x?.h)} / ${fmt(x?.l)}`;});
  socket.on("kline",d=>{const x=d?.data??d;const symbol=String(x?.s??x?.pair??state.pair).toUpperCase();if(symbol!==state.pair)return;const k=x?.k??x;const frame=String(k?.i??k?.interval??"").toLowerCase();const candle=normalizeCandle(k);const f=FRAMES.includes(frame)?frame:null;if(f&&Number.isFinite(candle.close)&&candle.close>0){const arr=state.candles[f]||[];const idx=arr.findIndex(c=>c.time===candle.time);if(idx>=0)arr[idx]=candle;else arr.push(candle);arr.sort((a,b)=>a.time-b.time);state.candles[f]=arr.slice(-300);if(arr.length>=35){state.analysis[f]=analyze(f);renderRows();buildFinalSignal();}}});
}
$("pair").addEventListener("change",()=>{state.pair=$("pair").value;state.price=null;state.candles={};state.analysis={};$("price").textContent="—";connectSocket();refreshAll();});
$("priceType").addEventListener("change",()=>{state.priceType=$("priceType").value;state.candles={};state.analysis={};refreshAll();});
$("refresh").addEventListener("click",refreshAll);
connectSocket();refreshAll();setInterval(refreshAll,60000);
