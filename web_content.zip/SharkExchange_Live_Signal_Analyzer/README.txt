SHARK EXCHANGE LIVE SIGNAL ANALYZER
===================================

Files:
- index.html: app interface
- style.css: responsive styling
- script.js: public Shark API connection, indicators and signal logic

Features:
- Live price and 24h ticker via Shark Exchange public Socket.IO stream
- Public REST candles for 3m, 5m, 15m using POST /v1/market/klines?priceType=MARK_PRICE (or LAST_PRICE)
- EMA 9/21/34, RSI(14), MACD histogram, ATR(14), relative volume
- Final signal requires 5m and 15m agreement plus 3m confirmation
- ATR-based reference target and stop only when a BUY/SELL signal is confirmed
- India Standard Time display
- No API key is needed for these documented public market endpoints; do not place secret API keys in browser code.

HOW TO USE
1. Extract this ZIP.
2. Open index.html in a browser with internet access, or host the folder on a static web host.
3. Select a pair and candle price type.
4. Watch the connection status. If market data fails, inspect browser console and Shark API availability.
5. For a WebView/APK, use the hosted HTTPS page or package the files in your WebView builder with internet permission enabled.

IMPORTANT NOTES
- Shark API data shapes or server access/CORS policies can change. This project uses the public endpoints and event names described in the Shark API documentation, with defensive response parsing; the live connection must still be tested from your network/browser.
- Socket.IO kline event payloads can vary. REST candle refresh runs every 60 seconds as a fallback.
- Signal output is an indicator-based estimate, not a guarantee or financial advice. This app does not place trades.
- The target and stop are indicative ATR levels, not exchange-native order levels.
- Official docs: https://docs.sharkexchange.in/
