# TradeHertz Kelly Calculator — Android APK starter

This Android Studio project wraps the supplied calculator HTML in an Android WebView. The calculator is bundled locally and can run offline.

## Build an APK
1. On a computer, install Android Studio (current stable) and a compatible JDK.
2. Open Android Studio → **Open** → choose this `TradeHertz_Kelly_APK_Starter` folder.
3. Allow Gradle sync and install any SDK platform/build tools Android Studio requests.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When finished, click **Locate** in the notification. The APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. Android may ask you to allow installs from that file manager.

## Notes
- This is the source project, not a precompiled APK.
- An Android SDK/Gradle build environment is required to compile the APK. This workspace does not have a configured Android build toolchain.
- Package ID: `pro.tradehertz.kelly`
- App name: `TradeHertz Kelly`
- The app uses the HTML file in `app/src/main/assets/index.html`. Edit that file to update the calculator.
- The calculator's bullish/bearish values are percentage-based scenarios, not a forecast or probability.
