import { Link, NavLink } from 'react-router-dom';
import { CarFront, Menu, X } from 'lucide-react';
import { useState } from 'react';

const links = [
  { to: '/', label: 'الرئيسية' },
  { to: '/client', label: 'احجز رحلة' },
  { to: '/driver', label: 'للسائقين' },
  { to: '/admin', label: 'الإدارة' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return <header className="site-header"><div className="header-inner">
    <Link to="/" className="brand" onClick={() => setOpen(false)}><span className="brand-mark"><CarFront size={22}/></span><span>مشوار<span className="brand-dot">.</span><small>كل لبنان أقرب</small></span></Link>
    <button className="mobile-toggle" onClick={() => setOpen(!open)} aria-label="فتح القائمة">{open ? <X/> : <Menu/>}</button>
    <nav className={open ? 'nav-links open' : 'nav-links'}>{links.map(item => <NavLink key={item.to} to={item.to} end={item.to === '/'} onClick={() => setOpen(false)}>{item.label}</NavLink>)}<Link className="nav-cta" to="/client" onClick={() => setOpen(false)}>اطلب سيارة <span>←</span></Link></nav>
  </div></header>;
}
