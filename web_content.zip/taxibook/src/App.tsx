import { Routes, Route } from 'react-router-dom';
import ClientApp from './pages/ClientApp';
import DriverApp from './pages/DriverApp';
import AdminApp from './pages/AdminApp';
import ImageEditorPage from './pages/ImageEditorPage';
import HomePage from './pages/HomePage';
import Navbar from './components/Navbar';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 font-sans antialiased flex flex-col">
      <Navbar />
      <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/client" element={<ClientApp />} />
          <Route path="/driver" element={<DriverApp />} />
          <Route path="/admin" element={<AdminApp />} />
          <Route path="/image-editor" element={<ImageEditorPage />} />
        </Routes>
      </main>
      <footer className="bg-gray-800 text-white text-center p-4">
        <p>&copy; 2026 مشوار — نموذج حجز رحلات في لبنان</p>
      </footer>
    </div>
  );
}

export default App;
