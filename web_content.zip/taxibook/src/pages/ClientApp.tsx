import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowUpLeft, CalendarDays, CarFront, Check, Clock3, LocateFixed, MapPin, Phone, Users } from 'lucide-react';

const places = ['وسط بيروت، بيروت', 'الحمرا، بيروت', 'مطار رفيق الحريري الدولي', 'جونية، كسروان', 'طرابلس، الشمال', 'صيدا، الجنوب', 'زحلة، البقاع', 'صور، الجنوب'];
const beirutClock = () => new Intl.DateTimeFormat('ar-LB', { timeZone: 'Asia/Beirut', hour: '2-digit', minute: '2-digit' }).format(new Date());

export default function ClientApp() {
  const [from, setFrom] = useState(places[0]);
  const [to, setTo] = useState(places[2]);
  const [phone, setPhone] = useState('+961 ');
  const [ride, setRide] = useState('اقتصادية');
  const [booked, setBooked] = useState(false);
  const [beirutTime, setBeirutTime] = useState(beirutClock);
  useEffect(() => {
    const timer = window.setInterval(() => setBeirutTime(beirutClock()), 60_000);
    return () => window.clearInterval(timer);
  }, []);
  const phoneValid = /^\+961\s?\d{1,2}[\s-]?\d{3}[\s-]?\d{3}$/.test(phone.trim());
  const price = ride === 'اقتصادية' ? '$8' : ride === 'مريحة' ? '$12' : '$18';

  return <div className="page-shell">
    <div className="page-heading"><div><span className="section-kicker">رحلتك تبدأ هون</span><h1>احجز مشوارك</h1><p>من وين لوين؟ خبرنا وخلّينا نهتم بالباقي.</p></div><span className="country-pill">🇱🇧 لبنان · USD</span></div>
    {booked ? <div className="success-card"><div className="success-icon"><Check/></div><span className="section-kicker">تم تسجيل طلبك</span><h2>مشوارك صار بالطريق.</h2><p>هذه معاينة تجريبية؛ لم يُرسل الطلب إلى سائق فعلي.</p><div className="summary-line"><span>{from}</span><ArrowLeft size={16}/><span>{to}</span></div><button className="button button-primary" onClick={() => setBooked(false)}>حجز رحلة ثانية</button></div> : <div className="booking-layout">
      <section className="booking-card"><div className="booking-step"><span>01</span><div><b>تفاصيل الرحلة</b><small>حدد نقطة الانطلاق والوجهة</small></div></div>
        <label className="field-label" htmlFor="from">نقطة الانطلاق</label><div className="input-wrap"><span className="field-dot green"/><select id="from" value={from} onChange={e => setFrom(e.target.value)}>{places.map(p => <option key={p}>{p}</option>)}</select><LocateFixed size={17}/></div>
        <div className="route-divider"/><label className="field-label" htmlFor="to">الوجهة</label><div className="input-wrap"><span className="field-dot red"/><select id="to" value={to} onChange={e => setTo(e.target.value)}>{places.map(p => <option key={p}>{p}</option>)}</select><MapPin size={17}/></div>
        <div className="form-row"><div><label className="field-label" htmlFor="date">موعد الرحلة (توقيت بيروت)</label><div className="input-wrap"><CalendarDays size={17}/><input id="date" type="datetime-local"/></div></div><div><label className="field-label" htmlFor="passengers">الركاب</label><div className="input-wrap"><Users size={17}/><select id="passengers"><option>راكب واحد</option><option>راكبان</option><option>3 ركاب</option><option>4 ركاب</option></select></div></div></div>
        <label className="field-label">نوع السيارة</label><div className="ride-options">{['اقتصادية', 'مريحة', 'عائلية'].map((label, i) => <button key={label} type="button" className={ride === label ? 'ride-option selected' : 'ride-option'} onClick={() => setRide(label)}><CarFront/><span><b>{label}</b><small>{['حتى 3 ركاب', 'مساحة إضافية', 'حتى 6 ركاب'][i]}</small></span><strong>{['$8', '$12', '$18'][i]}</strong></button>)}</div>
        <label className="field-label" htmlFor="phone">رقم الهاتف اللبناني</label><div className="input-wrap"><Phone size={17}/><input id="phone" inputMode="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+961 70 123 456"/></div><small className="field-hint">أدخل رقمًا صالحًا يبدأ بمفتاح لبنان ‎+961</small>
        <button className="button button-primary submit-booking" disabled={!phoneValid} onClick={() => setBooked(true)}>تابع إلى تأكيد الرحلة <ArrowUpLeft size={18}/></button><p className="demo-note">تجربة توضيحية — لن يتم إجراء حجز حقيقي أو خصم أي مبلغ.</p>
      </section>
      <aside className="booking-aside"><div className="aside-map"><div className="map-pattern"/><div className="map-pin-large"><MapPin/></div><div className="map-aside-label">لبنان <span>33° 53′ N</span></div><div className="map-road road-one"/><div className="map-road road-two"/></div><div className="aside-info"><span className="info-icon"><Clock3 size={18}/></span><div><b>الساعة الآن في بيروت</b><small>{beirutTime} · Asia/Beirut</small></div></div><div className="price-info"><span>تقدير السعر</span><strong>{price} <small>USD</small></strong><small>السعر النهائي يحدده مسار الرحلة</small></div><div className="aside-secure">✓ <span>بياناتك تبقى ضمن هذه المعاينة</span></div></aside>
    </div>}
  </div>;
}
