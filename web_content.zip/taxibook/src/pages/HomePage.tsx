import { ArrowUpLeft, BadgeCheck, Clock3, MapPin, MoveLeft, ShieldCheck, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const highlights = [
  { icon: <Clock3/>, title: 'على موعدك', text: 'خطط لمشاويرك داخل المدينة وبين المناطق.' },
  { icon: <ShieldCheck/>, title: 'رحلة مطمئنة', text: 'تفاصيل السائق والرحلة واضحة قبل الانطلاق.' },
  { icon: <BadgeCheck/>, title: 'سعر واضح', text: 'اعرف تقدير التكلفة بالدولار قبل تأكيد الطلب.' },
];

export default function HomePage() {
  return <div className="home-page">
    <section className="hero">
      <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot"/> مشاوير لبنان، ببساطة</div>
        <h1>مشوارك الجاي؟<br/><em>خلّيه علينا.</em></h1>
        <p className="hero-lead">من قلب بيروت إلى آخر الطريق، احجز سيارة بتفاصيل واضحة وخطوات قليلة.</p>
        <div className="hero-actions"><Link to="/client" className="button button-primary">احجز مشوارك <ArrowUpLeft size={18}/></Link><Link to="/driver" className="text-link">أنا سائق <MoveLeft size={16}/></Link></div>
        <div className="hero-proof"><div className="avatar-stack"><i>ر</i><i>م</i><i>ل</i><span>+</span></div><span><strong>طريقك أسهل</strong><small>من أول نقرة لحدّ الوصول</small></span></div>
      </div>
      <div className="hero-art"><div className="sun-glow"/><div className="hero-map"><svg viewBox="0 0 520 440" aria-hidden="true"><path d="M45 305 C98 245 76 207 158 195 S216 120 283 146 337 111 398 76 444 104 486 68"/><path d="M76 380 C139 330 127 273 208 260 S284 185 340 206 396 173 463 137"/><path d="M53 125 C120 151 174 97 228 105 S301 77 355 111 424 191 484 188"/><path d="M111 45 C153 92 132 146 172 187 S234 242 223 308 258 370 269 420"/><path d="M344 28 C328 93 370 136 348 188 S371 252 345 293 380 358 369 424"/><path d="M29 226 C99 213 135 230 185 215 S267 210 317 231 406 247 491 224"/></svg><div className="map-label label-beirut"><span/> بيروت</div><div className="map-label label-jounieh"><span/> جونية</div><div className="map-label label-sidon"><span/> صيدا</div><div className="map-route"><span className="route-start"/><span className="route-line"/><span className="route-end"><MapPin size={17}/></span></div><div className="car-card"><div className="car-icon"><span>🚕</span></div><div><b>مشوارك بانتظارك</b><small>بيروت · لبنان</small></div><Sparkles size={16} className="sparkle"/></div><div className="ride-chip"><span className="chip-check">✓</span><span><b>سعر واضح</b><small>قبل تأكيد الرحلة</small></span></div></div><div className="art-caption">لبنان على الطريق <span>33° 53′ شمالًا</span></div></div>
    </section>
    <section className="benefits"><div className="section-kicker">ليش مشوار؟ <span>ـــــــــ</span></div><div className="benefit-grid">{highlights.map((item, i) => <article className="benefit-card" key={item.title}><div className="benefit-icon">{item.icon}</div><div className="benefit-num">0{i+1}</div><h3>{item.title}</h3><p>{item.text}</p></article>)}</div></section>
    <section className="cities"><div><span className="section-kicker">منطقتك ضمن الخريطة</span><h2>من بيروت،<br/>وكل لبنان.</h2><p>أمثلة وجهات محلية لتبدأ منها. أضف تفاصيل مشوارك من صفحة الحجز.</p><Link to="/client" className="text-link">اختار وجهتك <MoveLeft size={16}/></Link></div><div className="city-tags">{['بيروت','جونية','طرابلس','صيدا','صور','زحلة','بعبدا','عاليه'].map((city, i) => <span className={i === 0 ? 'city-tag featured' : 'city-tag'} key={city}>{city}<small>{i === 0 ? 'الوجهة الأكثر طلبًا' : 'لبنان'}</small></span>)}</div></section>
    <footer className="home-footer"><span>© 2026 مشوار — نموذج تجريبي لحجز الرحلات في لبنان</span><Link to="/image-editor">محرر الصور <MoveLeft size={13}/></Link></footer>
  </div>;
}
