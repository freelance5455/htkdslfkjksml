Dal Mill Executive Manager

How to use:
1. Extract dal_mill_manager.zip.
2. Open index.html in a modern browser (Chrome recommended).
3. Your shift records are saved in that browser's local storage.

Important:
- Data is stored locally in the browser/device. Clearing browser data or changing devices may remove or hide records.
- Use the same browser and device for continued records.
- WhatsApp sharing requires WhatsApp or a compatible browser/app.
