#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo 'Install Node.js 22+ first.'; exit 1; }
command -v npm >/dev/null || { echo 'npm was not found.'; exit 1; }
if [ ! -d node_modules ]; then npm install; fi
if [ ! -x android/gradlew ]; then npx cap add android; fi
npx cap sync android
npx cap open android
