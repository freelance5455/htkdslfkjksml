MYTHWEAVE ANDROID APP — PIXEL QUEST EDITION
===========================================

WHAT THIS DELIVERABLE IS
- Android-ready Capacitor project scaffold using the existing Mythweave game.
- Pixel-art-inspired retro CSS skin and touch-friendly responsive layout.
- Local-only saves: the game's autosave uses WebView localStorage on the device.
- No server, account, analytics, external fonts, or runtime network access is required by the game.
- Export JSON / Import remain available as portable save backups.

IMPORTANT
This is the Android project source package, not a precompiled APK. An APK must be compiled using Android build tools. This environment does not have a configured Android SDK/Android Studio installation, so it cannot honestly provide a tested APK binary yet.

REQUIREMENTS
1. A computer (Windows, macOS, or Linux).
2. Node.js 22 or newer.
3. Android Studio and an Android SDK installed through its SDK Manager.
4. Internet access once for npm dependencies / Gradle dependencies. Gameplay itself is offline.

WINDOWS QUICK START
1. Extract this ZIP.
2. Install Node.js 22+ and Android Studio.
3. Double-click BUILD_ANDROID_WINDOWS.bat.
4. Wait for Android Studio to open and finish Gradle sync.
5. In Android Studio, choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. For a debug APK, the output is normally android/app/build/outputs/apk/debug/app-debug.apk.

MAC / LINUX QUICK START
1. Extract the ZIP.
2. Install Node.js 22+ and Android Studio + SDK.
3. Run: ./BUILD_ANDROID_MAC_LINUX.sh
4. In Android Studio, choose Build > Build Bundle(s) / APK(s) > Build APK(s).
   Or, after Android project setup, run from this folder:
   cd android && ./gradlew assembleDebug
5. Debug APK normally appears at android/app/build/outputs/apk/debug/app-debug.apk.

PHONE INSTALLATION
Transfer app-debug.apk to your own Android phone and open it to install. Android may ask you to allow installation from the file app you used. Only install APKs you built or trust. The debug APK is for personal testing, not Play Store release.

SAVE BEHAVIOR
- Autosaves are stored in this app's private WebView storage on the device.
- Uninstalling the app or clearing its storage can delete local autosaves.
- Use in-game Export JSON for backups and Import to restore them.
- No cloud save is configured.

PROJECT DETAILS
App name: Mythweave
Application ID: com.mythweave.endlessrpg
Web asset directory: www/
Framework: Capacitor 8
Game source: www/index.html (self-contained game script)

IF YOU CHANGE THE GAME
Edit www/index.html, then run `npx cap sync android` before rebuilding the APK.

OFFICIAL BUILD REFERENCES
Capacitor environment setup: https://capacitorjs.com/docs/getting-started/environment-setup
Capacitor Android: https://capacitorjs.com/docs/android
Android Studio build/run: https://developer.android.com/studio/run
