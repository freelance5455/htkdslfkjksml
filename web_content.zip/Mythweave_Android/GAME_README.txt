MYTHWEAVE — ENDLESS FANTASY CARD RPG
====================================

QUICK START
1. Extract the ZIP anywhere.
2. Open index.html in a modern desktop browser (Chrome, Edge, Firefox, or Safari).
3. Enter a hero name and choose exactly THREE classes, then start your adventure.
4. Explore the world, open the Combat tab, play cards, manage intent and resources, earn rewards, improve your build, and keep exploring indefinitely.

This is a self-contained offline game. It uses no external scripts, fonts, images, servers, accounts, or network requests.

WHAT'S INCLUDED
- 20 playable classes; choose 3 at character creation. Class resources and distinct, swappable stances create different hybrid builds.
- 280 uniquely named cards across attack, spell, defense, summon, technique, utility, passive, and curse roles.
- 12 card-fusion recipes that consume compatible cards and resources to make persistent custom cards, including elemental reactions.
- 128 uniquely named weapons, armor, accessories, and relics, with rarity, item effects, upgrades, crafting, trading, and loot.
- 468 enemy archetypes built from species and tactical mutations, with different stats, resistances, weaknesses, intents, and mutation behaviors.
- 864 encounter blueprints across regions, hazards, modifiers, and objectives. Battles can include 1–5 foes and non-defeat objectives.
- Armor, Block, Ward, Evade, Armor Break, status effects, telegraphed enemy intent, enemy AI, class resources, mana, energy, stamina, elemental reactions, and multi-system synergies.
- Levels, experience, stat progression, skill points, reward choices, optional quests, factions, rumors, secrets, crafting, merchants, travel, achievements, and long-term goals.
- Eight in-game reference tabs: World, Combat, Deck, Hero, Inventory, Craft, Journal, and Codex.

SAVING YOUR ADVENTURE
The game attempts to autosave to this browser's local storage. Browser privacy settings can restrict local storage for files opened directly from disk, so use the in-game “Export JSON” button regularly to save a portable backup. “Import” restores a previously exported save. Keep backup JSON files somewhere safe. Clearing browser data can remove the local autosave.

GAME RULES NOTES
- A turn refreshes energy and draws cards. Card costs and targeting are shown before you play them.
- Enemy intent is telegraphed when practical. Stun, freeze, interruption, armor break, elemental reactions, and tactical objectives can change the course of combat.
- Armor Break removes armor in bounded stacks and expires; it is not an unlimited defense shred.
- Elemental reactions are defined in the Codex. They do not recursively trigger themselves.
- Combat and world rewards follow the game's rules; an escape grants reduced rewards rather than pretending a victory occurred.
- There is no forced main story or fixed ending. Exploration and encounters continue to be generated as you play.

TROUBLESHOOTING
- If a browser blocks local file storage, continue playing and export saves with the in-game button.
- For best results, use a current desktop browser and a screen wide enough to display the card grid comfortably.
- No installation or build step is required. The entire game is contained in index.html.

Build: Mythweave Offline Edition
