@echo off
setlocal
cd /d "%~dp0"
echo === Mythweave Android setup ===
where node >nul 2>nul || (echo Install Node.js 22+ first. & pause & exit /b 1)
where npm >nul 2>nul || (echo npm was not found. Install Node.js 22+ first. & pause & exit /b 1)
if not exist node_modules call npm install || (echo npm install failed. & pause & exit /b 1)
if not exist android\gradlew.bat (
  echo Generating native Android project...
  call npx cap add android || (echo Android project creation failed. & pause & exit /b 1)
)
call npx cap sync android || (echo Capacitor sync failed. & pause & exit /b 1)
echo.
echo Project is ready. Opening Android Studio...
call npx cap open android
pause
