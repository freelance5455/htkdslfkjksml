from datetime import datetime, timezone
from typing import Literal
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="XAU Trader API", version="0.1.0")

class State:
    mode: Literal["DEMO", "LIVE"] = "DEMO"
    bot_running = False
    kill_switch = False
    daily_pnl = 0.0
    equity = 10000.0
    balance = 10000.0
    position = 0.0
    entry = 0.0
    price = 0.0
    spread = 0.0
    regime = "NEUTRAL"
    signal = "FLAT"
    confidence = 0.0
    last_tick = datetime.now(timezone.utc)
    trades = []
    max_daily_loss = 100.0
    max_positions = 1
    max_spread = 1.50
    risk_per_trade = 0.25

S = State()

class Tick(BaseModel):
    bid: float = Field(gt=0)
    ask: float = Field(gt=0)
    timestamp: datetime | None = None

class RiskConfig(BaseModel):
    max_daily_loss: float = Field(gt=0)
    max_positions: int = Field(ge=1, le=20)
    max_spread: float = Field(gt=0)
    risk_per_trade: float = Field(gt=0, le=5)

class Order(BaseModel):
    side: Literal["BUY", "SELL"]
    volume: float = Field(gt=0)
    price: float = Field(gt=0)
    stop_loss: float | None = None
    take_profit: float | None = None

@app.get("/health")
def health():
    return {"status":"ok", "time":datetime.now(timezone.utc)}

@app.get("/api/state")
def state():
    return {
        "mode": S.mode, "bot_running": S.bot_running, "kill_switch": S.kill_switch,
        "daily_pnl": round(S.daily_pnl,2), "equity": round(S.equity,2),
        "balance": round(S.balance,2), "position": S.position, "entry": S.entry,
        "price": S.price, "spread": S.spread, "regime": S.regime,
        "signal": S.signal, "confidence": S.confidence,
        "risk_used": min(100, abs(S.position) * 10),
        "last_tick": S.last_tick,
    }

@app.post("/api/bot/start")
def start():
    if S.kill_switch: raise HTTPException(409, "Kill switch is active")
    S.bot_running = True
    return {"ok": True, "bot_running": True}

@app.post("/api/bot/pause")
def pause():
    S.bot_running = False
    return {"ok": True, "bot_running": False}

@app.post("/api/bot/kill")
def kill():
    S.kill_switch = True
    S.bot_running = False
    return {"ok": True, "kill_switch": True}

@app.post("/api/bot/reset-kill")
def reset_kill():
    S.kill_switch = False
    return {"ok": True}

@app.post("/api/config/risk")
def risk(c: RiskConfig):
    S.max_daily_loss = c.max_daily_loss
    S.max_positions = c.max_positions
    S.max_spread = c.max_spread
    S.risk_per_trade = c.risk_per_trade
    return {"ok": True}

@app.post("/api/market/tick")
def tick(t: Tick):
    if t.ask <= t.bid: raise HTTPException(400, "Ask must be greater than bid")
    S.price = (t.bid+t.ask)/2
    S.spread = t.ask-t.bid
    S.last_tick = t.timestamp or datetime.now(timezone.utc)
    # Simple transparent regime placeholder; replace with validated research models.
    S.regime = "TREND" if S.spread < S.max_spread and S.price else "NEUTRAL"
    S.signal = "FLAT"
    S.confidence = 0.0
    return state()

@app.post("/api/order/demo")
def demo_order(o: Order):
    if S.mode != "DEMO": raise HTTPException(403, "Demo endpoint disabled in live mode")
    if S.kill_switch or not S.bot_running: raise HTTPException(409, "Bot is not authorized to trade")
    if S.daily_pnl <= -S.max_daily_loss: raise HTTPException(409, "Daily loss limit reached")
    if S.spread > S.max_spread: raise HTTPException(409, "Spread limit reached")
    if abs(S.position) >= S.max_positions: raise HTTPException(409, "Position limit reached")
    signed = o.volume if o.side == "BUY" else -o.volume
    S.position += signed
    S.entry = o.price
    S.trades.append({"time":datetime.now(timezone.utc).isoformat(), **o.model_dump()})
    return {"ok": True, "mode":"DEMO", "position":S.position}

@app.post("/api/close-all")
def close_all():
    if S.position != 0 and S.price:
        pnl = (S.price-S.entry) * S.position
        S.daily_pnl += pnl
        S.equity += pnl
    S.position = 0.0
    S.entry = 0.0
    return {"ok": True, "daily_pnl": round(S.daily_pnl,2)}
