# XAU Trader — Android Release Build

This package contains the XAU Trader Flutter mobile source plus scripts that generate the Android wrapper and build a release APK.

## What you need

On a Windows PC:

1. Flutter SDK installed and added to PATH.
2. Android Studio installed, including Android SDK and Android SDK Platform-Tools.
3. An Android device with USB debugging enabled, or an Android emulator.
4. The XAU Trader backend running on a computer/VPS reachable by the phone.

Verify the toolchain:

```powershell
flutter doctor
```

Resolve any Android toolchain errors reported by `flutter doctor` before building.

## 1. Prepare the Android project

Open PowerShell in the project root and run:

```powershell
.\scripts\prepare_android.ps1
```

Or manually:

```powershell
cd mobile
flutter create --platforms=android --org com.xautrader --project-name xau_trader .
flutter pub get
```

This creates the standard Android Gradle project under `mobile/android/` using the Flutter version installed on your machine.

## 2. Configure the backend URL

The app reads the API URL from a Dart compile-time variable.

For an Android emulator talking to a backend on the same PC:

```powershell
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000
```

For a physical phone on the same Wi-Fi network, replace the URL with your PC's LAN address, for example:

```powershell
flutter run --dart-define=API_BASE_URL=http://192.168.1.50:8000
```

For a VPS with HTTPS:

```powershell
flutter build apk --release --dart-define=API_BASE_URL=https://api.example.com
```

Do not expose a development server directly to the public internet. For live use, put the API behind HTTPS, authentication, firewall rules and a reverse proxy.

## 3. Test on a phone

```powershell
cd mobile
flutter devices
flutter run --dart-define=API_BASE_URL=http://YOUR_PC_IP:8000
```

## 4. Build the release APK

From the project root:

```powershell
$env:API_BASE_URL='https://YOUR_SECURE_SERVER'
.\scripts\build_release.ps1
```

The APK will be created at:

```text
mobile\build\app\outputs\flutter-apk\app-release.apk
```

You can copy that APK to an Android phone and install it.

## 5. Signed release for distribution

For a personal/test installation, the unsigned-by-you Flutter release configuration can be used while evaluating the app. For Play Store or formal distribution, create your own upload keystore and configure signing in `mobile/android/key.properties` and `mobile/android/app/build.gradle` after the Android wrapper has been generated.

Generate a keystore with:

```powershell
keytool -genkeypair -v -keystore xau-trader-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias xau-trader
```

Keep the `.jks` file and passwords private. Do not commit them to Git.

Then configure Gradle signing using the generated `key.properties`. Flutter's generated Android project is intentionally used here so signing configuration matches the installed Flutter/Gradle toolchain.

For a Play Store bundle, build:

```powershell
flutter build appbundle --release --dart-define=API_BASE_URL=https://YOUR_SECURE_SERVER
```

Output:

```text
mobile\build\app\outputs\bundle\release\app-release.aab
```

## 6. Backend

The APK is a control client. It expects the FastAPI backend in `backend/` to be running.

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

The current package is configured as DEMO mode. Do not connect it to a live account until authentication, persistent storage, broker execution, monitoring and independent risk testing have been completed.

## 7. MT5 bridge

Compile `mt5/XAUTraderBridge.mq5` in MetaEditor and attach it to an XAUUSD chart. Configure the backend URL in the EA and allow the URL in MT5 WebRequest settings.

The current bridge is an integration adapter; it is not a substitute for server-side risk controls.

## Release checklist

Before distributing a live-trading build:

- [ ] HTTPS API endpoint
- [ ] Authentication and authorization
- [ ] Secrets stored outside the APK
- [ ] Persistent audit/trade storage
- [ ] Independent server-side risk gateway
- [ ] MT5 command authentication
- [ ] Stale-data and disconnect handling
- [ ] Max daily loss / exposure / position controls
- [ ] Kill switch and emergency flatten tested
- [ ] Demo and historical testing completed
- [ ] Execution-cost/slippage testing completed
- [ ] APK/AAB signed with a protected release key
- [ ] Monitoring and alerts enabled
