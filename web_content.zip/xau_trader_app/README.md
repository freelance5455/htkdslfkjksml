# XAU Trader — Android Release Package

XAU Trader is a Flutter mobile control app for the requested architecture:

**Phone → API/server → trading engine/risk gate → MT5 bridge → broker**

The mobile app is intentionally a control surface rather than a place to store broker secrets or make final risk decisions.

## Fastest Android build

### Windows

1. Install Flutter and Android Studio.
2. Open PowerShell in this project folder.
3. Run:

```powershell
.\scripts\prepare_android.ps1
$env:API_BASE_URL='http://YOUR_PC_IP:8000'
.\scripts\build_release.ps1
```

APK:

`mobile\build\app\outputs\flutter-apk\app-release.apk`

### Linux/macOS

```bash
./scripts/prepare_android.sh
API_BASE_URL=http://YOUR_PC_IP:8000 ./scripts/build_release.sh
```

See `BUILD_ANDROID.md` for signing, Play Store AAB builds, phone testing, backend setup and the live-trading safety checklist.

## Current functionality

- XAU/USD dashboard
- bot start/pause
- emergency close-all command
- kill switch
- price/spread display
- position and daily P&L display
- regime and signal display
- configurable API endpoint at build time
- FastAPI demo backend
- MT5 bridge source

## Safety

The included system defaults to DEMO mode. It should not be represented as a validated profitable trading strategy. Live trading requires additional authentication, persistent storage, monitoring, secure execution, and risk testing.
