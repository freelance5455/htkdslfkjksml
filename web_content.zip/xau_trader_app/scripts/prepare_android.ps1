$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..\mobile')

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  Write-Error 'Flutter is not installed or not on PATH. Install Flutter, then rerun this script.'
}

flutter doctor
flutter create --platforms=android --org com.xautrader --project-name xau_trader .
flutter pub get
Write-Host ''
Write-Host 'Android project prepared. Next run:'
Write-Host '  flutter build apk --release --dart-define=API_BASE_URL=http://YOUR_SERVER:8000'
