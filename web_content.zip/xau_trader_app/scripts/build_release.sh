#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../mobile"

API_BASE_URL_VALUE="${API_BASE_URL:-http://10.0.2.2:8000}"

if [ ! -d android ]; then
  echo "Android project is missing. Run scripts/prepare_android.sh first."
  exit 1
fi

flutter pub get
flutter build apk --release --dart-define=API_BASE_URL="$API_BASE_URL_VALUE"

echo
echo "Release APK:"
echo "$(pwd)/build/app/outputs/flutter-apk/app-release.apk"
