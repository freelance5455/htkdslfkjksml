#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../mobile"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter is not installed or not on PATH. Install Flutter, then rerun this script."
  exit 1
fi

flutter doctor
flutter create --platforms=android --org com.xautrader --project-name xau_trader .
flutter pub get

echo
echo "Android project prepared. Next run:"
echo "  flutter build apk --release --dart-define=API_BASE_URL=http://YOUR_SERVER:8000"
