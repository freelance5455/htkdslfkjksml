$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..\mobile')

if (-not (Test-Path 'android')) {
  Write-Error 'Android project is missing. Run scripts/prepare_android.ps1 first.'
}

$api = if ($env:API_BASE_URL) { $env:API_BASE_URL } else { 'http://10.0.2.2:8000' }
flutter pub get
flutter build apk --release --dart-define=API_BASE_URL=$api
Write-Host ''
Write-Host "Release APK: $((Get-Location).Path)\build\app\outputs\flutter-apk\app-release.apk"
