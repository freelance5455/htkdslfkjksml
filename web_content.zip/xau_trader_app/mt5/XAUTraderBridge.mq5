#property strict
#property version "0.1"

input string ApiBaseUrl = "http://127.0.0.1:8000";
input string SymbolToTrade = "XAUUSD";
input int TimerSeconds = 2;

int OnInit(){ EventSetTimer(TimerSeconds); return(INIT_SUCCEEDED); }
void OnDeinit(const int reason){ EventKillTimer(); }
void OnTimer(){
   MqlTick t;
   if(!SymbolInfoTick(SymbolToTrade,t)) return;
   string payload=StringFormat("{\"bid\":%.5f,\"ask\":%.5f}",t.bid,t.ask);
   char data[], result[]; string headers="Content-Type: application/json\r\n"; string result_headers;
   StringToCharArray(payload,data,0,WHOLE_ARRAY,CP_UTF8);
   string url=ApiBaseUrl+"/api/market/tick";
   ResetLastError();
   int code=WebRequest("POST",url,headers,1500,data,result,result_headers);
   if(code==-1) Print("XAU Trader API error: ",GetLastError());
}
