# XAU Trader architecture

Mobile app is the command center; the backend owns authoritative risk state; MT5 is the first execution adapter. This follows the requested phone → server → MT5/broker architecture.

## Safety boundaries
1. Demo mode is default.
2. Mobile UI cannot bypass backend risk limits.
3. Kill switch disables new trading.
4. Close-all is separate from strategy logic.
5. Live execution should only be enabled after broker-specific testing.

## Production next steps
- Replace demo order route with authenticated MT5 command queue.
- Add JWT/OIDC authentication and 2FA.
- Store secrets in a server-side secret manager.
- Add PostgreSQL persistence and immutable audit logs.
- Add Redis/WebSocket streaming.
- Add economic calendar integration.
- Add broker adapter interface for cTrader/FIX/IBKR.
- Add tick replay backtester and realistic spread/slippage model.
- Add monitoring, alerts, health checks and deployment manifests.
