import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

void main() => runApp(const XauTraderApp());

class XauTraderApp extends StatelessWidget {
  const XauTraderApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false, title:'XAU Trader',
    theme: ThemeData.dark(useMaterial3:true), home: const Dashboard());
}

class Dashboard extends StatefulWidget { const Dashboard({super.key}); @override State<Dashboard> createState()=>_DashboardState(); }
class _DashboardState extends State<Dashboard> {
  Map<String,dynamic> s={}; Timer? timer; String msg='Connecting...';
  @override void initState(){super.initState(); refresh(); timer=Timer.periodic(const Duration(seconds:2),(_)=>refresh());}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> refresh() async { try { final r=await http.get(Uri.parse('$apiBaseUrl/api/state')); if(r.statusCode==200)setState(()=>s=jsonDecode(r.body)); } catch(e){setState(()=>msg='Backend offline');} }
  Future<void> post(String path) async { try { final r=await http.post(Uri.parse('$apiBaseUrl$path')); setState(()=>msg=r.statusCode<300?'Done':'${r.statusCode}: ${r.body}'); await refresh(); } catch(e){setState(()=>msg='Connection error');} }
  Widget card(String a,String b){return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Colors.white60)),const SizedBox(height:6),Text(b,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold))])));}
  @override Widget build(BuildContext c){ final running=s['bot_running']==true; final pnl=(s['daily_pnl']??0).toString(); return Scaffold(appBar:AppBar(title:const Text('XAU TRADER'),actions:[Padding(padding:const EdgeInsets.only(right:16),child:Center(child:Text(s['mode']??'DEMO')))]),body:RefreshIndicator(onRefresh:refresh,child:ListView(padding:const EdgeInsets.all(12),children:[
    Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[Text('XAU/USD',style:Theme.of(c).textTheme.titleLarge),const SizedBox(height:8),Text('${s['price']??'—'}',style:const TextStyle(fontSize:36,fontWeight:FontWeight.bold)),Text(running?'● BOT RUNNING':'● BOT PAUSED',style:TextStyle(color:running?Colors.green:Colors.orange))]))),
    GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,children:[card('Daily P&L','\$$pnl'),card('Position','${s['position']??0} oz'),card('Regime','${s['regime']??'—'}'),card('Spread','${s['spread']??'—'}')]),
    const SizedBox(height:8),card('Signal','${s['signal']??'FLAT'}  •  Confidence ${s['confidence']??0}%'),
    const SizedBox(height:12),Row(children:[Expanded(child:FilledButton(onPressed:()=>post('/api/bot/start'),child:const Text('START BOT'))),const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:()=>post('/api/bot/pause'),child:const Text('PAUSE')))]),
    const SizedBox(height:8),SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:Colors.red),onPressed:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('Close all?'),content:const Text('This sends the emergency flatten command.'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('CANCEL')),FilledButton(onPressed:(){Navigator.pop(c);post('/api/close-all');},child:const Text('CLOSE ALL'))])),child:const Text('CLOSE ALL'))),
    const SizedBox(height:8),SizedBox(width:double.infinity,child:OutlinedButton(onPressed:()=>post('/api/bot/kill'),child:const Text('KILL SWITCH'))),
    const SizedBox(height:12),Text(msg,style:const TextStyle(color:Colors.white54))
  ])); }
}
