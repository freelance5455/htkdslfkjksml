# Uza(esme)r Android app

This is a native Android WebView wrapper around the supplied Uza(esme)r HTML/CSS/JS page. The original page is kept as local app assets, so it does not need a website connection to display.

The wrapper also exposes a small Android bridge for the existing daily-message control. Tapping “Turn on daily message” schedules a native Android notification at the chosen local time. Android 13+ asks for notification permission the first time the app opens.

## Build

Open in Android Studio and build `app` -> `assembleDebug`, or run:

```bash
gradle assembleDebug
```

The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`; it builds the debug APK and uploads it as a workflow artifact.
