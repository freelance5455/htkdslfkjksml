package com.uzaesmer.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) { if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()) || "android.intent.action.LOCKED_BOOT_COMPLETED".equals(i.getAction())) DailyMessageReceiver.scheduleNext(c); }
}
