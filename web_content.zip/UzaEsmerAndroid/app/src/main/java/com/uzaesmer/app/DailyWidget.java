package com.uzaesmer.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.util.Calendar;

public class DailyWidget extends AppWidgetProvider {
    public static void update(Context c, AppWidgetManager manager, int[] ids) {
        String start = c.getSharedPreferences("counter", 0).getString("start", "2024-12-12");
        int[] parts = since(start, Calendar.getInstance());
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_daily);
            v.setTextViewText(R.id.widgetCounter, parts[0] + "y " + parts[1] + "m " + parts[2] + "d");
            v.setTextViewText(R.id.widgetDay, "Day " + parts[3]);
            Intent open = new Intent(c, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(c, 9001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            v.setOnClickPendingIntent(R.id.widgetTitle, pi);
            v.setOnClickPendingIntent(R.id.widgetCounter, pi);
            v.setOnClickPendingIntent(R.id.widgetDay, pi);
            manager.updateAppWidget(id, v);
        }
    }

    private static int[] since(String start, Calendar now) {
        String[] a = start.split("-");
        int sy = Integer.parseInt(a[0]), sm = Integer.parseInt(a[1]), sd = Integer.parseInt(a[2]);
        Calendar s = Calendar.getInstance();
        s.clear(); s.set(sy, sm - 1, sd);
        Calendar t = Calendar.getInstance();
        t.clear(); t.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
        long total = Math.max(0, Math.round((t.getTimeInMillis() - s.getTimeInMillis()) / 86400000.0));
        int y = now.get(Calendar.YEAR) - sy;
        int m = now.get(Calendar.MONTH) - (sm - 1);
        int d = now.get(Calendar.DAY_OF_MONTH) - sd;
        if (d < 0) { m--; Calendar prev = Calendar.getInstance(); prev.clear(); prev.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), 1); prev.add(Calendar.DAY_OF_MONTH, -1); d += prev.get(Calendar.DAY_OF_MONTH); }
        if (m < 0) { y--; m += 12; }
        if (total < 0) y = m = d = 0;
        return new int[]{y, m, d, (int)Math.min(Integer.MAX_VALUE, total)};
    }

    @Override public void onUpdate(Context c, AppWidgetManager manager, int[] ids) { update(c, manager, ids); }
    @Override public void onEnabled(Context c) { updateAll(c); }
    public static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, DailyWidget.class));
        if (ids.length > 0) update(c, m, ids);
    }
}
