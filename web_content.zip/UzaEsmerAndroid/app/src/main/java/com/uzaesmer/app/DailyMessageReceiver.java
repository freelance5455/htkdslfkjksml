package com.uzaesmer.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.util.*;

public class DailyMessageReceiver extends BroadcastReceiver {
    static final String CH="uza_daily";
    @Override public void onReceive(Context c, Intent i) {
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CH,"Daily together message",NotificationManager.IMPORTANCE_DEFAULT));
        String body="Good morning! Your Uza(esme)r counter is waiting for you. 🤍🌷🐧";
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Uza(esme)r 🤍🌷🐧").setContentText(body).setAutoCancel(true);
        if(Build.VERSION.SDK_INT<33 || c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==0) nm.notify(1001,b.build());
        scheduleNext(c);
        DailyWidget.updateAll(c);
    }
    static void schedule(Context c,int hour,int minute){
        c.getSharedPreferences("reminder",0).edit().putBoolean("enabled",true).putInt("hour",hour).putInt("minute",minute).apply(); scheduleNext(c);
    }
    static void scheduleNext(Context c){
        android.content.SharedPreferences p=c.getSharedPreferences("reminder",0); if(!p.getBoolean("enabled",false)) return;
        int h=p.getInt("hour",8),m=p.getInt("minute",0);
        Calendar at=Calendar.getInstance(); at.set(Calendar.HOUR_OF_DAY,h); at.set(Calendar.MINUTE,m); at.set(Calendar.SECOND,0); at.set(Calendar.MILLISECOND,0); if(at.getTimeInMillis()<=System.currentTimeMillis()) at.add(Calendar.DATE,1);
        PendingIntent pi=PendingIntent.getBroadcast(c,1001,new Intent(c,DailyMessageReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at.getTimeInMillis(),pi); else if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at.getTimeInMillis(),pi); else am.setExact(AlarmManager.RTC_WAKEUP,at.getTimeInMillis(),pi);
    }
}
