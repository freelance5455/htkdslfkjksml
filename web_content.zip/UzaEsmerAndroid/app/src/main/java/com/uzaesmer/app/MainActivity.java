package com.uzaesmer.app;

import android.Manifest;
import android.app.*;
import android.appwidget.AppWidgetManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.webkit.*;
import android.webkit.JavascriptInterface;
import android.view.View;

public class MainActivity extends Activity {
    static final int NOTIF_REQ = 42;
    static final int WIDGET_REQ = 43;
    WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ return false; } });
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public void scheduleDaily(int h,int m){ DailyMessageReceiver.schedule(MainActivity.this,h,m); }
            @JavascriptInterface public void saveStartDate(String date){ getSharedPreferences("counter",0).edit().putString("start",date).apply(); DailyWidget.updateAll(MainActivity.this); }
            @JavascriptInterface public void addWidget(){ requestWidget(); }
        }, "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
        else showFirstRunSetup();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == NOTIF_REQ) showFirstRunSetup();
    }

    private void showFirstRunSetup() {
        if (isFinishing()) return;
        final android.content.SharedPreferences p = getSharedPreferences("setup",0);
        if (p.getBoolean("shown", false)) return;
        new AlertDialog.Builder(this)
            .setTitle("Turn on your daily message 🤍")
            .setMessage("Allow notifications so Uza(esme)r can send the daily together message automatically. You can also add the counter widget to your home screen.")
            .setPositiveButton("Turn on", (d,w) -> {
                p.edit().putBoolean("shown", true).apply();
                DailyMessageReceiver.schedule(MainActivity.this, 8, 0);
                requestWidget();
            })
            .setNegativeButton("Not now", (d,w) -> p.edit().putBoolean("shown", true).apply())
            .show();
    }

    private void requestWidget() {
        if (Build.VERSION.SDK_INT >= 26) {
            AppWidgetManager manager = AppWidgetManager.getInstance(this);
            if (manager.isRequestPinAppWidgetSupported()) {
                ComponentName provider = new ComponentName(this, DailyWidget.class);
                PendingIntent callback = PendingIntent.getBroadcast(this, WIDGET_REQ, new Intent(this, DailyWidget.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                manager.requestPinAppWidget(provider, null, callback.getIntentSender());
            }
        }
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
