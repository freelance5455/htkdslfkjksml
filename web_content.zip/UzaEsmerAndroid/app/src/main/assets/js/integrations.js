// Webhook/REST-ready actions (Make.com etc.). No URL is stored in code; nothing is sent until one is set.
(function (U) {
  const KEY = 'uza.webhookUrl';
  const url = () => { try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; } };
  U.integrations = {
    setWebhookUrl(u) { try { localStorage.setItem(KEY, u); } catch (e) {} },
    buildEventPayload({ title, description = '', date = null, startTime = null, endTime = null, location = '', user = {} }) {
      return { title, description, date, startTime, endTime, location, user };
    },
    async sendToWebhook(payload) {
      const u = url();
      if (!u) return { skipped: true };
      const r = await fetch(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      return { ok: r.ok, status: r.status };
    }
  };
})(window.Uza = window.Uza || {});
