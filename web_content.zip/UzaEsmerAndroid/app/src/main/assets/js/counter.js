// Counts by local calendar date, so each phone is right in its own time zone.
(function (U) {
  const KEY = 'uza.start', DEFAULT = '2024-12-12';
  const store = {
    get() { try { return localStorage.getItem(KEY) || DEFAULT; } catch (e) { return DEFAULT; } },
    set(v) { try { localStorage.setItem(KEY, v); } catch (e) {} }
  };
  function since(startStr, now = new Date()) {
    const [sy, sm, sd] = startStr.split('-').map(Number);
    const s = new Date(sy, sm - 1, sd), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const t = { h: now.getHours(), min: now.getMinutes(), sec: now.getSeconds() };
    const total = Math.round((today - s) / 864e5);
    if (total < 0) return { y: 0, m: 0, d: 0, total: 0, ...t };
    let y = now.getFullYear() - sy, m = now.getMonth() - (sm - 1), d = now.getDate() - sd;
    if (d < 0) { m--; d += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
    if (m < 0) { y--; m += 12; }
    return { y, m, d, total, ...t };
  }
  U.counter = { store, since, DEFAULT };
})(window.Uza = window.Uza || {});
