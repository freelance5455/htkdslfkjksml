// Inside an Android wrapper (Capacitor LocalNotifications) this schedules 60 mornings ahead by itself.
// In a plain browser it can only notify while the page is open.
(function (U) {
  const KEY = 'uza.reminder';
  const native = () => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) || null;
  const android = () => window.AndroidBridge || null;
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } };
  const save = r => { try { localStorage.setItem(KEY, JSON.stringify(r)); } catch (e) {} };
  const message = s => ({
    title: 'Uza(esme)r 🤍🌷🐧',
    body: `Good morning! ${s.y}y ${s.m}m ${s.d}d together, day ${s.total}. Incoming event: fly to south pole.`
  });

  async function schedule(hh, mm) {
    save({ hh, mm });
    const ln = native(), ab = android();
    if (ab && !ln) { ab.scheduleDaily(hh, mm); return { ok: true, mode: 'app' }; }
    if (ln) {
      const p = await ln.requestPermissions();
      if (p.display !== 'granted') return { ok: false, mode: 'app', reason: 'denied' };
      const pending = await ln.getPending();
      if (pending.notifications.length) await ln.cancel({ notifications: pending.notifications });
      const now = new Date(), start = U.counter.store.get(), list = [];
      for (let i = 0; i < 60; i++) {
        const at = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i, hh, mm);
        if (at > now) list.push({ id: 1000 + i, ...message(U.counter.since(start, at)), schedule: { at, allowWhileIdle: true } });
      }
      await ln.schedule({ notifications: list });
      return { ok: true, mode: 'app' };
    }
    if (!('Notification' in window)) return { ok: false, mode: 'web', reason: 'unsupported' };
    const perm = await Notification.requestPermission();
    return { ok: perm === 'granted', mode: 'web', reason: perm === 'granted' ? '' : 'denied' };
  }

  function refresh() { const r = load(); if (r && native()) schedule(r.hh, r.mm).catch(() => {}); }

  function notifyIfDue() {
    const r = load();
    if (!r || native() || android() || !('Notification' in window) || Notification.permission !== 'granted') return;
    const now = new Date(), day = now.toDateString();
    if (r.last === day || now < new Date(now.getFullYear(), now.getMonth(), now.getDate(), r.hh, r.mm)) return;
    const m = message(U.counter.since(U.counter.store.get(), now));
    try { new Notification(m.title, { body: m.body }); r.last = day; save(r); } catch (e) {}
  }

  U.notifications = { schedule, refresh, notifyIfDue, load };
})(window.Uza = window.Uza || {});
