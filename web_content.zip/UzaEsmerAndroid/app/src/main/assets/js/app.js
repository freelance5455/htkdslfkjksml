(function (U) {
  const $ = id => document.getElementById(id), pad = n => String(n).padStart(2, '0');
  const say = t => { $('status').textContent = t; };
  const fmt = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d).toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' }); };

  function render() {
    const start = U.counter.store.get(), s = U.counter.since(start);
    $('since').textContent = fmt(start);
    $('y').textContent = s.y; $('m').textContent = s.m; $('d').textContent = s.d;
    $('clock').textContent = pad(s.h) + ':' + pad(s.min) + ':' + pad(s.sec);
    $('total').textContent = s.total.toLocaleString();
  }

  function init() {
    $('start').value = U.counter.store.get(); if (window.AndroidBridge) AndroidBridge.saveStartDate($('start').value);
    const r = U.notifications.load();
    if (r) $('time').value = pad(r.hh) + ':' + pad(r.mm);

    $('saveStart').addEventListener('click', () => {
      if (!$('start').value) return say('Pick a date first.');
      U.counter.store.set($('start').value); if (window.AndroidBridge) AndroidBridge.saveStartDate($('start').value); render(); U.notifications.refresh(); say('Date saved 🤍');
    });

    $('remind').addEventListener('click', async () => {
      const [hh, mm] = $('time').value.split(':').map(Number);
      if (isNaN(hh)) return say('Pick a time first.');
      const res = await U.notifications.schedule(hh, mm);
      if (!res.ok) return say(res.reason === 'denied' ? 'Notifications are blocked. Allow them in your phone settings, then tap again.' : 'This browser cannot show notifications.');
      say(res.mode === 'app' ? 'Done 🌷 A message arrives every morning at ' + $('time').value + ', your time.' : 'Allowed 🌷 In a browser the message shows only while this page is open. The Android app sends it on its own.');
      try {
        await U.integrations.sendToWebhook(U.integrations.buildEventPayload({
          title: 'Daily together message', description: 'Daily count of days together', startTime: $('time').value,
          user: { timezone: Intl.DateTimeFormat().resolvedOptions().timeZone }
        }));
      } catch (e) {}
    });

    render(); setInterval(render, 1000);
    U.notifications.notifyIfDue(); U.notifications.refresh();
    document.addEventListener('visibilitychange', () => { if (!document.hidden) U.notifications.notifyIfDue(); });
  }
  document.addEventListener('DOMContentLoaded', init);
})(window.Uza);
