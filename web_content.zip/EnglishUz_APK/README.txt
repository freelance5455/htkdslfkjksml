EnglishUz — Ingliz tilini o‘yin bilan o‘rgan
============================================

Bu papkani APK ga aylantirish yo‘llari:

1. ENG OSON (Online):
   - https://www.pwabuilder.com  yoki
   - https://www.webintoapp.com  yoki
   - https://go.natively.dev
   - www/index.html faylini yuklang va APK oling

2. Capacitor (tavsiya etiladi):
   npm create @capacitor/app
   www papkasini nusxalang
   npx cap add android
   npx cap sync
   Android Studio da ochib APK build qiling

3. Cordova:
   cordova create EnglishUz
   www/ ni almashtiring
   cordova platform add android
   cordova build android

Ilova to‘liq offline ishlaydi (localStorage + speechSynthesis).
