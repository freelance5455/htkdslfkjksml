/* Guia do Pioneiro · Service Worker offline-first
   Estratégia:
   - Instalação: guarda a app, o manifest e todos os ícones (precache).
   - Páginas: responde logo a partir da cache e atualiza em segundo plano.
   - Ícones, imagens e restantes ficheiros locais: cache primeiro.
   - Outros domínios (ex.: fontes externas): cache primeiro, rede como reserva.
   Ao publicar uma nova versão, mude VERSION para a app oferecer "Atualizar". */
const VERSION = 'gp-2.0.0';
const CORE = `${VERSION}-core`;
const RUNTIME = `${VERSION}-runtime`;

const PRECACHE = [
  './',
  './index.html',
  './Guia_do_Pioneiro_UNIFICADO.html',
  './manifest.json',
  './icons/favicon.svg',
  './icons/favicon-32.png',
  './icons/apple-touch-icon.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-192.png',
  './icons/icon-maskable-512.png',
  './icons/sc-activity.png',
  './icons/sc-calendar.png',
  './icons/sc-people.png',
  './icons/sc-reports.png'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CORE);
    // Um ficheiro em falta não impede a instalação dos restantes.
    await Promise.all(PRECACHE.map(async url => {
      try {
        const res = await fetch(new Request(url, { cache: 'reload' }));
        if (res.ok) await cache.put(url, res);
      } catch (_) { /* sem rede: fica para a próxima */ }
    }));
    // Na primeira instalação ativa sozinho; nas atualizações espera pelo botão "Atualizar".
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k.startsWith('gp-') && !k.startsWith(VERSION)).map(k => caches.delete(k)));
    if (self.registration.navigationPreload) {
      try { await self.registration.navigationPreload.enable(); } catch (_) {}
    }
    await self.clients.claim();
  })());
});

self.addEventListener('message', event => {
  const type = event.data && event.data.type;
  if (type === 'SKIP_WAITING') self.skipWaiting();
  if (type === 'GET_VERSION' && event.ports[0]) event.ports[0].postMessage(VERSION);
});

async function putSafe(cacheName, request, response) {
  if (!response || !(response.ok || response.type === 'opaque')) return;
  try { const c = await caches.open(cacheName); await c.put(request, response); } catch (_) {}
}

// Páginas: cache primeiro (arranque instantâneo e sem rede), atualização em segundo plano.
async function handleNavigation(event) {
  const req = event.request;
  const cached = (await caches.match(req, { ignoreSearch: true })) ||
                 (await caches.match('./index.html'));
  const network = (async () => {
    try {
      const res = (await event.preloadResponse) || (await fetch(req));
      if (res && res.ok) { const u = new URL(req.url); await putSafe(CORE, u.origin + u.pathname, res.clone()); }
      return res;
    } catch (_) { return null; }
  })();
  event.waitUntil(network);
  if (cached) return cached;
  const fresh = await network;
  if (fresh) return fresh;
  return new Response(
    '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sem ligação</title><body style="font-family:system-ui;padding:32px;background:#F6F5FB;color:#1E1B2E"><h1 style="font-size:20px">Sem ligação</h1><p>Abra a app uma vez com internet para que fique disponível offline.</p></body>',
    { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
  );
}

// Ficheiros locais: cache primeiro, rede como reserva (e guarda o que vier).
async function cacheFirst(req, cacheName) {
  const cached = await caches.match(req, { ignoreSearch: true });
  if (cached) return cached;
  try {
    const res = await fetch(req);
    await putSafe(cacheName, req, res.clone());
    return res;
  } catch (_) {
    return new Response('', { status: 504, statusText: 'Offline' });
  }
}

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (!/^https?:$/.test(url.protocol)) return;

  if (req.mode === 'navigate') {
    event.respondWith(handleNavigation(event));
    return;
  }
  if (url.origin === self.location.origin) {
    event.respondWith(cacheFirst(req, url.pathname.includes('/icons/') ? CORE : RUNTIME));
    return;
  }
  event.respondWith(cacheFirst(req, RUNTIME));
});
