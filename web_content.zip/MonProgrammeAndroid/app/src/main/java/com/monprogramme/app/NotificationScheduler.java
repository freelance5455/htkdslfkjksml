package com.monprogramme.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class NotificationScheduler {
    private static final String PREFS = "mon_programme_data";
    private static final String KEY_TASKS = "tasks_json";
    private static final String KEY_COMPLETED = "completed_json";
    private static final String KEY_REQUEST_CODES = "request_codes";

    public static void saveAndSchedule(
        Context context, String tasksJson, String completedJson
    ) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TASKS, tasksJson)
            .putString(KEY_COMPLETED, completedJson)
            .apply();

        scheduleAll(context, tasksJson);
    }

    public static void scheduleSaved(Context context) {
        String tasks = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TASKS, "[]");
        scheduleAll(context, tasks);
    }

    private static void cancelOldSchedules(Context context) {
        Set<String> codes = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_REQUEST_CODES, new HashSet<>());
        if (codes == null) return;

        AlarmManager manager =
            (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        for (String value : new ArrayList<>(codes)) {
            try {
                int code = Integer.parseInt(value);
                Intent intent = new Intent(context, TaskNotificationReceiver.class);
                PendingIntent pi = PendingIntent.getBroadcast(
                    context, code, intent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                );
                if (pi != null) {
                    manager.cancel(pi);
                    pi.cancel();
                }
            } catch (Exception ignored) { }
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_REQUEST_CODES, new HashSet<>()).apply();
    }

    private static void scheduleAll(Context context, String tasksJson) {
        cancelOldSchedules(context);

        try {
            JSONArray days = new JSONArray(tasksJson);
            Calendar now = Calendar.getInstance();

            // Java Calendar: lundi=0 ... dimanche=6
            int todayIndex = (now.get(Calendar.DAY_OF_WEEK) + 5) % 7;

            for (int day = 0; day < Math.min(days.length(), 7); day++) {
                JSONArray dayTasks = days.optJSONArray(day);
                if (dayTasks == null) continue;

                for (int i = 0; i < dayTasks.length(); i++) {
                    JSONObject task = dayTasks.optJSONObject(i);
                    if (task == null) continue;

                    String id = task.optString("id", "");
                    String time = task.optString("start", "");
                    String name = task.optString("name", "Activité");

                    if (id.isEmpty() || !time.matches("\\d{2}:\\d{2}")) continue;

                    String[] parts = time.split(":");
                    int hour = Integer.parseInt(parts[0]);
                    int minute = Integer.parseInt(parts[1]);

                    Calendar next = (Calendar) now.clone();
                    int offset = (day - todayIndex + 7) % 7;
                    next.add(Calendar.DAY_OF_YEAR, offset);
                    next.set(Calendar.HOUR_OF_DAY, hour);
                    next.set(Calendar.MINUTE, minute);
                    next.set(Calendar.SECOND, 0);
                    next.set(Calendar.MILLISECOND, 0);

                    if (!next.after(now)) next.add(Calendar.DAY_OF_YEAR, 7);

                    scheduleOne(context, id, day, time, name, next.getTimeInMillis());
                }
            }
        } catch (Exception ignored) { }
    }

    public static void scheduleNextWeek(
        Context context, String id, int day, String time,
        String name, long previousTime
    ) {
        Calendar next = Calendar.getInstance();
        next.setTimeInMillis(previousTime);
        next.add(Calendar.DAY_OF_YEAR, 7);
        scheduleOne(context, id, day, time, name, next.getTimeInMillis());
    }

    private static void scheduleOne(
        Context context, String id, int day, String time,
        String name, long triggerAt
    ) {
        try {
            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US)
                .format(new Date(triggerAt));
            int requestCode = (id + "_" + date).hashCode();

            Intent intent = new Intent(context, TaskNotificationReceiver.class);
            intent.putExtra("task_id", id);
            intent.putExtra("task_name", name);
            intent.putExtra("task_day", day);
            intent.putExtra("task_time", time);
            intent.putExtra("task_date", date);
            intent.putExtra("trigger_at", triggerAt);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            AlarmManager manager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent
                );
            } else {
                manager.set(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
            }

            Set<String> codes = new HashSet<>(
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getStringSet(KEY_REQUEST_CODES, new HashSet<>())
            );
            codes.add(String.valueOf(requestCode));

            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putStringSet(KEY_REQUEST_CODES, codes).apply();

        } catch (Exception ignored) { }
    }
}
