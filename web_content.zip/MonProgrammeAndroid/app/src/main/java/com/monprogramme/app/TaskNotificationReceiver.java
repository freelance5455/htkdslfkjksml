package com.monprogramme.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

public class TaskNotificationReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "programme_silent";
    private static final String PREFS = "mon_programme_data";

    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("task_id");
        String name = intent.getStringExtra("task_name");
        String date = intent.getStringExtra("task_date");
        String time = intent.getStringExtra("task_time");
        int day = intent.getIntExtra("task_day", 0);
        long triggerAt = intent.getLongExtra("trigger_at", System.currentTimeMillis());

        if (id == null || date == null) return;

        if (!isCompleted(context, date, id)) {
            showNotification(context, id, name == null ? "Activité prévue" : name, time);
        }

        // Reprogramme la même tâche pour la semaine suivante.
        NotificationScheduler.scheduleNextWeek(
            context, id, day, time == null ? "00:00" : time,
            name == null ? "Activité" : name, triggerAt
        );
    }

    private boolean isCompleted(Context context, String date, String id) {
        try {
            String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("completed_json", "{}");
            JSONObject all = new JSONObject(json);
            JSONArray done = all.optJSONArray(date);
            if (done == null) return false;
            for (int i = 0; i < done.length(); i++) {
                if (id.equals(done.optString(i))) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private void showNotification(Context context, String id, String name, String time) {
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int notificationId = (id + "_" + System.currentTimeMillis()).hashCode();

        PendingIntent contentIntent = PendingIntent.getActivity(
            context, notificationId, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(context, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(context);
            builder.setPriority(Notification.PRIORITY_DEFAULT);
            builder.setSound(null);
            builder.setVibrate(new long[]{0});
        }

        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Mon Programme")
            .setContentText((time == null ? "" : time + " — ") + name)
            .setStyle(new Notification.BigTextStyle()
                .bigText("C'est le moment de commencer : " + name))
            .setAutoCancel(true)
            .setContentIntent(contentIntent);

        // Notification silencieuse : aucune sonnerie ni vibration.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setSilent(true);
        }

        NotificationManager manager =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(notificationId, builder.build());
    }
}
