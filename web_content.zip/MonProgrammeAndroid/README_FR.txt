MON PROGRAMME — Projet Android source

Ce projet contient :
- Une interface HTML/CSS/JavaScript dans une WebView Android.
- Des notifications Android silencieuses au début de chaque activité.
- Une programmation hebdomadaire des notifications.
- Le report de chaque tâche à la semaine suivante.
- La restauration des notifications après redémarrage du téléphone.
- La sauvegarde des tâches et des cases cochées.

IMPORTANT
1. Les notifications n'ont ni sonnerie ni vibration.
2. Android utilise en interne AlarmManager pour déclencher une notification à l'heure prévue.
   Ce n'est pas une alarme sonore de réveil.
3. La méthode setAndAllowWhileIdle est inexacte : Android peut retarder certaines notifications
   pendant les périodes d'économie d'énergie. Une ponctualité garantie à la minute nécessite
   l'accès spécial Android « Alarmes et rappels » (non demandé par cette version).
4. Sur Android 13+, ouvrir l'application puis appuyer sur « AUTORISER LES NOTIFICATIONS ».
5. Après installation, autoriser les notifications dans les paramètres Android.
6. Pour une meilleure fiabilité, autoriser l'activité en arrière-plan et retirer l'application
   des restrictions de batterie si Android les applique.

CONSTRUCTION
Ouvrir ce dossier comme projet Gradle Android dans un environnement Android compatible
(Android Studio ou un service de compilation Android acceptant les projets Gradle).
Le fichier APK de sortie sera généré dans app/build/outputs/apk/debug/.

QuickEdit sert à modifier les fichiers, mais ne compile pas à lui seul le code Java Android.
Un simple convertisseur HTML-vers-APK ne peut pas intégrer les BroadcastReceiver natifs
nécessaires aux notifications lorsque l'application est fermée.
