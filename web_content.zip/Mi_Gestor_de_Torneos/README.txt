MI GESTOR DE TORNEOS 2.6
- Se agregó la configuración de grupos también en Editar torneo.
- Puedes indicar número de grupos y cantidades por grupo diferentes (ej. 4,4,3,3).
- Los participantes se redistribuyen siguiendo el orden actual de inscripción.
- Para quitar los grupos, indica 0.
- La suma de capacidades debe cubrir a todos los participantes.
- Se conservan los partidos finalizados; después de modificar grupos actualiza el calendario desde la ficha del torneo.
- Exporta un respaldo desde Datos antes de actualizar.
Aplicación HTML offline; no es APK nativo.
