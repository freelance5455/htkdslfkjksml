# FC Mobile Player Guide

This is an Android Studio project for an offline reference app.

## Build an APK
1. Install Android Studio on a computer and open this project folder.
2. Let Android Studio sync/download the Android Gradle plugin and SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. When the build completes, use the APK link shown by Android Studio (usually under `app/build/outputs/apk/debug/`).

## App contents
- Clearly labelled player attributes: Pace, Dribbling, Shooting, Passing, Defending, Physical, Foot & Skills.
- Position-specific stat priorities.
- Interactive player inspection checklist.
- Rank vs training vs OVR explanation.
- Works offline after installation.

## Notes
This project source is provided, not a prebuilt APK. The build environment used to prepare it did not have the Android SDK/Gradle installed, so an APK could not be compiled here.
