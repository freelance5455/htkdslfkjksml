const DEFAULT_SETTINGS = {
    name: "Агро Пользователь",
    avatar: "",
    background: ""
};

function getSettings() {

    const data =
        localStorage.getItem("apkAssistantSettings");

    if (!data)
        return {...DEFAULT_SETTINGS};

    try {
        return JSON.parse(data);
    } catch {
        return {...DEFAULT_SETTINGS};
    }
}

function saveSettings(settings) {

    localStorage.setItem(
        "apkAssistantSettings",
        JSON.stringify(settings)
    );

}

function applySettings() {

    const settings = getSettings();

    document
        .querySelectorAll("[data-name]")
        .forEach(el => {
            el.textContent = settings.name;
        });

    document
        .querySelectorAll("[data-avatar]")
        .forEach(el => {

            if (settings.avatar) {

                el.src = settings.avatar;

            } else {

                el.removeAttribute("src");

                el.alt =
                    settings.name
                    .charAt(0)
                    .toUpperCase();

            }

        });

    if (settings.background) {

        document.body.style.backgroundImage =
            `url("${settings.background}")`;

    } else {

        document.body.style.backgroundImage = "";

    }

}

document.addEventListener(
    "DOMContentLoaded",
    applySettings
);