# Color Kids Android App

This project wraps the Color Kids working HTML prototype in an Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on an Android phone.

Package: com.colorkids.app
Version: 1.0
