# MAFIA – THE DARK GAME (وضع المنظّم السري)
تطبيق HTML/CSS/JS يعمل دون إنترنت، وجاهز للتغليف بـ Capacitor.

## تجربة سريعة
افتح `www/index.html` في المتصفح.

## بناء APK (يتطلب Node.js 18+ و Android Studio)
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android`
5. في Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

بعد أي تعديل على `www/` نفّذ `npx cap sync android`.

## الملفات
- `www/js/game.js` منطق اللعبة كاملاً (الأدوار، الليل، التصويت، القناص، الحفظ والاستئناف)
- `www/css/style.css` التصميم (RTL)
- الأصوات مولّدة برمجياً، لا ملفات صوت.
