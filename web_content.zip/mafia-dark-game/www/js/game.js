'use strict';
/* MAFIA – THE DARK GAME : وضع المنظّم السري فقط، يعمل دون إنترنت */
const R={boss:['زعيم المافيا','👑',1],killer:['مافيا القتل','🔪',1],silencer:['مافيا التسكيت','🤐',1],doctor:['الطبيب','💉',0],detective:['المحقق','🕵️',0],sniper:['القناص','🎯',0],citizen:['مواطن','🙂',0]};
const SP=['boss','killer','silencer','doctor','detective','sniper'];
const isM=r=>R[r][2]===1;
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
let S=Object.assign({sound:1,music:1,self:1,reveal:0,timer:3,pw:''},ld('m_set',{}));
let G=ld('m_game',null);
const ui={s:'splash',names:[],cfg:null,tab:'alive',hideM:0,unlocked:0,t:0,run:0,iv:0};
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ss=()=>sv('m_set',S), save=()=>sv('m_game',G), P=id=>G.players[id];
const alive=()=>G.players.filter(p=>p.alive);
const has=r=>G.players.some(p=>p.alive&&p.role===r);
const log=t=>{G.log.push({r:G.round,t});save()};
const cur=()=>G.rv!=null?'reveal':G.phase==='idle'?'panel':G.phase;
const rnd=n=>{const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]%n};
/* ---------- الصوت (مولّد برمجياً) ---------- */
let AC,drone;
const ctx=()=>{AC=AC||new (window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();return AC};
function tone(f,d,ty,at){const c=ctx(),o=c.createOscillator(),g=c.createGain(),t=c.currentTime+at;o.type=ty||'sine';o.frequency.value=f;g.gain.setValueAtTime(.2,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+d)}
const SF={click:[[700,.05]],reveal:[[392,.15],[523,.15],[659,.3]],night:[[220,.6],[165,.9]],day:[[440,.3],[554,.5]],wake:[[330,.2],[392,.3]],death:[[110,.9,'sawtooth']],vote:[[520,.15]],win:[[523,.2],[659,.2],[784,.6]],lose:[[200,.6],[150,.9]]};
function sfx(k){if(!S.sound)return;try{let a=0;(SF[k]||[]).forEach(n=>{tone(n[0],n[1],n[2],a);a+=n[1]*.7})}catch(e){}}
function music(){try{if(drone){drone.forEach(o=>o.stop());drone=0}if(!S.music)return;const c=ctx(),g=c.createGain();g.gain.value=.04;g.connect(c.destination);drone=[55,82.5,110].map(f=>{const o=c.createOscillator();o.frequency.value=f;o.connect(g);o.start();return o})}catch(e){}}
/* ---------- توزيع الأدوار ---------- */
function auto(n){const m=Math.max(1,Math.floor((n-1)/3)),c={boss:0,killer:0,silencer:0,doctor:n>=4?1:0,detective:n>=6?1:0,sniper:n>=8?1:0};
 if(m===1)c.killer=1;else if(m===2){c.killer=1;c.silencer=1}else{c.boss=1;c.killer=m-2;c.silencer=1}return c}
function chk(c,n){const sp=SP.reduce((a,k)=>a+c[k],0),m=c.boss+c.killer+c.silencer;
 if(n<4)return'أقل عدد للاعبين هو 4';if(sp>n)return'عدد الأدوار أكبر من عدد اللاعبين';
 if(m<1)return'يجب وجود لاعب مافيا واحد على الأقل';if(m*2>=n)return'المافيا كثيرة: ستفوز منذ البداية';return''}
function stp(k,d){const n=ui.names.length,mx=['boss','doctor','detective','sniper'].includes(k)?1:n;ui.cfg[k]=Math.min(mx,Math.max(0,ui.cfg[k]+d));render()}
function startGame(){const n=ui.names.length,c=ui.cfg;if(chk(c,n))return;
 const rs=[];SP.forEach(k=>{for(let i=0;i<c[k];i++)rs.push(k)});while(rs.length<n)rs.push('citizen');
 for(let i=n-1;i>0;i--){const j=rnd(i+1);[rs[i],rs[j]]=[rs[j],rs[i]]}
 G={players:ui.names.map((name,i)=>({id:i,name,role:rs[i],alive:1,silenced:0,death:''})),round:0,phase:'idle',log:[],used:0,win:null,last:null,n:null,v:null};
 log('بداية المباراة ('+n+' لاعبين)');G.players.forEach(p=>log('الدور: '+p.name+' = '+R[p.role][0]));G.rv=0;ui.show=0;ui.unlocked=1;ui.tab='alive';save();go('reveal')}
/* ---------- الليل ---------- */
const STP={boss:['زعيم المافيا يستيقظ',[['kill','🔪 ضحية القتل'],['silence','🤐 هدف التسكيت']]],killer:['مافيا القتل تستيقظ',[['kill','🔪 ضحية القتل']]],silencer:['مافيا التسكيت تستيقظ',[['silence','🤐 هدف التسكيت']]],doctor:['الطبيب يستيقظ',[['heal','💉 الشخص المراد علاجه']]],detective:['المحقق يستيقظ',[['inv','🔎 الشخص المراد التحقيق معه']]]};
function startNight(){G.round++;G.phase='night';const st=[];
 if(has('boss'))st.push('boss');else{if(has('killer'))st.push('killer');if(has('silencer'))st.push('silencer')}
 ['doctor','detective'].forEach(r=>has(r)&&st.push(r));if(has('sniper')&&!G.used)st.push('sniper');
 G.n={steps:st,i:-1,pick:{}};log('بداية الليل '+G.round);sfx('night');go('night')}
const ok=k=>k==='sniper'?(!G.used&&has('sniper')):has(k);
function nx(){const n=G.n;const k0=n.steps[n.i];if(k0==='detective'&&n.pick.inv!=null){}
 n.i++;while(n.i<n.steps.length&&!ok(n.steps[n.i]))n.i++;
 if(n.i>=n.steps.length)return resolve();sfx('wake');save();render()}
function pk(key,id){G.n.pick[key]=G.n.pick[key]===id?null:id;save();render()}
function resolve(){const q=G.n.pick,k=q.kill,s=q.silence,h=q.heal;G.players.forEach(p=>p.silenced=0);
 if(k!=null)log('المافيا اختارت للقتل: '+P(k).name);if(s!=null)log('اختيار التسكيت: '+P(s).name);if(h!=null)log('الطبيب عالج: '+P(h).name);
 if(q.inv!=null)log('المحقق حقق مع '+P(q.inv).name+': '+(isM(P(q.inv).role)?'مافيا':'ليس مافيا'));
 const L={dead:[],sil:null,saved:0};
 if(k!=null){if(h===k){L.saved=1;log('نجا '+P(k).name+' بفضل الطبيب')}else if(P(k).alive){die(k,'قتل المافيا');L.dead.push(k)}}
 if(s!=null&&P(s).alive){if(h===s)log('عولج '+P(s).name+' من التسكيت');else{P(s).silenced=1;L.sil=s}}
 G.last=L;G.phase='day';G.n=null;rt();sfx('day');save();if(!ck())go('day')}
function die(id,cause){const p=P(id);p.alive=0;p.silenced=0;p.death=cause;log(p.name+' ('+R[p.role][0]+') مات: '+cause);if(p.role==='boss')log('مات زعيم المافيا: انتقلت الصلاحيات إلى مافيا القتل والتسكيت');sfx('death')}
function ck(){const a=alive(),m=a.filter(p=>isM(p.role)).length,o=a.length-m;let w=0;if(!m)w='citizens';else if(m>=o)w='mafia';if(!w)return 0;
 G.phase='end';G.win=w;log('نهاية المباراة: فوز '+(w==='mafia'?'المافيا':'المواطنين'));sfx(w==='mafia'?'lose':'win');save();go('end');return 1}
/* ---------- القناص ---------- */
function shoot(id){const sn=G.players.find(p=>p.alive&&p.role==='sniper');if(!sn||G.used)return;
 if(!confirm('تأكيد: إطلاق الطلقة الوحيدة على '+P(id).name+'؟ لا يمكن التراجع.'))return;
 G.used=1;const t=P(id);log('طلقة القناص ('+sn.name+') على '+t.name+' ('+R[t.role][0]+')');
 if(isM(t.role)){die(id,'طلقة القناص');sn.role='citizen';log('القناص فقد دوره وأصبح مواطناً عادياً')}
 else{die(id,'طلقة القناص (مواطن)');die(sn.id,'مات القناص بعد قتله مواطناً')}
 if(G.phase==='night')nx();else if(!ck())go(cur())}
const snl=()=>'<div class=mu>طلقة واحدة فقط طوال المباراة</div><div class=chips>'+alive().filter(p=>p.role!=='sniper').map(p=>`<button onclick="shoot(${p.id})">🎯 ${esc(p.name)}</button>`).join('')+'</div>';
/* ---------- النهار والمؤقت ---------- */
const fmt=()=>String(ui.t/60|0).padStart(2,'0')+':'+String(ui.t%60).padStart(2,'0');
function rt(){clearInterval(ui.iv);ui.run=0;ui.t=S.timer*60}
const upd=()=>{const e=$('tm');if(e)e.textContent=fmt()};
function tm(){ui.run=!ui.run;clearInterval(ui.iv);if(ui.run)ui.iv=setInterval(()=>{ui.t--;if(ui.t<=0){ui.t=0;ui.run=0;clearInterval(ui.iv);sfx('lose');render()}upd()},1000);render()}
function adj(d){ui.t=Math.max(0,ui.t+d*60);render()}
/* ---------- التصويت ---------- */
function toVote(){clearInterval(ui.iv);ui.run=0;G.phase='vote';G.v={c:null,votes:{},res:null};log('بداية التصويت');sfx('vote');save();go('vote')}
function sv2(v,x){G.v.votes[v]=x===''?null:+x;save()}
function tally(){const v=G.v,cs=v.c||alive().map(p=>p.id),m={};cs.forEach(i=>m[i]=0);Object.values(v.votes).forEach(x=>{if(x!=null&&m[x]!=null)m[x]++});
 v.res=cs.map(i=>[i,m[i]]).sort((a,b)=>b[1]-a[1]);log('نتيجة التصويت: '+v.res.map(x=>P(x[0]).name+'='+x[1]).join('، '));save();render()}
function rev(){const t=G.v.res[0][1];G.v={c:G.v.res.filter(x=>x[1]===t).map(x=>x[0]),votes:{},res:null};log('تصويت إضافي بسبب التعادل');save();render()}
function elim(id){die(id,'إخراج بالتصويت');endVote()}
function endVote(){if(G.v&&G.v.res&&G.phase==='vote'&&!arguments[0]&&false){}G.phase='idle';G.v=null;save();if(!ck())go('panel')}
/* ---------- واجهات ---------- */
const B=(t,f,c)=>`<button class="b ${c||''}" onclick="${f}">${t}</button>`;
const hdr0=t=>`<div class=top><b>${t}</b></div>`;
const hdr=t=>`<div class=top><b>${t}</b><span><button class=ic onclick="go('panel')">📋</button><button class=ic onclick="cover(1)">🙈</button></span></div>`;
const lab=p=>ui.hideM&&isM(p.role)?'••••':R[p.role][1]+' '+R[p.role][0];
const nmx=p=>ui.hideM&&isM(p.role)?'••••':esc(p.name);
const SC={};
SC.splash=()=>`<div style="margin-top:18vh"><div class=logo>MAFIA</div><div class=sub>THE DARK GAME</div><div style="text-align:center;font-size:64px;margin:20px">🎩</div>${B('ادخل','go(\'menu\')','r')}</div>`;
SC.menu=()=>`<div class=logo style="margin-top:8vh;font-size:44px">MAFIA</div><div class=sub>THE DARK GAME</div><div style="margin-top:30px">${B('🎭 مباراة جديدة',"newGame()",'r')}${G&&G.phase!=='end'?B('▶️ استئناف المباراة','resume0()','g'):''}${B('⚙️ الإعدادات',"go('settings')")}</div>`;
SC.setup=()=>`${hdr0('إضافة اللاعبين ('+ui.names.length+')')}<div style="display:flex;gap:6px"><input id=nm placeholder="اسم اللاعب" onkeydown="if(event.key==='Enter')addN()"><button class=g style="width:80px" onclick="addN()">＋</button></div><div class=card>${ui.names.map((n,i)=>`<div class=row><span>${i+1}. ${esc(n)}</span><button class=ic onclick="rmN(${i})">✕</button></div>`).join('')||'<span class=mu>أضف 4 لاعبين على الأقل</span>'}</div><button class="b r" ${ui.names.length<4?'disabled':''} onclick="nextR()">التالي: إعداد الأدوار</button>${B('رجوع',"go('menu')")}`;
SC.roles=()=>{const n=ui.names.length,c=ui.cfg,e=chk(c,n),sp=SP.reduce((a,k)=>a+c[k],0),m=c.boss+c.killer+c.silencer;
 return `${hdr0('إعداد الأدوار وإعاينة التوزيع')}<div class=mu>${n} لاعبين</div><div class=card>${SP.map(k=>`<div class=row><span>${R[k][1]} ${R[k][0]}</span><span><button class=ic onclick="stp('${k}',-1)">−</button> <b>${c[k]}</b> <button class=ic onclick="stp('${k}',1)">＋</button></span></div>`).join('')}<div class=row><span>🙂 مواطنون (تلقائي)</span><b>${Math.max(0,n-sp)}</b></div></div>${e?`<div class=card style="border-color:var(--red)">⚠️ ${e}</div>`:`<div class=card>✅ توزيع متوازن: المافيا ${m} مقابل ${n-m}. سيتم توزيعها عشوائياً عند البدء.</div>`}<button class=b onclick="ui.cfg=auto(${n});render()">⚙️ توزيع تلقائي</button><button class="b g" ${e?'disabled':''} onclick="startGame()">START GAME</button>${B('رجوع',"go('setup')")}`};
SC.panel=()=>{if(!G)return SC.menu();const tab=ui.tab,al=G.players.filter(p=>p.alive),de=G.players.filter(p=>!p.alive);
 let h=hdr0('🕶️ لوحة المنظّم السرية — الجولة '+G.round)+`<div class=tabs>${[['alive','الأحياء '+al.length],['dead','المتوفون '+de.length],['log','السجل']].map(([k,l])=>`<button class="${tab===k?'on':''}" onclick="ui.tab='${k}';render()">${l}</button>`).join('')}</div><div class=card>`;
 if(tab==='alive')h+=al.map(p=>`<div class=row><span>${nmx(p)}${p.silenced?' 🤐':''}</span><span class=mu>${lab(p)}</span></div>`).join('');
 else if(tab==='dead')h+=de.map(p=>`<div class=row><span>${esc(p.name)}</span><span class=mu>${lab(p)} · ${esc(p.death)}</span></div>`).join('')||'<span class=mu>لا أحد</span>';
 else h+=G.log.slice().reverse().map(e=>`<div class=row><span class=mu>ج${e.r}</span><span style="flex:1;margin:0 8px">${esc(e.t)}</span></div>`).join('');
 h+='</div>';
 h+=G.phase==='idle'?B('🌙 بدء الليل','startNight()','r'):B('متابعة المباراة','go(G.phase)','r');
 if(!G.used&&G.phase!=='night'&&G.phase!=='end'&&has('sniper'))h+=B('🎯 القناص',"go('sniper')");
 return h+`<button class=b onclick="ui.hideM=!ui.hideM;render()">${ui.hideM?'👁 إظهار':'🙈 إخفاء'} المافيا</button>`+`<button class=b onclick="cover(1)">⬛ شاشة سوداء</button>`+B('☰ القائمة',"go('menu')")};
const tg=(key)=>alive().filter(p=>!(key==='heal'&&!S.self&&p.role==='doctor')&&!(key==='inv'&&p.role==='detective')).map(p=>`<button class="${G.n.pick[key]===p.id?'sel':''}" onclick="pk('${key}',${p.id})">${esc(p.name)}</button>`).join('');
SC.night=()=>{const n=G.n;
 if(n.i<0)return `<div class=big>THE NIGHT HAS BEGUN</div><div style="text-align:center;font-size:70px">🌙</div>${B('ابدأ الليل','nx()','r')}${B('📋 اللوحة',"go('panel')")}`;
 const k=n.steps[n.i];if(k==='sniper')return hdr('القناص يستيقظ')+snl()+B('تخطي (دون إطلاق)','nx()');
 const [t,ps]=STP[k];let h=hdr(t);ps.forEach(([key,l])=>{h+=`<div class=mu>${l}</div><div class=chips>${tg(key)}</div>`});
 if(k==='detective'&&n.pick.inv!=null)h+=`<div class=card>النتيجة (سرية): <b style="color:var(--gold)">${isM(P(n.pick.inv).role)?'مافيا':'ليس مافيا'}</b></div>`;
 return h+B('التالي ← نام','nx()','r')};
SC.day=()=>{const L=G.last,d=L.dead.map(i=>P(i)),an=d.length?'مات هذه الليلة: '+d.map(p=>p.name+(S.reveal?' ('+R[p.role][0]+')':'')).join('، '):'مرّت الليلة بسلام';
 return `<div class=big style="margin:14px 0">THE DAY HAS BEGUN</div>${hdr('اليوم '+G.round)}<div class=card>📢 ${esc(an)}</div>${L.saved?'<div class=card>💉 الطبيب أنقذ ضحية الليلة (سري)</div>':''}${L.sil!=null&&P(L.sil).alive?`<div class=card>🤐 المسكّت (سري): <b>${esc(P(L.sil).name)}</b><div class=mu>لا يتكلم اليوم ويستطيع التصويت. يمكنك الإعلان عن وجود مسكّت دون ذكر اسمه.</div></div>`:''}<div class=card style="text-align:center"><div id=tm style="font-size:44px;direction:ltr">${fmt()}</div><button class=ic onclick="adj(-1)">−1د</button><button class=ic onclick="tm()">${ui.run?'⏸':'▶️'}</button><button class=ic onclick="adj(1)">+1د</button></div>${!G.used&&has('sniper')?B('🎯 القناص',"go('sniper')"):''}${B('إنهاء النقاش ← التصويت','toVote()','r')}`};
SC.sniper=()=>hdr('🎯 القناص')+snl()+B('رجوع',"go(cur())");
SC.vote=()=>{const v=G.v,al=alive(),cs=v.c?v.c.map(i=>P(i)):al;
 let h=hdr('التصويت')+(v.c?'<div class=mu>تصويت إضافي بين المتعادلين فقط</div>':'');
 h+='<div class=card>'+al.map(p=>`<div class=row><span>${esc(p.name)}${p.silenced?' 🤐':''}</span><select style="width:55%" onchange="sv2(${p.id},this.value)"><option value="">امتناع</option>${cs.map(c=>`<option value="${c.id}" ${v.votes[p.id]===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select></div>`).join('')+'</div>'+B('احسب الأصوات','tally()','g');
 if(v.res){const rk=v.res,t=rk[0],tie=rk.filter(x=>x[1]===t[1]);
  h+='<div class=card><b>الترتيب</b>'+rk.map(x=>`<div class=row><span>${esc(P(x[0]).name)}</span><b>${x[1]}</b></div>`).join('')+'</div>';
  if(t[1]>0&&tie.length===1)h+=B('إخراج '+esc(P(t[0]).name)+' ('+R[P(t[0]).role][0]+')','elim('+t[0]+')','r');
  else h+=`<div class=card>⚖️ ${t[1]?'تعادل':'لا توجد أصوات'}</div>`+(t[1]?B('تصويت إضافي بين المتعادلين','rev()','g'):'');
  h+=B('عدم إخراج أي لاعب','endVote()')}
 return h};
SC.end=()=>`<div class=big>${G.win==='mafia'?'🔪 فازت المافيا':'🎉 فاز المواطنون'}</div><div class=card>${G.players.map(p=>`<div class=row><span>${esc(p.name)}${p.alive?'':' ☠️'}</span><span class=mu>${R[p.role][1]} ${R[p.role][0]}</span></div>`).join('')}</div><button class=b onclick="ui.tab='log';go('panel')">📜 سجل الأحداث</button>${B('مباراة جديدة','newG()','r')}`;
SC.lock=()=>hdr0('🔒 كلمة المرور')+'<input id=pw type=password>'+B('دخول','unlock()','r')+B('رجوع',"go('menu')");
SC.settings=()=>{const t=(k,l)=>`<div class=row><span>${l}</span><button class=ic onclick="tgl('${k}')">${S[k]?'✅':'⬜'}</button></div>`;
 return hdr0('الإعدادات')+'<div class=card>'+t('sound','المؤثرات الصوتية')+t('music','الموسيقى')+t('self','الطبيب يعالج نفسه')+t('reveal','كشف دور من يموت')+`<div class=row><span>مدة النقاش (دقائق)</span><input type=number min=1 max=30 style="width:80px" value="${S.timer}" onchange="S.timer=Math.max(1,+this.value||3);ss()"></div><div class=row><span>كلمة مرور (اختياري)</span><input type=password style="width:50%" value="${esc(S.pw)}" onchange="S.pw=this.value;ss()"></div></div>`+B('رجوع',"go('menu')")};
/* ---------- تنقل ---------- */
function render(){$('app').innerHTML=SC[ui.s]()+'<div class=ft>تم التطوير بواسطة ابراهيم خليل</div>'}
function go(s){ui.s=s;render();window.scrollTo(0,0)}
function cover(v){$('cv').style.display=v?'flex':'none'}
function tgl(k){S[k]=S[k]?0:1;ss();if(k==='music')music();render()}
function newGame(){if(G&&G.phase!=='end'&&!confirm('سيتم حذف المباراة المحفوظة. متابعة؟'))return;newG(1)}
function newG(x){G=null;localStorage.removeItem('m_game');ui.names=[];ui.cfg=null;go('setup')}
function resume0(){if(S.pw&&!ui.unlocked)go('lock');else go(cur())}
function unlock(){if($('pw').value===S.pw){ui.unlocked=1;go(cur())}else{alert('كلمة المرور خاطئة')}}
function addN(){const e=$('nm'),v=e.value.trim();if(!v)return;if(ui.names.includes(v)){alert('الاسم مكرر');return}if(ui.names.length>=30){alert('الحد الأقصى 30');return}ui.names.push(v);render();$('nm').focus()}
function rmN(i){ui.names.splice(i,1);render()}
function nextR(){ui.cfg=auto(ui.names.length);go('roles')}
const DESC={boss:'قائد المافيا: تختار ضحية القتل وهدف التسكيت كل ليلة.',killer:'مافيا القتل: تنتظر قرار الزعيم، وإذا مات تختار الضحية بنفسك.',silencer:'مافيا التسكيت: تنتظر قرار الزعيم، وإذا مات تختار من تُسكّته.',doctor:'من فريق المواطنين: تعالج كل ليلة شخصاً تظنه هدف المافيا.',detective:'من فريق المواطنين: تحقق كل ليلة مع لاعب لتعرف هل هو مافيا.',sniper:'من فريق المواطنين: لديك طلقة واحدة طوال المباراة. إن أصبت مواطناً متّ معه.',citizen:'مواطن: ناقش وصوّت لكشف المافيا.'};
SC.reveal=()=>{const p=G.players[G.rv];if(!p)return SC.panel();
 if(!ui.show)return `<div class=big>${G.rv+1} / ${G.players.length}</div><div class=card style="text-align:center"><div class=mu>سلّم الهاتف إلى</div><div style="font-size:32px;margin:10px;color:var(--gold)">${esc(p.name)}</div></div>${B('أنا '+esc(p.name)+'، اكشف دوري','showR()','r')}`;
 const mates=isM(p.role)?G.players.filter(q=>q.id!==p.id&&isM(q.role)):[];
 return `<div class=card style="text-align:center"><div style="font-size:70px">${R[p.role][1]}</div><div style="font-size:28px;color:var(--gold)">${R[p.role][0]}</div><p class=mu>${DESC[p.role]}</p>${mates.length?'<div>فريقك: '+mates.map(q=>esc(q.name)+' ('+R[q.role][0]+')').join('، ')+'</div>':''}</div>${B('التالي (إخفاء الدور)','nextP()','g')}`};
function showR(){ui.show=1;sfx('reveal');render()}
function nextP(){ui.show=0;G.rv++;if(G.rv>=G.players.length){delete G.rv;save();sfx('night');go('panel')}else{save();sfx('wake');render()}}
let mu0=0;document.addEventListener('click',e=>{if(!mu0){mu0=1;music()}if(e.target.closest('button'))sfx('click')});
rt();render();setTimeout(()=>{if(ui.s==='splash')go('menu')},2200);
