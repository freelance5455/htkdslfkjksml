MASTERSOFT CLOUD - ANDROID WEBVIEW PROJECT

This project wraps the supplied MasterSoft Cloud HTML file in a native Android WebView app.
The original HTML is kept at app/src/main/assets/index.html. JavaScript, DOM storage,
IndexedDB, and image/file selection are enabled for the features used by the page.

IMPORTANT
An APK has NOT been compiled in this environment because the Android SDK, Android build-tools,
and Gradle are not installed, and external downloads are unavailable. This ZIP is an Android
Studio project source, not an installable APK.

BUILD APK
1. Install Android Studio on a computer.
2. Open this folder (MasterSoftAndroid) in Android Studio.
3. Let Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location, usually app/build/outputs/apk/debug/app-debug.apk.
6. For sharing outside your own device, create a signed APK using Build > Generate Signed Bundle / APK.

APP DETAILS
Application ID: com.mastersoft.cloud
App name: MasterSoft Cloud
Minimum Android: 6.0 (API 23)

NOTE ON WEB FEATURES
The supplied page uses browser storage (localStorage and IndexedDB), image selection, and a
browser Blob-based export flow. Storage and image selection are enabled in the wrapper. Blob
file downloads/sharing may behave differently in Android WebView than in Chrome and should be
tested on the target device.
