#!/bin/bash
# Free Fire Tweaks NR 8.0
# Todos com 2>/dev/null || true

echo "Aplicando Free Fire Tweaks NR..."

settings put global activity_manager_constants max_cached_processes=32 2>/dev/null || true
settings put system min_refresh_rate 60 2>/dev/null || true
settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system user_refresh_rate 120 2>/dev/null || true
settings delete system thermal_limit_refresh_rate 2>/dev/null || true
settings put secure multi_press_timeout 130 2>/dev/null || true
settings put secure long_press_timeout 130 2>/dev/null || true
cmd thermalservice override-status 0 2>/dev/null || true
cmd power set-fixed-performance-mode-enabled true 2>/dev/null || true
device_config put game_overlay com.dts.freefiremax mode=2,downscaleFactor=0.7,fps=120:mode=3,downscaleFactor=0.7,fps=120 2>/dev/null || true
device_config put game_overlay com.dts.freefireth mode=2,downscaleFactor=0.7,fps=120:mode=3,downscaleFactor=0.7,fps=120 2>/dev/null || true
cmd game mode performance com.dts.freefiremax 2>/dev/null || true
cmd game mode performance com.dts.freefireth 2>/dev/null || true
cmd package compile -m quicken -f com.dts.freefireth 2>/dev/null || true
cmd package compile -m quicken -f com.dts.freefiremax 2>/dev/null || true

echo "Free Fire Tweaks NR aplicado!"
