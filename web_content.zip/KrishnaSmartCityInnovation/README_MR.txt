Krishna Smart City Innovation - Android project

महत्त्वाचे:
- हा Android Studio project आहे; compiled APK नाही.
- मूळ HTML portal assets/index.html मध्ये ठेवले आहे.
- App इंटरनेट वापरू शकतो. HTML मधील Google Fonts आणि Leaflet map सारख्या बाह्य गोष्टींसाठी इंटरनेट आवश्यक आहे.
- Android Studio मध्ये हा folder उघडा.
- आवश्यक Android SDK (API 35) install करा.
- Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
- APK साधारण app/build/outputs/apk/debug/app-debug.apk येथे तयार होईल.

App ID: com.krishnasmartcity.innovation
App name: Krishna Smart City Innovation
Minimum Android: Android 6.0 (API 23)
