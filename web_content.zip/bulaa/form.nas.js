
function getInputValue(id)
{
    var datax = document.getElementById(id)
    //Assume form with id="theform"
    var number = 0;
    //If the textbox is not blank
    if(datax.value != "")
    {
        number = parseFloat(datax.value);
    }
    return number;

}


function calcPosSize()
{
  // Inputs Capture & Variable declaration 
  var funds = getInputValue('funds');
  var ratio = getInputValue('ratio');
  var risk  = getInputValue('risk');
  var pos   = getInputValue('pos');
  var pips  = getInputValue('pips');
  var entry = getInputValue('entry');
  
  
   // Formulation of Stats Data
  var Lot =  (funds * risk * 0.01)/(pips*10);
  var poslot = Lot / pos;
  var sellsl = entry + (pips);
  var buytp  = entry + (pips * ratio);
  var selltp = entry - (pips * ratio);
  var buysl  = entry - (pips);
  var loss   = risk * 0.01 * funds;
  var returns = loss * ratio;


  // Display Of Calculation results
  document.getElementById('Lot').value = Lot.toFixed(2);
  
  document.getElementById('poslot').value = poslot.toFixed(2);
  
  document.getElementById('buytp').value = buytp.toFixed(2);
  
  document.getElementById('selltp').value = selltp.toFixed(2);
  
  document.getElementById('buysl').value = buysl.toFixed(2);
  
  document.getElementById('sellsl').value = sellsl.toFixed(2);

    document.getElementById('loss').value = loss.toFixed(2);
  
  document.getElementById('returns').value = returns.toFixed(2);
  
}
  