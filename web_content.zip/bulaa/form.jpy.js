
function getInputValue(id)
{
    var datax = document.getElementById(id)
    //Assume form with id="theform"
    var number = 0;
    //If the textbox is not blank
    if(datax.value != "")
    {
        number = parseFloat(datax.value);
    }
    return number;

}


function calcPosSize()
{
  // Inputs Capture & Variable declaration 
  var funds = getInputValue('funds');
  var ratio = getInputValue('ratio');
  var risk  = getInputValue('risk');
  var pos   = getInputValue('pos');
  var pips  = getInputValue('pips');
  var entry = getInputValue('entry');
  
  
   // Formulation of Stats Data
  var Lot =  ((funds * risk * 0.01)/pips)*0.1;
  var poslot = Lot / pos;
  var sellsl = entry + (pips * 0.01);
  var buytp  = entry + (pips * ratio * 0.01);
  var selltp = entry - (pips * ratio * 0.01);
  var buysl  = entry - (pips * 0.01);
  var loss   = risk * 0.01 * funds;
  var returns = loss * ratio;


  // Display Of Calculation results
  document.getElementById('Lot').value = Lot.toFixed(2);
  
  document.getElementById('poslot').value = poslot.toFixed(2);
  
  document.getElementById('buytp').value = buytp.toFixed(3);
  
  document.getElementById('selltp').value = selltp.toFixed(3);
  
  document.getElementById('buysl').value = buysl.toFixed(3);
  
  document.getElementById('sellsl').value = sellsl.toFixed(3);

    document.getElementById('loss').value = loss.toFixed(2);
  
  document.getElementById('returns').value = returns.toFixed(2);
  
}
  