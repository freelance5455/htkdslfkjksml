# TradeHertz Smart Risk — Android project

This Android Studio project wraps the current TradeHertz Smart Risk Calculator HTML prototype in a WebView.

## Features in the included HTML
- Overview risk plan
- XAUUSD manual entry / Buy-Sell scenario planner
- Stop Loss and TP1/TP2/TP3 percentage levels
- Bullish / bearish hypothetical percentage levels
- Kelly Criterion with fractional Kelly and risk cap
- Local trade-calculation history
- Light / dark theme

## Build an APK
This ZIP is a source project, not a compiled APK.

1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `TradeHertz_Smart_Risk_APK_Project` folder.
4. Allow Gradle sync and install the Android SDK components if prompted.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- Package ID: `pro.tradehertz.smartrisk`
- The calculator works offline; it does not fetch live prices or news.
- The app does not calculate broker-specific lot sizes yet because contract specifications differ by broker.
- Validate calculations and test on a device before using it for live trading.
