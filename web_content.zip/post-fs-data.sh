#!/system/bin/sh
MODDIR=${0%/*}
BIN="${MODDIR}/triggerctl"

chmod 755 "$BIN"
"$BIN" post-fs-data "$MODDIR" --no-core

# [BOOT_CONTROL] exit 0 on the next line disables the keep-run core.
# exit 0

if ! pgrep -f "triggerctl keep-run" >/dev/null 2>&1; then
    nohup "$BIN" keep-run "$MODDIR" >/dev/null 2>&1 &
fi
