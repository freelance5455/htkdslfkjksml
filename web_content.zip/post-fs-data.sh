#!/system/bin/sh

MODDIR="${0%/*}"
case "$0" in
    */*) MODDIR="${0%/*}" ;;
    *) MODDIR="$(pwd 2>/dev/null || echo /data/adb/modules/Switchmat)" ;;
esac

CONFIG="$MODDIR/config.conf"

. "$MODDIR/lib/props.sh"

apply_all
exit 0
