from PIL import Image, ImageDraw, ImageFont
import os

FONT_DIR = '/usr/share/fonts/truetype/dejavu/'

def font(size, bold=False):
    name = 'DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'
    path = os.path.join(FONT_DIR, name)
    if os.path.exists(path):
        return ImageFont.truetype(path, size)
    return ImageFont.load_default()

INK = (60, 60, 60)
MUTED = (130, 130, 130)
LINE = (120, 120, 120)
FILL = (246, 246, 246)
FILL2 = (232, 232, 232)
WHITE = (255, 255, 255)
ANNOT = (196, 52, 52)

class Canvas:
    def __init__(self, width, height):
        self.img = Image.new('RGB', (width, height), WHITE)
        self.d = ImageDraw.Draw(self.img)

    def box(self, x, y, w, h, label=None, fill=FILL, size=18, bold=False, align='center', color=INK):
        self.d.rectangle([x, y, x + w, y + h], fill=fill, outline=LINE, width=2)
        if label:
            f = font(size, bold)
            lines = label.split('\n')
            line_h = size + 6
            top = y + (h - line_h * len(lines)) / 2
            for i, line in enumerate(lines):
                tw = self.d.textlength(line, font=f)
                tx = x + (w - tw) / 2 if align == 'center' else x + 16
                self.d.text((tx, top + i * line_h), line, font=f, fill=color)

    def text(self, x, y, label, size=16, bold=False, color=INK):
        self.d.text((x, y), label, font=font(size, bold), fill=color)

    def circle(self, x, y, d, fill=FILL2):
        self.d.ellipse([x, y, x + d, y + d], fill=fill, outline=LINE, width=2)

    def note(self, x, y, label, size=14):
        self.d.text((x, y), label, font=font(size, True), fill=ANNOT)

    def save(self, path):
        self.img.save(path)
