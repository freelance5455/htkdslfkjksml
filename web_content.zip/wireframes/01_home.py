from draw_common import Canvas, MUTED, INK, WHITE, FILL, FILL2

W, H = 1440, 2090
c = Canvas(W, H)
M = 80
CW = W - 2 * M

c.box(0, 0, W, 76, None, fill=(250, 250, 250))
c.circle(M, 16, 44)
c.text(M + 58, 24, 'Appointments and schedule', 22, True)
nav_x = 620
for label, w in [('Home', 80), ('Appointments', 150), ('Events', 90), ('My Schedule', 150)]:
    c.text(nav_x, 27, label, 18)
    nav_x += w + 30
c.box(nav_x + 20, 16, 110, 44, 'Log In', fill=(255, 255, 255), size=18)
c.box(nav_x + 150, 16, 60, 44, 'Theme', fill=(255, 255, 255), size=14)
c.text(W - 240, 27, '', 14)

c.box(M, 110, CW, 440, None, fill=(243, 243, 243))
c.text(M + 60, 170, 'CITY COLLEGE OF SAN JOSE DEL MONTE', 16, True, MUTED)
c.text(M + 60, 205, 'Appointments and schedule,', 44, True)
c.text(M + 60, 262, 'all in one place', 44, True)
c.text(M + 60, 335, 'Book an appointment with a school office or your professor,', 20, False, MUTED)
c.text(M + 60, 364, 'get a digital queue number for walk-ins, and track it in one place.', 20, False, MUTED)
c.box(M + 60, 420, 260, 56, 'Book an Appointment', fill=(200, 200, 200), size=20, bold=True)
c.box(M + 340, 420, 200, 56, 'Browse Events', fill=WHITE, size=20)
c.text(M + 60, 500, 'Note: log in so your appointments and queue numbers stay private to you.', 15, False, MUTED)
c.box(W - M - 380, 150, 320, 300, 'Wordmark banner\n(assets/ccsjdm-wordmark.jpeg)', fill=(225, 225, 225), size=16)

stats_y = 590
stat_w = (CW - 3 * 24) // 4
labels = ['Offices Open Now', 'Appointment Slots Today', 'People In Queue Now', 'Upcoming Events']
for i, label in enumerate(labels):
    x = M + i * (stat_w + 24)
    c.box(x, stats_y, stat_w, 130, None, fill=WHITE)
    c.text(x + 30, stats_y + 22, '00', 40, True)
    c.text(x + 30, stats_y + 84, label, 17, False, MUTED)

sec_y = 770
c.text(M, sec_y, 'Offices and services', 30, True)
c.text(M, sec_y + 44, 'Choose an office to see its services, requirements, and schedule.', 17, False, MUTED)
card_w = (CW - 2 * 28) // 3
offices = ['Office 1: Registrar', 'Office 2: Clinic', 'Office 3: Guidance']
for i, name in enumerate(offices):
    x = M + i * (card_w + 28)
    c.box(x, sec_y + 90, card_w, 190, None, fill=WHITE)
    c.text(x + 24, sec_y + 112, name, 21, True)
    c.text(x + 24, sec_y + 150, 'Office hours and status line', 16, False, MUTED)
    c.text(x + 24, sec_y + 182, 'Services: 4 listed', 16, False, MUTED)
    c.box(x + 24, sec_y + 224, 190, 40, 'View services', fill=FILL2, size=16)
c.box(M + CW // 2 - 140, sec_y + 310, 280, 48, 'View All Offices and Faculty', fill=FILL2, size=17)

steps_y = 1230
c.text(M, steps_y, 'How it works', 30, True)
step_w = (CW - 3 * 24) // 4
steps = ['Choose an office\nor professor', 'Check the\nrequirements', 'Book a slot or\ntake a number', 'Track it in\nMy Schedule']
for i, s in enumerate(steps):
    x = M + i * (step_w + 24)
    c.box(x, steps_y + 60, step_w, 150, None, fill=WHITE)
    c.circle(x + 24, steps_y + 84, 40, fill=FILL2)
    c.text(x + 38, steps_y + 90, str(i + 1), 22, True)
    c.text(x + 24, steps_y + 128, s.split('\n')[0], 19, True)
    if '\n' in s: c.text(x + 24, steps_y + 156, s.split('\n')[1], 19, True)

ev_y = 1500
c.text(M, ev_y, 'Featured events', 30, True)
for i in range(3):
    x = M + i * (card_w + 28)
    c.box(x, ev_y + 60, card_w, 230, None, fill=WHITE)
    c.box(x, ev_y + 60, card_w, 110, 'Event banner (image or generated)', fill=FILL2, size=15)
    c.text(x + 20, ev_y + 186, 'Event title  |  Category', 18, True)
    c.text(x + 20, ev_y + 218, 'Date  |  Venue', 16, False, MUTED)
c.box(M + CW // 2 - 110, ev_y + 310, 220, 46, 'Browse Events', fill=FILL2, size=17)

c.box(0, H - 170, W, 170, None, fill=(250, 250, 250))
c.text(M, H - 140, '2026 Appointments and schedule. All Rights Reserved.', 17, False, MUTED)
c.text(M, H - 100, 'About    Privacy Policy    Contact', 16, False, MUTED)
c.text(M, H - 64, 'Prototype / demo build for a class presentation. No real data is stored.', 15, False, MUTED)

c.note(W - 420, 84, 'Header: only the seal logo links to ccsjdm.com')
c.save('01_home_wireframe.png')
print('saved')
