from draw_common import Canvas, MUTED, INK, WHITE, FILL, FILL2

W, H = 1440, 1540
c = Canvas(W, H)
M = 80
CW = W - 2 * M

c.box(0, 0, W, 76, None, fill=(250, 250, 250))
c.circle(M, 16, 44)
c.text(M + 58, 24, 'Appointments and schedule', 22, True)
nav_x = 620
for label, w, active in [('Home', 80, False), ('Appointments', 150, True), ('Events', 90, False), ('My Schedule', 150, False)]:
    c.text(nav_x, 27, label, 18, active)
    nav_x += w + 30
c.box(nav_x + 20, 16, 110, 44, 'Log In', fill=WHITE, size=18)
c.box(nav_x + 150, 16, 60, 44, 'Theme', fill=WHITE, size=14)

c.text(M, 110, 'Student Service Directory', 36, True)
c.text(M, 160, 'Find the right office, check the requirements before you go, then book an appointment or get a digital queue number.', 18, False, MUTED)

c.box(M, 210, CW, 62, 'Search an office, a service, a professor, or a subject            [ Search ]', fill=WHITE, size=18, align='left', color=MUTED)
c.box(M, 292, 420, 50, 'School Offices  (active)', fill=FILL2, size=18, bold=True)
c.box(M + 430, 292, 420, 50, 'Professors', fill=WHITE, size=18)

c.text(M, 378, 'School Offices', 28, True)
c.text(W - M - 200, 384, '6 results', 17, False, MUTED)

cards = [
    ('Office of the Registrar', 'Walk-in queue', 'Open now', 'Records, TOR, certificates'),
    ('Medical and Dental Clinic', 'Appointment or walk-in', 'Open now', 'Consultation, dental, certificates'),
    ('Guidance and Counseling', 'Appointment required', 'Closed', 'Counseling, good moral certificate'),
    ('Quality Assurance Office', 'Walk-in queue', 'Open now', 'Forms, surveys, accreditation'),
    ('Office of Student Affairs', 'Appointment or walk-in', 'Open now', 'Scholarships, org accreditation'),
    ('Faculty and Professors', 'Appointment required', 'Open now', 'Book a professor directly'),
]
card_w = (CW - 2 * 28) // 3
card_h = 250
for i, (name, mode, status, desc) in enumerate(cards):
    col, row = i % 3, i // 3
    x = M + col * (card_w + 28)
    y = 430 + row * (card_h + 28)
    c.box(x, y, card_w, card_h, None, fill=WHITE)
    c.box(x + 22, y + 20, 110, 30, status, fill=FILL2 if status == 'Open now' else (230, 230, 230), size=14)
    c.text(x + 22, y + 66, name, 21, True)
    c.text(x + 22, y + 100, desc, 16, False, MUTED)
    c.text(x + 22, y + 130, 'Mode: ' + mode, 16, False, MUTED)
    c.text(x + 22, y + 160, 'Requirements checklist shown on the next page', 15, False, MUTED)
    c.box(x + 22, y + 190, 180, 42, 'View services', fill=FILL2, size=16)
    c.box(x + 214, y + 190, 180, 42, 'Book / Queue', fill=FILL, size=16)

c.box(0, H - 170, W, 170, None, fill=(250, 250, 250))
c.text(M, H - 140, '2026 Appointments and schedule. All Rights Reserved.', 17, False, MUTED)
c.text(M, H - 100, 'About    Privacy Policy    Contact', 16, False, MUTED)
c.text(M, H - 64, 'Prototype / demo build for a class presentation. No real data is stored.', 15, False, MUTED)

c.text(M, 84, 'Note: Book / Queue asks for student login first. Guests can browse.', 14, True, (196, 52, 52))
c.save('02_appointments_wireframe.png')
print('saved')
