#!/usr/bin/env python3
"""Assemble index.html from the page partials. Usage: python3 build.py"""
import glob
head = open("head.html", encoding="utf-8").read()
parts = sorted(glob.glob("pages/*.html"))
body = "".join(open(p, encoding="utf-8").read() for p in parts)
tail = """<noscript><p style="padding:20px;color:#f6efdc">برای اجرای بازی جاوااسکریپت را فعال کن.</p></noscript>
<script src="vendor/jquery.min.js"></script>
<script src="js/effects.js"></script>
<script src="js/fallback.js"></script>
<script src="js/app.js"></script>
<script src="js/desktop.js"></script>
<script src="js/pwa.js"></script>
</body>
</html>
"""
open("index.html", "w", encoding="utf-8").write(head + body + tail)
print("index.html built from", len(parts), "parts")
