window.AppState = {
    file: null,
    fileBuffer: null,
    hashHex: '',
    dexFiles: [],
    parsedData: {
        strings: [],
        classes: [],
        methods: []
    },
    activeTab: 'strings',
    searchQuery: '',

    reset() {
        this.file = null;
        this.fileBuffer = null;
        this.hashHex = '';
        this.dexFiles = [];
        this.parsedData = { strings: [], classes: [], methods: [] };
        this.activeTab = 'strings';
        this.searchQuery = '';
    }
};
