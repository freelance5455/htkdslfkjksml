// Top-level build file for CORM v8.5 Native Android Project (Kotlin)
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
