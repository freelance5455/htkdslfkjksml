import java.util.Base64
import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.tasks.Copy
import org.gradle.api.tasks.InputFile
import org.gradle.api.tasks.OutputFile
import org.gradle.api.tasks.TaskAction
import org.gradle.api.tasks.bundling.Zip

// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.kotlin.compose) apply false
  alias(libs.plugins.google.devtools.ksp) apply false
  alias(libs.plugins.secrets) apply false
  alias(libs.plugins.google.services) apply false
}

abstract class DecodeKeystoreTask : DefaultTask() {
  @get:InputFile abstract val base64Input: RegularFileProperty
  @get:OutputFile abstract val decodedOutput: RegularFileProperty

  @TaskAction
  fun decode() {
    val raw = base64Input.get().asFile.readText()
    val bytes = Base64.getMimeDecoder().decode(raw)
    val out = decodedOutput.get().asFile
    out.parentFile.mkdirs()
    out.writeBytes(bytes)
  }
}

val decodeKeystoreForZip =
  tasks.register<DecodeKeystoreTask>("decodeKeystoreForZip") {
    base64Input.set(layout.projectDirectory.file("debug.keystore.base64"))
    decodedOutput.set(layout.buildDirectory.file("tmp/keystore-export/debug.keystore"))
  }

val createStandaloneProjectZip =
  tasks.register<Zip>("createStandaloneProjectZip") {
    dependsOn(decodeKeystoreForZip)
    archiveFileName.set("MoonChess-Reader-Android-Project.zip")
    destinationDirectory.set(layout.buildDirectory.dir("exported-zip"))

    from(layout.projectDirectory) {
      include(
        "settings.gradle.kts",
        "build.gradle.kts",
        "gradle.properties",
        ".gitignore",
        ".env.example",
        "metadata.json",
        "README_BUILD_APK.md",
        "debug.keystore.base64",
        ".github/**",
        "gradle/**",
        "app/**"
      )
      exclude(
        "**/build/**",
        ".gradle/**",
        ".kotlin/**",
        "app/src/main/assets/MoonChess-Reader-Android-Project.zip",
        "MoonChess-Reader-Android-Project.zip"
      )
    }

    from(decodeKeystoreForZip.flatMap { it.decodedOutput }) {
      into("")
    }
  }

val bundleProjectZipIntoAssets =
  tasks.register<Copy>("bundleProjectZipIntoAssets") {
    from(createStandaloneProjectZip)
    into(layout.projectDirectory.dir("app/src/main/assets"))
  }

tasks.register<Copy>("packageAndroidProjectZip") {
  dependsOn(bundleProjectZipIntoAssets)
  from(createStandaloneProjectZip)
  into(layout.projectDirectory)
}
