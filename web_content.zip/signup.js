(function () {
  var A = window.App, Au = window.Auth;
  if (A.redirectIfAuth()) return;
  Au.bindEyes();
  var form = document.getElementById('signup-form');
  var bars = A.$$('#strength-bars span'), txt = document.getElementById('strength-text');
  var levels = [
    { t: 'Çok zayıf', c: 'bg-destructive' }, { t: 'Zayıf', c: 'bg-destructive' },
    { t: 'Orta', c: 'bg-secondary-foreground' }, { t: 'İyi', c: 'bg-accent' }, { t: 'Güçlü', c: 'bg-accent' }
  ];
  function score(p) {
    var s = 0;
    if (p.length >= 8) s++;
    if (/[a-zçğıöşü]/.test(p) && /[A-ZÇĞİÖŞÜ]/.test(p)) s++;
    if (/\d/.test(p)) s++;
    if (/[^A-Za-z0-9]/.test(p) || p.length >= 12) s++;
    return s;
  }
  form.password.addEventListener('input', function () {
    var p = form.password.value, s = p ? score(p) : -1;
    bars.forEach(function (b, i) { b.className = 'h-1.5 rounded-full ' + (i < s ? levels[s].c : 'bg-muted'); });
    txt.textContent = p ? 'Şifre gücü: ' + levels[s].t : 'Şifre gücü';
  });
  form.username.addEventListener('input', function () {
    var u = form.username.value.trim();
    if (!u) return Au.showErr('username', '');
    if (!A.usernameValid(u)) Au.showErr('username', '3-20 karakter; harf, rakam, _ ve . kullanabilirsin.');
    else if (!A.usernameAvailable(u)) Au.showErr('username', 'Bu kullanıcı adı alınmış.');
    else Au.showErr('username', '');
  });
  document.getElementById('open-terms').addEventListener('click', function (e) { e.preventDefault(); Au.terms(); });
  document.getElementById('open-privacy').addEventListener('click', function (e) { e.preventDefault(); Au.privacy(); });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    try { handle(); } catch (err) { A.toast('Hata: ' + err.message, 'error'); }
  });
  function handle() {
    ['name', 'username', 'email', 'password', 'terms'].forEach(function (k) { Au.showErr(k, ''); });
    var ok = true;
    if (form.name.value.trim().length < 2) { Au.showErr('name', 'Adını gir.'); ok = false; }
    if (!A.usernameValid(form.username.value.trim())) { Au.showErr('username', '3-20 karakter; harf, rakam, _ ve . kullanabilirsin.'); ok = false; }
    else if (!A.usernameAvailable(form.username.value.trim())) { Au.showErr('username', 'Bu kullanıcı adı alınmış.'); ok = false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.value.trim())) { Au.showErr('email', 'Geçerli bir e-posta gir.'); ok = false; }
    if (form.password.value.length < 8) { Au.showErr('password', 'Şifre en az 8 karakter olmalı.'); ok = false; }
    if (!document.getElementById('terms').checked) { Au.showErr('terms', 'Devam etmek için kabul etmelisin.'); ok = false; }
    if (!ok) { var bad = document.querySelector('[data-err]:not(.hidden)'); if (bad) bad.scrollIntoView({ block: 'center' }); return; }
    var btn = form.querySelector('button[type="submit"]');
    Au.loading(btn, true, 'Kayıt ol');
    A.signup({ name: form.name.value, username: form.username.value, email: form.email.value, password: form.password.value })
      .then(function (id) {
        if (!A.setSession(id, true)) throw new Error('Oturum açılamadı: tarayıcı depolamaya izin vermiyor.');
        A.toast('Hesabın oluşturuldu 🎉');
        location.replace('home.html');
      })
      .catch(function (err) {
        var m = err.message;
        if (/kullanıcı adı/i.test(m)) Au.showErr('username', m);
        else if (/e-posta/i.test(m)) Au.showErr('email', m);
        else A.toast(m, 'error');
        Au.loading(btn, false, 'Kayıt ol');
      });
  }
})();
