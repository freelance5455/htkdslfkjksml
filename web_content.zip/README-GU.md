APMC Junagadh Labour — Admin Panel

FILES
- admin.html: mobile-friendly Admin Panel, Firebase Email/Password login, requires admin custom claim.
- database.rules.json: starting point for RTDB security rules. Review it against the exact data structure before publishing.

IMPORTANT SECURITY
1. The HTML intentionally does NOT let anyone promote themselves to admin.
2. Create/sign in the owner's account under Firebase Console > Authentication > Users using Email/Password.
3. Assign custom claim { "admin": true } to the owner's Firebase Auth UID from a trusted server using Firebase Admin SDK. Never put a service-account JSON/private key in this HTML, Acode project, or public GitHub repository.
4. Force-refresh the ID token / sign out and sign in again after setting the claim.
5. Deploy and test database.rules.json in the Rules Playground with normal-user and admin accounts. Do not publish rules blindly: adapt paths and fields to the existing app, especially if bills are stored under users/{uid}/bills or user IDs are not Firebase Auth UIDs.
6. Admin reads expected paths: users/, bills/, pockets/. Data field names supported by this UI include userId/uid, name, email/mobile, billNo/billNumber, date/billDate/createdAt, shopName/shop, total/amount/grandTotal.
7. Firebase web apiKey is not a server secret; database rules and trusted admin claims are what protect data. Never share passwords or service-account keys.

CUSTOM CLAIM SETUP (trusted environment only)
Using Firebase Admin SDK on your own trusted computer/server, after initializing Admin SDK with credentials safely:
  await getAuth().setCustomUserClaims("OWNER_FIREBASE_AUTH_UID", { admin: true });
Replace OWNER_FIREBASE_AUTH_UID with the owner's actual Authentication UID.
Do not run this command in browser code. Do not paste service-account private keys into ChatGPT or the app.

DEPLOY
- For local testing, open admin.html with a web server or Firebase Hosting (recommended).
- Firebase Hosting: place admin.html in the Hosting public folder, then deploy with Firebase CLI from a trusted computer.
- Use HTTPS and strong unique password. Enable MFA for the owner if practical.

NOTES
- The 260 shop records are not downloaded from Firebase by this admin panel; the local shop list in the main app can remain local.
- Current UI reads Firebase paths users, bills, pockets. Existing app data paths may differ and need mapping before all records show.
