/* ==========================================================================
   رهنما — احراز هویت و همگامی  |  hk-auth.js
   روی همهٔ صفحه‌ها: وضعیت ورود، دکمهٔ پروفایل در سربرگ، اعلان سراسری،
   و همگامی خودکار دادهٔ مطالعه با سرور (فقط اگر کاربر وارد شده باشد).
   ========================================================================== */
(function () {
  "use strict";

  var W = window, D = document;
  var $ = function (s, r) { return (r || D).querySelector(s); };
  var LS = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  };
  function toast(m, ms) { W.HK && W.HK.toast ? W.HK.toast(m, ms) : null; }

  var ME = null;
  var LAST_SYNC = 0;

  /* ----------------------------------------------------- درخواست API */
  function api(method, path, body) {
    var opt = { method: method, headers: {}, credentials: "same-origin" };
    if (method !== "GET") {
      opt.headers["Content-Type"] = "application/json";
      opt.headers["X-HK"] = "1";
      opt.body = JSON.stringify(body === undefined ? {} : body);
    }
    return fetch(path, opt).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { var e = new Error((j && j.error) || ("خطا (" + r.status + ")")); e.status = r.status; e.data = j; throw e; }
        return j;
      });
    });
  }

  /* ------------------------------------------------ جمع‌آوری دادهٔ محلی */
  function collectLocal() {
    var out = { read: {}, notes: [], marks: [], tasks: [], exams: [], studyLog: [], plan: null, fcKnown: {}, scores: {} };
    var i, k, v;
    try {
      for (i = 0; i < localStorage.length; i++) {
        k = localStorage.key(i);
        if (!k || k.indexOf("g8:") !== 0) continue;
        if (k.indexOf("g8:read:") === 0) { v = LS.get(k, false); if (v) out.read[k] = true; }
        else if (k.indexOf("g8:notes:") === 0) out.notes = out.notes.concat(LS.get(k, []) || []);
        else if (k === "g8:marks") out.marks = LS.get(k, []) || [];
        else if (k === "g8:tasks") out.tasks = LS.get(k, []) || [];
        else if (k === "g8:exams") out.exams = LS.get(k, []) || [];
        else if (k === "g8:studyLog") out.studyLog = LS.get(k, []) || [];
        else if (k === "g8:plan") out.plan = LS.get(k, null);
        else if (k === "g8:fcKnown") out.fcKnown = LS.get(k, {}) || {};
        else if (k.indexOf("g8:rpScores:") === 0) out.scores[k] = LS.get(k, {});
      }
    } catch (e) {}
    return out;
  }

  /** دادهٔ سرور را روی همین دستگاه می‌نویسد (طوری که بقیهٔ صفحه‌ها ببینند). */
  function applyServer(data) {
    if (!data) return;
    var set = function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
    Object.keys(data.read || {}).forEach(function (k) { set(k, true); });
    set("g8:marks", data.marks || []);
    set("g8:tasks", data.tasks || []);
    set("g8:exams", data.exams || []);
    set("g8:studyLog", data.studyLog || []);
    set("g8:fcKnown", data.fcKnown || {});
    if (data.plan) set("g8:plan", data.plan);
    Object.keys(data.scores || {}).forEach(function (k) { set(k, data.scores[k]); });

    // یادداشت‌ها بر پایهٔ درس گروه‌بندی می‌شوند
    var bySub = {};
    (data.notes || []).forEach(function (n) {
      var s = n.sub || "jozve";
      (bySub[s] = bySub[s] || []).push(n);
    });
    Object.keys(bySub).forEach(function (s) { set("g8:notes:" + s, bySub[s]); });
  }

  var syncTimer = 0;
  function sync(silent) {
    if (!ME) return Promise.resolve(null);
    if (syncTimer) { clearTimeout(syncTimer); syncTimer = 0; }
    return api("POST", "/api/me/sync", { data: collectLocal() }).then(function (r) {
      applyServer(r.data);
      LAST_SYNC = Date.now();
      if (!silent) toast("داده‌هایت با حساب همگام شد");
      paintAvatar();
      try { W.dispatchEvent(new CustomEvent("hk:synced", { detail: r.data })); } catch (e) {}
      return r.data;
    }).catch(function (e) {
      if (!silent) toast("همگامی انجام نشد: " + e.message);
      return null;
    });
  }
  function scheduleSync(delay) {
    if (!ME) return;
    if (syncTimer) clearTimeout(syncTimer);
    syncTimer = setTimeout(function () { sync(true); }, delay || 4000);
  }

  /* ------------------------------------------------------ سربرگ */
  function paintAvatar() {
    var nav = $(".header-nav");
    if (!nav) return;
    var old = $(".hk-account", nav);
    if (old) old.remove();

    var a = D.createElement("a");
    a.className = "hk-account";
    if (ME) {
      a.href = "/profile.html";
      a.title = ME.name + " — " + (ME.roleFa || "") + (ME.verified ? " · تأییدشده" : "");
      a.innerHTML =
        '<span class="hk-ava" style="background:linear-gradient(140deg,' + (ME.color || "#6d5efc") + ',color-mix(in srgb,' + (ME.color || "#6d5efc") + ' 55%,#000))">' +
        esc((ME.name || "؟").trim().charAt(0)) + "</span>" +
        "<span>" + esc((ME.name || "").split(" ")[0]) + "</span>" +
        (ME.verified ? '<span class="hk-tick" title="حساب تأییدشده" aria-label="تأییدشده"></span>' : "") +
        (ME.isOwner ? '<span class="hk-ownertag">مالک</span>'
          : (ME.role === "admin" || ME.role === "teacher" ? '<span class="hk-role">' + esc(ME.roleFa) + "</span>" : ""));
    } else {
      a.href = "/profile.html";
      a.title = "ورود یا ثبت‌نام";
      a.innerHTML = '<span class="hk-ava" style="background:var(--surface-3);color:var(--text-soft)">؟</span><span>ورود</span>';
    }
    var themeBtn = $("[data-theme-toggle]", nav);
    if (themeBtn) nav.insertBefore(a, themeBtn);
    else nav.appendChild(a);

    if (ME && (ME.role === "admin" || ME.isOwner)) {
      var adm = D.createElement("a");
      adm.className = "hk-account hk-admin-link";
      adm.href = "/admin.html";
      adm.innerHTML = '<span class="hk-ava" style="background:linear-gradient(140deg,#111827,#374151);color:#fff">⚙</span><span>مدیریت</span>';
      nav.insertBefore(adm, a);
    }
  }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  /* -------------------------------------------------- اعلان سراسری */
  function banner(ann) {
    var old = $(".hk-announce");
    if (ann && ann.active && ann.text) {
      if (old) { old.className = "hk-announce lv-" + ann.level; $("span", old).textContent = ann.text; return; }
      var b = D.createElement("div");
      b.className = "hk-announce lv-" + (ann.level || "info");
      b.innerHTML = '<span>' + esc(ann.text) + '</span><button aria-label="بستن">✕</button>';
      b.querySelector("button").addEventListener("click", function () { b.remove(); });
      var hdr = $(".site-header");
      if (hdr && hdr.parentNode) hdr.parentNode.insertBefore(b, hdr.nextSibling);
      else D.body.insertBefore(b, D.body.firstChild);
    } else if (old) old.remove();
  }

  /* --------------------------------------------------- راه‌اندازی */
  function boot() {
    // وضعیت عمومی سایت (اعلان، ثبت‌نام، تعمیر)
    fetch("/api/site/status", { credentials: "same-origin" })
      .then(function (r) { return r.json(); })
      .then(function (s) {
        if (s && s.announcement) banner(s.announcement);
        W.HK = W.HK || {};
        W.HK.siteStatus = s;
      })
      .catch(function () {});

    // وضعیت ورود
    api("GET", "/api/auth/me").then(function (r) {
      ME = r.user;
      paintAvatar();
      if (ME) {
        sync(true);
        setInterval(function () { sync(true); }, 3 * 60 * 1000);
        // هر تغییری در پیشرفت → همگامی با تأخیر
        W.addEventListener("hk:progress", function () { scheduleSync(4000); });
        D.addEventListener("visibilitychange", function () { if (D.hidden) sync(true); });
      }
      W.dispatchEvent(new CustomEvent("hk:auth", { detail: ME }));
    }).catch(function () { paintAvatar(); });

    W.HK = W.HK || {};
    W.HK.auth = {
      api: api,
      me: function () { return ME; },
      setMe: function (u) { ME = u; paintAvatar(); },
      login: function (email, password) {
        return api("POST", "/api/auth/login", { email: email, password: password }).then(function (r) {
          ME = r.user; paintAvatar(); sync(true); return r.user;
        });
      },
      register: function (payload) {
        return api("POST", "/api/auth/register", payload).then(function (r) {
          ME = r.user; paintAvatar(); sync(true); return r.user;
        });
      },
      logout: function () {
        return api("POST", "/api/auth/logout", {}).then(function () { ME = null; paintAvatar(); });
      },
      sync: sync,
      collect: collectLocal,
      apply: applyServer,
      lastSync: function () { return LAST_SYNC; }
    };
  }

  if (D.readyState === "loading") D.addEventListener("DOMContentLoaded", boot); else boot();
})();
