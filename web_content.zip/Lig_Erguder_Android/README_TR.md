# Lig Erguder — Android Studio projesi

Bu klasör, verdiğin kariyer modu oyununu Android telefonda çalışan bir uygulama kabuğuna yerleştirir.

## APK oluşturma
1. Android Studio'yu aç.
2. `Lig_Erguder_Android` klasörünü **Open** ile seç.
3. Gradle eşitlemesi tamamlanınca **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.
4. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumuna çıkar.

## Notlar
- Uygulama portre ekran yönünde açılır.
- Oyun HTML/JavaScript olarak cihazın içinde çalışır; oyun için internet gerekmez. Google Fonts bağlantısı yalnızca fontu çevrimiçi yükler; bağlantı yoksa sistem yazı tipine döner.
- Bu teslim bir Android Studio kaynak projesidir; burada imzalanmış APK derlenmedi.
- Uygulama kimliği: `com.ligerguder.app`
