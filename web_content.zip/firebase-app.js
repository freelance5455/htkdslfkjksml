// Firebase configuration for الفحماوي للنثريات
const firebaseConfig = {
  apiKey: "AIzaSyDTiOrD0MhY35I8fgFIA_gDs-sgsfjWL3g",
  authDomain: "fahmawi-nathriyat.firebaseapp.com",
  projectId: "fahmawi-nathriyat",
  storageBucket: "fahmawi-nathriyat.firebasestorage.app",
  messagingSenderId: "61266015430",
  appId: "1:61266015430:web:09cd4f2247589dbead13c7",
  measurementId: "G-KTLFKKFC1D"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
