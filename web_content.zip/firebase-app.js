// Firebase configuration for الفحماوي للنثريات
const firebaseConfig = {
  apiKey: "AIzaSyDTiOrD0MhY35I8fgFIA_gDs-sgsfjWL3g",
  authDomain: "fahmawi-nathriyat.firebaseapp.com",
  projectId: "fahmawi-nathriyat",
  storageBucket: "fahmawi-nathriyat.firebasestorage.app",
  messagingSenderId: "61266015430",
  appId: "1:61266015430:web:ef6c19e404dc5909ad13c7",
  measurementId: "G-2LJH25YKHQ"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
