# Carreira de Craque v1.61.4 — Imprensa realista e matérias pós-jogo

- Substituídos nomes e veículos fictícios das coletivas por jornalistas e veículos reais de cobertura esportiva brasileira (ge, sportv, TV Globo e GE TV).
- Perguntas e respostas continuam sendo conteúdo simulado do jogo; a interface deixa claro que não são declarações reais dos jornalistas.
- Manchete pós-jogo redesenhada em formato editorial inspirado no ge, com faixa de marca, editoria, título, linha fina e placar.
- Escudos dos dois clubes aparecem ao lado do placar da matéria.
- Matéria dinâmica contextualiza o resultado, a competição, a participação real do jogador e os gols registrados no motor da partida.
- Clássicos recebem título, linha fina e texto próprios, destacando a rivalidade e o desfecho do confronto.
- Cache do PWA atualizado para entregar a nova versão.

## Validação
- Sintaxe JavaScript verificada com `node --check`.
- ZIP do projeto validado após empacotamento.
