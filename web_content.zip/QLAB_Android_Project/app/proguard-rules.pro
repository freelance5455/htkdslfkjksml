# Q LAB: no custom shrinking rules required.
