Q LAB Android package

1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK platform/build tools requested by the project.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

The app loads app/src/main/assets/index.html in a WebView with JavaScript and DOM storage enabled.
The HTML uses network-hosted CDN libraries already present in the page, so internet access is enabled in the manifest.
