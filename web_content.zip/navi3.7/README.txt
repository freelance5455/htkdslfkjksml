ناوبری ۳.۷ — MapLibre + OpenStreetMap (رایگان) + GPS واقعی
==========================================================

فایل اصلی: navi3.7.html
نسخه: 3.7

تغییرات نسخه ۳.۷
----------------
- پیاده‌سازی کامل دریافت موقعیت واقعی GPS گوشی با بالاترین دقت (enableHighAccuracy)
- درخواست صریح اجازه کاربر قبل از دسترسی به موقعیت (Permissions API + watchPosition)
- نمایش زنده موقعیت روی نقشه با به‌روزرسانی لحظه‌ای هنگام حرکت
- دریافت جهت حرکت (heading) و سرعت واقعی خودرو در صورت پشتیبانی دستگاه
- مدیریت هوشمند خطاها:
  * اگر دسترسی رد شود → امکان درخواست مجدد با کلیک روی آیکون GPS یا دکمه موقعیت من
  * اگر GPS خاموش یا سیگنال نباشد → راهنمایی کاربر برای روشن کردن GPS
  * تلاش مجدد خودکار در صورت timeout
- بهینه‌سازی مصرف باتری و پردازنده (حداکثرAge مناسب + به‌روزرسانی UI محدود)
- هیچ مختصات ساختگی یا آزمایشی استفاده نمی‌شود
- سازگار با Android WebView (نمونه کد در پوشه android/)

نقشه
----
- کتابخانه: MapLibre GL JS
- داده: OpenStreetMap
- کاشی برداری آنلاین: OpenFreeMap (بدون API Key، رایگان)
  استایل‌ها: liberty / bright / 3d / dark
- ظاهر نزدیک به مسیریاب‌های ایرانی با جاده‌های رنگی
- ساختمان سه‌بعدی (fill-extrusion) و زاویه مایل (pitch)
- بدون نشان، بدون سرویس پولی

آفلاین (PMTiles)
----------------
1) فایل PMTiles شهر/منطقه را از منبع معتبر دانلود کنید
   (schema: OpenMapTiles)
2) تنظیمات → آدرس فایل .pmtiles را وارد کنید → اعمال
3) برای بازگشت: «بازگشت به نقشه آنلاین»

مسیریابی آفلاین هنوز پیاده نشده؛ MAP_CONFIG.routingMode برای آینده آماده است.

جستجو: Nominatim (OSM) — سیاست استفاده منصفانه
مسیریابی: OSRM عمومی — برای ترافیک کم/آزمایش

اجرا
----
navi3.7.html را کنار libraries و assets باز کنید.
اینترنت برای نقشه آنلاین لازم است.

نکته مهم GPS / Geolocation
--------------------------
- Geolocation API فقط در محیط امن کار می‌کند: HTTPS یا localhost یا file:// در برخی مرورگرها محدود است.
- برای تست واقعی GPS حتماً روی گوشی واقعی (نه شبیه‌ساز بدون GPS) و با GPS روشن تست کنید.
- اگر از file:// باز می‌کنید و GPS کار نکرد، فایل را از طریق یک سرور محلی (مثلاً python -m http.server) سرو کنید.
- در Android WebView حتماً مجوزهای Manifest و هندلینگ WebChromeClient را اضافه کنید (نمونه در android/).

Android WebView (نمونه)
-----------------------
پوشه android/ شامل:
- AndroidManifest.xml.snippet  → مجوزهای لازم
- MainActivity.java.snippet    → فعال‌سازی Geolocation در WebView
- WebAppInterface.java.snippet → پل اختیاری

مراحل سریع:
1. ACCESS_FINE_LOCATION و ACCESS_COARSE_LOCATION را در Manifest اضافه کنید.
2. در WebSettings: setGeolocationEnabled(true)
3. WebChromeClient.onGeolocationPermissionsShowPrompt را پیاده‌سازی کنید و به کاربر اجازه بدهید.
4. برای Android 6+ runtime permission را درخواست کنید.

محدودیت تست محیط توسعه
----------------------
دسترسی به سرویس‌های خارجی ممکن است از سرور توسعه محدود باشد.
روی دستگاه واقعی WebView/مرورگر با اینترنت و GPS تست کنید.
