راهنمای سریع اتصال GPS واقعی به Android WebView
==============================================

1. مجوزهای Manifest (فایل AndroidManifest.xml.snippet را کپی کنید)
   - ACCESS_FINE_LOCATION
   - ACCESS_COARSE_LOCATION

2. در MainActivity (یا Activity حاوی WebView):
   - webSettings.setGeolocationEnabled(true);
   - WebChromeClient با override کردن onGeolocationPermissionsShowPrompt
   - درخواست runtime permission برای Android 6+

3. فایل navi3.7.html و پوشه‌های libraries + assets را در assets/ پروژه اندروید کپی کنید
   و با file:///android_asset/navi3.7.html بارگذاری کنید
   یا از طریق HTTP محلی سرو کنید.

4. تست:
   - روی گوشی واقعی با GPS روشن
   - اجازه دسترسی به موقعیت را هنگام درخواست بدهید
   - آیکون GPS در بالای صفحه باید سبز شود و مختصات واقعی نمایش داده شود
   - با حرکت گوشی، موقعیت و جهت و سرعت به‌روز شود

نکته امنیتی: هیچ مختصات ساختگی در کد HTML وجود ندارد. همه از navigator.geolocation می‌آید.
