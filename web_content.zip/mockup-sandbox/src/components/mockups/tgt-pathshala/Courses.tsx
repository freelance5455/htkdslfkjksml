import {
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  CircleDashed,
  Clock3,
  Coins,
  GraduationCap,
  Landmark,
  Layers3,
  Languages,
  Map,
  ScrollText,
  Scale,
} from "lucide-react";
import { ScreenFrame } from "./_shared/AppShell";

type Subject = {
  name: string;
  topics: string;
  lessons: string;
  icon: typeof BookOpen;
  ink: string;
  wash: string;
  accent: string;
  progress?: number;
  note?: string;
};

const subjects: Subject[] = [
  {
    name: "History",
    topics: "18 topics",
    lessons: "74 lessons",
    icon: ScrollText,
    ink: "#a63731",
    wash: "#fff0e9",
    accent: "#e26754",
    progress: 62,
    note: "Ancient India to modern Odisha",
  },
  {
    name: "Geography",
    topics: "14 topics",
    lessons: "56 lessons",
    icon: Map,
    ink: "#16624c",
    wash: "#e9f6ed",
    accent: "#45a879",
  },
  {
    name: "Polity",
    topics: "16 topics",
    lessons: "61 lessons",
    icon: Scale,
    ink: "#274c84",
    wash: "#eaf1ff",
    accent: "#527dcc",
  },
  {
    name: "Economics",
    topics: "12 topics",
    lessons: "48 lessons",
    icon: Coins,
    ink: "#976b16",
    wash: "#fff8dc",
    accent: "#e4b530",
  },
  {
    name: "Education",
    topics: "15 topics",
    lessons: "52 lessons",
    icon: GraduationCap,
    ink: "#794070",
    wash: "#f8edfa",
    accent: "#ad6da5",
  },
  {
    name: "Odia",
    topics: "11 topics",
    lessons: "43 lessons",
    icon: Languages,
    ink: "#a14d27",
    wash: "#fff0e3",
    accent: "#d9854a",
  },
  {
    name: "English",
    topics: "13 topics",
    lessons: "49 lessons",
    icon: BookOpen,
    ink: "#315d77",
    wash: "#eaf5f8",
    accent: "#5fa6b6",
  },
];

function SubjectCard({ subject, featured = false }: { subject: Subject; featured?: boolean }) {
  const Icon = subject.icon;

  return (
    <article
      className={`relative overflow-hidden rounded-[22px] border border-[#e2e8ef] bg-[#fffdfa] shadow-[0_8px_25px_rgba(29,58,92,0.05)] ${
        featured ? "p-5" : "p-4"
      }`}
    >
      <div
        className="absolute bottom-0 left-0 top-0 w-1 rounded-l-full"
        style={{ backgroundColor: subject.accent }}
      />
      <div className={`flex items-start ${featured ? "gap-3" : "flex-col gap-2"}`}>
        <div
          className={`grid shrink-0 place-items-center rounded-[15px] ${
            featured ? "h-12 w-12" : "h-10 w-10"
          }`}
          style={{ backgroundColor: subject.wash, color: subject.ink }}
        >
          <Icon size={featured ? 23 : 19} strokeWidth={1.9} />
        </div>
        <div className={`min-w-0 flex-1 ${featured ? "" : "w-full"}`}>
          <div className="flex min-w-0 items-start justify-between gap-2 pt-0.5">
            <div className="min-w-0">
            <h3
              className={`font-extrabold tracking-[-0.025em] text-[#173052] ${
                featured ? "text-[18px]" : "text-[15px]"
              }`}
            >
              {subject.name}
            </h3>
            <p className="mt-1 text-[11px] font-medium text-slate-400">
              {subject.topics} <span className="px-1 text-slate-300">·</span> {subject.lessons}
            </p>
            </div>
            <div
              className="grid h-7 w-7 shrink-0 place-items-center rounded-full"
              style={{ backgroundColor: subject.wash, color: subject.ink }}
            >
              <ChevronRight size={15} strokeWidth={2.4} />
            </div>
          </div>
        </div>
      </div>
      {featured && (
        <div className="mt-5">
          <div className="flex items-center justify-between text-[11px] font-bold">
            <span className="text-slate-500">{subject.note}</span>
            <span style={{ color: subject.ink }}>{subject.progress}% complete</span>
          </div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#f3dfd8]">
            <div
              className="h-full rounded-full"
              style={{ width: `${subject.progress}%`, backgroundColor: subject.accent }}
            />
          </div>
        </div>
      )}
    </article>
  );
}

export function Courses() {
  return (
    <ScreenFrame title="Courses" active="Courses" showBack showSearch>
      <div className="pb-5">
        <section
          className="relative overflow-hidden rounded-[28px] bg-[#123b80] px-5 pb-5 pt-6 text-white shadow-[0_14px_32px_rgba(13,56,131,0.18)]"
        >
          <div
            className="pointer-events-none absolute -right-12 -top-16 h-44 w-44 rounded-full border-[20px] border-[#f3c64d]/20"
          />
          <div
            className="pointer-events-none absolute -bottom-20 right-10 h-36 w-36 rounded-full border-[11px] border-[#e7463f]/15"
          />
          <div className="relative">
            <div className="mb-3 flex items-center justify-between">
              <span className="rounded-full bg-white/10 px-3 py-1.5 text-[9px] font-extrabold uppercase tracking-[0.17em] text-[#f6d36d]">
                TGT preparation desk
              </span>
              <div className="flex items-center gap-1.5 text-[10px] font-semibold text-blue-100">
                <Layers3 size={13} />
                7 subjects
              </div>
            </div>
            <h1 className="max-w-[255px] text-[28px] font-black leading-[1.06] tracking-[-0.05em]">
              Build your subject command.
            </h1>
            <p className="mt-3 max-w-[290px] text-[12px] leading-[1.65] text-blue-100/80">
              One clear path through the TGT syllabus, with every important topic in its place.
            </p>
            <div className="mt-5 flex items-center gap-2.5">
              <div className="flex -space-x-1.5">
                {["#f3c64d", "#e26754", "#45a879"].map((color) => (
                  <span
                    key={color}
                    className="h-5 w-5 rounded-full border-2 border-[#123b80]"
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
              <span className="text-[10px] font-semibold text-blue-100/80">
                Structured for steady progress
              </span>
            </div>
          </div>
        </section>

        <section className="mt-5 grid grid-cols-[1.15fr_0.85fr] gap-3">
          <div className="rounded-[19px] border border-[#e6eaf0] bg-[#fffdfa] px-4 py-3.5">
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">
              <CheckCircle2 size={14} className="text-[#46a578]" />
              Current focus
            </div>
            <div className="mt-1.5 text-[15px] font-extrabold tracking-[-0.02em] text-[#173052]">
              Modern History
            </div>
            <div className="mt-1 text-[10px] font-medium text-slate-400">12 of 19 lessons done</div>
          </div>
          <div className="rounded-[19px] border border-[#e6eaf0] bg-[#fffdfa] px-4 py-3.5">
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">
              <Clock3 size={14} className="text-[#e2b431]" />
              Study time
            </div>
            <div className="mt-1.5 text-[15px] font-extrabold tracking-[-0.02em] text-[#173052]">
              4h 20m
            </div>
            <div className="mt-1 text-[10px] font-medium text-slate-400">this week</div>
          </div>
        </section>

        <div className="mb-3 mt-8 flex items-end justify-between">
          <div>
            <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#e7463f]">
              The syllabus, sorted
            </p>
            <h2 className="mt-1 text-[22px] font-black tracking-[-0.04em] text-[#173052]">
              All subjects
            </h2>
          </div>
          <span className="pb-1 text-[11px] font-bold text-slate-400">7 courses</span>
        </div>

        <div className="space-y-3">
          <SubjectCard subject={subjects[0]} featured />
          <div className="grid grid-cols-2 gap-3">
            <SubjectCard subject={subjects[1]} />
            <SubjectCard subject={subjects[2]} />
            <SubjectCard subject={subjects[3]} />
            <SubjectCard subject={subjects[4]} />
            <SubjectCard subject={subjects[5]} />
            <SubjectCard subject={subjects[6]} />
          </div>
        </div>

        <section className="mt-5 flex items-center justify-between rounded-[21px] border border-[#f0df9d] bg-[#fff8df] px-4 py-4">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-[13px] bg-[#f3c64d] text-[#725311]">
              <CircleDashed size={20} strokeWidth={2} />
            </div>
            <div className="min-w-0">
              <p className="text-[12px] font-extrabold text-[#5d481b]">Ready for a quick win?</p>
              <p className="mt-1 truncate text-[10px] font-medium text-[#93752e]">
                Continue your next History lesson
              </p>
            </div>
          </div>
          <ArrowUpRight className="shrink-0 text-[#9a761d]" size={19} />
        </section>
      </div>
    </ScreenFrame>
  );
}