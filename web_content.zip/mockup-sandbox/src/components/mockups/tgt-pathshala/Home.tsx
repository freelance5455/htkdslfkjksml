import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Clock3,
  FileText,
  Flame,
  PlayCircle,
  Target,
  Trophy,
  Video,
} from "lucide-react";
import { LogoMark, ScreenFrame } from "./_shared/AppShell";

const studyPaths = [
  {
    label: "Courses",
    detail: "Structured subject plans",
    icon: BookOpen,
    tone: "bg-[#e9f0ff] text-[#17458f]",
    accent: "border-[#c9dafa]",
  },
  {
    label: "PDF Notes",
    detail: "Revision-ready notes",
    icon: FileText,
    tone: "bg-[#fff3dc] text-[#a55e15]",
    accent: "border-[#f2d9a7]",
  },
  {
    label: "Test Series",
    detail: "Practice like the exam",
    icon: Trophy,
    tone: "bg-[#e9f6eb] text-[#287144]",
    accent: "border-[#cce5d0]",
  },
  {
    label: "Video Lectures",
    detail: "Learn from your mentors",
    icon: Video,
    tone: "bg-[#fceceb] text-[#bd423c]",
    accent: "border-[#f2cfcc]",
  },
];

export function Home() {
  return (
    <ScreenFrame title="TGT Pathshala" active="Home" showBell>
      <div className="mx-auto w-full max-w-[520px] pb-2">
        <section className="relative overflow-hidden rounded-[26px] bg-[#0e3b82] px-5 pb-5 pt-5 text-white shadow-[0_12px_28px_rgba(14,59,130,0.18)]">
          <div className="pointer-events-none absolute -right-12 -top-16 h-44 w-44 rounded-full border-[22px] border-white/[0.07]" />
          <div className="pointer-events-none absolute -bottom-16 right-14 h-32 w-32 rounded-full border-[14px] border-[#e7463f]/20" />
          <div className="relative flex items-start justify-between">
            <div>
              <LogoMark compact />
              <p className="mt-5 text-[11px] font-bold uppercase tracking-[0.18em] text-blue-200">
                Tuesday, 18 June
              </p>
              <h1 className="mt-1.5 text-[27px] font-black leading-[1.05] tracking-[-0.045em]">
                Good morning,
                <br />
                Ananya.
              </h1>
              <p className="mt-3 max-w-[220px] text-[12px] leading-5 text-blue-100/80">
                Your next small step is waiting. Keep your TGT preparation moving.
              </p>
            </div>
            <div className="mt-1 grid h-[74px] w-[74px] place-items-center rounded-full border border-white/15 bg-white/[0.08]">
              <div
                className="grid h-[61px] w-[61px] place-items-center rounded-full"
                style={{
                  background:
                    "conic-gradient(#f6c448 0deg 252deg, rgba(255,255,255,.12) 252deg 360deg)",
                }}
              >
                <div className="grid h-[50px] w-[50px] place-items-center rounded-full bg-[#0e3b82] text-center">
                  <span className="text-[16px] font-black leading-none">70%</span>
                  <span className="mt-0.5 text-[8px] font-semibold text-blue-200">
                    this week
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="relative mt-5 flex items-center justify-between border-t border-white/15 pt-3.5">
            <div className="flex items-center gap-2 text-[11px] font-semibold text-blue-50">
              <span className="grid h-6 w-6 place-items-center rounded-full bg-[#e7463f]">
                <Flame size={13} fill="currentColor" />
              </span>
              6 day study streak
            </div>
            <div className="text-[11px] font-semibold text-[#f8d678]">Keep it going</div>
          </div>
        </section>

        <section className="mt-7">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-[0.19em] text-[#e7463f]">
                Your study desk
              </p>
              <h2 className="mt-1 text-[21px] font-black tracking-[-0.035em] text-[#12366e]">
                Choose what to study
              </h2>
            </div>
            <span className="pb-0.5 text-[11px] font-semibold text-slate-400">4 paths</span>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            {studyPaths.map(({ label, detail, icon: Icon, tone, accent }) => (
              <div
                key={label}
                className={`rounded-[19px] border bg-white p-3.5 shadow-[0_5px_14px_rgba(24,55,93,0.04)] ${accent}`}
              >
                <div className={`grid h-9 w-9 place-items-center rounded-xl ${tone}`}>
                  <Icon size={18} strokeWidth={2.2} />
                </div>
                <div className="mt-3 text-[13px] font-extrabold text-[#173052]">{label}</div>
                <div className="mt-1 text-[10px] leading-4 text-slate-400">{detail}</div>
                <div className="mt-3 flex items-center gap-1 text-[10px] font-bold text-[#0e3b82]">
                  Explore <ArrowRight size={12} />
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-7">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-[0.19em] text-[#e7463f]">
                Continue learning
              </p>
              <h2 className="mt-1 text-[20px] font-black tracking-[-0.035em] text-[#12366e]">
                Pick up where you left off
              </h2>
            </div>
            <div className="grid h-9 w-9 place-items-center rounded-full bg-[#fff0ee] text-[#e7463f]">
              <PlayCircle size={19} />
            </div>
          </div>
          <div className="mt-4 rounded-[20px] border border-[#d9e3f0] bg-white p-4 shadow-[0_5px_14px_rgba(24,55,93,0.04)]">
            <div className="flex items-start justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-[14px] bg-[#e9f0ff] text-[#17458f]">
                  <BookOpen size={20} />
                </div>
                <div className="min-w-0">
                  <div className="truncate text-[13px] font-extrabold text-[#173052]">
                    Child Development &amp; Pedagogy
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-[10px] text-slate-400">
                    <Clock3 size={12} /> Lesson 08 of 12 <span className="text-slate-300">•</span>{" "}
                    18 min left
                  </div>
                </div>
              </div>
              <span className="shrink-0 text-[11px] font-extrabold text-[#287144]">66%</span>
            </div>
            <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-[#edf1f5]">
              <div className="h-full w-[66%] rounded-full bg-[#56a56d]" />
            </div>
            <div className="mt-3 flex items-center justify-between">
              <span className="text-[10px] font-medium text-slate-400">Last opened yesterday</span>
              <span className="flex items-center gap-1 text-[11px] font-extrabold text-[#0e3b82]">
                Resume <ChevronRight size={14} />
              </span>
            </div>
          </div>
        </section>

        <section className="mt-7 rounded-[20px] border border-[#f1dca7] bg-[#fff8e8] p-4">
          <div className="flex items-start gap-3">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#f6c448] text-[#6a4a0b]">
              <Target size={17} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <div className="text-[12px] font-extrabold text-[#6a4a0b]">Today&apos;s target</div>
                <div className="text-[10px] font-bold text-[#98721d]">2 of 3 done</div>
              </div>
              <div className="mt-2 text-[13px] font-bold leading-5 text-[#4c3c19]">
                Revise 30 questions from Hindi Grammar
              </div>
              <div className="mt-3 flex items-center gap-1.5">
                {[true, true, false].map((done, index) => (
                  <span
                    key={index}
                    className={`h-1.5 flex-1 rounded-full ${done ? "bg-[#56a56d]" : "bg-[#eadba9]"}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mt-7">
          <div className="flex items-center justify-between">
            <h2 className="text-[20px] font-black tracking-[-0.035em] text-[#12366e]">
              Latest update
            </h2>
            <span className="text-[11px] font-bold text-[#0e3b82]">View all</span>
          </div>
          <div className="mt-3 flex items-center gap-3 rounded-[18px] border border-[#e0e7ef] bg-white p-3.5 shadow-[0_5px_14px_rgba(24,55,93,0.035)]">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-[14px] bg-[#fceceb] text-[#bd423c]">
              <CheckCircle2 size={20} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[12px] font-extrabold leading-4 text-[#173052]">
                New CTET &amp; TGT Practice Set 04 is live
              </div>
              <div className="mt-1 text-[10px] leading-4 text-slate-400">
                25 questions • Hindi medium • Added 2 hours ago
              </div>
            </div>
            <ChevronRight size={17} className="shrink-0 text-slate-300" />
          </div>
        </section>
      </div>
    </ScreenFrame>
  );
}