import {
  Bookmark,
  CheckCircle2,
  ChevronRight,
  Clock3,
  LibraryBig,
  Play,
  Sparkles,
} from "lucide-react";
import { ScreenFrame } from "./_shared/AppShell";

type Lecture = {
  subject: string;
  title: string;
  teacher: string;
  duration: string;
  watched: string;
  image: string;
  accent: string;
};

const filters = ["All", "History", "Geography", "Polity"];

const lectures: Lecture[] = [
  {
    subject: "History",
    title: "The Revolt of 1857: causes, centres and consequences",
    teacher: "Meera Sharma",
    duration: "38 min",
    watched: "2.4k learners",
    image: "/__mockup/images/tgt-history-fort.jpg",
    accent: "#e7463f",
  },
  {
    subject: "Geography",
    title: "Indian drainage system in one visual map",
    teacher: "Amit Verma",
    duration: "42 min",
    watched: "1.8k learners",
    image: "/__mockup/images/tgt-geography-desert.jpg",
    accent: "#d69c2f",
  },
  {
    subject: "Polity",
    title: "Fundamental Rights: articles you must remember",
    teacher: "Rakesh Singh",
    duration: "31 min",
    watched: "3.1k learners",
    image: "/__mockup/images/tgt-polity-constitution.jpg",
    accent: "#4e916f",
  },
  {
    subject: "Revision",
    title: "TGT Social Science: 20-minute rapid revision",
    teacher: "Neha Kapoor",
    duration: "20 min",
    watched: "4.6k learners",
    image: "/__mockup/images/tgt-classroom-revision.jpg",
    accent: "#5675ad",
  },
];

export function VideoLectures() {
  return (
    <ScreenFrame
      title="Video Lectures"
      active="Video Lectures"
      showBack
      showSearch
    >
      <div className="space-y-6 pb-4">
        <section className="pt-1">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="mb-2 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#e7463f]">
                <span className="h-1.5 w-1.5 rounded-full bg-[#e7463f]" />
                Your classroom library
              </div>
              <h1 className="max-w-[250px] text-[27px] font-black leading-[1.08] tracking-[-0.045em] text-[#12366e]">
                Watch. Revise.
                <br />
                <span className="text-[#e7463f]">Move ahead.</span>
              </h1>
            </div>
            <div className="mt-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-[#eadfca] bg-[#fffaf0] text-[#b78021] shadow-[0_5px_14px_rgba(29,57,100,0.05)]">
              <LibraryBig size={20} strokeWidth={1.8} />
            </div>
          </div>
          <p className="mt-3 max-w-[305px] text-[13px] leading-[1.55] text-slate-500">
            Clear explanations for the topics that decide your TGT score.
            Learn at your pace, then return to your practice set.
          </p>
        </section>

        <section className="relative overflow-hidden rounded-[22px] bg-[#103c84] px-5 py-5 text-white shadow-[0_12px_24px_rgba(13,56,131,0.17)]">
          <div className="absolute -right-10 -top-12 h-36 w-36 rounded-full border-[18px] border-white/5" />
          <div className="absolute -bottom-16 right-10 h-28 w-28 rounded-full border border-[#f6c448]/20" />
          <div className="relative flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#f6c448]">
                <Sparkles size={12} />
                Pick for today
              </div>
              <h2 className="mt-2 max-w-[205px] text-[18px] font-extrabold leading-[1.18] tracking-[-0.025em]">
                Make History easy to recall
              </h2>
              <p className="mt-2 max-w-[225px] text-[11px] leading-5 text-blue-100/75">
                A visual walkthrough of the Revolt of 1857, with the exact
                links asked in TGT papers.
              </p>
            </div>
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#e7463f] shadow-lg shadow-red-950/25">
              <Play size={18} fill="currentColor" className="ml-0.5" />
            </div>
          </div>
          <div className="relative mt-4 flex items-center gap-2 text-[10px] font-semibold text-blue-100/75">
            <span className="h-1.5 w-1.5 rounded-full bg-[#f6c448]" />
            38 minutes
            <span className="mx-1 h-3 w-px bg-white/20" />
            Meera Sharma
          </div>
        </section>

        <section aria-label="Lecture subjects">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-[15px] font-extrabold tracking-[-0.02em] text-[#173052]">
              Browse by subject
            </h2>
            <span className="text-[10px] font-semibold text-slate-400">
              24 lectures
            </span>
          </div>
          <div className="flex gap-2 overflow-hidden">
            {filters.map((filter, index) => (
              <div
                key={filter}
                role="tab"
                aria-selected={index === 0}
                className={`shrink-0 rounded-full px-4 py-2 text-[11px] font-bold ${
                  index === 0
                    ? "bg-[#e7463f] text-white shadow-[0_5px_12px_rgba(231,70,63,0.2)]"
                    : "border border-[#dfe6ef] bg-white text-slate-500"
                }`}
              >
                {filter}
              </div>
            ))}
          </div>
        </section>

        <section>
          <div className="mb-3 flex items-end justify-between">
            <div>
              <div className="text-[10px] font-extrabold uppercase tracking-[0.17em] text-[#e7463f]">
                Continue learning
              </div>
              <h2 className="mt-1 text-[19px] font-black tracking-[-0.035em] text-[#173052]">
                Latest lectures
              </h2>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-bold text-[#0d3883]">
              View all
              <ChevronRight size={14} />
            </div>
          </div>

          <div className="space-y-3">
            {lectures.map((lecture, index) => (
              <article
                key={lecture.title}
                className="group flex gap-3 rounded-[18px] border border-[#e2e8f0] bg-white p-2.5 shadow-[0_5px_15px_rgba(29,57,100,0.045)]"
              >
                <div className="relative h-[78px] w-[110px] shrink-0 overflow-hidden rounded-[13px] bg-[#dce4ef]">
                  <img
                    src={lecture.image}
                    alt={`${lecture.subject} lecture: ${lecture.title}`}
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#092d6b]/70 via-transparent to-transparent" />
                  <div className="absolute bottom-2 left-2 flex h-6 w-6 items-center justify-center rounded-full bg-white/95 text-[#0d3883] shadow-sm">
                    <Play size={11} fill="currentColor" className="ml-0.5" />
                  </div>
                  <div className="absolute right-1.5 top-1.5 rounded-md bg-[#102f63]/85 px-1.5 py-1 text-[9px] font-bold text-white">
                    {lecture.duration}
                  </div>
                  <div
                    className="absolute bottom-0 left-0 h-1 rounded-r-full"
                    style={{
                      width: `${index === 0 ? 68 : index === 1 ? 42 : index === 2 ? 84 : 27}%`,
                      backgroundColor: lecture.accent,
                    }}
                  />
                </div>
                <div className="min-w-0 flex-1 py-0.5">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className="text-[9px] font-extrabold uppercase tracking-[0.13em]"
                      style={{ color: lecture.accent }}
                    >
                      {lecture.subject}
                    </span>
                    <Bookmark
                      size={14}
                      className="shrink-0 text-slate-300"
                      strokeWidth={1.8}
                    />
                  </div>
                  <h3 className="mt-1 line-clamp-2 text-[12px] font-extrabold leading-[1.3] tracking-[-0.01em] text-[#173052]">
                    {lecture.title}
                  </h3>
                  <div className="mt-2 flex items-center gap-1.5 text-[10px] text-slate-400">
                    <span className="font-semibold text-slate-500">
                      {lecture.teacher}
                    </span>
                    <span className="h-1 w-1 rounded-full bg-slate-300" />
                    <Clock3 size={11} />
                    <span>{lecture.watched}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <div className="flex items-center gap-3 rounded-2xl border border-[#d9eadf] bg-[#f3faf5] px-4 py-3.5">
          <CheckCircle2 size={19} className="shrink-0 text-[#4e916f]" />
          <p className="text-[11px] leading-4 text-[#3f6f57]">
            Finish one lecture today and keep your weekly study streak alive.
          </p>
        </div>
      </div>
    </ScreenFrame>
  );
}