import type { ReactNode } from "react";
import {
  Bell,
  BookOpen,
  ChevronLeft,
  FileText,
  Home,
  Menu,
  PlaySquare,
  Search,
  ShieldCheck,
  Trophy,
  X,
} from "lucide-react";

export type TgtPage =
  | "Home"
  | "Courses"
  | "PDF Notes"
  | "Test Series"
  | "Video Lectures"
  | "About Us";

const navItems: Array<{ label: TgtPage; icon: typeof Home }> = [
  { label: "Home", icon: Home },
  { label: "Courses", icon: BookOpen },
  { label: "PDF Notes", icon: FileText },
  { label: "Test Series", icon: Trophy },
  { label: "Video Lectures", icon: PlaySquare },
  { label: "About Us", icon: ShieldCheck },
];

export function LogoMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative grid h-9 w-9 place-items-center rounded-full border-[3px] border-[#0e3b82] bg-white shadow-sm">
        <div className="absolute inset-[3px] rounded-full border border-[#e7463f]" />
        <span className="relative -mt-0.5 text-[10px] font-black tracking-tight text-[#0e3b82]">
          TGT
        </span>
        <span className="absolute bottom-[4px] text-[4px] font-bold tracking-[0.08em] text-[#e7463f]">
          PATHSHALA
        </span>
      </div>
      {!compact && (
        <div className="leading-none">
          <div className="text-[13px] font-extrabold tracking-tight text-[#0e3b82]">
            TGT Pathshala
          </div>
          <div className="mt-1 text-[8px] font-medium text-slate-500">
            Your Success, Our Mission
          </div>
        </div>
      )}
    </div>
  );
}

export function ScreenFrame({
  title,
  active,
  children,
  showBack = false,
  showSearch = false,
  showBell = false,
  rightSlot,
}: {
  title: string;
  active?: TgtPage;
  children: ReactNode;
  showBack?: boolean;
  showSearch?: boolean;
  showBell?: boolean;
  rightSlot?: ReactNode;
}) {
  return (
    <main className="min-h-screen bg-[#f5f8fc] font-sans text-[#173052]">
      <header className="sticky top-0 z-10 flex h-[72px] items-center justify-between bg-[#0d3883] px-6 text-white shadow-lg shadow-blue-950/10">
        <div className="flex min-w-0 items-center gap-4">
          {showBack ? (
            <button className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/10">
              <ChevronLeft size={20} />
            </button>
          ) : (
            <button className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/10">
              <Menu size={19} />
            </button>
          )}
          <div className="truncate text-[17px] font-bold tracking-[-0.02em]">
            {title}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {rightSlot}
          {showSearch && (
            <button className="grid h-9 w-9 place-items-center rounded-full bg-white/10">
              <Search size={17} />
            </button>
          )}
          {showBell && (
            <button className="relative grid h-9 w-9 place-items-center rounded-full bg-white/10">
              <Bell size={17} />
              <span className="absolute right-[7px] top-[6px] h-1.5 w-1.5 rounded-full bg-[#fbbd24]" />
            </button>
          )}
        </div>
      </header>
      <div className="mx-auto max-w-[1180px] px-6 py-7">{children}</div>
      {active && (
        <nav className="sticky bottom-0 z-10 mx-auto flex max-w-[1180px] items-center justify-around border-t border-slate-200 bg-white/95 px-3 py-3 backdrop-blur">
          {navItems.slice(0, 5).map(({ label, icon: Icon }) => (
            <div
              key={label}
              className={`flex min-w-[70px] flex-col items-center gap-1 text-[10px] font-semibold ${
                active === label ? "text-[#0d3883]" : "text-slate-400"
              }`}
            >
              <Icon size={17} strokeWidth={active === label ? 2.5 : 2} />
              <span>{label === "Video Lectures" ? "Videos" : label}</span>
            </div>
          ))}
        </nav>
      )}
    </main>
  );
}

export function PageIntro({
  eyebrow,
  title,
  copy,
}: {
  eyebrow: string;
  title: string;
  copy: string;
}) {
  return (
    <div className="mb-7">
      <div className="mb-2 text-[11px] font-extrabold uppercase tracking-[0.18em] text-[#e7463f]">
        {eyebrow}
      </div>
      <h1 className="text-[31px] font-black leading-[1.06] tracking-[-0.04em] text-[#12366e]">
        {title}
      </h1>
      <p className="mt-3 max-w-[560px] text-[14px] leading-6 text-slate-500">
        {copy}
      </p>
    </div>
  );
}

export function DrawerMenu({ onClose }: { onClose?: () => void }) {
  return (
    <aside className="flex min-h-screen w-full max-w-[410px] flex-col bg-[#092d6b] text-white">
      <div className="flex items-center justify-between border-b border-white/10 px-7 py-7">
        <LogoMark />
        {onClose ? (
          <button onClick={onClose} className="grid h-10 w-10 place-items-center rounded-full bg-white/10">
            <X size={18} />
          </button>
        ) : (
          <div className="grid h-10 w-10 place-items-center rounded-full bg-white/10">
            <X size={18} />
          </div>
        )}
      </div>
      <div className="px-4 py-6">
        {navItems.map(({ label, icon: Icon }, index) => (
          <div
            key={label}
            className={`mb-1 flex items-center gap-4 rounded-2xl px-4 py-3.5 text-[14px] font-semibold ${
              index === 0 ? "bg-white/13 text-white" : "text-blue-100/75"
            }`}
          >
            <Icon size={18} />
            <span>{label}</span>
          </div>
        ))}
        <div className="my-5 h-px bg-white/10" />
        {["Bookmarks", "Downloads", "Share App", "Privacy Policy"].map(
          (label) => (
            <div
              key={label}
              className="mb-1 flex items-center gap-4 rounded-2xl px-4 py-3 text-[14px] font-medium text-blue-100/75"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-[#f6c448]" />
              <span>{label}</span>
            </div>
          ),
        )}
      </div>
      <div className="mt-auto p-6">
        <div className="rounded-2xl border border-white/10 bg-white/[0.06] p-4">
          <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-blue-200">
            Keep learning
          </div>
          <div className="mt-2 text-[13px] leading-5 text-blue-100/70">
            Small steps every day create big results.
          </div>
        </div>
        <div className="mt-5 text-[11px] text-blue-200/60">Version 1.0.0</div>
      </div>
    </aside>
  );
}