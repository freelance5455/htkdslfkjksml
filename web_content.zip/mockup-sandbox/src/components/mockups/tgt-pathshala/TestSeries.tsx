import {
  ArrowUpRight,
  BookOpenCheck,
  Brain,
  CalendarDays,
  ChevronRight,
  Clock3,
  FileArchive,
  Flame,
  Layers3,
  Medal,
  PenLine,
  Target,
  Trophy,
} from "lucide-react";

import { ScreenFrame } from "./_shared/AppShell";

const modes = [
  {
    title: "Subject Wise Test",
    description: "Focus one subject at a time",
    meta: "24 tests",
    icon: BookOpenCheck,
    iconColor: "#0d3883",
    iconBackground: "#e7effc",
  },
  {
    title: "Chapter Wise Test",
    description: "Strengthen every topic",
    meta: "36 tests",
    icon: Layers3,
    iconColor: "#b85a18",
    iconBackground: "#fff2df",
  },
  {
    title: "Previous Year Papers",
    description: "Practise with real papers",
    meta: "18 papers",
    icon: FileArchive,
    iconColor: "#277251",
    iconBackground: "#e4f5ec",
  },
  {
    title: "Practice Test",
    description: "A quick daily revision",
    meta: "10 questions",
    icon: PenLine,
    iconColor: "#a53736",
    iconBackground: "#fde9e5",
  },
];

export function TestSeries() {
  return (
    <ScreenFrame
      title="Test Series"
      active="Test Series"
      showBack
      showSearch
    >
      <div
        className="mx-auto w-full max-w-[660px]"
        style={{ fontFamily: "'Trebuchet MS', 'Segoe UI', sans-serif" }}
      >
        <div className="mb-5 flex items-start justify-between">
          <div>
            <div className="mb-1 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.18em] text-[#e7463f]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#e7463f]" />
              Your practice desk
            </div>
            <h1 className="text-[26px] font-black leading-tight tracking-[-0.045em] text-[#12366e]">
              Practice with a plan.
            </h1>
            <p className="mt-1.5 text-[13px] leading-5 text-slate-500">
              Build exam-day confidence, one test at a time.
            </p>
          </div>
          <div className="mt-1 grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-[#f2d88d] bg-[#fff8df] text-[#b27a0b]">
            <Target size={20} strokeWidth={2.1} />
          </div>
        </div>

        <section
          className="relative mb-7 overflow-hidden rounded-[22px] bg-[#0d3883] px-5 py-5 text-white shadow-[0_14px_30px_rgba(13,56,131,0.18)]"
          aria-label="Practice summary"
        >
          <div className="absolute -right-10 -top-12 h-36 w-36 rounded-full border-[18px] border-white/[0.05]" />
          <div className="absolute -bottom-16 right-14 h-32 w-32 rounded-full border-[14px] border-[#f6c448]/[0.09]" />
          <div className="relative">
            <div className="flex items-center justify-between">
              <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-blue-100/75">
                Practice snapshot
              </div>
              <div className="flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-semibold text-[#f7d76a]">
                <Flame size={12} />
                4 day streak
              </div>
            </div>
            <div className="mt-4 grid grid-cols-3 divide-x divide-white/15">
              <div className="pr-3">
                <div className="text-[25px] font-black tracking-[-0.05em]">68</div>
                <div className="mt-0.5 text-[10px] font-medium text-blue-100/70">
                  Total tests
                </div>
              </div>
              <div className="px-3">
                <div className="text-[25px] font-black tracking-[-0.05em]">18</div>
                <div className="mt-0.5 text-[10px] font-medium text-blue-100/70">
                  Attempted
                </div>
              </div>
              <div className="pl-3">
                <div className="text-[25px] font-black tracking-[-0.05em] text-[#f8d76b]">
                  72%
                </div>
                <div className="mt-0.5 text-[10px] font-medium text-blue-100/70">
                  Average score
                </div>
              </div>
            </div>
            <div className="mt-5 flex items-center gap-3">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/15">
                <div className="h-full w-[72%] rounded-full bg-[#f6c448]" />
              </div>
              <span className="text-[10px] font-semibold text-blue-100/80">
                Keep going
              </span>
            </div>
          </div>
        </section>

        <div className="mb-3 flex items-end justify-between">
          <div>
            <div className="text-[18px] font-extrabold tracking-[-0.03em] text-[#12366e]">
              Choose your practice mode
            </div>
            <div className="mt-1 text-[12px] text-slate-500">
              Start where your preparation needs you most.
            </div>
          </div>
          <div className="hidden text-[11px] font-bold text-[#0d3883] sm:block">
            5 ways to practise
          </div>
        </div>

        <section
          className="group relative mb-3 overflow-hidden rounded-[20px] border border-[#d9e3f2] bg-white p-4 shadow-[0_8px_22px_rgba(28,61,103,0.06)]"
          aria-label="Full length test"
        >
          <div className="absolute right-0 top-0 h-full w-1/3 bg-[#f8f3e7]" />
          <div className="relative flex items-center gap-3.5">
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-[15px] bg-[#e7463f] text-white shadow-[0_6px_12px_rgba(231,70,63,0.22)]">
              <Trophy size={23} strokeWidth={2.1} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h2 className="whitespace-nowrap text-[15px] font-extrabold text-[#12366e]">
                  Full Length Test
                </h2>
                <span className="hidden rounded-full bg-[#fff1cf] px-2 py-0.5 text-[8px] font-extrabold uppercase tracking-[0.12em] text-[#9c6a00] sm:inline-block">
                  Exam mode
                </span>
              </div>
              <p className="mt-1 text-[11px] text-slate-500">
                150 questions · 2 hours 30 minutes
              </p>
            </div>
            <div className="relative grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#12366e] text-white">
              <ArrowUpRight size={16} />
            </div>
          </div>
          <div className="relative mt-3 flex items-center gap-2 border-t border-slate-100 pt-3 text-[10px] font-semibold text-slate-500">
            <Clock3 size={13} className="text-[#e7463f]" />
            42 tests available
            <span className="ml-auto flex items-center gap-1 text-[#277251]">
              <Medal size={13} />
              Best score 84%
            </span>
          </div>
        </section>

        <div className="grid grid-cols-2 gap-3">
          {modes.map(
            ({
              title,
              description,
              meta,
              icon: Icon,
              iconColor,
              iconBackground,
            }) => (
              <section
                key={title}
                className="min-h-[148px] rounded-[19px] border border-[#dfe7f1] bg-white p-3.5 shadow-[0_6px_18px_rgba(28,61,103,0.045)]"
              >
                <div className="flex items-start justify-between gap-2">
                  <div
                    className="grid h-10 w-10 place-items-center rounded-[13px]"
                    style={{ backgroundColor: iconBackground, color: iconColor }}
                  >
                    <Icon size={19} strokeWidth={2} />
                  </div>
                  <ChevronRight size={15} className="mt-2 text-slate-300" />
                </div>
                <h2 className="mt-3 text-[13px] font-extrabold leading-[1.25] text-[#173052]">
                  {title}
                </h2>
                <p className="mt-1 text-[10px] leading-4 text-slate-500">
                  {description}
                </p>
                <div className="mt-3 text-[10px] font-bold text-[#0d3883]">
                  {meta}
                </div>
              </section>
            ),
          )}
        </div>

        <div className="mt-5 flex items-center gap-3 rounded-2xl border border-[#dcebdc] bg-[#f0f8f1] px-4 py-3.5">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white text-[#277251] shadow-sm">
            <Brain size={17} />
          </div>
          <div className="min-w-0">
            <div className="text-[12px] font-extrabold text-[#215b43]">
              A small test today keeps the momentum alive.
            </div>
            <div className="mt-0.5 text-[10px] text-[#56816b]">
              Your next 10-question practice test is ready.
            </div>
          </div>
          <CalendarDays size={16} className="ml-auto shrink-0 text-[#277251]" />
        </div>
      </div>
    </ScreenFrame>
  );
}