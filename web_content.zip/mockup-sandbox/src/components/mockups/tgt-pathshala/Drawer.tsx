import { DrawerMenu } from "./_shared/AppShell";

export function Drawer() {
  return (
    <main
      className="relative min-h-[100dvh] overflow-hidden bg-[#edf2f8] font-sans text-[#173052]"
      style={{
        backgroundImage:
          "radial-gradient(circle at 90% 12%, rgba(246,196,72,0.2), transparent 22%), linear-gradient(135deg, #f7f9fc 0%, #e9f0f8 100%)",
      }}
    >
      <section className="pointer-events-none absolute inset-0 hidden min-[720px]:block">
        <div className="absolute right-0 top-0 h-full w-[calc(100%-410px)] bg-[#f8fafc]">
          <div className="mx-auto max-w-[680px] px-16 py-14">
            <div className="flex items-center justify-between">
              <div>
                <div className="h-3 w-28 rounded-full bg-[#d8e2ef]" />
                <div className="mt-3 h-8 w-64 rounded-lg bg-[#cbd9eb]" />
              </div>
              <div className="h-11 w-11 rounded-full border border-[#d9e3ef] bg-white" />
            </div>
            <div className="mt-14 rounded-[28px] bg-[#0d3883] p-8 shadow-xl shadow-[#0d3883]/10">
              <div className="h-3 w-24 rounded-full bg-white/30" />
              <div className="mt-5 h-10 w-72 rounded-lg bg-white/85" />
              <div className="mt-3 h-3 w-52 rounded-full bg-white/35" />
              <div className="mt-8 h-11 w-32 rounded-xl bg-[#f6c448]" />
            </div>
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="h-36 rounded-3xl border border-[#e0e7f0] bg-white" />
              <div className="h-36 rounded-3xl border border-[#e0e7f0] bg-white" />
            </div>
          </div>
        </div>
      </section>

      <div className="absolute inset-0 bg-[#031b47]/25 min-[720px]:bg-[#031b47]/35" />

      <div className="relative z-10 min-h-[100dvh] w-full max-w-[410px] shadow-[18px_0_50px_rgba(4,31,78,0.22)]">
        <DrawerMenu />
      </div>
    </main>
  );
}