import {
  ArrowUpRight,
  BookOpenCheck,
  Check,
  ChevronRight,
  CircleCheck,
  GraduationCap,
  RefreshCw,
  ShieldCheck,
  Target,
  UsersRound,
} from "lucide-react";

import { LogoMark, ScreenFrame } from "./_shared/AppShell";

const trustPoints = [
  {
    icon: BookOpenCheck,
    title: "Quality content",
    copy: "Syllabus-aligned notes, practice sets, and explanations made for TGT preparation.",
    tone: "navy",
  },
  {
    icon: RefreshCw,
    title: "Regularly updated",
    copy: "Fresh questions and current exam guidance keep your preparation on track.",
    tone: "coral",
  },
  {
    icon: GraduationCap,
    title: "Expert guidance",
    copy: "Learn with the clarity and exam insight of teachers who know the journey.",
    tone: "yellow",
  },
  {
    icon: UsersRound,
    title: "Student-first",
    copy: "A focused study experience that respects your time, goals, and confidence.",
    tone: "green",
  },
] as const;

const toneStyles = {
  navy: {
    icon: "bg-[#e9f0ff] text-[#0d3883]",
    line: "bg-[#0d3883]",
  },
  coral: {
    icon: "bg-[#fff0ee] text-[#d84c47]",
    line: "bg-[#e7463f]",
  },
  yellow: {
    icon: "bg-[#fff7dc] text-[#9b7214]",
    line: "bg-[#f6c448]",
  },
  green: {
    icon: "bg-[#e6f5ed] text-[#248050]",
    line: "bg-[#43a76f]",
  },
};

export function AboutUs() {
  return (
    <ScreenFrame title="About Us" active="About Us" showBack>
      <div className="relative overflow-hidden pb-5">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-24 -top-20 h-56 w-56 rounded-full border-[20px] border-[#e8eef8]"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-24 top-[320px] h-40 w-40 rounded-full bg-[#fff4d7]"
        />

        <section className="relative rounded-[28px] border border-[#dbe5f3] bg-white px-5 pb-5 pt-6 shadow-[0_12px_30px_rgba(25,57,103,0.06)]">
          <div className="flex items-start justify-between gap-4">
            <LogoMark />
            <div className="rounded-full bg-[#edf7f0] px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.13em] text-[#257c4c]">
              Built for TGT
            </div>
          </div>

          <div className="mt-7">
            <div className="mb-2 flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.18em] text-[#e7463f]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#e7463f]" />
              About our path
            </div>
            <h1 className="max-w-[310px] text-[29px] font-black leading-[1.08] tracking-[-0.045em] text-[#12366e]">
              Preparation that keeps you moving forward.
            </h1>
            <p className="mt-3 max-w-[330px] text-[13px] leading-[1.7] text-slate-500">
              TGT Pathshala brings your complete TGT exam preparation into one
              clear, dependable study space.
            </p>
          </div>

          <div className="mt-5 flex items-center gap-2.5 rounded-2xl bg-[#f7f9fc] px-3.5 py-3">
            <div className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[#f6c448] text-[#6b5112]">
              <Target size={16} strokeWidth={2.5} />
            </div>
            <div>
              <div className="text-[12px] font-extrabold text-[#173052]">
                One focused goal
              </div>
              <div className="mt-0.5 text-[11px] text-slate-500">
                Help every serious aspirant walk into the exam prepared.
              </div>
            </div>
          </div>
        </section>

        <section className="relative mt-7">
          <div className="mb-3 flex items-end justify-between">
            <div>
              <div className="text-[10px] font-extrabold uppercase tracking-[0.17em] text-[#e7463f]">
                Why students trust us
              </div>
              <h2 className="mt-1.5 text-[20px] font-black tracking-[-0.035em] text-[#12366e]">
                Everything in its place.
              </h2>
            </div>
            <ShieldCheck className="mb-1 text-[#0d3883]" size={22} strokeWidth={2.2} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            {trustPoints.map(({ icon: Icon, title, copy, tone }) => {
              const styles = toneStyles[tone];
              return (
                <div
                  key={title}
                  className="min-h-[164px] rounded-[20px] border border-[#e0e8f2] bg-white p-3.5 shadow-[0_7px_20px_rgba(25,57,103,0.045)]"
                >
                  <div className={`grid h-9 w-9 place-items-center rounded-xl ${styles.icon}`}>
                    <Icon size={18} strokeWidth={2.2} />
                  </div>
                  <div className="mt-3 text-[13px] font-extrabold leading-4 text-[#173052]">
                    {title}
                  </div>
                  <p className="mt-1.5 text-[11px] leading-[1.55] text-slate-500">
                    {copy}
                  </p>
                  <div className={`mt-3 h-1 w-7 rounded-full ${styles.line}`} />
                </div>
              );
            })}
          </div>
        </section>

        <section className="relative mt-7 overflow-hidden rounded-[24px] bg-[#0d3883] px-5 py-5 text-white shadow-[0_14px_28px_rgba(13,56,131,0.18)]">
          <div
            aria-hidden="true"
            className="absolute -right-7 -top-10 h-32 w-32 rounded-full border-[14px] border-white/10"
          />
          <div
            aria-hidden="true"
            className="absolute -bottom-10 left-20 h-24 w-24 rounded-full bg-[#e7463f]/20"
          />
          <div className="relative flex items-start gap-3">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/12 text-[#f6c448]">
              <CircleCheck size={19} strokeWidth={2.3} />
            </div>
            <div>
              <div className="text-[16px] font-extrabold tracking-[-0.02em]">
                A study partner, not just an app.
              </div>
              <p className="mt-2 text-[12px] leading-[1.65] text-blue-100/80">
                From the first chapter to the final revision, we make the next
                right step easier to see.
              </p>
            </div>
          </div>
          <div className="relative mt-5 flex items-center gap-2 text-[11px] font-bold text-[#f6c448]">
            <span className="h-px w-6 bg-[#f6c448]" />
            Your success, our mission
          </div>
        </section>

        <section className="relative mt-7 rounded-[24px] border border-[#eadfbe] bg-[#fffaf0] p-5">
          <div className="flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.17em] text-[#9a741e]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#f6c448]" />
            Our promise to you
          </div>
          <p className="mt-3 text-[17px] font-extrabold leading-[1.3] tracking-[-0.025em] text-[#173052]">
            Clear lessons. Honest guidance. Consistent progress.
          </p>
          <div className="mt-4 space-y-2.5">
            {[
              "Study material that follows the exam, not the noise.",
              "Simple progress cues that help you keep going.",
              "A community that understands the TGT path.",
            ].map((item) => (
              <div key={item} className="flex items-start gap-2.5 text-[11px] leading-5 text-slate-600">
                <span className="mt-1 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-[#e6f5ed] text-[#248050]">
                  <Check size={11} strokeWidth={3} />
                </span>
                <span>{item}</span>
              </div>
            ))}
          </div>
          <div className="mt-5 flex items-center justify-between border-t border-[#efdfb9] pt-4 text-[11px] font-bold text-[#0d3883]">
            <span>Let&apos;s prepare with purpose.</span>
            <ArrowUpRight size={16} />
          </div>
        </section>

        <div className="mt-6 flex items-center justify-center gap-1.5 text-[10px] font-semibold text-slate-400">
          <span>Made for TGT aspirants</span>
          <ChevronRight size={12} />
          <span>Made with care</span>
        </div>
      </div>
    </ScreenFrame>
  );
}