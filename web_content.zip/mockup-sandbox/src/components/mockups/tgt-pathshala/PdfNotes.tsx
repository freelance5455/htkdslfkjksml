import {
  Bookmark,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Download,
  FileText,
  FolderOpen,
  History,
  Map,
  Scale,
  SlidersHorizontal,
} from "lucide-react";

import { ScreenFrame } from "./_shared/AppShell";

type Note = {
  subject: string;
  title: string;
  detail: string;
  pages: string;
  size: string;
  accent: string;
  tint: string;
  icon: typeof History;
  saved?: boolean;
};

const filters = ["All notes", "History", "Geography", "Polity"];

const notes: Note[] = [
  {
    subject: "HISTORY",
    title: "Modern India — Quick Revision",
    detail: "Freedom movement, acts and important years",
    pages: "42 pages",
    size: "2.4 MB",
    accent: "#c7463f",
    tint: "#fff1ef",
    icon: History,
    saved: true,
  },
  {
    subject: "GEOGRAPHY",
    title: "Indian Geography Essentials",
    detail: "Rivers, soils, climate and natural resources",
    pages: "36 pages",
    size: "1.8 MB",
    accent: "#2b866a",
    tint: "#eaf7f0",
    icon: Map,
  },
  {
    subject: "POLITY",
    title: "Constitution & Governance",
    detail: "Articles, schedules and landmark amendments",
    pages: "28 pages",
    size: "1.6 MB",
    accent: "#8a6418",
    tint: "#fff7df",
    icon: Scale,
  },
];

function NoteCard({ note }: { note: Note }) {
  const Icon = note.icon;

  return (
    <article className="relative overflow-hidden rounded-[22px] border border-[#dce5ef] bg-white p-4 shadow-[0_8px_24px_rgba(24,56,98,0.055)]">
      <div
        aria-hidden="true"
        className="absolute bottom-0 left-0 top-0 w-1"
        style={{ backgroundColor: note.accent }}
      />
      <div className="flex gap-3.5">
        <div
          className="grid h-[52px] w-[52px] shrink-0 place-items-center rounded-[16px]"
          style={{ backgroundColor: note.tint }}
        >
          <Icon size={23} strokeWidth={1.8} style={{ color: note.accent }} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div
                className="text-[9px] font-extrabold tracking-[0.14em]"
                style={{ color: note.accent }}
              >
                {note.subject}
              </div>
              <h2 className="mt-1 text-[15px] font-extrabold leading-[1.25] tracking-[-0.02em] text-[#173052]">
                {note.title}
              </h2>
            </div>
            <div
              aria-label={note.saved ? "Saved note" : "Save note"}
              className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#f5f8fc] text-[#73859b]"
            >
              <Bookmark
                size={14}
                fill={note.saved ? "#f6c448" : "none"}
                strokeWidth={note.saved ? 2.5 : 1.8}
                style={note.saved ? { color: "#f6c448" } : undefined}
              />
            </div>
          </div>
          <p className="mt-1.5 truncate text-[11px] text-slate-500">{note.detail}</p>
          <div className="mt-3 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 text-[10px] font-medium text-slate-400">
              <span className="flex items-center gap-1">
                <FileText size={12} />
                {note.pages}
              </span>
              <span className="h-3 w-px bg-slate-200" />
              <span>{note.size}</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-bold text-[#0d3883]">
              <span>Download</span>
              <Download size={14} strokeWidth={2.3} />
            </div>
          </div>
        </div>
      </div>
    </article>
  );
}

export function PdfNotes() {
  return (
    <ScreenFrame title="PDF Notes" active="PDF Notes" showBack showSearch>
      <div className="mx-auto w-full max-w-[590px]">
        <section className="relative overflow-hidden rounded-[24px] bg-[#eaf1fa] px-5 py-5">
          <div
            aria-hidden="true"
            className="absolute -right-8 -top-12 h-32 w-32 rounded-full border-[18px] border-[#dbe7f5]"
          />
          <div
            aria-hidden="true"
            className="absolute bottom-[-38px] right-[58px] h-20 w-20 rounded-full bg-[#f6c448]/25"
          />
          <div className="relative flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#e7463f]">
                <FolderOpen size={12} strokeWidth={2.6} />
                Study library
              </div>
              <h1 className="mt-2 text-[24px] font-black leading-[1.08] tracking-[-0.045em] text-[#12366e]">
                Notes that make
                <br />
                revision lighter.
              </h1>
              <p className="mt-2 max-w-[260px] text-[11px] leading-[1.55] text-[#5e7590]">
                Download concise, exam-ready material for your next focused study session.
              </p>
            </div>
            <div className="relative mt-1 grid h-[62px] w-[58px] shrink-0 place-items-center rounded-[18px] border border-white/80 bg-white/75 shadow-sm">
              <div className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#f6c448]" />
              <FileText size={29} strokeWidth={1.5} className="text-[#0d3883]" />
              <div className="absolute bottom-2 text-[7px] font-black tracking-[0.12em] text-[#e7463f]">
                PDF
              </div>
            </div>
          </div>
        </section>

        <div className="mt-6 flex items-center justify-between">
          <div>
            <div className="text-[18px] font-extrabold tracking-[-0.03em] text-[#173052]">
              Browse notes
            </div>
            <div className="mt-1 flex items-center gap-1.5 text-[10px] text-slate-400">
              <CheckCircle2 size={12} className="text-[#3d9b73]" />
              12 handpicked resources for TGT preparation
            </div>
          </div>
          <div className="grid h-9 w-9 place-items-center rounded-xl border border-[#dce5ef] bg-white text-[#0d3883]">
            <SlidersHorizontal size={16} />
          </div>
        </div>

        <div className="-mx-1 mt-4 flex gap-2 overflow-hidden px-1 pb-1">
          {filters.map((filter, index) => (
            <div
              key={filter}
              className={`shrink-0 rounded-full border px-3.5 py-2 text-[11px] font-bold ${
                index === 0
                  ? "border-[#0d3883] bg-[#0d3883] text-white shadow-[0_5px_12px_rgba(13,56,131,0.18)]"
                  : "border-[#dce5ef] bg-white text-[#6c7e93]"
              }`}
            >
              {filter}
            </div>
          ))}
        </div>

        <div className="mt-4 space-y-3">
          {notes.map((note) => (
            <NoteCard key={note.title} note={note} />
          ))}
        </div>

        <div className="mt-4 flex items-center justify-between rounded-[18px] border border-dashed border-[#cddbea] bg-[#f8fbfe] px-4 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="grid h-8 w-8 place-items-center rounded-full bg-[#e8f1fb] text-[#0d3883]">
              <Clock3 size={15} />
            </div>
            <div>
              <div className="text-[11px] font-bold text-[#173052]">More notes coming soon</div>
              <div className="mt-0.5 text-[9px] text-slate-400">Updated every week</div>
            </div>
          </div>
          <ChevronRight size={16} className="text-slate-300" />
        </div>
      </div>
    </ScreenFrame>
  );
}