import { LogoMark } from "./_shared/AppShell";

export function Splash() {
  return (
    <main className="min-h-[100dvh] overflow-hidden bg-[#f7f3eb] font-sans text-[#173052]">
      <div className="relative mx-auto flex min-h-[100dvh] w-full max-w-[390px] flex-col px-7 pb-8 pt-7">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-24 -top-20 h-64 w-64 rounded-full border-[26px] border-[#e7463f]/[0.08]"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-24 top-[31%] h-48 w-48 rounded-full border border-[#0e3b82]/[0.09]"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute bottom-28 right-[-42px] h-36 w-36 rounded-full border-[12px] border-[#f1c64d]/[0.18]"
        />

        <header className="relative flex items-center justify-between">
          <LogoMark />
          <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.16em] text-[#728096]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#5caa70]" />
            Study mode
          </div>
        </header>

        <section className="relative flex flex-1 flex-col items-center justify-center pb-3 pt-10 text-center">
          <div className="relative mb-8">
            <div
              aria-hidden="true"
              className="absolute -inset-5 rounded-[2.2rem] border border-[#0e3b82]/[0.08] rotate-6"
            />
            <div
              aria-hidden="true"
              className="absolute -inset-3 rounded-[1.8rem] border border-[#e7463f]/[0.12] -rotate-6"
            />
            <div className="relative grid h-[108px] w-[108px] place-items-center rounded-[1.8rem] border-[5px] border-[#0e3b82] bg-[#fbfaf6] shadow-[0_14px_28px_rgba(14,59,130,0.12)]">
              <div className="absolute inset-[8px] rounded-[1.25rem] border-2 border-[#e7463f]" />
              <div className="relative -mt-1 text-[25px] font-black leading-none tracking-[-0.08em] text-[#0e3b82]">
                TGT
              </div>
              <div className="absolute bottom-[22px] text-[7px] font-extrabold tracking-[0.2em] text-[#e7463f]">
                PATHSHALA
              </div>
              <div className="absolute bottom-[12px] h-[3px] w-7 rounded-full bg-[#f1c64d]" />
            </div>
          </div>

          <div className="mb-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-[#e7463f]">
            TGT preparation, made clear
          </div>
          <h1 className="max-w-[320px] text-[36px] font-black leading-[1.02] tracking-[-0.055em] text-[#12366e]">
            Your preparation.
            <br />
            <span className="text-[#e7463f]">Our purpose.</span>
          </h1>
          <p className="mt-5 max-w-[285px] text-[14px] leading-6 text-[#65748a]">
            Subject notes, practice tests, and revision plans for every TGT
            aspirant.
          </p>

          <div className="mt-11 w-full max-w-[286px]">
            <div className="mb-3 flex items-center justify-between text-left">
              <span className="text-[11px] font-bold text-[#49617d]">
                Preparing your study space
              </span>
              <span className="font-mono text-[11px] font-bold text-[#0e3b82]">
                72%
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-[#e3e7e7]">
              <div className="h-full w-[72%] rounded-full bg-[#5caa70]" />
            </div>
            <div className="mt-3 flex items-center justify-center gap-2 text-[10px] font-medium text-[#8a96a5]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#5caa70]" />
              <span>One focused session at a time</span>
            </div>
          </div>
        </section>

        <footer className="relative">
          <div className="flex items-center justify-between border-t border-[#dfe2df] pt-4 text-[10px] font-semibold text-[#8190a0]">
            <span>Built for TGT aspirants</span>
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-[#f1c64d]" />
              <span>Learn · Revise · Succeed</span>
            </div>
          </div>
        </footer>
      </div>
    </main>
  );
}