/*
 * Server engine (page side): talks to sw.js, which serves the stored ZIP as a real website.
 * If service workers are unavailable here (for example when the page is opened from file://),
 * open() returns null and the app falls back to the rewrite engine in preview.js.
 */
const ServerSession = (() => {
  let regPromise = null;

  function supported() {
    return 'serviceWorker' in navigator && window.isSecureContext && /^https?:$/.test(location.protocol);
  }

  function timeout(ms, value) { return new Promise(r => setTimeout(() => r(value), ms)); }

  function getReg() {
    if (!supported()) return Promise.resolve(null);
    if (!regPromise) {
      regPromise = (async () => {
        try {
          await navigator.serviceWorker.register('sw.js');
          const reg = await Promise.race([navigator.serviceWorker.ready, timeout(5000, null)]);
          if (!reg) return null;
          if (!navigator.serviceWorker.controller) {
            await Promise.race([
              new Promise(r => navigator.serviceWorker.addEventListener('controllerchange', r, { once: true })),
              timeout(2000),
            ]);
          }
          return reg;
        } catch (err) {
          console.warn('Service worker unavailable, using fallback preview', err);
          return null;
        }
      })();
    }
    return regPromise;
  }

  function setActive(reg, id) {
    return new Promise(resolve => {
      const worker = reg.active || navigator.serviceWorker.controller;
      if (!worker) return resolve(false);
      const ch = new MessageChannel();
      ch.port1.onmessage = () => resolve(true);
      setTimeout(() => resolve(false), 2000);
      worker.postMessage({ type: 'active', id }, [ch.port2]);
    });
  }

  async function ping(pre) {
    try {
      const r = await Promise.race([fetch(pre + '__ping__', { cache: 'no-store' }), timeout(2500, null)]);
      return !!r && r.ok && (await r.text()) === 'vault-ok';
    } catch (err) { return false; }
  }

  class Session {
    constructor(site, reg, pre, index) {
      this.server = true;
      this.site = site;
      this.reg = reg;
      this.pre = pre;
      this.index = index;
    }

    static async open(site) {
      const reg = await getReg();
      if (!reg) return null;
      const pre = new URL(reg.scope).pathname + '__vault__/';
      if (!(await ping(pre))) return null;
      const zip = await JSZip.loadAsync(site.zip);
      const found = SiteSession.find(zip);
      if (!found) return null;
      if (!(await setActive(reg, site.id))) return null;
      return new Session(site, reg, pre, found.path.slice(found.root.length));
    }

    /** Warm up in the background so the first preview is instant. Also clears a stale "open site". */
    static async init() {
      const reg = await getReg();
      if (reg) await setActive(reg, null);
    }

    page(path) {
      return this.pre + encodeURIComponent(this.site.id) + '/' +
        String(path || '').split('/').map(encodeURIComponent).join('/');
    }

    dispose() {
      setActive(this.reg, null);
    }
  }

  return { open: s => Session.open(s), init: () => Session.init() };
})();
