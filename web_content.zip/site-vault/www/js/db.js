/* IndexedDB storage: everything stays on the device, no server. */
const DB = (() => {
  const NAME = 'site-vault', STORE = 'sites';
  let dbp;

  function open() {
    if (dbp) return dbp;
    dbp = new Promise((resolve, reject) => {
      const req = indexedDB.open(NAME, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: 'id' });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbp;
  }

  async function tx(mode, fn) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const t = db.transaction(STORE, mode);
      const r = fn(t.objectStore(STORE));
      t.oncomplete = () => resolve(r && r.result);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
  }

  return {
    all: async () => (await tx('readonly', s => s.getAll())).sort((a, b) => b.created - a.created),
    get: id => tx('readonly', s => s.get(id)),
    add: site => tx('readwrite', s => s.put(site)),
    remove: id => tx('readwrite', s => s.delete(id)),
  };
})();
