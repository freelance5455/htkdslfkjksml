/*
 * Preview engine: unzips a website in memory and turns every file into a blob: URL,
 * rewriting paths inside HTML and CSS so the site runs fully offline inside an iframe.
 * A small injected script also fixes fetch/XHR, dynamically-added images/scripts and
 * links between pages of the same site.
 */
const MIME = {
  html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript', mjs: 'text/javascript',
  json: 'application/json', txt: 'text/plain', xml: 'application/xml', svg: 'image/svg+xml',
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp',
  ico: 'image/x-icon', avif: 'image/avif', bmp: 'image/bmp',
  woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf', eot: 'application/vnd.ms-fontobject',
  mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', mp4: 'video/mp4', webm: 'video/webm',
  pdf: 'application/pdf', wasm: 'application/wasm', csv: 'text/csv',
};
const SKIP_IN_MAP = new Set(['mp4', 'webm', 'mp3', 'wav', 'ogg', 'mov', 'avi', 'mkv', 'pdf', 'zip']);
const EXTERNAL = /^(?:[a-z][a-z0-9+.-]*:|\/\/|#)/i;

/** Resolve `ref` (as written in file `from`) to a path relative to the site root, or null. */
function resolvePath(from, ref) {
  if (!ref) return null;
  ref = ref.trim();
  if (!ref || EXTERNAL.test(ref)) return null;
  ref = ref.split('#')[0].split('?')[0];
  try { ref = decodeURIComponent(ref); } catch (e) { /* keep as is */ }
  const parts = ref.startsWith('/') ? [] : from.split('/').slice(0, -1);
  for (const seg of ref.split('/')) {
    if (seg === '..') parts.pop();
    else if (seg && seg !== '.') parts.push(seg);
  }
  return parts.length ? parts.join('/') : null;
}

const SHIM = `(function(){
var M=__MAP__,H=__HTML__,D=__DIR__;
function path(u){
  if(!u||typeof u!=='string')return null;
  if(/^([a-z][a-z0-9+.-]*:|\\/\\/|#)/i.test(u))return null;
  u=u.split('#')[0].split('?')[0];
  try{u=decodeURIComponent(u)}catch(e){}
  var p=u.charAt(0)==='/'?[]:D.split('/').filter(Boolean);
  u.split('/').forEach(function(s){if(s==='..')p.pop();else if(s&&s!=='.')p.push(s)});
  return p.join('/');
}
function res(u){var p=path(u);return p&&M[p]||null}
var f=window.fetch;
if(f)window.fetch=function(i,o){if(typeof i==='string'){var r=res(i);if(r)i=r}return f.call(this,i,o)};
var xo=XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open=function(m,u){var r=res(u);if(r)arguments[1]=r;return xo.apply(this,arguments)};
var ATTRS=['src','poster','data-src'];
function fix(el){
  if(!el||el.nodeType!==1)return;
  ATTRS.forEach(function(a){var v=el.getAttribute&&el.getAttribute(a);var r=v&&res(v);if(r&&r!==v)el.setAttribute(a,r)});
  if(el.tagName==='LINK'){var h=el.getAttribute('href'),r2=h&&res(h);if(r2&&r2!==h)el.setAttribute('href',r2)}
  if(el.children)for(var i=0;i<el.children.length;i++)fix(el.children[i]);
}
new MutationObserver(function(list){list.forEach(function(m){
  if(m.type==='attributes')fix(m.target);else m.addedNodes.forEach(fix);
})}).observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['src','poster','data-src','href']});
document.addEventListener('click',function(e){
  var a=e.target.closest&&e.target.closest('a[href]');if(!a||e.defaultPrevented)return;
  var href=a.getAttribute('href');
  if(!href||href.charAt(0)==='#')return;
  var p=path(href);
  if(p&&H.indexOf(p)>-1){e.preventDefault();parent.postMessage({vaultNav:p},'*')}
},true);
})();`;

/* Pages opened straight from disk (file://) have an opaque origin, where the browser
   refuses blob: URLs for sub-files (CSS, images, scripts). Use data: URLs there. */
const OPAQUE_ORIGIN = location.protocol === 'file:' || location.origin === 'null';
function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

class SiteSession {
  constructor(zip, root, indexPath) {
    this.root = root;
    this.index = indexPath;
    this.files = {};
    this.lower = {};
    this.cache = new Map();
    this.urls = [];
    zip.forEach((p, entry) => {
      if (entry.dir || p.startsWith('__MACOSX/') || p.endsWith('.DS_Store') || !p.startsWith(root)) return;
      const rel = p.slice(root.length);
      this.files[rel] = entry;
      this.lower[rel.toLowerCase()] = rel;
    });
  }

  /** Find the shallowest index.html. Returns {root, path} or null. */
  static find(zip) {
    let best = null;
    zip.forEach((p, entry) => {
      if (entry.dir || p.startsWith('__MACOSX/')) return;
      if (/(^|\/)index\.html?$/i.test(p)) {
        const depth = p.split('/').length;
        if (!best || depth < best.depth) best = { depth, root: p.slice(0, p.lastIndexOf('/') + 1), path: p };
      }
    });
    return best;
  }

  static async open(blob) {
    const zip = await JSZip.loadAsync(blob);
    const found = SiteSession.find(zip);
    if (!found) return null;
    return new SiteSession(zip, found.root, found.path.slice(found.root.length));
  }

  lookup(path) {
    if (path in this.files) return path;
    return this.lower[path.toLowerCase()] || null;
  }

  /** blob: URL for a file in the zip (CSS is rewritten first). */
  url(path, stack) {
    const key = this.lookup(path);
    if (!key || stack.includes(key)) return Promise.resolve(null);
    if (!this.cache.has(key)) this.cache.set(key, this._make(key, stack));
    return this.cache.get(key);
  }

  async _make(key, stack) {
    const ext = key.split('.').pop().toLowerCase();
    const entry = this.files[key];
    let blob;
    if (ext === 'css') {
      const css = await this.cssText(await entry.async('string'), key, stack);
      blob = new Blob([css], { type: MIME.css });
    } else {
      blob = new Blob([await entry.async('arraybuffer')], { type: MIME[ext] || 'application/octet-stream' });
    }
    if (OPAQUE_ORIGIN) return blobToDataUrl(blob);
    const u = URL.createObjectURL(blob);
    this.urls.push(u);
    return u;
  }

  /** blob/data URL for a JS file loaded as an ES module: relative imports are rewritten too. */
  modUrl(path, stack) {
    const key = this.lookup(path);
    if (!key || stack.includes(key)) return Promise.resolve(null);
    if (!this.mcache) this.mcache = new Map();
    if (!this.mcache.has(key)) this.mcache.set(key, this._makeModule(key, stack));
    return this.mcache.get(key);
  }

  async _makeModule(key, stack) {
    const st = [...stack, key];
    const text = await this.files[key].async('string');
    // import x from './a.js' | import './a.js' | export * from './a.js' | import('./a.js')
    const re = /(\bfrom\s*|\bimport\s*\(?\s*)(['"])([^'"\n]+)\2/g;
    const matches = [...text.matchAll(re)];
    const urls = await Promise.all(matches.map(m => {
      const p = resolvePath(key, m[3]);
      return p && /\.m?js$/i.test(p) ? this.modUrl(p, st) : null;
    }));
    let out = '', last = 0;
    matches.forEach((m, i) => {
      out += text.slice(last, m.index);
      out += urls[i] ? `${m[1]}${m[2]}${urls[i]}${m[2]}` : m[0];
      last = m.index + m[0].length;
    });
    out += text.slice(last);
    const blob = new Blob([out], { type: MIME.js });
    if (OPAQUE_ORIGIN) return blobToDataUrl(blob);
    const u = URL.createObjectURL(blob);
    this.urls.push(u);
    return u;
  }

  /** Rewrite url(...) and @import in CSS text. */
  async cssText(text, from, stack) {
    const st = [...stack, from];
    const re = /url\(\s*(['"]?)([^'")]+)\1\s*\)|@import\s+(['"])([^'"]+)\3/g;
    const matches = [...text.matchAll(re)];
    const urls = await Promise.all(matches.map(m => {
      const p = resolvePath(from, m[2] || m[4]);
      return p ? this.url(p, st) : null;
    }));
    let out = '', last = 0;
    matches.forEach((m, i) => {
      out += text.slice(last, m.index);
      const u = urls[i];
      out += u ? (m[2] !== undefined ? `url("${u}")` : `@import "${u}"`) : m[0];
      last = m.index + m[0].length;
    });
    return out + text.slice(last);
  }

  /** Build a runnable page for an HTML file. Returns a blob: URL. */
  async page(path) {
    const key = this.lookup(path);
    if (!key) throw new Error('Page not found: ' + path);
    const html = await this.files[key].async('string');
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const jobs = [];

    doc.querySelectorAll('base').forEach(b => b.remove());
    // A site's own Content-Security-Policy would block our blob:/data: files and leave the page blank.
    doc.querySelectorAll('meta[http-equiv]').forEach(m => {
      if (/content-security-policy/i.test(m.getAttribute('http-equiv'))) m.remove();
    });

    const swap = (el, attr) => {
      const p = resolvePath(key, el.getAttribute(attr));
      if (p) jobs.push(this.url(p, []).then(u => { if (u) el.setAttribute(attr, u); }));
    };
    doc.querySelectorAll('script[type="module"][src]').forEach(el => {
      const p = resolvePath(key, el.getAttribute('src'));
      if (p) jobs.push(this.modUrl(p, []).then(u => { if (u) el.setAttribute('src', u); }));
      el.setAttribute('data-vault', '1');
    });
    doc.querySelectorAll('img[src],script:not([data-vault])[src],source[src],audio[src],video[src],track[src],embed[src],input[src]')
      .forEach(el => swap(el, 'src'));
    doc.querySelectorAll('link[href]').forEach(el => swap(el, 'href'));
    doc.querySelectorAll('video[poster]').forEach(el => swap(el, 'poster'));
    doc.querySelectorAll('[data-src]').forEach(el => swap(el, 'data-src'));

    doc.querySelectorAll('img[srcset],source[srcset]').forEach(el => {
      const items = el.getAttribute('srcset').split(',').map(s => s.trim()).filter(Boolean);
      jobs.push(Promise.all(items.map(async item => {
        const [ref, ...rest] = item.split(/\s+/);
        const p = resolvePath(key, ref);
        const u = p && await this.url(p, []);
        return [u || ref, ...rest].join(' ');
      })).then(list => el.setAttribute('srcset', list.join(', '))));
    });

    doc.querySelectorAll('script[type="module"]:not([src])').forEach(el => {
      jobs.push((async () => {
        const text = el.textContent;
        const re = /(\bfrom\s*|\bimport\s*\(?\s*)(['"])([^'"\n]+)\2/g;
        const ms = [...text.matchAll(re)];
        const us = await Promise.all(ms.map(m => { const q = resolvePath(key, m[3]); return q && /\.m?js$/i.test(q) ? this.modUrl(q, []) : null; }));
        let out = '', last = 0;
        ms.forEach((m, i) => { out += text.slice(last, m.index) + (us[i] ? `${m[1]}${m[2]}${us[i]}${m[2]}` : m[0]); last = m.index + m[0].length; });
        el.textContent = out + text.slice(last);
      })());
    });

    doc.querySelectorAll('style').forEach(el =>
      jobs.push(this.cssText(el.textContent, key, []).then(t => { el.textContent = t; })));
    doc.querySelectorAll('[style*="url("]').forEach(el =>
      jobs.push(this.cssText(el.getAttribute('style'), key, []).then(t => el.setAttribute('style', t))));

    await Promise.all(jobs);

    // Map of path -> blob URL for scripts that load files dynamically (fetch, XHR, new Image()).
    const map = {};
    if (doc.querySelector('script')) {
      await Promise.all(Object.keys(this.files).map(async f => {
        const ext = f.split('.').pop().toLowerCase();
        if (/^html?$/.test(ext) || SKIP_IN_MAP.has(ext)) return;
        const u = await this.url(f, []);
        if (u) map[f] = u;
      }));
    }
    const htmlPaths = Object.keys(this.files).filter(f => /\.html?$/i.test(f));
    const dir = key.includes('/') ? key.slice(0, key.lastIndexOf('/')) : '';
    const safe = v => JSON.stringify(v).replace(/</g, '\\u003c');
    const shim = doc.createElement('script');
    shim.textContent = SHIM.replace('__MAP__', () => safe(map)).replace('__HTML__', () => safe(htmlPaths)).replace('__DIR__', () => safe(dir));
    (doc.head || doc.documentElement).prepend(shim);

    const out = '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
    const url = URL.createObjectURL(new Blob([out], { type: 'text/html' }));
    this.urls.push(url);
    return url;
  }

  dispose() {
    this.urls.forEach(u => URL.revokeObjectURL(u));
    this.urls = [];
    this.cache.clear();
    if (this.mcache) this.mcache.clear();
  }
}

if (typeof module !== 'undefined') module.exports = { SiteSession, resolvePath };
