const $ = s => document.querySelector(s);

/* ---------- helpers ---------- */
function toast(msg, type = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

function readWithProgress(file, onProgress) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onprogress = e => e.lengthComputable && onProgress(e.loaded / e.total);
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsArrayBuffer(file);
  });
}

function setupDropzone(zone, input, onFile) {
  input.addEventListener('change', () => { const f = input.files && input.files[0]; if (f) onFile(f); });
  ['dragenter', 'dragover'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove('over'); }));
  zone.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) onFile(f); });
}

/* ---------- theme ---------- */
(function theme() {
  let saved = null;
  try { saved = localStorage.getItem('sv-theme'); } catch (e) {}
  const dark = saved ? saved === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  $('#themeBtn').addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('sv-theme', next); } catch (e) {}
  });
})();

/* ---------- add website flow ---------- */
let pendingZip = null, pendingThumb = null, thumbUrl = null;

function showProgress(pct) {
  $('#progress').hidden = false;
  $('#progressBar').style.width = Math.round(pct * 100) + '%';
}

/* Optional website link (e.g. a Netlify URL).
   Returns '' when empty, the cleaned https URL when valid, or null when invalid. */
function cleanLink(raw) {
  raw = (raw || '').trim();
  if (!raw) return '';
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(raw)) raw = 'https://' + raw;   // "my-site.netlify.app" works too
  try {
    const u = new URL(raw);
    if (!/^https?:$/.test(u.protocol) || !u.hostname.includes('.')) return null;
    return u.href;
  } catch (e) { return null; }
}

function updateLinkState() {
  const bad = cleanLink($('#linkInput').value) === null;
  $('#linkInput').classList.toggle('invalid', bad);
  $('#linkHint').classList.toggle('err', bad);
  $('#linkHint').textContent = bad
    ? 'This link does not look right. Fix it or clear it to save without a link.'
    : 'Paste your Netlify (or any) website link. You can leave this empty.';
  return !bad;
}

function updateSave() {
  // The link is optional: an empty link never blocks saving, only a malformed one does.
  const linkOk = cleanLink($('#linkInput').value) !== null;
  $('#saveBtn').disabled = !(pendingZip && $('#nameInput').value.trim() && linkOk);
}

function resetForm() {
  pendingZip = pendingThumb = null;
  if (thumbUrl) URL.revokeObjectURL(thumbUrl);
  thumbUrl = null;
  $('#thumbPreview').hidden = true;
  $('#thumbText').hidden = false;
  $('#thumbDrop').classList.remove('done');
  $('#zipDrop').classList.remove('done');
  $('#zipText').innerHTML = '<strong>Drop a ZIP, HTML files or a folder</strong><br>or tap to browse';
  $('#progress').hidden = true;
  $('#detailsStep').hidden = true;
  $('#nameInput').value = '';
  $('#linkInput').value = '';
  updateLinkState();
  updateSave();
}

async function handleZip(file) {
  if (!file) return;
  if (file.size === 0) return toast('That file is empty', 'error');
  showProgress(0);
  try {
    const buf = await readWithProgress(file, p => showProgress(p * 0.8));
    // Check the real file signature ("PK"), not the name: Android file pickers
    // often return names without ".zip" (e.g. from Downloads or Drive).
    const sig = new Uint8Array(buf, 0, Math.min(4, buf.byteLength));
    if (!(sig[0] === 0x50 && sig[1] === 0x4B)) {
      $('#progress').hidden = true;
      return toast('That is not a ZIP file', 'error');
    }
    const zip = await JSZip.loadAsync(buf);
    showProgress(0.95);
    if (!SiteSession.find(zip)) {
      $('#progress').hidden = true;
      return toast('No index.html found in this ZIP', 'error');
    }
    showProgress(1);
    pendingZip = new Blob([buf], { type: 'application/zip' });
    $('#zipDrop').classList.add('done');
    $('#zipText').textContent = '✅ ' + (file.name || 'website.zip');
    $('#detailsStep').hidden = false;
    if (!$('#nameInput').value) $('#nameInput').value = (file.name || 'My website').replace(/\.zip$/i, '');
    updateSave();
    setTimeout(() => ($('#progress').hidden = true), 600);
  } catch (err) {
    console.error(err);
    $('#progress').hidden = true;
    toast('That ZIP could not be read', 'error');
  }
}

/* ---- any kind of website input: ZIP, single HTML, loose files, or a folder ---- */
const JUNK = /(^|\/)(\.DS_Store|Thumbs\.db|desktop\.ini)$/i;

async function isZipFile(file) {
  try {
    const head = new Uint8Array(await readWithProgress(file.slice(0, 4), () => {}));
    return head.length >= 2 && head[0] === 0x50 && head[1] === 0x4B;
  } catch (err) { return false; }
}

async function filesFromDrop(dt) {
  // Must read the entries synchronously, before any await, or the browser empties the drop.
  const entries = dt.items ? [...dt.items].map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean) : [];
  if (!entries.length) return [...dt.files].map(f => ({ file: f, path: f.name }));
  const out = [];
  async function walk(en, base) {
    if (en.isFile) {
      const file = await new Promise((res, rej) => en.file(res, rej));
      out.push({ file, path: base + en.name });
    } else if (en.isDirectory) {
      const reader = en.createReader();
      let batch;
      do {
        batch = await new Promise((res, rej) => reader.readEntries(res, rej));
        for (const child of batch) await walk(child, base + en.name + '/');
      } while (batch.length);
    }
  }
  for (const en of entries) await walk(en, '');
  return out;
}

function filesFromInput(input) {
  return [...(input.files || [])].map(f => ({ file: f, path: f.webkitRelativePath || f.name }));
}

async function handleFiles(list) {
  list = list.filter(x => x.file && !JUNK.test(x.path) && !x.path.startsWith('__MACOSX/'));
  if (!list.length) return toast('No files selected', 'error');
  if (list.length === 1 && await isZipFile(list[0].file)) return handleZip(list[0].file);

  showProgress(0.02);
  try {
    const zip = new JSZip();
    const byPath = new Map();
    for (const { file, path } of list) {
      const p = path.replace(/^\/+/, '');
      if (!p || byPath.has(p)) continue;
      byPath.set(p, file);
      zip.file(p, file);
    }
    let startPage = null;
    let found = SiteSession.find(zip);
    if (found) startPage = found.path.split('/').pop();
    else {
      // No index.html: use the HTML file closest to the top as the start page.
      const START = ['home', 'main', 'default', 'start', 'welcome', 'landing', 'app', 'site', 'page'];
      const rank = p => { const i = START.indexOf(p.split('/').pop().replace(/\.html?$/i, '').toLowerCase()); return i < 0 ? 99 : i; };
      const htmls = [...byPath.keys()].filter(p => /\.html?$/i.test(p))
        .sort((a, b) => a.split('/').length - b.split('/').length || rank(a) - rank(b) || a.localeCompare(b));
      if (!htmls.length) {
        $('#progress').hidden = true;
        return toast('No HTML file found. Add an .html file (with its CSS, JS and images), or a ZIP.', 'error');
      }
      const pick = htmls[0];
      zip.file(pick.slice(0, pick.lastIndexOf('/') + 1) + 'index.html', byPath.get(pick));
      startPage = pick.split('/').pop();
    }
    const blob = await zip.generateAsync(
      { type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 3 } },
      m => showProgress(0.05 + (m.percent / 100) * 0.9));
    showProgress(1);
    pendingZip = new Blob([blob], { type: 'application/zip' });

    // Suggested name: the folder name, else the HTML file name, else a default.
    const firsts = new Set([...byPath.keys()].map(p => (p.includes('/') ? p.split('/')[0] : '')));
    let name = firsts.size === 1 && [...firsts][0] ? [...firsts][0] : '';
    if (!name && !/^index\.html?$/i.test(startPage)) name = startPage.replace(/\.html?$/i, '');
    $('#zipDrop').classList.add('done');
    $('#zipText').textContent = `✅ ${byPath.size} file${byPath.size === 1 ? '' : 's'} · start page: ${startPage}`;
    $('#detailsStep').hidden = false;
    if (!$('#nameInput').value) $('#nameInput').value = name || 'My website';
    updateSave();
    setTimeout(() => ($('#progress').hidden = true), 600);
  } catch (err) {
    console.error(err);
    $('#progress').hidden = true;
    toast('Those files could not be added', 'error');
  }
}

function handleThumb(file) {
  if (!file.type.startsWith('image/')) return toast('Thumbnail must be an image', 'error');
  pendingThumb = file;
  if (thumbUrl) URL.revokeObjectURL(thumbUrl);
  thumbUrl = URL.createObjectURL(file);
  $('#thumbPreview').src = thumbUrl;
  $('#thumbPreview').hidden = false;
  $('#thumbText').hidden = true;
  $('#thumbDrop').classList.add('done');
}

(function zipPicker() {
  const zone = $('#zipDrop'), input = $('#zipInput'), folder = $('#folderInput');
  const pick = el => { el.value = ''; el.click(); };
  input.addEventListener('change', () => { const l = filesFromInput(input); if (l.length) handleFiles(l); });
  folder.addEventListener('change', () => { const l = filesFromInput(folder); if (l.length) handleFiles(l); });
  // Tap anywhere on the zone (or Browse) = choose files; the Folder button = choose a folder.
  zone.addEventListener('click', e => {
    if (e.target === input || e.target === folder) return;
    if (e.target.closest('#folderBrowse')) pick(folder); else pick(input);
  });
  zone.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(input); }
  });
  ['dragenter', 'dragover'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove('over'); }));
  zone.addEventListener('drop', async e => {
    try { const l = await filesFromDrop(e.dataTransfer); if (l.length) handleFiles(l); }
    catch (err) { console.error(err); toast('Could not read the dropped files', 'error'); }
  });
})();
setupDropzone($('#thumbDrop'), $('#thumbInput'), handleThumb);
$('#nameInput').addEventListener('input', updateSave);
$('#linkInput').addEventListener('input', () => { updateLinkState(); updateSave(); });
/* ---------- pages + bottom nav ---------- */
function showPage(name, opts = {}) {
  const add = name === 'add';
  $('#pageAdd').hidden = !add;
  $('#pageHome').hidden = add;
  $('#searchbar').hidden = add;           // search belongs to the Home page
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.page === name));
  window.scrollTo(0, 0);
  if (add && !opts.pop) history.pushState({ page: 'add' }, '');
  if (!add && !opts.pop && history.state && history.state.page === 'add') history.back();
}
document.querySelectorAll('.nav-btn').forEach(b => b.addEventListener('click', () => {
  if (!viewer.hidden) return;
  showPage(b.dataset.page);
}));
$('#cancelBtn').addEventListener('click', () => { resetForm(); showPage('home'); });

$('#saveBtn').addEventListener('click', async () => {
  const name = $('#nameInput').value.trim();
  if (!pendingZip || !name) return;
  const url = cleanLink($('#linkInput').value);
  if (url === null) return updateLinkState();
  try {
    await DB.add({
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      name, zip: pendingZip, thumb: pendingThumb || null, created: Date.now(),
      url,   // '' when no link was given
    });
    toast('Website saved', 'success');
    $('#search').value = '';
    resetForm();
    showPage('home');
    renderList();
  } catch (err) {
    console.error(err);
    toast('Could not save. Is storage full?', 'error');
  }
});

/* ---------- website list ---------- */
let thumbUrls = [];

let allSites = [];

async function renderList() {
  allSites = await DB.all();
  drawList();
}

function searchWords() {
  return $('#search').value.trim().toLowerCase().split(/\s+/).filter(Boolean);
}

/* Put the site name in `el`, wrapping every matched search word in <mark>. */
function renderName(el, text, words) {
  const lower = text.toLowerCase();
  const on = new Array(text.length).fill(false);
  words.forEach(w => {
    let i = lower.indexOf(w);
    while (i > -1) { for (let k = i; k < i + w.length; k++) on[k] = true; i = lower.indexOf(w, i + w.length); }
  });
  let i = 0;
  while (i < text.length) {
    let j = i;
    while (j < text.length && on[j] === on[i]) j++;
    const part = text.slice(i, j);
    if (on[i]) { const m = document.createElement('mark'); m.textContent = part; el.appendChild(m); }
    else el.appendChild(document.createTextNode(part));
    i = j;
  }
}

function drawList() {
  const words = searchWords();
  const sites = words.length
    ? allSites.filter(s => { const n = s.name.toLowerCase(); return words.every(w => n.includes(w)); })
    : allSites;
  thumbUrls.forEach(URL.revokeObjectURL);
  thumbUrls = [];
  const grid = $('#grid');
  grid.textContent = '';
  $('#count').textContent = words.length ? `${sites.length} of ${allSites.length}` : allSites.length;
  $('#empty').hidden = allSites.length > 0;
  const none = allSites.length > 0 && sites.length === 0;
  $('#noResults').hidden = !none;
  if (none) $('#noResultsText').textContent = `No websites match "${$('#search').value.trim()}"`;
  $('#clearSearch').hidden = !$('#search').value;

  for (const site of sites) {
    const card = document.createElement('article');
    card.className = 'site';

    if (site.thumb) {
      const img = document.createElement('img');
      img.className = 'thumb';
      img.alt = '';
      const u = URL.createObjectURL(site.thumb);
      thumbUrls.push(u);
      img.src = u;
      card.appendChild(img);
    } else {
      const ph = document.createElement('div');
      ph.className = 'ph';
      ph.textContent = site.name.charAt(0).toUpperCase();
      card.appendChild(ph);
    }

    const body = document.createElement('div');
    body.className = 'body';
    const name = document.createElement('div');
    name.className = 'name';
    renderName(name, site.name, words);
    const date = document.createElement('div');
    date.className = 'date';
    date.textContent = 'Added ' + new Date(site.created).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
    const actions = document.createElement('div');
    actions.className = 'actions';
    const prev = document.createElement('button');
    prev.className = 'btn primary';
    prev.textContent = '▶ Preview';
    prev.addEventListener('click', () => openPreview(site));
    const del = document.createElement('button');
    del.className = 'btn secondary';
    del.textContent = '🗑';
    del.setAttribute('aria-label', 'Delete ' + site.name);
    del.addEventListener('click', () => confirmDelete(site));
    if (site.url) {
      const safe = cleanLink(site.url);
      if (safe) {
        const link = document.createElement('a');
        link.className = 'btn secondary';
        link.href = safe;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = '🌐';
        link.title = safe;
        link.setAttribute('aria-label', 'Open website link for ' + site.name);
        actions.classList.add('has-link');
        actions.append(prev, link, del);
      } else actions.append(prev, del);
    } else actions.append(prev, del);
    body.append(name, date, actions);
    card.appendChild(body);
    grid.appendChild(card);
  }
}

function confirmDelete(site) {
  const dlg = $('#confirmDlg');
  $('#confirmText').textContent = `Delete "${site.name}"? This cannot be undone.`;
  dlg.showModal();
  const yes = async () => {
    cleanup();
    await DB.remove(site.id);
    toast('Deleted', 'success');
    renderList();
  };
  const no = () => cleanup();
  const cleanup = () => {
    dlg.close();
    $('#confirmYes').removeEventListener('click', yes);
    $('#confirmNo').removeEventListener('click', no);
  };
  $('#confirmYes').addEventListener('click', yes);
  $('#confirmNo').addEventListener('click', no);
}

/* ---------- search ---------- */
$('#search').addEventListener('input', drawList);
$('#search').addEventListener('keydown', e => {
  if (e.key === 'Enter') e.target.blur();                 // hides the phone keyboard
  if (e.key === 'Escape') { e.target.value = ''; drawList(); }
});
$('#clearSearch').addEventListener('click', () => { $('#search').value = ''; drawList(); $('#search').focus(); });

/* ---------- preview viewer ---------- */
let session = null, pageStack = [], currentSite = null, locStack = [];
const viewer = $('#viewer'), frame = $('#frame'), vMsg = $('#vMsg');

function viewerError(text) {
  frame.hidden = true;
  vMsg.hidden = false;
  vMsg.textContent = text;
}

async function loadPage(path) {
  vMsg.hidden = false;
  vMsg.textContent = 'Loading…';
  frame.hidden = true;
  try {
    const url = await session.page(path);
    if (session.server) locStack = [];
    frame.hidden = false;
    vMsg.hidden = true;
    // location.replace keeps iframe navigations out of the browser history,
    // so the phone's Back button closes the viewer instead of stepping through pages.
    frame.contentWindow.location.replace(url);
  } catch (err) {
    console.error(err);
    viewerError('Sorry, this page could not be opened.');
  }
}

async function openPreview(site) {
  closeViewer(true);
  currentSite = site;
  $('#vTitle').textContent = site.name;
  viewer.hidden = false;
  document.body.style.overflow = 'hidden';
  history.pushState({ viewer: true }, '');
  vMsg.hidden = false;
  vMsg.textContent = 'Opening…';
  frame.hidden = true;
  try {
    session = await ServerSession.open(site).catch(err => { console.warn(err); return null; });
    if (!session) session = await SiteSession.open(site.zip);
    if (!session) return viewerError('No index.html found in this ZIP, so there is nothing to preview. Re-zip your site with index.html at the top.');
    pageStack = [session.index];
    await loadPage(session.index);
  } catch (err) {
    console.error(err);
    viewerError('This ZIP could not be opened. It may be damaged.');
  }
}

function closeViewer(silent) {
  if (session) session.dispose();
  session = null;
  pageStack = [];
  locStack = [];
  try { frame.contentWindow.location.replace('about:blank'); } catch (e) { frame.removeAttribute('src'); }
  viewer.hidden = true;
  document.body.style.overflow = '';
}

$('#vBack').addEventListener('click', () => {
  if (session && session.server && locStack.length > 1) {
    try { frame.contentWindow.history.back(); return; } catch (e) {}
  }
  if (pageStack.length > 1) { pageStack.pop(); loadPage(pageStack[pageStack.length - 1]); }
  else {
    closeViewer();
    if (history.state && history.state.viewer) history.back();
  }
});
$('#vReload').addEventListener('click', () => {
  if (session && session.server) { try { frame.contentWindow.location.reload(); return; } catch (e) {} }
  if (session && pageStack.length) loadPage(pageStack[pageStack.length - 1]);
});
window.addEventListener('popstate', () => {
  if (!viewer.hidden) closeViewer();
  else if (!$('#pageAdd').hidden) showPage('home', { pop: true });
});
window.addEventListener('message', e => {
  if (e.source === frame.contentWindow && e.data && typeof e.data.vaultLoc === 'string' && session && session.server) {
    const loc = e.data.vaultLoc, top = locStack[locStack.length - 1];
    if (e.data.kind === 'replace') { if (locStack.length) locStack[locStack.length - 1] = loc; else locStack.push(loc); }
    else if (e.data.kind === 'push') locStack.push(loc);
    else if (loc === top) { /* same page */ }
    else if (loc === locStack[locStack.length - 2]) locStack.pop();   // went back
    else locStack.push(loc);
    return;
  }
  if (e.source !== frame.contentWindow || !e.data || !e.data.vaultNav || !session) return;
  pageStack.push(e.data.vaultNav);
  loadPage(e.data.vaultNav);
});

/* ---------- start ---------- */
ServerSession.init().catch(() => {});
renderList().catch(err => { console.error(err); toast('Storage is not available', 'error'); });
