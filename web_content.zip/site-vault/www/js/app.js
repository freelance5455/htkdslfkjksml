const $ = s => document.querySelector(s);

/* ---------- helpers ---------- */
function toast(msg, type = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

function readWithProgress(file, onProgress) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onprogress = e => e.lengthComputable && onProgress(e.loaded / e.total);
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsArrayBuffer(file);
  });
}

function setupDropzone(zone, input, onFile) {
  zone.addEventListener('click', e => { if (e.target !== input) input.click(); });
  zone.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
  input.addEventListener('change', () => { if (input.files[0]) onFile(input.files[0]); input.value = ''; });
  ['dragenter', 'dragover'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove('over'); }));
  zone.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) onFile(f); });
}

/* ---------- theme ---------- */
(function theme() {
  let saved = null;
  try { saved = localStorage.getItem('sv-theme'); } catch (e) {}
  const dark = saved ? saved === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  $('#themeBtn').addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('sv-theme', next); } catch (e) {}
  });
})();

/* ---------- add website flow ---------- */
let pendingZip = null, pendingThumb = null, thumbUrl = null;

function showProgress(pct) {
  $('#progress').hidden = false;
  $('#progressBar').style.width = Math.round(pct * 100) + '%';
}

function updateSave() {
  $('#saveBtn').disabled = !(pendingZip && $('#nameInput').value.trim());
}

function resetForm() {
  pendingZip = pendingThumb = null;
  if (thumbUrl) URL.revokeObjectURL(thumbUrl);
  thumbUrl = null;
  $('#thumbPreview').hidden = true;
  $('#thumbText').hidden = false;
  $('#thumbDrop').classList.remove('done');
  $('#zipDrop').classList.remove('done');
  $('#zipText').innerHTML = '<strong>Drag &amp; drop your ZIP here</strong><br>or tap to browse';
  $('#progress').hidden = true;
  $('#detailsStep').hidden = true;
  $('#nameInput').value = '';
  updateSave();
}

async function handleZip(file) {
  if (!/\.zip$/i.test(file.name)) return toast('Please choose a .zip file', 'error');
  showProgress(0);
  try {
    const buf = await readWithProgress(file, p => showProgress(p * 0.8));
    const zip = await JSZip.loadAsync(buf);
    showProgress(0.95);
    if (!SiteSession.find(zip)) {
      $('#progress').hidden = true;
      return toast('No index.html found in this ZIP', 'error');
    }
    showProgress(1);
    pendingZip = new Blob([buf], { type: 'application/zip' });
    $('#zipDrop').classList.add('done');
    $('#zipText').textContent = '✅ ' + file.name;
    $('#detailsStep').hidden = false;
    if (!$('#nameInput').value) $('#nameInput').value = file.name.replace(/\.zip$/i, '');
    updateSave();
    setTimeout(() => ($('#progress').hidden = true), 600);
  } catch (err) {
    console.error(err);
    $('#progress').hidden = true;
    toast('That ZIP could not be read', 'error');
  }
}

function handleThumb(file) {
  if (!file.type.startsWith('image/')) return toast('Thumbnail must be an image', 'error');
  pendingThumb = file;
  if (thumbUrl) URL.revokeObjectURL(thumbUrl);
  thumbUrl = URL.createObjectURL(file);
  $('#thumbPreview').src = thumbUrl;
  $('#thumbPreview').hidden = false;
  $('#thumbText').hidden = true;
  $('#thumbDrop').classList.add('done');
}

setupDropzone($('#zipDrop'), $('#zipInput'), handleZip);
setupDropzone($('#thumbDrop'), $('#thumbInput'), handleThumb);
$('#nameInput').addEventListener('input', updateSave);
function openAdd() {
  $('#addCard').hidden = false;
  $('#addToggle').hidden = true;
  $('#addCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
function closeAdd() {
  resetForm();
  $('#addCard').hidden = true;
  $('#addToggle').hidden = false;
}
$('#addToggle').addEventListener('click', openAdd);
$('#closeAdd').addEventListener('click', closeAdd);
$('#cancelBtn').addEventListener('click', closeAdd);

$('#saveBtn').addEventListener('click', async () => {
  const name = $('#nameInput').value.trim();
  if (!pendingZip || !name) return;
  try {
    await DB.add({
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      name, zip: pendingZip, thumb: pendingThumb || null, created: Date.now(),
    });
    toast('Website saved', 'success');
    closeAdd();
    renderList();
  } catch (err) {
    console.error(err);
    toast('Could not save. Is storage full?', 'error');
  }
});

/* ---------- website list ---------- */
let thumbUrls = [];

async function renderList() {
  const sites = await DB.all();
  thumbUrls.forEach(URL.revokeObjectURL);
  thumbUrls = [];
  const grid = $('#grid');
  grid.textContent = '';
  $('#count').textContent = sites.length;
  $('#empty').hidden = sites.length > 0;

  for (const site of sites) {
    const card = document.createElement('article');
    card.className = 'site';

    if (site.thumb) {
      const img = document.createElement('img');
      img.className = 'thumb';
      img.alt = '';
      const u = URL.createObjectURL(site.thumb);
      thumbUrls.push(u);
      img.src = u;
      card.appendChild(img);
    } else {
      const ph = document.createElement('div');
      ph.className = 'ph';
      ph.textContent = site.name.charAt(0).toUpperCase();
      card.appendChild(ph);
    }

    const body = document.createElement('div');
    body.className = 'body';
    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = site.name;
    const date = document.createElement('div');
    date.className = 'date';
    date.textContent = 'Added ' + new Date(site.created).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
    const actions = document.createElement('div');
    actions.className = 'actions';
    const prev = document.createElement('button');
    prev.className = 'btn primary';
    prev.textContent = '▶ Preview';
    prev.addEventListener('click', () => openPreview(site));
    const del = document.createElement('button');
    del.className = 'btn secondary';
    del.textContent = '🗑';
    del.setAttribute('aria-label', 'Delete ' + site.name);
    del.addEventListener('click', () => confirmDelete(site));
    actions.append(prev, del);
    body.append(name, date, actions);
    card.appendChild(body);
    grid.appendChild(card);
  }
}

function confirmDelete(site) {
  const dlg = $('#confirmDlg');
  $('#confirmText').textContent = `Delete "${site.name}"? This cannot be undone.`;
  dlg.showModal();
  const yes = async () => {
    cleanup();
    await DB.remove(site.id);
    toast('Deleted', 'success');
    renderList();
  };
  const no = () => cleanup();
  const cleanup = () => {
    dlg.close();
    $('#confirmYes').removeEventListener('click', yes);
    $('#confirmNo').removeEventListener('click', no);
  };
  $('#confirmYes').addEventListener('click', yes);
  $('#confirmNo').addEventListener('click', no);
}

/* ---------- preview viewer ---------- */
let session = null, pageStack = [], currentSite = null;
const viewer = $('#viewer'), frame = $('#frame'), vMsg = $('#vMsg');

function viewerError(text) {
  frame.hidden = true;
  vMsg.hidden = false;
  vMsg.textContent = text;
}

async function loadPage(path) {
  vMsg.hidden = false;
  vMsg.textContent = 'Loading…';
  frame.hidden = true;
  try {
    const url = await session.page(path);
    frame.hidden = false;
    vMsg.hidden = true;
    // location.replace keeps iframe navigations out of the browser history,
    // so the phone's Back button closes the viewer instead of stepping through pages.
    frame.contentWindow.location.replace(url);
  } catch (err) {
    console.error(err);
    viewerError('Sorry, this page could not be opened.');
  }
}

async function openPreview(site) {
  closeViewer(true);
  currentSite = site;
  $('#vTitle').textContent = site.name;
  viewer.hidden = false;
  document.body.style.overflow = 'hidden';
  history.pushState({ viewer: true }, '');
  vMsg.hidden = false;
  vMsg.textContent = 'Opening…';
  frame.hidden = true;
  try {
    session = await SiteSession.open(site.zip);
    if (!session) return viewerError('No index.html found in this ZIP, so there is nothing to preview. Re-zip your site with index.html at the top.');
    pageStack = [session.index];
    await loadPage(session.index);
  } catch (err) {
    console.error(err);
    viewerError('This ZIP could not be opened. It may be damaged.');
  }
}

function closeViewer(silent) {
  if (session) session.dispose();
  session = null;
  pageStack = [];
  try { frame.contentWindow.location.replace('about:blank'); } catch (e) { frame.removeAttribute('src'); }
  viewer.hidden = true;
  document.body.style.overflow = '';
}

$('#vBack').addEventListener('click', () => {
  if (pageStack.length > 1) { pageStack.pop(); loadPage(pageStack[pageStack.length - 1]); }
  else {
    closeViewer();
    if (history.state && history.state.viewer) history.back();
  }
});
$('#vReload').addEventListener('click', () => { if (session && pageStack.length) loadPage(pageStack[pageStack.length - 1]); });
window.addEventListener('popstate', () => { if (!viewer.hidden) closeViewer(); });
window.addEventListener('message', e => {
  if (e.source !== frame.contentWindow || !e.data || !e.data.vaultNav || !session) return;
  pageStack.push(e.data.vaultNav);
  loadPage(e.data.vaultNav);
});

/* ---------- start ---------- */
renderList().catch(err => { console.error(err); toast('Storage is not available', 'error'); });
