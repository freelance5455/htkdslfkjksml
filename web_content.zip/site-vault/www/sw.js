/*
 * MEDUSA service worker: a tiny web server that lives inside the browser.
 * It serves the files of a stored ZIP under real URLs, so any kind of site works:
 * multi-page sites, single-page apps with history routing, ES modules, fetch/XHR,
 * web workers, fonts, video/audio seeking (Range) and root-absolute paths.
 * Everything is read from IndexedDB on the device; nothing is uploaded anywhere.
 */
importScripts('js/jszip.min.js');

const SCOPE_PATH = new URL(self.registration.scope).pathname;   // e.g. "/"
const PREFIX = SCOPE_PATH + '__vault__/';                       // e.g. "/__vault__/"
const STATE_CACHE = 'medusa-state';

const MIME = {
  html: 'text/html', htm: 'text/html', xhtml: 'application/xhtml+xml', css: 'text/css',
  js: 'text/javascript', mjs: 'text/javascript', cjs: 'text/javascript', jsx: 'text/javascript',
  json: 'application/json', map: 'application/json', webmanifest: 'application/manifest+json',
  txt: 'text/plain', md: 'text/plain', xml: 'application/xml', csv: 'text/csv', svg: 'image/svg+xml',
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp',
  avif: 'image/avif', ico: 'image/x-icon', bmp: 'image/bmp', apng: 'image/apng',
  woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf', eot: 'application/vnd.ms-fontobject',
  mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg', m4a: 'audio/mp4', aac: 'audio/aac',
  mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm', ogv: 'video/ogg', mov: 'video/quicktime',
  pdf: 'application/pdf', wasm: 'application/wasm', zip: 'application/zip', glb: 'model/gltf-binary',
  gltf: 'model/gltf+json', ttl: 'text/turtle',
};
const TEXTY = new Set(['html', 'htm', 'xhtml', 'css', 'js', 'mjs', 'cjs', 'jsx', 'json', 'txt', 'md', 'xml', 'csv', 'svg', 'map', 'webmanifest']);

let ACTIVE;                 // undefined = not loaded yet, null = no site open, string = id of the open site
const sites = new Map();    // id -> parsed zip

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

self.addEventListener('message', e => {
  const msg = e.data || {};
  if (msg.type !== 'active') return;
  e.waitUntil((async () => {
    ACTIVE = msg.id || null;
    if (ACTIVE) sites.delete(ACTIVE);          // re-read the ZIP so a re-added site is never stale
    try {
      const c = await caches.open(STATE_CACHE);
      await c.put(new Request(PREFIX + '__active__'), new Response(ACTIVE || ''));
    } catch (err) { /* state is also kept in memory */ }
    if (e.ports && e.ports[0]) e.ports[0].postMessage('ok');
  })());
});

async function loadActive() {
  if (ACTIVE !== undefined) return;
  try {
    const c = await caches.open(STATE_CACHE);
    const r = await c.match(new Request(PREFIX + '__active__'));
    ACTIVE = r ? (await r.text()) || null : null;
  } catch (err) { ACTIVE = null; }
}

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (url.origin !== self.location.origin) return;
  const inVault = url.pathname.startsWith(PREFIX);
  // With no site open, only our own virtual URLs are touched: the app itself is never affected.
  if (!inVault && ACTIVE === null) return;
  // A top-level page load that is not an iframe can never be part of a site.
  if (!inVault && e.request.mode === 'navigate' && e.request.destination !== 'iframe') return;
  e.respondWith(handle(e, url, inVault));
});

/* ---------- storage ---------- */
function idbGet(id) {
  return new Promise((resolve, reject) => {
    const open = indexedDB.open('site-vault', 1);
    open.onupgradeneeded = () => open.result.createObjectStore('sites', { keyPath: 'id' });
    open.onerror = () => reject(open.error);
    open.onsuccess = () => {
      const db = open.result;
      try {
        const get = db.transaction('sites', 'readonly').objectStore('sites').get(id);
        get.onsuccess = () => { db.close(); resolve(get.result); };
        get.onerror = () => { db.close(); reject(get.error); };
      } catch (err) { db.close(); reject(err); }
    };
  });
}

async function getSite(id) {
  if (sites.has(id)) return sites.get(id);
  const rec = await idbGet(id);
  if (!rec || !rec.zip) return null;
  const zip = await JSZip.loadAsync(rec.zip);
  let best = null;
  zip.forEach((p, entry) => {
    if (entry.dir || p.startsWith('__MACOSX/')) return;
    if (/(^|\/)index\.html?$/i.test(p)) {
      const depth = p.split('/').length;
      if (!best || depth < best.depth) best = { depth, root: p.slice(0, p.lastIndexOf('/') + 1), path: p };
    }
  });
  if (!best) return null;
  const files = Object.create(null), lower = Object.create(null);
  zip.forEach((p, entry) => {
    if (entry.dir || p.startsWith('__MACOSX/') || !p.startsWith(best.root)) return;
    const rel = p.slice(best.root.length);
    files[rel] = entry;
    lower[rel.toLowerCase()] = rel;
  });
  const site = { files, lower, index: best.path.slice(best.root.length) };
  sites.set(id, site);
  if (sites.size > 3) sites.delete(sites.keys().next().value);
  return site;
}

function findFile(site, path) {
  const p = path.replace(/^\/+/, '');
  const tries = (p === '' || p.endsWith('/'))
    ? [p + 'index.html', p + 'index.htm']
    : [p, p + '.html', p + '/index.html'];           // /about -> about.html (clean URLs)
  for (const t of tries) {
    if (t in site.files) return t;
    const l = site.lower[t.toLowerCase()];
    if (l) return l;
  }
  return null;
}

/* ---------- which site does this request belong to? ---------- */
async function belongsToViewer(e) {
  if (e.request.destination === 'iframe') return true;
  if (!e.clientId) return false;
  const c = await self.clients.get(e.clientId);
  return !!c && (c.frameType === 'nested' || c.type === 'worker' || c.type === 'sharedworker');
}

async function handle(e, url, inVault) {
  let id = null, rel = '';
  try {
    if (inVault) {
      const rest = url.pathname.slice(PREFIX.length);
      if (rest === 'bridge.js') return bridgeResponse();
      if (rest === '__ping__') return new Response('vault-ok', { headers: { 'Cache-Control': 'no-store' } });
      const i = rest.indexOf('/');
      if (i > 0) { id = decodeURIComponent(rest.slice(0, i)); rel = rest.slice(i + 1); }
    } else {
      await loadActive();
      if (ACTIVE && await belongsToViewer(e)) {
        id = ACTIVE;
        rel = url.pathname.startsWith(SCOPE_PATH) ? url.pathname.slice(SCOPE_PATH.length) : url.pathname.slice(1);
      }
    }
    if (id) {
      const res = await serve(e.request, id, rel);
      if (res) return res;
    }
  } catch (err) {
    return new Response('MEDUSA preview error: ' + err.message, { status: 500, headers: { 'Content-Type': 'text/plain' } });
  }
  return fetch(e.request);
}

/* ---------- serving a file ---------- */
async function serve(request, id, rel) {
  const site = await getSite(id);
  if (!site) return new Response('This site is no longer stored in MEDUSA.', { status: 404, headers: { 'Content-Type': 'text/plain' } });
  let path;
  try { path = decodeURIComponent(rel); } catch (err) { path = rel; }
  path = path.split('?')[0].split('#')[0];

  let key = findFile(site, path);
  const accept = request.headers.get('accept') || '';
  const wantsPage = request.mode === 'navigate' || request.destination === 'iframe' ||
    request.destination === 'document' || accept.includes('text/html');
  const lastSeg = path.split('/').pop();
  // Single-page apps: unknown "routes" (no file extension) get index.html, like a real SPA host.
  if (!key && wantsPage && !/\.[a-z0-9]{1,8}$/i.test(lastSeg)) key = site.index;
  if (!key) return new Response('Not found: /' + path, { status: 404, headers: { 'Content-Type': 'text/plain' } });

  const ext = key.split('.').pop().toLowerCase();
  const type = (MIME[ext] || 'application/octet-stream') + (TEXTY.has(ext) ? '; charset=utf-8' : '');
  const headers = { 'Content-Type': type, 'Cache-Control': 'no-cache', 'Accept-Ranges': 'bytes' };
  const entry = site.files[key];

  if (ext === 'html' || ext === 'htm' || ext === 'xhtml') {
    const html = injectBridge(await entry.async('string'));
    return new Response(html, { status: 200, headers });
  }

  const buf = await entry.async('arraybuffer');
  const range = /^bytes=(\d*)-(\d*)$/.exec(request.headers.get('range') || '');
  if (range && (range[1] || range[2])) {
    const total = buf.byteLength;
    let start = range[1] ? parseInt(range[1], 10) : Math.max(0, total - parseInt(range[2], 10));
    let end = range[1] && range[2] ? parseInt(range[2], 10) : total - 1;
    end = Math.min(end, total - 1);
    if (start > end || start >= total) {
      return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + total } });
    }
    headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + total;
    return new Response(buf.slice(start, end + 1), { status: 206, headers });
  }
  return new Response(buf, { status: 200, headers });
}

/* ---------- HTML: load our small bridge script first ---------- */
function injectBridge(html) {
  // A site's own CSP meta tag would block the bridge and confuse a preview, so drop it.
  html = html.replace(/<meta[^>]+http-equiv\s*=\s*["']?content-security-policy["']?[^>]*>/gi, '');
  const tag = '<script src="' + PREFIX + 'bridge.js"></script>';
  let m = /<head[^>]*>/i.exec(html);
  if (!m) m = /<html[^>]*>/i.exec(html);
  if (!m) m = /<!doctype[^>]*>/i.exec(html);
  if (m) return html.slice(0, m.index + m[0].length) + tag + html.slice(m.index + m[0].length);
  return tag + html;
}

function bridgeResponse() {
  const js = '(' + bridgeMain.toString() + ')(' + JSON.stringify(SCOPE_PATH) + ',' + JSON.stringify(PREFIX) + ');';
  return new Response(js, { headers: { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-cache' } });
}

/* Runs inside the previewed page (this function is serialised and sent as bridge.js). */
function bridgeMain(BASE, PRE) {
  var rp = history.replaceState, pp = history.pushState;
  // The page was opened under /__vault__/<id>/...; make the address look like a normal server
  // (/ , /about.html ...) so routers and absolute paths in the site behave as they would online.
  if (location.pathname.indexOf(PRE) === 0) {
    var rest = location.pathname.slice(PRE.length);
    var j = rest.indexOf('/');
    var rel = j >= 0 ? rest.slice(j + 1) : '';
    if (rel === 'index.html' || rel === 'index.htm') rel = '';
    try { rp.call(history, history.state, '', BASE + rel + location.search + location.hash); } catch (e) {}
  }
  function cur() { return location.pathname + location.search + location.hash; }
  function send(kind) { try { parent.postMessage({ vaultLoc: cur(), kind: kind }, '*'); } catch (e) {} }
  history.pushState = function () { var r = pp.apply(history, arguments); send('push'); return r; };
  history.replaceState = function () { var r = rp.apply(history, arguments); send('replace'); return r; };
  addEventListener('popstate', function () { send('pop'); });
  addEventListener('hashchange', function () { send('pop'); });
  send('load');
  // A site must not replace MEDUSA's own service worker.
  try {
    var C = window.ServiceWorkerContainer && ServiceWorkerContainer.prototype;
    if (C) {
      C.register = function () { return Promise.reject(new DOMException('Service workers are turned off inside MEDUSA preview', 'SecurityError')); };
      C.getRegistrations = function () { return Promise.resolve([]); };
      C.getRegistration = function () { return Promise.resolve(undefined); };
    }
  } catch (e) {}
}
