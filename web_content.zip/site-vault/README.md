# Site Vault

Store your websites as ZIP files and preview them inside the app. Works offline, no server, no login.
Everything is saved on the device (IndexedDB).

## Folder structure

```
site-vault/
├── www/                  ← the whole app (this is what goes into the APK)
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── jszip.min.js  ← unzip library (bundled, works offline)
│       ├── db.js         ← saves ZIPs and thumbnails on the device
│       ├── preview.js    ← unzips a site and makes it run inside the app
│       └── app.js        ← screens, buttons, drag and drop
├── package.json
├── capacitor.config.json
└── README.md
```

## 1. Test on your computer (free)

```
cd site-vault
npx http-server www -p 8080
```

Open http://localhost:8080 in Chrome. Drag a website ZIP into the box, add a thumbnail and a name, press **Save website**, then **Preview**.

Tip: your ZIP must have `index.html` at the top, or inside one folder.

## 2. Build the APK (free)

You need Node.js and Android Studio (both free).

```
cd site-vault
npm install
npx cap add android
npx cap sync
npx cap open android
```

In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
Your file will be at `android/app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it.

After any change to the files in `www/`, run `npx cap sync` and build again.

No Android Studio? Zip the `www` folder and use a free online "website to APK" converter, or PWABuilder after hosting it on free HTTPS hosting.

## How the preview works

1. The ZIP is opened in memory with JSZip.
2. Every file gets a temporary `blob:` address, and paths inside HTML and CSS (images, fonts, scripts, `@import`, `url(...)`) are pointed to them.
3. A tiny helper is added to the page so `fetch()`, dynamically added images and links to your other pages (`about.html`) also work.
4. The page runs inside a sandboxed iframe in a full-screen viewer.

## Known limits

- Websites that need the internet (CDN scripts, Google Fonts, APIs) work only when the phone is online.
- JavaScript modules that import other files (`<script type="module">` with `import './x.js'`) are not supported. Use a bundled build.
- Sites that need a real server (PHP, login, databases) will not run.
- The preview shares the app's storage space, so only preview your own sites.
