# MEDUSA

Store your websites as ZIP files and preview them inside the app. Works offline, no server, no login.
Everything is saved on the device (IndexedDB).

## How the app works

- **Bottom navbar:** `Home` and `Add`.
- **Home:** the search bar and all your websites (thumbnail, name, date, Preview and Delete). Websites are shown only here.
- **Add:** drag and drop (or Browse) a website ZIP, add a thumbnail and a name, then Save. You return to Home automatically.
- **Preview:** opens your website full screen inside the app, with Back and Reload.

## Folder structure

```
site-vault/
├── www/                    ← the whole app (this goes into the APK)
│   ├── index.html
│   ├── css/style.css
│   ├── img/logo.png        ← MEDUSA emblem (transparent PNG)
│   └── js/
│       ├── jszip.min.js    ← unzip library (bundled, works offline)
│       ├── db.js           ← saves ZIPs and thumbnails on the device
│       ├── preview.js      ← unzips a site and makes it run inside the app
│       └── app.js          ← pages, bottom navbar, search, buttons
├── resources/
│   ├── icon.png            ← 1024x1024 app icon (MEDUSA emblem)
│   └── splash.png          ← splash screen (your full logo artwork)
├── package.json
├── capacitor.config.json   ← app name "MEDUSA"
└── README.md
```

## 1. Test on your computer (free)

```
cd site-vault
npx http-server www -p 8080
```

Open http://localhost:8080 in Chrome (use the phone-size view in DevTools).

Your website ZIP must have `index.html` at the top, or inside one folder.

## 2. Build the APK (free)

You need Node.js and Android Studio (both free).

```
cd site-vault
npm install
npx cap add android
npx @capacitor/assets generate --android   # makes the MEDUSA app icon and splash
npx cap sync
npx cap open android
```

In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
Your file will be at `android/app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it.

After any change to the files in `www/`, run `npx cap sync` and build again.

## How the preview works

1. The ZIP is opened in memory with JSZip.
2. Every file gets a temporary `blob:` address, and paths inside HTML and CSS (images, fonts, scripts, `@import`, `url(...)`) are pointed to them.
3. A tiny helper is added so `fetch()`, dynamically added images and links to your other pages also work.
4. The page runs inside a sandboxed iframe in a full-screen viewer.

## Known limits

- Websites that need the internet (CDN scripts, Google Fonts, APIs) work only when the phone is online.
- JavaScript modules that import other files (`<script type="module">` with `import './x.js'`) are not supported. Use a bundled build.
- Sites that need a real server (PHP, login, databases) will not run.
- Your data lives in the app. It is removed if you uninstall the app or clear its storage, so keep your original ZIPs.

## How previews run (two engines)

MEDUSA picks the best engine automatically every time you tap **Preview**:

1. **Server engine (preferred)** – `www/sw.js` is a service worker that acts as a small web server
   for the stored ZIP. The site gets real URLs (`/`, `/about`, `/assets/app.js`), so these all work:
   multi-page sites, single-page apps with history routing (React/Vue/Svelte/Angular builds),
   ES modules and dynamic `import()`, `fetch`/XHR to files in the ZIP, web workers, fonts,
   video/audio seeking, clean URLs (`/contact` → `contact.html`) and root-absolute paths.
   Needs `https://` or `http://localhost` (the Android app already runs on one).
2. **Rewrite engine (fallback)** – `www/js/preview.js`, used when service workers are unavailable
   (for example when `index.html` is opened straight from disk with `file://`).

Notes
- The site's own service worker is switched off inside the preview so it cannot replace MEDUSA's.
- Previewed sites share the app's browser storage (localStorage/IndexedDB), so avoid sites that
  call `localStorage.clear()` if you care about MEDUSA's theme setting.
- Sites that need a real backend (PHP, Node, databases) or content from the internet while you are
  offline cannot run from a ZIP.

## Adding websites (Add tab → Browse)

The picker accepts every common way a website is stored:
- a **.zip** (index.html at the top, or inside one folder),
- a single **.html** file,
- several files at once (HTML + CSS + JS + images, fonts, …),
- a whole **folder** (the 📁 Folder button, or drag a folder in on desktop).
Loose files and folders are packed into a ZIP on the device. If there is no `index.html`, the best
HTML file (home, main, default…) becomes the start page. Other archive types (.rar, .7z) are not supported.

## Optional website link
On the **Add** page there is an optional **Website link** field (for example your Netlify URL).
Leave it empty and the website saves normally. If you add one, a 🌐 button appears on that
website's card on the Home page and opens the link in your browser.
