import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
const scene=new THREE.Scene(); scene.background=new THREE.Color(0x9db4c9);scene.fog=new THREE.Fog(0x9db4c9,100,520);
const camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,900);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1;document.body.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xdbeeff,0x536048,2.0));const sun=new THREE.DirectionalLight(0xffedcf,3);sun.position.set(-80,130,60);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-90;sun.shadow.camera.right=90;sun.shadow.camera.top=90;sun.shadow.camera.bottom=-90;scene.add(sun);
const mat=(color,rough=1)=>new THREE.MeshStandardMaterial({color,roughness:rough});
const ground=new THREE.Mesh(new THREE.PlaneGeometry(1000,1000),mat(0x5c6950));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
// rolling terrain as broad raised patches
for(let i=0;i<30;i++){let hill=new THREE.Mesh(new THREE.SphereGeometry(1,16,12),mat(i%2?0x69785b:0x727d61));hill.scale.set(12+Math.random()*30,3+Math.random()*12,18+Math.random()*40);hill.position.set((Math.random()-.5)*480,-1,(Math.random()-.5)*480);hill.castShadow=true;scene.add(hill)}
// asphalt road
function road(x,z,w,l){let m=new THREE.Mesh(new THREE.PlaneGeometry(w,l),mat(0x34383b));m.rotation.x=-Math.PI/2;m.position.set(x,.03,z);scene.add(m);for(let k=-l/2+8;k<l/2;k+=18){let dash=new THREE.Mesh(new THREE.PlaneGeometry(.3,7),mat(0xd6d2bc));dash.rotation.x=-Math.PI/2;dash.position.set(x,.045,z+k);scene.add(dash)}}
road(0,0,12,500);road(0,0,500,12);
// city skyline far away
for(let i=0;i<95;i++){const h=12+Math.random()*80,w=8+Math.random()*18,d=8+Math.random()*18;let b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat([0x66798a,0x73818d,0x526778,0x8995a0][i%4]));b.position.set((Math.random()-.5)*250,h/2,-260-Math.random()*130);scene.add(b)}
// trees around hillside
function tree(x,z,s=1){let trunk=new THREE.Mesh(new THREE.CylinderGeometry(.35*s,.55*s,5*s,7),mat(0x594332));trunk.position.set(x,2.5*s,z);trunk.castShadow=true;scene.add(trunk);for(let j=0;j<3;j++){let crown=new THREE.Mesh(new THREE.ConeGeometry(3.5*s,5.5*s,9),mat(0x263f2b));crown.position.set(x,4.5*s+j*2.5*s,z);crown.castShadow=true;scene.add(crown)}}
for(let i=0;i<90;i++){let x=(Math.random()-.5)*280,z=(Math.random()-.5)*270;if(Math.abs(x)>12&&Math.abs(z)>14)tree(x,z,.65+Math.random()*.1)}
// character simple low poly silhouette
const player=new THREE.Group();scene.add(player);
const skin=mat(0xc7a07d),dark=mat(0x24282e),pants=mat(0x303b4b);
function capsule(r,len,m,x,y,z){let obj=new THREE.Mesh(new THREE.CapsuleGeometry(r,len,4,8),m);obj.position.set(x,y,z);obj.castShadow=true;player.add(obj);return obj}
capsule(.36,1.0,dark,0,1.55,0);capsule(.18,.75,pants,-.2,.52,0);capsule(.18,.75,pants,.2,.52,0);let head=new THREE.Mesh(new THREE.SphereGeometry(.25,12,10),skin);head.position.set(0,2.45,0);head.castShadow=true;player.add(head);
// motorbike built from shapes
const bike=new THREE.Group();scene.add(bike);
const frame=mat(0x20262d,.5),green=mat(0x2e6851,.45),rubber=mat(0x15181b),metal=mat(0x888f95,.3);
function cylBike(rad,len,m,x,y,z,rot){let mesh=new THREE.Mesh(new THREE.CylinderGeometry(rad,rad,len,16),m);mesh.position.set(x,y,z);mesh.rotation.z=rot||0;mesh.castShadow=true;bike.add(mesh);return mesh}
function wheel(x,z){let w=new THREE.Mesh(new THREE.TorusGeometry(.43,.11,10,20),rubber);w.position.set(x,.45,z);w.rotation.y=Math.PI/2;w.castShadow=true;bike.add(w);let hub=new THREE.Mesh(new THREE.CylinderGeometry(.14,.14,.2,12),metal);hub.position.copy(w.position);hub.rotation.z=Math.PI/2;bike.add(hub)}
wheel(-.8,.2);wheel(.8,.2);let tank=new THREE.Mesh(new BoxGeometry(.65,.5,1.2),green);tank.position.set(0,1.05,.1);tank.castShadow=true;bike.add(tank);let seat=new THREE.Mesh(new BoxGeometry(.55,.16,.8),dark);seat.position.set(0,1.35,-.5);bike.add(seat);cylBike(.07,1.2,metal,0,1.3,.8,Math.PI/4);let headlamp=new THREE.Mesh(new SphereGeometry(.18,10,8),mat(0xfff0b4));headlamp.position.set(0,1.05,.85);bike.add(headlamp);bike.position.set(4,0,3);
// controls, camera
let keys={},onBike=false,run=false,yaw=0,camYaw=0,camPitch=.18,mouseSensitivity=.005;
addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key==='e')toggleBike();if(e.key==='Shift')run=true});addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;if(e.key==='Shift')run=false});
let dragging=false,prevX=0,prevY=0;renderer.domElement.addEventListener('pointerdown',e=>{dragging=true;prevX=e.clientX;prevY=e.clientY});addEventListener('pointerup',()=>dragging=false);addEventListener('pointermove',e=>{if(dragging){camYaw-=(e.clientX-prevX)*mouseSensitivity;camPitch=Math.max(-.25,Math.min(.7,camPitch+(e.clientY-prevY)*.003));prevX=e.clientX;prevY=e.clientY}});
function toggleBike(){onBike=!onBike;if(onBike){bike.position.copy(player.position);bike.position.y=0;bike.rotation.y=player.rotation.y;player.visible=false}else{player.visible=true;player.position.copy(bike.position);player.position.x+=1.3}}
document.getElementById('ride').onclick=toggleBike;document.getElementById('run').onpointerdown=()=>run=true;document.getElementById('run').onpointerup=()=>run=false;
document.querySelectorAll('[data-key]').forEach(b=>{let k=b.dataset.key;b.onpointerdown=e=>{e.preventDefault();keys[k]=true};['pointerup','pointerleave','pointercancel'].forEach(ev=>b.addEventListener(ev,()=>keys[k]=false))});
let active=false;document.getElementById('play').onclick=()=>{active=true;document.getElementById('menu').classList.add('hidden');document.getElementById('hud').classList.remove('hidden');if(innerWidth<800)document.getElementById('touchUI').classList.remove('hidden');player.position.set(0,0,8);player.visible=true;bike.position.set(4,0,3);onBike=false};
document.getElementById('exit').onclick=()=>{active=false;document.getElementById('hud').classList.add('hidden');document.getElementById('touchUI').classList.add('hidden');document.getElementById('menu').classList.remove('hidden')};
document.querySelectorAll('.gameSelect button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.gameSelect button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');let vi=b.dataset.game==='vi';document.getElementById('gameHeading').innerHTML=vi?'GRAND THEFT AUTO <em>VI</em>':'GRAND THEFT AUTO <em>V</em>';document.getElementById('gameDesc').textContent=vi?'Vice City-inspired tropical prototype':'Los Santos-inspired hillside prototype';scene.fog.color.set(vi?0xb9a5a0:0x9db4c9);scene.background=scene.fog.color;});
document.getElementById('sens').oninput=e=>{let v=+e.target.value;document.getElementById('sensValue').textContent=v+'%';mouseSensitivity=.001+v/1000};
const clock=new THREE.Clock();
function tick(){requestAnimationFrame(tick);let dt=Math.min(clock.getDelta(),.05);if(active){let forward=keys.w||keys.z,back=keys.s,left=keys.a||keys.q,right=keys.d;let turn=(left?1:0)-(right?1:0);if(onBike){bike.rotation.y+=turn*dt*1.6;let speed=(forward?1:0)-(back?.5:0);bike.position.x+=Math.sin(bike.rotation.y)*speed*dt*(run?22:13);bike.position.z+=Math.cos(bike.rotation.y)*speed*dt*(run?22:13);player.position.copy(bike.position)}else{player.rotation.y+=turn*dt*2.2;let speed=(run?8:4);if(forward){player.position.x+=Math.sin(player.rotation.y)*speed*dt;player.position.z+=Math.cos(player.rotation.y)*speed*dt}if(back){player.position.x-=Math.sin(player.rotation.y)*speed*.6*dt;player.position.z-=Math.cos(player.rotation.y)*speed*.6*dt}}
let target=onBike?bike.position:player.position;let angle=camYaw+(onBike?bike.rotation.y:player.rotation.y);let dist=onBike?7:6;let desired=new THREE.Vector3(target.x-Math.sin(angle)*dist,target.y+(onBike?3:3.2)+camPitch*5,target.z-Math.cos(angle)*dist);camera.position.lerp(desired,.12);camera.lookAt(target.x,target.y+1.2,target.z);}}
renderer.render(scene,camera)}tick();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
