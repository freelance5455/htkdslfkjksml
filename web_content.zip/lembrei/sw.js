/* ==========================================================================
   Lembrei — Service Worker
   --------------------------------------------------------------------------
   O que este arquivo faz HOJE (testado):
   1) Cacheia o app inteiro (HTML/CSS/JS/ícones) -> o app abre sem internet.
   2) Registra os handlers de notificação (notificationclick) e de push.
      O handler de push só recebe mensagens se existir um servidor de push
      configurado (veja opcional/push-server/README.md). Sem servidor, ele
      simplesmente nunca é acionado — não há notificação "mágica" com o app
      fechado.
   Estratégia de cache: cache-first para arquivos do próprio app,
   network-update em segundo plano (stale-while-revalidate simples).
   ========================================================================== */

const VERSAO = 'lembrei-v3.0.3';
const ARQUIVOS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './sw.js',
  './css/styles.css',
  './js/app.js',
  './js/formulario.js',
  './js/modelo.js',
  './js/organizador.js',
  './js/relatorios.js',
  './js/store.js',
  './js/utils.js',
  './js/views-mais.js',
  './js/views.js',
  './icons/apple-touch-icon.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
];

self.addEventListener('install', (evento) => {
  evento.waitUntil(
    caches.open(VERSAO)
      .then((cache) => cache.addAll(ARQUIVOS))
      .then(() => self.skipWaiting())
      .catch(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (evento) => {
  evento.waitUntil(
    caches.keys()
      .then((chaves) => Promise.all(chaves.filter((k) => k !== VERSAO).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (evento) => {
  const req = evento.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // não intercepta terceiros

  evento.respondWith(
    caches.match(req, { ignoreSearch: true }).then((emCache) => {
      const daRede = fetch(req)
        .then((resp) => {
          if (resp && resp.status === 200 && resp.type === 'basic') {
            const copia = resp.clone();
            caches.open(VERSAO).then((c) => c.put(req, copia)).catch(() => {});
          }
          return resp;
        })
        .catch(() => emCache || caches.match('./index.html'));
      return emCache || daRede;
    })
  );
});

/* ---------- Notificações ---------- */

// Clique na notificação: foca (ou abre) o app.
self.addEventListener('notificationclick', (evento) => {
  evento.notification.close();
  const dados = evento.notification.data || {};
  const alvo = dados.url || './index.html#notificacoes';
  evento.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((lista) => {
      for (const c of lista) {
        if ('focus' in c) {
          c.postMessage({ tipo: 'ABRIR', rota: alvo });
          return c.focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(alvo);
    })
  );
});

// Push real: só funciona com um servidor de push enviando mensagens (VAPID).
// Sem servidor configurado este bloco nunca executa.
self.addEventListener('push', (evento) => {
  let payload = { title: 'Lembrei', body: 'Você tem uma conta para conferir.' };
  try {
    if (evento.data) payload = Object.assign(payload, evento.data.json());
  } catch (e) {
    if (evento.data) payload.body = evento.data.text();
  }
  evento.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body,
      icon: './icons/icon-192.png',
      badge: './icons/icon-192.png',
      tag: payload.tag || 'lembrei-push',
      data: { url: payload.url || './index.html#notificacoes' }
    })
  );
});
