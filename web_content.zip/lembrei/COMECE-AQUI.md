# Lembrei — comece por aqui

App de lembretes de contas a pagar. Funciona no Android e no iPhone, sem conta,
sem senha e sem mensalidade. Versão 2.

---

## 1. Colocar no celular (5 minutos, uma vez só)

O Lembrei é um **PWA**: um site que se instala na tela inicial e depois abre como
aplicativo, com ícone próprio, tela cheia e funcionando sem internet.
Essa é a forma mais barata (R$ 0) de ter um app nos dois sistemas.

### Passo 1 — publicar a pasta (grátis)

Escolha **uma** opção:

**Opção A · Netlify Drop (mais fácil, sem cadastro para testar)**
1. No computador, abra https://app.netlify.com/drop
2. Arraste a pasta `lembrei` inteira para a área indicada
3. Em segundos aparece um endereço tipo `https://nome-aleatorio.netlify.app`
4. Crie uma conta gratuita para manter esse endereço no ar

**Opção B · Netlify com conta (endereço com o nome que você quiser)**
1. https://app.netlify.com → "Add new site" → "Deploy manually"
2. Arraste a pasta `lembrei`
3. Site settings → "Change site name" → ex.: `lembrei-joao`

**Opção C · GitHub Pages**
1. Crie um repositório e envie o conteúdo da pasta `lembrei`
2. Settings → Pages → Branch `main` → pasta `/root` → Save
3. O endereço fica `https://seu-usuario.github.io/nome-do-repo`

**Opção D · Cloudflare Pages** — https://pages.cloudflare.com → "Upload assets"

> ⚠️ Para notificações funcionarem o site **precisa estar em HTTPS**.
> Netlify, GitHub Pages e Cloudflare já entregam HTTPS de graça.
> Se você abrir o arquivo direto (`file://`) ou em `http://` simples, o celular
> bloqueia as notificações.

### Passo 2 — instalar no celular

**Android** (Chrome, Edge ou Samsung Internet)
1. Abra o endereço do site no navegador
2. Menu ⋮ → **"Instalar aplicativo"** ou **"Adicionar à tela inicial"**
3. Confirme. O ícone do Lembrei aparece junto dos outros apps

**iPhone / iPad** (precisa ser o **Safari**)
1. Abra o endereço no Safari
2. Botão **Compartilhar** (quadrado com seta para cima)
3. **"Adicionar à Tela de Início"** → Adicionar
4. Abra o app **pelo ícone** (não pelo Safari). Isso é obrigatório:
   o iPhone só permite notificações de PWA aberto pelo ícone, e só a partir do iOS 16.4

### Passo 3 — liberar as notificações

Na primeira vez o Lembrei pede permissão. Toque em **Permitir**.

Se você disse "não" ou o aviso não apareceu:
- **Android:** Configurações do celular → Apps → Lembrei → Notificações → ativar.
  Também desative a economia de bateria para o Lembrei, senão o Android pode
  segurar os avisos.
- **iPhone:** Ajustes → Lembrei → Notificações → Permitir notificações.
  Precisa estar com "Som" e "Avisos" ligados.
- Dentro do app: **Ajustes ▸ Lembretes e notificações** mostra o estado atual
  e um botão para pedir de novo.

---

## 2. Como funcionam os lembretes (leia esta parte)

### O que você configura em cada conta

**Antecedências** — quantos dias antes avisar. Não há limite: 30, 15, 10, 7, 5,
3, 2, 1 dia antes, no dia do vencimento, ou qualquer número de 0 a 365.

**Horário próprio por lembrete** — cada antecedência tem a sua hora. Exemplo:
uma conta que vence em 20/11 pode avisar em 13/11 às 09:00, em 19/11 às 20:00
e em 20/11 às 07:00. O horário usa o fuso do seu celular.

**Repetição quando atrasa** — se a conta não for paga, o Lembrei continua
avisando: todo dia, a cada 2 dias, a cada 3 dias, toda semana, ou no intervalo
que você digitar (ex.: a cada 5 dias). Pode definir a hora do aviso de atraso e
uma data para parar — ou deixar em aberto até você marcar como paga.

Conta paga ou excluída **para de avisar na hora**. Nenhum aviso é enviado
para conta paga, e o mesmo aviso nunca é enviado duas vezes.

### Exemplo real

Conta de internet, R$ 120,00, vencimento 25/10/2026, lembretes de 3 dias antes
e no dia, ambos às 09:00:

| Quando | O que chega no celular |
|---|---|
| 22/10/2026 às 09:00 | **LEMBRETE DE CONTA** — Sua conta "Internet" vence daqui a 3 dias. Valor: R$ 120,00. |
| 25/10/2026 às 09:00 | **VENCIMENTO HOJE** — Não se esqueça de pagar sua conta "Internet". Valor: R$ 120,00. |

Se não for paga, e a repetição estiver em "todo dia" às 09:00:
26/10 → **CONTA ATRASADA** — Sua conta "Internet" está vencida há 1 dia.

### O limite honesto desta tecnologia

Um PWA **não tem permissão do sistema para acordar sozinho** com o app fechado.
O navegador encerra o código do app quando você o fecha. Isso vale para Android
e iPhone. Portanto:

- ✅ **App aberto ou em segundo plano:** os avisos saem na hora marcada, como
  notificação real do sistema (aparece na barra, com som e vibração).
- ✅ **Ao reabrir depois do horário:** o Lembrei verifica o que venceu e mostra
  na Central de lembretes, sem perder nada.
- ⚠️ **App 100% fechado e horário passando:** o aviso só aparece quando você
  abrir o app.

**Solução gratuita que fecha essa lacuna:** em **Ajustes ▸ Calendário (.ics)**
você exporta um arquivo e o importa na Agenda do celular, com alarmes reais.
A Agenda do sistema tem permissão de acordar com o aparelho fechado. É o
caminho sem custo para avisos com o app totalmente fechado.

**Solução definitiva (paga, opcional):** um app nativo via Capacitor
(veja `native/CAPACITOR.md`) — exige Mac/Xcode para iPhone e US$ 99/ano de conta
Apple; no Android exige cuidado com a economia de bateria dos fabricantes.

> O Lembrei **nunca finge** que uma notificação foi enviada. A Central mostra
> exatamente o que foi disparado e quando foi a última verificação.

---

## 3. Backup — leia antes de trocar de celular

Os dados ficam **só no seu aparelho**, num banco do próprio navegador
(IndexedDB). Nada é enviado para servidor nenhum. Isso é bom para a sua
privacidade e é o motivo de não existir conta nem mensalidade.

O lado ruim: se você desinstalar o app, limpar os dados do navegador ou trocar
de celular, os dados vão embora.

**Faça backup uma vez por mês:**
1. **Ajustes ▸ Fazer backup** → baixa um arquivo `.json`
2. Guarde esse arquivo no Google Drive, WhatsApp salvo em mensagens, e-mail
   para você mesmo, ou no computador
3. No celular novo: instale o Lembrei, abra **Ajustes ▸ Restaurar backup** e
   escolha o arquivo

Também existem **CSV** (abre no Excel e no Google Sheets) e **PDF**
(relatório para ler ou imprimir).

---

## 4. Dados das suas contas: onde ficam e como são protegidos

- Ficam no armazenamento do próprio navegador, na sua pasta de dados
- O app pede ao sistema para **não** apagar esses dados por falta de espaço
- Nenhuma informação sai do aparelho: não há servidor, login, chave de API ou
  banco de dados na nuvem
- Não é pedido nenhum dado bancário, CPF, senha ou número de cartão
- Como não há nuvem, também não há vazamento possível pela nuvem

Se um dia você quiser **sincronizar entre dois celulares**, será necessário um
servidor com autenticação. Isso tem custo e está documentado em
`opcional/push-server/README.md` — está desligado por padrão.

---

## 5. O que tem dentro de cada tela

**Painel** — total pendente, pago no mês, a pagar, vencidas, próximos 7 dias,
barra de progresso do mês e os próximos vencimentos.

**Contas** — busca por nome, filtros (todas, a vencer, vencidas, pagas,
categoria, mês) e ordenação. Toque numa conta para ver detalhes, editar,
duplicar ou marcar como paga.

**Calendário** — o mês inteiro com pontinhos coloridos por situação.
Toque num dia para ver as contas daquele dia.

**Relatórios** — histórico com filtros de período, categoria e busca,
resumo de pago e pendente, exportação em CSV e PDF.

**Lembretes (central)** — próximos avisos programados, com data e horário de
cada um, e o histórico do que já foi disparado.

**Ajustes** — seu nome, horário preferido, repetição padrão, tema claro/escuro,
backup/restauração, `.ics`, exportações, privacidade e exclusão de tudo.

---

## 6. Contas de exemplo

Na primeira abertura entram 6 contas marcadas com o selo **EXEMPLO**.
Elas servem para você ver o app funcionando e **nunca disparam notificações**.
Quando quiser limpar: **Ajustes ▸ Remover contas de exemplo**.

---

## 7. Mexer no código (opcional)

Tudo é HTML, CSS e JavaScript puro. Não precisa instalar nada, nem compilar.

| Arquivo | O que faz |
|---|---|
| `index.html` | estrutura da página |
| `css/styles.css` | aparência (cores no topo do arquivo em `:root`) |
| `js/utils.js` | formatação de datas e valores |
| `js/modelo.js` | regras de lembrete, repetição e mensagens |
| `js/store.js` | salvar e ler os dados |
| `js/relatorios.js` | CSV, PDF, `.ics` e backup |
| `js/views.js`, `js/views-mais.js` | telas |
| `js/formulario.js` | formulário de conta e editor de lembretes |
| `js/app.js` | navegação, botões e motor de avisos |
| `sw.js` | cache offline e notificações |

**Ao publicar uma alteração:** mude a linha `const VERSAO = 'lembrei-v2.0.2';`
no topo de `sw.js` (ex.: `lembrei-v2.0.3`). Sem isso o celular pode continuar
mostrando a versão antiga guardada em cache. Depois envie a pasta de novo para
o Netlify (arrastar e soltar substitui o site).

**Rodar no computador para testar:**
```bash
cd lembrei
python3 -m http.server 8000
```
Abra `http://localhost:8000`.

---

## 8. Perguntas frequentes

**Preciso pagar alguma coisa?** Não. Hospedagem gratuita, sem servidor, sem
mensalidade. O único custo possível é se um dia você publicar nas lojas
(Play Store tem taxa única; App Store US$ 99/ano).

**Funciona sem internet?** Sim. Depois de instalar, o app abre e salva tudo
offline.

**Meus dados vão para algum lugar?** Não saem do aparelho.

**Troquei de celular e perdi tudo.** Restaure o backup `.json`. Sem backup não
há como recuperar — os dados nunca existiram fora do aparelho antigo.

**O aviso não apareceu com o app fechado.** É o limite do PWA descrito na
seção 2. Use o `.ics` na Agenda ou considere a versão nativa.

**Mudei o vencimento, e os lembretes?** São recalculados automaticamente a
partir da nova data, e o aviso antigo deixa de existir (sem duplicar).

**Marquei como paga por engano.** Toque em **Desfazer** na confirmação, ou abra
a conta no histórico e use "Desfazer pagamento".

**Posso ter mais de um lembrete no mesmo dia?** Sim, mas com horários
diferentes — o app impede duplicar a mesma antecedência e explica o motivo.

---

# Versão 3 — organizador pessoal

## O que foi acrescentado

**Meu dia** — a primeira tela agora resume: compromissos de hoje, contas vencendo,
medicamentos do dia, treinos e jogos, tarefas pendentes e manutenção do veículo.
Cada linha mostra a quantidade e leva para a lista filtrada.

**Compromissos** — nova aba com seis tipos: 💊 medicamento, 🏥 consulta,
🏐 treino ou jogo, 📚 estudo e tarefa, 🎉 aniversário, 🚗 veículo.

**Preparar para o compromisso** — dentro de qualquer compromisso você monta os
avisos que quiser, cada um com a hora dele. Exemplo do jogo de vôlei às 19h:
"Separar uniforme às 16h", "Preparar a mochila às 17h", "Sair de casa às 18h".
O botão **Sugerir horários** calcula as horas a partir do tempo de deslocamento que
você digita e da hora que quer chegar — mas os avisos só existem depois que você
toca em Salvar. Nada é criado sozinho.

**Medicamentos** — nome, vários horários de dose (ex.: 08:00 e 20:00), data de
início e fim, dias da semana. O app avisa em cada horário. Os horários são os que
**você** recebeu do profissional de saúde; o app não sugere dose nem frequência.

**Treino/jogo** — local, minutos de deslocamento, hora que quer chegar, avisos de
preparação e lista de itens para levar (uniforme, tênis, joelheira, água), com
marcação de cada item separado.

**Concluir interrompe os avisos** — ao concluir um compromisso, todos os avisos dele
param. Marcar conta como paga continua cancelando os avisos dela.

## Testar as notificações do seu aparelho

Na aba **Compromissos**, cartão "Testar as notificações deste aparelho":
- **Testar agora** — dispara na hora, com som do app (quando o aparelho permite).
- **Testar em 2 min** — cria um lembrete marcado como **TESTE**, que não se mistura
  com seus dados e pode ser excluído no próprio cartão dele.

Para conferir de verdade: toque em "Testar em 2 min", **saia do app** (vá para a
tela inicial do celular) e espere. Se a notificação chegar com o app em segundo
plano, os avisos estão funcionando nesse aparelho.

## Correções do modo escuro

Campos de data, hora, mês, listas suspensas, caixas de seleção, interruptores,
diálogos, chips, selos e o calendário financeiro foram todos corrigidos com
variáveis de tema. A correção principal é a propriedade `color-scheme`, que faz o
navegador desenhar o calendário e o relógio nativos já no tom certo — sem ela, o
Chrome no Android abria o calendário branco mesmo com o app escuro. Também foi
corrigido o ícone do calendário (que vinha preto no fundo escuro) e os campos de
dias/horas do editor de lembretes.

## Notificação com o app fechado

Continua igual, e a explicação honesta é esta: **um PWA não recebe permissão do
sistema para acordar sozinho quando está fechado.** Com o app aberto ou em segundo
plano o aviso é real; com o app 100% fechado ele aparece quando você abrir o app
(na Central de lembretes, sem perder nada).

Duas saídas **gratuitas** que já estão no app:
1. **Ajustes ▸ Calendário (.ics)** — alarmes reais na Agenda do celular, que pode
   tocar com o aparelho fechado.
2. **Versão Android com Capacitor** (veja `native/ANDROID-CAPACITOR.md`) — embrulha
   o mesmo app em um aplicativo instalado, que pode agendar alarmes no sistema.

A rota paga (servidor de push) existe, mas envia seus dados para fora do aparelho —
não é necessária para começar.
