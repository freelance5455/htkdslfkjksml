# Servidor de Web Push (OPCIONAL — não está ativo)

Este é o **único** caminho que dispara avisos com o app totalmente fechado, sem virar app nativo.
**Nada aqui está ligado no app por padrão.** O Service Worker já traz o handler de `push` pronto
(`sw.js`), mas sem este servidor configurado ele nunca é acionado.

## O que você precisa entender antes

- Um servidor precisa ficar rodando 24 horas por dia para, na hora certa, enviar a mensagem ao navegador.
- Isso **não é de graça para sempre**: há planos gratuitos com limite de mensagens e requisições; acima do limite, é pago.
- No **iPhone**, o push só funciona com o app **adicionado à Tela de Início** e iOS **16.4 ou superior**.
- Se você deixar de pagar ou o servidor cair, os avisos param — o que **não** acontece com o arquivo `.ics` nem com a versão nativa, que continuam funcionando para sempre.

## Como funciona (resumo honesto)

1. O app pede permissão e se inscreve no serviço de push do navegador, recebendo um endereço único (endpoint).
2. Esse endpoint é enviado para o seu servidor, junto com as contas e os horários de lembrete.
3. Quando chega a hora de um lembrete, o servidor envia a mensagem assinada com sua chave VAPID.
4. O navegador acorda o Service Worker do Lembrei, que mostra a notificação.

Repare no ponto 2: passar as contas para um servidor significa que seus dados **saem do seu aparelho**. Essa é a razão de isso ser opcional e documentado separadamente — a promessa de privacidade do Lembrei ("seus dados ficam só no seu aparelho") vale para o app como ele está.

## Esqueleto mínimo (Node.js)

```bash
npm init -y
npm install express web-push
npx web-push generate-vapid-keys   # gera sua chave pública e a privada
```

```js
// server.js — esqueleto didático, precisa de banco de dados e lógica de agendamento
const express = require('express');
const webpush = require('web-push');
const app = express();

const PUBLIC_KEY = process.env.VAPID_PUBLIC;
const PRIVATE_KEY = process.env.VAPID_PRIVATE;

webpush.setVapidDetails('mailto:voce@exemplo.com', PUBLIC_KEY, PRIVATE_KEY);

let inscricao = null;   // em produção: salvar em banco de dados, junto das contas

app.use(express.json());

// o app envia a inscrição do navegador para cá
app.post('/inscrever', (req, res) => {
  inscricao = req.body;
  res.sendStatus(201);
});

// um agendador (cron) chama isto na hora de cada lembrete
app.post('/disparar', async (req, res) => {
  if (!inscricao) return res.sendStatus(400);
  await webpush.sendNotification(inscricao, JSON.stringify({
    title: 'Conta a vencer: Internet',
    body: 'R$ 120,00 • vence em 25/10/2026',
    tag: 'lembrei-internet-20261025',
    url: './index.html#notificacoes'
  }));
  res.sendStatus(200);
});

app.listen(3000);
```

No app, a inscrição é assim (cole a chave **pública** gerada acima):

```js
const reg = await navigator.serviceWorker.ready;
const inscricao = await reg.pushManager.subscribe({
  userVisibleOnly: true,
  applicationServerKey: '<COLE_AQUI_A_CHAVE_PUBLICA_VAPID>'
});
await fetch('https://SEU-SERVIDOR/inscrever', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(inscricao)
});
```

Onde hospedar pequeno e barato: Render, Railway, Fly.io ou Cloudflare Workers (este último tem camada gratuita generosa). Confirme os limites atuais de cada serviço — eles mudam com frequência.

## Comparação dos três caminhos

| Caminho | Funciona com app fechado | Custo | Seus dados saem do aparelho |
|---|---|---|---|
| Central de lembretes + aviso com o app aberto | Não | R$ 0 | Não |
| Arquivo Calendário `.ics` | **Sim** | R$ 0 | Não |
| Versão nativa (Capacitor + Local Notifications) | **Sim** | R$ 0 para uso próprio (taxa só para publicar) | Não |
| Servidor de Web Push | **Sim** | Plano gratuito com limite, depois pago | **Sim** |
