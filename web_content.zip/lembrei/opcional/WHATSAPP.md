# WhatsApp como canal de lembrete — avaliação (não implementado)

> **Não implementado, não ativado, nenhuma mensagem enviada.**
> Esta é a avaliação pedida: o que seria necessário, quanto custa e por que
> continua desligado.

## Resposta curta

É possível, mas **não é gratuito** e **exige servidor**. O Lembrei hoje funciona
sem servidor nenhum, com os dados só no seu aparelho. Por isso a decisão é:
**primeiro as notificações do próprio celular (R$ 0), WhatsApp só depois e só se
você quiser pagar.**

## O que a via oficial exige

A única forma legítima é a **WhatsApp Business Platform** (Cloud API, da Meta).
Qualquer "truque" (biblioteca não oficial, automação de WhatsApp Web) viola os
termos, derruba o número e pode virar processo — não farei isso.

| Item | O que é preciso |
|---|---|
| Conta | Meta Business Suite + conta de desenvolvedor |
| Verificação | Verificação do negócio (documentos da empresa/MEI) |
| Número | Um número comercial dedicado, que **não** pode estar em uso no WhatsApp comum |
| Modelos | Cada mensagem precisa ser um **template aprovado** pela Meta antes do envio |
| Servidor | Um backend que guarde o token e chame a API — não pode estar no app |
| Credenciais | Token permanente + ID do número; **nunca** no código público |

A Meta cria automaticamente uma conta de teste, um número de teste e um token de
teste ao começar, o que permite validar o fluxo antes de pagar
([Meta for Developers — About the platform](https://developers.facebook.com/documentation/business-messaging/whatsapp/about-the-platform),
[Get started](https://developers.facebook.com/documentation/business-messaging/whatsapp/get-started)).

## Custo

Desde 1º de outubro de 2026 a cobrança é **por mensagem**, conforme categoria e
país de destino ([Meta — Pricing](https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing)).

- Mensagem de **utilidade** (é o caso de lembrete de conta): a mais barata das
  categorias.
- Mensagem de marketing: por exemplo US$ 0,0250 na América do Norte
  ([DragApp, jul/2026](https://www.dragapp.com/blog/whatsapp-business-api-pricing/)) e
  cerca de US$ 0,0625 por conversa na região "Resto da América Latina", que é onde
  o Brasil se enquadra ([Ominiflow](https://ominiflow.com/whatsapp-api-pricing/brazil)).
- Some o custo do servidor (ligado 24 h) para disparar as mensagens nos horários.

**Os valores mudam com frequência e por país — confirme na página oficial da Meta
antes de decidir.** Não vou estimar um valor fechado para você sem isso.

## Como seria montado (sem ativar)

1. Item novo com `canais: { celular: true, whatsapp: false }` — assim você escolhe
   por lembrete se quer só no celular, só no WhatsApp, ou os dois.
2. Um endpoint no servidor (`/enviar`) que recebe `{ para, template, variaveis, quando }`.
3. Um agendador no servidor (cron) que lê os lembretes e chama a Cloud API na hora.
4. Template aprovado, algo como:
   `Olá {{1}}, sua conta {{2}} vence em {{3}} dias. Valor: R$ {{4}}.`
5. O app **nunca** guarda o token: ele só fala com o *seu* servidor.

Enquanto não houver servidor, o botão de WhatsApp fica visível mas desligado, com
um aviso explicando o motivo — nada de simulação, nada de mensagem falsa.

## Ordem recomendada

1. **Agora:** notificações do próprio celular (grátis, já implementadas).
2. **Grátis, cobre app fechado:** arquivo `.ics` na Agenda do celular (já existe).
3. **Depois, se quiser aviso com app 100% fechado:** versão Android com Capacitor
   (veja `native/ANDROID-CAPACITOR.md`, também R$ 0 de mensalidade).
4. **Só então:** WhatsApp, se você aceitar o custo por mensagem + servidor.
