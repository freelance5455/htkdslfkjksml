/* ==========================================================================
   Lembrei — store.js
   Persistência REAL e permanente dos dados:
   1) IndexedDB (padrão em Android, iPhone/Safari 10+, Chrome, Firefox).
   2) Se o navegador não tiver IndexedDB, cai automaticamente para
      localStorage (mesma API assíncrona) — o app nunca perde dados por isso.
   Os dados ficam SOMENTE no aparelho do usuário: não há servidor, não há
   cadastro e nada é enviado para a internet.
   ========================================================================== */
(function (raiz) {
  'use strict';

  const Store = {};
  const NOME_BD = 'lembrei';
  const VERSAO_BD = 2;   // v2: nova loja 'itens' (organizador pessoal).
                         // O IndexedDB só ACRESCENTA lojas no upgrade: nenhum
                         // dado existente é apagado ou reescrito.
  const LOJAS = ['contas', 'notificacoes', 'config', 'itens'];

  let bd = null;
  let modo = 'idb'; // 'idb' | 'localStorage'
  const cache = { contas: [], notificacoes: [], config: null, itens: [] };

  /* ------------------------------ IndexedDB ------------------------------- */
  function abrirIDB() {
    return new Promise(function (res, rej) {
      if (!raiz.indexedDB) return rej(new Error('sem-indexeddb'));
      let req;
      try { req = raiz.indexedDB.open(NOME_BD, VERSAO_BD); } catch (e) { return rej(e); }
      req.onupgradeneeded = function (ev) {
        const db = ev.target.result;
        if (!db.objectStoreNames.contains('contas')) db.createObjectStore('contas', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('notificacoes')) db.createObjectStore('notificacoes', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('config')) db.createObjectStore('config', { keyPath: 'chave' });
        if (!db.objectStoreNames.contains('itens')) db.createObjectStore('itens', { keyPath: 'id' });
      };
      req.onsuccess = function () { res(req.result); };
      req.onerror = function () { rej(req.error || new Error('erro-idb')); };
      req.onblocked = function () { rej(new Error('idb-bloqueado')); };
    });
  }
  function pedir(req) {
    return new Promise(function (res, rej) {
      req.onsuccess = function () { res(req.result); };
      req.onerror = function () { rej(req.error); };
    });
  }

  /* --------------------- fallback: localStorage --------------------------- */
  const LS = {
    ler: function (loja) {
      try { return JSON.parse(raiz.localStorage.getItem('lembrei:' + loja) || '[]'); } catch (e) { return []; }
    },
    gravar: function (loja, arr) { raiz.localStorage.setItem('lembrei:' + loja, JSON.stringify(arr)); },
    todos: function (loja) { return Promise.resolve(LS.ler(loja)); },
    put: function (loja, obj) {
      const arr = LS.ler(loja);
      const chave = obj.id || obj.chave;
      const i = arr.findIndex(function (x) { return (x.id || x.chave) === chave; });
      if (i >= 0) arr[i] = obj; else arr.push(obj);
      LS.gravar(loja, arr);
      return Promise.resolve(obj);
    },
    del: function (loja, id) {
      LS.gravar(loja, LS.ler(loja).filter(function (x) { return (x.id || x.chave) !== id; }));
      return Promise.resolve();
    },
    clear: function (loja) { LS.gravar(loja, []); return Promise.resolve(); }
  };

  function tx(loja, tipo) { return bd.transaction(loja, tipo).objectStore(loja); }

  Store.todosBrutos = async function (loja) {
    if (modo === 'idb' && bd) return (await pedir(tx(loja, 'readonly').getAll())) || [];
    return LS.todos(loja);
  };
  Store.putBruto = async function (loja, obj) {
    if (modo === 'idb' && bd) { await pedir(tx(loja, 'readwrite').put(obj)); return obj; }
    return LS.put(loja, obj);
  };
  Store.delBruto = async function (loja, id) {
    if (modo === 'idb' && bd) { await pedir(tx(loja, 'readwrite').delete(id)); return; }
    return LS.del(loja, id);
  };
  Store.limparBruto = async function (loja) {
    if (modo === 'idb' && bd) { await pedir(tx(loja, 'readwrite').clear()); return; }
    return LS.clear(loja);
  };

  /* -------------------------------- config -------------------------------- */
  Store.configPadrao = function () {
    return {
      chave: 'config',
      valor: {
        nome: '',
        hora: '09:00',
        lembretes: [7, 3, 1, 0],
        repeticaoPadrao: { modo: 'diaria', intervalo: null, hora: '09:00', fim: '' },
        tema: 'auto',
        moeda: 'BRL',
        onboardingVisto: false,
        exemplosCarregados: false,
        enviados: {},
        criadoEm: new Date().toISOString()
      }
    };
  };

  /* --------------------------------- API ---------------------------------- */
  Store.init = async function () {
    const problemas = [];
    try {
      bd = await abrirIDB();
      modo = 'idb';
    } catch (e) {
      bd = null;
      modo = 'localStorage';
      problemas.push('IndexedDB indisponível (' + (e && e.message) + '); usando localStorage.');
    }
    cache.contas = await Store.todosBrutos('contas');
    cache.notificacoes = await Store.todosBrutos('notificacoes');
    cache.itens = await Store.todosBrutos('itens');
    const cfgs = await Store.todosBrutos('config');
    const achado = cfgs.filter(function (c) { return c.chave === 'config'; })[0];
    cache.config = achado ? achado.valor : null;
    if (!cache.config) {
      const novo = Store.configPadrao();
      cache.config = novo.valor;
      await Store.putBruto('config', novo);
    }
    cache.config.lembretes = Array.isArray(cache.config.lembretes) ? cache.config.lembretes : [7, 3, 1, 0, -1];
    if (!cache.config.enviados) cache.config.enviados = {};
    // migra contas do formato antigo (lembretes = [7,3,1,0,-1]) sem perder nada
    let migradas = 0;
    for (const c of cache.contas) {
      try {
        if (U.migrarConta(c, cache.config)) { await Store.putBruto('contas', c); migradas++; }
      } catch (e) { problemas.push('Falha ao migrar conta ' + c.id + ': ' + e.message); }
    }
    if (migradas) problemas.push(migradas + ' conta(s) migrada(s) para o novo formato de lembretes (nada foi apagado).');
    Store.ordenarContas();
    return { modo: modo, problemas: problemas };
  };

  Store.modo = function () { return modo; };
  Store.contas = function () { return cache.contas; };
  Store.notificacoes = function () { return cache.notificacoes; };
  Store.itens = function () { return cache.itens; };
  Store.config = function () { return cache.config; };
  Store.ordenarContas = function () {
    cache.contas.sort(function (a, b) {
      return String(a.vencimento).localeCompare(String(b.vencimento)) || String(a.nome).localeCompare(String(b.nome), 'pt-BR');
    });
  };

  Store.obterConta = function (id) {
    return cache.contas.filter(function (c) { return c.id === id; })[0] || null;
  };

  Store.salvarConta = async function (conta) {
    conta.atualizadoEm = new Date().toISOString();
    const i = cache.contas.findIndex(function (c) { return c.id === conta.id; });
    if (i >= 0) cache.contas[i] = conta; else cache.contas.push(conta);
    Store.ordenarContas();
    await Store.putBruto('contas', conta);
    return conta;
  };

  Store.excluirConta = async function (id) {
    cache.contas = cache.contas.filter(function (c) { return c.id !== id; });
    await Store.delBruto('contas', id);
  };

  Store.salvarConfig = async function (parcial) {
    cache.config = Object.assign(cache.config, parcial || {});
    await Store.putBruto('config', { chave: 'config', valor: cache.config });
    return cache.config;
  };

  Store.registrarNotificacao = async function (n) {
    cache.notificacoes.unshift(n);
    if (cache.notificacoes.length > 200) cache.notificacoes = cache.notificacoes.slice(0, 200);
    await Store.putBruto('notificacoes', n);
    return n;
  };
  Store.limparNotificacoes = async function () {
    cache.notificacoes = [];
    await Store.limparBruto('notificacoes');
  };

  /* ------------------- organizador pessoal (itens) ------------------------ */
  Store.salvarItem = async function (item) {
    const i = cache.itens.findIndex(function (x) { return x.id === item.id; });
    if (i >= 0) cache.itens[i] = item; else cache.itens.push(item);
    await Store.putBruto('itens', item);
    return item;
  };
  Store.excluirItem = async function (id) {
    cache.itens = cache.itens.filter(function (x) { return x.id !== id; });
    await Store.delBruto('itens', id);
  };
  Store.limparItens = async function () {
    cache.itens = [];
    await Store.limparBruto('itens');
  };

  /* ---------------------- ja enviados (anti-duplicidade) ------------------- */
  Store.jaEnviado = function (chave) { return !!cache.config.enviados[chave]; };
  Store.marcarEnviado = async function (chave, quando) {
    cache.config.enviados[chave] = quando || new Date().toISOString();
    const chaves = Object.keys(cache.config.enviados);
    if (chaves.length > 600) {
      chaves.sort().slice(0, chaves.length - 600).forEach(function (k) { delete cache.config.enviados[k]; });
    }
    await Store.salvarConfig({ enviados: cache.config.enviados });
  };

  /* ------------------------------- exportar -------------------------------- */
  Store.exportar = function () {
    return {
      app: 'Lembrei',
      formato: 'lembrei-backup',
      versao: 1,
      geradoEm: new Date().toISOString(),
      contas: cache.contas.slice(),
      notificacoes: cache.notificacoes.slice(0, 200),
      itens: cache.itens.slice(),
      config: cache.config
    };
  };

  Store.importar = async function (pacote, substituir) {
    if (!pacote || typeof pacote !== 'object') throw new Error('Arquivo inválido.');
    if (!Array.isArray(pacote.contas)) throw new Error('O arquivo não contém uma lista de contas.');
    const validas = pacote.contas.filter(function (c) { return c && c.id && c.nome && c.vencimento; });
    if (!validas.length) throw new Error('Nenhuma conta válida encontrada no arquivo.');
    if (substituir) {
      await Store.limparBruto('contas');
      await Store.limparBruto('notificacoes');
      await Store.limparBruto('itens');
      cache.contas = [];
      cache.notificacoes = [];
      cache.itens = [];
    }
    for (const c of validas) {
      const existente = cache.contas.filter(function (x) { return x.id === c.id; })[0];
      const conta = Object.assign({
        id: U.uid(),
        valor: 0,
        categoria: 'outros',
        recorrencia: 'nenhuma',
        lembretes: [7, 0],
        hora: (cache.config.hora || '09:00'),
        pago: false,
        pagoEm: '',
        descricao: '',
        beneficiario: '',
        serieId: '',
        diaAncora: U.deISO(c.vencimento).getDate(),
        criadoEm: new Date().toISOString(),
        demo: false
      }, existente || {}, c);
      conta.diaAncora = conta.diaAncora || U.deISO(conta.vencimento).getDate();
      conta.lembretes = Array.isArray(conta.lembretes) ? conta.lembretes : [7, 0];
      await Store.salvarConta(conta);
    }
    if (Array.isArray(pacote.itens)) {
      for (const it of pacote.itens) {
        if (it && it.id && (it.titulo || it.tipo)) {
          it.tipo = it.tipo || 'estudo';
          it.preparos = Array.isArray(it.preparos) ? it.preparos : [];
          await Store.putBruto('itens', it);
        }
      }
      cache.itens = await Store.todosBrutos('itens');
    }
    if (pacote.config && pacote.config.nome !== undefined) {
      const cfg = Object.assign({}, pacote.config);
      cfg.enviados = cfg.enviados || {};
      cfg.chave = undefined;
      await Store.salvarConfig(cfg);
    }
    return validas.length;
  };

  Store.apagarTudo = async function () {
    for (const loja of LOJAS) await Store.limparBruto(loja);
    cache.contas = [];
    cache.notificacoes = [];
    cache.itens = [];
    const novo = Store.configPadrao();
    cache.config = novo.valor;
    cache.config.onboardingVisto = true; // não repete a introdução
    await Store.putBruto('config', { chave: 'config', valor: cache.config });
  };

  Store.excluirExemplos = async function () {
    const exemplos = cache.contas.filter(function (c) { return c.demo; });
    for (const c of exemplos) await Store.excluirConta(c.id);
    await Store.salvarConfig({ exemplosCarregados: true });
    return exemplos.length;
  };

  Store.pedirPersistencia = async function () {
    try {
      if (raiz.navigator && navigator.storage && navigator.storage.persist) {
        const concedido = await navigator.storage.persist();
        return concedido;
      }
    } catch (e) { /* ignore */ }
    return false;
  };
  Store.estimativaUso = async function () {
    try {
      if (raiz.navigator && navigator.storage && navigator.storage.estimate) {
        const e = await navigator.storage.estimate();
        return { uso: e.usage || 0, cota: e.quota || 0, persistente: (navigator.storage.persisted ? await navigator.storage.persisted() : false) };
      }
    } catch (e) { /* ignore */ }
    return null;
  };

  raiz.Store = Store;
  if (typeof module !== 'undefined' && module.exports) module.exports = Store;
})(typeof window !== 'undefined' ? window : globalThis);
