/* ==========================================================================
   Lembrei — relatorios.js
   Exportação real de dados: CSV (Excel), arquivo de backup (JSON) e
   calendário .ics (que gera LEMBRETES REAIS no app de calendário do celular,
   inclusive com o Lembrei fechado — recurso gratuito e honesto).
   O "PDF" usa a impressão do navegador ("Salvar como PDF"), que funciona
   no Android e no iPhone sem nenhuma biblioteca paga.
   ========================================================================== */
(function (raiz) {
  'use strict';
  const R = {};

  R.baixar = function (nomeArquivo, conteudo, tipo) {
    const blob = conteudo instanceof Blob ? conteudo : new Blob([conteudo], { type: tipo || 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = nomeArquivo;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 1200);
    return nomeArquivo;
  };

  R.seloStatus = function (conta) {
    if (conta.pago) return 'Paga';
    const s = U.status(conta);
    if (s === 'atrasada') return 'Atrasada';
    if (s === 'proxima') return 'Vence em breve';
    return 'A vencer';
  };

  /* ---------------------------------- CSV --------------------------------- */
  R.csv = function (contas) {
    const cab = ['Nome', 'Valor (R$)', 'Vencimento', 'Categoria', 'Situacao', 'Pago em', 'Recorrencia', 'Beneficiario', 'Descricao', 'Exemplo'];
    const linhas = [cab.join(';')];
    U.ordenar(contas, 'vencimento').forEach(function (c) {
      const campos = [
        c.nome,
        (Number(c.valor) || 0).toFixed(2).replace('.', ','),
        U.fmtData(c.vencimento),
        U.categoria(c.categoria).nome,
        R.seloStatus(c),
        c.pago ? U.fmtData((c.pagoEm || '').slice(0, 10)) : '',
        U.rotuloRecorrencia(c.recorrencia),
        c.beneficiario || '',
        c.descricao || '',
        c.demo ? 'SIM' : ''
      ];
      linhas.push(campos.map(function (v) {
        const t = String(v == null ? '' : v).replace(/[\r\n]+/g, ' ');
        return /[;"\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t;
      }).join(';'));
    });
    return '\ufeff' + linhas.join('\r\n');
  };

  /* -------------------------- ocorrências futuras -------------------------- */
  /** Lista as datas de vencimento de uma conta entre inicio e fim (ISO). */
  R.ocorrencias = function (conta, inicio, fim, limite) {
    const out = [];
    const ancora = conta.diaAncora || U.deISO(conta.vencimento).getDate();
    let data = conta.vencimento;
    let trava = 0;
    while (data < inicio && trava++ < 600) {
      const prox = U.proximaDe(data, conta.recorrencia, ancora);
      if (!prox) return out;
      data = prox;
    }
    while (data <= fim && out.length < (limite || 60) && trava++ < 900) {
      out.push(data);
      const prox = U.proximaDe(data, conta.recorrencia, ancora);
      if (!prox) break;
      if (conta.recorrenciaFim && prox > conta.recorrenciaFim) break;
      data = prox;
    }
    return out;
  };

  /* ----------------------------------- ICS -------------------------------- */
  function dobraIcs(linha) {
    if (linha.length <= 74) return linha;
    const pedacos = [];
    let resto = linha;
    while (resto.length > 74) {
      pedacos.push(resto.slice(0, 74));
      resto = resto.slice(74);
    }
    pedacos.push(resto);
    return pedacos.join('\r\n ');
  }
  function semQuebra(txt) {
    return String(txt == null ? '' : txt).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/[\r\n]+/g, ' ').slice(0, 180);
  }
  function dataIcs(iso, horaCompleta) {
    if (!horaCompleta) return iso.replace(/-/g, '');
    const [a, m, d] = iso.split('-');
    return a + m + d + 'T' + horaCompleta.replace(':', '') + '00';
  }
  /**
   * Cria um VALARM para um lembrete.
   * Se o horário do lembrete é igual ao do evento, usa gatilho relativo (TRIGGER:-P7D).
   * Se é diferente, usa gatilho absoluto (TRIGGER;VALUE=DATE-TIME:...), que é o único
   * jeito de um alarme de calendário respeitar um horário próprio por lembrete.
   */
  function alarme(lembrete, resumo, dataEvento, horaEvento) {
    const dias = Math.max(0, Number(lembrete && lembrete.dias) || 0);
    const hora = (lembrete && lembrete.hora) || horaEvento;
    let gatilho;
    if (hora === horaEvento) {
      gatilho = dias === 0 ? 'TRIGGER;RELATED=START:PT0M' : 'TRIGGER:-P' + dias + 'D';
    } else {
      const data = U.addDias(dataEvento, -dias);
      gatilho = 'TRIGGER;VALUE=DATE-TIME:' + dataIcs(data, hora);
    }
    return [
      'BEGIN:VALARM',
      'ACTION:DISPLAY',
      dobraIcs('DESCRIPTION:' + semQuebra(resumo)),
      gatilho,
      'END:VALARM'
    ];
  }

  R.ics = function (contas, config, hojeISO) {
    const hoje = hojeISO || U.hojeISO();
    const inicio = U.addDias(hoje, -45);
    const fim = U.addDias(hoje, 240);
    const linhas = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Lembrei//Contas a pagar//PT-BR',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
      dobraIcs('X-WR-CALNAME:Lembrei — Contas a pagar'),
      dobraIcs('X-WR-CALDESC:Contas cadastradas no app Lembrei, com alarmes antes do vencimento.'),
      'X-WR-TIMEZONE:America/Sao_Paulo'
    ];
    let n = 0;
    contas.filter(function (c) { return !c.demo; }).forEach(function (c) {
      const lembretes = U.lembretesNormalizados(c, config);
      const datas = R.ocorrencias(c, inicio, fim, 26);
      datas.forEach(function (data) {
        if (c.pago && data === c.vencimento) return; // ocorrência já paga
        n++;
        const hora = c.hora || config.hora || '09:00';
        const titulo = 'Pagar ' + c.nome + ' — ' + U.fmtBRL(c.valor);
        const desc = [c.nome, 'Valor: ' + U.fmtBRL(c.valor), 'Categoria: ' + U.categoria(c.categoria).nome,
          c.beneficiario ? 'Beneficiário: ' + c.beneficiario : '', c.descricao ? 'Obs.: ' + c.descricao : '',
          'Gerado pelo app Lembrei'].filter(Boolean).join('\n');
        linhas.push('BEGIN:VEVENT');
        linhas.push('UID:' + c.id + '-' + data.replace(/-/g, '') + '@lembrei-app');
        linhas.push('DTSTAMP:' + new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+Z$/, 'Z'));
        linhas.push('DTSTART:' + dataIcs(data, hora));
        linhas.push('DTEND:' + dataIcs(data, hora));
        linhas.push(dobraIcs('SUMMARY:' + semQuebra(titulo)));
        linhas.push(dobraIcs('DESCRIPTION:' + semQuebra(desc)));
        linhas.push(dobraIcs('CATEGORIES:' + semQuebra(U.categoria(c.categoria).nome)));
        lembretes.forEach(function (L) {
          alarme(L, titulo, data, hora).forEach(function (l) { linhas.push(l); });
        });
        const _rep = U.normalizarRepeticao(c, config);
        const _inter = U.intervaloRepeticao(_rep);
        if (_inter) {
          linhas.push('BEGIN:VALARM');
          linhas.push('ACTION:DISPLAY');
          linhas.push(dobraIcs('DESCRIPTION:' + semQuebra('CONTA ATRASADA — ' + titulo)));
          linhas.push('TRIGGER:P' + _inter + 'D');
          linhas.push('END:VALARM');
        }
        linhas.push('END:VEVENT');
      });
    });
    linhas.push('END:VCALENDAR');
    return { texto: linhas.join('\r\n'), eventos: n };
  };

  /* --------------------------- impressão (PDF) ---------------------------- */
  R.imprimir = function (html, titulo) {
    const janela = window.open('', '_blank');
    if (!janela) return false;
    janela.document.write(
      '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>' + U.esc(titulo || 'Lembrei') + '</title>' +
      '<style>body{font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;padding:26px;color:#12233a}' +
      'h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 8px}' +
      '.sub{color:#697d95;font-size:12px;margin-bottom:18px}' +
      'table{width:100%;border-collapse:collapse;font-size:12.5px;margin-bottom:16px}' +
      'th,td{border-bottom:1px solid #e4ebf4;padding:8px 6px;text-align:left}' +
      'th{background:#f4f7fb;font-size:11.5px;text-transform:uppercase;letter-spacing:.04em}' +
      'td.v{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}' +
      '.rodape{margin-top:26px;font-size:11px;color:#8ea0b5}' +
      '@media print{@page{margin:14mm}}</style></head><body>' + html +
      '<p class="rodape">Gerado pelo app Lembrei em ' + U.fmtDataHora(new Date().toISOString()) + ' — dados salvos apenas no aparelho.</p>' +
      '</body></html>'
    );
    janela.document.close();
    janela.focus();
    setTimeout(function () { try { janela.print(); } catch (e) { /* usuário pode imprimir manualmente */ } }, 450);
    return true;
  };

  R.htmlRelatorio = function (contas, resumo, periodo) {
    const l = [];
    l.push('<h1>Relatório de contas — Lembrei</h1>');
    l.push('<p class="sub">Período: ' + U.esc(periodo) + ' • ' + contas.length + ' conta(s)</p>');
    l.push('<h2>Resumo</h2><table><tr><th>Indicador</th><th>Valor</th></tr>');
    resumo.forEach(function (r) {
      l.push('<tr><td>' + U.esc(r[0]) + '</td><td class="v">' + U.esc(r[1]) + '</td></tr>');
    });
    l.push('</table><h2>Contas</h2><table><tr><th>Conta</th><th>Vencimento</th><th>Categoria</th><th>Situação</th><th>Valor</th></tr>');
    U.ordenar(contas, 'vencimento').forEach(function (c) {
      l.push('<tr><td>' + U.esc(c.nome) + '</td><td>' + U.fmtData(c.vencimento) + '</td><td>' + U.esc(U.categoria(c.categoria).nome) +
        '</td><td>' + R.seloStatus(c) + '</td><td class="v">' + U.fmtBRL(c.valor) + '</td></tr>');
    });
    l.push('</table>');
    return l.join('');
  };

  raiz.Relatorios = R;
  if (typeof module !== 'undefined' && module.exports) module.exports = R;
})(typeof window !== 'undefined' ? window : globalThis);
