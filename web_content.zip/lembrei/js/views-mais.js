/* ==========================================================================
   Lembrei — views-mais.js
   Calendário financeiro, histórico/relatórios, central de lembretes,
   ajustes e telas de ajuda (privacidade, instalação, publicação).
   ========================================================================== */
(function (raiz) {
  'use strict';
  const M = {};
  const U = raiz.U;

  /* ------------------------------ calendário ------------------------------- */
  M.calendario = function () {
    const contas = raiz.Store.contas();
    const hoje = U.hojeISO();
    const mesRef = raiz.App.estado.mesCal || U.mesDe(hoje);
    const [anoS, mesS] = mesRef.split('-');
    const ano = Number(anoS), mes = Number(mesS);
    const primeiro = new Date(ano, mes - 1, 1);
    const totalDias = U.diasNoMes(ano, mes);
    const inicioSemana = primeiro.getDay(); // 0=dom
    const mesAnt = mes === 1 ? 12 : mes - 1;
    const anoAnt = mes === 1 ? ano - 1 : ano;
    const totalAnt = U.diasNoMes(anoAnt, mesAnt);
    const mesProx = mes === 12 ? 1 : mes + 1;
    const anoProx = mes === 12 ? ano + 1 : ano;

    // agrupa por dia
    const porDia = {};
    contas.forEach(function (c) {
      const k = c.vencimento;
      if (!porDia[k]) porDia[k] = [];
      porDia[k].push(c);
    });

    function marcador(lista) {
      const ordem = { atrasada: 0, proxima: 1, avencer: 2, paga: 3 };
      const vistos = [];
      lista.map(function (c) { return U.status(c, hoje); })
        .sort(function (a, b) { return ordem[a] - ordem[b]; })
        .forEach(function (s) { if (vistos.indexOf(s) < 0 && vistos.length < 3) vistos.push(s); });
      return '<span class="pontos">' + vistos.map(function (s) { return '<i class="' + s + '"></i>'; }).join('') + '</span>';
    }

    let celulas = '';
    for (let i = inicioSemana - 1; i >= 0; i--) {
      celulas += '<button class="dia fora" disabled aria-hidden="true">' + (totalAnt - i) + '</button>';
    }
    for (let d = 1; d <= totalDias; d++) {
      const iso = ano + '-' + U.pad2(mes) + '-' + U.pad2(d);
      const lista = porDia[iso] || [];
      const classes = ['dia'];
      if (iso === hoje) classes.push('hoje');
      if (iso === raiz.App.estado.diaSel) classes.push('sel');
      celulas += '<button class="' + classes.join(' ') + '" data-acao="selecionar-dia" data-iso="' + iso + '"' +
        ' aria-label="' + U.fmtData(iso) + (lista.length ? ', ' + lista.length + ' conta(s)' : ', sem contas') + '">' +
        '<span>' + d + '</span>' + (lista.length ? marcador(lista) : '') + '</button>';
    }
    const resto = (7 - ((inicioSemana + totalDias) % 7)) % 7;
    for (let d = 1; d <= resto; d++) celulas += '<button class="dia fora" disabled aria-hidden="true">' + d + '</button>';

    let h = '<div class="cartao"><div class="cal-cab">' +
      '<button class="cal-nav-b" data-acao="mes" data-delta="-1" aria-label="Mês anterior">' + U.icone('voltar') + '</button>' +
      '<span class="mes">' + U.MESES[mes - 1] + ' de ' + ano + '</span>' +
      '<span class="cal-nav">' +
        '<button data-acao="mes" data-delta="1" aria-label="Próximo mês">' + U.icone('voltar').replace('<svg', '<svg style="transform:rotate(180deg)"') + '</button>' +
      '</span></div>' +
      '<div class="dias-sem"><span>dom</span><span>seg</span><span>ter</span><span>qua</span><span>qui</span><span>sex</span><span>sáb</span></div>' +
      '<div class="grade-cal">' + celulas + '</div>' +
      '<div class="legenda">' +
        '<span><i class="avencer" style="background:var(--azul-3)"></i>A vencer</span>' +
        '<span><i class="proxima" style="background:var(--laranja)"></i>Vence em 7 dias</span>' +
        '<span><i class="atrasada" style="background:var(--vermelho)"></i>Atrasada</span>' +
        '<span><i class="paga" style="background:var(--verde)"></i>Paga</span>' +
      '</div>' +
      '<div class="linha-botoes" style="margin-top:14px">' +
        '<button class="btn btn-claro" data-acao="cal-hoje">' + U.icone('atualizar') + 'Voltar para hoje</button>' +
      '</div>' +
      '<div class="totais" style="margin-bottom:0">' +
        '<div class="tl"><span>Contas no mês</span><b>' + contas.filter(function (c) { return U.mesDe(c.vencimento) === mesRef; }).length + '</b></div>' +
        '<div class="tl r"><span>Vencidas neste mês</span><b>' + U.fmtBRL(U.somar(contas.filter(function (c) { return !c.pago && U.mesDe(c.vencimento) === mesRef && U.diffDias(c.vencimento, hoje) < 0; }))) + '</b></div>' +
      '</div>' +
      '</div>';

    // dia selecionado
    const sel = raiz.App.estado.diaSel;
    if (sel) {
      const lista = U.ordenar(porDia[sel] || [], 'valor');
      h += '<div class="secao"><h2>' + U.fmtData(sel) + ' — ' + U.DIAS_LONGOS[U.deISO(sel).getDay()] + '</h2></div>';
      h += lista.length
        ? '<div class="contas">' + lista.map(function (c) { return raiz.Views.cartaoConta(c, hoje); }).join('') + '</div>'
        : '<div class="vazio"><div class="bolha">' + U.icone('calendario') + '</div><h3>Nenhuma conta neste dia</h3><p>Escolha outro dia com pontinhos coloridos ou cadastre uma conta nova.</p><button class="btn btn-primario btn-largo" data-acao="nova">' + U.icone('mais') + 'Adicionar conta</button></div>';
    } else {
      h += '<div class="caixa-info" style="margin-top:16px">' + U.icone('info') + ' Toque em um dia para ver as contas que vencem nele. Os pontinhos mostram a situação: verde paga, laranja vence em até 7 dias, vermelho atrasada.</div>';
    }
    return h;
  };

  /* ------------------------------- histórico ------------------------------- */
  M.historico = function () {
    const est = raiz.App.estado;
    const contas = raiz.Store.contas();
    const hoje = U.hojeISO();
    const hojeD = U.deISO(hoje);

    let lista = contas.slice();
    const per = est.periodo || 'mes';
    if (per === 'mes') lista = lista.filter(function (c) { return U.mesDe(c.vencimento) === U.mesDe(hoje); });
    else if (per === 'mespassado') {
      const d = new Date(hojeD.getFullYear(), hojeD.getMonth() - 1, 1);
      const ref = d.getFullYear() + '-' + U.pad2(d.getMonth() + 1);
      lista = lista.filter(function (c) { return U.mesDe(c.vencimento) === ref; });
    } else if (per === '90') lista = lista.filter(function (c) { return U.diffDias(c.vencimento, hoje) >= -90 && U.diffDias(c.vencimento, hoje) <= 90; });
    else if (per === 'ano') lista = lista.filter(function (c) { return U.anoDe(c.vencimento) === hojeD.getFullYear(); });
    else if (per === 'pendentes') lista = lista.filter(function (c) { return !c.pago; });
    else if (per === 'pagas') lista = lista.filter(function (c) { return c.pago; });
    else if (per === 'vencidas') lista = lista.filter(function (c) { return !c.pago && U.diffDias(c.vencimento, hoje) < 0; });

    if (est.categoria !== 'todas') lista = lista.filter(function (c) { return c.categoria === est.categoria; });
    if (est.busca) {
      const q = U.norm(est.busca);
      lista = lista.filter(function (c) { return U.norm(c.nome).indexOf(q) >= 0 || U.norm(c.beneficiario).indexOf(q) >= 0; });
    }
    lista = U.ordenar(lista, est.ordem);

    const pagas = lista.filter(function (c) { return c.pago; });
    const abertas = lista.filter(function (c) { return !c.pago; });
    const vencidas = abertas.filter(function (c) { return U.diffDias(c.vencimento, hoje) < 0; });
    const rec = {};
    lista.forEach(function (c) {
      const k = c.categoria || 'outros';
      if (!rec[k]) rec[k] = { qtd: 0, total: 0 };
      rec[k].qtd++; rec[k].total += Number(c.valor) || 0;
    });
    const maiores = Object.keys(rec).sort(function (a, b) { return rec[b].total - rec[a].total; }).slice(0, 6);
    const maxCat = maiores.length ? rec[maiores[0]].total : 0;

    const periodos = [['mes', 'Este mês'], ['mespassado', 'Mês passado'], ['90', '±90 dias'], ['ano', 'Este ano'], ['tudo', 'Tudo'], ['pagas', 'Só pagas'], ['pendentes', 'Só pendentes'], ['vencidas', 'Só vencidas']];

    let h = '<div class="rolagem-x" aria-label="Filtrar período">' +
      periodos.map(function (p) {
        return '<button class="chip ' + (per === p[0] ? 'marcado' : '') + '" data-acao="periodo" data-periodo="' + p[0] + '">' + p[1] + '</button>';
      }).join('') + '</div>';

    h += '<div class="rolagem-x" aria-label="Filtrar categoria">' +
      '<button class="chip ' + (est.categoria === 'todas' ? 'marcado' : '') + '" data-acao="categoria" data-cat="todas">Todas</button>' +
      U.CATEGORIAS.map(function (c) {
        const t = rec[c.id];
        if (!t) return '';
        return '<button class="chip ' + (est.categoria === c.id ? 'marcado' : '') + '" data-acao="categoria" data-cat="' + c.id + '">' + U.icone(c.icone) + c.nome + ' (' + t.qtd + ')</button>';
      }).join('') + '</div>';

    h += '<div class="busca">' + U.icone('busca') +
      '<input class="campo" id="campo-busca" type="search" placeholder="Buscar pelo nome da conta" value="' + U.esc(est.busca) + '" aria-label="Buscar no histórico"></div>';

    h += '<div class="totais">' +
      '<div class="tl v"><span>Total pago</span><b>' + U.fmtBRL(U.somar(pagas)) + '</b></div>' +
      '<div class="tl p"><span>Total pendente</span><b>' + U.fmtBRL(U.somar(abertas)) + '</b></div>' +
      '<div class="tl r"><span>Atrasado</span><b>' + U.fmtBRL(U.somar(vencidas)) + '</b></div>' +
      '<div class="tl"><span>Contas no filtro</span><b>' + lista.length + '</b></div>' +
      '</div>';

    if (maiores.length) {
      h += '<div class="cartao"><div class="secao" style="margin:0 0 10px"><h2>Gastos por categoria</h2></div>' +
        maiores.map(function (k) {
          const pct = maxCat > 0 ? Math.round(rec[k].total / maxCat * 100) : 0;
          return '<div style="margin-bottom:12px"><div style="display:flex;justify-content:space-between;font-size:13px;font-weight:650">' +
            '<span>' + U.esc(U.categoria(k).nome) + ' <span class="suave">(' + rec[k].qtd + ')</span></span>' +
            '<span class="destaque-num">' + U.fmtBRL(rec[k].total) + '</span></div>' +
            '<div class="barra" style="margin:6px 0 0"><i style="width:' + pct + '%;background:linear-gradient(90deg,var(--azul-3),var(--azul))"></i></div></div>';
        }).join('') + '</div>';
    }

    h += '<div class="secao"><h2>Exportar e compartilhar</h2></div>' +
      '<div class="grade2">' +
      '<button class="btn btn-contorno" data-acao="exportar-csv">' + U.icone('planilha') + 'CSV / Excel</button>' +
      '<button class="btn btn-contorno" data-acao="exportar-pdf">' + U.icone('pdf') + 'PDF</button>' +
      '<button class="btn btn-contorno" data-acao="exportar-ics">' + U.icone('calendario') + 'Calendário (.ics)</button>' +
      '<button class="btn btn-contorno" data-acao="exportar-backup">' + U.icone('escudo') + 'Backup</button>' +
      '</div>';

    h += '<div class="secao"><h2>Contas do filtro</h2><span class="mini suave">' + lista.length + ' registro(s)</span></div>';
    h += lista.length
      ? '<div class="contas">' + lista.map(function (c) { return raiz.Views.cartaoConta(c, hoje); }).join('') + '</div>'
      : '<div class="vazio"><div class="bolha">' + U.icone('grafico') + '</div><h3>Nenhum registro no filtro</h3><p>Troque o período ou a categoria para ver outros lançamentos.</p></div>';

    return h;
  };

  /* --------------------------- central de lembretes ------------------------ */
  M.notificacoes = function () {
    const enviadas = raiz.Store.notificacoes();
    const proximos = raiz.App.proximosLembretes(30);
    const perm = raiz.App.permissaoNotificacao();

    let h = '<div class="cartao"><div class="secao" style="margin:0 0 6px"><h2>Como os lembretes funcionam</h2></div>';
    if (perm === 'granted') {
      h += '<div class="faixa">' + U.icone('check') + '<span class="cresce"><b>Avisos do sistema ativados.</b> Com o app aberto (ou em segundo plano), o Lembrei mostra os avisos no seu celular.</span></div>';
    } else if (perm === 'denied') {
      h += '<div class="faixa alerta">' + U.icone('alerta') + '<span class="cresce"><b>Avisos bloqueados no navegador.</b> Toque em "Como liberar" para ver o passo a passo nas configurações do celular.</span><button data-acao="ajuda-notificacao">Como liberar</button></div>';
    } else {
      h += '<div class="faixa exemplo">' + U.icone('sino') + '<span class="cresce"><b>Permissão não solicitada.</b> Toque para permitir.</span><button data-acao="pedir-notificacao">Permitir</button></div>';
    }
    h += '<div class="aviso-li">' + U.icone('info') + '<span>Esta central guarda tudo o que o Lembrei já avisou, mesmo que o aviso do sistema esteja bloqueado. Nada se perde.</span></div>' +
      '<div class="aviso-li">' + U.icone('info') + '<span>Para alarmes garantidos com o app totalmente fechado, use o botão <b>Calendário (.ics)</b>: ele cria os alarmes no app de Agenda do seu celular.</span></div>' +
      '</div>';

    h += '<div class="secao"><h2>Próximos lembretes (30 dias)</h2><span class="mini suave">' + proximos.length + '</span></div>';
    if (!proximos.length) {
      h += '<div class="vazio"><div class="bolha">' + U.icone('sino') + '</div><h3>Nenhum lembrete agendado</h3><p>Cadastre uma conta e escolha quando quer ser avisado.</p><button class="btn btn-primario btn-largo" data-acao="nova">' + U.icone('mais') + 'Adicionar conta</button></div>';
    } else {
      h += '<div class="cartao central-notif">' + proximos.slice(0, 24).map(function (l) {
        return '<div class="item"><span class="bolha ' + (l.dias <= 0 ? 'espera' : '') + '">' + U.icone(l.dias === -1 ? 'fogo' : 'sino') + '</span>' +
          '<span class="txt"><b>' + U.esc(l.nome) + ' — ' + U.fmtBRL(l.valor) + '</b>' +
          '<p>' + U.rotuloLembrete(l.dias) + ' • ' + U.fmtData(l.data) + ' às ' + (l.hora || '09:00') +
          ' <span class="suave">(' + U.textoPrazo(l.data, U.hojeISO()) + ')</span></p></span></div>';
      }).join('') + '</div>';
    }

    h += '<div class="secao"><h2>Lembretes já enviados</h2>' +
      (enviadas.length ? '<button class="ver" data-acao="limpar-notificacoes">Limpar</button>' : '') + '</div>';
    h += enviadas.length
      ? '<div class="cartao central-notif">' + enviadas.slice(0, 30).map(function (n) {
        return '<div class="item"><span class="bolha ok">' + U.icone(n.sistema ? 'check' : 'info') + '</span>' +
          '<span class="txt"><b>' + U.esc(n.titulo) + '</b><p>' + U.esc(n.corpo) + '</p>' +
          '<p class="mini">' + U.fmtDataHora(n.quando) + (n.sistema ? ' • avisado no sistema' : ' • registrado no app') + '</p></span></div>';
      }).join('') + '</div>'
      : '<div class="empty" style="text-align:center;padding:22px;color:var(--suave);font-size:14px">Nada enviado ainda.</div>';

    h += '<div class="linha-botoes" style="margin-top:18px">' +
      '<button class="btn btn-contorno" data-acao="testar-notificacao">' + U.icone('sino') + 'Testar aviso</button>' +
      '<button class="btn btn-primario" data-acao="exportar-ics">' + U.icone('calendario') + 'Calendário (.ics)</button></div>';
    return h;
  };

  /* -------------------------------- ajustes -------------------------------- */
  M.config = function () {
    const cfg = raiz.Store.config();
    const perm = raiz.App.permissaoNotificacao();
    const suportaNotif = ('Notification' in window);
    const suportaSW = ('serviceWorker' in navigator);
    const instalado = raiz.matchMedia('(display-mode: standalone)').matches || raiz.navigator.standalone === true;

    let h = '<div class="cartao">' +
      '<div class="form-grupo" style="margin-bottom:8px"><label for="c-nome">Seu nome</label>' +
      '<input class="campo" id="c-nome" type="text" placeholder="Como quer ser chamado(a)" value="' + U.esc(cfg.nome) + '" autocomplete="given-name">' +
      '<div class="ajuda">Usado só na saudação do painel. É opcional.</div></div></div>';

    h += '<div class="secao"><h2>Lembretes e notificações</h2></div><div class="cartao">' +
      '<div class="form-grupo"><label for="c-hora">Horário preferido para avisar</label>' +
      '<input class="campo" id="c-hora" type="time" value="' + U.esc(cfg.hora || '09:00') + '">' +
      '<div class="ajuda">Usado quando a conta não tem horário próprio.</div></div>' +
      '<div class="form-grupo" style="margin-bottom:6px"><span class="rot-campo">Lembretes padrão para contas novas</span>' +
      '<div class="chips">' + U.LEMBRETES.map(function (d) {
        const on = (cfg.lembretes || []).indexOf(d) >= 0;
        return '<button class="chip lembrete ' + (on ? 'marcado' : '') + '" data-acao="toggle-lembrete-padrao" data-dias="' + d + '" aria-pressed="' + on + '">' + U.icone(d === -1 ? 'fogo' : 'sino') + U.rotuloCurtoLembrete(d) + '</button>';
      }).join('') + '</div></div>' +
      '<div class="interruptor"><span class="txt"><b>Repetir aviso de conta atrasada todos os dias</b>' +
      '<span>Um aviso por dia até você marcar como paga.</span></span>' +
      '<button class="sw ' + (cfg.repetirAtePagar ? 'ligado' : '') + '" data-acao="toggle-repetir-padrao" aria-label="Repetir até pagar" aria-pressed="' + !!cfg.repetirAtePagar + '"></button></div>' +

      '<div class="divisor"></div>' +
      '<div class="interruptor" style="padding-top:0"><span class="txt"><b>Permissão de notificação</b>' +
      '<span>' + (suportaNotif
        ? (perm === 'granted' ? 'Concedida neste navegador.' : perm === 'denied' ? 'Bloqueada. Veja como liberar.' : 'Ainda não solicitada.')
        : 'Este navegador não oferece notificações do sistema.') + '</span></span>' +
      '<button class="btn ' + (perm === 'granted' ? 'btn-claro' : 'btn-primario') + '" data-acao="pedir-notificacao" style="min-height:46px;padding:10px 16px">' +
      (perm === 'granted' ? 'Reativar' : 'Permitir') + '</button></div>' +
      '<div class="linha-botoes" style="margin-top:12px">' +
      '<button class="btn btn-contorno" data-acao="testar-notificacao">Testar aviso</button>' +
      '<button class="btn btn-contorno" data-acao="ajuda-notificacao">Como liberar</button></div>' +
      '<div class="caixa-info" style="margin-top:14px">' + U.icone('info') +
      ' <b>Importante e honesto:</b> um site/app da web (PWA) <b>não consegue</b> disparar aviso com o app totalmente fechado por conta própria — o navegador precisa estar rodando ou receber um envio de um servidor. ' +
      'Por isso o Lembrei faz <b>três coisas reais</b>: (1) avisa pelo sistema quando você abre o app ou o traz de volta à frente e vence um lembrete; ' +
      '(2) guarda todos os avisos na <b>Central de lembretes</b>; (3) gera um <b>arquivo de calendário (.ics)</b> que produz alarmes de verdade no app de Agenda do seu celular, mesmo com o Lembrei fechado. ' +
      'Para avisos 100% automáticos em segundo plano é necessário instalar a versão nativa (Capacitor + notificações locais) ou um servidor de push — explicado em "Como ter avisos com o app fechado".' +
      '</div>' +
      '<button class="btn btn-claro btn-largo" data-acao="ajuda-fechado" style="margin-top:10px">' + U.icone('celular') + 'Como ter avisos com o app fechado</button>' +
      '</div>';

    h += '<div class="secao"><h2>Aparência</h2></div><div class="cartao">' +
      '<span class="rot-campo">Tema</span><div class="chips">' +
      [['auto', 'Automático'], ['claro', 'Claro'], ['escuro', 'Escuro']].map(function (t) {
        return '<button class="chip ' + (cfg.tema === t[0] ? 'marcado' : '') + '" data-acao="tema" data-tema-op="' + t[0] + '">' + U.icone(t[0] === 'escuro' ? 'lua' : t[0] === 'claro' ? 'sol' : 'relogio') + t[1] + '</button>';
      }).join('') + '</div>' +
      '<div class="interruptor" style="margin-top:10px"><span class="txt"><b>Moeda</b><span>Real brasileiro (R$) — formato 1.234,56</span></span>' +
      '<span class="selo neutro">BRL</span></div></div>';

    h += '<div class="secao"><h2>Dados, backup e privacidade</h2></div><div class="cartao">' +
      '<div class="detalhe-lista"><span>Onde ficam meus dados</span><b>' + (raiz.Store.modo() === 'idb' ? 'No aparelho (IndexedDB)' : 'No aparelho (armazenamento local)') + '</b></div>' +
      '<div class="detalhe-lista"><span>Enviados para a internet</span><b>Não</b></div>' +
      '<div class="detalhe-lista"><span>Cadastro ou senha</span><b>Não exige</b></div>' +
      '<button class="btn btn-contorno btn-largo" data-acao="status-armazenamento" style="margin-top:12px">' + U.icone('escudo') + 'Verificar armazenamento permanente</button>' +
      '<div class="grade2" style="margin-top:12px">' +
      '<button class="btn btn-contorno" data-acao="exportar-backup">' + U.icone('download') + 'Fazer backup</button>' +
      '<button class="btn btn-contorno" data-acao="restaurar-backup">' + U.icone('upload') + 'Restaurar backup</button>' +
      '</div>' +
      '<div class="grade2">' +
      '<button class="btn btn-contorno" data-acao="exportar-csv">' + U.icone('planilha') + 'Exportar CSV</button>' +
      '<button class="btn btn-contorno" data-acao="exportar-pdf">' + U.icone('pdf') + 'Relatório PDF</button>' +
      '</div>' +
      '<input type="file" id="arq-backup" accept="application/json,.json" hidden>' +
      '<div class="divisor"></div>' +
      '<button class="linha-config" data-acao="ajuda-privacidade">' + U.icone('escudo') +
      '<span class="txt"><b>Política de privacidade</b><span>O que o app guarda e o que ele nunca faz</span></span>' + U.icone('voltar', 'seta').replace('style', 'style') + '</button>' +
      '<button class="linha-config" data-acao="remover-demos">' + U.icone('lixeira') +
      '<span class="txt"><b>Apagar contas de exemplo</b><span>' + raiz.MetricsDemo() + '</span></span>' + U.icone('voltar', 'seta') + '</button>' +
      '<button class="linha-config" data-acao="apagar-dados" style="color:var(--vermelho)">' + U.icone('alerta') +
      '<span class="txt"><b style="color:var(--vermelho)">Excluir todos os meus dados</b><span>Ação permanente, não pode ser desfeita</span></span>' + U.icone('voltar', 'seta') + '</button>' +
      '</div>';

    h += '<div class="secao"><h2>Ajuda e instalação</h2></div><div class="cartao">' +
      '<button class="linha-config" data-acao="ajuda-instalar">' + U.icone('celular') +
      '<span class="txt"><b>Como instalar no celular</b><span>' + (instalado ? 'Já instalado neste aparelho ✓' : 'Android e iPhone, passo a passo') + '</span></span>' + U.icone('voltar', 'seta') + '</button>' +
      '<button class="linha-config" data-acao="ajuda-fechado">' + U.icone('sino') +
      '<span class="txt"><b>Avisos com o app fechado</b><span>Calendário, versão nativa e servidor de push</span></span>' + U.icone('voltar', 'seta') + '</button>' +
      '<button class="linha-config" data-acao="ajuda-publicar">' + U.icone('raio') +
      '<span class="txt"><b>Publicar nas lojas (Play e App Store)</b><span>Passo a passo e custos</span></span>' + U.icone('voltar', 'seta') + '</button>' +
      '<button class="linha-config" data-acao="ajuda-custos">' + U.icone('dinheiro') +
      '<span class="txt"><b>Custos: o que é grátis e o que é pago</b><span>Comece com R$ 0</span></span>' + U.icone('voltar', 'seta') + '</button>' +
      '<button class="linha-config" data-acao="ajuda-entrar">' + U.icone('info') +
      '<span class="txt"><b>Ver introdução novamente</b><span>Tutorial de 3 passos</span></span>' + U.icone('voltar', 'seta') + '</button>' +
      '<div class="detalhe-lista" style="margin-top:10px"><span>Versão do Lembrei</span><b>1.0.0</b></div>' +
      '<div class="detalhe-lista"><span>Recursos do aparelho</span><b>' + (suportaSW ? 'Service Worker ativo' : 'sem Service Worker') + ' • ' + (suportaNotif ? 'Notificação disponível' : 'sem notificação') + '</b></div>' +
      '</div>';

    return h;
  };

  const MetricsDemo = function () {
    const n = raiz.Store.contas().filter(function (c) { return c.demo; }).length;
    return n ? n + ' conta(s) de exemplo no app' : 'Nenhuma conta de exemplo';
  };
  raiz.MetricsDemo = MetricsDemo;

  /* --------------------------------- ajuda --------------------------------- */
  M.ajuda = function (tipo) {
    const quando = U.fmtDataHora(new Date().toISOString());
    if (tipo === 'privacidade') {
      return '<h3>Política de privacidade</h3>' +
        '<p>Resumo direto, sem juridiquês.</p>' +
        '<div class="caixa-info">' +
        '<b>1. Seus dados ficam no seu aparelho.</b> O Lembrei salva tudo no armazenamento local do navegador (IndexedDB). ' +
        'Nada é enviado para servidores, nuvem ou terceiros. Não existe conta, login, senha ou cadastro.<br><br>' +
        '<b>2. O que o app guarda:</b> nome das contas, valores, datas, categorias, descrições, lembretes e seu nome (opcional).<br><br>' +
        '<b>3. O que o app NUNCA pede:</b> senha de banco, número de cartão, código de segurança, CPF, dados bancários ou qualquer informação financeira sensível. ' +
        'Marcar uma conta como paga é um controle pessoal seu — não há comprovante nem acesso à sua conta bancária.<br><br>' +
        '<b>4. Se você apagar o app</b> (ou limpar os dados do navegador), os dados vão junto. É a única forma de perda. ' +
        'Por isso existe o <b>Backup</b> nos Ajustes: toque em "Fazer backup" e guarde o arquivo em um lugar seguro.<br><br>' +
        '<b>5. Suas escolhas:</b> você pode exportar tudo em CSV/PDF, restaurar de um backup e apagar definitivamente todos os dados a qualquer momento em Ajustes ▸ Excluir todos os meus dados.<br><br>' +
        '<b>6. Notificações:</b> usadas apenas para avisar sobre as suas contas. Nenhum dado é compartilhado para enviar avisos.<br><br>' +
        '<b>7. Compromisso:</b> sem rastreamento, sem anúncios, sem venda de dados, sem analytics.' +
        '</div><p class="mini suave" style="margin-top:12px">Última revisão: ' + quando + '</p>';
    }
    if (tipo === 'instalar') {
      return '<h3>Como instalar no celular</h3>' +
        '<p>O Lembrei é um PWA (aplicativo web instalável). Ele fica com ícone na tela inicial, abre em tela cheia e <b>funciona sem internet</b>.</p>' +
        '<div class="caixa-info"><b>Android (Chrome, Edge, Samsung Internet)</b><br>' +
        '1. Abra o endereço do Lembrei no navegador.<br>' +
        '2. Toque no menu <b>⋮</b> (três pontinhos, canto superior direito).<br>' +
        '3. Escolha <b>“Adicionar à tela inicial”</b> ou <b>“Instalar aplicativo”</b>.<br>' +
        '4. Confirme o nome <b>Lembrei</b> e toque em <b>Instalar</b>.<br>' +
        '5. O ícone aparece junto com seus outros aplicativos. Abra por ele, não pelo navegador.</div>' +
        '<div class="caixa-info" style="margin-top:12px"><b>iPhone / iPad (Safari)</b><br>' +
        '1. Abra o endereço no <b>Safari</b> (obrigatório ser o Safari no iPhone).<br>' +
        '2. Toque no botão <b>Compartilhar</b> (quadrado com seta para cima, embaixo).<br>' +
        '3. Deslize e escolha <b>“Adicionar à Tela de Início”</b>.<br>' +
        '4. Toque em <b>Adicionar</b>.<br>' +
        '5. Abra o Lembrei pelo ícone novo. Só assim as notificações ficam disponíveis no iPhone.</div>' +
        '<div class="aviso-li" style="margin-top:12px">' + U.icone('info') + '<span>No <b>iPhone</b>, notificações web só existem a partir do iOS 16.4 e <b>somente depois</b> de adicionar à Tela de Início. Nas versões anteriores o app funciona normalmente, mas sem avisos do sistema — use a Central de lembretes e o arquivo de calendário (.ics).</span></div>';
    }
    if (tipo === 'fechado') {
      return '<h3>Avisos com o app fechado</h3>' +
        '<p>Explicação honesta do que dá e do que não dá para fazer sem pagar servidor.</p>' +
        '<div class="caixa-info"><b>O limite técnico</b><br>' +
        'Um PWA é um site. Quando o navegador não está rodando, não existe código seu sendo executado — então ele não pode “acordar sozinho” para avisar. ' +
        'A API de gatilhos agendados (<i>Notification Triggers</i>) que permitiria isso foi descontinuada pelo Chrome e nunca chegou ao Safari.</div>' +
        '<div class="caixa-info" style="margin-top:12px"><b>Opção 1 — Calendário .ics (grátis, funciona hoje)</b><br>' +
        'Em Relatórios ▸ Calendário (.ics) o Lembrei gera um arquivo. Ao abrir, o app de Agenda do seu celular cria os compromissos <b>com alarmes reais</b>, ' +
        'que tocam mesmo com o Lembrei fechado. Rode de novo a cada mês para atualizar. Custo: R$ 0.</div>' +
        '<div class="caixa-info" style="margin-top:12px"><b>Opção 2 — Versão nativa (grátis para instalar você mesmo)</b><br>' +
        'O projeto já está organizado para empacotar com <b>Capacitor</b>. Nela, o plugin <b>Local Notifications</b> agenda avisos no próprio aparelho, ' +
        'sem servidor, funcionando com o app fechado. Requer um computador e, no caso do iPhone, uma conta Apple. Passo a passo no arquivo COMECE-AQUI do projeto.</div>' +
        '<div class="caixa-info" style="margin-top:12px"><b>Opção 3 — Servidor de push (tem plano gratuito, com limite)</b><br>' +
        'Um pequeno servidor envia mensagens Web Push (VAPID) para o navegador. Funciona com o app fechado no Android e no iPhone (16.4+, instalado). ' +
        'Existem planos gratuitos com limite de mensagens; acima disso é pago. O projeto já traz o Service Worker com o handler de <i>push</i> pronto — basta colar as chaves VAPID. ' +
        'Nada disso está ativo por padrão, e eu não vou fingir que está.</div>';
    }
    if (tipo === 'publicar') {
      return '<h3>Publicar nas lojas</h3>' +
        '<p>Você pode começar de graça como PWA e depois publicar. Passo a passo:</p>' +
        '<div class="caixa-info"><b>Etapa 1 — Colocar o app na internet (grátis)</b><br>' +
        'Use <b>Netlify Drop</b> (arraste a pasta) ou <b>GitHub Pages</b>. Endereço com <b>HTTPS</b> é obrigatório para instalação e notificações. Custo: R$ 0.</div>' +
        '<div class="caixa-info" style="margin-top:12px"><b>Etapa 2 — Empacotar (Capacitor)</b><br>' +
        '<code>npm install @capacitor/core @capacitor/cli @capacitor/local-notifications</code><br>' +
        '<code>npx cap init Lembrei br.com.lembrei --web-dir=www</code><br>' +
        '<code>npx cap add android &amp;&amp; npx cap add ios</code><br>' +
        '<code>npx cap sync</code></div>' +
        '<div class="caixa-info" style="margin-top:12px"><b>Etapa 3 — Google Play</b><br>' +
        'Crie uma conta de desenvolvedor (taxa única, paga uma vez), gere o arquivo AAB assinado e envie pelo Play Console. ' +
        'Existe período de teste com até 20 pessoas antes de exigir a taxa.</div>' +
        '<div class="caixa-info" style="margin-top:12px"><b>Etapa 4 — App Store</b><br>' +
        'Exige um <b>Mac</b> com Xcode e o programa de desenvolvedor Apple (assinatura anual, separada por ano). ' +
        'É o caminho mais caro — por isso a recomendação é começar pelo PWA (Android + iPhone) e só depois ir para a loja.</div>' +
        '<div class="aviso-li" style="margin-top:12px">' + U.icone('alerta') + '<span>Os valores das taxas mudam com o tempo. Confirme os preços atuais nos sites oficiais do Google Play Console e do Apple Developer Program antes de pagar.</span></div>';
    }
    if (tipo === 'custos') {
      return '<h3>O que é grátis e o que pode custar</h3>' +
        '<div class="caixa-info"><b>Grátis para sempre</b><br>' +
        '• Usar o app no seu celular (Android e iPhone)<br>' +
        '• Cadastro ilimitado de contas, lembretes, calendário, relatórios<br>' +
        '• Dados salvos no aparelho, sem cadastro e sem senha<br>' +
        '• Exportar CSV, PDF, backup e Calendário (.ics)<br>' +
        '• Hospedar em Netlify, GitHub Pages ou Cloudflare Pages</div>' +
        '<div class="caixa-info" style="margin-top:12px"><b>Pode gerar custo (opcional)</b><br>' +
        '• <b>Servidor de push</b> para avisos automáticos com o app fechado — há planos gratuitos com limite de mensagens; uso acima do limite é pago<br>' +
        '• <b>Conta Google Play</b> — taxa única de desenvolvedor<br>' +
        '• <b>Apple Developer</b> — assinatura anual, e exige Mac<br>' +
        '• <b>Sincronizar entre aparelhos</b> — precisaria de um banco de dados na nuvem (planos gratuitos com limite) e de um login; hoje o Lembrei <b>não</b> faz sincronização, é de propósito, para você pagar R$ 0</div>' +
        '<div class="aviso-li" style="margin-top:12px">' + U.icone('info') + '<span>Para trocar de aparelho hoje: faça <b>Backup</b> no antigo e <b>Restaurar backup</b> no novo. Grátis e sem nuvem.</span></div>';
    }
    return '';
  };

  raiz.ViewsMais = M;
})(typeof window !== 'undefined' ? window : globalThis);
