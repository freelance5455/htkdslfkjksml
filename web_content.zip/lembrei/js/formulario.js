/* ==========================================================================
   Lembrei — formulario.js
   Substitui V.formulario pela versão 2 do formulário de conta:
   - múltiplas antecedências (0 a 365 dias), cada uma com horário próprio
   - adicionar, editar e excluir cada lembrete individualmente
   - repetição de conta atrasada configurável (diária, 2, 3, semanal, custom)
   - valor fixo ou variável para contas recorrentes
   ========================================================================== */
(function (raiz) {
  'use strict';
  const U = raiz.U;
  const Store = raiz.Store;

  function estado() { return raiz.App.estado; }
  function cfg() { return Store.config(); }
  function vencimentoAtual() {
    const el = document.getElementById('f-venc');
    return (el && el.value) || (estado().vencimentoForm || U.hojeISO());
  }

  /* ------------------------- linha de um lembrete ------------------------- */
  function linhaLembrete(L) {
    const venc = vencimentoAtual();
    const data = U.addDias(venc, -L.dias);
    const quando = U.fmtData(data) + ' às ' + L.hora;
    return '<div class="lembrete-item" data-lembrete-id="' + L.id + '">' +
      '<div class="li-topo">' +
        '<span class="li-dias">' +
          '<input type="number" min="0" max="365" inputmode="numeric" value="' + L.dias + '" data-campo="dias" aria-label="Quantos dias antes do vencimento">' +
          '<b>dia' + (L.dias === 1 ? '' : 's') + ' antes</b>' +
        '</span>' +
        '<input type="time" value="' + L.hora + '" data-campo="hora" aria-label="Horário do lembrete">' +
        '<button type="button" class="bloco-acao" data-acao="remover-lembrete" data-id="' + L.id + '" aria-label="Excluir este lembrete" title="Excluir lembrete">' + U.icone('lixeira') + '</button>' +
      '</div>' +
      '<div class="li-previa">' + U.icone('sino') + ' Avisa em <b data-previa>' + quando + '</b></div>' +
    '</div>';
  }

  const V = {};
  V.listaLembretes = function () {
    const lista = estado().lembretes || [];
    if (!lista.length) {
      return '<div class="li-vazio">' + U.icone('info') +
        'Nenhum lembrete. Sem lembrete, a conta não avisa nada. Toque em uma opção acima para adicionar.</div>';
    }
    return lista.map(linhaLembrete).join('');
  };

  /* -------------------------------- formulário ---------------------------- */
  raiz.Views.formularioV2 = function (conta) {
    const novo = !conta;
    const c = conta || {
      nome: '', valor: '', vencimento: U.hojeISO(), categoria: 'outros', descricao: '',
      beneficiario: '', recorrencia: 'nenhuma', recorrenciaFim: '', valorVariavel: false
    };

    // estado do editor de lembretes (fica em memória até salvar)
    estado().vencimentoForm = c.vencimento;
    estado().lembretes = U.lembretesNormalizados(conta || { vencimento: c.vencimento }, cfg())
      .map(function (L) { return { id: L.id, dias: L.dias, hora: L.hora }; });
    const rep = U.normalizarRepeticao(conta, cfg());
    const lembretes = estado().lembretes;

    let h = '<h3>' + (novo ? 'Nova conta' : 'Editar conta') + '</h3>' +
      '<p>' + (novo ? 'Preencha só o essencial. Os campos com * são obrigatórios.' : 'Altere o que precisar e salve.') + '</p>' +
      '<form id="form-conta" novalidate>';

    /* --- dados principais --- */
    h += '<div class="form-grupo"><label for="f-nome">Nome da conta *</label>' +
      '<input class="campo" id="f-nome" name="nome" type="text" autocomplete="off" enterkeyhint="next" placeholder="Ex.: Conta de luz" value="' + U.esc(c.nome) + '" required>' +
      '<div class="erro-texto" id="e-nome" hidden>Escreva um nome para identificar a conta.</div></div>';

    h += '<div class="form-grupo"><label for="f-valor">Valor em reais (R$) *</label>' +
      '<div style="display:flex;align-items:center;gap:10px">' +
      '<span class="destaque-num suave" style="font-size:22px">R$</span>' +
      '<input class="campo campo-valor" id="f-valor" name="valor" type="text" inputmode="decimal" autocomplete="off" placeholder="0,00" value="' + (c.valor === '' || c.valor == null ? '' : String(c.valor).replace('.', ',')) + '" required>' +
      '</div><div class="erro-texto" id="e-valor" hidden>Informe um valor maior que zero. Pode usar vírgula: 120,50</div></div>';

    h += '<div class="grade-campos">' +
      '<div class="form-grupo"><label for="f-venc">Data de vencimento *</label>' +
      '<input class="campo" id="f-venc" name="vencimento" type="date" value="' + U.esc(c.vencimento) + '" required>' +
      '<div class="erro-texto" id="e-venc" hidden>Escolha a data de vencimento.</div></div>' +
      '<div class="form-grupo"><label for="f-cat">Categoria</label>' +
      '<select class="campo-select" id="f-cat" name="categoria">' +
      U.CATEGORIAS.map(function (x) {
        return '<option value="' + x.id + '"' + (c.categoria === x.id ? ' selected' : '') + '>' + x.nome + '</option>';
      }).join('') + '</select></div>' +
      '</div>';

    h += '<div class="form-grupo"><label for="f-benef">Empresa ou beneficiário <span class="dica">(opcional)</span></label>' +
      '<input class="campo" id="f-benef" name="beneficiario" type="text" autocomplete="off" placeholder="Ex.: Enel, Vivo, Banco X" value="' + U.esc(c.beneficiario || '') + '"></div>';

    h += '<div class="form-grupo"><label for="f-desc">Descrição <span class="dica">(opcional)</span></label>' +
      '<textarea class="campo-area" id="f-desc" name="descricao" placeholder="Ex.: plano de 500 MB, aparelho em 12x">' + U.esc(c.descricao || '') + '</textarea></div>';

    /* --- lembretes: antecedência + horário por lembrete --- */
    h += '<div class="bloco-lembretes">' +
      '<span class="rot-campo">' + U.icone('sino') + ' Quando você quer ser avisado?</span>' +
      '<div class="ajuda" style="margin:2px 0 10px">Toque para adicionar quantos quiser. Cada lembrete tem o seu próprio horário.</div>' +

      '<div class="chips">' +
      U.PRESETS_DIAS.map(function (d) {
        const ativo = lembretes.some(function (L) { return L.dias === d; });
        return '<button type="button" class="chip lembrete ' + (ativo ? 'marcado' : '') + '" data-acao="add-lembrete" data-dias="' + d + '" aria-pressed="' + ativo + '">' +
          U.icone('sino') + U.rotuloCurtoDias(d) + '</button>';
      }).join('') + '</div>' +

      '<div class="linha-personalizado">' +
        '<input class="campo" id="novo-dias" type="number" min="0" max="365" inputmode="numeric" placeholder="Outro" aria-label="Outra quantidade de dias antes">' +
        '<button type="button" class="btn btn-claro" data-acao="add-lembrete-custom">' + U.icone('mais') + 'Adicionar</button>' +
      '</div>' +

      '<div class="lista-lembretes" id="lista-lembretes">' + V.listaLembretes() + '</div>' +
      '<div class="ajuda" id="total-lembretes">' + lembretes.length + ' lembrete(s) configurado(s).</div>' +
      '</div>';

    /* --- repetição de conta atrasada --- */
    h += '<div class="bloco-repeticao">' +
      '<span class="rot-campo">' + U.icone('fogo') + ' Se a conta atrasar, continuar avisando?</span>' +
      '<div class="chips" id="chips-repeticao">' +
      U.MODOS_REPETICAO.map(function (m) {
        return '<button type="button" class="chip ' + (rep.modo === m.id ? 'marcado' : '') + '" data-acao="modo-repeticao" data-modo="' + m.id + '" aria-pressed="' + (rep.modo === m.id) + '">' +
          U.icone(m.id === 'nenhuma' ? 'x' : 'relogio') + m.curto + '</button>';
      }).join('') + '</div>' +
      '<div class="form-grupo" id="grupo-intervalo" ' + (rep.modo === 'custom' ? '' : 'hidden') + ' style="margin-top:12px">' +
        '<label for="rep-intervalo">Repetir a cada quantos dias?</label>' +
        '<input class="campo" id="rep-intervalo" type="number" min="1" max="365" inputmode="numeric" value="' + (rep.intervalo || 5) + '">' +
      '</div>' +
      '<div id="grupo-rep-detalhes" ' + (rep.modo === 'nenhuma' ? 'hidden' : '') + '>' +
        '<div class="grade-campos" style="margin-top:12px">' +
          '<div><label for="rep-hora">Horário do aviso de atraso</label>' +
          '<input class="campo" id="rep-hora" type="time" value="' + (rep.hora || '09:00') + '"></div>' +
          '<div><label for="rep-fim">Repetir até <span class="dica">(opcional)</span></label>' +
          '<input class="campo" id="rep-fim" type="date" value="' + (rep.fim || '') + '"></div>' +
        '</div>' +
        '<div class="ajuda">Deixe a data vazia para repetir até você marcar a conta como paga.</div>' +
      '</div>' +
      '</div>';

    /* --- recorrência --- */
    h += '<div class="form-grupo" style="margin-top:18px"><label for="f-rec">Esta conta se repete?</label>' +
      '<select class="campo-select" id="f-rec" name="recorrencia">' +
      U.RECORRENCIAS.map(function (r) {
        return '<option value="' + r.id + '"' + (c.recorrencia === r.id ? ' selected' : '') + '>' + r.nome + '</option>';
      }).join('') + '</select>' +
      '<div class="ajuda">Ao marcar como paga, o Lembrei cria o próximo vencimento mantendo o histórico.</div></div>';

    h += '<div id="grupo-rec-extra" ' + (c.recorrencia === 'nenhuma' ? 'hidden' : '') + '>' +
      '<div class="form-grupo"><label for="f-rec-fim">Repetir até <span class="dica">(opcional — vazio = sem data final)</span></label>' +
      '<input class="campo" id="f-rec-fim" name="recorrenciaFim" type="date" value="' + U.esc(c.recorrenciaFim || '') + '"></div>' +
      '<div class="interruptor"><span class="txt"><b>O valor muda a cada vencimento</b>' +
      '<span>Marque se é uma conta de valor variável (ex.: cartão, água). Você informa o valor ao pagar.</span></span>' +
      '<button type="button" class="sw ' + (c.valorVariavel ? 'ligado' : '') + '" id="sw-valor-variavel" data-acao="toggle-switch" aria-label="Valor variável" aria-pressed="' + !!c.valorVariavel + '"></button></div>' +
      '</div>';

    h += '<div class="linha-botoes" style="margin-top:20px">' +
      (novo ? '' : '<button type="button" class="btn btn-perigo" data-acao="excluir" data-id="' + c.id + '">' + U.icone('lixeira') + 'Excluir</button>') +
      '<button type="submit" class="btn btn-primario btn-g" style="flex:2">' + U.icone('check') + (novo ? 'Salvar conta' : 'Salvar alterações') + '</button>' +
      '</div>';
    h += '<input type="hidden" id="f-id" value="' + (conta ? conta.id : '') + '">';
    h += '</form>';
    return h;
  };

  raiz.Views.listaLembretesHTML = V.listaLembretes;
})(typeof window !== 'undefined' ? window : globalThis);
