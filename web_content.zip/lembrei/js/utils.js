/* ==========================================================================
   Lembrei — utils.js
   Funções puras (datas locais, dinheiro, categorias, ícones, réguas de status).
   Todas as datas são strings "AAAA-MM-DD" tratadas como data LOCAL
   (nunca new Date("2026-10-25"), que o JavaScript interpreta como UTC).
   ========================================================================== */
(function (raiz) {
  'use strict';

  const U = {};

  U.DIAS_SEMANA = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
  U.DIAS_LONGOS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
  U.MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

  /* ------------------------------- categorias ------------------------------ */
  U.CATEGORIAS = [
    { id: 'agua', nome: 'Água', icone: 'agua' },
    { id: 'luz', nome: 'Luz', icone: 'luz' },
    { id: 'internet', nome: 'Internet', icone: 'internet' },
    { id: 'telefone', nome: 'Telefone', icone: 'telefone' },
    { id: 'aluguel', nome: 'Aluguel', icone: 'aluguel' },
    { id: 'cartao', nome: 'Cartão de crédito', icone: 'cartao' },
    { id: 'emprestimos', nome: 'Empréstimos', icone: 'dinheiro' },
    { id: 'financiamentos', nome: 'Financiamentos', icone: 'financiamentos' },
    { id: 'assinaturas', nome: 'Assinaturas', icone: 'assinaturas' },
    { id: 'impostos', nome: 'Impostos', icone: 'impostos' },
    { id: 'faculdade', nome: 'Faculdade', icone: 'faculdade' },
    { id: 'saude', nome: 'Saúde', icone: 'saude' },
    { id: 'outros', nome: 'Outros', icone: 'outros' }
  ];
  U.categoria = function (id) {
    return U.CATEGORIAS.filter(function (c) { return c.id === id; })[0] || U.CATEGORIAS[U.CATEGORIAS.length - 1];
  };

  /* --------------------------------- ícones -------------------------------- */
  const CAMINHOS = {
    agua: 'M12 3.2 6.9 9.4a7 7 0 1 0 10.2 0Z',
    luz: 'M13.5 2.5 5 13.8h5.6l-.6 7.7 8.5-11.3h-5.6Z',
    internet: 'M3 9.2a13.4 13.4 0 0 1 18 0M6.2 12.8a9 9 0 0 1 11.6 0M9.4 16.3a4.4 4.4 0 0 1 5.2 0M12 19.6h.01',
    telefone: 'M5 3h3.6l1.8 4.6-2.3 1.4a12.4 12.4 0 0 0 6 6l1.4-2.3 4.6 1.8V18a3 3 0 0 1-3 3A16.6 16.6 0 0 1 2 6a3 3 0 0 1 3-3Z',
    aluguel: 'M3 10.6 12 3.4l9 7.2M5.4 12v8.6h13.2V12M10 20.6v-5.4h4v5.4',
    cartao: 'M2.8 7.2h18.4v10.6H2.8ZM2.8 10.8h18.4M6 14.6h3',
    dinheiro: 'M2.8 7h18.4v10H2.8ZM12 9.4a2.6 2.6 0 1 0 .01 0M6 11.9h.01M18 11.9h.01',
    financiamentos: 'M3 9.4 12 3.6l9 5.8M4.8 11.4v7.2M19.2 11.4v7.2M8.4 11.4v7.2M12 11.4v7.2M15.6 11.4v7.2M3 19.4h18',
    assinaturas: 'M17.5 3.5 20.5 6.5 17.5 9.5M20.5 6.5H8a4.5 4.5 0 0 0-4.5 4.5M6.5 20.5 3.5 17.5l3-3M3.5 17.5H16a4.5 4.5 0 0 0 4.5-4.5',
    impostos: 'M6.2 3.2h11.6v17.6l-2.9-1.9-2.9 1.9-2.9-1.9-2.9 1.9ZM9 8.2h6M9 12.2h6',
    faculdade: 'M2.5 9.2 12 4.4l9.5 4.8L12 14ZM6.4 11.8v5.2c0 1.6 2.5 2.9 5.6 2.9s5.6-1.3 5.6-2.9v-5.2M21.5 10.2v5.6',
    saude: 'M12 20.4S4.6 15.8 4.6 10.6A4.1 4.1 0 0 1 12 7.9a4.1 4.1 0 0 1 7.4 2.7c0 5.2-7.4 9.8-7.4 9.8Z',
    outros: 'M5.5 12h.01M12 12h.01M18.5 12h.01',
    painel: 'M4 4h7v7H4Zm9 0h7v4.4h-7ZM13 11h7v9h-7ZM4 14h7v6H4Z',
    calendario: 'M3.5 6.5h17v14h-17ZM3.5 10.5h17M8 3.5v4M16 3.5v4M7.5 14.5h2M14.5 14.5h2M7.5 17.6h2M14.5 17.6h2',
    historico: 'M12 7.4v5l3.4 2M3.6 12.2a8.4 8.4 0 1 0 2.5-6M3.4 4.4v4.3h4.3',
    sino: 'M6.2 9.4a5.8 5.8 0 0 1 11.6 0c0 4.6 1.9 5.8 1.9 5.8H4.3s1.9-1.2 1.9-5.8ZM10 18.6a2 2 0 0 0 4 0',
    config: 'M4 7h9M17.5 7H20M4 12h3.5M12 12h8M4 17h11M19 17h1M14 7a1.9 1.9 0 1 0 3.8 0A1.9 1.9 0 0 0 14 7ZM8.5 12a1.9 1.9 0 1 0 3.8 0 1.9 1.9 0 0 0-3.8 0ZM16 17a1.9 1.9 0 1 0 3.8 0 1.9 1.9 0 0 0-3.8 0Z',
    mais: 'M12 5v14M5 12h14',
    check: 'M4.5 12.8 9.4 17.6 19.5 6.6',
    lixeira: 'M4.5 6.8h15M9.4 6.8V4.4h5.2v2.4M6.6 6.8 7.6 20.4h8.8l1-13.6M10.6 10.4v6.4M13.4 10.4v6.4',
    lapis: 'M4 20.2l4.4-1 10-10a2.2 2.2 0 0 0-3.1-3.1l-10 10ZM14.6 6.4l3.1 3.1',
    x: 'M6 6l12 12M18 6 6 18',
    busca: 'M10.8 17.6a6.8 6.8 0 1 0 0-13.6 6.8 6.8 0 0 0 0 13.6ZM15.8 15.8 20.5 20.5',
    voltar: 'M14.5 5.5 8 12l6.5 6.5',
    alerta: 'M12 4.4 21 19.6H3ZM12 10v4.2M12 16.9h.01',
    relogio: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7.4V12l3.2 1.9',
    sol: 'M12 16.4a4.4 4.4 0 1 0 0-8.8 4.4 4.4 0 0 0 0 8.8ZM12 2.6v2.2M12 19.2v2.2M2.6 12h2.2M19.2 12h2.2M5.2 5.2l1.6 1.6M17.2 17.2l1.6 1.6M18.8 5.2l-1.6 1.6M6.8 17.2l-1.6 1.6',
    lua: 'M20 14.4A8.4 8.4 0 0 1 9.6 4a8.6 8.6 0 1 0 10.4 10.4Z',
    download: 'M12 3.5v11M7.5 10.5 12 15l4.5-4.5M4.5 19.5h15',
    upload: 'M12 15.5v-11M7.5 8.5 12 4l4.5 4.5M4.5 19.5h15',
    info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 11v5.5M12 7.6h.01',
    escudo: 'M12 21.4s7-3.2 7-9V5.6L12 2.6 5 5.6v6.8c0 5.8 7 9 7 9ZM9 12.1l2.2 2.2 4.2-4.3',
    celular: 'M7 3.5h10v17H7ZM10.6 17.6h2.8',
    filtro: 'M3.5 5.5h17l-6.6 7.6v6.4l-3.8-2v-4.4Z',
    grafico: 'M4 19.5V4.5M4 19.5h16M8.2 19.5v-6.2M12.6 19.5V8.4M17 19.5v-9.4',
    atualizar: 'M20 12a8 8 0 1 1-2.4-5.7M20.3 4.2v4.4h-4.4',
    pago: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM8.4 12.2l2.6 2.6 4.8-5',
    desfazer: 'M4 12a8 8 0 1 0 2.4-5.7M3.7 4.2v4.4h4.4',
    pdf: 'M7 3.5h7l4.5 4.5v12.5H7ZM13.6 3.6v4.6h4.6M9.5 14h5M9.5 17h3',
    planilha: 'M4 5h16v14H4ZM4 9.6h16M10 9.6V19M15 9.6V19',
    calendario2: 'M3.5 6.5h17v14h-17ZM3.5 10.5h17M8 3.5v4M16 3.5v4M12 13v5M9.5 15.5h5',
    fogo: 'M12 22c3.6 0 6-2.3 6-5.4 0-3.9-3.4-5.4-3-9.6-2.2.6-4 2.6-4 4.6 0 1-.6 1.6-1.3 1.6-.8 0-1.3-.7-1.3-1.8C7 12.6 6 14 6 16.6 6 19.7 8.4 22 12 22Z',
    raio: 'M13.2 2.5 5.5 13.4h4.8l-.9 8.1 8.1-11.6h-5Z'
  };
  U.icone = function (nome, classe) {
    const d = CAMINHOS[nome] || CAMINHOS.outros;
    return '<svg class="ic ' + (classe || '') + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' + d + '"/></svg>';
  };
  U.temIcone = function (nome) { return !!CAMINHOS[nome]; };

  /* ---------------------------------- datas -------------------------------- */
  U.pad2 = function (n) { return String(n).padStart(2, '0'); };
  U.paraISO = function (d) { return d.getFullYear() + '-' + U.pad2(d.getMonth() + 1) + '-' + U.pad2(d.getDate()); };
  U.deISO = function (iso) {
    const p = String(iso || '').split('-');
    return new Date(Number(p[0]), Number(p[1]) - 1 || 0, Number(p[2]) || 1);
  };
  U.hojeISO = function () { return U.paraISO(new Date()); };
  U.agoraHHMM = function () {
    const d = new Date();
    return U.pad2(d.getHours()) + ':' + U.pad2(d.getMinutes());
  };
  U.fmtData = function (iso) {
    if (!iso) return '—';
    const p = String(iso).split('-');
    if (p.length !== 3) return iso;
    return p[2] + '/' + p[1] + '/' + p[0];
  };
  U.fmtDataHora = function (iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return U.pad2(d.getDate()) + '/' + U.pad2(d.getMonth() + 1) + '/' + d.getFullYear() + ' às ' + U.pad2(d.getHours()) + ':' + U.pad2(d.getMinutes());
  };
  U.fmtLonga = function (iso) {
    const d = U.deISO(iso);
    return d.getDate() + ' de ' + U.MESES[d.getMonth()] + ' de ' + d.getFullYear();
  };
  U.fmtMesAno = function (iso) {
    const d = U.deISO(iso);
    return U.MESES[d.getMonth()] + ' de ' + d.getFullYear();
  };
  U.addDias = function (iso, n) {
    const d = U.deISO(iso);
    d.setDate(d.getDate() + n);
    return U.paraISO(d);
  };
  U.diasNoMes = function (ano, mes1a12) { return new Date(ano, mes1a12, 0).getDate(); };
  U.addMeses = function (iso, k, diaAncora) {
    const d = U.deISO(iso);
    const ancora = diaAncora || d.getDate();
    let ano = d.getFullYear();
    let mes = d.getMonth() + k;
    ano += Math.floor(mes / 12);
    mes = ((mes % 12) + 12) % 12;
    const limite = U.diasNoMes(ano, mes + 1);
    return U.paraISO(new Date(ano, mes, Math.min(ancora, limite)));
  };
  U.addAnos = function (iso, k, diaAncora) {
    const d = U.deISO(iso);
    const ancora = diaAncora || d.getDate();
    const ano = d.getFullYear() + k;
    const limite = U.diasNoMes(ano, d.getMonth() + 1);
    return U.paraISO(new Date(ano, d.getMonth(), Math.min(ancora, limite)));
  };
  U.diffDias = function (a, b) {
    return Math.round((U.deISO(a).getTime() - U.deISO(b).getTime()) / 86400000);
  };
  U.mesDe = function (iso) { return String(iso).slice(0, 7); };
  U.anoDe = function (iso) { return Number(String(iso).slice(0, 4)); };
  U.horaValida = function (h) { return /^([01]\d|2[0-3]):[0-5]\d$/.test(String(h || '')); };

  /* -------------------------------- dinheiro ------------------------------- */
  U.fmtBRL = function (v) {
    return (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };
  U.parseValor = function (s) {
    let t = String(s == null ? '' : s).replace(/[R$\s\u00a0]/g, '');
    if (!t) return null;
    if (t.indexOf(',') >= 0) t = t.replace(/\./g, '').replace(',', '.');
    const n = parseFloat(t);
    if (isNaN(n) || n < 0) return null;
    return Math.round(n * 100) / 100;
  };

  /* ------------------------------- lembretes ------------------------------- */
  U.LEMBRETES = [7, 3, 1, 0, -1];
  U.rotuloLembrete = function (d) {
    if (d === 0) return 'No dia do vencimento';
    if (d === 1) return '1 dia antes';
    if (d > 1) return d + ' dias antes';
    if (d === -1) return 'Depois do vencimento (todo dia até pagar)';
    return Math.abs(d) + ' dias depois';
  };
  U.rotuloCurtoLembrete = function (d) {
    if (d === 0) return 'No dia';
    if (d === 1) return '1 dia antes';
    if (d > 1) return d + ' dias antes';
    return Math.abs(d) + ' dia' + (Math.abs(d) > 1 ? 's' : '') + ' depois';
  };

  /* ------------------------------ recorrências ----------------------------- */
  U.RECORRENCIAS = [
    { id: 'nenhuma', nome: 'Não se repete' },
    { id: 'semanal', nome: 'Toda semana' },
    { id: 'quinzenal', nome: 'A cada 15 dias' },
    { id: 'mensal', nome: 'Todo mês' },
    { id: 'bimestral', nome: 'A cada 2 meses' },
    { id: 'trimestral', nome: 'A cada 3 meses' },
    { id: 'semestral', nome: 'A cada 6 meses' },
    { id: 'anual', nome: 'Todo ano' }
  ];
  U.rotuloRecorrencia = function (id) {
    const r = U.RECORRENCIAS.filter(function (x) { return x.id === id; })[0];
    return r ? r.nome : 'Não se repete';
  };
  /** Próxima data de uma ocorrência, partindo de uma data qualquer (regra pura). */
  U.proximaDe = function (dataISO, recorrencia, diaAncora) {
    switch (recorrencia) {
      case 'semanal': return U.addDias(dataISO, 7);
      case 'quinzenal': return U.addDias(dataISO, 14);
      case 'mensal': return U.addMeses(dataISO, 1, diaAncora);
      case 'bimestral': return U.addMeses(dataISO, 2, diaAncora);
      case 'trimestral': return U.addMeses(dataISO, 3, diaAncora);
      case 'semestral': return U.addMeses(dataISO, 6, diaAncora);
      case 'anual': return U.addAnos(dataISO, 1, diaAncora);
      default: return null;
    }
  };
  U.proximaData = function (conta) {
    return U.proximaDe(conta.vencimento, conta.recorrencia, conta.diaAncora);
  };

  /* --------------------------------- status -------------------------------- */
  U.status = function (conta, hoje) {
    hoje = hoje || U.hojeISO();
    if (conta.pago) return 'paga';
    const d = U.diffDias(conta.vencimento, hoje);
    if (d < 0) return 'atrasada';
    if (d <= 7) return 'proxima';
    return 'avencer';
  };
  U.STATUS = {
    paga: { rotulo: 'Paga', classe: 'paga' },
    proxima: { rotulo: 'Vence em breve', classe: 'proxima' },
    atrasada: { rotulo: 'Atrasada', classe: 'atrasada' },
    avencer: { rotulo: 'A vencer', classe: 'avencer' }
  };
  U.textoPrazo = function (iso, hoje) {
    hoje = hoje || U.hojeISO();
    const d = U.diffDias(iso, hoje);
    if (d === 0) return 'Vence hoje';
    if (d === 1) return 'Vence amanhã';
    if (d > 1) return 'Faltam ' + d + ' dias';
    if (d === -1) return '1 dia de atraso';
    return Math.abs(d) + ' dias de atraso';
  };

  /* -------------------------------- utilidades ----------------------------- */
  U.uid = function (pre) {
    return (pre || 'c') + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  };
  U.norm = function (s) {
    return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  };
  U.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  U.clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  U.ordenar = function (lista, criterio) {
    const c = criterio || 'vencimento';
    const arr = lista.slice();
    if (c === 'valor') return arr.sort(function (a, b) { return b.valor - a.valor || a.vencimento.localeCompare(b.vencimento); });
    if (c === 'nome') return arr.sort(function (a, b) { return a.nome.localeCompare(b.nome, 'pt-BR'); });
    if (c === 'status') return arr.sort(function (a, b) { return a.vencimento.localeCompare(b.vencimento); });
    return arr.sort(function (a, b) { return a.vencimento.localeCompare(b.vencimento) || a.nome.localeCompare(b.nome, 'pt-BR'); });
  };
  U.somar = function (lista) { return lista.reduce(function (t, c) { return t + (Number(c.valor) || 0); }, 0); };
  U.saudacao = function () {
    const h = new Date().getHours();
    if (h < 12) return 'Bom dia';
    if (h < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  raiz.U = U;
  if (typeof module !== 'undefined' && module.exports) module.exports = U;
})(typeof window !== 'undefined' ? window : globalThis);
