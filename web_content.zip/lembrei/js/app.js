/* ==========================================================================
   Lembrei — app.js
   Controlador: rotas, ações, motor de lembretes, tema, onboarding, backup.
   ========================================================================== */
(function (raiz) {
  'use strict';

  const U = raiz.U;
  const Store = raiz.Store;
  const V = raiz.Views;
  const M = raiz.ViewsMais;
  const Rel = raiz.Relatorios;

  const App = {};
  App.estado = {
    rota: 'painel',
    modal: null,
    idEdicao: null,
    filtro: 'todas',
    categoria: 'todas',
    mes: '',
    busca: '',
    ordem: 'vencimento',
    periodo: 'mes',
    mesCal: '',
    diaSel: '',
    timerLembrete: null,
    varreduraFeita: ''
  };

  /* --------------------------- elementos fixos ---------------------------- */
  const el = function (id) { return document.getElementById(id); };
  const tela = function () { return el('tela'); };
  const topoEl = function () { return el('topo'); };

  App.toastTimer = null;
  App.toast = function (msg, tipo) {
    const t = el('toast');
    t.textContent = msg;
    t.className = 'toast ' + (tipo || '');
    t.hidden = false;
    clearTimeout(App.toastTimer);
    App.toastTimer = setTimeout(function () { t.hidden = true; }, 3200);
  };

  /* --------------------------------- modal -------------------------------- */
  App.abrirModal = function (html, opcoes) {
    opcoes = opcoes || {};
    const m = el('modal');
    m.innerHTML = '<div class="modal" role="dialog" aria-modal="true">' +
      '<button type="button" class="modal-x" data-acao="fechar-modal" aria-label="Fechar" title="Fechar">✕</button>' +
      html + '</div>';
    m.hidden = false;
    App.estado.modal = opcoes;
    document.body.style.overflow = 'hidden';
    const foco = m.querySelector('input,select,textarea') || m.querySelector('button:not(.modal-x)');
    if (foco && opcoes.foco !== false) setTimeout(function () { try { foco.focus(); } catch (e) {} }, 90);
  };
  App.fecharModal = function () {
    const m = el('modal');
    m.hidden = true;
    m.innerHTML = '';
    App.estado.modal = null;
    document.body.style.overflow = '';
  };
  App.confirmar = function (opcoes) {
    App.abrirModal(
      '<div class="modal-icone ' + (opcoes.tipo || '') + '">' + U.icone(opcoes.icone || 'alerta') + '</div>' +
      '<h3>' + U.esc(opcoes.titulo) + '</h3><p>' + opcoes.texto + '</p>' +
      '<div class="linha-botoes">' +
        '<button class="btn btn-contorno" data-acao="fechar-modal">' + U.esc(opcoes.cancelar || 'Cancelar') + '</button>' +
        '<button class="btn ' + (opcoes.perigo ? 'btn-perigo' : 'btn-primario') + '" data-acao="confirmar-modal">' + U.esc(opcoes.confirmar || 'Confirmar') + '</button>' +
      '</div>', { foco: false, onConfirmar: opcoes.onConfirmar, perigo: opcoes.perigo });
  };

  /* --------------------------------- tema --------------------------------- */
  App.aplicarTema = function () {
    const cfg = Store.config();
    const pref = cfg.tema || 'auto';
    const escuroSO = raiz.matchMedia && raiz.matchMedia('(prefers-color-scheme: dark)').matches;
    const tema = pref === 'auto' ? (escuroSO ? 'escuro' : 'claro') : pref;
    document.documentElement.setAttribute('data-tema', tema);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', tema === 'escuro' ? '#081422' : '#0d2b4e');
  };
  App.alternarTema = function () {
    const atual = document.documentElement.getAttribute('data-tema');
    Store.salvarConfig({ tema: atual === 'escuro' ? 'claro' : 'escuro' });
    App.aplicarTema();
    App.render();
  };

  /* --------------------------------- rotas -------------------------------- */
  const ROTAS = {
    painel: function () { return V.painel(); },
    contas: function () { return '<div class="secao" style="margin-top:6px"><h2>Minhas contas</h2><span class="mini suave">' + Store.contas().length + ' no total</span></div>' + V.contas(); },
    calendario: function () { return '<div class="secao" style="margin-top:6px"><h2>Calendário financeiro</h2></div>' + M.calendario(); },
    historico: function () { return '<div class="secao" style="margin-top:6px"><h2>Histórico e relatórios</h2></div>' + M.historico(); },
    notificacoes: function () { return M.notificacoes(); },
    config: function () { return M.config(); }
  };

  App.navegar = function (rota, extra) {
    if (!ROTAS[rota]) rota = 'painel';
    App.estado.rota = rota;
    if (extra) Object.assign(App.estado, extra);
    if (rota === 'calendario' && !App.estado.mesCal) App.estado.mesCal = U.mesDe(U.hojeISO());
    location.hash = rota;
    App.render();
    window.scrollTo({ top: 0, behavior: 'auto' });
  };

  /* -------------------------------- render -------------------------------- */
  App.render = function () {
    const r = App.estado.rota;
    topoEl().innerHTML = V.topo(App.estado);
    el('abas').innerHTML = V.abas(r === 'notificacoes' ? 'contas' : r);
    tela().innerHTML = (ROTAS[r] || ROTAS.painel)();
    const busca = el('campo-busca');
    if (busca) {
      busca.addEventListener('input', App.debounce(function (ev) {
        App.estado.busca = ev.target.value;
        App.renderSemFoco();
      }, 260));
      if (App.estado.busca && document.activeElement !== busca) { /* mantém filtro visual */ }
    }
    const campoMes = el('campo-mes');
    if (campoMes) {
      campoMes.addEventListener('change', function (ev) {
        App.estado.mes = ev.target.value;
        App.renderSemFoco();
      });
    }
  };
  App.renderSemFoco = function () {
    const buscaAtual = App.estado.busca;
    const r = App.estado.rota;
    tela().innerHTML = (ROTAS[r] || ROTAS.painel)();
    const busca = el('campo-busca');
    if (busca) {
      busca.value = buscaAtual;
      busca.focus();
      try { busca.setSelectionRange(busca.value.length, busca.value.length); } catch (e) {}
      busca.addEventListener('input', App.debounce(function (ev) {
        App.estado.busca = ev.target.value;
        App.renderSemFoco();
      }, 260));
    }
    const campoMes = el('campo-mes');
    if (campoMes) {
      campoMes.addEventListener('change', function (ev) { App.estado.mes = ev.target.value; App.renderSemFoco(); });
    }
  };
  App.debounce = function (fn, ms) {
    let t;
    return function () {
      const args = arguments, ctx = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(ctx, args); }, ms);
    };
  };

  /* ------------------------------- notificações --------------------------- */
  App.suportaNotificacao = function () { return typeof Notification !== 'undefined'; };
  App.suportaSW = function () { return 'serviceWorker' in navigator; };
  App.permissaoNotificacao = function () {
    if (!App.suportaNotificacao()) return 'indisponivel';
    return Notification.permission;
  };
  App.pedirNotificacao = async function () {
    if (!App.suportaNotificacao()) {
      App.toast('Este navegador não oferece notificações. Use a Central de lembretes.', 'erro');
      return 'indisponivel';
    }
    let p = Notification.permission;
    try { p = await Notification.requestPermission(); } catch (e) { p = Notification.permission; }
    if (p === 'granted') {
      App.toast('Avisos ativados! Você será lembrado das contas.', 'ok');
      setTimeout(App.verificarLembretes, 400);
    } else if (p === 'denied') {
      App.toast('Permissão negada. Veja "Como liberar" para ativar nas configurações.', 'erro');
    } else {
      App.toast('Permissão não concedida.');
    }
    App.render();
    return p;
  };

  /**
   * Mostra o aviso: pelo Service Worker quando possível, senão pela página.
   * A ordem importa: o registro na Central acontece PRIMEIRO, então o lembrete
   * nunca se perde mesmo se o aviso do sistema falhar ou demorar demais.
   */
  App.mostrarAviso = async function (titulo, corpo, etiqueta) {
    const registro = {
      id: U.uid('n'), titulo: titulo, corpo: corpo,
      quando: new Date().toISOString(), sistema: false
    };
    await Store.registrarNotificacao(registro);

    let noSistema = false;
    try {
      if (App.suportaSW() && navigator.serviceWorker.controller) {
        // limite de tempo: o aviso do sistema nunca pode travar o app
        const reg = await Promise.race([
          navigator.serviceWorker.ready,
          new Promise(function (res) { setTimeout(function () { res(null); }, 2500); })
        ]);
        if (reg && reg.showNotification) {
          await reg.showNotification(titulo, {
            body: corpo, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png',
            tag: etiqueta || ('lembrei-' + Date.now()), renotify: false,
            data: { url: './index.html#notificacoes' }
          });
          noSistema = true;
        }
      }
      if (!noSistema && App.permissaoNotificacao() === 'granted') {
        new Notification(titulo, { body: corpo, icon: 'icons/icon-192.png', tag: etiqueta || 'lembrei' });
        noSistema = true;
      }
    } catch (e) { noSistema = false; }

    if (noSistema) {
      registro.sistema = true;
      try { await Store.putBruto('notificacoes', registro); } catch (e) { /* já está na Central */ }
    }
    return noSistema;
  };

  /**
   * Regras de lembrete (idênticas às do calendário .ics).
   * d > 0 → avisa d dias antes; d = 0 → no dia; d = -1 → todo dia depois do vencimento.
   */
  /** Lembretes normalizados (modelo v2: cada um tem dias + hora). */
  App.lembretesDaConta = function (c) { return U.lembretesNormalizados(c, Store.config()); };

  /** Lista de lembretes futuros para a Central. */
  App.proximosLembretes = function (janelaDias) {
    const hoje = U.hojeISO();
    const fim = U.addDias(hoje, janelaDias || 30);
    const cfg = Store.config();
    const saida = [];
    Store.contas().forEach(function (c) {
      if (c.pago) return;
      U.lembretesNormalizados(c, cfg).forEach(function (L) {
        const data = U.addDias(c.vencimento, -L.dias);
        if (data < hoje || data > fim) return;
        saida.push({ id: c.id, nome: c.nome, valor: c.valor, dias: L.dias, data: data, hora: L.hora, demo: !!c.demo });
      });
      const rep = U.normalizarRepeticao(c, cfg);
      const inter = U.intervaloRepeticao(rep);
      const atraso = U.diffDias(hoje, c.vencimento);
      if (inter && atraso > 0) {
        const k = Math.ceil((atraso - 1) / inter);
        const data = U.addDias(c.vencimento, 1 + k * inter);
        if (data <= fim && (!rep.fim || data <= rep.fim)) {
          saida.push({ id: c.id, nome: c.nome, valor: c.valor, dias: -1, data: data, hora: rep.hora, demo: !!c.demo });
        }
      }
    });
    return saida.sort(function (a, b) { return a.data.localeCompare(b.data) || a.nome.localeCompare(b.nome); });
  };

  App.contarAvisosPendentes = function () {
    const hoje = U.hojeISO();
    const cfg = Store.config();
    let n = 0;
    Store.contas().forEach(function (c) {
      if (c.pago || c.demo) return;
      U.calcularAvisosConta(c, hoje, '23:59', cfg).forEach(function (av) {
        if (!Store.jaEnviado(av.chave)) n++;
      });
    });
    return n;
  };

  /** Varredura real: dispara os avisos cujo dia e horário já chegaram. */
  App.verificarLembretes = async function (silencioso) {
    const hoje = U.hojeISO();
    const agora = U.agoraHHMM();
    const cfg = Store.config();
    const disparar = [];

    Store.contas().forEach(function (c) {
      if (c.demo) return;                       // exemplos nunca notificam
      U.calcularAvisosConta(c, hoje, agora, cfg).forEach(function (av) {
        if (!Store.jaEnviado(av.chave)) disparar.push({ chave: av.chave, titulo: av.titulo, corpo: av.corpo, id: c.id });
      });
    });

    if (!disparar.length) {
      App.estado.varreduraFeita = new Date().toISOString();
      if (!silencioso && App.estado.rota === 'notificacoes') App.render();
      return 0;
    }
    let mostrados = 0;
    for (const av of disparar) {
      const ok = await App.mostrarAviso(av.titulo, av.corpo, 'lembrei-' + av.id + '-' + av.chave);
      if (ok) mostrados++;
      await Store.marcarEnviado(av.chave);
    }
    App.estado.varreduraFeita = new Date().toISOString();
    if (mostrados > 0) App.toast(mostrados + ' lembrete(s) de conta enviado(s).', 'ok');
    else if (!silencioso) App.toast(disparar.length + ' lembrete(s) registrado(s) na Central (aviso do sistema indisponível).');
    App.render();
    return disparar.length;
  };

  /* ================================= DADOS DE EXEMPLO =====================
     Todos com demo:true e selo "EXEMPLO" na tela. Nunca se misturam aos
     dados reais: podem ser apagados com um toque e nunca geram notificação. */
  App.criarExemplos = async function () {
    const hoje = U.hojeISO();
    const base = [
      { nome: 'Conta de luz', valor: 187.42, vencimento: U.addDias(hoje, -6), categoria: 'luz', beneficiario: 'Enel Distribuição', descricao: 'Leitura do medidor — consumo do mês', pago: false, recorrencia: 'mensal', lembretes: [7, 3, 1, 0, -1] },
      { nome: 'Internet fibra 500 MB', valor: 119.9, vencimento: U.addDias(hoje, 3), categoria: 'internet', beneficiario: 'Vivo Fibra', descricao: 'Plano residencial', pago: false, recorrencia: 'mensal', lembretes: [3, 0] },
      { nome: 'Cartão de crédito', valor: 1240.35, vencimento: U.addDias(hoje, 6), categoria: 'cartao', beneficiario: 'Banco do Brasil', descricao: 'Fatura fechada — compras de outubro', pago: false, recorrencia: 'mensal', lembretes: [7, 1, 0] },
      { nome: 'Água', valor: 92.15, vencimento: U.addDias(hoje, -14), categoria: 'agua', beneficiario: 'Sabesp', pago: true, pagoEm: U.addDias(hoje, -13) + 'T10:12:00.000Z', recorrencia: 'mensal', lembretes: [3, 0] },
      { nome: 'Aluguel', valor: 1600, vencimento: U.addDias(hoje, 12), categoria: 'aluguel', beneficiario: 'Imobiliária Central', pago: false, recorrencia: 'mensal', lembretes: [7, 3, 1, 0] },
      { nome: 'Mensalidade da faculdade', valor: 890, vencimento: U.addDias(hoje, 5), categoria: 'faculdade', beneficiario: 'Faculdade Horizonte', descricao: 'Curso de Administração — 2º semestre', pago: false, recorrencia: 'mensal', lembretes: [7, 0] }
    ];
    for (const b of base) {
      const conta = Object.assign({
        id: U.uid('d'),
        demo: true,
        serieId: '',
        recorrenciaFim: '',
        repetirAtePagar: true,
        hora: Store.config().hora || '09:00',
        criadoEm: new Date().toISOString(),
        diaAncora: U.deISO(b.vencimento).getDate()
      }, b);
      await Store.salvarConta(conta);
    }
    await Store.salvarConfig({ exemplosCarregados: true });
  };

  /* ================================ AÇÕES ================================ */
  App.pagarConta = async function (id) {
    const c = Store.obterConta(id);
    if (!c) return;
    const quando = new Date().toISOString();
    c.pago = true;
    c.pagoEm = quando;
    await Store.salvarConta(c);

    let proxima = null;
    if (c.recorrencia && c.recorrencia !== 'nenhuma') {
      const data = U.proximaDe(c.vencimento, c.recorrencia, c.diaAncora || U.deISO(c.vencimento).getDate());
      const dentroDoLimite = !c.recorrenciaFim || data <= c.recorrenciaFim;
      if (data && dentroDoLimite) {
        const jaExiste = Store.contas().some(function (x) {
          return !x.demo === !c.demo && x.nome === c.nome && x.vencimento === data && x.id !== c.id && (x.serieId || x.id) === (c.serieId || c.id);
        }) || Store.contas().some(function (x) { return x.nome === c.nome && x.vencimento === data; });
        if (!jaExiste) {
          proxima = Object.assign({}, c, {
            id: U.uid('c'),
            vencimento: data,
            pago: false,
            pagoEm: '',
            serieId: c.serieId || c.id,
            criadoEm: quando,
            atualizadoEm: quando,
            diaAncora: c.diaAncora || U.deISO(c.vencimento).getDate()
          });
          await Store.salvarConta(proxima);
        }
      }
    }
    App.fecharModal();
    App.render();
    if (proxima) {
      App.toast('Conta paga! Próximo vencimento criado: ' + U.fmtData(proxima.vencimento) + '.', 'ok');
    } else {
      App.toast('Conta marcada como paga. Os lembretes dela foram encerrados.', 'ok');
    }
  };
  App.duplicarConta = function (id) {
    const c = Store.obterConta(id);
    if (!c) return;
    App.confirmar({
      icone: 'atualizar',
      titulo: 'Duplicar esta conta?',
      texto: 'Vou criar uma cópia de <b>' + U.esc(c.nome) + '</b> com o mesmo valor, categoria, lembretes e repetição.<br><br>' +
        'A cópia entra como <b>pendente</b> e você pode mudar a data de vencimento em seguida. A conta original não é alterada.',
      confirmar: 'Duplicar',
      onConfirmar: async function () {
        const copia = JSON.parse(JSON.stringify(c));
        copia.id = U.uid('c');
        copia.nome = c.nome + ' (cópia)';
        copia.pago = false;
        copia.pagoEm = '';
        copia.serieId = '';
        copia.demo = false;
        copia.criadoEm = new Date().toISOString();
        copia.lembretes = (copia.lembretes || []).map(function (L) { return { id: U.uid('L'), dias: L.dias, hora: L.hora }; });
        await Store.salvarConta(copia);
        App.fecharModal();
        App.render();
        App.toast('Conta duplicada. Ajuste a data de vencimento se precisar.', 'ok');
      }
    });
  };

  /** Conta com valor variável: pergunta o valor antes de marcar como paga. */
  App.pagarValorVariavel = function (id) {
    const c = Store.obterConta(id);
    if (!c) return;
    App.abrirModal(
      '<div class="modal-icone ok">' + U.icone('dinheiro') + '</div>' +
      '<h3>Qual foi o valor pago?</h3>' +
      '<p>Esta conta tem <b>valor variável</b>. Informe o valor desta ocorrência — o histórico guarda o valor real.</p>' +
      '<div class="form-grupo"><label for="v-pago">Valor em reais (R$)</label>' +
      '<input class="campo campo-valor" id="v-pago" type="text" inputmode="decimal" value="' + String(c.valor).replace('.', ',') + '"></div>' +
      '<div class="linha-botoes">' +
      '<button class="btn btn-contorno" data-acao="fechar-modal">Cancelar</button>' +
      '<button class="btn btn-verde" data-acao="confirmar-valor-pago" data-id="' + c.id + '">' + U.icone('check') + 'Confirmar pagamento</button></div>'
    );
  };

  App.pagarComConfirmacao = function (id) {
    const c = Store.obterConta(id);
    if (!c) return;
    if (c.valorVariavel) { App.pagarValorVariavel(id); return; }
    App.confirmar({
      tipo: 'ok', icone: 'check',
      titulo: 'Marcar como paga?',
      texto: '<b>' + U.esc(c.nome) + '</b> — ' + U.fmtBRL(c.valor) + ', vencimento ' + U.fmtData(c.vencimento) + '.<br><br>' +
        'Vou registrar a data de hoje como pagamento, atualizar o painel e parar os lembretes desta conta.' +
        (c.recorrencia !== 'nenhuma' ? '<br><br>Como esta conta é <b>' + U.rotuloRecorrencia(c.recorrencia).toLowerCase() + '</b>, a próxima será criada em <b>' + U.fmtData(U.proximaDe(c.vencimento, c.recorrencia, c.diaAncora)) + '</b>.' : '') +
        '<br><br>Não é preciso enviar comprovante.',
      confirmar: 'Sim, marcar como paga',
      onConfirmar: function () { App.pagarConta(id); }
    });
  };
  App.desfazerPagamento = function (id) {
    const c = Store.obterConta(id);
    if (!c) return;
    App.confirmar({
      titulo: 'Desfazer o pagamento?',
      texto: '<b>' + U.esc(c.nome) + '</b> voltará para a lista de contas pendentes e os lembretes serão reativados.' +
        (c.seriesProxima ? '' : '') + '<br><br>A conta continuará aparecendo no histórico com o registro do pagamento removido.',
      confirmar: 'Desfazer pagamento',
      icone: 'desfazer',
      onConfirmar: async function () {
        // remove a próxima ocorrência gerada, se existir e ainda não tiver sido paga/editada
        const serie = c.serieId || c.id;
        const proxima = Store.contas().filter(function (x) {
          return x.id !== c.id && x.vencimento > c.vencimento && (x.serieId === serie || (x.nome === c.nome && x.recorrencia === c.recorrencia)) && !x.pago && !x.demo === !c.demo;
        }).sort(function (a, b) { return a.vencimento.localeCompare(b.vencimento); })[0];
        c.pago = false;
        c.pagoEm = '';
        await Store.salvarConta(c);
        if (proxima) await Store.excluirConta(proxima.id);
        App.fecharModal();
        App.render();
        App.toast('Pagamento desfeito. A conta voltou para as pendências.', 'ok');
      }
    });
  };
  App.excluirConta = function (id) {
    const c = Store.obterConta(id);
    if (!c) return;
    App.confirmar({
      perigo: true, icone: 'lixeira',
      titulo: 'Excluir esta conta?',
      texto: '<b>' + U.esc(c.nome) + '</b> — ' + U.fmtBRL(c.valor) + ', vencimento ' + U.fmtData(c.vencimento) + '.<br><br>' +
        'Esta ação não pode ser desfeita. Se você só quer parar de ver a conta, marque-a como paga ou desative os lembretes.',
      confirmar: 'Excluir definitivamente',
      onConfirmar: async function () {
        await Store.excluirConta(id);
        App.fecharModal();
        App.render();
        App.toast('Conta excluída.', 'ok');
      }
    });
  };

  /* ------------------------------ formulário ------------------------------- */
  App.novaConta = function () {
    App.estado.idEdicao = null;
    App.abrirModal(V.formularioV2(null));
    App.ligarFormulario();
  };
  App.editarConta = function (id) {
    const c = Store.obterConta(id);
    if (!c) return;
    App.estado.idEdicao = id;
    App.abrirModal(V.formularioV2(c));
    App.ligarFormulario();
  };
  App.ligarFormulario = function () {
    const form = el('form-conta');
    if (!form) return;
    form.addEventListener('submit', App.salvarFormulario);

    const rec = el('f-rec');
    if (rec) rec.addEventListener('change', function () {
      const g = el('grupo-rec-extra');
      if (g) g.hidden = rec.value === 'nenhuma';
    });

    // prévia dos lembretes acompanha a data de vencimento
    const venc = el('f-venc');
    if (venc) venc.addEventListener('change', function () {
      App.estado.vencimentoForm = venc.value || U.hojeISO();
      App.renderListaLembretes();
    });

    // editar dias/horário dentro da lista
    const lista = el('lista-lembretes');
    if (lista) {
      lista.addEventListener('change', function (ev) {
        const item = ev.target.closest('[data-lembrete-id]');
        if (!item) return;
        const L = (App.estado.lembretes || []).filter(function (x) { return x.id === item.dataset.lembreteId; })[0];
        if (!L) return;
        if (ev.target.dataset.campo === 'dias') {
          const n = Math.max(0, Math.min(365, Math.round(Number(ev.target.value) || 0)));
          if ((App.estado.lembretes || []).some(function (x) { return x.id !== L.id && x.dias === n; })) {
            App.toast('Já existe um lembrete com ' + n + ' dia(s) antes. Ajuste o outro em vez de duplicar.', 'erro');
            ev.target.value = L.dias;
            return;
          }
          L.dias = n;
        } else if (ev.target.dataset.campo === 'hora') {
          L.hora = U.horaValida(ev.target.value) ? ev.target.value : L.hora;
        }
        App.estado.lembretes.sort(function (a, b) { return b.dias - a.dias; });
        App.renderListaLembretes();
      });
    }

    const novoDias = el('novo-dias');
    if (novoDias) novoDias.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') { ev.preventDefault(); App.addLembrete(Number(novoDias.value)); novoDias.value = ''; }
    });
  };

  /** Redesenha a lista de lembretes e o estado dos chips. */
  App.renderListaLembretes = function () {
    const alvo = el('lista-lembretes');
    if (!alvo) return;
    alvo.innerHTML = V.listaLembretesHTML();
    document.querySelectorAll('[data-acao="add-lembrete"]').forEach(function (b) {
      const ativo = (App.estado.lembretes || []).some(function (L) { return L.dias === Number(b.dataset.dias); });
      b.classList.toggle('marcado', ativo);
      b.setAttribute('aria-pressed', String(ativo));
    });
    const tot = el('total-lembretes');
    if (tot) tot.textContent = (App.estado.lembretes || []).length + ' lembrete(s) configurado(s).';
  };

  App.addLembrete = function (dias, hora) {
    if (App.estado.lembretes === undefined) App.estado.lembretes = [];
    const n = Math.max(0, Math.min(365, Math.round(Number(dias))));
    if (!Number.isFinite(n)) { App.toast('Digite quantos dias antes (0 a 365).', 'erro'); return; }
    const existente = App.estado.lembretes.filter(function (L) { return L.dias === n; })[0];
    if (existente) {
      App.estado.lembretes = App.estado.lembretes.filter(function (L) { return L.dias !== n; });
      App.toast('Lembrete de ' + (n === 0 ? 'no dia do vencimento' : n + ' dia' + (n > 1 ? 's' : '') + ' antes') + ' removido.');
    } else {
      const horaPadrao = hora
        || (el('rep-hora') && el('rep-hora').value)
        || Store.config().hora || '09:00';
      App.estado.lembretes.push(U.novoLembrete(n, horaPadrao));
      App.estado.lembretes.sort(function (a, b) { return b.dias - a.dias; });
    }
    App.renderListaLembretes();
  };

  App.removerLembrete = function (id) {
    App.estado.lembretes = (App.estado.lembretes || []).filter(function (L) { return L.id !== id; });
    App.renderListaLembretes();
    App.toast('Lembrete excluído.', 'ok');
  };

  App.salvarFormulario = async function (ev) {
    ev.preventDefault();
    const id = el('f-id').value;
    const nome = el('f-nome').value.trim();
    const valor = U.parseValor(el('f-valor').value);
    const venc = el('f-venc').value;
    let ok = true;

    function marcar(campo, erro, cond) {
      const inp = el(campo), msg = el(erro);
      if (!inp) return;
      if (cond) { inp.classList.remove('campo-erro'); if (msg) msg.hidden = true; }
      else { inp.classList.add('campo-erro'); if (msg) msg.hidden = false; ok = false; }
    }
    marcar('f-nome', 'e-nome', nome.length >= 2);
    marcar('f-valor', 'e-valor', valor !== null && valor > 0);
    marcar('f-venc', 'e-venc', !!venc);
    if (!ok) {
      App.toast('Confira os campos destacados em vermelho.', 'erro');
      const primeiro = el('form-conta').querySelector('.campo-erro');
      if (primeiro) primeiro.focus();
      return;
    }

    const lembretes = (App.estado.lembretes || [])
      .map(function (L) { return { id: L.id, dias: Math.max(0, Math.min(365, Number(L.dias) || 0)), hora: U.horaValida(L.hora) ? L.hora : '09:00' }; })
      .sort(function (a, b) { return b.dias - a.dias; });

    const modoEl = document.querySelector('#chips-repeticao .chip.marcado');
    const modo = modoEl ? modoEl.dataset.modo : 'nenhuma';
    const repeticao = {
      modo: modo,
      intervalo: modo === 'custom' ? Math.max(1, Math.min(365, Number(el('rep-intervalo') && el('rep-intervalo').value) || 5)) : null,
      hora: U.horaValida(el('rep-hora') && el('rep-hora').value) ? el('rep-hora').value : '09:00',
      fim: (modo === 'nenhuma') ? '' : ((el('rep-fim') && el('rep-fim').value) || '')
    };

    const existente = id ? Store.obterConta(id) : null;
    const recorrencia = el('f-rec').value;
    const conta = Object.assign({
      id: id || U.uid('c'), demo: false, serieId: '', criadoEm: new Date().toISOString(), pago: false, pagoEm: ''
    }, existente || {}, {
      nome: nome,
      valor: valor,
      vencimento: venc,
      categoria: el('f-cat').value,
      beneficiario: el('f-benef').value.trim(),
      descricao: el('f-desc').value.trim(),
      lembretes: lembretes,
      repeticao: repeticao,
      repetirAtePagar: U.intervaloRepeticao(repeticao) > 0,
      recorrencia: recorrencia,
      recorrenciaFim: recorrencia === 'nenhuma' ? '' : ((el('f-rec-fim') && el('f-rec-fim').value) || ''),
      valorVariavel: !!(el('sw-valor-variavel') && el('sw-valor-variavel').classList.contains('ligado')),
      hora: lembretes.length ? lembretes[0].hora : (repeticao.hora || '09:00'),
      diaAncora: U.deISO(venc).getDate()
    });
    if (existente && existente.pago) { conta.pago = true; conta.pagoEm = existente.pagoEm; }

    await Store.salvarConta(conta);
    App.fecharModal();
    App.render();
    App.toast(existente ? 'Conta atualizada com sucesso.' : 'Conta cadastrada! Você será avisado nos horários escolhidos.', 'ok');
    App.verificarLembretes(true);
  };

  /* ------------------------------- detalhes -------------------------------- */
  App.detalhes = function (id) {
    const c = Store.obterConta(id);
    if (!c) return;
    App.abrirModal(V.detalhes(c) + '<div class="linha-botoes" style="margin-top:8px"><button class="btn btn-perigo" data-acao="excluir" data-id="' + c.id + '">' + U.icone('lixeira') + 'Excluir conta</button></div>', { foco: false });
  };

  /* ------------------------------ exportações ------------------------------ */
  App.exportarCSV = function () {
    const contas = Store.contas();
    if (!contas.length) { App.toast('Nenhuma conta para exportar ainda.', 'erro'); return; }
    const nome = 'lembrei-contas-' + U.hojeISO() + '.csv';
    Rel.baixar(nome, Rel.csv(contas), 'text/csv;charset=utf-8');
    App.toast('CSV gerado (' + contas.length + ' contas). Abra no Excel ou Google Planilhas.', 'ok');
  };
  App.exportarPDF = function () {
    const contas = Store.contas();
    if (!contas.length) { App.toast('Nenhuma conta para relatar ainda.', 'erro'); return; }
    const m = V.metricas(contas);
    const resumo = [
      ['Contas cadastradas', String(contas.length)],
      ['Total pendente', U.fmtBRL(m.valorPend)],
      ['Total pago no mês', U.fmtBRL(m.valorPagasMes)],
      ['Total a pagar no mês', U.fmtBRL(m.valorPagarMes)],
      ['Contas vencidas', String(m.qtdVencidas) + ' (' + U.fmtBRL(m.valorVencidas) + ')']
    ];
    const ok = Rel.imprimir(Rel.htmlRelatorio(contas, resumo, 'todas as contas — ' + U.fmtMesAno(U.hojeISO())), 'Relatório Lembrei');
    if (ok) App.toast('Escolha "Salvar como PDF" na janela de impressão.', 'ok');
    else App.toast('O navegador bloqueou a janela. Permita pop-ups para gerar o PDF.', 'erro');
  };
  App.exportarICS = function () {
    const contas = Store.contas().filter(function (c) { return !c.pago; });
    if (!contas.length) { App.toast('Nenhuma conta pendente para gerar o calendário.', 'erro'); return; }
    const r = Rel.ics(contas, Store.config(), U.hojeISO());
    if (!r.eventos) { App.toast('Nada a agendar no período.', 'erro'); return; }
    Rel.baixar('lembrei-calendario-' + U.hojeISO() + '.ics', r.texto, 'text/calendar;charset=utf-8');
    App.abrirModal(
      '<div class="modal-icone ok">' + U.icone('calendario') + '</div>' +
      '<h3>Calendário gerado!</h3>' +
      '<p>Foram criados <b>' + r.eventos + ' compromisso(s)</b> com alarmes configurados exatamente como no app. ' +
      'Isso produz <b>notificações reais</b> no seu celular, <b>mesmo com o Lembrei fechado</b>.</p>' +
      '<div class="caixa-info">' +
      '<b>Android:</b> abra o arquivo baixado (Notificações ▸ Downloads) e escolha o <b>Google Agenda</b> ou o app de Agenda do aparelho → "Importar".<br><br>' +
      '<b>iPhone:</b> abra o arquivo baixado no app <b>Arquivos</b>, toque nele e escolha <b>Adicionar à Agenda</b>. ' +
      'Ou envie o arquivo para você mesmo por e-mail/WhatsApp e abra pelo celular.<br><br>' +
      '<b>Manutenção:</b> refaça a exportação a cada mês (ou quando cadastrar contas novas) para manter a agenda atualizada com os novos vencimentos.</div>' +
      '<div class="linha-botoes"><button class="btn btn-claro btn-largo" data-acao="fechar-modal">Entendi</button></div>',
      { foco: false }
    );
  };
  App.exportarBackup = function () {
    const pacote = Store.exportar();
    const nome = 'lembrei-backup-' + U.hojeISO() + '.json';
    Rel.baixar(nome, JSON.stringify(pacote, null, 2), 'application/json');
    App.abrirModal(
      '<div class="modal-icone ok">' + U.icone('escudo') + '</div>' +
      '<h3>Backup criado</h3>' +
      '<p>O arquivo <b>' + nome + '</b> contém suas ' + pacote.contas.length + ' conta(s) e suas preferências, incluindo as de exemplo.</p>' +
      '<div class="caixa-info">Guarde esse arquivo no seu e-mail, Google Drive, iCloud ou WhatsApp. ' +
      'Para usar em outro celular, instale o Lembrei lá e vá em <b>Ajustes ▸ Restaurar backup</b>. ' +
      'O arquivo é seu e não passa por nenhum servidor.</div>' +
      '<div class="linha-botoes"><button class="btn btn-claro btn-largo" data-acao="fechar-modal">Fechar</button></div>',
      { foco: false }
    );
  };
  App.restaurarBackup = function () {
    const inp = el('arq-backup');
    if (!inp) return;
    inp.value = '';
    inp.onchange = async function () {
      const f = inp.files && inp.files[0];
      if (!f) return;
      try {
        const texto = await f.text();
        const pacote = JSON.parse(texto);
        App.confirmar({
          titulo: 'Como restaurar?',
          texto: 'O arquivo tem <b>' + (pacote.contas || []).length + ' conta(s)</b>.<br><br>' +
            '<b>Juntar</b> mantém o que você já tem e adiciona as contas do arquivo (duplicados são atualizados).<br><br>' +
            '<b>Substituir</b> apaga tudo o que está no app e deixa somente o conteúdo do backup.',
          confirmar: 'Juntar', cancelar: 'Substituir tudo',
          icone: 'upload',
          onConfirmar: function () { App.fazerRestauracao(pacote, false); }
        });
        const btns = el('modal').querySelectorAll('[data-acao]');
        btns.forEach ? btns.forEach(function (b) {
          if (b.dataset.acao === 'fechar-modal') {
            b.dataset.acao = 'restaurar-substituir';
            b.textContent = 'Substituir tudo';
          }
        }) : null;
        window.__pacotePendente = pacote;
      } catch (e) {
        App.toast('Não consegui ler o arquivo. Verifique se é um backup do Lembrei (.json).', 'erro');
      }
    };
    inp.click();
  };
  App.fazerRestauracao = async function (pacote, substituir) {
    try {
      const n = await Store.importar(pacote, substituir);
      App.fecharModal();
      App.aplicarTema();
      App.render();
      App.toast(n + ' conta(s) restaurada(s) com sucesso.', 'ok');
    } catch (e) {
      App.fecharModal();
      App.toast('Falha ao restaurar: ' + e.message, 'erro');
    }
  };

  /* ------------------------------- ações gerais ---------------------------- */
  App.limparFiltros = function () {
    Object.assign(App.estado, { filtro: 'todas', categoria: 'todas', mes: '', busca: '', ordem: 'vencimento' });
    App.render();
  };

  App.ajustesAosDados = async function () {
    const cfg = Store.config();
    if (!cfg.onboardingVisto) { App.onboarding(0); return; }
    if (!cfg.exemplosCarregados && Store.contas().length === 0) {
      await App.criarExemplos();
      App.render();
    }
  };

  /* ------------------------------- onboarding ------------------------------ */
  const PASSOS = [
    {
      icone: 'check',
      titulo: 'Bem-vindo ao Lembrei',
      texto: 'Seu organizador de contas a pagar. Simples assim: cadastre a conta, escolha quando quer ser lembrado e não perca mais nenhum vencimento.',
      corpo: '<div class="aviso-li">' + U.icone('escudo') + '<span>Seus dados ficam <b>somente no seu aparelho</b>. Sem cadastro, sem senha, sem enviar nada para a internet.</span></div>' +
        '<div class="aviso-li">' + U.icone('check') + '<span>Funciona no <b>Android</b> e no <b>iPhone</b>, e pode ser instalado na tela inicial como um aplicativo.</span></div>' +
        '<div class="aviso-li">' + U.icone('lixeira') + '<span>Vamos começar mostrando <b>contas de EXEMPLO</b> (com selo roxo). Você apaga todas com um toque.</span></div>'
    },
    {
      icone: 'mais',
      titulo: 'Cadastre sua primeira conta',
      texto: 'Leva menos de um minuto e só três campos são obrigatórios.',
      corpo: '<ol>' +
        '<li>Toque no botão azul <b>“Adicionar conta”</b>.</li>' +
        '<li>Escreva o <b>nome</b> (ex.: Conta de luz), o <b>valor</b> (ex.: 120,50) e a <b>data de vencimento</b>.</li>' +
        '<li>Escolha a <b>categoria</b> e, se repetir todo mês, marque <b>Todo mês</b> em recorrência.</li>' +
        '<li>Toque em <b>Salvar conta</b>. Pronto!</li>' +
        '</ol>' +
        '<div class="caixa-info">A data de vencimento aparece no formato <b>DD/MM/AAAA</b> e os valores em <b>reais (R$)</b>, como você já usa no dia a dia.</div>'
    },
    {
      icone: 'sino',
      titulo: 'Configure os lembretes',
      texto: 'Diga quando quer ser avisado. Pode escolher vários avisos para a mesma conta.',
      corpo: '<ol>' +
        '<li>No cadastro, toque nos <b>chips laranja</b>: 7 dias antes, 3 dias antes, 1 dia antes, no dia e depois do vencimento.</li>' +
        '<li>Defina o <b>horário</b> do aviso (ex.: 09:00).</li>' +
        '<li>Deixe ligado o <b>“Repetir o aviso até eu marcar como paga”</b>: assim o Lembrei insiste todos os dias enquanto a conta estiver atrasada.</li>' +
        '<li>Toque em <b>Permitir</b> quando o app pedir autorização de notificação.</li>' +
        '</ol>' +
        '<div class="caixa-info"><b>Para avisos com o app fechado:</b> em <b>Relatórios ▸ Calendário (.ics)</b> o Lembrei gera um arquivo que cria alarmes reais no app de Agenda do celular. É grátis e funciona sempre.</div>'
    }
  ];
  App.onboarding = function (passo) {
    const o = el('onboarding');
    const p = PASSOS[passo] || PASSOS[0];
    o.innerHTML = '<div class="onb">' +
      '<div class="passos">' + PASSOS.map(function (_, i) { return '<i class="' + (i <= passo ? 'on' : '') + '"></i>'; }).join('') + '</div>' +
      '<div class="bola">' + U.icone(p.icone) + '</div>' +
      '<h2>' + p.titulo + '</h2>' +
      '<p>' + p.texto + '</p>' + p.corpo +
      '<div class="rodape">' +
        '<div class="linha-botoes">' +
          (passo > 0 ? '<button class="btn btn-contorno" data-acao="onb-voltar">Voltar</button>' : '<button class="btn btn-contorno" data-acao="onb-pular">Pular</button>') +
          '<button class="btn btn-primario btn-g" data-acao="onb-proximo" style="flex:2">' +
          (passo === PASSOS.length - 1 ? U.icone('check') + 'Começar a usar' : 'Continuar') + '</button>' +
        '</div>' +
      '</div></div>';
    o.hidden = false;
    o.dataset.passo = String(passo);
    document.body.style.overflow = 'hidden';
  };
  App.fecharOnboarding = async function () {
    el('onboarding').hidden = true;
    el('onboarding').innerHTML = '';
    document.body.style.overflow = '';
    await Store.salvarConfig({ onboardingVisto: true });
    await App.ajustesAosDados();
    App.render();
  };

  /* ================================ AÇÕES CLICÁVEIS ====================== */
  const ACOES = {
    'navegar': function (b) { App.navegar(b.dataset.rota); },
    'nova': function () { App.novaConta(); },
    'editar': function (b) { App.editarConta(b.dataset.id); },
    'detalhes': function (b) { App.detalhes(b.dataset.id); },
    'pagar': function (b) { App.pagarComConfirmacao(b.dataset.id); },
    'desfazer-pagamento': function (b) { App.desfazerPagamento(b.dataset.id); },
    'excluir': function (b) { App.excluirConta(b.dataset.id); },
    'fechar-modal': function () { App.fecharModal(); },
    'confirmar-modal': function () {
      const cfg = App.estado.modal || {};
      const cb = cfg.onConfirmar;
      if (cb) cb(); else App.fecharModal();
    },
    'restaurar-substituir': function () { App.fazerRestauracao(window.__pacotePendente, true); },
    'toggle-tema': function () { App.alternarTema(); },
    'filtro': function (b) { App.estado.filtro = b.dataset.filtro; App.renderSemFoco(); },
    'filtro-atalho': function (b) { App.estado.filtro = b.dataset.filtro; App.navegar('contas'); },
    'categoria': function (b) { App.estado.categoria = b.dataset.cat; App.renderSemFoco(); },
    'ordem': function (b) { App.estado.ordem = b.dataset.criterio; App.renderSemFoco(); },
    'periodo': function (b) { App.estado.periodo = b.dataset.periodo; if (b.dataset.periodo === 'tudo') App.estado.periodo = 'tudo'; App.renderSemFoco(); },
    'limpar-mes': function () { App.estado.mes = ''; App.renderSemFoco(); },
    'limpar-filtros': function () { App.limparFiltros(); },
    'selecionar-dia': function (b) {
      App.estado.diaSel = App.estado.diaSel === b.dataset.iso ? '' : b.dataset.iso;
      App.render();
    },
    'mes': function (b) {
      const delta = Number(b.dataset.delta);
      const [a, m] = (App.estado.mesCal || U.mesDe(U.hojeISO())).split('-').map(Number);
      let mes = m + delta, ano = a;
      if (mes < 1) { mes = 12; ano--; }
      if (mes > 12) { mes = 1; ano++; }
      App.estado.mesCal = ano + '-' + U.pad2(mes);
      App.render();
    },
    'cal-hoje': function () {
      App.estado.mesCal = U.mesDe(U.hojeISO());
      App.estado.diaSel = U.hojeISO();
      App.render();
    },
    'toggle-lembrete': function (b) {
      b.classList.toggle('marcado');
      const on = b.classList.contains('marcado');
      b.setAttribute('aria-pressed', String(on));
    },
    'toggle-lembrete-padrao': async function (b) {
      const d = Number(b.dataset.dias);
      let atuais = (Store.config().lembretes || []).slice();
      if (atuais.indexOf(d) >= 0) atuais = atuais.filter(function (x) { return x !== d; });
      else { atuais.push(d); atuais.sort(function (x, y) { return y - x; }); }
      await Store.salvarConfig({ lembretes: atuais });
      b.classList.toggle('marcado');
      b.setAttribute('aria-pressed', String(b.classList.contains('marcado')));
      App.toast('Lembretes padrão salvos.', 'ok');
    },
    'toggle-switch': function (b) {
      b.classList.toggle('ligado');
      const on = b.classList.contains('ligado');
      b.setAttribute('aria-pressed', String(on));
    },
    'toggle-repetir-padrao': async function (b) {
      const on = !b.classList.contains('ligado');
      b.classList.toggle('ligado', on);
      b.setAttribute('aria-pressed', String(on));
      await Store.salvarConfig({ repetirAtePagar: on });
      App.toast(on ? 'Vou repetir o aviso todos os dias até você marcar como paga.' : 'O aviso de atraso será enviado uma vez só.', 'ok');
    },
    'tema': async function (b) {
      await Store.salvarConfig({ tema: b.dataset.temaOp });
      App.aplicarTema();
      App.render();
    },
    'pedir-notificacao': function () { App.pedirNotificacao(); },
    'testar-notificacao': async function () {
      const perm = App.permissaoNotificacao();
      if (perm !== 'granted') {
        const nova = await App.pedirNotificacao();
        if (nova !== 'granted') { App.toast('Sem permissão, não consigo mostrar o aviso do sistema. Ele ficará na Central.', ''); await App.mostrarAviso('Teste do Lembrei', 'Assim aparecem seus lembretes de contas.'); App.render(); return; }
      }
      const ok = await App.mostrarAviso('Teste do Lembrei 🎉', 'Se você está vendo isto, seus lembretes de contas vão funcionar.');
      App.toast(ok ? 'Aviso enviado para o sistema do celular.' : 'Aviso registrado na Central (o sistema não mostrou).', ok ? 'ok' : '');
      App.render();
    },
    'ajuda-notificacao': function () {
      App.abrirModal(
        '<div class="modal-icone">' + U.icone('sino') + '</div>' +
        '<h3>Como liberar as notificações</h3>' +
        '<div class="caixa-info">' +
        '<b>Android (Chrome)</b><br>1. Toque no cadeado 🔒 ao lado do endereço.<br>2. Toque em <b>Permissões</b> ▸ <b>Notificações</b> ▸ <b>Permitir</b>.<br>3. Recarregue a página.<br><br>' +
        '<b>iPhone (Safari)</b><br>1. O app precisa estar <b>adicionado à Tela de Início</b> (iOS 16.4 ou superior).<br>2. Abra o Lembrei pelo ícone da tela inicial, não pelo Safari.<br>3. Toque em <b>Permitir</b> quando o app pedir.<br>4. Se não aparecer o pedido: Ajustes do iPhone ▸ <b>Notificações</b> ▸ encontre <b>Lembrei</b> ▸ ative <b>Permitir Notificações</b>.<br><br>' +
        '<b>Celular inteiro bloqueado para sites</b><br>Android: Configurações ▸ Apps ▸ Chrome ▸ Notificações ▸ ativar. iPhone: Ajustes ▸ Safari ▸ Avançado ▸ Recursos de sites (verifique bloqueios).' +
        '</div>' +
        '<div class="caixa-info" style="margin-top:12px">Enquanto a permissão não é concedida, <b>nada se perde</b>: todos os avisos aparecem na <b>Central de lembretes</b> e o arquivo <b>Calendário (.ics)</b> garante alarmes no app de Agenda.</div>' +
        '<div class="linha-botoes"><button class="btn btn-primario btn-largo" data-acao="pedir-notificacao">Tentar permitir agora</button></div>' +
        '<div class="linha-botoes" style="margin-top:8px"><button class="btn btn-contorno btn-largo" data-acao="fechar-modal">Fechar</button></div>',
        { foco: false }
      );
    },
    'ajuda-instalar': function () { App.abrirModal(M.ajuda('instalar') + '<div class="linha-botoes"><button class="btn btn-primario btn-largo" data-acao="fechar-modal">Fechar</button></div>', { foco: false }); },
    'ajuda-fechado': function () { App.abrirModal(M.ajuda('fechado') + '<div class="linha-botoes"><button class="btn btn-claro" data-acao="fechar-modal">Fechar</button><button class="btn btn-primario" data-acao="exportar-ics">Gerar calendário</button></div>', { foco: false }); },
    'ajuda-publicar': function () { App.abrirModal(M.ajuda('publicar') + '<div class="linha-botoes"><button class="btn btn-primario btn-largo" data-acao="fechar-modal">Fechar</button></div>', { foco: false }); },
    'ajuda-custos': function () { App.abrirModal(M.ajuda('custos') + '<div class="linha-botoes"><button class="btn btn-primario btn-largo" data-acao="fechar-modal">Fechar</button></div>', { foco: false }); },
    'ajuda-privacidade': function () { App.abrirModal(M.ajuda('privacidade') + '<div class="linha-botoes"><button class="btn btn-primario btn-largo" data-acao="fechar-modal">Fechar</button></div>', { foco: false }); },
    'ajuda-entrar': function () { App.fecharModal(); App.onboarding(0); },
    'remover-demos': function () {
      const n = Store.contas().filter(function (c) { return c.demo; }).length;
      if (!n) { App.toast('Não há contas de exemplo no app.'); return; }
      App.confirmar({
        titulo: 'Apagar as contas de exemplo?',
        texto: 'Serão removidas <b>' + n + ' conta(s) de exemplo</b>. Suas contas reais não são afetadas. ' +
          'Se preferir manter para se orientar, escolha Cancelar.',
        confirmar: 'Apagar exemplos', icone: 'lixeira',
        onConfirmar: async function () {
          const q = await Store.excluirExemplos();
          App.fecharModal(); App.render();
          App.toast(q + ' conta(s) de exemplo removida(s). Agora o app só tem dados seus.', 'ok');
        }
      });
    },
    'apagar-dados': function () {
      App.confirmar({
        perigo: true, icone: 'alerta',
        titulo: 'Excluir TODOS os dados?',
        texto: 'Isto apaga <b>permanentemente</b> ' + Store.contas().length + ' conta(s), seus lembretes e suas preferências deste aparelho. ' +
          'Não há como recuperar depois.<br><br>' +
          '<b>Sugestão:</b> faça um backup antes. Se já fez, pode continuar.',
        confirmar: 'Apagar tudo agora',
        onConfirmar: async function () {
          await Store.apagarTudo();
          App.fecharModal();
          App.render();
          App.toast('Todos os dados foram apagados deste aparelho.', 'ok');
        }
      });
    },
    'status-armazenamento': async function () {
      const persistente = await Store.pedirPersistencia();
      const est = await Store.estimativaUso();
      const kb = est && est.uso ? (est.uso / 1024).toFixed(1) + ' KB' : 'indisponível';
      const cotaMb = est && est.cota ? (est.cota / 1048576).toFixed(0) + ' MB disponíveis' : 'indisponível';
      App.abrirModal(
        '<div class="modal-icone ok">' + U.icone('escudo') + '</div>' +
        '<h3>Armazenamento</h3>' +
        '<div class="detalhe-lista"><span>Motor de dados</span><b>' + (Store.modo() === 'idb' ? 'IndexedDB (permanente)' : 'Armazenamento local') + '</b></div>' +
        '<div class="detalhe-lista"><span>Proteção contra limpeza automática</span><b>' + (persistente ? 'Ativada ✓' : 'Não concedida pelo navegador') + '</b></div>' +
        '<div class="detalhe-lista"><span>Espaço usado</span><b>' + kb + '</b></div>' +
        '<div class="detalhe-lista"><span>Cota do navegador</span><b>' + cotaMb + '</b></div>' +
        '<div class="caixa-info" style="margin-top:12px">Se a proteção aparecer como não concedida, seus dados <b>continuam salvos</b> normalmente ao fechar o app. ' +
        'O que pode apagar é uma limpeza manual do navegador ou a desinstalação. Por isso o backup existe: faça de vez em quando.</div>' +
        '<div class="linha-botoes"><button class="btn btn-primario btn-largo" data-acao="fechar-modal">Fechar</button></div>',
        { foco: false }
      );
    },
    'exportar-csv': function () { App.exportarCSV(); },
    'exportar-pdf': function () { App.exportarPDF(); },
    'exportar-ics': function () { App.exportarICS(); },
    'exportar-backup': function () { App.exportarBackup(); },
    'restaurar-backup': function () { App.restaurarBackup(); },
    'limpar-notificacoes': function () {
      App.confirmar({
        titulo: 'Limpar o histórico de avisos?',
        texto: 'As contas e os lembretes continuam iguais. Só a lista de avisos já enviados será apagada.',
        confirmar: 'Limpar',
        onConfirmar: async function () { await Store.limparNotificacoes(); App.fecharModal(); App.render(); App.toast('Histórico de avisos limpo.', 'ok'); }
      });
    },
    'onb-proximo': function () {
      const atual = Number(el('onboarding').dataset.passo || 0);
      if (atual >= PASSOS.length - 1) App.fecharOnboarding();
      else App.onboarding(atual + 1);
    },
    'onb-voltar': function () { App.onboarding(Math.max(0, Number(el('onboarding').dataset.passo || 0) - 1)); },
    'onb-pular': function () { App.fecharOnboarding(); },
    'add-lembrete': function (b) { App.addLembrete(Number(b.dataset.dias)); },
    'add-lembrete-custom': function () {
      const campo = el('novo-dias');
      const n = Number(campo && campo.value);
      if (!campo || campo.value === '' || !Number.isFinite(n) || n < 0 || n > 365) {
        App.toast('Digite um número de dias entre 0 e 365.', 'erro');
        if (campo) campo.focus();
        return;
      }
      App.addLembrete(n);
      campo.value = '';
      campo.focus();
    },
    'remover-lembrete': function (b) { App.removerLembrete(b.dataset.id); },
    'modo-repeticao': function (b) {
      document.querySelectorAll('#chips-repeticao .chip').forEach(function (x) {
        const on = x === b;
        x.classList.toggle('marcado', on);
        x.setAttribute('aria-pressed', String(on));
      });
      const modo = b.dataset.modo;
      const gi = el('grupo-intervalo'), gd = el('grupo-rep-detalhes');
      if (gi) gi.hidden = modo !== 'custom';
      if (gd) gd.hidden = modo === 'nenhuma';
    },
    'duplicar': function (b) { App.duplicarConta(b.dataset.id); },
    'confirmar-valor-pago': function (b) {
      const v = U.parseValor(el('v-pago').value);
      if (v === null || v <= 0) { App.toast('Informe um valor maior que zero.', 'erro'); return; }
      const c = Store.obterConta(b.dataset.id);
      if (!c) return;
      c.valor = v;
      Store.salvarConta(c).then(function () { App.pagarConta(b.dataset.id); });
    },
    'modo-repeticao-padrao': async function (b) {
      const atual = Object.assign({ modo: 'diaria', intervalo: null, hora: Store.config().hora || '09:00', fim: '' }, Store.config().repeticaoPadrao || {});
      atual.modo = b.dataset.modo;
      await Store.salvarConfig({ repeticaoPadrao: atual });
      App.render();
      App.toast('Padrão de repetição salvo.', 'ok');
    }
  };

  App.clicar = function (alvo) {
    const b = alvo.closest('[data-acao]');
    if (!b) return;
    const nome = b.dataset.acao;
    const fn = ACOES[nome];
    if (fn) { fn(b); }
  };

  /* --------------------------------- eventos ------------------------------- */
  function ligarEventos() {
    document.addEventListener('click', function (ev) {
      const b = ev.target.closest('[data-acao]');
      if (b) { ev.preventDefault(); App.clicar(b); return; }
      const modal = el('modal');
      if (!modal.hidden && ev.target === modal) App.fecharModal();
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') App.fecharModal();
      if (ev.key === 'Enter' && ev.target && ev.target.dataset && ev.target.dataset.acao === 'detalhes') {
        ev.preventDefault(); App.detalhes(ev.target.dataset.id);
      }
    });
    window.addEventListener('hashchange', function () {
      const h = (location.hash || '').replace('#', '');
      if (h === 'nova') { App.novaConta(); history.replaceState(null, '', '#' + App.estado.rota); return; }
      if (h && ROTAS[h] && h !== App.estado.rota) App.navegar(h);
    });
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) { App.verificarLembretes(true); App.render(); }
    });
    window.addEventListener('focus', function () { App.verificarLembretes(true); });
    window.addEventListener('online', function () { App.toast('Você está online novamente.'); });
    window.addEventListener('offline', function () { App.toast('Sem internet — o Lembrei continua funcionando normalmente.', ''); });
    if (raiz.matchMedia) {
      const mq = raiz.matchMedia('(prefers-color-scheme: dark)');
      const reacao = function () { if (Store.config().tema === 'auto') { App.aplicarTema(); App.render(); } };
      if (mq.addEventListener) mq.addEventListener('change', reacao);
      else if (mq.addListener) mq.addListener(reacao);
    }
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', function (ev) {
        if (ev.data && ev.data.tipo === 'ABRIR') {
          const rota = String(ev.data.rota || '').split('#')[1] || 'notificacoes';
          App.navegar(ROTAS[rota] ? rota : 'notificacoes');
        }
      });
    }
  }

  /* --------------------------------- início -------------------------------- */
  App.iniciar = async function () {
    const info = await Store.init();
    App.aplicarTema();
    ligarEventos();

    if (Store.config().onboardingVisto) {
      if (!Store.config().exemplosCarregados && Store.contas().length === 0) await App.criarExemplos();
      const h = (location.hash || '').replace('#', '');
      App.estado.rota = ROTAS[h] ? h : 'painel';
      App.render();
    } else {
      App.onboarding(0);
      App.render();
    }

    clearInterval(App.estado.timerLembrete);
    App.estado.timerLembrete = setInterval(function () {
      if (!document.hidden) App.verificarLembretes(true);
    }, 5 * 60 * 1000);
    setTimeout(function () { App.verificarLembretes(true); }, 900);

    if ('serviceWorker' in navigator) {
      try { await navigator.serviceWorker.register('sw.js'); } catch (e) { /* funciona sem SW */ }
    }
    if (info.problemas.length) console.warn('[Lembrei]', info.problemas.join(' '));
    window.__lembreiPronto = true;
  };

  raiz.App = App;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', App.iniciar);
  else App.iniciar();
})(typeof window !== 'undefined' ? window : globalThis);
