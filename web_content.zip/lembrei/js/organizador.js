/* ==========================================================================
   Lembrei — organizador.js  (Etapas 4, 5 e 9)
   Acrescenta o ORGANIZADOR PESSOAL sem mexer no que já funciona:

   - "Meu dia": compromissos, doses de medicamento, treinos, tarefas,
     contas vencendo e avisos importantes.
   - Tipos: medicamento, consulta, treino/jogo, estudo, aniversário, veículo.
   - "Preparar para o compromisso": avisos próprios (separar uniforme às 16h,
     preparar a mochila às 17h, sair de casa às 18h). Cada aviso tem hora
     própria, e o app SÓ cria os avisos depois que VOCÊ confirma.
   - Teste de notificação (agora e em 2 minutos).

   Nada aqui apaga dado: cada item novo é gravado na sua própria loja
   ('itens') do mesmo banco. As contas continuam exatamente como estavam.
   ========================================================================== */
(function (raiz) {
  'use strict';

  const U = raiz.U;
  const Store = raiz.Store;
  const V = raiz.Views;
  const App = raiz.App;

  const Org = {};
  raiz.Organizador = Org;

  /* ======================= tipos de compromisso ========================== */
  Org.TIPOS = [
    { id: 'medicamento',  nome: 'Medicamento',        icone: 'saude',      emoji: '💊', cor: 'verde' },
    { id: 'consulta',     nome: 'Consulta',           icone: 'saude',      emoji: '🏥', cor: 'azul' },
    { id: 'treino',       nome: 'Treino ou jogo',     icone: 'financiamentos', emoji: '🏐', cor: 'laranja' },
    { id: 'estudo',       nome: 'Estudo e tarefa',    icone: 'faculdade',  emoji: '📚', cor: 'azul' },
    { id: 'aniversario',  nome: 'Aniversário e data', icone: 'assinaturas', emoji: '🎉', cor: 'verde' },
    { id: 'veiculo',      nome: 'Veículo',            icone: 'financiamentos', emoji: '🚗', cor: 'laranja' }
  ];
  Org.tipo = function (id) {
    return Org.TIPOS.filter(function (t) { return t.id === id; })[0] || Org.TIPOS[3];
  };

  const DIAS_SEMANA = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

  /* ======================= dados ======================================== */
  Org.itens = function () { return (Store.itens ? Store.itens() : []).slice(); };
  Org.obter = function (id) { return Org.itens().filter(function (i) { return i.id === id; })[0] || null; };
  Org.salvar = async function (item) {
    item.atualizadoEm = new Date().toISOString();
    await Store.salvarItem(item);
    return item;
  };
  Org.excluir = async function (id) { await Store.excluirItem(id); };

  Org.novoItem = function (tipo) {
    return {
      id: U.uid('i'),
      tipo: tipo || 'consulta',
      titulo: '',
      data: '',
      hora: '',
      local: '',
      descricao: '',
      prioridade: 'normal',
      status: 'pendente',
      preparos: [],
      itensLevar: [],
      doses: [],
      diasSemana: [],
      inicio: '',
      fim: '',
      recorrencia: 'nenhuma',
      recorrenciaFim: '',
      deslocamento: 0,
      chegada: '',
      km: '',
      kmProxima: '',
      demo: false,
      criadoEm: new Date().toISOString()
    };
  };

  /* ======================= avisos (notificações) ========================= */

  function msgDoItem(item, aviso) {
    const t = Org.tipo(item.tipo);
    const nome = String(item.titulo || '').trim() || t.nome;
    if (aviso.classe === 'preparo') {
      return {
        titulo: 'PREPARAR — ' + nome.toUpperCase(),
        corpo: aviso.texto + '. ' + (item.data ? 'Compromisso em ' + U.fmtData(item.data) + (item.hora ? ' às ' + item.hora : '') + '.' : '')
      };
    }
    if (aviso.classe === 'dose') {
      return { titulo: 'HORA DO MEDICAMENTO', corpo: 'Está na hora de tomar ' + nome + (item.doseTexto ? ' — ' + item.doseTexto : '') + '.' };
    }
    if (aviso.classe === 'evento') {
      const extra = item.local ? ' Local: ' + item.local + '.' : '';
      return { titulo: 'COMPROMISSO HOJE — ' + nome.toUpperCase(), corpo: 'É hoje' + (item.hora ? ' às ' + item.hora : '') + '.' + extra };
    }
    return { titulo: 'LEMBRETE — ' + nome.toUpperCase(), corpo: item.descricao || nome };
  }

  /**
   * Calcula os avisos de UM item para uma data/hora.
   * Um "preparo" é um aviso com diasAntes + hora (ex.: sair de casa, 0 dia antes, 18:00).
   * Item concluído não avisa mais nada.
   */
  Org.avisosDoItem = function (item, hoje, agora) {
    const out = [];
    if (!item || item.demo || item.status === 'concluido') return out;
    hoje = hoje || U.hojeISO();
    agora = agora || U.agoraHHMM();

    // 1) preparos (valem para consulta, treino, estudo, aniversário, veículo)
    (item.preparos || []).forEach(function (p) {
      if (!p || !p.hora || !item.data) return;
      const dias = Math.max(0, Math.round(Number(p.diasAntes) || 0));
      const data = U.addDias(item.data, -dias);
      if (data !== hoje) return;
      if (agora < p.hora) return;
      const msg = msgDoItem(item, { classe: 'preparo', texto: p.texto || 'Prepare-se' });
      out.push({
        chave: item.id + '|P' + p.id + '|' + hoje, tipo: 'item', item: item,
        titulo: msg.titulo, corpo: msg.corpo, hora: p.hora
      });
    });

    // 2) medicamento: uma notificação por horário de dose, nos dias escolhidos
    if (item.tipo === 'medicamento') {
      const dentro = (!item.inicio || item.inicio <= hoje) && (!item.fim || hoje <= item.fim);
      const dow = U.deISO(hoje).getDay();
      const diaCerto = !item.diasSemana || !item.diasSemana.length || item.diasSemana.indexOf(dow) >= 0;
      if (dentro && diaCerto) {
        (item.doses || []).forEach(function (d) {
          const hora = typeof d === 'string' ? d : (d && d.hora);
          if (!U.horaValida(hora)) return;
          if (agora < hora) return;
          const msg = msgDoItem(item, { classe: 'dose' });
          out.push({ chave: item.id + '|D' + hora + '|' + hoje, tipo: 'item', item: item,
            titulo: msg.titulo, corpo: msg.corpo, hora: hora });
        });
      }
    }

    // 3) o próprio compromisso, no dia e na hora
    if (item.data === hoje && item.hora && U.horaValida(item.hora) && agora >= item.hora) {
      const msg = msgDoItem(item, { classe: 'evento' });
      out.push({ chave: item.id + '|EV|' + hoje, tipo: 'item', item: item,
        titulo: msg.titulo, corpo: msg.corpo, hora: item.hora });
    }
    return out;
  };

  /** Quantos avisos novos estão pendentes (usado no painel). */
  Org.contarPendentes = function () {
    const hoje = U.hojeISO();
    const agora = U.agoraHHMM();
    let n = 0;
    Org.itens().forEach(function (i) {
      Org.avisosDoItem(i, hoje, agora).forEach(function (av) {
        if (!Store.jaEnviado(av.chave)) n++;
      });
    });
    return n;
  };

  /** Tudo o que aparece em "Meu dia". */
  Org.doDia = function (dia) {
    const hoje = dia || U.hojeISO();
    const contas = Store.contas().filter(function (c) { return !c.pago && !c.demo; });
    const vencendoHoje = contas.filter(function (c) { return c.vencimento === hoje; });
    const proximas = contas.filter(function (c) {
      const d = U.diffDias(hoje, c.vencimento);
      return d > 0 && d <= 7;
    }).sort(function (a, b) { return String(a.vencimento).localeCompare(String(b.vencimento)); });

    const itens = Org.itens().filter(function (i) { return !i.demo; });
    const compromissos = [], doses = [], treinos = [], tarefas = [], avisos = [];
    const dow = U.deISO(hoje).getDay();

    itens.forEach(function (i) {
      if (i.tipo === 'medicamento') {
        const dentro = (!i.inicio || i.inicio <= hoje) && (!i.fim || hoje <= i.fim);
        const diaCerto = !i.diasSemana || !i.diasSemana.length || i.diasSemana.indexOf(dow) >= 0;
        if (dentro && diaCerto && (i.doses || []).length) doses.push(i);
        return;
      }
      const dias = i.data ? U.diffDias(hoje, i.data) : null;   // >0 = futuro
      if (i.tipo === 'treino') { if (i.status !== 'concluido' && dias !== null && dias >= -1 && dias <= 14) treinos.push(i); return; }
      if (i.tipo === 'estudo') { if (i.status !== 'concluido' && (dias === null || dias >= -30)) tarefas.push(i); return; }
      if (i.tipo === 'consulta') { if (i.status !== 'concluido' && dias !== null && dias >= -1 && dias <= 60) compromissos.push(i); return; }
      if (i.tipo === 'aniversario') { if (dias !== null && dias >= 0 && dias <= 30) compromissos.push(i); return; }
      if (i.tipo === 'veiculo') {
        const alerta = i.data && dias !== null && dias >= -15 && dias <= 60;
        if (alerta) avisos.push(i);
      }
    });

    const ord = function (a, b) {
      return String(a.data || '9999').localeCompare(String(b.data || '9999')) || String(a.hora || '').localeCompare(String(b.hora || ''));
    };
    compromissos.sort(ord); treinos.sort(ord); tarefas.sort(ord); avisos.sort(ord);

    return { hoje: hoje, vencendoHoje: vencendoHoje, proximas: proximas,
      compromissos: compromissos, doses: doses, treinos: treinos, tarefas: tarefas, avisos: avisos };
  };

  /* ======================= telas ======================================== */

  function cartaoItem(i) {
    const t = Org.tipo(i.tipo);
    const hoje = U.hojeISO();
    const dias = i.data ? U.diffDias(hoje, i.data) : null;
    let quando = 'sem data';
    if (i.data) {
      if (dias === 0) quando = 'hoje';
      else if (dias === 1) quando = 'amanhã';
      else if (dias > 1) quando = 'em ' + dias + ' dias';
      else quando = 'há ' + Math.abs(dias) + ' dia(s)';
      quando = U.fmtData(i.data) + (i.hora ? ' às ' + i.hora : '') + ' · ' + quando;
    }
    const doses = (i.doses || []).length ? ' · doses: ' + i.doses.join(', ') : '';
    const prep = (i.preparos || []).length;
    const feito = i.status === 'concluido';
    return '<div class="cartao item-card ' + (feito ? 'concluido' : '') + '" data-item="' + i.id + '">' +
      '<div class="ic-tipo ' + t.cor + '">' + t.emoji + '</div>' +
      '<div class="cresce">' +
        '<div class="it-topo"><b>' + U.esc(i.titulo || t.nome) + '</b>' +
          '<span class="selo ' + (feito ? 'paga' : 'avencer') + '">' + (feito ? 'concluído' : t.nome) + '</span></div>' +
        '<div class="mini suave">' + U.icone('relogio') + ' ' + quando + doses +
          (i.local ? ' · ' + U.esc(i.local) : '') + '</div>' +
        (prep ? '<div class="mini prep-ok">' + U.icone('sino') + ' ' + prep + ' aviso(s) de preparação configurado(s)</div>' : '') +
        (i.tipo === 'veiculo' && (i.km || i.kmProxima)
          ? '<div class="mini suave">' + U.icone('financiamentos') + ' KM atual: ' + (i.km || '—') + ' · próxima: ' + (i.kmProxima || '—') + '</div>' : '') +
      '</div>' +
      '<div class="it-acoes">' +
        (i.tipo === 'teste'
          ? '<button class="btn-icone2" data-acao="excluir-teste" title="Excluir o teste" aria-label="Excluir o teste">' + U.icone('lixeira') + '</button>'
          : '<button class="btn-icone2" data-acao="org-preparar" data-id="' + i.id + '" title="Preparar para o compromisso" aria-label="Preparar para o compromisso">' + U.icone('sino') + '</button>') +
        '<button class="btn-icone2" data-acao="org-editar" data-id="' + i.id + '" title="Editar" aria-label="Editar">' + U.icone('editar') + '</button>' +
        '<button class="btn-icone2" data-acao="org-concluir" data-id="' + i.id + '" title="' + (feito ? 'Reabrir' : 'Concluir') + '" aria-label="' + (feito ? 'Reabrir' : 'Concluir') + '">' + U.icone('check') + '</button>' +
      '</div></div>';
  }

  Org.cartaoItem = cartaoItem;

  function bloco(titulo, lista, vazio) {
    return '<div class="secao"><h2>' + titulo + '</h2><span class="mini suave">' + lista.length + '</span></div>' +
      (lista.length ? '<div class="itens">' + lista.map(cartaoItem).join('') + '</div>'
        : '<div class="mini suave vazio-linha">' + vazio + '</div>');
  }

  Org.meuDia = function () {
    const d = Org.doDia();
    const cfg = Store.config();
    const perm = App.permissaoNotificacao();
    const nome = (cfg.nome || '').trim();
    let h = '<div class="cartao meu-dia">' +
      '<div class="md-topo"><span class="md-ola">' + U.icone('painel') + ' Meu dia</span>' +
      '<span class="mini suave">' + U.fmtData(d.hoje) + '</span></div>' +
      '<div class="md-lista">' +
        linha('Compromissos de hoje', d.compromissos.filter(function (i) { return i.data === d.hoje; }).length, 'Consulta') +
        linha('Contas vencendo hoje', d.vencendoHoje.length, 'Contas') +
        linha('Medicamentos para hoje', d.doses.length, 'Medicamento') +
        linha('Treinos e jogos', d.treinos.length, 'Treino') +
        linha('Tarefas pendentes', d.tarefas.length, 'Estudo') +
      '</div>' +
      '<div class="linha-botoes" style="margin-top:14px">' +
        '<button class="btn btn-primario btn-g" data-acao="nova"><span class="g">+</span> Nova conta</button>' +
        '<button class="btn btn-claro btn-g" data-acao="org-novo">' + U.icone('mais') + 'Novo compromisso</button>' +
      '</div>' +
      (perm === 'granted' ? '' :
        '<div class="caixa-info" style="margin-top:12px">' + U.icone('sino') +
        ' <b>Ative os avisos.</b> Sem permissão de notificação o Lembrei só consegue mostrar os lembretes dentro do app. ' +
        'Toque em <b>Ajustes ▸ Lembretes e notificações ▸ Ativar avisos</b>.</div>') +
      '</div>';

    function linha(rotulo, qtd, tipoAtalho) {
      return '<button class="md-linha" data-acao="org-filtrar" data-tipo="' + tipoAtalho + '">' +
        '<span class="md-num' + (qtd ? ' on' : '') + '">' + qtd + '</span>' +
        '<span class="md-rot">' + rotulo + '</span>' +
        '<span class="md-seta">' + U.icone('calendario') + '</span></button>';
    }

    h += '<div style="margin-top:16px">' + bloco('Próximos compromissos', d.compromissos,
      'Nenhuma consulta ou data marcada. Toque em "Novo compromisso" para cadastrar.') + '</div>';
    h += bloco('Medicamentos de hoje', d.doses,
      'Nenhum medicamento cadastrado para hoje. Você cadastra os horários que o profissional de saúde indicou.');
    h += bloco('Treinos e jogos', d.treinos, 'Nenhum treino ou jogo nos próximos 14 dias.');

    if (d.vencendoHoje.length || d.proximas.length) {
      const lista = d.vencendoHoje.concat(d.proximas).slice(0, 6);
      h += '<div class="secao"><h2>Contas a vencer</h2><button class="ver" data-acao="navegar" data-rota="contas">Ver todas</button></div>' +
        '<div class="contas">' + lista.map(function (c) { return V.cartaoConta(c, d.hoje); }).join('') + '</div>';
    }

    h += bloco('Tarefas pendentes', d.tarefas, 'Nenhuma tarefa pendente.');
    if (d.avisos.length) h += bloco('Veículo — próximas manutenções', d.avisos, '');
    h += '<div class="mini suave" style="margin:18px 0 4px">' + U.icone('info') +
      ' Os dados ficam salvos neste aparelho. Nada é enviado para servidores.' +
      (Store.modo() === 'localStorage' ? ' (Modo de backup: localStorage.)' : '') + '</div>';
    return h;
  };

  Org.telaCompromissos = function () {
    const est = App.estado;
    const filtro = est.orgFiltro || 'todos';
    let lista = Org.itens().filter(function (i) { return !i.demo; });
    if (filtro === 'todos') lista = Org.itens();   // inclui o item de TESTE, que é excluível
    else lista = lista.filter(function (i) { return i.tipo === filtro; });
    if (filtro === 'concluidos') lista = Org.itens().filter(function (i) { return i.status === 'concluido'; });
    const busca = (est.busca || '').toLowerCase();
    if (busca) lista = lista.filter(function (i) { return String(i.titulo).toLowerCase().indexOf(busca) >= 0; });
    lista.sort(function (a, b) {
      if (a.status !== b.status) return a.status === 'concluido' ? 1 : -1;
      return String(a.data || '9999').localeCompare(String(b.data || '9999'));
    });

    let h = '<div class="cartao" style="margin-top:6px">' +
      '<div class="campo-busca">' + U.icone('busca') +
      '<input class="campo" id="campo-busca" type="search" placeholder="Buscar compromisso pelo nome" value="' + U.esc(est.busca || '') + '"></div></div>';

    h += '<div class="cartao cartao-teste">' +
      '<div class="rot-campo">' + U.icone('sino') + 'Testar as notificações deste aparelho</div>' +
      '<p class="mini suave" style="margin:0 0 10px">Teste honesto: o app só pode afirmar que avisa se você vir o aviso chegar. ' +
      'O primeiro teste avisa agora; o segundo avisa daqui a 2 minutos.</p>' +
      '<div class="linha-botoes">' +
        '<button class="btn btn-claro btn-g" data-acao="testar-agora">' + U.icone('sino') + 'Testar agora</button>' +
        '<button class="btn btn-contorno btn-g" data-acao="testar-2min">' + U.icone('relogio') + 'Testar em 2 min</button>' +
      '</div>' +
      '<div class="mini suave" style="margin-top:8px">Para confirmar o aviso de 2 minutos: toque no botão, saia do app ' +
      '(vai para a tela inicial do celular) e espere. Se chegar, os avisos estão funcionando. O teste fica marcado ' +
      'como <b>TESTE</b> e pode ser excluído no cartão dele.</div>' +
      (Store.config().testesFeitos ? '' : '') +
      '</div>';

    h += '<div class="chips" style="margin-top:12px">' +
      [['todos', 'Todos']].concat(Org.TIPOS.map(function (t) { return [t.id, t.emoji + ' ' + t.nome]; }))
        .concat([['concluidos', '✓ Concluídos']])
        .map(function (f) {
          return '<button class="chip ' + (filtro === f[0] ? 'marcado' : '') + '" data-acao="org-filtro" data-tipo="' + f[0] + '">' + f[1] + '</button>';
        }).join('') + '</div>';

    h += '<button class="btn btn-primario btn-largo btn-g" style="margin-top:14px" data-acao="org-novo">' +
      U.icone('mais') + 'Novo compromisso</button>';

    h += '<div class="secao"><h2>' + (filtro === 'todos' ? 'Todos os compromissos' : 'Filtrados') + '</h2><span class="mini suave">' + lista.length + '</span></div>';
    if (!lista.length) {
      h += '<div class="vazio"><div class="bolha">' + U.icone('calendario') + '</div><h3>Nada por aqui ainda</h3>' +
        '<p>Cadastre medicamentos, consultas, treinos, tarefas, aniversários e manutenção do veículo. ' +
        'Tudo pode ter vários avisos antes, cada um no horário que você escolher.</p>' +
        '<button class="btn btn-primario btn-largo" data-acao="org-novo">' + U.icone('mais') + 'Criar o primeiro</button></div>';
    } else {
      h += '<div class="itens">' + lista.map(cartaoItem).join('') + '</div>';
    }
    return h;
  };

  /* ======================= formulário =================================== */

  function opcoesRecorrencia(sel) {
    return [['nenhuma', 'Não repetir'], ['semanal', 'Toda semana'], ['mensal', 'Todo mês'],
      ['bimestral', 'A cada 2 meses'], ['trimestral', 'A cada 3 meses'], ['semestral', 'A cada 6 meses'],
      ['anual', 'Todo ano']].map(function (o) {
      return '<option value="' + o[0] + '"' + (sel === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
    }).join('');
  }

  Org.formulario = function (item) {
    const novo = !item;
    const i = item || Org.novoItem('consulta');
    const t = Org.tipo(i.tipo);
    const mostraData = i.tipo !== 'medicamento';

    let h = '<h3>' + (novo ? 'Novo compromisso' : 'Editar compromisso') + '</h3>' +
      '<p class="mini suave">Você escolhe os avisos. Nada é criado sem a sua confirmação.</p>' +
      '<form id="form-item" novalidate>';

    h += '<div class="form-grupo"><label for="i-tipo">Tipo *</label>' +
      '<select class="campo campo-select" id="i-tipo">' +
      Org.TIPOS.map(function (x) {
        return '<option value="' + x.id + '"' + (i.tipo === x.id ? ' selected' : '') + '>' + x.emoji + ' ' + x.nome + '</option>';
      }).join('') + '</select></div>';

    h += '<div class="form-grupo"><label for="i-titulo" id="rot-titulo">' +
      (i.tipo === 'medicamento' ? 'Nome do medicamento *' : i.tipo === 'aniversario' ? 'Nome da pessoa ou data *' : i.tipo === 'veiculo' ? 'Qual manutenção *' : 'Nome do compromisso *') +
      '</label><input class="campo" id="i-titulo" type="text" autocomplete="off" placeholder="' +
      (i.tipo === 'medicamento' ? 'Ex.: Losartana 50 mg' : i.tipo === 'treino' ? 'Ex.: Jogo de vôlei' : i.tipo === 'veiculo' ? 'Ex.: Troca de óleo' : 'Ex.: Consulta com cardiologista') +
      '" value="' + U.esc(i.titulo) + '"></div>';

    if (mostraData) {
      h += '<div class="grade-campos">' +
        '<div class="form-grupo"><label for="i-data">Data</label>' +
        '<input class="campo" id="i-data" type="date" value="' + U.esc(i.data || '') + '"></div>' +
        '<div class="form-grupo"><label for="i-hora">Horário</label>' +
        '<input class="campo" id="i-hora" type="time" value="' + U.esc(i.hora || '') + '"></div></div>';
    }

    h += '<div class="form-grupo"><label for="i-local">Local <span class="dica">(opcional)</span></label>' +
      '<input class="campo" id="i-local" type="text" placeholder="Ex.: Ginásio do bairro" value="' + U.esc(i.local || '') + '"></div>';

    /* ---- campos por tipo ---- */
    h += '<div id="campos-tipo">';

    if (i.tipo === 'medicamento') {
      h += '<div class="form-grupo"><label for="i-doses">Horários das doses *</label>' +
        '<input class="campo" id="i-doses" type="text" placeholder="08:00, 14:00, 20:00" value="' + U.esc((i.doses || []).join(', ')) + '">' +
        '<span class="dica">Separe por vírgula. Use exatamente os horários que o profissional de saúde indicou.</span></div>' +
        '<div class="grade-campos">' +
        '<div class="form-grupo"><label for="i-inicio">Início do uso</label><input class="campo" id="i-inicio" type="date" value="' + U.esc(i.inicio || '') + '"></div>' +
        '<div class="form-grupo"><label for="i-fim">Fim do uso <span class="dica">(vazio = contínuo)</span></label><input class="campo" id="i-fim" type="date" value="' + U.esc(i.fim || '') + '"></div></div>' +
        '<div class="form-grupo"><label>Dias da semana <span class="dica">(nenhum = todos os dias)</span></label>' +
        '<div class="chips">' + DIAS_SEMANA.map(function (d, k) {
          return '<button type="button" class="chip ' + ((i.diasSemana || []).indexOf(k) >= 0 ? 'marcado' : '') + '" data-acao="org-dia-semana" data-dia="' + k + '">' + d.slice(0, 3) + '</button>';
        }).join('') + '</div></div>';
    }

    if (i.tipo === 'consulta' || i.tipo === 'treino') {
      h += '<div class="grade-campos">' +
        '<div class="form-grupo"><label for="i-desloc">Minutos de deslocamento</label>' +
        '<input class="campo" id="i-desloc" type="number" inputmode="numeric" min="0" max="600" value="' + (i.deslocamento || 0) + '"></div>' +
        '<div class="form-grupo"><label for="i-chegada">Quero chegar às</label>' +
        '<input class="campo" id="i-chegada" type="time" value="' + U.esc(i.chegada || '') + '"></div></div>' +
        '<div class="mini suave" style="margin:-4px 0 10px">Com os dois campos preenchidos, o botão “Sugerir horários” abaixo calcula as horas de saída — ' +
        'mas só cria os avisos depois que você revisar e tocar em Salvar.</div>';
    }

    const presets = i.tipo === 'treino' ? ['Separar uniforme', 'Preparar a mochila', 'Sair de casa', 'Levar água', 'Levar joelheira']
      : i.tipo === 'consulta' ? ['Separar documentos', 'Separar carteirinha', 'Tomar remédio', 'Sair de casa']
      : i.tipo === 'estudo' ? ['Começar a estudar', 'Revisar anotações']
      : i.tipo === 'aniversario' ? ['Comprar presente', 'Enviar mensagem de parabéns']
      : i.tipo === 'veiculo' ? ['Agendar a manutenção', 'Conferir óleo e água']
      : ['Primeira dose do dia'];

    h += '<div class="bloco-lembretes"><div class="rot-campo">' + U.icone('sino') + 'Avisos deste compromisso</div>' +
      '<p class="dica" style="margin:2px 0 10px">É aqui que você monta o “Preparar para o compromisso”: ' +
      'quantos dias antes e em que hora cada aviso deve chegar.</p>' +
      '<div class="chips" id="org-presets">' + presets.map(function (p) {
        return '<button type="button" class="chip" data-acao="org-add-preset" data-texto="' + U.esc(p) + '">+ ' + U.esc(p) + '</button>';
      }).join('') + '</div>' +
      '<div class="linha-personalizado">' +
        '<input class="campo" id="novo-preparo-texto" type="text" placeholder="Ex.: Sair de casa">' +
        '<input class="campo campo-dias" id="novo-preparo-dias" type="number" inputmode="numeric" min="0" max="365" value="0" aria-label="Dias antes">' +
        '<input class="campo campo-hora" id="novo-preparo-hora" type="time" value="' + (i.hora || Store.config().hora || '09:00') + '" aria-label="Horário do aviso">' +
        '<button type="button" class="btn btn-claro" data-acao="org-add-preparo">' + U.icone('mais') + '</button>' +
      '</div>' +
      '<button type="button" class="btn btn-contorno btn-largo" data-acao="org-sugerir" style="margin-bottom:12px">' + U.icone('relogio') + 'Sugerir horários de preparação</button>' +
      '<div class="lista-lembretes" id="lista-preparos">' + preparosHTML(i) + '</div>' +
      '</div>';

    if (i.tipo === 'treino') {
      h += '<div class="bloco-lembretes"><div class="rot-campo">' + U.icone('check') + 'O que levar</div>' +
        '<p class="dica" style="margin:2px 0 10px">Marque cada item ao separar. A lista fica junto do lembrete.</p>' +
        '<div class="chips">' + ['Uniforme', 'Tênis', 'Joelheira', 'Água', 'Documento'].map(function (x) {
          return '<button type="button" class="chip" data-acao="org-add-levar" data-texto="' + U.esc(x) + '">+ ' + U.esc(x) + '</button>';
        }).join('') + '</div><div id="lista-levar">' + levarHTML(i) + '</div></div>';
    }

    if (i.tipo === 'estudo') {
      h += '<div class="form-grupo"><label for="i-prio">Prioridade</label><select class="campo campo-select" id="i-prio">' +
        ['baixa', 'normal', 'alta'].map(function (p) {
          return '<option value="' + p + '"' + (i.prioridade === p ? ' selected' : '') + '>' + p.charAt(0).toUpperCase() + p.slice(1) + '</option>';
        }).join('') + '</select></div>';
    }

    if (i.tipo === 'veiculo') {
      h += '<div class="grade-campos">' +
        '<div class="form-grupo"><label for="i-km">KM atual</label><input class="campo" id="i-km" type="number" inputmode="numeric" min="0" value="' + U.esc(i.km || '') + '"></div>' +
        '<div class="form-grupo"><label for="i-kmprox">KM da próxima</label><input class="campo" id="i-kmprox" type="number" inputmode="numeric" min="0" value="' + U.esc(i.kmProxima || '') + '"></div>' +
        '</div>' +
        '<div class="caixa-info" style="margin-bottom:12px">' + U.icone('info') +
        ' O Lembrei <b>não</b> lê o hodômetro do carro. Você atualiza o KM à mão e o app usa a data para avisar. ' +
        'Quando o KM chegar no valor previsto, atualize aqui.</div>';
    }

    if (i.tipo !== 'medicamento') {
      h += '<div class="form-grupo"><label for="i-rec">Repetir este compromisso</label>' +
        '<select class="campo campo-select" id="i-rec">' + opcoesRecorrencia(i.recorrencia) + '</select></div>' +
        '<div class="form-grupo"' + (i.recorrencia === 'nenhuma' ? ' hidden' : '') + ' id="grupo-rec-item">' +
        '<label for="i-rec-fim">Repetir até <span class="dica">(opcional)</span></label>' +
        '<input class="campo" id="i-rec-fim" type="date" value="' + U.esc(i.recorrenciaFim || '') + '"></div>';
    }

    h += '<div class="form-grupo"><label for="i-desc">Observações <span class="dica">(opcional)</span></label>' +
      '<textarea class="campo" id="i-desc" rows="2" placeholder="Anotações, sala, número do vendedor...">' + U.esc(i.descricao || '') + '</textarea></div>';

    h += '</div>'; // campos-tipo

    h += '<div class="linha-botoes" style="margin-top:18px">' +
      (novo ? '' : '<button type="button" class="btn btn-perigo" data-acao="org-excluir" data-id="' + i.id + '">' + U.icone('lixeira') + 'Excluir</button>') +
      '<button type="submit" class="btn btn-primario btn-g" style="flex:2">' + U.icone('check') + (novo ? 'Salvar compromisso' : 'Salvar alterações') + '</button>' +
      '</div><input type="hidden" id="i-id" value="' + (item ? item.id : '') + '"><input type="hidden" id="i-json" value="">' +
      '</form>';
    return h;
  };

  function preparosHTML(i) {
    const lista = i.preparos || [];
    if (!lista.length) {
      return '<div class="li-vazio">' + U.icone('info') +
        'Nenhum aviso de preparação. Sem aviso, este compromisso não avisa nada. Use os atalhos acima ou escreva o seu.</div>';
    }
    return lista.map(function (p) {
      const dias = Math.max(0, Math.round(Number(p.diasAntes) || 0));
      const quando = dias === 0 ? 'no dia' : dias + ' dia' + (dias > 1 ? 's' : '') + ' antes';
      const dataTxt = i.data ? U.fmtData(U.addDias(i.data, -dias)) : '(defina a data)';
      return '<div class="lembrete-item" data-preparo-id="' + p.id + '">' +
        '<div class="li-topo">' +
          '<input class="campo-preparo" type="text" value="' + U.esc(p.texto || '') + '" data-campo="texto" aria-label="O que fazer">' +
          '<input type="number" min="0" max="365" inputmode="numeric" value="' + dias + '" data-campo="diasAntes" aria-label="Dias antes">' +
          '<input type="time" value="' + U.esc(p.hora || '09:00') + '" data-campo="hora" aria-label="Horário">' +
          '<button type="button" class="bloco-acao" data-acao="org-remover-preparo" data-id="' + p.id + '" aria-label="Excluir aviso">' + U.icone('lixeira') + '</button>' +
        '</div>' +
        '<div class="li-previa">' + U.icone('sino') + ' Avisa ' + quando + ' — em <b>' + dataTxt + ' às ' + U.esc(p.hora || '09:00') + '</b></div>' +
      '</div>';
    }).join('');
  }

  function levarHTML(i) {
    const lista = i.itensLevar || [];
    if (!lista.length) return '<div class="mini suave" style="margin-top:8px">Nada na lista ainda.</div>';
    return '<div class="chips" style="margin-top:10px">' + lista.map(function (x) {
      return '<button type="button" class="chip ' + (x.ok ? 'marcado' : '') + '" data-acao="org-toggle-levar" data-id="' + x.id + '">' +
        (x.ok ? '✓ ' : '') + U.esc(x.texto) + '</button>';
    }).join('') + '</div>';
  }

  /* ======================= ações ======================================== */

  Org.abrir = function (id) {
    const item = id ? Org.obter(id) : null;
    App.estado.itemEdicao = id || null;
    App.estado.itemRascunho = item ? JSON.parse(JSON.stringify(item)) : Org.novoItem('consulta');
    App.abrirModal(Org.formulario(App.estado.itemRascunho));
    ligarFormulario();
  };

  function rascunho() { return App.estado.itemRascunho; }

  /**
   * Copia o que está digitado no formulário para o rascunho.
   * Sem isso, a prévia dos avisos mostrava "(defina a data)" porque a data
   * escolhida ainda não tinha sido lida do campo.
   */
  function sincronizarCampos() {
    const r = rascunho();
    if (!r) return r;
    const val = function (id) { const e = raiz.document.getElementById(id); return e ? e.value : null; };
    const d = val('i-data');      if (d !== null) r.data = d || '';
    const h = val('i-hora');      if (h !== null) r.hora = h || '';
    const t = val('i-titulo');    if (t !== null) r.titulo = t.trim();
    const l = val('i-local');     if (l !== null) r.local = l.trim();
    const ds = val('i-desloc');   if (ds !== null) r.deslocamento = Math.round(Number(ds) || 0);
    const cg = val('i-chegada');  if (cg !== null) r.chegada = cg || '';
    return r;
  }
  Org.sincronizarCampos = sincronizarCampos;

  function redesenharListas() {
    sincronizarCampos();
    const alvo = raiz.document.getElementById('lista-preparos');
    if (alvo) alvo.innerHTML = preparosHTML(rascunho());
    const lev = raiz.document.getElementById('lista-levar');
    if (lev) lev.innerHTML = levarHTML(rascunho());
    const chips = raiz.document.querySelectorAll('[data-acao="org-add-preset"]');
    chips.forEach(function (b) {
      const ativo = (rascunho().preparos || []).some(function (p) { return p.texto === b.dataset.texto; });
      b.classList.toggle('marcado', ativo);
    });
  }
  Org.redesenharListas = redesenharListas;

  function ligarFormulario() {
    const form = raiz.document.getElementById('form-item');
    if (!form) return;
    form.addEventListener('submit', salvar);

    const tipo = raiz.document.getElementById('i-tipo');
    if (tipo) tipo.addEventListener('change', function () {
      const r = rascunho();
      r.tipo = tipo.value;
      App.abrirModal(Org.formulario(r));
      ligarFormulario();
    });

    ['i-data', 'i-hora'].forEach(function (id) {
      const campo = raiz.document.getElementById(id);
      if (campo) campo.addEventListener('change', function () { redesenharListas(); });
    });

    const rec = raiz.document.getElementById('i-rec');
    if (rec) rec.addEventListener('change', function () {
      const g = raiz.document.getElementById('grupo-rec-item');
      if (g) g.hidden = rec.value === 'nenhuma';
    });

    const lista = raiz.document.getElementById('lista-preparos');
    if (lista) lista.addEventListener('change', function (ev) {
      const box = ev.target.closest('[data-preparo-id]');
      if (!box) return;
      const p = (rascunho().preparos || []).filter(function (x) { return x.id === box.dataset.preparoId; })[0];
      if (!p) return;
      const campo = ev.target.dataset.campo;
      if (campo === 'texto') p.texto = ev.target.value.trim() || 'Prepare-se';
      else if (campo === 'hora') p.hora = U.horaValida(ev.target.value) ? ev.target.value : p.hora;
      else if (campo === 'diasAntes') p.diasAntes = Math.max(0, Math.min(365, Math.round(Number(ev.target.value) || 0)));
      redesenharListas();
    });
  }
  Org.ligarFormulario = ligarFormulario;

  Org.addPreparo = function (texto, hora, diasAntes) {
    const r = sincronizarCampos() || rascunho();
    r.preparos = r.preparos || [];
    const t = String(texto || '').trim();
    if (!t) { App.toast('Escreva o que precisa ser feito neste aviso.', 'erro'); return; }
    const h = U.horaValida(hora) ? hora : (r.hora || Store.config().hora || '09:00');
    const jaTem = r.preparos.filter(function (p) { return p.texto.toLowerCase() === t.toLowerCase() && p.hora === h; })[0];
    if (jaTem) { App.toast('Esse aviso já existe com esse horário.', 'erro'); return; }
    r.preparos.push({ id: U.uid('P'), texto: t, hora: h, diasAntes: Math.max(0, Math.round(Number(diasAntes) || 0)), feito: false });
    r.preparos.sort(function (a, b) { return (b.diasAntes - a.diasAntes) || a.hora.localeCompare(b.hora); });
    redesenharListas();
  };

  /** Sugere horários a partir da chegada e do deslocamento — só sugere, não salva. */
  Org.sugerir = function () {
    const r = sincronizarCampos() || rascunho();
    const chegada = raiz.document.getElementById('i-chegada').value;
    const min = Math.round(Number(raiz.document.getElementById('i-desloc').value) || 0);
    if (!chegada) { App.toast('Preencha "Quero chegar às" para o app calcular.', 'erro'); return; }
    if (!min) { App.toast('Informe os minutos de deslocamento.', 'erro'); return; }
    r.chegada = chegada;
    r.deslocamento = min;
    const [hh, mm] = chegada.split(':').map(Number);
    const total = hh * 60 + mm - min;
    const sai = String(Math.floor(((total % 1440) + 1440) % 1440 / 60)).padStart(2, '0') + ':' +
      String(((total % 60) + 60) % 60).padStart(2, '0');
    const antes = (total - 60 + 1440) % 1440;
    const mochila = String(Math.floor(antes / 60)).padStart(2, '0') + ':' + String(antes % 60).padStart(2, '0');
    const sugestoes = r.tipo === 'treino'
      ? [['Separar uniforme', mochila], ['Preparar a mochila', mochila], ['Sair de casa', sai]]
      : [['Separar documentos', mochila], ['Sair de casa', sai]];
    sugestoes.forEach(function (s) { Org.addPreparo(s[0], s[1], 0); });
    App.toast('Sugeri ' + sugestoes.length + ' avisos. Edite as horas e toque em Salvar para confirmar.', 'ok');
  };

  async function salvar(ev) {
    ev.preventDefault();
    const r = rascunho();
    const titulo = raiz.document.getElementById('i-titulo').value.trim();
    if (titulo.length < 2) { App.toast('Dê um nome para o compromisso.', 'erro'); return; }

    r.titulo = titulo;
    r.descricao = raiz.document.getElementById('i-desc').value.trim();
    const l = raiz.document.getElementById('i-local'); if (l) r.local = l.value.trim();
    const dt = raiz.document.getElementById('i-data'); if (dt) r.data = dt.value || '';
    const hr = raiz.document.getElementById('i-hora'); if (hr) r.hora = hr.value || '';
    const rc = raiz.document.getElementById('i-rec'); if (rc) r.recorrencia = rc.value;
    const rf = raiz.document.getElementById('i-rec-fim'); if (rf) r.recorrenciaFim = rf.value || '';
    const pr = raiz.document.getElementById('i-prio'); if (pr) r.prioridade = pr.value;
    const ds = raiz.document.getElementById('i-doses'); if (ds) {
      r.doses = ds.value.split(',').map(function (x) { return x.trim(); }).filter(function (x) { return U.horaValida(x); });
      if (!r.doses.length) { App.toast('Informe ao menos um horário de dose, no formato 08:00.', 'erro'); return; }
    }
    const ii = raiz.document.getElementById('i-inicio'); if (ii) r.inicio = ii.value || '';
    const fi = raiz.document.getElementById('i-fim'); if (fi) r.fim = fi.value || '';
    const km = raiz.document.getElementById('i-km'); if (km) r.km = km.value;
    const kmp = raiz.document.getElementById('i-kmprox'); if (kmp) r.kmProxima = kmp.value;

    if (r.tipo !== 'medicamento' && !r.data) {
      App.toast('Escolha a data do compromisso.', 'erro');
      return;
    }
    if (r.tipo === 'medicamento' && !r.doses.length) {
      App.toast('Informe os horários das doses.', 'erro');
      return;
    }

    r.demo = false;
    await Org.salvar(r);
    App.fecharModal();
    App.render();
    const n = (r.preparos || []).length + (r.tipo === 'medicamento' ? r.doses.length : 0) + (r.data ? 1 : 0);
    App.toast('Compromisso salvo! ' + n + ' aviso(s) programado(s).', 'ok');
    setTimeout(function () { App.verificarLembretes(true); }, 300);
  }
  Org.salvarFormulario = salvar;

  Org.excluir = function (id) {
    const i = Org.obter(id);
    if (!i) return;
    App.confirmar({
      perigo: true, icone: 'lixeira', titulo: 'Excluir este compromisso?',
      texto: '<b>' + U.esc(i.titulo) + '</b>' + (i.data ? ', ' + U.fmtData(i.data) : '') + '.<br><br>' +
        'Os avisos dele param de tocar na hora. Esta ação não pode ser desfeita.',
      confirmar: 'Excluir', onConfirmar: async function () {
        await Store.excluirItem(id);
        App.fecharModal(); App.render(); App.toast('Compromisso excluído.', 'ok');
      }
    });
  };

  Org.concluir = function (id) {
    const i = Org.obter(id);
    if (!i) return;
    const virando = i.status !== 'concluido';
    Org.salvar(Object.assign(i, { status: virando ? 'concluido' : 'pendente' })).then(function () {
      App.render();
      App.toast(virando ? 'Concluído! Os avisos deste compromisso foram interrompidos.' : 'Compromisso reaberto.', 'ok');
    });
  };

  /* ======================= teste de notificação ========================= */

  function bip(seq) {
    try {
      const Ctx = raiz.AudioContext || raiz.webkitAudioContext;
      if (!Ctx) return false;
      const ctx = new Ctx();
      (seq || [880, 1180]).forEach(function (f, k) {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        g.gain.value = 0.0001;
        o.connect(g); g.connect(ctx.destination);
        const t0 = ctx.currentTime + k * 0.35;
        g.gain.exponentialRampToValueAtTime(0.25, t0 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.3);
        o.start(t0); o.stop(t0 + 0.32);
      });
      return true;
    } catch (e) { return false; }
  }
  Org.bip = bip;

  Org.agoraHHMMmais = function (min) {
    const d = new Date();
    d.setMinutes(d.getMinutes() + (min || 0));
    return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  };

  Org.testarAgora = async function () {
    if (App.permissaoNotificacao() !== 'granted') {
      const p = await App.pedirNotificacao();
      if (p !== 'granted') { App.toast('Permissão não concedida — o aviso fica só na Central.', 'erro'); return; }
    }
    const tocou = bip([880, 1180, 1480]);
    const ok = await App.mostrarAviso('TESTE DO LEMBREI', 'Se você está vendo isto, os avisos estão funcionando neste aparelho.', 'lembrei-teste-' + Date.now());
    App.render();
    let msgTeste = 'Teste enviado! Olhe a barra de notificações.';
    if (tocou) msgTeste += ' (com som)';
    App.toast(msgTeste, ok ? 'ok' : 'erro');
    return ok;
  };

  Org.testar2Min = async function () {
    if (App.permissaoNotificacao() !== 'granted') {
      const p = await App.pedirNotificacao();
      if (p !== 'granted') { App.toast('Conceda a permissão para o teste fazer sentido.', 'erro'); return; }
    }
    const hora = Org.agoraHHMMmais(2);
    const existente = Org.itens().filter(function (i) { return i.tipo === 'teste'; })[0];
    const item = existente || Org.novoItem('consulta');
    item.tipo = 'teste';
    item.titulo = 'TESTE DE NOTIFICAÇÃO (pode excluir)';
    item.data = U.hojeISO();
    item.hora = hora;
    item.descricao = 'Teste criado por você para conferir o aviso de 2 minutos.';
    item.preparos = [{ id: 'teste' + hora.replace(':', ''), texto: 'Teste de notificação', hora: hora, diasAntes: 0, feito: false }];
    item.status = 'pendente';
    await Org.salvar(item);
    App.fecharModal(); App.render();
    App.toast('Teste marcado para às ' + hora + '. Deixe o app aberto ou em segundo plano.', 'ok');
  };

  Org.excluirTeste = function () {
    const t = Org.itens().filter(function (i) { return i.tipo === 'teste'; })[0];
    if (!t) { App.toast('Não há teste marcado.', 'erro'); return; }
    Store.excluirItem(t.id).then(function () { App.render(); App.toast('Teste removido.', 'ok'); });
  };

  /* ======================= integração com o app ========================== */

  App.estado.extRota = null;
  App.estado.orgFiltro = 'todos';

  // 1) avisos dos itens entram na mesma varredura das contas
  const verificarOrig = App.verificarLembretes;
  App.verificarLembretes = async function (silencioso) {
    const nContas = await verificarOrig(silencioso);
    const hoje = U.hojeISO();
    const agora = U.agoraHHMM();
    let nItens = 0;
    for (const item of Org.itens()) {
      const avisos = Org.avisosDoItem(item, hoje, agora);
      for (const av of avisos) {
        if (Store.jaEnviado(av.chave)) continue;
        await App.mostrarAviso(av.titulo, av.corpo, 'lembrei-' + item.id + '-' + av.chave);
        await Store.marcarEnviado(av.chave);
        nItens++;
      }
    }
    if (nItens && !silencioso) App.toast(nItens + ' aviso(s) de compromisso enviado(s).', 'ok');
    return nContas + nItens;
  };

  // 2) abas e rotas novas
  V.abas = function (rota) {
    const itens = [
      ['painel', 'painel', 'Meu dia'],
      ['compromissos', 'calendario', 'Compromissos'],
      ['contas', 'historico', 'Contas'],
      ['historico', 'grafico', 'Relatórios'],
      ['config', 'config', 'Ajustes']
    ];
    const atual = rota === 'calendario' || rota === 'notificacoes' ? 'compromissos' : rota;
    return itens.map(function (i) {
      return '<button class="ab ' + (atual === i[0] ? 'on' : '') + '" data-acao="navegar" data-rota="' + i[0] + '"' +
        (atual === i[0] ? ' aria-current="page"' : '') + '>' + U.icone(i[1]) + '<span>' + i[2] + '</span></button>';
    }).join('');
  };

  const painelOrig = V.painel;
  V.painel = function () {
    return '<div class="secao" style="margin-top:6px"><h2>Meu dia</h2>' +
      '<span class="mini suave">' + U.fmtData(U.hojeISO()) + '</span></div>' +
      Org.meuDia() +
      '<div class="secao" style="margin-top:26px"><h2>Minhas contas</h2><span class="mini suave">' +
      Store.contas().length + ' no total</span></div>' + painelOrig();
  };

  const renderOrig = App.render;
  const navOrig = App.navegar;
  const EXT = { compromissos: 1 };

  function pintarExt(rota) {
    App.estado.extRota = rota;
    const guarda = App.estado.rota;
    App.estado.rota = 'painel';
    renderOrig();
    App.estado.rota = guarda;
    const t = raiz.document.getElementById('tela');
    if (t) t.innerHTML = '<div class="secao" style="margin-top:6px"><h2>Compromissos</h2>' +
      '<span class="mini suave">' + Org.itens().length + ' cadastrado(s)</span></div>' + Org.telaCompromissos();
    const a = raiz.document.getElementById('abas');
    if (a) a.innerHTML = V.abas(rota);
    const busca = raiz.document.getElementById('campo-busca');
    if (busca) {
      busca.addEventListener('input', App.debounce(function (ev) {
        App.estado.busca = ev.target.value; pintarExt(rota);
        const b2 = raiz.document.getElementById('campo-busca');
        if (b2) { b2.focus(); try { b2.setSelectionRange(b2.value.length, b2.value.length); } catch (e) {} }
      }, 260));
    }
  }

  App.navegar = function (rota, extra) {
    if (EXT[rota]) {
      App.estado.rota = rota;
      if (extra) Object.assign(App.estado, extra);
      raiz.location.hash = rota;
      pintarExt(rota);
      raiz.scrollTo({ top: 0, behavior: 'auto' });
      return;
    }
    App.estado.extRota = null;
    return navOrig(rota, extra);
  };

  App.render = function () {
    if (EXT[App.estado.rota]) { pintarExt(App.estado.rota); return; }
    return renderOrig();
  };

  // 3) ações dos botões novos
  const acoesOrig = App.acoes || null;
  Org.acoes = {
    'org-novo': function () { Org.abrir(null); },
    'org-editar': function (b) { Org.abrir(b.dataset.id); },
    'org-excluir': function (b) { Org.excluir(b.dataset.id); },
    'org-concluir': function (b) { Org.concluir(b.dataset.id); },
    'org-preparar': function (b) { Org.abrir(b.dataset.id); },
    'org-filtro': function (b) { App.estado.orgFiltro = b.dataset.tipo; App.estado.rota = 'compromissos'; pintarExt('compromissos'); },
    'org-filtrar': function (b) {
      const mapa = { 'Consulta': 'consulta', 'Contas': 'todos', 'Medicamento': 'medicamento', 'Treino': 'treino', 'Estudo': 'estudo' };
      App.estado.orgFiltro = mapa[b.dataset.tipo] || 'todos';
      App.navegar('compromissos');
    },
    'org-add-preset': function (b) {
      const h = raiz.document.getElementById('novo-preparo-hora');
      Org.addPreparo(b.dataset.texto, h ? h.value : (rascunho().hora || '09:00'), 0);
    },
    'org-add-preparo': function () {
      const t = raiz.document.getElementById('novo-preparo-texto');
      const d = raiz.document.getElementById('novo-preparo-dias');
      const h = raiz.document.getElementById('novo-preparo-hora');
      Org.addPreparo(t ? t.value : '', h ? h.value : '09:00', d ? d.value : 0);
      if (t) t.value = '';
    },
    'org-remover-preparo': function (b) {
      const r = rascunho();
      r.preparos = (r.preparos || []).filter(function (p) { return p.id !== b.dataset.id; });
      redesenharListas();
      App.toast('Aviso removido.', 'ok');
    },
    'org-sugerir': function () { Org.sugerir(); },
    'org-dia-semana': function (b) {
      const r = rascunho(); r.diasSemana = r.diasSemana || [];
      const k = Number(b.dataset.dia);
      const p = r.diasSemana.indexOf(k);
      if (p >= 0) r.diasSemana.splice(p, 1); else r.diasSemana.push(k);
      b.classList.toggle('marcado');
    },
    'org-add-levar': function (b) {
      const r = rascunho(); r.itensLevar = r.itensLevar || [];
      const txt = b.dataset.texto;
      if (r.itensLevar.some(function (x) { return x.texto === txt; })) { App.toast('Já está na lista.', 'erro'); return; }
      r.itensLevar.push({ id: U.uid('K'), texto: txt, ok: false });
      redesenharListas();
    },
    'org-toggle-levar': function (b) {
      const r = rascunho();
      (r.itensLevar || []).forEach(function (x) { if (x.id === b.dataset.id) x.ok = !x.ok; });
      redesenharListas();
    },
    'testar-agora': function () { Org.testarAgora(); },
    'testar-2min': function () { Org.testar2Min(); },
    'excluir-teste': function () { Org.excluirTeste(); }
  };

  Org.tratarAcao = function (nome, botao) {
    const fn = Org.acoes[nome];
    if (!fn) return false;
    fn(botao);
    return true;
  };

  // liga as ações ao clique global sem tocar no despachante original
  raiz.document.addEventListener('click', function (ev) {
    const b = ev.target.closest ? ev.target.closest('[data-acao]') : null;
    if (!b) return;
    const nome = b.dataset.acao;
    if (!Org.acoes[nome]) return;
    ev.preventDefault();
    ev.stopPropagation();
    try { Org.acoes[nome](b); } catch (e) { App.toast('Não foi possível concluir: ' + e.message, 'erro'); }
  }, true);

  // 4) rota pela URL (ex.: recarregar a página em #compromissos)
  raiz.addEventListener('load', function () {
    const h = (raiz.location.hash || '').replace('#', '');
    if (EXT[h]) setTimeout(function () { App.navegar(h); }, 300);
  });

  if (typeof module !== 'undefined' && module.exports) module.exports = Org;
})(typeof window !== 'undefined' ? window : globalThis);
