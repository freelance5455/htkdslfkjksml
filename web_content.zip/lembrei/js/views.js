/* ==========================================================================
   Lembrei — views.js
   Telas principais: topo, abas, painel, lista de contas e formulário.
   ========================================================================== */
(function (raiz) {
  'use strict';
  const V = {};
  const U = raiz.U;

  /* ------------------------------- métricas -------------------------------- */
  V.metricas = function (contas, hoje) {
    hoje = hoje || U.hojeISO();
    const mes = U.mesDe(hoje);
    const pend = contas.filter(function (c) { return !c.pago; });
    const pagas = contas.filter(function (c) { return c.pago; });
    const pagarMes = pend.filter(function (c) { return U.mesDe(c.vencimento) === mes; });
    const pagasMes = pagas.filter(function (c) { return c.pagoEm && U.mesDe(String(c.pagoEm).slice(0, 10)) === mes; });
    const vencidas = pend.filter(function (c) { return U.diffDias(c.vencimento, hoje) < 0; });
    const prox = pend.filter(function (c) { const d = U.diffDias(c.vencimento, hoje); return d >= 0 && d <= 7; });
    const totalMes = U.somar(pagarMes) + U.somar(pagasMes);
    return {
      mes: mes,
      qtdPend: pend.length,
      valorPend: U.somar(pend),
      qtdPagarMes: pagarMes.length,
      valorPagarMes: U.somar(pagarMes),
      qtdPagasMes: pagasMes.length,
      valorPagasMes: U.somar(pagasMes),
      qtdVencidas: vencidas.length,
      valorVencidas: U.somar(vencidas),
      qtdProx: prox.length,
      valorProx: U.somar(prox),
      progresso: totalMes > 0 ? U.clamp(U.somar(pagasMes) / totalMes, 0, 1) : 0
    };
  };

  V.temDemo = function (contas) {
    return contas.some(function (c) { return c.demo; });
  };

  /* --------------------------------- topo --------------------------------- */
  V.topo = function (estado) {
    const cfg = raiz.Store.config();
    const pendentes = raiz.Store.contas().filter(function (c) { return !c.pago; });
    const naoLidas = raiz.App.contarAvisosPendentes ? raiz.App.contarAvisosPendentes() : 0;
    const nome = (cfg.nome || '').trim();
    const saud = U.saudacao() + (nome ? ', ' + U.esc(nome.split(' ')[0]) : '');
    return '' +
      '<div class="marca">' +
        '<span class="logo" aria-hidden="true">' + U.icone('check') + '</span>' +
        '<span style="min-width:0">' +
          '<h1>Lembrei</h1>' +
          '<span class="sub">' + saud + ' • ' + U.fmtData(U.hojeISO()) + '</span>' +
        '</span>' +
      '</div>' +
      '<button class="btn-icone" data-acao="navegar" data-rota="notificacoes" aria-label="Central de notificações" title="Lembretes">' +
        U.icone('sino') + (naoLidas > 0 ? '<span class="ponto"></span>' : '') +
      '</button>' +
      '<button class="btn-icone" data-acao="toggle-tema" aria-label="Alternar tema claro e escuro" title="Tema">' +
        U.icone(document.documentElement.getAttribute('data-tema') === 'escuro' ? 'sol' : 'lua') +
      '</button>';
  };

  /* --------------------------------- abas --------------------------------- */
  V.abas = function (rota) {
    const itens = [
      ['painel', 'painel', 'Painel'],
      ['contas', 'historico', 'Contas'],
      ['calendario', 'calendario', 'Agenda'],
      ['historico', 'grafico', 'Relatórios'],
      ['config', 'config', 'Ajustes']
    ];
    return itens.map(function (i) {
      return '<button class="ab ' + (rota === i[0] ? 'on' : '') + '" data-acao="navegar" data-rota="' + i[0] + '"' +
        (rota === i[0] ? ' aria-current="page"' : '') + '>' + U.icone(i[1]) + '<span>' + i[2] + '</span></button>';
    }).join('');
  };

  /* ------------------------------ cartão de conta -------------------------- */
  V.cartaoConta = function (c, hoje, opcoes) {
    opcoes = opcoes || {};
    const st = U.status(c, hoje);
    const cat = U.categoria(c.categoria);
    const detalhe = c.pago
      ? 'Pago em ' + U.fmtData(String(c.pagoEm || '').slice(0, 10))
      : U.textoPrazo(c.vencimento, hoje);
    const _ls = U.lembretesNormalizados(c, raiz.Store.config());
    const _lemb = _ls.length ? (c.pago ? 'lembretes encerrados' : _ls.length + ' lembrete' + (_ls.length > 1 ? 's' : '')) : 'sem lembrete';
    return '' +
    '<article class="conta ' + st + '" data-acao="detalhes" data-id="' + c.id + '" role="button" tabindex="0" aria-label="' + U.esc(c.nome) + ', ' + U.fmtBRL(c.valor) + ', ' + detalhe + '">' +
      '<span class="av" aria-hidden="true">' + U.icone(cat.icone, 'g') + '</span>' +
      '<div class="info">' +
        '<div class="nome">' + U.esc(c.nome) +
          (c.demo ? ' <span class="selo exemplo">EXEMPLO</span>' : '') +
          '<span class="selo ' + U.STATUS[st].classe + '">' + U.STATUS[st].rotulo + '</span>' +
        '</div>' +
        '<div class="meta">' +
          '<span>' + U.icone('calendario2') .replace('class="ic ', 'class="ic" style="width:14px;height:14px;display:inline-block;vertical-align:-2px;margin-right:3px" ') + U.fmtData(c.vencimento) + '</span>' +
          '<span>' + U.esc(cat.nome) + '</span>' +
          (c.recorrencia !== 'nenhuma' ? '<span>' + U.icone('atualizar').replace('class="ic ', 'class="ic" style="width:14px;height:14px;display:inline-block;vertical-align:-2px;margin-right:3px" ') + U.esc(U.rotuloRecorrencia(c.recorrencia)) + '</span>' : '') +
          '<span>' + U.esc(detalhe) + '</span>' +
          '<span>' + U.icone('sino').replace('class="ic ', 'class="ic" style="width:14px;height:14px;display:inline-block;vertical-align:-2px;margin-right:3px" ') + _lemb + '</span>' +
        '</div>' +
        '<div class="valor" style="margin-top:7px">' + U.fmtBRL(c.valor) + '</div>' +
      '</div>' +
      '<div class="dir">' +
        '<div class="acoes">' +
          (c.pago
            ? '<button class="bloco-acao" data-acao="desfazer-pagamento" data-id="' + c.id + '" aria-label="Desfazer pagamento de ' + U.esc(c.nome) + '" title="Desfazer pagamento">' + U.icone('desfazer') + '</button>'
            : '<button class="bloco-acao ok" data-acao="pagar" data-id="' + c.id + '" aria-label="Marcar ' + U.esc(c.nome) + ' como paga" title="Marcar como paga">' + U.icone('check') + '</button>') +
          '<button class="bloco-acao" data-acao="editar" data-id="' + c.id + '" aria-label="Editar ' + U.esc(c.nome) + '" title="Editar">' + U.icone('lapis') + '</button>' +
        '</div>' +
      '</div>' +
    '</article>';
  };

  /* -------------------------------- painel -------------------------------- */
  V.painel = function () {
    const contas = raiz.Store.contas();
    const hoje = U.hojeISO();
    const m = V.metricas(contas, hoje);
    const pend = U.ordenar(contas.filter(function (c) { return !c.pago; }), 'vencimento').slice(0, 5);
    const demo = V.temDemo(contas);

    let html = '';

    if (demo) {
      html += '<div class="faixa exemplo" style="margin-bottom:14px">' + U.icone('info') +
        '<span class="cresce"><b>Você está vendo contas de EXEMPLO.</b> Elas têm o selo roxo e servem só para conhecer o app. ' +
        'Suas contas reais aparecem do mesmo jeito. Nada de exemplo é misturado aos seus dados.</span></div>' +
        '<div class="linha-botoes" style="margin-bottom:18px">' +
        '<button class="btn btn-claro" data-acao="remover-exemplos">' + U.icone('lixeira') + 'Apagar exemplos</button>' +
        '<button class="btn btn-contorno" data-acao="nova">' + U.icone('mais') + 'Minha 1ª conta</button></div>';
    }

    html += '<button class="btn btn-primario btn-largo btn-g" data-acao="nova">' + U.icone('mais') + 'Adicionar conta</button>';

    html += '<div class="grade2" style="margin-top:16px">' +
      '<div class="cartao kpi"><div class="rot">' + U.icone('historico') + 'Contas pendentes</div>' +
        '<div class="val">' + m.qtdPend + '</div><div class="obs">' + U.fmtBRL(m.valorPend) + ' no total</div></div>' +
      '<div class="cartao kpi ok"><div class="rot">' + U.icone('pago') + 'Pago em ' + U.fmtMesAno(hoje).split(' de ')[0] + '</div>' +
        '<div class="val">' + U.fmtBRL(m.valorPagasMes) + '</div><div class="obs">' + m.qtdPagasMes + ' conta(s) paga(s)</div></div>' +
    '</div>' +
    '<div class="grade2">' +
      '<div class="cartao kpi atencao"><div class="rot">' + U.icone('relogio') + 'A pagar no mês</div>' +
        '<div class="val">' + U.fmtBRL(m.valorPagarMes) + '</div><div class="obs">' + m.qtdPagarMes + ' conta(s) vencendo</div></div>' +
      '<div class="cartao kpi ' + (m.qtdVencidas ? 'risco' : '') + '"><div class="rot">' + U.icone('alerta') + 'Contas vencidas</div>' +
        '<div class="val">' + m.qtdVencidas + '</div><div class="obs">' + (m.qtdVencidas ? U.fmtBRL(m.valorVencidas) + ' em atraso' : 'Nenhuma em atraso 🎉') + '</div></div>' +
    '</div>';

    html += '<div class="cartao" style="margin-top:12px">' +
      '<div class="secao" style="margin:0 0 4px"><h2>Progresso do mês</h2><span class="mini suave destaque-num">' + Math.round(m.progresso * 100) + '%</span></div>' +
      '<div class="barra"><i style="width:' + Math.round(m.progresso * 100) + '%"></i></div>' +
      '<div class="mini suave">' + U.fmtBRL(m.valorPagasMes) + ' pagos de ' + U.fmtBRL(m.valorPagasMes + m.valorPagarMes) + ' previstos em ' + U.fmtMesAno(hoje) + '.</div>' +
      '</div>';

    if (m.qtdVencidas > 0) {
      html += '<div class="faixa alerta" style="margin-top:14px">' + U.icone('alerta') +
        '<span class="cresce"><b>' + m.qtdVencidas + ' conta(s) em atraso</b> somando ' + U.fmtBRL(m.valorVencidas) + '. Resolva primeiro o que já venceu.</span>' +
        '<button data-acao="filtro-atalho" data-filtro="vencidas">Ver</button></div>';
    }

    html += '<div class="secao"><h2>Próximos vencimentos</h2>' +
      (pend.length ? '<button class="ver" data-acao="navegar" data-rota="contas">Ver todas</button>' : '') + '</div>';

    if (!pend.length) {
      html += '<div class="vazio"><div class="bolha">' + U.icone('pago') + '</div>' +
        '<h3>Nenhuma conta pendente</h3>' +
        '<p>Você está em dia! Cadastre a próxima conta para não esquecer.</p>' +
        '<button class="btn btn-primario btn-largo" data-acao="nova">' + U.icone('mais') + 'Adicionar conta</button></div>';
    } else {
      html += '<div class="contas">' + pend.map(function (c) { return V.cartaoConta(c, hoje); }).join('') + '</div>';
    }

    if (m.qtdProx > 0) {
      html += '<div class="faixa" style="margin-top:16px">' + U.icone('relogio') +
        '<span class="cresce"><b>' + m.qtdProx + ' conta(s)</b> vencem nos próximos 7 dias, total de ' + U.fmtBRL(m.valorProx) + '.</span></div>';
    }

    html += V.dicaLembretes(hoje);
    return html;
  };

  V.dicaLembretes = function (hoje) {
    const cfg = raiz.Store.config();
    const temPermissao = raiz.App.permissaoNotificacao() === 'granted';
    if (temPermissao) return '';
    return '<div class="caixa-info" style="margin-top:16px">' + U.icone('sino') +
      ' <b>Ative os lembretes.</b> Vá em <b>Ajustes ▸ Lembretes e notificações</b> para permitir avisos. ' +
      'Enquanto a permissão não é dada, o Lembrei mostra os avisos na <b>Central de lembretes</b> (o sininho no topo) e você pode também ' +
      'exportar um arquivo de calendário que gera alarmes no app de Agenda do celular.</div>';
  };

  /* -------------------------------- contas -------------------------------- */
  V.contas = function () {
    const est = raiz.App.estado;
    const contas = raiz.Store.contas();
    const hoje = U.hojeISO();

    let lista = contas.slice();
    if (est.filtro === 'avencer') lista = lista.filter(function (c) { return !c.pago && U.diffDias(c.vencimento, hoje) >= 0; });
    else if (est.filtro === 'vencidas') lista = lista.filter(function (c) { return !c.pago && U.diffDias(c.vencimento, hoje) < 0; });
    else if (est.filtro === 'pagas') lista = lista.filter(function (c) { return c.pago; });
    else if (est.filtro === 'pendentes') lista = lista.filter(function (c) { return !c.pago; });

    if (est.categoria !== 'todas') lista = lista.filter(function (c) { return c.categoria === est.categoria; });
    if (est.mes) lista = lista.filter(function (c) { return U.mesDe(c.vencimento) === est.mes; });
    if (est.busca) {
      const q = U.norm(est.busca);
      lista = lista.filter(function (c) {
        return U.norm(c.nome).indexOf(q) >= 0 || U.norm(c.beneficiario).indexOf(q) >= 0 || U.norm(c.descricao).indexOf(q) >= 0;
      });
    }
    lista = U.ordenar(lista, est.ordem);

    const filtros = [
      ['todas', 'Todas'],
      ['avencer', 'A vencer'],
      ['vencidas', 'Vencidas'],
      ['pagas', 'Pagas'],
      ['pendentes', 'Pendentes']
    ];
    let html = '<div class="busca">' + U.icone('busca') +
      '<input class="campo" id="campo-busca" type="search" inputmode="search" placeholder="Buscar por nome, empresa ou descrição" value="' + U.esc(est.busca) + '" aria-label="Buscar contas">' +
      '</div>';

    html += '<div class="rolagem-x" role="tablist" aria-label="Filtrar por situação">' +
      filtros.map(function (f) {
        return '<button class="chip ' + (est.filtro === f[0] ? 'marcado' : '') + '" data-acao="filtro" data-filtro="' + f[0] + '" role="tab" aria-selected="' + (est.filtro === f[0]) + '">' + f[1] + '</button>';
      }).join('') + '</div>';

    html += '<div class="rolagem-x" aria-label="Filtrar por categoria">' +
      '<button class="chip ' + (est.categoria === 'todas' ? 'marcado' : '') + '" data-acao="categoria" data-cat="todas">Todas as categorias</button>' +
      U.CATEGORIAS.map(function (c) {
        return '<button class="chip ' + (est.categoria === c.id ? 'marcado' : '') + '" data-acao="categoria" data-cat="' + c.id + '">' + U.icone(c.icone) + c.nome + '</button>';
      }).join('') + '</div>';

    html += '<div class="rolagem-x" style="align-items:center" aria-label="Filtrar por mês e ordenar">' +
      '<label class="chip ' + (est.mes ? 'marcado' : '') + '" style="cursor:default">' + U.icone('calendario') +
      '<input type="month" id="campo-mes" value="' + U.esc(est.mes) + '" aria-label="Filtrar por mês" style="border:0;background:none;font:inherit;color:inherit;padding:0;min-width:118px"></label>' +
      (est.mes ? '<button class="chip" data-acao="limpar-mes">' + U.icone('x') + 'Limpar mês</button>' : '') +
      '<button class="chip ' + (est.ordem === 'vencimento' ? 'marcado' : '') + '" data-acao="ordem" data-criterio="vencimento" aria-pressed="' + (est.ordem === 'vencimento') + '">' + U.icone('calendario2') + 'Vencimento</button>' +
      '<button class="chip ' + (est.ordem === 'valor' ? 'marcado' : '') + '" data-acao="ordem" data-criterio="valor" aria-pressed="' + (est.ordem === 'valor') + '">' + U.icone('dinheiro') + 'Valor</button>' +
      '<button class="chip ' + (est.ordem === 'nome' ? 'marcado' : '') + '" data-acao="ordem" data-criterio="nome" aria-pressed="' + (est.ordem === 'nome') + '">' + U.icone('outros') + 'Nome</button>' +
      '</div>';

    const total = U.somar(lista);
    html += '<div class="totais">' +
      '<div class="tl p"><span>Valor filtrado</span><b>' + U.fmtBRL(total) + '</b></div>' +
      '<div class="tl"><span>Contas exibidas</span><b>' + lista.length + '</b></div>' +
      '</div>';

    if (!lista.length) {
      const semNada = contas.length === 0;
      html += '<div class="vazio"><div class="bolha">' + U.icone(semNada ? 'mais' : 'busca') + '</div>' +
        '<h3>' + (semNada ? 'Nenhuma conta cadastrada' : 'Nada encontrado') + '</h3>' +
        '<p>' + (semNada
          ? 'Cadastre sua primeira conta: nome, valor e data de vencimento. Leva menos de um minuto.'
          : 'Tente outro filtro, outro mês ou limpe a busca para ver todas as contas.') + '</p>' +
        (semNada
          ? '<button class="btn btn-primario btn-largo" data-acao="nova">' + U.icone('mais') + 'Adicionar conta</button>'
          : '<button class="btn btn-claro btn-largo" data-acao="limpar-filtros">' + U.icone('atualizar') + 'Limpar filtros</button>') +
        '</div>';
    } else {
      html += '<div class="contas">' + lista.map(function (c) { return V.cartaoConta(c, hoje); }).join('') + '</div>';
    }

    html += '<button class="btn btn-primario btn-largo btn-g" data-acao="nova" style="margin-top:18px">' + U.icone('mais') + 'Adicionar conta</button>';
    return html;
  };

  /* ------------------------------- formulário ------------------------------ */
  V.formulario = function (conta) {
    const cfg = raiz.Store.config();
    const novo = !conta;
    const c = conta || {
      nome: '', valor: '', vencimento: U.hojeISO(), categoria: 'outros', descricao: '',
      beneficiario: '', recorrencia: 'nenhuma', recorrenciaFim: '', lembretes: (cfg.lembretes || [3, 0]).slice(),
      hora: cfg.hora || '09:00', repetirAtePagar: !!cfg.repetirAtePagar
    };
    const lembs = (c.lembretes || []).slice();

    let h = '<h3>' + (novo ? 'Nova conta' : 'Editar conta') + '</h3>' +
      '<p>' + (novo ? 'Preencha só o essencial. Os campos com * são obrigatórios.' : 'Altere o que precisar e salve.') + '</p>' +
      '<form id="form-conta" novalidate>';

    h += '<div class="form-grupo"><label for="f-nome">Nome da conta *</label>' +
      '<input class="campo" id="f-nome" name="nome" type="text" autocomplete="off" enterkeyhint="next" placeholder="Ex.: Conta de luz" value="' + U.esc(c.nome) + '" required>' +
      '<div class="erro-texto" id="e-nome" hidden>Escreva um nome para identificar a conta.</div></div>';

    h += '<div class="form-grupo"><label for="f-valor">Valor em reais (R$) *</label>' +
      '<div style="display:flex;align-items:center;gap:10px">' +
      '<span class="destaque-num suave" style="font-size:22px">R$</span>' +
      '<input class="campo campo-valor" id="f-valor" name="valor" type="text" inputmode="decimal" autocomplete="off" placeholder="0,00" value="' + (c.valor === '' || c.valor == null ? '' : String(c.valor).replace('.', ',')) + '" required>' +
      '</div><div class="erro-texto" id="e-valor" hidden>Informe um valor maior que zero. Você pode usar vírgula: 120,50</div>' +
      '<div class="ajuda">Aceita valores como <b>120</b>, <b>120,50</b> ou <b>1.250,90</b>.</div></div>';

    h += '<div class="grade-campos">' +
      '<div class="form-grupo"><label for="f-venc">Data de vencimento *</label>' +
      '<input class="campo" id="f-venc" name="vencimento" type="date" value="' + U.esc(c.vencimento) + '" required>' +
      '<div class="erro-texto" id="e-venc" hidden>Escolha a data de vencimento.</div></div>' +
      '<div class="form-grupo"><label for="f-hora">Horário do lembrete</label>' +
      '<input class="campo" id="f-hora" name="hora" type="time" value="' + U.esc(c.hora || '09:00') + '">' +
      '<div class="ajuda">Quando o aviso deve aparecer.</div></div>' +
      '</div>';

    h += '<div class="form-grupo"><label for="f-cat">Categoria</label><select class="campo-select" id="f-cat" name="categoria">' +
      U.CATEGORIAS.map(function (x) {
        return '<option value="' + x.id + '"' + (c.categoria === x.id ? ' selected' : '') + '>' + x.nome + '</option>';
      }).join('') + '</select></div>';

    h += '<div class="form-grupo"><label for="f-benef">Empresa ou beneficiário <span class="dica">(opcional)</span></label>' +
      '<input class="campo" id="f-benef" name="beneficiario" type="text" autocomplete="off" placeholder="Ex.: Enel, Vivo, Banco X" value="' + U.esc(c.beneficiario) + '"></div>';

    h += '<div class="form-grupo"><label for="f-desc">Descrição <span class="dica">(opcional)</span></label>' +
      '<textarea class="campo-area" id="f-desc" name="descricao" placeholder="Ex.: plano de 500 MB, aparelho em 12x">' + U.esc(c.descricao) + '</textarea></div>';

    h += '<div class="form-grupo"><label for="f-rec">Tipo de recorrência</label>' +
      '<select class="campo-select" id="f-rec" name="recorrencia">' +
      U.RECORRENCIAS.map(function (r) {
        return '<option value="' + r.id + '"' + (c.recorrencia === r.id ? ' selected' : '') + '>' + r.nome + '</option>';
      }).join('') + '</select>' +
      '<div class="ajuda">Ao marcar como paga, o Lembrei cria automaticamente a próxima conta mantendo o histórico.</div></div>';

    h += '<div class="form-grupo" id="grupo-rec-fim"' + (c.recorrencia === 'nenhuma' ? ' hidden' : '') + '>' +
      '<label for="f-rec-fim">Repetir até <span class="dica">(opcional — deixe vazio para sempre)</span></label>' +
      '<input class="campo" id="f-rec-fim" name="recorrenciaFim" type="date" value="' + U.esc(c.recorrenciaFim || '') + '"></div>';

    h += '<div class="form-grupo"><span class="rot-campo">Quando quer ser lembrado? <span class="dica">(pode escolher vários)</span></span>' +
      '<div class="chips" id="chips-lembretes">' +
      U.LEMBRETES.map(function (d) {
        return '<button type="button" class="chip lembrete ' + (lembs.indexOf(d) >= 0 ? 'marcado' : '') + '" data-acao="toggle-lembrete" data-dias="' + d + '" aria-pressed="' + (lembs.indexOf(d) >= 0) + '">' +
          U.icone(d === -1 ? 'fogo' : 'sino') + U.rotuloLembrete(d) + '</button>';
      }).join('') + '</div>' +
      (lembs.indexOf(-1) >= 0 ? '' : '') +
      '<div class="ajuda" id="dica-lembretes">Se não marcar nenhum, o Lembrei usa o padrão dos Ajustes (' + (cfg.lembretes || [3, 0]).map(U.rotuloCurtoLembrete).join(' e ') + ').</div></div>';

    h += '<div class="cartao" style="box-shadow:none;background:var(--fundo)">' +
      '<div class="interruptor" style="padding:0"><span class="txt">' +
      '<b>Repetir o aviso até eu marcar como paga</b>' +
      '<span>Depois do vencimento, o Lembrei lembra todos os dias (1 aviso por dia).</span></span>' +
      '<button type="button" class="sw ' + (c.repetirAtePagar !== false ? 'ligado' : '') + '" id="sw-repetir" data-acao="toggle-switch" aria-label="Repetir aviso até marcar como paga" aria-pressed="' + (c.repetirAtePagar !== false) + '"></button></div></div>';

    h += '<div class="linha-botoes" style="margin-top:20px">' +
      (novo ? '' : '<button type="button" class="btn btn-perigo" data-acao="excluir" data-id="' + c.id + '">' + U.icone('lixeira') + 'Excluir</button>') +
      '<button type="submit" class="btn btn-primario btn-g" style="flex:2">' + U.icone('check') + (novo ? 'Salvar conta' : 'Salvar alterações') + '</button>' +
      '</div>';
    h += '<input type="hidden" id="f-id" value="' + (conta ? conta.id : '') + '">';
    h += '</form>';
    return h;
  };

  /* --------------------------- detalhes da conta --------------------------- */
  V.detalhes = function (c) {
    const hoje = U.hojeISO();
    const st = U.status(c, hoje);
    const cat = U.categoria(c.categoria);
    const linha = function (r, v) { return '<div class="detalhe-lista"><span>' + r + '</span><b>' + v + '</b></div>'; };
    let h = '<div class="modal-icone">' + U.icone(cat.icone, 'g') + '</div>' +
      '<h3>' + U.esc(c.nome) + (c.demo ? ' <span class="selo exemplo">EXEMPLO</span>' : '') + '</h3>' +
      '<p style="margin-bottom:10px"><span class="selo ' + U.STATUS[st].classe + '">' + U.STATUS[st].rotulo + '</span> ' +
      '<span class="mini suave">' + U.textoPrazo(c.vencimento, hoje) + '</span></p>';
    h += linha('Valor', U.fmtBRL(c.valor));
    h += linha('Vencimento', U.fmtData(c.vencimento) + ' (' + U.DIAS_LONGOS[U.deISO(c.vencimento).getDay()] + ')');
    h += linha('Categoria', U.esc(cat.nome));
    if (c.beneficiario) h += linha('Empresa / beneficiário', U.esc(c.beneficiario));
    if (c.descricao) h += linha('Descrição', U.esc(c.descricao));
    h += linha('Recorrência', U.rotuloRecorrencia(c.recorrencia) + (c.recorrenciaFim ? ' até ' + U.fmtData(c.recorrenciaFim) : ''));
    if (c.recorrencia !== 'nenhuma' && U.proximaData(c)) h += linha('Próximo vencimento', U.fmtData(U.proximaData(c)));
    const _L = U.lembretesNormalizados(c, raiz.Store.config());
    h += linha('Lembretes', _L.length ? _L.map(U.lembreteTexto).join('<br>') : 'nenhum');
    const _rep = U.normalizarRepeticao(c, raiz.Store.config());
    h += linha('Se atrasar', U.intervaloRepeticao(_rep) ? U.repeticaoTexto(_rep, raiz.Store.config()) : 'não repetir');
    if (c.recorrencia !== 'nenhuma') h += linha('Valor', c.valorVariavel ? 'variável (informado ao pagar)' : 'fixo');
    if (c.pago) h += linha('Pago em', U.fmtDataHora(c.pagoEm));
    h += linha('Cadastrada em', U.fmtDataHora(c.criadoEm));

    h += '<div class="linha-botoes" style="margin-top:18px">' +
      (c.pago
        ? '<button class="btn btn-claro" data-acao="desfazer-pagamento" data-id="' + c.id + '">' + U.icone('desfazer') + 'Desfazer pagamento</button>'
        : '<button class="btn btn-verde" data-acao="pagar" data-id="' + c.id + '">' + U.icone('check') + 'Marcar como paga</button>') +
      '<button class="btn btn-contorno" data-acao="editar" data-id="' + c.id + '">' + U.icone('lapis') + 'Editar</button>' +
      '</div>' +
      '<div class="linha-botoes" style="margin-top:8px">' +
      '<button class="btn btn-contorno btn-largo" data-acao="duplicar" data-id="' + c.id + '">' + U.icone('atualizar') + 'Duplicar conta</button>' +
      '</div>';
    return h;
  };

  raiz.Views = V;
})(typeof window !== 'undefined' ? window : globalThis);
