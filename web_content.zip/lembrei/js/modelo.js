/* ==========================================================================
   Lembrei — modelo.js  (v2: lembretes com antecedência e horário individuais)
   --------------------------------------------------------------------------
   MODELO DE DADOS NOVO
   conta.lembretes = [ { id, dias, hora } ]     // dias = quantos dias ANTES
   conta.repeticao = { modo, intervalo, hora, fim }
   conta.valorVariavel = true/false

   Compatibilidade: contas antigas (lembretes = [7,3,1,0,-1]) são convertidas
   por U.migrarConta SEM perder nada. O "-1" (antigo "avisar depois do
   vencimento") vira repeticao.modo = 'diaria'.

   Tudo aqui é função pura (recebe data/hora como texto), para poder ser
   testada sem navegador.
   ========================================================================== */
(function (raiz) {
  'use strict';
  const U = raiz.U;

  U.PRESETS_DIAS = [0, 1, 2, 3, 5, 7, 10, 15, 20, 30];
  U.PRESETS_HORAS = ['07:00', '08:00', '09:00', '12:00', '15:00', '18:00', '20:00'];

  U.MODOS_REPETICAO = [
    { id: 'nenhuma', nome: 'Não repetir', curto: 'Não repetir', dias: 0 },
    { id: 'diaria', nome: 'Todos os dias', curto: 'Todos os dias', dias: 1 },
    { id: '2dias', nome: 'A cada 2 dias', curto: '2 dias', dias: 2 },
    { id: '3dias', nome: 'A cada 3 dias', curto: '3 dias', dias: 3 },
    { id: 'semanal', nome: 'Toda semana', curto: 'Semanal', dias: 7 },
    { id: 'custom', nome: 'Intervalo personalizado', curto: 'Personalizado', dias: null }
  ];

  /* ------------------------------- rótulos -------------------------------- */
  U.rotuloDias = function (d) {
    d = Number(d) || 0;
    if (d === 0) return 'No dia do vencimento';
    if (d === 1) return '1 dia antes';
    return d + ' dias antes';
  };
  U.rotuloCurtoDias = function (d) {
    d = Number(d) || 0;
    if (d === 0) return 'No dia';
    return d + ' dia' + (d > 1 ? 's' : '') + ' antes';
  };
  U.lembreteTexto = function (L) {
    return (Number(L.dias) === 0 ? 'No dia' : (L.dias + ' dias antes')) + ' às ' + (L.hora || '09:00');
  };
  U.modoRepeticao = function (id) {
    return U.MODOS_REPETICAO.filter(function (m) { return m.id === id; })[0] || U.MODOS_REPETICAO[0];
  };
  U.intervaloRepeticao = function (rep) {
    if (!rep || !rep.modo || rep.modo === 'nenhuma') return 0;
    if (rep.modo === 'custom') {
      const n = Math.round(Number(rep.intervalo));
      return n > 0 ? Math.min(365, n) : 0;
    }
    const m = U.modoRepeticao(rep.modo);
    return m.dias || 0;
  };
  U.repeticaoTexto = function (rep, cfg) {
    const inter = U.intervaloRepeticao(rep);
    if (!inter) return 'Não repetir';
    const hora = (rep && rep.hora) || (cfg && cfg.hora) || '09:00';
    let txt;
    if (inter === 1) txt = 'Todos os dias';
    else if (inter === 7) txt = 'Toda semana';
    else txt = 'A cada ' + inter + ' dias';
    txt += ' às ' + hora;
    txt += (rep && rep.fim) ? ', até ' + U.fmtData(rep.fim) : ', até eu marcar como paga';
    return txt;
  };

  /* ------------------------------ normalização ---------------------------- */
  U.repeticaoPadrao = function (cfg) {
    const p = (cfg && cfg.repeticaoPadrao) || {};
    return {
      modo: p.modo || 'diaria',
      intervalo: p.intervalo || null,
      hora: U.horaValida(p.hora) ? p.hora : ((cfg && cfg.hora) || '09:00'),
      fim: p.fim || ''
    };
  };
  U.normalizarRepeticao = function (conta, cfg) {
    const r = (conta && conta.repeticao) ? conta.repeticao : null;
    if (!r || !r.modo) {
      // conta antiga: "repetir até pagar" ligado => diária; desligado => nenhuma
      const quer = conta && conta.repetirAtePagar !== false;
      const padrao = U.repeticaoPadrao(cfg);
      return {
        modo: quer ? 'diaria' : 'nenhuma',
        intervalo: null,
        hora: (conta && conta.hora) || padrao.hora,
        fim: ''
      };
    }
    return {
      modo: r.modo,
      intervalo: r.intervalo || null,
      hora: U.horaValida(r.hora) ? r.hora : ((conta && conta.hora) || (cfg && cfg.hora) || '09:00'),
      fim: r.fim || ''
    };
  };

  U.novoLembrete = function (dias, hora) {
    return { id: U.uid('L'), dias: Math.max(0, Math.round(Number(dias) || 0)), hora: U.horaValida(hora) ? hora : '09:00' };
  };

  /** Lista sempre normalizada de lembretes (aceita formato antigo/numérico). */
  U.lembretesNormalizados = function (conta, cfg) {
    cfg = cfg || {};
    const horaConta = (conta && conta.hora) || cfg.hora || '09:00';
    let arr = (conta && Array.isArray(conta.lembretes)) ? conta.lembretes : null;

    if (!arr || !arr.length) {
      const nums = Array.isArray(cfg.lembretes) ? cfg.lembretes : [7, 3, 1, 0];
      arr = nums.filter(function (d) { return typeof d === 'number' && d >= 0; }).map(function (d) {
        return { id: 'padrao' + d, dias: d, hora: horaConta };
      });
    }

    const vistos = {};
    return arr.map(function (L) {
      if (typeof L === 'number') {
        return (L < 0) ? null : { id: 'n' + L, dias: L, hora: horaConta };
      }
      const dias = Math.max(0, Math.min(365, Math.round(Number(L.dias) || 0)));
      return { id: L.id || ('n' + dias), dias: dias, hora: U.horaValida(L.hora) ? L.hora : horaConta };
    }).filter(function (L) {
      if (!L) return false;
      if (vistos[L.dias]) return false;   // nunca dois lembretes no mesmo dia
      vistos[L.dias] = true;
      return true;
    }).sort(function (a, b) { return b.dias - a.dias; });
  };

  /* ------------------------------- mensagens ------------------------------ */
  U.mensagemAviso = function (conta, av) {
    const valor = U.fmtBRL(conta.valor);
    const nome = String(conta.nome || '').trim();
    if (av.tipo === 'atraso') {
      const n = av.diasAtraso;
      return {
        titulo: 'CONTA ATRASADA',
        corpo: 'Sua conta "' + nome + '" está vencida há ' + n + ' dia' + (n > 1 ? 's' : '') + '. Valor: ' + valor + '.'
      };
    }
    if (av.dias === 0) {
      return { titulo: 'VENCIMENTO HOJE', corpo: 'Não se esqueça de pagar sua conta "' + nome + '". Valor: ' + valor + '.' };
    }
    if (av.dias === 1) {
      return { titulo: 'CONTA VENCE AMANHÃ', corpo: 'Sua conta "' + nome + '" vence amanhã. Valor: ' + valor + '.' };
    }
    return {
      titulo: 'LEMBRETE DE CONTA',
      corpo: 'Sua conta "' + nome + '" vence daqui a ' + av.dias + ' dias. Valor: ' + valor + '.'
    };
  };

  /**
   * Quais avisos devem ser enviados HOJE para esta conta.
   * Regras:
   *  - conta paga nunca gera aviso;
   *  - antes do vencimento: respeita cada lembrete (dias antes + horário);
   *  - se o horário de hoje ainda não chegou, o aviso espera;
   *  - depois do vencimento: só a repetição configurada decide (diária, 2, 3,
   *    semanal, personalizada), respeitando o horário e a data final.
   */
  U.calcularAvisosConta = function (conta, hoje, agora, cfg) {
    const out = [];
    if (!conta || conta.pago || !conta.vencimento) return out;
    hoje = hoje || U.hojeISO();
    agora = agora || U.agoraHHMM();

    const atraso = U.diffDias(hoje, conta.vencimento); // > 0 = hoje depois do vencimento

    if (atraso <= 0) {
      U.lembretesNormalizados(conta, cfg).forEach(function (L) {
        const data = U.addDias(conta.vencimento, -L.dias);
        if (data !== hoje) return;                     // só no dia exato (não avisa dia perdido)
        if (agora < L.hora) return;                    // e somente a partir do horário escolhido
        const msg = U.mensagemAviso(conta, { tipo: 'antes', dias: L.dias });
        out.push({
          chave: conta.id + '|L' + L.dias + '|' + data + '|' + L.hora,
          tipo: 'antes', dias: L.dias, data: data, hora: L.hora,
          titulo: msg.titulo, corpo: msg.corpo
        });
      });
      return out;
    }

    const rep = U.normalizarRepeticao(conta, cfg);
    const inter = U.intervaloRepeticao(rep);
    if (!inter) return out;
    if (rep.fim && hoje > rep.fim) return out;
    if ((atraso - 1) % inter !== 0) return out;        // hoje não é dia de repetir
    if (agora < (rep.hora || '09:00')) return out;     // antes do horário escolhido
    const msg = U.mensagemAviso(conta, { tipo: 'atraso', diasAtraso: atraso });
    out.push({
      chave: conta.id + '|R|' + hoje,
      tipo: 'atraso', diasAtraso: atraso, data: hoje, hora: rep.hora,
      titulo: msg.titulo, corpo: msg.corpo
    });
    return out;
  };

  /* -------------------------------- migração ------------------------------ */
  /** Converte uma conta antiga para o modelo novo. Retorna true se alterou. */
  U.migrarConta = function (conta, cfg) {
    let mudou = false;
    if (!Array.isArray(conta.lembretes)) { conta.lembretes = []; mudou = true; }

    const tinhaAtrasoLegado = conta.lembretes.some(function (L) { return typeof L === 'number' && L < 0; });

    if (conta.lembretes.some(function (L) { return typeof L === 'number'; })) {
      conta.lembretes = conta.lembretes
        .map(function (L) {
          if (typeof L === 'number') {
            return (L < 0) ? null : U.novoLembrete(L, conta.hora || (cfg && cfg.hora) || '09:00');
          }
          return L;
        })
        .filter(Boolean);
      mudou = true;
    }

    if (!conta.repeticao || !conta.repeticao.modo) {
      const querRepetir = conta.repetirAtePagar !== false || tinhaAtrasoLegado;
      conta.repeticao = {
        modo: querRepetir ? 'diaria' : 'nenhuma',
        intervalo: null,
        hora: conta.hora || (cfg && cfg.hora) || '09:00',
        fim: ''
      };
      mudou = true;
    }
    if (typeof conta.valorVariavel !== 'boolean') { conta.valorVariavel = false; mudou = true; }

    if (!conta.lembretes.length) {
      const hora = conta.repeticao.hora || (cfg && cfg.hora) || '09:00';
      const nums = (cfg && Array.isArray(cfg.lembretes)) ? cfg.lembretes : [7, 3, 1, 0];
      conta.lembretes = nums
        .filter(function (d) { return typeof d === 'number' && d >= 0; })
        .map(function (d) { return U.novoLembrete(d, hora); });
      mudou = true;
    }
    return mudou;
  };

  /* ------------------------ helpers para o calendário .ics ---------------- */
  /** Minutos absolutos (dia local * 1440 + hora) — imune a fuso e horário de verão. */
  U.minutosAbs = function (iso, hora) {
    const dias = Math.round((U.deISO(iso).getTime() - U.deISO('1970-01-01').getTime()) / 86400000);
    const p = String(hora || '09:00').split(':');
    return dias * 1440 + (Number(p[0]) || 0) * 60 + (Number(p[1]) || 0);
  };
  /** Duração RFC 5545 a partir de minutos (negativo = antes). */
  U.duracaoIcs = function (min) {
    if (!min) return 'PT0M';
    const neg = min < 0;
    let m = Math.abs(Math.round(min));
    const d = Math.floor(m / 1440); m -= d * 1440;
    const h = Math.floor(m / 60); m -= h * 60;
    let s = (neg ? '-' : '') + 'P';
    if (d) s += d + 'D';
    if (h || m || !d) s += 'T' + (h ? h + 'H' : '') + (m ? m + 'M' : '');
    return s;
  };

  raiz.U = U;
})(typeof window !== 'undefined' ? window : globalThis);
