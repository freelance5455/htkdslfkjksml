# Empacotar o Lembrei como app nativo (Android e iOS)

Objetivo: transformar o mesmo app em um aplicativo de verdade, com **notificações que funcionam com o app fechado**, sem servidor.

A ferramenta usada é o **Capacitor**. Ele pega os arquivos desta pasta, coloca dentro de um projeto Android e de um projeto iOS e adiciona os recursos nativos.

---

## 1. O que você precisa

- Um computador (Windows ou Linux serve para o Android; **iOS exige um Mac** com Xcode).
- **Node.js** instalado (versão 20 ou superior) — https://nodejs.org
- Para Android: **Android Studio** — https://developer.android.com/studio
- Para iOS: **Xcode** (só no Mac, pela App Store)

Tudo isso é gratuito. As taxas só aparecem na hora de publicar na loja (item 5).

---

## 2. Preparar a pasta web

1. Crie uma pasta chamada `www` e copie para dentro dela: `index.html`, `sw.js`, `manifest.webmanifest`, `css/`, `js/` e `icons/` (tudo o que fica no app, menos os arquivos `.md` e a pasta `opcional`).
2. Em um terminal, dentro da pasta do projeto, rode:

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/local-notifications
npx cap init Lembrei br.com.lembrei --web-dir=www
npx cap add android
npx cap add ios
npx cap sync
```

> `br.com.lembrei` é o identificador do app. Troque pelo seu domínio invertido se tiver um. Ele não pode ser mudado depois de publicado.

---

## 3. Ativar as notificações locais (com app fechado)

O plugin já instalado (`@capacitor/local-notifications`) agenda alarmes **no próprio aparelho**, sem servidor. O app já foi escrito para o seu motor de lembretes funcionar bem com ele: cada lembrete tem data, hora e um identificador único.

No código do app (por exemplo, ao salvar uma conta), use:

```js
import { LocalNotifications } from '@capacitor/local-notifications';

// 1) pedir permissão (Android 13+ e iOS exigem)
await LocalNotifications.requestPermissions();

// 2) agendar cada lembrete da conta
const alarmes = lembretes.map((dias, i) => ({
  id: contador++,
  title: `Pagar ${conta.nome}`,
  body: `${valor} • vence em ${dataFormatada}`,
  schedule: { at: new Date(ano, mes - 1, dia - dias, 9, 0) },
  smallIcon: 'ic_stat_icon'
}));
await LocalNotifications.schedule({ notifications: alarmes });
```

E, ao marcar a conta como paga, cancele os alarmes pendentes daquela conta:

```js
await LocalNotifications.cancel({ notifications: [{ id: idDoAlarme }] });
```

Observações práticas:
- São necessários ícones pequenos de notificação no Android (arquivos `ic_stat_*.png` em `android/app/src/main/res/drawable/`). O Android usa ícone branco em fundo colorido.
- No iOS, alarmes agendados sobrevivem ao app fechado e à reinicialização do aparelho.
- No Android, alguns fabricantes (Xiaomi, Samsung, Huawei) aplicam economia de bateria agressiva. Oriente o usuário a marcar o app como "sem restrição de bateria" nas configurações do aparelho — isso é normal em qualquer app de lembrete.

---

## 4. Testar no celular

```bash
npx cap run android     # com o celular ligado por USB ou um emulador aberto
npx cap run ios         # no Mac, com simulador ou iPhone conectado
```

Sempre que alterar os arquivos da pasta `www`, rode `npx cap sync` antes de testar de novo.

---

## 5. Publicar nas lojas

### Google Play
1. Crie uma conta de desenvolvedor no **Google Play Console** (taxa única).
2. Gere o pacote assinado: no Android Studio, *Build ▸ Generate Signed Bundle / APK ▸ Android App Bundle*.
3. Crie o app no Play Console, envie o `.aab`, preencha ficha da loja, política de privacidade, classificação e prints.
4. Envie para teste interno primeiro (dá para testar com poucas pessoas antes de liberar geral).

### App Store
1. Conta no **Apple Developer Program** (assinatura anual).
2. No Xcode: *Product ▸ Archive ▸ Distribute App ▸ App Store Connect*.
3. No App Store Connect: preencha a ficha, envie para **TestFlight** (teste com até 100 pessoas) e depois para revisão.
4. A Apple exige que o app tenha conteúdo próprio suficiente — um app que é apenas um site embrulhado pode ser recusado. O Lembrei tem dados locais, notificações e relatórios, o que ajuda, mas vale explicar isso claramente na ficha.

> Os valores das taxas mudam. Confirme nos sites oficiais antes de pagar.

---

## 6. Alternativa sem computador

Se você não tem Mac nem quer instalar Android Studio, existem serviços que compilam na nuvem (a maioria é paga, com período de teste). A recomendação honesta é: comece usando o PWA pela tela inicial do celular. Ele já resolve 95% do problema, é grátis e não depende de loja nenhuma.
