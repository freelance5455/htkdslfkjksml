# Lembrei — versão Android com notificações confiáveis (Capacitor)

> **Status: NÃO ativado.** Este documento é o caminho preparado, não algo já feito.
> Enquanto você não autorizar, o app continua sendo o PWA (grátis, instalável,
> avisos reais com o app aberto ou em segundo plano).

## Por que isso é necessário

Um PWA não recebe permissão do sistema para "acordar" sozinho quando está fechado.
Isso não é uma limitação do Lembrei: vale para qualquer site/PWA no Android e no
iPhone. Para o aviso tocar com o app **totalmente fechado**, o app precisa virar um
aplicativo instalado de verdade (um pacote `.apk`/`.aab`), porque só apps
instalados podem pedir ao Android o direito de agendar alarmes.

O caminho mais barato para isso é o **Capacitor**: ele embrulha o **mesmo** HTML,
CSS e JavaScript que você já tem dentro de um app Android nativo. Nada do que está
pronto é jogado fora — nem as telas, nem os dados, nem as regras de lembrete.

| Alternativa | Aviso com app fechado | Custo | Reaproveita o app? |
|---|---|---|---|
| PWA (hoje) | Não | R$ 0 | — |
| PWA + arquivo `.ics` na Agenda | **Sim** | R$ 0 | Sim (já existe) |
| **Capacitor + notificações locais** | **Sim** | R$ 0 | Sim, quase tudo |
| Servidor de push (VAPID) | Sim | Servidor ligado 24h (pago) | Sim, mas envia dados para fora |

## Custos

| Item | Valor |
|---|---|
| Android Studio + SDK | R$ 0 |
| Publicar na Google Play (taxa única, conta pessoal) | US$ 25, uma vez |
| Teste fechado obrigatório (contas novas) | 12 testadores × 14 dias, sem custo |
| iPhone | precisa de Mac com Xcode + US$ 99/ano |

## Passos (quando você autorizar)

```bash
# 1. no computador, dentro da pasta do projeto
npm install @capacitor/core @capacitor/cli
npx cap init "Lembrei" "br.com.lembrei.app" --web-dir=.
npm install @capacitor/local-notifications
npx cap add android
npx cap sync android
```

### Permissões no `android/app/src/main/AndroidManifest.xml`

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
<uses-permission android:name="android.permission.VIBRATE"/>
```

- `POST_NOTIFICATIONS` — obrigatória no Android 13+. O app pede na primeira vez.
- `SCHEDULE_EXACT_ALARM` — no Android 14+ **não** é concedida sozinha. O app precisa
  abrir a tela de permissão e o usuário precisa permitir "Alarmes e lembretes".
- `RECEIVE_BOOT_COMPLETED` — para reagendar tudo depois de reiniciar o celular.

### O que muda no JavaScript (poucas linhas)

Hoje o aviso sai por `showNotification` do Service Worker. Com Capacitor, passa a sair
por `LocalNotifications.schedule(...)`. A lógica já está separada em um único lugar
(`App.mostrarAviso` e `App.verificarLembretes`), então a troca é pontual:

```js
import { LocalNotifications } from '@capacitor/local-notifications';

// pedir permissão
await LocalNotifications.requestPermissions();

// agendar um aviso nosso (id numérico estável evita duplicidade)
await LocalNotifications.schedule({ notifications: [{
  id: 20261022,                       // derive do lembrete: nunca repita
  title: 'CONTA VENCE AMANHÃ',
  body: 'Sua conta "Internet" vence amanhã. Valor: R$ 120,00.',
  schedule: { at: new Date(2026, 10, 19, 9, 0), allowWhileIdle: true },
  sound: 'default',                    // som do canal de notificação
  channelId: 'lembrei',                // canal com som e vibração
  smallIcon: 'ic_stat_lembrei',
  extra: { itemId: 'c-123' }
}]});
```

Regras que o código deve manter (já validadas na versão PWA):

1. **Cancelar** os avisos da ocorrência quando o usuário marcar como paga.
2. **Reagendar** tudo quando vencimento/data/horário mudar.
3. **Reagendar** após reiniciar o aparelho (`RECEIVE_BOOT_COMPLETED`).
4. **Id estável** por lembrete para nunca duplicar aviso.
5. **Fuso local** do aparelho, sem somar deslocamento de UTC.

### Avisos honestos sobre o resultado

- **Xiaomi, Samsung, Huawei, Oppo, Vivo** matam alarmes por economia de bateria.
  É obrigatório pedir ao usuário para desativar a otimização de bateria do Lembrei
  (`Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`).
- No **iPhone**, notificações locais agendadas podem não ser entregues se o app ficar
  muito tempo sem ser aberto. Não é possível garantir 100% de confiabilidade no iOS.
- Nada disso é afirmado como testado: a única forma de confirmar é rodar em um
  aparelho real (passo a passo na seção 9 do relatório).

## Alternativa de custo zero que já existe hoje

**Ajustes ▸ Calendário (.ics)** gera um arquivo com alarmes reais que você importa no
app de Agenda do celular. A Agenda tem a permissão de acordar com o aparelho fechado,
inclusive com som. É a solução gratuita que cobre o caso "app fechado" enquanto a
versão Android não é publicada.
