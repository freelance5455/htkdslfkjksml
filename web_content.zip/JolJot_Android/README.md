# JolJot Android Project

JolJot is a Bangladesh-focused urban waterlogging intelligence prototype prepared for the BIP World Town Planning Day 2026 Apps4Solutions concept.

## Included
- Mobile-first JolJot interface
- Live Open-Meteo weather/rainfall API
- OpenStreetMap/Leaflet map
- Current-location permission
- Waterlogging reporting flow
- Urban Planning Toolkit: drainage, mobility, land use, public-space resilience
- About section with Sultan Mahmud

## Build APK in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync and install the required SDK/Gradle dependencies.
3. Select `app` and an emulator/phone.
4. Run to test.
5. Choose **Build > Build APK(s)**.
6. APK will normally be under `app/build/outputs/apk/debug/`.

The app uses external live services, so the device needs internet access. Location permission is requested for the "Use my current location" feature.
