package com.joljot.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var lm: LocationManager
    private val locationRequestCode = 1001
    private val main = Handler(Looper.getMainLooper())

    // Location requests coming from JavaScript: id -> listener
    private class Req(val id: Int, val watch: Boolean) {
        val listeners = mutableListOf<LocationListener>()
        var timeout: Runnable? = null
        var delivered = false
    }
    private val reqs = mutableMapOf<Int, Req>()
    private val waitingForPermission = mutableListOf<Req>()

    private fun hasPerm() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        webView = findViewById(R.id.webView)
        WebView.setWebContentsDebuggingEnabled(false)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                val u = r?.url ?: return false
                if (u.scheme == "file") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { }
                return true
            }
        }
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun share(text: String) {
                runOnUiThread {
                    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                    startActivity(Intent.createChooser(i, "Send report"))
                }
            }
            @JavascriptInterface
            fun locStart(id: Int, watch: Boolean) { runOnUiThread { startLocation(Req(id, watch)) } }
            @JavascriptInterface
            fun locStop(id: Int) { runOnUiThread { stopLocation(id) } }
        }, "Android")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                val pick = Intent(Intent.ACTION_GET_CONTENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
                return try { startActivityForResult(Intent.createChooser(pick, "Choose photo"), 2001); true } catch (e: Exception) { fileCallback = null; false }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, hasPerm(), false)
            }
        }
        // Ask for permission as soon as the app opens
        if (!hasPerm()) requestPerm()
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun requestPerm() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            locationRequestCode
        )
    }

    // ---------- Native location bridge ----------

    private fun js(code: String) = runOnUiThread { webView.evaluateJavascript(code, null) }

    private fun deliver(r: Req, l: Location) {
        r.delivered = true
        js("window.__geo&&window.__geo.ok(${r.id},${l.latitude},${l.longitude},${l.accuracy})")
        if (!r.watch) stopLocation(r.id)
    }

    private fun fail(r: Req, code: Int, msg: String) {
        js("window.__geo&&window.__geo.err(${r.id},$code,'$msg')")
        stopLocation(r.id)
    }

    private fun startLocation(r: Req) {
        if (!hasPerm()) {
            waitingForPermission.add(r)
            requestPerm()
            return
        }
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (e: Exception) { false } }
        if (providers.isEmpty()) {
            askToEnableLocation()
            fail(r, 2, "Location services are turned off")
            return
        }
        reqs[r.id] = r

        // Instant answer: last known fix (if it is fresh enough)
        val last = providers.mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null } }
            .maxByOrNull { it.time }
        val fresh = last != null && System.currentTimeMillis() - last.time < 2 * 60 * 1000
        if (last != null && fresh) deliver(r, last)
        if (!r.watch && fresh) return

        // Fresh fixes from GPS and network
        for (p in providers) {
            val l = object : LocationListener {
                override fun onLocationChanged(loc: Location) { deliver(r, loc) }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            try {
                lm.requestLocationUpdates(p, if (r.watch) 3000L else 0L, if (r.watch) 5f else 0f, l, Looper.getMainLooper())
                r.listeners.add(l)
            } catch (e: Exception) { }
        }
        if (r.listeners.isEmpty()) { fail(r, 2, "Location unavailable"); return }

        // If nothing arrives, fall back to an old fix, then report a timeout
        val t = Runnable {
            if (!r.delivered) {
                if (last != null) deliver(r, last) else fail(r, 3, "Timed out waiting for GPS")
            }
        }
        r.timeout = t
        main.postDelayed(t, 20000)
    }

    private fun stopLocation(id: Int) {
        val r = reqs.remove(id) ?: return
        r.timeout?.let { main.removeCallbacks(it) }
        for (l in r.listeners) { try { lm.removeUpdates(l) } catch (e: Exception) { } }
        r.listeners.clear()
    }

    private var settingsShown = false
    private fun showPermissionSettings() {
        if (settingsShown) return
        settingsShown = true
        AlertDialog.Builder(this)
            .setTitle("Location permission needed")
            .setMessage("Allow location for JolJot in App settings > Permissions to see your live position.")
            .setPositiveButton("Open app settings") { _, _ ->
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (e: Exception) { }
            }
            .setNegativeButton("Not now", null)
            .setOnDismissListener { settingsShown = false }
            .show()
    }

    private fun askToEnableLocation() {
        AlertDialog.Builder(this)
            .setTitle("Turn on location")
            .setMessage("JolJot needs your phone's location (GPS) switched on to show where you are.")
            .setPositiveButton("Open settings") { _, _ ->
                try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (e: Exception) { }
            }
            .setNegativeButton("Not now", null)
            .show()
    }

    private var fileCallback: ValueCallback<Array<Uri>>? = null

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2001) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationRequestCode) {
            val granted = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            val pending = waitingForPermission.toList()
            waitingForPermission.clear()
            for (r in pending) {
                if (granted) startLocation(r) else fail(r, 1, "Location permission denied")
            }
            if (granted) js("window.dispatchEvent(new Event('joljot-location-granted'))")
            else showPermissionSettings()
        }
    }

    override fun onDestroy() {
        reqs.keys.toList().forEach { stopLocation(it) }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
