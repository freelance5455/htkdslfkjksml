# Nifty Signal Pro — Android Studio Project

यह Android WebView ऐप का source project है। यह APK फ़ाइल नहीं है।

## APK बनाने का तरीका
1. कंप्यूटर पर Android Studio स्थापित करें।
2. Android Studio में इस फ़ोल्डर को Open करें।
3. Gradle sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आमतौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।
6. उस APK को अपने Android फोन में भेजें और खोलकर इंस्टॉल करें।

## महत्वपूर्ण
- इसमें डेमो सिग्नल स्क्रीन है; लाइव Nifty Futures डेटा नहीं।
- लाइव डेटा के लिए किसी अधिकृत broker/market-data API और सुरक्षित backend की जरूरत होगी।
- API secret/key को Android ऐप में hard-code न करें।
- BUY/SELL सिग्नल लाभ की गारंटी नहीं देते। पहले paper trading करें।
