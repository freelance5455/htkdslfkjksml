# Android UI mapping notes

Candidate existing resources identified in the uploaded base APK:
- `res/layout/fragment_home_new.xml` — home dashboard
- `res/layout/activity_home.xml` — home activity container
- `res/layout/activity_sleep_summary.xml` — sleep summary
- `res/layout/activity_measure_heart.xml` — heart-rate measurement
- `res/layout/activity_measure_blood.xml` — blood oxygen measurement
- `res/layout/activity_steps_history.xml` — steps history
- `res/layout/fragment_device_new.xml` — device screen

These are binary Android XML resources in the APK, not editable source XML as extracted here. They need a proper APK resource decoder before editing. The layout names are inspection findings only; they do not prove that every screen can be restyled without code changes.

Do not edit BLE / GATT / pairing / device-protocol classes for a UI-only redesign.
