# Academia SQL SQLite — versión corregida

Proyecto Android Studio nativo, en español y diseñado para trabajar sin internet. La interfaz está en `app/src/main/assets/index.html` y ejecuta consultas contra SQLite local mediante `MainActivity.java`.

## Correcciones de esta versión
- La base local sube a versión 2: al actualizar desde la versión anterior, reconstruye las tablas y carga nuevamente los datos de ejemplo.
- Las consultas `SELECT`, `PRAGMA`, `EXPLAIN` y consultas `WITH` se envían por la ruta de lectura.
- La pantalla de tablas ahora muestra errores de carga en vez de ocultarlos.
- El botón **Probar en SQLite** pasa la consulta mediante un manejador JavaScript seguro, sin insertar SQL dentro de un atributo HTML que se rompa por comillas.
- Los botones de estudiar y de navegación usan manejadores controlados; los errores de interfaz se muestran en pantalla.

## Compilar
1. Extrae el ZIP en una computadora con Android Studio, JDK 17 y Android SDK 35.
2. Abre la carpeta `Academia_SQL_SQLite_Nativa`.
3. Espera la sincronización de Gradle.
4. Selecciona **Build → Build APK(s)**.
5. Instala el APK generado en `app/build/outputs/apk/debug/` en el teléfono Android.

## Nota
Este ZIP contiene el código fuente, no un APK compilado. Se validó la sintaxis JavaScript, pero la compilación Android y la prueba en dispositivo deben verificarse en Android Studio. La migración de base de datos a versión 2 vuelve a crear los datos de ejemplo y elimina tablas/datos que se hubieran agregado a la base de la versión anterior.
