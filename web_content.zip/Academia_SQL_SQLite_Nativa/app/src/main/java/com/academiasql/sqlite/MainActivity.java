package com.academiasql.sqlite;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private Db db;
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        db = new Db(this);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        SqlBridge bridge = new SqlBridge();
        web.addJavascriptInterface(bridge, "NativeSQL");
        web.addJavascriptInterface(bridge, "nativeSql");
        web.addJavascriptInterface(bridge, "nativeSQL");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    public class SqlBridge {
        @JavascriptInterface public String execute(String sql) {
            try {
                if (sql == null || sql.trim().isEmpty()) throw new Exception("Escribe una consulta SQL.");
                String s = sql.trim();
                SQLiteDatabase d = db.getWritableDatabase();
                if (s.matches("(?is)^\\s*(SELECT|PRAGMA|EXPLAIN|WITH)\\b.*")) {
                    Cursor c = d.rawQuery(s, null);
                    JSONArray rows = new JSONArray();
                    JSONArray cols = new JSONArray();
                    for (int i=0;i<c.getColumnCount();i++) cols.put(c.getColumnName(i));
                    while(c.moveToNext()) {
                        JSONObject row = new JSONObject();
                        for(int i=0;i<c.getColumnCount();i++) {
                            Object v;
                            int t=c.getType(i);
                            if(t==Cursor.FIELD_TYPE_NULL) v=JSONObject.NULL;
                            else if(t==Cursor.FIELD_TYPE_INTEGER) v=c.getLong(i);
                            else if(t==Cursor.FIELD_TYPE_FLOAT) v=c.getDouble(i);
                            else v=c.getString(i);
                            row.put(c.getColumnName(i),v);
                        }
                        rows.put(row);
                    }
                    c.close();
                    JSONObject out=new JSONObject(); out.put("ok",true); out.put("columns",cols); out.put("rows",rows); out.put("message","SQLite ejecutó la consulta: "+rows.length()+" fila(s).");
                    return out.toString();
                } else {
                    d.beginTransaction();
                    try {
                        d.execSQL(s);
                        d.setTransactionSuccessful();
                    } finally { d.endTransaction(); }
                    JSONObject out=new JSONObject(); out.put("ok",true); out.put("columns",new JSONArray()); out.put("rows",new JSONArray()); out.put("message","SQLite ejecutó la instrucción correctamente."); return out.toString();
                }
            } catch(Exception e) {
                JSONObject out=new JSONObject();
                try { out.put("ok",false); out.put("error", e.getMessage()==null?"Error SQL":e.getMessage()); } catch(JSONException ignored) {}
                return out.toString();
            }
        }
        @JavascriptInterface public String tables() {
            try {
                JSONArray a=new JSONArray();
                Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null);
                while(c.moveToNext()) a.put(c.getString(0)); c.close(); return a.toString();
            } catch(Exception e) { JSONArray err=new JSONArray(); try { JSONObject o=new JSONObject(); o.put("__error", e.getMessage()==null?"No se pudieron leer las tablas":e.getMessage()); err.put(o); } catch(Exception ignored) {} return err.toString(); }
        }
        @JavascriptInterface public String reset() {
            try { db.reset(); JSONObject o=new JSONObject();o.put("ok",true);o.put("message","Base de ejemplo restaurada.");return o.toString(); }
            catch(Exception e){JSONObject o=new JSONObject();try{o.put("ok",false);o.put("error",e.getMessage());}catch(Exception ignored){}return o.toString();}
        }
    }
    private static class Db extends SQLiteOpenHelper {
        private static final String NAME="academia_sql.db";
        Db(Activity a){super(a,NAME,null,3);}
        @Override public void onCreate(SQLiteDatabase d) { seed(d); }
        @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV) { d.execSQL("DROP TABLE IF EXISTS pedidos"); d.execSQL("DROP TABLE IF EXISTS productos"); d.execSQL("DROP TABLE IF EXISTS categorias"); d.execSQL("DROP TABLE IF EXISTS clientes"); d.execSQL("DROP TABLE IF EXISTS empleados"); seed(d); }
        private void seed(SQLiteDatabase d) {
            d.execSQL("PRAGMA foreign_keys=ON");
            d.execSQL("CREATE TABLE clientes(id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, apellido TEXT, ciudad TEXT, email TEXT, fecha_registro TEXT)");
            d.execSQL("CREATE TABLE categorias(id INTEGER PRIMARY KEY, nombre TEXT NOT NULL UNIQUE)");
            d.execSQL("CREATE TABLE productos(id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, categoria_id INTEGER REFERENCES categorias(id), precio NUMERIC NOT NULL DEFAULT 0 CHECK(precio>=0), stock INTEGER NOT NULL DEFAULT 0 CHECK(stock>=0))");
            d.execSQL("CREATE TABLE pedidos(id INTEGER PRIMARY KEY, cliente_id INTEGER NOT NULL REFERENCES clientes(id), fecha TEXT, estado TEXT, total NUMERIC NOT NULL DEFAULT 0)");
            d.execSQL("CREATE TABLE empleados(id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, departamento TEXT, salario NUMERIC, fecha_ingreso TEXT)");
            String[][] clients={{"1","Ana","López","CDMX","ana@ejemplo.mx","2024-01-12"},{"2","Luis","Pérez","Guadalajara","luis@ejemplo.mx","2024-02-03"},{"3","María","Hernández","Monterrey","maria@ejemplo.mx","2024-02-18"},{"4","Carlos","García","Puebla","carlos@ejemplo.mx","2024-03-01"},{"5","Sofía","Ramírez","CDMX","sofia@ejemplo.mx","2024-03-20"}};
            for(String[] r:clients)d.execSQL("INSERT INTO clientes VALUES(?,?,?,?,?,?)",new Object[]{Integer.parseInt(r[0]),r[1],r[2],r[3],r[4],r[5]});
            d.execSQL("INSERT INTO categorias VALUES(1,'Computación'),(2,'Accesorios'),(3,'Audio')");
            d.execSQL("INSERT INTO productos VALUES(1,'Laptop',1,15000,8),(2,'Mouse',2,250,100),(3,'Teclado',2,450,60),(4,'Monitor',1,3200,15),(5,'Audífonos',3,800,35),(6,'Cable USB',2,120,0)");
            d.execSQL("INSERT INTO pedidos VALUES(101,1,'2024-05-01','Entregado',15250),(102,2,'2024-05-03','Enviado',3200),(103,1,'2024-05-05','Pendiente',800),(104,3,'2024-05-08','Entregado',450),(105,5,'2024-05-11','Pendiente',15000),(106,4,'2024-05-12','Cancelado',250)");
            d.execSQL("INSERT INTO empleados VALUES(1,'Roberto','Ventas',18000,'2021-03-10'),(2,'Patricia','Finanzas',24000,'2020-08-14'),(3,'Jorge','Tecnología',28000,'2022-01-07'),(4,'Lucía','Ventas',19500,'2023-04-22'),(5,'Miguel','Operaciones',21000,'2019-11-02')");
        }
        void reset() { SQLiteDatabase d=getWritableDatabase(); d.beginTransaction(); try { d.execSQL("DROP TABLE IF EXISTS pedidos");d.execSQL("DROP TABLE IF EXISTS productos");d.execSQL("DROP TABLE IF EXISTS categorias");d.execSQL("DROP TABLE IF EXISTS clientes");d.execSQL("DROP TABLE IF EXISTS empleados");seed(d);d.setTransactionSuccessful(); } finally {d.endTransaction();} }
    }
}
