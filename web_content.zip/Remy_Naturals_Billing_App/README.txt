REMY NATURALS BILLING APP

Files:
- index.html: the billing app
- manifest.webmanifest and sw.js: installable/offline PWA support

Use:
1. Open index.html in Chrome/Edge on a PC or Android phone.
2. Enter recipient details and up to 10 product lines.
3. Select GST 0%, 5%, 12% or 18% per line.
4. Choose within Kerala for CGST+SGST, or other state for IGST.
5. Tap Save bill to store it in that browser/device.
6. Tap Print / Save PDF and choose "Save as PDF" in the print dialog.

For install prompt/service worker to work reliably, host the folder on an HTTPS website. On Android Chrome, open the hosted page and choose Install app / Add to Home screen. On PC Chrome/Edge, use the install icon in the address bar or browser menu.

Important:
- This is a responsive installable web app, not a signed Android APK yet.
- Saved bills are local to each browser/device; they do not automatically sync between phone and PC. Export/print PDFs for backup.
- GST is calculated on top of the entered rate (GST-exclusive). Please verify applicable HSN and tax rate with your accountant before issuing invoices.
- Add your official logo image later if you provide it; the current header uses a simple RN monogram.
