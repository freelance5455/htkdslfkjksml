/**
 * AI PERFEITA - Image Generator
 * Uses free public endpoints when possible (Pollinations.ai style)
 * Does NOT fake generation
 */

const Images = {
  async generate(prompt, style = 'realistic') {
    const styleMap = {
      realistic: 'photorealistic, highly detailed, 8k',
      '3d': '3d render, octane render, blender, highly detailed',
      anime: 'anime style, vibrant colors, detailed',
      drawing: 'pencil drawing, sketch, artistic',
      'digital-art': 'digital art, concept art, detailed',
      cyberpunk: 'cyberpunk, neon lights, futuristic city, rainy'
    };

    const fullPrompt = `${prompt}, ${styleMap[style] || styleMap.realistic}`;
    const encoded = encodeURIComponent(fullPrompt);

    // Pollinations.ai free endpoint (no key required for basic use)
    // Note: public, rate-limited, may change
    const url = `https://image.pollinations.ai/prompt/${encoded}?width=768&height=768&nologo=true&seed=${Date.now()}`;

    try {
      // Test if image loads
      const img = new Image();
      img.crossOrigin = 'anonymous';

      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Timeout ao gerar imagem. Serviço pode estar indisponível.'));
        }, 45000);

        img.onload = () => {
          clearTimeout(timeout);
          resolve({ url, prompt: fullPrompt });
        };
        img.onerror = () => {
          clearTimeout(timeout);
          reject(new Error('Falha ao carregar imagem. O serviço gratuito pode estar temporariamente indisponível ou bloqueado.'));
        };
        img.src = url;
      });
    } catch (err) {
      throw err;
    }
  },

  // Alternative: if user has API, could extend later
  getInfo() {
    return 'Usa Pollinations.ai (gratuito, sem chave). Resultados variam. Para melhor qualidade configure APIs pagas futuramente.';
  }
};
