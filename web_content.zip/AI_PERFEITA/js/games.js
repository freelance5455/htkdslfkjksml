/**
 * AI PERFEITA - Game Creator Module
 */

const Games = {
  async generate(prompt, type = 'platform') {
    const settings = Storage.getSettings();
    const hasApi = settings.apiKey && settings.apiKey.trim();

    if (hasApi) {
      const system = `Você é um especialista em jogos HTML5 Canvas para mobile.
Gere um jogo completo e jogável em um único arquivo HTML.
Requisitos:
- Canvas 2D
- Controles touch (e teclado se possível)
- Score, game over, restart
- Tema visual moderno (cores neon/roxo/ciano)
- Código limpo, sem dependências
- Totalmente funcional
Retorne APENAS o código HTML completo.`;

      const userMsg = `Crie um jogo do tipo "${type}": ${prompt}
O jogo deve funcionar bem em celular Android com touch.`;

      try {
        const result = await AI.chat(userMsg, [{ role: 'system', content: system }]);
        const codeMatch = result.match(/```html\n?([\s\S]*?)```/) || result.match(/```\n?([\s\S]*?)```/);
        return codeMatch ? codeMatch[1].trim() : result.trim();
      } catch (e) {
        console.error(e);
      }
    }

    return this.localTemplate(prompt, type);
  },

  localTemplate(prompt, type) {
    // Different simple templates based on type
    if (type === 'shooter') {
      return this.shooterTemplate(prompt);
    }
    if (type === 'runner') {
      return this.runnerTemplate(prompt);
    }
    // Default platform / custom
    return this.platformTemplate(prompt);
  },

  platformTemplate(prompt) {
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1.0">
  <title>Jogo Plataforma</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; touch-action:none; user-select:none; }
    body { background:#0a0a12; overflow:hidden; display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; font-family:system-ui; }
    #ui { position:fixed; top:12px; left:12px; right:12px; display:flex; justify-content:space-between; color:#0ff; font-family:monospace; font-size:16px; z-index:10; pointer-events:none; }
    canvas { background:linear-gradient(180deg,#1a1a2e 0%,#0a0a12 100%); border:2px solid #8b5cf6; max-width:100vw; max-height:80vh; }
    .controls { position:fixed; bottom:20px; left:0; right:0; display:flex; justify-content:center; gap:20px; z-index:10; }
    .btn { width:70px; height:70px; border-radius:50%; background:rgba(139,92,246,0.3); border:2px solid #8b5cf6; color:#fff; font-size:24px; display:flex; align-items:center; justify-content:center; }
    .btn:active { background:rgba(139,92,246,0.6); }
  </style>
</head>
<body>
  <div id="ui">
    <span>Score: <span id="score">0</span></span>
    <span id="msg">Toque para pular</span>
  </div>
  <canvas id="c"></canvas>
  <div class="controls">
    <div class="btn" id="btnLeft">◀</div>
    <div class="btn" id="btnJump">▲</div>
    <div class="btn" id="btnRight">▶</div>
  </div>
  <script>
    const canvas = document.getElementById('c');
    const ctx = canvas.getContext('2d');
    let W, H, score = 0, gameOver = false;
    const gravity = 0.55;
    const player = { x: 50, y: 0, w: 28, h: 28, vx: 0, vy: 0, onGround: false };
    let platforms = [];
    let coins = [];
    let keys = { left: false, right: false, jump: false };

    function resize() {
      W = canvas.width = Math.min(window.innerWidth - 8, 400);
      H = canvas.height = Math.min(window.innerHeight * 0.7, 500);
      player.y = H - 100;
      initLevel();
    }

    function initLevel() {
      platforms = [
        { x: 0, y: H - 30, w: W, h: 30 },
        { x: 80, y: H - 120, w: 80, h: 14 },
        { x: 200, y: H - 200, w: 90, h: 14 },
        { x: 40, y: H - 280, w: 70, h: 14 },
        { x: 180, y: H - 350, w: 100, h: 14 }
      ];
      coins = [
        { x: 110, y: H - 150, r: 8, collected: false },
        { x: 230, y: H - 230, r: 8, collected: false },
        { x: 70, y: H - 310, r: 8, collected: false },
        { x: 220, y: H - 380, r: 8, collected: false }
      ];
    }

    function update() {
      if (gameOver) return;
      if (keys.left) player.vx = -4.5;
      else if (keys.right) player.vx = 4.5;
      else player.vx *= 0.8;

      player.vy += gravity;
      player.x += player.vx;
      player.y += player.vy;
      player.onGround = false;

      // platform collision
      platforms.forEach(p => {
        if (player.x + player.w > p.x && player.x < p.x + p.w &&
            player.y + player.h > p.y && player.y + player.h < p.y + p.h + 12 &&
            player.vy >= 0) {
          player.y = p.y - player.h;
          player.vy = 0;
          player.onGround = true;
        }
      });

      if (keys.jump && player.onGround) {
        player.vy = -11;
        player.onGround = false;
      }

      // bounds
      if (player.x < 0) player.x = 0;
      if (player.x + player.w > W) player.x = W - player.w;
      if (player.y > H) {
        gameOver = true;
        document.getElementById('msg').textContent = 'Game Over! Toque para reiniciar';
      }

      // coins
      coins.forEach(c => {
        if (!c.collected && Math.hypot(player.x + player.w/2 - c.x, player.y + player.h/2 - c.y) < 20) {
          c.collected = true;
          score += 10;
          document.getElementById('score').textContent = score;
        }
      });
    }

    function draw() {
      ctx.clearRect(0, 0, W, H);
      // platforms
      ctx.fillStyle = '#3b82f6';
      platforms.forEach(p => {
        ctx.fillRect(p.x, p.y, p.w, p.h);
        ctx.fillStyle = '#8b5cf6';
        ctx.fillRect(p.x, p.y, p.w, 3);
        ctx.fillStyle = '#3b82f6';
      });
      // coins
      coins.forEach(c => {
        if (!c.collected) {
          ctx.beginPath();
          ctx.arc(c.x, c.y, c.r, 0, Math.PI * 2);
          ctx.fillStyle = '#fbbf24';
          ctx.fill();
        }
      });
      // player
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(player.x, player.y, player.w, player.h);
      ctx.fillStyle = '#fff';
      ctx.fillRect(player.x + 6, player.y + 6, 6, 6);
      ctx.fillRect(player.x + 16, player.y + 6, 6, 6);
    }

    function loop() {
      update();
      draw();
      requestAnimationFrame(loop);
    }

    function restart() {
      if (!gameOver) return;
      gameOver = false;
      score = 0;
      document.getElementById('score').textContent = 0;
      document.getElementById('msg').textContent = 'Toque para pular';
      player.x = 50;
      player.y = H - 100;
      player.vx = 0;
      player.vy = 0;
      initLevel();
    }

    // Controls
    document.getElementById('btnLeft').addEventListener('touchstart', e => { e.preventDefault(); keys.left = true; });
    document.getElementById('btnLeft').addEventListener('touchend', () => keys.left = false);
    document.getElementById('btnRight').addEventListener('touchstart', e => { e.preventDefault(); keys.right = true; });
    document.getElementById('btnRight').addEventListener('touchend', () => keys.right = false);
    document.getElementById('btnJump').addEventListener('touchstart', e => { e.preventDefault(); keys.jump = true; restart(); });
    document.getElementById('btnJump').addEventListener('touchend', () => keys.jump = false);

    window.addEventListener('keydown', e => {
      if (e.key === 'ArrowLeft' || e.key === 'a') keys.left = true;
      if (e.key === 'ArrowRight' || e.key === 'd') keys.right = true;
      if (e.key === 'ArrowUp' || e.key === ' ' || e.key === 'w') { keys.jump = true; restart(); }
    });
    window.addEventListener('keyup', e => {
      if (e.key === 'ArrowLeft' || e.key === 'a') keys.left = false;
      if (e.key === 'ArrowRight' || e.key === 'd') keys.right = false;
      if (e.key === 'ArrowUp' || e.key === ' ' || e.key === 'w') keys.jump = false;
    });

    canvas.addEventListener('click', restart);
    resize();
    window.addEventListener('resize', resize);
    loop();
  </script>
</body>
</html>`;
  },

  shooterTemplate(prompt) {
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>Space Shooter</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; touch-action:none; }
    body { background:#050510; overflow:hidden; height:100vh; display:flex; align-items:center; justify-content:center; }
    #ui { position:fixed; top:10px; left:10px; color:#0ff; font-family:monospace; font-size:18px; z-index:5; }
    canvas { border:2px solid #8b5cf6; max-width:100%; max-height:100%; }
  </style>
</head>
<body>
  <div id="ui">Score: <span id="score">0</span></div>
  <canvas id="c"></canvas>
  <script>
    const canvas = document.getElementById('c');
    const ctx = canvas.getContext('2d');
    let W, H, score = 0;
    const ship = { x: 0, y: 0, w: 30, h: 30 };
    let bullets = [], enemies = [], particles = [];
    let touchX = null, shooting = false, lastShot = 0;

    function resize() {
      W = canvas.width = Math.min(innerWidth, 360);
      H = canvas.height = Math.min(innerHeight * 0.85, 560);
      ship.x = W / 2 - 15;
      ship.y = H - 60;
    }

    function spawnEnemy() {
      enemies.push({ x: Math.random() * (W - 30), y: -30, w: 28, h: 28, speed: 1.5 + Math.random() * 2 });
    }

    function shoot() {
      if (Date.now() - lastShot < 180) return;
      bullets.push({ x: ship.x + 12, y: ship.y, speed: 9 });
      lastShot = Date.now();
    }

    function update() {
      if (touchX !== null) ship.x += (touchX - ship.x - 15) * 0.2;
      ship.x = Math.max(0, Math.min(W - ship.w, ship.x));
      if (shooting) shoot();

      bullets.forEach(b => b.y -= b.speed);
      bullets = bullets.filter(b => b.y > -10);

      if (Math.random() < 0.025) spawnEnemy();
      enemies.forEach(e => e.y += e.speed);

      // collisions
      enemies = enemies.filter(e => {
        for (let i = bullets.length - 1; i >= 0; i--) {
          const b = bullets[i];
          if (b.x > e.x && b.x < e.x + e.w && b.y > e.y && b.y < e.y + e.h) {
            bullets.splice(i, 1);
            score += 10;
            document.getElementById('score').textContent = score;
            for (let k = 0; k < 6; k++) particles.push({ x: e.x + 14, y: e.y + 14, vx: (Math.random()-0.5)*4, vy: (Math.random()-0.5)*4, life: 20 });
            return false;
          }
        }
        if (e.y > H) return false;
        if (e.x < ship.x + ship.w && e.x + e.w > ship.x && e.y < ship.y + ship.h && e.y + e.h > ship.y) {
          alert('Game Over! Score: ' + score);
          score = 0; enemies = []; bullets = []; document.getElementById('score').textContent = 0;
          return false;
        }
        return true;
      });

      particles.forEach(p => { p.x += p.vx; p.y += p.vy; p.life--; });
      particles = particles.filter(p => p.life > 0);
    }

    function draw() {
      ctx.fillStyle = '#050510';
      ctx.fillRect(0, 0, W, H);
      // stars
      ctx.fillStyle = '#fff';
      for (let i = 0; i < 40; i++) ctx.fillRect((i * 97) % W, (i * 53 + Date.now()/50) % H, 1, 1);

      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.moveTo(ship.x + 15, ship.y);
      ctx.lineTo(ship.x, ship.y + 30);
      ctx.lineTo(ship.x + 30, ship.y + 30);
      ctx.fill();

      ctx.fillStyle = '#fbbf24';
      bullets.forEach(b => ctx.fillRect(b.x, b.y, 4, 12));

      ctx.fillStyle = '#ef4444';
      enemies.forEach(e => ctx.fillRect(e.x, e.y, e.w, e.h));

      particles.forEach(p => {
        ctx.globalAlpha = p.life / 20;
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(p.x, p.y, 3, 3);
        ctx.globalAlpha = 1;
      });
    }

    function loop() { update(); draw(); requestAnimationFrame(loop); }

    canvas.addEventListener('touchstart', e => {
      e.preventDefault();
      touchX = (e.touches[0].clientX - canvas.getBoundingClientRect().left) * (W / canvas.clientWidth);
      shooting = true;
    });
    canvas.addEventListener('touchmove', e => {
      e.preventDefault();
      touchX = (e.touches[0].clientX - canvas.getBoundingClientRect().left) * (W / canvas.clientWidth);
    });
    canvas.addEventListener('touchend', () => { touchX = null; shooting = false; });

    resize();
    window.addEventListener('resize', resize);
    loop();
  </script>
</body>
</html>`;
  },

  runnerTemplate(prompt) {
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>Endless Runner</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; touch-action:none; }
    body { background:#0a0a12; height:100vh; display:flex; align-items:center; justify-content:center; overflow:hidden; }
    #ui { position:fixed; top:12px; left:12px; color:#0ff; font-family:monospace; font-size:18px; z-index:5; }
    canvas { border:2px solid #8b5cf6; max-width:100%; }
  </style>
</head>
<body>
  <div id="ui">Distância: <span id="score">0</span>m</div>
  <canvas id="c"></canvas>
  <script>
    const canvas = document.getElementById('c');
    const ctx = canvas.getContext('2d');
    let W, H, score = 0, speed = 4, gameOver = false;
    const player = { x: 60, y: 0, w: 30, h: 40, vy: 0, onGround: true };
    let obstacles = [], frame = 0;
    const gravity = 0.7;

    function resize() {
      W = canvas.width = Math.min(innerWidth, 400);
      H = canvas.height = Math.min(innerHeight * 0.7, 300);
      player.y = H - 70;
    }

    function update() {
      if (gameOver) return;
      frame++;
      score = Math.floor(frame / 5);
      document.getElementById('score').textContent = score;
      speed = 4 + score / 100;

      player.vy += gravity;
      player.y += player.vy;
      if (player.y >= H - 70) {
        player.y = H - 70;
        player.vy = 0;
        player.onGround = true;
      }

      if (frame % Math.max(40, 90 - score/10) === 0) {
        obstacles.push({ x: W + 20, y: H - 50, w: 24, h: 30 });
      }

      obstacles.forEach(o => o.x -= speed);
      obstacles = obstacles.filter(o => {
        if (o.x + o.w < 0) return false;
        if (player.x < o.x + o.w && player.x + player.w > o.x &&
            player.y < o.y + o.h && player.y + player.h > o.y) {
          gameOver = true;
          setTimeout(() => {
            alert('Game Over! Distância: ' + score + 'm');
            score = 0; frame = 0; obstacles = []; gameOver = false; speed = 4;
            document.getElementById('score').textContent = 0;
          }, 100);
          return false;
        }
        return true;
      });
    }

    function draw() {
      ctx.fillStyle = '#0a0a12';
      ctx.fillRect(0, 0, W, H);
      // ground
      ctx.fillStyle = '#1e1e2e';
      ctx.fillRect(0, H - 30, W, 30);
      ctx.fillStyle = '#8b5cf6';
      ctx.fillRect(0, H - 30, W, 3);

      // player
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(player.x, player.y, player.w, player.h);

      // obstacles
      ctx.fillStyle = '#ef4444';
      obstacles.forEach(o => ctx.fillRect(o.x, o.y, o.w, o.h));
    }

    function jump() {
      if (player.onGround && !gameOver) {
        player.vy = -12;
        player.onGround = false;
      }
    }

    function loop() { update(); draw(); requestAnimationFrame(loop); }

    canvas.addEventListener('touchstart', e => { e.preventDefault(); jump(); });
    canvas.addEventListener('click', jump);
    window.addEventListener('keydown', e => { if (e.key === ' ' || e.key === 'ArrowUp') jump(); });

    resize();
    window.addEventListener('resize', resize);
    loop();
  </script>
</body>
</html>`;
  },

  saveAsProject(name, code) {
    return Storage.addProject({
      name: name || 'Jogo ' + new Date().toLocaleDateString('pt-BR'),
      type: 'game',
      code,
      files: [{ name: 'index.html', content: code }]
    });
  }
};
