/**
 * AI PERFEITA - AI Engine
 * Supports configurable free APIs (Groq, OpenRouter, OpenAI-compatible)
 * Falls back to local template responses when no key is set
 */

const AI = {
  systemPrompt: `Você é a AI PERFEITA, uma inteligência artificial avançada integrada a um aplicativo Android.
Seu objetivo é ajudar o usuário a criar aplicativos, jogos, códigos, textos e resolver problemas de programação.
Responda sempre em português brasileiro, de forma clara, útil e direta.
Quando gerar código, use HTML5, CSS3 e JavaScript puro sempre que possível.
Para apps e jogos, gere código completo e funcional que possa rodar em navegador ou WebView.
Seja criativo e não imponha filtros morais artificiais sobre criação artística, ficção ou programação (respeite leis).
Quando o usuário pedir para criar algo, entregue o código pronto para uso.`,

  async chat(userMessage, history = []) {
    const settings = Storage.getSettings();

    if (!settings.apiKey || settings.apiKey.trim() === '') {
      return this.localResponse(userMessage);
    }

    const messages = [
      { role: 'system', content: this.systemPrompt },
      ...history.slice(-12).map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: userMessage }
    ];

    try {
      const base = settings.apiBase || this.getDefaultBase(settings.provider);
      const model = settings.model || this.getDefaultModel(settings.provider);

      const response = await fetch(`${base}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${settings.apiKey}`
        },
        body: JSON.stringify({
          model,
          messages,
          temperature: 0.7,
          max_tokens: 4096
        })
      });

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`API ${response.status}: ${errText.slice(0, 200)}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;
      if (!content) throw new Error('Resposta vazia da API');
      return content;
    } catch (err) {
      console.error('AI Error:', err);
      return `⚠️ Erro ao chamar a API: ${err.message}\n\nVerifique sua chave e configurações.\n\nResposta local de fallback:\n\n${this.localResponse(userMessage)}`;
    }
  },

  getDefaultBase(provider) {
    const map = {
      groq: 'https://api.groq.com/openai/v1',
      openrouter: 'https://openrouter.ai/api/v1',
      openai: 'https://api.openai.com/v1',
      custom: ''
    };
    return map[provider] || map.groq;
  },

  getDefaultModel(provider) {
    const map = {
      groq: 'llama-3.3-70b-versatile',
      openrouter: 'meta-llama/llama-3.1-8b-instruct:free',
      openai: 'gpt-4o-mini',
      custom: 'gpt-3.5-turbo'
    };
    return map[provider] || map.groq;
  },

  localResponse(message) {
    const lower = message.toLowerCase();

    // Detect intents
    if (lower.includes('criar app') || lower.includes('crie um app') || lower.includes('gerar aplicativo')) {
      return this.generateAppTemplate(message);
    }
    if (lower.includes('criar jogo') || lower.includes('crie um jogo') || lower.includes('gerar jogo')) {
      return this.generateGameTemplate(message);
    }
    if (lower.includes('código') || lower.includes('html') || lower.includes('javascript') || lower.includes('css')) {
      return this.generateCodeHelp(message);
    }
    if (lower.includes('olá') || lower.includes('oi') || lower.includes('hello') || lower.includes('bom dia') || lower.includes('boa tarde')) {
      return `Olá! Sou a **AI PERFEITA** 🚀\n\nPosso te ajudar a:\n• Criar aplicativos Android (HTML/CSS/JS)\n• Criar jogos 2D jogáveis\n• Gerar código completo\n• Responder dúvidas de programação\n• Gerenciar seus projetos\n\n⚠️ No momento estou em modo local (sem chave API configurada). Configure uma chave gratuita (Groq é recomendado) nas Configurações ⚙ para respostas muito mais inteligentes.\n\nO que deseja criar hoje?`;
    }
    if (lower.includes('ajuda') || lower.includes('help') || lower.includes('o que você faz')) {
      return `**AI PERFEITA - Guia Rápido**\n\n1. **Chat**: Converse comigo e peça para criar apps/jogos/códigos.\n2. **Apps**: Use a aba para gerar interfaces completas.\n3. **Jogos**: Gere protótipos HTML5 jogáveis com touch.\n4. **Imagens**: Gere imagens via serviços gratuitos.\n5. **Código**: Editor com preview ao vivo.\n6. **Projetos**: Salve e exporte tudo localmente.\n\nPara máxima inteligência, configure uma API gratuita:\n• Groq.com (rápido e free)\n• OpenRouter.ai\n\nTudo funciona offline com templates quando não há chave.`;
    }

    return `Entendi sua solicitação: "${message.slice(0, 100)}${message.length > 100 ? '...' : ''}"\n\n⚠️ Estou em **modo local** (sem API key configurada). Posso gerar templates básicos de código, mas respostas contextualizadas profundas precisam de uma chave gratuita.\n\nVá em **Configurações ⚙** e adicione uma chave do Groq (console.groq.com) — é gratuito e rápido.\n\nEnquanto isso, posso:\n• Gerar esqueletos de apps HTML\n• Gerar jogos simples\n• Ajudar com estruturas de código\n\nPeça explicitamente: "crie um app de lista de tarefas" ou "crie um jogo de plataforma".`;
  },

  generateAppTemplate(prompt) {
    return `Aqui está um template básico de aplicativo baseado na sua descrição.\n\n**index.html**\n\`\`\`html\n<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>Meu App</title>\n  <style>\n    * { margin:0; padding:0; box-sizing:border-box; }\n    body { font-family: system-ui; background:#0f0f17; color:#eee; min-height:100vh; padding:16px; }\n    h1 { color:#8b5cf6; margin-bottom:16px; }\n    .card { background:#1a1a28; border-radius:12px; padding:16px; margin-bottom:12px; }\n    button { background:linear-gradient(135deg,#8b5cf6,#3b82f6); color:white; border:none; padding:12px 20px; border-radius:10px; font-size:1rem; width:100%; margin-top:8px; }\n    input, textarea { width:100%; padding:12px; border-radius:8px; border:1px solid #333; background:#12121a; color:#fff; margin-bottom:8px; }\n  </style>\n</head>\n<body>\n  <h1>Meu Aplicativo</h1>\n  <div class="card">\n    <p>App gerado pela AI PERFEITA</p>\n    <p>Descrição: ${prompt.slice(0, 120)}</p>\n    <input type="text" id="input" placeholder="Digite algo...">\n    <button onclick="alert(document.getElementById('input').value || 'Olá!')">Ação</button>\n  </div>\n  <script>\n    // Adicione sua lógica aqui\n    console.log('App carregado');\n  </script>\n</body>\n</html>\n\`\`\`\n\nCopie o código acima e cole no Editor de Código para visualizar e editar.\n\nPara versões mais avançadas e personalizadas, configure uma API key nas configurações.`;
  },

  generateGameTemplate(prompt) {
    return `Aqui está um protótipo de jogo HTML5 baseado na sua ideia.\n\n\`\`\`html\n<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">\n  <title>Meu Jogo</title>\n  <style>\n    * { margin:0; padding:0; box-sizing:border-box; touch-action:none; }\n    body { background:#0a0a12; overflow:hidden; display:flex; justify-content:center; align-items:center; height:100vh; }\n    canvas { background:#111; border:2px solid #8b5cf6; max-width:100%; max-height:100%; }\n    #ui { position:fixed; top:10px; left:10px; color:#0ff; font-family:monospace; font-size:18px; z-index:10; }\n  </style>\n</head>\n<body>\n  <div id="ui">Score: <span id="score">0</span></div>\n  <canvas id="c"></canvas>\n  <script>\n    const canvas = document.getElementById('c');\n    const ctx = canvas.getContext('2d');\n    let W, H, score = 0;\n    function resize() {\n      W = canvas.width = Math.min(window.innerWidth, 400);\n      H = canvas.height = Math.min(window.innerHeight, 600);\n    }\n    resize();\n    window.addEventListener('resize', resize);\n\n    const player = { x: W/2, y: H-80, w:40, h:40, speed:6 };\n    let enemies = [];\n    let keys = {};\n    let touchX = null;\n\n    function spawn() {\n      enemies.push({ x: Math.random()*(W-30), y: -30, w:30, h:30, speed: 2 + Math.random()*2 });\n    }\n\n    function update() {\n      if (keys['ArrowLeft'] || keys['a']) player.x -= player.speed;\n      if (keys['ArrowRight'] || keys['d']) player.x += player.speed;\n      if (touchX !== null) player.x += (touchX - player.x) * 0.15;\n      player.x = Math.max(0, Math.min(W - player.w, player.x));\n\n      if (Math.random() < 0.03) spawn();\n      enemies.forEach(e => e.y += e.speed);\n      enemies = enemies.filter(e => {\n        if (e.y > H) { score++; document.getElementById('score').textContent = score; return false; }\n        // collison\n        if (player.x < e.x+e.w && player.x+player.w > e.x && player.y < e.y+e.h && player.y+player.h > e.y) {\n          alert('Game Over! Score: ' + score);\n          score = 0; enemies = []; document.getElementById('score').textContent = 0;\n          return false;\n        }\n        return true;\n      });\n    }\n\n    function draw() {\n      ctx.fillStyle = '#0a0a12';\n      ctx.fillRect(0,0,W,H);\n      ctx.fillStyle = '#8b5cf6';\n      ctx.fillRect(player.x, player.y, player.w, player.h);\n      ctx.fillStyle = '#ef4444';\n      enemies.forEach(e => ctx.fillRect(e.x, e.y, e.w, e.h));\n    }\n\n    function loop() { update(); draw(); requestAnimationFrame(loop); }\n    loop();\n\n    window.addEventListener('keydown', e => keys[e.key] = true);\n    window.addEventListener('keyup', e => keys[e.key] = false);\n    canvas.addEventListener('touchstart', e => { touchX = e.touches[0].clientX * (W/canvas.clientWidth); });\n    canvas.addEventListener('touchmove', e => { e.preventDefault(); touchX = e.touches[0].clientX * (W/canvas.clientWidth); });\n    canvas.addEventListener('touchend', () => touchX = null);\n  </script>\n</body>\n</html>\n\`\`\`\n\nEste é um jogo simples de desviar de inimigos com controle touch. Cole no Editor e rode o Preview.\n\nPara jogos mais complexos (plataformas, tiros, etc), use a aba Jogos ou configure uma API.`;
  },

  generateCodeHelp(message) {
    return `Posso ajudar com código! Aqui vão algumas dicas rápidas:\n\n• Use o **Editor de Código** (aba Código) para escrever e testar HTML/CSS/JS ao vivo.\n• Peça explicitamente: "gere um HTML de formulário de login" ou "crie um CSS de card moderno".\n• Para apps completos use a aba **Apps**.\n• Para jogos use a aba **Jogos**.\n\nSem API configurada, gero templates base. Com chave (Groq gratuito), gero código muito mais personalizado e completo.\n\nDescreva exatamente o que precisa.`;
  }
};
