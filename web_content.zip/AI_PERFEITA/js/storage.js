/**
 * AI PERFEITA - Local Storage Manager
 * Handles projects, chat history, settings
 */

const Storage = {
  KEYS: {
    SETTINGS: 'ai_perfecta_settings',
    PROJECTS: 'ai_perfecta_projects',
    CHAT_HISTORY: 'ai_perfecta_chat',
    CODE: 'ai_perfecta_code'
  },

  // Settings
  getSettings() {
    try {
      const data = localStorage.getItem(this.KEYS.SETTINGS);
      return data ? JSON.parse(data) : {
        provider: 'groq',
        apiKey: '',
        apiBase: 'https://api.groq.com/openai/v1',
        model: 'llama-3.3-70b-versatile'
      };
    } catch (e) {
      return { provider: 'groq', apiKey: '', apiBase: '', model: '' };
    }
  },

  saveSettings(settings) {
    localStorage.setItem(this.KEYS.SETTINGS, JSON.stringify(settings));
  },

  // Projects
  getProjects() {
    try {
      const data = localStorage.getItem(this.KEYS.PROJECTS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  saveProjects(projects) {
    localStorage.setItem(this.KEYS.PROJECTS, JSON.stringify(projects));
  },

  addProject(project) {
    const projects = this.getProjects();
    project.id = project.id || Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    project.createdAt = project.createdAt || new Date().toISOString();
    project.updatedAt = new Date().toISOString();
    projects.unshift(project);
    this.saveProjects(projects);
    return project;
  },

  updateProject(id, updates) {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => p.id === id);
    if (idx === -1) return null;
    projects[idx] = { ...projects[idx], ...updates, updatedAt: new Date().toISOString() };
    this.saveProjects(projects);
    return projects[idx];
  },

  deleteProject(id) {
    const projects = this.getProjects().filter(p => p.id !== id);
    this.saveProjects(projects);
  },

  duplicateProject(id) {
    const projects = this.getProjects();
    const original = projects.find(p => p.id === id);
    if (!original) return null;
    const copy = {
      ...JSON.parse(JSON.stringify(original)),
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      name: original.name + ' (cópia)',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    projects.unshift(copy);
    this.saveProjects(projects);
    return copy;
  },

  // Chat
  getChatHistory() {
    try {
      const data = localStorage.getItem(this.KEYS.CHAT_HISTORY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  saveChatHistory(messages) {
    // Keep last 100 messages
    const trimmed = messages.slice(-100);
    localStorage.setItem(this.KEYS.CHAT_HISTORY, JSON.stringify(trimmed));
  },

  clearChatHistory() {
    localStorage.removeItem(this.KEYS.CHAT_HISTORY);
  },

  // Code editor state
  getCodeState() {
    try {
      const data = localStorage.getItem(this.KEYS.CODE);
      return data ? JSON.parse(data) : { html: '', css: '', js: '', activeTab: 'html' };
    } catch (e) {
      return { html: '', css: '', js: '', activeTab: 'html' };
    }
  },

  saveCodeState(state) {
    localStorage.setItem(this.KEYS.CODE, JSON.stringify(state));
  },

  // Clear all
  clearAll() {
    Object.values(this.KEYS).forEach(k => localStorage.removeItem(k));
  },

  // Export project as downloadable files
  downloadFile(filename, content, mime = 'text/plain') {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  },

  downloadMultiple(files) {
    // Download one by one (browsers limit simultaneous)
    files.forEach((f, i) => {
      setTimeout(() => this.downloadFile(f.name, f.content, f.mime || 'text/plain'), i * 300);
    });
  }
};
