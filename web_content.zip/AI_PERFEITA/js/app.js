/**
 * AI PERFEITA - Main Application Logic
 */

const App = {
  currentView: 'chat',
  chatHistory: [],
  codeState: { html: '', css: '', js: '', activeTab: 'html' },

  init() {
    this.bindNav();
    this.bindChat();
    this.bindApps();
    this.bindGames();
    this.bindImages();
    this.bindVideos();
    this.bindEditor();
    this.bindProjects();
    this.bindSettings();
    this.loadChat();
    this.loadCode();
    this.renderProjects();
    this.showWelcome();
  },

  // Navigation
  bindNav() {
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.dataset.view;
        this.switchView(view);
      });
    });
  },

  switchView(view) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const el = document.getElementById('view-' + view);
    if (el) el.classList.add('active');
    const nav = document.querySelector(`.nav-item[data-view="${view}"]`);
    if (nav) nav.classList.add('active');
    this.currentView = view;

    if (view === 'projects') this.renderProjects();
    if (view === 'editor') this.syncEditor();
  },

  // Chat
  bindChat() {
    const input = document.getElementById('chat-input');
    const btn = document.getElementById('btn-send-chat');

    const send = async () => {
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      this.autoResize(input);
      this.addMessage('user', text);
      this.showLoading(true);

      try {
        const reply = await AI.chat(text, this.chatHistory);
        this.addMessage('assistant', reply);
      } catch (e) {
        this.addMessage('assistant', 'Erro: ' + e.message);
      } finally {
        this.showLoading(false);
      }
    };

    btn.addEventListener('click', send);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    });
    input.addEventListener('input', () => this.autoResize(input));
  },

  autoResize(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  },

  addMessage(role, content) {
    this.chatHistory.push({ role, content });
    Storage.saveChatHistory(this.chatHistory);

    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = `message ${role}`;

    // Simple markdown-like formatting
    let html = this.escapeHtml(content)
      .replace(/```(\w*)\n?([\s\S]*?)```/g, '<div class="code-block">$2</div>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>');

    div.innerHTML = html;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  },

  escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
  },

  loadChat() {
    this.chatHistory = Storage.getChatHistory();
    const container = document.getElementById('chat-messages');
    container.innerHTML = '';
    this.chatHistory.forEach(m => {
      const div = document.createElement('div');
      div.className = `message ${m.role}`;
      let html = this.escapeHtml(m.content)
        .replace(/```(\w*)\n?([\s\S]*?)```/g, '<div class="code-block">$2</div>')
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n/g, '<br>');
      div.innerHTML = html;
      container.appendChild(div);
    });
    if (this.chatHistory.length) container.scrollTop = container.scrollHeight;
  },

  showWelcome() {
    if (this.chatHistory.length === 0) {
      this.addMessage('assistant', `Olá! Eu sou a **AI PERFEITA** 🚀

Posso criar aplicativos, jogos, códigos e muito mais.

⚠️ Para respostas inteligentes, configure uma chave de API gratuita (Groq recomendado) em **Configurações ⚙**.

Sem chave, uso templates locais úteis.

O que você quer criar hoje?`);
    }
  },

  // Apps
  bindApps() {
    document.getElementById('btn-generate-app').addEventListener('click', async () => {
      const prompt = document.getElementById('app-prompt').value.trim();
      if (!prompt) return this.toast('Descreva o aplicativo primeiro', 'error');

      this.showLoading(true);
      try {
        const options = {
          includeCss: document.getElementById('app-include-css').checked,
          includeJs: document.getElementById('app-include-js').checked,
          responsive: document.getElementById('app-responsive').checked
        };
        const code = await Apps.generate(prompt, options);
        this.showAppResult(code, prompt);
      } catch (e) {
        this.toast('Erro: ' + e.message, 'error');
      } finally {
        this.showLoading(false);
      }
    });
  },

  showAppResult(code, prompt) {
    const area = document.getElementById('app-result');
    area.classList.remove('hidden');
    area.innerHTML = `
      <h3>Aplicativo Gerado</h3>
      <pre>${this.escapeHtml(code.slice(0, 2000))}${code.length > 2000 ? '\n\n... (código completo disponível ao salvar/exportar)' : ''}</pre>
      <div class="result-actions">
        <button class="btn-secondary" id="btn-app-editor">Abrir no Editor</button>
        <button class="btn-secondary" id="btn-app-save">Salvar Projeto</button>
        <button class="btn-secondary" id="btn-app-export">Exportar HTML</button>
        <button class="btn-primary" id="btn-app-preview">Preview</button>
      </div>
    `;

    document.getElementById('btn-app-editor').onclick = () => {
      this.codeState.html = code;
      this.codeState.css = '';
      this.codeState.js = '';
      Storage.saveCodeState(this.codeState);
      this.switchView('editor');
      this.syncEditor();
      this.toast('Código carregado no Editor');
    };

    document.getElementById('btn-app-save').onclick = () => {
      const name = prompt.slice(0, 40) || 'Meu App';
      Apps.saveAsProject(name, code);
      this.toast('Projeto salvo!', 'success');
      this.renderProjects();
    };

    document.getElementById('btn-app-export').onclick = () => {
      Storage.downloadFile('app-index.html', code, 'text/html');
      this.toast('Download iniciado');
    };

    document.getElementById('btn-app-preview').onclick = () => {
      this.codeState.html = code;
      this.switchView('editor');
      this.syncEditor();
      document.querySelector('.tab[data-lang="preview"]').click();
    };
  },

  // Games
  bindGames() {
    document.getElementById('btn-generate-game').addEventListener('click', async () => {
      const prompt = document.getElementById('game-prompt').value.trim();
      if (!prompt) return this.toast('Descreva o jogo primeiro', 'error');
      const type = document.getElementById('game-type').value;

      this.showLoading(true);
      try {
        const code = await Games.generate(prompt, type);
        this.showGameResult(code, prompt);
      } catch (e) {
        this.toast('Erro: ' + e.message, 'error');
      } finally {
        this.showLoading(false);
      }
    });
  },

  showGameResult(code, prompt) {
    const area = document.getElementById('game-result');
    area.classList.remove('hidden');
    area.innerHTML = `
      <h3>Jogo Gerado</h3>
      <pre>${this.escapeHtml(code.slice(0, 1500))}...</pre>
      <div class="result-actions">
        <button class="btn-secondary" id="btn-game-editor">Abrir no Editor</button>
        <button class="btn-secondary" id="btn-game-save">Salvar Projeto</button>
        <button class="btn-secondary" id="btn-game-export">Exportar</button>
        <button class="btn-primary" id="btn-game-play">▶ Jogar</button>
      </div>
    `;

    document.getElementById('btn-game-editor').onclick = () => {
      this.codeState.html = code;
      Storage.saveCodeState(this.codeState);
      this.switchView('editor');
      this.syncEditor();
    };

    document.getElementById('btn-game-save').onclick = () => {
      Games.saveAsProject(prompt.slice(0, 40) || 'Meu Jogo', code);
      this.toast('Jogo salvo!', 'success');
    };

    document.getElementById('btn-game-export').onclick = () => {
      Storage.downloadFile('game.html', code, 'text/html');
    };

    document.getElementById('btn-game-play').onclick = () => {
      this.codeState.html = code;
      this.switchView('editor');
      this.syncEditor();
      setTimeout(() => document.querySelector('.tab[data-lang="preview"]').click(), 100);
    };
  },

  // Images
  bindImages() {
    document.getElementById('btn-generate-image').addEventListener('click', async () => {
      const prompt = document.getElementById('image-prompt').value.trim();
      if (!prompt) return this.toast('Escreva um prompt', 'error');
      const style = document.getElementById('image-style').value;

      this.showLoading(true);
      const area = document.getElementById('image-result');
      area.classList.remove('hidden');
      area.innerHTML = '<p>Gerando imagem... isso pode levar alguns segundos.</p>';

      try {
        const result = await Images.generate(prompt, style);
        area.innerHTML = `
          <h3>Imagem Gerada</h3>
          <img src="${result.url}" class="generated-image" alt="Gerada">
          <p class="info-text">Prompt: ${this.escapeHtml(result.prompt)}</p>
          <div class="result-actions">
            <a class="btn-secondary" href="${result.url}" download="ai-perfecta-image.png" target="_blank">Abrir / Salvar</a>
          </div>
        `;
      } catch (e) {
        area.innerHTML = `<p style="color:var(--danger)">❌ ${this.escapeHtml(e.message)}</p>
          <p class="info-text">${Images.getInfo()}</p>`;
      } finally {
        this.showLoading(false);
      }
    });
  },

  // Videos
  bindVideos() {
    document.getElementById('btn-generate-video').addEventListener('click', async () => {
      const prompt = document.getElementById('video-prompt').value.trim();
      if (!prompt) return this.toast('Descreva o vídeo', 'error');
      const duration = document.getElementById('video-duration').value;
      const style = document.getElementById('video-style').value;

      this.showLoading(true);
      try {
        const result = await Videos.generate(prompt, duration, style);
        const area = document.getElementById('video-result');
        area.classList.remove('hidden');

        if (!result.success) {
          area.innerHTML = `
            <div style="white-space:pre-wrap;font-size:0.9rem;line-height:1.5">${this.escapeHtml(result.message)}</div>
            <div class="result-actions" style="margin-top:16px">
              <button class="btn-secondary" id="btn-storyboard">Gerar Storyboard</button>
              <button class="btn-secondary" id="btn-anim-proto">Protótipo Animado HTML</button>
            </div>
          `;
          document.getElementById('btn-storyboard').onclick = () => {
            const sb = Videos.generateStoryboard(prompt, duration, style);
            area.innerHTML = `<pre style="white-space:pre-wrap">${this.escapeHtml(sb)}</pre>
              <button class="btn-secondary" onclick="navigator.clipboard.writeText(\`${sb.replace(/`/g,"'")}\`)">Copiar</button>`;
          };
          document.getElementById('btn-anim-proto').onclick = () => {
            const html = Videos.generateAnimatedHTML(prompt);
            this.codeState.html = html;
            Storage.saveCodeState(this.codeState);
            this.switchView('editor');
            this.syncEditor();
            setTimeout(() => document.querySelector('.tab[data-lang="preview"]').click(), 100);
          };
        }
      } finally {
        this.showLoading(false);
      }
    });
  },

  // Code Editor
  bindEditor() {
    const editor = document.getElementById('code-editor');
    const tabs = document.querySelectorAll('.editor-tabs .tab');

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const lang = tab.dataset.lang;
        this.codeState.activeTab = lang;

        const preview = document.getElementById('preview-frame');
        if (lang === 'preview') {
          editor.classList.add('hidden');
          preview.classList.remove('hidden');
          this.runPreview();
        } else {
          editor.classList.remove('hidden');
          preview.classList.add('hidden');
          editor.value = this.codeState[lang] || '';
        }
        Storage.saveCodeState(this.codeState);
      });
    });

    editor.addEventListener('input', () => {
      const active = this.codeState.activeTab;
      if (active !== 'preview') {
        this.codeState[active] = editor.value;
        Storage.saveCodeState(this.codeState);
      }
    });

    document.getElementById('btn-copy-code').addEventListener('click', () => {
      const active = this.codeState.activeTab;
      const text = active === 'preview' ? this.buildFullHTML() : (this.codeState[active] || '');
      navigator.clipboard.writeText(text).then(() => this.toast('Copiado!')).catch(() => this.toast('Falha ao copiar', 'error'));
    });

    document.getElementById('btn-save-code').addEventListener('click', () => {
      Storage.saveCodeState(this.codeState);
      const project = Storage.addProject({
        name: 'Código ' + new Date().toLocaleString('pt-BR'),
        type: 'code',
        code: this.buildFullHTML(),
        files: [
          { name: 'index.html', content: this.codeState.html },
          { name: 'style.css', content: this.codeState.css },
          { name: 'script.js', content: this.codeState.js }
        ]
      });
      this.toast('Projeto salvo!', 'success');
    });

    document.getElementById('btn-export-code').addEventListener('click', () => {
      const full = this.buildFullHTML();
      Storage.downloadFile('projeto.html', full, 'text/html');
      this.toast('Exportado');
    });

    document.getElementById('btn-run-preview').addEventListener('click', () => {
      document.querySelector('.tab[data-lang="preview"]').click();
    });
  },

  syncEditor() {
    const editor = document.getElementById('code-editor');
    const active = this.codeState.activeTab || 'html';
    document.querySelectorAll('.editor-tabs .tab').forEach(t => {
      t.classList.toggle('active', t.dataset.lang === active);
    });
    if (active === 'preview') {
      editor.classList.add('hidden');
      document.getElementById('preview-frame').classList.remove('hidden');
      this.runPreview();
    } else {
      editor.classList.remove('hidden');
      document.getElementById('preview-frame').classList.add('hidden');
      editor.value = this.codeState[active] || '';
    }
  },

  loadCode() {
    this.codeState = Storage.getCodeState();
    this.syncEditor();
  },

  buildFullHTML() {
    const { html, css, js } = this.codeState;
    if (html.includes('<html') || html.includes('<!DOCTYPE')) {
      // Already full document
      return html;
    }
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Projeto AI PERFEITA</title>
  <style>${css || ''}</style>
</head>
<body>
${html || ''}
<script>${js || ''}<\/script>
</body>
</html>`;
  },

  runPreview() {
    const frame = document.getElementById('preview-frame');
    const content = this.buildFullHTML();
    frame.srcdoc = content;
  },

  // Projects
  bindProjects() {
    document.getElementById('btn-new-project').addEventListener('click', () => {
      const name = window.prompt('Nome do projeto:');
      if (!name) return;
      Storage.addProject({
        name,
        type: 'blank',
        code: '<!DOCTYPE html><html><body><h1>' + name + '</h1></body></html>',
        files: [{ name: 'index.html', content: '<!DOCTYPE html><html><body><h1>' + name + '</h1></body></html>' }]
      });
      this.renderProjects();
      this.toast('Projeto criado');
    });
  },

  renderProjects() {
    const list = document.getElementById('projects-list');
    const projects = Storage.getProjects();

    if (!projects.length) {
      list.innerHTML = `
        <div class="empty-state">
          <div class="icon">📁</div>
          <p>Nenhum projeto ainda</p>
          <p style="font-size:0.85rem;margin-top:8px">Crie apps, jogos ou salve códigos para vê-los aqui.</p>
        </div>`;
      return;
    }

    list.innerHTML = projects.map(p => `
      <div class="project-card" data-id="${p.id}">
        <h3>${this.escapeHtml(p.name)}</h3>
        <div class="meta">${p.type || 'projeto'} • ${new Date(p.updatedAt || p.createdAt).toLocaleString('pt-BR')}</div>
        <div class="project-actions">
          <button class="btn-secondary btn-open">Abrir</button>
          <button class="btn-secondary btn-export">Exportar</button>
          <button class="btn-secondary btn-dup">Duplicar</button>
          <button class="btn-secondary btn-del" style="color:var(--danger)">Excluir</button>
        </div>
      </div>
    `).join('');

    list.querySelectorAll('.project-card').forEach(card => {
      const id = card.dataset.id;
      card.querySelector('.btn-open').onclick = () => {
        const p = Storage.getProjects().find(x => x.id === id);
        if (!p) return;
        this.codeState.html = p.code || (p.files && p.files[0]?.content) || '';
        this.codeState.css = '';
        this.codeState.js = '';
        Storage.saveCodeState(this.codeState);
        this.switchView('editor');
        this.syncEditor();
        this.toast('Projeto aberto no Editor');
      };
      card.querySelector('.btn-export').onclick = () => {
        const p = Storage.getProjects().find(x => x.id === id);
        if (!p) return;
        Storage.downloadFile((p.name || 'projeto') + '.html', p.code || '', 'text/html');
      };
      card.querySelector('.btn-dup').onclick = () => {
        Storage.duplicateProject(id);
        this.renderProjects();
        this.toast('Duplicado');
      };
      card.querySelector('.btn-del').onclick = () => {
        if (confirm('Excluir este projeto?')) {
          Storage.deleteProject(id);
          this.renderProjects();
          this.toast('Excluído');
        }
      };
    });
  },

  // Settings
  bindSettings() {
    document.getElementById('btn-settings').addEventListener('click', () => {
      const s = Storage.getSettings();
      document.getElementById('ai-provider').value = s.provider || 'groq';
      document.getElementById('api-key').value = s.apiKey || '';
      document.getElementById('api-base').value = s.apiBase || '';
      document.getElementById('api-model').value = s.model || '';
      document.getElementById('settings-modal').classList.remove('hidden');
    });

    document.getElementById('btn-close-settings').addEventListener('click', () => {
      document.getElementById('settings-modal').classList.add('hidden');
    });

    document.getElementById('btn-save-settings').addEventListener('click', () => {
      const settings = {
        provider: document.getElementById('ai-provider').value,
        apiKey: document.getElementById('api-key').value.trim(),
        apiBase: document.getElementById('api-base').value.trim(),
        model: document.getElementById('api-model').value.trim()
      };
      // Auto-fill defaults
      if (!settings.apiBase) settings.apiBase = AI.getDefaultBase(settings.provider);
      if (!settings.model) settings.model = AI.getDefaultModel(settings.provider);
      Storage.saveSettings(settings);
      document.getElementById('settings-modal').classList.add('hidden');
      this.toast('Configurações salvas!', 'success');
    });

    document.getElementById('btn-clear-data').addEventListener('click', () => {
      if (confirm('Apagar TODOS os dados locais (projetos, chat, configurações)?')) {
        Storage.clearAll();
        this.chatHistory = [];
        document.getElementById('chat-messages').innerHTML = '';
        this.renderProjects();
        document.getElementById('settings-modal').classList.add('hidden');
        this.toast('Dados limpos');
        this.showWelcome();
      }
    });

    // Close modal on backdrop
    document.getElementById('settings-modal').addEventListener('click', e => {
      if (e.target.id === 'settings-modal') e.target.classList.add('hidden');
    });
  },

  // UI Helpers
  showLoading(show) {
    document.getElementById('loading').classList.toggle('hidden', !show);
  },

  toast(msg, type = '') {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.className = 'toast ' + type;
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => el.classList.add('hidden'), 2800);
  }
};

// Boot
document.addEventListener('DOMContentLoaded', () => App.init());
