/**
 * AI PERFEITA - Video Generator Module
 * Honest about limitations - free video gen APIs are rare and limited
 */

const Videos = {
  async generate(prompt, duration = 5, style = 'cinematic') {
    // Free video generation is extremely limited.
    // Most good services (Runway, Pika, Luma, Kling) require paid keys.
    // We do NOT fake results.

    const settings = Storage.getSettings();

    // Check if user has a custom endpoint that might support video (unlikely for free)
    // For now, provide clear guidance and a simple animated HTML "preview" alternative.

    return {
      success: false,
      message: `Geração de vídeo por IA ainda não possui APIs gratuitas estáveis e de qualidade acessíveis publicamente sem chave paga.

**Opções reais:**
• **Luma AI / Dream Machine** - tem plano gratuito limitado
• **RunwayML** - créditos free ocasionais
• **Pika Labs** - via Discord, limitado
• **Kling AI** - plano free limitado

**O que posso fazer agora:**
1. Gerar um **storyboard textual** detalhado do vídeo.
2. Gerar um **protótipo animado HTML/CSS/JS** simples baseado na descrição.
3. Você pode usar o Editor de Código para criar animações.

Deseja que eu gere um storyboard ou um protótipo animado HTML para: "${prompt.slice(0, 80)}"?`,
      prompt,
      duration,
      style
    };
  },

  generateStoryboard(prompt, duration, style) {
    return `# Storyboard - ${duration}s | Estilo: ${style}

**Prompt original:** ${prompt}

## Cena 1 (0-${Math.floor(duration/3)}s)
- Abertura: estabelecimento do cenário
- Elementos principais da descrição
- Movimento de câmera suave

## Cena 2 (${Math.floor(duration/3)}-${Math.floor(duration*2/3)}s)
- Ação principal
- Destaque dos elementos pedidos
- Transição dinâmica

## Cena 3 (${Math.floor(duration*2/3)}-${duration}s)
- Clímax / resolução visual
- Fechamento impactante
- Fade out ou efeito final

**Sugestão de áudio:** trilha ${style === 'cinematic' ? 'orquestral épica' : style === 'anime' ? 'eletrônica anime' : 'ambiente realista'}

Para gerar o vídeo real, use uma das plataformas listadas com o prompt completo acima.`;
  },

  // Simple animated HTML prototype
  generateAnimatedHTML(prompt) {
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Animação - ${prompt.slice(0,30)}</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { background:#0a0a12; height:100vh; display:flex; align-items:center; justify-content:center; overflow:hidden; font-family:system-ui; }
    .stage { width:min(90vw,400px); height:min(60vh,300px); background:linear-gradient(135deg,#1a1a2e,#0a0a12); border:2px solid #8b5cf6; border-radius:16px; position:relative; overflow:hidden; }
    .ball { width:40px; height:40px; background:radial-gradient(circle at 30% 30%,#06b6d4,#8b5cf6); border-radius:50%; position:absolute; bottom:20px; left:20px; animation:move 4s ease-in-out infinite alternate; box-shadow:0 0 20px #8b5cf6; }
    @keyframes move {
      0% { left:20px; bottom:20px; transform:scale(1); }
      50% { left:50%; bottom:60%; transform:scale(1.3); }
      100% { left:calc(100% - 60px); bottom:20px; transform:scale(1); }
    }
    .title { position:absolute; top:16px; left:0; right:0; text-align:center; color:#94a3b8; font-size:0.85rem; padding:0 12px; }
    .label { position:absolute; bottom:8px; left:0; right:0; text-align:center; color:#64748b; font-size:0.7rem; }
  </style>
</head>
<body>
  <div class="stage">
    <div class="title">${prompt.replace(/</g,'&lt;').slice(0,80)}</div>
    <div class="ball"></div>
    <div class="label">Protótipo animado • AI PERFEITA</div>
  </div>
</body>
</html>`;
  }
};
