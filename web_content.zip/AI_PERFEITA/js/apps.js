/**
 * AI PERFEITA - App Creator Module
 */

const Apps = {
  async generate(prompt, options = {}) {
    const { includeCss = true, includeJs = true, responsive = true } = options;

    const settings = Storage.getSettings();
    const hasApi = settings.apiKey && settings.apiKey.trim();

    if (hasApi) {
      const system = `Você é um gerador de aplicativos web mobile-first. 
Gere um aplicativo HTML completo e funcional baseado na descrição do usuário.
Regras:
- Um único arquivo HTML com CSS e JS embutidos (ou separados se pedido).
- Mobile-first, tema escuro moderno (preto, roxo, azul, ciano).
- Interface profissional, botões funcionais.
- Sem dependências externas.
- Código limpo e comentado.
- Retorne APENAS o código HTML completo, sem explicações antes ou depois.`;

      const userMsg = `Crie um aplicativo completo: ${prompt}
${includeCss ? 'Inclua CSS moderno.' : ''}
${includeJs ? 'Inclua JavaScript funcional.' : ''}
${responsive ? 'Totalmente responsivo para celular.' : ''}`;

      try {
        const result = await AI.chat(userMsg, [{ role: 'system', content: system }]);
        // Extract code if wrapped in markdown
        const codeMatch = result.match(/```html\n?([\s\S]*?)```/) || result.match(/```\n?([\s\S]*?)```/);
        return codeMatch ? codeMatch[1].trim() : result.trim();
      } catch (e) {
        console.error(e);
      }
    }

    // Local template fallback
    return this.localTemplate(prompt, options);
  },

  localTemplate(prompt, options) {
    const title = prompt.slice(0, 40).replace(/[<>]/g, '') || 'Meu App';
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>${title}</title>
  <style>
    :root {
      --bg: #0a0a0f;
      --card: #161622;
      --accent: #8b5cf6;
      --accent2: #06b6d4;
      --text: #f1f5f9;
      --muted: #94a3b8;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
      padding: 16px;
      padding-bottom: 80px;
    }
    header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 24px;
      padding-bottom: 12px;
      border-bottom: 1px solid #2a2a3a;
    }
    h1 {
      font-size: 1.4rem;
      background: linear-gradient(90deg, var(--accent), var(--accent2));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .card {
      background: var(--card);
      border-radius: 14px;
      padding: 16px;
      margin-bottom: 14px;
      border: 1px solid #2a2a3a;
    }
    .card h2 { font-size: 1.05rem; margin-bottom: 8px; color: var(--accent2); }
    .card p { color: var(--muted); font-size: 0.9rem; line-height: 1.45; }
    input, textarea, select {
      width: 100%;
      background: #12121a;
      border: 1px solid #2a2a3a;
      border-radius: 10px;
      padding: 12px 14px;
      color: var(--text);
      font-size: 1rem;
      margin-bottom: 10px;
      outline: none;
    }
    input:focus, textarea:focus { border-color: var(--accent); }
    button {
      background: linear-gradient(135deg, var(--accent), #3b82f6);
      color: white;
      border: none;
      border-radius: 12px;
      padding: 14px;
      font-size: 1rem;
      font-weight: 600;
      width: 100%;
      cursor: pointer;
      margin-top: 6px;
    }
    button:active { opacity: 0.9; transform: scale(0.98); }
    .list { list-style: none; }
    .list li {
      background: #1a1a28;
      padding: 12px 14px;
      border-radius: 10px;
      margin-bottom: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .list li button {
      width: auto;
      padding: 6px 12px;
      font-size: 0.8rem;
      background: #ef4444;
    }
    footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: #12121a;
      padding: 12px 16px;
      text-align: center;
      font-size: 0.75rem;
      color: var(--muted);
      border-top: 1px solid #2a2a3a;
    }
  </style>
</head>
<body>
  <header>
    <h1>${title}</h1>
  </header>

  <div class="card">
    <h2>Descrição</h2>
    <p>${prompt.replace(/</g, '&lt;').slice(0, 200)}</p>
  </div>

  <div class="card">
    <h2>Interação</h2>
    <input type="text" id="userInput" placeholder="Digite algo...">
    <button onclick="addItem()">Adicionar</button>
  </div>

  <div class="card">
    <h2>Itens</h2>
    <ul class="list" id="itemList"></ul>
  </div>

  <footer>Gerado por AI PERFEITA • Template local</footer>

  <script>
    const list = document.getElementById('itemList');
    const input = document.getElementById('userInput');
    let items = JSON.parse(localStorage.getItem('app_items') || '[]');

    function render() {
      list.innerHTML = items.map((item, i) =>
        \`<li><span>\${item}</span><button onclick="removeItem(\${i})">Remover</button></li>\`
      ).join('') || '<li style="color:#64748b">Nenhum item ainda</li>';
    }

    function addItem() {
      const val = input.value.trim();
      if (!val) return;
      items.push(val);
      localStorage.setItem('app_items', JSON.stringify(items));
      input.value = '';
      render();
    }

    function removeItem(i) {
      items.splice(i, 1);
      localStorage.setItem('app_items', JSON.stringify(items));
      render();
    }

    input.addEventListener('keydown', e => { if (e.key === 'Enter') addItem(); });
    render();
  </script>
</body>
</html>`;
  },

  saveAsProject(name, code) {
    return Storage.addProject({
      name: name || 'App ' + new Date().toLocaleDateString('pt-BR'),
      type: 'app',
      code,
      files: [{ name: 'index.html', content: code }]
    });
  }
};
