# AI PERFEITA

Aplicativo completo de Inteligência Artificial para criação de apps, jogos, códigos, imagens e mais.

Desenvolvido com **HTML5 + CSS3 + JavaScript puro**. Otimizado para Android (WebView / HTML to APK).

## Características

- 💬 **Chat com IA** — Conversação inteligente (Groq, OpenRouter ou qualquer API OpenAI-compatible)
- 📱 **Criador de Aplicativos** — Gera interfaces HTML/CSS/JS completas e funcionais
- 🎮 **Criador de Jogos** — Protótipos 2D jogáveis com controles touch (plataforma, tiro, runner...)
- 🖼 **Gerador de Imagens** — Via serviço gratuito (Pollinations)
- 🎬 **Criador de Vídeos** — Storyboard + protótipos animados (APIs de vídeo free são limitadas)
- 💻 **Editor de Código** — HTML / CSS / JS com preview ao vivo
- 📁 **Gerenciador de Projetos** — Salvar, exportar, duplicar, excluir (localStorage)
- 🌙 **Tema escuro futurista** — Preto, roxo, azul, ciano
- 📲 **Mobile-first** — Navegação inferior, gestos, safe areas

## Como usar no Android

1. Compacte a pasta `AI_PERFEITA` em ZIP **ou** copie todos os arquivos.
2. Use um conversor **HTML to APK** (ex: Website 2 APK Builder, HTML to APK, ou App Inventor com WebView).
3. Defina `index.html` como página inicial.
4. Ative permissões de Internet (para APIs e imagens).
5. Gere o APK e instale.

### Recomendado para WebView
- Habilite JavaScript
- Habilite armazenamento local / DOM Storage
- User Agent mobile
- Acesso à Internet

## Configuração da IA (recomendado)

1. Abra o app → toque no ícone ⚙
2. Escolha o provedor:
   - **Groq** (gratuito e rápido) → https://console.groq.com
   - **OpenRouter** → https://openrouter.ai
3. Cole a API Key
4. Salve

Sem chave a IA funciona em **modo local** com templates úteis de apps e jogos.

## Estrutura de arquivos

```
AI_PERFEITA/
├── index.html
├── css/
│   └── style.css
├── js/
│   ├── app.js
│   ├── ai.js
│   ├── apps.js
│   ├── games.js
│   ├── images.js
│   ├── videos.js
│   └── storage.js
├── assets/
│   ├── icons/
│   └── images/
├── manifest.json
└── README.md
```

## Recursos técnicos

- SPA (Single Page Application) — sem recarregar
- localStorage para tudo
- Sem frameworks / sem dependências externas obrigatórias
- Código organizado e comentado
- Tratamento de erros
- Exportação real de arquivos HTML

## Limitações honestas

- Geração de **vídeo** por IA ainda depende de serviços pagos ou com limites muito restritos. O app oferece storyboard e protótipos animados.
- Imagens usam endpoint público gratuito (pode ter rate limit ou indisponibilidade).
- Qualidade máxima da IA depende da chave configurada pelo usuário.

## Licença de uso

Projeto livre para uso pessoal e comercial. Crie o que quiser.

---

**AI PERFEITA** — Crie sem limites.
