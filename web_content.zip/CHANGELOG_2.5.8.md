# ANONYMOUX STUDIO 2.5.8 — Glass UI & Notification Experience

## Visual system
- Added a shared glassmorphism layer across authenticated workspace pages, Tools & Tutorials, admin views, sign-in, registration, onboarding and the Realtime Studio.
- Added stronger display typography, improved weight hierarchy, refined glass surfaces, borders, depth, and focus states.
- Preserved existing page layouts, forms, navigation and responsive breakpoints.

## Notifications
- Added a notification bell with unread count and a glass dropdown panel to authenticated workspace pages and Realtime Studio.
- Added 25-second polling of the existing per-user notifications API.
- Added floating toast notifications for newly received items, with safe text escaping and same-origin-safe navigation.
- Added a multi-tone bell sound using Web Audio API, a user-gesture audio unlock, and a persistent sound on/off control.
- Existing notifications on initial page load are shown in the panel without playing an intrusive sound.
- Added mark-one-read and mark-all-read actions using the existing CSRF-protected API.

## Browser behavior
- Browsers require a user interaction before audio playback; the sound engine unlocks on the first pointer, touch or keyboard interaction.
- If sound is disabled or browser audio is unavailable, visual floating notifications continue to work.
- Notification polling is limited to the current signed-in session and does not request browser push permissions.
