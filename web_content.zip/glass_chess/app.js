(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const game = new Chess();
  const glyph = {wk:"♔",wq:"♕",wr:"♖",wb:"♗",wn:"♘",wp:"♙",bk:"♚",bq:"♛",br:"♜",bb:"♝",bn:"♞",bp:"♟"};
  const files = "abcdefgh";
  let selected = null, legal = [], lastMove = null, rotate = false, pendingAction = null, soundOn = true, hintsOn = true, animationOn = true, toastTimer;
  const home=$("home"), gameScreen=$("game"), board=$("board");
  function toast(message){const t=$("toast");t.textContent=message;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),1800)}
  function beep(freq=440,duration=.07){if(!soundOn)return;try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const c=new C(),o=c.createOscillator(),g=c.createGain();o.frequency.value=freq;o.type="sine";g.gain.setValueAtTime(.035,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+duration);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+duration);o.onended=()=>c.close()}catch(e){}}
  function start(){home.classList.add("hidden");gameScreen.classList.remove("hidden");game.reset();selected=null;lastMove=null;rotate=false;render();beep(520,.1)}
  function backHome(){ $("resultOverlay").classList.add("hidden");gameScreen.classList.add("hidden");home.classList.remove("hidden");$("historyPanel").classList.add("hidden");}
  function pieceAt(square){return game.get(square)}
  function legalFor(square){return game.moves({square,verbose:true})}
  function render(){
    board.innerHTML="";
    const turn=game.turn(), orient=rotate;
    board.classList.toggle("rotated",orient);
    const ranks=orient?[1,2,3,4,5,6,7,8]:[8,7,6,5,4,3,2,1];
    const cols=orient?["h","g","f","e","d","c","b","a"]:["a","b","c","d","e","f","g","h"];
    const kingSquare=findKing(turn);
    ranks.forEach((rank,ri)=>cols.forEach((file,ci)=>{
      const sq=file+rank, p=pieceAt(sq), cell=document.createElement("button");
      cell.type="button";cell.className="square "+(((files.indexOf(file)+rank)%2===0)?"light":"dark");cell.dataset.square=sq;cell.setAttribute("aria-label",sq);
      if(lastMove&&(sq===lastMove.from||sq===lastMove.to))cell.classList.add("last");
      if(selected===sq)cell.classList.add("selected");
      if(kingSquare===sq&&game.in_check())cell.classList.add("check");
      if(p){const span=document.createElement("span");span.className="piece "+(p.color==="w"?"white":"black");span.textContent=glyph[p.color+p.type];cell.appendChild(span)}
      if(selected&&hintsOn&&legal.some(m=>m.to===sq)){const hint=document.createElement("i");hint.className=p?"legal-capture":"legal-dot";cell.appendChild(hint)}
      cell.addEventListener("click",()=>tapSquare(sq));board.appendChild(cell);
    }));
    const whiteTurn=turn==="w";
    $("topName").textContent=whiteTurn?"سیاه":"سفید";$("bottomName").textContent=whiteTurn?"سفید":"سیاه";
    $("topStatus").textContent=whiteTurn?"منتظر نوبت":"نوبت شما";$("bottomStatus").textContent=whiteTurn?"نوبت شما":"منتظر نوبت";
    $("topDot").classList.toggle("active",!whiteTurn);$("bottomDot").classList.toggle("active",whiteTurn);
    if(game.in_check())toast("کیش!");
    renderCoordinates();
    renderHistory();
  }
  function findKing(color){const b=game.board();for(let r=0;r<8;r++)for(let c=0;c<8;c++){const p=b[r][c];if(p&&p.type==="k"&&p.color===color)return files[c]+(8-r)}return null}
  function renderCoordinates(){const el=$("coordinates");el.innerHTML="";el.classList.toggle("hidden",!$("coordToggle").checked);const rows=rotate?[1,2,3,4,5,6,7,8]:[8,7,6,5,4,3,2,1],cols=rotate?["h","g","f","e","d","c","b","a"]:["a","b","c","d","e","f","g","h"];rows.forEach((r,i)=>{cols.forEach((f,j)=>{const s=document.createElement("span");s.textContent=(j===0?r:"")+(i===7?f:"");el.appendChild(s)})})}
  function tapSquare(sq){
    if(game.game_over())return;
    const p=pieceAt(sq);
    if(selected){
      if(sq===selected){selected=null;legal=[];render();return}
      const possible=legal.find(m=>m.to===sq);
      if(possible){
        if(possible.flags.includes("p")){showPromotion(sq);return}
        makeMove(selected,sq);return;
      }
      if(p&&p.color===game.turn()){selected=sq;legal=legalFor(sq);beep(620,.045);render();return}
      selected=null;legal=[];render();return;
    }
    if(p&&p.color===game.turn()){selected=sq;legal=legalFor(sq);beep(620,.045);render()}
  }
  function showPromotion(to){const color=game.turn(),opts=["q","r","b","n"],box=$("promotionOptions");box.innerHTML="";opts.forEach(t=>{const b=document.createElement("button");b.textContent=glyph[color+t];b.addEventListener("click",()=>{$("promotionOverlay").classList.add("hidden");makeMove(selected,to,t)});box.appendChild(b)});$("promotionOverlay").classList.remove("hidden")}
  function makeMove(from,to,promotion){const result=game.move({from,to,promotion:promotion||"q"});if(!result){toast("این حرکت مجاز نیست");return}lastMove={from,to};selected=null;legal=[];beep(result.captured?260:390,.08);rotate=$("rotateToggle").checked&&game.turn()==="b";render();if(game.in_checkmate()){finish((game.turn()==="w"?"سیاه":"سفید")+" برنده شد","کیش‌ومات");return}if(game.in_stalemate()){finish("بازی مساوی شد","پات");return}if(game.in_threefold_repetition()){finish("بازی مساوی شد","تکرار سه‌باره موقعیت");return}if(game.insufficient_material()){finish("بازی مساوی شد","مهره کافی برای مات وجود ندارد");return}if(game.in_draw()){finish("بازی مساوی شد","قانون ۵۰ حرکت یا وضعیت مساوی");return}if(game.in_check())beep(740,.13)}
  function finish(title,reason){$("resultTitle").textContent=title;$("resultReason").textContent=reason;$("resultSymbol").textContent=title.includes("سفید")?"♔":title.includes("سیاه")?"♚":"＝";$("resultOverlay").classList.remove("hidden")}
  function renderHistory(){const list=$("moveHistory");if(!list)return;list.innerHTML="";const hist=game.history();for(let i=0;i<hist.length;i+=2){const li=document.createElement("li");li.textContent=(Math.floor(i/2)+1)+". "+hist[i]+(hist[i+1]?"   "+hist[i+1]:"");list.appendChild(li)}}
  function ask(action,title,txt){pendingAction=action;$("confirmTitle").textContent=title;$("confirmText").textContent=txt;$("confirmOverlay").classList.remove("hidden")}
  $("startGame").addEventListener("click",start);
  $("openSettings").addEventListener("click",()=>$("settingsOverlay").classList.remove("hidden"));
  $("gameSettings").addEventListener("click",()=>$("settingsOverlay").classList.remove("hidden"));
  document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>$(b.dataset.close).classList.add("hidden")));
  $("resign").addEventListener("click",()=>ask("resign","تأیید انصراف","با انصراف، بازی به نفع حریف تمام می‌شود."));
  $("newGame").addEventListener("click",()=>ask("restart","شروع مجدد","بازی فعلی از ابتدا شروع شود؟"));
  $("cancelConfirm").addEventListener("click",()=>$("confirmOverlay").classList.add("hidden"));
  $("acceptConfirm").addEventListener("click",()=>{$("confirmOverlay").classList.add("hidden");if(pendingAction==="resign"){finish((game.turn()==="w"?"سیاه":"سفید")+" برنده شد","انصراف حریف")}else if(pendingAction==="restart"){game.reset();selected=null;lastMove=null;rotate=false;$("resultOverlay").classList.add("hidden");render()}pendingAction=null});
  $("undo").addEventListener("click",()=>{const m=game.undo();if(!m){toast("حرکتی برای برگشت وجود ندارد");return}lastMove=null;selected=null;legal=[];rotate=$("rotateToggle").checked&&game.turn()==="b";render();beep(320,.06)});
  $("historyToggle").addEventListener("click",()=>$("historyPanel").classList.toggle("hidden"));
  $("closeHistory").addEventListener("click",()=>$("historyPanel").classList.add("hidden"));
  $("playAgain").addEventListener("click",()=>{$("resultOverlay").classList.add("hidden");game.reset();selected=null;lastMove=null;rotate=false;render()});
  $("backHome").addEventListener("click",backHome);
  $("soundToggle").addEventListener("change",e=>soundOn=e.target.checked);
  $("hintToggle").addEventListener("change",e=>{hintsOn=e.target.checked;render()});
  $("animationToggle").addEventListener("change",e=>{animationOn=e.target.checked;board.style.transition=animationOn?"":"none"});
  $("coordToggle").addEventListener("change",renderCoordinates);
  $("rotateToggle").addEventListener("change",e=>{rotate=e.target.checked&&game.turn()==="b";render()});
  $("backgroundSelect").addEventListener("change",e=>{document.body.classList.remove("midnight","slate");if(e.target.value!=="dark")document.body.classList.add(e.target.value)});
  $("languageSelect").addEventListener("change",e=>{if(e.target.value==="en")toast("English interface is planned for the next version.");else toast("زبان فارسی فعال است")});
  render();
})();