MI INVENTARIO - PROYECTO ANDROID

Este proyecto convierte la app web Mi Inventario IA en una app Android instalable.
La información del inventario queda guardada localmente en el teléfono.

Para generar el APK:
1. Abrir esta carpeta en Android Studio.
2. Esperar a que Gradle sincronice.
3. Build > Build APK(s).
4. Instalar el APK generado en el teléfono.

La app solicita permiso de cámara para el lector de códigos. La lectura automática depende de
las capacidades del WebView del teléfono; si no funciona, la app web conserva el ingreso manual.

No contiene publicidad.
