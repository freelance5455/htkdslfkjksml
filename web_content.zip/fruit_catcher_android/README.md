# Fruit Catcher — Android starter project

Game 2D kasual offline. Source game berada di `www/index.html`.

## Cara menjalankan di komputer
1. Install Node.js LTS dan Android Studio.
2. Ekstrak folder project.
3. Buka terminal di folder `fruit_catcher_android`.
4. Jalankan:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
5. Di Android Studio, tunggu Gradle selesai lalu pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya berada di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Fitur versi 1.0
- Game offline, tanpa akun/server.
- Kontrol sentuh/geser.
- Buah acak, bom, skor, 3 nyawa.
- Kesulitan meningkat seiring waktu.
- Pause/resume/restart.
- Efek suara sederhana dan opsi mute.
- Skor tertinggi disimpan lokal di perangkat.

## Catatan
Project ini adalah source awal berbasis HTML5 yang dikemas dengan Capacitor. APK belum dibangun di sini; proses build Android membutuhkan Node.js, Android Studio, dan Android SDK pada komputer.
