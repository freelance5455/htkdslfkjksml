# Nova — AI Coding Agent

A mobile-first, browser-based AI coding agent. You talk to it in plain language
(English, Hindi or Hinglish); when you ask for something to be built or changed it
switches itself into coding mode, writes **real files** into a real project
workspace, validates them, and opens a live preview.

No build step. No framework. No npm install for the app itself. Open `index.html`
and it runs.

---

## 1. What you need

| Thing | Required? | Where to get it |
|---|---|---|
| **A modern browser** | Yes | Chrome, Edge, Safari 16+, Firefox 115+ |
| **Gemini API key** | Yes — for AI features | https://aistudio.google.com/apikey (free tier available) |
| **Web server** | Recommended | Any static server — see §3 |
| **Publishing token** | Optional | Netlify or GitHub, see §6 |
| **Node.js 18+** | Optional | Only for `server/proxy.js` (Cloudflare / Vercel publishing) |

You never edit a config file. Every key and setting is entered inside the app and
is stored in `localStorage` in your own browser.

---

## 2. Folder structure

```
ai-coding-agent/
├── index.html          App shell, onboarding, views
├── styles.css          Full design system (3 themes, mobile-first)
├── README.md
├── js/
│   ├── app.js          UI controller — wires every module
│   ├── store.js        localStorage persistence (settings, projects, chat)
│   ├── gemini.js       Gemini API client (retry, backoff, model fallback, SSE)
│   ├── agent.js        Agent brain: intent, prompts, ops, validation, repair
│   ├── preview.js      Sandbox preview + dependency-free ZIP writer
│   ├── voice.js        Speech recognition + speech synthesis
│   └── deploy.js       Publishing: Netlify, GitHub Pages, proxy providers
└── server/
    └── proxy.js        Optional Node proxy for Cloudflare Pages / Vercel
```

Module graph — `index.html` loads exactly one script, `js/app.js`, which imports
the other six. There are no unresolved imports and no CDN dependencies.

---

## 3. Run it

**Option A — open the file directly**

Double-click `index.html`. Everything works except two browser restrictions:
ES modules load fine over `file://` in Chrome/Edge/Firefox, but Safari blocks
module loading from `file://`, and microphone input needs a secure context.

**Option B — a local static server (recommended)**

```bash
cd ai-coding-agent
python3 -m http.server 5173
# open http://localhost:5173
```

or

```bash
npx serve -l 5173 .
# or
npx http-server -p 5173
```

`http://localhost` counts as a secure context, so the microphone works.

**Option C — host it**

Drop the whole folder on any static host (Netlify, GitHub Pages, Cloudflare
Pages, Vercel, S3). There is no server-side code in the app itself.

---

## 4. First run

1. The onboarding screen asks for your **Gemini API key**. Paste it and press
   **Test key** — the app calls `ListModels` with your key and fills the model
   dropdown with exactly the models your key can use. Nothing is hard-coded.
2. Pick a **model**. Anything coding-capable works; `gemini-2.5-pro` is the
   strongest, `gemini-2.5-flash` is the fast default.
3. Give the assistant a **name** (default *Nova*) and choose whether to enable
   voice output. Then press **Start building**.

You can change or remove the key at any time in **Settings → Assistant**.
Removing it leaves every project intact.

---

## 5. Using it

Type or speak a request. Examples that work:

- "Build me a restaurant booking website."
- "Create a modern portfolio site."
- "Make an Android-style calculator app."
- "मेरे लिए एक restaurant booking website बना दो"
- "Change the hero background to a gradient."
- "The contact form does not validate — fix it."
- "Add a pricing section."

**How the agent decides what to do.** A local intent detector looks for build
verbs and build nouns, in English, romanised Hinglish and Devanagari. If it sees
a build signal it enters coding mode automatically — you never toggle a switch.
Greetings, questions and thanks stay in conversation mode. If the detector is
unsure, the model itself returns an explicit mode in its response.

**In coding mode the agent will:**

1. Analyse the request and read only the project files relevant to it.
2. Return one JSON object containing a short natural message plus file operations.
3. Apply those operations to the workspace — create, modify, delete, rename.
4. Validate the result: broken asset references, unbalanced CSS braces,
   JavaScript syntax errors, unclosed tags, missing viewport meta.
5. If validation finds hard errors and **Auto repair** is on, send the findings
   back and apply the fix automatically.
6. Render the preview into the sandboxed iframe.
7. Tell you what it did, in one or two sentences, like a person.

The **AI Coding Agent** card in the chat shows each of those stages as it
happens. Each step on that card corresponds to a real operation that has already
completed — nothing is animated ahead of the work.

**Files tab** — browse, edit, save (`⌘/Ctrl+S`), rename, delete, add files, or
download the whole project as a ZIP.

**Preview tab** — Mobile / Tablet / Desktop viewports, refresh, open in a new
tab, a live **Console** fed by the preview's own `console.*` calls and runtime
errors, and the Publish button.

**Projects tab** — every project you have built, with its file count, summary
and last update. Switching projects makes the agent edit that one.

---

## 6. Publishing

Settings → Publishing. Pick a provider and paste a token. Tokens stay in your
browser and are sent only to the provider you selected.

| Provider | Works from the browser? | What you need |
|---|---|---|
| **Netlify** | Yes | A personal access token (app.netlify.com → User settings → Applications). The site is found or created for you. |
| **GitHub Pages** | Yes | A token with `repo` scope (classic) or Contents + Pages write (fine-grained), plus owner and repo name. |
| **Cloudflare Pages** | No — needs the proxy | API token + account ID, and `server/proxy.js` running. |
| **Vercel** | No — needs the proxy | Access token, and `server/proxy.js` running. |

Cloudflare and Vercel reject cross-origin browser requests, so the app will not
pretend to deploy to them. Press Publish and it tells you to start the proxy.

**The proxy:**

```bash
cd ai-coding-agent
node server/proxy.js
# Nova publishing proxy listening on http://127.0.0.1:8787
```

Put `http://localhost:8787` into Settings → Publishing → Proxy URL, press
**Test proxy**, then Publish. Environment variables: `PORT` (default 8787) and
`BIND` (default `127.0.0.1` — set `BIND=0.0.0.0` only if you understand the
exposure).

If no provider is configured, Publish shows **Connect a publishing provider**
instead of a fake success.

---

## 7. Voice

**Input** uses the Web Speech API. Tap the microphone, speak, and the
transcript is sent. Works well on Chrome for Android with
`en-IN` / `hi-IN`. Firefox has no `SpeechRecognition`; the mic button explains
that and you type instead.

**Output** uses `speechSynthesis`. Choose a voice and a speaking rate in
Settings → Voice. The app picks a natural-sounding voice for the reply language
when one exists. Startup phrases are never spoken — only actual replies. Code
blocks are stripped before speaking. **Text is always on screen regardless.**

---

## 8. Security notes

- Keys and tokens live in `localStorage` of your browser. They are never sent
  anywhere except the API you configured.
- Nothing is hard-coded, and no key is bundled in the source.
- The preview iframe is sandboxed with `allow-scripts` and no `allow-same-origin`,
  so generated code cannot read your keys or your page.
- Preview navigation to external URLs is blocked and logged in the Console.
- For a multi-user deployment, put the key behind a server-side proxy instead of
  letting each browser hold it.

---

## 9. Honest limitations

- **The preview is a sandbox, not a localhost server.** A browser page cannot
  open a listening socket, so previews are a real render of your real files
  assembled into one document and served to a sandboxed iframe. The UI labels it
  as a sandbox and never claims a dev server is running.
- **Cloudflare Pages and Vercel need the proxy.** See §6.
- **GitHub Pages takes up to a minute** to go live after the first deploy.
- **Validation is static.** It catches broken references, brace balance, JS
  syntax, unclosed tags and missing viewport meta. It does not run a DOM.
- **Generated frameworks** (React, Next.js) are written as real source files and
  shown in the Files tab, but the preview renders static HTML/CSS/JS. There is no
  bundler in the browser.
- **Speech recognition needs a network connection** — the browser sends audio to
  its own service. It does not work offline.

---

## 10. Keyboard shortcuts

| Shortcut | Action |
|---|---|
| `Enter` | Send |
| `Shift`+`Enter` | New line |
| `⌘/Ctrl`+`K` | Focus the composer |
| `⌘/Ctrl`+`S` | Save the open file |
| `Tab` in the editor | Insert two spaces |
| `Esc` | Close the sidebar |

---

## 11. Troubleshooting

**"That API key was rejected."** Check the key at aistudio.google.com. A `403`
usually means the Generative Language API is not enabled for its Google Cloud
project.

**"The model is temporarily overloaded. Retrying."** This is normal on the free
tier. The client backs off exponentially, honours `Retry-After`, and switches to
another model your key exposes before it gives up.

**Nothing happens when I press send.** Check the connection dot in the top bar.
Red means the key was rejected; the exact message appears in the chat.

**The preview is blank.** Open the Console panel in the Preview tab — a missing
asset or a runtime error will be listed there.

**Speech input does nothing.** The browser needs a secure context: use
`localhost` or HTTPS, not `file://`. Firefox does not support it at all.

**Browser storage is full.** Each project is capped by your browser's
localStorage quota (typically 5 MB). Delete an old project or export it as a zip.
