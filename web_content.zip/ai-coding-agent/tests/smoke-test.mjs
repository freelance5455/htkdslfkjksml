/* =========================================================
   smoke-test.mjs — headless verification of the pure modules.
   Run:  node tests/smoke-test.mjs
   ---------------------------------------------------------
   app.js / voice.js are DOM-coupled and are exercised in the
   browser instead; this covers the logic that must be right:
   intent detection, JSON repair, operation application,
   validation, path resolution, ZIP structure and slugging.
   ========================================================= */

import assert from 'node:assert/strict';

/* ---------- 1. intent detection (mirrors agent.js) ---------- */
const BUILD_VERBS = ['build','create','make','generate','develop','design','code','implement','add','fix','repair','debug','change','modify','edit','update','remove','delete','redesign','rewrite','bana','banao','bana do','banade','badal','badlo','ठीक','बनाओ','बदलो'];
const BUILD_NOUNS = ['website','site','page','landing','app','application','ui','component','form','button','navbar','hero','dashboard','portfolio','calculator','project','login','वेबसाइट','ऐप'];
const CHAT_ONLY = [
  /^(hi|hey|hello|yo|namaste)\b/i,
  /^(thanks|thank you|thx|shukriya)\b/i,
  /^(how are you|kaise ho|what'?s up)\b/i,
  /^(who are you|what can you do)\b/i,
  /^(explain|what is|what's|why|how does|tell me about|samjhao)\b/i,
];

function detectIntent(text, project) {
  const t = (text || '').trim();
  if (!t) return { mode: 'chat' };
  const low = t.toLowerCase();
  for (const re of CHAT_ONLY) {
    if (re.test(low)) {
      const hasBuild = BUILD_VERBS.some(v => low.includes(v)) && BUILD_NOUNS.some(n => low.includes(n));
      if (!hasBuild) return { mode: 'chat' };
    }
  }
  const verbHit = BUILD_VERBS.find(v => new RegExp(`(^|[^a-z])${v}`, 'i').test(low));
  const nounHit = BUILD_NOUNS.find(n => low.includes(n));
  const hasProject = !!project && Object.keys(project.files || {}).length > 0;
  const pronounEdit = hasProject && /\b(it|this|that|the|isko|ise)\b/i.test(low) && !!verbHit;
  if (verbHit && (nounHit || pronounEdit)) return { mode: hasProject ? 'modify' : 'build' };
  return { mode: 'chat' };
}

const emptyProject = { files: {} };
const openProject = { files: { 'index.html': { content: '<html></html>' } } };

const intentCases = [
  ['Build me a restaurant booking website.', emptyProject, 'build'],
  ['Create a modern portfolio website.', emptyProject, 'build'],
  ['Make me an Android-style calculator app.', emptyProject, 'build'],
  ['बनाओ एक वेबसाइट', emptyProject, 'build'],
  ['restaurant booking website bana do', emptyProject, 'build'],
  ['Add a contact form.', openProject, 'modify'],
  ['Change the button color.', openProject, 'modify'],
  ['Fix the login page.', openProject, 'modify'],
  ['hi', emptyProject, 'chat'],
  ['thanks!', emptyProject, 'chat'],
  ['what is a closure?', emptyProject, 'chat'],
  ['explain CSS grid', emptyProject, 'chat'],
  ['kaise ho', emptyProject, 'chat'],
];

let pass = 0, fail = 0;
for (const [text, project, expected] of intentCases) {
  const got = detectIntent(text, project).mode;
  try {
    assert.equal(got, expected);
    pass++; console.log(`  ✓ intent  "${text}" → ${got}`);
  } catch {
    fail++; console.log(`  ✗ intent  "${text}" → got ${got}, expected ${expected}`);
  }
}

/* ---------- 2. JSON extraction / repair (mirrors agent.js) ---------- */
function extractJson(raw) {
  if (!raw) return null;
  let s = raw.trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  try { return JSON.parse(s); } catch {}
  const start = s.indexOf('{');
  if (start === -1) return null;
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (esc) { esc = false; continue; }
    if (c === '\\') { esc = true; continue; }
    if (c === '"') { inStr = !inStr; continue; }
    if (inStr) continue;
    if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) { try { return JSON.parse(s.slice(start, i + 1)); } catch { break; } } }
  }
  try {
    const fixed = s.slice(start).replace(/"(?:[^"\\]|\\.)*"/gs, m => m.replace(/\n/g, '\\n').replace(/\r/g, ''));
    return JSON.parse(fixed);
  } catch { return null; }
}

const jsonCases = [
  ['plain',                       '{"message":"ok","operations":[]}'],
  ['fenced',                      '```json\n{"message":"ok","operations":[]}\n```'],
  ['preamble + object',           'Sure, here you go:\n{"message":"ok","operations":[]}'],
  ['trailing prose',              '{"message":"ok","operations":[]}\nHope that helps!'],
  ['raw newline in string',       '{"message":"line one\nline two","operations":[]}'],
  ['nested braces in content',    '{"message":"ok","operations":[{"type":"write_file","path":"a.js","content":"function f(){ return {a:1}; }"}]}'],
];

for (const [label, raw] of jsonCases) {
  const parsed = extractJson(raw);
  try {
    assert.ok(parsed && typeof parsed.message === 'string', `failed: ${label}`);
    pass++; console.log(`  ✓ json    ${label}`);
  } catch (e) {
    fail++; console.log(`  ✗ json    ${label} — ${e.message}`);
  }
}

/* ---------- 3. operation application + validation ---------- */
function applyOps(files, ops) {
  const applied = [], errors = []; let previewEntry = null;
  for (const op of ops) {
    if (op.type === 'write_file') {
      const existed = Object.prototype.hasOwnProperty.call(files, op.path);
      files[op.path] = { content: op.content, updatedAt: Date.now() };
      applied.push({ kind: existed ? 'mod' : 'new', path: op.path });
    } else if (op.type === 'apply_patch') {
      const f = files[op.path];
      if (!f) { errors.push({ path: op.path, message: 'missing' }); continue; }
      if (!f.content.includes(op.find)) { errors.push({ path: op.path, message: 'find not present' }); continue; }
      f.content = f.content.replace(op.find, op.replace ?? '');
      applied.push({ kind: 'mod', path: op.path });
    } else if (op.type === 'delete_file') {
      delete files[op.path]; applied.push({ kind: 'del', path: op.path });
    } else if (op.type === 'rename_file') {
      files[op.newPath] = files[op.path]; delete files[op.path];
      applied.push({ kind: 'mod', path: `${op.path} → ${op.newPath}` });
    } else if (op.type === 'run_preview') {
      previewEntry = op.entry || 'index.html';
    }
  }
  return { applied, errors, previewEntry };
}

const files = {};
const res = applyOps(files, [
  { type: 'write_file', path: 'index.html', content: '<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width"><link href="styles.css" rel="stylesheet"></head><body><h1>Hi</h1><script src="script.js"></script></body></html>' },
  { type: 'write_file', path: 'styles.css', content: 'body { color: red; }' },
  { type: 'write_file', path: 'script.js', content: 'console.log("ok");' },
  { type: 'run_preview', entry: 'index.html' },
]);

try {
  assert.equal(res.applied.length, 3, 'three files written');
  assert.equal(res.previewEntry, 'index.html');
  assert.deepEqual(res.errors, []);
  pass++; console.log('  ✓ ops     3 files written + preview entry recorded');
} catch (e) { fail++; console.log(`  ✗ ops     ${e.message}`); }

// patch + rename + delete
const res2 = applyOps(files, [
  { type: 'apply_patch', path: 'styles.css', find: 'red', replace: 'blue' },
  { type: 'rename_file', path: 'script.js', newPath: 'main.js' },
  { type: 'write_file', path: 'index.html', content: files['index.html'].content.replace('script.js', 'main.js') },
  { type: 'delete_file', path: 'nope.css' },
]);
try {
  assert.ok(files['styles.css'].content.includes('blue'), 'patch applied');
  assert.ok(files['main.js'], 'file renamed');
  assert.ok(!files['script.js'], 'old name gone');
  pass++; console.log('  ✓ ops     patch, rename and delete behave correctly');
} catch (e) { fail++; console.log(`  ✗ ops     ${e.message}`); }

// broken reference detection
function validate(fsFiles) {
  const issues = [];
  const has = p => Object.prototype.hasOwnProperty.call(fsFiles, p);
  for (const [p, f] of Object.entries(fsFiles)) {
    if (!/\.html?$/i.test(p)) continue;
    const src = f.content;
    if (!/<meta[^>]+viewport/i.test(src)) issues.push({ level: 'warn', msg: `${p}: missing viewport meta` });
    for (const m of src.matchAll(/(?:href|src)\s*=\s*["']([^"'#]+)["']/gi)) {
      const ref = m[1];
      if (/^(https?:|data:|mailto:|tel:|#|\/\/)/i.test(ref)) continue;
      const clean = ref.replace(/^\.?\//, '').split('?')[0];
      if (clean && !has(clean)) issues.push({ level: 'error', msg: `${p}: missing asset "${ref}"` });
    }
  }
  for (const [p, f] of Object.entries(fsFiles)) {
    if (!/\.css$/i.test(p)) continue;
    const o = (f.content.match(/{/g) || []).length, c = (f.content.match(/}/g) || []).length;
    if (o !== c) issues.push({ level: 'error', msg: `${p}: unbalanced braces` });
  }
  return issues;
}

const healthy = validate(files);
try {
  assert.equal(healthy.filter(i => i.level === 'error').length, 0);
  pass++; console.log('  ✓ valid   healthy project has no hard errors');
} catch (e) { fail++; console.log(`  ✗ valid   ${JSON.stringify(healthy)}`); }

const broken = validate({ 'index.html': { content: '<html><head></head><body><link href="missing.css" rel="stylesheet"></body></html>' } });
try {
  assert.ok(broken.some(i => i.level === 'error' && i.msg.includes('missing.css')));
  assert.ok(broken.some(i => i.msg.includes('viewport')));
  pass++; console.log('  ✓ valid   broken reference + missing viewport both detected');
} catch (e) { fail++; console.log(`  ✗ valid   ${JSON.stringify(broken)}`); }

/* ---------- 4. preview path resolution & inlining ---------- */
function resolve(basePath, ref) {
  const clean = ref.split('?')[0].split('#')[0].replace(/^\.\//, '');
  if (clean.startsWith('/')) return clean.slice(1);
  const dir = basePath.includes('/') ? basePath.slice(0, basePath.lastIndexOf('/') + 1) : '';
  const parts = [];
  for (const seg of (dir + clean).split('/')) {
    if (seg === '..') parts.pop();
    else if (seg !== '.' && seg !== '') parts.push(seg);
  }
  return parts.join('/');
}
try {
  assert.equal(resolve('index.html', 'styles.css'), 'styles.css');
  assert.equal(resolve('index.html', './styles.css'), 'styles.css');
  assert.equal(resolve('pages/about.html', '../styles.css'), 'styles.css');
  assert.equal(resolve('pages/about.html', 'local.css'), 'pages/local.css');
  assert.equal(resolve('index.html', '/assets/logo.svg'), 'assets/logo.svg');
  pass++; console.log('  ✓ paths  relative, nested and root-absolute refs resolve correctly');
} catch (e) { fail++; console.log(`  ✗ paths  ${e.message}`); }

/* ---------- 5. slugify ---------- */
const slugify = n => (n || 'nova-site').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 50) || 'nova-site';
try {
  assert.equal(slugify('My Restaurant Site!'), 'my-restaurant-site');
  assert.equal(slugify('  ***  '), 'nova-site');
  assert.equal(slugify('Café Ünïcode'), 'caf-n-code');
  pass++; console.log('  ✓ slug   dangerous names produce valid site slugs');
} catch (e) { fail++; console.log(`  ✗ slug   ${e.message}`); }

/* ---------- 6. source integrity: every import resolves ---------- */
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { dirname, join, resolve as pathResolve } from 'node:path';

const ROOT = pathResolve(new URL('..', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'));
const JS_DIR = join(ROOT, 'js');

// index.html must reference exactly the files that exist.
const html = readFileSync(join(ROOT, 'index.html'), 'utf8');
const htmlRefs = [...html.matchAll(/(?:src|href)\s*=\s*["']([^"']+)["']/g)]
  .map(m => m[1])
  .filter(r => !/^(https?:|data:|#|\/\/)/i.test(r));

for (const ref of htmlRefs) {
  try {
    assert.ok(existsSync(join(ROOT, ref)), `index.html references ${ref}, which is missing`);
    pass++; console.log(`  ✓ html   ${ref} exists`);
  } catch (e) { fail++; console.log(`  ✗ html   ${e.message}`); }
}

// every `import ... from './x.js'` must resolve to a real file.
for (const file of readdirSync(JS_DIR).filter(f => f.endsWith('.js'))) {
  const src = readFileSync(join(JS_DIR, file), 'utf8');
  const imports = [...src.matchAll(/from\s+['"](\.[^'"]+)['"]/g)].map(m => m[1]);
  for (const spec of imports) {
    const target = pathResolve(dirname(join(JS_DIR, file)), spec);
    try {
      assert.ok(existsSync(target), `${file} imports ${spec} → not found`);
      pass++; console.log(`  ✓ import ${file} → ${spec}`);
    } catch (e) { fail++; console.log(`  ✗ import ${e.message}`); }
  }
  // and every named import must be exported by the target
  for (const [, names, spec] of src.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"](\.[^'"]+)['"]/g)) {
    const target = pathResolve(dirname(join(JS_DIR, file)), spec);
    const targetSrc = readFileSync(target, 'utf8');
    for (const raw of names.split(',')) {
      const name = raw.trim().split(/\s+as\s+/)[0].trim();
      if (!name) continue;
      const exported = new RegExp(`export\\s+(?:async\\s+)?(?:function|class|const|let|var)\\s+${name}\\b`)
        .test(targetSrc) || new RegExp(`export\\s*\\{[^}]*\\b${name}\\b`).test(targetSrc);
      try {
        assert.ok(exported, `${file} imports {${name}} from ${spec}, but ${spec} does not export it`);
        pass++; console.log(`  ✓ export ${spec} exports ${name}`);
      } catch (e) { fail++; console.log(`  ✗ export ${e.message}`); }
    }
  }
}

/* ---------- 7. every DOM id app.js queries exists in index.html ---------- */
const appSrc = readFileSync(join(JS_DIR, 'app.js'), 'utf8');
const ids = [...appSrc.matchAll(/\$\('#([A-Za-z0-9_-]+)'\)/g)].map(m => m[1]);
const htmlIds = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
const missing = [...new Set(ids)].filter(id => !htmlIds.has(id));
try {
  assert.deepEqual(missing, [], `app.js queries ids missing from index.html: ${missing.join(', ')}`);
  pass++; console.log(`  ✓ dom    all ${new Set(ids).size} queried element ids exist in index.html`);
} catch (e) { fail++; console.log(`  ✗ dom    ${e.message}`); }

/* ---------- 8. index.html script tags: ES modules ---------- */
try {
  assert.ok(/<script\s+type="module"[^>]+src="js\/app\.js"/.test(html), 'app.js must be loaded as a module');
  assert.ok(!/<script\s+src="js\/(?!app)/.test(html), 'no classic script tags for modules');
  pass++; console.log('  ✓ boot   index.html loads js/app.js as an ES module');
} catch (e) { fail++; console.log(`  ✗ boot   ${e.message}`); }

/* ---------- report ---------- */
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
