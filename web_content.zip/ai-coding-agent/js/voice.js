/* =========================================================
   voice.js — speech input (SpeechRecognition) + output
   (speechSynthesis). Feature-detected; every failure path
   surfaces text instead, because text is the source of truth.
   ========================================================= */

export const VoiceOut = {
  supported() { return typeof window !== 'undefined' && 'speechSynthesis' in window; },

  voices() {
    if (!VoiceOut.supported()) return [];
    return window.speechSynthesis.getVoices();
  },

  /* Voices load asynchronously in Chrome — resolve once populated. */
  ready() {
    return new Promise(resolve => {
      if (!VoiceOut.supported()) return resolve([]);
      const now = VoiceOut.voices();
      if (now.length) return resolve(now);
      let done = false;
      const finish = () => { if (!done) { done = true; resolve(VoiceOut.voices()); } };
      window.speechSynthesis.addEventListener('voiceschanged', finish, { once: true });
      setTimeout(finish, 1500);
    });
  },

  pick(name, lang) {
    const list = VoiceOut.voices();
    if (!list.length) return null;
    if (name) {
      const exact = list.find(v => v.name === name);
      if (exact) return exact;
    }
    // Prefer a natural-sounding voice for the reply language.
    const base = (lang || 'en').slice(0, 2).toLowerCase();
    const sameLang = list.filter(v => v.lang.toLowerCase().startsWith(base));
    const prefer = /google|natural|neural|premium|enhanced|siri|samantha|aria|jenny/i;
    return sameLang.find(v => prefer.test(v.name))
        || sameLang.find(v => v.localService)
        || sameLang[0]
        || list[0];
  },

  speak(text, { voiceName, rate = 1, lang } = {}) {
    if (!VoiceOut.supported() || !text) return false;
    try {
      window.speechSynthesis.cancel();
      // Speak the prose, not the markup.
      const clean = stripForSpeech(text);
      if (!clean) return false;
      const u = new SpeechSynthesisUtterance(clean);
      const v = VoiceOut.pick(voiceName, lang);
      if (v) { u.voice = v; u.lang = v.lang; }
      u.rate = Math.min(2, Math.max(0.5, rate));
      u.pitch = 1;
      window.speechSynthesis.speak(u);
      return true;
    } catch { return false; }
  },

  stop() {
    if (VoiceOut.supported()) window.speechSynthesis.cancel();
  },
};

/* Turn a markdown-ish reply into something worth hearing. */
export function stripForSpeech(md) {
  return (md || '')
    .replace(/```[\s\S]*?```/g, ' (code omitted) ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/[*_~]{1,3}/g, '')
    .replace(/^\s*[-•]\s+/gm, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 700);
}

/* ---------------------------------------------------------
   Dictation
   --------------------------------------------------------- */
export function createRecognizer({ onPartial, onFinal, onError, onEnd, lang = 'en-IN' }) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    return {
      supported: false,
      start() { onError?.('not-supported'); },
      stop() {},
      abort() {},
      get listening() { return false; },
    };
  }

  const rec = new SR();
  rec.continuous = false;
  rec.interimResults = true;
  rec.maxAlternatives = 1;
  rec.lang = lang;

  let listening = false;
  let intentionalStop = false;

  rec.onstart = () => { listening = true; };

  rec.onresult = e => {
    let interim = '', final = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) final += r[0].transcript;
      else interim += r[0].transcript;
    }
    if (interim) onPartial?.(interim);
    if (final) onFinal?.(final.trim());
  };

  rec.onerror = e => {
    listening = false;
    const map = {
      'not-allowed': 'Microphone permission was blocked. Allow it in your browser settings.',
      'service-not-allowed': 'Speech recognition is unavailable in this browser.',
      'audio-capture': 'No microphone was found.',
      'network': 'Speech recognition needs a network connection.',
      'no-speech': 'I did not catch anything — try again.',
      'aborted': null,
    };
    const msg = map[e.error];
    if (msg) onError?.(msg, e.error);
    else if (e.error !== 'aborted') onError?.(`Speech error: ${e.error}`, e.error);
  };

  rec.onend = () => {
    listening = false;
    onEnd?.({ intentional: intentionalStop });
    intentionalStop = false;
  };

  return {
    supported: true,
    start() {
      if (listening) return;
      try { rec.start(); } catch { /* already started */ }
    },
    stop() {
      intentionalStop = true;
      try { rec.stop(); } catch { /* noop */ }
    },
    abort() {
      intentionalStop = true;
      try { rec.abort(); } catch { /* noop */ }
    },
    setLang(l) { rec.lang = l; },
    get listening() { return listening; },
  };
}

export function recognitionSupported() {
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

/* Guess a dictation language from settings/region. */
export function defaultDictationLang() {
  const nav = (navigator.language || 'en-IN');
  if (/^hi/i.test(nav)) return 'hi-IN';
  return nav.includes('-') ? nav : 'en-IN';
}
