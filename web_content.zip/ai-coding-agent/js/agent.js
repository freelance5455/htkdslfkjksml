/* =========================================================
   agent.js — the coding agent brain
   - intent detection (chat vs build vs modify)
   - prompt construction with compressed project context
   - structured operation parsing + repair pass
   - operation application against the project store
   ========================================================= */

import { generate, ApiError, PREFERRED_MODELS } from './gemini.js';
import { Projects } from './store.js';

/* ---------------------------------------------------------
   1. Intent detection
   Cheap, local, and deliberately conservative: when in doubt
   the model itself decides, because every build response also
   carries an explicit `mode` field.
   --------------------------------------------------------- */

const BUILD_VERBS = [
  // English
  'build','create','make','generate','develop','design','code','implement','scaffold','set up','setup',
  'add','insert','append','include',
  'fix','repair','debug','solve','correct',
  'change','modify','edit','update','adjust','tweak','rename','replace','refactor','improve','enhance',
  'remove','delete','drop',
  'redesign','restyle','rewrite','convert','migrate','optimise','optimize','responsive',
  // Hindi / Hinglish (romanised + devanagari)
  'bana','banao','banade','bana do','banade','banaye','banaiye','bnao','bna',
  'badal','badlo','badal do','thik','theek','sahi','hata','hatao','jodo','add kar','likh','likho',
  'बना','बनाओ','बनादो','बनाइए','बदल','बदलो','ठीक','हटा','हटाओ','जोड़','लिखो','सुधार',
];

const BUILD_NOUNS = [
  'website','site','webpage','web page','page','landing','app','application','ui','interface','component',
  'form','button','navbar','header','footer','hero','section','dashboard','portfolio','blog','store',
  'ecommerce','e-commerce','shop','calculator','game','clone','project','script','function','css','html',
  'javascript','js','react','layout','theme','animation','menu','card','modal','login','signup','contact',
  'वेबसाइट','ऐप','पेज','साइट','बटन','फॉर्म',
];

const CHAT_ONLY = [
  /^(hi|hey|hello|yo|namaste|namaskar|salaam|hola)\b/i,
  /^(thanks|thank you|thx|ty|shukriya|dhanyavad)\b/i,
  /^(how are you|kaise ho|kya haal|what'?s up|sup)\b/i,
  /^(who are you|what are you|what can you do|tumhara naam|aap kaun)\b/i,
  /^(talk to me|let'?s chat|baat karo)\b/i,
  /^(explain|what is|what's|why|how does|difference between|tell me about|samjhao|kya hota)\b/i,
];

export function detectIntent(text, project) {
  const t = (text || '').trim();
  if (!t) return { mode: 'chat', confidence: 1, reason: 'empty' };

  const low = t.toLowerCase();

  // Explicit conversational openers win — unless a build noun follows anyway.
  for (const re of CHAT_ONLY) {
    if (re.test(low)) {
      const hasBuild = BUILD_VERBS.some(v => low.includes(v)) && BUILD_NOUNS.some(n => low.includes(n));
      if (!hasBuild) return { mode: 'chat', confidence: 0.9, reason: 'conversational opener' };
    }
  }

  const verbHit = BUILD_VERBS.find(v => new RegExp(`(^|[^a-z])${v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'i').test(low));
  const nounHit = BUILD_NOUNS.find(n => low.includes(n));

  const hasProject = !!project && Object.keys(project.files || {}).length > 0;

  // "make it blue", "change the button" — pronoun reference to an open project.
  const pronounEdit = hasProject && /\b(it|this|that|the|us[ei]|isko|ise|yeh|ye|इसे|इसको)\b/i.test(low) && !!verbHit;

  if (verbHit && (nounHit || pronounEdit)) {
    return {
      mode: hasProject ? 'modify' : 'build',
      confidence: 0.85,
      reason: `verb "${verbHit}"${nounHit ? ` + noun "${nounHit}"` : ' + open project reference'}`,
    };
  }
  if (verbHit && t.split(/\s+/).length <= 12 && hasProject) {
    return { mode: 'modify', confidence: 0.6, reason: 'short imperative with open project' };
  }
  if (nounHit && /\b(need|want|chahiye|chaiye)\b/i.test(low)) {
    return { mode: hasProject ? 'modify' : 'build', confidence: 0.6, reason: 'stated need for an artifact' };
  }
  return { mode: 'chat', confidence: 0.5, reason: 'no build signal' };
}

/* ---------------------------------------------------------
   2. Prompts
   --------------------------------------------------------- */

const OPERATION_CONTRACT = `
When you write code you MUST return ONE JSON object and nothing else — no prose outside it,
no markdown fences. Shape:

{
  "message": "A short, natural, human sentence or two about what you just did.",
  "projectName": "Short Title Case name (only when creating a new project)",
  "summary": "one line describing the project as it now stands",
  "operations": [
    { "type": "write_file",   "path": "index.html", "content": "<!DOCTYPE html>..." },
    { "type": "apply_patch",  "path": "styles.css", "find": "color: blue;", "replace": "color: red;" },
    { "type": "delete_file",  "path": "old.js" },
    { "type": "rename_file",  "path": "a.css", "newPath": "main.css" },
    { "type": "create_folder","path": "assets" },
    { "type": "run_preview",  "entry": "index.html" }
  ]
}

Rules for operations:
- write_file content must be the COMPLETE final file, never a diff, never "// rest unchanged".
- Use apply_patch for small surgical edits to a large existing file; "find" must match the
  existing text EXACTLY and appear exactly once.
- Never touch files the request does not concern.
- Always finish a buildable change with a run_preview operation pointing at the HTML entry file.
- Escape newlines correctly — the whole thing must be valid JSON.`;

const QUALITY_BAR = `
Code quality bar for everything you generate:
- Mobile-first responsive CSS, no horizontal overflow at 360px, real breakpoints at 768px and 1024px.
- Semantic HTML, alt text on images, labels on inputs, visible focus states, sensible colour contrast.
- Modern polished visual design: consistent spacing scale, a real type scale, a coherent palette,
  subtle transitions. Never a bare unstyled page.
- Self-contained: no build step, no npm, no external JS frameworks unless the user asked for one.
  Google Fonts and image CDNs are fine. Use inline SVG rather than icon-font CDNs.
- Vanilla JS in a separate script.js unless the user asked for a framework.
- Working interactivity: forms validate, menus open, tabs switch. Nothing decorative-only.`;

export function systemPrompt({ assistantName, mode, project }) {
  const persona = `You are ${assistantName}, an AI coding agent that builds real, working web projects.
You are warm, direct and concise — a skilled engineer talking to a colleague, never a status robot.
Never say "Task started", "Processing" or "Operation complete".
Mirror the user's language exactly: reply in English to English, Hindi to Hindi, and natural
Hinglish (roman script) to Hinglish. Keep chat replies short unless depth is asked for.`;

  if (mode === 'chat') {
    return `${persona}

You are in conversation mode — the user is chatting or asking a question, not asking for a build.
Answer directly and helpfully in plain prose. Markdown is fine for structure and code snippets.
${project ? `\nContext: the user currently has a project open called "${project.name}" with these files: ${Object.keys(project.files).join(', ') || '(none yet)'}.` : ''}
If the user pivots to wanting something built, say briefly what you will build and they can confirm.`;
  }

  const isModify = mode === 'modify';
  return `${persona}

You are in CODING AGENT MODE. The user asked you to ${isModify ? 'modify an existing project' : 'build something'}.
You do not paste code into chat. You emit file operations that are applied to a real workspace.
${QUALITY_BAR}
${OPERATION_CONTRACT}

${isModify
  ? `This is a MODIFICATION. The current project state is given below. Change only what the request
requires. Preserve everything else exactly — content, structure, class names, existing features.
Prefer apply_patch for small edits; use write_file when the change is substantial or the file is short.
Do not rename or restructure files unless asked.`
  : `This is a NEW build. Produce a complete, genuinely impressive project — typically index.html,
styles.css and script.js, plus a short README.md. Include real content, not lorem ipsum: write
plausible copy for the actual subject. Make it something the user would be happy to publish.`}

The "message" field is what the user reads. Write it like a person: what you built, one or two
notable decisions, what they can do next. No bullet lists of file names — the UI already shows those.`;
}

/* ---------------------------------------------------------
   3. Project context compression
   Never ship every byte of every file on every turn.
   --------------------------------------------------------- */

const BIG = 6000;

export function buildProjectContext(project, { intent, userText }) {
  if (!project || !Object.keys(project.files).length) return '';
  const paths = Object.keys(project.files);

  // Which files are probably relevant to this request?
  const low = (userText || '').toLowerCase();
  const mentioned = paths.filter(p => low.includes(p.toLowerCase()) || low.includes(p.split('/').pop().toLowerCase()));
  const byKeyword = paths.filter(p => {
    if (/\.css$/.test(p)) return /color|style|design|css|font|spacing|layout|theme|dark|responsive|rang|design/i.test(low);
    if (/\.js$/.test(p))  return /script|function|click|button|logic|bug|error|validate|js|interactive/i.test(low);
    if (/\.html?$/.test(p)) return true;   // structure is almost always relevant
    return false;
  });

  const relevant = [...new Set([...mentioned, ...byKeyword])];
  const include = relevant.length ? relevant : paths.slice(0, 4);

  let out = `# CURRENT PROJECT: ${project.name}\n`;
  if (project.meta?.summary) out += `Summary: ${project.meta.summary}\n`;
  out += `All files: ${paths.join(', ')}\n\n`;

  for (const p of paths) {
    const body = project.files[p].content || '';
    if (!include.includes(p)) {
      out += `--- ${p} (${body.length} bytes, not included — ask for it with read_file if you need it) ---\n\n`;
      continue;
    }
    const clipped = body.length > BIG
      ? `${body.slice(0, BIG)}\n/* … truncated, ${body.length - BIG} more bytes … */`
      : body;
    out += `--- ${p} ---\n${clipped}\n\n`;
  }
  return out;
}

export function buildHistory(project, limit = 8) {
  const msgs = (project?.messages || []).filter(m => m.text && !m.hidden).slice(-limit);
  return msgs.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.role === 'assistant' && m.text.length > 1200 ? `${m.text.slice(0, 1200)}…` : m.text }],
  }));
}

/* ---------------------------------------------------------
   4. Response parsing — tolerant of the usual model slips
   --------------------------------------------------------- */

export function extractJson(raw) {
  if (!raw) return null;
  let s = raw.trim();

  // Strip markdown fences.
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();

  // Direct parse.
  try { return JSON.parse(s); } catch { /* keep going */ }

  // Find the outermost balanced object.
  const start = s.indexOf('{');
  if (start === -1) return null;
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (esc) { esc = false; continue; }
    if (c === '\\') { esc = true; continue; }
    if (c === '"') { inStr = !inStr; continue; }
    if (inStr) continue;
    if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) {
        const slice = s.slice(start, i + 1);
        try { return JSON.parse(slice); } catch { break; }
      }
    }
  }

  // Last resort: repair raw newlines inside string literals (a common model slip).
  try {
    const candidate = s.slice(start);
    const fixed = candidate.replace(/"(?:[^"\\]|\\.)*"/gs, m => m.replace(/\n/g, '\\n').replace(/\r/g, ''));
    return JSON.parse(fixed);
  } catch { return null; }
}

const VALID_OPS = new Set(['write_file','apply_patch','delete_file','rename_file','create_folder','run_preview','read_file']);

export function normaliseOperations(parsed) {
  if (!parsed) return [];
  const ops = Array.isArray(parsed.operations) ? parsed.operations
            : Array.isArray(parsed.files) ? parsed.files.map(f => ({ type: 'write_file', path: f.path, content: f.content }))
            : [];
  return ops
    .filter(o => o && typeof o === 'object' && VALID_OPS.has(o.type))
    .map(o => ({ ...o, path: typeof o.path === 'string' ? o.path.replace(/^\.?\//, '').trim() : o.path }))
    .filter(o => o.type === 'run_preview' || (typeof o.path === 'string' && o.path.length > 0 && !o.path.includes('..')));
}

/* ---------------------------------------------------------
   5. Applying operations to the store
   --------------------------------------------------------- */

export function applyOperations(projectId, ops, { onStep } = {}) {
  const applied = [];
  const errors = [];
  let previewEntry = null;

  for (const op of ops) {
    try {
      switch (op.type) {
        case 'write_file': {
          if (typeof op.content !== 'string') throw new Error('missing content');
          const before = Projects.get(projectId)?.files[op.path];
          Projects.writeFile(projectId, op.path, op.content);
          const rec = { kind: before ? 'mod' : 'new', path: op.path, bytes: op.content.length };
          applied.push(rec); onStep?.(rec);
          break;
        }
        case 'apply_patch': {
          const proj = Projects.get(projectId);
          const file = proj?.files[op.path];
          if (!file) throw new Error(`${op.path} does not exist`);
          if (typeof op.find !== 'string' || !op.find) throw new Error('patch had no find text');
          const count = file.content.split(op.find).length - 1;
          if (count === 0) throw new Error(`patch target not found in ${op.path}`);
          const next = file.content.replace(op.find, op.replace ?? '');
          Projects.writeFile(projectId, op.path, next);
          const rec = { kind: 'mod', path: op.path, bytes: next.length, patch: true };
          applied.push(rec); onStep?.(rec);
          break;
        }
        case 'delete_file': {
          Projects.deleteFile(projectId, op.path);
          const rec = { kind: 'del', path: op.path };
          applied.push(rec); onStep?.(rec);
          break;
        }
        case 'rename_file': {
          if (!op.newPath) throw new Error('rename had no newPath');
          Projects.renameFile(projectId, op.path, op.newPath.replace(/^\.?\//, ''));
          const rec = { kind: 'mod', path: `${op.path} → ${op.newPath}` };
          applied.push(rec); onStep?.(rec);
          break;
        }
        case 'create_folder': {
          // Folders are implicit in path names; record a keep-file so the tree shows it.
          const keep = `${op.path.replace(/\/$/, '')}/.keep`;
          if (!Projects.get(projectId)?.files[keep]) Projects.writeFile(projectId, keep, '');
          break;
        }
        case 'run_preview': {
          previewEntry = op.entry || 'index.html';
          break;
        }
        case 'read_file': break; // context-only; already supplied
      }
    } catch (err) {
      errors.push({ op: op.type, path: op.path, message: err.message });
    }
  }
  return { applied, errors, previewEntry };
}

/* ---------------------------------------------------------
   6. Static validation of generated code
   Real checks, reported honestly. Not a full parser.
   --------------------------------------------------------- */

export function validateProject(project) {
  const issues = [];
  const files = project.files || {};
  const paths = Object.keys(files);
  const has = p => Object.prototype.hasOwnProperty.call(files, p);

  const html = paths.filter(p => /\.html?$/i.test(p));
  if (!html.length) issues.push({ level: 'warn', msg: 'No HTML file — nothing to preview.' });

  for (const p of html) {
    const src = files[p].content;
    if (!/<html[\s>]/i.test(src)) issues.push({ level: 'warn', msg: `${p}: no <html> element.` });
    if (!/<meta[^>]+viewport/i.test(src)) issues.push({ level: 'warn', msg: `${p}: missing viewport meta — mobile layout will break.` });

    // Local asset references that do not exist.
    const refs = [...src.matchAll(/(?:href|src)\s*=\s*["']([^"'#]+)["']/gi)].map(m => m[1]);
    for (const ref of refs) {
      if (/^(https?:|data:|mailto:|tel:|#|\/\/)/i.test(ref)) continue;
      const clean = ref.replace(/^\.?\//, '').split('?')[0];
      if (clean && !has(clean)) {
        issues.push({ level: 'error', msg: `${p}: references "${ref}" which does not exist in the project.` });
      }
    }
    // Unclosed common tags (cheap balance check).
    for (const tag of ['div', 'section', 'main', 'header', 'footer', 'ul', 'body', 'html']) {
      const open = (src.match(new RegExp(`<${tag}[\\s>]`, 'gi')) || []).length;
      const close = (src.match(new RegExp(`</${tag}>`, 'gi')) || []).length;
      if (open !== close) issues.push({ level: 'warn', msg: `${p}: ${open} <${tag}> vs ${close} </${tag}> — possible unclosed tag.` });
    }
  }

  for (const p of paths.filter(x => /\.css$/i.test(x))) {
    const src = files[p].content;
    const open = (src.match(/{/g) || []).length, close = (src.match(/}/g) || []).length;
    if (open !== close) issues.push({ level: 'error', msg: `${p}: unbalanced braces (${open} open, ${close} close).` });
  }

  for (const p of paths.filter(x => /\.js$/i.test(x))) {
    const src = files[p].content;
    try {
      // Syntax-only check. Never executed.
      new Function(src);
    } catch (err) {
      if (!/import|export|await is only valid/i.test(err.message)) {
        issues.push({ level: 'error', msg: `${p}: ${err.message}` });
      }
    }
  }
  return issues;
}

/* ---------------------------------------------------------
   7. High level: run one coding turn
   --------------------------------------------------------- */

export async function runCodingTurn({
  settings, project, userText, mode, signal, onEvent,
}) {
  const sys = systemPrompt({ assistantName: settings.assistantName, mode, project });
  const ctx = buildProjectContext(project, { intent: mode, userText });
  const history = buildHistory(project, 6);

  const contents = [
    ...history,
    { role: 'user', parts: [{ text: ctx ? `${ctx}\n\n# REQUEST\n${userText}` : userText }] },
  ];

  const candidates = PREFERRED_MODELS.filter(m => m !== settings.model);

  let out = await generate({
    apiKey: settings.apiKey,
    model: settings.model,
    systemInstruction: sys,
    contents,
    json: true,
    temperature: 0.65,
    maxOutputTokens: 16384,
    candidates,
    signal,
    onEvent,
  });

  let parsed = extractJson(out.text);
  let ops = normaliseOperations(parsed);

  // Repair pass 1: the response was not usable JSON.
  if (!parsed) {
    onEvent?.({ type: 'repair', reason: 'invalid JSON' });
    out = await generate({
      apiKey: settings.apiKey, model: out.model, systemInstruction: sys,
      contents: [
        ...contents,
        { role: 'model', parts: [{ text: out.text.slice(0, 4000) }] },
        { role: 'user', parts: [{ text: 'That was not valid JSON. Return the SAME work as one valid JSON object matching the required schema. No prose, no code fences, nothing outside the object.' }] },
      ],
      json: true, temperature: 0.2, maxOutputTokens: 16384, candidates, signal, onEvent,
    });
    parsed = extractJson(out.text);
    ops = normaliseOperations(parsed);
  }

  // Repair pass 2: it talked instead of writing files.
  const writes = ops.filter(o => ['write_file', 'apply_patch', 'delete_file', 'rename_file'].includes(o.type));
  if (!writes.length && settings.autoRepair) {
    onEvent?.({ type: 'repair', reason: 'no file operations' });
    out = await generate({
      apiKey: settings.apiKey, model: out.model, systemInstruction: sys,
      contents: [
        ...contents,
        { role: 'model', parts: [{ text: (parsed?.message || out.text || '').slice(0, 2000) }] },
        { role: 'user', parts: [{ text: 'The previous response did not modify the workspace. Convert the requested task into actual file operations now. Return only valid structured file operations and a concise status message, as one JSON object.' }] },
      ],
      json: true, temperature: 0.3, maxOutputTokens: 16384, candidates, signal, onEvent,
    });
    const reParsed = extractJson(out.text);
    const reOps = normaliseOperations(reParsed);
    if (reOps.some(o => o.type === 'write_file' || o.type === 'apply_patch')) {
      parsed = reParsed; ops = reOps;
    }
  }

  if (!parsed) throw new ApiError('The model kept returning something unreadable. Try again, or switch model in Settings.');
  return { parsed, ops, model: out.model };
}

/* Repair a validation failure by feeding the issues back. */
export async function runValidationFix({ settings, project, issues, signal, onEvent }) {
  const sys = systemPrompt({ assistantName: settings.assistantName, mode: 'modify', project });
  const ctx = buildProjectContext(project, { intent: 'modify', userText: issues.map(i => i.msg).join(' ') });
  const list = issues.map(i => `- [${i.level}] ${i.msg}`).join('\n');

  const out = await generate({
    apiKey: settings.apiKey, model: settings.model, systemInstruction: sys,
    contents: [{ role: 'user', parts: [{ text: `${ctx}\n\n# AUTOMATED VALIDATION FOUND PROBLEMS\n${list}\n\nFix exactly these problems and nothing else. Return the JSON operations object.` }] }],
    json: true, temperature: 0.2, maxOutputTokens: 16384,
    candidates: PREFERRED_MODELS.filter(m => m !== settings.model), signal, onEvent,
  });
  const parsed = extractJson(out.text);
  return { parsed, ops: normaliseOperations(parsed) };
}

/* Conversational (non-coding) turn, optionally streamed. */
export async function runChatTurn({ settings, project, userText, signal, onDelta, onEvent }) {
  const sys = systemPrompt({ assistantName: settings.assistantName, mode: 'chat', project });
  const contents = [...buildHistory(project, 10), { role: 'user', parts: [{ text: userText }] }];
  return generate({
    apiKey: settings.apiKey,
    model: settings.model,
    systemInstruction: sys,
    contents,
    temperature: 0.85,
    maxOutputTokens: 2048,
    stream: settings.stream,
    candidates: PREFERRED_MODELS.filter(m => m !== settings.model),
    signal, onDelta, onEvent,
  });
}

/* Ask the model for a short project name when it did not supply one. */
export function fallbackName(text) {
  const clean = (text || '').replace(/["'`]/g, '').trim();
  const words = clean.split(/\s+/).filter(w => !/^(build|create|make|me|a|an|the|please|banao|bana|do|for|my)$/i.test(w));
  const name = words.slice(0, 4).join(' ');
  return (name || 'New project').replace(/\b\w/g, c => c.toUpperCase()).slice(0, 40);
}
