/* =========================================================
   app.js — UI controller. Wires every module together.
   ========================================================= */

import {
  Settings, Projects, Profile, Onboarded, uid,
} from './store.js';
import {
  detectIntent, runCodingTurn, runChatTurn, runValidationFix,
  applyOperations, validateProject, fallbackName,
} from './agent.js';
import { listModels, testKey, ApiError, PREFERRED_MODELS } from './gemini.js';
import { Preview, zipProject, findEntry } from './preview.js';
import {
  VoiceOut, createRecognizer, recognitionSupported, defaultDictationLang,
} from './voice.js';
import { publish, PROVIDERS, DeployError, slugify, pingProxy } from './deploy.js';

/* ---------------- tiny DOM helpers ---------------- */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') n.className = v;
    else if (k === 'html') n.innerHTML = v;
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
    else if (v != null && v !== false) n.setAttribute(k, v === true ? '' : String(v));
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    n.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return n;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* Minimal, safe markdown renderer for chat bubbles.
   Escapes first, then applies inline/code/heading/list rules. */
function renderMarkdown(md) {
  const blocks = [];
  let s = escapeHtml(md || '');

  s = s.replace(/```([a-z0-9]*)\n?([\s\S]*?)```/gi, (_m, lang, code) => {
    const i = blocks.push(`<pre><code data-lang="${lang}">${code.replace(/\n$/, '')}</code></pre>`) - 1;
    return `\u0000B${i}\u0000`;
  });

  s = s.replace(/`([^`\n]+)`/g, '<code>$1</code>');
  s = s.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/(^|\s)\*([^*\n]+)\*/g, '$1<em>$2</em>');
  s = s.replace(/^#{1,6}\s+(.+)$/gm, '<strong>$1</strong>');

  const lines = s.split('\n');
  const out = [];
  let list = null;
  const closeList = () => { if (list) { out.push(`</${list}>`); list = null; } };

  for (const line of lines) {
    const bullet = line.match(/^\s*[-•*]\s+(.*)$/);
    const num = line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (bullet || num) {
      const want = bullet ? 'ul' : 'ol';
      if (list !== want) { closeList(); out.push(`<${want}>`); list = want; }
      out.push(`<li>${(bullet || num)[1]}</li>`);
    } else if (!line.trim()) {
      closeList();
    } else {
      closeList();
      out.push(`<p>${line}</p>`);
    }
  }
  closeList();

  return out.join('').replace(/\u0000B(\d+)\u0000/g, (_m, i) => blocks[Number(i)]);
}

/* ---------------- app state ---------------- */
const State = {
  settings: Settings.get(),
  profile: Profile.get(),
  project: null,
  view: 'chat',
  busy: false,
  abort: null,
  activeFile: null,
  consoleLines: [],
  pendingEntry: null,
  recognizer: null,
  inited: false,
};

const DEFAULT_FILES = {
  'README.md': `# New project\n\nAsk the agent to build something and the files will appear here.\n`,
};

/* =========================================================
   Boot
   ========================================================= */
async function boot() {
  applyTheme(State.settings.theme);

  const previewIframe = $('#previewFrame');
  State.preview = new Preview(previewIframe, {
    onConsole: (kind, text) => addConsole(kind === 'log' ? 'info' : kind, text),
  });

  wireEverything();

  // Project selection
  const projects = Projects.all();
  if (!projects.length) {
    const p = Projects.create('Untitled project');
    Projects.update(p.id, proj => {
      proj.files = Object.fromEntries(
        Object.entries(DEFAULT_FILES).map(([k, v]) => [k, { content: v, updatedAt: Date.now() }]),
      );
      return proj;
    });
    State.project = Projects.get(p.id);
  } else {
    State.project = Projects.active() || projects[0];
    Projects.setActive(State.project.id);
  }

  renderTopbar();
  renderProjects();
  renderChat();
  renderFiles();
  renderProfile();
  fillSettingsForm();
  switchView('chat');

  if (Onboarded.get() && State.settings.apiKey) {
    showApp();
    await refreshModelList({ silent: true });
    probeConnection({ silent: true });
  } else {
    showOnboarding();
  }

  State.inited = true;
}

function showApp() {
  $('#onboarding').hidden = true;
  $('#app').hidden = false;
}

function showOnboarding() {
  $('#app').hidden = true;
  $('#onboarding').hidden = false;
  initOnboarding();
}

function applyTheme(theme) {
  document.body.dataset.theme = theme || 'midnight';
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.setAttribute('content', theme === 'daylight' ? '#f4f6fb' : '#0b0d12');
}

/* =========================================================
   Toasts + modal
   ========================================================= */
function toast(message, kind = 'info', ms = 4200) {
  const t = el('div', { class: 'toast', 'data-k': kind, text: message });
  $('#toasts').append(t);
  setTimeout(() => {
    t.style.transition = 'opacity .25s, transform .25s';
    t.style.opacity = '0';
    t.style.transform = 'translateY(6px)';
    setTimeout(() => t.remove(), 260);
  }, ms);
}

function openModal({ title, body, actions = [] }) {
  const host = $('#modalHost');
  const close = () => { host.hidden = true; host.innerHTML = ''; };
  const modal = el('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' },
    el('h3', { text: title }),
    body,
    el('div', { class: 'row-actions' },
      ...actions.map(a => el('button', {
        class: a.primary ? 'primary-btn' : 'ghost-btn',
        type: 'button',
        onclick: async () => { const keep = await a.onClick?.(close); if (!keep) close(); },
      }, a.label)),
      el('button', { class: 'ghost-btn', type: 'button', onclick: close }, 'Close'),
    ),
  );
  host.innerHTML = '';
  host.append(modal);
  host.hidden = false;
  host.onclick = e => { if (e.target === host) close(); };
  return close;
}

/* =========================================================
   Onboarding
   ========================================================= */
let obStep = 1;

function initOnboarding() {
  obStep = 1;
  paintObStep();

  $('#obKey').value = State.settings.apiKey || '';
  $('#obName').value = State.settings.assistantName || 'Nova';
  $('#obVoice').checked = !!State.settings.voiceOut;
  $('#obVoiceHint').textContent = recognitionSupported()
    ? `Microphone supported. Voice output: ${VoiceOut.supported() ? 'available' : 'not available in this browser'}.`
    : `Speech output: ${VoiceOut.supported() ? 'available' : 'not available'}. Microphone input is not supported in this browser on this page — you can still type.`;

  fillModelSelect($('#obModel'), State.settings.knownModels);
  if (!State.settings.knownModels.length) {
    $('#obModelHint').textContent = 'Enter a key and press “Test key” to load the exact models your key can use.';
  }
}

function paintObStep() {
  $$('.onboard-step').forEach(s => s.classList.toggle('is-active', Number(s.dataset.step) === obStep));
  $('#obDots').innerHTML = '<i class="on"></i><i class=""></i><i class=""></i>'.replace(
    /<i class="([^"]*)"><\/i>/g,
    (m, cls, i) => `<i class="${Number(m.index ?? 0)}"></i>`,
  );
  // simpler, correct dots:
  $('#obDots').innerHTML = [1, 2, 3].map(n => `<i class="${n <= obStep ? 'on' : ''}"></i>`).join('');
  $('#obBack').hidden = obStep === 1;
  $('#obNext').textContent = obStep === 3 ? 'Start building' : 'Next';
}

function wireOnboarding() {
  $('#obKeyToggle').addEventListener('click', () => {
    const f = $('#obKey');
    f.type = f.type === 'password' ? 'text' : 'password';
  });

  $('#obTestKey').addEventListener('click', async () => {
    const key = $('#obKey').value.trim();
    const pill = $('#obKeyStatus');
    if (!key) { pill.hidden = false; pill.dataset.kind = 'err'; pill.textContent = 'Enter a key first'; return; }
    pill.hidden = false; pill.dataset.kind = 'busy'; pill.textContent = 'Testing…';
    try {
      const models = await listModels(key);
      State.settings = Settings.set({ apiKey: key, knownModels: models });
      fillModelSelect($('#obModel'), models);
      if (models.length && !models.includes(State.settings.model)) {
        State.settings = Settings.set({ model: models[0] });
      }
      fillModelSelect($('#obModel'), models, State.settings.model);
      $('#obModelHint').textContent = `${models.length} model${models.length === 1 ? '' : 's'} available to this key.`;
      pill.dataset.kind = 'ok'; pill.textContent = 'Key works ✓';
    } catch (err) {
      pill.dataset.kind = 'err';
      pill.textContent = err instanceof ApiError ? err.message : 'Could not reach the API.';
    }
  });

  $('#obRefreshModels').addEventListener('click', async () => {
    const key = $('#obKey').value.trim() || State.settings.apiKey;
    if (!key) { toast('Enter your API key first.', 'err'); return; }
    try {
      const models = await listModels(key);
      State.settings = Settings.set({ knownModels: models });
      fillModelSelect($('#obModel'), models, State.settings.model);
      toast(`Loaded ${models.length} models.`, 'ok');
    } catch (err) {
      toast(err.message || 'Could not load models.', 'err');
    }
  });

  $('#obBack').addEventListener('click', () => { if (obStep > 1) { obStep--; paintObStep(); } });

  $('#obNext').addEventListener('click', async () => {
    if (obStep === 1) {
      const key = $('#obKey').value.trim();
      if (!key) { toast('Paste your Gemini API key to continue.', 'err'); return; }
      State.settings = Settings.set({ apiKey: key });
      obStep = 2; paintObStep();
      try {
        const models = await listModels(key);
        State.settings = Settings.set({ knownModels: models });
        fillModelSelect($('#obModel'), models, State.settings.model);
        $('#obModelHint').textContent = `${models.length} models available.`;
        if (models.length && !models.includes(State.settings.model)) {
          State.settings = Settings.set({ model: models[0] });
          fillModelSelect($('#obModel'), models, State.settings.model);
        }
      } catch (err) {
        $('#obModelHint').textContent = `Could not load models yet (${err.message}). The built-in list will be used.`;
      }
      return;
    }
    if (obStep === 2) {
      const model = $('#obModel').value;
      State.settings = Settings.set({ model });
      obStep = 3; paintObStep();
      return;
    }
    // finish
    State.settings = Settings.set({
      assistantName: $('#obName').value.trim() || 'Nova',
      voiceOut: $('#obVoice').checked,
    });
    Onboarded.set(true);
    showApp();
    renderTopbar(); fillSettingsForm(); renderProfile();
    if (State.settings.apiKey) {
      await refreshModelList({ silent: true });
      probeConnection({ silent: true });
    }
    toast(`${State.settings.assistantName} is ready. Describe what you want to build.`, 'ok');
  });
}

function fillModelSelect(select, models, current) {
  const list = models && models.length ? models : PREFERRED_MODELS;
  const chosen = current || select.value || State.settings.model;
  select.innerHTML = list.map(m => `<option value="${m}">${m}</option>`).join('');
  if (list.includes(chosen)) select.value = chosen;
}

/* =========================================================
   Topbar / connection
   ========================================================= */
function renderTopbar() {
  $('#assistantName').textContent = State.settings.assistantName || 'Nova';
  $('#modelLabel').textContent = (State.settings.model || '—').replace('gemini-', 'Gemini ');
  document.title = `${State.settings.assistantName} · AI Coding Agent`;
  const a = $('#avatar');
  if (a) a.textContent = (State.settings.assistantName || 'N').trim().charAt(0).toUpperCase();
  setConn('unknown', State.settings.apiKey ? 'Ready' : 'No API key');
}

function setConn(state, label) {
  $('#connDot').dataset.state = state;
  $('#connLabel').textContent = label;
}

async function refreshModelList({ silent = false } = {}) {
  if (!State.settings.apiKey) return;
  try {
    const models = await listModels(State.settings.apiKey);
    State.settings = Settings.set({ knownModels: models });
    fillModelSelect($('#setModel'), models, State.settings.model);
    fillModelSelect($('#obModel'), models, State.settings.model);
    $('#setModelHint').textContent = `${models.length} models available to this key.`;
    if (!silent) toast(`Loaded ${models.length} models.`, 'ok');
  } catch (err) {
    $('#setModelHint').textContent = `Could not refresh (${err.message}).`;
    if (!silent) toast(err.message || 'Could not load models.', 'err');
  }
}

async function probeConnection({ silent = false } = {}) {
  if (!State.settings.apiKey) { setConn('unknown', 'No API key'); return false; }
  setConn('busy', 'Checking…');
  try {
    await listModels(State.settings.apiKey);
    setConn('ok', 'Connected');
    return true;
  } catch (err) {
    setConn('err', err.status === 403 || err.status === 401 ? 'Key rejected' : 'Offline');
    if (!silent) toast(err.message || 'Connection failed.', 'err');
    return false;
  }
}

/* =========================================================
   Views / nav
   ========================================================= */
function switchView(name) {
  State.view = name;
  $$('.view').forEach(v => v.classList.toggle('is-active', v.dataset.view === name));
  $$('.nav-btn').forEach(b => b.classList.toggle('is-on', b.dataset.go === name));
  closeSidebar();
  if (name === 'projects') renderProjects();
  if (name === 'files') renderFiles();
  if (name === 'profile') renderProfile();
  if (name === 'preview') ensurePreview();
}

function openSidebar() {
  $('#sidebar').classList.add('is-open');
  $('#sidebar').setAttribute('aria-hidden', 'false');
  $('#scrim').hidden = false;
  $('#btnSidebar').setAttribute('aria-expanded', 'true');
}
function closeSidebar() {
  $('#sidebar').classList.remove('is-open');
  $('#sidebar').setAttribute('aria-hidden', 'true');
  $('#scrim').hidden = true;
  $('#btnSidebar').setAttribute('aria-expanded', 'false');
}

/* =========================================================
   Projects
   ========================================================= */
function renderProjects() {
  const list = Projects.all();

  // Sidebar
  const sb = $('#projectList');
  sb.innerHTML = '';
  if (!list.length) sb.append(el('p', { class: 'hint', style: 'padding:8px 12px', text: 'No projects yet.' }));
  for (const p of list) {
    const item = el('div', { class: `proj-item${State.project && p.id === State.project.id ? ' is-on' : ''}`, role: 'button', tabindex: '0' },
      el('div', { class: 'pi-main' },
        el('div', { class: 'pi-name', text: p.name }),
        el('div', { class: 'pi-meta', text: `${Object.keys(p.files || {}).length} files · ${relTime(p.updatedAt)}` }),
      ),
      el('button', {
        class: 'pi-del', type: 'button', 'aria-label': `Delete ${p.name}`,
        onclick: e => { e.stopPropagation(); confirmDeleteProject(p); },
      }, '✕'),
    );
    item.addEventListener('click', () => openProject(p.id));
    item.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openProject(p.id); } });
    sb.append(item);
  }

  // Grid
  const grid = $('#projectsGrid');
  grid.innerHTML = '';
  if (!list.length) {
    grid.append(el('div', { class: 'empty-state' }, el('p', { text: 'No projects yet.' }), el('p', { class: 'muted', text: 'Ask the agent to build something.' })));
  }
  for (const p of list) {
    const files = Object.keys(p.files || {}).filter(f => !f.endsWith('/.keep'));
    const card = el('div', { class: 'proj-card' },
      el('h3', { text: p.name }),
      el('div', { class: 'meta', text: `${files.length} file${files.length === 1 ? '' : 's'} · updated ${relTime(p.updatedAt)}` }),
      p.meta?.summary ? el('p', { class: 'muted', style: 'font-size:12.5px;margin:8px 0 0', text: p.meta.summary }) : null,
      el('div', { class: 'files' }, ...files.slice(0, 6).map(f => el('span', { text: f }))),
      el('div', { class: 'row' },
        el('button', { class: 'ghost-btn tiny', type: 'button', onclick: () => openProject(p.id) }, 'Open'),
        el('button', { class: 'ghost-btn tiny', type: 'button', onclick: () => { State.project = Projects.get(p.id); downloadZip(); } }, 'Download'),
        el('button', { class: 'ghost-btn tiny danger', type: 'button', onclick: () => confirmDeleteProject(p) }, 'Delete'),
      ),
    );
    grid.append(card);
  }
}

function openProject(id) {
  const p = Projects.get(id);
  if (!p) return;
  State.project = p;
  State.activeFile = null;
  Projects.setActive(id);
  renderProjects(); renderChat(); renderFiles(); renderTopbar();
  State.preview.revoke();
  $('#previewEmpty').hidden = false; $('#device').classList.add('is-hidden');
  addConsole('cmd', `opened project ${p.name}`);
  switchView('chat');
}

function confirmDeleteProject(p) {
  openModal({
    title: `Delete “${p.name}”?`,
    body: el('p', { class: 'sub', text: 'This removes the project and all of its files from this browser. It cannot be undone.' }),
    actions: [{
      label: 'Delete project',
      primary: false,
      onClick: () => {
        Projects.remove(p.id);
        const next = Projects.active() || Projects.all()[0];
        if (next) { State.project = next; Projects.setActive(next.id); }
        else {
          const fresh = Projects.create('Untitled project');
          State.project = Projects.get(fresh.id);
        }
        renderProjects(); renderChat(); renderFiles();
        toast('Project deleted.', 'info');
      },
    }],
  });
}

function newProject(name) {
  const p = Projects.create(name || 'Untitled project');
  State.project = Projects.get(p.id);
  State.activeFile = null;
  renderProjects(); renderChat(); renderFiles();
  switchView('chat');
  return State.project;
}

/* =========================================================
   Chat
   ========================================================= */
function renderChat() {
  const box = $('#messages');
  box.innerHTML = '';
  const msgs = State.project?.messages || [];

  if (!msgs.length) {
    box.append(el('div', { class: 'hero' },
      el('div', { class: 'brand-mark', text: (State.settings.assistantName || 'N').charAt(0).toUpperCase() }),
      el('h2', { text: `Hi, I'm ${State.settings.assistantName || 'Nova'}.` }),
      el('p', { text: 'Tell me what you want to build and I will create the real files, validate them and open a live preview.' }),
      el('div', { class: 'chips' },
        ...['Build a restaurant booking website',
          'Create a modern portfolio site',
          'Make an Android-style calculator',
          'Create a landing page for my business',
          'Build an e-commerce storefront',
        ].map(t => el('button', { class: 'chip', type: 'button', onclick: () => { $('#input').value = t; send(); } }, t)),
      ),
    ));
    return;
  }

  for (const m of msgs) box.append(messageNode(m));
  scrollChatToEnd();
}

function messageNode(m) {
  const wrap = el('div', { class: `msg ${m.role === 'user' ? 'user' : 'ai'}` });
  const initial = m.role === 'user'
    ? (State.profile.name || 'Y').trim().charAt(0).toUpperCase()
    : (State.settings.assistantName || 'N').trim().charAt(0).toUpperCase();
  wrap.append(el('div', { class: 'av', text: initial }));

  const bubble = el('div', { class: 'bubble' });
  if (m.role === 'user') bubble.textContent = m.text;
  else bubble.innerHTML = renderMarkdown(m.text || '');

  if (m.card) bubble.append(buildResultCard(m.card));

  const foot = el('div', { class: 'msg-foot' },
    el('button', { type: 'button', onclick: () => copyText(m.text) }, 'Copy'),
    m.role === 'assistant' && VoiceOut.supported()
      ? el('button', { type: 'button', onclick: () => VoiceOut.speak(m.text, { voiceName: State.settings.voiceName, rate: State.settings.rate }) }, 'Speak')
      : null,
  );
  bubble.append(foot);
  wrap.append(bubble);
  return wrap;
}

function buildResultCard(card) {
  const { files = [], issues = [], entry = null } = card || {};
  const node = el('div', { class: 'ac-files', style: 'border-top:1px solid var(--stroke);margin-top:10px' },
    el('div', { class: 't', text: 'Files written' }),
    ...files.map(f => el('div', { class: 'ac-file' },
      el('span', { class: `tag ${f.kind}`, text: f.kind === 'new' ? 'new' : f.kind === 'del' ? 'deleted' : 'updated' }),
      el('b', { text: f.path }),
    )),
    issues.length
      ? el('div', { class: 't', style: 'margin-top:10px', text: `Validation: ${issues.length} note${issues.length === 1 ? '' : 's'}` })
      : el('div', { class: 't', style: 'margin-top:10px', text: 'Validation: clean ✓' }),
    ...issues.slice(0, 5).map(i => el('div', { class: 'ac-file', style: `color:${i.level === 'error' ? 'var(--err)' : 'var(--warn)'};font-family:var(--font)` }, i.msg)),
    entry ? el('div', { class: 'ac-actions' },
      el('button', { class: 'ghost-btn tiny', type: 'button', onclick: () => switchView('preview') }, 'Open preview'),
      el('button', { class: 'ghost-btn tiny', type: 'button', onclick: () => switchView('files') }, 'View files'),
    ) : null,
  );
  return node;
}

function scrollChatToEnd() {
  const s = $('#chatScroll');
  requestAnimationFrame(() => { s.scrollTop = s.scrollHeight; });
}

/* Live agent card, tied to real operations. */
function createLiveCard() {
  const stepsBox = el('div', { class: 'ac-steps' });
  const filesBox = el('div', { class: 'ac-files', hidden: true },
    el('div', { class: 't', text: 'Files' }));
  const head = el('div', { class: 'ac-head' },
    el('span', { class: 'dot' }),
    el('span', { text: 'AI Coding Agent' }));
  const card = el('div', { class: 'agent-card' }, head, stepsBox, filesBox);
  const wrap = el('div', { class: 'msg ai' },
    el('div', { class: 'av', text: (State.settings.assistantName || 'N').charAt(0).toUpperCase() }),
    card,
  );
  $('#messages').append(wrap);
  scrollChatToEnd();

  const stepMap = new Map();
  return {
    node: card,
    setActive(label, sub) {
      for (const [k, s] of stepMap) if (s.dataset.s === 'active') s.dataset.s = 'done';
      let row = stepMap.get(label);
      if (!row) {
        row = el('div', { class: 'ac-step', 'data-s': 'active' },
          el('span', { class: 'ic', text: '◌' }),
          el('span', {}, el('span', { text: label }), el('span', { class: 'sub' })));
        stepMap.set(label, row);
        stepsBox.append(row);
      }
      row.dataset.s = 'active';
      row.querySelector('.sub').textContent = sub ? `· ${sub}` : '';
      row.querySelector('.ic').textContent = '◌';
      scrollChatToEnd();
    },
    complete(label) {
      const row = stepMap.get(label);
      if (row) { row.dataset.s = 'done'; row.querySelector('.ic').textContent = '✓'; }
    },
    note(text) {
      const row = el('div', { class: 'ac-step', 'data-s': 'fail' },
        el('span', { class: 'ic', text: '!' }), el('span', { text }));
      stepsBox.append(row);
      scrollChatToEnd();
    },
    addFile(rec) {
      filesBox.hidden = false;
      filesBox.append(el('div', { class: 'ac-file' },
        el('span', { class: `tag ${rec.kind}`, text: rec.kind === 'new' ? 'new' : rec.kind === 'del' ? 'deleted' : 'updated' }),
        el('b', { text: rec.path }),
        el('span', { class: 'sz', text: rec.bytes != null ? `${rec.bytes} B` : '' }),
      ));
      scrollChatToEnd();
    },
    finish(state = 'done') {
      head.classList.add(state);
      for (const [, s] of stepMap) if (s.dataset.s === 'active') { s.dataset.s = state === 'fail' ? 'fail' : 'done'; s.querySelector('.ic').textContent = state === 'fail' ? '✕' : '✓'; }
    },
  };
}

/* =========================================================
   Send / agent run
   ========================================================= */
function setBusy(on, label) {
  State.busy = on;
  $('#btnSend').disabled = on;
  $('#agentStrip').hidden = !on;
  if (on && label) $('#agentStripText').textContent = label;
  if (!on) $('#btnStop').hidden = true;
}

function setStrip(label) {
  $('#agentStrip').hidden = false;
  $('#agentStripText').textContent = label;
}

function addMessage(role, text, card) {
  const msg = { id: uid('m'), role, text, ts: Date.now(), ...(card ? { card } : {}) };
  State.project = Projects.addMessage(State.project.id, msg);
  Profile.bump('messages');
  return msg;
}

async function send(textOverride) {
  if (State.busy) return;
  const input = $('#input');
  const text = (textOverride ?? input.value).trim();
  if (!text) return;
  if (!State.settings.apiKey) {
    toast('Add your Gemini API key in Settings first.', 'err');
    switchView('settings');
    return;
  }

  input.value = '';
  autosize(input);
  VoiceOut.stop();

  addMessage('user', text);
  renderChat();

  const intent = State.settings.autoCode
    ? detectIntent(text, State.project)
    : { mode: 'chat', confidence: 1, reason: 'auto coding mode disabled' };

  State.pendingEntry = null;
  const controller = new AbortController();
  State.abort = controller;
  setBusy(true, 'Understanding request…');
  $('#btnStop').hidden = false;

  const projectSnapshot = Projects.get(State.project.id);

  try {
    if (intent.mode === 'chat') {
      await runChat(text, controller.signal);
    } else {
      await runCoding(text, intent, controller.signal);
    }
  } catch (err) {
    if (err.name === 'AbortError') {
      addMessage('assistant', 'Stopped. Nothing else was changed.');
      renderChat();
      addConsole('warn', 'request aborted by user');
    } else {
      const friendly = err instanceof ApiError ? err.message : (err.message || 'Something went wrong.');
      addMessage('assistant', `${friendly}${err.status === 401 || err.status === 403 ? ' You can update the key in Settings.' : ''}`);
      renderChat();
      addConsole('err', friendly);
      if (err.status === 401 || err.status === 403) setConn('err', 'Key rejected');
    }
  } finally {
    setBusy(false);
    State.abort = null;
  }
}

/* --- conversational turn --- */
async function runChat(text, signal) {
  setStrip('Thinking…');
  let live = null;

  const out = await runChatTurn({
    settings: State.settings,
    project: Projects.get(State.project.id),
    userText: text,
    signal,
    onDelta: (_piece, full) => {
      if (!live) {
        live = el('div', { class: 'msg ai' },
          el('div', { class: 'av', text: (State.settings.assistantName || 'N').charAt(0).toUpperCase() }),
          el('div', { class: 'bubble' }, el('div', { class: 'typing' }, el('i'), el('i'), el('i'))),
        );
        $('#messages').append(live);
      }
      live.querySelector('.bubble').innerHTML = renderMarkdown(full);
      scrollChatToEnd();
    },
    onEvent: ev => {
      if (ev.type === 'retry') setStrip(`Retrying — ${ev.reason} (attempt ${ev.attempt})`);
      if (ev.type === 'fallback') {
        setStrip(`Switching to ${ev.to}…`);
        toast(`${ev.from} was unavailable — using ${ev.to} instead.`, 'info');
      }
    },
  });

  if (live) live.remove();
  const reply = (out.text || '').trim() || 'I did not get a response back — try again.';
  addMessage('assistant', reply);
  renderChat();
  addConsole('info', `chat reply via ${out.model}`);

  if (State.settings.voiceOut) {
    VoiceOut.speak(reply, { voiceName: State.settings.voiceName, rate: State.settings.rate });
  }
}

/* --- coding turn: the real agent loop --- */
async function runCoding(text, intent, signal) {
  const live = createLiveCard();
  const started = Date.now();

  live.setActive('Analyzing request', intent.reason);
  addConsole('cmd', `agent run · mode=${intent.mode} · model=${State.settings.model}`);

  const project = Projects.get(State.project.id);
  const isNew = intent.mode === 'build' && Object.keys(project.files || {}).filter(f => !f.endsWith('README.md')).length === 0;

  live.complete('Analyzing request');
  live.setActive('Planning');

  const out = await runCodingTurn({
    settings: State.settings,
    project,
    userText: text,
    mode: intent.mode,
    signal,
    onEvent: ev => {
      if (ev.type === 'retry') {
        live.setActive('Planning', `retrying ${ev.model} — ${ev.reason}`);
        setStrip(`Model busy — retrying in ${Math.round(ev.waitMs / 1000)}s…`);
      }
      if (ev.type === 'fallback') {
        live.setActive('Planning', `falling back to ${ev.to}`);
        setStrip(`Switching to ${ev.to}…`);
        toast(`${ev.from} was overloaded — continuing on ${ev.to}.`, 'info');
      }
      if (ev.type === 'repair') {
        live.note(`Response was unusable (${ev.reason}) — automatically retrying`);
        addConsole('warn', `auto-repair: ${ev.reason}`);
        setStrip('Repairing the response…');
      }
    },
  });

  const { parsed, ops } = out;
  live.complete('Planning');

  // New project naming
  if (isNew && parsed.projectName) {
    State.project = Projects.update(State.project.id, p => { p.name = String(parsed.projectName).slice(0, 60); return p; });
    renderProjects(); renderTopbar();
  } else if (isNew && !parsed.projectName && State.project.name === 'Untitled project') {
    State.project = Projects.update(State.project.id, p => { p.name = fallbackName(text); return p; });
    renderProjects(); renderTopbar();
  }

  // Apply operations against the freshly re-read project.
  live.setActive('Creating files');
  setStrip('Writing files…');
  const { applied, errors, previewEntry } = applyOperations(State.project.id, ops, {
    onStep: rec => {
      live.setActive('Writing code', rec.path);
      live.addFile(rec);
      addConsole('ok', `${rec.kind === 'new' ? 'created' : rec.kind === 'del' ? 'deleted' : 'updated'} ${rec.path}`);
    },
  });
  for (const e of errors) {
    live.note(`${e.path || e.op}: ${e.message}`);
    addConsole('err', `${e.op} ${e.path || ''} — ${e.message}`);
  }
  live.complete('Creating files');
  live.complete('Writing code');

  State.project = Projects.get(State.project.id);

  // Validate + auto-repair
  live.setActive('Validating');
  setStrip('Validating project…');
  let issues = validateProject(State.project);
  addConsole(issues.length ? 'warn' : 'ok', issues.length ? `validation: ${issues.length} issue(s)` : 'validation: no issues');

  const hardErrors = issues.filter(i => i.level === 'error');
  if (hardErrors.length && State.settings.autoRepair) {
    live.setActive('Fixing errors', `${hardErrors.length} to address`);
    setStrip('Fixing errors…');
    try {
      const fixed = await runValidationFix({
        settings: State.settings,
        project: State.project,
        issues: hardErrors,
        signal,
        onEvent: () => {},
      });
      if (fixed.parsed) {
        const res2 = applyOperations(State.project.id, fixed.ops, { onStep: r => live.addFile(r) });
        State.project = Projects.get(State.project.id);
        for (const a of res2.applied) addConsole('ok', `fix applied: ${a.path}`);
        issues = validateProject(State.project);
        addConsole(issues.filter(i => i.level === 'error').length ? 'warn' : 'ok',
          `re-validation: ${issues.filter(i => i.level === 'error').length} error(s) remaining`);
      }
    } catch (err) {
      addConsole('warn', `auto-repair could not complete: ${err.message}`);
    }
  }
  live.complete('Validating');
  live.complete('Fixing errors');

  // Preview
  const entry = previewEntry || findEntry(State.project);
  if (entry && State.settings.autoPreview) {
    live.setActive('Starting preview');
    setStrip('Starting preview…');
    const res = State.preview.render(State.project, entry);
    if (res.ok) {
      addConsole('cmd', 'starting preview…');
      addConsole('ok', `preview ready · ${res.entry} · ${res.inlined.length} asset(s) inlined`);
      $('#previewEmpty').hidden = true;
      $('#device').classList.remove('is-hidden');
      $('#consoleBadge').textContent = String(State.consoleLines.length);
      live.complete('Starting preview');
      live.setActive('Ready');
      live.complete('Ready');
    } else {
      live.note(`preview unavailable — ${res.reason}`);
      addConsole('warn', `preview unavailable — ${res.reason}`);
      live.complete('Starting preview');
    }
  }

  // Summary of the turn
  const finalIssues = validateProject(State.project);
  State.project = Projects.update(State.project.id, p => {
    p.meta = {
      ...p.meta,
      summary: parsed.summary || p.meta?.summary || '',
      stack: /react|next/i.test(Object.keys(p.files).join(' ')) ? 'react' : 'static',
    };
    return p;
  });

  const summaryText = parsed.message || `Done — ${applied.length} file change${applied.length === 1 ? '' : 's'}.`;
  addMessage('assistant', summaryText, {
    files: applied,
    issues: finalIssues,
    entry,
  });

  live.finish('done');
  renderChat();
  renderFiles();
  renderProjects();

  const elapsed = ((Date.now() - started) / 1000).toFixed(1);
  addConsole('info', `agent turn finished in ${elapsed}s · ${applied.length} file(s)`);

  if (State.settings.voiceOut && summaryText) {
    VoiceOut.speak(summaryText, { voiceName: State.settings.voiceName, rate: State.settings.rate });
  }
}

async function ensurePreview() {
  if (!State.project) return;
  const entry = findEntry(State.project, State.pendingEntry);
  if (!entry) {
    $('#previewEmpty').hidden = false;
    $('#device').classList.add('is-hidden');
    return;
  }
  syncDeviceViewport();
  const res = State.preview.render(State.project, entry);
  $('#previewEmpty').hidden = res.ok;
  $('#device').classList.toggle('is-hidden', !res.ok);
}

/* =========================================================
   Files
   ========================================================= */
function renderFiles() {
  const tree = $('#fileTree');
  tree.innerHTML = '';
  $('#filesProjectName').textContent = State.project?.name || 'Files';

  const files = Object.keys(State.project?.files || {}).filter(f => !f.endsWith('/.keep')).sort();
  if (!files.length) {
    tree.append(el('p', { class: 'hint', style: 'padding:10px', text: 'No files yet.' }));
    return;
  }

  for (const path of files) {
    const depth = path.split('/').length - 1;
    const name = path.split('/').pop();
    const bytes = (State.project.files[path].content || '').length;
    const isHtml = /\.html?$/i.test(path);
    tree.append(el('button', {
      class: `node${State.activeFile === path ? ' is-on' : ''}`,
      type: 'button',
      'data-depth': String(Math.min(depth, 3)),
      onclick: () => selectFile(path),
    },
      el('span', { class: 'ic', text: isHtml ? '📄' : /\.css$/i.test(path) ? '🎨' : /\.js$/i.test(path) ? '⚙️' : /\.md$/i.test(path) ? '📘' : '📄' }),
      el('span', { text: name }),
      el('span', { class: 'sz', text: `${bytes} B` }),
    ));
  }

  const ed = $('#editor');
  if (State.activeFile && State.project.files[State.activeFile]) {
    $('#editorPath').textContent = State.activeFile;
    if (ed.dataset.path !== State.activeFile) {
      ed.value = State.project.files[State.activeFile].content;
      ed.dataset.path = State.activeFile;
      ed.dataset.dirty = '0';
    }
    $('#btnSaveFile').disabled = false;
    $('#btnDeleteFile').disabled = false;
    $('#btnRenameFile').disabled = false;
  } else {
    $('#editorPath').textContent = 'No file selected';
    ed.value = '';
    ed.dataset.path = '';
  }
}

function selectFile(path) {
  State.activeFile = path;
  renderFiles();
}

function saveActiveFile() {
  const ed = $('#editor');
  const path = ed.dataset.path;
  if (!path) return;
  try {
    State.project = Projects.writeFile(State.project.id, path, ed.value);
    ed.dataset.dirty = '0';
    addConsole('ok', `saved ${path}`);
    renderFiles(); renderProjects();
    if (State.settings.autoPreview && /\.(html?|css|js)$/i.test(path)) {
      ensurePreview();
      addConsole('info', 'preview refreshed after edit');
    }
    toast(`${path} saved.`, 'ok');
  } catch (err) {
    toast(err.message, 'err');
  }
}

/* =========================================================
   Console
   ========================================================= */
function addConsole(kind, text) {
  const line = { kind, text, ts: new Date() };
  State.consoleLines.push(line);
  if (State.consoleLines.length > 400) State.consoleLines.shift();
  const body = $('#consoleBody');
  const node = el('div', { class: 'cl', 'data-k': kind },
    el('span', { class: 'ts', text: line.ts.toTimeString().slice(0, 8) }),
    el('span', { text }),
  );
  body.append(node);
  body.scrollTop = body.scrollHeight;
  $('#consoleBadge').textContent = String(State.consoleLines.length);
}

/* =========================================================
   ZIP export
   ========================================================= */
function downloadZip(project = State.project) {
  if (!project) return;
  const files = Object.keys(project.files || {}).filter(f => !f.endsWith('/.keep'));
  if (!files.length) { toast('This project has no files to export.', 'err'); return; }
  const blob = zipProject(project);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${slugify(project.name)}.zip`;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  addConsole('ok', `exported ${files.length} file(s) as ${a.download}`);
  toast(`Downloaded ${a.download}`, 'ok');
}

/* =========================================================
   Publish
   ========================================================= */
async function doPublish() {
  if (!State.project) return;
  const provider = State.settings.provider;
  if (!provider || provider === 'none') {
    openModal({
      title: 'Connect a publishing provider',
      body: el('p', { class: 'sub', text: 'Choose where this site should go in Settings → Publishing. Netlify and GitHub Pages publish straight from the browser with your own token. Cloudflare and Vercel need the bundled proxy.' }),
      actions: [{ label: 'Open settings', primary: true, onClick: () => switchView('settings') }],
    });
    return;
  }

  const body = el('div', {},
    el('p', { class: 'sub', text: `Publishing “${State.project.name}” to ${PROVIDERS[provider].label}.` }),
    el('div', { class: 'console-body', style: 'max-height:30vh;border:1px solid var(--stroke);border-radius:12px;padding:10px' }),
  );
  const log = body.querySelector('.console-body');
  const put = (step, detail) => {
    log.append(el('div', { class: 'cl', 'data-k': 'info' }, el('span', { text: `$ ${step}${detail ? ` · ${detail}` : ''}` })));
    log.scrollTop = log.scrollHeight;
  };
  const close = openModal({ title: 'Publishing…', body, actions: [] });

  try {
    const result = await publish({
      settings: State.settings,
      project: State.project,
      onEvent: e => put(e.step, e.detail),
    });
    log.append(el('div', { class: 'cl', 'data-k': 'ok' }, el('span', { text: `✓ deploy ${result.deployId || ''} complete` })));
    State.project = Projects.update(State.project.id, p => {
      p.meta = { ...p.meta, lastDeploy: result };
      return p;
    });
    addConsole('ok', `published to ${result.url}`);

    close();
    openModal({
      title: 'Published successfully',
      body: el('div', {},
        el('div', { class: 'deploy-result' },
          el('div', { text: `Provider: ${PROVIDERS[result.provider].label}` }),
          el('div', { style: 'margin-top:6px' }, el('a', { href: result.url, target: '_blank', rel: 'noopener', text: result.url })),
          el('div', { style: 'margin-top:6px', text: `Project: ${State.project.name}` }),
          el('div', { text: `Files: ${result.filesUploaded}` }),
          el('div', { text: `Deployed: ${new Date(result.at).toLocaleString()}` }),
          result.note ? el('div', { class: 'muted', style: 'margin-top:6px', text: result.note }) : null,
        ),
      ),
      actions: [
        { label: 'Copy URL', onClick: () => copyText(result.url) },
        { label: 'Open website', primary: true, onClick: () => window.open(result.url, '_blank', 'noopener') },
      ],
    });
  } catch (err) {
    log.append(el('div', { class: 'cl', 'data-k': 'err' }, el('span', { text: `✕ ${err.message}` })));
    toast(err.message, 'err', 6000);
    addConsole('err', `publish failed: ${err.message}`);
    if (err.needsProxy) {
      close();
      openModal({
        title: 'That provider needs the proxy',
        body: el('p', { class: 'sub', text: `${PROVIDERS[provider].label} does not accept requests from a web page. Start the bundled proxy with “node server/proxy.js”, then paste its URL into Settings → Publishing and publish again.` }),
        actions: [{ label: 'Open settings', primary: true, onClick: () => switchView('settings') }],
      });
    }
  }
}

function copyText(text) {
  navigator.clipboard?.writeText(text)
    .then(() => toast('Copied.', 'ok', 1800))
    .catch(() => toast('Could not copy automatically.', 'err'));
}

/* =========================================================
   Settings
   ========================================================= */
function fillSettingsForm() {
  const s = State.settings;
  $('#setName').value = s.assistantName || '';
  $('#setKey').value = s.apiKey || '';
  fillModelSelect($('#setModel'), s.knownModels, s.model);
  $('#setVoice').checked = !!s.voiceOut;
  $('#setRate').value = String(s.rate ?? 1);
  $('#rateVal').textContent = `${Number(s.rate ?? 1).toFixed(2).replace(/0$/, '')}×`;
  $('#setAutoCode').checked = !!s.autoCode;
  $('#setAutoPreview').checked = !!s.autoPreview;
  $('#setAutoRepair').checked = !!s.autoRepair;
  $('#setStream').checked = !!s.stream;
  $('#setTheme').value = s.theme || 'midnight';
  $('#setProvider').value = s.provider || 'none';
  $('#voiceSupportHint').textContent = VoiceOut.supported()
    ? (recognitionSupported() ? 'Microphone and speech output are both available.' : 'Speech output available. Microphone input is not supported in this browser — typing still works.')
    : 'This browser has no speech synthesis. All replies stay on screen as text.';

  fillVoiceSelect();
  renderProviderFields();
  updateStorageHint();
}

function fillVoiceSelect() {
  const sel = $('#setVoiceName');
  const voices = VoiceOut.ready ? VoiceOut.voices() : [];
  if (!voices.length) {
    sel.innerHTML = '<option value="">Default voice</option>';
    return;
  }
  sel.innerHTML = '<option value="">Default (auto)</option>' + voices
    .map(v => `<option value="${escapeHtml(v.name)}">${escapeHtml(v.name)} · ${v.lang}</option>`).join('');
  sel.value = State.settings.voiceName || '';
}

const PROVIDER_FIELD_META = {
  netlifyToken:     { label: 'Netlify personal access token', type: 'password', hint: 'Create one at app.netlify.com → User settings → Applications.' },
  netlifySiteName:  { label: 'Site name (optional)', type: 'text', hint: 'Leave blank to let Netlify generate one.' },
  ghToken:          { label: 'GitHub token (repo scope)', type: 'password', hint: 'A classic PAT with the “repo” scope, or a fine-grained token with Contents + Pages write.' },
  ghOwner:          { label: 'Owner (user or org)', type: 'text' },
  ghRepo:           { label: 'Repository name', type: 'text' },
  cfToken:          { label: 'Cloudflare API token', type: 'password' },
  cfAccountId:      { label: 'Cloudflare account ID', type: 'text' },
  vercelToken:      { label: 'Vercel access token', type: 'password' },
  proxyUrl:         { label: 'Proxy URL', type: 'text', hint: 'Where server/proxy.js is running, e.g. http://localhost:8787' },
};

function renderProviderFields() {
  const host = $('#providerFields');
  host.innerHTML = '';
  const provider = $('#setProvider').value;
  const meta = PROVIDERS[provider];
  if (!meta || !meta.fields.length) {
    host.append(el('p', { class: 'hint', text: 'No credentials needed.' }));
    return;
  }
  const cfg = State.settings.providerConfig || {};
  for (const key of meta.fields) {
    const m = PROVIDER_FIELD_META[key] || { label: key, type: 'text' };
    host.append(el('label', { class: 'field' },
      el('span', { class: 'field-label', text: m.label }),
      el('input', {
        type: m.type || 'text',
        'data-cfg': key,
        value: cfg[key] || '',
        autocomplete: 'off',
        spellcheck: 'false',
      }),
      m.hint ? el('span', { class: 'hint', text: m.hint }) : null,
    ));
  }
  if (!meta.browser) {
    host.append(el('div', { class: 'row-actions' },
      el('button', { class: 'ghost-btn', type: 'button', onclick: async () => {
        const url = $('input[data-cfg=proxyUrl]')?.value || State.settings.providerConfig?.proxyUrl;
        const res = await pingProxy(url);
        toast(res.ok ? `Proxy reachable — providers: ${(res.providers || []).join(', ') || 'unknown'}` : res.reason, res.ok ? 'ok' : 'err');
      } }, 'Test proxy'),
    ));
  }
}

function updateStorageHint() {
  const bytes = Projects.storageUsed();
  $('#storageHint').textContent = `Using ${(bytes / 1024).toFixed(1)} KB of browser storage across ${Projects.all().length} project(s).`;
}

function saveSettings() {
  const cfg = { ...(State.settings.providerConfig || {}) };
  $$('#providerFields input[data-cfg]').forEach(i => { cfg[i.dataset.cfg] = i.value.trim(); });

  State.settings = Settings.set({
    assistantName: $('#setName').value.trim() || 'Nova',
    apiKey: $('#setKey').value.trim(),
    model: $('#setModel').value,
    voiceOut: $('#setVoice').checked,
    voiceName: $('#setVoiceName').value,
    rate: Number($('#setRate').value),
    theme: $('#setTheme').value,
    autoCode: $('#setAutoCode').checked,
    autoPreview: $('#setAutoPreview').checked,
    autoRepair: $('#setAutoRepair').checked,
    stream: $('#setStream').checked,
    provider: $('#setProvider').value,
    providerConfig: cfg,
  });

  applyTheme(State.settings.theme);
  renderTopbar();
  renderProfile();
  updateStorageHint();
  toast('Settings saved.', 'ok');
  if (State.settings.apiKey) probeConnection({ silent: true });
}

function renderProfile() {
  const p = Profile.get();
  $('#profileName').value = p.name || '';
  $('#statProjects').textContent = String(Projects.all().length);
  $('#statFiles').textContent = String(p.filesCreated || 0);
  $('#statMsgs').textContent = String(p.messages || 0);
  $('#prefSummary').innerHTML = `
    <div><span>Assistant name</span><span>${escapeHtml(State.settings.assistantName || 'Nova')}</span></div>
    <div><span>Model</span><span>${escapeHtml(State.settings.model || '—')}</span></div>
    <div><span>Auto coding mode</span><span>${State.settings.autoCode ? 'On' : 'Off'}</span></div>
    <div><span>Voice output</span><span>${State.settings.voiceOut ? 'On' : 'Off'}</span></div>
    <div><span>Theme</span><span>${escapeHtml(State.settings.theme)}</span></div>
    <div><span>Publishing</span><span>${escapeHtml(PROVIDERS[State.settings.provider]?.label || 'Not connected')}</span></div>`;
}

/* =========================================================
   Input handling
   ========================================================= */
function autosize(ta) {
  ta.style.height = 'auto';
  ta.style.height = `${Math.min(ta.scrollHeight, 150)}px`;
}

function wireComposer() {
  const input = $('#input');
  input.addEventListener('input', () => autosize(input));
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      send();
    }
  });
  $('#composer').addEventListener('submit', e => { e.preventDefault(); send(); });
  $('#btnStop').addEventListener('click', () => {
    State.abort?.abort();
    if (State.recognizer?.listening) State.recognizer.stop();
    setStatic('Stopping…');
  });
}

function setStatic(text) {
  $('#agentStripText').textContent = text;
}

/* =========================================================
   Voice wiring
   ========================================================= */
function wireVoice() {
  State.recognizer = createRecognizer({
    lang: defaultDictationLang(),
    onPartial: t => setStrip(`🎤 ${t}`),
    onFinal: t => {
      $('#input').value = t;
      autosize($('#input'));
      setBusy(false);
      send();
    },
    onError: (msg, code) => {
      setBusy(false);
      $('#btnMic').classList.remove('is-rec');
      if (msg) toast(msg, 'err');
    },
    onEnd: () => {
      $('#btnMic').classList.remove('is-rec');
      if (State.busy) setBusy(false);
    },
  });

  $('#btnMic').addEventListener('click', () => {
    if (!recognitionSupported()) {
      toast('Speech input is not supported in this browser. Type your message instead.', 'err', 5200);
      return;
    }
    if (State.recognizer.listening) {
      State.recognizer.stop();
      $('#btnMic').classList.remove('is-rec');
      setBusy(false);
      return;
    }
    if (State.busy) { toast('One moment — I am still working on the previous request.', 'info'); return; }
    try {
      State.recognizer.start();
      $('#btnMic').classList.add('is-rec');
      setStrip('Listening…');
    } catch {
      toast('Could not start the microphone.', 'err');
    }
  });
}

/* =========================================================
   Wiring
   ========================================================= */
function wireEverything() {
  wireOnboarding();
  wireComposer();
  wireVoice();

  $('#btnSidebar').addEventListener('click', openSidebar);
  $('#scrim').addEventListener('click', closeSidebar);
  $('#btnNewChat').addEventListener('click', () => { newProject(); toast('New project started.', 'info'); });
  $('#btnNewProject').addEventListener('click', () => newProject());
  $('#btnProfileFromSidebar').addEventListener('click', () => switchView('profile'));
  $('#btnSettings').addEventListener('click', () => switchView('settings'));

  $$('.nav-btn').forEach(b => b.addEventListener('click', () => switchView(b.dataset.go)));

  // Files
  $('#btnSaveFile').addEventListener('click', saveActiveFile);
  $('#editor').addEventListener('input', () => { $('#editor').dataset.dirty = '1'; });
  $('#editor').addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key === 's') { e.preventDefault(); saveActiveFile(); }
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.target, s = ta.selectionStart;
      ta.value = ta.value.slice(0, s) + '  ' + ta.value.slice(ta.selectionEnd);
      ta.selectionStart = ta.selectionEnd = s + 2;
      ta.dataset.dirty = '1';
    }
  });
  $('#btnDownloadZip').addEventListener('click', () => downloadZip());
  $('#btnDeleteFile').addEventListener('click', () => {
    const path = $('#editor').dataset.path;
    if (!path) return;
    openModal({
      title: `Delete ${path}?`,
      body: el('p', { class: 'sub', text: 'The file is removed from this project. Export it first if you want a copy.' }),
      actions: [{
        label: 'Delete', onClick: () => {
          State.project = Projects.deleteFile(State.project.id, path);
          State.activeFile = null;
          $('#editor').dataset.path = '';
          renderFiles(); renderProjects();
          addConsole('ok', `deleted ${path}`);
        },
      }],
    });
  });
  $('#btnRenameFile').addEventListener('click', () => {
    const path = $('#editor').dataset.path;
    if (!path) return;
    const input = el('input', { type: 'text', value: path });
    openModal({
      title: 'Rename file',
      body: el('label', { class: 'field' }, el('span', { class: 'field-label', text: 'New path' }), input),
      actions: [{
        label: 'Rename', primary: true, onClick: () => {
          const to = input.value.trim();
          if (!to || to === path) return;
          State.project = Projects.renameFile(State.project.id, path, to);
          State.activeFile = to;
          $('#editor').dataset.path = to;
          renderFiles(); renderProjects();
          addConsole('ok', `renamed ${path} → ${to}`);
        },
      }],
    });
  });
  $('#btnAddFile').addEventListener('click', () => {
    const input = el('input', { type: 'text', placeholder: 'components/header.html' });
    openModal({
      title: 'New file',
      body: el('label', { class: 'field' }, el('span', { class: 'field-label', text: 'Path' }), input),
      actions: [{
        label: 'Create', primary: true, onClick: () => {
          const path = input.value.trim().replace(/^\.?\//, '');
          if (!path) return;
          State.project = Projects.writeFile(State.project.id, path, '');
          State.activeFile = path;
          renderFiles(); renderProjects();
          addConsole('ok', `created ${path}`);
        },
      }],
    });
  });

  // Preview
  $$('.seg-btn').forEach(b => b.addEventListener('click', () => {
    $$('.seg-btn').forEach(x => { x.classList.remove('is-on'); x.setAttribute('aria-selected', 'false'); });
    b.classList.add('is-on'); b.setAttribute('aria-selected', 'true');
    $('#device').dataset.vp = b.dataset.vp;
    syncDeviceViewport();
  }));
  $('#btnRefreshPreview').addEventListener('click', () => { ensurePreview(); addConsole('cmd', 'preview refreshed'); });
  $('#btnOpenPreview').addEventListener('click', () => {
    if (!State.preview.openTab()) toast('Nothing to open yet — build something first.', 'err');
  });
  $('#btnPublish').addEventListener('click', doPublish);
  $('#btnConsoleToggle').addEventListener('click', () => {
    const body = $('#consoleBody');
    const open = body.hidden;
    body.hidden = !open;
    $('#btnConsoleToggle').setAttribute('aria-expanded', String(open));
  });

  // Settings
  $('#setKeyToggle').addEventListener('click', () => {
    const f = $('#setKey');
    f.type = f.type === 'password' ? 'text' : 'password';
  });
  $('#setProvider').addEventListener('change', () => {
    // remember typed values before re-rendering
    const cfg = { ...(State.settings.providerConfig || {}) };
    $$('#providerFields input[data-cfg]').forEach(i => { cfg[i.dataset.cfg] = i.value.trim(); });
    State.settings = Settings.set({ providerConfig: cfg, provider: $('#setProvider').value });
    renderProviderFields();
  });
  $('#setRate').addEventListener('input', e => {
    $('#rateVal').textContent = `${Number(e.target.value).toFixed(2).replace(/0$/, '')}×`;
  });
  $('#setTheme').addEventListener('change', e => applyTheme(e.target.value));
  $('#setVoice').addEventListener('change', async e => {
    if (e.target.checked) { await VoiceOut.ready(); fillVoiceSelect(); }
  });
  $('#btnSaveSettings').addEventListener('click', saveSettings);
  $('#btnTestKey').addEventListener('click', async () => {
    const key = $('#setKey').value.trim() || State.settings.apiKey;
    const pill = $('#keyStatus');
    if (!key) { pill.hidden = false; pill.dataset.kind = 'err'; pill.textContent = 'No key entered'; return; }
    pill.hidden = false; pill.dataset.kind = 'busy'; pill.textContent = 'Testing…';
    try {
      const out = await testKey(key, $('#setModel').value);
      State.settings = Settings.set({ apiKey: key, knownModels: out.models, model: out.model });
      fillModelSelect($('#setModel'), out.models, out.model);
      pill.dataset.kind = 'ok'; pill.textContent = `Connected · ${out.model}`;
      setConn('ok', 'Connected');
      toast(`Connected. Model replied: “${out.reply}”`, 'ok');
    } catch (err) {
      pill.dataset.kind = 'err'; pill.textContent = err.message || 'Failed';
      setConn('err', 'Key rejected');
      toast(err.message || 'Connection failed.', 'err', 6000);
    }
  });
  $('#btnRemoveKey').addEventListener('click', () => {
    State.settings = Settings.set({ apiKey: '' });
    $('#setKey').value = '';
    setConn('unknown', 'No API key');
    toast('API key removed from this browser.', 'info');
  });
  $('#btnRefreshModels').addEventListener('click', () => refreshModelList());
  $('#btnExportAll').addEventListener('click', () => {
    const all = Projects.all();
    if (!all.length) { toast('No projects to export.', 'err'); return; }
    const bundle = {
      exportedAt: new Date().toISOString(),
      projects: all.map(p => ({ name: p.name, files: Object.fromEntries(Object.entries(p.files || {}).map(([k, v]) => [k, v.content])) })),
    };
    const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = el('a', { href: url, download: 'nova-projects.json' });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  });
  $('#btnResetAll').addEventListener('click', () => {
    openModal({
      title: 'Reset everything?',
      body: el('p', { class: 'sub', text: 'Deletes all projects, settings, keys and stats from this browser.' }),
      actions: [{
        label: 'Reset', onClick: () => {
          Projects.resetAll();
          location.reload();
        },
      }],
    });
  });

  // Profile
  $('#profileName').addEventListener('input', e => {
    Profile.set({ name: e.target.value });
    renderChat();
  });

  // Global shortcuts
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeSidebar();
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); switchView('chat'); $('#input').focus(); }
  });
  window.addEventListener('beforeunload', () => VoiceOut.stop());

  if (VoiceOut.supported()) {
    window.speechSynthesis.addEventListener?.('voiceschanged', () => {
      if (!$('#view-settings').classList.contains('is-active')) return;
      fillVoiceSelect();
    });
  }
}

function syncDeviceViewport() {
  const vp = $('#device').dataset.vp;
  const frame = $('#previewFrame');
  frame.style.height = '100%';
  if (vp === 'desktop') frame.style.height = '100%';
}

function relTime(ts) {
  if (!ts) return 'just now';
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  if (s < 604800) return `${Math.floor(s / 86400)}d ago`;
  return new Date(ts).toLocaleDateString();
}

/* Expose a tiny debug surface for testing in the console. */
window.Nova = {
  state: State,
  Projects, Settings, Profile,
  send,
  openProject,
  detection: text => detectIntent(text, State.project),
  validate: () => validateProject(Projects.get(State.project.id)),
};

boot().catch(err => {
  console.error(err);
  document.body.innerHTML = `<div style="padding:24px;font-family:system-ui;color:#e8ecf4;background:#0b0d12;min-height:100vh">
    <h2>Nova failed to start</h2><pre style="white-space:pre-wrap;color:#f87171">${escapeHtml(err.stack || err.message)}</pre></div>`;
});
