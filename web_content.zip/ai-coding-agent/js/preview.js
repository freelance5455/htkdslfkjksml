/* =========================================================
   preview.js — in-browser sandbox preview
   Builds a single self-contained document from the project's
   virtual file system by inlining local css/js/img references,
   then serves it to a sandboxed iframe via a blob URL.

   This is a real render of the real files — but it is NOT a
   localhost server, and the UI labels it as a sandbox.
   ========================================================= */

const MIME = {
  html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript',
  mjs: 'text/javascript', json: 'application/json', svg: 'image/svg+xml',
  txt: 'text/plain', md: 'text/markdown',
};

function ext(path) { return (path.split('.').pop() || '').toLowerCase(); }

export function findEntry(project, preferred) {
  const files = Object.keys(project?.files || {});
  if (preferred && files.includes(preferred)) return preferred;
  if (files.includes('index.html')) return 'index.html';
  const root = files.find(f => /^[^/]+\.html?$/i.test(f));
  if (root) return root;
  return files.find(f => /\.html?$/i.test(f)) || null;
}

function resolve(basePath, ref) {
  const clean = ref.split('?')[0].split('#')[0].replace(/^\.\//, '');
  if (clean.startsWith('/')) return clean.slice(1);
  const dir = basePath.includes('/') ? basePath.slice(0, basePath.lastIndexOf('/') + 1) : '';
  const joined = dir + clean;
  // normalise ../
  const parts = [];
  for (const seg of joined.split('/')) {
    if (seg === '..') parts.pop();
    else if (seg !== '.' && seg !== '') parts.push(seg);
  }
  return parts.join('/');
}

function isExternal(ref) {
  return /^(https?:|data:|blob:|mailto:|tel:|#|\/\/)/i.test(ref);
}

/* Console + error bridge injected into every preview. */
const BRIDGE = `
<script>
(function(){
  var send = function(kind, args){
    try {
      parent.postMessage({ __novaPreview: true, kind: kind, text: Array.prototype.map.call(args, function(a){
        if (a instanceof Error) return a.message;
        if (typeof a === 'object') { try { return JSON.stringify(a); } catch(e){ return String(a); } }
        return String(a);
      }).join(' ') }, '*');
    } catch(e){}
  };
  ['log','info','warn','error'].forEach(function(m){
    var orig = console[m].bind(console);
    console[m] = function(){ send(m === 'log' ? 'info' : m, arguments); orig.apply(null, arguments); };
  });
  window.addEventListener('error', function(e){
    send('error', [(e.message || 'Script error') + (e.filename ? ' — ' + e.filename.split('/').pop() + ':' + e.lineno : '')]);
  });
  window.addEventListener('unhandledrejection', function(e){
    send('error', ['Unhandled promise rejection: ' + (e.reason && e.reason.message ? e.reason.message : e.reason)]);
  });
  document.addEventListener('click', function(e){
    var a = e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if (href.startsWith('#') || href.startsWith('javascript:')) return;
    if (/^https?:/i.test(href)) { e.preventDefault(); send('info', ['Blocked navigation to ' + href + ' (sandbox preview)']); }
  }, true);
  send('info', ['preview loaded']);
})();
<\/script>`;

/* Build a single HTML document with all local assets inlined. */
export function buildDocument(project, entryPath) {
  const files = project.files || {};
  const entry = files[entryPath];
  if (!entry) return null;

  let html = entry.content;
  const inlined = [];

  // <link rel=stylesheet href="local.css">
  html = html.replace(/<link\b[^>]*>/gi, tag => {
    const relM = tag.match(/rel\s*=\s*["']?([^"'\s>]+)/i);
    const hrefM = tag.match(/href\s*=\s*["']([^"']+)["']/i);
    if (!hrefM || !relM || !/stylesheet/i.test(relM[1])) return tag;
    const href = hrefM[1];
    if (isExternal(href)) return tag;
    const target = resolve(entryPath, href);
    if (!files[target]) return `<!-- missing stylesheet: ${href} -->`;
    inlined.push(target);
    return `<style data-src="${target}">\n${files[target].content}\n</style>`;
  });

  // <script src="local.js">
  html = html.replace(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi, (tag, attrs, body) => {
    const srcM = attrs.match(/src\s*=\s*["']([^"']+)["']/i);
    if (!srcM) return tag;
    const src = srcM[1];
    if (isExternal(src)) return tag;
    const target = resolve(entryPath, src);
    if (!files[target]) return `<!-- missing script: ${src} -->`;
    inlined.push(target);
    const type = /type\s*=\s*["']module["']/i.test(attrs) ? ' type="module"' : '';
    return `<script${type} data-src="${target}">\n${files[target].content}\n<\/script>`;
  });

  // <img src="local.svg"> and CSS url() for svg assets held in the project
  html = html.replace(/(<img\b[^>]*\bsrc\s*=\s*)["']([^"']+)["']/gi, (m, pre, src) => {
    if (isExternal(src)) return m;
    const target = resolve(entryPath, src);
    const f = files[target];
    if (!f) return m;
    const e = ext(target);
    if (e === 'svg') return `${pre}"data:image/svg+xml;charset=utf-8,${encodeURIComponent(f.content)}"`;
    return m;
  });

  // Base target so any surviving link opens in a new tab rather than the frame.
  const head = html.match(/<head[^>]*>/i);
  const injection = `${BRIDGE}\n<base target="_blank">`;
  html = head
    ? html.replace(head[0], `${head[0]}\n${injection}`)
    : `${injection}\n${html}`;

  return { html, inlined: [...new Set(inlined)] };
}

/* ---------------------------------------------------------
   Preview controller — owns the blob URL lifecycle.
   --------------------------------------------------------- */
export class Preview {
  constructor(iframe, { onConsole } = {}) {
    this.iframe = iframe;
    this.onConsole = onConsole;
    this.url = null;
    this.entry = null;

    this._onMessage = e => {
      const d = e.data;
      if (!d || d.__novaPreview !== true) return;
      if (d.kind === 'info' && d.text === 'preview loaded') return;   // internal handshake
      this.onConsole?.(d.kind, d.text);
    };
    window.addEventListener('message', this._onMessage);
  }

  render(project, preferredEntry) {
    const entry = findEntry(project, preferredEntry);
    if (!entry) return { ok: false, reason: 'no HTML file in this project' };

    const built = buildDocument(project, entry);
    if (!built) return { ok: false, reason: `entry file ${entry} is missing` };

    this.revoke();
    const blob = new Blob([built.html], { type: 'text/html' });
    this.url = URL.createObjectURL(blob);
    this.entry = entry;
    this.iframe.src = this.url;
    return { ok: true, entry, inlined: built.inlined, bytes: built.html.length };
  }

  openTab() {
    if (!this.url) return false;
    window.open(this.url, '_blank', 'noopener');
    return true;
  }

  revoke() {
    if (this.url) { URL.revokeObjectURL(this.url); this.url = null; }
  }

  destroy() {
    window.removeEventListener('message', this._onMessage);
    this.revoke();
  }
}

/* ---------------------------------------------------------
   Export the project as a .zip using a minimal store-only
   ZIP writer (no compression, no dependency).
   --------------------------------------------------------- */

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
    t[i] = c >>> 0;
  }
  return t;
})();

function crc32(bytes) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

export function zipProject(project) {
  const enc = new TextEncoder();
  const entries = Object.entries(project.files || {})
    .filter(([p]) => !p.endsWith('/.keep'));

  const chunks = [];
  const central = [];
  let offset = 0;

  const u16 = n => [n & 0xFF, (n >>> 8) & 0xFF];
  const u32 = n => [n & 0xFF, (n >>> 8) & 0xFF, (n >>> 16) & 0xFF, (n >>> 24) & 0xFF];

  for (const [path, file] of entries) {
    const nameBytes = enc.encode(path);
    const data = enc.encode(file.content ?? '');
    const crc = crc32(data);

    const local = new Uint8Array([
      ...u32(0x04034b50), ...u16(20), ...u16(0), ...u16(0),
      ...u16(0), ...u16(0),                    // time, date
      ...u32(crc), ...u32(data.length), ...u32(data.length),
      ...u16(nameBytes.length), ...u16(0),
    ]);
    chunks.push(local, nameBytes, data);

    central.push(new Uint8Array([
      ...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0), ...u16(0),
      ...u16(0), ...u16(0),
      ...u32(crc), ...u32(data.length), ...u32(data.length),
      ...u16(nameBytes.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0),
      ...u32(0), ...u32(offset),
    ]), nameBytes);

    offset += local.length + nameBytes.length + data.length;
  }

  const centralSize = central.reduce((n, c) => n + c.length, 0);
  const end = new Uint8Array([
    ...u32(0x06054b50), ...u16(0), ...u16(0),
    ...u16(entries.length), ...u16(entries.length),
    ...u32(centralSize), ...u32(offset), ...u16(0),
  ]);

  return new Blob([...chunks, ...central, end], { type: 'application/zip' });
}
