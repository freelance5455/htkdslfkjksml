/* =========================================================
   store.js — persistence for settings, projects, chats
   Everything lives in localStorage. No network, no telemetry.
   ========================================================= */

const NS = 'nova.v1';
const K = {
  settings: `${NS}.settings`,
  projects: `${NS}.projects`,
  active:   `${NS}.activeProject`,
  profile:  `${NS}.profile`,
  onboard:  `${NS}.onboarded`,
};

const DEFAULT_SETTINGS = {
  apiKey: '',
  model: 'gemini-2.5-flash',
  knownModels: [],          // populated from ListModels
  assistantName: 'Nova',
  voiceOut: false,
  voiceName: '',
  rate: 1.0,
  theme: 'midnight',
  autoCode: true,
  autoPreview: true,
  autoRepair: true,
  stream: true,
  provider: 'none',
  providerConfig: {},       // { netlifyToken, netlifySiteId, ghToken, ghOwner, ghRepo, proxyUrl }
};

const DEFAULT_PROFILE = { name: '', filesCreated: 0, messages: 0 };

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw == null) return structuredClone(fallback);
    const parsed = JSON.parse(raw);
    return parsed ?? structuredClone(fallback);
  } catch {
    return structuredClone(fallback);
  }
}

function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (err) {
    // Quota exceeded is the realistic failure here.
    console.warn('storage write failed', key, err);
    return false;
  }
}

/* ---------------- Settings ---------------- */

export const Settings = {
  get() {
    return { ...DEFAULT_SETTINGS, ...read(K.settings, DEFAULT_SETTINGS) };
  },
  set(patch) {
    const next = { ...Settings.get(), ...patch };
    write(K.settings, next);
    return next;
  },
  reset() { localStorage.removeItem(K.settings); },
};

/* ---------------- Profile ---------------- */

export const Profile = {
  get() { return { ...DEFAULT_PROFILE, ...read(K.profile, DEFAULT_PROFILE) }; },
  set(patch) { const n = { ...Profile.get(), ...patch }; write(K.profile, n); return n; },
  bump(field, by = 1) { const p = Profile.get(); p[field] = (p[field] || 0) + by; write(K.profile, p); return p; },
};

/* ---------------- Onboarding flag ---------------- */

export const Onboarded = {
  get() { return localStorage.getItem(K.onboard) === '1'; },
  set(v) { v ? localStorage.setItem(K.onboard, '1') : localStorage.removeItem(K.onboard); },
};

/* ---------------- Projects ----------------
   Project shape:
   {
     id, name, createdAt, updatedAt,
     files: { "index.html": { content, updatedAt } , ... },
     messages: [ { id, role:'user'|'assistant', text, ts, card? } ],
     meta: { summary, stack, lastDeploy }
   }
------------------------------------------- */

function uid(prefix = 'p') {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export const Projects = {
  all() {
    const list = read(K.projects, []);
    return Array.isArray(list) ? list : [];
  },
  saveAll(list) { return write(K.projects, list); },

  get(id) { return Projects.all().find(p => p.id === id) || null; },

  create(name = 'Untitled project') {
    const now = Date.now();
    const p = {
      id: uid(),
      name,
      createdAt: now,
      updatedAt: now,
      files: {},
      messages: [],
      meta: { summary: '', stack: 'static', lastDeploy: null },
    };
    const list = Projects.all();
    list.unshift(p);
    Projects.saveAll(list);
    Projects.setActive(p.id);
    return p;
  },

  update(id, mutator) {
    const list = Projects.all();
    const i = list.findIndex(p => p.id === id);
    if (i === -1) return null;
    const next = mutator({ ...list[i] }) || list[i];
    next.updatedAt = Date.now();
    list[i] = next;
    // keep most-recently-updated first
    list.sort((a, b) => b.updatedAt - a.updatedAt);
    const ok = Projects.saveAll(list);
    if (!ok) throw new Error('Browser storage is full. Delete an old project to free space.');
    return next;
  },

  remove(id) {
    const list = Projects.all().filter(p => p.id !== id);
    Projects.saveAll(list);
    if (Projects.activeId() === id) {
      Projects.setActive(list[0]?.id || null);
    }
  },

  activeId() { return localStorage.getItem(K.active) || null; },
  setActive(id) {
    if (id) localStorage.setItem(K.active, id);
    else localStorage.removeItem(K.active);
  },
  active() {
    const id = Projects.activeId();
    return id ? Projects.get(id) : null;
  },

  /* ---- file helpers ---- */
  writeFile(id, path, content) {
    return Projects.update(id, p => {
      const existed = Object.prototype.hasOwnProperty.call(p.files, path);
      p.files = { ...p.files, [path]: { content, updatedAt: Date.now() } };
      if (!existed) Profile.bump('filesCreated');
      return p;
    });
  },
  deleteFile(id, path) {
    return Projects.update(id, p => {
      const files = { ...p.files };
      delete files[path];
      p.files = files;
      return p;
    });
  },
  renameFile(id, from, to) {
    return Projects.update(id, p => {
      if (!p.files[from]) return p;
      const files = { ...p.files };
      files[to] = files[from];
      delete files[from];
      p.files = files;
      return p;
    });
  },
  addMessage(id, msg) {
    return Projects.update(id, p => {
      p.messages = [...(p.messages || []), msg];
      return p;
    });
  },

  storageUsed() {
    let bytes = 0;
    for (const key of Object.keys(localStorage)) {
      if (key.startsWith(NS)) bytes += (localStorage.getItem(key) || '').length;
    }
    return bytes;
  },

  resetAll() {
    for (const key of Object.keys(localStorage)) {
      if (key.startsWith(NS)) localStorage.removeItem(key);
    }
  },
};

export { uid };
