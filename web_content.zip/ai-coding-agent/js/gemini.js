/* =========================================================
   gemini.js — Google Generative Language API client
   - user-supplied key only (never hard-coded)
   - exponential backoff on 429/408/5xx
   - automatic fallback to another available model
   - streaming via SSE when enabled
   ========================================================= */

const BASE = 'https://generativelanguage.googleapis.com/v1beta';

/* Models we prefer, best-first. The live ListModels call overrides this
   list whenever the key can reach the API — so nothing here is hard-wired. */
export const PREFERRED_MODELS = [
  'gemini-2.5-pro',
  'gemini-2.5-flash',
  'gemini-2.0-flash',
  'gemini-2.5-flash-lite',
];

const RETRYABLE = new Set([408, 429, 500, 502, 503, 504]);
const PERMANENT = new Set([400, 401, 403, 404]);

export class ApiError extends Error {
  constructor(message, { status = 0, permanent = false, raw = '' } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.permanent = permanent;
    this.raw = raw;
  }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

function friendlyError(status, body) {
  const detail = (body && (body.error?.message || body.message)) || '';
  switch (status) {
    case 400:
      if (/api key not valid/i.test(detail)) return 'That API key was rejected. Check it in Settings.';
      return `The request was rejected: ${detail || 'malformed request'}`;
    case 401:
    case 403:
      return 'This API key does not have permission for that model. Check the key, or enable the Generative Language API for its project.';
    case 404:
      return 'That model is not available to this key.';
    case 429:
      return 'Rate limit reached on your key. Retrying with a longer wait.';
    case 500: case 502: case 503: case 504:
      return 'The model is temporarily overloaded. Retrying.';
    default:
      return detail || `Request failed (HTTP ${status}).`;
  }
}

async function parseBody(res) {
  const text = await res.text();
  try { return { json: JSON.parse(text), text }; }
  catch { return { json: null, text }; }
}

/* ---------------------------------------------------------
   List models available to this key.
   --------------------------------------------------------- */
export async function listModels(apiKey) {
  if (!apiKey) throw new ApiError('No API key set.', { permanent: true });
  const res = await fetch(`${BASE}/models?key=${encodeURIComponent(apiKey)}&pageSize=200`);
  const { json, text } = await parseBody(res);
  if (!res.ok) {
    throw new ApiError(friendlyError(res.status, json), {
      status: res.status, permanent: PERMANENT.has(res.status), raw: text,
    });
  }
  const names = (json.models || [])
    .filter(m => (m.supportedGenerationMethods || []).includes('generateContent'))
    .map(m => m.name.replace(/^models\//, ''))
    .filter(n => /^gemini/i.test(n) && !/embedding|aqa|vision-latest/i.test(n));

  // Rank: preferred order first, then everything else alphabetically.
  const rank = n => {
    const i = PREFERRED_MODELS.indexOf(n);
    return i === -1 ? 500 : i;
  };
  return [...new Set(names)].sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
}

/* ---------------------------------------------------------
   Low-level single-shot call with retry.
   --------------------------------------------------------- */
async function callOnce({ apiKey, model, body, signal, onRetry }) {
  const url = `${BASE}/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const MAX = 5;

  for (let attempt = 0; attempt <= MAX; attempt++) {
    let res;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal,
      });
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      // Network-level failure — worth a couple of retries.
      if (attempt >= 2) throw new ApiError('Network error — check your internet connection.', { status: 0 });
      const wait = 700 * 2 ** attempt;
      onRetry?.({ attempt: attempt + 1, waitMs: wait, reason: 'network' });
      await sleep(wait);
      continue;
    }

    if (res.ok) {
      const { json } = await parseBody(res);
      return json;
    }

    const { json, text } = await parseBody(res);

    if (RETRYABLE.has(res.status) && attempt < MAX) {
      // Honour Retry-After when the server sends one.
      const ra = Number(res.headers.get('retry-after'));
      const base = Number.isFinite(ra) && ra > 0 ? ra * 1000 : 800 * 2 ** attempt;
      const wait = Math.min(base + Math.random() * 400, 32000);
      onRetry?.({ attempt: attempt + 1, waitMs: wait, reason: `HTTP ${res.status}`, status: res.status });
      await sleep(wait);
      continue;
    }

    throw new ApiError(friendlyError(res.status, json), {
      status: res.status, permanent: PERMANENT.has(res.status), raw: text,
    });
  }
  throw new ApiError('The model stayed unavailable after several retries.', { status: 503 });
}

/* ---------------------------------------------------------
   Streaming call (SSE). Falls back to non-streaming on failure.
   --------------------------------------------------------- */
async function streamOnce({ apiKey, model, body, signal, onDelta, onRetry }) {
  const url = `${BASE}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse&key=${encodeURIComponent(apiKey)}`;
  const MAX = 3;

  for (let attempt = 0; attempt <= MAX; attempt++) {
    let res;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal,
      });
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      if (attempt >= 1) throw new ApiError('Network error — check your internet connection.', { status: 0 });
      await sleep(600 * 2 ** attempt);
      continue;
    }

    if (!res.ok) {
      const { json, text } = await parseBody(res);
      if (RETRYABLE.has(res.status) && attempt < MAX) {
        const wait = Math.min(800 * 2 ** attempt + Math.random() * 300, 20000);
        onRetry?.({ attempt: attempt + 1, waitMs: wait, reason: `HTTP ${res.status}`, status: res.status });
        await sleep(wait);
        continue;
      }
      throw new ApiError(friendlyError(res.status, json), {
        status: res.status, permanent: PERMANENT.has(res.status), raw: text,
      });
    }

    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    let full = '';
    let finishReason = '';
    let usage = null;

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });

      let nl;
      while ((nl = buf.indexOf('\n')) !== -1) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (!line.startsWith('data:')) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === '[DONE]') continue;
        try {
          const chunk = JSON.parse(payload);
          const cand = chunk.candidates?.[0];
          const piece = cand?.content?.parts?.map(p => p.text || '').join('') || '';
          if (piece) { full += piece; onDelta?.(piece, full); }
          if (cand?.finishReason) finishReason = cand.finishReason;
          if (chunk.usageMetadata) usage = chunk.usageMetadata;
        } catch { /* partial JSON across chunk boundary — ignore */ }
      }
    }
    return { text: full, finishReason, usage };
  }
  throw new ApiError('Streaming failed after retries.', { status: 503 });
}

/* ---------------------------------------------------------
   Public entry point.
   Tries the chosen model, then fallbacks, for transient failures.
   --------------------------------------------------------- */
export async function generate({
  apiKey,
  model,
  systemInstruction,
  contents,
  temperature = 0.7,
  maxOutputTokens = 8192,
  json = false,
  stream = false,
  candidates = [],
  signal,
  onDelta,
  onEvent,           // ({type:'retry'|'fallback', ...})
}) {
  if (!apiKey) throw new ApiError('Add your Gemini API key in Settings first.', { permanent: true });

  const body = {
    contents,
    generationConfig: {
      temperature,
      maxOutputTokens,
      ...(json ? { responseMimeType: 'application/json' } : {}),
    },
    safetySettings: [
      'HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH',
      'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT',
    ].map(category => ({ category, threshold: 'BLOCK_ONLY_HIGH' })),
  };
  if (systemInstruction) body.systemInstruction = { parts: [{ text: systemInstruction }] };

  // Build the try-order: chosen model first, then distinct fallbacks.
  const order = [model, ...candidates.filter(m => m && m !== model)].slice(0, 4);
  let lastErr = null;

  for (let i = 0; i < order.length; i++) {
    const m = order[i];
    if (i > 0) onEvent?.({ type: 'fallback', from: order[i - 1], to: m });
    try {
      const onRetry = info => onEvent?.({ type: 'retry', model: m, ...info });

      if (stream && !json) {
        const out = await streamOnce({ apiKey, model: m, body, signal, onDelta, onRetry });
        return { ...out, model: m };
      }
      const res = await callOnce({ apiKey, model: m, body, signal, onRetry });
      const cand = res.candidates?.[0];
      const text = cand?.content?.parts?.map(p => p.text || '').join('') || '';
      if (!text && cand?.finishReason === 'SAFETY') {
        throw new ApiError('The model declined that request under its safety filters. Try rephrasing.', { permanent: true });
      }
      return { text, finishReason: cand?.finishReason || '', usage: res.usageMetadata || null, model: m };
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      lastErr = err;
      // A permanent key/permission problem will not be fixed by another model
      // — except 404, which genuinely means "this model, not this key".
      if (err instanceof ApiError && err.permanent && err.status !== 404) throw err;
      // otherwise loop to the next candidate
    }
  }
  throw lastErr || new ApiError('All models failed.', { status: 503 });
}

/* Quick connectivity/permission probe used by the "Test connection" button. */
export async function testKey(apiKey, model) {
  const models = await listModels(apiKey);      // throws on bad key
  const use = models.includes(model) ? model : models[0];
  if (!use) throw new ApiError('The key works but exposes no usable Gemini model.', { permanent: true });
  const out = await generate({
    apiKey, model: use,
    contents: [{ role: 'user', parts: [{ text: 'Reply with the single word: ready' }] }],
    maxOutputTokens: 16, temperature: 0,
  });
  return { models, model: out.model, reply: (out.text || '').trim() };
}
