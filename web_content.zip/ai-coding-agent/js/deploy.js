/* =========================================================
   deploy.js — free static publishing, from the browser
   ---------------------------------------------------------
   Netlify  : direct deploy API (works from a browser with a
              personal access token, CORS-enabled).
   GitHub   : Contents API → repo → GitHub Pages branch
              (works from a browser with a PAT).
   Cloudflare Pages / Vercel : their APIs reject browser-origin
              requests. Those two go through the bundled
              server/proxy.js, which keeps the token off the
              client. Without it we refuse instead of pretending.
   ========================================================= */

const NETLIFY_API = 'https://api.netlify.com/api/v1';
const GH_API = 'https://api.github.com';

export class DeployError extends Error {
  constructor(message, { provider, status = 0, detail = '', needsProxy = false } = {}) {
    super(message);
    this.name = 'DeployError';
    this.provider = provider;
    this.status = status;
    this.detail = detail;
    this.needsProxy = needsProxy;
  }
}

export const PROVIDERS = {
  none:       { label: 'Not connected',          browser: true,  fields: [] },
  netlify:    { label: 'Netlify',                browser: true,  fields: ['netlifyToken', 'netlifySiteName'] },
  github:     { label: 'GitHub Pages',           browser: true,  fields: ['ghToken', 'ghOwner', 'ghRepo'] },
  cloudflare: { label: 'Cloudflare Pages',       browser: false, fields: ['cfToken', 'cfAccountId', 'proxyUrl'] },
  vercel:     { label: 'Vercel',                 browser: false, fields: ['vercelToken', 'proxyUrl'] },
};

/* ---------------------------------------------------------
   Shared: turn the virtual file system into a flat upload list
   --------------------------------------------------------- */
export function projectFiles(project) {
  return Object.entries(project.files || {})
    .filter(([p]) => !p.endsWith('/.keep'))
    .map(([path, f]) => ({ path, content: f.content ?? '' }));
}

function looksBinary(path) {
  return /\.(png|jpe?g|gif|webp|ico|woff2?|ttf|otf|mp3|mp4)$/i.test(path);
}

/* ---------------------------------------------------------
   Netlify — POST /sites/{site}/deploys with sha1 of each file,
   then PUT each file's content. No build step needed.
   --------------------------------------------------------- */
export async function deployNetlify({ token, siteName, project, onEvent }) {
  if (!token) throw new DeployError('Add a Netlify personal access token first.', { provider: 'netlify' });

  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  const files = projectFiles(project);
  if (!files.length) throw new DeployError('This project has no files to publish.', { provider: 'netlify' });

  onEvent?.({ step: 'Preparing files', detail: `${files.length} files` });

  // 1. Find or create the site.
  let siteId = project.meta?.lastDeploy?.provider === 'netlify' ? project.meta.lastDeploy.siteId : null;
  if (!siteId) {
    onEvent?.({ step: 'Creating Netlify site', detail: siteName || project.name });
    const res = await fetch(`${NETLIFY_API}/sites`, {
      method: 'POST', headers,
      body: JSON.stringify(siteName ? { name: siteName } : {}),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new DeployError(netlifyMessage(res.status, body), { provider: 'netlify', status: res.status, detail: JSON.stringify(body).slice(0, 300) });
    siteId = body.id;
  }

  // 2. Hash the files and open a deploy.
  const manifest = {};
  for (const f of files) {
    manifest[`/${f.path}`] = await sha1Hex(f.content, looksBinary(f.path));
  }

  onEvent?.({ step: 'Opening deploy', detail: siteId });
  const depRes = await fetch(`${NETLIFY_API}/sites/${siteId}/deploys`, {
    method: 'POST', headers,
    body: JSON.stringify({ files: manifest, draft: false }),
  });
  const dep = await depRes.json().catch(() => ({}));
  if (!depRes.ok) throw new DeployError(netlifyMessage(depRes.status, dep), { provider: 'netlify', status: depRes.status, detail: JSON.stringify(dep).slice(0, 300) });

  // 3. Upload only the files Netlify says it still needs.
  const needed = new Set((dep.required || []).map(p => p.replace(/^\//, '')));
  const toSend = files.filter(f => needed.size === 0 || needed.has(f.path));
  let done = 0;
  for (const f of toSend) {
    const up = await fetch(`${NETLIFY_API}/deploys/${dep.id}/files/${encodeURIComponent(f.path)}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/octet-stream' },
      body: f.content,
    });
    if (!up.ok) {
      const t = await up.text().catch(() => '');
      throw new DeployError(`Uploading ${f.path} failed (HTTP ${up.status}).`, { provider: 'netlify', status: up.status, detail: t.slice(0, 200) });
    }
    done++;
    onEvent?.({ step: 'Uploading', detail: `${f.path} (${done}/${toSend.length})` });
  }

  const url = dep.ssl_url || dep.url || `https://${dep.subdomain || siteId}.netlify.app`;
  return {
    provider: 'netlify',
    url,
    adminUrl: dep.admin_url || null,
    siteId,
    deployId: dep.id,
    filesUploaded: toSend.length,
    at: Date.now(),
  };
}

function netlifyMessage(status, body) {
  if (status === 401) return 'Netlify rejected that token. Check it has access to create sites.';
  if (status === 403) return 'This Netlify token lacks the required scope.';
  if (status === 422 && /name/i.test(body?.message || '')) return 'That site name is already taken — choose another.';
  return body?.message || `Netlify returned HTTP ${status}.`;
}

async function sha1Hex(text, binary) {
  const bytes = binary ? new Uint8Array([...text].map(c => c.charCodeAt(0) & 0xff)) : new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-1', bytes);
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ---------------------------------------------------------
   GitHub Pages — create/update repo contents, enable Pages.
   --------------------------------------------------------- */
export async function deployGitHub({ token, owner, repo, project, onEvent }) {
  if (!token || !owner || !repo) {
    throw new DeployError('GitHub needs a token, an owner and a repository name.', { provider: 'github' });
  }
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github+json',
    'Content-Type': 'application/json',
  };
  const files = projectFiles(project);
  if (!files.length) throw new DeployError('This project has no files to publish.', { provider: 'github' });

  // 1. Who are we / does the repo exist?
  const meRes = await fetch(`${GH_API}/user`, { headers });
  if (meRes.status === 401) throw new DeployError('GitHub rejected that token.', { provider: 'github', status: 401 });
  const me = await meRes.json().catch(() => ({}));
  const isUserRepo = me.login && me.login.toLowerCase() === owner.toLowerCase();

  const repoRes = await fetch(`${GH_API}/repos/${owner}/${repo}`, { headers });
  if (repoRes.status === 404) {
    onEvent?.({ step: 'Creating repository', detail: `${owner}/${repo}` });
    const createUrl = isUserRepo ? `${GH_API}/user/repos` : `${GH_API}/orgs/${owner}/repos`;
    const cRes = await fetch(createUrl, {
      method: 'POST', headers,
      body: JSON.stringify({ name: repo, private: false, auto_init: false, description: `Published with Nova — ${project.name}` }),
    });
    const cBody = await cRes.json().catch(() => ({}));
    if (!cRes.ok) throw new DeployError(cBody.message || `Could not create the repository (HTTP ${cRes.status}).`, { provider: 'github', status: cRes.status });
  } else if (!repoRes.ok) {
    throw new DeployError(`Could not read repository ${owner}/${repo} (HTTP ${repoRes.status}).`, { provider: 'github', status: repoRes.status });
  }

  // 2. Push each file (create or update).
  let i = 0;
  for (const f of files) {
    i++;
    onEvent?.({ step: 'Pushing files', detail: `${f.path} (${i}/${files.length})` });
    const path = `${GH_API}/repos/${owner}/${repo}/contents/${encodeURIComponent(f.path)}`;

    const existing = await fetch(`${path}?ref=main`, { headers });
    let sha = null;
    if (existing.ok) {
      const ex = await existing.json().catch(() => ({}));
      sha = ex.sha || null;
    }

    const put = await fetch(path, {
      method: 'PUT', headers,
      body: JSON.stringify({
        message: `Nova: update ${f.path}`,
        content: toBase64(f.content, looksBinary(f.path)),
        branch: 'main',
        ...(sha ? { sha } : {}),
      }),
    });
    if (!put.ok) {
      const body = await put.json().catch(() => ({}));
      // A missing branch on a fresh repo — retry once against the default branch.
      if (/branch/i.test(body?.message || '')) {
        const retry = await fetch(path, {
          method: 'PUT', headers,
          body: JSON.stringify({ message: `Nova: add ${f.path}`, content: toBase64(f.content, looksBinary(f.path)) }),
        });
        if (!retry.ok) throw new DeployError(`Pushing ${f.path} failed (HTTP ${retry.status}).`, { provider: 'github', status: retry.status });
      } else {
        throw new DeployError(`Pushing ${f.path} failed: ${body?.message || put.status}`, { provider: 'github', status: put.status });
      }
    }
  }

  // 3. Make sure Pages is on.
  onEvent?.({ step: 'Enabling GitHub Pages' });
  const pagesRes = await fetch(`${GH_API}/repos/${owner}/${repo}/pages`, {
    method: 'POST', headers,
    body: JSON.stringify({ source: { branch: 'main', path: '/' } }),
  });
  if (pagesRes.status === 409) {
    await fetch(`${GH_API}/repos/${owner}/${repo}/pages`, {
      method: 'PUT', headers,
      body: JSON.stringify({ source: { branch: 'main', path: '/' } }),
    });
  }

  const url = isUserRepo && repo.toLowerCase() === `${me.login.toLowerCase()}.github.io`
    ? `https://${me.login}.github.io/`
    : `https://${owner}.github.io/${repo}/`;

  return {
    provider: 'github',
    url,
    repoUrl: `https://github.com/${owner}/${repo}`,
    filesUploaded: files.length,
    note: 'GitHub Pages usually goes live within a minute.',
    at: Date.now(),
  };
}

function toBase64(text) {
  const bytes = new TextEncoder().encode(text);
  let bin = '';
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  }
  return btoa(bin);
}

/* ---------------------------------------------------------
   Proxy-backed providers (Cloudflare Pages, Vercel)
   --------------------------------------------------------- */
export async function deployViaProxy({ provider, proxyUrl, token, accountId, project, onEvent }) {
  if (!proxyUrl) {
    throw new DeployError(
      'This provider blocks direct browser requests. Run the bundled proxy (server/proxy.js) and set its URL in Settings, then publish.',
      { provider, needsProxy: true },
    );
  }
  if (!token) throw new DeployError(`Add your ${PROVIDERS[provider].label} token first.`, { provider, needsProxy: true });

  onEvent?.({ step: 'Sending to proxy', detail: proxyUrl });
  const res = await fetch(`${proxyUrl.replace(/\/$/, '')}/deploy`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      provider,
      token,
      accountId,
      projectName: project.name,
      files: projectFiles(project),
    }),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok || !body.ok) {
    throw new DeployError(body.error || `${PROVIDERS[provider].label} deploy failed (HTTP ${res.status}).`, {
      provider, status: res.status, needsProxy: true, detail: JSON.stringify(body).slice(0, 300),
    });
  }
  return { provider, url: body.url, filesUploaded: body.filesUploaded ?? projectFiles(project).length, at: Date.now() };
}

/* ---------------------------------------------------------
   Dispatcher used by the UI
   --------------------------------------------------------- */
export async function publish({ settings, project, onEvent }) {
  const provider = settings.provider;
  const cfg = settings.providerConfig || {};

  if (!provider || provider === 'none') {
    throw new DeployError('Connect a publishing provider in Settings first.', { provider: 'none' });
  }
  if (!PROVIDERS[provider]) {
    throw new DeployError('Unknown publishing provider.', { provider });
  }

  switch (provider) {
    case 'netlify':
      return deployNetlify({ token: cfg.netlifyToken, siteName: cfg.netlifySiteName, project, onEvent });
    case 'github':
      return deployGitHub({ token: cfg.ghToken, owner: cfg.ghOwner, repo: cfg.ghRepo || slugify(project.name), project, onEvent });
    case 'cloudflare':
      return deployViaProxy({ provider, proxyUrl: cfg.proxyUrl, token: cfg.cfToken, accountId: cfg.cfAccountId, project, onEvent });
    case 'vercel':
      return deployViaProxy({ provider, proxyUrl: cfg.proxyUrl, token: cfg.vercelToken, project, onEvent });
    default:
      throw new DeployError('Unsupported provider.', { provider });
  }
}

export function slugify(name) {
  return (name || 'nova-site')
    .toLowerCase().trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 50) || 'nova-site';
}

/* Ask the bundled proxy whether it is reachable. */
export async function pingProxy(proxyUrl) {
  if (!proxyUrl) return { ok: false, reason: 'No proxy URL set.' };
  try {
    const res = await fetch(`${proxyUrl.replace(/\/$/, '')}/health`, { method: 'GET' });
    if (!res.ok) return { ok: false, reason: `Proxy answered HTTP ${res.status}.` };
    const body = await res.json().catch(() => ({}));
    return { ok: true, providers: body.providers || [] };
  } catch (err) {
    return { ok: false, reason: `Could not reach the proxy (${err.message}). Is server/proxy.js running?` };
  }
}
