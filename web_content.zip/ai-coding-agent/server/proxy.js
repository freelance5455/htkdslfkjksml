#!/usr/bin/env node
/* =========================================================
   Nova publishing proxy
   ---------------------------------------------------------
   Why this exists: Cloudflare Pages and Vercel reject
   browser-origin requests, and their tokens must not sit in
   front-end source. This tiny server holds nothing itself —
   the token arrives per request from the user's own browser
   and is forwarded straight to the provider.

   Run:   node server/proxy.js
   Then:  put its URL (default http://localhost:8787) into
          Nova → Settings → Publishing → Proxy URL

   Endpoints
     GET  /health                  → { ok, providers }
     POST /deploy                  → { ok, url, filesUploaded }
   Body: { provider, token, accountId?, projectName, files:[{path,content}] }
   ========================================================= */

import http from 'node:http';
import { gzipSync } from 'node:zlib';

const PORT = Number(process.env.PORT || 8787);
const BIND = process.env.BIND || '127.0.0.1';
const MAX_BYTES = 25 * 1024 * 1024;   // 25 MB of project payload

const PROVIDERS = ['cloudflare', 'vercel'];

/* ---------- helpers ---------- */

function send(res, status, body, extraHeaders = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    ...extraHeaders,
  });
  res.end(payload);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > MAX_BYTES) { reject(new Error('Payload too large.')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch { reject(new Error('Body was not valid JSON.')); }
    });
    req.on('error', reject);
  });
}

/* ---------- Cloudflare Pages ----------
   POST /accounts/{account_id}/pages/projects            → create project
   POST /accounts/{account_id}/pages/projects/{name}/deployments  → deploy
   Cloudflare takes multipart/form-data, not JSON.
--------------------------------------- */

async function deployCloudflare({ token, accountId, projectName, files }) {
  if (!token) throw new Error('Missing Cloudflare API token.');
  if (!accountId) throw new Error('Missing Cloudflare account ID.');

  const name = slug(projectName);
  const base = `https://api.cloudflare.com/client/v4/accounts/${accountId}/pages/projects`;
  const auth = { Authorization: `Bearer ${token}` };

  // 1. Create the project if it doesn't exist yet.
  let projectRes = await fetch(`${base}/${name}`, { headers: auth });
  if (projectRes.status === 404) {
    const createRes = await fetch(base, {
      method: 'POST',
      headers: { ...auth, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, production_branch: 'main' }),
    });
    const created = await createRes.json().catch(() => ({}));
    if (!createRes.ok) {
      throw new Error(created.errors?.[0]?.message || `Cloudflare could not create the project (HTTP ${createRes.status}).`);
    }
  } else if (!projectRes.ok) {
    const body = await projectRes.json().catch(() => ({}));
    throw new Error(body.errors?.[0]?.message || `Cloudflare project lookup failed (HTTP ${projectRes.status}).`);
  }

  // 2. Build the multipart body.
  const form = new FormData();
  for (const f of files) {
    const name = f.path.split('/').pop();
    const rel = f.path.includes('/') ? f.path.slice(0, f.path.lastIndexOf('/')) : '';
    form.append('file', new Blob([f.content], { type: mimeFor(f.path) }), name);
    // Cloudflare keeps the folder via the filename for nested paths.
    if (rel) form.append('file', new Blob([f.content], { type: mimeFor(f.path) }), `${rel}/${name}`);
  }

  const depRes = await fetch(`${base}/${name}/deployments`, { method: 'POST', headers: auth, body: form });
  const dep = await depRes.json().catch(() => ({}));
  if (!depRes.ok) {
    throw new Error(dep.errors?.[0]?.message || `Cloudflare deploy failed (HTTP ${depRes.status}).`);
  }
  return {
    url: dep.result?.url || `https://${name}.pages.dev`,
    filesUploaded: files.length,
  };
}

/* ---------- Vercel ----------
   POST /v13/deployments with inline file content (base64).
------------------------------ */

async function deployVercel({ token, projectName, files }) {
  if (!token) throw new Error('Missing Vercel access token.');
  const name = slug(projectName);

  const payload = {
    name,
    target: 'production',
    files: files.map(f => ({
      file: f.path,
      data: Buffer.from(f.content, 'utf8').toString('base64'),
      encoding: 'base64',
    })),
    projectSettings: { framework: null },
  };

  const res = await fetch('https://api.vercel.com/v13/deployments', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(body.error?.message || `Vercel deploy failed (HTTP ${res.status}).`);
  }
  return {
    url: body.url ? `https://${body.url}` : `https://${name}.vercel.app`,
    filesUploaded: files.length,
  };
}

/* ---------- small utils ---------- */

function slug(name) {
  return String(name || 'nova-site').toLowerCase().trim()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 50) || 'nova-site';
}

function mimeFor(path) {
  const e = (path.split('.').pop() || '').toLowerCase();
  return {
    html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript',
    mjs: 'text/javascript', json: 'application/json', svg: 'image/svg+xml',
    png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
    webp: 'image/webp', ico: 'image/x-icon', txt: 'text/plain', md: 'text/markdown',
  }[e] || 'application/octet-stream';
}

/* ---------- server ---------- */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === 'OPTIONS') return send(res, 204, {});
  if (url.pathname === '/health') return send(res, 200, { ok: true, providers: PROVIDERS });
  if (url.pathname === '/' ) return send(res, 200, {
    ok: true,
    name: 'Nova publishing proxy',
    endpoints: ['GET /health', 'POST /deploy'],
    providers: PROVIDERS,
  });

  if (url.pathname !== '/deploy') return send(res, 404, { ok: false, error: 'Not found.' });
  if (req.method !== 'POST') return send(res, 405, { ok: false, error: 'Use POST.' });

  let body;
  try { body = await readJson(req); }
  catch (err) { return send(res, 400, { ok: false, error: err.message }); }

  const { provider, token, accountId, projectName, files } = body;
  if (!Array.isArray(files) || !files.length) {
    return send(res, 400, { ok: false, error: 'No files were sent.' });
  }
  if (!PROVIDERS.includes(provider)) {
    return send(res, 400, { ok: false, error: `Unknown provider "${provider}". Use: ${PROVIDERS.join(', ')}.` });
  }

  try {
    let result;
    if (provider === 'cloudflare') result = await deployCloudflare({ token, accountId, projectName, files });
    else result = await deployVercel({ token, projectName, files });

    console.log(`[deploy] ${provider} → ${result.url} (${result.filesUploaded} files)`);
    return send(res, 200, { ok: true, provider, ...result });
  } catch (err) {
    console.error(`[deploy] ${provider} failed:`, err.message);
    return send(res, 502, { ok: false, provider, error: err.message });
  }
});

server.listen(PORT, BIND, () => {
  console.log(`Nova publishing proxy listening on http://${BIND}:${PORT}`);
  console.log(`Providers: ${PROVIDERS.join(', ')}`);
  console.log(`Put http://${BIND === '0.0.0.0' ? 'localhost' : BIND}:${PORT} into Nova → Settings → Publishing → Proxy URL`);
});

export { server, deployCloudflare, deployVercel, slug, mimeFor, gzipSync };
