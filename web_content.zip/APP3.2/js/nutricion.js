

document.addEventListener("DOMContentLoaded", () => {
  const nutritionMenu = document.getElementById("nutrition-menu");

  const sections = {
    "nutrition-menu": nutritionMenu,
    "what-section": document.getElementById("what-section"),
    "not-section": document.getElementById("not-section"),
    "influence-section": document.getElementById("influence-section")
  };

  // Mostrar una sección y ocultar las demás.
  function showSection(targetId) {
    const targetSection = sections[targetId];

    // Evitar errores si el identificador no existe.
    if (!targetSection) return;

    // Ocultar todas las secciones.
    Object.values(sections).forEach((section) => {
      if (section) {
        section.hidden = true;
      }
    });

    // Cerrar todos los desplegables abiertos.
    document.querySelectorAll(".info-dropdown[open]").forEach((dropdown) => {
      dropdown.open = false;
    });

    // Mostrar la sección seleccionada.
    targetSection.hidden = false;

    // Volver al comienzo para facilitar la navegación.
    window.scrollTo({
      top: 0,
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "auto"
        : "smooth"
    });
  }

  // Navegación desde el menú principal.
  document.querySelectorAll("[data-show]").forEach((button) => {
    button.addEventListener("click", () => {
      showSection(button.dataset.show);
    });
  });

  // Botones para volver al menú principal.
  document.querySelectorAll("[data-back]").forEach((button) => {
    button.addEventListener("click", () => {
      showSection(button.dataset.back);
    });
  });

  // Permitir un solo desplegable abierto en toda la aplicación.
  // Al abrir cualquier desplegable, se cierran todos los demás,
  // incluso si pertenecen a otra sección o apartado.
  document.querySelectorAll(".info-dropdown").forEach((dropdown) => {
    dropdown.addEventListener("toggle", () => {
      if (!dropdown.open) return;

      document.querySelectorAll(".info-dropdown[open]").forEach((other) => {
        if (other !== dropdown) other.open = false;
      });
    });
  });

  console.log("Sección de Nutrición lista.");
});
