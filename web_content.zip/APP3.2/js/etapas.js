
document.addEventListener("DOMContentLoaded", () => {
  const nutritionMenu = document.getElementById("nutrition-menu");

  const sectionIds = [
    "prenatal-section",
    "newborn-section",
    "infant-section",
    "early-childhood-section",
    "preschool-section",
    "school-section"
  ];

  const sections = {
    "nutrition-menu": nutritionMenu
  };

  sectionIds.forEach((id) => {
    sections[id] = document.getElementById(id);
  });

  // Mostrar el menú o la etapa seleccionada.
  function showSection(targetId) {
    const target = sections[targetId];

    if (!target) return;

    Object.values(sections).forEach((section) => {
      if (section) {
        section.hidden = true;
      }
    });

    target.hidden = false;
  }

  // Abrir una etapa desde el menú.
  document.querySelectorAll("[data-show]").forEach((button) => {
    button.addEventListener("click", () => {
      showSection(button.dataset.show);
    });
  });

  // Volver al menú de las seis etapas.
  document.querySelectorAll("[data-back]").forEach((button) => {
    button.addEventListener("click", () => {
      showSection(button.dataset.back);
    });
  });

  // Comprobar que todas las secciones existan.
  const missingSections = Object.entries(sections)
    .filter(([, section]) => !section)
    .map(([id]) => id);

  if (missingSections.length > 0) {
    console.error(
      "No se encontraron las siguientes secciones:",
      missingSections
    );
  }



  // ¿Sabías que?: burbuja fija, no arrastrable, con panel desplegable.
  const queEsBoxes = document.querySelectorAll("[data-sabias-que]");

  function closeQueEs(except = null) {
    queEsBoxes.forEach((box) => {
      if (box === except) return;
      const trigger = box.querySelector(".sabias-que-trigger");
      const panel = box.querySelector(".sabias-que-panel");
      if (trigger && panel) {
        panel.hidden = true;
        trigger.setAttribute("aria-expanded", "false");
      }
    });
  }

  queEsBoxes.forEach((box) => {
    const trigger = box.querySelector(".sabias-que-trigger");
    const panel = box.querySelector(".sabias-que-panel");
    const close = box.querySelector(".sabias-que-close");
    if (!trigger || !panel) return;

    trigger.addEventListener("click", (event) => {
      event.stopPropagation();
      const opening = panel.hidden;
      closeQueEs(box);
      panel.hidden = !opening;
      trigger.setAttribute("aria-expanded", String(opening));
    });

    if (close) {
      close.addEventListener("click", (event) => {
        event.stopPropagation();
        panel.hidden = true;
        trigger.setAttribute("aria-expanded", "false");
      });
    }
    panel.addEventListener("click", (event) => event.stopPropagation());
  });

  document.addEventListener("click", () => closeQueEs());
  // Al comenzar a desplazarse, cerrar el panel para que nunca se despegue
  // visualmente de la burbuja ni quede flotando sobre el contenido.
  let scrollCloseQueued = false;
  window.addEventListener("scroll", () => {
    if (scrollCloseQueued) return;
    scrollCloseQueued = true;
    window.requestAnimationFrame(() => {
      closeQueEs();
      scrollCloseQueued = false;
    });
  }, { passive: true });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeQueEs();
  });

  console.log("Sección de etapas lista.");
});
