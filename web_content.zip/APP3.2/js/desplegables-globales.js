// Acordeón global: al abrir un desplegable, cierra los demás de la página.
// Conserva abiertos sus desplegables antecesores si el contenido está anidado.
document.addEventListener("click", (event) => {
  const summary = event.target.closest("summary");
  if (!summary) return;

  const selected = summary.closest("details");
  if (!selected || selected.open) return; // Si se está cerrando, no intervenir.

  const ancestors = new Set();
  let parent = selected.parentElement;
  while (parent) {
    if (parent instanceof HTMLDetailsElement) ancestors.add(parent);
    parent = parent.parentElement;
  }

  document.querySelectorAll("details[open]").forEach((dropdown) => {
    if (dropdown !== selected && !ancestors.has(dropdown)) {
      dropdown.open = false;
    }
  });
}, true);
