SUBWAY CRAFT — ENDLESS EDITION

Open index.html in a modern mobile browser to play.

NEW IN THIS VERSION
- Endless chunk-style station: new areas generate as you move.
- Larger station with repeating platforms, lights, rails, signs, and scenery.
- Expanded creative inventory (12 block types).
- Guard NPC that follows when you are nearby.
- Subway train feature and ride button.
- Flight, break/place blocks, look controls, and reset.

ANDROID NOTES
This ZIP is a browser game, not an APK yet. Extract it and open index.html in Chrome.
For an installable APK, the HTML must be packaged in an Android WebView project and built/signed with Android build tools. Do not install APKs from unknown sites.
