# sample-formula (Android)

The Round web app (`app/src/main/assets/index.html`, your track10xxxxxxxxviii build) running full screen in a native shell.

## Build and run
1. Open this folder in **Android Studio** (Koala or newer). It reads `gradle/wrapper/gradle-wrapper.properties`
   and downloads Gradle 8.9 itself. If it asks for a wrapper jar, run `gradle wrapper` once.
2. Let it sync, pick a device or emulator (Android 10 / API 29 or newer) and press Run.
3. Release build: Build > Generate Signed Bundle / APK.

## What is Kotlin and what is Java
| File | Language | Job |
|---|---|---|
| `MainActivity.kt` | Kotlin | Window and WebView setup, serves the page from assets over `https://appassets.androidplatform.net`, edge-to-edge insets (sets the page's `--safe-top/bottom`), keyboard resize, back button, image picker, opens outside links in Custom Tabs |
| `NativeBridge.java` | Java | The page-to-phone API, `window.RoundNative` |
| `Haptics.java` | Java | Turns the page's `navigator.vibrate()` into Android haptics (tick / click / patterns) |
| `FileSaver.java` | Java | Saves exported images to `Pictures/Round` (other files to `Downloads/Round`) with no storage permission |
| `assets/round-native.js` | JavaScript | Glue injected at page start: routes `navigator.vibrate`, `<a download>` of blob/data URLs and the back button to the native side, and adds `window.RoundApp` |

## How the pieces connect
- **Back button**: Kotlin asks the page `window.__roundBack()`. It closes, in order, the personality sheet, device panel, compare card, model/Inspect page or chat. If nothing was open, it goes back in history, then leaves the app.
- **Export image**: the page's Export button makes a blob link. A WebView cannot download that, so `round-native.js` sends it to `NativeBridge.saveFile` and Java writes it to Pictures/Round.
- **Haptics**: the page already calls `navigator.vibrate(...)` (8 places). Those now go to `Haptics.java`.
- **For future page features**: `if (window.RoundApp) { RoundApp.share(text); RoundApp.copy(text); RoundApp.haptic("heavy"); RoundApp.toast("Hi"); RoundApp.openExternal(url); }`

## Updating the page
Replace `app/src/main/assets/index.html` with a newer build. Nothing else changes.

## Notes
- minSdk 29 (Android 10). Lower it only if you also add storage-permission handling to `FileSaver`.
- Only your bundled page is loaded; every other link opens in the browser, which is why exposing `RoundNative` is safe.
- The app icon is a placeholder (a phone outline); replace `drawable/ic_launcher_foreground.xml`.
- The page's own network features (the optional search service) need an internet connection and a service address set inside the page.
- Not yet built on a device: it was checked against Android API stubs (Java compiles, XML and JS parse) but not with the Android SDK.
