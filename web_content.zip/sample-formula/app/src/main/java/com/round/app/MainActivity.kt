package com.round.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.util.Locale

/**
 * Hosts the Round web app (assets/index.html) full screen.
 *
 * Kotlin side: window, WebView, insets, back button, file picker, external links.
 * Java side:   NativeBridge / Haptics / FileSaver, reached from the page as window.RoundNative.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var container: FrameLayout
    private lateinit var webView: WebView

    private var pageReady = false
    private var safeAreaJs = ""
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            fileCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            )
            fileCallback = null
        }

    /** Serves assets/ over https://appassets.androidplatform.net so the page runs in a secure origin (IndexedDB, fetch, etc.). */
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    /** The glue that connects the page to the Java bridge (haptics, back button, downloads). */
    private val nativeScript by lazy {
        assets.open("round-native.js").bufferedReader().use { it.readText() }
    }

    private val backCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            // 1) let the page close whatever is open (chat, model card, compare, sheets)
            webView.evaluateJavascript("(window.__roundBack && window.__roundBack()) || false") { handled ->
                if (handled != "true") {
                    // 2) otherwise walk back through history, then leave the app
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // must come before super.onCreate
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        container = FrameLayout(this).apply {
            addView(
                webView,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
        setContentView(container)

        configureWebView()
        installInsets()
        onBackPressedDispatcher.addCallback(this, backCallback)

        if (savedInstanceState?.let { webView.restoreState(it) } == null) {
            webView.loadUrl(START_URL)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        WebView.setWebContentsDebuggingEnabled(debuggable)

        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // localStorage + IndexedDB (settings, board, the AI's memory)
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100                      // the page is laid out for 100%; system font size must not reflow it
        }

        webView.addJavascriptInterface(NativeBridge(this), "RoundNative")
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, nativeScript, setOf(ORIGIN))
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == HOST) return false
                openExternal(request.url)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                pageReady = false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pageReady = true
                view.evaluateJavascript(nativeScript, null)     // no-op if the document-start script already ran
                if (safeAreaJs.isNotEmpty()) view.evaluateJavascript(safeAreaJs, null)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams,
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    pickFiles.launch(params.createIntent())     // honours accept="image/*" and multiple
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }

            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                Log.d(TAG, "${message.message()} (${message.sourceId()}:${message.lineNumber()})")
                return true
            }
        }
    }

    /** Edge-to-edge: the page draws under the bars, so tell it how much to keep clear (its --safe-* variables). */
    private fun installInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(container) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val density = resources.displayMetrics.density

            container.setPadding(0, 0, 0, ime)                  // keyboard pushes the page up
            pushSafeArea(
                top = bars.top / density,
                bottom = if (ime > 0) 0f else bars.bottom / density,
                left = bars.left / density,
                right = bars.right / density,
            )
            insets
        }
    }

    private fun pushSafeArea(top: Float, bottom: Float, left: Float, right: Float) {
        fun px(v: Float) = String.format(Locale.US, "%.1fpx", v)
        safeAreaJs = "(function(){var s=document.documentElement.style;" +
            "s.setProperty('--safe-top','${px(top)}');s.setProperty('--safe-bottom','${px(bottom)}');" +
            "s.setProperty('--safe-left','${px(left)}');s.setProperty('--safe-right','${px(right)}');})();"
        if (pageReady) webView.evaluateJavascript(safeAreaJs, null)
    }

    private fun openExternal(uri: Uri) {
        try {
            when (uri.scheme) {
                "http", "https" -> CustomTabsIntent.Builder().build().launchUrl(this, uri)
                "mailto", "tel" -> startActivity(Intent(Intent.ACTION_VIEW, uri))
                else -> Log.w(TAG, "Blocked navigation to $uri")
            }
        } catch (e: ActivityNotFoundException) {
            Log.w(TAG, "No app can open $uri", e)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() { super.onResume(); webView.onResume() }
    override fun onPause() { webView.onPause(); super.onPause() }

    override fun onDestroy() {
        container.removeAllViews()
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "Round"
        const val HOST = "appassets.androidplatform.net"
        const val ORIGIN = "https://$HOST"
        const val START_URL = "$ORIGIN/assets/index.html"
    }
}
