package com.round.app;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

/** Turns the page's navigator.vibrate() calls into proper Android haptics. */
final class Haptics {

    private final Vibrator vibrator;

    Haptics(Context context) {
        Vibrator v;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            v = vm != null ? vm.getDefaultVibrator() : null;
        } else {
            v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        }
        vibrator = v;
    }

    private boolean usable() {
        return vibrator != null && vibrator.hasVibrator();
    }

    /** One value = a single pulse; several values = on/off/on/... like the web API. */
    void pattern(long[] ms) {
        if (!usable() || ms.length == 0) return;

        if (ms.length == 1) {
            long d = Math.min(Math.max(ms[0], 1L), 500L);
            if (d <= 12L) {
                vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK));
            } else if (d <= 30L) {
                vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK));
            } else {
                vibrator.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE));
            }
            return;
        }

        // Android waveforms start with a pause; the web API starts with a pulse.
        long[] timings = new long[ms.length + 1];
        long total = 0L;
        for (int i = 0; i < ms.length; i++) {
            long t = Math.min(ms[i], 1000L);
            total += t;
            if (total > 2000L) t = 0L;          // never buzz for more than about two seconds
            timings[i + 1] = t;
        }
        vibrator.vibrate(VibrationEffect.createWaveform(timings, -1));
    }

    void effect(String kind) {
        if (!usable()) return;
        int id;
        if ("tick".equals(kind)) id = VibrationEffect.EFFECT_TICK;
        else if ("heavy".equals(kind)) id = VibrationEffect.EFFECT_HEAVY_CLICK;
        else if ("double".equals(kind)) id = VibrationEffect.EFFECT_DOUBLE_CLICK;
        else id = VibrationEffect.EFFECT_CLICK;
        vibrator.vibrate(VibrationEffect.createPredefined(id));
    }
}
