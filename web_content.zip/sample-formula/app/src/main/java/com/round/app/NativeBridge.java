package com.round.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

/**
 * What the page can ask the phone to do, as window.RoundNative.*
 *
 * JavascriptInterface methods run on a background thread, so anything that touches the UI goes through runOnUiThread.
 * Only the app's own bundled page is ever loaded in this WebView (other links open in the browser), so exposing this is safe.
 */
public final class NativeBridge {

    private final Activity activity;
    private final Haptics haptics;

    NativeBridge(Activity activity) {
        this.activity = activity;
        this.haptics = new Haptics(activity);
    }

    /** navigator.vibrate(pattern) arrives here as a JSON array of milliseconds, e.g. "[10]" or "[20,40,20]". */
    @JavascriptInterface
    public void vibrate(String patternJson) {
        try {
            JSONArray arr = new JSONArray(patternJson);
            int n = Math.min(arr.length(), 20);
            long[] ms = new long[n];
            for (int i = 0; i < n; i++) ms[i] = Math.max(0L, arr.optLong(i, 0L));
            haptics.pattern(ms);
        } catch (JSONException ignored) {
            // a malformed pattern is not worth crashing for
        }
    }

    /** kind: "tick", "click", "heavy" or "double". */
    @JavascriptInterface
    public void haptic(String kind) {
        haptics.effect(kind);
    }

    @JavascriptInterface
    public void share(final String text) {
        if (text == null || text.isEmpty()) return;
        runOnUi(() -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text);
            activity.startActivity(Intent.createChooser(send, null));
        });
    }

    @JavascriptInterface
    public void copy(final String text) {
        runOnUi(() -> {
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Round", text == null ? "" : text));
                Toast.makeText(activity, "Copied", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @JavascriptInterface
    public void toast(final String message) {
        if (message == null || message.isEmpty()) return;
        runOnUi(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
    }

    /** Opens http(s), mailto and tel links outside the app. Anything else is ignored. */
    @JavascriptInterface
    public void openExternal(String url) {
        if (url == null) return;
        final Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();
        if (scheme == null) return;
        if (!(scheme.equals("http") || scheme.equals("https") || scheme.equals("mailto") || scheme.equals("tel"))) return;
        runOnUi(() -> {
            try {
                activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (ActivityNotFoundException ignored) {
                // no app can open it
            }
        });
    }

    /** Saves a file the page generated (a downloaded board image, for example). base64 is the raw payload without the data: prefix. */
    @JavascriptInterface
    public void saveFile(String name, String mime, String base64) {
        try {
            String where = FileSaver.save(activity, name, mime, base64);
            toast("Saved to " + where);
        } catch (IOException | IllegalArgumentException e) {
            toast("Couldn't save the file");
        }
    }

    /** JSON the page can read once at start: window.RoundApp.info. */
    @JavascriptInterface
    public String deviceInfo() {
        JSONObject o = new JSONObject();
        try {
            PackageInfo pi = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
            o.put("app", "sample-formula");
            o.put("version", pi.versionName);
            o.put("manufacturer", Build.MANUFACTURER);
            o.put("model", Build.MODEL);
            o.put("android", Build.VERSION.RELEASE);
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("density", activity.getResources().getDisplayMetrics().density);
        } catch (JSONException | PackageManager.NameNotFoundException ignored) {
            // return whatever was filled in
        }
        return o.toString();
    }

    private void runOnUi(Runnable r) {
        activity.runOnUiThread(r);
    }
}
