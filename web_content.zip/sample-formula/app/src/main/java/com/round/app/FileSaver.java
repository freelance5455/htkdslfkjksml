package com.round.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import java.io.IOException;
import java.io.OutputStream;

/** Saves files the page makes (a WebView cannot download blob: links by itself). Needs no storage permission on Android 10+. */
final class FileSaver {

    private FileSaver() {}

    /** @return the folder the file ended up in, for a toast such as "Saved to Pictures/Round". */
    static String save(Context context, String name, String mime, String base64) throws IOException {
        byte[] data = Base64.decode(base64, Base64.DEFAULT);

        String safe = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (safe.isEmpty()) safe = "round-file";
        String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
        boolean image = type.startsWith("image/");

        String folder = (image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/Round";
        Uri collection = image
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);

        ContentResolver resolver = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
        values.put(MediaStore.MediaColumns.MIME_TYPE, type);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);      // hidden until fully written

        Uri uri = resolver.insert(collection, values);
        if (uri == null) throw new IOException("Could not create the file");

        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IOException("Could not open the file");
            out.write(data);
        } catch (IOException e) {
            resolver.delete(uri, null, null);
            throw e;
        }

        values.clear();
        values.put(MediaStore.MediaColumns.IS_PENDING, 0);
        resolver.update(uri, values, null, null);
        return folder;
    }
}
