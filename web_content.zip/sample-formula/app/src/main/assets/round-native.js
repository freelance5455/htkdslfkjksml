/* Connects the Round page to the Android shell. Safe to run twice; does nothing in a normal browser. */
(function () {
  "use strict";
  var N = window.RoundNative;
  if (!N || window.__roundNativeReady) return;
  window.__roundNativeReady = true;

  /* Haptics: the page already calls navigator.vibrate; send it to the native haptic engine. */
  navigator.vibrate = function (pattern) {
    try { N.vibrate(JSON.stringify(Array.isArray(pattern) ? pattern : [pattern])); } catch (e) {}
    return true;
  };

  /* Back button: close whatever is open and say whether anything was. */
  window.__roundBack = function () {
    var q = function (s) { return document.querySelector(s); };
    try {
      if (q("#personalitySheet.open")) { window.dispatchEvent(new CustomEvent("personality:toggle")); return true; }
      if (q("#devicePanel.open") && typeof closeDevicePanel === "function") { closeDevicePanel(); return true; }
      if (q("#cmpCard.open") || q("#mdOver.open") || q("#chatView.open")) {
        document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        return true;
      }
    } catch (e) {}
    return false;
  };

  /* Downloads: a WebView cannot save blob: or data: links, so hand them to the Java FileSaver. */
  function saveFromUrl(url, name) {
    fetch(url).then(function (r) { return r.blob(); }).then(function (blob) {
      var fr = new FileReader();
      fr.onloadend = function () {
        var s = String(fr.result || ""), i = s.indexOf(",");
        N.saveFile(name, blob.type || "application/octet-stream", s.slice(i + 1));
      };
      fr.readAsDataURL(blob);
    }).catch(function () { try { N.toast("Couldn't save the file"); } catch (e) {} });
  }
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var href = this.href || "";
    if (this.hasAttribute("download") && /^(blob:|data:)/.test(href)) {
      saveFromUrl(href, this.getAttribute("download") || "round-file");
      return;
    }
    return origClick.apply(this, arguments);
  };

  /* A small API for the page itself: if (window.RoundApp) { RoundApp.share("...") } */
  var info = {};
  try { info = JSON.parse(N.deviceInfo()); } catch (e) {}
  window.RoundApp = {
    native: true,
    info: info,
    share: function (text) { N.share(String(text == null ? "" : text)); },
    copy: function (text) { N.copy(String(text == null ? "" : text)); },
    toast: function (msg) { N.toast(String(msg == null ? "" : msg)); },
    haptic: function (kind) { N.haptic(String(kind || "click")); },
    openExternal: function (url) { N.openExternal(String(url || "")); }
  };
})();
