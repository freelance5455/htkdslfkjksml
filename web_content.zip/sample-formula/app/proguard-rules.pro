# Methods the page calls through window.RoundNative must survive shrinking.
-keepclassmembers class com.round.app.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
