# Prüfliste (korrigierte Version)

## Behoben in dieser Version
- [x] Tempo-Slider greift auch bei Piper (`playbackRate`)
- [x] Modell-Proxy auf offizielles `rhasspy/piper-voices` umgestellt
- [x] Service Worker lässt `/piper-model/*` unangetastet (kein Cache-Konflikt)
- [x] Cache-Versionierung und `skipWaiting`/`clients.claim`
- [x] Redirect-Tests und Syntax-Checks grün

## Nach dem Netlify-Upload manuell prüfen
- [ ] ZIP hochladen → **Published**
- [ ] `/piper-model/de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx.json` liefert JSON (nicht 404/HTML)
- [ ] Kurzen Text mit Piper starten → hörbare Ausgabe
- [ ] Pause / Weiter / Stopp
- [ ] Tempo-Slider ändert Geschwindigkeit
- [ ] Nach erstem Lauf: Offline (Flugmodus) erneut starten → funktioniert
- [ ] Gerätestimme als Fallback auswählen und testen
