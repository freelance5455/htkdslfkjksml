SUPER RUNNER 3D — Android Studio Project

এই প্রজেক্টে আপনার আপলোড করা APK-এর ভেতরের assets/res.zip থেকে পাওয়া index.html গেম ফাইলটি রাখা হয়েছে।

AAB বানানোর ধাপ:
1. ZIP ফাইলটি Extract করুন।
2. কম্পিউটারে Android Studio খুলে File > Open দিয়ে SuperRunning3D ফোল্ডারটি খুলুন।
3. Gradle Sync শেষ হতে দিন। Android SDK Platform 35 এবং JDK 17 ইনস্টল/নির্বাচিত থাকতে হবে।
4. Build > Generate Signed Bundle / APK নির্বাচন করুন।
5. Android App Bundle নির্বাচন করে Next চাপুন।
6. নতুন keystore তৈরি করে release AAB তৈরি করুন। keystore ও password নিরাপদে সংরক্ষণ করুন।

গুরুত্বপূর্ণ:
- এখানে AAB তৈরি করা হয়নি; এটি AAB তৈরির জন্য Android Studio project source।
- গেমের HTML-এ Three.js 0.160.0 jsDelivr CDN থেকে লোড হয়। তাই গেম চালাতে ইন্টারনেট লাগবে।
- নতুন applicationId: com.superrunning3d.mywebapp। আগের APK-এর applicationId যদি আলাদা হয়, Play Store-এ এটি আলাদা অ্যাপ হিসেবে গণ্য হবে।
- Play Store-এ প্রকাশের আগে target SDK, privacy policy, app icon, screenshots, content rating, signing এবং বর্তমান Play Console requirements যাচাই করুন।
