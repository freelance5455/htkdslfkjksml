// سرور پیام‌رسان — بدون وابستگی (فقط Node.js نسخه ۱۸ یا بالاتر)
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const __dir = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const DATA = process.env.DATA_DIR || path.join(__dir, "data");
const FILES = path.join(DATA, "files");
fs.mkdirSync(FILES, { recursive: true });

const users = JSON.parse(fs.readFileSync(path.join(__dir, "users.json"), "utf8")); // { نام: رمز }
const names = Object.keys(users);
const SECRET_FILE = path.join(DATA, "secret.txt");
if (!fs.existsSync(SECRET_FILE)) fs.writeFileSync(SECRET_FILE, crypto.randomBytes(32).toString("hex"));
const SECRET = fs.readFileSync(SECRET_FILE, "utf8").trim();

// ---------- ذخیره‌سازی ----------
const DB_FILE = path.join(DATA, "db.json");
let store = { docs: {}, files: {} };
try { store = JSON.parse(fs.readFileSync(DB_FILE, "utf8")); } catch {}
store.docs ||= {}; store.files ||= {};
const docs = store.docs;
let saveT;
const save = () => {
  clearTimeout(saveT);
  saveT = setTimeout(() => fs.writeFile(DB_FILE + ".tmp", JSON.stringify(store), () => fs.rename(DB_FILE + ".tmp", DB_FILE, () => {})), 400);
};
docs["chats/all"] = { type: "group", name: "همه", members: names, by: "", ts: docs["chats/all"]?.ts || Date.now() };
save();

// ---------- احراز هویت ----------
const sign = (n) => crypto.createHmac("sha256", SECRET).update(n).digest("hex");
const mkToken = (n) => Buffer.from(n).toString("base64url") + "." + sign(n);
function verify(t) {
  const [a, s] = String(t || "").split(".");
  if (!a || !s) return null;
  const n = Buffer.from(a, "base64url").toString(), e = sign(n);
  return s.length === e.length && crypto.timingSafeEqual(Buffer.from(s), Buffer.from(e)) && names.includes(n) ? n : null;
}
const tries = new Map();
const limited = (ip) => {
  const now = Date.now(), a = (tries.get(ip) || []).filter((t) => now - t < 600000);
  tries.set(ip, a);
  return a.length >= 10;
};
const readJson = (req) => new Promise((res) => {
  let b = "";
  req.on("data", (c) => { b += c; if (b.length > 65536) req.destroy(); });
  req.on("end", () => { try { res(JSON.parse(b)); } catch { res({}); } });
});

// ---------- HTTP ----------
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".png": "image/png", ".svg": "image/svg+xml", ".webmanifest": "application/manifest+json" };

function upload(req, res, u, me, json) {
  if (!me) { req.resume(); return json(401, {}); }
  const id = crypto.randomBytes(12).toString("hex"), tmp = path.join(FILES, id + ".part");
  const out = fs.createWriteStream(tmp);
  let size = 0;
  req.on("data", (c) => (size += c.length));
  req.pipe(out);
  out.on("finish", () => {
    fs.renameSync(tmp, path.join(FILES, id));
    store.files[id] = { name: (u.searchParams.get("name") || "file").slice(0, 200), mime: (u.searchParams.get("mime") || "application/octet-stream").slice(0, 100), size, by: me };
    save();
    json(200, { url: "/f/" + id, size });
  });
  req.on("aborted", () => { out.destroy(); fs.unlink(tmp, () => {}); });
  out.on("error", () => json(500, {}));
}

function serveFile(req, res, u, me) {
  if (!me) { res.writeHead(401); return res.end(); }
  const id = u.pathname.slice(3).replace(/[^a-f0-9]/g, ""), meta = store.files[id], fp = path.join(FILES, id);
  if (!meta || !fs.existsSync(fp)) { res.writeHead(404); return res.end(); }
  const total = fs.statSync(fp).size;
  const media = /^(image\/(?!svg)|video\/|audio\/)/.test(meta.mime);
  const h = { "Content-Type": media ? meta.mime : "application/octet-stream", "Accept-Ranges": "bytes", "X-Content-Type-Options": "nosniff", "Cache-Control": "private, max-age=31536000" };
  if (!media || u.searchParams.get("dl")) h["Content-Disposition"] = "attachment; filename*=UTF-8''" + encodeURIComponent(meta.name);
  let start = 0, end = total - 1, code = 200;
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || "");
  if (m && (m[1] || m[2])) {
    if (m[1]) { start = +m[1]; if (m[2]) end = Math.min(+m[2], total - 1); } else start = Math.max(0, total - +m[2]);
    code = 206; h["Content-Range"] = `bytes ${start}-${end}/${total}`;
  }
  if (total === 0 || start > end || start >= total) { res.writeHead(416, { "Content-Range": `bytes */${total}` }); return res.end(); }
  h["Content-Length"] = end - start + 1;
  res.writeHead(code, h);
  fs.createReadStream(fp, { start, end }).pipe(res);
}

function serveStatic(res, p) {
  const root = path.join(__dir, "public"), f = path.join(root, decodeURIComponent(p === "/" ? "/index.html" : p));
  if (!f.startsWith(root + path.sep) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end("not found"); }
  res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream" });
  fs.createReadStream(f).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, "http://x");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }
  const me = verify(u.searchParams.get("token") || (req.headers.authorization || "").replace(/^Bearer /, ""));
  const json = (c, o) => { res.writeHead(c, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
  try {
    if (u.pathname === "/api/ping") return json(200, { ok: "msg-server" });
    if (u.pathname === "/api/login" && req.method === "POST") {
      const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim();
      if (limited(ip)) return json(429, { ok: false, error: "rate" });
      const pw = String((await readJson(req)).password || "").trim().toLowerCase();
      const name = names.find((n) => String(users[n]).trim().toLowerCase() === pw);
      if (!name) { tries.get(ip).push(Date.now()); return json(401, { ok: false }); }
      return json(200, { ok: true, name, token: mkToken(name) });
    }
    if (u.pathname === "/api/users") return me ? json(200, { users: names }) : json(401, {});
    if (u.pathname === "/upload" && req.method === "POST") return upload(req, res, u, me, json);
    if (u.pathname.startsWith("/f/")) return serveFile(req, res, u, me);
    return serveStatic(res, u.pathname);
  } catch { json(500, {}); }
});

// ---------- WebSocket (پیاده‌سازی ساده، بدون کتابخانه) ----------
const clients = new Set();
class WS {
  constructor(sock, me) { this.sock = sock; this.me = me; this.subs = {}; this.buf = Buffer.alloc(0); this.readyState = 1;
    sock.on("data", (d) => { this.buf = Buffer.concat([this.buf, d]); this.parse(); });
    sock.on("close", () => this.close()); sock.on("error", () => this.close()); }
  parse() {
    for (;;) {
      const b = this.buf; if (b.length < 2) return;
      const op = b[0] & 15, masked = b[1] & 128; let len = b[1] & 127, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > 1e6) return this.close();
      const mo = masked ? 4 : 0;
      if (b.length < off + mo + len) return;
      let p = b.subarray(off + mo, off + mo + len);
      if (masked) { const k = b.subarray(off, off + 4); p = Buffer.from(p.map((x, i) => x ^ k[i & 3])); }
      this.buf = b.subarray(off + mo + len);
      if (op === 8) return this.close();
      if (op === 9) this.frame(10, p);
      else if (op === 1) onMessage(this, p.toString());
    }
  }
  frame(op, p) {
    const n = p.length; let h;
    if (n < 126) h = Buffer.from([128 | op, n]);
    else if (n < 65536) { h = Buffer.alloc(4); h[0] = 128 | op; h[1] = 126; h.writeUInt16BE(n, 2); }
    else { h = Buffer.alloc(10); h[0] = 128 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(n), 2); }
    if (this.readyState === 1) this.sock.write(Buffer.concat([h, p]));
  }
  send(s) { this.frame(1, Buffer.from(s)); }
  close() { if (!this.readyState) return; this.readyState = 0; clients.delete(this); try { this.sock.destroy(); } catch {} }
}
server.on("upgrade", (req, sock) => {
  const u = new URL(req.url, "http://x"), me = u.pathname === "/ws" ? verify(u.searchParams.get("token")) : null;
  if (!me || !req.headers["sec-websocket-key"]) { sock.write("HTTP/1.1 401 Unauthorized\r\n\r\n"); return sock.destroy(); }
  const acc = crypto.createHash("sha1").update(req.headers["sec-websocket-key"] + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").digest("base64");
  sock.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${acc}\r\n\r\n`);
  clients.add(new WS(sock, me));
});
setInterval(() => clients.forEach((c) => c.frame(9, Buffer.alloc(0))), 30000);

// ---------- منطق داده و دسترسی ----------
const member = (cid, u) => !!docs["chats/" + cid]?.members?.includes(u);
function snap(ws, id, ch = []) {
  const p = ws.subs[id], pre = p + "/";
  let out = [];
  for (const k in docs) if (k.startsWith(pre) && !k.slice(pre.length).includes("/")) out.push([k.slice(pre.length), docs[k]]);
  out.sort((a, b) => (a[1].ts || 0) - (b[1].ts || 0));
  out = p === "chats" ? out.filter(([, d]) => d.members?.includes(ws.me)) : out.slice(-300);
  ws.send(JSON.stringify({ op: "snap", id, docs: out.map(([i, d]) => ({ id: i, d })), ch }));
}
const notify = (col, ch) => clients.forEach((c) => { for (const id in c.subs) if (c.subs[id] === col) snap(c, id, ch); });

function createChat(id, d, me) {
  d = d || {};
  const members = [...new Set(Array.isArray(d.members) ? d.members : [])].filter((n) => names.includes(n));
  if (!members.includes(me) || members.length < 2 || !["dm", "group"].includes(d.type)) throw new Error("bad chat");
  if (d.type === "dm" && members.length !== 2) throw new Error("bad dm");
  docs["chats/" + id] = { type: d.type, name: String(d.name || "").slice(0, 60), members, by: me, ts: Date.now() };
  save();
  notify("chats", [{ t: "added", id }]);
}

function handle(ws, m) {
  const me = ws.me, p = String(m.path || ""), s = p.split("/");
  const ok = (x) => ws.send(JSON.stringify({ rid: m.rid, ok: true, ...x }));
  if (m.op === "unsub") { delete ws.subs[m.id]; return; }
  if (m.op === "sub") {
    if (!(p === "chats" || (/^chats\/[\w-]+\/msgs$/.test(p) && member(s[1], me)))) throw new Error("denied");
    ws.subs[m.id] = p; return snap(ws, m.id);
  }
  if (!/^chats$|^chats\/[\w-]+(\/msgs(\/[\w-]+)?)?$/.test(p)) throw new Error("bad path");

  if (m.op === "get") {
    const d = docs[p];
    if (d && !member(s[1], me)) throw new Error("denied");
    return ok({ exists: !!d, data: d });
  }
  if (m.op === "add" && p === "chats") { const id = crypto.randomBytes(5).toString("hex"); createChat(id, m.data, me); return ok({ id }); }
  if (m.op === "set" && s.length === 2) {
    if (docs[p]) { if (!member(s[1], me)) throw new Error("denied"); return ok({}); }
    createChat(s[1], m.data, me); return ok({});
  }
  if (m.op === "add" && s.length === 3 && s[2] === "msgs") {
    if (!member(s[1], me)) throw new Error("denied");
    const d = m.data || {}, id = Date.now().toString(36) + crypto.randomBytes(3).toString("hex");
    const doc = { who: me, ts: Date.now(), t: String(d.t || "").slice(0, 5000) };
    if (d.q) doc.q = String(d.q).slice(0, 300);
    if (/^\/f\/[a-f0-9]+$/.test(d.url || "")) { doc.url = d.url; doc.mime = String(d.mime || "").slice(0, 100); doc.f = +d.f || 0; }
    docs[p + "/" + id] = doc; save(); notify(p, [{ t: "added", id }]);
    return ok({ id });
  }
  if (m.op === "update" && s.length === 4) {
    const d = docs[p];
    if (!d || !member(s[1], me)) throw new Error("denied");
    for (const k in m.data || {}) {
      if (k === "r_" + me) d[k] = String(m.data[k]).slice(0, 8);
      else if (k === "t" && d.who === me) { d.t = String(m.data.t).slice(0, 5000); d.edited = true; }
    }
    save(); notify(s.slice(0, 3).join("/"), [{ t: "modified", id: s[3] }]);
    return ok({});
  }
  if (m.op === "del") {
    const d = docs[p];
    if (!d) return ok({});
    if (s.length === 4) {
      if (d.who !== me) throw new Error("denied");
      delete docs[p]; save(); notify(s.slice(0, 3).join("/"), [{ t: "removed", id: s[3] }]); return ok({});
    }
    if (s.length === 2) {
      if (d.by !== me) throw new Error("denied");
      for (const k of Object.keys(docs)) if (k === p || k.startsWith(p + "/")) delete docs[k];
      save(); notify("chats", [{ t: "removed", id: s[1] }]); notify(p + "/msgs", []); return ok({});
    }
  }
  throw new Error("unsupported");
}
function onMessage(ws, raw) {
  let m; try { m = JSON.parse(raw); } catch { return; }
  try { handle(ws, m); } catch (e) { ws.send(JSON.stringify({ rid: m.rid, err: String(e.message || e) })); }
}

server.listen(PORT, () => console.log("پیام‌رسان روی پورت " + PORT + " آماده است"));
