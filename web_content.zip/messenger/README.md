# پیام‌رسان دوستان

## ۱) اجرای سرور
نیاز: یک سرور (VPS ارزان یا هر کامپیوتر همیشه روشن) با Node.js نسخه ۱۸ به بالا. هیچ کتابخانه‌ای لازم نیست.

    node server.js          # پورت ۳۰۰۰
    # یا ماندگار: npm i -g pm2 && pm2 start server.js --name chat && pm2 save

- رمزها در فایل `users.json` هستند (هر نام: رمز). عوضشان کنید و سرور را ری‌استارت کنید.
- پیام‌ها و فایل‌ها در پوشه `data/` ذخیره می‌شوند. از آن بکاپ بگیرید.
- حجم فایل محدودیتی ندارد؛ فقط فضای دیسک سرور.

## ۲) HTTPS (برای اپ اندروید لازم است)
یک دامنه به سرور وصل کنید و Caddy بگذارید (گواهی را خودش می‌گیرد). فایل `Caddyfile` همین پوشه نمونه است.
بعد از آن آدرس `https://chat.example.com` در مرورگر هم کار می‌کند.
اگر از Cloudflare Tunnel یا پراکسی Cloudflare استفاده کنید، آپلود بالای ۱۰۰ مگابایت رد می‌شود.

## ۳) ساخت APK (ساده‌ترین راه)
اپ یک صفحه وب است که به سرور وصل می‌شود، پس APK می‌تواند همان آدرس را باز کند:

    npm i @capacitor/core @capacitor/cli @capacitor/android
    npx cap init Messenger com.friends.messenger --web-dir=public
    # در capacitor.config.json اضافه کنید:  "server": { "url": "https://chat.example.com" }
    npx cap add android
    npx cap open android      # در Android Studio: Build > Build APK

مزیتش: هر تغییری در `public/index.html` روی سرور، بدون ساخت دوباره APK به دوستان می‌رسد.
برای دوربین، در `AndroidManifest.xml` مجوز `CAMERA` را اضافه کنید.

## محدودیت‌ها
- وقتی اپ بسته است اعلان نمی‌آید (برای آن Firebase لازم است). پیام‌ها هنگام باز شدن اپ می‌رسند.
- رمزگذاری سرتاسری ندارد؛ ادمین سرور می‌تواند پیام‌ها را ببیند.
