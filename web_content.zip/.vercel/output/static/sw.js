/* غلاف التطبيق: بعد أول زيارة يعمل الصفحة والملف الداخلي بدون شبكة */
const CACHE = "awrad-shell-v1";
const PRECACHE = ["/awrad/index.html", "/awrad/tw.css", "/awrad/manifest.webmanifest", "/awrad/icon-192.png", "/awrad/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    fetch(request)
      .then((response) => {
        if (response && response.ok && (url.pathname === "/" || url.pathname.startsWith("/awrad/") || url.pathname.startsWith("/assets/"))) {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(request, copy)).catch(() => {});
        }
        return response;
      })
      .catch(() => caches.match(request).then((cached) => cached || caches.match("/awrad/index.html"))),
  );
});
