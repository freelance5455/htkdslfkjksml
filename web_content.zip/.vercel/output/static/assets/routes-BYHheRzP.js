import{i as e,n as t,r as n,t as r}from"./index-COEzJtnF.js";var i=r(`chevron-left`,[[`path`,{d:`m15 18-6-6 6-6`,key:`1wnfg3`}]]),a=r(`eye-off`,[[`path`,{d:`M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49`,key:`ct8e1f`}],[`path`,{d:`M14.084 14.158a3 3 0 0 1-4.242-4.242`,key:`151rxh`}],[`path`,{d:`M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143`,key:`13bj9a`}],[`path`,{d:`m2 2 20 20`,key:`1ooewy`}]]),o=r(`eye`,[[`path`,{d:`M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0`,key:`1nclc0`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]),s=r(`lock`,[[`rect`,{width:`18`,height:`11`,x:`3`,y:`11`,rx:`2`,ry:`2`,key:`1w4ew1`}],[`path`,{d:`M7 11V7a5 5 0 0 1 10 0v4`,key:`fwvmzm`}]]),c=r(`minus`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}]]),l=r(`plus`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}],[`path`,{d:`M12 5v14`,key:`s699le`}]]),u=r(`search`,[[`path`,{d:`m21 21-4.34-4.34`,key:`14j7rj`}],[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}]]),d=r(`settings`,[[`path`,{d:`M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z`,key:`1qme2f`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]),f=r(`trash-2`,[[`path`,{d:`M3 6h18`,key:`d0wm0j`}],[`path`,{d:`M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6`,key:`4alrt4`}],[`path`,{d:`M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2`,key:`v07s0e`}],[`line`,{x1:`10`,x2:`10`,y1:`11`,y2:`17`,key:`1uufr5`}],[`line`,{x1:`14`,x2:`14`,y1:`11`,y2:`17`,key:`xtxkd`}]]),p=r(`x`,[[`path`,{d:`M18 6 6 18`,key:`1bl5f8`}],[`path`,{d:`m6 6 12 12`,key:`d8bk6v`}]]),m=e(n(),1);function h(e){var t,n,r=``;if(typeof e==`string`||typeof e==`number`)r+=e;else if(typeof e==`object`){if(Array.isArray(e)){var i=e.length;for(t=0;t<i;t++)e[t]&&(n=h(e[t]))&&(r&&(r+=` `),r+=n)}else for(n in e)e[n]&&(r&&(r+=` `),r+=n)}return r}function g(){for(var e,t,n=0,r=``,i=arguments.length;n<i;n++)(e=arguments[n])&&(t=h(e))&&(r&&(r+=` `),r+=t);return r}var _=e=>typeof e==`boolean`?`${e}`:e===0?`0`:e,v=g,y=(e,t)=>n=>{if(t?.variants==null)return v(e,n?.class,n?.className);let{variants:r,defaultVariants:i}=t,a=Object.keys(r).map(e=>{let t=n?.[e],a=i?.[e];if(t===null)return null;let o=_(t)||_(a);return r[e][o]}),o=n&&Object.entries(n).reduce((e,t)=>{let[n,r]=t;return r===void 0||(e[n]=r),e},{});return v(e,a,t?.compoundVariants?.reduce((e,t)=>{let{class:n,className:r,...a}=t;return Object.entries(a).every(e=>{let[t,n]=e;return Array.isArray(n)?n.includes({...i,...o}[t]):{...i,...o}[t]===n})?[...e,n,r]:e},[]),n?.class,n?.className)},b=(e,t)=>{let n=Array(e.length+t.length);for(let t=0;t<e.length;t++)n[t]=e[t];for(let r=0;r<t.length;r++)n[e.length+r]=t[r];return n},ee=(e,t)=>({classGroupId:e,validator:t}),x=(e=new Map,t=null,n)=>({nextPart:e,validators:t,classGroupId:n}),S=`-`,C=[],w=`arbitrary..`,te=e=>{let t=re(e),{conflictingClassGroups:n,conflictingClassGroupModifiers:r}=e;return{getClassGroupId:e=>{if(e.startsWith(`[`)&&e.endsWith(`]`))return T(e);let n=e.split(S);return ne(n,+(n[0]===``&&n.length>1),t)},getConflictingClassGroupIds:(e,t)=>{if(t){let t=r[e],i=n[e];return t?i?b(i,t):t:i||C}return n[e]||C}}},ne=(e,t,n)=>{if(e.length-t===0)return n.classGroupId;let r=e[t],i=n.nextPart.get(r);if(i){let n=ne(e,t+1,i);if(n)return n}let a=n.validators;if(a===null)return;let o=t===0?e.join(S):e.slice(t).join(S),s=a.length;for(let e=0;e<s;e++){let t=a[e];if(t.validator(o))return t.classGroupId}},T=e=>e.slice(1,-1).indexOf(`:`)===-1?void 0:(()=>{let t=e.slice(1,-1),n=t.indexOf(`:`),r=t.slice(0,n);return r?w+r:void 0})(),re=e=>{let{theme:t,classGroups:n}=e;return ie(n,t)},ie=(e,t)=>{let n=x();for(let r in e){let i=e[r];E(i,n,r,t)}return n},E=(e,t,n,r)=>{let i=e.length;for(let a=0;a<i;a++){let i=e[a];D(i,t,n,r)}},D=(e,t,n,r)=>{if(typeof e==`string`){O(e,t,n);return}if(typeof e==`function`){ae(e,t,n,r);return}oe(e,t,n,r)},O=(e,t,n)=>{let r=e===``?t:k(t,e);r.classGroupId=n},ae=(e,t,n,r)=>{if(se(e)){E(e(r),t,n,r);return}t.validators===null&&(t.validators=[]),t.validators.push(ee(n,e))},oe=(e,t,n,r)=>{let i=Object.entries(e),a=i.length;for(let e=0;e<a;e++){let[a,o]=i[e];E(o,k(t,a),n,r)}},k=(e,t)=>{let n=e,r=t.split(S),i=r.length;for(let e=0;e<i;e++){let t=r[e],i=n.nextPart.get(t);i||(i=x(),n.nextPart.set(t,i)),n=i}return n},se=e=>`isThemeGetter`in e&&e.isThemeGetter===!0,ce=e=>{if(e<1)return{get:()=>void 0,set:()=>{}};let t=0,n=Object.create(null),r=Object.create(null),i=(i,a)=>{n[i]=a,t++,t>e&&(t=0,r=n,n=Object.create(null))};return{get(e){let t=n[e];if(t!==void 0)return t;if((t=r[e])!==void 0)return i(e,t),t},set(e,t){e in n?n[e]=t:i(e,t)}}},A=`!`,j=`:`,M=[],N=(e,t,n,r,i)=>({modifiers:e,hasImportantModifier:t,baseClassName:n,maybePostfixModifierPosition:r,isExternal:i}),P=e=>{let{prefix:t,experimentalParseClassName:n}=e,r=e=>{let t=[],n=0,r=0,i=0,a,o=e.length;for(let s=0;s<o;s++){let o=e[s];if(n===0&&r===0){if(o===j){t.push(e.slice(i,s)),i=s+1;continue}if(o===`/`){a=s;continue}}o===`[`?n++:o===`]`?n--:o===`(`?r++:o===`)`&&r--}let s=t.length===0?e:e.slice(i),c=s,l=!1;s.endsWith(A)?(c=s.slice(0,-1),l=!0):s.startsWith(A)&&(c=s.slice(1),l=!0);let u=a&&a>i?a-i:void 0;return N(t,l,c,u)};if(t){let e=t+j,n=r;r=t=>t.startsWith(e)?n(t.slice(e.length)):N(M,!1,t,void 0,!0)}if(n){let e=r;r=t=>n({className:t,parseClassName:e})}return r},le=e=>{let t=new Map;return e.orderSensitiveModifiers.forEach((e,n)=>{t.set(e,1e6+n)}),e=>{let n=[],r=[];for(let i=0;i<e.length;i++){let a=e[i],o=a[0]===`[`,s=t.has(a);o||s?(r.length>0&&(r.sort(),n.push(...r),r=[]),n.push(a)):r.push(a)}return r.length>0&&(r.sort(),n.push(...r)),n}},F=e=>({cache:ce(e.cacheSize),parseClassName:P(e),sortModifiers:le(e),postfixLookupClassGroupIds:ue(e),...te(e)}),ue=e=>{let t=Object.create(null),n=e.postfixLookupClassGroups;if(n)for(let e=0;e<n.length;e++)t[n[e]]=!0;return t},de=/\s+/,fe=(e,t)=>{let{parseClassName:n,getClassGroupId:r,getConflictingClassGroupIds:i,sortModifiers:a,postfixLookupClassGroupIds:o}=t,s=[],c=e.trim().split(de),l=``;for(let e=c.length-1;e>=0;--e){let t=c[e],{isExternal:u,modifiers:d,hasImportantModifier:f,baseClassName:p,maybePostfixModifierPosition:m}=n(t);if(u){l=t+(l.length>0?` `+l:l);continue}let h=!!m,g;if(h){g=r(p.substring(0,m));let e=g&&o[g]?r(p):void 0;e&&e!==g&&(g=e,h=!1)}else g=r(p);if(!g){if(!h){l=t+(l.length>0?` `+l:l);continue}if(g=r(p),!g){l=t+(l.length>0?` `+l:l);continue}h=!1}let _=d.length===0?``:d.length===1?d[0]:a(d).join(`:`),v=f?_+A:_,y=v+g;if(s.indexOf(y)>-1)continue;s.push(y);let b=i(g,h);for(let e=0;e<b.length;++e){let t=b[e];s.push(v+t)}l=t+(l.length>0?` `+l:l)}return l},pe=(...e)=>{let t=0,n,r,i=``;for(;t<e.length;)(n=e[t++])&&(r=I(n))&&(i&&(i+=` `),i+=r);return i},I=e=>{if(typeof e==`string`)return e;let t,n=``;for(let r=0;r<e.length;r++)e[r]&&(t=I(e[r]))&&(n&&(n+=` `),n+=t);return n},me=(e,...t)=>{let n,r,i,a,o=o=>(n=F(t.reduce((e,t)=>t(e),e())),r=n.cache.get,i=n.cache.set,a=s,s(o)),s=e=>{let t=r(e);if(t)return t;let a=fe(e,n);return i(e,a),a};return a=o,(...e)=>a(pe(...e))},he=[],L=e=>{let t=t=>t[e]||he;return t.isThemeGetter=!0,t.themeKey=e,t},ge=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,_e=/^\((?:(\w[\w-]*):)?(.+)\)$/i,ve=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,ye=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,be=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,xe=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix|color|light-dark)\(.+\)$/,Se=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,Ce=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,R=e=>ve.test(e),z=e=>!!e&&!Number.isNaN(Number(e)),B=e=>!!e&&Number.isInteger(Number(e)),we=e=>e.endsWith(`%`)&&z(e.slice(0,-1)),V=e=>ye.test(e),Te=()=>!0,Ee=e=>be.test(e)&&!xe.test(e),De=()=>!1,Oe=e=>Se.test(e),ke=e=>Ce.test(e),Ae=e=>!H(e)&&!W(e),je=e=>e.startsWith(`@container`)&&(e[10]===`/`&&e[11]!==void 0||e[11]===`s`&&e[16]!==void 0&&e.startsWith(`-size/`,10)||e[11]===`n`&&e[18]!==void 0&&e.startsWith(`-normal/`,10)),Me=e=>K(e,qe,De),H=e=>ge.test(e),U=e=>K(e,Je,Ee),Ne=e=>K(e,Ye,z),Pe=e=>K(e,Ze,Te),Fe=e=>K(e,Xe,De),Ie=e=>K(e,Ge,De),Le=e=>K(e,Ke,ke),Re=e=>K(e,Qe,Oe),W=e=>_e.test(e),G=e=>q(e,Je),ze=e=>q(e,Xe),Be=e=>q(e,Ge),Ve=e=>q(e,qe),He=e=>q(e,Ke),Ue=e=>q(e,Qe,!0),We=e=>q(e,Ze,!0),K=(e,t,n)=>{let r=ge.exec(e);return r?r[1]?t(r[1]):n(r[2]):!1},q=(e,t,n=!1)=>{let r=_e.exec(e);return r?r[1]?t(r[1]):n:!1},Ge=e=>e===`position`||e===`percentage`,Ke=e=>e===`image`||e===`url`,qe=e=>e===`length`||e===`size`||e===`bg-size`,Je=e=>e===`length`,Ye=e=>e===`number`,Xe=e=>e===`family-name`,Ze=e=>e===`number`||e===`weight`,Qe=e=>e===`shadow`,$e=me(()=>{let e=L(`color`),t=L(`font`),n=L(`text`),r=L(`font-weight`),i=L(`tracking`),a=L(`leading`),o=L(`breakpoint`),s=L(`container`),c=L(`spacing`),l=L(`radius`),u=L(`shadow`),d=L(`inset-shadow`),f=L(`text-shadow`),p=L(`drop-shadow`),m=L(`blur`),h=L(`perspective`),g=L(`aspect`),_=L(`ease`),v=L(`animate`),y=()=>[`auto`,`avoid`,`all`,`avoid-page`,`page`,`left`,`right`,`column`],b=()=>[`center`,`top`,`bottom`,`left`,`right`,`top-left`,`left-top`,`top-right`,`right-top`,`bottom-right`,`right-bottom`,`bottom-left`,`left-bottom`],ee=()=>[...b(),W,H],x=()=>[`auto`,`hidden`,`clip`,`visible`,`scroll`],S=()=>[`auto`,`contain`,`none`],C=()=>[W,H,c],w=()=>[R,`full`,`auto`,...C()],te=()=>[B,`none`,`subgrid`,W,H],ne=()=>[`auto`,{span:[`full`,B,W,H]},B,W,H],T=()=>[B,`auto`,W,H],re=()=>[`auto`,`min`,`max`,`fr`,W,H],ie=()=>[`start`,`end`,`center`,`between`,`around`,`evenly`,`stretch`,`baseline`,`center-safe`,`end-safe`],E=()=>[`start`,`end`,`center`,`stretch`,`center-safe`,`end-safe`],D=()=>[`auto`,...C()],O=()=>[R,`auto`,`full`,`dvw`,`dvh`,`lvw`,`lvh`,`svw`,`svh`,`min`,`max`,`fit`,...C()],ae=()=>[s,R,`screen`,`full`,`dvw`,`lvw`,`svw`,`min`,`max`,`fit`,...C()],oe=()=>[R,`screen`,`full`,`lh`,`dvh`,`lvh`,`svh`,`min`,`max`,`fit`,...C()],k=()=>[e,W,H],se=()=>[...b(),Be,Ie,{position:[W,H]}],ce=()=>[`no-repeat`,{repeat:[``,`x`,`y`,`space`,`round`]}],A=()=>[`auto`,`cover`,`contain`,Ve,Me,{size:[W,H]}],j=()=>[we,G,U],M=()=>[``,`none`,`full`,l,W,H],N=()=>[``,z,G,U],P=()=>[`solid`,`dashed`,`dotted`,`double`],le=()=>[`normal`,`multiply`,`screen`,`overlay`,`darken`,`lighten`,`color-dodge`,`color-burn`,`hard-light`,`soft-light`,`difference`,`exclusion`,`hue`,`saturation`,`color`,`luminosity`],F=()=>[z,we,Be,Ie],ue=()=>[``,`none`,m,W,H],de=()=>[`none`,z,W,H],fe=()=>[`none`,z,W,H],pe=()=>[z,W,H],I=()=>[R,`full`,...C()];return{cacheSize:500,theme:{animate:[`spin`,`ping`,`pulse`,`bounce`],aspect:[`video`],blur:[V],breakpoint:[V],color:[Te],container:[V],"drop-shadow":[V],ease:[`in`,`out`,`in-out`],font:[Ae],"font-weight":[`thin`,`extralight`,`light`,`normal`,`medium`,`semibold`,`bold`,`extrabold`,`black`],"inset-shadow":[V],leading:[`none`,`tight`,`snug`,`normal`,`relaxed`,`loose`],perspective:[`dramatic`,`near`,`normal`,`midrange`,`distant`,`none`],radius:[V],shadow:[V],spacing:[`px`,z],text:[V],"text-shadow":[V],tracking:[`tighter`,`tight`,`normal`,`wide`,`wider`,`widest`]},classGroups:{aspect:[{aspect:[`auto`,`square`,R,H,W,g]}],container:[`container`],"container-type":[{"@container":[``,`normal`,`size`,W,H]}],"container-named":[je],columns:[{columns:[z,`auto`,H,W,s]}],"break-after":[{"break-after":y()}],"break-before":[{"break-before":y()}],"break-inside":[{"break-inside":[`auto`,`avoid`,`avoid-page`,`avoid-column`]}],"box-decoration":[{"box-decoration":[`slice`,`clone`]}],box:[{box:[`border`,`content`]}],display:[`block`,`inline-block`,`inline`,`flex`,`inline-flex`,`table`,`inline-table`,`table-caption`,`table-cell`,`table-column`,`table-column-group`,`table-footer-group`,`table-header-group`,`table-row-group`,`table-row`,`flow-root`,`grid`,`inline-grid`,`contents`,`list-item`,`hidden`],sr:[`sr-only`,`not-sr-only`],float:[{float:[`right`,`left`,`none`,`start`,`end`]}],clear:[{clear:[`left`,`right`,`both`,`none`,`start`,`end`]}],isolation:[`isolate`,`isolation-auto`],"object-fit":[{object:[`contain`,`cover`,`fill`,`none`,`scale-down`]}],"object-position":[{object:ee()}],overflow:[{overflow:x()}],"overflow-x":[{"overflow-x":x()}],"overflow-y":[{"overflow-y":x()}],overscroll:[{overscroll:S()}],"overscroll-x":[{"overscroll-x":S()}],"overscroll-y":[{"overscroll-y":S()}],position:[`static`,`fixed`,`absolute`,`relative`,`sticky`],inset:[{inset:w()}],"inset-x":[{"inset-x":w()}],"inset-y":[{"inset-y":w()}],start:[{"inset-s":w(),start:w()}],end:[{"inset-e":w(),end:w()}],"inset-bs":[{"inset-bs":w()}],"inset-be":[{"inset-be":w()}],top:[{top:w()}],right:[{right:w()}],bottom:[{bottom:w()}],left:[{left:w()}],visibility:[`visible`,`invisible`,`collapse`],z:[{z:[B,`auto`,W,H]}],basis:[{basis:[R,`full`,`auto`,s,...C()]}],"flex-direction":[{flex:[`row`,`row-reverse`,`col`,`col-reverse`]}],"flex-wrap":[{flex:[`nowrap`,`wrap`,`wrap-reverse`]}],flex:[{flex:[z,R,`auto`,`initial`,`none`,H]}],grow:[{grow:[``,z,W,H]}],shrink:[{shrink:[``,z,W,H]}],order:[{order:[B,`first`,`last`,`none`,W,H]}],"grid-cols":[{"grid-cols":te()}],"col-start-end":[{col:ne()}],"col-start":[{"col-start":T()}],"col-end":[{"col-end":T()}],"grid-rows":[{"grid-rows":te()}],"row-start-end":[{row:ne()}],"row-start":[{"row-start":T()}],"row-end":[{"row-end":T()}],"grid-flow":[{"grid-flow":[`row`,`col`,`dense`,`row-dense`,`col-dense`]}],"auto-cols":[{"auto-cols":re()}],"auto-rows":[{"auto-rows":re()}],gap:[{gap:C()}],"gap-x":[{"gap-x":C()}],"gap-y":[{"gap-y":C()}],"justify-content":[{justify:[...ie(),`normal`]}],"justify-items":[{"justify-items":[...E(),`normal`]}],"justify-self":[{"justify-self":[`auto`,...E()]}],"align-content":[{content:[`normal`,...ie()]}],"align-items":[{items:[...E(),{baseline:[``,`last`]}]}],"align-self":[{self:[`auto`,...E(),{baseline:[``,`last`]}]}],"place-content":[{"place-content":ie()}],"place-items":[{"place-items":[...E(),`baseline`]}],"place-self":[{"place-self":[`auto`,...E()]}],p:[{p:C()}],px:[{px:C()}],py:[{py:C()}],ps:[{ps:C()}],pe:[{pe:C()}],pbs:[{pbs:C()}],pbe:[{pbe:C()}],pt:[{pt:C()}],pr:[{pr:C()}],pb:[{pb:C()}],pl:[{pl:C()}],m:[{m:D()}],mx:[{mx:D()}],my:[{my:D()}],ms:[{ms:D()}],me:[{me:D()}],mbs:[{mbs:D()}],mbe:[{mbe:D()}],mt:[{mt:D()}],mr:[{mr:D()}],mb:[{mb:D()}],ml:[{ml:D()}],"space-x":[{"space-x":C()}],"space-x-reverse":[`space-x-reverse`],"space-y":[{"space-y":C()}],"space-y-reverse":[`space-y-reverse`],size:[{size:O()}],"inline-size":[{inline:[`auto`,...ae()]}],"min-inline-size":[{"min-inline":[`auto`,...ae()]}],"max-inline-size":[{"max-inline":[`none`,...ae()]}],"block-size":[{block:[`auto`,...oe()]}],"min-block-size":[{"min-block":[`auto`,...oe()]}],"max-block-size":[{"max-block":[`none`,...oe()]}],w:[{w:[s,`screen`,...O()]}],"min-w":[{"min-w":[s,`screen`,`none`,...O()]}],"max-w":[{"max-w":[s,`screen`,`none`,`prose`,{screen:[o]},...O()]}],h:[{h:[`screen`,`lh`,...O()]}],"min-h":[{"min-h":[`screen`,`lh`,`none`,...O()]}],"max-h":[{"max-h":[`screen`,`lh`,`none`,...O()]}],"font-size":[{text:[`base`,n,G,U]}],"font-smoothing":[`antialiased`,`subpixel-antialiased`],"font-style":[`italic`,`not-italic`],"font-weight":[{font:[r,We,Pe]}],"font-stretch":[{"font-stretch":[`ultra-condensed`,`extra-condensed`,`condensed`,`semi-condensed`,`normal`,`semi-expanded`,`expanded`,`extra-expanded`,`ultra-expanded`,we,H]}],"font-family":[{font:[ze,Fe,t]}],"font-features":[{"font-features":[H]}],"fvn-normal":[`normal-nums`],"fvn-ordinal":[`ordinal`],"fvn-slashed-zero":[`slashed-zero`],"fvn-figure":[`lining-nums`,`oldstyle-nums`],"fvn-spacing":[`proportional-nums`,`tabular-nums`],"fvn-fraction":[`diagonal-fractions`,`stacked-fractions`],tracking:[{tracking:[i,W,H]}],"line-clamp":[{"line-clamp":[z,`none`,W,Ne]}],leading:[{leading:[`none`,a,...C()]}],"list-image":[{"list-image":[`none`,W,H]}],"list-style-position":[{list:[`inside`,`outside`]}],"list-style-type":[{list:[`disc`,`decimal`,`none`,W,H]}],"text-alignment":[{text:[`left`,`center`,`right`,`justify`,`start`,`end`]}],"placeholder-color":[{placeholder:k()}],"text-color":[{text:k()}],"text-decoration":[`underline`,`overline`,`line-through`,`no-underline`],"text-decoration-style":[{decoration:[...P(),`wavy`]}],"text-decoration-thickness":[{decoration:[z,`from-font`,`auto`,W,U]}],"text-decoration-color":[{decoration:k()}],"underline-offset":[{"underline-offset":[z,`auto`,W,H]}],"text-transform":[`uppercase`,`lowercase`,`capitalize`,`normal-case`],"text-overflow":[`truncate`,`text-ellipsis`,`text-clip`],"text-wrap":[{text:[`wrap`,`nowrap`,`balance`,`pretty`]}],indent:[{indent:C()}],"tab-size":[{tab:[B,W,H]}],"vertical-align":[{align:[`baseline`,`top`,`middle`,`bottom`,`text-top`,`text-bottom`,`sub`,`super`,W,H]}],whitespace:[{whitespace:[`normal`,`nowrap`,`pre`,`pre-line`,`pre-wrap`,`break-spaces`]}],break:[{break:[`normal`,`words`,`all`,`keep`]}],wrap:[{wrap:[`break-word`,`anywhere`,`normal`]}],hyphens:[{hyphens:[`none`,`manual`,`auto`]}],content:[{content:[`none`,W,H]}],"bg-attachment":[{bg:[`fixed`,`local`,`scroll`]}],"bg-clip":[{"bg-clip":[`border`,`padding`,`content`,`text`]}],"bg-origin":[{"bg-origin":[`border`,`padding`,`content`]}],"bg-position":[{bg:se()}],"bg-repeat":[{bg:ce()}],"bg-size":[{bg:A()}],"bg-image":[{bg:[`none`,{linear:[{to:[`t`,`tr`,`r`,`br`,`b`,`bl`,`l`,`tl`]},B,W,H],radial:[``,W,H],conic:[``,B,W,H]},He,Le]}],"bg-color":[{bg:k()}],"gradient-from-pos":[{from:j()}],"gradient-via-pos":[{via:j()}],"gradient-to-pos":[{to:j()}],"gradient-from":[{from:k()}],"gradient-via":[{via:k()}],"gradient-to":[{to:k()}],rounded:[{rounded:M()}],"rounded-s":[{"rounded-s":M()}],"rounded-e":[{"rounded-e":M()}],"rounded-t":[{"rounded-t":M()}],"rounded-r":[{"rounded-r":M()}],"rounded-b":[{"rounded-b":M()}],"rounded-l":[{"rounded-l":M()}],"rounded-ss":[{"rounded-ss":M()}],"rounded-se":[{"rounded-se":M()}],"rounded-ee":[{"rounded-ee":M()}],"rounded-es":[{"rounded-es":M()}],"rounded-tl":[{"rounded-tl":M()}],"rounded-tr":[{"rounded-tr":M()}],"rounded-br":[{"rounded-br":M()}],"rounded-bl":[{"rounded-bl":M()}],"border-w":[{border:N()}],"border-w-x":[{"border-x":N()}],"border-w-y":[{"border-y":N()}],"border-w-s":[{"border-s":N()}],"border-w-e":[{"border-e":N()}],"border-w-bs":[{"border-bs":N()}],"border-w-be":[{"border-be":N()}],"border-w-t":[{"border-t":N()}],"border-w-r":[{"border-r":N()}],"border-w-b":[{"border-b":N()}],"border-w-l":[{"border-l":N()}],"divide-x":[{"divide-x":N()}],"divide-x-reverse":[`divide-x-reverse`],"divide-y":[{"divide-y":N()}],"divide-y-reverse":[`divide-y-reverse`],"border-style":[{border:[...P(),`hidden`,`none`]}],"divide-style":[{divide:[...P(),`hidden`,`none`]}],"border-color":[{border:k()}],"border-color-x":[{"border-x":k()}],"border-color-y":[{"border-y":k()}],"border-color-s":[{"border-s":k()}],"border-color-e":[{"border-e":k()}],"border-color-bs":[{"border-bs":k()}],"border-color-be":[{"border-be":k()}],"border-color-t":[{"border-t":k()}],"border-color-r":[{"border-r":k()}],"border-color-b":[{"border-b":k()}],"border-color-l":[{"border-l":k()}],"divide-color":[{divide:k()}],"outline-style":[{outline:[...P(),`none`,`hidden`]}],"outline-offset":[{"outline-offset":[z,W,H]}],"outline-w":[{outline:[``,z,G,U]}],"outline-color":[{outline:k()}],shadow:[{shadow:[``,`inner`,`none`,u,Ue,Re]}],"shadow-color":[{shadow:k()}],"inset-shadow":[{"inset-shadow":[`none`,d,Ue,Re]}],"inset-shadow-color":[{"inset-shadow":k()}],"ring-w":[{ring:N()}],"ring-w-inset":[`ring-inset`],"ring-color":[{ring:k()}],"ring-offset-w":[{"ring-offset":[z,U]}],"ring-offset-color":[{"ring-offset":k()}],"inset-ring-w":[{"inset-ring":N()}],"inset-ring-color":[{"inset-ring":k()}],"text-shadow":[{"text-shadow":[`none`,f,Ue,Re]}],"text-shadow-color":[{"text-shadow":k()}],opacity:[{opacity:[z,W,H]}],"mix-blend":[{"mix-blend":[...le(),`plus-darker`,`plus-lighter`]}],"bg-blend":[{"bg-blend":le()}],"mask-clip":[{"mask-clip":[`border`,`padding`,`content`,`fill`,`stroke`,`view`]},`mask-no-clip`],"mask-composite":[{mask:[`add`,`subtract`,`intersect`,`exclude`]}],"mask-image-linear-pos":[{"mask-linear":[z]}],"mask-image-linear-from-pos":[{"mask-linear-from":F()}],"mask-image-linear-to-pos":[{"mask-linear-to":F()}],"mask-image-linear-from-color":[{"mask-linear-from":k()}],"mask-image-linear-to-color":[{"mask-linear-to":k()}],"mask-image-t-from-pos":[{"mask-t-from":F()}],"mask-image-t-to-pos":[{"mask-t-to":F()}],"mask-image-t-from-color":[{"mask-t-from":k()}],"mask-image-t-to-color":[{"mask-t-to":k()}],"mask-image-r-from-pos":[{"mask-r-from":F()}],"mask-image-r-to-pos":[{"mask-r-to":F()}],"mask-image-r-from-color":[{"mask-r-from":k()}],"mask-image-r-to-color":[{"mask-r-to":k()}],"mask-image-b-from-pos":[{"mask-b-from":F()}],"mask-image-b-to-pos":[{"mask-b-to":F()}],"mask-image-b-from-color":[{"mask-b-from":k()}],"mask-image-b-to-color":[{"mask-b-to":k()}],"mask-image-l-from-pos":[{"mask-l-from":F()}],"mask-image-l-to-pos":[{"mask-l-to":F()}],"mask-image-l-from-color":[{"mask-l-from":k()}],"mask-image-l-to-color":[{"mask-l-to":k()}],"mask-image-x-from-pos":[{"mask-x-from":F()}],"mask-image-x-to-pos":[{"mask-x-to":F()}],"mask-image-x-from-color":[{"mask-x-from":k()}],"mask-image-x-to-color":[{"mask-x-to":k()}],"mask-image-y-from-pos":[{"mask-y-from":F()}],"mask-image-y-to-pos":[{"mask-y-to":F()}],"mask-image-y-from-color":[{"mask-y-from":k()}],"mask-image-y-to-color":[{"mask-y-to":k()}],"mask-image-radial":[{"mask-radial":[W,H]}],"mask-image-radial-from-pos":[{"mask-radial-from":F()}],"mask-image-radial-to-pos":[{"mask-radial-to":F()}],"mask-image-radial-from-color":[{"mask-radial-from":k()}],"mask-image-radial-to-color":[{"mask-radial-to":k()}],"mask-image-radial-shape":[{"mask-radial":[`circle`,`ellipse`]}],"mask-image-radial-size":[{"mask-radial":[{closest:[`side`,`corner`],farthest:[`side`,`corner`]}]}],"mask-image-radial-pos":[{"mask-radial-at":b()}],"mask-image-conic-pos":[{"mask-conic":[z]}],"mask-image-conic-from-pos":[{"mask-conic-from":F()}],"mask-image-conic-to-pos":[{"mask-conic-to":F()}],"mask-image-conic-from-color":[{"mask-conic-from":k()}],"mask-image-conic-to-color":[{"mask-conic-to":k()}],"mask-mode":[{mask:[`alpha`,`luminance`,`match`]}],"mask-origin":[{"mask-origin":[`border`,`padding`,`content`,`fill`,`stroke`,`view`]}],"mask-position":[{mask:se()}],"mask-repeat":[{mask:ce()}],"mask-size":[{mask:A()}],"mask-type":[{"mask-type":[`alpha`,`luminance`]}],"mask-image":[{mask:[`none`,W,H]}],filter:[{filter:[``,`none`,W,H]}],blur:[{blur:ue()}],brightness:[{brightness:[z,W,H]}],contrast:[{contrast:[z,W,H]}],"drop-shadow":[{"drop-shadow":[``,`none`,p,Ue,Re]}],"drop-shadow-color":[{"drop-shadow":k()}],grayscale:[{grayscale:[``,z,W,H]}],"hue-rotate":[{"hue-rotate":[z,W,H]}],invert:[{invert:[``,z,W,H]}],saturate:[{saturate:[z,W,H]}],sepia:[{sepia:[``,z,W,H]}],"backdrop-filter":[{"backdrop-filter":[``,`none`,W,H]}],"backdrop-blur":[{"backdrop-blur":ue()}],"backdrop-brightness":[{"backdrop-brightness":[z,W,H]}],"backdrop-contrast":[{"backdrop-contrast":[z,W,H]}],"backdrop-grayscale":[{"backdrop-grayscale":[``,z,W,H]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[z,W,H]}],"backdrop-invert":[{"backdrop-invert":[``,z,W,H]}],"backdrop-opacity":[{"backdrop-opacity":[z,W,H]}],"backdrop-saturate":[{"backdrop-saturate":[z,W,H]}],"backdrop-sepia":[{"backdrop-sepia":[``,z,W,H]}],"border-collapse":[{border:[`collapse`,`separate`]}],"border-spacing":[{"border-spacing":C()}],"border-spacing-x":[{"border-spacing-x":C()}],"border-spacing-y":[{"border-spacing-y":C()}],"table-layout":[{table:[`auto`,`fixed`]}],caption:[{caption:[`top`,`bottom`]}],transition:[{transition:[``,`all`,`colors`,`opacity`,`shadow`,`transform`,`none`,W,H]}],"transition-behavior":[{transition:[`normal`,`discrete`]}],duration:[{duration:[z,`initial`,W,H]}],ease:[{ease:[`linear`,`initial`,_,W,H]}],delay:[{delay:[z,W,H]}],animate:[{animate:[`none`,v,W,H]}],backface:[{backface:[`hidden`,`visible`]}],perspective:[{perspective:[h,W,H]}],"perspective-origin":[{"perspective-origin":ee()}],rotate:[{rotate:de()}],"rotate-x":[{"rotate-x":de()}],"rotate-y":[{"rotate-y":de()}],"rotate-z":[{"rotate-z":de()}],scale:[{scale:fe()}],"scale-x":[{"scale-x":fe()}],"scale-y":[{"scale-y":fe()}],"scale-z":[{"scale-z":fe()}],"scale-3d":[`scale-3d`],skew:[{skew:pe()}],"skew-x":[{"skew-x":pe()}],"skew-y":[{"skew-y":pe()}],transform:[{transform:[W,H,``,`none`,`gpu`,`cpu`]}],"transform-origin":[{origin:ee()}],"transform-style":[{transform:[`3d`,`flat`]}],translate:[{translate:I()}],"translate-x":[{"translate-x":I()}],"translate-y":[{"translate-y":I()}],"translate-z":[{"translate-z":I()}],"translate-none":[`translate-none`],zoom:[{zoom:[B,W,H]}],accent:[{accent:k()}],appearance:[{appearance:[`none`,`auto`]}],"caret-color":[{caret:k()}],"color-scheme":[{scheme:[`normal`,`dark`,`light`,`light-dark`,`only-dark`,`only-light`]}],cursor:[{cursor:[`auto`,`default`,`pointer`,`wait`,`text`,`move`,`help`,`not-allowed`,`none`,`context-menu`,`progress`,`cell`,`crosshair`,`vertical-text`,`alias`,`copy`,`no-drop`,`grab`,`grabbing`,`all-scroll`,`col-resize`,`row-resize`,`n-resize`,`e-resize`,`s-resize`,`w-resize`,`ne-resize`,`nw-resize`,`se-resize`,`sw-resize`,`ew-resize`,`ns-resize`,`nesw-resize`,`nwse-resize`,`zoom-in`,`zoom-out`,W,H]}],"field-sizing":[{"field-sizing":[`fixed`,`content`]}],"pointer-events":[{"pointer-events":[`auto`,`none`]}],resize:[{resize:[`none`,``,`y`,`x`]}],"scroll-behavior":[{scroll:[`auto`,`smooth`]}],"scrollbar-thumb-color":[{"scrollbar-thumb":k()}],"scrollbar-track-color":[{"scrollbar-track":k()}],"scrollbar-gutter":[{"scrollbar-gutter":[`auto`,`stable`,`both`]}],"scrollbar-w":[{scrollbar:[`auto`,`thin`,`none`]}],"scroll-m":[{"scroll-m":C()}],"scroll-mx":[{"scroll-mx":C()}],"scroll-my":[{"scroll-my":C()}],"scroll-ms":[{"scroll-ms":C()}],"scroll-me":[{"scroll-me":C()}],"scroll-mbs":[{"scroll-mbs":C()}],"scroll-mbe":[{"scroll-mbe":C()}],"scroll-mt":[{"scroll-mt":C()}],"scroll-mr":[{"scroll-mr":C()}],"scroll-mb":[{"scroll-mb":C()}],"scroll-ml":[{"scroll-ml":C()}],"scroll-p":[{"scroll-p":C()}],"scroll-px":[{"scroll-px":C()}],"scroll-py":[{"scroll-py":C()}],"scroll-ps":[{"scroll-ps":C()}],"scroll-pe":[{"scroll-pe":C()}],"scroll-pbs":[{"scroll-pbs":C()}],"scroll-pbe":[{"scroll-pbe":C()}],"scroll-pt":[{"scroll-pt":C()}],"scroll-pr":[{"scroll-pr":C()}],"scroll-pb":[{"scroll-pb":C()}],"scroll-pl":[{"scroll-pl":C()}],"snap-align":[{snap:[`start`,`end`,`center`,`align-none`]}],"snap-stop":[{snap:[`normal`,`always`]}],"snap-type":[{snap:[`none`,`x`,`y`,`both`]}],"snap-strictness":[{snap:[`mandatory`,`proximity`]}],touch:[{touch:[`auto`,`none`,`manipulation`]}],"touch-x":[{"touch-pan":[`x`,`left`,`right`]}],"touch-y":[{"touch-pan":[`y`,`up`,`down`]}],"touch-pz":[`touch-pinch-zoom`],select:[{select:[`none`,`text`,`all`,`auto`]}],"will-change":[{"will-change":[`auto`,`scroll`,`contents`,`transform`,W,H]}],fill:[{fill:[`none`,...k()]}],"stroke-w":[{stroke:[z,G,U,Ne]}],stroke:[{stroke:[`none`,...k()]}],"forced-color-adjust":[{"forced-color-adjust":[`auto`,`none`]}]},conflictingClassGroups:{"container-named":[`container-type`],overflow:[`overflow-x`,`overflow-y`],overscroll:[`overscroll-x`,`overscroll-y`],inset:[`inset-x`,`inset-y`,`inset-bs`,`inset-be`,`start`,`end`,`top`,`right`,`bottom`,`left`],"inset-x":[`start`,`end`,`right`,`left`],"inset-y":[`inset-bs`,`inset-be`,`top`,`bottom`],flex:[`basis`,`grow`,`shrink`],gap:[`gap-x`,`gap-y`],p:[`px`,`py`,`ps`,`pe`,`pbs`,`pbe`,`pt`,`pr`,`pb`,`pl`],px:[`ps`,`pe`,`pr`,`pl`],py:[`pbs`,`pbe`,`pt`,`pb`],m:[`mx`,`my`,`ms`,`me`,`mbs`,`mbe`,`mt`,`mr`,`mb`,`ml`],mx:[`ms`,`me`,`mr`,`ml`],my:[`mbs`,`mbe`,`mt`,`mb`],size:[`w`,`h`],"font-size":[`leading`],"fvn-normal":[`fvn-ordinal`,`fvn-slashed-zero`,`fvn-figure`,`fvn-spacing`,`fvn-fraction`],"fvn-ordinal":[`fvn-normal`],"fvn-slashed-zero":[`fvn-normal`],"fvn-figure":[`fvn-normal`],"fvn-spacing":[`fvn-normal`],"fvn-fraction":[`fvn-normal`],"line-clamp":[`display`,`overflow`],rounded:[`rounded-s`,`rounded-e`,`rounded-t`,`rounded-r`,`rounded-b`,`rounded-l`,`rounded-ss`,`rounded-se`,`rounded-ee`,`rounded-es`,`rounded-tl`,`rounded-tr`,`rounded-br`,`rounded-bl`],"rounded-s":[`rounded-ss`,`rounded-es`],"rounded-e":[`rounded-se`,`rounded-ee`],"rounded-t":[`rounded-tl`,`rounded-tr`],"rounded-r":[`rounded-tr`,`rounded-br`],"rounded-b":[`rounded-br`,`rounded-bl`],"rounded-l":[`rounded-tl`,`rounded-bl`],"border-spacing":[`border-spacing-x`,`border-spacing-y`],"border-w":[`border-w-x`,`border-w-y`,`border-w-s`,`border-w-e`,`border-w-bs`,`border-w-be`,`border-w-t`,`border-w-r`,`border-w-b`,`border-w-l`],"border-w-x":[`border-w-s`,`border-w-e`,`border-w-r`,`border-w-l`],"border-w-y":[`border-w-bs`,`border-w-be`,`border-w-t`,`border-w-b`],"border-color":[`border-color-x`,`border-color-y`,`border-color-s`,`border-color-e`,`border-color-bs`,`border-color-be`,`border-color-t`,`border-color-r`,`border-color-b`,`border-color-l`],"border-color-x":[`border-color-s`,`border-color-e`,`border-color-r`,`border-color-l`],"border-color-y":[`border-color-bs`,`border-color-be`,`border-color-t`,`border-color-b`],translate:[`translate-x`,`translate-y`,`translate-none`],"translate-none":[`translate`,`translate-x`,`translate-y`,`translate-z`],"scroll-m":[`scroll-mx`,`scroll-my`,`scroll-ms`,`scroll-me`,`scroll-mbs`,`scroll-mbe`,`scroll-mt`,`scroll-mr`,`scroll-mb`,`scroll-ml`],"scroll-mx":[`scroll-ms`,`scroll-me`,`scroll-mr`,`scroll-ml`],"scroll-my":[`scroll-mbs`,`scroll-mbe`,`scroll-mt`,`scroll-mb`],"scroll-p":[`scroll-px`,`scroll-py`,`scroll-ps`,`scroll-pe`,`scroll-pbs`,`scroll-pbe`,`scroll-pt`,`scroll-pr`,`scroll-pb`,`scroll-pl`],"scroll-px":[`scroll-ps`,`scroll-pe`,`scroll-pr`,`scroll-pl`],"scroll-py":[`scroll-pbs`,`scroll-pbe`,`scroll-pt`,`scroll-pb`],touch:[`touch-x`,`touch-y`,`touch-pz`],"touch-x":[`touch`],"touch-y":[`touch`],"touch-pz":[`touch`]},conflictingClassGroupModifiers:{"font-size":[`leading`]},postfixLookupClassGroups:[`container-type`],orderSensitiveModifiers:[`*`,`**`,`after`,`backdrop`,`before`,`details-content`,`file`,`first-letter`,`first-line`,`marker`,`placeholder`,`selection`]}});function J(...e){return $e(g(e))}function et(e){let t=e.trim().split(/\s+/).filter(Boolean).length;return Math.max(1,Math.round(t/180))}var Y=t(),tt=y(`inline-flex items-center justify-center gap-2 font-display font-medium tracking-tight transition-[opacity,transform,background-color,box-shadow,color] duration-150 ease-out select-none active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sage`,{variants:{variant:{primary:`bg-cream text-ink hover:opacity-90`,sage:`bg-sage text-ink hover:bg-sage-dim`,ghost:`bg-transparent text-cream/90 hover:bg-cream/8`,outline:`bg-transparent text-cream shadow-border hover:shadow-border-hover`,danger:`bg-danger text-cream hover:opacity-90`,paper:`bg-ink text-paper hover:opacity-90`,quiet:`bg-transparent text-ink/70 hover:bg-ink/6`},size:{default:`h-11 px-5 rounded-lg text-sm`,lg:`h-12 px-6 rounded-xl text-base`,sm:`h-9 px-3.5 rounded-md text-sm`,icon:`size-11 rounded-lg`,"icon-sm":`size-9 rounded-md`}},defaultVariants:{variant:`primary`,size:`default`}}),X=m.forwardRef(({className:e,variant:t,size:n,type:r=`button`,...i},a)=>(0,Y.jsx)(`button`,{ref:a,type:r,className:J(tt({variant:t,size:n}),e),...i}));X.displayName=`Button`;var nt={forest:`bg-cover-forest text-cream`,slate:`bg-cover-slate text-cream`,olive:`bg-cover-olive text-cream`,umber:`bg-cover-umber text-cream`,stone:`bg-cover-stone text-cream`,charcoal:`bg-cover-charcoal text-cream`,custom:`bg-ink-3 text-cream`},rt=[{id:`pushkin-rybaka`,title:`Сказка о рыбаке и рыбке`,author:`А. С. Пушкин`,years:`1833`,kind:`verse`,cover:`forest`,blurb:`Старик, невод и золотая рыбка — история о жадности, которая возвращает всё на круги своя.`,text:`Жил старик со своею старухой
У самого синего моря;
Они жили в ветхой землянке
Ровно тридцать лет и три года.
Старик ловил неводом рыбу,
Старуха пряла свою пряжу.
Раз он в море закинул невод, —
Пришёл невод с одною тиной.
Он в другой раз закинул невод,
Пришёл невод с травой морскою.
В третий раз закинул он невод, —
Пришла рыбка, не простая, золотая.

«Отпусти ты, старче, меня в море,
Дорогой за себя дам откуп:
Откуплюсь чем только пожелаешь».
Отпустил он рыбку золотую
И сказал ей ласковое слово:
«Бог с тобою, золотая рыбка!
Твоего мне откупа не надо;
Ступай себе в синее море,
Гуляй там себе на просторе».

Воротился старик ко старухе,
Рассказал ей великое чудо:
«Я сегодня поймал было рыбку,
Золотую рыбку, не простую;
По-нашему говорила рыбка,
Домой в море синее просилась,
Дорогою ценою откупалась:
Откупалась чем только пожелаю.
Не посмел я взять с неё выкуп;
Так пустил её в синее море».
Старика старуха забранила:
«Дурачина ты, простофиля!
Не умел ты взять выкупа с рыбки!
Хоть бы взял ты с неё корыто,
Наше-то совсем раскололось».

Вот пошёл он к синему морю;
Видит: море слегка разыгралось.
Стал он кликать золотую рыбку.
Приплыла к нему рыбка и спросила:
«Чего тебе надобно, старче?»
Ей с поклоном старик отвечает:
«Смилуйся, государыня рыбка,
Разбранила меня моя старуха,
Не даёт старику мне покою:
Надобно ей новое корыто;
Наше-то совсем раскололось».
Отвечает золотая рыбка:
«Не печалься, ступай себе с богом,
Будет вам новое корыто».

Пошёл старик ко старухе,
У старухи новое корыто.
Ещё пуще старуха бранится:
«Дурачина ты, простофиля!
Выпросил, дурачина, корыто!
В корыте много ли корысти?
Воротись, дурачина, ты к рыбке;
Поклонись ей, выпроси уж избу».

Пошёл старик к синему морю
(Помутилося синее море).
Стал он кликать золотую рыбку.
Приплыла к нему рыбка, спросила:
«Чего тебе надобно, старче?»
Ей с поклоном старик отвечает:
«Смилуйся, государыня рыбка!
Ещё пуще старуха бранится,
Не даёт старику мне покою:
Избу просит сварливая баба».
Отвечает золотая рыбка:
«Не печалься, ступай себе с богом,
Так и быть: изба вам будет».

Пошёл он ко своей землянке,
А землянки нет уж и следа;
Перед ним изба со светёлкой,
С кирпичною, беленою трубою.
Старуха сидит под окошком,
На чём свет стоит мужа ругает:
«Дурачина ты, прямой простофиля!
Выпросил, простофиля, избу!
Воротись, поклонися рыбке:
Не хочу быть чёрной крестьянкой,
Хочу быть столбовою дворянкой».

Стал старик кликать рыбку.
Приплыла к нему рыбка, спросила:
«Чего тебе надобно, старче?»
Ей с поклоном старик отвечает:
«Смилуйся, государыня рыбка!
Пуще прежнего старуха вздурилась:
Не хочет быть она крестьянкой,
Хочет быть столбовою дворянкой».
Отвечает золотая рыбка:
«Не печалься, ступай себе с богом».

Воротился старик ко старухе.
Что ж он видит? Высокий терем.
На крыльце стоит его старуха
В дорогой собольей душегрейке,
Парчовая на маковке кичка,
Жемчуги огрузили шею,
На руках золотые перстни,
На ногах красные сапожки.
Перед нею усердные слуги;
Она бьёт их, за чуб таскает.
Говорит старик своей старухе:
«Здравствуй, барыня сударыня дворянка!
Чай, теперь твоя душенька довольна».
На него старуха разъярилась,
По щеке ударила мужа.
«Как ты смел, мужик, спорить со мною,
Со столбовою дворянкой?
Ступай к службе, ступай вон».

На другой день вздурилась опять:
«Воротись, поклонися рыбке.
Не хочу быть столбовою дворянкой,
А хочу быть вольною царицей».
Испугался старик, взмолился:
«Что ты, баба, белены объелась?
Ни ступить, ни молвить не умеешь.
Насмешишь ты целое царство».
Старуха пуще бесится,
По щеке ударила мужа:
«Как ты смеешь, мужик, спорить со мною,
Со столбовою дворянкой?
Ступай к службе, ступай вон».

Пошёл старик к синему морю
(Не спокойно синее море).
Стал он кликать золотую рыбку.
Приплыла к нему рыбка, спросила:
«Чего тебе надобно, старче?»
Ей старик поклоняется:
«Смилуйся, государыня рыбка!
Опять моя старуха бунтует:
Не хочет быть она дворянкой,
Хочет быть вольною царицей».
Отвечает золотая рыбка:
«Не печалься, ступай себе с богом!
Добро, будет старуха царицей».

Воротился старик ко старухе.
Что ж? Пред ним царские палаты.
В палатах видит свою старуху,
За столом сидит она царицей,
Служат ей князья да бояре,
Наливают ей заморские вина;
Пряник печатный перед нею;
Вокруг её стоит грозная стража.
Увидав старика, пуще злится,
Царица его спровадила прочь.

Не прошло и двух недель,
Вздурилась опять старуха:
«Не хочу быть вольною царицей,
Хочу быть владычицей морскою,
Чтобы жить мне в Окияне-море,
Чтоб служила мне рыбка золотая
И была у меня на посылках».
Старик не посмел перечить,
Не дерзнул поперек слова молвить.

Вот идёт он к синему морю,
Видит: на море чёрная буря;
Так и вздулись сердитые волны,
Так и ходят, так воют и воют.
Стал он кликать золотую рыбку.
Приплыла к нему рыбка, спросила:
«Чего тебе надобно, старче?»
Ей старик кланяется:
«Смилуйся, государыня рыбка!
Что мне делать с проклятою бабой?
Не хочет быть она царицей,
Хочет быть владычицей морскою;
Чтобы жить ей в Окияне-море,
Чтоб служила ты ей и была у неё на посылках».
Ничего не сказала рыбка,
Лишь хвостом по воде плеснула
И ушла в глубокое море.

Долго у моря ждал он ответа,
Не дождался, к старухе воротился —
Глядь: опять перед ним землянка;
На пороге сидит его старуха,
А пред нею разбитое корыто.`},{id:`chekhov-tolsty`,title:`Толстый и тонкий`,author:`А. П. Чехов`,years:`1883`,kind:`prose`,cover:`slate`,blurb:`Вокзальная встреча двух гимназических друзей — и то, что делает с людьми чин.`,text:`На вокзале Николаевской железной дороги встретились два приятеля: один толстый, другой тонкий. Толстый только что пообедал на вокзале, и губы его, подёрнутые маслом, лоснились, как спелые вишни. Пахло от него хересом и флёр-д’оранжем. Тонкий же только что вышел из вагона и был навьючен чемоданами, узлами и картонками. Пахло от него ветчиной и кофейной гущей. Из-за него выглядывала худенькая женщина с длинным подбородком — его жена, и высокий гимназист с прищуренным глазом — его сын.

— Порфирий! — воскликнул толстый, увидев тонкого. — Ты ли это? Голубчик мой! Сколько зим, сколько лет!

— Батюшки! — изумился тонкий. — Миша! Друг детства! Откуда ты взялся?

Приятели троекратно облобызались и устремили друг на друга глаза, полные слёз. Оба были приятно ошеломлены.

— Милый мой! — начал тонкий после лобызания. — Вот не ожидал! Вот сюрприз! Да погляди же на меня хорошенько! Такой же красавец, как и был! Экий ты, однако, франт! Ну, ну, рассказывай, как живёшь? Что делаешь? На пенсии? А?

— Нет, милый, на службе, — ответил толстый. — Статским советником уже второй год и Станислава имею. Жалованье плохое… ну, да бог с ним! Жена преподаёт музыку, я портсигары приватно из дерева выпиливаю. Славные портсигары! По рублю за штуку продаю. А если кто берёт десять штук и более, тому, понимаешь, уступка. Пробавляемся кое-как. Служил, знаешь, в департаменте, а теперь сюда переведён столоначальником… Здесь буду служить. Ну, а ты как? Небось, уже статский? А?

— Нет, любезный, поднимай повыше, — сказал толстый. — Я уже до тайного дослужился… Две звезды имею.

Тонкий вдруг побледнел, окаменел, но скоро лицо его искривилось во все стороны широчайшей улыбкой; казалось, что с лица и с глаз его посыпались искры. Сам он съёжился, сгорбился, сузился… Его чемоданы, узлы и картонки съёжились, поморщились… Длинный подбородок жены стал ещё длиннее; Нафанаил вытянулся во фрунт и застегнул все пуговки своего мундира…

— Я, ваше превосходительство… Очень приятно-с! Друг, можно сказать, детства и вдруг вышли в такие вельможи-с! Хи-хи-с.

— Ну, полно! — поморщился толстый. — Для чего этот тон? Мы с тобой друзья детства — и к чему тут это чинопочитание!

— Помилуйте… Что вы-с… — захихикал тонкий, ещё более съёживаясь. — Милостивое внимание вашего превосходительства… вроде как бы живительной влаги…

Толстый хотел было возразить что-то, но на лице у тонкого было написано столько благоговения, сладости и почтительной кислоты, что тайного советника стошнило. Он отвернулся от тонкого и подал ему на прощание руку.

Тонкий пожал три пальца, поклонился всем туловищем и захихикал, как китаец: «хи-хи-хи». Жена улыбнулась. Нафанаил шаркнул ногой и уронил фуражку. Все трое были приятно ошеломлены.`},{id:`chekhov-hameleon`,title:`Хамелеон`,author:`А. П. Чехов`,years:`1884`,kind:`prose`,cover:`olive`,blurb:`Полицейский надзиратель Очумелов меняет цвет вместе с породой собаки — и с её хозяином.`,text:`Через базарную площадь идёт полицейский надзиратель Очумелов в новой шинели и с узелком в руке. За ним шагает рыжий городовой с решетом, наполненным доверху конфискованным крыжовником. Кругом тишина… На площади ни души… Открытые двери лавок и кабаков глядят на свет божий уныло, как голодные пасти; около них нет даже нищих.

— Так ты кусаться, проклятая? — слышит вдруг Очумелов. — Ребята, не пущай её! Нынче не велено кусаться! Держи! А… а!

Слышен визг собаки. Очумелов глядит в сторону и видит: из дровяного склада купца Пичугина, прыгая на трёх ногах и оглядываясь, бежит собака. За ней гонится человек в ситцевой крахмальной рубахе и расстёгнутой жилетке. Он бежит за ней и, подавшись туловищем вперёд, падает на землю и хватает собаку за задние ноги. Слышен вторичный визг собаки и крик: «Не пущай!» Из лавок высовываются сонные физиономии, и скоро около дровяного склада, как будто из земли выросши, собирается толпа.

— Никак беспорядок, ваше благородие!.. — говорит городовой.

Очумелов делает полуоборот налево и шагает к сборищу. Около самых ворот склада, видит он, стоит вышеописанный человек в расстёгнутой жилетке и, подняв вверх правую руку, показывает толпе окровавленный палец. На полупьяном лице его как бы написано: «Вот я тебя, шельма, обделаю!» да ещё победа написана. Человек этот и есть золотых дел мастер Хрюкин. В центре толпы, растопырив передние ноги и дрожа всем телом, сидит на земле виновник скандала — белый борзой щенок с острой мордой и с жёлтым пятном на спине. В его слезящихся глазах выражение тоски и ужаса.

— По какому это случаю тут? — спрашивает Очумелов, врезаясь в толпу. — Почему тут? Это ты зачем палец?.. Кто кричал?

— Иду я, ваше благородие, никого не трогаю… — начинает Хрюкин, кашляя в кулак. — Насчёт дров с Митрием Митричем, — и вдруг эта подлая ни с того, ни с сего за палец… Вы меня извините, я человек, который работает… Работа у меня мелкая. Пущай мне ихний благородие заплатят, потому — я, может, неделю палец не заживу… да ещё, ваше благородие, оно в законе: ежели каждый будет так…

— Гм!.. Хорошо… — говорит Очумелов строго, кашляя и шевеля бровями. — Хорошо… Чья собака? Я этого так не оставлю. Я покажу вам, как собак распускать! Пора обратить внимание на подобных господ, не желающих подчиняться постановлениям! Как только оштрафуют его, мерзавца, так он узнает у меня, что значит собака и прочий бродячий скот! Я ему покажу Кузькину мать!.. Елдырин, — обращается надзиратель к городовому, — узнай, чья это собака, и составляй протокол! А собаку истребить надо. Немедля! Она наверное бешеная… Чья это собака, спрашиваю?

— Это, кажись, генерала Жигалова! — говорит кто-то из толпы.

— Генерала Жигалова? Гм!.. Сними-ка, Елдырин, с меня пальто… Ужас как жарко! Должно полагать, перед дождём… Одного только я не понимаю: как она могла тебя укусить? — обращается Очумелов к Хрюкину. — Нешто она достанет до пальца? Она маленькая, а ты вон какой здоровила! Ты, должно быть, расковырял палец гвоздиком, а потом и пришла в твою голову идея, чтоб сорвать. Ты ведь… известный человек! Я тебя знаю!

— Он, ваше благородие, цигаркой ей в харю для смеха, а она — не будь дура и тяпни… Сущность-то Егора… Он, озорник, ваш…

— Соврал! Этого, ваше благородие, и не было… А ежели все будут свидетельствовать, то кто ж свинья? Он сам свинья, а ежели я…

— Ты не приставай! Ты вон какой здоровила, а она щенячья… Ты, должно быть, и сам…

— Нет, это не генеральская… — глубокомысленно замечает городовой. — У генерала таких нет. У него всё больше легавые…

— Ты это верно знаешь?

— Верно, ваше благородие…

— Я и сам знаю. У генерала собаки дорогие, породистые, а эта — безродная тварь, шерсть не такая… и подлая… Гм. Ты, Хрюкин, пострадал и дела не оставим… Но, брат, ежели это генеральская, то другое дело. Сними-ка, Елдырин, пальто с меня… Вот когда жара-то пошла… Должно полагать, к дождю…

— Да и больно кусается, проклятая… — говорит Хрюкин, с обидой кивая головой.

— Ты, брат, не мешай… Я разберу… Я дойду до самой сути.

В толпе раздаётся голос:

— И не генеральская это собака, а братца генеральского. Помнится, у братца белые…

— Братца генеральского? Так зачем же ты раньше молчал? — вспыхивает Очумелов. — Елдырин, помоги мне надеть пальто… Фу ты, какая ветрина… Так это ихняя? Ну, так и скажи. Надень пальто, Елдырин… Что-то ветром подуло… Знобит…

— Поди, разберись… — бормочет городовой. — Ещё намедни у них во дворе видел. Пегая. Толстая. Морда острая. Глаза злые. Прыгает, бесстыжая…

Очумелов поворачивается к Хрюкину и говорит:

— Ты вот что. Это, брат, генеральская собака. Стало быть, и разговаривать нечего. Она, щенок, может, и дорогая, а ты, Хрюкин, дурак. Небось палец тебе раздавило? Пущай! Ты сам виноват.

И, махнув рукой, Очумелов говорит городовому:

— Проваливай! Это щенок генеральский… Ты его к ним снеси. Скажи, что нашли и прислали… А ты, болван, не выставляй палец. Небось, дойдёшь до генерала и пожалуешься. Я ещё тебя, дуралея, проучу…

Толпа хохочет над Хрюкиным.

— Я ещё доберусь до тебя! — грозит ему Очумелов и, запахивая шинель, продолжает свой путь по базарной площади.`},{id:`krylov-basni`,title:`Три басни`,author:`И. А. Крылов`,years:`1808–1816`,kind:`verse`,cover:`umber`,blurb:`Ворона и Лисица, Стрекоза и Муравей, Лебедь, Щука и Рак — уроки, которые не стареют.`,text:`Ворона и Лисица

Уж сколько раз твердили миру,
Что лесть гнусна, вредна; но только всё не впрок,
И в сердце льстец всегда отыщет уголок.

Вороне где-то бог послал кусочек сыру;
На ель Ворона взгромоздясь,
Позавтракать было совсем уж собралась,
Да призадумалась, а сыр во рту держала.
На ту беду Лиса близехонько бежала;
Вдруг сырный дух Лису остановил:
Лисица видит сыр, Лисицу сыр пленил.
Плутовка к дереву на цыпочках подходит;
Вертит хвостом, с Вороны глаз не сводит
И говорит так сладко, чуть дыша:
«Голубушка, как хороша!
Ну что за шейка, что за глазки!
Рассказывать, так, право, сказки!
Какие пёрышки! какой носок!
И, верно, ангельский быть должен голосок!
Спой, светик, не стыдись! Что ежели, сестрица,
При красоте такой и петь ты мастерица, —
Ведь ты б у нас была царь-птица!»
Вещуньина с похвал вскружилась голова,
От радости в зобу дыханье спёрло, —
И на приветливы Лисицыны слова
Ворона каркнула во всё воронье горло:
Сыр выпал — с ним была плутовка такова.


Стрекоза и Муравей

Попрыгунья Стрекоза
Лето красное пропела;
Оглянуться не успела,
Как зима катит в глаза.
Помертвело чисто поле;
Нет уж дней тех светлых боле,
Как под каждым ей листком
Был готов и стол, и дом.
Всё прошло: с зимой холодной
Нужда, голод настаёт;
Стрекоза уж не поёт:
И кому же в ум пойдёт
На желудок петь голодный!
Злой тоской удручена,
К Муравью ползёт она:
«Не оставь меня, кум милый!
Дай ты мне собраться с силой
И до вешних только дней
Прокорми и обогрей!»
«Кумушка, мне странно это:
Да работала ль ты в лето?» —
Говорит ей Муравей.
«До того ль, голубчик, было?
В мягких муравах у нас
Песни, резвость всякий час,
Так, что голову вскружило».
«А, так ты…» — «Я без души
Лето целое всё пела».
«Ты всё пела? это дело:
Так поди же, попляши!»


Лебедь, Щука и Рак

Когда в товарищах согласья нет,
На лад их дело не пойдёт,
И выйдет из него не дело, только мука.

Однажды Лебедь, Рак да Щука
Везти с поклажей воз взялись,
И вместе трое все в него впряглись;
Из кожи лезут вон, а возу всё нет ходу!
Поклажа бы для них казалась и легка:
Да Лебедь рвётся в облака,
Рак пятится назад, а Щука тянет в воду.
Кто виноват из них, кто прав — судить не нам;
Да только воз и ныне там.`},{id:`tolstoy-filipok`,title:`Филипок`,author:`Л. Н. Толстой`,years:`1875`,kind:`prose`,cover:`stone`,blurb:`Мальчик, которого не пускали в школу, всё равно дошёл — босиком, через деревню, мимо собак.`,text:`Был мальчик, звали его Филипп. Пошёл раз этот мальчик на улицу. В деревне этой была школа. Филипп увидал из-за забора, как ребята ходят в школу. Он и сам захотел в школу.

В школе училась старшая сестра Филиппа. Она и говорит матери:

— Пусти Филипка в школу, он уже большой, ему скучно дома.

Мать говорит:

— Куда ему в школу? Он ещё мал, пускай подрастёт.

Прошёл ещё год, Филипп вырос. Он видит, как ребята ходят в школу, и сам просится. Мать его пустила. Филипп обрадовался и побежал в школу.

Школа была за деревней. Когда Филипп шёл по улице, собаки бросились на него. Он испугался и побежал назад. Дома все уже ушли в поле, в избе никого не было. Филипп разделся, полез на печку и сидел. Ему скучно. Он думает: «Лучше пойти в школу. Мать не пускала, так я сам пойду».

Он надел шапку и побежал. На улице никого нет. Собаки увидали Филипка и бросились на него. Филипп начал кричать, собаки отстали. Он добежал до школы. На крыльце никого нет. В сенях слышно, как в классе гудят голоса.

Филипп испугался: «Как я войду?» Он постоял, постоял, отворил дверь и влез в класс. В классе учитель учил ребят грамоте. Все ребята сидели на лавках, а учитель в красной рубахе ходил по классу и громко говорил.

Филипп стал у двери. Учитель обернулся и увидал его.

— Ты что? — спросил учитель.

Филипп молчит.

— Ты чей?

Филипп молчит.

— Да ты глухой, что ли?

Филипп так испугался, что говорить не мог.

Учитель подошёл к нему и сказал:

— Ну, ступай домой. Рано тебе ещё учиться.

Филипп заплакал и сказал:

— Мне хочется учиться. Я грамотный. Вот я знаю буквы.

Учитель спросил:

— Ну, скажи азбуку.

Филипп сказал азбуку. Учитель похвалил его и сказал:

— Ступай к ребятам, садись.

Филипп сел на лавку. Учитель начал показывать ему буквы, и Филипп стал учиться.

С тех пор Филипок ходил в школу каждый день. Он выучился грамоте и стал помогать дома. А собаки его уже не пугали: он знал дорогу.`},{id:`turgenev-vorobey`,title:`Воробей`,author:`И. С. Тургенев`,years:`1878`,kind:`prose`,cover:`charcoal`,blurb:`Охотничья собака, молодой воробей и старый — и то, что сильнее смерти.`,text:`Я возвращался с охоты и шёл по аллее сада. Собака бежала впереди меня.

Вдруг она уменьшила свои шаги и начала красться, как бы зачуяв перед собою дичь.

Я глянул вдоль аллеи и увидал молодого воробья с желтизной около клюва и пухом на голове. Он упал из гнезда (ветер сильно качал берёзы аллеи) и сидел неподвижно, беспомощно растопырив едва прораставшие крылышки.

Моя собака медленно приближалась к нему, как вдруг, сорвавшись с близкого дерева, старый черногрудый воробей камнем упал перед самой её мордой — и весь взъерошенный, искажённый, с отчаянным и жалким писком прыгнул раза два в направлении зубастой раскрытой пасти.

Он ринулся спасать, он заслонил собою своё детище… но всё его маленькое тело трепетало от ужаса, голосок одичал и охрип, он замирал, он жертвовал собою!

Каким громадным чудовищем должна была ему казаться собака! И всё-таки он не мог усидеть на своей высокой, безопасной ветке… Сила, сильнее его воли, сбросила его оттуда.

Мой Трезор остановился, попятился… Видно, и он признал эту силу.

Я поспешил отозвать смущённого пса — и удалился, благоговея.

Да; не смейтесь. Я благоговел перед той маленькой героической птицей, перед любовным её порывом.

Любовь, думал я, сильнее смерти и страха смерти. Только ею, только любовью держится и движется жизнь.`},{id:`lermontov-parus`,title:`Парус. Бородино. Тучи`,author:`М. Ю. Лермонтов`,years:`1832–1841`,kind:`verse`,cover:`slate`,blurb:`Три стихотворения: беспокойный парус, рассказ солдата о Бородине и прощание с тучами.`,text:`Парус

Белеет парус одинокой
В тумане моря голубом!..
Что ищет он в стране далёкой?
Что кинул он в краю родном?..

Играют волны — ветер свищет,
И мачта гнётся и скрыпит…
Увы! он счастия не ищет
И не от счастия бежит!

Под ним струя светлей лазури,
Над ним луч солнца золотой…
А он, мятежный, просит бури,
Как будто в бурях есть покой!


Бородино

— Скажи-ка, дядя, ведь недаром
Москва, спалённая пожаром,
Французу отдана?
Ведь были ж схватки боевые,
Да, говорят, ещё какие!
Недаром помнит вся Россия
Про день Бородина!

— Да, были люди в наше время,
Не то, что нынешнее племя:
Богатыри — не вы!
Плохая им досталась доля:
Не многие вернулись с поля…
Не будь на то господня воля,
Не отдали б Москвы!

Мы долго молча отступали,
Досадно было, боя ждали,
Ворчали старики:
«Что ж мы? на зимние квартиры?
Не смеют, что ли, командиры
Чужие изорвать мундиры
О русские штыки?»

И вот нашли большое поле:
Есть разгуляться где на воле!
Построили редут.
У наших ушки на макушке!
Чуть утро осветило пушки
И леса синие верхушки —
Французы тут как тут.

Забил заряд я в пушку туго
И думал: угощу я друга!
Постой-ка, брат мусью!
Что тут хитрить, пожалуй к бою;
Уж мы пойдём ломить стеною,
Уж постоим мы головою
За родину свою!

Два дня мы были в перестрелке.
Что толку в этакой безделке?
Мы ждали третий день.
Повсюду стали слышны речи:
«Пора добраться до картечи!»
И вот на поле грозной сечи
Ночная пала тень.

Прилёг вздремнуть я у лафета,
И слышно было до рассвета,
Как ликовал француз.
Но тих был наш бивак открытый:
Кто кивер чистил весь избитый,
Кто штык точил, ворча сердито,
Кусая длинный ус.

И только небо засветилось,
Всё шумно вдруг зашевелилось,
Сверкнул за строем строй.
Полковник наш рождён был хватом:
Слуга царю, отец солдатам…
Да, жаль его: сражён булатом,
Он спит в земле сырой.

И молвил он, сверкнув очами:
«Ребята! не Москва ль за нами?
Умрёмте ж под Москвой,
Как наши братья умирали!»
И умереть мы обещали,
И клятву верности сдержали
Мы в Бородинский бой.

Ну ж был денёк! Сквозь дым летучий
Французы двинулись, как тучи,
И всё на наш редут.
Уланы с пёстрыми значками,
Драгуны с конскими хвостами,
Все промелькнули перед нами,
Все побывали тут.

Вам не видать таких сражений!..
Носились знамена, как тени,
В дыму огонь блестел,
Звучал булат, картечь визжала,
Рука бойцов колоть устала,
И ядрам пролетать мешала
Гора кровавых тел.

Изведал враг в тот день немало,
Что значит русский бой удалый,
Наш рукопашный бой!..
Земля тряслась — как наши груди;
Смешались в кучу кони, люди,
И залпы тысячи орудий
Слились в протяжный вой…

Вот смерклось. Были все готовы
Заутра бой затеять новый
И до конца стоять…
Вот затрещали барабаны —
И отступили бусурманы.
Тогда считать мы стали раны,
Товарищей считать.

Да, были люди в наше время,
Могучее, лихое племя:
Богатыри — не вы.
Плохая им досталась доля:
Не многие вернулись с поля.
Когда б на то не божья воля,
Не отдали б Москвы!


Тучи

Тучки небесные, вечные странники!
Степью лазурною, цепью жемчужною
Мчитесь вы, будто как я же, изгнанники
С милого севера в сторону южную.

Кто же вас гонит: судьбы ли решение?
Зависть ли тайная? злоба ль открытая?
Или на вас тяготит преступление?
Или друзей клевета ядовитая?

Нет, вам наскучили нивы бесплодные…
Чужды вам страсти и чужды страдания;
Вечно холодные, вечно свободные,
Нет у вас родины, нет вам изгнания.`},{id:`gogol-shinel`,title:`Шинель`,author:`Н. В. Гоголь`,years:`1842`,kind:`prose`,cover:`charcoal`,blurb:`Начало повести об Акакии Акакиевиче — тихом чиновнике, одной шинели и целом Петербурге.`,text:`В департаменте… но лучше не называть, в каком департаменте. Ничего нет сердитее всякого рода департаментов, полков, канцелярий и, словом, всякого рода должностных сословий. Теперь уже всякий частный человек считает в лице своём оскорблённым всё общество.

Итак, во избежание всяких неприятностей, лучше департамент, о котором идёт дело, мы назовём одним департаментом. Итак, в одном департаменте служил один чиновник; чиновник нельзя сказать чтобы очень замечательный, низенького роста, несколько рябоват, несколько рыжеват, несколько даже на вид подслеповат, с небольшой лысиной на лбу, с морщинами по обеим сторонам щёк и цветом лица что называется геморроидальным…

Фамилия чиновника была Башмачкин. Уже по самому имени видно, что она когда-то произошла от башмака; но когда, в какое время и каким образом произошла она от башмака, ничего этого не известно. Отец и дед, и даже шурин, и все совершенно Башмачкины ходили в сапогах, переменяя только раза три в год подмётки.

Имя его было Акакий Акакиевич. Оно, может быть, читателю покажется несколько странным и выисканным, но можно уверить, что его никак не искали, а что сами собою случились такие обстоятельства, что никак нельзя было дать другого имени.

Родился Акакий Акакиевич против ночи, если только не изменяет память, на 23 марта. Покойница мать, чиновница и очень хорошая женщина, расположилась, как следует, окрестить ребёнка. Матушка ещё лежала на кровати против дверей, а справа стоял крёстный отец, человек превосходный, Иван Иванович Ерошкин, служивший столоначальником в сенате, и крёстная мать, жена квартального офицера, женщина редких добродетелей, Арина Семёновна Белобрюшкова.

Родильнице предоставлен был выбор любого из трёх, какое она хочет выбрать: Моккия, Соссия, или назвать ребёнка во имя мученика Хоздазата. «Нет, — подумала покойница, — имена-то всё такие». Чтобы угодить ей, развернули календарь в другом месте; вышли опять три имени: Трифилий, Дула и Варахасий. «Вот это наказание, вот это вот какие имена; я, право, никогда и не слыхивала таких. Разве уж Варадат или Варух, не то чтобы Трифилий и Варахасий». Обратили ещё страницу — вышли: Павсикахий и Вахтисий. «Ну, уж я вижу, — сказала старуха, — что, видно, его такая судьба. Уж если так, пусть лучше будет он, как и отец его, Акакий». Таким образом и произошёл Акакий Акакиевич.

Ребёнок был крещён, причём он заплакал и сделал такую гримасу, как будто бы предчувствовал, что будет титулярный советник.

Итак, вот каким образом произошёл Акакий Акакиевич. Говорят, мать его была ещё чиновница, очень добрая женщина. Когда и в какое время он поступил в департамент и кто определил его, этого никто не мог припомнить. Сколько ни переменялось директоров и всяких начальников, его видели всё на одном и том же месте, в том же самом положении, тем же самым чиновником для письма, так что потом уверились, что он, видно, так и родился на свет уже совершенно готовым, в вицмундире и с лысиной на голове.

Начальники поступали с ним как-то холодно-презрительно. Молодые чиновники подсмеивались и острились над ним, во сколько хватало канцелярского остроумия, рассказывали при нём разные составленные про него истории; говорили про его хозяйку, семидесятилетнюю старуху, говорили, что она бьёт его, спрашивали, когда будет их свадьба… Но Акакий Акакиевич не отвечал ни одного слова, как будто бы никого и не было перед ним; это не имело даже влияния на занятие его: среди всех этих докук он не делал ни одной ошибки в письме.

Только если слишком уж невыносима была шутка, когда толкали его под руку, мешая заниматься своим делом, он произносил: «Оставьте меня, зачем вы меня обижаете?» И в этих проникнутых кротостью словах отдавалось что-то странное, располагающее к жалости.

Вряд ли где можно было найти человека, который так жил бы в своей должности. Мало сказать: он служил ревностно, — нет, он служил с любовью. Там, в этом переписыванье, ему виделся какой-то свой разнообразный и приятный мир. Наслаждение выражалось на лице его; некоторые буквы у него были фавориты, до которых если он добирался, то был сам не свой: и подсмеивался, и подмигивал, и помогал губами, так что в лице его, казалось, можно было прочесть всякую букву, которую выводило перо его.

Вне этого переписыванья, казалось, для него ничего не существовало.`}];function it({book:e,compact:t=!1}){return(0,Y.jsxs)(`div`,{className:J(`relative flex aspect-book flex-col justify-between overflow-hidden p-4 sm:p-5`,nt[e.cover],t&&`h-full min-h-28 aspect-auto p-3`),children:[(0,Y.jsx)(`div`,{className:`absolute inset-y-0 left-0 w-1.5 bg-cream/10`}),(0,Y.jsx)(`p`,{className:`text-[0.65rem] uppercase tracking-[0.16em] text-cream/55`,children:e.author}),(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`p`,{className:J(`font-display leading-[1.15] tracking-tight text-balance`,t?`text-base`:`text-lg sm:text-xl`),children:e.title}),(0,Y.jsx)(`p`,{className:`mt-3 text-[0.65rem] tabular-nums tracking-[0.14em] text-cream/45`,children:e.years})]})]})}var Z=m.forwardRef(({className:e,type:t=`text`,...n},r)=>(0,Y.jsx)(`input`,{ref:r,type:t,className:J(`h-12 w-full rounded-xl bg-ink-2 px-4 text-base text-cream shadow-border`,`placeholder:text-muted outline-none transition-[box-shadow] duration-150`,`focus-visible:shadow-ring`,`disabled:opacity-50`,e),...n}));Z.displayName=`Input`;function Q({className:e,...t}){return(0,Y.jsx)(`label`,{className:J(`block text-sm font-medium tracking-wide text-muted`,e),...t})}var at=e=>{let t,n=new Set,r=(e,r)=>{let i=typeof e==`function`?e(t):e;if(!Object.is(i,t)){let e=t;t=r??(typeof i!=`object`||!i)?i:Object.assign({},t,i),n.forEach(n=>n(t,e))}},i=()=>t,a={setState:r,getState:i,getInitialState:()=>o,subscribe:e=>(n.add(e),()=>n.delete(e))},o=t=e(r,i,a);return a},ot=(e=>e?at(e):at),st=e=>e;function ct(e,t=st){let n=m.useSyncExternalStore(e.subscribe,m.useCallback(()=>t(e.getState()),[e,t]),m.useCallback(()=>t(e.getInitialState()),[e,t]));return m.useDebugValue(n),n}var lt=e=>{let t=ot(e),n=e=>ct(t,e);return Object.assign(n,t),n},ut=(e=>e?lt(e):lt);function dt(e,t){let n;try{n=e()}catch{return}return{getItem:e=>{let r=e=>e===null?null:JSON.parse(e,t?.reviver),i=n.getItem(e)??null;return i instanceof Promise?i.then(r):r(i)},setItem:(e,r)=>n.setItem(e,JSON.stringify(r,t?.replacer)),removeItem:e=>n.removeItem(e)}}var ft=e=>t=>{try{let n=e(t);return n instanceof Promise?n:{then(e){return ft(e)(n)},catch(e){return this}}}catch(e){return{then(e){return this},catch(t){return ft(t)(e)}}}},pt=(e,t)=>(n,r,i)=>{let a={storage:dt(()=>window.localStorage),partialize:e=>e,version:0,merge:(e,t)=>({...t,...e}),...t},o=!1,s=0,c=new Set,l=new Set,u=a.storage;if(!u)return e((...e)=>{console.warn(`[zustand persist middleware] Unable to update item '${a.name}', the given storage is currently unavailable.`),n(...e)},r,i);let d=()=>{let e=a.partialize({...r()});return u.setItem(a.name,{state:e,version:a.version})},f=i.setState;i.setState=(e,t)=>(f(e,t),d());let p=e((...e)=>(n(...e),d()),r,i);i.getInitialState=()=>p;let m,h=()=>{if(!u)return;let e=++s;o=!1,c.forEach(e=>e(r()??p));let t=a.onRehydrateStorage?.call(a,r()??p)||void 0;return ft(u.getItem.bind(u))(a.name).then(e=>{if(e){if(typeof e.version==`number`&&e.version!==a.version){if(a.migrate){let t=a.migrate(e.state,e.version);return t instanceof Promise?t.then(e=>[!0,e]):[!0,t]}console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`)}else return[!1,e.state]}return[!1,void 0]}).then(t=>{if(e!==s)return;let[i,o]=t;if(m=a.merge(o,r()??p),n(m,!0),i)return d()}).then(()=>{e===s&&(t?.(r(),void 0),m=r(),o=!0,l.forEach(e=>e(m)))}).catch(n=>{e===s&&t?.(void 0,n)})};return i.persist={setOptions:e=>{a={...a,...e},e.storage&&(u=e.storage)},clearStorage:()=>{++s,u?.removeItem(a.name)},getOptions:()=>a,rehydrate:()=>h(),hasHydrated:()=>o,onHydrate:e=>(c.add(e),()=>{c.delete(e)}),onFinishHydration:e=>(l.add(e),()=>{l.delete(e)})},a.skipHydration||h(),m||p};function mt(){let e=crypto.getRandomValues(new Uint8Array(16));return Array.from(e,e=>e.toString(16).padStart(2,`0`)).join(``)}async function ht(e,t){let n=new TextEncoder().encode(`${t}:${e}`),r=await crypto.subtle.digest(`SHA-256`,n);return Array.from(new Uint8Array(r),e=>e.toString(16).padStart(2,`0`)).join(``)}var gt=`taynaya-polka-session`,_t=`taynaya-polka`;function vt(e){typeof sessionStorage<`u`&&(e?sessionStorage.setItem(gt,`1`):sessionStorage.removeItem(gt))}var $=ut()(pt((e,t)=>({hydrated:!1,salt:null,hash:null,unlocked:!1,customBooks:[],progress:{},settings:{fontSize:20,readerTheme:`paper`},openBookId:null,adding:!1,settingsOpen:!1,hydrate:()=>{let n=typeof sessionStorage<`u`&&sessionStorage.getItem(`taynaya-polka-session`)===`1`,{hash:r}=t();e({hydrated:!0,unlocked:!!(r&&n)})},setup:async t=>{let n=mt(),r=await ht(t,n);vt(!0),e({salt:n,hash:r,unlocked:!0})},unlock:async n=>{let{salt:r,hash:i}=t();if(!r||!i)return!1;let a=await ht(n,r)===i;return a&&(vt(!0),e({unlocked:!0})),a},lock:()=>{vt(!1),e({unlocked:!1,openBookId:null,adding:!1,settingsOpen:!1})},changePassword:async(n,r)=>{if(!await t().unlock(n))return!1;let i=mt();return e({salt:i,hash:await ht(r,i)}),!0},resetVault:()=>{vt(!1),e({salt:null,hash:null,unlocked:!1,customBooks:[],progress:{},settings:{fontSize:20,readerTheme:`paper`},openBookId:null,adding:!1,settingsOpen:!1})},openBook:t=>e({openBookId:t,adding:!1,settingsOpen:!1}),closeBook:()=>e({openBookId:null}),setProgress:(t,n)=>e(e=>({progress:{...e.progress,[t]:{percent:Math.min(100,Math.max(0,Math.round(n))),updatedAt:Date.now()}}})),addBook:({title:t,author:n,text:r})=>{let i=`custom-${crypto.randomUUID()}`,a={id:i,title:t.trim(),author:n.trim()||`Без автора`,years:new Date().getFullYear().toString(),kind:`prose`,blurb:r.trim().slice(0,140),cover:`custom`,text:r.trim(),custom:!0};return e(e=>({customBooks:[a,...e.customBooks],adding:!1,openBookId:i})),i},removeBook:t=>e(e=>{let n={...e.progress};return delete n[t],{customBooks:e.customBooks.filter(e=>e.id!==t),progress:n,openBookId:e.openBookId===t?null:e.openBookId}}),setSettings:t=>e(e=>({settings:{...e.settings,...t}})),setAdding:n=>e({adding:n,settingsOpen:!n&&t().settingsOpen}),setSettingsOpen:n=>e({settingsOpen:n,adding:!n&&t().adding})}),{name:_t,skipHydration:!0,partialize:e=>({salt:e.salt,hash:e.hash,customBooks:e.customBooks,progress:e.progress,settings:e.settings})}));function yt(e){return[...e.customBooks,...rt]}function bt(e,t){if(t)return e.find(e=>e.id===t)}function xt(){let e=$(e=>e.setSettingsOpen),t=$(e=>e.changePassword),n=$(e=>e.resetVault),r=$(e=>e.lock),[i,a]=(0,m.useState)(``),[o,s]=(0,m.useState)(``),[c,l]=(0,m.useState)(``),[u,d]=(0,m.useState)(``),[f,h]=(0,m.useState)(``),[g,_]=(0,m.useState)(!1),[v,y]=(0,m.useState)(!1);async function b(e){if(e.preventDefault(),h(``),d(``),o.trim().length<4){h(`Новый пароль — не короче четырёх знаков.`);return}if(o!==c){h(`Новые пароли не совпадают.`);return}_(!0);let n=await t(i,o.trim());if(_(!1),!n){h(`Старый пароль неверный.`);return}a(``),s(``),l(``),d(`Пароль заменён.`)}return(0,Y.jsxs)(`div`,{className:`fixed inset-0 z-40 flex items-end justify-center sm:items-center`,children:[(0,Y.jsx)(`button`,{type:`button`,"aria-label":`Закрыть`,className:`absolute inset-0 bg-ink/70`,onClick:()=>e(!1)}),(0,Y.jsxs)(`div`,{className:`relative w-full max-w-md overflow-y-auto rounded-t-3xl bg-ink-2 p-5 shadow-lift sm:rounded-3xl sm:p-7`,children:[(0,Y.jsxs)(`div`,{className:`mb-6 flex items-start justify-between`,children:[(0,Y.jsx)(`h2`,{className:`font-display text-2xl tracking-tight`,children:`Замок`}),(0,Y.jsx)(X,{variant:`ghost`,size:`icon-sm`,"aria-label":`Закрыть`,onClick:()=>e(!1),children:(0,Y.jsx)(p,{className:`size-4`})})]}),(0,Y.jsxs)(`form`,{onSubmit:b,className:`space-y-3`,children:[(0,Y.jsx)(`p`,{className:`font-reading text-sm text-muted`,children:`Сменить пароль`}),(0,Y.jsxs)(`div`,{className:`space-y-1.5`,children:[(0,Y.jsx)(Q,{htmlFor:`old-pw`,children:`Сейчас`}),(0,Y.jsx)(Z,{id:`old-pw`,type:`password`,autoComplete:`current-password`,value:i,onChange:e=>a(e.target.value)})]}),(0,Y.jsxs)(`div`,{className:`space-y-1.5`,children:[(0,Y.jsx)(Q,{htmlFor:`new-pw`,children:`Новый`}),(0,Y.jsx)(Z,{id:`new-pw`,type:`password`,autoComplete:`new-password`,value:o,onChange:e=>s(e.target.value)})]}),(0,Y.jsxs)(`div`,{className:`space-y-1.5`,children:[(0,Y.jsx)(Q,{htmlFor:`new-pw-2`,children:`Ещё раз`}),(0,Y.jsx)(Z,{id:`new-pw-2`,type:`password`,autoComplete:`new-password`,value:c,onChange:e=>l(e.target.value)})]}),f&&(0,Y.jsx)(`p`,{className:`text-sm text-danger`,role:`alert`,children:f}),u&&(0,Y.jsx)(`p`,{className:`text-sm text-sage`,children:u}),(0,Y.jsx)(X,{type:`submit`,variant:`sage`,className:`w-full`,disabled:g,children:`Сменить пароль`})]}),(0,Y.jsx)(`div`,{className:`mt-8 border-t border-cream/10 pt-6`,children:v?(0,Y.jsxs)(`div`,{className:`space-y-3`,children:[(0,Y.jsx)(`p`,{className:`font-reading text-sm leading-relaxed text-cream-2`,children:`Пароль, свои тексты и закладки будут удалены с этого устройства.`}),(0,Y.jsxs)(`div`,{className:`flex gap-2`,children:[(0,Y.jsx)(X,{variant:`danger`,size:`sm`,onClick:()=>{n(),r()},children:`Стереть`}),(0,Y.jsx)(X,{variant:`ghost`,size:`sm`,onClick:()=>y(!1),children:`Отмена`})]})]}):(0,Y.jsx)(`button`,{type:`button`,onClick:()=>y(!0),className:`text-sm text-faint underline-offset-4 hover:text-danger hover:underline`,children:`Стереть сейф`})})]})]})}var St=m.forwardRef(({className:e,...t},n)=>(0,Y.jsx)(`textarea`,{ref:n,className:J(`min-h-48 w-full resize-y rounded-xl bg-ink-2 px-4 py-3 text-base leading-relaxed text-cream shadow-border`,`placeholder:text-muted outline-none transition-[box-shadow] duration-150`,`focus-visible:shadow-ring`,e),...t}));St.displayName=`Textarea`;function Ct(){let e=$(e=>e.setAdding),t=$(e=>e.addBook),[n,r]=(0,m.useState)(``),[i,a]=(0,m.useState)(``),[o,s]=(0,m.useState)(``),[c,l]=(0,m.useState)(``);function u(e){if(e.preventDefault(),!n.trim()||!o.trim()){l(`Нужны название и текст.`);return}t({title:n,author:i,text:o})}return(0,Y.jsxs)(`div`,{className:`fixed inset-0 z-40 flex items-end justify-center sm:items-center`,children:[(0,Y.jsx)(`button`,{type:`button`,"aria-label":`Закрыть`,className:`absolute inset-0 bg-ink/70`,onClick:()=>e(!1)}),(0,Y.jsxs)(`div`,{role:`dialog`,"aria-labelledby":`add-book-title`,className:`relative flex max-h-dvh w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-ink-2 p-5 shadow-lift sm:max-h-[min(40rem,92dvh)] sm:rounded-3xl sm:p-7`,children:[(0,Y.jsxs)(`div`,{className:`mb-5 flex items-start justify-between gap-3`,children:[(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`h2`,{id:`add-book-title`,className:`font-display text-2xl tracking-tight`,children:`Свой текст`}),(0,Y.jsx)(`p`,{className:`mt-1 font-reading text-sm text-muted`,children:`Останется на этой полке и за тем же паролем.`})]}),(0,Y.jsx)(X,{variant:`ghost`,size:`icon-sm`,"aria-label":`Закрыть`,onClick:()=>e(!1),children:(0,Y.jsx)(p,{className:`size-4`})})]}),(0,Y.jsxs)(`form`,{onSubmit:u,className:`flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto`,children:[(0,Y.jsxs)(`div`,{className:`space-y-1.5`,children:[(0,Y.jsx)(Q,{htmlFor:`book-title`,children:`Название`}),(0,Y.jsx)(Z,{id:`book-title`,value:n,onChange:e=>r(e.target.value),placeholder:`Заголовок`})]}),(0,Y.jsxs)(`div`,{className:`space-y-1.5`,children:[(0,Y.jsx)(Q,{htmlFor:`book-author`,children:`Автор`}),(0,Y.jsx)(Z,{id:`book-author`,value:i,onChange:e=>a(e.target.value),placeholder:`необязательно`})]}),(0,Y.jsxs)(`div`,{className:`flex min-h-0 flex-1 flex-col space-y-1.5`,children:[(0,Y.jsx)(Q,{htmlFor:`book-text`,children:`Текст`}),(0,Y.jsx)(St,{id:`book-text`,value:o,onChange:e=>s(e.target.value),placeholder:`Вставьте рассказ, главу, письмо…`,className:`min-h-40 flex-1`})]}),c&&(0,Y.jsx)(`p`,{className:`text-sm text-danger`,role:`alert`,children:c}),(0,Y.jsx)(X,{type:`submit`,variant:`sage`,size:`lg`,className:`mt-1 w-full`,children:`Поставить на полку`})]})]})]})}function wt({className:e=`size-10`}){return(0,Y.jsxs)(`svg`,{viewBox:`0 0 48 48`,className:e,"aria-hidden":`true`,children:[(0,Y.jsx)(`rect`,{x:`6`,y:`10`,width:`8`,height:`28`,rx:`1.5`,fill:`currentColor`,opacity:`0.92`}),(0,Y.jsx)(`rect`,{x:`16`,y:`8`,width:`7`,height:`30`,rx:`1.5`,fill:`currentColor`,opacity:`0.72`}),(0,Y.jsx)(`rect`,{x:`25`,y:`12`,width:`9`,height:`26`,rx:`1.5`,fill:`currentColor`,opacity:`0.84`}),(0,Y.jsx)(`rect`,{x:`36`,y:`9`,width:`6`,height:`29`,rx:`1.5`,fill:`currentColor`,opacity:`0.6`}),(0,Y.jsx)(`rect`,{x:`4`,y:`38`,width:`40`,height:`3`,rx:`1`,fill:`currentColor`})]})}function Tt({className:e=`size-8`}){return(0,Y.jsxs)(`svg`,{viewBox:`0 0 48 48`,className:e,"aria-hidden":`true`,children:[(0,Y.jsx)(`rect`,{x:`12`,y:`22`,width:`24`,height:`18`,rx:`3`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`}),(0,Y.jsx)(`path`,{d:`M17 22v-6a7 7 0 0 1 14 0v6`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`}),(0,Y.jsx)(`circle`,{cx:`24`,cy:`31`,r:`2.2`,fill:`currentColor`})]})}function Et(){let e=$(e=>e.customBooks),t=$(e=>e.progress),n=$(e=>e.openBook),r=$(e=>e.lock),i=$(e=>e.adding),a=$(e=>e.setAdding),o=$(e=>e.settingsOpen),c=$(e=>e.setSettingsOpen),[f,h]=(0,m.useState)(``),g=yt({customBooks:e}),_=(0,m.useMemo)(()=>{let e=f.trim().toLowerCase();return e?g.filter(t=>t.title.toLowerCase().includes(e)||t.author.toLowerCase().includes(e)||t.blurb.toLowerCase().includes(e)):g},[g,f]),v=(0,m.useMemo)(()=>{let e=Object.entries(t).filter(([,e])=>e.percent>2&&e.percent<98);return e.sort((e,t)=>t[1].updatedAt-e[1].updatedAt),e[0]?.[0]},[t]),y=g.find(e=>e.id===v);return(0,Y.jsxs)(`div`,{className:`shelf-grain min-h-dvh text-cream`,children:[(0,Y.jsx)(`header`,{className:`sticky top-0 z-20 border-b border-cream/8 bg-ink/85 backdrop-blur-md`,children:(0,Y.jsxs)(`div`,{className:`mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6`,children:[(0,Y.jsx)(wt,{className:`size-8 shrink-0 text-sage`}),(0,Y.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,Y.jsx)(`p`,{className:`truncate font-display text-lg tracking-tight sm:text-xl`,children:`Тайная полка`}),(0,Y.jsxs)(`p`,{className:`hidden text-[0.7rem] uppercase tracking-[0.18em] text-muted sm:block`,children:[g.length,` книг за замком`]})]}),(0,Y.jsx)(X,{variant:`ghost`,size:`icon`,"aria-label":`Добавить текст`,onClick:()=>a(!0),children:(0,Y.jsx)(l,{className:`size-5`})}),(0,Y.jsx)(X,{variant:`ghost`,size:`icon`,"aria-label":`Настройки`,onClick:()=>c(!0),children:(0,Y.jsx)(d,{className:`size-5`})}),(0,Y.jsxs)(X,{variant:`outline`,size:`sm`,onClick:r,className:`hidden sm:inline-flex`,children:[(0,Y.jsx)(s,{className:`size-3.5`}),`Закрыть`]}),(0,Y.jsx)(X,{variant:`ghost`,size:`icon`,"aria-label":`Закрыть полку`,onClick:r,className:`sm:hidden`,children:(0,Y.jsx)(s,{className:`size-5`})})]})}),(0,Y.jsxs)(`main`,{className:`mx-auto max-w-6xl px-4 pb-20 pt-8 sm:px-6`,children:[y&&(0,Y.jsxs)(`button`,{type:`button`,onClick:()=>n(y.id),className:`reveal mb-8 flex w-full items-stretch overflow-hidden rounded-2xl bg-ink-2 text-left shadow-border transition-[box-shadow] duration-150 hover:shadow-border-hover`,children:[(0,Y.jsx)(`div`,{className:`hidden w-28 shrink-0 sm:block`,children:(0,Y.jsx)(it,{book:y,compact:!0})}),(0,Y.jsxs)(`div`,{className:`flex min-w-0 flex-1 flex-col justify-center px-5 py-4`,children:[(0,Y.jsx)(`p`,{className:`text-[0.65rem] uppercase tracking-[0.2em] text-sage`,children:`продолжить`}),(0,Y.jsx)(`p`,{className:`mt-1 truncate font-display text-xl tracking-tight`,children:y.title}),(0,Y.jsx)(`p`,{className:`truncate text-sm text-muted`,children:y.author}),(0,Y.jsx)(`div`,{className:`mt-3 h-1 overflow-hidden rounded-full bg-cream/10`,children:(0,Y.jsx)(`div`,{className:`h-full rounded-full bg-sage`,style:{width:`${t[y.id]?.percent??0}%`}})})]})]}),(0,Y.jsxs)(`div`,{className:`mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between`,children:[(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`h2`,{className:`font-display text-3xl tracking-tight sm:text-4xl`,children:`Полка`}),(0,Y.jsx)(`p`,{className:`mt-1 font-reading text-sm text-muted`,children:`Классика в открытом доступе — и ваши тексты, которые видите только вы.`})]}),(0,Y.jsxs)(`label`,{className:`relative block w-full sm:w-72`,children:[(0,Y.jsx)(u,{className:`pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint`}),(0,Y.jsx)(`input`,{value:f,onChange:e=>h(e.target.value),placeholder:`Найти книгу`,className:`h-11 w-full rounded-xl bg-ink-2 pl-10 pr-10 text-sm text-cream shadow-border outline-none placeholder:text-muted focus-visible:shadow-ring`}),f&&(0,Y.jsx)(`button`,{type:`button`,"aria-label":`Очистить поиск`,onClick:()=>h(``),className:`absolute right-2 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center text-muted`,children:(0,Y.jsx)(p,{className:`size-4`})})]})]}),_.length===0?(0,Y.jsx)(`p`,{className:`py-16 text-center font-reading text-muted`,children:`Ничего не нашлось.`}):(0,Y.jsx)(`ul`,{className:`grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-5 lg:grid-cols-4`,children:_.map((e,r)=>{let i=t[e.id]?.percent??0;return(0,Y.jsx)(`li`,{className:`reveal`,style:{animationDelay:`${Math.min(r,8)*40}ms`},children:(0,Y.jsxs)(`button`,{type:`button`,onClick:()=>n(e.id),className:`group flex w-full flex-col text-left`,children:[(0,Y.jsx)(`div`,{className:`overflow-hidden rounded-xl shadow-lift transition-transform duration-200 ease-out group-hover:-translate-y-1 group-active:scale-[0.98]`,children:(0,Y.jsx)(it,{book:e})}),(0,Y.jsx)(`h3`,{className:`mt-3 line-clamp-2 font-display text-[0.95rem] leading-snug tracking-tight sm:text-base`,children:e.title}),(0,Y.jsx)(`p`,{className:`mt-0.5 truncate text-xs text-muted sm:text-sm`,children:e.author}),(0,Y.jsxs)(`p`,{className:`mt-1 text-[0.7rem] tabular-nums text-faint`,children:[et(e.text),` мин`,i>0?` · ${i}%`:``]}),i>0&&(0,Y.jsx)(`div`,{className:`mt-2 h-0.5 overflow-hidden rounded-full bg-cream/10`,children:(0,Y.jsx)(`div`,{className:`h-full bg-sage`,style:{width:`${i}%`}})})]})},e.id)})})]}),i&&(0,Y.jsx)(Ct,{}),o&&(0,Y.jsx)(xt,{})]})}function Dt({mode:e}){let t=$(e=>e.setup),n=$(e=>e.unlock),r=$(e=>e.resetVault),[i,s]=(0,m.useState)(``),[c,l]=(0,m.useState)(``),[u,d]=(0,m.useState)(!1),[f,p]=(0,m.useState)(``),[h,g]=(0,m.useState)(0),[_,v]=(0,m.useState)(!1),[y,b]=(0,m.useState)(!1);async function ee(r){r.preventDefault(),p(``);let a=i.trim();if(a.length<4){p(`Пароль — не короче четырёх знаков.`),g(e=>e+1);return}if(e===`setup`){if(a!==c.trim()){p(`Пароли не совпадают.`),g(e=>e+1);return}v(!0),await t(a),v(!1);return}v(!0);let o=await n(a);v(!1),o||(p(`Неверный пароль.`),g(e=>e+1),s(``))}return(0,Y.jsxs)(`main`,{className:`shelf-grain relative flex min-h-dvh flex-col items-center justify-start px-5 pt-14 pb-32 text-cream md:justify-center md:py-16 md:pb-28`,children:[(0,Y.jsx)(`div`,{"aria-hidden":!0,className:`pointer-events-none absolute inset-y-0 left-0 hidden w-16 border-r border-cream/8 md:block`,children:(0,Y.jsx)(Ot,{})}),(0,Y.jsx)(`div`,{"aria-hidden":!0,className:`pointer-events-none absolute inset-y-0 right-0 hidden w-16 border-l border-cream/8 md:block`,children:(0,Y.jsx)(Ot,{mirror:!0})}),(0,Y.jsxs)(`div`,{className:`relative w-full max-w-md`,children:[(0,Y.jsxs)(`div`,{className:`reveal mb-10 flex flex-col items-center text-center`,children:[(0,Y.jsx)(`span`,{className:`text-sage`,children:e===`setup`?(0,Y.jsx)(wt,{className:`size-12`}):(0,Y.jsx)(Tt,{className:`size-11`})}),(0,Y.jsx)(`p`,{className:`mt-5 text-[0.7rem] font-medium uppercase tracking-[0.28em] text-sage`,children:`закрытая библиотека`}),(0,Y.jsx)(`h1`,{className:`mt-3 font-display text-5xl font-medium tracking-[-0.04em] text-cream sm:text-6xl`,children:`Тайная полка`}),(0,Y.jsxs)(`div`,{className:`mt-6 flex w-full items-center gap-4 text-rule`,children:[(0,Y.jsx)(`span`,{className:`h-px flex-1 bg-cream/15`}),(0,Y.jsx)(`span`,{className:`text-[0.65rem] uppercase tracking-[0.22em] text-muted`,children:e===`setup`?`новый сейф`:`вход`}),(0,Y.jsx)(`span`,{className:`h-px flex-1 bg-cream/15`})]})]}),(0,Y.jsxs)(`form`,{onSubmit:ee,className:J(`reveal reveal-d2 space-y-4`,h>0&&f&&`shake`),children:[(0,Y.jsx)(`p`,{className:`text-center font-reading text-[0.95rem] leading-relaxed text-muted`,children:e===`setup`?`Придумайте пароль. Без него полка не откроется — никому, даже вам, если забудете.`:`Введите пароль, чтобы открыть книги.`}),(0,Y.jsxs)(`div`,{className:`space-y-2`,children:[(0,Y.jsx)(Q,{htmlFor:`password`,children:e===`setup`?`Пароль`:`Пароль полки`}),(0,Y.jsxs)(`div`,{className:`relative`,children:[(0,Y.jsx)(Z,{id:`password`,autoFocus:!0,autoComplete:e===`setup`?`new-password`:`current-password`,type:u?`text`:`password`,value:i,onChange:e=>s(e.target.value),placeholder:`не короче 4 знаков`,className:`pr-12`}),(0,Y.jsx)(`button`,{type:`button`,"aria-label":u?`Скрыть пароль`:`Показать пароль`,onClick:()=>d(e=>!e),className:`absolute right-1.5 top-1/2 flex size-9 -translate-y-1/2 items-center justify-center rounded-md text-muted hover:text-cream`,children:u?(0,Y.jsx)(a,{className:`size-4`}):(0,Y.jsx)(o,{className:`size-4`})})]})]}),e===`setup`&&(0,Y.jsxs)(`div`,{className:`space-y-2`,children:[(0,Y.jsx)(Q,{htmlFor:`confirm`,children:`Ещё раз`}),(0,Y.jsx)(Z,{id:`confirm`,autoComplete:`new-password`,type:u?`text`:`password`,value:c,onChange:e=>l(e.target.value),placeholder:`повторите пароль`})]}),f?(0,Y.jsx)(`p`,{className:`text-center text-sm text-danger`,role:`alert`,children:f}):(0,Y.jsx)(`p`,{className:`h-5`}),(0,Y.jsx)(X,{type:`submit`,variant:`sage`,size:`lg`,className:`w-full`,disabled:_,children:_?`Минуту…`:e===`setup`?`Закрыть полку`:`Открыть`})]},h),e===`unlock`&&(0,Y.jsx)(`div`,{className:`reveal reveal-d4 mt-10 text-center`,children:y?(0,Y.jsxs)(`div`,{className:`space-y-3 rounded-2xl bg-ink-2 p-5 text-left shadow-border`,children:[(0,Y.jsx)(`p`,{className:`font-reading text-sm leading-relaxed text-cream-2`,children:`Пароль нельзя восстановить. Можно только стереть сейф: книги, которые вы добавили, и закладки пропадут.`}),(0,Y.jsxs)(`div`,{className:`flex flex-wrap gap-2`,children:[(0,Y.jsx)(X,{variant:`danger`,size:`sm`,onClick:r,children:`Стереть сейф`}),(0,Y.jsx)(X,{variant:`ghost`,size:`sm`,onClick:()=>b(!1),children:`Оставить`})]})]}):(0,Y.jsx)(`button`,{type:`button`,onClick:()=>b(!0),className:`text-sm text-faint underline-offset-4 hover:text-muted hover:underline`,children:`Забыли пароль?`})})]})]})}function Ot({mirror:e=!1}){return(0,Y.jsx)(`div`,{className:J(`flex h-full items-end justify-center gap-1.5 px-3 pb-10 pt-16`,e&&`flex-row-reverse`),children:[{h:`68%`,c:`bg-cover-forest`},{h:`78%`,c:`bg-cover-umber`},{h:`60%`,c:`bg-cover-olive`},{h:`84%`,c:`bg-cover-slate`},{h:`72%`,c:`bg-cover-stone`}].map((e,t)=>(0,Y.jsx)(`span`,{className:J(`w-2 rounded-sm opacity-80`,e.c),style:{height:e.h}},t))})}var kt=[{id:`paper`,label:`Бумага`},{id:`sepia`,label:`Сепия`},{id:`night`,label:`Ночь`}];function At({bookId:e}){let t=bt(yt({customBooks:$(e=>e.customBooks)}),e),n=$(e=>e.closeBook),r=$(e=>e.setProgress),a=$(e=>e.removeBook),o=$(e=>e.settings),s=$(e=>e.setSettings),u=$(t=>t.progress[e]?.percent??0),d=(0,m.useRef)(null);if((0,m.useEffect)(()=>{let n=d.current;if(!n||!t)return;let r=$.getState().progress[e]?.percent??0;r>0&&requestAnimationFrame(()=>{let e=n.scrollHeight-n.clientHeight;e>0&&(n.scrollTop=r/100*e)});let i=!1;function a(){let t=d.current;t&&!i&&(i=!0,requestAnimationFrame(()=>{i=!1;let n=t.scrollHeight-t.clientHeight,r=n<=0?100:t.scrollTop/n*100;$.getState().setProgress(e,r)}))}return n.addEventListener(`scroll`,a,{passive:!0}),()=>n.removeEventListener(`scroll`,a)},[t,e]),!t)return(0,Y.jsxs)(`div`,{className:`shelf-grain flex min-h-dvh flex-col items-center justify-center gap-4 text-cream`,children:[(0,Y.jsx)(`p`,{children:`Книга не найдена.`}),(0,Y.jsx)(X,{onClick:n,children:`На полку`})]});let p=o.readerTheme,h=t.text.split(/\n{2,}/).map(e=>e.trim()).filter(Boolean);return(0,Y.jsxs)(`div`,{className:J(`flex min-h-dvh flex-col`,p===`paper`&&`paper-grain text-ink`,p===`sepia`&&`bg-sepia text-sepia-ink`,p===`night`&&`bg-night text-night-fg`),children:[(0,Y.jsxs)(`header`,{className:J(`sticky top-0 z-20 border-b backdrop-blur-md`,p===`paper`&&`border-ink/8 bg-paper/90`,p===`sepia`&&`border-sepia-ink/10 bg-sepia/90`,p===`night`&&`border-cream/8 bg-night/90`),children:[(0,Y.jsxs)(`div`,{className:`mx-auto flex max-w-3xl items-center gap-2 px-2 py-2 sm:px-4`,children:[(0,Y.jsx)(X,{variant:`quiet`,size:`icon`,"aria-label":`На полку`,onClick:n,className:J(p===`night`&&`text-cream hover:bg-cream/8`),children:(0,Y.jsx)(i,{className:`size-5`})}),(0,Y.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,Y.jsx)(`p`,{className:`truncate font-display text-sm tracking-tight sm:text-base`,children:t.title}),(0,Y.jsxs)(`p`,{className:`truncate text-[0.7rem] text-current/50`,children:[t.author,` · `,et(t.text),` мин`]})]}),(0,Y.jsxs)(`div`,{className:`flex items-center gap-0.5`,children:[(0,Y.jsx)(X,{variant:`quiet`,size:`icon-sm`,"aria-label":`Мельче`,className:J(p===`night`&&`text-cream hover:bg-cream/8`),onClick:()=>s({fontSize:Math.max(16,o.fontSize-2)}),children:(0,Y.jsx)(c,{className:`size-4`})}),(0,Y.jsx)(`span`,{className:`w-8 text-center text-xs tabular-nums text-current/55`,children:o.fontSize}),(0,Y.jsx)(X,{variant:`quiet`,size:`icon-sm`,"aria-label":`Крупнее`,className:J(p===`night`&&`text-cream hover:bg-cream/8`),onClick:()=>s({fontSize:Math.min(28,o.fontSize+2)}),children:(0,Y.jsx)(l,{className:`size-4`})})]})]}),(0,Y.jsx)(`div`,{className:`h-0.5 bg-current/10`,children:(0,Y.jsx)(`div`,{className:`h-full bg-sage transition-[width] duration-150`,style:{width:`${u}%`}})})]}),(0,Y.jsx)(`div`,{ref:d,className:`flex-1 overflow-y-auto`,children:(0,Y.jsxs)(`article`,{className:`mx-auto max-w-2xl px-5 pb-28 pt-10 sm:px-8`,children:[(0,Y.jsx)(`p`,{className:`text-[0.7rem] uppercase tracking-[0.2em] text-current/45`,children:t.author}),(0,Y.jsx)(`h1`,{className:`mt-2 font-display text-3xl font-medium tracking-tight sm:text-4xl`,children:t.title}),(0,Y.jsx)(`p`,{className:`mt-3 text-sm text-current/50`,children:t.years}),(0,Y.jsx)(`div`,{className:`mt-6 mb-10 h-px bg-current/12`}),(0,Y.jsx)(`div`,{className:J(`font-reading leading-[1.7]`,t.kind===`verse`&&`whitespace-pre-line`),style:{fontSize:`${o.fontSize}px`},children:h.map((e,n)=>(0,Y.jsx)(`p`,{className:J(n>0&&`mt-5`,t.kind===`prose`&&`indent-6`),children:e},n))}),(0,Y.jsxs)(`div`,{className:`mt-16 flex flex-col items-center gap-4 border-t border-current/10 pt-10`,children:[(0,Y.jsx)(`p`,{className:`font-display text-lg tracking-tight`,children:`Конец`}),(0,Y.jsx)(X,{variant:p===`night`?`primary`:`paper`,onClick:()=>{r(e,100),n()},children:`На полку`}),t.custom&&(0,Y.jsxs)(X,{variant:`quiet`,className:`text-danger`,onClick:()=>{confirm(`Удалить этот текст с полки?`)&&a(t.id)},children:[(0,Y.jsx)(f,{className:`size-4`}),`Удалить`]})]})]})}),(0,Y.jsx)(`div`,{className:J(`pointer-events-none sticky bottom-0 flex justify-center pb-4 pt-8`,p===`paper`&&`bg-linear-to-t from-paper via-paper/90 to-transparent`,p===`sepia`&&`bg-linear-to-t from-sepia via-sepia/90 to-transparent`,p===`night`&&`bg-linear-to-t from-night via-night/90 to-transparent`),children:(0,Y.jsx)(`div`,{className:J(`pointer-events-auto flex gap-1 rounded-full p-1 shadow-[var(--shadow-lift)]`,p===`night`?`bg-ink-2`:`bg-ink text-cream`),children:kt.map(e=>(0,Y.jsx)(`button`,{type:`button`,onClick:()=>s({readerTheme:e.id}),className:J(`h-9 rounded-full px-3.5 text-xs font-medium tracking-wide transition-colors duration-150`,o.readerTheme===e.id?`bg-sage text-ink`:`text-cream/70 hover:text-cream`),children:e.label},e.id))})})]})}function jt(){let e=$(e=>e.hydrated),t=$(e=>e.hash),n=$(e=>e.unlocked),r=$(e=>e.openBookId);return(0,m.useEffect)(()=>{let e=$.persist.rehydrate();Promise.resolve(e).then(()=>{$.getState().hydrate()})},[]),!e||!t?(0,Y.jsx)(Dt,{mode:`setup`}):n?r?(0,Y.jsx)(At,{bookId:r}):(0,Y.jsx)(Et,{}):(0,Y.jsx)(Dt,{mode:`unlock`})}export{jt as component};