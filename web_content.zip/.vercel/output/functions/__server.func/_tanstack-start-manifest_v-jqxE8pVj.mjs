//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-jqxE8pVj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/channel/$channelId"],
		preloads: ["/assets/index-ChjZRHEq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ChjZRHEq.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DymKdZm8.js", "/assets/topics-DJAkh2ii.js"]
	},
	"/channel/$channelId": {
		filePath: "/workspace/src/routes/channel.$channelId.tsx",
		children: void 0,
		preloads: ["/assets/channel._channelId-C5FeWEN7.js", "/assets/topics-DJAkh2ii.js"]
	}
} });
//#endregion
export { tsrStartManifest };
