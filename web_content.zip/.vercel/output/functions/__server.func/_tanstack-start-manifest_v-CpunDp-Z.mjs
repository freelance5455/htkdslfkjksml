//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CpunDp-Z.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-ClCCoUIs.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ClCCoUIs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Du5pYsx6.js"]
	}
} });
//#endregion
export { tsrStartManifest };
