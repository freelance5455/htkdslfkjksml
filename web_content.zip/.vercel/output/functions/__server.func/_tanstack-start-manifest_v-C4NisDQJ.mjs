//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C4NisDQJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-lkNKR1v2.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-lkNKR1v2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D7xPyxFi.js"]
	}
} });
//#endregion
export { tsrStartManifest };
