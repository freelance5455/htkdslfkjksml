//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DxR7Qymg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/esame",
			"/glossario",
			"/segnali",
			"/manuale/$slug",
			"/manuale/"
		],
		preloads: [
			"/assets/index-DAZnzosU.js",
			"/assets/jsx-runtime-Dk72oS4N.js",
			"/assets/word-context-9kNSVXJu.js",
			"/assets/link-D5U5J0TK.js",
			"/assets/useRouter-BWuYVZyj.js",
			"/assets/study-store-DOrL2yuA.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DAZnzosU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B52xQCn7.js",
			"/assets/curriculum-BbJ1-TRX.js",
			"/assets/quiz-SpjIwtrg.js",
			"/assets/signs-uYSm4mp2.js"
		]
	},
	"/esame": {
		filePath: "/workspace/src/routes/esame.tsx",
		children: void 0,
		preloads: [
			"/assets/esame-Cy7WYywq.js",
			"/assets/road-sign-CHNiVFbU.js",
			"/assets/curriculum-BbJ1-TRX.js",
			"/assets/quiz-SpjIwtrg.js",
			"/assets/signs-uYSm4mp2.js"
		]
	},
	"/glossario": {
		filePath: "/workspace/src/routes/glossario.tsx",
		children: void 0,
		preloads: ["/assets/glossario-voO4239q.js", "/assets/glossary-BA0mgaQZ.js"]
	},
	"/segnali": {
		filePath: "/workspace/src/routes/segnali.tsx",
		children: void 0,
		preloads: [
			"/assets/segnali-DSgRs6QQ.js",
			"/assets/road-sign-CHNiVFbU.js",
			"/assets/signs-uYSm4mp2.js"
		]
	},
	"/manuale/$slug": {
		filePath: "/workspace/src/routes/manuale/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-BtyZ3yXn.js",
			"/assets/_slug-cLleKE79.js",
			"/assets/road-sign-CHNiVFbU.js",
			"/assets/curriculum-BbJ1-TRX.js",
			"/assets/quiz-SpjIwtrg.js",
			"/assets/signs-uYSm4mp2.js"
		]
	},
	"/manuale/": {
		filePath: "/workspace/src/routes/manuale/index.tsx",
		children: void 0,
		preloads: ["/assets/manuale-CohUqvzR.js", "/assets/curriculum-BbJ1-TRX.js"]
	}
} });
//#endregion
export { tsrStartManifest };
