//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D90UxKN5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B4LHMRjj.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B4LHMRjj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C6ZX6nDY.js"]
	}
} });
//#endregion
export { tsrStartManifest };
