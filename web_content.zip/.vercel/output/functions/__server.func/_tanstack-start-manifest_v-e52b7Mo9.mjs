//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-e52b7Mo9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DFs1R4cs.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DFs1R4cs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CQ6m7z9B.js"]
	}
} });
//#endregion
export { tsrStartManifest };
