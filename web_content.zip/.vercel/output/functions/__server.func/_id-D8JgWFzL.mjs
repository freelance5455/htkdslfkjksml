import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, t as Dialog } from "./_libs/@radix-ui/react-dialog+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./_ssr/ssr.mjs";
import { n as CATEGORIES, r as STYLES, t as CAMPAIGNS } from "./_ssr/options-I4YTksiA.mjs";
import { a as scenesFromBeats, i as rebuildScenePrompts, r as localBeats, t as aspectFrameClass } from "./_ssr/prompts-C2oS8e1R.mjs";
import { a as number, n as array, o as object, r as boolean, s as string, t as _enum } from "./_libs/zod.mjs";
import { i as ChevronLeft, r as ChevronRight, t as X } from "./_libs/lucide-react.mjs";
import { r as Route$1 } from "./_ssr/router-BlmjsFDF.mjs";
import { a as useProjects, o as useStory, r as mapScene } from "./_ssr/use-projects-B0rAf6PZ.mjs";
import { a as TextInput, i as TextArea, n as SCENE_COUNTS, r as SelectInput, t as Field } from "./_ssr/types-C96IdVUM.mjs";
import { t as Button } from "./_ssr/button-ZNEObmRA.mjs";
import { n as downloadScenesZip, t as downloadDataUrl } from "./_ssr/download-BEVDFjl1.mjs";
import { n as SwitchThumb, t as Switch } from "./_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-D8JgWFzL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CopyButton({ text, label }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "secondary",
		className: "w-full",
		onClick: async () => {
			try {
				await navigator.clipboard.writeText(text);
			} catch {
				const area = document.createElement("textarea");
				area.value = text;
				document.body.appendChild(area);
				area.select();
				document.execCommand("copy");
				area.remove();
			}
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		},
		children: copied ? "Copied!" : label
	});
}
function SceneCard({ index, scene, aspect, busy, onPrompt, onGenerate, onSaveDraft }) {
	const [editingPrompt, setEditingPrompt] = (0, import_react.useState)(false);
	const [prompt, setPrompt] = (0, import_react.useState)(scene.imagePrompt);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(scene);
	(0, import_react.useEffect)(() => {
		if (!editingPrompt) setPrompt(scene.imagePrompt);
	}, [scene.imagePrompt, editingPrompt]);
	(0, import_react.useEffect)(() => {
		if (!open) setDraft(scene);
	}, [scene, open]);
	const number = String(index + 1).padStart(2, "0");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		id: `scene-${scene.id}`,
		className: "grid gap-3 rounded-xl border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "grid gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: ["Scene ", number]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl leading-tight font-medium tracking-tight",
						children: scene.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: scene.description
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `overflow-hidden rounded-md bg-bg ${aspectFrameClass(aspect)}`,
				children: scene.imageDataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: scene.imageDataUrl,
					alt: scene.title,
					className: "h-full w-full object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full items-center justify-center px-4 text-center text-sm text-muted",
					children: scene.status === "generating" ? "Membuat gambar scene ini." : scene.status === "queued" ? "Menunggu giliran." : "Gambar muncul di sini."
				})
			}),
			scene.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: scene.error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Image prompt"
					}),
					editingPrompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
						value: prompt,
						onChange: (event) => setPrompt(event.target.value),
						rows: 8
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-h-48 overflow-y-auto text-sm whitespace-pre-wrap text-ink",
						children: scene.imagePrompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
						text: editingPrompt ? prompt : scene.imagePrompt,
						label: "Copy prompt"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Image-to-video prompt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-h-48 overflow-y-auto text-sm whitespace-pre-wrap text-ink",
						children: scene.videoPrompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
						text: scene.videoPrompt,
						label: "Copy video prompt"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						disabled: busy,
						onClick: () => {
							if (editingPrompt) onPrompt(scene.id, prompt);
							onGenerate(scene.id);
						},
						children: "Regenerate scene"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => {
							if (editingPrompt) {
								onPrompt(scene.id, prompt);
								setEditingPrompt(false);
							} else setEditingPrompt(true);
						},
						children: editingPrompt ? "Simpan prompt" : "Edit prompt"
					}),
					editingPrompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: busy,
						onClick: () => {
							onPrompt(scene.id, prompt);
							setEditingPrompt(false);
							onGenerate(scene.id);
						},
						children: "Generate scene"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => setOpen(true),
						children: "Edit scene"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						disabled: !scene.imageDataUrl,
						onClick: () => {
							if (scene.imageDataUrl) downloadDataUrl(scene.imageDataUrl, `scene-${number}.jpg`);
						},
						children: "Download image"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "fixed inset-x-0 bottom-0 z-50 max-h-[92dvh] overflow-y-auto rounded-t-xl bg-surface p-4 sm:inset-x-auto sm:top-1/2 sm:bottom-auto sm:left-1/2 sm:w-full sm:max-w-lg sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-display text-2xl font-medium tracking-tight",
							children: "Edit scene"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
							className: "inline-flex size-11 items-center justify-center rounded-md",
							"aria-label": "Tutup",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Scene title",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									value: draft.title,
									onChange: (event) => setDraft({
										...draft,
										title: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Scene description",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
									value: draft.description,
									onChange: (event) => setDraft({
										...draft,
										description: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Camera angle",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									value: draft.cameraAngle,
									onChange: (event) => setDraft({
										...draft,
										cameraAngle: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Camera distance",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									value: draft.cameraDistance,
									onChange: (event) => setDraft({
										...draft,
										cameraDistance: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Lighting",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									value: draft.lighting,
									onChange: (event) => setDraft({
										...draft,
										lighting: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Background",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
									value: draft.background,
									onChange: (event) => setDraft({
										...draft,
										background: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Props",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
									value: draft.props,
									onChange: (event) => setDraft({
										...draft,
										props: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Human interaction",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
									value: draft.humanInteraction,
									onChange: (event) => setDraft({
										...draft,
										humanInteraction: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Mood",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									value: draft.mood,
									onChange: (event) => setDraft({
										...draft,
										mood: event.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Menyimpan akan menyusun ulang image prompt dan video prompt."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => {
									onSaveDraft(scene.id, draft);
									setOpen(false);
								},
								children: "Simpan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: busy,
								onClick: () => {
									onSaveDraft(scene.id, draft);
									setOpen(false);
									onGenerate(scene.id);
								},
								children: "Generate scene"
							})
						]
					})]
				})] })
			})
		]
	});
}
function pickEven(items, max) {
	if (items.length <= max) return items.slice();
	if (max <= 1) return items.slice(0, 1);
	const out = [];
	for (let i = 0; i < max; i++) {
		const idx = Math.round(i * (items.length - 1) / (max - 1));
		out.push(items[idx]);
	}
	return out;
}
function blobToDataUrl(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(blob);
	});
}
async function fileToStoredImage(file) {
	return recompressBlob(file, 1280, .82);
}
async function recompressDataUrl(dataUrl, maxEdge, quality) {
	let current = await recompressBlob(await (await fetch(dataUrl)).blob(), maxEdge, quality);
	const steps = [
		[maxEdge, quality],
		[640, .62],
		[512, .5]
	];
	for (const [edge, q] of steps) {
		if (current.length <= 105e4) break;
		current = await recompressBlob(await (await fetch(current)).blob(), edge, q);
	}
	return current;
}
async function recompressBlob(blob, maxEdge, quality) {
	const bitmap = await createImageBitmap(blob);
	const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
	const width = Math.max(1, Math.round(bitmap.width * scale));
	const height = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) {
		bitmap.close();
		throw new Error("Browser tidak bisa memproses gambar.");
	}
	ctx.drawImage(bitmap, 0, 0, width, height);
	bitmap.close();
	const out = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", quality));
	if (!out) throw new Error("Gagal mengompres gambar.");
	return blobToDataUrl(out);
}
function isAllowedImage(file) {
	if ([
		"image/jpeg",
		"image/png",
		"image/webp"
	].includes(file.type)) return true;
	return /\.(jpe?g|png|webp)$/i.test(file.name);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ASPECTS = [
	"1:1",
	"4:5",
	"9:16",
	"16:9"
];
object({
	category: string().max(80),
	customCategory: string().max(200),
	campaign: string().max(80),
	customCampaign: string().max(200),
	story: string().max(2e3),
	sceneCount: number().int().min(3).max(10),
	style: string().max(80),
	customStyle: string().max(500),
	aspect: _enum(ASPECTS),
	consistencyLock: boolean(),
	images: array(string().min(30).max(12e5)).min(1).max(4)
});
object({
	prompt: string().min(20).max(8e3),
	aspect: _enum(ASPECTS),
	images: array(string().min(30).max(12e5)).min(1).max(4),
	profile: string().max(4e3),
	consistencyLock: boolean()
});
var analyzeProduct = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("8e2ffb7a3302c24253f53288a6d4b2e15263d91209b4b159d694d7fe014fa36d"));
var generateSceneImage = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("27c91c00a7dfeafbfd538a57203c2b2a0ff00bd536c1a258fd1a46787beb67f7"));
var queue = Promise.resolve();
var fullRuns = /* @__PURE__ */ new Set();
function enqueue(task) {
	queue = queue.then(task, task);
	return queue;
}
function latest(id) {
	return useStory.getState().projects.find((project) => project.id === id);
}
function runFullGenerate(projectId) {
	const project = latest(projectId);
	if (!project || project.refs.length === 0) return;
	if (fullRuns.has(projectId) || project.phase === "planning" || project.phase === "generating") return;
	fullRuns.add(projectId);
	useStory.getState().patch(projectId, (current) => ({
		...current,
		phase: "planning",
		statusNote: "Menganalisis foto produk dan menyusun scene.",
		planError: null
	}), true);
	return enqueue(async () => {
		try {
			await planAndRender(projectId);
		} finally {
			fullRuns.delete(projectId);
			const done = latest(projectId);
			if (!done) return;
			if (!done.scenes.some((scene) => scene.status === "generating" || scene.status === "queued")) useStory.getState().patch(projectId, (current) => ({
				...current,
				phase: "ready",
				statusNote: ""
			}), true);
		}
	});
}
async function planAndRender(projectId) {
	const project = latest(projectId);
	if (!project || project.refs.length === 0) return;
	const refs = pickEven(project.refs, 4);
	let images = [];
	try {
		images = await Promise.all(refs.map((ref) => recompressDataUrl(ref.dataUrl, 640, .62)));
	} catch {
		useStory.getState().patch(projectId, (current) => ({
			...current,
			phase: "draft",
			statusNote: "",
			planError: "Foto referensi tidak bisa diproses. Coba unggah ulang."
		}), true);
		return;
	}
	const planned = await analyzeProduct({ data: {
		category: project.category,
		customCategory: project.customCategory,
		campaign: project.campaign,
		customCampaign: project.customCampaign,
		story: project.story,
		sceneCount: project.sceneCount,
		style: project.style,
		customStyle: project.customStyle,
		aspect: project.aspect,
		consistencyLock: project.consistencyLock,
		images
	} });
	const fresh = latest(projectId);
	if (!fresh) return;
	const remote = "scenes" in planned && Array.isArray(planned.scenes) ? planned.scenes : [];
	const beats = remote.length ? remote : localBeats(fresh);
	const withProfile = {
		...fresh,
		profile: planned.ok && planned.profile ? planned.profile : fresh.profile || "The uploaded reference photos are one single product seen from different angles. Identity comes only from those photos: shape, proportions, color, material, texture, logo, printed text, pattern, part count, drawers, handles, knobs, lids, and opening mechanism. Do not invent parts that are not visible.",
		productName: planned.ok && planned.productName ? planned.productName : fresh.productName,
		planError: planned.ok ? planned.note || null : planned.error
	};
	if (planned.ok && planned.productName && (fresh.name === "Storyboard baru" || !fresh.name.trim())) withProfile.name = planned.productName;
	const built = scenesFromBeats(withProfile, beats).map((scene) => ({
		...scene,
		id: crypto.randomUUID(),
		imageDataUrl: null,
		status: "queued",
		error: null
	}));
	useStory.getState().patch(projectId, () => ({
		...withProfile,
		scenes: built,
		phase: "generating",
		statusNote: `Membuat gambar 1/${built.length}.`
	}), true);
	for (let index = 0; index < built.length; index++) await generateSceneNow(projectId, built[index].id, index, built.length);
}
function runSceneGenerate(projectId, sceneId) {
	return enqueue(async () => {
		await generateSceneNow(projectId, sceneId);
		const done = latest(projectId);
		if (!done) return;
		if (!done.scenes.some((scene) => scene.status === "generating" || scene.status === "queued") && !fullRuns.has(projectId)) useStory.getState().patch(projectId, (current) => ({
			...current,
			phase: "ready",
			statusNote: ""
		}), true);
	});
}
async function generateSceneNow(projectId, sceneId, index, total) {
	const project = latest(projectId);
	const scene = project?.scenes.find((item) => item.id === sceneId);
	if (!project || !scene || project.refs.length === 0) return;
	useStory.getState().patch(projectId, (current) => ({
		...mapScene(current, sceneId, (item) => ({
			...item,
			status: "generating",
			error: null
		})),
		phase: "generating",
		statusNote: typeof index === "number" && total ? `Membuat gambar ${index + 1}/${total}.` : "Membuat ulang satu scene."
	}), true);
	try {
		const refs = await Promise.all(pickEven(project.refs, 3).map((ref) => recompressDataUrl(ref.dataUrl, 768, .68)));
		const result = await generateSceneImage({ data: {
			prompt: (latest(projectId)?.scenes.find((item) => item.id === sceneId) ?? scene).imagePrompt,
			aspect: project.aspect,
			images: refs,
			profile: latest(projectId)?.profile ?? project.profile,
			consistencyLock: project.consistencyLock
		} });
		useStory.getState().patch(projectId, (current) => mapScene(current, sceneId, (item) => result.ok ? {
			...item,
			status: "done",
			imageDataUrl: result.dataUrl,
			error: null
		} : {
			...item,
			status: "error",
			error: result.error
		}), true);
	} catch (error) {
		const message = error instanceof Error ? error.message : "Gagal membuat scene.";
		useStory.getState().patch(projectId, (current) => mapScene(current, sceneId, (item) => ({
			...item,
			status: "error",
			error: message
		})), true);
	}
}
function Editor({ project }) {
	const patch = useStory((state) => state.patch);
	const remove = useStory((state) => state.remove);
	const inputRef = (0, import_react.useRef)(null);
	const [uploadError, setUploadError] = (0, import_react.useState)(null);
	const navigate = useNavigate();
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [confirmAll, setConfirmAll] = (0, import_react.useState)(false);
	const [dragIndex, setDragIndex] = (0, import_react.useState)(null);
	const busy = project.phase === "planning" || project.phase === "generating";
	const hasImages = project.scenes.some((scene) => scene.imageDataUrl);
	function update(recipe, flush = false) {
		patch(project.id, recipe, flush);
	}
	async function addFiles(list) {
		const files = Array.from(list);
		const room = 10 - project.refs.length;
		if (room <= 0) {
			setUploadError("Maksimal 10 foto.");
			return;
		}
		const accepted = files.filter(isAllowedImage).slice(0, room);
		if (!accepted.length) {
			setUploadError("Hanya JPG, PNG, atau WEBP.");
			return;
		}
		if (accepted.length < files.length) setUploadError("Sebagian file dilewati. Hanya JPG, PNG, WEBP, maksimal 10.");
		else setUploadError(null);
		try {
			const next = [];
			for (const file of accepted) {
				if (file.size > 2e7) continue;
				const dataUrl = await fileToStoredImage(file);
				next.push({
					id: crypto.randomUUID(),
					name: file.name,
					dataUrl
				});
			}
			update((current) => ({
				...current,
				refs: [...current.refs, ...next].slice(0, 10)
			}), true);
		} catch {
			setUploadError("Foto tidak bisa dibaca.");
		}
	}
	function move(from, to) {
		if (to < 0 || to >= project.refs.length || from === to) return;
		update((current) => {
			const refs = current.refs.slice();
			const [item] = refs.splice(from, 1);
			if (!item) return current;
			refs.splice(to, 0, item);
			return {
				...current,
				refs
			};
		}, true);
	}
	function saveDraft(sceneId, draft) {
		update((current) => {
			const scenes = current.scenes.map((scene) => {
				if (scene.id !== sceneId) return scene;
				const blob = `${draft.humanInteraction} ${draft.description}`.toLowerCase();
				let motion = scene.motion;
				if (/drawer/.test(blob)) motion = "A hand opens one existing drawer slightly, once. The product stays rigid.";
				else if (/lid|flap|tutup/.test(blob)) motion = "A hand lifts the existing lid slowly once. The product stays rigid.";
				else if (/no person|product alone|no hand/.test(blob)) motion = "slow camera push-in, background stable";
				else if (/hand|touch|finger/.test(blob)) motion = "one simple hand movement, product geometry frozen";
				return rebuildScenePrompts(current, {
					...scene,
					...draft,
					motion
				});
			});
			return {
				...current,
				scenes
			};
		}, true);
	}
	function savePrompt(sceneId, imagePrompt) {
		update((current) => ({
			...current,
			scenes: current.scenes.map((scene) => scene.id === sceneId ? {
				...scene,
				imagePrompt
			} : scene)
		}), true);
	}
	const countDiffers = project.scenes.length > 0 && project.scenes.length !== project.sceneCount;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted uppercase",
					children: "Create storyboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					"aria-label": "Nama storyboard",
					value: project.name,
					onChange: (event) => update((current) => ({
						...current,
						name: event.target.value
					})),
					className: "font-display text-2xl font-medium"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 rounded-xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-medium tracking-tight",
					children: "Product reference"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "1–10 foto. Semua dianggap satu produk yang sama: depan, samping, belakang, atau saat terbuka."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 rounded-lg border border-dashed border-line bg-bg p-4",
					onDragOver: (event) => event.preventDefault(),
					onDrop: (event) => {
						event.preventDefault();
						if (event.dataTransfer.files.length) addFiles(event.dataTransfer.files);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: inputRef,
							type: "file",
							accept: "image/jpeg,image/png,image/webp",
							multiple: true,
							className: "sr-only",
							onChange: (event) => {
								if (event.target.files) addFiles(event.target.files);
								event.target.value = "";
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => inputRef.current?.click(),
							disabled: project.refs.length >= 10,
							children: "Tambah foto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [project.refs.length, " / 10 · JPG, PNG, WEBP"]
						}),
						uploadError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-danger",
							children: uploadError
						}) : null,
						project.refs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
							children: project.refs.map((ref, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "overflow-hidden rounded-md border border-line bg-surface",
								draggable: true,
								onDragStart: () => setDragIndex(index),
								onDragOver: (event) => event.preventDefault(),
								onDrop: () => {
									if (dragIndex !== null) move(dragIndex, index);
									setDragIndex(null);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "frame-1-1 bg-bg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: ref.dataUrl,
										alt: "",
										className: "h-full w-full object-contain"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-1 p-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-1 text-xs tabular-nums text-muted",
										children: index + 1
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center",
												"aria-label": "Pindah ke kiri",
												onClick: () => move(index, index - 1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center",
												"aria-label": "Pindah ke kanan",
												onClick: () => move(index, index + 1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center",
												"aria-label": "Hapus foto",
												onClick: () => update((current) => ({
													...current,
													refs: current.refs.filter((item) => item.id !== ref.id)
												}), true),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
											})
										]
									})]
								})]
							}, ref.id))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Tarik foto ke sini atau tambah dari galeri."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-medium tracking-tight",
						children: "Product & story"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Kunci produk menyala supaya bentuknya tidak berubah antar-scene."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-11 items-center justify-between gap-4 rounded-md border border-line bg-bg px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Product consistency lock"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Default aktif. Hanya background, cahaya, kamera, properti, dan interaksi yang berubah."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: project.consistencyLock,
							onCheckedChange: (checked) => update((current) => ({
								...current,
								consistencyLock: checked
							})),
							"aria-label": "Product consistency lock",
							className: "relative h-7 w-12 shrink-0 rounded-full bg-faint data-[state=checked]:bg-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-5 translate-x-1 rounded-full bg-surface transition-transform duration-150 data-[state=checked]:translate-x-6" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Product category",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: project.category,
							onChange: (event) => update((current) => ({
								...current,
								category: event.target.value
							})),
							children: CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					project.category === "Custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Describe your product",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: project.customCategory,
							onChange: (event) => update((current) => ({
								...current,
								customCategory: event.target.value
							})),
							placeholder: "Hardbox pohon Natal, dua laci"
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Campaign / occasion",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: project.campaign,
							onChange: (event) => update((current) => ({
								...current,
								campaign: event.target.value
							})),
							children: CAMPAIGNS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					project.campaign === "Custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Describe the occasion",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: project.customCampaign,
							onChange: (event) => update((current) => ({
								...current,
								customCampaign: event.target.value
							}))
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What story do you want?",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
							value: project.story,
							maxLength: 2e3,
							placeholder: "Buat cerita tentang hardbox sebagai hadiah Natal yang elegan dan berkesan.",
							onChange: (event) => update((current) => ({
								...current,
								story: event.target.value
							}))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-medium",
							children: "Number of scenes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: SCENE_COUNTS.map((count) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => update((current) => ({
									...current,
									sceneCount: count
								})),
								className: `inline-flex size-11 items-center justify-center rounded-md text-sm font-medium ${project.sceneCount === count ? "bg-accent text-accent-fg" : "border border-line bg-bg"}`,
								children: count
							}, count))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Photography style",
						hint: project.style === "Natural Smartphone" ? "Terlihat seperti foto smartphone: cahaya natural, grain halus, tidak seperti render." : void 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: project.style,
							onChange: (event) => update((current) => ({
								...current,
								style: event.target.value
							})),
							children: STYLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					project.style === "Custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Describe the photo style",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
							value: project.customStyle,
							onChange: (event) => update((current) => ({
								...current,
								customStyle: event.target.value
							}))
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Aspect ratio",
						hint: "Berlaku untuk semua scene. Tidak ada pilihan resolusi.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: project.aspect,
							onChange: (event) => update((current) => ({
								...current,
								aspect: event.target.value
							})),
							children: [
								"1:1",
								"4:5",
								"9:16",
								"16:9"
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "min-h-14 w-full text-base",
						disabled: busy || project.refs.length === 0,
						onClick: () => {
							if (hasImages && !confirmAll) {
								setConfirmAll(true);
								return;
							}
							setConfirmAll(false);
							runFullGenerate(project.id);
						},
						children: busy ? project.statusNote || "Menyusun storyboard" : confirmAll ? "Buat ulang semua scene" : "Generate storyboard"
					}),
					project.refs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Upload minimal satu foto produk."
					}) : null,
					confirmAll ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm text-muted underline",
						onClick: () => setConfirmAll(false),
						children: "Batalkan"
					}) : null,
					countDiffers ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Form memakai ",
							project.sceneCount,
							" scene, storyboard saat ini ",
							project.scenes.length,
							". Generate akan menyusun ulang semuanya."
						]
					}) : null,
					project.planError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: project.planError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Satu storyboard membuat satu gambar untuk setiap scene. Foto referensi ikut terkirim saat generate."
					})
				]
			}),
			project.profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-2 rounded-xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium tracking-widest text-muted uppercase",
					children: "Product consistency profile"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm whitespace-pre-wrap",
					children: project.profile
				})]
			}) : null,
			project.scenes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-medium tracking-tight",
						children: "Your storyboard"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/storyboards/$id/preview",
								params: { id: project.id },
								className: "inline-flex min-h-11 items-center rounded-md border border-line bg-surface px-4 text-sm font-medium",
								children: "Storyboard preview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								disabled: !hasImages,
								onClick: () => void downloadScenesZip(project.scenes, `${slug(project.name)}.zip`),
								children: "Download all"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => {
									if (!confirmDelete) {
										setConfirmDelete(true);
										return;
									}
									remove(project.id);
									navigate({ to: "/storyboards" });
								},
								children: confirmDelete ? "Ya, hapus" : "Hapus"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: project.scenes.map((scene, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneCard, {
						index,
						scene,
						aspect: project.aspect,
						busy: busy || scene.status === "generating",
						onPrompt: savePrompt,
						onGenerate: (id) => {
							runSceneGenerate(project.id, id);
						},
						onSaveDraft: saveDraft
					}, scene.id))
				})]
			}) : null
		]
	});
}
function slug(name) {
	return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "storyboard";
}
function ProjectPage() {
	const { id } = Route$1.useParams();
	const ready = useProjects();
	const project = useStory((state) => state.projects.find((item) => item.id === id));
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Memuat storyboard…"
	});
	if (!project) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Storyboard ini tidak ada." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/storyboards",
			className: "text-sm font-medium underline",
			children: "My storyboards"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, { project });
}
//#endregion
export { ProjectPage as component };
