//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BU6uuIs9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DavJnMQQ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DavJnMQQ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B9W8b37y.js"]
	}
} });
//#endregion
export { tsrStartManifest };
