//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BnRFeIYu.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CIwuUsGP.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CIwuUsGP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-czS1SCjw.js"]
	}
} });
//#endregion
export { tsrStartManifest };
