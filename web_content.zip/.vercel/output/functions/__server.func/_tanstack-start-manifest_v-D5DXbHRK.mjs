//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D5DXbHRK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Bj4q2PUK.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bj4q2PUK.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CZ-8z6Rc.js"]
	}
} });
//#endregion
export { tsrStartManifest };
