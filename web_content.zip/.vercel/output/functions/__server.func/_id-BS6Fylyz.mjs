import { P as require_jsx_runtime } from "./_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { o as getStudent, t as Skeleton } from "./_ssr/server-BRpT2GPU.mjs";
import { g as ArrowRight, s as Printer } from "./_libs/lucide-react.mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { r as Route$2 } from "./_ssr/router-C2NnLxPF.mjs";
import { t as Button } from "./_ssr/button-C0qE0jyX.mjs";
import { t as CertificateDoc } from "./_ssr/certificate-doc-BBvbW0tk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-BS6Fylyz.js
var import_jsx_runtime = require_jsx_runtime();
function CertificatePage() {
	const { id } = Route$2.useParams();
	const studentId = Number(id);
	const studentQuery = useQuery({
		queryKey: ["student", studentId],
		queryFn: () => getStudent({ data: { id: studentId } }),
		enabled: Number.isFinite(studentId)
	});
	const student = studentQuery.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg px-4 py-6 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mx-auto mb-6 flex max-w-[210mm] flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/students/$id",
					params: { id },
					className: "inline-flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" }), "ملف المترشح"]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => window.print(),
				disabled: !student?.certificateNumber,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "طباعة الشهادة"]
			})]
		}), studentQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mx-auto h-[280mm] max-w-[210mm] rounded-lg" }) : !student ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-center text-sm text-muted",
			children: "المترشح غير موجود."
		}) : student.decision !== "ناجح" || !student.certificateNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-center text-sm text-muted",
			children: "لا توجد شهادة صادرة لهذا الملف. أصدر الشهادة من صفحة المترشح بعد النجاح."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CertificateDoc, { student })]
	});
}
//#endregion
export { CertificatePage as component };
