//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-FWuQp0e6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/_app",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-D5Ax8C2E.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-C2gEKO8B.js",
			"/assets/link-tc0J8fvp.js",
			"/assets/jsx-runtime-BtH0gOTJ.js",
			"/assets/useRouter-DTQ3YH1D.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D5Ax8C2E.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-UbmSO4QZ.js", "/assets/splash-DZepagh8.js"]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/accounts",
			"/_app/audit",
			"/_app/checks",
			"/_app/close-day",
			"/_app/crm",
			"/_app/dashboard",
			"/_app/health",
			"/_app/journals",
			"/_app/kpi",
			"/_app/liquidity",
			"/_app/operations",
			"/_app/parties",
			"/_app/reports",
			"/_app/settings"
		],
		preloads: [
			"/assets/_app-DITuZmuq.js",
			"/assets/use-books-Ddcw8M0S.js",
			"/assets/client-bLCk0icn.js",
			"/assets/utils-DOQQTBMN.js",
			"/assets/splash-DZepagh8.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CDG1cdPk.js",
			"/assets/client-bLCk0icn.js",
			"/assets/splash-DZepagh8.js",
			"/assets/button-DWMP03-w.js",
			"/assets/input-DDJ-G7uh.js"
		]
	},
	"/_app/accounts": {
		filePath: "/workspace/src/routes/_app/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CtgZVnXb.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/button-DWMP03-w.js",
			"/assets/input-DDJ-G7uh.js"
		]
	},
	"/_app/audit": {
		filePath: "/workspace/src/routes/_app/audit.tsx",
		children: void 0,
		preloads: ["/assets/audit-B9oP16UL.js", "/assets/card-D3Y4CuiD.js"]
	},
	"/_app/checks": {
		filePath: "/workspace/src/routes/_app/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-CKHt4T8u.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/button-DWMP03-w.js"
		]
	},
	"/_app/close-day": {
		filePath: "/workspace/src/routes/_app/close-day.tsx",
		children: void 0,
		preloads: [
			"/assets/close-day-1mzTJqy0.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/button-DWMP03-w.js",
			"/assets/input-DDJ-G7uh.js",
			"/assets/export-BvTymIpn.js"
		]
	},
	"/_app/crm": {
		filePath: "/workspace/src/routes/_app/crm.tsx",
		children: void 0,
		preloads: ["/assets/crm-BLcrLQXr.js", "/assets/card-D3Y4CuiD.js"]
	},
	"/_app/dashboard": {
		filePath: "/workspace/src/routes/_app/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-Uk9Wa3yY.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/generateCategoricalChart-BBJGi9Wg.js"
		]
	},
	"/_app/health": {
		filePath: "/workspace/src/routes/_app/health.tsx",
		children: void 0,
		preloads: ["/assets/health-D-gl4V6v.js", "/assets/card-D3Y4CuiD.js"]
	},
	"/_app/journals": {
		filePath: "/workspace/src/routes/_app/journals.tsx",
		children: void 0,
		preloads: ["/assets/journals-B7SmEaRZ.js", "/assets/card-D3Y4CuiD.js"]
	},
	"/_app/kpi": {
		filePath: "/workspace/src/routes/_app/kpi.tsx",
		children: void 0,
		preloads: [
			"/assets/kpi-ClU1UdYr.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/generateCategoricalChart-BBJGi9Wg.js"
		]
	},
	"/_app/liquidity": {
		filePath: "/workspace/src/routes/_app/liquidity.tsx",
		children: void 0,
		preloads: ["/assets/liquidity-SpFhygOl.js", "/assets/card-D3Y4CuiD.js"]
	},
	"/_app/operations": {
		filePath: "/workspace/src/routes/_app/operations.tsx",
		children: ["/_app/operations/new"],
		preloads: [
			"/assets/operations-DKc6t7_V.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/button-DWMP03-w.js",
			"/assets/input-DDJ-G7uh.js"
		]
	},
	"/_app/parties": {
		filePath: "/workspace/src/routes/_app/parties.tsx",
		children: void 0,
		preloads: [
			"/assets/parties-Caf5YVv0.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/button-DWMP03-w.js",
			"/assets/input-DDJ-G7uh.js"
		]
	},
	"/_app/reports": {
		filePath: "/workspace/src/routes/_app/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BQ2cN_2M.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/button-DWMP03-w.js",
			"/assets/input-DDJ-G7uh.js",
			"/assets/export-BvTymIpn.js"
		]
	},
	"/_app/settings": {
		filePath: "/workspace/src/routes/_app/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BN62lRaI.js",
			"/assets/card-D3Y4CuiD.js",
			"/assets/button-DWMP03-w.js",
			"/assets/export-BvTymIpn.js"
		]
	},
	"/_app/operations/new": {
		filePath: "/workspace/src/routes/_app/operations.new.tsx",
		children: void 0,
		preloads: ["/assets/operations.new-DDwWVwPC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
