//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BA9pousq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-ClaVViKB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ClaVViKB.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D5EArB2z.js"]
	}
} });
//#endregion
export { tsrStartManifest };
