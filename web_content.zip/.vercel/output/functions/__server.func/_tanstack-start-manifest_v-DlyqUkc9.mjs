//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DlyqUkc9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-5oEr_9Ic.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-5oEr_9Ic.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Ca8CbZGc.js"]
	}
} });
//#endregion
export { tsrStartManifest };
