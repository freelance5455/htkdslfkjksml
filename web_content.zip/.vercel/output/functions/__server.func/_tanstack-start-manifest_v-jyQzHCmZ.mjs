//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-jyQzHCmZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BN5-z1JF.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BN5-z1JF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CifW21Uy.js"]
	}
} });
//#endregion
export { tsrStartManifest };
