import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as formatWhen, o as formatAud, p as useVault, u as parseAud } from "./_ssr/vault-store-CwqfT6q8.mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { i as TrendingUp, o as Plus } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { a as Input, i as CardTitle, n as Card, o as Label, t as Button } from "./_ssr/label-DOshPwvi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.index-LkfbV-Ld.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SOURCES = [
	"Sale",
	"Gig",
	"Affiliate",
	"Invoice",
	"Tip"
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogEarningForm, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentEarnings, {})]
	});
}
function LogEarningForm() {
	const addEarning = useVault((s) => s.addEarning);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [source, setSource] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	function onSubmit(event) {
		event.preventDefault();
		const parsed = parseAud(amount);
		if (parsed === null) {
			setError("Enter an amount greater than 0.");
			return;
		}
		if (!source.trim()) {
			setError("Add a source so you can recognise this later.");
			return;
		}
		addEarning({
			amountAud: parsed,
			source,
			note
		});
		setAmount("");
		setSource("");
		setNote("");
		setError(null);
		toast.success(`${formatAud(parsed)} logged`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "rise-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-5",
						strokeWidth: 2
					}), "Log an earning"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "amount",
						children: "Amount (AUD)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "amount",
						inputMode: "decimal",
						autoComplete: "off",
						placeholder: "0.00",
						value: amount,
						onChange: (e) => {
							setAmount(e.target.value);
							setError(null);
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "source",
							children: "Source"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "source",
							placeholder: "e.g. Sale, Gig, Affiliate",
							value: source,
							onChange: (e) => {
								setSource(e.target.value);
								setError(null);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5 pt-1",
							children: SOURCES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setSource(item);
									setError(null);
								},
								className: cn("h-8 rounded-full px-3 text-xs font-medium transition-colors duration-150", source === item ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-accent"),
								children: item
							}, item))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "note",
						children: "Note (optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "note",
						placeholder: "Details about this earning",
						value: note,
						onChange: (e) => setNote(e.target.value)
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-destructive",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "h-12 w-full text-base",
					children: "Add earning"
				})
			]
		})
	});
}
function RecentEarnings() {
	const earnings = useVault((s) => s.earnings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "rise-in rise-in-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
			className: "mb-4 flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, {
				className: "size-5",
				strokeWidth: 2
			}), "Recent earnings"]
		}), earnings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Nothing logged yet. Add your first earning above and it will show up here."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-border",
			children: earnings.slice(0, 12).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start justify-between gap-4 py-3 first:pt-0 last:pb-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium",
							children: row.source
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: formatWhen(row.createdAt)
						}),
						row.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 truncate text-sm text-muted-foreground",
							children: row.note
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shrink-0 font-medium tabular-nums text-success",
					children: formatAud(row.amountAud, { sign: true })
				})]
			}, row.id))
		})]
	});
}
//#endregion
export { Home as component };
