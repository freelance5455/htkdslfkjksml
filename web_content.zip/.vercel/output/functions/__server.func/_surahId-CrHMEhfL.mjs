import { i as __toESM } from "./_runtime.mjs";
import { B as require_react, x as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { C as Bookmark, S as ChevronLeft, _ as Heart, b as Download, d as Plus, f as Play, h as Minus, n as Type, p as Pause, s as Share2, u as Repeat, x as ChevronRight } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { n as Route$1 } from "./_ssr/router-CYk49Uxf.mjs";
import { t as BackButton } from "./_ssr/back-button-DImimZOp.mjs";
import { a as cn, i as audioEngine, l as toArabicDigits, o as downloadSurahAyahs, s as getReciter, t as AppShell, u as useAppStore } from "./_ssr/app-shell-C4IrQdCN.mjs";
import { c as loadSurah, l as loadTafsir, u as quranMeta } from "./_ssr/catalog-CjAfWU9w.mjs";
import { t as shareText } from "./_ssr/share-B1roieal.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_surahId-CrHMEhfL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Reader() {
	const { surahId: raw } = Route$1.useParams();
	const { ayah: startAyah } = Route$1.useSearch();
	const surahId = Number(raw);
	const meta = quranMeta.surahs.find((s) => s.id === surahId);
	const [surah, setSurah] = (0, import_react.useState)(null);
	const [active, setActive] = (0, import_react.useState)(null);
	const [tafsir, setTafsir] = (0, import_react.useState)(null);
	const [showTafsir, setShowTafsir] = (0, import_react.useState)(false);
	const [repeat, setRepeat] = (0, import_react.useState)(1);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const scale = useAppStore((s) => s.settings.quranScale);
	const setScale = useAppStore((s) => s.setQuranScale);
	const reciterId = useAppStore((s) => s.settings.reciterId);
	const setLast = useAppStore((s) => s.setLastReading);
	const toggleFavorite = useAppStore((s) => s.toggleFavorite);
	const favorites = useAppStore((s) => s.favorites);
	const addBookmark = useAppStore((s) => s.addBookmark);
	const markDownloaded = useAppStore((s) => s.markDownloaded);
	const downloaded = useAppStore((s) => s.downloadedSurahs);
	const [playingAyah, setPlayingAyah] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		setSurah(null);
		setActive(null);
		setTafsir(null);
		setShowTafsir(false);
		loadSurah(surahId).then((s) => {
			if (!live || !s) return;
			setSurah(s);
			const a = s.ayahs.find((x) => x.n === startAyah) ?? s.ayahs[0];
			setLast({
				surahId: s.id,
				ayah: a.n,
				updatedAt: Date.now()
			});
		});
		return () => {
			live = false;
		};
	}, [
		surahId,
		startAyah,
		setLast
	]);
	(0, import_react.useEffect)(() => {
		if (!surah || !startAyah) return;
		const t = window.setTimeout(() => {
			document.getElementById(`ayah-${startAyah}`)?.scrollIntoView({ block: "center" });
		}, 80);
		return () => window.clearTimeout(t);
	}, [surah, startAyah]);
	(0, import_react.useEffect)(() => audioEngine.subscribe((st) => setPlayingAyah(st.ayah)), []);
	const tafsirFor = (0, import_react.useMemo)(() => {
		if (!active || !tafsir) return "";
		return tafsir.find((t) => t.n === active.n)?.t ?? "";
	}, [active, tafsir]);
	if (!meta) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-8 text-center",
		children: "السورة غير موجودة"
	}) });
	async function openTafsir(a) {
		setActive(a);
		setShowTafsir(true);
		if (tafsir) return;
		try {
			setTafsir(await loadTafsir(surahId));
		} catch {
			toast("تعذر تحميل التفسير. يلزم الاتصال أول مرة ثم يُحفظ.");
		}
	}
	async function play(a, cont = false) {
		if (!surah) return;
		setLast({
			surahId: surah.id,
			ayah: a.n,
			updatedAt: Date.now()
		});
		await audioEngine.playAyah({
			surahId: surah.id,
			ayah: a.n,
			global: a.g,
			title: surah.name,
			reciterId,
			repeat,
			continueSurah: cont ? surah : null
		});
	}
	async function download() {
		if (!surah) return;
		setBusy(true);
		try {
			const n = await downloadSurahAyahs(getReciter(reciterId), surah);
			markDownloaded(surah.id);
			toast(n ? `تم حفظ ${toArabicDigits(n)} مقطعًا للتلاوة دون اتصال` : "تعذر التنزيل الآن");
		} finally {
			setBusy(false);
		}
	}
	const favId = active ? `ayah:${surahId}:${active.n}` : "";
	const isFav = favorites.some((f) => f.id === favId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-20 border-b border-border bg-paper/95 backdrop-blur-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1 px-1 py-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/quran" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate font-quran text-lg",
							children: meta.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-muted-foreground",
							children: [
								meta.type,
								" · ",
								toArabicDigits(meta.count),
								" آية"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "tap-lg size-10 text-muted-foreground",
								onClick: () => setScale(Math.max(.9, Number((scale - .1).toFixed(2)))),
								"aria-label": "تصغير الخط",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "mx-auto size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Type, { className: "size-4 text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "tap-lg size-10 text-muted-foreground",
								onClick: () => setScale(Math.min(1.8, Number((scale + .1).toFixed(2)))),
								"aria-label": "تكبير الخط",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mx-auto size-4" })
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-3 pb-2 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quran/$surahId",
						params: { surahId: String(Math.max(1, surahId - 1)) },
						className: cn("flex items-center gap-1 py-1", surahId <= 1 && "pointer-events-none opacity-30"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" }), " السابقة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex items-center gap-1 py-1",
						onClick: () => void download(),
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), downloaded.includes(surahId) ? "مُنزّلة" : "تنزيل التلاوة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quran/$surahId",
						params: { surahId: String(Math.min(114, surahId + 1)) },
						className: cn("flex items-center gap-1 py-1", surahId >= 114 && "pointer-events-none opacity-30"),
						children: ["التالية ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "bg-paper px-4 py-6",
			children: [surahId !== 9 && surahId !== 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-6 text-center font-quran text-xl text-accent",
				children: "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"
			}) : null, !surah ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-16 text-center text-sm text-muted-foreground",
				children: "جارٍ فتح المصحف…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "quran-text text-ink",
				style: { fontSize: `${scale * 1.55}rem` },
				children: surah.ayahs.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					id: `ayah-${a.n}`,
					onClick: () => {
						setActive(a);
						setShowTafsir(false);
						setLast({
							surahId,
							ayah: a.n,
							updatedAt: Date.now()
						});
					},
					className: cn("cursor-pointer rounded-md px-0.5 transition-colors duration-[var(--motion-quick)]", active?.n === a.n && "bg-surface", playingAyah === a.n && "bg-muted"),
					children: [
						a.t,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-1 inline-flex size-[1.35em] translate-y-0.5 items-center justify-center rounded-full border border-sage/40 align-middle font-sans text-[0.55em] text-sage",
							children: toArabicDigits(a.n)
						}),
						a.sajda ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ms-1 align-middle text-[0.55em] text-sage",
							children: "سجدة"
						}) : null
					]
				}, a.n))
			})]
		}),
		active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sticky bottom-[calc(5.25rem+env(safe-area-inset-bottom))] z-20 mx-3 mb-2 rounded-2xl border border-border bg-card p-3 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							meta.shortName,
							" · ",
							toArabicDigits(active.n)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs text-muted-foreground",
						onClick: () => setActive(null),
						children: "إغلاق"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-5 gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
							label: playingAyah === active.n ? "إيقاف" : "استماع",
							icon: playingAyah === active.n ? Pause : Play,
							onClick: () => {
								if (playingAyah === active.n) audioEngine.toggle();
								else play(active, true);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
							label: `تكرار ${toArabicDigits(repeat)}`,
							icon: Repeat,
							onClick: () => setRepeat((r) => r >= 7 ? 1 : r + 1)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
							label: "تفسير",
							icon: Type,
							onClick: () => void openTafsir(active)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
							label: isFav ? "محفوظة" : "مفضلة",
							icon: Heart,
							onClick: () => toggleFavorite({
								id: favId,
								kind: "ayah",
								title: `${meta.name} ${toArabicDigits(active.n)}`,
								text: active.t,
								href: `/quran/${surahId}?ayah=${active.n}`,
								meta: meta.name
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
							label: "مشاركة",
							icon: Share2,
							onClick: () => void shareText(`${meta.name} ${toArabicDigits(active.n)}`, active.t)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "h-10 flex-1 rounded-xl bg-surface text-xs",
						onClick: () => addBookmark({
							id: `ayah:${surahId}:${active.n}`,
							label: `${meta.name} — آية ${toArabicDigits(active.n)}`,
							href: `/quran/${surahId}?ayah=${active.n}`
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "mx-auto mb-0.5 size-3.5" }), "علامة"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-10 flex-1 rounded-xl bg-accent text-xs text-accent-foreground",
						onClick: () => void play(active, false),
						children: "استماع للآية"
					})]
				}),
				showTafsir ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 max-h-40 overflow-y-auto border-t border-border pt-2 text-sm leading-7 text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-[11px] text-muted-foreground",
						children: "التفسير الميسر — مجمع الملك فهد"
					}), tafsirFor || "جارٍ التحميل…"]
				}) : null
			]
		}) : null
	] });
}
function Tool({ label, icon: Icon, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex flex-col items-center gap-1 rounded-xl py-2 text-[10px] text-muted-foreground hover:bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
//#endregion
export { Reader as component };
