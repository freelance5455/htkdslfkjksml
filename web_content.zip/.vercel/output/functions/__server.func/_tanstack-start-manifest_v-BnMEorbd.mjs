//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BnMEorbd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DjdjWJ0X.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DjdjWJ0X.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-yxDuc0BE.js"]
	}
} });
//#endregion
export { tsrStartManifest };
