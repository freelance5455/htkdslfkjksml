//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CcU_8rBE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-slFJcKyH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-slFJcKyH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CCKHU58l.js"]
	}
} });
//#endregion
export { tsrStartManifest };
