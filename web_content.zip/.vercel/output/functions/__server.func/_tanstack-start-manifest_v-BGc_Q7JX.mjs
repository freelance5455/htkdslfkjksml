//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BGc_Q7JX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BhLs503M.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BhLs503M.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CFtw5mmD.js"]
	}
} });
//#endregion
export { tsrStartManifest };
