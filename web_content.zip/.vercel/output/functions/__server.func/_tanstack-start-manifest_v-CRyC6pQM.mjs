//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CRyC6pQM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/ardania"],
		preloads: ["/assets/index-DWjg_7Ol.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DWjg_7Ol.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-gsGiXxFX.js"]
	}
} });
//#endregion
export { tsrStartManifest };
