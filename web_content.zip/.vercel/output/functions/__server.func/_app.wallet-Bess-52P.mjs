import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as connectBrowserWallet, l as hasBrowserWallet, m as validateAddress, n as NETWORK_BY_ID, p as useVault, r as TOKENS, t as NETWORKS } from "./_ssr/vault-store-CwqfT6q8.mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { d as Copy, f as Check, n as Wallet, s as PlugZap } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { a as Input, i as CardTitle, n as Card, o as Label, r as CardHint, t as Button } from "./_ssr/label-DOshPwvi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.wallet-Bess-52P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WalletPage() {
	const saved = useVault((s) => s.wallet);
	const setWallet = useVault((s) => s.setWallet);
	const [networkId, setNetworkId] = (0, import_react.useState)(saved?.network ?? "base");
	const [token, setToken] = (0, import_react.useState)(saved?.token ?? "USDC");
	const [address, setAddress] = (0, import_react.useState)(saved?.address ?? "");
	const [connected, setConnected] = (0, import_react.useState)(saved?.connected ?? false);
	const [error, setError] = (0, import_react.useState)(null);
	const [connecting, setConnecting] = (0, import_react.useState)(false);
	const network = NETWORK_BY_ID[networkId];
	const tokens = network.tokens;
	const addressError = (0, import_react.useMemo)(() => address.trim() ? validateAddress(address, network.addressType) : null, [address, network.addressType]);
	function pickNetwork(id) {
		const next = NETWORK_BY_ID[id];
		setNetworkId(id);
		setConnected(false);
		setError(null);
		if (!next.tokens.includes(token)) setToken(next.tokens[0] ?? "USDC");
	}
	async function onConnect() {
		setConnecting(true);
		setError(null);
		try {
			const next = await connectBrowserWallet(network.addressType);
			setAddress(next);
			setConnected(true);
			toast.success("Wallet connected");
		} catch (err) {
			setConnected(false);
			setError(err instanceof Error ? err.message : "Could not connect.");
		} finally {
			setConnecting(false);
		}
	}
	function onSubmit(event) {
		event.preventDefault();
		const message = validateAddress(address, network.addressType);
		if (message) {
			setError(message);
			return;
		}
		if (!network.tokens.includes(token)) {
			setError("Pick a token this network supports.");
			return;
		}
		setWallet({
			address: address.trim(),
			network: networkId,
			token,
			connected
		});
		setError(null);
		toast.success("Destination wallet saved");
	}
	async function copyAddress() {
		if (!saved) return;
		try {
			await navigator.clipboard.writeText(saved.address);
			toast.success("Address copied");
		} catch {
			toast.error("Could not copy");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise-in space-y-1 px-1 pt-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Destination wallet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Cash-outs convert AUD and send to this address on the network you choose."
				})]
			}),
			saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rise-in rise-in-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-5" }), "Saved wallet"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							NETWORK_BY_ID[saved.network].name,
							" · ",
							saved.token,
							saved.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 rounded-full bg-success/15 px-2 py-0.5 text-xs font-medium text-success",
								children: "Connected"
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void copyAddress(),
						className: "flex w-full items-center justify-between gap-3 rounded-2xl bg-secondary px-3 py-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs leading-relaxed break-all",
							children: saved.address
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4 shrink-0 text-muted-foreground" })]
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "rise-in rise-in-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: saved ? "Update wallet" : "Add a wallet" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
							className: "mt-1",
							children: "Pick a network, then paste an address or connect a browser wallet."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Network" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2",
								children: NETWORKS.map((item) => {
									const active = item.id === networkId;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => pickNetwork(item.id),
										className: cn("rounded-2xl px-3 py-3 text-left transition-colors duration-150", active ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-accent"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-medium",
											children: item.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("mt-0.5 block text-xs", active ? "text-primary-foreground/70" : "text-muted-foreground"),
											children: item.hint
										})]
									}, item.id);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Receive as" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1.5",
								children: tokens.map((id) => {
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setToken(id),
										className: cn("h-10 rounded-full px-4 text-sm font-medium transition-colors duration-150", id === token ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-accent"),
										children: TOKENS[id].name
									}, id);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "address",
									children: "Wallet address"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "address",
									spellCheck: false,
									autoCapitalize: "off",
									autoCorrect: "off",
									placeholder: network.addressType === "evm" ? "0x…" : network.addressType === "solana" ? "Solana address" : "bc1… or 1…",
									value: address,
									onChange: (e) => {
										setAddress(e.target.value);
										setConnected(false);
										setError(null);
									},
									className: "font-mono text-sm"
								}),
								addressError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-destructive",
									children: addressError
								}) : null
							]
						}),
						hasBrowserWallet(network.addressType) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							className: "h-12 w-full text-base",
							onClick: () => void onConnect(),
							disabled: connecting,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlugZap, { className: "size-4" }), connecting ? "Connecting…" : "Connect browser wallet"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "No browser wallet detected on this network. Paste your address to continue."
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							className: "h-12 w-full text-base",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Save wallet"]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { WalletPage as component };
