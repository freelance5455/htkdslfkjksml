//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-n1335tzo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CS2ZSkS6.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CS2ZSkS6.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DrmR6LEs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
