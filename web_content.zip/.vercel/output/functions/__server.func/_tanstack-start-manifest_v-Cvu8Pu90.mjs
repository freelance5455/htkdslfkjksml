//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cvu8Pu90.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-UjQjKkL2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-UjQjKkL2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CtPBLvUr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
