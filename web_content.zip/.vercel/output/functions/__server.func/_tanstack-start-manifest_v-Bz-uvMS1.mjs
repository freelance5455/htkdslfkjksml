//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bz-uvMS1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/labs",
			"/quiz",
			"/sky",
			"/lessons/$id"
		],
		preloads: [
			"/assets/index-Bm2IQIxg.js",
			"/assets/store-BarBtQ0M.js",
			"/assets/preload-helper-DlPvR8Dc.js",
			"/assets/link-C56IPoRw.js",
			"/assets/useMatch-6CjmX1ly.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bm2IQIxg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-ADb0NukI.js",
			"/assets/use-now-C6goldL7.js",
			"/assets/lessons-ChNSaJvy.js",
			"/assets/astro-BxX39SfT.js",
			"/assets/ui-shD-TR74.js"
		]
	},
	"/labs": {
		filePath: "/workspace/src/routes/labs.tsx",
		children: void 0,
		preloads: ["/assets/labs-4EeHF5za.js", "/assets/season-lab-Q4yjomX6.js"]
	},
	"/quiz": {
		filePath: "/workspace/src/routes/quiz.tsx",
		children: void 0,
		preloads: [
			"/assets/quiz-DCACKbfx.js",
			"/assets/lessons-ChNSaJvy.js",
			"/assets/ui-shD-TR74.js"
		]
	},
	"/sky": {
		filePath: "/workspace/src/routes/sky.tsx",
		children: void 0,
		preloads: [
			"/assets/sky-CErLq31V.js",
			"/assets/use-now-C6goldL7.js",
			"/assets/astro-BxX39SfT.js",
			"/assets/ui-shD-TR74.js",
			"/assets/moon-draw-C0yDsWzg.js"
		]
	},
	"/lessons/$id": {
		filePath: "/workspace/src/routes/lessons.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/lessons._id-BE1n26Ed.js",
			"/assets/lessons-ChNSaJvy.js",
			"/assets/ui-shD-TR74.js",
			"/assets/season-lab-Q4yjomX6.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
