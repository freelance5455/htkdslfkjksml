//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C1sFRyKh.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DRNeI10f.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DRNeI10f.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-EeTNovoC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
