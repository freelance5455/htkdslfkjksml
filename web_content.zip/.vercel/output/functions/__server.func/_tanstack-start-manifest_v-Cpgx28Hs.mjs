//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cpgx28Hs.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DGWW9ARI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DGWW9ARI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-tPnD7MrF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
