import { o as __toESM } from "./_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Route$2 } from "./_ssr/router-B6lWlm2d.mjs";
import { C as primaryBtn, _ as joinGroup, h as getMe, t as Avatar, v as leaveGroup, w as quietBtn, x as listGroupMembers } from "./_ssr/auth-screens-DZe0plYT.mjs";
import { i as useSalon, t as Shell$1 } from "./_ssr/shell-DSe4icyb.mjs";
import { n as useMeId, t as FeedView } from "./_ssr/use-me-id-BM_D2CRi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-dKyLONAq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GroupPage() {
	const { slug } = Route$2.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Room, { slug }) });
}
function Room({ slug }) {
	const meId = useMeId();
	const bump = useSalon((s) => s.bump);
	const openCompose = useSalon((s) => s.openCompose);
	const [group, setGroup] = (0, import_react.useState)(null);
	const [missing, setMissing] = (0, import_react.useState)(false);
	const [people, setPeople] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)(null);
	async function load() {
		const found = (await getMe()).groups.find((item) => item.slug === slug) ?? null;
		setGroup(found);
		setMissing(!found);
		if (found) {
			const members = await listGroupMembers({ data: { slug } });
			if (members.ok) setPeople(members.people);
		}
	}
	(0, import_react.useEffect)(() => {
		let live = true;
		load().catch((err) => {
			if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
		});
		return () => {
			live = false;
		};
	}, [slug]);
	async function enter() {
		const result = await joinGroup({ data: { slug } });
		if (!result.ok) {
			setError(result.error);
			return;
		}
		bump();
		await load();
	}
	async function leave() {
		const result = await leaveGroup({ data: { slug } });
		if (!result.ok) {
			setError(result.error);
			return;
		}
		bump();
		await load();
	}
	if (!meId) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/groups",
				className: "text-sm text-mute",
				children: "كل المجموعات"
			}),
			missing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-rose",
				children: "هذه المجموعة غير موجودة."
			}) : null,
			group ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rounded-3xl bg-paper p-5 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-rose",
						children: group.forced ? "معك دائماً" : group.joined ? "أنت داخلها" : "لست عضواً بعد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl leading-tight",
						children: group.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-mute",
						children: group.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs tabular-nums text-mute",
						children: [group.members, " عضو"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [group.joined ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: primaryBtn,
							onClick: () => openCompose({ group: group.slug }),
							children: "انشر هنا"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: primaryBtn,
							onClick: () => void enter(),
							children: "انضمام فوري"
						}), group.joined && !group.forced ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: quietBtn,
							onClick: () => void leave(),
							children: "مغادرة"
						}) : null]
					}),
					people.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex gap-3 overflow-x-auto pb-1",
						children: people.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "w-16 shrink-0 text-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/u/$username",
								params: { username: person.username },
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									src: person.avatar,
									name: person.username,
									className: "mx-auto size-11 text-sm"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block truncate text-xs",
									children: person.username
								})]
							})
						}, person.username))
					}) : null
				]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-rose",
				children: error
			}) : null,
			group ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedView, {
				meId,
				query: {
					surface: "group",
					slug
				},
				variant: "feed",
				emptyTitle: "الغرفة هادئة",
				emptyBody: "أول منشور هنا يظهر أيضاً في الساحة إن كان فضفضة أو مسابقة أو معلومة أو نشرة."
			}) : null
		]
	});
}
//#endregion
export { GroupPage as component };
