import { S as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route$1 } from "./_ssr/router-vGnb3CUz.mjs";
import { n as NyalaGate } from "./_ssr/nyala-gate-DLLoNCea.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_roomId-CtyE51HN.js
var import_jsx_runtime = require_jsx_runtime();
function RoomPage() {
	const { roomId } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NyalaGate, { roomId });
}
//#endregion
export { RoomPage as component };
