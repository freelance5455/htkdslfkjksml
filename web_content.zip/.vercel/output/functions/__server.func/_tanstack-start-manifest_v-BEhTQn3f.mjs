//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BEhTQn3f.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-v1hL19O0.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-v1hL19O0.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CksrLdQv.js"]
	}
} });
//#endregion
export { tsrStartManifest };
