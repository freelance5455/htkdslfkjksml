//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BDYRRVBU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/reels",
			"/search",
			"/subliminals",
			"/groups/$slug",
			"/u/$username",
			"/groups/",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-BeXuwEca.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-B7QlvLg0.js",
			"/assets/link-Dj6r2xcZ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BeXuwEca.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CqSLtxCI.js",
			"/assets/auth-screens-fVjOBDu9.js",
			"/assets/shell-CFyZNm_9.js",
			"/assets/use-me-id-BZvTAyo8.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-QY7_08Vd.js", "/assets/auth-screens-fVjOBDu9.js"]
	},
	"/reels": {
		filePath: "/workspace/src/routes/reels.tsx",
		children: void 0,
		preloads: [
			"/assets/reels-DyQMevPj.js",
			"/assets/auth-screens-fVjOBDu9.js",
			"/assets/shell-CFyZNm_9.js",
			"/assets/use-me-id-BZvTAyo8.js"
		]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-Dy0OQH_G.js",
			"/assets/auth-screens-fVjOBDu9.js",
			"/assets/shell-CFyZNm_9.js"
		]
	},
	"/subliminals": {
		filePath: "/workspace/src/routes/subliminals.tsx",
		children: void 0,
		preloads: [
			"/assets/subliminals-c3ZYnleP.js",
			"/assets/auth-screens-fVjOBDu9.js",
			"/assets/shell-CFyZNm_9.js",
			"/assets/use-me-id-BZvTAyo8.js"
		]
	},
	"/groups/$slug": {
		filePath: "/workspace/src/routes/groups/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-DTKcjocB.js",
			"/assets/auth-screens-fVjOBDu9.js",
			"/assets/shell-CFyZNm_9.js",
			"/assets/use-me-id-BZvTAyo8.js"
		]
	},
	"/u/$username": {
		filePath: "/workspace/src/routes/u/$username.tsx",
		children: void 0,
		preloads: [
			"/assets/_username-C5n8v7MS.js",
			"/assets/auth-screens-fVjOBDu9.js",
			"/assets/shell-CFyZNm_9.js",
			"/assets/use-me-id-BZvTAyo8.js"
		]
	},
	"/groups/": {
		filePath: "/workspace/src/routes/groups/index.tsx",
		children: void 0,
		preloads: [
			"/assets/groups-LpjfdrTS.js",
			"/assets/auth-screens-fVjOBDu9.js",
			"/assets/shell-CFyZNm_9.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
