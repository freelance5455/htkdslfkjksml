//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BCyVX_OM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-ClpOw8Ws.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ClpOw8Ws.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CZB44Tvo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
