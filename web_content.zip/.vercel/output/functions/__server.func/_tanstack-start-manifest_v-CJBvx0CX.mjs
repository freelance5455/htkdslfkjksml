//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CJBvx0CX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Dm866zEy.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dm866zEy.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-JkrxKu7C.js"]
	}
} });
//#endregion
export { tsrStartManifest };
