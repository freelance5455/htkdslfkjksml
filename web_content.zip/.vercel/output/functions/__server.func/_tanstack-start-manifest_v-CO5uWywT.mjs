//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CO5uWywT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/boost",
			"/clicker",
			"/games",
			"/settings",
			"/tools"
		],
		preloads: ["/assets/index-DU1AiZfQ.js", "/assets/clsx-BUpemhFi.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DU1AiZfQ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-A2WW_lI5.js",
			"/assets/refresh-measure-D67oAKLw.js",
			"/assets/session-clock-C42n9Zcj.js"
		]
	},
	"/boost": {
		filePath: "/workspace/src/routes/boost.tsx",
		children: void 0,
		preloads: [
			"/assets/boost-CEaIo6f8.js",
			"/assets/fps-tools-Dru53AOP.js",
			"/assets/refresh-measure-D67oAKLw.js"
		]
	},
	"/clicker": {
		filePath: "/workspace/src/routes/clicker.tsx",
		children: void 0,
		preloads: ["/assets/clicker-BV2VJ9M0.js"]
	},
	"/games": {
		filePath: "/workspace/src/routes/games.tsx",
		children: void 0,
		preloads: ["/assets/games-BmY7zps6.js"]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-DExw6vkM.js"]
	},
	"/tools": {
		filePath: "/workspace/src/routes/tools.tsx",
		children: void 0,
		preloads: [
			"/assets/tools-D5ICgaRH.js",
			"/assets/fps-tools-Dru53AOP.js",
			"/assets/refresh-measure-D67oAKLw.js",
			"/assets/session-clock-C42n9Zcj.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
