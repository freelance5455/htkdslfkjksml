//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C5fD5Iq1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/inbox",
			"/star/$slug"
		],
		preloads: ["/assets/index-DfVQBnnB.js", "/assets/idb-9EGZ5Lw6.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DfVQBnnB.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BUkoIbnK.js",
			"/assets/app-shell-Dn5hcmYr.js",
			"/assets/star-photo-CS1x8kB6.js"
		]
	},
	"/inbox": {
		filePath: "/workspace/src/routes/inbox.tsx",
		children: void 0,
		preloads: [
			"/assets/inbox-IPL3US4x.js",
			"/assets/media-viewer-BkyK67sb.js",
			"/assets/app-shell-Dn5hcmYr.js"
		]
	},
	"/star/$slug": {
		filePath: "/workspace/src/routes/star.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/star._slug-CQIy9hq3.js",
			"/assets/media-viewer-BkyK67sb.js",
			"/assets/app-shell-Dn5hcmYr.js",
			"/assets/star-photo-CS1x8kB6.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
