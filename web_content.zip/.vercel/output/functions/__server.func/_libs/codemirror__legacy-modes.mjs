//#region node_modules/@codemirror/legacy-modes/mode/clike.js
function Context$1(indented, column, type, info, align, prev) {
	this.indented = indented;
	this.column = column;
	this.type = type;
	this.info = info;
	this.align = align;
	this.prev = prev;
}
function pushContext$1(state, col, type, info) {
	var indent = state.indented;
	if (state.context && state.context.type == "statement" && type != "statement") indent = state.context.indented;
	return state.context = new Context$1(indent, col, type, info, null, state.context);
}
function popContext$1(state) {
	var t = state.context.type;
	if (t == ")" || t == "]" || t == "}") state.indented = state.context.indented;
	return state.context = state.context.prev;
}
function typeBefore(stream, state, pos) {
	if (state.prevToken == "variable" || state.prevToken == "type") return true;
	if (/\S(?:[^- ]>|[*\]])\s*$|\*$/.test(stream.string.slice(0, pos))) return true;
	if (state.typeAtEndOfLine && stream.column() == stream.indentation()) return true;
}
function isTopScope(context) {
	for (;;) {
		if (!context || context.type == "top") return true;
		if (context.type == "}" && context.prev.info != "namespace") return false;
		context = context.prev;
	}
}
function clike(parserConfig) {
	var statementIndentUnit = parserConfig.statementIndentUnit, dontAlignCalls = parserConfig.dontAlignCalls, keywords = parserConfig.keywords || {}, types = parserConfig.types || {}, builtin = parserConfig.builtin || {}, blockKeywords = parserConfig.blockKeywords || {}, defKeywords = parserConfig.defKeywords || {}, atoms = parserConfig.atoms || {}, hooks = parserConfig.hooks || {}, multiLineStrings = parserConfig.multiLineStrings, indentStatements = parserConfig.indentStatements !== false, indentSwitch = parserConfig.indentSwitch !== false, namespaceSeparator = parserConfig.namespaceSeparator, isPunctuationChar = parserConfig.isPunctuationChar || /[\[\]{}\(\),;\:\.]/, numberStart = parserConfig.numberStart || /[\d\.]/, number = parserConfig.number || /^(?:0x[a-f\d]+|0b[01]+|(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?)(u|ll?|l|f)?/i, isOperatorChar = parserConfig.isOperatorChar || /[+\-*&%=<>!?|\/]/, isIdentifierChar = parserConfig.isIdentifierChar || /[\w\$_\xa1-\uffff]/, isReservedIdentifier = parserConfig.isReservedIdentifier || false;
	var curPunc, isDefKeyword;
	function tokenBase(stream, state) {
		var ch = stream.next();
		if (hooks[ch]) {
			var result = hooks[ch](stream, state);
			if (result !== false) return result;
		}
		if (ch == "\"" || ch == "'") {
			state.tokenize = tokenString(ch);
			return state.tokenize(stream, state);
		}
		if (numberStart.test(ch)) {
			stream.backUp(1);
			if (stream.match(number)) return "number";
			stream.next();
		}
		if (isPunctuationChar.test(ch)) {
			curPunc = ch;
			return null;
		}
		if (ch == "/") {
			if (stream.eat("*")) {
				state.tokenize = tokenComment;
				return tokenComment(stream, state);
			}
			if (stream.eat("/")) {
				stream.skipToEnd();
				return "comment";
			}
		}
		if (isOperatorChar.test(ch)) {
			while (!stream.match(/^\/[\/*]/, false) && stream.eat(isOperatorChar));
			return "operator";
		}
		stream.eatWhile(isIdentifierChar);
		if (namespaceSeparator) while (stream.match(namespaceSeparator)) stream.eatWhile(isIdentifierChar);
		var cur = stream.current();
		if (contains(keywords, cur)) {
			if (contains(blockKeywords, cur)) curPunc = "newstatement";
			if (contains(defKeywords, cur)) isDefKeyword = true;
			return "keyword";
		}
		if (contains(types, cur)) return "type";
		if (contains(builtin, cur) || isReservedIdentifier && isReservedIdentifier(cur)) {
			if (contains(blockKeywords, cur)) curPunc = "newstatement";
			return "builtin";
		}
		if (contains(atoms, cur)) return "atom";
		return "variable";
	}
	function tokenString(quote) {
		return function(stream, state) {
			var escaped = false, next, end = false;
			while ((next = stream.next()) != null) {
				if (next == quote && !escaped) {
					end = true;
					break;
				}
				escaped = !escaped && next == "\\";
			}
			if (end || !(escaped || multiLineStrings)) state.tokenize = null;
			return "string";
		};
	}
	function tokenComment(stream, state) {
		var maybeEnd = false, ch;
		while (ch = stream.next()) {
			if (ch == "/" && maybeEnd) {
				state.tokenize = null;
				break;
			}
			maybeEnd = ch == "*";
		}
		return "comment";
	}
	function maybeEOL(stream, state) {
		if (parserConfig.typeFirstDefinitions && stream.eol() && isTopScope(state.context)) state.typeAtEndOfLine = typeBefore(stream, state, stream.pos);
	}
	return {
		name: parserConfig.name,
		startState: function(indentUnit) {
			return {
				tokenize: null,
				context: new Context$1(-indentUnit, 0, "top", null, false),
				indented: 0,
				startOfLine: true,
				prevToken: null
			};
		},
		token: function(stream, state) {
			var ctx = state.context;
			if (stream.sol()) {
				if (ctx.align == null) ctx.align = false;
				state.indented = stream.indentation();
				state.startOfLine = true;
			}
			if (stream.eatSpace()) {
				maybeEOL(stream, state);
				return null;
			}
			curPunc = isDefKeyword = null;
			var style = (state.tokenize || tokenBase)(stream, state);
			if (style == "comment" || style == "meta") return style;
			if (ctx.align == null) ctx.align = true;
			if (curPunc == ";" || curPunc == ":" || curPunc == "," && stream.match(/^\s*(?:\/\/.*)?$/, false)) while (state.context.type == "statement") popContext$1(state);
			else if (curPunc == "{") pushContext$1(state, stream.column(), "}");
			else if (curPunc == "[") pushContext$1(state, stream.column(), "]");
			else if (curPunc == "(") pushContext$1(state, stream.column(), ")");
			else if (curPunc == "}") {
				while (ctx.type == "statement") ctx = popContext$1(state);
				if (ctx.type == "}") ctx = popContext$1(state);
				while (ctx.type == "statement") ctx = popContext$1(state);
			} else if (curPunc == ctx.type) popContext$1(state);
			else if (indentStatements && ((ctx.type == "}" || ctx.type == "top") && curPunc != ";" || ctx.type == "statement" && curPunc == "newstatement")) pushContext$1(state, stream.column(), "statement", stream.current());
			if (style == "variable" && (state.prevToken == "def" || parserConfig.typeFirstDefinitions && typeBefore(stream, state, stream.start) && isTopScope(state.context) && stream.match(/^\s*\(/, false))) style = "def";
			if (hooks.token) {
				var result = hooks.token(stream, state, style);
				if (result !== void 0) style = result;
			}
			if (style == "def" && parserConfig.styleDefs === false) style = "variable";
			state.startOfLine = false;
			state.prevToken = isDefKeyword ? "def" : style || curPunc;
			maybeEOL(stream, state);
			return style;
		},
		indent: function(state, textAfter, context) {
			if (state.tokenize != tokenBase && state.tokenize != null || state.typeAtEndOfLine && isTopScope(state.context)) return null;
			var ctx = state.context, firstChar = textAfter && textAfter.charAt(0);
			var closing = firstChar == ctx.type;
			if (ctx.type == "statement" && firstChar == "}") ctx = ctx.prev;
			if (parserConfig.dontIndentStatements) while (ctx.type == "statement" && parserConfig.dontIndentStatements.test(ctx.info)) ctx = ctx.prev;
			if (hooks.indent) {
				var hook = hooks.indent(state, ctx, textAfter, context.unit);
				if (typeof hook == "number") return hook;
			}
			var switchBlock = ctx.prev && ctx.prev.info == "switch";
			if (parserConfig.allmanIndentation && /[{(]/.test(firstChar)) {
				while (ctx.type != "top" && ctx.type != "}") ctx = ctx.prev;
				return ctx.indented;
			}
			if (ctx.type == "statement") return ctx.indented + (firstChar == "{" ? 0 : statementIndentUnit || context.unit);
			if (ctx.align && (!dontAlignCalls || ctx.type != ")")) return ctx.column + (closing ? 0 : 1);
			if (ctx.type == ")" && !closing) return ctx.indented + (statementIndentUnit || context.unit);
			return ctx.indented + (closing ? 0 : context.unit) + (!closing && switchBlock && !/^(?:case|default)\b/.test(textAfter) ? context.unit : 0);
		},
		languageData: {
			indentOnInput: indentSwitch ? /^\s*(?:case .*?:|default:|\{\}?|\})$/ : /^\s*[{}]$/,
			commentTokens: {
				line: "//",
				block: {
					open: "/*",
					close: "*/"
				}
			},
			autocomplete: Object.keys(keywords).concat(Object.keys(types)).concat(Object.keys(builtin)).concat(Object.keys(atoms)),
			...parserConfig.languageData
		}
	};
}
function words(str) {
	var obj = {}, words = str.split(" ");
	for (var i = 0; i < words.length; ++i) obj[words[i]] = true;
	return obj;
}
function contains(words, word) {
	if (typeof words === "function") return words(word);
	else return words.propertyIsEnumerable(word);
}
var cKeywords = "auto if break case register continue return default do sizeof static else struct switch extern typedef union for goto while enum const volatile inline restrict asm fortran";
var cppKeywords = "alignas alignof and and_eq audit axiom bitand bitor catch class compl concept constexpr const_cast decltype delete dynamic_cast explicit export final friend import module mutable namespace new noexcept not not_eq operator or or_eq override private protected public reinterpret_cast requires static_assert static_cast template this thread_local throw try typeid typename using virtual xor xor_eq";
var objCKeywords = "bycopy byref in inout oneway out self super atomic nonatomic retain copy readwrite readonly strong weak assign typeof nullable nonnull null_resettable _cmd @interface @implementation @end @protocol @encode @property @synthesize @dynamic @class @public @package @private @protected @required @optional @try @catch @finally @import @selector @encode @defs @synchronized @autoreleasepool @compatibility_alias @available";
var objCBuiltins = "FOUNDATION_EXPORT FOUNDATION_EXTERN NS_INLINE NS_FORMAT_FUNCTION  NS_RETURNS_RETAINEDNS_ERROR_ENUM NS_RETURNS_NOT_RETAINED NS_RETURNS_INNER_POINTER NS_DESIGNATED_INITIALIZER NS_ENUM NS_OPTIONS NS_REQUIRES_NIL_TERMINATION NS_ASSUME_NONNULL_BEGIN NS_ASSUME_NONNULL_END NS_SWIFT_NAME NS_REFINED_FOR_SWIFT";
var basicCTypes = words("int long char short double float unsigned signed void bool");
var basicObjCTypes = words("SEL instancetype id Class Protocol BOOL");
function cTypes(identifier) {
	return contains(basicCTypes, identifier) || /.+_t$/.test(identifier);
}
function objCTypes(identifier) {
	return cTypes(identifier) || contains(basicObjCTypes, identifier);
}
var cBlockKeywords = "case do else for if switch while struct enum union";
var cDefKeywords = "struct enum union";
function cppHook(stream, state) {
	if (!state.startOfLine) return false;
	for (var ch, next = null; ch = stream.peek();) {
		if (ch == "\\" && stream.match(/^.$/)) {
			next = cppHook;
			break;
		} else if (ch == "/" && stream.match(/^\/[\/\*]/, false)) break;
		stream.next();
	}
	state.tokenize = next;
	return "meta";
}
function pointerHook(_stream, state) {
	if (state.prevToken == "type") return "type";
	return false;
}
function cIsReservedIdentifier(token) {
	if (!token || token.length < 2) return false;
	if (token[0] != "_") return false;
	return token[1] == "_" || token[1] !== token[1].toLowerCase();
}
function cpp14Literal(stream) {
	stream.eatWhile(/[\w\.']/);
	return "number";
}
function cpp11StringHook(stream, state) {
	stream.backUp(1);
	if (stream.match(/^(?:R|u8R|uR|UR|LR)/)) {
		var match = stream.match(/^"([^\s\\()]{0,16})\(/);
		if (!match) return false;
		state.cpp11RawStringDelim = match[1];
		state.tokenize = tokenRawString;
		return tokenRawString(stream, state);
	}
	if (stream.match(/^(?:u8|u|U|L)/)) {
		if (stream.match(/^["']/, false)) return "string";
		return false;
	}
	stream.next();
	return false;
}
function cppLooksLikeConstructor(word) {
	var lastTwo = /(\w+)::~?(\w+)$/.exec(word);
	return lastTwo && lastTwo[1] == lastTwo[2];
}
function tokenAtString(stream, state) {
	var next;
	while ((next = stream.next()) != null) if (next == "\"" && !stream.eat("\"")) {
		state.tokenize = null;
		break;
	}
	return "string";
}
function tokenRawString(stream, state) {
	var delim = state.cpp11RawStringDelim.replace(/[^\w\s]/g, "\\$&");
	if (stream.match(new RegExp(".*?\\)" + delim + "\""))) state.tokenize = null;
	else stream.skipToEnd();
	return "string";
}
var c = clike({
	name: "c",
	keywords: words(cKeywords),
	types: cTypes,
	blockKeywords: words(cBlockKeywords),
	defKeywords: words(cDefKeywords),
	typeFirstDefinitions: true,
	atoms: words("NULL true false"),
	isReservedIdentifier: cIsReservedIdentifier,
	hooks: {
		"#": cppHook,
		"*": pointerHook
	}
});
clike({
	name: "cpp",
	keywords: words(cKeywords + " " + cppKeywords),
	types: cTypes,
	blockKeywords: words(cBlockKeywords + " class try catch"),
	defKeywords: words(cDefKeywords + " class namespace"),
	typeFirstDefinitions: true,
	atoms: words("true false NULL nullptr"),
	dontIndentStatements: /^template$/,
	isIdentifierChar: /[\w\$_~\xa1-\uffff]/,
	isReservedIdentifier: cIsReservedIdentifier,
	hooks: {
		"#": cppHook,
		"*": pointerHook,
		"u": cpp11StringHook,
		"U": cpp11StringHook,
		"L": cpp11StringHook,
		"R": cpp11StringHook,
		"0": cpp14Literal,
		"1": cpp14Literal,
		"2": cpp14Literal,
		"3": cpp14Literal,
		"4": cpp14Literal,
		"5": cpp14Literal,
		"6": cpp14Literal,
		"7": cpp14Literal,
		"8": cpp14Literal,
		"9": cpp14Literal,
		token: function(stream, state, style) {
			if (style == "variable" && stream.peek() == "(" && (state.prevToken == ";" || state.prevToken == null || state.prevToken == "}") && cppLooksLikeConstructor(stream.current())) return "def";
		}
	},
	namespaceSeparator: "::"
});
clike({
	name: "java",
	keywords: words("abstract assert break case catch class const continue default do else enum extends final finally for goto if implements import instanceof interface native new package private protected public return static strictfp super switch synchronized this throw throws transient try volatile while @interface"),
	types: words("var byte short int long float double boolean char void Boolean Byte Character Double Float Integer Long Number Object Short String StringBuffer StringBuilder Void"),
	blockKeywords: words("catch class do else finally for if switch try while"),
	defKeywords: words("class interface enum @interface"),
	typeFirstDefinitions: true,
	atoms: words("true false null"),
	number: /^(?:0x[a-f\d_]+|0b[01_]+|(?:[\d_]+\.?\d*|\.\d+)(?:e[-+]?[\d_]+)?)(u|ll?|l|f)?/i,
	hooks: {
		"@": function(stream) {
			if (stream.match("interface", false)) return false;
			stream.eatWhile(/[\w\$_]/);
			return "meta";
		},
		"\"": function(stream, state) {
			if (!stream.match(/""$/)) return false;
			state.tokenize = tokenTripleString;
			return state.tokenize(stream, state);
		}
	}
});
var csharp = clike({
	name: "csharp",
	keywords: words("abstract as async await base break case catch checked class const continue default delegate do else enum event explicit extern finally fixed for foreach goto if implicit in init interface internal is lock namespace new operator out override params private protected public readonly record ref required return sealed sizeof stackalloc static struct switch this throw try typeof unchecked unsafe using virtual void volatile while add alias ascending descending dynamic from get global group into join let orderby partial remove select set value var yield"),
	types: words("Action Boolean Byte Char DateTime DateTimeOffset Decimal Double Func Guid Int16 Int32 Int64 Object SByte Single String Task TimeSpan UInt16 UInt32 UInt64 bool byte char decimal double short int long object sbyte float string ushort uint ulong"),
	blockKeywords: words("catch class do else finally for foreach if struct switch try while"),
	defKeywords: words("class interface namespace record struct var"),
	typeFirstDefinitions: true,
	atoms: words("true false null"),
	hooks: { "@": function(stream, state) {
		if (stream.eat("\"")) {
			state.tokenize = tokenAtString;
			return tokenAtString(stream, state);
		}
		stream.eatWhile(/[\w\$_]/);
		return "meta";
	} }
});
function tokenTripleString(stream, state) {
	var escaped = false;
	while (!stream.eol()) {
		if (!escaped && stream.match("\"\"\"")) {
			state.tokenize = null;
			break;
		}
		escaped = stream.next() == "\\" && !escaped;
	}
	return "string";
}
function tokenNestedComment(depth) {
	return function(stream, state) {
		var ch;
		while (ch = stream.next()) if (ch == "*" && stream.eat("/")) {
			if (depth == 1) {
				state.tokenize = null;
				break;
			} else {
				state.tokenize = tokenNestedComment(depth - 1);
				return state.tokenize(stream, state);
			}
		} else if (ch == "/" && stream.eat("*")) {
			state.tokenize = tokenNestedComment(depth + 1);
			return state.tokenize(stream, state);
		}
		return "comment";
	};
}
clike({
	name: "scala",
	keywords: words("abstract case catch class def do else extends final finally for forSome if implicit import lazy match new null object override package private protected return sealed super this throw trait try type val var while with yield _ assert assume require print println printf readLine readBoolean readByte readShort readChar readInt readLong readFloat readDouble"),
	types: words("AnyVal App Application Array BufferedIterator BigDecimal BigInt Char Console Either Enumeration Equiv Error Exception Fractional Function IndexedSeq Int Integral Iterable Iterator List Map Numeric Nil NotNull Option Ordered Ordering PartialFunction PartialOrdering Product Proxy Range Responder Seq Serializable Set Specializable Stream StringBuilder StringContext Symbol Throwable Traversable TraversableOnce Tuple Unit Vector Boolean Byte Character CharSequence Class ClassLoader Cloneable Comparable Compiler Double Exception Float Integer Long Math Number Object Package Pair Process Runtime Runnable SecurityManager Short StackTraceElement StrictMath String StringBuffer System Thread ThreadGroup ThreadLocal Throwable Triple Void"),
	multiLineStrings: true,
	blockKeywords: words("catch class enum do else finally for forSome if match switch try while"),
	defKeywords: words("class enum def object package trait type val var"),
	atoms: words("true false null"),
	indentStatements: false,
	indentSwitch: false,
	isOperatorChar: /[+\-*&%=<>!?|\/#:@]/,
	hooks: {
		"@": function(stream) {
			stream.eatWhile(/[\w\$_]/);
			return "meta";
		},
		"\"": function(stream, state) {
			if (!stream.match("\"\"")) return false;
			state.tokenize = tokenTripleString;
			return state.tokenize(stream, state);
		},
		"'": function(stream) {
			if (stream.match(/^(\\[^'\s]+|[^\\'])'/)) return "character";
			stream.eatWhile(/[\w\$_\xa1-\uffff]/);
			return "atom";
		},
		"=": function(stream, state) {
			var cx = state.context;
			if (cx.type == "}" && cx.align && stream.eat(">")) {
				state.context = new Context$1(cx.indented, cx.column, cx.type, cx.info, null, cx.prev);
				return "operator";
			} else return false;
		},
		"/": function(stream, state) {
			if (!stream.eat("*")) return false;
			state.tokenize = tokenNestedComment(1);
			return state.tokenize(stream, state);
		}
	},
	languageData: { closeBrackets: { brackets: [
		"(",
		"[",
		"{",
		"'",
		"\"",
		"\"\"\""
	] } }
});
function tokenKotlinString(tripleString) {
	return function(stream, state) {
		var escaped = false, next, end = false;
		while (!stream.eol()) {
			if (!tripleString && !escaped && stream.match("\"")) {
				end = true;
				break;
			}
			if (tripleString && stream.match("\"\"\"")) {
				end = true;
				break;
			}
			next = stream.next();
			if (!escaped && next == "$" && stream.match("{")) stream.skipTo("}");
			escaped = !escaped && next == "\\" && !tripleString;
		}
		if (end || !tripleString) state.tokenize = null;
		return "string";
	};
}
var kotlin = clike({
	name: "kotlin",
	keywords: words("package as typealias class interface this super val operator var fun for is in This throw return annotation break continue object if else while do try when !in !is as? file import where by get set abstract enum open inner override private public internal protected catch finally out final vararg reified dynamic companion constructor init sealed field property receiver param sparam lateinit data inline noinline tailrec external annotation crossinline const operator infix suspend actual expect setparam"),
	types: words("Boolean Byte Character CharSequence Class ClassLoader Cloneable Comparable Compiler Double Exception Float Integer Long Math Number Object Package Pair Process Runtime Runnable SecurityManager Short StackTraceElement StrictMath String StringBuffer System Thread ThreadGroup ThreadLocal Throwable Triple Void Annotation Any BooleanArray ByteArray Char CharArray DeprecationLevel DoubleArray Enum FloatArray Function Int IntArray Lazy LazyThreadSafetyMode LongArray Nothing ShortArray Unit"),
	intendSwitch: false,
	indentStatements: false,
	multiLineStrings: true,
	number: /^(?:0x[a-f\d_]+|0b[01_]+|(?:[\d_]+(\.\d+)?|\.\d+)(?:e[-+]?[\d_]+)?)(ul?|l|f)?/i,
	blockKeywords: words("catch class do else finally for if where try while enum"),
	defKeywords: words("class val var object interface fun"),
	atoms: words("true false null this"),
	hooks: {
		"@": function(stream) {
			stream.eatWhile(/[\w\$_]/);
			return "meta";
		},
		"*": function(_stream, state) {
			return state.prevToken == "." ? "variable" : "operator";
		},
		"\"": function(stream, state) {
			state.tokenize = tokenKotlinString(stream.match("\"\""));
			return state.tokenize(stream, state);
		},
		"/": function(stream, state) {
			if (!stream.eat("*")) return false;
			state.tokenize = tokenNestedComment(1);
			return state.tokenize(stream, state);
		},
		indent: function(state, ctx, textAfter, indentUnit) {
			var firstChar = textAfter && textAfter.charAt(0);
			if ((state.prevToken == "}" || state.prevToken == ")") && textAfter == "") return state.indented;
			if (state.prevToken == "operator" && textAfter != "}" && state.context.type != "}" || state.prevToken == "variable" && firstChar == "." || (state.prevToken == "}" || state.prevToken == ")") && firstChar == ".") return indentUnit * 2 + ctx.indented;
			if (ctx.align && ctx.type == "}") return ctx.indented + (state.context.type == (textAfter || "").charAt(0) ? 0 : indentUnit);
		}
	},
	languageData: { closeBrackets: { brackets: [
		"(",
		"[",
		"{",
		"'",
		"\"",
		"\"\"\""
	] } }
});
clike({
	name: "shader",
	keywords: words("sampler1D sampler2D sampler3D samplerCube sampler1DShadow sampler2DShadow const attribute uniform varying break continue discard return for while do if else struct in out inout"),
	types: words("float int bool void vec2 vec3 vec4 ivec2 ivec3 ivec4 bvec2 bvec3 bvec4 mat2 mat3 mat4"),
	blockKeywords: words("for while do if else struct"),
	builtin: words("radians degrees sin cos tan asin acos atan pow exp log exp2 sqrt inversesqrt abs sign floor ceil fract mod min max clamp mix step smoothstep length distance dot cross normalize ftransform faceforward reflect refract matrixCompMult lessThan lessThanEqual greaterThan greaterThanEqual equal notEqual any all not texture1D texture1DProj texture1DLod texture1DProjLod texture2D texture2DProj texture2DLod texture2DProjLod texture3D texture3DProj texture3DLod texture3DProjLod textureCube textureCubeLod shadow1D shadow2D shadow1DProj shadow2DProj shadow1DLod shadow2DLod shadow1DProjLod shadow2DProjLod dFdx dFdy fwidth noise1 noise2 noise3 noise4"),
	atoms: words("true false gl_FragColor gl_SecondaryColor gl_Normal gl_Vertex gl_MultiTexCoord0 gl_MultiTexCoord1 gl_MultiTexCoord2 gl_MultiTexCoord3 gl_MultiTexCoord4 gl_MultiTexCoord5 gl_MultiTexCoord6 gl_MultiTexCoord7 gl_FogCoord gl_PointCoord gl_Position gl_PointSize gl_ClipVertex gl_FrontColor gl_BackColor gl_FrontSecondaryColor gl_BackSecondaryColor gl_TexCoord gl_FogFragCoord gl_FragCoord gl_FrontFacing gl_FragData gl_FragDepth gl_ModelViewMatrix gl_ProjectionMatrix gl_ModelViewProjectionMatrix gl_TextureMatrix gl_NormalMatrix gl_ModelViewMatrixInverse gl_ProjectionMatrixInverse gl_ModelViewProjectionMatrixInverse gl_TextureMatrixTranspose gl_ModelViewMatrixInverseTranspose gl_ProjectionMatrixInverseTranspose gl_ModelViewProjectionMatrixInverseTranspose gl_TextureMatrixInverseTranspose gl_NormalScale gl_DepthRange gl_ClipPlane gl_Point gl_FrontMaterial gl_BackMaterial gl_LightSource gl_LightModel gl_FrontLightModelProduct gl_BackLightModelProduct gl_TextureColor gl_EyePlaneS gl_EyePlaneT gl_EyePlaneR gl_EyePlaneQ gl_FogParameters gl_MaxLights gl_MaxClipPlanes gl_MaxTextureUnits gl_MaxTextureCoords gl_MaxVertexAttribs gl_MaxVertexUniformComponents gl_MaxVaryingFloats gl_MaxVertexTextureImageUnits gl_MaxTextureImageUnits gl_MaxFragmentUniformComponents gl_MaxCombineTextureImageUnits gl_MaxDrawBuffers"),
	indentSwitch: false,
	hooks: { "#": cppHook }
});
clike({
	name: "nesc",
	keywords: words(cKeywords + " as atomic async call command component components configuration event generic implementation includes interface module new norace nx_struct nx_union post provides signal task uses abstract extends"),
	types: cTypes,
	blockKeywords: words(cBlockKeywords),
	atoms: words("null true false"),
	hooks: { "#": cppHook }
});
clike({
	name: "objectivec",
	keywords: words(cKeywords + " " + objCKeywords),
	types: objCTypes,
	builtin: words(objCBuiltins),
	blockKeywords: words(cBlockKeywords + " @synthesize @try @catch @finally @autoreleasepool @synchronized"),
	defKeywords: words(cDefKeywords + " @interface @implementation @protocol @class"),
	dontIndentStatements: /^@.*$/,
	typeFirstDefinitions: true,
	atoms: words("YES NO NULL Nil nil true false nullptr"),
	isReservedIdentifier: cIsReservedIdentifier,
	hooks: {
		"#": cppHook,
		"*": pointerHook
	}
});
clike({
	name: "objectivecpp",
	keywords: words(cKeywords + " " + objCKeywords + " " + cppKeywords),
	types: objCTypes,
	builtin: words(objCBuiltins),
	blockKeywords: words(cBlockKeywords + " @synthesize @try @catch @finally @autoreleasepool @synchronized class try catch"),
	defKeywords: words(cDefKeywords + " @interface @implementation @protocol @class class namespace"),
	dontIndentStatements: /^@.*$|^template$/,
	typeFirstDefinitions: true,
	atoms: words("YES NO NULL Nil nil true false nullptr"),
	isReservedIdentifier: cIsReservedIdentifier,
	hooks: {
		"#": cppHook,
		"*": pointerHook,
		"u": cpp11StringHook,
		"U": cpp11StringHook,
		"L": cpp11StringHook,
		"R": cpp11StringHook,
		"0": cpp14Literal,
		"1": cpp14Literal,
		"2": cpp14Literal,
		"3": cpp14Literal,
		"4": cpp14Literal,
		"5": cpp14Literal,
		"6": cpp14Literal,
		"7": cpp14Literal,
		"8": cpp14Literal,
		"9": cpp14Literal,
		token: function(stream, state, style) {
			if (style == "variable" && stream.peek() == "(" && (state.prevToken == ";" || state.prevToken == null || state.prevToken == "}") && cppLooksLikeConstructor(stream.current())) return "def";
		}
	},
	namespaceSeparator: "::"
});
clike({
	name: "squirrel",
	keywords: words("base break clone continue const default delete enum extends function in class foreach local resume return this throw typeof yield constructor instanceof static"),
	types: cTypes,
	blockKeywords: words("case catch class else for foreach if switch try while"),
	defKeywords: words("function local class"),
	typeFirstDefinitions: true,
	atoms: words("true false null"),
	hooks: { "#": cppHook }
});
var stringTokenizer = null;
function tokenCeylonString(type) {
	return function(stream, state) {
		var escaped = false, next, end = false;
		while (!stream.eol()) {
			if (!escaped && stream.match("\"") && (type == "single" || stream.match("\"\""))) {
				end = true;
				break;
			}
			if (!escaped && stream.match("``")) {
				stringTokenizer = tokenCeylonString(type);
				end = true;
				break;
			}
			next = stream.next();
			escaped = type == "single" && !escaped && next == "\\";
		}
		if (end) state.tokenize = null;
		return "string";
	};
}
clike({
	name: "ceylon",
	keywords: words("abstracts alias assembly assert assign break case catch class continue dynamic else exists extends finally for function given if import in interface is let module new nonempty object of out outer package return satisfies super switch then this throw try value void while"),
	types: function(word) {
		var first = word.charAt(0);
		return first === first.toUpperCase() && first !== first.toLowerCase();
	},
	blockKeywords: words("case catch class dynamic else finally for function if interface module new object switch try while"),
	defKeywords: words("class dynamic function interface module object package value"),
	builtin: words("abstract actual aliased annotation by default deprecated doc final formal late license native optional sealed see serializable shared suppressWarnings tagged throws variable"),
	isPunctuationChar: /[\[\]{}\(\),;\:\.`]/,
	isOperatorChar: /[+\-*&%=<>!?|^~:\/]/,
	numberStart: /[\d#$]/,
	number: /^(?:#[\da-fA-F_]+|\$[01_]+|[\d_]+[kMGTPmunpf]?|[\d_]+\.[\d_]+(?:[eE][-+]?\d+|[kMGTPmunpf]|)|)/i,
	multiLineStrings: true,
	typeFirstDefinitions: true,
	atoms: words("true false null larger smaller equal empty finished"),
	indentSwitch: false,
	styleDefs: false,
	hooks: {
		"@": function(stream) {
			stream.eatWhile(/[\w\$_]/);
			return "meta";
		},
		"\"": function(stream, state) {
			state.tokenize = tokenCeylonString(stream.match("\"\"") ? "triple" : "single");
			return state.tokenize(stream, state);
		},
		"`": function(stream, state) {
			if (!stringTokenizer || !stream.match("`")) return false;
			state.tokenize = stringTokenizer;
			stringTokenizer = null;
			return state.tokenize(stream, state);
		},
		"'": function(stream) {
			if (stream.match(/^(\\[^'\s]+|[^\\'])'/)) return "string.special";
			stream.eatWhile(/[\w\$_\xa1-\uffff]/);
			return "atom";
		},
		token: function(_stream, state, style) {
			if ((style == "variable" || style == "type") && state.prevToken == ".") return "variableName.special";
		}
	},
	languageData: { closeBrackets: { brackets: [
		"(",
		"[",
		"{",
		"'",
		"\"",
		"\"\"\""
	] } }
});
function pushInterpolationStack(state) {
	(state.interpolationStack || (state.interpolationStack = [])).push(state.tokenize);
}
function popInterpolationStack(state) {
	return (state.interpolationStack || (state.interpolationStack = [])).pop();
}
function sizeInterpolationStack(state) {
	return state.interpolationStack ? state.interpolationStack.length : 0;
}
function tokenDartString(quote, stream, state, raw) {
	var tripleQuoted = false;
	if (stream.eat(quote)) {
		if (stream.eat(quote)) tripleQuoted = true;
		else return "string";
	}
	function tokenStringHelper(stream, state) {
		var escaped = false;
		while (!stream.eol()) {
			if (!raw && !escaped && stream.peek() == "$") {
				pushInterpolationStack(state);
				state.tokenize = tokenInterpolation;
				return "string";
			}
			var next = stream.next();
			if (next == quote && !escaped && (!tripleQuoted || stream.match(quote + quote))) {
				state.tokenize = null;
				break;
			}
			escaped = !raw && !escaped && next == "\\";
		}
		return "string";
	}
	state.tokenize = tokenStringHelper;
	return tokenStringHelper(stream, state);
}
function tokenInterpolation(stream, state) {
	stream.eat("$");
	if (stream.eat("{")) state.tokenize = null;
	else state.tokenize = tokenInterpolationIdentifier;
	return null;
}
function tokenInterpolationIdentifier(stream, state) {
	stream.eatWhile(/[\w_]/);
	state.tokenize = popInterpolationStack(state);
	return "variable";
}
var dart = clike({
	name: "dart",
	keywords: words("this super static final const abstract class extends external factory implements mixin get native set typedef with enum throw rethrow assert break case continue default in return new deferred async await covariant try catch finally do else for if switch while import library export part of show hide is as extension on yield late required sealed base interface when inline"),
	blockKeywords: words("try catch finally do else for if switch while"),
	builtin: words("void bool num int double dynamic var String Null Never"),
	atoms: words("true false null"),
	number: /^(?:0x[a-f\d_]+|(?:[\d_]+\.?[\d_]*|\.[\d_]+)(?:e[-+]?[\d_]+)?)/i,
	hooks: {
		"@": function(stream) {
			stream.eatWhile(/[\w\$_\.]/);
			return "meta";
		},
		"'": function(stream, state) {
			return tokenDartString("'", stream, state, false);
		},
		"\"": function(stream, state) {
			return tokenDartString("\"", stream, state, false);
		},
		"r": function(stream, state) {
			var peek = stream.peek();
			if (peek == "'" || peek == "\"") return tokenDartString(stream.next(), stream, state, true);
			return false;
		},
		"}": function(_stream, state) {
			if (sizeInterpolationStack(state) > 0) {
				state.tokenize = popInterpolationStack(state);
				return null;
			}
			return false;
		},
		"/": function(stream, state) {
			if (!stream.eat("*")) return false;
			state.tokenize = tokenNestedComment(1);
			return state.tokenize(stream, state);
		},
		token: function(stream, _, style) {
			if (style == "variable") {
				if (RegExp("^[_$]*[A-Z][a-zA-Z0-9_$]*$", "g").test(stream.current())) return "type";
			}
		}
	}
});
//#endregion
//#region node_modules/@codemirror/legacy-modes/mode/swift.js
function wordSet(words) {
	var set = {};
	for (var i = 0; i < words.length; i++) set[words[i]] = true;
	return set;
}
var keywords$3 = wordSet([
	"_",
	"var",
	"let",
	"actor",
	"class",
	"enum",
	"extension",
	"import",
	"protocol",
	"struct",
	"func",
	"typealias",
	"associatedtype",
	"open",
	"public",
	"internal",
	"fileprivate",
	"private",
	"deinit",
	"init",
	"new",
	"override",
	"self",
	"subscript",
	"super",
	"convenience",
	"dynamic",
	"final",
	"indirect",
	"lazy",
	"required",
	"static",
	"unowned",
	"unowned(safe)",
	"unowned(unsafe)",
	"weak",
	"as",
	"is",
	"break",
	"case",
	"continue",
	"default",
	"else",
	"fallthrough",
	"for",
	"guard",
	"if",
	"in",
	"repeat",
	"switch",
	"where",
	"while",
	"defer",
	"return",
	"inout",
	"mutating",
	"nonmutating",
	"isolated",
	"nonisolated",
	"catch",
	"do",
	"rethrows",
	"throw",
	"throws",
	"async",
	"await",
	"try",
	"didSet",
	"get",
	"set",
	"willSet",
	"assignment",
	"associativity",
	"infix",
	"left",
	"none",
	"operator",
	"postfix",
	"precedence",
	"precedencegroup",
	"prefix",
	"right",
	"Any",
	"AnyObject",
	"Type",
	"dynamicType",
	"Self",
	"Protocol",
	"__COLUMN__",
	"__FILE__",
	"__FUNCTION__",
	"__LINE__"
]);
var definingKeywords = wordSet([
	"var",
	"let",
	"actor",
	"class",
	"enum",
	"extension",
	"import",
	"protocol",
	"struct",
	"func",
	"typealias",
	"associatedtype",
	"for"
]);
var atoms$1 = wordSet([
	"true",
	"false",
	"nil",
	"self",
	"super",
	"_"
]);
var types = wordSet([
	"Array",
	"Bool",
	"Character",
	"Dictionary",
	"Double",
	"Float",
	"Int",
	"Int8",
	"Int16",
	"Int32",
	"Int64",
	"Never",
	"Optional",
	"Set",
	"String",
	"UInt8",
	"UInt16",
	"UInt32",
	"UInt64",
	"Void"
]);
var operators = "+-/*%=|&<>~^?!";
var punc = ":;,.(){}[]";
var binary = /^\-?0b[01][01_]*/;
var octal = /^\-?0o[0-7][0-7_]*/;
var hexadecimal = /^\-?0x[\dA-Fa-f][\dA-Fa-f_]*(?:(?:\.[\dA-Fa-f][\dA-Fa-f_]*)?[Pp]\-?\d[\d_]*)?/;
var decimal = /^\-?\d[\d_]*(?:\.\d[\d_]*)?(?:[Ee]\-?\d[\d_]*)?/;
var identifier = /^\$\d+|(`?)[_A-Za-z][_A-Za-z$0-9]*\1/;
var property = /^\.(?:\$\d+|(`?)[_A-Za-z][_A-Za-z$0-9]*\1)/;
var instruction = /^\#[A-Za-z]+/;
var attribute = /^@(?:\$\d+|(`?)[_A-Za-z][_A-Za-z$0-9]*\1)/;
function tokenBase$2(stream, state, prev) {
	if (stream.sol()) state.indented = stream.indentation();
	if (stream.eatSpace()) return null;
	var ch = stream.peek();
	if (ch == "/") {
		if (stream.match("//")) {
			stream.skipToEnd();
			return "comment";
		}
		if (stream.match("/*")) {
			state.tokenize.push(tokenComment);
			return tokenComment(stream, state);
		}
	}
	if (stream.match(instruction)) return "builtin";
	if (stream.match(attribute)) return "attribute";
	if (stream.match(binary)) return "number";
	if (stream.match(octal)) return "number";
	if (stream.match(hexadecimal)) return "number";
	if (stream.match(decimal)) return "number";
	if (stream.match(property)) return "property";
	if (operators.indexOf(ch) > -1) {
		stream.next();
		return "operator";
	}
	if (punc.indexOf(ch) > -1) {
		stream.next();
		stream.match("..");
		return "punctuation";
	}
	var stringMatch;
	if (stringMatch = stream.match(/("""|"|')/)) {
		var tokenize = tokenString$1.bind(null, stringMatch[0]);
		state.tokenize.push(tokenize);
		return tokenize(stream, state);
	}
	if (stream.match(identifier)) {
		var ident = stream.current();
		if (types.hasOwnProperty(ident)) return "type";
		if (atoms$1.hasOwnProperty(ident)) return "atom";
		if (keywords$3.hasOwnProperty(ident)) {
			if (definingKeywords.hasOwnProperty(ident)) state.prev = "define";
			return "keyword";
		}
		if (prev == "define") return "def";
		return "variable";
	}
	stream.next();
	return null;
}
function tokenUntilClosingParen() {
	var depth = 0;
	return function(stream, state, prev) {
		var inner = tokenBase$2(stream, state, prev);
		if (inner == "punctuation") {
			if (stream.current() == "(") ++depth;
			else if (stream.current() == ")") {
				if (depth == 0) {
					stream.backUp(1);
					state.tokenize.pop();
					return state.tokenize[state.tokenize.length - 1](stream, state);
				} else --depth;
			}
		}
		return inner;
	};
}
function tokenString$1(openQuote, stream, state) {
	var singleLine = openQuote.length == 1;
	var ch, escaped = false;
	while (ch = stream.peek()) if (escaped) {
		stream.next();
		if (ch == "(") {
			state.tokenize.push(tokenUntilClosingParen());
			return "string";
		}
		escaped = false;
	} else if (stream.match(openQuote)) {
		state.tokenize.pop();
		return "string";
	} else {
		stream.next();
		escaped = ch == "\\";
	}
	if (singleLine) state.tokenize.pop();
	return "string";
}
function tokenComment(stream, state) {
	var ch;
	while (ch = stream.next()) if (ch === "/" && stream.eat("*")) state.tokenize.push(tokenComment);
	else if (ch === "*" && stream.eat("/")) {
		state.tokenize.pop();
		break;
	}
	return "comment";
}
function Context(prev, align, indented) {
	this.prev = prev;
	this.align = align;
	this.indented = indented;
}
function pushContext(state, stream) {
	var align = stream.match(/^\s*($|\/[\/\*]|[)}\]])/, false) ? null : stream.column() + 1;
	state.context = new Context(state.context, align, state.indented);
}
function popContext(state) {
	if (state.context) {
		state.indented = state.context.indented;
		state.context = state.context.prev;
	}
}
var swift = {
	name: "swift",
	startState: function() {
		return {
			prev: null,
			context: null,
			indented: 0,
			tokenize: []
		};
	},
	token: function(stream, state) {
		var prev = state.prev;
		state.prev = null;
		var style = (state.tokenize[state.tokenize.length - 1] || tokenBase$2)(stream, state, prev);
		if (!style || style == "comment") state.prev = prev;
		else if (!state.prev) state.prev = style;
		if (style == "punctuation") {
			var bracket = /[\(\[\{]|([\]\)\}])/.exec(stream.current());
			if (bracket) (bracket[1] ? popContext : pushContext)(state, stream);
		}
		return style;
	},
	indent: function(state, textAfter, iCx) {
		var cx = state.context;
		if (!cx) return 0;
		var closing = /^[\]\}\)]/.test(textAfter);
		if (cx.align != null) return cx.align - (closing ? 1 : 0);
		return cx.indented + (closing ? 0 : iCx.unit);
	},
	languageData: {
		indentOnInput: /^\s*[\)\}\]]$/,
		commentTokens: {
			line: "//",
			block: {
				open: "/*",
				close: "*/"
			}
		},
		closeBrackets: { brackets: [
			"(",
			"[",
			"{",
			"'",
			"\"",
			"`"
		] }
	}
};
//#endregion
//#region node_modules/@codemirror/legacy-modes/mode/ruby.js
function wordObj$1(words) {
	var o = {};
	for (var i = 0, e = words.length; i < e; ++i) o[words[i]] = true;
	return o;
}
var keywordList = [
	"alias",
	"and",
	"BEGIN",
	"begin",
	"break",
	"case",
	"class",
	"def",
	"defined?",
	"do",
	"else",
	"elsif",
	"END",
	"end",
	"ensure",
	"false",
	"for",
	"if",
	"in",
	"module",
	"next",
	"not",
	"or",
	"redo",
	"rescue",
	"retry",
	"return",
	"self",
	"super",
	"then",
	"true",
	"undef",
	"unless",
	"until",
	"when",
	"while",
	"yield",
	"nil",
	"raise",
	"throw",
	"catch",
	"fail",
	"loop",
	"callcc",
	"caller",
	"lambda",
	"proc",
	"public",
	"protected",
	"private",
	"require",
	"load",
	"require_relative",
	"extend",
	"autoload",
	"__END__",
	"__FILE__",
	"__LINE__",
	"__dir__"
];
var keywords$2 = wordObj$1(keywordList);
var indentWords = wordObj$1([
	"def",
	"class",
	"case",
	"for",
	"while",
	"until",
	"module",
	"catch",
	"loop",
	"proc",
	"begin"
]);
var dedentWords = wordObj$1(["end", "until"]);
var opening = {
	"[": "]",
	"{": "}",
	"(": ")"
};
var closing = {
	"]": "[",
	"}": "{",
	")": "("
};
var curPunc$1;
function chain(newtok, stream, state) {
	state.tokenize.push(newtok);
	return newtok(stream, state);
}
function tokenBase$1(stream, state) {
	if (stream.sol() && stream.match("=begin") && stream.eol()) {
		state.tokenize.push(readBlockComment);
		return "comment";
	}
	if (stream.eatSpace()) return null;
	var ch = stream.next(), m;
	if (ch == "`" || ch == "'" || ch == "\"") return chain(readQuoted(ch, "string", ch == "\"" || ch == "`"), stream, state);
	else if (ch == "/") {
		if (regexpAhead(stream)) return chain(readQuoted(ch, "string.special", true), stream, state);
		else return "operator";
	} else if (ch == "%") {
		var style = "string", embed = true;
		if (stream.eat("s")) style = "atom";
		else if (stream.eat(/[WQ]/)) style = "string";
		else if (stream.eat(/[r]/)) style = "string.special";
		else if (stream.eat(/[wxq]/)) {
			style = "string";
			embed = false;
		}
		var delim = stream.eat(/[^\w\s=]/);
		if (!delim) return "operator";
		if (opening.propertyIsEnumerable(delim)) delim = opening[delim];
		return chain(readQuoted(delim, style, embed, true), stream, state);
	} else if (ch == "#") {
		stream.skipToEnd();
		return "comment";
	} else if (ch == "<" && (m = stream.match(/^<([-~])[\`\"\']?([a-zA-Z_?]\w*)[\`\"\']?(?:;|$)/))) return chain(readHereDoc(m[2], m[1]), stream, state);
	else if (ch == "0") {
		if (stream.eat("x")) stream.eatWhile(/[\da-fA-F]/);
		else if (stream.eat("b")) stream.eatWhile(/[01]/);
		else if (stream.eat(".")) stream.eat(/[\d_]*(?:[eE][+\-]?[\d_]+)?/);
		else stream.eatWhile(/[0-7]/);
		return "number";
	} else if (/\d/.test(ch)) {
		stream.match(/^[\d_]*(?:\.[\d_]+)?(?:[eE][+\-]?[\d_]+)?/);
		return "number";
	} else if (ch == "?") {
		while (stream.match(/^\\[CM]-/));
		if (stream.eat("\\")) stream.eatWhile(/\w/);
		else stream.next();
		return "string";
	} else if (ch == ":") {
		if (stream.eat("'")) return chain(readQuoted("'", "atom", false), stream, state);
		if (stream.eat("\"")) return chain(readQuoted("\"", "atom", true), stream, state);
		if (stream.eat(/[\<\>]/)) {
			stream.eat(/[\<\>]/);
			return "atom";
		}
		if (stream.eat(/[\+\-\*\/\&\|\:\!]/)) return "atom";
		if (stream.eat(/[a-zA-Z$@_\xa1-\uffff]/)) {
			stream.eatWhile(/[\w$\xa1-\uffff]/);
			stream.eat(/[\?\!\=]/);
			return "atom";
		}
		return "operator";
	} else if (ch == "@" && stream.match(/^@?[a-zA-Z_\xa1-\uffff]/)) {
		stream.eat("@");
		stream.eatWhile(/[\w\xa1-\uffff]/);
		return "propertyName";
	} else if (ch == "$") {
		if (stream.eat(/[a-zA-Z_]/)) stream.eatWhile(/[\w]/);
		else if (stream.eat(/\d/)) stream.eat(/\d/);
		else stream.next();
		return "variableName.special";
	} else if (/[a-zA-Z_\xa1-\uffff]/.test(ch)) {
		stream.eatWhile(/[\w\xa1-\uffff]/);
		stream.eat(/[\?\!]/);
		if (stream.eat(":")) return "atom";
		return "variable";
	} else if (ch == "|" && (state.varList || state.lastTok == "{" || state.lastTok == "do")) {
		curPunc$1 = "|";
		return null;
	} else if (/[\(\)\[\]{}\\;]/.test(ch)) {
		curPunc$1 = ch;
		return null;
	} else if (ch == "-" && stream.eat(">")) return "operator";
	else if (/[=+\-\/*:\.^%<>~|]/.test(ch)) {
		var more = stream.eatWhile(/[=+\-\/*:\.^%<>~|]/);
		if (ch == "." && !more) curPunc$1 = ".";
		return "operator";
	} else return null;
}
function regexpAhead(stream) {
	var start = stream.pos, depth = 0, next, found = false, escaped = false;
	while ((next = stream.next()) != null) if (!escaped) {
		if ("[{(".indexOf(next) > -1) depth++;
		else if ("]})".indexOf(next) > -1) {
			depth--;
			if (depth < 0) break;
		} else if (next == "/" && depth == 0) {
			found = true;
			break;
		}
		escaped = next == "\\";
	} else escaped = false;
	stream.backUp(stream.pos - start);
	return found;
}
function tokenBaseUntilBrace(depth) {
	if (!depth) depth = 1;
	return function(stream, state) {
		if (stream.peek() == "}") {
			if (depth == 1) {
				state.tokenize.pop();
				return state.tokenize[state.tokenize.length - 1](stream, state);
			} else state.tokenize[state.tokenize.length - 1] = tokenBaseUntilBrace(depth - 1);
		} else if (stream.peek() == "{") state.tokenize[state.tokenize.length - 1] = tokenBaseUntilBrace(depth + 1);
		return tokenBase$1(stream, state);
	};
}
function tokenBaseOnce() {
	var alreadyCalled = false;
	return function(stream, state) {
		if (alreadyCalled) {
			state.tokenize.pop();
			return state.tokenize[state.tokenize.length - 1](stream, state);
		}
		alreadyCalled = true;
		return tokenBase$1(stream, state);
	};
}
function readQuoted(quote, style, embed, unescaped) {
	return function(stream, state) {
		var escaped = false, ch;
		if (state.context.type === "read-quoted-paused") {
			state.context = state.context.prev;
			stream.eat("}");
		}
		while ((ch = stream.next()) != null) {
			if (ch == quote && (unescaped || !escaped)) {
				state.tokenize.pop();
				break;
			}
			if (embed && ch == "#" && !escaped) {
				if (stream.eat("{")) {
					if (quote == "}") state.context = {
						prev: state.context,
						type: "read-quoted-paused"
					};
					state.tokenize.push(tokenBaseUntilBrace());
					break;
				} else if (/[@\$]/.test(stream.peek())) {
					state.tokenize.push(tokenBaseOnce());
					break;
				}
			}
			escaped = !escaped && ch == "\\";
		}
		return style;
	};
}
function readHereDoc(phrase, mayIndent) {
	return function(stream, state) {
		if (mayIndent) stream.eatSpace();
		if (stream.match(phrase)) state.tokenize.pop();
		else stream.skipToEnd();
		return "string";
	};
}
function readBlockComment(stream, state) {
	if (stream.sol() && stream.match("=end") && stream.eol()) state.tokenize.pop();
	stream.skipToEnd();
	return "comment";
}
var ruby = {
	name: "ruby",
	startState: function(indentUnit) {
		return {
			tokenize: [tokenBase$1],
			indented: 0,
			context: {
				type: "top",
				indented: -indentUnit
			},
			continuedLine: false,
			lastTok: null,
			varList: false
		};
	},
	token: function(stream, state) {
		curPunc$1 = null;
		if (stream.sol()) state.indented = stream.indentation();
		var style = state.tokenize[state.tokenize.length - 1](stream, state), kwtype;
		var thisTok = curPunc$1;
		if (style == "variable") {
			var word = stream.current();
			style = state.lastTok == "." ? "property" : keywords$2.propertyIsEnumerable(stream.current()) ? "keyword" : /^[A-Z]/.test(word) ? "tag" : state.lastTok == "def" || state.lastTok == "class" || state.varList ? "def" : "variable";
			if (style == "keyword") {
				thisTok = word;
				if (indentWords.propertyIsEnumerable(word)) kwtype = "indent";
				else if (dedentWords.propertyIsEnumerable(word)) kwtype = "dedent";
				else if ((word == "if" || word == "unless") && stream.column() == stream.indentation()) kwtype = "indent";
				else if (word == "do" && state.context.indented < state.indented) kwtype = "indent";
			}
		}
		if (curPunc$1 || style && style != "comment") state.lastTok = thisTok;
		if (curPunc$1 == "|") state.varList = !state.varList;
		if (kwtype == "indent" || /[\(\[\{]/.test(curPunc$1)) state.context = {
			prev: state.context,
			type: curPunc$1 || style,
			indented: state.indented
		};
		else if ((kwtype == "dedent" || /[\)\]\}]/.test(curPunc$1)) && state.context.prev) state.context = state.context.prev;
		if (stream.eol()) state.continuedLine = curPunc$1 == "\\" || style == "operator";
		return style;
	},
	indent: function(state, textAfter, cx) {
		if (state.tokenize[state.tokenize.length - 1] != tokenBase$1) return null;
		var firstChar = textAfter && textAfter.charAt(0);
		var ct = state.context;
		var closed = ct.type == closing[firstChar] || ct.type == "keyword" && /^(?:end|until|else|elsif|when|rescue)\b/.test(textAfter);
		return ct.indented + (closed ? 0 : cx.unit) + (state.continuedLine ? cx.unit : 0);
	},
	languageData: {
		indentOnInput: /^\s*(?:end|rescue|elsif|else|\})$/,
		commentTokens: { line: "#" },
		autocomplete: keywordList
	}
};
//#endregion
//#region node_modules/@codemirror/legacy-modes/mode/lua.js
function prefixRE(words) {
	return new RegExp("^(?:" + words.join("|") + ")", "i");
}
function wordRE(words) {
	return new RegExp("^(?:" + words.join("|") + ")$", "i");
}
var builtins$1 = wordRE([
	"_G",
	"_VERSION",
	"assert",
	"collectgarbage",
	"dofile",
	"error",
	"getfenv",
	"getmetatable",
	"ipairs",
	"load",
	"loadfile",
	"loadstring",
	"module",
	"next",
	"pairs",
	"pcall",
	"print",
	"rawequal",
	"rawget",
	"rawset",
	"require",
	"select",
	"setfenv",
	"setmetatable",
	"tonumber",
	"tostring",
	"type",
	"unpack",
	"xpcall",
	"coroutine.create",
	"coroutine.resume",
	"coroutine.running",
	"coroutine.status",
	"coroutine.wrap",
	"coroutine.yield",
	"debug.debug",
	"debug.getfenv",
	"debug.gethook",
	"debug.getinfo",
	"debug.getlocal",
	"debug.getmetatable",
	"debug.getregistry",
	"debug.getupvalue",
	"debug.setfenv",
	"debug.sethook",
	"debug.setlocal",
	"debug.setmetatable",
	"debug.setupvalue",
	"debug.traceback",
	"close",
	"flush",
	"lines",
	"read",
	"seek",
	"setvbuf",
	"write",
	"io.close",
	"io.flush",
	"io.input",
	"io.lines",
	"io.open",
	"io.output",
	"io.popen",
	"io.read",
	"io.stderr",
	"io.stdin",
	"io.stdout",
	"io.tmpfile",
	"io.type",
	"io.write",
	"math.abs",
	"math.acos",
	"math.asin",
	"math.atan",
	"math.atan2",
	"math.ceil",
	"math.cos",
	"math.cosh",
	"math.deg",
	"math.exp",
	"math.floor",
	"math.fmod",
	"math.frexp",
	"math.huge",
	"math.ldexp",
	"math.log",
	"math.log10",
	"math.max",
	"math.min",
	"math.modf",
	"math.pi",
	"math.pow",
	"math.rad",
	"math.random",
	"math.randomseed",
	"math.sin",
	"math.sinh",
	"math.sqrt",
	"math.tan",
	"math.tanh",
	"os.clock",
	"os.date",
	"os.difftime",
	"os.execute",
	"os.exit",
	"os.getenv",
	"os.remove",
	"os.rename",
	"os.setlocale",
	"os.time",
	"os.tmpname",
	"package.cpath",
	"package.loaded",
	"package.loaders",
	"package.loadlib",
	"package.path",
	"package.preload",
	"package.seeall",
	"string.byte",
	"string.char",
	"string.dump",
	"string.find",
	"string.format",
	"string.gmatch",
	"string.gsub",
	"string.len",
	"string.lower",
	"string.match",
	"string.rep",
	"string.reverse",
	"string.sub",
	"string.upper",
	"table.concat",
	"table.insert",
	"table.maxn",
	"table.remove",
	"table.sort"
]);
var keywords$1 = wordRE([
	"and",
	"break",
	"elseif",
	"false",
	"nil",
	"not",
	"or",
	"return",
	"true",
	"function",
	"end",
	"if",
	"then",
	"else",
	"do",
	"while",
	"repeat",
	"until",
	"for",
	"in",
	"local"
]);
var indentTokens = wordRE([
	"function",
	"if",
	"repeat",
	"do",
	"\\(",
	"{"
]);
var dedentTokens = wordRE([
	"end",
	"until",
	"\\)",
	"}"
]);
var dedentPartial = prefixRE([
	"end",
	"until",
	"\\)",
	"}",
	"else",
	"elseif"
]);
function readBracket(stream) {
	var level = 0;
	while (stream.eat("=")) ++level;
	stream.eat("[");
	return level;
}
function normal(stream, state) {
	var ch = stream.next();
	if (ch == "-" && stream.eat("-")) {
		if (stream.eat("[") && /[\[=]/.test(stream.peek())) return (state.cur = bracketed(readBracket(stream), "comment"))(stream, state);
		stream.skipToEnd();
		return "comment";
	}
	if (ch == "\"" || ch == "'") return (state.cur = string(ch))(stream, state);
	if (ch == "[" && /[\[=]/.test(stream.peek())) return (state.cur = bracketed(readBracket(stream), "string"))(stream, state);
	if (/\d/.test(ch)) {
		stream.eatWhile(/[\w.%]/);
		return "number";
	}
	if (/[\w_]/.test(ch)) {
		stream.eatWhile(/[\w\\\-_.]/);
		return "variable";
	}
	return null;
}
function bracketed(level, style) {
	return function(stream, state) {
		var curlev = null, ch;
		while ((ch = stream.next()) != null) if (curlev == null) {
			if (ch == "]") curlev = 0;
		} else if (ch == "=") ++curlev;
		else if (ch == "]" && curlev == level) {
			state.cur = normal;
			break;
		} else curlev = null;
		return style;
	};
}
function string(quote) {
	return function(stream, state) {
		var escaped = false, ch;
		while ((ch = stream.next()) != null) {
			if (ch == quote && !escaped) break;
			escaped = !escaped && ch == "\\";
		}
		if (!escaped) state.cur = normal;
		return "string";
	};
}
var lua = {
	name: "lua",
	startState: function() {
		return {
			basecol: 0,
			indentDepth: 0,
			cur: normal
		};
	},
	token: function(stream, state) {
		if (stream.eatSpace()) return null;
		var style = state.cur(stream, state);
		var word = stream.current();
		if (style == "variable") {
			if (keywords$1.test(word)) style = "keyword";
			else if (builtins$1.test(word)) style = "builtin";
		}
		if (style != "comment" && style != "string") {
			if (indentTokens.test(word)) ++state.indentDepth;
			else if (dedentTokens.test(word)) --state.indentDepth;
		}
		return style;
	},
	indent: function(state, textAfter, cx) {
		var closing = dedentPartial.test(textAfter);
		return state.basecol + cx.unit * (state.indentDepth - (closing ? 1 : 0));
	},
	languageData: {
		indentOnInput: /^\s*(?:end|until|else|\)|\})$/,
		commentTokens: {
			line: "--",
			block: {
				open: "--[[",
				close: "]]--"
			}
		}
	}
};
//#endregion
//#region node_modules/@codemirror/legacy-modes/mode/r.js
function wordObj(words) {
	var res = {};
	for (var i = 0; i < words.length; ++i) res[words[i]] = true;
	return res;
}
var commonAtoms = [
	"NULL",
	"NA",
	"Inf",
	"NaN",
	"NA_integer_",
	"NA_real_",
	"NA_complex_",
	"NA_character_",
	"TRUE",
	"FALSE"
];
var commonBuiltins = [
	"list",
	"quote",
	"bquote",
	"eval",
	"return",
	"call",
	"parse",
	"deparse"
];
var commonKeywords = [
	"if",
	"else",
	"repeat",
	"while",
	"function",
	"for",
	"in",
	"next",
	"break"
];
var commonBlockKeywords = [
	"if",
	"else",
	"repeat",
	"while",
	"function",
	"for"
];
var atoms = wordObj(commonAtoms);
var builtins = wordObj(commonBuiltins);
var keywords = wordObj(commonKeywords);
var blockkeywords = wordObj(commonBlockKeywords);
var opChars = /[+\-*\/^<>=!&|~$:]/;
var curPunc;
function tokenBase(stream, state) {
	curPunc = null;
	var ch = stream.next();
	if (ch == "#") {
		stream.skipToEnd();
		return "comment";
	} else if (ch == "0" && stream.eat("x")) {
		stream.eatWhile(/[\da-f]/i);
		return "number";
	} else if (ch == "." && stream.eat(/\d/)) {
		stream.match(/\d*(?:e[+\-]?\d+)?/);
		return "number";
	} else if (/\d/.test(ch)) {
		stream.match(/\d*(?:\.\d+)?(?:e[+\-]\d+)?L?/);
		return "number";
	} else if (ch == "'" || ch == "\"") {
		state.tokenize = tokenString(ch);
		return "string";
	} else if (ch == "`") {
		stream.match(/[^`]+`/);
		return "string.special";
	} else if (ch == "." && stream.match(/.(?:[.]|\d+)/)) return "keyword";
	else if (/[a-zA-Z\.]/.test(ch)) {
		stream.eatWhile(/[\w\.]/);
		var word = stream.current();
		if (atoms.propertyIsEnumerable(word)) return "atom";
		if (keywords.propertyIsEnumerable(word)) {
			if (blockkeywords.propertyIsEnumerable(word) && !stream.match(/\s*if(\s+|$)/, false)) curPunc = "block";
			return "keyword";
		}
		if (builtins.propertyIsEnumerable(word)) return "builtin";
		return "variable";
	} else if (ch == "%") {
		if (stream.skipTo("%")) stream.next();
		return "variableName.special";
	} else if (ch == "<" && stream.eat("-") || ch == "<" && stream.match("<-") || ch == "-" && stream.match(/>>?/)) return "operator";
	else if (ch == "=" && state.ctx.argList) return "operator";
	else if (opChars.test(ch)) {
		if (ch == "$") return "operator";
		stream.eatWhile(opChars);
		return "operator";
	} else if (/[\(\){}\[\];]/.test(ch)) {
		curPunc = ch;
		if (ch == ";") return "punctuation";
		return null;
	} else return null;
}
function tokenString(quote) {
	return function(stream, state) {
		if (stream.eat("\\")) {
			var ch = stream.next();
			if (ch == "x") stream.match(/^[a-f0-9]{2}/i);
			else if ((ch == "u" || ch == "U") && stream.eat("{") && stream.skipTo("}")) stream.next();
			else if (ch == "u") stream.match(/^[a-f0-9]{4}/i);
			else if (ch == "U") stream.match(/^[a-f0-9]{8}/i);
			else if (/[0-7]/.test(ch)) stream.match(/^[0-7]{1,2}/);
			return "string.special";
		} else {
			var next;
			while ((next = stream.next()) != null) {
				if (next == quote) {
					state.tokenize = tokenBase;
					break;
				}
				if (next == "\\") {
					stream.backUp(1);
					break;
				}
			}
			return "string";
		}
	};
}
var ALIGN_YES = 1;
var ALIGN_NO = 2;
var BRACELESS = 4;
function push(state, type, stream) {
	state.ctx = {
		type,
		indent: state.indent,
		flags: 0,
		column: stream.column(),
		prev: state.ctx
	};
}
function setFlag(state, flag) {
	var ctx = state.ctx;
	state.ctx = {
		type: ctx.type,
		indent: ctx.indent,
		flags: ctx.flags | flag,
		column: ctx.column,
		prev: ctx.prev
	};
}
function pop(state) {
	state.indent = state.ctx.indent;
	state.ctx = state.ctx.prev;
}
var r = {
	name: "r",
	startState: function(indentUnit) {
		return {
			tokenize: tokenBase,
			ctx: {
				type: "top",
				indent: -indentUnit,
				flags: ALIGN_NO
			},
			indent: 0,
			afterIdent: false
		};
	},
	token: function(stream, state) {
		if (stream.sol()) {
			if ((state.ctx.flags & 3) == 0) state.ctx.flags |= ALIGN_NO;
			if (state.ctx.flags & BRACELESS) pop(state);
			state.indent = stream.indentation();
		}
		if (stream.eatSpace()) return null;
		var style = state.tokenize(stream, state);
		if (style != "comment" && (state.ctx.flags & ALIGN_NO) == 0) setFlag(state, ALIGN_YES);
		if ((curPunc == ";" || curPunc == "{" || curPunc == "}") && state.ctx.type == "block") pop(state);
		if (curPunc == "{") push(state, "}", stream);
		else if (curPunc == "(") {
			push(state, ")", stream);
			if (state.afterIdent) state.ctx.argList = true;
		} else if (curPunc == "[") push(state, "]", stream);
		else if (curPunc == "block") push(state, "block", stream);
		else if (curPunc == state.ctx.type) pop(state);
		else if (state.ctx.type == "block" && style != "comment") setFlag(state, BRACELESS);
		state.afterIdent = style == "variable" || style == "keyword";
		return style;
	},
	indent: function(state, textAfter, cx) {
		if (state.tokenize != tokenBase) return 0;
		var firstChar = textAfter && textAfter.charAt(0), ctx = state.ctx, closing = firstChar == ctx.type;
		if (ctx.flags & BRACELESS) ctx = ctx.prev;
		if (ctx.type == "block") return ctx.indent + (firstChar == "{" ? 0 : cx.unit);
		else if (ctx.flags & ALIGN_YES) return ctx.column + (closing ? 0 : 1);
		else return ctx.indent + (closing ? 0 : cx.unit);
	},
	languageData: {
		wordChars: ".",
		commentTokens: { line: "#" },
		autocomplete: commonAtoms.concat(commonBuiltins, commonKeywords)
	}
};
//#endregion
export { c as a, kotlin as c, swift as i, lua as n, csharp as o, ruby as r, dart as s, r as t };
