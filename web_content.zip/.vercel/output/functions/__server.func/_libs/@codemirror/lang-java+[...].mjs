import { B as tags, S as flatIndent, T as foldNodeProp, d as LRLanguage, k as indentNodeProp, m as LanguageSupport, w as foldInside, x as delimitedIndent, y as continuedIndent, z as styleTags } from "./autocomplete+[...].mjs";
import { i as LRParser } from "./lang-cpp+[...].mjs";
//#region node_modules/@lezer/java/dist/index.js
var javaHighlighting = styleTags({
	null: tags.null,
	instanceof: tags.operatorKeyword,
	this: tags.self,
	"new super assert open to with void": tags.keyword,
	"class interface extends implements enum var": tags.definitionKeyword,
	"module package import": tags.moduleKeyword,
	"switch while for if else case default do break continue return try catch finally throw": tags.controlKeyword,
	["requires exports opens uses provides public private protected static transitive abstract final strictfp synchronized native transient volatile throws"]: tags.modifier,
	IntegerLiteral: tags.integer,
	FloatingPointLiteral: tags.float,
	"StringLiteral TextBlock": tags.string,
	CharacterLiteral: tags.character,
	LineComment: tags.lineComment,
	BlockComment: tags.blockComment,
	BooleanLiteral: tags.bool,
	PrimitiveType: tags.standard(tags.typeName),
	TypeName: tags.typeName,
	Identifier: tags.variableName,
	"MethodName/Identifier": tags.function(tags.variableName),
	Definition: tags.definition(tags.variableName),
	ArithOp: tags.arithmeticOperator,
	LogicOp: tags.logicOperator,
	BitOp: tags.bitwiseOperator,
	CompareOp: tags.compareOperator,
	AssignOp: tags.definitionOperator,
	UpdateOp: tags.updateOperator,
	Asterisk: tags.punctuation,
	Label: tags.labelName,
	"( )": tags.paren,
	"[ ]": tags.squareBracket,
	"{ }": tags.brace,
	".": tags.derefOperator,
	", ;": tags.separator
});
var spec_identifier = {
	__proto__: null,
	true: 34,
	false: 34,
	null: 42,
	void: 46,
	byte: 48,
	short: 48,
	int: 48,
	long: 48,
	char: 48,
	float: 48,
	double: 48,
	boolean: 48,
	extends: 62,
	super: 64,
	class: 76,
	this: 78,
	new: 84,
	public: 100,
	protected: 102,
	private: 104,
	abstract: 106,
	static: 108,
	final: 110,
	strictfp: 112,
	default: 114,
	synchronized: 116,
	native: 118,
	transient: 120,
	volatile: 122,
	throws: 150,
	implements: 160,
	interface: 166,
	enum: 176,
	instanceof: 236,
	open: 265,
	module: 267,
	requires: 272,
	transitive: 274,
	exports: 276,
	to: 278,
	opens: 280,
	uses: 282,
	provides: 284,
	with: 286,
	package: 290,
	import: 294,
	if: 306,
	else: 308,
	while: 312,
	for: 316,
	var: 323,
	assert: 330,
	switch: 334,
	case: 340,
	do: 344,
	break: 348,
	continue: 352,
	return: 356,
	throw: 362,
	try: 366,
	catch: 370,
	finally: 378
};
var parser = LRParser.deserialize({
	version: 14,
	states: "##jQ]QPOOQ$wQPOOO(_QQO'#H]O*cQQO'#CbOOQO'#Cb'#CbO*jQPO'#CaO*rOSO'#CpOOQO'#Hb'#HbOOQO'#Cu'#CuO,_QPO'#D_O,xQQO'#HlOOQO'#Hl'#HlO/^QQO'#HgO/eQQO'#HgOOQO'#Hg'#HgOOQO'#Hf'#HfO1iQPO'#DUO1vQPO'#GmO4nQPO'#D_O4uQPO'#DzO*jQPO'#E[O5hQPO'#E[OOQO'#DV'#DVO6vQQO'#H`O8}QQO'#EeO9UQPO'#EdO9ZQPO'#EfOOQO'#Ha'#HaO7^QQO'#HaO:^QQO'#FgO:eQPO'#EwO:jQPO'#E|O:jQPO'#FOOOQO'#H`'#H`OOQO'#HX'#HXOOQO'#Gg'#GgOOQO'#HW'#HWO;zQPO'#FhOOQO'#HV'#HVOOQO'#Gf'#GfQ]QPOOOOQO'#Hr'#HrO<PQPO'#HrO<UQPO'#D{O<UQPO'#EVO<UQPO'#EQO<^QPO'#HoO<oQQO'#EfO*jQPO'#C`O<wQPO'#C`O*jQPO'#FbO<|QPO'#FdO=XQPO'#FjO=XQPO'#FmO<UQPO'#FrO=^QPO'#FoO:jQPO'#FvO=XQPO'#FxO]QPO'#F}O=cQPO'#GPO=nQPO'#GRO=yQPO'#GTO=XQPO'#GVO:jQPO'#GWO>QQPO'#GYO>nQQO'#HhO?ZQQO'#CuO?bQPO'#HwO?pQPO'#D_O@`QPO'#DpO?eQPO'#DqO@jQPO'#HwO@{QPO'#DpOATQPO'#IQOAYQPO'#E`OOQO'#Hq'#HqOOQO'#Gl'#GlQ$wQPOOOAbQPO'#HrOOQO'#H]'#H]OCaQQO,58{OOQO'#HZ'#HZOOOO'#Gh'#GhOESOSO,59[OOQO,59[,59[OOQO'#Hh'#HhOEsQPO,59eOFuQPO,59yOOQO-E:e-E:eO*jQPO,58zOGiQPO,58zO*jQPO,5;|OGnQPO'#DQOGsQPO'#DQOOQO'#Gj'#GjOHsQQO,59jOOQO'#Dm'#DmOJ[QPO'#HtOJfQPO'#DlOJtQPO'#HsOJ|QPO,5<^OKRQPO,59^OKlQPO'#CxOOQO,59c,59cOKsQPO,59bOLOQQO'#H]OM}QQO'#CbO! |QPO'#D_O!#RQQO'#HlO!#cQQO,59pO!#jQPO'#DvO!#xQPO'#H{O!$QQPO,5:`O!$VQPO,5:`O!$mQPO,5;mO!$xQPO'#ISO!%TQPO,5;dO!%YQPO,5=XOOQO-E:k-E:kOOQO,5:f,5:fO!&pQPO,5:fO!&wQPO,5:vO?bQPO,5<^O*jQPO,5:vO<UQPO,5:gO<UQPO,5:qO<UQPO,5:lO<UQPO,5<^O!'_QPO,59qO:jQPO,5:}O!'fQPO,5;QO:jQPO,59TO!'tQPO'#DXOOQO,5;O,5;OOOQO'#El'#ElOOQO'#Eo'#EoO:jQPO,5;UO:jQPO,5;UO:jQPO,5;UO:jQPO,5;UO:jQPO,5;UO:jQPO,5;UO:jQPO,5;UO:jQPO,5;UO:jQPO,5;UO:jQPO,5;eOOQO,5;h,5;hOOQO,5<R,5<RO!'{QPO,5;aO!(^QPO,5;cO!'{QPO'#CyO!(eQQO'#HlO!(sQQO,5;jO]QPO,5<SOOQO-E:d-E:dOOQO,5>^,5>^O!*TQPO,5:gO!*cQPO,5:qO!*kQPO,5:lO!*vQPO,5>ZO!#jQPO,5>ZO!&|QPO,59UO!+RQQO,58zO!+ZQQO,5;|O!+cQQO,5<OO*jQPO,5<OO:jQPO'#DUO]QPO,5<UO]QPO,5<XO!+kQPO'#FqO]QPO,5<ZO]QPO,5<`O!+{QQO,5<bO!,VQPO,5<dO!,[QPO,5<iOOQO'#Fi'#FiOOQO,5<k,5<kO!,aQPO,5<kOOQO,5<m,5<mO!,fQPO,5<mO!,kQQO,5<oOOQO,5<o,5<oO>TQPO,5<qO!,rQQO,5<rO!,yQPO'#GcO!.PQPO,5<tO>TQPO,5<|O!1}QPO,59jO!2[QPO'#HtO!2cQPO,59xO!2hQPO,5>cO?bQPO,59xO!2sQPO,5:[OAYQPO,5:zO!2{QPO'#DrO?eQPO'#DrO!3WQPO'#HxO!3`QPO,5:]O?bQPO,5>cO!'{QPO,5>cOATQPO,5>lOOQO,5:[,5:[O!$VQPO'#DtOOQO,5>l,5>lO!3eQPO'#EaOOQO,5:z,5:zO!6fQPO,5:zO!'{QPO'#DxOOQO-E:j-E:jOOQO,5:y,5:yO*jQPO,58}O!6kQPO'#ChOOQO1G.k1G.kOOOO-E:f-E:fOOQO1G.v1G.vO!+RQQO1G.fO*jQPO1G.fO!6uQQO1G1hOOQO,59l,59lO!6}QPO,59lOOQO-E:h-E:hO!7SQPO,5>`O!7kQPO,5:WO<UQPO'#GoO!7rQPO,5>_OOQO1G1x1G1xOOQO1G.x1G.xO!8]QPO'#CyO!8{QPO'#HlO!9VQPO'#CzO!9eQPO'#HkO!9mQPO,59dOOQO1G.|1G.|OKsQPO1G.|O!:TQPO,59eO!:bQQO'#H]O!:sQQO'#CbOOQO,5:b,5:bO<UQPO,5:cOOQO,5:a,5:aO!;UQQO,5:aOOQO1G/[1G/[O!;ZQPO,5:bO!;lQPO'#GrO!<PQPO,5>gOOQO1G/z1G/zO!<XQPO'#DvO!<jQPO1G/zO!'{QPO'#GpO!<oQPO1G1XO:jQPO1G1XO<UQPO'#GxO!<wQPO,5>nOOQO1G1O1G1OOOQO1G0Q1G0QO!=PQPO'#E]OOQO1G0b1G0bO!=pQPO1G1xO!&wQPO1G0bO!*TQPO1G0RO!*cQPO1G0]O!*kQPO1G0WOOQO1G/]1G/]O!=uQQO1G.pO9UQPO1G0jO*jQPO1G0jO<^QPO'#HoO!?iQQO1G.pOOQO1G.p1G.pO!?nQQO1G0iOOQO1G0l1G0lO!?uQPO1G0lO!@QQQO1G.oO!@hQQO'#HpO!@uQPO,59sO!BXQQO1G0pO!CmQQO1G0pO!CtQQO1G0pO!EYQQO1G0pO!FnQQO1G0pO!FuQQO1G0pO!HZQQO1G0pO!HbQQO1G0pO!HiQQO1G0pO!HpQQO1G1PO!HwQQO'#HlOOQO1G0{1G0{O!IzQQO1G0}OOQO1G0}1G0}OOQO1G1n1G1nO!JbQPO'#D[O!'{QPO'#D|O!'{QPO'#D}OOQO1G0R1G0RO!JiQPO1G0RO!JnQPO1G0RO!JvQPO1G0RO!KRQPO'#EXOOQO1G0]1G0]O!KfQPO1G0]O!KkQPO'#ETO!'{QPO'#ESOOQO1G0W1G0WO!LeQPO1G0WO!LjQPO1G0WO!LrQPO'#EhO!LyQPO'#EhOOQO'#Gw'#GwO!MRQQO1G0mO!NrQQO1G3uO9UQPO1G3uO#!qQPO'#FWOOQO1G.f1G.fOOQO1G1h1G1hO#!xQPO1G1jOOQO1G1j1G1jO##TQQO1G1jO##]QPO1G1pOOQO1G1s1G1sO*zQPO'#D_O,xQQO,5<aO#'TQPO,5<aO#'fQPO,5<]O#'mQPO,5<]OOQO1G1u1G1uOOQO1G1z1G1zOOQO1G1|1G1|O:jQPO1G1|O#+aQPO'#FzOOQO1G2O1G2OO=XQPO1G2TOOQO1G2V1G2VOOQO1G2X1G2XOOQO1G2Z1G2ZOOQO1G2]1G2]OOQO1G2^1G2^O#+hQQO'#H]O#,RQQO'#CbO,xQQO'#HlO#,lQQOOO#-YQQO'#EeO#,wQQO'#HaO!#jQPO'#GdO#-aQPO,5<}OOQO'#HP'#HPO#-iQPO1G2`O#1gQPO'#G[O>TQPO'#G`OOQO1G2`1G2`O#1lQPO1G2hO#5jQPO,5>fOOQO1G/d1G/dOOQO1G3}1G3}O#5{QPO1G/dOOQO1G/v1G/vOOQO1G0f1G0fO!6fQPO1G0fOOQO,5:^,5:^O!'{QPO'#DsO#6QQPO,5:^O?eQPO'#GqO#6]QPO,5>dOOQO1G/w1G/wOATQPO'#HzO#6eQPO1G3}O?bQPO1G3}OOQO1G4W1G4WO!!mQPO'#DvO! |QPO'#D_OOQO,5:{,5:{O#6pQPO,5:{O#6pQPO,5:{O#6wQQO'#H`O#8VQQO'#HaO#8aQQO'#EbO#8lQPO'#EbO#8tQPO'#H}OOQO,5:d,5:dOOQO1G.i1G.iO#9PQQO'#EeO#9aQQO'#H_O#9qQPO'#FSOOQO'#H_'#H_O#9{QPO'#H_O#:jQPO'#IVO#:rQPO,59SOOQO7+$Q7+$QO!+RQQO7+$QOOQO7+'S7+'SOOQO1G/W1G/WO#:wQPO'#DoO#;RQQO'#HuOOQO'#Hu'#HuOOQO1G/r1G/rOOQO,5=Z,5=ZOOQO-E:m-E:mO#;cQWO,58{O#;jQPO,59fOOQO,59f,59fO!'{QPO'#HnOKWQPO'#GiO#;xQPO,5>VOOQO1G/O1G/OOOQO7+$h7+$hOOQO1G/{1G/{O#<QQQO1G/{OOQO1G/}1G/}O#<VQPO1G/{OOQO1G/|1G/|O<UQPO1G/}OOQO,5=^,5=^OOQO-E:p-E:pOOQO7+%f7+%fOOQO,5=[,5=[OOQO-E:n-E:nO:jQPO7+&sOOQO7+&s7+&sOOQO,5=d,5=dOOQO-E:v-E:vO#<[QPO'#EUO#<jQPO'#EUOOQO'#Gv'#GvO#=RQPO,5:wOOQO,5:w,5:wOOQO7+'d7+'dOOQO7+%|7+%|OOQO7+%m7+%mO!JiQPO7+%mO!JnQPO7+%mO!JvQPO7+%mOOQO7+%w7+%wO!KfQPO7+%wOOQO7+%r7+%rO!LeQPO7+%rO!LjQPO7+%rOOQO7+&U7+&UOOQO'#Ee'#EeO9UQPO7+&UO9UQPO,5>ZO#=rQPO7+$[OOQO7+&T7+&TOOQO7+&W7+&WO:jQPO'#GkO#>QQPO,5>[OOQO1G/_1G/_O:jQPO7+&kO#>]QQO,59eO#?`QPO,59vOOQO,59v,59vOOQO,5:h,5:hOOQO'#EP'#EPOOQO,5:i,5:iO#?gQPO'#EYO<UQPO'#EYO#?xQPO'#IOO#@TQPO,5:sO?bQPO'#HwO!'{QPO'#HwO#@]QPO'#DpOOQO'#Gt'#GtO#@dQPO,5:oOOQO,5:o,5:oOOQO,5:n,5:nOOQO,5;S,5;SO#A^QQO,5;SO#AeQPO,5;SOOQO-E:u-E:uOOQO7+&X7+&XOOQO7+)a7+)aO#AlQQO7+)aOOQO'#G{'#G{O#CYQPO,5;rOOQO,5;r,5;rO#CaQPO'#FXO*jQPO'#FXO*jQPO'#FXO*jQPO'#FXO#CoQPO7+'UO#CtQPO7+'UOOQO7+'U7+'UO]QPO7+'[O#DPQPO1G1{O?bQPO1G1{O#D_QQO1G1wO!'tQPO1G1wO#DfQPO1G1wO#DmQQO7+'hOOQO'#HO'#HOO#DtQPO,5<fOOQO,5<f,5<fO#D{QPO'#HrO:jQPO'#F{O#ETQPO7+'oO#EYQPO,5=OO?bQPO,5=OO#E_QPO1G2iO#FhQPO1G2iOOQO1G2i1G2iOOQO-E:}-E:}OOQO7+'z7+'zO!;lQPO'#G^O>TQPO,5<vOOQO,5<z,5<zO#FpQPO7+(SOOQO7+(S7+(SO#JnQPO1G4QOOQO7+%O7+%OOOQO7+&Q7+&QO#KPQPO,5:_OOQO1G/x1G/xOOQO,5=],5=]OOQO-E:o-E:oOOQO7+)i7+)iO#K[QPO7+)iO!9rQPO,5:aOOQO1G0g1G0gO#KgQPO1G0gO#KnQPO,59qO#LSQPO,5:|O9UQPO,5:|O!'{QPO'#GsO#LXQPO,5>iO#LdQPO,59TO#LkQPO'#IUO#LsQPO,5;nO*jQPO'#GzO#LxQPO,5>qOOQO1G.n1G.nOOQO<<Gl<<GlO#MQQPO'#HvO#MYQPO,5:ZOOQO1G/Q1G/QOOQO,5>Y,5>YOOQO,5=T,5=TOOQO-E:g-E:gO#M_QPO7+%gOOQO7+%g7+%gOOQO7+%i7+%iOOQO<<J_<<J_O#MuQPO'#H]O#M|QPO'#CbO#NTQPO,5:pO#NYQPO,5:xO#<[QPO,5:pOOQO-E:t-E:tOOQO1G0c1G0cOOQO<<IX<<IXO!JiQPO<<IXO!JnQPO<<IXOOQO<<Ic<<IcOOQO<<I^<<I^O!LeQPO<<I^OOQO<<Ip<<IpO#N_QQO<<GvO9UQPO<<IpO*jQPO<<IpOOQO<<Gv<<GvO$!RQQO,5=VOOQO-E:i-E:iO$!`QQO<<JVOOQO1G/b1G/bOOQO,5:t,5:tO$!vQPO,5:tO$#UQPO,5:tO$#gQPO'#GuO$#}QPO,5>jO$$YQPO'#EZOOQO1G0_1G0_O$$aQPO1G0_O?bQPO,5:pOOQO-E:r-E:rOOQO1G0Z1G0ZOOQO1G0n1G0nO$$fQQO1G0nOOQO<<L{<<L{OOQO-E:y-E:yOOQO1G1^1G1^O$$mQQO,5;sOOQO'#G|'#G|O#CaQPO,5;sOOQO'#IW'#IWO$$uQQO,5;sO$%WQQO,5;sOOQO<<Jp<<JpO$%`QPO<<JpOOQO<<Jv<<JvO:jQPO7+'gO$%eQPO7+'gO!'tQPO7+'cO$%sQPO7+'cO$%xQQO7+'cOOQO<<KS<<KSOOQO-E:|-E:|OOQO1G2Q1G2QOOQO,5<g,5<gO$&PQQO,5<gOOQO<<KZ<<KZO:jQPO1G2jO$&WQPO1G2jOOQO,5=m,5=mOOQO7+(T7+(TO$&]QPO7+(TOOQO-E;P-E;PO$'zQWO'#HgO$'fQWO'#HgO$(RQPO'#G_O<UQPO,5<xO!#jQPO,5<xOOQO1G2b1G2bOOQO<<Kn<<KnO$(dQPO1G/yOOQO<<MT<<MTOOQO7+&R7+&RO$(oQPO1G0jO$(zQQO1G0hOOQO1G0h1G0hO$)SQPO1G0hOOQO,5=_,5=_OOQO-E:q-E:qO$)XQQO1G.oOOQO1G1Z1G1ZO$)cQPO'#GyO$)pQPO,5>pOOQO1G1Y1G1YO$)xQPO'#FTOOQO,5=f,5=fOOQO-E:x-E:xO$)}QPO'#GnO$*[QPO,5>bOOQO1G/u1G/uOOQO<<IR<<IROOQO1G0[1G0[O$*dQPO1G0dO$*iQPO1G0[O$*nQPO1G0dOOQOAN>sAN>sO!JiQPOAN>sOOQOAN>xAN>xOOQOAN?[AN?[O9UQPOAN?[OOQO1G0`1G0`O$*sQPO1G0`OOQO,5=a,5=aOOQO-E:s-E:sO$+RQPO,5:uOOQO7+%y7+%yOOQO7+&Y7+&YOOQO1G1_1G1_O$+YQQO1G1_OOQO-E:z-E:zO$+bQQO'#IXO$+]QPO1G1_O$${QPO1G1_O*jQPO1G1_OOQOAN@[AN@[O$+mQQO<<KRO:jQPO<<KRO$+tQPO<<J}OOQO<<J}<<J}O!'tQPO<<J}OOQO1G2R1G2RO$+yQQO7+(UO:jQPO7+(UOOQO<<Ko<<KoP!,yQPO'#HRO!#jQPO'#HQO$,TQPO,5<yO$,`QPO1G2dO<UQPO1G2dO9UQPO7+&SO$,eQPO7+&SOOQO7+&S7+&SOOQO,5=e,5=eOOQO-E:w-E:wO#LdQPO,5;oOOQO,5=Y,5=YOOQO-E:l-E:lO$,jQPO7+&OOOQO7+%v7+%vO$,xQPO7+&OOOQOG24_G24_OOQOG24vG24vOOQO7+%z7+%zOOQO7+&y7+&yO*jQPO'#G}O$,}QPO,5>sO$-VQPO7+&yO$-[QQO'#IYOOQOAN@mAN@mO$-gQQOAN@mOOQOAN@iAN@iO$-nQPOAN@iO$-sQQO<<KpO$-}QPO,5=lOOQO-E;O-E;OOOQO7+(O7+(OO$.`QPO7+(OO$.eQPO<<InOOQO<<In<<InO$.jQPO<<IjOOQO<<Ij<<IjO#LdQPO<<IjO$.jQPO<<IjO$.xQQO,5=iOOQO-E:{-E:{OOQO<<Je<<JeO$/TQPO,5>tOOQOG26XG26XOOQOG26TG26TOOQO<<Kj<<KjOOQOAN?YAN?YOOQOAN?UAN?UO#LdQPOAN?UO$/]QPOAN?UO$/bQPOAN?UO$/pQPOG24pOOQOG24pG24pO#LdQPOG24pOOQOLD*[LD*[O$/uQPOLD*[OOQO!$'Mv!$'MvO*jQPO'#CaO$/zQQO'#H]O$0_QQO'#CbO!'{QPO'#Cy",
	stateData: "$0}~OPOSQOS%xOS~OZ`O_VO`VOaVObVOcVOeVOg^Oh^Op!POv{OwkOz!OO}cO!PvO!SyO!TyO!UyO!VyO!WyO!XyO!YyO!ZzO![!`O!]yO!^yO!_yO!u}O!z|O#fpO#qoO#spO#tpO#x!RO#y!QO$V!SO$X!TO$_!UO$b!VO$d!XO$g!WO$k!YO$m!ZO$r![O$t!]O$v!^O$x!_O${!aO$}!bO%|TO&ORO&QQO&WUO&sdO~Og^Oh^Ov{O}cO!P!mO!SyO!TyO!UyO!VyO!W!pO!XyO!YyO!ZzO!]yO!^yO!_yO!u}O!z|O%|TO&O!cO&Q!dO&^!hO&sdO~OWiXW&PXZ&PXuiXu&PX!P&PX!b&PX#]&PX#_&PX#a&PX#b&PX#d&PX#e&PX#f&PX#g&PX#h&PX#j&PX#n&PX#q&PX%|iX&OiX&QiX&]&PX&^iX&^&PX&m&PX&uiX&u&PX&w!aX~O#o$]X~P&bOWUXW&[XZUXuUXu&[X!PUX!bUX#]UX#_UX#aUX#bUX#dUX#eUX#fUX#gUX#hUX#jUX#nUX#qUX%|&[X&O&[X&Q&[X&]UX&^UX&^&[X&mUX&uUX&u&[X&w!aX~O#o$]X~P(fO&OSO&Q!qO~O&V!vO&X!tO~Og^Oh^O!SyO!TyO!UyO!VyO!WyO!XyO!YyO!ZzO!]yO!^yO!_yO%|TO&O!wO&QWOg!RXh!RX$g!RX&O!RX&Q!RX~O#x!|O#y!{O$V!}Ov!RX!u!RX!z!RX&s!RX~P*zOW#XOu#OO%|TO&O#SO&Q#SO&u&`X~OW#[Ou&ZX%|&ZX&O&ZX&Q&ZX&u&ZXY&ZXw&ZX&m&ZX&p&ZXZ&ZXq&ZX&]&ZX!P&ZX#_&ZX#a&ZX#b&ZX#d&ZX#e&ZX#f&ZX#g&ZX#h&ZX#j&ZX#n&ZX#q&ZX}&ZX!r&ZX#o&ZXs&ZX|&ZX~O&^#YO~P-^O&^&ZX~P-^OZ`O_VO`VOaVObVOcVOeVOg^Oh^Op!POwkOz!OO!SyO!TyO!UyO!VyO!WyO!XyO!YyO!ZzO!]yO!^yO!_yO#fpO#qoO#spO#tpO%|TO&WUO~O&O#^O&Q#]OY&oP~P/lO%|TOg%aXh%aXv%aX!S%aX!T%aX!U%aX!V%aX!W%aX!X%aX!Y%aX!Z%aX!]%aX!^%aX!_%aX!u%aX!z%aX$g%aX&O%aX&Q%aX&s%aX&^%aX~O!SyO!TyO!UyO!VyO!WyO!XyO!YyO!ZzO!]yO!^yO!_yOg!RXh!RXv!RX!u!RX!z!RX&O!RX&Q!RX&s!RX&^!RX~O$g!RX~P3^O|#kO~P]Og^Oh^Ov#pO!u#rO!z#qO&O!wO&QWO&s#oO~O$g#sO~P4|Ou#uO&u#vO!P&SX#_&SX#a&SX#b&SX#d&SX#e&SX#f&SX#g&SX#h&SX#j&SX#n&SX#q&SX&]&SX&^&SX&m&SX~OW#tOY&SX#o&SXs&SXq&SX|&SX~P5oO!b#wO#]#wOW&TXu&TX!P&TX#_&TX#a&TX#b&TX#d&TX#e&TX#f&TX#g&TX#h&TX#j&TX#n&TX#q&TX&]&TX&^&TX&m&TX&u&TXY&TX#o&TXs&TXq&TX|&TX~OZ#XX~P7^OZ#xO~O&u#vO~O#_#|O#a#}O#b$OO#d$QO#e$RO#f$SO#g$TO#h$UO#j$YO#n$VO#q$WO&]#zO&^#zO&m#{O~O!P$XO~P9`O&w$ZO~OZ`O_VO`VOaVObVOcVOeVOg^Oh^Op!POwkOz!OO#fpO#qoO#spO#tpO%|TO&O0qO&Q0pO&WUO~O#o$_O~O![$aO~O&O#SO&Q#SO~Og^Oh^O&O!wO&QWO&^#YO~OW$gO&u#vO~O#y!{O~O!W$kO&OSO&Q!qO~OZ$lO~OZ$oO~O!P$vO&O$uO&Q$uO~O!P$xO&O$uO&Q$uO~O!P${O~P:jOZ%OO}cO~OW&[Xu&[X%|&[X&O&[X&Q&[X&^&[X~OZ!aX~P>YOWiXuiX%|iX&OiX&QiX&^iX~OZ!aX~P>uOu#OO%|TO&O#SO&Q#SO~O%|TO~P3^Og^Oh^Ov#pO!u#rO!z#qO&^!hO&s#oO~O&O!cO&Q!dO~P?wOg^Oh^O%|TO&O!cO&Q!dO~O}cO!P%aO~OZ%bO~O}%dO!m%gO~O}cOg&fXh&fXv&fX!S&fX!T&fX!U&fX!V&fX!W&fX!X&fX!Y&fX!Z&fX!]&fX!^&fX!_&fX!u&fX!z&fX%|&fX&O&fX&Q&fX&^&fX&s&fX~OW%jOZ%kOgTahTa%|Ta&OTa&QTa~OvTa!STa!TTa!UTa!VTa!WTa!XTa!YTa!ZTa!]Ta!^Ta!_Ta!uTa!zTa#xTa#yTa$VTa$gTa&sTa&^TauTaYTaqTa|Ta!PTa~PBxO&V%nO&X!tO~Ou#OO%|TOqma&]maYma&mma!Pma~O&uma}ma!rma~PE[O!SyO!TyO!UyO!VyO!WyO!XyO!YyO!ZzO!]yO!^yO!_yO~Og!Rah!Rav!Ra!u!Ra!z!Ra$g!Ra&O!Ra&Q!Ra&s!Ra&^!Ra~PFQO#y%pO~Os%rO~Ou%sO%|TO~Ou#OO%|ra&Ora&Qra&uraYrawra&mra&pra!Pra&]raqra~OWra#_ra#ara#bra#dra#era#fra#gra#hra#jra#nra#qra&^ra#orasra|ra~PG{Ou#OO%|TOq&hX!P&hX!b&hX~OY&hX#o&hX~PIyO!b%vOq!`X!P!`XY!`X~Oq%wO!P&gX~O!P%yO~Ov%zO~Og^Oh^O%|0oO&O!wO&QWO&a%}O~O&]&_P~PKWO%|TO&O!wO&QWO~OW&PXYiXY!aXY&PXZ&PXq!aXu&PXwiX!b&PX#]&PX#_&PX#a&PX#b&PX#d&PX#e&PX#f&PX#g&PX#h&PX#j&PX#n&PX#q&PX&]&PX&^&PX&miX&m&PX&piX&uiX&u&PX&w!aX~P>uOWUXYUXY!aXY&[XZUXq!aXuUXw&[X!bUX#]UX#_UX#aUX#bUX#dUX#eUX#fUX#gUX#hUX#jUX#nUX#qUX&]UX&^UX&mUX&m&[X&p&[X&uUX&u&[X&w!aX~P>YOg^Oh^O%|TO&O!wO&QWOg!RXh!RX&O!RX&Q!RX~PFQOu#OOw&XO%|TO&O&UO&Q&TO&p&WO~OW#XOY&`X&m&`X&u&`X~P!!mOY&ZO~P9`Og^Oh^O&O!wO&QWO~Oq&]OY&oX~OY&_O~Og^Oh^O%|TO&O!wO&QWOY&oP~PFQOY&dO&m&bO&u#vO~Oq&eO&w$ZOY&vX~OY&gO~O%|TOg%aah%aav%aa!S%aa!T%aa!U%aa!V%aa!W%aa!X%aa!Y%aa!Z%aa!]%aa!^%aa!_%aa!u%aa!z%aa$g%aa&O%aa&Q%aa&s%aa&^%aa~O|&hO~P]O}&iO~Op&uOw&vO&OSO&Q!qO&^#YO~Oz&tO~P!&|Oz&xO&OSO&Q!qO&^#YO~OY&dP~P:jOg^Oh^O%|TO&O!wO&QWO~O}cO~P:jOW#XOu#OO%|TO&u&`X~O#q$WO!P#ra#_#ra#a#ra#b#ra#d#ra#e#ra#f#ra#g#ra#h#ra#j#ra#n#ra&]#ra&^#ra&m#raY#ra#o#ras#raq#ra|#ra~Oo'_O}'^O!r'`O&^!hO~O}'eO!r'`O~Oo'iO}'hO&^!hO~OZ#xOu'mO%|TO~OW%jO}'sO~OW%jO!P'uO~OW'vO!P'wO~O$g!WO&O0qO&Q0pO!P&dP~P/lO!P(SO#o(TO~P9`O}(UO~O$b(WO~O!P(XO~O!P(YO~O!P(ZO~P9`O!P(]O~P9`OZ$lO_VO`VOaVObVOcVOeVOg^Oh^Op!POwkOz!OO%|TO&O(_O&Q(^O&WUO~PFQO%P(hO%T(iOZ$|a_$|a`$|aa$|ab$|ac$|ae$|ag$|ah$|ap$|av$|aw$|az$|a}$|a!P$|a!S$|a!T$|a!U$|a!V$|a!W$|a!X$|a!Y$|a!Z$|a![$|a!]$|a!^$|a!_$|a!u$|a!z$|a#f$|a#q$|a#s$|a#t$|a#x$|a#y$|a$V$|a$X$|a$_$|a$b$|a$d$|a$g$|a$k$|a$m$|a$r$|a$t$|a$v$|a$x$|a${$|a$}$|a%v$|a%|$|a&O$|a&Q$|a&W$|a&s$|a|$|a$`$|a$p$|a~O}ra!rra&}ra~PG{OZ%bO~PIyO!P(mO~O!m%gO}&ka!P&ka~O}cO!P(pO~Oo(tOq!fX&]!fX~Oq(vO&]&lX~O&](xO~OZ`O_VO`VOaVObVOcVOeVOg^Oh^Op)UOv{Ow)TOz!OO|)PO}cO!PvO![!`O!u}O!z|O#fpO#qoO#spO#tpO#x!RO#y!QO$V!SO$X!TO$_!UO$b!VO$d!XO$g!WO$k!YO$m!ZO$r![O$t!]O$v!^O$x!_O${!aO$}!bO%|TO&ORO&QQO&WUO&^#YO&sdO~PFQO}%dO~O})]OY&yP~P:jOW%jO!P)dO~Os)eO~Ou#OO%|TOq&ha!P&ha!b&haY&ha#o&ha~O})fO~P:jOq%wO!P&ga~Og^Oh^O%|0oO&O!wO&QWO~O&a)mO~P!7zOu#OO%|TOq&`X&]&`XY&`X&m&`X!P&`X~O}&`X!r&`X~P!8dOo)oOp)oOqnX&]nX~Oq)pO&]&_X~O&])rO~Ou#OOw)tO%|TO&OSO&Q!qO~OYma&mma&uma~P!9rOW&PXY!aXq!aXu!aX%|!aX~OWUXY!aXq!aXu!aX%|!aX~OW)wO~Ou#OO%|TO&O#SO&Q#SO&p)yO~Og^Oh^O%|TO&O!wO&QWO~PFQOq&]OY&oa~Ou#OO%|TO&O#SO&Q#SO&p&WO~OY)|O~OY*PO&m&bO~Oq&eOY&va~Og^Oh^Ov{O|*XO!u}O%|TO&O!wO&QWO&sdO~PFQO!P*YO~OW^iZ#XXu^i!P^i!b^i#]^i#_^i#a^i#b^i#d^i#e^i#f^i#g^i#h^i#j^i#n^i#q^i&]^i&^^i&m^i&u^iY^i#o^is^iq^i|^i~OW*iO~Os*jO~P9`Oz*kO&OSO&Q!qO~O!P]iY]i#o]is]iq]i|]i~P9`Oq*lOY&dX!P&dX~P9`OY*nO~O#f$SO#g$TO#j$YO#q$WO!P#^i#_#^i#a#^i#b#^i#d#^i#e#^i#n#^i&]#^i&^#^i&m#^iY#^i#o#^is#^iq#^i|#^i~O#h$UO~P!@zO#_#|O#d$QO#e$RO#f$SO#g$TO#h$UO#j$YO#q$WO&]#zO&^#zO&m#{O!P#^i#b#^i#n#^iY#^i#o#^is#^iq#^i|#^i~O#a#^i~P!B`O#a#}O~P!B`O#_#|O#f$SO#g$TO#h$UO#j$YO#q$WO&]#zO&^#zO!P#^i#a#^i#b#^i#d#^i#e#^i#n#^iY#^i#o#^is#^iq#^i|#^i~O&m#^i~P!C{O#_#|O#f$SO#g$TO#h$UO#j$YO#q$WO&]#zO&^#zO&m#{O!P#^i#a#^i#b#^i#d#^i#n#^iY#^i#o#^is#^iq#^i|#^i~O#e$RO~P!EaO&m#{O~P!C{O#j$YO#q$WO!P#^i#_#^i#a#^i#b#^i#d#^i#e#^i#f#^i#h#^i#n#^i&]#^i&^#^i&m#^iY#^i#o#^is#^iq#^i|#^i~O#g$TO~P!F|O#g#^i~P!F|O#h#^i~P!@zO#o*oO~P9`O#_&`X#a&`X#b&`X#d&`X#e&`X#f&`X#g&`X#h&`X#j&`X#n&`X#q&`X&^&`X#o&`Xs&`X|&`X~P!8dO!P#kiY#ki#o#kis#kiq#ki|#ki~P9`O|*rO~P$wO}'^O~O}'^O!r'`O~Oo'_O}'^O!r'`O~O%|TO&O#SO&Q#SO|&rP!P&rP~PFQO}'eO~Og^Oh^Ov{O|+PO!P*}O!u}O!z|O%|TO&O!wO&QWO&^!hO&sdO~PFQO}'hO~Oo'iO}'hO~Os+RO~P:jOu+TO%|TO~Ou'mO})fO%|TOW#Zi!P#Zi#_#Zi#a#Zi#b#Zi#d#Zi#e#Zi#f#Zi#g#Zi#h#Zi#j#Zi#n#Zi#q#Zi&]#Zi&^#Zi&m#Zi&u#ZiY#Zi#o#Zis#Ziq#Zi|#Zi~O}'^OW&ciu&ci!P&ci#_&ci#a&ci#b&ci#d&ci#e&ci#f&ci#g&ci#h&ci#j&ci#n&ci#q&ci&]&ci&^&ci&m&ci&u&ciY&ci#o&cis&ciq&ci|&ci~O#|+]O$O+^O$Q+^O$R+_O$S+`O~O|+[O~P#!`O$Y+aO&OSO&Q!qO~OW+bO!P+cO~O$`+dOZ$^i_$^i`$^ia$^ib$^ic$^ie$^ig$^ih$^ip$^iv$^iw$^iz$^i}$^i!P$^i!S$^i!T$^i!U$^i!V$^i!W$^i!X$^i!Y$^i!Z$^i![$^i!]$^i!^$^i!_$^i!u$^i!z$^i#f$^i#q$^i#s$^i#t$^i#x$^i#y$^i$V$^i$X$^i$_$^i$b$^i$d$^i$g$^i$k$^i$m$^i$r$^i$t$^i$v$^i$x$^i${$^i$}$^i%v$^i%|$^i&O$^i&Q$^i&W$^i&s$^i|$^i$p$^i~Og^Oh^O$g#sO&O!wO&QWO~O!P+hO~P:jO!P+iO~OZ`O_VO`VOaVObVOcVOeVOg^Oh^Op!POv{OwkOz!OO}cO!PvO!SyO!TyO!UyO!VyO!WyO!XyO!YyO!Z+nO![!`O!]yO!^yO!_yO!u}O!z|O#fpO#qoO#spO#tpO#x!RO#y!QO$V!SO$X!TO$_!UO$b!VO$d!XO$g!WO$k!YO$m!ZO$p+oO$r![O$t!]O$v!^O$x!_O${!aO$}!bO%|TO&ORO&QQO&WUO&sdO~O|+mO~P#'rOW&PXY&PXZ&PXu&PX!P&PX&uiX&u&PX~P>uOWUXYUXZUXuUX!PUX&uUX&u&[X~P>YOW#tOu#uO&u#vO~OW&TXY%WXu&TX!P%WX&u&TX~OZ#XX~P#,wOY+uO!P+sO~O%P(hO%T(iOZ$|i_$|i`$|ia$|ib$|ic$|ie$|ig$|ih$|ip$|iv$|iw$|iz$|i}$|i!P$|i!S$|i!T$|i!U$|i!V$|i!W$|i!X$|i!Y$|i!Z$|i![$|i!]$|i!^$|i!_$|i!u$|i!z$|i#f$|i#q$|i#s$|i#t$|i#x$|i#y$|i$V$|i$X$|i$_$|i$b$|i$d$|i$g$|i$k$|i$m$|i$r$|i$t$|i$v$|i$x$|i${$|i$}$|i%v$|i%|$|i&O$|i&Q$|i&W$|i&s$|i|$|i$`$|i$p$|i~OZ+xO~O%P(hO%T(iOZ%Ui_%Ui`%Uia%Uib%Uic%Uie%Uig%Uih%Uip%Uiv%Uiw%Uiz%Ui}%Ui!P%Ui!S%Ui!T%Ui!U%Ui!V%Ui!W%Ui!X%Ui!Y%Ui!Z%Ui![%Ui!]%Ui!^%Ui!_%Ui!u%Ui!z%Ui#f%Ui#q%Ui#s%Ui#t%Ui#x%Ui#y%Ui$V%Ui$X%Ui$_%Ui$b%Ui$d%Ui$g%Ui$k%Ui$m%Ui$r%Ui$t%Ui$v%Ui$x%Ui${%Ui$}%Ui%v%Ui%|%Ui&O%Ui&Q%Ui&W%Ui&s%Ui|%Ui$`%Ui$p%Ui~Ou#OO%|TO}&na!P&na!m&na~O!P,OO~Oo(tOq!fa&]!fa~Oq(vO&]&la~O!m%gO}&ki!P&ki~O|,XO~P]OW,ZO~P5oOW&TXu&TX#_&TX#a&TX#b&TX#d&TX#e&TX#f&TX#g&TX#h&TX#j&TX#n&TX#q&TX&]&TX&^&TX&m&TX&u&TX~OZ#xO!P&TX~P#7OOW$gOZ#xO&u#vO~Op,]Ow,]O~Oq,^O}&qX!P&qX~O!b,`O#]#wOY&TXZ#XX~P#7OOY&RXq&RX|&RX!P&RX~P9`O})]O|&xP~P:jOY&RXg%ZXh%ZX%|%ZX&O%ZX&Q%ZXq&RX|&RX!P&RX~Oq,cOY&yX~OY,eO~O})fO|&jP~P:jOq&iX!P&iX|&iXY&iX~P9`O&aTa~PBxOo)oOp)oOqna&]na~Oq)pO&]&_a~OW,mO~Ow,nO~Ou#OO%|TO&O,rO&Q,qO~Og^Oh^Ov#pO!u#rO&O!wO&QWO&s#oO~Og^Oh^Ov{O|,wO!u}O%|TO&O!wO&QWO&sdO~PFQOw-SO&OSO&Q!qO&^#YO~Oq*lOY&da!P&da~O#_ma#ama#bma#dma#ema#fma#gma#hma#jma#nma#qma&^ma#omasma|ma~PE[O|-WO~P$wOZ#xO}'^Oq!|X|!|X!P!|X~Oq-[O|&rX!P&rX~O|-_O!P-^O~O&^!hO~P4|Og^Oh^Ov{O|-cO!P*}O!u}O!z|O%|TO&O!wO&QWO&^!hO&sdO~PFQOs-dO~P9`Os-dO~P:jO}'^OW&cqu&cq!P&cq#_&cq#a&cq#b&cq#d&cq#e&cq#f&cq#g&cq#h&cq#j&cq#n&cq#q&cq&]&cq&^&cq&m&cq&u&cqY&cq#o&cqs&cqq&cq|&cq~O|-hO~P#!`O!W-lO#}-lO&OSO&Q!qO~O!P-oO~O$Y-pO&OSO&Q!qO~O!b%vO#o-rOq!`X!P!`X~O!P-tO~P9`O!P-tO~P:jO!P-wO~P9`O|-yO~P#'rO![$aO#o-zO~O!P-|O~O!b-}O~OY.QOZ$lO_VO`VOaVObVOcVOeVOg^Oh^Op!POwkOz!OO%|TO&O(_O&Q(^O&WUO~PFQOY.QO!P.RO~O%P(hO%T(iOZ%Uq_%Uq`%Uqa%Uqb%Uqc%Uqe%Uqg%Uqh%Uqp%Uqv%Uqw%Uqz%Uq}%Uq!P%Uq!S%Uq!T%Uq!U%Uq!V%Uq!W%Uq!X%Uq!Y%Uq!Z%Uq![%Uq!]%Uq!^%Uq!_%Uq!u%Uq!z%Uq#f%Uq#q%Uq#s%Uq#t%Uq#x%Uq#y%Uq$V%Uq$X%Uq$_%Uq$b%Uq$d%Uq$g%Uq$k%Uq$m%Uq$r%Uq$t%Uq$v%Uq$x%Uq${%Uq$}%Uq%v%Uq%|%Uq&O%Uq&Q%Uq&W%Uq&s%Uq|%Uq$`%Uq$p%Uq~Ou#OO%|TO}&ni!P&ni!m&ni~O&m&bOq!ga&]!ga~O!m%gO}&kq!P&kq~O|.^O~P]Op.`Ow&vOz&tO&OSO&Q!qO&^#YO~O!P.aO~Oq,^O}&qa!P&qa~O})]O~P:jOq.gO|&xX~O|.iO~Oq,cOY&ya~Oq.mO|&jX~O|.oO~Ow.pO~Oq!aXu!aX!P!aX!b!aX%|!aX~OZ&PX~P#MdOZUX~P#MdO!P.qO~OZ.rO~OW^yZ#XXu^y!P^y!b^y#]^y#_^y#a^y#b^y#d^y#e^y#f^y#g^y#h^y#j^y#n^y#q^y&]^y&^^y&m^y&u^yY^y#o^ys^yq^y|^y~OY%_aq%_a!P%_a~P9`O!P#myY#my#o#mys#myq#my|#my~P9`O}'^Oq!|a|!|a!P!|a~OZ#xO}'^Oq!|a|!|a!P!|a~O%|TO&O#SO&Q#SOq%iX|%iX!P%iX~PFQOq-[O|&ra!P&ra~O|!}X~P$wO|/PO~Os/QO~P9`OW%jO!P/RO~OW%jO$P/WO&OSO&Q!qO!P&{P~OW%jO$T/XO~O!P/YO~O!b%vO#o/[Oq!`X!P!`X~OY/^O~O!P/_O~P9`O#o/`O~P9`O!b/bO~OY/cOZ$lO_VO`VOaVObVOcVOeVOg^Oh^Op!POwkOz!OO%|TO&O(_O&Q(^O&WUO~PFQOW#[Ou&ZX%|&ZX&O&ZX&Q&ZX&}&ZX~O&^#YO~P$'fOu#OO%|TO&}/eO&O%RX&Q%RX~O&m&bOq!gi&]!gi~Op/iO&OSO&Q!qO~OW*iOZ#xO~O!P/kO~OY&RXq&RX~P9`O})]Oq%mX|%mX~P:jOq.gO|&xa~O!b/nO~O})fOq%bX|%bX~P:jOq.mO|&ja~OY/qO~O!P/rO~OZ/sO~O}'^Oq!|i|!|i!P!|i~O|!}a~P$wOW%jO!P/wO~OW%jOq/xO!P&{X~OY/|O~P9`OY0OO~OY%Wq!P%Wq~P9`O&}/eO&O%Ra&Q%Ra~OY0TO~O!P0WO~Ou#OO!P0YO!Z0ZO%|TO~OY0[O~Oq/xO!P&{a~O!P0_O~OW%jOq/xO!P&|X~OY0aO~P9`OY0bO~OY%Wy!P%Wy~P9`Ou#OO%|TO&O%ta&Q%ta&}%ta~OY0cO~O!P0dO~Ou#OO!P0eO!Z0fO%|TO~OW%jOq%qa!P%qa~Oq/xO!P&|a~O!P0jO~Ou#OO!P0jO!Z0kO%|TO~O!P0lO~O!P0nO~O#o&PXY&PXs&PXq&PX|&PX~P&bO#oUXYUXsUXqUX|UX~P(fO`Q_P#g%x&O&Wc&W~",
	goto: "#+R&}PPPP'O'c*w-}P'cPP.c.g0OPPPPP1mP3YPP4u7k:Z<y=c?ZPPP?aPAzPPPBt3YPDpPPEkPFbFjPPPPPPPPPPPPGuH^PKiKqK}LiLoLuNhNlNlNtP! T!!]!#Q!#[P!#q!!]P!#w!$R!!x!$bP!%R!%]!%c!!]!%f!%lFbFb!%p!%z!%}3Y!'l3Y3Y!)hP.gP!)lPP!*^PPPPP.gP.g!*}.gPP.gP.gPP.g!,f!,pPP!,v!-PPPPPPPPP'OP'OPP!-T!-T!-h!-TPP!-TP!-TP!.R!.UP!-T!.l!-TP!-TP!.o!.rP!-TP!-TP!-TP!-TP!-T!-TP!-TP!.vP!.|!/P!/VP!-T!/c!/fP!/n!0Q!4S!4Y!4`!5f!5l!5z!7Q!7W!7^!7h!7n!7t!7z!8Q!8W!8^!8d!8j!8p!8v!8|!9S!9^!9d!9n!9tPPP!9z!-T!:oP!>VP!?ZP!Ao!BV!E[3YPPP!F{!Jl!M`PP#!O#!RP#$_#$e#&U#&e#&m#'o#(X#)S#)]#)`#)nP#)q#)}P#*U#*]P#*`P#*kP#*n#*q#*t#*x#+OstOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,Y'urOPXY`acopx!Y![!_!a!e!f!h!i!o!x#P#T#Y#[#_#`#e#i#l#n#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$[$]$_$e$l$m$n$o$p$q%O%S%V%Z%^%_%b%d%g%k%u%v%{%|&R&S&[&]&`&b&d&i'X'^'_'`'e'h'i'm'n'p'{'|(O(T(U(`(l(t(v({(})O)Q)R)])f)o)p*P*T*W*l*o*p*q*z*{+O+T+d+f+h+i+l+o+r+s+x+},W,Y,^,`,u-[-^-a-r-t-}.R.V.g.m/O/[/_/b/d/n/q0R0X0Z0[0f0h0k0r#xhO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%d%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o,Y,`-r-t-}.g.m/[/_/b/n0Z0f0kt!sT!Q!S!T!{!}$k%p+]+^+_+`-k-m/W/X/x0oQ#mdS&Y#`(}Q&l#oU&q#t$g,ZQ&x#vW(b%O+s.R/dU)Y%j'v+bQ)Z%kS)u&S,WU*f&s-R._Q*k&yQ,t*TQ-P*iQ.j,cR.t,uu!sT!Q!S!T!{!}$k%p+]+^+_+`-k-m/W/X/x0oT%l!r)l#{qO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o,Y,`-r-t-}.g.m/[/_/b/n0Z0f0k#zlO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o,Y,`-r-t-}.g.m/[/_/b/n0Z0f0kX(c%O+s.R/d$TVO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%O%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o+s,Y,`-r-t-}.R.g.m/[/_/b/d/n0Z0f0k$TkO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%O%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o+s,Y,`-r-t-}.R.g.m/[/_/b/d/n0Z0f0k&O[OPX`ceopx!O!Y![!_!a!g!i!o#Y#_#b#e#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$[$_$f$l$m$n$o$p$q%O%_%b%d%g%k%v%{&]&b&d&i&t'^'_'`'h'i'm'{'}(O(T(U(d(t)O)Q)R)])f)o)p*P*U*W*l*o*q*{*|+O+T+d+h+i+l+o+s,Y,^,`-^-r-t-}.R.g.m/O/[/_/b/d/n0Z0f0k0rQ&Q#[Q)s&RV.T+x.X/e&O[OPX`ceopx!O!Y![!_!a!g!i!o#Y#_#b#e#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$[$_$f$l$m$n$o$p$q%O%_%b%d%g%k%v%{&]&b&d&i&t'^'_'`'h'i'm'{'}(O(T(U(d(t)O)Q)R)])f)o)p*P*U*W*l*o*q*{*|+O+T+d+h+i+l+o+s,Y,^,`-^-r-t-}.R.g.m/O/[/_/b/d/n0Z0f0k0rV.T+x.X/e&O]OPX`ceopx!O!Y![!_!a!g!i!o#Y#_#b#e#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$[$_$f$l$m$n$o$p$q%O%_%b%d%g%k%v%{&]&b&d&i&t'^'_'`'h'i'm'{'}(O(T(U(d(t)O)Q)R)])f)o)p*P*U*W*l*o*q*{*|+O+T+d+h+i+l+o+s,Y,^,`-^-r-t-}.R.g.m/O/[/_/b/d/n0Z0f0k0rV.U+x.X/eS#Z[.TS$f!O&tS&s#t$gQ&y#vQ)V%dQ-R*iR._,Z$kZO`copx!Y![!_!a#Y#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$_$l$m$n$o$p$q%O%d%g%k%v&b&d'_'`'i'm(O(T(U(t)Q)R)])f)o)p*P*l*o+T+d+h+i+l+o+s,Y,^,`-r-t-}.R.g.m/[/_/b/d/n0Z0f0kQ&O#YR,k)p&P_OPX`ceopx!Y![!_!a!g!i!o#Y#_#b#e#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$[$_$l$m$n$o$p$q%O%_%b%d%g%k%v%{&]&b&d&i'^'_'`'h'i'm'{'}(O(T(U(d(t)O)Q)R)])f)o)p*P*U*W*l*o*q*{*|+O+T+d+h+i+l+o+s+x,Y,^,`-^-r-t-}.R.X.g.m/O/[/_/b/d/e/n0Z0f0k0r!o#QY!e!x#R#T#`#n$]%R%S%V%^%u%|&S&[&`'X'|(`(l({(}*T*p*z+f+r+},W,u-a.V/q0R0X0[0h$SkO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%O%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o+s,Y,`-r-t-}.R.g.m/[/_/b/d/n0Z0f0kQ$m!UQ$n!VQ$s!ZQ$|!`R+p(WQ#yiS'q$e*hQ*e&rQ+X'rS,[)T)UQ-O*gQ-Y*vQ.b,]Q.x-QQ.{-ZQ/j.`Q/u.yR0V/iQ'a$bW*[&m'b'c'dQ+W'qU,x*]*^*_Q-X*vQ-f+XS.u,y,zS.z-Y-ZQ/t.vR/v.{]!mP!o'^*q-^/OreOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,Y[!gP!o'^*q-^/OW#b`#e%b&]Q'}$oW(d%O+s.R/dS*U&i*WS*w'e-[S*|'h+OR.X+xh#VY!W!e#n#s%V'|*T*z+f,u-aQ)j%wQ)v&WR,o)y#xnOcopx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o,Y,`-r-t-}.g.m/[/_/b/n0Z0f0k^!kP!g!o'^*q-^/Ov#TY!W#`#n#s%w&W&[&`'|(`(})y*T+f+r,u.W/hQ#g`Q$b{Q$c|Q$d}W%S!e%V*z-aS%Y!h(vQ%`!iQ&m#pQ&n#qQ&o#rQ(u%ZS(y%^({Q*R&eS*v'e-[R-Z*wU)h%v)f.mR+V'p[!mP!o'^*q-^/OT*}'h+O^!iP!g!o'^*q-^/OQ'd$bQ'l$dQ*_&mQ*d&oV*{'h*|+OQ%[!hR,S(vQ(s%YR,R(u#znO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o,Y,`-r-t-}.g.m/[/_/b/n0Z0f0kQ%c!kS(l%S(yR(|%`T#e`%bU#c`#e%bR)z&]Q%f!lQ(n%UQ(r%XQ,U(zR.],VrvOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,Y[!mP!o'^*q-^/OQ%P!bQ%a!jQ%i!pQ'[$ZQ([$|Q(k%QQ(p%WQ+z(iR.Y+yrtOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,Y[!mP!o'^*q-^/OS*V&i*WT*}'h+OQ'c$bS*^&m'dR,z*_Q'b$bQ'g$cU*]&m'c'dQ*a&nS,y*^*_R.v,zQ*u'`R+Q'iQ'k$dS*c&o'lR,}*dQ'j$dU*b&o'k'lS,|*c*dR.w,}rtOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,Y[!mP!o'^*q-^/OT*}'h+OQ'f$cS*`&n'gR,{*aQ*x'eR.|-[R-`*yQ&j#mR*Z&lT*V&i*WQ%e!lS(q%X%fR,P(rR)R%dWk%O+s.R/d#{lO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o,Y,`-r-t-}.g.m/[/_/b/n0Z0f0k$SiO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%O%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o+s,Y,`-r-t-}.R.g.m/[/_/b/d/n0Z0f0kU&r#t$g,ZS*g&s._Q-Q*iR.y-RT'o$e'p!_#|m#a$r$z$}&w&z&{'O'P'Q'R'S'W'Z)[)g+S+g+j-T-V-e-v-{.e/Z/a/}0Q!]$Pm#a$r$z$}&w&z&{'O'P'R'S'W'Z)[)g+S+g+j-T-V-e-v-{.e/Z/a/}0Q#{nO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o,Y,`-r-t-}.g.m/[/_/b/n0Z0f0ka)^%k)],`.g/n0Z0f0kQ)`%kR.k,cQ't$hQ)b%oR,f)cT+Y's+ZsvOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,YruOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,YQ$w!]R$y!^R$p!XrvOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,YR(O$oR$q!XR(V$sT+k(U+lX(f%P(g(k+{R+y(hQ.W+xR/h.XQ(j%PQ+w(gQ+|(kR.Z+{R%Q!bQ(e%OV.P+s.R/dQxOQ#lcW$`x#l)Q,YQ)Q%dR,Y)RrXOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,Yn!fP!o#e&]&i'^'e'h*W*q+O+x-[-^/Ol!zX!f#P#_#i$[%Z%_%{&R'n'{)O0r!j#PY!e!x#T#`#n$]%S%V%^%u%|&S&[&`'X'|(`(l({(}*T*p*z+f+r+},W,u-a.V/q0R0X0[0hQ#_`Q#ia#d$[op!Y!_!a#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$l%g%k%v&b&d'_'`'i'm(O(T(t)])f)o*P*l*o+T+h+i+o,^,`-r-t-}.g.m/[/_/b/n0Z0f0kS%Z!h(vS%_!i*{S%{#Y)pQ&R#[S'n$e'pY'{$o%O+s.R/dQ)O%bR0r$YQ!uUR%m!uQ)q&OR,l)q^#RY#`$]'X'|(`*px%R!e!x#n%V%^%|&S&[&`({(}*T*z+f+r,W,u-a.V0R[%t#R%R%u+}0X0hS%u#T%SQ+}(lQ0X/qR0h0[Q*m&{R-U*mQ!oPU%h!o*q/OQ*q'^R/O-^!pbOP`cx![!o#e#l$_$m$n$o$p$q%O%b%d&]&i'^'e'h(U)Q)R*W*q+O+d+l+s+x,Y-[-^.R/O/dY!yX!f#_'{)OT#jb!yQ.n,gR/p.nQ%x#VR)k%xQ&c#fS*O&c.[R.[,QQ(w%[R,T(wQ&^#cR){&^Q,_)WR.d,_Q+O'hR-b+OQ-]*xR.}-]Q*W&iR,v*WQ'p$eR+U'pQ&f#gR*S&fQ.h,aR/m.hQ,d)`R.l,dQ+Z'sR-g+ZQ-k+]R/T-kQ/y/US0^/y0`R0`/{Q+l(UR-x+lQ(g%PS+v(g+{R+{(kQ/f.VR0S/fQ+t(eR.S+t`wOcx#l%d)Q)R,YQ$t![Q']$_Q'y$mQ'z$nQ(Q$pQ(R$qS+k(U+lR-q+d'dsOPXY`acopx!Y![!_!a!e!f!h!i!o!x#P#T#Y#[#_#`#e#i#l#n#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$[$]$_$e$l$m$n$o$p$q%O%S%V%Z%^%_%b%d%g%u%v%{%|&R&S&[&]&`&b&d&i'X'^'_'`'e'h'i'm'n'p'{'|(O(T(U(`(l(t(v({(})O)Q)R)f)o)p*P*T*W*l*o*p*q*z*{+O+T+d+f+h+i+l+o+r+s+x+},W,Y,^,u-[-^-a-r-t-}.R.V.m/O/[/_/b/d/q0R0X0[0h0ra)_%k)],`.g/n0Z0f0kQ!rTQ$h!QQ$i!SQ$j!TQ%o!{Q%q!}Q'x$kQ)c%pQ)l0oS-i+]+_Q-m+^Q-n+`Q/S-kS/U-m/WQ/{/XR0]/x%uSOT`cdopx!Q!S!T!Y![!_!a!{!}#`#l#o#t#u#v#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$g$k$l$m$n$o$p$q%O%d%j%k%p%v&S&d&s&y'm'v(O(T(U(})Q)R)])f*P*T*i*l*o+T+]+^+_+`+b+d+h+i+l+o+s,W,Y,Z,`,c,u-R-k-m-r-t-}.R._.g.m/W/X/[/_/b/d/n/x0Z0f0k0oQ)a%kQ,a)]S.f,`/nQ/l.gQ0g0ZQ0i0fR0m0krmOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,YS#a`$lQ$WoQ$^pQ$r!YQ$z!_Q$}!aQ&w#uQ&z#wY&{#x$o+h-t/_Q&}#|Q'O#}Q'P$OQ'Q$PQ'R$QQ'S$RQ'T$SQ'U$TQ'V$UQ'W$VQ'Z$Z^)[%k)].g/n0Z0f0kU)g%v)f.mQ*Q&dQ+S'mQ+g(OQ+j(TQ,p*PQ-T*lQ-V*oQ-e+TQ-v+iQ-{+oQ.e,`Q/Z-rQ/a-}Q/}/[R0Q/b#xgO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o,Y,`-r-t-}.g.m/[/_/b/n0Z0f0kW(a%O+s.R/dR)S%drYOcx![#l$_$m$n$p$q%d(U)Q)R+d+l,Y[!eP!o'^*q-^/OW!xX$[%{'{Q#``Q#ne#S$]op!Y!_!a#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$l%k%v&d'm(O(T)])f*P*l*o+T+h+i+o,`-r-t-}.g.m/[/_/b/n0Z0f0kQ%V!gS%^!i*{d%|#Y%g&b'_'`'i(t)o)p,^Q&S#_Q&[#bS&`#e&]Q'X$YQ'|$oW(`%O+s.R/dQ({%_Q(}%bS*T&i*WQ*p0rS*z'h+OQ+f'}Q+r(dQ,W)OQ,u*UQ-a*|S.V+x.XR0R/e&O_OPX`ceopx!Y![!_!a!g!i!o#Y#_#b#e#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$[$_$l$m$n$o$p$q%O%_%b%d%g%k%v%{&]&b&d&i'^'_'`'h'i'm'{'}(O(T(U(d(t)O)Q)R)])f)o)p*P*U*W*l*o*q*{*|+O+T+d+h+i+l+o+s+x,Y,^,`-^-r-t-}.R.X.g.m/O/[/_/b/d/e/n0Z0f0k0rQ$e!OQ'r$fR*h&t&ZWOPX`ceopx!O!Y![!_!a!g!i!o#Y#[#_#b#e#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Y$Z$[$_$f$l$m$n$o$p$q%O%_%b%d%g%k%v%{&R&]&b&d&i&t'^'_'`'h'i'm'{'}(O(T(U(d(t)O)Q)R)])f)o)p*P*U*W*l*o*q*{*|+O+T+d+h+i+l+o+s+x,Y,^,`-^-r-t-}.R.X.g.m/O/[/_/b/d/e/n0Z0f0k0rR&P#Y$QjOcopx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%O%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o+s,Y,`-r-t-}.R.g.m/[/_/b/d/n0Z0f0kQ#f`Q&O#YQ'Y$YU)W%g'`'iQ)}&bQ*s'_Q,Q(tQ,j)oQ,k)pR.c,^Q)n%}R,i)m$SfO`copx!Y![!_!a#l#u#w#x#|#}$O$P$Q$R$S$T$U$V$Z$_$l$m$n$o$p$q%O%d%k%v&d'm(O(T(U)Q)R)])f*P*l*o+T+d+h+i+l+o+s,Y,`-r-t-}.R.g.m/[/_/b/d/n0Z0f0kT&p#t,ZQ&|#xQ(P$oQ-u+hQ/]-tR0P/_]!nP!o'^*q-^/O#PaOPX`bcx![!f!o!y#_#e#l$_$m$n$o$p$q%O%b%d&]&i'^'e'h'{(U)O)Q)R*W*q+O+d+l+s+x,Y-[-^.R/O/dU#WY!W'|Q%T!eU&k#n#s+fQ(o%VS,s*T*zT.s,u-aj#UY!W!e#n#s%V%w&W)y*T*z,u-aU&V#`&`(}Q)x&[Q+e'|Q+q(`Q-s+fQ.O+rQ/g.WR0U/hQ)i%vQ,g)fR/o.mR,h)f`!jP!o'^'h*q+O-^/OT%W!g*|R%]!hW%U!e%V*z-aQ(z%^R,V({S#d`%bR&a#eQ)X%gT*t'`'iR*y'e[!lP!o'^*q-^/OR%X!gR#h`R,b)]R)a%kT-j+]-kQ/V-mR/z/WR/z/X",
	nodeNames: "⚠ LineComment BlockComment Program ModuleDeclaration MarkerAnnotation Identifier ScopedIdentifier . Annotation ) ( AnnotationArgumentList AssignmentExpression FieldAccess IntegerLiteral FloatingPointLiteral BooleanLiteral CharacterLiteral StringLiteral TextBlock null ClassLiteral void PrimitiveType TypeName ScopedTypeName GenericType TypeArguments AnnotatedType Wildcard extends super , ArrayType ] Dimension [ class this ParenthesizedExpression ObjectCreationExpression new ArgumentList } { ClassBody ; FieldDeclaration Modifiers public protected private abstract static final strictfp default synchronized native transient volatile VariableDeclarator Definition AssignOp ArrayInitializer MethodDeclaration TypeParameters TypeParameter TypeBound FormalParameters ReceiverParameter FormalParameter SpreadParameter Throws throws Block ClassDeclaration Superclass SuperInterfaces implements InterfaceTypeList InterfaceDeclaration interface ExtendsInterfaces InterfaceBody ConstantDeclaration EnumDeclaration enum EnumBody EnumConstant EnumBodyDeclarations AnnotationTypeDeclaration AnnotationTypeBody AnnotationTypeElementDeclaration StaticInitializer ConstructorDeclaration ConstructorBody ExplicitConstructorInvocation ArrayAccess MethodInvocation MethodName MethodReference ArrayCreationExpression Dimension AssignOp BinaryExpression CompareOp CompareOp LogicOp LogicOp BitOp BitOp BitOp ArithOp ArithOp BitOp InstanceofExpression instanceof LambdaExpression InferredParameters TernaryExpression LogicOp : UpdateExpression UpdateOp UnaryExpression LogicOp BitOp CastExpression ElementValueArrayInitializer ElementValuePair open module ModuleBody ModuleDirective requires transitive exports to opens uses provides with PackageDeclaration package ImportDeclaration import Asterisk ExpressionStatement LabeledStatement Label IfStatement if else WhileStatement while ForStatement for ForSpec LocalVariableDeclaration var EnhancedForStatement ForSpec AssertStatement assert SwitchStatement switch SwitchBlock SwitchLabel case DoStatement do BreakStatement break ContinueStatement continue ReturnStatement return SynchronizedStatement ThrowStatement throw TryStatement try CatchClause catch CatchFormalParameter CatchType FinallyClause finally TryWithResourcesStatement ResourceSpecification Resource ClassContent",
	maxTerm: 275,
	nodeProps: [
		[
			"isolate",
			-4,
			1,
			2,
			18,
			19,
			""
		],
		[
			"group",
			-26,
			4,
			47,
			76,
			77,
			82,
			87,
			92,
			144,
			146,
			149,
			150,
			152,
			155,
			157,
			160,
			162,
			164,
			166,
			171,
			173,
			175,
			177,
			179,
			180,
			182,
			190,
			"Statement",
			-25,
			6,
			13,
			14,
			15,
			16,
			17,
			18,
			19,
			20,
			21,
			22,
			39,
			40,
			41,
			99,
			100,
			102,
			103,
			106,
			117,
			119,
			121,
			124,
			126,
			129,
			"Expression",
			-7,
			23,
			24,
			25,
			26,
			27,
			29,
			34,
			"Type"
		],
		[
			"openedBy",
			10,
			"(",
			44,
			"{"
		],
		[
			"closedBy",
			11,
			")",
			45,
			"}"
		]
	],
	propSources: [javaHighlighting],
	skippedNodes: [
		0,
		1,
		2
	],
	repeatNodeCount: 28,
	tokenData: "##i_R!_OX%QXY'fYZ)bZ^'f^p%Qpq'fqr*|rs,^st%Qtu2luv4Rvw5cwx6yxy?byz@Oz{@l{|Ab|}Bx}!OCf!O!PEP!P!QMy!Q!R!*o!R![!.Z![!]!:s!]!^!<T!^!_!<q!_!`!>[!`!a!?O!a!b!@l!b!c!A[!c!}!HW!}#O!Im#O#P%Q#P#Q!JZ#Q#R!Jw#R#S2l#S#T%Q#T#o2l#o#p!Kk#p#q!LX#q#r!Mq#r#s!N_#s#y%Q#y#z'f#z$f%Q$f$g'f$g#BY2l#BY#BZ!N{#BZ$IS2l$IS$I_!N{$I_$I|2l$I|$JO!N{$JO$JT2l$JT$JU!N{$JU$KV2l$KV$KW!N{$KW&FU2l&FU&FV!N{&FV;'S2l;'S;=`3{<%lO2lS%VV&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QS%qO&XSS%tVOY&ZYZ%lZr&Zrs&ys;'S&Z;'S;=`'`<%lO&ZS&^VOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QS&vP;=`<%l%QS&|UOY&ZYZ%lZr&Zs;'S&Z;'S;=`'`<%lO&ZS'cP;=`<%l&Z_'mk&XS%xZOX%QXY'fYZ)bZ^'f^p%Qpq'fqr%Qrs%qs#y%Q#y#z'f#z$f%Q$f$g'f$g#BY%Q#BY#BZ'f#BZ$IS%Q$IS$I_'f$I_$I|%Q$I|$JO'f$JO$JT%Q$JT$JU'f$JU$KV%Q$KV$KW'f$KW&FU%Q&FU&FV'f&FV;'S%Q;'S;=`&s<%lO%Q_)iY&XS%xZX^*Xpq*X#y#z*X$f$g*X#BY#BZ*X$IS$I_*X$I|$JO*X$JT$JU*X$KV$KW*X&FU&FV*XZ*^Y%xZX^*Xpq*X#y#z*X$f$g*X#BY#BZ*X$IS$I_*X$I|$JO*X$JT$JU*X$KV$KW*X&FU&FV*XV+TX#sP&XSOY%QYZ%lZr%Qrs%qs!_%Q!_!`+p!`;'S%Q;'S;=`&s<%lO%QU+wV#_Q&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QT,aXOY,|YZ%lZr,|rs1as#O,|#O#P0k#P;'S,|;'S;=`1Z<%lO,|T-PXOY-lYZ%lZr-lrs.^s#O-l#O#P.x#P;'S-l;'S;=`1T<%lO-lT-qX&XSOY-lYZ%lZr-lrs.^s#O-l#O#P.x#P;'S-l;'S;=`1T<%lO-lT.cVcPOY&ZYZ%lZr&Zrs&ys;'S&Z;'S;=`'`<%lO&ZT.}V&XSOY-lYZ%lZr-lrs/ds;'S-l;'S;=`1T<%lO-lT/gXOY,|YZ%lZr,|rs0Ss#O,|#O#P0k#P;'S,|;'S;=`1Z<%lO,|T0XUcPOY&ZYZ%lZr&Zs;'S&Z;'S;=`'`<%lO&ZT0nVOY-lYZ%lZr-lrs/ds;'S-l;'S;=`1T<%lO-lT1WP;=`<%l-lT1^P;=`<%l,|T1fVcPOY&ZYZ%lZr&Zrs1{s;'S&Z;'S;=`'`<%lO&ZT2QR&VSXY2ZYZ2gpq2ZP2^RXY2ZYZ2gpq2ZP2lO&WP_2sb&XS&OZOY%QYZ%lZr%Qrs%qst%Qtu2lu!Q%Q!Q![2l![!c%Q!c!}2l!}#R%Q#R#S2l#S#T%Q#T#o2l#o$g%Q$g;'S2l;'S;=`3{<%lO2l_4OP;=`<%l2lU4YX&XS#gQOY%QYZ%lZr%Qrs%qs!_%Q!_!`4u!`;'S%Q;'S;=`&s<%lO%QU4|V#]Q&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QV5jZ&mR&XSOY%QYZ%lZr%Qrs%qsv%Qvw6]w!_%Q!_!`4u!`;'S%Q;'S;=`&s<%lO%QU6dV#aQ&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QT7OZ&XSOY7qYZ%lZr7qrs9Psw7qwx%Qx#O7q#O#P:Z#P;'S7q;'S;=`?[<%lO7qT7vX&XSOY%QYZ%lZr%Qrs%qsw%Qwx8cx;'S%Q;'S;=`&s<%lO%QT8jVbP&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QT9SXOY&ZYZ%lZr&Zrs&ysw&Zwx9ox;'S&Z;'S;=`'`<%lO&ZT9tVbPOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QT:`Z&XSOY;RYZ%lZr;Rrs;ysw;Rwx7qx#O;R#O#P7q#P;'S;R;'S;=`=e<%lO;RT;WZ&XSOY;RYZ%lZr;Rrs;ysw;Rwx8cx#O;R#O#P%Q#P;'S;R;'S;=`=e<%lO;RT;|ZOY<oYZ%lZr<ors=ksw<owx9ox#O<o#O#P&Z#P;'S<o;'S;=`?U<%lO<oT<rZOY;RYZ%lZr;Rrs;ysw;Rwx8cx#O;R#O#P%Q#P;'S;R;'S;=`=e<%lO;RT=hP;=`<%l;RT=nZOY<oYZ%lZr<ors>asw<owx9ox#O<o#O#P&Z#P;'S<o;'S;=`?U<%lO<oP>dVOY>aZw>awx>yx#O>a#P;'S>a;'S;=`?O<%lO>aP?OObPP?RP;=`<%l>aT?XP;=`<%l<oT?_P;=`<%l7q_?iVZZ&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QV@VVYR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QV@uX$YP&XS#gQOY%QYZ%lZr%Qrs%qs!_%Q!_!`4u!`;'S%Q;'S;=`&s<%lO%QVAiZ#fR&XSOY%QYZ%lZr%Qrs%qs{%Q{|B[|!_%Q!_!`4u!`;'S%Q;'S;=`&s<%lO%QVBcV#qR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QVCPVqR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QVCm[#fR&XSOY%QYZ%lZr%Qrs%qs}%Q}!OB[!O!_%Q!_!`4u!`!aDc!a;'S%Q;'S;=`&s<%lO%QVDjV&wR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%Q_EWZWY&XSOY%QYZ%lZr%Qrs%qs!O%Q!O!PEy!P!Q%Q!Q![GX![;'S%Q;'S;=`&s<%lO%QVFOX&XSOY%QYZ%lZr%Qrs%qs!O%Q!O!PFk!P;'S%Q;'S;=`&s<%lO%QVFrV&pR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QTG`c&XS`POY%QYZ%lZr%Qrs%qs!Q%Q!Q![GX![!f%Q!f!gHk!g!hIX!h!iHk!i#R%Q#R#SMR#S#W%Q#W#XHk#X#YIX#Y#ZHk#Z;'S%Q;'S;=`&s<%lO%QTHrV&XS`POY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QTI^]&XSOY%QYZ%lZr%Qrs%qs{%Q{|JV|}%Q}!OJV!O!Q%Q!Q![Jw![;'S%Q;'S;=`&s<%lO%QTJ[X&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q![Jw![;'S%Q;'S;=`&s<%lO%QTKOc&XS`POY%QYZ%lZr%Qrs%qs!Q%Q!Q![Jw![!f%Q!f!gHk!g!h%Q!h!iHk!i#R%Q#R#SLZ#S#W%Q#W#XHk#X#Y%Q#Y#ZHk#Z;'S%Q;'S;=`&s<%lO%QTL`Z&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q![Jw![#R%Q#R#SLZ#S;'S%Q;'S;=`&s<%lO%QTMWZ&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q![GX![#R%Q#R#SMR#S;'S%Q;'S;=`&s<%lO%Q_NQ]&XS#gQOY%QYZ%lZr%Qrs%qsz%Qz{Ny{!P%Q!P!Q!'l!Q!_%Q!_!`4u!`;'S%Q;'S;=`&s<%lO%Q_! OX&XSOYNyYZ! kZrNyrs!#WszNyz{!$f{;'SNy;'S;=`!%z<%lONy_! pT&XSOz!!Pz{!!c{;'S!!P;'S;=`!#Q<%lO!!PZ!!STOz!!Pz{!!c{;'S!!P;'S;=`!#Q<%lO!!PZ!!fVOz!!Pz{!!c{!P!!P!P!Q!!{!Q;'S!!P;'S;=`!#Q<%lO!!PZ!#QOQZZ!#TP;=`<%l!!P_!#ZXOY!#vYZ! kZr!#vrs!&Qsz!#vz{!&p{;'S!#v;'S;=`!'f<%lO!#v_!#yXOYNyYZ! kZrNyrs!#WszNyz{!$f{;'SNy;'S;=`!%z<%lONy_!$kZ&XSOYNyYZ! kZrNyrs!#WszNyz{!$f{!PNy!P!Q!%^!Q;'SNy;'S;=`!%z<%lONy_!%eV&XSQZOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%Q_!%}P;=`<%lNy_!&TXOY!#vYZ! kZr!#vrs!!Psz!#vz{!&p{;'S!#v;'S;=`!'f<%lO!#v_!&sZOYNyYZ! kZrNyrs!#WszNyz{!$f{!PNy!P!Q!%^!Q;'SNy;'S;=`!%z<%lONy_!'iP;=`<%l!#v_!'sV&XSPZOY!'lYZ%lZr!'lrs!(Ys;'S!'l;'S;=`!)`<%lO!'l_!(_VPZOY!(tYZ%lZr!(trs!)fs;'S!(t;'S;=`!*i<%lO!(t_!(yVPZOY!'lYZ%lZr!'lrs!(Ys;'S!'l;'S;=`!)`<%lO!'l_!)cP;=`<%l!'l_!)kVPZOY!(tYZ%lZr!(trs!*Qs;'S!(t;'S;=`!*i<%lO!(tZ!*VSPZOY!*QZ;'S!*Q;'S;=`!*c<%lO!*QZ!*fP;=`<%l!*Q_!*lP;=`<%l!(tT!*vq&XS_POY%QYZ%lZr%Qrs%qs!O%Q!O!P!,}!P!Q%Q!Q![!.Z![!d%Q!d!e!1e!e!f%Q!f!gHk!g!hIX!h!iHk!i!n%Q!n!o!0P!o!z%Q!z!{!3c!{#R%Q#R#S!0m#S#U%Q#U#V!1e#V#W%Q#W#XHk#X#YIX#Y#ZHk#Z#`%Q#`#a!0P#a#l%Q#l#m!3c#m;'S%Q;'S;=`&s<%lO%QT!-Ua&XS`POY%QYZ%lZr%Qrs%qs!Q%Q!Q![GX![!f%Q!f!gHk!g!hIX!h!iHk!i#W%Q#W#XHk#X#YIX#Y#ZHk#Z;'S%Q;'S;=`&s<%lO%QT!.bi&XS_POY%QYZ%lZr%Qrs%qs!O%Q!O!P!,}!P!Q%Q!Q![!.Z![!f%Q!f!gHk!g!hIX!h!iHk!i!n%Q!n!o!0P!o#R%Q#R#S!0m#S#W%Q#W#XHk#X#YIX#Y#ZHk#Z#`%Q#`#a!0P#a;'S%Q;'S;=`&s<%lO%QT!0WV&XS_POY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QT!0rZ&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q![!.Z![#R%Q#R#S!0m#S;'S%Q;'S;=`&s<%lO%QT!1jY&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q!R!2Y!R!S!2Y!S;'S%Q;'S;=`&s<%lO%QT!2a`&XS_POY%QYZ%lZr%Qrs%qs!Q%Q!Q!R!2Y!R!S!2Y!S!n%Q!n!o!0P!o#R%Q#R#S!1e#S#`%Q#`#a!0P#a;'S%Q;'S;=`&s<%lO%QT!3h_&XSOY%QYZ%lZr%Qrs%qs!O%Q!O!P!4g!P!Q%Q!Q![!6u![!c%Q!c!i!6u!i#T%Q#T#Z!6u#Z;'S%Q;'S;=`&s<%lO%QT!4l]&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q![!5e![!c%Q!c!i!5e!i#T%Q#T#Z!5e#Z;'S%Q;'S;=`&s<%lO%QT!5jc&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q![!5e![!c%Q!c!i!5e!i!r%Q!r!sIX!s#R%Q#R#S!4g#S#T%Q#T#Z!5e#Z#d%Q#d#eIX#e;'S%Q;'S;=`&s<%lO%QT!6|i&XS_POY%QYZ%lZr%Qrs%qs!O%Q!O!P!8k!P!Q%Q!Q![!6u![!c%Q!c!i!6u!i!n%Q!n!o!0P!o!r%Q!r!sIX!s#R%Q#R#S!9u#S#T%Q#T#Z!6u#Z#`%Q#`#a!0P#a#d%Q#d#eIX#e;'S%Q;'S;=`&s<%lO%QT!8pa&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q![!5e![!c%Q!c!i!5e!i!r%Q!r!sIX!s#T%Q#T#Z!5e#Z#d%Q#d#eIX#e;'S%Q;'S;=`&s<%lO%QT!9z]&XSOY%QYZ%lZr%Qrs%qs!Q%Q!Q![!6u![!c%Q!c!i!6u!i#T%Q#T#Z!6u#Z;'S%Q;'S;=`&s<%lO%QV!:zX#oR&XSOY%QYZ%lZr%Qrs%qs![%Q![!]!;g!];'S%Q;'S;=`&s<%lO%QV!;nV&uR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QV!<[V!PR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%Q_!<xY&^Z&XSOY%QYZ%lZr%Qrs%qs!^%Q!^!_!=h!_!`+p!`;'S%Q;'S;=`&s<%lO%QU!=oX#hQ&XSOY%QYZ%lZr%Qrs%qs!_%Q!_!`4u!`;'S%Q;'S;=`&s<%lO%QV!>cX!bR&XSOY%QYZ%lZr%Qrs%qs!_%Q!_!`+p!`;'S%Q;'S;=`&s<%lO%QV!?VY&]R&XSOY%QYZ%lZr%Qrs%qs!_%Q!_!`+p!`!a!?u!a;'S%Q;'S;=`&s<%lO%QU!?|Y#hQ&XSOY%QYZ%lZr%Qrs%qs!_%Q!_!`4u!`!a!=h!a;'S%Q;'S;=`&s<%lO%Q_!@uV&aX#nQ&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%Q_!AcX%|Z&XSOY%QYZ%lZr%Qrs%qs#]%Q#]#^!BO#^;'S%Q;'S;=`&s<%lO%QV!BTX&XSOY%QYZ%lZr%Qrs%qs#b%Q#b#c!Bp#c;'S%Q;'S;=`&s<%lO%QV!BuX&XSOY%QYZ%lZr%Qrs%qs#h%Q#h#i!Cb#i;'S%Q;'S;=`&s<%lO%QV!CgX&XSOY%QYZ%lZr%Qrs%qs#X%Q#X#Y!DS#Y;'S%Q;'S;=`&s<%lO%QV!DXX&XSOY%QYZ%lZr%Qrs%qs#f%Q#f#g!Dt#g;'S%Q;'S;=`&s<%lO%QV!DyX&XSOY%QYZ%lZr%Qrs%qs#Y%Q#Y#Z!Ef#Z;'S%Q;'S;=`&s<%lO%QV!EkX&XSOY%QYZ%lZr%Qrs%qs#T%Q#T#U!FW#U;'S%Q;'S;=`&s<%lO%QV!F]X&XSOY%QYZ%lZr%Qrs%qs#V%Q#V#W!Fx#W;'S%Q;'S;=`&s<%lO%QV!F}X&XSOY%QYZ%lZr%Qrs%qs#X%Q#X#Y!Gj#Y;'S%Q;'S;=`&s<%lO%QV!GqV&sR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%Q_!H_b&QZ&XSOY%QYZ%lZr%Qrs%qst%Qtu!HWu!Q%Q!Q![!HW![!c%Q!c!}!HW!}#R%Q#R#S!HW#S#T%Q#T#o!HW#o$g%Q$g;'S!HW;'S;=`!Ig<%lO!HW_!IjP;=`<%l!HW_!ItVuZ&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QV!JbVsR&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QU!KOX#eQ&XSOY%QYZ%lZr%Qrs%qs!_%Q!_!`4u!`;'S%Q;'S;=`&s<%lO%QV!KrV}R&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%Q_!LbZ&}X#dQ&XSOY%QYZ%lZr%Qrs%qs!_%Q!_!`4u!`#p%Q#p#q!MT#q;'S%Q;'S;=`&s<%lO%QU!M[V#bQ&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QV!MxV|R&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%QT!NfV#tP&XSOY%QYZ%lZr%Qrs%qs;'S%Q;'S;=`&s<%lO%Q_# Uu&XS%xZ&OZOX%QXY'fYZ)bZ^'f^p%Qpq'fqr%Qrs%qst%Qtu2lu!Q%Q!Q![2l![!c%Q!c!}2l!}#R%Q#R#S2l#S#T%Q#T#o2l#o#y%Q#y#z'f#z$f%Q$f$g'f$g#BY2l#BY#BZ!N{#BZ$IS2l$IS$I_!N{$I_$I|2l$I|$JO!N{$JO$JT2l$JT$JU!N{$JU$KV2l$KV$KW!N{$KW&FU2l&FU&FV!N{&FV;'S2l;'S;=`3{<%lO2l",
	tokenizers: [
		0,
		1,
		2,
		3
	],
	topRules: {
		"Program": [0, 3],
		"ClassContent": [1, 193]
	},
	dynamicPrecedences: {
		"27": 1,
		"231": -1,
		"242": -1
	},
	specialized: [{
		term: 230,
		get: (value) => spec_identifier[value] || -1
	}],
	tokenPrec: 7072
});
//#endregion
//#region node_modules/@codemirror/lang-java/dist/index.js
/**
A language provider based on the [Lezer Java
parser](https://github.com/lezer-parser/java), extended with
highlighting and indentation information.
*/
var javaLanguage = /*@__PURE__*/ LRLanguage.define({
	name: "java",
	parser: /*@__PURE__*/ parser.configure({ props: [/*@__PURE__*/ indentNodeProp.add({
		IfStatement: /*@__PURE__*/ continuedIndent({ except: /^\s*({|else\b)/ }),
		TryStatement: /*@__PURE__*/ continuedIndent({ except: /^\s*({|catch|finally)\b/ }),
		LabeledStatement: flatIndent,
		SwitchBlock: (context) => {
			let after = context.textAfter, closed = /^\s*\}/.test(after), isCase = /^\s*(case|default)\b/.test(after);
			return context.baseIndent + (closed ? 0 : isCase ? 1 : 2) * context.unit;
		},
		Block: /*@__PURE__*/ delimitedIndent({ closing: "}" }),
		BlockComment: () => null,
		Statement: /*@__PURE__*/ continuedIndent({ except: /^{/ })
	}), /*@__PURE__*/ foldNodeProp.add({
		["Block SwitchBlock ClassBody ElementValueArrayInitializer ModuleBody EnumBody ConstructorBody InterfaceBody ArrayInitializer"]: foldInside,
		BlockComment(tree) {
			return {
				from: tree.from + 2,
				to: tree.to - 2
			};
		}
	})] }),
	languageData: {
		commentTokens: {
			line: "//",
			block: {
				open: "/*",
				close: "*/"
			}
		},
		indentOnInput: /^\s*(?:case |default:|\{|\})$/
	}
});
/**
Java language support.
*/
function java() {
	return new LanguageSupport(javaLanguage);
}
//#endregion
export { java as t };
