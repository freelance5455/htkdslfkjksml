import { B as tags, T as foldNodeProp, d as LRLanguage, k as indentNodeProp, kt as parseMixed, m as LanguageSupport, w as foldInside, x as delimitedIndent, y as continuedIndent, z as styleTags } from "./autocomplete+[...].mjs";
import { i as LRParser, r as ExternalTokenizer } from "./lang-cpp+[...].mjs";
import { t as html } from "./lang-html+[...].mjs";
//#region node_modules/@lezer/php/dist/index.js
var castOpen = 1;
var HeredocString = 2;
var interpolatedStringContent = 276;
var EscapeSequence = 3;
var afterInterpolation = 277;
var automaticSemicolon = 278;
var eof = 279;
var abstract = 4;
var and = 5;
var array = 6;
var as = 7;
var Boolean = 8;
var _break = 9;
var _case = 10;
var _catch = 11;
var clone = 12;
var _const = 13;
var _continue = 14;
var _default = 15;
var declare = 16;
var _do = 17;
var echo = 18;
var _else = 19;
var elseif = 20;
var enddeclare = 21;
var endfor = 22;
var endforeach = 23;
var endif = 24;
var endswitch = 25;
var endwhile = 26;
var _enum = 27;
var _extends = 28;
var final = 29;
var _finally = 30;
var fn = 31;
var _for = 32;
var foreach = 33;
var from = 34;
var _function = 35;
var global = 36;
var goto = 37;
var _if = 38;
var _implements = 39;
var include = 40;
var include_once = 41;
var _instanceof = 42;
var insteadof = 43;
var _interface = 44;
var list = 45;
var match = 46;
var namespace = 47;
var _new = 48;
var _null = 49;
var or = 50;
var print = 51;
var readonly = 52;
var _require = 53;
var require_once = 54;
var _return = 55;
var _switch = 56;
var _throw = 57;
var trait = 58;
var _try = 59;
var unset = 60;
var use = 61;
var _var = 62;
var Visibility = 63;
var keywordMap = {
	abstract,
	and,
	array,
	as,
	true: Boolean,
	false: Boolean,
	break: _break,
	case: _case,
	catch: _catch,
	clone,
	const: _const,
	continue: _continue,
	declare,
	default: _default,
	do: _do,
	echo,
	else: _else,
	elseif,
	enddeclare,
	endfor,
	endforeach,
	endif,
	endswitch,
	endwhile,
	enum: _enum,
	extends: _extends,
	final,
	finally: _finally,
	fn,
	for: _for,
	foreach,
	from,
	function: _function,
	global,
	goto,
	if: _if,
	implements: _implements,
	include,
	include_once,
	instanceof: _instanceof,
	insteadof,
	interface: _interface,
	list,
	match,
	namespace,
	new: _new,
	null: _null,
	or,
	print,
	readonly,
	require: _require,
	require_once,
	return: _return,
	switch: _switch,
	throw: _throw,
	trait,
	try: _try,
	unset,
	use,
	var: _var,
	public: Visibility,
	private: Visibility,
	protected: Visibility,
	while: 64,
	xor: 65,
	yield: 66,
	__proto__: null
};
function keywords(name) {
	let found = keywordMap[name.toLowerCase()];
	return found == null ? -1 : found;
}
function isSpace(ch) {
	return ch == 9 || ch == 10 || ch == 13 || ch == 32;
}
function isASCIILetter(ch) {
	return ch >= 97 && ch <= 122 || ch >= 65 && ch <= 90;
}
function isIdentifierStart(ch) {
	return ch == 95 || ch >= 128 || isASCIILetter(ch);
}
function isHex(ch) {
	return ch >= 48 && ch <= 55 || ch >= 97 && ch <= 102 || ch >= 65 && ch <= 70;
}
var castTypes = {
	int: true,
	integer: true,
	bool: true,
	boolean: true,
	float: true,
	double: true,
	real: true,
	string: true,
	array: true,
	object: true,
	unset: true,
	__proto__: null
};
var expression = new ExternalTokenizer((input) => {
	if (input.next == 40) {
		input.advance();
		let peek = 0;
		while (isSpace(input.peek(peek))) peek++;
		let name = "", next;
		while (isASCIILetter(next = input.peek(peek))) {
			name += String.fromCharCode(next);
			peek++;
		}
		while (isSpace(input.peek(peek))) peek++;
		if (input.peek(peek) == 41 && castTypes[name.toLowerCase()]) input.acceptToken(castOpen);
	} else if (input.next == 60 && input.peek(1) == 60 && input.peek(2) == 60) {
		for (let i = 0; i < 3; i++) input.advance();
		while (input.next == 32 || input.next == 9) input.advance();
		let quoted = input.next == 39;
		if (quoted) input.advance();
		if (!isIdentifierStart(input.next)) return;
		let tag = String.fromCharCode(input.next);
		for (;;) {
			input.advance();
			if (!isIdentifierStart(input.next) && !(input.next >= 48 && input.next <= 55)) break;
			tag += String.fromCharCode(input.next);
		}
		if (quoted) {
			if (input.next != 39) return;
			input.advance();
		}
		if (input.next != 10 && input.next != 13) return;
		for (;;) {
			let lineStart = input.next == 10 || input.next == 13;
			input.advance();
			if (input.next < 0) return;
			if (lineStart) {
				while (input.next == 32 || input.next == 9) input.advance();
				let match = true;
				for (let i = 0; i < tag.length; i++) {
					if (input.next != tag.charCodeAt(i)) {
						match = false;
						break;
					}
					input.advance();
				}
				if (match) return input.acceptToken(HeredocString);
			}
		}
	}
});
var eofToken = new ExternalTokenizer((input) => {
	if (input.next < 0) input.acceptToken(eof);
});
var semicolon = new ExternalTokenizer((input, stack) => {
	if (input.next == 63 && stack.canShift(automaticSemicolon) && input.peek(1) == 62) input.acceptToken(automaticSemicolon);
});
function scanEscape(input) {
	let after = input.peek(1);
	if (after == 110 || after == 114 || after == 116 || after == 118 || after == 101 || after == 102 || after == 92 || after == 36 || after == 34 || after == 123) return 2;
	if (after >= 48 && after <= 55) {
		let size = 2, next;
		while (size < 5 && (next = input.peek(size)) >= 48 && next <= 55) size++;
		return size;
	}
	if (after == 120 && isHex(input.peek(2))) return isHex(input.peek(3)) ? 4 : 3;
	if (after == 117 && input.peek(2) == 123) for (let size = 3;; size++) {
		let next = input.peek(size);
		if (next == 125) return size == 2 ? 0 : size + 1;
		if (!isHex(next)) break;
	}
	return 0;
}
var interpolated = new ExternalTokenizer((input, stack) => {
	let content = false;
	for (;; content = true) {
		if (input.next == 34 || input.next < 0 || input.next == 36 && (isIdentifierStart(input.peek(1)) || input.peek(1) == 123) || input.next == 123 && input.peek(1) == 36) break;
		else if (input.next == 92) {
			let escaped = scanEscape(input);
			if (escaped) {
				if (content) break;
				else return input.acceptToken(EscapeSequence, escaped);
			}
		} else if (!content && (input.next == 91 || input.next == 45 && input.peek(1) == 62 && isIdentifierStart(input.peek(2)) || input.next == 63 && input.peek(1) == 45 && input.peek(2) == 62 && isIdentifierStart(input.peek(3))) && stack.canShift(afterInterpolation)) break;
		input.advance();
	}
	if (content) input.acceptToken(interpolatedStringContent);
});
var phpHighlighting = styleTags({
	"Visibility abstract final static": tags.modifier,
	"for foreach while do if else elseif switch try catch finally return throw break continue default case": tags.controlKeyword,
	"endif endfor endforeach endswitch endwhile declare enddeclare goto match": tags.controlKeyword,
	"and or xor yield unset clone instanceof insteadof": tags.operatorKeyword,
	"function fn class trait implements extends const enum global interface use var": tags.definitionKeyword,
	"include include_once require require_once namespace": tags.moduleKeyword,
	"new from echo print array list as": tags.keyword,
	null: tags.null,
	Boolean: tags.bool,
	VariableName: tags.variableName,
	"NamespaceName/...": tags.namespace,
	"NamedType/...": tags.typeName,
	Name: tags.name,
	"CallExpression/Name": tags.function(tags.variableName),
	"LabelStatement/Name": tags.labelName,
	"MemberExpression/Name": tags.propertyName,
	"MemberExpression/VariableName": tags.special(tags.propertyName),
	"ScopedExpression/ClassMemberName/Name": tags.propertyName,
	"ScopedExpression/ClassMemberName/VariableName": tags.special(tags.propertyName),
	"CallExpression/MemberExpression/Name": tags.function(tags.propertyName),
	"CallExpression/ScopedExpression/ClassMemberName/Name": tags.function(tags.propertyName),
	"MethodDeclaration/Name": tags.function(tags.definition(tags.variableName)),
	"FunctionDefinition/Name": tags.function(tags.definition(tags.variableName)),
	"ClassDeclaration/Name": tags.definition(tags.className),
	UpdateOp: tags.updateOperator,
	ArithOp: tags.arithmeticOperator,
	"LogicOp IntersectionType/&": tags.logicOperator,
	BitOp: tags.bitwiseOperator,
	CompareOp: tags.compareOperator,
	ControlOp: tags.controlOperator,
	AssignOp: tags.definitionOperator,
	"$ ConcatOp": tags.operator,
	LineComment: tags.lineComment,
	BlockComment: tags.blockComment,
	Integer: tags.integer,
	Float: tags.float,
	String: tags.string,
	ShellExpression: tags.special(tags.string),
	"=> ->": tags.punctuation,
	"( )": tags.paren,
	"#[ [ ]": tags.squareBracket,
	"${ { }": tags.brace,
	"-> ?->": tags.derefOperator,
	", ; :: : \\": tags.separator,
	"PhpOpen PhpClose": tags.processingInstruction
});
var spec_name = {
	__proto__: null,
	static: 325,
	STATIC: 325,
	class: 351,
	CLASS: 351
};
var parser = LRParser.deserialize({
	version: 14,
	states: "%$dQ`OWOOQhQaOOP%oO`OOOOO#t'#Hh'#HhO%tO#|O'#DuOOO#u'#Dx'#DxQ&SOWO'#DxO&XO$VOOOOQ#u'#Dy'#DyO&lQaO'#D}O'[QdO'#EQO+QQdO'#IrO+_QdO'#ERO-RQaO'#EXO/bQ`O'#EUO/gQ`O'#E_O2UQaO'#E_O2]Q`O'#EgO2bQ`O'#EqO-RQaO'#EqO2mQpO'#FOO2rQ`O'#FOOOQS'#Ir'#IrO2wQ`O'#ExOOQS'#Ii'#IiO5SQdO'#IfO9UQeO'#F]O-RQaO'#FlO-RQaO'#FmO-RQaO'#FnO-RQaO'#FoO-RQaO'#FoO-RQaO'#FrOOQO'#Is'#IsO9cQ`O'#FxOOQO'#Ht'#HtO9kQ`O'#HXO:VQ`O'#FsO:bQ`O'#HfO:mQ`O'#GPO:uQaO'#GQO-RQaO'#G`O-RQaO'#GcO;bOrO'#GfOOQS'#JR'#JROOQS'#JQ'#JQOOQS'#If'#IfO/bQ`O'#GmO/bQ`O'#GoO/bQ`O'#GtOhQaO'#GvO;iQ`O'#GwO;nQ`O'#GzO:]Q`O'#G}O;sQeO'#HOO;sQeO'#HPO;sQeO'#HQO;}Q`O'#HRO<SQ`O'#HTO<XQaO'#HUO>hQ`O'#HVO:]Q`O'#HWO>mQ`O'#HWO;}Q`O'#HXO:]Q`O'#HZO:]Q`O'#H[O:]Q`O'#H]O>rQ`O'#H`O>}Q`O'#HaO<XQaO'#HeOOQ#u'#Id'#IdOOQ#u'#Hj'#HjQhQaOOO:]Q`O'#HYO:QQ`O'#HYO?]O#|O'#DsPOOO)CDU)CDUOOO#t-E;f-E;fOOO#u,5:d,5:dOOO#u'#Hi'#HiO&XO$VOOO?hQ$VO'#IcOOOO'#Ic'#IcQOOOOOOOQ#y,5:i,5:iO?oQaO,5:iOOQ#u,5:k,5:kO?vQaO,5:nO?}QaO,5;VO@UQpO,5;WOBsQaO'#EuOOQS,5;`,5;`OBzQ`O,5;pOOQP'#Fd'#FdO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xO-RQaO,5;xOOQ#u'#Ix'#IxOOQS,5<z,5<zOOQ#u,5:m,5:mODsQ`O,5:sODzQ`O'#FsOESQ`O'#FsOE[Q`O,5:pOEaQaO'#E`OOQS,5:y,5:yOGeQ`O'#IkO<XQaO'#EbO<XQaO'#IkOOQS'#Ik'#IkOGlQ`O'#IjOGtQ`O,5:yO/lQaO,5:yOGyQaO'#EhOOQS,5;R,5;ROOQS,5;],5;]OHTQ`O,5;]OHsQdO'#FQOJxQ`O'#HrO2mQpO,5;jOOQS,5;j,5;jOJ}QpO,5;jOKSQtO'#EQOKaQpO,5;dO2wQ`O'#E|OOQS'#E}'#E}OOQS'#Iq'#IqOKlQaO,5:xO-RQaO,5;uOOQS,5;w,5;wO-RQaO,5;wOKsQdO,5<WOLTQdO,5<XOLeQdO,5<YOLuQdO,5<ZON|QdO,5<ZO! TQdO,5<^O! eQ`O'#FyO! pQ`O'#IvO! xQ`O,5<dOOQO-E;r-E;rO! }Q`O'#JPO:]Q`O,5=rO!!VQ`O,5=rO;}Q`O,5=sO:]Q`O,5=wO:]Q`O,5=tO!![Q`O,5=tOOQS'#EQ'#EQO!!aQ`O'#FuO!!zQ`O,5<_O!#VQ`O,5<_O!#_Q`O,5?kO!#dQ`O,5<_O!#lQ`O,5<kO!#tQdO'#GYO!$SQdO'#JOO!$_QdO,5>QO!$gQ`O,5<kO!#_Q`O,5<kO!$oQdO,5<lO!%PQ`O,5<lO!%_Q`O,5<lO!%uQdO,5<zO!'zQdO,5<}O!([OrO'#IQOOOQ'#JU'#JUO-RQaO'#GkOOOQ'#IQ'#IQO!(|OrO,5=QOOQS,5=Q,5=QO!)TQaO,5=XO!)[Q`O,5=ZO!)dQeO,5=`O!)nQ`O,5=bO!)sQaO'#GxO!)dQeO,5=cO<XQaO'#G{O!)dQeO,5=fO!$_QdO,5=iO+_QdO,5=jOOQ#u,5=j,5=jO+_QdO,5=kOOQ#u,5=k,5=kO+_QdO,5=lOOQ#u,5=l,5=lO!)zQ`O,5=mO:]Q`O,5=oO!*SQdO'#JWOOQS'#JW'#JWO!$_QdO,5=pO!+lQaO,5=qO!-{Q`O'#GWO!.QQdO'#I}O!$_QdO,5=rOOQ#u,5=s,5=sO!.]Q`O,5=uO!.`Q`O,5=vO!.eQ`O,5=wO!.pQdO,5=zOOQ#u,5=z,5=zO2mQpO,5={O!.{Q`O,5={O!/QQdO'#JXO!$_QdO,5={O!/`Q`O,5={O!/hQdO'#IhO!$_QdO,5>POOQ#u-E;h-E;hO!1TQ`O,5=tOOO#u,5:_,5:_O!1`O#|O,5:_OOO#u-E;g-E;gOOOO,5>},5>}OOQ#y1G0T1G0TO!1hQ`O1G0YO-RQaO1G0YO!2zQ`O1G0qOOQS1G0q1G0qOOQS'#Eo'#EoOOQS'#Im'#ImO-RQaO'#ImOOQS1G0r1G0rO!4^Q`O'#IpO!5sQ`O'#IrO!6QQaO'#EwOOQO'#Ip'#IpO!6[Q`O'#IoO!6dQ`O,5;aO-RQaO'#FXOOQS'#FW'#FWOOQS1G1[1G1[O!6iQdO1G1dO!8nQdO1G1dO!:ZQdO1G1dO!;vQdO1G1dO!=cQdO1G1dO!?OQdO1G1dO!@kQdO1G1dO!BWQdO1G1dO!CsQdO1G1dO!E`QdO1G1dO!F{QdO1G1dO!HhQdO1G1dO!JTQdO1G1dO!KpQdO1G1dO!M]QdO1G1dO!NxQdO1G1dOOQT1G0_1G0_O!#_Q`O,5<_O#!eQaO'#EYOOQS1G0[1G0[O#!lQ`O,5:zOEdQaO,5:zO#!qQaO,5;OO#!xQdO,5:|O#$wQdO,5?VO#&vQaO'#HmO#'WQ`O,5?UOOQS1G0e1G0eO#'`Q`O1G0eO#'eQ`O'#IlO#(}Q`O'#IlO#)VQ`O,5;SOG|QaO,5;SOOQS1G0w1G0wOOQO,5>^,5>^OOQO-E;p-E;pOOQS1G1U1G1UO#)sQdO'#FQO#+xQ`O'#HsOJ}QpO1G1UO2wQ`O'#HpO#+}QtO,5;eO2wQ`O'#HqO#,lQtO,5;gO#-ZQaO1G1OOOQS,5;h,5;hO#/jQtO'#FQO#/wQdO1G0dO-RQaO1G0dO#1dQdO1G1aO#3PQdO1G1cOOQO,5<e,5<eO#3aQ`O'#HuO#3oQ`O,5?bOOQO1G2O1G2OO:]Q`O,5?kO!$_QdO1G3^O:]Q`O1G3^OOQ#u1G3_1G3_O#3wQ`O1G3cO!1TQ`O1G3`O:]Q`O1G3`O#4SQpO'#FvO#4bQ`O'#FvO#4xQ`O'#FvO#5TQ`O'#FvO#5]Q`O'#FzOOQO'#Iw'#IwOOQO'#Hv'#HvO#5bQ`O'#F{OOQO'#Iu'#IuO#5oQ`O'#ItO#5wQ`O,5<aOOQS1G1y1G1yO2wQ`O1G1yO#5|Q`O1G1yO#6RQ`O1G1yO!#_Q`O1G5VO#6^QdO1G5VO!#_Q`O1G1yO#6lQ`O1G2VO!#_Q`O1G2VO<XQaO,5<tO#6tQdO'#IOO#7SQdO,5?jOOQ#u1G3l1G3lO-RQaO1G2VO2wQ`O1G2VO#7_QdO1G2WO9cQ`O'#GSO9cQ`O'#GTO#9qQ`O'#GUOOQS1G2W1G2WO!.`Q`O1G2WO!1WQ`O1G2WO!1TQ`O1G2WO!%PQ`O1G2WO:]O`O,5=RO#:kO`O,5=RO#:vO!bO,5=SO#;UQ`O,5=VOOOQ-E<O-E<OOOQS1G2l1G2lO#;]QaO'#GnO#;vQ$VO1G2sO#@vQ`O1G2sO#ARQ`O'#GpO#A^Q`O'#GsOOQ#u1G2u1G2uO#AiQ`O1G2uOOQ#u'#Gu'#GuOOQ#u'#JV'#JVOOQ#u1G2z1G2zO#AnQ`O1G2zO/bQ`O1G2|O#AsQaO,5=dO#AzQ`O,5=dOOQ#u1G2}1G2}O#BPQ`O1G2}O#BUQ`O,5=gOOQ#u1G3Q1G3QO#ChQ`O1G3QOOQ#u1G3T1G3TOOQ#u1G3U1G3UOOQ#u1G3V1G3VOOQ#u1G3W1G3WO#CmQ`O'#IVO;}Q`O'#IVO#CrQ$VO1G3XO#HxQ`O1G3ZO<XQaO'#IUO#H}QdO,5=eOOQ#u1G3[1G3[O#IYQ`O1G3]O<XQaO,5<rO#I_QdO'#H}O#ImQdO,5?iOOQ#u1G3^1G3^OOQ#u1G3a1G3aO!.`Q`O1G3aOOQ#u1G3b1G3bO#IxQ`O'#H^OOQ#u1G3c1G3cO#JuQ`O1G3cO#JzQ`O1G3cOOQ#u1G3f1G3fO#K]Q`O1G3gO#KbQpO1G3gO#KjQdO'#IXO#K{QdO,5?sO:]Q`O,5?sOOQ#u1G3g1G3gO2mQpO1G3gO#LWQ`O1G3gO!$_QdO1G3gO#L]QeO'#HkO#LmQdO,5?SOOQ#u1G3k1G3kOOQ#u1G3`1G3`O!.`Q`O1G3`O!1WQ`O1G3`OOO#u1G/y1G/yO-RQaO7+%tO#L{QdO7+%tOOQS7+&]7+&]O#NhQ`O,5?XO!+lQaO,5;bO#NoQ`O,5;cO$!UQaO'#HoO$!`Q`O,5?ZOOQS1G0{1G0{O$!hQ`O,5;sO$!oQ`O'#EZO$!tQ`O'#IgO$!|Q`O,5:tOOQS1G0f1G0fO$#RQ`O1G0fO$#WQ`O1G0jO<XQaO1G0jOOQO,5>X,5>XOOQO-E;k-E;kOOQS7+&P7+&PO!+lQaO,5;TO$$mQaO'#HnO$$wQ`O,5?WOOQS1G0n1G0nO$%PQ`O1G0nPOQO'#FQ'#FQOOQO,5>_,5>_OOQO-E;q-E;qOOQS7+&p7+&pOOQS,5>[,5>[OOQS-E;n-E;nO$%UQtO,5>]OOQS-E;o-E;oO$%sQdO7+&jO$'xQtO'#FQO$(VQdO7+&OOOQS1G0j1G0jOOQO,5>a,5>aOOQO-E;s-E;sOOQ#u7+(x7+(xO!$_QdO7+(xOOQ#u7+(}7+(}O#JuQ`O7+(}O#JzQ`O7+(}OOQ#u7+(z7+(zO!.`Q`O7+(zO!1WQ`O7+(zO!1TQ`O7+(zO$)rQ`O,5<bO$)|Q`O,5<bO$*XQ`O,5<fO$*^QpO,5<bO$*lQ`O,5<bO$*tQ`O,5<gO!+lQaO,5<bOOQO,5<f,5<fO$+RQpO,5<gOOQO-E;t-E;tO$+^Q`O,5<gO$+lQ`O'#HxO$,YQ`O,5?`OOQS1G1{1G1{O$,bQpO7+'eO$,mQ`O'#GOO$,xQ`O7+'eOOQS7+'e7+'eO2wQ`O7+'eO#5|Q`O7+'eO$-QQdO7+*qO2wQ`O7+*qO$-`Q`O7+'eO-RQaO7+'qO2wQ`O7+'qO$-kQ`O7+'qO$-sQdO1G2`OOQS,5>j,5>jOOQS-E;|-E;|O$/]QdO7+'qO$/mQpO7+'qO$/xQdO'#IzOOQO,5<n,5<nOOQO,5<o,5<oO$0ZQpO'#GXO$0fQ`O'#GXOOQO'#I|'#I|OOQO'#H|'#H|O$1YQ`O'#GXO#JzQ`O'#GVO$1yQdO'#GXO!.pQdO'#GZO9cQ`O'#G[OOQO'#I{'#I{OOQO'#H{'#H{O$2UQ`O,5<pOOQ#y,5<p,5<pOOQS7+'r7+'rO!.`Q`O7+'rO!1WQ`O7+'rO!1TQ`O7+'rOOOQ1G2m1G2mO:]O`O1G2mO$3OO!bO1G2nO$3^O`O'#GiO$3cO`O1G2nOOOQ1G2q1G2qO$3hQaO,5=YO/bQ`O'#IRO$4RQ$VO7+(_OhQaO7+(_O/bQ`O'#ISO$9RQ`O7+(_O!$_QdO7+(_O$9^Q`O7+(_O$9cQaO'#GqO$;rQ`O'#GrOOQO'#IT'#ITO$;zQ`O,5=[OOQ#u,5=[,5=[O$<VQ`O,5=_O!$_QdO7+(aO!$_QdO7+(fO!$_QdO7+(hO$<bQaO1G3OO$<iQ`O1G3OO$<nQaO1G3OO!$_QdO7+(iO<XQaO1G3RO!$_QdO7+(lO2wQ`O'#HSO;}Q`O,5>qOOQ#u,5>q,5>qOOQ#u-E<T-E<TO$<uQaO7+(uO$=^QdO,5>pOOQS-E<S-E<SO!$_QdO7+(wO$>vQdO1G2^OOQS,5>i,5>iOOQS-E;{-E;{OOQ#u7+({7+({O$@`Q`O'#GXO:]Q`O'#H_OOQO'#IW'#IWO$AVQ`O,5=xOOQ#u,5=x,5=xO$BSQ!bO'#EQO$BkQ!bO7+(}O$ByQpO7+)RO#KbQpO7+)RO$CRQ`O'#HbO!$_QdO7+)RO$CaQdO,5>sOOQS-E<V-E<VO$CoQdO1G5_O$CzQ`O7+)RO#KbQpO7+)ROOQ#u7+)R7+)RO$DPQdO,5>VOOQS-E;i-E;iO$ElQdO<<I`OOQS1G4s1G4sO$GXQ`O1G0|OOQO,5>Z,5>ZOOQO-E;m-E;mOOQS1G1_1G1_O$9cQaO,5:uO$HnQaO'#HlO$H{Q`O,5?ROOQS1G0`1G0`OOQS7+&Q7+&QO$ITQ`O7+&UO$JjQ`O1G0oO$LPQ`O,5>YOOQO,5>Y,5>YOOQO-E;l-E;lOOQS7+&Y7+&YOOQS7+&U7+&UOOQ#u<<Ld<<LdOOQ#u<<Li<<LiO$BkQ!bO<<LiOOQ#u<<Lf<<LfO!.`Q`O<<LfO!1WQ`O<<LfO$MiQ`O1G1|O$MtQ`O1G2QO!+lQaO1G1|OOQO1G2Q1G2QO$MyQ`O1G1|O$NTQpO1G2RO$N`Q`O1G2RO$NnQ`O1G1|O%!TQ`O'#F|O!+lQaO1G2ROOQO1G2R1G2ROOQO,5>d,5>dOOQO-E;v-E;vOOQS<<KP<<KPO%!]Q`O'#IyO%!eQ`O'#IyO%!jQ`O,5<jO2wQ`O<<KPO$,bQpO<<KPO%!oQ`O<<KPO2wQ`O<<N]O%!wQtO<<N]O#5|Q`O<<KPO%#YQdO<<K]O%#jQpO<<K]O-RQaO<<K]O2wQ`O<<K]O%#uQdO'#HzO%$^QdO,5?fO$1yQdO,5<sO$0ZQpO,5<sO%$oQ`O,5<sO#JzQ`O,5<qO!.pQdO,5<uOOQO-E;z-E;zO%%`Q!bO,5<qO%%kQ!bO'#IrO!$_QdO,5<qOOQO,5<s,5<sOOQO,5<u,5<uO%%yQdO,5<vOOQO-E;y-E;yOOQ#y1G2[1G2[OOQS<<K^<<K^O!.`Q`O<<K^O!1WQ`O<<K^OOOQ7+(X7+(XO%&UO`O7+(YOOOO,5=T,5=TOOOQ7+(Y7+(YOhQaO,5>mOOQ#u-E<P-E<POhQaO<<KyOOQ#u<<Ky<<KyO$9^Q`O,5>nOOQO-E<Q-E<QO!$_QdO<<KyO$9^Q`O<<KyO%&ZQ`O<<KyO%&`Q`O,5=]O%'uQaO,5=^OOQO-E<R-E<ROOQ#u1G2v1G2vOOQ#u<<K{<<K{OOQ#u<<LQ<<LQOOQ#u<<LS<<LSOOQT7+(j7+(jO%(VQ`O7+(jO%([QaO7+(jO%(cQ`O7+(jOOQ#u<<LT<<LTO%(hQ`O7+(mO%)}Q`O7+(mOOQ#u<<LW<<LWO%*SQpO,5=nOOQ#u1G4]1G4]O%*bQ`O<<LaOOQ#u<<Lc<<LcO:]Q`O,5=yO%*gQdO,5=yOOQO-E<U-E<UOOQ#u1G3d1G3dO%*rQ!bO,5;eO%+TQ!bO,5;gO#JuQ`O<<LiO%+fQ!bO'#FQP%+zQpO<<LmO!$_QdO<<LmO%,SQ`O'#HcO9cQ`O'#HcO%,_Q`O'#JYO%,gQ`O,5=|OOQ#u<<Lm<<LmO:]Q`O1G4_O%,lQdO7+*yO$ByQpO<<LmO#KbQpO<<LmO%,wQ`O1G0aOOQO,5>W,5>WOOQO-E;j-E;jO!+lQaO,5;UOOQ#uANBTANBTO#JuQ`OANBTOOQ#uANBQANBQO!.`Q`OANBQO!+lQaO7+'hOOQO7+'l7+'lO%.^Q`O7+'hO%/sQ`O7+'hO%0OQ`O7+'lO%0TQ`O7+'mO!+lQaO7+'mOOQO7+'m7+'mO%0cQdO'#F}OOQO'#Hw'#HwO%0tQ`O,5<hOOQO,5<h,5<hO%0|Q`O7+'mO%2cQ`O'#HyO%2qQ`O,5?eO%2qQ`O,5?eOOQO1G2U1G2UO$,bQpOAN@kOOQSAN@kAN@kO2wQ`OAN@kO%2yQtOANCwO%3[Q`OAN@kO-RQaOAN@wO%3dQdOAN@wO%3tQpOAN@wOOQS,5>f,5>fOOQS-E;x-E;xOOQO1G2_1G2_O$1yQdO1G2_O$0ZQpO1G2_O#JzQ`O1G2]O!.pQdO1G2aO%%`Q!bO1G2]O!$_QdO1G2]OOQO1G2a1G2aOOQO1G2]1G2]O%4PQaO'#G]OOQO1G2b1G2bOOQSAN@xAN@xO!.`Q`OAN@xOOOQ<<Kt<<KtOOQ#u1G4X1G4XOOQ#uANAeANAeOOQO1G4Y1G4YO%6OQ`OANAeO!$_QdOANAeO%6TQaO1G2wO%6eQaO1G2xOOQT<<LU<<LUO%6uQ`O<<LUO%6zQaO<<LUO-RQaO,5=hOOQT<<LX<<LXOOQO1G3Y1G3YO%7RQ`O1G3YO!)dQeOANA{O%7WQdO1G3eOOQO1G3e1G3eO%7cQ`O1G3eO%7kQ!bO,5>]O%7|Q!bO'#FQO!$_QdOANBXOOQ#uANBXANBXO:]Q`O,5=}O%8bQ`O,5=}O%8mQ`O'#IYO%9RQ`O,5?tOOQS1G3h1G3hOOQS7+)y7+)yP%+zQpOANBXO%9ZQ`O1G0pOOQ#uG27oG27oOOQ#uG27lG27lO%:pQ`O<<KSO!+lQaO<<KSOOQO<<KW<<KWO!+lQaO<<KXOOQO<<KX<<KXO%<VQ`O<<KXOOQO,5<i,5<iO-RQaO,5<iO%=lQ`O,5<iOOQO-E;u-E;uOOQO1G2S1G2SOOQO,5>e,5>eO%=tQ`O,5>eOOQO-E;w-E;wO%=yQ`O1G5POOQSG26VG26VO$,bQpOG26VO2wQ`OG26VO%>RQdOG26cO-RQaOG26cOOQO7+'y7+'yO$1yQdO7+'yO%%`Q!bO7+'wO!$_QdO7+'wOOQO7+'{7+'{OOQO7+'w7+'wO%>cQ`OLD+}O%?rQ`O'#IrO%?|Q`O'#IiO!$_QdO'#IPO%AvQaO,5<wOOQO,5<w,5<wOOQSG26dG26dO!$_QdOG27POOQ#uG27PG27PO%CuQaO7+(cOOQTANApANApO%DVQ`OANApO%D[Q`O1G3SOOQO7+(t7+(tOOQ#uG27gG27gO%DcQ`OG27gOOQO7+)P7+)PO%DhQ`O7+)PO!$_QdO7+)POOQ#uG27sG27sOOQO1G3i1G3iO:]Q`O1G3iO%DpQ`O'#HdO9cQ`O'#HdOOQO,5>t,5>tOOQO-E<W-E<WP!$_QdOG27sO%D{Q`OAN@nO%FbQ`OAN@sO+_QdO1G2TOOQO1G2T1G2TO-RQaO1G2TOOQO1G4P1G4POOQSLD+qLD+qO$,bQpOLD+qO%GwQdOLD+}OOQO<<Ke<<KeO!$_QdO<<KcOOQO<<Kc<<KcO:]Q`O,5<xO%HXQ`O,5<yOOQP,5>k,5>kOOQP-E;}-E;}OOQO1G2c1G2cOOQ#uLD,kLD,kOOQTG27[G27[O!$_QdOLD-RO!$_QdO<<LkOOQO<<Lk<<LkOOQO7+)T7+)TO:]Q`O,5>OO%HaQ`O,5>OPOQ#uLD-_LD-_OOQO7+'o7+'oO+_QdO7+'oOOQS!$( ]!$( ]OOQOAN@}AN@}OOQS1G2d1G2dOOQS1G2e1G2eO%HlQdO1G2eOOQ#u!$(!m!$(!mOOQOANBVANBVOOQO1G3j1G3jO:]Q`O1G3jOOQO<<KZ<<KZOOQS7+(P7+(POOQO7+)U7+)UO%HwQpO'#FOO%H|QpO'#FOO%HwQpO,5;jO%H|QpO,5;jO%IRQpO,5;jO%IWQpO,5;jO#JzQ`O'#E|O%I]QdO,5<lO%KRQaO,5;OO%IRQpO1G1UO%IWQpO1G1UO#JzQ`O'#HpO#JzQ`O'#HqO-RQaO1G0jO%KYQ`O'#FOO%K_Q`O'#FOO%KdQaO'#GQO#-ZQaO'#G`O#-ZQaO'#GcO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO#-ZQaO,5;xO%KnQdO'#IkO%M^QdO'#IkO#-ZQaO'#EbO#-ZQaO'#IkO& cQaO,5:xO#-ZQaO,5;uO#-ZQaO,5;wO& jQdO,5<WO&#`QdO,5<XO&%UQdO,5<YO&&zQdO,5<ZO&(pQdO,5<ZO&)QQdO,5<^O&*vQdO,5<}O#-ZQaO1G0YO&,lQdO1G1dO&.bQdO1G1dO&0WQdO1G1dO&1|QdO1G1dO&3rQdO1G1dO&5hQdO1G1dO&7^QdO1G1dO&9SQdO1G1dO&:xQdO1G1dO&<nQdO1G1dO&>dQdO1G1dO&@YQdO1G1dO&BOQdO1G1dO&CtQdO1G1dO&EjQdO1G1dO&G`QdO,5:|O&IUQdO,5?VO&JzQdO1G0dO#-ZQaO1G0dO&LpQdO1G1aO&NfQdO1G1cO#-ZQaO1G2VO#-ZQaO7+%tO'![QdO7+%tO'$QQdO7+&OO#-ZQaO7+'qO'%vQdO7+'qO''lQdO<<I`O')bQdO<<K]O#-ZQaO<<K]O#-ZQaOAN@wO'+WQdOAN@wO',|QdOG26cO#-ZQaOG26cO'.rQdOLD+}O'0hQaO,5;OO'2gQaO1G0jO'4cQdO'#IfO'4pQeO'#F]O'8gQeO'#F]O#-ZQaO'#FlO'2gQaO'#FlO#-ZQaO'#FmO'2gQaO'#FmO#-ZQaO'#FnO'2gQaO'#FnO#-ZQaO'#FoO'2gQaO'#FoO#-ZQaO'#FoO'2gQaO'#FoO#-ZQaO'#FrO'2gQaO'#FrO'<mQaO,5:nO'<tQ`O,5<kO'<|Q`O1G0YO'2gQaO1G1OO'>`Q`O1G2VO'>hQ`O7+'qO'>pQpO7+'qO'>{QpO<<K]O'?WQpOAN@wO'?cQaO'#GQO'2gQaO'#G`O'2gQaO'#GcO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO,5;xO'2gQaO'#EbO'2gQaO'#IkO'AeQaO,5:xO'2gQaO,5;uO'2gQaO,5;wO'CdQdO,5<WO'EiQdO,5<XO'GnQdO,5<YO'IsQdO,5<ZO'KxQdO,5<ZO'LiQdO,5<^O'NnQdO,5<}O'2gQaO1G0YO(!sQdO1G1dO($xQdO1G1dO(&}QdO1G1dO()SQdO1G1dO(+XQdO1G1dO(-^QdO1G1dO(/cQdO1G1dO(1hQdO1G1dO(3mQdO1G1dO(5rQdO1G1dO(7wQdO1G1dO(9|QdO1G1dO(<RQdO1G1dO(>WQdO1G1dO(@]QdO1G1dO(BbQdO,5:|O(DgQdO,5?VO(FlQdO1G0dO'2gQaO1G0dO(HqQdO1G1aO(JvQdO1G1cO'2gQaO1G2VO'2gQaO7+%tO(L{QdO7+%tO) QQdO7+&OO'2gQaO7+'qO)#VQdO7+'qO)%[QdO<<I`O)'aQdO<<K]O'2gQaO<<K]O'2gQaOAN@wO))fQdOAN@wO)+kQdOG26cO'2gQaOG26cO)-pQdOLD+}O)/uQaO,5;OO#-ZQaO1G0jO)/|Q`O'#GPO)0UQpO,5;dO)0aQ`O,5<kO!#_Q`O,5<kO!#_Q`O1G2VO2wQ`O1G2VO2wQ`O7+'qO2wQ`O<<K]O)0iQdO,5<lO)2nQdO'#IkO)4gQdO'#IfO)5TQaO,5:nO)5[Q`O,5<kO)5dQ`O1G0YO)6vQ`O1G2VO)7OQ`O7+'qO)7WQpO7+'qO)7cQpO<<K]O)7nQpOAN@wO2wQ`O'#ExO<XQaO'#FlO<XQaO'#FmO<XQaO'#FnO<XQaO'#FoO<XQaO'#FoO<XQaO'#FrO)7yQaO'#GQO<XQaO'#G`O<XQaO'#GcO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO<XQaO,5;xO)8TQ`O'#FsO-RQaO'#EbO-RQaO'#IkO)8]QaO,5:xO<XQaO,5;uO<XQaO,5;wO)8dQdO,5<WO):cQdO,5<XO)<bQdO,5<YO)>aQdO,5<ZO)@`QdO,5<ZO)@yQdO,5<^O)BxQdO,5<lO)DwQdO,5<}O)FvQ`O'#JWO)H]Q`O'#IhO<XQaO1G0YO)IrQdO1G1dO)KqQdO1G1dO)MpQdO1G1dO* oQdO1G1dO*#nQdO1G1dO*%mQdO1G1dO*'lQdO1G1dO*)kQdO1G1dO*+jQdO1G1dO*-iQdO1G1dO*/hQdO1G1dO*1gQdO1G1dO*3fQdO1G1dO*5eQdO1G1dO*7dQdO1G1dO*9cQaO,5;OO*9jQdO,5:|O*9zQdO,5?VO*:[QaO'#HmO*:lQ`O,5?UO*:tQdO1G0dO<XQaO1G0dO*<sQdO1G1aO*>rQdO1G1cO<XQaO1G2VO!+lQaO'#IUO*@qQ`O,5=eO*@yQaO'#HkO*ATQ`O,5?SO<XQaO7+%tO*A]QdO7+%tO*C[Q`O1G0jO!+lQaO1G0jO*DqQdO7+&OO<XQaO7+'qO*FpQdO7+'qO*HoQ`O,5>pO*JUQ`O,5>VO*KkQdO<<I`O*MjQ`O7+&UO+ PQdO<<K]O<XQaO<<K]O<XQaOAN@wO+#OQdOAN@wO+$}QdOG26cO<XQaOG26cO+&|QdOLD+}O+({QaO,5;OO<XQaO1G0jO+)SQdO'#IkO+)pQ`O'#GPO+)xQ`O,5<kO!#_Q`O,5<kO!#_Q`O1G2VO2wQ`O1G2VO2wQ`O7+'qO2wQ`O<<K]O+*QQdO'#IfO+*nQeO'#F]O++_QeO'#F]O+-ZQaO'#F]O+.sQaO'#F]O!+lQaO'#FlO!+lQaO'#FmO!+lQaO'#FnO!+lQaO'#FoO!+lQaO'#FoO!+lQaO'#FrO+0cQaO'#GQO!+lQaO'#G`O!+lQaO'#GcO+0mQaO,5:nO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO!+lQaO,5;xO+0tQ`O'#IkO$9cQaO'#EbO+2^QaOG26cO$9cQaO'#IkO+4YQ`O'#IjO+4bQaO,5:xO!+lQaO,5;uO!+lQaO,5;wO+4iQ`O,5<WO+6OQ`O,5<XO+7eQ`O,5<YO+8zQ`O,5<ZO+:aQ`O,5<ZO+;vQ`O,5<^O+=]Q`O,5<kO+=eQ`O,5<lO+>zQ`O,5<}O+@aQ`O1G0YO!+lQaO1G0YO+AsQ`O1G1dO+CYQ`O1G1dO+DoQ`O1G1dO+FUQ`O1G1dO+GkQ`O1G1dO+IQQ`O1G1dO+JgQ`O1G1dO+K|Q`O1G1dO+McQ`O1G1dO+NxQ`O1G1dO,!_Q`O1G1dO,#tQ`O1G1dO,%ZQ`O1G1dO,&pQ`O1G1dO,(VQ`O1G1dO,)lQ`O1G0dO!+lQaO1G0dO,+RQ`O1G1aO,,hQ`O1G1cO,-}Q`O1G2VO$9cQaO,5<tO!+lQaO1G2VO!+lQaO7+%tO,.VQ`O7+%tO,/lQ`O7+&OO!+lQaO7+'qO,1RQ`O7+'qO,1ZQ`O7+'qO,2pQpO7+'qO,2{Q`O<<I`O,4bQ`O<<K]O,5wQpO<<K]O!+lQaO<<K]O!+lQaOAN@wO,6SQ`OAN@wO,7iQpOAN@wO,7tQ`OG26cO!+lQaOG26cO,9ZQ`OLD+}O,:pQaO,5;OO!+lQaO1G0jO,:wQ`O'#IkO$9cQaO'#FlO$9cQaO'#FmO$9cQaO'#FnO$9cQaO'#FoO$9cQaO'#FoO+2^QaO'#FoO$9cQaO'#FrO,<aQaO'#GQO,<kQaO'#GQO$9cQaO'#G`O+2^QaO'#G`O$9cQaO'#GcO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO$9cQaO,5;xO+2^QaO,5;xO,>mQ`O'#FsO!+lQaO'#EbO!+lQaO'#IkO,>uQaO,5:xO,>|QaO,5:xO$9cQaO,5;uO+2^QaO,5;uO$9cQaO,5;wO,@{QdO,5<WO,BnQdO,5<XO,DaQdO,5<YO,FSQdO,5<ZO,GuQdO,5<ZO,IhQ`O,5<ZO,JwQdO,5<^O,LjQdO,5<lO%>cQ`O,5<lO,N]QdO,5<}O$9cQaO1G0YO+2^QaO1G0YO-!OQdO1G1dO-#qQ`O1G1dO-%QQdO1G1dO-&sQ`O1G1dO-(SQdO1G1dO-)uQ`O1G1dO-+UQdO1G1dO-,wQ`O1G1dO-.WQdO1G1dO-/yQ`O1G1dO-1YQdO1G1dO-2{Q`O1G1dO-4[QdO1G1dO-5}Q`O1G1dO-7^QdO1G1dO-9PQ`O1G1dO-:`QdO1G1dO-<RQ`O1G1dO-=bQdO1G1dO-?TQ`O1G1dO-@dQdO1G1dO-BVQ`O1G1dO-CfQdO1G1dO-EXQ`O1G1dO-FhQdO1G1dO-HZQ`O1G1dO-IjQdO1G1dO-K]Q`O1G1dO-LlQdO1G1dO-N_Q`O1G1dO. nQ`O,5:|O.#TQ`O,5?VO.$jQdO1G0dO.&]Q`O1G0dO$9cQaO1G0dO+2^QaO1G0dO.'lQdO1G1aO.)_Q`O1G1aO.*nQdO1G1cO$9cQaO1G2VO$9cQaO7+%tO+2^QaO7+%tO.,aQdO7+%tO..SQ`O7+%tO./cQdO7+&OO.1UQ`O7+&OO$9cQaO7+'qO.2eQdO7+'qO.4WQdO<<I`O.5yQ`O<<I`O.7YQdO<<K]O$9cQaO<<K]O$9cQaOAN@wO.8{QdOAN@wO.:nQdOG26cO$9cQaOG26cO.<aQdOLD+}O.>SQaO,5;OO.>ZQaO,5;OO$9cQaO1G0jO+2^QaO1G0jO.@YQ`O'#IkO.AlQdO'#IkO.ERQ`O'#IfO.E`Q`O'#GPO.EhQaO,5:nO.EoQ`O,5<kO.EwQdO'#GYO.FYQ`O,5<kO!#_Q`O,5<kO.FbQ`O1G0YO.GtQdO,5:|O.IgQdO,5?VO.KYQ`O1G2VO!#_Q`O1G2VO.KbQdO'#IOO.KsQdO,5?jO2wQ`O1G2VO2wQ`O7+'qO.LRQ`O7+'qO.LZQdO1G2`O.MvQpO7+'qO.NRQpO<<K]O2wQ`O<<K]O.N^QpOAN@wO.NiQdO'#IfO/ SQ`O'#IfO/!vQaO,5:nO/!}QaO,5:nO/#UQ`O,5<kO/#^Q`O7+'qO/#fQ`O1G0YO/$xQ`O1G0YO/&[Q`O1G2VO/&dQ`O7+'qO/&lQpO7+'qO/&wQpOAN@wO/'SQpO<<K]O/'_QpOAN@wO/'jQ`O'#GPO/'rQ`O'#FsO/'zQ`O,5<kO/(SQdO'#JOO!#_Q`O,5<kO!#_Q`O1G2VO2wQ`O1G2VO2wQ`O7+'qO2wQ`O<<K]O/(bQ`O'#GPO/(jQ`O,5<kO/(rQ`O,5<kO!#_Q`O,5<kO!#_Q`O1G2VO!#_Q`O1G2VO2wQ`O1G2VO2wQ`O<<K]O2wQ`O7+'qO2wQ`O<<K]O/(zQ`O'#FsO/)SQ`O'#FsO/)[Q`O'#Fs",
	stateData: "/)q~O!eOS!fOS'TOS!hQQ~O!jTO'URO~OPgOQ|OS!lOU_OW}OX!XO[mO]!_O^!WO`![Oa!SOb!]Ok!dOm!lOowOp!TOq!UOsuOt!gOu!VOv!POxkOykO|!bO}aO!O^O!P!eO!QxO!R}O!TpO!VlO!WlO!X!YO!Y!QO!ZzO![!cO!]!ZO!^!^O!_!fO!a!`O!b!RO!djO!nWO!pXO!z]O#X`O#dhO#fbO#gcO#sdO$[oO$dnO$eoO$hqO$krO$u!kO%TyO%U!OO%W}O%X}O%`|O'XYO'w{O~O!h!mO~O'URO!j!iX&}!iX'R!iX~O!j!pO~O!e!qO!f!qO!h!mO'R!tO'T!qO~PhO!o!vO~PhO!n!tX#T!tX#s#vX'Q!tX!y!tX#P!tX!p!tX~OT!tXz!tX!S!tX!c!tX!r!tX!w!tX!z!tX#X!tX#a!tX#b!tX#y!tX$R!tX$S!tX$T!tX$U!tX$V!tX$X!tX$Y!tX$Z!tX$[!tX$]!tX$^!tX$_!tX%T!tX#O!tX#Y!tX!o!tXV!tX#|!tX$O!tXw!tX{!tX~P&sOT'fXz'fX!S'fX!c'fX!w'fX!z'fX#T'fX#X'fX#a'fX#b'fX#y'fX$R'fX$S'fX$T'fX$U'fX$V'fX$X'fX$Y'fX$Z'fX$['fX$]'fX$^'fX$_'fX%T'fX~O!r!xO!n'fX'Q'fX~P)dOT#SOz#QO!S#TO!c#UO!n#bO!w!yO!z!|O#T#PO#X!zO#a!{O#b!{O#y#OO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cO'Q#bO~OPgOQ|OU_OW}O[mOowOs#fOxkOykO}aO!O^O!QxO!R}O!TpO!VlO!WlO!ZzO!djO!z]O#X`O#dhO#fbO#gcO#sdO$[oO$dnO$eoO$hqO%TyO%U!OO%W}O%X}O%`|O'XYO'w{O~O!z]O~O!z#iO~OP8QOQ|OU_OW}O[8TOo?OOs#fOx8ROy8RO}aO!O^O!Q8XO!R}O!T8WO!V8SO!W8SO!Z8ZO!d:ZO!z]O#T#mO#V#lO#X`O#dhO#fbO#gcO#sdO$[8VO$d8UO$e8VO$hqO%T8YO%U!OO%W}O%X}O%`|O'XYO'w{O#Y'^P~O#O#qO~P/lO!z#rO~O#d#tO#fbO#gcO~O'b#vO~O#s#zO~OU$OO!R$OO!w#}O#s3qO'X#{O~OT'YXz'YX!S'YX!c'YX!n'YX!w'YX!z'YX#T'YX#X'YX#a'YX#b'YX#y'YX$R'YX$S'YX$T'YX$U'YX$V'YX$X'YX$Y'YX$Z'YX$['YX$]'YX$^'YX$_'YX%T'YX'Q'YX!y'YX!o'YX~O#|$QO$O$RO~P3YOP8QOQ|OU_OW}O[8TOo?OOs#fOx8ROy8RO}aO!O^O!Q8XO!R}O!T8WO!V8SO!W8SO!Z8ZO!d:ZO!z]O#X`O#dhO#fbO#gcO#sdO$[8VO$d8UO$e8VO$hqO%T8YO%U!OO%W}O%X}O%`|O'XYO'w{OT$PXz$PX!S$PX!c$PX!n$PX!w$PX#a$PX#b$PX#y$PX$R$PX$S$PX$T$PX$U$PX$V$PX$X$PX$Y$PX$Z$PX$]$PX$^$PX$_$PX'Q$PX!y$PX!o$PX~Or$TO#T8nO#V8mO~P5^O#sdO'XYO~OS$fO]$aOk$dOm$fOs$`O!a$bO$krO$u$eO~O!z$hO#T$jO'X$gO~Oo$mOs$lO#d$nO~O!z$hO#T$rO~O!U$uO$u$tO~P-ROR${O!p$zO#d$yO#g$zO'O${O~O'v$}O~P;PO!z%SO~O!z%UO~O!n#bO'Q#bO~P-RO!pXO~O!z%`O~OP8QOQ|OU_OW}O[8TOo?OOs#fOx8ROy8RO}aO!O^O!Q8XO!R}O!T8WO!V8SO!W8SO!Z8ZO!d:ZO!z]O#X`O#dhO#fbO#gcO#sdO$[8VO$d8UO$e8VO$hqO%T8YO%U!OO%W}O%X}O%`|O'XYO'w{O~O!z%dO~O]$aO~O!pXO#sdO'XYO~O]%rOs%rO#s%nO'XYO~O!j%wO'R%wO'URO~O'R%zO~PhO!o%{O~PhO!r%}O~P<XO#Y&PO~P<XO!p&SO#d&RO'b&QO~OPgOQ|OU_OW}O[:aOo?sOs#fOx:_Oy:_O}aO!O^O!Q:eO!R}O!T:dO!V:`O!W:`O!Z:gO!d:^O!z]O#V&WO#X`O#dhO#fbO#gcO#sdO$[:cO$d:bO$e:cO$hqO%T:fO%U!OO%W}O%X}O%`|O'XYO'w{O~O!y'cP~P@aO!p&[O#d&]O'X$gO~OT#SOz#QO!S#TO!c#UO!w!yO!z!|O#T#PO#X!zO#a!{O#b!{O#y#OO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cO~O!y&oO~PCVO!z$hO#T&pO~Oo$mOs$lO~O!p&qO~O#O&tO#T=YO#V=XO!y'^P~P<XOT8^Oz8[O!S8_O!c8`O!w:hO!z!|O#T#PO#X!zO#a!{O#b!{O#y#OO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O'_X#Y'_X~O#P&uO~PEqO#O&xO#Y'^X~O#Y&zO~O#O'PO!y'`P~P<XO!o'QO~PCVO!n#uX#T#uX#s#tX'Q#uX!y#uX#P#uX!p#uX~OT#uXz#uX!S#uX!c#uX!w#uX!z#uX#X#uX#a#uX#b#uX#y#uX$R#uX$S#uX$T#uX$U#uX$V#uX$X#uX$Y#uX$Z#uX$[#uX$]#uX$^#uX$_#uX%T#uX#O#uX#Y#uX!o#uXV#uX!r#uX#|#uX$O#uXw#uX~PH[O#s'RO~O'b'UO~O#n!tX#V!tX#d!tX~P&sO!y']O#T'ZO#n'XO~O#T'aO~P-RO!n$`a'Q$`a!y$`a!o$`a~PCVO!n$aa'Q$aa!y$aa!o$aa~PCVO!n$ba'Q$ba!y$ba!o$ba~PCVO!n$ca'Q$ca!y$ca!o$ca~PCVO!z!|O#X!zO#a!{O#b!{O#y#OO%T#cOT$ca!S$ca!c$ca!n$ca!w$ca#T$ca$R$ca$S$ca$T$ca$U$ca$V$ca$X$ca$Y$ca$Z$ca$[$ca$]$ca$^$ca$_$ca'Q$ca!y$ca!o$ca~Oz#QO~PMVO!n$fa'Q$fa!y$fa!o$fa~PCVO!z!|O#O$mX#Y$mX~O#O'eO#Y'jX~O#Y'gO~O#T'hO'X$gO~O]'jO~O$u'nO~O!U'tO!a'tO#T'rO#V'sO#d'qO$krO!y'hP~P2wO!_'|O!pXO!r'{O~O!z$hO'X$gO~O!z$hO~O!z$hO#T(QO~O!z$hO#T(SO~O#|(TO!n$|X#O$|X'Q$|X~O#O(UO!n'rX'Q'rX~O!n#bO'Q#bO~O!r(YO#P(XO~O!n$ta'Q$ta!y$ta!o$ta~PCVOl([Ow(]O!p(^O!z!|O~O$u(cO~O!z!|O#X!zO#a!{O#b!{O#y#OO~OT%Saz%Sa!S%Sa!c%Sa!n%Sa!w%Sa#T%Sa$R%Sa$S%Sa$T%Sa$U%Sa$V%Sa$X%Sa$Y%Sa$Z%Sa$[%Sa$]%Sa$^%Sa$_%Sa%T%Sa'Q%Sa!y%Sa#O%Sa#P%Sa#Y%Sa!o%Sa!r%SaV%Sa#|%Sa$O%Sa!p%Sa~P!%dO!n%Va'Q%Va!y%Va!o%Va~PCVO#X(fO#a(dO#b(dO'P(eOR&tX!p&tX#d&tX#g&tX'O&tX'v&tX~O'v(iO~P;PO!r(jO~PhO!p(mO!r(nO~O!r(jO'Q(qO~PhO!b(uO~O!n(vO~P<XOZ)ROn)SO~OT8^Oz8[O!S8_O!c8`O!w:hO#O)VO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!n'zX'Q'zX~P!%dOPgOQ|OU_OW}O[:aOo?sOs#fOx:_Oy:_O}aO!O^O!Q:eO!R}O!T:dO!V:`O!W:`O!Z:gO!d:^O!z]O#X`O#dhO#fbO#gcO#sdO$[:cO$d:bO$e:cO$hqO%T:fO%U!OO%W}O%X}O%`|O'XYO'w{O~O#|)ZO~O#O)[O!n'qX'Q'qX~Ol([O!p(^O~Ow(]O!p)bO!r)eO~O!n#bO!pXO'Q#bO~O#s)hO~OV)kO#O)iO!n'{X'Q'{X~O#s)mO'XYO~OT8^Oz8[O!S8_O!c8`O!w:hO#O)pO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!n'[X'Q'[X#P'[X~P!%dOl([Ow(]O!p(^O~O!j)vO'R)vO~OT8^Oz8[O!S8_O!c8`O!r)wO!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO#Y)yO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y'dX#O'dX~P!%dO!r){O!y'fX#O'fX~P)dO!y#kX#O#kX~P!+lO#O)}O!y'cX~O!y*PO~O%T#cOT$Qiz$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi$^$Qi$_$Qi'Q$Qi!y$Qi#O$Qi#P$Qi#Y$Qi!o$Qi!r$QiV$Qi#|$Qi$O$Qi!p$Qi~P!%dOz#QO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO!w!yO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi'Q$Qi!y$Qi!o$Qi~P!%dOT#SOz#QO!c#UO!w!yO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cO!S$Qi!n$Qi'Q$Qi!y$Qi!o$Qi~P!%dOT#SOz#QO!w!yO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cO!S$Qi!c$Qi!n$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO#T#PO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi$R$Qi$S$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO#T#PO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi$R$Qi$S$Qi$T$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO#T#PO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi$R$Qi$S$Qi$T$Qi$U$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO#T#PO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO$[#_O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$]$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO$Z#^O$[#_O$^#aO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$]$Qi'Q$Qi!y$Qi!o$Qi~P!%dOz#QO$_#aO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi$^$Qi'Q$Qi!y$Qi!o$Qi~P!%dO_*RO~P<XO!y*UO~O#T*XO~P<XOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O#Ua#Y#Ua#P#Ua!n#Ua'Q#Ua!r#Ua!y#Ua!o#UaV#Ua!p#Ua~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O'_a#Y'_a#P'_a!n'_a'Q'_a!r'_a!y'_a!o'_aV'_a!p'_a~P!%dO#T#mO#V#lO#O&aX#Y&aX~P<XO#O&xO#Y'^a~O#Y*[O~OT8^Oz8[O!S8_O!c8`O!w:hO#O*^O#P*]O#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!y'`X~P!%dO#O*^O!y'`X~O!y*`O~O!n#wX#T#wX#s#tX'Q#wX!y#wX#P#wX!p#wX~OT#wXz#wX!S#wX!c#wX!w#wX!z#wX#X#wX#a#wX#b#wX#y#wX$R#wX$S#wX$T#wX$U#wX$V#wX$X#wX$Y#wX$Z#wX$[#wX$]#wX$^#wX$_#wX%T#wX#O#wX#Y#wX!o#wXV#wX!r#wX#|#wX$O#wXw#wX~P#)[O#s*cO~O#n'XO!y#ma#T#ma#V#ma#d#ma!p#ma#P#ma!n#ma'Q#ma~O#T'ZO!y#oa#n#oa#V#oa#d#oa!p#oa#P#oa!n#oa'Q#oa~OPgOQ|OU_OW}O[5sOo7mOs#fOx5oOy5oO}aO!O^O!Q4RO!R}O!T5yO!V5qO!W5qO!Z4TO!d5mO!z]O#X`O#dhO#fbO#gcO#sdO$[5wO$d5uO$e5wO$hqO%T4SO%U!OO%W}O%X}O%`|O'XYO'w{O~O#n#uX#V#uX#d#uX~PH[Oz#QO!w!yO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT#Qi!S#Qi!c#Qi!n#Qi'Q#Qi!y#Qi!o#Qi~P!%dOz#QO!w!yO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT#}i!S#}i!c#}i!n#}i'Q#}i!y#}i!o#}i~P!%dO!n$Pi'Q$Pi!y$Pi!o$Pi~PCVO#sdO'XYO#O&iX#Y&iX~O#O'eO#Y'ja~Ow(]O!p)bO!r*tO~O#T*yO#V*{O#d*zO#n'XO~O!U'tO!a'tO#T*}O#V*{O#d*zO$krO~P2wO#|+PO!y$jX#O$jX~O#V*{O#d*zO~O#d+QO~O!U'tO!a'tO#d+TO~P2wO#O+UO!y'hX~O!y+WO~O!z+YO~O!_+^O!pXO!r+]O~O!r+`O!p'si!n'si'Q'si~O!r+cO#P+bO~O#d$nO!n&rX#O&rX'Q&rX~O#O(UO!n'ra'Q'ra~OT$tiz$ti!S$ti!c$ti!n$ti!w$ti!z$ti#T$ti#X$ti#a$ti#b$ti#y$ti#|#ha$O#ha$R$ti$S$ti$T$ti$U$ti$V$ti$X$ti$Y$ti$Z$ti$[$ti$]$ti$^$ti$_$ti%T$ti'Q$ti!y$ti#O$ti#P$ti#Y$ti!o$ti!r$tiV$ti!p$ti~OS+oO]+rOm+oOs$`O!U+oO!_+uO!`+oO!a+oO!o+yO#d?RO$hqO$krO~P2wO#X,QO#a,PO#b,PO~O#d,SO%W,SO%^,RO'X$gO~O!o,TO~PCVOc%bXd%bXh%bXj%bXf%bXg%bXe%bX~PhOc,XOd,VOP%aiQ%aiS%aiU%aiW%aiX%ai[%ai]%ai^%ai`%aia%aib%aik%aim%aio%aip%aiq%ais%ait%aiu%aiv%aix%aiy%ai|%ai}%ai!O%ai!P%ai!Q%ai!R%ai!T%ai!V%ai!W%ai!X%ai!Y%ai!Z%ai![%ai!]%ai!^%ai!_%ai!a%ai!b%ai!d%ai!n%ai!p%ai!z%ai#X%ai#d%ai#f%ai#g%ai#s%ai$[%ai$d%ai$e%ai$h%ai$k%ai$u%ai%T%ai%U%ai%W%ai%X%ai%`%ai&}%ai'X%ai'w%ai'R%ai!o%aih%aij%aif%aig%aiY%ai_%aii%aie%ai~Oc,]Od,YOh,[O~OY,^O_,_O!o,bO~OY,^O_,_Oi%gX~Oi,dO~Oj,eO~O!n,gO~P<XO!n,iO~Of,jO~OT8^OV,kOz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dOg,lO~O!z,mO~OZ)ROn)SOP%uiQ%uiS%uiU%uiW%uiX%ui[%ui]%ui^%ui`%uia%uib%uik%uim%uio%uip%uiq%uis%uit%uiu%uiv%uix%uiy%ui|%ui}%ui!O%ui!P%ui!Q%ui!R%ui!T%ui!V%ui!W%ui!X%ui!Y%ui!Z%ui![%ui!]%ui!^%ui!_%ui!a%ui!b%ui!d%ui!n%ui!p%ui!z%ui#X%ui#d%ui#f%ui#g%ui#s%ui$[%ui$d%ui$e%ui$h%ui$k%ui$u%ui%T%ui%U%ui%W%ui%X%ui%`%ui&}%ui'X%ui'w%ui'R%ui!o%uic%uid%uih%uij%uif%uig%uiY%ui_%uii%uie%ui~O#|,qO~O#O)VO!n%ma'Q%ma~O!y,tO~O'X$gO!n&qX#O&qX'Q&qX~O#O)[O!n'qa'Q'qa~OS+oOY,zO]+rOm+oOs$`O!U+oO!_+uO!`+oO!a+oO!o,}O#d?RO$hqO$krO~P2wO!p)bO~OU$OO!R$OO!w3wO#s3rO'X-OO~O#s-QO~O!p-SO'b'UO~O#sdO'XYO!n&{X#O&{X'Q&{X~O#O)iO!n'{a'Q'{a~O#s-YO~O!n&_X#O&_X'Q&_X#P&_X~P<XO#O)pO!n'[a'Q'[a#P'[a~Oz#QO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT!vq!S!vq!c!vq!n!vq!w!vq'Q!vq!y!vq!o!vq~P!%dO!o-_O~PCVOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y#ka#O#ka~P!%dO!y&cX#O&cX~P@aO#O)}O!y'ca~O!o-cO~PCVO#P-dO~O#O-eO!o'ZX~O!o-gO~O!y-hO~OT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O#Wi#Y#Wi~P!%dO!y&bX#O&bX~P<XO#O*^O!y'`a~O!y-nO~O#n'XO!y&ea#T&ea#V&ea#d&ea!p&ea#P&ea!n&ea'Q&ea~OT#lqz#lq!S#lq!c#lq!n#lq!w#lq#T#lq#|#lq$O#lq$R#lq$S#lq$T#lq$U#lq$V#lq$X#lq$Y#lq$Z#lq$[#lq$]#lq$^#lq$_#lq%T#lq'Q#lq!y#lq#O#lq#P#lq#Y#lq!o#lq!r#lqV#lq!p#lq~P!%dO#n#wX#V#wX#d#wX~P#)[Oz#QO!w!yO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT#Qq!S#Qq!c#Qq!n#Qq'Q#Qq!y#Qq!o#Qq~P!%dO#V-wO#d-vO~P2wO#|-xO!y$ja#O$ja~O#d-yO~O#T-zO#V-wO#d-vO#n'XO~O#V-wO#d-vO~O!U'tO!a'tO#d-|O~P2wO#T'ZO#d-|O#n'XO~O!p.OO#|.PO!y$oa#O$oa~O!U'tO!a'tO#T'rO#V'sO#d'qO$krO!y&lX#O&lX~P2wO#O+UO!y'ha~O!pXO#T'ZO#n'XO~O#T.VO#d.UO!y'mP~O!pXO!r.XO~O!r.[O!p'sq!n'sq'Q'sq~O!_.^O!pXO!r.XO~O!r.bO#P.aO~OT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!n$|i#O$|i'Q$|i~P!%dO!n$sq'Q$sq!y$sq!o$sq~PCVO#P.aO#T'ZO#n'XO~O#O.cOw'nX!p'nX!n'nX'Q'nX~O#T'ZO#d?RO#n'XO~OS+oO].hOm+oOs$`O!U+oO!`+oO!a+oO#d?RO$hqO$krO~P2wOS+oO].hOm+oOs$`O!U+oO!`+oO!a+oO#d?RO$hqO~P2wO!n#bO!p.OO'Q#bO~OS+oO]+rOm+oOs$`O!U+oO!_+uO!`+oO!a+oO!o.rO#d?RO$hqO$krO~P2wO#d.wO%W.wO%^,RO'X$gO~O%W.xO~O#Y.yO~Oc%bad%bah%baj%baf%bag%bae%ba~PhOc.|Od,VOP%aqQ%aqS%aqU%aqW%aqX%aq[%aq]%aq^%aq`%aqa%aqb%aqk%aqm%aqo%aqp%aqq%aqs%aqt%aqu%aqv%aqx%aqy%aq|%aq}%aq!O%aq!P%aq!Q%aq!R%aq!T%aq!V%aq!W%aq!X%aq!Y%aq!Z%aq![%aq!]%aq!^%aq!_%aq!a%aq!b%aq!d%aq!n%aq!p%aq!z%aq#X%aq#d%aq#f%aq#g%aq#s%aq$[%aq$d%aq$e%aq$h%aq$k%aq$u%aq%T%aq%U%aq%W%aq%X%aq%`%aq&}%aq'X%aq'w%aq'R%aq!o%aqh%aqj%aqf%aqg%aqY%aq_%aqi%aqe%aq~Oc/ROd,YOh/QO~O!r(jO~OP8QOQ|OU_OW}O[<[Oo?|Os#fOx<YOy<YO}aO!O^O!Q<aO!R}O!T<`O!V<ZO!W<ZO!Z<eO!d:[O!z]O#X`O#dhO#fbO#gcO#sdO$[<^O$d<]O$e<^O$hqO%T<cO%U!OO%W}O%X}O%`|O'XYO'w{O~O!n/UO!r/UO~OY,^O_,_O!o/WO~OY,^O_,_Oi%ga~O!y/[O~P!+lO!n/^O~O!n/^O~P<XOQ|OW}O!R}O%W}O%X}O%`|O'w{O~OT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!n&xa#O&xa'Q&xa~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!n$zi#O$zi'Q$zi~P!%dOS+oOY/hO].hOm+oOs$`O!U+oO!`+oO!a+oO#d?RO$hqO$krO~P2wOS+oOY,zO]+rOm+oOs$`O!U+oO!_+uO!`+oO!a+oO!o/kO#d?RO$hqO$krO~P2wOw!tX!p!tX#T!tX#n!tX#s#vX#|!tX'X!tX~Ow(]O!p)bO#T3}O#n3|O~O!p-SO'b&fa~O]/sOs/sO#sdO'XYO~OV/wO!n&{a#O&{a'Q&{a~O#O)iO!n'{i'Q'{i~O#s/yO~OT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!n&_a#O&_a'Q&_a#P&_a~P!%dOz#QO#T#PO$R#RO$S#VO$T#WO$U#XO$V#YO$X#[O$Y#]O$Z#^O$[#_O$]#`O$^#aO$_#aO%T#cOT!vy!S!vy!c!vy!n!vy!w!vy'Q!vy!y!vy!o!vy~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y#ji#O#ji~P!%dO_*RO!o&`X#O&`X~P<XO#O-eO!o'Za~OT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O#Wq#Y#Wq~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y#]i#O#]i~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#P0OO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!y&ba#O&ba~P!%dO#|0TO!y$ji#O$ji~O#d0UO~O#V0XO#d0WO~P2wO#T'ZO#d0YO#n'XO~O!p.OO#|0ZO!y$oi#O$oi~OT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$ji#O$ji~P!%dO!o0`O'X$gO~O#O0bO!y'mX~O#d0dO~O!y0eO~O!pXO!r0hO~O#T'ZO#n'XO!p'sy!n'sy'Q'sy~O!n$sy'Q$sy!y$sy!o$sy~PCVO#P0kO#T'ZO#n'XO~O#sdO'XYOw&nX!p&nX#O&nX!n&nX'Q&nX~O#O.cOw'na!p'na!n'na'Q'na~OS+oO]0sOm+oOs$`O!U+oO!`+oO!a+oO#d?RO$hqO~P2wO#T3}O#n3|O'X$gO~O#|)ZO#T'fX#n'fX'X'fX~O!n#bO!p0yO'Q#bO~O#Y0}O~Oh1SO~OT<jOz<fO!S<lO!c<nO!n1TO!r1TO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO~P!%dOY%fa_%fa!o%fai%fa~PhO!y1VO~O!y1VO~P!+lO!n1XO~OT8^Oz8[O!S8_O!c8`O!w:hO!y1ZO#P1YO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dO!y1ZO~O!y1[O#T'ZO#d1]O#n'XO~O!y1^O~O!n#bO#|1aO'Q#bO~O#n3|Ow#ma!p#ma#T#ma'X#ma~O#T3}Ow#oa!p#oa#n#oa'X#oa~Ow#uX!p#uX#T#uX#n#uX#s#tX'X#uX~O!p-SO'b*bO~OV1fO!o&VX#O&VX~O#O1hO!o'|X~O!o1jO~O#O)iO!n'{q'Q'{q~OT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!o!}i#O!}i~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$jq#O$jq~P!%dO#|1qO!y$jq#O$jq~O#d1rO~O!p.OO#|1sO!y$oq#O$oq~O!n#bO!pXO!z$hO#P1wO'Q#bO~O!o1zO'X$gO~OT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$oq#O$oq~P!%dO#T1|O#d1{O!y&mX#O&mX~O#O0bO!y'ma~O#T'ZO#n'XO!p's!R!n's!R'Q's!R~O!pXO!r2RO~O!n$s!R'Q$s!R!y$s!R!o$s!R~PCVO#P2TO#T'ZO#n'XO~OP8QOU_O[:{Oo?}Os#fOx:{Oy:{O}aO!O^O!Q<bO!T:{O!V:{O!W:{O!Z:{O!d:]O!o2aO!z]O#X`O#dhO#fbO#gcO#sdO$[<_O$d:{O$e<_O$hqO%T<dO%U!OO'XYO~P$<uOh2cO~OY%ei_%ei!o%eii%ei~PhOY%fi_%fi!o%fii%fi~PhO!y2fO~O!y2fO~P!+lO!y2iO~O!n#bO#|2mO'Q#bO~O%W2nO%`2nO~O#n3|Ow&ea!p&ea#T&ea'X&ea~Ow#wX!p#wX#T#wX#n#wX#s#tX'X#wX~OV2qO!o&Va#O&Va~O]2sOs2sO#sdO'XYO!o&|X#O&|X~O#O1hO!o'|a~OT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y#^i#O#^i~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$jy#O$jy~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$oy#O$oy~P!%dO!pXO#P2{O~O#d2|O~O#O0bO!y'mi~O!n$s!Z'Q$s!Z!y$s!Z!o$s!Z~PCVOT<kOz<gO!S<mO!c<oO!w?hO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cO~P!%dOV3UO{3TO~P)dOV3UO{3TOT']Xz']X!S']X!c']X!w']X!z']X#T']X#X']X#a']X#b']X#y']X#|']X$O']X$R']X$S']X$T']X$U']X$V']X$X']X$Y']X$Z']X$[']X$]']X$^']X$_']X%T']X~OP8QOU_O[:{Oo?}Os#fOx:{Oy:{O}aO!O^O!Q<bO!T:{O!V:{O!W:{O!Z:{O!d:]O!o3XO!z]O#X`O#dhO#fbO#gcO#sdO$[<_O$d:{O$e<_O$hqO%T<dO%U!OO'XYO~P$<uOY%eq_%eq!o%eqi%eq~PhO!y3ZO~O!y%pi~PCVOe3[O~O%W3]O%`3]O~OV3`O!o&WX#O&WX~OT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$j!R#O$j!R~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$o!R#O$o!R~P!%dO!n$s!c'Q$s!c!y$s!c!o$s!c~PCVO!a3iO'X$gO~OV3mO!o&Wa#O&Wa~O'X$gO!n%Ri'Q%Ri~O'b'_O~O'b/oO~O'b*kO~O'b1cO~OT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$ta#|$ta$O$ta'Q$ta!y$ta!o$ta#O$ta~P!%dO#T4OO~P-RO#s3uO~O#s3vO~O!U$uO$u$tO~P#-ZOT8^Oz8[O!S8_O!c8`O!w:hO#P3yO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!n'_X'Q'_X!y'_X!o'_X~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#P5jO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O'_X#Y'_X#|'_X$O'_X!n'_X'Q'_X!r'_X!y'_X!o'_XV'_X!p'_X~P!%dO#T5XO~P#-ZOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$`a#|$`a$O$`a'Q$`a!y$`a!o$`a#O$`a~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$aa#|$aa$O$aa'Q$aa!y$aa!o$aa#O$aa~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$ba#|$ba$O$ba'Q$ba!y$ba!o$ba#O$ba~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$ca#|$ca$O$ca'Q$ca!y$ca!o$ca#O$ca~P!%dOz4UO#|$ca$O$ca#O$ca~PMVOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$fa#|$fa$O$fa'Q$fa!y$fa!o$fa#O$fa~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n%Va#|%Va$O%Va'Q%Va!y%Va!o%Va#O%Va~P!%dOz4UO#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#|$Qi$O$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi#|$Qi$O$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOT4WOz4UO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!S$Qi!n$Qi#|$Qi$O$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOT4WOz4UO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!S$Qi!c$Qi!n$Qi#|$Qi$O$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO#T#PO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#|$Qi$O$Qi$R$Qi$S$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO#T#PO$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO#T#PO$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO#T#PO$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO$[4cO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$]$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO$Z4bO$[4cO$^4eO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$]$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOz4UO$_4eO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!w$Qi#T$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi$^$Qi'Q$Qi!y$Qi!o$Qi#O$Qi~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n#Ua#|#Ua$O#Ua'Q#Ua!y#Ua!o#Ua#O#Ua~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n'_a#|'_a$O'_a'Q'_a!y'_a!o'_a#O'_a~P!%dOz4UO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT#Qi!S#Qi!c#Qi!n#Qi#|#Qi$O#Qi'Q#Qi!y#Qi!o#Qi#O#Qi~P!%dOz4UO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT#}i!S#}i!c#}i!n#}i#|#}i$O#}i'Q#}i!y#}i!o#}i#O#}i~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$Pi#|$Pi$O$Pi'Q$Pi!y$Pi!o$Pi#O$Pi~P!%dOz4UO#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT!vq!S!vq!c!vq!n!vq!w!vq#|!vq$O!vq'Q!vq!y!vq!o!vq#O!vq~P!%dOz4UO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT#Qq!S#Qq!c#Qq!n#Qq#|#Qq$O#Qq'Q#Qq!y#Qq!o#Qq#O#Qq~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$sq#|$sq$O$sq'Q$sq!y$sq!o$sq#O$sq~P!%dOz4UO#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cOT!vy!S!vy!c!vy!n!vy!w!vy#|!vy$O!vy'Q!vy!y!vy!o!vy#O!vy~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$sy#|$sy$O$sy'Q$sy!y$sy!o$sy#O$sy~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$s!R#|$s!R$O$s!R'Q$s!R!y$s!R!o$s!R#O$s!R~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$s!Z#|$s!Z$O$s!Z'Q$s!Z!y$s!Z!o$s!Z#O$s!Z~P!%dOT4WOz4UO!S4XO!c4YO!w5{O#T#PO$R4VO$S4ZO$T4[O$U4]O$V4^O$X4`O$Y4aO$Z4bO$[4cO$]4dO$^4eO$_4eO%T#cO!n$s!c#|$s!c$O$s!c'Q$s!c!y$s!c!o$s!c#O$s!c~P!%dOP8QOU_O[5tOo:ROs#fOx5pOy5pO}aO!O^O!Q6UO!T5zO!V5rO!W5rO!Z6WO!d5nO!z]O#T5kO#X`O#dhO#fbO#gcO#sdO$[5xO$d5vO$e5xO$hqO%T6VO%U!OO'XYO~P$<uOP8QOU_O[5tOo:ROs#fOx5pOy5pO}aO!O^O!Q6UO!T5zO!V5rO!W5rO!Z6WO!d5nO!z]O#X`O#dhO#fbO#gcO#sdO$[5xO$d5vO$e5xO$hqO%T6VO%U!OO'XYO~P$<uO#|4jO$O4kO#O'YX~P3YOP8QOU_O[5tOo:ROr4lOs#fOx5pOy5pO}aO!O^O!Q6UO!T5zO!V5rO!W5rO!Z6WO!d5nO!z]O#T4iO#V4hO#X`O#dhO#fbO#gcO#sdO$[5xO$d5vO$e5xO$hqO%T6VO%U!OO'XYOT$PXz$PX!S$PX!c$PX!n$PX!w$PX#a$PX#b$PX#y$PX#|$PX$O$PX$R$PX$S$PX$T$PX$U$PX$V$PX$X$PX$Y$PX$Z$PX$]$PX$^$PX$_$PX'Q$PX!y$PX!o$PX#O$PX~P$<uOP8QOU_O[5tOo:ROr6mOs#fOx5pOy5pO}aO!O^O!Q6UO!T5zO!V5rO!W5rO!Z6WO!d5nO!z]O#T6jO#V6iO#X`O#dhO#fbO#gcO#sdO$[5xO$d5vO$e5xO$hqO%T6VO%U!OO'XYOT$PXz$PX!S$PX!c$PX!w$PX#O$PX#P$PX#Y$PX#a$PX#b$PX#y$PX#|$PX$O$PX$R$PX$S$PX$T$PX$U$PX$V$PX$X$PX$Y$PX$Z$PX$]$PX$^$PX$_$PX!n$PX'Q$PX!r$PX!y$PX!o$PXV$PX!p$PX~P$<uO!r4tO~P<XO!r7rO#P5[O~OT8^Oz8[O!S8_O!c8`O!r5]O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dO!r7sO#P5`O~O!r7tO#P5dO~O#P5dO#T'ZO#n'XO~O#P5eO#T'ZO#n'XO~O#P5hO#T'ZO#n'XO~OP8QOU_O[5tOo:ROs#fOx5pOy5pO}aO!O^O!Q6UO!T5zO!U$uO!V5rO!W5rO!Z6WO!d5nO!z]O#X`O#dhO#fbO#gcO#sdO$[5xO$d5vO$e5xO$hqO$u$tO%T6VO%U!OO'XYO~P$<uOP8QOU_O[5tOo:ROs#fOx5pOy5pO}aO!O^O!Q6UO!T5zO!V5rO!W5rO!Z6WO!d5nO!z]O#T7YO#X`O#dhO#fbO#gcO#sdO$[5xO$d5vO$e5xO$hqO%T6VO%U!OO'XYO~P$<uOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$`a#P$`a#Y$`a#|$`a$O$`a!n$`a'Q$`a!r$`a!y$`a!o$`aV$`a!p$`a~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$aa#P$aa#Y$aa#|$aa$O$aa!n$aa'Q$aa!r$aa!y$aa!o$aaV$aa!p$aa~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$ba#P$ba#Y$ba#|$ba$O$ba!n$ba'Q$ba!r$ba!y$ba!o$baV$ba!p$ba~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$ca#P$ca#Y$ca#|$ca$O$ca!n$ca'Q$ca!r$ca!y$ca!o$caV$ca!p$ca~P!%dOz6XO#O$ca#P$ca#Y$ca#|$ca$O$ca!r$caV$ca!p$ca~PMVOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$fa#P$fa#Y$fa#|$fa$O$fa!n$fa'Q$fa!r$fa!y$fa!o$faV$fa!p$fa~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O%Va#P%Va#Y%Va#|%Va$O%Va!n%Va'Q%Va!r%Va!y%Va!o%VaV%Va!p%Va~P!%dOz6XO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi#|$Qi$O$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi#O$Qi#P$Qi#Y$Qi#|$Qi$O$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOT6ZOz6XO!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO!S$Qi#O$Qi#P$Qi#Y$Qi#|$Qi$O$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOT6ZOz6XO!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO!S$Qi!c$Qi#O$Qi#P$Qi#Y$Qi#|$Qi$O$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO#T#PO$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO#T#PO$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO#T#PO$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO#T#PO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO$[6fO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$]$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO$Z6eO$[6fO$^6hO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$]$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz6XO$_6hO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi#|$Qi$O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi$^$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O#Ua#P#Ua#Y#Ua#|#Ua$O#Ua!n#Ua'Q#Ua!r#Ua!y#Ua!o#UaV#Ua!p#Ua~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O'_a#P'_a#Y'_a#|'_a$O'_a!n'_a'Q'_a!r'_a!y'_a!o'_aV'_a!p'_a~P!%dOz6XO!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT#Qi!S#Qi!c#Qi#O#Qi#P#Qi#Y#Qi#|#Qi$O#Qi!n#Qi'Q#Qi!r#Qi!y#Qi!o#QiV#Qi!p#Qi~P!%dOz6XO!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT#}i!S#}i!c#}i#O#}i#P#}i#Y#}i#|#}i$O#}i!n#}i'Q#}i!r#}i!y#}i!o#}iV#}i!p#}i~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$Pi#P$Pi#Y$Pi#|$Pi$O$Pi!n$Pi'Q$Pi!r$Pi!y$Pi!o$PiV$Pi!p$Pi~P!%dOz6XO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT!vq!S!vq!c!vq!w!vq#O!vq#P!vq#Y!vq#|!vq$O!vq!n!vq'Q!vq!r!vq!y!vq!o!vqV!vq!p!vq~P!%dOz6XO!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT#Qq!S#Qq!c#Qq#O#Qq#P#Qq#Y#Qq#|#Qq$O#Qq!n#Qq'Q#Qq!r#Qq!y#Qq!o#QqV#Qq!p#Qq~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$sq#P$sq#Y$sq#|$sq$O$sq!n$sq'Q$sq!r$sq!y$sq!o$sqV$sq!p$sq~P!%dOz6XO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cOT!vy!S!vy!c!vy!w!vy#O!vy#P!vy#Y!vy#|!vy$O!vy!n!vy'Q!vy!r!vy!y!vy!o!vyV!vy!p!vy~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$sy#P$sy#Y$sy#|$sy$O$sy!n$sy'Q$sy!r$sy!y$sy!o$syV$sy!p$sy~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$s!R#P$s!R#Y$s!R#|$s!R$O$s!R!n$s!R'Q$s!R!r$s!R!y$s!R!o$s!RV$s!R!p$s!R~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$s!Z#P$s!Z#Y$s!Z#|$s!Z$O$s!Z!n$s!Z'Q$s!Z!r$s!Z!y$s!Z!o$s!ZV$s!Z!p$s!Z~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$s!c#P$s!c#Y$s!c#|$s!c$O$s!c!n$s!c'Q$s!c!r$s!c!y$s!c!o$s!cV$s!c!p$s!c~P!%dO#T7lO~P#-ZO!z$hO#T7pO~O!y6OO#T'ZO#n'XO~O!z$hO#T7qO~OT6ZOz6XO!S6[O!c6]O!w7xO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO#O$ta#P$ta#Y$ta#|$ta$O$ta!n$ta'Q$ta!r$ta!y$ta!o$taV$ta!p$ta~P!%dOT6ZOz6XO!S6[O!c6]O!w7xO#P7kO#T#PO$R6YO$S6^O$T6_O$U6`O$V6aO$X6cO$Y6dO$Z6eO$[6fO$]6gO$^6hO$_6hO%T#cO!n'_X#|'_X$O'_X'Q'_X!y'_X!o'_X#O'_X~P!%dO#|6kO$O6lO#O'YX#P'YX#Y'YX!r'YXV'YX!p'YX~P3YO!r6uO~P<XO!r:VO#P7]O~OT8^Oz8[O!S8_O!c8`O!r7^O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dO!r:WO#P7aO~O!r:XO#P7eO~O#P7eO#T'ZO#n'XO~O#P7fO#T'ZO#n'XO~O#P7iO#T'ZO#n'XO~O!U$uO$u$tO~P<XOo7oOs$lO~O#T9dO~P<XOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$`a#P$`a#Y$`a!n$`a'Q$`a!r$`a!y$`a!o$`aV$`a!p$`a~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$aa#P$aa#Y$aa!n$aa'Q$aa!r$aa!y$aa!o$aaV$aa!p$aa~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$ba#P$ba#Y$ba!n$ba'Q$ba!r$ba!y$ba!o$baV$ba!p$ba~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$ca#P$ca#Y$ca!n$ca'Q$ca!r$ca!y$ca!o$caV$ca!p$ca~P!%dOz8[O#O$ca#P$ca#Y$ca!r$caV$ca!p$ca~PMVOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$fa#P$fa#Y$fa!n$fa'Q$fa!r$fa!y$fa!o$faV$fa!p$fa~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$ta#P$ta#Y$ta!n$ta'Q$ta!r$ta!y$ta!o$taV$ta!p$ta~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O%Va#P%Va#Y%Va!n%Va'Q%Va!r%Va!y%Va!o%VaV%Va!p%Va~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#O9hO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y'zX~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#O9jO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y'[X~P!%dOz8[O#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi#O$Qi#P$Qi#Y$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOT8^Oz8[O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!S$Qi#O$Qi#P$Qi#Y$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOT8^Oz8[O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!S$Qi!c$Qi#O$Qi#P$Qi#Y$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O#T#PO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi$R$Qi$S$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O#T#PO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi$R$Qi$S$Qi$T$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O#T#PO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O#T#PO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O$[8iO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$]$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O$Z8hO$[8iO$^8kO$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$]$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dOz8[O$_8kO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#O$Qi#P$Qi#T$Qi#Y$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi$^$Qi!n$Qi'Q$Qi!r$Qi!y$Qi!o$QiV$Qi!p$Qi~P!%dO#T9oO~P!+lO!n#Ua'Q#Ua!y#Ua!o#Ua~PCVO!n'_a'Q'_a!y'_a!o'_a~PCVO#T=YO#V=XO!y&aX#O&aX~P<XO#O9aO!y'^a~Oz8[O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT#Qi!S#Qi!c#Qi#O#Qi#P#Qi#Y#Qi!n#Qi'Q#Qi!r#Qi!y#Qi!o#QiV#Qi!p#Qi~P!%dOz8[O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT#}i!S#}i!c#}i#O#}i#P#}i#Y#}i!n#}i'Q#}i!r#}i!y#}i!o#}iV#}i!p#}i~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$Pi#P$Pi#Y$Pi!n$Pi'Q$Pi!r$Pi!y$Pi!o$PiV$Pi!p$Pi~P!%dO#O9hO!y%ma~O!y&_X#O&_X~P!+lO#O9jO!y'[a~Oz8[O#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT!vq!S!vq!c!vq!w!vq#O!vq#P!vq#Y!vq!n!vq'Q!vq!r!vq!y!vq!o!vqV!vq!p!vq~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y#Wi#O#Wi~P!%dOz8[O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT#Qq!S#Qq!c#Qq#O#Qq#P#Qq#Y#Qq!n#Qq'Q#Qq!r#Qq!y#Qq!o#QqV#Qq!p#Qq~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$sq#P$sq#Y$sq!n$sq'Q$sq!r$sq!y$sq!o$sqV$sq!p$sq~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y&xa#O&xa~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y&_a#O&_a~P!%dOz8[O#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cOT!vy!S!vy!c!vy!w!vy#O!vy#P!vy#Y!vy!n!vy'Q!vy!r!vy!y!vy!o!vyV!vy!p!vy~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y#Wq#O#Wq~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$sy#P$sy#Y$sy!n$sy'Q$sy!r$sy!y$sy!o$syV$sy!p$sy~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$s!R#P$s!R#Y$s!R!n$s!R'Q$s!R!r$s!R!y$s!R!o$s!RV$s!R!p$s!R~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$s!Z#P$s!Z#Y$s!Z!n$s!Z'Q$s!Z!r$s!Z!y$s!Z!o$s!ZV$s!Z!p$s!Z~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO#O$s!c#P$s!c#Y$s!c!n$s!c'Q$s!c!r$s!c!y$s!c!o$s!cV$s!c!p$s!c~P!%dO#T:PO~P<XO#P:OO!n'_X'Q'_X!r'_X!y'_X!o'_XV'_X!p'_X~PEqO!z$hO#T:TO~O!z$hO#T:UO~O#|8oO$O8pO#O'YX#P'YX#Y'YX!r'YXV'YX!p'YX~P3YOr8qO#T#mO#V#lO#O$PX#P$PX#Y$PX!r$PXV$PX!p$PX~P5^Or=_O#T:|O#V:zOT$PXz$PX!S$PX!c$PX!n$PX!r$PX!w$PX#a$PX#b$PX#y$PX$R$PX$S$PX$T$PX$U$PX$V$PX$X$PX$Y$PX$Z$PX$]$PX$^$PX$_$PX!o$PX#O$PX!p$PX'Q$PX~P<XOr:{O#T:{O#V:{OT$PXz$PX!S$PX!c$PX!w$PX#a$PX#b$PX#y$PX$R$PX$S$PX$T$PX$U$PX$V$PX$X$PX$Y$PX$Z$PX$]$PX$^$PX$_$PX~P<XOr;QO#T=YO#V=XOT$PXz$PX!S$PX!c$PX!w$PX!y$PX#O$PX#a$PX#b$PX#y$PX$R$PX$S$PX$T$PX$U$PX$V$PX$X$PX$Y$PX$Z$PX$]$PX$^$PX$_$PX~P<XO!U$uO$u$tO~P!+lO!r8|O~P<XOT8^Oz8[O!S8_O!c8`O!w:hO#P9^O#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!y'_X#O'_X~P!%dOP8QOU_O[:{Oo?}Os#fOx:{Oy:{O}aO!O^O!Q<bO!T:{O!V:{O!W:{O!Z:{O!d:]O!z]O#X`O#dhO#fbO#gcO#sdO$[<_O$d:{O$e<_O$hqO%T<dO%U!OO'XYO~P$<uO#O9aO!y'^X~O#T;nO~P!+lOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$`a#O$`a~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$aa#O$aa~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$ba#O$ba~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$ca#O$ca~P!%dOz:iO%T#cOT$ca!S$ca!c$ca!w$ca!y$ca#O$ca#T$ca$R$ca$S$ca$T$ca$U$ca$V$ca$X$ca$Y$ca$Z$ca$[$ca$]$ca$^$ca$_$ca~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$fa#O$fa~P!%dO!r?]O#P9gO~OT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$ta#O$ta~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y%Va#O%Va~P!%dOT8^Oz8[O!S8_O!c8`O!r9lO!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dOz:iO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi~P!%dOz:iO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!y$Qi#O$Qi~P!%dOT:kOz:iO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!S$Qi!y$Qi#O$Qi~P!%dOT:kOz:iO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!S$Qi!c$Qi!y$Qi#O$Qi~P!%dOz:iO#T#PO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi$R$Qi$S$Qi~P!%dOz:iO#T#PO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi$R$Qi$S$Qi$T$Qi~P!%dOz:iO#T#PO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi$R$Qi$S$Qi$T$Qi$U$Qi~P!%dOz:iO#T#PO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi~P!%dOz:iO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi~P!%dOz:iO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi~P!%dOz:iO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi~P!%dOz:iO$[:vO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$]$Qi~P!%dOz:iO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi~P!%dOz:iO$Z:uO$[:vO$^:xO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$]$Qi~P!%dOz:iO$_:xO%T#cOT$Qi!S$Qi!c$Qi!w$Qi!y$Qi#O$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi$^$Qi~P!%dOz:iO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT#Qi!S#Qi!c#Qi!y#Qi#O#Qi~P!%dOz:iO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT#}i!S#}i!c#}i!y#}i#O#}i~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$Pi#O$Pi~P!%dO!r?^O#P9qO~Oz:iO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT!vq!S!vq!c!vq!w!vq!y!vq#O!vq~P!%dOz:iO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT#Qq!S#Qq!c#Qq!y#Qq#O#Qq~P!%dO!r?cO#P9xO~OT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$sq#O$sq~P!%dO#P9xO#T'ZO#n'XO~Oz:iO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cOT!vy!S!vy!c!vy!w!vy!y!vy#O!vy~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$sy#O$sy~P!%dO#P9yO#T'ZO#n'XO~OT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$s!R#O$s!R~P!%dO#P9|O#T'ZO#n'XO~OT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$s!Z#O$s!Z~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y$s!c#O$s!c~P!%dO#T<WO~P!+lOT8^Oz8[O!S8_O!c8`O!w:hO#P<VO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!y'_X#O'_X~P!%dO!U$uO$u$tO~P$9cOP8QOU_O[:{Oo?}Os#fOx:{Oy:{O}aO!O^O!Q<bO!T:{O!U$uO!V:{O!W:{O!Z:{O!d:]O!z]O#X`O#dhO#fbO#gcO#sdO$[<_O$d:{O$e<_O$hqO$u$tO%T<dO%U!OO'XYO~P$<uOo:SOs$lO~O#T>`O~P$9cOP8QOU_O[:{Oo?}Os#fOx:{Oy:{O}aO!O^O!Q<bO!T:{O!V:{O!W:{O!Z:{O!d:]O!z]O#T>aO#X`O#dhO#fbO#gcO#sdO$[<_O$d:{O$e<_O$hqO%T<dO%U!OO'XYO~P$<uOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$`a!r$`a!o$`a#O$`a!p$`a'Q$`a~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$aa!r$aa!o$aa#O$aa!p$aa'Q$aa~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$ba!r$ba!o$ba#O$ba!p$ba'Q$ba~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$ca!r$ca!o$ca#O$ca!p$ca'Q$ca~P!%dOz<fO%T#cOT$ca!S$ca!c$ca!n$ca!r$ca!w$ca#T$ca$R$ca$S$ca$T$ca$U$ca$V$ca$X$ca$Y$ca$Z$ca$[$ca$]$ca$^$ca$_$ca!o$ca#O$ca!p$ca'Q$ca~P!%dOz<gO%T#cOT$ca!S$ca!c$ca!w$ca#T$ca$R$ca$S$ca$T$ca$U$ca$V$ca$X$ca$Y$ca$Z$ca$[$ca$]$ca$^$ca$_$ca~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$fa!r$fa!o$fa#O$fa!p$fa'Q$fa~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$ta!r$ta!o$ta#O$ta!p$ta'Q$ta~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n%Va!r%Va!o%Va#O%Va!p%Va'Q%Va~P!%dOz<fO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi~P!%dOz<fO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO!w?hO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi~P!%dOT<jOz<fO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!S$Qi!n$Qi!r$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOT<kOz<gO!c<oO!w?hO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cO!S$Qi~P!%dOT<jOz<fO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!S$Qi!c$Qi!n$Qi!r$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOT<kOz<gO!w?hO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cO!S$Qi!c$Qi~P!%dOz<fO#T#PO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi$R$Qi$S$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO#T#PO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi$R$Qi$S$Qi~P!%dOz<fO#T#PO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi$R$Qi$S$Qi$T$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO#T#PO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi$R$Qi$S$Qi$T$Qi~P!%dOz<fO#T#PO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi$R$Qi$S$Qi$T$Qi$U$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO#T#PO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi$R$Qi$S$Qi$T$Qi$U$Qi~P!%dOz<fO#T#PO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO#T#PO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi~P!%dOz<fO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi~P!%dOz<fO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi~P!%dOz<fO$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi~P!%dOz<fO$[=QO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$]$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO$[=RO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$]$Qi~P!%dOz<fO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi~P!%dOz<fO$Z=OO$[=QO$^=UO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$]$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO$Z=PO$[=RO$^=VO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$]$Qi~P!%dOz<fO$_=UO%T#cOT$Qi!S$Qi!c$Qi!n$Qi!r$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi$^$Qi!o$Qi#O$Qi!p$Qi'Q$Qi~P!%dOz<gO$_=VO%T#cOT$Qi!S$Qi!c$Qi!w$Qi#T$Qi$R$Qi$S$Qi$T$Qi$U$Qi$V$Qi$X$Qi$Y$Qi$Z$Qi$[$Qi$]$Qi$^$Qi~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y#Ua#O#Ua~P!%dOT:kOz:iO!S:lO!c:mO!w?PO#T#PO$R:jO$S:nO$T:oO$U:pO$V:qO$X:sO$Y:tO$Z:uO$[:vO$]:wO$^:xO$_:xO%T#cO!y'_a#O'_a~P!%dOz<fO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT#Qi!S#Qi!c#Qi!n#Qi!r#Qi!o#Qi#O#Qi!p#Qi'Q#Qi~P!%dOz<gO!w?hO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT#Qi!S#Qi!c#Qi~P!%dOz<fO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT#}i!S#}i!c#}i!n#}i!r#}i!o#}i#O#}i!p#}i'Q#}i~P!%dOz<gO!w?hO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT#}i!S#}i!c#}i~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$Pi!r$Pi!o$Pi#O$Pi!p$Pi'Q$Pi~P!%dOz<fO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT!vq!S!vq!c!vq!n!vq!r!vq!w!vq!o!vq#O!vq!p!vq'Q!vq~P!%dOz<gO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT!vq!S!vq!c!vq!w!vq~P!%dOz<fO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT#Qq!S#Qq!c#Qq!n#Qq!r#Qq!o#Qq#O#Qq!p#Qq'Q#Qq~P!%dOz<gO!w?hO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT#Qq!S#Qq!c#Qq~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$sq!r$sq!o$sq#O$sq!p$sq'Q$sq~P!%dOz<fO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cOT!vy!S!vy!c!vy!n!vy!r!vy!w!vy!o!vy#O!vy!p!vy'Q!vy~P!%dOz<gO#T#PO$R<iO$S<qO$T<sO$U<uO$V<wO$X<{O$Y<}O$Z=PO$[=RO$]=TO$^=VO$_=VO%T#cOT!vy!S!vy!c!vy!w!vy~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$sy!r$sy!o$sy#O$sy!p$sy'Q$sy~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$s!R!r$s!R!o$s!R#O$s!R!p$s!R'Q$s!R~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$s!Z!r$s!Z!o$s!Z#O$s!Z!p$s!Z'Q$s!Z~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$s!c!r$s!c!o$s!c#O$s!c!p$s!c'Q$s!c~P!%dO#T>yO~P$9cOP8QOU_O[:{Oo?}Os#fOx:{Oy:{O}aO!O^O!Q<bO!T:{O!V:{O!W:{O!Z:{O!d:]O!z]O#T>zO#X`O#dhO#fbO#gcO#sdO$[<_O$d:{O$e<_O$hqO%T<dO%U!OO'XYO~P$<uOT8^Oz8[O!S8_O!c8`O!w:hO#P>xO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dOT8^Oz8[O!S8_O!c8`O!w:hO#P>wO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO!n'_X!r'_X!o'_X#O'_X!p'_X'Q'_X~P!%dOT'YXz'YX!S'YX!c'YX!w'YX!z'YX#O'YX#T'YX#X'YX#a'YX#b'YX#y'YX$R'YX$S'YX$T'YX$U'YX$V'YX$X'YX$Y'YX$Z'YX$['YX$]'YX$^'YX$_'YX%T'YX~O#|;OO$O;PO!y'YX~P.CbO!z$hO#T?TO~O!r;]O~P<XO!z$hO#T?YO~O#|;rO!n$|X!p$|X#O$|X'Q$|X~O!r?yO#P;sO~OT8^Oz8[O!S8_O!c8`O!r;tO!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n#Ua!r#Ua!o#Ua#O#Ua!p#Ua'Q#Ua~P!%dOT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n'_a!r'_a!o'_a#O'_a!p'_a'Q'_a~P!%dO!r?zO#P;wO~O#d?RO!n&rX!p&rX#O&rX'Q&rX~O#O?ZO!n'ra!p'ra'Q'ra~O!r?{O#P<OO~OT<jOz<fO!S<lO!c<nO!w?gO#T#PO$R<hO$S<pO$T<rO$U<tO$V<vO$X<zO$Y<|O$Z=OO$[=QO$]=SO$^=UO$_=UO%T#cO!n$|i!p$|i#O$|i'Q$|i~P!%dO#P<OO#T'ZO#n'XO~O#P<PO#T'ZO#n'XO~O#P<TO#T'ZO#n'XO~O#|=ZO$O=]O!n'YX!r'YX!o'YX!p'YX'Q'YX~P.CbO#|=[O$O=^OT'YXz'YX!S'YX!c'YX!w'YX!z'YX#T'YX#X'YX#a'YX#b'YX#y'YX$R'YX$S'YX$T'YX$U'YX$V'YX$X'YX$Y'YX$Z'YX$['YX$]'YX$^'YX$_'YX%T'YX~O!r=jO~P<XO!r=kO~P<XO!r@SO#P>eO~O!r@TO#P:{O~OT8^Oz8[O!S8_O!c8`O!r>fO!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dOT8^Oz8[O!S8_O!c8`O!r>gO!w:hO#T#PO$R8]O$S8aO$T8bO$U8cO$V8dO$X8fO$Y8gO$Z8hO$[8iO$]8jO$^8kO$_8kO%T#cO~P!%dO!r@UO#P>lO~O!r@VO#P>qO~O#P>qO#T'ZO#n'XO~O#P:{O#T'ZO#n'XO~O#P>rO#T'ZO#n'XO~O#P>uO#T'ZO#n'XO~O!z$hO#T?wO~Oo?QOs$lO~O!z$hO#T?xO~O#O?ZO!n'rX!p'rX'Q'rX~O!z$hO#T@PO~O!z$hO#T@QO~O!z$hO#T@RO~Oo?uOs$lO~Oo@OOs$lO~Oo?}Os$lO~O%X$]%W$k!e$^#d%`#g'w'X#f~",
	goto: "%2U'}PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP(OP(VPP(](`PPP(xP(`*q(`6gP6gPP>hGOGRPP6gGX! YP! ]P! ]PPGX! l! o! sGXGXPP! vP! yPPGX!)}!0z!0zGX!1OP!1O!1O!1O!2ZP!;s!<a!<m!F_!FmP!Np!NsP6gP6g6gPPPPP!NvPPPPPPP6g6g6g6gPP6g6gP#&e#(^P#(b#)U#(^#(^#)[#)q#)u6g6gP#*O#*f#+a#,e#,k#,e#,y#,e#,e#-_#-b#-b6gPP6gPP#-f#5h#5h#5lP#5rP(`#5v(`#6`#6c#6c#6i(`#6l(`(`#6r#6u(`#7O#7R(`(`(`(`(`#7U(`(`(`(`(`(`(`(`(`#7X#7k(`(`#7o#8P#8S(`(`P#8V#8^#8d#9P#9Z#9a#9k#9r#9x#:}#<Q#<b#<z#=v#=|#>X#>_#>e#>o#>u#>{#?Z#?a#?k#?q#?w#?}#@T#@_#@i#@o#@u#APPPPPPPPP#AV#AZP#BP$)^$)a$)k$1x$2U$2k$2qP$2t$2w$2}$6U$@U$Ho$Hr$Hx$H{$IS$Lf$Li$Lr$Lz$MU$Mm$NT% O%)SPP%1U%1Y%1f%1{%2RQ!nQT!qV!rQUOR%x!mRVO}!hPVX!S!j!r!s!w%O%Q%T%V(j,U,X.z.|/U1T1U1^2e|!hPVX!S!j!r!s!w%O%Q%T%V(j,U,X.z.|/U1T1U1^2eQ%_!ZQ%h!aQ%m!eQ'k$cQ'z$iQ)f%lQ+['}Q,o)SU.T+X+Z+aQ.o+tQ/e,nS0g.Y.ZQ0w.iQ1v0]S2P0f0jQ2Y0tQ2z1xQ2}2QR3e3O|ZPVX!S!j!r!s!w%O%Q%T%V(j,U,X.z.|/U1T1U1^2e2pf]`cgjklmnoprxyz!W!X!Y!]!e!f!g!y!z#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r#}$Q$R$T$h$z%S%U%d%r%}&S&W&[&q&t&u&x'P'X'Z']'a'e'p'v'{(T(X(Y([(](^(v)V)Z)b)e)i)p)w){*X*]*^*t*y+O+P+U+]+`+b+c+n+q+u+x,^,g,i,k,m,y,|-S-d-e-x-z.P.X.[.a.b.c.g/^/s0O0T0Z0h0k1X1Y1h1q1s1w2R2T2s2{3w3y3|3}4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7r7s7t7x8Q8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:V:W:X:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?]?^?c?g?h?y?z?{@S@T@U@VS$ku$`Q%W!V^%e!_$a'j)[.k0u2WQ%i!bQ%j!cQ%k!dQ%v!kS&V!|)}Q&]#OQ'l$dQ'm$eS(O$j'hQ)U%`Q*x'nQ,O(dQ,S(fQ-W)kU.l+r.h0sQ.v,PQ.w,QQ/i,zS0].O0_Q1_/hQ1k/wS2]0y2`Q2p1fQ3_2qQ3g3TQ3h3UQ3l3`Q3o3iR3p3m0}!OPVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k-d-e-x.P.a.z.|/U/^0O0T0Z0k0y1T1U1X1Y1^1q1s1w2T2`2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?h0|!OPVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k-d-e-x.P.a.z.|/U/^0O0T0Z0k0y1T1U1X1Y1^1q1s1w2T2`2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?hQ#h^Q%O!PQ%P!QQ%Q!RQ,f(uQ.z,VR/O,YR&r#hQ*S&qR/|-e0}hPVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k-d-e-x.P.a.z.|/U/^0O0T0Z0k0y1T1U1X1Y1^1q1s1w2T2`2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?hR#j_k#n`j#i#q&t&x5m5n9a:Z:[:]:^R#saT&}#r'PR-l*^R&R!{0|hPVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k-d-e-x.P.a.z.|/U/^0O0T0Z0k0y1T1U1X1Y1^1q1s1w2T2`2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?hR#tb-z!}[#e#k#u$U$V$W$X$Y$Z$v$w%X%Z%]%a%s%|&O&U&_&`&a&b&c&d&e&f&g&h&i&j&k&l&m&n&v&w&|'`'b'c(g(z)x)z)|*Q*W*j*l+e+h,r,u-[-^-`-i-j-k-}._/T/a/{0V0a0l1m1p1u2S2[2h2w2x2y3P3d4f4g4m4n4o4p4q4r4s4u4v4w4x4y4z4{4|4}5O5P5Q5R5S5T5U5V5W5Y5Z5^5_5a5b5c5f5g5i5}6n6o6p6q6r6s6t6v6w6x6y6z6{6|6}7O7P7Q7R7S7T7U7V7W7X7Z7[7_7`7b7c7d7g7h7j7v7z8r8s8t8u8v8w8y8z8{8}9O9P9Q9R9S9T9U9V9W9X9Y9Z9[9]9_9`9c9e9f9m9n9p9r9s9t9u9v9w9z9{9}:Q:y;R;S;T;U;V;W;Z;[;^;_;`;a;b;c;d;e;f;g;h;i;j;k;l;m;o;p;u;v;y;{;|<Q<S<U<X=`=a=b=c=d=e=f=i=l=m=n=o=p=q=r=s=t=u=v=w=x=y=z={=|=}>O>P>Q>R>S>T>U>V>W>X>Y>Z>[>]>^>_>b>c>d>h>i>j>k>m>n>o>p>s>t>v>{>|?U?V?W?`?k?lQ'd$[Y(Z$s8x;Y=g=hS(_3x7uQ(b$tR+}(cT&X!|)}#c$Pg#}$h'X'Z'p'v'{(Y(^)b)e*t*y+O+U+]+`+c+n+q+r+x,m,y,|-z.X.[.b.g.h0h0s2R3w3|3}7r7s7t8Q:V:W:X?]?^?c?y?z?{@S@T@U@V3}fPVX]`cgjklmnoprxyz!S!W!X!Y!]!e!f!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r#}$Q$R$T$h$z%O%Q%S%T%U%V%d%r%}&S&W&[&q&t&u&x'P'X'Z']'a'e'p'v'{(T(X(Y([(](^(j(v)V)Z)b)e)i)p)w){)}*X*]*^*t*y+O+P+U+]+`+b+c+n+q+r+u+x,U,X,^,g,i,k,m,y,|-S-d-e-x-z.P.X.[.a.b.c.g.h.z.|/U/^/s0O0T0Z0h0k0s0y1T1U1X1Y1^1h1q1s1w2R2T2`2e2s2{3w3y3|3}4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7r7s7t7x8Q8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:V:W:X:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?]?^?c?g?h?y?z?{@S@T@U@V[#wd#x3q3r3s3th'V#z'W)h-R-Y/p/z1l3u3v3z3{Q)g%nR-X)mY#yd%n)m3q3rV'T#x3s3t1fePVX]`cjklmnoprxyz!S!W!X!Y!]!e!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a'e(T(X([(](j(v)V)Z)i)p)w){)}*X*]*^+P+b+u,U,X,^,g,i,k-S-d-e-x.P.a.c.z.|/U/^/s0O0T0Z0k0y1T1U1X1Y1^1h1q1s1w2T2`2e2s2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?hQ%o!fQ)n%r#Q4Pg#}$h'X'Z'p'v'{(Y(^)b*y+O+U+]+`+c+n+q+x,m,y,|-z.X.[.b.g0h2R7r7s7t8Q:V:W:X?]?^?c?y?z?{@S@T@U@Va4Q)e*t+r.h0s3w3|3}Y'T#z)h-Y3u3vZ*e'W-R/z3z3{0xhPVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k-d-e-x.P.a.z.|/U/^0O0T0Z0k1T1U1X1Y1^1q1s1w2T2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?hT2^0y2`R&^#OR&]#O!r#Z[#e#u$U$V$W$X$Z$s$w%X%Z%]&`&a&b&c&d&e&f&g'`'b'c(g)x)z*Q*l+h-^._0l2S2h2y3P3d9_9`!Y4_3x4m4n4o4p4r4s4u4v4w4x4y4z4{4|5U5V5W5Y5Z5^5_5a5b5c5f5g5i!^6b4g6n6o6p6q6s6t6v6w6x6y6z6{6|6}7V7W7X7Z7[7_7`7b7c7d7g7h7j7u7v#b8e#k%a%s%|&O&v&w&|(z*W+e,r,u-[-i-k/a4f5}7z8r8s8t8u8w8x8y8}9O9P9Q9R9S9T9U9c9e9f9m9p9r9u9w9z9{9}:Q:y;[<X>{>|?U?k?l#O:r&U)|-`-j-}0V0a1m1p1u2w2x8z8{9n9s9t9v;R;S;T;U;W;Y;Z;^;_;`;a;b;c;d;e;m;o;p;u;v;y;{;|<Q<S<U>[>]!`<x/T/{=`=a=b=c=f=g=i=l=n=p=r=t=v=x=z>^>b>d>h>j>m>n>p>s>t>v?V?W?`o<y2[=h=m=o=q=s=u=w=y={>_>c>i>k>oS$iu#fQ$qwU'}$j$l&pQ(P$kS(R$m$rQ+_(OQ+a(QQ+d(SQ1x0]Q5|7mS6P7o7pQ6Q7qQ7y:RS7{:S:TQ7|:UQ;X?OS;q?Q?TQ;x?YQ?S?sS?X?u?wQ?_?xQ?i?|S?j?}@QS?m@O@PR?n@RT'w$h+U!csPVXt!S!j!r!s!w$h%O%Q%T%V'p(^(j)b+U+n+x,U,X,y,|.z.|/U1T1U1^2eQ$]rR*n'eQ.Q+TQ.n+sQ0[-|Q0p.eQ1t0YQ2U0qR3Q2VT0^.O0_Q+Z'|Q.Z+^R0j.^Q(a$tQ)`%iQ)u%vQ*w'mS+|(b(cQ-u*xR.u+}Q(`$tQ)d%kQ)t%vQ*s'lS*v'm)uU+{(a(b(cS-t*w*xS.t+|+}Q/n-PQ0Q-rQ0S-uR0|.uQ(_$tQ)_%iQ)a%jQ)s%vU*u'm)t)uW+z(`(a(b(cQ,x)`U-s*v*w*xU.s+{+|+}S0R-t-uS0{.t.uQ1o0SR2b0|X+v(^)b+x,|b%f!_$a'j+r.h.k0s0u2WR,v)[Q$ovS+f(U?Zg?v(^)b+m+n+q+x,y,|.f.g0rR0z.pT2_0y2`1P|PVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k,q-d-e-x.P.a.z.|/U/^0O0T0Z0k0y1T1U1X1Y1^1q1s1w2T2`2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?hT$y{$|Q,S(fR.w,QT${{$|Q(l%OQ(t%QQ(y%TQ(|%VQ/S,]Q1Q/OQ1R/RR2k1^R(o%PX,`(m(n,a,cR(p%PX(r%Q%T%V1^R%T!T_%b!]%S(v,g,i/^1XR%V!UR/b,kR,n)RQ)c%kS*r'l)dS-q*s-PS0P-r/nR1n0QT,{)b,|Q-T)hU/q-Q-R-YU1d/p/y/zR2v1lR/t-SR2t1hSSO!mR!oSQ!rVR%y!rQ!jPS!sV!rQ!wX[%u!j!s!w,U1U2eQ,U(jQ1U/UR2e1TQ)q%sS-])q9kR9k8{Q-f*SR/}-fQ&y#oS*Z&y9bR9b:}S*_&|&}R-m*_Q*O&YR-b*O!l'Y#|'o*h*|+R+X+i+m-{.Y.].`.f/d0f0i0m0r2Q3O6R6S6T7n7}8O8P;z;}<R?a?b?d?o?p?q?rS*g'Y/l]/l-P-r.k0u1b2W!j'[#|'o*|+R+X+i+m-{.Y.].`.f/d0f0i0m0r2Q3O6R6S6T7n7}8O8P;z;}<R?a?b?d?o?p?q?rS*i'[/mZ/m-P-r.k0u2WU#xd%n)mU'S#x3s3tQ3s3qR3t3rQ'W#z^*d'W-R/p/z1l3z3{Q-R)hQ/z-YQ3z3uR3{3v|tPVX!S!j!r!s!w%O%Q%T%V(j,U,X.z.|/U1T1U1^2eW$_t'p+n,yS'p$h+US+n(^+xT,y)b,|Q'f$]R*o'fS'v$h+UQ+O'pT+S'v+OQ0_.OR1y0_Q+V'xR.S+VQ0c.US1}0c2OR2O0dQ.d+jR0o.dQ+x(^R.q+xW+q(^)b+x,|S.g+n,yT.j+q.gQ)]%fR,w)]Q(V$oS+g(V?[R?[?vQ2`0yR3W2`Q$|{R(h$|Q,W(kR.{,WQ,Z(lR/P,ZQ,a(mQ,c(nT/V,a,cQ)W%aS,s)W9iR9i8zQ)T%_R,p)TQ,|)bR/j,|Q)j%pS-V)j/xR/x-WQ1i/tR2u1iT!uV!rj!iPVX!j!r!s!w(j,U/U1T1U2eQ%R!SQ(k%OW(r%Q%T%V1^Q.},XQ1O.zR1P.||[PVX!S!j!r!s!w%O%Q%T%V(j,U,X.z.|/U1T1U1^2eQ#e]U#k`#q&xQ#ucQ$UkQ$VlQ$WmQ$XnQ$YoQ$ZpQ$sx^$vy4S6V8Y:f<c<dQ$wzQ%X!WQ%Z!XQ%]!YW%a!]%S(v,iU%s!g&q-eQ%|!yQ&O!zS&U!|)}^&_#Q4U6X8[:i<f<gQ&`#RQ&a#SQ&b#TQ&c#UQ&d#VQ&e#WQ&f#XQ&g#YQ&h#ZQ&i#[Q&j#]Q&k#^Q&l#_Q&m#`Q&n#aQ&v#lQ&w#mS&|#r'PQ'`$QQ'b$RQ'c$TQ(g$zQ(z%UQ)x%}Q)z&SQ)|&WQ*Q&[Q*W&uS*j']6OQ*l'a^*m3y5j7k:O<V>w>xQ+e(TQ+h(XQ,r)VQ,u)ZQ-[)pQ-^)wQ-`){Q-i*XQ-j*]Q-k*^^-o4O5k7l:P<W>y>zQ-}+PQ._+bQ/T,^Q/a,kQ/{-dQ0V-xQ0a.PQ0l.aQ1m0OQ1p0TQ1u0ZQ2S0kU2[0y2`:{Q2h1YQ2w1qQ2x1sQ2y1wQ3P2TQ3d2{Q3x4RQ4fjQ4g5nQ4m5oQ4n5qQ4o5sQ4p5uQ4q5wQ4r5yQ4s4TQ4u4VQ4v4WQ4w4XQ4x4YQ4y4ZQ4z4[Q4{4]Q4|4^Q4}4_Q5O4`Q5P4aQ5Q4bQ5R4cQ5S4dQ5T4eQ5U4hQ5V4iQ5W4jQ5Y4kQ5Z4lQ5^4tQ5_5XQ5a5[Q5b5]Q5c5`Q5f5dQ5g5eQ5i5hQ5}5{Q6n5pQ6o5rQ6p5tQ6q5vQ6r5xQ6s5zQ6t6WQ6v6YQ6w6ZQ6x6[Q6y6]Q6z6^Q6{6_Q6|6`Q6}6aQ7O6bQ7P6cQ7Q6dQ7R6eQ7S6fQ7T6gQ7U6hQ7V6iQ7W6jQ7X6kQ7Z6lQ7[6mQ7_6uQ7`7YQ7b7]Q7c7^Q7d7aQ7g7eQ7h7fQ7j7iQ7u6UQ7v5mQ7z7xQ8r8RQ8s8SQ8t8TQ8u8UQ8v8VQ8w8WQ8x8XQ8y8ZU8z,g/^1XQ8{%dQ8}8]Q9O8^Q9P8_Q9Q8`Q9R8aQ9S8bQ9T8cQ9U8dQ9V8eQ9W8fQ9X8gQ9Y8hQ9Z8iQ9[8jQ9]8kQ9_8mQ9`8nQ9c8oQ9e8pQ9f8qQ9m8|Q9n9^Q9p9dQ9r9gQ9s9hQ9t9jQ9u9lQ9v9oQ9w9qQ9z9xQ9{9yQ9}9|Q:Q:ZU:y#i&t9aQ;R:_Q;S:`Q;T:aQ;U:bQ;V:cQ;W:dQ;Y:eQ;Z:gQ;[:hQ;^:jQ;_:kQ;`:lQ;a:mQ;b:nQ;c:oQ;d:pQ;e:qQ;f:rQ;g:sQ;h:tQ;i:uQ;j:vQ;k:wQ;l:xQ;m;OQ;o;PQ;p;QQ;u;]Q;v;nQ;y;sQ;{;tQ;|;wQ<Q<OQ<S<PQ<U<TQ<X:^Q=`<YQ=a<ZQ=b<[Q=c<]Q=d<^Q=e<_Q=f<`Q=g<aQ=h<bQ=i<eQ=l<hQ=m<iQ=n<jQ=o<kQ=p<lQ=q<mQ=r<nQ=s<oQ=t<pQ=u<qQ=v<rQ=w<sQ=x<tQ=y<uQ=z<vQ={<wQ=|<xQ=}<yQ>O<zQ>P<{Q>Q<|Q>R<}Q>S=OQ>T=PQ>U=QQ>V=RQ>W=SQ>X=TQ>Y=UQ>Z=VQ>[=XQ>]=YQ>^=ZQ>_=[Q>b=]Q>c=^Q>d=_Q>h=jQ>i=kQ>j>`Q>k>aQ>m>eQ>n>fQ>o>gQ>p>lQ>s>qQ>t>rQ>v>uQ>{:]Q>|:[Q?U?PQ?V:zQ?W:|Q?`;rQ?k?gR?l?hR*T&qQ%t!gQ)Y%dT*R&q-e$WiPVX]cklmnopxyz!S!W!X!Y!j!r!s!w#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a$Q$R$T$z%O%Q%T%V%}&S&['a(X(j)w+b,U,X.a.z.|/U0k1T1U1Y1^1w2T2e2{3y4O8m8n!t5l']4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5o5q5s5u5w5y7k7l!x7w5j5k5m5n5p5r5t5v5x5z6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i$`:Y`j!]!g!y!z#i#l#m#q#r%S%U&q&t&u&x'P(T(v)V)Z)p*X*^,i,k-e5{7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8o8p8q8|9a9d9g9l9q9x9y9|:O:P:Z:[:]:^:h?P?g?h#n>}!|%d&W){)}*]+P,g-x.P/^0O0T0Z1X1q1s9^9h9j9o:_:`:a:b:c:d:e:f:g:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x;O;P;Q;];n;s;t;w<O<P<T<V<W=X=Y!x?e,^-d:z:|;r<Y<Z<[<]<^<`<a<c<e<f<h<j<l<n<p<r<t<v<x<z<|=O=Q=S=U=Z=]=_=j>`>e>f>l>q>r>u>w>y!]?f0y2`:{<_<b<d<g<i<k<m<o<q<s<u<w<y<{<}=P=R=T=V=[=^=k>a>g>x>zQ#p`Q&s#iQ&{#qR*V&tS#o`#q^$Sj5m5n:Z:[:]:^S*Y&x9aT:}#i&tQ'O#rR*a'PR&T!{R&Z!|Q&Y!|R-a)}Q#|gS'^#}3wS'o$h+US*f'X3|U*h'Z*y-zQ*|'pQ+R'vQ+X'{Q+i(YW+m(^)b+x,|Q-P)eQ-r*tQ-{+OQ.Y+]Q.]+`Q.`+cU.f+n+q,yQ.k+rQ/d,mQ0f.XQ0i.[Q0m.bQ0r.gQ0u.hQ1b3}Q2Q0hQ2W0sQ3O2RQ6R7rQ6S7sQ6T7tQ7n8QQ7}:VQ8O:WQ8P:XQ;z?]Q;}?^Q<R?cQ?a?yQ?b?zQ?d?{Q?o@SQ?p@TQ?q@UR?r@V0|!OPVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k-d-e-x.P.a.z.|/U/^0O0T0Z0k0y1T1U1X1Y1^1q1s1w2T2`2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?h#b$Og#}$h'X'Z'p'v'{(Y(^)b)e*t*y+O+U+]+`+c+n+q+r+x,m,y,|-z.X.[.b.g.h0h0s2R3w3|3}7r7s7t8Q:V:W:X?]?^?c?y?z?{@S@T@U@VS$[r'eQ%l!eS%p!f%rU+j([(]+uQ-U)iQ/r-SQ0n.cQ1g/sQ2r1hR3a2s|vPVX!S!j!r!s!w%O%Q%T%V(j,U,X.z.|/U1T1U1^2e#Y#g]cklmnopxyz!W!X!Y#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a$Q$R$T$z%}&S&['a(X)w+b.a0k1Y1w2T2{3y4O8m8n`+o(^)b+n+q+x,y,|.g!t8l']4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5o5q5s5u5w5y7k7l!x=W5j5k5m5n5p5r5t5v5x5z6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i$`?t`j!]!g!y!z#i#l#m#q#r%S%U&q&t&u&x'P(T(v)V)Z)p*X*^,i,k-e5{7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8o8p8q8|9a9d9g9l9q9x9y9|:O:P:Z:[:]:^:h?P?g?h#n@W!|%d&W){)}*]+P,g-x.P/^0O0T0Z1X1q1s9^9h9j9o:_:`:a:b:c:d:e:f:g:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x;O;P;Q;];n;s;t;w<O<P<T<V<W=X=Y!x@X,^-d:z:|;r<Y<Z<[<]<^<`<a<c<e<f<h<j<l<n<p<r<t<v<x<z<|=O=Q=S=U=Z=]=_=j>`>e>f>l>q>r>u>w>y!]@Y0y2`:{<_<b<d<g<i<k<m<o<q<s<u<w<y<{<}=P=R=T=V=[=^=k>a>g>x>zR'y$hQ'x$hR.R+UR$^rZ'u$h'p'v+O+UQ#d[Q%Y!WQ%[!XQ%^!YQ(W$pQ(}%WQ)O%XQ)P%ZQ)Q%]Q)X%cQ)^%gQ)f%lQ)l%qQ)r%tQ*p'iQ-Z)oQ-p*qQ.n+sQ.o+tQ.},[Q/X,dQ/Y,eQ/Z,fQ/`,jQ/c,lQ/g,tQ/v-TQ0p.eQ0w.iQ0x.mQ0z.pQ1P/QQ1`/iQ1e/qQ1v0]Q2U0qQ2Y0tQ2Z0vQ2d1SQ2l1_Q2o1dQ3Q2VQ3S2XQ3V2_Q3Y2cQ3^2nQ3b2vQ3c2yQ3f3RQ3j3[Q3k3]R3n3dR.W+YQ+k([Q+l(]R.p+uS+w(^+xT,{)b,|a+p(^)b+n+q+x,y,|.gQ%g!_Q'i$aQ*q'jQ.m+rS0v.h.kS2X0s0uR3R2WQ$pvW+s(^)b+x,|W.e+m+n+q,yS0q.f.gR2V0r|!aPVX!S!j!r!s!w%O%Q%T%V(j,U,X.z.|/U1T1U1^2eQ$ctW+t(^)b+x,|U.i+n+q,yR0t.g0|!OPVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k-d-e-x.P.a.z.|/U/^0O0T0Z0k0y1T1U1X1Y1^1q1s1w2T2`2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?hR/f,q1P}PVX]`cjklmnopxyz!S!W!X!Y!]!g!j!r!s!w!y!z!|#Q#R#S#T#U#V#W#X#Y#Z#[#]#^#_#`#a#i#l#m#q#r$Q$R$T$z%O%Q%S%T%U%V%d%}&S&W&[&q&t&u&x'P']'a(T(X(j(v)V)Z)p)w){)}*X*]*^+P+b,U,X,^,g,i,k,q-d-e-x.P.a.z.|/U/^0O0T0Z0k0y1T1U1X1Y1^1q1s1w2T2`2e2{3y4O4R4S4T4U4V4W4X4Y4Z4[4]4^4_4`4a4b4c4d4e4h4i4j4k4l4t5X5[5]5`5d5e5h5j5k5m5n5o5p5q5r5s5t5u5v5w5x5y5z5{6O6U6V6W6X6Y6Z6[6]6^6_6`6a6b6c6d6e6f6g6h6i6j6k6l6m6u7Y7]7^7a7e7f7i7k7l7x8R8S8T8U8V8W8X8Y8Z8[8]8^8_8`8a8b8c8d8e8f8g8h8i8j8k8m8n8o8p8q8|9^9a9d9g9h9j9l9o9q9x9y9|:O:P:Z:[:]:^:_:`:a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:z:{:|;O;P;Q;];n;r;s;t;w<O<P<T<V<W<Y<Z<[<]<^<_<`<a<b<c<d<e<f<g<h<i<j<k<l<m<n<o<p<q<r<s<t<u<v<w<x<y<z<{<|<}=O=P=Q=R=S=T=U=V=X=Y=Z=[=]=^=_=j=k>`>a>e>f>g>l>q>r>u>w>x>y>z?P?g?hT$x{$|Q(s%QQ(x%TQ({%VR2j1^Q%c!]Q(w%SQ,h(vQ/],gQ/_,iQ1W/^R2g1XQ%q!fR)o%rR/u-S",
	nodeNames: "⚠ ( HeredocString EscapeSequence abstract LogicOp array as Boolean break case catch clone const continue default declare do echo else elseif enddeclare endfor endforeach endif endswitch endwhile enum extends final finally fn for foreach from function global goto if implements include include_once LogicOp insteadof interface list match namespace new null LogicOp print readonly require require_once return switch throw trait try unset use var Visibility while LogicOp yield LineComment BlockComment TextInterpolation PhpClose Text PhpOpen Template TextInterpolation EmptyStatement ; } { Block : LabelStatement Name ExpressionStatement ConditionalExpression LogicOp MatchExpression ) ( ParenthesizedExpression MatchBlock MatchArm , => AssignmentExpression ArrayExpression ValueList & VariadicUnpacking ... Pair [ ] ListExpression ValueList Pair Pair SubscriptExpression MemberExpression -> ?-> Name VariableName DynamicVariable $ ${ CallExpression ArgList NamedArgument SpreadArgument CastExpression UnionType LogicOp IntersectionType OptionalType NamedType QualifiedName \\ NamespaceName Name NamespaceName Name ScopedExpression :: ClassMemberName DynamicMemberName AssignOp UpdateExpression UpdateOp YieldExpression BinaryExpression LogicOp LogicOp LogicOp BitOp BitOp BitOp CompareOp CompareOp BitOp ArithOp ConcatOp ArithOp ArithOp IncludeExpression RequireExpression CloneExpression UnaryExpression ControlOp LogicOp PrintIntrinsic FunctionExpression static ParamList Parameter #[ Attributes Attribute VariadicParameter PropertyParameter PropertyHooks PropertyHook UseList ArrowFunction NewExpression class BaseClause ClassInterfaceClause DeclarationList ConstDeclaration VariableDeclarator PropertyDeclaration VariableDeclarator MethodDeclaration UseDeclaration UseList UseInsteadOfClause UseAsClause UpdateExpression ArithOp ShellExpression ThrowExpression Integer Float String MemberExpression SubscriptExpression UnaryExpression ArithOp Interpolation String IfStatement ColonBlock SwitchStatement Block CaseStatement DefaultStatement ColonBlock WhileStatement EmptyStatement DoStatement ForStatement ForSpec SequenceExpression ForeachStatement ForSpec Pair GotoStatement ContinueStatement BreakStatement ReturnStatement TryStatement CatchDeclarator DeclareStatement EchoStatement UnsetStatement ConstDeclaration FunctionDefinition ClassDeclaration InterfaceDeclaration TraitDeclaration EnumDeclaration EnumBody EnumCase NamespaceDefinition NamespaceUseDeclaration UseGroup UseClause UseClause GlobalDeclaration FunctionStaticDeclaration Program",
	maxTerm: 320,
	nodeProps: [
		[
			"group",
			-36,
			2,
			8,
			49,
			82,
			84,
			86,
			89,
			94,
			95,
			103,
			107,
			108,
			112,
			113,
			116,
			120,
			126,
			132,
			137,
			139,
			140,
			154,
			155,
			156,
			157,
			160,
			161,
			173,
			174,
			188,
			190,
			191,
			192,
			193,
			194,
			200,
			"Expression",
			-28,
			75,
			79,
			81,
			83,
			201,
			203,
			208,
			210,
			211,
			214,
			217,
			218,
			219,
			220,
			221,
			223,
			224,
			225,
			226,
			227,
			228,
			229,
			230,
			231,
			234,
			235,
			239,
			240,
			"Statement",
			-4,
			121,
			123,
			124,
			125,
			"Type"
		],
		[
			"isolate",
			-4,
			67,
			68,
			71,
			200,
			""
		],
		[
			"openedBy",
			70,
			"phpOpen",
			77,
			"{",
			87,
			"(",
			102,
			"#["
		],
		[
			"closedBy",
			72,
			"phpClose",
			78,
			"}",
			88,
			")",
			165,
			"]"
		]
	],
	propSources: [phpHighlighting],
	skippedNodes: [0],
	repeatNodeCount: 33,
	tokenData: "!GQ_R!]OX$zXY&^YZ'sZ]$z]^&^^p$zpq&^qr)Rrs+Pst+otu2buv5evw6rwx8Vxy>]yz>yz{?g{|@}|}Bb}!OCO!O!PDh!P!QKT!Q!R!!o!R![!$q![!]!,P!]!^!-a!^!_!-}!_!`!1S!`!a!2d!a!b!3t!b!c!7^!c!d!7z!d!e!9Y!e!}!7z!}#O!;b#O#P!<O#P#Q!<l#Q#R!=Y#R#S!7z#S#T!=y#T#U!7z#U#V!9Y#V#o!7z#o#p!Cs#p#q!Da#q#r!Ev#r#s!Fd#s$f$z$f$g&^$g&j!7z&j$I_$z$I_$I`&^$I`$KW$z$KW$KX&^$KX;'S$z;'S;=`&W<%l?HT$z?HT?HU&^?HUO$zP%PV'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zP%kO'UPP%nWOY$zYZ%fZ!a$z!b;'S$z;'S;=`&W<%l~$z~O$z~~%fP&ZP;=`<%l$z_&ed'UP'T^OX$zXY&^YZ'sZ]$z]^&^^p$zpq&^q!^$z!^!_%k!_$f$z$f$g&^$g$I_$z$I_$I`&^$I`$KW$z$KW$KX&^$KX;'S$z;'S;=`&W<%l?HT$z?HT?HU&^?HUO$z_'zW'UP'T^XY(dYZ(d]^(dpq(d$f$g(d$I_$I`(d$KW$KX(d?HT?HU(d^(iW'T^XY(dYZ(d]^(dpq(d$f$g(d$I_$I`(d$KW$KX(d?HT?HU(dR)YW$eQ'UPOY$zYZ%fZ!^$z!^!_%k!_!`)r!`;'S$z;'S;=`&W<%lO$zR)yW$XQ'UPOY$zYZ%fZ!^$z!^!_%k!_!`*c!`;'S$z;'S;=`&W<%lO$zR*jV$XQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zV+YV'vS'UP'wQOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_+v]'UP!e^OY,oYZ%fZ],o]^$z^!^,o!^!_-i!_!a,o!a!b/y!b!},o!}#O1f#O;'S,o;'S;=`/s<%lO,o_,vZ'UP!e^OY,oYZ%fZ],o]^$z^!^,o!^!_-i!_!a,o!a!b/y!b;'S,o;'S;=`/s<%lO,o_-nZ!e^OY,oYZ%fZ],o]^$z^!a,o!a!b.a!b;'S,o;'S;=`/s<%l~,o~O,o~~%f^.dWOY.|YZ/nZ].|]^/n^!`.|!a;'S.|;'S;=`/h<%lO.|^/RV!e^OY.|Z].|^!a.|!a!b.a!b;'S.|;'S;=`/h<%lO.|^/kP;=`<%l.|^/sO!e^_/vP;=`<%l,o_0OZ'UPOY,oYZ0qZ],o]^0x^!^,o!^!_-i!_!`,o!`!a$z!a;'S,o;'S;=`/s<%lO,o_0xO'UP!e^_1PV'UP!e^OY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_1oZ'UP$kQ!e^OY,oYZ%fZ],o]^$z^!^,o!^!_-i!_!a,o!a!b/y!b;'S,o;'S;=`/s<%lO,o_2i`'UP#fQOY$zYZ%fZ!^$z!^!_%k!_!c$z!c!}3k!}#R$z#R#S3k#S#T$z#T#o3k#o#p4w#p$g$z$g&j3k&j;'S$z;'S;=`&W<%lO$z_3ra'UP#d^OY$zYZ%fZ!Q$z!Q![3k![!^$z!^!_%k!_!c$z!c!}3k!}#R$z#R#S3k#S#T$z#T#o3k#o$g$z$g&j3k&j;'S$z;'S;=`&W<%lO$zV5OV'UP#gUOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR5lW'UP$^QOY$zYZ%fZ!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zR6]V$OQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_6yY#T^'UPOY$zYZ%fZv$zvw7iw!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zR7pV$TQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR8^Z'UP%`QOY8VYZ9PZw8Vwx;_x!^8V!^!_;{!_#O8V#O#P<y#P;'S8V;'S;=`>V<%lO8VR9WV'UP%`QOw9mwx:Xx#O9m#O#P:^#P;'S9m;'S;=`;X<%lO9mQ9rV%`QOw9mwx:Xx#O9m#O#P:^#P;'S9m;'S;=`;X<%lO9mQ:^O%`QQ:aRO;'S9m;'S;=`:j;=`O9mQ:oW%`QOw9mwx:Xx#O9m#O#P:^#P;'S9m;'S;=`;X;=`<%l9m<%lO9mQ;[P;=`<%l9mR;fV'UP%`QOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR<Q]%`QOY8VYZ9PZw8Vwx;_x!a8V!a!b9m!b#O8V#O#P<y#P;'S8V;'S;=`>V<%l~8V~O8V~~%fR=OW'UPOY8VYZ9PZ!^8V!^!_;{!_;'S8V;'S;=`=h;=`<%l9m<%lO8VR=mW%`QOw9mwx:Xx#O9m#O#P:^#P;'S9m;'S;=`;X;=`<%l8V<%lO9mR>YP;=`<%l8VR>dV!zQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zV?QV!yU'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR?nY'UP$^QOY$zYZ%fZz$zz{@^{!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zR@eW$_Q'UPOY$zYZ%fZ!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zRAUY$[Q'UPOY$zYZ%fZ{$z{|At|!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zRA{V%TQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zRBiV#OQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_CXZ$[Q%^W'UPOY$zYZ%fZ}$z}!OAt!O!^$z!^!_%k!_!`6U!`!aCz!a;'S$z;'S;=`&W<%lO$zVDRV#aU'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zVDo['UP$]QOY$zYZ%fZ!O$z!O!PEe!P!Q$z!Q![Fs![!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zVEjX'UPOY$zYZ%fZ!O$z!O!PFV!P!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zVF^V#VU'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zRFz_'UP%XQOY$zYZ%fZ!Q$z!Q![Fs![!^$z!^!_%k!_!g$z!g!hGy!h#R$z#R#SJc#S#X$z#X#YGy#Y;'S$z;'S;=`&W<%lO$zRHO]'UPOY$zYZ%fZ{$z{|Hw|}$z}!OHw!O!Q$z!Q![Ii![!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zRH|X'UPOY$zYZ%fZ!Q$z!Q![Ii![!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zRIpZ'UP%XQOY$zYZ%fZ!Q$z!Q![Ii![!^$z!^!_%k!_#R$z#R#SHw#S;'S$z;'S;=`&W<%lO$zRJhX'UPOY$zYZ%fZ!Q$z!Q![Fs![!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_K[['UP$^QOY$zYZ%fZz$zz{LQ{!P$z!P!Q,o!Q!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$z_LVX'UPOYLQYZLrZzLQz{N_{!^LQ!^!_! s!_;'SLQ;'S;=`!!i<%lOLQ_LwT'UPOzMWz{Mj{;'SMW;'S;=`NX<%lOMW^MZTOzMWz{Mj{;'SMW;'S;=`NX<%lOMW^MmVOzMWz{Mj{!PMW!P!QNS!Q;'SMW;'S;=`NX<%lOMW^NXO!f^^N[P;=`<%lMW_NdZ'UPOYLQYZLrZzLQz{N_{!PLQ!P!Q! V!Q!^LQ!^!_! s!_;'SLQ;'S;=`!!i<%lOLQ_! ^V!f^'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_! vZOYLQYZLrZzLQz{N_{!aLQ!a!bMW!b;'SLQ;'S;=`!!i<%l~LQ~OLQ~~%f_!!lP;=`<%lLQZ!!vm'UP%WYOY$zYZ%fZ!O$z!O!PFs!P!Q$z!Q![!$q![!^$z!^!_%k!_!d$z!d!e!&o!e!g$z!g!hGy!h!q$z!q!r!(a!r!z$z!z!{!){!{#R$z#R#S!%}#S#U$z#U#V!&o#V#X$z#X#YGy#Y#c$z#c#d!(a#d#l$z#l#m!){#m;'S$z;'S;=`&W<%lO$zZ!$xa'UP%WYOY$zYZ%fZ!O$z!O!PFs!P!Q$z!Q![!$q![!^$z!^!_%k!_!g$z!g!hGy!h#R$z#R#S!%}#S#X$z#X#YGy#Y;'S$z;'S;=`&W<%lO$zZ!&SX'UPOY$zYZ%fZ!Q$z!Q![!$q![!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zZ!&tY'UPOY$zYZ%fZ!Q$z!Q!R!'d!R!S!'d!S!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zZ!'k['UP%WYOY$zYZ%fZ!Q$z!Q!R!'d!R!S!'d!S!^$z!^!_%k!_#R$z#R#S!&o#S;'S$z;'S;=`&W<%lO$zZ!(fX'UPOY$zYZ%fZ!Q$z!Q!Y!)R!Y!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zZ!)YZ'UP%WYOY$zYZ%fZ!Q$z!Q!Y!)R!Y!^$z!^!_%k!_#R$z#R#S!(a#S;'S$z;'S;=`&W<%lO$zZ!*Q]'UPOY$zYZ%fZ!Q$z!Q![!*y![!^$z!^!_%k!_!c$z!c!i!*y!i#T$z#T#Z!*y#Z;'S$z;'S;=`&W<%lO$zZ!+Q_'UP%WYOY$zYZ%fZ!Q$z!Q![!*y![!^$z!^!_%k!_!c$z!c!i!*y!i#R$z#R#S!){#S#T$z#T#Z!*y#Z;'S$z;'S;=`&W<%lO$zR!,WX!rQ'UPOY$zYZ%fZ![$z![!]!,s!]!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!,zV#yQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zV!-hV!nU'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!.S[$YQOY$zYZ%fZ!^$z!^!_!.x!_!`!/i!`!a*c!a!b!0]!b;'S$z;'S;=`&W<%l~$z~O$z~~%fR!/PW$ZQ'UPOY$zYZ%fZ!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zR!/pX$YQ'UPOY$zYZ%fZ!^$z!^!_%k!_!`$z!`!a*c!a;'S$z;'S;=`&W<%lO$zP!0bR!jP!_!`!0k!r!s!0p#d#e!0pP!0pO!jPP!0sQ!j!k!0y#[#]!0yP!0|Q!r!s!0k#d#e!0k_!1ZX#|Y'UPOY$zYZ%fZ!^$z!^!_%k!_!`)r!`!a!1v!a;'S$z;'S;=`&W<%lO$zV!1}V#PU'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!2kX$YQ'UPOY$zYZ%fZ!^$z!^!_%k!_!`!3W!`!a!.x!a;'S$z;'S;=`&W<%lO$zR!3_V$YQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_!3{[!wQ'UPOY$zYZ%fZ}$z}!O!4q!O!^$z!^!_%k!_!`$z!`!a!6P!a!b!6m!b;'S$z;'S;=`&W<%lO$zV!4vX'UPOY$zYZ%fZ!^$z!^!_%k!_!`$z!`!a!5c!a;'S$z;'S;=`&W<%lO$zV!5jV#bU'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_!6WV!h^'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!6tW$RQ'UPOY$zYZ%fZ!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zR!7eV$dQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_!8Ta'bS'UP'XYOY$zYZ%fZ!Q$z!Q![!7z![!^$z!^!_%k!_!c$z!c!}!7z!}#R$z#R#S!7z#S#T$z#T#o!7z#o$g$z$g&j!7z&j;'S$z;'S;=`&W<%lO$z_!9ce'bS'UP'XYOY$zYZ%fZr$zrs!:tsw$zwx8Vx!Q$z!Q![!7z![!^$z!^!_%k!_!c$z!c!}!7z!}#R$z#R#S!7z#S#T$z#T#o!7z#o$g$z$g&j!7z&j;'S$z;'S;=`&W<%lO$zR!:{V'UP'wQOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zV!;iV#XU'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_!<VV#s^'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!<sV#YQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!=aW$VQ'UPOY$zYZ%fZ!^$z!^!_%k!_!`6U!`;'S$z;'S;=`&W<%lO$zR!>OZ'UPOY!=yYZ!>qZ!^!=y!^!_!@y!_#O!=y#O#P!Au#P#S!=y#S#T!CP#T;'S!=y;'S;=`!Cm<%lO!=yR!>vV'UPO#O!?]#O#P!?u#P#S!?]#S#T!@n#T;'S!?];'S;=`!@s<%lO!?]Q!?`VO#O!?]#O#P!?u#P#S!?]#S#T!@n#T;'S!?];'S;=`!@s<%lO!?]Q!?xRO;'S!?];'S;=`!@R;=`O!?]Q!@UWO#O!?]#O#P!?u#P#S!?]#S#T!@n#T;'S!?];'S;=`!@s;=`<%l!?]<%lO!?]Q!@sO%UQQ!@vP;=`<%l!?]R!@|]OY!=yYZ!>qZ!a!=y!a!b!?]!b#O!=y#O#P!Au#P#S!=y#S#T!CP#T;'S!=y;'S;=`!Cm<%l~!=y~O!=y~~%fR!AzW'UPOY!=yYZ!>qZ!^!=y!^!_!@y!_;'S!=y;'S;=`!Bd;=`<%l!?]<%lO!=yR!BgWO#O!?]#O#P!?u#P#S!?]#S#T!@n#T;'S!?];'S;=`!@s;=`<%l!=y<%lO!?]R!CWV%UQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!CpP;=`<%l!=y_!CzV!p^'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z_!DjY$UQ#n['UPOY$zYZ%fZ!^$z!^!_%k!_!`6U!`#p$z#p#q!EY#q;'S$z;'S;=`&W<%lO$zR!EaV$SQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!E}V!oQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$zR!FkV$eQ'UPOY$zYZ%fZ!^$z!^!_%k!_;'S$z;'S;=`&W<%lO$z",
	tokenizers: [
		expression,
		interpolated,
		semicolon,
		0,
		1,
		2,
		3,
		eofToken
	],
	topRules: {
		"Template": [0, 73],
		"Program": [1, 241]
	},
	dynamicPrecedences: { "299": 1 },
	specialized: [{
		term: 285,
		get: (value, stack) => keywords(value) << 1,
		external: keywords
	}, {
		term: 285,
		get: (value) => spec_name[value] || -1
	}],
	tokenPrec: 30012
});
//#endregion
//#region node_modules/@codemirror/lang-php/dist/index.js
/**
A language provider based on the [Lezer PHP
parser](https://github.com/lezer-parser/php), extended with
highlighting and indentation information.
*/
var phpLanguage = /*@__PURE__*/ LRLanguage.define({
	name: "php",
	parser: /*@__PURE__*/ parser.configure({ props: [/*@__PURE__*/ indentNodeProp.add({
		IfStatement: /*@__PURE__*/ continuedIndent({ except: /^\s*({|else\b|elseif\b|endif\b)/ }),
		TryStatement: /*@__PURE__*/ continuedIndent({ except: /^\s*({|catch\b|finally\b)/ }),
		SwitchBody: (context) => {
			let after = context.textAfter, closed = /^\s*\}/.test(after), isCase = /^\s*(case|default)\b/.test(after);
			return context.baseIndent + (closed ? 0 : isCase ? 1 : 2) * context.unit;
		},
		ColonBlock: (cx) => cx.baseIndent + cx.unit,
		"Block EnumBody DeclarationList": /*@__PURE__*/ delimitedIndent({ closing: "}" }),
		ArrowFunction: (cx) => cx.baseIndent + cx.unit,
		"String BlockComment": () => null,
		Statement: /*@__PURE__*/ continuedIndent({ except: /^({|end(for|foreach|switch|while)\b)/ })
	}), /*@__PURE__*/ foldNodeProp.add({
		"Block EnumBody DeclarationList SwitchBody ArrayExpression ValueList": foldInside,
		ColonBlock(tree) {
			return {
				from: tree.from + 1,
				to: tree.to
			};
		},
		BlockComment(tree) {
			return {
				from: tree.from + 2,
				to: tree.to - 2
			};
		}
	})] }),
	languageData: {
		commentTokens: {
			block: {
				open: "/*",
				close: "*/"
			},
			line: "//"
		},
		indentOnInput: /^\s*(?:case |default:|end(?:if|for(?:each)?|switch|while)|else(?:if)?|\{|\})$/,
		wordChars: "$",
		closeBrackets: { stringPrefixes: ["b", "B"] }
	}
});
/**
PHP language support.
*/
function php(config = {}) {
	let support = [], base;
	if (config.baseLanguage === null);
	else if (config.baseLanguage) base = config.baseLanguage;
	else {
		let htmlSupport = html({ matchClosingTags: false });
		support.push(htmlSupport.support);
		base = htmlSupport.language;
	}
	return new LanguageSupport(phpLanguage.configure({
		wrap: base && parseMixed((node) => {
			if (!node.type.isTop) return null;
			return {
				parser: base.parser,
				overlay: (node) => node.name == "Text"
			};
		}),
		top: config.plain ? "Program" : "Template"
	}), support);
}
//#endregion
export { php as t };
