import { B as tags$1, Et as NodeWeakMap, L as syntaxTree, St as IterMode, T as foldNodeProp, d as LRLanguage, k as indentNodeProp, m as LanguageSupport, w as foldInside, y as continuedIndent, z as styleTags } from "./autocomplete+[...].mjs";
import { a as LocalTokenGroup, i as LRParser, r as ExternalTokenizer } from "./lang-cpp+[...].mjs";
//#region node_modules/@lezer/css/dist/index.js
var descendantOp = 148;
var Unit = 1;
var identifier$1 = 149;
var callee = 150;
var VariableName = 2;
var queryIdentifier = 151;
var queryVariableName = 3;
var QueryCallee = 4;
var hashNameColor = 152;
var space = [
	9,
	10,
	11,
	12,
	13,
	32,
	133,
	160,
	5760,
	8192,
	8193,
	8194,
	8195,
	8196,
	8197,
	8198,
	8199,
	8200,
	8201,
	8202,
	8232,
	8233,
	8239,
	8287,
	12288
];
var colon = 58;
var parenL = 40;
var underscore = 95;
var bracketL = 91;
var dash = 45;
var period = 46;
var hash = 35;
var percent = 37;
var ampersand = 38;
var backslash = 92;
var newline = 10;
var asterisk = 42;
function isAlpha(ch) {
	return ch >= 65 && ch <= 90 || ch >= 97 && ch <= 122 || ch >= 161;
}
function isDigit(ch) {
	return ch >= 48 && ch <= 57;
}
function isHex(ch) {
	return isDigit(ch) || ch >= 97 && ch <= 102 || ch >= 65 && ch <= 70;
}
var identifierTokens = (id, varName, callee) => (input, stack) => {
	for (let inside = false, dashes = 0, i = 0;; i++) {
		let { next } = input;
		if (isAlpha(next) || next == dash || next == underscore || inside && isDigit(next)) {
			if (!inside && (next != dash || i > 0)) inside = true;
			if (dashes === i && next == dash) dashes++;
			input.advance();
		} else if (next == backslash && input.peek(1) != newline) {
			input.advance();
			if (isHex(input.next)) {
				do
					input.advance();
				while (isHex(input.next));
				if (input.next == 32) input.advance();
			} else if (input.next > -1) input.advance();
			inside = true;
		} else {
			if (inside) input.acceptToken(dashes >= 2 && stack.canShift(VariableName) ? varName : next == parenL ? callee : id);
			break;
		}
	}
};
var identifiers = new ExternalTokenizer(identifierTokens(identifier$1, VariableName, callee), { contextual: true });
var queryIdentifiers = new ExternalTokenizer(identifierTokens(queryIdentifier, queryVariableName, QueryCallee), { contextual: true });
var descendant = new ExternalTokenizer((input) => {
	if (space.includes(input.peek(-1))) {
		let { next } = input;
		if (isAlpha(next) || next == underscore || next == hash || next == period || next == asterisk || next == bracketL || next == colon && isAlpha(input.peek(1)) || next == dash || next == ampersand) input.acceptToken(descendantOp);
	}
});
var unitToken = new ExternalTokenizer((input) => {
	if (!space.includes(input.peek(-1))) {
		let { next } = input;
		if (next == percent) {
			input.advance();
			input.acceptToken(Unit);
		}
		if (isAlpha(next)) {
			do
				input.advance();
			while (isAlpha(input.next) || isDigit(input.next));
			input.acceptToken(Unit);
		}
	}
});
function hashColor(name) {
	return /^#[a-f\d]{3}([a-f\d]{3}([a-f\d]{2})?)?$/i.test(name) ? hashNameColor : -1;
}
var cssHighlighting = styleTags({
	"AtKeyword import charset namespace keyframes media supports font-feature-values": tags$1.definitionKeyword,
	"from to selector scope MatchFlag": tags$1.keyword,
	NamespaceName: tags$1.namespace,
	KeyframeName: tags$1.labelName,
	KeyframeRangeName: tags$1.operatorKeyword,
	TagName: tags$1.tagName,
	ClassName: tags$1.className,
	PseudoClassName: tags$1.constant(tags$1.className),
	IdName: tags$1.labelName,
	"FeatureName PropertyName": tags$1.propertyName,
	AttributeName: tags$1.attributeName,
	NumberLiteral: tags$1.number,
	KeywordQuery: tags$1.keyword,
	UnaryQueryOp: tags$1.operatorKeyword,
	"CallTag ValueName FontName": tags$1.atom,
	VariableName: tags$1.variableName,
	Callee: tags$1.operatorKeyword,
	Unit: tags$1.unit,
	"UniversalSelector NestingSelector": tags$1.definitionOperator,
	"MatchOp CompareOp": tags$1.compareOperator,
	"ChildOp SiblingOp, LogicOp": tags$1.logicOperator,
	BinOp: tags$1.arithmeticOperator,
	Important: tags$1.modifier,
	Comment: tags$1.blockComment,
	ColorLiteral: tags$1.color,
	"ParenthesizedContent StringLiteral": tags$1.string,
	":": tags$1.punctuation,
	"PseudoOp": tags$1.derefOperator,
	"; , |": tags$1.separator,
	"( )": tags$1.paren,
	"[ ]": tags$1.squareBracket,
	"{ }": tags$1.brace
});
var spec_callee = {
	__proto__: null,
	lang: 44,
	"nth-child": 44,
	"nth-last-child": 44,
	"nth-of-type": 44,
	"nth-last-of-type": 44,
	dir: 44,
	"host-context": 44,
	if: 88,
	url: 158,
	"url-prefix": 158,
	domain: 158,
	regexp: 158
};
var spec_queryIdentifier = {
	__proto__: null,
	or: 102,
	and: 102,
	not: 112,
	only: 112,
	layer: 212
};
var spec_QueryCallee = {
	__proto__: null,
	selector: 118,
	style: 124,
	layer: 208
};
var spec_AtKeyword = {
	__proto__: null,
	"@import": 204,
	"@media": 216,
	"@charset": 220,
	"@namespace": 224,
	"@keyframes": 230,
	"@supports": 242,
	"@scope": 246,
	"@font-feature-values": 252
};
var spec_identifier = {
	__proto__: null,
	to: 249
};
var parser = LRParser.deserialize({
	version: 14,
	states: "MrQYQdOOO$TQdOOP$[O`OOO%XQaO'#CfOOQP'#Ce'#CeO%`QdO'#CgO%eQ`O'#CgO%jQaO'#FrO&eQdO'#CkO'XQaO'#CcO'cQdO'#CnOOQP'#ES'#ESOOQP'#ER'#ERO'nQdO'#ETO'yQdO'#E[O'yQdO'#E_OOQP'#Fr'#FrO)`QhO'#FQOOQS'#Fq'#FqOOQS'#FT'#FTQYQdOOO)gQdO'#EeO*vQhO'#EkO)gQdO'#EmO*}QdO'#EoO+YQdO'#ErO*[QhO'#ExO+bQdO'#EzO+mQdO'#E}O+rQaO'#CfO+yQ`O'#EbO,OQ`O'#GPO,ZQdO'#GPQOQ`OOP,eO&jO'#CaPOOO)CAa)CAaOOQP'#Ci'#CiOOQP,59R,59RO%`QdO,59ROOQP'#Cm'#CmOOQP,59V,59VO&eQdO,59VO,pQdO,59YOOQP,5:m,5:mO'nQdO,5:oO'yQdO,5:vO'yQdO,5:xO'yQdO,5:yO'yQdO'#F[O,{Q`O,58}O-TQdO'#EaOOQS,58},58}OOQP'#Cq'#CqOOQO'#EP'#EPOOQP,59Y,59YO-[Q`O,59YO-aQ`O,59YO-fQpO'#EUO-qQdO'#EVO-vQ`O'#EVO-{QpO,5:oO.iQaO,5:vO/PQaO,5:yOOQW'#D]'#D]O0OQhO'#DgO0cQhO,5;lO*[QhO'#DeO0pQ`O'#DnO0uQhO'#D{OOQW'#Fx'#FxOOQS,5;l,5;lO0zQ`O'#DhO1PQ`O'#DkOOQS-E9R-E9ROOQ['#Cv'#CvO1UQdO'#CwO1iQdO'#C|O1|QdO'#DPOOQ['#DQ'#DQO2aQ!pO'#DRO4jQ!jO,5;POOQO'#DW'#DWO-aQ`O'#DVO4zQ!nO'#FuO6}Q`O'#DXO7SQ`O'#D|OOQ['#Fu'#FuO7XQhO'#GSO7gQ`O,5;VO7lQ!bO,5;XOOQS'#Eq'#EqO7tQ`O,5;ZO7yQdO,5;ZOOQO'#Et'#EtO8RQ`O,5;^O8WQhO,5;dO'yQdO'#DjOOQS,5;f,5;fO0zQ`O,5;fO8`QdO,5;fOOQS'#Fc'#FcO8hQdO'#FPO7gQ`O,5;iO8pQdO,5:|O9QQdO'#F^O9_Q`O,5<kO9_Q`O,5<kPOOO'#FS'#FSP9jO&jO,58{POOO,58{,58{OOQP1G.m1G.mOOQP1G.q1G.qOOQP1G.t1G.tO-[Q`O1G.tO-aQ`O1G.tO9uQpO1G0ZO9}QaO1G0bO:eQaO1G0dO:{QaO1G0eO;cQaO,5;vOOQO-E9Y-E9YOOQS1G.i1G.iO;mQ`O,5:{O;rQdO'#EQO;yQdO'#CuOOQO'#EX'#EXOOQO,5:q,5:qO-qQdO,5:qOOQP1G0Z1G0ZO)gQdO1G0ZO<QQ!jO'#D]O<`Q!bO,59xO<hQhO,5:ROOQO'#Dc'#DcOOQO'#Fy'#FyO<cQ!bO,59|O<pQhO'#FdO*[QhO,59zO*[QhO'#FdO=hQhO1G1WOOQS1G1W1G1WO=rQhO,5:PO>mQhO'#DoOOQW,5:Y,5:YOOQW,5:g,5:gOOQW,5:S,5:SO>wQhO,5:VO?cQ!fO'#FvOOQS'#Fv'#FvOOQS'#FV'#FVO@pQdO,59cOOQ[,59c,59cOATQdO,59hOOQ[,59h,59hOAhQdO,59kOOQ[,59k,59kOOQ[,59m,59mO)gQdO,59oOA{QhO'#EgOOQW'#Eg'#EgOBjQ`O1G0kO4sQhO1G0kOOQ[,59q,59qO*[QhO'#DZOOQ[,59s,59sOBoQ#tO,5:hOBzQhO'#F`OCXQ`O,5<nOOQS1G0q1G0qOOQS1G0s1G0sOOQS1G0u1G0uOCdQ`O1G0uOCiQdO'#EuOOQS1G0x1G0xOOQS1G1O1G1OOCtQaO,5:UO7gQ`O1G1QOOQS1G1Q1G1QO0zQ`O1G1QOOQS-E9a-E9aOOQS1G1T1G1TOC{Q!fO1G0hODcQ`O'#EdOOQO1G0h1G0hOOQO,5;x,5;xODhQdO,5;xOOQO-E9[-E9[ODuQ`O1G2VPOOO-E9Q-E9QPOOO1G.g1G.gOOQP7+$`7+$`OOQP7+%u7+%uO)gQdO7+%uOOQS1G0g1G0gOEQQaO'#F}OE[Q`O,5:lOEaQ!fO'#FUOF_QdO'#FtOFiQ`O,59aOOQO1G0]1G0]OFnQ!bO7+%uO)gQdO1G/dOFyQhO1G/hOOQW1G/m1G/mOOQW1G/f1G/fOG[QhO,5<OOOQW-E9b-E9bOOQS7+&r7+&rOHSQhO'#D]OHbQhO'#F|OHmQ`O'#F|OHrQ`O,5:ZOHwQ!bO'#D_O>wQhO'#DmOISQhO'#DsOI[QhO'#DuOIaQ!jO'#F{OOQO'#F{'#F{OIlQ`O'#DxOItQ!bO'#DzOOQO'#Fz'#FzOIyQ`O1G/qOOQS-E9T-E9TOOQ[1G.}1G.}OOQ[1G/S1G/SOOQ[1G/V1G/VOOQ[1G/Z1G/ZOJOQdO,5;ROOQS7+&V7+&VOJTQ`O7+&VOJYQhO'#D[OJbQ`O,59uO*[QhO,59uOOQ[1G0S1G0SOJjQ`O1G0SOJoQhO,5;zOOQO-E9^-E9^OOQS7+&a7+&aOJ}QbO'#DROOQO'#Ew'#EwOK]Q`O'#EvOOQO'#Ev'#EvOKhQ`O'#FaOKpQdO,5;aOOQS,5;a,5;aOOQ[1G/p1G/pOOQS7+&l7+&lO7gQ`O7+&lOK{Q!fO'#F]O)gQdO'#F]OMSQdO7+&SOOQO7+&S7+&SOOQO,5;O,5;OOOQO1G1d1G1dOMgQ!bO<<IaOMrQdO'#FZOM|Q`O,5<iOOQP1G0W1G0WOOQS-E9S-E9SONUQdO'#FYON`Q`O,5<`OOQ]1G.{1G.{OOQP<<Ia<<IaONhQ`O<<IaONmQdO7+%OOOQO'#D_'#D_ONtQ!bO7+%SON|QhO'#FXO! ZQ`O,5<hO)gQdO,5<hOOQW1G/u1G/uO! cQ`O,5:XO>wQhO'#DtOOQO,5:_,5:_O! hQhO,5:aO! pQhO,5:fO)gQdO,5:dOOQW7+%]7+%]OOQO'#Ei'#EiO! wQ`O1G0mOOQS<<Iq<<IqO)gQdO,59vO!!kQhO1G/aOOQ[1G/a1G/aO!!rQ`O1G/aOOQW-E9U-E9UOOQ[7+%n7+%nOOQO,5;b,5;bOClQdO'#FbOKhQ`O,5;{OOQS,5;{,5;{OOQS-E9_-E9_OOQS1G0{1G0{OOQS<<JW<<JWO!!zQ!fO,5;wOOQS-E9Z-E9ZOOQO<<In<<InOOQPAN>{AN>{O!$RQ`OAN>{O!$WQaO,5;uOOQO-E9X-E9XO!$bQdO,5;tOOQO-E9W-E9WOOQW<<Hj<<HjOOQW<<Hn<<HnO!$lQhO<<HnO!$}QhO'#D]O!%]QhO,5;sO!%hQ`O,5;sOOQO-E9V-E9VO!%mQdO1G2SO!%wQhO1G/sO!&PQ`O,5:`O>wQhO'#DwOOQO1G/{1G/{O!&UQ!bO1G0QO!&^QdO1G0OOJOQdO'#F_O!&eQ`O7+&XOOQW7+&X7+&XO!&mQ!bO1G/bOOQ[7+${7+${O!&xQhO7+${P!'PQ`O'#FWOOQO,5;|,5;|OOQO-E9`-E9`OOQS1G1g1G1gOOQPG24gG24gO!'UQ`OAN>YO)gQdO1G1_O!'ZQ`O7+'nOOQO1G/z1G/zO!'cQ`O,5:cO!'hQhO7+%lOOQO,5;y,5;yOOQO-E9]-E9]OOQW<<Is<<IsOOQ[<<Hg<<HgPOQW,5;r,5;rOOQWG23tG23tO!'oQdO7+&yOOQO1G/}1G/}OOQO<<IW<<IW",
	stateData: "!(S~O$`OS$aQQ~OWVO^`O`WOcYOdYOlaOo]O#P^O#S_O#YeO#`fO#bgO#dhO#giO#mjO#okO#rlO$ZRO$^ZO$gTO$rZO~OQnOWVO^`O`WOcYOdYOlaOo]O#P^O#S_O#YeO#`fO#bgO#dhO#giO#mjO#okO#rlO$ZmO$^ZO$gTO$rZO~O$X$sP~P!mO$arO~O`YXcYXdYXoYXrYX!eYX#PYX#SYX$YYX$^YX$g[X$rYX~OgYX~P$aO$ZtO~O$gvO~O$gvO`$fXc$fXd$fXo$fXr$fX!e$fX#P$fX#S$fX$Y$fX$^$fX$r$fXg$fX~O$ZwO~O`yOczOdzOo|O#P}O#S!PO$Y!OO$^ZO$rZO~Or!SO!e!QO~P&jOf!YO$Z!UO$[!VO~OW!]O$Z!ZO$g![O~OWVO^`O`WOcYOdYOo]O#P^O#S_O$ZRO$^ZO$gTO$rZO~OS!eOc!fOd!fOh!bOr!SO!Y!dO!]!iO!`!jO$]!aO~Om!hO~P(qOQ!uOh!mOo!nOr!oOv!xO|!vO!q!wO$Z!lO$[!sO$^!pO$k!qO~OS!eOc!fOd!fOh!bO!Y!dO!]!iO!`!jO$]!aO~Or$vP~P*[Ov!}O!q!wO$Z!|O~Ov#PO$Z#PO~Oh#SOr!SO#p#UO~O$Z#WO~Oc#VX~P$aOc#ZO~Om#[O$X$sXq$sX~O$X$sXq$sX~P!mO$b#_O$c#_O$d#aO~Of#fO$Z!UO$[!VO~Or!SO!e!QO~Oq$sP~P!mOh#oO~Oh#pO~On!xX!|!xX$g!zX~O$Z#qO~O$g#sO~On#tO!|#uO~O`yOczOdzOo|O$^ZO$rZO~Or#Oa!e#Oa#P#Oa#S#Oa$Y#Oag#Oa~P.TOr#Ra!e#Ra#P#Ra#S#Ra$Y#Rag#Ra~P.TOS!eOc!fOd!fOh!bO!Y!dO!]!iO!`!jO~OR#zOv#zO$]#vO$^#yO$k!qO~P/gOm$QO!T#}O!e$OO~P(qOh$SO~O$]$UO~Oh#SO~Oh$WO~O`$YOc$YOg$]Ol$YOm$YO~P)gO`$YOc$YOl$YOm$YOn$_O~P)gO`$YOc$YOl$YOm$YOq$aO~P)gOP$bOSuXcuXduXhuXmuXxuX!YuX!]uX!`uX#[uX#^uX$]uX!WuXQuX`uXguXluXouXruXvuX|uX!quX$ZuX$[uX$^uX$kuXnuXquX!euX$XuX$uuX!}uX~Ox$cO#[$dO#^$eOm$vP~P*[Oh#pOS$iXc$iXd$iXm$iXx$iX!Y$iX!]$iX!`$iX#[$iX#^$iX$]$iXQ$iX`$iXg$iXl$iXo$iXr$iXv$iX|$iX!q$iX$Z$iX$[$iX$^$iX$k$iXn$iXq$iX!e$iX$X$iX$u$iX!}$iX~Oh$iO~Oh$kO~O!T#}O!e$lOr$vXm$vX~Or!SO~Om$oOx$cO~Om$pO~Ov$qO!q!wO~Or$rO~Or!SO!T#}O~Or!SO#p$xO~O$Z#WOr#sX~O$u$|Om#Ua$X#Uaq#Ua~P)gOm$QX$X$QXq$QX~P!mOm#[O$X$saq$sa~O$b#_O$c#_O$d%TO~On%VO!|%WO~Or#Oi!e#Oi#P#Oi#S#Oi$Y#Oig#Oi~P.TOr#Qi!e#Qi#P#Qi#S#Qi$Y#Qig#Qi~P.TOr#Ri!e#Ri#P#Ri#S#Ri$Y#Rig#Ri~P.TOr$Oa!e$Oa~P&jOq%XO~Og$qP~P'yOg$hP~P)gOc!RXg!PX!T!PX!W!RX~Oc%aO!W%bO~Og%cO!T#}O~O!T#}OS$WXc$WXd$WXh$WXm$WXr$WX!Y$WX!]$WX!`$WX!e$WX$]$WX~Om%gO!e$OO~P(qO!T#}OS!Xac!Xad!Xah!Xam!Xar!Xa!Y!Xa!]!Xa!`!Xa!e!Xa$]!Xag!Xa~O$]%hOg$pP~P/gOR#zOS!eOh%mOv#zO!Y%nO$]%lO$^#yO$k!qO~Ox$cOQ$jX`$jXc$jXg$jXh$jXl$jXm$jXo$jXr$jXv$jX|$jX!q$jX$Z$jX$[$jX$^$jX$k$jXn$jXq$jX~O`$YOc$YOg%wOl$YOm$YO~P)gO`$YOc$YOl$YOm$YOn%xO~P)gO`$YOc$YOl$YOm$YOq%yO~P)gOh%{OS#ZXc#ZXd#ZXm#ZX!Y#ZX!]#ZX!`#ZX$]#ZX~Om%|O~Og&ROv&SO!r&SO~Or$SX!e$SXm$SX~P*[O!e$lOr$vam$va~Om&VO~Oq&^O$Z&XO$k&WO~Og&_O~P&jOx$cO!e&cO$u$|Om#Ui$X#Uiq#Ui~P)gO$t&fO~Om$Qa$X$Qaq$Qa~P!mOm#[O$X$siq$si~O!e&iOg$qX~P&jOg&kO~Ox$cOQ#xXg#xXh#xXo#xXr#xXv#xX|#xX!e#xX!q#xX$Z#xX$[#xX$^#xX$k#xX~O!e&mOg$hX~P)gOg&oO~On&pOx$cO!}&qO~OR#zOv#zO$]&sO$^#yO$k!qO~O!T#}OS$Wac$Wad$Wah$Wam$War$Wa!Y$Wa!]$Wa!`$Wa!e$Wa$]$Wa~Oc!dXg!PX!T!PX!e!PX~O!T#}O!e&uOg$pX~Oc&wO~Og&xO~Oc!mXg!mX!W!RX~OS!eOh&zO~O!T&|O~O!T&|O!W&}Og$oX~Oc'OOg!lX~O!W&}O~Og'PO~O$Z'QO~Om'SO~Oc'TO!T#}O~Og'VOm'UO~Og'YO~O!T#}Or$Sa!e$Sam$Sa~OP$bOruX!euXguX~O$k&WOr#jX!e#jX~Or!SO!e'[O~Oq'`O$Z&XO$k&WO~Ox$cOQ$PXh$PXm$PXo$PXr$PXv$PX|$PX!e$PX!q$PX$X$PX$Z$PX$[$PX$^$PX$k$PX$u$PXq$PX~O!e&cO$u$|Om#Uq$X#Uqq#Uq~P)gOn'eOx$cO!}'fO~Og#}X!e#}X~P'yO!e&iOg$qa~Og#|X!e#|X~P)gO!e&mOg$ha~On'eO~Og'kO~P)gOg'lO!W'mO~O$]'nOg#{X!e#{X~P/gO!e&uOg$pa~Og'sO~OS!eOh'uO~OS!eO~PFyO`'yOg'{O~OS#zac#zad#zah#za!Y#za!]#za!`#za$]#za~Og'}O~P!!POg'}Om(OO~Ox$cOQ$Pah$Pam$Pao$Par$Pav$Pa|$Pa!e$Pa!q$Pa$X$Pa$Z$Pa$[$Pa$^$Pa$k$Pa$u$Paq$Pa~On(TO~Og#}a!e#}a~P&jOg#|a!e#|a~P)gOR#zOv#zO$]&sO$^#yO$k&WO~Oc!fXg!PX!T!PX!e!PX~O!T#}Og#{a!e#{a~Oc(VO~O!e&uOg$pi~P)gOg!ai!T!ji~Og(XO~O!W(ZOg!ni~Og!li~P)gO`'yOg(^O~Ox$cOg!Oim!Oi~Og(_O~P!!POm(`O~Og(aO~O!e&uOg$pq~Og(cO~OS!eO~P!$lOg#{q!e#{q~P)gO$`!r$a$k`$kx#S~",
	goto: "8^$wPPPPP$xP${P%U%h%U%z&^P%UP&d%UPP&jPPP&p&z&zPPPP&zPP&z&z'jP&zP&z(m&zP)])`)f)f)x)fP)f*_P)fP)f)fP*j)fP*v*|+r+uP+x*v+{*v,O,U,X,_,X)f,ePP-Z-a%U-g%U.V.V.].aPP%UP%U%UP.g/c/p/w${P0QP0TP${P${P${P0Z${P0^0a0d0k${P${PP${P0p${P0s0y1Y1t2S2Y2d2j2p2v2|3W3^3d3j3p3vPPPPPPPPPPPP3|4VP4{5O6SP6[7U7k,X7w7zP7}PP8TRsQ_bOPdp!S#[%Pq`OP^_dp}!O!P!Q!S#S#[#o%P&iqSOP^_dp}!O!P!Q!S#S#[#o%P&iqUOP^_dp}!O!P!Q!S#S#[#o%P&iQuTR#bvQxWR#cyQ!WYR#dzQ#d!YS$h!t!uR%U#f!Z!xeg!m!n!o#Z#p#u$[$^$`$c${%W%]%a&c&d&m&r&w'O'T'i'r'x(V(b!Y!xeg!m!n!o#Z#p#u$[$^$`$c${%W%]%a&c&d&m&r&w'O'T'i'r'x(V(bb#z!b$W%b%m&z&}'m'u(ZU&Z$r&]'[R'Z&Y!Z!teg!m!n!o#Z#p#u$[$^$`$c${%W%]%a&c&d&m&r&w'O'T'i'r'x(V(bR$j!vQ&P$iR'W&Qq!gafj!b!c!d!r#}$O$P$S$g$i$l&Q&uQ#w!bW%s$W%m&z'uQ&t%bQ'w&}Q(U'mR(d(Zc#z!b$W%b%m&z&}'m'u(ZQ#VkQ$V!iQ$v#UR&a$xX%q$W%m&z'up!gafj!b!c!d!r#}$O$P$S$g$i$l&Q&uW%p$W%m&z'uQ&{%nQ'v&|Q'w&}R(d(ZR$T!eR%j$SR'p&uR&{%nX%o$W%m&z'uR'v&|X%t$W%m&z'uX%r$W%m&z'u!Y!xeg!m!n!o#Z#p#u$[$^$`$c${%W%]%a&c&d&m&r&w'O'T'i'r'x(V(bQ!}hR$q#OQ!XYR#ezQ#d!XR%U#ep[OP^_dp}!O!P!Q!S#S#[#o%P&ie{X!_!`#h#i#j#k$u%Y'gQ!^]R#g|T!]]|Q#r![R%_#sQ!TXQ!haQ#TkQ#m!RQ$Q!cQ$n!zQ$t#RQ$w#VQ$z#YQ%g$PQ&`$vQ'^&[Q'a&aR(S']SoP!SQ#^pQ%O#[R&g%PZnPp!S#[%PQ$}#ZQ&e${R'd&dR$g!rQ'R%{R(['yR#OhR#QiR$s#QS&[$r&]R(Q'[V&Y$r&]'[R#YlQ#`rR%S#`QdOSpP!SU!kdp%PR%P#[Q%]#p[&l%]&r'i'r'x(bQ&r%aQ'i&mQ'r&wQ'x'OR(b(VQ$[!mQ$^!nQ$`!oV%v$[$^$`Q&Q$iR'X&QQ&v%iS'q&v(WR(W'rQ&n%]R'j&nQ&j%YR'h&jQ!RXR#l!RQ&d${R'c&dQ#]oS%Q#]%RR%R#^Q'z'RR(]'zQ$m!yR&U$mQ&]$rR'_&]Q']&[R(R']Q#XlR$y#XQ$P!cR%f$P_cOPdp!S#[%P^XOPdp!S#[%PQ!_^Q!`_Q#h}Q#i!OQ#j!PQ#k!QQ$u#SQ%Y#oR'g&iR%^#pQ!reQ!{g[$X!m!n!o$[$^$`Q${#Zh%[#p%]%a&m&r&w'O'i'r'x(V(bQ%`#uQ%z$cS&b${&dQ&h%WQ'b&cR'|'T]$Z!m!n!o$[$^$`Q!caU!yf!r$gQ#RjQ#x!bS#|!c$PQ$R!dQ%d#}Q%e$OQ%i$SS&O$i&QQ&T$lR'o&uQ#{!bW%s$W%m&z'uQ&t%bQ'w&}Q(U'mR(d(ZQ%u$WQ&y%mQ't&zR(Y'uR%k$SR%Z#oQqPR#n!SQ!zfQ$f!rR%}$g",
	nodeNames: "⚠ Unit VariableName VariableName QueryCallee Comment StyleSheet RuleSet UniversalSelector TagSelector TagName NamespacedTagSelector NamespaceName TagName NestingSelector ClassSelector . ClassName PseudoClassSelector : :: PseudoClassName PseudoClassName ) ( ArgList ValueName ParenthesizedValue AtKeyword ; ] [ BracketedValue } { BracedValue ColorLiteral NumberLiteral StringLiteral BinaryExpression BinOp CallExpression Callee IfExpression if ArgList IfBranch KeywordQuery FeatureQuery FeatureName BinaryQuery LogicOp ComparisonQuery ColorLiteral CompareOp UnaryQuery UnaryQueryOp ParenthesizedQuery SelectorQuery selector ParenthesizedSelector StyleQuery style ParenthesedQuery CallQuery ArgList PropertyName , PropertyName UnaryQuery ParenthesedQuery BinaryQuery ParenthesedQuery ParenthesedQuery StyleFeature PropertyName StyleRange PseudoQuery CallLiteral CallTag ParenthesizedContent PseudoClassName ArgList IdSelector IdName AttributeSelector AttributeName NamespacedAttribute NamespaceName AttributeName MatchOp MatchFlag ChildSelector ChildOp DescendantSelector SiblingSelector SiblingOp Block Declaration PropertyName Important ImportStatement import Layer layer LayerName layer MediaStatement media CharsetStatement charset NamespaceStatement namespace NamespaceName KeyframesStatement keyframes KeyframeName KeyframeList KeyframeSelector KeyframeRangeName SupportsStatement supports ScopeStatement scope to FontFeatureStatement font-feature-values FontName AtRule Styles",
	maxTerm: 176,
	nodeProps: [
		[
			"isolate",
			-2,
			5,
			38,
			""
		],
		[
			"openedBy",
			23,
			"(",
			30,
			"[",
			33,
			"{"
		],
		[
			"closedBy",
			24,
			")",
			31,
			"]",
			34,
			"}"
		]
	],
	propSources: [cssHighlighting],
	skippedNodes: [
		0,
		5,
		130
	],
	repeatNodeCount: 17,
	tokenData: "IO~R!bOX%ZX^&R^p%Zpq&Rqr)ers)vst+jtu/wuv%Zvw0qwx1Sxy2qyz3Sz{3X{|3r|}8e}!O8v!O!P9e!P!Q9|!Q![:u![!];p!]!^<l!^!_<}!_!`=y!`!a>^!a!b%Z!b!c?_!c!k%Z!k!lAl!l!u%Z!u!vAl!v!}%Z!}#OA}#O#P%Z#P#QB`#Q#R/w#R#]%Z#]#^Bq#^#g%Z#g#hAl#h#o%Z#o#pGU#p#qGg#q#rHO#r#sHa#s#y%Z#y#z&R#z$f%Z$f$g&R$g#BY%Z#BY#BZ&R#BZ$IS%Z$IS$I_&R$I_$I|%Z$I|$JO&R$JO$JT%Z$JT$JU&R$JU$KV%Z$KV$KW&R$KW&FU%Z&FU&FV&R&FV;'S%Z;'S;=`Hx<%lO%Z`%^SOy%jz;'S%j;'S;=`%{<%lO%j`%oS!r`Oy%jz;'S%j;'S;=`%{<%lO%j`&OP;=`<%l%j~&Wh$`~OX%jX^'r^p%jpq'rqy%jz#y%j#y#z'r#z$f%j$f$g'r$g#BY%j#BY#BZ'r#BZ$IS%j$IS$I_'r$I_$I|%j$I|$JO'r$JO$JT%j$JT$JU'r$JU$KV%j$KV$KW'r$KW&FU%j&FU&FV'r&FV;'S%j;'S;=`%{<%lO%j~'yh$`~!r`OX%jX^'r^p%jpq'rqy%jz#y%j#y#z'r#z$f%j$f$g'r$g#BY%j#BY#BZ'r#BZ$IS%j$IS$I_'r$I_$I|%j$I|$JO'r$JO$JT%j$JT$JU'r$JU$KV%j$KV$KW'r$KW&FU%j&FU&FV'r&FV;'S%j;'S;=`%{<%lO%jj)jS$uYOy%jz;'S%j;'S;=`%{<%lO%j~)yWOY)vZr)vrs*cs#O)v#O#P*h#P;'S)v;'S;=`+d<%lO)v~*hOv~~*kRO;'S)v;'S;=`*t;=`O)v~*wXOY)vZr)vrs*cs#O)v#O#P*h#P;'S)v;'S;=`+d;=`<%l)v<%lO)v~+gP;=`<%l)vj+maOy%jz}%j}!O,r!O!Q%j!Q![,r![!c%j!c!},r!}#O%j#O#P.O#P#R%j#R#S,r#S#T%j#T#o,r#o$g%j$g;'S,r;'S;=`/q<%lO,rj,ya$rY!r`Oy%jz}%j}!O,r!O!Q%j!Q![,r![!c%j!c!},r!}#O%j#O#P.O#P#R%j#R#S,r#S#T%j#T#o,r#o$g%j$g;'S,r;'S;=`/q<%lO,rj.TV!r`OY,rYZ%jZy,ryz.jz;'S,r;'S;=`/q<%lO,rY.oX$rY}!O.j!Q![.j!c!}.j#O#P/[#R#S.j#T#o.j$g;'S.j;'S;=`/k<%lO.jY/_SOY.jZ;'S.j;'S;=`/k<%lO.jY/nP;=`<%l.jj/tP;=`<%l,rd/zUOy%jz!_%j!_!`0^!`;'S%j;'S;=`%{<%lO%jd0eS!|S!r`Oy%jz;'S%j;'S;=`%{<%lO%jb0vS^QOy%jz;'S%j;'S;=`%{<%lO%j~1VWOY1SZw1Swx*cx#O1S#O#P1o#P;'S1S;'S;=`2k<%lO1S~1rRO;'S1S;'S;=`1{;=`O1S~2OXOY1SZw1Swx*cx#O1S#O#P1o#P;'S1S;'S;=`2k;=`<%l1S<%lO1S~2nP;=`<%l1Sj2vShYOy%jz;'S%j;'S;=`%{<%lO%j~3XOg~n3`UWQxWOy%jz!_%j!_!`0^!`;'S%j;'S;=`%{<%lO%jj3yWxW#SQOy%jz!O%j!O!P4c!P!Q%j!Q![7h![;'S%j;'S;=`%{<%lO%jj4hU!r`Oy%jz!Q%j!Q![4z![;'S%j;'S;=`%{<%lO%jj5RY!r`$kYOy%jz!Q%j!Q![4z![!g%j!g!h5q!h#X%j#X#Y5q#Y;'S%j;'S;=`%{<%lO%jj5vY!r`Oy%jz{%j{|6f|}%j}!O6f!O!Q%j!Q![6}![;'S%j;'S;=`%{<%lO%jj6kU!r`Oy%jz!Q%j!Q![6}![;'S%j;'S;=`%{<%lO%jj7UU!r`$kYOy%jz!Q%j!Q![6}![;'S%j;'S;=`%{<%lO%jj7o[!r`$kYOy%jz!O%j!O!P4z!P!Q%j!Q![7h![!g%j!g!h5q!h#X%j#X#Y5q#Y;'S%j;'S;=`%{<%lO%jj8jS!eYOy%jz;'S%j;'S;=`%{<%lO%jj8{WxWOy%jz!O%j!O!P4c!P!Q%j!Q![7h![;'S%j;'S;=`%{<%lO%jj9jU`YOy%jz!Q%j!Q![4z![;'S%j;'S;=`%{<%lO%j~:RTxWOy%jz{:b{;'S%j;'S;=`%{<%lO%j~:iS!r`$a~Oy%jz;'S%j;'S;=`%{<%lO%jj:z[$kYOy%jz!O%j!O!P4z!P!Q%j!Q![7h![!g%j!g!h5q!h#X%j#X#Y5q#Y;'S%j;'S;=`%{<%lO%jj;uUcYOy%jz![%j![!]<X!];'S%j;'S;=`%{<%lO%jj<`SdY!r`Oy%jz;'S%j;'S;=`%{<%lO%jj<qSmYOy%jz;'S%j;'S;=`%{<%lO%jh=SU!WWOy%jz!_%j!_!`=f!`;'S%j;'S;=`%{<%lO%jh=mS!WW!r`Oy%jz;'S%j;'S;=`%{<%lO%jl>QS!WW!|SOy%jz;'S%j;'S;=`%{<%lO%jj>eV#PQ!WWOy%jz!_%j!_!`=f!`!a>z!a;'S%j;'S;=`%{<%lO%jb?RS#PQ!r`Oy%jz;'S%j;'S;=`%{<%lO%jj?bYOy%jz}%j}!O@Q!O!c%j!c!}@o!}#T%j#T#o@o#o;'S%j;'S;=`%{<%lO%jj@VW!r`Oy%jz!c%j!c!}@o!}#T%j#T#o@o#o;'S%j;'S;=`%{<%lO%jj@v[lY!r`Oy%jz}%j}!O@o!O!Q%j!Q![@o![!c%j!c!}@o!}#T%j#T#o@o#o;'S%j;'S;=`%{<%lO%jhAqS!}WOy%jz;'S%j;'S;=`%{<%lO%jjBSSoYOy%jz;'S%j;'S;=`%{<%lO%jnBeSn^Oy%jz;'S%j;'S;=`%{<%lO%jjBvU!}WOy%jz#a%j#a#bCY#b;'S%j;'S;=`%{<%lO%jbC_U!r`Oy%jz#d%j#d#eCq#e;'S%j;'S;=`%{<%lO%jbCvU!r`Oy%jz#c%j#c#dDY#d;'S%j;'S;=`%{<%lO%jbD_U!r`Oy%jz#f%j#f#gDq#g;'S%j;'S;=`%{<%lO%jbDvU!r`Oy%jz#h%j#h#iEY#i;'S%j;'S;=`%{<%lO%jbE_U!r`Oy%jz#T%j#T#UEq#U;'S%j;'S;=`%{<%lO%jbEvU!r`Oy%jz#b%j#b#cFY#c;'S%j;'S;=`%{<%lO%jbF_U!r`Oy%jz#h%j#h#iFq#i;'S%j;'S;=`%{<%lO%jbFxS$tQ!r`Oy%jz;'S%j;'S;=`%{<%lO%jjGZSrYOy%jz;'S%j;'S;=`%{<%lO%jfGlU$gUOy%jz!_%j!_!`0^!`;'S%j;'S;=`%{<%lO%jjHTSqYOy%jz;'S%j;'S;=`%{<%lO%jfHfU#SQOy%jz!_%j!_!`0^!`;'S%j;'S;=`%{<%lO%j`H{P;=`<%l%Z",
	tokenizers: [
		descendant,
		unitToken,
		identifiers,
		queryIdentifiers,
		1,
		2,
		3,
		4,
		new LocalTokenGroup("m~RRYZ[z{a~~g~aO$c~~dP!P!Qg~lO$d~~", 28, 156)
	],
	topRules: {
		"StyleSheet": [0, 6],
		"Styles": [1, 129]
	},
	dynamicPrecedences: { "97": 1 },
	specialized: [
		{
			term: 172,
			get: (value, stack) => hashColor(value) << 1,
			external: hashColor
		},
		{
			term: 150,
			get: (value) => spec_callee[value] || -1
		},
		{
			term: 151,
			get: (value) => spec_queryIdentifier[value] || -1
		},
		{
			term: 4,
			get: (value) => spec_QueryCallee[value] || -1
		},
		{
			term: 28,
			get: (value) => spec_AtKeyword[value] || -1
		},
		{
			term: 149,
			get: (value) => spec_identifier[value] || -1
		}
	],
	tokenPrec: 2433
});
//#endregion
//#region node_modules/@codemirror/lang-css/dist/index.js
var _properties = null;
function properties() {
	if (!_properties && typeof document == "object" && document.body) {
		let { style } = document.body, names = [], seen = /* @__PURE__ */ new Set();
		for (let prop in style) if (prop != "cssText" && prop != "cssFloat") {
			if (typeof style[prop] == "string") {
				if (/[A-Z]/.test(prop)) prop = prop.replace(/[A-Z]/g, (ch) => "-" + ch.toLowerCase());
				if (!seen.has(prop)) {
					names.push(prop);
					seen.add(prop);
				}
			}
		}
		_properties = names.sort().map((name) => ({
			type: "property",
			label: name,
			apply: name + ": "
		}));
	}
	return _properties || [];
}
var pseudoClasses = /*@__PURE__*/ [
	"active",
	"after",
	"any-link",
	"autofill",
	"backdrop",
	"before",
	"checked",
	"cue",
	"default",
	"defined",
	"disabled",
	"empty",
	"enabled",
	"file-selector-button",
	"first",
	"first-child",
	"first-letter",
	"first-line",
	"first-of-type",
	"focus",
	"focus-visible",
	"focus-within",
	"fullscreen",
	"has",
	"host",
	"host-context",
	"hover",
	"in-range",
	"indeterminate",
	"invalid",
	"is",
	"lang",
	"last-child",
	"last-of-type",
	"left",
	"link",
	"marker",
	"modal",
	"not",
	"nth-child",
	"nth-last-child",
	"nth-last-of-type",
	"nth-of-type",
	"only-child",
	"only-of-type",
	"optional",
	"out-of-range",
	"part",
	"placeholder",
	"placeholder-shown",
	"read-only",
	"read-write",
	"required",
	"right",
	"root",
	"scope",
	"selection",
	"slotted",
	"target",
	"target-text",
	"valid",
	"visited",
	"where"
].map((name) => ({
	type: "class",
	label: name
}));
var values = /*@__PURE__*/ [
	"above",
	"absolute",
	"activeborder",
	"additive",
	"activecaption",
	"after-white-space",
	"ahead",
	"alias",
	"all",
	"all-scroll",
	"alphabetic",
	"alternate",
	"always",
	"antialiased",
	"appworkspace",
	"asterisks",
	"attr",
	"auto",
	"auto-flow",
	"avoid",
	"avoid-column",
	"avoid-page",
	"avoid-region",
	"axis-pan",
	"background",
	"backwards",
	"baseline",
	"below",
	"bidi-override",
	"blink",
	"block",
	"block-axis",
	"bold",
	"bolder",
	"border",
	"border-box",
	"both",
	"bottom",
	"break",
	"break-all",
	"break-word",
	"bullets",
	"button",
	"button-bevel",
	"buttonface",
	"buttonhighlight",
	"buttonshadow",
	"buttontext",
	"calc",
	"capitalize",
	"caps-lock-indicator",
	"caption",
	"captiontext",
	"caret",
	"cell",
	"center",
	"checkbox",
	"circle",
	"cjk-decimal",
	"clear",
	"clip",
	"close-quote",
	"col-resize",
	"collapse",
	"color",
	"color-burn",
	"color-dodge",
	"column",
	"column-reverse",
	"compact",
	"condensed",
	"contain",
	"content",
	"contents",
	"content-box",
	"context-menu",
	"continuous",
	"copy",
	"counter",
	"counters",
	"cover",
	"crop",
	"cross",
	"crosshair",
	"currentcolor",
	"cursive",
	"cyclic",
	"darken",
	"dashed",
	"decimal",
	"decimal-leading-zero",
	"default",
	"default-button",
	"dense",
	"destination-atop",
	"destination-in",
	"destination-out",
	"destination-over",
	"difference",
	"disc",
	"discard",
	"disclosure-closed",
	"disclosure-open",
	"document",
	"dot-dash",
	"dot-dot-dash",
	"dotted",
	"double",
	"down",
	"e-resize",
	"ease",
	"ease-in",
	"ease-in-out",
	"ease-out",
	"element",
	"ellipse",
	"ellipsis",
	"embed",
	"end",
	"ethiopic-abegede-gez",
	"ethiopic-halehame-aa-er",
	"ethiopic-halehame-gez",
	"ew-resize",
	"exclusion",
	"expanded",
	"extends",
	"extra-condensed",
	"extra-expanded",
	"fantasy",
	"fast",
	"fill",
	"fill-box",
	"fixed",
	"flat",
	"flex",
	"flex-end",
	"flex-start",
	"footnotes",
	"forwards",
	"from",
	"geometricPrecision",
	"graytext",
	"grid",
	"groove",
	"hand",
	"hard-light",
	"help",
	"hidden",
	"hide",
	"higher",
	"highlight",
	"highlighttext",
	"horizontal",
	"hsl",
	"hsla",
	"hue",
	"icon",
	"ignore",
	"inactiveborder",
	"inactivecaption",
	"inactivecaptiontext",
	"infinite",
	"infobackground",
	"infotext",
	"inherit",
	"initial",
	"inline",
	"inline-axis",
	"inline-block",
	"inline-flex",
	"inline-grid",
	"inline-table",
	"inset",
	"inside",
	"intrinsic",
	"invert",
	"italic",
	"justify",
	"keep-all",
	"landscape",
	"large",
	"larger",
	"left",
	"level",
	"lighter",
	"lighten",
	"line-through",
	"linear",
	"linear-gradient",
	"lines",
	"list-item",
	"listbox",
	"listitem",
	"local",
	"logical",
	"loud",
	"lower",
	"lower-hexadecimal",
	"lower-latin",
	"lower-norwegian",
	"lowercase",
	"ltr",
	"luminosity",
	"manipulation",
	"match",
	"matrix",
	"matrix3d",
	"medium",
	"menu",
	"menutext",
	"message-box",
	"middle",
	"min-intrinsic",
	"mix",
	"monospace",
	"move",
	"multiple",
	"multiple_mask_images",
	"multiply",
	"n-resize",
	"narrower",
	"ne-resize",
	"nesw-resize",
	"no-close-quote",
	"no-drop",
	"no-open-quote",
	"no-repeat",
	"none",
	"normal",
	"not-allowed",
	"nowrap",
	"ns-resize",
	"numbers",
	"numeric",
	"nw-resize",
	"nwse-resize",
	"oblique",
	"opacity",
	"open-quote",
	"optimizeLegibility",
	"optimizeSpeed",
	"outset",
	"outside",
	"outside-shape",
	"overlay",
	"overline",
	"padding",
	"padding-box",
	"painted",
	"page",
	"paused",
	"perspective",
	"pinch-zoom",
	"plus-darker",
	"plus-lighter",
	"pointer",
	"polygon",
	"portrait",
	"pre",
	"pre-line",
	"pre-wrap",
	"preserve-3d",
	"progress",
	"push-button",
	"radial-gradient",
	"radio",
	"read-only",
	"read-write",
	"read-write-plaintext-only",
	"rectangle",
	"region",
	"relative",
	"repeat",
	"repeating-linear-gradient",
	"repeating-radial-gradient",
	"repeat-x",
	"repeat-y",
	"reset",
	"reverse",
	"rgb",
	"rgba",
	"ridge",
	"right",
	"rotate",
	"rotate3d",
	"rotateX",
	"rotateY",
	"rotateZ",
	"round",
	"row",
	"row-resize",
	"row-reverse",
	"rtl",
	"run-in",
	"running",
	"s-resize",
	"sans-serif",
	"saturation",
	"scale",
	"scale3d",
	"scaleX",
	"scaleY",
	"scaleZ",
	"screen",
	"scroll",
	"scrollbar",
	"scroll-position",
	"se-resize",
	"self-start",
	"self-end",
	"semi-condensed",
	"semi-expanded",
	"separate",
	"serif",
	"show",
	"single",
	"skew",
	"skewX",
	"skewY",
	"skip-white-space",
	"slide",
	"slider-horizontal",
	"slider-vertical",
	"sliderthumb-horizontal",
	"sliderthumb-vertical",
	"slow",
	"small",
	"small-caps",
	"small-caption",
	"smaller",
	"soft-light",
	"solid",
	"source-atop",
	"source-in",
	"source-out",
	"source-over",
	"space",
	"space-around",
	"space-between",
	"space-evenly",
	"spell-out",
	"square",
	"start",
	"static",
	"status-bar",
	"stretch",
	"stroke",
	"stroke-box",
	"sub",
	"subpixel-antialiased",
	"svg_masks",
	"super",
	"sw-resize",
	"symbolic",
	"symbols",
	"system-ui",
	"table",
	"table-caption",
	"table-cell",
	"table-column",
	"table-column-group",
	"table-footer-group",
	"table-header-group",
	"table-row",
	"table-row-group",
	"text",
	"text-bottom",
	"text-top",
	"textarea",
	"textfield",
	"thick",
	"thin",
	"threeddarkshadow",
	"threedface",
	"threedhighlight",
	"threedlightshadow",
	"threedshadow",
	"to",
	"top",
	"transform",
	"translate",
	"translate3d",
	"translateX",
	"translateY",
	"translateZ",
	"transparent",
	"ultra-condensed",
	"ultra-expanded",
	"underline",
	"unidirectional-pan",
	"unset",
	"up",
	"upper-latin",
	"uppercase",
	"url",
	"var",
	"vertical",
	"vertical-text",
	"view-box",
	"visible",
	"visibleFill",
	"visiblePainted",
	"visibleStroke",
	"visual",
	"w-resize",
	"wait",
	"wave",
	"wider",
	"window",
	"windowframe",
	"windowtext",
	"words",
	"wrap",
	"wrap-reverse",
	"x-large",
	"x-small",
	"xor",
	"xx-large",
	"xx-small"
].map((name) => ({
	type: "keyword",
	label: name
})).concat(/*@__PURE__*/ [
	"aliceblue",
	"antiquewhite",
	"aqua",
	"aquamarine",
	"azure",
	"beige",
	"bisque",
	"black",
	"blanchedalmond",
	"blue",
	"blueviolet",
	"brown",
	"burlywood",
	"cadetblue",
	"chartreuse",
	"chocolate",
	"coral",
	"cornflowerblue",
	"cornsilk",
	"crimson",
	"cyan",
	"darkblue",
	"darkcyan",
	"darkgoldenrod",
	"darkgray",
	"darkgreen",
	"darkkhaki",
	"darkmagenta",
	"darkolivegreen",
	"darkorange",
	"darkorchid",
	"darkred",
	"darksalmon",
	"darkseagreen",
	"darkslateblue",
	"darkslategray",
	"darkturquoise",
	"darkviolet",
	"deeppink",
	"deepskyblue",
	"dimgray",
	"dodgerblue",
	"firebrick",
	"floralwhite",
	"forestgreen",
	"fuchsia",
	"gainsboro",
	"ghostwhite",
	"gold",
	"goldenrod",
	"gray",
	"grey",
	"green",
	"greenyellow",
	"honeydew",
	"hotpink",
	"indianred",
	"indigo",
	"ivory",
	"khaki",
	"lavender",
	"lavenderblush",
	"lawngreen",
	"lemonchiffon",
	"lightblue",
	"lightcoral",
	"lightcyan",
	"lightgoldenrodyellow",
	"lightgray",
	"lightgreen",
	"lightpink",
	"lightsalmon",
	"lightseagreen",
	"lightskyblue",
	"lightslategray",
	"lightsteelblue",
	"lightyellow",
	"lime",
	"limegreen",
	"linen",
	"magenta",
	"maroon",
	"mediumaquamarine",
	"mediumblue",
	"mediumorchid",
	"mediumpurple",
	"mediumseagreen",
	"mediumslateblue",
	"mediumspringgreen",
	"mediumturquoise",
	"mediumvioletred",
	"midnightblue",
	"mintcream",
	"mistyrose",
	"moccasin",
	"navajowhite",
	"navy",
	"oldlace",
	"olive",
	"olivedrab",
	"orange",
	"orangered",
	"orchid",
	"palegoldenrod",
	"palegreen",
	"paleturquoise",
	"palevioletred",
	"papayawhip",
	"peachpuff",
	"peru",
	"pink",
	"plum",
	"powderblue",
	"purple",
	"rebeccapurple",
	"red",
	"rosybrown",
	"royalblue",
	"saddlebrown",
	"salmon",
	"sandybrown",
	"seagreen",
	"seashell",
	"sienna",
	"silver",
	"skyblue",
	"slateblue",
	"slategray",
	"snow",
	"springgreen",
	"steelblue",
	"tan",
	"teal",
	"thistle",
	"tomato",
	"turquoise",
	"violet",
	"wheat",
	"white",
	"whitesmoke",
	"yellow",
	"yellowgreen"
].map((name) => ({
	type: "constant",
	label: name
})));
var tags = /*@__PURE__*/ [
	"a",
	"abbr",
	"address",
	"article",
	"aside",
	"b",
	"bdi",
	"bdo",
	"blockquote",
	"body",
	"br",
	"button",
	"canvas",
	"caption",
	"cite",
	"code",
	"col",
	"colgroup",
	"dd",
	"del",
	"details",
	"dfn",
	"dialog",
	"div",
	"dl",
	"dt",
	"em",
	"figcaption",
	"figure",
	"footer",
	"form",
	"header",
	"hgroup",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"hr",
	"html",
	"i",
	"iframe",
	"img",
	"input",
	"ins",
	"kbd",
	"label",
	"legend",
	"li",
	"main",
	"meter",
	"nav",
	"ol",
	"output",
	"p",
	"pre",
	"ruby",
	"section",
	"select",
	"small",
	"source",
	"span",
	"strong",
	"sub",
	"summary",
	"sup",
	"table",
	"tbody",
	"td",
	"template",
	"textarea",
	"tfoot",
	"th",
	"thead",
	"tr",
	"u",
	"ul"
].map((name) => ({
	type: "type",
	label: name
}));
var atRules = /*@__PURE__*/ [
	"@charset",
	"@color-profile",
	"@container",
	"@counter-style",
	"@font-face",
	"@font-feature-values",
	"@font-palette-values",
	"@import",
	"@keyframes",
	"@layer",
	"@media",
	"@namespace",
	"@page",
	"@position-try",
	"@property",
	"@scope",
	"@starting-style",
	"@supports",
	"@view-transition"
].map((label) => ({
	type: "keyword",
	label
}));
var identifier = /^(\w[\w-]*|-\w[\w-]*|)$/;
var variable = /^-(-[\w-]*)?$/;
function isVarArg(node, doc) {
	var _a;
	if (node.name == "(" || node.type.isError) node = node.parent || node;
	if (node.name != "ArgList") return false;
	let callee = (_a = node.parent) === null || _a === void 0 ? void 0 : _a.firstChild;
	if ((callee === null || callee === void 0 ? void 0 : callee.name) != "Callee") return false;
	return doc.sliceString(callee.from, callee.to) == "var";
}
var VariablesByNode = /*@__PURE__*/ new NodeWeakMap();
var declSelector = ["Declaration"];
function astTop(node) {
	for (let cur = node;;) {
		if (cur.type.isTop) return cur;
		if (!(cur = cur.parent)) return node;
	}
}
function variableNames(doc, node, isVariable) {
	if (node.to - node.from > 4096) {
		let known = VariablesByNode.get(node);
		if (known) return known;
		let result = [], seen = /* @__PURE__ */ new Set(), cursor = node.cursor(IterMode.IncludeAnonymous);
		if (cursor.firstChild()) do
			for (let option of variableNames(doc, cursor.node, isVariable)) if (!seen.has(option.label)) {
				seen.add(option.label);
				result.push(option);
			}
		while (cursor.nextSibling());
		VariablesByNode.set(node, result);
		return result;
	} else {
		let result = [], seen = /* @__PURE__ */ new Set();
		node.cursor().iterate((node) => {
			var _a;
			if (isVariable(node) && node.matchContext(declSelector) && ((_a = node.node.nextSibling) === null || _a === void 0 ? void 0 : _a.name) == ":") {
				let name = doc.sliceString(node.from, node.to);
				if (!seen.has(name)) {
					seen.add(name);
					result.push({
						label: name,
						type: "variable"
					});
				}
			}
		});
		return result;
	}
}
/**
Create a completion source for a CSS dialect, providing a
predicate for determining what kind of syntax node can act as a
completable variable. This is used by language modes like Sass and
Less to reuse this package's completion logic.
*/
var defineCSSCompletionSource = (isVariable) => (context) => {
	let { state, pos } = context, node = syntaxTree(state).resolveInner(pos, -1);
	let isDash = node.type.isError && node.from == node.to - 1 && state.doc.sliceString(node.from, node.to) == "-";
	if (node.name == "PropertyName" || (isDash || node.name == "TagName") && /^(Block|Styles)$/.test(node.resolve(node.to).name)) return {
		from: node.from,
		options: properties(),
		validFor: identifier
	};
	if (node.name == "ValueName") return {
		from: node.from,
		options: values,
		validFor: identifier
	};
	if (node.name == "PseudoClassName") return {
		from: node.from,
		options: pseudoClasses,
		validFor: identifier
	};
	if (isVariable(node) || (context.explicit || isDash) && isVarArg(node, state.doc)) return {
		from: isVariable(node) || isDash ? node.from : pos,
		options: variableNames(state.doc, astTop(node), isVariable),
		validFor: variable
	};
	if (node.name == "TagName") {
		for (let { parent } = node; parent; parent = parent.parent) if (parent.name == "Block") return {
			from: node.from,
			options: properties(),
			validFor: identifier
		};
		return {
			from: node.from,
			options: tags,
			validFor: identifier
		};
	}
	if (node.name == "AtKeyword") return {
		from: node.from,
		options: atRules,
		validFor: identifier
	};
	if (!context.explicit) return null;
	let above = node.resolve(pos), before = above.childBefore(pos);
	if (before && before.name == ":" && above.name == "PseudoClassSelector") return {
		from: pos,
		options: pseudoClasses,
		validFor: identifier
	};
	if (before && before.name == ":" && above.name == "Declaration" || above.name == "ArgList") return {
		from: pos,
		options: values,
		validFor: identifier
	};
	if (above.name == "Block" || above.name == "Styles") return {
		from: pos,
		options: properties(),
		validFor: identifier
	};
	return null;
};
/**
CSS property, variable, and value keyword completion source.
*/
var cssCompletionSource = /*@__PURE__*/ defineCSSCompletionSource((n) => n.name == "VariableName");
/**
A language provider based on the [Lezer CSS
parser](https://github.com/lezer-parser/css), extended with
highlighting and indentation information.
*/
var cssLanguage = /*@__PURE__*/ LRLanguage.define({
	name: "css",
	parser: /*@__PURE__*/ parser.configure({ props: [/*@__PURE__*/ indentNodeProp.add({ Declaration: /*@__PURE__*/ continuedIndent() }), /*@__PURE__*/ foldNodeProp.add({ "Block KeyframeList": foldInside })] }),
	languageData: {
		commentTokens: { block: {
			open: "/*",
			close: "*/"
		} },
		indentOnInput: /^\s*\}$/,
		wordChars: "-"
	}
});
/**
Language support for CSS.
*/
function css() {
	return new LanguageSupport(cssLanguage, cssLanguage.data.of({ autocomplete: cssCompletionSource }));
}
//#endregion
export { cssLanguage as n, css as t };
