//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CtqDp_IN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/_app"],
		preloads: ["/assets/index-aCRSX1yA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-aCRSX1yA.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/dashboard",
			"/_app/wallet",
			"/_app/"
		],
		preloads: [
			"/assets/_app-DVf6IsRE.js",
			"/assets/wallet-5uSnHjWk.js",
			"/assets/utils-DOQQTBMN.js"
		]
	},
	"/_app/dashboard": {
		filePath: "/workspace/src/routes/_app.dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/_app.dashboard-oVD9vCZ4.js",
			"/assets/copy-mGjrz7Db.js",
			"/assets/label-BvAoQ5bc.js"
		]
	},
	"/_app/wallet": {
		filePath: "/workspace/src/routes/_app.wallet.tsx",
		children: void 0,
		preloads: [
			"/assets/_app.wallet-8BOKqvEf.js",
			"/assets/copy-mGjrz7Db.js",
			"/assets/label-BvAoQ5bc.js"
		]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app.index.tsx",
		children: void 0,
		preloads: ["/assets/_app.index-DycWtCYw.js", "/assets/label-BvAoQ5bc.js"]
	}
} });
//#endregion
export { tsrStartManifest };
