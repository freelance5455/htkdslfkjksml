//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CiaEvftk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Cfg3wiXm.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cfg3wiXm.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DW40ZZGS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
