import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-CEah5Vjv.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["الفصل غير موجود. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
	to: "/manuale",
	children: "العودة للمنهج"
})] });
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
