import { o as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as signOut } from "./_ssr/client-IWHfIGH2.mjs";
import { a as hasGateSessionMarker } from "./_ssr/server-Bp8ENvuS.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { i as require_jsx_runtime, t as useQuery } from "./_libs/react+tanstack__react-query.mjs";
import { a as useCurrentUserState, i as useCurrentUser, n as Splash, t as BrandMark } from "./_ssr/splash-34x-4Cka.mjs";
import { S as Navigate, _ as Outlet, m as useRouterState, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { m as useBootstrap, u as searchBooks } from "./_ssr/use-books-BtZpLk9U.mjs";
import { a as Plus, c as Landmark, d as BookOpen, f as Activity, i as Search, l as Ellipsis, n as Users, o as ListChecks, s as LayoutDashboard, t as Wallet, u as CalendarCheck } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-C3tjRPg9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var NAV = [
	{
		to: "/dashboard",
		label: "داشبورد",
		icon: LayoutDashboard
	},
	{
		to: "/operations",
		label: "عملیات",
		icon: ListChecks
	},
	{
		to: "/parties",
		label: "اشخاص",
		icon: Users
	},
	{
		to: "/reports",
		label: "گزارش‌ها",
		icon: BookOpen
	}
];
var MORE = [
	{
		to: "/liquidity",
		label: "نقدینگی",
		icon: Wallet
	},
	{
		to: "/kpi",
		label: "شاخص‌ها",
		icon: Activity
	},
	{
		to: "/crm",
		label: "باشگاه مشتریان",
		icon: Users
	},
	{
		to: "/checks",
		label: "چک‌ها",
		icon: Landmark
	},
	{
		to: "/accounts",
		label: "کدینگ حساب‌ها"
	},
	{
		to: "/journals",
		label: "اسناد حسابداری"
	},
	{
		to: "/close-day",
		label: "بستن روز",
		icon: CalendarCheck
	},
	{
		to: "/audit",
		label: "حسابرسی"
	},
	{
		to: "/health",
		label: "سلامت سیستم"
	},
	{
		to: "/settings",
		label: "تنظیمات"
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const user = useCurrentUser();
	const [more, setMore] = (0, import_react.useState)(false);
	const [searchOpen, setSearchOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-grain min-h-dvh bg-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed top-0 right-0 z-30 hidden h-dvh w-[272px] flex-col border-l border-white/10 bg-navy text-cream lg:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-5 pt-6 pb-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, { className: "size-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-lg tracking-[0.14em] leading-none",
							children: "MR,KHORASANI"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-[10px] tracking-[0.18em] text-gold-2",
							children: "ACCOUNTING"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mx-5" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex-1 space-y-0.5 overflow-y-auto px-3 py-4",
						children: [
							NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
								...item,
								active: pathname.startsWith(item.to)
							}, item.to)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "px-3 pt-5 pb-2 text-[10px] tracking-[0.2em] text-gold/80",
								children: "ماژول‌ها"
							}),
							MORE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
								...item,
								active: pathname.startsWith(item.to)
							}, item.to))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-white/10 p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm",
									children: user?.displayName ?? "کاربر"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-[11px] text-cream/50",
									children: user?.email ?? ""
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:mr-[272px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-cream/90 px-4 py-3 backdrop-blur-md lg:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 lg:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-base tracking-[0.12em]",
								children: "MR,KHORASANI"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden text-sm text-muted lg:block",
							children: "سامانه حسابداری دوبل · سال مالی ۱۴۰۵"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/operations/new",
									className: "inline-flex h-10 items-center gap-1.5 rounded-[10px] bg-navy px-3 text-sm text-cream",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: "ثبت عملیات"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setSearchOpen(true),
									className: "inline-flex size-10 items-center justify-center rounded-[10px] border border-line bg-paper",
									"aria-label": "جستجو",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "lg:hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-6xl px-4 pb-28 pt-5 lg:px-8 lg:pb-10",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-5",
					children: [NAV.map((item) => {
						const Icon = item.icon;
						const active = pathname.startsWith(item.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex flex-col items-center gap-1 py-2.5 text-[11px]", active ? "text-navy" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-5", active && "text-gold") }), item.label]
						}, item.to);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setMore(true),
						className: "flex flex-col items-center gap-1 py-2.5 text-[11px] text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-5" }), "بیشتر"]
					})]
				})
			}),
			more ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "absolute inset-0 bg-navy/50",
					onClick: () => setMore(false),
					"aria-label": "بستن"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 rounded-t-[24px] bg-paper p-5 pb-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1 w-10 rounded-full bg-line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: MORE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							onClick: () => setMore(false),
							className: "rounded-[16px] border border-line bg-cream px-2 py-4 text-center text-xs",
							children: item.label
						}, item.to))
					})]
				})]
			}) : null,
			searchOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchOverlay, { onClose: () => setSearchOpen(false) }) : null
		]
	});
}
function NavLink({ to, label, icon: Icon, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex items-center gap-2.5 rounded-[12px] px-3 py-2.5 text-sm transition-colors", active ? "bg-white/10 text-gold-2" : "text-cream/75 hover:bg-white/5 hover:text-cream"),
		children: [Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 opacity-80" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-gold/70" }), label]
	});
}
function SearchOverlay({ onClose }) {
	const [q, setQ] = (0, import_react.useState)("");
	const { data, isFetching } = useQuery({
		queryKey: ["search", q],
		queryFn: () => searchBooks({ data: { q } }),
		enabled: q.trim().length >= 2
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-start justify-center bg-navy/50 p-4 pt-[12vh]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "absolute inset-0",
			onClick: onClose,
			"aria-label": "بستن جستجو"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative w-full max-w-lg rounded-[20px] border border-line bg-paper p-4 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "جستجوی شخص، سند، مبلغ، شرح…",
					className: "h-12 w-full rounded-[12px] border border-line bg-cream px-3 text-sm outline-none focus:border-gold"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted",
					children: "جستجو در دفتر کل، اشخاص و عملیات. حداقل دو نویسه."
				}),
				isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-16 animate-pulse rounded-xl bg-secondary" }) : null,
				data && !data.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 text-sm text-muted",
					children: "موردی یافت نشد."
				}) : null,
				data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 max-h-72 space-y-1 overflow-y-auto",
					children: data.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: r.to,
						onClick: onClose,
						className: "flex items-center justify-between rounded-[12px] px-3 py-2.5 hover:bg-cream",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: r.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] text-muted",
							children: r.kind
						})]
					}) }, r.id))
				}) : null
			]
		})]
	});
}
function AppLayout() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) });
}
function BootGate({ children }) {
	const boot = useBootstrap();
	if (boot.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, { message: "باز کردن دفاتر سال مالی" });
	if (boot.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-cream p-8 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-lg font-semibold text-navy",
			children: "خطا در بارگذاری دفاتر"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: boot.error.message
		})] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
//#endregion
export { AppLayout as component };
