import { i as __toESM } from "./_runtime.mjs";
import { b as require_jsx_runtime, x as require_react } from "./_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route$1 } from "./_ssr/router-JV23dvxm.mjs";
import { C as sexLabel, D as todayIso, O as useFlock, c as ageLabel, f as daysFromToday, g as formatKg, h as formatInt, i as HEALTH_KIND_LABEL, k as useHydrated, m as formatDate, p as daysLabel, t as AppShell, v as inHerd, w as sheepName, y as isLamb } from "./_ssr/store-g4o8WGZx.mjs";
import { t as SheepBadges } from "./_ssr/sheep-bits-ABYC-5qN.mjs";
import { t as Input } from "./_ssr/input-CkkIr1XO.mjs";
import { t as Card } from "./_ssr/card-DKPDfbAA.mjs";
import { t as Button } from "./_ssr/button-C77Erh3S.mjs";
import { t as Field } from "./_ssr/field-DxoiOhiJ.mjs";
import { i as SheepForm, n as HealthForm, r as LambingForm, t as BreedingForm } from "./_ssr/forms-z1jNLbZu.mjs";
import { t as Confirm } from "./_ssr/confirm-D8Ph184n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-Dts8J8vn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SheepPage() {
	const { id } = Route$1.useParams();
	const navigate = Route$1.useNavigate();
	const hydrated = useHydrated();
	const sheep = useFlock((s) => s.sheep);
	const breeding = useFlock((s) => s.breeding);
	const health = useFlock((s) => s.health);
	const weights = useFlock((s) => s.weights);
	const setStatus = useFlock((s) => s.setStatus);
	const removeSheep = useFlock((s) => s.removeSheep);
	const addWeight = useFlock((s) => s.addWeight);
	const removeWeight = useFlock((s) => s.removeWeight);
	const removeHealth = useFlock((s) => s.removeHealth);
	const markLost = useFlock((s) => s.markLost);
	const removeBreeding = useFlock((s) => s.removeBreeding);
	const animal = sheep.find((s) => s.id === id);
	const [panel, setPanel] = (0, import_react.useState)(null);
	const [ask, setAsk] = (0, import_react.useState)(null);
	const [weightDate, setWeightDate] = (0, import_react.useState)(todayIso());
	const [weightValue, setWeightValue] = (0, import_react.useState)("");
	const [weightError, setWeightError] = (0, import_react.useState)(null);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "…",
		backTo: "/flock",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "يُفتح السجل…"
		})
	});
	if (!animal) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "غير موجود",
		backTo: "/flock",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "هذا الرأس ليس في السجل."
		})
	});
	const young = isLamb(animal);
	const herd = inHerd(animal);
	const pending = breeding.find((b) => b.eweId === animal.id && b.result === "pending");
	const history = breeding.filter((b) => b.eweId === animal.id || b.ramId === animal.id).slice().sort((a, b) => a.matingDate < b.matingDate ? 1 : -1);
	const animalHealth = health.filter((h) => h.sheepId === animal.id).slice().sort((a, b) => a.date < b.date ? 1 : -1);
	const animalWeights = weights.filter((w) => w.sheepId === animal.id).slice().sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0);
	const spark = animalWeights.slice().sort((a, b) => a.date.localeCompare(b.date));
	const dam = sheep.find((s) => s.id === animal.damId);
	const sire = sheep.find((s) => s.id === animal.sireId);
	const offspring = sheep.filter((s) => s.damId === animal.id || s.sireId === animal.id);
	function saveWeight(e) {
		e.preventDefault();
		const kg = Number(weightValue.replace(",", "."));
		const result = addWeight(animal.id, weightDate, kg);
		if ("error" in result) {
			setWeightError(result.error);
			return;
		}
		setWeightValue("");
		setWeightError(null);
		setPanel(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: animal.tag,
		backTo: "/flock",
		children: [
			panel === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheepForm, {
				sheepId: animal.id,
				onSaved: () => setPanel(null)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5",
				children: [
					!herd ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-2xl border border-border px-4 py-3 text-sm text-muted-foreground",
						children: [
							"هذا الرأس خارج القطيع (",
							animal.status === "sold" ? "مبيع" : "نافق",
							")."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-3xl font-semibold break-all tabular-nums tracking-tight",
							children: animal.tag
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								sexLabel(animal.sex, young),
								animal.name,
								animal.breed
							].filter(Boolean).join(" · ")
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheepBadges, {
							sheep: animal,
							breeding
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "grid grid-cols-2 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								label: "العمر",
								value: ageLabel(animal.birthDate)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								label: "الوزن",
								value: formatKg(animal.weightKg)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								label: "الحظيرة",
								value: animal.pen || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								label: "الميلاد",
								value: formatDate(animal.birthDate)
							})
						]
					}),
					animal.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-normal whitespace-pre-wrap",
						children: animal.notes
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-3 text-sm",
						children: [dam ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sheep/$id",
							params: { id: dam.id },
							className: "text-muted-foreground",
							children: ["الأم ", sheepName(dam, "")]
						}) : null, sire ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sheep/$id",
							params: { id: sire.id },
							className: "text-muted-foreground",
							children: ["الأب ", sheepName(sire, "")]
						}) : null]
					}),
					pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "حمل قائم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-medium",
							children: daysLabel(daysFromToday(pending.expectedDate))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								"تلقيح ",
								formatDate(pending.matingDate),
								" · تُنتظر",
								" ",
								formatDate(pending.expectedDate)
							]
						})
					] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setPanel("weight"),
								children: "تسجيل وزن"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setPanel("health"),
								children: "علاج أو تطعيم"
							}),
							animal.sex === "ewe" && herd && !pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setPanel("breed"),
								children: "تلقيح"
							}) : null,
							pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => setPanel("lamb"),
								children: "تسجيل ولادة"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setPanel("edit"),
								children: "تعديل البيانات"
							})
						]
					}),
					panel === "weight" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: saveWeight,
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "التاريخ",
								htmlFor: "w-date",
								error: weightError ?? void 0,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "w-date",
									type: "date",
									value: weightDate,
									onChange: (e) => setWeightDate(e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الوزن كغ",
								htmlFor: "w-kg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "w-kg",
									inputMode: "decimal",
									value: weightValue,
									onChange: (e) => setWeightValue(e.target.value),
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								children: "حفظ الوزن"
							})
						]
					}) }) : null,
					panel === "health" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HealthForm, {
						defaultSheepId: animal.id,
						onDone: () => setPanel(null)
					}) }) : null,
					panel === "breed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreedingForm, {
						defaultEweId: animal.id,
						onDone: () => setPanel(null)
					}) }) : null,
					panel === "lamb" && pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LambingForm, {
						breedingId: pending.id,
						onDone: () => setPanel(null)
					}) }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium text-muted-foreground",
								children: "الأوزان"
							}),
							spark.length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { points: spark }) : null,
							animalWeights.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "لا أوزان مسجلة."
							}) : animalWeights.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: [
										formatDate(w.date),
										" · ",
										formatKg(w.kg)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-muted-foreground",
									onClick: () => removeWeight(w.id),
									children: "حذف"
								})]
							}, w.id))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-muted-foreground",
							children: "الصحة"
						}), animalHealth.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "لا سجلات لهذا الرأس."
						}) : animalHealth.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium",
								children: h.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [
									HEALTH_KIND_LABEL[h.kind],
									" · ",
									formatDate(h.date)
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-muted-foreground",
								onClick: () => removeHealth(h.id),
								children: "حذف"
							})]
						}, h.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium text-muted-foreground",
								children: "التناسل"
							}),
							history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "لا تلقيح مرتبط."
							}) : history.map((b) => {
								const otherId = b.eweId === animal.id ? b.ramId : b.eweId;
								const other = sheep.find((s) => s.id === otherId);
								const label = b.result === "pending" ? "قائم" : b.result === "lambed" ? `ولادة ${formatInt(b.lambCount ?? 0)}` : "مفقود";
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-medium",
											children: [
												formatDate(b.matingDate),
												" · ",
												label
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-muted-foreground",
											children: [
												b.eweId === animal.id ? "الكبش" : "النعجة",
												" ",
												other ? sheepName(other, "") : "غير محدد",
												b.result === "pending" ? ` · ${formatDate(b.expectedDate)}` : ""
											]
										}),
										b.result !== "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "mt-1 text-muted-foreground",
											onClick: () => removeBreeding(b.id),
											children: "حذف"
										}) : null
									]
								}, b.id);
							}),
							offspring.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-col gap-1",
								children: offspring.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/sheep/$id",
									params: { id: child.id },
									className: "text-sm text-muted-foreground",
									children: ["مولود ", child.tag]
								}, child.id))
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 border-t border-border pt-4",
						children: [
							herd ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setStatus(animal.id, animal.status === "sick" ? "active" : "sick"),
									children: animal.status === "sick" ? "تعليم سليم" : "تعليم مريض"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setAsk("sold"),
									children: "تسجيل بيع"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setAsk("dead"),
									children: "تسجيل نفوق"
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setStatus(animal.id, "active"),
								children: "إعادة إلى القطيع"
							}),
							pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setAsk("lost"),
								children: "الحمل لم يكتمل"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setAsk("delete"),
								children: "حذف من السجل"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Confirm, {
				open: ask === "sold",
				onOpenChange: (open) => !open && setAsk(null),
				title: "تسجيل البيع؟",
				body: "يخرج الرأس من تعداد الحظيرة ويبقى في الأرشيف.",
				confirmLabel: "بيع",
				onConfirm: () => {
					setStatus(animal.id, "sold");
					setAsk(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Confirm, {
				open: ask === "dead",
				onOpenChange: (open) => !open && setAsk(null),
				title: "تسجيل النفوق؟",
				body: "يخرج الرأس من تعداد الحظيرة ويبقى في الأرشيف.",
				confirmLabel: "تأكيد",
				destructive: true,
				onConfirm: () => {
					setStatus(animal.id, "dead");
					setAsk(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Confirm, {
				open: ask === "lost",
				onOpenChange: (open) => !open && setAsk(null),
				title: "إغلاق الحمل؟",
				body: "يُعلَّم التلقيح القائم مفقوداً ولن تُحسب النعجة حاملاً.",
				confirmLabel: "إغلاق",
				onConfirm: () => {
					if (pending) markLost(pending.id, todayIso());
					setAsk(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Confirm, {
				open: ask === "delete",
				onOpenChange: (open) => !open && setAsk(null),
				title: "حذف هذا الرأس؟",
				body: "تُحذف أوزانه وسجلاته الصحية وتلقيحاته. لا يمكن التراجع.",
				confirmLabel: "حذف",
				destructive: true,
				onConfirm: () => {
					removeSheep(animal.id);
					navigate({ to: "/flock" });
				}
			})
		]
	});
}
function Fact({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm font-medium",
		children: value
	})] });
}
function Spark({ points }) {
	const vals = points.map((p) => p.kg);
	const min = Math.min(...vals);
	const span = Math.max(...vals) - min || 1;
	const w = 320;
	const h = 88;
	const coords = points.map((p, i) => {
		return `${i / (points.length - 1) * w},${h - (p.kg - min) / span * 76 - 6}`;
	}).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "h-24 w-full text-foreground",
		role: "img",
		"aria-label": "منحنى الوزن",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.5",
			strokeLinejoin: "round",
			strokeLinecap: "round",
			points: coords
		})
	});
}
//#endregion
export { SheepPage as component };
