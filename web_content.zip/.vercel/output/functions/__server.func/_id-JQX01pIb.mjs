import { o as __toESM } from "./_runtime.mjs";
import { a as genderLabel, i as fullName, r as formatScore } from "./_ssr/calc-DDlXNlj6.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { P as require_jsx_runtime, a as Overlay2, c as Title2, i as Description2, l as Trigger2, n as Cancel, o as Portal2, r as Content2, s as Root2, t as Action } from "./_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Card } from "./_ssr/card-n_ZyUc_C.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link, x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { f as saveGrades, i as deleteStudent, l as listSchools, o as getStudent, p as updateStudent, s as issueCertificate, t as Skeleton, u as listStreams } from "./_ssr/server-BRpT2GPU.mjs";
import { n as MentionBadge, t as DecisionBadge } from "./_ssr/mention-badge-kWeo3_az.mjs";
import { g as ArrowRight, i as Trash2, s as Printer } from "./_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { n as Route } from "./_ssr/router-C2NnLxPF.mjs";
import { n as buttonVariants, t as Button } from "./_ssr/button-C0qE0jyX.mjs";
import { t as CertificateDoc } from "./_ssr/certificate-doc-BBvbW0tk.mjs";
import { c as TableBody, d as TableHeader, f as TableRow, l as TableCell, s as Table, t as Input, u as TableHead } from "./_ssr/table-DKHBmBA9.mjs";
import { t as StudentForm } from "./_ssr/student-form-DnG5GB3q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-JQX01pIb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AlertDialog = Root2;
var AlertDialogTrigger = Trigger2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	ref,
	className: cn("fixed inset-0 z-50 bg-ink/40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 gap-4 rounded-lg bg-surface p-5 shadow-card duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 text-start", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
function StudentDetailPage() {
	const { id } = Route.useParams();
	const studentId = Number(id);
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const studentQuery = useQuery({
		queryKey: ["student", studentId],
		queryFn: () => getStudent({ data: { id: studentId } }),
		enabled: Number.isFinite(studentId)
	});
	const streamsQuery = useQuery({
		queryKey: ["streams"],
		queryFn: () => listStreams()
	});
	const schoolsQuery = useQuery({
		queryKey: ["schools"],
		queryFn: () => listSchools()
	});
	const student = studentQuery.data;
	const [scores, setScores] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		if (!student) return;
		const next = {};
		for (const grade of student.grades) next[grade.subjectId] = grade.score == null ? "" : grade.score.toFixed(2);
		setScores(next);
	}, [student]);
	const saveMutation = useMutation({
		mutationFn: saveGrades,
		onSuccess: () => {
			toast.success("تم حفظ العلامات وحسم المعدل");
			queryClient.invalidateQueries({ queryKey: ["student", studentId] });
			queryClient.invalidateQueries({ queryKey: ["students"] });
			queryClient.invalidateQueries({ queryKey: ["results"] });
			queryClient.invalidateQueries({ queryKey: ["dashboard"] });
		},
		onError: (err) => toast.error(err.message)
	});
	const updateMutation = useMutation({
		mutationFn: updateStudent,
		onSuccess: () => {
			toast.success("تم تحديث بيانات المترشح");
			queryClient.invalidateQueries({ queryKey: ["student", studentId] });
			queryClient.invalidateQueries({ queryKey: ["students"] });
		},
		onError: (err) => toast.error(err.message)
	});
	const issueMutation = useMutation({
		mutationFn: issueCertificate,
		onSuccess: (res) => {
			toast.success(`صدرت الشهادة برقم ${res.certificateNumber}`);
			queryClient.invalidateQueries({ queryKey: ["student", studentId] });
			queryClient.invalidateQueries({ queryKey: ["results"] });
		},
		onError: (err) => toast.error(err.message)
	});
	const deleteMutation = useMutation({
		mutationFn: deleteStudent,
		onSuccess: () => {
			toast.success("حُذف ملف المترشح");
			queryClient.invalidateQueries({ queryKey: ["students"] });
			queryClient.invalidateQueries({ queryKey: ["dashboard"] });
			queryClient.invalidateQueries({ queryKey: ["results"] });
			navigate({ to: "/students" });
		},
		onError: (err) => toast.error(err.message)
	});
	if (studentQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96 rounded-lg" });
	if (!student) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "المترشح غير موجود."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		asChild: true,
		variant: "outline",
		className: "mt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/students",
			children: "العودة إلى القائمة"
		})
	})] });
	const weighted = student.grades.reduce((sum, g) => {
		const raw = scores[g.subjectId];
		const score = raw === "" || raw == null ? g.score : Number(raw);
		if (score == null || Number.isNaN(score)) return sum;
		return sum + score * g.coefficient;
	}, 0);
	const liveAverage = student.totalCoefficient ? weighted / student.totalCoefficient : 0;
	const allFilled = student.grades.every((g) => {
		const raw = scores[g.subjectId];
		const score = raw === "" ? null : Number(raw);
		return score != null && !Number.isNaN(score);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/students",
						className: "inline-flex min-h-11 items-center gap-1 text-sm text-muted hover:text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" }), "المترشحون"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold",
						children: fullName(student.lastName, student.firstName)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"رقم التسجيل ",
							student.examNumber,
							" · ",
							student.streamName,
							" · ",
							student.sessionLabel
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [student.decision === "ناجح" ? student.certificateNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/certificates/$id",
							params: { id: String(student.id) },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "عرض الشهادة"]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => issueMutation.mutate({ data: { studentId: student.id } }),
						disabled: issueMutation.isPending,
						children: "إصدار الشهادة"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "حذف"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "حذف ملف المترشح؟" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "سيُحذف المترشح وعلاماته ونتيجته. لا يمكن التراجع عن هذا الإجراء." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "إلغاء" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						className: "bg-danger text-primary-fg hover:opacity-90",
						onClick: () => deleteMutation.mutate({ data: { id: student.id } }),
						children: "تأكيد الحذف"
					})] })] })] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold",
							children: "البيانات الشخصية"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-2 gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "الجنس"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5",
									children: genderLabel(student.gender)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "تاريخ الميلاد"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5 tabular-nums",
									children: student.birthDate
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "مكان الميلاد"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-0.5",
									children: student.birthPlace
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "الثانوية"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "mt-0.5",
									children: [student.schoolName, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-muted",
										children: student.wilaya
									})]
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MentionBadge, {
									mention: student.mention,
									decision: student.decision,
									average: student.average
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionBadge, { decision: student.decision }),
								student.average != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm font-semibold tabular-nums",
									children: ["المعدل ", formatScore(student.average)]
								}) : null
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex flex-wrap items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base font-semibold",
								children: "كشف النقاط"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: ["العلامات من 0 إلى 20 · المعامل الإجمالي ", student.totalCoefficient]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm",
								children: [
									"المعدل الحي",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold tabular-nums",
										children: allFilled ? formatScore(liveAverage) : "—"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "المادة" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "المعامل" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "العلامة" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "النقاط" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: student.grades.map((grade) => {
							const raw = scores[grade.subjectId] ?? "";
							const score = raw === "" ? null : Number(raw);
							const points = score != null && !Number.isNaN(score) ? score * grade.coefficient : null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: grade.nameAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "tabular-nums",
									children: grade.coefficient
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "w-28",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										min: 0,
										max: 20,
										step: "0.25",
										value: raw,
										onChange: (e) => setScores((prev) => ({
											...prev,
											[grade.subjectId]: e.target.value
										})),
										className: "h-10 tabular-nums"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "tabular-nums",
									children: formatScore(points)
								})
							] }, grade.subjectId);
						}) })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4",
							disabled: saveMutation.isPending || !allFilled,
							onClick: () => {
								const grades = student.grades.map((g) => ({
									subjectId: g.subjectId,
									score: Number(scores[g.subjectId])
								}));
								if (grades.some((g) => Number.isNaN(g.score) || g.score < 0 || g.score > 20)) {
									toast.error("أدخل علامات صحيحة بين 0 و 20");
									return;
								}
								saveMutation.mutate({ data: {
									studentId: student.id,
									grades
								} });
							},
							children: saveMutation.isPending ? "جاري الحفظ…" : "حفظ العلامات وحسم النتيجة"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-4 text-base font-semibold",
				children: "تعديل الملف"
			}), streamsQuery.data && schoolsQuery.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentForm, {
				streams: streamsQuery.data,
				schools: schoolsQuery.data,
				initial: {
					firstName: student.firstName,
					lastName: student.lastName,
					birthDate: student.birthDate,
					birthPlace: student.birthPlace,
					gender: student.gender,
					schoolId: student.schoolId,
					streamId: student.streamId
				},
				submitLabel: "تحديث البيانات",
				pending: updateMutation.isPending,
				onSubmit: (values) => updateMutation.mutate({ data: {
					id: student.id,
					...values
				} })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32" })] }),
			student.decision === "ناجح" && student.certificateNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CertificateDoc, { student })
			}) : null
		]
	});
}
//#endregion
export { StudentDetailPage as component };
