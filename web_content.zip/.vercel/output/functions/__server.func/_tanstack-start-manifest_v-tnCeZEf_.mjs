//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-tnCeZEf_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/rtc"],
		preloads: ["/assets/index-BX4B-DBb.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BX4B-DBb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CaIEACQ4.js"]
	}
} });
//#endregion
export { tsrStartManifest };
