//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CkP4myV9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-A4myXiEg.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-A4myXiEg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DyVF24xM.js"]
	}
} });
//#endregion
export { tsrStartManifest };
