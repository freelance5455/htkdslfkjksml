//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C-V4dGT6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DSMr8JUr.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DSMr8JUr.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B884vvXr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
