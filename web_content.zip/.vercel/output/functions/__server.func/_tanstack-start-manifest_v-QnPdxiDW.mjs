//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-QnPdxiDW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Cw_se9zh.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cw_se9zh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BpGjUA0A.js"]
	}
} });
//#endregion
export { tsrStartManifest };
