//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-skxBmliZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CWTssCJH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CWTssCJH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Cx-IQX6J.js"]
	}
} });
//#endregion
export { tsrStartManifest };
