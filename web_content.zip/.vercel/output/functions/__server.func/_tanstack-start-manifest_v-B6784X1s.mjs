//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B6784X1s.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-MyWYAoVN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-MyWYAoVN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C8X6pv_6.js"]
	}
} });
//#endregion
export { tsrStartManifest };
