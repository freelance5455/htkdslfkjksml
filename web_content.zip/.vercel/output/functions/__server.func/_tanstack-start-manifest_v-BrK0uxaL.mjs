//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BrK0uxaL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BMBhJMXG.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BMBhJMXG.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DdIwoZFs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
