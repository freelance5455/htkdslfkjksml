//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-y8uOT9Iz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/studio/forward"],
		preloads: ["/assets/index-CBxb7llX.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CBxb7llX.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bd9p4dUL.js"]
	}
} });
//#endregion
export { tsrStartManifest };
