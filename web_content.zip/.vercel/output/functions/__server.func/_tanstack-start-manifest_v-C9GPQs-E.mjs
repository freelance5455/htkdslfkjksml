//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C9GPQs-E.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-ByKN_FWC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ByKN_FWC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DTaFLQyf.js"]
	}
} });
//#endregion
export { tsrStartManifest };
