//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BKjhAsnE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/workspace"],
		preloads: [
			"/assets/index-BHlERPAb.js",
			"/assets/link-CUXDjV5u.js",
			"/assets/useNavigate-CSFW_em-.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BHlERPAb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BRUyWNR0.js", "/assets/button-BVTk_EGA.js"]
	},
	"/workspace": {
		filePath: "/workspace/src/routes/workspace.tsx",
		children: void 0,
		preloads: ["/assets/workspace-BZJIuZHo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
