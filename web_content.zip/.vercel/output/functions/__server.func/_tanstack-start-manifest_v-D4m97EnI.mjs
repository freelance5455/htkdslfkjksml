//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D4m97EnI.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-TA8BOZmm.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-TA8BOZmm.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BoebuX27.js"]
	}
} });
//#endregion
export { tsrStartManifest };
