//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BdoRQ2HX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/read/$bookId"],
		preloads: [
			"/assets/index-JJIW_qCG.js",
			"/assets/rolldown-runtime-W7wSyTde.js",
			"/assets/dist-BJHmb1Oz.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-JJIW_qCG.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-k0XZok8n.js", "/assets/library-DdNz-g8-.js"]
	},
	"/read/$bookId": {
		filePath: "/workspace/src/routes/read.$bookId.tsx",
		children: void 0,
		preloads: ["/assets/read._bookId-B2KXATGH.js", "/assets/library-DdNz-g8-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
