//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dzff7DUc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/create",
			"/settings",
			"/storyboards/",
			"/storyboards/$id/preview",
			"/storyboards/$id/"
		],
		preloads: [
			"/assets/index-Cabaj4Mn.js",
			"/assets/jsx-runtime-Dk72oS4N.js",
			"/assets/preload-helper-NQ6MQN_N.js",
			"/assets/link-D5U5J0TK.js",
			"/assets/useRouter-BWuYVZyj.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cabaj4Mn.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CPRsm-3x.js",
			"/assets/use-projects-RCLuieFH.js",
			"/assets/format-DVr6sjC1.js"
		]
	},
	"/create": {
		filePath: "/workspace/src/routes/create.tsx",
		children: void 0,
		preloads: [
			"/assets/create-DaAg5I61.js",
			"/assets/useNavigate-DMavMrLm.js",
			"/assets/use-projects-RCLuieFH.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CKX7Nuvc.js",
			"/assets/types-BzuhMYJg.js",
			"/assets/use-projects-RCLuieFH.js",
			"/assets/options-BcekeRNx.js"
		]
	},
	"/storyboards/": {
		filePath: "/workspace/src/routes/storyboards/index.tsx",
		children: void 0,
		preloads: [
			"/assets/storyboards-C6Lxd8pV.js",
			"/assets/use-projects-RCLuieFH.js",
			"/assets/format-DVr6sjC1.js"
		]
	},
	"/storyboards/$id/preview": {
		filePath: "/workspace/src/routes/storyboards/$id/preview.tsx",
		children: void 0,
		preloads: [
			"/assets/preview-C-2Vxm-O.js",
			"/assets/use-projects-RCLuieFH.js",
			"/assets/options-BcekeRNx.js",
			"/assets/prompts-DVgq3jEQ.js"
		]
	},
	"/storyboards/$id/": {
		filePath: "/workspace/src/routes/storyboards/$id/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-BXOidf4p.js",
			"/assets/useNavigate-DMavMrLm.js",
			"/assets/types-BzuhMYJg.js",
			"/assets/use-projects-RCLuieFH.js",
			"/assets/options-BcekeRNx.js",
			"/assets/prompts-DVgq3jEQ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
