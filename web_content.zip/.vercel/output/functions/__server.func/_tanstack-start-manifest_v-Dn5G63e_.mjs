//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dn5G63e_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/_app", "/certificates/$id"],
		preloads: [
			"/assets/index-B17dvujr.js",
			"/assets/createLucideIcon-CjV2GK-l.js",
			"/assets/query-CkrW9HuT.js",
			"/assets/link-C1KcwR7P.js",
			"/assets/useMatch-CIo9h2PM.js",
			"/assets/preload-helper-cIPVFF8l.js",
			"/assets/useRouter-B-hTMCwg.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B17dvujr.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app/route.tsx",
		children: [
			"/_app/results",
			"/_app/schools",
			"/_app/",
			"/_app/students/$id",
			"/_app/students/"
		],
		preloads: [
			"/assets/route-DuxAOj_P.js",
			"/assets/users-BYk-LzMk.js",
			"/assets/x-B-sBa6MY.js",
			"/assets/dist-CDC_-6nH.js",
			"/assets/button-U8k001FT.js",
			"/assets/dist-CEQjN7G5.js"
		]
	},
	"/_app/results": {
		filePath: "/workspace/src/routes/_app/results.tsx",
		children: void 0,
		preloads: [
			"/assets/results-yUj54URk.js",
			"/assets/server-BayxF2lD.js",
			"/assets/useNavigate-CKUq1g8p.js",
			"/assets/table-CYcd-DRL.js",
			"/assets/search-DMFIIHdM.js",
			"/assets/card-CzzjXXNZ.js",
			"/assets/mention-badge-LbqiWWfZ.js",
			"/assets/calc-CeVy41EL.js"
		]
	},
	"/_app/schools": {
		filePath: "/workspace/src/routes/_app/schools.tsx",
		children: void 0,
		preloads: [
			"/assets/schools-BWDbBpSQ.js",
			"/assets/server-BayxF2lD.js",
			"/assets/table-CYcd-DRL.js",
			"/assets/label-JzeWIZRg.js",
			"/assets/card-CzzjXXNZ.js"
		]
	},
	"/certificates/$id": {
		filePath: "/workspace/src/routes/certificates/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-BTHre1cS.js",
			"/assets/server-BayxF2lD.js",
			"/assets/certificate-doc-BaTTvyj7.js",
			"/assets/button-U8k001FT.js"
		]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_app-BLBUcry8.js",
			"/assets/server-BayxF2lD.js",
			"/assets/card-CzzjXXNZ.js",
			"/assets/mention-badge-LbqiWWfZ.js",
			"/assets/calc-CeVy41EL.js"
		]
	},
	"/_app/students/$id": {
		filePath: "/workspace/src/routes/_app/students/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-BT2y4YCQ.js",
			"/assets/server-BayxF2lD.js",
			"/assets/useNavigate-CKUq1g8p.js",
			"/assets/certificate-doc-BaTTvyj7.js",
			"/assets/table-CYcd-DRL.js",
			"/assets/label-JzeWIZRg.js",
			"/assets/card-CzzjXXNZ.js",
			"/assets/mention-badge-LbqiWWfZ.js",
			"/assets/calc-CeVy41EL.js",
			"/assets/Combination-Do8nL79k.js",
			"/assets/dist-BTbX7k5X.js",
			"/assets/student-form-O4ZskyzR.js"
		]
	},
	"/_app/students/": {
		filePath: "/workspace/src/routes/_app/students/index.tsx",
		children: void 0,
		preloads: [
			"/assets/students-BOcNM8Ws.js",
			"/assets/server-BayxF2lD.js",
			"/assets/useNavigate-CKUq1g8p.js",
			"/assets/table-CYcd-DRL.js",
			"/assets/search-DMFIIHdM.js",
			"/assets/label-JzeWIZRg.js",
			"/assets/card-CzzjXXNZ.js",
			"/assets/mention-badge-LbqiWWfZ.js",
			"/assets/calc-CeVy41EL.js",
			"/assets/student-form-O4ZskyzR.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
