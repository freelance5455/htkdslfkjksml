//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BGU78At3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/goals",
			"/habits",
			"/month",
			"/notebook",
			"/notes",
			"/studio",
			"/tasks",
			"/vision",
			"/week",
			"/year"
		],
		preloads: ["/assets/index-CbCQwrc_.js", "/assets/store-CvbcpLzy.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CbCQwrc_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CgrBL84G.js",
			"/assets/chevron-right-D4CnO3mI.js",
			"/assets/sortable-Sd-jN-Fi.js",
			"/assets/check-list-BMAUsXLT.js",
			"/assets/primitives-CX7CpXgj.js",
			"/assets/id-DNK6nbJQ.js"
		]
	},
	"/goals": {
		filePath: "/workspace/src/routes/goals.tsx",
		children: void 0,
		preloads: [
			"/assets/goals-Zy61EWYQ.js",
			"/assets/sortable-Sd-jN-Fi.js",
			"/assets/check-list-BMAUsXLT.js",
			"/assets/primitives-CX7CpXgj.js",
			"/assets/id-DNK6nbJQ.js"
		]
	},
	"/habits": {
		filePath: "/workspace/src/routes/habits.tsx",
		children: void 0,
		preloads: [
			"/assets/habits-CGtiySFF.js",
			"/assets/chevron-right-D4CnO3mI.js",
			"/assets/sortable-Sd-jN-Fi.js",
			"/assets/primitives-CX7CpXgj.js",
			"/assets/id-DNK6nbJQ.js"
		]
	},
	"/month": {
		filePath: "/workspace/src/routes/month.tsx",
		children: void 0,
		preloads: [
			"/assets/month-DCxsLvwT.js",
			"/assets/chevron-right-D4CnO3mI.js",
			"/assets/primitives-CX7CpXgj.js",
			"/assets/id-DNK6nbJQ.js"
		]
	},
	"/notebook": {
		filePath: "/workspace/src/routes/notebook.tsx",
		children: void 0,
		preloads: [
			"/assets/notebook-wMnsKZXj.js",
			"/assets/sortable-Sd-jN-Fi.js",
			"/assets/primitives-CX7CpXgj.js",
			"/assets/id-DNK6nbJQ.js"
		]
	},
	"/notes": {
		filePath: "/workspace/src/routes/notes.tsx",
		children: void 0,
		preloads: [
			"/assets/notes-Cj9uAjZZ.js",
			"/assets/primitives-CX7CpXgj.js",
			"/assets/id-DNK6nbJQ.js"
		]
	},
	"/studio": {
		filePath: "/workspace/src/routes/studio.tsx",
		children: void 0,
		preloads: ["/assets/studio-CAHwmsYp.js", "/assets/primitives-CX7CpXgj.js"]
	},
	"/tasks": {
		filePath: "/workspace/src/routes/tasks.tsx",
		children: void 0,
		preloads: [
			"/assets/tasks-Didx9tZf.js",
			"/assets/sortable-Sd-jN-Fi.js",
			"/assets/primitives-CX7CpXgj.js",
			"/assets/id-DNK6nbJQ.js"
		]
	},
	"/vision": {
		filePath: "/workspace/src/routes/vision.tsx",
		children: void 0,
		preloads: [
			"/assets/vision-Bth7QhBj.js",
			"/assets/sortable-Sd-jN-Fi.js",
			"/assets/primitives-CX7CpXgj.js",
			"/assets/id-DNK6nbJQ.js"
		]
	},
	"/week": {
		filePath: "/workspace/src/routes/week.tsx",
		children: void 0,
		preloads: [
			"/assets/week-DobKWmZp.js",
			"/assets/chevron-right-D4CnO3mI.js",
			"/assets/check-list-BMAUsXLT.js",
			"/assets/primitives-CX7CpXgj.js"
		]
	},
	"/year": {
		filePath: "/workspace/src/routes/year.tsx",
		children: void 0,
		preloads: [
			"/assets/year-5hFkfTtp.js",
			"/assets/chevron-right-D4CnO3mI.js",
			"/assets/primitives-CX7CpXgj.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
