//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-gmCf7-71.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DF2zAJOc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DF2zAJOc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/routes-hG2-v7mV.css"],
		preloads: ["/assets/routes-CtSSCuHF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
