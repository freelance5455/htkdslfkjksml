//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CocMhrb0.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/beolvasas",
			"/celok",
			"/dijak",
			"/eszkozok",
			"/meg",
			"/mozgasok"
		],
		preloads: ["/assets/index-DMv5pp27.js", "/assets/catalog-CyBYr64M.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DMv5pp27.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DdxkxOWW.js",
			"/assets/shell-DnboCtAR.js",
			"/assets/format-Dt2Ge92Y.js"
		]
	},
	"/beolvasas": {
		filePath: "/workspace/src/routes/beolvasas.tsx",
		children: void 0,
		preloads: [
			"/assets/beolvasas-qihZxV3f.js",
			"/assets/shell-DnboCtAR.js",
			"/assets/format-Dt2Ge92Y.js"
		]
	},
	"/celok": {
		filePath: "/workspace/src/routes/celok.tsx",
		children: void 0,
		preloads: [
			"/assets/celok-BzYFn2Tk.js",
			"/assets/shell-DnboCtAR.js",
			"/assets/format-Dt2Ge92Y.js"
		]
	},
	"/dijak": {
		filePath: "/workspace/src/routes/dijak.tsx",
		children: void 0,
		preloads: [
			"/assets/dijak-BLEP8Bth.js",
			"/assets/shell-DnboCtAR.js",
			"/assets/format-Dt2Ge92Y.js"
		]
	},
	"/eszkozok": {
		filePath: "/workspace/src/routes/eszkozok.tsx",
		children: void 0,
		preloads: [
			"/assets/eszkozok-Cn9Hy2B9.js",
			"/assets/shell-DnboCtAR.js",
			"/assets/format-Dt2Ge92Y.js"
		]
	},
	"/meg": {
		filePath: "/workspace/src/routes/meg.tsx",
		children: void 0,
		preloads: ["/assets/meg-c0NszGm1.js", "/assets/shell-DnboCtAR.js"]
	},
	"/mozgasok": {
		filePath: "/workspace/src/routes/mozgasok.tsx",
		children: void 0,
		preloads: [
			"/assets/mozgasok-DK-o3Cxs.js",
			"/assets/shell-DnboCtAR.js",
			"/assets/format-Dt2Ge92Y.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
