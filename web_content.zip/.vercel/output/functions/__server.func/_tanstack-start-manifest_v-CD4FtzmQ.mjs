//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CD4FtzmQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-VERn5iJb.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-VERn5iJb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dn7eU1Ao.js"]
	}
} });
//#endregion
export { tsrStartManifest };
