//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-eVi6D8lZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-ByRagu6i.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ByRagu6i.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Kv-lIVfo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
