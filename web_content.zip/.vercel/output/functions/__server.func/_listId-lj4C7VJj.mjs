import { x as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { _ as Heart, l as RotateCcw, s as Share2, t as Volume2 } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { i as Route$8 } from "./_ssr/router-CYk49Uxf.mjs";
import { t as BackButton } from "./_ssr/back-button-DImimZOp.mjs";
import { a as cn, i as audioEngine, l as toArabicDigits, r as TopBar, t as AppShell, u as useAppStore } from "./_ssr/app-shell-C4IrQdCN.mjs";
import { a as getList } from "./_ssr/catalog-CjAfWU9w.mjs";
import { t as shareText } from "./_ssr/share-B1roieal.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_listId-lj4C7VJj.js
var import_jsx_runtime = require_jsx_runtime();
function DhikrListPage() {
	const { listId } = Route$8.useParams();
	const list = getList(listId);
	const progress = useAppStore((s) => s.dhikrProgress);
	const bump = useAppStore((s) => s.bumpDhikr);
	const resetList = useAppStore((s) => s.resetListDhikr);
	const toggleFavorite = useAppStore((s) => s.toggleFavorite);
	const favorites = useAppStore((s) => s.favorites);
	const scale = useAppStore((s) => s.settings.fontScale);
	if (!list) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "غير موجود",
		back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/adhkar" })
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: list.title,
			back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/adhkar" }),
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "tap-lg text-muted-foreground",
				"aria-label": "إعادة العداد",
				onClick: () => resetList(list.items.map((i) => i.id)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-5 pt-3 text-xs leading-5 text-muted-foreground",
			children: list.blurb
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3 px-4 py-4",
			children: list.items.map((item) => {
				const current = progress[item.id] ?? 0;
				const done = current >= item.count && item.count > 0;
				const fav = favorites.some((f) => f.id === item.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					id: item.id,
					className: "rounded-[22px] bg-card p-4 shadow-[var(--shadow-border)]",
					children: [
						item.title && item.title !== list.title && item.book === "القرآن الكريم" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs text-sage",
							children: item.title
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "quran-text leading-loose text-ink",
							style: { fontSize: `${.95 * scale + .7}rem` },
							children: item.text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[11px] leading-5 text-muted-foreground",
							children: item.source
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => bump(item.id, item.count),
									className: cn("flex h-12 flex-1 items-center justify-center rounded-2xl text-sm font-medium", done ? "bg-sage text-accent-foreground" : "bg-accent text-accent-foreground"),
									children: done ? "تم" : `${toArabicDigits(current)} / ${toArabicDigits(item.count)}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: "استماع",
									onClick: () => {
										if (!audioEngine.speak(item.text, list.title)) toast("قراءة الجهاز غير متاحة على هذا المتصفح");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: "مفضلة",
									onClick: () => toggleFavorite({
										id: item.id,
										kind: list.kind === "dua" ? "dua" : "dhikr",
										title: list.title,
										text: item.text,
										href: `/adhkar/${list.id}#${item.id}`,
										meta: item.source
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-4", fav && "fill-current") })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: "مشاركة",
									onClick: () => void shareText(list.title, item.text),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" })
								})
							]
						})
					]
				}, item.id);
			})
		})
	] });
}
function IconBtn({ children, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "tap-lg flex size-12 items-center justify-center rounded-2xl bg-surface text-foreground",
		children
	});
}
//#endregion
export { DhikrListPage as component };
