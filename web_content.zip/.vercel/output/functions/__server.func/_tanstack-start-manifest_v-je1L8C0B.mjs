//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-je1L8C0B.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CKj0j44D.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CKj0j44D.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CBkOYpuI.js"]
	}
} });
//#endregion
export { tsrStartManifest };
