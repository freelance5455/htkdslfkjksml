//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CScb9TMl.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DPzpz-EG.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DPzpz-EG.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CXyxEfik.js"]
	}
} });
//#endregion
export { tsrStartManifest };
