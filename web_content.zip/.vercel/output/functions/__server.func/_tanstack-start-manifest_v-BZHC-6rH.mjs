//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BZHC-6rH.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-siXg-ATw.js", "/assets/dist-DhB7tkh3.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-siXg-ATw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D2NSfY9q.js"]
	}
} });
//#endregion
export { tsrStartManifest };
