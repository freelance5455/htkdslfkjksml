//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-0V12GiHV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/rtc",
			"/s/$roomId",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-BC5P-kna.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-CDkc3fXQ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BC5P-kna.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dkhslt7S.js", "/assets/nyala-gate-Dpag6g4j.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-QVfufbjU.js", "/assets/nyala-gate-Dpag6g4j.js"]
	},
	"/s/$roomId": {
		filePath: "/workspace/src/routes/s/$roomId.tsx",
		children: void 0,
		preloads: ["/assets/_roomId-KTMBwHF6.js", "/assets/nyala-gate-Dpag6g4j.js"]
	}
} });
//#endregion
export { tsrStartManifest };
