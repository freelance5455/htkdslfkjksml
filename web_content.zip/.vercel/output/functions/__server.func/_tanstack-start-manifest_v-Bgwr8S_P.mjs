//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bgwr8S_P.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CDm6-3_i.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CDm6-3_i.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CKriKWSZ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
