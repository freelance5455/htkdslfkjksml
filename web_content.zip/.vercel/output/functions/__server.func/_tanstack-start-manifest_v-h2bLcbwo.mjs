//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-h2bLcbwo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-oTISEa37.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-oTISEa37.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-GJgw6aGF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
