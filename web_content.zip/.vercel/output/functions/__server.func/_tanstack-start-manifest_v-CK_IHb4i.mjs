//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CK_IHb4i.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-XCF6cG6x.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-XCF6cG6x.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DVLILQy_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
