//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dm-8jVKc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/browser",
			"/downloads",
			"/library",
			"/settings",
			"/player/$id"
		],
		preloads: [
			"/assets/index-Bk6RHfNf.js",
			"/assets/idb-D-tWmGy_.js",
			"/assets/dropdown-menu-kZ15wwdb.js",
			"/assets/preload-helper-Bmmb4hna.js",
			"/assets/player-store-DC-rDRmy.js",
			"/assets/x-CCMdGSkl.js",
			"/assets/library-store-DQ0kslKC.js",
			"/assets/dist-BEjgqdp7.js",
			"/assets/dist-DeUuJ1x1.js",
			"/assets/settings-store-2j8_3gkx.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bk6RHfNf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B1SaSG0F.js", "/assets/media-card-UJadDJLn.js"]
	},
	"/browser": {
		filePath: "/workspace/src/routes/browser.tsx",
		children: void 0,
		preloads: ["/assets/browser-f14KH_8Q.js"]
	},
	"/downloads": {
		filePath: "/workspace/src/routes/downloads.tsx",
		children: void 0,
		preloads: ["/assets/downloads-CLgg0vkP.js"]
	},
	"/library": {
		filePath: "/workspace/src/routes/library.tsx",
		children: void 0,
		preloads: ["/assets/library-EHreCjOG.js", "/assets/media-card-UJadDJLn.js"]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-J_WbamOb.js", "/assets/slider-DR-_jbxM.js"]
	},
	"/player/$id": {
		filePath: "/workspace/src/routes/player.$id.tsx",
		children: void 0,
		preloads: ["/assets/player._id-CMAZfovO.js", "/assets/slider-DR-_jbxM.js"]
	}
} });
//#endregion
export { tsrStartManifest };
