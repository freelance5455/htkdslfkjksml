//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CacpRcHa.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/battery",
			"/calculator",
			"/device",
			"/flashlight",
			"/network",
			"/storage",
			"/studio"
		],
		preloads: ["/assets/index-BIKd0v6M.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BIKd0v6M.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BF0RPQHg.js",
			"/assets/battery-charging-pLESLaoR.js",
			"/assets/app-shell-CWzDSOTX.js",
			"/assets/flashlight-CWjkCtLj.js",
			"/assets/hard-drive-DNfDPnp2.js",
			"/assets/smartphone-CvTM5n76.js",
			"/assets/wifi-DAM5Tepp.js"
		]
	},
	"/battery": {
		filePath: "/workspace/src/routes/battery.tsx",
		children: void 0,
		preloads: [
			"/assets/battery-CvaRqtJZ.js",
			"/assets/screen-header-DbfBi6Eb.js",
			"/assets/battery-charging-pLESLaoR.js",
			"/assets/app-shell-CWzDSOTX.js",
			"/assets/web-device-DIfOcCE5.js"
		]
	},
	"/calculator": {
		filePath: "/workspace/src/routes/calculator.tsx",
		children: void 0,
		preloads: [
			"/assets/calculator-DoY1kpX0.js",
			"/assets/screen-header-DbfBi6Eb.js",
			"/assets/app-shell-CWzDSOTX.js",
			"/assets/utils-GX8uj5jH.js"
		]
	},
	"/device": {
		filePath: "/workspace/src/routes/device.tsx",
		children: void 0,
		preloads: [
			"/assets/device-DZZkyhM6.js",
			"/assets/screen-header-DbfBi6Eb.js",
			"/assets/app-shell-CWzDSOTX.js",
			"/assets/smartphone-CvTM5n76.js",
			"/assets/web-device-DIfOcCE5.js"
		]
	},
	"/flashlight": {
		filePath: "/workspace/src/routes/flashlight.tsx",
		children: void 0,
		preloads: [
			"/assets/flashlight-kDacM59p.js",
			"/assets/screen-header-DbfBi6Eb.js",
			"/assets/app-shell-CWzDSOTX.js",
			"/assets/flashlight-CWjkCtLj.js"
		]
	},
	"/network": {
		filePath: "/workspace/src/routes/network.tsx",
		children: void 0,
		preloads: [
			"/assets/network-DUYo4LH-.js",
			"/assets/screen-header-DbfBi6Eb.js",
			"/assets/app-shell-CWzDSOTX.js",
			"/assets/wifi-DAM5Tepp.js",
			"/assets/web-device-DIfOcCE5.js"
		]
	},
	"/storage": {
		filePath: "/workspace/src/routes/storage.tsx",
		children: void 0,
		preloads: [
			"/assets/storage-B5Dp2SGn.js",
			"/assets/screen-header-DbfBi6Eb.js",
			"/assets/app-shell-CWzDSOTX.js",
			"/assets/hard-drive-DNfDPnp2.js",
			"/assets/web-device-DIfOcCE5.js",
			"/assets/utils-GX8uj5jH.js"
		]
	},
	"/studio": {
		filePath: "/workspace/src/routes/studio.tsx",
		children: void 0,
		preloads: [
			"/assets/studio-Cbl68cj3.js",
			"/assets/screen-header-DbfBi6Eb.js",
			"/assets/app-shell-CWzDSOTX.js",
			"/assets/smartphone-CvTM5n76.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
