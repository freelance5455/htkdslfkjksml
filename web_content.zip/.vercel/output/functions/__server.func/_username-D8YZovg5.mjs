import { o as __toESM } from "./_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Youtube } from "./_libs/lucide-react.mjs";
import { n as Route$1 } from "./_ssr/router-B6lWlm2d.mjs";
import { i as ROLES } from "./_ssr/model-Ck66RVeO.mjs";
import { C as primaryBtn, E as setFollow, O as updateProfile, b as listConnections, g as getProfile, m as fieldClass, s as RolePill, t as Avatar, w as quietBtn } from "./_ssr/auth-screens-DZe0plYT.mjs";
import { i as useSalon, n as UserButton, r as compressImage, t as Shell$1 } from "./_ssr/shell-DSe4icyb.mjs";
import { n as useMeId, t as FeedView } from "./_ssr/use-me-id-BM_D2CRi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_username-D8YZovg5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const { username } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileView, { username }) });
}
function ProfileView({ username }) {
	const meId = useMeId();
	const tick = useSalon((s) => s.tick);
	const bump = useSalon((s) => s.bump);
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [dir, setDir] = (0, import_react.useState)(null);
	const [people, setPeople] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		let live = true;
		setDir(null);
		getProfile({ data: { username } }).then((result) => {
			if (!live) return;
			if (!result.ok) {
				setProfile(null);
				setError(result.error);
			} else {
				setError(null);
				setProfile(result.profile);
			}
		}).catch((err) => {
			if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
		});
		return () => {
			live = false;
		};
	}, [username, tick]);
	async function toggleFollow() {
		if (!profile) return;
		const result = await setFollow({ data: {
			username: profile.username,
			follow: !profile.isFollowing
		} });
		if (!result.ok) {
			setError(result.error);
			return;
		}
		setProfile({
			...profile,
			isFollowing: result.following,
			followers: result.followers
		});
	}
	async function openList(next) {
		if (!profile) return;
		if (dir === next) {
			setDir(null);
			return;
		}
		const result = await listConnections({ data: {
			username: profile.username,
			dir: next
		} });
		if (!result.ok) {
			setError(result.error);
			return;
		}
		setPeople(result.people);
		setDir(next);
	}
	if (!meId) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl",
		children: [error && !profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-rose",
			children: error
		}) : null, profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-3xl bg-paper shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative h-40 bg-rose/20 sm:h-48",
					children: profile.banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: profile.banner,
						alt: "",
						className: "h-full w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 end-0 w-1/2 bg-ink/15" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 pb-5 sm:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "-mt-10 flex items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								src: profile.avatar,
								name: profile.username,
								className: "size-20 border-4 border-paper text-2xl"
							}), profile.isSelf ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: quietBtn,
								onClick: () => setEditing((v) => !v),
								children: editing ? "إغلاق" : "تعديل"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: profile.isFollowing ? quietBtn : primaryBtn,
								onClick: () => void toggleFollow(),
								children: profile.isFollowing ? "إلغاء المتابعة" : "متابعة"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-4xl leading-none",
								children: profile.username
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolePill, { role: profile.role })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: profile.youtubeUrl,
							target: "_blank",
							rel: "noreferrer",
							className: "mt-3 inline-flex min-h-11 max-w-full items-center gap-2 rounded-full bg-ivory px-4 text-sm text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Youtube, { className: "size-4 shrink-0 text-rose" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								dir: "ltr",
								children: profile.youtubeUrl.replace("https://www.", "")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 whitespace-pre-wrap text-sm leading-7",
							children: profile.bio || "لا نبذة بعد."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "min-h-11 rounded-2xl px-3 text-sm",
								onClick: () => void openList("followers"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums font-medium",
										children: profile.followers
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mute",
										children: "متابعون"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "min-h-11 rounded-2xl px-3 text-sm",
								onClick: () => void openList("following"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums font-medium",
										children: profile.following
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mute",
										children: "يتابع"
									})
								]
							})]
						}),
						profile.isSelf ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
						}) : null
					]
				})]
			}),
			editing && profile.isSelf ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
				profile,
				onSaved: () => {
					setEditing(false);
					bump();
				}
			}) : null,
			dir ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2",
				children: [people.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/u/$username",
					params: { username: person.username },
					className: "flex min-h-14 items-center gap-3 rounded-2xl bg-paper px-3 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							src: person.avatar,
							name: person.username,
							className: "size-9 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: person.username
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolePill, { role: person.role })
					]
				}) }, person.username)), !people.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-mute",
					children: "لا أحد هنا بعد."
				}) : null]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedView, {
					meId,
					query: {
						surface: "user",
						username: profile.username
					},
					variant: "feed",
					emptyTitle: "لا منشورات",
					emptyBody: "حين يُنشر شيء، يظهر هنا وللجميع."
				})
			})
		] }) : null]
	});
}
function Editor({ profile, onSaved }) {
	const [bio, setBio] = (0, import_react.useState)(profile.bio);
	const [role, setRole] = (0, import_react.useState)(profile.role);
	const [avatar, setAvatar] = (0, import_react.useState)(profile.avatar);
	const [banner, setBanner] = (0, import_react.useState)(profile.banner);
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	async function pick(file, which) {
		if (!file) return;
		try {
			const data = await compressImage(file, which === "avatar" ? 512 : 1400, which === "avatar" ? 2e5 : 4e5);
			if (which === "avatar") setAvatar(data);
			else setBanner(data);
		} catch (err) {
			setError(err instanceof Error ? err.message : "تعذر قراءة الصورة");
		}
	}
	async function save(event) {
		event.preventDefault();
		setPending(true);
		setError(null);
		try {
			const result = await updateProfile({ data: {
				bio,
				role,
				avatar,
				banner
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			onSaved();
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: save,
		className: "mt-3 space-y-3 rounded-3xl bg-paper p-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-mute",
					children: "النبذة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${fieldClass} min-h-24 py-3`,
					value: bio,
					maxLength: 280,
					onChange: (e) => setBio(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: ROLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setRole(item.id),
					className: `min-h-11 rounded-full text-sm ${role === item.id ? "bg-rose text-paper" : "bg-ivory"}`,
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm text-mute",
				children: ["الصورة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "image/*",
					className: "mt-1 block w-full text-ink",
					onChange: (e) => void pick(e.target.files?.[0], "avatar")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm text-mute",
				children: ["البانر", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "image/*",
					className: "mt-1 block w-full text-ink",
					onChange: (e) => void pick(e.target.files?.[0], "banner")
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-rose",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: primaryBtn,
				disabled: pending,
				type: "submit",
				children: pending ? "يُحفظ…" : "حفظ"
			})
		]
	});
}
//#endregion
export { ProfilePage as component };
