//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CEWJOEp8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		css: ["/assets/index-DpNpueA3.css"],
		preloads: ["/assets/index-D2jEwNgY.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D2jEwNgY.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C9EhZ9Dz.js"]
	}
} });
//#endregion
export { tsrStartManifest };
