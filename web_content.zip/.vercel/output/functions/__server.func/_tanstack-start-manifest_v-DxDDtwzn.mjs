//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DxDDtwzn.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CE_-YcTs.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CE_-YcTs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-gO6LyLTO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
