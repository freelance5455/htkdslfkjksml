//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B5cazyrk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DihmPJ8c.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DihmPJ8c.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CzN140nU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
