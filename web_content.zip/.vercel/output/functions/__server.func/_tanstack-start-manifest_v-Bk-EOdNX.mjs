//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bk-EOdNX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/flock",
			"/log",
			"/more",
			"/sheep/$id",
			"/sheep/new"
		],
		preloads: [
			"/assets/index-6oU0yS-0.js",
			"/assets/createLucideIcon-DGh7nqS1.js",
			"/assets/preload-helper-D83gMg9A.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-6oU0yS-0.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-2VooHuN9.js",
			"/assets/store-DJtNwu4D.js",
			"/assets/card-BStgqdoP.js",
			"/assets/button-pBsU0skK.js"
		]
	},
	"/flock": {
		filePath: "/workspace/src/routes/flock.tsx",
		children: void 0,
		preloads: [
			"/assets/flock-CLI3r1eM.js",
			"/assets/store-DJtNwu4D.js",
			"/assets/sheep-bits-DANhTrA_.js",
			"/assets/input-DTa9yNZY.js"
		]
	},
	"/log": {
		filePath: "/workspace/src/routes/log.tsx",
		children: void 0,
		preloads: [
			"/assets/log-CMq1qwRO.js",
			"/assets/store-DJtNwu4D.js",
			"/assets/card-BStgqdoP.js",
			"/assets/button-pBsU0skK.js",
			"/assets/forms-CJgG7tVP.js",
			"/assets/field-DiTWVzva.js",
			"/assets/dist-CPm4r_D0.js"
		]
	},
	"/more": {
		filePath: "/workspace/src/routes/more.tsx",
		children: void 0,
		preloads: [
			"/assets/more-BCn25QGR.js",
			"/assets/store-DJtNwu4D.js",
			"/assets/input-DTa9yNZY.js",
			"/assets/card-BStgqdoP.js",
			"/assets/button-pBsU0skK.js",
			"/assets/field-DiTWVzva.js",
			"/assets/confirm-vi9lfC1x.js"
		]
	},
	"/sheep/$id": {
		filePath: "/workspace/src/routes/sheep/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-GkxzNkOt.js",
			"/assets/store-DJtNwu4D.js",
			"/assets/sheep-bits-DANhTrA_.js",
			"/assets/input-DTa9yNZY.js",
			"/assets/card-BStgqdoP.js",
			"/assets/button-pBsU0skK.js",
			"/assets/forms-CJgG7tVP.js",
			"/assets/field-DiTWVzva.js",
			"/assets/confirm-vi9lfC1x.js"
		]
	},
	"/sheep/new": {
		filePath: "/workspace/src/routes/sheep/new.tsx",
		children: void 0,
		preloads: [
			"/assets/new-D4PMACLe.js",
			"/assets/useNavigate-RmSYguL5.js",
			"/assets/store-DJtNwu4D.js",
			"/assets/forms-CJgG7tVP.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
