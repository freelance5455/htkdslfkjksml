import { i as __toESM } from "./_runtime.mjs";
import { B as require_react, x as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { _ as Heart, d as Plus, h as Minus, s as Share2, t as Volume2 } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as Route$5 } from "./_ssr/router-CYk49Uxf.mjs";
import { t as BackButton } from "./_ssr/back-button-DImimZOp.mjs";
import { a as cn, i as audioEngine, t as AppShell, u as useAppStore } from "./_ssr/app-shell-C4IrQdCN.mjs";
import { i as getBook } from "./_ssr/catalog-CjAfWU9w.mjs";
import { t as shareText } from "./_ssr/share-B1roieal.mjs";
import { t as TextLink } from "./_ssr/text-link-CJNQ8wl3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_bookId-Sqej3BtO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookReader() {
	const { bookId } = Route$5.useParams();
	const { section } = Route$5.useSearch();
	const book = getBook(bookId);
	const scale = useAppStore((s) => s.settings.fontScale);
	const setScale = useAppStore((s) => s.setFontScale);
	const setLastBook = useAppStore((s) => s.setLastBook);
	const toggleFavorite = useAppStore((s) => s.toggleFavorite);
	const favorites = useAppStore((s) => s.favorites);
	const addBookmark = useAppStore((s) => s.addBookmark);
	const sections = book?.sections ?? [];
	const current = (0, import_react.useMemo)(() => {
		if (!sections.length) return null;
		return sections.find((s) => s.id === section) ?? sections[0];
	}, [sections, section]);
	(0, import_react.useEffect)(() => {
		if (book && current && !book.comingSoon) setLastBook({
			bookId: book.id,
			sectionId: current.id,
			updatedAt: Date.now()
		});
	}, [
		book,
		current,
		setLastBook
	]);
	if (!book) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-8",
		children: "الكتاب غير موجود"
	}) });
	if (book.comingSoon || !current) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center gap-2 px-2 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/library" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "flex-1 text-center font-semibold",
				children: book.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-11" })
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-5 pt-6 text-sm leading-7 text-muted-foreground",
		children: book.source
	})] });
	const idx = sections.findIndex((s) => s.id === current.id);
	const favId = `${book.id}:${current.id}`;
	const isFav = favorites.some((f) => f.id === favId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-border bg-background/90 backdrop-blur-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1 px-1 py-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/library" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-sm font-semibold",
							children: book.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-[11px] text-muted-foreground",
							children: current.title
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tap-lg size-10",
						onClick: () => setScale(Math.max(.85, scale - .1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "mx-auto size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tap-lg size-10",
						onClick: () => setScale(Math.min(1.6, scale + .1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mx-auto size-4" })
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "bg-paper px-5 py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-lg font-semibold text-accent",
					children: current.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "whitespace-pre-wrap leading-8 text-ink",
					style: { fontSize: `${.7 + scale * .55}rem` },
					children: current.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 border-t border-border pt-4 text-[11px] leading-5 text-muted-foreground",
					children: book.source
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sticky bottom-[calc(5.25rem+env(safe-area-inset-bottom))] z-20 mx-3 mb-2 flex gap-2 rounded-2xl border border-border bg-card p-2 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex h-11 flex-1 items-center justify-center gap-1 rounded-xl bg-surface text-xs",
					onClick: () => {
						if (!audioEngine.speak(current.body.slice(0, 4e3), current.title)) toast("قراءة الجهاز غير متاحة");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }), " استماع"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("flex size-11 items-center justify-center rounded-xl bg-surface", isFav && "text-accent"),
					onClick: () => toggleFavorite({
						id: favId,
						kind: book.category === "hadith" ? "hadith" : "mutn",
						title: `${book.title} — ${current.title}`,
						text: current.body.slice(0, 280),
						href: `/library/${book.id}?section=${current.id}`,
						meta: book.author
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-4", isFav && "fill-current") })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-xl bg-surface",
					onClick: () => void shareText(current.title, current.body.slice(0, 800)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex h-11 flex-1 items-center justify-center rounded-xl bg-accent text-xs text-accent-foreground",
					onClick: () => addBookmark({
						id: favId,
						label: `${book.title} — ${current.title}`,
						href: `/library/${book.id}?section=${current.id}`
					}),
					children: "علامة"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "flex justify-between px-4 pb-4 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				disabled: idx <= 0,
				href: idx > 0 ? `/library/${book.id}?section=${sections[idx - 1].id}` : void 0,
				label: "السابق"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				disabled: idx >= sections.length - 1,
				href: idx < sections.length - 1 ? `/library/${book.id}?section=${sections[idx + 1].id}` : void 0,
				label: "التالي"
			})]
		})
	] });
}
function Pager({ href, label, disabled }) {
	if (disabled || !href) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "opacity-30",
		children: label
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextLink, {
		href,
		className: "text-accent",
		children: label
	});
}
//#endregion
export { BookReader as component };
