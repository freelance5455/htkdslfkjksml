//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B8hjGPmT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CeP6JjFS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CeP6JjFS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-0fElp72P.js"]
	}
} });
//#endregion
export { tsrStartManifest };
