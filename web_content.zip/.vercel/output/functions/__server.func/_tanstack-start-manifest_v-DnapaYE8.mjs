//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DnapaYE8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-C09JQVB0.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C09JQVB0.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-6wLbC1fd.js"]
	}
} });
//#endregion
export { tsrStartManifest };
