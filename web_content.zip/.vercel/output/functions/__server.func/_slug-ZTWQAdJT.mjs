import { J as notFound, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { a as useStudy, n as Route } from "./_ssr/router-C-xQh0iG.mjs";
import { n as RoadSign, t as ItText } from "./_ssr/road-sign-_-tGVxDe.mjs";
import { n as chapterBySlug, t as CHAPTERS } from "./_ssr/curriculum-BHBVcVfN.mjs";
import { n as questionsByChapter } from "./_ssr/quiz-C2Kzqaia.mjs";
import { r as signById } from "./_ssr/signs-CNNmKTo_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-ZTWQAdJT.js
var import_jsx_runtime = require_jsx_runtime();
function Pair({ it, ar }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItText, { text: it }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl bg-soft px-3 py-3 text-base leading-relaxed",
			children: ar
		})]
	});
}
function SignRow({ ids }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
		children: ids.map((id) => {
			const info = signById(id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl border border-line bg-surface p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoadSign, {
						id,
						className: "mx-auto h-24 w-24"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						dir: "ltr",
						lang: "it",
						className: "mt-2 text-left text-sm font-semibold",
						children: info?.nameIt ?? id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: info?.nameAr
					})
				]
			}, id);
		})
	});
}
function ChapterPage() {
	const { slug } = Route.useParams();
	const chapter = chapterBySlug(slug);
	const markRead = useStudy((s) => s.markRead);
	const read = useStudy((s) => s.read.includes(slug));
	if (!chapter) throw notFound();
	const index = CHAPTERS.findIndex((c) => c.slug === slug);
	const prev = CHAPTERS[index - 1];
	const next = CHAPTERS[index + 1];
	const quizCount = questionsByChapter(chapter.n).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/manuale",
					className: "text-sm text-primary",
					children: "كل الفصول"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"فصل ",
						chapter.n,
						" من ",
						CHAPTERS.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold leading-tight",
					children: chapter.titleAr
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					dir: "ltr",
					lang: "it",
					className: "text-left text-lg text-muted",
					children: chapter.titleIt
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6",
				children: chapter.blocks.map((block, i) => {
					if (block.k === "signs") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignRow, { ids: block.ids }, i);
					if (block.k === "h") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "border-t border-line pt-4 text-2xl font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							dir: "ltr",
							lang: "it",
							className: "mb-1 block text-left text-base font-medium text-muted",
							children: block.it
						}), block.ar]
					}, i);
					if (block.k === "note") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "space-y-2 rounded-2xl bg-warn px-3 py-3 text-warn-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pair, {
							it: block.it,
							ar: block.ar
						})
					}, i);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pair, {
						it: block.it,
						ar: block.ar
					}, i);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => markRead(chapter.slug),
					className: "min-h-11 rounded-full bg-primary px-4 text-primary-fg",
					children: read ? "معلَّم كمقروء" : "علّم الفصل كمقروء"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/esame",
					search: { ch: chapter.n },
					className: "inline-flex min-h-11 items-center rounded-full border border-line px-4",
					children: [
						"تدرب على ",
						quizCount,
						" سؤالًا"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex justify-between gap-3 border-t border-line pt-4 text-sm",
				children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/manuale/$slug",
					params: { slug: prev.slug },
					className: "text-primary",
					children: ["السابق: ", prev.titleAr]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/manuale/$slug",
					params: { slug: next.slug },
					className: "text-primary",
					children: ["التالي: ", next.titleAr]
				}) : null]
			})
		]
	});
}
//#endregion
export { ChapterPage as component };
