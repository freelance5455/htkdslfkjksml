import { d as selectTotals, o as formatAud, p as useVault } from "./_ssr/vault-store-CwqfT6q8.mjs";
import { b as Link, g as Outlet, p as useRouterState } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { l as LayoutDashboard, n as Wallet, u as House } from "./_libs/lucide-react.mjs";
import { n as useVaultReady } from "./_ssr/router-vYZiRy86.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-6smCUbpS.js
var import_jsx_runtime = require_jsx_runtime();
function VaultMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8 text-foreground", className),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "9",
			fill: "currentColor"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 21.5V11M11.5 15.25 16 10.75l4.5 4.5",
			fill: "none",
			className: "stroke-background",
			strokeWidth: "2.1",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
function Wordmark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("font-display text-2xl leading-none tracking-tight", className),
		children: "Vault"
	});
}
var NAV = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/dashboard",
		label: "Vault",
		icon: LayoutDashboard
	},
	{
		to: "/wallet",
		label: "Wallet",
		icon: Wallet
	}
];
function AppShell({ children }) {
	const ready = useVaultReady();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const totals = useVault(selectTotals);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 pt-safe",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultMark, { className: "size-9" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-full bg-card px-3 py-1.5 shadow-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Available"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium tabular-nums text-success leading-tight",
						children: ready ? formatAud(totals.available) : "—"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 pb-nav",
				children: ready ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 pt-2",
					"aria-busy": "true",
					"aria-label": "Loading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 rounded-3xl bg-card shadow-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52 rounded-3xl bg-card shadow-border" })]
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-lg px-4 pb-nav-float",
			"aria-label": "Primary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 rounded-full bg-card p-1.5 shadow-border",
				children: NAV.map((item) => {
					const active = pathname === item.to;
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: cn("flex h-12 items-center justify-center gap-2 rounded-full text-sm font-medium transition-colors duration-150", active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
						"aria-current": active ? "page" : void 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-4",
							strokeWidth: 1.8
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
					}, item.to);
				})
			})
		})]
	});
}
function AppLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { AppLayout as component };
