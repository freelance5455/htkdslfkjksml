//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CnuNTblo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/file"],
		preloads: ["/assets/index-BLLhJ_qE.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BLLhJ_qE.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-FDK02z9_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
