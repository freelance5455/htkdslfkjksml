//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BytOwMpr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DgSq-nRQ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DgSq-nRQ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Ddh1vMPO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
