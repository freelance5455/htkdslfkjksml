import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as formatWhen, d as selectTotals, f as shortenAddress, i as audToToken, n as NETWORK_BY_ID, o as formatAud, p as useVault, r as TOKENS, s as formatToken, u as parseAud } from "./_ssr/vault-store-CwqfT6q8.mjs";
import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { a as Send, c as LoaderCircle, d as Copy, f as Check, n as Wallet, t as X } from "./_libs/lucide-react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "./_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { a as Input, i as CardTitle, n as Card, o as Label, r as CardHint, t as Button } from "./_ssr/label-DOshPwvi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.dashboard-BnL2JCJC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-overlay data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, showClose = true, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(100%-2rem,28rem)] -translate-x-1/2 -translate-y-1/2 rounded-3xl bg-card p-5 text-card-foreground shadow-sheet outline-none", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props,
		children: [children, showClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-4 right-4 rounded-full p-2 text-muted-foreground transition-colors duration-150 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		}) : null]
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("pr-8 text-lg font-semibold tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-1 text-sm text-muted-foreground", className),
		...props
	});
}
/** Fallback AUD per 1 unit of token — used when the live quote is unreachable. */
var FALLBACK_AUD_PER_TOKEN = {
	USDC: 1.52,
	USDT: 1.52,
	ETH: 6200,
	SOL: 280,
	BTC: 145e3
};
var GECKO_URL = "https://api.coingecko.com/api/v3/simple/price?ids=usd-coin,tether,ethereum,solana,bitcoin&vs_currencies=aud";
async function fetchAudRates() {
	const response = await fetch(GECKO_URL, { headers: { accept: "application/json" } });
	if (!response.ok) throw new Error("Quote unavailable");
	const data = await response.json();
	const next = { ...FALLBACK_AUD_PER_TOKEN };
	Object.keys(TOKENS).forEach((id) => {
		const aud = data[TOKENS[id].geckoId]?.aud;
		if (typeof aud === "number" && aud > 0) next[id] = aud;
	});
	return next;
}
function useAudRates() {
	const [rates, setRates] = (0, import_react.useState)(FALLBACK_AUD_PER_TOKEN);
	const [live, setLive] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		fetchAudRates().then((next) => {
			if (cancelled) return;
			setRates(next);
			setLive(true);
		}).catch(() => {
			if (!cancelled) setLive(false);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	return {
		rates,
		live
	};
}
var STEPS = [
	"Quote locked",
	"Routing payout",
	"Broadcasting",
	"Confirmed"
];
function DashboardPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise-in space-y-1 px-1 pt-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Earnings Dashboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Track your real income and cash out to your crypto wallet."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BalanceCards, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CashOutCard, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayoutHistory, {})
		]
	});
}
function BalanceCards() {
	const { available, earned, cashed } = useVault(selectTotals);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rise-in rise-in-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Available balance"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-display text-4xl leading-none tracking-tight text-success tabular-nums",
					children: formatAud(available)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rise-in rise-in-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Total earned"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-display text-4xl leading-none tracking-tight tabular-nums",
					children: formatAud(earned)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rise-in rise-in-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Cash-outs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-display text-4xl leading-none tracking-tight tabular-nums",
					children: formatAud(cashed)
				})]
			})
		]
	});
}
function CashOutCard() {
	const wallet = useVault((s) => s.wallet);
	const { available } = useVault(selectTotals);
	const cashOut = useVault((s) => s.cashOut);
	const confirmPayout = useVault((s) => s.confirmPayout);
	const { rates, live } = useAudRates();
	const [amount, setAmount] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)("review");
	const [step, setStep] = (0, import_react.useState)(0);
	const [active, setActive] = (0, import_react.useState)(null);
	const network = wallet ? NETWORK_BY_ID[wallet.network] : null;
	const parsed = parseAud(amount);
	const quote = (0, import_react.useMemo)(() => {
		if (!wallet || !network || parsed === null) return null;
		const rate = rates[wallet.token];
		const feeAud = network.feeAud;
		if (parsed <= feeAud) return { invalid: "Amount must cover the network fee." };
		const gross = audToToken(parsed, rate);
		const feeToken = audToToken(feeAud, rate);
		return {
			rate,
			feeAud,
			gross,
			feeToken,
			net: Math.max(0, gross - feeToken),
			invalid: null
		};
	}, [
		wallet,
		network,
		parsed,
		rates
	]);
	function resetDialog() {
		setPhase("review");
		setStep(0);
		setActive(null);
		setError(null);
	}
	function onOpenChange(next) {
		if (!next && phase === "sending") return;
		setOpen(next);
		if (!next) resetDialog();
	}
	function onSubmit(event) {
		event.preventDefault();
		if (!wallet || !network) return;
		if (parsed === null) {
			setError("Enter an amount greater than 0.");
			return;
		}
		if (parsed > available) {
			setError("That is more than your available balance.");
			return;
		}
		if (!quote || quote.invalid) {
			setError(quote?.invalid ?? "Could not price this payout.");
			return;
		}
		setError(null);
		setPhase("review");
		setOpen(true);
	}
	function fillMax() {
		if (available <= 0) return;
		setAmount(available.toFixed(2));
		setError(null);
	}
	async function confirmSend() {
		if (!wallet || !network || parsed === null || !quote || quote.invalid) return;
		try {
			const payout = cashOut({
				amountAud: parsed,
				tokenAmount: quote.net,
				feeAud: quote.feeAud
			});
			setActive(payout);
			setPhase("sending");
			for (let i = 0; i < STEPS.length; i += 1) {
				setStep(i);
				await wait(i === STEPS.length - 1 ? 520 : 420);
			}
			confirmPayout(payout.id);
			setPhase("done");
			setAmount("");
		} catch (err) {
			setPhase("review");
			setError(err instanceof Error ? err.message : "Could not send this payout.");
			setOpen(false);
		}
	}
	async function copyId(value) {
		try {
			await navigator.clipboard.writeText(value);
			toast.success("Copied");
		} catch {
			toast.error("Could not copy");
		}
	}
	if (!wallet || !network) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "rise-in rise-in-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
					className: "size-5",
					strokeWidth: 2
				}), "Cash out to your wallet"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
				className: "mt-2",
				children: "Add a destination wallet first. Payouts convert AUD to crypto and send to that address."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-5 h-12 w-full text-base",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/wallet",
					children: "Set up wallet"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "rise-in rise-in-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
					className: "size-5",
					strokeWidth: 2
				}), "Cash out to your wallet"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHint, {
				className: "mt-2",
				children: [
					"Available balance: ",
					formatAud(available),
					". Payouts go to",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-foreground",
						children: shortenAddress(wallet.address)
					}),
					" on",
					" ",
					network.name,
					" as ",
					wallet.token,
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-5 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "cashout-amount",
								children: "Amount (AUD)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: fillMax,
								className: "text-xs font-medium text-muted-foreground hover:text-foreground",
								children: "Max"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cashout-amount",
							inputMode: "decimal",
							placeholder: "0.00",
							value: amount,
							onChange: (e) => {
								setAmount(e.target.value);
								setError(null);
							}
						})]
					}),
					quote && !quote.invalid && parsed !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-secondary px-4 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "You receive"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium tabular-nums",
									children: formatToken(quote.net, wallet.token)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Network fee"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: formatAud(quote.feeAud)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-xs text-muted-foreground",
								children: [
									live ? "Live quote" : "Estimated quote",
									" · 1 ",
									wallet.token,
									" ≈ ",
									formatAud(quote.rate)
								]
							})
						]
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "h-12 w-full text-base",
						disabled: available <= 0,
						children: "Send to wallet"
					})
				]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			showClose: phase !== "sending",
			children: [
				phase === "review" && quote && !quote.invalid && parsed !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Confirm payout" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						"Convert ",
						formatAud(parsed),
						" and send ",
						wallet.token,
						" to your ",
						network.name,
						" wallet."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 space-y-2.5 rounded-2xl bg-secondary px-4 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "You send",
								value: formatAud(parsed)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "You receive",
								value: formatToken(quote.net, wallet.token)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Network",
								value: network.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Fee",
								value: formatAud(quote.feeAud)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "To",
								value: shortenAddress(wallet.address, 6),
								mono: true
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-5 h-12 w-full text-base",
						onClick: () => void confirmSend(),
						children: "Confirm send"
					})
				] }) : null,
				phase === "sending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Sending" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Keep this open while the payout is routed." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-5 space-y-3",
						children: STEPS.map((label, index) => {
							const done = index < step;
							const current = index === step;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("flex size-7 items-center justify-center rounded-full", done || current ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
									children: current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs",
										children: index + 1
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: current ? "font-medium" : "text-muted-foreground",
									children: label
								})]
							}, label);
						})
					})
				] }) : null,
				phase === "done" && active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Sent to your wallet" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						formatToken(active.tokenAmount, active.token),
						" is on the way to",
						" ",
						shortenAddress(active.walletAddress),
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-2 rounded-2xl bg-secondary px-4 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Amount",
								value: formatAud(active.amountAud)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Received",
								value: formatToken(active.tokenAmount, active.token)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Network",
								value: NETWORK_BY_ID[active.network].name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Transaction ID"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex max-w-48 items-center gap-1.5 text-right font-mono text-xs leading-snug break-all",
									onClick: () => void copyId(active.txId),
									children: [shortenAddress(active.txId, 8), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5 shrink-0" })]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-5 h-12 w-full text-base",
						onClick: () => onOpenChange(false),
						children: "Done"
					})
				] }) : null
			]
		})
	})] });
}
function Row({ label, value, mono }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: cn("font-medium tabular-nums", mono && "font-mono text-xs"),
			children: value
		})]
	});
}
function PayoutHistory() {
	const payouts = useVault((s) => s.payouts);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Payout history" }), payouts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
		className: "mt-2",
		children: "Cash-outs will appear here with a transaction ID."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-4 divide-y divide-border",
		children: payouts.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-start justify-between gap-4 py-3 first:pt-0 last:pb-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							formatToken(row.tokenAmount, row.token),
							" · ",
							NETWORK_BY_ID[row.network].name
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-mono text-xs text-muted-foreground",
						children: shortenAddress(row.walletAddress, 6)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: formatWhen(row.createdAt)
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 text-right",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium tabular-nums",
					children: formatAud(row.amountAud)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground capitalize",
					children: row.status
				})]
			})]
		}, row.id))
	})] });
}
function wait(ms) {
	return new Promise((resolve) => window.setTimeout(resolve, ms));
}
//#endregion
export { DashboardPage as component };
