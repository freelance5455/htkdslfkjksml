//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DFS3udMW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DDo2SRQj.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DDo2SRQj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DCv9EAtS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
