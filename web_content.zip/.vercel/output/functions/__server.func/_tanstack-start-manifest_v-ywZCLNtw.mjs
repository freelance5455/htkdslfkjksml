//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ywZCLNtw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-KWT8L702.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-KWT8L702.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-0_sAK4h-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
