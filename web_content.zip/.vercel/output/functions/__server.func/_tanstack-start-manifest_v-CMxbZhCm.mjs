//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CMxbZhCm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BhO9cJTv.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BhO9cJTv.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bv0OBKuH.js"]
	}
} });
//#endregion
export { tsrStartManifest };
