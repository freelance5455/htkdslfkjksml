//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-TSfXTYT_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/nueva",
			"/partida/$id"
		],
		preloads: [
			"/assets/index-D_FXSTxb.js",
			"/assets/createLucideIcon-DcJ_mmXp.js",
			"/assets/useNavigate-DYQmma_P.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D_FXSTxb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DZ2XQI6Y.js", "/assets/ui-C277VzJz.js"]
	},
	"/nueva": {
		filePath: "/workspace/src/routes/nueva.tsx",
		children: void 0,
		preloads: [
			"/assets/nueva-Cv5oRaO9.js",
			"/assets/narrate-CB3s9g5A.js",
			"/assets/ui-C277VzJz.js"
		]
	},
	"/partida/$id": {
		filePath: "/workspace/src/routes/partida.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/partida._id-DNZwsxKh.js",
			"/assets/narrate-CB3s9g5A.js",
			"/assets/ui-C277VzJz.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
