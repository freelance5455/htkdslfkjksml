//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-98yhVg4h.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CVY6UIiJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CVY6UIiJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Chw6nDUv.js"]
	}
} });
//#endregion
export { tsrStartManifest };
