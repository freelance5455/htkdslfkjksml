//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BmDjfOOx.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/availability",
			"/help",
			"/history",
			"/members",
			"/planner",
			"/reports",
			"/settings",
			"/skills",
			"/workbook"
		],
		preloads: ["/assets/index-CjmU1O3B.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CjmU1O3B.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BJ6NltKR.js", "/assets/shell-aPgSFpd1.js"]
	},
	"/availability": {
		filePath: "/workspace/src/routes/availability.tsx",
		children: void 0,
		preloads: [
			"/assets/availability-B80XQwu5.js",
			"/assets/shell-aPgSFpd1.js",
			"/assets/desk-pages-DvtIbE3z.js"
		]
	},
	"/help": {
		filePath: "/workspace/src/routes/help.tsx",
		children: void 0,
		preloads: [
			"/assets/help-BHxJKaNk.js",
			"/assets/shell-aPgSFpd1.js",
			"/assets/desk-pages-DvtIbE3z.js"
		]
	},
	"/history": {
		filePath: "/workspace/src/routes/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-ElkeRCwq.js",
			"/assets/shell-aPgSFpd1.js",
			"/assets/desk-pages-DvtIbE3z.js"
		]
	},
	"/members": {
		filePath: "/workspace/src/routes/members.tsx",
		children: void 0,
		preloads: [
			"/assets/members-EBGDkboP.js",
			"/assets/shell-aPgSFpd1.js",
			"/assets/types-0NEwtwiG.js"
		]
	},
	"/planner": {
		filePath: "/workspace/src/routes/planner.tsx",
		children: void 0,
		preloads: ["/assets/planner-BICP3t5-.js", "/assets/shell-aPgSFpd1.js"]
	},
	"/reports": {
		filePath: "/workspace/src/routes/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DM_586AM.js",
			"/assets/shell-aPgSFpd1.js",
			"/assets/desk-pages-DvtIbE3z.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-ojjw5izq.js",
			"/assets/shell-aPgSFpd1.js",
			"/assets/desk-pages-DvtIbE3z.js"
		]
	},
	"/skills": {
		filePath: "/workspace/src/routes/skills.tsx",
		children: void 0,
		preloads: [
			"/assets/skills-BGMxkZaB.js",
			"/assets/shell-aPgSFpd1.js",
			"/assets/types-0NEwtwiG.js"
		]
	},
	"/workbook": {
		filePath: "/workspace/src/routes/workbook.tsx",
		children: void 0,
		preloads: ["/assets/workbook-7c7_4T4A.js", "/assets/shell-aPgSFpd1.js"]
	}
} });
//#endregion
export { tsrStartManifest };
