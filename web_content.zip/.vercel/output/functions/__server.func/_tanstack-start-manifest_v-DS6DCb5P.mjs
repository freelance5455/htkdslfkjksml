//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DS6DCb5P.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/media"],
		preloads: ["/assets/index-Ci4eT-ym.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Ci4eT-ym.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BeKZ76Xx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
