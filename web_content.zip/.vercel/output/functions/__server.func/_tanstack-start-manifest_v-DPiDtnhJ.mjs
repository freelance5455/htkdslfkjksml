//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DPiDtnhJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/live",
			"/overlay/alert",
			"/overlay/chat",
			"/overlay/goal",
			"/overlay/rank"
		],
		preloads: [
			"/assets/index-CSrxvO5M.js",
			"/assets/createLucideIcon-B0gP0fY2.js",
			"/assets/search-DFGgYyLb.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CSrxvO5M.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BfetSeoI.js", "/assets/bits-OD6IEA3M.js"]
	},
	"/overlay/alert": {
		filePath: "/workspace/src/routes/overlay/alert.tsx",
		children: void 0,
		preloads: ["/assets/alert-C-90Pe6N.js", "/assets/panels-DC_ociPn.js"]
	},
	"/overlay/chat": {
		filePath: "/workspace/src/routes/overlay/chat.tsx",
		children: void 0,
		preloads: ["/assets/chat-_ELTZ_Ut.js", "/assets/panels-DC_ociPn.js"]
	},
	"/overlay/goal": {
		filePath: "/workspace/src/routes/overlay/goal.tsx",
		children: void 0,
		preloads: ["/assets/goal-BJ9ODMcq.js", "/assets/panels-DC_ociPn.js"]
	},
	"/overlay/rank": {
		filePath: "/workspace/src/routes/overlay/rank.tsx",
		children: void 0,
		preloads: ["/assets/rank-CN_Y5Ngg.js", "/assets/panels-DC_ociPn.js"]
	}
} });
//#endregion
export { tsrStartManifest };
