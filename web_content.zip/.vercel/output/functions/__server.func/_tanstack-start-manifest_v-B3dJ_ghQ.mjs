//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B3dJ_ghQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-FDiNtiCH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-FDiNtiCH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D1Luojza.js"]
	}
} });
//#endregion
export { tsrStartManifest };
