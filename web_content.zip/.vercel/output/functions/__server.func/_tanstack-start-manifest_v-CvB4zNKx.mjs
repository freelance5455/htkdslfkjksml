//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CvB4zNKx.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CUI2J1m2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CUI2J1m2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BaibRC3r.js"]
	}
} });
//#endregion
export { tsrStartManifest };
