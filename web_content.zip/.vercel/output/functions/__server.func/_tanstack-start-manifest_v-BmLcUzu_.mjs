//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BmLcUzu_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/calendario",
			"/configuracoes",
			"/estatisticas",
			"/habitos",
			"/postura",
			"/sessoes",
			"/treinos",
			"/dia/$date"
		],
		preloads: [
			"/assets/index-Dz5_Jirz.js",
			"/assets/store-v6OcPqSD.js",
			"/assets/link-OnVWJYu4.js",
			"/assets/preload-helper-BsAoYw_P.js",
			"/assets/createLucideIcon-ou9q12u2.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dz5_Jirz.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CcpntTSp.js",
			"/assets/useNavigate-DkEcbXAy.js",
			"/assets/calendar-days-3k8aSQUy.js",
			"/assets/chevron-right-DFdA-eSi.js",
			"/assets/check-item-B0rgCJ8u.js",
			"/assets/page-header-hVR0WGtz.js",
			"/assets/card--lS0763W.js",
			"/assets/stat-card-Bxh2A2PZ.js"
		]
	},
	"/calendario": {
		filePath: "/workspace/src/routes/calendario.tsx",
		children: void 0,
		preloads: [
			"/assets/calendario-CGYZj4Cm.js",
			"/assets/page-header-hVR0WGtz.js",
			"/assets/card--lS0763W.js"
		]
	},
	"/configuracoes": {
		filePath: "/workspace/src/routes/configuracoes.tsx",
		children: void 0,
		preloads: [
			"/assets/configuracoes-B8_G0i2j.js",
			"/assets/page-header-hVR0WGtz.js",
			"/assets/card--lS0763W.js",
			"/assets/input-DmdhHqrh.js",
			"/assets/dist-Y_dIBsul.js"
		]
	},
	"/estatisticas": {
		filePath: "/workspace/src/routes/estatisticas.tsx",
		children: void 0,
		preloads: [
			"/assets/estatisticas-D5yxeGju.js",
			"/assets/page-header-hVR0WGtz.js",
			"/assets/card--lS0763W.js",
			"/assets/stat-card-Bxh2A2PZ.js"
		]
	},
	"/habitos": {
		filePath: "/workspace/src/routes/habitos.tsx",
		children: void 0,
		preloads: [
			"/assets/habitos-BQLii9qf.js",
			"/assets/calendar-days-3k8aSQUy.js",
			"/assets/day-checklist-Cj7AjRJ6.js",
			"/assets/page-header-hVR0WGtz.js"
		]
	},
	"/postura": {
		filePath: "/workspace/src/routes/postura.tsx",
		children: void 0,
		preloads: [
			"/assets/postura-DnNCjIiH.js",
			"/assets/dialog-p68mW98x.js",
			"/assets/page-header-hVR0WGtz.js",
			"/assets/card--lS0763W.js",
			"/assets/textarea-VEjRqyTp.js"
		]
	},
	"/sessoes": {
		filePath: "/workspace/src/routes/sessoes.tsx",
		children: ["/sessoes/$id"],
		preloads: [
			"/assets/sessoes-Dj7J2b6O.js",
			"/assets/chevron-right-DFdA-eSi.js",
			"/assets/page-header-hVR0WGtz.js",
			"/assets/card--lS0763W.js",
			"/assets/badge-DeLHke0c.js"
		]
	},
	"/treinos": {
		filePath: "/workspace/src/routes/treinos.tsx",
		children: ["/treinos/$day"],
		preloads: [
			"/assets/treinos-DKhJ4pvO.js",
			"/assets/chevron-right-DFdA-eSi.js",
			"/assets/page-header-hVR0WGtz.js",
			"/assets/card--lS0763W.js",
			"/assets/badge-DeLHke0c.js"
		]
	},
	"/dia/$date": {
		filePath: "/workspace/src/routes/dia.$date.tsx",
		children: void 0,
		preloads: [
			"/assets/dia._date-CQFio_zT.js",
			"/assets/arrow-left-C_-FaAu_.js",
			"/assets/day-checklist-Cj7AjRJ6.js"
		]
	},
	"/sessoes/$id": {
		filePath: "/workspace/src/routes/sessoes.$id.tsx",
		children: void 0,
		preloads: ["/assets/sessoes._id-5u_E-Dc_.js", "/assets/arrow-left-C_-FaAu_.js"]
	},
	"/treinos/$day": {
		filePath: "/workspace/src/routes/treinos.$day.tsx",
		children: void 0,
		preloads: [
			"/assets/treinos._day-DTRG3wO_.js",
			"/assets/dialog-p68mW98x.js",
			"/assets/arrow-left-C_-FaAu_.js",
			"/assets/textarea-VEjRqyTp.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
