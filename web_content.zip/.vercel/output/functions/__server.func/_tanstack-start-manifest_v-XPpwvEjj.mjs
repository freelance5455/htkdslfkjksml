//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-XPpwvEjj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-5cilU7Q7.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-5cilU7Q7.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-ZYukZnhG.js"]
	}
} });
//#endregion
export { tsrStartManifest };
