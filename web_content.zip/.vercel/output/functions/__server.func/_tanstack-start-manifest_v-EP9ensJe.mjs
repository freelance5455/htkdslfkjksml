//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-EP9ensJe.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BLO9POBc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BLO9POBc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CDCEo9ox.js"]
	}
} });
//#endregion
export { tsrStartManifest };
