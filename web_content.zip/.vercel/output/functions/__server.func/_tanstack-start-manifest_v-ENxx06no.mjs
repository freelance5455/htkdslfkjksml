//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ENxx06no.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BIYVh7p1.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BIYVh7p1.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B89G6K55.js"]
	}
} });
//#endregion
export { tsrStartManifest };
