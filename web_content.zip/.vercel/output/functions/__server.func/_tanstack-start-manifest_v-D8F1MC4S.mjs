//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D8F1MC4S.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DBmpXz8N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DBmpXz8N.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BZx5jl3M.js"]
	}
} });
//#endregion
export { tsrStartManifest };
