import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as useDashboard } from "./use-books-BtZpLk9U.mjs";
import { s as formatJalali, u as formatRialCompact } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, n as Card, o as StatCard, r as Money } from "./card-Bb_-PO54.mjs";
import { a as Bar, n as BarChart, o as ResponsiveContainer, r as XAxis, s as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kpi-C5VbzLVT.js
var import_jsx_runtime = require_jsx_runtime();
function KpiPage() {
	const { data } = useDashboard();
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-[24px] bg-secondary" });
	data.ar + data.receiptsToday > 0 && Math.round(data.receiptsToday / (data.ar + data.receiptsToday) * 1e3) / 10;
	const expenseToSales = data.income > 0 ? Math.round(data.expense / data.income * 1e3) / 10 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "شاخص‌های مدیریتی",
			description: "فروش، وصول، نقدینگی، هزینه و سودآوری از روی دفتر کل محاسبه می‌شود."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					gold: true,
					label: "فروش دوره",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.income,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "سود ناخالص",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.gross,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "سود خالص",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.net,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "هزینه به فروش",
					value: `${expenseToSales}٪`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "مطالبات باز",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.ar,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "وصول امروز",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.receiptsToday,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "نسبت نقد",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.liquid,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "تعهدات",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.ap + data.notesPay,
						compact: true
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 text-sm font-medium text-navy",
				children: "فروش در برابر هزینه"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-56",
				dir: "ltr",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: data.series,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "date",
								tickFormatter: (v) => formatJalali(String(v)).slice(-5),
								tick: { fontSize: 10 }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								formatter: (v) => formatRialCompact(Number(v)),
								labelFormatter: (v) => formatJalali(String(v))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "sales",
								name: "فروش",
								fill: "#071428",
								radius: [
									4,
									4,
									0,
									0
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "expense",
								name: "هزینه",
								fill: "#C9A227",
								radius: [
									4,
									4,
									0,
									0
								]
							})
						]
					})
				})
			})]
		})
	] });
}
//#endregion
export { KpiPage as component };
