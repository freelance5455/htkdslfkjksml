import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Trash2 } from "../_libs/lucide-react.mjs";
import { a as STICKERS, g as youtubeVideoId, r as REACTIONS, s as ago } from "./model-Ck66RVeO.mjs";
import { A as useCurrentUserState, D as setReaction, S as listPosts, a as MarkIcon, c as SkeletonCard, f as deleteComment, m as fieldClass, n as EmptyNote, p as deletePost, r as KindPill, s as RolePill, t as Avatar, u as addComment, y as listComments } from "./auth-screens-DZe0plYT.mjs";
import { i as useSalon } from "./shell-DSe4icyb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-me-id-BM_D2CRi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PostCard({ post, variant, mine, onRemoved }) {
	const bump = useSalon((s) => s.bump);
	const [reactions, setReactions] = (0, import_react.useState)(post.reactions);
	const [myReaction, setMine] = (0, import_react.useState)(post.myReaction);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [comments, setComments] = (0, import_react.useState)(null);
	const [count, setCount] = (0, import_react.useState)(post.commentCount);
	const [body, setBody] = (0, import_react.useState)("");
	const [sticker, setSticker] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const video = post.link ? youtubeVideoId(post.link) : null;
	(0, import_react.useEffect)(() => {
		setReactions(post.reactions);
		setMine(post.myReaction);
		setCount(post.commentCount);
	}, [post]);
	async function react(kind) {
		setError(null);
		const result = await setReaction({ data: {
			postId: post.id,
			kind
		} });
		if (!result.ok) {
			setError(result.error);
			return;
		}
		setReactions(result.reactions);
		setMine(result.myReaction);
	}
	async function loadComments() {
		const next = !open;
		setOpen(next);
		if (!next || comments) return;
		const result = await listComments({ data: { postId: post.id } });
		if (result.ok) setComments(result.comments);
	}
	async function sendComment(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			const result = await addComment({ data: {
				postId: post.id,
				body,
				sticker
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setBody("");
			setSticker(null);
			const fresh = await listComments({ data: { postId: post.id } });
			if (fresh.ok) {
				setComments(fresh.comments);
				setCount(fresh.comments.length);
			}
		} finally {
			setBusy(false);
		}
	}
	async function removeComment(id) {
		const result = await deleteComment({ data: { id } });
		if (!result.ok) {
			setError(result.error);
			return;
		}
		setComments((list) => list ? list.filter((item) => item.id !== id) : list);
		setCount((n) => Math.max(0, n - 1));
	}
	async function removePost() {
		const result = await deletePost({ data: { id: post.id } });
		if (!result.ok) {
			setError(result.error);
			return;
		}
		onRemoved(post.id);
		bump();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-3xl bg-paper p-4 shadow-card sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/u/$username",
						params: { username: post.username },
						className: "shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							src: post.avatar,
							name: post.username
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/u/$username",
									params: { username: post.username },
									className: "truncate font-medium",
									children: post.username
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolePill, { role: post.role }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs tabular-nums text-mute",
									children: ago(post.createdAt)
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindPill, { kind: post.kind }), post.groupSlug && post.groupName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/groups/$slug",
								params: { slug: post.groupSlug },
								className: "text-xs text-mute",
								children: post.groupName
							}) : null]
						})]
					}),
					mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 shrink-0 place-items-center rounded-full text-mute hover:bg-ivory hover:text-rose",
						onClick: () => void removePost(),
						"aria-label": "حذف المنشور",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					}) : null
				]
			}),
			post.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 font-display text-2xl leading-snug",
				children: post.title
			}) : null,
			post.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 whitespace-pre-wrap text-sm leading-7 text-ink",
				children: post.body
			}) : null,
			post.media ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: post.media,
				alt: "",
				className: `mt-4 w-full rounded-2xl object-cover ${variant === "reel" ? "aspect-[4/5]" : "max-h-80"}`
			}) : null,
			video ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				className: "mt-4 aspect-video w-full rounded-2xl",
				src: `https://www.youtube-nocookie.com/embed/${video}`,
				title: post.title || "سيبلمنال",
				allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
				allowFullScreen: true
			}) : post.link ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: post.link,
				target: "_blank",
				rel: "noreferrer",
				className: "mt-3 block truncate text-sm text-rose",
				dir: "ltr",
				children: post.link
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid grid-cols-6 gap-1",
				children: REACTIONS.map((item) => {
					const active = myReaction === item.id;
					const n = reactions[item.id] ?? 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": active,
						"aria-label": item.label,
						onClick: () => void react(item.id),
						className: `flex min-h-11 flex-col items-center justify-center rounded-2xl text-xs ${active ? "bg-rose text-paper" : "bg-ivory text-ink"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkIcon, {
							name: item.id,
							className: "size-4"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: n > 0 ? n : item.label
						})]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 min-h-11 text-sm text-mute",
				onClick: () => void loadComments(),
				children: open ? "إخفاء التعليقات" : `تعليقات ${count}`
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 space-y-3 border-t border-ink/10 pt-3",
				children: [(comments ?? []).map((comment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						src: comment.avatar,
						name: comment.username,
						className: "size-8 text-xs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/u/$username",
										params: { username: comment.username },
										className: "text-sm font-medium",
										children: comment.username
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-mute",
										children: ago(comment.createdAt)
									}),
									comment.mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-xs text-mute",
										onClick: () => void removeComment(comment.id),
										children: "حذف"
									}) : null
								]
							}),
							comment.sticker ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 inline-flex items-center gap-1 rounded-2xl bg-rose/10 px-2 py-1 text-xs text-rose",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkIcon, { name: comment.sticker }), STICKERS.find((item) => item.id === comment.sticker)?.label]
							}) : null,
							comment.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-6",
								children: comment.body
							}) : null
						]
					})]
				}, comment.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: sendComment,
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-1.5",
						children: STICKERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": sticker === item.id,
							onClick: () => setSticker((cur) => cur === item.id ? null : item.id),
							className: `flex min-h-11 flex-col items-center justify-center rounded-2xl text-xs ${sticker === item.id ? "bg-rose text-paper" : "bg-ivory"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkIcon, { name: item.id }), item.label]
						}, item.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} h-12 flex-1`,
							placeholder: "تعليق أو ملصق",
							value: body,
							onChange: (e) => setBody(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "min-h-12 shrink-0 rounded-full bg-rose px-4 text-sm text-paper disabled:opacity-50",
							disabled: busy,
							type: "submit",
							children: "إرسال"
						})]
					})]
				})]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-rose",
				children: error
			}) : null
		]
	});
}
function FeedView({ query, variant, emptyTitle, emptyBody, meId }) {
	const tick = useSalon((s) => s.tick);
	const [posts, setPosts] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		listPosts({ data: query }).then((result) => {
			if (!live) return;
			if (!result.ok) setError(result.error);
			else {
				setError(null);
				setPosts(result.posts);
			}
		}).catch((err) => {
			if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
		});
		return () => {
			live = false;
		};
	}, [
		tick,
		query.surface,
		query.kind,
		query.scope,
		query.slug,
		query.username
	]);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-3xl bg-paper px-4 py-6 text-sm text-rose shadow-card",
		children: error
	});
	if (!posts) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonCard, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonCard, {})]
	});
	if (!posts.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, {
		title: emptyTitle,
		body: emptyBody
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: variant === "reel" ? "space-y-4" : "space-y-3",
		children: posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, {
			post,
			variant,
			mine: post.userId === meId,
			onRemoved: (id) => setPosts((list) => list?.filter((item) => item.id !== id) ?? list)
		}, post.id))
	});
}
function useMeId() {
	const { user } = useCurrentUserState();
	return user?.id ?? null;
}
//#endregion
export { useMeId as n, FeedView as t };
