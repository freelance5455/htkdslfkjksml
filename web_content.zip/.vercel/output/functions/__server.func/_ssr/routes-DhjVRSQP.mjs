import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as CalendarDays, D as ArrowUpRight, T as BookOpen, _ as Hourglass, a as Sparkles, b as CircleCheck, g as Info, n as Users, w as CalendarCheck, y as Clock3 } from "../_libs/lucide-react.mjs";
import { E as utcTodayIso, S as partStatus, T as useMinistry, g as formatShort, h as formatLong, i as Card, l as StatusPill, r as Button, t as AppShell, v as fullName } from "./shell-CGpvgZIy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DhjVRSQP.js
var import_jsx_runtime = require_jsx_runtime();
var QUICK = [
	{
		to: "/planner",
		label: "AI Meeting Planner",
		detail: "Arrange or adjust the week",
		icon: Sparkles
	},
	{
		to: "/workbook",
		label: "JW Workbook",
		detail: "Themes, readings, and parts",
		icon: BookOpen
	},
	{
		to: "/members",
		label: "Members",
		detail: "Profiles, skills, and notes",
		icon: Users
	},
	{
		to: "/availability",
		label: "Availability",
		detail: "Who can take a part",
		icon: CalendarCheck
	}
];
function DashboardPage() {
	const navigate = useNavigate();
	const congregation = useMinistry((state) => state.congregation);
	const members = useMinistry((state) => state.members);
	const meetings = useMinistry((state) => state.meetings);
	const assignments = useMinistry((state) => state.assignments);
	const activities = useMinistry((state) => state.activities);
	const requestArrange = useMinistry((state) => state.requestArrange);
	const today = utcTodayIso();
	const byId = new Map(members.map((member) => [member.id, member]));
	const upcomingMeetings = meetings.filter((meeting) => meeting.date >= today);
	const next = upcomingMeetings[0];
	const nextParts = next ? assignments.filter((assignment) => assignment.meetingId === next.id).sort((a, b) => a.order - b.order) : [];
	const completed = assignments.filter((assignment) => {
		const meeting = meetings.find((item) => item.id === assignment.meetingId);
		return meeting ? partStatus(meeting.date, assignment.assigneeId, today) === "completed" : false;
	}).length;
	const pending = assignments.filter((assignment) => {
		const meeting = meetings.find((item) => item.id === assignment.meetingId);
		return meeting ? partStatus(meeting.date, assignment.assigneeId, today) === "pending" : false;
	}).length;
	const openCount = nextParts.filter((part) => !part.assigneeId).length;
	const stats = [
		{
			label: "Registered Members",
			value: members.length,
			icon: Users,
			note: congregation
		},
		{
			label: "Upcoming Meetings",
			value: upcomingMeetings.length,
			icon: CalendarDays,
			note: "On the schedule"
		},
		{
			label: "Completed Assignments",
			value: completed,
			icon: CircleCheck,
			note: "Already given"
		},
		{
			label: "Pending Assignments",
			value: pending,
			icon: Hourglass,
			note: "Still ahead"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-w-0 overflow-hidden rounded-[1.75rem] bg-sidebar px-5 py-6 text-on-navy shadow-lift sm:px-8 sm:py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0",
				"aria-hidden": true,
				style: { backgroundImage: "radial-gradient(520px 180px at 100% 0%, rgb(53 106 230 / 0.45), transparent 60%), linear-gradient(180deg, rgb(54 197 232 / 0.12), transparent 32%)" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-[0.18em] text-cyan uppercase",
							children: "Midweek meeting desk"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 text-4xl text-on-navy sm:text-5xl",
							children: "Welcome to MinistryFlow AI"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-md text-base text-on-navy/75",
							children: "Your intelligent meeting assignment assistant."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							requestArrange();
							navigate({ to: "/planner" });
						},
						className: "tap inline-flex h-14 items-center gap-3 rounded-full bg-royal pr-5 pl-2 text-sm font-semibold text-on-royal shadow-[0_14px_30px_-16px_rgb(53,106,230,0.95)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ai-orb grid size-10 place-items-center rounded-full bg-cyan text-sidebar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" })
						}), "Arrange with AI"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "h-14 text-on-navy hover:bg-on-navy/10",
						onClick: () => void navigate({ to: "/planner" }),
						children: "Open planner"
					})]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stagger mt-5 grid min-w-0 gap-3 sm:grid-cols-2 xl:grid-cols-4",
			children: stats.map((stat) => {
				const Icon = stat.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: stat.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-10 place-items-center rounded-2xl bg-soft text-royal",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-4xl tabular-nums text-ink",
							children: stat.value
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-xs text-muted",
							children: stat.note
						})
					]
				}, stat.label);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,0.9fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-[0.16em] text-royal uppercase",
							children: "Upcoming meeting"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 text-3xl text-ink",
							children: next ? next.theme : "No meeting scheduled"
						}),
						next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								formatLong(next.date),
								" · ",
								next.reading
							]
						}) : null
					] }), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void navigate({ to: "/planner" }),
						className: "tap grid size-11 shrink-0 place-items-center rounded-full bg-soft text-ink",
						"aria-label": "Open this meeting",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })
					}) : null]
				}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2 text-xs font-medium text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-soft px-3 py-1",
							children: ["Week of ", next.weekLabel]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-soft px-3 py-1",
							children: ["Songs ", next.songs.join(" · ")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-soft px-3 py-1",
							children: openCount === 0 ? "Programme filled" : `${openCount} parts still open`
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-5 space-y-2",
					children: nextParts.slice(0, 5).map((part) => {
						const person = part.assigneeId ? byId.get(part.assigneeId) : void 0;
						const status = partStatus(next.date, part.assigneeId, today);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex min-w-0 items-center gap-3 rounded-2xl bg-soft/70 px-3 py-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "w-12 shrink-0 text-xs font-semibold text-muted tabular-nums",
									children: [part.durationMin, "m"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-semibold",
										children: part.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted",
										children: person ? fullName(person) : "Needs a publisher"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status })
							]
						}, part.id);
					})
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "Add a meeting week from the workbook when you are ready."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.16em] text-royal uppercase",
						children: "Recent activity"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-3xl",
						children: "What changed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 space-y-4",
						children: activities.slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 grid size-9 shrink-0 place-items-center rounded-2xl bg-soft text-royal",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: item.detail
								})]
							})]
						}, item.id))
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: "Quick access"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid min-w-0 gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: QUICK.map((item) => {
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void navigate({ to: item.to }),
						className: "tap flex min-w-0 items-center gap-3 rounded-3xl border border-line bg-card p-4 text-left shadow-card hover:border-royal/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 place-items-center rounded-2xl bg-sidebar text-cyan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-semibold",
								children: item.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-muted",
								children: item.detail
							})]
						})]
					}, item.to);
				})
			})]
		}),
		next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-5 flex items-center gap-3 p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-10 shrink-0 place-items-center rounded-2xl bg-soft text-royal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "min-w-0 flex-1 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold text-ink",
					children: formatShort(next.date)
				}), " is the next meeting. Suggestions stay editable — the overseer confirms the final programme."]
			})]
		}) : null
	] });
}
var SplitComponent = function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardPage, {}) });
};
//#endregion
export { SplitComponent as component };
