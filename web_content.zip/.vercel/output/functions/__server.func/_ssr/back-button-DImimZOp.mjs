import { b as useRouter, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { x as ChevronRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/back-button-DImimZOp.js
var import_jsx_runtime = require_jsx_runtime();
function BackButton({ href }) {
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "tap-lg flex size-11 items-center justify-center rounded-full text-foreground hover:bg-surface",
		"aria-label": "رجوع",
		onClick: () => {
			if (href) router.navigate({ to: href });
			else if (window.history.length > 1) router.history.back();
			else router.navigate({ to: "/" });
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
	});
}
//#endregion
export { BackButton as t };
