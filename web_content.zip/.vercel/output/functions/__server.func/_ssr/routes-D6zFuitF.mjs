import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D6zFuitF.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
		title: "CricketWorld Scorecard",
		src: "/scorecard.html",
		className: "score-frame"
	});
}
//#endregion
export { Home as component };
