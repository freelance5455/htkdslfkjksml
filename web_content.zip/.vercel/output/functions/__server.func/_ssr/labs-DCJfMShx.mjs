import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PolarisLab, r as SeasonLab, t as MoonLab } from "./season-lab-Df_aMhYl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/labs-DCJfMShx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WORLDS = [
	{
		name: "Sun",
		km: 1392700,
		au: 0
	},
	{
		name: "Mercury",
		km: 4879,
		au: .387
	},
	{
		name: "Venus",
		km: 12104,
		au: .723
	},
	{
		name: "Earth",
		km: 12742,
		au: 1
	},
	{
		name: "Mars",
		km: 6779,
		au: 1.524
	},
	{
		name: "Jupiter",
		km: 139820,
		au: 5.203
	},
	{
		name: "Saturn",
		km: 116460,
		au: 9.537
	},
	{
		name: "Uranus",
		km: 50724,
		au: 19.19
	},
	{
		name: "Neptune",
		km: 49244,
		au: 30.07
	}
];
var SUN_PX = 220;
function ScaleLab() {
	const [t, setT] = (0, import_react.useState)(.35);
	const span = .45 * 70 ** t;
	const box = (0, import_react.useRef)(null);
	const [width, setWidth] = (0, import_react.useState)(640);
	(0, import_react.useEffect)(() => {
		const el = box.current;
		if (!el) return;
		const measure = () => setWidth(el.clientWidth);
		measure();
		const ro = new ResizeObserver(measure);
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	const pxPerAu = width / span;
	const sunR = Math.max(pxPerAu / 215, .6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
			className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
					className: "text-xs uppercase tracking-widest text-gold",
					children: "Sizes, if the Sun is this circle"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted",
					children: "Earth is the speck under the tick. Jupiter, the giant, is still a marble next to that Sun. Distances are ignored here — that lie is corrected below."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 overflow-x-auto pb-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-6",
						style: { minWidth: 640 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "shrink-0 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-full bg-gold",
								style: {
									width: SUN_PX,
									height: SUN_PX
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-fg",
								children: "Sun"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex items-end gap-4 pb-8",
							children: WORLDS.filter((w) => w.name !== "Sun").map((w) => {
								const d = Math.max(3, w.km / 1392700 * SUN_PX);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex w-16 flex-col items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block rounded-full bg-fg",
										style: {
											width: d,
											height: d
										}
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-center text-xs text-muted",
										children: w.name
									})]
								}, w.name);
							})
						})]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
			className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
					className: "text-xs uppercase tracking-widest text-gold",
					children: "Distances, at the same scale as the sizes"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"The window shows ",
						span < 10 ? span.toFixed(1) : span.toFixed(0),
						" AU. One AU is the Earth–Sun distance. At true scale the planets shrink to dots. That emptiness is the solar system."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: box,
					className: "relative mt-4 h-48 overflow-hidden rounded-xl bg-bg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute top-1/2 rounded-full bg-gold",
						style: {
							width: sunR * 2,
							height: sunR * 2,
							left: 0,
							transform: "translateY(-50%)"
						}
					}), WORLDS.filter((w) => w.au > 0 && w.au <= span * 1.02).map((w) => {
						const x = w.au * pxPerAu;
						const r = Math.max(1.5, w.km / 1392700 * sunR);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute top-1/2",
							style: {
								left: x,
								transform: "translate(-50%, -50%)"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block rounded-full bg-fg",
								style: {
									width: r * 2,
									height: r * 2
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute top-4 left-1/2 -translate-x-1/2 text-xs whitespace-nowrap text-muted",
								children: w.name
							})]
						}, w.name);
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex justify-between",
						children: ["Zoom out", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-fg tabular-nums",
							children: [
								"to ",
								span < 10 ? span.toFixed(1) : Math.round(span),
								" AU"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-2 w-full",
						type: "range",
						min: 0,
						max: 1,
						step: .01,
						value: t,
						onChange: (e) => setT(Number(e.target.value))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-fg",
					children: "Light takes 8.3 minutes to cross 1 AU. Neptune, at 30 AU, is about 4 hours of light away — and still inside the Solar System."
				})
			]
		})]
	});
}
function LabsPage() {
	const hash = useRouterState({ select: (s) => s.location.hash });
	(0, import_react.useEffect)(() => {
		const id = hash.replace(/^#/, "");
		if (!id) return;
		document.getElementById(id)?.scrollIntoView({ block: "start" });
	}, [hash]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-widest text-gold",
			children: "Instruments"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 max-w-xl text-4xl text-fg md:text-5xl",
			children: "Three ideas the eye can check."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-xl text-muted",
			children: "Latitude in the pole star, the Moon's orbit, the year's tilt, and the rude truth about distance. The same latitude feeds the sky chart."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 grid gap-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "pole",
					className: "scroll-mt-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl text-fg",
							children: "The pole"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 mb-4 max-w-xl text-sm text-muted",
							children: "Polaris is not bright. It is useful, which is better. Its height is your latitude."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarisLab, {})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "moon",
					className: "scroll-mt-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl text-fg",
							children: "The Moon"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 mb-4 max-w-xl text-sm text-muted",
							children: "Drag it. New is toward the Sun, full is opposite. Earth's shadow is not involved unless the alignment is exact — that's an eclipse."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoonLab, {})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "seasons",
					className: "scroll-mt-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl text-fg",
							children: "The year"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 mb-4 max-w-xl text-sm text-muted",
							children: "Slide from January to June at your latitude. Watch noon altitude and the length of the day. Then try the other hemisphere."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonLab, {})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "scale",
					className: "scroll-mt-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl text-fg",
							children: "The emptiness"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 mb-4 max-w-xl text-sm text-muted",
							children: "Textbooks draw planets as neighbors. They aren't. Sizes first, then the same scale stretched across distance."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScaleLab, {})
					]
				})
			]
		})
	] });
}
//#endregion
export { LabsPage as component };
