import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as LoaderCircle, f as ChevronRight, h as ArrowLeft, i as Sun, l as List, o as Pause, p as ChevronLeft, s as Moon, t as Volume2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route } from "./router-CcA7s-SN.mjs";
import { n as cn, o as useLibrary, t as Button } from "./library-Dk3ax1hI.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/read._bookId-zLqmwg8Q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex h-11 w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1 w-full grow overflow-hidden rounded-full bg-bg-subtle",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-accent shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none" })]
}));
Slider.displayName = "Slider";
var SENTENCE_SPLIT = /(?<=[.!?¡¿…»”"\n])\s+/;
function splitSentences(text) {
	return text.split(SENTENCE_SPLIT).map((part) => part.trim()).filter(Boolean).map((value, id) => ({
		id,
		text: value
	}));
}
function groupChunks(sentences, maxLen = 280) {
	const chunks = [];
	let buffer = [];
	let length = 0;
	const flush = () => {
		if (buffer.length === 0) return;
		chunks.push({
			text: buffer.map((s) => s.text).join(" "),
			sentenceIds: buffer.map((s) => s.id)
		});
		buffer = [];
		length = 0;
	};
	for (const sentence of sentences) {
		if (length + sentence.text.length > maxLen && buffer.length > 0) flush();
		buffer.push(sentence);
		length += sentence.text.length + 1;
	}
	flush();
	return chunks;
}
function genderOf(name) {
	const n = name.toLowerCase();
	if (/\b(female|woman|mujer|femenina|monica|paulina|zira|samantha|karen|moira|veena|tessa)\b/.test(n)) return "female";
	if (/\b(male|man|hombre|masculina|jorge|pablo|diego|david|daniel|jorge)\b/.test(n)) return "male";
	return "unknown";
}
function listVoices() {
	if (typeof window === "undefined" || !("speechSynthesis" in window)) return [];
	return window.speechSynthesis.getVoices().map((voice) => ({
		uri: voice.voiceURI,
		name: voice.name,
		lang: voice.lang,
		gender: genderOf(`${voice.name} ${voice.lang}`),
		isSpanish: voice.lang.toLowerCase().startsWith("es")
	}));
}
function voiceLabel(voice) {
	const gender = voice.gender === "female" ? "mujer" : voice.gender === "male" ? "hombre" : null;
	const locale = voice.lang || "voz";
	return gender ? `${voice.name} · ${gender} · ${locale}` : `${voice.name} · ${locale}`;
}
function ttsSupported() {
	return typeof window !== "undefined" && "speechSynthesis" in window;
}
var TtsEngine = class {
	chapters = [];
	chunks = [];
	chapter = 0;
	chunk = 0;
	state = "idle";
	utterance = null;
	voiceURI = null;
	rate = 1;
	handlers;
	disposed = false;
	wakeLock = null;
	generation = 0;
	constructor(handlers) {
		this.handlers = handlers;
	}
	load(chapters, startChapter = 0, startChunk = 0) {
		this.stopInternal(false);
		this.chapters = chapters;
		this.chapter = clamp(startChapter, 0, Math.max(0, chapters.length - 1));
		this.prepareChunks();
		this.chunk = clamp(startChunk, 0, Math.max(0, this.chunks.length - 1));
		this.emitPosition();
	}
	setVoice(uri) {
		this.voiceURI = uri;
	}
	setRate(rate) {
		this.rate = Math.min(1.6, Math.max(.6, rate));
	}
	getPosition() {
		return {
			chapter: this.chapter,
			chunk: this.chunk,
			sentenceIds: this.chunks[this.chunk]?.sentenceIds ?? []
		};
	}
	async play() {
		if (this.chapters.length === 0) return;
		this.setState("playing");
		await this.enableWakeLock();
		this.speakCurrent();
		this.syncMediaSession();
	}
	pause() {
		if (this.state !== "playing") return;
		this.generation += 1;
		try {
			window.speechSynthesis.pause();
		} catch {}
		if (!window.speechSynthesis.paused) window.speechSynthesis.cancel();
		this.setState("paused");
		this.releaseWakeLock();
		this.syncMediaSession();
	}
	async resume() {
		if (this.state === "playing") return;
		if (this.state === "paused" && window.speechSynthesis.paused) {
			this.setState("playing");
			await this.enableWakeLock();
			window.speechSynthesis.resume();
			this.syncMediaSession();
			window.setTimeout(() => {
				if (this.state === "playing" && !window.speechSynthesis.speaking) this.speakCurrent();
			}, 120);
			return;
		}
		await this.play();
	}
	stop() {
		this.stopInternal(true);
	}
	async nextChapter() {
		const playing = this.state === "playing";
		if (this.chapter >= this.chapters.length - 1) {
			this.finishBook();
			return;
		}
		this.stopInternal(false);
		this.chapter += 1;
		this.prepareChunks();
		this.chunk = 0;
		this.emitPosition();
		if (playing) await this.play();
		else this.setState("idle");
	}
	async prevChapter() {
		const playing = this.state === "playing";
		this.stopInternal(false);
		this.chapter = Math.max(0, this.chapter - 1);
		this.prepareChunks();
		this.chunk = 0;
		this.emitPosition();
		if (playing) await this.play();
		else this.setState("idle");
	}
	async jumpToChapter(index) {
		const playing = this.state === "playing";
		this.stopInternal(false);
		this.chapter = clamp(index, 0, this.chapters.length - 1);
		this.prepareChunks();
		this.chunk = 0;
		this.emitPosition();
		if (playing) await this.play();
		else this.setState("idle");
	}
	dispose() {
		this.disposed = true;
		this.stopInternal(true);
		this.releaseWakeLock();
	}
	prepareChunks() {
		const chapter = this.chapters[this.chapter];
		const sentences = splitSentences(chapter?.text ?? "");
		this.chunks = groupChunks(sentences);
		if (this.chunks.length === 0) this.chunks = [{
			text: chapter?.text || " ",
			sentenceIds: []
		}];
	}
	speakCurrent() {
		if (this.disposed) return;
		if (!("speechSynthesis" in window)) return;
		if (this.chunk >= this.chunks.length) {
			this.nextChapterFromEnd();
			return;
		}
		const gen = ++this.generation;
		window.speechSynthesis.cancel();
		const chunk = this.chunks[this.chunk];
		const utterance = new SpeechSynthesisUtterance(chunk.text);
		this.utterance = utterance;
		utterance.rate = this.rate;
		utterance.pitch = 1;
		utterance.lang = "es-ES";
		const voices = window.speechSynthesis.getVoices();
		const selected = this.voiceURI && voices.find((v) => v.voiceURI === this.voiceURI) || voices.find((v) => v.lang.toLowerCase().startsWith("es")) || null;
		if (selected) {
			utterance.voice = selected;
			utterance.lang = selected.lang || "es-ES";
		}
		utterance.onend = () => {
			if (this.disposed || gen !== this.generation) return;
			if (this.state !== "playing") return;
			if (Date.now() - startedAt < 90 && chunk.text.length > 48) {
				this.pause();
				this.handlers.onError?.("El navegador no pudo reproducir la voz. Prueba otra voz o el volumen del sistema.");
				return;
			}
			this.chunk += 1;
			this.speakCurrent();
		};
		utterance.onerror = (event) => {
			if (this.disposed || gen !== this.generation) return;
			const code = "error" in event ? String(event.error) : "";
			if (code === "canceled" || code === "interrupted") return;
			if (this.state !== "playing") return;
			this.pause();
			this.handlers.onError?.("No se pudo leer este fragmento. Elige otra voz e inténtalo de nuevo.");
		};
		this.emitPosition();
		const startedAt = Date.now();
		window.speechSynthesis.speak(utterance);
	}
	async nextChapterFromEnd() {
		if (this.chapter >= this.chapters.length - 1) {
			this.finishBook();
			return;
		}
		this.chapter += 1;
		this.prepareChunks();
		this.chunk = 0;
		this.emitPosition();
		this.speakCurrent();
	}
	finishBook() {
		this.stopInternal(true);
		this.handlers.onFinished();
	}
	stopInternal(resetState) {
		this.generation += 1;
		if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
		this.utterance = null;
		if (resetState) {
			this.setState("idle");
			this.releaseWakeLock();
		}
	}
	setState(state) {
		this.state = state;
		this.handlers.onState(state);
		this.syncMediaSession();
	}
	emitPosition() {
		this.handlers.onPosition(this.getPosition());
	}
	async enableWakeLock() {
		try {
			if (this.wakeLock || !("wakeLock" in navigator)) return;
			this.wakeLock = await navigator.wakeLock.request("screen");
			this.wakeLock.addEventListener("release", () => {
				this.wakeLock = null;
			});
		} catch {
			this.wakeLock = null;
		}
	}
	async releaseWakeLock() {
		try {
			await this.wakeLock?.release();
		} catch {}
		this.wakeLock = null;
	}
	syncMediaSession() {
		if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
		const chapter = this.chapters[this.chapter];
		navigator.mediaSession.metadata = new MediaMetadata({
			title: chapter?.title || "Folio",
			artist: "Folio",
			album: "Lector de EPUB con voz"
		});
		navigator.mediaSession.playbackState = this.state === "playing" ? "playing" : "paused";
		try {
			navigator.mediaSession.setActionHandler("play", () => {
				this.resume();
			});
			navigator.mediaSession.setActionHandler("pause", () => this.pause());
			navigator.mediaSession.setActionHandler("previoustrack", () => {
				this.prevChapter();
			});
			navigator.mediaSession.setActionHandler("nexttrack", () => {
				this.nextChapter();
			});
		} catch {}
	}
};
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function ReaderView({ bookId }) {
	const { getBook, hydrate, progress, settings, saveProgress, saveSettings, hydrated } = useLibrary();
	const [book, setBook] = (0, import_react.useState)(void 0);
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [chapter, setChapter] = (0, import_react.useState)(0);
	const [activeIds, setActiveIds] = (0, import_react.useState)([]);
	const [voices, setVoices] = (0, import_react.useState)([]);
	const [tocOpen, setTocOpen] = (0, import_react.useState)(false);
	const engineRef = (0, import_react.useRef)(null);
	const scrollRef = (0, import_react.useRef)(null);
	const night = settings.night;
	const rate = settings.rate;
	const voiceURI = settings.voiceURI;
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		let cancelled = false;
		getBook(bookId).then((loaded) => {
			if (!cancelled) setBook(loaded);
		});
		return () => {
			cancelled = true;
		};
	}, [
		bookId,
		getBook,
		hydrated
	]);
	(0, import_react.useEffect)(() => {
		if (!book) return;
		const saved = progress[book.id];
		const engine = new TtsEngine({
			onState: setStatus,
			onPosition: (pos) => {
				setChapter(pos.chapter);
				setActiveIds(pos.sentenceIds);
				saveProgress(book.id, pos.chapter, pos.chunk);
			},
			onFinished: () => {
				toast.success("Has terminado el libro");
			},
			onError: (message) => {
				toast.error(message);
			}
		});
		engine.setRate(rate);
		engine.setVoice(voiceURI);
		engine.load(book.chapters, saved?.chapter ?? 0, saved?.chunk ?? 0);
		engineRef.current = engine;
		const pos = engine.getPosition();
		setChapter(pos.chapter);
		setActiveIds(pos.sentenceIds);
		return () => {
			engine.dispose();
			engineRef.current = null;
		};
	}, [book?.id]);
	(0, import_react.useEffect)(() => {
		engineRef.current?.setRate(rate);
	}, [rate]);
	(0, import_react.useEffect)(() => {
		engineRef.current?.setVoice(voiceURI);
	}, [voiceURI]);
	(0, import_react.useEffect)(() => {
		function collect() {
			const all = listVoices();
			const spanish = all.filter((v) => v.isSpanish);
			setVoices(spanish.length > 0 ? spanish : all);
		}
		collect();
		if (typeof window === "undefined") return;
		window.speechSynthesis?.addEventListener("voiceschanged", collect);
		return () => {
			window.speechSynthesis?.removeEventListener("voiceschanged", collect);
		};
	}, []);
	const sentences = (0, import_react.useMemo)(() => {
		return splitSentences(book?.chapters[chapter]?.text ?? "");
	}, [book, chapter]);
	(0, import_react.useEffect)(() => {
		scrollRef.current?.scrollTo({ top: 0 });
	}, [chapter]);
	(0, import_react.useEffect)(() => {
		const id = activeIds[0];
		if (id === void 0) return;
		const node = document.getElementById(`s-${id}`);
		const root = scrollRef.current;
		if (!node || !root) return;
		const nodeRect = node.getBoundingClientRect();
		const rootRect = root.getBoundingClientRect();
		if (!(nodeRect.top >= rootRect.top + 48 && nodeRect.bottom <= rootRect.bottom - 48)) node.scrollIntoView({
			block: "center",
			behavior: "smooth"
		});
	}, [activeIds, chapter]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			const target = event.target;
			if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) return;
			if (event.code === "Space") {
				event.preventDefault();
				togglePlay();
			} else if (event.key === "ArrowLeft") engineRef.current?.prevChapter();
			else if (event.key === "ArrowRight") engineRef.current?.nextChapter();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	function togglePlay() {
		const engine = engineRef.current;
		if (!engine) return;
		if (!ttsSupported()) {
			toast.error("Este navegador no puede leer en voz alta");
			return;
		}
		if (status === "playing") engine.pause();
		else if (status === "paused") engine.resume();
		else engine.play();
	}
	if (book === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin" })
	});
	if (book === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-4 px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-medium",
				children: "Libro no encontrado"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Puede que se haya borrado de esta biblioteca."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Volver a Folio"
				})
			})
		]
	});
	const current = book.chapters[chapter];
	const chapterCount = book.chapters.length;
	const progressRatio = chapterCount === 0 ? 0 : (chapter + (sentences.length ? (activeIds[0] ?? 0) / sentences.length : 0)) / chapterCount;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex min-h-dvh flex-col bg-bg text-fg", night && "theme-night"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-border/70 bg-bg/90 px-3 py-2 backdrop-blur-sm sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							asChild: true,
							"aria-label": "Volver a la biblioteca",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 px-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-display text-sm font-medium tracking-tight",
								children: book.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted tabular-nums",
								children: [
									"Capítulo ",
									chapter + 1,
									" de ",
									chapterCount
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": night ? "Usar papel claro" : "Usar noche",
							onClick: () => saveSettings({ night: !night }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative size-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: cn("absolute inset-0 size-5 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-in-out", night ? "scale-100 opacity-100 blur-0" : "scale-[0.25] opacity-0 blur-[4px]") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: cn("absolute inset-0 size-5 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-in-out", night ? "scale-[0.25] opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-0") })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Capítulos",
							onClick: () => setTocOpen(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-5" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mt-2 h-0.5 max-w-3xl overflow-hidden rounded-full bg-bg-subtle",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-accent transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-out)]",
						style: { width: `${Math.min(100, Math.max(2, progressRatio * 100))}%` }
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scrollRef,
				className: "mx-auto w-full max-w-2xl flex-1 overflow-y-auto px-5 py-8 sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-medium tracking-tight text-fg sm:text-3xl",
					children: current?.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 font-display text-[1.0625rem] leading-[1.7] text-fg sm:text-lg sm:leading-[1.75]",
					children: sentences.map((sentence) => {
						const active = activeIds.includes(sentence.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							id: `s-${sentence.id}`,
							className: cn("transition-colors duration-[var(--motion-quick)]", active && "sentence-active"),
							children: sentence.text
						}), " "] }, sentence.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerDock, {
				status,
				voices,
				voiceURI,
				rate,
				onVoice: (uri) => saveSettings({ voiceURI: uri }),
				onRate: (value) => saveSettings({ rate: value }),
				onPrev: () => void engineRef.current?.prevChapter(),
				onNext: () => void engineRef.current?.nextChapter(),
				onToggle: togglePlay,
				ttsOk: ttsSupported()
			}),
			tocOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterDrawer, {
				title: book.title,
				chapters: book.chapters.map((c) => c.title),
				current: chapter,
				onClose: () => setTocOpen(false),
				onSelect: (index) => {
					engineRef.current?.jumpToChapter(index);
					setTocOpen(false);
				}
			})
		]
	});
}
function PlayerDock({ status, voices, voiceURI, rate, onVoice, onRate, onPrev, onNext, onToggle, ttsOk }) {
	const playing = status === "playing";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sticky bottom-0 z-20 border-t border-border/70 bg-bg/95 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-2xl flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4 shrink-0 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "folio-voice",
							children: "Voz"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "folio-voice",
							className: "h-11 min-w-0 flex-1 rounded-md bg-bg-elevated px-3 font-sans text-sm text-fg shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
							value: voiceURI ?? "",
							onChange: (event) => onVoice(event.target.value || null),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Voz del sistema"
							}), voices.map((voice) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: voice.uri,
								children: voiceLabel(voice)
							}, voice.uri))]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "w-10 shrink-0 text-xs text-muted tabular-nums",
						children: [rate.toFixed(1), "×"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: .6,
						max: 1.6,
						step: .1,
						value: [rate],
						onValueChange: (values) => onRate(values[0] ?? 1),
						"aria-label": "Velocidad de lectura"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-center gap-6 pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Capítulo anterior",
							onClick: onPrev,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "play",
							"aria-label": playing ? "Pausar" : "Reproducir",
							onClick: onToggle,
							disabled: !ttsOk,
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: cn("absolute size-7 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-in-out", playing ? "scale-100 opacity-100 blur-0" : "scale-[0.25] opacity-0 blur-[4px]") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: cn("size-7 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-in-out", playing ? "scale-[0.25] opacity-0 blur-[4px]" : "ml-0.5 scale-100 opacity-100 blur-0") })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Capítulo siguiente",
							onClick: onNext,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-6" })
						})
					]
				}),
				!ttsOk && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-xs text-muted",
					children: "La lectura en voz alta no está disponible en este navegador."
				})
			]
		})
	});
}
function ChapterDrawer({ title, chapters, current, onClose, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-fg/40",
			"aria-label": "Cerrar capítulos",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-x-0 bottom-0 max-h-[80vh] overflow-hidden rounded-t-2xl bg-bg-elevated pb-[env(safe-area-inset-bottom)] shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 pb-3 pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
						children: "Capítulos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 truncate font-display text-lg font-medium tracking-tight",
						children: title
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "max-h-[60vh] overflow-y-auto px-2 pb-4",
					children: chapters.map((name, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSelect(index),
						className: cn("flex w-full items-baseline gap-3 rounded-md px-3 py-3 text-left transition-colors duration-[var(--motion-quick)]", index === current ? "bg-bg-subtle text-fg" : "text-fg hover:bg-bg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 shrink-0 font-sans text-xs tabular-nums text-muted",
							children: index + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-sm leading-snug",
							children: name
						})]
					}) }, `${index}-${name}`))
				})
			]
		})]
	});
}
function ReadPage() {
	const { bookId } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderView, { bookId });
}
//#endregion
export { ReadPage as component };
