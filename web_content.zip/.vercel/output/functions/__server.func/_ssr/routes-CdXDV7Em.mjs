import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Coffee, a as ShoppingBasket, b as Bus, c as Plus, d as Minus, f as Laptop, g as Ellipsis, h as Gift, i as Ticket, l as PiggyBank, m as HeartPulse, n as TrendingUp, o as ShoppingBag, p as House, r as Trash2, s as Receipt, u as Pencil, v as ChevronRight, x as Briefcase, y as ChevronLeft } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { a as Tooltip, i as ResponsiveContainer, n as Pie, r as Cell, t as PieChart } from "../_libs/recharts+[...].mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CdXDV7Em.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var CATEGORIES = [
	{
		id: "salary",
		type: "income",
		label: "Зарплата",
		chart: ""
	},
	{
		id: "freelance",
		type: "income",
		label: "Фриланс",
		chart: ""
	},
	{
		id: "invest",
		type: "income",
		label: "Инвестиции",
		chart: ""
	},
	{
		id: "gift-in",
		type: "income",
		label: "Подарки",
		chart: ""
	},
	{
		id: "other-in",
		type: "income",
		label: "Другое",
		chart: ""
	},
	{
		id: "groceries",
		type: "expense",
		label: "Продукты",
		chart: "var(--color-cat-groceries)"
	},
	{
		id: "home",
		type: "expense",
		label: "Жильё",
		chart: "var(--color-cat-home)"
	},
	{
		id: "transport",
		type: "expense",
		label: "Транспорт",
		chart: "var(--color-cat-transport)"
	},
	{
		id: "cafe",
		type: "expense",
		label: "Кафе",
		chart: "var(--color-cat-cafe)"
	},
	{
		id: "health",
		type: "expense",
		label: "Здоровье",
		chart: "var(--color-cat-health)"
	},
	{
		id: "shopping",
		type: "expense",
		label: "Покупки",
		chart: "var(--color-cat-shopping)"
	},
	{
		id: "fun",
		type: "expense",
		label: "Досуг",
		chart: "var(--color-cat-fun)"
	},
	{
		id: "bills",
		type: "expense",
		label: "Счета",
		chart: "var(--color-cat-bills)"
	},
	{
		id: "other-out",
		type: "expense",
		label: "Другое",
		chart: "var(--color-cat-other)"
	}
];
var monthFmt = new Intl.DateTimeFormat("ru-RU", {
	month: "long",
	year: "numeric"
});
var dayFmt = new Intl.DateTimeFormat("ru-RU", {
	day: "numeric",
	month: "long",
	weekday: "short"
});
function categoriesFor(type) {
	return CATEGORIES.filter((category) => category.type === type);
}
function categoryById(id) {
	return CATEGORIES.find((category) => category.id === id) ?? null;
}
function parseRubles(raw) {
	const cleaned = raw.replace(/[\s\u00a0\u202f]/g, "").replace(",", ".");
	if (!/^\d+(\.\d{0,2})?$/.test(cleaned)) return null;
	const value = Number(cleaned);
	if (!Number.isFinite(value) || value <= 0 || value > 999999999) return null;
	return Math.round(value * 100);
}
function formatAmountInput(cents) {
	const hasKop = Math.abs(cents) % 100 !== 0;
	return new Intl.NumberFormat("ru-RU", {
		minimumFractionDigits: hasKop ? 2 : 0,
		maximumFractionDigits: 2
	}).format(Math.abs(cents) / 100);
}
function currentMonthKey(date = /* @__PURE__ */ new Date()) {
	const month = String(date.getMonth() + 1).padStart(2, "0");
	return `${date.getFullYear()}-${month}`;
}
function monthOf(iso) {
	return iso.slice(0, 7);
}
function shiftMonth(key, delta) {
	const [year, month] = key.split("-").map(Number);
	return currentMonthKey(new Date(year, month - 1 + delta, 1));
}
function formatMonthLabel(key) {
	const [year, month] = key.split("-").map(Number);
	const raw = monthFmt.format(new Date(year, month - 1, 1)).replace(/\s*г\.?$/, "");
	return raw.charAt(0).toUpperCase() + raw.slice(1);
}
function formatDayLabel(iso) {
	const [year, month, day] = iso.split("-").map(Number);
	const raw = dayFmt.format(new Date(year, month - 1, day));
	return raw.charAt(0).toUpperCase() + raw.slice(1);
}
function defaultDateForMonth(key, today = /* @__PURE__ */ new Date()) {
	if (key === currentMonthKey(today)) return toIso(today);
	const [year, month] = key.split("-").map(Number);
	const last = new Date(year, month, 0).getDate();
	return `${key}-${String(Math.min(15, last)).padStart(2, "0")}`;
}
function toIso(date) {
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${date.getFullYear()}-${month}-${day}`;
}
function blankDraft(month) {
	return {
		id: null,
		type: "expense",
		amount: "",
		categoryId: "groceries",
		date: defaultDateForMonth(month),
		note: ""
	};
}
function signed(tx) {
	return tx.type === "income" ? tx.amount : -tx.amount;
}
function summarize(txs) {
	let income = 0;
	let expense = 0;
	for (const tx of txs) if (tx.type === "income") income += tx.amount;
	else expense += tx.amount;
	return {
		income,
		expense,
		balance: income - expense
	};
}
function expenseSlices(txs) {
	const totals = /* @__PURE__ */ new Map();
	for (const tx of txs) {
		if (tx.type !== "expense") continue;
		totals.set(tx.categoryId, (totals.get(tx.categoryId) ?? 0) + tx.amount);
	}
	return [...totals.entries()].map(([id, amount]) => {
		const category = categoryById(id);
		return {
			id,
			label: category?.label ?? "Другое",
			amount,
			chart: category?.chart || "var(--color-muted)"
		};
	}).sort((a, b) => b.amount - a.amount);
}
function projectBalance(options) {
	const { balance, month, txs, draft } = options;
	if (!draft) return {
		next: balance,
		changed: false,
		inView: true
	};
	let next = balance;
	if (draft.id) {
		const previous = txs.find((tx) => tx.id === draft.id);
		if (previous && monthOf(previous.date) === month) next -= signed(previous);
	}
	const inView = monthOf(draft.date) === month;
	if (inView) next += draft.type === "income" ? draft.amount : -draft.amount;
	return {
		next,
		changed: next !== balance,
		inView
	};
}
function plural(n, one, few, many) {
	const abs = Math.abs(n) % 100;
	const digit = abs % 10;
	if (abs > 10 && abs < 20) return many;
	if (digit > 1 && digit < 5) return few;
	if (digit === 1) return one;
	return many;
}
function dayInMonth(preferred, now) {
	const today = now.getDate();
	if (preferred <= today) return preferred;
	return (preferred - 1) % today + 1;
}
function makeSeed(now = /* @__PURE__ */ new Date()) {
	const rows = [
		{
			day: 5,
			type: "income",
			amount: 186e5,
			categoryId: "salary",
			note: "Основная работа"
		},
		{
			day: 14,
			type: "income",
			amount: 275e4,
			categoryId: "freelance",
			note: "Макет для студии"
		},
		{
			day: 3,
			type: "expense",
			amount: 52e5,
			categoryId: "home",
			note: "Аренда"
		},
		{
			day: 4,
			type: "expense",
			amount: 349e3,
			categoryId: "bills",
			note: "Связь и интернет"
		},
		{
			day: 6,
			type: "expense",
			amount: 428e3,
			categoryId: "groceries",
			note: "Супермаркет"
		},
		{
			day: 8,
			type: "expense",
			amount: 24e4,
			categoryId: "transport",
			note: "Проездной"
		},
		{
			day: 9,
			type: "expense",
			amount: 64e3,
			categoryId: "cafe",
			note: "Кофе"
		},
		{
			day: 11,
			type: "expense",
			amount: 184050,
			categoryId: "groceries",
			note: "Рынок"
		},
		{
			day: 12,
			type: "expense",
			amount: 215e3,
			categoryId: "health",
			note: "Аптека"
		},
		{
			day: 16,
			type: "expense",
			amount: 128e3,
			categoryId: "cafe",
			note: "Ужин"
		},
		{
			day: 18,
			type: "expense",
			amount: 312e3,
			categoryId: "groceries",
			note: "На неделю"
		},
		{
			day: 19,
			type: "expense",
			amount: 89e3,
			categoryId: "fun",
			note: "Кино"
		},
		{
			day: 20,
			type: "expense",
			amount: 89e3,
			categoryId: "transport",
			note: "Такси"
		},
		{
			day: 21,
			type: "expense",
			amount: 456e3,
			categoryId: "shopping",
			note: "Обувь"
		},
		{
			day: 22,
			type: "expense",
			amount: 96e3,
			categoryId: "groceries",
			note: "Хлеб и молоко"
		}
	];
	const year = now.getFullYear();
	const month = String(now.getMonth() + 1).padStart(2, "0");
	return rows.map((row, index) => {
		const day = String(dayInMonth(row.day, now)).padStart(2, "0");
		return {
			id: `seed-${index + 1}`,
			type: row.type,
			amount: row.amount,
			categoryId: row.categoryId,
			note: row.note,
			date: `${year}-${month}-${day}`
		};
	});
}
var DEFAULT_GOAL = {
	name: "Подушка",
	target: 18e6
};
function normalizeTx(value) {
	if (!value || typeof value !== "object") return null;
	const tx = value;
	if (tx.type !== "income" && tx.type !== "expense") return null;
	if (typeof tx.id !== "string" || !tx.id) return null;
	if (typeof tx.amount !== "number" || !Number.isFinite(tx.amount) || tx.amount <= 0) return null;
	if (typeof tx.date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(tx.date)) return null;
	if (typeof tx.categoryId !== "string" || !tx.categoryId) return null;
	return {
		id: tx.id,
		type: tx.type,
		amount: Math.round(tx.amount),
		categoryId: tx.categoryId,
		date: tx.date,
		note: typeof tx.note === "string" ? tx.note.slice(0, 80) : ""
	};
}
function normalizeGoal(value) {
	if (!value || typeof value !== "object") return null;
	const goal = value;
	if (typeof goal.name !== "string" || !goal.name.trim()) return null;
	if (typeof goal.target !== "number" || !Number.isFinite(goal.target) || goal.target <= 0) return null;
	if (goal.target > 1e11) return null;
	return {
		name: goal.name.trim().slice(0, 40),
		target: Math.round(goal.target)
	};
}
var NUMBER = {
	hero: "text-4xl sm:text-5xl lg:text-6xl",
	stat: "text-xl sm:text-2xl",
	row: "text-base",
	goal: "text-xl",
	inline: "text-sm"
};
var MARK = {
	hero: "text-xl sm:text-2xl",
	stat: "text-sm",
	row: "text-xs",
	goal: "text-sm",
	inline: "text-xs"
};
function Money({ cents, size = "row", sign = "never", display = false, className }) {
	const prefix = sign === "never" ? "" : cents < 0 ? "−" : sign === "always" && cents > 0 ? "+" : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("tabular-nums tracking-tight", display || size === "hero" || size === "stat" || size === "goal" ? "font-display" : "font-sans font-semibold", NUMBER[size], className),
		children: [
			prefix,
			formatAmountInput(cents),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("ml-1 font-sans font-semibold tracking-normal opacity-70", MARK[size]),
				children: "₽"
			})
		]
	});
}
function ExpenseChart({ slices, total, activeId, onSelect }) {
	const reduceMotion = usePrefersReducedMotion();
	if (slices.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-52 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex size-40 items-center justify-center rounded-full border border-dashed border-line px-6 text-center text-sm text-muted",
			children: "Нет расходов за месяц"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-52",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full w-full",
			"aria-hidden": true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				minWidth: 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
					data: slices,
					dataKey: "amount",
					nameKey: "label",
					innerRadius: "68%",
					outerRadius: "92%",
					paddingAngle: 2,
					cornerRadius: 6,
					stroke: "none",
					isAnimationActive: !reduceMotion,
					animationDuration: 400,
					onClick: (entry) => {
						const id = sliceId(entry);
						if (!id) return;
						onSelect(activeId === id ? null : id);
					},
					children: slices.map((slice) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						fill: slice.chart,
						opacity: activeId && activeId !== slice.id ? .35 : 1,
						className: "cursor-pointer"
					}, slice.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseTip, {}),
					cursor: false,
					wrapperStyle: { outline: "none" }
				})] })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium text-muted",
				children: "расходы"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
				cents: total,
				size: "goal"
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 flex flex-col gap-1",
		children: slices.map((slice) => {
			const pct = total > 0 ? Math.round(slice.amount / total * 100) : 0;
			const selected = activeId === slice.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onSelect(selected ? null : slice.id),
				className: cn("w-full rounded-xl px-3 py-2 text-left transition-colors", selected ? "bg-bg" : "hover:bg-bg"),
				"aria-pressed": selected,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-2.5 shrink-0 rounded-full",
							style: { background: slice.chart }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate text-sm",
							children: slice.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-medium text-muted tabular-nums",
							children: [pct, "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
							cents: slice.amount,
							size: "inline"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-2 block h-1 overflow-hidden rounded-full bg-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block h-full rounded-full",
						style: {
							width: `${pct}%`,
							background: slice.chart
						}
					})
				})]
			}) }, slice.id);
		})
	})] });
}
function ExpenseTip({ active, payload }) {
	if (!active || !payload?.length || typeof payload[0].value !== "number") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-ink px-3 py-2 text-on-ink shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-on-ink-soft",
			children: payload[0].name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
			cents: payload[0].value,
			size: "inline",
			className: "text-on-ink"
		})]
	});
}
function sliceId(entry) {
	if (!entry || typeof entry !== "object") return null;
	const value = entry;
	return value.id ?? value.payload?.id ?? null;
}
function usePrefersReducedMotion() {
	const [reduce, setReduce] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const query = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => setReduce(query.matches);
		apply();
		query.addEventListener("change", apply);
		return () => query.removeEventListener("change", apply);
	}, []);
	return reduce;
}
var useBudget = create()(persist((set) => ({
	transactions: [],
	goal: DEFAULT_GOAL,
	initialized: false,
	add: (tx) => set((state) => ({ transactions: [{
		...tx,
		id: crypto.randomUUID()
	}, ...state.transactions] })),
	update: (id, tx) => set((state) => ({ transactions: state.transactions.map((item) => item.id === id ? {
		...tx,
		id
	} : item) })),
	remove: (id) => set((state) => ({ transactions: state.transactions.filter((item) => item.id !== id) })),
	setGoal: (goal) => set({ goal }),
	clearAll: () => set({
		transactions: [],
		initialized: true
	}),
	loadExample: () => set((state) => ({
		transactions: makeSeed(),
		initialized: true,
		goal: state.initialized ? state.goal : DEFAULT_GOAL
	}))
}), {
	name: "smeta-v1",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		transactions: state.transactions,
		goal: state.goal,
		initialized: state.initialized
	}),
	merge: (persisted, current) => {
		const saved = persisted ?? {};
		const transactions = Array.isArray(saved.transactions) ? saved.transactions.flatMap((item) => {
			const tx = normalizeTx(item);
			return tx ? [tx] : [];
		}) : [];
		return {
			...current,
			transactions,
			goal: normalizeGoal(saved.goal) ?? current.goal,
			initialized: saved.initialized === true
		};
	}
}));
function GoalCard({ balance }) {
	const goal = useBudget((state) => state.goal);
	const setGoal = useBudget((state) => state.setGoal);
	const [name, setName] = (0, import_react.useState)(goal.name);
	const [amount, setAmount] = (0, import_react.useState)(() => formatAmountInput(goal.target));
	const parsed = parseRubles(amount);
	const target = parsed ?? goal.target;
	const rawPct = target > 0 ? Math.round((balance > 0 ? balance : 0) / target * 100) : 0;
	const bar = Math.min(100, Math.max(0, rawPct));
	const gap = target - balance;
	function commitName(next) {
		const trimmed = next.trim().slice(0, 40);
		if (!trimmed) {
			setName(goal.name);
			return;
		}
		setName(trimmed);
		setGoal({
			name: trimmed,
			target
		});
	}
	function commitAmount() {
		if (parsed == null) {
			setAmount(formatAmountInput(goal.target));
			return;
		}
		setAmount(formatAmountInput(parsed));
		setGoal({
			name: name.trim() || goal.name,
			target: parsed
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-3xl bg-surface p-5 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PiggyBank, {
					className: "size-4 text-pine",
					"aria-hidden": true
				}), "Цель накоплений"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				"aria-label": "Название цели",
				value: name,
				maxLength: 40,
				onChange: (event) => {
					const next = event.target.value;
					setName(next);
					const trimmed = next.trim().slice(0, 40);
					if (trimmed) setGoal({
						name: trimmed,
						target
					});
				},
				onBlur: () => commitName(name),
				className: "mt-2 w-full bg-transparent text-lg font-semibold outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mt-4 block text-xs font-medium text-muted",
				htmlFor: "goal-amount",
				children: "Сколько хотите отложить"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "goal-amount",
				inputMode: "decimal",
				autoComplete: "off",
				value: amount,
				onChange: (event) => {
					const next = event.target.value;
					setAmount(next);
					const cents = parseRubles(next);
					if (cents != null) setGoal({
						name: name.trim() || goal.name,
						target: cents
					});
				},
				onBlur: commitAmount,
				className: "mt-1 w-full bg-transparent font-display text-3xl tabular-nums tracking-tight outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium tabular-nums",
					children: balance < 0 ? "0%" : `${rawPct}%`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-right text-muted",
					children: "от остатка этого месяца"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 h-2 overflow-hidden rounded-full bg-line",
				role: "progressbar",
				"aria-valuemin": 0,
				"aria-valuemax": 100,
				"aria-valuenow": bar,
				"aria-label": "Прогресс цели",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("h-full rounded-full", balance < 0 ? "bg-clay" : "bg-pine"),
					style: { width: `${bar}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm",
				children: balance < 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-clay",
					children: "Сначала выйти в плюс — остаток отрицательный"
				}) : gap > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Ещё ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
					cents: gap,
					size: "inline"
				})] }) : gap === 0 ? "Цель закрыта ровно" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Сверх плана ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
					cents: -gap,
					size: "inline",
					className: "text-pine"
				})] })
			})
		]
	});
}
var ICONS = {
	salary: Briefcase,
	freelance: Laptop,
	invest: TrendingUp,
	"gift-in": Gift,
	"other-in": Plus,
	groceries: ShoppingBasket,
	home: House,
	transport: Bus,
	cafe: Coffee,
	health: HeartPulse,
	shopping: ShoppingBag,
	fun: Ticket,
	bills: Receipt,
	"other-out": Ellipsis
};
function CategoryGlyph({ id, className }) {
	const Icon = ICONS[id] ?? Ellipsis;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		strokeWidth: 1.75,
		"aria-hidden": true
	});
}
function LedgerList({ items, filterLabel, pendingDelete, pendingClear, onEdit, onAskDelete, onConfirmDelete, onCancelDelete, onClearFilter, onAskClear, onConfirmClear, onCancelClear, onLoadExample }) {
	const groups = groupByDate(items);
	const countLabel = `${items.length} ${plural(items.length, "операция", "операции", "операций")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-3xl bg-surface shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3 px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Операции"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: items.length === 0 ? "Пока пусто" : countLabel
				})] }), filterLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onClearFilter,
					className: "rounded-full bg-bg px-3 py-2 text-sm font-medium",
					children: [filterLabel, " ×"]
				}) : null]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 pb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: filterLabel ? "В этой категории за месяц ничего нет." : "Добавьте доход или расход — остаток пересчитается сразу."
				}), !filterLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onLoadExample,
					className: "mt-3 text-sm font-semibold text-pine",
					children: "Показать пример"
				}) : null]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "bg-bg px-5 py-2 text-xs font-semibold text-muted",
				children: formatDayLabel(group.date)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: group.items.map((tx) => {
				const category = categoryById(tx.categoryId);
				const confirming = pendingDelete === tx.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-line last:border-b-0",
					children: confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-16 items-center justify-between gap-3 px-5 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Удалить операцию?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onConfirmDelete,
								className: "h-11 rounded-xl bg-clay px-3 text-sm font-semibold text-on-clay",
								children: "Удалить"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onCancelDelete,
								className: "h-11 rounded-xl bg-bg px-3 text-sm font-semibold",
								children: "Оставить"
							})]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 pr-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onEdit(tx),
							className: "flex min-h-16 min-w-0 flex-1 items-center gap-3 px-5 py-3 text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: tx.type === "income" ? "flex size-10 shrink-0 items-center justify-center rounded-full bg-pine-soft text-pine" : "flex size-10 shrink-0 items-center justify-center rounded-full bg-clay-soft text-clay",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryGlyph, {
										id: tx.categoryId,
										className: "size-4"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate font-medium",
											children: category?.label ?? "Без категории"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
											className: "size-3.5 shrink-0 text-muted",
											"aria-hidden": true
										})]
									}), tx.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm text-muted",
										children: tx.note
									}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
									cents: tx.type === "income" ? tx.amount : -tx.amount,
									sign: "always",
									className: tx.type === "income" ? "text-pine" : "text-clay"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `Удалить: ${category?.label ?? "операция"}`,
							onClick: () => onAskDelete(tx.id),
							className: "flex size-11 shrink-0 items-center justify-center rounded-xl text-muted hover:bg-bg hover:text-clay",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
								className: "size-4",
								"aria-hidden": true
							})
						})]
					})
				}, tx.id);
			}) })] }, group.date)) }),
			items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line px-5 py-4",
				children: pendingClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: "Удалить все операции?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onConfirmClear,
							className: "h-11 rounded-xl bg-clay px-3 text-sm font-semibold text-on-clay",
							children: "Удалить всё"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onCancelClear,
							className: "h-11 rounded-xl bg-bg px-3 text-sm font-semibold",
							children: "Отмена"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onAskClear,
					className: "text-sm font-medium text-muted hover:text-ink",
					children: "Очистить все операции"
				})
			}) : null
		]
	});
}
function groupByDate(items) {
	const sorted = items.slice().sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
	const groups = [];
	for (const tx of sorted) {
		const last = groups[groups.length - 1];
		if (!last || last.date !== tx.date) groups.push({
			date: tx.date,
			items: [tx]
		});
		else last.items.push(tx);
	}
	return groups;
}
function TransactionForm({ value, error, preview, showCancel, amountRef, onChange, onSubmit, onCancel }) {
	const categories = categoriesFor(value.type);
	function setType(type) {
		const nextCategories = categoriesFor(type);
		const categoryId = nextCategories.some((category) => category.id === value.categoryId) ? value.categoryId : nextCategories[0].id;
		onChange({
			...value,
			type,
			categoryId
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => {
			event.preventDefault();
			onSubmit();
		},
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: value.id ? "Редактирование" : "Новая операция"
				}), showCancel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onCancel,
					className: "text-sm font-medium text-muted lg:hidden",
					children: "Закрыть"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid h-12 grid-cols-2 rounded-xl bg-bg p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeButton, {
					active: value.type === "expense",
					tone: "expense",
					onClick: () => setType("expense"),
					children: "Расход"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeButton, {
					active: value.type === "income",
					tone: "income",
					onClick: () => setType("income"),
					children: "Доход"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-line pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "tx-amount",
					className: "text-xs font-medium text-muted",
					children: "Сумма"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: amountRef,
					id: "tx-amount",
					inputMode: "decimal",
					autoComplete: "off",
					placeholder: "0",
					value: value.amount,
					onChange: (event) => onChange({
						...value,
						amount: event.target.value
					}),
					className: cn("mt-1 w-full bg-transparent font-display text-4xl tabular-nums tracking-tight outline-none placeholder:text-muted", value.type === "income" ? "text-pine" : "text-clay")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "mb-2 text-xs font-medium text-muted",
				children: "Категория"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: categories.map((category) => {
					const selected = category.id === value.categoryId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": selected,
						onClick: () => onChange({
							...value,
							categoryId: category.id
						}),
						className: cn("flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl px-1 py-2 text-xs leading-tight transition-colors", selected ? value.type === "income" ? "bg-pine-soft font-semibold text-pine" : "bg-clay-soft font-semibold text-clay" : "bg-bg text-ink hover:bg-line"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryGlyph, {
							id: category.id,
							className: "size-4"
						}), category.label]
					}, category.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-xs font-medium text-muted",
					htmlFor: "tx-date",
					children: ["Дата", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "tx-date",
						type: "date",
						required: true,
						value: value.date,
						onChange: (event) => onChange({
							...value,
							date: event.target.value
						}),
						className: "mt-1 h-11 w-full rounded-xl border border-line bg-bg px-3 text-sm font-medium text-ink"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-xs font-medium text-muted",
					htmlFor: "tx-note",
					children: ["Комментарий", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "tx-note",
						maxLength: 80,
						value: value.note,
						placeholder: "Необязательно",
						onChange: (event) => onChange({
							...value,
							note: event.target.value
						}),
						className: "mt-1 h-11 w-full rounded-xl border border-line bg-bg px-3 text-sm text-ink placeholder:text-muted"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-bg px-3 py-3 text-sm",
				"aria-live": "polite",
				children: preview ? preview.inView ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Остаток станет ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
					cents: preview.next,
					size: "inline"
				})] }) : "Дата в другом месяце — этот остаток не изменится" : "Остаток пересчитается сразу после сохранения"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-sm font-medium text-clay",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: cn("h-12 flex-1 rounded-xl text-sm font-semibold", value.type === "income" ? "bg-pine text-on-pine" : "bg-ink text-on-ink"),
					children: value.id ? "Сохранить" : value.type === "income" ? "Добавить доход" : "Добавить расход"
				}), value.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onCancel,
					className: "h-12 rounded-xl bg-bg px-4 text-sm font-semibold text-ink",
					children: "Отмена"
				}) : null]
			})
		]
	});
}
function TypeButton({ active, tone, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: cn("rounded-lg text-sm font-semibold transition-colors", active ? tone === "income" ? "bg-pine text-on-pine" : "bg-clay text-on-clay" : "text-muted"),
		children
	});
}
function BudgetApp() {
	const transactions = useBudget((state) => state.transactions);
	const add = useBudget((state) => state.add);
	const update = useBudget((state) => state.update);
	const remove = useBudget((state) => state.remove);
	const clearAll = useBudget((state) => state.clearAll);
	const loadExample = useBudget((state) => state.loadExample);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [month, setMonth] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)(null);
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const [pendingClear, setPendingClear] = (0, import_react.useState)(false);
	const amountRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		let ran = false;
		const done = () => {
			if (cancel || ran) return;
			ran = true;
			const state = useBudget.getState();
			if (!state.initialized) state.loadExample();
			const nextMonth = /* @__PURE__ */ new Date();
			const key = `${nextMonth.getFullYear()}-${String(nextMonth.getMonth() + 1).padStart(2, "0")}`;
			setMonth(key);
			setForm(blankDraft(key));
			setReady(true);
		};
		const persist = useBudget.persist;
		if (!persist) {
			done();
			return;
		}
		const unsubscribe = persist.onFinishHydration(() => done());
		Promise.resolve(persist.rehydrate()).catch(() => done());
		return () => {
			cancel = true;
			unsubscribe();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (window.matchMedia("(min-width: 1024px)").matches) return;
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		amountRef.current?.focus();
		return () => {
			document.body.style.overflow = previous;
		};
	}, [open]);
	const monthTxs = (0, import_react.useMemo)(() => month ? transactions.filter((tx) => monthOf(tx.date) === month) : [], [transactions, month]);
	const totals = (0, import_react.useMemo)(() => summarize(monthTxs), [monthTxs]);
	const slices = (0, import_react.useMemo)(() => expenseSlices(monthTxs), [monthTxs]);
	const visible = filter ? monthTxs.filter((tx) => tx.categoryId === filter) : monthTxs;
	const draftCents = form ? parseRubles(form.amount) : null;
	const projection = form && month && draftCents != null ? projectBalance({
		balance: totals.balance,
		month,
		txs: transactions,
		draft: {
			id: form.id,
			type: form.type,
			amount: draftCents,
			date: form.date
		}
	}) : null;
	const liveBalance = projection?.changed ? projection.next : totals.balance;
	const show = ready && month != null && form != null;
	function submit() {
		if (!form || !month) return;
		const amount = parseRubles(form.amount);
		if (amount == null) {
			setError("Введите сумму больше нуля");
			amountRef.current?.focus();
			return;
		}
		if (!/^\d{4}-\d{2}-\d{2}$/.test(form.date)) {
			setError("Укажите дату");
			return;
		}
		const next = {
			type: form.type,
			amount,
			categoryId: form.categoryId,
			date: form.date,
			note: form.note.trim().slice(0, 80)
		};
		if (form.id) update(form.id, next);
		else add(next);
		const targetMonth = monthOf(form.date);
		setMonth(targetMonth);
		setForm(blankDraft(targetMonth));
		setError("");
		setOpen(false);
		setFilter(null);
	}
	function cancel() {
		if (!month) return;
		setForm(blankDraft(month));
		setError("");
		setOpen(false);
	}
	function edit(tx) {
		setForm({
			id: tx.id,
			type: tx.type,
			amount: formatAmountInput(tx.amount),
			categoryId: tx.categoryId,
			date: tx.date,
			note: tx.note
		});
		setError("");
		setOpen(true);
		amountRef.current?.focus();
	}
	const tone = liveBalance > 0 ? "good" : liveBalance < 0 ? "bad" : "flat";
	const status = liveBalance > 0 ? "в плюсе" : liveBalance < 0 ? "дефицит" : "ноль";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-6xl px-4 py-4 lg:px-8 lg:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 -mx-4 mb-5 border-b border-line bg-bg/90 px-4 py-3 backdrop-blur lg:-mx-8 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-2.5 rounded-full bg-pine",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-xl font-semibold tracking-tight",
								children: "Смета"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Личный бюджет"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							if (month && form?.id) {
								setForm(blankDraft(month));
								setError("");
							}
							setOpen(true);
						},
						className: "inline-flex h-11 items-center gap-2 rounded-xl bg-ink pl-4 pr-3.5 text-sm font-semibold text-on-ink lg:hidden",
						children: ["Добавить", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "size-4",
							"aria-hidden": true
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 items-center rounded-2xl bg-surface p-1 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Предыдущий месяц",
								disabled: !month,
								onClick: () => month && setMonth(shiftMonth(month, -1)),
								className: "flex size-11 items-center justify-center rounded-xl hover:bg-bg disabled:opacity-40",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
									className: "size-5",
									"aria-hidden": true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "min-w-0 flex-1 text-center text-sm font-semibold",
								children: month ? formatMonthLabel(month) : "Загрузка"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Следующий месяц",
								disabled: !month,
								onClick: () => month && setMonth(shiftMonth(month, 1)),
								className: "flex size-11 items-center justify-center rounded-xl hover:bg-bg disabled:opacity-40",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
									className: "size-5",
									"aria-hidden": true
								})
							})
						]
					}), month && month !== currentKey() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setMonth(currentKey()),
						className: "h-11 shrink-0 rounded-xl px-3 text-sm font-semibold text-pine",
						children: "Сегодня"
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5 lg:grid lg:grid-cols-5 lg:items-start lg:gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "contents lg:col-span-3 lg:flex lg:flex-col lg:gap-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "order-1 rounded-3xl bg-ink px-6 py-7 text-on-ink shadow-card lg:order-none",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-on-ink-soft",
										children: month ? `Остаток за ${formatMonthLabel(month)}` : "Остаток"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("rounded-full px-2.5 py-1 text-xs font-semibold", projection?.changed ? "bg-surface/15 text-on-ink" : tone === "good" ? "bg-pine text-on-pine" : tone === "bad" ? "bg-clay text-on-clay" : "bg-surface/15 text-on-ink"),
										children: projection?.changed ? "черновик" : status
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4",
									"aria-live": "polite",
									children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
										cents: liveBalance,
										size: "hero",
										sign: "auto",
										className: "text-on-ink"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-12 w-48 animate-pulse rounded-xl bg-surface/15" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-on-ink-soft",
									children: projection?.changed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["если сохранить · сейчас ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
										cents: totals.balance,
										size: "inline",
										sign: "auto"
									})] }) : "доходы минус расходы"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "order-2 grid grid-cols-2 gap-3 lg:order-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Доходы",
								cents: totals.income,
								ready: show,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
									className: "size-4",
									"aria-hidden": true
								}),
								tone: "income"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Расходы",
								cents: totals.expense,
								ready: show,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
									className: "size-4",
									"aria-hidden": true
								}),
								tone: "expense"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "order-5 lg:order-none",
							children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerList, {
								items: visible,
								filterLabel: filter ? categoryById(filter)?.label ?? null : null,
								pendingDelete,
								pendingClear,
								onEdit: edit,
								onAskDelete: setPendingDelete,
								onConfirmDelete: () => {
									if (pendingDelete) {
										if (form?.id === pendingDelete) cancel();
										remove(pendingDelete);
									}
									setPendingDelete(null);
								},
								onCancelDelete: () => setPendingDelete(null),
								onClearFilter: () => setFilter(null),
								onAskClear: () => setPendingClear(true),
								onConfirmClear: () => {
									clearAll();
									setPendingClear(false);
									setFilter(null);
									if (month) setForm(blankDraft(month));
								},
								onCancelClear: () => setPendingClear(false),
								onLoadExample: () => {
									loadExample();
									setFilter(null);
								}
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-48 animate-pulse rounded-3xl bg-surface shadow-card" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "contents lg:col-span-2 lg:flex lg:min-w-0 lg:flex-col lg:gap-5",
					children: [
						open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Закрыть форму",
							className: "fixed inset-0 z-40 bg-ink/40 lg:hidden",
							onClick: () => setOpen(false)
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
							className: cn("order-6 min-w-0 lg:order-none lg:static", open ? "fixed inset-0 z-50 block overflow-y-auto bg-bg px-4 py-4" : "hidden lg:block"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-3xl bg-surface p-5 shadow-card",
								children: form ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionForm, {
									value: form,
									error,
									preview: projection ? {
										next: projection.next,
										inView: projection.inView
									} : null,
									showCancel: open,
									amountRef,
									onChange: (next) => {
										setForm(next);
										setError("");
									},
									onSubmit: submit,
									onCancel: cancel
								}) : null
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "order-3 lg:order-none",
							children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalCard, { balance: totals.balance }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-44 animate-pulse rounded-3xl bg-surface shadow-card" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "order-4 rounded-3xl bg-surface p-5 shadow-card lg:order-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-semibold",
								children: "Расходы по категориям"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseChart, {
									slices,
									total: totals.expense,
									activeId: filter,
									onSelect: setFilter
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-6 size-40 animate-pulse rounded-full bg-bg" })
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-center text-xs text-muted",
				children: "Суммы хранятся только в этом браузере."
			})
		]
	});
}
function Stat({ label, cents, ready, icon, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-surface px-4 py-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-sm text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("flex size-8 items-center justify-center rounded-full", tone === "income" ? "bg-pine-soft text-pine" : "bg-clay-soft text-clay"),
				children: icon
			}), label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children: ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
				cents,
				size: "stat",
				className: tone === "income" ? "text-pine" : "text-clay"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-8 w-24 animate-pulse rounded-lg bg-bg" })
		})]
	});
}
function currentKey() {
	const now = /* @__PURE__ */ new Date();
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetApp, {});
}
//#endregion
export { Home as component };
