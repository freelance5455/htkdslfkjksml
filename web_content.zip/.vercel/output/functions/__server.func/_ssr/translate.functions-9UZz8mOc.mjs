import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/translate.functions-9UZz8mOc.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var LANGUAGE_NAMES = {
	af: "الأفريقانية",
	ar: "العربية",
	bg: "البلغارية",
	bn: "البنغالية",
	ca: "الكتالونية",
	cs: "التشيكية",
	da: "الدنماركية",
	de: "الألمانية",
	el: "اليونانية",
	en: "الإنجليزية",
	es: "الإسبانية",
	et: "الإستونية",
	fa: "الفارسية",
	fi: "الفنلندية",
	fr: "الفرنسية",
	he: "العبرية",
	hi: "الهندية",
	hr: "الكرواتية",
	hu: "المجرية",
	id: "الإندونيسية",
	it: "الإيطالية",
	ja: "اليابانية",
	ko: "الكورية",
	lt: "الليتوانية",
	lv: "اللاتفية",
	ms: "الملايوية",
	nl: "الهولندية",
	no: "النرويجية",
	pl: "البولندية",
	pt: "البرتغالية",
	ro: "الرومانية",
	ru: "الروسية",
	sk: "السلوفاكية",
	sl: "السلوفينية",
	sv: "السويدية",
	sw: "السواحيلية",
	th: "التايلاندية",
	tr: "التركية",
	uk: "الأوكرانية",
	ur: "الأردية",
	vi: "الفيتنامية",
	zh: "الصينية"
};
var cache = /* @__PURE__ */ new Map();
var hits = [];
var MAX_CHARS = 4e3;
var CACHE_LIMIT = 80;
var RATE_LIMIT = 30;
function isMostlyArabic(text) {
	const arabic = text.match(/[\u0600-\u06FF]/g)?.length ?? 0;
	const foreign = text.match(/[A-Za-z\u00C0-\u024F\u0400-\u04FF\u0590-\u05FF\u0900-\u097F\u3040-\u30FF\u4E00-\u9FFF\uAC00-\uD7AF]/g)?.length ?? 0;
	return arabic >= 4 && arabic > foreign * 1.5;
}
function languageName(code) {
	const base = code.toLowerCase();
	return LANGUAGE_NAMES[base] ?? LANGUAGE_NAMES[base.split("-")[0] ?? ""] ?? "لغة أخرى";
}
function remember(key, value) {
	if (cache.size >= CACHE_LIMIT) {
		const oldest = cache.keys().next().value;
		if (oldest) cache.delete(oldest);
	}
	cache.set(key, value);
}
function limited() {
	const now = Date.now();
	while (hits.length > 0) {
		const first = hits[0];
		if (first === void 0 || now - first <= 6e4) break;
		hits.shift();
	}
	if (hits.length >= RATE_LIMIT) return true;
	hits.push(now);
	return false;
}
function splitForTranslate(text, limit = 900) {
	if (text.length <= limit) return [text];
	const parts = [];
	let rest = text;
	while (rest.length > limit) {
		let cut = rest.lastIndexOf("\n", limit);
		if (cut < limit * .4) cut = rest.lastIndexOf(" ", limit);
		if (cut < limit * .4) cut = limit;
		parts.push(rest.slice(0, cut));
		rest = rest.slice(cut);
	}
	if (rest) parts.push(rest);
	return parts;
}
async function googlePiece(text) {
	try {
		const clients = await fetchClients5(text);
		if (clients) return clients;
	} catch {}
	return fetchGtx(text);
}
async function fetchClients5(text) {
	const url = new URL("https://clients5.google.com/translate_a/t");
	url.searchParams.set("client", "dict-chrome-ex");
	url.searchParams.set("sl", "auto");
	url.searchParams.set("tl", "ar");
	url.searchParams.set("q", text);
	const res = await fetch(url, {
		headers: { Accept: "application/json" },
		signal: AbortSignal.timeout(12e3)
	});
	if (!res.ok) return null;
	return readClientsPayload(await res.json());
}
function readClientsPayload(data) {
	if (!Array.isArray(data) || data.length === 0) return null;
	const rows = data.filter((row) => Array.isArray(row) && typeof row[0] === "string");
	if (rows.length === 0) return null;
	const arabic = rows.map((row) => row[0] ?? "").join("").trim();
	const langCode = typeof rows[0]?.[1] === "string" ? rows[0][1] : "";
	if (!arabic) return null;
	return {
		arabic,
		langCode
	};
}
async function fetchGtx(text) {
	const url = new URL("https://translate.googleapis.com/translate_a/single");
	url.searchParams.set("client", "gtx");
	url.searchParams.set("sl", "auto");
	url.searchParams.set("tl", "ar");
	url.searchParams.set("dt", "t");
	url.searchParams.set("dj", "1");
	url.searchParams.set("q", text);
	const res = await fetch(url, {
		headers: { Accept: "application/json" },
		signal: AbortSignal.timeout(12e3)
	});
	if (!res.ok) throw new Error("translate-unavailable");
	const data = await res.json();
	const sentences = data.sentences ?? [];
	const withOrig = sentences.filter((sentence) => sentence.orig);
	const arabic = (withOrig.length > 0 ? withOrig : sentences).map((sentence) => sentence.trans ?? "").join("").trim();
	if (!arabic) throw new Error("translate-empty");
	return {
		arabic,
		langCode: data.src || ""
	};
}
async function translateToArabic(raw) {
	const text = raw.replace(/\r\n/g, "\n").trim();
	if (!text) return {
		ok: false,
		error: "أدخل نص الرسالة أولاً."
	};
	if (text.length > MAX_CHARS) return {
		ok: false,
		error: "الرسالة طويلة. الحد ٤٠٠٠ حرف."
	};
	const cached = cache.get(text);
	if (cached) return cached;
	if (isMostlyArabic(text)) {
		const result = {
			ok: true,
			arabic: text,
			language: "العربية",
			unchanged: true
		};
		remember(text, result);
		return result;
	}
	if (limited()) return {
		ok: false,
		error: "طلبات كثيرة خلال دقيقة. انتظر قليلاً ثم أعد المحاولة."
	};
	try {
		const pieces = splitForTranslate(text);
		const translated = [];
		let langCode = "";
		for (const piece of pieces) {
			if (!piece.trim()) {
				translated.push(piece);
				continue;
			}
			const part = await googlePiece(piece);
			if (!langCode) langCode = part.langCode;
			translated.push(part.arabic);
		}
		const arabic = translated.join("").trim();
		if (!arabic) return {
			ok: false,
			error: "لم تصل ترجمة لهذه الرسالة."
		};
		const unchanged = langCode === "ar";
		const result = {
			ok: true,
			arabic: unchanged ? text : arabic,
			language: languageName(langCode),
			unchanged
		};
		remember(text, result);
		return result;
	} catch {
		return {
			ok: false,
			error: "تعذّر الاتصال بالترجمة. حاول بعد لحظات."
		};
	}
}
var translateMessage_createServerFn_handler = createServerRpc({
	id: "2d8ccda29d54bae8673efff69d6f26db8a1803f79d1dd69a9ed2e7ecc7c81ef2",
	name: "translateMessage",
	filename: "src/lib/translate.functions.ts"
}, (opts) => translateMessage.__executeServer(opts));
var translateMessage = createServerFn({ method: "POST" }).validator((input) => ({ text: typeof input?.text === "string" ? input.text : "" })).handler(translateMessage_createServerFn_handler, async ({ data }) => translateToArabic(data.text));
//#endregion
export { translateMessage_createServerFn_handler };
