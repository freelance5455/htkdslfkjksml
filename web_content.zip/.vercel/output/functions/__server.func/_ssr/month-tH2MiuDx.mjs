import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { g as ChevronLeft, h as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as format } from "../_libs/date-fns.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as parseMonth, E as shiftMonth, S as parseDay, b as monthCells, d as inkOn, i as usePlanner, k as cn, n as Route$7, o as MONTH_TONES, p as monthTone, v as useTodayKey, w as sameMonth, y as dayKey } from "./router-CQnHyG8o.mjs";
import { i as ColorDot, n as Card, o as IconButton, r as CardTitle, s as PageHeader, t as AddRow } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/month-tH2MiuDx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MonthView({ initialKey }) {
	const today = useTodayKey();
	const [cursor, setCursor] = (0, import_react.useState)(initialKey ?? null);
	(0, import_react.useEffect)(() => {
		if (initialKey) setCursor(initialKey);
	}, [initialKey]);
	const active = cursor ?? (today ? today.slice(0, 7) : null);
	if (!active || !today) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		section: "month",
		title: "Month",
		lede: "Opening the month."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthPage, {
		monthId: active,
		today,
		onMonth: setCursor
	});
}
function MonthPage({ monthId, today, onMonth }) {
	const month = usePlanner((s) => s.months[monthId]);
	const patchMonth = usePlanner((s) => s.patchMonth);
	const anchor = parseMonth(monthId);
	const cells = monthCells(anchor);
	const [selected, setSelected] = (0, import_react.useState)(today.slice(0, 7) === monthId ? today : dayKey(anchor));
	const color = monthTone(monthId, month?.color);
	const events = month?.events ?? [];
	const intention = month?.intention ?? "";
	const selectedEvents = events.filter((event) => event.date === selected);
	(0, import_react.useEffect)(() => {
		setSelected(today.slice(0, 7) === monthId ? today : `${monthId}-01`);
	}, [monthId, today]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		section: "month",
		title: format(anchor, "MMMM"),
		lede: format(anchor, "yyyy"),
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
				label: "Previous month",
				onClick: () => onMonth(shiftMonth(monthId, -1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: "size-5",
					strokeWidth: 1.6
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
				label: "Next month",
				onClick: () => onMonth(shiftMonth(monthId, 1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: "size-5",
					strokeWidth: 1.6
				})
			})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Intention" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: intention,
					onChange: (event) => patchMonth(monthId, (m) => ({
						...m,
						intention: event.target.value
					})),
					placeholder: "What should this month feel like when it is over?",
					rows: 3,
					className: "min-h-20 w-full resize-none bg-transparent font-display text-xl outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: "Month color"
						}),
						MONTH_TONES.map((tone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `Use ${tone}`,
							onClick: () => patchMonth(monthId, (m) => ({
								...m,
								color: tone
							})),
							className: cn("size-11 rounded-full border", color === tone ? "border-ink" : "border-transparent"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-auto block size-5 rounded-full",
								style: { background: tone }
							})
						}, tone)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDot, {
							label: "Custom month color",
							value: color,
							onChange: (next) => patchMonth(monthId, (m) => ({
								...m,
								color: next
							}))
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7 text-center text-xs text-muted",
					children: [
						"Mon",
						"Tue",
						"Wed",
						"Thu",
						"Fri",
						"Sat",
						"Sun"
					].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "py-2",
						children: label
					}, label))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7",
					children: cells.map((day) => {
						const key = dayKey(day);
						const inMonth = sameMonth(day, anchor);
						const marked = events.some((event) => event.date === key);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelected(key),
							className: cn("flex h-12 flex-col items-center justify-center rounded-lg text-sm tabular-nums", !inMonth && "text-muted opacity-50", key === selected && "bg-blush", key === today && "font-medium text-accent"),
							children: [format(day, "d"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-0.5 size-1 rounded-full", marked ? "bg-accent" : "bg-transparent") })]
						}, key);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 inline-flex rounded-full px-3 py-1 text-sm",
					style: {
						background: color,
						color: inkOn(color)
					},
					children: format(parseDay(selected), "EEEE d MMMM")
				}),
				selectedEvents.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Nothing written on this day."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: selectedEvents.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: event.title,
							"aria-label": "Event",
							onChange: (e) => patchMonth(monthId, (m) => ({
								...m,
								events: m.events.map((item) => item.id === event.id ? {
									...item,
									title: e.target.value
								} : item)
							})),
							className: "h-11 min-w-0 flex-1 rounded-lg border border-line bg-card px-3 text-base outline-none"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 px-2 text-sm text-muted",
							onClick: () => {
								const prev = events;
								patchMonth(monthId, (m) => ({
									...m,
									events: m.events.filter((item) => item.id !== event.id)
								}));
								toast("Removed", { action: {
									label: "Undo",
									onClick: () => patchMonth(monthId, (m) => ({
										...m,
										events: prev
									}))
								} });
							},
							children: "Remove"
						})]
					}, event.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddRow, {
					placeholder: "Add to this day",
					onAdd: (title) => patchMonth(monthId, (m) => ({
						...m,
						events: [...m.events, {
							id: uid(),
							date: selected,
							title
						}]
					}))
				})
			] })
		]
	})] });
}
var SplitComponent = function MonthRoute() {
	const { m } = Route$7.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthView, { initialKey: m });
};
//#endregion
export { SplitComponent as component };
