import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as QrCode, r as Download } from "../_libs/lucide-react.mjs";
import { t as require_lib } from "../_libs/qrcode.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-on5YJoJI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = require_lib();
var SIZE_MIN = 128;
var SIZE_MAX = 1024;
var SIZE_STEP = 16;
var EXAMPLE = "https://exemple.fr/atelier";
var PRESETS = [
	{
		id: "encre",
		name: "Encre",
		fg: "#1a1814",
		bg: "#fffdf8"
	},
	{
		id: "nuit",
		name: "Nuit",
		fg: "#f4efe6",
		bg: "#1a1814"
	},
	{
		id: "foret",
		name: "Forêt",
		fg: "#0f6e56",
		bg: "#f3f7f4"
	},
	{
		id: "corail",
		name: "Corail",
		fg: "#9a3412",
		bg: "#fff6f1"
	}
];
var LEVELS = [
	{
		id: "L",
		short: "7 %",
		detail: "Faible. Environ 7 % du motif peut être masqué. Le code reste le plus compact."
	},
	{
		id: "M",
		short: "15 %",
		detail: "Moyen. Environ 15 %. Un bon réglage pour un écran ou une page propre."
	},
	{
		id: "Q",
		short: "25 %",
		detail: "Quartile. Environ 25 %. Utile si le support s’use ou se plie."
	},
	{
		id: "H",
		short: "30 %",
		detail: "Élevé. Environ 30 %. Le motif est plus dense, le texte possible plus court."
	}
];
function normalizeHex(raw) {
	const trimmed = raw.trim();
	const withHash = trimmed.startsWith("#") ? trimmed : `#${trimmed}`;
	if (!/^#[0-9a-fA-F]{6}$/.test(withHash)) return null;
	return withHash.toLowerCase();
}
function clampSize(value) {
	if (!Number.isFinite(value)) return SIZE_MIN;
	return Math.min(SIZE_MAX, Math.max(SIZE_MIN, Math.round(value)));
}
function channel(hex, start) {
	return parseInt(hex.slice(start, start + 2), 16) / 255;
}
function luminance(hex) {
	const lin = [
		1,
		3,
		5
	].map((start) => {
		const s = channel(hex, start);
		return s <= .03928 ? s / 12.92 : ((s + .055) / 1.055) ** 2.4;
	});
	return .2126 * lin[0] + .7152 * lin[1] + .0722 * lin[2];
}
function contrastRatio(fg, bg) {
	const lighter = Math.max(luminance(fg), luminance(bg));
	const darker = Math.min(luminance(fg), luminance(bg));
	return (lighter + .05) / (darker + .05);
}
function frenchError(err) {
	const raw = err instanceof Error ? err.message : "";
	if (/too big|too long|maximum/i.test(raw)) return "Ce texte est trop long pour un QR à ce niveau de correction. Raccourcissez-le, ou choisissez un niveau plus bas.";
	return "Impossible de générer ce code. Vérifiez le texte saisi.";
}
async function downloadPng(dataUrl) {
	const blob = await (await fetch(dataUrl)).blob();
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = "code-qr.png";
	document.body.appendChild(link);
	link.click();
	link.remove();
	URL.revokeObjectURL(url);
}
function ColorField({ id, label, value, draft, onDraft, onBlur, invalid }) {
	const errorId = `${id}-error`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: id,
				className: "text-sm font-medium text-ink",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id,
					className: "color-well shrink-0",
					type: "color",
					value,
					onChange: (event) => onDraft(event.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: `${id}-hex`,
					className: "h-11 w-full rounded-xl border border-line bg-sheet px-3 text-sm tracking-wide text-ink outline-none focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent",
					type: "text",
					inputMode: "text",
					autoCapitalize: "off",
					autoCorrect: "off",
					spellCheck: false,
					maxLength: 7,
					value: draft,
					"aria-label": `${label}, valeur hexadécimale`,
					"aria-invalid": invalid || void 0,
					"aria-describedby": invalid ? errorId : void 0,
					onChange: (event) => onDraft(event.target.value),
					onBlur
				})]
			}),
			invalid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: errorId,
				className: "text-sm text-warn",
				children: "Indiquez 6 chiffres hexadécimaux, par exemple #1A1814."
			}) : null
		]
	});
}
function QrStudio() {
	const [text, setText] = (0, import_react.useState)("");
	const [fg, setFg] = (0, import_react.useState)(PRESETS[0].fg);
	const [bg, setBg] = (0, import_react.useState)(PRESETS[0].bg);
	const [fgDraft, setFgDraft] = (0, import_react.useState)(PRESETS[0].fg);
	const [bgDraft, setBgDraft] = (0, import_react.useState)(PRESETS[0].bg);
	const [fgTouched, setFgTouched] = (0, import_react.useState)(false);
	const [bgTouched, setBgTouched] = (0, import_react.useState)(false);
	const [size, setSize] = (0, import_react.useState)(320);
	const [sizeDraft, setSizeDraft] = (0, import_react.useState)("320");
	const [ecc, setEcc] = (0, import_react.useState)("M");
	const [dataUrl, setDataUrl] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const value = text;
		if (!value.trim()) {
			setDataUrl(null);
			setError(null);
			setPending(false);
			return;
		}
		let cancelled = false;
		setPending(true);
		(0, import_lib.toDataURL)(value, {
			errorCorrectionLevel: ecc,
			width: size,
			margin: 2,
			color: {
				dark: fg,
				light: bg
			}
		}).then((url) => {
			if (cancelled) return;
			setDataUrl(url);
			setError(null);
			setPending(false);
		}).catch((err) => {
			if (cancelled) return;
			setDataUrl(null);
			setError(frenchError(err));
			setPending(false);
		});
		return () => {
			cancelled = true;
		};
	}, [
		text,
		fg,
		bg,
		size,
		ecc
	]);
	const ratio = contrastRatio(fg, bg);
	const lowContrast = ratio < 3;
	const level = LEVELS.find((item) => item.id === ecc) ?? LEVELS[1];
	const trimmed = text.trim();
	let status = "En attente d’un texte ou d’une URL.";
	let tone = "muted";
	if (trimmed && error) {
		status = error;
		tone = "warn";
	} else if (trimmed && !dataUrl) status = "Génération du code…";
	else if (dataUrl && lowContrast) {
		status = `Aperçu à jour · contraste ${ratio.toFixed(1)}:1 · trop faible, le scan peut échouer.`;
		tone = "warn";
	} else if (dataUrl) status = `Aperçu à jour · contraste ${ratio.toFixed(1)}:1.`;
	function commitFg(raw) {
		setFgDraft(raw);
		const next = normalizeHex(raw);
		if (next) {
			setFg(next);
			setFgTouched(false);
		}
	}
	function commitBg(raw) {
		setBgDraft(raw);
		const next = normalizeHex(raw);
		if (next) {
			setBg(next);
			setBgTouched(false);
		}
	}
	function blurFg() {
		const next = normalizeHex(fgDraft);
		if (next) {
			setFg(next);
			setFgDraft(next);
			setFgTouched(false);
			return;
		}
		setFgTouched(true);
	}
	function blurBg() {
		const next = normalizeHex(bgDraft);
		if (next) {
			setBg(next);
			setBgDraft(next);
			setBgTouched(false);
			return;
		}
		setBgTouched(true);
	}
	function applyPreset(nextFg, nextBg) {
		setFg(nextFg);
		setBg(nextBg);
		setFgDraft(nextFg);
		setBgDraft(nextBg);
		setFgTouched(false);
		setBgTouched(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {
						className: "size-5",
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight text-ink",
					children: "Studio QR"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-xl text-sm leading-normal text-muted",
				children: "Le code se redessine pendant la saisie. Téléchargez-le ensuite en PNG."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "qr-layout grid items-start gap-6",
			onSubmit: (event) => {
				event.preventDefault();
				if (dataUrl) downloadPng(dataUrl);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "qr-area-payload flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "payload",
								className: "text-sm font-medium text-ink",
								children: "URL ou texte"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-xl px-3 text-sm font-medium text-accent outline-none focus-visible:ring-2 focus-visible:ring-accent",
								onClick: () => setText(EXAMPLE),
								children: "Essayer un exemple"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "payload",
							className: "min-h-24 w-full resize-y rounded-2xl border border-line bg-sheet px-3 py-3 text-base leading-normal text-ink outline-none focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent",
							value: text,
							placeholder: "https://exemple.fr ou un message",
							autoCapitalize: "off",
							autoCorrect: "off",
							spellCheck: false,
							"aria-invalid": error ? true : void 0,
							"aria-describedby": "payload-hint qr-status",
							onChange: (event) => setText(event.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							id: "payload-hint",
							className: "text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: text.length
							}), " caractères. Liens et texte libre sont acceptés."]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-labelledby": "preview-heading",
					className: "qr-area-preview flex flex-col gap-4 rounded-3xl border border-line bg-sheet p-4 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "preview-heading",
								className: "text-sm font-medium text-ink",
								children: "Aperçu"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm tabular-nums text-muted",
								children: [
									size,
									" × ",
									size,
									" px"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-2xl border border-line bg-paper p-4",
							children: dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: dataUrl,
								alt: `Code QR pour ${trimmed.slice(0, 120)}`,
								width: size,
								height: size,
								className: `qr-preview mx-auto aspect-square w-full max-w-72 sm:max-w-80 lg:max-w-none ${pending ? "opacity-70" : ""}`
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex h-36 w-full flex-col items-center justify-center gap-2 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {
									className: "size-8 text-muted",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-xs text-sm text-muted",
									children: "Le code apparaît ici dès le premier caractère."
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "qr-status",
							role: "status",
							className: `text-sm leading-normal ${tone === "warn" ? "text-warn" : "text-muted"}`,
							children: status
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: !dataUrl,
							className: "flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-accent text-base font-medium text-accent-ink outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-sheet disabled:opacity-40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-5",
								"aria-hidden": "true"
							}), "Télécharger le PNG"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-labelledby": "settings-heading",
					className: "qr-area-settings flex flex-col gap-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "settings-heading",
							className: "text-sm font-medium text-ink",
							children: "Réglages"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: "preset-label",
								className: "text-sm font-medium text-ink",
								children: "Couleurs prédéfinies"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
								role: "group",
								"aria-labelledby": "preset-label",
								children: PRESETS.map((preset) => {
									const active = fg === preset.fg && bg === preset.bg;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-pressed": active,
										className: `flex min-h-11 items-center justify-center gap-2 rounded-xl border px-2 text-sm font-medium outline-none focus-visible:ring-2 focus-visible:ring-accent ${active ? "border-accent bg-accent text-accent-ink" : "border-line bg-sheet text-ink"}`,
										onClick: () => applyPreset(preset.fg, preset.bg),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex overflow-hidden rounded-md",
											"aria-hidden": "true",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "size-4",
												style: { backgroundColor: preset.fg }
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "size-4",
												style: { backgroundColor: preset.bg }
											})]
										}), preset.name]
									}, preset.id);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
								id: "fg",
								label: "Couleur du premier plan",
								value: fg,
								draft: fgDraft,
								invalid: fgTouched && normalizeHex(fgDraft) === null,
								onDraft: commitFg,
								onBlur: blurFg
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
								id: "bg",
								label: "Couleur de l’arrière-plan",
								value: bg,
								draft: bgDraft,
								invalid: bgTouched && normalizeHex(bgDraft) === null,
								onDraft: commitBg,
								onBlur: blurBg
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Premier plan : les modules du code. Arrière-plan : le fond autour."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "size",
										className: "text-sm font-medium text-ink",
										children: "Taille"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("output", {
										htmlFor: "size",
										className: "text-sm tabular-nums text-muted",
										children: [size, " px"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "size",
										className: "size-range",
										type: "range",
										min: SIZE_MIN,
										max: SIZE_MAX,
										step: SIZE_STEP,
										value: size,
										"aria-valuetext": `${size} pixels`,
										"aria-describedby": "size-hint",
										onChange: (event) => {
											const next = clampSize(Number(event.target.value));
											setSize(next);
											setSizeDraft(String(next));
										}
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "size-px",
										className: "h-11 w-24 shrink-0 rounded-xl border border-line bg-sheet px-3 text-sm tabular-nums text-ink outline-none focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent",
										type: "number",
										inputMode: "numeric",
										min: SIZE_MIN,
										max: SIZE_MAX,
										value: sizeDraft,
										"aria-label": "Taille en pixels",
										onChange: (event) => {
											const raw = event.target.value;
											setSizeDraft(raw);
											if (!/^\d+$/.test(raw)) return;
											const next = Number(raw);
											if (next >= SIZE_MIN && next <= SIZE_MAX) setSize(next);
										},
										onBlur: () => {
											if (!/^\d+$/.test(sizeDraft)) {
												setSizeDraft(String(size));
												return;
											}
											const next = clampSize(Number(sizeDraft));
											setSize(next);
											setSizeDraft(String(next));
										}
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									id: "size-hint",
									className: "text-sm text-muted",
									children: [
										"Le fichier PNG mesure ",
										size,
										" pixels de côté, entre ",
										SIZE_MIN,
										" et ",
										SIZE_MAX,
										"."
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "text-sm font-medium text-ink",
									children: "Niveau de correction d’erreurs"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
									children: LEVELS.map((item) => {
										const selected = ecc === item.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: `flex min-h-11 cursor-pointer flex-col items-center justify-center rounded-xl border px-2 py-2 text-center outline-none focus-within:ring-2 focus-within:ring-accent focus-within:ring-offset-2 focus-within:ring-offset-paper ${selected ? "border-accent bg-accent text-accent-ink" : "border-line bg-sheet text-ink"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													className: "sr-only",
													type: "radio",
													name: "ecc",
													value: item.id,
													checked: selected,
													onChange: () => setEcc(item.id)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm font-semibold",
													children: item.id
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-xs ${selected ? "text-accent-ink" : "text-muted"}`,
													children: item.short
												})
											]
										}, item.id);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: level.detail
								})
							]
						})
					]
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrStudio, {});
}
//#endregion
export { Home as component };
