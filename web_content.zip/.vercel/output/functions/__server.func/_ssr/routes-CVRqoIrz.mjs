import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as leagueById, n as SUGGESTED_CLUBS, r as initials, t as LEAGUES } from "./catalog-J4SrKMs0.mjs";
import { a as RefreshCw, c as House, d as ChevronRight, f as ChevronLeft, h as Bell, i as Search, l as History, m as Bot, o as Newspaper, p as ChartColumn, r as Star, s as Menu, t as Trophy, u as Earth } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CVRqoIrz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function ymd$1(value) {
	if (!/^\d{8}$/.test(value)) throw new Error("bad date");
	return value;
}
var fetchHome = createServerFn({ method: "GET" }).validator((input) => ({
	today: ymd$1(input.today),
	tomorrow: ymd$1(input.tomorrow)
})).handler(createSsrRpc("6c8967caee8dacb6068c727131691ee2a88f68ac12f81bed0df35104c9a9a8cd"));
var fetchBoard = createServerFn({ method: "GET" }).validator((input) => ({ dates: (input.dates ?? []).filter((d) => /^\d{8}$/.test(d)).slice(0, 7) })).handler(createSsrRpc("f638fa8d9d6499f48200f613502584f1e56ce94d494db2e222c17a808a497a28"));
var fetchLeague = createServerFn({ method: "GET" }).validator((id) => {
	if (typeof id !== "string" || id.length < 2 || id.length > 80) throw new Error("bad league");
	return id;
}).handler(createSsrRpc("e3e0b969a488ee1cedea7aa03dd5fdaf7ba0b665d822113963b27ba6ba8f07c4"));
var fetchTeam = createServerFn({ method: "GET" }).validator((input) => input).handler(createSsrRpc("2dca60edffd6562f7155f4a493d72b02c2f51d9dd0d72ad4b5ddbce1358f824b"));
var fetchMatch = createServerFn({ method: "GET" }).validator((input) => input).handler(createSsrRpc("cfb23f8752e86a05951b919d613363d22f6e9145a543949954e4f6f35c932ba3"));
var fetchPlayer = createServerFn({ method: "GET" }).validator((input) => input).handler(createSsrRpc("882985e2bac589c6918fd33f32839b6d309717193107d0822b8e1b75fc1332b8"));
var fetchH2H = createServerFn({ method: "GET" }).validator((input) => input).handler(createSsrRpc("cb2401235f1aafa4139224ab2d59742643fd34ee2c145239dcebc46d16d7bda4"));
var fetchSearch = createServerFn({ method: "GET" }).validator((q) => String(q ?? "").trim().slice(0, 60)).handler(createSsrRpc("91f6d7ce87ad61bf23d3b1be24ca8a2ab0ba61f85dddaac04da66546ad4d84dd"));
var askAssistant = createServerFn({ method: "POST" }).validator((input) => ({
	question: String(input.question ?? "").trim().slice(0, 600),
	lang: input.lang === "en" ? "en" : "ar",
	today: /^\d{8}$/.test(input.today ?? "") ? input.today : ""
})).handler(createSsrRpc("602d2a4cc06895d44cde6d79658eae6430fd2a3d795d46608d88901d2bf1e7cf"));
var KEY = "fap-cache-v1";
function readBag() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return {};
		const parsed = JSON.parse(raw);
		return parsed && typeof parsed === "object" ? parsed : {};
	} catch {
		return {};
	}
}
function readCache(key) {
	const hit = readBag()[key];
	if (!hit || typeof hit.at !== "string") return null;
	return hit;
}
function writeCache(key, data) {
	try {
		const bag = readBag();
		bag[key] = {
			at: (/* @__PURE__ */ new Date()).toISOString(),
			data
		};
		const keys = Object.keys(bag);
		if (keys.length > 36) delete bag[keys[0]];
		localStorage.setItem(KEY, JSON.stringify(bag));
	} catch {}
}
var ar = {
	app: "FOOTBALL AI PRO",
	home: "الرئيسية",
	matches: "المباريات",
	leagues: "البطولات",
	insights: "التحليل",
	assistant: "المساعد",
	news: "الأخبار",
	settings: "الإعدادات",
	search: "بحث",
	favorites: "المفضلة",
	nations: "المنتخبات",
	history: "آخر ما شاهدت",
	today: "اليوم",
	tomorrow: "الغد",
	live: "مباشر",
	upcoming: "قادمة",
	past: "منتهية",
	week: "أسبوع",
	refresh: "تحديث",
	refreshing: "جارٍ التحديث",
	updated: "آخر تحديث ناجح",
	saved: "بيانات محفوظة وليست تحديثاً جديداً",
	offline: "لا يوجد اتصال. نعرض آخر بيانات صحيحة.",
	emptyMatches: "لا توجد مباريات في هذا التصنيف حسب المصادر المتاحة.",
	emptyNews: "لا توجد أخبار من المصدر حالياً.",
	loading: "جارٍ جلب البيانات الحقيقية…",
	failed: "تعذر جلب البيانات. تحقق من الاتصال ثم أعد المحاولة.",
	featured: "الأكثر متابعة",
	arab: "دوريات عربية",
	europe: "دوريات أوروبية",
	africaWorld: "أفريقيا وبطولات دولية",
	asia: "آسيا",
	americas: "الأمريكتان",
	standings: "الترتيب",
	results: "النتائج",
	fixtures: "المباريات القادمة",
	teams: "الفرق",
	scorers: "الهدافون",
	assists: "صانعو الأهداف",
	squad: "التشكيلة",
	compare: "مقارنة",
	compareTeams: "مقارنة فريقين",
	comparePlayers: "مقارنة لاعبين",
	h2h: "المواجهات السابقة",
	prediction: "توقع إحصائي",
	notFact: "توقع وليس نتيجة",
	notify: "إشعارات المباريات",
	notifyHint: "تعمل أثناء فتح التطبيق أو بقاء الصفحة بالخلفية. لا يوجد تحديث بعد إغلاق التطبيق تماماً.",
	theme: "المظهر",
	dark: "ليلي",
	light: "نهاري",
	font: "حجم الخط",
	sm: "صغير",
	md: "متوسط",
	lg: "كبير",
	language: "اللغة",
	sources: "الشعارات والنتائج من ESPN وTheSportsDB وOpenLigaDB. لا نعرض أرقاماً مخترعة. FootyLogos لا يسمح بالربط المباشر، لذلك تُستخدم شعارات المصادر الرسمية مع اختصار النادي إذا تعذر تحميل الصورة.",
	reset: "إعادة الضبط",
	pickFav: "اختر أندية مفضلة",
	noFav: "لم تختر أندية بعد.",
	add: "إضافة",
	added: "في المفضلة",
	open: "فتح",
	back: "رجوع",
	season: "الموسم",
	played: "لعب",
	pts: "نقاط",
	gd: "فارق",
	ask: "اسأل عن نتيجة أو ترتيب أو موعد",
	send: "إرسال",
	thinking: "أحلل البيانات المتاحة…",
	facts: "من البيانات",
	model: "تحليل",
	noScorers: "الهدافون غير متاحين من هذا المصدر حالياً.",
	noAssists: "صانعو الأهداف غير متاحين من هذا المصدر.",
	noSquad: "القائمة غير متاحة من المصدر.",
	stats: "إحصائيات المباراة",
	timeline: "أحداث",
	venue: "الملعب",
	searchPh: "نادي، لاعب، أو بطولة",
	date: "تاريخ",
	all: "الكل",
	partial: "جدول جزئي من المصدر المجاني",
	notificationsTitle: "تنبيهاتك",
	noAlerts: "لا توجد مباريات مفضلة قريبة أو مباشرة الآن.",
	enableNotify: "تفعيل إشعارات المتصفح",
	record: "السجل",
	next: "القادمة",
	position: "المركز",
	age: "العمر",
	nation: "الجنسية",
	goals: "أهداف",
	vs: "ضد",
	insufficient: "البيانات لا تكفي لتوقع مسؤول.",
	clear: "مسح"
};
var en = {
	app: "FOOTBALL AI PRO",
	home: "Home",
	matches: "Matches",
	leagues: "Competitions",
	insights: "Analysis",
	assistant: "Assistant",
	news: "News",
	settings: "Settings",
	search: "Search",
	favorites: "Favorites",
	nations: "National teams",
	history: "Recently viewed",
	today: "Today",
	tomorrow: "Tomorrow",
	live: "Live",
	upcoming: "Upcoming",
	past: "Finished",
	week: "Week",
	refresh: "Refresh",
	refreshing: "Refreshing",
	updated: "Last successful update",
	saved: "Saved data, not a fresh update",
	offline: "Offline. Showing the last good data.",
	emptyMatches: "No matches in this filter from the available sources.",
	emptyNews: "No news from the source right now.",
	loading: "Loading real data…",
	failed: "Could not load data. Check the connection and retry.",
	featured: "Most followed",
	arab: "Arab leagues",
	europe: "European leagues",
	africaWorld: "Africa and internationals",
	asia: "Asia",
	americas: "Americas",
	standings: "Table",
	results: "Results",
	fixtures: "Fixtures",
	teams: "Teams",
	scorers: "Scorers",
	assists: "Assists",
	squad: "Squad",
	compare: "Compare",
	compareTeams: "Compare teams",
	comparePlayers: "Compare players",
	h2h: "Head to head",
	prediction: "Statistical estimate",
	notFact: "Estimate, not a result",
	notify: "Match alerts",
	notifyHint: "Works while the app is open or the tab is in the background. Nothing updates after the app is fully closed.",
	theme: "Theme",
	dark: "Dark",
	light: "Light",
	font: "Text size",
	sm: "Small",
	md: "Medium",
	lg: "Large",
	language: "Language",
	sources: "Crests and scores come from ESPN, TheSportsDB, and OpenLigaDB. Numbers are never invented. FootyLogos blocks hotlinking, so official source crests are used, with club initials if an image fails.",
	reset: "Reset",
	pickFav: "Pick favorite clubs",
	noFav: "No favorite clubs yet.",
	add: "Add",
	added: "Favorite",
	open: "Open",
	back: "Back",
	season: "Season",
	played: "P",
	pts: "Pts",
	gd: "GD",
	ask: "Ask about a score, table, or kickoff",
	send: "Send",
	thinking: "Checking the available data…",
	facts: "From the data",
	model: "Analysis",
	noScorers: "Scorers are not available from this source right now.",
	noAssists: "Assists are not available from this source.",
	noSquad: "Squad is not available from the source.",
	stats: "Match stats",
	timeline: "Events",
	venue: "Venue",
	searchPh: "Club, player, or competition",
	date: "Date",
	all: "All",
	partial: "Partial table from the free source",
	notificationsTitle: "Your alerts",
	noAlerts: "No favorite matches are live or starting soon.",
	enableNotify: "Enable browser alerts",
	record: "Record",
	next: "Next",
	position: "Position",
	age: "Age",
	nation: "Nationality",
	goals: "Goals",
	vs: "vs",
	insufficient: "Not enough data for a responsible estimate.",
	clear: "Clear"
};
function copy(lang) {
	return lang === "en" ? en : ar;
}
function estimate(home, away) {
	if (home.played < 3 || away.played < 3) return null;
	const expH = (home.gf / home.played + away.ga / away.played) / 2 * 1.08;
	const expA = (away.gf / away.played + home.ga / home.played) / 2;
	const h = Math.max(.25, expH);
	const a = Math.max(.25, expA);
	const d = 1.05;
	const sum = h + a + d;
	const homePct = Math.round(h / sum * 100);
	const drawPct = Math.round(d / sum * 100);
	let awayPct = 100 - homePct - drawPct;
	if (awayPct < 0) awayPct = 0;
	return {
		home: homePct,
		draw: drawPct,
		away: awayPct,
		goals: Math.round((h + a) * 10) / 10
	};
}
function Crest({ src, name, className = "size-10" }) {
	const [ok, setOk] = (0, import_react.useState)(Boolean(src));
	if (!src || !ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `${className} grid shrink-0 place-items-center rounded-full border border-line bg-surface-2 text-xs font-bold text-fg`,
		children: initials(name)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		className: `${className} shrink-0 rounded-full border border-line bg-surface-2 object-contain`,
		onError: () => setOk(false)
	});
}
function formatWhen(iso, lang, withTime = true) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "—";
	return new Intl.DateTimeFormat(lang === "ar" ? "ar-EG" : "en-GB", {
		month: "short",
		day: "numeric",
		hour: withTime ? "2-digit" : void 0,
		minute: withTime ? "2-digit" : void 0
	}).format(date);
}
function Freshness({ at, stale, busy, t, lang }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-xs text-muted",
		children: [busy ? t.refreshing : stale ? t.saved : t.updated, at ? ` · ${formatWhen(at, lang)}` : ""]
	});
}
function Empty({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 py-8 text-center text-sm text-muted",
		children: text
	});
}
function MatchCard({ match, lang, onOpen }) {
	const league = lang === "ar" ? match.leagueNameAr : match.leagueNameEn;
	const score = match.status === "pre" ? "–" : `${match.home.score ?? 0} - ${match.away.score ?? 0}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: "flex w-full items-center gap-2 rounded-2xl border border-line bg-surface px-3 py-3 text-start",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSide, {
				name: match.home.name,
				logo: match.home.logo
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-16 flex-1 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg font-bold tabular-nums text-accent",
						children: score
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted",
						children: formatWhen(match.kickoff, lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 flex items-center justify-center gap-1",
						children: match.status === "in" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-live px-2 py-0.5 text-xs font-bold text-onlive",
							children: match.statusText || "LIVE"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: league
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSide, {
				name: match.away.name,
				logo: match.away.logo
			})
		]
	});
}
function TeamSide({ name, logo }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex w-24 flex-col items-center gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
			src: logo,
			name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "line-clamp-2 text-center text-xs font-medium",
			children: name
		})]
	});
}
function StandingTable({ rows, t, onTeam }) {
	let lastGroup = "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[36rem] text-center text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-xs text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-1 py-2",
						children: "#"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-1 py-2 text-start",
						children: t.teams
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-1 py-2",
						children: t.played
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-1 py-2",
						children: "W"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-1 py-2",
						children: "D"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-1 py-2",
						children: "L"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-1 py-2",
						children: t.gd
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-1 py-2",
						children: t.pts
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => {
				const showGroup = row.group && row.group !== lastGroup;
				if (row.group) lastGroup = row.group;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [showGroup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 8,
					className: "bg-surface-2 px-3 py-1 text-start text-xs font-semibold text-muted",
					children: row.group
				}) }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 font-bold text-accent",
							children: row.rank || "–"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onTeam(row.team.id),
								className: "flex items-center gap-2 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
									src: row.team.logo,
									name: row.team.name,
									className: "size-7"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: row.team.name
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: row.played }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: row.won }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: row.draw }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: row.lost }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: row.gd }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "font-bold",
							children: row.pts
						})
					]
				})] }, `${row.group ?? ""}-${row.team.id}-${row.rank}`);
			}) })]
		})
	});
}
function SectionTitle({ children, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex items-center justify-between px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-base font-bold",
			children
		}), action]
	});
}
var PREFS_KEY = "fap-prefs-v1";
var DEFAULT_PREFS = {
	lang: "ar",
	mode: "dark",
	theme: "green",
	font: "md",
	favs: [],
	favLeagues: [
		"eng.1",
		"ksa.1",
		"egy"
	],
	recent: [],
	notify: false
};
function loadPrefs() {
	try {
		const raw = localStorage.getItem(PREFS_KEY);
		if (!raw) return DEFAULT_PREFS;
		return {
			...DEFAULT_PREFS,
			...JSON.parse(raw)
		};
	} catch {
		return DEFAULT_PREFS;
	}
}
function ymd(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
}
function shift(days) {
	const date = /* @__PURE__ */ new Date();
	date.setDate(date.getDate() + days);
	return ymd(date);
}
function leagueName(id, lang) {
	const league = leagueById(id);
	if (!league) return id;
	return lang === "ar" ? league.nameAr : league.nameEn;
}
function FootballApp() {
	const [prefs, setPrefs] = (0, import_react.useState)(DEFAULT_PREFS);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [stack, setStack] = (0, import_react.useState)([{ name: "home" }]);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [bell, setBell] = (0, import_react.useState)(false);
	const [home, setHome] = (0, import_react.useState)(null);
	const [homeAt, setHomeAt] = (0, import_react.useState)();
	const [homeStale, setHomeStale] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const screen = stack[stack.length - 1];
	const t = copy(prefs.lang);
	const seen = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const booted = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const stored = loadPrefs();
		setPrefs(stored);
		const cached = readCache("home");
		if (cached) {
			setHome(cached.data);
			setHomeAt(cached.at);
			setHomeStale(true);
		}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const root = document.documentElement;
		root.lang = prefs.lang;
		root.dir = prefs.lang === "ar" ? "rtl" : "ltr";
		root.classList.toggle("light", prefs.mode === "light");
		root.classList.remove("theme-blue", "theme-purple", "theme-orange");
		if (prefs.theme !== "green") root.classList.add(`theme-${prefs.theme}`);
		root.classList.remove("font-sm", "font-lg");
		if (prefs.font === "sm") root.classList.add("font-sm");
		if (prefs.font === "lg") root.classList.add("font-lg");
		try {
			localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
		} catch {}
	}, [prefs, ready]);
	const savePrefs = (patch) => setPrefs((prev) => ({
		...prev,
		...patch
	}));
	const remember = (item) => {
		setPrefs((prev) => ({
			...prev,
			recent: [item, ...prev.recent.filter((r) => !(r.kind === item.kind && r.id === item.id))].slice(0, 12)
		}));
	};
	const open = (next) => setStack((prev) => [...prev, next]);
	const tab = (name) => setStack([{ name }]);
	const back = () => setStack((prev) => prev.length > 1 ? prev.slice(0, -1) : prev);
	const loadHome = (0, import_react.useCallback)(async (force = false) => {
		if (!force) {
			const cached = readCache("home");
			if (cached && Date.now() - new Date(cached.at).getTime() < 45e3) {
				setHome(cached.data);
				setHomeAt(cached.at);
				setHomeStale(false);
				return;
			}
		}
		setBusy(true);
		setError("");
		try {
			const data = await fetchHome({ data: {
				today: ymd(),
				tomorrow: shift(1)
			} });
			setHome(data);
			setHomeAt(data.updatedAt);
			setHomeStale(Boolean(data.stale));
			if (!data.stale && !data.error) writeCache("home", data);
			if (data.error) setError(t.failed);
		} catch {
			const cached = readCache("home");
			if (cached) {
				setHome(cached.data);
				setHomeAt(cached.at);
				setHomeStale(true);
			}
			setError(t.offline);
		} finally {
			setBusy(false);
		}
	}, [t.failed, t.offline]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		loadHome(true);
	}, [ready, loadHome]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const tick = window.setInterval(() => {
			if (document.visibilityState !== "visible") return;
			loadHome(false);
		}, 6e4);
		const onVis = () => {
			if (document.visibilityState === "visible") loadHome(false);
		};
		const onNet = () => {
			if (navigator.onLine) loadHome(true);
		};
		document.addEventListener("visibilitychange", onVis);
		window.addEventListener("online", onNet);
		return () => {
			window.clearInterval(tick);
			document.removeEventListener("visibilitychange", onVis);
			window.removeEventListener("online", onNet);
		};
	}, [ready, loadHome]);
	(0, import_react.useEffect)(() => {
		if (!home || !prefs.notify || typeof Notification === "undefined" || Notification.permission !== "granted") return;
		const interesting = [...home.live, ...home.today].filter((m) => prefs.favs.some((f) => f.id === m.home.id || f.id === m.away.id));
		for (const match of interesting) {
			const key = `${match.id}:${match.status}:${match.home.score}:${match.away.score}`;
			if (!booted.current) {
				seen.current.add(key);
				continue;
			}
			if (seen.current.has(key)) continue;
			seen.current.add(key);
			const title = `${match.home.name} ${match.home.score ?? ""}-${match.away.score ?? ""} ${match.away.name}`;
			try {
				new Notification(title, { body: match.statusText });
			} catch {}
		}
		booted.current = true;
	}, [
		home,
		prefs.favs,
		prefs.notify
	]);
	const alerts = (0, import_react.useMemo)(() => {
		if (!home) return [];
		const soon = Date.now() + 72e5;
		return [
			...home.live,
			...home.today,
			...home.upcoming
		].filter((m) => {
			const fav = prefs.favs.some((f) => f.id === m.home.id || f.id === m.away.id);
			const start = new Date(m.kickoff).getTime();
			return fav && (m.status === "in" || m.status === "pre" && start < soon);
		}).slice(0, 8);
	}, [home, prefs.favs]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "p-6 text-sm text-muted",
		children: t.loading
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-screen max-w-3xl bg-bg pb-24 text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-surface px-3 py-3",
				children: [
					stack.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": t.back,
						onClick: back,
						className: "grid size-10 place-items-center rounded-full border border-line",
						children: prefs.lang === "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 place-items-center rounded-full bg-accent text-sm font-black text-onaccent",
						children: "FA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-sm font-black tracking-wide",
							children: t.app
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Freshness, {
							at: homeAt,
							stale: homeStale,
							busy,
							t,
							lang: prefs.lang
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-label": t.notificationsTitle,
						onClick: () => setBell(true),
						className: "relative grid size-10 place-items-center rounded-full border border-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" }), alerts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1 end-1 size-2 rounded-full bg-live" }) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": t.search,
						onClick: () => tab("search"),
						className: "grid size-10 place-items-center rounded-full border border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "menu",
						onClick: () => setMenu(true),
						className: "grid size-10 place-items-center rounded-full border border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-4 mt-3 rounded-xl border border-line bg-surface px-3 py-2 text-sm text-warn",
				children: error
			}) : null,
			screen.name === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {
				home,
				prefs,
				t,
				busy,
				onRefresh: () => void loadHome(true),
				onMatch: (m) => open({
					name: "match",
					leagueId: m.leagueId,
					id: m.id
				}),
				onLeague: (id) => {
					remember({
						kind: "league",
						id,
						title: leagueName(id, prefs.lang),
						logo: leagueById(id)?.logo ?? null
					});
					open({
						name: "league",
						id
					});
				},
				onTeam: (leagueId, id, name, logo) => {
					remember({
						kind: "team",
						id,
						leagueId,
						title: name,
						logo
					});
					open({
						name: "team",
						leagueId,
						id
					});
				}
			}),
			screen.name === "matches" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchesScreen, {
				lang: prefs.lang,
				t,
				onMatch: (m) => open({
					name: "match",
					leagueId: m.leagueId,
					id: m.id
				})
			}),
			screen.name === "leagues" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeagueList, {
				title: t.leagues,
				leagues: LEAGUES,
				lang: prefs.lang,
				favs: prefs.favLeagues,
				onToggle: (id) => savePrefs({ favLeagues: prefs.favLeagues.includes(id) ? prefs.favLeagues.filter((x) => x !== id) : [...prefs.favLeagues, id] }),
				onOpen: (id) => {
					remember({
						kind: "league",
						id,
						title: leagueName(id, prefs.lang),
						logo: leagueById(id)?.logo ?? null
					});
					open({
						name: "league",
						id
					});
				}
			}),
			screen.name === "league" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeagueScreen, {
				id: screen.id,
				lang: prefs.lang,
				t,
				onMatch: (m) => open({
					name: "match",
					leagueId: m.leagueId,
					id: m.id
				}),
				onTeam: (id) => open({
					name: "team",
					leagueId: screen.id,
					id
				}),
				onPlayer: (playerId, teamId) => open({
					name: "player",
					leagueId: screen.id,
					id: playerId,
					teamId
				})
			}),
			screen.name === "match" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchScreen, {
				leagueId: screen.leagueId,
				id: screen.id,
				lang: prefs.lang,
				t,
				onTeam: (id) => open({
					name: "team",
					leagueId: screen.leagueId,
					id
				})
			}),
			screen.name === "team" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamScreen, {
				leagueId: screen.leagueId,
				id: screen.id,
				lang: prefs.lang,
				t,
				fav: prefs.favs.some((f) => f.id === screen.id),
				onFav: (club) => savePrefs({ favs: prefs.favs.some((f) => f.id === club.id) ? prefs.favs.filter((f) => f.id !== club.id) : [...prefs.favs, club] }),
				onMatch: (m) => open({
					name: "match",
					leagueId: m.leagueId,
					id: m.id
				}),
				onPlayer: (playerId) => open({
					name: "player",
					leagueId: screen.leagueId,
					id: playerId,
					teamId: screen.id
				})
			}),
			screen.name === "player" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerScreen, {
				leagueId: screen.leagueId,
				id: screen.id,
				teamId: screen.teamId,
				lang: prefs.lang,
				t
			}),
			screen.name === "insights" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsScreen, {
				lang: prefs.lang,
				t,
				onMatch: (m) => open({
					name: "match",
					leagueId: m.leagueId,
					id: m.id
				}),
				onPlayer: (leagueId, playerId, teamId) => open({
					name: "player",
					leagueId,
					id: playerId,
					teamId
				})
			}),
			screen.name === "ai" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiScreen, {
				lang: prefs.lang,
				t
			}),
			screen.name === "news" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewsScreen, {
				home,
				lang: prefs.lang,
				t
			}),
			screen.name === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {
				prefs,
				t,
				onChange: savePrefs
			}),
			screen.name === "search" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchScreen, {
				lang: prefs.lang,
				t,
				onLeague: (id) => open({
					name: "league",
					id
				}),
				onTeam: (leagueId, id) => open({
					name: "team",
					leagueId,
					id
				}),
				onPlayer: (leagueId, id) => open({
					name: "player",
					leagueId,
					id
				})
			}),
			screen.name === "favorites" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoritesScreen, {
				prefs,
				t,
				onTeam: (f) => open({
					name: "team",
					leagueId: f.leagueId,
					id: f.id
				}),
				onLeague: (id) => open({
					name: "league",
					id
				}),
				onAdd: (club) => savePrefs({ favs: prefs.favs.some((f) => f.id === club.id) ? prefs.favs : [...prefs.favs, club] })
			}),
			screen.name === "nations" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeagueList, {
				title: t.nations,
				leagues: LEAGUES.filter((l) => l.national),
				lang: prefs.lang,
				favs: prefs.favLeagues,
				onToggle: (id) => savePrefs({ favLeagues: prefs.favLeagues.includes(id) ? prefs.favLeagues.filter((x) => x !== id) : [...prefs.favLeagues, id] }),
				onOpen: (id) => open({
					name: "league",
					id
				})
			}),
			screen.name === "history" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryScreen, {
				items: prefs.recent,
				t,
				onOpen: (item) => {
					if (item.kind === "league") open({
						name: "league",
						id: item.id
					});
					else if (item.kind === "team" && item.leagueId) open({
						name: "team",
						leagueId: item.leagueId,
						id: item.id
					});
					else if (item.kind === "match" && item.leagueId) open({
						name: "match",
						leagueId: item.leagueId,
						id: item.id
					});
					else if (item.kind === "player" && item.leagueId) open({
						name: "player",
						leagueId: item.leagueId,
						id: item.id,
						teamId: item.teamId
					});
				}
			}),
			menu && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-30 bg-bg/70",
				onClick: () => setMenu(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-x-4 bottom-24 rounded-2xl border border-line bg-surface p-2 text-start",
					onClick: (e) => e.stopPropagation(),
					children: [
						["news", t.news],
						["settings", t.settings],
						["nations", t.nations],
						["favorites", t.favorites],
						["history", t.history]
					].map(([name, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "block w-full rounded-xl px-3 py-3 text-start hover:bg-surface-2",
						onClick: () => {
							setMenu(false);
							tab(name);
						},
						children: label
					}, name))
				})
			}),
			bell && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-30 bg-bg/70",
				onClick: () => setBell(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-4 top-20 rounded-2xl border border-line bg-surface p-3 text-start",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-2 font-bold",
							children: t.notificationsTitle
						}),
						alerts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.noAlerts }) : alerts.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-line py-2 text-sm",
							children: [
								m.home.name,
								" ",
								m.home.score ?? "",
								"–",
								m.away.score ?? "",
								" ",
								m.away.name,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted",
									children: [
										m.statusText,
										" · ",
										formatWhen(m.kickoff, prefs.lang)
									]
								})
							]
						}, m.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: t.notifyHint
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex max-w-3xl",
					children: [
						[
							"home",
							t.home,
							House
						],
						[
							"matches",
							t.matches,
							Earth
						],
						[
							"leagues",
							t.leagues,
							Trophy
						],
						[
							"insights",
							t.insights,
							ChartColumn
						],
						[
							"ai",
							t.assistant,
							Bot
						]
					].map(([name, label, Icon]) => {
						const active = screen.name === name;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => tab(name),
							className: `flex flex-1 flex-col items-center gap-1 py-2 text-xs ${active ? "text-accent" : "text-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), String(label)]
						}, String(name));
					})
				})
			})
		]
	});
}
function HomeScreen({ home, prefs, t, busy, onRefresh, onMatch, onLeague, onTeam }) {
	const lang = prefs.lang;
	const groups = [
		{
			title: t.featured,
			items: LEAGUES.filter((l) => l.featured)
		},
		{
			title: t.arab,
			items: LEAGUES.filter((l) => l.arab || l.region === "arab")
		},
		{
			title: t.europe,
			items: LEAGUES.filter((l) => l.region === "europe")
		},
		{
			title: t.africaWorld,
			items: LEAGUES.filter((l) => l.region === "africa" || l.national)
		},
		{
			title: t.asia,
			items: LEAGUES.filter((l) => l.region === "asia" || l.id === "ksa.1" || l.id === "uae" || l.id === "qat")
		},
		{
			title: t.americas,
			items: LEAGUES.filter((l) => l.region === "americas" || l.id === "conmebol.america")
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-lg font-black",
					children: t.today
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onRefresh,
					className: "inline-flex items-center gap-1 rounded-full bg-accent px-3 py-2 text-sm font-bold text-onaccent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-4 ${busy ? "animate-spin" : ""}` }), t.refresh]
				})]
			}),
			!home ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.loading }) : null,
			home && home.live.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t.live }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 px-4",
				children: home.live.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
					match: m,
					lang,
					onOpen: () => onMatch(m)
				}, m.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t.today }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 px-4",
				children: [home && home.today.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyMatches }) : null, home?.today.slice(0, 8).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
					match: m,
					lang,
					onOpen: () => onMatch(m)
				}, m.id))]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t.upcoming }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto px-4 pb-1",
				children: home?.upcoming.slice(0, 10).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onMatch(m),
					className: "w-44 shrink-0 rounded-2xl border border-line bg-surface p-3 text-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs text-muted",
							children: lang === "ar" ? m.leagueNameAr : m.leagueNameEn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
								src: m.home.logo,
								name: m.home.name,
								className: "size-6"
							}), m.home.name]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
								src: m.away.logo,
								name: m.away.name,
								className: "size-6"
							}), m.away.name]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-xs text-accent",
							children: formatWhen(m.kickoff, lang)
						})
					]
				}, m.id))
			})] }),
			groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: group.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 px-4 sm:grid-cols-3",
				children: group.items.map((league) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onLeague(league.id),
					className: "rounded-2xl border border-line bg-surface p-3 text-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
							src: league.logo,
							name: lang === "ar" ? league.nameAr : league.nameEn,
							className: "size-12"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-sm font-bold",
							children: lang === "ar" ? league.nameAr : league.nameEn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted",
							children: lang === "ar" ? league.countryAr : league.countryEn
						})
					]
				}, league.id + group.title))
			})] }, group.title)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t.news }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 px-4",
				children: [home && home.news.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyNews }) : null, home?.news.slice(0, 6).map((story) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: story.url,
					target: "_blank",
					rel: "noreferrer",
					className: "flex gap-3 rounded-2xl border border-line bg-surface p-3",
					children: [story.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: story.image,
						alt: "",
						className: "size-16 rounded-xl object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-16 place-items-center rounded-xl bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newspaper, { className: "size-5 text-muted" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "line-clamp-2 text-sm font-semibold",
						children: story.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-xs text-muted",
						children: [
							story.source,
							" · ",
							formatWhen(story.published, lang, false)
						]
					})] })]
				}, story.id))]
			})] }),
			home?.tables.map((table) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs font-semibold text-accent",
						onClick: () => onLeague(table.leagueId),
						children: t.open
					}),
					children: `${t.standings} · ${lang === "ar" ? table.nameAr : table.nameEn}`
				}),
				table.partial ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-4 pb-2 text-xs text-warn",
					children: [
						t.partial,
						" · ",
						table.season
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-4 pb-2 text-xs text-muted",
					children: [
						t.season,
						": ",
						table.season
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StandingTable, {
						rows: table.rows,
						t,
						onTeam: (id) => {
							const row = table.rows.find((r) => r.team.id === id);
							onTeam(table.leagueId, id, row?.team.name ?? id, row?.team.logo ?? null);
						}
					})
				})
			] }, table.leagueId)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-xs font-semibold text-accent",
					onClick: () => onLeague("eng.1"),
					children: t.favorites
				}),
				children: t.favorites
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-3 overflow-x-auto px-4",
				children: (prefs.favs.length ? prefs.favs : SUGGESTED_CLUBS.slice(0, 8)).map((club) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onTeam(club.leagueId, club.id, lang === "ar" ? club.nameAr : club.name, club.logo),
					className: "flex w-20 shrink-0 flex-col items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
						src: club.logo,
						name: club.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "line-clamp-2 text-center text-xs",
						children: lang === "ar" ? club.nameAr : club.name
					})]
				}, club.id))
			})] })
		]
	});
}
function MatchesScreen({ lang, t, onMatch }) {
	const [filter, setFilter] = (0, import_react.useState)("today");
	const [query, setQuery] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)("");
	const [matches, setMatches] = (0, import_react.useState)([]);
	const [at, setAt] = (0, import_react.useState)();
	const [stale, setStale] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(true);
	const load = (0, import_react.useCallback)(async () => {
		setBusy(true);
		const dates = filter === "today" ? [ymd()] : filter === "tomorrow" ? [shift(1)] : filter === "past" ? [shift(-1), shift(-2)] : [
			0,
			1,
			2,
			3,
			4,
			5,
			6
		].map((n) => shift(n));
		if (date) dates.splice(0, dates.length, date.replaceAll("-", ""));
		try {
			const data = await fetchBoard({ data: { dates } });
			let list = data.matches;
			if (filter === "live") list = list.filter((m) => m.status === "in");
			if (filter === "past") list = list.filter((m) => m.status === "post");
			if (filter === "week") list = list.filter((m) => m.status !== "post");
			setMatches(list);
			setAt(data.updatedAt);
			setStale(data.stale);
		} catch {
			setStale(true);
		} finally {
			setBusy(false);
		}
	}, [filter, date]);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	const shown = matches.filter((m) => {
		const q = query.trim().toLowerCase();
		if (!q) return true;
		return m.home.name.toLowerCase().includes(q) || m.away.name.toLowerCase().includes(q);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto px-4",
				children: [
					"today",
					"tomorrow",
					"live",
					"week",
					"past"
				].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setDate("");
						setFilter(key);
					},
					className: `rounded-full px-3 py-2 text-sm ${filter === key && !date ? "bg-accent text-onaccent" : "border border-line text-fg"}`,
					children: t[key === "week" ? "week" : key]
				}, key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value),
						className: "rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: t.searchPh,
						className: "min-w-0 flex-1 rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void load(),
						className: "rounded-xl border border-line px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Freshness, {
					at,
					stale,
					busy,
					t,
					lang
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 space-y-2 px-4",
				children: [
					busy && !shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.loading }) : null,
					!busy && !shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyMatches }) : null,
					shown.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
						match: m,
						lang,
						onOpen: () => onMatch(m)
					}, m.id + m.kickoff))
				]
			})
		]
	});
}
function LeagueList({ title, leagues, lang, favs, onToggle, onOpen }) {
	const [q, setQ] = (0, import_react.useState)("");
	const list = leagues.filter((l) => `${l.nameAr} ${l.nameEn} ${l.countryAr}`.toLowerCase().includes(q.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "px-4 text-lg font-black",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: title,
				className: "mx-4 mt-3 w-[calc(100%-2rem)] rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-2 px-4",
				children: list.map((league) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpen(league.id),
						className: "w-full text-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
								src: league.logo,
								name: lang === "ar" ? league.nameAr : league.nameEn,
								className: "size-12"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 text-sm font-bold",
								children: lang === "ar" ? league.nameAr : league.nameEn
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: lang === "ar" ? league.countryAr : league.countryEn
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onToggle(league.id),
						className: "mt-2 text-xs text-accent",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `inline size-3 ${favs.includes(league.id) ? "fill-accent" : ""}` }),
							" ",
							favs.includes(league.id) ? "★" : "+"
						]
					})]
				}, league.id))
			})
		]
	});
}
function LeagueScreen({ id, lang, t, onMatch, onTeam, onPlayer }) {
	const [tabName, setTab] = (0, import_react.useState)("standings");
	const [data, setData] = (0, import_react.useState)(null);
	const [stale, setStale] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const load = (0, import_react.useCallback)(async () => {
		setBusy(true);
		try {
			const next = await fetchLeague({ data: id });
			setData(next);
			setStale(Boolean(next.stale));
			if (!next.error) writeCache(`league:${id}`, next);
		} catch {
			setStale(true);
		} finally {
			setBusy(false);
		}
	}, [id]);
	(0, import_react.useEffect)(() => {
		const cached = readCache(`league:${id}`);
		if (cached) {
			setData(cached.data);
			setStale(true);
		}
		load();
	}, [id, load]);
	const name = data ? lang === "ar" ? data.nameAr : data.nameEn : leagueName(id, lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
						src: data?.logo ?? leagueById(id)?.logo,
						name,
						className: "size-14"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-lg font-black",
							children: name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Freshness, {
							at: data?.updatedAt,
							stale,
							busy,
							t,
							lang
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted",
							children: [
								t.season,
								": ",
								data?.season || "—"
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void load(),
						className: "ms-auto rounded-full border border-line p-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" })
					})
				]
			}),
			data?.noteAr || data?.noteEn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-4 mt-3 rounded-xl bg-surface-2 px-3 py-2 text-xs text-warn",
				children: lang === "ar" ? data.noteAr : data.noteEn
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-2 overflow-x-auto px-4",
				children: [
					"standings",
					"results",
					"fixtures",
					"teams",
					"scorers",
					"assists"
				].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(key),
					className: `rounded-full px-3 py-2 text-sm ${tabName === key ? "bg-accent text-onaccent" : "border border-line"}`,
					children: t[key]
				}, key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [
					!data && busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.loading }) : null,
					tabName === "standings" && data && (data.standings.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StandingTable, {
						rows: data.standings,
						t,
						onTeam
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: lang === "ar" ? "لا يوجد ترتيب من المصدر." : "No table from the source." })),
					tabName === "results" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2 px-4",
						children: data?.results.length ? data.results.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
							match: m,
							lang,
							onOpen: () => onMatch(m)
						}, m.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyMatches })
					}),
					tabName === "fixtures" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2 px-4",
						children: data?.upcoming.length ? data.upcoming.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
							match: m,
							lang,
							onOpen: () => onMatch(m)
						}, m.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyMatches })
					}),
					tabName === "teams" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 px-4",
						children: [data?.teams.map((team) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onTeam(team.id),
							className: "flex items-center gap-2 rounded-2xl border border-line bg-surface p-3 text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
								src: team.logo,
								name: team.name,
								className: "size-8"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: team.name
							})]
						}, team.id)), data && !data.teams.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyMatches }) : null]
					}),
					tabName === "scorers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScorerList, {
						rows: data?.scorers ?? [],
						empty: t.noScorers,
						onOpen: onPlayer
					}),
					tabName === "assists" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScorerList, {
						rows: data?.assists ?? [],
						empty: t.noAssists,
						onOpen: onPlayer
					})
				]
			})
		]
	});
}
function ScorerList({ rows, empty, onOpen }) {
	if (!rows.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: empty });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 px-4",
		children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onOpen(row.id, row.teamId),
			className: "flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-5 font-bold text-accent",
					children: index + 1
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
					src: row.teamLogo,
					name: row.teamName,
					className: "size-8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm font-semibold",
						children: row.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-xs text-muted",
						children: row.teamName
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-lg font-black tabular-nums",
					children: row.value
				})
			]
		}, row.id))
	});
}
function MatchScreen({ leagueId, id, lang, t, onTeam }) {
	const [data, setData] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		setBusy(true);
		fetchMatch({ data: {
			leagueId,
			eventId: id
		} }).then((next) => {
			if (!cancel) setData(next);
		}).catch(() => {
			if (!cancel) setData(null);
		}).finally(() => {
			if (!cancel) setBusy(false);
		});
		return () => {
			cancel = true;
		};
	}, [leagueId, id]);
	if (busy && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.loading });
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.failed });
	const match = data.match;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted",
						children: lang === "ar" ? match.leagueNameAr : match.leagueNameEn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center justify-between",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onTeam(match.home.id),
								className: "flex w-28 flex-col items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
									src: match.home.logo,
									name: match.home.name,
									className: "size-14"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold",
									children: match.home.name
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-black tabular-nums text-accent",
								children: match.status === "pre" ? "–" : `${match.home.score ?? 0} - ${match.away.score ?? 0}`
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: match.status === "in" ? match.statusText : formatWhen(match.kickoff, lang)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onTeam(match.away.id),
								className: "flex w-28 flex-col items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
									src: match.away.logo,
									name: match.away.name,
									className: "size-14"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold",
									children: match.away.name
								})]
							})
						]
					}),
					match.venue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted",
						children: [
							t.venue,
							": ",
							match.venue
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Freshness, {
						at: data.updatedAt,
						stale: data.stale,
						t,
						lang
					})
				]
			}),
			data.noteAr || data.noteEn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-4 text-xs text-warn",
				children: lang === "ar" ? data.noteAr : data.noteEn
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-bold",
					children: t.stats
				}), data.stats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: lang === "ar" ? "لا إحصائيات تفصيلية من المصدر لهذه المباراة." : "No detailed stats from the source for this match." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: data.stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[3rem_1fr_3rem] items-center text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold tabular-nums",
								children: stat.home
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-center text-xs text-muted",
								children: stat.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-end font-bold tabular-nums",
								children: stat.away
							})
						]
					}, stat.label))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-bold",
					children: t.timeline
				}), data.timeline.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: lang === "ar" ? "لا أحداث مفصلة." : "No event feed." }) : data.timeline.filter((item) => item.scoring || item.text).slice(0, 16).map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-line py-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-accent",
							children: item.minute
						}),
						" ",
						item.text,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: item.team
						})
					]
				}, i))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 font-bold",
						children: t.h2h
					}),
					data.h2hSummary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs text-muted",
						children: data.h2hSummary
					}) : null,
					data.h2h.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: lang === "ar" ? "لا سجل مواجهات من المصدر." : "No head-to-head from the source." }) : data.h2h.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
							match: m,
							lang,
							onOpen: () => void 0
						})
					}, m.id))
				]
			})
		]
	});
}
function TeamScreen({ leagueId, id, lang, t, fav, onFav, onMatch, onPlayer }) {
	const [data, setData] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		setBusy(true);
		fetchTeam({ data: {
			leagueId,
			teamId: id
		} }).then((next) => {
			if (!cancel) setData(next);
		}).finally(() => {
			if (!cancel) setBusy(false);
		});
		return () => {
			cancel = true;
		};
	}, [leagueId, id]);
	if (busy && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.loading });
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.failed });
	const club = data.club;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
						src: club.logo,
						name: club.name,
						className: "size-16"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-lg font-black",
								children: club.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: lang === "ar" ? club.leagueNameAr : club.leagueNameEn
							}),
							club.standing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs",
								children: club.standing
							}) : null,
							data.row ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-semibold text-accent",
								children: [
									data.row.pts,
									" ",
									t.pts,
									" · ",
									t.gd,
									" ",
									data.row.gd
								]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onFav({
							id: club.id,
							name: club.name,
							nameAr: club.name,
							leagueId: club.leagueId,
							logo: club.logo
						}),
						className: "rounded-full border border-line px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `inline size-3 ${fav ? "fill-accent text-accent" : ""}` }),
							" ",
							fav ? t.added : t.add
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Freshness, {
					at: data.updatedAt,
					stale: data.stale,
					t,
					lang
				})
			}),
			data.noteAr || data.noteEn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 text-xs text-warn",
				children: lang === "ar" ? data.noteAr : data.noteEn
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t.matches }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 px-4",
				children: data.matches.length ? data.matches.slice(-12).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
					match: m,
					lang,
					onOpen: () => onMatch(m)
				}, m.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyMatches })
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t.squad }), data.squad.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.noSquad }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-2 px-4",
				children: data.squad.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPlayer(player.id),
					className: "flex items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
							src: player.headshot,
							name: player.name,
							className: "size-10"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-semibold",
								children: player.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted",
								children: [
									player.position,
									" ",
									player.jersey ? `· ${player.jersey}` : ""
								]
							})]
						}),
						player.goals !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-accent",
							children: [
								player.goals,
								" ",
								t.goals
							]
						}) : null
					]
				}, player.id))
			})] })
		]
	});
}
function PlayerScreen({ leagueId, id, teamId, lang, t }) {
	const [data, setData] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		fetchPlayer({ data: {
			leagueId,
			playerId: id,
			teamId
		} }).then((next) => {
			if (!cancel) setData(next);
		});
		return () => {
			cancel = true;
		};
	}, [
		leagueId,
		id,
		teamId
	]);
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.loading });
	const player = data.player;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-6 px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
					src: player.headshot || player.teamLogo,
					name: player.name,
					className: "size-16"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-lg font-black",
					children: player.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: player.teamName
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 space-y-2 text-sm",
				children: [
					player.position ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-b border-line py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: t.position
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: player.position })]
					}) : null,
					player.jersey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-b border-line py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "#"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: player.jersey })]
					}) : null,
					player.age ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-b border-line py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: t.age
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: player.age })]
					}) : null,
					player.nationality ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-b border-line py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: t.nation
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: player.nationality })]
					}) : null,
					player.goals !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-b border-line py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: t.goals
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: player.goals })]
					}) : null,
					player.assists !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-b border-line py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: t.assists
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: player.assists })]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: lang === "ar" ? data.noteAr : data.noteEn
			}),
			data.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-warn",
				children: t.failed
			}) : null
		]
	});
}
function InsightsScreen({ lang, t, onMatch, onPlayer }) {
	const [leagueId, setLeagueId] = (0, import_react.useState)("eng.1");
	const [data, setData] = (0, import_react.useState)(null);
	const [a, setA] = (0, import_react.useState)("");
	const [b, setB] = (0, import_react.useState)("");
	const [pa, setPa] = (0, import_react.useState)("");
	const [pb, setPb] = (0, import_react.useState)("");
	const [h2h, setH2h] = (0, import_react.useState)([]);
	const [note, setNote] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let cancel = false;
		fetchLeague({ data: leagueId }).then((next) => {
			if (!cancel) {
				setData(next);
				setA("");
				setB("");
				setPa("");
				setPb("");
				setH2h([]);
			}
		});
		return () => {
			cancel = true;
		};
	}, [leagueId]);
	const byId = new Map((data?.standings ?? []).map((row) => [row.team.id, row]));
	const picks = data?.upcoming.slice(0, 6) ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-lg font-black",
						children: t.insights
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: leagueId,
						onChange: (e) => setLeagueId(e.target.value),
						className: "mt-2 w-full rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm",
						children: LEAGUES.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: l.id,
							children: lang === "ar" ? l.nameAr : l.nameEn
						}, l.id))
					}),
					data?.partial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-warn",
						children: t.partial
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 font-bold",
						children: t.prediction
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs text-warn",
						children: t.notFact
					}),
					picks.map((m) => {
						const home = byId.get(m.home.id);
						const away = byId.get(m.away.id);
						const est = home && away ? estimate(home, away) : null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 rounded-2xl border border-line bg-surface p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onMatch(m),
								className: "text-sm font-semibold",
								children: [
									m.home.name,
									" ",
									t.vs,
									" ",
									m.away.name
								]
							}), est ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm tabular-nums",
								children: [
									est.home,
									"% / ",
									est.draw,
									"% / ",
									est.away,
									"% · xG ",
									est.goals
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: t.insufficient
							})]
						}, m.id);
					}),
					!picks.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyMatches }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 font-bold",
						children: t.compareTeams
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSelect, {
							rows: data?.standings ?? [],
							value: a,
							onChange: setA
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSelect, {
							rows: data?.standings ?? [],
							value: b,
							onChange: setB
						})]
					}),
					a && b && byId.get(a) && byId.get(b) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareRows, {
						left: byId.get(a),
						right: byId.get(b),
						t
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !a || !b,
						onClick: () => {
							fetchH2H({ data: {
								leagueId,
								teamA: a,
								teamB: b
							} }).then((res) => {
								setH2h(res.matches);
								setNote(lang === "ar" ? res.noteAr : res.noteEn);
							});
						},
						className: "mt-2 rounded-full bg-accent px-3 py-2 text-sm font-bold text-onaccent disabled:opacity-40",
						children: t.h2h
					}),
					note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: note
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 space-y-2",
						children: h2h.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
							match: m,
							lang,
							onOpen: () => onMatch(m)
						}, m.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 font-bold",
						children: t.comparePlayers
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerSelect, {
							rows: data?.scorers ?? [],
							value: pa,
							onChange: setPa
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerSelect, {
							rows: data?.scorers ?? [],
							value: pb,
							onChange: setPb
						})]
					}),
					pa && pb ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCompare, {
						left: (data?.scorers ?? []).find((s) => s.id === pa),
						right: (data?.scorers ?? []).find((s) => s.id === pb),
						assists: data?.assists ?? [],
						onOpen: (pid, teamId) => onPlayer(leagueId, pid, teamId)
					}) : null,
					!data?.scorers.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.noScorers }) : null
				]
			})
		]
	});
}
function TeamSelect({ rows, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		value,
		onChange: (e) => onChange(e.target.value),
		className: "rounded-xl border border-line bg-surface-2 px-2 py-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			children: "—"
		}), rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: row.team.id,
			children: row.team.name
		}, row.team.id))]
	});
}
function PlayerSelect({ rows, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		value,
		onChange: (e) => onChange(e.target.value),
		className: "rounded-xl border border-line bg-surface-2 px-2 py-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			children: "—"
		}), rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: row.id,
			children: row.name
		}, row.id))]
	});
}
function CompareRows({ left, right, t }) {
	const lines = [
		[
			t.pts,
			left.pts,
			right.pts
		],
		[
			t.gd,
			left.gd,
			right.gd
		],
		[
			t.goals,
			left.gf,
			right.gf
		],
		[
			"GA",
			left.ga,
			right.ga
		],
		[
			t.played,
			left.played,
			right.played
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-2xl border border-line bg-surface p-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-center justify-between font-bold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
					src: left.team.logo,
					name: left.team.name,
					className: "size-6"
				}), left.team.name]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1",
				children: [right.team.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
					src: right.team.logo,
					name: right.team.name,
					className: "size-6"
				})]
			})]
		}), lines.map(([label, l, r]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 border-t border-line py-1 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r })
			]
		}, String(label)))]
	});
}
function PlayerCompare({ left, right, assists, onOpen }) {
	if (!left || !right) return null;
	const ag = assists.find((s) => s.id === left.id)?.value ?? "—";
	const bg = assists.find((s) => s.id === right.id)?.value ?? "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-2xl border border-line bg-surface p-3 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onOpen(left.id, left.teamId),
					children: left.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onOpen(right.id, right.teamId),
					children: right.name
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 grid grid-cols-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: left.value }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: "G"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: right.value })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ag }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: "A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: bg })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-muted",
				children: [
					left.teamName,
					" / ",
					right.teamName
				]
			})
		]
	});
}
function AiScreen({ lang, t }) {
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [log, setLog] = (0, import_react.useState)([{
		role: "ai",
		text: lang === "ar" ? "اسأل عن نتيجة أو ترتيب أو موعد من البيانات المحمّلة. التوقعات تُذكر صراحةً وليست نتائج." : "Ask about a score, table, or kickoff from loaded data. Forecasts are labeled and are not results."
	}]);
	const send = async () => {
		const question = text.trim();
		if (!question || busy) return;
		setText("");
		setLog((prev) => [...prev, {
			role: "user",
			text: question
		}]);
		setBusy(true);
		try {
			const answer = await askAssistant({ data: {
				question,
				lang,
				today: ymd()
			} });
			setLog((prev) => [...prev, {
				role: "ai",
				text: answer.text
			}]);
		} catch {
			setLog((prev) => [...prev, {
				role: "ai",
				text: t.failed
			}]);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[70vh] flex-col py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 space-y-2 px-4",
			children: [log.map((msg, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `max-w-[90%] rounded-2xl px-3 py-2 text-sm ${msg.role === "user" ? "ms-auto bg-accent text-onaccent" : "bg-surface border border-line"}`,
				children: msg.text
			}, i)), busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: t.thinking
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sticky bottom-20 flex gap-2 px-4 pt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: text,
				onChange: (e) => setText(e.target.value),
				onKeyDown: (e) => {
					if (e.key === "Enter") send();
				},
				placeholder: t.ask,
				className: "min-w-0 flex-1 rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void send(),
				className: "rounded-xl bg-accent px-3 font-bold text-onaccent",
				children: t.send
			})]
		})]
	});
}
function NewsScreen({ home, lang, t }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 px-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-lg font-black",
			children: t.news
		}), home?.news.length ? home.news.map((story) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: story.url,
			target: "_blank",
			rel: "noreferrer",
			className: "block rounded-2xl border border-line bg-surface p-3",
			children: [
				story.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: story.image,
					alt: "",
					className: "mb-2 h-36 w-full rounded-xl object-cover"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-semibold",
					children: story.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: story.summary
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 text-xs text-accent",
					children: [
						story.source,
						" · ",
						formatWhen(story.published, lang)
					]
				})
			]
		}, story.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.emptyNews })]
	});
}
function SettingsScreen({ prefs, t, onChange }) {
	const enable = async () => {
		if (typeof Notification === "undefined") return;
		onChange({ notify: await Notification.requestPermission() === "granted" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-black",
				children: t.settings
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: [t.language, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: prefs.lang,
					onChange: (e) => onChange({ lang: e.target.value }),
					className: "mt-1 w-full rounded-xl border border-line bg-surface-2 px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "ar",
						children: "العربية"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "en",
						children: "English"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 text-sm",
				children: t.theme
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange({ mode: prefs.mode === "dark" ? "light" : "dark" }),
					className: "rounded-full border border-line px-3 py-2 text-sm",
					children: prefs.mode === "dark" ? t.light : t.dark
				}), [
					"green",
					"blue",
					"purple",
					"orange"
				].map((theme) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange({ theme }),
					className: `rounded-full px-3 py-2 text-sm ${prefs.theme === theme ? "bg-accent text-onaccent" : "border border-line"}`,
					children: theme
				}, theme))]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 text-sm",
				children: t.font
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [
					"sm",
					"md",
					"lg"
				].map((font) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange({ font }),
					className: `rounded-full px-3 py-2 text-sm ${prefs.font === font ? "bg-accent text-onaccent" : "border border-line"}`,
					children: t[font]
				}, font))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-line bg-surface p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-semibold",
						children: t.notify
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: t.notifyHint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void enable(),
						className: "mt-2 rounded-full bg-accent px-3 py-2 text-sm font-bold text-onaccent",
						children: t.enableNotify
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-6 text-muted",
				children: t.sources
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(DEFAULT_PREFS),
				className: "w-full rounded-xl border border-line py-3 text-sm",
				children: t.reset
			})
		]
	});
}
function SearchScreen({ lang, t, onLeague, onTeam, onPlayer }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (q.trim().length < 2) {
			setHits([]);
			return;
		}
		const timer = window.setTimeout(() => {
			setBusy(true);
			fetchSearch({ data: q }).then(setHits).catch(() => setHits([])).finally(() => setBusy(false));
		}, 300);
		return () => window.clearTimeout(timer);
	}, [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-black",
				children: t.search
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				autoFocus: true,
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t.searchPh,
				className: "mt-3 w-full rounded-xl border border-line bg-surface-2 px-3 py-3 text-sm"
			}),
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: t.loading
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 space-y-2",
				children: hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						if (hit.kind === "league") onLeague(hit.id);
						else if (hit.kind === "team" && hit.leagueId) onTeam(hit.leagueId, hit.id);
						else if (hit.kind === "player" && hit.leagueId) onPlayer(hit.leagueId, hit.id);
					},
					className: "flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
						src: hit.logo,
						name: hit.title,
						className: "size-9"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-semibold",
						children: hit.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted",
						children: [
							hit.kind,
							" · ",
							hit.subtitle
						]
					})] })]
				}, `${hit.kind}-${hit.id}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-muted",
				children: lang === "ar" ? "البحث يطابق البطولات محلياً والأندية واللاعبين عبر ESPN." : "Search matches competitions locally, and clubs or players via ESPN."
			})
		]
	});
}
function FavoritesScreen({ prefs, t, onTeam, onLeague, onAdd }) {
	const lang = prefs.lang;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-black",
				children: t.favorites
			}),
			prefs.favs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.noFav }) : prefs.favs.map((club) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onTeam(club),
				className: "flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
					src: club.logo,
					name: club.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "ar" ? club.nameAr : club.name })]
			}, club.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-bold",
				children: t.pickFav
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: SUGGESTED_CLUBS.map((club) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onAdd(club),
					className: "flex items-center gap-2 rounded-2xl border border-line bg-surface p-2 text-start text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
						src: club.logo,
						name: club.name,
						className: "size-8"
					}), lang === "ar" ? club.nameAr : club.name]
				}, club.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-bold",
				children: t.leagues
			}),
			prefs.favLeagues.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onLeague(id),
				className: "block w-full rounded-xl border border-line px-3 py-2 text-start text-sm",
				children: leagueName(id, lang)
			}, id))
		]
	});
}
function HistoryScreen({ items, t, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
			className: "mb-3 flex items-center gap-2 text-lg font-black",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-5" }), t.history]
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: t.history }) : items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onOpen(item),
			className: "mb-2 flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-2 text-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
				src: item.logo,
				name: item.title,
				className: "size-8"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm",
				children: item.title
			})]
		}, item.kind + item.id))]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootballApp, {});
}
//#endregion
export { Home as component };
