import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Store, c as RotateCcw, d as Package, f as DoorOpen, l as Play, n as Wallet, o as Star, p as ClipboardList, r as Users, s as Sparkles, t as X, u as Pause } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CPFWFcjq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var PRODUCTS = [
	{
		id: "bread",
		name: "Bread",
		category: "bakery",
		buyPrice: 1.15,
		sellPrice: 2.49,
		unlockLevel: 1,
		color: 12887412,
		shelf: "gondola",
		perishable: true,
		demand: 1.15
	},
	{
		id: "milk",
		name: "Milk",
		category: "dairy",
		buyPrice: 1.05,
		sellPrice: 2.29,
		unlockLevel: 1,
		color: 15922423,
		shelf: "fridge",
		perishable: true,
		demand: 1.2
	},
	{
		id: "eggs",
		name: "Eggs",
		category: "dairy",
		buyPrice: 1.7,
		sellPrice: 3.49,
		unlockLevel: 1,
		color: 15783050,
		shelf: "fridge",
		perishable: true,
		demand: 1.05
	},
	{
		id: "drinks",
		name: "Drinks",
		category: "drinks",
		buyPrice: .65,
		sellPrice: 1.59,
		unlockLevel: 1,
		color: 4034516,
		shelf: "gondola",
		perishable: false,
		demand: 1.1
	},
	{
		id: "chocolate",
		name: "Chocolate",
		category: "snacks",
		buyPrice: .85,
		sellPrice: 1.99,
		unlockLevel: 1,
		color: 6042391,
		shelf: "gondola",
		perishable: false,
		demand: .95
	},
	{
		id: "biscuits",
		name: "Biscuits",
		category: "snacks",
		buyPrice: .8,
		sellPrice: 1.89,
		unlockLevel: 2,
		color: 14267530,
		shelf: "gondola",
		perishable: false,
		demand: .9
	},
	{
		id: "noodles",
		name: "Noodles",
		category: "pantry",
		buyPrice: .55,
		sellPrice: 1.39,
		unlockLevel: 2,
		color: 13934615,
		shelf: "gondola",
		perishable: false,
		demand: 1
	},
	{
		id: "rice",
		name: "Rice",
		category: "pantry",
		buyPrice: 2.2,
		sellPrice: 4.79,
		unlockLevel: 2,
		color: 15261904,
		shelf: "rack",
		perishable: false,
		demand: .85
	},
	{
		id: "meat",
		name: "Meat",
		category: "fresh",
		buyPrice: 4.4,
		sellPrice: 8.99,
		unlockLevel: 3,
		color: 12082268,
		shelf: "fridge",
		perishable: true,
		demand: .8
	},
	{
		id: "vegetables",
		name: "Vegetables",
		category: "fresh",
		buyPrice: .75,
		sellPrice: 1.79,
		unlockLevel: 2,
		color: 5214026,
		shelf: "produce",
		perishable: true,
		demand: 1
	},
	{
		id: "fruits",
		name: "Fruits",
		category: "fresh",
		buyPrice: .9,
		sellPrice: 1.99,
		unlockLevel: 2,
		color: 14708816,
		shelf: "produce",
		perishable: true,
		demand: 1.05
	},
	{
		id: "shampoo",
		name: "Shampoo",
		category: "personal",
		buyPrice: 2.1,
		sellPrice: 4.49,
		unlockLevel: 3,
		color: 8036041,
		shelf: "gondola",
		perishable: false,
		demand: .7
	},
	{
		id: "cleaning",
		name: "Cleaner",
		category: "household",
		buyPrice: 1.7,
		sellPrice: 3.79,
		unlockLevel: 3,
		color: 5941408,
		shelf: "gondola",
		perishable: false,
		demand: .65
	},
	{
		id: "frozen",
		name: "Frozen",
		category: "frozen",
		buyPrice: 2,
		sellPrice: 4.29,
		unlockLevel: 3,
		color: 9357544,
		shelf: "freezer",
		perishable: false,
		demand: .75
	}
];
var PRODUCT_MAP = Object.fromEntries(PRODUCTS.map((p) => [p.id, p]));
var SUPPLIERS = [
	{
		id: "fresh",
		name: "FreshFarm Co",
		specialty: "fresh",
		priceMul: .88,
		delayMin: 18,
		bulk: .94
	},
	{
		id: "metro",
		name: "Metro Wholesale",
		specialty: "all",
		priceMul: 1,
		delayMin: 12,
		bulk: .92
	},
	{
		id: "quick",
		name: "QuickStock",
		specialty: "all",
		priceMul: 1.28,
		delayMin: 5,
		bulk: 1
	},
	{
		id: "frost",
		name: "FrozenKing",
		specialty: "frozen",
		priceMul: .9,
		delayMin: 16,
		bulk: .93
	},
	{
		id: "bulk",
		name: "BulkBuy",
		specialty: "pantry",
		priceMul: .82,
		delayMin: 22,
		bulk: .86
	}
];
var LOCATIONS = [
	{
		id: "town",
		name: "Small Town",
		rent: 70,
		traffic: .78,
		unlockLevel: 1,
		blurb: "Quiet streets. Budget shoppers and regulars."
	},
	{
		id: "city",
		name: "City",
		rent: 160,
		traffic: 1,
		unlockLevel: 2,
		blurb: "Steady mix of every customer type."
	},
	{
		id: "downtown",
		name: "Downtown",
		rent: 280,
		traffic: 1.22,
		unlockLevel: 3,
		blurb: "Busy, impatient, and willing to spend."
	},
	{
		id: "beach",
		name: "Beach Area",
		rent: 210,
		traffic: .95,
		unlockLevel: 3,
		blurb: "Drinks and snacks fly off the shelf."
	},
	{
		id: "business",
		name: "Business District",
		rent: 360,
		traffic: 1.35,
		unlockLevel: 4,
		blurb: "Lunch rushes and high-ticket baskets."
	}
];
var LOCATION_MAP = Object.fromEntries(LOCATIONS.map((l) => [l.id, l]));
var STORE_LABELS = [
	"Corner Grocery",
	"Medium Store",
	"Supermarket",
	"Hypermarket"
];
var UPGRADE_COST = [
	0,
	8500,
	26e3,
	82e3
];
var ROLE_META = {
	cashier: {
		label: "Cashier",
		salary: 85,
		hire: 420,
		blurb: "Serves the checkout queue."
	},
	stocker: {
		label: "Stock Worker",
		salary: 80,
		hire: 390,
		blurb: "Moves warehouse crates onto shelves."
	},
	cleaner: {
		label: "Cleaner",
		salary: 70,
		hire: 310,
		blurb: "Keeps floors and shelves presentable."
	},
	security: {
		label: "Security Guard",
		salary: 95,
		hire: 480,
		blurb: "Stops shoplifters and calms queues."
	},
	delivery: {
		label: "Delivery Worker",
		salary: 90,
		hire: 450,
		blurb: "Cuts supplier wait times."
	},
	manager: {
		label: "Manager",
		salary: 140,
		hire: 900,
		blurb: "Lifts staff skill and daily rating."
	}
};
var CUSTOMER_META = {
	budget: {
		label: "Budget",
		color: 7043658,
		speed: 1.55,
		patience: 28,
		scale: 1
	},
	rich: {
		label: "Rich",
		color: 2898517,
		speed: 1.7,
		patience: 22,
		scale: 1.04
	},
	impatient: {
		label: "Impatient",
		color: 10570308,
		speed: 2.15,
		patience: 12,
		scale: 1
	},
	child: {
		label: "Child",
		color: 13935178,
		speed: 1.9,
		patience: 16,
		scale: .72
	},
	elderly: {
		label: "Elderly",
		color: 10133672,
		speed: 1.15,
		patience: 40,
		scale: .96
	},
	regular: {
		label: "Regular",
		color: 4025738,
		speed: 1.65,
		patience: 26,
		scale: 1
	}
};
var STAFF_NAMES = [
	"Rina",
	"Karim",
	"Sofia",
	"Jamal",
	"Hana",
	"Leo",
	"Priya",
	"Omar",
	"Mira",
	"Victor",
	"Nadia",
	"Chen",
	"Aya",
	"Noah",
	"Lila"
];
function storeFootprint(level) {
	if (level <= 1) return {
		w: 18,
		d: 24
	};
	if (level === 2) return {
		w: 24,
		d: 28
	};
	if (level === 3) return {
		w: 32,
		d: 34
	};
	return {
		w: 40,
		d: 40
	};
}
var SAVE_KEY = "smx-sim-v1";
var PRODUCT_IDS = PRODUCTS.map((p) => p.id);
function emptyStock() {
	const o = {};
	for (const id of PRODUCT_IDS) o[id] = 0;
	return o;
}
function emptyMul() {
	const o = {};
	for (const id of PRODUCT_IDS) o[id] = 1;
	return o;
}
function emptyUnlock() {
	const o = {};
	for (const p of PRODUCTS) o[p.id] = p.unlockLevel <= 1;
	return o;
}
function defaultSim() {
	const warehouse = emptyStock();
	warehouse.bread = 36;
	warehouse.milk = 32;
	warehouse.eggs = 24;
	warehouse.drinks = 28;
	warehouse.chocolate = 20;
	return {
		version: 1,
		money: 2800,
		day: 1,
		timeOfDay: 8,
		storeOpen: false,
		storeLevel: 1,
		location: "town",
		rating: 3.6,
		xp: 0,
		warehouse,
		unlocked: emptyUnlock(),
		sellMul: emptyMul(),
		shelves: [],
		staff: [],
		orders: [],
		missions: [],
		event: null,
		cleanliness: .92,
		lights: 0,
		decor: 0,
		warehouseCap: 220,
		checkouts: 1,
		player: {
			x: 0,
			z: 9.4,
			yaw: 0,
			holding: null
		},
		daily: {
			revenue: 0,
			expenses: 0,
			sold: 0,
			served: 0,
			lost: 0
		},
		tutorial: 0,
		seenHelp: false,
		settings: {
			sfx: .7,
			music: .35,
			shake: true,
			quality: "med"
		},
		nextCustomer: 1,
		nextStaff: 1,
		nextOrder: 1,
		soldToday: emptyStock(),
		demandMul: emptyMul()
	};
}
function migrate(raw) {
	const base = defaultSim();
	return {
		...base,
		...raw,
		version: 1,
		warehouse: {
			...base.warehouse,
			...raw.warehouse
		},
		unlocked: {
			...base.unlocked,
			...raw.unlocked
		},
		sellMul: {
			...base.sellMul,
			...raw.sellMul
		},
		soldToday: {
			...base.soldToday,
			...raw.soldToday
		},
		demandMul: {
			...base.demandMul,
			...raw.demandMul
		},
		settings: {
			...base.settings,
			...raw.settings
		},
		player: {
			...base.player,
			...raw.player
		},
		daily: {
			...base.daily,
			...raw.daily
		},
		shelves: raw.shelves ?? [],
		staff: raw.staff ?? [],
		orders: raw.orders ?? [],
		missions: raw.missions ?? []
	};
}
function loadSave() {
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return defaultSim();
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed !== "object") return defaultSim();
		return migrate(parsed);
	} catch {
		return defaultSim();
	}
}
function writeSave(state) {
	try {
		const blob = JSON.stringify(state);
		localStorage.setItem(SAVE_KEY + ":bak", localStorage.getItem("smx-sim-v1") ?? "");
		localStorage.setItem(SAVE_KEY, blob);
	} catch {}
}
function clearSave() {
	try {
		localStorage.removeItem(SAVE_KEY);
		localStorage.removeItem(SAVE_KEY + ":bak");
	} catch {}
}
function Hud({ hud, toast, panel, onPanel, onOpen, onPause, onInteract, onSprint, portrait }) {
	const toggle = (id) => onPanel(panel === id ? null : id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-3 sm:p-4",
		children: [
			portrait ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto mx-auto mb-2 max-w-sm rounded-xl border border-border bg-surface/90 px-4 py-2 text-center text-xs text-muted",
				children: "Rotate to landscape for the full aisle view."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-surface/85 px-3 py-2 backdrop-blur-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3.5 text-money" }),
							label: fmtMoney(hud.money)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 text-warn" }),
							label: hud.rating.toFixed(1)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-3.5 text-accent" }),
							label: `Day ${hud.day} · ${hud.clock}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden text-xs text-muted sm:inline",
							children: [
								hud.customers,
								" in store",
								hud.queue ? ` · ${hud.queue} in queue` : ""
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onOpen,
						className: `inline-flex h-11 items-center gap-2 rounded-xl px-4 text-sm font-semibold transition-transform active:scale-[0.98] ${hud.open ? "bg-success text-accent-fg" : "bg-elevated text-fg border border-border-strong"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoorOpen, { className: "size-4" }), hud.open ? "Open" : "Closed"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onPause,
						className: "grid size-11 place-items-center rounded-xl border border-border-strong bg-surface text-fg",
						"aria-label": "Pause",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center justify-center pointer-events-none",
				children: [
					hud.event ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-full border border-danger/40 bg-danger/15 px-4 py-1.5 text-xs font-medium text-danger",
						children: hud.event
					}) : null,
					toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 rounded-xl border border-border bg-elevated/90 px-4 py-2 text-sm text-fg",
						children: toast
					}) : null,
					hud.tutorial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 max-w-md rounded-xl border border-accent/30 bg-surface/90 px-4 py-2 text-sm text-fg",
						children: hud.tutorial
					}) : null,
					hud.prompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 rounded-full border border-border-strong bg-bg/75 px-4 py-2 text-sm font-medium text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 text-accent",
							children: "E"
						}), hud.prompt]
					}) : null,
					hud.holding ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 text-xs text-muted",
						children: [
							"Holding ",
							hud.holding.qty,
							" ",
							hud.holding.name
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden w-[116px] md:block" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "pointer-events-auto mx-auto flex items-center gap-1 rounded-2xl border border-border bg-surface/90 p-1.5 backdrop-blur-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dock, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-4" }),
								label: "Stock",
								onClick: () => toggle("stock"),
								active: panel === "stock"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dock, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }),
								label: "Order",
								onClick: () => toggle("order"),
								active: panel === "order"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dock, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-4" }),
								label: "Upgrade",
								onClick: () => toggle("shop"),
								active: panel === "shop"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dock, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }),
								label: "Staff",
								onClick: () => toggle("staff"),
								active: panel === "staff"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dock, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-4" }),
								label: "Jobs",
								onClick: () => toggle("missions"),
								active: panel === "missions"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-auto flex flex-col gap-2 md:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onPointerDown: () => onSprint(true),
							onPointerUp: () => onSprint(false),
							onPointerCancel: () => onSprint(false),
							className: "grid size-14 place-items-center rounded-full border border-border-strong bg-elevated text-xs font-semibold text-fg",
							children: "Run"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onInteract,
							className: "grid size-14 place-items-center rounded-full bg-accent text-xs font-semibold text-accent-fg",
							children: "Use"
						})]
					})
				]
			})
		]
	});
}
function Chip({ icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5 text-sm font-medium tabular-nums text-fg",
		children: [icon, label]
	});
}
function Dock({ icon, label, onClick, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: `flex min-w-14 flex-col items-center gap-0.5 rounded-xl px-3 py-2 text-[10px] font-medium uppercase tracking-wide ${active ? "bg-elevated text-accent" : "text-muted"}`,
		children: [icon, label]
	});
}
function fmtMoney(n) {
	return `${n < 0 ? "-" : ""}$${Math.abs(n).toLocaleString(void 0, { maximumFractionDigits: 0 })}`;
}
function TouchControls({ onMove, onLook }) {
	const moveRef = (0, import_react.useRef)(null);
	const lookRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const moveEl = moveRef.current;
		const lookEl = lookRef.current;
		if (!moveEl || !lookEl) return;
		let moveId = null;
		let lookId = null;
		let ox = 0;
		let oy = 0;
		let lx = 0;
		let ly = 0;
		const md = (e) => {
			moveEl.setPointerCapture(e.pointerId);
			moveId = e.pointerId;
			ox = e.clientX;
			oy = e.clientY;
		};
		const mm = (e) => {
			if (e.pointerId !== moveId) return;
			const dx = (e.clientX - ox) / 48;
			const dy = (e.clientY - oy) / 48;
			const m = Math.hypot(dx, dy) || 1;
			const s = m > 1 ? 1 / m : 1;
			onMove(dx * s, dy * s);
		};
		const mu = (e) => {
			if (e.pointerId !== moveId) return;
			moveId = null;
			onMove(0, 0);
		};
		const ld = (e) => {
			lookEl.setPointerCapture(e.pointerId);
			lookId = e.pointerId;
			lx = e.clientX;
			ly = e.clientY;
		};
		const lm = (e) => {
			if (e.pointerId !== lookId) return;
			onLook(e.clientX - lx, e.clientY - ly);
			lx = e.clientX;
			ly = e.clientY;
		};
		const lu = (e) => {
			if (e.pointerId !== lookId) return;
			lookId = null;
			onLook(0, 0);
		};
		moveEl.addEventListener("pointerdown", md);
		moveEl.addEventListener("pointermove", mm);
		moveEl.addEventListener("pointerup", mu);
		moveEl.addEventListener("pointercancel", mu);
		lookEl.addEventListener("pointerdown", ld);
		lookEl.addEventListener("pointermove", lm);
		lookEl.addEventListener("pointerup", lu);
		lookEl.addEventListener("pointercancel", lu);
		return () => {
			moveEl.removeEventListener("pointerdown", md);
			moveEl.removeEventListener("pointermove", mm);
			moveEl.removeEventListener("pointerup", mu);
			moveEl.removeEventListener("pointercancel", mu);
			lookEl.removeEventListener("pointerdown", ld);
			lookEl.removeEventListener("pointermove", lm);
			lookEl.removeEventListener("pointerup", lu);
			lookEl.removeEventListener("pointercancel", lu);
		};
	}, [onLook, onMove]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 md:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: moveRef,
			className: "pointer-events-auto absolute bottom-20 left-5 size-[116px] rounded-full border border-border bg-surface/55",
			style: { touchAction: "none" },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-7 rounded-full border border-border-strong bg-elevated/80" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: lookRef,
			className: "pointer-events-auto absolute top-16 right-0 bottom-28 w-[38%]",
			style: { touchAction: "none" }
		})]
	});
}
function GamePanel({ panel, game, onClose, onRebuild }) {
	if (!panel) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "pointer-events-auto absolute inset-x-3 bottom-24 z-30 mx-auto flex max-h-[70vh] w-[min(560px,100%)] flex-col overflow-hidden rounded-2xl border border-border bg-surface/95 shadow-xl sm:inset-x-auto sm:right-4 sm:bottom-8 sm:top-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between border-b border-border px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg tracking-wide text-fg",
				children: panel === "stock" ? "Warehouse" : panel === "order" ? "Suppliers" : panel === "shop" ? "Store upgrades" : panel === "staff" ? "Staff" : panel === "missions" ? "Daily jobs" : "Settings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				className: "grid size-9 place-items-center rounded-lg text-muted hover:text-fg",
				"aria-label": "Close",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto p-4",
			children: [
				panel === "stock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockBody, { game }) : null,
				panel === "order" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderBody, { game }) : null,
				panel === "shop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopBody, {
					game,
					onRebuild
				}) : null,
				panel === "staff" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffBody, { game }) : null,
				panel === "missions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionBody, { game }) : null,
				panel === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsBody, { game }) : null
			]
		})]
	});
}
function StockBody({ game }) {
	const s = game.sim.s;
	const used = game.sim.warehouseUsed();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted",
			children: [
				"Capacity ",
				used,
				"/",
				s.warehouseCap,
				" · pick crates in the back room"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: PRODUCTS.filter((p) => s.unlocked[p.id]).map((p) => {
				const onShelf = s.shelves.filter((sh) => sh.productId === p.id).reduce((a, sh) => a + sh.stock, 0);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-xl bg-elevated px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: p.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"Buy ",
							fmtMoney(p.buyPrice),
							" · Sell ",
							fmtMoney(p.sellPrice * s.sellMul[p.id]),
							" ·",
							" ",
							fmtMoney(p.sellPrice * s.sellMul[p.id] - p.buyPrice),
							" profit"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm tabular-nums text-fg",
							children: [s.warehouse[p.id], " in back"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [onShelf, " on shelf"]
						})]
					})]
				}, p.id);
			})
		})]
	});
}
function OrderBody({ game }) {
	const s = game.sim.s;
	const [pid, setPid] = (0, import_react.useState)("milk");
	const [qty, setQty] = (0, import_react.useState)(24);
	const [sid, setSid] = (0, import_react.useState)("metro");
	const [err, setErr] = (0, import_react.useState)("");
	const p = PRODUCT_MAP[pid];
	const sup = SUPPLIERS.find((x) => x.id === sid);
	const spec = sup.specialty === "all" || sup.specialty === p.category;
	const cost = p.buyPrice * qty * (spec ? sup.priceMul : sup.priceMul * 1.12) * (qty >= 40 ? sup.bulk : 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			s.orders.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: s.orders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						o.qty,
						" ",
						PRODUCT_MAP[o.productId].name
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [Math.max(0, o.eta).toFixed(0), "s out"]
					})]
				}, o.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "No trucks on the way."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs text-muted",
				children: ["Product", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: pid,
					onChange: (e) => setPid(e.target.value),
					className: "mt-1 h-11 w-full rounded-lg border border-border bg-elevated px-3 text-sm text-fg",
					children: PRODUCTS.filter((x) => s.unlocked[x.id]).map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: x.id,
						children: x.name
					}, x.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs text-muted",
				children: ["Supplier", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: sid,
					onChange: (e) => setSid(e.target.value),
					className: "mt-1 h-11 w-full rounded-lg border border-border bg-elevated px-3 text-sm text-fg",
					children: SUPPLIERS.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: x.id,
						children: [
							x.name,
							" · ",
							x.delayMin,
							"m · x",
							x.priceMul
						]
					}, x.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs text-muted",
				children: [
					"Quantity · ",
					qty,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 8,
						max: 80,
						step: 4,
						value: qty,
						onChange: (e) => setQty(Number(e.target.value)),
						className: "mt-2 w-full"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm tabular-nums text-fg",
				children: ["Order total ", fmtMoney(cost)]
			}),
			err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: err
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					const msg = game.sim.placeOrder(pid, qty, sid);
					setErr(msg);
				},
				className: "h-11 w-full rounded-xl bg-accent text-sm font-semibold text-accent-fg",
				children: "Place order"
			})
		]
	});
}
function ShopBody({ game, onRebuild }) {
	const s = game.sim.s;
	const [msg, setMsg] = (0, import_react.useState)("");
	const run = (fn) => {
		const r = fn();
		if (r === "rebuild") onRebuild();
		else setMsg(r);
	};
	const next = UPGRADE_COST[s.storeLevel] ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-fg",
				children: [
					STORE_LABELS[s.storeLevel - 1],
					" · ",
					LOCATION_MAP[s.location].name
				]
			}),
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: msg
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				title: s.storeLevel < 4 ? `Expand to ${STORE_LABELS[s.storeLevel]}` : "Max size",
				detail: s.storeLevel < 4 ? fmtMoney(next) : "Hypermarket",
				onClick: () => run(() => game.sim.upgradeStore())
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				title: "Extra checkout",
				detail: "$2,500",
				onClick: () => run(() => game.sim.buyCheckout())
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				title: "Lighting",
				detail: "$1,200",
				onClick: () => run(() => game.sim.buyLights())
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				title: "Decoration",
				detail: "$1,600",
				onClick: () => run(() => game.sim.buyDecor())
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				title: "Warehouse",
				detail: "$2,800",
				onClick: () => run(() => game.sim.expandWarehouse())
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "pt-2 text-xs font-medium uppercase tracking-wide text-muted",
				children: "Locations"
			}),
			LOCATIONS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => run(() => game.sim.setLocation(l.id)),
				className: `w-full rounded-xl border px-3 py-2 text-left ${s.location === l.id ? "border-accent bg-elevated" : "border-border bg-elevated/50"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-fg",
					children: [l.name, s.storeLevel < l.unlockLevel ? " · locked" : ""]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						l.blurb,
						" · rent ",
						fmtMoney(l.rent),
						"/day"
					]
				})]
			}, l.id))
		]
	});
}
function StaffBody({ game }) {
	const s = game.sim.s;
	const [msg, setMsg] = (0, import_react.useState)("");
	const roles = Object.keys(ROLE_META);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: msg
			}) : null,
			s.staff.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No staff yet. Hire a cashier when the queue grows."
			}) : null,
			s.staff.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between rounded-xl bg-elevated px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-fg",
					children: [
						e.name,
						" · ",
						ROLE_META[e.role].label,
						" · Lv.",
						e.level
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [fmtMoney(ROLE_META[e.role].salary + (e.level - 1) * 12), " / day"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-9 rounded-lg border border-border px-2 text-xs text-fg",
						onClick: () => setMsg(game.sim.train(e.id)),
						children: "Train"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-9 rounded-lg px-2 text-xs text-danger",
						onClick: () => game.sim.fire(e.id),
						children: "Fire"
					})]
				})]
			}, e.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "pt-1 text-xs font-medium uppercase tracking-wide text-muted",
				children: "Hire"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setMsg(game.sim.hire(r)),
					className: "rounded-xl border border-border bg-elevated px-3 py-2 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: ROLE_META[r].label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							fmtMoney(ROLE_META[r].hire),
							" · ",
							ROLE_META[r].blurb
						]
					})]
				}, r))
			})
		]
	});
}
function MissionBody({ game }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: game.sim.s.missions.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-xl bg-elevated px-3 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: m.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: m.detail
					})] }), m.done && !m.claimed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => game.sim.claimMission(m.id),
						className: "h-9 rounded-lg bg-accent px-3 text-xs font-semibold text-accent-fg",
						children: "Claim"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs tabular-nums text-muted",
						children: [
							m.progress,
							"/",
							m.target
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-1.5 overflow-hidden rounded-full bg-bg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-accent",
						style: { width: `${Math.min(100, m.progress / m.target * 100)}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-subtle",
					children: [
						fmtMoney(m.rewardMoney),
						" · ",
						m.rewardXp,
						" XP"
					]
				})
			]
		}, m.id))
	});
}
function SettingsBody({ game }) {
	const s = game.sim.s.settings;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs text-muted",
				children: [
					"Sound ",
					Math.round(s.sfx * 100),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 0,
						max: 1,
						step: .05,
						value: s.sfx,
						onChange: (e) => {
							s.sfx = Number(e.target.value);
							game.audio.sfxVol = s.sfx;
							game.audio.applyVol();
						},
						className: "mt-2 w-full"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs text-muted",
				children: [
					"Music ",
					Math.round(s.music * 100),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 0,
						max: 1,
						step: .05,
						value: s.music,
						onChange: (e) => {
							s.music = Number(e.target.value);
							game.audio.musicVol = s.music;
							game.audio.applyVol();
						},
						className: "mt-2 w-full"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center justify-between text-sm text-fg",
				children: ["Camera shake", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: s.shake,
					onChange: (e) => {
						s.shake = e.target.checked;
					}
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs text-muted",
				children: ["Quality", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: s.quality,
					onChange: (e) => game.setQuality(e.target.value),
					className: "mt-1 h-11 w-full rounded-lg border border-border bg-elevated px-3 text-sm text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "low",
							children: "Low"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "med",
							children: "Medium"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "high",
							children: "High"
						})
					]
				})]
			})
		]
	});
}
function Row({ title, detail, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex w-full items-center justify-between rounded-xl border border-border bg-elevated px-3 py-3 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-fg",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs tabular-nums text-muted",
			children: detail
		})]
	});
}
function PauseMenu({ onResume, onSettings, onTitle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-40 grid place-items-center bg-bg/70 px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm rounded-2xl border border-border bg-surface p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-fg",
				children: "Paused"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onResume,
						className: "h-12 rounded-xl bg-accent font-semibold text-accent-fg",
						children: "Resume"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onSettings,
						className: "h-12 rounded-xl border border-border-strong text-fg",
						children: "Settings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onTitle,
						className: "h-12 rounded-xl text-muted",
						children: "Title"
					})
				]
			})]
		})
	});
}
function DayEnd({ report, onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-40 grid place-items-center bg-bg/75 px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl border border-border bg-surface p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.2em] text-accent",
					children: "Closing report"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display mt-1 text-3xl text-fg",
					children: ["Day ", report.day]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-5 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Revenue",
							v: fmtMoney(report.revenue)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Rent",
							v: fmtMoney(report.rent)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Power",
							v: fmtMoney(report.power)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Wages",
							v: fmtMoney(report.wages)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Expenses",
							v: fmtMoney(report.expenses)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Profit",
							v: fmtMoney(report.profit),
							strong: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Sold",
							v: String(report.sold)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Served",
							v: String(report.served)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Walked out",
							v: String(report.lost)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							k: "Rating",
							v: report.rating.toFixed(1)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onNext,
					className: "mt-6 h-12 w-full rounded-xl bg-accent font-semibold text-accent-fg",
					children: "Next day"
				})
			]
		})
	});
}
function Line({ k, v, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: `tabular-nums ${strong ? "text-money" : "text-fg"}`,
			children: v
		})]
	});
}
function TitleScreen({ hasSave, onPlay, onFresh }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-30 flex flex-col items-center justify-center bg-bg/80 px-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(125,206,196,0.08),transparent_55%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative max-w-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs font-medium tracking-[0.28em] text-accent uppercase",
					children: "Independent grocer"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-5xl leading-none tracking-tight text-fg text-balance sm:text-6xl",
					children: "SUPER MARKET X"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-xl tracking-[0.2em] text-muted",
					children: "SIMULATOR"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-5 max-w-md text-sm leading-relaxed text-muted text-pretty",
					children: "Stock the bays, run the till, hire a crew, and grow a corner grocery into a hypermarket."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onPlay,
						className: "inline-flex h-12 min-w-[200px] items-center justify-center gap-2 rounded-xl bg-accent px-6 text-sm font-semibold text-accent-fg transition-transform duration-150 hover:brightness-110 active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
							className: "size-4",
							strokeWidth: 2.2
						}), hasSave ? "Continue" : "Open store"]
					}), hasSave ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onFresh,
						className: "inline-flex h-12 min-w-[160px] items-center justify-center gap-2 rounded-xl border border-border-strong bg-surface px-5 text-sm font-medium text-fg transition-transform duration-150 active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "New game"]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-xs text-subtle",
					children: "WASD move · mouse look · E interact · Shift sprint"
				})
			]
		})]
	});
}
var emptyHud = {
	money: 0,
	rating: 0,
	day: 1,
	clock: "8:00 AM",
	open: false,
	prompt: "",
	holding: null,
	cleanliness: 1,
	customers: 0,
	queue: 0,
	event: null,
	tutorial: null,
	interact: false,
	speed: 0,
	yaw: 0,
	px: 0,
	pz: 0,
	storeLevel: 1,
	location: "town",
	xp: 0
};
function GameApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const [phase, setPhase] = (0, import_react.useState)("title");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [hasSave, setHasSave] = (0, import_react.useState)(false);
	const [hud, setHud] = (0, import_react.useState)(emptyHud);
	const [toast, setToast] = (0, import_react.useState)(null);
	const [panel, setPanel] = (0, import_react.useState)(null);
	const [report, setReport] = (0, import_react.useState)(null);
	const [portrait, setPortrait] = (0, import_react.useState)(false);
	const toastT = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setHasSave(loadSave().day > 1 || loadSave().money !== 2800 || loadSave().xp > 0);
	}, []);
	(0, import_react.useEffect)(() => {
		const onResize = () => setPortrait(window.innerHeight > window.innerWidth + 40);
		onResize();
		window.addEventListener("resize", onResize);
		return () => window.removeEventListener("resize", onResize);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!canvasRef.current) return;
		let dead = false;
		let handle = null;
		import("./engine-D9NJmTdq.mjs").then(({ createGame }) => {
			if (dead || !canvasRef.current) return;
			handle = createGame(canvasRef.current, {
				onHud: (h) => setHud(h),
				onToast: (t) => {
					setToast(t);
					if (toastT.current) window.clearTimeout(toastT.current);
					toastT.current = window.setTimeout(() => setToast(null), 2800);
				},
				onDayEnd: (r) => {
					setReport(r);
					setPhase("dayend");
					handle?.stop();
				}
			});
			gameRef.current = handle;
			setReady(true);
		});
		return () => {
			dead = true;
			handle?.dispose();
			gameRef.current = null;
		};
	}, []);
	const play = () => {
		const g = gameRef.current;
		if (!g) return;
		g.audio.unlock();
		g.start();
		g.sim.s.seenHelp = true;
		setPhase("playing");
		setPanel(null);
	};
	const fresh = () => {
		clearSave();
		window.location.reload();
	};
	const onMove = (0, import_react.useCallback)((x, y) => {
		const g = gameRef.current;
		if (!g) return;
		g.input.stick.x = x;
		g.input.stick.y = y;
	}, []);
	const onLook = (0, import_react.useCallback)((x, y) => {
		const g = gameRef.current;
		if (!g) return;
		g.input.look.x = x * .35;
		g.input.look.y = y * .35;
	}, []);
	(0, import_react.useEffect)(() => {
		const g = gameRef.current;
		if (!g) return;
		g.input.enabled = phase === "playing" && !panel;
	}, [phase, panel]);
	const game = gameRef.current;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none",
				onPointerDown: () => {
					if (phase !== "playing" || panel) return;
					const c = canvasRef.current;
					if (c && window.matchMedia("(pointer:fine)").matches) c.requestPointerLock?.();
				}
			}),
			!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-10 grid place-items-center bg-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl tracking-widest text-muted",
					children: "LOADING AISLES"
				})
			}) : null,
			phase === "title" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleScreen, {
				hasSave,
				onPlay: play,
				onFresh: fresh
			}) : null,
			phase === "playing" || phase === "paused" || phase === "dayend" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {
				hud,
				toast,
				panel,
				onPanel: setPanel,
				onOpen: () => gameRef.current?.sim.toggleOpen(),
				onPause: () => {
					setPhase("paused");
					gameRef.current?.stop();
					document.exitPointerLock?.();
				},
				onInteract: () => {
					const g = gameRef.current;
					if (!g) return;
					g.input.interactHeld = true;
					window.setTimeout(() => {
						if (g.input) g.input.interactHeld = false;
					}, 80);
				},
				onSprint: (v) => {
					const g = gameRef.current;
					if (g) g.input.sprintTouch = v;
				},
				portrait
			}) : null,
			phase === "playing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchControls, {
				onMove,
				onLook
			}) : null,
			game && panel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GamePanel, {
				panel,
				game,
				onClose: () => setPanel(null),
				onRebuild: () => game.rebuild()
			}) : null,
			phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseMenu, {
				onResume: () => {
					setPhase("playing");
					gameRef.current?.start();
				},
				onSettings: () => {
					setPanel("settings");
					setPhase("playing");
					gameRef.current?.start();
				},
				onTitle: () => {
					setPhase("title");
					gameRef.current?.stop();
				}
			}) : null,
			phase === "dayend" && report ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayEnd, {
				report,
				onNext: () => {
					gameRef.current?.sim.nextDay();
					setReport(null);
					setPhase("playing");
					gameRef.current?.start();
				}
			}) : null
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { LOCATION_MAP as a, ROLE_META as c, SUPPLIERS as d, UPGRADE_COST as f, CUSTOMER_META as i, STAFF_NAMES as l, loadSave as n, PRODUCTS as o, storeFootprint as p, writeSave as r, PRODUCT_MAP as s, routes_exports as t, STORE_LABELS as u };
