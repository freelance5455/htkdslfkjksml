import { o as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Search, c as Heart, d as Copy, i as Share2, l as Gift, n as UserPlus, o as Radio, s as MessageCircle, t as Users } from "../_libs/lucide-react.mjs";
import { c as nextDemo, d as sampleGift, f as summarize, i as driftViewers, l as normalizeUsername, n as applyStats, o as formatCount, r as defaultSettings, s as isChatVisible, t as SEED, u as sampleChat } from "./model-CryEHs3X.mjs";
import { n as GoalMeter, r as ToggleRow, t as ChatLine } from "./bits-DB9gFqO2.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CfactBpL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VOICES = [
	{
		id: "mx",
		tag: "México",
		name: "Lina",
		place: "Ciudad de México",
		lang: "es-MX",
		gender: "f",
		pitch: 1.12,
		rate: 1.02,
		hints: [
			"méxico",
			"mexico",
			"mexican",
			"dalia",
			"sabina"
		],
		line: "Qué onda, soy Lina y leo el chat desde México."
	},
	{
		id: "es",
		tag: "España",
		name: "Mateo",
		place: "Madrid",
		lang: "es-ES",
		gender: "m",
		pitch: .84,
		rate: .95,
		hints: [
			"españa",
			"spain",
			"castell",
			"álvaro",
			"alvaro",
			"jorge"
		],
		line: "Hola, soy Mateo y te leo desde Madrid."
	},
	{
		id: "ar",
		tag: "Argentina",
		name: "Vale",
		place: "Buenos Aires",
		lang: "es-AR",
		gender: "f",
		pitch: 1.05,
		rate: 1.16,
		hints: ["argentin", "buenos aires"],
		line: "Che, soy Vale y te leo desde Buenos Aires."
	},
	{
		id: "co",
		tag: "Colombia",
		name: "Santi",
		place: "Bogotá",
		lang: "es-CO",
		gender: "m",
		pitch: .98,
		rate: .9,
		hints: ["colombia", "bogot"],
		line: "Quiubo, soy Santi y leo desde Bogotá."
	},
	{
		id: "cl",
		tag: "Chile",
		name: "Camila",
		place: "Santiago de Chile",
		lang: "es-CL",
		gender: "f",
		pitch: 1.2,
		rate: 1.2,
		hints: ["chile"],
		line: "Hola, soy Camila y te leo desde Santiago de Chile."
	},
	{
		id: "pe",
		tag: "Perú",
		name: "Diego",
		place: "Lima",
		lang: "es-PE",
		gender: "m",
		pitch: .88,
		rate: 1.02,
		hints: [
			"perú",
			"peru",
			"lima"
		],
		line: "Hola causa, soy Diego y leo desde Lima."
	},
	{
		id: "pr",
		tag: "Caribe",
		name: "Yara",
		place: "Puerto Rico",
		lang: "es-PR",
		gender: "f",
		pitch: 1.26,
		rate: 1.08,
		hints: [
			"puerto rico",
			"puerto",
			"cuba",
			"dominican",
			"caribe"
		],
		line: "Qué lo que, soy Yara y leo desde el Caribe."
	},
	{
		id: "ic",
		tag: "Canarias",
		name: "Lucía",
		place: "Canarias",
		lang: "es-ES",
		gender: "f",
		pitch: 1.18,
		rate: .9,
		hints: [
			"canaria",
			"canarias",
			"elvira",
			"helena"
		],
		line: "Hola, soy Lucía y te leo desde Canarias."
	},
	{
		id: "uy",
		tag: "Uruguay",
		name: "Renata",
		place: "Montevideo",
		lang: "es-UY",
		gender: "f",
		pitch: 1.02,
		rate: 1.12,
		hints: ["uruguay", "montevideo"],
		line: "Hola, soy Renata y te leo desde Montevideo."
	},
	{
		id: "ve",
		tag: "Venezuela",
		name: "Pablo",
		place: "Caracas",
		lang: "es-VE",
		gender: "m",
		pitch: .78,
		rate: 1.1,
		hints: ["venezuela", "caracas"],
		line: "Épale, soy Pablo y leo desde Caracas."
	},
	{
		id: "us",
		tag: "EE. UU.",
		name: "Noa",
		place: "Estados Unidos",
		lang: "es-US",
		gender: "f",
		pitch: 1.14,
		rate: 1,
		hints: [
			"estados unidos",
			"united states",
			"es-us",
			"us spanish"
		],
		line: "Hola, soy Noa y te leo en español de Estados Unidos."
	},
	{
		id: "ec",
		tag: "Ecuador",
		name: "Leo",
		place: "Quito",
		lang: "es-EC",
		gender: "m",
		pitch: .94,
		rate: .98,
		hints: ["ecuador", "quito"],
		line: "Hola, soy Leo y te leo desde Quito."
	}
];
var KNOWN = /* @__PURE__ */ new Set(["mix", ...VOICES.map((voice) => voice.id)]);
function isVoiceChoice(value) {
	return KNOWN.has(value);
}
function voiceById(id) {
	return VOICES.find((voice) => voice.id === id) ?? null;
}
function hashName(name) {
	let hash = 2166136261;
	for (let index = 0; index < name.length; index += 1) {
		hash ^= name.charCodeAt(index);
		hash = Math.imul(hash, 16777619);
	}
	return hash >>> 0;
}
function voiceFor(choice, who = "") {
	const fixed = voiceById(choice);
	if (fixed) return fixed;
	return VOICES[who ? hashName(who.toLowerCase()) % VOICES.length : 0] ?? VOICES[0];
}
var audio = null;
var queued = 0;
var generation = 0;
var previewCursor = 0;
var cachedVoices = [];
function unlockAudio() {
	if (typeof window === "undefined") return;
	const Ctx = window.AudioContext || window.webkitAudioContext;
	if (!Ctx) return;
	if (!audio) audio = new Ctx();
	if (audio.state === "suspended") audio.resume();
	warmVoices();
}
function warmVoices() {
	if (typeof window === "undefined" || !window.speechSynthesis) return;
	const list = window.speechSynthesis.getVoices();
	if (list.length) cachedVoices = list;
	window.speechSynthesis.onvoiceschanged = () => {
		cachedVoices = window.speechSynthesis.getVoices();
	};
}
function playChime(kind) {
	if (!audio || audio.state !== "running") return;
	const now = audio.currentTime;
	(kind === "gift" ? [
		523.25,
		659.25,
		783.99
	] : [440, 554.37]).forEach((freq, index) => {
		const osc = audio.createOscillator();
		const gain = audio.createGain();
		osc.type = "sine";
		osc.frequency.value = freq;
		gain.gain.setValueAtTime(1e-4, now + index * .07);
		gain.gain.exponentialRampToValueAtTime(.05, now + index * .07 + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + index * .07 + .18);
		osc.connect(gain);
		gain.connect(audio.destination);
		osc.start(now + index * .07);
		osc.stop(now + index * .07 + .2);
	});
}
function spanishVoices() {
	if (typeof window !== "undefined" && window.speechSynthesis) {
		const fresh = window.speechSynthesis.getVoices();
		if (fresh.length) cachedVoices = fresh;
	}
	return cachedVoices.filter((voice) => voice.lang.toLowerCase().replace("_", "-").startsWith("es"));
}
function scoreVoice(voice, profile) {
	let score = voice.lang.toLowerCase().replace("_", "-") === profile.lang.toLowerCase() ? 100 : 40;
	const name = `${voice.name} ${voice.lang}`.toLowerCase();
	if (profile.hints.some((hint) => name.includes(hint))) score += 36;
	const female = /female|mujer|woman|dalia|elvira|sabina|paulina|helena|laura|monica|sof[ií]a/.test(name);
	const male = /male|hombre|\bman\b|alvaro|álvaro|jorge|enrique|pablo|raul|diego/.test(name);
	if (profile.gender === "f" && female) score += 24;
	if (profile.gender === "m" && male) score += 24;
	if (profile.gender === "f" && male) score -= 18;
	if (profile.gender === "m" && female) score -= 18;
	return score;
}
function bestOf(voices, profile) {
	let best = voices[0];
	let bestScore = -1;
	for (const voice of voices) {
		const score = scoreVoice(voice, profile);
		if (score > bestScore) {
			best = voice;
			bestScore = score;
		}
	}
	return best;
}
function matchVoice(profile) {
	const voices = spanishVoices();
	if (!voices.length) return null;
	const want = profile.lang.toLowerCase();
	const exact = voices.filter((voice) => voice.lang.toLowerCase().replace("_", "-") === want);
	if (exact.length) return bestOf(exact, profile);
	if (voices.length > 1) return voices[Math.max(0, VOICES.findIndex((voice) => voice.id === profile.id)) % voices.length] ?? voices[0];
	return bestOf(voices, profile);
}
function utter(text, profile, interrupt) {
	if (typeof window === "undefined" || !window.speechSynthesis) return;
	if (!interrupt && queued >= 2) return;
	if (interrupt) {
		generation += 1;
		window.speechSynthesis.cancel();
		queued = 0;
	}
	const token = generation;
	const utterance = new SpeechSynthesisUtterance(text.slice(0, 180));
	const match = matchVoice(profile);
	utterance.lang = match?.lang || profile.lang;
	utterance.pitch = profile.pitch;
	utterance.rate = profile.rate;
	if (match) utterance.voice = match;
	queued += 1;
	const done = () => {
		if (token !== generation) return;
		queued = Math.max(0, queued - 1);
	};
	utterance.onend = done;
	utterance.onerror = done;
	if (window.speechSynthesis.paused) window.speechSynthesis.resume();
	window.speechSynthesis.speak(utterance);
}
function speak(text, choice = "mix", who = "") {
	utter(text, voiceFor(choice, who), false);
}
function previewVoice(choice = "mix") {
	const profile = choice === "mix" ? VOICES[previewCursor++ % VOICES.length] : voiceFor(choice);
	utter(profile.line, profile, true);
}
function postToFrames(payload) {
	if (typeof document === "undefined") return;
	document.querySelectorAll("iframe").forEach((frame) => {
		frame.contentWindow?.postMessage({
			source: "onda",
			...payload
		}, window.location.origin);
	});
}
async function relay(roomId, body) {
	if (!roomId) return;
	try {
		await fetch("/api/live", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				roomId,
				...body
			})
		});
	} catch {}
}
var SETTINGS_KEY = "onda-settings-v1";
var useStudio = create((set) => ({
	feed: SEED,
	stats: summarize(SEED),
	username: "",
	phase: "demo",
	notice: "Sala demo con comentarios de ejemplo. Conecta un @ que esté en vivo para leer el chat real.",
	host: "",
	roomId: "",
	settings: defaultSettings,
	hidden: [],
	answered: [],
	overlay: "chat",
	metric: "likes",
	setUsername: (username) => set({ username }),
	setRoomId: (roomId) => set({ roomId }),
	setPhase: (phase, notice, host) => set((state) => ({
		phase,
		notice,
		host: host === void 0 ? state.host : host
	})),
	patchSettings: (patch) => set((state) => {
		const settings = {
			...state.settings,
			...patch
		};
		try {
			localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
		} catch {}
		return { settings };
	}),
	hydrateSettings: (settings) => set({ settings }),
	add: (event) => set((state) => {
		if (event.kind !== "viewers" && event.kind !== "like" && state.feed.some((item) => item.id === event.id)) return state;
		const stats = applyStats(state.stats, event);
		if (event.kind === "viewers") return { stats };
		if (event.kind === "like") {
			if (!state.settings.showLikes) return { stats };
			return {
				stats,
				feed: [...state.feed.filter((item) => item.kind !== "like"), event].slice(-180)
			};
		}
		return {
			stats,
			feed: [...state.feed, event].slice(-180)
		};
	}),
	show: (event) => set((state) => {
		if (event.kind === "viewers" || event.kind === "like" || event.kind === "sync" || event.kind === "status") return state;
		if (state.feed.some((item) => item.id === event.id)) return state;
		return { feed: [...state.feed, event].slice(-180) };
	}),
	setStats: (stats) => set({ stats }),
	resetFeed: (events) => set({
		feed: events,
		stats: summarize(events),
		answered: []
	}),
	hideUser: (name) => set((state) => ({ hidden: state.hidden.includes(name) ? state.hidden : [...state.hidden, name] })),
	toggleAnswered: (id) => set((state) => ({ answered: state.answered.includes(id) ? state.answered.filter((item) => item !== id) : [...state.answered, id] })),
	setOverlay: (overlay) => set({ overlay }),
	setMetric: (metric) => set({ metric })
}));
function loadStoredSettings() {
	try {
		const raw = localStorage.getItem(SETTINGS_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (parsed.voice && !isVoiceChoice(parsed.voice)) parsed.voice = defaultSettings.voice;
		return {
			...defaultSettings,
			...parsed
		};
	} catch {
		return null;
	}
}
function overlayPath(kind, roomId, settings, metric) {
	const params = new URLSearchParams({
		room: roomId,
		scale: settings.fontScale,
		hide: String(settings.hideAfter),
		joins: settings.showJoins ? "1" : "0",
		likes: settings.showLikes ? "1" : "0",
		mods: settings.modsOnly ? "1" : "0",
		blocked: settings.blocked
	});
	if (kind === "goal") {
		const goal = metric === "likes" ? settings.likeGoal : metric === "follows" ? settings.followGoal : settings.coinGoal;
		params.set("metric", metric);
		params.set("goal", String(goal));
	}
	return `/overlay/${kind}?${params.toString()}`;
}
function StudioApp() {
	const feed = useStudio((s) => s.feed);
	const stats = useStudio((s) => s.stats);
	const username = useStudio((s) => s.username);
	const phase = useStudio((s) => s.phase);
	const notice = useStudio((s) => s.notice);
	const host = useStudio((s) => s.host);
	const roomId = useStudio((s) => s.roomId);
	const settings = useStudio((s) => s.settings);
	const hidden = useStudio((s) => s.hidden);
	const answered = useStudio((s) => s.answered);
	const overlay = useStudio((s) => s.overlay);
	const metric = useStudio((s) => s.metric);
	const setUsername = useStudio((s) => s.setUsername);
	const setRoomId = useStudio((s) => s.setRoomId);
	const setPhase = useStudio((s) => s.setPhase);
	const patchSettings = useStudio((s) => s.patchSettings);
	const hydrateSettings = useStudio((s) => s.hydrateSettings);
	const add = useStudio((s) => s.add);
	const show = useStudio((s) => s.show);
	const setStats = useStudio((s) => s.setStats);
	const resetFeed = useStudio((s) => s.resetFeed);
	const hideUser = useStudio((s) => s.hideUser);
	const toggleAnswered = useStudio((s) => s.toggleAnswered);
	const setOverlay = useStudio((s) => s.setOverlay);
	const setMetric = useStudio((s) => s.setMetric);
	const [tab, setTab] = (0, import_react.useState)("chat");
	const [query, setQuery] = (0, import_react.useState)("");
	const [signKey, setSignKey] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [rail, setRail] = (0, import_react.useState)("top");
	const viewers = (0, import_react.useRef)(stats.viewers || 186);
	const scroller = (0, import_react.useRef)(null);
	const stick = (0, import_react.useRef)(true);
	const seenSpeech = (0, import_react.useRef)(new Set(SEED.map((event) => event.id)));
	(0, import_react.useEffect)(() => {
		const stored = loadStoredSettings();
		if (stored) hydrateSettings(stored);
		const id = localStorage.getItem("onda-room") || crypto.randomUUID();
		localStorage.setItem("onda-room", id);
		setRoomId(id);
		relay(id, { action: "prime" });
	}, [hydrateSettings, setRoomId]);
	(0, import_react.useEffect)(() => {
		if (phase !== "demo") return;
		const id = window.setInterval(() => {
			const next = nextDemo(viewers.current);
			viewers.current = next.viewers;
			emit(next.event);
			if (Math.random() > .72) {
				const drift = driftViewers(viewers.current);
				viewers.current = drift.count;
				emit(drift);
			}
		}, 2800);
		return () => window.clearInterval(id);
	}, [phase, roomId]);
	(0, import_react.useEffect)(() => {
		if (!listening || !roomId) return;
		const source = new EventSource(`/api/live?room=${encodeURIComponent(roomId)}`);
		source.onmessage = (message) => {
			const event = JSON.parse(message.data);
			if (event.kind === "sync") {
				setStats({
					viewers: event.viewers,
					likes: event.likes,
					follows: event.follows,
					shares: event.shares,
					coins: event.coins,
					ranks: event.ranks
				});
				broadcast();
				return;
			}
			if (event.kind === "status") {
				setPhase(event.phase, event.message, useStudio.getState().host);
				return;
			}
			if (event.replay) {
				show(event);
				return;
			}
			add(event);
			broadcast();
			voice(event);
		};
		return () => source.close();
	}, [
		listening,
		roomId,
		add,
		setPhase,
		setStats,
		show
	]);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el || !stick.current) return;
		el.scrollTop = el.scrollHeight;
	}, [feed.length]);
	const lines = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return feed.filter((event) => {
			if (!isChatVisible(event, settings, hidden)) return false;
			if (!needle) return true;
			return (event.kind === "chat" ? `${event.user.nick} ${event.user.name} ${event.text}` : "user" in event ? `${event.user.nick} ${event.user.name} ${event.kind}` : "").toLowerCase().includes(needle);
		});
	}, [
		feed,
		settings,
		hidden,
		query
	]);
	const questions = feed.filter((event) => event.kind === "chat" && event.text.includes("?"));
	const activity = feed.filter((event) => event.kind === "gift" || event.kind === "follow" || event.kind === "share" || event.kind === "join");
	function broadcast() {
		const state = useStudio.getState();
		postToFrames({
			snapshot: state.feed,
			stats: state.stats
		});
	}
	function emit(event) {
		const state = useStudio.getState();
		state.add(event);
		broadcast();
		if (state.phase === "demo" && state.roomId) relay(state.roomId, {
			action: "push",
			event
		});
		voice(event);
	}
	function voice(event) {
		if (seenSpeech.current.has(event.id)) return;
		seenSpeech.current.add(event.id);
		const state = useStudio.getState();
		const choice = state.settings.voice;
		if (event.kind === "chat" && state.settings.ttsChat) speak(`${event.user.nick} dice ${event.text}`, choice, event.user.name);
		if (event.kind === "gift" && state.settings.ttsGifts) speak(`${event.user.nick} envió ${event.gift}`, choice, event.user.name);
		if (event.kind === "gift" && state.settings.sound) playChime("gift");
		if (event.kind === "follow" && state.settings.sound) playChime("follow");
	}
	async function connectLive() {
		unlockAudio();
		const name = normalizeUsername(username);
		if (!name) {
			setPhase("error", "Escribe un usuario válido, sin espacios. También puedes pegar el enlace del live.");
			return;
		}
		setListening(false);
		resetFeed([]);
		setPhase("connecting", `Buscando el live de @${name}…`, name);
		const response = await fetch("/api/live", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				action: "start",
				roomId,
				username: name,
				signApiKey: signKey.trim() || void 0
			})
		});
		if (!response.ok) {
			const payload = await response.json().catch(() => null);
			setPhase("error", payload?.error || "No se pudo iniciar la lectura.");
			return;
		}
		setListening(true);
	}
	async function backToDemo() {
		setListening(false);
		if (roomId) await relay(roomId, { action: "stop" });
		resetFeed(SEED);
		viewers.current = 186;
		setPhase("demo", "Sala demo otra vez. Los overlays siguen el ejemplo hasta que conectes un live.", "");
		if (roomId) relay(roomId, { action: "prime" });
	}
	async function trySample(kind) {
		const state = useStudio.getState();
		if (state.phase === "live" || state.phase === "connecting") {
			await relay(state.roomId, {
				action: "inject",
				kind
			});
			return;
		}
		emit(kind === "chat" ? sampleChat() : sampleGift());
	}
	async function copyLink(kind) {
		const path = overlayPath(kind, roomId, settings, metric);
		try {
			await navigator.clipboard.writeText(`${window.location.origin}${path}`);
			setCopied(kind);
			window.setTimeout(() => setCopied(""), 1600);
		} catch {
			setCopied("");
		}
	}
	const preview = overlayPath(overlay, roomId, settings, metric);
	const goal = metric === "likes" ? settings.likeGoal : metric === "follows" ? settings.followGoal : settings.coinGoal;
	const goalValue = metric === "likes" ? stats.likes : metric === "follows" ? stats.follows : stats.coins;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg text-fg",
		onPointerDown: unlockAudio,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex shrink-0 items-center gap-3 border-b border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl leading-none text-fg",
							children: "Onda"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `inline-flex items-center gap-2 rounded-full border px-2.5 py-1 text-xs font-semibold ${phase === "live" || phase === "connecting" ? "border-signal text-signal" : phase === "error" ? "border-hot text-hot" : "border-line text-muted"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-2 w-2 rounded-full ${phase === "error" ? "bg-hot" : "bg-signal"} ${phase === "demo" ? "" : "onda-led"}` }),
								phase === "live" ? "En vivo" : phase === "connecting" ? "Conectando" : phase === "error" ? "Sin live" : "Sala demo",
								host ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium text-fg",
									children: ["@", host]
								}) : null
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate text-sm text-muted",
						children: "Chat, regalos y capas de un TikTok LIVE"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto hidden items-center gap-4 tabular-nums text-sm text-muted sm:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-signal" }), formatCount(stats.viewers)]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-4 w-4 text-hot" }), formatCount(stats.likes)]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex shrink-0 gap-2 border-b border-line px-3 py-3 lg:hidden",
				onSubmit: (event) => {
					event.preventDefault();
					connectLive();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: username,
					onChange: (event) => setUsername(event.target.value),
					placeholder: "@usuario o enlace",
					"aria-label": "Usuario de TikTok",
					className: "h-11 min-w-0 flex-1 rounded-md border border-line bg-surface px-3 text-fg placeholder:text-muted"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-11 shrink-0 rounded-md bg-signal px-3 text-sm font-semibold text-bg",
					children: "Leer"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-h-0 flex-1 lg:grid-cols-[300px_minmax(0,1fr)_300px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: `${tab === "capas" ? "flex" : "hidden"} min-h-0 flex-col gap-4 overflow-y-auto border-line p-4 lg:flex lg:border-r`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "hidden flex-col gap-3 lg:flex",
								onSubmit: (event) => {
									event.preventDefault();
									connectLive();
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-semibold text-fg",
										children: "Conexión"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-pretty text-muted",
										children: "El usuario de quien esté emitiendo. Onda lee el chat público: comentarios, regalos, likes y follows."
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: username,
										onChange: (event) => setUsername(event.target.value),
										placeholder: "@usuario o enlace del live",
										"aria-label": "Usuario de TikTok",
										className: "h-11 rounded-md border border-line bg-bg px-3 text-fg placeholder:text-muted"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										disabled: phase === "connecting",
										className: "h-11 rounded-md bg-signal text-sm font-semibold text-bg disabled:opacity-60",
										children: phase === "connecting" ? "Buscando el live…" : "Leer este live"
									}),
									phase !== "demo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void backToDemo(),
										className: "h-11 rounded-md border border-line text-sm text-fg",
										children: "Volver a la sala demo"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
										className: "text-sm text-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
												className: "cursor-pointer text-fg",
												children: "Clave Euler, opcional"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-pretty",
												children: "El chat entra sin clave. Pégala solo si TikTok pide una firma extra. No se guarda."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: signKey,
												onChange: (event) => setSignKey(event.target.value),
												type: "password",
												autoComplete: "off",
												placeholder: "Clave",
												"aria-label": "Clave de Euler Stream",
												className: "mt-2 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg placeholder:text-muted"
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-semibold text-fg",
										children: "Lectura"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
										on: settings.ttsChat,
										label: "Leer comentarios",
										onClick: () => patchSettings({ ttsChat: !settings.ttsChat })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
										on: settings.ttsGifts,
										label: "Leer regalos",
										onClick: () => patchSettings({ ttsGifts: !settings.ttsGifts })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
										on: settings.sound,
										label: "Sonido de alertas",
										onClick: () => patchSettings({ sound: !settings.sound })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoicePicker, {
										value: settings.voice,
										onChange: (voice) => patchSettings({ voice })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
										on: settings.showJoins,
										label: "Mostrar entradas",
										onClick: () => patchSettings({ showJoins: !settings.showJoins })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
										on: settings.showLikes,
										label: "Mostrar likes",
										onClick: () => patchSettings({ showLikes: !settings.showLikes })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
										on: settings.modsOnly,
										label: "Solo mods y subs",
										onClick: () => patchSettings({ modsOnly: !settings.modsOnly })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-sm text-muted",
										children: ["Palabras bloqueadas", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: settings.blocked,
											onChange: (event) => patchSettings({ blocked: event.target.value }),
											placeholder: "spoiler, insulto",
											className: "mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg placeholder:text-muted"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-sm text-muted",
										children: [settings.hideAfter === 0 ? "Las líneas se quedan en pantalla" : `Las líneas se van a los ${settings.hideAfter}s`, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 30,
											value: settings.hideAfter,
											onChange: (event) => patchSettings({ hideAfter: Number(event.target.value) }),
											className: "mt-2 w-full accent-signal"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex gap-2",
										children: [
											"sm",
											"md",
											"lg"
										].map((scale) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => patchSettings({ fontScale: scale }),
											className: `h-11 flex-1 rounded-md border text-sm ${settings.fontScale === scale ? "border-signal text-signal" : "border-line text-muted"}`,
											children: scale === "sm" ? "Chico" : scale === "md" ? "Medio" : "Grande"
										}, scale))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-semibold text-fg",
										children: "Capas para OBS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-pretty text-muted",
										children: "Copia el enlace y pégalo como fuente de navegador o enlace. Deja esta pestaña abierta."
									}),
									[
										["chat", "Chat"],
										["alert", "Alerta de regalo"],
										["goal", "Meta"],
										["rank", "Top regalos"]
									].map(([kind, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setOverlay(kind),
											className: `h-11 flex-1 rounded-md border px-3 text-left text-sm ${overlay === kind ? "border-signal text-fg" : "border-line text-muted"}`,
											children: label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => void copyLink(kind),
											className: "inline-flex h-11 w-11 items-center justify-center rounded-md border border-line text-fg",
											"aria-label": `Copiar enlace de ${label}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" })
										})]
									}, kind)),
									copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-signal",
										children: "Enlace copiado."
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex gap-2",
										children: [
											"likes",
											"follows",
											"coins"
										].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setMetric(item),
											className: `h-11 flex-1 rounded-md border text-sm ${metric === item ? "border-signal text-signal" : "border-line text-muted"}`,
											children: item === "likes" ? "Likes" : item === "follows" ? "Follows" : "Monedas"
										}, item))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-sm text-muted",
										children: [
											"Meta de ",
											metric === "likes" ? "likes" : metric === "follows" ? "follows" : "monedas",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												min: 1,
												max: 1e7,
												value: goal,
												onChange: (event) => {
													const value = Math.max(1, Number(event.target.value) || 1);
													if (metric === "likes") patchSettings({ likeGoal: value });
													else if (metric === "follows") patchSettings({ followGoal: value });
													else patchSettings({ coinGoal: value });
												},
												className: "mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 tabular-nums text-fg"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => void trySample("chat"),
											className: "h-11 flex-1 rounded-md border border-line text-sm text-fg",
											children: "Probar chat"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => void trySample("gift"),
											className: "h-11 flex-1 rounded-md border border-line text-sm text-fg",
											children: "Probar regalo"
										})]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: `${tab === "chat" ? "flex" : "hidden"} min-h-0 flex-col lg:flex`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 border-b border-line px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: query,
									onChange: (event) => setQuery(event.target.value),
									placeholder: "Filtrar el chat",
									"aria-label": "Filtrar el chat",
									className: "h-11 min-w-0 flex-1 bg-transparent text-sm text-fg placeholder:text-muted"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "status",
								className: "border-b border-line px-4 py-2 text-sm text-pretty text-muted",
								children: notice
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								ref: scroller,
								onScroll: () => {
									const el = scroller.current;
									if (!el) return;
									stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
								},
								className: "min-h-0 flex-1 overflow-y-auto px-2 py-2",
								children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-3 py-8 text-sm text-muted",
									children: "Nada que mostrar con estos filtros."
								}) : lines.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatLine, {
									event,
									onHide: hideUser,
									scale: settings.fontScale,
									place: settings.voice === "mix" && (settings.ttsChat || settings.ttsGifts) && (event.kind === "chat" || event.kind === "gift") ? voiceFor("mix", event.user.name).tag : void 0
								}, event.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden border-t border-line p-3 lg:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "scene-preview relative h-40 overflow-hidden rounded-lg border border-line",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
										title: "Vista previa de la capa",
										src: preview,
										onLoad: () => broadcast(),
										className: "h-full w-full"
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: `${tab === "sala" ? "block" : "hidden"} min-h-0 overflow-y-auto border-line p-4 lg:block lg:border-l`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-signal" }),
										label: "Viendo",
										value: formatCount(stats.viewers)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-4 w-4 text-hot" }),
										label: "Likes",
										value: formatCount(stats.likes)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4 text-signal" }),
										label: "Follows",
										value: formatCount(stats.follows)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-4 w-4 text-hot" }),
										label: "Monedas",
										value: formatCount(stats.coins)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 rounded-lg border border-line bg-surface p-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalMeter, {
									label: metric === "likes" ? "Meta de likes" : metric === "follows" ? "Meta de follows" : "Meta de monedas",
									value: goalValue,
									goal
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex gap-2",
								children: [
									["top", "Top"],
									["preguntas", "Preguntas"],
									["sala", "Sala"]
								].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setRail(id),
									className: `h-11 flex-1 rounded-md border text-sm ${rail === id ? "border-signal text-fg" : "border-line text-muted"}`,
									children: [label, id === "preguntas" ? ` ${questions.length}` : ""]
								}, id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-col gap-2",
								children: [
									rail === "top" ? stats.ranks.slice(0, 5).map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 rounded-md border border-line px-3 py-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `w-5 tabular-nums font-semibold ${index === 0 ? "text-signal" : "text-muted"}`,
												children: index + 1
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "min-w-0 flex-1 truncate text-sm",
												children: row.nick
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "tabular-nums text-sm text-muted",
												children: formatCount(row.coins)
											})
										]
									}, row.name)) : null,
									rail === "top" && stats.ranks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "Todavía no entra un regalo."
									}) : null,
									rail === "preguntas" ? questions.slice().reverse().map((event) => event.kind === "chat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => toggleAnswered(event.id),
										className: `rounded-md border border-line px-3 py-3 text-left ${answered.includes(event.id) ? "opacity-50" : ""}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-semibold text-fg",
											children: event.user.nick
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-sm text-pretty text-fg",
											children: event.text
										})]
									}, event.id) : null) : null,
									rail === "preguntas" && questions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "Las preguntas con ? aparecen aquí."
									}) : null,
									rail === "sala" ? activity.slice().reverse().slice(0, 12).map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-sm text-fg",
										children: [
											event.kind === "gift" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-4 w-4 text-hot" }) : null,
											event.kind === "follow" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4 text-signal" }) : null,
											event.kind === "share" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "h-4 w-4 text-muted" }) : null,
											event.kind === "join" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "h-4 w-4 text-muted" }) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "min-w-0 truncate",
												children: [
													"user" in event ? event.user.nick : "",
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted",
														children: event.kind === "gift" ? event.gift : event.kind === "follow" ? "follow" : event.kind === "share" ? "share" : "entró"
													})
												]
											})
										]
									}, event.id)) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 flex items-start gap-2 text-sm text-pretty text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "mt-0.5 h-4 w-4 shrink-0" }), "En la sala demo los comentarios son de prueba. Al conectar, se sustituyen por el live."]
							}),
							phase !== "demo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void backToDemo(),
								className: "mt-3 h-11 w-full rounded-md border border-line text-sm lg:hidden",
								children: "Volver a la sala demo"
							}) : null
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "grid shrink-0 grid-cols-3 border-t border-line lg:hidden",
				children: [
					["chat", "Chat"],
					["sala", "Sala"],
					["capas", "Capas"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(id),
					className: `h-14 text-sm font-semibold ${tab === id ? "text-signal" : "text-muted"}`,
					children: label
				}, id))
			})
		]
	});
}
function VoicePicker({ value, onChange }) {
	const selected = value === "mix" ? null : voiceFor(value);
	const choices = [{
		id: "mix",
		label: "Varias"
	}, ...VOICES.map((voice) => ({
		id: voice.id,
		label: voice.tag
	}))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-fg",
				children: "Acentos"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: selected ? `${selected.name} lee todo, con acento de ${selected.place}.` : "Cada persona conserva un acento. Prueba varias para oírlos."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid grid-cols-2 gap-2",
				role: "group",
				"aria-label": "Acento de la voz",
				children: choices.map((choice) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": value === choice.id,
					onClick: () => onChange(choice.id),
					className: `h-11 rounded-md border px-2 text-sm ${value === choice.id ? "border-signal text-signal" : "border-line text-muted"}`,
					children: choice.label
				}, choice.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					unlockAudio();
					previewVoice(value);
				},
				className: "mt-2 h-11 w-full rounded-md border border-line text-sm text-fg",
				children: "Probar voz"
			})
		]
	});
}
function Stat({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1.5 text-xs text-muted",
			children: [icon, label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xl font-semibold tabular-nums text-fg",
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioApp, {});
}
//#endregion
export { Home as component };
