import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { _ as Check, a as Shield, c as Send, d as Mic, f as MessageCircle, g as Clock, h as Download, i as Signal, l as Search, m as Image$1, n as Users, o as Share2, p as Lock, s as Settings, t as VideoOff, u as Phone, v as BadgeCheck } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as require_lib } from "../_libs/qrcode.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-7x0H-DXC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
var PEOPLE = [
	{
		id: "hana",
		name: "Hana Bekele",
		city: "Addis Ababa",
		about: "Clinic rounds until the light goes.",
		online: true
	},
	{
		id: "tolosa",
		name: "Tolosa Gemechu",
		city: "Adama",
		about: "On the road toward Asella.",
		online: true
	},
	{
		id: "meron",
		name: "Meron Tadesse",
		city: "Dire Dawa",
		about: "The train is late again.",
		online: false
	},
	{
		id: "kenna",
		name: "Kenna Jiru",
		city: "Jimma",
		about: "Coffee is drying on the beds today.",
		online: true
	},
	{
		id: "abel",
		name: "Abel Mekonnen",
		city: "Nairobi",
		about: "Same hour tomorrow if the line holds.",
		online: false
	},
	{
		id: "sara",
		name: "Sara Ahmed",
		city: "London",
		about: "Night shift. A voice note is easier.",
		online: true
	},
	{
		id: "liya",
		name: "Liya Worku",
		city: "Washington",
		about: "Sunday call, if the path is quiet.",
		online: false
	},
	{
		id: "yonatan",
		name: "Yonatan Desta",
		city: "Bahir Dar",
		about: "The lake is calm. Text first.",
		online: true
	}
];
function personById(id) {
	return PEOPLE.find((p) => p.id === id);
}
function initials(name) {
	return name.split(/\s+/).slice(0, 2).map((p) => p[0] ?? "").join("").toUpperCase();
}
var SEEDS = {
	en: [
		{
			contactId: "hana",
			from: "them",
			text: "The ward is loud, but this came through. Are you in the city?",
			minutesAgo: 80
		},
		{
			contactId: "hana",
			from: "me",
			text: "On the way. The signal thins out past Bole.",
			minutesAgo: 74
		},
		{
			contactId: "tolosa",
			from: "them",
			text: "Coffee is on. Call if the road is washed out.",
			minutesAgo: 26
		},
		{
			contactId: "sara",
			from: "them",
			text: "Night shift. Send a voice note if typing is hard.",
			minutesAgo: 6
		}
	],
	om: [
		{
			contactId: "hana",
			from: "them",
			text: "Waardiin waca, garuu ergaan si qaqqabe. Magaalaa keessa jirtaa?",
			minutesAgo: 80
		},
		{
			contactId: "hana",
			from: "me",
			text: "Karaa irra. Sararri Boolee booda laafa.",
			minutesAgo: 74
		},
		{
			contactId: "tolosa",
			from: "them",
			text: "Bunni qophaa'eera. Karaa yoo cite bilbili.",
			minutesAgo: 26
		},
		{
			contactId: "sara",
			from: "them",
			text: "Halkan hojjadha. Barreessuun yoo ulfaate sagalee ergi.",
			minutesAgo: 6
		}
	],
	am: [
		{
			contactId: "hana",
			from: "them",
			text: "ዋርዱ ጫጫታ ነው፣ መልዕክቱ ግን ደረሰ። ከተማው ውስጥ ነዎት?",
			minutesAgo: 80
		},
		{
			contactId: "hana",
			from: "me",
			text: "መንገድ ላይ ነኝ። ከቦሌ በኋላ መስመሩ ይዳከማል።",
			minutesAgo: 74
		},
		{
			contactId: "tolosa",
			from: "them",
			text: "ቡና ዝግጁ ነው። መንገዱ ከተበላሸ ይደውሉ።",
			minutesAgo: 26
		},
		{
			contactId: "sara",
			from: "them",
			text: "የሌሊት ፈረቃ ነው። መጻፍ ከከበደ የድምጽ መልዕክት ይላኩ።",
			minutesAgo: 6
		}
	]
};
function seedTexts(lang) {
	return SEEDS[lang];
}
var REPLIES = {
	en: {
		hana: ["Between patients. I'll answer properly after sunset.", "Received. This ward network drops a lot."],
		tolosa: ["I saw it. I'll wait at the station if the rain starts.", "Good. Keep the voice notes short."],
		meron: ["Train still hasn't moved. Text is better than a call.", "Got it. I'll reply when we roll."],
		kenna: ["The drying beds can wait. Say what you need.", "Heard. I'll send a photo of the lot later."],
		abel: ["Line is expensive here. I have it.", "Okay. I'll call when I'm on wifi."],
		sara: ["I'm on break. Go ahead.", "Voice note received. I'll listen after this round."],
		liya: ["It's late here, but I saw this.", "I'll answer in the morning my time."],
		yonatan: ["Lake's quiet. I'm here.", "Send the photo. Data is fine for a minute."]
	},
	om: {
		hana: ["Yaalii gidduu dha. Aduu lixxee deebisa.", "Na qaqqabe. Sararri waardii baay'ee cita."],
		tolosa: ["Argeera. Roobni yoo eegale buufata eega.", "Tole. Sagalee gabaabsi."],
		meron: ["Treeniin ammayyuu hin sochoone. Barreeffamni wayya.", "Na qaqqabe. Yoon deemu deebisa."],
		kenna: ["Sireen qorraa eeguu danda'a. Waan barbaaddu himi.", "Dhaga'eera. Suuraa booda siif erga."],
		abel: ["Sararri asitti gatiidha. Na qaqqabe.", "Tole. WiFi irratti bilbilaan."],
		sara: ["Boqonnaa irra jira. Itti fufi.", "Sagaleen na qaqqabe. Eega xumure dhaggeeffadha."],
		liya: ["Asitti sa'aatiin galgalee, garuu argeera.", "Ganama kootiin deebisa."],
		yonatan: ["Harri callisaadha. As jira.", "Suuraa ergi. Daataan daqiiqaa tokkoof ni danda'ama."]
	},
	am: {
		hana: ["በታካሚዎች መካከል ነኝ። ፀሐይ ከጠለቀች በኋላ እመልሳለሁ።", "ደረሰኝ። የዋርዱ መስመር ብዙ ጊዜ ይቋረጣል።"],
		tolosa: ["አየሁት። ዝናብ ከጀመረ ጣቢያው እጠብቃለሁ።", "እሺ። የድምጽ መልዕክቱን አጭር አድርጉ።"],
		meron: ["ባቡሩ አልተንቀሳቀሰም። ጽሑፍ ከጥሪ ይሻላል።", "ደረሰኝ። ስንጓዝ እመልሳለሁ።"],
		kenna: ["የማድረቂያው አልጋ ሊጠብቅ ይችላል። የሚያስፈልግዎትን ይበሉ።", "ሰማሁ። ፎቶ በኋላ እልካለሁ።"],
		abel: ["መስመሩ እዚህ ውድ ነው። ደረሰኝ።", "እሺ። ዋይፋይ ላይ እደውላለሁ።"],
		sara: ["እረፍት ላይ ነኝ። ይቀጥሉ።", "የድምጽ መልዕክቱ ደረሰ። ዙሩን ጨርሼ አዳምጣለሁ።"],
		liya: ["እዚህ ምሽት ሆኗል፣ ግን አየሁት።", "በኔ ጊዜ ጠዋት እመልሳለሁ።"],
		yonatan: ["ሐይቁ ጸጥ ነው። እዚህ ነኝ።", "ፎቶውን ይላኩ። ለደቂቃ ውሂቡ ይሆናል።"]
	}
};
function replyLine(lang, contactId) {
	const pool = REPLIES[lang][contactId] ?? REPLIES.en[contactId] ?? ["Received."];
	return pool[Math.floor(Math.random() * pool.length)] ?? "Received.";
}
var goldBtn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-gold px-4 text-sm font-semibold text-ink disabled:opacity-50";
var ghostBtn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 text-sm font-medium text-fg disabled:opacity-50";
var fieldCls = "min-h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm text-fg outline-none focus:border-gold";
function Avatar({ name, online, src }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative grid size-11 shrink-0 place-items-center overflow-hidden rounded-full bg-surface-2 text-sm font-semibold text-gold",
		children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "size-full object-cover"
		}) : initials(name), online === void 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute right-0 bottom-0 size-3 rounded-full ring-2 ring-bg ${online ? "bg-gold" : "bg-line"}` })]
	});
}
function ScreenScroll({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full overflow-y-auto px-4 py-5",
		children
	});
}
var STR = {
	en: {
		tagline: "Messages for a thin signal.",
		principleScan: "A card is read on this phone. The number becomes a one-way key and is thrown away.",
		principleLock: "Chats are locked here. A relay would only ever carry ciphertext.",
		principleQueue: "If the path drops, messages wait on the phone, then send themselves.",
		languageTitle: "Choose a language",
		languageBody: "Afaan Oromoo, Amharic, and English. You can change this later.",
		continue: "Continue",
		scanTitle: "Read an ID",
		scanBody: "Your name is taken from the card. You cannot type it or change it. The ID number is never stored.",
		practice: "Practice card",
		practiceNote: "Not a real document. Used so this preview can read a name without a camera.",
		fayda: "Fayda-style card",
		passport: "Passport",
		kebele: "Kebele card",
		readCard: "Read this card",
		reading: "Reading on this device…",
		nameRead: "Name read",
		nameLocked: "Locked. This name cannot be edited.",
		numberGone: "ID number hashed and discarded. It is not on this phone.",
		retake: "Choose another card",
		toSelfie: "Continue to selfie",
		openCamera: "Use camera",
		closeCamera: "Close camera",
		couldNotRead: "No name line in that frame. The photo was discarded and not saved.",
		tryPractice: "Use a practice card",
		selfieTitle: "Live selfie",
		selfieBody: "Front camera, one face, one blink. Nothing is chosen from a gallery.",
		blinkPlease: "Look here and blink once.",
		blinkSeen: "Blink seen.",
		oneFace: "Only one face can be in the frame.",
		lookHere: "Center your face.",
		noCamera: "This preview cannot open a camera.",
		useSeal: "Continue with a preview seal",
		sealNote: "A phone install uses the front camera only. This seal exists because the preview blocked the camera.",
		capture: "Keep this selfie",
		creating: "Locking your key…",
		chats: "Chats",
		people: "People",
		calls: "Calls",
		settings: "Settings",
		search: "Search",
		online: "On the wire",
		away: "Away",
		offline: "Offline",
		weak: "Weak signal",
		typeMessage: "Message",
		send: "Send",
		queued: "Waiting on this phone",
		sent: "Sent",
		encryptedNote: "Locked with AES-256-GCM. The key stays on this phone.",
		voice: "Voice",
		photo: "Photo",
		dataSaver: "Data saver",
		dataSaverHint: "Smaller photos, short voice notes, and calls stay audio-only.",
		path: "Path",
		pathAuto: "Auto",
		pathWeak: "Weak",
		pathOffline: "Offline",
		pathHint: "Auto follows this device. Weak and offline show the queue and audio-only calls.",
		security: "Security code",
		securityBody: "Compare these groups on a call or in person. If they match, mark the contact verified.",
		verified: "Verified",
		markVerified: "Mark verified",
		verifiedDone: "You marked this code as matched.",
		share: "Share YOOYYAA",
		shareBody: "Pass the app itself: a file for Bluetooth, Nearby Share, Xender, WhatsApp, or Telegram, plus a link and a QR code.",
		downloadApk: "Download Android APK",
		copyLink: "Copy link",
		copied: "Copied",
		whatsapp: "WhatsApp",
		telegram: "Telegram",
		systemShare: "Share…",
		offlineShare: "Offline, send the APK file — not the link. Bluetooth, Nearby Share, and Xender move the file with no internet.",
		adminTitle: "Operator",
		adminBody: "The password is checked on the server, not stored in this page. Five misses lock the desk for ten minutes. A session ends after one hour.",
		password: "Password",
		unlock: "Unlock",
		locked: "Locked",
		attempts: "tries left",
		wrongPassword: "That password was refused.",
		dashboard: "Desk",
		broadcast: "Broadcast",
		adTitle: "Title",
		adText: "Text",
		adLink: "Link",
		adDays: "Days",
		publish: "Publish",
		stopAds: "Stop all notices",
		stats: "On this phone",
		messagesStored: "Messages locked here",
		queuedNow: "Waiting to send",
		peopleHere: "People",
		activeAds: "Live notices",
		suspend: "Suspend",
		unsuspend: "Restore",
		suspendedTitle: "This phone is suspended",
		suspendedBody: "The operator paused this account. Messages stay locked here, but you cannot send.",
		you: "You",
		endCall: "End call",
		audioOnly: "Audio only — the path is too thin for video.",
		calling: "Setting up an encrypted call…",
		connected: "Encrypted line",
		mute: "Mute",
		unmute: "Unmute",
		noRoute: "No live path. Messages will wait on this phone.",
		micOff: "Microphone is off. The line is still shown so you can see call setup.",
		emptyThread: "Nothing here yet. The first message locks to this phone.",
		emptySearch: "No one by that name or city.",
		emptyCalls: "No calls yet.",
		loginKey: "Login key",
		erase: "Erase this phone",
		eraseBody: "Deletes the locked chats, selfie, and key from this browser. The same ID can open a new empty phone.",
		eraseConfirm: "Erase everything here",
		cancel: "Cancel",
		back: "Back",
		weakBanner: "Weak signal. Calls stay on audio. Messages still send.",
		offlineBanner: "Offline. Messages wait here and send when a path returns.",
		resending: "Sending what was waiting…",
		call: "Call",
		message: "Message",
		recording: "Recording",
		stop: "Stop",
		adEmpty: "No live notice.",
		daysInvalid: "Choose 1 to 30 days.",
		needTitle: "A title and a text are required.",
		sessionNote: "This desk closes itself one hour after unlock.",
		verifyTitle: "Verify",
		notVerified: "Not verified",
		worldwide: "People you can reach",
		suspendedContact: "Suspended. You cannot message them.",
		cannotSend: "Sending is paused.",
		flushNote: "Waiting messages have been sent.",
		newNotice: "New notice",
		dismiss: "Dismiss",
		linkBad: "That link was ignored. Use http or https.",
		publishOk: "Notice is live on this phone.",
		stoppedAds: "Notices stopped.",
		keyCopied: "Login key copied",
		bluetooth: "Bluetooth",
		nearby: "Nearby Share",
		xender: "Xender",
		qrCaption: "Scan to open this app",
		apkHelp: "On the phone, open the APK and allow this source if Android asks.",
		dataSaverCall: "Data saver is on, so this call is audio only.",
		operator: "Operator desk",
		minutes: "min",
		thisPhone: "This phone",
		restoreYou: "Restore this phone",
		pauseYou: "Suspend this phone",
		photoFailed: "That picture could not be prepared.",
		voiceFailed: "The microphone could not start.",
		tooBig: "That voice note is too heavy for a thin path. Try a shorter one.",
		searchChats: "Search chats",
		searchPeople: "Search people or cities",
		fromOperator: "From the operator",
		openLink: "Open",
		videoOff: "Video off",
		cameraPreview: "Your camera",
		hangupSoon: "Closing the line…",
		verifiedMark: "Verified",
		awayLong: "Last seen recently",
		practicePick: "Pick a practice card",
		frameDiscarded: "Frame discarded",
		holdCard: "Hold the card in the light. Nothing is uploaded.",
		captured: "Captured",
		keepGoing: "Name is fixed",
		sealUsed: "Preview seal",
		languages: "Language",
		securityRow: "Safety check",
		shareRow: "Give someone the app",
		aboutRow: "How this phone keeps messages",
		version: "YOOYYAA 1.0",
		hidden: "Operator entry is hidden on the version line.",
		deskEmpty: "Publish a title, a text, and how many days it should stay.",
		imageOptional: "Image, optional",
		remove: "Remove",
		users: "People on this list",
		live: "Live",
		paused: "Paused",
		callSomeone: "Call someone",
		noMatch: "Nothing matches.",
		queuedCount: "queued",
		delivered: "On the wire",
		saving: "Working…",
		confirmErase: "This cannot be undone on this phone.",
		yesErase: "Yes, erase",
		selfieReady: "Selfie ready",
		blinkFirst: "Blink once before keeping the selfie.",
		facesMany: "Step back so only one face shows.",
		cameraBusy: "Starting camera…",
		pathNow: "Path now",
		autoOnline: "Auto · online",
		autoOffline: "Auto · offline",
		weakNow: "Weak signal",
		offlineNow: "Offline",
		noticeDays: "days",
		statsKey: "Key prefix",
		readAgain: "Read again",
		galleryBlocked: "Gallery is not used for your portrait."
	},
	om: {
		tagline: "Ergaa sarara laafaa irratti.",
		principleScan: "Kaardiin bilbila kana irratti dubbifama. Lakkoofsi furtuu tokko qofa ta'ee gatama.",
		principleLock: "Haasaan asitti cufama. Daddabarsi yoo jiraate iccitii qofa baachisa.",
		principleQueue: "Sararri yoo cite ergaan bilbila irratti eega, sana booda ofiin erga.",
		languageTitle: "Afaan filadhu",
		languageBody: "Afaan Oromoo, Amaariffaa, fi English. Booda jijjiiruu dandeessa.",
		continue: "Itti fufi",
		scanTitle: "Eenyummaa dubbisi",
		scanBody: "Maqaan kaardii irraa fudhatama. Barreessuun hin danda'amu, jijjiiruun hin danda'amu. Lakkoofsi eenyummaa hin kuufamu.",
		practice: "Kaardii shaakalaa",
		practiceNote: "Sanadi dhugaa miti. Maqaa kameraan malee dubbisuuf qofa.",
		fayda: "Kaardii akaakaa Faydaa",
		passport: "Paaspoortii",
		kebele: "Kaardii gandaa",
		readCard: "Kaardii kana dubbisi",
		reading: "Bilbila kana irratti dubbifamaa jira…",
		nameRead: "Maqaan dubbifame",
		nameLocked: "Cufameera. Maqaan kun hin jijjiiramu.",
		numberGone: "Lakkoofsi hash ta'ee gatameera. Bilbila kana irratti hin jiru.",
		retake: "Kaardii biraa filadhu",
		toSelfie: "Suuraa ofii itti fufi",
		openCamera: "Kaameraa fayyadami",
		closeCamera: "Kaameraa cufi",
		couldNotRead: "Sararri maqaa hin argamne. Suuraan gatamee hin kuufamne.",
		tryPractice: "Kaardii shaakalaa fayyadami",
		selfieTitle: "Suuraa ofii kallattii",
		selfieBody: "Kaameraa fuulduraa, fuulli tokko, ija tokko. Kuusaa suuraa hin fayyadamu.",
		blinkPlease: "As ilaali, ija tokko cuqi.",
		blinkSeen: "Ijaan cuqame arge.",
		oneFace: "Fuulli tokko qofa frame keessa jiraachuu qaba.",
		lookHere: "Fuula kee gidduu godhi.",
		noCamera: "Agarsiisni kun kaameraa banuu hin dandeenye.",
		useSeal: "Chaappaa agarsiisaa itti fufi",
		sealNote: "Bilbilli kaameraa fuulduraa qofa gaafata. Chaappaan kun kaameraan cufameef qofa.",
		capture: "Suuraa kana kuusi",
		creating: "Furtuu cufaa jira…",
		chats: "Haasaa",
		people: "Namoota",
		calls: "Waamicha",
		settings: "Qindaa'ina",
		search: "Barbaadi",
		online: "Sarara irra",
		away: "Fagaate",
		offline: "Sarara ala",
		weak: "Sarara laafa",
		typeMessage: "Ergaa",
		send: "Ergi",
		queued: "Bilbila kana irratti eega",
		sent: "Ergame",
		encryptedNote: "AES-256-GCM tiin cufame. Furtuun bilbila kana irratti hafa.",
		voice: "Sagalee",
		photo: "Suuraa",
		dataSaver: "Daataa qusachuu",
		dataSaverHint: "Suuraa xiqqaa, sagalee gabaabaa, waamichi sagalee qofa.",
		path: "Karaa",
		pathAuto: "Ofiin",
		pathWeak: "Laafa",
		pathOffline: "Ala",
		pathHint: "Ofiin bilbila kana hordofa. Laafaa fi ala tarree fi waamicha sagalee agarsiisu.",
		security: "Koodii nageenyaa",
		securityBody: "Garee kana waamicha yookaan walitti dhufeenya wal bira qabi. Yoo wal fakkaate mirkaneessi.",
		verified: "Mirkanaa'e",
		markVerified: "Mirkaneesse jedhi",
		verifiedDone: "Koodiin kun wal fakkaate jette.",
		share: "YOOYYAA qoodi",
		shareBody: "Appii ofii dabarsi: faayila Bluetooth, Nearby Share, Xender, WhatsApp, yookaan Telegram, hidhaa fi QR.",
		downloadApk: "APK Andirooyidii buusi",
		copyLink: "Hidhaa garagalchi",
		copied: "Garagale",
		whatsapp: "WhatsApp",
		telegram: "Telegram",
		systemShare: "Qoodi…",
		offlineShare: "Sarara ala, faayila APK ergi — hidhaa miti. Bluetooth, Nearby Share, fi Xender interneetii malee fe'u.",
		adminTitle: "Bulchaa",
		adminBody: "Jechi iccitii saarvarii irratti mirkanaa'a, fuula kana irratti hin kuufamu. Dogongorri shanan daqiiqaa kudhan cufa. Turtiin sa'aatii tokko booda xumurama.",
		password: "Jecha iccitii",
		unlock: "Bani",
		locked: "Cufame",
		attempts: "yaalii hafe",
		wrongPassword: "Jechi iccitii sun didame.",
		dashboard: "Teso",
		broadcast: "Beeksisa",
		adTitle: "Mata duree",
		adText: "Barreeffama",
		adLink: "Hidhaa",
		adDays: "Guyyoota",
		publish: "Maxxansi",
		stopAds: "Beeksisa hunda dhaabi",
		stats: "Bilbila kana irratti",
		messagesStored: "Ergaa asitti cufame",
		queuedNow: "Ergamuuf eega",
		peopleHere: "Namoota",
		activeAds: "Beeksisa jira",
		suspend: "Dhorki",
		unsuspend: "Deebisi",
		suspendedTitle: "Bilbilli kun dhorkameera",
		suspendedBody: "Bulchaan herrega kana dhaabe. Ergaan asitti cufamee hafa, garuu erguu hin dandeessu.",
		you: "Ati",
		endCall: "Waamicha xumuri",
		audioOnly: "Sagalee qofa — karaan viidiyoodhaaf laafaa dha.",
		calling: "Waamicha iccitii qopheessaa jira…",
		connected: "Sarara iccitii",
		mute: "Callisi",
		unmute: "Sagalee deebisi",
		noRoute: "Karaan jiru hin jiru. Ergaan bilbila kana irratti eega.",
		micOff: "Maayikiroofooniin cufaadha. Sararri qophii waamichaa agarsiifama.",
		emptyThread: "Hamma ammaatti hin jiru. Ergaan jalqabaa bilbila kana irratti cufama.",
		emptySearch: "Maqaa yookaan magaalatiin namni hin jiru.",
		emptyCalls: "Waamichi ammallee hin jiru.",
		loginKey: "Furtuu seensaa",
		erase: "Bilbila kana haqi",
		eraseBody: "Haasaa cufame, suuraa ofii, fi furtuu biraawzari kana keessaa balleessa. Eenyummaan tokko bilbila haaraa bana.",
		eraseConfirm: "Asii hundumaa haqi",
		cancel: "Dhiisi",
		back: "Duubatti",
		weakBanner: "Sarara laafa. Waamichi sagalee qofa. Ergaan ni ergame.",
		offlineBanner: "Sarara ala. Ergaan as eega, karaan yoo deebi'e ofiin erga.",
		resending: "Kan eegaa ture ergaa jira…",
		call: "Waamicha",
		message: "Ergaa",
		recording: "Warabuu",
		stop: "Dhaabi",
		adEmpty: "Beeksisni hin jiru.",
		daysInvalid: "Guyyaa 1 hanga 30 filadhu.",
		needTitle: "Mata duree fi barreeffamni barbaachisa.",
		sessionNote: "Tesoon kun sa'aatii tokko booda ofiin cufama.",
		verifyTitle: "Mirkaneessi",
		notVerified: "Hin mirkanoofne",
		worldwide: "Namoota qaqqabamuu danda'an",
		suspendedContact: "Dhorkameera. Erguu hin dandeessu.",
		cannotSend: "Erguun dhaabateera.",
		flushNote: "Ergaan eegaa ture ergameera.",
		newNotice: "Beeksisa haaraa",
		dismiss: "Cufi",
		linkBad: "Hidhaan sun dhiifame. http yookaan https fayyadami.",
		publishOk: "Beeksisni bilbila kana irratti jira.",
		stoppedAds: "Beeksisni dhaabate.",
		keyCopied: "Furtuun seensaa garagale",
		bluetooth: "Bluetooth",
		nearby: "Nearby Share",
		xender: "Xender",
		qrCaption: "Appii kana banuuf scan godhi",
		apkHelp: "Bilbila irratti APK bani, Andirooyidiin yoo gaafate madda kana eeyyami.",
		dataSaverCall: "Daataa qusachuun banamee, waamichi sagalee qofa.",
		operator: "Teso bulchaa",
		minutes: "daq",
		thisPhone: "Bilbila kana",
		restoreYou: "Bilbila kana deebisi",
		pauseYou: "Bilbila kana dhorki",
		photoFailed: "Suuraan sun qophaa'uu hin dandeenye.",
		voiceFailed: "Maayikiroofooniin jalqabuu hin dandeenye.",
		tooBig: "Sagaleen sun karaa laafaa irratti ulfaata. Gabaabduu yaali.",
		searchChats: "Haasaa barbaadi",
		searchPeople: "Namoota yookaan magaalota barbaadi",
		fromOperator: "Bulchaa irraa",
		openLink: "Bani",
		videoOff: "Viidiyeen cufa",
		cameraPreview: "Kaameraa kee",
		hangupSoon: "Sarara cufaa jira…",
		verifiedMark: "Mirkanaa'e",
		awayLong: "Yeroo dhiyoo mul'ate",
		practicePick: "Kaardii shaakalaa filadhu",
		frameDiscarded: "Suuraan gatame",
		holdCard: "Kaardii ifa keessa qabi. Homtuu hin ol ka'u.",
		captured: "Fuudhame",
		keepGoing: "Maqaan dhaabbate",
		sealUsed: "Chaappaa agarsiisaa",
		languages: "Afaan",
		securityRow: "Mirkaneessa nageenyaa",
		shareRow: "Namaaf appii kenni",
		aboutRow: "Bilbilli kun ergaa akkamitti kuusa",
		version: "YOOYYAA 1.0",
		hidden: "Seensii bulchaa sarara version irratti dhokate.",
		deskEmpty: "Mata duree, barreeffama, fi guyyaa meeqa turu qabu maxxansi.",
		imageOptional: "Suuraa, filannoo",
		remove: "Haqi",
		users: "Namoota tarree kana irratti",
		live: "Jira",
		paused: "Dhaabate",
		callSomeone: "Nama waami",
		noMatch: "Wanni wal fakkaatu hin jiru.",
		queuedCount: "eega",
		delivered: "Sarara irra",
		saving: "Hojjettuu jira…",
		confirmErase: "Bilbila kana irratti deebi'uu hin danda'amu.",
		yesErase: "Eeyyee, haqi",
		selfieReady: "Suuraan ofii qophaa'e",
		blinkFirst: "Suuraa kuusuu dura ija tokko cuqi.",
		facesMany: "Fuulli tokko qofa akka mul'atu duubatti ba'i.",
		cameraBusy: "Kaameraa jalqabaa jira…",
		pathNow: "Karaa amma",
		autoOnline: "Ofiin · sarara irra",
		autoOffline: "Ofiin · sarara ala",
		weakNow: "Sarara laafa",
		offlineNow: "Sarara ala",
		noticeDays: "guyyaa",
		statsKey: "Furtuu gabaabaa",
		readAgain: "Ammas dubbisi",
		galleryBlocked: "Kuusaan suuraa suuraa ofii miti."
	},
	am: {
		tagline: "ለቀጭን መስመር የተሰራ መልዕክት።",
		principleScan: "መታወቂያው በዚህ ስልክ ይነበባል። ቁጥሩ አንድ መንገድ ቁልፍ ሆኖ ይጣላል።",
		principleLock: "ውይይቶች እዚህ ይቆለፋሉ። ማስተላለፊያ ቢኖር የተመሰጠረ ጽሑፍ ብቻ ይሸከማል።",
		principleQueue: "መስመሩ ቢቋረጥ መልዕክቶች በስልኩ ይጠብቃሉ፣ ከዚያ ራሳቸውን ይልካሉ።",
		languageTitle: "ቋንቋ ይምረጡ",
		languageBody: "አማርኛ፣ Afaan Oromoo፣ እና English። በኋላ መቀየር ይችላሉ።",
		continue: "ይቀጥሉ",
		scanTitle: "መታወቂያ ያንብቡ",
		scanBody: "ስምዎ ከካርዱ ይወሰዳል። መተየብ ወይም መቀየር አይቻልም። የመታወቂያ ቁጥር አይቀመጥም።",
		practice: "የልምምድ ካርድ",
		practiceNote: "እውነተኛ ሰነድ አይደለም። ካሜራ ሳይኖር ስም ለማንበብ ብቻ።",
		fayda: "የፋይዳ አይነት ካርድ",
		passport: "ፓስፖርት",
		kebele: "የቀበሌ ካርድ",
		readCard: "ይህን ካርድ አንብብ",
		reading: "በዚህ መሣሪያ ላይ እየተነበበ ነው…",
		nameRead: "የተነበበ ስም",
		nameLocked: "ተቆልፏል። ይህ ስም አይቀየርም።",
		numberGone: "የመታወቂያ ቁጥር ሃሽ ተደርጎ ተጥሏል። በዚህ ስልክ ላይ የለም።",
		retake: "ሌላ ካርድ ይምረጡ",
		toSelfie: "ወደ ሴልፊ ይቀጥሉ",
		openCamera: "ካሜራ ተጠቀም",
		closeCamera: "ካሜራውን ዝጋ",
		couldNotRead: "በፍሬሙ ውስጥ የስም መስመር አልተገኘም። ፎቶው ተጥሎ አልተቀመጠም።",
		tryPractice: "የልምምድ ካርድ ተጠቀም",
		selfieTitle: "የቀጥታ ሴልፊ",
		selfieBody: "የፊት ካሜራ፣ አንድ ፊት፣ አንድ ብልጭታ። ከጋለሪ አይመረጥም።",
		blinkPlease: "እዚህ ይመልከቱ እና አንድ ጊዜ ብልጭ ይበሉ።",
		blinkSeen: "ብልጭታ ታይቷል።",
		oneFace: "በፍሬሙ ውስጥ አንድ ፊት ብቻ መኖር አለበት።",
		lookHere: "ፊትዎን መሃል ያድርጉ።",
		noCamera: "ይህ ቅድመ እይታ ካሜራ መክፈት አልቻለም።",
		useSeal: "በቅድመ ማህተም ይቀጥሉ",
		sealNote: "የስልክ ጭነት የፊት ካሜራ ብቻ ይጠይቃል። ማህተሙ ካሜራው ስለተዘጋ ብቻ ነው።",
		capture: "ይህን ሴልፊ ጠብቅ",
		creating: "ቁልፍዎን እየቆለፈ ነው…",
		chats: "ውይይቶች",
		people: "ሰዎች",
		calls: "ጥሪዎች",
		settings: "ቅንብሮች",
		search: "ፈልግ",
		online: "በመስመር ላይ",
		away: "ርቆ",
		offline: "ከመስመር ውጭ",
		weak: "ደካማ መስመር",
		typeMessage: "መልዕክት",
		send: "ላክ",
		queued: "በዚህ ስልክ ላይ ይጠብቃል",
		sent: "ተልኳል",
		encryptedNote: "በAES-256-GCM ተቆልፏል። ቁልፉ በዚህ ስልክ ላይ ይቆያል።",
		voice: "ድምጽ",
		photo: "ፎቶ",
		dataSaver: "ውሂብ ቆጣቢ",
		dataSaverHint: "ትናንሽ ፎቶዎች፣ አጭር ድምጽ፣ ጥሪዎች ድምጽ ብቻ።",
		path: "መንገድ",
		pathAuto: "ራስ-ሰር",
		pathWeak: "ደካማ",
		pathOffline: "ውጭ",
		pathHint: "ራስ-ሰር ይህን መሣሪያ ይከተላል። ደካማ እና ውጭ ወረፋውንና የድምጽ ጥሪ ያሳያሉ።",
		security: "የደህንነት ኮድ",
		securityBody: "እነዚህን ቡድኖች በጥሪ ወይም ፊት ለፊት ያወዳድሩ። ከተመሳሰሉ እውቂያውን ያረጋግጡ።",
		verified: "የተረጋገጠ",
		markVerified: "እንደተረጋገጠ ምልክት አድርግ",
		verifiedDone: "ይህ ኮድ እንደተመሳሰለ ምልክት አድርገዋል።",
		share: "YOOYYAA ያጋሩ",
		shareBody: "መተግበሪያውን ራሱ ያስተላልፉ፦ ፋይል ለBluetooth፣ Nearby Share፣ Xender፣ WhatsApp ወይም Telegram፣ ከሊንክ እና QR ጋር።",
		downloadApk: "የአንድሮይድ APK ያውርዱ",
		copyLink: "ሊንኩን ቅዳ",
		copied: "ተቀድቷል",
		whatsapp: "WhatsApp",
		telegram: "Telegram",
		systemShare: "አጋራ…",
		offlineShare: "ከመስመር ውጭ የAPK ፋይሉን ይላኩ — ሊንኩን አይደለም። Bluetooth፣ Nearby Share፣ እና Xender ያለ ኢንተርኔት ያንቀሳቅሳሉ።",
		adminTitle: "ኦፐሬተር",
		adminBody: "የይለፍ ቃሉ በሰርቨሩ ይረጋገጣል፣ በዚህ ገጽ አይቀመጥም። አምስት ስህተት ዴስኩን ለአስር ደቂቃ ይቆልፋል። ክፍለ ጊዜ ከአንድ ሰዓት በኋላ ያበቃል።",
		password: "የይለፍ ቃል",
		unlock: "ክፈት",
		locked: "ተቆልፏል",
		attempts: "ሙከራ ቀርቷል",
		wrongPassword: "ያ የይለፍ ቃል ተቀባይነት አላገኘም።",
		dashboard: "ዴስክ",
		broadcast: "ማስታወቂያ",
		adTitle: "ርዕስ",
		adText: "ጽሑፍ",
		adLink: "ሊንክ",
		adDays: "ቀናት",
		publish: "አውጣ",
		stopAds: "ሁሉንም ማሳወቂያ አቁም",
		stats: "በዚህ ስልክ ላይ",
		messagesStored: "እዚህ የተቆለፉ መልዕክቶች",
		queuedNow: "ለመላክ የሚጠብቁ",
		peopleHere: "ሰዎች",
		activeAds: "የቀጥታ ማሳወቂያ",
		suspend: "እገዳ",
		unsuspend: "መልስ",
		suspendedTitle: "ይህ ስልክ ታግዷል",
		suspendedBody: "ኦፐሬተሩ ይህን መለያ አቁሟል። መልዕክቶች እዚህ ተቆልፈው ይቆያሉ፣ መላክ ግን አይቻልም።",
		you: "እርስዎ",
		endCall: "ጥሪውን ጨርስ",
		audioOnly: "ድምጽ ብቻ — መንገዱ ለቪዲዮ በጣም ቀጭን ነው።",
		calling: "የተመሰጠረ ጥሪ እየተዘጋጀ ነው…",
		connected: "የተመሰጠረ መስመር",
		mute: "ድምጽ አጥፋ",
		unmute: "ድምጽ መልስ",
		noRoute: "የቀጥታ መንገድ የለም። መልዕክቶች በዚህ ስልክ ይጠብቃሉ።",
		micOff: "ማይክራፎኑ ጠፍቷል። የጥሪ ዝግጅቱ ይታያል።",
		emptyThread: "እስካሁን ምንም የለም። የመጀመሪያው መልዕክት በዚህ ስልክ ይቆለፋል።",
		emptySearch: "በዚህ ስም ወይም ከተማ ማንም የለም።",
		emptyCalls: "እስካሁን ጥሪ የለም።",
		loginKey: "የመግቢያ ቁልፍ",
		erase: "ይህን ስልክ ደምስስ",
		eraseBody: "የተቆለፉ ውይይቶችን፣ ሴልፊውን፣ እና ቁልፉን ከዚህ አሳሽ ያጠፋል። ተመሳሳይ መታወቂያ አዲስ ባዶ ስልክ ይከፍታል።",
		eraseConfirm: "እዚህ ያለውን ሁሉ ደምስስ",
		cancel: "ይቅር",
		back: "ተመለስ",
		weakBanner: "ደካማ መስመር። ጥሪዎች በድምጽ ይቆያሉ። መልዕክቶች ይላካሉ።",
		offlineBanner: "ከመስመር ውጭ። መልዕክቶች እዚህ ይጠብቃሉ፣ መንገድ ሲመለስ ይላካሉ።",
		resending: "የሚጠብቀውን እየላከ ነው…",
		call: "ጥሪ",
		message: "መልዕክት",
		recording: "እየቀረጸ ነው",
		stop: "አቁም",
		adEmpty: "የቀጥታ ማሳወቂያ የለም።",
		daysInvalid: "ከ1 እስከ 30 ቀን ይምረጡ።",
		needTitle: "ርዕስ እና ጽሑፍ ያስፈልጋሉ።",
		sessionNote: "ይህ ዴስክ ከተከፈተ አንድ ሰዓት በኋላ ራሱን ይዘጋል።",
		verifyTitle: "አረጋግጥ",
		notVerified: "አልተረጋገጠም",
		worldwide: "መድረስ የሚችሏቸው ሰዎች",
		suspendedContact: "ታግዷል። መልዕክት መላክ አይቻልም።",
		cannotSend: "መላክ ቆሟል።",
		flushNote: "የሚጠብቁ መልዕክቶች ተልከዋል።",
		newNotice: "አዲስ ማሳወቂያ",
		dismiss: "ዝጋ",
		linkBad: "ያ ሊንክ ተትቷል። http ወይም https ይጠቀሙ።",
		publishOk: "ማሳወቂያው በዚህ ስልክ ላይ ቀጥሏል።",
		stoppedAds: "ማሳወቂያዎች ቆመዋል።",
		keyCopied: "የመግቢያ ቁልፍ ተቀድቷል",
		bluetooth: "Bluetooth",
		nearby: "Nearby Share",
		xender: "Xender",
		qrCaption: "ይህን መተግበሪያ ለመክፈት ይቃኙ",
		apkHelp: "በስልኩ ላይ APK ይክፈቱ። አንድሮይድ ከጠየቀ ይህን ምንጭ ይፍቀዱ።",
		dataSaverCall: "ውሂብ ቆጣቢ በርቷል፣ ስለዚህ ይህ ጥሪ ድምጽ ብቻ ነው።",
		operator: "የኦፐሬተር ዴስክ",
		minutes: "ደቂቃ",
		thisPhone: "ይህ ስልክ",
		restoreYou: "ይህን ስልክ መልስ",
		pauseYou: "ይህን ስልክ እገዳ",
		photoFailed: "ያ ፎቶ መዘጋጀት አልቻለም።",
		voiceFailed: "ማይክራፎኑ መጀመር አልቻለም።",
		tooBig: "ያ የድምጽ መልዕክት ለቀጭን መንገድ ከባድ ነው። አጭር ይሞክሩ።",
		searchChats: "ውይይቶችን ፈልግ",
		searchPeople: "ሰዎችን ወይም ከተሞችን ፈልግ",
		fromOperator: "ከኦፐሬተሩ",
		openLink: "ክፈት",
		videoOff: "ቪዲዮ ጠፍቷል",
		cameraPreview: "ካሜራዎ",
		hangupSoon: "መስመሩን እየዘጋ ነው…",
		verifiedMark: "የተረጋገጠ",
		awayLong: "በቅርቡ ታይቷል",
		practicePick: "የልምምድ ካርድ ይምረጡ",
		frameDiscarded: "ፍሬሙ ተጥሏል",
		holdCard: "ካርዱን በብርሃን ይያዙ። ምንም አይላክም።",
		captured: "ተይዟል",
		keepGoing: "ስሙ ተስተካክሏል",
		sealUsed: "የቅድመ ማህተም",
		languages: "ቋንቋ",
		securityRow: "የደህንነት ማረጋገጫ",
		shareRow: "መተግበሪያውን ለሰው ስጥ",
		aboutRow: "ይህ ስልክ መልዕክት እንዴት እንደሚጠብቅ",
		version: "YOOYYAA 1.0",
		hidden: "የኦፐሬተር መግቢያ በስሪት መስመር ላይ ተደብቋል።",
		deskEmpty: "ርዕስ፣ ጽሑፍ፣ እና ስንት ቀን መቆየት እንዳለበት ያውጡ።",
		imageOptional: "ምስል፣ አማራጭ",
		remove: "አስወግድ",
		users: "በዚህ ዝርዝር ላይ ያሉ ሰዎች",
		live: "ቀጥታ",
		paused: "ቆሟል",
		callSomeone: "ሰው ይደውሉ",
		noMatch: "የሚመሳሰል የለም።",
		queuedCount: "በመጠባበቅ",
		delivered: "በመስመር ላይ",
		saving: "እየሰራ ነው…",
		confirmErase: "በዚህ ስልክ ላይ መመለስ አይቻልም።",
		yesErase: "አዎ፣ ደምስስ",
		selfieReady: "ሴልፊ ዝግጁ ነው",
		blinkFirst: "ሴልፊውን ከማስቀመጥዎ በፊት አንድ ጊዜ ብልጭ ይበሉ።",
		facesMany: "አንድ ፊት ብቻ እንዲታይ ወደ ኋላ ይሂዱ።",
		cameraBusy: "ካሜራ እየጀመረ ነው…",
		pathNow: "አሁን ያለው መንገድ",
		autoOnline: "ራስ-ሰር · በመስመር ላይ",
		autoOffline: "ራስ-ሰር · ከመስመር ውጭ",
		weakNow: "ደካማ መስመር",
		offlineNow: "ከመስመር ውጭ",
		noticeDays: "ቀናት",
		statsKey: "አጭር ቁልፍ",
		readAgain: "እንደገና አንብብ",
		galleryBlocked: "ለቁም ሥዕልዎ ጋለሪ አይውልም።"
	}
};
function t(lang, key) {
	return STR[lang][key] ?? STR.en[key];
}
function compressImage(file, max, quality) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const img = new Image();
		img.onload = () => {
			const scale = Math.min(1, max / Math.max(img.width, img.height, 1));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("canvas"));
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			URL.revokeObjectURL(url);
			resolve(canvas.toDataURL("image/jpeg", quality));
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("image"));
		};
		img.src = url;
	});
}
function frameToJpeg(video, max, quality) {
	const w = video.videoWidth;
	const h = video.videoHeight;
	if (!w || !h) return null;
	const scale = Math.min(1, max / Math.max(w, h));
	const canvas = document.createElement("canvas");
	canvas.width = Math.max(1, Math.round(w * scale));
	canvas.height = Math.max(1, Math.round(h * scale));
	const ctx = canvas.getContext("2d");
	if (!ctx) return null;
	ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
	return canvas.toDataURL("image/jpeg", quality);
}
function monogramSeal(name) {
	const canvas = document.createElement("canvas");
	canvas.width = 640;
	canvas.height = 640;
	const ctx = canvas.getContext("2d");
	if (!ctx) return "";
	ctx.fillStyle = "#1a2e26";
	ctx.fillRect(0, 0, 640, 640);
	ctx.strokeStyle = "#e2b657";
	ctx.lineWidth = 10;
	ctx.beginPath();
	ctx.arc(320, 300, 168, 0, Math.PI * 2);
	ctx.stroke();
	ctx.fillStyle = "#e2b657";
	ctx.font = "600 132px 'Noto Serif Ethiopic', serif";
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	const letters = name.split(/\s+/).slice(0, 2).map((p) => p[0] ?? "").join("").toUpperCase();
	ctx.fillText(letters, 320, 312);
	return canvas.toDataURL("image/jpeg", .86);
}
function safeHttp(url) {
	try {
		const parsed = new URL(url);
		if (parsed.protocol === "https:" || parsed.protocol === "http:") return parsed.href;
	} catch {
		return null;
	}
	return null;
}
function stopStream(stream) {
	stream?.getTracks().forEach((track) => track.stop());
}
function sampleLuma(video) {
	const w = video.videoWidth;
	const h = video.videoHeight;
	if (!w || !h) return null;
	const canvas = document.createElement("canvas");
	canvas.width = 32;
	canvas.height = 32;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) return null;
	const sx = w * .3;
	const sy = h * .22;
	ctx.drawImage(video, sx, sy, w * .4, h * .28, 0, 0, 32, 32);
	const data = ctx.getImageData(0, 0, 32, 32).data;
	let sum = 0;
	for (let i = 0; i < data.length; i += 4) {
		const r = data[i] ?? 0;
		const g = data[i + 1] ?? 0;
		const b = data[i + 2] ?? 0;
		sum += .2126 * r + .7152 * g + .0722 * b;
	}
	return sum / (data.length / 4);
}
var empty = {
	lang: "en",
	dataSaver: false,
	linkMode: "auto",
	account: null,
	messages: [],
	verified: [],
	suspendedContacts: [],
	ads: [],
	callLog: []
};
var useYooyyaa = create()(persist((set) => ({
	...empty,
	setLang: (lang) => set({ lang }),
	setDataSaver: (dataSaver) => set({ dataSaver }),
	setLinkMode: (linkMode) => set({ linkMode }),
	setAccount: (account, messages) => set({
		account,
		messages,
		verified: [],
		suspendedContacts: [],
		callLog: []
	}),
	setSuspendedSelf: (suspended) => set((s) => ({ account: s.account ? {
		...s.account,
		suspended
	} : s.account })),
	addMessage: (message) => set((s) => ({ messages: [...s.messages, message] })),
	markQueuedSent: () => set((s) => ({ messages: s.messages.map((m) => m.status === "queued" ? {
		...m,
		status: "sent"
	} : m) })),
	toggleVerified: (id) => set((s) => ({ verified: s.verified.includes(id) ? s.verified.filter((v) => v !== id) : [...s.verified, id] })),
	toggleSuspendedContact: (id) => set((s) => ({ suspendedContacts: s.suspendedContacts.includes(id) ? s.suspendedContacts.filter((v) => v !== id) : [...s.suspendedContacts, id] })),
	addAd: (ad) => set((s) => ({ ads: [ad, ...s.ads] })),
	stopAds: () => set((s) => ({ ads: s.ads.map((a) => ({
		...a,
		active: false
	})) })),
	addCall: (entry) => set((s) => ({ callLog: [entry, ...s.callLog].slice(0, 40) })),
	erase: () => set((s) => ({
		...empty,
		lang: s.lang,
		dataSaver: s.dataSaver
	}))
}), {
	name: "yooyyaa",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? {
		getItem: () => null,
		setItem: () => void 0,
		removeItem: () => void 0
	} : localStorage),
	partialize: (s) => ({
		lang: s.lang,
		dataSaver: s.dataSaver,
		linkMode: s.linkMode,
		account: s.account,
		messages: s.messages,
		verified: s.verified,
		suspendedContacts: s.suspendedContacts,
		ads: s.ads,
		callLog: s.callLog
	})
}));
function activeAds(ads, now = Date.now()) {
	return ads.filter((ad) => ad.active && now < ad.start + ad.days * 864e5);
}
function bytesToB64(bytes) {
	let bin = "";
	for (const b of bytes) bin += String.fromCharCode(b);
	return btoa(bin);
}
function copyBytes(bytes) {
	const copy = new ArrayBuffer(bytes.byteLength);
	new Uint8Array(copy).set(bytes);
	return copy;
}
function b64ToBytes(value) {
	const bin = atob(value);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
	return out;
}
async function sha256Hex(text) {
	const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
	return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function normalizeId(raw) {
	return raw.toUpperCase().replace(/[^A-Z0-9]/g, "");
}
async function idKey(rawNumber) {
	return sha256Hex(`yooyyaa-id|${normalizeId(rawNumber)}`);
}
async function vaultKey(idHash) {
	const raw = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`yooyyaa-vault|${idHash}`));
	return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}
async function encryptString(key, plain) {
	const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	const cipher = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv
	}, key, new TextEncoder().encode(plain));
	return {
		cipher: bytesToB64(new Uint8Array(cipher)),
		iv: bytesToB64(iv)
	};
}
async function decryptString(key, cipher, iv) {
	const buf = await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv: copyBytes(b64ToBytes(iv))
	}, key, copyBytes(b64ToBytes(cipher)));
	return new TextDecoder().decode(buf);
}
async function encryptPayload(key, payload) {
	return encryptString(key, JSON.stringify(payload));
}
async function decryptPayload(key, cipher, iv) {
	try {
		const parsed = JSON.parse(await decryptString(key, cipher, iv));
		if (!parsed || typeof parsed !== "object") return { text: "—" };
		return parsed;
	} catch {
		return { text: "—" };
	}
}
async function securityGroups(idHash, contactId) {
	const hex = (await sha256Hex(`${idHash}|${contactId}|yooyyaa-safety`)).toUpperCase();
	const groups = [];
	for (let i = 0; i < 6; i += 1) groups.push(hex.slice(i * 4, i * 4 + 4));
	return groups;
}
function shortKey(idHash) {
	return `${idHash.slice(0, 4)} ${idHash.slice(4, 8)}`.toUpperCase();
}
async function pushMessage(contactId, from, kind, payload, status, at = Date.now()) {
	const account = useYooyyaa.getState().account;
	if (!account) return;
	const packed = await encryptPayload(await vaultKey(account.idHash), payload);
	const message = {
		id: crypto.randomUUID(),
		contactId,
		from,
		kind,
		cipher: packed.cipher,
		iv: packed.iv,
		at,
		status
	};
	useYooyyaa.getState().addMessage(message);
}
async function openAccount(input) {
	const key = await vaultKey(input.idHash);
	const selfie = await encryptString(key, input.selfie);
	const now = Date.now();
	const messages = [];
	for (const seed of seedTexts(input.lang)) {
		const packed = await encryptPayload(key, { text: seed.text });
		messages.push({
			id: crypto.randomUUID(),
			contactId: seed.contactId,
			from: seed.from,
			kind: "text",
			cipher: packed.cipher,
			iv: packed.iv,
			at: now - seed.minutesAgo * 6e4,
			status: "sent"
		});
	}
	useYooyyaa.getState().setAccount({
		name: input.personName,
		idHash: input.idHash,
		selfieCipher: selfie.cipher,
		selfieIv: selfie.iv,
		createdAt: now,
		suspended: false
	}, messages);
}
async function sendPayload(contactId, kind, payload, link, lang) {
	const offline = link === "offline";
	await pushMessage(contactId, "me", kind, payload, offline ? "queued" : "sent");
	if (!offline) window.setTimeout(() => {
		pushMessage(contactId, "them", "text", { text: replyLine(lang, contactId) }, "sent");
	}, 900);
}
async function loadPlain(messages, idHash) {
	const key = await vaultKey(idHash);
	const map = {};
	for (const message of messages) map[message.id] = await decryptPayload(key, message.cipher, message.iv);
	return map;
}
async function loadSelfie(cipher, iv, idHash) {
	try {
		return await decryptString(await vaultKey(idHash), cipher, iv);
	} catch {
		return "";
	}
}
function formatWhen(at, lang) {
	const locale = lang === "am" ? "am" : "en";
	const d = new Date(at);
	if (d.toDateString() === (/* @__PURE__ */ new Date()).toDateString()) return d.toLocaleTimeString(locale, {
		hour: "2-digit",
		minute: "2-digit"
	});
	return d.toLocaleDateString(locale, {
		month: "short",
		day: "numeric"
	});
}
function clock(seconds) {
	return `${Math.floor(seconds / 60)}:${(seconds % 60).toString().padStart(2, "0")}`;
}
function previewText(kind, payload, lang) {
	if (kind === "photo") return t(lang, "photo");
	if (kind === "voice") return t(lang, "voice");
	return payload?.text ?? "…";
}
function ChatsScreen({ lang, messages, plain, go }) {
	const [q, setQ] = (0, import_react.useState)("");
	const latest = /* @__PURE__ */ new Map();
	for (const message of messages) {
		const prev = latest.get(message.contactId);
		if (!prev || message.at > prev.at) latest.set(message.contactId, message);
	}
	const rows = [...latest.values()].sort((a, b) => b.at - a.at).filter((message) => {
		const person = personById(message.contactId);
		return `${person?.name ?? ""} ${person?.city ?? ""} ${previewText(message.kind, plain[message.id], lang)}`.toLowerCase().includes(q.trim().toLowerCase());
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: t(lang, "chats")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-4 flex min-h-11 items-center gap-2 rounded-xl border border-line bg-surface px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t(lang, "searchChats"),
				className: "w-full bg-transparent text-sm text-fg outline-none placeholder:text-muted"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y divide-line",
			children: rows.map((message) => {
				const person = personById(message.contactId);
				if (!person) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-3 py-3 text-left",
					onClick: () => go({
						name: "thread",
						id: person.id
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: person.name,
						online: person.online
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-baseline justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate font-semibold",
								children: person.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-xs text-muted tabular-nums",
								children: formatWhen(message.at, lang)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 flex items-center gap-1 text-sm text-muted",
							children: [message.status === "queued" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: previewText(message.kind, plain[message.id], lang)
							})]
						})]
					})]
				}) }, message.contactId);
			})
		}),
		rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-muted",
			children: t(lang, "emptySearch")
		}) : null
	] });
}
function ThreadScreen({ lang, contactId, link, dataSaver, messages, plain, suspended, verified, go, toast }) {
	const person = personById(contactId);
	const [text, setText] = (0, import_react.useState)("");
	const [recording, setRecording] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	const recRef = (0, import_react.useRef)(null);
	const chunks = (0, import_react.useRef)([]);
	const streamRef = (0, import_react.useRef)(null);
	const scroller = (0, import_react.useRef)(null);
	const sending = (0, import_react.useRef)(false);
	const mine = messages.filter((m) => m.contactId === contactId);
	const blocked = suspended || busy;
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
	}, [mine.length]);
	(0, import_react.useEffect)(() => () => stopStream(streamRef.current), []);
	if (!person) return null;
	async function sendText() {
		const value = text.trim();
		if (!value || blocked || sending.current) return;
		sending.current = true;
		setText("");
		setBusy(true);
		await sendPayload(contactId, "text", { text: value }, link, lang);
		setBusy(false);
		sending.current = false;
	}
	async function onPhoto(file) {
		try {
			await sendPayload(contactId, "photo", { dataUrl: await compressImage(file, dataSaver ? 480 : 960, dataSaver ? .45 : .62) }, link, lang);
		} catch {
			toast(t(lang, "photoFailed"));
		}
	}
	async function toggleVoice() {
		if (recording) {
			recRef.current?.stop();
			setRecording(false);
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			streamRef.current = stream;
			chunks.current = [];
			const rec = new MediaRecorder(stream, { audioBitsPerSecond: dataSaver ? 8e3 : 2e4 });
			recRef.current = rec;
			rec.ondataavailable = (ev) => {
				if (ev.data.size) chunks.current.push(ev.data);
			};
			rec.onstop = () => {
				const blob = new Blob(chunks.current, { type: rec.mimeType || "audio/webm" });
				stopStream(stream);
				streamRef.current = null;
				if (blob.size > 28e4) {
					toast(t(lang, "tooBig"));
					return;
				}
				const reader = new FileReader();
				reader.onload = () => {
					const dataUrl = typeof reader.result === "string" ? reader.result : "";
					if (dataUrl) sendPayload(contactId, "voice", { dataUrl }, link, lang);
				};
				reader.readAsDataURL(blob);
			};
			rec.start();
			setRecording(true);
			window.setTimeout(() => {
				if (rec.state === "recording") rec.stop();
				setRecording(false);
			}, 8e3);
		} catch {
			toast(t(lang, "voiceFailed"));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3 border-b border-line px-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 px-1 text-sm text-muted",
						onClick: () => go({ name: "chats" }),
						children: t(lang, "back")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: person.name,
						online: person.online
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-semibold",
							children: person.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: person.online ? t(lang, "online") : t(lang, "away")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center text-gold",
						"aria-label": t(lang, "security"),
						onClick: () => go({
							name: "verify",
							id: person.id
						}),
						children: verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs",
							children: t(lang, "verifyTitle")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						"aria-label": t(lang, "call"),
						onClick: () => {
							if (link === "offline") toast(t(lang, "noRoute"));
							else go({
								name: "live",
								id: person.id
							});
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: "min-h-0 flex-1 space-y-2 overflow-y-auto px-3 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-center text-xs text-pretty text-muted",
						children: t(lang, "encryptedNote")
					}),
					mine.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t(lang, "emptyThread")
					}) : null,
					mine.map((message) => {
						const payload = plain[message.id];
						const mineBubble = message.from === "me";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `flex ${mineBubble ? "justify-end" : "justify-start"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `max-w-xs rounded-2xl px-3 py-2 text-sm ${mineBubble ? "rounded-br-md bg-gold text-ink" : "rounded-bl-md bg-surface-2 text-fg"}`,
								children: [
									message.kind === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "break-words text-pretty",
										children: payload?.text
									}) : null,
									message.kind === "photo" && payload?.dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: payload.dataUrl,
										alt: t(lang, "photo"),
										className: "max-h-56 rounded-xl object-cover"
									}) : null,
									message.kind === "voice" && payload?.dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
										controls: true,
										src: payload.dataUrl,
										className: "w-48"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: `mt-1 flex items-center justify-end gap-1 text-xs tabular-nums ${mineBubble ? "text-ink" : "text-muted"}`,
										children: [
											formatWhen(message.at, lang),
											mineBubble && message.status === "queued" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "queued") }) : null,
											mineBubble ? message.status === "queued" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : null
										]
									})
								]
							})
						}, message.id);
					})
				]
			}),
			suspended ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-2 text-sm text-muted",
				children: t(lang, "suspendedContact")
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex items-end gap-2 border-t border-line px-3 py-2",
				onSubmit: (e) => {
					e.preventDefault();
					sendText();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "image/*",
						capture: "environment",
						className: "hidden",
						onChange: (e) => {
							const file = e.target.files?.[0];
							e.target.value = "";
							if (file) onPhoto(file);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center text-muted",
						"aria-label": t(lang, "photo"),
						disabled: blocked,
						onClick: () => fileRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `grid size-11 place-items-center ${recording ? "text-gold" : "text-muted"}`,
						"aria-label": t(lang, "voice"),
						disabled: blocked,
						onClick: () => void toggleVoice(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 1,
						value: text,
						disabled: blocked,
						placeholder: recording ? t(lang, "recording") : t(lang, "typeMessage"),
						className: `${fieldCls} max-h-24 resize-none py-3`,
						onChange: (e) => setText(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter" && !e.shiftKey) {
								e.preventDefault();
								sendText();
							}
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "grid size-11 shrink-0 place-items-center rounded-xl bg-gold text-ink disabled:opacity-50",
						"aria-label": t(lang, "send"),
						disabled: blocked || !text.trim(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
					})
				]
			})
		]
	});
}
function PeopleScreen({ lang, verified, suspendedContacts, link, go, toast }) {
	const [q, setQ] = (0, import_react.useState)("");
	const rows = PEOPLE.filter((p) => `${p.name} ${p.city}`.toLowerCase().includes(q.trim().toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: t(lang, "people")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: t(lang, "worldwide")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-4 flex min-h-11 items-center gap-2 rounded-xl border border-line bg-surface px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t(lang, "searchPeople"),
				className: "w-full bg-transparent text-sm outline-none placeholder:text-muted"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-line",
			children: rows.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: person.name,
						online: person.online
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate font-semibold",
							children: [
								person.name,
								" ",
								verified.includes(person.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "inline size-4 text-gold" }) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs text-muted",
							children: [
								person.city,
								" · ",
								person.online ? t(lang, "online") : t(lang, "away"),
								suspendedContacts.includes(person.id) ? ` · ${t(lang, "paused")}` : ""
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 px-2 text-sm text-gold",
						onClick: () => go({
							name: "thread",
							id: person.id
						}),
						children: t(lang, "message")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						"aria-label": t(lang, "call"),
						onClick: () => {
							if (link === "offline") toast(t(lang, "noRoute"));
							else go({
								name: "live",
								id: person.id
							});
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" })
					})
				]
			}, person.id))
		}),
		rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: t(lang, "noMatch")
		}) : null
	] });
}
function CallsScreen({ lang, callLog, link, go, toast }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: t(lang, "calls")
		}),
		callLog.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: t(lang, "emptyCalls")
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-line",
			children: callLog.map((entry) => {
				const person = personById(entry.contactId);
				if (!person) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-3 py-3 text-left",
					onClick: () => {
						if (link === "offline") toast(t(lang, "noRoute"));
						else go({
							name: "live",
							id: person.id
						});
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							name: person.name,
							online: person.online
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-semibold",
								children: person.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted",
								children: [
									entry.audioOnly ? t(lang, "audioOnly") : t(lang, "call"),
									" · ",
									formatWhen(entry.at, lang)
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 text-gold" })
					]
				}) }, entry.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-8 text-sm font-semibold text-muted",
			children: t(lang, "callSomeone")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2",
			children: PEOPLE.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex min-h-11 w-full items-center justify-between text-left text-sm",
				onClick: () => {
					if (link === "offline") toast(t(lang, "noRoute"));
					else go({
						name: "live",
						id: person.id
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: person.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: person.city
				})]
			}) }, person.id))
		})
	] });
}
function LiveCall({ lang, contactId, link, dataSaver, go }) {
	const person = personById(contactId);
	const audioOnly = link !== "online" || dataSaver;
	const [phase, setPhase] = (0, import_react.useState)("setup");
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [seconds, setSeconds] = (0, import_react.useState)(0);
	const [mic, setMic] = (0, import_react.useState)("unknown");
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let dead = false;
		const wait = window.setTimeout(() => setPhase("live"), 900);
		const constraints = audioOnly ? {
			audio: true,
			video: false
		} : {
			audio: true,
			video: { facingMode: "user" }
		};
		navigator.mediaDevices?.getUserMedia(constraints).then((stream) => {
			if (dead) {
				stopStream(stream);
				return;
			}
			streamRef.current = stream;
			setMic("on");
			if (videoRef.current && stream.getVideoTracks().length) {
				videoRef.current.srcObject = stream;
				videoRef.current.play().catch(() => void 0);
			}
		}).catch(() => {
			if (!dead) setMic("off");
		});
		return () => {
			dead = true;
			window.clearTimeout(wait);
			stopStream(streamRef.current);
		};
	}, [audioOnly]);
	(0, import_react.useEffect)(() => {
		if (phase !== "live") return;
		const id = window.setInterval(() => setSeconds((s) => s + 1), 1e3);
		return () => window.clearInterval(id);
	}, [phase]);
	(0, import_react.useEffect)(() => {
		streamRef.current?.getAudioTracks().forEach((track) => {
			track.enabled = !muted;
		});
	}, [muted]);
	if (!person) return null;
	const bars = audioOnly ? 1 : 4;
	function hangup() {
		stopStream(streamRef.current);
		useYooyyaa.getState().addCall({
			id: crypto.randomUUID(),
			contactId,
			at: Date.now(),
			video: !audioOnly,
			audioOnly
		});
		go({ name: "calls" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col px-5 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-gold uppercase",
				children: t(lang, "encryptedNote")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center justify-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: person.name }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-3xl text-balance",
						children: person.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: phase === "live" ? t(lang, "connected") : t(lang, "calling")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-2xl tabular-nums",
						children: clock(seconds)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex items-end gap-1",
						"aria-hidden": "true",
						children: [
							"h-2",
							"h-3",
							"h-4",
							"h-6"
						].map((height, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-1.5 rounded-sm ${height} ${i < bars ? "bg-gold" : "bg-line"}` }, height))
					}),
					audioOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 max-w-xs text-sm text-pretty text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoOff, { className: "mr-1 inline size-4" }), dataSaver ? t(lang, "dataSaverCall") : t(lang, "audioOnly")]
					}) : null,
					mic === "off" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xs text-sm text-muted",
						children: t(lang, "micOff")
					}) : null
				]
			}),
			!audioOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				className: "mb-4 ml-auto aspect-square w-28 rounded-xl bg-ink object-cover",
				playsInline: true,
				muted: true
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				className: "hidden",
				playsInline: true,
				muted: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: ghostBtn,
					onClick: () => setMuted((v) => !v),
					children: muted ? t(lang, "unmute") : t(lang, "mute")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: goldBtn,
					onClick: hangup,
					children: t(lang, "endCall")
				})]
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function passwordField(input) {
	if (!input || typeof input !== "object" || !("password" in input)) throw new Error("invalid");
	const password = input.password;
	if (typeof password !== "string" || password.length < 1 || password.length > 200) throw new Error("invalid");
	return password;
}
function tokenField(input) {
	if (!input || typeof input !== "object" || !("token" in input)) throw new Error("invalid");
	const value = input.token;
	if (typeof value !== "string" || value.length < 16 || value.length > 200) throw new Error("invalid");
	return value;
}
var adminLogin = createServerFn({ method: "POST" }).validator((input) => ({ password: passwordField(input) })).handler(createSsrRpc("000d385d830f5d5b96c837e7c7a8e8a7e0fd34937fdaaf440ed137665146fadf"));
var adminCheck = createServerFn({ method: "POST" }).validator((input) => ({ token: tokenField(input) })).handler(createSsrRpc("26f64bc26b0ebda10e78df52bdee5b0f9122b8e4857462585dd8b69dbafe77e9"));
var ADMIN_TOKEN = "yooyyaa-admin";
function versionTaps(go) {
	let taps = 0;
	let at = 0;
	return () => {
		const now = Date.now();
		if (now - at > 2500) taps = 0;
		at = now;
		taps += 1;
		if (taps >= 7) {
			taps = 0;
			go({ name: "admin" });
		}
	};
}
function SettingsScreen({ lang, account, selfie, go, toast }) {
	const dataSaver = useYooyyaa((s) => s.dataSaver);
	const linkMode = useYooyyaa((s) => s.linkMode);
	const setLang = useYooyyaa((s) => s.setLang);
	const setDataSaver = useYooyyaa((s) => s.setDataSaver);
	const setLinkMode = useYooyyaa((s) => s.setLinkMode);
	const [askErase, setAskErase] = (0, import_react.useState)(false);
	const onVersion = (0, import_react.useRef)(versionTaps(go)).current;
	if (!account) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: t(lang, "settings")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-16 place-items-center overflow-hidden rounded-full bg-surface-2 text-lg font-semibold text-gold",
				children: selfie ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: selfie,
					alt: "",
					className: "size-full object-cover"
				}) : account.name.slice(0, 1)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: account.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: t(lang, "nameLocked")
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-xs font-semibold tracking-wide text-gold uppercase",
			children: t(lang, "languages")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid gap-2",
			children: [
				{
					id: "om",
					label: "Afaan Oromoo"
				},
				{
					id: "am",
					label: "አማርኛ"
				},
				{
					id: "en",
					label: "English"
				}
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": lang === item.id,
				className: `min-h-11 rounded-xl border px-3 text-left text-sm ${lang === item.id ? "border-gold" : "border-line"}`,
				onClick: () => setLang(item.id),
				children: item.label
			}, item.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-xs font-semibold tracking-wide text-gold uppercase",
			children: t(lang, "path")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-pretty text-muted",
			children: t(lang, "pathHint")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid grid-cols-3 gap-2",
			children: [
				{
					id: "auto",
					label: "pathAuto"
				},
				{
					id: "weak",
					label: "pathWeak"
				},
				{
					id: "offline",
					label: "pathOffline"
				}
			].map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": linkMode === mode.id,
				className: `min-h-11 rounded-xl border text-sm ${linkMode === mode.id ? "border-gold text-gold" : "border-line"}`,
				onClick: () => setLinkMode(mode.id),
				children: t(lang, mode.label)
			}, mode.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-pressed": dataSaver,
			className: "mt-4 flex min-h-11 w-full items-center justify-between rounded-xl border border-line px-3 text-left",
			onClick: () => setDataSaver(!dataSaver),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm font-semibold",
				children: t(lang, "dataSaver")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted",
				children: t(lang, "dataSaverHint")
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `rounded-full px-2 py-1 text-xs ${dataSaver ? "bg-gold text-ink" : "bg-surface-2 text-muted"}`,
				children: dataSaver ? t(lang, "live") : t(lang, "paused")
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-xl border border-line p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: t(lang, "loginKey")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-semibold tabular-nums",
					children: shortKey(account.idHash)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${ghostBtn} mt-3`,
					onClick: () => {
						navigator.clipboard?.writeText(account.idHash).then(() => toast(t(lang, "keyCopied"))).catch(() => void 0);
					},
					children: t(lang, "copyLink")
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: `${ghostBtn} mt-3 w-full`,
			onClick: () => go({ name: "share" }),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), t(lang, "shareRow")]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 text-sm leading-6 text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(lang, "principleScan") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: t(lang, "principleLock")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: t(lang, "principleQueue")
				})
			]
		}),
		askErase ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-xl border border-line p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-pretty",
					children: t(lang, "eraseBody")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: t(lang, "confirmErase")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: ghostBtn,
						onClick: () => setAskErase(false),
						children: t(lang, "cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: goldBtn,
						onClick: () => {
							useYooyyaa.getState().erase();
							sessionStorage.removeItem(ADMIN_TOKEN);
						},
						children: t(lang, "yesErase")
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: `${ghostBtn} mt-6 w-full`,
			onClick: () => setAskErase(true),
			children: t(lang, "erase")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-8 min-h-11 text-xs text-muted",
			onClick: onVersion,
			children: t(lang, "version")
		})
	] });
}
function ShareScreen({ lang, go, toast }) {
	const [svg, setSvg] = (0, import_react.useState)("");
	const url = typeof window === "undefined" ? "" : `${window.location.origin}${window.location.pathname}`;
	const blurb = `YOOYYAA — ${url}`;
	(0, import_react.useEffect)(() => {
		let dead = false;
		import_lib.toString(url || "https://yooyyaa.app", {
			type: "svg",
			margin: 1,
			color: {
				dark: "#10211b",
				light: "#f3ecdf"
			}
		}).then((value) => {
			if (!dead) setSvg(value);
		}).catch(() => void 0);
		return () => {
			dead = true;
		};
	}, [url]);
	async function shareSystem() {
		if (navigator.share) try {
			await navigator.share({
				title: "YOOYYAA",
				text: blurb,
				url
			});
			return;
		} catch {
			return;
		}
		toast(t(lang, "copyLink"));
		await navigator.clipboard?.writeText(blurb);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-3 min-h-11 text-sm text-muted",
			onClick: () => go({ name: "settings" }),
			children: t(lang, "back")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl text-balance",
			children: t(lang, "share")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-pretty text-muted",
			children: t(lang, "shareBody")
		}),
		svg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 rounded-2xl bg-fg p-4",
			dangerouslySetInnerHTML: { __html: svg }
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-center text-xs text-muted",
			children: t(lang, "qrCaption")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: goldBtn,
					href: "/downloads/YOOYYAA.apk",
					download: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), t(lang, "downloadApk")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: ghostBtn,
					onClick: () => void navigator.clipboard?.writeText(url).then(() => toast(t(lang, "copied"))),
					children: t(lang, "copyLink")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: ghostBtn,
					href: `https://wa.me/?text=${encodeURIComponent(blurb)}`,
					target: "_blank",
					rel: "noreferrer",
					children: t(lang, "whatsapp")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: ghostBtn,
					href: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent("YOOYYAA")}`,
					target: "_blank",
					rel: "noreferrer",
					children: t(lang, "telegram")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: ghostBtn,
					onClick: () => void shareSystem(),
					children: t(lang, "systemShare")
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 rounded-xl border border-line p-3 text-sm text-pretty text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(lang, "offlineShare") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2",
					children: [
						t(lang, "bluetooth"),
						" · ",
						t(lang, "nearby"),
						" · ",
						t(lang, "xender")
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: t(lang, "apkHelp")
				})
			]
		})
	] });
}
function VerifyScreen({ lang, contactId, idHash, verified, go }) {
	const person = personById(contactId);
	const [groups, setGroups] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!idHash) return;
		let dead = false;
		securityGroups(idHash, contactId).then((value) => {
			if (!dead) setGroups(value);
		});
		return () => {
			dead = true;
		};
	}, [idHash, contactId]);
	if (!person) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-3 min-h-11 text-sm text-muted",
			onClick: () => go({
				name: "thread",
				id: contactId
			}),
			children: t(lang, "back")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: t(lang, "security")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-pretty text-muted",
			children: person.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-pretty text-muted",
			children: t(lang, "securityBody")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 grid grid-cols-3 gap-2",
			children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-surface-2 py-3 text-center font-semibold tabular-nums tracking-wide",
				children: group
			}, group))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm",
			children: verified ? t(lang, "verifiedDone") : t(lang, "notVerified")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: `${goldBtn} mt-4 w-full`,
			onClick: () => useYooyyaa.getState().toggleVerified(contactId),
			children: verified ? t(lang, "verified") : t(lang, "markVerified")
		})
	] });
}
function SuspendedScreen({ lang, go }) {
	const onVersion = (0, import_react.useRef)(versionTaps(go)).current;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl text-balance",
			children: t(lang, "suspendedTitle")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-pretty text-muted",
			children: t(lang, "suspendedBody")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-16 min-h-11 text-xs text-muted",
			onClick: onVersion,
			children: t(lang, "version")
		})
	] });
}
function AdminScreen({ lang, go, toast }) {
	const account = useYooyyaa((s) => s.account);
	const messages = useYooyyaa((s) => s.messages);
	const ads = useYooyyaa((s) => s.ads);
	const suspendedContacts = useYooyyaa((s) => s.suspendedContacts);
	const [password, setPassword] = (0, import_react.useState)("");
	const [token, setToken] = (0, import_react.useState)(null);
	const [expires, setExpires] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [title, setTitle] = (0, import_react.useState)("");
	const [text, setText] = (0, import_react.useState)("");
	const [link, setLink] = (0, import_react.useState)("");
	const [days, setDays] = (0, import_react.useState)("7");
	const [image, setImage] = (0, import_react.useState)();
	const fileRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const saved = sessionStorage.getItem(ADMIN_TOKEN);
		if (!saved) return;
		let dead = false;
		adminCheck({ data: { token: saved } }).then((res) => {
			if (dead) return;
			if (res.ok) {
				setToken(saved);
				setExpires(res.expiresAt);
			} else sessionStorage.removeItem(ADMIN_TOKEN);
		}).catch(() => void 0);
		return () => {
			dead = true;
		};
	}, []);
	async function unlock() {
		setBusy(true);
		setError(null);
		try {
			const res = await adminLogin({ data: { password } });
			if (res.ok) {
				sessionStorage.setItem(ADMIN_TOKEN, res.token);
				setToken(res.token);
				setExpires(res.expiresAt);
				setPassword("");
			} else if (res.lockedForMs > 0) {
				const mins = Math.max(1, Math.ceil(res.lockedForMs / 6e4));
				setError(`${t(lang, "locked")} · ${mins} ${t(lang, "minutes")}`);
			} else setError(`${t(lang, "wrongPassword")} · ${res.attemptsLeft} ${t(lang, "attempts")}`);
		} catch {
			setError(t(lang, "wrongPassword"));
		}
		setBusy(false);
	}
	async function authorized() {
		if (!token) return false;
		if (!(await adminCheck({ data: { token } })).ok) {
			sessionStorage.removeItem(ADMIN_TOKEN);
			setToken(null);
			toast(t(lang, "sessionNote"));
			return false;
		}
		return true;
	}
	const queued = messages.filter((m) => m.status === "queued").length;
	const live = activeAds(ads);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-3 min-h-11 text-sm text-muted",
			onClick: () => go(account?.suspended ? { name: "suspended" } : { name: "settings" }),
			children: t(lang, "back")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: t(lang, "operator")
		}),
		!token ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4",
			onSubmit: (e) => {
				e.preventDefault();
				unlock();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-pretty text-muted",
					children: t(lang, "adminBody")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-4 block text-xs text-muted",
					htmlFor: "operator-pass",
					children: t(lang, "password")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "operator-pass",
					type: "password",
					autoComplete: "off",
					value: password,
					onChange: (e) => setPassword(e.target.value),
					className: `${fieldCls} mt-1`
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-gold",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: `${goldBtn} mt-4 w-full`,
					disabled: busy || !password,
					children: busy ? t(lang, "saving") : t(lang, "unlock")
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						t(lang, "sessionNote"),
						" · ",
						new Date(expires).toLocaleTimeString(lang === "am" ? "am" : "en", {
							hour: "2-digit",
							minute: "2-digit"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-6 font-display text-xl",
					children: t(lang, "broadcast")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: t(lang, "adTitle"),
					className: `${fieldCls} mt-3`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: t(lang, "adText"),
					rows: 3,
					className: `${fieldCls} mt-2 py-3`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: link,
					onChange: (e) => setLink(e.target.value),
					placeholder: t(lang, "adLink"),
					className: `${fieldCls} mt-2`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-2 block text-xs text-muted",
					htmlFor: "ad-days",
					children: t(lang, "adDays")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "ad-days",
					inputMode: "numeric",
					value: days,
					onChange: (e) => setDays(e.target.value),
					className: `${fieldCls} mt-1`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: fileRef,
					type: "file",
					accept: "image/*",
					className: "hidden",
					onChange: (e) => {
						const file = e.target.files?.[0];
						e.target.value = "";
						if (!file) return;
						compressImage(file, 640, .6).then(setImage).catch(() => toast(t(lang, "photoFailed")));
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${ghostBtn} mt-2`,
					onClick: () => fileRef.current?.click(),
					children: t(lang, "imageOptional")
				}),
				image ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: image,
						alt: "",
						className: "max-h-32 rounded-xl object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-1 min-h-11 text-sm text-muted",
						onClick: () => setImage(void 0),
						children: t(lang, "remove")
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${goldBtn} mt-3 w-full`,
					onClick: () => {
						(async () => {
							if (!await authorized()) return;
							const span = Number(days);
							if (!title.trim() || !text.trim()) {
								toast(t(lang, "needTitle"));
								return;
							}
							if (!Number.isInteger(span) || span < 1 || span > 30) {
								toast(t(lang, "daysInvalid"));
								return;
							}
							let href;
							if (link.trim()) {
								const safe = safeHttp(link.trim());
								if (!safe) {
									toast(t(lang, "linkBad"));
									return;
								}
								href = safe;
							}
							useYooyyaa.getState().addAd({
								id: crypto.randomUUID(),
								title: title.trim(),
								text: text.trim(),
								link: href,
								image,
								days: span,
								start: Date.now(),
								active: true
							});
							setTitle("");
							setText("");
							setLink("");
							setImage(void 0);
							toast(t(lang, "publishOk"));
						})();
					},
					children: t(lang, "publish")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${ghostBtn} mt-2 w-full`,
					onClick: () => {
						(async () => {
							if (!await authorized()) return;
							useYooyyaa.getState().stopAds();
							toast(t(lang, "stoppedAds"));
						})();
					},
					children: t(lang, "stopAds")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-8 font-display text-xl",
					children: t(lang, "stats")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-3 grid grid-cols-2 gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: t(lang, "messagesStored"),
							value: String(messages.length)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: t(lang, "queuedNow"),
							value: String(queued)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: t(lang, "peopleHere"),
							value: String(PEOPLE.length)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: t(lang, "activeAds"),
							value: String(live.length)
						})
					]
				}),
				live.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: t(lang, "adEmpty")
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-8 font-display text-xl",
					children: t(lang, "users")
				}),
				account ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-between gap-2 border-b border-line py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: account.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							t(lang, "thisPhone"),
							" · ",
							shortKey(account.idHash)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: ghostBtn,
						onClick: () => void authorized().then((ok) => ok && useYooyyaa.getState().setSuspendedSelf(!account.suspended)),
						children: account.suspended ? t(lang, "restoreYou") : t(lang, "pauseYou")
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: PEOPLE.map((person) => {
					const paused = suspendedContacts.includes(person.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-2 border-b border-line py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: person.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: person.city
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: ghostBtn,
							onClick: () => void authorized().then((ok) => ok && useYooyyaa.getState().toggleSuspendedContact(person.id)),
							children: paused ? t(lang, "unsuspend") : t(lang, "suspend")
						})]
					}, person.id);
				}) })
			]
		})
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-display text-2xl tabular-nums",
			children: value
		})]
	});
}
function Mark({ className = "size-12" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "7",
				className: "fill-bg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "0.8",
				y: "0.8",
				width: "30.4",
				height: "30.4",
				rx: "6.4",
				className: "fill-none stroke-gold",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12.2 6.4C5.2 11 5.2 21 12.2 25.6",
				fill: "none",
				className: "stroke-gold",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M19.8 6.4C26.8 11 26.8 21 19.8 25.6",
				fill: "none",
				className: "stroke-gold",
				strokeWidth: "2.4",
				strokeLinecap: "round"
			})
		]
	});
}
var CARDS = [
	{
		id: "fayda",
		kind: "fayda",
		personName: "Tigist Alemu",
		number: "FYD-2048-7715"
	},
	{
		id: "passport",
		kind: "passport",
		personName: "Gemechu Bekele",
		number: "EP8841203"
	},
	{
		id: "kebele",
		kind: "kebele",
		personName: "Chaltu Daba",
		number: "KB-OR-11842"
	}
];
function startView(account) {
	if (!account) return { name: "lang" };
	if (account.suspended) return { name: "suspended" };
	return { name: "chats" };
}
function Shell() {
	const lang = useYooyyaa((s) => s.lang);
	const account = useYooyyaa((s) => s.account);
	const messages = useYooyyaa((s) => s.messages);
	const dataSaver = useYooyyaa((s) => s.dataSaver);
	const linkMode = useYooyyaa((s) => s.linkMode);
	const ads = useYooyyaa((s) => s.ads);
	const verified = useYooyyaa((s) => s.verified);
	const suspendedContacts = useYooyyaa((s) => s.suspendedContacts);
	const callLog = useYooyyaa((s) => s.callLog);
	const [view, setView] = (0, import_react.useState)(() => startView(useYooyyaa.getState().account));
	const [online, setOnline] = (0, import_react.useState)(true);
	const [plain, setPlain] = (0, import_react.useState)({});
	const [selfie, setSelfie] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)(null);
	const [flushing, setFlushing] = (0, import_react.useState)(false);
	const seenAds = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const primed = (0, import_react.useRef)(false);
	const link = !online || linkMode === "offline" ? "offline" : linkMode === "weak" ? "weak" : "online";
	const liveAds = activeAds(ads);
	const banner = liveAds[0];
	(0, import_react.useEffect)(() => {
		const sync = () => setOnline(navigator.onLine);
		sync();
		window.addEventListener("online", sync);
		window.addEventListener("offline", sync);
		return () => {
			window.removeEventListener("online", sync);
			window.removeEventListener("offline", sync);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang === "am" ? "am" : lang === "om" ? "om" : "en";
	}, [lang]);
	(0, import_react.useEffect)(() => {
		if (!account) {
			setPlain({});
			setSelfie("");
			return;
		}
		let dead = false;
		(async () => {
			const map = await loadPlain(messages, account.idHash);
			const face = await loadSelfie(account.selfieCipher, account.selfieIv, account.idHash);
			if (!dead) {
				setPlain(map);
				setSelfie(face);
			}
		})();
		return () => {
			dead = true;
		};
	}, [account, messages]);
	(0, import_react.useEffect)(() => {
		if (!account && view.name !== "lang" && view.name !== "scan" && view.name !== "selfie") setView({ name: "lang" });
	}, [account, view.name]);
	(0, import_react.useEffect)(() => {
		if (account?.suspended && view.name !== "admin" && view.name !== "suspended") setView({ name: "suspended" });
	}, [account, view.name]);
	(0, import_react.useEffect)(() => {
		if (link === "offline") return;
		if (!messages.some((m) => m.status === "queued")) return;
		setFlushing(true);
		const id = window.setTimeout(() => {
			useYooyyaa.getState().markQueuedSent();
			setFlushing(false);
			setNote(t(lang, "flushNote"));
		}, 800);
		return () => window.clearTimeout(id);
	}, [
		link,
		messages,
		lang
	]);
	(0, import_react.useEffect)(() => {
		if (!primed.current) {
			liveAds.forEach((ad) => seenAds.current.add(ad.id));
			primed.current = true;
			return;
		}
		for (const ad of liveAds) if (!seenAds.current.has(ad.id)) {
			seenAds.current.add(ad.id);
			setNote(t(lang, "newNotice"));
		}
	}, [liveAds, lang]);
	const showNav = !!account && !account.suspended && (view.name === "chats" || view.name === "people" || view.name === "calls" || view.name === "settings");
	const pathLabel = link === "offline" ? t(lang, "offlineNow") : link === "weak" ? t(lang, "weakNow") : t(lang, "autoOnline");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-bg text-fg lg:flex lg:h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden h-dvh flex-1 flex-col justify-between overflow-y-auto border-r border-line px-12 py-12 lg:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-14" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-8 font-display text-5xl text-balance",
						children: "YOOYYAA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-sm text-lg text-pretty text-muted",
						children: t(lang, "tagline")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-10 space-y-5 text-sm leading-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-5 text-gold" }),
								text: t(lang, "principleScan")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5 text-gold" }),
								text: t(lang, "principleLock")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signal, { className: "size-5 text-gold" }),
								text: t(lang, "principleQueue")
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					t(lang, "pathNow"),
					": ",
					pathLabel
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto flex h-dvh w-full max-w-lg flex-col lg:mx-0 lg:w-96 lg:max-w-none lg:shrink-0",
			children: [
				banner && showNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdBanner, {
					ad: banner,
					lang
				}) : null,
				link === "offline" && showNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Strip, { children: t(lang, "offlineBanner") }) : null,
				link === "weak" && showNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Strip, { children: t(lang, "weakBanner") }) : null,
				flushing && showNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Strip, { children: t(lang, "resending") }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 overflow-hidden",
					children: [
						view.name === "lang" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageScreen, { go: setView }) : null,
						view.name === "scan" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanScreen, {
							lang,
							go: setView
						}) : null,
						view.name === "selfie" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelfieScreen, {
							lang,
							personName: view.personName,
							idHash: view.idHash,
							go: setView
						}) : null,
						view.name === "chats" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatsScreen, {
							lang,
							messages,
							plain,
							go: setView
						}) : null,
						view.name === "thread" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadScreen, {
							lang,
							contactId: view.id,
							link,
							dataSaver,
							messages,
							plain,
							suspended: suspendedContacts.includes(view.id),
							verified: verified.includes(view.id),
							go: setView,
							toast: setNote
						}) : null,
						view.name === "people" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PeopleScreen, {
							lang,
							verified,
							suspendedContacts,
							link,
							go: setView,
							toast: setNote
						}) : null,
						view.name === "calls" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallsScreen, {
							lang,
							callLog,
							link,
							go: setView,
							toast: setNote
						}) : null,
						view.name === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveCall, {
							lang,
							contactId: view.id,
							link,
							dataSaver,
							go: setView
						}) : null,
						view.name === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {
							lang,
							account,
							selfie,
							go: setView,
							toast: setNote
						}) : null,
						view.name === "share" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareScreen, {
							lang,
							go: setView,
							toast: setNote
						}) : null,
						view.name === "verify" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifyScreen, {
							lang,
							contactId: view.id,
							idHash: account?.idHash ?? "",
							verified: verified.includes(view.id),
							go: setView
						}) : null,
						view.name === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminScreen, {
							lang,
							go: setView,
							toast: setNote
						}) : null,
						view.name === "suspended" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuspendedScreen, {
							lang,
							go: setView
						}) : null
					]
				}),
				showNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBar, {
					lang,
					view: view.name,
					go: setView
				}) : null,
				note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-x-4 bottom-24 z-20 mx-auto max-w-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex min-h-11 w-full items-center justify-between gap-3 rounded-xl border border-line bg-surface px-4 text-left text-sm",
						onClick: () => setNote(null),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: note }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: t(lang, "dismiss")
						})]
					})
				}) : null
			]
		})]
	});
}
function Rail({ icon, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 shrink-0",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-pretty",
			children: text
		})]
	});
}
function Strip({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "border-b border-line bg-surface px-4 py-2 text-xs text-muted",
		children
	});
}
function AdBanner({ ad, lang }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-line bg-surface px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-wide text-gold uppercase",
				children: t(lang, "fromOperator")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-lg text-balance",
				children: ad.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: ad.text
			}),
			ad.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: ad.image,
				alt: "",
				className: "mt-3 max-h-36 w-full rounded-xl object-cover"
			}) : null,
			ad.link ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-gold",
				href: ad.link,
				target: "_blank",
				rel: "noreferrer",
				children: t(lang, "openLink")
			}) : null
		]
	});
}
function TabBar({ lang, view, go }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "grid grid-cols-4 border-t border-line bg-bg",
		children: [
			{
				name: "chats",
				label: "chats",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" })
			},
			{
				name: "people",
				label: "people",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
			},
			{
				name: "calls",
				label: "calls",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
			},
			{
				name: "settings",
				label: "settings",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
			}
		].map((item) => {
			const on = view === item.name;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-current": on ? "page" : void 0,
				className: `flex min-h-16 flex-col items-center justify-center gap-1 text-xs ${on ? "text-gold" : "text-muted"}`,
				onClick: () => go({ name: item.name }),
				children: [item.icon, t(lang, item.label)]
			}, item.name);
		})
	});
}
function LanguageScreen({ go }) {
	const lang = useYooyyaa((s) => s.lang);
	const setLang = useYooyyaa((s) => s.setLang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col justify-center overflow-y-auto px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-12" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 font-display text-4xl",
						children: "YOOYYAA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty text-muted",
						children: t(lang, "tagline")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 font-display text-2xl text-balance lg:mt-2",
				children: t(lang, "languageTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-pretty text-muted",
				children: t(lang, "languageBody")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid gap-2",
				children: [
					{
						id: "om",
						label: "Afaan Oromoo"
					},
					{
						id: "am",
						label: "አማርኛ"
					},
					{
						id: "en",
						label: "English"
					}
				].map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": lang === opt.id,
					className: `min-h-12 rounded-xl border px-4 text-left text-base ${lang === opt.id ? "border-gold bg-surface" : "border-line"}`,
					onClick: () => setLang(opt.id),
					children: opt.label
				}, opt.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${goldBtn} mt-6 w-full`,
				onClick: () => go({ name: "scan" }),
				children: t(lang, "continue")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-8 space-y-3 text-sm text-muted lg:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t(lang, "principleScan") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t(lang, "principleLock") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t(lang, "principleQueue") })
				]
			})
		]
	});
}
function ScanScreen({ lang, go }) {
	const [cardId, setCardId] = (0, import_react.useState)(CARDS[0]?.id ?? "fayda");
	const [phase, setPhase] = (0, import_react.useState)("pick");
	const [read, setRead] = (0, import_react.useState)(null);
	const [camOn, setCamOn] = (0, import_react.useState)(false);
	const [camNote, setCamNote] = (0, import_react.useState)(null);
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const card = CARDS.find((c) => c.id === cardId) ?? CARDS[0];
	(0, import_react.useEffect)(() => () => stopStream(streamRef.current), []);
	async function readCard() {
		if (!card) return;
		setPhase("reading");
		setCamNote(null);
		const hash = await idKey(card.number);
		window.setTimeout(() => {
			setRead({
				personName: card.personName,
				idHash: hash
			});
			setPhase("done");
		}, 1100);
	}
	async function openCam() {
		setCamNote(null);
		try {
			const stream = await navigator.mediaDevices.getUserMedia({
				video: { facingMode: "environment" },
				audio: false
			});
			streamRef.current = stream;
			setCamOn(true);
			window.setTimeout(() => {
				if (videoRef.current) {
					videoRef.current.srcObject = stream;
					videoRef.current.play().catch(() => void 0);
				}
			}, 0);
		} catch {
			setCamNote(t(lang, "noCamera"));
		}
	}
	function closeCam() {
		stopStream(streamRef.current);
		streamRef.current = null;
		setCamOn(false);
	}
	function shoot() {
		const video = videoRef.current;
		if (!video) return;
		frameToJpeg(video, 640, .5);
		closeCam();
		setCamNote(t(lang, "couldNotRead"));
	}
	if (!card) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl text-balance",
			children: t(lang, "scanTitle")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-pretty text-muted",
			children: t(lang, "scanBody")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mt-5 overflow-hidden rounded-2xl border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-gold uppercase",
					children: t(lang, "practice")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted",
					children: t(lang, card.kind)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-2xl text-balance",
					children: phase === "done" && read ? read.personName : card.personName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted",
					children: phase === "done" ? t(lang, "numberGone") : t(lang, "practiceNote")
				}),
				phase === "reading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan-line mt-4 h-0.5 w-full bg-gold" }) : null
			]
		}),
		phase !== "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2",
				children: CARDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": item.id === card.id,
					className: `min-h-11 rounded-xl border px-3 text-left text-sm ${item.id === card.id ? "border-gold" : "border-line"}`,
					onClick: () => setCardId(item.id),
					children: t(lang, item.kind)
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${goldBtn} mt-4 w-full`,
				disabled: phase === "reading",
				onClick: () => void readCard(),
				children: phase === "reading" ? t(lang, "reading") : t(lang, "readCard")
			}),
			camOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: videoRef,
						className: "aspect-video w-full rounded-xl bg-ink object-cover",
						playsInline: true,
						muted: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: t(lang, "holdCard")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: goldBtn,
							onClick: shoot,
							children: t(lang, "captured")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: ghostBtn,
							onClick: closeCam,
							children: t(lang, "closeCamera")
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${ghostBtn} mt-2 w-full`,
				onClick: () => void openCam(),
				children: t(lang, "openCamera")
			}),
			camNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: camNote
			}) : null
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-gold uppercase",
					children: t(lang, "nameRead")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-3xl",
					children: read?.personName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 flex items-center gap-2 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 text-gold" }), t(lang, "nameLocked")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${goldBtn} mt-5 w-full`,
					onClick: () => {
						if (read) go({
							name: "selfie",
							personName: read.personName,
							idHash: read.idHash
						});
					},
					children: t(lang, "toSelfie")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${ghostBtn} mt-2 w-full`,
					onClick: () => {
						setPhase("pick");
						setRead(null);
					},
					children: t(lang, "retake")
				})
			]
		})
	] });
}
function SelfieScreen({ lang, personName, idHash, go }) {
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const [status, setStatus] = (0, import_react.useState)("starting");
	const [blink, setBlink] = (0, import_react.useState)(false);
	const [faces, setFaces] = (0, import_react.useState)(null);
	const [shot, setShot] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const baseline = (0, import_react.useRef)(0);
	const dropped = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		let dead = false;
		let timer = 0;
		navigator.mediaDevices?.getUserMedia({
			video: { facingMode: "user" },
			audio: false
		}).then((stream) => {
			if (dead) {
				stopStream(stream);
				return;
			}
			streamRef.current = stream;
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
				videoRef.current.play().catch(() => void 0);
			}
			setStatus("ready");
			const Detector = window.FaceDetector;
			const detector = Detector ? new Detector({
				fastMode: true,
				maxDetectedFaces: 2
			}) : null;
			timer = window.setInterval(() => {
				const video = videoRef.current;
				if (!video || video.readyState < 2) return;
				const luma = sampleLuma(video);
				if (luma !== null) {
					if (!baseline.current) baseline.current = luma;
					baseline.current = baseline.current * .92 + luma * .08;
					if (luma < baseline.current - 12 && !dropped.current) dropped.current = performance.now();
					if (dropped.current && luma > baseline.current - 5 && performance.now() - dropped.current > 50 && performance.now() - dropped.current < 450) {
						setBlink(true);
						dropped.current = 0;
					} else if (dropped.current && performance.now() - dropped.current > 500) dropped.current = 0;
				}
				if (detector) detector.detect(video).then((found) => {
					if (!dead) setFaces(found.length);
				}).catch(() => void 0);
			}, 140);
		}).catch(() => {
			if (!dead) setStatus("blocked");
		});
		return () => {
			dead = true;
			window.clearInterval(timer);
			stopStream(streamRef.current);
		};
	}, []);
	async function keep(image) {
		setBusy(true);
		await openAccount({
			idHash,
			personName,
			selfie: image,
			lang
		});
		stopStream(streamRef.current);
		go({ name: "chats" });
	}
	const many = faces !== null && faces > 1;
	const none = faces === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenScroll, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl text-balance",
			children: t(lang, "selfieTitle")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-pretty text-muted",
			children: t(lang, "selfieBody")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 font-display text-xl",
			children: personName
		}),
		status === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				className: "mt-4 aspect-square w-full rounded-2xl bg-ink object-cover",
				playsInline: true,
				muted: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: many ? t(lang, "oneFace") : none ? t(lang, "lookHere") : blink ? t(lang, "blinkSeen") : t(lang, "blinkPlease")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${goldBtn} mt-4 w-full`,
				disabled: !blink || many || busy,
				onClick: () => {
					const image = videoRef.current ? frameToJpeg(videoRef.current, 720, .72) : null;
					if (image) keep(image);
				},
				children: busy ? t(lang, "creating") : t(lang, "capture")
			})
		] }) : null,
		status === "starting" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-muted",
			children: t(lang, "cameraBusy")
		}) : null,
		status === "blocked" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: t(lang, "noCamera")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-pretty text-muted",
					children: t(lang, "sealNote")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${goldBtn} mt-4 w-full`,
					disabled: busy,
					onClick: () => void keep(monogramSeal(personName)),
					children: busy ? t(lang, "creating") : t(lang, "useSeal")
				})
			]
		}) : null
	] });
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const pending = useYooyyaa.persist.rehydrate();
		Promise.resolve(pending).finally(() => setReady(true));
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-bg px-6 text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-16" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl tracking-wide",
				children: "YOOYYAA"
			})]
		})
	});
}
//#endregion
export { Home as component };
