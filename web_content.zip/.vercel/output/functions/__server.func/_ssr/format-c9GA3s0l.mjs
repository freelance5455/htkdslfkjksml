import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-c9GA3s0l.js
var format_c9GA3s0l_exports = /* @__PURE__ */ __exportAll({
	a: () => PARTY_LABELS,
	c: () => formatJalaliLong,
	d: () => format_exports,
	f: () => jalaliYearOf,
	g: () => uid,
	h: () => todayIso,
	i: () => OP_LABELS,
	l: () => formatRial,
	m: () => parseFaNumber,
	n: () => GROUP_LABELS,
	o: () => fiscalBounds,
	p: () => padSeq,
	r: () => OP_GROUPS,
	s: () => formatJalali,
	t: () => CHECK_STATUS,
	u: () => formatRialCompact
});
var format_exports = /* @__PURE__ */ __exportAll$1({
	CHECK_STATUS: () => CHECK_STATUS,
	GROUP_LABELS: () => GROUP_LABELS,
	OP_GROUPS: () => OP_GROUPS,
	OP_LABELS: () => OP_LABELS,
	PARTY_LABELS: () => PARTY_LABELS,
	fiscalBounds: () => fiscalBounds,
	formatJalali: () => formatJalali,
	formatJalaliLong: () => formatJalaliLong,
	formatRial: () => formatRial,
	formatRialCompact: () => formatRialCompact,
	gregorianToJalali: () => gregorianToJalali,
	isoToJalali: () => isoToJalali,
	jalaliToGregorian: () => jalaliToGregorian,
	jalaliYearOf: () => jalaliYearOf,
	padSeq: () => padSeq,
	parseFaNumber: () => parseFaNumber,
	toFaDigits: () => toFaDigits,
	todayIso: () => todayIso,
	uid: () => uid
});
var GDM = [
	0,
	31,
	59,
	90,
	120,
	151,
	181,
	212,
	243,
	273,
	304,
	334
];
var J_MONTHS = [
	"فروردین",
	"اردیبهشت",
	"خرداد",
	"تیر",
	"مرداد",
	"شهریور",
	"مهر",
	"آبان",
	"آذر",
	"دی",
	"بهمن",
	"اسفند"
];
var J_WEEKDAYS = [
	"یکشنبه",
	"دوشنبه",
	"سه‌شنبه",
	"چهارشنبه",
	"پنجشنبه",
	"جمعه",
	"شنبه"
];
function gregorianToJalali(gy, gm, gd) {
	const gy2 = gm > 2 ? gy + 1 : gy;
	let days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + GDM[gm - 1];
	let jy = -1595 + 33 * Math.floor(days / 12053);
	days %= 12053;
	jy += 4 * Math.floor(days / 1461);
	days %= 1461;
	if (days > 365) {
		jy += Math.floor((days - 1) / 365);
		days = (days - 1) % 365;
	}
	const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
	const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
	return {
		jy,
		jm,
		jd
	};
}
function jalaliToGregorian(jy, jm, jd) {
	jy += 1595;
	let days = -355668 + 365 * jy + Math.floor(jy / 33) * 8 + Math.floor((jy % 33 + 3) / 4) + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
	let gy = 400 * Math.floor(days / 146097);
	days %= 146097;
	if (days > 36524) {
		gy += 100 * Math.floor(--days / 36524);
		days %= 36524;
		if (days >= 365) days += 1;
	}
	gy += 4 * Math.floor(days / 1461);
	days %= 1461;
	if (days > 365) {
		gy += Math.floor((days - 1) / 365);
		days = (days - 1) % 365;
	}
	const gd = days + 1;
	const sal_a = [
		0,
		31,
		gy % 4 === 0 && gy % 100 !== 0 || gy % 400 === 0 ? 29 : 28,
		31,
		30,
		31,
		30,
		31,
		31,
		30,
		31,
		30,
		31
	];
	let gm = 0;
	let v = gd;
	for (gm = 1; gm <= 12 && v > sal_a[gm]; gm += 1) v -= sal_a[gm];
	return {
		gy,
		gm,
		gd: v
	};
}
function isoToJalali(iso) {
	const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
	return gregorianToJalali(y, m, d);
}
function todayIso() {
	const n = /* @__PURE__ */ new Date();
	const z = (v) => String(v).padStart(2, "0");
	return `${n.getFullYear()}-${z(n.getMonth() + 1)}-${z(n.getDate())}`;
}
function formatJalali(iso, withWeekday = false) {
	if (!iso) return "—";
	const { jy, jm, jd } = isoToJalali(iso);
	const base = `${toFaDigits(jy)}/${toFaDigits(String(jm).padStart(2, "0"))}/${toFaDigits(String(jd).padStart(2, "0"))}`;
	if (!withWeekday) return base;
	return `${J_WEEKDAYS[(/* @__PURE__ */ new Date(`${iso.slice(0, 10)}T12:00:00`)).getDay()]} ${base}`;
}
function formatJalaliLong(iso) {
	const { jy, jm, jd } = isoToJalali(iso);
	return `${J_WEEKDAYS[(/* @__PURE__ */ new Date(`${iso.slice(0, 10)}T12:00:00`)).getDay()]} ${toFaDigits(jd)} ${J_MONTHS[jm - 1]} ${toFaDigits(jy)}`;
}
function jalaliYearOf(iso) {
	return isoToJalali(iso).jy;
}
function fiscalBounds(jy) {
	const start = jalaliToGregorian(jy, 1, 1);
	const end = jalaliToGregorian(jy, 12, 29);
	const z = (v) => String(v).padStart(2, "0");
	return {
		start: `${start.gy}-${z(start.gm)}-${z(start.gd)}`,
		end: `${end.gy}-${z(end.gm)}-${z(end.gd)}`
	};
}
function toFaDigits(v) {
	return String(v).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
}
function parseFaNumber(raw) {
	const normalized = raw.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d))).replace(/[,،_\s]/g, "");
	const n = Number(normalized);
	return Number.isFinite(n) ? n : 0;
}
function formatRial(n, fa = true) {
	const abs = Math.round(Number(n) || 0);
	const formatted = new Intl.NumberFormat("en-US").format(abs);
	return fa ? `${toFaDigits(formatted)} ریال` : `${formatted} IRR`;
}
function formatRialCompact(n) {
	const v = Math.round(Number(n) || 0);
	const sign = v < 0 ? "−" : "";
	const a = Math.abs(v);
	if (a >= 0xe8d4a51000) return `${sign}${toFaDigits((a / 0xe8d4a51000).toFixed(2))} هزار میلیارد`;
	if (a >= 1e9) return `${sign}${toFaDigits((a / 1e9).toFixed(2))} میلیارد`;
	if (a >= 1e6) return `${sign}${toFaDigits((a / 1e6).toFixed(1))} میلیون`;
	return formatRial(v);
}
var OP_LABELS = {
	receipt: "دریافت از مشتری",
	receipt_other: "دریافت خارج از فاکتور",
	payment: "پرداخت به تأمین‌کننده",
	payment_other: "پرداخت خارج از فاکتور",
	transfer: "انتقال بین منابع",
	sale_cash: "فروش نقدی / بانکی",
	sale_credit: "فروش نسیه",
	sale_mixed: "فروش ترکیبی",
	sale_return: "برگشت از فروش",
	purchase_cash: "خرید نقدی / بانکی",
	purchase_credit: "خرید نسیه",
	purchase_return: "برگشت از خرید",
	sale_discount: "تخفیف فروش",
	purchase_discount: "تخفیف خرید",
	expense_cash: "هزینه نقدی",
	expense_payable: "هزینه پرداختنی",
	income: "درآمد",
	check_receive: "دریافت چک",
	check_pay: "پرداخت چک",
	check_collect: "وصول چک",
	check_return: "برگشت چک",
	capital_in: "واریز سرمایه",
	draw: "برداشت مالک",
	petty_fund: "تخصیص تنخواه",
	petty_settle: "تسویه تنخواه",
	prepay: "پیش‌پرداخت",
	advance: "پیش‌دریافت",
	payroll: "حقوق و دستمزد",
	manual: "سند دستی",
	adjustment: "سند اصلاحی",
	reversal: "سند برگشتی",
	opening: "سند افتتاحیه",
	closing: "سند اختتامیه"
};
var OP_GROUPS = [
	{
		title: "دریافت و پرداخت",
		types: [
			"receipt",
			"receipt_other",
			"payment",
			"payment_other",
			"transfer"
		]
	},
	{
		title: "فروش و خرید",
		types: [
			"sale_cash",
			"sale_credit",
			"sale_mixed",
			"sale_return",
			"purchase_cash",
			"purchase_credit",
			"purchase_return"
		]
	},
	{
		title: "هزینه و درآمد",
		types: [
			"expense_cash",
			"expense_payable",
			"income",
			"sale_discount",
			"purchase_discount"
		]
	},
	{
		title: "چک و تنخواه",
		types: [
			"check_receive",
			"check_pay",
			"check_collect",
			"check_return",
			"petty_fund",
			"petty_settle"
		]
	},
	{
		title: "سرمایه و سایر",
		types: [
			"capital_in",
			"draw",
			"prepay",
			"advance",
			"payroll",
			"manual",
			"adjustment"
		]
	}
];
var PARTY_LABELS = {
	customer: "مشتری",
	supplier: "تأمین‌کننده",
	employee: "کارمند",
	shareholder: "شریک / سهامدار",
	bank: "بانک",
	government: "دولتی",
	other: "سایر"
};
var GROUP_LABELS = {
	asset: "دارایی‌ها",
	liability: "بدهی‌ها",
	equity: "سرمایه",
	income: "درآمدها",
	cogs: "بهای تمام‌شده",
	expense: "هزینه‌ها",
	contra: "حساب‌های کاهنده",
	control: "حساب‌های کنترلی"
};
var CHECK_STATUS = {
	in_hand: "نزد صندوق",
	deposited: "واگذار به بانک",
	collected: "وصول‌شده",
	returned: "برگشتی",
	issued: "صادرشده",
	paid: "پرداخت‌شده"
};
function uid() {
	return crypto.randomUUID();
}
function padSeq(n) {
	return String(n).padStart(6, "0");
}
//#endregion
export { PARTY_LABELS as a, formatJalaliLong as c, format_c9GA3s0l_exports as d, jalaliYearOf as f, uid as g, todayIso as h, OP_LABELS as i, formatRial as l, parseFaNumber as m, GROUP_LABELS as n, fiscalBounds as o, padSeq as p, OP_GROUPS as r, formatJalali as s, CHECK_STATUS as t, formatRialCompact as u };
