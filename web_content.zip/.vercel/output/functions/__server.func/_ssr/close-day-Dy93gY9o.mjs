import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as useHealth, c as requestReopenDay, g as useDashboard, n as closeDay, v as useInvalidateBooks } from "./use-books-BtZpLk9U.mjs";
import { c as formatJalaliLong, h as todayIso } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, n as Card } from "./card-Bb_-PO54.mjs";
import { t as Button } from "./button-BiViDDnZ.mjs";
import { n as Input } from "./input-CAg20-g-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as downloadJson } from "./export-tWZA3qLh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/close-day-Dy93gY9o.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CloseDayPage() {
	const dash = useDashboard();
	const health = useHealth();
	const invalidate = useInvalidateBooks();
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [ack, setAck] = (0, import_react.useState)(false);
	const [phrase, setPhrase] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function close() {
		if (!ack) {
			toast.error("تأیید الزامی است.");
			return;
		}
		setBusy(true);
		try {
			const res = await closeDay({ data: {
				date,
				confirm: true
			} });
			toast.success(`روز بسته شد. پشتیبان ${res.backupName}`);
			downloadJson(res.backupName, res.package);
			invalidate();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "خطا");
		} finally {
			setBusy(false);
		}
	}
	async function reopen() {
		try {
			await requestReopenDay({ data: {
				date,
				phrase
			} });
			toast.success("روز با ثبت در حسابرسی بازگشایی شد.");
			invalidate();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "خطا");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "بستن روز",
		description: "پس از بستن، ویرایش مستقیم ممنوع است. اصلاح فقط با سند برگشتی / اصلاحی."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-navy",
				children: "کنترل‌های پایان روز"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 space-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["اسناد نامتوازن: ", health.data?.unbalanced ?? "—"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["عملیات امروز: ", health.data?.opsToday ?? "—"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["وضعیت امروز: ", dash.data?.todayStatus === "closed" ? "بسته" : "باز"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["تاریخ انتخابی: ", formatJalaliLong(date)] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-5 block text-xs text-muted",
				children: ["تاریخ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					className: "mt-1",
					value: date,
					onChange: (e) => setDate(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 flex items-start gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: ack,
					onChange: (e) => setAck(e.target.checked),
					className: "mt-1"
				}), "پس از بستن روز، اطلاعات این روز قابل ویرایش مستقیم نخواهد بود."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-5 w-full",
				variant: "gold",
				disabled: busy,
				onClick: close,
				children: "بستن روز و تولید بسته روزانه"
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-navy",
				children: "درخواست اصلاح روز بسته‌شده"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "بازگشایی عادی مجاز نیست. برای موارد استثنا، عبارت «بازگشایی» را وارد کنید. تمام این فرآیند در Audit Log ثبت می‌شود."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "mt-4",
				value: phrase,
				onChange: (e) => setPhrase(e.target.value),
				placeholder: "بازگشایی"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "outline",
				onClick: reopen,
				children: "ثبت درخواست و بازگشایی"
			})
		] })]
	})] });
}
//#endregion
export { CloseDayPage as component };
