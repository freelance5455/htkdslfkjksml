import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BackButton } from "./back-button-DImimZOp.mjs";
import { r as TopBar, t as AppShell } from "./app-shell-C4IrQdCN.mjs";
import { n as CATEGORY_LABEL, o as libraryBooks } from "./catalog-CjAfWU9w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-DXGNdjX7.js
var import_jsx_runtime = require_jsx_runtime();
var ORDER = [
	"hadith",
	"aqeedah",
	"fiqh",
	"tajweed"
];
function LibraryHome() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: "المكتبة الشرعية",
			back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-5 pt-3 text-xs leading-5 text-muted-foreground",
			children: "المتون المعروضة نُقلت من مصادر مطبوعة أو من ويكي مصدر / السُّنة، ولم يُولَّد شيء منها. ما لم يُراجع نصه بعد يظهر للطبعة القادمة."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-6 px-4 py-4",
			children: ORDER.map((cat) => {
				const books = libraryBooks.filter((b) => b.category === cat);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-sm font-semibold text-muted-foreground",
					children: CATEGORY_LABEL[cat]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: books.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: b.comingSoon ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-card px-4 py-3.5 opacity-70 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: b.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [b.author, " · يُضاف بعد مراجعة النص"]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/library/$bookId",
						params: { bookId: b.id },
						className: "block rounded-2xl bg-card px-4 py-3.5 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: b.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								b.author,
								" · ",
								b.blurb
							]
						})]
					}) }, b.id))
				})] }, cat);
			})
		})
	] });
}
//#endregion
export { LibraryHome as component };
