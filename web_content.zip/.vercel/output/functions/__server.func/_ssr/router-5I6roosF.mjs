import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as Slot, P as require_jsx_runtime, d as DialogContent$1, f as DialogDescription$1, h as DialogTitle$1, l as Dialog$1, m as DialogPortal$1, p as DialogOverlay$1, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { C as Link2, M as Download, N as Compass, O as FolderPlus, T as House, a as TriangleAlert, i as Upload, k as FolderOpen, l as Settings, m as Play, p as Plus, t as X } from "../_libs/lucide-react.mjs";
import { a as Root2, i as Portal2, n as Item2, o as Separator2, r as Label2, s as Trigger, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as Root$1, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
import { n as Portal, r as Provider, t as Content2$1 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/idb-DtuedZZ6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatDuration(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "—";
	const s = Math.floor(seconds);
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const sec = s % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
	return `${m}:${String(sec).padStart(2, "0")}`;
}
function formatBytes(bytes) {
	if (!Number.isFinite(bytes) || bytes < 0) return "—";
	if (bytes < 1024) return `${bytes} B`;
	const units = [
		"KB",
		"MB",
		"GB",
		"TB"
	];
	let value = bytes / 1024;
	let unit = 0;
	while (value >= 1024 && unit < units.length - 1) {
		value /= 1024;
		unit += 1;
	}
	return `${value < 10 ? value.toFixed(1) : Math.round(value)} ${units[unit]}`;
}
function formatClock(date) {
	try {
		return new Intl.DateTimeFormat(void 0, {
			dateStyle: "medium",
			timeStyle: "short"
		}).format(new Date(date));
	} catch {
		return "—";
	}
}
function slugId() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function extensionOf(name) {
	const i = name.lastIndexOf(".");
	return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}
function basename(path) {
	const parts = path.replace(/\\/g, "/").split("/").filter(Boolean);
	return parts[parts.length - 1] ?? path;
}
function parentFolder(path) {
	const parts = path.replace(/\\/g, "/").split("/").filter(Boolean);
	if (parts.length <= 1) return "Root";
	return parts[parts.length - 2] ?? "Root";
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[transform,background-color,color,opacity,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			ghost: "text-fg hover:bg-secondary",
			outline: "bg-transparent shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			destructive: "bg-destructive text-destructive-fg hover:bg-destructive/90",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-md px-3 text-xs",
			lg: "h-12 px-5 text-base",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var APP_NAME$1 = "UPLAY.IND";
var APP_VERSION = "1.0.0";
var APP_TAGLINE = "Offline-first cinema and music, on your terms.";
var LIBRARY_DB = "uplay-ind";
var VIDEO_EXTS = /* @__PURE__ */ new Set([
	"mp4",
	"webm",
	"ogg",
	"ogv",
	"mov",
	"m4v",
	"mkv",
	"avi",
	"3gp",
	"m3u8"
]);
var AUDIO_EXTS = /* @__PURE__ */ new Set([
	"mp3",
	"wav",
	"ogg",
	"oga",
	"m4a",
	"aac",
	"flac",
	"opus",
	"weba"
]);
var MEDIA_ACCEPT = "video/*,audio/*,.mp4,.webm,.ogg,.ogv,.mov,.m4v,.mkv,.avi,.mp3,.wav,.m4a,.aac,.flac,.opus,.srt,.vtt";
var SPEED_PRESETS = [
	.25,
	.5,
	.75,
	1,
	1.25,
	1.5,
	1.75,
	2
];
var EQ_FREQUENCIES = [
	32,
	64,
	125,
	250,
	500,
	1e3,
	2e3,
	4e3,
	8e3,
	16e3
];
/**
* Public-domain / openly licensed demonstration streams.
* Used only for optional network-playback trials — never as a fake local library.
*/
var PUBLIC_STREAMS = [
	{
		id: "bbb",
		name: "Big Buck Bunny",
		url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
		kind: "video",
		note: "Blender Foundation · open movie"
	},
	{
		id: "sintel",
		name: "Sintel",
		url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
		kind: "video",
		note: "Blender Foundation · open movie"
	},
	{
		id: "elephants",
		name: "Elephants Dream",
		url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
		kind: "video",
		note: "Blender Foundation · open movie"
	}
];
var SEARCH_ENGINES = {
	ddg: {
		label: "DuckDuckGo",
		url: "https://duckduckgo.com/?q="
	},
	google: {
		label: "Google",
		url: "https://www.google.com/search?q="
	},
	bing: {
		label: "Bing",
		url: "https://www.bing.com/search?q="
	}
};
var DEFAULT_HOMEPAGE = "https://duckduckgo.com";
var MIME_BY_EXT = {
	mp4: "video/mp4",
	m4v: "video/mp4",
	webm: "video/webm",
	ogv: "video/ogg",
	ogg: "video/ogg",
	mov: "video/quicktime",
	mkv: "video/x-matroska",
	avi: "video/x-msvideo",
	"3gp": "video/3gpp",
	m3u8: "application/vnd.apple.mpegurl",
	mp3: "audio/mpeg",
	wav: "audio/wav",
	m4a: "audio/mp4",
	aac: "audio/aac",
	flac: "audio/flac",
	opus: "audio/ogg",
	oga: "audio/ogg",
	weba: "audio/webm",
	srt: "application/x-subrip",
	vtt: "text/vtt"
};
var HARD_NO = /* @__PURE__ */ new Set([
	"mkv",
	"avi",
	"3gp"
]);
function sniffKind(name, mime = "") {
	const ext = extensionOf(name);
	if (ext === "srt" || ext === "vtt") return "subtitle";
	if (mime.startsWith("video/") || VIDEO_EXTS.has(ext)) return "video";
	if (mime.startsWith("audio/") || AUDIO_EXTS.has(ext)) return "audio";
	return "unknown";
}
function mimeFor(name, mime = "") {
	if (mime && mime !== "application/octet-stream") return mime;
	return MIME_BY_EXT[extensionOf(name)] ?? mime ?? "application/octet-stream";
}
/**
* Ask the actual browser whether it can decode this type.
* Never claims hardware/software decoder modes the web platform cannot select.
*/
function probePlayback(name, mime = "") {
	const ext = extensionOf(name);
	const kind = sniffKind(name, mime);
	const resolved = mimeFor(name, mime);
	if (kind === "subtitle") return {
		kind,
		mime: resolved,
		playable: true,
		canPlay: "probably"
	};
	if (kind === "unknown") return {
		kind,
		mime: resolved,
		playable: false,
		canPlay: "",
		reason: "This file is not a recognised audio or video type."
	};
	if (typeof document === "undefined") return {
		kind,
		mime: resolved,
		playable: true,
		canPlay: "maybe"
	};
	const el = document.createElement(kind === "audio" ? "audio" : "video");
	let canPlay = "";
	try {
		canPlay = el.canPlayType(resolved) || "";
		if (!canPlay && resolved.includes("/")) {
			const generic = `${kind}/${ext === "mp4" || ext === "m4v" || ext === "m4a" ? "mp4" : ext}`;
			canPlay = el.canPlayType(generic) || "";
		}
	} catch {
		canPlay = "";
	}
	if (ext === "m3u8") {
		const hlsNative = canPlay === "probably" || canPlay === "maybe";
		return {
			kind,
			mime: resolved,
			playable: hlsNative,
			canPlay,
			reason: hlsNative ? void 0 : "HLS (.m3u8) is not decoded by this browser. Use an MP4 or WebM URL, or Safari."
		};
	}
	if (HARD_NO.has(ext) && !canPlay) return {
		kind,
		mime: resolved,
		playable: false,
		canPlay,
		reason: `${ext.toUpperCase()} is not decoded by this browser. Convert to MP4 or WebM for playback.`
	};
	if (!canPlay && HARD_NO.has(ext)) return {
		kind,
		mime: resolved,
		playable: false,
		canPlay,
		reason: `${ext.toUpperCase()} is not decoded by this browser. Convert to MP4 or WebM for playback.`
	};
	const playable = canPlay === "probably" || canPlay === "maybe" || !HARD_NO.has(ext) && (ext === "mp4" || ext === "webm" || ext === "mp3" || ext === "wav" || ext === "ogg" || ext === "m4a");
	return {
		kind,
		mime: resolved,
		playable,
		canPlay,
		reason: playable ? void 0 : `This browser reports no decoder for ${resolved || ext || "this file"}.`
	};
}
function decoderDescription() {
	return "Browser auto";
}
function decoderHelp() {
	return "The browser chooses a hardware or software decoder. UPLAY.IND cannot force HW / SW / HW+ modes the way a native Android player can — claiming otherwise would be fake.";
}
function openDb() {
	return new Promise((resolve, reject) => {
		if (typeof indexedDB === "undefined") {
			reject(/* @__PURE__ */ new Error("IndexedDB is not available in this browser."));
			return;
		}
		const req = indexedDB.open(LIBRARY_DB, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			for (const name of [
				"media",
				"thumbs",
				"handles",
				"downloads",
				"history",
				"files"
			]) if (!db.objectStoreNames.contains(name)) db.createObjectStore(name, { keyPath: "id" });
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("Failed to open library database."));
	});
}
async function withStore(store, mode, fn) {
	const db = await openDb();
	try {
		return await new Promise((resolve, reject) => {
			const tx = db.transaction(store, mode);
			const req = fn(tx.objectStore(store));
			tx.oncomplete = () => {
				if (req) resolve(req.result);
				else resolve(void 0);
			};
			tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("Library database transaction failed."));
			tx.onabort = () => reject(tx.error ?? /* @__PURE__ */ new Error("Library database transaction aborted."));
			if (req) req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("Library database request failed."));
		});
	} finally {
		db.close();
	}
}
async function idbPut(store, value) {
	await withStore(store, "readwrite", (s) => s.put(value));
}
async function idbDelete(store, id) {
	await withStore(store, "readwrite", (s) => s.delete(id));
}
async function idbAll(store) {
	return withStore(store, "readonly", (s) => s.getAll());
}
async function idbClear(store) {
	await withStore(store, "readwrite", (s) => s.clear());
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/input-CbsAZD02.js
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-lg bg-input px-3 text-sm text-fg shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 placeholder:text-subtle focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/library-store-BrI8vPTO.js
/**
* Session-scoped File / ObjectURL registry.
* Files cannot live in localStorage; handles may persist in IndexedDB (Chromium).
*/
var files = /* @__PURE__ */ new Map();
var urls = /* @__PURE__ */ new Map();
var handles = /* @__PURE__ */ new Map();
function setFile(id, file) {
	files.set(id, file);
	const prev = urls.get(id);
	if (prev) URL.revokeObjectURL(prev);
	const url = URL.createObjectURL(file);
	urls.set(id, url);
	return url;
}
function getFile(id) {
	return files.get(id);
}
function getObjectUrl(id) {
	return urls.get(id);
}
function setHandle(id, handle) {
	handles.set(id, handle);
}
function getHandle(id) {
	return handles.get(id);
}
function release(id) {
	files.delete(id);
	handles.delete(id);
	const prev = urls.get(id);
	if (prev) URL.revokeObjectURL(prev);
	urls.delete(id);
}
async function fileFromHandle(handle) {
	try {
		const anyHandle = handle;
		if (anyHandle.queryPermission) {
			let state = await anyHandle.queryPermission({ mode: "read" });
			if (state !== "granted" && anyHandle.requestPermission) state = await anyHandle.requestPermission({ mode: "read" });
			if (state !== "granted") return null;
		}
		return await handle.getFile();
	} catch {
		return null;
	}
}
function isMovie(item) {
	if (item.kind !== "video") return false;
	if (item.duration >= 2700) return true;
	return /movie|film|cinema/i.test(item.folder);
}
function loadMetadata(url, kind) {
	return new Promise((resolve) => {
		const el = document.createElement(kind);
		const done = (values) => {
			el.removeAttribute("src");
			try {
				el.load();
			} catch {}
			resolve(values);
		};
		const timer = window.setTimeout(() => done({ duration: 0 }), 8e3);
		el.preload = "metadata";
		el.onloadedmetadata = () => {
			window.clearTimeout(timer);
			const duration = Number.isFinite(el.duration) ? el.duration : 0;
			if (kind === "video") {
				const v = el;
				done({
					duration,
					width: v.videoWidth || void 0,
					height: v.videoHeight || void 0
				});
			} else done({ duration });
		};
		el.onerror = () => {
			window.clearTimeout(timer);
			done({ duration: 0 });
		};
		el.src = url;
	});
}
async function captureThumb(url, at = 3) {
	if (typeof document === "undefined") return null;
	return new Promise((resolve) => {
		const video = document.createElement("video");
		video.muted = true;
		video.playsInline = true;
		video.preload = "auto";
		const timer = window.setTimeout(() => {
			cleanup();
			resolve(null);
		}, 1e4);
		const cleanup = () => {
			window.clearTimeout(timer);
			video.removeAttribute("src");
			try {
				video.load();
			} catch {}
		};
		video.onerror = () => {
			cleanup();
			resolve(null);
		};
		video.onloadeddata = () => {
			const seekTo = Math.min(at, Math.max(0, (video.duration || 1) * .08));
			try {
				video.currentTime = seekTo;
			} catch {}
		};
		const snap = () => {
			try {
				const w = video.videoWidth;
				const h = video.videoHeight;
				if (!w || !h) {
					cleanup();
					resolve(null);
					return;
				}
				const scale = Math.min(1, 480 / Math.max(w, h));
				const canvas = document.createElement("canvas");
				canvas.width = Math.max(1, Math.round(w * scale));
				canvas.height = Math.max(1, Math.round(h * scale));
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					cleanup();
					resolve(null);
					return;
				}
				ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
				canvas.toBlob((blob) => {
					cleanup();
					resolve(blob);
				}, "image/jpeg", .72);
			} catch {
				cleanup();
				resolve(null);
			}
		};
		video.onseeked = snap;
		video.src = url;
	});
}
async function itemFromFile(file, relativePath) {
	const path = relativePath || file.webkitRelativePath || file.name;
	const probe = probePlayback(file.name, file.type);
	const kind = probe.kind === "audio" || probe.kind === "video" ? probe.kind : sniffKind(file.name, file.type) === "audio" ? "audio" : "video";
	const id = slugId();
	const objectUrl = setFile(id, file);
	let duration = 0;
	let width;
	let height;
	let thumb;
	if (probe.playable && (kind === "video" || kind === "audio")) {
		const meta = await loadMetadata(objectUrl, kind);
		duration = meta.duration;
		width = meta.width;
		height = meta.height;
		if (kind === "video") {
			const blob = await captureThumb(objectUrl);
			if (blob) thumb = blob;
		}
	}
	return {
		item: {
			id,
			name: basename(file.name),
			kind,
			mime: probe.mime || file.type,
			ext: extensionOf(file.name),
			size: file.size,
			duration,
			width,
			height,
			folder: parentFolder(path),
			relativePath: path,
			addedAt: Date.now(),
			position: 0,
			favourite: false,
			source: "local",
			linked: true,
			playable: probe.playable,
			unsupportedReason: probe.reason
		},
		thumb
	};
}
async function scanFiles(fileList, onProgress, onItem) {
	const mediaFiles = fileList.filter((f) => {
		const kind = sniffKind(f.name, f.type);
		return kind === "video" || kind === "audio";
	});
	const items = [];
	const total = mediaFiles.length;
	for (let i = 0; i < mediaFiles.length; i++) {
		const file = mediaFiles[i];
		try {
			const { item, thumb } = await itemFromFile(file);
			items.push(item);
			await onItem?.(item, thumb);
			onProgress?.(i + 1, total, item);
		} catch {
			onProgress?.(i + 1, total);
		}
		if (i % 3 === 2) await new Promise((r) => window.setTimeout(r, 0));
	}
	return items;
}
function collectRelativeFiles(list) {
	return Array.from(list).filter((f) => f.size > 0 && !f.name.startsWith("."));
}
async function persistItem(item) {
	const { ...rest } = item;
	await idbPut("media", rest);
}
async function persistThumb(id, blob) {
	await idbPut("thumbs", {
		id,
		blob
	});
}
function thumbUrlFromBlob(blob) {
	return URL.createObjectURL(blob);
}
var useLibrary = create((set, get) => ({
	items: [],
	thumbs: {},
	ready: false,
	scanning: false,
	scanDone: 0,
	scanTotal: 0,
	error: null,
	hydrate: async () => {
		try {
			const [media, thumbs] = await Promise.all([idbAll("media"), idbAll("thumbs")]);
			const urls = {};
			for (const t of thumbs) if (t.blob) urls[t.id] = thumbUrlFromBlob(t.blob);
			set({
				items: media.map((m) => ({
					...m,
					linked: Boolean(getFile(m.id))
				})),
				thumbs: urls,
				ready: true,
				error: null
			});
			get().restoreHandles();
		} catch (err) {
			set({
				ready: true,
				error: err instanceof Error ? err.message : "Could not load the local library."
			});
		}
	},
	restoreHandles: async () => {
		try {
			const stored = await idbAll("handles");
			const updates = [];
			for (const row of stored) {
				if (!row.handle) continue;
				setHandle(row.id, row.handle);
				const file = await fileFromHandle(row.handle);
				if (!file) continue;
				setFile(row.id, file);
				const current = get().items.find((i) => i.id === row.id);
				if (current && !current.linked) updates.push({
					...current,
					linked: true
				});
			}
			if (updates.length) set({ items: get().items.map((i) => updates.find((u) => u.id === i.id) ?? i) });
		} catch {}
	},
	addFiles: async (files) => {
		if (!files.length) return;
		set({
			scanning: true,
			scanDone: 0,
			scanTotal: files.length,
			error: null
		});
		try {
			await scanFiles(files, (done, total) => set({
				scanDone: done,
				scanTotal: total
			}), async (item, thumb) => {
				await persistItem(item);
				if (thumb) {
					await persistThumb(item.id, thumb);
					const url = thumbUrlFromBlob(thumb);
					set((s) => ({ thumbs: {
						...s.thumbs,
						[item.id]: url
					} }));
				}
				set((s) => ({ items: [item, ...s.items.filter((i) => i.id !== item.id)] }));
			});
		} catch (err) {
			set({ error: err instanceof Error ? err.message : "Scanning stopped because a file could not be read." });
		} finally {
			set({ scanning: false });
		}
	},
	addUrl: (name, url, kind) => {
		const probe = probePlayback(name || url);
		const item = {
			id: slugId(),
			name: name || url,
			kind,
			mime: probe.mime,
			ext: probe.mime.includes("audio") ? "mp3" : "mp4",
			size: 0,
			duration: 0,
			folder: "Network",
			relativePath: url,
			addedAt: Date.now(),
			position: 0,
			favourite: false,
			source: "url",
			url,
			linked: true,
			playable: true
		};
		persistItem(item);
		set((s) => ({ items: [item, ...s.items] }));
		return item;
	},
	toggleFavourite: (id) => {
		const items = get().items.map((i) => i.id === id ? {
			...i,
			favourite: !i.favourite
		} : i);
		const item = items.find((i) => i.id === id);
		if (item) persistItem(item);
		set({ items });
	},
	rememberPlay: (id, position, duration) => {
		const items = get().items.map((i) => i.id === id ? {
			...i,
			position: Math.max(0, position),
			lastPlayedAt: Date.now(),
			duration: duration && duration > 0 ? duration : i.duration
		} : i);
		const item = items.find((i) => i.id === id);
		if (item) persistItem(item);
		set({ items });
	},
	rename: (id, name) => {
		const trimmed = name.trim();
		if (!trimmed) return;
		const items = get().items.map((i) => i.id === id ? {
			...i,
			name: trimmed
		} : i);
		const item = items.find((i) => i.id === id);
		if (item) persistItem(item);
		set({ items });
	},
	remove: async (id, deleteFile = false) => {
		get().items.find((i) => i.id === id);
		if (deleteFile) {
			const handle = getHandle(id);
			try {
				const anyHandle = handle;
				if (anyHandle?.remove) await anyHandle.remove();
			} catch {}
		}
		release(id);
		await idbDelete("media", id);
		await idbDelete("thumbs", id);
		await idbDelete("handles", id);
		const prev = get().thumbs[id];
		if (prev) URL.revokeObjectURL(prev);
		const thumbs = { ...get().thumbs };
		delete thumbs[id];
		set({
			items: get().items.filter((i) => i.id !== id),
			thumbs
		});
	},
	relink: async (id, file) => {
		const { item, thumb } = await itemFromFile(file);
		const previous = get().items.find((i) => i.id === id);
		if (!previous) return;
		release(id);
		setFile(id, file);
		const merged = {
			...previous,
			name: previous.name || item.name,
			mime: item.mime,
			ext: item.ext,
			size: item.size,
			duration: item.duration || previous.duration,
			width: item.width ?? previous.width,
			height: item.height ?? previous.height,
			linked: true,
			playable: item.playable,
			unsupportedReason: item.unsupportedReason
		};
		await persistItem(merged);
		if (thumb) {
			await persistThumb(id, thumb);
			const url = thumbUrlFromBlob(thumb);
			set((s) => ({ thumbs: {
				...s.thumbs,
				[id]: url
			} }));
		}
		set({ items: get().items.map((i) => i.id === id ? merged : i) });
	}
}));
function sortItems(items, sort) {
	const copy = [...items];
	copy.sort((a, b) => {
		switch (sort) {
			case "name": return a.name.localeCompare(b.name);
			case "duration": return b.duration - a.duration;
			case "size": return b.size - a.size;
			default: return b.addedAt - a.addedAt;
		}
	});
	return copy;
}
function itemsForTab(items, tab) {
	switch (tab) {
		case "videos": return items.filter((i) => i.kind === "video" && !isMovie(i));
		case "movies": return items.filter((i) => isMovie(i));
		case "music": return items.filter((i) => i.kind === "audio");
		case "recent": return [...items].filter((i) => i.lastPlayedAt).sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0));
		case "favourites": return items.filter((i) => i.favourite);
		case "downloads": return items.filter((i) => i.source === "download");
		case "folders": return items;
		default: return items;
	}
}
function continueWatching(items) {
	return [...items].filter((i) => i.kind === "video" && i.position > 3 && i.duration > 0 && i.position / i.duration < .95).sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0)).slice(0, 16);
}
function folderGroups(items) {
	const map = /* @__PURE__ */ new Map();
	for (const item of items) {
		const name = item.folder || "Root";
		const g = map.get(name) ?? {
			name,
			count: 0,
			videos: 0,
			audio: 0
		};
		g.count += 1;
		if (item.kind === "video") g.videos += 1;
		else g.audio += 1;
		map.set(name, g);
	}
	return [...map.values()].sort((a, b) => a.name.localeCompare(b.name));
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/player-store-C4oK5lCI.js
var usePlayer = create((set, get) => ({
	currentId: null,
	queue: [],
	playing: false,
	error: null,
	locked: false,
	cues: [],
	subtitleName: null,
	audioTrackLabel: "Default",
	open: (item, queue) => {
		const ids = (queue && queue.length ? queue : [item]).map((i) => i.id);
		set({
			currentId: item.id,
			queue: ids,
			playing: true,
			error: null,
			locked: false,
			cues: [],
			subtitleName: null,
			audioTrackLabel: "Default"
		});
	},
	close: () => set({
		currentId: null,
		playing: false,
		locked: false,
		error: null
	}),
	setPlaying: (playing) => set({ playing }),
	setError: (error) => set({
		error,
		playing: false
	}),
	setLocked: (locked) => set({ locked }),
	setCues: (cues, name = null) => set({
		cues,
		subtitleName: name
	}),
	setAudioTrackLabel: (audioTrackLabel) => set({ audioTrackLabel }),
	nextId: () => {
		const { currentId, queue } = get();
		if (!currentId || queue.length === 0) return null;
		return queue[queue.indexOf(currentId) + 1] ?? null;
	},
	prevId: () => {
		const { currentId, queue } = get();
		if (!currentId || queue.length === 0) return null;
		const i = queue.indexOf(currentId);
		return i > 0 ? queue[i - 1] ?? null : null;
	}
}));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/dialog-BCV9Jtzz.js
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/70 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 grid w-[min(100%-1.5rem,28rem)] -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-elevated p-5 text-fg shadow-[var(--shadow-float)] duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-3 top-3 rounded-md p-2 text-muted opacity-80 hover:bg-secondary hover:opacity-100",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-lg font-semibold", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/dropdown-menu-SW_I0PtA.js
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 min-w-44 overflow-hidden rounded-lg bg-popover p-1 text-popover-foreground shadow-[var(--shadow-float)]", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("flex cursor-pointer select-none items-center gap-2 rounded-md px-2.5 py-2 text-sm outline-none focus:bg-secondary data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-border", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2.5 py-1.5 text-xs font-medium text-muted", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/label-EYcHgVlk.js
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-sm font-medium text-fg", className),
	...props
}));
Label.displayName = Root.displayName;
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-5I6roosF.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-destructive",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function AddMediaButton({ variant = "default" }) {
	const fileRef = (0, import_react.useRef)(null);
	const folderRef = (0, import_react.useRef)(null);
	const addFiles = useLibrary((s) => s.addFiles);
	const addUrl = useLibrary((s) => s.addUrl);
	const openPlayer = usePlayer((s) => s.open);
	const [urlOpen, setUrlOpen] = (0, import_react.useState)(false);
	const [url, setUrl] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const ingest = async (list) => {
		if (!list) return;
		const files = collectRelativeFiles(list);
		if (!files.length) {
			toast.error("No readable media files in that selection.");
			return;
		}
		await addFiles(files);
		toast.success(`Added ${files.length} file${files.length === 1 ? "" : "s"}`);
	};
	const pickFolder = async () => {
		const picker = window;
		if (picker.showDirectoryPicker) try {
			const dir = await picker.showDirectoryPicker({ mode: "read" });
			const files = [];
			const walk = async (handle, prefix) => {
				for await (const [childName, child] of handle.entries()) if (child.kind === "file") {
					const file = await child.getFile();
					Object.defineProperty(file, "webkitRelativePath", { value: `${prefix}${childName}` });
					files.push(file);
				} else if (child.kind === "directory") await walk(child, `${prefix}${childName}/`);
			};
			await walk(dir, `${dir.name}/`);
			await ingest(files);
			return;
		} catch (err) {
			if (err instanceof DOMException && err.name === "AbortError") return;
		}
		folderRef.current?.click();
	};
	const playUrl = () => {
		const trimmed = url.trim();
		if (!trimmed) return;
		try {
			new URL(trimmed);
		} catch {
			toast.error("Enter a valid http(s) URL.");
			return;
		}
		const kind = /\.(mp3|wav|m4a|aac|flac|opus)(\?|$)/i.test(trimmed) ? "audio" : "video";
		const item = addUrl(name.trim() || trimmed, trimmed, kind);
		setUrlOpen(false);
		setUrl("");
		setName("");
		openPlayer(item);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: fileRef,
			type: "file",
			accept: MEDIA_ACCEPT,
			multiple: true,
			className: "sr-only",
			onChange: (e) => {
				ingest(e.target.files);
				e.target.value = "";
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: folderRef,
			type: "file",
			webkitdirectory: "",
			multiple: true,
			className: "sr-only",
			onChange: (e) => {
				ingest(e.target.files);
				e.target.value = "";
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: variant === "header" ? "sm" : "default",
				"aria-label": "Add media",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add media"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
			align: "end",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onSelect: () => fileRef.current?.click(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), " Files"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onSelect: () => void pickFolder(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPlus, {}), " Folder"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onSelect: () => setUrlOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, {}), " Play URL"]
				})
			]
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: urlOpen,
			onOpenChange: setUrlOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Play a network URL" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Direct HTTP(S) media only. Pages, DRM, and extracted streams are not supported." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "media-url",
							children: "URL"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "media-url",
							value: url,
							onChange: (e) => setUrl(e.target.value),
							placeholder: "https://example.com/film.mp4",
							autoComplete: "off"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "media-title",
							children: "Title (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "media-title",
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Display name"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setUrlOpen(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: playUrl,
					children: "Play"
				})] })
			] })
		})
	] });
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("shrink-0", className),
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				fill: "currentColor",
				className: "text-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M9 8.5v10.2c0 3.4 2.5 6.3 7 6.3s7-2.9 7-6.3V8.5h-3.1v10.1c0 1.7-1.2 3.2-3.9 3.2s-3.9-1.5-3.9-3.2V8.5H9z",
				fill: "currentColor",
				className: "text-primary-fg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M21.2 13.2v5.2l4.6-2.6-4.6-2.6z",
				fill: "currentColor",
				className: "text-primary-fg"
			})
		]
	});
}
function Wordmark({ compact = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-2.5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-8" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-display text-lg font-semibold tracking-tight",
				children: ["UPLAY", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-primary",
					children: ".IND"
				})]
			}),
			!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "UPLAY.IND"
			}) : null
		]
	});
}
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full bg-primary transition-[width] duration-200",
		style: { width: `${value ?? 0}%` }
	})
}));
Progress.displayName = Root$1.displayName;
var defaults = {
	theme: "dark",
	accent: "peacock",
	defaultSpeed: 1,
	resumePlayback: true,
	gestures: true,
	brightnessGesture: true,
	backgroundPlayback: true,
	pipEnabled: true,
	autoHideControlsMs: 2800,
	aspect: "contain",
	doubleTapSeek: 10,
	eqEnabled: false,
	eqBands: EQ_FREQUENCIES.map(() => 0),
	bassBoost: 0,
	stereo: true,
	normalize: false,
	subtitleSize: 1.05,
	subtitleColor: "#f8fafc",
	subtitlePosition: 12,
	subtitleDelay: 0,
	subtitleEnabled: true,
	sort: "date",
	view: "grid",
	homepage: DEFAULT_HOMEPAGE,
	searchEngine: "ddg",
	rememberHistory: true,
	wifiOnlyDownloads: false,
	concurrentDownloads: 2
};
var useSettings = create()(persist((set) => ({
	...defaults,
	set: (key, value) => set({ [key]: value }),
	patch: (partial) => set(partial),
	resetEq: () => set({
		eqBands: EQ_FREQUENCIES.map(() => 0),
		bassBoost: 0
	})
}), { name: "uplay-ind-settings" }));
function applyDocumentTheme(theme, accent) {
	if (typeof document === "undefined") return;
	const systemDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? true;
	const resolved = theme === "system" ? systemDark ? "dark" : "light" : theme;
	document.documentElement.dataset.theme = resolved;
	document.documentElement.dataset.accent = accent;
	const color = resolved === "light" ? "#f4f1ea" : "#07080b";
	document.documentElement.style.background = color;
	const meta = document.querySelector("meta[name=\"theme-color\"]");
	if (meta) meta.setAttribute("content", color);
}
function MiniPlayer() {
	const currentId = usePlayer((s) => s.currentId);
	const close = usePlayer((s) => s.close);
	const background = useSettings((s) => s.backgroundPlayback);
	const item = useLibrary((s) => s.items.find((i) => i.id === currentId));
	if (!currentId || !item || !background) return null;
	const pct = item.duration > 0 ? item.position / item.duration * 100 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 bottom-14 z-40 px-3 md:bottom-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto mx-auto flex max-w-xl items-center gap-3 rounded-xl bg-elevated p-2 shadow-[var(--shadow-float)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/player/$id",
				params: { id: item.id },
				className: "flex min-w-0 flex-1 items-center gap-3 px-2",
				"aria-label": `Continue ${item.name}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-9 items-center justify-center rounded-md bg-primary text-primary-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm font-medium",
						children: item.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: pct,
						className: "mt-1"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon-sm",
				variant: "ghost",
				"aria-label": "Dismiss",
				onClick: () => close(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
			})]
		})
	});
}
function Toaster$1() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		theme: "dark",
		position: "bottom-center",
		toastOptions: { classNames: { toast: "bg-elevated text-fg border-border shadow-[var(--shadow-float)]" } }
	});
}
var TooltipProvider = Provider;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-md bg-elevated px-2.5 py-1.5 text-xs text-fg shadow-[var(--shadow-border)]", className),
	...props
}) }));
TooltipContent.displayName = Content2$1.displayName;
function emptyTab() {
	return {
		id: slugId(),
		url: DEFAULT_HOMEPAGE,
		title: "Home",
		loading: false,
		blocked: false
	};
}
function normalizeUrl(raw, searchPrefix) {
	const value = raw.trim();
	if (!value) return DEFAULT_HOMEPAGE;
	if (/^https?:\/\//i.test(value)) return value;
	if (value.includes(" ") || !value.includes(".")) return `${searchPrefix}${encodeURIComponent(value)}`;
	return `https://${value}`;
}
var useBrowser = create()(persist((set, get) => {
	const first = emptyTab();
	return {
		tabs: [first],
		activeId: first.id,
		history: [],
		address: first.url,
		ready: false,
		stacks: { [first.id]: {
			list: [first.url],
			index: 0
		} },
		hydrateHistory: async () => {
			try {
				const history = await idbAll("history");
				history.sort((a, b) => b.visitedAt - a.visitedAt);
				set({
					history,
					ready: true
				});
			} catch {
				set({ ready: true });
			}
		},
		setAddress: (address) => set({ address }),
		navigate: (raw, searchPrefix, remember) => {
			const url = normalizeUrl(raw, searchPrefix);
			const { activeId, tabs, stacks } = get();
			const stack = stacks[activeId] ?? {
				list: [url],
				index: 0
			};
			const list = [...stack.list.slice(0, stack.index + 1), url];
			const index = list.length - 1;
			set({
				tabs: tabs.map((t) => t.id === activeId ? {
					...t,
					url,
					loading: true,
					blocked: false,
					title: url
				} : t),
				address: url,
				stacks: {
					...stacks,
					[activeId]: {
						list,
						index
					}
				}
			});
			if (remember) {
				const entry = {
					id: slugId(),
					url,
					title: url,
					visitedAt: Date.now()
				};
				idbPut("history", entry);
				set({ history: [entry, ...get().history].slice(0, 200) });
			}
		},
		setTabMeta: (id, partial) => {
			set({ tabs: get().tabs.map((t) => t.id === id ? {
				...t,
				...partial
			} : t) });
		},
		newTab: () => {
			const tab = emptyTab();
			set({
				tabs: [...get().tabs, tab],
				activeId: tab.id,
				address: tab.url,
				stacks: {
					...get().stacks,
					[tab.id]: {
						list: [tab.url],
						index: 0
					}
				}
			});
		},
		closeTab: (id) => {
			const tabs = get().tabs.filter((t) => t.id !== id);
			if (tabs.length === 0) {
				const tab = emptyTab();
				set({
					tabs: [tab],
					activeId: tab.id,
					address: tab.url,
					stacks: { [tab.id]: {
						list: [tab.url],
						index: 0
					} }
				});
				return;
			}
			const activeId = get().activeId === id ? tabs[tabs.length - 1].id : get().activeId;
			set({
				tabs,
				activeId,
				address: tabs.find((t) => t.id === activeId).url
			});
		},
		activate: (id) => {
			const tab = get().tabs.find((t) => t.id === id);
			if (!tab) return;
			set({
				activeId: id,
				address: tab.url
			});
		},
		back: () => {
			const { activeId, stacks, tabs } = get();
			const stack = stacks[activeId];
			if (!stack || stack.index <= 0) return;
			const index = stack.index - 1;
			const url = stack.list[index];
			set({
				stacks: {
					...stacks,
					[activeId]: {
						...stack,
						index
					}
				},
				address: url,
				tabs: tabs.map((t) => t.id === activeId ? {
					...t,
					url
				} : t)
			});
		},
		forward: () => {
			const { activeId, stacks, tabs } = get();
			const stack = stacks[activeId];
			if (!stack || stack.index >= stack.list.length - 1) return;
			const index = stack.index + 1;
			const url = stack.list[index];
			set({
				stacks: {
					...stacks,
					[activeId]: {
						...stack,
						index
					}
				},
				address: url,
				tabs: tabs.map((t) => t.id === activeId ? {
					...t,
					url
				} : t)
			});
		},
		reload: () => {
			const { activeId, tabs } = get();
			set({ tabs: tabs.map((t) => t.id === activeId ? {
				...t,
				loading: true,
				url: t.url
			} : t) });
		},
		home: (homepage) => {
			get().navigate(homepage, homepage, false);
		},
		clearHistory: async () => {
			await idbClear("history");
			set({ history: [] });
		}
	};
}, {
	name: "uplay-ind-browser-tabs",
	partialize: (s) => ({
		tabs: s.tabs.map((t) => ({
			...t,
			loading: false
		})),
		activeId: s.activeId,
		address: s.address,
		stacks: s.stacks
	})
}));
var controllers = /* @__PURE__ */ new Map();
var paused = /* @__PURE__ */ new Set();
var DIRECT_EXT = /\.(mp4|webm|ogg|ogv|mp3|wav|m4a|aac|flac|opus|mov|m4v)(\?|$)/i;
function looksDirect(url) {
	return DIRECT_EXT.test(url);
}
async function persist$1(rec) {
	await idbPut("downloads", rec);
}
function patch(id, partial) {
	useDownloads.setState((s) => ({ items: s.items.map((i) => i.id === id ? {
		...i,
		...partial
	} : i) }));
	const rec = useDownloads.getState().items.find((i) => i.id === id);
	if (rec) persist$1(rec);
}
async function runDownload(id) {
	const rec = useDownloads.getState().items.find((i) => i.id === id);
	if (!rec) return;
	if (!looksDirect(rec.url) && !rec.url.startsWith("blob:")) {
		patch(id, {
			status: "error",
			error: "This is not a direct media URL. UPLAY.IND will not extract media from web pages.",
			finishedAt: Date.now()
		});
		return;
	}
	const controller = new AbortController();
	controllers.set(id, controller);
	patch(id, {
		status: "running",
		error: void 0
	});
	try {
		const res = await fetch(rec.url, { signal: controller.signal });
		if (!res.ok) throw new Error(`Download failed (${res.status}).`);
		const type = res.headers.get("content-type") || "";
		if (type.includes("text/html")) throw new Error("This URL returned a web page, not a media file. Direct media URLs only.");
		const total = Number(res.headers.get("content-length") || rec.total || 0);
		if (!res.body) {
			const blob = await res.blob();
			await finishBlob(id, rec.name, blob, rec.url);
			return;
		}
		const reader = res.body.getReader();
		const chunks = [];
		let received = 0;
		while (true) {
			if (paused.has(id)) {
				controller.abort();
				patch(id, {
					status: "paused",
					received,
					total
				});
				return;
			}
			const { done, value } = await reader.read();
			if (done) break;
			if (value) {
				chunks.push(value.slice());
				received += value.byteLength;
				patch(id, {
					received,
					total
				});
			}
		}
		const blob = new Blob(chunks, { type: type || "application/octet-stream" });
		await finishBlob(id, rec.name, blob, rec.url);
	} catch (err) {
		if (paused.has(id)) {
			patch(id, { status: "paused" });
			return;
		}
		const message = err instanceof DOMException && err.name === "AbortError" ? void 0 : err instanceof Error ? err.message : "Download failed.";
		if (useDownloads.getState().items.find((i) => i.id === id)?.status === "cancelled") return;
		patch(id, {
			status: "error",
			error: message || "Download was interrupted.",
			finishedAt: Date.now()
		});
	} finally {
		controllers.delete(id);
	}
}
async function finishBlob(id, name, blob, url) {
	const filename = name || basename(url.split("?")[0] ?? "download");
	const file = new File([blob], filename, { type: blob.type });
	if (!probePlayback(filename, blob.type).playable) {
		triggerSave(file);
		patch(id, {
			status: "done",
			received: blob.size,
			total: blob.size,
			finishedAt: Date.now()
		});
		return;
	}
	await useLibrary.getState().addFiles([file]);
	const added = useLibrary.getState().items.find((i) => i.name === filename);
	if (added) {
		const updated = {
			...added,
			source: "download",
			url
		};
		useLibrary.setState((s) => ({ items: s.items.map((i) => i.id === added.id ? updated : i) }));
	}
	triggerSave(file);
	patch(id, {
		status: "done",
		received: blob.size,
		total: blob.size,
		finishedAt: Date.now(),
		mediaId: added?.id
	});
}
function triggerSave(file) {
	try {
		const a = document.createElement("a");
		a.href = URL.createObjectURL(file);
		a.download = file.name;
		a.rel = "noopener";
		a.click();
		window.setTimeout(() => URL.revokeObjectURL(a.href), 4e3);
	} catch {}
}
function pumpQueue() {
	const { items } = useDownloads.getState();
	const running = items.filter((i) => i.status === "running").length;
	const max = 2;
	const next = items.find((i) => i.status === "queued");
	if (next && running < max) runDownload(next.id);
}
var useDownloads = create((set, get) => ({
	items: [],
	ready: false,
	hydrate: async () => {
		try {
			set({
				items: await idbAll("downloads"),
				ready: true
			});
		} catch {
			set({ ready: true });
		}
	},
	enqueue: async (url, name) => {
		const trimmed = url.trim();
		if (!trimmed) return null;
		try {
			new URL(trimmed);
		} catch {
			return null;
		}
		if (!looksDirect(trimmed)) {
			const rec = {
				id: slugId(),
				name: name || basename(trimmed),
				url: trimmed,
				status: "error",
				received: 0,
				total: 0,
				error: "Not a direct media URL. Paste a link that ends in mp4, webm, mp3, etc.",
				startedAt: Date.now(),
				finishedAt: Date.now()
			};
			await persist$1(rec);
			set({ items: [rec, ...get().items] });
			return rec.id;
		}
		const rec = {
			id: slugId(),
			name: name || basename(trimmed.split("?")[0] ?? "media"),
			url: trimmed,
			status: "queued",
			received: 0,
			total: 0,
			startedAt: Date.now()
		};
		await persist$1(rec);
		set({ items: [rec, ...get().items] });
		pumpQueue();
		return rec.id;
	},
	pause: (id) => {
		paused.add(id);
		controllers.get(id)?.abort();
		patch(id, { status: "paused" });
	},
	resume: (id) => {
		paused.delete(id);
		patch(id, { status: "queued" });
		pumpQueue();
	},
	cancel: (id) => {
		paused.delete(id);
		controllers.get(id)?.abort();
		patch(id, {
			status: "cancelled",
			finishedAt: Date.now()
		});
	},
	remove: (id) => {
		paused.delete(id);
		controllers.get(id)?.abort();
		idbDelete("downloads", id);
		set({ items: get().items.filter((i) => i.id !== id) });
	}
}));
var NAV = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/library",
		label: "Library",
		icon: FolderOpen
	},
	{
		to: "/browser",
		label: "Browser",
		icon: Compass
	},
	{
		to: "/downloads",
		label: "Downloads",
		icon: Download
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings
	}
];
function AppShell() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const hydrate = useLibrary((s) => s.hydrate);
	const hydrateDownloads = useDownloads((s) => s.hydrate);
	const hydrateHistory = useBrowser((s) => s.hydrateHistory);
	const theme = useSettings((s) => s.theme);
	const accent = useSettings((s) => s.accent);
	const scanning = useLibrary((s) => s.scanning);
	const scanDone = useLibrary((s) => s.scanDone);
	const scanTotal = useLibrary((s) => s.scanTotal);
	(0, import_react.useEffect)(() => {
		hydrate();
		hydrateDownloads();
		hydrateHistory();
	}, [
		hydrate,
		hydrateDownloads,
		hydrateHistory
	]);
	(0, import_react.useEffect)(() => {
		applyDocumentTheme(theme, accent);
		const mq = window.matchMedia("(prefers-color-scheme: dark)");
		const onChange = () => applyDocumentTheme(theme, accent);
		mq.addEventListener?.("change", onChange);
		return () => mq.removeEventListener?.("change", onChange);
	}, [theme, accent]);
	const hideChrome = pathname.startsWith("/player/");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 250,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-dvh bg-bg text-fg",
			children: [hideChrome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-dvh max-w-[1400px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "sticky top-0 hidden h-dvh w-[220px] shrink-0 flex-col border-r border-border bg-sidebar p-4 md:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "mb-8 px-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "flex flex-1 flex-col gap-1",
								children: NAV.map((item) => {
									const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
									const Icon = item.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: item.to,
										className: cn("flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium text-muted transition-colors duration-150", active ? "bg-secondary text-fg" : "hover:bg-secondary/60 hover:text-fg"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
									}, item.to);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddMediaButton, {})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 backdrop-blur md:hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { compact: true })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddMediaButton, { variant: "header" })]
							}),
							scanning ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b border-border bg-surface px-4 py-2 text-xs text-muted",
								children: [
									"Scanning library… ",
									scanDone,
									"/",
									scanTotal
								]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
								className: "flex-1 px-4 pb-28 pt-4 md:px-8 md:pb-24 md:pt-8",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden",
						children: NAV.map((item) => {
							const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("flex h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium", active ? "text-primary" : "text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniPlayer, {})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})]
		})
	});
}
var styles_default = "/assets/styles-CEDQ2yyh.css";
var APP_NAME = "UPLAY.IND";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#07080b"
			},
			{
				name: "description",
				content: "UPLAY.IND — a dark-first, offline-first media player for video and music on your device."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Outfit:wght@400;500;600;700&family=Syne:wght@600;700;800&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	}),
	notFoundComponent: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[50vh] flex-col items-center justify-center gap-2 p-8 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold",
			children: "Not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "That screen doesn’t exist in UPLAY.IND."
		})]
	})
});
var $$splitComponentImporter$5 = () => import("./routes-CKJhEafy.mjs");
var Route$5 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./browser-BRISgVsd.mjs");
var Route$4 = createFileRoute("/browser")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./downloads-DfEqAvF4.mjs");
var Route$3 = createFileRoute("/downloads")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./library-DAlfiNAB.mjs");
var Route$2 = createFileRoute("/library")({
	validateSearch: (s) => ({
		tab: typeof s.tab === "string" ? s.tab : void 0,
		folder: typeof s.folder === "string" ? s.folder : void 0,
		q: typeof s.q === "string" ? s.q : void 0,
		inspect: typeof s.inspect === "string" ? s.inspect : void 0,
		action: typeof s.action === "string" ? s.action : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./settings-DMuw8DnY.mjs");
var Route$1 = createFileRoute("/settings")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./player._id-DECSilkI.mjs");
var Route = createFileRoute("/player/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$5.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$6
	}),
	BrowserRoute: Route$4.update({
		id: "/browser",
		path: "/browser",
		getParentRoute: () => Route$6
	}),
	DownloadsRoute: Route$3.update({
		id: "/downloads",
		path: "/downloads",
		getParentRoute: () => Route$6
	}),
	LibraryRoute: Route$2.update({
		id: "/library",
		path: "/library",
		getParentRoute: () => Route$6
	}),
	SettingsRoute: Route$1.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$6
	}),
	PlayerIdRoute: Route.update({
		id: "/player/$id",
		path: "/player/$id",
		getParentRoute: () => Route$6
	})
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Input as A, clamp as B, continueWatching as C, itemsForTab as D, getObjectUrl as E, EQ_FREQUENCIES as F, formatClock as G, decoderDescription as H, PUBLIC_STREAMS as I, formatDuration as K, SEARCH_ENGINES as L, APP_TAGLINE as M, APP_VERSION as N, sortItems as O, Button as P, SPEED_PRESETS as R, usePlayer as S, getFile as T, decoderHelp as U, cn as V, formatBytes as W, DialogContent as _, useBrowser as a, DialogHeader as b, AddMediaButton as c, DropdownMenuContent as d, DropdownMenuItem as f, Dialog as g, DropdownMenuTrigger as h, useDownloads as i, APP_NAME$1 as j, useLibrary as k, Label as l, DropdownMenuSeparator as m, Route as n, useSettings as o, DropdownMenuLabel as p, Route$2 as r, Progress as s, router_exports as t, DropdownMenu as u, DialogDescription as v, folderGroups as w, DialogTitle as x, DialogFooter as y, buttonVariants as z };
