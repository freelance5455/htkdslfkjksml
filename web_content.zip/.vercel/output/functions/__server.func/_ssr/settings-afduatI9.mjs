import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as STYLES } from "./options-I4YTksiA.mjs";
import { a as useProjects, c as writePrefs, i as readPrefs, o as useStory, t as DEFAULT_PREFS } from "./use-projects-B0rAf6PZ.mjs";
import { n as SCENE_COUNTS, r as SelectInput, t as Field } from "./types-C96IdVUM.mjs";
import { t as Button } from "./button-ZNEObmRA.mjs";
import { n as SwitchThumb, t as Switch } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-afduatI9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const ready = useProjects();
	const clearAll = useStory((state) => state.clearAll);
	const [prefs, setPrefs] = (0, import_react.useState)(DEFAULT_PREFS);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setPrefs(readPrefs());
	}, []);
	function save(next) {
		setPrefs(next);
		writePrefs(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-xl gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted uppercase",
					children: "Settings"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Pengaturan baru"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Dipakai saat storyboard baru dibuat. Storyboard yang sudah ada tidak berubah. Data tetap di browser ini."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-medium",
							children: "Default scenes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: SCENE_COUNTS.map((count) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => save({
									...prefs,
									sceneCount: count
								}),
								className: `inline-flex size-11 items-center justify-center rounded-md text-sm font-medium ${prefs.sceneCount === count ? "bg-accent text-accent-fg" : "border border-line bg-bg"}`,
								children: count
							}, count))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Default photography style",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: prefs.style,
							onChange: (event) => save({
								...prefs,
								style: event.target.value
							}),
							children: STYLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Default aspect ratio",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: prefs.aspect,
							onChange: (event) => save({
								...prefs,
								aspect: event.target.value
							}),
							children: [
								"1:1",
								"4:5",
								"9:16",
								"16:9"
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-11 items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium",
							children: "Product consistency lock"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: prefs.consistencyLock,
							onCheckedChange: (checked) => save({
								...prefs,
								consistencyLock: checked
							}),
							className: "relative h-7 w-12 rounded-full bg-faint data-[state=checked]:bg-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-5 translate-x-1 rounded-full bg-surface transition-transform duration-150 data-[state=checked]:translate-x-6" })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium",
						children: "Hapus semua storyboard"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Foto referensi dan gambar scene di browser ini ikut terhapus."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						disabled: !ready,
						onClick: () => {
							if (!confirm) {
								setConfirm(true);
								return;
							}
							clearAll();
							setConfirm(false);
						},
						children: confirm ? "Ya, hapus semua" : "Hapus semua"
					})
				]
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
