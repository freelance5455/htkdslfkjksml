import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as Input, F as EQ_FREQUENCIES, H as decoderDescription, L as SEARCH_ENGINES, N as APP_VERSION, P as Button, U as decoderHelp, V as cn, a as useBrowser, j as APP_NAME, l as Label, o as useSettings } from "./router-5I6roosF.mjs";
import { t as Slider } from "./slider-VODu9m8l.mjs";
import { t as Root } from "../_libs/radix-ui__react-separator.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DMuw8DnY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
	...props
}));
Separator.displayName = Root.displayName;
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full bg-secondary shadow-[var(--shadow-border)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block size-5 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0.5 data-[state=checked]:bg-primary-fg") })
}));
Switch.displayName = Switch$1.displayName;
function SettingsPage() {
	const s = useSettings();
	const clearHistory = useBrowser((st) => st.clearHistory);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Settings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Stored on this device only."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Appearance",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Theme",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						value: s.theme,
						onChange: (v) => s.set("theme", v),
						options: [
							{
								id: "dark",
								label: "Dark"
							},
							{
								id: "light",
								label: "Light"
							},
							{
								id: "system",
								label: "System"
							}
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						value: s.accent,
						onChange: (v) => s.set("accent", v),
						options: [
							{
								id: "peacock",
								label: "Peacock"
							},
							{
								id: "copper",
								label: "Copper"
							},
							{
								id: "steel",
								label: "Steel"
							}
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Player",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Resume playback",
						hint: "Continue from the last position",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.resumePlayback,
							onCheckedChange: (v) => s.set("resumePlayback", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Gesture controls",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.gestures,
							onCheckedChange: (v) => s.set("gestures", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Brightness gesture",
						hint: "Left-edge vertical drag",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.brightnessGesture,
							onCheckedChange: (v) => s.set("brightnessGesture", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Background playback",
						hint: "Keep a mini player when you leave the screen",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.backgroundPlayback,
							onCheckedChange: (v) => s.set("backgroundPlayback", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Picture-in-picture",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.pipEnabled,
							onCheckedChange: (v) => s.set("pipEnabled", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Default speed",
						hint: `${s.defaultSpeed}×`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: .25,
								max: 2,
								step: .25,
								value: [s.defaultSpeed],
								onValueChange: ([v]) => s.set("defaultSpeed", v ?? 1)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Double-tap seek",
						hint: `${s.doubleTapSeek}s`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 5,
								max: 30,
								step: 5,
								value: [s.doubleTapSeek],
								onValueChange: ([v]) => s.set("doubleTapSeek", v ?? 10)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Decoder",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xs text-right text-sm text-muted",
							children: decoderDescription()
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: decoderHelp()
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Video",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Default aspect",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						value: s.aspect,
						onChange: (v) => s.set("aspect", v),
						options: [
							{
								id: "contain",
								label: "Fit"
							},
							{
								id: "cover",
								label: "Crop"
							},
							{
								id: "fill",
								label: "Stretch"
							}
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Audio",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Equalizer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.eqEnabled,
							onCheckedChange: (v) => s.set("eqEnabled", v)
						})
					}),
					s.eqEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: EQ_FREQUENCIES.map((freq, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: freq >= 1e3 ? `${freq / 1e3} kHz` : `${freq} Hz`,
							hint: `${s.eqBands[i] ?? 0} dB`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-40",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									min: -12,
									max: 12,
									step: 1,
									value: [s.eqBands[i] ?? 0],
									onValueChange: ([v]) => {
										const next = [...s.eqBands];
										next[i] = v ?? 0;
										s.set("eqBands", next);
									}
								})
							})
						}, freq))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: "Turned off so unused Web Audio graphs are not created."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Bass boost",
						hint: `${s.bassBoost} dB`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 0,
								max: 12,
								step: 1,
								value: [s.bassBoost],
								onValueChange: ([v]) => s.set("bassBoost", v ?? 0)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Stereo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.stereo,
							onCheckedChange: (v) => s.set("stereo", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Loudness limiter",
						hint: "Gentle compressor, not replay-gain scanning",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.normalize,
							onCheckedChange: (v) => s.set("normalize", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => s.resetEq(),
						children: "Reset equalizer"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Subtitles",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Enabled",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.subtitleEnabled,
							onCheckedChange: (v) => s.set("subtitleEnabled", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Size",
						hint: `${s.subtitleSize.toFixed(2)} rem`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: .8,
								max: 2,
								step: .05,
								value: [s.subtitleSize],
								onValueChange: ([v]) => s.set("subtitleSize", v ?? 1)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Position from bottom",
						hint: `${s.subtitlePosition}%`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 4,
								max: 40,
								step: 1,
								value: [s.subtitlePosition],
								onValueChange: ([v]) => s.set("subtitlePosition", v ?? 12)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Delay",
						hint: `${s.subtitleDelay.toFixed(1)}s`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: -5,
								max: 5,
								step: .1,
								value: [s.subtitleDelay],
								onValueChange: ([v]) => s.set("subtitleDelay", v ?? 0)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Colour",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "color",
							value: s.subtitleColor,
							onChange: (e) => s.set("subtitleColor", e.target.value),
							className: "h-10 w-14 cursor-pointer rounded-md bg-transparent",
							"aria-label": "Subtitle colour"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Library",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Default sort",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						value: s.sort,
						onChange: (v) => s.set("sort", v),
						options: [
							{
								id: "date",
								label: "Added"
							},
							{
								id: "name",
								label: "Name"
							},
							{
								id: "duration",
								label: "Length"
							},
							{
								id: "size",
								label: "Size"
							}
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Default view",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						value: s.view,
						onChange: (v) => s.set("view", v),
						options: [{
							id: "grid",
							label: "Grid"
						}, {
							id: "list",
							label: "List"
						}]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Browser",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "homepage",
							children: "Homepage"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "homepage",
							value: s.homepage,
							onChange: (e) => s.set("homepage", e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Search engine",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
							value: s.searchEngine,
							onChange: (v) => s.set("searchEngine", v),
							options: Object.keys(SEARCH_ENGINES).map((id) => ({
								id,
								label: SEARCH_ENGINES[id].label
							}))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Remember history",
						hint: "Stored locally. Never sent to a server.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: s.rememberHistory,
							onCheckedChange: (v) => s.set("rememberHistory", v)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => {
							clearHistory();
						},
						children: "Clear browsing data"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Downloads",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Concurrent downloads",
					hint: String(s.concurrentDownloads),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 1,
							max: 3,
							step: 1,
							value: [s.concurrentDownloads],
							onValueChange: ([v]) => s.set("concurrentDownloads", v ?? 1)
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: "Files save through the browser download prompt. UPLAY.IND does not write arbitrary paths on disk — that would bypass browser security."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "About",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							APP_NAME,
							" ",
							APP_VERSION
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Playback uses the browser’s media engine. Library metadata, playback position, favourites, history, and settings stay in IndexedDB / localStorage on this device. No accounts. No analytics. No media uploaded."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Permissions used: file access you grant via the picker. No contacts, SMS, phone, location, camera, or microphone."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Open-source libraries: React, TanStack Router, Zustand, Radix UI, Lucide, Sonner. Media decoding is provided by the browser, not a bundled codec pack."
					})
				]
			})
		]
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-lg font-semibold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "mt-2" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children
		})]
	});
}
function Row({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium",
			children: label
		}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-subtle",
			children: hint
		}) : null] }), children]
	});
}
function Segment({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap justify-end gap-1 rounded-lg bg-secondary p-1",
		children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(o.id),
			className: cn("h-8 rounded-md px-2.5 text-xs font-medium", value === o.id ? "bg-elevated text-fg shadow-[var(--shadow-border)]" : "text-muted"),
			children: o.label
		}, o.id))
	});
}
//#endregion
export { SettingsPage as component };
