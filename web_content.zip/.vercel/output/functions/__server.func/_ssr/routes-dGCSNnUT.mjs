import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { g as ChevronLeft, h as ChevronRight, r as Trash2 } from "../_libs/lucide-react.mjs";
import { t as format } from "../_libs/date-fns.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { D as streakEnding, S as parseDay, T as shiftDay, _ as useDayPart, g as greetingFor, i as usePlanner, k as cn, s as MOODS, v as useTodayKey } from "./router-CQnHyG8o.mjs";
import { c as SectionMark, n as Card, o as IconButton, r as CardTitle, t as AddRow } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
import { t as SortableList } from "./sortable-DqnUMi7n.mjs";
import { t as CheckList } from "./check-list-Bim0RNJK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-dGCSNnUT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TodayView() {
	const today = useTodayKey();
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const active = cursor ?? today;
	if (!active || !today) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodaySkeleton, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayPage, {
		date: active,
		today,
		onDate: setCursor
	});
}
function TodaySkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionMark, { section: "today" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-medium text-ink",
			children: "Today"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted",
			children: "Opening your page."
		})
	] });
}
function TodayPage({ date, today, onDate }) {
	const name = usePlanner((s) => s.name);
	const samplesOn = usePlanner((s) => s.samplesOn);
	const dismissSamples = usePlanner((s) => s.dismissSamples);
	const day = usePlanner((s) => s.days[date]);
	const patchDay = usePlanner((s) => s.patchDay);
	const habits = usePlanner((s) => s.habits);
	const tasks = usePlanner((s) => s.tasks);
	const lists = usePlanner((s) => s.lists);
	const toggleHabit = usePlanner((s) => s.toggleHabit);
	const updateTask = usePlanner((s) => s.updateTask);
	const part = useDayPart();
	const log = {
		intention: day?.intention ?? "",
		gratitude: [
			day?.gratitude?.[0] ?? "",
			day?.gratitude?.[1] ?? "",
			day?.gratitude?.[2] ?? ""
		],
		priorities: day?.priorities ?? [],
		schedule: day?.schedule ?? [],
		mood: day?.mood ?? null,
		water: day?.water ?? 0,
		journal: day?.journal ?? "",
		affirmation: day?.affirmation ?? ""
	};
	const todayList = lists.find((list) => list.id === "list-today") ?? lists[0];
	const due = tasks.filter((task) => todayList && task.listId === todayList.id && !task.done);
	const when = parseDay(date);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		samplesOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex items-start justify-between gap-3 rounded-3xl bg-blush px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-pretty text-ink",
				children: "Sample pages are open so you can look around. Edit them freely, or clear everything in Studio."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 shrink-0 px-1 text-sm font-medium",
				onClick: dismissSamples,
				children: "Dismiss"
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex items-end justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionMark, { section: "today" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl font-medium tracking-tight text-balance text-ink",
						children: format(when, "EEEE")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-base text-muted",
						children: [
							greetingFor(part, name),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: " · " }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: format(when, "d MMMM")
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Previous day",
					onClick: () => onDate(shiftDay(date, -1)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
						className: "size-5",
						strokeWidth: 1.6
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Next day",
					onClick: () => onDate(shiftDay(date, 1)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
						className: "size-5",
						strokeWidth: 1.6
					})
				})]
			})]
		}),
		date !== today ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-4 text-sm font-medium text-accent",
			onClick: () => onDate(null),
			children: "Back to today"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 lg:grid-cols-[1.3fr_0.9fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid content-start gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Intention" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: log.intention,
						onChange: (event) => patchDay(date, (d) => ({
							...d,
							intention: event.target.value
						})),
						placeholder: "One sentence for how you want to move through this day.",
						rows: 3,
						className: "min-h-20 w-full resize-none bg-transparent text-base leading-normal outline-none placeholder:text-muted"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						aside: log.priorities.length > 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: "Three is usually enough."
						}) : null,
						children: "Priorities"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckList, {
						items: log.priorities,
						placeholder: "A priority",
						onChange: (priorities) => patchDay(date, (d) => ({
							...d,
							priorities
						}))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Schedule" }),
						log.schedule.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableList, {
							items: log.schedule,
							getId: (item) => item.id,
							onReorder: (schedule) => patchDay(date, (d) => ({
								...d,
								schedule
							})),
							render: (block, grip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1 rounded-lg border border-line bg-card pr-1",
								children: [
									grip,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: block.time,
										onChange: (event) => patchDay(date, (d) => ({
											...d,
											schedule: d.schedule.map((item) => item.id === block.id ? {
												...item,
												time: event.target.value
											} : item)
										})),
										"aria-label": "Time",
										className: "h-11 w-16 shrink-0 bg-transparent text-center text-sm tabular-nums outline-none"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "grid size-11 shrink-0 place-items-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: block.done,
											"aria-label": "Mark block",
											onChange: () => patchDay(date, (d) => ({
												...d,
												schedule: d.schedule.map((item) => item.id === block.id ? {
													...item,
													done: !item.done
												} : item)
											})),
											className: "size-5 accent-accent"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: block.text,
										onChange: (event) => patchDay(date, (d) => ({
											...d,
											schedule: d.schedule.map((item) => item.id === block.id ? {
												...item,
												text: event.target.value
											} : item)
										})),
										"aria-label": "Plan",
										className: cn("h-11 min-w-0 flex-1 bg-transparent text-base outline-none", block.done && "text-muted line-through")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Remove block",
										className: "grid size-11 place-items-center text-muted",
										onClick: () => {
											const prev = log.schedule;
											patchDay(date, (d) => ({
												...d,
												schedule: d.schedule.filter((item) => item.id !== block.id)
											}));
											toast("Removed", { action: {
												label: "Undo",
												onClick: () => patchDay(date, (d) => ({
													...d,
													schedule: prev
												}))
											} });
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
											className: "size-4",
											strokeWidth: 1.6
										})
									})
								]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "A loose shape for the hours, not a packed grid."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddRow, {
							placeholder: "What happens",
							onAdd: (text) => patchDay(date, (d) => ({
								...d,
								schedule: [...d.schedule, {
									id: uid(),
									time: "09:00",
									text,
									done: false
								}]
							}))
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Journal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: log.journal,
						onChange: (event) => patchDay(date, (d) => ({
							...d,
							journal: event.target.value
						})),
						placeholder: "What is asking for your attention?",
						rows: 6,
						className: "min-h-32 w-full resize-y bg-transparent font-display text-lg leading-normal outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
					})] })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid content-start gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						aside: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/habits",
							className: "text-sm text-muted hover:text-ink",
							children: "All habits"
						}),
						children: "Habits"
					}), habits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No habits yet."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-1",
						children: habits.map((habit) => {
							const on = !!habit.checks[date];
							const streak = streakEnding(habit.checks, parseDay(today));
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": on,
										onClick: () => toggleHabit(habit.id, date),
										className: "grid size-11 place-items-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-5 rounded-full border-2",
											style: {
												borderColor: habit.color,
												background: on ? habit.color : "transparent"
											}
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("min-w-0 flex-1 truncate text-base", on && "text-muted line-through"),
										children: habit.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm tabular-nums text-muted",
										children: [streak, "d"]
									})
								]
							}, habit.id);
						})
					})] }),
					todayList && due.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						aside: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tasks",
							className: "text-sm text-muted hover:text-ink",
							children: todayList.name
						}),
						children: "To do"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-1",
						children: due.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "grid size-11 place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: task.done,
									"aria-label": task.text,
									onChange: () => updateTask(task.id, { done: !task.done }),
									className: "size-5 accent-accent"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 text-base",
								children: task.text
							})]
						}, task.id))
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Gratitude" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: log.gratitude.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: line,
							"aria-label": `Gratitude ${index + 1}`,
							placeholder: index === 0 ? "Something small and true" : "And another",
							onChange: (event) => patchDay(date, (d) => {
								const gratitude = [...d.gratitude];
								gratitude[index] = event.target.value;
								return {
									...d,
									gratitude
								};
							}),
							className: "h-11 w-full bg-transparent text-base outline-none placeholder:text-muted"
						}, index))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Mood" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-5 gap-1",
						children: MOODS.map((mood, index) => {
							const on = log.mood === index;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": on,
								"aria-label": mood.hint,
								onClick: () => patchDay(date, (d) => ({
									...d,
									mood: d.mood === index ? null : index
								})),
								className: cn("flex h-14 flex-col items-center justify-center rounded-lg text-xs font-medium", on ? "bg-blush text-ink" : "text-muted hover:bg-paper"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mb-1 size-2 rounded-full", on ? "bg-accent" : "bg-line") }), mood.label]
							}, mood.label);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-sm text-muted",
							children: [log.water, "/8"]
						}),
						children: "Water"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-8 gap-1",
						children: Array.from({ length: 8 }, (_, i) => {
							const n = i + 1;
							const on = log.water >= n;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `${n} glasses`,
								"aria-pressed": on,
								onClick: () => patchDay(date, (d) => ({
									...d,
									water: d.water === n ? n - 1 : n
								})),
								className: "grid h-11 place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-4 rounded-full border", on ? "border-sage bg-sage" : "border-line") })
							}, n);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "A line to return to" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: log.affirmation,
						onChange: (event) => patchDay(date, (d) => ({
							...d,
							affirmation: event.target.value
						})),
						placeholder: "Short enough to remember.",
						className: "h-11 w-full bg-transparent font-display text-xl outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
					})] })
				]
			})]
		})
	] });
}
var SplitComponent = TodayView;
//#endregion
export { SplitComponent as component };
