import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { G as visualsForPreset, I as presetLabel, L as safeLaunchUrl, N as graphicsLabel, O as detailLabel, R as scaleLabel, T as aaLabel, V as useAppStore, W as visualsForGraphics, _ as PageHeader, a as Button, c as DETAIL, d as GRAPHICS, g as PRESETS, h as Notice, l as FPS_TARGETS, t as AA, u as Field, v as Panel, y as SCALE } from "./ui-CJMJB--P.mjs";
import { c as ImagePlus, d as ExternalLink, r as Trash2 } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/games-DzKK9ZEE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function imageFileToDataUrl(file) {
	if (!file.type.startsWith("image/")) throw new Error("Choose an image file.");
	if (file.size > 8388608) throw new Error("That image is larger than 8 MB.");
	const source = await loadSource(file);
	const size = 192;
	const canvas = document.createElement("canvas");
	canvas.width = size;
	canvas.height = size;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("This browser could not prepare the image.");
	const scale = Math.max(size / source.width, size / source.height);
	const width = source.width * scale;
	const height = source.height * scale;
	ctx.drawImage(source, (size - width) / 2, (size - height) / 2, width, height);
	if ("close" in source && typeof source.close === "function") source.close();
	return canvas.toDataURL("image/jpeg", .82);
}
async function loadSource(file) {
	if (typeof createImageBitmap === "function") try {
		return await createImageBitmap(file);
	} catch {}
	const url = URL.createObjectURL(file);
	try {
		const image = new Image();
		image.decoding = "async";
		const loaded = new Promise((resolve, reject) => {
			image.onload = () => resolve(image);
			image.onerror = () => reject(/* @__PURE__ */ new Error("That image could not be opened."));
		});
		image.src = url;
		return await loaded;
	} finally {
		URL.revokeObjectURL(url);
	}
}
function GamesPage() {
	const games = useAppStore((state) => state.games);
	const selectedId = useAppStore((state) => state.selectedGameId);
	const cardStyle = useAppStore((state) => state.cardStyle);
	const addGame = useAppStore((state) => state.addGame);
	const selectGame = useAppStore((state) => state.selectGame);
	const hash = useRouterState({ select: (state) => state.location.hash });
	const [query, setQuery] = (0, import_react.useState)("");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const id = decodeURIComponent(hash.replace(/^#/, ""));
		if (!id.startsWith("g-")) return;
		const gameId = id.slice(2);
		if (!useAppStore.getState().games.some((game) => game.id === gameId)) return;
		selectGame(gameId);
		setOpenId(gameId);
	}, [hash, selectGame]);
	(0, import_react.useEffect)(() => {
		if (!openId) return;
		document.getElementById(`g-${openId}`)?.scrollIntoView({ block: "start" });
	}, [openId]);
	const filtered = games.filter((game) => game.name.toLowerCase().includes(query.trim().toLowerCase()));
	const open = games.find((game) => game.id === openId) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Library",
				title: "Games",
				subtitle: "Profiles are manual. This app cannot scan installed Android packages or launch a game you did not link."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field-input",
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Filter profiles",
					"aria-label": "Filter profiles"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "shrink-0",
					onClick: () => {
						const id = addGame("New game");
						setOpenId(id);
						setQuery("");
					},
					children: "Add game"
				})]
			}),
			games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "No games yet",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Add a game by name. Where Winds Meet can be one of them. Icons and links are optional."
				})
			}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "No matches",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Nothing in the library matches that filter."
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "stack",
				children: filtered.map((game) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameCard, {
					game,
					selected: game.id === selectedId,
					poster: cardStyle === "poster",
					onOpen: () => {
						selectGame(game.id);
						setOpenId(game.id);
					}
				}) }, game.id))
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameEditor, {
				game: open,
				onClose: () => setOpenId(null)
			}) : null
		]
	});
}
function GameCard({ game, selected, poster, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: poster ? "surface overflow-hidden" : "surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onOpen,
			className: poster ? "block w-full text-left" : "flex w-full items-center gap-3 p-3 text-left",
			children: [poster ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative h-28 bg-surface-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
					name: game.name,
					image: game.image,
					poster: true
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
				name: game.name,
				image: game.image
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: poster ? "p-4" : "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "truncate font-display text-xl font-semibold",
						children: game.name
					}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 text-xs font-semibold tracking-widest text-ok uppercase",
						children: "Selected"
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Target ",
						game.fpsTarget,
						" · ",
						presetLabel(game.preset),
						" · Shadows ",
						detailLabel(game.shadows)
					]
				})]
			})]
		})
	});
}
function Mark({ name, image, poster = false }) {
	if (image) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: image,
		alt: "",
		className: poster ? "media-frame h-full w-full object-cover" : "media-frame size-14 shrink-0 rounded-lg object-cover"
	});
	const letter = name.trim().slice(0, 1).toUpperCase() || "?";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: poster ? "grid h-full place-items-center font-display text-4xl text-primary" : "grid size-14 shrink-0 place-items-center rounded-lg bg-surface-2 font-display text-xl text-primary",
		"aria-hidden": "true",
		children: letter
	});
}
function GameEditor({ game, onClose }) {
	const updateGame = useAppStore((state) => state.updateGame);
	const removeGame = useAppStore((state) => state.removeGame);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [imageError, setImageError] = (0, import_react.useState)(null);
	const launch = safeLaunchUrl(game.launchUrl);
	async function onFile(file) {
		if (!file) return;
		try {
			const image = await imageFileToDataUrl(file);
			updateGame(game.id, { image });
			setImageError(null);
		} catch (error) {
			setImageError(error instanceof Error ? error.message : "Could not use that image.");
		}
	}
	function applyPreset(preset) {
		if (preset === "custom") {
			updateGame(game.id, { preset: "custom" });
			return;
		}
		updateGame(game.id, {
			preset,
			...visualsForPreset(preset, game.fpsTarget)
		});
	}
	function applyGraphics(level) {
		if (level === "custom") {
			updateGame(game.id, {
				graphics: "custom",
				preset: "custom"
			});
			return;
		}
		updateGame(game.id, {
			preset: "custom",
			...visualsForGraphics(level)
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		id: `g-${game.id}`,
		title: game.name,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field-input",
						value: game.name,
						maxLength: 60,
						onChange: (event) => updateGame(game.id, { name: event.target.value.slice(0, 60) || game.name })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Icon",
					hint: "Stored on this device as a small image. Optional.",
					error: imageError,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
								name: game.name,
								image: game.image
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex min-h-11 items-center gap-2 rounded-lg bg-surface-2 px-4 text-sm font-semibold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
										className: "size-4",
										"aria-hidden": "true"
									}),
									"Add icon",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "sr-only",
										type: "file",
										accept: "image/*",
										onChange: (event) => {
											onFile(event.target.files?.[0]);
											event.target.value = "";
										}
									})
								]
							}),
							game.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => updateGame(game.id, { image: null }),
								children: "Remove"
							}) : null
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Launch link",
					hint: "http(s) or an app link you already have. Javascript links are blocked.",
					error: game.launchUrl.trim() && !launch ? "That link cannot be opened." : null,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field-input",
						value: game.launchUrl,
						maxLength: 500,
						placeholder: "https:// or yourgame://",
						onChange: (event) => updateGame(game.id, { launchUrl: event.target.value })
					})
				}),
				launch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-primary",
					href: launch,
					target: "_blank",
					rel: "noopener noreferrer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Open link"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-faint",
					children: "Add a link to enable launch. Installed apps are not scanned."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-2 text-sm font-semibold",
						children: "Target FPS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm text-muted",
						children: "Targets, not guaranteed frame rates."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: FPS_TARGETS.map((target) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": game.fpsTarget === target,
							className: `min-h-11 min-w-11 rounded-lg px-3 text-sm font-semibold tabular-nums ${game.fpsTarget === target ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`,
							onClick: () => updateGame(game.id, { fpsTarget: target }),
							children: target
						}, target))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Performance preset",
					hint: "Writes recommended settings onto this profile. You still change them in the game.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": game.preset === preset,
							className: `min-h-11 rounded-lg px-3 text-sm font-semibold ${game.preset === preset ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`,
							onClick: () => applyPreset(preset),
							children: presetLabel(preset)
						}, preset))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Graphics bundle",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field-input",
						value: game.graphics,
						onChange: (event) => applyGraphics(event.target.value),
						children: GRAPHICS.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: level,
							children: graphicsLabel(level)
						}, level))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Resolution scale",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field-input",
								value: game.resolutionScale,
								onChange: (event) => updateGame(game.id, {
									resolutionScale: event.target.value,
									preset: "custom",
									graphics: "custom"
								}),
								children: SCALE.map((scale) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: scale,
									children: scaleLabel(scale)
								}, scale))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Shadows",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field-input",
								value: game.shadows,
								onChange: (event) => updateGame(game.id, {
									shadows: event.target.value,
									preset: "custom",
									graphics: "custom"
								}),
								children: DETAIL.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: level,
									children: detailLabel(level)
								}, level))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Effects",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field-input",
								value: game.effects,
								onChange: (event) => updateGame(game.id, {
									effects: event.target.value,
									preset: "custom",
									graphics: "custom"
								}),
								children: DETAIL.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: level,
									children: detailLabel(level)
								}, level))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Anti-aliasing",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field-input",
								value: game.aa,
								onChange: (event) => updateGame(game.id, {
									aa: event.target.value,
									preset: "custom",
									graphics: "custom"
								}),
								children: AA.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: level,
									children: aaLabel(level)
								}, level))
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "VSync note",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field-input",
						value: game.vsync,
						onChange: (event) => updateGame(game.id, {
							vsync: event.target.value === "off" ? "off" : "on",
							preset: "custom",
							graphics: "custom"
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "on",
							children: "On"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "off",
							children: "Off"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notes",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field-input min-h-28",
						maxLength: 2e3,
						value: game.notes,
						onChange: (event) => updateGame(game.id, { notes: event.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Changes save on this device as you edit." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: onClose,
						children: "Close editor"
					}), confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => {
							removeGame(game.id);
							onClose();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Confirm delete"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => setConfirmDelete(true),
						children: "Delete profile"
					})]
				})
			]
		})
	});
}
var SplitComponent = GamesPage;
//#endregion
export { SplitComponent as component };
