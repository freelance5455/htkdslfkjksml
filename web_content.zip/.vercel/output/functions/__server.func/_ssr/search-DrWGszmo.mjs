import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Search } from "../_libs/lucide-react.mjs";
import { t as BackButton } from "./back-button-DImimZOp.mjs";
import { c as normalizeArabic, r as TopBar, t as AppShell } from "./app-shell-C4IrQdCN.mjs";
import { o as libraryBooks, r as adhkarLists, s as loadQuran, u as quranMeta } from "./catalog-CjAfWU9w.mjs";
import { t as TextLink } from "./text-link-CJNQ8wl3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-DrWGszmo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function clip(text, q) {
	const i = normalizeArabic(text).indexOf(q);
	if (i < 0) return text.slice(0, 110);
	const start = Math.max(0, i - 24);
	return (start > 0 ? "…" : "") + text.slice(start, start + 140);
}
async function searchAll(query) {
	const q = normalizeArabic(query);
	if (q.length < 2) return [];
	const hits = [];
	const quran = await loadQuran();
	for (const s of quran) {
		for (const a of s.ayahs) if (normalizeArabic(a.t).includes(q)) {
			hits.push({
				id: `q-${s.id}-${a.n}`,
				source: "quran",
				sourceLabel: "القرآن الكريم",
				title: `${s.name} — آية ${a.n}`,
				snippet: a.t,
				href: `/quran/${s.id}?ayah=${a.n}`
			});
			if (hits.filter((h) => h.source === "quran").length >= 20) break;
		}
		if (hits.filter((h) => h.source === "quran").length >= 20) break;
	}
	for (const list of adhkarLists) for (const item of list.items) if (normalizeArabic(item.text + " " + item.title).includes(q)) hits.push({
		id: item.id,
		source: list.kind === "dua" ? "dua" : "adhkar",
		sourceLabel: list.kind === "dua" ? "الأدعية" : "الأذكار",
		title: list.title,
		snippet: clip(item.text, q),
		href: `/adhkar/${list.id}#${item.id}`
	});
	for (const book of libraryBooks) {
		if (book.comingSoon) continue;
		const kind = book.category === "hadith" ? "hadith" : "mutn";
		const label = book.category === "hadith" ? "الحديث" : "المكتبة";
		for (const sec of book.sections) if (normalizeArabic(sec.title + " " + sec.body).includes(q)) hits.push({
			id: `${book.id}:${sec.id}`,
			source: kind,
			sourceLabel: label,
			title: `${book.title} — ${sec.title}`,
			snippet: clip(sec.body, q),
			href: `/library/${book.id}?section=${sec.id}`
		});
	}
	for (const s of quranMeta.surahs) if (normalizeArabic(s.name + s.shortName + s.englishName).includes(q)) hits.unshift({
		id: `sura-${s.id}`,
		source: "quran",
		sourceLabel: "القرآن الكريم",
		title: s.name,
		snippet: `${s.type} · ${s.count} آية`,
		href: `/quran/${s.id}`
	});
	return hits.slice(0, 80);
}
var FILTERS = [
	{
		id: "all",
		label: "الكل"
	},
	{
		id: "quran",
		label: "القرآن"
	},
	{
		id: "adhkar",
		label: "الأذكار"
	},
	{
		id: "dua",
		label: "الأدعية"
	},
	{
		id: "hadith",
		label: "الحديث"
	},
	{
		id: "mutn",
		label: "المتون"
	}
];
function SearchPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)([]);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (q.trim().length < 2) {
			setHits([]);
			return;
		}
		setLoading(true);
		const t = window.setTimeout(() => {
			searchAll(q).then((r) => {
				setHits(r);
				setLoading(false);
			});
		}, 180);
		return () => window.clearTimeout(t);
	}, [q]);
	const shown = (0, import_react.useMemo)(() => filter === "all" ? hits : hits.filter((h) => h.source === filter), [hits, filter]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: "البحث",
			back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 rounded-2xl bg-card px-3 py-2 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "ابحث في القرآن والأذكار والمتون",
					className: "h-10 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1 overflow-x-auto pb-1",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(f.id),
					className: `h-9 shrink-0 rounded-full px-3 text-xs ${filter === f.id ? "bg-accent text-accent-foreground" : "bg-surface text-muted-foreground"}`,
					children: f.label
				}, f.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 py-3",
			children: [
				loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-muted-foreground",
					children: "جارٍ البحث…"
				}) : null,
				!loading && q.trim().length >= 2 && shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-muted-foreground",
					children: "لا نتائج"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: shown.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TextLink, {
						href: h.href,
						className: "block rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-sage",
								children: h.sourceLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-medium",
								children: h.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 line-clamp-3 text-sm leading-7 text-muted-foreground",
								children: h.snippet
							})
						]
					}) }, h.id))
				})
			]
		})
	] });
}
//#endregion
export { SearchPage as component };
