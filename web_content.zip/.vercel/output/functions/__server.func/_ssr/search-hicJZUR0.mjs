import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Route$5 } from "./router-B6lWlm2d.mjs";
import { T as searchUsers, m as fieldClass, s as RolePill, t as Avatar } from "./auth-screens-DZe0plYT.mjs";
import { t as Shell$1 } from "./shell-DSe4icyb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-hicJZUR0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const { q } = Route$5.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBody, { initial: q }) });
}
function SearchBody({ initial }) {
	const [q, setQ] = (0, import_react.useState)(initial);
	const [people, setPeople] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const handle = window.setTimeout(() => {
			searchUsers({ data: { q } }).then((result) => {
				setPeople(result.people);
				setError(null);
			}).catch((err) => setError(err instanceof Error ? err.message : "تعذر البحث"));
		}, 180);
		return () => window.clearTimeout(handle);
	}, [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-rose",
				children: "دليل"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "بحث"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: `${fieldClass} h-12`,
				placeholder: "اسم الحساب",
				value: q,
				dir: "ltr",
				onChange: (e) => setQ(e.target.value),
				autoFocus: true
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-rose",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: (people ?? []).map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/u/$username",
					params: { username: person.username },
					className: "flex min-h-16 items-center gap-3 rounded-3xl bg-paper px-3 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						src: person.avatar,
						name: person.username
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate font-medium",
								children: person.username
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolePill, { role: person.role })]
						}), person.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm text-mute",
							children: person.bio
						}) : null]
					})]
				}) }, person.username))
			}),
			people && !people.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mute",
				children: "لا حسابات بهذا الاسم."
			}) : null
		]
	});
}
//#endregion
export { SearchPage as component };
