import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Smartphone, c as Bluetooth, l as Bell, n as Wifi, o as Shield, r as Usb, s as Radio, t as X, u as BellOff } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-F0DKC3Sb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var timer = 0;
var mode = "off";
var high = false;
function primeAudio() {
	if (typeof window === "undefined") return;
	const Ctx = window.AudioContext;
	if (!Ctx) return;
	if (!ctx) ctx = new Ctx();
	if (ctx.state === "suspended") ctx.resume();
}
function tone(freq, dur, level) {
	if (!ctx || ctx.state !== "running") return;
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = "sine";
	osc.frequency.value = freq;
	gain.gain.value = level;
	osc.connect(gain);
	gain.connect(ctx.destination);
	const t = ctx.currentTime;
	gain.gain.setValueAtTime(level, t);
	gain.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	osc.start(t);
	osc.stop(t + dur + .02);
}
function setAlarm(next) {
	if (next === mode) return;
	mode = next;
	window.clearInterval(timer);
	timer = 0;
	if (next === "off") return;
	const tick = () => {
		if (mode === "siren") {
			high = !high;
			tone(high ? 740 : 494, .26, .045);
			return;
		}
		tone(620, .1, .04);
		window.setTimeout(() => tone(880, .12, .04), 150);
	};
	tick();
	timer = window.setInterval(tick, next === "siren" ? 340 : 1400);
}
var CAM_IDS = [
	"c1",
	"c2",
	"c3",
	"c4",
	"c5",
	"c6"
];
var KIND_LABEL = {
	clear: "آمن",
	flame: "اشتعال",
	smoke: "دخان",
	smoking: "تدخين"
};
var SOURCE_LABEL = {
	rtsp: "واي فاي / RTSP",
	usb: "USB",
	bluetooth: "بلوتوث",
	phone: "جوال"
};
var CAMERA_DEFAULTS = [
	{
		id: "c1",
		name: "كاميرا ١",
		zone: "مدخل السوبرماركت",
		source: "rtsp",
		rtspUrl: "rtsp://192.168.1.21/live",
		btName: "",
		usbLabel: ""
	},
	{
		id: "c2",
		name: "كاميرا ٢",
		zone: "مطبخ المطعم",
		source: "rtsp",
		rtspUrl: "rtsp://192.168.1.22/live",
		btName: "",
		usbLabel: ""
	},
	{
		id: "c3",
		name: "كاميرا ٣",
		zone: "ممر المول",
		source: "rtsp",
		rtspUrl: "rtsp://192.168.1.23/live",
		btName: "",
		usbLabel: ""
	},
	{
		id: "c4",
		name: "كاميرا ٤",
		zone: "المستودع",
		source: "usb",
		rtspUrl: "rtsp://192.168.1.24/live",
		btName: "",
		usbLabel: ""
	},
	{
		id: "c5",
		name: "كاميرا ٥",
		zone: "صالة الجلوس",
		source: "bluetooth",
		rtspUrl: "rtsp://192.168.1.25/live",
		btName: "",
		usbLabel: ""
	},
	{
		id: "c6",
		name: "كاميرا ٦",
		zone: "بث الجوال",
		source: "phone",
		rtspUrl: "",
		btName: "",
		usbLabel: ""
	}
];
var EMPTY_READING = {
	kind: "clear",
	confidence: 0,
	flame: 0,
	smoke: 0
};
function emptyReadings() {
	return {
		c1: { ...EMPTY_READING },
		c2: { ...EMPTY_READING },
		c3: { ...EMPTY_READING },
		c4: { ...EMPTY_READING },
		c5: { ...EMPTY_READING },
		c6: { ...EMPTY_READING }
	};
}
function defaultCameras() {
	const map = {};
	for (const cam of CAMERA_DEFAULTS) map[cam.id] = { ...cam };
	return map;
}
var CLOUD_BUDGET = 4;
function emptyDrills() {
	return {
		c1: null,
		c2: null,
		c3: null,
		c4: null,
		c5: null,
		c6: null
	};
}
function emptyForced() {
	return {
		c1: "clear",
		c2: "clear",
		c3: "clear",
		c4: "clear",
		c5: "clear",
		c6: "clear"
	};
}
function isEmergency(state) {
	if (state.linkOverride === "emergency") return true;
	if (state.linkOverride === "online") return false;
	return !state.browserOnline;
}
var useSafety = create()(persist((set) => ({
	mode: null,
	linkOverride: "auto",
	browserOnline: true,
	muted: false,
	autoDrill: true,
	autoCloud: false,
	leading: false,
	inspector: null,
	cloudBusy: false,
	cloudLeft: CLOUD_BUDGET,
	cameras: defaultCameras(),
	drills: emptyDrills(),
	forced: emptyForced(),
	threats: emptyReadings(),
	incidents: [],
	remoteFrames: {},
	setMode: (mode) => set({ mode }),
	setLink: (linkOverride) => set({ linkOverride }),
	setBrowserOnline: (browserOnline) => set({ browserOnline }),
	setMuted: (muted) => set({ muted }),
	setAutoDrill: (autoDrill) => set({ autoDrill }),
	setAutoCloud: (autoCloud) => set({ autoCloud }),
	setLeading: (leading) => set({ leading }),
	setInspector: (inspector) => set({ inspector }),
	patchCamera: (id, patch) => set((state) => ({ cameras: {
		...state.cameras,
		[id]: {
			...state.cameras[id],
			...patch
		}
	} })),
	setDrill: (id, kind, ms = 22e3) => set((state) => ({ drills: {
		...state.drills,
		[id]: kind === "clear" ? null : {
			kind,
			until: Date.now() + ms
		}
	} })),
	stopDrills: () => set({
		autoDrill: false,
		drills: emptyDrills()
	}),
	setForced: (id, kind) => set((state) => state.forced[id] === kind ? state : { forced: {
		...state.forced,
		[id]: kind
	} }),
	setReading: (id, reading) => set((state) => {
		const prev = state.threats[id];
		if (prev.kind === reading.kind && prev.confidence === reading.confidence && prev.flame === reading.flame && prev.smoke === reading.smoke) return state;
		return { threats: {
			...state.threats,
			[id]: reading
		} };
	}),
	addIncident: (incident) => set((state) => {
		if (state.incidents.some((item) => item.id === incident.id)) return state;
		return { incidents: [incident, ...state.incidents].slice(0, 12) };
	}),
	patchIncident: (id, patch) => set((state) => ({ incidents: state.incidents.map((item) => item.id === id ? {
		...item,
		...patch
	} : item) })),
	setRemoteFrame: (id, jpg, kind, confidence) => set((state) => ({
		remoteFrames: {
			...state.remoteFrames,
			[id]: jpg
		},
		threats: state.leading ? state.threats : {
			...state.threats,
			[id]: {
				kind,
				confidence,
				flame: 0,
				smoke: 0
			}
		}
	})),
	setCloudBusy: (cloudBusy) => set({ cloudBusy }),
	consumeCloud: () => set((state) => ({ cloudLeft: Math.max(0, state.cloudLeft - 1) }))
}), {
	name: "dera-aman",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		mode: state.mode,
		linkOverride: state.linkOverride,
		muted: state.muted,
		autoDrill: state.autoDrill,
		autoCloud: state.autoCloud,
		cameras: state.cameras,
		incidents: state.incidents.slice(0, 6).map((item) => ({
			...item,
			snapshot: item.snapshot.length > 9e4 ? "" : item.snapshot
		}))
	})
}));
function choose(mode) {
	primeAudio();
	useSafety.getState().setMode(mode);
}
function BootScreen({ ready }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col justify-center gap-8 px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-14 items-center justify-center rounded-lg border border-border bg-surface text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
						className: "size-7",
						strokeWidth: 1.5,
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "سلامة المتاجر والصالات والمنازل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-medium tracking-tight text-balance",
					children: "درع الأمان"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-pretty text-muted",
				children: "ست قنوات على شاشة واحدة. المحلل المحلي يقرأ اللهب والدخان وجمرة التدخين من الصورة نفسها، ويبقى يعمل إذا انقطع الاتصال. عند توفر الشبكة يمكن تأكيد الحدث سحابياً بلقطة واحدة."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeCard, {
					ready,
					title: "المركز المحلي",
					body: "لجهاز الموقع أو الجهاز اللوحي. شبكة ٢×٣، ومصادر RTSP وUSB وبلوتوث، وإنذار في المكان.",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
						className: "size-5",
						"aria-hidden": "true"
					}),
					onClick: () => choose("hub"),
					testId: "boot-hub"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeCard, {
					ready,
					title: "المراقبة البعيدة",
					body: "لهاتفك. متابعة اللقطات، تنبيه حرج، وتأكيد الأحداث حتى لو كان المركز في نافذة أخرى.",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
						className: "size-5",
						"aria-hidden": "true"
					}),
					onClick: () => choose("viewer"),
					testId: "boot-viewer"
				})]
			})
		]
	});
}
function ModeCard({ title, body, icon, onClick, ready, testId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"data-testid": testId,
		disabled: !ready,
		onClick,
		className: "press flex flex-col gap-4 rounded-xl border border-border bg-surface p-4 text-start disabled:opacity-60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-10 items-center justify-center rounded-sm bg-elevated text-fg",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-lg font-medium",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-sm text-pretty text-muted",
			children: body
		})] })]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var confirmThreat = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("4ce10131cf00d94a88323bf8acd07852f96b9badcf9e15ce3b998bb055755e6c"));
async function runCloud(incidentId) {
	const state = useSafety.getState();
	const incident = state.incidents.find((item) => item.id === incidentId);
	if (!incident || incident.cloud || state.cloudBusy) return;
	if (isEmergency(state)) {
		state.patchIncident(incidentId, { cloud: { error: "وضع الطوارئ: التحليل المحلي فقط" } });
		return;
	}
	if (state.cloudLeft <= 0) {
		state.patchIncident(incidentId, { cloud: { error: "استُهلك حد التأكيدات في هذه الجلسة" } });
		return;
	}
	if (!incident.snapshot.startsWith("data:image/")) {
		state.patchIncident(incidentId, { cloud: { error: "لا توجد لقطة صالحة لهذا الحدث" } });
		return;
	}
	state.setCloudBusy(true);
	state.consumeCloud();
	try {
		const result = await confirmThreat({ data: {
			image: incident.snapshot,
			hint: incident.kind
		} });
		if (!result.ok || !result.kind) {
			useSafety.getState().patchIncident(incidentId, { cloud: { error: result.error ?? "تعذّر التأكيد" } });
			return;
		}
		useSafety.getState().patchIncident(incidentId, { cloud: {
			kind: result.kind,
			confidence: result.confidence ?? 0,
			note: result.note ?? ""
		} });
	} catch {
		useSafety.getState().patchIncident(incidentId, { cloud: { error: "تعذّر الاتصال بالتأكيد السحابي" } });
	} finally {
		useSafety.getState().setCloudBusy(false);
	}
}
var STEP = 2;
function isFlame(r, g, b) {
	return r > 165 && g > 45 && g < 215 && b < 100 && r > g + 25 && g > b + 8;
}
function isSmoke(r, g, b) {
	const max = r > g ? r > b ? r : b : g > b ? g : b;
	const min = r < g ? r < b ? r : b : g < b ? g : b;
	const lum = (r + g + b) / 3;
	return max - min < 26 && lum > 100 && lum < 176;
}
function clamp01(n) {
	if (n < 0) return 0;
	if (n > 1) return 1;
	return n;
}
/** Classifies a frame from pixel evidence. Counts are sampled every other pixel. */
function analyzeFrame(data, width, height) {
	let flame = 0;
	let smoke = 0;
	let minX = width;
	let minY = height;
	let maxX = 0;
	let maxY = 0;
	for (let y = 0; y < height; y += STEP) {
		const row = y * width;
		for (let x = 0; x < width; x += STEP) {
			const i = (row + x) * 4;
			const r = data[i] ?? 0;
			const g = data[i + 1] ?? 0;
			const b = data[i + 2] ?? 0;
			if (isFlame(r, g, b)) {
				flame += 1;
				if (x < minX) minX = x;
				if (y < minY) minY = y;
				if (x > maxX) maxX = x;
				if (y > maxY) maxY = y;
			} else if (isSmoke(r, g, b)) smoke += 1;
		}
	}
	const bw = flame > 0 ? maxX - minX : 0;
	const bh = flame > 0 ? maxY - minY : 0;
	const compact = flame >= 4 && flame <= 150 && Math.max(bw, bh) <= 64;
	let nearSmoke = 0;
	if (compact) {
		const x0 = Math.max(0, minX - 40);
		const y0 = Math.max(0, minY - 80);
		const x1 = Math.min(width - 1, maxX + 40);
		const y1 = Math.min(height - 1, maxY + 28);
		for (let y = y0; y <= y1; y += STEP) {
			const row = y * width;
			for (let x = x0; x <= x1; x += STEP) {
				const i = (row + x) * 4;
				if (isSmoke(data[i] ?? 0, data[i + 1] ?? 0, data[i + 2] ?? 0)) nearSmoke += 1;
			}
		}
	}
	if (flame > 180 && bw > 26 && bh > 26) return {
		kind: "flame",
		confidence: clamp01(flame / 700),
		flame,
		smoke
	};
	if (compact && nearSmoke > 18) return {
		kind: "smoking",
		confidence: clamp01(.55 + nearSmoke / 400),
		flame,
		smoke
	};
	if (smoke > 650) return {
		kind: "smoke",
		confidence: clamp01(smoke / 2200),
		flame,
		smoke
	};
	return {
		kind: "clear",
		confidence: 0,
		flame,
		smoke
	};
}
var listeners = /* @__PURE__ */ new Set();
function emit() {
	for (const listener of listeners) listener();
}
function onLiveChange(listener) {
	listeners.add(listener);
	return () => {
		listeners.delete(listener);
	};
}
var live = /* @__PURE__ */ new Map();
function liveVideo(id) {
	const row = live.get(id);
	if (!row || row.video.readyState < 2) return null;
	return row.video;
}
function hasLive(id) {
	return live.has(id);
}
function detachLive(id) {
	const row = live.get(id);
	if (!row) return;
	for (const track of row.stream.getTracks()) track.stop();
	row.video.srcObject = null;
	live.delete(id);
	emit();
}
async function attachLive(id, constraints) {
	detachLive(id);
	const stream = await navigator.mediaDevices.getUserMedia(constraints);
	const video = document.createElement("video");
	video.muted = true;
	video.playsInline = true;
	video.srcObject = stream;
	await video.play();
	live.set(id, {
		stream,
		video
	});
	emit();
}
async function listVideoInputs() {
	return (await navigator.mediaDevices.enumerateDevices()).filter((device) => device.kind === "videoinput");
}
function alertsSupported() {
	return typeof window !== "undefined" && "Notification" in window;
}
async function requestAlerts() {
	if (!alertsSupported()) return "unsupported";
	return await Notification.requestPermission() === "granted" ? "granted" : "denied";
}
function pushCritical(title, body) {
	if (!alertsSupported() || Notification.permission !== "granted") return;
	try {
		new Notification(title, {
			body,
			tag: "dera-aman-critical"
		});
	} catch {}
}
var INK = "#1a1e1c";
var WALL = "#2a312e";
var FLOOR = "#232826";
var WOOD = "#6b5344";
var WOOD_DARK = "#4e3b30";
var CLOTH = "#1c2836";
var SKIN = "#c4a48a";
var STEEL = "#3a4144";
var GLASS = "#1d333c";
var SEED = {
	c1: .4,
	c2: 1.1,
	c3: 1.7,
	c4: 2.2,
	c5: .2,
	c6: 2.4
};
var FEET = {
	c1: 230,
	c2: 228,
	c3: 236,
	c4: 240,
	c5: 232,
	c6: 242
};
function personX(now, seed) {
	return 48 + (Math.sin(now / 1600 + seed) + 1) / 2 * 384;
}
function actor(id, now) {
	return {
		x: personX(now, SEED[id]),
		feet: FEET[id]
	};
}
function fillRect(ctx, x, y, w, h, color) {
	ctx.fillStyle = color;
	ctx.fillRect(x, y, w, h);
}
function ellipse(ctx, x, y, rx, ry, color) {
	ctx.fillStyle = color;
	ctx.beginPath();
	ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
	ctx.fill();
}
function drawPerson(ctx, x, feet) {
	fillRect(ctx, x - 8, feet - 46, 16, 32, CLOTH);
	ellipse(ctx, x, feet - 56, 8, 8, SKIN);
}
function drawRoom(ctx, id, now) {
	fillRect(ctx, 0, 0, 480, 270, INK);
	fillRect(ctx, 0, 0, 480, 118, WALL);
	fillRect(ctx, 0, 118, 480, 152, FLOOR);
	fillRect(ctx, 0, 114, 480, 4, "#343c38");
	const px = actor(id, now).x;
	if (id === "c1") {
		for (const x of [
			36,
			168,
			300
		]) {
			fillRect(ctx, x, 78, 26, 150, WOOD);
			fillRect(ctx, x - 10, 86, 46, 8, WOOD_DARK);
			fillRect(ctx, x - 10, 124, 46, 8, "#8c3030");
			fillRect(ctx, x - 10, 160, 46, 8, "#2a4068");
		}
		drawPerson(ctx, px, 230);
	} else if (id === "c2") {
		fillRect(ctx, 24, 132, 430, 28, STEEL);
		fillRect(ctx, 150, 146, 78, 46, "#2a2e30");
		fillRect(ctx, 164, 158, 50, 8, "#4a4038");
		fillRect(ctx, 40, 36, 120, 18, STEEL);
		fillRect(ctx, 300, 70, 90, 70, "#243028");
		drawPerson(ctx, px, 228);
	} else if (id === "c3") {
		fillRect(ctx, 18, 48, 70, 90, GLASS);
		fillRect(ctx, 392, 48, 70, 90, GLASS);
		fillRect(ctx, 110, 70, 260, 8, "#3c4440");
		ellipse(ctx, 160, 28, 10, 6, "#d7ded8");
		ellipse(ctx, 320, 28, 10, 6, "#d7ded8");
		drawPerson(ctx, px, 236);
	} else if (id === "c4") {
		fillRect(ctx, 30, 64, 180, 12, WOOD_DARK);
		fillRect(ctx, 30, 100, 180, 12, WOOD_DARK);
		fillRect(ctx, 48, 76, 36, 24, WOOD);
		fillRect(ctx, 100, 76, 36, 24, "#5c4632");
		fillRect(ctx, 280, 80, 150, 110, "#3d342c");
		fillRect(ctx, 300, 100, 40, 30, WOOD);
		drawPerson(ctx, px, 240);
	} else if (id === "c5") {
		fillRect(ctx, 40, 150, 170, 48, "#243044");
		fillRect(ctx, 48, 138, 150, 18, "#2c3c52");
		fillRect(ctx, 250, 168, 90, 14, WOOD);
		ellipse(ctx, 400, 70, 16, 10, "#efe6d4");
		fillRect(ctx, 392, 80, 8, 70, WOOD_DARK);
		fillRect(ctx, 300, 36, 70, 50, GLASS);
		drawPerson(ctx, px, 232);
	} else {
		fillRect(ctx, 70, 40, 340, 150, "#202624");
		fillRect(ctx, 200, 70, 80, 120, "#2c3330");
		ellipse(ctx, 240, 24, 8, 5, "#d7ded8");
		drawPerson(ctx, px, 242);
	}
}
function paintFlame(ctx, x, y, now) {
	const flick = .9 + Math.sin(now / 70) * .1;
	ellipse(ctx, x, y + 8, 34 * flick, 48 * flick, "#e25a12");
	ellipse(ctx, x + 16, y + 16, 18, 28, "#d04a10");
	ellipse(ctx, x, y + 18, 16 * flick, 26 * flick, "#ffb428");
	ellipse(ctx, x, y + 26, 6, 8, "#ffe7a0");
}
function paintSmoke(ctx, x, y, now) {
	const rise = (Math.sin(now / 500) + 1) * 8;
	ellipse(ctx, x, y + 30 - rise, 54, 28, "#6e736f");
	ellipse(ctx, x + 24, y + 8 - rise, 46, 26, "#8a8f8b");
	ellipse(ctx, x - 18, y - 16 - rise, 40, 22, "#9a9e99");
	ellipse(ctx, x + 10, y - 36 - rise, 28, 16, "#8e938e");
}
function paintSmoking(ctx, x, feet, now) {
	const mouthX = x + 6;
	const mouthY = feet - 52;
	const drift = Math.sin(now / 400) * 4;
	ellipse(ctx, mouthX + 2, mouthY - 28 - drift, 16, 26, "#8a8f8b");
	ellipse(ctx, mouthX + 6, mouthY - 48 - drift, 12, 14, "#9a9e99");
	ellipse(ctx, mouthX, mouthY, 5.5, 5.5, "#ff9a1e");
}
var FLAME_ANCHOR = {
	c1: {
		x: 250,
		y: 150
	},
	c2: {
		x: 188,
		y: 132
	},
	c3: {
		x: 240,
		y: 150
	},
	c4: {
		x: 120,
		y: 150
	},
	c5: {
		x: 300,
		y: 150
	},
	c6: {
		x: 240,
		y: 150
	}
};
var SMOKE_ANCHOR = {
	c1: {
		x: 240,
		y: 70
	},
	c2: {
		x: 188,
		y: 70
	},
	c3: {
		x: 240,
		y: 64
	},
	c4: {
		x: 150,
		y: 60
	},
	c5: {
		x: 200,
		y: 64
	},
	c6: {
		x: 240,
		y: 60
	}
};
function drawChannel(ctx, id, now, scenario, video) {
	ctx.imageSmoothingEnabled = true;
	if (video && video.readyState >= 2) ctx.drawImage(video, 0, 0, 480, 270);
	else drawRoom(ctx, id, now);
	if (scenario === "flame") {
		const a = FLAME_ANCHOR[id];
		paintFlame(ctx, a.x, a.y, now);
	} else if (scenario === "smoke") {
		const a = SMOKE_ANCHOR[id];
		paintSmoke(ctx, a.x, a.y, now);
	} else if (scenario === "smoking") {
		const body = actor(id, now);
		paintSmoking(ctx, body.x, body.feet, now);
	}
}
var CHANNEL = "dera-aman-v1";
var channel = null;
function bus() {
	if (typeof BroadcastChannel === "undefined") return null;
	if (!channel) channel = new BroadcastChannel(CHANNEL);
	return channel;
}
function publishRelay(msg) {
	bus()?.postMessage(msg);
}
function subscribeRelay(onMessage) {
	const current = bus();
	if (!current) return () => {};
	const handler = (event) => onMessage(event.data);
	current.addEventListener("message", handler);
	return () => current.removeEventListener("message", handler);
}
var canvases = /* @__PURE__ */ new Map();
var streak = /* @__PURE__ */ new Map();
var stable = /* @__PURE__ */ new Map();
var shown = /* @__PURE__ */ new Map();
var raf = 0;
var running = false;
var startedAt = 0;
var lastRender = 0;
var cursor = 0;
var relayCursor = 0;
var lastRelay = 0;
function registerCanvas(id, canvas) {
	canvas.width = 480;
	canvas.height = 270;
	canvases.set(id, canvas);
}
function unregisterCanvas(id, canvas) {
	if (canvases.get(id) === canvas) canvases.delete(id);
}
function scenarioFor(id, wall) {
	const state = useSafety.getState();
	const drill = state.drills[id];
	if (drill && drill.until > wall) return drill.kind;
	if (!state.autoDrill || hasLive(id)) return "clear";
	const phase = (wall - startedAt) % 72e3;
	if (id === "c2" && phase > 7e3 && phase < 2e4) return "flame";
	if (id === "c5" && phase > 26e3 && phase < 39e3) return "smoke";
	if (id === "c1" && phase > 45e3 && phase < 56e3) return "smoking";
	return "clear";
}
function debounce(id, kind) {
	const prev = streak.get(id);
	if (!prev || prev.kind !== kind) streak.set(id, {
		kind,
		n: 1
	});
	else prev.n += 1;
	if ((streak.get(id)?.n ?? 1) >= (kind === "clear" ? 4 : 2)) stable.set(id, kind);
	return stable.get(id) ?? "clear";
}
function raiseIncident(id, kind, confidence, scenario, canvas) {
	if (kind === (shown.get(id) ?? "clear")) return;
	shown.set(id, kind);
	if (kind === "clear") return;
	let snapshot = "";
	try {
		snapshot = canvas.toDataURL("image/jpeg", .62);
	} catch {
		snapshot = "";
	}
	const incident = {
		id: crypto.randomUUID(),
		camId: id,
		kind,
		confidence,
		at: Date.now(),
		snapshot,
		origin: scenario === "clear" ? "sensor" : "drill"
	};
	const state = useSafety.getState();
	state.addIncident(incident);
	publishRelay({
		type: "incident",
		incident
	});
	const hidden = typeof document !== "undefined" && document.hidden;
	if ((state.mode === "viewer" || hidden) && !state.muted) {
		const cam = state.cameras[id];
		pushCritical(`درع الأمان — ${KIND_LABEL[kind]}`, `${cam.zone} · ثقة ${Math.round(confidence * 100)}٪`);
	}
	if (state.autoCloud && !isEmergency(state)) runCloud(incident.id);
}
function tick(now) {
	const wall = Date.now();
	for (const id of CAM_IDS) {
		const canvas = canvases.get(id);
		if (!canvas) continue;
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		if (!ctx) continue;
		const scenario = scenarioFor(id, wall);
		useSafety.getState().setForced(id, scenario);
		drawChannel(ctx, id, now, scenario, liveVideo(id));
	}
	const id = CAM_IDS[cursor % CAM_IDS.length] ?? "c1";
	cursor += 1;
	const canvas = canvases.get(id);
	if (canvas) {
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		if (ctx) {
			const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
			const det = analyzeFrame(image.data, image.width, image.height);
			const kind = debounce(id, det.kind);
			const confidence = Math.round((kind === "clear" ? 0 : det.confidence) * 100) / 100;
			useSafety.getState().setReading(id, {
				kind,
				confidence,
				flame: det.flame,
				smoke: det.smoke
			});
			raiseIncident(id, kind, confidence, scenarioFor(id, wall), canvas);
		}
	}
	const state = useSafety.getState();
	setAlarm(!CAM_IDS.some((camId) => state.threats[camId].kind !== "clear") || state.muted ? "off" : state.mode === "viewer" ? "pulse" : "siren");
	if (now - lastRelay > 450) {
		lastRelay = now;
		const rid = CAM_IDS[relayCursor % CAM_IDS.length] ?? "c1";
		relayCursor += 1;
		const relayCanvas = canvases.get(rid);
		if (relayCanvas) {
			const reading = useSafety.getState().threats[rid];
			try {
				publishRelay({
					type: "frame",
					id: rid,
					jpg: relayCanvas.toDataURL("image/jpeg", .42),
					kind: reading.kind,
					confidence: reading.confidence
				});
			} catch {}
		}
	}
}
function loop(now) {
	if (!running) return;
	raf = requestAnimationFrame(loop);
	if (now - lastRender < 50) return;
	lastRender = now;
	tick(now);
}
function startEngine() {
	if (running || typeof window === "undefined") return;
	running = true;
	startedAt = Date.now();
	lastRender = 0;
	useSafety.getState().setLeading(true);
	raf = requestAnimationFrame(loop);
}
function stopEngine() {
	running = false;
	cancelAnimationFrame(raf);
	streak.clear();
	stable.clear();
	shown.clear();
	setAlarm("off");
	if (typeof window !== "undefined") useSafety.getState().setLeading(false);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function CameraTile({ id }) {
	const canvasRef = (0, import_react.useRef)(null);
	const camera = useSafety((state) => state.cameras[id]);
	const reading = useSafety((state) => state.threats[id]);
	const forced = useSafety((state) => state.forced[id]);
	const leading = useSafety((state) => state.leading);
	const remote = useSafety((state) => state.remoteFrames[id]);
	const selected = useSafety((state) => state.inspector === id);
	const setInspector = useSafety((state) => state.setInspector);
	const [live, setLive] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		registerCanvas(id, canvas);
		return () => unregisterCanvas(id, canvas);
	}, [id]);
	(0, import_react.useEffect)(() => onLiveChange(() => setLive(hasLive(id))), [id]);
	const alert = reading.kind !== "clear";
	const detail = camera.source === "rtsp" ? camera.rtspUrl || "بدون عنوان" : camera.source === "bluetooth" ? camera.btName || "غير مقترن" : camera.source === "usb" ? camera.usbLabel || "غير متصل" : live ? "كاميرا الجهاز" : "محاكاة الدورية";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		"data-testid": `cam-${id}`,
		"data-kind": reading.kind,
		"data-flame": reading.flame,
		"data-smoke": reading.smoke,
		"data-scenario": forced,
		className: cn("flex min-w-0 flex-col gap-2 rounded-xl border border-border bg-surface p-2", alert && "is-alert", selected && "outline outline-1 outline-fg"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-2 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "truncate text-sm font-medium",
						children: camera.zone
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted",
						children: camera.name
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 rounded-sm bg-elevated px-2 py-1 text-sm text-muted",
					children: SOURCE_LABEL[camera.source]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "press relative aspect-video overflow-hidden rounded-lg bg-bg text-start",
				onClick: () => setInspector(id),
				"aria-label": `إعداد ${camera.zone}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: canvasRef,
						className: cn("feed h-full w-full object-cover", !leading && "opacity-0")
					}),
					!leading && remote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: remote,
						alt: "",
						className: "feed absolute inset-0 h-full w-full object-cover"
					}) : null,
					!leading && !remote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute inset-0 flex items-center justify-center text-sm text-subtle",
						children: "لا توجد إشارة"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "feed-mask absolute inset-0" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute start-2 top-2 flex items-center gap-1 font-mono text-sm text-fg",
						dir: "ltr",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", alert ? "bg-alarm" : "bg-ok") }), alert ? "REC" : "LIVE"]
					}),
					alert ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute bottom-2 start-2 rounded-sm bg-alarm px-2 py-1 text-sm font-medium text-alarm-fg",
						children: [
							KIND_LABEL[reading.kind],
							" · ",
							Math.round(reading.confidence * 100),
							"٪"
						]
					}) : null,
					forced !== "clear" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute bottom-2 end-2 rounded-sm bg-bg/80 px-2 py-1 text-sm text-fg",
						children: "تدريب"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate px-1 font-mono text-sm text-subtle",
				dir: "ltr",
				children: detail
			})
		]
	});
}
var STYLES = {
	primary: "bg-fg text-bg",
	quiet: "border border-border bg-elevated text-fg",
	alarm: "bg-alarm text-alarm-fg",
	ghost: "text-fg"
};
function Button({ variant = "quiet", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium press disabled:cursor-not-allowed disabled:opacity-40", STYLES[variant], className),
		...props
	});
}
function isVerdict(cloud) {
	return Boolean(cloud && "kind" in cloud);
}
function IncidentDock() {
	const incidents = useSafety((state) => state.incidents);
	const cameras = useSafety((state) => state.cameras);
	const cloudBusy = useSafety((state) => state.cloudBusy);
	const cloudLeft = useSafety((state) => state.cloudLeft);
	const emergency = useSafety(isEmergency);
	const mode = useSafety((state) => state.mode);
	const leading = useSafety((state) => state.leading);
	const setDrill = useSafety((state) => state.setDrill);
	const stopDrills = useSafety((state) => state.stopDrills);
	const latest = incidents[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex max-h-72 min-h-0 flex-col border-t border-border bg-bg lg:max-h-none lg:w-80 lg:shrink-0 lg:border-s lg:border-t-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 border-b border-border px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "سجل الأحداث"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-sm tabular-nums text-muted",
					dir: "ltr",
					children: [cloudLeft, " تأكيد"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				role: "status",
				"aria-live": "assertive",
				children: latest ? `${KIND_LABEL[latest.kind]} في ${cameras[latest.camId].zone}` : "لا تنبيهات"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2 border-b border-border p-3",
				children: mode === "hub" || leading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						"data-testid": "quick-flame",
						variant: "alarm",
						onClick: () => setDrill("c2", "flame"),
						children: "اشتعال المطبخ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						"data-testid": "quick-smoke",
						onClick: () => setDrill("c5", "smoke"),
						children: "دخان الصالة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						"data-testid": "quick-smoking",
						onClick: () => setDrill("c1", "smoking"),
						children: "تدخين المدخل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: stopDrills,
						children: "إيقاف التدريب"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "التدريب يُشغَّل من المركز المحلي."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-h-0 flex-1 flex-col gap-3 overflow-auto p-3",
				children: incidents.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-pretty text-muted",
					children: "لا أحداث بعد. التدريب يحقن الخطر في البكسلات، والإنذار لا يُطلق إلا إذا رصده المحلل."
				}) : incidents.map((incident) => {
					const verdict = isVerdict(incident.cloud) ? incident.cloud : null;
					const error = incident.cloud && "error" in incident.cloud ? incident.cloud.error : null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "flex gap-3 rounded-lg border border-border bg-surface p-2",
						children: [incident.snapshot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: incident.snapshot,
							alt: "",
							className: "h-16 w-24 shrink-0 rounded-sm object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 w-24 shrink-0 rounded-sm bg-bg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-medium",
									children: [
										KIND_LABEL[incident.kind],
										" · ",
										cameras[incident.camId].zone
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-sm tabular-nums text-muted",
									dir: "ltr",
									children: [
										new Date(incident.at).toLocaleTimeString("ar", {
											hour: "2-digit",
											minute: "2-digit",
											second: "2-digit"
										}),
										" · ",
										Math.round(incident.confidence * 100),
										"٪",
										" · ",
										incident.origin === "drill" ? "تدريب" : "رصد"
									]
								}),
								verdict ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-pretty text-muted",
									children: [
										"سحابة: ",
										KIND_LABEL[verdict.kind],
										verdict.note ? ` — ${verdict.note}` : ""
									]
								}) : null,
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-pretty text-muted",
									children: error
								}) : null,
								!incident.cloud ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "mt-2",
									variant: "primary",
									disabled: cloudBusy || emergency || cloudLeft <= 0,
									onClick: () => void runCloud(incident.id),
									children: emergency ? "محلي فقط" : "تأكيد سحابي"
								}) : null
							]
						})]
					}, incident.id);
				})
			})
		]
	});
}
var BT_DEVICES = [
	{
		id: "bt-hall",
		name: "Cam-BT صالة الطعام",
		ok: true
	},
	{
		id: "bt-store",
		name: "Cam-BT المخزن الخلفي",
		ok: true
	},
	{
		id: "bt-sensor",
		name: "مستشعر دخان لاسلكي",
		ok: false
	}
];
function SourcePanel() {
	const inspector = useSafety((state) => state.inspector);
	const camera = useSafety((state) => inspector ? state.cameras[inspector] : null);
	const setInspector = useSafety((state) => state.setInspector);
	const patchCamera = useSafety((state) => state.patchCamera);
	const setDrill = useSafety((state) => state.setDrill);
	const [rtsp, setRtsp] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [usb, setUsb] = (0, import_react.useState)([]);
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const [found, setFound] = (0, import_react.useState)(false);
	const [pairing, setPairing] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setRtsp(camera?.rtspUrl ?? "");
		setMessage("");
		setFound(false);
		setScanning(false);
	}, [camera?.id, camera?.rtspUrl]);
	(0, import_react.useEffect)(() => {
		if (!inspector) return;
		const onKey = (event) => {
			if (event.key === "Escape") setInspector(null);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [inspector, setInspector]);
	if (!inspector || !camera) return null;
	async function connectUsb(device) {
		setMessage("");
		try {
			await attachLive(inspector, {
				audio: false,
				video: device.deviceId ? { deviceId: { exact: device.deviceId } } : true
			});
			patchCamera(inspector, {
				source: "usb",
				usbLabel: device.label || "كاميرا USB"
			});
			setMessage("تم وصل البث من منفذ الجهاز.");
		} catch {
			setMessage("تعذّر فتح كاميرا USB في هذه الجلسة.");
		}
	}
	async function connectPhone() {
		setMessage("");
		try {
			try {
				await attachLive(inspector, {
					audio: false,
					video: { facingMode: { ideal: "environment" } }
				});
			} catch {
				await attachLive(inspector, {
					audio: false,
					video: true
				});
			}
			patchCamera(inspector, {
				source: "phone",
				usbLabel: "كاميرا الجهاز"
			});
			setMessage("بث الجوال يعمل، والتحليل يقرأ إطاره مباشرة.");
		} catch {
			setMessage("المتصفح منع الكاميرا. تبقى قناة المحاكاة.");
		}
	}
	function saveRtsp() {
		const url = rtsp.trim();
		if (!/^rtsp:\/\/\S+$/i.test(url)) {
			setMessage("العنوان يجب أن يبدأ بـ rtsp://");
			return;
		}
		detachLive(inspector);
		patchCamera(inspector, {
			source: "rtsp",
			rtspUrl: url
		});
		setMessage("حُفظ العنوان. المتصفح لا يفك RTSP، لذا تُعرض قناة الموقع التجريبية المرتبطة به.");
	}
	function scanBt() {
		setScanning(true);
		setFound(false);
		window.setTimeout(() => {
			setScanning(false);
			setFound(true);
		}, 900);
	}
	function pair(device) {
		if (!device.ok) {
			setMessage("هذا الجهاز مستشعر وليس كاميرا فيديو.");
			return;
		}
		setPairing(device.id);
		window.setTimeout(() => {
			detachLive(inspector);
			patchCamera(inspector, {
				source: "bluetooth",
				btName: device.name
			});
			setPairing(null);
			setMessage("تم الإقران التجريبي. البث المعروض مشهد الكاميرا المرتبطة.");
		}, 800);
	}
	function drill(kind) {
		setDrill(inspector, kind);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-30 flex items-end bg-bg/70 lg:items-center lg:justify-center",
		onClick: () => setInspector(null),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "source-title",
			className: "max-h-[85dvh] w-full overflow-auto rounded-t-xl border border-border bg-surface p-4 lg:max-w-lg lg:rounded-xl",
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "source-title",
						className: "text-lg font-medium",
						children: camera.zone
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "مصدر الفيديو ومحرك الاتصال"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						"aria-label": "إغلاق",
						onClick: () => setInspector(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mb-4 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "flex items-center gap-2 text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, {
								className: "size-4",
								"aria-hidden": "true"
							}), "واي فاي / RTSP"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm text-muted",
							htmlFor: "rtsp-url",
							children: "عنوان البث"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "rtsp-url",
							dir: "ltr",
							value: rtsp,
							onChange: (event) => setRtsp(event.target.value),
							className: "h-11 w-full rounded-md border border-border bg-bg px-3 font-mono text-sm text-fg",
							placeholder: "rtsp://192.168.1.21/live"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveRtsp,
							children: "حفظ عنوان RTSP"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mb-4 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "flex items-center gap-2 text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Usb, {
								className: "size-4",
								"aria-hidden": "true"
							}), "كاميرا USB"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								listVideoInputs().then((devices) => {
									setUsb(devices);
									if (devices.length === 0) setMessage("لا توجد كاميرا USB ظاهرة للمتصفح.");
								}).catch(() => setMessage("تعذّر قراءة أجهزة USB."));
							},
							children: "البحث عن أجهزة USB"
						}),
						usb.map((device, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void connectUsb(device),
							children: device.label || `كاميرا ${index + 1}`
						}, device.deviceId || index)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "primary",
							onClick: () => void connectPhone(),
							children: "بث كاميرا هذا الجهاز"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mb-4 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "flex items-center gap-2 text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bluetooth, {
								className: "size-4",
								"aria-hidden": "true"
							}), "اكتشاف بلوتوث"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-pretty text-muted",
							children: "البحث إقران تجريبي داخل المعاينة، لا يفتح راديو البلوتوث الحقيقي في المتصفح."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: scanBt,
							children: scanning ? "جارٍ البحث…" : "بحث عن أجهزة قريبة"
						}),
						found ? BT_DEVICES.map((device) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => pair(device),
							disabled: pairing === device.id,
							children: pairing === device.id ? "جارٍ الإقران…" : device.name
						}, device.id)) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "تدريب الكشف على هذه القناة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								"data-testid": "drill-flame",
								variant: "alarm",
								onClick: () => drill("flame"),
								children: KIND_LABEL.flame
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								"data-testid": "drill-smoke",
								onClick: () => drill("smoke"),
								children: KIND_LABEL.smoke
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								"data-testid": "drill-smoking",
								onClick: () => drill("smoking"),
								children: KIND_LABEL.smoking
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								"data-testid": "drill-clear",
								onClick: () => drill("clear"),
								children: "مشهد آمن"
							})
						]
					})]
				}),
				message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-pretty text-muted",
					children: message
				}) : null
			]
		})
	});
}
var LINKS = [
	{
		id: "auto",
		label: "تلقائي"
	},
	{
		id: "online",
		label: "متصل"
	},
	{
		id: "emergency",
		label: "طوارئ"
	}
];
function TopBar() {
	const mode = useSafety((state) => state.mode);
	const link = useSafety((state) => state.linkOverride);
	const setLink = useSafety((state) => state.setLink);
	const muted = useSafety((state) => state.muted);
	const setMuted = useSafety((state) => state.setMuted);
	const autoDrill = useSafety((state) => state.autoDrill);
	const setAutoDrill = useSafety((state) => state.setAutoDrill);
	const autoCloud = useSafety((state) => state.autoCloud);
	const setAutoCloud = useSafety((state) => state.setAutoCloud);
	const emergency = useSafety(isEmergency);
	const threats = useSafety((state) => state.threats);
	const setMode = useSafety((state) => state.setMode);
	const active = CAM_IDS.filter((id) => threats[id].kind !== "clear").length;
	const [clock, setClock] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const tick = () => setClock((/* @__PURE__ */ new Date()).toLocaleTimeString("ar", {
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit"
		}));
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex flex-wrap items-center gap-3 border-b border-border px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
					className: "size-5 shrink-0",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium",
						children: "درع الأمان · مجمع النخيل"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: mode === "hub" ? "وضع المركز المحلي" : "وضع المراقبة البعيدة"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-sm tabular-nums text-muted",
				dir: "ltr",
				children: clock
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "radiogroup",
				"aria-label": "حالة الاتصال",
				className: "flex rounded-md border border-border p-1",
				children: LINKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "radio",
					"aria-checked": link === item.id,
					onClick: () => setLink(item.id),
					className: cn("press min-h-11 rounded-sm px-3 text-sm", link === item.id ? "bg-fg text-bg" : "text-muted"),
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("rounded-sm px-2 py-1 text-sm", emergency ? "bg-elevated text-fg" : "bg-elevated text-ok"),
				children: emergency ? "تحليل محلي — طوارئ" : active > 0 ? `خطر في ${active} قنوات` : "السحابة جاهزة للتأكيد"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ms-auto flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: autoDrill ? "primary" : "quiet",
						"aria-pressed": autoDrill,
						onClick: () => setAutoDrill(!autoDrill),
						children: "تدريب تلقائي"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: autoCloud ? "primary" : "quiet",
						"aria-pressed": autoCloud,
						onClick: () => setAutoCloud(!autoCloud),
						children: "تأكيد تلقائي"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						"aria-label": muted ? "تشغيل الإنذار" : "كتم الإنذار",
						"aria-pressed": muted,
						onClick: () => {
							primeAudio();
							setMuted(!muted);
							if (!muted) setAlarm("off");
						},
						children: [muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), muted ? "صامت" : "إنذار"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							primeAudio();
							setMode(mode === "hub" ? "viewer" : "hub");
						},
						children: mode === "hub" ? "المراقبة البعيدة" : "المركز المحلي"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							stopEngine();
							setMode(null);
						},
						children: "إنهاء"
					})
				]
			})
		]
	});
}
function Console() {
	const mode = useSafety((state) => state.mode);
	const leading = useSafety((state) => state.leading);
	const emergency = useSafety(isEmergency);
	const [alertNote, setAlertNote] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (mode === "hub") startEngine();
	}, [mode]);
	(0, import_react.useEffect)(() => () => stopEngine(), []);
	(0, import_react.useEffect)(() => {
		const sync = () => useSafety.getState().setBrowserOnline(navigator.onLine);
		sync();
		window.addEventListener("online", sync);
		window.addEventListener("offline", sync);
		return () => {
			window.removeEventListener("online", sync);
			window.removeEventListener("offline", sync);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		return subscribeRelay((message) => {
			const state = useSafety.getState();
			if (message.type === "incident") state.addIncident(message.incident);
			if (message.type === "frame" && !state.leading) state.setRemoteFrame(message.id, message.jpg, message.kind, message.confidence);
		});
	}, []);
	(0, import_react.useEffect)(() => {
		return useSafety.subscribe((state) => {
			if (state.leading) return;
			setAlarm(!CAM_IDS.some((id) => state.threats[id].kind !== "clear") || state.muted || state.mode === null ? "off" : "pulse");
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-dvh flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "border-b border-border px-3 py-2 text-sm text-pretty text-muted",
				children: [mode === "hub" ? "خمس قنوات موقع تجريبية والقناة السادسة للجوال. الكشف يقرأ البكسل، لا قائمة أحداث جاهزة." : leading ? "البث مستمر من هذا الجهاز، والتنبيه يصل هنا حتى وأنت في وضع المراقبة." : "بانتظار المركز. شغّل وضع المركز في نافذة أخرى على نفس الجهاز، أو ارجع وافتحه هنا.", emergency ? " الاتصال في وضع الطوارئ: لا تأكيد سحابي." : ""]
			}),
			mode === "viewer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 border-b border-border px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => {
						requestAlerts().then((result) => {
							setAlertNote(result === "granted" ? "سيصل إشعار الجهاز عند وقوع حدث والشاشة في الخلفية." : result === "unsupported" ? "هذا المتصفح لا يعرض إشعارات. التنبيه داخل الشاشة يعمل." : "رُفض الإذن. التنبيه داخل الشاشة يبقى فعالاً.");
						});
					},
					children: "تفعيل إشعار الشاشة"
				}), alertNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: alertNote
				}) : null]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "grid min-h-0 flex-1 grid-cols-2 content-start gap-2 overflow-auto p-2 lg:grid-cols-3 lg:p-3",
					children: CAM_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraTile, { id }, id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncidentDock, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourcePanel, {})
		]
	});
}
function Home() {
	const mode = useSafety((state) => state.mode);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let live = true;
		Promise.resolve(useSafety.persist.rehydrate()).finally(() => {
			if (live) setReady(true);
		});
		return () => {
			live = false;
		};
	}, []);
	if (!ready || mode === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, { ready });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Console, {});
}
//#endregion
export { Home as component };
