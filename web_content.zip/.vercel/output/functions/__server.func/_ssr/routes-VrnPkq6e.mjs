import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as startOfDay, i as isAfter, r as isBefore } from "../_libs/date-fns.mjs";
import { D as useAppStore, E as toDateKey, O as weekdayFromDate, S as getDayStatus, T as projectProgressPct, a as SESSION_TYPE_LABEL, f as cn, h as daysUntil, m as countHabitMarks, n as PROJECT_END, p as computeStreak, r as PROJECT_START, u as WEEKDAY_LABEL, w as projectDayNumber, x as getDayChecks } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-ML3_y2lP.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as CalendarDays, S as ChartArea, _ as Droplets, b as ChevronRight, g as Dumbbell, u as PersonStanding } from "../_libs/lucide-react.mjs";
import { a as ProgressRing, s as buttonVariants } from "./router-0AvkMag6.mjs";
import { t as CheckItem } from "./check-item-DFFuMcWH.mjs";
import { t as StatCard } from "./stat-card-ajAgjbVP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-VrnPkq6e.js
var import_jsx_runtime = require_jsx_runtime();
function motivationLine(opts) {
	const { beforeStart, afterEnd, progressPct, streak, todayComplete, todayPartial } = opts;
	if (beforeStart) return "Prepare o terreno. O dia 1 está perto.";
	if (afterEnd) return "101 dias. O que ficou foi o hábito.";
	if (todayComplete) return "Hoje está fechado. Amanhã você só precisa aparecer.";
	if (streak >= 21) return "Três semanas seguidas. Isso já é o padrão, não o esforço.";
	if (streak >= 14) return "Duas semanas no ritmo. Proteja essa sequência.";
	if (streak >= 7) return "Uma semana inteira. Continue no mesmo tom.";
	if (todayPartial) return "Você já começou o dia. Falta só fechar o restante.";
	if (progressPct < 8) return "Mostre-se hoje. O resto se constrói nisso.";
	if (progressPct < 35) return "Constância vale mais que um dia perfeito.";
	if (progressPct < 70) return "O meio do caminho pede o mesmo cuidado do começo.";
	return "Reta final. Mantenha o padrão que te trouxe até aqui.";
}
function Home() {
	const navigate = useNavigate();
	const today = startOfDay(/* @__PURE__ */ new Date());
	const date = toDateKey(today);
	const settings = useAppStore((s) => s.settings);
	const logs = useAppStore((s) => s.logs);
	const sessions = useAppStore((s) => s.sessions);
	const workouts = useAppStore((s) => s.workouts);
	const activeSession = useAppStore((s) => s.activeSession);
	const toggleSkinCare = useAppStore((s) => s.toggleSkinCare);
	const toggleFood = useAppStore((s) => s.toggleFood);
	const togglePostureHabit = useAppStore((s) => s.togglePostureHabit);
	const toggleWorkoutHabit = useAppStore((s) => s.toggleWorkoutHabit);
	const log = logs[date];
	const checks = getDayChecks(log, settings);
	const status = getDayStatus(log, settings);
	const dayNum = projectDayNumber(today);
	const pct = projectProgressPct(today);
	const beforeStart = isBefore(today, PROJECT_START);
	const afterEnd = isAfter(today, PROJECT_END);
	const untilEnd = Math.max(0, daysUntil(PROJECT_END, today));
	const untilStart = Math.max(0, daysUntil(PROJECT_START, today));
	const weekday = weekdayFromDate(today);
	const todayWorkout = workouts[weekday];
	const streak = computeStreak(logs, settings, today);
	const completedDays = Object.values(logs).filter((l) => getDayStatus(l, settings) === "complete").length;
	const habitsDone = Object.values(logs).reduce((acc, l) => acc + countHabitMarks(l), 0);
	const trainingSessions = sessions.filter((s) => s.type !== "postura").length;
	const quote = motivationLine({
		beforeStart,
		afterEnd,
		progressPct: pct,
		streak,
		todayComplete: status === "complete",
		todayPartial: status === "partial"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: settings.name ? settings.name : "Disciplina",
				title: "PROJETO 101",
				subtitle: "Treino, postura e hábitos. Sem teatro."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mb-5 overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex flex-col items-center gap-5 p-6 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ProgressRing, {
						value: pct,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display text-2xl font-semibold tabular-nums",
							children: [pct, "%"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] tracking-wide text-muted-foreground uppercase",
							children: "concluído"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 text-center sm:text-left",
						children: [beforeStart ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-xl font-semibold",
							children: [
								"Começa em ",
								untilStart,
								" ",
								untilStart === 1 ? "dia" : "dias"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "21/09/2026 — Dia 01 de 101"
						})] }) : afterEnd ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl font-semibold",
							children: "Ciclo encerrado"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "101 de 101 dias · 30/12/2026"
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-xl font-semibold",
							children: [
								"Dia ",
								dayNum,
								" de ",
								101
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: untilEnd === 0 ? "Último dia do ciclo." : `${untilEnd} ${untilEnd === 1 ? "dia" : "dias"} até 30/12/2026`
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-secondary-foreground",
							children: quote
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Sequência atual",
						value: streak,
						hint: "dias seguidos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Dias concluídos",
						value: completedDays,
						hint: `de 101`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Hábitos concluídos",
						value: habitsDone
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Sessões de treino",
						value: trainingSessions
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "flex flex-row items-center justify-between space-y-0 p-5 pb-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Checklist de hoje" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dia/$date",
						params: { date },
						className: "text-xs font-medium text-primary",
						children: "Abrir o dia"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-0.5 pt-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
							checked: checks.skinCare,
							label: "Skin care",
							hint: "Limpeza, hidratante e protetor",
							onToggle: () => {
								const next = !(log?.skinCare.cleansing && log?.skinCare.moisturizer && log?.skinCare.sunscreen);
								[
									"cleansing",
									"moisturizer",
									"sunscreen"
								].forEach((k) => {
									if (Boolean(log?.skinCare[k]) !== next) toggleSkinCare(date, k);
								});
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
							checked: checks.water,
							label: "Água — 2 L",
							hint: `${log?.waterMl ?? 0} / ${settings.waterGoalMl} ml`,
							onToggle: () => navigate({ to: "/habitos" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
							checked: checks.sleep,
							label: "Sono — 8 h",
							hint: log?.sleepHours == null ? "Ainda não registrado" : `${log.sleepHours} h registradas`,
							onToggle: () => navigate({ to: "/habitos" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
							checked: checks.food,
							label: "Alimentação saudável",
							onToggle: () => {
								const next = !checks.food;
								[
									"completeMeals",
									"fruitsVeggies",
									"protein",
									"reducedUltra"
								].forEach((k) => {
									if (Boolean(log?.food[k]) !== next) toggleFood(date, k);
								});
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
							checked: checks.posture,
							label: "Postura",
							onToggle: () => togglePostureHabit(date)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
							checked: checks.workout,
							label: "Treino do dia",
							hint: `${WEEKDAY_LABEL[weekday]} · ${todayWorkout.title}`,
							onToggle: () => toggleWorkoutHabit(date)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mb-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex items-center gap-4 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-12 items-center justify-center rounded-xl bg-primary/15 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-medium tracking-wide text-muted-foreground uppercase",
									children: WEEKDAY_LABEL[weekday]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg font-semibold",
									children: SESSION_TYPE_LABEL[todayWorkout.type]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: todayWorkout.subtitle
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/treinos/$day",
							params: { day: weekday },
							className: cn(buttonVariants()),
							children: activeSession ? "Continuar" : "Abrir"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickLink, {
						to: "/calendario",
						icon: CalendarDays,
						title: "Calendário",
						hint: "101 dias · status de cada um"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickLink, {
						to: "/estatisticas",
						icon: ChartArea,
						title: "Estatísticas",
						hint: "Consistência, não estética"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickLink, {
						to: "/postura",
						icon: PersonStanding,
						title: "Rotina de postura",
						hint: "Separada do treino principal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickLink, {
						to: "/habitos",
						icon: Droplets,
						title: "Hábitos",
						hint: "Água, sono, skin care, comida"
					})
				]
			})
		]
	});
}
function QuickLink({ to, icon: Icon, title, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: "block",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "p-4 transition-colors hover:border-primary/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-10 items-center justify-center rounded-xl bg-accent text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: hint
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted-foreground" })
				]
			})
		})
	});
}
//#endregion
export { Home as component };
