import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Settings, c as Moon, d as Copy, f as Check, h as ArrowLeftRight, i as Sun, l as History, m as ArrowUpDown, o as Search, p as Calculator, r as Trash2, s as RefreshCw, t as X, u as Delete } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B8j4wzBG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var EXTRAS = {
	FOK: {
		en: "Faroese Króna",
		ar: "كرونة فاروية"
	},
	GGP: {
		en: "Guernsey Pound",
		ar: "جنيه غيرنزي"
	},
	IMP: {
		en: "Isle of Man Pound",
		ar: "جنيه جزيرة مان"
	},
	JEP: {
		en: "Jersey Pound",
		ar: "جنيه جيرسي"
	},
	KID: {
		en: "Kiribati Dollar",
		ar: "دولار كيريباتي"
	},
	TVD: {
		en: "Tuvaluan Dollar",
		ar: "دولار توفالو"
	}
};
var OBSOLETE = /* @__PURE__ */ new Set([
	"ATS",
	"AZM",
	"BEF",
	"BYR",
	"CUC",
	"CYP",
	"DEM",
	"EEK",
	"ESP",
	"FIM",
	"FRF",
	"GHC",
	"GRD",
	"HRK",
	"IEP",
	"ITL",
	"LTL",
	"LUF",
	"LVL",
	"MGF",
	"MRO",
	"MTL",
	"MXV",
	"MZM",
	"NLG",
	"PTE",
	"ROL",
	"SDD",
	"SIT",
	"SKK",
	"SLL",
	"SRG",
	"STD",
	"TMM",
	"TRL",
	"VEB",
	"VED",
	"VEF",
	"XAG",
	"XAU",
	"XPD",
	"XPT",
	"XDR",
	"ZMK",
	"ZWD",
	"ZWN"
]);
var displayEn = null;
var displayAr = null;
function display(lang) {
	if (lang === "ar") {
		displayAr ??= new Intl.DisplayNames(["ar"], { type: "currency" });
		return displayAr;
	}
	displayEn ??= new Intl.DisplayNames(["en"], { type: "currency" });
	return displayEn;
}
function knownCurrency(code) {
	if (!/^[A-Z]{3}$/.test(code) || OBSOLETE.has(code)) return false;
	if (EXTRAS[code]) return true;
	try {
		const name = display("en").of(code);
		return Boolean(name && name.toUpperCase() !== code);
	} catch {
		return false;
	}
}
function currencyLabel(code, lang) {
	const extra = EXTRAS[code];
	if (extra) return lang === "ar" ? extra.ar : extra.en;
	try {
		return display(lang).of(code) ?? code;
	} catch {
		return code;
	}
}
var QUICK_PAIRS = [
	["USD", "EGP"],
	["EUR", "EGP"],
	["SAR", "EGP"],
	["GBP", "USD"],
	["AED", "EGP"]
];
var POPULAR_CODES = [
	"USD",
	"EUR",
	"EGP",
	"SAR",
	"AED",
	"GBP",
	"KWD",
	"QAR",
	"BHD",
	"OMR",
	"JOD",
	"TRY",
	"JPY",
	"CNY",
	"INR"
];
function pickRates(raw) {
	const out = {};
	for (const [key, value] of Object.entries(raw)) {
		const code = key.toUpperCase();
		if (!knownCurrency(code)) continue;
		const n = typeof value === "number" ? value : Number(value);
		if (!Number.isFinite(n) || n <= 0) continue;
		out[code] = n;
	}
	out.USD = 1;
	return out;
}
function convert(amount, from, to, rates) {
	const fromRate = rates[from];
	const toRate = rates[to];
	if (!fromRate || !toRate || !Number.isFinite(amount)) return null;
	const value = amount / fromRate * toRate;
	return Number.isFinite(value) ? value : null;
}
function formatRate(n) {
	if (!Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	let digits = 2;
	if (abs < 1e-4) digits = 8;
	else if (abs < .01) digits = 6;
	else if (abs < 1) digits = 4;
	else if (abs < 100) digits = 4;
	else digits = 2;
	return new Intl.NumberFormat("en-US", {
		minimumFractionDigits: Math.min(2, digits),
		maximumFractionDigits: digits
	}).format(n);
}
function formatMoney(n, code) {
	if (!Number.isFinite(n)) return "—";
	let digits = 2;
	try {
		digits = new Intl.NumberFormat("en", {
			style: "currency",
			currency: code
		}).resolvedOptions().maximumFractionDigits ?? 2;
	} catch {
		digits = 2;
	}
	const abs = Math.abs(n);
	if (abs !== 0 && abs < 10 ** -Math.min(digits, 6)) return new Intl.NumberFormat("en-US", { maximumFractionDigits: 8 }).format(n);
	return new Intl.NumberFormat("en-US", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	}).format(n);
}
async function fromExchangeRate(signal) {
	const res = await fetch("https://open.er-api.com/v6/latest/USD", {
		signal,
		headers: { accept: "application/json" }
	});
	if (!res.ok) throw new Error("exchange-rate");
	const data = await res.json();
	if (data.result !== "success" || !data.rates) throw new Error("exchange-rate");
	const rates = pickRates(data.rates);
	if (!rates.EGP || !rates.EUR || !rates.SAR) throw new Error("exchange-rate");
	return {
		rates,
		asOf: typeof data.time_last_update_unix === "number" ? (/* @__PURE__ */ new Date(data.time_last_update_unix * 1e3)).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
		provider: "ExchangeRate-API"
	};
}
async function fromCurrencyApi(signal) {
	const res = await fetch("https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.min.json", {
		signal,
		headers: { accept: "application/json" }
	});
	if (!res.ok) throw new Error("currency-api");
	const data = await res.json();
	if (!data.usd) throw new Error("currency-api");
	const rates = pickRates(data.usd);
	if (!rates.EGP || !rates.EUR) throw new Error("currency-api");
	return {
		rates,
		asOf: data.date ? `${data.date}T00:00:00.000Z` : (/* @__PURE__ */ new Date()).toISOString(),
		provider: "currency-api"
	};
}
async function fetchRateBook(signal) {
	try {
		return await fromExchangeRate(signal);
	} catch (error) {
		if (signal?.aborted) throw error;
		return fromCurrencyApi(signal);
	}
}
var audio = null;
function playClick() {
	const Ctx = window.AudioContext || window.webkitAudioContext;
	if (!Ctx) return;
	audio ??= new Ctx();
	const now = audio.currentTime;
	const osc = audio.createOscillator();
	const gain = audio.createGain();
	osc.type = "sine";
	osc.frequency.setValueAtTime(740, now);
	gain.gain.setValueAtTime(1e-4, now);
	gain.gain.exponentialRampToValueAtTime(.035, now + .008);
	gain.gain.exponentialRampToValueAtTime(1e-4, now + .05);
	osc.connect(gain);
	gain.connect(audio.destination);
	osc.start(now);
	osc.stop(now + .055);
	audio.resume();
}
function tick(sound, haptic) {
	if (typeof window === "undefined") return;
	if (sound) try {
		playClick();
	} catch {}
	if (haptic && typeof navigator.vibrate === "function") navigator.vibrate(10);
}
async function copyText(text) {
	if (!text) return false;
	try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {
		try {
			const area = document.createElement("textarea");
			area.value = text;
			area.setAttribute("readonly", "");
			area.style.position = "fixed";
			area.style.opacity = "0";
			document.body.appendChild(area);
			area.select();
			const ok = document.execCommand("copy");
			area.remove();
			return ok;
		} catch {
			return false;
		}
	}
}
var dict = {
	ar: {
		appName: "Smart Calculator Pro",
		subtitle: "آلة حاسبة علمية ومحول عملات",
		standard: "عادي",
		scientific: "علمي",
		calculator: "الحاسبة",
		currency: "العملات",
		history: "السجل",
		settings: "الإعدادات",
		clear: "مسح",
		backspace: "تراجع",
		copy: "نسخ النتيجة",
		copied: "تم النسخ",
		copyFail: "تعذر النسخ",
		errorMath: "عملية غير صالحة",
		errorSyntax: "التعبير غير مكتمل",
		errorEmpty: "أدخل عملية أولاً",
		deg: "درجات",
		rad: "راديان",
		ans: "آخر نتيجة",
		amount: "المبلغ",
		from: "من",
		to: "إلى",
		swap: "تبديل العملتين",
		rate: "سعر الصرف",
		inverse: "السعر العكسي",
		updated: "آخر تحديث",
		live: "محدّث من الإنترنت",
		cached: "آخر سعر محفوظ — غير محدث",
		cachedDetail: "تعذر تحديث الأسعار الآن. القيمة المعروضة آخر سعر تم حفظه على هذا الجهاز وليست سعرًا جديدًا.",
		loadingRates: "جارٍ جلب أسعار العملات…",
		noRates: "لا توجد أسعار محفوظة. اتصل بالإنترنت لإظهار سعر الصرف الحقيقي.",
		refresh: "تحديث الأسعار",
		search: "ابحث بالاسم أو الرمز",
		noMatch: "لا توجد عملة مطابقة",
		choose: "اختر العملة",
		close: "إغلاق",
		popular: "شائعة",
		allCurrencies: "كل العملات",
		pairs: "مقارنات سريعة",
		spotlight: "أسعار اليوم",
		recent: "آخر العمليات",
		emptyHistory: "لا توجد عمليات بعد. نتائج الحاسبة والتحويلات التي تحفظها تظهر هنا.",
		saveCompare: "حفظ المقارنة",
		saved: "حُفظت في السجل",
		tapCopy: "نسخ",
		remove: "حذف",
		appearance: "المظهر",
		light: "نهاري",
		dark: "ليلي",
		system: "تلقائي",
		accent: "لون التطبيق",
		gold: "ذهبي",
		jade: "زمردي",
		cobalt: "أزرق",
		coral: "مرجاني",
		language: "اللغة",
		sound: "صوت الأزرار",
		soundHint: "نقرة خفيفة عند الضغط",
		haptic: "الاهتزاز",
		hapticHint: "اهتزاز قصير على الهواتف التي تدعمه",
		clearHistory: "مسح السجل",
		confirmClear: "تأكيد المسح",
		historyCleared: "تم مسح السجل",
		about: "حول التطبيق",
		aboutBody: "آلة حاسبة للعمليات اليومية والعلمية، مع محول عملات يغطي عملات العالم. الأسعار تُجلب مباشرة من مصدر بيانات على الإنترنت، وتُحفظ آخر نسخة على الجهاز إذا انقطع الاتصال.",
		disclaimer: "السعر مرجعي من السوق وليس سعر شراء أو بيع من بنك أو صراف.",
		privacy: "الإعدادات والسجل وآخر الأسعار تبقى على هذا الجهاز فقط.",
		source: "مصدر السعر",
		install: "التثبيت على أندرويد",
		installLead: "يمكن إضافة التطبيق إلى الشاشة الرئيسية ليعمل كتطبيق مستقل.",
		install1: "افتح التطبيق في متصفح Chrome على هاتف أندرويد.",
		install2: "من قائمة المتصفح اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».",
		install3: "أكد الاسم Smart Calculator Pro وسيظهر بين تطبيقاتك.",
		installNow: "تثبيت التطبيق",
		version: "الإصدار 1.0.0",
		theme: "تبديل المظهر",
		result: "النتيجة",
		expression: "العملية",
		perOne: "مقابل",
		currenciesCount: "عملة",
		angle: "وحدة الزاوية"
	},
	en: {
		appName: "Smart Calculator Pro",
		subtitle: "Scientific calculator and currency converter",
		standard: "Standard",
		scientific: "Scientific",
		calculator: "Calculator",
		currency: "Currency",
		history: "History",
		settings: "Settings",
		clear: "Clear",
		backspace: "Backspace",
		copy: "Copy result",
		copied: "Copied",
		copyFail: "Could not copy",
		errorMath: "Invalid operation",
		errorSyntax: "Incomplete expression",
		errorEmpty: "Enter an expression first",
		deg: "Degrees",
		rad: "Radians",
		ans: "Last answer",
		amount: "Amount",
		from: "From",
		to: "To",
		swap: "Swap currencies",
		rate: "Exchange rate",
		inverse: "Inverse rate",
		updated: "Last update",
		live: "Updated from the internet",
		cached: "Saved rate — not updated",
		cachedDetail: "Rates could not be refreshed. The value shown is the last rate saved on this device, not a new quote.",
		loadingRates: "Fetching live exchange rates…",
		noRates: "No saved rates yet. Connect to the internet to load real exchange rates.",
		refresh: "Refresh rates",
		search: "Search by name or code",
		noMatch: "No matching currency",
		choose: "Choose currency",
		close: "Close",
		popular: "Popular",
		allCurrencies: "All currencies",
		pairs: "Quick comparisons",
		spotlight: "Today's rates",
		recent: "Recent",
		emptyHistory: "Nothing yet. Calculator results and saved conversions will show up here.",
		saveCompare: "Save comparison",
		saved: "Saved to history",
		tapCopy: "Copy",
		remove: "Delete",
		appearance: "Appearance",
		light: "Light",
		dark: "Dark",
		system: "System",
		accent: "App color",
		gold: "Gold",
		jade: "Jade",
		cobalt: "Cobalt",
		coral: "Coral",
		language: "Language",
		sound: "Button sounds",
		soundHint: "A soft click on each key",
		haptic: "Vibration",
		hapticHint: "A short pulse on phones that support it",
		clearHistory: "Clear history",
		confirmClear: "Confirm clear",
		historyCleared: "History cleared",
		about: "About",
		aboutBody: "A calculator for everyday and scientific work, plus a world currency converter. Rates are fetched live from the internet and the last copy is kept on the device if you go offline.",
		disclaimer: "Rates are market reference quotes, not a bank or exchange buy/sell price.",
		privacy: "Settings, history, and the last rates stay on this device only.",
		source: "Rate source",
		install: "Install on Android",
		installLead: "Add the app to your home screen and use it like a native app.",
		install1: "Open the app in Chrome on your Android phone.",
		install2: "From the browser menu choose “Install app” or “Add to Home screen”.",
		install3: "Confirm the name Smart Calculator Pro and it will appear with your apps.",
		installNow: "Install app",
		version: "Version 1.0.0",
		theme: "Toggle theme",
		result: "Result",
		expression: "Expression",
		perOne: "per",
		currenciesCount: "currencies",
		angle: "Angle unit"
	}
};
function t(lang, key) {
	return dict[lang][key];
}
function formatWhen(iso, lang) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return iso;
	return new Intl.DateTimeFormat(lang === "ar" ? "ar" : "en", {
		dateStyle: "medium",
		timeStyle: "short",
		numberingSystem: "latn"
	}).format(date);
}
function uid() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
var useAppStore = create()(persist((set) => ({
	theme: "dark",
	accent: "gold",
	lang: "ar",
	sound: true,
	haptic: true,
	angle: "deg",
	sci: false,
	tab: "calc",
	history: [],
	fxFrom: "USD",
	fxTo: "EGP",
	fxAmount: "100",
	rates: null,
	rateAsOf: null,
	rateProvider: null,
	rateStatus: "idle",
	setTheme: (theme) => set({ theme }),
	setAccent: (accent) => set({ accent }),
	setLang: (lang) => set({ lang }),
	setSound: (sound) => set({ sound }),
	setHaptic: (haptic) => set({ haptic }),
	setAngle: (angle) => set({ angle }),
	setSci: (sci) => set({ sci }),
	setTab: (tab) => set({ tab }),
	setFx: (patch) => set(patch),
	swapFx: () => set((s) => ({
		fxFrom: s.fxTo,
		fxTo: s.fxFrom
	})),
	addHistory: (item) => set((s) => ({ history: [{
		...item,
		id: uid(),
		ts: Date.now()
	}, ...s.history].slice(0, 100) })),
	removeHistory: (id) => set((s) => ({ history: s.history.filter((item) => item.id !== id) })),
	clearHistory: () => set({ history: [] }),
	applyBook: (book, status) => set({
		rates: book.rates,
		rateAsOf: book.asOf,
		rateProvider: book.provider,
		rateStatus: status
	}),
	setRateStatus: (rateStatus) => set({ rateStatus })
}), {
	name: "scp-store",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (s) => ({
		theme: s.theme,
		accent: s.accent,
		lang: s.lang,
		sound: s.sound,
		haptic: s.haptic,
		angle: s.angle,
		sci: s.sci,
		history: s.history,
		fxFrom: s.fxFrom,
		fxTo: s.fxTo,
		fxAmount: s.fxAmount,
		rates: s.rates,
		rateAsOf: s.rateAsOf,
		rateProvider: s.rateProvider
	})
}));
var CalcError = class extends Error {
	code;
	constructor(code) {
		super(code);
		this.name = "CalcError";
		this.code = code;
	}
};
var NUM_RE = /^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i;
function endsValue(t) {
	if (!t) return false;
	return t.k === "num" || t.k === "const" || t.k === "rp" || t.k === "pct" || t.k === "fact";
}
function startsValue(t) {
	return t.k === "num" || t.k === "const" || t.k === "lp" || t.k === "fn";
}
function parenBalance(tokens) {
	let n = 0;
	for (const t of tokens) if (t.k === "lp") n += 1;
	else if (t.k === "rp") n -= 1;
	return n;
}
function withStar(tokens) {
	const last = tokens[tokens.length - 1];
	if (last && endsValue(last)) return [...tokens, {
		k: "op",
		v: "*"
	}];
	return tokens;
}
function insertDigit(tokens, digit) {
	const last = tokens[tokens.length - 1];
	if (last?.k === "num") {
		if (digit === "." && last.s.includes(".")) return tokens;
		if (last.s.replace(".", "").length >= 15 && digit !== ".") return tokens;
		let s = last.s;
		if (s === "0" && digit !== ".") s = digit;
		else s += digit;
		const next = tokens.slice();
		next[next.length - 1] = {
			k: "num",
			s
		};
		return next;
	}
	return [...withStar(tokens), {
		k: "num",
		s: digit === "." ? "0." : digit
	}];
}
function insertOp(tokens, op) {
	if (tokens.length === 0) return op === "-" ? [{
		k: "op",
		v: "-"
	}] : tokens;
	const last = tokens[tokens.length - 1];
	if (last.k === "op") {
		if (op === "-" && last.v !== "-") return [...tokens, {
			k: "op",
			v: "-"
		}];
		const next = tokens.slice();
		next[next.length - 1] = {
			k: "op",
			v: op
		};
		return next;
	}
	if (last.k === "fn" || last.k === "lp") return op === "-" ? [...tokens, {
		k: "op",
		v: "-"
	}] : tokens;
	return [...tokens, {
		k: "op",
		v: op
	}];
}
function insertFn(tokens, fn) {
	return [
		...withStar(tokens),
		{
			k: "fn",
			v: fn
		},
		{ k: "lp" }
	];
}
function insertLp(tokens) {
	return [...withStar(tokens), { k: "lp" }];
}
function insertRp(tokens) {
	if (parenBalance(tokens) <= 0) return tokens;
	const last = tokens[tokens.length - 1];
	if (!last || last.k === "op" || last.k === "fn" || last.k === "lp") return tokens;
	return [...tokens, { k: "rp" }];
}
function insertPct(tokens) {
	const last = tokens[tokens.length - 1];
	if (!last || !endsValue(last)) return tokens;
	return [...tokens, { k: "pct" }];
}
function insertFact(tokens) {
	const last = tokens[tokens.length - 1];
	if (!last || !endsValue(last)) return tokens;
	return [...tokens, { k: "fact" }];
}
function insertConst(tokens, name) {
	return [...withStar(tokens), {
		k: "const",
		v: name
	}];
}
function backspace(tokens) {
	if (tokens.length === 0) return tokens;
	const next = tokens.slice();
	const last = next[next.length - 1];
	if (last.k === "num" && last.s.length > 1) {
		next[next.length - 1] = {
			k: "num",
			s: last.s.slice(0, -1)
		};
		return next;
	}
	next.pop();
	return next;
}
function numberToTokens(n) {
	if (!Number.isFinite(n)) throw new CalcError("math");
	const neg = n < 0;
	const abs = Math.abs(n);
	let s;
	if (abs === 0) s = "0";
	else if (abs >= 0x38d7ea4c68000 || abs < 1e-9) s = abs.toExponential(8).replace(/\.?0+e/, "e").replace("e+", "e");
	else s = Number(abs.toPrecision(12)).toString();
	const num = {
		k: "num",
		s
	};
	return neg ? [{
		k: "op",
		v: "-"
	}, num] : [num];
}
function insertNumber(tokens, n) {
	const piece = numberToTokens(n);
	const last = tokens[tokens.length - 1];
	if (last && endsValue(last)) return [
		...tokens,
		{
			k: "op",
			v: "*"
		},
		...piece
	];
	return [...tokens, ...piece];
}
function prepareTokens(tokens) {
	const t = tokens.slice();
	while (t.length) {
		const last = t[t.length - 1];
		if (last.k === "op" || last.k === "fn" || last.k === "lp") t.pop();
		else break;
	}
	let open = parenBalance(t);
	while (open > 0) {
		t.push({ k: "rp" });
		open -= 1;
	}
	return t;
}
function withImplicit(tokens) {
	const out = [];
	for (const token of tokens) {
		const prev = out[out.length - 1];
		if (prev && endsValue(prev) && startsValue(token)) out.push({
			k: "op",
			v: "*"
		});
		out.push(token);
	}
	return out;
}
function isBinary(t, ops) {
	return !!t && t.k === "op" && ops.includes(t.v);
}
function parse(tokens) {
	const src = withImplicit(tokens);
	let i = 0;
	const peek = () => src[i];
	const eat = () => {
		const t = src[i];
		i += 1;
		return t;
	};
	function parseExpr() {
		let left = parseTerm();
		while (isBinary(peek(), ["+", "-"])) left = {
			t: "bin",
			op: eat().v,
			l: left,
			r: parseTerm()
		};
		return left;
	}
	function parseTerm() {
		let left = parsePower();
		while (isBinary(peek(), ["*", "/"])) left = {
			t: "bin",
			op: eat().v,
			l: left,
			r: parsePower()
		};
		return left;
	}
	function parsePower() {
		const left = parseUnary();
		if (isBinary(peek(), ["^"])) {
			eat();
			return {
				t: "bin",
				op: "^",
				l: left,
				r: parsePower()
			};
		}
		return left;
	}
	function parseUnary() {
		if (isBinary(peek(), ["-"])) {
			eat();
			return {
				t: "neg",
				x: parseUnary()
			};
		}
		return parsePostfix();
	}
	function parsePostfix() {
		let node = parsePrimary();
		for (;;) {
			const t = peek();
			if (t?.k === "pct") {
				eat();
				node = {
					t: "pct",
					x: node
				};
			} else if (t?.k === "fact") {
				eat();
				node = {
					t: "fact",
					x: node
				};
			} else break;
		}
		return node;
	}
	function parsePrimary() {
		const t = peek();
		if (!t) throw new CalcError("syntax");
		if (t.k === "num") {
			eat();
			if (!NUM_RE.test(t.s)) throw new CalcError("syntax");
			const v = Number(t.s);
			if (!Number.isFinite(v)) throw new CalcError("syntax");
			return {
				t: "num",
				v
			};
		}
		if (t.k === "const") {
			eat();
			return {
				t: "num",
				v: t.v === "pi" ? Math.PI : Math.E
			};
		}
		if (t.k === "lp") {
			eat();
			const inner = parseExpr();
			if (peek()?.k !== "rp") throw new CalcError("syntax");
			eat();
			return inner;
		}
		if (t.k === "fn") {
			eat();
			return {
				t: "call",
				fn: t.v,
				x: parseUnary()
			};
		}
		throw new CalcError("syntax");
	}
	if (src.length === 0) throw new CalcError("empty");
	const ast = parseExpr();
	if (i !== src.length) throw new CalcError("syntax");
	return ast;
}
function factorial(n) {
	if (!Number.isFinite(n) || n < 0 || Math.floor(n) !== n || n > 170) throw new CalcError("math");
	let r = 1;
	for (let i = 2; i <= n; i += 1) r *= i;
	return r;
}
function toRad(n, angle) {
	return angle === "deg" ? n * Math.PI / 180 : n;
}
function fromRad(n, angle) {
	return angle === "deg" ? n * 180 / Math.PI : n;
}
function evalAst(node, angle) {
	switch (node.t) {
		case "num": return node.v;
		case "neg": {
			const v = -evalAst(node.x, angle);
			if (!Number.isFinite(v)) throw new CalcError("math");
			return v;
		}
		case "pct": {
			const v = evalAst(node.x, angle) / 100;
			if (!Number.isFinite(v)) throw new CalcError("math");
			return v;
		}
		case "fact": return factorial(evalAst(node.x, angle));
		case "call": {
			const x = evalAst(node.x, angle);
			return applyFn(node.fn, x, angle);
		}
		case "bin": {
			if ((node.op === "+" || node.op === "-") && node.r.t === "pct") {
				const base = evalAst(node.l, angle);
				const ratio = evalAst(node.r, angle);
				const v = node.op === "+" ? base + base * ratio : base - base * ratio;
				if (!Number.isFinite(v)) throw new CalcError("math");
				return v;
			}
			const l = evalAst(node.l, angle);
			const r = evalAst(node.r, angle);
			let v;
			switch (node.op) {
				case "+":
					v = l + r;
					break;
				case "-":
					v = l - r;
					break;
				case "*":
					v = l * r;
					break;
				case "/":
					if (r === 0) throw new CalcError("math");
					v = l / r;
					break;
				case "^":
					v = l ** r;
					break;
				default: throw new CalcError("syntax");
			}
			if (!Number.isFinite(v)) throw new CalcError("math");
			return v;
		}
		default: throw new CalcError("syntax");
	}
}
function applyFn(fn, x, angle) {
	let v;
	switch (fn) {
		case "sin":
			v = Math.sin(toRad(x, angle));
			break;
		case "cos":
			v = Math.cos(toRad(x, angle));
			break;
		case "tan": {
			const r = toRad(x, angle);
			if (Math.abs(Math.cos(r)) < 1e-12) throw new CalcError("math");
			v = Math.sin(r) / Math.cos(r);
			break;
		}
		case "asin":
			if (x < -1 || x > 1) throw new CalcError("math");
			v = fromRad(Math.asin(x), angle);
			break;
		case "acos":
			if (x < -1 || x > 1) throw new CalcError("math");
			v = fromRad(Math.acos(x), angle);
			break;
		case "atan":
			v = fromRad(Math.atan(x), angle);
			break;
		case "log":
			if (x <= 0) throw new CalcError("math");
			v = Math.log10(x);
			break;
		case "ln":
			if (x <= 0) throw new CalcError("math");
			v = Math.log(x);
			break;
		case "sqrt":
			if (x < 0) throw new CalcError("math");
			v = Math.sqrt(x);
			break;
		case "abs":
			v = Math.abs(x);
			break;
		default: throw new CalcError("syntax");
	}
	if (!Number.isFinite(v)) throw new CalcError("math");
	return v;
}
function snap(n) {
	if (!Number.isFinite(n)) throw new CalcError("math");
	if (n === 0) return 0;
	const abs = Math.abs(n);
	if (abs >= 0x38d7ea4c68000 || abs < 1e-12) return n;
	const rounded = Number(n.toPrecision(12));
	return Object.is(rounded, -0) ? 0 : rounded;
}
function evaluateTokens(tokens, angle) {
	const ready = prepareTokens(tokens);
	if (ready.length === 0) throw new CalcError("empty");
	return snap(evalAst(parse(ready), angle));
}
function tryEvaluate(tokens, angle) {
	try {
		return evaluateTokens(tokens, angle);
	} catch {
		return null;
	}
}
function tokensToDisplay(tokens) {
	let out = "";
	for (let i = 0; i < tokens.length; i += 1) {
		const t = tokens[i];
		if (t.k === "num") out += t.s;
		else if (t.k === "op") {
			if (t.v === "-") {
				const prev = tokens[i - 1];
				const unary = !prev || prev.k === "op" || prev.k === "lp" || prev.k === "fn";
				out += unary ? "−" : " − ";
			} else if (t.v === "+") out += " + ";
			else if (t.v === "*") out += " × ";
			else if (t.v === "/") out += " ÷ ";
			else out += "^";
		} else if (t.k === "fn") out += t.v === "sqrt" ? "√" : t.v;
		else if (t.k === "lp") out += "(";
		else if (t.k === "rp") out += ")";
		else if (t.k === "pct") out += "%";
		else if (t.k === "fact") out += "!";
		else out += t.v === "pi" ? "π" : "e";
	}
	return out;
}
function formatNumber(n) {
	if (!Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	if (abs !== 0 && (abs >= 0xe8d4a51000 || abs < 1e-8)) return n.toExponential(6).replace(/\.?0+e/, "e").replace("e+", "e");
	const rounded = Number(n.toPrecision(12));
	return new Intl.NumberFormat("en-US", {
		maximumFractionDigits: 10,
		useGrouping: true
	}).format(Object.is(rounded, -0) ? 0 : rounded);
}
function plainNumber(n) {
	if (!Number.isFinite(n)) return "";
	const abs = Math.abs(n);
	if (abs !== 0 && (abs >= 0xe8d4a51000 || abs < 1e-8)) return n.toExponential(10).replace(/\.?0+e/, "e").replace("e+", "e");
	return String(Number(n.toPrecision(12)));
}
var SCI_ROWS = [
	[
		{
			id: "lp",
			label: "(",
			aria: "(",
			tone: "op",
			action: { t: "lp" }
		},
		{
			id: "rp",
			label: ")",
			aria: ")",
			tone: "op",
			action: { t: "rp" }
		},
		{
			id: "pow",
			label: "xʸ",
			aria: "power",
			tone: "op",
			action: {
				t: "op",
				v: "^"
			}
		},
		{
			id: "sq",
			label: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["x", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sup", { children: "2" })] }),
			aria: "square",
			tone: "op",
			action: { t: "pow2" }
		}
	],
	[
		{
			id: "sin",
			label: "sin",
			aria: "sin",
			tone: "op",
			action: {
				t: "fn",
				v: "sin"
			}
		},
		{
			id: "cos",
			label: "cos",
			aria: "cos",
			tone: "op",
			action: {
				t: "fn",
				v: "cos"
			}
		},
		{
			id: "tan",
			label: "tan",
			aria: "tan",
			tone: "op",
			action: {
				t: "fn",
				v: "tan"
			}
		},
		{
			id: "sqrt",
			label: "√",
			aria: "square root",
			tone: "op",
			action: {
				t: "fn",
				v: "sqrt"
			}
		}
	],
	[
		{
			id: "log",
			label: "log",
			aria: "log",
			tone: "op",
			action: {
				t: "fn",
				v: "log"
			}
		},
		{
			id: "ln",
			label: "ln",
			aria: "ln",
			tone: "op",
			action: {
				t: "fn",
				v: "ln"
			}
		},
		{
			id: "pi",
			label: "π",
			aria: "pi",
			tone: "op",
			action: {
				t: "const",
				v: "pi"
			}
		},
		{
			id: "e",
			label: "e",
			aria: "e",
			tone: "op",
			action: {
				t: "const",
				v: "e"
			}
		}
	],
	[
		{
			id: "abs",
			label: "|x|",
			aria: "absolute value",
			tone: "op",
			action: {
				t: "fn",
				v: "abs"
			}
		},
		{
			id: "fact",
			label: "n!",
			aria: "factorial",
			tone: "op",
			action: { t: "fact" }
		},
		{
			id: "inv",
			label: "1/x",
			aria: "reciprocal",
			tone: "op",
			action: { t: "inv" }
		},
		{
			id: "ans",
			label: "Ans",
			aria: "last answer",
			tone: "op",
			action: { t: "ans" }
		}
	]
];
var BASIC_ROWS = [
	[
		{
			id: "ac",
			label: "AC",
			aria: "clear",
			tone: "ghost",
			action: { t: "ac" }
		},
		{
			id: "bs",
			label: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, { className: "size-5" }),
			aria: "backspace",
			tone: "ghost",
			action: { t: "bs" }
		},
		{
			id: "pct",
			label: "%",
			aria: "percent",
			tone: "op",
			action: { t: "pct" }
		},
		{
			id: "div",
			label: "÷",
			aria: "divide",
			tone: "op",
			action: {
				t: "op",
				v: "/"
			}
		}
	],
	[
		{
			id: "7",
			label: "7",
			aria: "7",
			tone: "num",
			action: {
				t: "digit",
				v: "7"
			}
		},
		{
			id: "8",
			label: "8",
			aria: "8",
			tone: "num",
			action: {
				t: "digit",
				v: "8"
			}
		},
		{
			id: "9",
			label: "9",
			aria: "9",
			tone: "num",
			action: {
				t: "digit",
				v: "9"
			}
		},
		{
			id: "mul",
			label: "×",
			aria: "multiply",
			tone: "op",
			action: {
				t: "op",
				v: "*"
			}
		}
	],
	[
		{
			id: "4",
			label: "4",
			aria: "4",
			tone: "num",
			action: {
				t: "digit",
				v: "4"
			}
		},
		{
			id: "5",
			label: "5",
			aria: "5",
			tone: "num",
			action: {
				t: "digit",
				v: "5"
			}
		},
		{
			id: "6",
			label: "6",
			aria: "6",
			tone: "num",
			action: {
				t: "digit",
				v: "6"
			}
		},
		{
			id: "sub",
			label: "−",
			aria: "subtract",
			tone: "op",
			action: {
				t: "op",
				v: "-"
			}
		}
	],
	[
		{
			id: "1",
			label: "1",
			aria: "1",
			tone: "num",
			action: {
				t: "digit",
				v: "1"
			}
		},
		{
			id: "2",
			label: "2",
			aria: "2",
			tone: "num",
			action: {
				t: "digit",
				v: "2"
			}
		},
		{
			id: "3",
			label: "3",
			aria: "3",
			tone: "num",
			action: {
				t: "digit",
				v: "3"
			}
		},
		{
			id: "add",
			label: "+",
			aria: "add",
			tone: "op",
			action: {
				t: "op",
				v: "+"
			}
		}
	],
	[
		{
			id: "0",
			label: "0",
			aria: "0",
			tone: "num",
			span: 2,
			action: {
				t: "digit",
				v: "0"
			}
		},
		{
			id: "dot",
			label: ".",
			aria: "decimal",
			tone: "num",
			action: {
				t: "digit",
				v: "."
			}
		},
		{
			id: "eq",
			label: "=",
			aria: "equals",
			tone: "accent",
			action: { t: "eq" }
		}
	]
];
function feedback$3() {
	const { sound, haptic } = useAppStore.getState();
	tick(sound, haptic);
}
function CalculatorView({ onToast }) {
	const lang = useAppStore((s) => s.lang);
	const sci = useAppStore((s) => s.sci);
	const angle = useAppStore((s) => s.angle);
	const setSci = useAppStore((s) => s.setSci);
	const setAngle = useAppStore((s) => s.setAngle);
	const [tokens, setTokens] = (0, import_react.useState)([]);
	const [settled, setSettled] = (0, import_react.useState)(false);
	const [lastExpr, setLastExpr] = (0, import_react.useState)("");
	const [lastValue, setLastValue] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const tokensRef = (0, import_react.useRef)(tokens);
	const settledRef = (0, import_react.useRef)(settled);
	const lastValueRef = (0, import_react.useRef)(lastValue);
	tokensRef.current = tokens;
	settledRef.current = settled;
	lastValueRef.current = lastValue;
	function valueBase() {
		return settledRef.current ? [] : tokensRef.current;
	}
	function opBase() {
		if (!settledRef.current) return tokensRef.current;
		if (lastValueRef.current == null) return [];
		return numberToTokens(lastValueRef.current);
	}
	function run(action) {
		feedback$3();
		if (action.t === "ac") {
			setTokens([]);
			setSettled(false);
			setLastExpr("");
			setError(null);
			return;
		}
		if (action.t === "bs") {
			if (settledRef.current) {
				setSettled(false);
				setLastExpr("");
				setTokens(backspace(tokensRef.current));
			} else setTokens(backspace(tokensRef.current));
			setError(null);
			return;
		}
		if (action.t === "eq") {
			const current = tokensRef.current;
			try {
				const value = evaluateTokens(current, useAppStore.getState().angle);
				const expr = tokensToDisplay(current);
				if (!(current.length === 1 && current[0].k === "num") && expr.trim()) useAppStore.getState().addHistory({
					kind: "calc",
					expression: expr,
					result: formatNumber(value),
					copyValue: plainNumber(value)
				});
				setLastExpr(expr);
				setLastValue(value);
				setTokens(numberToTokens(value));
				setSettled(true);
				setError(null);
			} catch (err) {
				setError(err instanceof CalcError ? err.code : "syntax");
			}
			return;
		}
		setError(null);
		const base = action.t === "op" || action.t === "pct" || action.t === "fact" || action.t === "pow2" || action.t === "inv" ? opBase() : valueBase();
		let next = base;
		if (action.t === "digit") next = insertDigit(base, action.v);
		else if (action.t === "op") next = insertOp(base, action.v);
		else if (action.t === "fn") next = insertFn(base, action.v);
		else if (action.t === "lp") next = insertLp(base);
		else if (action.t === "rp") next = insertRp(settledRef.current ? [] : tokensRef.current);
		else if (action.t === "pct") next = insertPct(base);
		else if (action.t === "fact") next = insertFact(base);
		else if (action.t === "const") next = insertConst(base, action.v);
		else if (action.t === "pow2") {
			if (base.length === 0) return;
			next = [...insertOp(base, "^"), {
				k: "num",
				s: "2"
			}];
		} else if (action.t === "inv") {
			if (base.length === 0) return;
			next = [
				...insertOp(base, "^"),
				{ k: "lp" },
				{
					k: "op",
					v: "-"
				},
				{
					k: "num",
					s: "1"
				},
				{ k: "rp" }
			];
		} else if (action.t === "ans") {
			if (lastValueRef.current == null) return;
			next = insertNumber(valueBase(), lastValueRef.current);
		}
		setSettled(false);
		setTokens(next);
	}
	const runRef = (0, import_react.useRef)(run);
	runRef.current = run;
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (useAppStore.getState().tab !== "calc") return;
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
			const key = event.key;
			let action = null;
			if (/^\d$/.test(key)) action = {
				t: "digit",
				v: key
			};
			else if (key === ".") action = {
				t: "digit",
				v: "."
			};
			else if (key === "+") action = {
				t: "op",
				v: "+"
			};
			else if (key === "-") action = {
				t: "op",
				v: "-"
			};
			else if (key === "*") action = {
				t: "op",
				v: "*"
			};
			else if (key === "/") action = {
				t: "op",
				v: "/"
			};
			else if (key === "^") action = {
				t: "op",
				v: "^"
			};
			else if (key === "%") action = { t: "pct" };
			else if (key === "(") action = { t: "lp" };
			else if (key === ")") action = { t: "rp" };
			else if (key === "!") action = { t: "fact" };
			else if (key === "Enter" || key === "=") action = { t: "eq" };
			else if (key === "Backspace") action = { t: "bs" };
			else if (key === "Escape") action = { t: "ac" };
			if (!action) return;
			event.preventDefault();
			runRef.current(action);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const live = settled ? lastValue : tryEvaluate(tokens, angle);
	const expr = settled ? lastExpr : tokensToDisplay(tokens);
	const big = error ? t(lang, error === "math" ? "errorMath" : error === "empty" ? "errorEmpty" : "errorSyntax") : live == null ? tokens.length ? "—" : "0" : formatNumber(live);
	async function onCopy() {
		if (live == null) return;
		feedback$3();
		const ok = await copyText(plainNumber(live));
		onToast(t(lang, ok ? "copied" : "copyFail"));
	}
	const rows = sci ? [...SCI_ROWS, ...BASIC_ROWS] : BASIC_ROWS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 px-4 pt-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 rounded-full bg-surface p-1",
					role: "group",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": !sci,
						onClick: () => {
							feedback$3();
							setSci(false);
						},
						className: cn("rounded-full py-2 text-sm font-semibold", !sci ? "bg-primary text-primary-fg" : "text-muted"),
						children: t(lang, "standard")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": sci,
						onClick: () => {
							feedback$3();
							setSci(true);
						},
						className: cn("rounded-full py-2 text-sm font-semibold", sci ? "bg-primary text-primary-fg" : "text-muted"),
						children: t(lang, "scientific")
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "shrink-0 px-4 pt-3",
				dir: "ltr",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-border bg-surface px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-0 flex-1 truncate text-end text-sm text-muted",
							dir: "ltr",
							children: expr || "\xA0"
						}), sci ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t(lang, "angle"),
							onClick: () => {
								feedback$3();
								setAngle(angle === "deg" ? "rad" : "deg");
							},
							className: "rounded-full bg-primary-soft px-3 py-1 text-xs font-semibold text-primary",
							children: angle === "deg" ? "DEG" : "RAD"
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t(lang, "copy"),
							onClick: () => void onCopy(),
							className: "mb-1 grid size-11 shrink-0 place-items-center rounded-2xl text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							"aria-live": "polite",
							className: cn("min-w-0 flex-1 overflow-x-auto text-end font-semibold tabular-nums", error ? "text-xl text-primary" : "text-4xl sm:text-5xl"),
							children: big
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-3 pt-3 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-2",
					dir: "ltr",
					children: rows.flat().map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": key.aria,
						onClick: () => run(key.action),
						className: cn("flex items-center justify-center rounded-2xl font-medium tabular-nums transition active:scale-95", sci ? "h-11 text-base" : "h-12 text-lg", key.span === 2 && "col-span-2", key.tone === "num" && "bg-key text-key-fg", key.tone === "op" && "bg-op text-op-fg text-base", key.tone === "ghost" && "bg-ghost text-ghost-fg text-base", key.tone === "accent" && "bg-primary text-primary-fg text-2xl"),
						children: key.label
					}, key.id))
				})
			})
		]
	});
}
function feedback$2() {
	const { sound, haptic } = useAppStore.getState();
	tick(sound, haptic);
}
function sanitizeAmount(raw) {
	let value = raw.replace(/[^\d.,،]/g, "").replace(/[,،]/g, ".");
	const parts = value.split(".");
	if (parts.length > 2) value = `${parts[0]}.${parts.slice(1).join("")}`;
	if (value.startsWith(".")) value = `0${value}`;
	return value.slice(0, 16);
}
function CurrencyView({ onToast, onRefresh }) {
	const lang = useAppStore((s) => s.lang);
	const rates = useAppStore((s) => s.rates);
	const status = useAppStore((s) => s.rateStatus);
	const asOf = useAppStore((s) => s.rateAsOf);
	const provider = useAppStore((s) => s.rateProvider);
	const fxFrom = useAppStore((s) => s.fxFrom);
	const fxTo = useAppStore((s) => s.fxTo);
	const fxAmount = useAppStore((s) => s.fxAmount);
	const setFx = useAppStore((s) => s.setFx);
	const swapFx = useAppStore((s) => s.swapFx);
	const [picking, setPicking] = (0, import_react.useState)(null);
	const amount = fxAmount === "" || fxAmount === "." ? 0 : Number(fxAmount);
	const value = rates && Number.isFinite(amount) ? convert(amount, fxFrom, fxTo, rates) : null;
	const unit = rates ? convert(1, fxFrom, fxTo, rates) : null;
	const inverse = rates ? convert(1, fxTo, fxFrom, rates) : null;
	const effective = status === "idle" && rates ? "cached" : status;
	const count = rates ? Object.keys(rates).length : 0;
	async function copyResult() {
		if (value == null) return;
		feedback$2();
		const ok = await copyText(String(value));
		onToast(t(lang, ok ? "copied" : "copyFail"));
	}
	function saveCompare() {
		if (value == null) return;
		feedback$2();
		useAppStore.getState().addHistory({
			kind: "fx",
			expression: `${fxAmount || "0"} ${fxFrom} → ${fxTo}`,
			result: `${formatMoney(value, fxTo)} ${fxTo}`,
			copyValue: String(value)
		});
		onToast(t(lang, "saved"));
	}
	if (picking) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrencyPicker, {
		selected: picking === "from" ? fxFrom : fxTo,
		onClose: () => setPicking(null),
		onPick: (code) => {
			feedback$2();
			setFx(picking === "from" ? { fxFrom: code } : { fxTo: code });
			setPicking(null);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col overflow-y-auto px-4 pt-2 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: t(lang, "from")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								feedback$2();
								setPicking("from");
							},
							className: "rounded-full bg-primary-soft px-3 py-1 text-sm font-semibold text-primary",
							dir: "ltr",
							children: fxFrom
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-2 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: t(lang, "amount")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							inputMode: "decimal",
							value: fxAmount,
							onChange: (event) => setFx({ fxAmount: sanitizeAmount(event.target.value) }),
							className: "w-full bg-transparent text-end text-4xl font-semibold tabular-nums outline-none",
							dir: "ltr"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							feedback$2();
							setPicking("from");
						},
						className: "mt-1 text-sm text-muted",
						children: currencyLabel(fxFrom, lang)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 -my-3 flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": t(lang, "swap"),
					onClick: () => {
						feedback$2();
						swapFx();
					},
					className: "grid size-11 place-items-center rounded-full bg-primary text-primary-fg shadow-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "size-5" })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: t(lang, "to")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								feedback$2();
								setPicking("to");
							},
							className: "rounded-full bg-primary-soft px-3 py-1 text-sm font-semibold text-primary",
							dir: "ltr",
							children: fxTo
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-0 flex-1 overflow-x-auto text-end text-4xl font-semibold text-primary tabular-nums",
							dir: "ltr",
							children: effective === "loading" && !rates ? "…" : value == null ? "—" : formatMoney(value, fxTo)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t(lang, "copy"),
							onClick: () => void copyResult(),
							className: "grid size-11 shrink-0 place-items-center rounded-2xl text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							feedback$2();
							setPicking("to");
						},
						className: "mt-1 text-sm text-muted",
						children: currencyLabel(fxTo, lang)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-3xl border border-border bg-surface px-4 py-3",
				children: [
					unit != null && inverse != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1 text-sm",
						dir: "ltr",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [t(lang, "rate"), ": "]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold tabular-nums",
								children: [
									"1 ",
									fxFrom,
									" = ",
									formatRate(unit),
									" ",
									fxTo
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-end text-muted tabular-nums",
							children: [
								"1 ",
								fxTo,
								" = ",
								formatRate(inverse),
								" ",
								fxFrom
							]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: effective === "loading" ? t(lang, "loadingRates") : t(lang, "noRates")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							asOf ? `${t(lang, "updated")}: ${formatWhen(asOf, lang)}` : t(lang, "loadingRates"),
							provider ? ` · ${provider}` : "",
							count ? ` · ${count} ${t(lang, "currenciesCount")}` : ""
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								feedback$2();
								onRefresh();
							},
							className: "inline-flex items-center gap-1 rounded-full bg-surface-2 px-3 py-1 font-medium text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: cn("size-3.5", effective === "loading" && "animate-spin") }), t(lang, "refresh")]
						})]
					}),
					effective === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs font-medium text-primary",
						children: t(lang, "live")
					}) : null,
					effective === "cached" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-fg",
						children: t(lang, "cached")
					}) : null,
					effective === "cached" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: t(lang, "cachedDetail")
					}) : null,
					effective === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: t(lang, "noRates")
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: t(lang, "disclaimer")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-medium text-muted",
					children: t(lang, "pairs")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto pb-1",
					children: QUICK_PAIRS.map(([from, to]) => {
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							dir: "ltr",
							onClick: () => {
								feedback$2();
								setFx({
									fxFrom: from,
									fxTo: to
								});
							},
							className: cn("shrink-0 rounded-full border px-3 py-2 text-sm font-medium tabular-nums", fxFrom === from && fxTo === to ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface text-fg"),
							children: [
								from,
								"/",
								to
							]
						}, `${from}-${to}`);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: saveCompare,
				disabled: value == null,
				className: "mt-4 rounded-2xl bg-primary py-3 text-sm font-semibold text-primary-fg disabled:opacity-40",
				children: t(lang, "saveCompare")
			})
		]
	});
}
function CurrencyPicker({ selected, onPick, onClose }) {
	const lang = useAppStore((s) => s.lang);
	const rates = useAppStore((s) => s.rates);
	const [query, setQuery] = (0, import_react.useState)("");
	const codes = (0, import_react.useMemo)(() => Object.keys(rates ?? {}).sort(), [rates]);
	const q = query.trim().toLowerCase();
	const filtered = (0, import_react.useMemo)(() => {
		return codes.map((code) => ({
			code,
			name: currencyLabel(code, lang)
		})).filter((item) => {
			if (!q) return true;
			return item.code.toLowerCase().includes(q) || item.name.toLowerCase().includes(q) || currencyLabel(item.code, "en").toLowerCase().includes(q) || currencyLabel(item.code, "ar").includes(query.trim());
		}).sort((a, b) => a.name.localeCompare(b.name, lang === "ar" ? "ar" : "en"));
	}, [
		codes,
		lang,
		q,
		query
	]);
	const popular = POPULAR_CODES.filter((code) => codes.includes(code)).filter((code) => filtered.some((item) => item.code === code));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-4 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 items-center gap-2 rounded-2xl bg-surface px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 shrink-0 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: t(lang, "search"),
						className: "h-12 w-full bg-transparent text-sm outline-none"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": t(lang, "close"),
					onClick: onClose,
					className: "grid size-12 place-items-center rounded-2xl bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pt-3 text-sm font-medium",
				children: t(lang, "choose")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto pb-4",
				children: [
					!q && popular.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs text-muted",
							children: t(lang, "popular")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: popular.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onPick(code),
								className: cn("rounded-full px-3 py-2 text-sm font-medium", code === selected ? "bg-primary text-primary-fg" : "bg-surface text-fg"),
								dir: "ltr",
								children: code
							}, code))
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 pt-4 text-xs text-muted",
						children: t(lang, "allCurrencies")
					}),
					filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 py-6 text-sm text-muted",
						children: rates ? t(lang, "noMatch") : t(lang, "loadingRates")
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: filtered.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onPick(item.code),
						className: "flex w-full items-center gap-3 px-4 py-3 text-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-11 w-14 shrink-0 place-items-center rounded-2xl bg-surface text-sm font-semibold",
								dir: "ltr",
								children: item.code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: item.name
							}),
							item.code === selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-primary" }) : null
						]
					}) }, item.code)) })
				]
			})
		]
	});
}
function feedback$1() {
	const { sound, haptic } = useAppStore.getState();
	tick(sound, haptic);
}
function stamp(ts, lang) {
	return new Intl.DateTimeFormat(lang === "ar" ? "ar" : "en", {
		dateStyle: "medium",
		timeStyle: "short",
		numberingSystem: "latn"
	}).format(new Date(ts));
}
function HistoryList({ items, onToast, compact = false }) {
	const lang = useAppStore((s) => s.lang);
	const removeHistory = useAppStore((s) => s.removeHistory);
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: t(lang, "emptyHistory")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "rounded-2xl border border-border bg-surface px-3 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-muted",
							dir: "ltr",
							children: item.expression
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-lg font-semibold tabular-nums",
							dir: "ltr",
							children: item.result
						}),
						!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: stamp(item.ts, lang)
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": t(lang, "tapCopy"),
						onClick: () => {
							feedback$1();
							copyText(item.copyValue).then((ok) => onToast(t(lang, ok ? "copied" : "copyFail")));
						},
						className: "grid size-10 place-items-center rounded-xl text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": t(lang, "remove"),
						onClick: () => {
							feedback$1();
							removeHistory(item.id);
						},
						className: "grid size-10 place-items-center rounded-xl text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				})]
			})
		}, item.id))
	});
}
function HistoryView({ onToast }) {
	const history = useAppStore((s) => s.history);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full overflow-y-auto px-4 pt-2 pb-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryList, {
			items: history,
			onToast
		})
	});
}
function feedback() {
	const { sound, haptic } = useAppStore.getState();
	tick(sound, haptic);
}
function SettingsView({ onToast }) {
	const lang = useAppStore((s) => s.lang);
	const theme = useAppStore((s) => s.theme);
	const accent = useAppStore((s) => s.accent);
	const sound = useAppStore((s) => s.sound);
	const haptic = useAppStore((s) => s.haptic);
	const setTheme = useAppStore((s) => s.setTheme);
	const setAccent = useAppStore((s) => s.setAccent);
	const setLang = useAppStore((s) => s.setLang);
	const setSound = useAppStore((s) => s.setSound);
	const setHaptic = useAppStore((s) => s.setHaptic);
	const clearHistory = useAppStore((s) => s.clearHistory);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [install, setInstall] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		function onPrompt(event) {
			event.preventDefault();
			setInstall(event);
		}
		window.addEventListener("beforeinstallprompt", onPrompt);
		return () => window.removeEventListener("beforeinstallprompt", onPrompt);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-full overflow-y-auto px-4 pt-2 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-surface px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-3 text-sm font-medium text-muted",
						children: t(lang, "appearance")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2 py-3",
						children: [
							{
								id: "light",
								label: "light"
							},
							{
								id: "dark",
								label: "dark"
							},
							{
								id: "system",
								label: "system"
							}
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": theme === item.id,
							onClick: () => {
								feedback();
								setTheme(item.id);
							},
							className: cn("rounded-2xl py-3 text-sm font-medium", theme === item.id ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"),
							children: t(lang, item.label)
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-muted",
						children: t(lang, "accent")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-2 py-3",
						children: [
							{
								id: "gold",
								label: "gold",
								swatch: "bg-swatch-gold"
							},
							{
								id: "jade",
								label: "jade",
								swatch: "bg-swatch-jade"
							},
							{
								id: "cobalt",
								label: "cobalt",
								swatch: "bg-swatch-cobalt"
							},
							{
								id: "coral",
								label: "coral",
								swatch: "bg-swatch-coral"
							}
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": accent === item.id,
							"aria-label": t(lang, item.label),
							onClick: () => {
								feedback();
								setAccent(item.id);
							},
							className: cn("flex flex-col items-center gap-2 rounded-2xl py-3 text-xs", accent === item.id ? "bg-primary-soft" : "bg-surface-2"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-6 rounded-full", item.swatch) }), t(lang, item.label)]
						}, item.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-3xl border border-border bg-surface px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-3 text-sm font-medium text-muted",
						children: t(lang, "language")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": lang === "ar",
							onClick: () => {
								feedback();
								setLang("ar");
							},
							className: cn("rounded-2xl py-3 text-sm font-medium", lang === "ar" ? "bg-primary text-primary-fg" : "bg-surface-2"),
							children: "العربية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": lang === "en",
							onClick: () => {
								feedback();
								setLang("en");
							},
							className: cn("rounded-2xl py-3 text-sm font-medium", lang === "en" ? "bg-primary text-primary-fg" : "bg-surface-2"),
							children: "English"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						title: t(lang, "sound"),
						hint: t(lang, "soundHint"),
						on: sound,
						onChange: (value) => {
							setSound(value);
							if (value) tick(true, false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						title: t(lang, "haptic"),
						hint: t(lang, "hapticHint"),
						on: haptic,
						onChange: (value) => {
							setHaptic(value);
							if (value) tick(false, true);
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-3 rounded-3xl border border-border bg-surface px-4 py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						feedback();
						if (!confirm) {
							setConfirm(true);
							return;
						}
						clearHistory();
						setConfirm(false);
						onToast(t(lang, "historyCleared"));
					},
					className: "w-full rounded-2xl bg-surface-2 py-3 text-sm font-semibold",
					children: confirm ? t(lang, "confirmClear") : t(lang, "clearHistory")
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-3xl border border-border bg-surface px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold",
						children: t(lang, "about")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted",
						children: t(lang, "aboutBody")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted",
						children: t(lang, "disclaimer")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted",
						children: t(lang, "privacy")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted",
						children: t(lang, "version")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-3xl border border-border bg-surface px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold",
						children: t(lang, "install")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted",
						children: t(lang, "installLead")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-3 list-decimal space-y-2 ps-5 text-sm leading-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t(lang, "install1") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t(lang, "install2") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t(lang, "install3") })
						]
					}),
					install ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							feedback();
							install.prompt();
							setInstall(null);
						},
						className: "mt-4 w-full rounded-2xl bg-primary py-3 text-sm font-semibold text-primary-fg",
						children: t(lang, "installNow")
					}) : null
				]
			})
		]
	});
}
function Toggle({ title, hint, on, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-4 border-t border-border py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: hint
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			role: "switch",
			"aria-checked": on,
			onClick: () => onChange(!on),
			className: cn("flex h-7 w-12 shrink-0 items-center rounded-full p-1", on ? "justify-end bg-primary" : "justify-start bg-surface-2"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-5 rounded-full", on ? "bg-primary-fg" : "bg-fg") })
		})]
	});
}
var TABS = [
	{
		id: "calc",
		icon: Calculator,
		key: "calculator"
	},
	{
		id: "fx",
		icon: ArrowLeftRight,
		key: "currency"
	},
	{
		id: "history",
		icon: History,
		key: "history"
	},
	{
		id: "settings",
		icon: Settings,
		key: "settings"
	}
];
function applyTheme() {
	const state = useAppStore.getState();
	let mode = state.theme === "light" ? "light" : "dark";
	if (state.theme === "system") mode = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
	const root = document.documentElement;
	root.dataset.mode = mode;
	root.dataset.accent = state.accent;
	root.lang = state.lang;
	root.dir = state.lang === "ar" ? "rtl" : "ltr";
	document.querySelector("meta[name=\"theme-color\"]")?.setAttribute("content", mode === "light" ? "#f3efe6" : "#12130f");
	return mode;
}
function App() {
	const lang = useAppStore((s) => s.lang);
	const tab = useAppStore((s) => s.tab);
	const theme = useAppStore((s) => s.theme);
	const setTab = useAppStore((s) => s.setTab);
	const setTheme = useAppStore((s) => s.setTheme);
	const rates = useAppStore((s) => s.rates);
	const history = useAppStore((s) => s.history);
	const [toast, setToast] = (0, import_react.useState)(null);
	const [nonce, setNonce] = (0, import_react.useState)(0);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let unsub = () => {};
		let mq = null;
		const onMq = () => applyTheme();
		Promise.resolve(useAppStore.persist.rehydrate()).then(() => {
			applyTheme();
			unsub = useAppStore.subscribe(() => applyTheme());
			mq = window.matchMedia("(prefers-color-scheme: dark)");
			mq.addEventListener("change", onMq);
			setReady(true);
		});
		return () => {
			unsub();
			mq?.removeEventListener("change", onMq);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const ac = new AbortController();
		let alive = true;
		const existing = useAppStore.getState().rates;
		useAppStore.getState().setRateStatus(existing ? "cached" : "loading");
		fetchRateBook(ac.signal).then((book) => {
			if (!alive) return;
			useAppStore.getState().applyBook(book, "live");
		}).catch(() => {
			if (!alive || ac.signal.aborted) return;
			const state = useAppStore.getState();
			state.setRateStatus(state.rates ? "cached" : "error");
		});
		return () => {
			alive = false;
			ac.abort();
		};
	}, [ready, nonce]);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const id = window.setTimeout(() => setToast(null), 1800);
		return () => window.clearTimeout(id);
	}, [toast]);
	function notify(message) {
		setToast(message);
	}
	function toggleTheme() {
		const { sound, haptic } = useAppStore.getState();
		tick(sound, haptic);
		const resolved = theme === "system" ? window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light" : theme;
		setTheme(resolved === "dark" ? "light" : "dark");
	}
	const resolvedDark = theme === "dark" || theme === "system" && typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh w-full max-w-5xl overflow-hidden bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex h-full min-h-0 w-full max-w-md flex-col overflow-hidden lg:mx-0 lg:border-e lg:border-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex shrink-0 items-center gap-3 px-4 pt-4 pb-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 place-items-center rounded-2xl bg-primary text-primary-fg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate text-base font-semibold tracking-tight",
								children: t(lang, "appName")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted",
								children: t(lang, "subtitle")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": t(lang, "theme"),
							onClick: toggleTheme,
							className: "grid size-11 place-items-center rounded-2xl bg-surface",
							children: resolvedDark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "min-h-0 flex-1 overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: tab === "calc" ? "h-full" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalculatorView, { onToast: notify })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: tab === "fx" ? "h-full" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrencyView, {
								onToast: notify,
								onRefresh: () => setNonce((n) => n + 1)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: tab === "history" ? "h-full" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryView, { onToast: notify })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: tab === "settings" ? "h-full" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, { onToast: notify })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "safe-bottom grid shrink-0 grid-cols-4 border-t border-border bg-surface px-2 pt-1",
					children: TABS.map((item) => {
						const Icon = item.icon;
						const active = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-current": active ? "page" : void 0,
							onClick: () => {
								const { sound, haptic } = useAppStore.getState();
								tick(sound, haptic);
								setTab(item.id);
							},
							className: cn("flex flex-col items-center gap-1 rounded-2xl py-2 text-xs font-medium", active ? "text-primary" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), t(lang, item.key)]
						}, item.id);
					})
				}),
				toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-x-0 top-4 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-fg",
						children: toast
					})
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden min-h-0 flex-1 overflow-y-auto px-8 py-8 lg:block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: t(lang, "spotlight")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-3",
					children: QUICK_PAIRS.map(([from, to]) => {
						const rate = rates ? convert(1, from, to, rates) : null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								useAppStore.getState().setFx({
									fxFrom: from,
									fxTo: to
								});
								setTab("fx");
							},
							className: "flex items-center justify-between rounded-3xl border border-border bg-surface px-4 py-4 text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-medium",
								dir: "ltr",
								children: [
									from,
									" / ",
									to
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-semibold tabular-nums",
								dir: "ltr",
								children: rate == null ? "—" : formatRate(rate)
							})]
						}, `${from}-${to}`);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm font-medium text-muted",
					children: t(lang, "recent")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryList, {
						items: history.slice(0, 5),
						onToast: notify,
						compact: true
					})
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {});
}
//#endregion
export { Home as component };
