import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CLBFGspg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SQUAD = [
	"انصار خان",
	"بلال افریدی",
	"ولي نور",
	"حمزه شینواري",
	"طارق یوسفزی",
	"فرید کاکړ",
	"سامي دراني",
	"نسیم ګل",
	"روحان قادر",
	"الیاس مروت",
	"ظفر مهمند"
];
var BOWLERS = [
	"کامران شاه",
	"ادیل روف",
	"یونس سپین",
	"هارون جان"
];
var SHOTS = [
	{
		id: "straight",
		ps: "سټریټ",
		en: "Drive"
	},
	{
		id: "cover",
		ps: "کور",
		en: "Cover"
	},
	{
		id: "pull",
		ps: "پل",
		en: "Pull"
	},
	{
		id: "sweep",
		ps: "سویپ",
		en: "Sweep"
	},
	{
		id: "loft",
		ps: "شپږ",
		en: "Loft"
	},
	{
		id: "block",
		ps: "دفاع",
		en: "Block"
	}
];
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function rollDelivery(rng, overIndex) {
	const bowler = BOWLERS[overIndex % BOWLERS.length];
	const spin = overIndex % 4 === 2;
	const r = rng();
	const length = r < .14 ? "yorker" : r < .4 ? "full" : r < .72 ? "good" : r < .9 ? "short" : "bouncer";
	const lineRoll = rng();
	return {
		length,
		line: lineRoll < .38 ? "off" : lineRoll < .72 ? "middle" : "leg",
		kind: spin ? "spin" : rng() < .45 ? "swing" : "pace",
		bowler
	};
}
/** timingError is seconds relative to the ideal contact (negative = early). */
function judgeTiming(timingError) {
	const a = Math.abs(timingError);
	if (a < .055) return "perfect";
	if (a < .11) return "good";
	if (a < .2) return "ok";
	return "miss";
}
function fit(shot, d) {
	let s = .45;
	if (shot === "block") return d.length === "bouncer" ? .35 : .85;
	if (shot === "loft") {
		if (d.length === "short" || d.length === "good") s = .9;
		else if (d.length === "full") s = .62;
		else if (d.length === "bouncer") s = .55;
		else s = .18;
	} else if (shot === "pull") {
		if (d.length === "short" || d.length === "bouncer") s = d.line === "off" ? .45 : .92;
		else if (d.length === "good") s = .5;
		else s = .22;
	} else if (shot === "sweep") {
		if (d.kind === "spin" && (d.length === "full" || d.length === "good") && d.line !== "off") s = .9;
		else if (d.length === "yorker") s = .15;
		else s = .4;
	} else if (shot === "cover") {
		if ((d.length === "full" || d.length === "good") && d.line !== "leg") s = .88;
		else if (d.length === "short") s = .35;
		else s = .5;
	} else if (shot === "straight") {
		if (d.length === "full" || d.length === "yorker" || d.length === "good") s = d.line === "leg" ? .55 : .86;
		else s = .4;
	}
	return s;
}
function pickRuns(shot, grade, match, rng) {
	const boost = match > .75 ? 1 : match > .5 ? .65 : .35;
	const roll = rng();
	if (grade === "miss") return roll < .15 ? 1 : 0;
	if (shot === "block") return grade === "perfect" && roll < .25 ? 1 : 0;
	if (shot === "loft") {
		if (grade === "perfect" && boost > .6) return roll < .78 ? 6 : 4;
		if (grade === "good") return roll < .45 * boost + .15 ? 6 : roll < .7 ? 4 : 2;
		if (grade === "ok") return roll < .35 ? 4 : roll < .6 ? 2 : 1;
		return roll < .2 ? 2 : 0;
	}
	if (grade === "perfect") {
		if (roll < .15 * boost) return 6;
		if (roll < .72) return 4;
		return roll < .88 ? 2 : 1;
	}
	if (grade === "good") {
		if (roll < .42 * boost) return 4;
		if (roll < .7) return 2;
		return roll < .85 ? 1 : 0;
	}
	if (roll < .22) return 2;
	if (roll < .55) return 1;
	return 0;
}
function wicketHow(shot, d, rng) {
	const r = rng();
	if (!shot || shot === "block" || d.length === "yorker") return r < .7 ? "بولډ" : "LBW";
	if (shot === "loft" || shot === "pull") return r < .75 ? "کیچ" : "بولډ";
	if (r < .45) return "کیچ";
	if (r < .75) return "LBW";
	return "بولډ";
}
function blurb(runs, wicket, how, shot, grade) {
	if (wicket) {
		if (how === "بولډ") return "اوټ! سټمپونه مات شول.";
		if (how === "کیچ") return "اوټ! په هوا کې کیچ ونیول شو.";
		return "اوټ! امپیر ګوته پورته کړه — LBW.";
	}
	if (runs === 6) return grade === "perfect" ? "شپږ! بال له لوبغالي ووت." : "شپږ! لوړ شاټ پولې ته ولاړ.";
	if (runs === 4) return "څلور! بال پولې ته ورسېد.";
	if (runs === 3) return "درې منډې. ښه منډې وهل.";
	if (runs === 2) return "دوه منډې.";
	if (runs === 1) return "یوه منډه.";
	if (!shot) return "شاټ ونه شو. ډاټ بال.";
	if (shot === "block") return "کلین دفاع. منډه نشته.";
	return "بیټر بال ته ونه رسېد.";
}
function resolveBall(d, shot, timingError, rng) {
	if (shot == null || timingError == null) {
		if ((d.length === "yorker" || d.length === "full") && d.line !== "off" && rng() < (d.length === "yorker" ? .55 : .22)) return {
			runs: 0,
			wicket: true,
			how: "بولډ",
			text: "شاټ نشته — بال سټمپونه یوړل.",
			timing: "miss",
			shot: null
		};
		return {
			runs: 0,
			wicket: false,
			how: "",
			text: "شاټ ونه شو. ډاټ بال.",
			timing: "miss",
			shot: null
		};
	}
	const grade = judgeTiming(timingError);
	const match = fit(shot, d);
	let wicketP = .02;
	if (grade === "miss") wicketP = .62;
	else if (grade === "ok") wicketP = .16 + (1 - match) * .28;
	else if (grade === "good") wicketP = .04 + (1 - match) * .2;
	else wicketP = .012 + (1 - match) * .08;
	if (shot === "block" && grade !== "miss") wicketP *= .35;
	if (d.length === "yorker" && shot === "loft") wicketP = Math.max(wicketP, grade === "perfect" ? .12 : .45);
	if (rng() < wicketP) {
		const how = wicketHow(shot, d, rng);
		return {
			runs: 0,
			wicket: true,
			how,
			text: blurb(0, true, how, shot, grade),
			timing: grade,
			shot
		};
	}
	let runs = pickRuns(shot, grade, match, rng);
	if (grade === "miss") runs = 0;
	return {
		runs,
		wicket: false,
		how: "",
		text: blurb(runs, false, "", shot, grade),
		timing: grade,
		shot
	};
}
function freshInnings() {
	return {
		runs: 0,
		wickets: 0,
		balls: 0,
		striker: 0,
		nonStriker: 1,
		nextBatter: 2,
		scores: Array(11).fill(0),
		ballsFaced: Array(11).fill(0),
		recent: []
	};
}
function applyBall(inn, result, legal = true) {
	const next = {
		...inn,
		scores: inn.scores.slice(),
		ballsFaced: inn.ballsFaced.slice(),
		recent: inn.recent.slice()
	};
	if (result.wicket) {
		next.wickets += 1;
		next.ballsFaced[next.striker] += 1;
		next.recent.push("W");
		if (next.wickets < 10) {
			next.striker = next.nextBatter;
			next.nextBatter += 1;
		}
	} else {
		next.runs += result.runs;
		next.scores[next.striker] += result.runs;
		next.ballsFaced[next.striker] += 1;
		next.recent.push(String(result.runs));
		if (result.runs % 2 === 1) {
			const s = next.striker;
			next.striker = next.nonStriker;
			next.nonStriker = s;
		}
	}
	if (legal) next.balls += 1;
	if (next.recent.length > 12) next.recent = next.recent.slice(-12);
	if (legal && next.balls % 6 === 0 && !result.wicket) {
		const s = next.striker;
		next.striker = next.nonStriker;
		next.nonStriker = s;
	} else if (legal && next.balls % 6 === 0 && result.wicket) {
		const s = next.striker;
		next.striker = next.nonStriker;
		next.nonStriker = s;
	}
	return next;
}
/** Silent AI innings so the chase has a fair target. */
function simulateAiInnings(overs, seed) {
	const rng = mulberry32(seed);
	const max = overs * 6;
	const balls = [];
	let runs = 0;
	let wickets = 0;
	for (let i = 0; i < max && wickets < 10; i++) {
		const d = rollDelivery(rng, Math.floor(i / 6));
		const shots = [
			"straight",
			"cover",
			"pull",
			"sweep",
			"loft",
			"block"
		];
		const shot = shots[Math.floor(rng() * shots.length)];
		const res = resolveBall(d, shot, (rng() - .42) * .34, rng);
		balls.push(res);
		if (res.wicket) wickets += 1;
		else runs += res.runs;
	}
	return {
		runs,
		wickets,
		balls
	};
}
var CONTACT_AT = .74;
var BALL_SECONDS = 1.55;
function overBallLabel(balls) {
	return `${Math.floor(balls / 6)}.${balls % 6}`;
}
function roundRect(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.arcTo(x + w, y, x + w, y + h, r);
	ctx.arcTo(x + w, y + h, x, y + h, r);
	ctx.arcTo(x, y + h, x, y, r);
	ctx.arcTo(x, y, x + w, y, r);
	ctx.closePath();
}
function drawPitch(ctx, w, h, s) {
	ctx.clearRect(0, 0, w, h);
	const sky = ctx.createLinearGradient(0, 0, 0, h);
	sky.addColorStop(0, "#07111c");
	sky.addColorStop(.45, "#0c2418");
	sky.addColorStop(1, "#12351f");
	ctx.fillStyle = sky;
	ctx.fillRect(0, 0, w, h);
	ctx.fillStyle = "#0d1c14";
	ctx.fillRect(0, h * .18, w, h * .22);
	for (let i = 0; i < 48; i++) {
		const x = i * 97 % w;
		const y = h * .22 + i * 53 % (h * .14);
		ctx.fillStyle = i % 3 === 0 ? "#e8b84a" : i % 3 === 1 ? "#f4efe4" : "#2f6b45";
		ctx.globalAlpha = .55;
		ctx.fillRect(x, y, 4, 4);
		ctx.globalAlpha = 1;
	}
	for (const lx of [w * .18, w * .82]) {
		const g = ctx.createRadialGradient(lx, h * .08, 4, lx, h * .2, w * .28);
		g.addColorStop(0, "rgba(244,239,228,0.35)");
		g.addColorStop(1, "rgba(244,239,228,0)");
		ctx.fillStyle = g;
		ctx.fillRect(lx - w * .28, 0, w * .56, h * .55);
		ctx.fillStyle = "#d7d2c4";
		ctx.fillRect(lx - 16, h * .05, 32, 8);
	}
	const groundY = h * .62;
	const grass = ctx.createLinearGradient(0, groundY - 20, 0, h);
	grass.addColorStop(0, "#1f8a40");
	grass.addColorStop(1, "#0e4d24");
	ctx.fillStyle = grass;
	ctx.fillRect(0, groundY - 10, w, h);
	const px = w * .18;
	const pw = w * .64;
	const py = groundY;
	const ph = h * .16;
	ctx.fillStyle = "#c4a36a";
	ctx.beginPath();
	ctx.moveTo(px + pw * .08, py);
	ctx.lineTo(px + pw * .92, py);
	ctx.lineTo(px + pw, py + ph);
	ctx.lineTo(px, py + ph);
	ctx.closePath();
	ctx.fill();
	ctx.strokeStyle = "rgba(255,255,255,0.35)";
	ctx.lineWidth = 2;
	ctx.stroke();
	ctx.strokeStyle = "rgba(255,255,255,0.8)";
	ctx.lineWidth = 2;
	const creaseX = px + pw * .78;
	ctx.beginPath();
	ctx.moveTo(creaseX, py + 6);
	ctx.lineTo(creaseX, py + ph - 6);
	ctx.stroke();
	drawStumps(ctx, px + pw * .16, py + ph * .15, h * .055, false);
	const bailFly = s.result?.wicket && s.result.how === "بولډ" ? Math.min(1, (s.progress - CONTACT_AT) * 4) : 0;
	drawStumps(ctx, creaseX + 8, py + ph * .05, h * .09, true, bailFly);
	for (const [fx, fy] of [
		[.3, .5],
		[.55, .48],
		[.42, .78],
		[.7, .84],
		[.12, .72],
		[.88, .7]
	]) drawFielder(ctx, w * fx, h * fy);
	const ballT = s.delivery ? Math.min(Math.max(s.progress, 0), 1) : 0;
	const bowlerX = px + pw * .2;
	const batterX = creaseX - w * .03;
	drawBowler(ctx, bowlerX - (1 - Math.min(ballT / .28, 1)) * w * .08, py + ph * .35, h);
	const flight = ballT < .28 ? 0 : (ballT - .28) / .72;
	const startX = bowlerX + 10;
	const bx = startX + (batterX + 6 - startX) * Math.min(flight, 1);
	const lengthHop = s.delivery?.length === "bouncer" ? .34 : s.delivery?.length === "short" ? .24 : s.delivery?.length === "yorker" ? .08 : .16;
	const arc = Math.sin(Math.min(flight, 1) * Math.PI) * h * lengthHop;
	const by = py + ph * .45 - arc;
	if (s.delivery && flight > 0 && flight < 1.05) {
		ctx.fillStyle = "rgba(0,0,0,0.25)";
		ctx.beginPath();
		ctx.ellipse(bx, py + ph * .72, 7, 3, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#f4efe4";
		ctx.beginPath();
		ctx.arc(bx, by, 7, 0, Math.PI * 2);
		ctx.fill();
		ctx.strokeStyle = "#c0392b";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.arc(bx, by, 7, .2, 1.4);
		ctx.stroke();
	}
	const swinging = s.shot != null && ballT > .66;
	drawBatter(ctx, batterX, py + ph * .15, h, swinging, s.shot);
	if (s.delivery && !s.result && ballT > .35 && ballT < .82 && !s.shot) {
		const remain = (CONTACT_AT - ballT) / (CONTACT_AT - .35);
		const radius = 18 + remain * 46;
		ctx.beginPath();
		ctx.arc(batterX + 18, py + ph * .35, radius, 0, Math.PI * 2);
		ctx.strokeStyle = remain < .18 ? "#e8b84a" : "rgba(244,239,228,0.85)";
		ctx.lineWidth = 3;
		ctx.stroke();
	}
	if (s.result && s.progress > .74) {
		const label = s.result.wicket ? "اوټ" : s.result.runs === 0 ? "۰" : String(s.result.runs);
		ctx.save();
		ctx.translate((s.shake || 0) * 4, 0);
		ctx.fillStyle = s.result.wicket ? "#e15b4a" : s.result.runs >= 4 ? "#e8b84a" : "#f4efe4";
		ctx.font = `700 ${Math.floor(h * .16)}px Oswald, sans-serif`;
		ctx.textAlign = "center";
		ctx.fillText(label, w * .5, h * .28);
		ctx.restore();
	}
	if (s.delivery && ballT > .3 && ballT < .7 && !s.result) {
		ctx.fillStyle = "rgba(7,20,12,0.72)";
		roundRect(ctx, w * .38, h * .08, w * .24, h * .07, 8);
		ctx.fill();
		ctx.fillStyle = "#f4efe4";
		ctx.font = `700 ${Math.floor(h * .035)}px "Noto Sans Arabic", sans-serif`;
		ctx.textAlign = "center";
		const hint = s.delivery.length === "yorker" ? "یارکر" : s.delivery.length === "full" ? "فل" : s.delivery.length === "good" ? "ښه اوږدوالی" : s.delivery.length === "short" ? "لنډ" : "بانسر";
		ctx.fillText(hint, w * .5, h * .125);
	}
}
function drawStumps(ctx, x, y, h, near, bailFly = 0) {
	ctx.strokeStyle = near ? "#f4efe4" : "#d9d3c4";
	ctx.lineWidth = near ? 3 : 2;
	const gap = near ? 7 : 5;
	for (let i = -1; i <= 1; i++) {
		ctx.beginPath();
		ctx.moveTo(x + i * gap, y);
		ctx.lineTo(x + i * gap, y + h);
		ctx.stroke();
	}
	ctx.strokeStyle = "#e8b84a";
	ctx.lineWidth = 2;
	ctx.beginPath();
	const by = y - bailFly * 28;
	const bx = bailFly * 18;
	ctx.moveTo(x - gap + bx, by);
	ctx.lineTo(x + gap + bx, by);
	ctx.stroke();
}
function drawFielder(ctx, x, y) {
	ctx.fillStyle = "#163e28";
	ctx.beginPath();
	ctx.arc(x, y - 10, 5, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillRect(x - 4, y - 6, 8, 12);
}
function drawBowler(ctx, x, y, h) {
	const s = h * .012;
	ctx.save();
	ctx.translate(x, y);
	ctx.fillStyle = "#1d4ed8";
	ctx.fillRect(-6 * s, -18 * s, 12 * s, 22 * s);
	ctx.fillStyle = "#f4efe4";
	ctx.beginPath();
	ctx.arc(0, -24 * s, 6 * s, 0, Math.PI * 2);
	ctx.fill();
	ctx.strokeStyle = "#1d4ed8";
	ctx.lineWidth = 3;
	ctx.beginPath();
	ctx.moveTo(4 * s, -12 * s);
	ctx.lineTo(16 * s, -22 * s);
	ctx.stroke();
	ctx.restore();
}
function drawBatter(ctx, x, y, h, swing, shot) {
	const s = h * .016;
	ctx.save();
	ctx.translate(x, y);
	ctx.fillStyle = "#f4efe4";
	ctx.fillRect(-4 * s, 2 * s, 5 * s, 16 * s);
	ctx.fillRect(2 * s, 2 * s, 5 * s, 16 * s);
	ctx.fillStyle = "#e8b84a";
	ctx.fillRect(-7 * s, -16 * s, 14 * s, 18 * s);
	ctx.fillStyle = "#2a1d05";
	ctx.fillRect(-7 * s, -10 * s, 14 * s, 3 * s);
	ctx.fillStyle = "#2a1d05";
	ctx.beginPath();
	ctx.arc(0, -22 * s, 6.5 * s, 0, Math.PI * 2);
	ctx.fill();
	ctx.strokeStyle = "#e8b84a";
	ctx.lineWidth = 2;
	ctx.stroke();
	ctx.save();
	ctx.translate(8 * s, -4 * s);
	const ang = swing ? shot === "pull" || shot === "sweep" ? -1.4 : shot === "block" ? -.3 : -1.05 : -.45;
	ctx.rotate(ang);
	ctx.fillStyle = "#f3e2b8";
	ctx.fillRect(-2 * s, -18 * s, 4 * s, 22 * s);
	ctx.fillStyle = "#8d5a2b";
	ctx.fillRect(-2.4 * s, 2 * s, 4.8 * s, 8 * s);
	ctx.restore();
	ctx.restore();
}
var HOLD = .85;
var audioCtx = null;
function beep(freq, dur, type = "square", gain = .05) {
	const Ctx = window.AudioContext || window.webkitAudioContext;
	if (!Ctx) return;
	audioCtx = audioCtx ?? new Ctx();
	if (audioCtx.state === "suspended") audioCtx.resume();
	const o = audioCtx.createOscillator();
	const g = audioCtx.createGain();
	o.type = type;
	o.frequency.value = freq;
	g.gain.value = gain;
	g.gain.exponentialRampToValueAtTime(1e-4, audioCtx.currentTime + dur);
	o.connect(g);
	g.connect(audioCtx.destination);
	o.start();
	o.stop(audioCtx.currentTime + dur);
}
function loadBest() {
	try {
		return Number(localStorage.getItem("ansar-best") || "0") || 0;
	} catch {
		return 0;
	}
}
function CricketApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const [overs, setOvers] = (0, import_react.useState)(5);
	const [screen, setScreen] = (0, import_react.useState)("menu");
	const [target, setTarget] = (0, import_react.useState)(0);
	const [aiWkts, setAiWkts] = (0, import_react.useState)(0);
	const [innings, setInnings] = (0, import_react.useState)(() => freshInnings());
	const [comment, setComment] = (0, import_react.useState)("حلقه برابره کړه، بیا شاټ ووهه.");
	const [best, setBest] = (0, import_react.useState)(0);
	const [won, setWon] = (0, import_react.useState)(null);
	const [aiFlash, setAiFlash] = (0, import_react.useState)("0/0");
	const live = (0, import_react.useRef)({
		screen: "menu",
		innings: freshInnings(),
		delivery: null,
		result: null,
		shot: null,
		timing: null,
		elapsed: 0,
		rng: mulberry32(1),
		target: 0,
		overs: 5,
		shake: 0,
		resolved: false,
		finishing: false
	});
	const api = (0, import_react.useRef)({
		beginBall: () => {},
		finishChase: (_inn, _tgt) => {}
	});
	(0, import_react.useEffect)(() => {
		setBest(loadBest());
	}, []);
	function beginBall() {
		const L = live.current;
		const overIndex = Math.floor(L.innings.balls / 6);
		const d = rollDelivery(L.rng, overIndex);
		L.delivery = d;
		L.result = null;
		L.shot = null;
		L.timing = null;
		L.elapsed = 0;
		L.resolved = false;
		setComment(`${d.bowler} را روان دی…`);
	}
	function finishChase(inn, tgt) {
		const L = live.current;
		if (L.screen !== "play") return;
		L.screen = "result";
		L.delivery = null;
		let outcome = "lose";
		if (inn.runs >= tgt) outcome = "win";
		else if (inn.runs === tgt - 1) outcome = "tie";
		setWon(outcome);
		setScreen("result");
		setInnings(inn);
		if (outcome === "win") {
			setBest((prev) => {
				const next = Math.max(prev, inn.runs);
				try {
					localStorage.setItem("ansar-best", String(next));
				} catch {}
				return next;
			});
			setComment(`انصار وګټله. ${inn.runs} منډې په ${overBallLabel(inn.balls)} کې.`);
		} else if (outcome === "tie") setComment("لوبه مساوي شوه.");
		else setComment(`سیال وګټله. ${tgt - 1 - inn.runs} منډې پاتې وې.`);
	}
	api.current.beginBall = beginBall;
	api.current.finishChase = finishChase;
	(0, import_react.useEffect)(() => {
		const c = canvasRef.current;
		if (!c) return;
		let raf = 0;
		let last = performance.now();
		const frame = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			const L = live.current;
			if (L.screen === "play" && L.delivery && !L.resolved) {
				L.elapsed += dt;
				if (L.elapsed / 1.55 >= 1) {
					L.resolved = true;
					const res = resolveBall(L.delivery, L.shot, L.timing, L.rng);
					L.result = res;
					const nextInn = applyBall(L.innings, res);
					L.innings = nextInn;
					setInnings(nextInn);
					setComment(res.text);
					L.shake = res.wicket || res.runs >= 4 ? 1 : 0;
					if (res.wicket) beep(140, .25, "sawtooth", .06);
					else if (res.runs === 6) beep(520, .18, "triangle", .07);
					else if (res.runs === 4) beep(420, .12, "triangle", .06);
					else if (res.runs > 0) beep(300, .08, "square", .04);
					else beep(180, .05, "square", .03);
					if ((nextInn.wickets >= 10 || nextInn.balls >= L.overs * 6 || nextInn.runs >= L.target) && !L.finishing) {
						L.finishing = true;
						window.setTimeout(() => api.current.finishChase(nextInn, L.target), 900);
					}
				}
			} else if (L.screen === "play" && L.delivery && L.resolved) {
				L.elapsed += dt;
				if (L.elapsed > 1.55 + HOLD && !L.finishing) {
					if (!(L.innings.wickets >= 10 || L.innings.balls >= L.overs * 6 || L.innings.runs >= L.target)) api.current.beginBall();
				}
			}
			if (L.shake > 0) L.shake = Math.max(0, L.shake - dt * 2.2);
			const rect = c.getBoundingClientRect();
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			const bw = Math.max(2, Math.floor(rect.width * dpr));
			const bh = Math.max(2, Math.floor(rect.height * dpr));
			if (c.width !== bw || c.height !== bh) {
				c.width = bw;
				c.height = bh;
			}
			const ctx = c.getContext("2d");
			if (ctx && rect.width > 0 && rect.height > 0) {
				ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
				const sx = L.shake > 0 ? (Math.random() - .5) * 8 * L.shake : 0;
				ctx.save();
				ctx.translate(sx, 0);
				drawPitch(ctx, rect.width, rect.height, {
					delivery: L.delivery,
					innings: L.innings,
					target: L.target,
					progress: L.delivery ? L.elapsed / BALL_SECONDS : 0,
					shot: L.shot,
					result: L.result,
					shake: L.shake,
					batterName: SQUAD[L.innings.striker] ?? "",
					bowlerName: L.delivery?.bowler ?? ""
				});
				ctx.restore();
			}
			raf = requestAnimationFrame(frame);
		};
		raf = requestAnimationFrame(frame);
		return () => cancelAnimationFrame(raf);
	}, []);
	function startMatch(chosenOvers) {
		beep(330, .08, "square", .04);
		const seed = (Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0;
		const ai = simulateAiInnings(chosenOvers, seed);
		const tgt = Math.max(1, ai.runs + 1);
		const inn = freshInnings();
		live.current = {
			screen: "ai",
			innings: inn,
			delivery: null,
			result: null,
			shot: null,
			timing: null,
			elapsed: 0,
			rng: mulberry32(seed ^ 2654435769),
			target: tgt,
			overs: chosenOvers,
			shake: 0,
			resolved: false,
			finishing: false
		};
		setOvers(chosenOvers);
		setTarget(tgt);
		setAiWkts(ai.wickets);
		setInnings(inn);
		setWon(null);
		setScreen("ai");
		setComment("سیالان بیټ کوي…");
		setAiFlash("0/0");
		let i = 0;
		let runs = 0;
		let wk = 0;
		const tick = () => {
			if (live.current.screen !== "ai") return;
			if (i >= ai.balls.length) {
				setAiFlash(`${runs}/${wk}`);
				goPlay();
				return;
			}
			const b = ai.balls[i];
			if (b.wicket) wk += 1;
			else runs += b.runs;
			i += 1;
			setAiFlash(`${runs}/${wk}`);
			window.setTimeout(tick, 60);
		};
		window.setTimeout(tick, 240);
	}
	function goPlay() {
		if (live.current.screen === "play" || live.current.screen === "result") return;
		live.current.screen = "play";
		setScreen("play");
		setComment("ستا وار دی. حلقه سمه کړه او شاټ ووهه.");
		beginBall();
	}
	function playShot(shot) {
		const L = live.current;
		if (L.screen !== "play" || !L.delivery || L.shot || L.resolved) return;
		if (L.elapsed / 1.55 < .22) {
			setComment("ډیر وختي! بال ته انتظار وکړه.");
			return;
		}
		L.shot = shot;
		L.timing = L.elapsed - CONTACT_AT * BALL_SECONDS;
		beep(640, .05, "square", .04);
	}
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const shot = {
				Digit1: "straight",
				Digit2: "cover",
				Digit3: "pull",
				Digit4: "sweep",
				Digit5: "loft",
				Digit6: "block"
			}[e.code];
			if (shot) playShot(shot);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	const ballsLeft = overs * 6 - innings.balls;
	const need = Math.max(0, target - innings.runs);
	const rrr = ballsLeft > 0 ? (need / ballsLeft * 6).toFixed(2) : "0";
	const striker = SQUAD[innings.striker] ?? "—";
	const non = SQUAD[innings.nonStriker] ?? "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-[100dvh] flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-score text-xl tracking-wide text-gold",
					children: "انصار کرکټ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "د شپې لوبغالی · بیټنګ"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-score text-sm text-muted",
					children: ["غوره ", best]
				})]
			}),
			screen === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2 px-3 py-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface px-2 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "انصار"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-score text-2xl leading-none",
								children: [
									innings.runs,
									"/",
									innings.wickets
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-score text-xs text-muted",
								children: overBallLabel(innings.balls)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface px-2 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "هدف"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-score text-2xl leading-none text-gold",
								children: target
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									"سیال ",
									Math.max(0, target - 1),
									"/",
									aiWkts
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface px-2 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "اړتیا"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-score text-2xl leading-none",
								children: need
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-score text-xs text-muted",
								children: ["RRR ", rrr]
							})
						]
					})
				]
			}),
			screen === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate px-4 pb-1 text-center text-sm text-muted",
				children: comment
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: screen === "play" ? "relative min-h-48 flex-1 px-3" : "relative px-3 pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: canvasRef,
					className: screen === "play" ? "absolute inset-x-3 inset-y-0 h-auto w-auto rounded-2xl border border-line" : "h-52 w-full rounded-2xl border border-line bg-surface"
				}), screen === "ai" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute inset-x-3 top-3 flex h-52 flex-col items-center justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "سیالان بیټ کوي"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-score text-6xl text-gold",
						children: aiFlash
					})]
				})]
			}),
			screen === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-1 flex-col items-center justify-center gap-5 px-5 pb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-md text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl font-extrabold",
							children: "انصار الیون تعقیب کوي"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "سیالان لومړی بیټ کوي. ته هدف څاري. کله چې طلایي حلقه د بیټر سره برابره شي، شاټ وټاکه — سم وخت څلور او شپږ راوړي."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2",
						children: [5, 10].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setOvers(n),
							className: `min-h-11 rounded-xl px-4 py-2 text-sm font-bold ${overs === n ? "bg-gold text-gold-ink" : "bg-surface-2 text-fg"}`,
							children: [n, " اوورونه"]
						}, n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => startMatch(overs),
						className: "min-h-12 rounded-xl bg-gold px-8 py-3 text-base font-extrabold text-gold-ink",
						children: "لوبه پیل کړه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-muted",
						children: "کمپیوټر: ۱ سټریټ · ۲ کور · ۳ پل · ۴ سویپ · ۵ شپږ · ۶ دفاع"
					})
				]
			}),
			screen === "ai" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						if (live.current.screen === "ai") goPlay();
					},
					className: "min-h-11 rounded-xl bg-surface-2 px-5 py-2 text-sm font-bold",
					children: "هدف ته ورشه"
				})
			}),
			screen === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 px-4 py-1 text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "truncate",
						children: [
							striker,
							" ",
							innings.scores[innings.striker],
							"(",
							innings.ballsFaced[innings.striker],
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-score shrink-0 tracking-widest",
						children: innings.recent.slice(-6).join(" ") || "•"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "truncate",
						children: [
							non,
							" ",
							innings.scores[innings.nonStriker]
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2 px-3 pb-3",
				children: SHOTS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onPointerDown: (e) => {
						e.preventDefault();
						playShot(s.id);
					},
					className: "min-h-12 rounded-xl bg-surface-2 px-2 py-2 text-sm font-bold active:bg-gold active:text-gold-ink",
					children: [s.ps, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-0.5 block text-xs font-medium text-muted",
						children: [
							i + 1,
							" ",
							s.en
						]
					})]
				}, s.id))
			})] }),
			screen === "result" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-1 flex-col items-center gap-3 overflow-auto px-5 pb-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-score text-sm text-gold",
						children: won === "win" ? "بریا" : won === "tie" ? "مساوي" : "ماته"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-extrabold",
						children: won === "win" ? "انصار وګټله" : won === "tie" ? "لوبه مساوي شوه" : "سیال وګټله"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-score text-5xl",
						children: [
							innings.runs,
							"/",
							innings.wickets
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"هدف ",
							target,
							" · ",
							overBallLabel(innings.balls)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm text-muted",
						children: comment
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "w-full max-w-sm space-y-1 text-sm",
						children: SQUAD.slice(0, Math.min(11, Math.max(innings.nextBatter, 2))).map((name, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between rounded-lg bg-surface px-3 py-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-score",
								children: [innings.scores[idx], innings.ballsFaced[idx] ? ` (${innings.ballsFaced[idx]})` : ""]
							})]
						}, name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							live.current.screen = "menu";
							live.current.delivery = null;
							live.current.result = null;
							setScreen("menu");
						},
						className: "min-h-12 rounded-xl bg-gold px-8 py-3 font-extrabold text-gold-ink",
						children: "بیا لوبه"
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CricketApp, {});
}
//#endregion
export { Home as component };
