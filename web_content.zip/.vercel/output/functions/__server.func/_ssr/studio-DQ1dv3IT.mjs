import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { A as Modal, a as FLORAL_OPTIONS, c as PALETTES, f as isHex, h as SECTIONS, i as usePlanner, k as cn, r as snapshot, u as defaultTheme } from "./router-CQnHyG8o.mjs";
import { d as fieldClass, i as ColorDot, l as Segmented, n as Card, r as CardTitle, s as PageHeader } from "./primitives-DM2UCvsE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-DQ1dv3IT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonStyles = cva("inline-flex shrink-0 items-center justify-center gap-2 font-medium select-none transition-[opacity,background-color,color] duration-150 ease-smooth hover:opacity-90 active:opacity-80 disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", {
	variants: {
		variant: {
			primary: "h-11 rounded-full bg-accent px-4 text-accent-fg",
			quiet: "h-11 rounded-full bg-blush px-4 text-ink",
			ghost: "h-11 rounded-full px-3 text-ink hover:bg-blush",
			danger: "h-11 rounded-full border border-line bg-card px-4 text-accent"
		},
		size: {
			md: "",
			icon: "size-11 px-0"
		}
	},
	defaultVariants: {
		variant: "quiet",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonStyles({
			variant,
			size
		}), className),
		...props
	});
}
function isRecord(value) {
	return !!value && typeof value === "object" && !Array.isArray(value);
}
/** Accept a Solenne backup file. Reject anything that is not planner data. */
function parseBackup(raw) {
	try {
		const parsed = JSON.parse(raw);
		if (!isRecord(parsed)) return null;
		if (!Array.isArray(parsed.goals) || !Array.isArray(parsed.habits) || !Array.isArray(parsed.tasks)) return null;
		const base = defaultTheme();
		const themeRaw = isRecord(parsed.theme) ? parsed.theme : {};
		const tabs = { ...base.tabs };
		if (isRecord(themeRaw.tabs)) for (const section of SECTIONS) {
			const color = themeRaw.tabs[section.id];
			if (typeof color === "string" && isHex(color)) tabs[section.id] = color;
		}
		const theme = {
			...base,
			...typeof themeRaw.paper === "string" && isHex(themeRaw.paper) ? { paper: themeRaw.paper } : {},
			...typeof themeRaw.card === "string" && isHex(themeRaw.card) ? { card: themeRaw.card } : {},
			...typeof themeRaw.ink === "string" && isHex(themeRaw.ink) ? { ink: themeRaw.ink } : {},
			...typeof themeRaw.muted === "string" && isHex(themeRaw.muted) ? { muted: themeRaw.muted } : {},
			...typeof themeRaw.line === "string" && isHex(themeRaw.line) ? { line: themeRaw.line } : {},
			...typeof themeRaw.accent === "string" && isHex(themeRaw.accent) ? { accent: themeRaw.accent } : {},
			...typeof themeRaw.accentFg === "string" && isHex(themeRaw.accentFg) ? { accentFg: themeRaw.accentFg } : {},
			...typeof themeRaw.blush === "string" && isHex(themeRaw.blush) ? { blush: themeRaw.blush } : {},
			...typeof themeRaw.sage === "string" && isHex(themeRaw.sage) ? { sage: themeRaw.sage } : {},
			...typeof themeRaw.sageSoft === "string" && isHex(themeRaw.sageSoft) ? { sageSoft: themeRaw.sageSoft } : {},
			floral: themeRaw.floral === "off" || themeRaw.floral === "soft" || themeRaw.floral === "bloom" ? themeRaw.floral : base.floral,
			paletteId: themeRaw.paletteId === "petal" || themeRaw.paletteId === "linen" || themeRaw.paletteId === "dusk" || themeRaw.paletteId === "porcelain" || themeRaw.paletteId === "custom" ? themeRaw.paletteId : "custom",
			tabs
		};
		return {
			name: typeof parsed.name === "string" ? parsed.name : "",
			samplesOn: false,
			theme,
			days: isRecord(parsed.days) ? parsed.days : {},
			weeks: isRecord(parsed.weeks) ? parsed.weeks : {},
			months: isRecord(parsed.months) ? parsed.months : {},
			years: isRecord(parsed.years) ? parsed.years : {},
			goals: parsed.goals,
			habits: parsed.habits,
			lists: Array.isArray(parsed.lists) ? parsed.lists : [],
			tasks: parsed.tasks,
			notes: Array.isArray(parsed.notes) ? parsed.notes : [],
			notebooks: Array.isArray(parsed.notebooks) ? parsed.notebooks : [],
			pages: Array.isArray(parsed.pages) ? parsed.pages : [],
			visions: Array.isArray(parsed.visions) ? parsed.visions : [],
			dream: typeof parsed.dream === "string" ? parsed.dream : ""
		};
	} catch {
		return null;
	}
}
var PRESETS = Object.entries(PALETTES);
function StudioView() {
	const name = usePlanner((s) => s.name);
	const theme = usePlanner((s) => s.theme);
	const setName = usePlanner((s) => s.setName);
	const applyPalette = usePlanner((s) => s.applyPalette);
	const setPaper = usePlanner((s) => s.setPaper);
	const setAccent = usePlanner((s) => s.setAccent);
	const setTheme = usePlanner((s) => s.setTheme);
	const setTabColor = usePlanner((s) => s.setTabColor);
	const unifyTabs = usePlanner((s) => s.unifyTabs);
	const varyTabs = usePlanner((s) => s.varyTabs);
	const clearContent = usePlanner((s) => s.clearContent);
	const restoreSamples = usePlanner((s) => s.restoreSamples);
	const replaceData = usePlanner((s) => s.replaceData);
	const fileRef = (0, import_react.useRef)(null);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	function download() {
		const blob = new Blob([JSON.stringify({
			solenne: 1,
			...snapshot()
		}, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "solenne-backup.json";
		link.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Studio",
			lede: "Paper, color, and how Solenne feels."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Your name" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (event) => setName(event.target.value),
						placeholder: "What should we call you?",
						"aria-label": "Your name",
						autoComplete: "given-name",
						className: fieldClass
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-2xl text-ink",
						children: name.trim() ? `Hello, ${name.trim()}.` : "Hello."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Paper" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: PRESETS.map(([id, palette]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": theme.paletteId === id,
							onClick: () => applyPalette(id),
							className: cn("flex h-auto items-center gap-3 rounded-2xl border px-3 py-3 text-left", theme.paletteId === id ? "border-accent bg-blush" : "border-line"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex shrink-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-8 rounded-full border border-line",
										style: { background: palette.colors.paper }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "-ml-2 size-8 rounded-full border border-line",
										style: { background: palette.colors.accent }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "-ml-2 size-8 rounded-full border border-line",
										style: { background: palette.colors.sage }
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-medium",
								children: palette.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm text-muted",
								children: palette.hint
							})] })]
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDot, {
								label: "Background color",
								value: theme.paper,
								onChange: setPaper
							}), "Background"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDot, {
								label: "Accent color",
								value: theme.accent,
								onChange: setAccent
							}), "Accent"]
						})]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Florals" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
						label: "Floral intensity",
						value: theme.floral,
						options: FLORAL_OPTIONS,
						onChange: (floral) => setTheme({ floral })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "A whisper of botanical linework behind the pages."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Section colors" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: "These mark each part of the planner, including every month you color yourself."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: varyTabs,
							children: "Vary the tabs"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: unifyTabs,
							children: "One accent"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2 sm:grid-cols-2",
						children: SECTIONS.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 rounded-lg border border-line px-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDot, {
									label: `${section.label} color`,
									value: theme.tabs[section.id],
									onChange: (color) => setTabColor(section.id, color)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: section.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto h-1 w-8 rounded-full",
									style: { background: theme.tabs[section.id] }
								})
							]
						}, section.id))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "On this device" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-pretty text-muted",
						children: "Everything stays in this browser. Download a backup if you want a copy, or restore one later."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "primary",
								onClick: download,
								children: "Download backup"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "quiet",
								onClick: () => fileRef.current?.click(),
								children: "Restore backup"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setConfirm("samples"),
								children: "Sample pages"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: () => setConfirm("clear"),
								children: "Clear planner"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "application/json",
						className: "sr-only",
						"aria-label": "Backup file",
						onChange: async (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							if (!file) return;
							const data = parseBackup(await file.text());
							if (!data) {
								toast("That file is not a Solenne backup.");
								return;
							}
							replaceData(data);
							toast("Backup restored.");
						}
					})
				] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open: confirm !== null,
			onOpenChange: (open) => {
				if (!open) setConfirm(null);
			},
			title: confirm === "clear" ? "Clear the planner?" : "Restore sample pages?",
			description: confirm === "clear" ? "Days, goals, habits, tasks, notes, notebooks, and the vision board on this device will be erased. Your name and colors stay." : "This replaces your pages with the sample set. Your name and colors stay.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setConfirm(null),
					children: "Keep my pages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: confirm === "clear" ? "danger" : "primary",
					onClick: () => {
						if (confirm === "clear") clearContent();
						if (confirm === "samples") restoreSamples();
						setConfirm(null);
					},
					children: confirm === "clear" ? "Clear everything" : "Restore samples"
				})]
			})
		})
	] });
}
var SplitComponent = StudioView;
//#endregion
export { SplitComponent as component };
