import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useWord } from "./router-C-xQh0iG.mjs";
import { n as lookupTokens } from "./glossary-ClGpQtp5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/road-sign-_-tGVxDe.js
var import_jsx_runtime = require_jsx_runtime();
var WORD = /[A-Za-zÀ-ÖØ-öø-ÿ0-9’']+/;
function ItText({ text, className }) {
	const open = useWord();
	const parts = text.split(/([^A-Za-zÀ-ÖØ-öø-ÿ0-9’']+)/);
	const tokens = parts.filter((p) => WORD.test(p));
	const nodes = [];
	let ti = 0;
	for (let i = 0; i < parts.length;) {
		const part = parts[i] ?? "";
		if (!WORD.test(part)) {
			nodes.push(part);
			i += 1;
			continue;
		}
		const rest = tokens.slice(ti);
		const hit = lookupTokens(rest);
		const len = hit?.len ?? 1;
		const raw = rebuild(parts, i, len);
		const label = rest.slice(0, len).join(" ");
		nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "it-word",
			onClick: () => open({
				word: label,
				meaning: hit?.entry.ar,
				note: hit?.entry.note,
				context: text
			}),
			children: raw
		}, `${i}-${label}`));
		ti += len;
		i = advance(parts, i, len);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		dir: "ltr",
		lang: "it",
		className: `text-left text-lg leading-relaxed ${className ?? ""}`,
		children: nodes
	});
}
function rebuild(parts, start, words) {
	let left = words;
	let out = "";
	for (let i = start; i < parts.length && left > 0; i++) {
		const p = parts[i] ?? "";
		out += p;
		if (WORD.test(p)) left -= 1;
	}
	return out;
}
function advance(parts, start, words) {
	let left = words;
	let i = start;
	while (i < parts.length && left > 0) {
		if (WORD.test(parts[i] ?? "")) left -= 1;
		i += 1;
	}
	return i;
}
var W = "var(--color-sign-white)";
var K = "var(--color-sign-black)";
var R = "var(--color-sign-red)";
var B = "var(--color-sign-blue)";
var Y = "var(--color-sign-yellow)";
var G = "var(--color-sign-green)";
var O = "var(--color-sign-orange)";
var sans = "Arial, Helvetica, sans-serif";
function Tri({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "60,5 115,112 5,112",
			fill: R
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "60,22 100,104 20,104",
			fill: W
		}),
		children
	] });
}
function Ring({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "60",
		cy: "60",
		r: "54",
		fill: W,
		stroke: R,
		strokeWidth: "11"
	}), children] });
}
function Blue({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
		cx: "60",
		cy: "60",
		r: "54",
		fill: B
	}), children] });
}
function stroke(d, color, width = 7) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d,
		fill: "none",
		stroke: color,
		strokeWidth: width,
		strokeLinecap: "round",
		strokeLinejoin: "round"
	});
}
function Person({ x, y, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
		transform: `translate(${x} ${y})`,
		fill: color,
		stroke: color,
		strokeLinecap: "round",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "0",
			cy: "0",
			r: "5",
			stroke: "none"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M0 6 V22 M0 12 L-9 18 M0 12 L9 18 M0 22 L-7 34 M0 22 L7 34",
			fill: "none",
			strokeWidth: "4"
		})]
	});
}
function CarSide({ x, y, color, flip }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
		transform: `translate(${x} ${y}) scale(${flip ? -1 : 1} 1)`,
		fill: color,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M-16 4 H6 L12 -4 H4 L-2 -12 H-14 Z" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "-10",
				cy: "6",
				r: "3.2",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "6",
				cy: "6",
				r: "3.2",
				fill: W
			})
		]
	});
}
function Arrow({ color, rotate = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
		transform: `rotate(${rotate} 60 60)`,
		children: stroke(`M34 60 H82 M66 44 L84 60 L66 76`, color, 9)
	});
}
function SpeedDisc({ n, end, min }) {
	if (min) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blue, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
		x: "60",
		y: "70",
		textAnchor: "middle",
		fontFamily: sans,
		fontSize: "32",
		fontWeight: "700",
		fill: W,
		children: n
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "60",
			cy: "60",
			r: "54",
			fill: W,
			stroke: end ? K : R,
			strokeWidth: end ? 6 : 11
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "72",
			textAnchor: "middle",
			fontFamily: sans,
			fontSize: "34",
			fontWeight: "700",
			fill: end ? "#8a8a8a" : K,
			children: n
		}),
		end ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "24",
			y1: "96",
			x2: "96",
			y2: "24",
			stroke: K,
			strokeWidth: "8"
		}) : null
	] });
}
function renderBody(id) {
	if (id.startsWith("limite-")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeedDisc, { n: id.slice(7) });
	if (id.startsWith("fine-limite-")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeedDisc, {
		n: id.slice(12),
		end: true
	});
	if (id.startsWith("vmin-")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeedDisc, {
		n: id.slice(5),
		min: true
	});
	switch (id) {
		case "curva-dx": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: stroke("M40 86 V64 C40 46 58 42 76 42 H84 M68 30 L86 42 L68 54", K) });
		case "curva-sx": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			transform: "translate(120 0) scale(-1 1)",
			children: stroke("M40 86 V64 C40 46 58 42 76 42 H84 M68 30 L86 42 L68 54", K)
		}) });
		case "doppia-dx": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: stroke("M34 88 C34 70 48 64 58 56 C68 48 70 40 78 34 M66 28 L82 32 L72 46", K, 6) });
		case "doppia-sx": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			transform: "translate(120 0) scale(-1 1)",
			children: stroke("M34 88 C34 70 48 64 58 56 C68 48 70 40 78 34 M66 28 L82 32 L72 46", K, 6)
		}) });
		case "dosso": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: stroke("M30 80 H44 C50 80 52 58 60 52 C68 58 70 80 76 80 H90", K) });
		case "cunetta": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: stroke("M30 58 H44 C52 58 54 80 60 84 C66 80 68 58 76 58 H90", K) });
		case "dissestata": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: stroke("M28 70 H40 L48 56 L56 82 L66 50 L74 74 H92", K, 6) });
		case "strettoia": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [stroke("M34 40 L48 60 L34 80", K, 6), stroke("M86 40 L72 60 L86 80", K, 6)] });
		case "strettoia-dx": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [stroke("M32 42 H78", K, 6), stroke("M32 86 H58 L78 60 L58 42", K, 6)] });
		case "discesa": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [stroke("M32 48 H88", K, 5), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "36,70 86,48 86,70",
			fill: K
		})] });
		case "salita": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [stroke("M32 78 H88", K, 5), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "36,78 86,56 86,78",
			fill: K
		})] });
		case "sdrucciolevole": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarSide, {
			x: 58,
			y: 58,
			color: K
		}), stroke("M36 86 C48 74 70 98 88 82", K, 5)] });
		case "bambini": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, {
			x: 50,
			y: 48,
			color: K
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, {
			x: 74,
			y: 54,
			color: K
		})] });
		case "pedoni": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, {
			x: 60,
			y: 46,
			color: K
		}) });
		case "bici-pericolo": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "46",
				cy: "78",
				r: "9",
				fill: "none",
				stroke: K,
				strokeWidth: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "78",
				cy: "78",
				r: "9",
				fill: "none",
				stroke: K,
				strokeWidth: "4"
			}),
			stroke("M46 78 L60 58 L74 74 M60 58 L78 78 M60 58 L52 50", K, 4)
		] });
		case "animali": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [
			stroke("M36 80 C40 62 50 66 54 54 C58 66 70 60 74 48", K, 5),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "78",
				cy: "44",
				r: "5",
				fill: K
			}),
			stroke("M40 80 L34 92 M58 80 L52 94 M70 78 L78 92", K, 4)
		] });
		case "selvatici": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [
			stroke("M34 82 L48 60 L60 74 L78 46", K, 5),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "78,40 88,48 74,50",
				fill: K
			}),
			stroke("M46 82 L40 96 M62 82 L70 96", K, 4)
		] });
		case "lavori": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, {
			x: 48,
			y: 50,
			color: K
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "70,52 92,52 84,88 62,88",
			fill: K
		})] });
		case "massi": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "78,36 96,70 60,70",
			fill: K
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "40,78 70,78 58,96 34,96",
			fill: K
		})] });
		case "ghiaia": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "42",
				cy: "70",
				r: "4",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "56",
				cy: "84",
				r: "3.5",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "70",
				cy: "68",
				r: "4",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "82",
				cy: "86",
				r: "3",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarSide, {
				x: 58,
				y: 52,
				color: K
			})
		] });
		case "banchina": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [
			stroke("M36 42 V92 M84 42 V92", K, 5),
			stroke("M36 70 H58", K, 5),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "58,62 78,70 58,78",
				fill: K
			})
		] });
		case "passaggio-barriere": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [
			stroke("M32 70 H88", K, 6),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "36",
				y: "58",
				width: "6",
				height: "28",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "78",
				y: "58",
				width: "6",
				height: "28",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "46",
				y: "64",
				width: "10",
				height: "8",
				fill: R
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "62",
				y: "64",
				width: "10",
				height: "8",
				fill: W,
				stroke: K
			})
		] });
		case "passaggio-senza": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [stroke("M34 86 H86 M48 86 V48 H72 V86", K, 5), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "52,48 68,48 60,36",
			fill: K
		})] });
		case "croce": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			transform: "translate(60 60) rotate(45)",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "-50",
				y: "-9",
				width: "100",
				height: "18",
				fill: W,
				stroke: R,
				strokeWidth: "5"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			transform: "translate(60 60) rotate(-45)",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "-50",
				y: "-9",
				width: "100",
				height: "18",
				fill: W,
				stroke: R,
				strokeWidth: "5"
			})
		})] });
		case "semaforo-pericolo": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "50",
				y: "40",
				width: "20",
				height: "48",
				rx: "4",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "50",
				r: "4",
				fill: R
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "62",
				r: "4",
				fill: Y
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "74",
				r: "4",
				fill: G
			})
		] });
		case "intersezione": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: stroke("M60 40 V92 M36 66 H84", K, 7) });
		case "precedenza-incrocio": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [stroke("M60 38 V96", K, 10), stroke("M34 68 H86", K, 5)] });
		case "confluenza-dx": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: stroke("M60 38 V96 M60 62 L88 40", K, 6) });
		case "confluenza-sx": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: stroke("M60 38 V96 M60 62 L32 40", K, 6) });
		case "vento": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [stroke("M36 78 C50 70 48 58 64 56 C78 54 80 44 92 40", K, 5), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "30,70 18,84 40,80",
			fill: K
		})] });
		case "doppio-senso": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tri, { children: [stroke("M46 40 V88 M46 40 L38 52 M46 40 L54 52", K, 5), stroke("M74 88 V40 M74 88 L66 76 M74 88 L82 76", K, 5)] });
		case "altri": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tri, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "78",
			textAnchor: "middle",
			fontSize: "42",
			fontWeight: "700",
			fill: K,
			fontFamily: sans,
			children: "!"
		}) });
		case "transito": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {});
		case "senso-vietato": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "60",
			cy: "60",
			r: "54",
			fill: R
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "16",
			y: "49",
			width: "88",
			height: "22",
			fill: W
		})] });
		case "sorpasso": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ring, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarSide, {
			x: 52,
			y: 46,
			color: K
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarSide, {
			x: 70,
			y: 70,
			color: R
		})] });
		case "fine-sorpasso": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "54",
				fill: W,
				stroke: K,
				strokeWidth: "6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarSide, {
				x: 52,
				y: 46,
				color: "#9a9a9a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarSide, {
				x: 70,
				y: 70,
				color: "#9a9a9a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "22",
				y1: "98",
				x2: "98",
				y2: "22",
				stroke: K,
				strokeWidth: "8"
			})
		] });
		case "sosta": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ring, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "28",
			y1: "92",
			x2: "92",
			y2: "28",
			stroke: R,
			strokeWidth: "10"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "28",
			y1: "28",
			x2: "92",
			y2: "92",
			stroke: B,
			strokeWidth: "10"
		})] });
		case "fermata": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ring, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "26",
			y1: "94",
			x2: "94",
			y2: "26",
			stroke: R,
			strokeWidth: "10"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "26",
			y1: "26",
			x2: "94",
			y2: "94",
			stroke: R,
			strokeWidth: "10"
		})] });
		case "clacson": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ring, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M40 70 H52 L70 82 V42 L52 54 H40 Z",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "76",
				y1: "48",
				x2: "88",
				y2: "36",
				stroke: R,
				strokeWidth: "6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "78",
				y1: "62",
				x2: "94",
				y2: "62",
				stroke: R,
				strokeWidth: "6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "24",
				y1: "96",
				x2: "96",
				y2: "24",
				stroke: R,
				strokeWidth: "8"
			})
		] });
		case "inversione": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ring, { children: [
			stroke("M40 70 H78 C86 70 86 46 74 46 H48", K, 6),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "40,60 28,70 40,80",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "26",
				y1: "96",
				x2: "96",
				y2: "24",
				stroke: R,
				strokeWidth: "8"
			})
		] });
		case "divieto-auto": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarSide, {
			x: 60,
			y: 58,
			color: K
		}) });
		case "divieto-camion": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ring, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "34",
				y: "50",
				width: "36",
				height: "18",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "70",
				y: "56",
				width: "16",
				height: "12",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "44",
				cy: "72",
				r: "4",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "74",
				cy: "72",
				r: "4",
				fill: K
			})
		] });
		case "divieto-pedoni": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, {
			x: 60,
			y: 42,
			color: K
		}) });
		case "divieto-bici": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ring, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "46",
				cy: "70",
				r: "8",
				fill: "none",
				stroke: K,
				strokeWidth: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "76",
				cy: "70",
				r: "8",
				fill: "none",
				stroke: K,
				strokeWidth: "4"
			}),
			stroke("M46 70 L58 52 L72 68 M58 52 L76 70", K, 4)
		] });
		case "fine-divieti": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "54",
				fill: W,
				stroke: K,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "28",
				y1: "92",
				x2: "92",
				y2: "28",
				stroke: K,
				strokeWidth: "6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "36",
				y1: "100",
				x2: "100",
				y2: "36",
				stroke: K,
				strokeWidth: "6"
			})
		] });
		case "dritto": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blue, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arrow, {
			color: W,
			rotate: -90
		}) });
		case "destra": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blue, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arrow, {
			color: W,
			rotate: 0
		}) });
		case "sinistra": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blue, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arrow, {
			color: W,
			rotate: 180
		}) });
		case "dritto-destra": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blue, { children: stroke("M60 86 V40 M60 40 L48 54 M60 40 L72 54 M60 62 H88 M76 50 L90 62 L76 74", W, 8) });
		case "passaggio-dx": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Blue, { children: [stroke("M42 30 V90", W, 8), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "58,36 90,60 58,84",
			fill: W
		})] });
		case "rotatoria": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Blue, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "22",
				fill: "none",
				stroke: W,
				strokeWidth: "7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "78,30 96,40 76,48",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "42,90 24,80 44,72",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "28,42 40,24 48,44",
				fill: W
			})
		] });
		case "pedoni-obb": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blue, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, {
			x: 60,
			y: 40,
			color: W
		}) });
		case "bici-obb": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Blue, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "44",
				cy: "72",
				r: "10",
				fill: "none",
				stroke: W,
				strokeWidth: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "80",
				cy: "72",
				r: "10",
				fill: "none",
				stroke: W,
				strokeWidth: "4"
			}),
			stroke("M44 72 L58 50 L76 70 M58 50 L80 72 M58 50 L50 42", W, 4)
		] });
		case "catene": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Blue, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "44",
				cy: "60",
				r: "10",
				fill: "none",
				stroke: W,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "64",
				cy: "60",
				r: "10",
				fill: "none",
				stroke: W,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "84",
				cy: "60",
				r: "10",
				fill: "none",
				stroke: W,
				strokeWidth: "5"
			})
		] });
		case "dare": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "6,8 114,8 60,114",
			fill: R
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "22,18 98,18 60,96",
			fill: W
		})] });
		case "stop": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "36,6 84,6 114,36 114,84 84,114 36,114 6,84 6,36",
			fill: R
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "70",
			textAnchor: "middle",
			fontFamily: sans,
			fontSize: "26",
			fontWeight: "700",
			fill: W,
			children: "STOP"
		})] });
		case "diritto": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "60,4 116,60 60,116 4,60",
			fill: Y
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "60,18 102,60 60,102 18,60",
			fill: W
		})] });
		case "fine-diritto": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "60,4 116,60 60,116 4,60",
				fill: Y
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "60,18 102,60 60,102 18,60",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "24",
				y1: "96",
				x2: "96",
				y2: "24",
				stroke: K,
				strokeWidth: "8"
			})
		] });
		case "autostrada": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "28",
				width: "104",
				height: "64",
				rx: "6",
				fill: G
			}),
			stroke("M28 78 H92", W, 5),
			stroke("M40 78 V48 H80 V78", W, 4),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "52,48 68,48 60,36",
				fill: W
			})
		] });
		case "fine-autostrada": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "28",
				width: "104",
				height: "64",
				rx: "6",
				fill: G
			}),
			stroke("M28 78 H92", W, 5),
			stroke("M40 78 V48 H80 V78", W, 4),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "18",
				y1: "84",
				x2: "102",
				y2: "36",
				stroke: R,
				strokeWidth: "8"
			})
		] });
		case "ospedale": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "18",
				y: "18",
				width: "84",
				height: "84",
				rx: "6",
				fill: B
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "50",
				y: "34",
				width: "20",
				height: "52",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "34",
				y: "50",
				width: "52",
				height: "20",
				fill: W
			})
		] });
		case "soccorso": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "14",
				y: "30",
				width: "92",
				height: "60",
				rx: "6",
				fill: B
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "30",
				y: "48",
				width: "36",
				height: "24",
				rx: "3",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "66",
				y: "54",
				width: "18",
				height: "12",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "42",
				y: "42",
				width: "8",
				height: "8",
				fill: R
			})
		] });
		case "benzina": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "18",
				y: "18",
				width: "84",
				height: "84",
				rx: "6",
				fill: B
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "42",
				y: "36",
				width: "28",
				height: "40",
				rx: "3",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "70",
				y: "46",
				width: "12",
				height: "8",
				fill: W
			}),
			stroke("M76 54 V70", W, 3)
		] });
		case "parcheggio": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "18",
			y: "18",
			width: "84",
			height: "84",
			rx: "6",
			fill: B
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "80",
			textAnchor: "middle",
			fontFamily: sans,
			fontSize: "58",
			fontWeight: "700",
			fill: W,
			children: "P"
		})] });
		case "abitato": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "10",
			y: "34",
			width: "100",
			height: "52",
			fill: W,
			stroke: K,
			strokeWidth: "4"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "68",
			textAnchor: "middle",
			fontFamily: sans,
			fontSize: "22",
			fontWeight: "700",
			fill: K,
			children: "ROMA"
		})] });
		case "fine-abitato": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "10",
				y: "34",
				width: "100",
				height: "52",
				fill: W,
				stroke: K,
				strokeWidth: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "60",
				y: "68",
				textAnchor: "middle",
				fontFamily: sans,
				fontSize: "22",
				fontWeight: "700",
				fill: K,
				children: "ROMA"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "16",
				y1: "78",
				x2: "104",
				y2: "40",
				stroke: R,
				strokeWidth: "6"
			})
		] });
		case "senso-unico": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "28",
			y: "10",
			width: "64",
			height: "100",
			rx: "4",
			fill: B
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "60,24 92,70 74,70 74,98 46,98 46,70 28,70",
			fill: W
		})] });
		case "senza-uscita": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "18",
				y: "18",
				width: "84",
				height: "84",
				rx: "6",
				fill: B
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "52",
				y: "32",
				width: "16",
				height: "56",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "36",
				y: "32",
				width: "48",
				height: "14",
				fill: R
			})
		] });
		case "attraversamento": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "18",
			y: "18",
			width: "84",
			height: "84",
			rx: "6",
			fill: B
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, {
			x: 60,
			y: 38,
			color: W
		})] });
		case "preavviso": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "6",
			y: "36",
			width: "108",
			height: "48",
			rx: "4",
			fill: G
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "18",
			y: "66",
			fontFamily: sans,
			fontSize: "16",
			fontWeight: "700",
			fill: W,
			children: "A1 Milano"
		})] });
		case "continua": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "8",
			y: "28",
			width: "104",
			height: "64",
			fill: "#5e6660"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "54",
			y: "34",
			width: "12",
			height: "52",
			fill: W
		})] });
		case "discontinua": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "28",
				width: "104",
				height: "64",
				fill: "#5e6660"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "54",
				y: "34",
				width: "12",
				height: "12",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "54",
				y: "54",
				width: "12",
				height: "12",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "54",
				y: "74",
				width: "12",
				height: "12",
				fill: W
			})
		] });
		case "doppia-continua": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "28",
				width: "104",
				height: "64",
				fill: "#5e6660"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "46",
				y: "34",
				width: "8",
				height: "52",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "66",
				y: "34",
				width: "8",
				height: "52",
				fill: W
			})
		] });
		case "zebrato": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "36",
				width: "104",
				height: "48",
				fill: "#5e6660"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "20",
				y: "42",
				width: "12",
				height: "36",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "42",
				y: "42",
				width: "12",
				height: "36",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "64",
				y: "42",
				width: "12",
				height: "36",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "86",
				y: "42",
				width: "12",
				height: "36",
				fill: W
			})
		] });
		case "stop-terra": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "20",
				width: "104",
				height: "80",
				fill: "#5e6660"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "60",
				y: "68",
				textAnchor: "middle",
				fontFamily: sans,
				fontSize: "22",
				fontWeight: "700",
				fill: W,
				children: "STOP"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "18",
				y: "86",
				width: "84",
				height: "8",
				fill: W
			})
		] });
		case "freccia-suolo": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "8",
			y: "20",
			width: "104",
			height: "80",
			fill: "#5e6660"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "60,30 82,58 68,58 68,90 52,90 52,58 38,58",
			fill: W
		})] });
		case "corsia-bus": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "8",
			y: "20",
			width: "104",
			height: "80",
			fill: "#5e6660"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "68",
			textAnchor: "middle",
			fontFamily: sans,
			fontSize: "18",
			fontWeight: "700",
			fill: Y,
			children: "BUS"
		})] });
		case "rosso":
		case "giallo":
		case "verde": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "42",
				y: "8",
				width: "36",
				height: "104",
				rx: "8",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "32",
				r: "10",
				fill: id === "rosso" ? R : "#3a3a3a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "10",
				fill: id === "giallo" ? Y : "#3a3a3a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "88",
				r: "10",
				fill: id === "verde" ? G : "#3a3a3a"
			})
		] });
		case "lampeggiante": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "42",
				y: "28",
				width: "36",
				height: "64",
				rx: "8",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "12",
				fill: Y
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "60",
				y: "112",
				textAnchor: "middle",
				fontSize: "12",
				fontFamily: sans,
				fill: K,
				children: "flash"
			})
		] });
		case "freccia-verde": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "42",
				y: "8",
				width: "36",
				height: "104",
				rx: "8",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "60,70 78,92 66,92 66,104 54,104 54,92 42,92",
				fill: G,
				transform: "rotate(180 60 86)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "60,28 76,50 66,50 66,64 54,64 54,50 44,50",
				fill: G
			})
		] });
		case "corsia-x": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "36",
				y: "28",
				width: "48",
				height: "64",
				rx: "6",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "48",
				y1: "40",
				x2: "72",
				y2: "80",
				stroke: R,
				strokeWidth: "8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "72",
				y1: "40",
				x2: "48",
				y2: "80",
				stroke: R,
				strokeWidth: "8"
			})
		] });
		case "agente-alt": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "28",
				r: "12",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "48",
				y: "42",
				width: "24",
				height: "36",
				rx: "6",
				fill: B
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "56",
				y: "18",
				width: "8",
				height: "16",
				fill: O
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "60",
				y: "108",
				textAnchor: "middle",
				fontFamily: sans,
				fontSize: "13",
				fontWeight: "700",
				fill: K,
				children: "ALT"
			})
		] });
		case "agente-fronte": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "26",
				r: "10",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M60 38 V72 M28 52 H92",
				stroke: B,
				strokeWidth: "10",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M48 72 L40 100 M72 72 L80 100",
				stroke: K,
				strokeWidth: "6",
				strokeLinecap: "round"
			})
		] });
		case "agente-profilo": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "78",
				cy: "26",
				r: "10",
				fill: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M70 40 H40 V78",
				stroke: B,
				strokeWidth: "10",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M40 70 L28 96 M58 78 L62 102",
				stroke: K,
				strokeWidth: "6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "60",
				y: "116",
				textAnchor: "middle",
				fontSize: "11",
				fontFamily: sans,
				fill: K,
				children: "VIA"
			})
		] });
		case "pannello-distanza": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "22",
			y: "28",
			width: "76",
			height: "64",
			fill: W,
			stroke: K,
			strokeWidth: "4"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "68",
			textAnchor: "middle",
			fontFamily: sans,
			fontSize: "20",
			fontWeight: "700",
			fill: K,
			children: "150 m"
		})] });
		case "pannello-estesa": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "22",
			y: "36",
			width: "76",
			height: "48",
			fill: W,
			stroke: K,
			strokeWidth: "4"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "68",
			textAnchor: "middle",
			fontFamily: sans,
			fontSize: "22",
			fontWeight: "700",
			fill: K,
			children: "3 km"
		})] });
		case "pannello-ghiaccio": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "18",
			y: "34",
			width: "84",
			height: "52",
			fill: W,
			stroke: K,
			strokeWidth: "4"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "66",
			textAnchor: "middle",
			fontFamily: sans,
			fontSize: "16",
			fontWeight: "700",
			fill: K,
			children: "ghiaccio"
		})] });
		case "pannello-orario": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "16",
				y: "32",
				width: "88",
				height: "56",
				fill: W,
				stroke: K,
				strokeWidth: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "60",
				y: "58",
				textAnchor: "middle",
				fontFamily: sans,
				fontSize: "14",
				fontWeight: "700",
				fill: K,
				children: "8–20"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "60",
				y: "76",
				textAnchor: "middle",
				fontFamily: sans,
				fontSize: "12",
				fill: K,
				children: "lun–ven"
			})
		] });
		case "cantiere": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "60,8 112,108 8,108",
				fill: Y,
				stroke: K,
				strokeWidth: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, {
				x: 46,
				y: 48,
				color: K
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "68,54 90,54 82,90 60,90",
				fill: K
			})
		] });
		case "deviazione": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "10",
			y: "28",
			width: "100",
			height: "64",
			rx: "6",
			fill: Y,
			stroke: K,
			strokeWidth: "3"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: "30,60 70,36 70,50 96,50 96,70 70,70 70,84",
			fill: K
		})] });
		case "coni": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "40,96 60,28 80,96",
				fill: O
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "46",
				y: "58",
				width: "28",
				height: "8",
				fill: W
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "42",
				y: "74",
				width: "36",
				height: "8",
				fill: W
			})
		] });
		case "fig-destra": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cross, { kind: "destra" });
		case "fig-rotatoria": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cross, { kind: "rotatoria" });
		case "fig-strettoia": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cross, { kind: "strettoia" });
		case "fig-svolta": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cross, { kind: "svolta" });
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "10",
			y: "10",
			width: "100",
			height: "100",
			rx: "8",
			fill: W,
			stroke: K
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "66",
			textAnchor: "middle",
			fontSize: "14",
			fill: K,
			fontFamily: sans,
			children: id.slice(0, 10)
		})] });
	}
}
function Cross({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "120",
			height: "120",
			fill: "#d9d3c6"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "46",
			y: "4",
			width: "28",
			height: "112",
			fill: "#6d756f"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "4",
			y: "46",
			width: "112",
			height: "28",
			fill: "#6d756f"
		}),
		kind === "destra" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "54",
			y: "78",
			width: "12",
			height: "22",
			fill: R
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "78",
			y: "54",
			width: "22",
			height: "12",
			fill: B
		})] }) : null,
		kind === "svolta" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "54",
				y: "70",
				width: "12",
				height: "28",
				fill: R
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "50,70 70,70 60,56",
				fill: R
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "54",
				y: "18",
				width: "12",
				height: "24",
				fill: B
			})
		] }) : null,
		kind === "rotatoria" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "18",
				fill: "none",
				stroke: W,
				strokeWidth: "6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "86",
				y: "54",
				width: "16",
				height: "10",
				fill: R
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "55",
				y: "28",
				width: "10",
				height: "14",
				fill: B
			})
		] }) : null,
		kind === "strettoia" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "18",
				y: "40",
				width: "20",
				height: "40",
				fill: "#9aa198"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "82",
				y: "40",
				width: "20",
				height: "40",
				fill: "#9aa198"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "54",
				y: "78",
				width: "12",
				height: "18",
				fill: B
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "54",
				y: "22",
				width: "12",
				height: "18",
				fill: R
			})
		] }) : null
	] });
}
function RoadSign({ id, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 120 120",
		className,
		"aria-hidden": true,
		children: renderBody(id)
	});
}
//#endregion
export { RoadSign as n, ItText as t };
