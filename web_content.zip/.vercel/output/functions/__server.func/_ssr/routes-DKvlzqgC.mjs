import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { _ as readStored, a as clampScale, b as uid, c as fresh, d as normalizeTr, f as parseActions, g as rankTask, h as parseLocalDateTime, l as isDate, m as parseChat, n as STORAGE_KEY, o as composeReply, p as parseAppData, r as buildDataContext, s as containsSecret, t as CHAT_KEY, u as localStamp, v as sweepReminders, x as writeStored, y as todayString } from "./prompt-DNxJ_SQu.mjs";
import { a as Sprout, c as Mic, d as FolderKanban, f as FileChartColumnIncreasing, h as Bell, i as Square, l as ListChecks, m as Check, o as Send, p as Download, r as Trash2, s as Plus, t as Upload, u as LayoutDashboard } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DKvlzqgC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ALLOWED = /* @__PURE__ */ new Set([
	"add_task",
	"delete_task",
	"edit_task",
	"complete_task",
	"list_tasks",
	"add_project",
	"delete_project",
	"edit_project",
	"add_growth",
	"delete_growth",
	"edit_growth",
	"update_growth_progress",
	"evaluate_progress",
	"inspect_data",
	"add_reminder",
	"list_reminders",
	"delete_reminder"
]);
function clone(data) {
	return JSON.parse(JSON.stringify(data));
}
function fail(data, error) {
	return {
		ok: false,
		data,
		summary: "",
		error
	};
}
function success(data, summary) {
	return {
		ok: true,
		data,
		summary,
		error: ""
	};
}
function named(item) {
	return normalizeTr(item.name ?? item.title ?? "");
}
function findMatches(list, id, query) {
	if (id !== void 0 && id !== null && String(id) !== "") {
		const exact = list.filter((item) => String(item.id) === String(id));
		if (exact.length) return exact;
	}
	const q = normalizeTr(query);
	if (!q) return [];
	const exactName = list.filter((item) => named(item) === q);
	if (exactName.length) return exactName;
	return list.filter((item) => named(item).includes(q));
}
function selection(data, error, actionType, payload, selectAs, candidates) {
	return {
		ok: false,
		data,
		summary: "",
		error,
		needsSelection: true,
		actionType,
		payload,
		selectAs,
		candidates
	};
}
function confirm(data, error, confirmData) {
	return {
		ok: false,
		data,
		summary: "",
		error,
		needsConfirm: true,
		confirmData
	};
}
function dropTaskReminders(data, taskId) {
	data.reminders = data.reminders.filter((r) => !(r.linkType === "task" && String(r.linkId) === String(taskId)));
}
function reminderWhen(raw, now = /* @__PURE__ */ new Date()) {
	const at = parseLocalDateTime(raw);
	if (!at) return {
		ok: false,
		error: "Hatırlatma için tarih ve saat gerekli (YYYY-AA-GGTHH:DD)."
	};
	const diff = at.getTime() - now.getTime();
	if (diff < -9e4) return {
		ok: false,
		error: "Hatırlatma zamanı geçmişte kalamaz."
	};
	return {
		ok: true,
		at: diff <= 0 ? now.getTime() + 1500 : at.getTime()
	};
}
function snapshot(data) {
	const openTasks = data.tasks.filter((t) => !t.done);
	const doneTasks = data.tasks.filter((t) => t.done);
	const activeProj = data.projects.filter((p) => !p.done);
	const doneProj = data.projects.filter((p) => p.done);
	const activeReminders = data.reminders.filter((r) => r.active);
	const avg = data.growth.length ? Math.round(data.growth.reduce((sum, item) => sum + item.progress, 0) / data.growth.length) : 0;
	return `Mevcut durum: ${activeProj.length} aktif proje, ${doneProj.length} biten proje, ${openTasks.length} açık görev, ${doneTasks.length} tamamlanan görev, ${activeReminders.length} aktif hatırlatıcı, gelişim ortalaması %${avg}.`;
}
function executeCommand(data, cmd, opts) {
	if (!cmd || typeof cmd !== "object" || Array.isArray(cmd)) return fail(data, "Geçersiz komut yapısı alındı.");
	const rec = cmd;
	const type = String(rec.type ?? "").trim();
	if (!ALLOWED.has(type)) return fail(data, `Desteklenmeyen komut reddedildi: "${type}"`);
	if (type === "add_task") {
		const name = String(rec.name ?? "").trim();
		if (!name) return fail(data, "Görev adı boş olamaz.");
		let projectId = null;
		if (rec.project_id !== void 0 && rec.project_id !== null && String(rec.project_id) !== "") {
			const project = data.projects.find((item) => String(item.id) === String(rec.project_id));
			if (!project) return fail(data, "Bağlanacak proje bulunamadı.");
			projectId = project.id;
		} else if (rec.project_name) {
			const matches = findMatches(data.projects, null, rec.project_name);
			if (matches.length > 1) return selection(data, `"${String(rec.project_name)}" ile birden fazla proje eşleşti. Hangisine bağlayayım?`, "add_task", {
				...rec,
				project_name: void 0
			}, "project_id", matches.map((item) => ({
				id: item.id,
				label: item.name
			})));
			if (matches.length === 1) projectId = matches[0].id;
			else return fail(data, `"${String(rec.project_name)}" adında bir proje bulunamadı. Görev eklenmedi.`);
		}
		if (rec.date !== void 0 && rec.date !== "" && !isDate(rec.date)) return fail(data, "Görev tarihi YYYY-AA-GG biçiminde olmalı.");
		const next = clone(data);
		const task = {
			id: uid(),
			name: name.slice(0, 200),
			project: projectId,
			priority: clampScale(rec.priority, 2),
			date: isDate(rec.date) ? rec.date : "",
			done: false
		};
		next.tasks.push(task);
		const label = task.priority === 3 ? "acil" : task.priority === 2 ? "önemli" : "daha sonra";
		return success(next, `"${task.name}" görevi eklendi (${label}).`);
	}
	if (type === "complete_task") {
		const matches = findMatches(data.tasks, rec.id, rec.name ?? rec.query);
		if (matches.length === 0) return fail(data, `"${String(rec.name || rec.id || "")}" ile eşleşen görev bulunamadı.`);
		if (matches.length > 1) return selection(data, `Birden fazla görev eşleşti. Hangisini tamamlayayım?`, "complete_task", { type: "complete_task" }, "id", matches.map((item) => ({
			id: item.id,
			label: `${item.name} (${item.done ? "tamamlanmış" : "açık"})`
		})));
		const target = matches[0];
		if (target.done) return success(data, `"${target.name}" zaten tamamlanmış.`);
		const next = clone(data);
		const task = next.tasks.find((item) => item.id === target.id);
		if (!task) return fail(data, "Görev bulunamadı.");
		task.done = true;
		dropTaskReminders(next, task.id);
		return success(next, `"${task.name}" tamamlandı olarak işaretlendi.`);
	}
	if (type === "edit_task") {
		const matches = findMatches(data.tasks, rec.id, rec.target_name ?? rec.name);
		if (matches.length === 0) return fail(data, `Düzenlenecek görev bulunamadı: "${String(rec.target_name || rec.name || "")}".`);
		if (matches.length > 1) return selection(data, "Birden fazla görev eşleşti. Hangisini düzenleyeyim?", "edit_task", { ...rec }, "id", matches.map((item) => ({
			id: item.id,
			label: item.name
		})));
		if (rec.date !== void 0 && rec.date !== "" && rec.date !== null && !isDate(rec.date)) return fail(data, "Tarih YYYY-AA-GG biçiminde olmalı. Mevcut tarih korundu.");
		const next = clone(data);
		const target = next.tasks.find((item) => item.id === matches[0].id);
		if (!target) return fail(data, "Görev bulunamadı.");
		const before = JSON.stringify(target);
		if (rec.new_name && String(rec.new_name).trim()) target.name = String(rec.new_name).trim().slice(0, 200);
		if (rec.priority !== void 0) target.priority = clampScale(rec.priority, target.priority);
		if (rec.date === "" || rec.date === null) target.date = "";
		else if (isDate(rec.date)) target.date = rec.date;
		if (typeof rec.done === "boolean") {
			target.done = rec.done;
			if (rec.done) dropTaskReminders(next, target.id);
		}
		if (JSON.stringify(target) === before && !(typeof rec.done === "boolean" && rec.done)) return fail(data, "Görevde uygulanacak bir değişiklik yok.");
		return success(next, `"${target.name}" görevi güncellendi.`);
	}
	if (type === "delete_task") {
		const matches = findMatches(data.tasks, rec.id, rec.name ?? rec.query);
		if (matches.length === 0) return fail(data, `Silinecek görev bulunamadı: "${String(rec.name || rec.id || "")}".`);
		if (matches.length > 1) return selection(data, "Birden fazla görev eşleşti. Hangisini silmek istiyorsun?", "delete_task", { type: "delete_task" }, "id", matches.map((item) => ({
			id: item.id,
			label: item.name
		})));
		const target = matches[0];
		if (!opts?.bypassConfirm) return confirm(data, `"${target.name}" görevini kalıcı olarak silmek için onay gerekiyor.`, {
			type: "delete_task",
			id: target.id,
			name: target.name
		});
		const next = clone(data);
		next.tasks = next.tasks.filter((item) => item.id !== target.id);
		dropTaskReminders(next, target.id);
		if (next.tasks.some((item) => item.id === target.id)) return fail(data, "Doğrulama hatası: görev silinemedi.");
		return success(next, `"${target.name}" görevi silindi.`);
	}
	if (type === "list_tasks") {
		if (data.tasks.length === 0) return success(data, "Kayıtlı görev yok.");
		const lines = data.tasks.map((task) => {
			const label = task.priority === 3 ? "acil" : task.priority === 2 ? "önemli" : "daha sonra";
			return `- [${task.done ? "Tamamlandı" : "Açık"}] ${task.name} (${label}${task.date ? `, tarih: ${task.date}` : ""})`;
		}).join("\n");
		return success(data, `Görevler (${data.tasks.length}):\n${lines}`);
	}
	if (type === "add_project") {
		const name = String(rec.name ?? "").trim();
		if (!name) return fail(data, "Proje adı boş olamaz.");
		if (rec.date !== void 0 && rec.date !== "" && !isDate(rec.date)) return fail(data, "Proje tarihi YYYY-AA-GG biçiminde olmalı.");
		const next = clone(data);
		const project = {
			id: uid(),
			name: name.slice(0, 160),
			desc: String(rec.desc ?? "").trim().slice(0, 2e3),
			importance: clampScale(rec.importance, 2),
			date: isDate(rec.date) ? rec.date : "",
			done: false
		};
		next.projects.push(project);
		return success(next, `"${project.name}" projesi oluşturuldu.`);
	}
	if (type === "edit_project") {
		const matches = findMatches(data.projects, rec.id, rec.target_name ?? rec.name);
		if (matches.length === 0) return fail(data, `Düzenlenecek proje bulunamadı: "${String(rec.target_name || rec.name || "")}".`);
		if (matches.length > 1) return selection(data, "Birden fazla proje eşleşti. Hangisini düzenleyeyim?", "edit_project", { ...rec }, "id", matches.map((item) => ({
			id: item.id,
			label: item.name
		})));
		if (rec.date !== void 0 && rec.date !== "" && rec.date !== null && !isDate(rec.date)) return fail(data, "Tarih geçersiz. Proje korundu.");
		const next = clone(data);
		const target = next.projects.find((item) => item.id === matches[0].id);
		if (!target) return fail(data, "Proje bulunamadı.");
		if (rec.new_name && String(rec.new_name).trim()) target.name = String(rec.new_name).trim().slice(0, 160);
		if (rec.desc !== void 0) target.desc = String(rec.desc).trim().slice(0, 2e3);
		if (rec.importance !== void 0) target.importance = clampScale(rec.importance, target.importance);
		if (rec.date === "" || rec.date === null) target.date = "";
		else if (isDate(rec.date)) target.date = rec.date;
		if (typeof rec.done === "boolean") {
			target.done = rec.done;
			if (rec.done) next.reminders = next.reminders.filter((item) => !(item.linkType === "project" && String(item.linkId) === target.id));
		}
		return success(next, `"${target.name}" projesi güncellendi.`);
	}
	if (type === "delete_project") {
		const matches = findMatches(data.projects, rec.id, rec.name ?? rec.query);
		if (matches.length === 0) return fail(data, `Silinecek proje bulunamadı: "${String(rec.name || rec.id || "")}".`);
		if (matches.length > 1) return selection(data, "Birden fazla proje eşleşti. Hangisini silmek istiyorsun?", "delete_project", { type: "delete_project" }, "id", matches.map((item) => ({
			id: item.id,
			label: item.name
		})));
		const target = matches[0];
		const linked = data.tasks.filter((task) => task.project === target.id);
		if (!opts?.bypassConfirm) return confirm(data, `"${target.name}" projesini${linked.length ? ` ve bağlı ${linked.length} görevi` : ""} kalıcı olarak silmek için onay gerekiyor.`, {
			type: "delete_project",
			id: target.id,
			name: target.name
		});
		const next = clone(data);
		const taskIds = new Set(linked.map((task) => task.id));
		next.projects = next.projects.filter((item) => item.id !== target.id);
		next.tasks = next.tasks.filter((task) => task.project !== target.id);
		next.reminders = next.reminders.filter((item) => !(item.linkType === "project" && item.linkId === target.id || item.linkType === "task" && item.linkId && taskIds.has(item.linkId)));
		return success(next, `"${target.name}" projesi ve bağlı görevleri silindi.`);
	}
	if (type === "add_growth") {
		const name = String(rec.name ?? "").trim();
		if (!name) return fail(data, "Gelişim alanı başlığı boş olamaz.");
		const next = clone(data);
		const item = {
			id: uid(),
			name: name.slice(0, 160),
			action: String(rec.action ?? "").trim().slice(0, 2e3),
			progress: 0,
			done: false
		};
		next.growth.push(item);
		return success(next, `"${item.name}" gelişim alanı eklendi.`);
	}
	if (type === "edit_growth") {
		const matches = findMatches(data.growth, rec.id, rec.target_name ?? rec.name);
		if (matches.length === 0) return fail(data, `Düzenlenecek gelişim alanı bulunamadı: "${String(rec.target_name || rec.name || "")}".`);
		if (matches.length > 1) return selection(data, "Birden fazla gelişim alanı eşleşti. Hangisini düzenleyeyim?", "edit_growth", { ...rec }, "id", matches.map((item) => ({
			id: item.id,
			label: item.name
		})));
		const next = clone(data);
		const target = next.growth.find((item) => item.id === matches[0].id);
		if (!target) return fail(data, "Gelişim alanı bulunamadı.");
		if (rec.new_name && String(rec.new_name).trim()) target.name = String(rec.new_name).trim().slice(0, 160);
		if (rec.action !== void 0) target.action = String(rec.action).trim().slice(0, 2e3);
		if (rec.progress !== void 0) {
			const pct = Number(rec.progress);
			if (!Number.isFinite(pct)) return fail(data, "İlerleme 0 ile 100 arasında olmalı.");
			target.progress = Math.max(0, Math.min(100, Math.round(pct)));
			target.done = target.progress === 100;
		}
		if (typeof rec.done === "boolean") {
			target.done = rec.done;
			target.progress = rec.done ? 100 : rec.progress === void 0 ? 0 : target.progress;
		}
		return success(next, `"${target.name}" gelişim alanı güncellendi.`);
	}
	if (type === "update_growth_progress") {
		const matches = findMatches(data.growth, rec.id, rec.name ?? rec.query);
		if (matches.length === 0) return fail(data, `Gelişim alanı bulunamadı: "${String(rec.name || rec.id || "")}".`);
		if (matches.length > 1) return selection(data, "Birden fazla gelişim alanı eşleşti. Hangisinin ilerlemesini güncelleyeyim?", "update_growth_progress", { ...rec }, "id", matches.map((item) => ({
			id: item.id,
			label: item.name
		})));
		const pct = Number(rec.progress);
		if (!Number.isFinite(pct)) return fail(data, "Geçerli bir ilerleme yüzdesi (0-100) gerekli.");
		const next = clone(data);
		const target = next.growth.find((item) => item.id === matches[0].id);
		if (!target) return fail(data, "Gelişim alanı bulunamadı.");
		target.progress = Math.max(0, Math.min(100, Math.round(pct)));
		target.done = target.progress === 100;
		return success(next, `"${target.name}" ilerlemesi %${target.progress} oldu.`);
	}
	if (type === "delete_growth") {
		const matches = findMatches(data.growth, rec.id, rec.name ?? rec.query);
		if (matches.length === 0) return fail(data, `Silinecek gelişim alanı bulunamadı: "${String(rec.name || rec.id || "")}".`);
		if (matches.length > 1) return selection(data, "Birden fazla gelişim alanı eşleşti. Hangisini silmek istiyorsun?", "delete_growth", { type: "delete_growth" }, "id", matches.map((item) => ({
			id: item.id,
			label: item.name
		})));
		const target = matches[0];
		if (!opts?.bypassConfirm) return confirm(data, `"${target.name}" gelişim alanını kalıcı olarak silmek için onay gerekiyor.`, {
			type: "delete_growth",
			id: target.id,
			name: target.name
		});
		const next = clone(data);
		next.growth = next.growth.filter((item) => item.id !== target.id);
		return success(next, `"${target.name}" gelişim alanı silindi.`);
	}
	if (type === "add_reminder") {
		const title = String(rec.title ?? "").trim();
		if (!title) return fail(data, "Hatırlatma metni gerekli.");
		const when = reminderWhen(rec.datetime, opts?.now ?? /* @__PURE__ */ new Date());
		if (!when.ok) return fail(data, when.error);
		const repeat = rec.repeat === "daily" ? "daily" : "once";
		const linkType = rec.link_type === "task" || rec.link_type === "project" ? rec.link_type : "general";
		let linkId = null;
		if (linkType !== "general") {
			if (rec.link_id !== void 0 && rec.link_id !== null && String(rec.link_id) !== "") {
				const found = (linkType === "task" ? data.tasks : data.projects).find((item) => String(item.id) === String(rec.link_id));
				if (!found) return fail(data, "Bağlanacak kayıt bulunamadı.");
				linkId = found.id;
			} else {
				const matches = linkType === "task" ? findMatches(data.tasks, null, rec.link_name) : findMatches(data.projects, null, rec.link_name);
				if (matches.length > 1) return selection(data, "Birden fazla kayıt eşleşti. Hatırlatıcı hangisine bağlansın?", "add_reminder", {
					...rec,
					link_name: void 0
				}, "link_id", matches.map((item) => ({
					id: item.id,
					label: item.name
				})));
				if (matches.length !== 1) return fail(data, "Bağlanacak tek bir görev veya proje bulunamadı.");
				linkId = matches[0].id;
			}
		}
		const next = clone(data);
		const reminder = {
			id: uid(),
			title: title.slice(0, 200),
			at: when.at,
			repeat,
			linkType,
			linkId,
			active: true
		};
		next.reminders.push(reminder);
		return success(next, `${reminder.title} hatırlatıcısı ${new Date(reminder.at).toLocaleString("tr-TR")} için kaydedildi.`);
	}
	if (type === "list_reminders") {
		if (data.reminders.length === 0) return success(data, "Kayıtlı hatırlatıcı yok.");
		return success(data, data.reminders.map((item) => `- ${item.title}: ${new Date(item.at).toLocaleString("tr-TR")}${item.active ? "" : " (geçti)"}`).join("\n"));
	}
	if (type === "delete_reminder") {
		const matches = findMatches(data.reminders, rec.id, rec.title ?? rec.name);
		if (matches.length === 0) return fail(data, "Silinecek hatırlatıcı bulunamadı.");
		if (matches.length > 1) return selection(data, "Birden fazla hatırlatıcı eşleşti. Hangisini silmek istiyorsun?", "delete_reminder", { type: "delete_reminder" }, "id", matches.map((item) => ({
			id: item.id,
			label: item.title
		})));
		const target = matches[0];
		if (!opts?.bypassConfirm) return confirm(data, `"${target.title}" hatırlatıcısını silmek için onay gerekiyor.`, {
			type: "delete_reminder",
			id: target.id,
			title: target.title
		});
		const next = clone(data);
		next.reminders = next.reminders.filter((item) => item.id !== target.id);
		return success(next, `${target.title} hatırlatıcısı silindi.`);
	}
	if (type === "evaluate_progress" || type === "inspect_data") return success(data, snapshot(data));
	return fail(data, "Bilinmeyen işlem durumu.");
}
function pendingFrom(res, rest) {
	if (res.needsConfirm && res.confirmData) return {
		kind: "confirm",
		error: res.error,
		confirmData: res.confirmData,
		rest
	};
	if (res.needsSelection && res.actionType && res.payload && res.selectAs && res.candidates) return {
		kind: "select",
		error: res.error,
		actionType: res.actionType,
		payload: res.payload,
		selectAs: res.selectAs,
		candidates: res.candidates,
		rest
	};
	return null;
}
function applyActions(data, cmds, now) {
	let current = data;
	const logs = [];
	const summaries = [];
	const errors = [];
	for (let i = 0; i < cmds.length; i++) {
		const res = executeCommand(current, cmds[i], { now });
		const pending = pendingFrom(res, cmds.slice(i + 1));
		if (pending) return {
			data: current,
			logs,
			summaries,
			errors,
			pending
		};
		if (res.ok) {
			current = res.data;
			summaries.push(res.summary);
			logs.push({
				level: "ok",
				text: res.summary
			});
		} else {
			errors.push(res.error);
			logs.push({
				level: "err",
				text: res.error
			});
		}
	}
	return {
		data: current,
		logs,
		summaries,
		errors,
		pending: null
	};
}
function resolvePending(data, pending, choice, now) {
	if (pending.kind === "confirm") {
		const res = executeCommand(data, pending.confirmData, {
			bypassConfirm: true,
			now
		});
		if (!res.ok) return {
			data,
			logs: [{
				level: "err",
				text: res.error
			}],
			summaries: [],
			errors: [res.error],
			pending: pendingFrom(res, pending.rest)
		};
		const rest = applyActions(res.data, pending.rest, now);
		return {
			data: rest.data,
			logs: [{
				level: "ok",
				text: res.summary
			}, ...rest.logs],
			summaries: [res.summary, ...rest.summaries],
			errors: rest.errors,
			pending: rest.pending
		};
	}
	return applyActions(data, [{
		...pending.payload,
		type: pending.actionType,
		[pending.selectAs]: choice
	}, ...pending.rest], now);
}
function priorityLabel(level) {
	return level === 3 ? "Acil" : level === 2 ? "Önemli" : "Sonra";
}
function importanceLabel(level) {
	return level === 3 ? "Çok önemli" : level === 2 ? "Önemli" : "Daha sonra";
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function cleanMessages(input) {
	if (!input || !Array.isArray(input.messages)) throw new Error("Geçersiz istek.");
	if (input.messages.length > 14) throw new Error("Çok fazla mesaj.");
	const messages = input.messages.map((message) => {
		if (!message || message.role !== "user" && message.role !== "assistant" || typeof message.content !== "string") throw new Error("Geçersiz mesaj.");
		return {
			role: message.role,
			content: message.content.slice(0, 4e3)
		};
	});
	if (typeof input.dataContext !== "string" || input.dataContext.length > 24e3) throw new Error("Veri çok büyük.");
	return {
		messages,
		dataContext: input.dataContext,
		nowLocal: String(input.nowLocal ?? "").slice(0, 40),
		timeZone: String(input.timeZone ?? "").slice(0, 80)
	};
}
var askNexor = createServerFn({ method: "POST" }).validator((input) => cleanMessages(input)).handler(createSsrRpc("54ca6542a0f01998de26b0165ce636ff9fb427129dfb34de442fc7b8137a4b00"));
var speakNexor = createServerFn({ method: "POST" }).validator((input) => {
	const text = String(input?.text ?? "").replace(/\s+/g, " ").trim().slice(0, 420);
	if (!text) throw new Error("Boş metin.");
	return { text };
}).handler(createSsrRpc("fc014d317b755dc1bb790328a6d83b1112d25cf90e3f72b4eebc36312c3c3080"));
var SILENT_WAV = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=";
var audio = null;
var speakToken = 0;
function cleanForSpeech(text) {
	return text.replace(/\[ACTION\][\s\S]*?\[\/ACTION\]/gi, " ").replace(/https?:\/\/\S+/g, " ").replace(/[*#`_>~]/g, " ").replace(/\s+/g, " ").trim().slice(0, 420);
}
function chunkSpeech(text, size = 180) {
	if (!text) return [];
	if (text.length <= size) return [text];
	const parts = [];
	let rest = text;
	while (rest.length > size) {
		let cut = rest.lastIndexOf(". ", size);
		if (cut < 40) cut = rest.lastIndexOf(" ", size);
		if (cut < 40) cut = size;
		parts.push(rest.slice(0, cut).trim());
		rest = rest.slice(cut).trim();
	}
	if (rest) parts.push(rest);
	return parts.filter(Boolean);
}
function speechErrorMessage(code) {
	switch (code) {
		case "not-allowed":
		case "service-not-allowed": return "Mikrofon izni kapalı. Tarayıcı ayarlarından mikrofona izin ver.";
		case "no-speech": return "Ses duyulmadı. Tekrar dene.";
		case "audio-capture": return "Mikrofon bulunamadı.";
		case "network": return "Ses tanıma için internet gerekli.";
		case "language-not-supported": return "Bu cihazda Türkçe ses tanıma yok.";
		default: return "";
	}
}
var active = null;
function canListen() {
	if (typeof window === "undefined") return false;
	const w = window;
	return Boolean(w.SpeechRecognition || w.webkitSpeechRecognition);
}
function turkishVoice(voices) {
	const matches = voices.filter((voice) => /^tr([-_]|$)/i.test(voice.lang) || /turkish|türkçe|turkce/i.test(voice.name));
	return matches.find((voice) => voice.localService) ?? matches[0] ?? null;
}
/** Call inside the microphone tap, before any await. Later speech is otherwise dropped. */
function unlockSpeech() {
	if (typeof window === "undefined") return;
	const synth = window.speechSynthesis;
	if (synth) {
		synth.resume();
		try {
			const primer = new SpeechSynthesisUtterance(" ");
			primer.volume = 0;
			primer.lang = "tr-TR";
			primer.rate = 1;
			primer.pitch = 1;
			synth.speak(primer);
		} catch {}
	}
	if (!audio) audio = new Audio();
	audio.src = SILENT_WAV;
	audio.play().catch(() => void 0);
}
function stopListening() {
	if (!active) return;
	try {
		active.abort();
	} catch {
		try {
			active.stop();
		} catch {}
	}
	active = null;
}
function startListening(handlers) {
	stopListening();
	const w = window;
	const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
	if (!Ctor) throw new Error("unsupported");
	const rec = new Ctor();
	active = rec;
	rec.lang = "tr-TR";
	rec.interimResults = false;
	rec.continuous = false;
	rec.maxAlternatives = 1;
	rec.onstart = () => handlers.onStart();
	rec.onend = () => {
		if (active === rec) active = null;
		handlers.onEnd();
	};
	rec.onerror = (ev) => handlers.onError(ev.error || "unknown");
	rec.onresult = (ev) => {
		const text = ev.results?.[0]?.[0]?.transcript?.trim() ?? "";
		if (text) handlers.onText(text);
		else handlers.onError("no-speech");
	};
	try {
		rec.start();
	} catch {
		active = null;
		throw new Error("busy");
	}
}
function speakWithBrowser(text) {
	const chunks = chunkSpeech(cleanForSpeech(text));
	if (!chunks.length || typeof window === "undefined" || !window.speechSynthesis) return Promise.resolve(false);
	const synth = window.speechSynthesis;
	const voice = turkishVoice(synth.getVoices());
	if (!voice) return Promise.resolve(false);
	const token = ++speakToken;
	return new Promise((resolve) => {
		let settled = false;
		let started = false;
		const finish = (ok) => {
			if (settled || token !== speakToken) return;
			settled = true;
			resolve(ok);
		};
		let index = 0;
		const kick = () => {
			if (token !== speakToken) return;
			if (index >= chunks.length) {
				finish(true);
				return;
			}
			const utterance = new SpeechSynthesisUtterance(chunks[index] ?? "");
			index += 1;
			utterance.lang = "tr-TR";
			utterance.rate = 1;
			utterance.pitch = 1;
			utterance.voice = voice;
			utterance.onstart = () => {
				started = true;
			};
			utterance.onend = () => kick();
			utterance.onerror = () => finish(started);
			synth.resume();
			synth.speak(utterance);
		};
		const arm = () => {
			synth.resume();
			kick();
		};
		if (synth.speaking || synth.pending) {
			synth.cancel();
			window.setTimeout(arm, 120);
		} else arm();
		window.setTimeout(() => {
			if (!started && token === speakToken) {
				synth.cancel();
				finish(false);
			}
		}, 1400);
		const timer = window.setInterval(() => {
			if (token !== speakToken || !synth.speaking) {
				window.clearInterval(timer);
				return;
			}
			synth.resume();
		}, 3e3);
	});
}
async function playBase64(b64, mime) {
	if (typeof window === "undefined" || !b64) return false;
	if (!audio) audio = new Audio();
	audio.src = `data:${mime || "audio/mpeg"};base64,${b64}`;
	try {
		await audio.play();
		return true;
	} catch {
		return false;
	}
}
function stopSpeaking() {
	speakToken += 1;
	if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.cancel();
	if (audio) {
		audio.pause();
		audio.currentTime = 0;
	}
}
var TABS = [
	{
		id: "home",
		label: "Genel",
		icon: LayoutDashboard
	},
	{
		id: "projects",
		label: "Projeler",
		icon: FolderKanban
	},
	{
		id: "growth",
		label: "Gelişim",
		icon: Sprout
	},
	{
		id: "plan",
		label: "Görevler",
		icon: ListChecks
	},
	{
		id: "reminders",
		label: "Hatırlatıcı",
		icon: Bell
	},
	{
		id: "report",
		label: "Rapor",
		icon: FileChartColumnIncreasing
	},
	{
		id: "nexor",
		label: "NEXOR"
	}
];
var inputCls = "mt-1 w-full min-h-11 rounded-xl border border-line bg-bg px-3 py-2 text-base text-ink placeholder:text-muted";
function useStored(key) {
	return (0, import_react.useSyncExternalStore)((cb) => {
		const handler = () => cb();
		window.addEventListener(key, handler);
		window.addEventListener("storage", handler);
		return () => {
			window.removeEventListener(key, handler);
			window.removeEventListener("storage", handler);
		};
	}, () => localStorage.getItem(key) ?? "", () => "");
}
function loadData() {
	return parseAppData(readStored(STORAGE_KEY));
}
function saveData(data) {
	writeStored(STORAGE_KEY, JSON.stringify(data));
}
function saveChat(messages) {
	writeStored(CHAT_KEY, JSON.stringify(messages.filter((msg) => !containsSecret(msg.content)).slice(-40)));
}
function download(obj, name) {
	const blob = new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	a.click();
	URL.revokeObjectURL(url);
}
function Btn({ children, onClick, variant = "primary", disabled, type = "button" }) {
	const look = {
		primary: "bg-gold text-gold-ink",
		ghost: "border border-line bg-surface-2 text-ink",
		danger: "border border-nexor/50 bg-nexor/20 text-danger",
		nexor: "bg-nexor text-ink"
	}[variant];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		disabled,
		onClick,
		className: `inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold ${look}`,
		children
	});
}
function Card({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children
	});
}
function Tag({ level, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-1 text-xs font-semibold ${level === 3 ? "bg-nexor/20 text-danger" : level === 2 ? "bg-gold/15 text-gold" : "bg-surface-2 text-muted"}`,
		children: label
	});
}
function Bar({ pct }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 h-2 overflow-hidden rounded-full bg-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full rounded-full bg-gold",
			style: { width: `${pct}%` }
		})
	});
}
function Empty({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border border-dashed border-line px-4 py-8 text-center text-sm text-muted",
		children
	});
}
function Orb({ size = "size-12" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `nexor-core ${size} shrink-0 rounded-full bg-nexor` });
}
function NexorApp() {
	const raw = useStored(STORAGE_KEY);
	const chatRaw = useStored(CHAT_KEY);
	const data = (0, import_react.useMemo)(() => parseAppData(raw), [raw]);
	const chat = (0, import_react.useMemo)(() => parseChat(chatRaw), [chatRaw]);
	const [tab, setTab] = (0, import_react.useState)("home");
	const [now, setNow] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)("");
	const [input, setInput] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	const [listening, setListening] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)(null);
	const [projectOpen, setProjectOpen] = (0, import_react.useState)(false);
	const [taskOpen, setTaskOpen] = (0, import_react.useState)(false);
	const [pName, setPName] = (0, import_react.useState)("");
	const [pDesc, setPDesc] = (0, import_react.useState)("");
	const [pImportance, setPImportance] = (0, import_react.useState)(3);
	const [pDate, setPDate] = (0, import_react.useState)("");
	const [tName, setTName] = (0, import_react.useState)("");
	const [tProject, setTProject] = (0, import_react.useState)("");
	const [tPriority, setTPriority] = (0, import_react.useState)(3);
	const [tDate, setTDate] = (0, import_react.useState)("");
	const [gName, setGName] = (0, import_react.useState)("");
	const [gAction, setGAction] = (0, import_react.useState)("");
	const [rTitle, setRTitle] = (0, import_react.useState)("");
	const [rWhen, setRWhen] = (0, import_react.useState)("");
	const [rRepeat, setRRepeat] = (0, import_react.useState)("once");
	const [rLink, setRLink] = (0, import_react.useState)("general");
	const [rLinked, setRLinked] = (0, import_react.useState)("");
	const [modal, setModal] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	const chatRef = (0, import_react.useRef)(null);
	const sendingRef = (0, import_react.useRef)(false);
	const voiceSession = (0, import_react.useRef)(false);
	const pendingRef = (0, import_react.useRef)(null);
	const stickyStatus = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		pendingRef.current = pending;
	}, [pending]);
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(/* @__PURE__ */ new Date());
		tick();
		const id = window.setInterval(tick, 3e4);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		const synth = window.speechSynthesis;
		synth?.getVoices();
		const load = () => synth?.getVoices();
		synth?.addEventListener("voiceschanged", load);
		return () => synth?.removeEventListener("voiceschanged", load);
	}, []);
	(0, import_react.useEffect)(() => {
		const check = () => {
			const current = loadData();
			const swept = sweepReminders(current, Date.now());
			if (!swept.fired.length) return;
			saveData(swept.data);
			for (const title of swept.fired) {
				toast("Hatırlatıcı", { description: title });
				if (typeof Notification !== "undefined" && Notification.permission === "granted") try {
					new Notification("Nexor", {
						body: title,
						tag: title
					});
				} catch {}
			}
		};
		check();
		const id = window.setInterval(check, 15e3);
		const onVis = () => {
			if (!document.hidden) check();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", onVis);
		};
	}, [raw]);
	(0, import_react.useEffect)(() => {
		if (tab === "nexor") chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight });
	}, [
		tab,
		chat,
		pending
	]);
	const today = now ? todayString(now) : "";
	const openTasks = data.tasks.filter((task) => !task.done).sort((a, b) => rankTask(b, today) - rankTask(a, today));
	const doneTasks = data.tasks.filter((task) => task.done);
	function run(cmd) {
		const res = executeCommand(loadData(), cmd, { now: /* @__PURE__ */ new Date() });
		if (res.needsConfirm && res.confirmData) {
			const confirmData = res.confirmData;
			setModal({
				title: "Onay gerekli",
				body: res.error,
				confirmLabel: "Evet, sil",
				danger: true,
				onConfirm: () => {
					const done = executeCommand(loadData(), confirmData, {
						bypassConfirm: true,
						now: /* @__PURE__ */ new Date()
					});
					if (done.ok) saveData(done.data);
					else toast.error(done.error);
					setModal(null);
				}
			});
			return false;
		}
		if (!res.ok) {
			toast.error(res.error);
			return false;
		}
		saveData(res.data);
		return true;
	}
	async function voiceOut(text) {
		const cleaned = cleanForSpeech(text);
		if (!cleaned) return;
		if (await speakWithBrowser(cleaned)) return;
		try {
			const audio = await speakNexor({ data: { text: cleaned } });
			if (audio.ok) await playBase64(audio.audio, audio.mime);
		} catch {}
	}
	function pushChat(extra) {
		saveChat([...parseChat(readStored(CHAT_KEY)), ...extra]);
	}
	async function finish(fromVoice, reply, nextPending) {
		if (fromVoice) voiceSession.current = true;
		if (voiceSession.current) await voiceOut(reply);
		if (!nextPending) voiceSession.current = false;
	}
	async function send(text, fromVoice) {
		const trimmed = text.trim();
		if (!trimmed) return;
		if (sendingRef.current) {
			setInput(trimmed);
			stickyStatus.current = true;
			setStatus("Önceki yanıt bitmeden bu mesaj gönderilmedi.");
			return;
		}
		if (containsSecret(trimmed)) {
			setInput("");
			pushChat([{
				role: "err",
				content: "Mesajda bir API anahtarı vardı. Gönderilmedi. Anahtar bu uygulamada istenmez."
			}]);
			return;
		}
		if (!fromVoice) voiceSession.current = false;
		setInput("");
		const active = pendingRef.current;
		const norm = normalizeTr(trimmed);
		if (active?.kind === "confirm" && [
			"evet",
			"onayla",
			"onaylıyorum",
			"onayliyorum",
			"tamam"
		].includes(norm)) {
			pushChat([{
				role: "user",
				content: trimmed
			}]);
			const result = resolvePending(loadData(), active, void 0, /* @__PURE__ */ new Date());
			if (result.data !== loadData()) saveData(result.data);
			setPending(result.pending);
			const reply = composeReply("", result.summaries, result.errors, result.pending?.error);
			pushChat([...result.logs.map((log) => ({
				role: log.level === "ok" ? "log" : "err",
				content: log.text
			})), {
				role: "nexor",
				content: reply
			}]);
			await finish(fromVoice, reply, result.pending);
			return;
		}
		if (active?.kind === "confirm" && [
			"hayır",
			"hayir",
			"iptal",
			"vazgeç",
			"vazgec"
		].includes(norm)) {
			pushChat([{
				role: "user",
				content: trimmed
			}, {
				role: "nexor",
				content: "İşlem iptal edildi. Kayıtlar değişmedi."
			}]);
			setPending(null);
			await finish(fromVoice, "İşlem iptal edildi. Kayıtlar değişmedi.", null);
			return;
		}
		if (active?.kind === "select") {
			const exact = active.candidates.filter((item) => normalizeTr(item.label) === norm);
			if (exact.length === 1 && exact[0]) {
				pushChat([{
					role: "user",
					content: trimmed
				}]);
				const result = resolvePending(loadData(), active, exact[0].id, /* @__PURE__ */ new Date());
				saveData(result.data);
				setPending(result.pending);
				const reply = composeReply("", result.summaries, result.errors, result.pending?.error);
				pushChat([...result.logs.map((log) => ({
					role: log.level === "ok" ? "log" : "err",
					content: log.text
				})), {
					role: "nexor",
					content: reply
				}]);
				await finish(fromVoice, reply, result.pending);
				return;
			}
		}
		sendingRef.current = true;
		setSending(true);
		stickyStatus.current = true;
		setStatus("NEXOR analiz ediyor…");
		pushChat([{
			role: "user",
			content: trimmed
		}]);
		const history = parseChat(readStored(CHAT_KEY)).filter((msg) => msg.role === "user" || msg.role === "nexor").slice(-12).map((msg) => ({
			role: msg.role === "nexor" ? "assistant" : "user",
			content: msg.content
		}));
		const deviceNow = /* @__PURE__ */ new Date();
		try {
			const res = await askNexor({ data: {
				messages: history,
				dataContext: buildDataContext(loadData(), deviceNow),
				nowLocal: localStamp(deviceNow),
				timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "yerel"
			} });
			if (!res.ok) throw new Error(res.error);
			const parsed = parseActions(res.text);
			const applied = applyActions(loadData(), parsed.cmds, deviceNow);
			if (JSON.stringify(applied.data) !== JSON.stringify(loadData())) saveData(applied.data);
			setPending(applied.pending);
			const reply = composeReply(parsed.clean, applied.summaries, [...parsed.errors, ...applied.errors], applied.pending?.error);
			pushChat([...applied.logs.map((log) => ({
				role: log.level === "ok" ? "log" : "err",
				content: log.text
			})), {
				role: "nexor",
				content: reply
			}]);
			setStatus("");
			await finish(fromVoice, reply, applied.pending);
		} catch (error) {
			const message = error instanceof Error ? error.message : "Bağlantı hatası.";
			pushChat([{
				role: "err",
				content: message
			}, {
				role: "nexor",
				content: "Yanıt alınamadı. Biraz sonra yeniden dene."
			}]);
			setStatus(message);
			await finish(fromVoice, "Yanıt alınamadı. Biraz sonra yeniden dene.", null);
		} finally {
			sendingRef.current = false;
			setSending(false);
		}
	}
	function toggleVoice() {
		if (!canListen()) {
			setStatus("Bu tarayıcı ses tanımayı desteklemiyor.");
			return;
		}
		if (listening) {
			stopListening();
			return;
		}
		unlockSpeech();
		stopSpeaking();
		try {
			startListening({
				onStart: () => {
					stickyStatus.current = false;
					setListening(true);
					setStatus("Dinliyorum…");
				},
				onEnd: () => {
					setListening(false);
					if (!stickyStatus.current) setStatus("");
				},
				onError: (code) => {
					setListening(false);
					const message = speechErrorMessage(code);
					if (!message) return;
					stickyStatus.current = true;
					setStatus(message);
				},
				onText: (text) => {
					stickyStatus.current = true;
					setStatus("NEXOR analiz ediyor…");
					send(text, true);
				}
			});
		} catch {
			setListening(false);
			setStatus("Mikrofon şu an meşgul. Tekrar dene.");
		}
	}
	function choose(id) {
		const active = pendingRef.current;
		if (!active || active.kind !== "select") return;
		const result = resolvePending(loadData(), active, id, /* @__PURE__ */ new Date());
		saveData(result.data);
		setPending(result.pending);
		const reply = composeReply("", result.summaries, result.errors, result.pending?.error);
		pushChat([...result.logs.map((log) => ({
			role: log.level === "ok" ? "log" : "err",
			content: log.text
		})), {
			role: "nexor",
			content: reply
		}]);
		finish(voiceSession.current, reply, result.pending);
	}
	function confirmChat() {
		const active = pendingRef.current;
		if (!active || active.kind !== "confirm") return;
		const result = resolvePending(loadData(), active, void 0, /* @__PURE__ */ new Date());
		saveData(result.data);
		setPending(result.pending);
		const reply = composeReply("", result.summaries, result.errors, result.pending?.error);
		pushChat([...result.logs.map((log) => ({
			role: log.level === "ok" ? "log" : "err",
			content: log.text
		})), {
			role: "nexor",
			content: reply
		}]);
		finish(voiceSession.current, reply, result.pending);
	}
	function cancelChat() {
		setPending(null);
		const reply = "İşlem iptal edildi. Kayıtlar değişmedi.";
		pushChat([{
			role: "nexor",
			content: reply
		}]);
		finish(voiceSession.current, reply, null);
	}
	const linkItems = rLink === "task" ? data.tasks.filter((task) => !task.done) : rLink === "project" ? data.projects.filter((project) => !project.done) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: tab === "nexor" ? "mx-auto flex h-dvh max-w-3xl flex-col overflow-hidden px-4" : "mx-auto flex min-h-dvh max-w-3xl flex-col px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { style: {
					background: "var(--color-surface)",
					color: "var(--color-ink)",
					border: "1px solid var(--color-line)"
				} }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "shrink-0 pt-5 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orb, { size: "size-11" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl font-semibold tracking-wide",
						children: "Nexor"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Fikirlerini tamamla, kendini geliştir."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-gold tabular-nums",
					children: now ? `Cihaz saati: ${new Intl.DateTimeFormat("tr-TR", {
						weekday: "long",
						day: "numeric",
						month: "long",
						hour: "2-digit",
						minute: "2-digit"
					}).format(now)}` : "Cihaz saati alınıyor…"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "sticky top-0 z-10 -mx-4 flex shrink-0 gap-2 overflow-x-auto bg-bg/90 px-4 py-2 backdrop-blur",
				children: TABS.map((item) => {
					const Icon = item.icon;
					const active = tab === item.id;
					const accent = item.id === "nexor";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab(item.id),
						className: `inline-flex min-h-11 shrink-0 items-center gap-2 rounded-xl border px-3 text-sm font-semibold ${active ? accent ? "border-nexor text-nexor" : "border-gold text-gold" : accent ? "border-nexor/40 text-nexor" : "border-line bg-surface text-muted"}`,
						children: [accent || !Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nexor-core size-2.5 rounded-full bg-nexor" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-4",
							"aria-hidden": true
						}), item.label]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: tab === "nexor" ? "flex min-h-0 flex-1 flex-col pb-safe" : "flex flex-col gap-3 py-3 pb-safe",
				children: [
					tab === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Aktif proje"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl text-gold",
									children: data.projects.filter((p) => !p.done).length
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Tamamlanan görev"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl text-gold",
									children: doneTasks.length
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Açık görev"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl text-gold",
									children: openTasks.length
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Biten proje"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl text-gold",
									children: data.projects.filter((p) => p.done).length
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg",
								children: "Bugünün odağı"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: "Öncelik sırası"
							})]
						}),
						openTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Öncelikli görev yok. Bir görev ekleyebilirsin." }) : openTasks.slice(0, 3).map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
							task,
							data,
							today,
							onRun: run
						}, task.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg",
								children: "Projelerde ilerleme"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								onClick: () => setTab("projects"),
								children: "Tümünü gör"
							})]
						}),
						data.projects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Henüz proje eklemedin." }) : data.projects.slice(0, 4).map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectRow, {
							project,
							data,
							onRun: run
						}, project.id))
					] }),
					tab === "projects" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg",
								children: "Projelerim"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
								onClick: () => {
									setProjectOpen((v) => !v);
									if (!pDate && now) setPDate(todayString(now));
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Proje ekle"]
							})]
						}),
						projectOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "Yeni proje"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-2 block text-xs text-muted",
								children: ["Proje adı", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputCls,
									value: pName,
									onChange: (e) => setPName(e.target.value),
									placeholder: "Örn. Kişisel uygulamam"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-2 block text-xs text-muted",
								children: ["Açıklama", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: inputCls,
									value: pDesc,
									onChange: (e) => setPDesc(e.target.value),
									placeholder: "Bu projede ne yapmak istiyorsun?"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid gap-3 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted",
									children: ["Önem", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: inputCls,
										value: pImportance,
										onChange: (e) => setPImportance(Number(e.target.value)),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 3,
												children: "Çok önemli"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 2,
												children: "Önemli"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 1,
												children: "Daha sonra"
											})
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted",
									children: ["Son tarih", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputCls,
										type: "date",
										value: pDate,
										onChange: (e) => setPDate(e.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => {
										if (!run({
											type: "add_project",
											name: pName,
											desc: pDesc,
											importance: pImportance,
											date: pDate
										})) return;
										setPName("");
										setPDesc("");
										setPDate("");
										setProjectOpen(false);
									},
									children: "Kaydet"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									variant: "ghost",
									onClick: () => setProjectOpen(false),
									children: "Vazgeç"
								})]
							})
						] }),
						data.projects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "İlk projen burada görünecek." }) : [...data.projects].sort((a, b) => b.importance - a.importance).map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectRow, {
							project,
							data,
							onRun: run
						}, project.id))
					] }),
					tab === "growth" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg",
							children: "Gelişim alanlarım"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Bunlar kesin etiket değil; üzerinde çalışılabilecek başlıklar."
						}),
						data.growth.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Henüz gelişim alanı yok." }) : data.growth.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold",
									children: item.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "size-5 accent-gold",
										type: "checkbox",
										checked: item.done,
										onChange: () => run({
											type: "edit_growth",
											id: item.id,
											done: !item.done
										})
									}), " Tamam"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: item.action || "Adım belirtilmemiş."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, { pct: item.progress }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted",
									children: ["İlerleme %", item.progress]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "ghost",
										onClick: () => run({
											type: "update_growth_progress",
											id: item.id,
											progress: Math.min(100, item.progress + 25)
										}),
										children: "+%25"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "danger",
										onClick: () => run({
											type: "delete_growth",
											id: item.id
										}),
										children: "Sil"
									})]
								})]
							})
						] }, item.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "Yeni gelişim alanı"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputCls,
								value: gName,
								onChange: (e) => setGName(e.target.value),
								placeholder: "Örn. Düzenli tekrar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: inputCls,
								value: gAction,
								onChange: (e) => setGAction(e.target.value),
								placeholder: "Bunun için atacağım küçük adım"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => {
										if (!run({
											type: "add_growth",
											name: gName,
											action: gAction
										})) return;
										setGName("");
										setGAction("");
									},
									children: "Ekle"
								})
							})
						] })
					] }),
					tab === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg",
								children: "Görevler"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
								onClick: () => {
									setTaskOpen((v) => !v);
									if (!tDate && now) setTDate(todayString(now));
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Görev ekle"]
							})]
						}),
						taskOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted",
								children: ["Görev", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputCls,
									value: tName,
									onChange: (e) => setTName(e.target.value),
									placeholder: "Yapılacak iş"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid gap-3 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted",
									children: ["Bağlı proje", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: inputCls,
										value: tProject,
										onChange: (e) => setTProject(e.target.value),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Genel görev"
										}), data.projects.filter((project) => !project.done).map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: project.id,
											children: project.name
										}, project.id))]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted",
									children: ["Öncelik", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: inputCls,
										value: tPriority,
										onChange: (e) => setTPriority(Number(e.target.value)),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 3,
												children: "Acil ve önemli"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 2,
												children: "Önemli"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 1,
												children: "Daha sonra"
											})
										]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-2 block text-xs text-muted",
								children: ["Son tarih", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputCls,
									type: "date",
									value: tDate,
									onChange: (e) => setTDate(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => {
										if (!run({
											type: "add_task",
											name: tName,
											project_id: tProject || void 0,
											priority: tPriority,
											date: tDate
										})) return;
										setTName("");
										setTDate("");
										setTaskOpen(false);
									},
									children: "Görevi kaydet"
								})
							})
						] }),
						openTasks.length === 0 && doneTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Henüz görev yok." }) : null,
						openTasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
							task,
							data,
							today,
							onRun: run
						}, task.id)),
						doneTasks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-display text-base",
							children: "Tamamlananlar"
						}),
						doneTasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
							task,
							data,
							today,
							onRun: run
						}, task.id))
					] }),
					tab === "reminders" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg",
								children: "Hatırlatıcılar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								onClick: () => {
									if (typeof Notification === "undefined") {
										toast.error("Bu tarayıcı bildirim sunmuyor.");
										return;
									}
									Notification.requestPermission().then((permission) => toast(permission === "granted" ? "Bildirim izni verildi." : "Bildirim izni verilmedi."));
								},
								children: "Bildirim izni"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted",
								children: ["Ne hatırlatayım?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputCls,
									value: rTitle,
									onChange: (e) => setRTitle(e.target.value),
									placeholder: "Örn. Ders çalışmaya geri dön"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-2 block text-xs text-muted",
								children: ["Tarih ve saat", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: inputCls,
									type: "datetime-local",
									value: rWhen,
									onChange: (e) => setRWhen(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid gap-3 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted",
									children: ["Tekrar", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: inputCls,
										value: rRepeat,
										onChange: (e) => setRRepeat(e.target.value === "daily" ? "daily" : "once"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "once",
											children: "Bir kez"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "daily",
											children: "Her gün"
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted",
									children: ["Bağlantı", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: inputCls,
										value: rLink,
										onChange: (e) => {
											const value = e.target.value;
											setRLink(value === "task" || value === "project" ? value : "general");
											setRLinked("");
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "general",
												children: "Genel"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "task",
												children: "Görev"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "project",
												children: "Proje"
											})
										]
									})]
								})]
							}),
							rLink !== "general" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: inputCls,
								value: rLinked,
								onChange: (e) => setRLinked(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Seç"
								}), linkItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.name
								}, item.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									onClick: () => {
										if (!run({
											type: "add_reminder",
											title: rTitle,
											datetime: rWhen,
											repeat: rRepeat,
											link_type: rLink,
											link_id: rLink === "general" ? void 0 : rLinked
										})) return;
										setRTitle("");
										setRWhen("");
									},
									children: "Oluştur"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-muted",
								children: "Hatırlatıcılar bu cihazda saklanır ve uygulama açıkken kontrol edilir. Uygulama tamamen kapalıyken bildirim için tarayıcının bildirim izni gerekir; kapalı uygulamada garanti değildir."
							})
						] }),
						[...data.reminders].sort((a, b) => a.at - b.at).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									new Date(item.at).toLocaleString("tr-TR"),
									" · ",
									item.repeat === "daily" ? "Her gün" : "Bir kez",
									" · ",
									item.linkType === "task" ? "Görev" : item.linkType === "project" ? "Proje" : "Genel",
									item.active ? "" : " · geçti"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "danger",
								onClick: () => run({
									type: "delete_reminder",
									id: item.id
								}),
								children: "Sil"
							})]
						}) }, item.id)),
						data.reminders.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Henüz hatırlatıcı yok." })
					] }),
					tab === "report" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg",
								children: "Gelişim raporu"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-muted",
								children: [
									data.projects.length,
									" proje · ",
									doneTasks.length,
									" tamamlanan görev · ",
									openTasks.length,
									" açık görev · ",
									data.growth.filter((item) => item.done).length,
									"/",
									data.growth.length,
									" gelişim alanı tamamlandı"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									onClick: () => download({
										app: "Nexor",
										reportDate: (/* @__PURE__ */ new Date()).toISOString(),
										...data
									}, "nexor-raporu.json"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Raporu indir"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									variant: "ghost",
									onClick: () => download(data, "nexor-yedek.json"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Yedek al"]
								})]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "Yedeği geri yükle"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Seçtiğin yedek mevcut kayıtların üzerine yazılır."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								className: "mt-3 block w-full text-sm",
								type: "file",
								accept: ".json,application/json"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									variant: "ghost",
									onClick: () => {
										const file = fileRef.current?.files?.[0];
										if (!file) {
											toast.error("Önce yedek dosyasını seç.");
											return;
										}
										const reader = new FileReader();
										reader.onload = () => {
											try {
												const parsed = JSON.parse(String(reader.result));
												if (!Array.isArray(parsed.projects) || !Array.isArray(parsed.tasks) || !Array.isArray(parsed.growth)) throw new Error("bad");
												setModal({
													title: "Yedeği yükle",
													body: "Mevcut kayıtların yerine bu yedek yazılacak.",
													confirmLabel: "Yükle",
													danger: true,
													onConfirm: () => {
														saveData(parseAppData(JSON.stringify({
															projects: parsed.projects,
															tasks: parsed.tasks,
															growth: parsed.growth,
															reminders: parsed.reminders ?? []
														})));
														setModal(null);
														toast.success("Yedek yüklendi.");
													}
												});
											} catch {
												toast.error("Dosya geçerli bir Nexor yedeği değil.");
											}
										};
										reader.readAsText(file);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), " Yedeği yükle"]
								})
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "flex items-center gap-2 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldIcon, {}), " Gizlilik"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Kayıtlar yalnızca bu cihazdaki tarayıcı hafızasında durur. Tarayıcı verisini silersen kayıtlar gidebilir; ara sıra yedek al. Sohbet anahtarın bu sayfada saklanmaz."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									variant: "danger",
									onClick: () => setModal({
										title: "Tüm verileri sil",
										body: "Projeler, görevler, gelişim alanları ve hatırlatıcılar silinir. Sohbet ayrıca durur.",
										confirmLabel: "Hepsini sil",
										danger: true,
										onConfirm: () => {
											saveData(fresh());
											saveChat([]);
											setPending(null);
											setModal(null);
										}
									}),
									children: "Tüm verileri sil"
								})
							})
						] })
					] }),
					tab === "nexor" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-0 flex-1 flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orb, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-lg font-semibold tracking-wide",
										children: "NEXOR"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: "Kişisel asistan · doğrulanmış işlem"
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									variant: "ghost",
									onClick: () => setModal({
										title: "Sohbeti temizle",
										body: "Projelerin ve görevlerin durur. Yalnızca sohbet silinir.",
										confirmLabel: "Temizle",
										onConfirm: () => {
											saveChat([]);
											setPending(null);
											setModal(null);
										}
									}),
									children: "Sohbeti temizle"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								ref: chatRef,
								className: "min-h-0 flex-1 space-y-2 overflow-y-auto rounded-2xl border border-nexor/30 bg-nexor-deep p-3",
								children: [
									chat.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubble, {
										role: "nexor",
										children: "Merhaba. Ben NEXOR. Görevlerini, projelerini ve gelişim alanlarını buradan yönetebilirim. Ne yapıyoruz?"
									}),
									chat.map((msg, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubble, {
										role: msg.role,
										children: msg.content
									}, `${msg.role}-${index}`)),
									pending?.kind === "confirm" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "max-w-bubble rounded-2xl border border-nexor bg-nexor-deep p-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-danger",
											children: pending.error
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex flex-wrap gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
												variant: "danger",
												onClick: confirmChat,
												children: "Evet, kalıcı olarak sil"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
												variant: "ghost",
												onClick: cancelChat,
												children: "Vazgeç"
											})]
										})]
									}),
									pending?.kind === "select" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "max-w-bubble rounded-2xl border border-nexor bg-nexor-deep p-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-ink",
											children: pending.error
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex flex-wrap gap-2",
											children: [pending.candidates.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
												variant: "ghost",
												onClick: () => choose(item.id),
												children: item.label
											}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
												variant: "danger",
												onClick: cancelChat,
												children: "İptal"
											})]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "min-h-6 py-1 text-xs text-nexor",
								"aria-live": "polite",
								children: status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 pb-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "min-h-11 flex-1 rounded-xl border border-nexor/40 bg-bg px-3 text-base text-ink placeholder:text-muted",
										value: input,
										placeholder: "NEXOR’a yaz veya komut ver…",
										autoComplete: "off",
										onChange: (e) => setInput(e.target.value),
										onKeyDown: (e) => {
											if (e.key === "Enter") {
												e.preventDefault();
												unlockSpeech();
												send(input, false);
											}
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": listening ? "Dinlemeyi durdur" : "Sesli komut",
										disabled: sending,
										onClick: toggleVoice,
										className: `inline-flex size-11 items-center justify-center rounded-xl border ${listening ? "border-nexor bg-nexor text-ink" : "border-line bg-surface text-ink"}`,
										children: listening ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Gönder",
										disabled: sending || !input.trim(),
										onClick: () => {
											unlockSpeech();
											send(input, false);
										},
										className: "inline-flex size-11 items-center justify-center rounded-xl bg-nexor text-ink disabled:opacity-50",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
									})
								]
							})
						]
					})
				]
			}),
			tab !== "nexor" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pb-6 text-center text-xs text-muted",
				children: "Nexor · kişisel kullanım"
			}),
			modal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-20 flex items-end justify-center bg-bg/70 p-4 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-2xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg",
							children: modal.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: modal.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: modal.danger ? "danger" : "primary",
								onClick: modal.onConfirm,
								children: modal.confirmLabel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								onClick: () => setModal(null),
								children: "Vazgeç"
							})]
						})
					]
				})
			})
		]
	});
}
function ShieldIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
		className: "size-4 text-gold",
		"aria-hidden": true
	});
}
function Bubble({ role, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `max-w-bubble rounded-2xl border px-3 py-2 text-sm leading-6 whitespace-pre-wrap ${role === "user" ? "ml-auto border-line bg-surface-2" : role === "log" ? "border-line bg-surface text-gold" : role === "err" ? "border-nexor/50 bg-nexor/10 text-danger" : "border-nexor/40 bg-bg text-ink"}`,
		children
	});
}
function TaskRow({ task, data, today, onRun }) {
	const project = data.projects.find((item) => item.id === task.project);
	const overdue = Boolean(today && task.date && !task.done && task.date < today);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-start gap-3 text-sm font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "mt-0.5 size-5 accent-gold",
					type: "checkbox",
					checked: task.done,
					onChange: () => onRun({
						type: "edit_task",
						id: task.id,
						done: !task.done
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: task.name })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
				level: task.priority,
				label: priorityLabel(task.priority)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm text-muted",
			children: [
				project ? `Proje: ${project.name}` : "Genel görev",
				task.date ? ` · Tarih: ${task.date}` : "",
				overdue ? " · Gecikti" : ""
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "ghost",
				onClick: () => onRun({
					type: "delete_task",
					id: task.id
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Sil"]
			})
		})
	] });
}
function ProjectRow({ project, data, onRun }) {
	const related = data.tasks.filter((task) => task.project === project.id);
	const completed = related.filter((task) => task.done).length;
	const pct = related.length ? Math.round(completed / related.length * 100) : project.done ? 100 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: project.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
				level: project.importance,
				label: importanceLabel(project.importance)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: [project.desc, project.date ? ` · Son tarih: ${project.date}` : ""]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, { pct }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-xs text-muted",
				children: [
					"%",
					pct,
					" · ",
					completed,
					"/",
					related.length,
					" görev"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => onRun({
						type: "edit_project",
						id: project.id,
						done: !project.done
					}),
					children: project.done ? "Geri al" : "Bitir"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "danger",
					onClick: () => onRun({
						type: "delete_project",
						id: project.id
					}),
					children: "Sil"
				})]
			})]
		})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NexorApp, {});
}
//#endregion
export { Home as component };
