import { o as __toESM } from "../_runtime.mjs";
import { S as useNavigate, Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as Gem, h as House, p as Moon, r as Users } from "../_libs/lucide-react.mjs";
import { _ as joinGroup, h as getMe } from "./auth-screens-DZe0plYT.mjs";
import { i as useSalon, t as Shell$1 } from "./shell-DSe4icyb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/groups-g16tEzCl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	everyone: Users,
	family: House,
	yandere: Moon,
	suitor: Gem
};
function GroupsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Groups, {}) });
}
function Groups() {
	const navigate = useNavigate();
	const bump = useSalon((s) => s.bump);
	const [groups, setGroups] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		getMe().then((me) => {
			if (live) setGroups(me.groups);
		}).catch((err) => {
			if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
		});
		return () => {
			live = false;
		};
	}, []);
	async function enter(group) {
		if (!group.joined) {
			setPending(group.slug);
			const result = await joinGroup({ data: { slug: group.slug } });
			setPending(null);
			if (!result.ok) {
				setError(result.error);
				return;
			}
			bump();
		}
		await navigate({
			to: "/groups/$slug",
			params: { slug: group.slug }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-rose",
					children: "غرف"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: "المجموعات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-6 text-mute",
					children: "الدخول فوري. الجماعة الشاملة معك رغماً عن أي اختيار آخر."
				})
			] }),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-rose",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: (groups ?? []).map((group) => {
					const Icon = ICONS[group.slug] ?? Users;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-3xl bg-paper p-4 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 shrink-0 place-items-center rounded-2xl bg-rose/10 text-rose",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									strokeWidth: 1.75
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "font-display text-2xl leading-snug",
											children: group.name
										}), group.forced ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-rose",
											children: "معك دائماً"
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm leading-6 text-mute",
										children: group.blurb
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-xs tabular-nums text-mute",
										children: [group.members, " عضو"]
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: pending === group.slug,
							onClick: () => void enter(group),
							className: "mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-rose text-sm font-medium text-paper disabled:opacity-50",
							children: pending === group.slug ? "لحظات…" : group.joined ? "ادخل" : "انضمام ودخول"
						})]
					}, group.slug);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-xs text-mute",
				children: ["أو من ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/search",
					search: { q: "" },
					className: "text-rose",
					children: "البحث"
				})]
			})
		]
	});
}
//#endregion
export { GroupsPage as component };
