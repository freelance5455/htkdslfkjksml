import { a as categoryLabel, i as campaignLabel, o as styleFragment } from "./options-I4YTksiA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/prompts-C2oS8e1R.js
var BASELINE = `Photorealistic lifestyle product photography using the exact product from the uploaded reference images. Preserve the original product geometry, proportions, colors, materials, textures, branding, printed details, construction and every visible design element exactly as shown in the reference. Do not redesign, reshape, simplify, replace, add or remove any part of the product. The product must remain visually identical across all storyboard scenes.

Natural realistic photography, authentic environment, realistic lighting and shadows, realistic material texture, natural depth of field, subtle smartphone camera characteristics, slightly imperfect composition, believable human interaction when needed, aesthetically pleasing but not overly polished, no CGI, no 3D render, no plastic-looking surfaces, no surreal elements.`;
var LOCK_SENTENCE = "Use the exact product from the uploaded reference images. Preserve the original product geometry, proportions, colors, materials, textures, branding, printed details, construction and every visible design element. Do not redesign, reshape, simplify, replace, add or remove any part of the product.";
var VIDEO_LOCK = [
	"Keep the product exactly unchanged throughout the animation.",
	"Do not morph the product.",
	"Do not change the product shape.",
	"Do not change colors, logos, text or printed details.",
	"Do not add or remove product parts.",
	"Maintain consistent geometry and proportions.",
	"Keep the background stable.",
	"Natural realistic motion."
].join("\n");
function groupOf(category) {
	const c = category.toLowerCase();
	if ([
		"hardbox",
		"hampers",
		"packaging",
		"gift"
	].includes(c)) return "gift";
	if (c === "fashion") return "fashion";
	if (c === "beauty") return "beauty";
	if (c === "food") return "food";
	if (c === "beverage") return "beverage";
	if (c === "jewelry") return "jewelry";
	if (c === "flower") return "flower";
	if (c === "furniture") return "furniture";
	return "general";
}
function campaignEnvironment(campaign, custom) {
	if (campaign === "Custom") {
		const text = custom.trim() || "a personal occasion";
		return {
			background: `a real place fitting this occasion: ${text}`,
			props: "a few small props beside the product only, never attached to it and never covering logos",
			lighting: "the same natural light direction in every scene",
			mood: text
		};
	}
	const map = {
		Christmas: {
			background: "a real home interior with a quiet seasonal feeling",
			props: "a few pine sprigs and a plain ribbon placed beside the product, not on logos or openings",
			lighting: "soft window daylight plus a warm practical lamp, realistic shadows",
			mood: "calm, festive, intimate"
		},
		"Eid / Ramadan": {
			background: "a calm Indonesian home prepared for Eid",
			props: "a simple tray or dates kept in the background, not attached to the product",
			lighting: "warm evening indoor light, realistic and soft",
			mood: "warm, respectful, celebratory"
		},
		"Valentine's Day": {
			background: "a real table at home, softly dressed",
			props: "one or two flowers or a small card beside the product, not covering it",
			lighting: "soft natural side light",
			mood: "tender, quiet, close"
		},
		Birthday: {
			background: "a real home table set for a birthday",
			props: "a small cake or candle far enough not to hide the product",
			lighting: "bright natural indoor light",
			mood: "warm and personal"
		},
		Wedding: {
			background: "a bright real ceremony or getting-ready room",
			props: "soft fabric and a small floral sprig beside the product only",
			lighting: "clean daylight, gentle contrast",
			mood: "graceful, calm, celebratory"
		},
		Anniversary: {
			background: "a quiet real dining table at home",
			props: "minimal table setting beside the product",
			lighting: "evening window light, realistic",
			mood: "intimate and steady"
		},
		"Mother's Day": {
			background: "a bright home corner, flowers optional in the background",
			props: "a simple note or bloom beside the product",
			lighting: "soft morning daylight",
			mood: "gentle and sincere"
		},
		"Father's Day": {
			background: "a real lived-in home desk or table",
			props: "one everyday object beside the product, not a costume prop",
			lighting: "natural side light",
			mood: "grounded and warm"
		},
		"New Product": {
			background: "a clean real tabletop or interior, not a virtual void",
			props: "almost none, nothing covering branding",
			lighting: "soft natural daylight from one side, realistic shadows",
			mood: "clear, fresh, credible"
		},
		"Product Promotion": {
			background: "a tidy real setting where the product reads immediately",
			props: "only props that explain use, kept off the product body",
			lighting: "clear natural light, true color",
			mood: "direct and trustworthy"
		},
		"Luxury Gift": {
			background: "a quiet upscale real interior with linen, stone, or wood",
			props: "very few, refined, never plastic, never covering the product",
			lighting: "controlled soft daylight, deep but real shadows",
			mood: "quiet luxury"
		}
	};
	return map[campaign] ?? map["New Product"];
}
var PICK = {
	3: [
		0,
		2,
		9
	],
	4: [
		0,
		1,
		3,
		9
	],
	5: [
		0,
		1,
		2,
		4,
		9
	],
	6: [
		0,
		1,
		2,
		3,
		4,
		9
	],
	7: [
		0,
		1,
		2,
		3,
		4,
		7,
		9
	],
	8: [
		0,
		1,
		2,
		3,
		4,
		5,
		7,
		9
	],
	9: [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		9
	],
	10: [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9
	]
};
var TITLES = {
	gift: [
		"Aesthetic Product Setup",
		"First Touch",
		"Opening the Product",
		"First Gift Reveal",
		"Product Detail Close-Up",
		"Lifestyle Context",
		"Placing the Gift",
		"Three-Quarter View",
		"Top-Down Reveal",
		"Final Aesthetic Product Display"
	],
	fashion: [
		"Styled Setup",
		"First Touch",
		"Natural Wear",
		"Look Reveal",
		"Material Close-Up",
		"Lifestyle Context",
		"Adjusting the Fit",
		"Three-Quarter View",
		"Flat Lay",
		"Hero Look"
	],
	beauty: [
		"Vanity Setup",
		"First Touch",
		"Simple Application",
		"Product Reveal",
		"Texture Close-Up",
		"Lifestyle Context",
		"Setting it Down",
		"Three-Quarter View",
		"Top-Down Still Life",
		"Hero Product Display"
	],
	food: [
		"Table Setup",
		"First Touch",
		"Serving Moment",
		"Food Reveal",
		"Texture Close-Up",
		"Shared Table",
		"Placing the Dish",
		"Three-Quarter View",
		"Top-Down Plate",
		"Hero Serving"
	],
	beverage: [
		"Table Setup",
		"First Touch",
		"Holding the Drink",
		"Label Reveal",
		"Detail Close-Up",
		"Lifestyle Sip Setting",
		"Setting the Glass Aside",
		"Three-Quarter View",
		"Top-Down",
		"Hero Pour Still"
	],
	jewelry: [
		"Quiet Setup",
		"First Touch",
		"On Skin",
		"Sparkle Reveal",
		"Macro Detail",
		"Lifestyle Context",
		"Placing the Piece",
		"Three-Quarter View",
		"Top-Down",
		"Hero Still"
	],
	flower: [
		"Arrangement Setup",
		"First Touch",
		"Adjusting Blooms",
		"Bouquet Reveal",
		"Petal Close-Up",
		"Room Context",
		"Setting the Vase",
		"Three-Quarter View",
		"Top-Down",
		"Hero Arrangement"
	],
	furniture: [
		"Room Setup",
		"First Touch",
		"Using the Piece",
		"Form Reveal",
		"Material Close-Up",
		"Wide Room Context",
		"Beside the Piece",
		"Three-Quarter View",
		"Top Detail",
		"Hero Placement"
	],
	general: [
		"Aesthetic Product Setup",
		"First Touch",
		"Using the Product",
		"Product Reveal",
		"Product Detail Close-Up",
		"Lifestyle Context",
		"Placing the Product",
		"Three-Quarter View",
		"Top-Down View",
		"Final Aesthetic Product Display"
	]
};
var DISTANCE = [
	"wide shot",
	"medium shot",
	"close-up",
	"medium-close three-quarter",
	"macro close-up",
	"medium environmental shot",
	"medium shot",
	"three-quarter view",
	"top-down",
	"hero shot"
];
var ANGLE = [
	"slightly above eye level",
	"eye level",
	"close, slight three-quarter",
	"three-quarter, just below eye level",
	"straight into the most identifying detail",
	"eye level, a step back",
	"eye level from the side",
	"classic three-quarter",
	"directly overhead",
	"eye-level hero, centered but not perfectly symmetric"
];
function interaction(group, index) {
	if (index === 0 || index === 4 || index === 5 || index === 7 || index === 8 || index === 9) {
		const motions = [
			"slow camera push-in",
			"gentle handheld micro-movement",
			"slow push-in",
			"subtle camera drift",
			"very slow push-in on the detail",
			"subtle parallax, camera barely moves",
			"hand moves, product stays rigid",
			"gentle camera pan of only a few degrees",
			"locked-off camera with a slight push-in",
			"slow camera push-in"
		];
		const humans = [
			"No person. The product is alone and fully visible.",
			"One hand may rest near the product without covering logos.",
			"Interaction only if it does not hide the product structure.",
			"No person, or only an out-of-focus shoulder far behind.",
			"No face. Fingertips only if they give scale and do not cover print.",
			"No person. The room explains the story.",
			"A hand is beside the product.",
			"No person.",
			"No person. Entire product footprint stays visible.",
			"No person. Hero frame, product fully readable."
		];
		return {
			human: humans[index] ?? humans[0],
			motion: motions[index] ?? motions[0]
		};
	}
	if (index === 1 || index === 6) return {
		human: "One realistic hand enters from the side and lightly touches or places something beside the product. Five fingers, natural skin, no extra limbs. The hand must not cover the logo or change the product.",
		motion: index === 1 ? "gentle handheld movement while one hand lightly touches the product" : "a hand places a small prop beside the product; the product itself does not deform"
	};
	if (index === 3) return {
		human: "The product is revealed more clearly. A hand may leave the frame. Do not add parts during the reveal.",
		motion: "slow product reveal with a short push-in, product geometry frozen"
	};
	return {
		gift: {
			human: "A hand opens the product only if a lid, flap, ribbon already on it, or drawer is visible in the reference photos. If none is visible, the hand rests beside the closed product. Do not invent a drawer, door, or handle.",
			motion: "If the references show a lid, open it slowly once. If they show drawers, open one existing drawer slightly. If neither exists, use only a slow camera push-in. Never bend the box."
		},
		fashion: {
			human: "The garment is held or worn naturally. Do not change the cut, print, seams, or closures.",
			motion: "a small natural shift of fabric from a hand or a step, garment construction unchanged"
		},
		beauty: {
			human: "A hand holds the closed product or does one simple application. Do not change the cap, pump, label, or bottle shape.",
			motion: "a hand tilts or holds the product slightly; the container does not morph"
		},
		food: {
			human: "A hand presents or serves the product as it already exists. Do not reshape the food or the packaging.",
			motion: "a hand sets the product down or lifts a lid only if a lid is visible in the references"
		},
		beverage: {
			human: "A hand holds the bottle, can, or cup. Do not change the label, cap, or container. Do not pour if pouring would hide the product shape.",
			motion: "a hand lifts the container a little, or a slow push-in. The container stays rigid."
		},
		jewelry: {
			human: "The piece rests against skin or is held lightly. Do not change stones, metal, prongs, or clasp.",
			motion: "a very small wrist turn or a slow push-in. Metal geometry stays fixed."
		},
		flower: {
			human: "A hand may adjust a stem or an existing ribbon. Do not rebuild the arrangement into a different bouquet.",
			motion: "a hand makes one small adjustment, then rests. Flowers do not grow or change count."
		},
		furniture: {
			human: "A hand may open a door or drawer only if that door or drawer is visible in the references. Otherwise the hand rests on an existing edge. Nobody climbs the piece.",
			motion: "If a drawer or door exists in the references, it opens slightly once. Otherwise only a slow camera move. Joints stay rigid."
		},
		general: {
			human: "A hand interacts in the simplest way the product allows. Do not add lids, buttons, drawers, or handles that are not in the references.",
			motion: "one simple hand motion or, if interaction is unclear, a slow camera push-in only"
		}
	}[group];
}
function localBeats(project) {
	const group = groupOf(project.category === "Custom" ? project.customCategory : project.category);
	const env = campaignEnvironment(project.campaign, project.customCampaign);
	const titles = TITLES[group];
	const count = Math.min(10, Math.max(3, project.sceneCount));
	const indexes = PICK[count] ?? PICK[6];
	const storyBit = project.story.trim() ? project.story.trim() : `A clear visual story for this ${categoryLabel(project.category, project.customCategory).toLowerCase()} around ${campaignLabel(project.campaign, project.customCampaign)}.`;
	return indexes.map((index, order) => {
		const act = interaction(group, index);
		return {
			title: titles[index] ?? `Scene ${order + 1}`,
			description: `${storyBit} Beat ${order + 1} of ${count}: ${titles[index]}. Same product, same place, new camera position.`,
			cameraAngle: ANGLE[index] ?? "eye level",
			cameraDistance: DISTANCE[index] ?? "medium shot",
			lighting: `${env.lighting}. Keep this light direction for the whole storyboard.`,
			background: env.background,
			props: env.props,
			humanInteraction: act.human,
			mood: env.mood,
			motion: act.motion
		};
	});
}
function buildImagePrompt(project, scene) {
	const category = categoryLabel(project.category, project.customCategory);
	const campaign = campaignLabel(project.campaign, project.customCampaign);
	const style = styleFragment(project.style, project.customStyle);
	const profile = project.profile.trim() || "The uploaded reference photos are one single product seen from different angles. Identity comes only from those photos: shape, proportions, color, material, texture, logo, printed text, pattern, part count, drawers, handles, knobs, lids, and opening mechanism. Do not invent parts that are not visible.";
	return [
		BASELINE,
		`Photography style: ${project.style}. ${style}`,
		`Aspect ratio ${project.aspect}. Compose the photograph for a ${project.aspect} frame.`,
		`Product category: ${category}.`,
		`Campaign / occasion: ${campaign}. Campaign styling may change only the background, lighting, props, and human interaction. Never restyle, recolor, or rebuild the product to match the campaign.`,
		project.story.trim() ? `Story: ${project.story.trim()}` : "",
		`Scene: ${scene.title}. ${scene.description}`,
		`Subject: the exact uploaded product, fully visible, not cropped through logos or structural edges.`,
		`Product position: primary subject, readable, stable, consistent scale relative to hands and furniture.`,
		`Camera angle: ${scene.cameraAngle}. Camera distance: ${scene.cameraDistance}.`,
		`Composition: one photoshoot session shared with the other scenes. Same location, time of day, color temperature, and mood. This scene changes angle and distance so the board is not repetitive.`,
		`Environment and background: ${scene.background}.`,
		`Lighting: ${scene.lighting}.`,
		`Props: ${scene.props}.`,
		`Human interaction: ${scene.humanInteraction}.`,
		`Mood: ${scene.mood}.`,
		`Product consistency profile, highest priority after the reference photos: ${profile}`,
		project.consistencyLock ? LOCK_SENTENCE : "Consistency lock is off, but do not casually redesign the product.",
		"All uploaded photos are the same one product from different angles, including front, side, back, or open states. Do not merge them into a new product.",
		"If a part is not visible in the references, do not add it. If a part is visible, do not remove it.",
		"The attached images are the primary visual reference."
	].filter(Boolean).join("\n\n");
}
function buildVideoPrompt(project, scene) {
	const profile = project.profile.trim() || "The uploaded reference photos are one single product seen from different angles. Identity comes only from those photos: shape, proportions, color, material, texture, logo, printed text, pattern, part count, drawers, handles, knobs, lids, and opening mechanism. Do not invent parts that are not visible.";
	return [
		`Animate this storyboard still, "${scene.title}".`,
		scene.description,
		`Motion, one action only: ${scene.motion}`,
		"Choose a physically possible move. Product-only frames use camera movement. Hands stay simple. Open a drawer or lid only if that part exists on this product.",
		`Product facts to preserve: ${profile}`,
		project.consistencyLock ? "The product is a locked visual identity." : "",
		VIDEO_LOCK
	].filter(Boolean).join("\n\n");
}
function scenesFromBeats(project, beats) {
	return beats.map((beat) => ({
		...beat,
		imagePrompt: buildImagePrompt(project, beat),
		videoPrompt: buildVideoPrompt(project, beat)
	}));
}
function rebuildScenePrompts(project, scene) {
	const beat = {
		title: scene.title,
		description: scene.description,
		cameraAngle: scene.cameraAngle,
		cameraDistance: scene.cameraDistance,
		lighting: scene.lighting,
		background: scene.background,
		props: scene.props,
		humanInteraction: scene.humanInteraction,
		mood: scene.mood,
		motion: scene.motion
	};
	return {
		...scene,
		imagePrompt: buildImagePrompt(project, beat),
		videoPrompt: buildVideoPrompt(project, beat)
	};
}
function buildAnalyzePrompt(project, beats) {
	const category = categoryLabel(project.category, project.customCategory);
	const campaign = campaignLabel(project.campaign, project.customCampaign);
	return `You are directing a product photo storyboard. The attached images are ONE product from several angles. Study them before writing.

Return JSON only, no markdown:
{
  "productName": "short name, 2-6 words",
  "profile": "visible facts only: shape, color, material, structure, part counts, drawers, lids, handles, knobs, logos, readable text, patterns, opening mechanism. If unknown, say it is not visible. Do not invent.",
  "scenes": [ exactly ${beats.length} objects with title, description, cameraAngle, cameraDistance, lighting, background, props, humanInteraction, mood, motion ]
}

Rules:
- Category: ${category}
- Occasion: ${campaign}
- Story from the user: ${project.story.trim() || "(none — invent a natural arc from the category and occasion)"}
- Photography style: ${project.style}. ${styleFragment(project.style, project.customStyle)}
- Aspect ratio for every scene: ${project.aspect}
- Scene titles: short. Use the user's language if the story is written. Otherwise English.
- Keep one location, one lighting setup, one mood. Vary camera angle and distance.
- Do not redesign the product. Do not change drawer count, handles into knobs, lids, printed words, or colors.
- Human motion must be physically possible for THIS product. If the photos show no drawer, do not open a drawer.
- Suggested arc you may improve but must keep the same scene count:
${beats.map((b, i) => `${i + 1}. ${b.title} — ${b.cameraDistance}, ${b.cameraAngle}. Motion idea: ${b.motion}`).join("\n")}`;
}
function aspectFrameClass(aspect) {
	if (aspect === "1:1") return "frame-1-1";
	if (aspect === "4:5") return "frame-4-5";
	if (aspect === "16:9") return "frame-16-9";
	return "frame-9-16";
}
function withImageGuards(prompt, profile, lock) {
	const chunks = [];
	if (!prompt.includes("Photorealistic lifestyle product photography")) chunks.push(BASELINE);
	chunks.push(prompt.trim());
	if (!prompt.includes("Use the exact product from the uploaded reference images.")) chunks.push(LOCK_SENTENCE);
	if (lock && profile.trim() && !prompt.includes(profile.trim().slice(0, 60))) chunks.push(`Product consistency profile: ${profile.trim()}`);
	if (!prompt.includes("primary visual reference")) chunks.push("The attached images are the primary visual reference and show one single product. Do not invent a different product.");
	return chunks.join("\n\n").slice(0, 7e3);
}
//#endregion
export { scenesFromBeats as a, rebuildScenePrompts as i, buildAnalyzePrompt as n, withImageGuards as o, localBeats as r, aspectFrameClass as t };
