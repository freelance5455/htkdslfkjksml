//#region node_modules/.nitro/vite/services/ssr/assets/catalog-J4SrKMs0.js
var crest = (file) => `https://a.espncdn.com/i/leaguelogos/soccer/500/${file}.png`;
function splitSeason(now = /* @__PURE__ */ new Date()) {
	const y = now.getFullYear();
	const start = now.getMonth() >= 6 ? y : y - 1;
	return {
		start,
		label: `${start}-${start + 1}`
	};
}
function calendarSeason(now = /* @__PURE__ */ new Date()) {
	return String(now.getFullYear());
}
var LEAGUES = [
	{
		id: "eng.1",
		nameAr: "الدوري الإنجليزي",
		nameEn: "Premier League",
		countryAr: "إنجلترا",
		countryEn: "England",
		region: "europe",
		source: "espn",
		espn: "eng.1",
		seasonKind: "split",
		logo: crest("23"),
		featured: true
	},
	{
		id: "esp.1",
		nameAr: "الدوري الإسباني",
		nameEn: "LaLiga",
		countryAr: "إسبانيا",
		countryEn: "Spain",
		region: "europe",
		source: "espn",
		espn: "esp.1",
		seasonKind: "split",
		logo: crest("15"),
		featured: true
	},
	{
		id: "ita.1",
		nameAr: "الدوري الإيطالي",
		nameEn: "Serie A",
		countryAr: "إيطاليا",
		countryEn: "Italy",
		region: "europe",
		source: "espn",
		espn: "ita.1",
		seasonKind: "split",
		logo: crest("12"),
		featured: true
	},
	{
		id: "ger.1",
		nameAr: "الدوري الألماني",
		nameEn: "Bundesliga",
		countryAr: "ألمانيا",
		countryEn: "Germany",
		region: "europe",
		source: "espn",
		espn: "ger.1",
		seasonKind: "split",
		logo: crest("10"),
		featured: true
	},
	{
		id: "fra.1",
		nameAr: "الدوري الفرنسي",
		nameEn: "Ligue 1",
		countryAr: "فرنسا",
		countryEn: "France",
		region: "europe",
		source: "espn",
		espn: "fra.1",
		seasonKind: "split",
		logo: crest("9")
	},
	{
		id: "por.1",
		nameAr: "الدوري البرتغالي",
		nameEn: "Primeira Liga",
		countryAr: "البرتغال",
		countryEn: "Portugal",
		region: "europe",
		source: "espn",
		espn: "por.1",
		seasonKind: "split",
		logo: crest("14")
	},
	{
		id: "ned.1",
		nameAr: "الدوري الهولندي",
		nameEn: "Eredivisie",
		countryAr: "هولندا",
		countryEn: "Netherlands",
		region: "europe",
		source: "espn",
		espn: "ned.1",
		seasonKind: "split",
		logo: crest("11")
	},
	{
		id: "tur.1",
		nameAr: "الدوري التركي",
		nameEn: "Süper Lig",
		countryAr: "تركيا",
		countryEn: "Turkey",
		region: "europe",
		source: "espn",
		espn: "tur.1",
		seasonKind: "split",
		logo: crest("18")
	},
	{
		id: "uefa.champions",
		nameAr: "دوري أبطال أوروبا",
		nameEn: "Champions League",
		countryAr: "أوروبا",
		countryEn: "Europe",
		region: "europe",
		source: "espn",
		espn: "uefa.champions",
		seasonKind: "split",
		logo: crest("2"),
		featured: true
	},
	{
		id: "uefa.europa",
		nameAr: "الدوري الأوروبي",
		nameEn: "Europa League",
		countryAr: "أوروبا",
		countryEn: "Europe",
		region: "europe",
		source: "espn",
		espn: "uefa.europa",
		seasonKind: "split",
		logo: crest("2310"),
		featured: true
	},
	{
		id: "uefa.europa.conf",
		nameAr: "دوري المؤتمر الأوروبي",
		nameEn: "Conference League",
		countryAr: "أوروبا",
		countryEn: "Europe",
		region: "europe",
		source: "espn",
		espn: "uefa.europa.conf",
		seasonKind: "split",
		logo: crest("20296")
	},
	{
		id: "ger.2",
		nameAr: "الألماني الدرجة الثانية",
		nameEn: "2. Bundesliga",
		countryAr: "ألمانيا",
		countryEn: "Germany",
		region: "europe",
		source: "espn",
		espn: "ger.2",
		seasonKind: "split",
		logo: crest("97")
	},
	{
		id: "bl3",
		nameAr: "الألماني الدرجة الثالثة",
		nameEn: "3. Liga",
		countryAr: "ألمانيا",
		countryEn: "Germany",
		region: "europe",
		source: "openliga",
		openliga: "bl3",
		seasonKind: "openliga",
		logo: null
	},
	{
		id: "dfb",
		nameAr: "كأس ألمانيا",
		nameEn: "DFB-Pokal",
		countryAr: "ألمانيا",
		countryEn: "Germany",
		region: "europe",
		source: "openliga",
		openliga: "dfb",
		seasonKind: "openliga",
		logo: null
	},
	{
		id: "egy",
		nameAr: "الدوري المصري",
		nameEn: "Egyptian Premier League",
		countryAr: "مصر",
		countryEn: "Egypt",
		region: "arab",
		source: "sportsdb",
		sportsdbId: "4829",
		seasonKind: "split",
		logo: null,
		featured: true,
		arab: true
	},
	{
		id: "ksa.1",
		nameAr: "الدوري السعودي",
		nameEn: "Saudi Pro League",
		countryAr: "السعودية",
		countryEn: "Saudi Arabia",
		region: "arab",
		source: "espn",
		espn: "ksa.1",
		seasonKind: "split",
		logo: crest("2488"),
		featured: true,
		arab: true
	},
	{
		id: "uae",
		nameAr: "الدوري الإماراتي",
		nameEn: "UAE Pro League",
		countryAr: "الإمارات",
		countryEn: "UAE",
		region: "arab",
		source: "sportsdb",
		sportsdbId: "4678",
		seasonKind: "split",
		logo: null,
		arab: true
	},
	{
		id: "qat",
		nameAr: "الدوري القطري",
		nameEn: "Qatar Stars League",
		countryAr: "قطر",
		countryEn: "Qatar",
		region: "arab",
		source: "sportsdb",
		sportsdbId: "4663",
		seasonKind: "split",
		logo: null,
		arab: true
	},
	{
		id: "mar",
		nameAr: "البطولة المغربية",
		nameEn: "Moroccan Championship",
		countryAr: "المغرب",
		countryEn: "Morocco",
		region: "arab",
		source: "sportsdb",
		sportsdbId: "4520",
		seasonKind: "split",
		logo: null,
		arab: true
	},
	{
		id: "alg",
		nameAr: "الدوري الجزائري",
		nameEn: "Algerian Ligue 1",
		countryAr: "الجزائر",
		countryEn: "Algeria",
		region: "arab",
		source: "sportsdb",
		sportsdbId: "4753",
		seasonKind: "split",
		logo: null,
		arab: true
	},
	{
		id: "tun",
		nameAr: "الدوري التونسي",
		nameEn: "Tunisian Ligue 1",
		countryAr: "تونس",
		countryEn: "Tunisia",
		region: "arab",
		source: "sportsdb",
		sportsdbId: "4828",
		seasonKind: "split",
		logo: null,
		arab: true
	},
	{
		id: "caf.champions",
		nameAr: "دوري أبطال أفريقيا",
		nameEn: "CAF Champions League",
		countryAr: "أفريقيا",
		countryEn: "Africa",
		region: "africa",
		source: "espn",
		espn: "caf.champions",
		seasonKind: "split",
		logo: crest("2391"),
		featured: true
	},
	{
		id: "caf.confed",
		nameAr: "الكونفدرالية الأفريقية",
		nameEn: "CAF Confederation Cup",
		countryAr: "أفريقيا",
		countryEn: "Africa",
		region: "africa",
		source: "espn",
		espn: "caf.confed",
		seasonKind: "split",
		logo: null
	},
	{
		id: "rsa.1",
		nameAr: "الدوري الجنوب أفريقي",
		nameEn: "South African Premiership",
		countryAr: "جنوب أفريقيا",
		countryEn: "South Africa",
		region: "africa",
		source: "espn",
		espn: "rsa.1",
		seasonKind: "split",
		logo: null
	},
	{
		id: "caf.nations",
		nameAr: "كأس أمم أفريقيا",
		nameEn: "Africa Cup of Nations",
		countryAr: "أفريقيا",
		countryEn: "Africa",
		region: "world",
		source: "espn",
		espn: "caf.nations",
		seasonKind: "split",
		logo: crest("76"),
		national: true
	},
	{
		id: "jpn.1",
		nameAr: "الدوري الياباني",
		nameEn: "J1 League",
		countryAr: "اليابان",
		countryEn: "Japan",
		region: "asia",
		source: "espn",
		espn: "jpn.1",
		seasonKind: "calendar",
		logo: crest("2199")
	},
	{
		id: "kor",
		nameAr: "الدوري الكوري",
		nameEn: "K League 1",
		countryAr: "كوريا الجنوبية",
		countryEn: "South Korea",
		region: "asia",
		source: "sportsdb",
		sportsdbId: "4689",
		seasonKind: "calendar",
		logo: null
	},
	{
		id: "afc.champions",
		nameAr: "دوري أبطال آسيا",
		nameEn: "AFC Champions League",
		countryAr: "آسيا",
		countryEn: "Asia",
		region: "asia",
		source: "espn",
		espn: "afc.champions",
		seasonKind: "split",
		logo: crest("2200")
	},
	{
		id: "afc.asian.cup",
		nameAr: "كأس آسيا",
		nameEn: "AFC Asian Cup",
		countryAr: "آسيا",
		countryEn: "Asia",
		region: "world",
		source: "espn",
		espn: "afc.asian.cup",
		seasonKind: "split",
		logo: crest("2243"),
		national: true
	},
	{
		id: "bra.1",
		nameAr: "الدوري البرازيلي",
		nameEn: "Brasileirão",
		countryAr: "البرازيل",
		countryEn: "Brazil",
		region: "americas",
		source: "espn",
		espn: "bra.1",
		seasonKind: "calendar",
		logo: crest("85")
	},
	{
		id: "arg.1",
		nameAr: "الدوري الأرجنتيني",
		nameEn: "Liga Profesional",
		countryAr: "الأرجنتين",
		countryEn: "Argentina",
		region: "americas",
		source: "espn",
		espn: "arg.1",
		seasonKind: "calendar",
		logo: crest("1")
	},
	{
		id: "usa.1",
		nameAr: "الدوري الأمريكي",
		nameEn: "MLS",
		countryAr: "الولايات المتحدة",
		countryEn: "USA",
		region: "americas",
		source: "espn",
		espn: "usa.1",
		seasonKind: "calendar",
		logo: crest("19")
	},
	{
		id: "conmebol.america",
		nameAr: "كوبا أمريكا",
		nameEn: "Copa América",
		countryAr: "أمريكا الجنوبية",
		countryEn: "South America",
		region: "world",
		source: "espn",
		espn: "conmebol.america",
		seasonKind: "split",
		logo: crest("83"),
		national: true
	},
	{
		id: "fifa.world",
		nameAr: "كأس العالم",
		nameEn: "FIFA World Cup",
		countryAr: "عالمي",
		countryEn: "World",
		region: "world",
		source: "espn",
		espn: "fifa.world",
		seasonKind: "split",
		logo: crest("4"),
		national: true,
		featured: true
	},
	{
		id: "uefa.euro",
		nameAr: "أمم أوروبا",
		nameEn: "UEFA Euro",
		countryAr: "أوروبا",
		countryEn: "Europe",
		region: "world",
		source: "espn",
		espn: "uefa.euro",
		seasonKind: "split",
		logo: crest("74"),
		national: true
	}
];
var byId = new Map(LEAGUES.map((l) => [l.id, l]));
var byEspn = new Map(LEAGUES.filter((l) => l.espn).map((l) => [l.espn, l]));
function leagueById(id) {
	return byId.get(id) ?? null;
}
function leagueByEspn(slug) {
	return byEspn.get(slug) ?? null;
}
function seasonLabel(def, now = /* @__PURE__ */ new Date()) {
	if (def.seasonKind === "calendar") return calendarSeason(now);
	return splitSeason(now).label;
}
function openligaYear(now = /* @__PURE__ */ new Date()) {
	return splitSeason(now).start;
}
var teamLogo = (id) => `https://a.espncdn.com/i/teamlogos/soccer/500/${id}.png`;
var SUGGESTED_CLUBS = [
	{
		id: "10207",
		name: "Al Ahly",
		nameAr: "الأهلي",
		leagueId: "caf.champions",
		logo: teamLogo("10207")
	},
	{
		id: "8392",
		name: "Zamalek",
		nameAr: "الزمالك",
		leagueId: "caf.champions",
		logo: teamLogo("8392")
	},
	{
		id: "20220",
		name: "Pyramids FC",
		nameAr: "بيراميدز",
		leagueId: "caf.champions",
		logo: teamLogo("20220")
	},
	{
		id: "929",
		name: "Al Hilal",
		nameAr: "الهلال",
		leagueId: "ksa.1",
		logo: teamLogo("929")
	},
	{
		id: "817",
		name: "Al Nassr",
		nameAr: "النصر",
		leagueId: "ksa.1",
		logo: teamLogo("817")
	},
	{
		id: "364",
		name: "Liverpool",
		nameAr: "ليفربول",
		leagueId: "eng.1",
		logo: teamLogo("364")
	},
	{
		id: "86",
		name: "Real Madrid",
		nameAr: "ريال مدريد",
		leagueId: "esp.1",
		logo: teamLogo("86")
	},
	{
		id: "83",
		name: "Barcelona",
		nameAr: "برشلونة",
		leagueId: "esp.1",
		logo: teamLogo("83")
	},
	{
		id: "382",
		name: "Manchester City",
		nameAr: "مانشستر سيتي",
		leagueId: "eng.1",
		logo: teamLogo("382")
	},
	{
		id: "360",
		name: "Manchester United",
		nameAr: "مانشستر يونايتد",
		leagueId: "eng.1",
		logo: teamLogo("360")
	},
	{
		id: "359",
		name: "Arsenal",
		nameAr: "آرسنال",
		leagueId: "eng.1",
		logo: teamLogo("359")
	},
	{
		id: "363",
		name: "Chelsea",
		nameAr: "تشيلسي",
		leagueId: "eng.1",
		logo: teamLogo("363")
	},
	{
		id: "132",
		name: "Bayern Munich",
		nameAr: "بايرن ميونخ",
		leagueId: "ger.1",
		logo: teamLogo("132")
	},
	{
		id: "160",
		name: "Paris Saint-Germain",
		nameAr: "باريس سان جيرمان",
		leagueId: "fra.1",
		logo: teamLogo("160")
	},
	{
		id: "111",
		name: "Juventus",
		nameAr: "يوفنتوس",
		leagueId: "ita.1",
		logo: teamLogo("111")
	},
	{
		id: "103",
		name: "AC Milan",
		nameAr: "ميلان",
		leagueId: "ita.1",
		logo: teamLogo("103")
	},
	{
		id: "110",
		name: "Inter",
		nameAr: "إنتر",
		leagueId: "ita.1",
		logo: teamLogo("110")
	}
];
function initials(name) {
	const parts = name.replace(/[^\p{L}\p{N} ]/gu, "").trim().split(/\s+/).filter(Boolean);
	if (!parts.length) return "FC";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
//#endregion
export { leagueById as a, leagueByEspn as i, SUGGESTED_CLUBS as n, openligaYear as o, initials as r, seasonLabel as s, LEAGUES as t };
