import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as formatDuration, H as useRuntime, V as useAppStore, a as Button, h as Notice, k as formatBytes, p as MetricRow, z as sessionElapsed } from "./ui-CJMJB--P.mjs";
import { n as useDeviceSnapshot } from "./refresh-measure-CQ_5yNsN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session-clock-Dj1rOmaj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DevicePanel() {
	const snap = useDeviceSnapshot();
	const [showUa, setShowUa] = (0, import_react.useState)(false);
	if (!snap) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Reading what this browser can report…"
	});
	const memory = snap.memoryGb == null ? null : `About ${snap.memoryGb} GB`;
	const storage = snap.storage && (snap.storage.usage != null || snap.storage.quota != null) ? `${snap.storage.usage != null ? formatBytes(snap.storage.usage) : "—"} used` + (snap.storage.quota != null ? ` of about ${formatBytes(snap.storage.quota)}` : "") : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Browser",
				value: snap.browser,
				source: snap.brands ? `userAgentData brands: ${snap.brands}` : "Parsed from the user agent. Open the raw string below if you need the exact report."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Platform",
				value: snap.platform,
				source: snap.mobile == null ? "navigator.platform or userAgentData" : `userAgentData mobile: ${snap.mobile ? "yes" : "no"}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Screen",
				value: `${snap.screenLabel} · ${snap.dpr.toFixed(2)}×`,
				source: "window.screen and devicePixelRatio. CSS pixels, not a benchmark."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Logical CPU cores",
				value: snap.cores == null ? void 0 : String(snap.cores),
				unavailable: snap.cores == null,
				source: "navigator.hardwareConcurrency. This is a count, not current CPU load."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "CPU utilization",
				unavailable: true,
				source: "No browser API exposes live CPU load."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "GPU utilization",
				unavailable: true,
				source: "No browser API exposes live GPU load."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "GPU name",
				value: snap.webgl.ok ? snap.webgl.renderer ?? "WebGL available" : void 0,
				unavailable: !snap.webgl.ok,
				source: snap.webgl.ok ? `WebGL renderer${snap.webgl.vendor ? ` · ${snap.webgl.vendor}` : ""}. This is a name, not activity.` : "WebGL context was not available."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Exact RAM",
				unavailable: true,
				source: "Browsers do not report exact installed memory."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Memory class",
				value: memory,
				unavailable: memory == null,
				source: "navigator.deviceMemory. Chrome-only and coarse, often capped at 8 GB."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Temperature",
				unavailable: true,
				source: "No browser API exposes device temperature."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Battery",
				value: snap.battery ? `${Math.round(snap.battery.level * 100)}% · ${snap.battery.charging ? "charging" : "not charging"}` : void 0,
				unavailable: !snap.battery,
				source: snap.batterySupported ? "Battery Status API. Some browsers hide it." : "Battery Status API is not in this browser."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Network hint",
				value: snap.net ? [
					snap.net.effectiveType,
					snap.net.saveData ? "data saver on" : "data saver off",
					snap.net.downlink != null ? `${snap.net.downlink} Mb/s hint` : null
				].filter(Boolean).join(" · ") : void 0,
				unavailable: !snap.net,
				source: "Network Information API, when the browser provides it. Not a speed test."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Origin storage",
				value: storage,
				unavailable: !storage,
				source: "StorageManager estimate for this site, not a full phone storage report."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Saved data in this app",
				value: snap.localStorage ? "localStorage can be written" : void 0,
				unavailable: !snap.localStorage,
				source: "A write test against localStorage. Your profiles use that store."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Display mode",
				value: snap.standalone ? "Home screen / standalone" : "Browser tab",
				source: "matchMedia display-mode: standalone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
				label: "Online",
				value: snap.online ? "Yes" : "No",
				source: "navigator.onLine"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-3 text-sm font-semibold text-primary",
			onClick: () => setShowUa((value) => !value),
			children: showUa ? "Hide raw user agent" : "Show raw user agent"
		}),
		showUa ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs break-all text-faint",
			children: snap.ua
		}) : null
	] });
}
function SessionClock({ prominent = false }) {
	const session = useAppStore((state) => state.session);
	const startSession = useAppStore((state) => state.startSession);
	const pauseSession = useAppStore((state) => state.pauseSession);
	const resetSession = useAppStore((state) => state.resetSession);
	const keepAwake = useAppStore((state) => state.keepAwake);
	const wake = useRuntime((state) => state.wake);
	const [now, setNow] = (0, import_react.useState)(null);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setNow(Date.now());
		if (!session.running) return;
		const id = window.setInterval(() => setNow(Date.now()), 200);
		return () => window.clearInterval(id);
	}, [session.running]);
	const elapsed = sessionElapsed(session, now);
	const hasTime = elapsed > 0 || session.running;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-widest text-faint uppercase",
			children: "Session"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: prominent ? "font-display text-5xl font-semibold tabular-nums" : "font-display text-4xl font-semibold tabular-nums",
			children: formatDuration(elapsed)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: [session.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-ok",
				children: "Timing. "
			}) : "Stopped. ", "Same clock on Home and in Tools."]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-wrap gap-2",
			children: [session.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: pauseSession,
				children: "Pause"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: startSession,
				children: "Start"
			}), confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				onClick: () => {
					resetSession();
					setConfirmReset(false);
				},
				children: "Confirm reset"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "quiet",
				onClick: () => setConfirmReset(false),
				children: "Cancel"
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "quiet",
				onClick: () => hasTime ? setConfirmReset(true) : resetSession(),
				disabled: !hasTime && !session.running,
				children: "Reset"
			})]
		}),
		keepAwake ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3",
			children: [
				wake === "on" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "ok",
					children: "Screen wake lock is on while this session runs."
				}) : null,
				wake === "denied" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "warn",
					children: "The browser denied the screen wake lock. The timer still runs."
				}) : null,
				wake === "unsupported" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Not available in this version." }) : null,
				wake === "off" && session.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Wake lock is off until the browser grants it." }) : null
			]
		}) : null
	] });
}
//#endregion
export { SessionClock as n, DevicePanel as t };
