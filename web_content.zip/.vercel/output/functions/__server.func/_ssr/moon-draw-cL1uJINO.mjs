//#region node_modules/.nitro/vite/services/ssr/assets/moon-draw-cL1uJINO.js
/** Northern view: waxing moons are lit on the right. Pass southern=true to mirror. */
function drawMoonDisk(ctx, cx, cy, radius, elongation, southern) {
	const phase = (elongation % 360 + 360) % 360;
	ctx.save();
	ctx.beginPath();
	ctx.arc(cx, cy, radius, 0, Math.PI * 2);
	ctx.fillStyle = "#241c14";
	ctx.fill();
	ctx.clip();
	ctx.translate(cx, cy);
	if (southern) ctx.scale(-1, 1);
	ctx.fillStyle = "#f4ead2";
	ctx.beginPath();
	const waxing = phase <= 180;
	ctx.arc(0, 0, radius, -Math.PI / 2, Math.PI / 2, !waxing);
	const limb = Math.cos(phase * Math.PI / 180) * radius;
	ctx.ellipse(0, 0, Math.max(Math.abs(limb), .4), radius, 0, Math.PI / 2, -Math.PI / 2, waxing ? limb < 0 : limb >= 0);
	ctx.fill();
	ctx.restore();
	ctx.beginPath();
	ctx.arc(cx, cy, radius, 0, Math.PI * 2);
	ctx.strokeStyle = "rgba(239,231,214,0.35)";
	ctx.lineWidth = 1;
	ctx.stroke();
}
//#endregion
export { drawMoonDisk as t };
