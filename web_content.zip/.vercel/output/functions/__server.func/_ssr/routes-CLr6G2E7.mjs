import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as LoaderCircle, t as X } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CLr6G2E7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-md px-4 text-sm font-medium transition-[transform,background-color,color,opacity] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40", {
	variants: { variant: {
		primary: "min-h-11 bg-accent text-ink hover:bg-fg",
		quiet: "min-h-11 border border-line bg-raised text-fg hover:bg-surface",
		ghost: "min-h-11 text-muted hover:text-fg"
	} },
	defaultVariants: { variant: "primary" }
});
function Button({ className, variant, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({ variant }), className),
		...props
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var DURATIONS$1 = /* @__PURE__ */ new Set([
	6,
	8,
	10
]);
var ASPECTS$1 = /* @__PURE__ */ new Set([
	"16:9",
	"9:16",
	"1:1"
]);
var RESOLUTIONS$1 = /* @__PURE__ */ new Set(["480p", "720p"]);
var MODELS = /* @__PURE__ */ new Set(["lite", "studio"]);
function cleanImage(raw) {
	const value = raw.trim();
	if (!value) return "";
	if (value.length > 12e5) throw new Error("La foto es demasiado pesada. Prueba con una más pequeña.");
	if (value.startsWith("https://")) return value;
	if (/^data:image\/(jpeg|png|webp);base64,/i.test(value)) return value;
	throw new Error("La foto debe ser un enlace https o una imagen JPG, PNG o WebP.");
}
function asStart(input) {
	const prompt = typeof input.prompt === "string" ? input.prompt.trim() : "";
	if (prompt.length < 3 || prompt.length > 1e3) throw new Error("La escena debe tener entre 3 y 1000 caracteres.");
	if (!DURATIONS$1.has(input.duration)) throw new Error("Elige 6, 8 o 10 segundos.");
	if (!ASPECTS$1.has(input.aspectRatio)) throw new Error("Elige una relación de aspecto.");
	if (!RESOLUTIONS$1.has(input.resolution)) throw new Error("Elige una resolución.");
	if (!MODELS.has(input.model)) throw new Error("Elige un modelo.");
	return {
		prompt,
		duration: input.duration,
		aspectRatio: input.aspectRatio,
		resolution: input.resolution,
		model: input.model,
		sound: Boolean(input.sound),
		imageUrl: cleanImage(typeof input.imageUrl === "string" ? input.imageUrl : "")
	};
}
var studioStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("de201c99413a36c9bdf85deed5ef18d705c1ac8fde8f538e538525a074db11d8"));
var refineScene = createServerFn({ method: "POST" }).validator((input) => {
	const idea = input.idea.trim();
	if (idea.length < 3 || idea.length > 1e3) throw new Error("Escribe una idea un poco más larga antes de afinarla.");
	return { idea };
}).handler(createSsrRpc("4ee2ed0f937c128e2b6f3e1d5e96aa093828cccdee18070b24433c0bc58ec3e9"));
var startVideo = createServerFn({ method: "POST" }).validator((input) => asStart(input)).handler(createSsrRpc("f0614f37822e8605ff0ce162c1d7cf6610a18a722082e25e1ad47e42c2b0a3e4"));
var pollVideo = createServerFn({ method: "POST" }).validator((input) => {
	const requestId = input.requestId.trim();
	if (!/^[a-zA-Z0-9_-]{8,128}$/.test(requestId)) throw new Error("Solicitud no válida.");
	return { requestId };
}).handler(createSsrRpc("05d73e7963645371137940c4245d56b717a2bab48d2c85fbc33df8f0a000ab41"));
var HISTORY_KEY = "toma.clips";
var JOB_KEY = "toma.job";
var PRESETS = [
	{
		title: "Faro",
		prompt: "Plano general de un faro de piedra sobre un acantilado gallego al anochecer. El haz gira y abre la niebla. Olas lentas abajo. Cámara fija, grano suave de película."
	},
	{
		title: "Mercado",
		prompt: "Plano medio en un mercado de la Ciudad de México al mediodía. Vapor de elotes, una bicicleta cruza de izquierda a derecha y la cámara la sigue un momento. Luz dura, colores naturales."
	},
	{
		title: "Torno",
		prompt: "Primer plano de unas manos en un torno de cerámica. El barro sube y toma forma de cuenco. Luz lateral cálida, fondo de taller desenfocado, movimiento lento."
	},
	{
		title: "Tren",
		prompt: "Un tren nocturno cruza un puente de hierro sobre un río. Las ventanas iluminadas se reflejan en el agua. La cámara avanza en paralelo, ligera niebla."
	}
];
var ASPECTS = [
	"16:9",
	"9:16",
	"1:1"
];
var DURATIONS = [
	6,
	8,
	10
];
var RESOLUTIONS = [{
	id: "480p",
	label: "Ligera"
}, {
	id: "720p",
	label: "Nítida"
}];
function isClip(value) {
	if (!value || typeof value !== "object") return false;
	const clip = value;
	return typeof clip.id === "string" && typeof clip.prompt === "string" && typeof clip.url === "string" && clip.url.startsWith("https://") && (clip.aspect === "16:9" || clip.aspect === "9:16" || clip.aspect === "1:1") && typeof clip.duration === "number" && typeof clip.createdAt === "number";
}
function loadHistory() {
	try {
		const raw = localStorage.getItem(HISTORY_KEY);
		if (!raw) return [];
		const data = JSON.parse(raw);
		if (!Array.isArray(data)) return [];
		return data.filter(isClip).slice(0, 12);
	} catch {
		return [];
	}
}
function loadJob() {
	try {
		const raw = sessionStorage.getItem(JOB_KEY);
		if (!raw) return null;
		const job = JSON.parse(raw);
		if (!job?.requestId || Date.now() - job.startedAt > 48e4) return null;
		return job;
	} catch {
		return null;
	}
}
function formatElapsed(ms) {
	const total = Math.max(0, Math.floor(ms / 1e3));
	return `${Math.floor(total / 60)}:${(total % 60).toString().padStart(2, "0")}`;
}
function frameClass(aspect) {
	if (aspect === "9:16") return "aspect-[9/16] h-[min(68dvh,640px)] w-auto max-w-full";
	if (aspect === "1:1") return "aspect-square w-full max-w-xl";
	return "aspect-video w-full";
}
async function fileToDataUrl(file) {
	if (file.size > 12e6) throw new Error("La foto pesa demasiado.");
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, 1024 / Math.max(bitmap.width, bitmap.height));
	const canvas = document.createElement("canvas");
	canvas.width = Math.max(1, Math.round(bitmap.width * scale));
	canvas.height = Math.max(1, Math.round(bitmap.height * scale));
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("No se pudo leer la foto.");
	ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
	bitmap.close();
	let url = canvas.toDataURL("image/jpeg", .82);
	if (url.length > 9e5) url = canvas.toDataURL("image/jpeg", .6);
	if (url.length > 115e4) throw new Error("La foto sigue siendo demasiado pesada.");
	return url;
}
function Chip({ pressed, children, onClick, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		disabled,
		onClick,
		className: cn("min-h-11 rounded-md px-3 text-sm font-medium tabular-nums transition-[background-color,color] duration-150", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", "disabled:opacity-40", pressed ? "bg-accent text-ink" : "bg-raised text-muted hover:text-fg"),
		children
	});
}
function Studio() {
	const promptId = (0, import_react.useId)();
	const urlId = (0, import_react.useId)();
	const fileRef = (0, import_react.useRef)(null);
	const stageRef = (0, import_react.useRef)(null);
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [aspect, setAspect] = (0, import_react.useState)("16:9");
	const [duration, setDuration] = (0, import_react.useState)(6);
	const [resolution, setResolution] = (0, import_react.useState)("720p");
	const [model, setModel] = (0, import_react.useState)("lite");
	const [sound, setSound] = (0, import_react.useState)(true);
	const [photoOpen, setPhotoOpen] = (0, import_react.useState)(false);
	const [still, setStill] = (0, import_react.useState)({ kind: "none" });
	const [available, setAvailable] = (0, import_react.useState)(null);
	const [refining, setRefining] = (0, import_react.useState)(false);
	const [starting, setStarting] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [job, setJob] = (0, import_react.useState)(null);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [active, setActive] = (0, import_react.useState)(null);
	const [now, setNow] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		setHistory(loadHistory());
		const saved = loadJob();
		if (saved) setJob(saved);
		else sessionStorage.removeItem(JOB_KEY);
		studioStatus().then((status) => setAvailable(status.available)).catch(() => setAvailable(false));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!job) return;
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		setNow(Date.now());
		return () => window.clearInterval(id);
	}, [job]);
	(0, import_react.useEffect)(() => {
		if (!job) return;
		const current = job;
		let cancelled = false;
		let attempts = 0;
		let timer = 0;
		const finish = (url) => {
			const clip = {
				id: current.requestId,
				prompt: current.prompt,
				url,
				aspect: current.aspect,
				duration: current.duration,
				createdAt: Date.now()
			};
			setActive(clip);
			setHistory((prev) => {
				const next = [clip, ...prev.filter((item) => item.id !== clip.id)].slice(0, 12);
				localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
				return next;
			});
			sessionStorage.removeItem(JOB_KEY);
			setJob(null);
			const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			stageRef.current?.scrollIntoView({
				behavior: reduce ? "auto" : "smooth",
				block: "center"
			});
		};
		const fail = (message) => {
			setError(message);
			sessionStorage.removeItem(JOB_KEY);
			setJob(null);
		};
		const loop = async () => {
			if (cancelled) return;
			attempts += 1;
			if (attempts > 80 || Date.now() - current.startedAt > 48e4) {
				fail("La toma tardó demasiado. Prueba de nuevo con 6 segundos.");
				return;
			}
			try {
				const res = await pollVideo({ data: { requestId: current.requestId } });
				if (cancelled) return;
				if (res.ok && res.status === "done") {
					finish(res.url);
					return;
				}
				if (!res.ok) {
					fail(res.error);
					return;
				}
			} catch (err) {
				if (attempts > 6) {
					fail(err instanceof Error ? err.message : "Se perdió el contacto con la toma.");
					return;
				}
			}
			timer = window.setTimeout(() => void loop(), 4e3);
		};
		timer = window.setTimeout(() => void loop(), 2e3);
		return () => {
			cancelled = true;
			window.clearTimeout(timer);
		};
	}, [job]);
	const imageUrl = still.kind === "file" ? still.dataUrl : still.kind === "url" ? still.url.trim() : "";
	const busy = starting || refining || job !== null;
	const frameAspect = job ? job.aspect : active?.aspect ?? aspect;
	const elapsed = job ? formatElapsed((now || Date.now()) - job.startedAt) : "";
	async function onFile(file) {
		if (!file) return;
		setError("");
		try {
			const dataUrl = await fileToDataUrl(file);
			setStill({
				kind: "file",
				name: file.name,
				dataUrl
			});
			setPhotoOpen(true);
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo usar esa foto. Prueba con JPG o PNG.");
		}
	}
	function clearStill() {
		setStill({ kind: "none" });
		if (fileRef.current) fileRef.current.value = "";
	}
	async function refine() {
		if (busy || prompt.trim().length < 3) return;
		setRefining(true);
		setError("");
		try {
			const res = await refineScene({ data: { idea: prompt } });
			if (!res.ok) setError(res.error);
			else setPrompt(res.prompt);
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo afinar la idea.");
		} finally {
			setRefining(false);
		}
	}
	async function generate() {
		if (busy || available === false || prompt.trim().length < 3) return;
		setStarting(true);
		setError("");
		try {
			const res = await startVideo({ data: {
				prompt,
				duration,
				aspectRatio: imageUrl ? aspect : aspect,
				resolution,
				model,
				sound,
				imageUrl
			} });
			if (!res.ok) {
				setError(res.error);
				return;
			}
			const next = {
				requestId: res.requestId,
				prompt: prompt.trim(),
				aspect,
				duration,
				startedAt: Date.now()
			};
			sessionStorage.setItem(JOB_KEY, JSON.stringify(next));
			setActive(null);
			setJob(next);
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo empezar el video.");
		} finally {
			setStarting(false);
		}
	}
	function removeClip(id) {
		setHistory((prev) => {
			const next = prev.filter((item) => item.id !== id);
			localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
			return next;
		});
		setActive((current) => current?.id === id ? null : current);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl px-4 py-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex flex-wrap items-end justify-between gap-3 border-b border-line pb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Generador de videos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-5xl leading-none tracking-tight italic",
					children: "Toma"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted tabular-nums",
					children: [
						duration,
						" s · ",
						aspect,
						" · ",
						resolution
					]
				})]
			}),
			available === false && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "mb-4 rounded-lg border border-line bg-surface px-4 py-3 text-sm text-muted",
				children: "Ahora mismo no se puede generar video en este espacio."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-6 lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "rounded-xl border border-line bg-surface p-4 max-lg:pb-24",
					onSubmit: (event) => {
						event.preventDefault();
						generate();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: promptId,
								className: "text-sm font-medium text-muted",
								children: "Escena"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-faint tabular-nums",
								children: [prompt.length, "/1000"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: promptId,
							value: prompt,
							maxLength: 1e3,
							onChange: (event) => setPrompt(event.target.value),
							onKeyDown: (event) => {
								if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
									event.preventDefault();
									generate();
								}
							},
							placeholder: "Un tren de noche cruza un puente. Las ventanas iluminadas se reflejan en el río.",
							className: "mt-2 min-h-32 w-full resize-y rounded-md border border-line bg-raised px-3 py-3 text-sm text-fg placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex gap-2 overflow-x-auto pb-1",
							children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPrompt(preset.prompt),
								className: "min-h-11 shrink-0 rounded-md bg-raised px-3 text-sm text-muted hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
								children: preset.title
							}, preset.title))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
									disabled: Boolean(imageUrl),
									className: "min-w-0 disabled:opacity-40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
										className: "mb-2 text-sm font-medium text-muted",
										children: "Relación"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-2",
										children: ASPECTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											pressed: aspect === item,
											onClick: () => setAspect(item),
											children: item
										}, item))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "mb-2 text-sm font-medium text-muted",
									children: "Duración"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: DURATIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										pressed: duration === item,
										onClick: () => setDuration(item),
										children: `${item} s`
									}, item))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "mb-2 text-sm font-medium text-muted",
									children: "Nitidez"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: RESOLUTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										pressed: resolution === item.id,
										onClick: () => setResolution(item.id),
										children: item.label
									}, item.id))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "mb-2 text-sm font-medium text-muted",
									children: "Modelo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										pressed: model === "lite",
										onClick: () => setModel("lite"),
										children: "Ágil"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										pressed: model === "studio",
										onClick: () => setModel("studio"),
										children: "Estudio"
									})]
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "mb-2 text-sm font-medium text-muted",
								children: "Sonido"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									pressed: sound,
									onClick: () => setSound(true),
									children: "Con audio"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									pressed: !sound,
									onClick: () => setSound(false),
									children: "En silencio"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs text-faint",
							children: "Ágil gasta menos créditos. Cada video tarda cerca de un minuto."
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "mt-3 text-sm text-danger",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "fixed inset-x-0 bottom-0 z-20 flex gap-2 border-t border-line bg-bg px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] lg:static lg:inset-auto lg:z-auto lg:mt-4 lg:border-0 lg:bg-transparent lg:p-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "quiet",
								className: "shrink-0",
								onClick: () => void refine(),
								disabled: busy || prompt.trim().length < 3,
								children: refining ? "Afinando…" : "Afinar idea"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "flex-1",
								disabled: busy || available === false || prompt.trim().length < 3,
								children: starting || job ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), "Generando…"] }) : "Generar video"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-expanded": photoOpen,
								onClick: () => setPhotoOpen((open) => !open),
								className: "min-h-11 text-sm font-medium text-muted underline-offset-4 hover:text-fg hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
								children: photoOpen ? "Ocultar foto de partida" : "Animar una foto"
							}), photoOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 rounded-lg border border-line bg-bg p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "La foto es el primer fotograma. Describe el movimiento, no la imagen."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 flex flex-wrap items-center gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "inline-flex min-h-11 cursor-pointer items-center rounded-md border border-line bg-raised px-3 text-sm text-fg hover:bg-surface",
												children: ["Elegir foto", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													ref: fileRef,
													type: "file",
													accept: "image/jpeg,image/png,image/webp",
													className: "sr-only",
													onChange: (event) => void onFile(event.target.files?.[0])
												})]
											}),
											still.kind === "file" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "max-w-40 truncate text-sm text-muted",
												children: still.name
											}),
											still.kind !== "none" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: clearStill,
												className: "inline-flex min-h-11 min-w-11 items-center justify-center text-muted hover:text-fg",
												"aria-label": "Quitar foto",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
											})
										]
									}),
									still.kind === "file" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: still.dataUrl,
										alt: "",
										className: "mt-3 h-24 w-24 rounded-md object-cover"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: urlId,
										className: "mt-3 block text-sm text-muted",
										children: "O un enlace https"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: urlId,
										type: "url",
										inputMode: "url",
										placeholder: "https://",
										value: still.kind === "url" ? still.url : "",
										onChange: (event) => setStill({
											kind: "url",
											url: event.target.value
										}),
										className: "mt-2 min-h-11 w-full rounded-md border border-line bg-raised px-3 text-sm text-fg placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
									}),
									imageUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-faint",
										children: "Con foto, el encuadre sale de la imagen."
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "sr-only",
							role: "status",
							"aria-live": "polite",
							children: job ? `Exponiendo ${elapsed}` : refining ? "Afinando la escena" : ""
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					ref: stageRef,
					className: "rounded-lg border border-line bg-surface p-3",
					"aria-label": "Visor",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("relative overflow-hidden rounded-md bg-stage", frameClass(frameAspect)),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute top-3 left-3 size-4 border-t border-l border-fg/30" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute top-3 right-3 size-4 border-t border-r border-fg/30" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute bottom-3 left-3 size-4 border-b border-l border-fg/30" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute right-3 bottom-3 size-4 border-r border-b border-fg/30" }),
								job ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex h-full flex-col items-center justify-center px-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: "Exponiendo"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 font-serif text-4xl text-fg tabular-nums",
											children: elapsed
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute inset-x-0 bottom-0 h-px overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-expose h-full w-1/3 bg-accent" })
										})
									]
								}) : active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
									src: active.url,
									controls: true,
									playsInline: true,
									autoPlay: true,
									className: "h-full w-full bg-stage object-contain"
								}, active.url) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-full items-center justify-center px-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "line-clamp-6 max-w-[32ch] text-center font-serif text-lg text-muted italic",
										children: prompt.trim() || "Aquí se proyecta el video"
									})
								})
							]
						})
					}), active && !job && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-start justify-between gap-3 px-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "line-clamp-3 max-w-prose font-serif text-base text-fg italic",
							children: active.prompt
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: active.url,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex min-h-11 shrink-0 items-center rounded-md border border-line bg-raised px-3 text-sm text-fg hover:bg-bg",
							children: "Abrir archivo"
						})]
					})]
				})]
			}),
			history.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				"aria-label": "Videos recientes",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium text-muted",
						children: "Videos recientes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-faint",
						children: "En este navegador. El enlace puede caducar."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex gap-3 overflow-x-auto pb-2",
					children: history.map((clip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "w-56 shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("flex h-full flex-col rounded-lg border bg-surface p-3", active?.id === clip.id ? "border-fg/30" : "border-line"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setActive(clip);
									setError("");
								},
								className: "flex-1 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "line-clamp-3 text-sm text-fg",
									children: clip.prompt
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-muted tabular-nums",
									children: [
										clip.duration,
										" s · ",
										clip.aspect
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => removeClip(clip.id),
								className: "mt-2 min-h-11 self-start text-xs text-faint hover:text-fg",
								children: "Quitar"
							})]
						})
					}, clip.id))
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
