import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as QrCode, r as Download } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BzeUcA06.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SIZE_MIN = 128;
var SIZE_MAX = 1024;
var SIZE_STEP = 8;
var LEVELS = [
	{
		id: "L",
		name: "منخفض",
		detail: "7%"
	},
	{
		id: "M",
		name: "متوسط",
		detail: "15%"
	},
	{
		id: "Q",
		name: "عالٍ",
		detail: "25%"
	},
	{
		id: "H",
		name: "أعلى",
		detail: "30%"
	}
];
var PRESETS = [
	{
		name: "كلاسيكي",
		fg: "#111111",
		bg: "#ffffff"
	},
	{
		name: "حبر على ورق",
		fg: "#1c1916",
		bg: "#f3efe7"
	},
	{
		name: "معكوس",
		fg: "#ffffff",
		bg: "#1c1916"
	},
	{
		name: "طيني",
		fg: "#8c2f1b",
		bg: "#fff6ee"
	}
];
var qrModule = null;
function loadQr() {
	qrModule ??= import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	return qrModule;
}
function parseHex(input) {
	const match = /^#?([0-9a-fA-F]{6})$/.exec(input.trim());
	return match ? `#${match[1].toLowerCase()}` : null;
}
function channel(value) {
	const s = value / 255;
	return s <= .03928 ? s / 12.92 : ((s + .055) / 1.055) ** 2.4;
}
function contrastRatio(a, b) {
	const lum = (hex) => {
		const n = parseInt(hex.slice(1), 16);
		const r = channel(n >> 16 & 255);
		const g = channel(n >> 8 & 255);
		const bl = channel(n & 255);
		return .2126 * r + .7152 * g + .0722 * bl;
	};
	const hi = Math.max(lum(a), lum(b));
	const lo = Math.min(lum(a), lum(b));
	return (hi + .05) / (lo + .05);
}
function messageFor(err) {
	const raw = err instanceof Error ? err.message : "";
	if (/too big|too large|data is too/i.test(raw)) return "النص أطول من سعة رمز QR بهذا المستوى. قصّره أو اختر مستوى تصحيح أقل.";
	return "تعذّر إنشاء الرمز. جرّب نصاً أقصر.";
}
function ColorField({ label, value, onChange }) {
	const groupId = (0, import_react.useId)();
	const [draft, setDraft] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => {
		setDraft(value.toUpperCase());
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		role: "group",
		"aria-labelledby": groupId,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			id: groupId,
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "color",
				value,
				"aria-label": `${label}، منتقي الألوان`,
				onChange: (event) => onChange(event.target.value.toLowerCase()),
				className: "size-11 shrink-0 cursor-pointer rounded-lg"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "text",
				dir: "ltr",
				inputMode: "text",
				spellCheck: false,
				autoComplete: "off",
				maxLength: 7,
				value: draft,
				"aria-label": `${label}، القيمة السداسية`,
				onChange: (event) => {
					const next = event.target.value;
					setDraft(next);
					const parsed = parseHex(next);
					if (parsed) onChange(parsed);
				},
				onBlur: () => setDraft(value.toUpperCase()),
				className: "h-11 min-w-0 flex-1 rounded-lg border border-line bg-surface px-3 font-mono text-sm text-ink"
			})]
		})]
	});
}
function QrStudio() {
	const textId = (0, import_react.useId)();
	const textHintId = (0, import_react.useId)();
	const sizeId = (0, import_react.useId)();
	const sizeHintId = (0, import_react.useId)();
	const eccHintId = (0, import_react.useId)();
	const seq = (0, import_react.useRef)(0);
	const [text, setText] = (0, import_react.useState)("");
	const [fg, setFg] = (0, import_react.useState)("#111111");
	const [bg, setBg] = (0, import_react.useState)("#ffffff");
	const [size, setSize] = (0, import_react.useState)(320);
	const [ecc, setEcc] = (0, import_react.useState)("M");
	const [dataUrl, setDataUrl] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const trimmed = text.trim();
	const lowContrast = contrastRatio(fg, bg) < 3;
	const showImage = Boolean(dataUrl) && trimmed.length > 0 && !error;
	const canDownload = showImage;
	(0, import_react.useEffect)(() => {
		const value = text.trim();
		if (!value) {
			setError(null);
			setDataUrl(null);
			return;
		}
		const id = ++seq.current;
		let cancelled = false;
		loadQr().then((qr) => {
			if (cancelled || seq.current !== id) return null;
			const offscreen = document.createElement("canvas");
			return qr.toCanvas(offscreen, value, {
				errorCorrectionLevel: ecc,
				margin: 4,
				width: size,
				color: {
					dark: fg,
					light: bg
				}
			}).then(() => offscreen);
		}).then((offscreen) => {
			if (!offscreen || cancelled || seq.current !== id) return;
			setDataUrl(offscreen.toDataURL("image/png"));
			setError(null);
		}).catch((err) => {
			if (cancelled || seq.current !== id) return;
			setDataUrl(null);
			setError(messageFor(err));
		});
		return () => {
			cancelled = true;
		};
	}, [
		text,
		fg,
		bg,
		size,
		ecc
	]);
	function downloadPng() {
		if (!dataUrl || !canDownload) return;
		const link = document.createElement("a");
		link.href = dataUrl;
		link.download = "qr-code.png";
		document.body.appendChild(link);
		link.click();
		link.remove();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: textId,
						className: "text-sm font-medium",
						children: "النص أو الرابط"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: textId,
						dir: "auto",
						rows: 4,
						value: text,
						placeholder: "https://example.com أو أي نص",
						"aria-describedby": textHintId,
						onChange: (event) => setText(event.target.value),
						className: "min-h-28 w-full resize-y rounded-xl border border-line bg-surface px-3 py-3 text-base text-ink placeholder:text-muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: textHintId,
						className: "text-sm text-muted",
						children: "يتحدث الرمز مع كل حرف."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-labelledby": "preview-heading",
				className: "flex flex-col gap-4 rounded-2xl border border-line bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "preview-heading",
						className: "text-sm font-medium",
						children: "المعاينة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `flex flex-col items-center justify-center overflow-hidden rounded-xl bg-bg p-4 ${showImage ? "" : "min-h-48"}`,
						children: showImage && dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: dataUrl,
							alt: "معاينة رمز QR",
							width: size,
							height: size,
							style: { width: `min(100%, ${size}px)` },
							className: "h-auto max-w-full"
						}) : !trimmed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xs px-4 text-center text-sm text-muted",
							children: "اكتب نصاً أو رابطاً لتظهر المعاينة هنا فوراً."
						}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "max-w-xs px-4 text-center text-sm text-accent",
							children: error
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "جارٍ إنشاء الرمز…"
						})
					}),
					trimmed && !error && lowContrast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-accent",
						role: "status",
						children: "التباين منخفض وقد يتعذّر مسح الرمز. غمّق أحد اللونين أو افتح الآخر."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: downloadPng,
						disabled: !canDownload,
						className: "inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-accent text-base font-semibold text-on-accent transition-colors duration-150 hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-5",
							"aria-hidden": "true"
						}), "تنزيل PNG"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "يُحفظ الملف بالمقاس المختار، مع هامش هادئ حول الرمز."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
							label: "لون الرمز",
							value: fg,
							onChange: setFg
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
							label: "لون الخلفية",
							value: bg,
							onChange: setBg
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium",
							id: "preset-label",
							children: "ألوان جاهزة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							role: "group",
							"aria-labelledby": "preset-label",
							children: PRESETS.map((preset) => {
								const active = fg === preset.fg && bg === preset.bg;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": active,
									"aria-label": preset.name,
									onClick: () => {
										setFg(preset.fg);
										setBg(preset.bg);
									},
									className: `size-11 rounded-xl border border-line bg-surface p-1 ${active ? "ring-2 ring-ink ring-offset-2 ring-offset-bg" : ""}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block size-full rounded-lg",
										style: {
											background: preset.bg,
											boxShadow: `inset 0 0 0 7px ${preset.fg}`
										}
									})
								}, preset.name);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: sizeId,
									className: "text-sm font-medium",
									children: "الحجم"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									dir: "ltr",
									className: "font-mono text-sm text-muted",
									children: [size, "px"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: sizeId,
								className: "qr-range",
								type: "range",
								min: SIZE_MIN,
								max: SIZE_MAX,
								step: SIZE_STEP,
								value: size,
								"aria-valuemin": SIZE_MIN,
								"aria-valuemax": SIZE_MAX,
								"aria-valuenow": size,
								"aria-valuetext": `${size} بكسل`,
								"aria-describedby": sizeHintId,
								onChange: (event) => setSize(Number(event.target.value))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								id: sizeHintId,
								className: "text-sm text-muted",
								children: [
									"مقاس ملف التنزيل من ",
									SIZE_MIN,
									" إلى ",
									SIZE_MAX,
									" بكسل. المعاينة تتقلص لتناسب الشاشة."
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "flex flex-col gap-2",
						"aria-describedby": eccHintId,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium",
								children: "مستوى تصحيح الأخطاء"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
								children: LEVELS.map((level) => {
									const selected = ecc === level.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: `flex min-h-11 cursor-pointer flex-col items-center justify-center rounded-xl border px-2 py-2 text-center has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-accent has-[:focus-visible]:ring-offset-2 has-[:focus-visible]:ring-offset-bg ${selected ? "border-ink bg-ink text-surface" : "border-line bg-surface text-ink"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												className: "sr-only",
												type: "radio",
												name: "error-correction",
												value: level.id,
												checked: selected,
												onChange: () => setEcc(level.id)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-semibold",
												children: level.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												dir: "ltr",
												className: `font-mono text-xs ${selected ? "text-on-accent" : "text-muted"}`,
												children: [
													level.id,
													" · ",
													level.detail
												]
											})
										]
									}, level.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: eccHintId,
								className: "text-sm text-muted",
								children: "مستوى أعلى يقاوم التلف أكثر، والرمز يصبح أكثف."
							})
						]
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-xl flex-col gap-8 px-4 py-8 sm:py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block h-1 w-12 rounded-full bg-accent",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-11 shrink-0 place-items-center rounded-xl bg-ink text-surface",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {
							className: "size-5",
							"aria-hidden": "true"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl font-semibold leading-tight tracking-tight",
						children: "مولّد رمز QR"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-base text-muted",
					children: "معاينة فورية وأنت تكتب، ثم تنزيل PNG. يُنشأ الرمز داخل المتصفح ولا يُرسل النص إلى أي خادم."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrStudio, {})]
	});
}
//#endregion
export { Home as component };
