import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Camera, a as Route, c as LockOpen, d as Eye, f as EyeOff, g as ChevronDown, h as ChevronLeft, i as Trash2, l as Locate, m as ChevronUp, n as Upload, o as Plus, p as Download, s as Lock, t as X, u as Gem, v as ArrowUp, y as ArrowDown } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DHJqqCo2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MINERALS = [
	"Bergkristall",
	"Rauchquarz",
	"Amethyst",
	"Smaragd",
	"Epidot",
	"Granat",
	"Adular",
	"Calcit",
	"Fluorit",
	"Pyrit",
	"Wulfenit",
	"Siderit",
	"Malachit",
	"Azurit",
	"Gold",
	"Scheelit",
	"Magnesit",
	"Kupfer & Silber",
	"Anderes"
];
var PLACES = [
	{
		id: "knappenwand",
		name: "Knappenwand",
		mineral: "Epidot",
		region: "Salzburg · Untersulzbachtal",
		lat: 47.22141,
		lng: 12.27764,
		note: "Berühmte Epidotkluft im Nationalpark Hohe Tauern. Heute Schau- und Forschungsstelle, kein freies Sammeln."
	},
	{
		id: "leckbachrinne",
		name: "Leckbachrinne",
		mineral: "Smaragd",
		region: "Salzburg · Habachtal",
		lat: 47.19711,
		lng: 12.35305,
		note: "Klassische Smaragdlagerstätte am Nasenkopf. Stollen und Nationalpark: nur nach den geltenden Regeln."
	},
	{
		id: "erzberg",
		name: "Steirischer Erzberg",
		mineral: "Siderit",
		region: "Steiermark · Eisenerz",
		lat: 47.52417,
		lng: 14.91222,
		note: "Aktiver Tagbau und Schaubergwerk. Betriebsgelände, kein Sammelplatz."
	},
	{
		id: "leogang",
		name: "Schaubergwerk Leogang",
		mineral: "Kupfer & Silber",
		region: "Salzburg · Schwarzleo",
		lat: 47.42361,
		lng: 12.67253,
		note: "Historischer Bergbau. Besuch über den Barbarastollen, nicht zum freien Schürfen."
	},
	{
		id: "schwaz",
		name: "Silberbergwerk Schwaz",
		mineral: "Kupfer & Silber",
		region: "Tirol · Schwaz",
		lat: 47.35361,
		lng: 11.72645,
		note: "Schaubergwerk an der Alten Landstraße. Orientierung auf das Besucherbergwerk."
	},
	{
		id: "bleiberg",
		name: "Bad Bleiberg",
		mineral: "Wulfenit",
		region: "Kärnten · Villach-Land",
		lat: 46.6246,
		lng: 13.68716,
		note: "Typlokalität des Wulfenits. Koordinate ist die Ortslage, nicht ein einzelner Stollen."
	},
	{
		id: "huettenberg",
		name: "Knappenberg",
		mineral: "Siderit",
		region: "Kärnten · Hüttenberg",
		lat: 46.93535,
		lng: 14.56421,
		note: "Hüttenberger Erzberg mit Schaubergwerk. Orientierung auf den Ort Knappenberg."
	},
	{
		id: "rauris",
		name: "Rauris",
		mineral: "Gold",
		region: "Salzburg · Hohe Tauern",
		lat: 47.22863,
		lng: 12.99412,
		note: "Altes Tauerngold. Koordinate ist der Ort; in der Höhe gilt der Nationalpark."
	},
	{
		id: "annaberg",
		name: "Annaberg",
		mineral: "Wulfenit",
		region: "Niederösterreich · Annaberg",
		lat: 47.87174,
		lng: 15.37561,
		note: "Historisches Revier, in dem Wulfenit früh beschrieben wurde. Koordinate: Ortslage."
	}
];
var MONTHS = [
	"Jän",
	"Feb",
	"Mär",
	"Apr",
	"Mai",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Okt",
	"Nov",
	"Dez"
];
function placeStopId(id) {
	return `place:${id}`;
}
function todayIso() {
	const d = /* @__PURE__ */ new Date();
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${m}-${day}`;
}
function formatDate(iso) {
	if (!iso) return "ohne Datum";
	const [year, month, day] = iso.split("-");
	const index = Number(month) - 1;
	if (!year || !day || index < 0 || index > 11) return iso;
	return `${Number(day)}. ${MONTHS[index]} ${year}`;
}
function formatCoords(lat, lng) {
	const ns = lat >= 0 ? "N" : "S";
	const ew = lng >= 0 ? "E" : "W";
	return `${Math.abs(lat).toFixed(5)}° ${ns}, ${Math.abs(lng).toFixed(5)}° ${ew}`;
}
function formatKm(km) {
	if (!Number.isFinite(km) || km <= 0) return "0 m";
	if (km < 1) return `${Math.round(km * 1e3)} m`;
	return `${km.toFixed(km < 10 ? 1 : 0)} km`;
}
function inAustria(lat, lng) {
	return lat >= 46.3 && lat <= 49.1 && lng >= 9.4 && lng <= 17.3;
}
function validCoord(lat, lng) {
	return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
}
function haversineKm(a, b) {
	const r = 6371;
	const dLat = (b.lat - a.lat) * Math.PI / 180;
	const dLng = (b.lng - a.lng) * Math.PI / 180;
	const s = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
	return 2 * r * Math.asin(Math.min(1, Math.sqrt(s)));
}
function resolveStop(id, finds) {
	if (id.startsWith("place:")) {
		const place = PLACES.find((item) => item.id === id.slice(6));
		if (!place) return null;
		return {
			id,
			name: place.name,
			mineral: place.mineral,
			lat: place.lat,
			lng: place.lng,
			kind: "place"
		};
	}
	const find = finds.find((item) => item.id === id);
	if (!find) return null;
	return {
		id,
		name: find.name,
		mineral: find.mineral,
		lat: find.lat,
		lng: find.lng,
		kind: "find"
	};
}
function tourLengthKm(tour, finds) {
	const points = tour.stopIds.map((id) => resolveStop(id, finds)).filter((point) => point !== null);
	let sum = 0;
	for (let i = 1; i < points.length; i += 1) {
		const prev = points[i - 1];
		const next = points[i];
		if (prev && next) sum += haversineKm(prev, next);
	}
	return sum;
}
function parseCoord(value) {
	const number = Number(value.trim().replace(",", "."));
	return Number.isFinite(number) ? number : null;
}
var TILES = {
	topo: {
		url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
		attribution: "Kartendaten © OpenStreetMap, SRTM · Darstellung © OpenTopoMap (CC-BY-SA)",
		maxZoom: 17,
		subdomains: "abc"
	},
	karte: {
		url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
		attribution: "© OpenStreetMap © CARTO",
		maxZoom: 19,
		subdomains: "abcd"
	},
	satellit: {
		url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
		attribution: "Bilder © Esri, Maxar, Earthstar Geographics",
		maxZoom: 18
	}
};
function crystal(kind, selected, number) {
	const badge = number ? `<span class="pin-n">${number}</span>` : "";
	return `<div class="pin pin-${kind}${selected ? " is-on" : ""}">${badge}<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 2.2 27.2 13.2 16 30 4.8 13.2Z" fill="${kind === "place" ? "none" : "currentColor"}" stroke="${kind === "place" ? "currentColor" : "var(--color-primary-fg)"}" stroke-width="${kind === "place" ? "1.8" : "1.2"}" stroke-linejoin="round"/></svg></div>`;
}
function FieldMap({ basemap, finds, tours, showPlaces, selectedKey, activeTourId, draftPin, userLoc, focus, placing, onMapClick, onSelect }) {
	const hostRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const tileRef = (0, import_react.useRef)(null);
	const groupRef = (0, import_react.useRef)(null);
	const leafletRef = (0, import_react.useRef)(null);
	const clickRef = (0, import_react.useRef)(onMapClick);
	const selectRef = (0, import_react.useRef)(onSelect);
	const draftRef = (0, import_react.useRef)(draftPin);
	const [mapReady, setMapReady] = (0, import_react.useState)(false);
	clickRef.current = onMapClick;
	selectRef.current = onSelect;
	draftRef.current = draftPin;
	(0, import_react.useEffect)(() => {
		const host = hostRef.current;
		if (!host) return;
		let alive = true;
		let map = null;
		(async () => {
			const L = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			await Promise.resolve({});
			if (!alive || !hostRef.current) return;
			leafletRef.current = L;
			map = L.map(hostRef.current, {
				zoomControl: false,
				minZoom: 6,
				maxZoom: 18,
				maxBounds: L.latLngBounds([45.7, 8.3], [49.7, 18.1]),
				maxBoundsViscosity: .7
			}).setView([47.45, 13.35], 7);
			L.control.zoom({ position: "topright" }).addTo(map);
			groupRef.current = L.layerGroup().addTo(map);
			map.on("click", (event) => {
				clickRef.current(event.latlng.lat, event.latlng.lng);
			});
			mapRef.current = map;
			map.invalidateSize();
			setMapReady(true);
		})();
		const observer = new ResizeObserver(() => {
			const current = mapRef.current;
			current?.invalidateSize();
			const pin = draftRef.current;
			if (pin && current && !current.getBounds().contains([pin.lat, pin.lng])) current.panTo([pin.lat, pin.lng]);
		});
		observer.observe(host);
		return () => {
			alive = false;
			observer.disconnect();
			map?.remove();
			mapRef.current = null;
			tileRef.current = null;
			groupRef.current = null;
			setMapReady(false);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		const L = leafletRef.current;
		if (!map || !L || !mapReady) return;
		tileRef.current?.remove();
		const spec = TILES[basemap];
		const layer = L.tileLayer(spec.url, {
			attribution: spec.attribution,
			maxZoom: spec.maxZoom,
			...spec.subdomains ? { subdomains: spec.subdomains } : {}
		});
		layer.addTo(map);
		layer.bringToBack();
		tileRef.current = layer;
	}, [basemap, mapReady]);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		const group = groupRef.current;
		const L = leafletRef.current;
		if (!map || !group || !L || !mapReady) return;
		group.clearLayers();
		const copper = getComputedStyle(document.documentElement).getPropertyValue("--color-primary").trim() || "rgb(208, 137, 58)";
		const active = tours.find((tour) => tour.id === activeTourId);
		const numbers = /* @__PURE__ */ new Map();
		if (active?.visible) active.stopIds.forEach((id, index) => {
			if (!numbers.has(id)) numbers.set(id, index + 1);
		});
		for (const tour of tours) {
			if (!tour.visible) continue;
			const points = tour.stopIds.map((id) => resolveStop(id, finds)).filter((point) => point !== null);
			if (points.length < 2) continue;
			const line = L.polyline(points.map((point) => [point.lat, point.lng]), {
				color: copper,
				weight: tour.fixed ? 4 : 3,
				opacity: tour.id === activeTourId ? .95 : .42,
				dashArray: tour.fixed ? void 0 : "8 8",
				interactive: false
			});
			group.addLayer(line);
		}
		if (showPlaces) for (const place of PLACES) {
			const key = placeStopId(place.id);
			const marker = L.marker([place.lat, place.lng], {
				icon: L.divIcon({
					className: "ader-pin",
					html: crystal("place", selectedKey === key, numbers.get(key)),
					iconSize: [28, 28],
					iconAnchor: [14, 28]
				}),
				keyboard: false,
				zIndexOffset: selectedKey === key ? 800 : 100,
				title: place.name
			});
			marker.on("click", () => {
				selectRef.current(key);
			});
			group.addLayer(marker);
		}
		for (const find of finds) {
			const key = find.id;
			const marker = L.marker([find.lat, find.lng], {
				icon: L.divIcon({
					className: "ader-pin",
					html: crystal("find", selectedKey === key, numbers.get(key)),
					iconSize: [28, 28],
					iconAnchor: [14, 28]
				}),
				keyboard: false,
				zIndexOffset: selectedKey === key ? 900 : 400,
				title: find.name
			});
			marker.on("click", (event) => {
				event.originalEvent?.stopPropagation();
				selectRef.current(key);
			});
			group.addLayer(marker);
		}
		if (draftPin) {
			const marker = L.marker([draftPin.lat, draftPin.lng], {
				icon: L.divIcon({
					className: "ader-pin",
					html: crystal("draft", true),
					iconSize: [28, 28],
					iconAnchor: [14, 28]
				}),
				keyboard: false,
				zIndexOffset: 1e3,
				interactive: false
			});
			group.addLayer(marker);
			if (!map.getBounds().pad(-.2).contains([draftPin.lat, draftPin.lng])) map.panTo([draftPin.lat, draftPin.lng]);
		}
		if (userLoc) {
			const marker = L.marker([userLoc.lat, userLoc.lng], {
				icon: L.divIcon({
					className: "ader-pin",
					html: `<div class="me-dot"></div>`,
					iconSize: [14, 14],
					iconAnchor: [7, 7]
				}),
				keyboard: false,
				zIndexOffset: 1100,
				interactive: false,
				title: "Dein Standort"
			});
			group.addLayer(marker);
		}
	}, [
		finds,
		tours,
		showPlaces,
		selectedKey,
		activeTourId,
		draftPin,
		userLoc,
		mapReady
	]);
	(0, import_react.useEffect)(() => {
		if (!focus || !mapRef.current || !mapReady) return;
		mapRef.current.flyTo([focus.lat, focus.lng], focus.zoom, { duration: .65 });
	}, [focus, mapReady]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: placing ? "ader-map placing absolute inset-0 z-0" : "ader-map absolute inset-0 z-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: hostRef,
			className: "h-full w-full",
			role: "application",
			"aria-label": "Karte von Österreich"
		})
	});
}
var MAX_PHOTOS = 6;
var urls = {};
var loadOnce = null;
var dbPromise = null;
function openDb() {
	if (typeof indexedDB === "undefined") return Promise.reject(/* @__PURE__ */ new Error("Kein lokaler Speicher"));
	if (!dbPromise) dbPromise = new Promise((resolve, reject) => {
		const request = indexedDB.open("ader", 1);
		request.onupgradeneeded = () => {
			const db = request.result;
			for (const name of [
				"finds",
				"tours",
				"photos"
			]) if (!db.objectStoreNames.contains(name)) db.createObjectStore(name, { keyPath: "id" });
		};
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => {
			dbPromise = null;
			reject(request.error ?? /* @__PURE__ */ new Error("Speicher öffnen fehlgeschlagen"));
		};
	});
	return dbPromise;
}
function requestToPromise(request) {
	return new Promise((resolve, reject) => {
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error);
	});
}
function transactionDone(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
		tx.onabort = () => reject(tx.error ?? /* @__PURE__ */ new Error("abgebrochen"));
	});
}
async function putRow(store, value) {
	const tx = (await openDb()).transaction(store, "readwrite");
	const done = transactionDone(tx);
	tx.objectStore(store).put(value);
	await done;
}
async function deleteRow(store, id) {
	const tx = (await openDb()).transaction(store, "readwrite");
	const done = transactionDone(tx);
	tx.objectStore(store).delete(id);
	await done;
}
async function getAll(store) {
	const tx = (await openDb()).transaction(store, "readonly");
	const done = transactionDone(tx);
	const rows = await requestToPromise(tx.objectStore(store).getAll());
	await done;
	return rows;
}
function rememberPhoto(id, blob) {
	if (urls[id]) URL.revokeObjectURL(urls[id]);
	urls[id] = URL.createObjectURL(blob);
}
function forgetPhoto(id) {
	if (!urls[id]) return;
	URL.revokeObjectURL(urls[id]);
	delete urls[id];
}
async function compressImage(file) {
	if (file.size > 15728640) throw new Error("Bild ist größer als 15 MB.");
	const bitmap = await createImageBitmap(file);
	try {
		const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
		const width = Math.max(1, Math.round(bitmap.width * scale));
		const height = Math.max(1, Math.round(bitmap.height * scale));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Bild konnte nicht verarbeitet werden.");
		ctx.drawImage(bitmap, 0, 0, width, height);
		const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", .78));
		if (!blob) throw new Error("Bild konnte nicht gespeichert werden.");
		return blob;
	} finally {
		bitmap.close();
	}
}
function blobToDataUrl(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(blob);
	});
}
function cleanTours(tours, finds) {
	const known = /* @__PURE__ */ new Set([...finds.map((find) => find.id), ...PLACES.map((place) => placeStopId(place.id))]);
	return tours.map((tour) => ({
		...tour,
		stopIds: tour.stopIds.filter((id) => known.has(id))
	}));
}
function isFind(value) {
	if (!value || typeof value !== "object") return false;
	const row = value;
	return typeof row.id === "string" && typeof row.name === "string" && typeof row.mineral === "string" && typeof row.lat === "number" && typeof row.lng === "number" && Array.isArray(row.photoIds);
}
function isTour(value) {
	if (!value || typeof value !== "object") return false;
	const row = value;
	return typeof row.id === "string" && typeof row.name === "string" && Array.isArray(row.stopIds);
}
var useField = create((set, get) => ({
	ready: false,
	loadError: null,
	finds: [],
	tours: [],
	photoUrls: {},
	load: () => {
		if (!loadOnce) loadOnce = (async () => {
			try {
				const [finds, rawTours, photos] = await Promise.all([
					getAll("finds"),
					getAll("tours"),
					getAll("photos")
				]);
				for (const photo of photos) if (photo?.id && photo.blob) rememberPhoto(photo.id, photo.blob);
				const tours = cleanTours(rawTours, finds);
				finds.sort((a, b) => b.createdAt - a.createdAt);
				tours.sort((a, b) => b.createdAt - a.createdAt);
				set({
					ready: true,
					finds,
					tours,
					photoUrls: { ...urls },
					loadError: null
				});
			} catch {
				set({
					ready: true,
					loadError: "Lokaler Speicher ist nicht erreichbar. Einträge gelten nur für diesen Besuch."
				});
			}
		})();
		return loadOnce;
	},
	saveFind: async (input) => {
		const name = input.name.trim();
		if (!name) throw new Error("Name fehlt.");
		const mineral = input.mineral.trim() || "Anderes";
		if (input.keepPhotoIds.length + input.files.length > MAX_PHOTOS) throw new Error("Höchstens 6 Fotos pro Fund.");
		const id = input.id ?? crypto.randomUUID();
		const previous = get().finds.find((find) => find.id === id);
		const removed = (previous?.photoIds ?? []).filter((photoId) => !input.keepPhotoIds.includes(photoId));
		const photoIds = [...input.keepPhotoIds];
		for (const file of input.files) {
			if (!file.type.startsWith("image/")) throw new Error("Bitte JPEG, PNG oder WebP.");
			const blob = await compressImage(file);
			const photoId = crypto.randomUUID();
			await putRow("photos", {
				id: photoId,
				blob
			});
			rememberPhoto(photoId, blob);
			photoIds.push(photoId);
		}
		for (const photoId of removed) {
			await deleteRow("photos", photoId);
			forgetPhoto(photoId);
		}
		const find = {
			id,
			name,
			mineral,
			notes: input.notes.trim(),
			date: input.date,
			lat: input.lat,
			lng: input.lng,
			photoIds,
			createdAt: previous?.createdAt ?? Date.now()
		};
		await putRow("finds", find);
		set({
			finds: [find, ...get().finds.filter((item) => item.id !== id)].sort((a, b) => b.createdAt - a.createdAt),
			photoUrls: { ...urls },
			loadError: null
		});
		return id;
	},
	deleteFind: async (id) => {
		const find = get().finds.find((item) => item.id === id);
		if (!find) return;
		for (const photoId of find.photoIds) {
			await deleteRow("photos", photoId);
			forgetPhoto(photoId);
		}
		await deleteRow("finds", id);
		const tours = get().tours.map((tour) => tour.stopIds.includes(id) ? {
			...tour,
			stopIds: tour.stopIds.filter((stop) => stop !== id)
		} : tour);
		for (const tour of tours) if (tour.stopIds.length !== get().tours.find((item) => item.id === tour.id)?.stopIds.length) await putRow("tours", tour);
		set({
			finds: get().finds.filter((item) => item.id !== id),
			tours,
			photoUrls: { ...urls }
		});
	},
	createTour: async () => {
		const tour = {
			id: crypto.randomUUID(),
			name: "Neue Tour",
			notes: "",
			date: todayIso(),
			stopIds: [],
			fixed: false,
			visible: true,
			createdAt: Date.now()
		};
		await putRow("tours", tour);
		set({ tours: [tour, ...get().tours] });
		return tour.id;
	},
	patchTour: async (id, patch) => {
		const current = get().tours.find((tour) => tour.id === id);
		if (!current) return;
		const next = {
			...current,
			...patch
		};
		await putRow("tours", next);
		set({ tours: get().tours.map((tour) => tour.id === id ? next : tour) });
	},
	deleteTour: async (id) => {
		await deleteRow("tours", id);
		set({ tours: get().tours.filter((tour) => tour.id !== id) });
	},
	addStop: async (tourId, stopId) => {
		const tour = get().tours.find((item) => item.id === tourId);
		if (!tour || tour.fixed || tour.stopIds.includes(stopId)) return false;
		const next = {
			...tour,
			stopIds: [...tour.stopIds, stopId]
		};
		await putRow("tours", next);
		set({ tours: get().tours.map((item) => item.id === tourId ? next : item) });
		return true;
	},
	removeStop: async (tourId, index) => {
		const tour = get().tours.find((item) => item.id === tourId);
		if (!tour || tour.fixed) return;
		const next = {
			...tour,
			stopIds: tour.stopIds.filter((_, i) => i !== index)
		};
		await putRow("tours", next);
		set({ tours: get().tours.map((item) => item.id === tourId ? next : item) });
	},
	moveStop: async (tourId, index, dir) => {
		const tour = get().tours.find((item) => item.id === tourId);
		if (!tour || tour.fixed) return;
		const target = index + dir;
		if (target < 0 || target >= tour.stopIds.length) return;
		const stopIds = [...tour.stopIds];
		const current = stopIds[index];
		const swap = stopIds[target];
		if (current === void 0 || swap === void 0) return;
		stopIds[index] = swap;
		stopIds[target] = current;
		const next = {
			...tour,
			stopIds
		};
		await putRow("tours", next);
		set({ tours: get().tours.map((item) => item.id === tourId ? next : item) });
	},
	exportBackup: async () => {
		const photos = await getAll("photos");
		const encoded = await Promise.all(photos.map(async (photo) => ({
			id: photo.id,
			dataUrl: await blobToDataUrl(photo.blob)
		})));
		const payload = {
			app: "ader",
			version: 1,
			finds: get().finds,
			tours: get().tours,
			photos: encoded
		};
		const blob = new Blob([JSON.stringify(payload)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `ader-sicherung-${todayIso()}.json`;
		link.click();
		URL.revokeObjectURL(url);
	},
	importBackup: async (file) => {
		if (file.size > 41943040) throw new Error("Sicherung ist größer als 40 MB.");
		const text = await file.text();
		const data = JSON.parse(text);
		if (!data || !Array.isArray(data.finds)) throw new Error("Das ist keine Ader-Sicherung.");
		const existingFinds = new Set(get().finds.map((find) => find.id));
		const existingTours = new Set(get().tours.map((tour) => tour.id));
		let added = 0;
		for (const photo of data.photos ?? []) {
			if (!photo?.id || !photo.dataUrl || urls[photo.id]) continue;
			const blob = await (await fetch(photo.dataUrl)).blob();
			await putRow("photos", {
				id: photo.id,
				blob
			});
			rememberPhoto(photo.id, blob);
		}
		const finds = [...get().finds];
		for (const row of data.finds) {
			if (!isFind(row) || existingFinds.has(row.id)) continue;
			const find = {
				id: row.id,
				name: row.name,
				mineral: row.mineral || "Anderes",
				notes: row.notes ?? "",
				date: row.date ?? "",
				lat: row.lat,
				lng: row.lng,
				photoIds: row.photoIds.filter((id) => typeof id === "string"),
				createdAt: row.createdAt || Date.now()
			};
			await putRow("finds", find);
			finds.push(find);
			added += 1;
		}
		const tours = [...get().tours];
		for (const row of data.tours ?? []) {
			if (!isTour(row) || existingTours.has(row.id)) continue;
			const tour = {
				id: row.id,
				name: row.name,
				notes: row.notes ?? "",
				date: row.date ?? "",
				stopIds: row.stopIds.filter((id) => typeof id === "string"),
				fixed: Boolean(row.fixed),
				visible: row.visible !== false,
				createdAt: row.createdAt || Date.now()
			};
			await putRow("tours", tour);
			tours.push(tour);
		}
		finds.sort((a, b) => b.createdAt - a.createdAt);
		tours.sort((a, b) => b.createdAt - a.createdAt);
		set({
			finds,
			tours: cleanTours(tours, finds),
			photoUrls: { ...urls }
		});
		return added;
	}
}));
var fieldCls = "w-full rounded-md border border-border bg-bg px-3 text-sm text-fg placeholder:text-muted";
var btnPrimary = "inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-medium text-primary-fg hover:opacity-90 disabled:opacity-50";
var btnQuiet = "inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-surface-2 px-4 text-sm font-medium text-fg hover:bg-bg disabled:opacity-50";
function matches(query, parts) {
	const needle = query.trim().toLowerCase();
	if (!needle) return true;
	return parts.join(" ").toLowerCase().includes(needle);
}
function FieldPanel(props) {
	const finds = useField((state) => state.finds);
	const tours = useField((state) => state.tours);
	const ready = useField((state) => state.ready);
	const photoUrls = useField((state) => state.photoUrls);
	const loadError = useField((state) => state.loadError);
	const filteredFinds = finds.filter((find) => matches(props.query, [
		find.name,
		find.mineral,
		find.notes,
		find.date
	]));
	const filteredPlaces = PLACES.filter((place) => matches(props.query, [
		place.name,
		place.mineral,
		place.region,
		place.note
	]));
	const filteredTours = tours.filter((tour) => matches(props.query, [tour.name, tour.notes]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: clsx("flex w-full min-h-0 shrink-0 flex-col border-t border-border bg-surface xl:h-full xl:w-80 xl:flex-none xl:border-t-0 xl:border-l", props.sheetOpen ? "max-xl:flex-1" : "h-14"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-14 shrink-0 items-center gap-1 border-b border-border px-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
					active: props.tab === "funde",
					onClick: () => props.setTab("funde"),
					label: "Funde",
					count: finds.length
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
					active: props.tab === "touren",
					onClick: () => props.setTab("touren"),
					label: "Touren",
					count: tours.length
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
					active: props.tab === "orte",
					onClick: () => props.setTab("orte"),
					label: "Orte",
					count: PLACES.length
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ml-auto grid size-11 place-items-center rounded-md text-muted xl:hidden",
					"aria-label": props.sheetOpen ? "Liste einklappen" : "Liste öffnen",
					onClick: () => props.setSheetOpen(!props.sheetOpen),
					children: props.sheetOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-5" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: clsx("flex min-h-0 flex-1 flex-col", props.sheetOpen ? "" : "hidden xl:flex"),
			children: [!props.editor && !props.detailKey && props.activeTourId === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 px-3 pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "sr-only",
					htmlFor: "ader-search",
					children: "Suchen"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "ader-search",
					value: props.query,
					onChange: (event) => props.setQuery(event.target.value),
					placeholder: props.tab === "touren" ? "Tour suchen" : "Name oder Mineral",
					className: clsx(fieldCls, "h-11")
				})]
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-3 py-3",
				children: [
					loadError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: loadError
					}) : null,
					!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Lade deine Funde…"
					}) : null,
					ready && props.editor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FindForm, {
						editor: props.editor,
						pin: props.pin,
						setPin: props.setPin,
						userLoc: props.userLoc,
						finds,
						photoUrls,
						onCancel: props.onCloseEditor,
						onSaved: props.onSaved,
						onBanner: props.onBanner
					}, `${props.editor.id ?? "neu"}-${props.editor.seed?.name ?? ""}`) : null,
					ready && !props.editor && props.detailKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
						detailKey: props.detailKey,
						finds,
						photoUrls,
						onBack: props.onCloseDetail,
						onEdit: (id) => props.onOpenEditor({ id }),
						onAdopt: (placeId) => {
							const place = PLACES.find((item) => item.id === placeId);
							if (!place) return;
							props.setPin({
								lat: place.lat,
								lng: place.lng
							});
							props.onOpenEditor({
								id: null,
								seed: {
									name: place.name,
									mineral: place.mineral,
									notes: place.note
								}
							});
						},
						onBanner: props.onBanner
					}) : null,
					ready && !props.editor && !props.detailKey && props.tab === "funde" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FindList, {
						finds: filteredFinds,
						total: finds.length,
						photoUrls,
						onOpen: props.onOpenDetail,
						onCreate: () => props.onOpenEditor({ id: null }),
						onBanner: props.onBanner
					}) : null,
					ready && !props.editor && !props.detailKey && props.tab === "touren" && props.activeTourId === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TourList, {
						tours: filteredTours,
						finds,
						onOpen: props.onOpenTour,
						onCreate: async () => {
							const id = await useField.getState().createTour();
							props.onOpenTour(id);
							props.setRecording(true);
						}
					}) : null,
					ready && !props.editor && !props.detailKey && props.activeTourId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TourEditor, {
						tourId: props.activeTourId,
						finds,
						recording: props.recording,
						setRecording: props.setRecording,
						onBack: props.onCloseTour,
						onBanner: props.onBanner
					}) : null,
					ready && !props.editor && !props.detailKey && props.tab === "orte" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceList, {
						places: filteredPlaces,
						showPlaces: props.showPlaces,
						setShowPlaces: props.setShowPlaces,
						onOpen: (id) => props.onOpenDetail(placeStopId(id))
					}) : null
				]
			})]
		})]
	});
}
function TabButton({ active, label, count, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: clsx("relative h-11 rounded-md px-2.5 text-sm font-medium", active ? "text-fg" : "text-muted"),
		children: [
			label,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-1 text-xs text-muted",
				children: count
			}),
			active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-x-2 bottom-1 h-0.5 rounded-full bg-primary" }) : null
		]
	});
}
function FindList({ finds, total, photoUrls, onOpen, onCreate, onBanner }) {
	const fileRef = (0, import_react.useRef)(null);
	const exportBackup = useField((state) => state.exportBackup);
	const importBackup = useField((state) => state.importBackup);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: btnPrimary,
				onClick: onCreate,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Fund eintragen"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Tipp auf die Karte setzt den Punkt. Fotos und Notizen bleiben auf diesem Gerät."
			}),
			total === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl leading-snug text-fg",
				children: "Noch keine eigenen Funde."
			}) : finds.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nichts passt zur Suche."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: finds.map((find) => {
					const photo = find.photoIds.map((id) => photoUrls[id]).find(Boolean);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpen(find.id),
						className: "flex w-full items-center gap-3 rounded-md border border-border bg-bg p-2 text-left hover:border-primary",
						children: [photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: photo,
							alt: "",
							className: "size-14 rounded-md object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-14 place-items-center rounded-md bg-surface-2 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rotate-45 bg-primary" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-medium text-fg",
								children: find.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block truncate text-sm text-muted",
								children: [
									find.mineral,
									" · ",
									formatDate(find.date)
								]
							})]
						})]
					}) }, find.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: btnQuiet,
						onClick: () => {
							exportBackup().catch(() => onBanner("Sicherung konnte nicht gespeichert werden."));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Sichern"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: btnQuiet,
						onClick: () => fileRef.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), "Laden"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "application/json",
						className: "sr-only",
						onChange: (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							if (!file) return;
							importBackup(file).then((count) => onBanner(count ? `${count} Funde übernommen.` : "Nichts Neues in der Sicherung.")).catch(() => onBanner("Diese Datei ist keine Ader-Sicherung."));
						}
					})
				]
			})
		]
	});
}
function PlaceList({ places, showPlaces, setShowPlaces, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Bekannte Reviere zur Orientierung. Nationalpark, Privatgrund und Bergbau sind oft gesperrt — das ist kein Sammelrecht."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: btnQuiet,
				"aria-pressed": showPlaces,
				onClick: () => setShowPlaces(!showPlaces),
				children: [showPlaces ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }), showPlaces ? "Orte auf der Karte" : "Orte ausgeblendet"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: places.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen(place.id),
					className: "w-full rounded-md border border-border bg-bg px-3 py-3 text-left hover:border-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-medium text-fg",
						children: place.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-sm text-muted",
						children: [
							place.mineral,
							" · ",
							place.region
						]
					})]
				}) }, place.id))
			})
		]
	});
}
function TourList({ tours, finds, onOpen, onCreate }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: btnPrimary,
				disabled: busy,
				onClick: () => {
					setBusy(true);
					onCreate().finally(() => setBusy(false));
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, { className: "size-4" }), "Neue Tour"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Hänge Punkte in der Reihenfolge an und fixiere die Tour, wenn die Runde steht."
			}),
			tours.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl leading-snug text-fg",
				children: "Noch keine Tour."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: tours.map((tour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen(tour.id),
					className: "w-full rounded-md border border-border bg-bg px-3 py-3 text-left hover:border-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 font-medium text-fg",
						children: [tour.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 text-primary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: tour.name
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-sm text-muted",
						children: [
							tour.stopIds.length,
							" Punkte · ",
							formatKm(tourLengthKm(tour, finds)),
							" Luftlinie",
							tour.fixed ? " · fixiert" : ""
						]
					})]
				}) }, tour.id))
			})
		]
	});
}
function FindForm({ editor, pin, setPin, userLoc, finds, photoUrls, onCancel, onSaved, onBanner }) {
	const existing = finds.find((find) => find.id === editor.id);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? editor.seed?.name ?? "");
	const initialMineral = existing?.mineral ?? editor.seed?.mineral ?? "Bergkristall";
	const known = MINERALS.includes(initialMineral);
	const [mineralPick, setMineralPick] = (0, import_react.useState)(known ? initialMineral : "Anderes");
	const [customMineral, setCustomMineral] = (0, import_react.useState)(known ? "" : initialMineral);
	const [notes, setNotes] = (0, import_react.useState)(existing?.notes ?? editor.seed?.notes ?? "");
	const [date, setDate] = (0, import_react.useState)(existing?.date || todayIso());
	const [latText, setLatText] = (0, import_react.useState)(pin ? String(pin.lat) : "");
	const [lngText, setLngText] = (0, import_react.useState)(pin ? String(pin.lng) : "");
	const [keepPhotoIds, setKeepPhotoIds] = (0, import_react.useState)(existing?.photoIds ?? []);
	const [files, setFiles] = (0, import_react.useState)([]);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!pin) return;
		setLatText(pin.lat.toFixed(5));
		setLngText(pin.lng.toFixed(5));
	}, [pin?.lat, pin?.lng]);
	const filesRef = (0, import_react.useRef)(files);
	filesRef.current = files;
	(0, import_react.useEffect)(() => {
		return () => {
			for (const item of filesRef.current) URL.revokeObjectURL(item.url);
		};
	}, []);
	const mineral = mineralPick === "Anderes" ? customMineral.trim() : mineralPick;
	const lat = parseCoord(latText);
	const lng = parseCoord(lngText);
	const outside = lat !== null && lng !== null && validCoord(lat, lng) && !inAustria(lat, lng);
	function pushCoords(nextLat, nextLng) {
		const parsedLat = parseCoord(nextLat);
		const parsedLng = parseCoord(nextLng);
		if (parsedLat === null || parsedLng === null || !validCoord(parsedLat, parsedLng)) return;
		setPin({
			lat: parsedLat,
			lng: parsedLng
		});
	}
	async function onSubmit(event) {
		event.preventDefault();
		if (lat === null || lng === null || !validCoord(lat, lng)) {
			setError("Koordinaten fehlen oder sind ungültig.");
			return;
		}
		setSaving(true);
		setError(null);
		const input = {
			id: editor.id,
			name,
			mineral,
			notes,
			date,
			lat,
			lng,
			keepPhotoIds,
			files: files.map((item) => item.file)
		};
		try {
			onSaved(await useField.getState().saveFind(input));
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "Speichern fehlgeschlagen.");
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-col gap-3",
		onSubmit: (event) => void onSubmit(event),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "inline-flex h-11 items-center gap-1 text-sm text-muted",
				onClick: onCancel,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Zurück"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-fg",
				children: editor.id ? "Fund bearbeiten" : "Neuer Fund"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Ein Tipp auf die Karte verschiebt den Punkt."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-xs font-medium text-muted",
				children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: clsx(fieldCls, "h-11"),
					value: name,
					maxLength: 80,
					onChange: (event) => setName(event.target.value),
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-xs font-medium text-muted",
				children: ["Mineral", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: clsx(fieldCls, "h-11"),
					value: mineralPick,
					onChange: (event) => setMineralPick(event.target.value),
					children: MINERALS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item,
						children: item
					}, item))
				})]
			}),
			mineralPick === "Anderes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: clsx(fieldCls, "h-11"),
				value: customMineral,
				maxLength: 40,
				placeholder: "Mineral nennen",
				onChange: (event) => setCustomMineral(event.target.value)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-xs font-medium text-muted",
				children: ["Datum", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: clsx(fieldCls, "h-11"),
					type: "date",
					value: date,
					onChange: (event) => setDate(event.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-1 text-xs font-medium text-muted",
					children: ["Breite", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: clsx(fieldCls, "h-11"),
						inputMode: "decimal",
						value: latText,
						onChange: (event) => {
							setLatText(event.target.value);
							pushCoords(event.target.value, lngText);
						}
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-1 text-xs font-medium text-muted",
					children: ["Länge", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: clsx(fieldCls, "h-11"),
						inputMode: "decimal",
						value: lngText,
						onChange: (event) => {
							setLngText(event.target.value);
							pushCoords(latText, event.target.value);
						}
					})]
				})]
			}),
			userLoc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: btnQuiet,
				onClick: () => setPin(userLoc),
				children: "Meinen Standort übernehmen"
			}) : null,
			outside ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Liegt außerhalb von Österreich. Du kannst ihn trotzdem speichern."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-xs font-medium text-muted",
				children: ["Notiz", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: clsx(fieldCls, "min-h-24 py-2"),
					value: notes,
					maxLength: 2e3,
					onChange: (event) => setNotes(event.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium text-muted",
						children: "Fotos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 overflow-x-auto",
						children: [keepPhotoIds.map((id) => photoUrls[id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: photoUrls[id],
								alt: "",
								className: "size-16 rounded-md object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "absolute right-1 top-1 grid size-6 place-items-center rounded-full bg-bg text-fg",
								"aria-label": "Foto entfernen",
								onClick: () => setKeepPhotoIds((ids) => ids.filter((item) => item !== id)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
							})]
						}, id) : null), files.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.url,
								alt: "",
								className: "size-16 rounded-md object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "absolute right-1 top-1 grid size-6 place-items-center rounded-full bg-bg text-fg",
								"aria-label": "Foto entfernen",
								onClick: () => {
									URL.revokeObjectURL(item.url);
									setFiles((current) => current.filter((entry) => entry.url !== item.url));
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
							})]
						}, item.url))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: clsx(btnQuiet, "cursor-pointer"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }),
							"Foto hinzufügen",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								multiple: true,
								className: "sr-only",
								onChange: (event) => {
									const list = Array.from(event.target.files ?? []);
									event.target.value = "";
									const room = 6 - keepPhotoIds.length - files.length;
									if (room <= 0) {
										onBanner("Höchstens 6 Fotos pro Fund.");
										return;
									}
									const next = list.slice(0, room).map((file) => ({
										file,
										url: URL.createObjectURL(file)
									}));
									setFiles((current) => [...current, ...next]);
								}
							})
						]
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: btnPrimary,
				disabled: saving || !name.trim(),
				children: saving ? "Speichert…" : "Fund speichern"
			})
		]
	});
}
function Detail({ detailKey, finds, photoUrls, onBack, onEdit, onAdopt, onBanner }) {
	const place = detailKey.startsWith("place:") ? PLACES.find((item) => item.id === detailKey.slice(6)) : void 0;
	const find = place ? void 0 : finds.find((item) => item.id === detailKey);
	const [photoIndex, setPhotoIndex] = (0, import_react.useState)(0);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const point = place ? {
		name: place.name,
		mineral: place.mineral,
		lat: place.lat,
		lng: place.lng,
		notes: place.note
	} : find ? {
		name: find.name,
		mineral: find.mineral,
		lat: find.lat,
		lng: find.lng,
		notes: find.notes
	} : null;
	const photos = (0, import_react.useMemo)(() => find ? find.photoIds.map((id) => photoUrls[id]).filter(Boolean) : [], [find, photoUrls]);
	if (!point) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "text-sm text-muted",
		onClick: onBack,
		children: "Zurück"
	});
	const current = photos[photoIndex] ?? photos[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "inline-flex h-11 items-center gap-1 text-sm text-muted",
				onClick: onBack,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Zurück"]
			}),
			current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: current,
				alt: point.name,
				className: "aspect-square w-full rounded-md object-cover"
			}) : null,
			photos.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: photos.map((src, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPhotoIndex(index),
					"aria-label": `Foto ${index + 1}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "",
						className: clsx("size-12 rounded-md object-cover", index === photoIndex ? "ring-2 ring-primary" : "")
					})
				}, src))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl leading-tight text-fg",
				children: point.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-primary",
				children: point.mineral
			}),
			place ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: place.region
			}) : null,
			find ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: formatDate(find.date)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg",
				children: formatCoords(point.lat, point.lng)
			}),
			point.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-fg",
				children: point.notes
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: btnQuiet,
				onClick: () => {
					navigator.clipboard?.writeText(`${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`).then(() => onBanner("Koordinaten kopiert."), () => onBanner("Kopieren nicht möglich."));
				},
				children: "Koordinaten kopieren"
			}),
			find ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: btnPrimary,
				onClick: () => onEdit(find.id),
				children: "Bearbeiten"
			}), confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 rounded-md border border-border p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: "Fund und Fotos löschen? Er verschwindet auch aus Touren."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: btnQuiet,
						onClick: () => {
							useField.getState().deleteFind(find.id).then(onBack);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Endgültig löschen"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 text-sm text-muted",
						onClick: () => setConfirmDelete(false),
						children: "Abbrechen"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 text-sm text-muted",
				onClick: () => setConfirmDelete(true),
				children: "Löschen"
			})] }) : place ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: btnPrimary,
				onClick: () => onAdopt(place.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Als eigenen Fund"]
			}) : null
		]
	});
}
function TourEditor({ tourId, finds, recording, setRecording, onBack, onBanner }) {
	const tour = useField((state) => state.tours.find((item) => item.id === tourId));
	const patchTour = useField((state) => state.patchTour);
	const deleteTour = useField((state) => state.deleteTour);
	const removeStop = useField((state) => state.removeStop);
	const moveStop = useField((state) => state.moveStop);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	if (!tour) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "text-sm text-muted",
		onClick: onBack,
		children: "Zurück"
	});
	const km = tourLengthKm(tour, finds);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "inline-flex h-11 items-center gap-1 text-sm text-muted",
				onClick: onBack,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Alle Touren"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-xs font-medium text-muted",
				children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: clsx(fieldCls, "h-11 font-display text-lg"),
					value: tour.name,
					maxLength: 80,
					onChange: (event) => void patchTour(tour.id, { name: event.target.value })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-xs font-medium text-muted",
				children: ["Datum", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: clsx(fieldCls, "h-11"),
					type: "date",
					value: tour.date,
					onChange: (event) => void patchTour(tour.id, { date: event.target.value })
				})]
			}),
			tour.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-md border border-border bg-bg px-3 py-3 text-sm leading-relaxed text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "mr-1 inline size-4 text-primary" }), "Fixiert. Reihenfolge und Punkte bleiben, bis du die Fixierung löst."]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: recording ? "Tippe Funde oder Orte auf der Karte an. Sie hängen sich in dieser Reihenfolge an." : "Starte das Aufnehmen und tippe die Punkte auf der Karte an."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-fg",
				children: [
					tour.stopIds.length,
					" Punkte · ",
					formatKm(km),
					" Luftlinie"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-2",
				children: tour.stopIds.map((stopId, index) => {
					const point = resolveStop(stopId, finds);
					if (!point) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2 rounded-md border border-border bg-bg px-2 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-7 shrink-0 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-fg",
								children: index + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm font-medium text-fg",
									children: point.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block truncate text-xs text-muted",
									children: [point.mineral, point.kind === "place" ? " · Orientierung" : ""]
								})]
							}),
							!tour.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex shrink-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-9 place-items-center text-muted",
										"aria-label": "Nach oben",
										onClick: () => void moveStop(tour.id, index, -1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-9 place-items-center text-muted",
										"aria-label": "Nach unten",
										onClick: () => void moveStop(tour.id, index, 1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-9 place-items-center text-muted",
										"aria-label": "Punkt entfernen",
										onClick: () => void removeStop(tour.id, index),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
									})
								]
							}) : null
						]
					}, `${stopId}-${index}`);
				})
			}),
			!tour.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: recording ? btnPrimary : btnQuiet,
				onClick: () => setRecording(!recording),
				children: recording ? "Aufnahme beenden" : "Punkte aufnehmen"
			}) : null,
			tour.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: btnQuiet,
				onClick: () => void patchTour(tour.id, { fixed: false }),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { className: "size-4" }), "Fixierung lösen"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: btnPrimary,
				disabled: tour.stopIds.length < 2,
				onClick: () => {
					patchTour(tour.id, {
						fixed: true,
						visible: true
					});
					setRecording(false);
					onBanner("Tour ist fixiert.");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), "Tour fixieren"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: btnQuiet,
				onClick: () => void patchTour(tour.id, { visible: !tour.visible }),
				children: [tour.visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }), tour.visible ? "Auf der Karte" : "Auf der Karte aus"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-xs font-medium text-muted",
				children: ["Notiz", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: clsx(fieldCls, "min-h-24 py-2"),
					value: tour.notes,
					maxLength: 2e3,
					onChange: (event) => void patchTour(tour.id, { notes: event.target.value })
				})]
			}),
			tour.stopIds.length < 2 && !tour.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Zum Fixieren brauchst du mindestens zwei Punkte."
			}) : null,
			confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: btnQuiet,
				onClick: () => {
					deleteTour(tour.id).then(onBack);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Tour löschen"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 text-sm text-muted",
				onClick: () => setConfirmDelete(true),
				children: "Tour löschen"
			})
		]
	});
}
var MAPS = [
	{
		id: "topo",
		label: "Topo"
	},
	{
		id: "karte",
		label: "Karte"
	},
	{
		id: "satellit",
		label: "Luft"
	}
];
function MineralApp() {
	const load = useField((state) => state.load);
	const finds = useField((state) => state.finds);
	const tours = useField((state) => state.tours);
	const addStop = useField((state) => state.addStop);
	const [basemap, setBasemap] = (0, import_react.useState)("topo");
	const [tab, setTab] = (0, import_react.useState)("funde");
	const [sheetOpen, setSheetOpen] = (0, import_react.useState)(true);
	const [query, setQuery] = (0, import_react.useState)("");
	const [showPlaces, setShowPlaces] = (0, import_react.useState)(true);
	const [editor, setEditor] = (0, import_react.useState)(null);
	const [pin, setPin] = (0, import_react.useState)(null);
	const [detailKey, setDetailKey] = (0, import_react.useState)(null);
	const [activeTourId, setActiveTourId] = (0, import_react.useState)(null);
	const [recording, setRecording] = (0, import_react.useState)(false);
	const [userLoc, setUserLoc] = (0, import_react.useState)(null);
	const [focus, setFocus] = (0, import_react.useState)(null);
	const [banner, setBanner] = (0, import_react.useState)(null);
	const [hintOff, setHintOff] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		load();
		try {
			setHintOff(localStorage.getItem("ader-hint") === "1");
		} catch {
			setHintOff(false);
		}
	}, [load]);
	const selectedKey = editor ? null : detailKey;
	const placing = !recording;
	function openDetail(key) {
		setDetailKey(key);
		setEditor(null);
		setPin(null);
		setActiveTourId(null);
		setRecording(false);
		setSheetOpen(true);
		if (key.startsWith("place:")) setTab("orte");
		else setTab("funde");
		const place = PLACES.find((item) => placeStopId(item.id) === key);
		const find = finds.find((item) => item.id === key);
		const point = place ?? find;
		if (point) setFocus({
			lat: point.lat,
			lng: point.lng,
			zoom: 12,
			token: Date.now()
		});
	}
	function onSelect(key) {
		if (recording && activeTourId) {
			const tour = tours.find((item) => item.id === activeTourId);
			if (tour?.fixed) return;
			if (tour?.stopIds.includes(key)) {
				setBanner("Der Punkt ist schon in der Tour.");
				return;
			}
			addStop(activeTourId, key).then((added) => {
				if (added) setBanner("Punkt angehängt.");
			});
			return;
		}
		openDetail(key);
	}
	function onMapClick(lat, lng) {
		if (recording) {
			setBanner("Tippe einen Fund oder einen Ort an, keine leere Stelle.");
			return;
		}
		setPin({
			lat,
			lng
		});
		setEditor((current) => current ?? { id: null });
		setDetailKey(null);
		setActiveTourId(null);
		setTab("funde");
		setSheetOpen(true);
	}
	function locate() {
		if (!navigator.geolocation) {
			setBanner("Standort ist hier nicht verfügbar.");
			return;
		}
		navigator.geolocation.getCurrentPosition((position) => {
			const next = {
				lat: position.coords.latitude,
				lng: position.coords.longitude
			};
			setUserLoc(next);
			setFocus({
				...next,
				zoom: 14,
				token: Date.now()
			});
		}, () => setBanner("Standort nicht freigegeben. Setze den Punkt auf der Karte."), {
			enableHighAccuracy: true,
			timeout: 12e3,
			maximumAge: 2e4
		});
	}
	const hint = recording ? "Aufnahme läuft — tippe Punkte auf der Karte an." : editor ? "Tipp auf die Karte verschiebt den Fund." : hintOff ? null : "Tipp auf die Karte, um einen Fund einzutragen.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex h-14 shrink-0 items-center gap-2 border-b border-border px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-9 shrink-0 place-items-center rounded-md bg-primary text-primary-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 leading-tight",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-lg font-semibold tracking-tight text-fg",
						children: "Ader"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden truncate text-xs text-muted sm:block",
						children: "Mineraliensuche · Österreich"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex rounded-md border border-border bg-surface p-0.5",
					role: "group",
					"aria-label": "Kartenstil",
					children: MAPS.map((map) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": basemap === map.id,
						onClick: () => setBasemap(map.id),
						className: clsx("h-9 rounded-md px-2 text-xs font-medium sm:px-3 sm:text-sm", basemap === map.id ? "bg-primary text-primary-fg" : "text-muted"),
						children: map.label
					}, map.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-md border border-border bg-surface text-fg",
					"aria-label": "Meinen Standort zeigen",
					onClick: locate,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Locate, { className: "size-5" })
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col xl:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative isolate min-h-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldMap, {
						basemap,
						finds,
						tours,
						showPlaces,
						selectedKey,
						activeTourId,
						draftPin: editor ? pin : null,
						userLoc,
						focus,
						placing,
						onMapClick,
						onSelect
					}),
					hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute inset-x-0 top-3 z-10 flex justify-center px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "pointer-events-auto flex max-w-md items-start gap-2 rounded-md border border-border bg-surface px-3 py-2 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hint }), !recording && !editor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-6 shrink-0 place-items-center text-muted",
								"aria-label": "Hinweis schließen",
								onClick: () => {
									setHintOff(true);
									try {
										localStorage.setItem("ader-hint", "1");
									} catch {}
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							}) : null]
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-none absolute bottom-8 left-3 z-10 hidden flex-col gap-1 rounded-md border border-border bg-surface px-3 py-2 text-xs text-muted sm:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "inline-block size-2.5 rotate-45 bg-primary" }), " Eigener Fund"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "inline-block size-2.5 rotate-45 border border-fg" }), " Orientierung"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "inline-block h-0.5 w-4 bg-primary" }), " Fixierte Tour"]
							})
						]
					}),
					banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-x-3 bottom-3 z-10 sm:left-auto sm:max-w-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-start gap-2 rounded-md border border-border bg-surface px-3 py-2 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								children: banner
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-muted",
								"aria-label": "Meldung schließen",
								onClick: () => setBanner(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						})
					}) : null,
					userLoc && !editor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute left-3 top-16 z-10 h-11 rounded-md border border-border bg-surface px-3 text-sm text-fg",
						onClick: () => {
							setPin(userLoc);
							setEditor({ id: null });
							setDetailKey(null);
							setTab("funde");
							setSheetOpen(true);
						},
						children: "Fund hier"
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldPanel, {
				tab,
				setTab: (next) => {
					setTab(next);
					setDetailKey(null);
					setEditor(null);
					setPin(null);
					setActiveTourId(null);
					setRecording(false);
					setSheetOpen(true);
				},
				sheetOpen,
				setSheetOpen,
				query,
				setQuery,
				showPlaces,
				setShowPlaces,
				editor,
				pin,
				setPin,
				detailKey,
				activeTourId,
				recording,
				setRecording,
				userLoc,
				onOpenDetail: openDetail,
				onCloseDetail: () => setDetailKey(null),
				onOpenEditor: (next) => {
					setEditor(next);
					setDetailKey(null);
					setActiveTourId(null);
					setRecording(false);
					setTab("funde");
					setSheetOpen(true);
					if (next.id) {
						const find = finds.find((item) => item.id === next.id);
						if (find) setPin({
							lat: find.lat,
							lng: find.lng
						});
					}
				},
				onCloseEditor: () => {
					setEditor(null);
					setPin(null);
				},
				onOpenTour: (id) => {
					setActiveTourId(id);
					setTab("touren");
					setEditor(null);
					setDetailKey(null);
					setPin(null);
					setSheetOpen(true);
					const first = tours.find((item) => item.id === id)?.stopIds[0];
					if (first) {
						const point = finds.find((item) => item.id === first);
						const place = PLACES.find((item) => placeStopId(item.id) === first);
						const target = point ?? place;
						if (target) setFocus({
							lat: target.lat,
							lng: target.lng,
							zoom: 10,
							token: Date.now()
						});
					}
				},
				onCloseTour: () => {
					setActiveTourId(null);
					setRecording(false);
				},
				onSaved: (id) => {
					const saved = pin;
					setEditor(null);
					setPin(null);
					setDetailKey(id);
					setActiveTourId(null);
					setRecording(false);
					setTab("funde");
					setSheetOpen(true);
					if (saved) setFocus({
						lat: saved.lat,
						lng: saved.lng,
						zoom: 12,
						token: Date.now()
					});
					setBanner("Fund liegt auf der Karte.");
				},
				onBanner: setBanner
			})]
		})]
	});
}
var SplitComponent = MineralApp;
//#endregion
export { SplitComponent as component };
