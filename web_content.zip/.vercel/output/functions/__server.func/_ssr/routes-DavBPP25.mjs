import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as LoaderCircle, d as FileUp, m as BookOpen, r as Trash2, u as Headphones } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as hashString, i as formatCount, n as cn, o as useLibrary, r as estimateMinutes, t as Button } from "./library-Dk3ax1hI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DavBPP25.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COVER_PALETTES = [
	{
		bg: "#2f3d38",
		fg: "#e8e0d4",
		rule: "#9db5ab"
	},
	{
		bg: "#3a322c",
		fg: "#f0e6d8",
		rule: "#c4b09a"
	},
	{
		bg: "#2a3340",
		fg: "#dce4ea",
		rule: "#8aa0b5"
	},
	{
		bg: "#3d3630",
		fg: "#efe6d4",
		rule: "#b8a48c"
	},
	{
		bg: "#2c3532",
		fg: "#e4ece8",
		rule: "#7f9e94"
	},
	{
		bg: "#403530",
		fg: "#f2e8dc",
		rule: "#c9a792"
	}
];
function coverFor(id) {
	return COVER_PALETTES[hashString(id) % COVER_PALETTES.length];
}
function initials(title) {
	const words = title.trim().split(/\s+/).filter(Boolean);
	if (words.length === 0) return "F";
	if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
	return (words[0][0] + words[1][0]).toUpperCase();
}
function BookCover({ id, title, className }) {
	const palette = coverFor(id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative isolate overflow-hidden rounded-md", className),
		style: {
			background: palette.bg,
			color: palette.fg
		},
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-y-0 left-0 w-1.5 opacity-80",
				style: { background: palette.rule }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 opacity-[0.07] [background-image:repeating-linear-gradient(90deg,transparent,transparent_11px,currentColor_11px,currentColor_12px)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-full flex-col justify-between p-3 pl-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-2xl font-medium tracking-tight",
					children: initials(title)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "line-clamp-3 font-display text-xs leading-snug tracking-tight",
					children: title
				})]
			})
		]
	});
}
function LibraryView() {
	const navigate = useNavigate();
	const inputRef = (0, import_react.useRef)(null);
	const [dragging, setDragging] = (0, import_react.useState)(false);
	const [importing, setImporting] = (0, import_react.useState)(false);
	const { books, hydrated, progress, hydrate, importEpub, removeBook } = useLibrary();
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	const continueId = mostRecentProgress(books, progress);
	async function handleFiles(files) {
		const file = files?.[0];
		if (!file) return;
		if (!file.name.toLowerCase().endsWith(".epub") && file.type !== "application/epub+zip") {
			toast.error("Elige un archivo .epub");
			return;
		}
		setImporting(true);
		try {
			const book = await importEpub(file);
			toast.success(`«${book.title}» está en tu biblioteca`);
			navigate({
				to: "/read/$bookId",
				params: { bookId: book.id }
			});
		} catch (err) {
			const message = err instanceof Error ? err.message : "No se pudo abrir el EPUB";
			toast.error(message);
		} finally {
			setImporting(false);
			if (inputRef.current) inputRef.current.value = "";
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-dvh w-full max-w-3xl px-5 pb-16 pt-8 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise-in mb-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-sans text-xs font-medium uppercase tracking-[0.18em] text-muted",
						children: "Lector con voz"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-5xl font-medium tracking-tight text-fg sm:text-6xl",
						children: "Folio"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-md text-pretty text-base leading-relaxed text-muted",
						children: "Abre un EPUB y escúchalo con las voces de tu dispositivo. El progreso se guarda aquí, en este aparato."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cn("rise-in-2 relative rounded-2xl bg-bg-elevated p-5 shadow-[var(--shadow-border)] sm:p-6", dragging && "ring-2 ring-ring"),
				onDragOver: (event) => {
					event.preventDefault();
					setDragging(true);
				},
				onDragLeave: () => setDragging(false),
				onDrop: (event) => {
					event.preventDefault();
					setDragging(false);
					handleFiles(event.dataTransfer.files);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-11 items-center justify-center rounded-md bg-bg-subtle text-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, {
								className: "size-5",
								strokeWidth: 1.75
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-sans text-sm font-medium text-fg",
							children: "Abrir un EPUB"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 max-w-sm text-sm leading-relaxed text-muted",
							children: "Arrástralo aquí o elige un archivo. Folio extrae los capítulos y los deja listos para leer en voz alta."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => inputRef.current?.click(),
						disabled: importing,
						className: "shrink-0",
						children: [importing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, { className: "size-4" }), importing ? "Abriendo…" : "Elegir archivo"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: inputRef,
					type: "file",
					accept: ".epub,application/epub+zip",
					className: "sr-only",
					tabIndex: -1,
					"aria-hidden": "true",
					onChange: (event) => void handleFiles(event.target.files)
				})]
			}),
			continueId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise-in-3 mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					className: "w-full justify-between sm:w-auto",
					onClick: () => void navigate({
						to: "/read/$bookId",
						params: { bookId: continueId }
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" }), "Continuar lectura"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-muted",
						children: books.find((b) => b.id === continueId)?.title
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium tracking-tight",
						children: "Biblioteca"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted tabular-nums",
						children: [
							hydrated ? formatCount(books.length) : "—",
							" ",
							books.length === 1 ? "libro" : "libros"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
					children: books.map((book) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCard, {
						book,
						chapter: progress[book.id]?.chapter,
						onOpen: () => void navigate({
							to: "/read/$bookId",
							params: { bookId: book.id }
						}),
						onRemove: book.isSample ? void 0 : () => void removeBook(book.id)
					}) }, book.id))
				})]
			})
		]
	});
}
function BookCard({ book, chapter, onOpen, onRemove }) {
	const minutes = estimateMinutes(book.totalChars);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group relative flex gap-3 rounded-xl bg-bg-elevated p-3 shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:shadow-[var(--shadow-border-hover)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onOpen,
			className: "flex min-w-0 flex-1 gap-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCover, {
				id: book.id,
				title: book.title,
				className: "h-[7.5rem] w-[5.25rem] shrink-0"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-base font-medium leading-snug tracking-tight text-fg",
						children: book.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate text-sm text-muted",
						children: book.author ?? "Autor desconocido"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-auto pt-3 text-xs text-subtle tabular-nums",
						children: [
							book.chapterCount,
							" ",
							book.chapterCount === 1 ? "capítulo" : "capítulos",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-1.5 text-border",
								children: "·"
							}),
							minutes,
							" min",
							typeof chapter === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-1.5 text-border",
									children: "·"
								}),
								"cap. ",
								chapter + 1
							] }) : null
						]
					}),
					book.isSample && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 w-fit rounded-sm bg-bg-subtle px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wider text-muted",
						children: "Muestra"
					})
				]
			})]
		}), onRemove && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon",
			className: "size-9 shrink-0 self-start text-muted hover:text-danger",
			"aria-label": `Quitar ${book.title}`,
			onClick: () => onRemove(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
		})]
	});
}
function mostRecentProgress(books, progress) {
	let best = null;
	for (const book of books) {
		const entry = progress[book.id];
		if (!entry) continue;
		if (!best || entry.updatedAt > best.at) best = {
			id: book.id,
			at: entry.updatedAt
		};
	}
	return best?.id ?? null;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryView, {});
}
//#endregion
export { Home as component };
