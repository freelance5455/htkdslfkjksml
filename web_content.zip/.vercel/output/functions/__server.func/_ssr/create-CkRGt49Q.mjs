import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useProjects, n as idbPut, o as useStory } from "./use-projects-B0rAf6PZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/create-CkRGt49Q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PENDING_KEY = "storyboard-ai-pending-create";
function Create() {
	const ready = useProjects();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const pending = sessionStorage.getItem(PENDING_KEY);
		if (pending) {
			sessionStorage.removeItem(PENDING_KEY);
			navigate({
				to: "/storyboards/$id",
				params: { id: pending },
				replace: true
			});
			return;
		}
		const project = useStory.getState().createBlank();
		sessionStorage.setItem(PENDING_KEY, project.id);
		idbPut(project).finally(() => {
			sessionStorage.removeItem(PENDING_KEY);
			navigate({
				to: "/storyboards/$id",
				params: { id: project.id },
				replace: true
			});
		});
	}, [ready, navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Menyiapkan storyboard…"
	});
}
//#endregion
export { Create as component };
