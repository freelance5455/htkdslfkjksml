import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ask-grok-g1LKXSlt.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askGrok_createServerFn_handler = createServerRpc({
	id: "45fa6e0b190ce19650091744e8f19e6f28d1755841078e62174c799ba69fbf04",
	name: "askGrok",
	filename: "src/lib/ai/ask-grok.ts"
}, (opts) => askGrok.__executeServer(opts));
var askGrok = createServerFn({ method: "POST" }).validator((input) => input).handler(askGrok_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment"
	};
	const prompt = data.prompt.slice(0, 4e3);
	const snapshot = data.snapshot.slice(0, 2500);
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 700,
			temperature: .6,
			messages: [{
				role: "system",
				content: "You are Lumen, a concise personal assistant. The user's private board lives on their device. Use the snapshot only as context. Keep replies under 120 words unless they ask for long form. Do not claim you can control hardware beyond suggesting tel/sms/mailto. If they want something saved (task, note, reminder, message), end with a single fenced action block:\n```action\n{\"type\":\"add_task\",\"title\":\"...\"}\n```\nValid types: add_task (title, dueAt null|ms), add_note (title, body), add_reminder (title, at ms), add_list_item (list, item), add_event (title, startAt ms, place), message (name, body, kind sms|email). If no board change is needed, omit the action block."
			}, {
				role: "user",
				content: `Board snapshot:\n${snapshot || "(empty)"}\n\nRequest:\n${prompt}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI API error ${res.status}`
	};
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content ?? ""
	};
});
//#endregion
export { askGrok_createServerFn_handler };
