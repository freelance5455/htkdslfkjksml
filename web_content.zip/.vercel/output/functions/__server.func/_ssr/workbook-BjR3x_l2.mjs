import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as BookOpen } from "../_libs/lucide-react.mjs";
import { E as utcTodayIso, S as partStatus, T as useMinistry, h as formatLong, i as Card, r as Button, s as PageIntro, t as AppShell } from "./shell-CGpvgZIy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workbook-BjR3x_l2.js
var import_jsx_runtime = require_jsx_runtime();
var SECTION = {
	opening: "Opening",
	treasures: "Treasures from God’s Word",
	ministry: "Apply Yourself to the Field Ministry",
	living: "Living as Christians",
	closing: "Closing"
};
function WorkbookPage() {
	const navigate = useNavigate();
	const focusMeeting = useMinistry((state) => state.focusMeeting);
	const meetings = useMinistry((state) => state.meetings);
	const assignments = useMinistry((state) => state.assignments);
	const today = utcTodayIso();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: "Workbook",
		title: "JW Workbook",
		lede: "Original midweek outlines for this congregation. Open a week in the planner when you are ready to assign it."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: meetings.map((meeting) => {
			const parts = assignments.filter((assignment) => assignment.meetingId === meeting.id).sort((a, b) => a.order - b.order);
			const open = parts.filter((part) => partStatus(meeting.date, part.assigneeId, today) === "unassigned").length;
			let section = null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-12 shrink-0 place-items-center rounded-2xl bg-sidebar text-cyan",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold tracking-[0.14em] text-royal uppercase",
									children: ["Week of ", meeting.weekLabel]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-3xl",
									children: meeting.theme
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										formatLong(meeting.date),
										" · Bible reading ",
										meeting.reading
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 max-w-xl text-sm text-muted",
									children: meeting.summary
								})
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "soft",
							onClick: () => {
								focusMeeting(meeting.id);
								navigate({ to: "/planner" });
							},
							children: "Open in planner"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs font-medium text-muted",
						children: [
							"Songs ",
							meeting.songs.join(" · "),
							meeting.date < today ? " · Completed week" : open ? ` · ${open} open parts` : " · Parts assigned"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 space-y-2",
						children: parts.map((part) => {
							const show = part.section !== section;
							section = part.section;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 mb-1 text-[11px] font-semibold tracking-[0.14em] text-muted uppercase",
								children: SECTION[part.section]
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3 rounded-2xl bg-soft px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm font-semibold",
										children: part.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted",
										children: part.detail
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 text-xs font-semibold text-muted tabular-nums",
									children: [part.durationMin, " min"]
								})]
							})] }, part.id);
						})
					})
				]
			}, meeting.id);
		})
	})] });
}
var SplitComponent = function WorkbookRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkbookPage, {}) });
};
//#endregion
export { SplitComponent as component };
