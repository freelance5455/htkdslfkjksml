//#region node_modules/.nitro/vite/services/ssr/assets/id-capIYR7Y.js
function uid() {
	return crypto.randomUUID();
}
function moveItem(items, from, to) {
	if (to < 0 || to >= items.length || from === to) return items;
	const next = items.slice();
	const [item] = next.splice(from, 1);
	if (item === void 0) return items;
	next.splice(to, 0, item);
	return next;
}
//#endregion
export { uid as n, moveItem as t };
