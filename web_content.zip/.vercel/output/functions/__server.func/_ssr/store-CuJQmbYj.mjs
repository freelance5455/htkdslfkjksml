import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { a as format, c as startOfDay, i as isAfter, l as addDays, n as parseISO, o as eachDayOfInterval, r as isBefore, s as differenceInCalendarDays, t as ptBR } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-CuJQmbYj.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}
function formatHours(h) {
	if (h == null || Number.isNaN(h)) return "—";
	const sign = h < 0 ? "-" : "";
	const abs = Math.abs(h);
	const hours = Math.floor(abs);
	const mins = Math.round((abs - hours) * 60);
	if (mins === 0) return `${sign}${hours}h`;
	if (mins === 60) return `${sign}${hours + 1}h`;
	return `${sign}${hours}h${String(mins).padStart(2, "0")}`;
}
function formatDuration(sec) {
	const s = Math.max(0, Math.round(sec));
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const r = s % 60;
	if (h > 0) return `${h}h ${String(m).padStart(2, "0")}min`;
	if (m > 0) return `${m} min ${String(r).padStart(2, "0")}s`;
	return `${r}s`;
}
function formatMmSs(sec) {
	const s = Math.max(0, Math.ceil(sec));
	const m = Math.floor(s / 60);
	const r = s % 60;
	return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}
function ex(id, name, sets, reps, restSec, extra) {
	return {
		id,
		name,
		sets,
		reps,
		load: extra?.load ?? "",
		restSec,
		notes: extra?.notes ?? "",
		timeBased: extra?.timeBased ?? false
	};
}
var REST_PRESETS = [
	30,
	45,
	60,
	90,
	120
];
var DEFAULT_SETTINGS = {
	name: "",
	defaultRest: 60,
	soundEnabled: true,
	notificationsEnabled: true,
	waterGoalMl: 2e3,
	sleepGoalHours: 8,
	extraHabits: []
};
var DEFAULT_POSTURE = [
	ex("pos-chin-tuck", "Chin tuck", 3, "10 reps", 45, { notes: "Olhe para frente, recolha o queixo em direção ao pescoço sem baixar a cabeça. Segure 2–3 s." }),
	ex("pos-retracao", "Retração escapular", 3, "12 reps", 45, { notes: "Puxe os ombros para trás e para baixo, aproximando as escápulas. Sem encoger." }),
	ex("pos-crucifixo", "Crucifixo inverso", 3, "12 reps", 60, { notes: "Abra os braços na linha dos ombros, apertando as escápulas no final do movimento." }),
	ex("pos-peitoral", "Alongamento peitoral na parede", 3, "30 s cada lado", 30, {
		timeBased: true,
		notes: "Antebraço na parede, gire o tronco para o lado oposto até sentir o peito abrir."
	})
];
var MUAY_THAI = [
	ex("mt-corda", "Corda / aquecimento", 3, "3 min", 60, {
		timeBased: true,
		notes: "Ritmo leve a moderado. Ombros relaxados, respiração constante."
	}),
	ex("mt-sombra", "Sombra", 3, "3 min", 60, {
		timeBased: true,
		notes: "Jab, cruzado, guardas altas. Movimento de pés contínuo."
	}),
	ex("mt-jab-cross", "Jab e cruzado no saco", 4, "12 reps", 60, { notes: "Estenda sem travar o cotovelo. Recolha a guarda após cada golpe." }),
	ex("mt-teep", "Teep (chute frontal)", 3, "10 cada perna", 60, { notes: "Empurre com o calcanhar, quadril para frente, guarda alta." }),
	ex("mt-roundhouse", "Roundhouse (chute circular)", 3, "8 cada perna", 75, { notes: "Gire o quadril, bata com a canela, volte à base." }),
	ex("mt-joelhos", "Joelhos no saco", 3, "12 reps", 60, { notes: "Puxe o saco e suba o joelho. Tronco firme." }),
	ex("mt-clinch", "Clinch / pummeling", 3, "30 s", 45, {
		timeBased: true,
		notes: "Controle da nuca e postura. Sem pressa, posição primeiro."
	}),
	ex("mt-core", "Core de luta", 3, "15 reps", 45, { notes: "Abdominais curtos ou bicycle. Expire na contração." })
];
var SUPERIOR = [
	ex("sup-flexao", "Flexão com mochila", 4, "8–15", 90, {
		load: "Mochila",
		notes: "Corpo em prancha, cotovelos a ~45°. Peito próximo ao chão."
	}),
	ex("sup-remada-curvada", "Remada curvada com mochila", 4, "8–15", 90, {
		load: "Mochila",
		notes: "Quadril para trás, coluna neutra. Puxe em direção ao quadril."
	}),
	ex("sup-remada-uni", "Remada unilateral com mochila", 3, "10–15", 60, {
		load: "Mochila",
		notes: "Apoie uma mão. Evite girar o tronco."
	}),
	ex("sup-pike", "Pike push-up", 3, "6–12", 90, { notes: "Quadril alto, em A. Desça a cabeça à frente das mãos." }),
	ex("sup-fechada", "Flexão fechada", 3, "8–15", 60, { notes: "Mãos próximas, cotovelos rasando o tronco." }),
	ex("sup-rosca", "Rosca com mochila", 3, "10–15", 45, {
		load: "Mochila",
		notes: "Cotovelos fixos. Suba sem balanço."
	})
];
var INFERIOR = [
	ex("inf-agachamento", "Agachamento com mochila", 4, "10–15", 90, {
		load: "Mochila",
		notes: "Pés na largura do quadril. Desça com controle, joelho alinhado."
	}),
	ex("inf-afundo", "Afundo búlgaro", 3, "8–12 cada perna", 75, {
		load: "Mochila",
		notes: "Pé de trás elevado. Tronco alto, joelho da frente estável."
	}),
	ex("inf-stiff", "Stiff com mochila", 3, "10–15", 75, {
		load: "Mochila",
		notes: "Joelhos levemente flexionados. Quadril para trás, posterior ativo."
	}),
	ex("inf-pelvica", "Elevação pélvica com mochila", 3, "10–15", 60, {
		load: "Mochila",
		notes: "Aperte o glúteo no topo. Sem hiperextender a lombar."
	}),
	ex("inf-panturrilha", "Panturrilha unilateral", 4, "12–20", 45, { notes: "Amplitude completa. Pausa de 1 s no topo." }),
	ex("inf-pernas", "Elevação de pernas", 3, "10–15", 45, { notes: "Lombar no chão. Suba com controle, sem balanço." }),
	ex("inf-prancha", "Prancha", 3, "30–60 s", 45, {
		timeBased: true,
		notes: "Quadril alinhado. Glúteo e abdômen ativos."
	})
];
var RECUPERACAO = [
	ex("rec-caminhada", "Caminhada leve", 1, "20–40 min", 0, {
		timeBased: true,
		notes: "Ritmo conversável. Sem ofegância."
	}),
	ex("rec-quadril", "Mobilidade de quadril", 2, "10 reps", 30, { notes: "Círculos, 90/90 ou abertura de joelhos. Sem dor aguda." }),
	ex("rec-gato-vaca", "Gato-vaca", 2, "10 reps", 20, { notes: "Alterne flexão e extensão da coluna, respirando devagar." }),
	ex("rec-posterior", "Alongamento posterior", 3, "30 s", 20, {
		timeBased: true,
		notes: "Isquiotibiais e panturrilha. Sem forçar a lombar."
	}),
	ex("rec-respiracao", "Respiração", 1, "5 min", 0, {
		timeBased: true,
		notes: "Inspire pelo nariz, expire longo. Ombros baixos."
	})
];
var DESCANSO = [ex("des-livre", "Descanso ativo opcional", 1, "10–20 min", 0, {
	timeBased: true,
	notes: "Caminhada curta, alongamento ou nada. O descanso conta."
})];
function workout(day, type, title, subtitle, exercises) {
	return {
		day,
		type,
		title,
		subtitle,
		exercises
	};
}
var DEFAULT_WORKOUTS = {
	segunda: workout("segunda", "muay-thai", "Muay Thai", "Técnica, saco e rounds", MUAY_THAI),
	terca: workout("terca", "superior", "Superior", "Empurrar, puxar e braços", SUPERIOR),
	quarta: workout("quarta", "muay-thai", "Muay Thai", "Técnica, saco e rounds", MUAY_THAI.map((e) => ({
		...e,
		id: e.id.replace("mt-", "mt2-")
	}))),
	quinta: workout("quinta", "inferior", "Inferior + Core", "Pernas, glúteo e tronco", INFERIOR),
	sexta: workout("sexta", "muay-thai", "Muay Thai", "Técnica, saco e rounds", MUAY_THAI.map((e) => ({
		...e,
		id: e.id.replace("mt-", "mt3-")
	}))),
	sabado: workout("sabado", "recuperacao", "Recuperação", "Atividade leve e mobilidade", RECUPERACAO),
	domingo: workout("domingo", "descanso", "Descanso", "Recuperação completa", DESCANSO)
};
function cloneWorkouts() {
	return JSON.parse(JSON.stringify(DEFAULT_WORKOUTS));
}
function clonePosture() {
	return JSON.parse(JSON.stringify(DEFAULT_POSTURE));
}
function cloneSettings() {
	return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
}
var SESSION_TYPE_LABEL = {
	"muay-thai": "Muay Thai",
	superior: "Superior",
	inferior: "Inferior + Core",
	recuperacao: "Recuperação",
	descanso: "Descanso",
	postura: "Postura"
};
var SKIN_CARE_ITEMS = [
	{
		key: "cleansing",
		label: "Limpeza facial"
	},
	{
		key: "moisturizer",
		label: "Hidratante facial"
	},
	{
		key: "sunscreen",
		label: "Protetor solar"
	}
];
var FOOD_ITEMS = [
	{
		key: "completeMeals",
		label: "Fiz refeições completas"
	},
	{
		key: "fruitsVeggies",
		label: "Comi frutas/vegetais"
	},
	{
		key: "protein",
		label: "Consumi fontes de proteína"
	},
	{
		key: "reducedUltra",
		label: "Reduzi ultraprocessados"
	}
];
var WATER_QUICK = [
	250,
	500,
	750
];
var SLEEP_QUICK = [
	6,
	7,
	7.5,
	8,
	8.5,
	9
];
var PROJECT_START = startOfDay(new Date(2026, 8, 21));
var PROJECT_END = startOfDay(new Date(2026, 11, 30));
var WEEKDAYS = [
	"segunda",
	"terca",
	"quarta",
	"quinta",
	"sexta",
	"sabado",
	"domingo"
];
var WEEKDAY_LABEL = {
	segunda: "Segunda",
	terca: "Terça",
	quarta: "Quarta",
	quinta: "Quinta",
	sexta: "Sexta",
	sabado: "Sábado",
	domingo: "Domingo"
};
var JS_DAY_TO_KEY = [
	"domingo",
	"segunda",
	"terca",
	"quarta",
	"quinta",
	"sexta",
	"sabado"
];
function toDateKey(d) {
	return format(d, "yyyy-MM-dd");
}
function parseDateKey(key) {
	return startOfDay(parseISO(key));
}
function weekdayFromDate(d) {
	return JS_DAY_TO_KEY[d.getDay()] ?? "segunda";
}
function formatLongDate(d) {
	const date = typeof d === "string" ? parseDateKey(d) : d;
	return format(date, "d 'de' MMMM yyyy", { locale: ptBR });
}
function formatShortDate(d) {
	const date = typeof d === "string" ? parseDateKey(d) : d;
	return format(date, "dd/MM/yyyy");
}
function projectDayNumber(d) {
	const date = startOfDay(d);
	if (isBefore(date, PROJECT_START)) return 0;
	if (isAfter(date, PROJECT_END)) return 101;
	return differenceInCalendarDays(date, PROJECT_START) + 1;
}
function allProjectDates() {
	return eachDayOfInterval({
		start: PROJECT_START,
		end: PROJECT_END
	}).map(toDateKey);
}
function daysUntil(target, from) {
	return differenceInCalendarDays(startOfDay(target), startOfDay(from));
}
function projectProgressPct(d) {
	if (isBefore(startOfDay(d), PROJECT_START)) return 0;
	const n = projectDayNumber(d);
	return Math.round(n / 101 * 100);
}
function emptyLog(date) {
	return {
		date,
		skinCare: {
			cleansing: false,
			moisturizer: false,
			sunscreen: false
		},
		waterMl: 0,
		sleepHours: null,
		food: {
			completeMeals: false,
			fruitsVeggies: false,
			protein: false,
			reducedUltra: false
		},
		posture: false,
		workout: false,
		notes: "",
		extraHabits: {}
	};
}
function getDayChecks(log, settings) {
	if (!log) return {
		skinCare: false,
		water: false,
		sleep: false,
		food: false,
		posture: false,
		workout: false,
		extras: [],
		doneCount: 0,
		total: 6 + settings.extraHabits.length
	};
	const skinCare = log.skinCare.cleansing && log.skinCare.moisturizer && log.skinCare.sunscreen;
	const water = log.waterMl >= settings.waterGoalMl;
	const sleep = log.sleepHours != null && log.sleepHours >= settings.sleepGoalHours;
	const food = log.food.completeMeals && log.food.fruitsVeggies && log.food.protein && log.food.reducedUltra;
	const extras = settings.extraHabits.map((h) => ({
		...h,
		done: Boolean(log.extraHabits[h.id])
	}));
	const doneCount = [
		skinCare,
		water,
		sleep,
		food,
		log.posture,
		log.workout
	].filter(Boolean).length + extras.filter((e) => e.done).length;
	return {
		skinCare,
		water,
		sleep,
		food,
		posture: log.posture,
		workout: log.workout,
		extras,
		doneCount,
		total: 6 + extras.length
	};
}
function getDayStatus(log, settings) {
	if (!log) return "empty";
	const c = getDayChecks(log, settings);
	if (c.doneCount === 0 && log.waterMl === 0 && log.sleepHours == null) return "empty";
	if (c.doneCount >= c.total) return "complete";
	return "partial";
}
function countHabitMarks(log) {
	if (!log) return 0;
	let n = 0;
	if (log.skinCare.cleansing) n += 1;
	if (log.skinCare.moisturizer) n += 1;
	if (log.skinCare.sunscreen) n += 1;
	if (log.waterMl > 0) n += 1;
	if (log.sleepHours != null) n += 1;
	if (log.food.completeMeals) n += 1;
	if (log.food.fruitsVeggies) n += 1;
	if (log.food.protein) n += 1;
	if (log.food.reducedUltra) n += 1;
	if (log.posture) n += 1;
	if (log.workout) n += 1;
	n += Object.values(log.extraHabits).filter(Boolean).length;
	return n;
}
function computeStreak(logs, settings, today) {
	let cursor = startOfDay(today);
	if (getDayStatus(logs[toDateKey(cursor)], settings) === "empty") cursor = addDays(cursor, -1);
	let streak = 0;
	while (true) {
		if (getDayStatus(logs[toDateKey(cursor)], settings) === "empty") break;
		streak += 1;
		cursor = addDays(cursor, -1);
		if (streak > 400) break;
	}
	return streak;
}
var idleRest = {
	open: false,
	running: false,
	duration: 60,
	remaining: 0,
	exerciseName: "",
	finished: false
};
function mutateLog(logs, date, fn) {
	const current = logs[date] ?? emptyLog(date);
	return {
		...logs,
		[date]: fn({ ...current })
	};
}
function toLive(ex) {
	return {
		...ex,
		completedSets: 0,
		setLogs: []
	};
}
function moveItem(list, id, dir) {
	const i = list.findIndex((x) => x.id === id);
	if (i < 0) return list;
	const j = i + dir;
	if (j < 0 || j >= list.length) return list;
	const next = [...list];
	const tmp = next[i];
	next[i] = next[j];
	next[j] = tmp;
	return next;
}
function blankExercise(rest, name = "Novo exercício") {
	return {
		id: uid(),
		name,
		sets: 3,
		reps: "10",
		load: "",
		restSec: rest,
		notes: "",
		timeBased: false
	};
}
var useAppStore = create()(persist((set, get) => ({
	hydrated: false,
	settings: cloneSettings(),
	workouts: cloneWorkouts(),
	posture: clonePosture(),
	logs: {},
	sessions: [],
	activeSession: null,
	restTimer: idleRest,
	setHydrated: (v) => set({ hydrated: v }),
	patchSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch
	} })),
	restoreSettings: () => set({ settings: cloneSettings() }),
	ensureLog: (date) => {
		const existing = get().logs[date];
		if (existing) return existing;
		const log = emptyLog(date);
		set((s) => ({ logs: {
			...s.logs,
			[date]: log
		} }));
		return log;
	},
	toggleSkinCare: (date, key) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		skinCare: {
			...log.skinCare,
			[key]: !log.skinCare[key]
		}
	})) })),
	addWater: (date, ml) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		waterMl: Math.max(0, log.waterMl + ml)
	})) })),
	setWater: (date, ml) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		waterMl: Math.max(0, ml)
	})) })),
	setSleep: (date, hours) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		sleepHours: hours
	})) })),
	toggleFood: (date, key) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		food: {
			...log.food,
			[key]: !log.food[key]
		}
	})) })),
	togglePostureHabit: (date) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		posture: !log.posture
	})) })),
	toggleWorkoutHabit: (date) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		workout: !log.workout
	})) })),
	toggleExtraHabit: (date, id) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		extraHabits: {
			...log.extraHabits,
			[id]: !log.extraHabits[id]
		}
	})) })),
	setDayNotes: (date, notes) => set((s) => ({ logs: mutateLog(s.logs, date, (log) => ({
		...log,
		notes
	})) })),
	addExtraHabit: (name) => set((s) => ({ settings: {
		...s.settings,
		extraHabits: [...s.settings.extraHabits, {
			id: uid(),
			name: name.trim()
		}]
	} })),
	removeExtraHabit: (id) => set((s) => ({ settings: {
		...s.settings,
		extraHabits: s.settings.extraHabits.filter((h) => h.id !== id)
	} })),
	renameExtraHabit: (id, name) => set((s) => ({ settings: {
		...s.settings,
		extraHabits: s.settings.extraHabits.map((h) => h.id === id ? {
			...h,
			name
		} : h)
	} })),
	startSession: ({ date, dayKey, exercises, type, title }) => {
		const id = uid();
		set({ activeSession: {
			id,
			date,
			dayKey,
			type,
			title,
			startedAt: Date.now(),
			exercises: exercises.map(toLive),
			notes: ""
		} });
		return id;
	},
	completeSet: (exerciseId) => {
		const session = get().activeSession;
		if (!session) return;
		const exercise = session.exercises.find((e) => e.id === exerciseId);
		if (!exercise) return;
		if (exercise.completedSets >= exercise.sets) return;
		set({ activeSession: {
			...session,
			exercises: session.exercises.map((e) => e.id === exerciseId ? {
				...e,
				completedSets: e.completedSets + 1,
				setLogs: [...e.setLogs, {
					reps: e.reps,
					load: e.load,
					at: Date.now()
				}]
			} : e)
		} });
		if (exercise.restSec > 0) get().startRest(exercise.restSec, exercise.name);
	},
	undoSet: (exerciseId) => {
		const session = get().activeSession;
		if (!session) return;
		set({ activeSession: {
			...session,
			exercises: session.exercises.map((e) => e.id === exerciseId && e.completedSets > 0 ? {
				...e,
				completedSets: e.completedSets - 1,
				setLogs: e.setLogs.slice(0, -1)
			} : e)
		} });
	},
	updateLiveExercise: (exerciseId, patch) => {
		const session = get().activeSession;
		if (!session) return;
		set({ activeSession: {
			...session,
			exercises: session.exercises.map((e) => e.id === exerciseId ? {
				...e,
				...patch
			} : e)
		} });
	},
	setSessionNotes: (notes) => {
		const session = get().activeSession;
		if (!session) return;
		set({ activeSession: {
			...session,
			notes
		} });
	},
	finishSession: () => {
		const session = get().activeSession;
		if (!session) return null;
		const finishedAt = Date.now();
		const saved = {
			id: session.id,
			date: session.date,
			dayKey: session.dayKey,
			type: session.type,
			title: session.title,
			startedAt: session.startedAt,
			finishedAt,
			durationSec: Math.max(1, Math.round((finishedAt - session.startedAt) / 1e3)),
			notes: session.notes,
			completed: true,
			exercises: session.exercises
		};
		set((s) => ({
			activeSession: null,
			restTimer: idleRest,
			sessions: [saved, ...s.sessions],
			logs: mutateLog(s.logs, session.date, (log) => ({
				...log,
				workout: session.type === "postura" ? log.workout : true,
				posture: session.type === "postura" ? true : log.posture
			}))
		}));
		return saved;
	},
	abandonSession: () => set({
		activeSession: null,
		restTimer: idleRest
	}),
	updateWorkoutExercise: (day, exerciseId, patch) => set((s) => ({ workouts: {
		...s.workouts,
		[day]: {
			...s.workouts[day],
			exercises: s.workouts[day].exercises.map((e) => e.id === exerciseId ? {
				...e,
				...patch
			} : e)
		}
	} })),
	addWorkoutExercise: (day, exercise) => set((s) => ({ workouts: {
		...s.workouts,
		[day]: {
			...s.workouts[day],
			exercises: [...s.workouts[day].exercises, {
				...blankExercise(s.settings.defaultRest),
				...exercise,
				id: uid()
			}]
		}
	} })),
	removeWorkoutExercise: (day, exerciseId) => set((s) => ({ workouts: {
		...s.workouts,
		[day]: {
			...s.workouts[day],
			exercises: s.workouts[day].exercises.filter((e) => e.id !== exerciseId)
		}
	} })),
	duplicateWorkoutExercise: (day, exerciseId) => set((s) => {
		const list = s.workouts[day].exercises;
		const i = list.findIndex((e) => e.id === exerciseId);
		if (i < 0) return {};
		const copy = {
			...list[i],
			id: uid(),
			name: `${list[i].name} (cópia)`
		};
		const exercises = [...list];
		exercises.splice(i + 1, 0, copy);
		return { workouts: {
			...s.workouts,
			[day]: {
				...s.workouts[day],
				exercises
			}
		} };
	}),
	moveWorkoutExercise: (day, exerciseId, dir) => set((s) => ({ workouts: {
		...s.workouts,
		[day]: {
			...s.workouts[day],
			exercises: moveItem(s.workouts[day].exercises, exerciseId, dir)
		}
	} })),
	restoreWorkout: (day) => {
		const fresh = cloneWorkouts();
		set((s) => ({ workouts: {
			...s.workouts,
			[day]: fresh[day]
		} }));
	},
	updatePostureExercise: (exerciseId, patch) => set((s) => ({ posture: s.posture.map((e) => e.id === exerciseId ? {
		...e,
		...patch
	} : e) })),
	addPostureExercise: (exercise) => set((s) => ({ posture: [...s.posture, {
		...blankExercise(s.settings.defaultRest),
		...exercise,
		id: uid()
	}] })),
	removePostureExercise: (exerciseId) => set((s) => ({ posture: s.posture.filter((e) => e.id !== exerciseId) })),
	duplicatePostureExercise: (exerciseId) => set((s) => {
		const i = s.posture.findIndex((e) => e.id === exerciseId);
		if (i < 0) return {};
		const copy = {
			...s.posture[i],
			id: uid(),
			name: `${s.posture[i].name} (cópia)`
		};
		const posture = [...s.posture];
		posture.splice(i + 1, 0, copy);
		return { posture };
	}),
	movePostureExercise: (exerciseId, dir) => set((s) => ({ posture: moveItem(s.posture, exerciseId, dir) })),
	restorePosture: () => set({ posture: clonePosture() }),
	startRest: (duration, exerciseName) => set({ restTimer: {
		open: true,
		running: true,
		duration,
		remaining: duration,
		exerciseName,
		finished: false
	} }),
	pauseRest: () => set((s) => ({ restTimer: {
		...s.restTimer,
		running: false
	} })),
	resumeRest: () => set((s) => ({ restTimer: {
		...s.restTimer,
		running: s.restTimer.remaining > 0
	} })),
	skipRest: () => set({ restTimer: idleRest }),
	restartRest: () => set((s) => ({ restTimer: {
		...s.restTimer,
		remaining: s.restTimer.duration,
		running: true,
		finished: false,
		open: true
	} })),
	closeRest: () => set({ restTimer: idleRest }),
	tickRest: (dt) => {
		const t = get().restTimer;
		if (!t.open || !t.running || t.finished) return;
		const remaining = Math.max(0, t.remaining - dt);
		if (remaining <= 0) {
			set({ restTimer: {
				...t,
				remaining: 0,
				running: false,
				finished: true
			} });
			return;
		}
		set({ restTimer: {
			...t,
			remaining
		} });
	},
	resetAllData: () => set({
		settings: cloneSettings(),
		workouts: cloneWorkouts(),
		posture: clonePosture(),
		logs: {},
		sessions: [],
		activeSession: null,
		restTimer: idleRest
	})
}), {
	name: "projeto-101-v1",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		settings: state.settings,
		workouts: state.workouts,
		posture: state.posture,
		logs: state.logs,
		sessions: state.sessions,
		activeSession: state.activeSession
	}),
	merge: (persisted, current) => {
		const p = persisted ?? {};
		return {
			...current,
			...p,
			settings: {
				...current.settings,
				...p.settings
			},
			workouts: {
				...current.workouts,
				...p.workouts
			},
			posture: p.posture ?? current.posture,
			logs: p.logs ?? {},
			sessions: p.sessions ?? [],
			activeSession: p.activeSession ?? null
		};
	}
}));
//#endregion
export { parseDateKey as C, useAppStore as D, toDateKey as E, weekdayFromDate as O, getDayStatus as S, projectProgressPct as T, formatHours as _, SESSION_TYPE_LABEL as a, formatShortDate as b, WATER_QUICK as c, allProjectDates as d, cn as f, formatDuration as g, daysUntil as h, REST_PRESETS as i, WEEKDAYS as l, countHabitMarks as m, PROJECT_END as n, SKIN_CARE_ITEMS as o, computeStreak as p, PROJECT_START as r, SLEEP_QUICK as s, FOOD_ITEMS as t, WEEKDAY_LABEL as u, formatLongDate as v, projectDayNumber as w, getDayChecks as x, formatMmSs as y };
