import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ChevronLeft, i as EllipsisVertical, n as Plus, o as Check, r as Pencil } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Ce8g5fOc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** One tap of + or −. Cups change only after a full pass through 1..sips. */
function stepSip(state, direction) {
	const n = Math.max(1, Math.trunc(state.sips));
	let position = Math.trunc(state.position);
	let cups = Math.max(0, Math.trunc(state.cups));
	let credited = Boolean(state.credited);
	if (direction > 0) {
		if (position < n) {
			position += 1;
			if (position === n && !credited) {
				cups += 1;
				credited = true;
			}
		} else {
			position = 1;
			credited = false;
			if (n === 1) {
				cups += 1;
				credited = true;
			}
		}
	} else if (position <= 0) return {
		position: 0,
		cups,
		sips: n,
		credited: false
	};
	else if (position === 1) {
		if (cups > 0) {
			position = n;
			cups -= 1;
			credited = true;
		} else {
			position = 0;
			credited = false;
		}
	} else position -= 1;
	return {
		position,
		cups,
		sips: n,
		credited
	};
}
function stepSipBy(state, direction, times) {
	const count = Math.max(1, Math.min(100, Math.trunc(times) || 1));
	let next = state;
	for (let i = 0; i < count; i += 1) next = stepSip(next, direction);
	return next;
}
var STORAGE_KEY = "drink-counter-v1";
var LEGACY_KEYS = ["radix-counter-v2", "radix-counter-v1"];
var DEFAULT_COLOR = "#fffdf8";
var SIP_MIN = 1;
var SIP_MAX = 99;
var THEMES = [
	{
		id: "system",
		label: "系统默认"
	},
	{
		id: "light",
		label: "浅色模式"
	},
	{
		id: "dark",
		label: "深色模式"
	}
];
var PALETTES = [
	{
		id: "paper",
		label: "暖纸"
	},
	{
		id: "wine",
		label: "酒红"
	},
	{
		id: "sea",
		label: "海蓝"
	},
	{
		id: "forest",
		label: "森绿"
	},
	{
		id: "dusk",
		label: "暮紫"
	},
	{
		id: "sand",
		label: "沙金"
	},
	{
		id: "slate",
		label: "雾灰"
	},
	{
		id: "ink",
		label: "松烟"
	}
];
function seedItems() {
	return [
		"A",
		"B",
		"C",
		"D",
		"E"
	].map((name, index) => ({
		id: `seed-${index}`,
		name,
		sips: 6,
		position: 0,
		cups: 0,
		credited: false,
		step: 1,
		color: DEFAULT_COLOR
	}));
}
function nextName(items) {
	const used = new Set(items.map((item) => item.name));
	for (let i = 0; i < 26; i += 1) {
		const letter = String.fromCharCode(65 + i);
		if (!used.has(letter)) return letter;
	}
	let n = 1;
	while (used.has(`对象${n}`)) n += 1;
	return `对象${n}`;
}
function cleanColor(value) {
	return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value) ? value.toLowerCase() : DEFAULT_COLOR;
}
function cleanItem(row, fallbackSips) {
	if (typeof row.id !== "string" || typeof row.name !== "string") return null;
	const name = row.name.trim().slice(0, 16);
	if (!name) return null;
	const rawSips = Number.isInteger(row.sips) ? row.sips : Number.isInteger(row.base) ? row.base : fallbackSips;
	const sips = Math.min(SIP_MAX, Math.max(SIP_MIN, rawSips ?? 6));
	const step = Number.isInteger(row.step) && row.step >= 1 ? Math.min(100, row.step) : 1;
	const position = Number.isInteger(row.position) ? Math.min(sips, Math.max(0, row.position)) : 0;
	const cups = Number.isInteger(row.cups) && row.cups >= 0 ? row.cups : 0;
	const credited = typeof row.credited === "boolean" ? row.credited : position === sips && position > 0;
	return {
		id: row.id,
		name,
		sips,
		position,
		cups,
		credited,
		step,
		color: cleanColor(row.color)
	};
}
function readSaved() {
	try {
		const current = localStorage.getItem(STORAGE_KEY);
		if (current) {
			const data = JSON.parse(current);
			if (!Array.isArray(data.items)) return null;
			return {
				items: data.items.flatMap((item) => {
					const row = cleanItem(item ?? {}, 6);
					return row ? [row] : [];
				}),
				prefs: {
					theme: THEMES.some((theme) => theme.id === data.theme) ? data.theme : "system",
					palette: PALETTES.some((palette) => palette.id === data.palette) ? data.palette : "paper"
				}
			};
		}
		for (const key of LEGACY_KEYS) {
			const legacy = localStorage.getItem(key);
			if (!legacy) continue;
			const data = JSON.parse(legacy);
			if (!Array.isArray(data.items)) continue;
			const fallback = Number.isInteger(data.base) ? data.base : 6;
			return {
				items: data.items.flatMap((item) => {
					const row = cleanItem(item ?? {}, fallback);
					return row ? [row] : [];
				}),
				prefs: {
					theme: "system",
					palette: "paper"
				}
			};
		}
		return null;
	} catch {
		return null;
	}
}
function textOn(color) {
	const hex = color.slice(1);
	return Number.parseInt(hex.slice(0, 2), 16) * 299 + Number.parseInt(hex.slice(2, 4), 16) * 587 + Number.parseInt(hex.slice(4, 6), 16) * 114 > 15e4 ? "#211c16" : "#fff7f3";
}
function blankItem(items) {
	return {
		id: crypto.randomUUID(),
		name: nextName(items),
		sips: 6,
		position: 0,
		cups: 0,
		credited: false,
		step: 1,
		color: DEFAULT_COLOR
	};
}
function RadixCounter() {
	const [items, setItems] = (0, import_react.useState)(seedItems);
	const [prefs, setPrefs] = (0, import_react.useState)({
		theme: "system",
		palette: "paper"
	});
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [page, setPage] = (0, import_react.useState)("home");
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [picker, setPicker] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [dragId, setDragId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const saved = readSaved();
		if (saved) {
			if (saved.items.length) setItems(saved.items);
			setPrefs(saved.prefs);
		}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			items,
			theme: prefs.theme,
			palette: prefs.palette
		}));
	}, [
		items,
		prefs,
		hydrated
	]);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = prefs.theme;
		document.documentElement.dataset.palette = prefs.palette;
	}, [prefs]);
	function stepItem(id, direction) {
		setItems((prev) => prev.map((item) => {
			if (item.id !== id) return item;
			const next = stepSipBy({
				position: item.position,
				cups: item.cups,
				sips: item.sips,
				credited: item.credited
			}, direction, item.step);
			return {
				...item,
				position: next.position,
				cups: next.cups,
				credited: next.credited
			};
		}));
	}
	function beginReorder(event, id) {
		if (event.target.closest("button, a, input")) return;
		const pointerId = event.pointerId;
		const startY = event.clientY;
		let active = false;
		const timer = window.setTimeout(() => {
			active = true;
			setDragId(id);
		}, 420);
		const finish = () => {
			window.clearTimeout(timer);
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", up);
			window.removeEventListener("pointercancel", up);
			if (active) setDragId(null);
		};
		const move = (e) => {
			if (e.pointerId !== pointerId) return;
			if (!active) {
				if (Math.abs(e.clientY - startY) > 8) finish();
				return;
			}
			e.preventDefault();
			const nodes = [...document.querySelectorAll("[data-row-id]")].filter((node) => node.dataset.rowId !== id);
			let to = 0;
			for (const node of nodes) {
				const rect = node.getBoundingClientRect();
				if (e.clientY > rect.top + rect.height / 2) to += 1;
			}
			setItems((prev) => {
				const from = prev.findIndex((item) => item.id === id);
				if (from < 0 || from === to) return prev;
				const next = prev.slice();
				const [row] = next.splice(from, 1);
				next.splice(to, 0, row);
				return next;
			});
		};
		const up = (e) => {
			if (e.pointerId !== pointerId) return;
			finish();
		};
		window.addEventListener("pointermove", move, { passive: false });
		window.addEventListener("pointerup", up);
		window.addEventListener("pointercancel", up);
	}
	const themeLabel = THEMES.find((theme) => theme.id === prefs.theme)?.label ?? "系统默认";
	const paletteLabel = PALETTES.find((palette) => palette.id === prefs.palette)?.label ?? "暖纸";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: page === "home" ? "flex h-dvh flex-col" : "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-bg/95 px-4 py-3 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-lg items-center gap-2",
					children: [page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "min-w-0 flex-1 text-base font-semibold leading-tight",
						children: "何以解忧，唯有一醉解千愁"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "返回",
						onClick: () => {
							setPicker(null);
							setPage("home");
						},
						className: "inline-flex size-11 items-center justify-center rounded-xl border border-line bg-surface text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "min-w-0 flex-1 text-lg font-semibold",
						children: page === "settings" ? "设置" : "关于"
					})] }), page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "菜单",
							"aria-expanded": menuOpen,
							onClick: () => setMenuOpen((open) => !open),
							className: "inline-flex size-11 items-center justify-center rounded-xl border border-line bg-surface text-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EllipsisVertical, { className: "size-5" })
						}), menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute right-0 z-40 mt-2 w-40 overflow-hidden rounded-xl border border-line bg-surface-2 shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "block w-full px-4 py-3 text-left",
									onClick: () => {
										setMenuOpen(false);
										setPage("settings");
									},
									children: "设置"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "block w-full border-t border-line px-4 py-3 text-left",
									onClick: () => {
										setItems((prev) => prev.map((item) => ({
											...item,
											position: 0,
											cups: 0,
											credited: false
										})));
										setMenuOpen(false);
									},
									children: "全部清零"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "block w-full border-t border-line px-4 py-3 text-left",
									onClick: () => {
										setMenuOpen(false);
										setPage("about");
									},
									children: "关于"
								})
							]
						}) : null]
					}) : null]
				})
			}),
			menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "关闭菜单",
				className: "fixed inset-0 z-20 cursor-default",
				onClick: () => setMenuOpen(false)
			}) : null,
			page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex min-h-0 w-full max-w-lg flex-1 flex-col px-4 pb-24 pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: `grid min-h-0 flex-1 gap-2 overflow-y-auto ${dragId ? "touch-none" : ""}`,
					style: { gridAutoRows: `calc((100% - ${Math.max(Math.min(items.length, 7), 1) - 1} * 0.5rem) / ${Math.max(Math.min(items.length, 7), 1)})` },
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "h-full min-h-0",
						"data-row-id": item.id,
						onPointerDown: (event) => beginReorder(event, item.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CounterRow, {
							item,
							dragging: dragId === item.id,
							onStep: (direction) => stepItem(item.id, direction),
							onOpen: () => setEditing({
								item,
								creating: false
							})
						})
					}, item.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "添加",
					onClick: () => setEditing({
						item: blankItem(items),
						creating: true
					}),
					className: "fixed bottom-6 right-5 z-20 inline-flex size-14 items-center justify-center rounded-full bg-accent text-accent-ink shadow-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-7" })
				})]
			}) : null,
			page === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto w-full max-w-lg px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "block w-full border-b border-line py-4 text-left",
					onClick: () => setPicker("theme"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-base",
						children: "主题"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-sm text-muted",
						children: themeLabel
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "block w-full border-b border-line py-4 text-left",
					onClick: () => setPicker("palette"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-base",
						children: "色彩"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-sm text-muted",
						children: paletteLabel
					})]
				})]
			}) : null,
			page === "about" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex min-h-[calc(100vh-4.5rem)] w-full max-w-lg flex-col px-6 pb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 flex-col items-center justify-center text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "about-quote",
						children: "美酒虽好，切勿贪杯"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "about-version mt-3",
						children: "版本号：0.777"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "作者：rody" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["联系方式：", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "mailto:rody777@163.com",
							className: "underline",
							children: "rody777@163.com"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "永远支持单依纯！" })
					]
				})]
			}) : null,
			picker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceMenu, {
				title: picker === "theme" ? "主题" : "色彩",
				options: picker === "theme" ? THEMES : PALETTES,
				current: picker === "theme" ? prefs.theme : prefs.palette,
				onClose: () => setPicker(null),
				onPick: (id) => {
					setPrefs((prev) => picker === "theme" ? {
						...prev,
						theme: id
					} : {
						...prev,
						palette: id
					});
					setPicker(null);
				}
			}) : null,
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemSettings, {
				item: editing.item,
				creating: editing.creating,
				onClose: () => setEditing(null),
				onDelete: () => {
					if (!editing.creating) {
						const id = editing.item.id;
						setItems((prev) => prev.filter((item) => item.id !== id));
					}
					setEditing(null);
				},
				onSave: (next, unify) => {
					setItems((prev) => {
						const applySips = (item) => {
							if (!unify) return item;
							const position = Math.min(item.position, next.sips);
							return {
								...item,
								sips: next.sips,
								position,
								credited: position === next.sips && position > 0
							};
						};
						if (editing.creating) return [...prev.map(applySips), next];
						return prev.map((item) => item.id === editing.item.id ? next : applySips(item));
					});
					setEditing(null);
				}
			}) : null
		]
	});
}
function CounterRow({ item, dragging, onStep, onOpen }) {
	const custom = item.color !== DEFAULT_COLOR;
	const ink = custom ? textOn(item.color) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: `flex h-full w-full flex-col justify-center gap-2 rounded-card border border-line px-3 py-3 ${custom ? "" : "bg-surface-2 text-ink"} ${dragging ? "relative z-10 scale-[1.02] shadow-sm" : ""}`,
		style: custom ? {
			backgroundColor: item.color,
			color: ink
		} : void 0,
		onContextMenu: (event) => event.preventDefault(),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-semibold leading-snug break-words",
			children: item.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "shrink-0 text-xs opacity-70",
					children: [item.sips, "口一杯"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "min-w-16 flex-1 text-center font-mono text-3xl font-semibold leading-none tabular-nums",
					children: [item.cups, "杯"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepButton, {
							label: `${item.name} 减一口`,
							onStep: () => onStep(-1),
							children: "−"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "digit-in inline-block min-w-6 text-center font-mono text-2xl tabular-nums",
							children: item.position
						}, item.position),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepButton, {
							label: `${item.name} 加一口`,
							onStep: () => onStep(1),
							tone: "accent",
							children: "+"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `${item.name} 设置`,
							onClick: onOpen,
							onPointerDown: (event) => event.stopPropagation(),
							className: "inline-flex size-11 items-center justify-center rounded-xl border border-line bg-surface text-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-5" })
						})
					]
				})
			]
		})]
	});
}
function ItemSettings({ item, creating, onClose, onSave, onDelete }) {
	const [name, setName] = (0, import_react.useState)(item.name);
	const [sips, setSips] = (0, import_react.useState)(String(item.sips));
	const [color, setColor] = (0, import_react.useState)(item.color);
	const [initial, setInitial] = (0, import_react.useState)(String(item.position));
	const [step, setStep] = (0, import_react.useState)(String(item.step));
	const [unify, setUnify] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const origin = (0, import_react.useRef)(item);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key === "Escape") onClose();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [onClose]);
	function save() {
		const perCup = Number(sips);
		if (!Number.isInteger(perCup) || perCup < SIP_MIN || perCup > SIP_MAX) {
			setError(`一杯酒喝几口请填 ${SIP_MIN} 到 ${SIP_MAX} 的整数`);
			return;
		}
		const position = Number(initial);
		if (!Number.isInteger(position) || position < 0 || position > perCup) {
			setError("初始数值要在 0 和一杯酒喝几口之间");
			return;
		}
		const inc = Number(step);
		if (!Number.isInteger(inc) || inc < 1) {
			setError("增量请填大于 0 的整数");
			return;
		}
		const previous = origin.current;
		const positionChanged = creating || position !== previous.position;
		const cups = positionChanged ? position === perCup ? 1 : 0 : previous.cups;
		const credited = positionChanged || perCup !== previous.sips ? position === perCup && position > 0 : previous.credited;
		onSave({
			...previous,
			name: name.trim().slice(0, 16) || "未命名",
			sips: perCup,
			position,
			cups,
			credited,
			step: Math.min(100, inc),
			color: cleanColor(color)
		}, unify);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "scrim fixed inset-0 z-40 flex items-end justify-center p-4 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": creating ? "添加" : `${item.name} 设置`,
			className: "max-h-[90vh] w-full max-w-md overflow-y-auto rounded-card bg-surface-2 p-5 shadow-sm",
			onClick: (event) => event.stopPropagation(),
			onSubmit: (event) => {
				event.preventDefault();
				save();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: creating ? "添加" : "设置"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "名称",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								"aria-label": "名称",
								onChange: (event) => setName(event.target.value.slice(0, 16)),
								className: "h-12 w-full rounded-xl border border-line bg-surface px-3 outline-none focus:border-accent"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "一杯酒喝几口",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									inputMode: "numeric",
									"aria-label": "一杯酒喝几口",
									value: sips,
									onChange: (event) => setSips(event.target.value.replace(/[^\d]/g, "").slice(0, 2)),
									className: "h-12 w-24 rounded-xl border border-line bg-surface px-3 text-center font-mono text-lg outline-none focus:border-accent"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: unify,
										onChange: (event) => setUnify(event.target.checked),
										className: "size-5 accent-accent"
									}), "统一标准"]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "颜色",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "color",
								"aria-label": "颜色",
								value: color,
								onChange: (event) => setColor(event.target.value),
								className: "h-12 w-full cursor-pointer rounded-xl border border-line bg-surface"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "初始数值",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "numeric",
								"aria-label": "初始数值",
								value: initial,
								onChange: (event) => setInitial(event.target.value.replace(/[^\d]/g, "").slice(0, 2)),
								className: "h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "增量",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "numeric",
								"aria-label": "增量",
								value: step,
								onChange: (event) => setStep(event.target.value.replace(/[^\d]/g, "").slice(0, 3)),
								className: "h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
							})
						})
					]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-accent",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "h-12 rounded-xl bg-ink font-medium text-surface",
						children: "保存"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onDelete,
						className: "h-12 rounded-xl border border-line font-medium",
						children: "删除"
					})]
				})
			]
		})
	});
}
function ChoiceMenu({ title, options, current, onPick, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "scrim fixed inset-0 z-40 flex items-center justify-center p-6",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": title,
			className: "max-h-[80vh] w-full max-w-sm overflow-y-auto rounded-card border border-line bg-surface-2 p-2 shadow-sm",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 py-2 text-sm text-muted",
				children: title
			}), options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onPick(option.id),
				className: "flex w-full items-center justify-between rounded-xl px-3 py-3 text-left hover:bg-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: option.label }), option.id === current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-accent" }) : null]
			}, option.id))]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-sm text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1",
		children
	})] });
}
function StepButton({ label, onStep, children, tone = "ghost" }) {
	const onStepRef = (0, import_react.useRef)(onStep);
	onStepRef.current = onStep;
	const delayRef = (0, import_react.useRef)(null);
	const repeatRef = (0, import_react.useRef)(null);
	function stop() {
		if (delayRef.current) clearTimeout(delayRef.current);
		if (repeatRef.current) clearInterval(repeatRef.current);
		delayRef.current = null;
		repeatRef.current = null;
	}
	(0, import_react.useEffect)(() => stop, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: `inline-flex size-11 select-none items-center justify-center rounded-xl text-2xl leading-none touch-manipulation ${tone === "accent" ? "bg-accent text-accent-ink" : "border border-line bg-surface text-ink"}`,
		onContextMenu: (event) => event.preventDefault(),
		onPointerDown: (event) => {
			if (event.button !== 0) return;
			event.stopPropagation();
			onStepRef.current();
			try {
				event.currentTarget.setPointerCapture(event.pointerId);
			} catch {}
			stop();
			delayRef.current = setTimeout(() => {
				repeatRef.current = setInterval(() => onStepRef.current(), 70);
			}, 360);
		},
		onPointerUp: stop,
		onPointerCancel: stop,
		children
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadixCounter, {});
}
//#endregion
export { Home as component };
