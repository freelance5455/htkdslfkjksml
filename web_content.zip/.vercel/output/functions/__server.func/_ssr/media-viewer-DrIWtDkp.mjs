import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Trash2, f as Film, n as UserRound, u as Image } from "../_libs/lucide-react.mjs";
import { c as useVault, d as Button, f as cn } from "./router-CboP5aV-.mjs";
import { n as Dialog, o as DialogTitle, r as DialogContent } from "./app-shell-Dk04OjoX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/media-viewer-DrIWtDkp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Thumb({ item, onOpen }) {
	const getBlob = useVault((s) => s.getBlob);
	const [url, setUrl] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let revoke = null;
		let alive = true;
		getBlob(item.id).then((got) => {
			if (!alive || !got) return;
			const blob = got.thumb ?? (item.kind !== "video" ? got.blob : null);
			if (!blob) return;
			revoke = URL.createObjectURL(blob);
			setUrl(revoke);
		});
		return () => {
			alive = false;
			if (revoke) URL.revokeObjectURL(revoke);
		};
	}, [
		getBlob,
		item.id,
		item.kind
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: "group relative aspect-square overflow-hidden rounded-md bg-card text-left shadow-[var(--shadow-border)]",
		children: [
			url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: url,
				alt: "",
				className: "h-full w-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full w-full items-center justify-center text-muted-foreground",
				children: item.kind === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-6" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent opacity-80" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute bottom-1.5 left-1.5 right-1.5 truncate text-xs text-paper",
				children: item.name
			}),
			item.kind === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute left-1.5 top-1.5 rounded-full bg-ink/70 px-1.5 py-0.5 text-xs uppercase tracking-wide text-ivory",
				children: "Video"
			}) : item.kind === "gif" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute left-1.5 top-1.5 rounded-full bg-ink/70 px-1.5 py-0.5 text-xs uppercase tracking-wide text-ivory",
				children: "GIF"
			}) : null
		]
	});
}
function MediaGrid({ items, onOpen, onDelete, onAssign, emptyTitle = "Nothing filed yet", emptyBody = "Add videos, photos, or GIFs. Names like angela.white.mp4 file themselves." }) {
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-dashed border-border px-6 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: emptyTitle
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: emptyBody
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
				item,
				onOpen: () => onOpen(item)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute right-1 top-1 flex flex-col gap-1",
				children: [onAssign ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					className: cn("size-9 bg-ink/50 text-paper hover:bg-ink/80"),
					onClick: (e) => {
						e.stopPropagation();
						onAssign(item);
					},
					"aria-label": `Assign ${item.name}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-3.5" })
				}) : null, onDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					className: cn("size-9 bg-ink/50 text-paper hover:bg-ink/80"),
					onClick: (e) => {
						e.stopPropagation();
						onDelete(item);
					},
					"aria-label": `Delete ${item.name}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
				}) : null]
			})]
		}, item.id))
	});
}
function MediaViewer({ item, onClose }) {
	const getBlob = useVault((s) => s.getBlob);
	const [url, setUrl] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!item) {
			setUrl(null);
			return;
		}
		let revoke = null;
		let alive = true;
		getBlob(item.id).then((got) => {
			if (!alive || !got) return;
			revoke = URL.createObjectURL(got.blob);
			setUrl(revoke);
		});
		return () => {
			alive = false;
			if (revoke) URL.revokeObjectURL(revoke);
		};
	}, [getBlob, item]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: Boolean(item),
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[92dvh] overflow-hidden p-0 sm:max-w-4xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "sr-only",
				children: item?.name ?? "Media"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex max-h-[92dvh] flex-col bg-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-h-0 flex-1 items-center justify-center p-3",
					children: url && item?.kind === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						src: url,
						controls: true,
						autoPlay: true,
						playsInline: true,
						className: "max-h-[80dvh] w-full rounded-md"
					}) : url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: url,
						alt: item?.name ?? "",
						className: "max-h-[80dvh] w-full rounded-md object-contain"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Loading"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate px-4 pb-4 text-sm text-muted-foreground",
					children: item?.name
				})]
			})]
		})
	});
}
//#endregion
export { MediaViewer as n, MediaGrid as t };
