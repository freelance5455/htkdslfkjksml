import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { f as cn } from "./store-CuJQmbYj.mjs";
import { t as Card } from "./card-ML3_y2lP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stat-card-ajAgjbVP.js
var import_jsx_runtime = require_jsx_runtime();
function StatCard({ label, value, hint, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: cn("p-4", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-wide text-muted-foreground uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl font-semibold tabular-nums tracking-tight",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
//#endregion
export { StatCard as t };
