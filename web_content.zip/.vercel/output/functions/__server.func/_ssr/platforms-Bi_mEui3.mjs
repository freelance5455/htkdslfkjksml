//#region node_modules/.nitro/vite/services/ssr/assets/platforms-Bi_mEui3.js
function ensureHttp(raw) {
	const trimmed = raw.trim().replace(/\s+/g, "");
	if (!trimmed) return trimmed;
	if (/^https?:\/\//i.test(trimmed)) return trimmed;
	return `https://${trimmed}`;
}
function parseUrl(raw) {
	try {
		return new URL(ensureHttp(raw));
	} catch {
		return null;
	}
}
function hostOf(u) {
	return u.hostname.replace(/^www\./, "").toLowerCase();
}
function detectPlatform(raw) {
	const u = parseUrl(raw);
	if (!u) return "unknown";
	const host = hostOf(u);
	if (host === "youtu.be" || host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com" || host === "youtube-nocookie.com") return "youtube";
	if (host === "tiktok.com" || host.endsWith(".tiktok.com")) return "tiktok";
	if (host === "instagram.com" || host.endsWith(".instagram.com") || host === "instagr.am") return "instagram";
	if (host === "x.com" || host === "twitter.com" || host === "t.co" || host === "mobile.twitter.com") return "x";
	if (host === "facebook.com" || host.endsWith(".facebook.com") || host === "fb.watch" || host === "fb.com") return "facebook";
	return "unknown";
}
function isYtId(value) {
	return !!value && /^[A-Za-z0-9_-]{11}$/.test(value);
}
function youtubeVideoId(raw) {
	const u = parseUrl(raw);
	if (!u) return null;
	if (hostOf(u) === "youtu.be") {
		const id = u.pathname.split("/").filter(Boolean)[0]?.split("?")[0] ?? "";
		return isYtId(id) ? id : null;
	}
	const v = u.searchParams.get("v");
	if (isYtId(v)) return v;
	return u.pathname.match(/\/(?:shorts|embed|live|v|e|watch)\/([A-Za-z0-9_-]{11})/)?.[1] ?? null;
}
function instagramShortcode(raw) {
	const u = parseUrl(raw);
	if (!u) return null;
	return u.pathname.match(/\/(?:p|reel|reels|tv)\/([A-Za-z0-9_-]+)/)?.[1] ?? null;
}
function needsCanonicalize(raw) {
	const u = parseUrl(raw);
	if (!u) return false;
	const host = hostOf(u);
	const path = u.pathname;
	if (host === "vm.tiktok.com" || host === "vt.tiktok.com" || host === "t.co") return true;
	if (host.endsWith("tiktok.com") && (path.startsWith("/t/") || path.startsWith("/share/"))) return true;
	if ((host.endsWith("instagram.com") || host === "instagr.am") && path.startsWith("/share/")) return true;
	if (host === "l.instagram.com") return true;
	return false;
}
function unsupportedReason(raw) {
	const u = parseUrl(raw);
	if (!u) return "Esse link não parece válido.";
	const platform = detectPlatform(raw);
	const path = u.pathname;
	if (platform === "youtube") {
		if (youtubeVideoId(raw)) return null;
		if (path.startsWith("/@") || path.startsWith("/channel") || path.startsWith("/c/") || path.startsWith("/user/")) return "Cola o link do vídeo, não do canal.";
		if (path.startsWith("/playlist")) return "Playlist inteira não dá — cola o link de um vídeo só.";
		return "Não reconheci o vídeo nesse link do YouTube.";
	}
	if (platform === "instagram") {
		if (instagramShortcode(raw) || path.startsWith("/share/") || path.startsWith("/stories/")) return null;
		if (path === "/" || /^\/[A-Za-z0-9._]+\/?$/.test(path)) return "Cola o link do reel ou do post, não do perfil.";
	}
	if (platform === "tiktok") {
		if (/\/video\/\d+/.test(path) || /\/photo\/\d+/.test(path) || hostOf(u) === "vm.tiktok.com" || hostOf(u) === "vt.tiktok.com" || path.startsWith("/t/")) return null;
		if (path.startsWith("/@") && !path.includes("/video")) return "Cola o link do vídeo, não do perfil.";
	}
	return null;
}
function platformLabel(platform) {
	switch (platform) {
		case "youtube": return "YouTube";
		case "tiktok": return "TikTok";
		case "instagram": return "Instagram";
		case "x": return "X";
		case "facebook": return "Facebook";
		default: return "Link";
	}
}
function normalizeWatchUrl(raw) {
	const platform = detectPlatform(raw);
	if (platform === "youtube") {
		const id = youtubeVideoId(raw);
		if (id) return `https://www.youtube.com/watch?v=${id}`;
	}
	const code = instagramShortcode(raw);
	if (platform === "instagram" && code) {
		const u = parseUrl(raw);
		return !!u && /\/reels?\//.test(u.pathname) ? `https://www.instagram.com/reel/${code}/` : `https://www.instagram.com/p/${code}/`;
	}
	return ensureHttp(raw);
}
//#endregion
export { normalizeWatchUrl as a, unsupportedReason as c, needsCanonicalize as i, youtubeVideoId as l, ensureHttp as n, parseUrl as o, instagramShortcode as r, platformLabel as s, detectPlatform as t };
