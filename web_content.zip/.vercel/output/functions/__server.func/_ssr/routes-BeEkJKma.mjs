import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as House, i as RotateCcw, n as Volume2, o as Pause, s as Music, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BeEkJKma.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ChirpAudio = class {
	ctx = null;
	master = null;
	musicBus = null;
	sfxBus = null;
	noise = null;
	wind = null;
	windGain = null;
	pads = [];
	timer = 0;
	nextNote = 0;
	noteIndex = 0;
	scene = "quiet";
	pendingScene = "menu";
	musicOn = true;
	soundOn = true;
	volume = .85;
	windWanted = false;
	lastFlap = 0;
	wantClick = false;
	scheduling = false;
	unlock() {
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return;
		if (!this.ctx) {
			this.ctx = new AC({ latencyHint: "interactive" });
			this.buildGraph();
		}
		if (this.ctx.state === "suspended") this.ctx.resume().then(() => this.flush());
		else this.flush();
	}
	onVisible() {
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume().then(() => this.flush());
	}
	apply(opts) {
		this.soundOn = opts.soundOn;
		this.musicOn = opts.musicOn;
		this.volume = opts.volume;
		this.applyGains();
		if (!this.musicOn) this.stopMusic();
		else if (this.ctx?.state === "running") this.applyScene(this.pendingScene);
		this.syncWind();
	}
	setVolume(v) {
		this.volume = Math.min(1, Math.max(0, v));
		this.applyGains();
	}
	setSoundOn(on) {
		this.soundOn = on;
		this.applyGains();
		this.syncWind();
	}
	setMusicOn(on) {
		this.musicOn = on;
		if (!on) this.stopMusic();
		else this.applyScene(this.pendingScene);
		this.applyGains();
	}
	syncScene(scene) {
		this.pendingScene = scene;
		if (!this.ctx || this.ctx.state !== "running") return;
		this.applyScene(scene);
	}
	setWind(on) {
		this.windWanted = on;
		this.syncWind();
	}
	click() {
		this.wantClick = true;
		if (this.sfxReady()) {
			this.wantClick = false;
			this.blip(880, .045, .12, "sine");
		}
	}
	flap() {
		if (!this.sfxReady() || !this.ctx) return;
		const now = this.ctx.currentTime;
		if (now - this.lastFlap < .07) return;
		this.lastFlap = now;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = "sine";
		osc.frequency.setValueAtTime(620 + Math.random() * 40, now);
		osc.frequency.exponentialRampToValueAtTime(1240, now + .08);
		gain.gain.setValueAtTime(1e-4, now);
		gain.gain.exponentialRampToValueAtTime(.2, now + .012);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .1);
		osc.connect(gain);
		gain.connect(this.sfxBus);
		osc.start(now);
		osc.stop(now + .11);
		this.noiseBurst(now, 900, .08, .06);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
		};
	}
	score() {
		if (!this.sfxReady() || !this.ctx) return;
		const now = this.ctx.currentTime;
		this.tone(784, now, .09, .14, "triangle");
		this.tone(1174, now + .07, .12, .16, "triangle");
	}
	hit(kind) {
		if (!this.sfxReady() || !this.ctx) return;
		const now = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = "sine";
		const start = kind === "ground" ? 180 : 240;
		osc.frequency.setValueAtTime(start, now);
		osc.frequency.exponentialRampToValueAtTime(55, now + .22);
		gain.gain.setValueAtTime(1e-4, now);
		gain.gain.exponentialRampToValueAtTime(kind === "ground" ? .32 : .26, now + .01);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .28);
		osc.connect(gain);
		gain.connect(this.sfxBus);
		osc.start(now);
		osc.stop(now + .3);
		this.noiseBurst(now, kind === "ground" ? 180 : 320, .22, .18);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
		};
	}
	over() {
		if (!this.sfxReady() || !this.ctx) return;
		const now = this.ctx.currentTime;
		[
			523,
			392,
			311
		].forEach((f, i) => this.tone(f, now + i * .12, .16, .12, "triangle"));
	}
	dispose() {
		this.stopMusic();
		this.stopWind();
		window.clearTimeout(this.timer);
		this.ctx?.close();
		this.ctx = null;
	}
	flush() {
		if (this.wantClick && this.sfxReady()) {
			this.wantClick = false;
			this.blip(880, .045, .12, "sine");
		}
		this.applyScene(this.pendingScene);
		this.syncWind();
	}
	buildGraph() {
		if (!this.ctx) return;
		const ctx = this.ctx;
		this.master = ctx.createGain();
		this.musicBus = ctx.createGain();
		this.sfxBus = ctx.createGain();
		this.musicBus.connect(this.master);
		this.sfxBus.connect(this.master);
		this.master.connect(ctx.destination);
		const seconds = 2;
		this.noise = ctx.createBuffer(1, Math.floor(ctx.sampleRate * seconds), ctx.sampleRate);
		const data = this.noise.getChannelData(0);
		for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
		this.applyGains();
	}
	applyGains() {
		if (!this.ctx || !this.master || !this.musicBus || !this.sfxBus) return;
		const now = this.ctx.currentTime;
		const master = this.volume * this.volume;
		this.master.gain.setTargetAtTime(master, now, .02);
		this.sfxBus.gain.setTargetAtTime(this.soundOn ? 1 : 0, now, .02);
		this.musicBus.gain.setTargetAtTime(this.musicOn ? 1 : 0, now, .03);
	}
	sfxReady() {
		return Boolean(this.soundOn && this.ctx && this.ctx.state === "running" && this.sfxBus);
	}
	applyScene(scene) {
		if (!this.ctx || this.ctx.state !== "running") return;
		if (!this.musicOn) {
			this.scene = scene;
			this.stopMusic();
			return;
		}
		if (scene === "quiet") {
			this.scene = scene;
			this.stopMusic();
			return;
		}
		if (this.scene === scene && this.scheduling) return;
		this.scene = scene;
		this.stopMusic();
		this.startPad(scene);
		this.noteIndex = 0;
		this.nextNote = this.ctx.currentTime + .05;
		this.scheduling = true;
		this.schedule();
	}
	startPad(scene) {
		if (!this.ctx || !this.musicBus) return;
		const freqs = scene === "menu" ? [
			196,
			247,
			392
		] : [
			174,
			220,
			262
		];
		const now = this.ctx.currentTime;
		for (const f of freqs) {
			const osc = this.ctx.createOscillator();
			const gain = this.ctx.createGain();
			osc.type = "sine";
			osc.frequency.value = f;
			gain.gain.setValueAtTime(1e-4, now);
			gain.gain.setTargetAtTime(scene === "menu" ? .018 : .012, now, .4);
			osc.connect(gain);
			gain.connect(this.musicBus);
			osc.start();
			this.pads.push({
				osc,
				gain
			});
		}
	}
	schedule = () => {
		if (!this.scheduling || !this.ctx || !this.musicBus) return;
		const pattern = this.scene === "play" ? PLAY_NOTES : MENU_NOTES;
		const step = this.scene === "play" ? .58 : .42;
		const horizon = this.ctx.currentTime + .35;
		while (this.nextNote < horizon) {
			const freq = pattern[this.noteIndex % pattern.length];
			this.tone(freq, this.nextNote, .34, this.scene === "play" ? .05 : .07, "triangle", true);
			this.nextNote += step;
			this.noteIndex++;
		}
		this.timer = window.setTimeout(this.schedule, 120);
	};
	stopMusic() {
		this.scheduling = false;
		window.clearTimeout(this.timer);
		const ctx = this.ctx;
		const pads = this.pads;
		this.pads = [];
		if (!ctx) return;
		const now = ctx.currentTime;
		for (const pad of pads) try {
			pad.gain.gain.setTargetAtTime(1e-4, now, .05);
			pad.osc.stop(now + .2);
		} catch {}
	}
	syncWind() {
		if (!this.ctx || this.ctx.state !== "running") return;
		if (this.windWanted && this.soundOn) this.ensureWind();
		else this.stopWind();
	}
	ensureWind() {
		if (this.wind || !this.ctx || !this.noise || !this.sfxBus) return;
		const src = this.ctx.createBufferSource();
		src.buffer = this.noise;
		src.loop = true;
		const filter = this.ctx.createBiquadFilter();
		filter.type = "bandpass";
		filter.frequency.value = 480;
		filter.Q.value = .55;
		const gain = this.ctx.createGain();
		gain.gain.setValueAtTime(1e-4, this.ctx.currentTime);
		gain.gain.setTargetAtTime(.04, this.ctx.currentTime, .35);
		src.connect(filter);
		filter.connect(gain);
		gain.connect(this.sfxBus);
		src.start();
		this.wind = src;
		this.windGain = gain;
	}
	stopWind() {
		const wind = this.wind;
		const gain = this.windGain;
		this.wind = null;
		this.windGain = null;
		if (!wind || !this.ctx || !gain) return;
		gain.gain.setTargetAtTime(1e-4, this.ctx.currentTime, .05);
		window.setTimeout(() => {
			try {
				wind.stop();
			} catch {}
		}, 180);
	}
	blip(freq, dur, amp, type) {
		if (!this.ctx) return;
		this.tone(freq, this.ctx.currentTime, dur, amp, type);
	}
	tone(freq, when, dur, amp, type, music = false) {
		if (!this.ctx) return;
		const bus = music ? this.musicBus : this.sfxBus;
		if (!bus) return;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, when);
		gain.gain.setValueAtTime(1e-4, when);
		gain.gain.exponentialRampToValueAtTime(Math.max(2e-4, amp), when + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, when + dur);
		osc.connect(gain);
		gain.connect(bus);
		osc.start(when);
		osc.stop(when + dur + .02);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
		};
	}
	noiseBurst(when, highpass, dur, amp) {
		if (!this.ctx || !this.noise || !this.sfxBus) return;
		const src = this.ctx.createBufferSource();
		src.buffer = this.noise;
		const filter = this.ctx.createBiquadFilter();
		filter.type = "highpass";
		filter.frequency.value = highpass;
		const gain = this.ctx.createGain();
		gain.gain.setValueAtTime(amp, when);
		gain.gain.exponentialRampToValueAtTime(1e-4, when + dur);
		src.connect(filter);
		filter.connect(gain);
		gain.connect(this.sfxBus);
		src.start(when);
		src.stop(when + dur);
		src.onended = () => {
			src.disconnect();
			filter.disconnect();
			gain.disconnect();
		};
	}
};
var MENU_NOTES = [
	262,
	330,
	392,
	494,
	392,
	330,
	294,
	330
];
var PLAY_NOTES = [
	220,
	262,
	330,
	262,
	196,
	247,
	294,
	262
];
var THEMES = [
	{
		sky0: "#8ec8f5",
		sky1: "#f6d7a8",
		sky2: "#f3b98a",
		sun: "#ffe7a3",
		sunCore: "#fffaf0",
		cloud: "#fff7ee",
		hillFar: "#8fb89a",
		hillNear: "#3f8f62",
		grass: "#3e9a5c",
		grassDark: "#2d7a48",
		dirt: "#d7b07a",
		dirtDark: "#8d6843",
		pipe: "#2f9d74",
		pipeDark: "#14634a",
		pipeLite: "#8ae6c8",
		lip: "#1f7a58",
		star: 0,
		sunX: .78,
		sunY: .16,
		night: 0
	},
	{
		sky0: "#4a3278",
		sky1: "#e36b4a",
		sky2: "#ffb067",
		sun: "#ffd0a1",
		sunCore: "#fff1d4",
		cloud: "#ffd0b8",
		hillFar: "#7a4e72",
		hillNear: "#8a4458",
		grass: "#6d8f45",
		grassDark: "#4e6b32",
		dirt: "#c48b62",
		dirtDark: "#7a4e38",
		pipe: "#2a8f6a",
		pipeDark: "#124c3c",
		pipeLite: "#7ddec0",
		lip: "#1b654c",
		star: .15,
		sunX: .5,
		sunY: .58,
		night: .15
	},
	{
		sky0: "#0e1730",
		sky1: "#1b2c5c",
		sky2: "#3d527f",
		sun: "#f4f0dd",
		sunCore: "#ffffff",
		cloud: "#c9d4ea",
		hillFar: "#1a2744",
		hillNear: "#243456",
		grass: "#1d4d4a",
		grassDark: "#143834",
		dirt: "#3a4658",
		dirtDark: "#232a38",
		pipe: "#1f8f86",
		pipeDark: "#0c3d45",
		pipeLite: "#7ee0d2",
		lip: "#146860",
		star: 1,
		sunX: .8,
		sunY: .14,
		night: 1
	}
];
function mixHex(a, b, t) {
	const pa = Number.parseInt(a.slice(1), 16);
	const pb = Number.parseInt(b.slice(1), 16);
	return `rgb(${Math.round((pa >> 16 & 255) + ((pb >> 16 & 255) - (pa >> 16 & 255)) * t)}, ${Math.round((pa >> 8 & 255) + ((pb >> 8 & 255) - (pa >> 8 & 255)) * t)}, ${Math.round((pa & 255) + ((pb & 255) - (pa & 255)) * t)})`;
}
function mixTheme(a, b, t) {
	const m = (x, y) => mixHex(x, y, t);
	const n = (x, y) => x + (y - x) * t;
	return {
		sky0: m(a.sky0, b.sky0),
		sky1: m(a.sky1, b.sky1),
		sky2: m(a.sky2, b.sky2),
		sun: m(a.sun, b.sun),
		sunCore: m(a.sunCore, b.sunCore),
		cloud: m(a.cloud, b.cloud),
		hillFar: m(a.hillFar, b.hillFar),
		hillNear: m(a.hillNear, b.hillNear),
		grass: m(a.grass, b.grass),
		grassDark: m(a.grassDark, b.grassDark),
		dirt: m(a.dirt, b.dirt),
		dirtDark: m(a.dirtDark, b.dirtDark),
		pipe: m(a.pipe, b.pipe),
		pipeDark: m(a.pipeDark, b.pipeDark),
		pipeLite: m(a.pipeLite, b.pipeLite),
		lip: m(a.lip, b.lip),
		star: n(a.star, b.star),
		sunX: n(a.sunX, b.sunX),
		sunY: n(a.sunY, b.sunY),
		night: n(a.night, b.night)
	};
}
/** index wraps across morning → sunset → night. */
function sampleTheme(indexFloat) {
	const n = THEMES.length;
	const wrapped = (indexFloat % n + n) % n;
	const i0 = Math.floor(wrapped) % n;
	const i1 = (i0 + 1) % n;
	return mixTheme(THEMES[i0], THEMES[i1], wrapped - Math.floor(wrapped));
}
var STEP = 1 / 60;
function circleRect(cx, cy, r, x, y, w, h) {
	if (w <= 0 || h <= 0) return false;
	const nx = Math.max(x, Math.min(cx, x + w));
	const ny = Math.max(y, Math.min(cy, y + h));
	const dx = cx - nx;
	const dy = cy - ny;
	return dx * dx + dy * dy < r * r;
}
function hash(n) {
	const x = Math.sin(n * 127.1) * 43758.5453;
	return x - Math.floor(x);
}
var SkyGame = class {
	canvas;
	audio;
	hooks;
	phase = "menu";
	score = 0;
	best;
	newRecord = false;
	announced = false;
	baselineBest;
	pop = 0;
	sig = "";
	cssW = 0;
	cssH = 0;
	dpr = 1;
	stageW = 360;
	stageH = 640;
	offsetX = 0;
	unit = 1;
	groundY = 560;
	birdX = 120;
	birdY = 280;
	vy = 0;
	rot = 0;
	flapAge = 10;
	flapBuffer = 0;
	cooldown = 0;
	autoFlap = false;
	hitStop = 0;
	deathT = 0;
	scroll = 0;
	time = 0;
	theme = 0;
	shake = 0;
	flash = 0;
	pipeSerial = 1;
	pipes = [];
	feathers = [];
	floaters = [];
	clouds = [];
	prevPad = false;
	reduceMotion = false;
	raf = 0;
	last = 0;
	acc = 0;
	ctx2d = null;
	constructor(canvas, audio, hooks, best) {
		this.canvas = canvas;
		this.audio = audio;
		this.hooks = hooks;
		this.best = best;
		this.baselineBest = best;
		this.reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	}
	start() {
		this.ctx2d = this.canvas.getContext("2d");
		this.resize();
		this.emit();
		window.addEventListener("keydown", this.onKey);
		window.addEventListener("pointerdown", this.onPointer);
		window.addEventListener("resize", this.resize);
		document.addEventListener("visibilitychange", this.onVis);
		this.raf = requestAnimationFrame(this.loop);
		window.__skyChirp = {
			flap: () => this.requestFlap(),
			pause: () => this.pause(),
			resume: () => this.resume(),
			state: () => ({
				phase: this.phase,
				score: this.score,
				best: this.best,
				birdY: this.birdY,
				vy: this.vy,
				pipes: this.pipes.length
			})
		};
	}
	stop() {
		cancelAnimationFrame(this.raf);
		window.removeEventListener("keydown", this.onKey);
		window.removeEventListener("pointerdown", this.onPointer);
		window.removeEventListener("resize", this.resize);
		document.removeEventListener("visibilitychange", this.onVis);
		this.audio.dispose();
		if (window.__skyChirp) delete window.__skyChirp;
	}
	beginReady() {
		this.clearRun();
		this.phase = "ready";
		this.birdY = this.stageH * .36;
		this.baselineBest = this.best;
		this.syncAudio();
		this.emit();
	}
	pause() {
		if (this.phase !== "play") return;
		this.phase = "pause";
		this.flapBuffer = 0;
		this.audio.setWind(false);
		this.emit();
	}
	resume() {
		if (this.phase !== "pause") return;
		this.phase = "play";
		this.audio.setWind(true);
		this.emit();
	}
	restart() {
		this.beginReady();
	}
	home() {
		this.clearRun();
		this.phase = "menu";
		this.birdY = this.stageH * .32;
		this.syncAudio();
		this.emit();
	}
	requestFlap() {
		if (this.phase !== "ready" && this.phase !== "play") return;
		this.flapBuffer = .12;
	}
	clearRun() {
		this.score = 0;
		this.pop = 0;
		this.newRecord = false;
		this.announced = false;
		this.pipes = [];
		this.feathers = [];
		this.floaters = [];
		this.vy = 0;
		this.rot = 0;
		this.flapAge = 10;
		this.cooldown = 0;
		this.flapBuffer = 0;
		this.deathT = 0;
		this.hitStop = 0;
		this.shake = 0;
		this.flash = 0;
	}
	resize = () => {
		const parent = this.canvas.parentElement;
		if (!parent) return;
		const cssW = parent.clientWidth;
		const cssH = parent.clientHeight;
		if (cssW < 2 || cssH < 2) return;
		const prevW = this.stageW;
		const prevH = this.stageH;
		this.cssW = cssW;
		this.cssH = cssH;
		this.dpr = Math.min(window.devicePixelRatio || 1, 2);
		this.canvas.width = Math.floor(cssW * this.dpr);
		this.canvas.height = Math.floor(cssH * this.dpr);
		this.stageW = Math.max(280, Math.min(cssW, 560));
		this.stageH = cssH;
		this.offsetX = (cssW - this.stageW) / 2;
		this.unit = this.stageH / 780;
		this.groundY = this.stageH * .86;
		this.birdX = this.stageW * .32;
		if (prevH > 40 && (this.phase === "play" || this.phase === "pause" || this.phase === "dying")) {
			const sy = this.stageH / prevH;
			const sx = this.stageW / prevW;
			this.birdY *= sy;
			this.vy *= sy;
			for (const p of this.pipes) {
				p.x *= sx;
				p.gapY *= sy;
				p.gap *= sy;
			}
		} else if (this.phase === "menu" || this.phase === "ready" || prevH < 40) this.birdY = this.stageH * (this.phase === "menu" ? .32 : .36);
		if (this.clouds.length === 0) this.seedClouds();
	};
	seedClouds() {
		this.clouds = [];
		for (let i = 0; i < 9; i++) this.clouds.push({
			x: Math.random() * this.cssW,
			y: this.cssH * (.06 + i % 5 * .07),
			s: .7 + i % 4 * .28,
			v: 6 + i % 3 * 7,
			a: .42 + i % 3 * .12,
			layer: i % 3
		});
	}
	loop = (now) => {
		const dt = this.last ? Math.min(.05, (now - this.last) / 1e3) : 0;
		this.last = now;
		this.acc += dt;
		let steps = 0;
		while (this.acc >= STEP && steps < 5) {
			this.update(STEP);
			this.acc -= STEP;
			steps++;
		}
		if (steps === 5) this.acc = 0;
		this.draw();
		this.raf = requestAnimationFrame(this.loop);
	};
	update(dt) {
		if (this.stageH < 20) return;
		if (this.pollPad()) {
			if (this.phase === "menu") this.beginReady();
			else if (this.phase === "pause") this.resume();
			else this.requestFlap();
		}
		if (this.phase === "pause") return;
		this.time += dt;
		this.flapAge += dt;
		this.updateTheme(dt);
		this.updateFx(dt);
		if (this.phase === "menu" || this.phase === "ready") {
			const base = this.stageH * (this.phase === "menu" ? .32 : .36);
			this.birdY = base + Math.sin(this.time * 2.3) * 12 * this.unit;
			this.rot = Math.sin(this.time * 2.3) * .1;
			const pulse = Math.sin(this.time * 1.35) > .93;
			if (pulse && !this.autoFlap) this.flapAge = 0;
			this.autoFlap = pulse;
		}
		this.cooldown = Math.max(0, this.cooldown - dt);
		if (this.flapBuffer > 0) {
			this.flapBuffer -= dt;
			if (this.cooldown <= 0 && (this.phase === "ready" || this.phase === "play")) this.doFlap();
		}
		const scrolling = this.phase === "play" || this.phase === "menu" || this.phase === "ready";
		const speed = this.phase === "play" ? this.difficulty().speed : scrolling ? 34 * this.unit : 0;
		if (speed > 0) {
			this.scroll += speed * dt;
			this.driftClouds(speed, dt);
		}
		if (this.phase === "play") {
			this.maybeSpawn();
			for (const p of this.pipes) p.x -= speed * dt;
			if (this.pipes[0] && this.pipes[0].x < -160 * this.unit) this.pipes.shift();
			const g = 2e3 * this.unit;
			this.vy = Math.min(860 * this.unit, this.vy + g * dt);
			this.birdY += this.vy * dt;
			const r = 15 * this.unit;
			if (this.birdY < r + 6) {
				this.birdY = r + 6;
				if (this.vy < 0) this.vy = 0;
			}
			const target = Math.max(-.7, Math.min(1.2, this.vy / (640 * this.unit)));
			this.rot += (target - this.rot) * (1 - Math.exp(-10 * dt));
			this.passPipes();
			const hit = this.hitTest();
			if (hit) this.kill(hit);
		} else if (this.phase === "dying") {
			this.deathT += dt;
			if (this.hitStop > 0) this.hitStop -= dt;
			else {
				const g = 2e3 * this.unit;
				this.vy = Math.min(900 * this.unit, this.vy + g * dt);
				this.birdY += this.vy * dt;
				const r = 16 * this.unit;
				if (this.birdY > this.groundY - r) {
					this.birdY = this.groundY - r;
					if (Math.abs(this.vy) > 40 * this.unit) this.vy *= -.28;
					else this.vy = 0;
				}
				const target = 1.15;
				this.rot += (target - this.rot) * (1 - Math.exp(-4 * dt));
			}
			if (this.deathT > .92) {
				this.phase = "over";
				this.audio.over();
				this.syncAudio();
				this.emit();
			}
		}
	}
	doFlap() {
		if (this.phase === "ready") {
			this.phase = "play";
			this.syncAudio();
			this.maybeSpawn();
		}
		if (this.phase !== "play") return;
		this.vy = -680 * this.unit;
		this.flapAge = 0;
		this.cooldown = .09;
		this.flapBuffer = 0;
		this.audio.flap();
		this.burst(this.birdX - 18 * this.unit, this.birdY, 3, .7);
		this.emit();
	}
	difficulty() {
		const t = Math.min(this.score, 24) / 24;
		const wide = Math.max(1, this.stageW / 420);
		return {
			speed: (142 + t * 108) * this.unit * wide,
			gap: (206 - t * 42) * this.unit,
			spacing: (268 - t * 40) * this.unit
		};
	}
	pipeW() {
		return 64 * this.unit;
	}
	maybeSpawn() {
		const { spacing } = this.difficulty();
		let guard = 0;
		while (guard++ < 3) {
			const last = this.pipes[this.pipes.length - 1];
			if (last && last.x >= this.stageW - spacing) break;
			const x = last ? last.x + spacing : this.stageW + 48 * this.unit;
			this.spawn(x, !last && this.score === 0);
		}
	}
	spawn(x, easy) {
		const lip = 26 * this.unit;
		const margin = 28 * this.unit;
		let gap = this.difficulty().gap;
		if (easy) gap = Math.max(gap, 236 * this.unit);
		const minCenter = margin + gap / 2 + lip;
		const maxCenter = this.groundY - margin - gap / 2 - lip;
		const gapY = easy ? this.stageH * .42 : minCenter + Math.random() * Math.max(0, maxCenter - minCenter);
		this.pipes.push({
			id: this.pipeSerial++,
			x,
			gapY,
			gap,
			scored: false
		});
	}
	passPipes() {
		const w = this.pipeW();
		for (const p of this.pipes) {
			if (p.scored || p.x + w * .5 >= this.birdX) continue;
			p.scored = true;
			this.score += 1;
			this.pop += 1;
			this.audio.score();
			this.floaters.push({
				x: this.birdX,
				y: this.birdY - 40 * this.unit,
				life: .7,
				text: "+1",
				gold: false
			});
			if (this.score > this.best) {
				this.best = this.score;
				this.newRecord = this.score > this.baselineBest;
				if (!this.announced && this.baselineBest > 0 && this.newRecord) {
					this.announced = true;
					this.floaters.push({
						x: this.birdX,
						y: this.birdY - 68 * this.unit,
						life: .95,
						text: "Best!",
						gold: true
					});
				} else if (!this.announced) this.announced = this.newRecord;
			}
			this.emit();
		}
	}
	hitTest() {
		const r = 14.5 * this.unit;
		if (this.birdY + r >= this.groundY) return "ground";
		const w = this.pipeW();
		const lipOver = 8 * this.unit;
		const lipH = 26 * this.unit;
		for (const p of this.pipes) {
			if (p.x > this.birdX + r + lipOver || p.x + w + lipOver < this.birdX - r) continue;
			const gapTop = p.gapY - p.gap / 2;
			const gapBot = p.gapY + p.gap / 2;
			const bodyX = p.x;
			if (circleRect(this.birdX, this.birdY, r, bodyX, 0, w, gapTop - lipH)) return "pipe";
			if (circleRect(this.birdX, this.birdY, r, bodyX - lipOver, gapTop - lipH, w + lipOver * 2, lipH)) return "pipe";
			if (circleRect(this.birdX, this.birdY, r, bodyX - lipOver, gapBot, w + lipOver * 2, lipH)) return "pipe";
			if (circleRect(this.birdX, this.birdY, r, bodyX, gapBot + lipH, w, this.groundY - (gapBot + lipH))) return "pipe";
		}
		return null;
	}
	kill(kind) {
		if (this.phase !== "play") return;
		this.phase = "dying";
		this.deathT = 0;
		this.hitStop = this.reduceMotion ? 0 : .045;
		this.vy = (kind === "ground" ? -280 : -200) * this.unit;
		this.shake = 1;
		this.flash = .85;
		this.flapBuffer = 0;
		this.burst(this.birdX, this.birdY, 14, 1);
		this.audio.hit(kind);
		this.audio.setWind(false);
		this.syncAudio();
		this.emit();
	}
	burst(x, y, n, power) {
		for (let i = 0; i < n; i++) {
			const ang = Math.random() * Math.PI * 2;
			const sp = (40 + Math.random() * 160) * this.unit * power;
			this.feathers.push({
				x,
				y,
				vx: Math.cos(ang) * sp - 30 * this.unit,
				vy: Math.sin(ang) * sp - 40 * this.unit,
				life: .45 + Math.random() * .45,
				max: .9,
				rot: Math.random() * 6,
				spin: (Math.random() - .5) * 8,
				size: (4 + Math.random() * 5) * this.unit,
				cream: Math.random() > .45
			});
		}
		if (this.feathers.length > 48) this.feathers.splice(0, this.feathers.length - 48);
	}
	updateFx(dt) {
		this.flash = Math.max(0, this.flash - dt * 2.4);
		this.shake = Math.max(0, this.shake - dt * 2.1);
		for (const f of this.feathers) {
			f.life -= dt;
			f.vy += 420 * this.unit * dt;
			f.x += f.vx * dt;
			f.y += f.vy * dt;
			f.rot += f.spin * dt;
		}
		this.feathers = this.feathers.filter((f) => f.life > 0);
		for (const floater of this.floaters) {
			floater.life -= dt;
			floater.y -= 36 * this.unit * dt;
		}
		this.floaters = this.floaters.filter((f) => f.life > 0);
	}
	updateTheme(dt) {
		if (this.phase === "menu") {
			this.theme = this.time * .035 % 3;
			return;
		}
		const target = this.score / 7 % 3;
		const max = 3;
		const delta = ((target - this.theme) % max + max) % max;
		this.theme = (this.theme + Math.min(delta, dt * .55)) % max;
	}
	driftClouds(speed, dt) {
		for (const c of this.clouds) {
			c.x -= (c.v + speed * (.12 + c.layer * .1)) * dt;
			if (c.x < -180) c.x = this.cssW + 60 + Math.random() * 80;
		}
	}
	syncAudio() {
		const scene = this.phase === "play" || this.phase === "pause" ? "play" : this.phase === "menu" || this.phase === "ready" ? "menu" : "quiet";
		this.audio.syncScene(scene);
		this.audio.setWind(this.phase === "play");
	}
	pollPad() {
		const pads = navigator.getGamepads?.();
		if (!pads) return false;
		let down = false;
		for (const pad of pads) {
			if (!pad) continue;
			if (pad.buttons[0]?.pressed) down = true;
		}
		const just = down && !this.prevPad;
		this.prevPad = down;
		return just;
	}
	emit() {
		const sig = `${this.phase}|${this.score}|${this.best}|${this.newRecord ? 1 : 0}|${this.pop}`;
		if (sig === this.sig) return;
		this.sig = sig;
		this.hooks.onUi({
			phase: this.phase,
			score: this.score,
			best: this.best,
			newRecord: this.newRecord,
			pop: this.pop
		});
	}
	onKey = (e) => {
		if (e.repeat) return;
		this.audio.unlock();
		if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") {
			e.preventDefault();
			if (this.phase === "menu") this.beginReady();
			else this.requestFlap();
		} else if (e.code === "Escape" || e.code === "KeyP") {
			if (this.phase === "play") this.pause();
			else if (this.phase === "pause") this.resume();
		}
	};
	onPointer = (e) => {
		this.audio.unlock();
		if (e.target?.closest("button, input, label, a, [data-no-flap]")) return;
		if (this.phase === "menu") return;
		e.preventDefault();
		this.requestFlap();
	};
	onVis = () => {
		if (document.hidden) {
			if (this.phase === "play") this.pause();
		} else this.audio.onVisible();
	};
	wingAngle() {
		if (this.flapAge < .2) {
			const t = this.flapAge / .2;
			return -.95 + Math.sin(t * Math.PI) * 1.65;
		}
		if (this.phase === "play" && this.vy > 280 * this.unit) return -1.05;
		return -.4 + Math.sin(this.time * 6.2) * .18;
	}
	draw() {
		const ctx = this.ctx2d;
		if (!ctx || this.cssW < 2) return;
		ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
		const theme = sampleTheme(this.theme);
		const mag = this.reduceMotion ? 0 : this.shake * 8 * this.unit;
		const sx = (Math.random() - .5) * 2 * mag;
		const sy = (Math.random() - .5) * 2 * mag;
		ctx.clearRect(0, 0, this.cssW, this.cssH);
		ctx.save();
		ctx.translate(sx, sy);
		this.drawSky(ctx, theme);
		this.drawClouds(ctx, theme, 0);
		this.drawHills(ctx, theme, true);
		this.drawHills(ctx, theme, false);
		this.drawClouds(ctx, theme, 2);
		this.drawPipes(ctx, theme);
		this.drawGround(ctx, theme);
		this.drawFeathers(ctx);
		this.drawBird(ctx, theme);
		this.drawFloaters(ctx);
		ctx.restore();
		this.drawVignette(ctx, theme);
		if (this.flash > 0) {
			ctx.fillStyle = `rgba(255, 236, 214, ${this.flash * .45})`;
			ctx.fillRect(0, 0, this.cssW, this.cssH);
		}
	}
	drawSky(ctx, theme) {
		const g = ctx.createLinearGradient(0, 0, 0, this.cssH);
		g.addColorStop(0, theme.sky0);
		g.addColorStop(.55, theme.sky1);
		g.addColorStop(1, theme.sky2);
		ctx.fillStyle = g;
		ctx.fillRect(-20, -20, this.cssW + 40, this.cssH + 40);
		if (theme.star > .05) {
			for (let i = 0; i < 36; i++) {
				const x = hash(i * 3.1) * this.cssW;
				const y = hash(i * 8.7) * this.cssH * .55;
				const tw = .45 + .55 * Math.sin(this.time * 2 + i);
				ctx.globalAlpha = theme.star * tw * .85;
				ctx.fillStyle = "#fff8e8";
				ctx.beginPath();
				ctx.arc(x, y, (hash(i) > .8 ? 1.8 : 1.1) * this.unit, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.globalAlpha = 1;
		}
		const sx = this.cssW * theme.sunX;
		const sy = this.cssH * theme.sunY;
		const glow = ctx.createRadialGradient(sx, sy, 8, sx, sy, this.cssH * .48);
		glow.addColorStop(0, theme.sunCore);
		glow.addColorStop(.12, theme.sun);
		glow.addColorStop(1, "rgba(255,255,255,0)");
		ctx.globalAlpha = .9 - theme.night * .35;
		ctx.fillStyle = glow;
		ctx.fillRect(0, 0, this.cssW, this.cssH);
		ctx.globalAlpha = 1;
		ctx.save();
		ctx.translate(sx, sy);
		if (theme.night < .65) {
			ctx.rotate(this.time * .04);
			ctx.globalAlpha = (.14 - theme.night * .12) * (this.reduceMotion ? .4 : 1);
			ctx.fillStyle = theme.sun;
			for (let i = 0; i < 8; i++) {
				ctx.rotate(Math.PI / 8);
				ctx.beginPath();
				ctx.moveTo(0, 0);
				ctx.lineTo(this.cssH * .7, 16);
				ctx.lineTo(this.cssH * .7, -16);
				ctx.fill();
			}
			ctx.globalAlpha = 1;
			const sunR = 36 + (1 - theme.night) * 10;
			const sun = ctx.createRadialGradient(-8, -8, 4, 0, 0, sunR);
			sun.addColorStop(0, "#fffef8");
			sun.addColorStop(.6, theme.sun);
			sun.addColorStop(1, theme.sun);
			ctx.fillStyle = sun;
			ctx.beginPath();
			ctx.arc(0, 0, sunR, 0, Math.PI * 2);
			ctx.fill();
		}
		if (theme.night > .35) {
			ctx.globalAlpha = Math.min(1, (theme.night - .35) / .5);
			ctx.fillStyle = theme.sunCore;
			ctx.beginPath();
			ctx.arc(0, 0, 28, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha *= .95;
			ctx.fillStyle = theme.sky0;
			ctx.beginPath();
			ctx.arc(12, -6, 22, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha = 1;
		}
		ctx.restore();
	}
	drawClouds(ctx, theme, layer) {
		for (const c of this.clouds) {
			if (c.layer !== layer && !(layer === 0 && c.layer === 1)) continue;
			if (layer === 2 && c.layer !== 2) continue;
			if (layer === 0 && c.layer === 2) continue;
			ctx.save();
			ctx.translate(c.x, c.y);
			ctx.scale(c.s * this.unit * 1.35, c.s * this.unit * 1.35);
			ctx.globalAlpha = c.a * (1 - theme.night * .45);
			for (const [px, py, pr] of [
				[
					0,
					0,
					28
				],
				[
					26,
					-8,
					22
				],
				[
					-24,
					-4,
					18
				],
				[
					12,
					8,
					16
				]
			]) {
				const g = ctx.createRadialGradient(px - 6, py - 8, 2, px, py, pr);
				g.addColorStop(0, "#ffffff");
				g.addColorStop(1, theme.cloud);
				ctx.fillStyle = g;
				ctx.beginPath();
				ctx.arc(px, py, pr, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.restore();
		}
		ctx.globalAlpha = 1;
	}
	drawHills(ctx, theme, far) {
		const amp = (far ? 28 : 18) * this.unit;
		const base = this.groundY - (far ? 70 : 28) * this.unit;
		const freq = far ? .008 : .014;
		const parallax = far ? .15 : .32;
		ctx.fillStyle = far ? theme.hillFar : theme.hillNear;
		ctx.beginPath();
		ctx.moveTo(0, this.cssH);
		for (let x = 0; x <= this.cssW; x += 10) {
			const y = base - Math.sin((x + this.scroll * parallax) * freq) * amp - Math.sin((x + this.scroll * parallax) * freq * .37 + 1.2) * amp * .45;
			if (x === 0) ctx.lineTo(0, y);
			else ctx.lineTo(x, y);
		}
		ctx.lineTo(this.cssW, this.cssH);
		ctx.closePath();
		ctx.fill();
	}
	drawPipes(ctx, theme) {
		const w = this.pipeW();
		const lipOver = 8 * this.unit;
		const lipH = 26 * this.unit;
		for (const p of this.pipes) {
			const x = this.offsetX + p.x;
			const gapTop = p.gapY - p.gap / 2;
			const gapBot = p.gapY + p.gap / 2;
			this.drawPipeColumn(ctx, theme, x, 0, w, Math.max(0, gapTop - lipH), "down", p.id);
			this.drawLip(ctx, theme, x - lipOver, gapTop - lipH, w + lipOver * 2, lipH, p.id);
			this.drawLip(ctx, theme, x - lipOver, gapBot, w + lipOver * 2, lipH, p.id + 20);
			this.drawPipeColumn(ctx, theme, x, gapBot + lipH, w, Math.max(0, this.groundY - (gapBot + lipH)), "up", p.id + 3);
			ctx.fillStyle = "rgba(6, 28, 24, 0.55)";
			ctx.beginPath();
			ctx.ellipse(x + w / 2, gapTop - 2 * this.unit, w * .26, 7 * this.unit, 0, 0, Math.PI * 2);
			ctx.fill();
			ctx.beginPath();
			ctx.ellipse(x + w / 2, gapBot + lipH * .15, w * .26, 7 * this.unit, 0, 0, Math.PI * 2);
			ctx.fill();
		}
	}
	drawPipeColumn(ctx, theme, x, y, w, h, _end, id) {
		if (h < 1) return;
		const g = ctx.createLinearGradient(x, 0, x + w, 0);
		g.addColorStop(0, theme.pipeDark);
		g.addColorStop(.22, theme.pipeLite);
		g.addColorStop(.48, theme.pipe);
		g.addColorStop(1, theme.pipeDark);
		ctx.fillStyle = g;
		ctx.fillRect(x, y, w, h);
		ctx.fillStyle = "rgba(255,255,255,0.22)";
		ctx.fillRect(x + w * .18, y, Math.max(3, w * .08), h);
		ctx.fillStyle = "rgba(0,0,0,0.16)";
		ctx.fillRect(x + w * .82, y, w * .18, h);
		ctx.save();
		ctx.beginPath();
		ctx.rect(x, y, w, h);
		ctx.clip();
		for (let i = 0; i < 4; i++) {
			const px = x + 8 * this.unit + hash(id * 5 + i) * (w - 16 * this.unit);
			const py = y + hash(id * 9 + i) * h;
			ctx.fillStyle = "rgba(12, 60, 40, 0.28)";
			ctx.beginPath();
			ctx.ellipse(px, py, 3.2 * this.unit, 2.1 * this.unit, 0, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.restore();
	}
	drawLip(ctx, theme, x, y, w, h, _id) {
		if (h < 1 || y > this.groundY) return;
		const g = ctx.createLinearGradient(x, 0, x + w, 0);
		g.addColorStop(0, theme.pipeDark);
		g.addColorStop(.25, theme.pipeLite);
		g.addColorStop(.7, theme.lip);
		g.addColorStop(1, theme.pipeDark);
		ctx.fillStyle = g;
		roundRect(ctx, x, y, w, h, 8 * this.unit);
		ctx.fill();
		ctx.fillStyle = "rgba(255,255,255,0.28)";
		ctx.fillRect(x + 8 * this.unit, y + 4 * this.unit, w * .18, Math.max(2, h - 8 * this.unit));
		ctx.strokeStyle = "rgba(255, 236, 190, 0.35)";
		ctx.lineWidth = 2;
		roundRect(ctx, x + 1, y + 1, w - 2, h - 2, 7 * this.unit);
		ctx.stroke();
	}
	drawGround(ctx, theme) {
		const y = this.groundY;
		const g = ctx.createLinearGradient(0, y, 0, this.cssH);
		g.addColorStop(0, theme.grass);
		g.addColorStop(.16, theme.dirt);
		g.addColorStop(1, theme.dirtDark);
		ctx.fillStyle = g;
		ctx.fillRect(0, y, this.cssW, this.cssH - y);
		ctx.fillStyle = theme.grassDark;
		ctx.fillRect(0, y, this.cssW, 8 * this.unit);
		ctx.fillStyle = theme.grass;
		const blade = 16 * this.unit;
		const offset = this.scroll % blade;
		ctx.beginPath();
		for (let x = -blade; x < this.cssW + blade; x += blade) {
			const bx = x - offset;
			ctx.moveTo(bx, y);
			ctx.lineTo(bx + 5 * this.unit, y - 12 * this.unit);
			ctx.lineTo(bx + 10 * this.unit, y);
		}
		ctx.fill();
		ctx.globalAlpha = .28;
		ctx.fillStyle = theme.dirtDark;
		for (let i = 0; i < 18; i++) {
			const px = ((i * 97 - this.scroll * .85) % (this.cssW + 30) + 30) % (this.cssW + 30);
			const py = y + 22 * this.unit + i % 5 * 8 * this.unit;
			ctx.beginPath();
			ctx.ellipse(px, py, 4 * this.unit, 2.4 * this.unit, 0, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.globalAlpha = 1;
	}
	drawFeathers(ctx) {
		for (const f of this.feathers) {
			ctx.save();
			ctx.translate(this.offsetX + f.x, f.y);
			ctx.rotate(f.rot);
			ctx.globalAlpha = Math.max(0, f.life / f.max);
			ctx.fillStyle = f.cream ? "#fff1dc" : "#ef7a45";
			ctx.beginPath();
			ctx.ellipse(0, 0, f.size * 1.6, f.size * .55, 0, 0, Math.PI * 2);
			ctx.fill();
			ctx.restore();
		}
		ctx.globalAlpha = 1;
	}
	drawBird(ctx, _theme) {
		const s = 1.22 * this.unit;
		const wing = this.wingAngle();
		const blink = this.time % 3.8 > 3.62;
		ctx.save();
		ctx.translate(this.offsetX + this.birdX, this.birdY);
		ctx.rotate(this.rot);
		ctx.fillStyle = "rgba(90, 40, 20, 0.18)";
		ctx.beginPath();
		ctx.ellipse(0, 16 * s, 14 * s, 4 * s, 0, 0, Math.PI * 2);
		ctx.fill();
		drawWing(ctx, s, wing, true);
		ctx.fillStyle = "#9a3412";
		ctx.beginPath();
		ctx.ellipse(0, 2 * s, 17 * s, 14.2 * s, -.2, 0, Math.PI * 2);
		ctx.fill();
		const body = ctx.createRadialGradient(-6 * s, -4 * s, 2 * s, 0, 2 * s, 18 * s);
		body.addColorStop(0, "#ffd0a6");
		body.addColorStop(.45, "#f4894e");
		body.addColorStop(1, "#e15a32");
		ctx.fillStyle = body;
		ctx.beginPath();
		ctx.ellipse(0, 2 * s, 15.4 * s, 12.6 * s, -.2, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#fff3e0";
		ctx.beginPath();
		ctx.ellipse(2 * s, 6 * s, 8.5 * s, 6.4 * s, .15, 0, Math.PI * 2);
		ctx.fill();
		ctx.save();
		ctx.rotate(.35 + wing * .08);
		ctx.fillStyle = "#c2410c";
		ctx.beginPath();
		ctx.ellipse(-14 * s, 2 * s, 8 * s, 4 * s, .4, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#fff1dc";
		ctx.beginPath();
		ctx.ellipse(-18 * s, 3 * s, 3 * s, 2 * s, .4, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
		const head = ctx.createRadialGradient(4 * s, -12 * s, 1 * s, 6 * s, -8 * s, 12 * s);
		head.addColorStop(0, "#ffe0c2");
		head.addColorStop(1, "#ef7444");
		ctx.fillStyle = "#9a3412";
		ctx.beginPath();
		ctx.arc(6 * s, -8 * s, 10.4 * s, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = head;
		ctx.beginPath();
		ctx.arc(6 * s, -8 * s, 9.2 * s, 0, Math.PI * 2);
		ctx.fill();
		const crestLift = Math.sin(this.time * 8) * .8 * s;
		ctx.fillStyle = "#ff8fab";
		for (let i = 0; i < 3; i++) {
			ctx.beginPath();
			ctx.ellipse(1 * s + i * 3.1 * s, -16.5 * s - i * .6 * s + crestLift, 2 * s, 5 * s, -.7 + i * .38, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.fillStyle = "#f0b429";
		ctx.beginPath();
		ctx.moveTo(13 * s, -10 * s);
		ctx.lineTo(24 * s, -7.2 * s);
		ctx.lineTo(13.5 * s, -5.4 * s);
		ctx.closePath();
		ctx.fill();
		ctx.fillStyle = "#d4922a";
		ctx.beginPath();
		ctx.moveTo(13.2 * s, -7.2 * s);
		ctx.quadraticCurveTo(20 * s, -6.2 * s, 13.2 * s, -4.6 * s);
		ctx.fill();
		ctx.fillStyle = "#fff";
		ctx.beginPath();
		ctx.ellipse(10 * s, -9.5 * s, 4.3 * s, blink ? .7 * s : 4.6 * s, 0, 0, Math.PI * 2);
		ctx.fill();
		if (!blink) {
			ctx.fillStyle = "#3a2418";
			ctx.beginPath();
			ctx.arc(11.2 * s, -9.4 * s, 2.2 * s, 0, Math.PI * 2);
			ctx.fill();
			ctx.fillStyle = "#fff";
			ctx.beginPath();
			ctx.arc(10.4 * s, -10.3 * s, .9 * s, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.fillStyle = "rgba(239, 106, 69, 0.4)";
		ctx.beginPath();
		ctx.ellipse(7.5 * s, -4.5 * s, 2.5 * s, 1.5 * s, 0, 0, Math.PI * 2);
		ctx.fill();
		drawWing(ctx, s, wing, false);
		ctx.strokeStyle = "#e8a317";
		ctx.lineWidth = 1.7 * s;
		ctx.lineCap = "round";
		ctx.beginPath();
		ctx.moveTo(-1 * s, 12 * s);
		ctx.lineTo(-3 * s, 16 * s);
		ctx.moveTo(5 * s, 12.5 * s);
		ctx.lineTo(7 * s, 16.5 * s);
		ctx.stroke();
		ctx.restore();
	}
	drawFloaters(ctx) {
		ctx.textAlign = "center";
		ctx.lineJoin = "round";
		for (const f of this.floaters) {
			ctx.globalAlpha = Math.max(0, Math.min(1, f.life * 1.6));
			ctx.font = `700 ${Math.round(26 * this.unit)}px Fredoka, Trebuchet MS, sans-serif`;
			ctx.lineWidth = 4;
			ctx.strokeStyle = "rgba(27, 36, 48, 0.45)";
			ctx.strokeText(f.text, this.offsetX + f.x, f.y);
			ctx.fillStyle = f.gold ? "#f0b429" : "#fff7ec";
			ctx.fillText(f.text, this.offsetX + f.x, f.y);
		}
		ctx.globalAlpha = 1;
	}
	drawVignette(ctx, theme) {
		const v = ctx.createRadialGradient(this.cssW / 2, this.cssH * .45, this.cssH * .25, this.cssW / 2, this.cssH * .5, this.cssH * .78);
		v.addColorStop(0, "rgba(0,0,0,0)");
		v.addColorStop(1, `rgba(12, 18, 32, ${.16 + theme.night * .32})`);
		ctx.fillStyle = v;
		ctx.fillRect(0, 0, this.cssW, this.cssH);
	}
};
function drawWing(ctx, s, wing, back) {
	ctx.save();
	ctx.translate(back ? -2 * s : 1 * s, 0);
	ctx.rotate(wing);
	const count = back ? 3 : 4;
	for (let i = 0; i < count; i++) {
		const len = (15 - i * 2) * s;
		const wid = (4.6 - i * .35) * s;
		ctx.fillStyle = i % 2 === 0 ? "#c2410c" : "#ea580c";
		ctx.beginPath();
		ctx.ellipse(-2 * s - i * s, 1.5 * s, len, wid, Math.PI * .92 + i * .06, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#ffe7c4";
		ctx.beginPath();
		ctx.ellipse(-2 * s - len * .72, 1.5 * s, wid * .7, wid * .42, Math.PI, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.restore();
}
function roundRect(ctx, x, y, w, h, r) {
	const rr = Math.min(r, w / 2, Math.max(0, h / 2));
	ctx.beginPath();
	ctx.moveTo(x + rr, y);
	ctx.arcTo(x + w, y, x + w, y + h, rr);
	ctx.arcTo(x + w, y + h, x, y + h, rr);
	ctx.arcTo(x, y + h, x, y, rr);
	ctx.arcTo(x, y, x + w, y, rr);
	ctx.closePath();
}
var KEY = "sky-chirp-v1";
var FALLBACK = {
	best: 0,
	soundOn: true,
	musicOn: true,
	volume: .85
};
function loadSettings() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return { ...FALLBACK };
		const p = JSON.parse(raw);
		return {
			best: typeof p.best === "number" && p.best >= 0 ? Math.floor(p.best) : 0,
			soundOn: p.soundOn !== false,
			musicOn: p.musicOn !== false,
			volume: typeof p.volume === "number" ? Math.min(1, Math.max(0, p.volume)) : FALLBACK.volume
		};
	} catch {
		return { ...FALLBACK };
	}
}
function saveSettings(s) {
	try {
		localStorage.setItem(KEY, JSON.stringify({
			v: 1,
			...s
		}));
	} catch {}
}
function SkyChirp() {
	const canvasRef = (0, import_react.useRef)(null);
	const audioRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const settingsRef = (0, import_react.useRef)({
		best: 0,
		soundOn: true,
		musicOn: true,
		volume: .85
	});
	const [phase, setPhase] = (0, import_react.useState)("menu");
	const [score, setScore] = (0, import_react.useState)(0);
	const [best, setBest] = (0, import_react.useState)(null);
	const [newRecord, setNewRecord] = (0, import_react.useState)(false);
	const [pop, setPop] = (0, import_react.useState)(0);
	const [soundOn, setSoundOn] = (0, import_react.useState)(true);
	const [musicOn, setMusicOn] = (0, import_react.useState)(true);
	const [volume, setVolume] = (0, import_react.useState)(.85);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const saved = loadSettings();
		settingsRef.current = saved;
		setBest(saved.best);
		setSoundOn(saved.soundOn);
		setMusicOn(saved.musicOn);
		setVolume(saved.volume);
		const audio = new ChirpAudio();
		audio.apply(saved);
		const game = new SkyGame(canvas, audio, { onUi: (ui) => {
			setPhase(ui.phase);
			setScore(ui.score);
			setPop(ui.pop);
			setNewRecord(ui.newRecord);
			setBest(ui.best);
			if (ui.best !== settingsRef.current.best) {
				settingsRef.current = {
					...settingsRef.current,
					best: ui.best
				};
				saveSettings(settingsRef.current);
			}
		} }, saved.best);
		audioRef.current = audio;
		gameRef.current = game;
		game.start();
		return () => game.stop();
	}, []);
	function persist(partial) {
		settingsRef.current = {
			...settingsRef.current,
			...partial
		};
		saveSettings(settingsRef.current);
	}
	function press(fn) {
		const audio = audioRef.current;
		audio?.unlock();
		audio?.click();
		fn();
	}
	function onPlay() {
		press(() => gameRef.current?.beginReady());
	}
	function onPause() {
		press(() => gameRef.current?.pause());
	}
	function onResume() {
		press(() => gameRef.current?.resume());
	}
	function onRestart() {
		press(() => gameRef.current?.restart());
	}
	function onHome() {
		press(() => gameRef.current?.home());
	}
	function toggleSound() {
		const next = !soundOn;
		const audio = audioRef.current;
		audio?.unlock();
		if (next) {
			audio?.setSoundOn(true);
			audio?.click();
		} else {
			audio?.click();
			audio?.setSoundOn(false);
		}
		setSoundOn(next);
		persist({ soundOn: next });
	}
	function toggleMusic() {
		const next = !musicOn;
		const audio = audioRef.current;
		audio?.unlock();
		audio?.click();
		audio?.setMusicOn(next);
		setMusicOn(next);
		persist({ musicOn: next });
	}
	function onVolume(value) {
		setVolume(value);
		audioRef.current?.unlock();
		audioRef.current?.setVolume(value);
		persist({ volume: value });
	}
	const showHud = phase === "play" || phase === "pause" || phase === "dying";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "game-root",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "game-canvas",
				"aria-label": "Sky Chirp sky"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: phase === "play" ? `Score ${score}` : phase === "over" ? `Game over. Score ${score}` : "Sky Chirp"
			}),
			showHud && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between px-4 pt-[max(0.75rem,env(safe-area-inset-top))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-12" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "score-pop rounded-full bg-ink/40 px-5 py-1 backdrop-blur-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-5xl font-semibold text-cream tabular-nums",
							children: score
						})
					}, pop),
					phase === "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Pause",
						onClick: onPause,
						className: "pointer-events-auto flex size-12 items-center justify-center rounded-full bg-ink/40 text-cream backdrop-blur-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-6" })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-12" })
				]
			}),
			phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-20 flex items-end justify-center px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-in pointer-events-auto w-full max-w-sm rounded-3xl border border-line bg-cream/95 p-6 text-ink shadow-xl backdrop-blur-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-sm font-semibold tracking-wide text-coral",
							children: "A morning flight"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 text-center font-display text-5xl font-semibold leading-tight",
							children: "Sky Chirp"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-center text-mist",
							children: "Tap to flap. Slip through the gates."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-center font-display text-lg",
							children: ["Best ", best ?? "—"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onPlay,
							className: "mt-4 flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-coral font-display text-xl font-semibold text-cream transition active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-6" }), "Play"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								on: soundOn,
								onClick: toggleSound,
								label: "Sound",
								icon: soundOn ? "on" : "off"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								on: musicOn,
								onClick: toggleMusic,
								label: "Music",
								icon: "music"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "volume",
							className: "mt-3 block text-sm font-medium text-mist",
							children: "Volume"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "volume",
							type: "range",
							min: 0,
							max: 1,
							step: .01,
							value: volume,
							"aria-valuetext": `${Math.round(volume * 100)} percent`,
							onChange: (e) => onVolume(Number(e.target.value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-center text-sm text-mist sm:block",
							children: "Space or click also starts"
						})
					]
				})
			}),
			phase === "ready" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-x-0 top-1/2 z-20 flex -translate-y-1/2 justify-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-in rounded-full bg-cream/95 px-6 py-3 text-center text-ink shadow-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-semibold leading-tight",
						children: "Get ready"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mist",
						children: "Tap anywhere to flap"
					})]
				})
			}),
			phase === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				title: "Paused",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onResume,
						className: "flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-coral font-display text-lg font-semibold text-cream transition active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" }), "Resume"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onRestart,
						className: "flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-foam font-display text-lg font-semibold text-ink transition active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-5" }), "Restart"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onHome,
						className: "flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-foam font-display text-lg font-semibold text-ink transition active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "size-5" }), "Home"]
					})
				]
			}),
			phase === "over" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				title: "Game over",
				children: [
					newRecord && score > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "record-in text-center font-display text-lg font-semibold text-coral",
						children: "New record"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-foam px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-wide text-mist",
								children: "Score"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-4xl font-semibold tabular-nums",
								children: score
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-foam px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-wide text-mist",
								children: "Best"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-4xl font-semibold tabular-nums",
								children: best ?? 0
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onRestart,
						className: "flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-coral font-display text-lg font-semibold text-cream transition active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-5" }), "Restart"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onHome,
						className: "flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-foam font-display text-lg font-semibold text-ink transition active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "size-5" }), "Home"]
					})
				]
			})
		]
	});
}
function Toggle({ on, onClick, label, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: `flex h-12 items-center justify-center gap-2 rounded-2xl font-display text-base font-semibold transition active:scale-95 ${on ? "bg-jade text-cream" : "bg-foam text-mist"}`,
		children: [icon === "music" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, { className: "size-5" }) : icon === "on" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }), label]
	});
}
function Modal({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-30 flex items-center justify-center px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 bg-ink/45",
			"data-no-flap": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "card-in relative w-full max-w-sm space-y-3 rounded-3xl border border-line bg-cream p-6 text-ink shadow-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-center font-display text-4xl font-semibold leading-tight",
				children: title
			}), children]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkyChirp, {});
}
//#endregion
export { Home as component };
