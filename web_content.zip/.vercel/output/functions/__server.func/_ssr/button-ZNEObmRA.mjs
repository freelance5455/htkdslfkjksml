import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as cn } from "./router-BlmjsFDF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-ZNEObmRA.js
var import_jsx_runtime = require_jsx_runtime();
function Button({ className, variant = "primary", type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center rounded-md px-4 text-center text-sm font-medium disabled:cursor-not-allowed disabled:opacity-45", variant === "primary" && "bg-accent text-accent-fg", variant === "secondary" && "border border-line bg-surface text-ink", variant === "ghost" && "bg-transparent text-ink", className),
		...props
	});
}
//#endregion
export { Button as t };
