import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Sun, c as Moon, d as ClipboardCheck, f as ChevronUp, g as CalendarDays, h as ChevronDown, i as Trash2, l as Info, m as ChevronLeft, n as Truck, o as Phone, p as ChevronRight, s as Package, t as Video, u as ImagePlus } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D5Y7fgnQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HUB = "কামরাঙ্গীরচর";
var WEEKDAYS = [
	"রবিবার",
	"সোমবার",
	"মঙ্গলবার",
	"বুধবার",
	"বৃহস্পতিবার",
	"শুক্রবার",
	"শনিবার"
];
var MONTHS = [
	"জানুয়ারি",
	"ফেব্রুয়ারি",
	"মার্চ",
	"এপ্রিল",
	"মে",
	"জুন",
	"জুলাই",
	"আগস্ট",
	"সেপ্টেম্বর",
	"অক্টোবর",
	"নভেম্বর",
	"ডিসেম্বর"
];
var BN = "০১২৩৪৫৬৭৮৯";
function bn(n) {
	return String(n).replace(/\d/g, (d) => BN[Number(d)] ?? d);
}
function operationalToday(now = /* @__PURE__ */ new Date()) {
	const d = new Date(now);
	if (d.getHours() < 9) d.setDate(d.getDate() - 1);
	const p = (x) => String(x).padStart(2, "0");
	return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
function pickDate(o) {
	const a = operationalToday();
	return o.dm && o.da === a ? o.dm : a;
}
function fmtCloseDate(s) {
	if (!s) return "";
	const p = s.split("-");
	return bn(`${p[2]}/${p[1]}/${p[0]}`);
}
function fmtCloseTime(s) {
	if (!s) return "";
	const p = s.split(":");
	let h = Number(p[0]);
	const ap = h >= 12 ? "PM" : "AM";
	h = h % 12 || 12;
	return `${bn(`${h}:${p[1]}`)} ${ap}`;
}
function bdate(s) {
	if (!s) return "";
	const p = s.split("-");
	return `${p[2]}-${p[1]}-${p[0].slice(2)}`;
}
function gdateF(s) {
	if (!s) return "";
	const p = s.split("-");
	return `${p[2]}-${p[1]}-${p[0]}`;
}
function g12(s) {
	if (!s) return "";
	const p = s.split(":");
	return `${Number(p[0]) % 12 || 12}:${p[1]}`;
}
function fmtClock(d = /* @__PURE__ */ new Date()) {
	const p = (n) => String(n).padStart(2, "0");
	return bn(`${p(d.getHours())}:${p(d.getMinutes())}`);
}
function fmtOpsDay(s) {
	if (!s) return "";
	const p = s.split("-");
	return `${WEEKDAYS[(/* @__PURE__ */ new Date(`${s}T00:00:00`)).getDay()] ?? ""}, ${bn(Number(p[2]))} ${MONTHS[Number(p[1]) - 1] ?? ""}`;
}
function uid() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
var DEF = [
	["বস্তার শীট এবং গ্রুপে বস্তার হিসাব দেওয়া হয়েছে কি?", true],
	["ডেইলি ট্রিপ সিট কমপ্লিট কি?", true],
	["ইনকামিং ট্রিপ কমপ্লিট হয়েছে?", true],
	["কুরআন শরীফ গেছে কিনা?", false],
	["ট্রাঙ্ক গেছে কি না?", false],
	["হাবে কোন পার্সেল রয়ে গেছে কি? তার ভিডিও।", false],
	["ডেক্সটপ লক করা হয়েছে কি?", false],
	["হাব ক্লোজ এর মেসেজ গ্রুপে দেওয়া হয়েছে কি?", false]
];
function defaultQuestions() {
	return DEF.map(([t, c]) => ({
		id: uid(),
		t,
		c,
		v: ""
	}));
}
function closeReport(s) {
	const lines = ["Hub Close :- " + [
		HUB,
		fmtCloseDate(s.date),
		fmtCloseTime(s.time)
	].filter(Boolean).join(" | "), ""];
	s.qs.forEach((q, i) => {
		if (!q.t.trim()) return;
		const v = q.v === "yes" ? "হ্যাঁ ✅" : q.v === "no" ? "না ❌" : "";
		lines.push(`${q.c ? "🔴⭐ " : ""}${bn(i + 1)}. ${q.t.trim()}`, `= ${v}`, "");
	});
	return lines.join("\n").trim();
}
var BROWS = [
	"Cumilla-1",
	"Cumilla2",
	"Sylhet",
	"Ctg",
	"Ctg2",
	"Bhanga-1",
	"Bhanga-2",
	"Rangpur",
	"Mirpur-1",
	"Mirpur-2",
	"Central-1",
	"Central-2",
	"Central-3",
	"Central-4",
	"Central-5",
	"Savar"
];
function num(v) {
	const n = parseFloat(v ?? "");
	return Number.isNaN(n) ? 0 : n;
}
function bostaTotals(b) {
	let i = 0;
	let o = 0;
	for (const name of BROWS) {
		const x = b.r[name] || {};
		i += num(x.i);
		o += num(x.o);
	}
	return {
		i,
		o
	};
}
function bostaMessages(b) {
	const groups = [
		["Mirpur-1", "Mirpur-2"],
		[
			"Central-1",
			"Central-2",
			"Central-3",
			"Central-4",
			"Central-5"
		],
		["Cumilla-1", "Cumilla2"],
		["Sylhet"],
		["Ctg", "Ctg2"],
		["Bhanga-1", "Bhanga-2"],
		["Rangpur"]
	];
	const sum = (names, k) => names.reduce((n, name) => n + num(b.r[name]?.[k]), 0);
	const ai = groups.map((g) => sum(g, "i"));
	const ao = groups.map((g) => sum(g, "o"));
	const sv = sum(["Savar"], "i");
	const st = num(b.store);
	const d = bdate(b.date);
	const totalIn = ai.reduce((x, y) => x + y, 0) + sv + st;
	const totalOut = ao.reduce((x, y) => x + y, 0);
	return {
		inn: [
			`তারিখ: ${d}`,
			"আজকের কাপড়ের বস্তা এসেছে।",
			`মোট: ${totalIn} বস্তা।`,
			"",
			`মিরপুর — ${ai[0]}`,
			`ফুলফিল — ${ai[1]}`,
			`কুমিল্লা — ${ai[2]}`,
			`সিলেট — ${ai[3]}`,
			`চট্টগ্রাম — ${ai[4]}`,
			`ভাঙ্গা — ${ai[5]}`,
			`রংপুর — ${ai[6]}`,
			`সাভার -- ${sv}`,
			`স্টোর থেকে -- ${st}`
		].join("\n"),
		out: [
			`তারিখ:- ${d}`,
			"আজকে কাপড়ের বস্তা পাঠানো হয়েছে।",
			`মোট: ${totalOut}`,
			"",
			`মিরপুর- ${ao[0]}`,
			`ফুলফিল- ${ao[1]}`,
			`কুমিল্লা- ${ao[2]}`,
			`সিলেট- ${ao[3]}`,
			`চট্টগ্রাম- ${ao[4]}`,
			`ভাঙ্গা- ${ao[5]}`,
			`রংপুর- ${ao[6]}`
		].join("\n")
	};
}
var WAREHOUSES = [
	"Cumilla",
	"Sylhet",
	"Chittagong",
	"Bhanga",
	"Rangpur",
	"Mirpur",
	"Central"
];
var TRIPS = [
	"1st",
	"2nd",
	"3rd",
	"4th",
	"5th",
	"6th",
	"7th",
	"8th",
	"9th",
	"10th"
];
function emptyGari(date = "") {
	return {
		date,
		wh: "",
		no: "",
		dn: "",
		di: "",
		dp: "",
		hn: "",
		hi: "",
		hp: "",
		tin: "",
		tout: "",
		b: "",
		big: "",
		tq: "",
		car: ""
	};
}
function gpair(n, i) {
	const name = (n || "").trim();
	const id = (i || "").trim();
	return name && id ? `${name} / ${id}` : name + id;
}
function gariReport(g) {
	const to = "Kamrangirchar hub to" + (g.wh ? ` ${g.wh} warehouse` + (g.no ? ` ${g.no}` : "") : "");
	return [
		"Date:" + gdateF(g.date),
		to,
		"Driver: " + gpair(g.dn, g.di),
		"Number:" + (g.dp || ""),
		"Helper: " + gpair(g.hn, g.hi),
		"number: " + (g.hp || ""),
		"In: " + g12(g.tin),
		"Out: " + g12(g.tout),
		"Bosta:" + (g.b || ""),
		"Big: " + (g.big || ""),
		"Total Quantity:" + (g.tq || ""),
		"Gari number: " + (g.car || "")
	].join("\n");
}
var PROGRESS = [
	{
		key: "date",
		label: "তারিখ"
	},
	{
		key: "wh",
		label: "গন্তব্য"
	},
	{
		key: "dn+di+dp",
		label: "ড্রাইভার"
	},
	{
		key: "hn+hi+hp",
		label: "হেলপার"
	},
	{
		key: "tin",
		label: "ইন"
	},
	{
		key: "tout",
		label: "আউট"
	},
	{
		key: "b",
		label: "বস্তা"
	},
	{
		key: "big",
		label: "বড়"
	},
	{
		key: "tq",
		label: "মোট"
	},
	{
		key: "car",
		label: "গাড়ি"
	}
];
function fieldDone(g, key) {
	if (key.includes("+")) return key.split("+").every((part) => fieldDone(g, part));
	const v = String(g[key] ?? "").trim();
	if (!v) return false;
	if (key === "dp" || key === "hp") return v.length === 11;
	if (key === "car") return v.length === 7;
	return true;
}
function gariProgress(g) {
	const missing = PROGRESS.filter((item) => !fieldDone(g, item.key));
	const total = PROGRESS.length;
	return {
		done: total - missing.length,
		total,
		missing: missing.map((m) => m.label)
	};
}
function withUpsert(list, n, i, p) {
	const name = (n || "").trim();
	const id = (i || "").trim();
	const phone = (p || "").trim();
	if (!name && !id) return list;
	const idx = list.findIndex((e) => id && e.i === id || !id && name && e.n.toLowerCase() === name.toLowerCase());
	const prev = idx >= 0 ? list[idx] : {
		n: "",
		i: "",
		p: ""
	};
	return [{
		n: name || prev.n,
		i: id || prev.i,
		p: phone || prev.p
	}, ...idx >= 0 ? list.filter((_, j) => j !== idx) : list.slice()];
}
function rememberCar(list, car) {
	if (!car || !/^\d\d-\d{4}$/.test(car)) return list;
	return [car, ...list.filter((c) => c !== car)];
}
function parsePerson(line) {
	let s = ` ${line} `;
	let p = "";
	const m = s.match(/01\d(?:-?\d){8}/);
	if (m) {
		p = m[0].replace(/\D/g, "");
		s = s.replace(m[0], " ");
	}
	const im = s.match(/\d{3,}/);
	let i = "";
	if (im) {
		i = im[0];
		s = s.replace(i, " ");
	}
	return {
		n: s.replace(/[/,\|:–—-]+/g, " ").replace(/\s+/g, " ").trim(),
		i,
		p
	};
}
function addPeople(list, text) {
	let next = list;
	let count = 0;
	for (const ln of text.split("\n")) {
		const q = parsePerson(ln);
		if (q.n || q.i) {
			next = withUpsert(next, q.n, q.i, q.p);
			count += 1;
		}
	}
	return {
		list: next,
		count
	};
}
function addCars(list, text) {
	const next = list.slice();
	let count = 0;
	for (const t of text.split(/[\s,]+/)) {
		const d = t.replace(/\D/g, "");
		if (d.length === 6) {
			const c = `${d.slice(0, 2)}-${d.slice(2)}`;
			if (!next.includes(c)) {
				next.push(c);
				count += 1;
			}
		}
	}
	return {
		list: next,
		count
	};
}
function suggestPeople(list, q) {
	const query = q.trim().toLowerCase();
	return list.map((e) => {
		const nm = e.n.toLowerCase();
		return [!query ? 2 : nm.startsWith(query) ? 0 : nm.includes(query) || e.i.includes(query) || e.p.includes(query) ? 1 : -1, e];
	}).filter((x) => x[0] >= 0).sort((a, b) => a[0] - b[0]).slice(0, 6).map((x) => x[1]);
}
function suggestCars(list, q) {
	const qd = q.replace(/\D/g, "");
	return list.map((c) => {
		const d = c.replace("-", "");
		return [!qd ? 2 : d.startsWith(qd) ? 0 : d.includes(qd) ? 1 : -1, c];
	}).filter((x) => x[0] >= 0).sort((a, b) => a[0] - b[0]).slice(0, 6).map((x) => x[1]);
}
function makeBackup(info, lists) {
	const payload = JSON.stringify({
		v: 1,
		t: Date.now(),
		info,
		lists
	});
	return `HUBBK1:${btoa(unescape(encodeURIComponent(payload)))}`;
}
function parseBackup(raw) {
	const compact = raw.replace(/\s+/g, "");
	if (!compact.startsWith("HUBBK1:")) return {
		ok: false,
		error: "ব্যাকআপ কোড সঠিক নয়"
	};
	try {
		const o = JSON.parse(decodeURIComponent(escape(atob(compact.slice(7)))));
		if (!o || o.v !== 1) return {
			ok: false,
			error: "ব্যাকআপ কোড সঠিক নয়"
		};
		return {
			ok: true,
			info: Array.isArray(o.info) ? o.info : void 0,
			lists: o.lists || {}
		};
	} catch {
		return {
			ok: false,
			error: "কোডটি পড়া যাচ্ছে না, পুরো কোড পেস্ট করুন"
		};
	}
}
function mergeLists(base, incoming) {
	let d = base.d;
	let h = base.h;
	for (const e of [...incoming.d || []].reverse()) d = withUpsert(d, e.n, e.i, e.p);
	for (const e of [...incoming.h || []].reverse()) h = withUpsert(h, e.n, e.i, e.p);
	let c = base.c;
	for (const car of [...incoming.c || []].reverse()) c = [car, ...c.filter((v) => v !== car)];
	return {
		d,
		h,
		c
	};
}
var DT = {
	S: {
		bn: "সুমন",
		d: "Sumon",
		dp: "01736169769",
		da: "",
		h: "Rubel",
		hp: "01923475760",
		ha: ""
	},
	L: {
		bn: "সুলেমান",
		d: "Soleman",
		dp: "01910786706",
		da: "",
		h: "Mojahid",
		hp: "01946374326",
		ha: ""
	},
	B: {
		bn: "বাপ্পি",
		d: "Bappi",
		dp: "01611266878",
		da: "",
		h: "Robiul",
		hp: "01312424921",
		ha: ""
	}
};
var DRIVER_CODES = [
	"S",
	"L",
	"B"
];
var NOVEMBER_2026 = "SB,LB,LS,SB,BL,X,LS,SB,BL,LS,SB,BL,X,LS,SB,BL,LS,SB,BL,X,LS,SB,BL,LS,SB,BL,X,LS,SB,BL".split(",");
function dstep(p) {
	const t = [
		"S",
		"L",
		"B"
	].filter((c) => c !== p[0] && c !== p[1])[0] || p[0];
	return p[1] + t;
}
function dutyMonth(key, store) {
	const s = store[key];
	if (!s) return key === "2026-11" ? NOVEMBER_2026.slice() : null;
	const [ys, ms] = key.split("-");
	const y = Number(ys);
	const m = Number(ms);
	const n = new Date(y, m, 0).getDate();
	const out = [];
	let prev = null;
	for (let d = 1; d <= n; d++) {
		if (new Date(y, m - 1, d).getDay() === 5) {
			out.push("X");
			continue;
		}
		const c = d === 1 ? s.a : d === 2 && s.b ? s.b : prev ? dstep(prev) : dstep(s.a);
		out.push(c);
		prev = c;
	}
	return out;
}
function dutyCode(ds, store) {
	const p = ds.split("-");
	const arr = dutyMonth(`${p[0]}-${p[1]}`, store);
	if (!arr) return null;
	return arr[Number(p[2]) - 1] || null;
}
function nextOpenMonth(store, today = operationalToday()) {
	const t = today.split("-");
	let y = Number(t[0]);
	let m = Number(t[1]);
	for (let i = 0; i < 13; i++) {
		const k = `${y}-${String(m).padStart(2, "0")}`;
		if (!dutyMonth(k, store)) return k;
		m += 1;
		if (m > 12) {
			m = 1;
			y += 1;
		}
	}
	return today.slice(0, 7);
}
var KEYS = {
	check: "hub-close-v2",
	bosta: "hub-bosta-v1",
	gari: "hub-gari-v1",
	lists: "hub-lists-v1",
	info: "hub-info-v1",
	duty: "hub-duty-v1",
	images: "hub-gimg-v1",
	tab: "hub-tab",
	theme: "hub-theme"
};
function readJSON(key) {
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function writeJSON(key, value) {
	try {
		localStorage.setItem(key, JSON.stringify(value));
		return true;
	} catch {
		return false;
	}
}
function asAnswer(v) {
	return v === "yes" || v === "no" ? v : "";
}
function loadChecklist() {
	const blank = () => ({
		date: operationalToday(),
		time: "",
		qs: defaultQuestions()
	});
	const saved = readJSON(KEYS.check);
	if (saved?.qs?.length) return {
		...saved,
		qs: saved.qs.map((q) => ({
			id: q.id || uid(),
			t: q.t || "",
			c: !!q.c,
			v: asAnswer(q.v)
		})),
		date: pickDate(saved)
	};
	const old = readJSON("hub-close-v1");
	if (old?.a && old.a.length === DEF.length) {
		const base = {
			date: old.date || "",
			time: old.time || "",
			qs: DEF.map(([t, c], i) => ({
				id: uid(),
				t,
				c,
				v: asAnswer(old.a?.[i]?.v)
			}))
		};
		return {
			...base,
			date: pickDate(base)
		};
	}
	return blank();
}
function loadBosta() {
	const saved = readJSON(KEYS.bosta);
	if (saved?.r) return {
		...saved,
		store: saved.store || "",
		date: pickDate(saved)
	};
	return {
		date: operationalToday(),
		r: {},
		store: ""
	};
}
function loadGari() {
	const saved = readJSON(KEYS.gari);
	const base = emptyGari(operationalToday());
	if (saved && typeof saved === "object") {
		const merged = {
			...base,
			...saved,
			date: saved.date || ""
		};
		return {
			...merged,
			date: pickDate(merged)
		};
	}
	return base;
}
function loadLists() {
	const saved = readJSON(KEYS.lists);
	if (saved && Array.isArray(saved.d) && Array.isArray(saved.h) && Array.isArray(saved.c)) return saved;
	return {
		d: [],
		h: [],
		c: []
	};
}
function loadInfo() {
	const saved = readJSON(KEYS.info);
	return Array.isArray(saved) ? saved : [];
}
function loadDuty() {
	const saved = readJSON(KEYS.duty);
	return saved && typeof saved === "object" ? saved : {};
}
function loadImages() {
	const saved = readJSON(KEYS.images);
	return saved && typeof saved === "object" ? saved : {};
}
function loadTab() {
	const t = localStorage.getItem(KEYS.tab);
	if (t === "p1" || t === "p2" || t === "p3" || t === "p4" || t === "p5") return t;
	return "p1";
}
function loadTheme() {
	return localStorage.getItem(KEYS.theme) === "light" ? "light" : "dark";
}
async function copyText(text) {
	try {
		if (navigator.clipboard?.writeText) {
			await navigator.clipboard.writeText(text);
			return true;
		}
	} catch {}
	try {
		const ta = document.createElement("textarea");
		ta.value = text;
		ta.setAttribute("readonly", "");
		ta.style.position = "fixed";
		ta.style.opacity = "0";
		document.body.appendChild(ta);
		ta.select();
		const ok = document.execCommand("copy");
		document.body.removeChild(ta);
		return ok;
	} catch {
		return false;
	}
}
function openWhatsApp(text) {
	const a = document.createElement("a");
	a.href = `https://wa.me/?text=${encodeURIComponent(text)}`;
	a.target = "_blank";
	a.rel = "noopener";
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
}
function shrinkImage(file) {
	return new Promise((resolve) => {
		const reader = new FileReader();
		reader.onerror = () => resolve(null);
		reader.onload = () => {
			const img = new Image();
			img.onerror = () => resolve(null);
			img.onload = () => {
				const scale = Math.min(1, 1400 / Math.max(img.width, img.height));
				const canvas = document.createElement("canvas");
				canvas.width = Math.round(img.width * scale);
				canvas.height = Math.round(img.height * scale);
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					resolve(null);
					return;
				}
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				resolve(canvas.toDataURL("image/jpeg", .75));
			};
			img.src = String(reader.result || "");
		};
		reader.readAsDataURL(file);
	});
}
var HubContext = (0, import_react.createContext)(null);
function useHub() {
	const ctx = (0, import_react.use)(HubContext);
	if (!ctx) throw new Error("Hub context missing");
	return ctx;
}
var blankCheck = () => ({
	date: "",
	time: "",
	qs: []
});
function HubProvider({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [tab, setTabState] = (0, import_react.useState)("p1");
	const [theme, setTheme] = (0, import_react.useState)("dark");
	const [checklist, setChecklist] = (0, import_react.useState)(blankCheck);
	const [bosta, setBosta] = (0, import_react.useState)({
		date: "",
		r: {},
		store: ""
	});
	const [gari, setGari] = (0, import_react.useState)(emptyGari());
	const [lists, setLists] = (0, import_react.useState)({
		d: [],
		h: [],
		c: []
	});
	const [info, setInfo] = (0, import_react.useState)([]);
	const [duty, setDuty] = (0, import_react.useState)({});
	const [images, setImages] = (0, import_react.useState)({});
	const [dutyDate, setDutyDate] = (0, import_react.useState)("");
	const [checkEdit, setCheckEdit] = (0, import_react.useState)(false);
	const [infoEdit, setInfoEdit] = (0, import_react.useState)(false);
	const [toast, setToast] = (0, import_react.useState)("");
	const [confirmState, setConfirmState] = (0, import_react.useState)(null);
	const toastTimer = (0, import_react.useRef)(0);
	(0, import_react.useLayoutEffect)(() => {
		const today = operationalToday();
		setChecklist(loadChecklist());
		setBosta(loadBosta());
		setGari(loadGari());
		setLists(loadLists());
		setInfo(loadInfo());
		setDuty(loadDuty());
		setImages(loadImages());
		setTabState(loadTab());
		setTheme(loadTheme());
		setDutyDate(today);
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		writeJSON(KEYS.check, checklist);
	}, [ready, checklist]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		writeJSON(KEYS.bosta, bosta);
	}, [ready, bosta]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		writeJSON(KEYS.gari, gari);
	}, [ready, gari]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		writeJSON(KEYS.lists, lists);
	}, [ready, lists]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		writeJSON(KEYS.info, info);
	}, [ready, info]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		writeJSON(KEYS.duty, duty);
	}, [ready, duty]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		writeJSON(KEYS.images, images);
	}, [ready, images]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(KEYS.tab, tab);
	}, [ready, tab]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(KEYS.theme, theme);
		document.documentElement.dataset.theme = theme;
	}, [ready, theme]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const sync = () => {
			const a = operationalToday();
			const next = (o) => {
				const d = o.dm && o.da === a ? o.dm : a;
				return d === o.date ? o.date : d;
			};
			setChecklist((s) => {
				const d = next(s);
				return d === s.date ? s : {
					...s,
					date: d
				};
			});
			setBosta((s) => {
				const d = next(s);
				return d === s.date ? s : {
					...s,
					date: d
				};
			});
			setGari((s) => {
				const d = next(s);
				return d === s.date ? s : {
					...s,
					date: d
				};
			});
		};
		const id = window.setInterval(sync, 6e4);
		const onVis = () => {
			if (!document.hidden) sync();
		};
		document.addEventListener("visibilitychange", onVis);
		window.addEventListener("focus", sync);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", onVis);
			window.removeEventListener("focus", sync);
		};
	}, [ready]);
	const notify = (message) => {
		setToast(message);
		window.clearTimeout(toastTimer.current);
		toastTimer.current = window.setTimeout(() => setToast(""), 2200);
	};
	const confirm = (message) => new Promise((resolve) => {
		setConfirmState({
			message,
			resolve
		});
	});
	const closeConfirm = (ok) => {
		confirmState?.resolve(ok);
		setConfirmState(null);
	};
	const stamp = (value) => ({
		dm: value,
		da: operationalToday()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HubContext, {
		value: {
			ready,
			tab,
			setTab: setTabState,
			theme,
			toggleTheme: () => setTheme((t) => t === "dark" ? "light" : "dark"),
			checklist,
			checkEdit,
			toggleCheckEdit: () => {
				if (checkEdit) setChecklist((s) => ({
					...s,
					qs: s.qs.filter((q) => q.t.trim())
				}));
				setCheckEdit((v) => !v);
			},
			setCheckDate: (date) => setChecklist((s) => ({
				...s,
				date,
				...stamp(date)
			})),
			setCheckTime: (time) => setChecklist((s) => ({
				...s,
				time
			})),
			setAnswer: (id, v) => setChecklist((s) => ({
				...s,
				qs: s.qs.map((q) => q.id === id ? {
					...q,
					v: q.v === v ? "" : v
				} : q)
			})),
			setQuestionText: (id, t) => setChecklist((s) => ({
				...s,
				qs: s.qs.map((q) => q.id === id ? {
					...q,
					t
				} : q)
			})),
			setQuestionCritical: (id, c) => setChecklist((s) => ({
				...s,
				qs: s.qs.map((q) => q.id === id ? {
					...q,
					c
				} : q)
			})),
			moveQuestion: (id, dir) => setChecklist((s) => {
				const i = s.qs.findIndex((q) => q.id === id);
				const j = i + dir;
				if (i < 0 || j < 0 || j >= s.qs.length) return s;
				const qs = s.qs.slice();
				const a = qs[i];
				qs[i] = qs[j];
				qs[j] = a;
				return {
					...s,
					qs
				};
			}),
			removeQuestion: (id) => setChecklist((s) => ({
				...s,
				qs: s.qs.filter((q) => q.id !== id)
			})),
			addQuestion: () => setChecklist((s) => ({
				...s,
				qs: [...s.qs, {
					id: uid(),
					t: "",
					c: false,
					v: ""
				}]
			})),
			restoreQuestions: () => setChecklist((s) => ({
				...s,
				qs: defaultQuestions()
			})),
			resetChecklist: () => setChecklist((s) => ({
				...s,
				qs: s.qs.map((q) => ({
					...q,
					v: ""
				})),
				dm: "",
				da: "",
				date: operationalToday(),
				time: ""
			})),
			bosta,
			setBostaDate: (date) => setBosta((s) => ({
				...s,
				date,
				...stamp(date)
			})),
			setLane: (name, key, raw) => setBosta((s) => {
				const value = raw.replace(/[^\d]/g, "").slice(0, 6);
				return {
					...s,
					r: {
						...s.r,
						[name]: {
							...s.r[name],
							[key]: value
						}
					}
				};
			}),
			setStore: (raw) => setBosta((s) => ({
				...s,
				store: raw.replace(/[^\d]/g, "").slice(0, 6)
			})),
			resetBosta: () => setBosta({
				date: operationalToday(),
				r: {},
				store: ""
			}),
			gari,
			setGariField: (key, raw) => setGari((s) => {
				if (key === "dp" || key === "hp" || key === "car") return {
					...s,
					[key]: awaitFormat(key, raw)
				};
				if (key === "b" || key === "big" || key === "tq") return {
					...s,
					[key]: raw.replace(/[^\d]/g, "").slice(0, 6)
				};
				if (key === "date") return {
					...s,
					date: raw,
					...stamp(raw)
				};
				return {
					...s,
					[key]: raw
				};
			}),
			setGariCrew: (who, person) => setGari((s) => who === "d" ? {
				...s,
				dn: person.n,
				di: person.i,
				dp: person.p
			} : {
				...s,
				hn: person.n,
				hi: person.i,
				hp: person.p
			}),
			resetGari: () => setGari((s) => ({
				...emptyGari(s.date),
				date: s.date,
				dm: s.dm,
				da: s.da
			})),
			rememberCrew: () => setLists((prev) => ({
				d: withUpsert(prev.d, gari.dn, gari.di, gari.dp),
				h: withUpsert(prev.h, gari.hn, gari.hi, gari.hp),
				c: rememberCar(prev.c, gari.car)
			})),
			lists,
			addBulk: (key, text) => {
				if (key === "c") {
					const result = addCars(lists.c, text);
					if (result.count) setLists((s) => ({
						...s,
						c: result.list
					}));
					return result.count;
				}
				const result = addPeople(key === "d" ? lists.d : lists.h, text);
				if (result.count) setLists((s) => ({
					...s,
					[key]: result.list
				}));
				return result.count;
			},
			removeListItem: (key, index) => setLists((s) => ({
				...s,
				[key]: s[key].filter((_, i) => i !== index)
			})),
			info,
			infoEdit,
			toggleInfoEdit: () => {
				if (infoEdit) setInfo((cards) => cards.filter((c) => c.t.trim() || c.b.trim()));
				setInfoEdit((v) => !v);
			},
			setInfoCard: (index, patch) => setInfo((cards) => cards.map((c, i) => i === index ? {
				...c,
				...patch
			} : c)),
			moveInfo: (index, dir) => setInfo((cards) => {
				const j = index + dir;
				if (j < 0 || j >= cards.length) return cards;
				const next = cards.slice();
				const a = next[index];
				next[index] = next[j];
				next[j] = a;
				return next;
			}),
			removeInfo: (index) => setInfo((cards) => cards.filter((_, i) => i !== index)),
			addInfo: () => setInfo((cards) => [...cards, {
				t: "",
				b: ""
			}]),
			restoreBackup: (raw) => {
				const parsed = parseBackup(raw);
				if (!parsed.ok) return parsed;
				const nextInfo = parsed.info ?? info;
				if (parsed.info) {
					setInfo(parsed.info);
					setInfoEdit(false);
				}
				const nextLists = mergeLists(lists, parsed.lists);
				setLists(nextLists);
				return {
					ok: true,
					summary: `রিস্টোর হয়েছে: Driver ${nextLists.d.length}, Helper ${nextLists.h.length}, Gari ${nextLists.c.length}, Info ${nextInfo.length}`
				};
			},
			duty,
			dutyDate,
			setDutyDate: (value) => setDutyDate(value),
			shiftDuty: (days) => setDutyDate((d) => shiftDateSafe(d, days)),
			jumpToday: () => setDutyDate(operationalToday()),
			saveDutyMonth: (month, a, b) => setDuty((s) => ({
				...s,
				[month]: {
					a,
					b
				}
			})),
			deleteDutyMonth: (month) => {
				if (!duty[month]) return false;
				setDuty((s) => {
					const next = { ...s };
					delete next[month];
					return next;
				});
				return true;
			},
			images,
			setImageFile: async (slot, file) => {
				const data = await shrinkImage(file);
				if (!data) return "ছবি পড়া যায়নি";
				const next = {
					...images,
					[slot]: data
				};
				if (!writeJSON(KEYS.images, next)) return "জায়গা কম, ছবি সেভ হয়নি";
				setImages(next);
				return null;
			},
			clearImage: (slot) => setImages((s) => {
				const next = { ...s };
				delete next[slot];
				return next;
			}),
			toast,
			notify,
			confirm,
			confirmState,
			closeConfirm
		},
		children
	});
}
function awaitFormat(key, raw) {
	if (key === "car") {
		const d = raw.replace(/\D/g, "").slice(0, 6);
		return d.length > 2 ? `${d.slice(0, 2)}-${d.slice(2)}` : d;
	}
	return raw.replace(/\D/g, "").slice(0, 11);
}
function shiftDateSafe(ds, n) {
	const base = ds || operationalToday();
	const d = /* @__PURE__ */ new Date(`${base}T00:00:00`);
	d.setDate(d.getDate() + n);
	const p = (x) => String(x).padStart(2, "0");
	return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonStyles = cva("press inline-flex touch-manipulation items-center justify-center gap-2 rounded-md font-semibold transition-[background-color,color,border-color,opacity] duration-150 disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			primary: "border border-transparent bg-accent text-accent-ink",
			ghost: "border border-line bg-transparent text-ink",
			danger: "border border-no bg-transparent text-no",
			quiet: "border border-transparent bg-transparent text-muted"
		},
		size: {
			md: "h-11 px-4 text-sm",
			lg: "h-12 px-4 text-base",
			sm: "h-9 px-3 text-sm",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonStyles({
			variant,
			size
		}), className),
		...props
	});
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("block", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-medium text-muted",
			children: label
		}), children]
	});
}
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-xl border border-line bg-surface p-4", className),
		children
	});
}
function Choice({ pressed, tone, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		onClick,
		className: cn("press h-12 flex-1 rounded-md border text-base font-semibold transition-[background-color,color,border-color] duration-150", pressed && tone === "yes" && "border-yes bg-yes-bg text-yes", pressed && tone === "no" && "border-no bg-no-bg text-no", !pressed && "border-line bg-transparent text-ink"),
		children
	});
}
function ChecklistTab() {
	const hub = useHub();
	const { checklist: s, checkEdit } = hub;
	const done = s.qs.filter((q) => q.v).length;
	const pct = s.qs.length ? done / s.qs.length * 100 : 0;
	const criticalOpen = s.qs.some((q) => q.c && q.v !== "yes");
	const prevLen = (0, import_react.useRef)(s.qs.length);
	(0, import_react.useEffect)(() => {
		if (checkEdit && s.qs.length > prevLen.current) {
			const inputs = document.querySelectorAll("[data-q-input]");
			inputs[inputs.length - 1]?.focus();
		}
		prevLen.current = s.qs.length;
	}, [s.qs.length, checkEdit]);
	const report = closeReport(s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "সকাল ৯টার আগে আগের দিনের হিসাব থাকে। মেসেজ গ্রুপে যাবে নিচের টেক্সট।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1.5 block text-xs font-medium text-muted",
						children: "তারিখ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "date",
						value: s.date,
						onChange: (e) => hub.setCheckDate(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1.5 block text-xs font-medium text-muted",
						children: "সময়"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "time",
						value: s.time,
						onChange: (e) => hub.setCheckTime(e.target.value)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-[4.5rem] z-10 -mx-4 border-b border-line bg-bg px-4 py-3 md:top-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 overflow-hidden rounded-full bg-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-yes",
						style: { width: `${pct}%` }
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold tabular-nums text-ink",
								children: [
									bn(done),
									"/",
									bn(s.qs.length)
								]
							}),
							" ",
							"উত্তর"
						]
					}), criticalOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-no",
						children: "জরুরি এখনো বাকি"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-yes",
						children: "জরুরি মিলেছে"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: hub.toggleCheckEdit,
					children: checkEdit ? "সম্পাদনা শেষ" : "প্রশ্ন সম্পাদনা"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3",
				children: s.qs.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: cn(q.c && "border-l-4 border-l-no", !checkEdit && q.v === "yes" && "border-yes"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "w-8 shrink-0 font-semibold tabular-nums text-muted",
							children: [bn(i + 1), "."]
						}), checkEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"data-q-input": true,
							className: "field",
							value: q.t,
							placeholder: "প্রশ্ন লিখুন",
							"aria-label": `প্রশ্ন ${bn(i + 1)}`,
							onChange: (e) => hub.setQuestionText(q.id, e.target.value)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold",
							children: [q.t, q.c ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs font-semibold text-no",
								children: "জরুরি"
							}) : null]
						})]
					}), checkEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mr-auto flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									className: "size-4 accent-accent",
									checked: q.c,
									onChange: (e) => hub.setQuestionCritical(q.id, e.target.checked)
								}), "জরুরি"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "উপরে নিন",
								disabled: i === 0,
								onClick: () => hub.moveQuestion(q.id, -1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "নিচে নিন",
								disabled: i === s.qs.length - 1,
								onClick: () => hub.moveQuestion(q.id, 1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								size: "icon",
								"aria-label": "মুছুন",
								onClick: async () => {
									if (await hub.confirm("এই প্রশ্নটি মুছে ফেলবেন?")) hub.removeQuestion(q.id);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							pressed: q.v === "yes",
							tone: "yes",
							onClick: () => hub.setAnswer(q.id, "yes"),
							children: "হ্যাঁ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							pressed: q.v === "no",
							tone: "no",
							onClick: () => hub.setAnswer(q.id, "no"),
							children: "না"
						})]
					})]
				}, q.id))
			}),
			checkEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "lg",
					className: "w-full border-dashed",
					onClick: hub.addQuestion,
					children: "নতুন প্রশ্ন যোগ করুন"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mx-auto text-sm text-muted underline",
					onClick: async () => {
						if (await hub.confirm("সব প্রশ্ন মুছে আগের ৮টি প্রশ্ন ফিরিয়ে আনবেন?")) hub.restoreQuestions();
					},
					children: "আগের ৮টি প্রশ্ন ফিরিয়ে আনুন"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-2 sm:grid-cols-[1fr_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: async () => {
						const ok = await copyText(report);
						hub.notify(ok ? "কপি হয়েছে" : "মেসেজটি সিলেক্ট করে কপি করুন");
					},
					children: "হাব ক্লোজ মেসেজ কপি করুন"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "lg",
					onClick: async () => {
						if (await hub.confirm("সব উত্তর মুছে নতুন চেকলিস্ট শুরু করবেন? (প্রশ্নগুলো থাকবে)")) hub.resetChecklist();
					},
					children: "নতুন করুন"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-muted",
				children: "গ্রুপে যাবে"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 whitespace-pre-wrap break-words font-sans text-sm leading-relaxed",
				children: report
			})] })] })
		]
	});
}
function BostaTab() {
	const hub = useHub();
	const b = hub.bosta;
	const totals = bostaTotals(b);
	const msgs = bostaMessages(b);
	const copy = async (text) => {
		const ok = await copyText(text);
		hub.notify(ok ? "কপি হয়েছে" : "মেসেজটি সিলেক্ট করে কপি করুন");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "লেন অনুযায়ী ইন ও আউট। নিচের মেসেজে স্টোর যোগ হয়, টেবিলের মোটে শুধু লেন।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block max-w-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1.5 block text-xs font-medium text-muted",
					children: "তারিখ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					type: "date",
					value: b.date,
					onChange: (e) => hub.setBostaDate(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lanes px-1 pb-2 text-xs font-semibold text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "লেন" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right",
							children: "ইন"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right",
							children: "আউট"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col",
					children: [
						BROWS.map((name) => {
							const row = b.r[name] || {};
							const quiet = !row.i && !row.o;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("lanes border-t border-line py-1.5", quiet && "text-muted"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate text-sm font-medium",
										children: name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field h-11 text-right tabular-nums",
										inputMode: "numeric",
										"aria-label": `${name} in`,
										value: row.i || "",
										onChange: (e) => hub.setLane(name, "i", e.target.value)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field h-11 text-right tabular-nums",
										inputMode: "numeric",
										"aria-label": `${name} out`,
										value: row.o || "",
										onChange: (e) => hub.setLane(name, "o", e.target.value)
									})
								]
							}, name);
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lanes border-t border-line py-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: "Store in"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field h-11 text-right tabular-nums",
									inputMode: "numeric",
									"aria-label": "Store in",
									value: b.store,
									onChange: (e) => hub.setStore(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lanes border-t-2 border-ink py-3 text-base font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "মোট" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-right tabular-nums",
									children: totals.i
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-right tabular-nums",
									children: totals.o
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "lg",
				onClick: async () => {
					if (await hub.confirm("সব সংখ্যা মুছে নতুন দিন শুরু করবেন?")) hub.resetBosta();
				},
				children: "নতুন করুন"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Message, {
				title: "হাবে বস্তা এসেছে",
				text: msgs.inn,
				onCopy: () => copy(msgs.inn)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Message, {
				title: "হাব থেকে বস্তা পাঠানো হয়েছে",
				text: msgs.out,
				onCopy: () => copy(msgs.out)
			})
		]
	});
}
function Message({ title, text, onCopy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-between gap-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: title
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-3 w-full",
			size: "lg",
			onClick: onCopy,
			children: "কপি করুন"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mt-3 whitespace-pre-wrap break-words rounded-md bg-elevated p-3 font-sans text-sm leading-relaxed",
			children: text
		})
	] });
}
function GariTab() {
	const hub = useHub();
	const g = hub.gari;
	const progress = gariProgress(g);
	const tone = progress.done >= progress.total ? "ok" : progress.done === progress.total - 1 ? "near" : "bad";
	const [video, setVideo] = (0, import_react.useState)(null);
	const [viewer, setViewer] = (0, import_react.useState)(null);
	const img1 = (0, import_react.useRef)(null);
	const img2 = (0, import_react.useRef)(null);
	const vid = (0, import_react.useRef)(null);
	const report = gariReport(g);
	const clearVideo = () => {
		setVideo((current) => {
			if (current) URL.revokeObjectURL(current.url);
			return null;
		});
	};
	const onImage = async (slot, file) => {
		if (!file) return;
		const err = await hub.setImageFile(slot, file);
		if (err) hub.notify(err);
	};
	const copy = async () => {
		hub.rememberCrew();
		const ok = await copyText(report);
		hub.notify(ok ? "কপি হয়েছে" : "কপি করা যায়নি");
	};
	const send = async () => {
		hub.rememberCrew();
		const ok = await copyText(report);
		if (video) {
			const shareData = {
				files: [new File([video.file], video.file.name || "video.mp4", { type: video.file.type || "video/mp4" })],
				text: report
			};
			if (navigator.share) try {
				await navigator.share(shareData);
			} catch (e) {
				if (!(e instanceof Error) || e.name !== "AbortError") hub.notify("মেসেজ কপি হয়েছে — WhatsApp-এ ভিডিও বেছে ক্যাপশনে পেস্ট করুন");
			}
			else hub.notify("মেসেজ কপি হয়েছে — WhatsApp-এ ভিডিও বেছে ক্যাপশনে পেস্ট করুন");
			return;
		}
		if (!ok) hub.notify("কপি করা যায়নি");
		if (navigator.share) try {
			await navigator.share({ text: report });
		} catch (e) {
			if (!(e instanceof Error) || e.name !== "AbortError") openWhatsApp(report);
		}
		else openWhatsApp(report);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "কপি করলে ড্রাইভার, হেলপার আর গাড়ির নম্বর তালিকায় থেকে যায়।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Date",
						className: "col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "date",
							value: g.date,
							onChange: (e) => hub.setGariField("date", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Kamrangirchar hub to",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: g.wh,
							onChange: (v) => hub.setGariField("wh", v),
							options: WAREHOUSES
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Trip no.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: g.no,
							onChange: (v) => hub.setGariField("no", v),
							options: TRIPS
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "col-span-2 mt-1 text-sm font-semibold",
						children: "Driver"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonInput, {
						label: "Name",
						value: g.dn,
						people: hub.lists.d,
						onChange: (v) => hub.setGariField("dn", v),
						onPick: (p) => hub.setGariCrew("d", p)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonInput, {
						label: "ID",
						value: g.di,
						people: hub.lists.d,
						align: "end",
						inputMode: "numeric",
						onChange: (v) => hub.setGariField("di", v),
						onPick: (p) => hub.setGariCrew("d", p)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Number",
						className: "col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "numeric",
							maxLength: 11,
							value: g.dp,
							onChange: (e) => hub.setGariField("dp", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "col-span-2 mt-1 text-sm font-semibold",
						children: "Helper"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonInput, {
						label: "Name",
						value: g.hn,
						people: hub.lists.h,
						onChange: (v) => hub.setGariField("hn", v),
						onPick: (p) => hub.setGariCrew("h", p)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonInput, {
						label: "ID",
						value: g.hi,
						people: hub.lists.h,
						align: "end",
						inputMode: "numeric",
						onChange: (v) => hub.setGariField("hi", v),
						onPick: (p) => hub.setGariCrew("h", p)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Number",
						className: "col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "numeric",
							maxLength: 11,
							value: g.hp,
							onChange: (e) => hub.setGariField("hp", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "col-span-2 mt-1 text-sm font-semibold",
						children: "Gari"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "In time",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "time",
							value: g.tin,
							onChange: (e) => hub.setGariField("tin", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Out time",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "time",
							value: g.tout,
							onChange: (e) => hub.setGariField("tout", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bosta",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field text-right tabular-nums",
							inputMode: "numeric",
							value: g.b,
							onChange: (e) => hub.setGariField("b", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Big",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field text-right tabular-nums",
							inputMode: "numeric",
							value: g.big,
							onChange: (e) => hub.setGariField("big", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Total Quantity (নিজে লিখুন)",
						className: "col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field text-right tabular-nums",
							inputMode: "numeric",
							value: g.tq,
							onChange: (e) => hub.setGariField("tq", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarField, {})
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mx-auto flex w-fit flex-col items-center rounded-full border px-4 py-2 text-center", tone === "ok" && "border-yes bg-yes-bg text-yes", tone === "near" && "border-warn bg-warn-bg text-warn", tone === "bad" && "border-no bg-no-bg text-no"),
				role: "status",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
					className: "tabular-nums",
					children: [
						bn(progress.done),
						"/",
						bn(progress.total)
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium",
					children: progress.missing.length ? `বাকি: ${progress.missing.join(", ")}` : "সব ঘর পূরণ হয়েছে"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: copy,
					children: "কপি করুন"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "lg",
					onClick: async () => {
						if (await hub.confirm("সব তথ্য মুছে নতুন গাড়ির জন্য শুরু করবেন? (তারিখ থাকবে)")) {
							hub.resetGari();
							clearVideo();
						}
					},
					children: "নতুন গাড়ি"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "w-full",
				onClick: send,
				children: "WhatsApp-এ পাঠান"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-muted",
				children: "মেসেজ"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 whitespace-pre-wrap break-words font-sans text-sm leading-relaxed",
				children: report
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-sm font-semibold",
					children: "গাড়ির ছবি"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageSlot, {
						n: "1",
						src: hub.images["1"],
						onAdd: () => img1.current?.click(),
						onClear: () => hub.clearImage("1"),
						onOpen: () => hub.images["1"] && setViewer(hub.images["1"])
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageSlot, {
						n: "2",
						src: hub.images["2"],
						onAdd: () => img2.current?.click(),
						onClear: () => hub.clearImage("2"),
						onOpen: () => hub.images["2"] && setViewer(hub.images["2"])
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: img1,
					hidden: true,
					type: "file",
					accept: "image/*",
					onChange: (e) => {
						const file = e.target.files?.[0];
						e.target.value = "";
						onImage("1", file);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: img2,
					hidden: true,
					type: "file",
					accept: "image/*",
					onChange: (e) => {
						const file = e.target.files?.[0];
						e.target.value = "";
						onImage("2", file);
					}
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-sm font-semibold",
					children: "ভিডিও"
				}),
				video ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						className: "max-h-64 w-full rounded-lg bg-ink",
						src: video.url,
						controls: true,
						playsInline: true,
						preload: "metadata"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-center text-xs text-muted",
						children: [
							video.name,
							" · ",
							(video.size / 1048576).toFixed(1),
							" MB"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => vid.current?.click(),
							children: "বদলান"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: clearVideo,
							children: "মুছুন"
						})]
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => vid.current?.click(),
					className: "press flex h-28 w-full flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-subtle text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-5" }), "ভিডিও যোগ করুন"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: vid,
					hidden: true,
					type: "file",
					accept: "video/*",
					onChange: (e) => {
						const file = e.target.files?.[0];
						e.target.value = "";
						if (!file) return;
						clearVideo();
						setVideo({
							file,
							url: URL.createObjectURL(file),
							name: file.name,
							size: file.size
						});
					}
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Directory, {}),
			viewer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 overflow-auto bg-ink",
				role: "dialog",
				"aria-modal": "true",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "fixed top-[calc(env(safe-area-inset-top)+8px)] right-3 z-10 rounded-md bg-surface px-4 py-2 text-sm font-semibold text-ink",
					onClick: () => setViewer(null),
					children: "বন্ধ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: viewer,
					alt: "",
					className: "w-full"
				})]
			}) : null
		]
	});
}
function ImageSlot({ n, src, onAdd, onClear, onOpen }) {
	if (!src) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onAdd,
		className: "press flex h-36 flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-subtle text-sm font-semibold",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" }),
			"ছবি ",
			bn(n)
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: onOpen,
		className: "block w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: `ছবি ${bn(n)}`,
			className: "h-44 w-full rounded-lg border border-line bg-surface object-contain"
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 grid grid-cols-2 gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "sm",
			onClick: onAdd,
			children: "বদলান"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "danger",
			size: "sm",
			onClick: onClear,
			children: "মুছুন"
		})]
	})] });
}
function Select({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		className: "field",
		value,
		onChange: (e) => onChange(e.target.value),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			children: "—"
		}), options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: o }, o))]
	});
}
function PersonInput({ label, value, people, onChange, onPick, align, inputMode }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const items = suggestPeople(people, value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				value,
				autoComplete: "off",
				inputMode,
				onChange: (e) => onChange(e.target.value),
				onFocus: () => setOpen(true),
				onBlur: () => window.setTimeout(() => setOpen(false), 160)
			})
		}), open && items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("sug", align === "end" && "end"),
			role: "listbox",
			children: items.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "block w-full border-b border-line px-3 py-2 text-left last:border-b-0",
				onMouseDown: (ev) => ev.preventDefault(),
				onClick: () => {
					onPick(e);
					setOpen(false);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block text-sm font-medium",
					children: [e.n, e.i ? ` / ${e.i}` : ""]
				}), e.p ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted",
					children: e.p
				}) : null]
			}, `${e.n}-${e.i}-${i}`))
		}) : null]
	});
}
function CarField() {
	const hub = useHub();
	const [open, setOpen] = (0, import_react.useState)(false);
	const items = suggestCars(hub.lists.c, hub.gari.car);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label: "Gari number",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field tabular-nums",
			inputMode: "numeric",
			placeholder: "12-3456",
			maxLength: 7,
			value: hub.gari.car,
			autoComplete: "off",
			onChange: (e) => hub.setGariField("car", e.target.value),
			onFocus: () => setOpen(true),
			onBlur: () => window.setTimeout(() => setOpen(false), 160)
		})
	}), open && items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sug",
		role: "listbox",
		children: items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "block w-full border-b border-line px-3 py-2 text-left text-sm font-medium tabular-nums last:border-b-0",
			onMouseDown: (ev) => ev.preventDefault(),
			onClick: () => {
				hub.setGariField("car", c);
				setOpen(false);
			},
			children: c
		}, c))
	}) : null] });
}
function Directory() {
	const hub = useHub();
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "flex w-full items-center justify-between text-left font-semibold",
		onClick: () => setOpen((v) => !v),
		children: ["সেভ করা তালিকা", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium text-muted",
			children: open ? "বন্ধ" : "খুলুন"
		})]
	}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "কপি করলে নিজে সেভ হয়। একসাথে যোগ করতে প্রতি লাইনে একজন লিখুন।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bulk, {
				keyName: "d",
				title: "Driver",
				hint: "Name / ID / Number",
				count: hub.lists.d.length
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bulk, {
				keyName: "h",
				title: "Helper",
				hint: "Name / ID / Number",
				count: hub.lists.h.length
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bulk, {
				keyName: "c",
				title: "Gari number",
				hint: "12-3456",
				count: hub.lists.c.length
			})
		]
	}) : null] });
}
function Bulk({ keyName, title, hint, count }) {
	const hub = useHub();
	const [text, setText] = (0, import_react.useState)("");
	const rows = hub.lists[keyName];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
			className: "text-sm font-semibold",
			children: [
				title,
				" (",
				count,
				")"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "field mt-2",
			rows: 3,
			value: text,
			placeholder: keyName === "c" ? `প্রতি লাইনে বা কমা দিয়ে: ${hint}` : `প্রতি লাইনে একজন: ${hint}`,
			"aria-label": `${title} যোগ করুন`,
			onChange: (e) => setText(e.target.value)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-2",
			size: "sm",
			onClick: () => {
				const n = hub.addBulk(keyName, text);
				if (n) {
					setText("");
					hub.notify(`${n}টি যোগ হয়েছে`);
				}
			},
			children: "যোগ করুন"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 max-h-44 overflow-auto",
			children: rows.map((entry, idx) => {
				const label = typeof entry === "string" ? entry : `${entry.n}${entry.i ? ` / ${entry.i}` : ""}${entry.p ? ` · ${entry.p}` : ""}`;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 border-b border-line py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 break-words",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "মুছুন",
						className: "text-no",
						onClick: () => hub.removeListItem(keyName, idx),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				}, `${label}-${idx}`);
			})
		})
	] });
}
function DutyTab() {
	const hub = useHub();
	const ds = hub.dutyDate || operationalToday();
	const today = operationalToday();
	const code = dutyCode(ds, hub.duty);
	const mk = ds.slice(0, 7);
	const monthRows = dutyMonth(mk, hub.duty) || [];
	const monthTitle = monthRows.length ? `${MONTHS[Number(mk.slice(5)) - 1]} ${bn(mk.slice(0, 4))}` : "";
	const parts = ds.split("-");
	const heading = `${WEEKDAYS[(/* @__PURE__ */ new Date(`${ds}T00:00:00`)).getDay()]}, ${bn(`${parts[2]}/${parts[1]}/${parts[0]}`)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "শুক্রবার বন্ধ। রাত ১২টা ও রাত ২টার ডিউটি। হেলপার ড্রাইভারের সাথে থাকে।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "আগের দিন",
						onClick: () => hub.shiftDuty(-1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "date",
						value: ds,
						onChange: (e) => e.target.value && hub.setDutyDate(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "পরের দিন",
						onClick: () => hub.shiftDuty(1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: hub.jumpToday,
						children: "আজ"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: ds === today ? `আজকের ডিউটি — ${heading}` : heading
			}), code === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "এই মাসের চার্ট এখনো বানানো হয়নি। নিচে ১ ও ২ তারিখের ডিউটি দিয়ে বানান।"
			}) : code === "X" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm font-medium text-muted",
				children: "বন্ধ (শুক্রবার)"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shift, {
					title: "রাত ১২টা",
					code: code[0]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shift, {
					title: "রাত ২টা",
					code: code[1]
				})]
			})] }),
			monthTitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: monthTitle
			}) : null,
			monthRows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "roster px-2 pb-2 text-xs font-semibold text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "তারিখ" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "রাত ১২টা" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "রাত ২টা" })
				]
			}), monthRows.map((row, i) => {
				const day = i + 1;
				const key = `${mk}-${String(day).padStart(2, "0")}`;
				const wd = WEEKDAYS[(/* @__PURE__ */ new Date(`${key}T00:00:00`)).getDay()];
				const names = row === "X" ? ["বন্ধ", "বন্ধ"] : [crewName(row[0]), crewName(row[1])];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						hub.setDutyDate(key);
						window.scrollTo(0, 0);
					},
					className: cn("roster w-full border-t border-line px-2 py-3 text-left text-sm", key === ds && "rounded-md bg-yes-bg font-semibold", row === "X" && "text-muted"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							bn(`${String(day).padStart(2, "0")}/${mk.slice(5)}`),
							" ",
							wd
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: names[0] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: names[1] })
					]
				}, key);
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Builder, {})
		]
	});
}
function crewName(code) {
	if (!code || !(code in DT)) return "—";
	return DT[code].bn;
}
function Shift({ title, code }) {
	if (!code || !(code in DT)) return null;
	const t = DT[code];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-line bg-elevated p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-muted",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 font-semibold",
				children: [
					t.bn,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium text-muted",
						children: [
							"(",
							t.d,
							")"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: `tel:${t.dp}`,
				className: "mt-1 inline-flex items-center gap-2 text-sm font-semibold text-yes",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }),
					t.dp,
					t.da ? ` / ${t.da}` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm",
				children: [
					"হেলপার · ",
					t.h,
					t.ha ? ` / ${t.ha}` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: `tel:${t.hp}`,
				className: "inline-flex items-center gap-2 text-sm font-semibold text-yes",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), t.hp]
			})
		]
	});
}
function Builder() {
	const hub = useHub();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [month, setMonth] = (0, import_react.useState)("");
	const [d1a, setD1a] = (0, import_react.useState)("S");
	const [d1b, setD1b] = (0, import_react.useState)("L");
	const [d2a, setD2a] = (0, import_react.useState)("L");
	const [d2b, setD2b] = (0, import_react.useState)("B");
	(0, import_react.useEffect)(() => {
		if (!hub.ready || month) return;
		setMonth(nextOpenMonth(hub.duty));
	}, [
		hub.ready,
		hub.duty,
		month
	]);
	const onMonth = (value) => {
		setMonth(value);
		const saved = hub.duty[value];
		if (!saved) return;
		setD1a(saved.a[0]);
		setD1b(saved.a[1]);
		setD2a(saved.b[0]);
		setD2b(saved.b[1]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "flex w-full items-center justify-between text-left font-semibold",
		onClick: () => setOpen((v) => !v),
		children: ["নতুন মাসের চার্ট", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium text-muted",
			children: open ? "বন্ধ" : "খুলুন"
		})]
	}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "১ ও ২ তারিখ দিন। বাকি দিন একই নিয়মে সাজবে, শুক্রবার বন্ধ থাকবে। নভেম্বর ২০২৬ আগে থেকে সাজানো।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "মাস",
						className: "col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "month",
							value: month,
							onChange: (e) => onMonth(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "col-span-2 text-sm font-semibold",
						children: "১ তারিখ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrewSelect, {
						label: "রাত ১২টা",
						value: d1a,
						onChange: setD1a
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrewSelect, {
						label: "রাত ২টা",
						value: d1b,
						onChange: setD1b
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "col-span-2 text-sm font-semibold",
						children: "২ তারিখ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrewSelect, {
						label: "রাত ১২টা",
						value: d2a,
						onChange: setD2a
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrewSelect, {
						label: "রাত ২টা",
						value: d2b,
						onChange: setD2b
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						if (!month) {
							hub.notify("মাস বেছে নিন");
							return;
						}
						if (d1a === d1b || d2a === d2b) {
							hub.notify("রাত ১২টা ও রাত ২টায় একই জন দেওয়া যাবে না");
							return;
						}
						hub.saveDutyMonth(month, d1a + d1b, d2a + d2b);
						hub.setDutyDate(`${month}-01`);
						hub.notify("চার্ট বানানো হয়েছে");
						window.scrollTo(0, 0);
					},
					children: "চার্ট বানান"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => {
						if (!hub.deleteDutyMonth(month)) {
							hub.notify("এই মাসের জন্য বানানো চার্ট নেই");
							return;
						}
						if (month) hub.setDutyDate(`${month}-01`);
						hub.notify("মুছে ফেলা হয়েছে");
					},
					children: "এই মাস মুছুন"
				})]
			})
		]
	}) : null] });
}
function CrewSelect({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			className: "field",
			value,
			onChange: (e) => onChange(e.target.value),
			children: DRIVER_CODES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: c,
				children: DT[c].bn
			}, c))
		})
	});
}
function InfoTab() {
	const hub = useHub();
	const [backup, setBackup] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: hub.toggleInfoEdit,
					children: hub.infoEdit ? "সম্পাদনা শেষ" : "সম্পাদনা"
				})
			}),
			hub.info.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "কোনো তথ্য নেই। সম্পাদনা চেপে নতুন কার্ড যোগ করুন — নাম, নম্বর, আইডি।"
			}) }) : null,
			hub.info.map((card, i) => hub.infoEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: card.t,
					placeholder: "শিরোনাম",
					"aria-label": "শিরোনাম",
					onChange: (e) => hub.setInfoCard(i, { t: e.target.value })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "field mt-2",
					rows: Math.max(3, card.b.split("\n").length),
					value: card.b,
					placeholder: "বিবরণ (নাম, নম্বর, আইডি)",
					"aria-label": "বিবরণ",
					onChange: (e) => hub.setInfoCard(i, { b: e.target.value })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mr-auto" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "উপরে নিন",
							disabled: i === 0,
							onClick: () => hub.moveInfo(i, -1),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "নিচে নিন",
							disabled: i === hub.info.length - 1,
							onClick: () => hub.moveInfo(i, 1),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							size: "icon",
							"aria-label": "মুছুন",
							onClick: async () => {
								if (await hub.confirm("এই কার্ডটি মুছে ফেলবেন?")) hub.removeInfo(i);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				})
			] }, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: card.t
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: async () => {
						const ok = await copyText(`${card.t ? `${card.t}\n` : ""}${card.b}`);
						hub.notify(ok ? "কপি হয়েছে" : "কপি করা যায়নি");
					},
					children: "কপি"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, { text: card.b })] }, i)),
			hub.infoEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "lg",
				className: "w-full border-dashed",
				onClick: hub.addInfo,
				children: "নতুন কার্ড যোগ করুন"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full items-center justify-between text-left font-semibold",
				onClick: () => setOpen((v) => !v),
				children: ["ব্যাকআপ ও রিস্টোর", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium text-muted",
					children: open ? "বন্ধ" : "খুলুন"
				})]
			}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "ড্রাইভার, হেলপার, গাড়ির নম্বর আর তথ্য কার্ড একটা কোডে কপি করে রাখুন। নতুন ফোনে পেস্ট করে রিস্টোর করুন।"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						onClick: async () => {
							const code = makeBackup(hub.info, hub.lists);
							setBackup(code);
							const ok = await copyText(code);
							hub.notify(ok ? "কপি হয়েছে" : "কপি করা যায়নি");
						},
						children: "ব্যাকআপ কপি করুন"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field mt-3",
						rows: 4,
						value: backup,
						placeholder: "ব্যাকআপ কোড এখানে পেস্ট করুন",
						onChange: (e) => setBackup(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						onClick: async () => {
							if (!await hub.confirm("রিস্টোর করলে Info কার্ড ব্যাকআপের মতো হবে, আর Driver, Helper, Gari নম্বর আগেরগুলোর সাথে যোগ হবে। সম্মত?")) return;
							const result = hub.restoreBackup(backup);
							if (!result.ok) {
								hub.notify(result.error);
								return;
							}
							hub.notify(result.summary);
						},
						children: "রিস্টোর করুন"
					})
				]
			}) : null] })
		]
	});
}
function RichText({ text }) {
	const re = /01[\d-]{9,12}/g;
	const nodes = [];
	let last = 0;
	let match;
	let k = 0;
	while (match = re.exec(text)) {
		const digits = match[0].replace(/-/g, "");
		if (digits.length !== 11) continue;
		if (match.index > last) nodes.push(text.slice(last, match.index));
		nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: `tel:${digits}`,
			className: "font-semibold text-yes",
			children: match[0]
		}, k++));
		last = match.index + match[0].length;
	}
	nodes.push(text.slice(last));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 whitespace-pre-wrap break-words text-sm leading-relaxed",
		children: nodes
	});
}
var NAV = [
	{
		id: "p1",
		short: "ক্লোজ",
		label: "হাব ক্লোজ",
		icon: ClipboardCheck
	},
	{
		id: "p2",
		short: "বস্তা",
		label: "বস্তা হিসাব",
		icon: Package
	},
	{
		id: "p4",
		short: "গাড়ি",
		label: "গাড়ি এন্ট্রি",
		icon: Truck
	},
	{
		id: "p5",
		short: "ডিউটি",
		label: "ডিউটি চার্ট",
		icon: CalendarDays
	},
	{
		id: "p3",
		short: "তথ্য",
		label: "তথ্য",
		icon: Info
	}
];
var TITLES = {
	p1: "হাব ক্লোজ",
	p2: "আজকের বস্তা",
	p4: "গাড়ি এন্ট্রি",
	p5: "ডিউটি চার্ট",
	p3: "তথ্য ও ব্যাকআপ"
};
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 32 32",
		className: "size-6",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M4 24V6h5.2l6.8 12.4L22.8 6H28v18h-4.2V13.2L18.2 24h-4.4l-5.6-10.8V24H4z"
		})
	});
}
function HubShell() {
	const hub = useHub();
	const [clock, setClock] = (0, import_react.useState)(() => fmtClock());
	const [ops, setOps] = (0, import_react.useState)(() => operationalToday());
	(0, import_react.useEffect)(() => {
		const tick = () => {
			setClock(fmtClock());
			setOps(operationalToday());
		};
		const id = window.setInterval(tick, 15e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hub.ready) return;
		window.scrollTo(0, 0);
	}, [hub.tab, hub.ready]);
	if (!hub.ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg px-6 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid size-12 place-items-center rounded-md bg-accent text-accent-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg font-semibold",
					children: "কামরাঙ্গীরচর হাব"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "অপারেশন ডেস্ক খুলছে"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-dvh w-full max-w-6xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-line px-3 py-5 md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-11 place-items-center rounded-md bg-accent text-accent-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-medium text-muted",
								children: "অপারেশন"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold leading-tight",
								children: "কামরাঙ্গীরচর"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "mt-8 flex flex-col gap-1",
							"aria-label": "বিভাগ",
							children: NAV.map((item) => {
								const Icon = item.icon;
								const active = hub.tab === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-current": active ? "page" : void 0,
									onClick: () => hub.setTab(item.id),
									className: cn("flex h-12 items-center gap-3 rounded-md px-3 text-left text-sm font-semibold", active ? "bg-elevated text-ink" : "text-muted"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5",
										strokeWidth: 1.75
									}), item.label]
								}, item.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-auto px-3 text-xs leading-relaxed text-subtle",
							children: "সকাল ৯টার আগে আগের দিনের হিসাব। ফোনেই সেভ থাকে।"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
						className: "sticky top-0 z-20 border-b border-line bg-bg pt-[env(safe-area-inset-top)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-4 py-3 md:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-11 shrink-0 place-items-center rounded-md bg-accent text-accent-ink md:hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs font-medium text-muted",
										children: ["কামরাঙ্গীরচর হাব · ", fmtOpsDay(ops)]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "truncate text-lg font-semibold leading-tight tracking-tight",
										children: TITLES[hub.tab]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-base font-semibold tabular-nums",
										children: clock
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: hub.toggleTheme,
										"aria-label": hub.theme === "dark" ? "লাইট থিম" : "ডার্ক থিম",
										className: "press mt-0.5 inline-flex h-8 items-center gap-1 text-xs font-medium text-muted",
										children: [hub.theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-3.5" }), hub.theme === "dark" ? "লাইট" : "ডার্ক"]
									})]
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "mx-auto w-full max-w-2xl flex-1 px-4 pt-4 pb-28 md:px-8 md:pb-12",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: hub.tab === "p1" ? "tab-enter" : "hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChecklistTab, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: hub.tab === "p2" ? "tab-enter" : "hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BostaTab, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: hub.tab === "p4" ? "tab-enter" : "hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GariTab, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: hub.tab === "p5" ? "tab-enter" : "hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutyTab, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: hub.tab === "p3" ? "tab-enter" : "hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTab, {})
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] md:hidden",
				"aria-label": "বিভাগ",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-lg grid-cols-5",
					children: NAV.map((item) => {
						const Icon = item.icon;
						const active = hub.tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-current": active ? "page" : void 0,
							"aria-label": item.label,
							onClick: () => hub.setTab(item.id),
							className: cn("flex h-16 flex-col items-center justify-center gap-1 text-xs font-semibold", active ? "text-accent" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: 1.75
							}), item.short]
						}, item.id);
					})
				})
			}),
			hub.toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed inset-x-0 bottom-24 z-40 flex justify-center px-4 md:bottom-8",
				role: "status",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-full bg-ink px-4 py-2 text-sm font-semibold text-bg",
					children: hub.toast
				})
			}) : null,
			hub.confirmState ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-ink/40 px-5",
				role: "presentation",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "alertdialog",
					"aria-modal": "true",
					"aria-labelledby": "confirm-title",
					className: "modal-pop w-full max-w-sm rounded-xl border border-line bg-surface p-5 text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: "confirm-title",
						className: "text-base leading-relaxed",
						children: hub.confirmState.message
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							autoFocus: true,
							className: "press h-12 rounded-md border border-line font-semibold",
							onClick: () => hub.closeConfirm(false),
							children: "না, থাক"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "press h-12 rounded-md bg-accent font-semibold text-accent-ink",
							onClick: () => hub.closeConfirm(true),
							children: "হ্যাঁ"
						})]
					})]
				})
			}) : null
		]
	});
}
function HubApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HubProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HubShell, {}) });
}
var SplitComponent = HubApp;
//#endregion
export { SplitComponent as component };
