import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-eDpl53rA.mjs";
import { i as computeCommission, n as authMiddleware, p as toNumber } from "./rooms-model-vkd-sanX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms-api-D44b6Cfk.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asKind(v) {
	return v === "fixed" ? "fixed" : "percent";
}
function asStatus(v) {
	return v === "rented" ? "rented" : "available";
}
function iso(value) {
	if (value instanceof Date) return value.toISOString();
	return String(value);
}
function toPublic(row) {
	return {
		id: row.id,
		ownerId: row.owner_id,
		title: row.title,
		location: row.location,
		rent: toNumber(row.rent),
		currency: row.currency || "",
		deposit: toNumber(row.deposit),
		availableFrom: row.available_from || "",
		description: row.description || "",
		commissionType: asKind(row.commission_type),
		commissionValue: toNumber(row.commission_value),
		renterCommissionType: asKind(row.renter_commission_type),
		renterCommissionValue: toNumber(row.renter_commission_value),
		status: asStatus(row.status),
		createdAt: iso(row.created_at)
	};
}
function toOwned(row) {
	return {
		...toPublic(row),
		phone: row.phone || "",
		whatsapp: row.whatsapp || "",
		rentedVia: row.rented_via ?? null
	};
}
var listRooms_createServerFn_handler = createServerRpc({
	id: "52c2ed81cbe0b3dfe8bb9d9916d27eb903bffdbd45a6149fafd59b387d7e52b6",
	name: "listRooms",
	filename: "src/lib/rooms-api.ts"
}, (opts) => listRooms.__executeServer(opts));
var listRooms = createServerFn({ method: "GET" }).handler(listRooms_createServerFn_handler, async () => {
	return (await (await getSql())`
    select id, owner_id, title, location, rent, currency, deposit, available_from,
           description, commission_type, commission_value, renter_commission_type,
           renter_commission_value, status, created_at
    from rooms
    order by created_at desc
    limit 300
  `).map(toPublic);
});
var listMyRooms_createServerFn_handler = createServerRpc({
	id: "f9937666c001e2bd903d189d0e01ae04e18e63ebde4a2e9096d9634a33f26be8",
	name: "listMyRooms",
	filename: "src/lib/rooms-api.ts"
}, (opts) => listMyRooms.__executeServer(opts));
var listMyRooms = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMyRooms_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select id, owner_id, title, location, rent, currency, deposit, available_from,
             phone, whatsapp, description, commission_type, commission_value,
             renter_commission_type, renter_commission_value, status, rented_via, created_at
      from rooms
      where owner_id = ${context.userId}
      order by created_at desc
    `).map(toOwned);
});
var createRoom_createServerFn_handler = createServerRpc({
	id: "214a817ad94b80eb9ff1050573bbbb5b192dee7b2e345046acb55bed64b704ce",
	name: "createRoom",
	filename: "src/lib/rooms-api.ts"
}, (opts) => createRoom.__executeServer(opts));
var createRoom = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const title = String(input.title || "").trim();
	const location = String(input.location || "").trim();
	const phone = String(input.phone || "").trim();
	if (!title) throw new Error("Title is required.");
	if (!location) throw new Error("Pick an area for this room.");
	if (!phone) throw new Error("Owner phone is required.");
	const rent = toNumber(input.rent);
	if (rent < 0) throw new Error("Rent must be zero or more.");
	return {
		title: title.slice(0, 120),
		location: location.slice(0, 120),
		rent,
		currency: String(input.currency || "").trim().slice(0, 12),
		deposit: Math.max(0, toNumber(input.deposit)),
		availableFrom: String(input.availableFrom || "").trim().slice(0, 80),
		phone: phone.slice(0, 40),
		whatsapp: String(input.whatsapp || "").trim().slice(0, 40),
		description: String(input.description || "").trim().slice(0, 2e3),
		commissionType: asKind(String(input.commissionType)),
		commissionValue: Math.max(0, toNumber(input.commissionValue)),
		renterCommissionType: asKind(String(input.renterCommissionType)),
		renterCommissionValue: Math.max(0, toNumber(input.renterCommissionValue))
	};
}).handler(createRoom_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const id = crypto.randomUUID();
	await sql`
      insert into rooms (
        id, owner_id, title, location, rent, currency, deposit, available_from,
        phone, whatsapp, description, commission_type, commission_value,
        renter_commission_type, renter_commission_value, status, created_at
      ) values (
        ${id}, ${context.userId}, ${data.title}, ${data.location}, ${data.rent},
        ${data.currency}, ${data.deposit}, ${data.availableFrom}, ${data.phone},
        ${data.whatsapp}, ${data.description}, ${data.commissionType}, ${data.commissionValue},
        ${data.renterCommissionType}, ${data.renterCommissionValue}, 'available', now()
      )
    `;
	return { id };
});
var getRoomContact_createServerFn_handler = createServerRpc({
	id: "49632de4bd84b45145dbb9a65f3993836f03d4b1cd025c301cc484773c55d588",
	name: "getRoomContact",
	filename: "src/lib/rooms-api.ts"
}, (opts) => getRoomContact.__executeServer(opts));
var getRoomContact = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	roomId: String(input.roomId || ""),
	referrerId: input.referrerId ? String(input.referrerId) : null
})).handler(getRoomContact_createServerFn_handler, async ({ context, data }) => {
	if (!data.roomId) throw new Error("Missing room.");
	const sql = await getSql();
	if (((await sql`
      select count(*)::int as n
      from contact_reveals
      where user_id = ${context.userId}
        and created_at > now() - interval '60 seconds'
    `)[0]?.n ?? 0) >= 8) throw new Error("Too many numbers viewed at once — please wait a moment.");
	const room = (await sql`
      select phone, whatsapp, title, owner_id from rooms where id = ${data.roomId} limit 1
    `)[0];
	if (!room) throw new Error("That listing is gone.");
	await sql`
      insert into contact_reveals (user_id, room_id, created_at)
      values (${context.userId}, ${data.roomId}, now())
    `;
	const referrerId = data.referrerId;
	if (referrerId && referrerId !== context.userId && referrerId !== room.owner_id && context.userId !== room.owner_id) await sql`
        insert into leads (room_id, referrer_id, viewer_id, created_at)
        values (${data.roomId}, ${referrerId}, ${context.userId}, now())
        on conflict (room_id, referrer_id, viewer_id) do nothing
      `;
	return {
		phone: room.phone,
		whatsapp: room.whatsapp,
		title: room.title
	};
});
var deleteRoom_createServerFn_handler = createServerRpc({
	id: "d5475b9ac8a1da002804217be4c7b57dfc63fe11e5f9e1b278e96723a040ee43",
	name: "deleteRoom",
	filename: "src/lib/rooms-api.ts"
}, (opts) => deleteRoom.__executeServer(opts));
var deleteRoom = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((roomId) => String(roomId || "")).handler(deleteRoom_createServerFn_handler, async ({ context, data: roomId }) => {
	const sql = await getSql();
	if (!(await sql`
      delete from rooms where id = ${roomId} and owner_id = ${context.userId} returning id
    `).length) throw new Error("Couldn't delete that listing.");
	await sql`delete from leads where room_id = ${roomId}`;
	return { ok: true };
});
var reopenRoom_createServerFn_handler = createServerRpc({
	id: "dfd9567548e8bc28fad50c432f19b2015233f7206befba62d7457243d019fefe",
	name: "reopenRoom",
	filename: "src/lib/rooms-api.ts"
}, (opts) => reopenRoom.__executeServer(opts));
var reopenRoom = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((roomId) => String(roomId || "")).handler(reopenRoom_createServerFn_handler, async ({ context, data: roomId }) => {
	if (!(await (await getSql())`
      update rooms
      set status = 'available', rented_via = null, rented_at = null
      where id = ${roomId} and owner_id = ${context.userId}
      returning id
    `).length) throw new Error("Couldn't reopen that listing.");
	return { ok: true };
});
var listLeadsForRoom_createServerFn_handler = createServerRpc({
	id: "38f0cf1d5acc95c4ff47d1df294a6e290e691b3f274790ba0054e2e4eb21154d",
	name: "listLeadsForRoom",
	filename: "src/lib/rooms-api.ts"
}, (opts) => listLeadsForRoom.__executeServer(opts));
var listLeadsForRoom = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((roomId) => String(roomId || "")).handler(listLeadsForRoom_createServerFn_handler, async ({ context, data: roomId }) => {
	const sql = await getSql();
	if (!(await sql`
      select id from rooms where id = ${roomId} and owner_id = ${context.userId}
    `).length) throw new Error("Not found.");
	return (await sql`
      select distinct l.referrer_id, u.name
      from leads l
      left join "user" u on u.id = l.referrer_id
      where l.room_id = ${roomId}
    `).map((r) => ({
		referrerId: r.referrer_id,
		name: r.name?.trim() || "Someone"
	}));
});
var confirmRented_createServerFn_handler = createServerRpc({
	id: "91e22eeec88c0fcee3e9995304684012e6aece21061f2aa8cd64d64152f789a7",
	name: "confirmRented",
	filename: "src/lib/rooms-api.ts"
}, (opts) => confirmRented.__executeServer(opts));
var confirmRented = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	roomId: String(input.roomId || ""),
	referrerId: input.referrerId ? String(input.referrerId) : null
})).handler(confirmRented_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const room = (await sql`
      select id, owner_id, title, location, rent, currency, deposit, available_from,
             description, commission_type, commission_value, renter_commission_type,
             renter_commission_value, status, created_at
      from rooms
      where id = ${data.roomId} and owner_id = ${context.userId}
      limit 1
    `)[0];
	if (!room) throw new Error("Not found.");
	if (asStatus(room.status) === "rented") throw new Error("Already marked rented.");
	const referrerId = data.referrerId;
	await sql`
      update rooms
      set status = 'rented', rented_via = ${referrerId}, rented_at = now()
      where id = ${data.roomId} and owner_id = ${context.userId}
    `;
	if (referrerId) {
		const publicRoom = toPublic(room);
		const amount = computeCommission(publicRoom);
		await sql`
        insert into commissions (room_id, room_title, referrer_id, amount, currency, status, created_at)
        values (${data.roomId}, ${room.title}, ${referrerId}, ${amount}, ${room.currency || ""}, 'pending', now())
      `;
	}
	return {
		ok: true,
		createdCommission: Boolean(referrerId)
	};
});
var listMyCommissions_createServerFn_handler = createServerRpc({
	id: "8fcfe99380eab88423ff3e930be2e16062a113b7007a6a34bd05afea8e4fe851",
	name: "listMyCommissions",
	filename: "src/lib/rooms-api.ts"
}, (opts) => listMyCommissions.__executeServer(opts));
var listMyCommissions = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMyCommissions_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select id, room_id, room_title, referrer_id, amount, currency, status, created_at
      from commissions
      where referrer_id = ${context.userId}
      order by created_at desc
    `).map((r) => ({
		id: toNumber(r.id),
		roomId: r.room_id,
		roomTitle: r.room_title,
		referrerId: r.referrer_id,
		amount: toNumber(r.amount),
		currency: r.currency || "",
		status: r.status === "paid" ? "paid" : "pending",
		createdAt: iso(r.created_at)
	}));
});
var listRoomCommissions_createServerFn_handler = createServerRpc({
	id: "2a6b7c5fdaa9bccbeb428b9c7a94803ba975ff404c917c93e2076d7ffcb3a090",
	name: "listRoomCommissions",
	filename: "src/lib/rooms-api.ts"
}, (opts) => listRoomCommissions.__executeServer(opts));
var listRoomCommissions = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((roomId) => String(roomId || "")).handler(listRoomCommissions_createServerFn_handler, async ({ context, data: roomId }) => {
	const sql = await getSql();
	if (!(await sql`
      select id from rooms where id = ${roomId} and owner_id = ${context.userId}
    `).length) throw new Error("Not found.");
	return (await sql`
      select id, amount, currency, status from commissions where room_id = ${roomId} order by created_at desc
    `).map((r) => ({
		id: toNumber(r.id),
		amount: toNumber(r.amount),
		currency: r.currency || "",
		status: r.status === "paid" ? "paid" : "pending"
	}));
});
var markCommissionPaid_createServerFn_handler = createServerRpc({
	id: "a3c988054409db2b89c732f250457de5b700e3fc83acc60388b4188eaf49d378",
	name: "markCommissionPaid",
	filename: "src/lib/rooms-api.ts"
}, (opts) => markCommissionPaid.__executeServer(opts));
var markCommissionPaid = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((commissionId) => toNumber(commissionId)).handler(markCommissionPaid_createServerFn_handler, async ({ context, data: commissionId }) => {
	if (!(await (await getSql())`
      update commissions c
      set status = 'paid'
      from rooms r
      where c.id = ${commissionId}
        and c.room_id = r.id
        and r.owner_id = ${context.userId}
        and c.status = 'pending'
      returning c.id
    `).length) throw new Error("Couldn't mark that commission paid.");
	return { ok: true };
});
//#endregion
export { confirmRented_createServerFn_handler, createRoom_createServerFn_handler, deleteRoom_createServerFn_handler, getRoomContact_createServerFn_handler, listLeadsForRoom_createServerFn_handler, listMyCommissions_createServerFn_handler, listMyRooms_createServerFn_handler, listRoomCommissions_createServerFn_handler, listRooms_createServerFn_handler, markCommissionPaid_createServerFn_handler, reopenRoom_createServerFn_handler };
