import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BdTkXvcj.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "awrad-frame",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			title: "أوراد وروحانيات",
			src: "/awrad.html",
			className: "awrad-iframe"
		})
	});
}
//#endregion
export { Home as component };
