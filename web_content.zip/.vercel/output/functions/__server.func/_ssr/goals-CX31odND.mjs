import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as usePlanner, k as cn } from "./router-CQnHyG8o.mjs";
import { a as EmptyCopy, d as fieldClass, n as Card, s as PageHeader } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
import { t as SortableList } from "./sortable-DqnUMi7n.mjs";
import { t as CheckList } from "./check-list-Bim0RNJK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/goals-CX31odND.js
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	{
		value: "active",
		label: "Active"
	},
	{
		value: "paused",
		label: "Paused"
	},
	{
		value: "done",
		label: "Done"
	}
];
function GoalsView() {
	const goals = usePlanner((s) => s.goals);
	const addGoal = usePlanner((s) => s.addGoal);
	const updateGoal = usePlanner((s) => s.updateGoal);
	const setGoals = usePlanner((s) => s.setGoals);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			section: "goals",
			title: "Goals",
			lede: "The few outcomes that matter."
		}),
		goals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCopy, {
			title: "Nothing named yet",
			body: "A goal with a reason is easier to keep."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableList, {
			items: goals,
			getId: (goal) => goal.id,
			onReorder: setGoals,
			className: "gap-3",
			render: (goal, grip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-start gap-1",
					children: [
						grip,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: goal.title,
								"aria-label": "Goal title",
								onChange: (event) => updateGoal(goal.id, { title: event.target.value }),
								placeholder: "Name the goal",
								className: "h-11 w-full bg-transparent font-display text-2xl outline-none placeholder:text-muted"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: goal.area,
								"aria-label": "Area",
								onChange: (event) => updateGoal(goal.id, { area: event.target.value }),
								placeholder: "Area — craft, home, body",
								className: "h-10 w-full bg-transparent text-sm text-muted outline-none placeholder:text-muted"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 px-2 text-sm text-muted",
							onClick: () => {
								const prev = goals;
								setGoals(goals.filter((item) => item.id !== goal.id));
								toast("Goal removed", { action: {
									label: "Undo",
									onClick: () => setGoals(prev)
								} });
							},
							children: "Remove"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: goal.why,
					"aria-label": "Why this goal",
					onChange: (event) => updateGoal(goal.id, { why: event.target.value }),
					placeholder: "Why it matters.",
					rows: 2,
					className: "mb-3 min-h-16 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mb-3 grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center justify-between text-sm text-muted",
						children: ["Progress", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-ink",
							children: [goal.progress, "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 0,
						max: 100,
						value: goal.progress,
						"aria-label": "Progress",
						onChange: (event) => updateGoal(goal.id, { progress: Number(event.target.value) }),
						className: "slider"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex flex-wrap gap-2",
					children: [STATUSES.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": goal.status === status.value,
						onClick: () => updateGoal(goal.id, { status: status.value }),
						className: cn("h-10 rounded-full px-3 text-sm font-medium", goal.status === status.value ? "bg-blush text-ink" : "text-muted"),
						children: status.label
					}, status.value)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: goal.deadline,
						"aria-label": "Deadline",
						onChange: (event) => updateGoal(goal.id, { deadline: event.target.value }),
						className: "h-10 min-w-0 rounded-lg border border-line bg-card px-2 text-sm"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-medium",
					children: "Milestones"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckList, {
					items: goal.milestones,
					placeholder: "A milestone",
					onChange: (milestones) => updateGoal(goal.id, { milestones })
				})
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 flex gap-2",
			onSubmit: (event) => {
				event.preventDefault();
				const data = new FormData(event.currentTarget);
				const title = String(data.get("title") ?? "").trim();
				if (!title) return;
				addGoal({
					id: uid(),
					title,
					area: "",
					why: "",
					progress: 0,
					deadline: "",
					status: "active",
					milestones: []
				});
				event.currentTarget.reset();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				name: "title",
				placeholder: "New goal",
				"aria-label": "New goal",
				className: fieldClass
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "h-11 shrink-0 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg",
				children: "Add"
			})]
		})
	] });
}
var SplitComponent = GoalsView;
//#endregion
export { SplitComponent as component };
