import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { G as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as Rocket, i as Scan, n as Volume2, o as Pause, s as Map, t as VolumeX } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B77Qjfsp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function atlasPos(i, n, radius, yScale) {
	const golden = Math.PI * (3 - Math.sqrt(5));
	const y = n <= 1 ? 0 : 1 - i / (n - 1) * 2;
	const r = Math.sqrt(Math.max(0, 1 - y * y));
	const theta = golden * i + .7;
	return [
		Math.cos(theta) * r * radius,
		y * yScale,
		Math.sin(theta) * r * radius
	];
}
var CATALOG = [
	{
		name: "Milky Way",
		kind: "spiral",
		colorA: 16765851,
		colorB: 10406399,
		radius: 5,
		arms: 4,
		spin: 1.3,
		bulge: .35,
		thick: .18,
		info: "Home galaxy · the Sun sits ≈26,000 ly from the core"
	},
	{
		name: "Andromeda (M31)",
		kind: "spiral",
		colorA: 16769200,
		colorB: 12178687,
		radius: 5.4,
		arms: 2,
		spin: 1.6,
		bulge: .5,
		thick: .15,
		info: "≈2.5 million ly away · on a slow collision course with us"
	},
	{
		name: "Triangulum (M33)",
		kind: "spiral",
		colorA: 16771272,
		colorB: 13625599,
		radius: 4.2,
		arms: 3,
		spin: 1,
		bulge: .15,
		thick: .2,
		info: "≈2.7 million ly away · a loosely wound spiral"
	},
	{
		name: "Large Magellanic Cloud",
		kind: "irregular",
		colorA: 16773312,
		colorB: 10475263,
		radius: 2.6,
		thick: .5,
		info: "≈160,000 ly away · a satellite of the Milky Way"
	},
	{
		name: "Small Magellanic Cloud",
		kind: "irregular",
		colorA: 16771520,
		colorB: 10471679,
		radius: 1.8,
		thick: .5,
		info: "≈200,000 ly away · rich in young blue stars"
	},
	{
		name: "Whirlpool (M51)",
		kind: "interact",
		colorA: 16769720,
		colorB: 10473727,
		radius: 4.6,
		arms: 2,
		spin: 1.9,
		bulge: .3,
		thick: .15,
		info: "≈31 million ly away · classic grand-design spiral"
	},
	{
		name: "Sombrero (M104)",
		kind: "edgeOn",
		colorA: 16767392,
		colorB: 14203274,
		radius: 4.6,
		bulge: .75,
		thick: .06,
		info: "≈29 million ly away · a bright bulge and dust lane"
	},
	{
		name: "Pinwheel (M101)",
		kind: "spiral",
		colorA: 16772299,
		colorB: 11460863,
		radius: 5.6,
		arms: 5,
		spin: 1.1,
		bulge: .15,
		thick: .14,
		info: "≈21 million ly away · a face-on giant spiral"
	},
	{
		name: "Bode's Galaxy (M81)",
		kind: "spiral",
		colorA: 16768160,
		colorB: 12376319,
		radius: 4.4,
		arms: 2,
		spin: 1.7,
		bulge: .45,
		thick: .16,
		info: "≈12 million ly away · a grand-design companion of M82"
	},
	{
		name: "Cigar Galaxy (M82)",
		kind: "edgeOnBurst",
		colorA: 16751979,
		colorB: 16736138,
		radius: 2.6,
		thick: .05,
		info: "≈12 million ly away · a starburst with polar outflows"
	},
	{
		name: "Black Eye (M64)",
		kind: "spiral",
		colorA: 16767405,
		colorB: 9403312,
		radius: 4,
		arms: 2,
		spin: 1.4,
		bulge: .5,
		thick: .14,
		info: "≈17 million ly away · a prominent absorbing dust band"
	},
	{
		name: "Sunflower (M63)",
		kind: "spiral",
		colorA: 16770749,
		colorB: 12115199,
		radius: 4.4,
		arms: 8,
		spin: 1.2,
		bulge: .3,
		thick: .15,
		info: "≈27 million ly away · flocculent spiral structure"
	},
	{
		name: "Sculptor (NGC 253)",
		kind: "edgeOn",
		colorA: 16764830,
		colorB: 13215864,
		radius: 4.2,
		bulge: .25,
		thick: .07,
		info: "≈11 million ly away · a dusty starburst disk"
	},
	{
		name: "Centaurus A",
		kind: "elliptical",
		colorA: 16764830,
		colorB: 16757626,
		radius: 3.6,
		info: "≈12 million ly away · an elliptical crossed by a dust lane"
	},
	{
		name: "Messier 87",
		kind: "elliptical",
		colorA: 16773583,
		colorB: 16769696,
		radius: 4,
		info: "≈53 million ly away · giant elliptical with a relativistic jet"
	},
	{
		name: "Cartwheel Galaxy",
		kind: "ring",
		colorA: 10475263,
		colorB: 16771248,
		radius: 4.2,
		info: "≈500 million ly away · a collisional ring"
	},
	{
		name: "Tadpole Galaxy",
		kind: "irregular",
		colorA: 12575743,
		colorB: 16773320,
		radius: 2.4,
		thick: .35,
		info: "≈420 million ly away · a disrupted spiral with a long tail"
	},
	{
		name: "Antennae Galaxies",
		kind: "interact",
		colorA: 16767392,
		colorB: 10473727,
		radius: 3.6,
		arms: 3,
		spin: 1.6,
		bulge: .3,
		thick: .15,
		info: "≈45 million ly away · a pair in mid-merger"
	},
	{
		name: "Seyfert's Sextet",
		kind: "cluster",
		colorA: 16769712,
		colorB: 10473727,
		radius: 1.1,
		info: "≈190 million ly away · a compact group of galaxies"
	},
	{
		name: "Hoag's Object",
		kind: "ring",
		colorA: 16770751,
		colorB: 10471679,
		radius: 3.6,
		info: "≈600 million ly away · a nearly perfect ring galaxy"
	},
	{
		name: "NGC 1300",
		kind: "barred",
		colorA: 16769712,
		colorB: 11130111,
		radius: 4.4,
		arms: 2,
		spin: 1.5,
		bulge: .25,
		thick: .15,
		info: "≈61 million ly away · the prototypical barred spiral"
	},
	{
		name: "NGC 1365",
		kind: "barred",
		colorA: 16768164,
		colorB: 10473727,
		radius: 4.8,
		arms: 2,
		spin: 1.9,
		bulge: .3,
		thick: .15,
		info: "≈56 million ly away · a barred spiral in Fornax"
	},
	{
		name: "NGC 4258 (M106)",
		kind: "spiral",
		colorA: 16770752,
		colorB: 11589887,
		radius: 4.6,
		arms: 2,
		spin: 1.3,
		bulge: .35,
		thick: .16,
		info: "≈23 million ly away · anomalous arms from a central engine"
	},
	{
		name: "Whale Galaxy (NGC 4631)",
		kind: "edgeOn",
		colorA: 16768160,
		colorB: 13228287,
		radius: 4.8,
		bulge: .1,
		thick: .05,
		info: "≈25 million ly away · an edge-on distorted disk"
	},
	{
		name: "Needle Galaxy (NGC 4565)",
		kind: "edgeOn",
		colorA: 16770752,
		colorB: 13623551,
		radius: 5.2,
		bulge: .45,
		thick: .03,
		info: "≈40 million ly away · a razor-thin edge-on spiral"
	},
	{
		name: "Fireworks (NGC 6946)",
		kind: "spiral",
		colorA: 16770760,
		colorB: 11133183,
		radius: 4.6,
		arms: 6,
		spin: 1,
		bulge: .2,
		thick: .16,
		info: "≈22 million ly away · prolific in supernovae"
	},
	{
		name: "Sagittarius A*",
		kind: "blackhole",
		colorA: 16773832,
		colorB: 16738876,
		radius: 2.2,
		info: "≈26,000 ly away · ≈4.3 million solar masses"
	},
	{
		name: "Messier 87*",
		kind: "blackhole",
		colorA: 16771504,
		colorB: 16742972,
		radius: 3.4,
		info: "≈55 million ly away · ≈6.5 billion solar masses"
	},
	{
		name: "Cygnus X-1",
		kind: "blackhole",
		colorA: 13623551,
		colorB: 6982655,
		radius: 1.7,
		info: "≈7,200 ly away · ≈21 solar masses · a stellar-mass binary"
	},
	{
		name: "TON 618",
		kind: "blackhole",
		colorA: 16773056,
		colorB: 16734780,
		radius: 4.6,
		info: "≈10 billion ly away · ≈66 billion solar masses"
	},
	{
		name: "Phoenix A*",
		kind: "blackhole",
		colorA: 16770736,
		colorB: 16747084,
		radius: 4.2,
		info: "≈5.8 billion ly away · ≈100 billion solar masses (est.)"
	}
].map((s, i) => {
	const isBH = s.kind === "blackhole";
	const gi = isBH ? i - 26 : i;
	const n = isBH ? 5 : 26;
	const pos = isBH ? atlasPos(gi, n, 210, 46) : atlasPos(gi, n, 430, 96);
	return {
		id: i,
		name: s.name,
		kind: s.kind,
		colorA: s.colorA,
		colorB: s.colorB,
		radius: s.radius,
		arms: s.arms ?? 2,
		spin: s.spin ?? 1.2,
		bulge: s.bulge ?? .3,
		thick: s.thick ?? .16,
		info: s.info,
		pos
	};
});
var TOTAL_BODIES = CATALOG.length;
var KIND_LABEL = {
	spiral: "Spiral galaxy",
	barred: "Barred spiral",
	elliptical: "Elliptical galaxy",
	irregular: "Irregular galaxy",
	edgeOn: "Edge-on disk",
	edgeOnBurst: "Starburst disk",
	ring: "Ring galaxy",
	interact: "Interacting pair",
	cluster: "Compact group",
	blackhole: "Black hole"
};
var MISSIONS = [
	{
		id: "awaken",
		title: "Awaken the Atlas",
		text: "Throttle toward a glowing system and scan it at close range.",
		xp: 50,
		goal: 1,
		kind: "scan"
	},
	{
		id: "core",
		title: "Into the Core",
		text: "Dive inside a galaxy (under 8 units) and complete a core scan.",
		xp: 90,
		goal: 1,
		kind: "dive"
	},
	{
		id: "horizon",
		title: "Event Horizon",
		text: "Scan a black hole. Keep hull above zero — gravity will pull you in.",
		xp: 140,
		goal: 1,
		kind: "bh"
	},
	{
		id: "survey",
		title: "Deep-Space Survey",
		text: "Chart 5 different celestial objects on the atlas.",
		xp: 180,
		goal: 5,
		kind: "discover"
	},
	{
		id: "samples",
		title: "Stellar Harvest",
		text: "Fly through 8 orbiting stellar samples to collect them.",
		xp: 160,
		goal: 8,
		kind: "samples"
	},
	{
		id: "pilot",
		title: "Atlas Pilot",
		text: "Warp to 3 different systems using the catalog.",
		xp: 200,
		goal: 3,
		kind: "warp"
	},
	{
		id: "atlas",
		title: "Build the Atlas",
		text: "Discover 12 objects. The atlas is taking shape.",
		xp: 320,
		goal: 12,
		kind: "discover12"
	},
	{
		id: "master",
		title: "Atlas Master",
		text: "Chart every galaxy and black hole in the atlas.",
		xp: 600,
		goal: 31,
		kind: "all"
	}
];
var RANKS = [
	{
		name: "CADET",
		xp: 0
	},
	{
		name: "SCOUT",
		xp: 80
	},
	{
		name: "PILOT",
		xp: 200
	},
	{
		name: "EXPLORER",
		xp: 400
	},
	{
		name: "NAVIGATOR",
		xp: 700
	},
	{
		name: "CARTOGRAPHER",
		xp: 1100
	},
	{
		name: "VOIDWALKER",
		xp: 1700
	},
	{
		name: "ATLAS MASTER",
		xp: 2500
	}
];
function rankFor(xp) {
	let current = RANKS[0];
	for (const r of RANKS) if (xp >= r.xp) current = r;
	const next = RANKS[RANKS.indexOf(current) + 1] ?? null;
	return {
		current,
		next
	};
}
var KEY = "galaxy_atlas_ultra_x_v2";
var SAVE_VERSION = 2;
var DEFAULT_SAVE = {
	version: SAVE_VERSION,
	xp: 0,
	credits: 0,
	discovered: [],
	completed: [],
	samples: 0,
	warps: 0,
	scans: 0,
	dives: 0,
	bhScans: 0,
	muted: false
};
function migrate(raw) {
	const s = {
		...DEFAULT_SAVE,
		...raw,
		version: raw.version ?? 1
	};
	if (s.version < 2) s.version = 2;
	s.discovered = Array.isArray(s.discovered) ? s.discovered.filter((id) => CATALOG.some((c) => String(c.id) === id)) : [];
	s.completed = Array.isArray(s.completed) ? s.completed : [];
	s.xp = Number.isFinite(s.xp) ? s.xp : 0;
	s.credits = Number.isFinite(s.credits) ? s.credits : 0;
	s.samples = Number.isFinite(s.samples) ? s.samples : 0;
	s.warps = Number.isFinite(s.warps) ? s.warps : 0;
	s.scans = Number.isFinite(s.scans) ? s.scans : 0;
	s.dives = Number.isFinite(s.dives) ? s.dives : 0;
	s.bhScans = Number.isFinite(s.bhScans) ? s.bhScans : 0;
	s.muted = Boolean(s.muted);
	s.version = SAVE_VERSION;
	return s;
}
function loadSave() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return {
			...DEFAULT_SAVE,
			discovered: []
		};
		return migrate(JSON.parse(raw));
	} catch {
		return {
			...DEFAULT_SAVE,
			discovered: []
		};
	}
}
function writeSave(data) {
	try {
		localStorage.setItem(KEY, JSON.stringify({
			...data,
			version: SAVE_VERSION
		}));
	} catch {}
}
function clearSave() {
	try {
		localStorage.removeItem(KEY);
	} catch {}
}
var bus = null;
var muted = false;
var drone = null;
function ensure() {
	if (typeof window === "undefined") return null;
	if (bus) return bus;
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return null;
	const ctx = new AC({ latencyHint: "interactive" });
	const master = ctx.createGain();
	const sfx = ctx.createGain();
	const music = ctx.createGain();
	master.gain.value = muted ? 0 : .7;
	sfx.gain.value = .9;
	music.gain.value = .55;
	sfx.connect(master);
	music.connect(master);
	master.connect(ctx.destination);
	bus = {
		ctx,
		master,
		sfx,
		music
	};
	return bus;
}
function unlockAudio() {
	const b = ensure();
	if (!b) return;
	if (b.ctx.state === "suspended") b.ctx.resume();
}
function setMuted(next) {
	muted = next;
	if (!bus) return;
	bus.master.gain.setTargetAtTime(next ? 0 : .7, bus.ctx.currentTime, .04);
}
function beep(freq, dur, type, gain, slide = 0) {
	const b = ensure();
	if (!b || muted) return;
	const t = b.ctx.currentTime;
	const o = b.ctx.createOscillator();
	const g = b.ctx.createGain();
	o.type = type;
	o.frequency.setValueAtTime(freq, t);
	if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
	g.gain.setValueAtTime(1e-4, t);
	g.gain.exponentialRampToValueAtTime(gain, t + .012);
	g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	o.connect(g);
	g.connect(b.sfx);
	o.start(t);
	o.stop(t + dur + .02);
}
function sfxScan() {
	beep(880, .18, "sine", .08, 420);
	beep(1320, .12, "triangle", .04, 200);
}
function sfxCollect() {
	beep(740, .1, "sine", .07, 520);
	beep(1180, .16, "triangle", .05);
}
function sfxWarp() {
	beep(140, .55, "sawtooth", .05, 900);
	beep(90, .4, "sine", .06, 200);
}
function sfxWarn() {
	beep(180, .22, "square", .04);
}
function sfxRank() {
	beep(520, .16, "sine", .07, 200);
	beep(780, .22, "triangle", .05, 280);
}
function sfxDiscover() {
	beep(660, .2, "sine", .07, 340);
	beep(990, .28, "triangle", .045);
}
function startDrone() {
	const b = ensure();
	if (!b || drone) return;
	const o1 = b.ctx.createOscillator();
	const o2 = b.ctx.createOscillator();
	const g = b.ctx.createGain();
	o1.type = "sine";
	o2.type = "triangle";
	o1.frequency.value = 42;
	o2.frequency.value = 63;
	g.gain.value = 1e-4;
	o1.connect(g);
	o2.connect(g);
	g.connect(b.music);
	o1.start();
	o2.start();
	g.gain.setTargetAtTime(.022, b.ctx.currentTime, .6);
	drone = {
		o1,
		o2,
		g
	};
}
function pulseDrone(nearDanger) {
	if (!drone || !bus) return;
	const target = .018 + nearDanger * .04;
	drone.g.gain.setTargetAtTime(target, bus.ctx.currentTime, .15);
	drone.o1.frequency.setTargetAtTime(42 + nearDanger * 28, bus.ctx.currentTime, .2);
}
var emptyHud = () => ({
	fps: 60,
	speed: 0,
	hull: 1,
	boost: 1,
	credits: 0,
	xp: 0,
	rank: "CADET",
	xpInto: 0,
	xpSpan: 80,
	discovered: 0,
	total: TOTAL_BODIES,
	samples: 0,
	missionTitle: MISSIONS[0].title,
	missionText: MISSIONS[0].text,
	missionProgress: 0,
	missionGoal: MISSIONS[0].goal,
	nearestName: "—",
	nearestDist: 0,
	nearestKind: "",
	canScan: false,
	scanning: false,
	targetId: null,
	targetName: "None",
	warping: false,
	markers: [],
	toastTitle: "",
	toastText: "",
	toastOn: false,
	phase: "attract",
	muted: false
});
function currentMission(save) {
	return MISSIONS.find((m) => !save.completed.includes(m.id)) ?? MISSIONS[MISSIONS.length - 1];
}
function missionProgress(save) {
	const m = currentMission(save);
	switch (m.kind) {
		case "scan": return Math.min(m.goal, save.scans);
		case "dive": return Math.min(m.goal, save.dives);
		case "bh": return Math.min(m.goal, save.bhScans);
		case "discover":
		case "discover12":
		case "all": return Math.min(m.goal, save.discovered.length);
		case "samples": return Math.min(m.goal, save.samples);
		case "warp": return Math.min(m.goal, save.warps);
		default: return 0;
	}
}
var persistAt = 0;
var useGameStore = create((set, get) => ({
	save: {
		...DEFAULT_SAVE,
		discovered: []
	},
	hud: emptyHud(),
	catalogOpen: false,
	toastTimer: 0,
	load: () => {
		const save = loadSave();
		setMuted(save.muted);
		set({ save });
		get().flushMissions();
		get().patchHud({
			credits: save.credits,
			xp: save.xp,
			muted: save.muted,
			samples: save.samples,
			discovered: save.discovered.length
		});
	},
	persist: () => {
		writeSave(get().save);
	},
	resetProgress: () => {
		clearSave();
		set({
			save: {
				...DEFAULT_SAVE,
				discovered: []
			},
			catalogOpen: false
		});
		get().flushMissions();
		get().patchHud({
			credits: 0,
			xp: 0,
			samples: 0,
			discovered: 0,
			rank: "CADET",
			xpInto: 0,
			xpSpan: 80
		});
	},
	setPhase: (phase) => {
		get().patchHud({ phase });
	},
	setCatalogOpen: (open) => set({ catalogOpen: open }),
	toggleMute: () => {
		const save = {
			...get().save,
			muted: !get().save.muted
		};
		setMuted(save.muted);
		set({ save });
		get().patchHud({ muted: save.muted });
		get().persist();
	},
	patchHud: (partial) => {
		set((s) => ({ hud: {
			...s.hud,
			...partial
		} }));
	},
	toast: (title, text) => {
		window.clearTimeout(get().toastTimer);
		set({ toastTimer: window.setTimeout(() => {
			get().patchHud({ toastOn: false });
		}, 2200) });
		get().patchHud({
			toastTitle: title,
			toastText: text,
			toastOn: true
		});
	},
	addXP: (amount, reason) => {
		const before = rankFor(get().save.xp).current.name;
		const save = {
			...get().save,
			xp: get().save.xp + amount,
			credits: get().save.credits + Math.max(1, Math.round(amount * .35))
		};
		set({ save });
		const after = rankFor(save.xp).current.name;
		if (after !== before) {
			sfxRank();
			get().toast("RANK UP", after);
		} else get().toast("XP GAINED", `+${amount} · ${reason}`);
		get().flushMissions();
		schedulePersist();
	},
	discover: (id) => {
		const key = String(id);
		if (get().save.discovered.includes(key)) return false;
		const body = CATALOG[id];
		set({ save: {
			...get().save,
			discovered: [...get().save.discovered, key],
			xp: get().save.xp + 25,
			credits: get().save.credits + 10
		} });
		sfxDiscover();
		get().toast("NEW DISCOVERY", body?.name ?? "Unknown object");
		get().flushMissions();
		schedulePersist();
		return true;
	},
	recordScan: (id, dive, blackHole) => {
		const first = get().discover(id);
		set({ save: {
			...get().save,
			scans: get().save.scans + 1,
			dives: get().save.dives + (dive ? 1 : 0),
			bhScans: get().save.bhScans + (blackHole ? 1 : 0)
		} });
		if (!first) get().addXP(12, "Rescan");
		else get().flushMissions();
		schedulePersist();
	},
	collectSample: () => {
		const save = {
			...get().save,
			samples: get().save.samples + 1,
			xp: get().save.xp + 15,
			credits: get().save.credits + 8
		};
		set({ save });
		sfxCollect();
		get().toast("SAMPLE COLLECTED", `Stellar sample · ${save.samples} held`);
		get().flushMissions();
		schedulePersist();
	},
	recordWarp: () => {
		set({ save: {
			...get().save,
			warps: get().save.warps + 1
		} });
		get().addXP(20, "Warp");
		get().flushMissions();
		schedulePersist();
	},
	flushMissions: () => {
		const save = { ...get().save };
		let gained = 0;
		for (const m of MISSIONS) {
			if (save.completed.includes(m.id)) continue;
			if (missionProgress(save) >= m.goal) {
				save.completed = [...save.completed, m.id];
				save.xp += m.xp;
				save.credits += Math.round(m.xp * .45);
				gained += m.xp;
				get().toast("MISSION COMPLETE", m.title);
			}
		}
		set({ save });
		const m = currentMission(save);
		const rk = rankFor(save.xp);
		const base = rk.current.xp;
		const top = rk.next ? rk.next.xp : base + 800;
		get().patchHud({
			credits: save.credits,
			xp: save.xp,
			rank: rk.current.name,
			xpInto: save.xp - base,
			xpSpan: top - base,
			discovered: save.discovered.length,
			samples: save.samples,
			missionTitle: m.title,
			missionText: m.text,
			missionProgress: missionProgress(save),
			missionGoal: m.goal,
			phase: save.completed.includes("master") && get().hud.phase === "play" ? "complete" : get().hud.phase
		});
		if (gained) schedulePersist();
	}
}));
function schedulePersist() {
	const now = performance.now();
	if (now - persistAt < 800) return;
	persistAt = now;
	useGameStore.getState().persist();
}
function isDiscovered(id) {
	return useGameStore.getState().save.discovered.includes(String(id));
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium transition-colors transition-transform duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent/90",
			outline: "border border-border bg-surface text-fg hover:border-border-strong",
			ghost: "text-fg hover:bg-surface"
		},
		size: {
			default: "h-11 px-5 text-sm",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-6 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Hud({ onPause, onCatalog, onWarp }) {
	const hud = useGameStore((s) => s.hud);
	const xpPct = hud.xpSpan <= 0 ? 100 : Math.max(0, Math.min(100, hud.xpInto / hud.xpSpan * 100));
	const missionPct = hud.missionGoal <= 0 ? 100 : Math.max(0, Math.min(100, hud.missionProgress / hud.missionGoal * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] pr-[max(0.75rem,env(safe-area-inset-right))] pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-min max-w-[min(22rem,72vw)] rounded-lg border border-border bg-surface/90 px-3 py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-2xs tracking-[0.16em] text-muted uppercase",
							children: [
								"Mission · ",
								hud.missionProgress,
								"/",
								hud.missionGoal
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-medium text-fg",
							children: hud.missionTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs leading-snug text-muted",
							children: hud.missionText
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-0.5 overflow-hidden rounded-full bg-surface-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-accent transition-[width] duration-200",
								style: { width: `${missionPct}%` }
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto hidden items-center gap-2 sm:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						onClick: onCatalog,
						"aria-label": "Open catalog",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						onClick: onPause,
						"aria-label": "Pause",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute top-3 left-1/2 w-40 -translate-x-1/2 sm:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between font-mono text-2xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hud.rank }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [Math.round(hud.hull * 100), "%"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 h-1 overflow-hidden rounded-full bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-ok",
						style: { width: `${hud.hull * 100}%` }
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute top-3 left-1/2 hidden w-56 -translate-x-1/2 sm:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between font-mono text-2xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hud.rank }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [hud.xp, " XP"] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 h-1 overflow-hidden rounded-full bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-accent",
						style: { width: `${xpPct}%` }
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 hidden w-56 rounded-lg border border-border bg-surface/90 p-2.5 sm:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid grid-cols-2 gap-x-3 gap-y-1.5 font-mono text-2xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle uppercase tracking-wider",
							children: "Speed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-sm text-fg tabular-nums",
							children: hud.speed.toFixed(0)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle uppercase tracking-wider",
							children: "FPS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-sm text-fg tabular-nums",
							children: hud.fps.toFixed(0)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle uppercase tracking-wider",
							children: "Hull"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "text-sm text-fg tabular-nums",
							children: [Math.round(hud.hull * 100), "%"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle uppercase tracking-wider",
							children: "Boost"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "text-sm text-fg tabular-nums",
							children: [Math.round(hud.boost * 100), "%"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle uppercase tracking-wider",
							children: "Charted"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "text-sm text-fg tabular-nums",
							children: [
								hud.discovered,
								"/",
								hud.total
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle uppercase tracking-wider",
							children: "Credits"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-sm text-fg tabular-nums",
							children: hud.credits
						})] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-1 overflow-hidden rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-ok",
						style: { width: `${hud.hull * 100}%` }
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-24 right-3 hidden max-w-56 rounded-lg border border-border bg-surface/90 p-2.5 md:block",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-[0.14em] text-muted uppercase",
						children: "Nearest"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-fg",
						children: hud.nearestName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs text-subtle",
						children: [
							KIND_LABEL[hud.nearestKind] ?? hud.nearestKind,
							" · ",
							hud.nearestDist.toFixed(0),
							" u"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-mono text-2xs text-muted",
						children: hud.canScan ? hud.scanning ? "Scanning…" : "Hold E / Space to scan" : "Close in to scan"
					})
				]
			}),
			hud.markers.map((m) => {
				if (m.offscreen) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute hidden -translate-x-1/2 -translate-y-1/2 md:block",
					style: {
						left: m.x,
						top: m.y
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `size-1.5 rounded-full ${m.discovered ? "bg-ok" : "bg-accent"}` }), m.dist < 70 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 whitespace-nowrap font-mono text-2xs text-muted",
						children: m.name
					})]
				}, m.id);
			}),
			hud.toastOn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-1/2 left-1/2 w-[min(20rem,80vw)] -translate-x-1/2 -translate-y-1/2 rounded-lg border border-border-strong bg-surface px-4 py-3 text-center shadow-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-fg",
					children: hud.toastTitle
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: hud.toastText
				})]
			}),
			hud.phase === "complete" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute inset-x-0 bottom-28 mx-auto w-[min(24rem,90vw)] rounded-lg border border-border bg-surface p-4 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Atlas complete"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: "Every system is charted. Keep flying if you want."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute right-3 bottom-20 hidden sm:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: onWarp,
					disabled: hud.targetId == null || hud.warping,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "size-3.5" }),
						"Warp ",
						hud.targetName === "None" ? "" : hud.targetName
					]
				})
			})
		]
	});
}
function StartScreen({ onStart }) {
	const save = useGameStore((s) => s.save);
	const returning = save.discovered.length > 0 || save.xp > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-20 flex items-center justify-center bg-bg/55 px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-xl border border-border bg-surface p-6 shadow-2xl sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.22em] text-muted uppercase",
					children: "Ultra X · cosmic survey"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-3xl font-medium tracking-tight text-fg sm:text-4xl",
					children: "Galaxy Atlas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-md text-sm leading-relaxed text-muted",
					children: "Pilot a scout craft through 26 galaxies and 5 black holes. Scan systems, collect stellar samples, and complete the atlas. Stay clear of event horizons."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-5 grid gap-1 font-mono text-2xs text-subtle sm:text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "W / S throttle · A / D yaw · R / F pitch · Shift boost" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Hold E or Space to scan · Q warp · C catalog · P pause" })]
				}),
				returning && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 font-mono text-xs text-accent",
					children: [
						"Saved survey · ",
						save.discovered.length,
						"/31 charted · ",
						save.xp,
						" XP"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						onClick: onStart,
						children: returning ? "Resume expedition" : "Start expedition"
					})
				})
			]
		})
	});
}
function CatalogPanel({ onWarp }) {
	const discovered = useGameStore((s) => s.save.discovered);
	const targetId = useGameStore((s) => s.hud.targetId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-20 flex items-end justify-end bg-bg/40 p-3 sm:items-stretch sm:p-6",
		onClick: () => useGameStore.getState().setCatalogOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-[min(70dvh,36rem)] w-full max-w-md flex-col rounded-xl border border-border bg-surface shadow-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.16em] text-muted uppercase",
					children: "Atlas catalog"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-sm font-medium",
					children: [discovered.length, "/31 charted"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => useGameStore.getState().setCatalogOpen(false),
					children: "Close"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto p-2",
				children: CATALOG.map((b) => {
					const found = discovered.includes(String(b.id));
					const active = targetId === b.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onWarp(b.id),
						className: `flex w-full items-center justify-between rounded-md px-3 py-2 text-left ${active ? "bg-surface-2" : "hover:bg-surface-2/70"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-fg",
							children: found ? b.name : "Uncharted signal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-2xs text-subtle",
							children: [found ? KIND_LABEL[b.kind] : "Unknown", " · warp"]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-1.5 rounded-full ${found ? "bg-ok" : "bg-subtle"}` })]
					}, b.id);
				})
			})]
		})
	});
}
function TouchPad({ onChange, onWarp, onPause, onCatalog }) {
	const stickRef = (0, import_react.useRef)(null);
	const pid = (0, import_react.useRef)(null);
	const scanning = useGameStore((s) => s.hud.scanning);
	const canScan = useGameStore((s) => s.hud.canScan);
	const readStick = (clientX, clientY) => {
		const el = stickRef.current;
		if (!el) return;
		const r = el.getBoundingClientRect();
		const nx = (clientX - (r.left + r.width / 2)) / (r.width * .5);
		const ny = (clientY - (r.top + r.height / 2)) / (r.height * .5);
		const x = Math.max(-1, Math.min(1, nx));
		const y = Math.max(-1, Math.min(1, ny));
		onChange({
			steer: -x,
			throttle: -y
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 sm:hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: stickRef,
				className: "pointer-events-auto absolute bottom-[max(1.25rem,env(safe-area-inset-bottom))] left-[max(1rem,env(safe-area-inset-left))] size-32 rounded-full border border-border bg-surface/70",
				onPointerDown: (e) => {
					pid.current = e.pointerId;
					e.currentTarget.setPointerCapture(e.pointerId);
					readStick(e.clientX, e.clientY);
				},
				onPointerMove: (e) => {
					if (pid.current !== e.pointerId) return;
					readStick(e.clientX, e.clientY);
				},
				onPointerUp: (e) => {
					if (pid.current !== e.pointerId) return;
					pid.current = null;
					onChange({
						steer: 0,
						throttle: 0
					});
				},
				onPointerCancel: () => {
					pid.current = null;
					onChange({
						steer: 0,
						throttle: 0
					});
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-10 rounded-full border border-border-strong" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute right-[max(0.75rem,env(safe-area-inset-right))] bottom-[max(1.25rem,env(safe-area-inset-bottom))] grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-14 rounded-lg border border-border bg-surface/80 text-fg",
						onPointerDown: () => onChange({ pitch: 1 }),
						onPointerUp: () => onChange({ pitch: 0 }),
						onPointerCancel: () => onChange({ pitch: 0 }),
						children: "Up"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `size-14 rounded-lg border border-border bg-surface/80 text-fg ${canScan ? "border-accent" : ""}`,
						onPointerDown: () => onChange({ scan: true }),
						onPointerUp: () => onChange({ scan: false }),
						onPointerCancel: () => onChange({ scan: false }),
						"aria-label": "Scan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scan, { className: `mx-auto size-5 ${scanning ? "text-accent" : ""}` })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-14 rounded-lg border border-border bg-surface/80 text-fg",
						onPointerDown: () => onChange({ pitch: -1 }),
						onPointerUp: () => onChange({ pitch: 0 }),
						onPointerCancel: () => onChange({ pitch: 0 }),
						children: "Dn"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-14 rounded-lg border border-border bg-surface/80 text-fg",
						onPointerDown: () => onChange({ boost: true }),
						onPointerUp: () => onChange({ boost: false }),
						onPointerCancel: () => onChange({ boost: false }),
						children: "Boost"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-14 rounded-lg border border-border bg-surface/80 text-fg",
						onClick: onWarp,
						"aria-label": "Warp",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "mx-auto size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-14 rounded-lg border border-border bg-surface/80 text-fg",
						onClick: onCatalog,
						"aria-label": "Catalog",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, { className: "mx-auto size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pointer-events-auto absolute top-[max(0.75rem,env(safe-area-inset-top))] right-[max(0.75rem,env(safe-area-inset-right))] size-11 rounded-md border border-border bg-surface/80",
				onClick: onPause,
				"aria-label": "Pause",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "mx-auto size-4" })
			})
		]
	});
}
function PauseOverlay({ onResume, onReset }) {
	const muted = useGameStore((s) => s.hud.muted);
	const save = useGameStore((s) => s.save);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 grid place-items-center bg-bg/70 px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm rounded-xl border border-border bg-surface p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
					children: "Paused"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-xl font-medium",
					children: "Survey hold"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						save.discovered.length,
						"/31 charted · ",
						save.xp,
						" XP · rank saved locally"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: onResume,
							children: "Resume"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => useGameStore.getState().toggleMute(),
							children: [muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }), muted ? "Unmute" : "Mute"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: onReset,
							children: "Reset progress"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-mono text-2xs leading-relaxed text-subtle",
					children: "W throttle · A left · D right · R/F pitch · Shift boost · E scan · Q warp"
				})
			]
		})
	});
}
function GameRoot() {
	const canvasRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [fail, setFail] = (0, import_react.useState)(null);
	const phase = useGameStore((s) => s.hud.phase);
	const catalogOpen = useGameStore((s) => s.catalogOpen);
	(0, import_react.useEffect)(() => {
		useGameStore.getState().load();
		let disposed = false;
		const canvas = canvasRef.current;
		if (!canvas) return;
		let onHide = null;
		import("./engine-BUxbc0KM.mjs").then(({ AtlasEngine }) => {
			if (disposed || !canvas) return;
			const engine = new AtlasEngine(canvas);
			engineRef.current = engine;
			setReady(true);
			onHide = () => {
				if (document.hidden) useGameStore.getState().persist();
			};
			document.addEventListener("visibilitychange", onHide);
		}).catch((err) => {
			setFail(err instanceof Error ? err.message : "WebGL failed to start");
		});
		return () => {
			disposed = true;
			if (onHide) document.removeEventListener("visibilitychange", onHide);
			engineRef.current?.dispose();
			engineRef.current = null;
			useGameStore.getState().persist();
		};
	}, []);
	const start = () => {
		unlockAudio();
		startDrone();
		engineRef.current?.startExpedition();
	};
	const warpTo = (id) => {
		engineRef.current?.warpTo(id);
		engineRef.current?.setTarget(id);
		useGameStore.getState().setCatalogOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none",
				"aria-label": "Galaxy Atlas 3D view"
			}),
			fail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-30 grid place-items-center bg-bg p-6 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-md rounded-xl border border-border bg-surface p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-lg font-medium",
						children: "Atlas cannot start"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: fail
					})]
				})
			}),
			ready && phase === "attract" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartScreen, { onStart: start }),
			ready && phase !== "attract" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {
				onPause: () => engineRef.current?.togglePause(),
				onCatalog: () => useGameStore.getState().setCatalogOpen(!catalogOpen),
				onWarp: () => {
					const id = useGameStore.getState().hud.targetId;
					if (id != null) warpTo(id);
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchPad, {
				onChange: (t) => engineRef.current?.setTouch(t),
				onWarp: () => {
					const id = useGameStore.getState().hud.targetId ?? 0;
					warpTo(id);
				},
				onPause: () => engineRef.current?.togglePause(),
				onCatalog: () => useGameStore.getState().setCatalogOpen(!catalogOpen)
			})] }),
			catalogOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogPanel, { onWarp: warpTo }),
			phase === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseOverlay, {
				onResume: () => engineRef.current?.setPaused(false),
				onReset: () => {
					useGameStore.getState().resetProgress();
					engineRef.current?.startExpedition();
				}
			})
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameRoot, {});
}
//#endregion
export { sfxScan as a, CATALOG as c, pulseDrone as i, isDiscovered as n, sfxWarn as o, useGameStore as r, sfxWarp as s, routes_exports as t };
