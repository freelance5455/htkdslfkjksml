import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, W as isRedirect, b as useRouter, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as CodeXml, E as Briefcase, S as Copy, T as Calculator, _ as ListChecks, b as GraduationCap, c as Send, d as RefreshCw, f as Plus, g as Menu, h as MessageSquare, i as Volume2, l as Search, m as Mic, n as Wrench, o as Trash2, p as PenLine, r as WandSparkles, s as Sparkles, t as X, u as Scan, v as Languages, w as Check, x as Download, y as ImagePlus } from "../_libs/lucide-react.mjs";
import { a as errorCopy, i as drawLv99, n as Route, r as askLv99 } from "./router-DoojfGY6.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B8yzkPhC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
/** Deterministic helpers. These are not AI — answers are computed on device. */
var BN_DIGITS = "০১২৩৪৫৬৭৮৯";
function normalizeDigits(input) {
	return input.replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
}
function formatNumber(n) {
	if (!Number.isFinite(n)) return null;
	const rounded = Math.round(n * 1e8) / 1e8;
	return new Intl.NumberFormat("bn-BD", { maximumFractionDigits: 8 }).format(rounded);
}
function soften(raw) {
	let s = normalizeDigits(raw).trim();
	s = s.replace(/[?？!！।]+$/g, "").trim();
	s = s.replace(/^(?:বলো|বলুন|calculate|what is|what's|কত)\s+/i, "");
	s = s.replace(/\s*(?:কত|কতো|হয়|হবে)\s*$/i, "");
	return s.replace(/\s+/g, " ").trim();
}
function tokenize(input) {
	const s = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/\s+/g, "");
	if (!s || !/^[\d.+\-*/%^()a-z]+$/i.test(s)) return null;
	const out = [];
	let i = 0;
	while (i < s.length) {
		const ch = s[i];
		if (/[0-9.]/.test(ch)) {
			let j = i + 1;
			while (j < s.length && /[0-9.]/.test(s[j])) j++;
			const num = Number(s.slice(i, j));
			if (!Number.isFinite(num)) return null;
			out.push(num);
			i = j;
			continue;
		}
		if (/[a-z]/i.test(ch)) {
			let j = i + 1;
			while (j < s.length && /[a-z]/i.test(s[j])) j++;
			out.push(s.slice(i, j).toLowerCase());
			i = j;
			continue;
		}
		out.push(ch);
		i++;
	}
	return out;
}
function evalMath(expr) {
	const tokens = tokenize(expr);
	if (!tokens || tokens.length === 0) return null;
	let i = 0;
	const peek = () => tokens[i];
	const eat = () => tokens[i++];
	function parseAdd() {
		let left = parseMul();
		while (peek() === "+" || peek() === "-") {
			const op = eat();
			const right = parseMul();
			left = op === "+" ? left + right : left - right;
		}
		return left;
	}
	function parseMul() {
		let left = parsePow();
		while (peek() === "*" || peek() === "/") {
			const op = eat();
			const right = parsePow();
			if (op === "/" && right === 0) throw new Error("div0");
			left = op === "*" ? left * right : left / right;
		}
		return left;
	}
	function parsePow() {
		const base = parseUnary();
		if (peek() === "^") {
			eat();
			return base ** parsePow();
		}
		return base;
	}
	function parseUnary() {
		if (peek() === "+") {
			eat();
			return parseUnary();
		}
		if (peek() === "-") {
			eat();
			return -parseUnary();
		}
		if (peek() === "sqrt" || peek() === "abs") {
			const fn = eat();
			const inner = parseUnary();
			return fn === "sqrt" ? Math.sqrt(inner) : Math.abs(inner);
		}
		if (peek() === "(") {
			eat();
			const v = parseAdd();
			if (eat() !== ")") throw new Error("paren");
			return percent(v);
		}
		if (typeof peek() === "number") return percent(eat());
		throw new Error("token");
	}
	function percent(n) {
		if (peek() === "%") {
			eat();
			return n / 100;
		}
		return n;
	}
	try {
		const value = parseAdd();
		if (i !== tokens.length || !Number.isFinite(value)) return null;
		return value;
	} catch {
		return null;
	}
}
var LENGTH$1 = {
	mm: .001,
	cm: .01,
	m: 1,
	km: 1e3,
	inch: .0254,
	ft: .3048,
	mi: 1609.344
};
var WEIGHT$1 = {
	mg: .001,
	g: 1,
	kg: 1e3,
	lb: 453.59237,
	oz: 28.3495
};
var VOLUME = {
	ml: 1,
	l: 1e3,
	gal: 3785.411784
};
var DATA = {
	b: 1,
	kb: 1024,
	mb: 1024 ** 2,
	gb: 1024 ** 3
};
/** Dhaka customary land measure. Other districts differ — answers say so. */
var LAND_SQFT = {
	sqft: 1,
	shotok: 435.6,
	katha: 720,
	bigha: 14400,
	acre: 43560
};
var UNIT_ALIAS = {
	mm: {
		dim: "len",
		id: "mm"
	},
	millimeter: {
		dim: "len",
		id: "mm"
	},
	মিলিমিটার: {
		dim: "len",
		id: "mm"
	},
	cm: {
		dim: "len",
		id: "cm"
	},
	centimeter: {
		dim: "len",
		id: "cm"
	},
	সেন্টিমিটার: {
		dim: "len",
		id: "cm"
	},
	সেমি: {
		dim: "len",
		id: "cm"
	},
	m: {
		dim: "len",
		id: "m"
	},
	meter: {
		dim: "len",
		id: "m"
	},
	metre: {
		dim: "len",
		id: "m"
	},
	মিটার: {
		dim: "len",
		id: "m"
	},
	km: {
		dim: "len",
		id: "km"
	},
	kilometer: {
		dim: "len",
		id: "km"
	},
	kilometre: {
		dim: "len",
		id: "km"
	},
	কিমি: {
		dim: "len",
		id: "km"
	},
	কিলোমিটার: {
		dim: "len",
		id: "km"
	},
	inch: {
		dim: "len",
		id: "inch"
	},
	in: {
		dim: "len",
		id: "inch"
	},
	ইঞ্চি: {
		dim: "len",
		id: "inch"
	},
	ft: {
		dim: "len",
		id: "ft"
	},
	foot: {
		dim: "len",
		id: "ft"
	},
	feet: {
		dim: "len",
		id: "ft"
	},
	ফুট: {
		dim: "len",
		id: "ft"
	},
	mi: {
		dim: "len",
		id: "mi"
	},
	mile: {
		dim: "len",
		id: "mi"
	},
	miles: {
		dim: "len",
		id: "mi"
	},
	মাইল: {
		dim: "len",
		id: "mi"
	},
	mg: {
		dim: "w",
		id: "mg"
	},
	g: {
		dim: "w",
		id: "g"
	},
	gram: {
		dim: "w",
		id: "g"
	},
	গ্রাম: {
		dim: "w",
		id: "g"
	},
	kg: {
		dim: "w",
		id: "kg"
	},
	kilogram: {
		dim: "w",
		id: "kg"
	},
	কেজি: {
		dim: "w",
		id: "kg"
	},
	কিলোগ্রাম: {
		dim: "w",
		id: "kg"
	},
	lb: {
		dim: "w",
		id: "lb"
	},
	pound: {
		dim: "w",
		id: "lb"
	},
	পাউন্ড: {
		dim: "w",
		id: "lb"
	},
	oz: {
		dim: "w",
		id: "oz"
	},
	ounce: {
		dim: "w",
		id: "oz"
	},
	ml: {
		dim: "vol",
		id: "ml"
	},
	millilitre: {
		dim: "vol",
		id: "ml"
	},
	মিলি: {
		dim: "vol",
		id: "ml"
	},
	l: {
		dim: "vol",
		id: "l"
	},
	liter: {
		dim: "vol",
		id: "l"
	},
	litre: {
		dim: "vol",
		id: "l"
	},
	লিটার: {
		dim: "vol",
		id: "l"
	},
	gal: {
		dim: "vol",
		id: "gal"
	},
	gallon: {
		dim: "vol",
		id: "gal"
	},
	গ্যালন: {
		dim: "vol",
		id: "gal"
	},
	b: {
		dim: "data",
		id: "b"
	},
	byte: {
		dim: "data",
		id: "b"
	},
	kb: {
		dim: "data",
		id: "kb"
	},
	mb: {
		dim: "data",
		id: "mb"
	},
	gb: {
		dim: "data",
		id: "gb"
	},
	c: {
		dim: "temp",
		id: "c"
	},
	celcius: {
		dim: "temp",
		id: "c"
	},
	celsius: {
		dim: "temp",
		id: "c"
	},
	সেলসিয়াস: {
		dim: "temp",
		id: "c"
	},
	f: {
		dim: "temp",
		id: "f"
	},
	fahrenheit: {
		dim: "temp",
		id: "f"
	},
	ফারেনহাইট: {
		dim: "temp",
		id: "f"
	},
	k: {
		dim: "temp",
		id: "k"
	},
	kelvin: {
		dim: "temp",
		id: "k"
	},
	sqft: {
		dim: "land",
		id: "sqft"
	},
	বর্গফুট: {
		dim: "land",
		id: "sqft"
	},
	shotok: {
		dim: "land",
		id: "shotok"
	},
	decimal: {
		dim: "land",
		id: "shotok"
	},
	শতাংশ: {
		dim: "land",
		id: "shotok"
	},
	শতক: {
		dim: "land",
		id: "shotok"
	},
	katha: {
		dim: "land",
		id: "katha"
	},
	কাঠা: {
		dim: "land",
		id: "katha"
	},
	bigha: {
		dim: "land",
		id: "bigha"
	},
	বিঘা: {
		dim: "land",
		id: "bigha"
	},
	acre: {
		dim: "land",
		id: "acre"
	},
	একর: {
		dim: "land",
		id: "acre"
	}
};
var TABLES = {
	len: LENGTH$1,
	w: WEIGHT$1,
	vol: VOLUME,
	data: DATA,
	land: LAND_SQFT
};
function lookupUnit(raw) {
	return UNIT_ALIAS[raw.trim().toLowerCase().replace(/°/g, "")] ?? UNIT_ALIAS[raw.trim()] ?? null;
}
function convertTemp(value, from, to) {
	const toC = (v, u) => u === "c" ? v : u === "f" ? (v - 32) * 5 / 9 : v - 273.15;
	const fromC = (c, u) => u === "c" ? c : u === "f" ? c * 9 / 5 + 32 : c + 273.15;
	if (![
		"c",
		"f",
		"k"
	].includes(from) || ![
		"c",
		"f",
		"k"
	].includes(to)) return null;
	return fromC(toC(value, from), to);
}
function tryUnit(s) {
	const m = s.match(/^(-?[\d.]+)\s*([^\d\s]+)\s*(?:to|in|into|কে|এ|থেকে|হলে|→|->|=)?\s*([^\d\s]+)$/i);
	if (!m) return null;
	const value = Number(m[1]);
	const from = lookupUnit(m[2] ?? "");
	const to = lookupUnit(m[3] ?? "");
	if (!from || !to || from.dim !== to.dim || !Number.isFinite(value)) return null;
	let out;
	if (from.dim === "temp") {
		const t = convertTemp(value, from.id, to.id);
		if (t === null) return null;
		out = t;
	} else {
		const table = TABLES[from.dim];
		out = value * table[from.id] / table[to.id];
	}
	const pretty = formatNumber(out);
	if (!pretty) return null;
	const note = from.dim === "land" ? "\n\nঢাকার প্রচলিত হিসাব: ১ কাঠা = ৭২০ বর্গফুট, ১ বিঘা = ২০ কাঠা। অন্য এলাকায় কাঠা আলাদা হতে পারে।" : "";
	return `তাৎক্ষণিক রূপান্তর (অনলাইন AI নয়)\n\n${formatNumber(value)} ${m[2]} = ${pretty} ${m[3]}${note}`;
}
function tryPercent(s) {
	const of = s.match(/^([\d.]+)\s*%\s*(?:of|এর)\s*([\d.]+)$/i);
	if (of) {
		const p = Number(of[1]);
		const base = Number(of[2]);
		const pretty = formatNumber(base * p / 100);
		return pretty ? `তাৎক্ষণিক হিসাব (অনলাইন AI নয়)\n\n${formatNumber(base)}-এর ${formatNumber(p)}% = ${pretty}` : null;
	}
	const rev = s.match(/^([\d.]+)\s*(?:টাকার|টাকায়|এর)\s*([\d.]+)\s*%$/i);
	if (rev) {
		const base = Number(rev[1]);
		const p = Number(rev[2]);
		const pretty = formatNumber(base * p / 100);
		return pretty ? `তাৎক্ষণিক হিসাব (অনলাইন AI নয়)\n\n${formatNumber(base)}-এর ${formatNumber(p)}% = ${pretty}` : null;
	}
	const off = s.match(/^([\d.]+)\s*(?:টাকায়|টাকার|টাকা)?\s*([\d.]+)\s*%\s*(?:ছাড়|discount)$/i);
	if (off) {
		const base = Number(off[1]);
		const saved = base * Number(off[2]) / 100;
		const pay = base - saved;
		const a = formatNumber(saved);
		const b = formatNumber(pay);
		return a && b ? `তাৎক্ষণিক হিসাব (অনলাইন AI নয়)\n\nছাড় ${a}। দিতে হবে ${b}।` : null;
	}
	return null;
}
function tryExpression(s) {
	if (!/^[\d.\s+\-*/%^()a-z×÷]+$/i.test(s)) return null;
	if (!/\d/.test(s)) return null;
	const value = evalMath(s);
	if (value === null) return null;
	const pretty = formatNumber(value);
	if (!pretty) return null;
	return `তাৎক্ষণিক হিসাব (অনলাইন AI নয়)\n\n= ${pretty}`;
}
/** Returns a full reply when the message can be answered without the model. */
function tryLocal(raw) {
	const s = soften(raw);
	if (!s || s.length > 200) return null;
	return tryPercent(s) ?? tryUnit(s) ?? tryExpression(s);
}
function countText(text) {
	const chars = [...text].length;
	const charsNoSpace = [...text.replace(/\s/g, "")].length;
	const words = text.trim() ? text.trim().split(/\s+/).length : 0;
	const lines = text ? text.split(/\r?\n/).length : 0;
	const minutes = Math.max(1, Math.round(words / 180));
	return {
		chars,
		charsNoSpace,
		words,
		lines,
		minutes: words === 0 ? 0 : minutes
	};
}
function utf8ToBase64(text) {
	const bytes = new TextEncoder().encode(text);
	let bin = "";
	for (const b of bytes) bin += String.fromCharCode(b);
	return btoa(bin);
}
function base64ToUtf8(b64) {
	const bin = atob(b64.trim());
	const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
	return new TextDecoder().decode(bytes);
}
function prettyJson(text) {
	try {
		return {
			ok: true,
			text: JSON.stringify(JSON.parse(text), null, 2)
		};
	} catch {
		return {
			ok: false,
			error: "এটি বৈধ JSON নয়।"
		};
	}
}
function makePassword(length, symbols) {
	const alphabet = symbols ? "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*" : "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
	const buf = new Uint32Array(Math.min(64, Math.max(8, Math.round(length))));
	crypto.getRandomValues(buf);
	return Array.from(buf, (n) => alphabet[n % alphabet.length]).join("");
}
function dateSpan(from, to) {
	const a = /* @__PURE__ */ new Date(`${from}T00:00:00`);
	const b = /* @__PURE__ */ new Date(`${to}T00:00:00`);
	if (Number.isNaN(a.getTime()) || Number.isNaN(b.getTime())) return null;
	const ms = b.getTime() - a.getTime();
	const days = Math.round(ms / 864e5);
	const sign = days < 0 ? "আগে" : "পরে";
	const abs = Math.abs(days);
	const weeks = Math.floor(abs / 7);
	const rem = abs % 7;
	return `${formatNumber(abs)} দিন (${formatNumber(weeks)} সপ্তাহ ${formatNumber(rem)} দিন)। শেষ তারিখটি প্রথমটির ${sign}।`;
}
var MODES = [
	{
		id: "chat",
		label: "চ্যাট",
		hint: "যেকোনো প্রশ্ন"
	},
	{
		id: "code",
		label: "কোড",
		hint: "লিখো, ঠিক করো"
	},
	{
		id: "write",
		label: "লেখা",
		hint: "গুছিয়ে লেখো"
	},
	{
		id: "translate",
		label: "অনুবাদ",
		hint: "বাংলা ↔ ইংরেজি"
	},
	{
		id: "study",
		label: "পড়াশোনা",
		hint: "সহজ ব্যাখ্যা"
	},
	{
		id: "math",
		label: "গণিত",
		hint: "ধাপে ধাপে"
	},
	{
		id: "plan",
		label: "পরিকল্পনা",
		hint: "কাজ ভাগো"
	},
	{
		id: "business",
		label: "ব্যবসা",
		hint: "আইডিয়া ও হিসাব"
	},
	{
		id: "vision",
		label: "ছবি",
		hint: "ছবি বুঝে বলো"
	},
	{
		id: "imagine",
		label: "আঁকো",
		hint: "নতুন ছবি বানাও"
	}
];
var QUICK = {
	chat: ["আজকের দিনটা গুছিয়ে সাজাও", "একটা কঠিন বিষয় সহজে বুঝিয়ে দাও"],
	code: ["এই এররটা কেন হচ্ছে বলো", "একটা ছোট ফাংশন লিখে দাও"],
	write: ["এই লেখাটা আরও শক্ত করো", "একটা ছোট ইমেইল লিখে দাও"],
	translate: ["এটা স্বাভাবিক ইংরেজিতে অনুবাদ করো", "এটা সহজ বাংলায় অনুবাদ করো"],
	study: ["একটা উদাহরণ দিয়ে বুঝিয়ে দাও", "আমাকে ৩টা প্রশ্ন করে যাচাই করো"],
	math: ["ধাপে ধাপে সমাধান করো", "কোথায় ভুল হচ্ছে দেখাও"],
	plan: ["৭ দিনের পরিকল্পনা বানাও", "কাজগুলো অগ্রাধিকার দাও"],
	business: ["এই আইডিয়ার ঝুঁকি কী", "গ্রাহক কারা হতে পারে"],
	vision: ["ছবিতে কী আছে বাংলায় বলো", "ছবির লেখাটা তুলে দাও"],
	imagine: ["একটি শান্ত নদীর সন্ধ্যা, বাস্তব ছবির মতো", "নীল ও সোনালি রঙের একটি সাদাসিধে লোগো"]
};
var GREETING = "আসসালামু আলাইকুম! আমি LV99 AI। বাংলায় প্রশ্ন করো, ছবি পাঠিয়ে সেটি বুঝতে বলো, অথবা মাইক্রোফোনে কথা বলো। হিসাব, একক আর জমির কাঠা-শতাংশ তাৎক্ষণিকভাবেও করতে পারি।";
function greeting() {
	return {
		id: "greet",
		role: "assistant",
		text: GREETING
	};
}
function homeDeck() {
	return {
		activeId: "home",
		depth: "normal",
		lang: "auto",
		threads: [{
			id: "home",
			title: "নতুন কথা",
			updatedAt: 0,
			mode: "chat",
			messages: [greeting()]
		}]
	};
}
var MODE_IDS = new Set(MODES.map((m) => m.id));
function isMsg(v) {
	if (!v || typeof v !== "object") return false;
	const m = v;
	return typeof m.id === "string" && (m.role === "user" || m.role === "assistant") && typeof m.text === "string" && m.text.length < 2e4;
}
function parseDeck(raw) {
	try {
		const data = JSON.parse(raw);
		if (!Array.isArray(data.threads) || data.threads.length === 0) return null;
		const threads = [];
		for (const item of data.threads.slice(0, 30)) {
			if (!item || typeof item !== "object") return null;
			const t = item;
			if (typeof t.id !== "string" || typeof t.title !== "string" || !Array.isArray(t.messages)) return null;
			if (!MODE_IDS.has(t.mode)) return null;
			const messages = t.messages.filter(isMsg).slice(-80);
			if (messages.length === 0) continue;
			threads.push({
				id: t.id,
				title: t.title.slice(0, 80),
				updatedAt: typeof t.updatedAt === "number" ? t.updatedAt : 0,
				mode: t.mode,
				messages: messages.map((m) => ({
					id: m.id,
					role: m.role,
					text: m.text,
					thumb: typeof m.thumb === "string" && m.thumb.length < 18e4 ? m.thumb : void 0,
					generatedUrl: typeof m.generatedUrl === "string" ? m.generatedUrl.slice(0, 4e3) : void 0,
					error: m.error === true
				}))
			});
		}
		if (threads.length === 0) return null;
		return {
			threads,
			activeId: threads.some((t) => t.id === data.activeId) ? data.activeId : threads[0].id,
			depth: data.depth === "brief" || data.depth === "deep" ? data.depth : "normal",
			lang: data.lang === "bn" || data.lang === "en" ? data.lang : "auto"
		};
	} catch {
		return null;
	}
}
var STORAGE_KEY = "lv99-ai-deck-v1";
function Inline({ text }) {
	const re = /(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^\s)]+\))/g;
	const nodes = [];
	let last = 0;
	let match;
	let key = 0;
	while (match = re.exec(text)) {
		if (match.index > last) nodes.push(text.slice(last, match.index));
		const token = match[0];
		if (token.startsWith("**")) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-semibold",
			children: token.slice(2, -2)
		}, key++));
		else if (token.startsWith("`")) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "rounded-md bg-ink px-1.5 py-0.5",
			children: token.slice(1, -1)
		}, key++));
		else {
			const link = token.match(/^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/);
			if (link) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: link[2],
				target: "_blank",
				rel: "noreferrer",
				className: "underline decoration-gold underline-offset-2",
				children: link[1]
			}, key++));
		}
		last = match.index + token.length;
	}
	if (last < text.length) nodes.push(text.slice(last));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: nodes });
}
function CodeBlock({ code }) {
	const [done, setDone] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl border border-line bg-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-end border-b border-line px-2 py-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs text-muted hover:text-fg",
				onClick: () => {
					navigator.clipboard.writeText(code).then(() => {
						setDone(true);
						window.setTimeout(() => setDone(false), 1200);
					});
				},
				children: [done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), done ? "কপি হয়েছে" : "কপি"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "overflow-x-auto p-3 text-sm leading-relaxed",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: code.replace(/\n$/, "") })
		})]
	});
}
function RichText({ text }) {
	const chunks = text.split(/```/);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 leading-relaxed",
		children: chunks.map((chunk, index) => {
			if (index % 2 === 1) {
				const nl = chunk.indexOf("\n");
				const code = nl === -1 ? chunk : chunk.slice(nl + 1);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code }, index);
			}
			const lines = chunk.split("\n");
			const blocks = [];
			let list = [];
			const flush = (key) => {
				if (list.length === 0) return;
				blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "list-disc space-y-1 pl-5",
					children: list.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inline, { text: item }) }, i))
				}, key));
				list = [];
			};
			lines.forEach((line, lineIndex) => {
				const bullet = line.match(/^\s*(?:[-*]|\d+[.)])\s+(.*)$/);
				if (bullet) {
					list.push(bullet[1] ?? "");
					return;
				}
				flush(`l-${lineIndex}`);
				if (!line.trim()) return;
				const head = line.match(/^(#{1,3})\s+(.*)$/);
				if (head) {
					blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inline, { text: head[2] ?? "" })
					}, lineIndex));
					return;
				}
				blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inline, { text: line }) }, lineIndex));
			});
			flush("end");
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: blocks
			}, index);
		})
	});
}
var field = "w-full rounded-xl border border-line bg-ink px-3 py-3 text-base text-fg outline-none focus-visible:border-cobalt";
function Card({ title, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 space-y-3",
				children
			})
		]
	});
}
function Result({ text }) {
	if (!text) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-3 rounded-xl bg-ink px-3 py-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "whitespace-pre-wrap leading-relaxed",
			children: text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "inline-flex size-11 shrink-0 items-center justify-center rounded-xl text-muted hover:text-fg",
			"aria-label": "ফলাফল কপি",
			onClick: () => {
				navigator.clipboard.writeText(text);
				toast("কপি হয়েছে");
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
		})]
	});
}
var LENGTH = [
	["mm", "মিলিমিটার"],
	["cm", "সেমি"],
	["m", "মিটার"],
	["km", "কিলোমিটার"],
	["ft", "ফুট"],
	["inch", "ইঞ্চি"],
	["mi", "মাইল"]
];
var WEIGHT = [
	["g", "গ্রাম"],
	["kg", "কেজি"],
	["lb", "পাউন্ড"]
];
var LAND = [
	["shotok", "শতাংশ"],
	["katha", "কাঠা"],
	["bigha", "বিঘা"],
	["acre", "একর"],
	["sqft", "বর্গফুট"]
];
function ToolsPanel() {
	const [expr, setExpr] = (0, import_react.useState)(" (১২+৮)*৩ ");
	const math = (0, import_react.useMemo)(() => {
		const cleaned = expr.trim();
		if (!cleaned) return "";
		const hit = tryLocal(cleaned);
		return hit ? hit.replace(/^তাৎক্ষণিক হিসাব \(অনলাইন AI নয়\)\n\n/, "") : "এই অঙ্কটা পড়া যায়নি। যেমন (12+8)*3";
	}, [expr]);
	const [base, setBase] = (0, import_react.useState)("500");
	const [pct, setPct] = (0, import_react.useState)("15");
	const [pctMode, setPctMode] = (0, import_react.useState)("of");
	const [amount, setAmount] = (0, import_react.useState)("5");
	const [group, setGroup] = (0, import_react.useState)("land");
	const options = group === "len" ? LENGTH : group === "w" ? WEIGHT : LAND;
	const [fromU, setFromU] = (0, import_react.useState)("katha");
	const [toU, setToU] = (0, import_react.useState)("shotok");
	const [fromDate, setFromDate] = (0, import_react.useState)("");
	const [toDate, setToDate] = (0, import_react.useState)("");
	const [sample, setSample] = (0, import_react.useState)("LV99 AI এখন আরও শক্তিশালী। হিসাব, ছবি, ভয়েস — সব এক জায়গায়।");
	const [blob, setBlob] = (0, import_react.useState)("{\"নাম\":\"LV99\"}");
	const [codec, setCodec] = (0, import_react.useState)("pretty");
	const [secret, setSecret] = (0, import_react.useState)("");
	const [len, setLen] = (0, import_react.useState)(16);
	const [symbols, setSymbols] = (0, import_react.useState)(true);
	const percentText = (0, import_react.useMemo)(() => {
		const b = Number(base);
		const p = Number(pct);
		if (!Number.isFinite(b) || !Number.isFinite(p)) return "সংখ্যা দাও।";
		if (pctMode === "of") return `${formatNumber(b)}-এর ${formatNumber(p)}% = ${formatNumber(b * p / 100)}`;
		if (pctMode === "off") {
			const saved = b * p / 100;
			return `ছাড় ${formatNumber(saved)}। দিতে হবে ${formatNumber(b - saved)}।`;
		}
		return `বাড়লে হবে ${formatNumber(b + b * p / 100)}।`;
	}, [
		base,
		pct,
		pctMode
	]);
	const unitText = (0, import_react.useMemo)(() => {
		const n = Number(amount);
		if (!Number.isFinite(n)) return "";
		const hit = tryLocal(`${n} ${fromU} to ${toU}`);
		return hit ? hit.replace(/^তাৎক্ষণিক রূপান্তর \(অনলাইন AI নয়\)\n\n/, "") : "";
	}, [
		amount,
		fromU,
		toU
	]);
	const stats = countText(sample);
	const dates = fromDate && toDate ? dateSpan(fromDate, toDate) : "";
	const transformed = (0, import_react.useMemo)(() => {
		if (codec === "pretty") {
			const res = prettyJson(blob);
			return res.ok ? res.text : res.error;
		}
		if (codec === "b64") try {
			return blob.trim().match(/^[A-Za-z0-9+/=]+$/) && blob.trim().length % 4 === 0 ? base64ToUtf8(blob) : utf8ToBase64(blob);
		} catch {
			return "Base64 পড়া যায়নি।";
		}
		const lines = blob.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
		return Array.from(new Set(lines)).sort((a, b) => a.localeCompare(b, "bn")).join("\n");
	}, [blob, codec]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "scroll-thin flex-1 overflow-y-auto px-4 py-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-5xl gap-3 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "হিসাব",
					hint: "যোগ, বিয়োগ, শতাংশ, বর্গমূল। বাংলা সংখ্যা চলে।",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: expr,
						onChange: (e) => setExpr(e.target.value),
						"aria-label": "অঙ্ক"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, { text: math.replace(/^তাৎক্ষণিক হিসাব \(অনলাইন AI নয়\)\n\n/, "") })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "শতাংশ ও ছাড়",
					hint: "কত টাকা, কত ছাড়, কত বাড়ল।",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: field,
								inputMode: "decimal",
								value: base,
								onChange: (e) => setBase(e.target.value),
								"aria-label": "মূল সংখ্যা"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: field,
								inputMode: "decimal",
								value: pct,
								onChange: (e) => setPct(e.target.value),
								"aria-label": "শতাংশ"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								["of", "এর শতাংশ"],
								["off", "ছাড়"],
								["up", "বাড়তি"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPctMode(id),
								className: "min-h-11 rounded-xl border px-2 text-sm " + (pctMode === id ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line bg-ink text-muted"),
								children: label
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, { text: percentText })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "একক ও জমি",
					hint: "কাঠা, শতাংশ, বিঘা — ঢাকার ৭২০ বর্গফুট হিসাব।",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								["land", "জমি"],
								["len", "দৈর্ঘ্য"],
								["w", "ওজন"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-xl border text-sm " + (group === id ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line bg-ink text-muted"),
								onClick: () => {
									setGroup(id);
									const next = id === "land" ? LAND : id === "len" ? LENGTH : WEIGHT;
									setFromU(next[0][0]);
									setToU(next[1][0]);
								},
								children: label
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							inputMode: "decimal",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							"aria-label": "পরিমাণ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: field,
								value: fromU,
								onChange: (e) => setFromU(e.target.value),
								"aria-label": "থেকে",
								children: options.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: id,
									children: label
								}, id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: field,
								value: toU,
								onChange: (e) => setToU(e.target.value),
								"aria-label": "এ",
								children: options.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: id,
									children: label
								}, id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, { text: unitText.replace(/^তাৎক্ষণিক রূপান্তর \(অনলাইন AI নয়\)\n\n/, "") })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "তারিখের ফারাক",
					hint: "দুই তারিখের মাঝে কত দিন।",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							type: "date",
							value: fromDate,
							onChange: (e) => setFromDate(e.target.value),
							"aria-label": "শুরু"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							type: "date",
							value: toDate,
							onChange: (e) => setToDate(e.target.value),
							"aria-label": "শেষ"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, { text: dates ?? "" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "লেখার হিসাব",
					hint: "শব্দ, অক্ষর, পড়ার সময়।",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: field + " min-h-28",
						value: sample,
						onChange: (e) => setSample(e.target.value),
						"aria-label": "লেখা"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, { text: `${formatNumber(stats.words)} শব্দ · ${formatNumber(stats.chars)} অক্ষর · ${formatNumber(stats.lines)} লাইন · পড়তে প্রায় ${formatNumber(stats.minutes)} মিনিট` })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "JSON, Base64, তালিকা",
					hint: "গুছিয়ে নাও, এনকোড করো, ডুপ্লিকেট বাদ দাও।",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								["pretty", "JSON"],
								["b64", "Base64"],
								["lines", "তালিকা"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCodec(id),
								className: "min-h-11 rounded-xl border text-sm " + (codec === id ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line bg-ink text-muted"),
								children: label
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: field + " min-h-28 font-mono text-sm",
							value: blob,
							onChange: (e) => setBlob(e.target.value),
							"aria-label": "টেক্সট"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, { text: transformed })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "পাসওয়ার্ড",
					hint: "এই ডিভাইসেই তৈরি। কোথাও পাঠানো হয় না।",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center justify-between gap-3 text-sm text-muted",
							children: [
								"দৈর্ঘ্য ",
								len,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									min: 8,
									max: 48,
									value: len,
									onChange: (e) => setLen(Number(e.target.value)),
									className: "w-40 accent-cobalt"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: symbols,
								onChange: (e) => setSymbols(e.target.checked)
							}), "চিহ্ন রাখো"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-xl bg-cobalt px-4 text-sm font-semibold text-on-cobalt",
							onClick: () => setSecret(makePassword(len, symbols)),
							children: "নতুন পাসওয়ার্ড"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, { text: secret })
					]
				})
			]
		})
	});
}
var MODE_ICON = {
	chat: MessageSquare,
	code: CodeXml,
	write: PenLine,
	translate: Languages,
	study: GraduationCap,
	math: Calculator,
	plan: ListChecks,
	business: Briefcase,
	vision: Scan,
	imagine: WandSparkles
};
function uid() {
	return crypto.randomUUID();
}
async function fileToImage(file) {
	const bitmap = await createImageBitmap(file);
	const width = bitmap.width;
	const height = bitmap.height;
	const draw = (max, quality) => {
		const scale = Math.min(1, max / Math.max(width, height));
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.round(width * scale));
		canvas.height = Math.max(1, Math.round(height * scale));
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("canvas");
		ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
		return canvas.toDataURL("image/jpeg", quality);
	};
	let dataUrl = draw(1280, .78);
	if (dataUrl.length > 24e5) dataUrl = draw(1024, .62);
	const thumb = draw(320, .66);
	bitmap.close();
	if (dataUrl.length > 25e5) throw new Error("large");
	return {
		kind: "image",
		name: file.name || "ছবি",
		dataUrl,
		thumb,
		width,
		height
	};
}
function Studio({ ready }) {
	const ask = useServerFn(askLv99);
	const draw = useServerFn(drawLv99);
	const [deck, setDeck] = (0, import_react.useState)(homeDeck);
	const [tab, setTab] = (0, import_react.useState)("chat");
	const [query, setQuery] = (0, import_react.useState)("");
	const [drawer, setDrawer] = (0, import_react.useState)(false);
	const [input, setInput] = (0, import_react.useState)("");
	const [attachment, setAttachment] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("AI সহকারী");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(null);
	const [showPower, setShowPower] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	const recRef = (0, import_react.useRef)(null);
	const endRef = (0, import_react.useRef)(null);
	const images = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	(0, import_react.useEffect)(() => {
		try {
			const saved = localStorage.getItem(STORAGE_KEY);
			const parsed = saved ? parseDeck(saved) : null;
			if (parsed) setDeck(parsed);
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify(deck));
		} catch {}
	}, [deck]);
	const active = deck.threads.find((t) => t.id === deck.activeId) ?? deck.threads[0];
	(0, import_react.useEffect)(() => {
		endRef.current?.scrollIntoView({ block: "end" });
	}, [
		active.messages.length,
		busy,
		tab
	]);
	const visibleThreads = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (!q) return deck.threads;
		return deck.threads.filter((t) => t.title.toLowerCase().includes(q) || t.messages.some((m) => m.text.toLowerCase().includes(q)));
	}, [deck.threads, query]);
	function patchActive(fn) {
		setDeck((d) => ({
			...d,
			threads: d.threads.map((t) => t.id === d.activeId ? fn(t) : t)
		}));
	}
	function setMode(mode) {
		patchActive((t) => ({
			...t,
			mode
		}));
	}
	async function onPick(file) {
		if (file.type.startsWith("image/")) {
			try {
				setStatus("ছবি প্রস্তুত হচ্ছে…");
				setAttachment(await fileToImage(file));
				setStatus("ছবি যোগ করা হয়েছে");
			} catch {
				setStatus("ছবিটি পড়া যায়নি");
				toast("ছবিটি পড়া যায়নি। অন্য একটি JPEG বা PNG দাও।");
			}
			return;
		}
		const text = (await file.text()).slice(0, 12e3);
		setAttachment({
			kind: "text",
			name: file.name || "ফাইল",
			text
		});
		setStatus("ফাইল যোগ হয়েছে");
	}
	function speak(text) {
		if (typeof window === "undefined" || !window.speechSynthesis) {
			setStatus("এই ব্রাউজারে উত্তর শোনানো যায় না");
			return;
		}
		window.speechSynthesis.cancel();
		const utter = new SpeechSynthesisUtterance(text.slice(0, 3500));
		utter.lang = /[\u0980-\u09FF]/.test(text) ? "bn-BD" : "en-US";
		window.speechSynthesis.speak(utter);
	}
	function startVoice() {
		const w = window;
		const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
		if (!Ctor) {
			setStatus("এই ব্রাউজারে ভয়েস টাইপিং চালু নেই");
			toast("ভয়েস চালু নেই। কিবোর্ডের মাইক্রোফোনও ব্যবহার করতে পারো।");
			return;
		}
		if (listening) {
			recRef.current?.stop();
			setListening(false);
			return;
		}
		const rec = new Ctor();
		rec.lang = "bn-BD";
		rec.interimResults = false;
		rec.continuous = false;
		rec.onresult = (ev) => {
			const spoken = ev.results[0]?.[0]?.transcript ?? "";
			if (spoken) setInput((prev) => [prev, spoken].filter(Boolean).join(" "));
		};
		rec.onerror = () => setStatus("ভয়েস নেওয়া যায়নি");
		rec.onend = () => setListening(false);
		recRef.current = rec;
		try {
			rec.start();
			setListening(true);
			setStatus("শুনছি…");
		} catch {
			setStatus("ভয়েস চালু হয়নি");
		}
	}
	function recentImage() {
		if (active.mode !== "vision") return void 0;
		for (let i = active.messages.length - 1; i >= 0; i--) {
			const msg = active.messages[i];
			if (msg.role === "user" && images.current.has(msg.id)) return images.current.get(msg.id);
		}
	}
	async function send() {
		const typed = input.trim();
		const prompt = (typed + (attachment?.kind === "text" ? `\n\n[ফাইল: ${attachment.name}]\n${attachment.text}` : "")).trim();
		const image = attachment?.kind === "image" ? attachment : null;
		if (!prompt && !image || busy) return;
		const local = (active.mode === "chat" || active.mode === "math") && !image && attachment?.kind !== "text" ? tryLocal(prompt) : null;
		const userText = prompt || "এই ছবিটি দেখে কী আছে তা বাংলায় বুঝিয়ে বলো।";
		const userMsg = {
			id: uid(),
			role: "user",
			text: typed || (image ? "এই ছবিটি দেখে কী আছে তা বাংলায় বুঝিয়ে বলো।" : prompt),
			thumb: image?.thumb
		};
		if (image) images.current.set(userMsg.id, image.dataUrl);
		const history = [...active.messages.filter((m) => m.id !== "greet" || active.messages.length > 1).filter((m) => m.id !== "greet"), userMsg].slice(-12);
		const title = active.title === "নতুন কথা" ? userText.slice(0, 42) : active.title;
		setInput("");
		setAttachment(null);
		setBusy(true);
		patchActive((t) => ({
			...t,
			title,
			updatedAt: Date.now(),
			messages: [...t.messages.filter((m) => !(t.messages.length === 1 && m.id === "greet")), userMsg]
		}));
		if (local) {
			patchActive((t) => ({
				...t,
				updatedAt: Date.now(),
				messages: [...t.messages, {
					id: uid(),
					role: "assistant",
					text: local
				}]
			}));
			setBusy(false);
			setStatus("তাৎক্ষণিক হিসাব");
			return;
		}
		setStatus(active.mode === "imagine" ? "ছবি তৈরি হচ্ছে…" : image ? "ছবি বিশ্লেষণ হচ্ছে…" : "উত্তর তৈরি হচ্ছে…");
		try {
			if (active.mode === "imagine") {
				const drawn = await draw({ data: {
					prompt: userText,
					imageDataUrl: image?.dataUrl
				} });
				const text = drawn.ok ? image ? "ছবিটি বদলে দেওয়া হয়েছে।" : "এই ছবিটি তৈরি করা হয়েছে।" : errorCopy(drawn.error);
				patchActive((t) => ({
					...t,
					updatedAt: Date.now(),
					messages: [...t.messages, {
						id: uid(),
						role: "assistant",
						text,
						generatedUrl: drawn.ok ? drawn.url : void 0,
						error: !drawn.ok
					}]
				}));
			} else {
				const lastImage = image?.dataUrl ?? recentImage();
				const turns = history.map((m, i) => ({
					role: m.role,
					text: m.text,
					imageDataUrl: i === history.length - 1 ? lastImage : void 0
				}));
				const reply = await ask({ data: {
					mode: active.mode,
					depth: deck.depth,
					lang: deck.lang,
					threadId: /^[0-9a-f-]{36}$/i.test(active.id) ? active.id : void 0,
					turns
				} });
				let text = reply.ok ? reply.text : errorCopy(reply.error);
				if (!reply.ok && reply.error === "credit" && image) {
					const kb = Math.max(1, Math.round(image.dataUrl.length * .75 / 1024));
					text += `\n\nছবি লোড হয়েছে: ${image.width}×${image.height}, প্রায় ${kb} KB। দৃশ্য বুঝতে অনলাইন AI দরকার।`;
				}
				patchActive((t) => ({
					...t,
					updatedAt: Date.now(),
					messages: [...t.messages, {
						id: uid(),
						role: "assistant",
						text,
						error: !reply.ok
					}]
				}));
			}
			setStatus(ready ? "AI সহকারী" : "AI এখন অনুপলব্ধ");
		} catch {
			patchActive((t) => ({
				...t,
				messages: [...t.messages, {
					id: uid(),
					role: "assistant",
					text: errorCopy("failed"),
					error: true
				}]
			}));
			setStatus("আবার চেষ্টা করো");
		} finally {
			setBusy(false);
		}
	}
	function clearChat() {
		patchActive((t) => ({
			...t,
			title: "নতুন কথা",
			updatedAt: Date.now(),
			messages: [greeting()]
		}));
		setInput("");
		setAttachment(null);
		setStatus("চ্যাট পরিষ্কার");
	}
	function newChat() {
		const thread = {
			id: uid(),
			title: "নতুন কথা",
			updatedAt: Date.now(),
			mode: active.mode,
			messages: [greeting()]
		};
		setDeck((d) => ({
			...d,
			activeId: thread.id,
			threads: [thread, ...d.threads].slice(0, 30)
		}));
		setDrawer(false);
		setTab("chat");
	}
	function removeThread(id) {
		setDeck((d) => {
			const threads = d.threads.filter((t) => t.id !== id);
			if (threads.length === 0) return homeDeck();
			return {
				...d,
				threads,
				activeId: d.activeId === id ? threads[0].id : d.activeId
			};
		});
		setConfirmDelete(null);
	}
	function exportChat() {
		const body = active.messages.map((m) => `${m.role === "user" ? "আপনি" : "LV99"}: ${m.text}`).join("\n\n");
		const blob = new Blob([body], { type: "text/plain;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "lv99-chat.txt";
		a.click();
		URL.revokeObjectURL(url);
	}
	const showWelcome = active.messages.length <= 1 && !busy;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b border-line bg-panel px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-xl text-fg lg:hidden",
							"aria-label": "কথোপকথন",
							onClick: () => setDrawer(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-11 shrink-0 items-center justify-center rounded-xl bg-cobalt text-sm font-bold text-on-cobalt",
							children: "99"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "truncate text-lg font-bold tracking-tight",
									children: "LV99 AI"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
									className: "size-4 shrink-0 text-gold",
									"aria-hidden": "true"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted",
								children: listening ? "শুনছি…" : status
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-2 gap-1 rounded-xl border border-line p-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg text-sm font-semibold " + (tab === "chat" ? "bg-cobalt text-on-cobalt" : "text-muted"),
						onClick: () => setTab("chat"),
						children: "চ্যাট"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex min-h-11 items-center justify-center gap-1 rounded-lg text-sm font-semibold " + (tab === "tools" ? "bg-cobalt text-on-cobalt" : "text-muted"),
						onClick: () => setTab("tools"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "size-4" }), "টুলস"]
					})]
				})]
			}),
			tab === "tools" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolsPanel, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadRail, {
					className: "hidden lg:flex",
					threads: visibleThreads,
					activeId: active.id,
					query,
					confirmDelete,
					onQuery: setQuery,
					onOpen: (id) => setDeck((d) => ({
						...d,
						activeId: id
					})),
					onNew: newChat,
					onAskDelete: setConfirmDelete,
					onDelete: removeThread
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex min-w-0 flex-1 flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "scroll-thin flex gap-2 overflow-x-auto border-b border-line px-3 py-2",
							children: MODES.map((mode) => {
								const Icon = MODE_ICON[mode.id];
								const on = active.mode === mode.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setMode(mode.id),
									className: "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border px-3 text-sm " + (on ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line bg-card text-muted"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), mode.label]
								}, mode.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "scroll-thin flex-1 overflow-y-auto px-3 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto flex max-w-3xl flex-col gap-3",
								children: [
									showWelcome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Welcome, {
										onImage: () => {
											setMode("vision");
											fileRef.current?.click();
										},
										onVoice: () => {
											setTab("chat");
											startVoice();
										},
										onMode: setMode
									}) : null,
									active.messages.map((msg, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "max-w-[92%] rounded-2xl px-3.5 py-3 text-sm " + (msg.role === "user" ? "ml-auto bg-cobalt text-on-cobalt" : "mr-auto border border-line bg-card text-fg"),
										children: [
											msg.thumb ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: msg.thumb,
												alt: "পাঠানো ছবি",
												className: "mb-2 max-h-56 w-full rounded-xl object-cover"
											}) : null,
											msg.generatedUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: msg.generatedUrl,
												alt: "LV99 AI তৈরি করা ছবি",
												className: "mb-2 max-h-80 w-full rounded-xl object-contain"
											}) : null,
											msg.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, { text: msg.text }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "whitespace-pre-wrap leading-relaxed",
												children: msg.text
											}),
											msg.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 flex flex-wrap gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														className: "inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs text-gold",
														onClick: () => speak(msg.text),
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }), "উত্তর শুনুন"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														className: "inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs text-muted",
														onClick: () => {
															navigator.clipboard.writeText(msg.text);
															toast("কপি হয়েছে");
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "কপি"]
													}),
													index === active.messages.length - 1 && !busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														className: "inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs text-muted",
														onClick: () => {
															const msgs = active.messages;
															let lastUserIndex = -1;
															msgs.forEach((m, i) => {
																if (m.role === "user") lastUserIndex = i;
															});
															if (lastUserIndex < 0) return;
															const lastUser = msgs[lastUserIndex];
															patchActive((t) => {
																const cut = t.messages.slice(0, lastUserIndex);
																return {
																	...t,
																	messages: cut.length > 0 ? cut : [greeting()]
																};
															});
															setInput(lastUser.text);
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), "আবার"]
													}) : null
												]
											}) : null
										]
									}, msg.id)),
									busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										"aria-live": "polite",
										children: "LV99 AI কাজ করছে…"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: endRef })
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-t border-line bg-panel px-3 py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto max-w-3xl",
								children: [
									showWelcome ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mb-2 flex gap-2 overflow-x-auto",
										children: QUICK[active.mode].map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 shrink-0 rounded-full border border-line px-3 text-xs text-muted",
											onClick: () => setInput(chip),
											children: chip
										}, chip))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "mb-2 text-xs text-muted",
										onClick: () => setShowPower((v) => !v),
										children: [
											"শক্তি নিয়ন্ত্রণ · ",
											deck.depth === "brief" ? "সংক্ষিপ্ত" : deck.depth === "deep" ? "গভীর" : "মাঝারি",
											" ·",
											" ",
											deck.lang === "bn" ? "বাংলা" : deck.lang === "en" ? "English" : "অটো ভাষা"
										]
									}),
									showPower ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-2 flex flex-wrap gap-2",
										children: [[
											["brief", "সংক্ষিপ্ত"],
											["normal", "মাঝারি"],
											["deep", "গভীর"]
										].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-full border px-3 text-xs " + (deck.depth === id ? "border-cobalt bg-cobalt text-on-cobalt" : "border-line text-muted"),
											onClick: () => setDeck((d) => ({
												...d,
												depth: id
											})),
											children: label
										}, id)), [
											["auto", "অটো"],
											["bn", "বাংলা"],
											["en", "English"]
										].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-full border px-3 text-xs " + (deck.lang === id ? "border-gold bg-gold text-ink" : "border-line text-muted"),
											onClick: () => setDeck((d) => ({
												...d,
												lang: id
											})),
											children: label
										}, id))]
									}) : null,
									attachment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-2 flex items-center gap-3 rounded-xl border border-line bg-card p-2",
										children: [
											attachment.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: attachment.thumb,
												alt: "",
												className: "size-14 rounded-lg object-cover"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex size-14 items-center justify-center rounded-lg bg-ink text-xs text-gold",
												children: "ফাইল"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0 flex-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "truncate text-sm font-semibold",
													children: attachment.kind === "image" ? "ছবি পাঠানোর জন্য প্রস্তুত" : attachment.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-muted",
													children: attachment.kind === "image" ? `${attachment.width}×${attachment.height} · সাথে প্রশ্ন লিখতে পারো` : "ফাইলের লেখা প্রশ্নের সাথে যাবে"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center",
												"aria-label": "সংযুক্তি সরান",
												onClick: () => setAttachment(null),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
											})
										]
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-end gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center rounded-xl text-cobalt",
												"aria-label": "ছবি বা ফাইল",
												disabled: busy,
												onClick: () => fileRef.current?.click(),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center rounded-xl " + (listening ? "text-gold" : "text-cobalt"),
												"aria-label": "ভয়েস ইনপুট",
												"aria-pressed": listening,
												disabled: busy,
												onClick: startVoice,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "sr-only",
												htmlFor: "lv99-input",
												children: "প্রশ্ন"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												id: "lv99-input",
												rows: 1,
												value: input,
												disabled: busy,
												placeholder: active.mode === "imagine" ? "কী আঁকতে চাও লিখুন…" : "প্রশ্ন লিখুন… ২+২, ছবি, বা কোড",
												className: "max-h-36 min-h-11 flex-1 resize-none rounded-2xl border border-line bg-ink px-3 py-3 text-sm outline-none focus-visible:border-cobalt",
												onChange: (e) => setInput(e.target.value),
												onKeyDown: (e) => {
													if (e.key === "Enter" && !e.shiftKey) {
														e.preventDefault();
														send();
													}
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center rounded-full bg-cobalt text-on-cobalt disabled:opacity-40",
												"aria-label": "পাঠান",
												disabled: busy || !input.trim() && !attachment,
												onClick: () => void send(),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center justify-between gap-2 text-xs text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "গুরুত্বপূর্ণ তথ্য যাচাই করো। তাৎক্ষণিক হিসাব লোকাল; বাকি উত্তর অনলাইন AI।" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex shrink-0 gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center",
												"aria-label": "এক্সপোর্ট",
												onClick: exportChat,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "inline-flex size-11 items-center justify-center",
												"aria-label": "চ্যাট পরিষ্কার",
												onClick: clearChat,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
											})]
										})]
									})
								]
							})
						})
					]
				})]
			}),
			drawer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-20 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-ink/70",
					"aria-label": "বন্ধ",
					onClick: () => setDrawer(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadRail, {
					className: "absolute inset-y-0 left-0 flex w-72",
					threads: visibleThreads,
					activeId: active.id,
					query,
					confirmDelete,
					onQuery: setQuery,
					onOpen: (id) => {
						setDeck((d) => ({
							...d,
							activeId: id
						}));
						setDrawer(false);
						setTab("chat");
					},
					onNew: newChat,
					onAskDelete: setConfirmDelete,
					onDelete: removeThread
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "image/*,.txt,.md,.json,.csv,.py,.js,.ts,.tsx,.kt",
				className: "hidden",
				onChange: (e) => {
					const file = e.target.files?.[0];
					e.target.value = "";
					if (file) onPick(file);
				}
			})
		]
	});
}
function Welcome({ onImage, onVoice, onMode }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-3xl bg-hero p-5 text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold",
						children: "তোমার ব্যক্তিগত AI"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm leading-relaxed",
					children: "প্রশ্ন করো, ছবি দেখাও, বাংলায় কথা বলো — এক জায়গায়। মেমরি, দশটা বিশেষজ্ঞ মোড, আর ক্রেডিট ছাড়াই হিসাব।"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onImage,
						className: "inline-flex min-h-11 items-center gap-2 rounded-xl bg-fg px-3 text-sm font-semibold text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), "ছবি বুঝুন"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onVoice,
						className: "inline-flex min-h-11 items-center gap-2 rounded-xl border border-line px-3 text-sm font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" }), "কথা বলুন"]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: MODES.map((mode) => {
				const Icon = MODE_ICON[mode.id];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onMode(mode.id),
					className: "rounded-2xl border border-line bg-card p-3 text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-gold" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-semibold",
							children: mode.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: mode.hint
						})
					]
				}, mode.id);
			})
		})]
	});
}
function ThreadRail({ className, threads, activeId, query, confirmDelete, onQuery, onOpen, onNew, onAskDelete, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "w-72 shrink-0 flex-col border-r border-line bg-panel " + (className ?? ""),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-2 p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onNew,
					className: "inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-cobalt text-sm font-semibold text-on-cobalt",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "নতুন চ্যাট"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-xl border border-line bg-ink px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (e) => onQuery(e.target.value),
						placeholder: "খুঁজুন",
						"aria-label": "চ্যাট খুঁজুন",
						className: "min-h-11 w-full bg-transparent text-sm outline-none"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scroll-thin flex-1 overflow-y-auto px-2 pb-3",
				children: threads.map((thread) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1 flex items-center rounded-xl " + (thread.id === activeId ? "bg-card" : "hover:bg-ink"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpen(thread.id),
						className: "min-h-11 flex-1 truncate px-3 text-left text-sm",
						children: thread.title
					}), confirmDelete === thread.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 px-2 text-xs text-gold",
						onClick: () => onDelete(thread.id),
						children: "মুছুন"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-11 items-center justify-center text-muted",
						"aria-label": "চ্যাট মুছুন",
						onClick: () => onAskDelete(thread.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}, thread.id))
			})
		]
	});
}
function Home() {
	const status = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, { ready: status.ready });
}
//#endregion
export { Home as component };
