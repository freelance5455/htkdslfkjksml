import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as History, i as RotateCcw, o as Copy, r as Settings, s as ClipboardPaste, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Kot724Tf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var supported = null;
function audioSupported() {
	if (supported != null) return supported;
	if (typeof window === "undefined") return false;
	supported = "AudioContext" in window || "webkitAudioContext" in window;
	return supported;
}
function playTone(kind, enabled) {
	if (!enabled || !audioSupported()) return;
	try {
		const Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) {
			supported = false;
			return;
		}
		if (!ctx) ctx = new Ctx();
		if (ctx.state === "suspended") ctx.resume();
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = kind === "err" ? "triangle" : "sine";
		osc.frequency.value = kind === "eq" ? 680 : kind === "err" ? 190 : 530;
		const now = ctx.currentTime;
		const peak = kind === "err" ? .04 : .025;
		gain.gain.setValueAtTime(1e-4, now);
		gain.gain.exponentialRampToValueAtTime(peak, now + .01);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + (kind === "eq" ? .11 : .05));
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start(now);
		osc.stop(now + .13);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
		};
	} catch {
		supported = false;
	}
}
var DEFAULT_FORMAT = {
	group: true,
	places: "auto"
};
function sanitize(n) {
	if (!Number.isFinite(n)) return n;
	const next = Number(n.toPrecision(12));
	if (!Number.isFinite(next)) return n;
	return Object.is(next, -0) ? 0 : next;
}
function formatSci(n, digits) {
	let s = n.toExponential(digits);
	s = s.replace(/(\.\d*?)0+e/, "$1e").replace(/\.e/, "e");
	return s.replace("e+", "e");
}
function formatResult(n, opts = DEFAULT_FORMAT) {
	if (!Number.isFinite(n)) return "Error";
	if (Object.is(n, -0)) n = 0;
	const clean = sanitize(n);
	if (!Number.isFinite(clean)) return "Error";
	const abs = Math.abs(clean);
	if (clean !== 0 && (abs >= 0xe8d4a51000 || abs < 1e-7)) return formatSci(clean, opts.places === "auto" ? 6 : opts.places);
	const body = opts.places === "auto" ? String(clean) : clean.toFixed(opts.places);
	if (!opts.group) return body;
	const neg = body.startsWith("-");
	const [int, frac] = (neg ? body.slice(1) : body).split(".");
	const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	return `${neg ? "-" : ""}${grouped}${frac !== void 0 ? `.${frac}` : ""}`;
}
function basicFormat(n) {
	return formatResult(n, {
		group: false,
		places: "auto"
	});
}
var MAX_DIGITS = 16;
var MAX_TOKENS = 80;
var OP_SYM = {
	"+": "+",
	"-": "−",
	"*": "×",
	"/": "÷",
	"^": "^"
};
function createState() {
	return {
		tokens: [],
		draft: null,
		evaluated: false,
		exprSnapshot: "",
		error: null,
		ans: null,
		memory: 0,
		angle: "deg",
		repeat: null
	};
}
function reduce(state, action) {
	switch (action.type) {
		case "digit": return inputDigit(state, action.d);
		case "dot": return inputDot(state);
		case "op": return inputOp(state, action.op);
		case "eq": return inputEq(state);
		case "ac": return {
			...createState(),
			memory: state.memory,
			angle: state.angle
		};
		case "c":
			if (state.error) return {
				...state,
				error: null
			};
			if (state.draft) return {
				...state,
				draft: null,
				repeat: null
			};
			return state;
		case "bs": return inputBs(state);
		case "sign": return inputSign(state);
		case "percent": return inputPercent(state);
		case "fn": return inputFn(state, action.fn);
		case "const": return inputConst(state, action.name);
		case "lp": return inputLp(state);
		case "rp": return inputRp(state);
		case "mem": return inputMem(state, action.m);
		case "angle": return {
			...state,
			angle: action.mode
		};
		case "load": return inputLoad(state, action.value);
		default: return state;
	}
}
function view(state, opts = DEFAULT_FORMAT) {
	const expression = state.evaluated && state.exprSnapshot && !state.draft ? state.exprSnapshot : liveExpr(state);
	let main = "0";
	let isError = false;
	if (state.error) {
		main = state.error;
		isError = true;
	} else if (state.draft) {
		if (state.draft.percent) main = state.draft.expr || "0";
		else if (state.draft.display === "text") main = state.draft.text.length ? state.draft.text : "0";
		else main = state.draft.value == null ? "0" : formatResult(state.draft.value, opts);
	} else if (state.evaluated && state.ans != null) main = formatResult(state.ans, opts);
	else {
		const end = state.tokens[state.tokens.length - 1];
		if (end?.kind === "num") main = formatResult(end.value, opts);
		else main = "0";
	}
	const copyText = isError ? state.ans == null ? "" : formatResult(state.ans, opts) : main;
	return {
		expression,
		main,
		isError,
		copyText,
		memoryOn: state.memory !== 0,
		angle: state.angle
	};
}
function currentValue(state) {
	if (state.draft?.value != null && Number.isFinite(state.draft.value)) return state.draft.value;
	if (state.evaluated && state.ans != null) return state.ans;
	for (let i = state.tokens.length - 1; i >= 0; i--) {
		const t = state.tokens[i];
		if (t.kind === "num") return t.value;
	}
	return state.ans;
}
function inputDigit(state, d) {
	if (!/^\d$/.test(d)) return state;
	let next = state.error ? blankCalc(state) : state;
	if (next.evaluated) next = blankCalc(next);
	if (next.draft?.replace) next = {
		...next,
		draft: null
	};
	if (!next.draft) {
		const text = d;
		return {
			...next,
			draft: textDraft(text),
			repeat: null,
			evaluated: false,
			exprSnapshot: ""
		};
	}
	if (digitCount(next.draft.text) >= MAX_DIGITS) return next;
	let text = next.draft.text;
	if (text === "0") text = d;
	else if (text === "-0") text = `-${d}`;
	else text += d;
	return {
		...next,
		draft: textDraft(text),
		repeat: null
	};
}
function inputDot(state) {
	let next = state.error ? blankCalc(state) : state;
	if (next.evaluated) next = blankCalc(next);
	if (next.draft?.replace) next = {
		...next,
		draft: null
	};
	if (!next.draft) return {
		...next,
		draft: textDraft("0."),
		repeat: null,
		evaluated: false,
		exprSnapshot: ""
	};
	if (next.draft.text.includes(".")) return next;
	const text = next.draft.text === "-" ? "-0." : `${next.draft.text || "0"}.`;
	return {
		...next,
		draft: textDraft(text),
		repeat: null
	};
}
function inputOp(state, op) {
	let next = state;
	if (next.error) next = next.ans != null ? fromAnswer(next) : blankCalc(next);
	if (next.evaluated) next = {
		...next,
		evaluated: false,
		exprSnapshot: "",
		repeat: null
	};
	if ((next.tokens.length === 0 || next.tokens[next.tokens.length - 1]?.kind === "lp") && !next.draft && op === "-") return {
		...next,
		draft: textDraft("-"),
		repeat: null
	};
	if (next.draft) {
		if (next.draft.value == null) return next;
		next = commitDraft(next);
	}
	if (next.tokens.length >= MAX_TOKENS) return {
		...next,
		error: "That expression is too long"
	};
	const tokens = next.tokens.slice();
	const last = tokens[tokens.length - 1];
	if (!last) {
		tokens.push(numToken(0, "0"));
		tokens.push({
			kind: "op",
			op
		});
	} else if (last.kind === "op") tokens[tokens.length - 1] = {
		kind: "op",
		op
	};
	else if (last.kind === "lp") return next;
	else tokens.push({
		kind: "op",
		op
	});
	return {
		...next,
		tokens,
		draft: null,
		repeat: null,
		error: null
	};
}
function inputEq(state) {
	if (state.error) return state;
	if (state.evaluated && state.repeat && state.ans != null && !state.draft) {
		const again = applyOp(state.ans, state.repeat.op, state.repeat.rhs);
		if (typeof again !== "number") return {
			...state,
			error: again
		};
		return finish(state, again, `${basicFormat(state.ans)} ${OP_SYM[state.repeat.op]} ${state.repeat.rhsExpr}`, state.repeat);
	}
	let next = state;
	if (next.draft) {
		if (next.draft.value == null) return {
			...next,
			error: "Finish the number first"
		};
		next = commitDraft(next);
	}
	let tokens = next.tokens.slice();
	while (tokens.length && tokens[tokens.length - 1].kind === "op") tokens = tokens.slice(0, -1);
	if (!tokens.length) return {
		...next,
		tokens,
		draft: null
	};
	if (tokens[tokens.length - 1].kind === "lp") return {
		...next,
		error: "Add a closing parenthesis"
	};
	if (depth(tokens) !== 0) return {
		...next,
		error: "Add a closing parenthesis"
	};
	const repeat = lastRepeat(tokens);
	const expr = tokensToExpr(tokens);
	const result = evalTokens(tokens);
	if (!result.ok) return {
		...next,
		error: result.error
	};
	return finish(next, result.value, expr, repeat);
}
function inputBs(state) {
	if (state.error) return {
		...state,
		error: null
	};
	if (state.draft) {
		if (state.draft.replace || state.draft.display !== "text" || state.draft.percent) return {
			...state,
			draft: null
		};
		const text = state.draft.text.slice(0, -1);
		if (!text) return {
			...state,
			draft: null
		};
		return {
			...state,
			draft: textDraft(text)
		};
	}
	if (!state.tokens.length) return state;
	return {
		...state,
		tokens: state.tokens.slice(0, -1),
		evaluated: false,
		exprSnapshot: "",
		repeat: null
	};
}
function inputSign(state) {
	if (state.error) return {
		...state,
		error: null
	};
	if (state.draft) {
		if (state.draft.percent) {
			const flipped = flipTextSign(state.draft.text);
			return applyPercent({
				...state,
				draft: textDraft(flipped)
			});
		}
		if (state.draft.display === "text") {
			const text = flipTextSign(state.draft.text);
			return {
				...state,
				draft: textDraft(text)
			};
		}
		if (state.draft.value == null) return state;
		const value = -state.draft.value;
		const expr = state.draft.expr.startsWith("−(") ? state.draft.expr.slice(2, -1) : `−(${state.draft.expr})`;
		return {
			...state,
			draft: {
				text: basicFormat(value),
				value,
				expr,
				display: "value",
				replace: true,
				percent: false
			}
		};
	}
	if (state.evaluated && state.ans != null) {
		const value = -state.ans;
		const expr = state.exprSnapshot ? `−(${state.exprSnapshot})` : basicFormat(value);
		return {
			...state,
			ans: value,
			tokens: [numToken(value, basicFormat(value))],
			exprSnapshot: expr,
			repeat: null
		};
	}
	const tokens = state.tokens.slice();
	const last = tokens[tokens.length - 1];
	if (last?.kind === "num") {
		const value = -last.value;
		tokens[tokens.length - 1] = numToken(value, basicFormat(value));
		return {
			...state,
			tokens
		};
	}
	return {
		...state,
		draft: textDraft("-")
	};
}
function inputPercent(state) {
	if (state.error) return {
		...state,
		error: null
	};
	if (!state.draft || state.draft.percent) return state;
	if (state.draft.value == null) return {
		...state,
		error: "Enter a number first"
	};
	return applyPercent(state);
}
function applyPercent(state) {
	const draft = state.draft;
	if (!draft || draft.value == null) return state;
	const pct = /^-?\d*\.?\d+$/.test(draft.text) ? Number(draft.text) : draft.value;
	if (!Number.isFinite(pct)) return {
		...state,
		error: "Enter a number first"
	};
	const last = state.tokens[state.tokens.length - 1];
	let computed = pct / 100;
	if (last?.kind === "op" && (last.op === "+" || last.op === "-")) {
		const left = evalTokens(state.tokens.slice(0, -1));
		if (!left.ok) return {
			...state,
			error: left.error
		};
		computed = left.value * (pct / 100);
	}
	if (!Number.isFinite(computed)) return {
		...state,
		error: "That number is too large"
	};
	const label = `${trimTyped(draft.text)}%`;
	return {
		...state,
		error: null,
		draft: {
			text: draft.text,
			value: computed,
			expr: label,
			display: "text",
			replace: true,
			percent: true
		}
	};
}
function inputFn(state, fn) {
	let next = state.error ? {
		...state,
		error: null
	} : state;
	const source = takeSource(next);
	if (!source.ok) return {
		...next,
		error: source.error
	};
	const applied = applyFn(fn, source.value, next.angle);
	if (typeof applied !== "number") return {
		...next,
		error: applied
	};
	if (!Number.isFinite(applied)) return {
		...next,
		error: "That number is too large"
	};
	return {
		...next,
		tokens: source.tokens,
		draft: {
			text: basicFormat(applied),
			value: applied,
			expr: fnExpr(fn, source.inner),
			display: "value",
			replace: true,
			percent: false
		},
		evaluated: false,
		exprSnapshot: "",
		error: null,
		repeat: null,
		ans: next.ans
	};
}
function inputConst(state, name) {
	let next = state.error ? blankCalc(state) : state;
	if (next.evaluated) next = blankCalc(next);
	if (next.draft?.replace) next = {
		...next,
		draft: null
	};
	if (next.draft?.value != null && next.draft.display === "text" && !next.draft.percent) next = commitDraft(next);
	else if (next.draft) next = {
		...next,
		draft: null
	};
	const value = name === "pi" ? Math.PI : Math.E;
	const expr = name === "pi" ? "π" : "e";
	return {
		...next,
		evaluated: false,
		exprSnapshot: "",
		repeat: null,
		error: null,
		draft: {
			text: expr,
			value,
			expr,
			display: "value",
			replace: true,
			percent: false
		}
	};
}
function inputLp(state) {
	let next = state.error ? blankCalc(state) : state;
	if (next.evaluated && next.ans != null) next = {
		...next,
		tokens: [numToken(next.ans, basicFormat(next.ans))],
		evaluated: false,
		exprSnapshot: "",
		draft: null,
		repeat: null
	};
	if (next.draft) {
		if (next.draft.value == null) return next;
		next = commitDraft(next);
	}
	if (next.tokens.length >= MAX_TOKENS) return {
		...next,
		error: "That expression is too long"
	};
	const tokens = next.tokens.slice();
	const last = tokens[tokens.length - 1];
	if (last && (last.kind === "num" || last.kind === "rp")) tokens.push({
		kind: "op",
		op: "*"
	});
	tokens.push({ kind: "lp" });
	return {
		...next,
		tokens,
		draft: null,
		evaluated: false,
		exprSnapshot: "",
		repeat: null,
		error: null
	};
}
function inputRp(state) {
	if (state.error) return {
		...state,
		error: null
	};
	if (depth(state.tokens) <= 0) return state;
	let next = state;
	if (next.draft) {
		if (next.draft.value == null) return next;
		next = commitDraft(next);
	}
	const last = next.tokens[next.tokens.length - 1];
	if (!last || last.kind === "op" || last.kind === "lp") return next;
	if (next.tokens.length >= MAX_TOKENS) return {
		...next,
		error: "That expression is too long"
	};
	return {
		...next,
		tokens: [...next.tokens, { kind: "rp" }],
		evaluated: false,
		exprSnapshot: "",
		repeat: null,
		error: null
	};
}
function inputMem(state, m) {
	if (m === "mc") return {
		...state,
		memory: 0
	};
	if (m === "mr") {
		let next = state.error ? blankCalc(state) : state;
		if (next.evaluated) next = blankCalc(next);
		return {
			...next,
			evaluated: false,
			exprSnapshot: "",
			repeat: null,
			error: null,
			draft: {
				text: basicFormat(next.memory),
				value: next.memory,
				expr: basicFormat(next.memory),
				display: "value",
				replace: true,
				percent: false
			}
		};
	}
	const v = currentValue(state);
	if (v == null || !Number.isFinite(v)) return state;
	const next = m === "mp" ? state.memory + v : state.memory - v;
	if (!Number.isFinite(next)) return {
		...state,
		error: "Memory is too large"
	};
	return {
		...state,
		memory: next
	};
}
function inputLoad(state, value) {
	if (!Number.isFinite(value)) return state;
	const label = basicFormat(value);
	return {
		...state,
		tokens: [numToken(value, label)],
		draft: null,
		evaluated: true,
		exprSnapshot: label,
		error: null,
		ans: value,
		repeat: null
	};
}
function finish(state, value, expr, repeat) {
	if (!Number.isFinite(value)) return {
		...state,
		error: "That number is too large"
	};
	const label = basicFormat(value);
	return {
		...state,
		tokens: [numToken(value, label)],
		draft: null,
		evaluated: true,
		exprSnapshot: expr || label,
		error: null,
		ans: value,
		repeat
	};
}
function commitDraft(state) {
	const draft = state.draft;
	if (!draft || draft.value == null || !Number.isFinite(draft.value)) return state;
	const tokens = state.tokens.slice();
	const last = tokens[tokens.length - 1];
	if (last && (last.kind === "num" || last.kind === "rp")) tokens.push({
		kind: "op",
		op: "*"
	});
	tokens.push(numToken(draft.value, draft.expr || draft.text || basicFormat(draft.value)));
	return {
		...state,
		tokens,
		draft: null
	};
}
function textDraft(text) {
	return {
		text,
		value: parseTyped(text),
		expr: text,
		display: "text",
		replace: false,
		percent: false
	};
}
function parseTyped(text) {
	if (!text || text === "-" || text === "." || text === "-.") return null;
	if (!/^-?\d+\.$/.test(text) && !/^-?\d*(\.\d+)?$/.test(text)) return null;
	const n = Number(text);
	return Number.isFinite(n) ? n : null;
}
function numToken(value, label) {
	return {
		kind: "num",
		value,
		label
	};
}
function digitCount(text) {
	return text.replace(/[^0-9]/g, "").length;
}
function flipTextSign(text) {
	if (!text || text === "0" || text === "0.") return text.startsWith("-") ? text.slice(1) : `-${text}`;
	if (text.startsWith("-")) return text.slice(1) || "0";
	return `-${text}`;
}
function trimTyped(text) {
	if (text.endsWith(".")) return text.slice(0, -1) || "0";
	return text;
}
function blankCalc(state) {
	return {
		...createState(),
		memory: state.memory,
		angle: state.angle,
		ans: state.ans
	};
}
function fromAnswer(state) {
	if (state.ans == null) return blankCalc(state);
	const label = basicFormat(state.ans);
	return {
		...blankCalc(state),
		tokens: [numToken(state.ans, label)],
		ans: state.ans
	};
}
function depth(tokens) {
	let d = 0;
	for (const t of tokens) if (t.kind === "lp") d++;
	else if (t.kind === "rp") d--;
	return d;
}
function endsWithValue(tokens) {
	const last = tokens[tokens.length - 1];
	return last?.kind === "num" || last?.kind === "rp";
}
function tokensToExpr(tokens) {
	const bits = [];
	for (const t of tokens) if (t.kind === "num") bits.push(t.label);
	else if (t.kind === "op") bits.push(OP_SYM[t.op]);
	else if (t.kind === "lp") bits.push("(");
	else bits.push(")");
	let s = "";
	for (let i = 0; i < bits.length; i++) {
		const b = bits[i];
		const prev = bits[i - 1];
		if (i === 0) {
			s = b;
			continue;
		}
		if (b === ")" || prev === "(") s += b;
		else s += ` ${b}`;
	}
	return s;
}
function liveExpr(state) {
	const base = tokensToExpr(state.tokens);
	if (!state.draft) return base;
	const piece = state.draft.expr || state.draft.text;
	if (!piece) return base;
	if (!base) return piece;
	if (endsWithValue(state.tokens)) return `${base} × ${piece}`;
	if (base.endsWith("(")) return `${base}${piece}`;
	return `${base} ${piece}`;
}
function lastRepeat(tokens) {
	if (tokens.length < 2) return null;
	const rhs = tokens[tokens.length - 1];
	const op = tokens[tokens.length - 2];
	if (rhs.kind !== "num" || op.kind !== "op") return null;
	if (parenDepthAt(tokens, tokens.length - 2) !== 0) return null;
	return {
		op: op.op,
		rhs: rhs.value,
		rhsExpr: basicFormat(rhs.value)
	};
}
function parenDepthAt(tokens, index) {
	let d = 0;
	for (let i = 0; i <= index; i++) {
		const t = tokens[i];
		if (t.kind === "lp") d++;
		else if (t.kind === "rp") d--;
	}
	return d;
}
function takeSource(state) {
	if (state.draft) {
		if (state.draft.value == null) return {
			ok: false,
			error: "Enter a number first"
		};
		const inner = state.draft.percent ? state.draft.expr : state.draft.expr || state.draft.text;
		return {
			ok: true,
			value: state.draft.value,
			inner,
			tokens: state.tokens
		};
	}
	if (state.evaluated && state.ans != null) {
		const inner = state.exprSnapshot || basicFormat(state.ans);
		return {
			ok: true,
			value: state.ans,
			inner,
			tokens: []
		};
	}
	if (state.tokens.length && depth(state.tokens) === 0 && endsWithValue(state.tokens)) {
		const result = evalTokens(state.tokens);
		if (!result.ok) return {
			ok: false,
			error: "Enter a number first"
		};
		return {
			ok: true,
			value: result.value,
			inner: tokensToExpr(state.tokens),
			tokens: []
		};
	}
	return {
		ok: false,
		error: "Enter a number first"
	};
}
function applyOp(a, op, b) {
	let r;
	switch (op) {
		case "+":
			r = a + b;
			break;
		case "-":
			r = a - b;
			break;
		case "*":
			r = a * b;
			break;
		case "/":
			if (b === 0) return "Can't divide by zero";
			r = a / b;
			break;
		case "^":
			if (a < 0 && !Number.isInteger(b)) return "That power isn't a real number";
			r = a ** b;
			break;
		default: return "That expression isn't complete";
	}
	if (!Number.isFinite(r)) return "That number is too large";
	return r;
}
function evalTokens(tokens) {
	if (!tokens.length) return {
		ok: false,
		error: "Enter a calculation"
	};
	if (depth(tokens) !== 0) return {
		ok: false,
		error: "Add a closing parenthesis"
	};
	const output = [];
	const ops = [];
	const prec = {
		"+": 1,
		"-": 1,
		"*": 2,
		"/": 2,
		"^": 3
	};
	for (const tok of tokens) if (tok.kind === "num") output.push({
		kind: "n",
		v: tok.value
	});
	else if (tok.kind === "op") {
		while (ops.length) {
			const top = ops[ops.length - 1];
			if (top === "(") break;
			const right = tok.op === "^";
			if (prec[top] > prec[tok.op] || prec[top] === prec[tok.op] && !right) output.push({
				kind: "op",
				op: ops.pop()
			});
			else break;
		}
		ops.push(tok.op);
	} else if (tok.kind === "lp") ops.push("(");
	else {
		let found = false;
		while (ops.length) {
			const top = ops.pop();
			if (top === "(") {
				found = true;
				break;
			}
			if (top) output.push({
				kind: "op",
				op: top
			});
		}
		if (!found) return {
			ok: false,
			error: "Add a closing parenthesis"
		};
	}
	while (ops.length) {
		const top = ops.pop();
		if (top === "(" || !top) return {
			ok: false,
			error: "Add a closing parenthesis"
		};
		output.push({
			kind: "op",
			op: top
		});
	}
	const stack = [];
	for (const item of output) {
		if (item.kind === "n") {
			stack.push(item.v);
			continue;
		}
		if (stack.length < 2) return {
			ok: false,
			error: "That expression isn't complete"
		};
		const b = stack.pop();
		const r = applyOp(stack.pop(), item.op, b);
		if (typeof r !== "number") return {
			ok: false,
			error: r
		};
		stack.push(r);
	}
	if (stack.length !== 1) return {
		ok: false,
		error: "That expression isn't complete"
	};
	return {
		ok: true,
		value: stack[0]
	};
}
function crispTrig(n) {
	if (!Number.isFinite(n)) return n;
	if (Math.abs(n) < 1e-12) return 0;
	const rounded = sanitize(n);
	const nearest = Math.round(rounded);
	if (Math.abs(rounded - nearest) < 1e-9) return nearest;
	return rounded;
}
function applyFn(fn, x, angle) {
	const toRad = (n) => angle === "deg" ? n * Math.PI / 180 : n;
	const fromRad = (n) => angle === "deg" ? n * 180 / Math.PI : n;
	switch (fn) {
		case "sin": return crispTrig(Math.sin(toRad(x)));
		case "cos": return crispTrig(Math.cos(toRad(x)));
		case "tan": {
			const r = toRad(x);
			if (Math.abs(Math.cos(r)) < 1e-12) return "Tangent is undefined there";
			return crispTrig(Math.tan(r));
		}
		case "asin":
			if (x < -1 || x > 1) return "Inverse sine needs a number from −1 to 1";
			return crispTrig(fromRad(Math.asin(x)));
		case "acos":
			if (x < -1 || x > 1) return "Inverse cosine needs a number from −1 to 1";
			return crispTrig(fromRad(Math.acos(x)));
		case "atan": return crispTrig(fromRad(Math.atan(x)));
		case "ln":
			if (!(x > 0)) return "Natural log needs a positive number";
			return Math.log(x);
		case "log":
			if (!(x > 0)) return "Logarithm needs a positive number";
			return Math.log10(x);
		case "sqrt":
			if (x < 0) return "Square root needs a number that isn't negative";
			return Math.sqrt(x);
		case "cbrt": return Math.cbrt(x);
		case "square": {
			const r = x * x;
			return Number.isFinite(r) ? r : "That number is too large";
		}
		case "cube": {
			const r = x * x * x;
			return Number.isFinite(r) ? r : "That number is too large";
		}
		case "recip":
			if (x === 0) return "Can't divide by zero";
			return 1 / x;
		case "exp": {
			const r = Math.exp(x);
			return Number.isFinite(r) ? r : "That number is too large";
		}
		case "fact": {
			if (x < 0 || !Number.isInteger(x)) return "Factorial needs a whole number, 0 or greater";
			if (x > 170) return "That factorial is too large";
			let r = 1;
			for (let i = 2; i <= x; i++) r *= i;
			return r;
		}
		default: return "Enter a number first";
	}
}
function fnExpr(fn, inner) {
	const g = /^-?[\d.]+$/.test(inner) || inner === "π" || inner === "e" ? inner : `(${inner})`;
	switch (fn) {
		case "sin": return `sin(${inner})`;
		case "cos": return `cos(${inner})`;
		case "tan": return `tan(${inner})`;
		case "asin": return `asin(${inner})`;
		case "acos": return `acos(${inner})`;
		case "atan": return `atan(${inner})`;
		case "ln": return `ln(${inner})`;
		case "log": return `log(${inner})`;
		case "sqrt": return `√(${inner})`;
		case "cbrt": return `∛(${inner})`;
		case "square": return `${g}²`;
		case "cube": return `${g}³`;
		case "recip": return `1/(${inner})`;
		case "exp": return `e^(${inner})`;
		case "fact": return `${g}!`;
		default: return inner;
	}
}
var PREFS_KEY = "neon-calc-prefs-v1";
var HISTORY_KEY = "neon-calc-history-v1";
var DEFAULT_PREFS = {
	theme: "midnight",
	sound: true,
	haptic: false,
	group: true,
	places: "auto"
};
var THEMES = [
	{
		id: "midnight",
		name: "Midnight Purple"
	},
	{
		id: "cyan",
		name: "Neon Cyan"
	},
	{
		id: "pink",
		name: "Pink Eclipse"
	},
	{
		id: "minimal",
		name: "Minimal Dark"
	},
	{
		id: "light",
		name: "Clean Light"
	}
];
var PLACES = [
	{
		id: "auto",
		label: "Auto"
	},
	{
		id: 0,
		label: "0"
	},
	{
		id: 2,
		label: "2"
	},
	{
		id: 4,
		label: "4"
	},
	{
		id: 6,
		label: "6"
	}
];
var STD_KEYS = [
	{
		id: "ac",
		label: "AC",
		aria: "All clear",
		tone: "danger",
		action: { type: "ac" }
	},
	{
		id: "c",
		label: "C",
		aria: "Clear entry",
		tone: "ghost",
		action: { type: "c" }
	},
	{
		id: "bs",
		label: "⌫",
		aria: "Backspace",
		tone: "ghost",
		action: { type: "bs" }
	},
	{
		id: "pct",
		label: "%",
		aria: "Percent",
		tone: "op",
		action: { type: "percent" }
	},
	{
		id: "7",
		label: "7",
		tone: "num",
		action: {
			type: "digit",
			d: "7"
		}
	},
	{
		id: "8",
		label: "8",
		tone: "num",
		action: {
			type: "digit",
			d: "8"
		}
	},
	{
		id: "9",
		label: "9",
		tone: "num",
		action: {
			type: "digit",
			d: "9"
		}
	},
	{
		id: "div",
		label: "÷",
		aria: "Divide",
		tone: "op",
		action: {
			type: "op",
			op: "/"
		}
	},
	{
		id: "4",
		label: "4",
		tone: "num",
		action: {
			type: "digit",
			d: "4"
		}
	},
	{
		id: "5",
		label: "5",
		tone: "num",
		action: {
			type: "digit",
			d: "5"
		}
	},
	{
		id: "6",
		label: "6",
		tone: "num",
		action: {
			type: "digit",
			d: "6"
		}
	},
	{
		id: "mul",
		label: "×",
		aria: "Multiply",
		tone: "op",
		action: {
			type: "op",
			op: "*"
		}
	},
	{
		id: "1",
		label: "1",
		tone: "num",
		action: {
			type: "digit",
			d: "1"
		}
	},
	{
		id: "2",
		label: "2",
		tone: "num",
		action: {
			type: "digit",
			d: "2"
		}
	},
	{
		id: "3",
		label: "3",
		tone: "num",
		action: {
			type: "digit",
			d: "3"
		}
	},
	{
		id: "sub",
		label: "−",
		aria: "Subtract",
		tone: "op",
		action: {
			type: "op",
			op: "-"
		}
	},
	{
		id: "sign",
		label: "+/−",
		aria: "Change sign",
		tone: "ghost",
		action: { type: "sign" }
	},
	{
		id: "0",
		label: "0",
		tone: "num",
		action: {
			type: "digit",
			d: "0"
		}
	},
	{
		id: "dot",
		label: ".",
		aria: "Decimal point",
		tone: "num",
		action: { type: "dot" }
	},
	{
		id: "add",
		label: "+",
		aria: "Add",
		tone: "op",
		action: {
			type: "op",
			op: "+"
		}
	},
	{
		id: "eq",
		label: "=",
		aria: "Equals",
		tone: "eq",
		action: { type: "eq" },
		wide: true
	}
];
var SCI_KEYS = [
	{
		id: "sin",
		label: "sin",
		tone: "fn",
		action: {
			type: "fn",
			fn: "sin"
		}
	},
	{
		id: "cos",
		label: "cos",
		tone: "fn",
		action: {
			type: "fn",
			fn: "cos"
		}
	},
	{
		id: "tan",
		label: "tan",
		tone: "fn",
		action: {
			type: "fn",
			fn: "tan"
		}
	},
	{
		id: "asin",
		label: "sin⁻¹",
		aria: "Inverse sine",
		tone: "fn",
		action: {
			type: "fn",
			fn: "asin"
		}
	},
	{
		id: "acos",
		label: "cos⁻¹",
		aria: "Inverse cosine",
		tone: "fn",
		action: {
			type: "fn",
			fn: "acos"
		}
	},
	{
		id: "atan",
		label: "tan⁻¹",
		aria: "Inverse tangent",
		tone: "fn",
		action: {
			type: "fn",
			fn: "atan"
		}
	},
	{
		id: "ln",
		label: "ln",
		aria: "Natural log",
		tone: "fn",
		action: {
			type: "fn",
			fn: "ln"
		}
	},
	{
		id: "log",
		label: "log",
		aria: "Log base 10",
		tone: "fn",
		action: {
			type: "fn",
			fn: "log"
		}
	},
	{
		id: "sqrt",
		label: "√",
		aria: "Square root",
		tone: "fn",
		action: {
			type: "fn",
			fn: "sqrt"
		}
	},
	{
		id: "cbrt",
		label: "∛",
		aria: "Cube root",
		tone: "fn",
		action: {
			type: "fn",
			fn: "cbrt"
		}
	},
	{
		id: "sq",
		label: "x²",
		aria: "Square",
		tone: "fn",
		action: {
			type: "fn",
			fn: "square"
		}
	},
	{
		id: "cube",
		label: "x³",
		aria: "Cube",
		tone: "fn",
		action: {
			type: "fn",
			fn: "cube"
		}
	},
	{
		id: "pow",
		label: "xʸ",
		aria: "Power",
		tone: "fn",
		action: {
			type: "op",
			op: "^"
		}
	},
	{
		id: "recip",
		label: "1/x",
		aria: "Reciprocal",
		tone: "fn",
		action: {
			type: "fn",
			fn: "recip"
		}
	},
	{
		id: "fact",
		label: "n!",
		aria: "Factorial",
		tone: "fn",
		action: {
			type: "fn",
			fn: "fact"
		}
	},
	{
		id: "exp",
		label: "eˣ",
		aria: "Exponential",
		tone: "fn",
		action: {
			type: "fn",
			fn: "exp"
		}
	},
	{
		id: "lp",
		label: "(",
		aria: "Open parenthesis",
		tone: "fn",
		action: { type: "lp" }
	},
	{
		id: "rp",
		label: ")",
		aria: "Close parenthesis",
		tone: "fn",
		action: { type: "rp" }
	},
	{
		id: "pi",
		label: "π",
		aria: "Pi",
		tone: "fn",
		action: {
			type: "const",
			name: "pi"
		}
	},
	{
		id: "e",
		label: "e",
		aria: "Euler number",
		tone: "fn",
		action: {
			type: "const",
			name: "e"
		}
	}
];
function worthHistory(expr) {
	return /[+\×÷^%√∛!()]|sin\(|cos\(|tan\(|asin\(|acos\(|atan\(|log\(|ln\(|e\^| − /.test(expr);
}
function mainClass(text, isError) {
	if (isError) return "is-error";
	const len = text.replace(/,/g, "").length;
	if (len > 18) return "is-xs";
	if (len > 14) return "is-sm";
	if (len > 10) return "is-md";
	return "is-lg";
}
function parseLoose(text) {
	const cleaned = text.trim().replace(/,/g, "").replace(/\s+/g, "");
	if (!/^-?\d+(\.\d+)?$/.test(cleaned)) return null;
	const n = Number(cleaned);
	return Number.isFinite(n) ? n : null;
}
function readField(text) {
	return parseLoose(text);
}
function isTheme(value) {
	return value === "midnight" || value === "cyan" || value === "pink" || value === "minimal" || value === "light";
}
function isPlaces(value) {
	return value === "auto" || value === 0 || value === 2 || value === 4 || value === 6;
}
function NeonCalc() {
	const [state, setState] = (0, import_react.useState)(() => createState());
	const [prefs, setPrefs] = (0, import_react.useState)(DEFAULT_PREFS);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [mode, setMode] = (0, import_react.useState)("std");
	const [panel, setPanel] = (0, import_react.useState)(null);
	const [toast, setToast] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [canAudio, setCanAudio] = (0, import_react.useState)(true);
	const [canVibrate, setCanVibrate] = (0, import_react.useState)(true);
	const stateRef = (0, import_react.useRef)(state);
	const prefsRef = (0, import_react.useRef)(prefs);
	const modeRef = (0, import_react.useRef)(mode);
	const panelRef = (0, import_react.useRef)(panel);
	const idRef = (0, import_react.useRef)(0);
	stateRef.current = state;
	prefsRef.current = prefs;
	modeRef.current = mode;
	panelRef.current = panel;
	const display = view(state, {
		group: prefs.group,
		places: prefs.places
	});
	const flash = (0, import_react.useCallback)((message) => {
		setToast(message);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const id = window.setTimeout(() => setToast(null), 1600);
		return () => window.clearTimeout(id);
	}, [toast]);
	(0, import_react.useEffect)(() => {
		setCanAudio(audioSupported());
		setCanVibrate(typeof navigator.vibrate === "function");
		try {
			const savedPrefs = localStorage.getItem(PREFS_KEY);
			if (savedPrefs) {
				const parsed = JSON.parse(savedPrefs);
				setPrefs({
					theme: isTheme(parsed.theme) ? parsed.theme : DEFAULT_PREFS.theme,
					sound: typeof parsed.sound === "boolean" ? parsed.sound : DEFAULT_PREFS.sound,
					haptic: typeof parsed.haptic === "boolean" ? parsed.haptic : DEFAULT_PREFS.haptic,
					group: typeof parsed.group === "boolean" ? parsed.group : DEFAULT_PREFS.group,
					places: isPlaces(parsed.places) ? parsed.places : DEFAULT_PREFS.places
				});
				setState((current) => ({
					...current,
					angle: parsed.angle === "rad" ? "rad" : "deg",
					memory: typeof parsed.memory === "number" && Number.isFinite(parsed.memory) ? parsed.memory : 0
				}));
			}
			const savedHistory = localStorage.getItem(HISTORY_KEY);
			if (savedHistory) {
				const parsed = JSON.parse(savedHistory);
				if (Array.isArray(parsed)) setHistory(parsed.filter((item) => item && typeof item.expr === "string" && typeof item.result === "string" && typeof item.value === "number").slice(0, 40));
			}
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = prefs.theme;
	}, [prefs.theme]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		try {
			localStorage.setItem(PREFS_KEY, JSON.stringify({
				...prefs,
				angle: state.angle,
				memory: state.memory
			}));
		} catch {}
	}, [
		prefs,
		state.angle,
		state.memory,
		hydrated
	]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		try {
			localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
		} catch {}
	}, [history, hydrated]);
	const copyText = (0, import_react.useCallback)(async (text) => {
		if (!text) {
			flash("Nothing to copy");
			return;
		}
		try {
			await navigator.clipboard.writeText(text);
			flash("Copied");
		} catch {
			flash("Couldn't copy that");
		}
	}, [flash]);
	const pasteValue = (0, import_react.useCallback)(async () => {
		try {
			const n = parseLoose(await navigator.clipboard.readText());
			if (n == null) {
				flash("Couldn't paste that");
				return;
			}
			setState((prev) => reduce(prev, {
				type: "load",
				value: n
			}));
			flash("Pasted");
		} catch {
			flash("Paste isn't available here");
		}
	}, [flash]);
	const act = (0, import_react.useCallback)((action) => {
		const prev = stateRef.current;
		const next = reduce(prev, action);
		stateRef.current = next;
		setState(next);
		if (action.type === "eq" && next.evaluated && !next.error && next.ans != null && worthHistory(next.exprSnapshot)) {
			const formatted = formatResult(next.ans, prefsRef.current);
			const item = {
				id: `${Date.now()}-${idRef.current++}`,
				expr: next.exprSnapshot,
				result: formatted,
				value: next.ans
			};
			setHistory((items) => {
				if (items[0] && items[0].expr === item.expr && items[0].result === item.result) return items;
				return [item, ...items].slice(0, 40);
			});
		}
		const currentPrefs = prefsRef.current;
		if (currentPrefs.haptic) try {
			navigator.vibrate?.(10);
		} catch {}
		if (next.error && !prev.error) playTone("err", currentPrefs.sound);
		else if (action.type === "eq" && !next.error) playTone("eq", currentPrefs.sound);
		else playTone("tap", currentPrefs.sound);
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
			if (event.metaKey || event.ctrlKey || event.altKey) {
				const key = event.key.toLowerCase();
				if ((event.metaKey || event.ctrlKey) && key === "c") {
					event.preventDefault();
					const shown = view(stateRef.current, prefsRef.current);
					copyText(shown.copyText);
				}
				if ((event.metaKey || event.ctrlKey) && key === "v") {
					event.preventDefault();
					pasteValue();
				}
				return;
			}
			if (event.key === "Escape") {
				event.preventDefault();
				if (panelRef.current) {
					setPanel(null);
					return;
				}
				act({ type: "ac" });
				return;
			}
			if (panelRef.current || modeRef.current === "pct") return;
			let action = null;
			if (/^\d$/.test(event.key)) action = {
				type: "digit",
				d: event.key
			};
			else if (event.key === "." || event.key === ",") action = { type: "dot" };
			else if (event.key === "+") action = {
				type: "op",
				op: "+"
			};
			else if (event.key === "-") action = {
				type: "op",
				op: "-"
			};
			else if (event.key === "*") action = {
				type: "op",
				op: "*"
			};
			else if (event.key === "/") action = {
				type: "op",
				op: "/"
			};
			else if (event.key === "^") action = {
				type: "op",
				op: "^"
			};
			else if (event.key === "Enter" || event.key === "=") action = { type: "eq" };
			else if (event.key === "Backspace") action = { type: "bs" };
			else if (event.key === "Delete") action = { type: "c" };
			else if (event.key === "%") action = { type: "percent" };
			else if (event.key === "(") action = { type: "lp" };
			else if (event.key === ")") action = { type: "rp" };
			else return;
			event.preventDefault();
			event.stopPropagation();
			act(action);
		};
		const onPaste = (event) => {
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
			const n = parseLoose(event.clipboardData?.getData("text") ?? "");
			if (n == null) {
				flash("Couldn't paste that");
				return;
			}
			event.preventDefault();
			act({
				type: "load",
				value: n
			});
			flash("Pasted");
		};
		window.addEventListener("keydown", onKey, true);
		window.addEventListener("paste", onPaste);
		return () => {
			window.removeEventListener("keydown", onKey, true);
			window.removeEventListener("paste", onPaste);
		};
	}, [
		act,
		copyText,
		flash,
		pasteValue
	]);
	const useValue = (value) => {
		act({
			type: "load",
			value
		});
		setMode("std");
		setPanel(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "nc-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `nc-frame ${mode === "sci" ? "is-sci" : ""} ${mode === "pct" ? "is-pct" : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "nc-top",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "nc-mark",
							children: "Neon Calc"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "nc-sub",
							children: "Gen Z Edition"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "nc-top-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "nc-icon-btn",
								"aria-label": "History",
								onClick: () => setPanel("history"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "nc-icon-btn",
								"aria-label": "Settings",
								onClick: () => setPanel("settings"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "nc-modes",
						role: "tablist",
						"aria-label": "Calculator mode",
						children: [
							["std", "Standard"],
							["sci", "Scientific"],
							["pct", "Percent"]
						].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "nc-tab",
							role: "tab",
							"aria-selected": mode === id,
							onClick: () => setMode(id),
							children: label
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "nc-screen",
						"aria-live": "polite",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "nc-screen-tools",
								children: [
									display.memoryOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "nc-pill",
										children: "M"
									}) : null,
									mode === "sci" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "nc-angle",
										role: "group",
										"aria-label": "Angle unit",
										children: ["deg", "rad"].map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": state.angle === unit,
											onClick: () => act({
												type: "angle",
												mode: unit
											}),
											children: unit === "deg" ? "DEG" : "RAD"
										}, unit))
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "nc-icon-btn nc-mini",
										"aria-label": "Copy result",
										onClick: () => void copyText(display.copyText),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "nc-icon-btn nc-mini",
										"aria-label": "Paste number",
										onClick: () => void pasteValue(),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "nc-expr",
								children: display.expression || "\xA0"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `nc-main ${mainClass(display.main, display.isError)}`,
								children: display.main
							})
						]
					}),
					mode === "pct" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PercentBoard, {
						onUse: useValue,
						onCopy: (text) => void copyText(text)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "nc-board",
						children: [mode === "sci" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyGrid, {
							keys: SCI_KEYS,
							className: "nc-sci",
							onPress: act
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "nc-std",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "nc-mem",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Memory clear",
										onClick: () => act({
											type: "mem",
											m: "mc"
										}),
										children: "MC"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Memory recall",
										onClick: () => act({
											type: "mem",
											m: "mr"
										}),
										children: "MR"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Memory add",
										onClick: () => act({
											type: "mem",
											m: "mp"
										}),
										children: "M+"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Memory subtract",
										onClick: () => act({
											type: "mem",
											m: "mm"
										}),
										children: "M−"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyGrid, {
								keys: STD_KEYS,
								onPress: act
							})]
						})]
					})
				]
			}),
			panel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nc-shade",
				onClick: () => setPanel(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nc-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": panel === "history" ? "History" : "Settings",
					onClick: (event) => event.stopPropagation(),
					children: panel === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryPanel, {
						items: history,
						onClose: () => setPanel(null),
						onUse: useValue,
						onCopy: (text) => void copyText(text),
						onClear: () => {
							setHistory([]);
							flash("History cleared");
						}
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {
						prefs,
						canAudio,
						canVibrate,
						onClose: () => setPanel(null),
						onChange: setPrefs,
						onReset: () => {
							setPrefs(DEFAULT_PREFS);
							flash("Settings reset");
						}
					})
				})
			}) : null,
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nc-toast",
				role: "status",
				children: toast
			}) : null
		]
	});
}
function KeyGrid({ keys, onPress, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `nc-grid ${className ?? ""}`,
		children: keys.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: `nc-key nc-key-${key.tone} ${key.wide ? "nc-key-wide" : ""}`,
			"aria-label": key.aria ?? key.label,
			onClick: () => onPress(key.action),
			children: key.label
		}, key.id))
	});
}
function HistoryPanel({ items, onClose, onUse, onCopy, onClear }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nc-panel-head",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "History" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "nc-icon-btn",
				"aria-label": "Close history",
				onClick: onClose,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
			})]
		}),
		items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "nc-empty",
			children: "No calculations yet. Finished results will show up here."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nc-history-list",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nc-history-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "nc-history-item",
					onClick: () => onUse(item.value),
					"aria-label": `Use result ${item.result}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.expr }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.result })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nc-row-actions",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "nc-text-btn",
						onClick: () => onCopy(item.result),
						children: "Copy"
					})
				})]
			}, item.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "nc-text-btn",
			onClick: onClear,
			disabled: items.length === 0,
			children: "Clear history"
		})
	] });
}
function SettingsPanel({ prefs, canAudio, canVibrate, onClose, onChange, onReset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nc-panel-head",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Settings" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "nc-icon-btn",
				"aria-label": "Close settings",
				onClick: onClose,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "nc-note",
			children: "Theme"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nc-swatches",
			children: THEMES.map((theme) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: `nc-swatch is-${theme.id}`,
				"aria-pressed": prefs.theme === theme.id,
				onClick: () => onChange({
					...prefs,
					theme: theme.id
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nc-swatch-dot" }), theme.name]
			}, theme.id))
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nc-setting",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Button sounds" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `nc-switch ${prefs.sound ? "is-on" : ""}`,
				role: "switch",
				"aria-checked": prefs.sound,
				"aria-label": "Button sounds",
				disabled: !canAudio,
				onClick: () => onChange({
					...prefs,
					sound: !prefs.sound
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
			})]
		}),
		!canAudio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "nc-note",
			children: "Sound isn't supported in this browser."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nc-setting",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Haptic feedback" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `nc-switch ${prefs.haptic ? "is-on" : ""}`,
				role: "switch",
				"aria-checked": prefs.haptic,
				"aria-label": "Haptic feedback",
				disabled: !canVibrate,
				onClick: () => onChange({
					...prefs,
					haptic: !prefs.haptic
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
			})]
		}),
		!canVibrate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "nc-note",
			children: "Haptics aren't supported on this device."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "nc-note",
			children: "Decimal places"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nc-choices",
			children: PLACES.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "nc-choice",
				"aria-pressed": prefs.places === place.id,
				onClick: () => onChange({
					...prefs,
					places: place.id
				}),
				children: place.label
			}, String(place.id)))
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nc-setting",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Thousands separators" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `nc-switch ${prefs.group ? "is-on" : ""}`,
				role: "switch",
				"aria-checked": prefs.group,
				"aria-label": "Thousands separators",
				onClick: () => onChange({
					...prefs,
					group: !prefs.group
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "nc-note",
			children: "The % key, after + or −, takes that percent of the left side. After × or ÷, 15% becomes 0.15. On its own, it divides by 100."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nc-inline",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "nc-text-btn nc-link",
				href: "/neon_calc.html",
				download: "neon_calc.html",
				children: "Save offline copy"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "nc-text-btn",
				onClick: onReset,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 16 }), " Reset settings"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "nc-note",
			children: "The offline copy is one HTML file. Save it, then open it in Chrome on a tablet with no internet."
		})
	] });
}
function PercentBoard({ onUse, onCopy }) {
	const [ofPct, setOfPct] = (0, import_react.useState)("15");
	const [ofBase, setOfBase] = (0, import_react.useState)("200");
	const [upBase, setUpBase] = (0, import_react.useState)("200");
	const [upPct, setUpPct] = (0, import_react.useState)("15");
	const [downBase, setDownBase] = (0, import_react.useState)("200");
	const [downPct, setDownPct] = (0, import_react.useState)("15");
	const [from, setFrom] = (0, import_react.useState)("80");
	const [to, setTo] = (0, import_react.useState)("100");
	const [diffA, setDiffA] = (0, import_react.useState)("80");
	const [diffB, setDiffB] = (0, import_react.useState)("100");
	const ofValue = pair((a, b) => b * a / 100, ofPct, ofBase);
	const upValue = pair((base, pct) => base * (1 + pct / 100), upBase, upPct);
	const downValue = pair((base, pct) => base * (1 - pct / 100), downBase, downPct);
	const change = changeOf(from, to);
	const diff = diffOf(diffA, diffB);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "nc-board",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nc-cards",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcCard, {
					title: "Percent of a number",
					text: "What is X% of Y?",
					fields: [[
						"Percent",
						ofPct,
						setOfPct
					], [
						"Of",
						ofBase,
						setOfBase
					]],
					value: ofValue,
					suffix: "",
					onUse,
					onCopy
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcCard, {
					title: "Increase",
					text: "Raise a number by a percent.",
					fields: [[
						"Start",
						upBase,
						setUpBase
					], [
						"Percent",
						upPct,
						setUpPct
					]],
					value: upValue,
					suffix: "",
					onUse,
					onCopy
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcCard, {
					title: "Decrease",
					text: "Lower a number by a percent.",
					fields: [[
						"Start",
						downBase,
						setDownBase
					], [
						"Percent",
						downPct,
						setDownPct
					]],
					value: downValue,
					suffix: "",
					onUse,
					onCopy
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcCard, {
					title: "Percent change",
					text: "From A to B, compared with A.",
					fields: [[
						"From",
						from,
						setFrom
					], [
						"To",
						to,
						setTo
					]],
					value: change,
					suffix: "%",
					onUse,
					onCopy
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcCard, {
					title: "Percent difference",
					text: "How far apart two numbers are, compared with their average.",
					fields: [[
						"First",
						diffA,
						setDiffA
					], [
						"Second",
						diffB,
						setDiffB
					]],
					value: diff,
					suffix: "%",
					onUse,
					onCopy
				})
			]
		})
	});
}
function pair(fn, a, b) {
	const left = readField(a);
	const right = readField(b);
	if (left == null || right == null) return null;
	const value = fn(left, right);
	return Number.isFinite(value) ? value : null;
}
function changeOf(from, to) {
	const a = readField(from);
	const b = readField(to);
	if (a == null || b == null || a === 0) return null;
	const value = (b - a) / Math.abs(a) * 100;
	return Number.isFinite(value) ? value : null;
}
function diffOf(aText, bText) {
	const a = readField(aText);
	const b = readField(bText);
	if (a == null || b == null) return null;
	const den = (Math.abs(a) + Math.abs(b)) / 2;
	if (den === 0) return null;
	const value = Math.abs(a - b) / den * 100;
	return Number.isFinite(value) ? value : null;
}
function CalcCard({ title, text, fields, value, suffix, onUse, onCopy }) {
	const shown = value == null ? "—" : `${formatResult(value, {
		group: true,
		places: "auto"
	})}${suffix}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "nc-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: title }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nc-fields",
				children: fields.map(([label, field, setField]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nc-field",
					children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "decimal",
						value: field,
						"aria-label": label,
						onChange: (event) => {
							const next = event.target.value;
							if (next === "" || /^-?\d*\.?\d*$/.test(next)) setField(next);
						}
					})]
				}, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nc-result-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "nc-result",
					children: shown
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nc-inline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "nc-text-btn",
						disabled: value == null,
						onClick: () => value != null && onCopy(shown),
						children: "Copy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "nc-text-btn",
						disabled: value == null,
						onClick: () => value != null && onUse(value),
						children: "Use"
					})]
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeonCalc, {});
}
//#endregion
export { Home as component };
