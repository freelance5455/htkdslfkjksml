import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { n as buildAnalyzePrompt, o as withImageGuards, r as localBeats } from "./prompts-C2oS8e1R.mjs";
import { a as number, n as array, o as object, r as boolean, s as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-C79IeUDk.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ASPECTS = [
	"1:1",
	"4:5",
	"9:16",
	"16:9"
];
var analyzeSchema = object({
	category: string().max(80),
	customCategory: string().max(200),
	campaign: string().max(80),
	customCampaign: string().max(200),
	story: string().max(2e3),
	sceneCount: number().int().min(3).max(10),
	style: string().max(80),
	customStyle: string().max(500),
	aspect: _enum(ASPECTS),
	consistencyLock: boolean(),
	images: array(string().min(30).max(12e5)).min(1).max(4)
});
var imageSchema = object({
	prompt: string().min(20).max(8e3),
	aspect: _enum(ASPECTS),
	images: array(string().min(30).max(12e5)).min(1).max(4),
	profile: string().max(4e3),
	consistencyLock: boolean()
});
var CHAT_MODEL = "grok-4.5";
var IMAGE_MODEL = "grok-imagine-image-2.0";
function clip(value, max, fallback) {
	if (typeof value !== "string") return fallback;
	const text = value.replace(/\s+/g, " ").trim();
	if (!text) return fallback;
	return text.slice(0, max);
}
async function xaiFetch(path, body, timeoutMs) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) throw new Error("AI tidak tersedia di lingkungan ini.");
	let last = null;
	for (let attempt = 0; attempt < 2; attempt++) {
		const res = await fetch(`https://api.x.ai/v1${path}`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify(body),
			signal: AbortSignal.timeout(timeoutMs)
		});
		if (res.ok) return res;
		last = res;
		if (![
			429,
			500,
			502,
			503
		].includes(res.status) || attempt === 1) break;
		await new Promise((r) => setTimeout(r, 1200));
	}
	return last;
}
async function readError(res) {
	const text = await res.text();
	try {
		const json = JSON.parse(text);
		const message = json.error?.message || json.message;
		if (typeof message === "string" && message.length < 280) return message;
	} catch {}
	return `Permintaan AI gagal (${res.status}).`;
}
function extractJson(text) {
	const trimmed = text.trim().replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
	const start = trimmed.indexOf("{");
	const end = trimmed.lastIndexOf("}");
	if (start < 0 || end <= start) throw new Error("Analisis tidak mengembalikan data.");
	return JSON.parse(trimmed.slice(start, end + 1));
}
var analyzeProduct_createServerFn_handler = createServerRpc({
	id: "8e2ffb7a3302c24253f53288a6d4b2e15263d91209b4b159d694d7fe014fa36d",
	name: "analyzeProduct",
	filename: "src/lib/storyboard/server.ts"
}, (opts) => analyzeProduct.__executeServer(opts));
var analyzeProduct = createServerFn({ method: "POST" }).validator((input) => input).handler(analyzeProduct_createServerFn_handler, async ({ data }) => {
	const parsed = analyzeSchema.safeParse(data);
	if (!parsed.success) return {
		ok: false,
		error: "Data storyboard tidak valid."
	};
	const input = parsed.data;
	const pseudo = {
		...input,
		profile: "",
		productName: ""
	};
	const beats = localBeats(pseudo);
	if (!process.env.XAI_API_KEY) return {
		ok: true,
		source: "local",
		productName: "",
		profile: "",
		scenes: beats,
		note: "AI tidak tersedia. Rencana disusun dari pengaturan kamu."
	};
	try {
		const res = await xaiFetch("/chat/completions", {
			model: CHAT_MODEL,
			temperature: .4,
			max_tokens: 4e3,
			response_format: { type: "json_object" },
			messages: [{
				role: "user",
				content: [{
					type: "text",
					text: buildAnalyzePrompt(pseudo, beats)
				}, ...input.images.map((url) => ({
					type: "image_url",
					image_url: {
						url,
						detail: "high"
					}
				}))]
			}]
		}, 6e4);
		if (!res.ok) return {
			ok: false,
			error: await readError(res),
			scenes: beats
		};
		const json = extractJson((await res.json()).choices?.[0]?.message?.content ?? "");
		const rawScenes = Array.isArray(json.scenes) ? json.scenes : [];
		const scenes = beats.map((beat, index) => {
			const row = rawScenes[index] ?? {};
			return {
				title: clip(row.title, 80, beat.title),
				description: clip(row.description, 500, beat.description),
				cameraAngle: clip(row.cameraAngle, 180, beat.cameraAngle),
				cameraDistance: clip(row.cameraDistance, 180, beat.cameraDistance),
				lighting: clip(row.lighting, 280, beat.lighting),
				background: clip(row.background, 360, beat.background),
				props: clip(row.props, 360, beat.props),
				humanInteraction: clip(row.humanInteraction, 400, beat.humanInteraction),
				mood: clip(row.mood, 160, beat.mood),
				motion: clip(row.motion, 360, beat.motion)
			};
		});
		return {
			ok: true,
			source: "ai",
			productName: clip(json.productName, 80, ""),
			profile: clip(json.profile, 2500, ""),
			scenes,
			note: ""
		};
	} catch (error) {
		return {
			ok: false,
			error: (error instanceof Error ? error.message : "Analisis gagal.").slice(0, 240),
			scenes: beats
		};
	}
});
function imagePayload(prompt, aspect, images) {
	const shared = {
		model: IMAGE_MODEL,
		prompt,
		aspect_ratio: aspect,
		resolution: "1k",
		quality: "medium",
		response_format: "b64_json",
		n: 1
	};
	if (images.length === 1) return {
		...shared,
		image: {
			url: images[0],
			type: "image_url"
		}
	};
	return {
		...shared,
		images: images.map((url) => ({
			type: "image_url",
			url
		}))
	};
}
var prefer34 = false;
function aspectFor(aspect) {
	if (aspect === "4:5" && prefer34) return "3:4";
	return aspect;
}
async function imageToDataUrl(json) {
	const root = json;
	const item = root.data?.[0] ?? root.image ?? root;
	const b64 = item && "b64_json" in item ? item.b64_json : item && "base64" in item ? item.base64 : void 0;
	if (typeof b64 === "string" && b64.length > 40) return b64.startsWith("data:") ? b64 : `data:image/jpeg;base64,${b64}`;
	const url = item && "url" in item && typeof item.url === "string" ? item.url : void 0;
	if (!url) return null;
	const fetched = await fetch(url, { signal: AbortSignal.timeout(3e4) });
	if (!fetched.ok) return null;
	const buf = Buffer.from(await fetched.arrayBuffer());
	return `data:${fetched.headers.get("content-type") || "image/jpeg"};base64,${buf.toString("base64")}`;
}
var generateSceneImage_createServerFn_handler = createServerRpc({
	id: "27c91c00a7dfeafbfd538a57203c2b2a0ff00bd536c1a258fd1a46787beb67f7",
	name: "generateSceneImage",
	filename: "src/lib/storyboard/server.ts"
}, (opts) => generateSceneImage.__executeServer(opts));
var generateSceneImage = createServerFn({ method: "POST" }).validator((input) => input).handler(generateSceneImage_createServerFn_handler, async ({ data }) => {
	const parsed = imageSchema.safeParse(data);
	if (!parsed.success) return {
		ok: false,
		error: "Prompt atau foto referensi tidak valid."
	};
	if (!process.env.XAI_API_KEY) return {
		ok: false,
		error: "Pembuatan gambar tidak tersedia di lingkungan ini."
	};
	const prompt = withImageGuards(parsed.data.prompt, parsed.data.profile, parsed.data.consistencyLock);
	const attempts = [parsed.data.aspect];
	try {
		let res = await xaiFetch("/images/edits", imagePayload(prompt, aspectFor(parsed.data.aspect), parsed.data.images), 9e4);
		if (!res.ok && parsed.data.aspect === "4:5") {
			const errText = await res.text();
			if (/aspect|ratio/i.test(errText)) {
				prefer34 = true;
				res = await xaiFetch("/images/edits", imagePayload(prompt, "3:4", parsed.data.images), 9e4);
			} else return {
				ok: false,
				error: errText.slice(0, 240) || "Gagal membuat gambar."
			};
		}
		if (!res.ok) return {
			ok: false,
			error: await readError(res)
		};
		const dataUrl = await imageToDataUrl(await res.json());
		if (!dataUrl) return {
			ok: false,
			error: "Gambar tidak kembali dari model."
		};
		return {
			ok: true,
			dataUrl,
			usedAspect: attempts[0] === "4:5" && prefer34 ? "3:4" : parsed.data.aspect
		};
	} catch (error) {
		return {
			ok: false,
			error: (error instanceof Error ? error.message : "Gagal membuat gambar.").slice(0, 240)
		};
	}
});
//#endregion
export { analyzeProduct_createServerFn_handler, generateSceneImage_createServerFn_handler };
