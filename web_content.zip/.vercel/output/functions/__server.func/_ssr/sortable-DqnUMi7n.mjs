import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { m as GripVertical } from "../_libs/lucide-react.mjs";
import { k as cn } from "./router-CQnHyG8o.mjs";
import { t as moveItem } from "./id-capIYR7Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sortable-DqnUMi7n.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Pointer drag from the grip, plus arrow keys.
* Listeners sit on window so a reorder re-render cannot drop the gesture.
*/
function SortableList({ items, getId, onReorder, render, className }) {
	const [dragId, setDragId] = (0, import_react.useState)(null);
	const itemsRef = (0, import_react.useRef)(items);
	const onReorderRef = (0, import_react.useRef)(onReorder);
	const cleanupRef = (0, import_react.useRef)(null);
	itemsRef.current = items;
	onReorderRef.current = onReorder;
	(0, import_react.useEffect)(() => () => cleanupRef.current?.(), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: cn("grid gap-2", className),
		children: items.map((item, index) => {
			const id = getId(item);
			const grip = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Reorder",
				className: "grid size-11 shrink-0 cursor-grab touch-none place-items-center rounded-lg text-muted hover:bg-paper hover:text-ink active:cursor-grabbing focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
				onKeyDown: (event) => {
					if (event.key !== "ArrowUp" && event.key !== "ArrowDown") return;
					event.preventDefault();
					const dir = event.key === "ArrowUp" ? -1 : 1;
					onReorder(moveItem(itemsRef.current, index, index + dir));
				},
				onPointerDown: (event) => {
					if (event.button !== 0) return;
					event.preventDefault();
					const startY = event.clientY;
					const origin = itemsRef.current.slice();
					const from = index;
					let last = from;
					const row = (event.currentTarget.closest("li")?.getBoundingClientRect().height ?? 56) + 8;
					setDragId(id);
					const move = (ev) => {
						const steps = Math.round((ev.clientY - startY) / row);
						const target = Math.max(0, Math.min(origin.length - 1, from + steps));
						if (target === last) return;
						last = target;
						const copy = origin.slice();
						const [picked] = copy.splice(from, 1);
						if (picked === void 0) return;
						copy.splice(target, 0, picked);
						onReorderRef.current(copy);
					};
					const end = () => {
						setDragId(null);
						window.removeEventListener("pointermove", move);
						window.removeEventListener("pointerup", end);
						window.removeEventListener("pointercancel", end);
						cleanupRef.current = null;
					};
					cleanupRef.current = end;
					window.addEventListener("pointermove", move);
					window.addEventListener("pointerup", end);
					window.addEventListener("pointercancel", end);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, {
					className: "size-4",
					strokeWidth: 1.6
				})
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: cn(dragId === id && "relative z-10 opacity-80"),
				children: render(item, grip)
			}, id);
		})
	});
}
//#endregion
export { SortableList as t };
