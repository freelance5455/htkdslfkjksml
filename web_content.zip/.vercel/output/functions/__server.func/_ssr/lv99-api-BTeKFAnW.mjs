import { n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lv99-api-BTeKFAnW.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var MODES = /* @__PURE__ */ new Set([
	"chat",
	"code",
	"write",
	"translate",
	"study",
	"math",
	"plan",
	"business",
	"vision",
	"imagine"
]);
var IMAGE_RE = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
var GUIDE = {
	chat: "সাধারণ সহকারী হিসেবে স্পষ্ট ও সরাসরি উত্তর দাও।",
	code: "তুমি সিনিয়র ইঞ্জিনিয়ার। কাজ করা কোড দাও, কারণ বলো, কোড ব্লক ব্যবহার করো।",
	write: "তুমি সম্পাদক। লেখা শক্ত, পরিষ্কার ও উদ্দেশ্যমতো করো।",
	translate: "অনুবাদক। অর্থ ঠিক রেখে স্বাভাবিক ভাষায় অনুবাদ করো। লক্ষ্য ভাষা না বললে বাংলা ও ইংরেজির মধ্যে ধরে নাও।",
	study: "ধৈর্যশীল শিক্ষক। সহজ উদাহরণে বোঝাও, শেষে একটা ছোট প্রশ্ন দিয়ে যাচাই করো।",
	math: "গণিত ধাপে ধাপে দেখাও এবং শেষে উত্তর আলাদা করে লেখো।",
	plan: "ব্যবহারযোগ্য পরিকল্পনা দাও: লক্ষ্য, ধাপ, সময় ও একটা ঝুঁকি।",
	business: "আইডিয়া, সম্ভাব্য খরচ, গ্রাহক ও পরের একটা কাজ স্পষ্ট করো। অতিরঞ্জন কোরো না।",
	vision: "ছবিতে সত্যিই যা দেখা যায় তা বলো। নিশ্চিত না হলে ‘মনে হচ্ছে’ বলে চিহ্নিত করো।",
	imagine: "ছবির বিবরণ সংক্ষেপে সাজাও।"
};
function instructions(mode, depth, lang) {
	return [
		"তুমি LV99 AI, একজন শক্তিশালী ব্যক্তিগত সহকারী।",
		lang === "bn" ? "সবসময় বাংলায় উত্তর দাও।" : lang === "en" ? "Always answer in English." : "ব্যবহারকারী যে ভাষায় লেখে সেই ভাষায় উত্তর দাও। বাংলা হলে স্বাভাবিক বাংলা ব্যবহার করো।",
		depth === "brief" ? "উত্তর সংক্ষিপ্ত রাখো।" : depth === "deep" ? "গভীরভাবে বলো, তবে গুছিয়ে — পুনরাবৃত্তি কমিয়ে।" : "মাঝারি দৈর্ঘ্যে পরিষ্কার উত্তর দাও।",
		GUIDE[mode],
		"নিশ্চিত নও এমন তথ্য বানিয়ে বলো না। অনিশ্চিত হলে স্পষ্ট করো।",
		"চিকিৎসা, আইন, টাকা বা জরুরি সিদ্ধান্ত নিজে যাচাই করতে বলো।",
		"সাম্প্রতিক খবর, দাম বা আইন নিয়ে নিশ্চিত দাবি কোরো না।",
		"ক্ষতিকর বা অবৈধ কাজে সাহায্য কোরো না।",
		"ছবি থাকলে শুধু দৃশ্যমান বিষয় বর্ণনা করো।"
	].join(" ");
}
var hits = /* @__PURE__ */ new Map();
function allow(bucket, limit) {
	const now = Date.now();
	const arr = (hits.get(bucket) ?? []).filter((t) => now - t < 6e4);
	if (arr.length >= limit) {
		hits.set(bucket, arr);
		return false;
	}
	arr.push(now);
	hits.set(bucket, arr);
	return true;
}
async function clientKey() {
	try {
		return (await import("./ssr.mjs").then((n) => n.o).then((n) => n.t)).getRequest().headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
	} catch {
		return "local";
	}
}
function classify(status, raw) {
	if (status === 403 || raw.includes("spending-limit") || raw.includes("credits")) return {
		ok: false,
		error: "credit"
	};
	if (status === 429) return {
		ok: false,
		error: "rate"
	};
	return {
		ok: false,
		error: "failed"
	};
}
function extractText(body) {
	if (!body || typeof body !== "object") return "";
	const record = body;
	if (typeof record.output_text === "string" && record.output_text.trim()) return record.output_text.trim();
	const choice = record.choices?.[0]?.message?.content;
	if (typeof choice === "string" && choice.trim()) return choice.trim();
	const output = record.output;
	if (!Array.isArray(output)) return "";
	const parts = [];
	for (const item of output) {
		if (!item || typeof item !== "object") continue;
		const content = item.content;
		if (typeof content === "string") parts.push(content);
		if (!Array.isArray(content)) continue;
		for (const part of content) {
			if (!part || typeof part !== "object") continue;
			const text = part.text;
			const type = part.type;
			if (typeof text === "string" && text && type !== "reasoning") parts.push(text);
		}
	}
	return parts.join("\n").trim();
}
function extractImageUrl(body) {
	if (!body || typeof body !== "object") return "";
	const record = body;
	const data = record.data;
	if (Array.isArray(data) && data[0] && typeof data[0] === "object") {
		const row = data[0];
		if (typeof row.url === "string") return row.url;
		if (typeof row.b64_json === "string") return `data:image/png;base64,${row.b64_json}`;
	}
	if (typeof record.url === "string") return record.url;
	return "";
}
function parseAsk(input) {
	if (!input || typeof input !== "object") throw new Error("ইনপুট ঠিক নেই।");
	const raw = input;
	if (!raw.mode || !MODES.has(raw.mode)) throw new Error("মোড ঠিক নেই।");
	const depth = raw.depth === "brief" || raw.depth === "deep" ? raw.depth : "normal";
	const lang = raw.lang === "bn" || raw.lang === "en" ? raw.lang : "auto";
	if (!Array.isArray(raw.turns) || raw.turns.length === 0 || raw.turns.length > 16) throw new Error("কথোপকথন খুব বড় বা খালি।");
	const turns = raw.turns.map((turn, index) => {
		if (!turn || turn.role !== "user" && turn.role !== "assistant" || typeof turn.text !== "string") throw new Error("বার্তা ঠিক নেই।");
		const text = turn.text.trim().slice(0, 6e3);
		const image = index === raw.turns.length - 1 && turn.role === "user" && typeof turn.imageDataUrl === "string" ? turn.imageDataUrl : void 0;
		if (image && (image.length > 26e5 || !IMAGE_RE.test(image))) throw new Error("ছবির ফরম্যাট গ্রহণযোগ্য নয়।");
		if (!text && !image) throw new Error("লেখা বা ছবি লাগবে।");
		return {
			role: turn.role,
			text,
			imageDataUrl: image
		};
	});
	const threadId = typeof raw.threadId === "string" && UUID_RE.test(raw.threadId) ? raw.threadId : void 0;
	return {
		mode: raw.mode,
		depth,
		lang,
		threadId,
		turns
	};
}
var lv99Status_createServerFn_handler = createServerRpc({
	id: "cb2c564f16a972d417393572d608c6722a09c0088b4b1d8e8a4275652e0b4c12",
	name: "lv99Status",
	filename: "src/lib/lv99-api.ts"
}, (opts) => lv99Status.__executeServer(opts));
var lv99Status = createServerFn({ method: "GET" }).handler(lv99Status_createServerFn_handler, () => {
	return { ready: Boolean(process.env.XAI_API_KEY) };
});
var askLv99_createServerFn_handler = createServerRpc({
	id: "ba4d1d36d5473b8cd1f126adc02529947a6c610360270bae7b15367683b2fd89",
	name: "askLv99",
	filename: "src/lib/lv99-api.ts"
}, (opts) => askLv99.__executeServer(opts));
var askLv99 = createServerFn({ method: "POST" }).validator(parseAsk).handler(askLv99_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "unavailable"
	};
	if (!allow(`chat:${await clientKey()}`, 12)) return {
		ok: false,
		error: "rate"
	};
	const tokens = data.depth === "brief" ? 420 : data.depth === "deep" ? 1400 : 900;
	const input = data.turns.map((turn) => {
		if (turn.imageDataUrl) return {
			role: "user",
			content: [{
				type: "input_text",
				text: turn.text || "এই ছবিটি বিশ্লেষণ করে বাংলায় বুঝিয়ে বলো।"
			}, {
				type: "input_image",
				image_url: turn.imageDataUrl,
				detail: data.mode === "vision" ? "high" : "auto"
			}]
		};
		return {
			role: turn.role,
			content: turn.text
		};
	});
	const headers = {
		"Content-Type": "application/json",
		Authorization: `Bearer ${apiKey}`
	};
	if (data.threadId) headers["x-grok-conv-id"] = data.threadId;
	const body = {
		model: "grok-4.7",
		instructions: instructions(data.mode, data.depth, data.lang),
		input,
		max_output_tokens: tokens,
		reasoning: { effort: data.depth === "deep" ? "medium" : "low" }
	};
	try {
		let res = await fetch("https://api.x.ai/v1/responses", {
			method: "POST",
			headers,
			body: JSON.stringify(body)
		});
		if (res.status === 400) res = await fetch("https://api.x.ai/v1/responses", {
			method: "POST",
			headers,
			body: JSON.stringify({
				model: "grok-4.5",
				instructions: body.instructions,
				input,
				max_output_tokens: tokens
			})
		});
		const raw = await res.text();
		if (!res.ok) {
			console.error("LV99 chat failed", res.status);
			return classify(res.status, raw);
		}
		const text = extractText(JSON.parse(raw));
		if (!text) return {
			ok: false,
			error: "failed"
		};
		return {
			ok: true,
			text: text.slice(0, 12e3)
		};
	} catch (err) {
		console.error("LV99 chat error", err instanceof Error ? err.name : "unknown");
		return {
			ok: false,
			error: "failed"
		};
	}
});
function parseDraw(input) {
	if (!input || typeof input !== "object") throw new Error("ইনপুট ঠিক নেই।");
	const raw = input;
	const prompt = typeof raw.prompt === "string" ? raw.prompt.trim().slice(0, 800) : "";
	if (prompt.length < 2) throw new Error("কী আঁকতে হবে লিখুন।");
	const image = typeof raw.imageDataUrl === "string" ? raw.imageDataUrl : void 0;
	if (image && (image.length > 26e5 || !IMAGE_RE.test(image))) throw new Error("ছবির ফরম্যাট গ্রহণযোগ্য নয়।");
	return {
		prompt,
		imageDataUrl: image
	};
}
var drawLv99_createServerFn_handler = createServerRpc({
	id: "2d337cd494cf387ead0644dfca9fbf25e0c950fee0ff724cc64bf4313901c2e3",
	name: "drawLv99",
	filename: "src/lib/lv99-api.ts"
}, (opts) => drawLv99.__executeServer(opts));
var drawLv99 = createServerFn({ method: "POST" }).validator(parseDraw).handler(drawLv99_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "unavailable"
	};
	if (!allow(`draw:${await clientKey()}`, 3)) return {
		ok: false,
		error: "rate"
	};
	const payload = data.imageDataUrl ? {
		model: "grok-imagine-image",
		prompt: data.prompt,
		image: {
			url: data.imageDataUrl,
			type: "image_url"
		},
		response_format: "url",
		n: 1
	} : {
		model: "grok-imagine-image",
		prompt: data.prompt,
		response_format: "url",
		resolution: "1k",
		n: 1
	};
	try {
		const res = await fetch(data.imageDataUrl ? "https://api.x.ai/v1/images/edits" : "https://api.x.ai/v1/images/generations", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify(payload)
		});
		const raw = await res.text();
		if (!res.ok) {
			console.error("LV99 image failed", res.status);
			return classify(res.status, raw);
		}
		const url = extractImageUrl(JSON.parse(raw));
		if (!url) return {
			ok: false,
			error: "failed"
		};
		return {
			ok: true,
			url
		};
	} catch (err) {
		console.error("LV99 image error", err instanceof Error ? err.name : "unknown");
		return {
			ok: false,
			error: "failed"
		};
	}
});
//#endregion
export { askLv99_createServerFn_handler, drawLv99_createServerFn_handler, lv99Status_createServerFn_handler };
