import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as usePlanner, k as cn } from "./router-CQnHyG8o.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/primitives-DM2UCvsE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fieldClass = "h-11 w-full min-w-0 rounded-lg border border-line bg-card px-3 text-base text-ink outline-none placeholder:text-muted focus-visible:border-accent";
var areaClass = "min-h-28 w-full min-w-0 resize-none rounded-lg border border-line bg-card px-3 py-3 text-base leading-normal text-ink outline-none placeholder:text-muted focus-visible:border-accent";
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-3xl border border-line bg-card p-4", className),
		children
	});
}
function SectionMark({ section }) {
	const color = usePlanner((s) => section ? s.theme.tabs[section] : s.theme.accent);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "mb-3 block h-1 w-8 rounded-full",
		style: { background: color }
	});
}
function PageHeader({ section, title, lede, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-6 flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionMark, { section }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-medium tracking-tight text-balance text-ink",
					children: title
				}),
				lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-prose text-pretty text-base text-muted",
					children: lede
				}) : null
			]
		}), action]
	});
}
function CardTitle({ children, aside }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex items-baseline justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-base font-medium text-ink",
			children
		}), aside]
	});
}
function AddRow({ placeholder, label = "Add", onAdd }) {
	const [text, setText] = (0, import_react.useState)("");
	function submit(event) {
		event.preventDefault();
		const next = text.trim();
		if (!next) return;
		onAdd(next);
		setText("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-3 flex gap-2",
		onSubmit: submit,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: text,
			onChange: (event) => setText(event.target.value),
			placeholder,
			"aria-label": placeholder,
			autoComplete: "off",
			className: fieldClass
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "submit",
			className: "h-11 shrink-0 rounded-full bg-blush px-4 text-sm font-medium text-ink hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
			children: label
		})]
	});
}
function IconButton({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "grid size-11 place-items-center rounded-full text-ink hover:bg-blush focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
		children
	});
}
function Segmented({ value, options, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "group",
		"aria-label": label,
		className: "grid grid-flow-col gap-1 rounded-full bg-paper p-1",
		children: options.map((option) => {
			const on = option.value === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": on,
				onClick: () => onChange(option.value),
				className: cn("h-11 rounded-full px-3 text-sm font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", on ? "bg-card text-ink shadow-soft" : "text-muted"),
				children: option.label
			}, option.value);
		})
	});
}
function EmptyCopy({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl font-medium text-balance text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-pretty text-base text-muted",
			children: body
		})]
	});
}
function ColorDot({ value, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type: "color",
		"aria-label": label,
		value,
		onChange: (event) => onChange(event.target.value),
		className: "color-dot"
	});
}
//#endregion
export { EmptyCopy as a, SectionMark as c, fieldClass as d, ColorDot as i, Segmented as l, Card as n, IconButton as o, CardTitle as r, PageHeader as s, AddRow as t, areaClass as u };
