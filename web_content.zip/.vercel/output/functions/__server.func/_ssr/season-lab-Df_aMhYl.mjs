import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useVespera } from "./router-D7Hr81ml.mjs";
import { c as formatLat, h as seasonStats, m as monthName, s as formatHours } from "./astro-2CYvScwN.mjs";
import { t as drawMoonDisk } from "./moon-draw-cL1uJINO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/season-lab-Df_aMhYl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function phaseName(elong) {
	const e = (elong % 360 + 360) % 360;
	if (e < 22 || e > 338) return "New moon";
	if (e < 68) return "Waxing crescent";
	if (e < 112) return "First quarter";
	if (e < 158) return "Waxing gibbous";
	if (e < 202) return "Full moon";
	if (e < 248) return "Waning gibbous";
	if (e < 292) return "Last quarter";
	return "Waning crescent";
}
function whenToLook(elong) {
	const e = (elong % 360 + 360) % 360;
	if (e < 22 || e > 338) return "Up in the daytime, next to the Sun. You will not see it.";
	if (e < 68) return "West, shortly after sunset. Sets early.";
	if (e < 112) return "High at sunset, gone by midnight.";
	if (e < 158) return "Rises in the afternoon. Most of the night is lit.";
	if (e < 202) return "Rises at sunset, opposite the Sun. Up all night.";
	if (e < 248) return "Rises after sunset and is still up at dawn.";
	if (e < 292) return "Rises around midnight. High at dawn.";
	return "East, in the hour before sunrise.";
}
function MoonLab() {
	const lat = useVespera((s) => s.lat);
	const [elong, setElong] = (0, import_react.useState)(90);
	const orbitRef = (0, import_react.useRef)(null);
	const diskRef = (0, import_react.useRef)(null);
	const dragging = (0, import_react.useRef)(false);
	const fraction = (1 - Math.cos(elong * Math.PI / 180)) / 2;
	const southern = lat < 0;
	(0, import_react.useEffect)(() => {
		const canvas = diskRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const size = 160;
		canvas.width = size * dpr;
		canvas.height = size * dpr;
		canvas.style.width = `${size}px`;
		canvas.style.height = `${size}px`;
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.clearRect(0, 0, size, size);
		drawMoonDisk(ctx, size / 2, size / 2, 70, elong, southern);
	}, [elong, southern]);
	function setFromPointer(clientX, clientY) {
		const el = orbitRef.current;
		if (!el) return;
		const r = el.getBoundingClientRect();
		const dx = clientX - (r.left + r.width / 2);
		const dy = clientY - (r.top + r.height / 2);
		let deg = Math.atan2(-dy, dx) * 180 / Math.PI;
		if (deg < 0) deg += 360;
		setElong(deg);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "text-xs uppercase tracking-widest text-gold",
			children: "Drag the Moon around Earth"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid items-center gap-6 md:grid-cols-[minmax(0,280px)_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: orbitRef,
				className: "relative mx-auto aspect-square w-full max-w-[280px] touch-none select-none",
				onPointerDown: (e) => {
					dragging.current = true;
					e.currentTarget.setPointerCapture(e.pointerId);
					setFromPointer(e.clientX, e.clientY);
				},
				onPointerMove: (e) => {
					if (!dragging.current) return;
					setFromPointer(e.clientX, e.clientY);
				},
				onPointerUp: () => {
					dragging.current = false;
				},
				role: "slider",
				"aria-valuemin": 0,
				"aria-valuemax": 360,
				"aria-valuenow": Math.round(elong),
				"aria-label": "Moon position around Earth",
				tabIndex: 0,
				onKeyDown: (e) => {
					if (e.key === "ArrowRight" || e.key === "ArrowUp") setElong((v) => (v + 8) % 360);
					if (e.key === "ArrowLeft" || e.key === "ArrowDown") setElong((v) => (v + 352) % 360);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 200",
					className: "h-full w-full",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "78",
							fill: "none",
							stroke: "#2c3a48"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							stroke: "#e2b15a",
							strokeOpacity: "0.7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "168",
									y1: "100",
									x2: "196",
									y2: "100"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "188",
									y1: "94",
									x2: "196",
									y2: "100"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "188",
									y1: "106",
									x2: "196",
									y2: "100"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: "188",
							y: "88",
							fill: "#e2b15a",
							fontSize: "10",
							children: "Sun"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "10",
							fill: "#3d6b8a"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: "100",
							y: "128",
							textAnchor: "middle",
							fill: "#7d8b9c",
							fontSize: "10",
							children: "Earth"
						}),
						(() => {
							const a = elong * Math.PI / 180;
							const mx = 100 + Math.cos(a) * 78;
							const my = 100 - Math.sin(a) * 78;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: mx,
								cy: my,
								r: "7",
								fill: "#f4ead2"
							});
						})()
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl text-fg",
					children: phaseName(elong)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted tabular-nums",
					children: [Math.round(fraction * 100), "% of the disk lit"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-fg",
					children: whenToLook(elong)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-faint",
					children: southern ? "Southern latitude is set, so the bright side is mirrored — waxing moons are lit on the left." : "Northern view: a waxing moon is bright on the right. Set a southern latitude and this flips."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex items-center gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: diskRef,
						className: "shrink-0"
					})
				})
			] })]
		})]
	});
}
function PolarisLab() {
	const lat = useVespera((s) => s.lat);
	const setLat = useVespera((s) => s.setLat);
	const north = lat >= 0;
	const alt = Math.abs(lat);
	const y = 118 - alt / 90 * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "text-xs uppercase tracking-widest text-gold",
			children: "Latitude, measured in the sky"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-5 sm:grid-cols-[180px_1fr] sm:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 200 150",
				className: "w-full",
				role: "img",
				"aria-label": "Horizon diagram",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M20 118 A80 80 0 0 1 180 118",
						fill: "#10161d",
						stroke: "#2c3a48"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "16",
						y1: "118",
						x2: "184",
						y2: "118",
						stroke: "#efe7d6",
						strokeOpacity: "0.45"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "100",
						y: "140",
						textAnchor: "middle",
						fill: "#7d8b9c",
						fontSize: "11",
						children: "horizon"
					}),
					north ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: y,
						r: "4",
						fill: "#e2b15a"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "112",
						y: y + 4,
						fill: "#efe7d6",
						fontSize: "11",
						children: "Polaris"
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: y,
						r: "3",
						fill: "#7d8b9c"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "108",
						y: y - 6,
						fill: "#a7b0bd",
						fontSize: "11",
						children: "south pole"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
						x: "100",
						y: "18",
						textAnchor: "middle",
						fill: "#e2b15a",
						fontSize: "12",
						children: [alt.toFixed(0), "°"]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl text-fg",
					children: north ? `Polaris is ${alt.toFixed(0)}° up` : `Pole is ${alt.toFixed(0)}° up, with no bright star`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: north ? "That angle is your latitude. Slide until it matches the pole star outside — or pick the parallel you actually live on." : "South of the equator the north star is below the ground. The south celestial pole stands this high, but Sigma Octantis is too faint to steer by. Use the Southern Cross."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-baseline justify-between",
						children: ["Latitude", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-base text-fg tabular-nums",
							children: formatLat(lat)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-2 w-full",
						type: "range",
						min: -60,
						max: 70,
						step: 1,
						value: lat,
						onChange: (e) => setLat(Number(e.target.value))
					})]
				})
			] })]
		})]
	});
}
var MONTH_START = [
	1,
	32,
	60,
	91,
	121,
	152,
	182,
	213,
	244,
	274,
	305,
	335
];
function monthOf(day) {
	let idx = 0;
	for (let i = 0; i < 12; i++) if (day >= MONTH_START[i]) idx = i;
	return monthName(idx + 1);
}
function SeasonLab() {
	const lat = useVespera((s) => s.lat);
	const setLat = useVespera((s) => s.setLat);
	const [day, setDay] = (0, import_react.useState)(172);
	const stats = seasonStats(lat, day);
	const toward = lat >= 0 ? stats.dec > 2 : stats.dec < -2;
	const away = lat >= 0 ? stats.dec < -2 : stats.dec > 2;
	const lean = stats.dec;
	let verdict = "Near an equinox. Day and night are close, everywhere.";
	if (stats.dayHours > 23) verdict = "The Sun doesn't set. Midnight sun — you are inside the polar day.";
	else if (stats.dayHours < 1) verdict = "The Sun doesn't rise. Polar night.";
	else if (toward) verdict = "Your hemisphere leans toward the Sun. Longer days, a high noon, summer weather.";
	else if (away) verdict = "Your hemisphere leans away. Short days, a low noon Sun, winter weather.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "text-xs uppercase tracking-widest text-gold",
			children: "One tilt, two seasons"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid items-center gap-6 md:grid-cols-[220px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 220 160",
				className: "w-full",
				role: "img",
				"aria-label": "Earth tilt relative to the Sun",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						stroke: "#e2b15a",
						strokeOpacity: "0.55",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "8",
								y1: "80",
								x2: "48",
								y2: "80"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "8",
								y1: "68",
								x2: "36",
								y2: "68"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "8",
								y1: "92",
								x2: "36",
								y2: "92"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "8",
						y: "28",
						fill: "#e2b15a",
						fontSize: "11",
						children: "Sun"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						transform: `rotate(${-lean} 130 80)`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "130",
								cy: "80",
								r: "36",
								fill: "#1a3a52",
								stroke: "#efe7d6",
								strokeOpacity: "0.4"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "130",
								y1: "28",
								x2: "130",
								y2: "132",
								stroke: "#e2b15a"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "130",
								cy: "36",
								r: "3",
								fill: "#e2b15a"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x: "138",
								y: "32",
								fill: "#efe7d6",
								fontSize: "11",
								children: "N"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x: "138",
								y: "136",
								fill: "#a7b0bd",
								fontSize: "11",
								children: "S"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "96",
								y1: "80",
								x2: "164",
								y2: "80",
								stroke: "#7d8b9c",
								strokeDasharray: "3 3"
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-3xl text-fg",
					children: [
						monthOf(day),
						" · day ",
						day
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-fg",
					children: verdict
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 grid grid-cols-3 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-faint",
							children: "Noon sun"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "mt-1 font-display text-2xl tabular-nums text-fg",
							children: [stats.noonAlt.toFixed(0), "°"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-faint",
							children: "Daylight"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-display text-2xl tabular-nums text-fg",
							children: formatHours(stats.dayHours)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-faint",
							children: "Sun declination"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "mt-1 font-display text-2xl tabular-nums text-fg",
							children: [
								stats.dec >= 0 ? "+" : "−",
								Math.abs(stats.dec).toFixed(0),
								"°"
							]
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex justify-between",
						children: ["Day of the year ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: monthOf(day)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-2 w-full",
						type: "range",
						min: 1,
						max: 365,
						value: day,
						onChange: (e) => setDay(Number(e.target.value))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex justify-between",
						children: ["Your latitude ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg tabular-nums",
							children: formatLat(lat)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-2 w-full",
						type: "range",
						min: -60,
						max: 70,
						value: lat,
						onChange: (e) => setLat(Number(e.target.value))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-faint",
					children: "Schematic, not to scale. The axis keeps pointing the same way in space — only our place in the orbit changes."
				})
			] })]
		})]
	});
}
//#endregion
export { PolarisLab as n, SeasonLab as r, MoonLab as t };
