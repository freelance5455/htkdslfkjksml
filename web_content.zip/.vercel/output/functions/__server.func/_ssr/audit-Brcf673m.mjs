import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { p as useAudit } from "./use-books-BtZpLk9U.mjs";
import { i as PageHeader, t as Badge } from "./card-Bb_-PO54.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-Brcf673m.js
var import_jsx_runtime = require_jsx_runtime();
function AuditPage() {
	const { data = [] } = useAudit();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "ردپای حسابرسی",
		description: "چه کسی، چه چیزی، چه زمانی، چه مبلغی، قبل و بعد از تغییر، روی کدام سند و کدام روز."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-[24px] border border-line bg-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[720px] text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-xs text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "زمان"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "عمل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "موجودیت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "شناسه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "دلیل"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: data.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-line align-top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3 text-xs",
						children: r.occurred_at.slice(0, 19).replace("T", " ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: r.action })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: r.entity
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3 text-xs",
						children: r.entity_id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "px-4 py-3 text-xs",
						children: [
							r.reason,
							r.old_value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-muted",
								children: ["قبل: ", r.old_value.slice(0, 80)]
							}) : null,
							r.new_value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted",
								children: ["بعد: ", r.new_value.slice(0, 80)]
							}) : null
						]
					})
				]
			}, r.id)) })]
		})
	})] });
}
//#endregion
export { AuditPage as component };
