import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BackButton } from "./back-button-DImimZOp.mjs";
import { n as RECITERS, r as TopBar, t as AppShell, u as useAppStore } from "./app-shell-C4IrQdCN.mjs";
import { u as quranMeta } from "./catalog-CjAfWU9w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-DgVZRhLm.js
var import_jsx_runtime = require_jsx_runtime();
function MorePage() {
	const settings = useAppStore((s) => s.settings);
	const setTheme = useAppStore((s) => s.setTheme);
	const setLarge = useAppStore((s) => s.setLargeDisplay);
	const setReciter = useAppStore((s) => s.setReciter);
	const setFont = useAppStore((s) => s.setFontScale);
	const setQuran = useAppStore((s) => s.setQuranScale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "المزيد",
		back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: "العرض الكبير",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs leading-5 text-muted-foreground",
					children: "خط أكبر، أزرار أوضح، ومساحات أوسع لتسهيل القراءة والاستماع لكبار السن."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					checked: settings.largeDisplay,
					onChange: setLarge,
					label: "تفعيل العرض الكبير"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "المظهر",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						["light", "فاتح"],
						["dark", "ليلي"],
						["system", "تلقائي"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTheme(id),
						className: `h-11 rounded-xl text-sm ${settings.theme === id ? "bg-accent text-accent-foreground" : "bg-surface"}`,
						children: label
					}, id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: "حجم الخط",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-xs text-muted-foreground",
						children: "المصحف"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: .9,
						max: 1.8,
						step: .05,
						value: settings.quranScale,
						onChange: (e) => setQuran(Number(e.target.value)),
						className: "mt-1 w-full"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-xs text-muted-foreground",
						children: "المتون والأذكار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: .85,
						max: 1.6,
						step: .05,
						value: settings.fontScale,
						onChange: (e) => setFont(Number(e.target.value)),
						className: "mt-1 w-full"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "القارئ",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-11 w-full rounded-xl border border-border bg-background px-3 text-sm",
					value: settings.reciterId,
					onChange: (e) => setReciter(e.target.value),
					children: RECITERS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: r.id,
						children: r.name
					}, r.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: "أقسام",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/listen",
					className: "block py-2 text-sm",
					children: "الاستماع والتنزيل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/search",
					className: "block py-2 text-sm",
					children: "البحث الموحد"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "المصادر",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-3 text-xs leading-6 text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: quranMeta.source.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							quranMeta.source.publisher,
							". ",
							quranMeta.source.note
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "التفسير الميسر، إعداد مجمع الملك فهد لطباعة المصحف الشريف." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "حصن المسلم من أذكار الكتاب والسنة، لسعيد بن علي بن وهف القحطاني (نسخة مقابلة على المطبوع)." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الأربعون النووية، عن رواية معتمدة عبر sunnah.com." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الأصول الثلاثة، القواعد الأربع، كتاب التوحيد، وتحفة الأطفال: من ويكي مصدر اعتمادًا على المطبوع." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "التلاوة من تسجيلات مشاري العفاسي والحصري والسديس والمنشاوي عبر مصادر علنية للتلاوة." })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 pb-4 text-center text-[11px] text-muted-foreground",
				children: "رفيق تطبيق يومي للقراءة والاستماع. لا شبكة اجتماعية، ولا اشتراك على النصوص الشرعية."
			})
		]
	})] });
}
function Card({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-sm font-semibold",
			children: title
		}), children]
	});
}
function Toggle({ checked, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "switch",
		"aria-checked": checked,
		"aria-label": label,
		onClick: () => onChange(!checked),
		className: `relative h-8 w-14 rounded-full ${checked ? "bg-accent" : "bg-surface-2"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-1 size-6 rounded-full bg-paper transition-transform duration-[var(--motion-fast)] ${checked ? "start-7" : "start-1"}` })
	});
}
//#endregion
export { MorePage as component };
