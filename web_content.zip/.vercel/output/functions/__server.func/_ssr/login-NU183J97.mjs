import { S as require_jsx_runtime, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useCurrentUserState, r as Splash, t as AuthPanel } from "./nyala-gate-DLLoNCea.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-NU183J97.js
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, { label: "Menyalakan panggung…" });
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-ink px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-center font-display text-4xl",
			children: "NYALA"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPanel, { next: "/" })] })
	});
}
//#endregion
export { Login as component };
