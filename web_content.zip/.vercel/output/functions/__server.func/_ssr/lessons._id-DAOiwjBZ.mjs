import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useVespera, n as Route } from "./router-D7Hr81ml.mjs";
import { n as PolarisLab, r as SeasonLab, t as MoonLab } from "./season-lab-Df_aMhYl.mjs";
import { n as lessonById, t as LESSONS } from "./lessons-DkJWLy0d.mjs";
import { n as btnGhost, t as Choice } from "./ui-B4w5JSuo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lessons._id-DAOiwjBZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	{
		mag: "−1.5",
		label: "Sirius",
		size: "size-5"
	},
	{
		mag: "0",
		label: "Vega",
		size: "size-4"
	},
	{
		mag: "1",
		label: "Spica",
		size: "size-3.5"
	},
	{
		mag: "2",
		label: "Polaris",
		size: "size-2.5"
	},
	{
		mag: "3",
		label: "Megrez's neighbors",
		size: "size-2"
	},
	{
		mag: "4",
		label: "City limit",
		size: "size-1.5"
	}
];
function MagnitudeLab() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-2xl border border-line bg-surface px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "text-xs uppercase tracking-widest text-gold",
				children: "Brightness, not size"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Smaller magnitude, more light. Dots here are only a guide — stars are points, and the scale is logarithmic."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-5 grid grid-cols-3 gap-4 sm:grid-cols-6",
				children: STEPS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-col items-center gap-2 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `block rounded-full bg-fg ${s.size}` }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg tabular-nums text-fg",
							children: s.mag
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-faint",
							children: s.label
						})
					]
				}, s.mag))
			})
		]
	});
}
function LessonPage() {
	const { id } = Route.useParams();
	const lesson = lessonById(id);
	const done = useVespera((s) => s.done);
	const mark = useVespera((s) => s.markLesson);
	const [picked, setPicked] = (0, import_react.useState)(null);
	if (!lesson) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "text-4xl text-fg",
		children: "That lesson isn't on the path."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: `${btnGhost} mt-6`,
		children: "Back to the path"
	})] });
	const index = LESSONS.findIndex((l) => l.id === lesson.id);
	const prev = LESSONS[index - 1];
	const next = LESSONS[index + 1];
	const complete = done.includes(lesson.id);
	const right = picked === lesson.check.answer;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-gold",
				children: lesson.kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-4xl text-fg md:text-5xl",
				children: lesson.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-lg text-muted",
				children: lesson.lede
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs uppercase tracking-widest text-faint",
				children: [lesson.minutes, " min"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-8",
				children: lesson.sections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl text-fg",
					children: section.heading
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-3",
					children: section.paragraphs.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base leading-relaxed text-muted",
						children: p
					}, p))
				})] }, section.heading))
			}),
			lesson.lab && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [
					lesson.lab === "magnitude" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MagnitudeLab, {}),
					lesson.lab === "polaris" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarisLab, {}),
					lesson.lab === "moon" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoonLab, {}),
					lesson.lab === "seasons" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonLab, {})
				]
			}),
			lesson.skyCon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sky",
					search: { con: lesson.skyCon },
					className: "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-transparent px-5 text-sm font-medium text-fg transition-colors duration-200 hover:border-gold hover:text-gold",
					children: "See it on the chart"
				})
			}),
			lesson.id === "worlds" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sky",
					search: {},
					className: "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-transparent px-5 text-sm font-medium text-fg transition-colors duration-200 hover:border-gold hover:text-gold",
					children: "Find the planets on the chart"
				})
			}),
			lesson.id === "seasons" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: [
					"The distance lie has its own instrument.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/labs",
						hash: "scale",
						className: "text-gold",
						children: "Open the scale lab"
					}),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 border-t border-line pt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl text-fg",
						children: "Check"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-lg text-fg",
						children: lesson.check.prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid gap-3",
						children: lesson.check.options.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							selected: picked === i,
							locked: picked != null,
							correct: picked != null && i === lesson.check.answer,
							wrong: picked === i && i !== lesson.check.answer,
							onClick: () => {
								if (picked == null) setPicked(i);
							},
							children: opt
						}, opt))
					}),
					picked != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-fg",
							children: lesson.check.why
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-3",
							children: [
								!right && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-transparent px-5 text-sm font-medium text-fg transition-colors duration-200 hover:border-gold hover:text-gold",
									onClick: () => setPicked(null),
									children: "Try again"
								}),
								right && !complete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex h-11 items-center justify-center gap-2 rounded-full bg-gold px-5 text-sm font-medium text-ink transition-colors duration-200 hover:bg-gold-2",
									onClick: () => mark(lesson.id),
									children: "Mark complete"
								}),
								(complete || right) && next && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/lessons/$id",
									params: { id: next.id },
									className: complete || right ? "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-transparent px-5 text-sm font-medium text-fg transition-colors duration-200 hover:border-gold hover:text-gold" : "inline-flex h-11 items-center justify-center gap-2 rounded-full bg-gold px-5 text-sm font-medium text-ink transition-colors duration-200 hover:bg-gold-2",
									children: "Next lesson"
								})
							]
						})]
					}),
					complete && picked == null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-gold",
						children: "Marked complete."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex justify-between gap-3 text-sm",
				children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/lessons/$id",
					params: { id: prev.id },
					className: "text-muted hover:text-fg",
					children: prev.title
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/lessons/$id",
					params: { id: next.id },
					className: "text-muted hover:text-fg",
					children: next.title
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/quiz",
					className: "text-gold",
					children: "Take the quiz"
				})]
			})
		]
	});
}
//#endregion
export { LessonPage as component };
