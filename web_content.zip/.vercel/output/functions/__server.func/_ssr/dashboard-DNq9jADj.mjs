import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as useDashboard } from "./use-books-BtZpLk9U.mjs";
import { c as formatJalaliLong, s as formatJalali, u as formatRialCompact } from "./format-c9GA3s0l.mjs";
import { a as SkeletonGrid, i as PageHeader, n as Card, o as StatCard, r as Money } from "./card-Bb_-PO54.mjs";
import { i as Area, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DNq9jADj.js
var import_jsx_runtime = require_jsx_runtime();
function DashboardPage() {
	const { data, isLoading } = useDashboard();
	if (isLoading || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonGrid, { n: 10 });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Overview",
			title: "داشبورد مدیریتی",
			description: `${formatJalaliLong(data.today)} · سال مالی ${data.fiscalYear} · روز ${data.todayStatus === "closed" ? "بسته" : "باز"}`,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/operations/new",
				className: "inline-flex h-11 items-center rounded-[10px] bg-navy px-4 text-sm text-cream",
				children: "ثبت عملیات امروز"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					gold: true,
					label: "موجودی نقد",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.liquid,
						compact: true
					}),
					hint: "صندوق + بانک + تنخواه"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "بانک",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.bank,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "صندوق",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.cash,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "مطالبات",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.ar,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "بدهی‌ها",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.ap,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "فروش امروز",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.salesToday,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "دریافت امروز",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.receiptsToday,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "پرداخت امروز",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.paymentsToday,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "هزینه امروز",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.expenseToday,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "سود تقریبی دوره",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.net,
						compact: true
					}),
					hint: "درآمد − بهای تمام‌شده − هزینه"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4 text-sm font-medium text-navy",
					children: "روند ۱۴ روز اخیر"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-56",
					dir: "ltr",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: data.series,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
									id: "s",
									x1: "0",
									y1: "0",
									x2: "0",
									y2: "1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "0%",
										stopColor: "#071428",
										stopOpacity: .35
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "100%",
										stopColor: "#071428",
										stopOpacity: .02
									})]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "date",
									tickFormatter: (v) => formatJalali(String(v)).slice(-5),
									tick: { fontSize: 10 }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									formatter: (v) => formatRialCompact(Number(v)),
									labelFormatter: (v) => formatJalali(String(v))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									type: "monotone",
									dataKey: "sales",
									name: "فروش",
									stroke: "#071428",
									fill: "url(#s)",
									strokeWidth: 1.6
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									type: "monotone",
									dataKey: "receipts",
									name: "دریافت",
									stroke: "#C9A227",
									fill: "transparent",
									strokeWidth: 1.6
								})
							]
						})
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-medium text-navy",
					children: "بزرگ‌ترین بدهکاران"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: data.topDebtors.length ? data.topDebtors.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
							value: d.amount,
							compact: true,
							className: "text-navy"
						})]
					}, d.name)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-xs text-muted",
						children: "مانده‌ای نیست."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 text-sm font-medium text-navy",
					children: "بزرگ‌ترین بستانکاران"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: data.topCreditors.length ? data.topCreditors.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
							value: d.amount,
							compact: true
						})]
					}, d.name)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-xs text-muted",
						children: "مانده‌ای نیست."
					})
				})
			] })]
		})
	] });
}
//#endregion
export { DashboardPage as component };
