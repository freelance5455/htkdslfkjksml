import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, _ as createFileRoute, b as require_jsx_runtime, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as object, i as number, n as array, o as string, r as literal, s as union, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-dQtX0wis.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-D82FAJz3.css";
var APP_NAME = "Charlie";
var Route$4 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Charlie is a best friend who looks things up — a personal assistant with the live web."
			},
			{
				name: "theme-color",
				content: "#0c0d10"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Outfit:wght@400;500;600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-B7pihAU9.mjs");
var Route$3 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var buckets = /* @__PURE__ */ new Map();
function allow(bucket, limit, windowMs) {
	const now = Date.now();
	const fresh = (buckets.get(bucket) ?? []).filter((t) => t > now - windowMs);
	if (fresh.length >= limit) {
		buckets.set(bucket, fresh);
		return false;
	}
	fresh.push(now);
	buckets.set(bucket, fresh);
	return true;
}
function charlieInstructions(profile) {
	const name = profile.name.trim() || "they have not said yet";
	const notes = profile.notes.trim() || "nothing saved yet";
	return [
		"You are Charlie, a close friend and personal assistant. You talk like a sharp, warm person: brief, specific, and honest.",
		"You are not a help desk. Never open with Certainly, Absolutely, or As an AI. Do not narrate your process.",
		"You can search the live web. Use it when a fact could have changed — news, weather, prices, scores, releases, people, places, anything dated.",
		"For feelings, plans, jokes, greetings, and opinions, just talk. A hello is not a search. Do not search merely to sound busy.",
		"When you use a source, name it in a normal sentence. Do not invent citations.",
		"You live in this chat. You cannot see their home, screen, or accounts, and you cannot control devices.",
		"If you do not know, say so. Match their length. No emoji unless they use them first.",
		"Ask a follow-up when it would actually help, not as a reflex.",
		`What to call them: ${name}.`,
		`What they asked you to remember: ${notes}.`
	].join("\n");
}
var bodySchema$1 = object({
	conversationId: string().trim().min(1).max(80),
	profile: object({
		name: string().max(80).optional(),
		notes: string().max(1200).optional()
	}),
	messages: array(object({
		role: _enum(["user", "assistant"]),
		content: string().trim().min(1).max(4e3)
	})).min(1).max(16)
});
function sse(event, data) {
	return `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
}
function hostLabel(url, title) {
	if (title && !/^\d+$/.test(title.trim()) && title.trim().length > 1 && title.trim().length < 80) return title.trim();
	try {
		return new URL(url).hostname.replace(/^www\./, "");
	} catch {
		return "Source";
	}
}
function pushCitation(into, url, title) {
	if (typeof url !== "string" || !/^https?:\/\//i.test(url)) return;
	const label = hostLabel(url, typeof title === "string" ? title : void 0);
	if (!into.has(url)) into.set(url, label);
}
function collectCitations(node, into) {
	if (!node || typeof node !== "object") return;
	const record = node;
	if (record.type === "url_citation") pushCitation(into, record.url, record.title);
	if (record.type === "web_search_call") {
		const action = record.action;
		if (action && typeof action === "object") {
			const sources = action.sources;
			if (Array.isArray(sources)) {
				for (const source of sources) if (source && typeof source === "object") {
					const item = source;
					pushCitation(into, item.url, item.title);
				}
			}
		}
	}
	if (Array.isArray(record.annotations)) for (const ann of record.annotations) collectCitations(ann, into);
	if (Array.isArray(record.content)) for (const part of record.content) collectCitations(part, into);
	if (Array.isArray(record.output)) for (const item of record.output) collectCitations(item, into);
}
function citationsOf(map) {
	return [...map.entries()].slice(0, 6).map(([url, label]) => ({
		url,
		label
	}));
}
var Route$2 = createFileRoute("/api/chat")({ server: { handlers: { POST: async ({ request }) => {
	if (!allow("chat", 16, 6e4)) return Response.json({
		ok: false,
		error: "Charlie needs a short breather. Try again in a minute."
	}, { status: 429 });
	let json;
	try {
		json = await request.json();
	} catch {
		return Response.json({
			ok: false,
			error: "That message didn't come through."
		}, { status: 400 });
	}
	const parsed = bodySchema$1.safeParse(json);
	if (!parsed.success) return Response.json({
		ok: false,
		error: "Keep it a little shorter and try again."
	}, { status: 400 });
	if (parsed.data.messages[parsed.data.messages.length - 1].role !== "user") return Response.json({
		ok: false,
		error: "Say something and Charlie will answer."
	}, { status: 400 });
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return Response.json({
		ok: false,
		error: "Charlie can't think in this environment yet."
	}, { status: 503 });
	const history = parsed.data.messages.slice(-12).map((message) => ({
		role: message.role,
		content: message.content
	}));
	let upstream;
	try {
		upstream = await fetch("https://api.x.ai/v1/responses", {
			method: "POST",
			signal: request.signal,
			headers: {
				Authorization: `Bearer ${apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				model: "grok-4.5",
				store: false,
				stream: true,
				temperature: .8,
				max_output_tokens: 700,
				max_tool_calls: 2,
				reasoning: { effort: "low" },
				prompt_cache_key: parsed.data.conversationId,
				instructions: charlieInstructions({
					name: parsed.data.profile.name ?? "",
					notes: parsed.data.profile.notes ?? ""
				}),
				tools: [{ type: "web_search" }, { type: "x_search" }],
				input: history
			})
		});
	} catch (error) {
		if (error instanceof DOMException && error.name === "AbortError") return new Response(null, { status: 499 });
		return Response.json({
			ok: false,
			error: "Charlie couldn't reach the web just now."
		}, { status: 502 });
	}
	if (!upstream.ok || !upstream.body) return Response.json({
		ok: false,
		error: "Charlie stumbled. Try that once more."
	}, { status: 502 });
	const encoder = new TextEncoder();
	const decoder = new TextDecoder();
	const citations = /* @__PURE__ */ new Map();
	let full = "";
	const stream = new ReadableStream({ async start(controller) {
		const send = (event, data) => {
			try {
				controller.enqueue(encoder.encode(sse(event, data)));
			} catch {}
		};
		send("status", { phase: "thinking" });
		const reader = upstream.body.getReader();
		let buffer = "";
		try {
			while (true) {
				const { done, value } = await reader.read();
				if (done) break;
				buffer += decoder.decode(value, { stream: true });
				const blocks = buffer.split(/\r?\n\r?\n/);
				buffer = blocks.pop() ?? "";
				for (const block of blocks) {
					const dataLines = block.split(/\r?\n/).filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trim());
					if (!dataLines.length || dataLines[0] === "[DONE]") continue;
					let payload;
					try {
						payload = JSON.parse(dataLines.join("\n"));
					} catch {
						continue;
					}
					const type = typeof payload.type === "string" ? payload.type : "";
					if (type === "response.output_item.added") {
						const item = payload.item;
						if (item?.type === "web_search_call" || item?.type === "x_search_call") send("status", { phase: "searching" });
						collectCitations(item, citations);
					}
					if (type === "response.output_text.delta" && typeof payload.delta === "string") {
						full += payload.delta;
						send("delta", { text: payload.delta });
					}
					if (type === "response.output_text.done" || type === "response.completed") {
						collectCitations(payload, citations);
						const response = payload.response;
						if (response) collectCitations(response, citations);
					}
					if (type === "response.failed" || type === "error") send("error", { message: "Charlie couldn't finish that. Try again." });
				}
			}
		} catch (error) {
			if (!(error instanceof DOMException && error.name === "AbortError")) send("error", { message: "The line dropped. Charlie kept what was already said." });
		} finally {
			send("done", {
				text: full,
				citations: citationsOf(citations)
			});
			controller.close();
		}
	} });
	return new Response(stream, { headers: {
		"Content-Type": "text/event-stream; charset=utf-8",
		"Cache-Control": "no-cache, no-transform",
		"X-Accel-Buffering": "no"
	} });
} } } });
var MAX_BYTES = 15e5;
var Route$1 = createFileRoute("/api/hear")({ server: { handlers: { POST: async ({ request }) => {
	if (!allow("hear", 8, 6e4)) return Response.json({
		ok: false,
		error: "Listening needs a short pause. Type this one."
	}, { status: 429 });
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return Response.json({
		ok: false,
		error: "Listening isn't available here."
	}, { status: 503 });
	let form;
	try {
		form = await request.formData();
	} catch {
		return Response.json({
			ok: false,
			error: "That recording didn't come through."
		}, { status: 400 });
	}
	const file = form.get("file");
	if (!(file instanceof File) || file.size === 0) return Response.json({
		ok: false,
		error: "Charlie didn't catch any audio."
	}, { status: 400 });
	if (file.size > MAX_BYTES) return Response.json({
		ok: false,
		error: "That was a bit long. Try a shorter note."
	}, { status: 400 });
	const outbound = new FormData();
	outbound.append("model", "grok-voice-transcribe-2.0");
	outbound.append("file", file, file.name || "speech.webm");
	const upstream = await fetch("https://api.x.ai/v1/stt", {
		method: "POST",
		headers: { Authorization: `Bearer ${apiKey}` },
		body: outbound
	});
	if (!upstream.ok) return Response.json({
		ok: false,
		error: "Charlie couldn't make out the words."
	}, { status: 502 });
	const payload = await upstream.json();
	const text = typeof payload.text === "string" ? payload.text.trim() : "";
	if (!text) return Response.json({
		ok: false,
		error: "Charlie heard silence. Try again."
	}, { status: 422 });
	return Response.json({
		ok: true,
		text: text.slice(0, 2e3)
	});
} } } });
var VOICES = /* @__PURE__ */ new Set([
	"eve",
	"leo",
	"ara",
	"orion"
]);
var bodySchema = object({
	text: string().trim().min(1).max(700),
	voiceId: string().trim().max(40)
});
function speakable(text) {
	return text.replace(/\[\[\d+\]\]\([^)]+\)/g, "").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/[*_`#>]/g, "").replace(/\s+/g, " ").trim().slice(0, 700);
}
var Route = createFileRoute("/api/speak")({ server: { handlers: { POST: async ({ request }) => {
	if (!allow("speak", 10, 6e4)) return Response.json({
		ok: false,
		error: "Voice needs a minute. Read this one, or try again shortly."
	}, { status: 429 });
	let json;
	try {
		json = await request.json();
	} catch {
		return Response.json({
			ok: false,
			error: "Nothing to say."
		}, { status: 400 });
	}
	const parsed = bodySchema.safeParse(json);
	if (!parsed.success) return Response.json({
		ok: false,
		error: "That was too long to speak."
	}, { status: 400 });
	const text = speakable(parsed.data.text);
	if (!text) return Response.json({
		ok: false,
		error: "Nothing to say."
	}, { status: 400 });
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return Response.json({
		ok: false,
		error: "Voice isn't available here."
	}, { status: 503 });
	const voiceId = VOICES.has(parsed.data.voiceId) ? parsed.data.voiceId : "leo";
	const upstream = await fetch("https://api.x.ai/v1/tts", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${apiKey}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			text,
			voice_id: voiceId,
			language: "en"
		})
	});
	if (!upstream.ok || !upstream.body) return Response.json({
		ok: false,
		error: "Charlie couldn't speak just now."
	}, { status: 502 });
	return new Response(upstream.body, { headers: {
		"Content-Type": upstream.headers.get("content-type") || "audio/mpeg",
		"Cache-Control": "no-store"
	} });
} } } });
var rootRouteChildren = {
	IndexRoute: Route$3.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$4
	}),
	ApiChatRoute: Route$2.update({
		id: "/api/chat",
		path: "/api/chat",
		getParentRoute: () => Route$4
	}),
	ApiHearRoute: Route$1.update({
		id: "/api/hear",
		path: "/api/hear",
		getParentRoute: () => Route$4
	}),
	ApiSpeakRoute: Route.update({
		id: "/api/speak",
		path: "/api/speak",
		getParentRoute: () => Route$4
	})
};
var routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { previewPathPrefix as n, router_exports as t };
