import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat.functions-DIjYusOV.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SYSTEM = `You are Bareline, a direct assistant. Answer the actual question first, in plain language, with useful detail and code when it helps. Skip lectures, filler, and moralizing preambles. Stay accurate. If a request is for criminal activity, weapons construction, or sexual content involving minors, refuse in one short sentence.`;
function clip(text, max) {
	const t = text.trim();
	return t.length > max ? t.slice(0, max) : t;
}
var sendChat_createServerFn_handler = createServerRpc({
	id: "1f52bca271952cad5ff37d96814219878833f65591cf5b6efeb8abd49a80b0d9",
	name: "sendChat",
	filename: "src/lib/chat.functions.ts"
}, (opts) => sendChat.__executeServer(opts));
var sendChat = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || !Array.isArray(input.messages) || input.messages.length === 0) throw new Error("Send a message first.");
	const messages = input.messages.filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string").slice(-16).map((m) => ({
		role: m.role,
		content: clip(m.content, 6e3)
	}));
	if (!messages.length || messages[messages.length - 1]?.role !== "user") throw new Error("The latest message must be from you.");
	return { messages };
}).handler(sendChat_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Chat is unavailable in this environment."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .7,
			max_tokens: 900,
			messages: [{
				role: "system",
				content: SYSTEM
			}, ...data.messages]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `The model didn't answer (${res.status}). Try again.`
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "Empty reply. Try again."
	};
	return {
		ok: true,
		text
	};
});
//#endregion
export { sendChat_createServerFn_handler };
