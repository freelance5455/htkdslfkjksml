import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as ChevronRight, c as ChevronFirst, i as FlipVertical2, n as SquarePen, o as ChevronLeft, r as RotateCcw, s as ChevronLast } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as DEFAULT_POSITION, t as Chess } from "../_libs/chess.js.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B8TXIBAF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function ChessPiece({ type, color, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 80 80",
		className: cn("piece-svg", color === "w" ? "piece-light" : "piece-dark", className),
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			strokeWidth: "1.6",
			strokeLinejoin: "round",
			children: [
				type === "p" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pawn, {}),
				type === "r" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rook, {}),
				type === "n" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knight, {}),
				type === "b" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bishop, {}),
				type === "q" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Queen, {}),
				type === "k" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(King, {})
			]
		})
	});
}
function Base() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
		x: "16",
		y: "64",
		width: "48",
		height: "7",
		rx: "2.5"
	});
}
function Pawn() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "40",
			cy: "26",
			r: "10"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M30 64c1.2-14 4-22 10-24 6 2 8.8 10 10 24z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Base, {})
	] });
}
function Rook() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20 28h8v6h6v-6h12v6h6v-6h8v10H20z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M24 38h32v26H24z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Base, {})
	] });
}
function Knight() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 66h40l-2-12c6-2 10-8 8-16-2-6-6-8-8-14l6-6-5-4-8 6c-2-4-8-6-14-4-10 3-16 12-14 22l-8 6c2 6 6 10 8 14z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			className: "piece-eye",
			cx: "46",
			cy: "28",
			r: "2.1"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Base, {})
	] });
}
function Bishop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M40 10l5 8H35z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "40",
			cy: "26",
			r: "9"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			className: "piece-line",
			d: "M40 20v10"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M28 64c1-16 4-24 12-28 8 4 11 12 12 28z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Base, {})
	] });
}
function Queen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "24",
			r: "3.3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "28",
			cy: "16",
			r: "3.3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "40",
			cy: "12",
			r: "3.3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "52",
			cy: "16",
			r: "3.3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "64",
			cy: "24",
			r: "3.3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 26c3 8 8 14 24 16 16-2 21-8 24-16-2 14-8 22-24 24C24 48 18 40 16 26z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M26 64c1-8 4-12 14-14 10 2 13 6 14 14z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Base, {})
	] });
}
function King() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			className: "piece-line",
			d: "M40 6v12M34 12h12"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M24 32h32l-3 8H27z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "22",
			cy: "30",
			r: "3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "40",
			cy: "26",
			r: "3.2"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "58",
			cy: "30",
			r: "3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M28 64c1-14 4-20 12-22 8 2 11 8 12 22z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Base, {})
	] });
}
var FILES = [
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h"
];
function Board({ fen, orientation, selected, targets, captures, last, check, hint, interactive, onSquare, onDrop }) {
	const boardRef = (0, import_react.useRef)(null);
	const dragRef = (0, import_react.useRef)(null);
	const [ghost, setGhost] = (0, import_react.useState)(null);
	const chess = new Chess(fen);
	const ranks = orientation === "w" ? [
		8,
		7,
		6,
		5,
		4,
		3,
		2,
		1
	] : [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	];
	const files = orientation === "w" ? FILES : [...FILES].reverse();
	const targetSet = new Set(targets);
	const captureSet = new Set(captures);
	function squareFromPoint(x, y) {
		const square = document.elementFromPoint(x, y)?.closest("[data-square]")?.getAttribute("data-square");
		return square ? square : null;
	}
	function center(square) {
		const file = square.charCodeAt(0) - 97;
		const rank = Number(square[1]) - 1;
		return {
			x: (orientation === "w" ? file : 7 - file) + .5,
			y: (orientation === "w" ? 7 - rank : rank) + .5
		};
	}
	const arrow = hint && hint.length >= 4 ? {
		from: hint.slice(0, 2),
		to: hint.slice(2, 4)
	} : null;
	const start = arrow ? center(arrow.from) : null;
	const end = arrow ? center(arrow.to) : null;
	const tip = start && end ? {
		x: start.x + (end.x - start.x) * .72,
		y: start.y + (end.y - start.y) * .72
	} : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: boardRef,
		className: "relative w-full touch-none select-none",
		style: { aspectRatio: "1" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-full w-full grid-cols-8 overflow-hidden rounded-xl",
				children: ranks.flatMap((rank) => files.map((file) => {
					const square = `${file}${rank}`;
					const piece = chess.get(square);
					const light = (file.charCodeAt(0) - 97 + rank) % 2 === 1;
					const hide = ghost?.from === square;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"data-square": square,
						"aria-label": piece ? `${square} ${piece.color === "w" ? "white" : "black"} ${piece.type}` : square,
						className: cn("sq", light ? "sq-light" : "sq-dark", interactive ? "cursor-pointer" : "cursor-default"),
						onPointerDown: (event) => {
							if (!interactive) return;
							onSquare(square);
							if (!piece || piece.color !== chess.turn()) return;
							const rect = boardRef.current?.getBoundingClientRect();
							const size = rect ? rect.width / 8 : 48;
							const next = {
								from: square,
								x: event.clientX,
								y: event.clientY,
								x0: event.clientX,
								y0: event.clientY,
								size,
								type: piece.type,
								color: piece.color,
								moved: false
							};
							dragRef.current = next;
							event.currentTarget.setPointerCapture(event.pointerId);
						},
						onPointerMove: (event) => {
							const drag = dragRef.current;
							if (!drag || drag.from !== square) return;
							const moved = Math.hypot(event.clientX - drag.x0, event.clientY - drag.y0) > 8;
							drag.x = event.clientX;
							drag.y = event.clientY;
							drag.moved = drag.moved || moved;
							if (drag.moved) setGhost({
								from: drag.from,
								x: drag.x,
								y: drag.y,
								size: drag.size,
								type: drag.type,
								color: drag.color
							});
						},
						onPointerUp: (event) => {
							const drag = dragRef.current;
							if (!drag || drag.from !== square) return;
							dragRef.current = null;
							setGhost(null);
							if (!drag.moved) return;
							const dest = squareFromPoint(event.clientX, event.clientY);
							if (dest && dest !== drag.from) onDrop(drag.from, dest);
						},
						onContextMenu: (event) => event.preventDefault(),
						children: [
							last && (last.from === square || last.to === square) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "sq-wash sq-wash-last" }),
							selected === square && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "sq-wash sq-wash-sel" }),
							check === square && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "sq-check" }),
							file === files[0] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "coord coord-rank",
								children: rank
							}),
							rank === ranks[7] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "coord coord-file",
								children: file
							}),
							targetSet.has(square) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: captureSet.has(square) ? "dot-ring" : "dot" }),
							piece && !hide && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChessPiece, {
								type: piece.type,
								color: piece.color
							})
						]
					}, square);
				}))
			}),
			start && tip && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				className: "pointer-events-none absolute inset-0 z-[4]",
				viewBox: "0 0 8 8",
				"aria-hidden": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: start.x,
					y1: start.y,
					x2: tip.x,
					y2: tip.y,
					stroke: "var(--color-pine)",
					strokeWidth: "0.14",
					strokeLinecap: "round"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: tip.x,
					cy: tip.y,
					r: "0.16",
					fill: "var(--color-pine)"
				})]
			}),
			ghost && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed z-30",
				style: {
					left: ghost.x,
					top: ghost.y,
					width: ghost.size,
					height: ghost.size,
					transform: "translate(-50%, -50%)"
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChessPiece, {
					type: ghost.type,
					color: ghost.color
				})
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-full font-medium transition-[transform,background-color,opacity,color] duration-150 ease-out active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-ink hover:opacity-90",
			secondary: "border border-line bg-panel-2 text-ink hover:bg-panel",
			ghost: "text-ink hover:bg-panel-2"
		},
		size: {
			md: "h-11 px-4 text-sm",
			sm: "h-10 px-3 text-sm"
		}
	},
	defaultVariants: {
		variant: "secondary",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function classify(lossCp, isBest) {
	if (isBest || lossCp <= 15) return "best";
	if (lossCp < 45) return "excellent";
	if (lossCp < 90) return "good";
	if (lossCp < 160) return "inaccuracy";
	if (lossCp < 300) return "mistake";
	return "blunder";
}
var MARK_GLYPH = {
	best: "",
	excellent: "!",
	good: "",
	inaccuracy: "?!",
	mistake: "?",
	blunder: "??"
};
function formatEval(cp, mate) {
	if (mate != null) {
		if (mate === 0) return "Mate";
		return mate > 0 ? `+M${mate}` : `-M${Math.abs(mate)}`;
	}
	if (cp == null) return "0.0";
	const pawns = cp / 100;
	return `${pawns > 0 ? "+" : ""}${pawns.toFixed(1)}`;
}
function evalShare(cp, mate) {
	let score = cp ?? 0;
	if (mate != null) score = mate === 0 ? 0 : mate > 0 ? 1800 : -1800;
	return 50 + Math.max(-900, Math.min(900, score)) / 900 * 46;
}
function resultOf(chess) {
	if (chess.isCheckmate()) {
		const winner = chess.turn() === "w" ? "Black" : "White";
		return {
			text: `Checkmate · ${winner} wins`,
			pgn: winner === "White" ? "1-0" : "0-1"
		};
	}
	if (chess.isStalemate()) return {
		text: "Stalemate · draw",
		pgn: "1/2-1/2"
	};
	if (chess.isThreefoldRepetition()) return {
		text: "Threefold repetition · draw",
		pgn: "1/2-1/2"
	};
	if (chess.isInsufficientMaterial()) return {
		text: "Insufficient material · draw",
		pgn: "1/2-1/2"
	};
	if (chess.isDrawByFiftyMoves()) return {
		text: "Fifty-move rule · draw",
		pgn: "1/2-1/2"
	};
	if (chess.isDraw()) return {
		text: "Draw",
		pgn: "1/2-1/2"
	};
	return {
		text: "",
		pgn: "*"
	};
}
function pgnResultToken(result) {
	if (!result) return "*";
	if (result.includes("White wins")) return "1-0";
	if (result.includes("Black wins")) return "0-1";
	if (/draw|stalemate/i.test(result)) return "1/2-1/2";
	return "*";
}
function buildPgn(input) {
	const chess = input.startFen === "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" ? new Chess() : new Chess(input.startFen);
	if (input.startFen !== "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1") {
		chess.setHeader("FEN", input.startFen);
		chess.setHeader("SetUp", "1");
	}
	for (const san of input.sans) chess.move(san);
	const youWhite = input.player === "w";
	const bot = `Halden ${input.botElo}`;
	chess.setHeader("Event", "Halden");
	chess.setHeader("Site", "Halden");
	chess.setHeader("Date", (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replaceAll("-", "."));
	chess.setHeader("White", youWhite ? "You" : bot);
	chess.setHeader("Black", youWhite ? bot : "You");
	chess.setHeader("Result", pgnResultToken(input.result));
	return chess.pgn({ maxWidth: 76 });
}
function strengthLabel(elo, floor, ceiling, engineReady) {
	if (!engineReady || elo < floor) {
		if (elo < 400) return "Built-in beginner";
		if (elo < 800) return "Built-in casual";
		if (elo < floor) return "Built-in club player";
	}
	if (elo > ceiling) return "Stockfish, full strength";
	return "Stockfish, strength limited";
}
var LINES = [
	["e4", "King's Pawn"],
	["e4 e5", "Open Game"],
	["e4 e5 Nf3", "King's Knight"],
	["e4 e5 Nf3 Nc6", "King's Knight Opening"],
	["e4 e5 Nf3 Nc6 Bc4", "Italian Game"],
	["e4 e5 Nf3 Nc6 Bc4 Bc5", "Giuoco Piano"],
	["e4 e5 Nf3 Nc6 Bc4 Bc5 c3", "Giuoco Piano"],
	["e4 e5 Nf3 Nc6 Bc4 Nf6", "Two Knights Defense"],
	["e4 e5 Nf3 Nc6 Bc4 Be7", "Hungarian Defense"],
	["e4 e5 Nf3 Nc6 Bb5", "Ruy Lopez"],
	["e4 e5 Nf3 Nc6 Bb5 a6", "Ruy Lopez, Morphy"],
	["e4 e5 Nf3 Nc6 Bb5 Nf6", "Ruy Lopez, Berlin"],
	["e4 e5 Nf3 Nf6", "Petrov Defense"],
	["e4 e5 Nf3 d6", "Philidor Defense"],
	["e4 e5 Nf3 Nc6 d4", "Scotch Game"],
	["e4 e5 f4", "King's Gambit"],
	["e4 c5", "Sicilian Defense"],
	["e4 c5 Nf3", "Sicilian Defense"],
	["e4 c5 Nf3 d6", "Sicilian Defense"],
	["e4 c5 Nf3 d6 d4", "Open Sicilian"],
	["e4 c5 Nf3 Nc6", "Sicilian, Old Sicilian"],
	["e4 c5 c3", "Sicilian, Alapin"],
	["e4 c5 Nc3", "Closed Sicilian"],
	["e4 e6", "French Defense"],
	["e4 e6 d4", "French Defense"],
	["e4 c6", "Caro-Kann"],
	["e4 c6 d4", "Caro-Kann"],
	["e4 d5", "Scandinavian Defense"],
	["e4 d6", "Pirc Defense"],
	["e4 g6", "Modern Defense"],
	["e4 Nf6", "Alekhine Defense"],
	["d4", "Queen's Pawn"],
	["d4 d5", "Closed Game"],
	["d4 d5 c4", "Queen's Gambit"],
	["d4 d5 c4 e6", "Queen's Gambit Declined"],
	["d4 d5 c4 c6", "Slav Defense"],
	["d4 d5 c4 dxc4", "Queen's Gambit Accepted"],
	["d4 Nf6", "Indian Defense"],
	["d4 Nf6 c4", "Indian Game"],
	["d4 Nf6 c4 e6", "Nimzo / Queen's Indian family"],
	["d4 Nf6 c4 g6", "King's Indian / Grünfeld family"],
	["d4 Nf6 Nf3", "Indian, flexible"],
	["d4 f5", "Dutch Defense"],
	["c4", "English Opening"],
	["c4 e5", "English, reversed Sicilian"],
	["c4 c5", "English, symmetrical"],
	["Nf3", "Réti / Zukertort"],
	["Nf3 d5", "Réti"],
	["Nf3 Nf6", "Réti"]
];
function keyOf(fen) {
	return fen.split(" ").slice(0, 4).join(" ");
}
var BOOK$1 = /* @__PURE__ */ new Map();
for (const [moves, name] of LINES) {
	const chess = new Chess();
	let ok = true;
	for (const san of moves.split(" ")) try {
		chess.move(san);
	} catch {
		ok = false;
		break;
	}
	if (ok) BOOK$1.set(keyOf(chess.fen()), name);
}
function openingName(startFen, sans) {
	if (startFen !== "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1") return null;
	const chess = new Chess();
	let name = null;
	for (const san of sans) {
		try {
			chess.move(san);
		} catch {
			break;
		}
		const hit = BOOK$1.get(keyOf(chess.fen()));
		if (hit) name = hit;
	}
	return name;
}
var ENGINE_URL = "/engines/stockfish-19-lite-single.js";
function pvToSan(fen, uciMoves) {
	const chess = new Chess(fen);
	const sans = [];
	for (const uci of uciMoves.slice(0, 12)) {
		if (uci.length < 4) break;
		try {
			const move = chess.move({
				from: uci.slice(0, 2),
				to: uci.slice(2, 4),
				promotion: uci[4]
			});
			sans.push(move.san);
		} catch {
			break;
		}
	}
	return sans;
}
function parseInfo(line, fen) {
	if (!line.startsWith("info ") || !line.includes(" pv ")) return null;
	if (line.includes(" lowerbound") || line.includes(" upperbound")) return null;
	const score = line.match(/\bscore (cp|mate) (-?\d+)/);
	if (!score) return null;
	const depth = Number(line.match(/\bdepth (\d+)/)?.[1] ?? 0);
	const multipv = Number(line.match(/\bmultipv (\d+)/)?.[1] ?? 1);
	const turn = fen.split(" ")[1] === "b" ? "b" : "w";
	const raw = Number(score[2]);
	let cp = null;
	let mate = null;
	if (score[1] === "mate") mate = turn === "w" ? raw : -raw;
	else cp = turn === "w" ? raw : -raw;
	const pvUci = line.split(" pv ")[1]?.trim().split(/\s+/) ?? [];
	return {
		multipv,
		depth,
		cp,
		mate,
		pvUci,
		pvSan: pvToSan(fen, pvUci)
	};
}
var UciEngine = class {
	worker = null;
	listeners = /* @__PURE__ */ new Set();
	chain = Promise.resolve();
	searching = false;
	infoFn = null;
	startPromise = null;
	eloMin = 1320;
	eloMax = 3190;
	failed = false;
	start() {
		if (this.startPromise) return this.startPromise;
		if (typeof Worker === "undefined") {
			this.failed = true;
			this.startPromise = Promise.reject(/* @__PURE__ */ new Error("Workers are unavailable"));
			return this.startPromise;
		}
		const worker = new Worker(ENGINE_URL);
		this.worker = worker;
		worker.onmessage = (event) => {
			const line = typeof event.data === "string" ? event.data : "";
			if (!line) return;
			if (line.startsWith("bestmove")) this.searching = false;
			for (const listener of [...this.listeners]) listener(line);
		};
		worker.onerror = () => {
			this.failed = true;
		};
		this.startPromise = this.enqueue(() => this.handshake()).catch((error) => {
			this.failed = true;
			throw error;
		});
		return this.startPromise;
	}
	interrupt() {
		this.clearInfo();
		if (this.worker && this.searching) this.send("stop");
	}
	bestMove(fen, opts) {
		return this.enqueue(() => this.bestMoveJob(fen, opts));
	}
	evalOnce(fen, movetime) {
		return this.enqueue(() => this.evalJob(fen, movetime));
	}
	analyze(fen, onLines) {
		return this.enqueue(() => this.analyzeJob(fen, onLines));
	}
	enqueue(job) {
		const run = this.chain.then(job, job);
		this.chain = run.then(() => void 0, () => void 0);
		return run;
	}
	send(command) {
		this.worker?.postMessage(command);
	}
	wait(test, ms) {
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				this.listeners.delete(listener);
				reject(/* @__PURE__ */ new Error("Engine timed out"));
			}, ms);
			const listener = (line) => {
				if (!test(line)) return;
				clearTimeout(timer);
				this.listeners.delete(listener);
				resolve(line);
			};
			this.listeners.add(listener);
		});
	}
	clearInfo() {
		if (!this.infoFn) return;
		this.listeners.delete(this.infoFn);
		this.infoFn = null;
	}
	async handshake() {
		const ready = this.wait((line) => line === "readyok", 2e4);
		const listen = (line) => {
			const match = line.match(/^option name UCI_Elo type spin default \d+ min (\d+) max (\d+)/);
			if (match) {
				this.eloMin = Number(match[1]);
				this.eloMax = Number(match[2]);
			}
			if (line === "uciok") {
				this.send("setoption name Hash value 16");
				this.send("isready");
			}
		};
		this.listeners.add(listen);
		this.send("uci");
		await ready;
		this.listeners.delete(listen);
	}
	async stopSearch() {
		if (!this.searching) return;
		const pending = this.wait((line) => line.startsWith("bestmove"), 1e4);
		this.send("stop");
		try {
			await pending;
		} catch {
			this.searching = false;
		}
		this.clearInfo();
	}
	async ready() {
		this.send("isready");
		await this.wait((line) => line === "readyok", 8e3);
	}
	async configureStrength(elo) {
		const limited = elo != null && elo >= this.eloMin && elo <= this.eloMax;
		this.send(`setoption name UCI_LimitStrength value ${limited ? "true" : "false"}`);
		if (limited && elo != null) this.send(`setoption name UCI_Elo value ${Math.round(elo)}`);
		await this.ready();
	}
	async bestMoveJob(fen, opts) {
		this.clearInfo();
		await this.stopSearch();
		const limited = opts.elo >= this.eloMin && opts.elo <= this.eloMax ? opts.elo : null;
		await this.configureStrength(limited);
		this.send("setoption name MultiPV value 1");
		await this.ready();
		this.send(`position fen ${fen}`);
		this.searching = true;
		this.send(`go movetime ${opts.movetime}`);
		const line = await this.wait((row) => row.startsWith("bestmove"), opts.movetime + 15e3);
		this.searching = false;
		const uci = line.split(/\s+/)[1];
		if (!uci || uci === "(none)") throw new Error("No move");
		return uci;
	}
	async evalJob(fen, movetime) {
		this.clearInfo();
		await this.stopSearch();
		await this.configureStrength(null);
		this.send("setoption name MultiPV value 1");
		await this.ready();
		this.send(`position fen ${fen}`);
		const turn = fen.split(" ")[1] === "b" ? "b" : "w";
		let cp = 0;
		let mate = null;
		const listen = (line) => {
			const score = line.match(/\bscore (cp|mate) (-?\d+)/);
			if (!score || !line.startsWith("info ")) return;
			if (score[1] === "mate") mate = Number(score[2]);
			else {
				mate = null;
				cp = Number(score[2]);
			}
		};
		this.listeners.add(listen);
		this.searching = true;
		this.send(`go movetime ${movetime}`);
		const best = await this.wait((line) => line.startsWith("bestmove"), movetime + 12e3);
		this.listeners.delete(listen);
		this.searching = false;
		const bestUci = best.split(/\s+/)[1];
		let whiteCp;
		if (mate != null) {
			const matePlies = mate;
			const stm = (matePlies > 0 ? 1 : -1) * (1e5 - Math.min(80, Math.abs(matePlies)) * 40);
			whiteCp = turn === "w" ? stm : -stm;
		} else whiteCp = turn === "w" ? cp : -cp;
		return {
			whiteCp,
			bestUci: bestUci && bestUci !== "(none)" ? bestUci : null
		};
	}
	async analyzeJob(fen, onLines) {
		this.clearInfo();
		await this.stopSearch();
		await this.configureStrength(null);
		this.send("setoption name MultiPV value 3");
		await this.ready();
		this.send(`position fen ${fen}`);
		const bucket = /* @__PURE__ */ new Map();
		this.infoFn = (line) => {
			if (line.startsWith("bestmove")) {
				this.searching = false;
				this.clearInfo();
				return;
			}
			const parsed = parseInfo(line, fen);
			if (!parsed) return;
			bucket.set(parsed.multipv, parsed);
			onLines([...bucket.values()].sort((a, b) => a.multipv - b.multipv));
		};
		this.listeners.add(this.infoFn);
		this.searching = true;
		this.send("go depth 14 movetime 2200");
	}
};
var engine = new UciEngine();
function thinkMs(elo) {
	if (elo < 1600) return 280;
	if (elo < 2e3) return 450;
	if (elo < 2400) return 700;
	if (elo < 2800) return 1e3;
	if (elo < 3200) return 1400;
	if (elo < 3600) return 1800;
	return 2300;
}
var ctx = null;
function unlockAudio() {
	if (typeof window === "undefined") return;
	const AudioCtx = window.AudioContext ?? window.webkitAudioContext;
	if (!AudioCtx) return;
	ctx = ctx ?? new AudioCtx();
	if (ctx.state === "suspended") ctx.resume();
}
function playMoveSound(kind) {
	if (!ctx || ctx.state !== "running") return;
	const now = ctx.currentTime;
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = "triangle";
	osc.frequency.value = kind === "capture" ? 168 : kind === "check" ? 490 : 312;
	gain.gain.setValueAtTime(.035, now);
	gain.gain.exponentialRampToValueAtTime(.001, now + .07);
	osc.connect(gain).connect(ctx.destination);
	osc.start(now);
	osc.stop(now + .08);
}
var VAL = {
	p: 100,
	n: 320,
	b: 330,
	r: 500,
	q: 900,
	k: 0
};
/** Piece-square tables, index 0 = a8, white's point of view. Mirrored for black. */
var PST = {
	p: [
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		50,
		50,
		50,
		50,
		50,
		50,
		50,
		50,
		10,
		10,
		20,
		30,
		30,
		20,
		10,
		10,
		5,
		5,
		10,
		25,
		25,
		10,
		5,
		5,
		0,
		0,
		0,
		20,
		20,
		0,
		0,
		0,
		5,
		-5,
		-10,
		0,
		0,
		-10,
		-5,
		5,
		5,
		10,
		10,
		-20,
		-20,
		10,
		10,
		5,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	],
	n: [
		-50,
		-40,
		-30,
		-30,
		-30,
		-30,
		-40,
		-50,
		-40,
		-20,
		0,
		0,
		0,
		0,
		-20,
		-40,
		-30,
		0,
		10,
		15,
		15,
		10,
		0,
		-30,
		-30,
		5,
		15,
		20,
		20,
		15,
		5,
		-30,
		-30,
		0,
		15,
		20,
		20,
		15,
		0,
		-30,
		-30,
		5,
		10,
		15,
		15,
		10,
		5,
		-30,
		-40,
		-20,
		0,
		5,
		5,
		0,
		-20,
		-40,
		-50,
		-40,
		-30,
		-30,
		-30,
		-30,
		-40,
		-50
	],
	b: [
		-20,
		-10,
		-10,
		-10,
		-10,
		-10,
		-10,
		-20,
		-10,
		0,
		0,
		0,
		0,
		0,
		0,
		-10,
		-10,
		0,
		5,
		10,
		10,
		5,
		0,
		-10,
		-10,
		5,
		5,
		10,
		10,
		5,
		5,
		-10,
		-10,
		0,
		10,
		10,
		10,
		10,
		0,
		-10,
		-10,
		10,
		10,
		10,
		10,
		10,
		10,
		-10,
		-10,
		5,
		0,
		0,
		0,
		0,
		5,
		-10,
		-20,
		-10,
		-10,
		-10,
		-10,
		-10,
		-10,
		-20
	],
	r: [
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		5,
		10,
		10,
		10,
		10,
		10,
		10,
		5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		-5,
		0,
		0,
		0,
		0,
		0,
		0,
		-5,
		0,
		0,
		0,
		5,
		5,
		0,
		0,
		0
	],
	q: [
		-20,
		-10,
		-10,
		-5,
		-5,
		-10,
		-10,
		-20,
		-10,
		0,
		0,
		0,
		0,
		0,
		0,
		-10,
		-10,
		0,
		5,
		5,
		5,
		5,
		0,
		-10,
		-5,
		0,
		5,
		5,
		5,
		5,
		0,
		-5,
		0,
		0,
		5,
		5,
		5,
		5,
		0,
		-5,
		-10,
		5,
		5,
		5,
		5,
		5,
		0,
		-10,
		-10,
		0,
		5,
		0,
		0,
		0,
		0,
		-10,
		-20,
		-10,
		-10,
		-5,
		-5,
		-10,
		-10,
		-20
	],
	k: [
		-30,
		-40,
		-40,
		-50,
		-50,
		-40,
		-40,
		-30,
		-30,
		-40,
		-40,
		-50,
		-50,
		-40,
		-40,
		-30,
		-30,
		-40,
		-40,
		-50,
		-50,
		-40,
		-40,
		-30,
		-30,
		-40,
		-40,
		-50,
		-50,
		-40,
		-40,
		-30,
		-20,
		-30,
		-30,
		-40,
		-40,
		-30,
		-30,
		-20,
		-10,
		-20,
		-20,
		-20,
		-20,
		-20,
		-20,
		-10,
		20,
		20,
		0,
		0,
		0,
		0,
		20,
		20,
		20,
		30,
		10,
		0,
		0,
		10,
		30,
		20
	]
};
var BOOK_LINES = [
	"e4 e5 Nf3 Nc6 Bb5 a6",
	"e4 e5 Nf3 Nc6 Bc4 Bc5",
	"e4 e5 Nf3 Nc6 Bc4 Nf6",
	"e4 c5 Nf3 d6 d4 cxd4 Nxd4",
	"e4 c5 Nf3 Nc6 d4",
	"e4 e6 d4 d5",
	"e4 c6 d4 d5",
	"e4 e5 Nf3 Nf6",
	"d4 d5 c4 e6",
	"d4 d5 c4 c6",
	"d4 Nf6 c4 g6",
	"d4 Nf6 c4 e6",
	"d4 d5 Nf3 Nf6",
	"Nf3 d5 d4",
	"c4 e5 Nc3 Nf6"
];
function uciOf(move) {
	return `${move.from}${move.to}${move.promotion ?? ""}`;
}
function bookReplies() {
	const map = /* @__PURE__ */ new Map();
	for (const line of BOOK_LINES) {
		const chess = new Chess();
		for (const san of line.split(" ")) {
			const key = chess.fen().split(" ").slice(0, 4).join(" ");
			let move;
			try {
				move = chess.move(san);
			} catch {
				break;
			}
			const list = map.get(key) ?? [];
			const uci = uciOf(move);
			if (!list.includes(uci)) list.push(uci);
			map.set(key, list);
		}
	}
	return map;
}
var BOOK = bookReplies();
function bookUci(fen, elo) {
	if (elo < 380) return null;
	const options = BOOK.get(fen.split(" ").slice(0, 4).join(" "));
	if (!options?.length) return null;
	if (Math.random() > (elo > 900 ? .9 : elo > 600 ? .62 : .35)) return null;
	return options[Math.floor(Math.random() * options.length)];
}
function spec(move) {
	return {
		from: move.from,
		to: move.to,
		promotion: move.promotion
	};
}
function evalWhite(fen) {
	const placement = fen.split(" ")[0] ?? "";
	let rank = 0;
	let file = 0;
	let score = 0;
	for (const ch of placement) {
		if (ch === "/") {
			rank += 1;
			file = 0;
			continue;
		}
		if (ch >= "1" && ch <= "8") {
			file += Number(ch);
			continue;
		}
		const color = ch === ch.toUpperCase() ? "w" : "b";
		const type = ch.toLowerCase();
		const idx = (color === "w" ? rank : 7 - rank) * 8 + file;
		const val = VAL[type] + (PST[type][idx] ?? 0);
		score += color === "w" ? val : -val;
		file += 1;
	}
	return score;
}
function sideEval(chess) {
	const white = evalWhite(chess.fen());
	return chess.turn() === "w" ? white : -white;
}
function ordered(chess) {
	const moves = chess.moves({ verbose: true });
	const victim = {
		p: 1,
		n: 3,
		b: 3,
		r: 5,
		q: 9,
		k: 0
	};
	return moves.sort((a, b) => score(b) - score(a));
	function score(move) {
		let value = 0;
		if (move.captured) value += 10 * victim[move.captured] - victim[move.piece];
		if (move.promotion === "q") value += 8;
		return value;
	}
}
function search(chess, elo) {
	const depth = elo < 550 ? 1 : 2;
	const maxNodes = elo < 450 ? 500 : elo < 850 ? 4e3 : 14e3;
	let nodes = 0;
	const scoreMove = (depthLeft, alphaIn, beta, ply) => {
		if (nodes++ > maxNodes) return sideEval(chess);
		if (chess.isCheckmate()) return -1e5 + ply;
		if (chess.isDraw()) return 0;
		if (depthLeft === 0) return quiesce(alphaIn, beta, ply, 0);
		let alpha = alphaIn;
		const moves = ordered(chess);
		if (!moves.length) return chess.inCheck() ? -1e5 + ply : 0;
		for (const move of moves) {
			chess.move(spec(move));
			const score = -scoreMove(depthLeft - 1, -beta, -alpha, ply + 1);
			chess.undo();
			if (score > alpha) alpha = score;
			if (alpha >= beta) break;
		}
		return alpha;
	};
	const quiesce = (alphaIn, beta, ply, qdepth) => {
		if (nodes++ > maxNodes) return sideEval(chess);
		if (chess.isCheckmate()) return -1e5 + ply;
		if (chess.isDraw()) return 0;
		const check = chess.inCheck();
		let alpha = alphaIn;
		if (!check) {
			const stand = sideEval(chess);
			if (stand >= beta) return beta;
			if (stand > alpha) alpha = stand;
			if (qdepth >= 2) return alpha;
		}
		const moves = ordered(chess).filter((move) => check || move.captured || move.promotion);
		if (!moves.length) return alpha;
		for (const move of moves) {
			chess.move(spec(move));
			const score = -quiesce(-beta, -alpha, ply + 1, qdepth + 1);
			chess.undo();
			if (score > alpha) alpha = score;
			if (alpha >= beta) break;
		}
		return alpha;
	};
	const root = ordered(chess).map((move) => {
		chess.move(spec(move));
		const score = depth <= 1 ? -sideEval(chess) : -scoreMove(depth - 1, -1e6, 1e6, 1);
		chess.undo();
		return {
			move,
			score
		};
	});
	root.sort((a, b) => b.score - a.score);
	return root;
}
function pick(scored, elo) {
	if (!scored.length) throw new Error("No scored moves");
	if (scored.length === 1) return scored[0].move;
	if (Math.random() < (elo < 180 ? .85 : elo < 400 ? .42 : elo < 700 ? .16 : elo < 1e3 ? .06 : .015)) {
		const pool = elo > 650 ? scored.filter((row) => row.score > -5e4 && row.score >= scored[0].score - 180) : scored;
		const choices = pool.length ? pool : scored;
		const span = elo < 400 ? choices.length : Math.min(choices.length, 5);
		return choices[Math.floor(Math.random() * span)].move;
	}
	const temp = Math.max(8, (1100 - elo) / 12 + 8);
	const pool = scored.filter((row) => row.score >= scored[0].score - temp * 3);
	const band = pool.length ? pool : scored.slice(0, 2);
	const max = band[0].score;
	const weights = band.map((row) => Math.exp((row.score - max) / temp));
	let roll = Math.random() * weights.reduce((sum, weight) => sum + weight, 0);
	for (let i = 0; i < band.length; i += 1) {
		roll -= weights[i];
		if (roll <= 0) return band[i].move;
	}
	return band[0].move;
}
function weakUci(fen, elo) {
	const chess = new Chess(fen);
	const moves = chess.moves({ verbose: true });
	if (!moves.length) throw new Error("No legal moves");
	const booked = bookUci(fen, elo);
	if (booked && moves.some((move) => uciOf(move) === booked)) return booked;
	if (elo < 280) {
		const captures = moves.filter((move) => move.captured);
		const pool = captures.length && Math.random() < .35 ? captures : moves;
		return uciOf(pool[Math.floor(Math.random() * pool.length)]);
	}
	const scored = search(chess, elo);
	if (!scored.length) return uciOf(moves[0]);
	return uciOf(pick(scored, elo));
}
function thinkDelay(elo) {
	if (elo < 400) return 180 + Math.random() * 220;
	if (elo < 1e3) return 260 + Math.random() * 320;
	return 320 + Math.random() * 380;
}
var STORAGE_KEY = "halden.v1";
var botGen = 0;
var reviewGen = 0;
var activeFen = null;
var booted = false;
var lastSaved = "";
function readPersist() {
	if (typeof window === "undefined") return {};
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return {};
		return JSON.parse(raw) ?? {};
	} catch {
		return {};
	}
}
function writePersist(state) {
	if (typeof window === "undefined") return;
	const data = {
		botElo: state.botElo,
		player: state.player,
		hints: state.hints,
		archive: state.archive.slice(0, 20)
	};
	localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
function canHuman(state) {
	if (state.thinking || state.reviewing || state.promo) return false;
	const chess = new Chess(state.fens[state.cursor]);
	if (chess.isGameOver()) return false;
	if (state.mode === "play") {
		if (state.over) return false;
		if (state.cursor !== state.fens.length - 1) return false;
		if (chess.turn() !== state.player) return false;
	}
	return true;
}
async function chooseUci(fen, elo, engineReady) {
	if (elo >= engine.eloMin && !engine.failed) try {
		if (!engineReady) await engine.start();
		if (!engine.failed) return await engine.bestMove(fen, {
			elo,
			movetime: thinkMs(elo)
		});
	} catch {
		return weakUci(fen, Math.min(elo, 1800));
	}
	const started = performance.now();
	const uci = weakUci(fen, elo);
	const wait = thinkDelay(elo) - (performance.now() - started);
	if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
	return uci;
}
var useStudio = create((set, get) => ({
	mode: "play",
	startFen: DEFAULT_POSITION,
	sans: [],
	fens: [DEFAULT_POSITION],
	cursor: 0,
	player: "w",
	botElo: 1400,
	orientation: "w",
	over: false,
	result: null,
	anns: [],
	reviewing: false,
	reviewIndex: 0,
	hints: false,
	thinking: false,
	engineReady: false,
	engineError: null,
	lines: [],
	selected: null,
	promo: null,
	archive: [],
	notationError: null,
	boot: () => {
		if (booted) return;
		booted = true;
		const saved = readPersist();
		const player = saved.player === "b" ? "b" : "w";
		set({
			player,
			orientation: player,
			botElo: typeof saved.botElo === "number" ? Math.max(100, Math.min(4e3, Math.round(saved.botElo))) : 1400,
			hints: Boolean(saved.hints),
			archive: Array.isArray(saved.archive) ? saved.archive.slice(0, 20) : []
		});
		engine.start().then(() => {
			if (!engine.failed) set({ engineReady: true });
			else set({ engineError: "Stockfish did not start. Opponents use the built-in player." });
		}).catch(() => {
			set({ engineError: "Stockfish did not start. Opponents use the built-in player." });
		});
	},
	onPosition: () => {
		const state = get();
		const chess = new Chess(state.fens[state.cursor]);
		if (state.mode === "play" && !state.over && !state.reviewing && state.cursor === state.fens.length - 1 && !chess.isGameOver() && chess.turn() !== state.player) {
			if (!state.thinking) requestBot();
			return;
		}
		if (!state.thinking) syncEngine();
	},
	newGame: (player) => {
		const state = get();
		saveIfNeeded(state);
		botGen += 1;
		reviewGen += 1;
		activeFen = null;
		engine.interrupt();
		const side = player ?? state.player;
		set({
			mode: "play",
			player: side,
			orientation: side,
			startFen: DEFAULT_POSITION,
			sans: [],
			fens: [DEFAULT_POSITION],
			cursor: 0,
			over: false,
			result: null,
			anns: [],
			reviewing: false,
			thinking: false,
			lines: [],
			selected: null,
			promo: null,
			notationError: null
		});
	},
	setElo: (elo) => set({ botElo: Math.max(100, Math.min(4e3, Math.round(elo))) }),
	flip: () => set((state) => ({ orientation: state.orientation === "w" ? "b" : "w" })),
	step: (delta) => {
		const state = get();
		set({
			cursor: Math.max(0, Math.min(state.fens.length - 1, state.cursor + delta)),
			selected: null,
			promo: null
		});
	},
	goto: (cursor) => {
		const state = get();
		set({
			cursor: Math.max(0, Math.min(state.fens.length - 1, cursor)),
			selected: null,
			promo: null
		});
	},
	takeback: () => {
		const state = get();
		botGen += 1;
		engine.interrupt();
		if (state.mode !== "play") {
			set({
				cursor: Math.max(0, state.cursor - 1),
				thinking: false,
				selected: null,
				promo: null
			});
			return;
		}
		const drop = new Chess(state.fens[state.fens.length - 1]).turn() === state.player ? Math.min(2, state.sans.length) : Math.min(1, state.sans.length);
		const sans = state.sans.slice(0, state.sans.length - drop);
		set({
			sans,
			fens: state.fens.slice(0, sans.length + 1),
			cursor: sans.length,
			over: false,
			result: null,
			anns: [],
			thinking: false,
			selected: null,
			promo: null,
			lines: []
		});
		activeFen = null;
	},
	resign: () => {
		const state = get();
		if (state.mode !== "play" || state.over || state.sans.length === 0) return;
		botGen += 1;
		engine.interrupt();
		set({
			over: true,
			result: `Resigned · ${state.player === "w" ? "Black" : "White"} wins`,
			thinking: false,
			selected: null,
			promo: null
		});
		saveIfNeeded(get());
	},
	setHints: (hints) => {
		activeFen = null;
		set({
			hints,
			lines: hints ? get().lines : []
		});
	},
	setMode: (mode) => {
		if (mode === get().mode) return;
		botGen += 1;
		reviewGen += 1;
		activeFen = null;
		engine.interrupt();
		set({
			mode,
			thinking: false,
			reviewing: false,
			selected: null,
			promo: null,
			lines: []
		});
	},
	handleSquare: (square) => {
		unlockAudio();
		const state = get();
		if (!canHuman(state)) return;
		const chess = new Chess(state.fens[state.cursor]);
		if (state.selected) {
			if (chess.moves({
				square: state.selected,
				verbose: true
			}).some((move) => move.to === square)) {
				get().tryMove(state.selected, square);
				return;
			}
		}
		const piece = chess.get(square);
		if (piece && piece.color === chess.turn()) set({ selected: square });
		else set({ selected: null });
	},
	tryMove: (from, to, promotion) => {
		unlockAudio();
		const state = get();
		if (!canHuman(state)) return;
		const moves = new Chess(state.fens[state.cursor]).moves({
			square: from,
			verbose: true
		}).filter((move) => move.to === to);
		if (!moves.length) {
			set({ selected: null });
			return;
		}
		if (moves.some((move) => move.promotion) && !promotion) {
			set({
				promo: {
					from,
					to
				},
				selected: null
			});
			return;
		}
		commitSan((promotion ? moves.find((move) => move.promotion === promotion) ?? moves[0] : moves[0]).san);
	},
	choosePromotion: (piece) => {
		const promo = get().promo;
		if (!promo) return;
		set({ promo: null });
		get().tryMove(promo.from, promo.to, piece);
	},
	cancelPromo: () => set({ promo: null }),
	loadNotation: (text) => {
		const trimmed = text.trim();
		if (!trimmed) {
			set({ notationError: "Paste a PGN or a FEN first." });
			return;
		}
		botGen += 1;
		reviewGen += 1;
		activeFen = null;
		engine.interrupt();
		try {
			if (trimmed.includes("/") && !trimmed.startsWith("[") && !/\d+\./.test(trimmed)) {
				const chess = new Chess(trimmed);
				const fen = chess.fen();
				const over = chess.isGameOver();
				set({
					mode: "review",
					startFen: fen,
					sans: [],
					fens: [fen],
					cursor: 0,
					over,
					result: over ? resultOf(chess).text : null,
					anns: [],
					reviewing: false,
					thinking: false,
					lines: [],
					selected: null,
					promo: null,
					notationError: null
				});
				return;
			}
			const chess = new Chess();
			chess.loadPgn(trimmed, { strict: false });
			const headers = chess.getHeaders();
			const startFen = headers.SetUp === "1" && headers.FEN ? headers.FEN : DEFAULT_POSITION;
			const sans = chess.history();
			const replay = startFen === "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" ? new Chess() : new Chess(startFen);
			const fens = [replay.fen()];
			for (const san of sans) {
				replay.move(san);
				fens.push(replay.fen());
			}
			const over = replay.isGameOver();
			set({
				mode: "review",
				startFen: fens[0],
				sans,
				fens,
				cursor: fens.length - 1,
				over,
				result: over ? resultOf(replay).text : headers.Result && headers.Result !== "*" ? headers.Result : null,
				anns: [],
				reviewing: false,
				thinking: false,
				lines: [],
				selected: null,
				promo: null,
				notationError: null,
				player: replay.turn(),
				orientation: replay.turn()
			});
		} catch (error) {
			set({ notationError: error instanceof Error ? error.message : "Could not read that notation." });
		}
	},
	reviewGame: () => {
		const state = get();
		if (!state.sans.length || state.reviewing || !state.engineReady || engine.failed) return;
		reviewGen += 1;
		const gen = reviewGen;
		botGen += 1;
		activeFen = null;
		engine.interrupt();
		set({
			mode: "review",
			reviewing: true,
			reviewIndex: 0,
			anns: [],
			thinking: false,
			lines: [],
			selected: null,
			promo: null
		});
		runReview(gen);
	},
	cancelReview: () => {
		reviewGen += 1;
		set({ reviewing: false });
	},
	playFromHere: () => {
		const state = get();
		const fen = state.fens[state.cursor];
		const chess = new Chess(fen);
		botGen += 1;
		reviewGen += 1;
		activeFen = null;
		engine.interrupt();
		const over = chess.isGameOver();
		set({
			mode: "play",
			startFen: fen,
			sans: [],
			fens: [fen],
			cursor: 0,
			over,
			result: over ? resultOf(chess).text : null,
			anns: [],
			reviewing: false,
			thinking: false,
			lines: [],
			selected: null,
			promo: null,
			orientation: state.player
		});
	},
	saveCurrent: () => saveIfNeeded(get(), true)
}));
function commitSan(san) {
	const state = useStudio.getState();
	const chess = new Chess(state.fens[state.cursor]);
	let move;
	try {
		move = chess.move(san);
	} catch {
		return;
	}
	const sans = state.sans.slice(0, state.cursor).concat(move.san);
	const fens = state.fens.slice(0, state.cursor + 1).concat(chess.fen());
	const over = chess.isGameOver();
	const result = over ? resultOf(chess).text : null;
	playMoveSound(chess.inCheck() ? "check" : move.isCapture() ? "capture" : "move");
	activeFen = null;
	useStudio.setState({
		sans,
		fens,
		cursor: fens.length - 1,
		over: state.mode === "play" ? over : over,
		result,
		anns: [],
		selected: null,
		promo: null,
		lines: []
	});
	if (over && state.mode === "play") saveIfNeeded(useStudio.getState());
}
async function requestBot() {
	const state = useStudio.getState();
	const fen = state.fens[state.cursor];
	const gen = ++botGen;
	activeFen = null;
	engine.interrupt();
	useStudio.setState({
		thinking: true,
		lines: [],
		selected: null,
		promo: null
	});
	try {
		const uci = await chooseUci(fen, state.botElo, useStudio.getState().engineReady);
		if (gen !== botGen) return;
		if (useStudio.getState().fens[useStudio.getState().cursor] !== fen) return;
		commitSan(new Chess(fen).move({
			from: uci.slice(0, 2),
			to: uci.slice(2, 4),
			promotion: uci[4]
		}).san);
	} catch {} finally {
		if (gen === botGen) useStudio.setState({ thinking: false });
	}
}
function syncEngine() {
	const state = useStudio.getState();
	if (state.reviewing || state.thinking || !state.engineReady || engine.failed) return;
	const fen = state.fens[state.cursor];
	const chess = new Chess(fen);
	if (!(state.mode === "review" || state.hints && state.mode === "play" && !state.over && state.cursor === state.fens.length - 1 && chess.turn() === state.player)) {
		if (activeFen) {
			activeFen = null;
			engine.interrupt();
			useStudio.setState({ lines: [] });
		}
		return;
	}
	if (activeFen === fen) return;
	activeFen = fen;
	const token = fen;
	engine.analyze(fen, (lines) => {
		if (activeFen !== token) return;
		if (useStudio.getState().fens[useStudio.getState().cursor] !== token) return;
		useStudio.setState({ lines });
	});
}
async function runReview(gen) {
	const state = useStudio.getState();
	const anns = [];
	const chess = state.startFen === "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" ? new Chess() : new Chess(state.startFen);
	for (let i = 0; i < state.sans.length; i += 1) {
		if (gen !== reviewGen) return;
		useStudio.setState({
			reviewIndex: i + 1,
			cursor: i
		});
		let before;
		try {
			before = await engine.evalOnce(chess.fen(), 170);
		} catch {
			anns.push(null);
			try {
				chess.move(state.sans[i]);
			} catch {
				break;
			}
			continue;
		}
		if (gen !== reviewGen) return;
		let bestSan;
		if (before.bestUci && before.bestUci.length >= 4) {
			const probe = new Chess(chess.fen());
			try {
				bestSan = probe.move({
					from: before.bestUci.slice(0, 2),
					to: before.bestUci.slice(2, 4),
					promotion: before.bestUci[4]
				}).san;
			} catch {
				bestSan = void 0;
			}
		}
		const mover = chess.turn();
		const beforeWhite = before.whiteCp;
		let played;
		try {
			played = chess.move(state.sans[i]);
		} catch {
			break;
		}
		let afterWhite = beforeWhite;
		try {
			afterWhite = (await engine.evalOnce(chess.fen(), 120)).whiteCp;
		} catch {
			afterWhite = beforeWhite;
		}
		if (gen !== reviewGen) return;
		const loss = Math.max(0, mover === "w" ? beforeWhite - afterWhite : afterWhite - beforeWhite);
		anns.push({
			mark: classify(loss, bestSan === played.san),
			loss,
			bestSan
		});
		useStudio.setState({
			anns: [...anns],
			cursor: i + 1
		});
	}
	if (gen !== reviewGen) return;
	useStudio.setState({
		reviewing: false,
		cursor: useStudio.getState().fens.length - 1
	});
}
function saveIfNeeded(state, force = false) {
	if (!state.sans.length && state.startFen === "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1") return;
	let pgn = "";
	try {
		pgn = buildPgn({
			startFen: state.startFen,
			sans: state.sans,
			player: state.player,
			botElo: state.botElo,
			result: state.result
		});
	} catch {
		return;
	}
	if (!force && pgn === lastSaved) return;
	lastSaved = pgn;
	const label = `${state.sans.length} plies${state.result ? ` · ${state.result}` : ""}`;
	const entry = {
		id: `${Date.now()}`,
		at: Date.now(),
		pgn,
		label
	};
	useStudio.setState({ archive: [entry, ...useStudio.getState().archive].slice(0, 20) });
}
if (typeof window !== "undefined") useStudio.subscribe((state, prev) => {
	if (state.botElo !== prev.botElo || state.player !== prev.player || state.hints !== prev.hints || state.archive !== prev.archive) writePersist(state);
});
var PRESETS = [
	{
		elo: 200,
		name: "Beginner"
	},
	{
		elo: 600,
		name: "Casual"
	},
	{
		elo: 1e3,
		name: "Club"
	},
	{
		elo: 1400,
		name: "Strong"
	},
	{
		elo: 1800,
		name: "Expert"
	},
	{
		elo: 2200,
		name: "Master"
	},
	{
		elo: 2700,
		name: "Grandmaster"
	},
	{
		elo: 3200,
		name: "Engine"
	},
	{
		elo: 4e3,
		name: "Max"
	}
];
var SAMPLES = [
	{
		name: "Scholar's mate",
		pgn: `[Event "Halden sample"]
[Result "1-0"]

1. e4 e5 2. Qh5 Nc6 3. Bc4 Nf6 4. Qxf7# 1-0`
	},
	{
		name: "Fool's mate",
		pgn: `[Event "Halden sample"]
[Result "0-1"]

1. f3 e5 2. g4 Qh4# 0-1`
	},
	{
		name: "Opera game",
		pgn: `[Event "Opera game"]
[White "Morphy"]
[Black "Duke and Count"]
[Result "1-0"]

1. e4 e5 2. Nf3 d6 3. d4 Bg4 4. dxe5 Bxf3 5. Qxf3 dxe5 6. Bc4 Nf6 7. Qb3 Qe7 8. Nc3 c6 9. Bg5 b5 10. Nxb5 cxb5 11. Bxb5+ Nbd7 12. O-O-O Rd8 13. Rxd7 Rxd7 14. Rd1 Qe6 15. Bxd7+ Nxd7 16. Qb8+ Nxb8 17. Rd8# 1-0`
	}
];
var PIECE_NAME = {
	p: "pawn",
	n: "knight",
	b: "bishop",
	r: "rook",
	q: "queen",
	k: "king"
};
function Studio() {
	const state = useStudio();
	const fen = state.fens[state.cursor] ?? "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
	const [notationOpen, setNotationOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [eloText, setEloText] = (0, import_react.useState)(String(state.botElo));
	(0, import_react.useEffect)(() => {
		state.boot();
	}, [state.boot]);
	(0, import_react.useEffect)(() => {
		state.onPosition();
	}, [
		state.onPosition,
		fen,
		state.cursor,
		state.mode,
		state.over,
		state.player,
		state.hints,
		state.reviewing,
		state.engineReady,
		state.thinking,
		state.botElo
	]);
	(0, import_react.useEffect)(() => {
		setEloText(String(state.botElo));
	}, [state.botElo]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
			if (event.key === "ArrowLeft") state.step(-1);
			if (event.key === "ArrowRight") state.step(1);
			if (event.key === "Home") state.goto(0);
			if (event.key === "End") state.goto(state.fens.length - 1);
			if (event.key === "f" || event.key === "F") state.flip();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		state.step,
		state.goto,
		state.flip,
		state.fens.length
	]);
	const position = (0, import_react.useMemo)(() => new Chess(fen), [fen]);
	const opening = openingName(state.startFen, state.sans.slice(0, state.cursor));
	const last = (0, import_react.useMemo)(() => lastSquares(state.fens, state.sans, state.cursor), [
		state.fens,
		state.sans,
		state.cursor
	]);
	const check = (0, import_react.useMemo)(() => {
		if (!position.inCheck()) return null;
		for (const row of position.board()) for (const piece of row) if (piece && piece.type === "k" && piece.color === position.turn()) return piece.square;
		return null;
	}, [position]);
	const legal = state.selected ? position.moves({
		square: state.selected,
		verbose: true
	}) : [];
	const interactive = canPlay(state, position);
	const line = state.lines[0];
	const hint = state.mode === "review" || state.hints ? line?.pvUci[0] ?? null : null;
	const share = line ? evalShare(line.cp, line.mate) : 50;
	const bottomShare = state.orientation === "w" ? share : 100 - share;
	const ann = state.cursor > 0 ? state.anns[state.cursor - 1] : null;
	const status = statusText(state, position, opening);
	function openNotation() {
		unlockAudio();
		try {
			setDraft(buildPgn({
				startFen: state.startFen,
				sans: state.sans,
				player: state.player,
				botElo: state.botElo,
				result: state.result
			}));
		} catch {
			setDraft("");
		}
		setCopied(false);
		setNotationOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-dvh w-full max-w-6xl px-3 pb-8 pt-4 sm:px-6",
		onPointerDown: unlockAudio,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl leading-none tracking-tight text-ink",
					children: "Halden"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Play, import, and review"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "seg",
					role: "tablist",
					"aria-label": "Mode",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": state.mode === "play",
						"aria-pressed": state.mode === "play",
						onClick: () => state.setMode("play"),
						children: "Play"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": state.mode === "review",
						"aria-pressed": state.mode === "review",
						onClick: () => state.setMode("review"),
						children: "Review"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-[minmax(0,40rem)_minmax(18rem,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-stretch gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "eval-track",
							role: "img",
							"aria-label": line ? `Evaluation ${formatEval(line.cp, line.mate)}` : "No evaluation yet",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("eval-fill", state.orientation === "w" ? "eval-dark" : "eval-light"),
								style: { flex: 100 - bottomShare }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("eval-fill", state.orientation === "w" ? "eval-light" : "eval-dark"),
								style: { flex: bottomShare }
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {
								fen,
								orientation: state.orientation,
								selected: state.selected,
								targets: legal.map((move) => move.to),
								captures: legal.filter((move) => move.captured || move.isEnPassant()).map((move) => move.to),
								last,
								check,
								hint,
								interactive,
								onSquare: state.handleSquare,
								onDrop: state.tryMove
							}), state.promo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 z-20 flex items-center justify-center bg-canvas/55",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "panel flex gap-2 p-3",
									role: "dialog",
									"aria-label": "Choose promotion",
									children: [[
										"q",
										"r",
										"b",
										"n"
									].map((piece) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "flex size-14 items-center justify-center rounded-xl bg-sq-light",
										"aria-label": `Promote to ${PIECE_NAME[piece]}`,
										onClick: () => state.choosePromotion(piece),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChessPiece, {
											type: piece,
											color: position.turn()
										})
									}, piece)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "sm",
										onClick: state.cancelPromo,
										children: "Cancel"
									})]
								})
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("text-sm font-medium text-ink", state.thinking && "pulse-soft"),
								role: "status",
								children: status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-sm text-muted",
								children: [line ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: [formatEval(line.cp, line.mate), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-faint",
										children: [" · depth ", line.depth]
									})]
								}) : opening ? opening : " ", ann ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: ann.mark === "blunder" || ann.mark === "mistake" ? "text-danger" : "text-pine",
									children: [` · ${labelMark(ann.mark)}`, ann.bestSan ? ` · best ${ann.bestSan}` : ""]
								}) : null]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Start",
									onClick: () => state.goto(0),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronFirst, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Previous move",
									onClick: () => state.step(-1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Next move",
									onClick: () => state.step(1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Latest",
									onClick: () => state.goto(state.fens.length - 1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLast, { className: "size-5" })
								})
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "panel min-w-0 p-4",
					children: [
						state.mode === "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-muted",
									children: "You play"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "seg mt-2 w-fit",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": state.player === "w",
										onClick: () => state.newGame("w"),
										children: "White"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": state.player === "b",
										onClick: () => state.newGame("b"),
										children: "Black"
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-muted",
											children: "Opponent"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-2xl tabular-nums leading-none",
											children: state.botElo
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-faint",
										children: strengthLabel(state.botElo, engine.eloMin, engine.eloMax, state.engineReady && !state.engineError)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider, {
										className: "relative mt-3 flex h-11 w-full touch-none items-center",
										min: 100,
										max: 4e3,
										step: 10,
										value: [state.botElo],
										onValueChange: ([value]) => state.setElo(value),
										"aria-label": "Opponent Elo",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
											className: "relative h-1.5 grow rounded-full bg-panel-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full rounded-full bg-pine" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, {
											className: "flex size-11 items-center justify-center rounded-full focus-visible:outline-none",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block size-5 rounded-full bg-accent" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "mt-2 flex items-center justify-between gap-3 text-sm text-muted",
										children: ["Exact Elo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: "field h-11 w-24 text-center tabular-nums",
											inputMode: "numeric",
											"aria-label": "Exact Elo",
											value: eloText,
											onChange: (event) => setEloText(event.target.value.replace(/[^\d]/g, "").slice(0, 4)),
											onBlur: () => {
												const next = Math.max(100, Math.min(4e3, Number(eloText) || state.botElo));
												setEloText(String(next));
												state.setElo(next);
											},
											onKeyDown: (event) => {
												if (event.key === "Enter") event.currentTarget.blur();
											}
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 flex flex-wrap gap-2",
										children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											"aria-pressed": state.botElo === preset.elo,
											className: cn("h-11 rounded-full border border-line px-3 text-sm", state.botElo === preset.elo ? "bg-accent text-accent-ink" : "bg-panel-2 text-muted"),
											onClick: () => state.setElo(preset.elo),
											children: [
												preset.name,
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "tabular-nums",
													children: preset.elo
												})
											]
										}, preset.elo))
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "primary",
											onClick: () => state.newGame(),
											children: "New game"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: state.takeback,
											disabled: !state.sans.length,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Take back"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: state.flip,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlipVertical2, { className: "size-4" }), "Flip"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: state.resign,
											disabled: state.over || state.sans.length === 0,
											children: "Resign"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-pressed": state.hints,
									className: "flex h-11 items-center justify-between rounded-2xl border border-line bg-panel-2 px-3 text-sm",
									onClick: () => state.setHints(!state.hints),
									children: ["Engine lines while you play", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("tabular-nums", state.hints ? "text-pine" : "text-faint"),
										children: state.hints ? "On" : "Off"
									})]
								}),
								state.mode === "play" && state.cursor < state.fens.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => state.goto(state.fens.length - 1),
									children: "Back to the live game"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "primary",
											onClick: state.reviewGame,
											disabled: !state.sans.length || state.reviewing || !state.engineReady,
											children: state.reviewing ? `Reading ${state.reviewIndex}/${state.sans.length}` : "Analyze game"
										}),
										state.reviewing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											onClick: state.cancelReview,
											children: "Cancel"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: state.playFromHere,
											children: "Play from here"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: state.flip,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlipVertical2, { className: "size-4" }), "Flip"]
										})
									]
								}),
								state.reviewing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-1 overflow-hidden rounded-full bg-panel-2",
									"aria-hidden": true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-pine",
										style: { width: `${state.sans.length ? state.reviewIndex / state.sans.length * 100 : 0}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-faint",
									children: state.engineError ?? (state.engineReady ? "Stockfish reads the current position. Analyze game marks every move." : "Preparing Stockfish…")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EngineLines, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveList, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: openNotation,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-4" }), "PGN / FEN"]
							})
						}),
						state.archive.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-muted",
								children: "Saved on this device"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-1",
								children: state.archive.slice(0, 6).map((game) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "w-full rounded-xl px-2 py-2 text-left text-sm text-ink hover:bg-panel-2",
									onClick: () => state.loadNotation(game.pgn),
									children: game.label
								}) }, game.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-xs leading-relaxed text-faint",
							children: [
								"Bots under ",
								engine.eloMin,
								" are a built-in player. ",
								engine.eloMin,
								"–",
								engine.eloMax,
								" uses Stockfish with a strength cap. Above that, Stockfish thinks longer at full strength. Engine:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "underline",
									href: "https://github.com/official-stockfish/Stockfish",
									target: "_blank",
									rel: "noreferrer",
									children: "Stockfish 19"
								}),
								" ",
								"(GPL-3.0)."
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: notationOpen,
				onOpenChange: setNotationOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "modal-overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "modal-card",
					"aria-describedby": void 0,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-display text-2xl tracking-tight",
							children: "Notation"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "mt-1 text-sm text-muted",
							children: "Paste a PGN or a FEN. Samples load straight into review."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "field mt-3 min-h-40 font-mono text-sm",
							value: draft,
							onChange: (event) => setDraft(event.target.value),
							spellCheck: false,
							"aria-label": "PGN or FEN"
						}),
						state.notationError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-danger",
							children: state.notationError
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "primary",
									onClick: () => {
										state.loadNotation(draft);
										if (!useStudio.getState().notationError) setNotationOpen(false);
									},
									children: "Load"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => {
										navigator.clipboard?.writeText(draft).then(() => setCopied(true), () => setCopied(false));
									},
									children: copied ? "Copied" : "Copy"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: () => setNotationOpen(false),
									children: "Close"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: SAMPLES.map((sample) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => {
									setDraft(sample.pgn);
									state.loadNotation(sample.pgn);
									if (!useStudio.getState().notationError) setNotationOpen(false);
								},
								children: sample.name
							}, sample.name))
						})
					]
				})] })
			})
		]
	});
}
function EngineLines() {
	const lines = useStudio((s) => s.lines);
	const mode = useStudio((s) => s.mode);
	const hints = useStudio((s) => s.hints);
	const thinking = useStudio((s) => s.thinking);
	if (mode === "play" && !hints) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium text-muted",
			children: "Lines"
		}), lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("text-sm text-faint", thinking && "pulse-soft"),
			children: thinking ? "Opponent is thinking" : "Waiting for the engine"
		}) : lines.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm leading-snug text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mr-2 tabular-nums text-pine",
				children: formatEval(row.cp, row.mate)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-faint",
				children: row.pvSan.join(" ") || "…"
			})]
		}, row.multipv))]
	});
}
function MoveList() {
	const sans = useStudio((s) => s.sans);
	const cursor = useStudio((s) => s.cursor);
	const anns = useStudio((s) => s.anns);
	const goto = useStudio((s) => s.goto);
	if (!sans.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-4 text-sm text-faint",
		children: "Moves will show up here. Tap a piece, then a square, or drag it."
	});
	const rows = [];
	for (let i = 0; i < sans.length; i += 2) rows.push({
		n: i / 2 + 1,
		w: sans[i],
		b: sans[i + 1],
		wPly: i,
		bPly: sans[i + 1] ? i + 1 : void 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 max-h-64 overflow-auto pr-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-[2rem_1fr_1fr] gap-x-2 gap-y-1 text-sm",
			children: rows.flatMap((row) => [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "self-center tabular-nums text-faint",
					children: [row.n, "."]
				}, `n-${row.n}`),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveButton, {
					san: row.w ?? "",
					ply: row.wPly,
					cursor,
					ann: anns[row.wPly],
					onGoto: goto
				}, `w-${row.n}`),
				row.bPly != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveButton, {
					san: row.b ?? "",
					ply: row.bPly,
					cursor,
					ann: anns[row.bPly],
					onGoto: goto
				}, `b-${row.n}`) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}, `e-${row.n}`)
			])
		})
	});
}
function MoveButton({ san, ply, cursor, ann, onGoto }) {
	const glyph = ann ? MARK_GLYPH[ann.mark] : "";
	const bad = ann && (ann.mark === "blunder" || ann.mark === "mistake" || ann.mark === "inaccuracy");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: cn("h-11 rounded-lg px-2 text-left tabular-nums", cursor === ply + 1 ? "move-on" : "hover:bg-panel-2", bad ? "text-danger" : ann?.mark === "best" ? "text-pine" : "text-ink"),
		onClick: () => onGoto(ply + 1),
		children: [san, glyph]
	});
}
function IconButton({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: "flex size-11 items-center justify-center rounded-full bg-panel text-ink",
		onClick,
		children
	});
}
function canPlay(state, position) {
	if (state.thinking || state.reviewing || state.promo) return false;
	if (position.isGameOver()) return false;
	if (state.mode === "play") {
		if (state.over) return false;
		if (state.cursor !== state.fens.length - 1) return false;
		if (position.turn() !== state.player) return false;
	}
	return true;
}
function statusText(state, position, opening) {
	if (state.reviewing) return `Analyzing move ${state.reviewIndex} of ${state.sans.length}`;
	if (state.result && (state.over || position.isGameOver())) return state.result;
	if (position.isGameOver()) return resultText(position);
	if (state.mode === "play" && state.cursor < state.fens.length - 1) return "Browsing the game";
	if (state.thinking) return "Halden is thinking";
	if (state.mode === "play" && position.turn() === state.player) return opening ? `Your move · ${opening}` : "Your move";
	if (state.mode === "play") return "Halden to move";
	return position.turn() === "w" ? "White to move" : "Black to move";
}
function resultText(position) {
	if (position.isCheckmate()) return position.turn() === "w" ? "Checkmate · Black wins" : "Checkmate · White wins";
	if (position.isStalemate()) return "Stalemate · draw";
	if (position.isDraw()) return "Draw";
	return "Game over";
}
function labelMark(mark) {
	if (mark === "best") return "Best";
	if (mark === "excellent") return "Excellent";
	if (mark === "good") return "Good";
	if (mark === "inaccuracy") return "Inaccuracy";
	if (mark === "mistake") return "Mistake";
	return "Blunder";
}
function lastSquares(fens, sans, cursor) {
	if (cursor <= 0) return null;
	try {
		const move = new Chess(fens[cursor - 1]).move(sans[cursor - 1]);
		return {
			from: move.from,
			to: move.to
		};
	} catch {
		return null;
	}
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
