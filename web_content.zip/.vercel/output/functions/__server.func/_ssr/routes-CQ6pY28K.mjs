import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CQ6pY28K.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "fixed inset-0 bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-5 py-6 text-sm text-muted",
			children: "Memuat Kris Soundboard…"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			title: "Kris Soundboard",
			src: "/board.html",
			className: "absolute inset-0 h-full w-full border-0 bg-bg"
		})]
	});
}
//#endregion
export { Home as component };
