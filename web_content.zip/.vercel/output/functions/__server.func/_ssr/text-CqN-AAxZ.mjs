//#region node_modules/.nitro/vite/services/ssr/assets/text-CqN-AAxZ.js
function norm(value) {
	return value.trim().toLowerCase().normalize("NFD").replace(/\p{M}/gu, "");
}
function sameName(a, b) {
	const left = norm(a);
	const right = norm(b);
	return left.length > 0 && left === right;
}
function clamp(value, min, max) {
	return Math.min(max, Math.max(min, value));
}
function uid() {
	return crypto.randomUUID();
}
function formatClock(clock) {
	const hour = Math.floor(clock.minute / 60);
	const minute = clock.minute % 60;
	const hh = String(hour).padStart(2, "0");
	const mm = String(minute).padStart(2, "0");
	const label = clock.label.trim();
	return `Día ${clock.day} · ${hh}:${mm}${label ? ` · ${label}` : ""}`;
}
function opinionLabel(value) {
	if (value <= -4) return "Hostil";
	if (value <= -2) return "Frío";
	if (value === -1) return "Cauteloso";
	if (value === 0) return "Neutro";
	if (value === 1) return "Atento";
	if (value <= 3) return "Cercano";
	return "Leal";
}
function clip(value, max) {
	const text = value.trim();
	if (text.length <= max) return text;
	return `${text.slice(0, max - 1).trimEnd()}…`;
}
//#endregion
export { opinionLabel as a, norm as i, clip as n, sameName as o, formatClock as r, uid as s, clamp as t };
