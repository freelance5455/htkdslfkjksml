import { r as isLoginRequired, t as isConnectorPending } from "./login-BxQ-E10E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/normalize-6SyGCqa5.js
var MESSAGE_RULES = [
	{
		needles: ["not_connected", "failed_precondition"],
		kind: "not_connected",
		message: "Connect this connector in Grok to load your data."
	},
	{
		needles: ["scope_denied"],
		kind: "scope_denied",
		message: "This view isn't available — the app requested a tool outside its grant."
	},
	{
		needles: ["access_denied"],
		kind: "access_denied",
		message: "You don't have access to this data."
	}
];
function matchMessageRule(raw) {
	return MESSAGE_RULES.find((rule) => rule.needles.some((needle) => raw.includes(needle)));
}
function classifyCallToolError(result) {
	if (result.ok) return null;
	const detail = result.errorMessage || void 0;
	const raw = (result.errorMessage ?? "").toLowerCase();
	if (isConnectorPending(result)) return {
		kind: "pending",
		message: "Connecting to your data…",
		detail
	};
	if (raw.includes("missing_connector_token")) return {
		kind: "error",
		message: "Open this app from Grok to load your data.",
		detail
	};
	if (isLoginRequired(result)) return {
		kind: "login",
		message: "Continue with Grok to load your data.",
		detail
	};
	const rule = matchMessageRule(raw);
	if (rule) return {
		kind: rule.kind,
		message: rule.message,
		detail
	};
	return {
		kind: "error",
		message: detail ?? "Something went wrong. Try again.",
		detail
	};
}
function isRecord(value) {
	return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function asRecordArray(data) {
	if (Array.isArray(data)) return data.filter(isRecord);
	if (!isRecord(data)) return [];
	for (const key of [
		"files",
		"messages",
		"events",
		"items",
		"results",
		"threads",
		"calendars",
		"data",
		"value"
	]) {
		const nested = data[key];
		if (Array.isArray(nested)) return nested.filter(isRecord);
	}
	return [data];
}
function firstString(item, keys) {
	for (const key of keys) {
		const value = item[key];
		if (typeof value === "string" && value.trim()) return value.trim();
		if (typeof value === "number") return String(value);
	}
}
function titleOf(item) {
	return firstString(item, [
		"name",
		"title",
		"subject",
		"summary",
		"filename",
		"snippet",
		"displayName",
		"display_name"
	]) ?? "Untitled";
}
function idOf(item) {
	return firstString(item, [
		"id",
		"fileId",
		"file_id",
		"eventId",
		"event_id",
		"messageId",
		"message_id",
		"threadId"
	]);
}
function subtitleOf(item) {
	return firstString(item, [
		"from",
		"sender",
		"organizer",
		"mimeType",
		"mime_type",
		"start",
		"startTime",
		"start_time",
		"modifiedTime",
		"modified_time",
		"snippet",
		"description",
		"location",
		"owners"
	]);
}
function flattenTime(value) {
	if (typeof value === "string") return value;
	if (isRecord(value)) return firstString(value, [
		"dateTime",
		"date",
		"date_time"
	]);
}
function toLibraryItem(item) {
	const start = flattenTime(item.start) ?? flattenTime(item.startTime);
	const from = firstString(item, ["from", "sender"]) ?? (isRecord(item.from) ? firstString(item.from, ["email", "name"]) : void 0);
	const mime = firstString(item, ["mimeType", "mime_type"]);
	const subtitle = from ?? start ?? mime ?? subtitleOf(item);
	return {
		id: idOf(item) ?? titleOf(item),
		title: titleOf(item),
		subtitle,
		extra: start ?? from
	};
}
function truncate(text, max = 12e3) {
	if (text.length <= max) return text;
	return `${text.slice(0, max)}\n\n[truncated]`;
}
function stringifyToolData(data) {
	try {
		return truncate(JSON.stringify(data, null, 2), 14e3);
	} catch {
		return String(data);
	}
}
//#endregion
export { subtitleOf as a, stringifyToolData as i, classifyCallToolError as n, titleOf as o, idOf as r, toLibraryItem as s, asRecordArray as t };
