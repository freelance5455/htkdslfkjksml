import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as utf8Bytes, i as shouldSkipZipPath, n as PYTHON_LOAD_TIMEOUT_MS, r as RUN_TIMEOUT_MS, t as AI_MAX_CODE_CHARS } from "./limits-CuuT0Tt_.mjs";
import { a as string, i as object, t as _enum } from "../_libs/zod.mjs";
import { A as Eraser, C as Image, D as FilePlus, E as FolderOpen, F as ChevronLeft, I as Check, M as Copy, O as FileCode2, P as ClipboardPaste, S as Maximize2, T as FolderPlus, _ as Play, a as Tablet, b as Minus, c as Smartphone, d as Scissors, f as RotateCcw, g as Plus, h as Redo2, i as Trash2, j as Ellipsis, k as Eye, l as Settings, m as RefreshCw, n as Undo2, o as SquareCheckBig, s as Sparkles, t as Upload, u as Search, v as Pencil, w as Folder, x as Minimize2, y as Monitor } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as createId, c as parentPath, i as cn, n as NijoMark, o as extOf, r as baseName, s as joinPath, t as Button } from "./button-ryli-Zjw.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
import { t as require_js } from "../_libs/js-beautify.mjs";
import { A as indentOnInput, C as foldGutter, J as highlightActiveLineGutter, U as EditorView, X as lineNumbers, Y as keymap, Z as placeholder, _ as bracketMatching, g as StreamLanguage, i as closeBracketsKeymap, n as autocompletion, o as completionKeymap, q as highlightActiveLine, r as closeBrackets, st as EditorState } from "../_libs/@codemirror/autocomplete+[...].mjs";
import { t as cpp } from "../_libs/@codemirror/lang-cpp+[...].mjs";
import { r as javascript, t as html$1 } from "../_libs/@codemirror/lang-html+[...].mjs";
import { t as css$1 } from "../_libs/@codemirror/lang-css+[...].mjs";
import { t as python } from "../_libs/@codemirror/lang-python+[...].mjs";
import { t as json } from "../_libs/@codemirror/lang-json+[...].mjs";
import { t as markdown } from "../_libs/@codemirror/lang-markdown+[...].mjs";
import { t as xml } from "../_libs/@codemirror/lang-xml+[...].mjs";
import { t as sql } from "../_libs/codemirror__lang-sql.mjs";
import { t as php } from "../_libs/@codemirror/lang-php+[...].mjs";
import { t as java } from "../_libs/@codemirror/lang-java+[...].mjs";
import { t as rust } from "../_libs/@codemirror/lang-rust+[...].mjs";
import { t as go } from "../_libs/codemirror__lang-go+lezer__go.mjs";
import { a as c, c as kotlin, i as swift, n as lua, o as csharp, r as ruby, s as dart, t as r } from "../_libs/codemirror__legacy-modes.mjs";
import { t as purify_default } from "../_libs/dompurify.mjs";
import { t as k } from "../_libs/marked.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as require_lib } from "../_libs/jszip+[...].mjs";
import { a as redo, i as indentWithTab, n as history, o as undo, r as historyKeymap, t as defaultKeymap } from "../_libs/codemirror__commands.mjs";
import { n as searchKeymap, t as highlightSelectionMatches } from "../_libs/codemirror__search.mjs";
import { t as oneDark } from "../_libs/codemirror__theme-one-dark.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workspace-app-DidRAp3I.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_js = require_js();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	ref,
	className: cn("flex h-11 w-full rounded-md bg-surface px-3 text-base text-fg shadow-nijo outline-none placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-primary/70", className),
	...props
}));
Input.displayName = "Input";
function Sheet({ open, onOpenChange, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
		open,
		onOpenChange,
		shouldScaleBackground: false,
		children
	});
}
function SheetContent({ children, className, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-50 bg-black/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
		className: cn("fixed inset-x-0 bottom-0 z-50 flex max-h-[88dvh] flex-col rounded-t-xl bg-elevated pb-[env(safe-area-inset-bottom)] text-fg shadow-nijo outline-none", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-2 h-1 w-10 rounded-full bg-border-strong" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
				className: "px-5 pb-2 pt-4 text-base font-medium tracking-tight",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-5 pb-5",
				children
			})
		]
	})] });
}
function formatCode(code, language) {
	const options = {
		indent_size: 2,
		preserve_newlines: true,
		max_preserve_newlines: 2
	};
	try {
		switch (language) {
			case "html":
			case "svg":
			case "xml":
			case "vue":
			case "svelte": return (0, import_js.html)(code, options);
			case "css": return (0, import_js.css)(code, options);
			case "javascript":
			case "typescript":
			case "react":
			case "react-native": return (0, import_js.js)(code, options);
			case "json": return JSON.stringify(JSON.parse(code), null, 2);
			default: return code;
		}
	} catch {
		return code;
	}
}
var LANGUAGES = [
	{
		id: "auto",
		label: "Auto Detect",
		group: "Other",
		extensions: [],
		output: "unavailable"
	},
	{
		id: "html",
		label: "HTML",
		group: "Web",
		extensions: ["html", "htm"],
		output: "preview"
	},
	{
		id: "css",
		label: "CSS",
		group: "Web",
		extensions: ["css"],
		output: "preview"
	},
	{
		id: "javascript",
		label: "JavaScript",
		group: "Web",
		extensions: [
			"js",
			"mjs",
			"cjs"
		],
		output: "console"
	},
	{
		id: "typescript",
		label: "TypeScript",
		group: "Web",
		extensions: ["ts", "mts"],
		output: "console"
	},
	{
		id: "react",
		label: "React",
		group: "Web",
		extensions: ["jsx", "tsx"],
		output: "unavailable",
		unavailableReason: "React needs a bundler. Use HTML + JavaScript for in-browser preview."
	},
	{
		id: "vue",
		label: "Vue",
		group: "Web",
		extensions: ["vue"],
		output: "unavailable",
		unavailableReason: "Vue single-file components cannot run in this browser sandbox."
	},
	{
		id: "svelte",
		label: "Svelte",
		group: "Web",
		extensions: ["svelte"],
		output: "unavailable",
		unavailableReason: "Svelte requires a compiler that is not available here."
	},
	{
		id: "dart",
		label: "Dart",
		group: "Mobile",
		extensions: ["dart"],
		output: "unavailable",
		unavailableReason: "Dart VM is not available in this browser."
	},
	{
		id: "flutter",
		label: "Flutter",
		group: "Mobile",
		extensions: ["dart"],
		output: "unavailable",
		unavailableReason: "Flutter SDK is not available in this browser."
	},
	{
		id: "kotlin",
		label: "Kotlin",
		group: "Mobile",
		extensions: ["kt", "kts"],
		output: "unavailable",
		unavailableReason: "Kotlin compiler is not available in this browser."
	},
	{
		id: "java",
		label: "Java",
		group: "Mobile",
		extensions: ["java"],
		output: "unavailable",
		unavailableReason: "Java runtime is not available in this browser."
	},
	{
		id: "swift",
		label: "Swift",
		group: "Mobile",
		extensions: ["swift"],
		output: "unavailable",
		unavailableReason: "Swift compiler is not available in this browser."
	},
	{
		id: "react-native",
		label: "React Native",
		group: "Mobile",
		extensions: ["jsx", "tsx"],
		output: "unavailable",
		unavailableReason: "React Native cannot run inside a mobile browser sandbox."
	},
	{
		id: "python",
		label: "Python",
		group: "General",
		extensions: ["py"],
		output: "console"
	},
	{
		id: "c",
		label: "C",
		group: "General",
		extensions: ["c", "h"],
		output: "unavailable",
		unavailableReason: "A C compiler is not available in this browser."
	},
	{
		id: "cpp",
		label: "C++",
		group: "General",
		extensions: [
			"cpp",
			"cc",
			"cxx",
			"hpp"
		],
		output: "unavailable",
		unavailableReason: "A C++ compiler is not available in this browser."
	},
	{
		id: "csharp",
		label: "C#",
		group: "General",
		extensions: ["cs"],
		output: "unavailable",
		unavailableReason: ".NET runtime is not available in this browser."
	},
	{
		id: "go",
		label: "Go",
		group: "General",
		extensions: ["go"],
		output: "unavailable",
		unavailableReason: "Go toolchain is not available in this browser."
	},
	{
		id: "rust",
		label: "Rust",
		group: "General",
		extensions: ["rs"],
		output: "unavailable",
		unavailableReason: "Rust compiler is not available in this browser."
	},
	{
		id: "ruby",
		label: "Ruby",
		group: "General",
		extensions: ["rb"],
		output: "unavailable",
		unavailableReason: "Ruby interpreter is not available in this browser."
	},
	{
		id: "php",
		label: "PHP",
		group: "General",
		extensions: ["php"],
		output: "unavailable",
		unavailableReason: "PHP runtime is not available in this browser."
	},
	{
		id: "lua",
		label: "Lua",
		group: "General",
		extensions: ["lua"],
		output: "unavailable",
		unavailableReason: "Lua runtime is not available in this browser."
	},
	{
		id: "r",
		label: "R",
		group: "General",
		extensions: ["r"],
		output: "unavailable",
		unavailableReason: "R runtime is not available in this browser."
	},
	{
		id: "sql",
		label: "SQL",
		group: "Data",
		extensions: ["sql"],
		output: "formatted"
	},
	{
		id: "json",
		label: "JSON",
		group: "Data",
		extensions: ["json"],
		output: "formatted"
	},
	{
		id: "xml",
		label: "XML",
		group: "Data",
		extensions: ["xml"],
		output: "formatted"
	},
	{
		id: "markdown",
		label: "Markdown",
		group: "Data",
		extensions: ["md", "markdown"],
		output: "markdown"
	},
	{
		id: "svg",
		label: "SVG",
		group: "Data",
		extensions: ["svg"],
		output: "svg"
	},
	{
		id: "plaintext",
		label: "Plain text",
		group: "Other",
		extensions: ["txt"],
		output: "unavailable"
	},
	{
		id: "image",
		label: "Image",
		group: "Other",
		extensions: [
			"png",
			"jpg",
			"jpeg",
			"gif",
			"webp"
		],
		output: "image"
	}
];
var OPEN_ACCEPT = [
	".html",
	".htm",
	".css",
	".js",
	".ts",
	".jsx",
	".tsx",
	".py",
	".dart",
	".java",
	".kt",
	".c",
	".cpp",
	".h",
	".cs",
	".php",
	".rb",
	".go",
	".rs",
	".swift",
	".json",
	".xml",
	".md",
	".svg",
	".vue",
	".svelte",
	".sql",
	".lua",
	".txt",
	".zip"
].join(",");
var EXT_MAP = {};
for (const lang of LANGUAGES) {
	if (lang.id === "auto" || lang.id === "flutter" || lang.id === "react-native") continue;
	for (const ext of lang.extensions) if (!EXT_MAP[ext]) EXT_MAP[ext] = lang.id;
}
function languageById(id) {
	return LANGUAGES.find((l) => l.id === id) ?? LANGUAGES[LANGUAGES.length - 2];
}
function languageFromExtension(path) {
	return EXT_MAP[extOf(path)] ?? "plaintext";
}
function languageExtension(id) {
	switch (id) {
		case "html": return [html$1()];
		case "css": return [css$1()];
		case "javascript":
		case "vue":
		case "svelte": return [javascript()];
		case "typescript": return [javascript({ typescript: true })];
		case "react":
		case "react-native": return [javascript({
			jsx: true,
			typescript: true
		})];
		case "python": return [python()];
		case "json": return [json()];
		case "markdown": return [markdown()];
		case "xml":
		case "svg": return [xml()];
		case "sql": return [sql()];
		case "php": return [php()];
		case "java": return [java()];
		case "cpp": return [cpp()];
		case "c": return [StreamLanguage.define(c)];
		case "rust": return [rust()];
		case "go": return [go()];
		case "dart":
		case "flutter": return [StreamLanguage.define(dart)];
		case "kotlin": return [StreamLanguage.define(kotlin)];
		case "csharp": return [StreamLanguage.define(csharp)];
		case "swift": return [StreamLanguage.define(swift)];
		case "ruby": return [StreamLanguage.define(ruby)];
		case "lua": return [StreamLanguage.define(lua)];
		case "r": return [StreamLanguage.define(r)];
		default: return [];
	}
}
function groupedLanguages() {
	return [
		"Web",
		"Mobile",
		"General",
		"Data",
		"Other"
	].map((group) => ({
		group,
		items: LANGUAGES.filter((l) => l.group === group && l.id !== "image")
	})).filter((g) => g.items.length > 0);
}
function has(code, re) {
	return re.test(code);
}
function detectLanguage(code, path) {
	const fromPath = path ? languageFromExtension(path) : "plaintext";
	if (path && fromPath !== "plaintext" && fromPath !== "image") return fromPath;
	const text = code.slice(0, 12e3).trim();
	if (!text) return fromPath === "plaintext" ? "javascript" : fromPath;
	const signals = [];
	if (/^\s*</.test(text) && /<!doctype html|<html[\s>]|<body[\s>]/i.test(text)) signals.push({
		id: "html",
		score: 10
	});
	if (/^\s*<svg[\s>]/i.test(text) || /xmlns="http:\/\/www\.w3\.org\/2000\/svg"/i.test(text)) signals.push({
		id: "svg",
		score: 12
	});
	if (/^\s*<\?xml/.test(text) || /^\s*</.test(text) && /<\/[a-zA-Z0-9:_-]+>\s*$/.test(text) && !/<html/i.test(text)) signals.push({
		id: "xml",
		score: 6
	});
	if (/^\s*[{[]/.test(text)) try {
		JSON.parse(text);
		signals.push({
			id: "json",
			score: 11
		});
	} catch {}
	if (has(text, /<\?php/i)) signals.push({
		id: "php",
		score: 12
	});
	if (has(text, /\b(def|import|from|print|elif|None|True|False)\b/) && has(text, /:\s*$/m)) signals.push({
		id: "python",
		score: 8
	});
	if (has(text, /\bfn\s+main\b|\blet\s+mut\b|\bimpl\s+|println!/)) signals.push({
		id: "rust",
		score: 10
	});
	if (has(text, /\bpackage\s+main\b|\bfunc\s+\w+\s*\(/)) signals.push({
		id: "go",
		score: 9
	});
	if (has(text, /\bStatelessWidget\b|\bStatefulWidget\b|\bWidget\s+build\(/)) signals.push({
		id: "flutter",
		score: 11
	});
	if (has(text, /\bvoid\s+main\s*\(\s*\)/) && has(text, /\b(dart|print)\b/)) signals.push({
		id: "dart",
		score: 8
	});
	if (has(text, /\bfun\s+\w+\s*\(|\bval\s+\w+\s*[:=]|\bcompanion object\b/)) signals.push({
		id: "kotlin",
		score: 9
	});
	if (has(text, /\bpublic\s+class\s+\w+|\bSystem\.out\.println/)) signals.push({
		id: "java",
		score: 8
	});
	if (has(text, /\bimport\s+UIKit|\bfunc\s+\w+\s*\([^)]*\)\s*\{|\bvar\s+\w+\s*:\s*\w+/)) signals.push({
		id: "swift",
		score: 7
	});
	if (has(text, /\busing\s+System\b|\bnamespace\s+\w+|Console\.WriteLine/)) signals.push({
		id: "csharp",
		score: 9
	});
	if (has(text, /\bSELECT\b[\s\S]*\bFROM\b/i) && !has(text, /function|const |let /)) signals.push({
		id: "sql",
		score: 8
	});
	if (has(text, /^#\s.+/m) && has(text, /^\s*[-*]\s/m) && !has(text, /<html/i)) signals.push({
		id: "markdown",
		score: 6
	});
	if (has(text, /\{[^}]*:[^}]*;/) && has(text, /[.#]?[a-zA-Z][\w-]*\s*\{/)) signals.push({
		id: "css",
		score: 7
	});
	if (has(text, /\b(interface|type)\s+\w+\s*[=<{]/) || has(text, /:\s*(string|number|boolean|void)\b/)) signals.push({
		id: "typescript",
		score: 8
	});
	if (has(text, /\b(function|const|let|var|=>|export |import )\b/)) signals.push({
		id: "javascript",
		score: 5
	});
	if (has(text, /\b(include|require)\b/) && has(text, /\bend\b/)) signals.push({
		id: "ruby",
		score: 5
	});
	if (has(text, /\b#include\s*<.*>/) && has(text, /\bint\s+main\s*\(/)) signals.push({
		id: has(text, /\bstd::|cout\s*<</) ? "cpp" : "c",
		score: 9
	});
	signals.sort((a, b) => b.score - a.score);
	return signals[0]?.id ?? (fromPath === "plaintext" ? "javascript" : fromPath);
}
function resolveFileLanguage(language, content, path) {
	if (language !== "auto") return language;
	return detectLanguage(content, path);
}
var SAMPLE_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>NIJO Demo</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <main class="wrap">
    <p class="eyebrow">NIJO MOBILE</p>
    <h1>Hello World</h1>
    <p class="lede">Code anywhere. Build anywhere.</p>
    <button id="go" type="button">Run a line of JS</button>
    <p id="out" class="out"></p>
  </main>
  <script src="script.js"><\/script>
</body>
</html>
`;
var SAMPLE_CSS = `:root {
  color-scheme: dark;
  --ink: #eef1f6;
  --muted: #9aa3b5;
  --accent: #4d8dff;
  --bg: #0b0d12;
}

* { box-sizing: border-box; }

html, body {
  margin: 0;
  min-height: 100%;
  font-family: ui-sans-serif, system-ui, sans-serif;
  background: radial-gradient(1200px 600px at 10% -10%, #152036, var(--bg));
  color: var(--ink);
}

.wrap {
  max-width: 28rem;
  margin: 0 auto;
  padding: 3rem 1.5rem;
}

.eyebrow {
  letter-spacing: 0.18em;
  text-transform: uppercase;
  font-size: 0.7rem;
  color: var(--accent);
  margin: 0 0 0.75rem;
}

h1 {
  font-size: 2.4rem;
  letter-spacing: -0.04em;
  margin: 0 0 0.5rem;
}

.lede {
  color: var(--muted);
  margin: 0 0 1.5rem;
}

button {
  appearance: none;
  border: 0;
  border-radius: 999px;
  padding: 0.8rem 1.2rem;
  background: var(--accent);
  color: #06101e;
  font-weight: 600;
  font-size: 0.95rem;
}

.out {
  min-height: 1.4em;
  margin-top: 1rem;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  color: #9ad7b5;
}
`;
var SAMPLE_JS = `const button = document.getElementById("go");
const out = document.getElementById("out");

button?.addEventListener("click", () => {
  const total = 75 + 75;
  out.textContent = "Total: " + total;
  console.log("Hello World");
  console.log("Total:", total);
});

console.log("NIJO preview ready");
`;
function createSampleFiles() {
	return [
		{
			id: createId(),
			path: "index.html",
			content: SAMPLE_HTML,
			language: "html"
		},
		{
			id: createId(),
			path: "style.css",
			content: SAMPLE_CSS,
			language: "css"
		},
		{
			id: createId(),
			path: "script.js",
			content: SAMPLE_JS,
			language: "javascript"
		}
	];
}
var STORAGE_KEY = "nijo-mobile-v1";
var defaultSettings = {
	fontSize: 16,
	theme: "dark",
	wrap: true,
	tabSize: 2
};
var saveTimer = null;
function persistSlice(state) {
	if (typeof window === "undefined") return;
	if (saveTimer) clearTimeout(saveTimer);
	saveTimer = setTimeout(() => {
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify({
				projectName: state.projectName,
				files: state.files,
				folders: state.folders,
				activeFileId: state.activeFileId,
				settings: state.settings,
				currentDir: state.currentDir
			}));
		} catch {}
	}, 280);
}
function projectBytes(files) {
	return files.reduce((sum, file) => sum + utf8Bytes(file.content), 0);
}
function canFit(files, extra) {
	if (files.length >= 80) return "Project file limit reached.";
	if (utf8Bytes(extra) > 15e5) return "That file is too large for NIJO MOBILE.";
	if (projectBytes(files) + utf8Bytes(extra) > 4e6) return "This project is over the storage limit.";
	return null;
}
function sampleState() {
	const files = createSampleFiles();
	return {
		projectName: "My Project",
		files,
		folders: [],
		activeFileId: files[0]?.id ?? null,
		settings: defaultSettings,
		currentDir: ""
	};
}
var useProjectStore = create((set, get) => ({
	...sampleState(),
	hydrated: false,
	tab: "editor",
	previewDevice: "mobile",
	consoleLines: [],
	run: {
		mode: "preview",
		status: "idle"
	},
	fullscreen: false,
	findOpen: false,
	editorViewVersion: 0,
	hydrate: () => {
		if (get().hydrated) return;
		let next = sampleState();
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (Array.isArray(parsed.files) && parsed.files.length > 0) next = {
					projectName: parsed.projectName || "My Project",
					files: parsed.files,
					folders: parsed.folders ?? [],
					activeFileId: parsed.activeFileId ?? parsed.files[0]?.id ?? null,
					settings: {
						...defaultSettings,
						...parsed.settings
					},
					currentDir: parsed.currentDir ?? ""
				};
			}
		} catch {}
		set({
			...next,
			hydrated: true
		});
		queueMicrotask(() => get().applyTheme());
	},
	setTab: (tab) => set({
		tab,
		fullscreen: tab === "editor" ? get().fullscreen : false
	}),
	setDevice: (previewDevice) => set({ previewDevice }),
	setFullscreen: (fullscreen) => set({ fullscreen }),
	setFindOpen: (findOpen) => set({ findOpen }),
	bumpEditor: () => set({ editorViewVersion: get().editorViewVersion + 1 }),
	setActiveFile: (id) => set({
		activeFileId: id,
		tab: "editor"
	}),
	setCurrentDir: (currentDir) => set({ currentDir }),
	updateContent: (id, content) => {
		set({ files: get().files.map((file) => file.id === id ? {
			...file,
			content
		} : file) });
		persistSlice(get());
	},
	setLanguage: (id, language) => {
		set({ files: get().files.map((file) => file.id === id ? {
			...file,
			language
		} : file) });
		persistSlice(get());
	},
	autoDetectActive: () => {
		const { files, activeFileId } = get();
		const file = files.find((f) => f.id === activeFileId);
		if (!file) return "javascript";
		const detected = detectLanguage(file.content, file.path);
		set({ files: files.map((f) => f.id === file.id ? {
			...f,
			language: detected
		} : f) });
		persistSlice(get());
		return detected;
	},
	createFile: (name, content = "", language) => {
		const trimmed = name.trim().replace(/^\/+/, "");
		if (!trimmed) return "Enter a file name.";
		const path = joinPath(get().currentDir, trimmed);
		if (get().files.some((f) => f.path === path)) return "A file with that name already exists.";
		const error = canFit(get().files, content);
		if (error) return error;
		const lang = language ?? languageFromExtension(path);
		const file = {
			id: createId(),
			path,
			content,
			language: lang === "plaintext" ? "javascript" : lang
		};
		set({
			files: [...get().files, file],
			activeFileId: file.id,
			tab: "editor"
		});
		persistSlice(get());
		return null;
	},
	createFolder: (name) => {
		const trimmed = name.trim().replace(/^\/+|\/+$/g, "");
		if (!trimmed) return "Enter a folder name.";
		const path = joinPath(get().currentDir, trimmed);
		if (get().folders.includes(path) || get().files.some((f) => f.path === path)) return "That folder already exists.";
		set({
			folders: [...get().folders, path],
			currentDir: path
		});
		persistSlice(get());
		return null;
	},
	renameNode: (path, nextName, isFolder) => {
		const name = nextName.trim();
		if (!name) return;
		const nextPath = joinPath(parentPath(path), name);
		if (isFolder) set({
			folders: get().folders.map((folder) => folder === path || folder.startsWith(path + "/") ? nextPath + folder.slice(path.length) : folder),
			files: get().files.map((file) => file.path === path || file.path.startsWith(path + "/") ? {
				...file,
				path: nextPath + file.path.slice(path.length)
			} : file),
			currentDir: get().currentDir === path ? nextPath : get().currentDir
		});
		else set({ files: get().files.map((file) => file.path === path ? {
			...file,
			path: nextPath,
			language: languageFromExtension(nextPath)
		} : file) });
		persistSlice(get());
	},
	deleteNode: (path, isFolder) => {
		if (isFolder) {
			const files = get().files.filter((file) => file.path !== path && !file.path.startsWith(path + "/"));
			set({
				files,
				folders: get().folders.filter((folder) => folder !== path && !folder.startsWith(path + "/")),
				activeFileId: (files.find((f) => f.id === get().activeFileId) ?? files[0])?.id ?? null,
				currentDir: get().currentDir === path ? parentPath(path) : get().currentDir
			});
		} else {
			const files = get().files.filter((file) => file.path !== path);
			set({
				files,
				activeFileId: (files.find((f) => f.id === get().activeFileId) ?? files[0])?.id ?? null
			});
		}
		persistSlice(get());
	},
	replaceProject: (name, files, folders) => {
		if (files.length === 0) return "No files found in that project.";
		if (files.length > 80) return "Too many files in this ZIP.";
		if (projectBytes(files) > 4e6) return "Project is too large to open on this device.";
		const html = files.find((f) => f.path.endsWith(".html") || f.path.endsWith(".htm"));
		set({
			projectName: name || "My Project",
			files,
			folders,
			activeFileId: html?.id ?? files[0]?.id ?? null,
			currentDir: "",
			tab: "files",
			consoleLines: [],
			run: {
				mode: "preview",
				status: "idle"
			}
		});
		persistSlice(get());
		return null;
	},
	openLocalText: (filename, content) => {
		const error = canFit(get().files.filter((f) => f.path !== joinPath(get().currentDir, filename)), content);
		if (error) return error;
		const path = joinPath(get().currentDir, baseName(filename));
		const language = detectLanguage(content, path);
		const existing = get().files.find((f) => f.path === path);
		const file = existing ? {
			...existing,
			content,
			language
		} : {
			id: createId(),
			path,
			content,
			language
		};
		set({
			files: existing ? get().files.map((f) => f.id === existing.id ? file : f) : [...get().files, file],
			activeFileId: file.id,
			tab: "editor"
		});
		persistSlice(get());
		return null;
	},
	setSettings: (patch) => {
		set({ settings: {
			...get().settings,
			...patch
		} });
		persistSlice(get());
		if (patch.theme) queueMicrotask(() => get().applyTheme());
	},
	applyTheme: () => {
		if (typeof document === "undefined") return;
		document.documentElement.classList.toggle("light", get().settings.theme === "light");
	},
	appendConsole: (line) => {
		const entry = {
			...line,
			id: createId(),
			ts: Date.now()
		};
		set({ consoleLines: [...get().consoleLines, entry].slice(-200) });
	},
	clearConsole: () => set({ consoleLines: [] }),
	setRun: (run) => set({ run }),
	resetProject: () => {
		set({
			...sampleState(),
			consoleLines: [],
			run: {
				mode: "preview",
				status: "idle"
			},
			tab: "editor",
			currentDir: ""
		});
		persistSlice(get());
	}
}));
function getActiveFile() {
	const { files, activeFileId } = useProjectStore.getState();
	return files.find((f) => f.id === activeFileId);
}
function resolvedLanguage(file) {
	if (!file) return "javascript";
	return resolveFileLanguage(file.language, file.content, file.path);
}
var BRIDGE = `<script>
(function(){
  if (window.__nijo) return;
  window.__nijo = true;
  function send(type, payload){
    try { parent.postMessage(Object.assign({ source: "nijo-preview", type: type }, payload), "*"); }
    catch (e) {}
  }
  function fmt(v){
    if (typeof v === "string") return v;
    if (v instanceof Error) return v.stack || v.message;
    try { return JSON.stringify(v); } catch (e) { return String(v); }
  }
  ["log","info","warn","error"].forEach(function(level){
    var orig = console[level] ? console[level].bind(console) : function(){};
    console[level] = function(){
      var text = Array.prototype.slice.call(arguments).map(fmt).join(" ");
      send("console", { level: level, text: text });
      orig.apply(console, arguments);
    };
  });
  window.addEventListener("error", function(ev){
    send("console", { level: "error", text: ev.message, meta: ev.lineno ? ("Line " + ev.lineno) : undefined });
  });
  window.addEventListener("unhandledrejection", function(ev){
    send("console", { level: "error", text: String(ev.reason) });
  });
  send("ready", {});
})();
<\/script>`;
function escapeScript(code) {
	return code.replace(/<\/script/gi, "<\\/script");
}
function findByRef(files, href, fromPath) {
	const cleaned = href.split("?")[0]?.split("#")[0] ?? href;
	const fromDir = fromPath.includes("/") ? fromPath.slice(0, fromPath.lastIndexOf("/") + 1) : "";
	const candidates = [
		cleaned.replace(/^\.\//, ""),
		fromDir + cleaned.replace(/^\.\//, ""),
		cleaned.replace(/^\//, "")
	];
	return files.find((f) => candidates.includes(f.path) || f.path.endsWith("/" + cleaned) || f.path === cleaned);
}
function buildWebDocument(files, entry) {
	let html = entry.content;
	if (!/<html/i.test(html)) html = `<!DOCTYPE html><html><head><meta charset="utf-8"/></head><body>${html}</body></html>`;
	html = html.replace(/<link([^>]*?)href=["']([^"']+)["']([^>]*)>/gi, (full, pre, href, post) => {
		if (!/stylesheet/i.test(pre + post) && !href.endsWith(".css")) return full;
		const file = findByRef(files, href, entry.path);
		if (!file) return full;
		return `<style>\n${file.content}\n</style>`;
	});
	html = html.replace(/<script([^>]*?)src=["']([^"']+)["']([^>]*)><\/script>/gi, (full, pre, src) => {
		const file = findByRef(files, src, entry.path);
		if (!file) return full;
		return `<script${pre}>\n${escapeScript(file.content)}\n<\/script>`;
	});
	html = html.replace(/<(img|image)([^>]*?)src=["']([^"']+)["']/gi, (full, tag, pre, src) => {
		if (src.startsWith("data:") || src.startsWith("http")) return full;
		const file = findByRef(files, src, entry.path);
		if (!file) return full;
		return `<${tag}${pre}src="${file.content}"`;
	});
	if (/<head[\s>]/i.test(html)) html = html.replace(/<head([^>]*)>/i, `<head$1>${BRIDGE}`);
	else html = BRIDGE + html;
	return html;
}
function wrapCssPreview(css) {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"/>${BRIDGE}<style>
html,body{margin:0;min-height:100%;font-family:ui-sans-serif,system-ui;background:#0b0d12;color:#eef1f6}
.preview-note{padding:24px;max-width:28rem}
${css}
</style></head><body>
<main class="preview-note">
  <h1>CSS preview</h1>
  <p>Your stylesheet is applied to this page.</p>
  <button type="button">Sample button</button>
</main>
</body></html>`;
}
function wrapJsConsole(code) {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"/>${BRIDGE}</head><body>
<script>
try {
${escapeScript(code)}
  parent.postMessage({ source: "nijo-preview", type: "done" }, "*");
} catch (err) {
  parent.postMessage({ source: "nijo-preview", type: "console", level: "error", text: err && err.message ? err.message : String(err), meta: "Runtime error" }, "*");
  parent.postMessage({ source: "nijo-preview", type: "done" }, "*");
}
<\/script>
</body></html>`;
}
function stripTs(code) {
	return code.replace(/^\s*import\s+[\s\S]*?from\s+["'][^"']+["'];?/gm, "").replace(/^\s*export\s+\{[\s\S]*?\};?/gm, "").replace(/\bexport\s+default\s+/g, "").replace(/\bexport\s+/g, "").replace(/:\s*[A-Za-z_][\w.<>,\s|&[\]']*(?=[,)=;{])/g, "").replace(/\bas\s+[A-Za-z_][\w.]*/g, "").replace(/interface\s+\w+\s*\{[\s\S]*?\}\s*/g, "").replace(/type\s+\w+\s*=\s*[^;]+;?/g, "");
}
async function renderMarkdown(code) {
	const raw = await k.parse(code, {
		async: true,
		gfm: true
	});
	return `<!DOCTYPE html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
  html,body{margin:0;background:#0b0d12;color:#eef1f6;font-family:ui-sans-serif,system-ui;line-height:1.6}
  main{padding:20px 18px 48px;max-width:40rem;margin:0 auto}
  a{color:#4d8dff}
  pre,code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:0.9em}
  pre{background:#161a22;padding:12px;border-radius:12px;overflow:auto}
  img{max-width:100%;border-radius:12px}
  h1,h2,h3{letter-spacing:-0.03em}
</style></head><body><main>${purify_default.sanitize(raw, { USE_PROFILES: { html: true } })}</main></body></html>`;
}
function formattedView(title, body) {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
  html,body{margin:0;background:#0b0d12;color:#d7deea}
  pre{margin:0;padding:16px;font:13px/1.6 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap}
  .label{padding:12px 16px 0;color:#8e96a8;font:600 11px Outfit,system-ui;letter-spacing:.14em;text-transform:uppercase}
</style></head><body><div class="label">${title}</div><pre>${body.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">")}</pre></body></html>`;
}
function svgDocument(code) {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
<style>html,body{margin:0;background:#0b0d12;display:grid;place-items:center;min-height:100%} svg{max-width:90vw;max-height:90vh}</style>
</head><body>${code.trim().startsWith("<") ? code : `<svg xmlns="http://www.w3.org/2000/svg">${code}</svg>`}</body></html>`;
}
function imageDocument(src) {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
<style>html,body{margin:0;background:#0b0d12;display:grid;place-items:center;min-height:100%} img{max-width:92vw;max-height:92vh;border-radius:12px}</style>
</head><body><img alt="Preview" src="${src}" /></body></html>`;
}
function planRun(files, active) {
	if (!active) return {
		mode: "unavailable",
		language: "plaintext",
		reason: "Open a file first."
	};
	const language = resolvedLanguage(active);
	const meta = languageById(language);
	const hasHtml = files.some((f) => f.path.endsWith(".html") || f.path.endsWith(".htm") || f.language === "html");
	if (language === "html" || language === "css" || (language === "javascript" || language === "typescript") && hasHtml) return {
		mode: "preview",
		language
	};
	if (language === "javascript" || language === "typescript") return {
		mode: "console",
		language
	};
	if (language === "python") return {
		mode: "console",
		language
	};
	if (language === "markdown") return {
		mode: "markdown",
		language
	};
	if (language === "json" || language === "xml" || language === "sql") return {
		mode: "formatted",
		language
	};
	if (language === "svg") return {
		mode: "svg",
		language
	};
	if (language === "image") return {
		mode: "image",
		language
	};
	return {
		mode: "unavailable",
		language,
		reason: meta.unavailableReason ?? "Execution environment unavailable"
	};
}
function htmlEntry(files, active) {
	if (active.language === "html" || active.path.endsWith(".html") || active.path.endsWith(".htm")) return active;
	return files.find((f) => f.path === "index.html" || f.path.endsWith("/index.html")) ?? files.find((f) => f.path.endsWith(".html") || f.path.endsWith(".htm")) ?? active;
}
async function prepareRun(files, active) {
	const plan = planRun(files, active);
	if (!active) return {
		mode: "unavailable",
		status: "unavailable",
		message: plan.reason
	};
	if (plan.mode === "unavailable") return {
		mode: "unavailable",
		status: "unavailable",
		message: plan.reason,
		ranAt: Date.now()
	};
	try {
		if (plan.mode === "preview") {
			if (plan.language === "css" && !files.some((f) => f.language === "html" || f.path.endsWith(".html"))) return {
				mode: "preview",
				status: "ok",
				html: wrapCssPreview(active.content),
				ranAt: Date.now()
			};
			return {
				mode: "preview",
				status: "ok",
				html: buildWebDocument(files, htmlEntry(files, active)),
				ranAt: Date.now()
			};
		}
		if (plan.mode === "console" && (plan.language === "javascript" || plan.language === "typescript")) return {
			mode: "console",
			status: "running",
			html: wrapJsConsole(plan.language === "typescript" ? stripTs(active.content) : active.content),
			ranAt: Date.now()
		};
		if (plan.mode === "console" && plan.language === "python") return {
			mode: "console",
			status: "running",
			message: "Loading Python runtime…",
			ranAt: Date.now()
		};
		if (plan.mode === "markdown") return {
			mode: "markdown",
			status: "ok",
			html: await renderMarkdown(active.content),
			ranAt: Date.now()
		};
		if (plan.mode === "formatted") {
			let body = active.content;
			if (plan.language === "json") try {
				body = JSON.stringify(JSON.parse(active.content), null, 2);
			} catch (err) {
				return {
					mode: "formatted",
					status: "error",
					message: err instanceof Error ? err.message : "Invalid JSON",
					ranAt: Date.now()
				};
			}
			return {
				mode: "formatted",
				status: "ok",
				html: formattedView(plan.language.toUpperCase(), body),
				ranAt: Date.now()
			};
		}
		if (plan.mode === "svg") return {
			mode: "svg",
			status: "ok",
			html: svgDocument(active.content),
			ranAt: Date.now()
		};
		if (plan.mode === "image") return {
			mode: "image",
			status: "ok",
			html: imageDocument(active.content),
			ranAt: Date.now()
		};
	} catch (err) {
		return {
			mode: plan.mode,
			status: "error",
			message: err instanceof Error ? err.message : "Run failed",
			ranAt: Date.now()
		};
	}
	return {
		mode: plan.mode,
		status: "unavailable",
		message: "Execution environment unavailable",
		ranAt: Date.now()
	};
}
var RUN_TIMEOUT = RUN_TIMEOUT_MS;
var pyodidePromise = null;
async function loadPyodideRuntime() {
	if (!window.loadPyodide) await new Promise((resolve, reject) => {
		const script = document.createElement("script");
		script.src = "https://cdn.jsdelivr.net/pyodide/v0.27.5/full/pyodide.js";
		script.onload = () => resolve();
		script.onerror = () => reject(/* @__PURE__ */ new Error("Could not load the Python runtime."));
		document.head.appendChild(script);
	});
	const loader = window.loadPyodide;
	return loader({ indexURL: "https://cdn.jsdelivr.net/pyodide/v0.27.5/full/" });
}
async function runPython(code, onOutput) {
	const timeout = new Promise((_, reject) => {
		setTimeout(() => reject(/* @__PURE__ */ new Error("Python runtime timed out.")), PYTHON_LOAD_TIMEOUT_MS);
	});
	if (!pyodidePromise) pyodidePromise = loadPyodideRuntime();
	let pyodide;
	try {
		pyodide = await Promise.race([pyodidePromise, timeout]);
	} catch (err) {
		pyodidePromise = null;
		throw err;
	}
	pyodide.setStdout({ batched: (s) => onOutput("log", s) });
	pyodide.setStderr({ batched: (s) => onOutput("error", s) });
	const execTimeout = new Promise((_, reject) => {
		setTimeout(() => reject(/* @__PURE__ */ new Error("Execution timed out.")), RUN_TIMEOUT_MS);
	});
	await Promise.race([pyodide.runPythonAsync(code), execTimeout]);
}
var TEXT_EXT = /* @__PURE__ */ new Set([
	"html",
	"htm",
	"css",
	"js",
	"mjs",
	"cjs",
	"ts",
	"tsx",
	"jsx",
	"py",
	"dart",
	"java",
	"kt",
	"kts",
	"c",
	"h",
	"cpp",
	"cc",
	"hpp",
	"cs",
	"php",
	"rb",
	"go",
	"rs",
	"swift",
	"json",
	"xml",
	"md",
	"markdown",
	"svg",
	"vue",
	"svelte",
	"sql",
	"lua",
	"txt",
	"yml",
	"yaml",
	"toml",
	"env",
	"gitignore"
]);
var IMAGE_EXT = /* @__PURE__ */ new Set([
	"png",
	"jpg",
	"jpeg",
	"gif",
	"webp",
	"ico"
]);
function ext(path) {
	const base = path.split("/").pop() ?? path;
	const i = base.lastIndexOf(".");
	return i === -1 ? "" : base.slice(i + 1).toLowerCase();
}
function normalizePath(path) {
	return path.replace(/\\/g, "/").replace(/^\.?\//, "");
}
async function importZip(file) {
	if (file.size > 8e6) throw new Error("ZIP is too large. Keep projects under 8 MB.");
	const zip = await import_lib.default.loadAsync(file);
	const files = [];
	const folderSet = /* @__PURE__ */ new Set();
	const entries = Object.values(zip.files);
	for (const entry of entries) {
		const path = normalizePath(entry.name);
		if (!path || shouldSkipZipPath(path)) continue;
		if (entry.dir) {
			const dir = path.replace(/\/+$/, "");
			if (dir) folderSet.add(dir);
			continue;
		}
		const parent = parentPath(path);
		if (parent) {
			const parts = parent.split("/");
			let acc = "";
			for (const part of parts) {
				acc = acc ? `${acc}/${part}` : part;
				folderSet.add(acc);
			}
		}
		const kind = ext(path);
		if (IMAGE_EXT.has(kind)) {
			const blob = await entry.async("base64");
			if (blob.length * .75 > 15e5) continue;
			const mime = kind === "jpg" ? "jpeg" : kind;
			files.push({
				id: createId(),
				path,
				content: `data:image/${mime};base64,${blob}`,
				language: "image",
				binary: true
			});
			continue;
		}
		if (!TEXT_EXT.has(kind) && kind !== "") continue;
		const content = await entry.async("string");
		if (content.length > 15e5) continue;
		const language = detectLanguage(content, path);
		files.push({
			id: createId(),
			path,
			content,
			language: language === "plaintext" ? languageFromExtension(path) : language
		});
	}
	return {
		name: file.name.replace(/\.zip$/i, "") || "My Project",
		files,
		folders: [...folderSet].sort()
	};
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var inputSchema = object({
	task: _enum([
		"explain",
		"fix",
		"optimize",
		"convert",
		"generate"
	]),
	code: string().max(AI_MAX_CODE_CHARS),
	language: string().max(40),
	prompt: string().max(500).optional()
});
var askNijoAssistant = createServerFn({ method: "POST" }).validator(inputSchema).handler(createSsrRpc("adefec2d702eba7f709f00486945ad277e874c50ae02c50fb3195f0d6195fc17"));
var hourKey = "nijo-ai-hour";
function canCallAssistant() {
	if (typeof window === "undefined") return {
		ok: false,
		error: "Unavailable"
	};
	try {
		const raw = localStorage.getItem(hourKey);
		const now = Date.now();
		const parsed = raw ? JSON.parse(raw) : {
			start: now,
			count: 0
		};
		if (now - parsed.start > 36e5) {
			localStorage.setItem(hourKey, JSON.stringify({
				start: now,
				count: 0
			}));
			return { ok: true };
		}
		if (parsed.count >= 8) return {
			ok: false,
			error: "Assistant limit reached. Try again in a bit."
		};
		return { ok: true };
	} catch {
		return { ok: true };
	}
}
function recordAssistantCall() {
	try {
		const raw = localStorage.getItem(hourKey);
		const now = Date.now();
		const parsed = raw ? JSON.parse(raw) : {
			start: now,
			count: 0
		};
		const start = now - parsed.start > 36e5 ? now : parsed.start;
		const count = start === parsed.start ? parsed.count + 1 : 1;
		localStorage.setItem(hourKey, JSON.stringify({
			start,
			count
		}));
	} catch {}
}
var TASKS = [
	{
		id: "explain",
		label: "Explain"
	},
	{
		id: "fix",
		label: "Fix"
	},
	{
		id: "optimize",
		label: "Optimize"
	},
	{
		id: "convert",
		label: "Convert"
	},
	{
		id: "generate",
		label: "Generate"
	}
];
function AssistantSheet({ open, onOpenChange }) {
	const [task, setTask] = (0, import_react.useState)("explain");
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [reply, setReply] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function run() {
		const gate = canCallAssistant();
		if (!gate.ok) {
			toast.error(gate.error);
			return;
		}
		const file = getActiveFile();
		const code = (file?.content ?? "").slice(0, AI_MAX_CODE_CHARS);
		if (!code && task !== "generate") {
			toast.error("Open a file first.");
			return;
		}
		setBusy(true);
		setReply("");
		try {
			const result = await askNijoAssistant({ data: {
				task,
				code: code || "// empty",
				language: file ? resolvedLanguage(file) : "javascript",
				prompt: prompt.trim() || void 0
			} });
			if (!result.ok) {
				toast.error(result.error);
				return;
			}
			recordAssistantCall();
			setReply(result.text);
		} catch {
			toast.error("Assistant is not available right now.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
			title: "AI assistant",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: TASKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setTask(item.id),
							className: `h-10 rounded-full px-3 text-sm ${task === item.id ? "bg-primary text-primary-fg" : "bg-surface text-fg"}`,
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: prompt,
						onChange: (e) => setPrompt(e.target.value),
						placeholder: "Optional: convert to JavaScript, explain in Arabic…",
						className: "min-h-20 w-full rounded-md bg-surface p-3 text-sm text-fg shadow-nijo outline-none placeholder:text-subtle"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void run(),
						disabled: busy,
						children: busy ? "Working…" : "Ask assistant"
					}),
					reply && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "max-h-64 overflow-auto whitespace-pre-wrap rounded-md bg-surface p-3 font-mono text-xs leading-relaxed text-fg",
						children: reply
					})
				]
			})
		})
	});
}
var CodeEditor = (0, import_react.forwardRef)(function CodeEditor({ value, language, fontSize, wrap, tabSize, theme, onChange, className }, ref) {
	const parentRef = (0, import_react.useRef)(null);
	const viewRef = (0, import_react.useRef)(null);
	const valueRef = (0, import_react.useRef)(value);
	const onChangeRef = (0, import_react.useRef)(onChange);
	const [ready, setReady] = (0, import_react.useState)(false);
	valueRef.current = value;
	onChangeRef.current = onChange;
	const extensions = (0, import_react.useMemo)(() => {
		const themeExt = EditorView.theme({
			"&": {
				height: "100%",
				fontSize: `${fontSize}px`,
				backgroundColor: "transparent"
			},
			".cm-scroller": {
				overflow: "auto",
				fontFamily: "var(--font-mono)",
				lineHeight: "1.65",
				paddingBottom: "6rem"
			},
			".cm-content": { caretColor: theme === "dark" ? "#4d8dff" : "#2f74f0" },
			".cm-gutters": {
				backgroundColor: "transparent",
				color: theme === "dark" ? "#6b7386" : "#8a93a3",
				border: "none"
			},
			".cm-activeLineGutter": { backgroundColor: "transparent" }
		});
		const list = [
			lineNumbers(),
			highlightActiveLineGutter(),
			highlightActiveLine(),
			highlightSelectionMatches(),
			history(),
			indentOnInput(),
			bracketMatching(),
			closeBrackets(),
			autocompletion(),
			foldGutter(),
			keymap.of([
				...closeBracketsKeymap,
				...defaultKeymap,
				...historyKeymap,
				...searchKeymap,
				...completionKeymap,
				indentWithTab
			]),
			EditorState.tabSize.of(tabSize),
			placeholder("Start typing, or paste code from your phone…"),
			...languageExtension(language),
			themeExt,
			EditorView.updateListener.of((update) => {
				if (update.docChanged) {
					const next = update.state.doc.toString();
					valueRef.current = next;
					onChangeRef.current(next);
				}
			})
		];
		if (wrap) list.push(EditorView.lineWrapping);
		if (theme === "dark") list.push(oneDark);
		return list;
	}, [
		fontSize,
		language,
		tabSize,
		theme,
		wrap
	]);
	(0, import_react.useEffect)(() => {
		const parent = parentRef.current;
		if (!parent) return;
		const view = new EditorView({
			doc: valueRef.current,
			parent,
			extensions
		});
		viewRef.current = view;
		setReady(true);
		return () => {
			view.destroy();
			viewRef.current = null;
		};
	}, [extensions]);
	(0, import_react.useEffect)(() => {
		const view = viewRef.current;
		if (!view) return;
		const current = view.state.doc.toString();
		if (current !== value) view.dispatch({ changes: {
			from: 0,
			to: current.length,
			insert: value
		} });
	}, [value]);
	(0, import_react.useImperativeHandle)(ref, () => ({
		insert: (text) => {
			const view = viewRef.current;
			if (!view) return;
			const { from, to } = view.state.selection.main;
			view.dispatch({
				changes: {
					from,
					to,
					insert: text
				},
				selection: { anchor: from + text.length }
			});
			view.focus();
		},
		undo: () => {
			const view = viewRef.current;
			if (view) undo(view);
		},
		redo: () => {
			const view = viewRef.current;
			if (view) redo(view);
		},
		selectAll: () => {
			const view = viewRef.current;
			if (!view) return;
			view.dispatch({ selection: {
				anchor: 0,
				head: view.state.doc.length
			} });
			view.focus();
		},
		focus: () => viewRef.current?.focus(),
		getSelected: () => {
			const view = viewRef.current;
			if (!view) return "";
			const { from, to } = view.state.selection.main;
			return view.state.doc.sliceString(from, to);
		},
		replaceSelection: (text) => {
			const view = viewRef.current;
			if (!view) return;
			view.dispatch(view.state.replaceSelection(text));
			view.focus();
		},
		view: () => viewRef.current
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative h-full min-h-0 bg-bg", className),
		children: [!ready && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 flex items-center justify-center text-sm text-muted",
			children: "Opening editor…"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: parentRef,
			className: "h-full min-h-0 overflow-hidden"
		})]
	});
});
function FilesPanel() {
	const files = useProjectStore((s) => s.files);
	const folders = useProjectStore((s) => s.folders);
	const currentDir = useProjectStore((s) => s.currentDir);
	const activeFileId = useProjectStore((s) => s.activeFileId);
	const projectName = useProjectStore((s) => s.projectName);
	const setCurrentDir = useProjectStore((s) => s.setCurrentDir);
	const setActiveFile = useProjectStore((s) => s.setActiveFile);
	const createFile = useProjectStore((s) => s.createFile);
	const createFolder = useProjectStore((s) => s.createFolder);
	const renameNode = useProjectStore((s) => s.renameNode);
	const deleteNode = useProjectStore((s) => s.deleteNode);
	const openLocalText = useProjectStore((s) => s.openLocalText);
	const replaceProject = useProjectStore((s) => s.replaceProject);
	const fileInput = (0, import_react.useRef)(null);
	const zipInput = (0, import_react.useRef)(null);
	const [composer, setComposer] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [menu, setMenu] = (0, import_react.useState)(null);
	const [rename, setRename] = (0, import_react.useState)("");
	const items = (0, import_react.useMemo)(() => {
		return {
			childFolders: folders.filter((folder) => parentPath(folder) === currentDir).sort((a, b) => a.localeCompare(b)),
			childFiles: files.filter((file) => parentPath(file.path) === currentDir).sort((a, b) => a.path.localeCompare(b.path))
		};
	}, [
		files,
		folders,
		currentDir
	]);
	async function onPickFile(list) {
		if (!list?.length) return;
		const file = list[0];
		if (file.name.toLowerCase().endsWith(".zip")) {
			await onZip(file);
			return;
		}
		try {
			const text = await file.text();
			const error = openLocalText(file.name, text);
			if (error) toast.error(error);
			else toast.success(`Opened ${file.name}`);
		} catch {
			toast.error("Could not read that file.");
		}
	}
	async function onZip(file) {
		try {
			toast.message("Opening project…");
			const imported = await importZip(file);
			const error = replaceProject(imported.name, imported.files, imported.folders);
			if (error) toast.error(error);
			else toast.success(`Opened ${imported.name}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not open ZIP.");
		}
	}
	function submitComposer() {
		const error = composer === "folder" ? createFolder(draft) : createFile(draft);
		if (error) toast.error(error);
		else setComposer(null);
		setDraft("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 border-b border-border px-3 py-3",
				children: [currentDir ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-10 items-center justify-center rounded-md text-fg",
					onClick: () => setCurrentDir(parentPath(currentDir)),
					"aria-label": "Up one folder",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium",
						children: currentDir ? baseName(currentDir) : projectName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted",
						children: currentDir || "Project root"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: () => {
							setComposer("file");
							setDraft("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePlus, { className: "size-4" }), " New file"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: () => {
							setComposer("folder");
							setDraft("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPlus, { className: "size-4" }), " New folder"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => fileInput.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), " Open file"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => zipInput.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-4" }), " Open ZIP"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileInput,
				type: "file",
				accept: OPEN_ACCEPT,
				className: "hidden",
				onChange: (e) => void onPickFile(e.target.files)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: zipInput,
				type: "file",
				accept: ".zip,application/zip",
				className: "hidden",
				onChange: (e) => {
					const file = e.target.files?.[0];
					if (file) onZip(file);
				}
			}),
			composer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 px-3 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					autoFocus: true,
					value: draft,
					placeholder: composer === "folder" ? "src" : "main.py",
					onChange: (e) => setDraft(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter") submitComposer();
						if (e.key === "Escape") setComposer(null);
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: submitComposer,
					children: "Create"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-2 pb-6",
				children: [
					items.childFolders.length === 0 && items.childFiles.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-3 py-10 text-center text-sm text-muted",
						children: "This folder is empty."
					}),
					items.childFolders.map((folder) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex h-12 min-w-0 flex-1 items-center gap-3 rounded-md px-3 text-left",
							onClick: () => setCurrentDir(folder),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folder, { className: "size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm",
								children: baseName(folder)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-11 items-center justify-center text-muted",
							"aria-label": "Folder actions",
							onClick: () => {
								setMenu({
									path: folder,
									folder: true
								});
								setRename(baseName(folder));
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
						})]
					}, folder)),
					items.childFiles.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `flex h-12 min-w-0 flex-1 items-center gap-3 rounded-md px-3 text-left ${file.id === activeFileId ? "bg-surface" : ""}`,
							onClick: () => setActiveFile(file.id),
							children: [file.language === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-5 shrink-0 text-muted" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode2, { className: "size-5 shrink-0 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm",
								children: baseName(file.path)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-11 items-center justify-center text-muted",
							"aria-label": "File actions",
							onClick: () => {
								setMenu({
									path: file.path,
									folder: false
								});
								setRename(baseName(file.path));
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
						})]
					}, file.id))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!menu,
				onOpenChange: (open) => !open && setMenu(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					title: menu?.folder ? "Folder" : "File",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 pt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: rename,
								onChange: (e) => setRename(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "w-full",
								variant: "secondary",
								onClick: () => {
									if (menu) renameNode(menu.path, rename, menu.folder);
									setMenu(null);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" }), " Rename"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "w-full",
								variant: "danger",
								onClick: () => {
									if (menu) deleteNode(menu.path, menu.folder);
									setMenu(null);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Delete"]
							})
						]
					})
				})
			})
		]
	});
}
var DEVICE_CLASS = {
	mobile: "max-w-[390px]",
	tablet: "max-w-[768px]",
	desktop: "max-w-none"
};
function PreviewPanel({ onFullscreen }) {
	const run = useProjectStore((s) => s.run);
	const device = useProjectStore((s) => s.previewDevice);
	const setDevice = useProjectStore((s) => s.setDevice);
	const appendConsole = useProjectStore((s) => s.appendConsole);
	const setRun = useProjectStore((s) => s.setRun);
	const iframeRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		function onMessage(event) {
			const data = event.data;
			if (!data || data.source !== "nijo-preview") return;
			if (data.type === "console") {
				const level = data.level === "error" || data.level === "warn" || data.level === "info" ? data.level : "log";
				appendConsole({
					level,
					text: data.text ?? "",
					meta: data.meta
				});
				if (level === "error") setRun({
					...useProjectStore.getState().run,
					status: "error"
				});
			}
			if (data.type === "done" || data.type === "ready") {
				const current = useProjectStore.getState().run;
				if (current.status === "running") setRun({
					...current,
					status: "ok"
				});
			}
		}
		window.addEventListener("message", onMessage);
		return () => window.removeEventListener("message", onMessage);
	}, [appendConsole, setRun]);
	(0, import_react.useEffect)(() => {
		if (run.status !== "running") return;
		const timer = window.setTimeout(() => {
			const current = useProjectStore.getState().run;
			if (current.status === "running" && current.mode !== "console") {
				setRun({
					...current,
					status: "ok"
				});
				return;
			}
			if (current.status === "running") {
				setRun({
					...current,
					status: "timeout",
					message: "Execution timed out."
				});
				appendConsole({
					level: "error",
					text: "Execution timed out.",
					meta: "Stopped for safety"
				});
				if (iframeRef.current) iframeRef.current.src = "about:blank";
			}
		}, RUN_TIMEOUT);
		return () => window.clearTimeout(timer);
	}, [
		run.status,
		run.ranAt,
		appendConsole,
		setRun
	]);
	(0, import_react.useEffect)(() => {
		if (run.mode !== "console" || run.message !== "Loading Python runtime…") return;
		const file = getActiveFile();
		if (!file) return;
		let cancelled = false;
		(async () => {
			try {
				await runPython(file.content, (level, text) => {
					if (!cancelled) appendConsole({
						level: level === "error" ? "error" : "log",
						text
					});
				});
				if (!cancelled) {
					appendConsole({
						level: "success",
						text: "Execution completed"
					});
					setRun({
						mode: "console",
						status: "ok",
						ranAt: Date.now()
					});
				}
			} catch (err) {
				if (cancelled) return;
				const message = err instanceof Error ? err.message : "Python failed.";
				appendConsole({
					level: "error",
					text: message
				});
				setRun({
					mode: "console",
					status: message.includes("load") ? "unavailable" : "error",
					message: message.includes("load") ? "Execution environment unavailable" : message,
					ranAt: Date.now()
				});
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [
		run.mode,
		run.message,
		run.ranAt,
		appendConsole,
		setRun
	]);
	const devices = [
		{
			id: "mobile",
			icon: Smartphone,
			label: "Mobile"
		},
		{
			id: "tablet",
			icon: Tablet,
			label: "Tablet"
		},
		{
			id: "desktop",
			icon: Monitor,
			label: "Desktop"
		}
	];
	const visualMode = run.mode === "preview" || run.mode === "markdown" || run.mode === "formatted" || run.mode === "svg" || run.mode === "image";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1 border-b border-border px-2 py-2",
			children: [devices.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setDevice(item.id),
				className: `flex h-10 items-center gap-1.5 rounded-md px-3 text-xs font-medium ${device === item.id ? "bg-surface text-fg" : "text-muted"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }), item.label]
			}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					"aria-label": "Refresh preview",
					onClick: () => {
						const html = useProjectStore.getState().run.html;
						if (iframeRef.current && html) iframeRef.current.srcdoc = html;
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					"aria-label": "Fullscreen preview",
					onClick: onFullscreen,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-4" })
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-auto bg-elevated p-3",
			children: [
				run.status === "unavailable" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-sm rounded-xl bg-surface p-5 shadow-nijo",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Execution environment unavailable"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: run.message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-subtle",
							children: "The editor still works. You can copy, edit, and save this file."
						})
					]
				}),
				run.status === "idle" && !run.html && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-full place-items-center text-center text-sm text-muted",
					children: "Tap Run to preview this file."
				}),
				run.html && run.status !== "unavailable" && visualMode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `mx-auto h-full overflow-hidden rounded-lg bg-white shadow-nijo ${DEVICE_CLASS[device]}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						ref: iframeRef,
						title: "NIJO preview",
						className: "h-full w-full bg-white",
						sandbox: "allow-scripts allow-forms allow-modals",
						srcDoc: run.html
					})
				}),
				run.mode === "console" && !run.html && run.status === "running" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-full place-items-center text-sm text-muted",
					children: run.message ?? "Running…"
				})
			]
		})]
	});
}
function ConsolePanel() {
	const lines = useProjectStore((s) => s.consoleLines);
	const clearConsole = useProjectStore((s) => s.clearConsole);
	const run = useProjectStore((s) => s.run);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-40 flex-col border-t border-border bg-elevated",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-10 items-center justify-between px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
				children: "Console"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-xs text-muted",
				onClick: clearConsole,
				children: "Clear"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-3 pb-3 font-mono text-xs leading-relaxed",
			children: [
				run.status === "ok" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-success",
					children: "Execution completed"
				}),
				run.status === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-danger",
					children: "Error"
				}),
				run.status === "timeout" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-warning",
					children: "Timed out"
				}),
				run.status === "unavailable" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-warning",
					children: "Execution environment unavailable"
				}),
				lines.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-subtle",
					children: "No output yet."
				}),
				lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: line.level === "error" ? "whitespace-pre-wrap text-danger" : line.level === "warn" ? "whitespace-pre-wrap text-warning" : line.level === "success" ? "whitespace-pre-wrap text-success" : "whitespace-pre-wrap text-fg",
					children: [line.meta ? `${line.meta} · ` : "", line.text]
				}, line.id))
			]
		})]
	});
}
function SettingsPanel({ onAssistant }) {
	const settings = useProjectStore((s) => s.settings);
	const setSettings = useProjectStore((s) => s.setSettings);
	const resetProject = useProjectStore((s) => s.resetProject);
	const [installEvent, setInstallEvent] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const onPrompt = (event) => {
			event.preventDefault();
			setInstallEvent(event);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		return () => window.removeEventListener("beforeinstallprompt", onPrompt);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full overflow-y-auto bg-bg px-4 py-5 pb-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-lg flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-elevated p-4 shadow-nijo",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
							children: "Editor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "Font size"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "secondary",
										"aria-label": "Smaller",
										onClick: () => setSettings({ fontSize: Math.max(12, settings.fontSize - 1) }),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-8 text-center font-mono text-sm tabular-nums",
										children: settings.fontSize
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "secondary",
										"aria-label": "Larger",
										onClick: () => setSettings({ fontSize: Math.min(22, settings.fontSize + 1) }),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Light editor",
							checked: settings.theme === "light",
							onChange: (checked) => setSettings({ theme: checked ? "light" : "dark" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Word wrap",
							checked: settings.wrap,
							onChange: (checked) => setSettings({ wrap: checked })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Tab size 4",
							checked: settings.tabSize === 4,
							onChange: (checked) => setSettings({ tabSize: checked ? 4 : 2 })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-elevated p-4 shadow-nijo",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
							children: "Install"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Add NIJO MOBILE to your home screen and use it like an app, even with a flaky connection."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							onClick: async () => {
								if (installEvent) {
									await installEvent.prompt();
									setInstallEvent(null);
									return;
								}
								toast.message("Use your browser menu: Add to Home Screen.");
							},
							children: "Add to Home Screen"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-elevated p-4 shadow-nijo",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
							children: "Assistant"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Explain, fix, or convert code. Calls are user-initiated and capped."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							variant: "secondary",
							onClick: onAssistant,
							children: "Open assistant"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-elevated p-4 shadow-nijo",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
						children: "Project"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-4 w-full",
						variant: "outline",
						onClick: () => {
							resetProject();
							toast.success("Restored the sample project.");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), " Reset sample project"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex items-center gap-3 rounded-xl bg-elevated p-4 shadow-nijo",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NijoMark, { className: "size-12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium tracking-tight",
							children: "NIJO MOBILE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Code Anywhere. Build Anywhere."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-subtle",
							children: "Developed by Bouzidi Softworks"
						})
					] })]
				})
			]
		})
	});
}
function Toggle({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mt-3 flex h-12 items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			role: "switch",
			"aria-checked": checked,
			onClick: () => onChange(!checked),
			className: `relative h-7 w-12 rounded-full transition-colors duration-150 ${checked ? "bg-primary" : "bg-surface shadow-nijo"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-fg transition-transform duration-150 ${checked ? "translate-x-5 bg-primary-fg" : "translate-x-0.5"}` })
		})]
	});
}
var TOOLBAR_CHARS = [
	"{",
	"}",
	"(",
	")",
	"[",
	"]",
	"<",
	">",
	";",
	":",
	"\"",
	"'",
	"=",
	"/",
	"+",
	"-",
	"*",
	"_",
	"#"
];
var TABS = [
	{
		id: "editor",
		label: "Editor",
		icon: FileCode2
	},
	{
		id: "run",
		label: "Run",
		icon: Play
	},
	{
		id: "preview",
		label: "Preview",
		icon: Eye
	},
	{
		id: "files",
		label: "Files",
		icon: FolderOpen
	},
	{
		id: "settings",
		label: "Settings",
		icon: Settings
	}
];
function WorkspaceApp({ intent }) {
	const hydrate = useProjectStore((s) => s.hydrate);
	const hydrated = useProjectStore((s) => s.hydrated);
	const tab = useProjectStore((s) => s.tab);
	const setTab = useProjectStore((s) => s.setTab);
	const files = useProjectStore((s) => s.files);
	const activeFileId = useProjectStore((s) => s.activeFileId);
	const settings = useProjectStore((s) => s.settings);
	const updateContent = useProjectStore((s) => s.updateContent);
	const setLanguage = useProjectStore((s) => s.setLanguage);
	const autoDetectActive = useProjectStore((s) => s.autoDetectActive);
	const fullscreen = useProjectStore((s) => s.fullscreen);
	const setFullscreen = useProjectStore((s) => s.setFullscreen);
	const findOpen = useProjectStore((s) => s.findOpen);
	const setFindOpen = useProjectStore((s) => s.setFindOpen);
	const openLocalText = useProjectStore((s) => s.openLocalText);
	const replaceProject = useProjectStore((s) => s.replaceProject);
	const appendConsole = useProjectStore((s) => s.appendConsole);
	const clearConsole = useProjectStore((s) => s.clearConsole);
	const setRun = useProjectStore((s) => s.setRun);
	const run = useProjectStore((s) => s.run);
	const file = files.find((f) => f.id === activeFileId);
	const language = file ? resolvedLanguage(file) : "javascript";
	const editorRef = (0, import_react.useRef)(null);
	const fileInput = (0, import_react.useRef)(null);
	const navigate = useNavigate();
	const [kb, setKb] = (0, import_react.useState)(0);
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	const [langOpen, setLangOpen] = (0, import_react.useState)(false);
	const [pasteOpen, setPasteOpen] = (0, import_react.useState)(false);
	const [pasteDraft, setPasteDraft] = (0, import_react.useState)("");
	const [assistantOpen, setAssistantOpen] = (0, import_react.useState)(false);
	const [find, setFind] = (0, import_react.useState)("");
	const [replace, setReplace] = (0, import_react.useState)("");
	const handledIntent = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		if (!hydrated || handledIntent.current || !intent) return;
		handledIntent.current = true;
		if (intent === "open") fileInput.current?.click();
		if (intent === "paste") handlePaste();
		navigate({
			to: "/workspace",
			search: {},
			replace: true
		});
	}, [
		hydrated,
		intent,
		navigate
	]);
	(0, import_react.useEffect)(() => {
		const vv = window.visualViewport;
		if (!vv) return;
		const update = () => {
			const inset = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
			setKb(inset);
			document.documentElement.style.setProperty("--nijo-kb", `${inset}px`);
		};
		vv.addEventListener("resize", update);
		vv.addEventListener("scroll", update);
		update();
		return () => {
			vv.removeEventListener("resize", update);
			vv.removeEventListener("scroll", update);
		};
	}, []);
	async function handlePaste() {
		try {
			const text = await navigator.clipboard.readText();
			if (text) {
				applyPasted(text);
				return;
			}
		} catch {}
		setPasteDraft("");
		setPasteOpen(true);
	}
	function applyPasted(text) {
		const current = getActiveFile();
		if (!current) return;
		useProjectStore.getState().updateContent(current.id, text);
		const detected = autoDetectActive();
		toast.success(`Pasted · ${languageById(detected).label}`);
		setTab("editor");
		setPasteOpen(false);
	}
	async function handleCopy() {
		const text = file?.content ?? "";
		try {
			await navigator.clipboard.writeText(text);
			toast.success("Code copied");
		} catch {
			toast.error("Could not copy. Select the code and copy it manually.");
		}
	}
	async function handleOpen(list) {
		const picked = list?.[0];
		if (!picked) return;
		if (picked.name.toLowerCase().endsWith(".zip")) {
			try {
				const imported = await importZip(picked);
				const error = replaceProject(imported.name, imported.files, imported.folders);
				if (error) toast.error(error);
				else toast.success(`Opened ${imported.name}`);
			} catch (err) {
				toast.error(err instanceof Error ? err.message : "Could not open ZIP.");
			}
			return;
		}
		try {
			const text = await picked.text();
			const error = openLocalText(picked.name, text);
			if (error) toast.error(error);
			else toast.success(`Opened ${picked.name}`);
		} catch {
			toast.error("Could not read that file.");
		}
	}
	async function handleRun() {
		const active = getActiveFile();
		clearConsole();
		appendConsole({
			level: "status",
			text: "Running…"
		});
		setRun({
			mode: "preview",
			status: "running"
		});
		const snapshot = await prepareRun(useProjectStore.getState().files, active);
		setRun(snapshot);
		if (snapshot.status === "unavailable") appendConsole({
			level: "error",
			text: snapshot.message ?? "Execution environment unavailable"
		});
		else if (snapshot.status === "error") appendConsole({
			level: "error",
			text: snapshot.message ?? "Run failed"
		});
		else if (snapshot.mode === "preview" || snapshot.mode === "markdown" || snapshot.mode === "svg" || snapshot.mode === "formatted" || snapshot.mode === "image") appendConsole({
			level: "success",
			text: "Preview ready"
		});
		if (snapshot.mode === "console" || snapshot.mode === "unavailable") setTab("run");
		else setTab("preview");
	}
	function findNext(direction) {
		const view = editorRef.current?.view();
		if (!view || !find) return;
		const doc = view.state.doc.toString();
		const start = view.state.selection.main.to;
		const hay = direction === 1 ? doc.slice(start) + "\n" + doc.slice(0, start) : doc;
		const idx = direction === 1 ? hay.toLowerCase().indexOf(find.toLowerCase()) : doc.toLowerCase().lastIndexOf(find.toLowerCase(), view.state.selection.main.from - 1);
		if (idx < 0) {
			toast.message("No matches");
			return;
		}
		const from = direction === 1 ? (idx + start) % (doc.length + 1) : idx;
		const to = from + find.length;
		view.dispatch({
			selection: {
				anchor: from,
				head: to
			},
			scrollIntoView: true
		});
		view.focus();
	}
	function replaceOne() {
		if (!editorRef.current?.view() || !find) return;
		if ((editorRef.current?.getSelected() ?? "").toLowerCase() === find.toLowerCase()) editorRef.current?.replaceSelection(replace);
		findNext(1);
	}
	function replaceEvery() {
		if (!file || !find) return;
		const next = file.content.split(find).join(replace);
		updateContent(file.id, next);
		toast.success("Replaced all");
	}
	const keyboardOpen = kb > 80;
	const navHidden = fullscreen || keyboardOpen;
	const groups = (0, import_react.useMemo)(() => groupedLanguages(), []);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-dvh place-items-center bg-bg text-sm text-muted",
		children: "Loading workspace…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col overflow-hidden bg-bg text-fg",
		style: { paddingBottom: navHidden ? kb : void 0 },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-12 shrink-0 items-center gap-2 border-b border-border px-2 nijo-safe-top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "flex size-11 items-center justify-center",
						"aria-label": "Home",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NijoMark, { className: "size-8" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium",
							children: file ? baseName(file.path) : "No file"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "truncate text-left text-xs text-muted",
							onClick: () => setLangOpen(true),
							children: languageById(language).label
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderIcon, {
						label: "Paste",
						onClick: () => void handlePaste(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderIcon, {
						label: "Copy",
						onClick: () => void handleCopy(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderIcon, {
						label: "More",
						onClick: () => setMoreOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
					})
				]
			}),
			findOpen && tab === "editor" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 border-b border-border bg-elevated p-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: find,
							onChange: (e) => setFind(e.target.value),
							placeholder: "Find",
							className: "h-10"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => findNext(-1),
							children: "Prev"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => findNext(1),
							children: "Next"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: replace,
							onChange: (e) => setReplace(e.target.value),
							placeholder: "Replace",
							className: "h-10"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: replaceOne,
							children: "One"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: replaceEvery,
							children: "All"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setFindOpen(false),
							children: "Close"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative min-h-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("absolute inset-0", tab === "editor" ? "block" : "hidden"),
						children: file?.language === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-full place-items-center p-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: file.content,
								alt: file.path,
								className: "max-h-full max-w-full rounded-lg"
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
							ref: editorRef,
							value: file?.content ?? "",
							language,
							fontSize: settings.fontSize,
							wrap: settings.wrap,
							tabSize: settings.tabSize,
							theme: settings.theme,
							onChange: (value) => {
								if (file) updateContent(file.id, value);
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("absolute inset-0 flex flex-col", tab === "run" ? "flex" : "hidden"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 border-b border-border px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: "Run"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: languageById(language).label
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => void handleRun(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), " Run"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-h-0 flex-1 overflow-y-auto p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "Web files preview in a sandboxed frame. Console programs print below. Compilers that need a native SDK stay in the editor."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "mt-4 w-full",
										variant: "secondary",
										onClick: () => void handleRun(),
										children: "Run this file"
									}),
									run.html && run.mode === "console" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
										title: "NIJO runner",
										className: "hidden",
										sandbox: "allow-scripts",
										srcDoc: run.html
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsolePanel, {})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("absolute inset-0 flex flex-col", tab === "preview" ? "flex" : "hidden"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewPanel, { onFullscreen: () => setFullscreen(!fullscreen) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsolePanel, {})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("absolute inset-0", tab === "files" ? "block" : "hidden"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesPanel, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("absolute inset-0", tab === "settings" ? "block" : "hidden"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, { onAssistant: () => setAssistantOpen(true) })
					})
				]
			}),
			!fullscreen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nijo-toolbar flex shrink-0 gap-1 overflow-x-auto border-t border-border bg-elevated px-2 py-1.5",
				style: { paddingBottom: keyboardOpen ? 6 : void 0 },
				children: TOOLBAR_CHARS.map((char) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex h-10 min-w-10 shrink-0 items-center justify-center rounded-sm bg-surface font-mono text-sm text-fg",
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => {
						editorRef.current?.insert(char);
					},
					children: char
				}, char))
			}),
			!navHidden && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "grid shrink-0 grid-cols-5 border-t border-border bg-elevated pb-[env(safe-area-inset-bottom)]",
				style: { minHeight: "var(--nijo-nav)" },
				children: TABS.map((item) => {
					const Icon = item.icon;
					const active = tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: cn("flex flex-col items-center justify-center gap-0.5 text-[11px]", active ? "text-primary" : "text-muted"),
						onClick: () => {
							if (item.id === "run") handleRun();
							else setTab(item.id);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileInput,
				type: "file",
				accept: OPEN_ACCEPT,
				className: "hidden",
				onChange: (e) => void handleOpen(e.target.files)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: moreOpen,
				onOpenChange: setMoreOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					title: "Editor actions",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 pt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: Scissors,
								label: "Cut",
								onClick: async () => {
									const selected = editorRef.current?.getSelected() || file?.content || "";
									try {
										await navigator.clipboard.writeText(selected);
										if (editorRef.current?.getSelected()) editorRef.current.replaceSelection("");
										else if (file) updateContent(file.id, "");
									} catch {
										toast.error("Cut needs clipboard permission.");
									}
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: Copy,
								label: "Copy all",
								onClick: () => {
									handleCopy();
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: ClipboardPaste,
								label: "Paste",
								onClick: () => {
									setMoreOpen(false);
									handlePaste();
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: Undo2,
								label: "Undo",
								onClick: () => {
									editorRef.current?.undo();
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: Redo2,
								label: "Redo",
								onClick: () => {
									editorRef.current?.redo();
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: Search,
								label: "Find",
								onClick: () => {
									setFindOpen(true);
									setTab("editor");
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: SquareCheckBig,
								label: "Select all",
								onClick: () => {
									editorRef.current?.selectAll();
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: Eraser,
								label: "Clear",
								onClick: () => {
									if (file) updateContent(file.id, "");
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: FileCode2,
								label: "Format",
								onClick: () => {
									if (!file) return;
									updateContent(file.id, formatCode(file.content, language));
									toast.success("Formatted");
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: fullscreen ? Minimize2 : Maximize2,
								label: "Fullscreen",
								onClick: () => {
									setFullscreen(!fullscreen);
									setMoreOpen(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: Sparkles,
								label: "Assistant",
								onClick: () => {
									setMoreOpen(false);
									setAssistantOpen(true);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
								icon: FolderOpen,
								label: "Open file",
								onClick: () => {
									setMoreOpen(false);
									fileInput.current?.click();
								}
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: langOpen,
				onOpenChange: setLangOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					title: "Language",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-4",
						children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs font-medium uppercase tracking-[0.14em] text-muted",
							children: group.group
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col",
							children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex h-11 items-center justify-between text-left text-sm",
								onClick: () => {
									if (file) setLanguage(file.id, item.id);
									if (item.id === "auto") autoDetectActive();
									setLangOpen(false);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label }), file?.language === item.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-primary" })]
							}, item.id))
						})] }, group.group))
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: pasteOpen,
				onOpenChange: setPasteOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					title: "Paste code",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm text-muted",
							children: "Long-press and paste, then tap Insert."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							autoFocus: true,
							value: pasteDraft,
							onChange: (e) => setPasteDraft(e.target.value),
							className: "min-h-40 w-full rounded-md bg-surface p-3 font-mono text-sm text-fg shadow-nijo outline-none",
							placeholder: "Paste here"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-3 w-full",
							onClick: () => applyPasted(pasteDraft),
							disabled: !pasteDraft.trim(),
							children: "Insert into editor"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssistantSheet, {
				open: assistantOpen,
				onOpenChange: setAssistantOpen
			})
		]
	});
}
function HeaderIcon({ children, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "flex size-11 items-center justify-center rounded-md text-fg",
		children
	});
}
function Action({ icon: Icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex h-16 flex-col items-center justify-center gap-1 rounded-md bg-surface text-xs text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
//#endregion
export { WorkspaceApp };
