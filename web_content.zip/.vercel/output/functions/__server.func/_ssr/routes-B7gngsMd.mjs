import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ChevronLeft, i as Flame, o as ArrowDownUp, r as RotateCcw, t as Undo2 } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Chess } from "../_libs/chess.js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B7gngsMd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var bB_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cg%20fill='none'%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cg%20fill='%23000'%20stroke-linecap='butt'%3e%3cpath%20d='M9%2036c3.4-1%2010.1.4%2013.5-2%203.4%202.4%2010.1%201%2013.5%202%200%200%201.6.5%203%202-.7%201-1.6%201-3%20.5-3.4-1-10.1.5-13.5-1-3.4%201.5-10.1%200-13.5%201-1.4.5-2.3.5-3-.5%201.4-2%203-2%203-2z'/%3e%3cpath%20d='M15%2032c2.5%202.5%2012.5%202.5%2015%200%20.5-1.5%200-2%200-2%200-2.5-2.5-4-2.5-4%205.5-1.5%206-11.5-5-15.5-11%204-10.5%2014-5%2015.5%200%200-2.5%201.5-2.5%204%200%200-.5.5%200%202z'/%3e%3cpath%20d='M25%208a2.5%202.5%200%201%201-5%200%202.5%202.5%200%201%201%205%200z'/%3e%3c/g%3e%3cpath%20stroke='%23ececec'%20stroke-linejoin='miter'%20d='M17.5%2026h10M15%2030h15m-7.5-14.5v5M20%2018h5'/%3e%3c/g%3e%3c/svg%3e";
var bK_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20viewBox='0%200%2045%2045'%3e%3cg%20fill='none'%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cpath%20stroke-linejoin='miter'%20d='M22.5%2011.6V6'/%3e%3cpath%20fill='%23000'%20stroke-linecap='butt'%20stroke-linejoin='miter'%20d='M22.5%2025s4.5-7.5%203-10.5c0%200-1-2.5-3-2.5s-3%202.5-3%202.5c-1.5%203%203%2010.5%203%2010.5'/%3e%3cpath%20fill='%23000'%20d='M11.5%2037a22.3%2022.3%200%200%200%2021%200v-7s9-4.5%206-10.5c-4-6.5-13.5-3.5-16%204V27v-3.5c-3.5-7.5-13-10.5-16-4-3%206%205%2010%205%2010z'/%3e%3cpath%20stroke-linejoin='miter'%20d='M20%208h5'/%3e%3cpath%20stroke='%23ececec'%20d='M32%2029.5s8.5-4%206-9.7C34.1%2014%2025%2018%2022.5%2024.6v2.1-2.1C20%2018%209.9%2014%207%2019.9c-2.5%205.6%204.8%209%204.8%209'/%3e%3cpath%20stroke='%23ececec'%20d='M11.5%2030c5.5-3%2015.5-3%2021%200m-21%203.5c5.5-3%2015.5-3%2021%200m-21%203.5c5.5-3%2015.5-3%2021%200'/%3e%3c/g%3e%3c/svg%3e";
var bN_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cg%20fill='none'%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cpath%20fill='%23000'%20d='M22%2010c10.5%201%2016.5%208%2016%2029H15c0-9%2010-6.5%208-21'/%3e%3cpath%20fill='%23000'%20d='M24%2018c.38%202.91-5.55%207.37-8%209-3%202-2.82%204.34-5%204-1.04-.94%201.41-3.04%200-3-1%200%20.19%201.23-1%202-1%200-4%201-4-4%200-2%206-12%206-12s1.89-1.9%202-3.5c-.73-1-.5-2-.5-3%201-1%203%202.5%203%202.5h2s.78-2%202.5-3c1%200%201%203%201%203'/%3e%3cpath%20fill='%23ececec'%20stroke='%23ececec'%20d='M9.5%2025.5a.5.5%200%201%201-1%200%20.5.5%200%201%201%201%200m5.43-9.75a.5%201.5%2030%201%201-.86-.5.5%201.5%2030%201%201%20.86.5'/%3e%3cpath%20fill='%23ececec'%20stroke='none'%20d='m24.55%2010.4-.45%201.45.5.15c3.15%201%205.65%202.49%207.9%206.75S35.75%2029.06%2035.25%2039l-.05.5h2.25l.05-.5c.5-10.06-.88-16.85-3.25-21.34s-5.79-6.64-9.19-7.16z'/%3e%3c/g%3e%3c/svg%3e";
var bP_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2045%2045'%3e%3cpath%20fill='%23000'%20stroke='%23000'%20stroke-linecap='round'%20stroke-width='1.5'%20d='M22.5%209a4%204%200%200%200-3.22%206.38%206.48%206.48%200%200%200-.87%2010.65c-3%201.06-7.41%205.55-7.41%2013.47h23c0-7.92-4.41-12.41-7.41-13.47a6.46%206.46%200%200%200-.87-10.65A4.01%204.01%200%200%200%2022.5%209z'/%3e%3c/svg%3e";
var bQ_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cg%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cg%20stroke='none'%3e%3ccircle%20cx='6'%20cy='12'%20r='2.75'/%3e%3ccircle%20cx='14'%20cy='9'%20r='2.75'/%3e%3ccircle%20cx='22.5'%20cy='8'%20r='2.75'/%3e%3ccircle%20cx='31'%20cy='9'%20r='2.75'/%3e%3ccircle%20cx='39'%20cy='12'%20r='2.75'/%3e%3c/g%3e%3cpath%20stroke-linecap='butt'%20d='M9%2026c8.5-1.5%2021-1.5%2027%200l2.5-12.5L31%2025l-.3-14.1-5.2%2013.6-3-14.5-3%2014.5-5.2-13.6L14%2025%206.5%2013.5z'/%3e%3cpath%20stroke-linecap='butt'%20d='M9%2026c0%202%201.5%202%202.5%204%201%201.5%201%201%20.5%203.5-1.5%201-1.5%202.5-1.5%202.5-1.5%201.5.5%202.5.5%202.5%206.5%201%2016.5%201%2023%200%200%200%201.5-1%200-2.5%200%200%20.5-1.5-1-2.5-.5-2.5-.5-2%20.5-3.5%201-2%202.5-2%202.5-4-8.5-1.5-18.5-1.5-27%200z'/%3e%3cpath%20fill='none'%20stroke-linecap='butt'%20d='M11%2038.5a35%2035%201%200%200%2023%200'/%3e%3cpath%20fill='none'%20stroke='%23ececec'%20d='M11%2029a35%2035%201%200%201%2023%200m-21.5%202.5h20m-21%203a35%2035%201%200%200%2022%200m-23%203a35%2035%201%200%200%2024%200'/%3e%3c/g%3e%3c/svg%3e";
var bR_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cg%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cpath%20stroke-linecap='butt'%20d='M9%2039h27v-3H9zm3.5-7%201.5-2.5h17l1.5%202.5zm-.5%204v-4h21v4z'/%3e%3cpath%20stroke-linecap='butt'%20stroke-linejoin='miter'%20d='M14%2029.5v-13h17v13z'/%3e%3cpath%20stroke-linecap='butt'%20d='M14%2016.5%2011%2014h23l-3%202.5zM11%2014V9h4v2h5V9h5v2h5V9h4v5z'/%3e%3cpath%20fill='none'%20stroke='%23ececec'%20stroke-linejoin='miter'%20stroke-width='1'%20d='M12%2035.5h21m-20-4h19m-18-2h17m-17-13h17M11%2014h23'/%3e%3c/g%3e%3c/svg%3e";
var wB_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cg%20fill='none'%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cg%20fill='%23fff'%20stroke-linecap='butt'%3e%3cpath%20d='M9%2036c3.39-.97%2010.11.43%2013.5-2%203.39%202.43%2010.11%201.03%2013.5%202%200%200%201.65.54%203%202-.68.97-1.65.99-3%20.5-3.39-.97-10.11.46-13.5-1-3.39%201.46-10.11.03-13.5%201-1.35.49-2.32.47-3-.5%201.35-1.94%203-2%203-2z'/%3e%3cpath%20d='M15%2032c2.5%202.5%2012.5%202.5%2015%200%20.5-1.5%200-2%200-2%200-2.5-2.5-4-2.5-4%205.5-1.5%206-11.5-5-15.5-11%204-10.5%2014-5%2015.5%200%200-2.5%201.5-2.5%204%200%200-.5.5%200%202z'/%3e%3cpath%20d='M25%208a2.5%202.5%200%201%201-5%200%202.5%202.5%200%201%201%205%200z'/%3e%3c/g%3e%3cpath%20stroke-linejoin='miter'%20d='M17.5%2026h10M15%2030h15m-7.5-14.5v5M20%2018h5'/%3e%3c/g%3e%3c/svg%3e";
var wK_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20viewBox='0%200%2045%2045'%3e%3cg%20fill='none'%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cpath%20stroke-linejoin='miter'%20d='M22.5%2011.63V6M20%208h5'/%3e%3cpath%20fill='%23fff'%20stroke-linecap='butt'%20stroke-linejoin='miter'%20d='M22.5%2025s4.5-7.5%203-10.5c0%200-1-2.5-3-2.5s-3%202.5-3%202.5c-1.5%203%203%2010.5%203%2010.5'/%3e%3cpath%20fill='%23fff'%20d='M11.5%2037c5.5%203.5%2015.5%203.5%2021%200v-7s9-4.5%206-10.5c-4-6.5-13.5-3.5-16%204V27v-3.5c-3.5-7.5-13-10.5-16-4-3%206%205%2010%205%2010z'/%3e%3cpath%20d='M11.5%2030c5.5-3%2015.5-3%2021%200m-21%203.5c5.5-3%2015.5-3%2021%200m-21%203.5c5.5-3%2015.5-3%2021%200'/%3e%3c/g%3e%3c/svg%3e";
var wN_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cg%20fill='none'%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cpath%20fill='%23fff'%20d='M22%2010c10.5%201%2016.5%208%2016%2029H15c0-9%2010-6.5%208-21'/%3e%3cpath%20fill='%23fff'%20d='M24%2018c.38%202.91-5.55%207.37-8%209-3%202-2.82%204.34-5%204-1.042-.94%201.41-3.04%200-3-1%200%20.19%201.23-1%202-1%200-4.003%201-4-4%200-2%206-12%206-12s1.89-1.9%202-3.5c-.73-.994-.5-2-.5-3%201-1%203%202.5%203%202.5h2s.78-1.992%202.5-3c1%200%201%203%201%203'/%3e%3cpath%20fill='%23000'%20d='M9.5%2025.5a.5.5%200%201%201-1%200%20.5.5%200%201%201%201%200m5.433-9.75a.5%201.5%2030%201%201-.866-.5.5%201.5%2030%201%201%20.866.5'/%3e%3c/g%3e%3c/svg%3e";
var wP_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cpath%20fill='%23fff'%20stroke='%23000'%20stroke-linecap='round'%20stroke-width='1.5'%20d='M22.5%209c-2.21%200-4%201.79-4%204%200%20.89.29%201.71.78%202.38C17.33%2016.5%2016%2018.59%2016%2021c0%202.03.94%203.84%202.41%205.03-3%201.06-7.41%205.55-7.41%2013.47h23c0-7.92-4.41-12.41-7.41-13.47%201.47-1.19%202.41-3%202.41-5.03%200-2.41-1.33-4.5-3.28-5.62.49-.67.78-1.49.78-2.38%200-2.21-1.79-4-4-4z'/%3e%3c/svg%3e";
var wQ_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cg%20fill='%23fff'%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cpath%20d='M8%2012a2%202%200%201%201-4%200%202%202%200%201%201%204%200m16.5-4.5a2%202%200%201%201-4%200%202%202%200%201%201%204%200M41%2012a2%202%200%201%201-4%200%202%202%200%201%201%204%200M16%208.5a2%202%200%201%201-4%200%202%202%200%201%201%204%200M33%209a2%202%200%201%201-4%200%202%202%200%201%201%204%200'/%3e%3cpath%20stroke-linecap='butt'%20d='M9%2026c8.5-1.5%2021-1.5%2027%200l2-12-7%2011V11l-5.5%2013.5-3-15-3%2015-5.5-14V25L7%2014z'/%3e%3cpath%20stroke-linecap='butt'%20d='M9%2026c0%202%201.5%202%202.5%204%201%201.5%201%201%20.5%203.5-1.5%201-1.5%202.5-1.5%202.5-1.5%201.5.5%202.5.5%202.5%206.5%201%2016.5%201%2023%200%200%200%201.5-1%200-2.5%200%200%20.5-1.5-1-2.5-.5-2.5-.5-2%20.5-3.5%201-2%202.5-2%202.5-4-8.5-1.5-18.5-1.5-27%200z'/%3e%3cpath%20fill='none'%20d='M11.5%2030c3.5-1%2018.5-1%2022%200M12%2033.5c6-1%2015-1%2021%200'/%3e%3c/g%3e%3c/svg%3e";
var wR_default = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cg%20fill='%23fff'%20fill-rule='evenodd'%20stroke='%23000'%20stroke-linecap='round'%20stroke-linejoin='round'%20stroke-width='1.5'%3e%3cpath%20stroke-linecap='butt'%20d='M9%2039h27v-3H9zm3-3v-4h21v4zm-1-22V9h4v2h5V9h5v2h5V9h4v5'/%3e%3cpath%20d='m34%2014-3%203H14l-3-3'/%3e%3cpath%20stroke-linecap='butt'%20stroke-linejoin='miter'%20d='M31%2017v12.5H14V17'/%3e%3cpath%20d='m31%2029.5%201.5%202.5h-20l1.5-2.5'/%3e%3cpath%20fill='none'%20stroke-linejoin='miter'%20d='M11%2014h23'/%3e%3c/g%3e%3c/svg%3e";
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var SRC = {
	bb: bB_default,
	bk: bK_default,
	bn: bN_default,
	bp: bP_default,
	bq: bQ_default,
	br: bR_default,
	wb: wB_default,
	wk: wK_default,
	wn: wN_default,
	wp: wP_default,
	wq: wQ_default,
	wr: wR_default
};
function pieceSrc(piece) {
	return SRC[`${piece.color}${piece.type}`] ?? "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20style='color-scheme:light%20only'%20width='45'%20height='45'%20viewBox='0%200%2045%2045'%3e%3cpath%20fill='%23fff'%20stroke='%23000'%20stroke-linecap='round'%20stroke-width='1.5'%20d='M22.5%209c-2.21%200-4%201.79-4%204%200%20.89.29%201.71.78%202.38C17.33%2016.5%2016%2018.59%2016%2021c0%202.03.94%203.84%202.41%205.03-3%201.06-7.41%205.55-7.41%2013.47h23c0-7.92-4.41-12.41-7.41-13.47%201.47-1.19%202.41-3%202.41-5.03%200-2.41-1.33-4.5-3.28-5.62.49-.67.78-1.49.78-2.38%200-2.21-1.79-4-4-4z'/%3e%3c/svg%3e";
}
function PieceGlyph({ piece, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: pieceSrc(piece),
		alt: "",
		draggable: false,
		className: cn("piece-shadow pointer-events-none size-full select-none", className)
	});
}
var FILES = [
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h"
];
var ROLE = {
	k: "king",
	q: "queen",
	r: "rook",
	b: "bishop",
	n: "knight",
	p: "pawn"
};
function allSquares() {
	const squares = [];
	for (let rank = 8; rank >= 1; rank--) for (const file of FILES) squares.push(`${file}${rank}`);
	return squares;
}
function samePiece(a, b) {
	if (!a && !b) return true;
	if (!a || !b) return false;
	return a.color === b.color && a.type === b.type;
}
function pieceName(piece) {
	return `${piece.color === "w" ? "White" : "Black"} ${ROLE[piece.type]}`;
}
function piecesFromChess(chess) {
	const map = {};
	const board = chess.board();
	for (let rank = 0; rank < 8; rank++) for (let file = 0; file < 8; file++) {
		const piece = board[rank]?.[file];
		if (!piece) continue;
		const square = `${FILES[file]}${8 - rank}`;
		map[square] = {
			color: piece.color,
			type: piece.type
		};
	}
	return map;
}
function piecesFromFen(fen) {
	return piecesFromChess(new Chess(fen));
}
function isLightSquare(square) {
	return (square.charCodeAt(0) - 97 + Number(square[1])) % 2 === 0;
}
/** A position is usable only if it can be loaded and the side not to move is not in check. */
function isLegalPosition(fen) {
	let chess;
	try {
		chess = new Chess(fen);
	} catch {
		return false;
	}
	const parts = chess.fen().split(" ");
	parts[1] = chess.turn() === "w" ? "b" : "w";
	parts[3] = "-";
	try {
		if (new Chess(parts.join(" ")).inCheck()) return false;
	} catch {
		return false;
	}
	const kings = [];
	for (const square of allSquares()) if (chess.get(square)?.type === "k") kings.push(square);
	if (kings.length !== 2) return false;
	const [a, b] = kings;
	if (!a || !b) return false;
	const fileGap = Math.abs(a.charCodeAt(0) - b.charCodeAt(0));
	const rankGap = Math.abs(Number(a[1]) - Number(b[1]));
	return fileGap > 1 || rankGap > 1;
}
function scorePosition(expected, actual) {
	let correct = 0;
	let missing = 0;
	let wrong = 0;
	let extras = 0;
	let total = 0;
	const correctSquares = [];
	const mistakes = [];
	for (const square of allSquares()) {
		const want = expected[square] ?? null;
		const got = actual[square] ?? null;
		if (want) total += 1;
		if (samePiece(want, got)) {
			if (want) {
				correct += 1;
				correctSquares.push(square);
			}
			continue;
		}
		if (want && !got) {
			missing += 1;
			mistakes.push({
				square,
				kind: "missing",
				expected: want,
				actual: null
			});
		} else if (want && got) {
			wrong += 1;
			mistakes.push({
				square,
				kind: "wrong",
				expected: want,
				actual: got
			});
		} else if (got) {
			extras += 1;
			mistakes.push({
				square,
				kind: "extra",
				expected: null,
				actual: got
			});
		}
	}
	const accuracy = total === 0 ? 0 : Math.max(0, Math.round(correct / (total + extras) * 100));
	return {
		correct,
		missing,
		incorrect: wrong + extras,
		extras,
		total,
		accuracy,
		correctSquares,
		mistakes
	};
}
function formatClock(ms) {
	const totalSeconds = Math.max(0, ms) / 1e3;
	if (totalSeconds < 60) return `${totalSeconds.toFixed(1)}s`;
	const minutes = Math.floor(totalSeconds / 60);
	const seconds = Math.floor(totalSeconds % 60);
	return `${minutes}:${String(seconds).padStart(2, "0")}`;
}
var RANKS_WHITE = [
	"8",
	"7",
	"6",
	"5",
	"4",
	"3",
	"2",
	"1"
];
var RANKS_BLACK = [
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8"
];
function squareFromPoint(x, y) {
	const square = (document.elementFromPoint(x, y)?.closest?.("[data-square]"))?.getAttribute("data-square");
	return square ? square : null;
}
function ChessBoard({ pieces, ghosts, badges, marks, flipped, interactive, armedSquare, liftedSquare, dimPieces = false, label, onSquarePointerDown }) {
	const files = flipped ? [...FILES].reverse() : [...FILES];
	const ranks = flipped ? RANKS_BLACK : RANKS_WHITE;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-raised p-2 shadow-lg ring-1 ring-line sm:p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid w-4 shrink-0 grid-rows-8",
				"aria-hidden": "true",
				children: ranks.map((rank) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex items-center justify-center text-xs font-medium text-muted",
					children: rank
				}, rank))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "grid",
				"aria-label": label,
				"data-testid": "board",
				className: "grid aspect-square min-w-0 flex-1 touch-none grid-cols-8 overflow-hidden rounded-lg select-none",
				children: ranks.map((rank) => files.map((file) => {
					const square = `${file}${rank}`;
					const piece = pieces[square];
					const ghost = ghosts?.[square];
					const badge = badges?.[square];
					const mark = marks?.[square];
					const light = isLightSquare(square);
					const lifted = liftedSquare === square;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "gridcell",
						"data-square": square,
						"data-testid": `square-${square}`,
						"aria-label": squareLabel(square, piece, mark),
						onPointerDown: (event) => {
							if (!interactive) return;
							event.preventDefault();
							onSquarePointerDown?.(square, event);
						},
						className: cn("relative aspect-square", light ? "bg-light" : "bg-darksq", interactive && "cursor-pointer", armedSquare === square && "ring-2 ring-brass ring-inset"),
						children: [
							mark === "correct" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-0 bg-good/30" }),
							mark === "missing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-0 bg-brass/25" }),
							(mark === "wrong" || mark === "extra") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-0 bg-bad/30" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("absolute inset-0 p-1 transition-opacity duration-200 sm:p-1.5", dimPieces && "opacity-0"),
								children: [ghost && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieceGlyph, {
									piece: ghost,
									className: "opacity-60"
								}), piece && !lifted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieceGlyph, { piece })]
							}),
							badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute top-0 right-0 h-2/5 w-2/5 rounded-sm bg-light p-px ring-1 ring-brass",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieceGlyph, { piece: badge })
							})
						]
					}, square);
				}))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex gap-1",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid min-w-0 flex-1 grid-cols-8",
				children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-center text-xs font-medium text-muted",
					children: file
				}, file))
			})]
		})]
	});
}
function squareLabel(square, piece, mark) {
	const occupant = piece ? pieceName(piece) : "empty";
	if (!mark) return `${square}, ${occupant}`;
	return `${square}, ${occupant}, ${mark}`;
}
var SHOWCASE_FEN = "r1bq1rk1/pp2ppbp/2np1np1/2p5/4P3/2NP1NP1/PPP2PBP/R1BQ1RK1 w - - 0 8";
var FALLBACKS = {
	beginner: [
		"4k3/8/2n1p3/8/3B4/4P3/5P2/4K3 w - - 0 1",
		"6k1/5pp1/8/3N4/2B5/8/5P2/6K1 w - - 0 1",
		"4kb2/6p1/4n3/8/3P4/8/6P1/4K3 w - - 0 1",
		"6k1/4pp2/3n4/8/3B4/8/4PP2/6K1 w - - 0 1",
		"2r1k3/8/4n3/3p4/4P3/5N2/8/4K3 w - - 0 1",
		"4k3/pp3p2/8/8/3N4/8/5P2/4K3 w - - 0 1"
	],
	intermediate: [
		"r1bq1rk1/pp2ppbp/2np1np1/2p5/4P3/2NP1NP1/PPP2PBP/R1BQ1RK1 w - - 0 8",
		"r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 4 5",
		"rnbqkb1r/pp2pppp/3p1n2/2p5/4P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 2 4",
		"rnbq1rk1/ppp1ppbp/3p1np1/8/2PPP3/2N2N2/PP3PPP/R1BQKB1R w KQ - 0 6"
	],
	advanced: [
		"r1bqk2r/pp1n1ppp/2pbpn2/3p4/3P4/2NBPN2/PPP2PPP/R1BQK2R w KQkq - 2 7",
		"r1bq1rk1/2ppbppp/p1n2n2/1p2p3/4P3/1B1P1N2/PPP2PPP/RNBQR1K1 w - - 0 9",
		"rnbq1rk1/ppp1ppbp/3p1np1/8/2PPP3/2N2N2/PP3PPP/R1BQKB1R w KQ - 0 6",
		"r1bq1rk1/pp2ppbp/2np1np1/2p5/4P3/2NP1NP1/PPP2PBP/R1BQ1RK1 w - - 0 8"
	]
};
var START_MAP = piecesOf(new Chess());
function rand(min, max) {
	return min + Math.floor(Math.random() * (max - min + 1));
}
function shuffle(items) {
	const copy = [...items];
	for (let i = copy.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		const swap = copy[i];
		copy[i] = copy[j];
		copy[j] = swap;
	}
	return copy;
}
function weighted(items, weight) {
	let total = 0;
	const weights = items.map((item) => {
		const value = Math.max(.001, weight(item));
		total += value;
		return value;
	});
	let roll = Math.random() * total;
	for (let i = 0; i < items.length; i++) {
		roll -= weights[i] ?? 0;
		if (roll <= 0) return items[i];
	}
	return items[items.length - 1];
}
function inspect(chess) {
	const summary = {
		w: 0,
		b: 0,
		total: 0,
		wq: 0,
		bq: 0,
		removable: []
	};
	const board = chess.board();
	for (let rank = 0; rank < 8; rank++) for (let file = 0; file < 8; file++) {
		const piece = board[rank]?.[file];
		if (!piece) continue;
		summary.total += 1;
		if (piece.color === "w") summary.w += 1;
		else summary.b += 1;
		if (piece.type === "q") {
			if (piece.color === "w") summary.wq += 1;
			else summary.bq += 1;
		}
		if (piece.type === "k") continue;
		summary.removable.push({
			sq: `${"abcdefgh"[file]}${8 - rank}`,
			type: piece.type,
			color: piece.color
		});
	}
	return summary;
}
function piecesOf(chess) {
	const map = /* @__PURE__ */ new Map();
	for (const square of allSquares()) {
		const piece = chess.get(square);
		if (piece) map.set(square, `${piece.color}${piece.type}`);
	}
	return map;
}
function displacedCount(chess) {
	const map = piecesOf(chess);
	let diff = 0;
	for (const square of allSquares()) if ((map.get(square) ?? "") !== (START_MAP.get(square) ?? "")) diff += 1;
	return diff;
}
function scoreMove(move, ply, captureBias) {
	let weight = .55 + Math.random();
	const early = ply < 18;
	if (move.piece === "n" || move.piece === "b") weight += early ? 2.5 : .55;
	if (move.piece === "p" && "cde".includes(move.to[0] ?? "")) weight += early ? 1.4 : .25;
	if (move.isKingsideCastle() || move.isQueensideCastle()) weight += 5;
	if (move.piece === "k" && !move.isKingsideCastle() && !move.isQueensideCastle()) weight *= .12;
	if (move.piece === "q" && ply < 10) weight *= .32;
	if (move.piece === "r" && ply < 14 && !move.isCapture()) weight *= .4;
	if (move.isCapture()) weight *= captureBias;
	return weight;
}
var BOOKS = [
	[
		"e4",
		"e5",
		"Nf3",
		"Nc6",
		"Bb5",
		"a6",
		"Ba4",
		"Nf6",
		"O-O",
		"Be7",
		"Re1",
		"b5",
		"Bb3",
		"d6",
		"c3",
		"O-O",
		"h3",
		"Nb8",
		"d4"
	],
	[
		"d4",
		"Nf6",
		"c4",
		"g6",
		"Nc3",
		"Bg7",
		"e4",
		"d6",
		"Nf3",
		"O-O",
		"Be2",
		"e5",
		"O-O",
		"Nc6",
		"d5",
		"Ne7"
	],
	[
		"e4",
		"c5",
		"Nf3",
		"d6",
		"d4",
		"cxd4",
		"Nxd4",
		"Nf6",
		"Nc3",
		"a6",
		"Be3",
		"e5",
		"Nb3",
		"Be6",
		"f3",
		"Be7",
		"Qd2",
		"O-O"
	],
	[
		"e4",
		"e5",
		"Nf3",
		"Nc6",
		"Bc4",
		"Bc5",
		"c3",
		"Nf6",
		"d3",
		"d6",
		"O-O",
		"O-O",
		"Bb3",
		"a6",
		"Nbd2",
		"Be6",
		"Re1"
	],
	[
		"d4",
		"d5",
		"c4",
		"e6",
		"Nc3",
		"Nf6",
		"Nf3",
		"Be7",
		"Bf4",
		"O-O",
		"e3",
		"b6",
		"cxd5",
		"exd5",
		"Bd3",
		"Bb7",
		"O-O"
	],
	[
		"Nf3",
		"Nf6",
		"c4",
		"g6",
		"Nc3",
		"Bg7",
		"g3",
		"O-O",
		"Bg2",
		"d6",
		"O-O",
		"e5",
		"d3",
		"Nc6",
		"Rb1",
		"a5"
	],
	[
		"e4",
		"e6",
		"d4",
		"d5",
		"Nc3",
		"Nf6",
		"Bg5",
		"Be7",
		"e5",
		"Nfd7",
		"Bxe7",
		"Qxe7",
		"f4",
		"O-O",
		"Nf3",
		"c5"
	],
	[
		"e4",
		"c6",
		"d4",
		"d5",
		"Nc3",
		"dxe4",
		"Nxe4",
		"Bf5",
		"Ng3",
		"Bg6",
		"h4",
		"h6",
		"Nf3",
		"Nd7",
		"h5",
		"Bh7",
		"Bd3"
	],
	[
		"d4",
		"d5",
		"Nf3",
		"Nf6",
		"e3",
		"e6",
		"Bd3",
		"c5",
		"c3",
		"Nc6",
		"O-O",
		"Bd6",
		"Nbd2",
		"O-O",
		"dxc5",
		"Bxc5"
	],
	[
		"e4",
		"g6",
		"d4",
		"Bg7",
		"Nc3",
		"d6",
		"f4",
		"Nf6",
		"Nf3",
		"O-O",
		"Bd3",
		"Nc6",
		"O-O"
	],
	[
		"d4",
		"d5",
		"c4",
		"dxc4",
		"Nf3",
		"Nf6",
		"e3",
		"e6",
		"Bxc4",
		"c5",
		"O-O",
		"a6",
		"Qe2",
		"b5"
	],
	[
		"e4",
		"e5",
		"Nf3",
		"Nc6",
		"Bb5",
		"Nf6",
		"O-O",
		"Nxe4",
		"d4",
		"Nd6",
		"Bxc6",
		"dxc6",
		"dxe5",
		"Nf5",
		"Qxd8",
		"Kxd8"
	]
];
function playBook(minPly, maxPly, extra) {
	const line = BOOKS[Math.floor(Math.random() * BOOKS.length)];
	if (!line) return null;
	const chess = new Chess();
	const target = Math.min(line.length, rand(minPly, Math.max(minPly, maxPly)));
	let ply = 0;
	for (const san of line) {
		if (ply >= target) break;
		if (!chess.move(san)) return null;
		ply += 1;
		if (chess.isCheckmate() || chess.isStalemate()) return null;
	}
	for (let i = 0; i < extra; i++) {
		const moves = chess.moves({ verbose: true }).filter((move) => {
			if (move.isCapture() || move.isPromotion()) return false;
			if (move.piece === "q") return false;
			if (move.piece === "k" && !move.isKingsideCastle() && !move.isQueensideCastle()) return false;
			return true;
		});
		if (moves.length === 0) break;
		const chosen = weighted(moves, (move) => scoreMove(move, ply, .2));
		chess.move({
			from: chosen.from,
			to: chosen.to,
			promotion: chosen.promotion
		});
		ply += 1;
		if (chess.isCheckmate() || chess.isStalemate()) return null;
	}
	return {
		chess,
		ply
	};
}
function tryRemove(chess, square) {
	const next = new Chess(chess.fen());
	const piece = next.get(square);
	if (!piece || piece.type === "k") return null;
	next.remove(square);
	const fen = next.fen();
	if (!isLegalPosition(fen)) return null;
	return new Chess(fen);
}
function stripTo(chess, target) {
	let current = chess;
	let guard = 48;
	while (inspect(current).total > target && guard > 0) {
		guard -= 1;
		const summary = inspect(current);
		if (summary.removable.length === 0) return null;
		let pool = summary.removable;
		if (summary.w > summary.b + 1) {
			const side = pool.filter((piece) => piece.color === "w");
			if (side.length > 0) pool = side;
		} else if (summary.b > summary.w + 1) {
			const side = pool.filter((piece) => piece.color === "b");
			if (side.length > 0) pool = side;
		}
		const order = [
			"q",
			"r",
			"n",
			"b",
			"p"
		];
		let chosen = pool;
		for (const type of order) {
			const ofType = pool.filter((piece) => piece.type === type);
			if (ofType.length > 0) {
				chosen = ofType;
				break;
			}
		}
		const pick = chosen[Math.floor(Math.random() * chosen.length)];
		if (!pick) return null;
		const removed = tryRemove(current, pick.sq);
		if (removed) {
			current = removed;
			continue;
		}
		let progressed = false;
		for (const candidate of shuffle(summary.removable)) {
			const alt = tryRemove(current, candidate.sq);
			if (!alt) continue;
			current = alt;
			progressed = true;
			break;
		}
		if (!progressed) return null;
	}
	return inspect(current).total <= target ? current : null;
}
function pack(chess, ply, source) {
	return {
		fen: chess.fen(),
		ply,
		pieceCount: inspect(chess).total,
		turn: chess.turn(),
		source
	};
}
function acceptable(chess, difficulty) {
	if (!isLegalPosition(chess.fen())) return false;
	if (chess.isCheckmate() || chess.isStalemate()) return false;
	const summary = inspect(chess);
	if (summary.wq > 1 || summary.bq > 1) return false;
	if (difficulty === "beginner") return summary.total >= 6 && summary.total <= 10 && summary.w >= 2 && summary.b >= 2 && !chess.inCheck();
	if (difficulty === "intermediate") return summary.total >= 24 && summary.total <= 32 && summary.w >= 10 && summary.b >= 10 && displacedCount(chess) >= 8;
	return summary.total >= 28 && summary.w >= 13 && summary.b >= 13 && summary.wq >= 1 && summary.bq >= 1 && displacedCount(chess) >= 10;
}
function fallback(difficulty) {
	const choices = FALLBACKS[difficulty];
	const fen = choices[Math.floor(Math.random() * choices.length)] ?? choices[0] ?? "r1bq1rk1/pp2ppbp/2np1np1/2p5/4P3/2NP1NP1/PPP2PBP/R1BQ1RK1 w - - 0 8";
	return pack(new Chess(fen), 0, "fallback");
}
function generateOrFallback(difficulty) {
	for (let attempt = 0; attempt < 40; attempt++) {
		if (difficulty === "beginner") {
			const played = playBook(8, 14, 0);
			if (!played) continue;
			const stripped = stripTo(played.chess, rand(6, 9));
			if (!stripped || !acceptable(stripped, difficulty)) continue;
			return pack(stripped, played.ply, "played");
		}
		if (difficulty === "intermediate") {
			const played = playBook(10, 18, rand(0, 3));
			if (!played || !acceptable(played.chess, difficulty)) continue;
			return pack(played.chess, played.ply, "played");
		}
		const played = playBook(12, 19, rand(0, 2));
		if (!played || !acceptable(played.chess, difficulty)) continue;
		return pack(played.chess, played.ply, "played");
	}
	return fallback(difficulty);
}
function generatePosition(difficulty) {
	try {
		return generateOrFallback(difficulty);
	} catch {
		return fallback(difficulty);
	}
}
var DURATIONS = [
	3,
	5,
	10,
	15
];
var DEFAULT_DURATION = {
	beginner: 10,
	intermediate: 5,
	advanced: 3
};
function isDifficulty(value) {
	return value === "beginner" || value === "intermediate" || value === "advanced";
}
function isDuration(value) {
	return value === 3 || value === 5 || value === 10 || value === 15;
}
var KEY = "chess-memory-trainer-v1";
var BACKUP = "chess-memory-trainer-v1-backup";
function dayKey(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function previousDay(key) {
	const [year, month, day] = key.split("-").map(Number);
	const date = new Date(year || 1970, (month || 1) - 1, day || 1);
	date.setDate(date.getDate() - 1);
	return dayKey(date);
}
function defaultSave() {
	return {
		version: 1,
		streak: 0,
		lastDay: null,
		bestAccuracy: 0,
		accuracySum: 0,
		sessions: 0,
		history: [],
		difficulty: "intermediate",
		duration: 5
	};
}
function finiteNumber(value, fallback = 0) {
	return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
function isSession(value) {
	if (!value || typeof value !== "object") return false;
	const session = value;
	return typeof session.at === "number" && isDifficulty(session.difficulty) && isDuration(session.duration) && typeof session.accuracy === "number" && typeof session.correct === "number" && typeof session.total === "number";
}
function normalize(raw) {
	const base = defaultSave();
	if (!raw || typeof raw !== "object") return base;
	const data = raw;
	const history = Array.isArray(data.history) ? data.history.filter(isSession).slice(0, 40) : [];
	const lastDay = typeof data.lastDay === "string" && /^\d{4}-\d{2}-\d{2}$/.test(data.lastDay) ? data.lastDay : null;
	return {
		version: 1,
		streak: Math.max(0, Math.round(finiteNumber(data.streak))),
		lastDay,
		bestAccuracy: Math.min(100, Math.max(0, Math.round(finiteNumber(data.bestAccuracy)))),
		accuracySum: Math.max(0, finiteNumber(data.accuracySum)),
		sessions: Math.max(0, Math.round(finiteNumber(data.sessions))),
		history,
		difficulty: isDifficulty(data.difficulty) ? data.difficulty : base.difficulty,
		duration: isDuration(data.duration) ? data.duration : base.duration
	};
}
function loadSave() {
	if (typeof localStorage === "undefined") return defaultSave();
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return defaultSave();
		return normalize(JSON.parse(raw));
	} catch {
		try {
			const backup = localStorage.getItem(BACKUP);
			if (!backup) return defaultSave();
			return normalize(JSON.parse(backup));
		} catch {
			return defaultSave();
		}
	}
}
function writeSave(save) {
	if (typeof localStorage === "undefined") return;
	try {
		const previous = localStorage.getItem(KEY);
		if (previous) localStorage.setItem(BACKUP, previous);
		localStorage.setItem(KEY, JSON.stringify(save));
	} catch {}
}
function visibleStreak(save, today = dayKey()) {
	if (!save.lastDay || save.streak <= 0) return 0;
	if (save.lastDay === today || save.lastDay === previousDay(today)) return save.streak;
	return 0;
}
function averageAccuracy(save) {
	if (save.sessions <= 0) return null;
	return Math.round(save.accuracySum / save.sessions);
}
function applySession(save, session, today = dayKey()) {
	let streak = 1;
	if (save.lastDay === today) streak = Math.max(1, save.streak);
	else if (save.lastDay === previousDay(today)) streak = Math.max(1, save.streak) + 1;
	return {
		...save,
		streak,
		lastDay: today,
		sessions: save.sessions + 1,
		accuracySum: save.accuracySum + session.accuracy,
		bestAccuracy: Math.max(save.bestAccuracy, session.accuracy),
		history: [session, ...save.history].slice(0, 40),
		difficulty: session.difficulty,
		duration: session.duration
	};
}
var DIFFICULTIES = [
	{
		id: "beginner",
		label: "Beginner",
		hint: "Fewer pieces, and a longer look."
	},
	{
		id: "intermediate",
		label: "Intermediate",
		hint: "A middlegame you might actually reach."
	},
	{
		id: "advanced",
		label: "Advanced",
		hint: "A crowded board. A short glance."
	}
];
var PALETTE = [
	{
		color: "w",
		type: "k"
	},
	{
		color: "w",
		type: "q"
	},
	{
		color: "w",
		type: "r"
	},
	{
		color: "w",
		type: "b"
	},
	{
		color: "w",
		type: "n"
	},
	{
		color: "w",
		type: "p"
	},
	{
		color: "b",
		type: "k"
	},
	{
		color: "b",
		type: "q"
	},
	{
		color: "b",
		type: "r"
	},
	{
		color: "b",
		type: "b"
	},
	{
		color: "b",
		type: "n"
	},
	{
		color: "b",
		type: "p"
	}
];
function TrainerApp() {
	const showcase = (0, import_react.useMemo)(() => piecesFromFen(SHOWCASE_FEN), []);
	const [save, setSave] = (0, import_react.useState)(defaultSave);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [difficulty, setDifficulty] = (0, import_react.useState)("intermediate");
	const [duration, setDuration] = (0, import_react.useState)(5);
	const [phase, setPhase] = (0, import_react.useState)("home");
	const [puzzle, setPuzzle] = (0, import_react.useState)(null);
	const [puzzlePieces, setPuzzlePieces] = (0, import_react.useState)(showcase);
	const [userPieces, setUserPieces] = (0, import_react.useState)({});
	const [flipped, setFlipped] = (0, import_react.useState)(false);
	const [remaining, setRemaining] = (0, import_react.useState)(duration * 1e3);
	const [fading, setFading] = (0, import_react.useState)(false);
	const [studiedMs, setStudiedMs] = (0, import_react.useState)(0);
	const [recallElapsed, setRecallElapsed] = (0, import_react.useState)(0);
	const [score, setScore] = (0, import_react.useState)(null);
	const [review, setReview] = (0, import_react.useState)("compare");
	const [newBest, setNewBest] = (0, import_react.useState)(false);
	const [armed, setArmed] = (0, import_react.useState)(null);
	const [lifted, setLifted] = (0, import_react.useState)(null);
	const [undoCount, setUndoCount] = (0, import_react.useState)(0);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	const boardRef = (0, import_react.useRef)({});
	const undoStack = (0, import_react.useRef)([]);
	const recallStartRef = (0, import_react.useRef)(0);
	const remainingRef = (0, import_react.useRef)(duration * 1e3);
	const fadeTimer = (0, import_react.useRef)(null);
	const studyTimer = (0, import_react.useRef)(null);
	const gesture = (0, import_react.useRef)(false);
	const ghostRef = (0, import_react.useRef)(null);
	const ghostImgRef = (0, import_react.useRef)(null);
	const ghostPos = (0, import_react.useRef)({
		x: -200,
		y: -200,
		visible: false,
		src: pieceSrc({
			color: "w",
			type: "k"
		})
	});
	const [round, setRound] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const loaded = loadSave();
		setSave(loaded);
		setDifficulty(loaded.difficulty);
		setDuration(loaded.duration);
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		setSave((current) => {
			if (current.difficulty === difficulty && current.duration === duration) return current;
			const next = {
				...current,
				difficulty,
				duration
			};
			writeSave(next);
			return next;
		});
	}, [
		difficulty,
		duration,
		hydrated
	]);
	(0, import_react.useEffect)(() => {
		if (phase !== "study") return;
		const endsAt = performance.now() + duration * 1e3;
		remainingRef.current = duration * 1e3;
		setRemaining(duration * 1e3);
		studyTimer.current = window.setInterval(() => {
			const left = Math.max(0, endsAt - performance.now());
			remainingRef.current = left;
			setRemaining(left);
			if (left <= 0) {
				if (studyTimer.current != null) {
					window.clearInterval(studyTimer.current);
					studyTimer.current = null;
				}
				beginRecall(duration * 1e3);
			}
		}, 80);
		return () => {
			if (studyTimer.current != null) {
				window.clearInterval(studyTimer.current);
				studyTimer.current = null;
			}
		};
	}, [
		phase,
		round,
		duration
	]);
	(0, import_react.useEffect)(() => {
		if (phase !== "recall") return;
		const id = window.setInterval(() => {
			setRecallElapsed(performance.now() - recallStartRef.current);
		}, 200);
		return () => window.clearInterval(id);
	}, [phase, puzzle?.fen]);
	(0, import_react.useLayoutEffect)(() => {
		const shell = ghostRef.current;
		const image = ghostImgRef.current;
		if (!shell || !image) return;
		image.src = ghostPos.current.src;
		shell.style.opacity = ghostPos.current.visible ? "1" : "0";
		shell.style.transform = `translate3d(${ghostPos.current.x}px, ${ghostPos.current.y}px, 0)`;
	});
	(0, import_react.useEffect)(() => {
		return () => {
			if (fadeTimer.current != null) window.clearTimeout(fadeTimer.current);
		};
	}, []);
	function placeGhost(piece, x, y, visible) {
		ghostPos.current = {
			x: x - 32,
			y: y - 58,
			visible,
			src: pieceSrc(piece)
		};
		const shell = ghostRef.current;
		const image = ghostImgRef.current;
		if (!shell || !image) return;
		if (image.src !== ghostPos.current.src) image.src = ghostPos.current.src;
		shell.style.opacity = visible ? "1" : "0";
		shell.style.transform = `translate3d(${ghostPos.current.x}px, ${ghostPos.current.y}px, 0)`;
	}
	function hideGhost() {
		ghostPos.current.visible = false;
		const shell = ghostRef.current;
		if (shell) shell.style.opacity = "0";
	}
	function resetBoard() {
		boardRef.current = {};
		undoStack.current = [];
		setUserPieces({});
		setUndoCount(0);
		setArmed(null);
		setLifted(null);
	}
	function setBoard(next, recordUndo) {
		if (recordUndo) undoStack.current.push(boardRef.current);
		boardRef.current = next;
		setUserPieces(next);
		setUndoCount(undoStack.current.length);
	}
	function place(square, piece, from) {
		const next = { ...boardRef.current };
		if (from && from !== square) delete next[from];
		next[square] = piece;
		setBoard(next, true);
		setArmed(null);
		setLifted(null);
	}
	function removeSquare(square) {
		if (!boardRef.current[square]) {
			setArmed(null);
			return;
		}
		const next = { ...boardRef.current };
		delete next[square];
		setBoard(next, true);
		setArmed(null);
	}
	function undo() {
		const previous = undoStack.current.pop();
		if (!previous) return;
		boardRef.current = previous;
		setUserPieces(previous);
		setUndoCount(undoStack.current.length);
		setArmed(null);
	}
	function clearBoard() {
		if (Object.keys(boardRef.current).length === 0) return;
		setBoard({}, true);
		setArmed(null);
	}
	function tapSquare(square) {
		const occupant = boardRef.current[square];
		if (armed) {
			if (armed.from === square) {
				removeSquare(square);
				return;
			}
			place(square, armed.piece, armed.from);
			return;
		}
		if (occupant) setArmed({
			piece: occupant,
			from: square
		});
	}
	function armPalette(piece) {
		setArmed((current) => current && current.from == null && samePiece(current.piece, piece) ? null : {
			piece,
			from: null
		});
	}
	function onSquarePointerDown(square, event) {
		if (phase !== "recall" || gesture.current) return;
		const piece = boardRef.current[square];
		gesture.current = true;
		const startX = event.clientX;
		const startY = event.clientY;
		let dragging = false;
		if (piece) placeGhost(piece, startX, startY, false);
		const move = (ev) => {
			if (Math.hypot(ev.clientX - startX, ev.clientY - startY) <= 8) return;
			if (!dragging) {
				dragging = true;
				if (piece) setLifted(square);
			}
			if (piece) {
				ev.preventDefault();
				placeGhost(piece, ev.clientX, ev.clientY, true);
			}
		};
		const up = (ev) => {
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", up);
			gesture.current = false;
			hideGhost();
			setLifted(null);
			if (!dragging) {
				tapSquare(square);
				return;
			}
			if (!piece) return;
			const target = squareFromPoint(ev.clientX, ev.clientY);
			if (!target) {
				removeSquare(square);
				return;
			}
			if (target !== square) place(target, piece, square);
		};
		window.addEventListener("pointermove", move, { passive: false });
		window.addEventListener("pointerup", up);
	}
	function onPalettePointerDown(piece, event) {
		if (phase !== "recall" || gesture.current) return;
		event.preventDefault();
		gesture.current = true;
		const startX = event.clientX;
		const startY = event.clientY;
		let dragging = false;
		placeGhost(piece, startX, startY, false);
		const move = (ev) => {
			if (Math.hypot(ev.clientX - startX, ev.clientY - startY) <= 8) return;
			dragging = true;
			ev.preventDefault();
			placeGhost(piece, ev.clientX, ev.clientY, true);
		};
		const up = (ev) => {
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", up);
			gesture.current = false;
			hideGhost();
			if (!dragging) {
				armPalette(piece);
				return;
			}
			const target = squareFromPoint(ev.clientX, ev.clientY);
			if (target) place(target, piece, null);
		};
		window.addEventListener("pointermove", move, { passive: false });
		window.addEventListener("pointerup", up);
	}
	function beginRecall(studied) {
		if (studyTimer.current != null) {
			window.clearInterval(studyTimer.current);
			studyTimer.current = null;
		}
		if (fadeTimer.current != null) return;
		const reduced = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const finish = () => {
			fadeTimer.current = null;
			setFading(false);
			resetBoard();
			setStudiedMs(studied);
			recallStartRef.current = performance.now();
			setRecallElapsed(0);
			setScore(null);
			setReview("compare");
			setPhase("recall");
		};
		if (reduced) {
			finish();
			return;
		}
		setFading(true);
		fadeTimer.current = window.setTimeout(finish, 240);
	}
	function hideNow() {
		if (phase !== "study" || fadeTimer.current != null) return;
		beginRecall(Math.max(0, duration * 1e3 - remainingRef.current));
	}
	function startPuzzle(next) {
		if (fadeTimer.current != null) {
			window.clearTimeout(fadeTimer.current);
			fadeTimer.current = null;
		}
		const position = next ?? generatePosition(difficulty);
		setPuzzle(position);
		setPuzzlePieces(piecesFromFen(position.fen));
		resetBoard();
		setFading(false);
		setScore(null);
		setNewBest(false);
		setReview("compare");
		setRemaining(duration * 1e3);
		remainingRef.current = duration * 1e3;
		setRound((value) => value + 1);
		setPhase("study");
	}
	function goHome() {
		if (fadeTimer.current != null) {
			window.clearTimeout(fadeTimer.current);
			fadeTimer.current = null;
		}
		setFading(false);
		setPhase("home");
		setArmed(null);
		setLifted(null);
	}
	function submit() {
		if (!puzzle || phase !== "recall") return;
		const recallMs = Math.max(0, performance.now() - recallStartRef.current);
		const nextScore = scorePosition(puzzlePieces, boardRef.current);
		const previousBest = save.bestAccuracy;
		const hadSessions = save.sessions > 0;
		const session = {
			at: Date.now(),
			difficulty,
			duration,
			accuracy: nextScore.accuracy,
			correct: nextScore.correct,
			total: nextScore.total,
			missing: nextScore.missing,
			incorrect: nextScore.incorrect,
			recallMs,
			studiedMs
		};
		const nextSave = applySession(save, session);
		writeSave(nextSave);
		setSave(nextSave);
		setScore(nextScore);
		setRecallElapsed(recallMs);
		setNewBest(hadSessions && nextScore.accuracy > previousBest);
		setReview("compare");
		setArmed(null);
		setPhase("result");
	}
	function chooseDifficulty(next) {
		setDifficulty(next);
		setDuration(DEFAULT_DURATION[next]);
		setConfirmReset(false);
	}
	function resetProgress() {
		const next = {
			...defaultSave(),
			difficulty,
			duration
		};
		writeSave(next);
		setSave(next);
		setConfirmReset(false);
	}
	const streak = visibleStreak(save);
	const average = averageAccuracy(save);
	const placed = Object.keys(userPieces).length;
	const activeMeta = DIFFICULTIES.find((item) => item.id === difficulty) ?? DIFFICULTIES[1];
	const turnLabel = puzzle?.turn === "b" ? "Black to move" : "White to move";
	const marks = {};
	const ghosts = {};
	const badges = {};
	if (phase === "result" && score && review === "compare") {
		for (const square of score.correctSquares) marks[square] = "correct";
		for (const mistake of score.mistakes) {
			marks[mistake.square] = mistake.kind;
			if (mistake.kind === "missing" && mistake.expected) ghosts[mistake.square] = mistake.expected;
			if (mistake.kind === "wrong" && mistake.expected) badges[mistake.square] = mistake.expected;
		}
	}
	const displayPieces = phase === "home" ? showcase : phase === "study" ? puzzlePieces : phase === "result" && review === "solution" ? puzzlePieces : userPieces;
	const boardLabel = phase === "study" ? "Position to memorize" : phase === "recall" ? "Blank board. Rebuild the position" : phase === "result" ? "Reviewed position" : "Sample middlegame";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-6xl flex-col px-4 pt-4 pb-28 lg:px-8 lg:pt-8 lg:pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [phase !== "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Back to setup",
						onClick: goHome,
						className: "grid size-11 shrink-0 place-items-center rounded-full border border-line bg-surface text-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-brass uppercase",
							children: "Board memory"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-2xl leading-none text-balance text-fg sm:text-4xl",
							children: ["Chess ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-brass italic",
								children: "Memory"
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 items-center gap-2 rounded-full border border-line bg-surface px-3 py-2",
					"aria-label": streak > 0 ? `${streak} day streak` : "No streak yet",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: cn("size-4", streak > 0 ? "text-brass" : "text-muted") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium text-fg tabular-nums",
							children: streak
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-sm text-muted lg:inline",
							children: "day streak"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-5 lg:grid-cols-[minmax(0,36rem)_minmax(18rem,1fr)] lg:gap-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-w-0 lg:sticky lg:top-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChessBoard, {
						pieces: displayPieces,
						ghosts,
						badges,
						marks,
						flipped,
						interactive: phase === "recall",
						armedSquare: armed?.from ?? null,
						liftedSquare: lifted,
						dimPieces: fading,
						label: boardLabel,
						onSquarePointerDown
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								phase === "home" && "A quiet sample. Your drill starts blank after the timer.",
								phase === "study" && `${activeMeta.label} · ${turnLabel}`,
								phase === "recall" && `${placed} placed · ${formatClock(recallElapsed)}`,
								phase === "result" && (score ? `${score.correct} of ${score.total} pieces on the right squares` : "")
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setFlipped((value) => !value),
							className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-3 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownUp, { className: "size-4" }), "Flip"]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-w-0 flex-col gap-5",
					children: [
						phase === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePanel, {
							difficulty,
							duration,
							save,
							average,
							confirmReset,
							onDifficulty: chooseDifficulty,
							onDuration: (value) => {
								setDuration(value);
								setConfirmReset(false);
							},
							onResetAsk: () => setConfirmReset(true),
							onResetCancel: () => setConfirmReset(false),
							onResetConfirm: resetProgress
						}),
						phase === "study" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudyPanel, {
							remaining,
							duration,
							hint: activeMeta.hint
						}),
						phase === "recall" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecallPanel, {
							armed,
							undoCount,
							onPalettePointerDown,
							onUndo: undo,
							onClear: clearBoard
						}),
						phase === "result" && score && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, {
							score,
							recallElapsed,
							studiedMs,
							review,
							newBest,
							onReview: setReview
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 backdrop-blur lg:static lg:z-auto lg:border-0 lg:bg-transparent lg:p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto flex w-full max-w-6xl gap-2 px-4 py-3 lg:max-w-none lg:px-0",
								children: [
									phase === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"data-testid": "start",
										onClick: () => startPuzzle(),
										className: "min-h-12 flex-1 rounded-xl bg-brass px-4 text-base font-semibold text-brass-ink",
										children: "Start practice"
									}),
									phase === "study" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"data-testid": "hide-now",
										onClick: hideNow,
										className: "min-h-12 flex-1 rounded-xl bg-brass px-4 text-base font-semibold text-brass-ink",
										children: "Hide pieces now"
									}),
									phase === "recall" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"data-testid": "check",
										onClick: submit,
										className: "min-h-12 flex-1 rounded-xl bg-brass px-4 text-base font-semibold text-brass-ink",
										children: "Check memory"
									}),
									phase === "result" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => puzzle && startPuzzle(puzzle),
										className: "inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-3 text-sm font-semibold text-fg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Retry"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => startPuzzle(),
										className: "min-h-12 flex-1 rounded-xl bg-brass px-3 text-sm font-semibold text-brass-ink",
										children: "New position"
									})] })
								]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: ghostRef,
				className: "pointer-events-none fixed top-0 left-0 z-50 size-16 opacity-0",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					ref: ghostImgRef,
					src: pieceSrc({
						color: "w",
						type: "k"
					}),
					alt: "",
					draggable: false,
					className: "piece-shadow size-full"
				})
			})
		]
	});
}
function HomePanel({ difficulty, duration, save, average, confirmReset, onDifficulty, onDuration, onResetAsk, onResetCancel, onResetConfirm }) {
	const meta = DIFFICULTIES.find((item) => item.id === difficulty);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-balance text-fg",
				children: "Hold the position, then rebuild it."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-pretty text-muted",
				children: "A legal position appears for a few seconds. When it vanishes, drag the pieces back onto the same squares."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-medium text-fg",
						children: "Difficulty"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-1 rounded-xl bg-surface p-1",
						role: "radiogroup",
						"aria-label": "Difficulty",
						children: DIFFICULTIES.map((item) => {
							const selected = item.id === difficulty;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "radio",
								"aria-checked": selected,
								onClick: () => onDifficulty(item.id),
								className: cn("min-h-11 rounded-lg px-1 text-center text-sm leading-tight font-medium", selected ? "bg-brass text-brass-ink" : "text-muted"),
								children: item.label
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: meta?.hint
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-sm font-medium text-fg",
					children: "Display time"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-1 rounded-xl bg-surface p-1",
					role: "radiogroup",
					"aria-label": "Display time",
					children: DURATIONS.map((value) => {
						const selected = value === duration;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							role: "radio",
							"aria-checked": selected,
							onClick: () => onDuration(value),
							className: cn("min-h-11 rounded-lg text-sm font-medium tabular-nums", selected ? "bg-brass text-brass-ink" : "text-muted"),
							children: [value, "s"]
						}, value);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Best",
						value: save.sessions > 0 ? `${save.bestAccuracy}%` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Average",
						value: average == null ? "—" : `${average}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Sessions",
						value: String(save.sessions)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-medium text-fg",
				children: "Recent"
			}), save.history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Finish a board and it will land here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 flex flex-col gap-2",
				children: save.history.slice(0, 5).map((session) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 rounded-xl border border-line bg-surface px-3 py-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg capitalize",
							children: session.difficulty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted tabular-nums",
							children: formatClock(session.recallMs)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-medium text-brass tabular-nums",
							children: [session.accuracy, "%"]
						})
					]
				}, session.at))
			})] }),
			confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "Erase saved stats on this device?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onResetConfirm,
						className: "min-h-11 rounded-lg px-3 text-bad",
						children: "Erase"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onResetCancel,
						className: "min-h-11 rounded-lg px-3 text-fg",
						children: "Cancel"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onResetAsk,
				className: "self-start text-sm text-muted",
				children: "Reset progress"
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-display text-2xl text-fg tabular-nums",
			children: value
		})]
	});
}
function StudyPanel({ remaining, duration, hint }) {
	const progress = duration === 0 ? 0 : remaining / (duration * 1e3);
	const seconds = Math.max(0, Math.ceil(remaining / 1e3));
	const radius = 18;
	const circumference = 2 * Math.PI * radius;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-fg",
				children: "Memorize"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm leading-relaxed text-pretty text-muted",
				children: [hint, " The board clears when the clock ends."]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 44 44",
					className: "size-16 shrink-0",
					"aria-hidden": "true",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "22",
						cy: "22",
						r: radius,
						fill: "none",
						className: "stroke-line",
						strokeWidth: "3"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "22",
						cy: "22",
						r: radius,
						fill: "none",
						className: "stroke-brass",
						strokeWidth: "3",
						strokeLinecap: "round",
						strokeDasharray: circumference,
						strokeDashoffset: circumference * (1 - progress),
						transform: "rotate(-90 22 22)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-5xl text-fg tabular-nums",
					"data-testid": "timer",
					children: seconds
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "seconds left"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-1.5 overflow-hidden rounded-full bg-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-brass",
					style: { width: `${Math.max(0, Math.min(100, progress * 100))}%` }
				})
			})
		]
	});
}
function RecallPanel({ armed, undoCount, onPalettePointerDown, onUndo, onClear }) {
	const hint = armed ? armed.from ? `Tap a square to move the ${pieceName(armed.piece).toLowerCase()}, or tap it again to remove it.` : `Tap a square to place the ${pieceName(armed.piece).toLowerCase()}. Tap the piece again to cancel.` : "Drag a piece onto a square, or tap a piece and then a square.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-fg",
				children: "Rebuild"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-pretty text-muted",
				children: hint
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium text-fg",
					children: "Piece tray"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onUndo,
						disabled: undoCount === 0,
						className: "inline-flex min-h-11 items-center gap-1 rounded-lg px-3 text-sm text-fg disabled:opacity-40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "size-4" }), "Undo"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClear,
						className: "min-h-11 rounded-lg px-3 text-sm text-fg",
						children: "Clear"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "touch-none rounded-2xl border border-line bg-surface p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaletteRow, {
						color: "w",
						label: "White",
						armed,
						onPointerDown: onPalettePointerDown
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-line" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaletteRow, {
						color: "b",
						label: "Black",
						armed,
						onPointerDown: onPalettePointerDown
					})
				]
			})
		]
	});
}
function PaletteRow({ color, label, armed, onPointerDown }) {
	const pieces = PALETTE.filter((piece) => piece.color === color);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-6 gap-1",
			children: pieces.map((piece) => {
				const selected = armed?.from == null && armed != null && samePiece(armed.piece, piece);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": pieceName(piece),
					"aria-pressed": selected,
					"data-testid": `palette-${piece.color}${piece.type}`,
					onPointerDown: (event) => onPointerDown(piece, event),
					onContextMenu: (event) => event.preventDefault(),
					className: cn("grid aspect-square min-h-11 place-items-center rounded-lg bg-raised p-1", selected && "ring-2 ring-brass"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieceGlyph, { piece })
				}, `${piece.color}${piece.type}`);
			})
		})]
	});
}
function ResultPanel({ score, recallElapsed, studiedMs, review, newBest, onReview }) {
	const tone = score.accuracy >= 90 ? "text-good" : score.accuracy >= 60 ? "text-brass" : "text-bad";
	const headline = score.accuracy === 100 ? "You rebuilt it." : score.accuracy >= 80 ? "Close." : "Not quite.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-fg",
				children: headline
			}), newBest && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-brass",
				children: "New best accuracy."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("font-display text-6xl leading-none tabular-nums", tone),
				"data-testid": "accuracy",
				children: [score.accuracy, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-3xl",
					children: "%"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Studied ",
					formatClock(studiedMs),
					" · rebuilt in ",
					formatClock(recallElapsed)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Correct",
						value: String(score.correct)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Missing",
						value: String(score.missing)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Incorrect",
						value: String(score.incorrect)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-pretty text-muted",
				children: "Accuracy is pieces on the right squares, divided by the original pieces plus any extras."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-1 rounded-xl bg-surface p-1",
				role: "radiogroup",
				"aria-label": "Board review",
				children: [
					["compare", "Review"],
					["solution", "Solution"],
					["yours", "Yours"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "radio",
					"aria-checked": review === id,
					onClick: () => onReview(id),
					className: cn("min-h-11 rounded-lg text-sm font-medium", review === id ? "bg-brass text-brass-ink" : "text-muted"),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "flex flex-wrap gap-3 text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm bg-good" }), " Correct"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm bg-brass" }), " Missing"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm bg-bad" }), " Incorrect"]
					})
				]
			}),
			score.mistakes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg",
				children: "Every piece landed on its square."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex max-h-56 flex-col gap-2 overflow-auto pr-1",
				children: score.mistakes.map((mistake) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "text-sm leading-snug text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-brass tabular-nums",
							children: mistake.square
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: mistakeCopy(mistake)
						})
					]
				}, `${mistake.kind}-${mistake.square}`))
			})
		]
	});
}
function mistakeCopy(mistake) {
	if (mistake.kind === "missing" && mistake.expected) return `missing ${pieceName(mistake.expected).toLowerCase()}`;
	if (mistake.kind === "extra" && mistake.actual) return `extra ${pieceName(mistake.actual).toLowerCase()}`;
	if (mistake.expected && mistake.actual) return `placed ${pieceName(mistake.actual).toLowerCase()}, expected ${pieceName(mistake.expected).toLowerCase()}`;
	return "incorrect";
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrainerApp, {});
}
//#endregion
export { Home as component };
