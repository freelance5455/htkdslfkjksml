import { n as __exportAll$1 } from "../_runtime.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-D0BjXlW4.js
var catalog_D0BjXlW4_exports = /* @__PURE__ */ __exportAll$1({
	a: () => matchInstrument,
	i: () => findCatalog,
	n: () => FALLBACK_FX,
	o: () => __exportAll,
	r: () => catalog_exports,
	t: () => CATALOG
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var catalog_exports = /* @__PURE__ */ __exportAll({
	CATALOG: () => CATALOG,
	FALLBACK_FX: () => FALLBACK_FX,
	catalogByIsin: () => catalogByIsin,
	findCatalog: () => findCatalog,
	instrumentsFrom: () => instrumentsFrom,
	matchInstrument: () => matchInstrument
});
var CATALOG = [
	{
		symbol: "VWCE",
		name: "Vanguard FTSE All-World",
		assetClass: "etf",
		currency: "EUR",
		yahoo: "VWCE.DE",
		isin: "IE00BK5BQT80",
		fallback: 170.44
	},
	{
		symbol: "VWRA",
		name: "Vanguard FTSE All-World (USD)",
		assetClass: "etf",
		currency: "USD",
		yahoo: "VWRA.L",
		isin: "IE00BK5BQT80",
		fallback: 191.68
	},
	{
		symbol: "SXR8",
		name: "iShares Core S&P 500",
		assetClass: "etf",
		currency: "EUR",
		yahoo: "SXR8.DE",
		isin: "IE00B5BMR087",
		fallback: 740.78
	},
	{
		symbol: "CSPX",
		name: "iShares Core S&P 500 (USD)",
		assetClass: "etf",
		currency: "USD",
		yahoo: "CSPX.L",
		isin: "IE00B5BMR087",
		fallback: 832.99
	},
	{
		symbol: "VUAA",
		name: "Vanguard S&P 500",
		assetClass: "etf",
		currency: "EUR",
		yahoo: "VUAA.DE",
		isin: "IE00BFMXXD54",
		fallback: 132.8
	},
	{
		symbol: "EUNL",
		name: "iShares Core MSCI World",
		assetClass: "etf",
		currency: "EUR",
		yahoo: "EUNL.DE",
		isin: "IE00B4L5Y983",
		fallback: 130.54
	},
	{
		symbol: "IWDA",
		name: "iShares Core MSCI World (Amszterdam)",
		assetClass: "etf",
		currency: "EUR",
		yahoo: "IWDA.AS",
		isin: "IE00B4L5Y983",
		fallback: 130.55
	},
	{
		symbol: "SXRV",
		name: "iShares Nasdaq 100",
		assetClass: "etf",
		currency: "EUR",
		yahoo: "SXRV.DE",
		isin: "IE00B53SZB19",
		fallback: 1508.8
	},
	{
		symbol: "QDVE",
		name: "iShares S&P 500 Information Technology",
		assetClass: "etf",
		currency: "EUR",
		yahoo: "QDVE.DE",
		isin: "IE00B3WJKG14",
		fallback: 45.88
	},
	{
		symbol: "IS3N",
		name: "iShares Core MSCI EM IMI",
		assetClass: "etf",
		currency: "EUR",
		yahoo: "IS3N.DE",
		isin: "IE00BKM4GZ66",
		fallback: 46.36
	},
	{
		symbol: "EIMI",
		name: "iShares Core MSCI EM IMI (USD)",
		assetClass: "etf",
		currency: "USD",
		yahoo: "EIMI.L",
		isin: "IE00BKM4GZ66",
		fallback: 41.2
	},
	{
		symbol: "SWRD",
		name: "SPDR MSCI World",
		assetClass: "etf",
		currency: "USD",
		yahoo: "SWRD.L",
		isin: "IE00BFY0GT14",
		fallback: 46.5
	},
	{
		symbol: "IGLN",
		name: "iShares Physical Gold",
		assetClass: "etf",
		currency: "USD",
		yahoo: "IGLN.L",
		isin: "IE00B4ND3602",
		fallback: 81.02
	},
	{
		symbol: "SGLD",
		name: "Invesco Physical Gold",
		assetClass: "etf",
		currency: "USD",
		yahoo: "SGLD.L",
		isin: "IE00B579F325",
		fallback: 401.73
	},
	{
		symbol: "OTP",
		name: "OTP Bank",
		assetClass: "reszveny",
		currency: "HUF",
		yahoo: "OTP.BD",
		isin: "HU0000061726",
		fallback: 42430
	},
	{
		symbol: "MOL",
		name: "MOL",
		assetClass: "reszveny",
		currency: "HUF",
		yahoo: "MOL.BD",
		isin: "HU0000153937",
		fallback: 5075
	},
	{
		symbol: "RICHTER",
		name: "Richter Gedeon",
		assetClass: "reszveny",
		currency: "HUF",
		yahoo: "RICHTER.BD",
		isin: "HU0000123096",
		fallback: 9765
	},
	{
		symbol: "MTEL",
		name: "Magyar Telekom",
		assetClass: "reszveny",
		currency: "HUF",
		yahoo: "MTEL.BD",
		isin: "HU0000073507",
		fallback: 2692
	},
	{
		symbol: "OPUS",
		name: "OPUS",
		assetClass: "reszveny",
		currency: "HUF",
		yahoo: "OPUS.BD",
		isin: "HU0000110226",
		fallback: 213
	},
	{
		symbol: "4IG",
		name: "4iG",
		assetClass: "reszveny",
		currency: "HUF",
		yahoo: "4IG.BD",
		isin: "HU0000167788",
		fallback: 1550
	},
	{
		symbol: "ANY",
		name: "ANY Biztonsági Nyomda",
		assetClass: "reszveny",
		currency: "HUF",
		yahoo: "ANY.BD",
		isin: "HU0000093257",
		fallback: 6140
	},
	{
		symbol: "BTC",
		name: "Bitcoin",
		assetClass: "kripto",
		currency: "USD",
		gecko: "bitcoin",
		fallback: 81471
	},
	{
		symbol: "ETH",
		name: "Ethereum",
		assetClass: "kripto",
		currency: "USD",
		gecko: "ethereum",
		fallback: 2425
	},
	{
		symbol: "SOL",
		name: "Solana",
		assetClass: "kripto",
		currency: "USD",
		gecko: "solana",
		fallback: 104.67
	},
	{
		symbol: "ADA",
		name: "Cardano",
		assetClass: "kripto",
		currency: "USD",
		gecko: "cardano",
		fallback: .4
	},
	{
		symbol: "XRP",
		name: "XRP",
		assetClass: "kripto",
		currency: "USD",
		gecko: "ripple",
		fallback: .55
	},
	{
		symbol: "DOGE",
		name: "Dogecoin",
		assetClass: "kripto",
		currency: "USD",
		gecko: "dogecoin",
		fallback: .12
	},
	{
		symbol: "AVAX",
		name: "Avalanche",
		assetClass: "kripto",
		currency: "USD",
		gecko: "avalanche-2",
		fallback: 22
	},
	{
		symbol: "DOT",
		name: "Polkadot",
		assetClass: "kripto",
		currency: "USD",
		gecko: "polkadot",
		fallback: 4.2
	},
	{
		symbol: "LINK",
		name: "Chainlink",
		assetClass: "kripto",
		currency: "USD",
		gecko: "chainlink",
		fallback: 14
	},
	{
		symbol: "TON",
		name: "Toncoin",
		assetClass: "kripto",
		currency: "USD",
		gecko: "the-open-network",
		fallback: 3.2
	},
	{
		symbol: "BNB",
		name: "BNB",
		assetClass: "kripto",
		currency: "USD",
		gecko: "binancecoin",
		fallback: 600
	},
	{
		symbol: "LTC",
		name: "Litecoin",
		assetClass: "kripto",
		currency: "USD",
		gecko: "litecoin",
		fallback: 80
	},
	{
		symbol: "UNI",
		name: "Uniswap",
		assetClass: "kripto",
		currency: "USD",
		gecko: "uniswap",
		fallback: 8
	},
	{
		symbol: "AAVE",
		name: "Aave",
		assetClass: "kripto",
		currency: "USD",
		gecko: "aave",
		fallback: 180
	},
	{
		symbol: "NEAR",
		name: "NEAR",
		assetClass: "kripto",
		currency: "USD",
		gecko: "near",
		fallback: 3
	},
	{
		symbol: "APT",
		name: "Aptos",
		assetClass: "kripto",
		currency: "USD",
		gecko: "aptos",
		fallback: 6
	},
	{
		symbol: "SUI",
		name: "Sui",
		assetClass: "kripto",
		currency: "USD",
		gecko: "sui",
		fallback: 2.2
	},
	{
		symbol: "PEPE",
		name: "Pepe",
		assetClass: "kripto",
		currency: "USD",
		gecko: "pepe",
		fallback: 8e-6
	},
	{
		symbol: "SHIB",
		name: "Shiba Inu",
		assetClass: "kripto",
		currency: "USD",
		gecko: "shiba-inu",
		fallback: 12e-6
	},
	{
		symbol: "RENDER",
		name: "Render",
		assetClass: "kripto",
		currency: "USD",
		gecko: "render-token",
		fallback: 4
	},
	{
		symbol: "ATOM",
		name: "Cosmos",
		assetClass: "kripto",
		currency: "USD",
		gecko: "cosmos",
		fallback: 4.5
	}
];
var FALLBACK_FX = {
	usdHuf: 322.65,
	eurHuf: 363.08,
	gbpHuf: 430.26
};
function findCatalog(symbol) {
	const key = symbol.trim().toUpperCase();
	return CATALOG.find((item) => item.symbol === key);
}
function catalogByIsin(isin) {
	const key = isin.trim().toUpperCase();
	return CATALOG.filter((item) => item.isin === key);
}
function matchInstrument(isin, context) {
	const found = catalogByIsin(isin);
	if (found.length === 0) return void 0;
	if (found.length === 1) return found[0];
	const upper = context.toUpperCase();
	const byTicker = found.find((item) => new RegExp(`\\b${item.symbol}\\b`).test(upper));
	if (byTicker) return byTicker;
	if (/\bUSD\b/.test(upper)) return found.find((item) => item.currency === "USD") ?? found[0];
	if (/\bGBP\b/.test(upper)) return found.find((item) => item.currency === "GBP") ?? found[0];
	if (/\bEUR\b/.test(upper)) return found.find((item) => item.currency === "EUR") ?? found[0];
	return found[0];
}
function instrumentsFrom(holdings) {
	const map = /* @__PURE__ */ new Map();
	for (const holding of holdings) {
		if (holding.assetClass === "keszpenz" || map.has(holding.symbol)) continue;
		const known = findCatalog(holding.symbol);
		const yahoo = holding.yahoo || known?.yahoo;
		const gecko = holding.gecko || known?.gecko;
		if (!yahoo && !gecko && !(holding.manualPrice && holding.manualPrice > 0)) continue;
		map.set(holding.symbol, {
			symbol: holding.symbol,
			currency: holding.currency,
			yahoo,
			gecko
		});
	}
	return [...map.values()].slice(0, 24);
}
//#endregion
export { findCatalog as a, catalog_D0BjXlW4_exports as i, FALLBACK_FX as n, matchInstrument as o, __exportAll as r, CATALOG as t };
