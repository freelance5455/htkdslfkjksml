import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as ArrowLeft } from "../_libs/lucide-react.mjs";
import { i as Route$2, o as Button } from "./router-0AvkMag6.mjs";
import { t as DayChecklist } from "./day-checklist-BPquXlsy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dia._date-De7QYJzU.js
var import_jsx_runtime = require_jsx_runtime();
function DayPage() {
	const { date } = Route$2.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "ghost",
			size: "sm",
			className: "-ml-2 mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/calendario",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), " Calendário"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayChecklist, { date })]
	});
}
//#endregion
export { DayPage as component };
