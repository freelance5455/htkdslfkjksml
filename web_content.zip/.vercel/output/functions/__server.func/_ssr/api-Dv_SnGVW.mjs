import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as number, n as array, o as object, r as boolean, s as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-Dv_SnGVW.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var optionalString = string().optional().nullable();
var emptySearch = {
	channels: [],
	continuation: null,
	resolved: null
};
var emptyPosts = {
	channel: null,
	posts: [],
	continuation: null,
	hasPostsTab: false
};
var emptyComments = {
	comments: [],
	continuation: null,
	hiddenContinuation: null,
	totalText: ""
};
var searchChannelsFn_createServerFn_handler = createServerRpc({
	id: "a290d10df71b420f8f7349b8755415d24d8a337df2428e267ca60b04ec700f5e",
	name: "searchChannelsFn",
	filename: "src/lib/youtube/api.ts"
}, (opts) => searchChannelsFn.__executeServer(opts));
var searchChannelsFn = createServerFn({ method: "POST" }).validator(object({
	query: string(),
	continuation: optionalString
})).handler(searchChannelsFn_createServerFn_handler, async ({ data }) => {
	try {
		const { searchChannels } = await import("./innertube-Cxmnl2Mp.mjs");
		return await searchChannels({
			query: data.query,
			continuation: data.continuation ?? void 0
		});
	} catch {
		return emptySearch;
	}
});
var getChannelFn_createServerFn_handler = createServerRpc({
	id: "90e37794b753508efce0c276cbabd9deed7a76d19942eea954c9452679281e1e",
	name: "getChannelFn",
	filename: "src/lib/youtube/api.ts"
}, (opts) => getChannelFn.__executeServer(opts));
var getChannelFn = createServerFn({ method: "POST" }).validator(object({ id: string().min(1) })).handler(getChannelFn_createServerFn_handler, async ({ data }) => {
	try {
		const { getChannel, resolveChannel, parseUserQuery } = await import("./innertube-Cxmnl2Mp.mjs");
		const parsed = parseUserQuery(data.id);
		if (parsed.kind === "handle" || parsed.kind === "url") return await resolveChannel(data.id);
		if (parsed.kind === "id") return await getChannel(parsed.value);
		return await resolveChannel(data.id) ?? await getChannel(data.id);
	} catch {
		return null;
	}
});
var getChannelPostsFn_createServerFn_handler = createServerRpc({
	id: "ac3f239e32e817830b127a58a6df7910bc5381003ef6e9879e7d73d1873bd972",
	name: "getChannelPostsFn",
	filename: "src/lib/youtube/api.ts"
}, (opts) => getChannelPostsFn.__executeServer(opts));
var getChannelPostsFn = createServerFn({ method: "POST" }).validator(object({
	channelId: string().min(1),
	continuation: optionalString
})).handler(getChannelPostsFn_createServerFn_handler, async ({ data }) => {
	try {
		const { getChannelPosts } = await import("./innertube-Cxmnl2Mp.mjs");
		return await getChannelPosts({
			channelId: data.channelId,
			continuation: data.continuation ?? void 0
		});
	} catch {
		return emptyPosts;
	}
});
var loadFeedPageFn_createServerFn_handler = createServerRpc({
	id: "459816b48cc9688e7062e7cb7d9ffb9f911e46a5c5be9635c49ac69bace32ff8",
	name: "loadFeedPageFn",
	filename: "src/lib/youtube/api.ts"
}, (opts) => loadFeedPageFn.__executeServer(opts));
var loadFeedPageFn = createServerFn({ method: "POST" }).validator(object({
	topic: string().default("all"),
	queryIndex: number().int().min(0).default(0),
	searchContinuation: optionalString,
	extraChannelIds: array(string()).max(500).default([]),
	channelCursors: array(object({
		id: string(),
		continuation: optionalString
	})).max(500).default([]),
	discover: boolean().default(true)
})).handler(loadFeedPageFn_createServerFn_handler, async ({ data }) => {
	try {
		const { loadFeedPage } = await import("./innertube-Cxmnl2Mp.mjs");
		return await loadFeedPage({
			topic: data.topic === "images" || data.topic === "polls" || data.topic === "videos" || data.topic === "text" ? "all" : data.topic,
			queryIndex: data.queryIndex,
			searchContinuation: data.searchContinuation ?? void 0,
			extraChannelIds: data.extraChannelIds,
			channelCursors: data.channelCursors,
			discover: data.discover
		});
	} catch {
		return {
			posts: [],
			channels: [],
			queryIndex: data.queryIndex + 1,
			searchContinuation: null,
			nextCursors: []
		};
	}
});
var getPostCommentsFn_createServerFn_handler = createServerRpc({
	id: "04e056aac362061e2d1879651b22cb9166afd939180493363ca86ad0a9ad88d2",
	name: "getPostCommentsFn",
	filename: "src/lib/youtube/api.ts"
}, (opts) => getPostCommentsFn.__executeServer(opts));
var getPostCommentsFn = createServerFn({ method: "POST" }).validator(object({
	postId: string().min(1),
	channelId: optionalString,
	commentParams: optionalString,
	continuation: optionalString,
	includeHidden: boolean().optional(),
	sort: _enum(["newest", "top"]).optional()
})).handler(getPostCommentsFn_createServerFn_handler, async ({ data }) => {
	try {
		const { getPostComments } = await import("./innertube-Cxmnl2Mp.mjs");
		return await getPostComments({
			postId: data.postId,
			channelId: data.channelId ?? void 0,
			commentParams: data.commentParams ?? void 0,
			continuation: data.continuation ?? void 0,
			includeHidden: data.includeHidden,
			sort: data.sort
		});
	} catch {
		return emptyComments;
	}
});
//#endregion
export { getChannelFn_createServerFn_handler, getChannelPostsFn_createServerFn_handler, getPostCommentsFn_createServerFn_handler, loadFeedPageFn_createServerFn_handler, searchChannelsFn_createServerFn_handler };
