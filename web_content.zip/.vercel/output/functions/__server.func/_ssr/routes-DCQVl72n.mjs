import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DCQVl72n.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEY = "ahdaf.v1";
function isoDaysFromNow(days) {
	const d = /* @__PURE__ */ new Date();
	d.setHours(12, 0, 0, 0);
	d.setDate(d.getDate() + days);
	return d.toISOString().slice(0, 10);
}
function seedGoals() {
	return [
		{
			id: "g1",
			title: "وامهای آرپناهی تا تعمیر ماشین",
			priority: "medium",
			active: true,
			deadline: isoDaysFromNow(8),
			pinned: false,
			order: 0,
			tasks: []
		},
		{
			id: "g2",
			title: "خاص کردن استایل",
			priority: "medium",
			active: true,
			deadline: isoDaysFromNow(365),
			pinned: false,
			order: 1,
			tasks: []
		},
		{
			id: "g3",
			title: "تعمیر آبگرمکن خونه",
			priority: "medium",
			active: true,
			deadline: isoDaysFromNow(30),
			pinned: false,
			order: 2,
			tasks: [{
				id: "t1",
				title: "هماهنگی با تعمیرکار",
				done: false,
				deadline: isoDaysFromNow(7),
				note: "",
				pinned: false,
				order: 0
			}]
		}
	];
}
function loadGoals() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return seedGoals();
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return seedGoals();
		return parsed;
	} catch {
		return seedGoals();
	}
}
function saveGoals(goals) {
	localStorage.setItem(KEY, JSON.stringify(goals));
}
function uid() {
	return Math.random().toString(36).slice(2, 10);
}
function fa(n) {
	return n.toLocaleString("fa-IR");
}
function daysLeft(iso) {
	if (!iso) return null;
	const today = /* @__PURE__ */ new Date();
	today.setHours(0, 0, 0, 0);
	const d = /* @__PURE__ */ new Date(`${iso}T00:00:00`);
	return Math.round((d.getTime() - today.getTime()) / 864e5);
}
function progressOf(goal) {
	if (goal.tasks.length === 0) return 0;
	const done = goal.tasks.filter((t) => t.done).length;
	return Math.round(done / goal.tasks.length * 100);
}
function sortItems(items) {
	return [...items].sort((a, b) => {
		if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
		return a.order - b.order;
	});
}
function moveInGroup(items, id, targetId) {
	const moving = items.find((i) => i.id === id);
	const target = items.find((i) => i.id === targetId);
	if (!moving || !target || moving.pinned !== target.pinned || id === targetId) return items;
	const group = items.filter((i) => i.pinned === moving.pinned).sort((a, b) => a.order - b.order);
	const rest = items.filter((i) => i.pinned !== moving.pinned);
	const from = group.findIndex((i) => i.id === id);
	const to = group.findIndex((i) => i.id === targetId);
	const next = [...group];
	const [item] = next.splice(from, 1);
	next.splice(to, 0, item);
	return [...next.map((item, index) => ({
		...item,
		order: index
	})), ...rest.map((item, index) => ({
		...item,
		order: index
	}))];
}
var PRIORITY_LABEL = {
	low: "کم",
	medium: "متوسط",
	high: "زیاد"
};
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [goals, setGoals] = (0, import_react.useState)(seedGoals);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [modal, setModal] = (0, import_react.useState)(null);
	const [menu, setMenu] = (0, import_react.useState)(null);
	const [drag, setDrag] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setGoals(loadGoals());
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (ready) saveGoals(goals);
	}, [goals, ready]);
	const openGoal = goals.find((g) => g.id === openId) ?? null;
	const sorted = (0, import_react.useMemo)(() => sortItems(goals), [goals]);
	function patchGoal(id, fn) {
		setGoals((list) => list.map((g) => g.id === id ? fn(g) : g));
	}
	function onDropGoal(targetId) {
		if (!drag || drag.scope !== "goal") return;
		setGoals((list) => moveInGroup(list, drag.id, targetId));
		setDrag(null);
	}
	function onDropTask(targetId) {
		if (!drag || drag.scope !== "task" || !openId) return;
		patchGoal(openId, (g) => ({
			...g,
			tasks: moveInGroup(g.tasks, drag.id, targetId)
		}));
		setDrag(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-full max-w-[480px] flex-col bg-[#f5f8f9]",
		onClick: () => setMenu(null),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				dir: "ltr",
				className: "flex items-center justify-between border-b border-[#e7eef0] bg-white px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "grid h-12 w-12 place-items-center rounded-2xl bg-[#12a085] text-white shadow-sm",
					onClick: (e) => {
						e.stopPropagation();
						setModal(openGoal ? { kind: "task" } : { kind: "goal" });
					},
					"aria-label": "افزودن",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[26px] font-extrabold tracking-tight text-[#17323c]",
					children: openGoal ? "کارها" : "اهداف"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 px-4 pb-8",
				children: openGoal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskList, {
					goal: openGoal,
					dragId: drag?.scope === "task" ? drag.id : null,
					menuId: menu?.scope === "task" ? menu.id : null,
					onBack: () => setOpenId(null),
					onToggle: (id) => patchGoal(openGoal.id, (g) => ({
						...g,
						tasks: g.tasks.map((t) => t.id === id ? {
							...t,
							done: !t.done
						} : t)
					})),
					onPin: (id) => patchGoal(openGoal.id, (g) => ({
						...g,
						tasks: g.tasks.map((t) => t.id === id ? {
							...t,
							pinned: !t.pinned
						} : t)
					})),
					onMenu: (id) => setMenu({
						scope: "task",
						id
					}),
					onEdit: (id) => setModal({
						kind: "task",
						id
					}),
					onDelete: (id) => patchGoal(openGoal.id, (g) => ({
						...g,
						tasks: g.tasks.filter((t) => t.id !== id)
					})),
					onDragStart: (id) => setDrag({
						scope: "task",
						id
					}),
					onDrop: onDropTask
				}) : sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-16 text-center text-[#8aa0a8]",
					children: "هنوز هدفی نداری. با دکمه به‌علاوه یکی بساز."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 space-y-4",
					children: sorted.map((goal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalCard, {
						goal,
						dragging: drag?.scope === "goal" && drag.id === goal.id,
						menuOpen: menu?.scope === "goal" && menu.id === goal.id,
						onOpen: () => setOpenId(goal.id),
						onMenu: () => setMenu({
							scope: "goal",
							id: goal.id
						}),
						onPin: () => patchGoal(goal.id, (g) => ({
							...g,
							pinned: !g.pinned
						})),
						onEdit: () => setModal({
							kind: "goal",
							id: goal.id
						}),
						onDelete: () => setGoals((list) => list.filter((g) => g.id !== goal.id)),
						onDragStart: () => setDrag({
							scope: "goal",
							id: goal.id
						}),
						onDrop: () => onDropGoal(goal.id)
					}, goal.id))
				})
			}),
			modal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
				modal,
				goal: openGoal,
				goals,
				onClose: () => setModal(null),
				onSaveGoal: (data) => {
					if (modal.id) patchGoal(modal.id, (g) => ({
						...g,
						...data
					}));
					else setGoals((list) => [{
						id: uid(),
						tasks: [],
						pinned: false,
						order: list.length,
						...data
					}, ...list]);
					setModal(null);
				},
				onSaveTask: (data) => {
					if (!openGoal) return;
					if (modal.id) patchGoal(openGoal.id, (g) => ({
						...g,
						tasks: g.tasks.map((t) => t.id === modal.id ? {
							...t,
							...data
						} : t)
					}));
					else patchGoal(openGoal.id, (g) => ({
						...g,
						tasks: [...g.tasks, {
							id: uid(),
							done: false,
							pinned: false,
							order: g.tasks.length,
							...data
						}]
					}));
					setModal(null);
				}
			}) : null
		]
	});
}
function GoalCard({ goal, dragging, menuOpen, onOpen, onMenu, onPin, onEdit, onDelete, onDragStart, onDrop }) {
	const pct = progressOf(goal);
	const left = daysLeft(goal.deadline);
	const done = goal.tasks.filter((t) => t.done).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: `relative rounded-[28px] bg-white px-4 py-5 shadow-[0_8px_24px_rgba(22,48,58,0.04)] ${dragging ? "drag-ghost" : ""}`,
		onDragOver: (e) => e.preventDefault(),
		onDrop: (e) => {
			e.preventDefault();
			onDrop();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 pt-1 text-[#b7c7cd]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							draggable: true,
							"aria-label": "جابه‌جایی",
							className: "grid h-8 w-6 cursor-grab place-items-center active:cursor-grabbing",
							onDragStart: (e) => {
								e.dataTransfer.effectAllowed = "move";
								onDragStart();
							},
							onClick: (e) => e.stopPropagation(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grip, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, { value: pct })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "min-w-0 flex-1 text-right",
						onClick: onOpen,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-[22px] leading-8 font-extrabold text-[#17323c]",
							children: goal.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap justify-end gap-2",
							children: [
								goal.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: "mint",
									children: "فعال"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: "muted",
									children: "متوقف"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: goal.priority === "high" ? "rose" : goal.priority === "low" ? "muted" : "amber",
									children: PRIORITY_LABEL[goal.priority]
								}),
								goal.pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: "mint",
									children: "پین"
								}) : null
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "grid h-8 w-8 place-items-center text-[#9eb0b6]",
						"aria-label": "منو",
						onClick: (e) => {
							e.stopPropagation();
							onMenu();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dots, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center justify-between text-[13px] text-[#8ea3aa]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: left === null ? "بدون ددلاین" : left < 0 ? `${fa(Math.abs(left))} روز گذشته` : `${fa(left)} روز باقی‌مونده` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pct === 0 ? "تازه آغاز شده" : `${fa(pct)}٪ پیش رفته` })]
			}),
			goal.tasks.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-left text-[13px] text-[#7f969d]",
				children: [
					fa(done),
					" از ",
					fa(goal.tasks.length),
					" مورد انجام شده"
				]
			}) : null,
			menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuBox, {
				pinned: goal.pinned,
				onPin,
				onEdit,
				onDelete
			}) : null
		]
	});
}
function TaskList({ goal, dragId, menuId, onBack, onToggle, onPin, onMenu, onEdit, onDelete, onDragStart, onDrop }) {
	const tasks = sortItems(goal.tasks);
	const pct = progressOf(goal);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "mb-3 text-[13px] font-semibold text-[#12a085]",
				onClick: onBack,
				children: "بازگشت به اهداف"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 rounded-[28px] bg-white p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, { value: pct }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[20px] font-extrabold",
						children: goal.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[13px] text-[#8ea3aa]",
						children: [fa(pct), "٪ انجام شده"]
					})] })]
				})
			}),
			tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-center text-[#8aa0a8]",
				children: "کاری داخل این هدف نیست. با به‌علاوه اضافه کن."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
					task,
					dragging: dragId === task.id,
					menuOpen: menuId === task.id,
					onToggle: () => onToggle(task.id),
					onPin: () => onPin(task.id),
					onMenu: () => onMenu(task.id),
					onEdit: () => onEdit(task.id),
					onDelete: () => onDelete(task.id),
					onDragStart: () => onDragStart(task.id),
					onDrop: () => onDrop(task.id)
				}, task.id))
			})
		]
	});
}
function TaskRow({ task, dragging, menuOpen, onToggle, onPin, onMenu, onEdit, onDelete, onDragStart, onDrop }) {
	const left = daysLeft(task.deadline);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `relative flex items-start gap-2 rounded-2xl bg-white px-3 py-3 shadow-[0_6px_16px_rgba(22,48,58,0.04)] ${dragging ? "drag-ghost" : ""} ${task.done ? "opacity-60" : ""}`,
		onDragOver: (e) => e.preventDefault(),
		onDrop: (e) => {
			e.preventDefault();
			onDrop();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				draggable: true,
				"aria-label": "جابه‌جایی کار",
				className: "mt-1 grid h-8 w-6 cursor-grab place-items-center text-[#b7c7cd]",
				onDragStart: (e) => {
					e.dataTransfer.effectAllowed = "move";
					onDragStart();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grip, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				"aria-label": task.done ? "انجام‌نشده" : "انجام شد",
				onClick: onToggle,
				className: `mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 ${task.done ? "border-[#12a085] bg-[#12a085] text-white" : "border-[#c5d5da]"}`,
				children: task.done ? "✓" : ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `font-semibold ${task.done ? "line-through" : ""}`,
					children: task.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-[12px] text-[#8ea3aa]",
					children: [
						task.pinned ? "پین‌شده · " : "",
						left === null ? "بدون ددلاین" : left < 0 ? `${fa(Math.abs(left))} روز گذشته` : `${fa(left)} روز مانده`,
						task.note ? ` · ${task.note}` : ""
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "grid h-8 w-8 place-items-center text-[#9eb0b6]",
				onClick: onMenu,
				"aria-label": "منوی کار",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dots, {})
			}),
			menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuBox, {
				pinned: task.pinned,
				onPin,
				onEdit,
				onDelete
			}) : null
		]
	});
}
function MenuBox({ pinned, onPin, onEdit, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute top-12 left-3 z-30 w-36 overflow-hidden rounded-2xl border border-[#e6eef0] bg-white text-right shadow-lg",
		onClick: (e) => e.stopPropagation(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
				onClick: onPin,
				children: pinned ? "برداشتن پین" : "پین کردن"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
				onClick: onEdit,
				children: "ویرایش"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
				danger: true,
				onClick: onDelete,
				children: "حذف"
			})
		]
	});
}
function MenuItem({ children, onClick, danger }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: `block w-full px-3 py-2.5 text-[13px] font-medium hover:bg-[#f4f8f8] ${danger ? "text-[#d14343]" : "text-[#17323c]"}`,
		onClick,
		children
	});
}
function Editor({ modal, goal, goals, onClose, onSaveGoal, onSaveTask }) {
	const existingGoal = modal.kind === "goal" ? goals.find((g) => g.id === modal.id) : void 0;
	const existingTask = modal.kind === "task" ? goal?.tasks.find((t) => t.id === modal.id) : void 0;
	const [title, setTitle] = (0, import_react.useState)(existingGoal?.title ?? existingTask?.title ?? "");
	const [deadline, setDeadline] = (0, import_react.useState)(existingGoal?.deadline ?? existingTask?.deadline ?? "");
	const [priority, setPriority] = (0, import_react.useState)(existingGoal?.priority ?? "medium");
	const [note, setNote] = (0, import_react.useState)(existingTask?.note ?? "");
	const [active, setActive] = (0, import_react.useState)(existingGoal?.active ?? true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: modal.id ? "ویرایش" : modal.kind === "goal" ? "هدف جدید" : "کار جدید",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 block text-[13px] text-[#607780]",
				children: ["عنوان", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					className: "mt-1 w-full rounded-xl border border-[#e1ebed] bg-[#f7fbfb] px-3 py-2.5 text-[15px] text-[#17323c] outline-none"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 block text-[13px] text-[#607780]",
				children: ["ددلاین", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					value: deadline ?? "",
					onChange: (e) => setDeadline(e.target.value),
					className: "mt-1 w-full rounded-xl border border-[#e1ebed] bg-[#f7fbfb] px-3 py-2.5 text-[15px] outline-none"
				})]
			}),
			modal.kind === "goal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 block text-[13px] text-[#607780]",
				children: ["اولویت", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: priority,
					onChange: (e) => setPriority(e.target.value),
					className: "mt-1 w-full rounded-xl border border-[#e1ebed] bg-[#f7fbfb] px-3 py-2.5 outline-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "low",
							children: "کم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "medium",
							children: "متوسط"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "high",
							children: "زیاد"
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-4 flex items-center gap-2 text-[14px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: active,
					onChange: (e) => setActive(e.target.checked)
				}), "فعال"]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-4 block text-[13px] text-[#607780]",
				children: ["یادداشت", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: note,
					onChange: (e) => setNote(e.target.value),
					className: "mt-1 w-full rounded-xl border border-[#e1ebed] bg-[#f7fbfb] px-3 py-2.5 outline-none",
					rows: 3
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "w-full rounded-2xl bg-[#12a085] py-3 font-bold text-white",
				onClick: () => {
					if (!title.trim()) return;
					if (modal.kind === "goal") onSaveGoal({
						title: title.trim(),
						priority,
						deadline: deadline || null,
						active
					});
					else onSaveTask({
						title: title.trim(),
						deadline: deadline || null,
						note: note.trim()
					});
				},
				children: "ذخیره"
			})
		]
	});
}
function Sheet({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-black/35",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-[480px] rounded-t-3xl bg-white p-5 pb-8",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-[18px] font-extrabold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "text-[#8aa0a8]",
					onClick: onClose,
					children: "بستن"
				})]
			}), children]
		})
	});
}
function Ring({ value }) {
	const r = 26;
	const c = 2 * Math.PI * r;
	const offset = c - Math.min(100, Math.max(0, value)) / 100 * c;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "72",
		height: "72",
		viewBox: "0 0 72 72",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				className: "ring-track",
				cx: "36",
				cy: "36",
				r,
				fill: "none",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "36",
				cy: "36",
				r,
				fill: "none",
				stroke: "#7fd3c2",
				strokeWidth: "6",
				strokeLinecap: "round",
				strokeDasharray: c,
				strokeDashoffset: offset,
				transform: "rotate(-90 36 36)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
				x: "36",
				y: "40",
				textAnchor: "middle",
				fontSize: "13",
				fill: "#9eb0b6",
				fontFamily: "Vazirmatn, sans-serif",
				children: [fa(value), "٪"]
			})
		]
	});
}
function Chip({ children, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-lg px-2.5 py-1 text-[12px] font-semibold ${{
			mint: "bg-[#d8f7ee] text-[#14967d]",
			amber: "bg-[#ffe7b8] text-[#c98412]",
			muted: "bg-[#eef3f4] text-[#6d848c]",
			rose: "bg-[#ffe1e1] text-[#d14343]"
		}[tone]}`,
		children
	});
}
function Plus() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 5v14M5 12h14" })
	});
}
function Dots() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "18",
		height: "18",
		viewBox: "0 0 24 24",
		fill: "currentColor",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "5",
				r: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "19",
				r: "1.6"
			})
		]
	});
}
function Grip() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "14",
		height: "18",
		viewBox: "0 0 14 18",
		fill: "currentColor",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "4",
				cy: "3",
				r: "1.3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "10",
				cy: "3",
				r: "1.3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "4",
				cy: "9",
				r: "1.3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "10",
				cy: "9",
				r: "1.3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "4",
				cy: "15",
				r: "1.3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "10",
				cy: "15",
				r: "1.3"
			})
		]
	});
}
//#endregion
export { Home as component };
