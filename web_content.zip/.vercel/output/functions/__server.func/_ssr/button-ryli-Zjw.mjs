import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { l as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-ryli-Zjw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function createId() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `id_${Math.random().toString(36).slice(2, 10)}_${Date.now().toString(36)}`;
}
function parentPath(path) {
	const i = path.lastIndexOf("/");
	return i === -1 ? "" : path.slice(0, i);
}
function baseName(path) {
	const i = path.lastIndexOf("/");
	return i === -1 ? path : path.slice(i + 1);
}
function joinPath(dir, name) {
	if (!dir) return name;
	return `${dir.replace(/\/+$/, "")}/${name.replace(/^\/+/, "")}`;
}
function extOf(path) {
	const base = baseName(path);
	const i = base.lastIndexOf(".");
	if (i <= 0) return "";
	return base.slice(i + 1).toLowerCase();
}
function NijoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("block", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				fill: "#08090d"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "0.75",
				y: "0.75",
				width: "30.5",
				height: "30.5",
				rx: "7.25",
				fill: "none",
				stroke: "#4d8dff",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M9.2 23.2V8.8h3.1l7.3 9.6V8.8h3.2v14.4h-3.1l-7.3-9.6v9.6H9.2Z",
				fill: "#eef1f6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "22.4",
				y: "21.4",
				width: "1.7",
				height: "4.2",
				rx: "0.6",
				fill: "#4d8dff"
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium transition-[transform,background-color,opacity,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/70 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg shadow-nijo",
			secondary: "bg-surface text-fg shadow-nijo",
			outline: "bg-transparent text-fg shadow-nijo",
			ghost: "bg-transparent text-fg hover:bg-surface",
			danger: "bg-danger text-primary-fg"
		},
		size: {
			default: "h-11 px-4 text-sm",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5 text-base",
			icon: "size-11",
			pill: "h-11 px-4 text-sm rounded-full"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
//#endregion
export { createId as a, parentPath as c, cn as i, NijoMark as n, extOf as o, baseName as r, joinPath as s, Button as t };
