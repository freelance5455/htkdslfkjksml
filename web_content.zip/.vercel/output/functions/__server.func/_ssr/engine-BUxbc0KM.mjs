import { a as sfxScan, c as CATALOG, i as pulseDrone, n as isDiscovered, o as sfxWarn, r as useGameStore, s as sfxWarp } from "./routes-B77Qjfsp.mjs";
import { C as Sprite, S as SphereGeometry, T as Vector3, _ as Points, a as CanvasTexture, b as Scene, c as ConeGeometry, d as Group, f as InstancedMesh, g as PerspectiveCamera, h as Object3D, i as BufferGeometry, l as DynamicDrawUsage, m as MeshBasicMaterial, n as BoxGeometry, o as CircleGeometry, p as Mesh, r as BufferAttribute, s as Color, t as WebGLRenderer, u as FogExp2, v as PointsMaterial, w as SpriteMaterial, x as ShaderMaterial, y as SRGBColorSpace } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-BUxbc0KM.js
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"KeyR",
	"KeyF",
	"KeyE",
	"KeyQ",
	"KeyC",
	"KeyM",
	"Space",
	"ShiftLeft",
	"ShiftRight",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight",
	"Escape",
	"Tab",
	"KeyP"
]);
function radialDeadzone(x, y, dz = .16) {
	const m = Math.hypot(x, y);
	if (m < dz) return {
		x: 0,
		y: 0
	};
	const scale = (m - dz) / (1 - dz) / m;
	return {
		x: x * scale,
		y: y * scale
	};
}
var Input = class {
	keys = /* @__PURE__ */ new Set();
	qaKeys = null;
	qaSteer = null;
	touch = {
		throttle: 0,
		steer: 0,
		pitch: 0,
		boost: false,
		scan: false
	};
	scanEdge = false;
	warpEdge = false;
	pauseEdge = false;
	catalogEdge = false;
	muteEdge = false;
	prevScan = false;
	prevWarp = false;
	prevPause = false;
	prevCatalog = false;
	prevMute = false;
	attached = false;
	onDown = (e) => {
		if (e.metaKey || e.ctrlKey || e.altKey) return;
		const tag = e.target?.tagName;
		if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
		this.keys.add(e.code);
		if (GAME_CODES.has(e.code)) e.preventDefault();
	};
	onUp = (e) => {
		this.keys.delete(e.code);
	};
	onBlur = () => {
		this.keys.clear();
	};
	attach() {
		if (this.attached) return;
		this.attached = true;
		addEventListener("keydown", this.onDown);
		addEventListener("keyup", this.onUp);
		addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onBlur);
	}
	detach() {
		if (!this.attached) return;
		this.attached = false;
		removeEventListener("keydown", this.onDown);
		removeEventListener("keyup", this.onUp);
		removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onBlur);
		this.keys.clear();
	}
	setKeys(codes) {
		this.qaKeys = new Set(codes);
	}
	setSteer(v) {
		this.qaSteer = v;
	}
	setTouch(next) {
		Object.assign(this.touch, next);
	}
	held(code) {
		return (this.qaKeys ?? this.keys).has(code);
	}
	sample() {
		const src = this.qaKeys ?? this.keys;
		let throttle = this.touch.throttle;
		if (src.has("KeyW")) throttle += 1;
		if (src.has("KeyS")) throttle -= 1;
		throttle = Math.max(-1, Math.min(1, throttle));
		let steer = this.touch.steer;
		if (src.has("KeyA") || src.has("ArrowLeft")) steer += 1;
		if (src.has("KeyD") || src.has("ArrowRight")) steer -= 1;
		if (this.qaSteer !== null) steer = this.qaSteer;
		steer = Math.max(-1, Math.min(1, steer));
		let pitch = this.touch.pitch;
		if (src.has("KeyR") || src.has("ArrowUp")) pitch += 1;
		if (src.has("KeyF") || src.has("ArrowDown")) pitch -= 1;
		pitch = Math.max(-1, Math.min(1, pitch));
		let boost = this.touch.boost || src.has("ShiftLeft") || src.has("ShiftRight");
		let scan = this.touch.scan || src.has("KeyE") || src.has("Space");
		let warp = src.has("KeyQ");
		let pause = src.has("KeyP") || src.has("Escape");
		let catalog = src.has("KeyC") || src.has("Tab");
		let mute = src.has("KeyM");
		const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : null;
		if (pads) for (const pad of pads) {
			if (!pad || pad.mapping !== "standard") continue;
			const ls = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
			const rs = radialDeadzone(pad.axes[2] ?? 0, pad.axes[3] ?? 0);
			steer += -ls.x;
			throttle += -ls.y;
			pitch += -rs.y;
			if (pad.buttons[7]?.value > .4 || pad.buttons[0]?.pressed) boost = true;
			if (pad.buttons[2]?.pressed) scan = true;
			if (pad.buttons[3]?.pressed) warp = true;
			if (pad.buttons[9]?.pressed) pause = true;
			if (pad.buttons[8]?.pressed) catalog = true;
		}
		throttle = Math.max(-1, Math.min(1, throttle));
		steer = Math.max(-1, Math.min(1, steer));
		pitch = Math.max(-1, Math.min(1, pitch));
		this.scanEdge = scan && !this.prevScan;
		this.warpEdge = warp && !this.prevWarp;
		this.pauseEdge = pause && !this.prevPause;
		this.catalogEdge = catalog && !this.prevCatalog;
		this.muteEdge = mute && !this.prevMute;
		this.prevScan = scan;
		this.prevWarp = warp;
		this.prevPause = pause;
		this.prevCatalog = catalog;
		this.prevMute = mute;
		return {
			throttle,
			steer,
			pitch,
			boost,
			scan
		};
	}
};
var TAU = Math.PI * 2;
function makeGlowTexture(size = 64) {
	const c = document.createElement("canvas");
	c.width = c.height = size;
	const g = c.getContext("2d");
	if (!g) throw new Error("2d");
	const grd = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
	grd.addColorStop(0, "rgba(255,255,255,1)");
	grd.addColorStop(.35, "rgba(255,255,255,0.45)");
	grd.addColorStop(1, "rgba(255,255,255,0)");
	g.fillStyle = grd;
	g.fillRect(0, 0, size, size);
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.needsUpdate = true;
	return tex;
}
function disposeObject(obj) {
	obj.traverse((o) => {
		const mesh = o;
		if (mesh.geometry) mesh.geometry.dispose();
		const mat = o.material;
		if (!mat) return;
		if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
		else mat.dispose();
	});
}
function rand() {
	return Math.random();
}
function gauss() {
	return rand() + rand() + rand() - 1.5;
}
function makeStarfield(count, radius) {
	const pos = new Float32Array(count * 3);
	const col = new Float32Array(count * 3);
	for (let i = 0; i < count; i++) {
		const z = rand() * 2 - 1;
		const a = rand() * TAU;
		const s = Math.sqrt(1 - z * z);
		const r = radius * (.55 + rand() * .45);
		const k = i * 3;
		pos[k] = r * s * Math.cos(a);
		pos[k + 1] = r * z * .72;
		pos[k + 2] = r * s * Math.sin(a);
		const cool = rand();
		col[k] = .72 + cool * .28;
		col[k + 1] = .78 + cool * .18;
		col[k + 2] = .92 + (1 - cool) * .08;
	}
	const geo = new BufferGeometry();
	geo.setAttribute("position", new BufferAttribute(pos, 3));
	geo.setAttribute("color", new BufferAttribute(col, 3));
	return geo;
}
function makeGalaxyGeometry(g, count) {
	const P = new Float32Array(count * 3);
	const C = new Float32Array(count * 3);
	const c1 = new Color(g.colorA);
	const c2 = new Color(g.colorB);
	const mix = new Color();
	let i = 0;
	const put = (x, y, z, t, bright = 1) => {
		if (i >= count) return;
		const k = i * 3;
		P[k] = x;
		P[k + 1] = y;
		P[k + 2] = z;
		mix.copy(c1).lerp(c2, t);
		C[k] = mix.r * bright;
		C[k + 1] = mix.g * bright;
		C[k + 2] = mix.b * bright;
		i++;
	};
	const radius = g.radius;
	const thick = g.thick;
	const arms = Math.max(2, g.arms);
	const spin = g.spin;
	const bulge = g.bulge;
	const disc = (n, ox = 0, oy = 0, oz = 0, sc = 1, bar = false) => {
		for (let k = 0; k < n && i < count; k++) if (rand() < bulge) {
			const s = radius * sc * .28 * Math.pow(rand(), 1.5);
			const z = rand() * 2 - 1;
			const a = rand() * TAU;
			const q = Math.sqrt(1 - z * z);
			put(ox + s * q * Math.cos(a), oy + s * z * .7, oz + s * q * Math.sin(a), .15, 1.15);
		} else {
			let r = -Math.log(1 - rand() * .995) * radius * sc * .32;
			let a = Math.floor(rand() * arms) * (TAU / arms) + spin * 1.9 * Math.log(1 + 4 * r / (radius * sc)) + gauss() * .45 / (1 + r * .3);
			if (bar && r < radius * sc * .32) {
				a = (rand() < .5 ? 0 : Math.PI) + gauss() * .12;
				r *= 1.15;
			}
			const y = gauss() * thick * radius * sc * .32 * (1 + r / (radius * sc));
			put(ox + r * Math.cos(a), oy + y, oz + r * Math.sin(a), Math.min(1, r / (radius * sc)), .85 + rand() * .4);
		}
	};
	const t = g.kind;
	if (t === "elliptical") for (let k = 0; k < count; k++) {
		const s = radius * .58 * Math.pow(rand(), 2);
		const z = rand() * 2 - 1;
		const a = rand() * TAU;
		const q = Math.sqrt(1 - z * z);
		put(s * q * Math.cos(a), s * z * .78, s * q * Math.sin(a), .25, .9);
	}
	else if (t === "ring") {
		for (let k = 0; k < count * .82; k++) {
			const a = rand() * TAU;
			const r = radius * .82 * (1 + gauss() * .05);
			put(r * Math.cos(a), gauss() * .08, r * Math.sin(a), .7, 1.1);
		}
		while (i < count) {
			const s = radius * .2 * Math.pow(rand(), 1.3);
			const z = rand() * 2 - 1;
			const a = rand() * TAU;
			const q = Math.sqrt(1 - z * z);
			put(s * q * Math.cos(a), s * z, s * q * Math.sin(a), .2);
		}
	} else if (t === "irregular") {
		const clumps = Array.from({ length: 7 }, () => {
			const z = rand() * 2 - 1;
			const a = rand() * TAU;
			const q = Math.sqrt(1 - z * z);
			const s = radius * .55 * Math.pow(rand(), .7);
			return [
				s * q * Math.cos(a),
				s * z * .5,
				s * q * Math.sin(a),
				radius * (.14 + rand() * .22)
			];
		});
		while (i < count) {
			const c = clumps[i % clumps.length];
			put(c[0] + gauss() * c[3] * 1.3, c[1] + gauss() * c[3] * .7, c[2] + gauss() * c[3] * 1.3, rand(), .9);
		}
	} else if (t === "cluster") {
		const clumps = Array.from({ length: 6 }, () => {
			const z = rand() * 2 - 1;
			const a = rand() * TAU;
			const q = Math.sqrt(1 - z * z);
			const s = radius * 2.1;
			return [
				s * q * Math.cos(a),
				s * z * .6,
				s * q * Math.sin(a)
			];
		});
		while (i < count) {
			const c = clumps[i % clumps.length];
			put(c[0] + gauss() * radius * .4, c[1] + gauss() * radius * .32, c[2] + gauss() * radius * .4, rand());
		}
	} else if (t === "interact") {
		disc(count * .62, 0, 0, 0, 1, false);
		disc(count * .38, radius * 1.45, radius * .2, -radius * .45, .55, false);
	} else {
		disc(t === "edgeOnBurst" ? count * .86 : count, 0, 0, 0, 1, t === "barred");
		if (t === "edgeOnBurst") while (i < count) {
			const y = (rand() < .5 ? -1 : 1) * (rand() * radius * .9 + .12);
			put(gauss() * (.12 + Math.abs(y) * .14), y, gauss() * (.12 + Math.abs(y) * .14), .85, 1.2);
		}
	}
	const geo = new BufferGeometry();
	geo.setAttribute("position", new BufferAttribute(P, 3));
	geo.setAttribute("color", new BufferAttribute(C, 3));
	geo.computeBoundingSphere();
	return geo;
}
function makeShip() {
	const g = new Group();
	const hullMat = new MeshBasicMaterial({ color: 13227234 });
	const accentMat = new MeshBasicMaterial({ color: 10405096 });
	const darkMat = new MeshBasicMaterial({ color: 1712684 });
	const bodyGeo = new ConeGeometry(.22, 1.15, 6);
	bodyGeo.rotateX(Math.PI / 2);
	const body = new Mesh(bodyGeo, hullMat);
	body.position.z = .12;
	g.add(body);
	const cabin = new Mesh(new SphereGeometry(.16, 8, 6), accentMat);
	cabin.position.set(0, .08, .05);
	g.add(cabin);
	const wingGeo = new BoxGeometry(1.15, .04, .28);
	const wings = new Mesh(wingGeo, darkMat);
	wings.position.z = .22;
	g.add(wings);
	const fin = new Mesh(new BoxGeometry(.05, .32, .22), darkMat);
	fin.position.set(0, .2, .28);
	g.add(fin);
	const engine = new Mesh(new SphereGeometry(.12, 8, 6), new MeshBasicMaterial({ color: 11065343 }));
	engine.position.z = .72;
	engine.name = "engine";
	g.add(engine);
	g.traverse((o) => {
		o.frustumCulled = false;
	});
	return g;
}
var BH_V = `
varying vec2 vUv;
void main(){
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);
}
`;
var BH_F = `
uniform float uTime;
uniform vec3 uHot;
uniform vec3 uCool;
varying vec2 vUv;
void main(){
  vec2 p = vUv - 0.5;
  float r = length(p) * 2.0;
  float a = atan(p.y, p.x);
  float band = smoothstep(0.28, 0.42, r) * smoothstep(1.0, 0.62, r);
  float swirl = 0.5 + 0.5 * sin(a * 9.0 - r * 14.0 - uTime * 2.4);
  vec3 col = mix(uHot, uCool, swirl);
  float hole = smoothstep(0.34, 0.22, r);
  col *= 1.0 - hole;
  gl_FragColor = vec4(col, band * 0.92);
}
`;
function makeBlackHole(body) {
	const g = new Group();
	const scale = .55 + body.radius * .18;
	const hole = new Mesh(new SphereGeometry(.55 * scale, 16, 12), new MeshBasicMaterial({ color: 0 }));
	g.add(hole);
	const mat = new ShaderMaterial({
		uniforms: {
			uTime: { value: 0 },
			uHot: { value: new Color(body.colorA) },
			uCool: { value: new Color(body.colorB) }
		},
		vertexShader: BH_V,
		fragmentShader: BH_F,
		transparent: true,
		depthWrite: false,
		blending: 2,
		toneMapped: false,
		side: 2
	});
	const disk = new Mesh(new CircleGeometry(2.4 * scale, 48), mat);
	disk.rotation.x = Math.PI / 2.35;
	disk.name = "disk";
	g.add(disk);
	const glow = new Sprite(new SpriteMaterial({
		color: body.colorB,
		transparent: true,
		opacity: .55,
		depthWrite: false,
		blending: 2
	}));
	glow.scale.setScalar(5.2 * scale);
	g.add(glow);
	return g;
}
function makeCoreSprite(color, tex) {
	const mat = new SpriteMaterial({
		map: tex,
		color,
		transparent: true,
		depthWrite: false,
		blending: 2,
		opacity: .95
	});
	const s = new Sprite(mat);
	s.scale.setScalar(14);
	return s;
}
var POINT_MAT_PARAMS = {
	size: .09,
	vertexColors: true,
	transparent: true,
	depthWrite: false,
	blending: 2,
	opacity: .95,
	sizeAttenuation: true
};
var WORLD = 520;
var CRUISE = 34;
var BOOST_SPD = 82;
var TURN = 2.15;
var PITCH_RATE = 1.55;
var SCAN_RANGE = 16;
var DIVE_RANGE = 8;
var SAMPLE_RANGE = 1.35;
var TRAIL_N = 40;
var QUALITY = [
	{
		bg: 2600,
		field: 4200,
		dpr: 1.15
	},
	{
		bg: 1600,
		field: 2400,
		dpr: 1
	},
	{
		bg: 900,
		field: 1200,
		dpr: .82
	}
];
function damp(a, b, k, dt) {
	return a + (b - a) * (1 - Math.exp(-k * dt));
}
var AtlasEngine = class {
	renderer;
	scene = new Scene();
	camera = new PerspectiveCamera(62, 1, .25, 1400);
	input = new Input();
	ship = makeShip();
	pos = new Vector3();
	vel = new Vector3();
	yaw = 0;
	pitch = .12;
	speed = 0;
	hull = 1;
	boost = 1;
	elapsed = 0;
	last = 0;
	acc = 0;
	hudAcc = 0;
	fpsAcc = 0;
	fpsFrames = 0;
	fps = 60;
	quality = 0;
	slow = 0;
	fast = 0;
	cool = 3;
	phase = "attract";
	targetId = 0;
	nearest = 0;
	warpT = 0;
	warpFrom = new Vector3();
	warpTo = new Vector3();
	warpActive = false;
	scanHold = 0;
	lastWarn = 0;
	shake = 0;
	reduced = false;
	glowTex;
	starfield;
	cores;
	field = null;
	fieldId = -1;
	blackHoles = [];
	samples = [];
	sampleMesh;
	trail;
	trailBuf = [];
	tmp = new Vector3();
	tmp2 = new Vector3();
	tmp3 = new Vector3();
	fwd = new Vector3();
	dummy = new Object3D();
	sampleColor = new Color(12115199);
	pointMat;
	running = false;
	canvas;
	constructor(canvas) {
		this.canvas = canvas;
		this.reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: false,
			alpha: false,
			powerPreference: "high-performance"
		});
		this.renderer.setClearColor(329484, 1);
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.setPixelRatio(this.dpr());
		this.scene.fog = new FogExp2(329484, .00155);
		this.glowTex = makeGlowTexture(64);
		this.pointMat = new PointsMaterial({
			...POINT_MAT_PARAMS,
			map: this.glowTex,
			size: .11
		});
		const q = QUALITY[this.quality];
		this.starfield = new Points(makeStarfield(q.bg, 900), this.pointMat);
		this.starfield.frustumCulled = false;
		this.scene.add(this.starfield);
		this.cores = new Group();
		this.scene.add(this.cores);
		for (const body of CATALOG) {
			const node = new Group();
			node.position.set(body.pos[0], body.pos[1], body.pos[2]);
			node.userData.id = body.id;
			if (body.kind === "blackhole") {
				const bh = makeBlackHole(body);
				node.add(bh);
				this.blackHoles.push({
					id: body.id,
					group: bh
				});
			} else {
				const sprite = makeCoreSprite(body.colorA, this.glowTex);
				sprite.scale.setScalar(9 + body.radius * 1.6);
				node.add(sprite);
				const inner = makeCoreSprite(body.colorB, this.glowTex);
				inner.scale.setScalar(4 + body.radius * .7);
				node.add(inner);
			}
			this.cores.add(node);
		}
		const sGeo = new SphereGeometry(.22, 8, 6);
		const sMat = new MeshBasicMaterial({
			color: 13625599,
			transparent: true,
			opacity: .9
		});
		this.sampleMesh = new InstancedMesh(sGeo, sMat, 64);
		this.sampleMesh.instanceMatrix.setUsage(DynamicDrawUsage);
		this.sampleMesh.frustumCulled = false;
		this.scene.add(this.sampleMesh);
		this.seedSamples();
		const tGeo = new SphereGeometry(.06, 6, 4);
		const tMat = new MeshBasicMaterial({
			color: 10405096,
			transparent: true,
			opacity: .55,
			depthWrite: false,
			blending: 2
		});
		this.trail = new InstancedMesh(tGeo, tMat, TRAIL_N);
		this.trail.instanceMatrix.setUsage(DynamicDrawUsage);
		this.trail.frustumCulled = false;
		this.scene.add(this.trail);
		for (let i = 0; i < TRAIL_N; i++) this.trailBuf.push(new Vector3());
		this.sampleMesh.count = 0;
		this.trail.count = 0;
		this.ship.visible = false;
		this.scene.add(this.ship);
		const mw = CATALOG[0];
		this.pos.set(mw.pos[0], mw.pos[1] + 4, mw.pos[2] + 22);
		this.camera.position.set(0, 40, 240);
		this.camera.lookAt(0, 0, 0);
		this.input.attach();
		this.resize();
		this.bindProbe();
		addEventListener("resize", this.onResize);
		this.last = performance.now();
		this.running = true;
		this.renderer.setAnimationLoop(this.tick);
	}
	dpr() {
		const cap = QUALITY[this.quality].dpr;
		return Math.min(typeof devicePixelRatio === "number" ? devicePixelRatio : 1, cap);
	}
	onResize = () => this.resize();
	resize() {
		const w = this.canvas.clientWidth || innerWidth;
		const h = this.canvas.clientHeight || innerHeight;
		this.camera.aspect = w / Math.max(1, h);
		this.camera.updateProjectionMatrix();
		this.renderer.setPixelRatio(this.dpr());
		this.renderer.setSize(w, h, false);
	}
	startExpedition() {
		this.phase = "play";
		this.ship.visible = true;
		this.hull = 1;
		this.boost = 1;
		const mw = CATALOG[0];
		this.pos.set(mw.pos[0], mw.pos[1] + 3.5, mw.pos[2] + 18);
		this.vel.set(0, 0, 0);
		this.yaw = 0;
		this.pitch = .08;
		this.speed = 0;
		this.targetId = 0;
		const f = this.forward();
		this.camera.position.copy(this.pos).addScaledVector(f, -11.5);
		this.camera.position.y += 3.4;
		this.camera.lookAt(this.pos);
		this.trail.count = TRAIL_N;
		useGameStore.getState().setPhase("play");
	}
	setPaused(paused) {
		if (this.phase === "attract") return;
		this.phase = paused ? "pause" : "play";
		useGameStore.getState().setPhase(this.phase);
	}
	togglePause() {
		if (this.phase === "play") this.setPaused(true);
		else if (this.phase === "pause") this.setPaused(false);
	}
	setTouch(next) {
		this.input.setTouch(next);
	}
	warpTo(id) {
		if (this.phase !== "play" && this.phase !== "complete" || this.warpActive) return;
		const body = CATALOG[id];
		if (!body) return;
		this.targetId = id;
		this.warpFrom.copy(this.pos);
		const [x, y, z] = body.pos;
		this.tmp.set(x, y, z);
		this.tmp2.copy(this.pos).sub(this.tmp);
		if (this.tmp2.lengthSq() < 1) this.tmp2.set(0, 0, 1);
		this.tmp2.normalize().multiplyScalar(body.kind === "blackhole" ? 18 : 14);
		this.warpTo.copy(this.tmp).add(this.tmp2);
		this.warpActive = true;
		this.warpT = 0;
		sfxWarp();
		useGameStore.getState().recordWarp();
	}
	setTarget(id) {
		this.targetId = id;
	}
	bindProbe() {
		window.__controlsTest = {
			getYaw: () => this.yaw,
			getSpeed: () => this.speed,
			setSteer: (v) => this.input.setSteer(v),
			setKeys: (codes) => this.input.setKeys(codes)
		};
	}
	seedSamples() {
		this.samples = [];
		for (const body of CATALOG) {
			if (body.kind === "blackhole") continue;
			const n = 2;
			for (let k = 0; k < n; k++) this.samples.push({
				pos: new Vector3(),
				taken: false,
				home: body.id,
				phase: Math.random() * Math.PI * 2
			});
		}
	}
	forward() {
		const cp = Math.cos(this.pitch);
		this.fwd.set(-Math.sin(this.yaw) * cp, Math.sin(this.pitch), -Math.cos(this.yaw) * cp);
		return this.fwd;
	}
	nearestBody() {
		let best = 0;
		let bestD = Infinity;
		for (const b of CATALOG) {
			const d = this.tmp.set(b.pos[0], b.pos[1], b.pos[2]).sub(this.pos).length();
			if (d < bestD) {
				bestD = d;
				best = b.id;
			}
		}
		return {
			id: best,
			dist: bestD,
			body: CATALOG[best]
		};
	}
	localScale(body) {
		return 1.15 + body.radius * .42;
	}
	ensureField(id) {
		if (this.fieldId === id) return;
		if (this.field) {
			this.scene.remove(this.field);
			this.field.geometry.dispose();
			this.field = null;
		}
		this.fieldId = id;
		const body = CATALOG[id];
		if (!body || body.kind === "blackhole") return;
		const geo = makeGalaxyGeometry(body, QUALITY[this.quality].field);
		const pts = new Points(geo, this.pointMat);
		pts.position.set(body.pos[0], body.pos[1], body.pos[2]);
		const s = this.localScale(body);
		pts.scale.setScalar(s);
		if (/edgeOn/.test(body.kind)) pts.rotation.x = 1.15;
		pts.frustumCulled = false;
		this.scene.add(pts);
		this.field = pts;
	}
	dropField() {
		if (!this.field) return;
		this.scene.remove(this.field);
		this.field.geometry.dispose();
		this.field = null;
		this.fieldId = -1;
	}
	tick = (now) => {
		if (!this.running) return;
		const raw = Math.max(0, (now - this.last) / 1e3);
		this.last = now;
		const dt = Math.min(raw, .1);
		this.elapsed += dt;
		if (this.phase === "pause") {
			this.renderer.render(this.scene, this.camera);
			this.pushHud(dt);
			return;
		}
		if (this.phase === "attract") this.updateAttract(dt);
		else {
			this.acc += dt;
			const step = 1 / 60;
			let guard = 0;
			while (this.acc >= step && guard++ < 6) {
				this.fixed(step);
				this.acc -= step;
			}
			this.updateVisuals(dt);
		}
		if (raw < .5) {
			this.fpsFrames++;
			this.fpsAcc += raw;
		}
		if (this.fpsAcc > 1) {
			this.fps = this.fpsFrames / this.fpsAcc;
			this.fpsFrames = 0;
			this.fpsAcc = 0;
			this.adapt();
		}
		this.renderer.render(this.scene, this.camera);
		this.pushHud(dt);
	};
	adapt() {
		if (this.elapsed < this.cool) {
			this.slow = 0;
			this.fast = 0;
			return;
		}
		if (this.fps < 38) {
			this.fast = 0;
			if (++this.slow >= 2 && this.quality < 2) {
				this.quality++;
				this.slow = 0;
				this.cool = this.elapsed + 4;
				this.applyQuality();
			}
		} else if (this.fps > 56 && this.quality > 0) {
			this.slow = 0;
			if (++this.fast >= 8) {
				this.quality--;
				this.fast = 0;
				this.cool = this.elapsed + 8;
				this.applyQuality();
			}
		} else {
			this.slow = 0;
			this.fast = 0;
		}
	}
	applyQuality() {
		this.starfield.geometry.dispose();
		this.starfield.geometry = makeStarfield(QUALITY[this.quality].bg, 900);
		if (this.fieldId >= 0) {
			const keep = this.fieldId;
			this.dropField();
			this.ensureField(keep);
		}
		this.resize();
	}
	updateAttract(dt) {
		const t = this.elapsed;
		this.camera.position.set(Math.sin(t * .11) * 250, 48 + Math.sin(t * .07) * 22, Math.cos(t * .11) * 250);
		this.camera.lookAt(0, 0, 0);
		this.starfield.rotation.y += dt * .012;
		this.spinDisks();
	}
	spinDisks() {
		for (const bh of this.blackHoles) {
			const mat = bh.group.getObjectByName("disk")?.material;
			if (mat?.uniforms?.uTime) mat.uniforms.uTime.value = this.elapsed;
			bh.group.rotation.y = this.elapsed * .08;
		}
		if (this.field) this.field.rotation.y += .08 * (1 / 60);
	}
	fixed(dt) {
		const act = this.input.sample();
		if (this.input.pauseEdge) this.togglePause();
		if (this.input.catalogEdge) useGameStore.getState().setCatalogOpen(!useGameStore.getState().catalogOpen);
		if (this.input.muteEdge) useGameStore.getState().toggleMute();
		if (this.phase !== "play" && this.phase !== "complete") return;
		if (this.input.warpEdge) {
			const dest = this.targetId ?? this.nearest;
			this.warpTo(dest);
		}
		if (this.warpActive) {
			this.warpT += dt / 1.35;
			const t = Math.min(1, this.warpT);
			const k = t * t * (3 - 2 * t);
			this.pos.lerpVectors(this.warpFrom, this.warpTo, k);
			this.vel.set(0, 0, 0);
			this.speed = 0;
			if (t >= 1) this.warpActive = false;
		} else {
			this.yaw += act.steer * TURN * dt;
			this.pitch += act.pitch * PITCH_RATE * dt;
			this.pitch = Math.max(-1.15, Math.min(1.15, this.pitch));
			const boosting = act.boost && this.boost > .05 && act.throttle > 0;
			if (boosting) this.boost = Math.max(0, this.boost - dt * .28);
			else this.boost = Math.min(1, this.boost + dt * .16);
			const cap = boosting ? BOOST_SPD : CRUISE;
			const thrust = act.throttle * cap * 1.8;
			const f = this.forward();
			this.vel.addScaledVector(f, thrust * dt);
			this.vel.multiplyScalar(Math.exp(-2.4 * dt));
			this.applyGravity(dt);
			this.pos.addScaledVector(this.vel, dt);
			this.speed = this.vel.length();
			const r = this.pos.length();
			if (r > WORLD) {
				this.pos.multiplyScalar(WORLD / r);
				this.vel.multiplyScalar(.4);
			}
		}
		this.handleScan(act.scan, dt);
		this.collectSamples();
		this.updateFieldLod();
		this.spinDisks();
	}
	applyGravity(dt) {
		let danger = 0;
		for (const body of CATALOG) {
			if (body.kind !== "blackhole") continue;
			this.tmp.set(body.pos[0], body.pos[1], body.pos[2]);
			this.tmp2.copy(this.tmp).sub(this.pos);
			const d = this.tmp2.length();
			const rs = 2.2 + body.radius * .55;
			if (d < 55) {
				const pull = 38 * body.radius / Math.max(4, d * d);
				this.vel.addScaledVector(this.tmp2.normalize(), pull * dt);
				danger = Math.max(danger, 1 - d / 55);
				if (d < rs) {
					this.hull = Math.max(0, this.hull - dt * .85);
					this.shake = Math.min(1, this.shake + dt * 2.4);
					if (this.elapsed - this.lastWarn > .7) {
						sfxWarn();
						this.lastWarn = this.elapsed;
					}
					if (this.hull <= 0) this.emergencyExtract(body);
				} else if (d < rs * 2.4) {
					this.hull = Math.max(.12, this.hull - dt * .08);
					this.shake = Math.min(1, this.shake + dt * .9);
				}
			}
		}
		if (danger < .05) this.hull = Math.min(1, this.hull + dt * .04);
		pulseDrone(danger);
	}
	emergencyExtract(body) {
		this.tmp.set(body.pos[0], body.pos[1], body.pos[2]);
		this.tmp2.copy(this.pos).sub(this.tmp).normalize().multiplyScalar(28);
		this.pos.copy(this.tmp).add(this.tmp2);
		this.vel.set(0, 0, 0);
		this.hull = .45;
		this.shake = .8;
		useGameStore.getState().toast("EMERGENCY EXTRACT", "Pulled clear of the event horizon");
	}
	handleScan(holding, dt) {
		const n = this.nearestBody();
		this.nearest = n.id;
		const inRange = n.dist < SCAN_RANGE + n.body.radius;
		if (holding && inRange) this.scanHold += dt;
		else this.scanHold = Math.max(0, this.scanHold - dt * 2);
		if (this.scanHold > .55 && inRange) {
			this.scanHold = 0;
			const dive = n.body.kind !== "blackhole" && n.dist < DIVE_RANGE + n.body.radius * .25;
			sfxScan();
			useGameStore.getState().recordScan(n.id, dive, n.body.kind === "blackhole");
			this.shake = Math.min(1, this.shake + .18);
		}
	}
	collectSamples() {
		for (const s of this.samples) {
			if (s.taken) continue;
			if (!isDiscovered(s.home)) continue;
			if (s.pos.distanceTo(this.pos) < SAMPLE_RANGE) {
				s.taken = true;
				useGameStore.getState().collectSample();
			}
		}
	}
	updateFieldLod() {
		const n = this.nearestBody();
		if (n.dist < 70 && n.body.kind !== "blackhole") this.ensureField(n.id);
		else if (n.dist > 90) this.dropField();
	}
	updateVisuals(dt) {
		const f = this.forward();
		this.ship.position.copy(this.pos);
		this.tmp.copy(this.pos).add(f);
		this.ship.lookAt(this.tmp);
		const engine = this.ship.getObjectByName("engine");
		if (engine) {
			const mat = engine.material;
			const glow = .45 + Math.min(1, this.speed / BOOST_SPD) * .55;
			mat.color.setRGB(.55 * glow, .78 * glow, 1);
			engine.scale.setScalar(.8 + glow * .7);
		}
		const follow = this.reduced ? 14 : 10;
		this.tmp.copy(this.pos).addScaledVector(f, -11.5).y += 3.4;
		this.camera.position.x = damp(this.camera.position.x, this.tmp.x, follow, dt);
		this.camera.position.y = damp(this.camera.position.y, this.tmp.y, follow, dt);
		this.camera.position.z = damp(this.camera.position.z, this.tmp.z, follow, dt);
		this.tmp2.copy(this.pos).addScaledVector(f, 6);
		if (this.shake > 0 && !this.reduced) {
			const mag = this.shake * this.shake * .45;
			this.camera.position.x += (Math.random() - .5) * mag;
			this.camera.position.y += (Math.random() - .5) * mag;
			this.shake = Math.max(0, this.shake - dt * 1.8);
		}
		this.camera.lookAt(this.tmp2);
		this.camera.fov = damp(this.camera.fov, this.warpActive ? 78 : 62 + Math.min(8, this.speed * .08), 6, dt);
		this.camera.updateProjectionMatrix();
		this.trailBuf[Math.floor(this.elapsed * 48) % TRAIL_N]?.copy(this.pos);
		if (Math.floor(this.elapsed * 48) !== Math.floor((this.elapsed - dt) * 48)) this.trailBuf[Math.floor(this.elapsed * 48) % TRAIL_N].copy(this.pos);
		for (let i = 0; i < TRAIL_N; i++) {
			const p = this.trailBuf[i];
			this.dummy.position.copy(p);
			const s = .4 + i % 7 * .08;
			this.dummy.scale.setScalar(s);
			this.dummy.updateMatrix();
			this.trail.setMatrixAt(i, this.dummy.matrix);
		}
		this.trail.instanceMatrix.needsUpdate = true;
		let si = 0;
		for (const s of this.samples) {
			const home = CATALOG[s.home];
			const orbit = 7 + s.home % 5 * .45;
			const a = this.elapsed * .55 + s.phase;
			s.pos.set(home.pos[0] + Math.cos(a) * orbit, home.pos[1] + Math.sin(a * 1.4) * 1.6, home.pos[2] + Math.sin(a) * orbit);
			this.dummy.position.copy(s.pos);
			this.dummy.scale.setScalar(s.taken || !isDiscovered(s.home) ? 1e-4 : 1);
			this.dummy.updateMatrix();
			this.sampleMesh.setMatrixAt(si, this.dummy.matrix);
			this.sampleMesh.setColorAt?.(si, this.sampleColor);
			si++;
		}
		this.sampleMesh.count = si;
		this.sampleMesh.instanceMatrix.needsUpdate = true;
		if (this.sampleMesh.instanceColor) this.sampleMesh.instanceColor.needsUpdate = true;
		this.starfield.rotation.y += dt * .004;
	}
	pushHud(dt) {
		this.hudAcc += dt;
		if (this.hudAcc < .08) return;
		this.hudAcc = 0;
		const n = this.nearestBody();
		const w = this.canvas.clientWidth || innerWidth;
		const h = this.canvas.clientHeight || innerHeight;
		const markers = [];
		for (const b of CATALOG) {
			this.tmp.set(b.pos[0], b.pos[1], b.pos[2]);
			const dist = this.tmp.distanceTo(this.pos);
			if (dist > 160 && b.id !== this.targetId) continue;
			this.tmp.project(this.camera);
			const off = this.tmp.z > 1 || this.tmp.x < -1.15 || this.tmp.x > 1.15 || this.tmp.y < -1.15 || this.tmp.y > 1.15;
			markers.push({
				id: b.id,
				name: b.name,
				kind: b.kind,
				x: (this.tmp.x * .5 + .5) * w,
				y: (-this.tmp.y * .5 + .5) * h,
				discovered: isDiscovered(b.id),
				dist,
				offscreen: off
			});
		}
		markers.sort((a, b) => a.dist - b.dist);
		const target = this.targetId != null ? CATALOG[this.targetId] : null;
		useGameStore.getState().patchHud({
			fps: this.fps,
			speed: this.speed,
			hull: this.hull,
			boost: this.boost,
			nearestName: n.body.name,
			nearestDist: n.dist,
			nearestKind: n.body.kind,
			canScan: n.dist < SCAN_RANGE + n.body.radius,
			scanning: this.scanHold > 0,
			targetId: this.targetId,
			targetName: target?.name ?? "None",
			warping: this.warpActive,
			markers: markers.slice(0, 10),
			phase: this.phase
		});
	}
	dispose() {
		this.running = false;
		this.renderer.setAnimationLoop(null);
		this.input.detach();
		removeEventListener("resize", this.onResize);
		if (window.__controlsTest) delete window.__controlsTest;
		this.dropField();
		disposeObject(this.scene);
		this.glowTex.dispose();
		this.pointMat.dispose();
		this.renderer.dispose();
	}
};
//#endregion
export { AtlasEngine };
