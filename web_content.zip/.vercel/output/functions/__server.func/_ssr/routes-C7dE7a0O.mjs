import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ShieldCheck, c as Power, d as Download, f as Bell, i as ShieldOff, l as Layers, n as Smartphone, o as ShieldAlert, p as Activity, r as Shield, s as Search, u as Eye } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C7dE7a0O.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color,border-color] duration-150 ease-[var(--ease-out-smooth)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg border border-border hover:border-border-strong",
			ghost: "text-fg hover:bg-surface-2",
			outline: "border border-border bg-transparent text-fg hover:bg-surface",
			danger: "bg-danger text-danger-fg hover:opacity-90",
			warn: "bg-warn text-warn-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
});
Button.displayName = "Button";
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { tone: {
		muted: "bg-surface-2 text-muted",
		safe: "bg-primary/15 text-primary",
		warn: "bg-warn/15 text-warn",
		danger: "bg-danger/15 text-danger"
	} },
	defaultVariants: { tone: "muted" }
});
function Badge({ className, tone, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({
			tone,
			className
		})),
		...props
	});
}
function ShieldMark({ className, pulse = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className: cn("text-primary", className),
		"aria-hidden": "true",
		children: [
			pulse ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("circle", {
				cx: "32",
				cy: "34",
				r: "22",
				fill: "currentColor",
				opacity: "0.08",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("animate", {
					attributeName: "r",
					values: "20;26;20",
					dur: "2.8s",
					repeatCount: "indefinite"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("animate", {
					attributeName: "opacity",
					values: "0.12;0.02;0.12",
					dur: "2.8s",
					repeatCount: "indefinite"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 6 L54 14 V32 C54 46 44 56 32 60 C20 56 10 46 10 32 V14 Z",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 14 L46 19 V32 C46 42 39 50 32 53 C25 50 18 42 18 32 V19 Z",
				fill: "currentColor",
				opacity: "0.16"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 18 V46",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M24 31 H40",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinecap: "round"
			})
		]
	});
}
var TRUSTED_TLDS = /* @__PURE__ */ new Set([
	"de",
	"com",
	"org",
	"net",
	"eu",
	"gov",
	"edu",
	"int",
	"at",
	"ch",
	"nl",
	"fr",
	"uk",
	"io",
	"app"
]);
var RISKY_TLDS = /* @__PURE__ */ new Set([
	"tk",
	"gq",
	"ml",
	"cf",
	"ga",
	"xyz",
	"top",
	"click",
	"link",
	"work",
	"zip",
	"mov",
	"country",
	"stream",
	"gdn",
	"loan",
	"win",
	"review",
	"download",
	"racing",
	"accountants"
]);
var SHORTENERS = /* @__PURE__ */ new Set([
	"bit.ly",
	"tinyurl.com",
	"t.co",
	"goo.gl",
	"ow.ly",
	"is.gd",
	"cutt.ly",
	"rebrand.ly",
	"tiny.cc"
]);
var TRUSTED_BRANDS = [
	{
		name: "Sparkasse",
		hosts: ["sparkasse.de", "sparkasse-leipzig.de"]
	},
	{
		name: "Volksbank",
		hosts: ["volksbank.de", "vr.de"]
	},
	{
		name: "Deutsche Bank",
		hosts: ["deutsche-bank.de", "db.com"]
	},
	{
		name: "Commerzbank",
		hosts: ["commerzbank.de"]
	},
	{
		name: "Postbank",
		hosts: ["postbank.de"]
	},
	{
		name: "ING",
		hosts: ["ing.de", "ing.com"]
	},
	{
		name: "N26",
		hosts: ["n26.com"]
	},
	{
		name: "PayPal",
		hosts: [
			"paypal.com",
			"paypal.de",
			"paypal.me"
		]
	},
	{
		name: "Amazon",
		hosts: [
			"amazon.de",
			"amazon.com",
			"amazon.co.uk"
		]
	},
	{
		name: "eBay",
		hosts: ["ebay.de", "ebay.com"]
	},
	{
		name: "DHL",
		hosts: ["dhl.de", "dhl.com"]
	},
	{
		name: "Hermes",
		hosts: ["myhermes.de", "evri.com"]
	},
	{
		name: "Telekom",
		hosts: ["telekom.de", "t-online.de"]
	},
	{
		name: "Vodafone",
		hosts: ["vodafone.de"]
	},
	{
		name: "Apple",
		hosts: ["apple.com", "icloud.com"]
	},
	{
		name: "Google",
		hosts: [
			"google.com",
			"google.de",
			"gmail.com",
			"youtube.com"
		]
	},
	{
		name: "Microsoft",
		hosts: [
			"microsoft.com",
			"live.com",
			"office.com",
			"outlook.com"
		]
	},
	{
		name: "Meta",
		hosts: [
			"facebook.com",
			"instagram.com",
			"whatsapp.com",
			"whatsapp.net"
		]
	},
	{
		name: "ELSTER",
		hosts: ["elster.de"]
	},
	{
		name: "Bundesregierung",
		hosts: ["bundesregierung.de", "bund.de"]
	},
	{
		name: "Netflix",
		hosts: ["netflix.com"]
	},
	{
		name: "Spotify",
		hosts: ["spotify.com"]
	},
	{
		name: "Zalando",
		hosts: ["zalando.de"]
	},
	{
		name: "Otto",
		hosts: ["otto.de"]
	},
	{
		name: "Check24",
		hosts: ["check24.de"]
	},
	{
		name: "Payback",
		hosts: ["payback.de"]
	},
	{
		name: "Klarna",
		hosts: ["klarna.com"]
	},
	{
		name: "Bundesfinanzministerium",
		hosts: ["bundesfinanzministerium.de"]
	}
];
var KNOWN_MALICIOUS = /* @__PURE__ */ new Set([
	"sparkasse-sicherheit.tk",
	"sparkasse-login-check.tk",
	"paypal-konto-update.com",
	"paypal-sicherheit-service.net",
	"dhl-paket-sendung.net",
	"dhl-sendungsverfolgung.xyz",
	"appleid-verify-login.com",
	"icloud-account-restore.tk",
	"telekom-kundencenter.xyz",
	"amazon-prime-bonus.top",
	"microsoft-konto-alert.gq",
	"elster-steuerauskunft.click",
	"whatsapp-voice-mail.ml",
	"postbank-tan-freigabe.cf",
	"n26-karten-sperre.ga",
	"bund-id-verifizieren.zip",
	"konto-update-sparkasse.com",
	"secure-paypal-de.net"
]);
var BAIT_WORDS = [
	"login",
	"secure",
	"update",
	"verify",
	"konto",
	"account",
	"support",
	"sicherheit",
	"kundencenter",
	"paket",
	"sendung",
	"tan",
	"freigabe",
	"restore",
	"bonus",
	"gewinn",
	"alert",
	"service"
];
function levenshtein(a, b) {
	if (a === b) return 0;
	if (!a.length) return b.length;
	if (!b.length) return a.length;
	const row = Array.from({ length: b.length + 1 }, (_, i) => i);
	for (let i = 1; i <= a.length; i++) {
		let prev = i - 1;
		row[0] = i;
		for (let j = 1; j <= b.length; j++) {
			const tmp = row[j];
			const cost = a[i - 1] === b[j - 1] ? 0 : 1;
			row[j] = Math.min(row[j] + 1, row[j - 1] + 1, prev + cost);
			prev = tmp;
		}
	}
	return row[b.length];
}
function normalizeHost(raw) {
	return raw.trim().toLowerCase().replace(/\.$/, "");
}
function parseHost(input) {
	const trimmed = input.trim();
	if (!trimmed) return {
		host: "",
		url: null
	};
	try {
		const withScheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(trimmed) ? trimmed : `https://${trimmed}`;
		const u = new URL(withScheme);
		if (u.protocol === "javascript:" || u.protocol === "data:") return {
			host: u.protocol.replace(":", ""),
			url: trimmed
		};
		return {
			host: normalizeHost(u.hostname),
			url: u.toString()
		};
	} catch {
		return {
			host: normalizeHost(trimmed.split("/")[0] ?? trimmed),
			url: null
		};
	}
}
function registrable(host) {
	const parts = host.split(".").filter(Boolean);
	if (parts.length <= 2) return host;
	return parts.slice(-2).join(".");
}
function isIpHost(host) {
	if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
	if (host.includes(":")) return true;
	return false;
}
function looksHomograph(host) {
	return /[^\u0000-\u007f]/.test(host) || host.includes("xn--");
}
function brandLookalike(host) {
	const labels = host.split(".");
	const core = registrable(host).split(".")[0] ?? host;
	const cleaned = core.replace(/[-0-9]/g, "");
	let best = null;
	for (const brand of TRUSTED_BRANDS) {
		for (const official of brand.hosts) if (host === official || host.endsWith(`.${official}`)) return null;
		const brandCore = brand.hosts[0]?.split(".")[0] ?? brand.name.toLowerCase();
		const compact = brandCore.replace(/[-0-9]/g, "");
		const dist = Math.min(levenshtein(core, brandCore), levenshtein(cleaned, compact));
		if (labels.some((l) => l.includes(brandCore) || brandCore.includes(l.replace(/[-0-9]/g, ""))) && !brand.hosts.some((h) => host === h || host.endsWith(`.${h}`))) {
			const candidate = {
				brand: brand.name,
				distance: Math.min(dist, 2)
			};
			if (!best || candidate.distance < best.distance) best = candidate;
		} else if (dist > 0 && dist <= 2 && Math.abs(core.length - brandCore.length) <= 2) {
			if (!best || dist < best.distance) best = {
				brand: brand.name,
				distance: dist
			};
		}
	}
	return best;
}
function isOfficialHost(host) {
	return TRUSTED_BRANDS.some((b) => b.hosts.some((h) => host === h || host.endsWith(`.${h}`)));
}
function inspectTarget(input) {
	const { host, url } = parseHost(input);
	const findings = [];
	let score = 0;
	let brandHit = null;
	if (!host) return {
		input,
		host: "",
		displayHost: input,
		url,
		verdict: "unknown",
		score: 0,
		findings: [{
			code: "empty",
			severity: "info",
			title: "Keine Adresse",
			detail: "Geben Sie eine Domain oder URL ein."
		}],
		brandHit: null
	};
	if (host === "javascript" || host === "data") {
		findings.push({
			code: "dangerous-scheme",
			severity: "danger",
			title: "Gefährliches Protokoll",
			detail: "Diese Adresse versucht Skript- oder Dateninhalte statt einer Website zu öffnen."
		});
		score += 80;
	}
	if (isIpHost(host)) {
		findings.push({
			code: "ip-host",
			severity: "danger",
			title: "IP statt Domain",
			detail: "Seriöse Dienste nutzen fast nie eine nackte IP-Adresse in der Adresszeile."
		});
		score += 45;
	}
	if (KNOWN_MALICIOUS.has(host) || KNOWN_MALICIOUS.has(registrable(host))) {
		findings.push({
			code: "blocklist",
			severity: "danger",
			title: "Bekannte Betrugsseite",
			detail: "Diese Adresse steht auf der lokalen Sperrliste von Netzschild."
		});
		score += 90;
	}
	if (looksHomograph(host)) {
		findings.push({
			code: "idn",
			severity: "danger",
			title: "Versteckte Zeichen",
			detail: "Die Domain nutzt Punycode oder fremde Schriftzeichen — klassischer Lookalike-Trick."
		});
		score += 40;
	}
	const tld = host.split(".").pop() ?? "";
	if (RISKY_TLDS.has(tld)) {
		findings.push({
			code: "risky-tld",
			severity: "warn",
			title: `Auffällige Endung .${tld}`,
			detail: "Diese Domain-Endung wird überdurchschnittlich oft für Phishing missbraucht."
		});
		score += 22;
	}
	if ((host.match(/-/g) ?? []).length >= 2) {
		findings.push({
			code: "hyphens",
			severity: "warn",
			title: "Viele Bindestriche",
			detail: "Echte Marken-Domains sind kurz. Lange Ketten wie konto-update-service sind verdächtig."
		});
		score += 12;
	}
	if (host.split(".").length >= 5) {
		findings.push({
			code: "deep-sub",
			severity: "warn",
			title: "Tiefe Unterdomain",
			detail: "Viele Unterdomains sollen eine bekannte Adresse vortäuschen."
		});
		score += 14;
	}
	const baitHits = BAIT_WORDS.filter((w) => host.includes(w));
	if (baitHits.length >= 1) {
		findings.push({
			code: "bait-words",
			severity: "warn",
			title: "Druck-Wörter in der Domain",
			detail: `Enthält ${baitHits.slice(0, 3).join(", ")} — typisch für gefälschte Login-Seiten.`
		});
		score += 8 * Math.min(baitHits.length, 3);
	}
	if (SHORTENERS.has(registrable(host))) {
		findings.push({
			code: "shortener",
			severity: "warn",
			title: "Kurzlink",
			detail: "Das Ziel ist verborgen. Netzschild fragt nach, bevor der Link geöffnet wird."
		});
		score += 18;
	}
	const lookalike = brandLookalike(host);
	if (lookalike) {
		brandHit = lookalike.brand;
		findings.push({
			code: "lookalike",
			severity: "danger",
			title: `Sieht aus wie ${lookalike.brand}`,
			detail: `Die Adresse imitiert ${lookalike.brand}, ist aber nicht die offizielle Domain.`
		});
		score += 50;
	}
	if (url) try {
		const u = new URL(url);
		if (u.username || u.password) {
			findings.push({
				code: "userinfo",
				severity: "danger",
				title: "Login in der URL",
				detail: "Benutzername in der Adresse wird genutzt, um die echte Domain zu verschleiern."
			});
			score += 30;
		}
		if (u.protocol === "http:") {
			findings.push({
				code: "http",
				severity: "warn",
				title: "Unverschlüsselt (HTTP)",
				detail: "Ohne HTTPS können Daten auf dem Weg mitgelesen oder verändert werden."
			});
			score += 10;
		}
	} catch {}
	if (isOfficialHost(host)) {
		findings.unshift({
			code: "official",
			severity: "info",
			title: "Bekannte Original-Domain",
			detail: "Diese Adresse gehört zu einem hinterlegten Vertrauensanker."
		});
		score = Math.max(0, score - 70);
	} else if (TRUSTED_TLDS.has(tld) && findings.length === 0) findings.push({
		code: "plain",
		severity: "info",
		title: "Keine bekannten Warnsignale",
		detail: "Kein Treffer in der Sperrliste. Bei unbekannten Seiten fragt Netzschild trotzdem nach."
	});
	let verdict;
	if (score >= 55) verdict = "malicious";
	else if (score >= 22) verdict = "suspicious";
	else if (isOfficialHost(host) || score === 0) verdict = findings.some((f) => f.code === "official") ? "trusted" : "unknown";
	else verdict = "unknown";
	if (isOfficialHost(host) && score < 22) verdict = "trusted";
	return {
		input,
		host,
		displayHost: host,
		url,
		verdict,
		score: Math.max(0, Math.min(100, score)),
		findings,
		brandHit
	};
}
function verdictLabel(v) {
	switch (v) {
		case "trusted": return "Vertrauenswürdig";
		case "unknown": return "Unbekannt";
		case "suspicious": return "Verdächtig";
		case "malicious": return "Gefährlich";
	}
}
var PERMISSION_IDS = [
	"vpn",
	"notifications",
	"background",
	"boot",
	"apps",
	"overlay"
];
function emptyPermissions() {
	return Object.fromEntries(PERMISSION_IDS.map((id) => [id, {
		id,
		granted: false,
		asked: false
	}]));
}
function uid() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
var useShield = create()(persist((set, get) => ({
	onboarded: false,
	protectionOn: false,
	permissions: emptyPermissions(),
	events: [],
	decisions: {},
	pending: null,
	bytesProtected: 0,
	blockedCount: 0,
	askedCount: 0,
	setOnboarded: (v) => set({ onboarded: v }),
	grantPermission: (id, granted) => set((s) => ({ permissions: {
		...s.permissions,
		[id]: {
			id,
			granted,
			asked: true
		}
	} })),
	setProtection: (on) => set({ protectionOn: on }),
	ingest: (partial) => {
		const inspection = inspectTarget(partial.domain);
		const prior = get().decisions[inspection.host];
		let decision = "pending";
		if (prior) decision = prior.decision;
		else if (inspection.verdict === "trusted") decision = "allowed";
		else if (inspection.verdict === "malicious" || inspection.verdict === "suspicious") decision = "pending";
		else decision = "allowed";
		const event = {
			id: uid(),
			at: Date.now(),
			app: partial.app,
			domain: inspection.host || partial.domain,
			proto: partial.proto,
			bytes: partial.bytes,
			verdict: inspection.verdict,
			inspection,
			decision
		};
		const needsAsk = get().protectionOn && !prior && (inspection.verdict === "malicious" || inspection.verdict === "suspicious") && !get().pending;
		set((s) => ({
			events: [event, ...s.events].slice(0, 250),
			bytesProtected: s.bytesProtected + (decision === "blocked" ? 0 : partial.bytes),
			pending: needsAsk ? event : s.pending,
			askedCount: needsAsk ? s.askedCount + 1 : s.askedCount,
			blockedCount: decision === "blocked" || needsAsk && inspection.verdict === "malicious" ? s.blockedCount : s.blockedCount
		}));
		return event;
	},
	resolvePending: (decision) => {
		const pending = get().pending;
		if (!pending) return;
		const host = pending.inspection.host;
		set((s) => ({
			pending: null,
			decisions: {
				...s.decisions,
				[host]: {
					host,
					decision,
					at: Date.now()
				}
			},
			blockedCount: decision === "blocked" ? s.blockedCount + 1 : s.blockedCount,
			events: s.events.map((e) => e.id === pending.id || e.inspection.host === host ? {
				...e,
				decision
			} : e)
		}));
	},
	resetAll: () => set({
		onboarded: false,
		protectionOn: false,
		permissions: emptyPermissions(),
		events: [],
		decisions: {},
		pending: null,
		bytesProtected: 0,
		blockedCount: 0,
		askedCount: 0
	})
}), { name: "netzschild-v1" }));
var PERMISSION_COPY = {
	vpn: {
		title: "Lokales VPN",
		why: "Damit Netzschild jede Domain sieht, bevor eine Verbindung aufgebaut wird. Der Verkehr bleibt auf dem Gerät — kein Fernzugriff.",
		required: true
	},
	notifications: {
		title: "Benachrichtigungen",
		why: "Warnung, wenn eine unsichere oder unbekannte Seite aufgerufen wird — auch bei gesperrtem Bildschirm.",
		required: true
	},
	background: {
		title: "Hintergrunddienst",
		why: "Schutz bleibt aktiv, wenn Sie die App verlassen. Ein dauerhafter Hinweis „Schutz aktiv“ bleibt sichtbar.",
		required: true
	},
	boot: {
		title: "Start nach Neustart",
		why: "Nach einem Handy-Neustart wird der Schutz wieder eingeschaltet, statt still zu bleiben.",
		required: false
	},
	apps: {
		title: "App-Zuordnung",
		why: "Zeigt, welche App den Verkehr auslöst (Browser, Messenger, Spiel). Ohne diese Rechte nur Domain, nicht die App.",
		required: false
	},
	overlay: {
		title: "Warnung über anderen Apps",
		why: "Blendet die Nachfrage direkt über dem Browser ein, statt nur in einer stillen Mitteilung.",
		required: false
	}
};
function toneFor$1(v) {
	if (v === "malicious") return "danger";
	if (v === "suspicious") return "warn";
	if (v === "trusted") return "safe";
	return "muted";
}
function UrlChecker() {
	const [value, setValue] = (0, import_react.useState)("");
	const [submitted, setSubmitted] = (0, import_react.useState)("");
	const ingest = useShield((s) => s.ingest);
	const protectionOn = useShield((s) => s.protectionOn);
	const result = (0, import_react.useMemo)(() => submitted ? inspectTarget(submitted) : null, [submitted]);
	function run(e) {
		e.preventDefault();
		const v = value.trim();
		if (!v) return;
		setSubmitted(v);
		if (protectionOn) ingest({
			app: "Prüfung",
			domain: v,
			proto: "HTTPS",
			bytes: 0
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium",
				children: "Website prüfen"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs leading-relaxed text-muted",
				children: "Domain oder Link einfügen. Netzschild bewertet Vertrauenssignale lokal."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: run,
				className: "mt-3 flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "url-check",
						children: "Adresse"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "url-check",
						value,
						onChange: (e) => setValue(e.target.value),
						placeholder: "z. B. paypal-konto-update.com",
						autoComplete: "off",
						spellCheck: false,
						className: "h-11 min-w-0 flex-1 rounded-md border border-border bg-bg px-3 font-mono text-sm text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "icon",
						"aria-label": "Prüfen",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {})
					})
				]
			}),
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-mono text-xs",
						children: result.displayHost
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: toneFor$1(result.verdict),
						children: verdictLabel(result.verdict)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1.5",
					children: result.findings.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "text-xs leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-medium text-fg",
								children: [f.title, "."]
							}),
							" ",
							f.detail
						]
					}, f.code))
				})]
			}) : null
		]
	});
}
function toneFor(v) {
	if (v === "malicious") return "danger";
	if (v === "suspicious") return "warn";
	if (v === "trusted") return "safe";
	return "muted";
}
function formatBytes$1(n) {
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(1)} MB`;
}
function Row({ e }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "grid grid-cols-[1fr_auto] gap-x-3 gap-y-1 border-b border-border py-3 last:border-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate font-mono text-xs text-fg",
				children: e.domain
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				tone: toneFor(e.verdict),
				children: verdictLabel(e.verdict)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					e.app,
					" · ",
					e.proto,
					" · ",
					formatBytes$1(e.bytes)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-right text-[11px] uppercase tracking-wider text-subtle",
				children: e.decision === "blocked" ? "Blockiert" : e.decision === "trusted" ? "Vertraut" : e.decision === "pending" ? "Wartet" : "Durch"
			})
		]
	});
}
function TrafficFeed() {
	const events = useShield((s) => s.events);
	if (!events.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted",
		children: "Noch kein Verkehr. Schutz einschalten oder eine Website prüfen."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "rounded-xl border border-border bg-surface px-4",
		children: events.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { e }, e.id))
	});
}
function DownloadPack() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-medium",
				children: "Android-Paket"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Das ZIP enthält das vollständige Android-Projekt (Kotlin) mit lokalem VPN, Domainprüfung, Nachfrage-Bildschirm und den nötigen Berechtigungsabfragen. Daraus entsteht die APK — nicht durch Umbenennen der Datei, sondern über Android Studio."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-4 list-decimal space-y-2 pl-5 text-sm leading-relaxed text-fg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ZIP herunterladen und entpacken." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Android Studio öffnen (kostenlos bei Google) und den Ordner",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs",
							children: "Netzschild"
						}),
						" als Projekt laden."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Handy per USB verbinden oder einen Emulator wählen, USB-Debugging erlauben." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Menü ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Build → Build APK(s)"
						}),
						". Die fertige Datei liegt unter",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs",
							children: "app/release"
						}),
						"."
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-5 w-full",
				size: "lg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "/netzschild-android.zip",
					download: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "ZIP herunterladen"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs leading-relaxed text-subtle",
				children: "Netzschild entschlüsselt kein HTTPS. Geprüft werden DNS-Namen, Ziel-IPs und Vertrauenssignale. Der Schutz läuft als sichtbarer Dienst — kein verstecktes Mitschneiden."
			})
		]
	});
}
var BASELINE_TRAFFIC = [
	{
		app: "WhatsApp",
		domain: "g.whatsapp.net",
		proto: "HTTPS",
		bytes: 8400,
		weight: 8
	},
	{
		app: "WhatsApp",
		domain: "whatsapp.com",
		proto: "DNS",
		bytes: 120,
		weight: 4
	},
	{
		app: "Chrome",
		domain: "google.de",
		proto: "HTTPS",
		bytes: 22e3,
		weight: 6
	},
	{
		app: "Chrome",
		domain: "www.google.com",
		proto: "DNS",
		bytes: 180,
		weight: 5
	},
	{
		app: "Instagram",
		domain: "instagram.com",
		proto: "HTTPS",
		bytes: 54e3,
		weight: 4
	},
	{
		app: "System",
		domain: "connectivitycheck.gstatic.com",
		proto: "HTTPS",
		bytes: 640,
		weight: 3
	},
	{
		app: "Telekom",
		domain: "telekom.de",
		proto: "HTTPS",
		bytes: 4100,
		weight: 2
	},
	{
		app: "Gmail",
		domain: "gmail.com",
		proto: "HTTPS",
		bytes: 12e3,
		weight: 3
	},
	{
		app: "Spotify",
		domain: "spotify.com",
		proto: "HTTPS",
		bytes: 18e4,
		weight: 2
	},
	{
		app: "Play Store",
		domain: "play.google.com",
		proto: "HTTPS",
		bytes: 9300,
		weight: 2
	},
	{
		app: "Clock",
		domain: "time.android.com",
		proto: "UDP",
		bytes: 96,
		weight: 2
	},
	{
		app: "Maps",
		domain: "maps.google.com",
		proto: "HTTPS",
		bytes: 28e3,
		weight: 2
	},
	{
		app: "Outlook",
		domain: "outlook.office.com",
		proto: "HTTPS",
		bytes: 16e3,
		weight: 1
	},
	{
		app: "DHL",
		domain: "dhl.de",
		proto: "HTTPS",
		bytes: 7200,
		weight: 1
	},
	{
		app: "System",
		domain: "dns.google",
		proto: "DNS",
		bytes: 84,
		weight: 3
	}
];
var ATTACK_SAMPLES = [
	{
		app: "Chrome",
		domain: "sparkasse-login-check.tk",
		proto: "HTTPS",
		bytes: 2400,
		weight: 1
	},
	{
		app: "SMS-Link",
		domain: "dhl-paket-sendung.net",
		proto: "HTTPS",
		bytes: 1800,
		weight: 1
	},
	{
		app: "Chrome",
		domain: "paypal-konto-update.com",
		proto: "HTTPS",
		bytes: 3100,
		weight: 1
	},
	{
		app: "Mail",
		domain: "appleid-verify-login.com",
		proto: "HTTPS",
		bytes: 1500,
		weight: 1
	},
	{
		app: "Chrome",
		domain: "telekom-kundencenter.xyz",
		proto: "HTTPS",
		bytes: 2100,
		weight: 1
	},
	{
		app: "WhatsApp",
		domain: "elster-steuerauskunft.click",
		proto: "HTTPS",
		bytes: 900,
		weight: 1
	},
	{
		app: "Chrome",
		domain: "secure-paypal-de.net",
		proto: "HTTPS",
		bytes: 2600,
		weight: 1
	}
];
function pickWeighted(list) {
	const sum = list.reduce((a, b) => a + b.weight, 0);
	let r = Math.random() * sum;
	for (const item of list) {
		r -= item.weight;
		if (r <= 0) return item;
	}
	return list[0];
}
function nextBaseline() {
	const s = pickWeighted(BASELINE_TRAFFIC);
	const jitter = .6 + Math.random() * .8;
	return {
		...s,
		bytes: Math.round(s.bytes * jitter)
	};
}
function nextAttack() {
	return ATTACK_SAMPLES[Math.floor(Math.random() * ATTACK_SAMPLES.length)];
}
function formatBytes(n) {
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(1)} MB`;
}
function Dashboard() {
	const [tab, setTab] = (0, import_react.useState)("home");
	const protectionOn = useShield((s) => s.protectionOn);
	const setProtection = useShield((s) => s.setProtection);
	const bytesProtected = useShield((s) => s.bytesProtected);
	const blockedCount = useShield((s) => s.blockedCount);
	const askedCount = useShield((s) => s.askedCount);
	const events = useShield((s) => s.events);
	const ingest = useShield((s) => s.ingest);
	const permissions = useShield((s) => s.permissions);
	const grant = useShield((s) => s.grantPermission);
	const grantedCount = (0, import_react.useMemo)(() => Object.values(permissions).filter((p) => p.granted).length, [permissions]);
	async function toggleProtection() {
		if (!protectionOn) {
			if ("Notification" in window && Notification.permission === "default") {
				const res = await Notification.requestPermission();
				grant("notifications", res === "granted");
			}
			grant("vpn", true);
			grant("background", true);
		}
		setProtection(!protectionOn);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-5 pb-3 pt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium leading-none",
						children: "Netzschild"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] uppercase tracking-wider text-subtle",
						children: protectionOn ? "Hintergrund aktiv" : "Pause"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: protectionOn ? "safe" : "muted",
					children: protectionOn ? "Schutz an" : "Schutz aus"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 px-5 pb-28",
				children: [
					tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "rounded-xl border border-border bg-surface p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-4",
									children: [protectionOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldMark, {
										pulse: true,
										className: "size-16 shrink-0"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, { className: "size-12 shrink-0 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-xl font-medium tracking-tight",
											children: protectionOn ? "Ihr Netz wird geprüft" : "Schutz ist ausgeschaltet"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm leading-relaxed text-muted",
											children: protectionOn ? "Jede neue Domain wird bewertet. Bei Zweifel kommt eine Nachfrage." : "Ohne aktiven Dienst passiert Verkehr ungeprüft."
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "mt-5 w-full",
									variant: protectionOn ? "secondary" : "default",
									size: "lg",
									onClick: toggleProtection,
									children: protectionOn ? "Schutz pausieren" : "Schutz starten"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Verkehr",
										value: formatBytes(bytesProtected)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Nachfragen",
										value: String(askedCount)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Blockiert",
										value: String(blockedCount)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UrlChecker, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "rounded-xl border border-border bg-surface p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-sm font-medium",
											children: "Phishing-Probe"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: "warn",
											children: "Demo"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs leading-relaxed text-muted",
										children: "Simuliert einen gefälschten Link (Sparkasse, PayPal, DHL) und öffnet die Nachfrage."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "mt-3",
										size: "sm",
										variant: "outline",
										onClick: () => {
											if (!protectionOn) setProtection(true);
											ingest(nextAttack());
										},
										children: "Gefälschte Seite auslösen"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "rounded-xl border border-border bg-surface p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-medium",
										children: "Rechte"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted",
										children: [grantedCount, " von 6 erteilt · erforderliche zuerst"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "mt-3 space-y-1.5 text-xs text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "VPN, Benachrichtigungen, Hintergrund: für den Schutz" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Autostart, App-Zuordnung, Overlay: schärfer, optional" })]
									})
								]
							})
						]
					}) : null,
					tab === "traffic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-xl font-medium tracking-tight",
								children: "Verkehr"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [events.length, " erfasste Verbindungen"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrafficFeed, {})
						]
					}) : null,
					tab === "pack" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-xl font-medium tracking-tight",
							children: "APK-Paket"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadPack, {})]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-lg grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							active: tab === "home",
							onClick: () => setTab("home"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }),
							label: "Schutz"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							active: tab === "traffic",
							onClick: () => setTab("traffic"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" }),
							label: "Verkehr"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							active: tab === "pack",
							onClick: () => setTab("pack"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }),
							label: "ZIP"
						})
					]
				})
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-wider text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-mono text-sm tabular-nums",
			children: value
		})]
	});
}
function NavBtn({ active, onClick, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: `flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] ${active ? "text-primary" : "text-muted"}`,
		children: [icon, label]
	});
}
var ICONS = {
	vpn: Shield,
	notifications: Bell,
	background: Eye,
	boot: Power,
	apps: Smartphone,
	overlay: Layers
};
function Onboarding() {
	const [step, setStep] = (0, import_react.useState)("intro");
	const grant = useShield((s) => s.grantPermission);
	const permissions = useShield((s) => s.permissions);
	const setOnboarded = useShield((s) => s.setOnboarded);
	const setProtection = useShield((s) => s.setProtection);
	async function ask(id) {
		if (id === "notifications" && "Notification" in window) {
			const res = await Notification.requestPermission();
			grant(id, res === "granted");
			return;
		}
		grant(id, true);
	}
	const requiredOk = permissions.vpn.granted && permissions.notifications.asked && permissions.background.granted;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col px-5 pb-10 pt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex items-center gap-2 text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldMark, { className: "size-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium tracking-wide",
					children: "Netzschild"
				})]
			}),
			step === "intro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldMark, {
						pulse: true,
						className: "mb-8 size-20"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-sans text-3xl font-medium leading-tight tracking-tight text-fg",
						children: "Schutz, der nachfragt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-prose text-base leading-relaxed text-muted",
						children: "Netzschild läuft im Hintergrund, sieht den Netzwerkverkehr des Handys und hält an, bevor unsichere oder gefälschte Websites Daten empfangen. Der Inhalt verschlüsselter Seiten wird nicht gelesen — geprüft werden Domain, Ziel und Vertrauenssignale."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 space-y-3 text-sm text-fg",
						children: [
							"Jeder Domain-Aufruf wird lokal geprüft",
							"Bei Zweifel erscheint eine klare Nachfrage",
							"Sperren und Vertrauen legen Sie selbst fest"
						].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t })]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-auto pt-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							size: "lg",
							onClick: () => setStep("permissions"),
							children: "Berechtigungen prüfen"
						})
					})
				]
			}) : null,
			step === "permissions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-medium tracking-tight",
						children: "Nur was nötig ist"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: "Jede Berechtigung wird einzeln erklärt. Nichts wird still eingeschaltet. Pflichtrechte zuerst, optionale danach."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-3",
						children: Object.keys(PERMISSION_COPY).map((id) => {
							const copy = PERMISSION_COPY[id];
							const state = permissions[id];
							const Icon = ICONS[id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-xl border border-border bg-surface p-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 flex size-9 items-center justify-center rounded-md bg-surface-2 text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium",
													children: copy.title
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] uppercase tracking-wider text-subtle",
													children: copy.required ? "Erforderlich" : "Optional"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm leading-relaxed text-muted",
												children: copy.why
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: state.granted ? "secondary" : "default",
												className: "mt-3",
												onClick: () => ask(id),
												children: state.granted ? "Erteilt" : state.asked ? "Erneut fragen" : "Erlauben"
											})
										]
									})]
								})
							}, id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setStep("intro"),
							children: "Zurück"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "flex-1",
							disabled: !requiredOk,
							onClick: () => setStep("ready"),
							children: "Weiter"
						})]
					})
				]
			}) : null,
			step === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldMark, {
						pulse: true,
						className: "mb-8 size-20"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-medium tracking-tight",
						children: "Bereit zum Schützen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "Nach dem Start erscheint ein dauerhafter Hinweis „Netzschild aktiv“. Neue oder zweifelhafte Ziele werden nicht still durchgelassen — Sie entscheiden."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto pt-10 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							size: "lg",
							onClick: () => {
								setProtection(true);
								setOnboarded(true);
							},
							children: "Schutz jetzt starten"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: "ghost",
							onClick: () => {
								setProtection(false);
								setOnboarded(true);
							},
							children: "Zuerst nur ansehen"
						})]
					})
				]
			}) : null
		]
	});
}
function ProtectionLoop() {
	const protectionOn = useShield((s) => s.protectionOn);
	const pending = useShield((s) => s.pending);
	const ingest = useShield((s) => s.ingest);
	const ticks = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		if (!protectionOn) return;
		const id = window.setInterval(() => {
			if (useShield.getState().pending) return;
			ticks.current += 1;
			const sample = ticks.current % 11 === 0 ? nextAttack() : nextBaseline();
			ingest(sample);
		}, 2200);
		return () => window.clearInterval(id);
	}, [protectionOn, ingest]);
	(0, import_react.useEffect)(() => {
		if (!pending) return;
		if (!("Notification" in window) || Notification.permission !== "granted") return;
		try {
			new Notification("Netzschild fragt nach", {
				body: `${pending.app} → ${pending.domain}`,
				tag: pending.id
			});
		} catch {}
	}, [pending]);
	return null;
}
function ThreatDialog() {
	const pending = useShield((s) => s.pending);
	const resolve = useShield((s) => s.resolvePending);
	if (!pending) return null;
	const { inspection, app } = pending;
	const tone = inspection.verdict === "malicious" ? "danger" : inspection.verdict === "suspicious" ? "warn" : "muted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-4 sm:items-center",
		role: "dialog",
		"aria-modal": "true",
		"aria-labelledby": "threat-title",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-xl border border-border bg-bg-elevated p-5 shadow-[0_24px_80px_rgba(0,0,0,0.45)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-10 items-center justify-center rounded-md bg-danger/15 text-danger",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Nachfrage"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "threat-title",
						className: "mt-1 text-lg font-medium",
						children: "Dieser Aufruf ist nicht klar vertrauenswürdig"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-5 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Ziel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-mono text-xs text-fg",
								children: inspection.displayHost
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "App"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: app })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Bewertung"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone,
								children: verdictLabel(inspection.verdict)
							}) })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-2",
					children: inspection.findings.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md border border-border bg-surface px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: f.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs leading-relaxed text-muted",
							children: f.detail
						})]
					}, f.code))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => resolve("blocked"),
							children: "Blockieren"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => resolve("allowed"),
							children: "Nur diesmal erlauben"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => resolve("trusted"),
							children: "Immer vertrauen"
						})
					]
				})
			]
		})
	});
}
function Home() {
	const onboarded = useShield((s) => s.onboarded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProtectionLoop, {}),
		onboarded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreatDialog, {})
	] });
}
//#endregion
export { Home as component };
