import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as EyeOff } from "../_libs/lucide-react.mjs";
import { o as formatCount } from "./model-CryEHs3X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bits-DB9gFqO2.js
var import_jsx_runtime = require_jsx_runtime();
var ROLE_LABEL = {
	mod: "Mod",
	sub: "Sub",
	fan: "Fan",
	viewer: null
};
function initials(nick) {
	return (nick.trim().split(/\s+/).slice(0, 2).map((part) => part[0] ?? "").join("") || "?").toUpperCase();
}
function Avatar({ person, size = "md" }) {
	const box = size === "lg" ? "h-14 w-14 text-lg" : size === "sm" ? "h-8 w-8 text-xs" : "h-10 w-10 text-sm";
	if (person.avatar) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: person.avatar,
		alt: "",
		referrerPolicy: "no-referrer",
		className: `${box} shrink-0 rounded-full object-cover`
	});
	const tone = person.role === "mod" ? "bg-signal text-bg" : person.role === "sub" ? "bg-hot text-bg" : "bg-raised text-fg";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `${box} ${tone} inline-flex shrink-0 items-center justify-center rounded-full font-semibold`,
		children: initials(person.nick)
	});
}
function RoleBadge({ role }) {
	const label = ROLE_LABEL[role];
	if (!label) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full border px-1.5 py-0.5 text-xs font-semibold ${role === "mod" ? "border-signal text-signal" : role === "sub" ? "border-hot text-hot" : "border-line text-muted"}`,
		children: label
	});
}
function ChatLine({ event, onHide, scale = "md", place }) {
	if (!("user" in event)) return null;
	const textSize = scale === "sm" ? "text-sm" : scale === "lg" ? "text-xl" : "text-base";
	const accent = event.kind === "gift" ? "border-hot" : event.kind === "follow" ? "border-signal" : event.kind === "chat" && event.text.startsWith("!") ? "border-signal" : "border-transparent";
	let body = "";
	if (event.kind === "chat") body = event.text;
	else if (event.kind === "gift") body = `envió ${event.gift}${event.repeat > 1 ? ` ×${event.repeat}` : ""}`;
	else if (event.kind === "follow") body = "empezó a seguir";
	else if (event.kind === "share") body = "compartió el live";
	else if (event.kind === "join") body = "entró al live";
	else if (event.kind === "like") body = `envió ${formatCount(event.count)} likes`;
	else return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: `onda-rise group flex gap-3 border-l-2 ${accent} py-2 pl-3`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
			person: event.user,
			size: scale === "lg" ? "md" : "sm"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `truncate font-semibold ${event.kind === "gift" ? "text-hot" : "text-fg"}`,
							children: event.user.nick
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleBadge, { role: event.user.role }),
						place ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-xs text-muted",
							children: place
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "truncate text-xs text-muted",
							children: ["@", event.user.name]
						}),
						onHide ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onHide(event.user.name),
							className: "ml-auto inline-flex h-8 w-8 items-center justify-center rounded-md text-muted opacity-100 hover:bg-raised hover:text-fg lg:opacity-0 lg:group-hover:opacity-100",
							"aria-label": `Ocultar a ${event.user.nick}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-4 w-4" })
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `${textSize} break-words text-pretty text-fg`,
					children: body
				}),
				event.kind === "gift" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm tabular-nums text-muted",
					children: [formatCount(event.diamonds * event.repeat), " monedas"]
				}) : null
			]
		})]
	});
}
function GoalMeter({ label, value, goal, large = false }) {
	const pct = Math.max(0, Math.min(100, Math.round(value / Math.max(1, goal) * 100)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: large ? "font-display text-2xl text-fg" : "text-sm text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: `tabular-nums ${large ? "text-lg text-fg" : "text-sm text-fg"}`,
				children: [formatCount(value), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [" / ", formatCount(goal)]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `mt-2 overflow-hidden rounded-full bg-raised ${large ? "h-3" : "h-2"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-signal",
				style: { width: `${pct}%` }
			})
		}),
		pct >= 100 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm font-semibold text-signal",
			children: "Meta cumplida"
		}) : null
	] });
}
function ToggleRow({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		onClick,
		className: "flex h-11 w-full items-center justify-between gap-3 rounded-md border border-line bg-bg px-3 text-left text-sm text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `flex h-6 w-11 shrink-0 items-center rounded-full p-0.5 ${on ? "bg-signal" : "bg-raised"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-5 w-5 rounded-full ${on ? "translate-x-5 bg-bg" : "bg-muted"}` })
		})]
	});
}
//#endregion
export { GoalMeter as n, ToggleRow as r, ChatLine as t };
