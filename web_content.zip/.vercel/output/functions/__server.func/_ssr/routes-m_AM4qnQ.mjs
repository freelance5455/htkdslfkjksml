import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as Overlay2, c as Title2, i as Description2, n as Cancel, o as Portal2, r as Content2, s as Root2, t as Action, v as Slot, x as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as PanelLeft, i as Plus, n as Trash2, o as Eye, r as Search, s as EyeOff } from "../_libs/lucide-react.mjs";
import { t as Markdown } from "../_libs/react-markdown+[...].mjs";
import { t as remarkGfm } from "../_libs/remark-gfm.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Viewport, i as ScrollAreaThumb, n as Root, r as ScrollAreaScrollbar, t as Corner } from "../_libs/radix-ui__react-scroll-area.mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2$1 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-m_AM4qnQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var components = {
	a: ({ href, children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		target: "_blank",
		rel: "noreferrer noopener",
		children
	}),
	input: ({ node: _node, ...props }) => {
		if (props.type === "checkbox") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			...props,
			disabled: true,
			readOnly: true,
			className: "md-check"
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { ...props });
	}
};
function MarkdownPreview({ content }) {
	if (!content.trim()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-serif text-lg text-subtle",
		children: "Nothing to preview yet. Write a little first."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "md-preview",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, {
			remarkPlugins: [remarkGfm],
			components,
			children: content
		})
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function isModKey(event) {
	return event.metaKey || event.ctrlKey;
}
function formatEdited(ts, now = Date.now()) {
	const seconds = Math.max(0, Math.round((now - ts) / 1e3));
	if (seconds < 45) return "just now";
	const minutes = Math.round(seconds / 60);
	if (minutes < 60) return `${minutes}m ago`;
	const hours = Math.round(minutes / 60);
	if (hours < 24) return `${hours}h ago`;
	const days = Math.round(hours / 24);
	if (days < 7) return `${days}d ago`;
	return new Intl.DateTimeFormat(void 0, {
		month: "short",
		day: "numeric"
	}).format(new Date(ts));
}
var buttonVariants = cva("ui-btn inline-flex items-center justify-center gap-2 whitespace-nowrap font-sans text-sm font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			ghost: "text-muted hover:bg-surface-hover hover:text-fg",
			outline: "text-fg shadow-border hover:bg-surface-hover",
			danger: "text-danger hover:bg-danger-soft"
		},
		size: {
			default: "h-11 rounded-md px-4",
			sm: "h-9 rounded-sm px-3",
			icon: "size-11 rounded-md",
			iconSm: "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, disablePress, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size
		}), disablePress && "ui-btn-static", className),
		...props
	});
}
function ScrollArea({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root, {
		className: cn("relative overflow-hidden", className),
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
				className: "h-full w-full",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Corner, {})
		]
	});
}
function ScrollBar({ className, orientation = "vertical", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
		orientation,
		className: cn("flex touch-none p-px select-none", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border" })
	});
}
function TooltipProvider({ delayDuration = 250, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration,
		...props
	});
}
function Tooltip({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root3, { ...props });
}
function TooltipTrigger({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, { ...props });
}
function TooltipContent({ className, sideOffset = 6, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
		sideOffset,
		className: cn("z-50 rounded-sm bg-fg px-2 py-1 font-sans text-xs text-accent-fg shadow-float", "ui-tooltip-in", className),
		...props
	}) });
}
function EditorPane({ note, preview, queryActive, onChange, onTogglePreview, onDelete, onCreate, onOpenList, editorRef, now, modLabel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-0 min-w-0 flex-1 flex-col bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center gap-1 border-b border-border px-2 py-2 md:gap-2 md:px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon",
					className: "md:hidden",
					onClick: onOpenList,
					"aria-label": "Open notes list",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 flex-1 px-1",
					children: note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-serif text-base font-medium tracking-tight text-fg",
						children: note.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate font-sans text-xs text-subtle tabular-nums",
						children: ["Edited ", formatEdited(note.updatedAt, now)]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-base text-muted",
						children: queryActive ? "No matching note" : "No note selected"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon",
					className: "md:hidden",
					onClick: onCreate,
					"aria-label": "New note",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon",
						onClick: onTogglePreview,
						disabled: !note,
						"aria-label": preview ? "Show editor" : "Show preview",
						"aria-pressed": preview,
						children: preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipContent, { children: [
					preview ? "Edit" : "Preview",
					" · ",
					modLabel,
					"E"
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "danger",
						size: "icon",
						onClick: onDelete,
						disabled: !note,
						"aria-label": "Delete note",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "Delete" })] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-hidden",
			children: !note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyEditor, {
				queryActive,
				onCreate
			}) : preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
				className: "h-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-prose px-5 py-8 md:px-8 md:py-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownPreview, { content: note.content })
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto h-full max-w-prose",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "sr-only",
					htmlFor: "folio-editor",
					children: "Note content"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					id: "folio-editor",
					ref: editorRef,
					className: "writing-surface h-full w-full resize-none bg-transparent px-5 py-8 font-serif text-lg leading-relaxed text-fg focus-visible:outline-none md:px-8 md:py-10",
					value: note.content,
					onChange: (event) => onChange(event.target.value),
					placeholder: "Start writing…",
					spellCheck: true,
					wrap: "soft"
				}, note.id)]
			})
		})]
	});
}
function EmptyEditor({ queryActive, onCreate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col items-center justify-center gap-3 px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-serif text-xl tracking-tight text-fg text-balance",
				children: queryActive ? "Nothing matches that search" : "A blank folio"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm font-sans text-sm text-muted text-pretty",
				children: queryActive ? "Try another word, or start a new note from here." : "Create a note and begin. Everything stays on this device."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				onClick: onCreate,
				children: "New note"
			})
		]
	});
}
function FolioMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-6", className),
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-surface-hover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M9 7h10.2L23 11.8V25H9V7Z",
				className: "fill-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M19.2 7V11.8H23",
				className: "fill-muted"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 16h8M12 19.2h6",
				className: "stroke-accent-fg",
				strokeWidth: "1.4",
				strokeLinecap: "round",
				fill: "none"
			})
		]
	});
}
function Input({ className, type = "text", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("h-11 w-full rounded-md bg-surface-hover px-3 font-sans text-sm text-fg shadow-border", "placeholder:text-subtle", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", "disabled:cursor-not-allowed disabled:opacity-40", className),
		...props
	});
}
function deriveTitle(content) {
	const line = content.split("\n").find((entry) => entry.trim().length > 0);
	if (!line) return "Untitled";
	const cleaned = line.replace(/^#{1,6}\s+/, "").replace(/^\s*[-*+]\s+/, "").replace(/^\s*\d+\.\s+/, "").replace(/[*_`~]/g, "").trim();
	if (!cleaned) return "Untitled";
	return cleaned.slice(0, 80);
}
function notePreview(content) {
	const body = content.split("\n").map((line) => line.trim()).filter((line) => line.length > 0 && !/^#{1,6}\s/.test(line))[0] ?? "";
	if (!body) return "Empty note";
	return body.replace(/[*_`>#-]/g, "").trim().slice(0, 96) || "Empty note";
}
function Sidebar({ notes, selectedId, query, totalCount, onQueryChange, onSelect, onCreate, searchRef, listRef, now, modLabel }) {
	const searching = query.trim().length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 px-4 pt-5 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolioMark, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-lg leading-tight font-medium tracking-tight italic",
							children: "Folio"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-sans text-xs text-subtle",
							children: "Quiet notes"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "iconSm",
						onClick: onCreate,
						"aria-label": "New note",
						title: `New note (${modLabel}N)`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "relative block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Search notes"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							ref: searchRef,
							value: query,
							onChange: (event) => onQueryChange(event.target.value),
							placeholder: "Search",
							className: "pl-9",
							autoComplete: "off",
							autoCorrect: "off",
							spellCheck: false,
							"aria-keyshortcuts": "Meta+K Control+K"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
				className: "min-h-0 flex-1 px-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: listRef,
					role: "listbox",
					"aria-label": "Notes",
					tabIndex: 0,
					className: "flex flex-col gap-1 pb-3 focus-visible:outline-none",
					children: notes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-3 py-8 text-center font-sans text-sm text-subtle",
						children: searching ? "No matching notes" : "No notes yet"
					}) : notes.map((note) => {
						const selected = note.id === selectedId;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							role: "option",
							"aria-selected": selected,
							onClick: () => onSelect(note.id),
							className: cn("note-item flex min-h-11 w-full flex-col items-start gap-1 border-l-2 px-3 py-3 text-left", selected ? "border-accent bg-surface-hover text-fg" : "border-transparent text-muted hover:bg-surface hover:text-fg"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-full truncate font-sans text-sm font-medium",
								children: note.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex w-full items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-xs text-subtle",
									children: notePreview(note.content)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 font-sans text-xs text-subtle tabular-nums",
									children: formatEdited(note.updatedAt, now)
								})]
							})]
						}, note.id);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 px-4 py-3 text-xs text-subtle",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: searching ? `${notes.length} found` : `${totalCount} ${totalCount === 1 ? "note" : "notes"}`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "hidden lg:inline",
					children: [modLabel, "K search"]
				})]
			})
		]
	});
}
function AlertDialog({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root2, { ...props });
}
function AlertDialogPortal({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { ...props });
}
function AlertDialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
		className: cn("fixed inset-0 z-50 bg-overlay ui-overlay-in", className),
		...props
	});
}
function AlertDialogContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		className: cn("dialog-panel fixed top-1/2 left-1/2 z-50 -translate-x-1/2 -translate-y-1/2", "rounded-xl bg-elevated p-5 shadow-float ui-modal-in", className),
		...props
	})] });
}
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-2", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-5 flex justify-end gap-2", className),
		...props
	});
}
function AlertDialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
		className: cn("font-serif text-lg font-medium tracking-tight text-fg text-balance", className),
		...props
	});
}
function AlertDialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
		className: cn("font-sans text-sm leading-normal text-muted text-pretty", className),
		...props
	});
}
function AlertDialogAction({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
		className: cn(buttonVariants(), className),
		...props
	});
}
function AlertDialogCancel({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
		className: cn(buttonVariants({ variant: "ghost" }), className),
		...props
	});
}
var WELCOME = `# Welcome to Folio

A quiet place for notes. Write in **Markdown**, search instantly, and stay on the keyboard.

## Shortcuts

- \`⌘/Ctrl N\` — new note
- \`⌘/Ctrl K\` — search
- \`⌘/Ctrl E\` — toggle preview
- \`↑\` \`↓\` — move through the list
- \`Delete\` — delete the selected note (from the list)
- \`Escape\` — back to the list

Open preview to see this page rendered.
`;
var MARKS = `# Markdown marks

Write _italics_, **bold**, and \`inline code\`.

> Short quotes sit in the margin.

- Lists
- Feel
- Natural

1. Then numbered
2. When you need order

A [link](https://example.com) when you must leave the page.

- [ ] Outline the essay
- [x] Open Folio
`;
var EVENING = `# Tuesday, late

The room is quiet enough to hear the keys. That is the whole point.

Keep this note, rewrite it, or throw it away. Folio stores everything on this device — nothing leaves unless you copy it out.
`;
function createSampleNotes(now = Date.now()) {
	return [
		{
			id: "welcome",
			title: "Welcome to Folio",
			content: WELCOME,
			createdAt: now - 936e5,
			updatedAt: now - 72e4
		},
		{
			id: "markdown-marks",
			title: "Markdown marks",
			content: MARKS,
			createdAt: now - 144e6,
			updatedAt: now - 18e6
		},
		{
			id: "tuesday-late",
			title: "Tuesday, late",
			content: EVENING,
			createdAt: now - 288e5,
			updatedAt: now - 288e5
		}
	];
}
function newId() {
	if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
	return `note_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
function emptyStorage() {
	return {
		getItem: () => null,
		setItem: () => {},
		removeItem: () => {}
	};
}
var defaultState = {
	notes: [],
	selectedId: null,
	preview: false,
	seeded: false
};
var useNotesStore = create()(persist((set, get) => ({
	...defaultState,
	hydrated: false,
	setHydrated: (value) => set({ hydrated: value }),
	createNote: () => {
		const now = Date.now();
		const note = {
			id: newId(),
			title: "Untitled",
			content: "",
			createdAt: now,
			updatedAt: now
		};
		set({
			notes: [note, ...get().notes],
			selectedId: note.id,
			preview: false
		});
		return note.id;
	},
	updateContent: (id, content) => {
		const now = Date.now();
		set({ notes: get().notes.map((note) => note.id === id ? {
			...note,
			content,
			title: deriveTitle(content),
			updatedAt: now
		} : note).sort((a, b) => b.updatedAt - a.updatedAt) });
	},
	deleteNote: (id) => {
		const remaining = get().notes.filter((note) => note.id !== id);
		set({
			notes: remaining,
			selectedId: get().selectedId === id ? remaining[0]?.id ?? null : get().selectedId
		});
	},
	selectNote: (id) => set({ selectedId: id }),
	togglePreview: () => set({ preview: !get().preview }),
	setPreview: (value) => set({ preview: value })
}), {
	name: "folio-notes-v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? emptyStorage() : localStorage),
	partialize: (state) => ({
		notes: state.notes,
		selectedId: state.selectedId,
		preview: state.preview,
		seeded: state.seeded
	}),
	merge: (persisted, current) => {
		const saved = persisted ?? {};
		const notes = Array.isArray(saved.notes) ? saved.notes : [];
		const seeded = Boolean(saved.seeded);
		if (notes.length === 0 && !seeded) {
			const sample = createSampleNotes();
			return {
				...current,
				notes: sample,
				selectedId: sample[0]?.id ?? null,
				preview: Boolean(saved.preview),
				seeded: true
			};
		}
		const selectedId = notes.some((note) => note.id === saved.selectedId) ? saved.selectedId ?? null : notes[0]?.id ?? null;
		return {
			...current,
			notes,
			selectedId,
			preview: Boolean(saved.preview),
			seeded: true
		};
	}
}));
function rehydrateNotes() {
	let finished = false;
	const finish = () => {
		if (finished) return;
		finished = true;
		const state = useNotesStore.getState();
		if (state.notes.length === 0 && !state.seeded) {
			const sample = createSampleNotes();
			useNotesStore.setState({
				notes: sample,
				selectedId: sample[0]?.id ?? null,
				seeded: true,
				hydrated: true
			});
			return;
		}
		useNotesStore.setState({ hydrated: true });
	};
	const unsub = useNotesStore.persist.onFinishHydration(finish);
	useNotesStore.persist.rehydrate();
	if (useNotesStore.persist.hasHydrated()) finish();
	return unsub;
}
function useNow(interval = 3e4) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), interval);
		return () => window.clearInterval(id);
	}, [interval]);
	return now;
}
function useModLabel() {
	const [label, setLabel] = (0, import_react.useState)("Ctrl");
	(0, import_react.useEffect)(() => {
		const mac = /Mac|iPhone|iPad|iPod/i.test(navigator.platform);
		setLabel(mac ? "⌘" : "Ctrl");
	}, []);
	return label;
}
function NotesApp() {
	const hydrated = useNotesStore((state) => state.hydrated);
	const notes = useNotesStore((state) => state.notes);
	const selectedId = useNotesStore((state) => state.selectedId);
	const preview = useNotesStore((state) => state.preview);
	const createNote = useNotesStore((state) => state.createNote);
	const updateContent = useNotesStore((state) => state.updateContent);
	const deleteNote = useNotesStore((state) => state.deleteNote);
	const selectNote = useNotesStore((state) => state.selectNote);
	const togglePreview = useNotesStore((state) => state.togglePreview);
	const [query, setQuery] = (0, import_react.useState)("");
	const [listOpen, setListOpen] = (0, import_react.useState)(false);
	const [deleteOpen, setDeleteOpen] = (0, import_react.useState)(false);
	const [focusTick, setFocusTick] = (0, import_react.useState)(0);
	const searchRef = (0, import_react.useRef)(null);
	const listRef = (0, import_react.useRef)(null);
	const editorRef = (0, import_react.useRef)(null);
	const now = useNow();
	const modLabel = useModLabel();
	(0, import_react.useEffect)(() => rehydrateNotes(), []);
	(0, import_react.useEffect)(() => {
		if (focusTick === 0) return;
		editorRef.current?.focus();
	}, [
		focusTick,
		selectedId,
		preview
	]);
	const visibleNotes = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		if (!needle) return notes;
		return notes.filter((note) => note.title.toLowerCase().includes(needle) || note.content.toLowerCase().includes(needle));
	}, [notes, query]);
	const selected = notes.find((note) => note.id === selectedId) ?? null;
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (visibleNotes.some((note) => note.id === selectedId)) return;
		selectNote(visibleNotes[0]?.id ?? null);
	}, [
		hydrated,
		query,
		visibleNotes,
		selectedId,
		selectNote
	]);
	const handleCreate = (0, import_react.useCallback)(() => {
		setQuery("");
		setListOpen(false);
		createNote();
		setFocusTick((tick) => tick + 1);
	}, [createNote]);
	const handleSelect = (0, import_react.useCallback)((id) => {
		selectNote(id);
		setListOpen(false);
	}, [selectNote]);
	const requestDelete = (0, import_react.useCallback)(() => {
		if (!selected) return;
		if (!selected.content.trim()) {
			deleteNote(selected.id);
			return;
		}
		setDeleteOpen(true);
	}, [selected, deleteNote]);
	const confirmDelete = (0, import_react.useCallback)(() => {
		if (!selected) return;
		deleteNote(selected.id);
		setDeleteOpen(false);
	}, [selected, deleteNote]);
	const moveSelection = (0, import_react.useCallback)((delta) => {
		if (visibleNotes.length === 0) return;
		const index = visibleNotes.findIndex((note) => note.id === selectedId);
		const nextIndex = index < 0 ? delta > 0 ? 0 : visibleNotes.length - 1 : Math.max(0, Math.min(visibleNotes.length - 1, index + delta));
		const next = visibleNotes[nextIndex];
		if (next) selectNote(next.id);
		listRef.current?.focus();
	}, [
		visibleNotes,
		selectedId,
		selectNote
	]);
	(0, import_react.useEffect)(() => {
		function onKeyDown(event) {
			if (event.isComposing || deleteOpen) return;
			const target = event.target;
			const inField = Boolean(target) && (target?.tagName === "INPUT" || target?.tagName === "TEXTAREA" || Boolean(target?.isContentEditable));
			const mod = isModKey(event);
			const listFocused = Boolean(listRef.current?.contains(document.activeElement));
			if (event.key === "Escape") {
				if (listOpen) {
					setListOpen(false);
					event.preventDefault();
					return;
				}
				if (document.activeElement === searchRef.current && query) {
					setQuery("");
					event.preventDefault();
					return;
				}
				listRef.current?.focus();
				event.preventDefault();
				return;
			}
			if (mod && event.key.toLowerCase() === "n") {
				event.preventDefault();
				handleCreate();
				return;
			}
			if (mod && event.key.toLowerCase() === "k") {
				event.preventDefault();
				setListOpen(true);
				searchRef.current?.focus();
				searchRef.current?.select();
				return;
			}
			if (mod && event.key.toLowerCase() === "e") {
				event.preventDefault();
				if (selected) togglePreview();
				return;
			}
			if (mod && event.key.toLowerCase() === "s") {
				event.preventDefault();
				return;
			}
			if (event.key === "/" && !inField && !mod) {
				event.preventDefault();
				setListOpen(true);
				searchRef.current?.focus();
				return;
			}
			if ((event.key === "ArrowDown" || event.key === "ArrowUp" || (!inField || listFocused) && (event.key === "j" || event.key === "k")) && (listFocused || document.activeElement === searchRef.current || !inField)) {
				if ((event.key === "j" || event.key === "k") && inField && !listFocused) return;
				event.preventDefault();
				moveSelection(event.key === "ArrowDown" || event.key === "j" ? 1 : -1);
				return;
			}
			if ((event.key === "Delete" || event.key === "Backspace") && listFocused && !mod) {
				if (document.activeElement?.tagName === "INPUT") return;
				event.preventDefault();
				requestDelete();
			}
		}
		window.addEventListener("keydown", onKeyDown);
		return () => window.removeEventListener("keydown", onKeyDown);
	}, [
		deleteOpen,
		listOpen,
		query,
		selected,
		handleCreate,
		togglePreview,
		moveSelection,
		requestDelete
	]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesSkeleton, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-shell flex overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "sidebar-backdrop fixed inset-0 z-30 bg-overlay md:hidden",
				"data-open": listOpen,
				tabIndex: listOpen ? 0 : -1,
				"aria-label": "Close notes list",
				onClick: () => setListOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: cn("sidebar-drawer fixed inset-y-0 left-0 z-40 flex h-full flex-col shadow-float md:relative md:z-0 md:shadow-none", "md:w-sidebar md:shrink-0 md:border-r md:border-border"),
				"data-open": listOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
					notes: visibleNotes,
					selectedId,
					query,
					totalCount: notes.length,
					onQueryChange: setQuery,
					onSelect: handleSelect,
					onCreate: handleCreate,
					searchRef,
					listRef,
					now,
					modLabel
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorPane, {
				note: selected,
				preview,
				queryActive: query.trim().length > 0,
				onChange: (content) => {
					if (selected) updateContent(selected.id, content);
				},
				onTogglePreview: togglePreview,
				onDelete: requestDelete,
				onCreate: handleCreate,
				onOpenList: () => setListOpen(true),
				editorRef,
				now,
				modLabel
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: deleteOpen,
		onOpenChange: setDeleteOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Delete this note?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: selected ? `“${selected.title}” will be removed from this device. This cannot be undone.` : "This note will be removed from this device." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Keep" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
			onClick: confirmDelete,
			children: "Delete"
		})] })] })
	})] });
}
function NotesSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-shell flex overflow-hidden bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden h-full w-sidebar shrink-0 border-r border-border bg-bg md:block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-4 pt-5 pb-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-24 rounded-sm bg-surface-hover" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-3 pb-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-11 rounded-md bg-surface-hover" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 px-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 rounded-md bg-surface" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 rounded-md bg-surface" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 rounded-md bg-surface" })
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex min-w-0 flex-1 flex-col bg-paper",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border px-4 py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-40 rounded-sm bg-surface-hover" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-8 py-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-56 rounded-sm bg-surface-hover" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-6 h-4 w-full max-w-prose rounded-sm bg-surface" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-4 w-4/5 max-w-prose rounded-sm bg-surface" })
				]
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesApp, {});
}
//#endregion
export { Home as component };
