//#region node_modules/.nitro/vite/services/ssr/assets/astro-2CYvScwN.js
/** Naked-eye astronomy: horizon coordinates and low-precision planet positions.
*  Planetary elements follow Paul Schlyter's public-domain algorithm
*  (stjarnhimlen.se), accurate to about a degree — enough to learn the sky,
*  not enough to point a telescope.
*/
var DEG = Math.PI / 180;
var RAD = 180 / Math.PI;
function wrap360(d) {
	return (d % 360 + 360) % 360;
}
function wrap24(h) {
	return (h % 24 + 24) % 24;
}
function rad(d) {
	return d * DEG;
}
function deg(r) {
	return r * RAD;
}
function julianDay(date) {
	return date.getTime() / 864e5 + 2440587.5;
}
/** Days since 2000 Jan 0.0 UT (Schlyter day number). */
function dayNumber(date) {
	return julianDay(date) - 2451543.5;
}
function lstHours(date, lonDeg) {
	return wrap24(wrap360(280.46061837 + 360.98564736629 * (julianDay(date) - 2451545)) / 15 + lonDeg / 15);
}
function toAltAz(raHours, decDeg, latDeg, lst) {
	const ha = rad((lst - raHours) * 15);
	const dec = rad(decDeg);
	const lat = rad(latDeg);
	const sinAlt = Math.sin(dec) * Math.sin(lat) + Math.cos(dec) * Math.cos(lat) * Math.cos(ha);
	const alt = Math.asin(Math.max(-1, Math.min(1, sinAlt)));
	const cosAz = (Math.sin(dec) - Math.sin(alt) * Math.sin(lat)) / (Math.cos(alt) * Math.cos(lat) || 1e-6);
	let az = Math.acos(Math.max(-1, Math.min(1, cosAz)));
	if (Math.sin(ha) > 0) az = 2 * Math.PI - az;
	return {
		alt: deg(alt),
		az: deg(az)
	};
}
function kepler(Mdeg, e) {
	const Mr = rad(wrap360(Mdeg));
	let E = Mr + e * Math.sin(Mr) * (1 + e * Math.cos(Mr));
	for (let i = 0; i < 15; i++) {
		const dE = (E - e * Math.sin(E) - Mr) / (1 - e * Math.cos(E));
		E -= dE;
		if (Math.abs(dE) < 1e-8) break;
	}
	return E;
}
function helio(el) {
	const E = kepler(el.M, el.e);
	const xv = el.a * (Math.cos(E) - el.e);
	const yv = el.a * Math.sqrt(1 - el.e * el.e) * Math.sin(E);
	const v = Math.atan2(yv, xv);
	const r = Math.hypot(xv, yv);
	const N = rad(el.N);
	const i = rad(el.i);
	const vw = v + rad(el.w);
	const x = r * (Math.cos(N) * Math.cos(vw) - Math.sin(N) * Math.sin(vw) * Math.cos(i));
	const y = r * (Math.sin(N) * Math.cos(vw) + Math.cos(N) * Math.sin(vw) * Math.cos(i));
	const z = r * Math.sin(vw) * Math.sin(i);
	return {
		x,
		y,
		z,
		r,
		lon: deg(Math.atan2(y, x)),
		lat: deg(Math.atan2(z, Math.hypot(x, y)))
	};
}
function earthEls(d) {
	return {
		N: 0,
		i: 0,
		w: 282.9404 + 470935e-10 * d,
		a: 1,
		e: .016709 - 1.151e-9 * d,
		M: 356.047 + .9856002585 * d
	};
}
/** Sun elements are the Sun's apparent geocentric orbit, so v + w is already
*  the Sun's ecliptic longitude. Planet geocentric = heliocentric + that Sun vector. */
function sunGeo(d) {
	const s = helio(earthEls(d));
	return {
		x: s.x,
		y: s.y,
		z: s.z,
		lon: wrap360(s.lon),
		r: s.r
	};
}
function obliquity(d) {
	return rad(23.4393 - 3.563e-7 * d);
}
function equatorial(x, y, z, d) {
	const ecl = obliquity(d);
	const xe = x;
	const ye = y * Math.cos(ecl) - z * Math.sin(ecl);
	const ze = y * Math.sin(ecl) + z * Math.cos(ecl);
	return {
		ra: wrap24(deg(Math.atan2(ye, xe)) / 15),
		dec: deg(Math.atan2(ze, Math.hypot(xe, ye)))
	};
}
var PLANETS = [
	{
		id: "mercury",
		name: "Mercury",
		blurb: "Innermost planet. Easy to miss — it never climbs far from the Sun, so look in twilight, low in the sky.",
		els: (d) => ({
			N: 48.3313 + 324587e-10 * d,
			i: 7.0047 + 5e-8 * d,
			w: 29.1241 + 101444e-10 * d,
			a: .387098,
			e: .205635 + 559e-12 * d,
			M: 168.6562 + 4.0923344368 * d
		})
	},
	{
		id: "venus",
		name: "Venus",
		blurb: "The brightest planet. Thick cloud, not a star. It is only an evening or morning star — never high at midnight.",
		els: (d) => ({
			N: 76.6799 + 24659e-9 * d,
			i: 3.3946 + 2.75e-8 * d,
			w: 54.891 + 138374e-10 * d,
			a: .72333,
			e: .006773 - 1.302e-9 * d,
			M: 48.0052 + 1.6021302244 * d
		})
	},
	{
		id: "mars",
		name: "Mars",
		blurb: "A cold desert. Once you compare it with a white star, the rust color is obvious.",
		els: (d) => ({
			N: 49.5574 + 211081e-10 * d,
			i: 1.8497 - 1.78e-8 * d,
			w: 286.5016 + 292961e-10 * d,
			a: 1.523688,
			e: .093405 + 2.516e-9 * d,
			M: 18.6021 + .5240207766 * d
		})
	},
	{
		id: "jupiter",
		name: "Jupiter",
		blurb: "Largest planet, steady and bright. Four of its moons show up in binoculars as a tiny line of dots.",
		els: (d) => ({
			N: 100.4542 + 276854e-10 * d,
			i: 1.303 - 1.557e-7 * d,
			w: 273.8777 + 164505e-10 * d,
			a: 5.20256,
			e: .048498 + 4.469e-9 * d,
			M: 19.895 + .0830853001 * d
		})
	},
	{
		id: "saturn",
		name: "Saturn",
		blurb: "To the eye, a calm yellow point. The rings need a small telescope — Galileo thought they were handles.",
		els: (d) => ({
			N: 113.6634 + 23898e-9 * d,
			i: 2.4886 - 1.081e-7 * d,
			w: 339.3939 + 297661e-10 * d,
			a: 9.55475,
			e: .055546 - 9.499e-9 * d,
			M: 316.967 + .0334442282 * d
		})
	}
];
function sinD(x) {
	return Math.sin(rad(x));
}
function moonGeo(d) {
	const N = 125.1228 - .0529538083 * d;
	const i = 5.1454;
	const w = 318.0634 + .1643573223 * d;
	const e = .0549;
	const M = 115.3654 + 13.0649929509 * d;
	const Ms = 356.047 + .9856002585 * d;
	const ws = 282.9404 + 470935e-10 * d;
	const Lm = M + w + N;
	const D = Lm - (Ms + ws);
	const F = Lm - N;
	const E = kepler(M, e);
	const a = 60.2666;
	const xv = a * (Math.cos(E) - e);
	const yv = a * Math.sqrt(1 - e * e) * Math.sin(E);
	const v = Math.atan2(yv, xv);
	const r = Math.hypot(xv, yv);
	const Nr = rad(N);
	const ir = rad(i);
	const vw = v + rad(w);
	const xh = r * (Math.cos(Nr) * Math.cos(vw) - Math.sin(Nr) * Math.sin(vw) * Math.cos(ir));
	const yh = r * (Math.sin(Nr) * Math.cos(vw) + Math.cos(Nr) * Math.sin(vw) * Math.cos(ir));
	const zh = r * Math.sin(vw) * Math.sin(ir);
	let lon = deg(Math.atan2(yh, xh));
	let lat = deg(Math.atan2(zh, Math.hypot(xh, yh)));
	lon += -1.274 * sinD(M - 2 * D) + .658 * sinD(2 * D) - .186 * sinD(Ms) - .059 * sinD(2 * M - 2 * D) - .057 * sinD(M - 2 * D + Ms) + .053 * sinD(M + 2 * D) + .046 * sinD(2 * D - Ms) + .041 * sinD(M - Ms) - .035 * sinD(D) - .031 * sinD(M + Ms) - .015 * sinD(2 * F - 2 * D) + .011 * sinD(M - 4 * D);
	lat += -.173 * sinD(F - 2 * D) - .055 * sinD(M - F - 2 * D) - .046 * sinD(M + F - 2 * D) + .033 * sinD(F + 2 * D) + .017 * sinD(2 * M + F);
	const lonR = rad(wrap360(lon));
	const latR = rad(lat);
	const eq = equatorial(Math.cos(latR) * Math.cos(lonR), Math.cos(latR) * Math.sin(lonR), Math.sin(latR), d);
	return {
		lon: wrap360(lon),
		lat,
		ra: eq.ra,
		dec: eq.dec
	};
}
function lightPhrase(au) {
	const minutes = au * 8.317;
	if (minutes < 2) return `${Math.round(minutes * 60)} light-seconds`;
	if (minutes < 90) return `${minutes.toFixed(1)} light-minutes`;
	return `${(minutes / 60).toFixed(1)} light-hours`;
}
function moonPhase(date) {
	const d = dayNumber(date);
	const sun = sunGeo(d);
	const elongation = wrap360(moonGeo(d).lon - sun.lon);
	const fraction = (1 - Math.cos(rad(elongation))) / 2;
	const waxing = elongation < 180;
	let name = "New moon";
	if (elongation < 22 || elongation > 338) name = "New moon";
	else if (elongation < 68) name = "Waxing crescent";
	else if (elongation < 112) name = "First quarter";
	else if (elongation < 158) name = "Waxing gibbous";
	else if (elongation < 202) name = "Full moon";
	else if (elongation < 248) name = "Waning gibbous";
	else if (elongation < 292) name = "Last quarter";
	else name = "Waning crescent";
	return {
		name,
		fraction,
		waxing,
		elongation
	};
}
function bodiesAt(date) {
	const d = dayNumber(date);
	const sun = sunGeo(d);
	const sunEq = equatorial(sun.x, sun.y, sun.z, d);
	const out = [{
		id: "sun",
		name: "Sun",
		kind: "sun",
		ra: sunEq.ra,
		dec: sunEq.dec,
		elongation: 0,
		note: `Our star. Sunlight takes ${lightPhrase(sun.r)} to reach Earth. Anything within a few degrees of it is lost in the glare.`
	}];
	const moon = moonGeo(d);
	const phase = moonPhase(date);
	out.push({
		id: "moon",
		name: "Moon",
		kind: "moon",
		ra: moon.ra,
		dec: moon.dec,
		elongation: phase.elongation,
		note: `${phase.name}, about ${Math.round(phase.fraction * 100)}% of the disk lit. Moonlight takes about 1.3 seconds to arrive. The phase is geometry — not Earth's shadow.`
	});
	for (const p of PLANETS) {
		const h = helio(p.els(d));
		const x = h.x + sun.x;
		const y = h.y + sun.y;
		const z = h.z + sun.z;
		const eq = equatorial(x, y, z, d);
		const dist = Math.hypot(x, y, z);
		const elongation = wrap360(deg(Math.atan2(y, x)) - sun.lon);
		const glare = (elongation > 180 ? 360 - elongation : elongation) < 15 ? " Right now it sits too close to the Sun to see." : "";
		out.push({
			id: p.id,
			name: p.name,
			kind: "planet",
			ra: eq.ra,
			dec: eq.dec,
			elongation,
			note: `${p.blurb} About ${dist.toFixed(2)} AU from Earth — ${lightPhrase(dist)}.${glare}`
		});
	}
	return out;
}
function eclipticSamples() {
	const eps = rad(23.4393);
	const pts = [];
	for (let i = 0; i <= 72; i++) {
		const lon = rad(i * 5);
		const dec = Math.asin(Math.sin(eps) * Math.sin(lon));
		const ra = Math.atan2(Math.sin(lon) * Math.cos(eps), Math.cos(lon));
		pts.push({
			ra: wrap24(deg(ra) / 15),
			dec: deg(dec)
		});
	}
	return pts;
}
function seasonStats(latDeg, dayOfYear) {
	const dec = 23.44 * Math.sin((dayOfYear - 79) / 365 * 2 * Math.PI);
	const lat = rad(latDeg);
	const decR = rad(dec);
	const noonAlt = deg(Math.asin(Math.sin(lat) * Math.sin(decR) + Math.cos(lat) * Math.cos(decR)));
	const cosH = -(Math.tan(lat) * Math.tan(decR));
	let dayHours;
	if (!Number.isFinite(cosH) || cosH <= -1) dayHours = latDeg * dec > 0 ? 24 : 0;
	else if (cosH >= 1) dayHours = 0;
	else dayHours = 2 * deg(Math.acos(Math.max(-1, Math.min(1, cosH)))) / 15;
	return {
		dec,
		noonAlt,
		dayHours,
		equinox: Math.abs(dec) < 2
	};
}
function formatLat(lat) {
	const hemi = lat >= 0 ? "N" : "S";
	const abs = Math.abs(lat);
	return `${abs >= 10 ? abs.toFixed(0) : abs.toFixed(1)}°${hemi}`;
}
function formatLon(lon) {
	const hemi = lon >= 0 ? "E" : "W";
	return `${Math.abs(lon).toFixed(0)}°${hemi}`;
}
function formatRa(hours) {
	const h = wrap24(hours);
	const hh = Math.floor(h);
	const m = Math.round((h - hh) * 60);
	if (m === 60) {
		const h2 = (hh + 1) % 24;
		return `${String(h2).padStart(2, "0")}h 00m`;
	}
	return `${String(hh).padStart(2, "0")}h ${String(m).padStart(2, "0")}m`;
}
function formatDec(dec) {
	return `${dec >= 0 ? "+" : "−"}${Math.abs(dec).toFixed(1)}°`;
}
function formatAlt(alt) {
	return `${alt >= 0 ? "+" : "−"}${Math.abs(alt).toFixed(0)}°`;
}
var COMPASS = [
	"N",
	"NNE",
	"NE",
	"ENE",
	"E",
	"ESE",
	"SE",
	"SSE",
	"S",
	"SSW",
	"SW",
	"WSW",
	"W",
	"WNW",
	"NW",
	"NNW"
];
function compass(az) {
	return COMPASS[Math.round(wrap360(az) / 22.5) % 16] ?? "N";
}
var MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
function formatHours(h) {
	if (!Number.isFinite(h)) return "—";
	const clamped = Math.max(0, Math.min(24, h));
	let hh = Math.floor(clamped);
	let m = Math.round((clamped - hh) * 60);
	if (m === 60) {
		hh += 1;
		m = 0;
	}
	return `${hh}h ${String(m).padStart(2, "0")}m`;
}
function formatCivil(date, lon) {
	const shifted = new Date(date.getTime() + lon / 15 * 36e5);
	const h = shifted.getUTCHours();
	const m = shifted.getUTCMinutes();
	const ampm = h >= 12 ? "pm" : "am";
	const hr = h % 12 === 0 ? 12 : h % 12;
	return `${shifted.getUTCDate()} ${MONTHS[shifted.getUTCMonth()]} ${shifted.getUTCFullYear()} · ${hr}:${String(m).padStart(2, "0")} ${ampm}`;
}
function localHour(date, lon) {
	const shifted = new Date(date.getTime() + lon / 15 * 36e5);
	return shifted.getUTCHours() + shifted.getUTCMinutes() / 60;
}
function localMonth(date, lon) {
	return new Date(date.getTime() + lon / 15 * 36e5).getUTCMonth() + 1;
}
function skyInstant(lon, custom, now) {
	if (!custom) return now;
	let minutes = custom.hour * 60 - lon / 15 * 60;
	let day = 15;
	while (minutes < 0) {
		minutes += 1440;
		day -= 1;
	}
	while (minutes >= 1440) {
		minutes -= 1440;
		day += 1;
	}
	const uh = Math.floor(minutes / 60);
	const um = Math.round(minutes % 60);
	return new Date(Date.UTC(2026, custom.month - 1, day, uh, um));
}
function twilight(sunAlt) {
	if (sunAlt >= 0) return "The Sun is up. Stars are still drawn, so you can learn the layout they keep behind the blue.";
	if (sunAlt >= -6) return "Civil twilight. Only Venus, the Moon, and the brightest stars really show.";
	if (sunAlt >= -12) return "Nautical twilight. The brighter patterns are coming out.";
	if (sunAlt >= -18) return "Astronomical twilight. Give it a few minutes and the sky is fully dark.";
	return null;
}
function monthName(m) {
	return MONTHS[Math.min(12, Math.max(1, m)) - 1] ?? "January";
}
//#endregion
export { toAltAz as _, formatCivil as a, formatLat as c, localHour as d, localMonth as f, skyInstant as g, seasonStats as h, formatAlt as i, formatLon as l, monthName as m, compass as n, formatDec as o, lstHours as p, eclipticSamples as r, formatHours as s, bodiesAt as t, formatRa as u, twilight as v };
