import { i as __toESM } from "../_runtime.mjs";
import { a as findCatalog, t as CATALOG } from "./catalog-D0BjXlW4.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as viewsOf, g as viewHolding, m as sumViews, n as usePortfolio, s as fxToHuf } from "./router-Ddmv2GI8.mjs";
import { t as Shell } from "./shell-wztA7KjE.mjs";
import { f as formatQty, g as uid, i as Modal, l as formatMoney, m as pnlClass, n as Field, r as KIND_LABEL, t as CLASS_LABEL } from "./format-Bbm5TEoT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/eszkozok-CxIIXqwZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CURRENCIES = [
	"HUF",
	"EUR",
	"USD",
	"GBP"
];
var CLASSES = [
	"etf",
	"reszveny",
	"kripto",
	"keszpenz"
];
function num(value) {
	const parsed = Number(value.replace(/\s/g, "").replace(",", "."));
	return Number.isFinite(parsed) ? parsed : NaN;
}
function HoldingDialog({ open, holding, mode, onClose }) {
	const { state, saveHolding, refresh } = usePortfolio();
	const [source, setSource] = (0, import_react.useState)("VWCE");
	const [symbol, setSymbol] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [assetClass, setAssetClass] = (0, import_react.useState)("etf");
	const [currency, setCurrency] = (0, import_react.useState)("EUR");
	const [groupId, setGroupId] = (0, import_react.useState)(state.groups[0]?.id ?? "");
	const [quantity, setQuantity] = (0, import_react.useState)("");
	const [avgCost, setAvgCost] = (0, import_react.useState)("");
	const [costFx, setCostFx] = (0, import_react.useState)("");
	const [manualPrice, setManualPrice] = (0, import_react.useState)("");
	const [yahoo, setYahoo] = (0, import_react.useState)("");
	const [gecko, setGecko] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const cash = holding?.assetClass === "keszpenz" || !holding && mode === "cash";
		const known = holding ? findCatalog(holding.symbol) : void 0;
		setSource(cash ? "cash" : known?.symbol ?? (holding ? "custom" : "VWCE"));
		setSymbol(holding?.symbol ?? "");
		setName(holding?.name ?? "");
		setAssetClass(holding?.assetClass ?? (cash ? "keszpenz" : "etf"));
		setCurrency(holding?.currency ?? (cash ? "EUR" : "EUR"));
		setGroupId(holding?.groupId ?? state.groups[0]?.id ?? "");
		setQuantity(holding ? String(holding.quantity) : "");
		setAvgCost(holding ? String(holding.avgCost) : cash ? "1" : "");
		setCostFx(holding ? String(holding.costFxToHuf) : "");
		setManualPrice(holding?.manualPrice ? String(holding.manualPrice) : "");
		setYahoo(holding?.yahoo ?? "");
		setGecko(holding?.gecko ?? "");
		setError("");
	}, [
		open,
		holding,
		mode,
		state.groups
	]);
	const catalog = source !== "custom" && source !== "cash" ? findCatalog(source) : void 0;
	const resolvedClass = source === "cash" ? "keszpenz" : catalog?.assetClass ?? assetClass;
	const resolvedCurrency = source === "cash" ? currency : catalog?.currency ?? currency;
	const save = () => {
		const qty = num(quantity);
		const cost = resolvedClass === "keszpenz" ? 1 : num(avgCost);
		const fxInput = num(costFx);
		const fx = Number.isFinite(fxInput) && fxInput > 0 ? fxInput : fxToHuf(resolvedCurrency, state.market.fx);
		const sym = (source === "cash" ? resolvedCurrency : catalog?.symbol ?? symbol).trim().toUpperCase();
		if (!sym) return setError("Kell egy szimbólum.");
		if (!groupId) return setError("Válassz csoportot.");
		if (!Number.isFinite(qty) || qty < 0) return setError("A mennyiség nem szám.");
		if (!Number.isFinite(cost) || cost < 0) return setError("A bekerülési ár nem szám.");
		const manual = num(manualPrice);
		const next = {
			id: holding?.id ?? uid(),
			symbol: sym,
			name: source === "cash" ? `Készpénz (${resolvedCurrency})` : name || catalog?.name || sym,
			assetClass: resolvedClass,
			currency: resolvedCurrency,
			groupId,
			quantity: qty,
			avgCost: cost,
			costFxToHuf: resolvedCurrency === "HUF" ? 1 : fx,
			manualPrice: Number.isFinite(manual) && manual > 0 ? manual : void 0,
			yahoo: yahoo.trim().toUpperCase() || catalog?.yahoo,
			gecko: gecko.trim().toLowerCase() || catalog?.gecko,
			chain: holding?.chain,
			walletAddress: holding?.walletAddress
		};
		saveHolding(next);
		onClose();
		refresh();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: holding ? "Eszköz módosítása" : source === "cash" || mode === "cash" ? "Készpénz" : "Új eszköz",
		description: "Ugyanaz a papír több csoportban is lehet, külön soron.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				mode === "asset" || holding?.assetClass !== "keszpenz" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Katalógus",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: source,
						onChange: (event) => setSource(event.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
								label: "ETF",
								children: CATALOG.filter((item) => item.assetClass === "etf").map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: item.symbol,
									children: [
										item.symbol,
										" · ",
										item.name
									]
								}, item.symbol))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
								label: "Részvény",
								children: CATALOG.filter((item) => item.assetClass === "reszveny").map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: item.symbol,
									children: [
										item.symbol,
										" · ",
										item.name
									]
								}, item.symbol))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
								label: "Kripto",
								children: CATALOG.filter((item) => item.assetClass === "kripto").map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: item.symbol,
									children: [
										item.symbol,
										" · ",
										item.name
									]
								}, item.symbol))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "custom",
								children: "Saját szimbólum"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "cash",
								children: "Készpénz"
							})
						]
					})
				}) : null,
				source === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Szimbólum",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: symbol,
								onChange: (event) => setSymbol(event.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Név",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: name,
								onChange: (event) => setName(event.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Osztály",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field",
								value: assetClass,
								onChange: (event) => setAssetClass(event.target.value),
								children: CLASSES.filter((item) => item !== "keszpenz").map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: CLASS_LABEL[item]
								}, item))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Jegyzés devizája",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field",
								value: currency,
								onChange: (event) => setCurrency(event.target.value),
								children: CURRENCIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Yahoo szimbólum",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: yahoo,
								placeholder: "VWCE.DE",
								onChange: (event) => setYahoo(event.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "CoinGecko azonosító",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: gecko,
								placeholder: "bitcoin",
								onChange: (event) => setGecko(event.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Kézi ár, ha nincs jegyzés",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "decimal",
							value: manualPrice,
							onChange: (event) => setManualPrice(event.target.value)
						})
					})
				] }) : null,
				source === "cash" || mode === "cash" && !holding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Deviza",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: currency,
						onChange: (event) => setCurrency(event.target.value),
						children: CURRENCIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Csoport vagy számla",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: groupId,
						onChange: (event) => setGroupId(event.target.value),
						children: state.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: group.id,
							children: [
								group.name,
								" · ",
								KIND_LABEL[group.kind]
							]
						}, group.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: resolvedClass === "keszpenz" ? "Összeg" : "Mennyiség",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "decimal",
							value: quantity,
							onChange: (event) => setQuantity(event.target.value)
						})
					}), resolvedClass === "keszpenz" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Bekerülés (${resolvedCurrency})`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "decimal",
							value: avgCost,
							onChange: (event) => setAvgCost(event.target.value)
						})
					})]
				}),
				resolvedCurrency !== "HUF" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Bekerüléskori árfolyam (1 ${resolvedCurrency} hány Ft)`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field tabular-nums",
						inputMode: "decimal",
						placeholder: String(Math.round(fxToHuf(resolvedCurrency, state.market.fx))),
						value: costFx,
						onChange: (event) => setCostFx(event.target.value)
					})
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-clay",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: onClose,
						children: "Mégse"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: save,
						children: "Mentés"
					})]
				})
			]
		})
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Assets, {}) });
}
function Assets() {
	const { state, deleteHolding, saveGroup, deleteGroup } = usePortfolio();
	const [groupFilter, setGroupFilter] = (0, import_react.useState)("mind");
	const [query, setQuery] = (0, import_react.useState)("");
	const [dialog, setDialog] = (0, import_react.useState)({
		open: false,
		holding: null,
		mode: "asset"
	});
	const [groupEditor, setGroupEditor] = (0, import_react.useState)(null);
	const [groupError, setGroupError] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return viewsOf(state, groupFilter === "mind" ? void 0 : groupFilter).filter((row) => {
			if (!needle) return true;
			return `${row.holding.name} ${row.holding.symbol}`.toLowerCase().includes(needle);
		}).sort((a, b) => b.huf - a.huf);
	}, [
		state,
		groupFilter,
		query
	]);
	const totals = sumViews(rows);
	const cashByGroup = state.groups.map((group) => ({
		group,
		rows: state.holdings.filter((holding) => holding.assetClass === "keszpenz" && holding.groupId === group.id).map((holding) => viewHolding(holding, state.market))
	})).filter((block) => block.rows.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl",
				children: "Eszközök"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-xl text-sm text-muted",
				children: "Egy számlán több deviza is állhat. Ugyanaz az ETF külön TBSZ-eken külön sor, külön bekerüléssel."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost",
					onClick: () => setDialog({
						open: true,
						holding: null,
						mode: "cash"
					}),
					children: "Készpénz"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary",
					onClick: () => setDialog({
						open: true,
						holding: null,
						mode: "asset"
					}),
					children: "Új eszköz"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					on: groupFilter === "mind",
					onClick: () => setGroupFilter("mind"),
					children: "Mind"
				}),
				state.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					on: groupFilter === group.id,
					onClick: () => setGroupFilter(group.id),
					children: group.name
				}, group.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-quiet",
					onClick: () => setGroupEditor({
						id: uid(),
						name: "",
						kind: "tbsz"
					}),
					children: "Új csoport"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field max-w-sm",
				placeholder: "Keresés",
				value: query,
				onChange: (event) => setQuery(event.target.value)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm text-muted tabular-nums",
			children: [
				"Szűrt érték ",
				formatMoney(totals.huf, "HUF"),
				" · ",
				formatMoney(totals.usd, "USD")
			]
		}),
		cashByGroup.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl",
				children: "Készpénz devizánként"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-4 md:grid-cols-2",
				children: cashByGroup.map((block) => {
					const sum = sumViews(block.rows);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-medium",
								children: block.group.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted tabular-nums",
								children: formatMoney(sum.huf, "HUF")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2",
							children: block.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-baseline justify-between gap-3 py-1 text-sm tabular-nums",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									formatQty(row.holding.quantity),
									" ",
									row.holding.currency
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: formatMoney(row.usd, "USD")
								})]
							}, row.holding.id))
						})]
					}, block.group.id);
				})
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-8 divide-y divide-line border-t border-line",
			children: [rows.map((row) => {
				const group = state.groups.find((item) => item.id === row.holding.groupId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-3 py-4 md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_auto] md:items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: row.holding.name
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted",
										children: row.holding.symbol
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									group?.name ?? "Csoport nélkül",
									" · ",
									CLASS_LABEL[row.holding.assetClass],
									" · ",
									formatQty(row.holding.quantity),
									" ",
									row.holding.assetClass === "keszpenz" ? row.holding.currency : "db"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tabular-nums md:text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatMoney(row.huf, "HUF") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: formatMoney(row.usd, "USD")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 md:flex-col md:items-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: `text-sm tabular-nums ${pnlClass(row.totalPnlHuf)}`,
								children: [
									"ár ",
									formatMoney(row.pricePnlHuf, "HUF"),
									" · deviza ",
									formatMoney(row.fxPnlHuf, "HUF")
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-quiet",
									onClick: () => setDialog({
										open: true,
										holding: row.holding,
										mode: "asset"
									}),
									children: "Módosít"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-quiet text-clay",
									onClick: () => {
										if (confirm(`Törlöd: ${row.holding.name}?`)) deleteHolding(row.holding.id);
									},
									children: "Töröl"
								})]
							})]
						})
					]
				}, row.holding.id);
			}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "py-10 text-sm text-muted",
				children: "Ebben a szűrésben nincs eszköz."
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Csoportok"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-line",
					children: state.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: group.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: KIND_LABEL[group.kind]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-quiet",
								onClick: () => setGroupEditor(group),
								children: "Átnevez"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-quiet text-clay",
								onClick: () => {
									const message = deleteGroup(group.id);
									if (message) setGroupError(message);
								},
								children: "Töröl"
							})]
						})]
					}, group.id))
				}),
				groupError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-clay",
					children: groupError
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoldingDialog, {
			open: dialog.open,
			holding: dialog.holding,
			mode: dialog.mode,
			onClose: () => setDialog((current) => ({
				...current,
				open: false
			}))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupDialog, {
			group: groupEditor,
			onClose: () => setGroupEditor(null),
			onSave: (group) => {
				saveGroup(group);
				setGroupEditor(null);
				setGroupError("");
			}
		})
	] });
}
function Filter({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `btn ${on ? "btn-primary" : "btn-ghost"}`,
		children
	});
}
function GroupDialog({ group, onClose, onSave }) {
	const [name, setName] = (0, import_react.useState)(group?.name ?? "");
	const [kind, setKind] = (0, import_react.useState)(group?.kind ?? "tbsz");
	(0, import_react.useEffect)(() => {
		setName(group?.name ?? "");
		setKind(group?.kind ?? "egyeb");
	}, [group]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open: Boolean(group),
		title: group && group.name ? "Csoport" : "Új csoport",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Név",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: name,
						onChange: (event) => setName(event.target.value),
						placeholder: "TBSZ 2027"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Típus",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: kind,
						onChange: (event) => setKind(event.target.value),
						children: Object.keys(KIND_LABEL).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: KIND_LABEL[item]
						}, item))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: onClose,
						children: "Mégse"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => group && name.trim() && onSave({
							...group,
							name: name.trim(),
							kind
						}),
						children: "Mentés"
					})]
				})
			]
		})
	});
}
//#endregion
export { Page as component };
