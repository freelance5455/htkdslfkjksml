import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as useHealth } from "./use-books-BtZpLk9U.mjs";
import { i as PageHeader, n as Card, o as StatCard } from "./card-Bb_-PO54.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/health-C0sec37R.js
var import_jsx_runtime = require_jsx_runtime();
function HealthPage() {
	const { data } = useHealth();
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-[24px] bg-secondary" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "سلامت سیستم",
			description: "تراز، همگام‌سازی، پشتیبان و روزهای باز."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "عملیات امروز",
					value: data.opsToday
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "اسناد",
					value: data.journals
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "اسناد نامتوازن",
					value: data.unbalanced,
					hint: data.unbalanced === 0 ? "سالم" : "نیاز به بررسی"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "روزهای باز",
					value: data.openDays
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "روزهای بسته",
					value: data.closedDays
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "رویداد حسابرسی",
					value: data.auditEvents
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "صف همگام‌سازی",
					value: data.syncPending
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "آخرین پشتیبان",
					value: data.lastBackup?.backup_name ?? "—"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "mt-5 text-sm text-muted",
			children: "هسته سیستم زنجیرهٔ عملیات → اعتبارسنجی → موتور حسابداری → سند دوبل → دفتر کل → تراز → گزارش و KPI را در یک تراکنش منطقی اجرا می‌کند."
		})
	] });
}
//#endregion
export { HealthPage as component };
