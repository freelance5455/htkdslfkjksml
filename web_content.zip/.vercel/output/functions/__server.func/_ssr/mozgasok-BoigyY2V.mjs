import { i as __toESM } from "../_runtime.mjs";
import { a as findCatalog, t as CATALOG } from "./catalog-D0BjXlW4.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as usePortfolio, s as fxToHuf } from "./router-Ddmv2GI8.mjs";
import { t as Shell } from "./shell-wztA7KjE.mjs";
import { a as SIDE_LABEL, c as formatDay, f as formatQty, g as uid, h as todayIso, i as Modal, l as formatMoney, n as Field, r as KIND_LABEL, t as CLASS_LABEL } from "./format-Bbm5TEoT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mozgasok-BoigyY2V.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ledger, {}) });
}
function num(value) {
	const parsed = Number(value.replace(/\s/g, "").replace(",", "."));
	return Number.isFinite(parsed) ? parsed : NaN;
}
function Ledger() {
	const { state, saveTx, deleteTx, refresh } = usePortfolio();
	const [open, setOpen] = (0, import_react.useState)(false);
	const rows = [...state.transactions].sort((a, b) => b.date.localeCompare(a.date));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl",
				children: "Mozgások"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-xl text-sm text-muted",
				children: "Vétel és eladás frissíti az állományt. Osztalék és díj csak a naplóba kerül. A törlés nem számolja vissza a készletet."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => setOpen(true),
				children: "Új mozgás"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-8 divide-y divide-line border-t border-line",
			children: [rows.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "grid gap-2 py-4 sm:grid-cols-[7rem_1fr_auto] sm:items-baseline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted tabular-nums",
						children: formatDay(tx.date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						SIDE_LABEL[tx.side],
						" · ",
						tx.name,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: tx.symbol
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							state.groups.find((group) => group.id === tx.groupId)?.name,
							" · ",
							formatQty(tx.quantity),
							" × ",
							formatMoney(tx.price, tx.currency),
							tx.note ? ` · ${tx.note}` : ""
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-quiet justify-start text-clay sm:justify-center",
						onClick: () => deleteTx(tx.id),
						children: "Töröl a naplóból"
					})
				]
			}, tx.id)), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "py-10 text-sm text-muted",
				children: "Még nincs mozgás."
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TxDialog, {
			open,
			onClose: () => setOpen(false),
			onSave: (tx, apply) => {
				saveTx(tx, apply);
				setOpen(false);
				if (apply) refresh();
			}
		})
	] });
}
function TxDialog({ open, onClose, onSave }) {
	const { state } = usePortfolio();
	const [side, setSide] = (0, import_react.useState)("vetel");
	const [source, setSource] = (0, import_react.useState)("VWCE");
	const [symbol, setSymbol] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [assetClass, setAssetClass] = (0, import_react.useState)("etf");
	const [currency, setCurrency] = (0, import_react.useState)("EUR");
	const [groupId, setGroupId] = (0, import_react.useState)(state.groups[0]?.id ?? "");
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [quantity, setQuantity] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [fx, setFx] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [apply, setApply] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setSide("vetel");
		setSource("VWCE");
		setDate(todayIso());
		setQuantity("");
		setPrice("");
		setFx("");
		setNote("");
		setApply(true);
		setError("");
		setGroupId(state.groups[0]?.id ?? "");
	}, [open, state.groups]);
	const known = source === "custom" ? void 0 : findCatalog(source);
	const resolvedClass = known?.assetClass ?? assetClass;
	const resolvedCurrency = known?.currency ?? currency;
	const save = () => {
		const qty = num(quantity);
		const px = num(price);
		const fxInput = num(fx);
		const rate = Number.isFinite(fxInput) && fxInput > 0 ? fxInput : fxToHuf(resolvedCurrency, state.market.fx);
		const sym = (known?.symbol ?? symbol).trim().toUpperCase();
		if (!sym || !groupId) return setError("Szimbólum és csoport kell.");
		if (!Number.isFinite(qty) || qty < 0 || !Number.isFinite(px) || px < 0) return setError("Mennyiség és ár szám legyen.");
		onSave({
			id: uid(),
			date,
			side,
			symbol: sym,
			name: name || known?.name || sym,
			assetClass: resolvedClass,
			currency: resolvedCurrency,
			groupId,
			quantity: qty,
			price: px,
			fxToHuf: resolvedCurrency === "HUF" ? 1 : rate,
			note: note.trim()
		}, apply && (side === "vetel" || side === "eladas"));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		title: "Mozgás",
		onClose,
		description: "A vétel súlyozza a bekerülési árat és a régi devizaárfolyamot.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Típus",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: side,
							onChange: (event) => setSide(event.target.value),
							children: Object.keys(SIDE_LABEL).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: SIDE_LABEL[item]
							}, item))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Dátum",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "date",
							value: date,
							onChange: (event) => setDate(event.target.value)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Eszköz",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: source,
						onChange: (event) => setSource(event.target.value),
						children: [CATALOG.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item.symbol,
							children: [
								item.symbol,
								" · ",
								item.name
							]
						}, item.symbol)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "custom",
							children: "Saját"
						})]
					})
				}),
				source === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Szimbólum",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: symbol,
								onChange: (event) => setSymbol(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Név",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: name,
								onChange: (event) => setName(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Osztály",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field",
								value: assetClass,
								onChange: (event) => setAssetClass(event.target.value),
								children: Object.keys(CLASS_LABEL).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: CLASS_LABEL[item]
								}, item))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Deviza",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field",
								value: currency,
								onChange: (event) => setCurrency(event.target.value),
								children: [
									"HUF",
									"EUR",
									"USD",
									"GBP"
								].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
							})
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Csoport",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: groupId,
						onChange: (event) => setGroupId(event.target.value),
						children: state.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: group.id,
							children: [
								group.name,
								" · ",
								KIND_LABEL[group.kind]
							]
						}, group.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Mennyiség",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "decimal",
							value: quantity,
							onChange: (event) => setQuantity(event.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Ár (${resolvedCurrency})`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "decimal",
							value: price,
							onChange: (event) => setPrice(event.target.value)
						})
					})]
				}),
				resolvedCurrency !== "HUF" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Forintárfolyam aznap",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field tabular-nums",
						inputMode: "decimal",
						value: fx,
						placeholder: String(Math.round(fxToHuf(resolvedCurrency, state.market.fx))),
						onChange: (event) => setFx(event.target.value)
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Megjegyzés",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: note,
						onChange: (event) => setNote(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "size-5 accent-pine",
						checked: apply,
						onChange: (event) => setApply(event.target.checked)
					}), "Alkalmazd az állományra, ha vétel vagy eladás"]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-clay",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: onClose,
						children: "Mégse"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: save,
						children: "Rögzít"
					})]
				})
			]
		})
	});
}
//#endregion
export { Page as component };
