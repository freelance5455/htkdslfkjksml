import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as RotateCcw, c as Headphones, i as Speaker, l as Bluetooth, n as Upload, o as Play, s as Pause, t as Volume2 } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ce2Fr84U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BANDS = [
	{
		freq: 31,
		label: "31"
	},
	{
		freq: 62,
		label: "62"
	},
	{
		freq: 125,
		label: "125"
	},
	{
		freq: 250,
		label: "250"
	},
	{
		freq: 500,
		label: "500"
	},
	{
		freq: 1e3,
		label: "1k"
	},
	{
		freq: 2e3,
		label: "2k"
	},
	{
		freq: 4e3,
		label: "4k"
	},
	{
		freq: 8e3,
		label: "8k"
	},
	{
		freq: 16e3,
		label: "16k"
	}
];
var BAND_COUNT = BANDS.length;
var BAND_Q = 1.414;
var TREBLE_FREQ = 4e3;
var SAMPLE_RATE = 48e3;
var OUTPUT_MODES = [
	{
		id: "wired",
		label: "Wired",
		hint: "Headphones or a USB DAC"
	},
	{
		id: "bluetooth",
		label: "Bluetooth",
		hint: "AirPods, buds, or a BT speaker"
	},
	{
		id: "speaker",
		label: "Speaker",
		hint: "Phone or laptop speakers — EQ off"
	}
];
function emptyGains() {
	return Array.from({ length: BAND_COUNT }, () => 0);
}
function clampGain(value) {
	return Math.min(12, Math.max(-12, value));
}
function formatDb(value) {
	if (Math.abs(value) < .05) return "0.0";
	return `${value > 0 ? "+" : ""}${value.toFixed(1)}`;
}
var EqEngine = class {
	ctx;
	audio;
	analyser;
	source;
	preamp;
	bass;
	treble;
	bands;
	compressor;
	master;
	eqInput;
	dry;
	wet;
	spectrum = /* @__PURE__ */ new Uint8Array(1024);
	constructor() {
		this.ctx = new AudioContext();
		this.audio = new Audio();
		this.audio.crossOrigin = "anonymous";
		this.audio.loop = true;
		this.audio.preload = "auto";
		this.source = this.ctx.createMediaElementSource(this.audio);
		this.preamp = this.ctx.createGain();
		this.eqInput = this.ctx.createGain();
		this.bass = this.ctx.createBiquadFilter();
		this.bass.type = "lowshelf";
		this.bass.frequency.value = 250;
		this.bands = BANDS.map((band) => {
			const filter = this.ctx.createBiquadFilter();
			filter.type = "peaking";
			filter.frequency.value = band.freq;
			filter.Q.value = BAND_Q;
			filter.gain.value = 0;
			return filter;
		});
		this.treble = this.ctx.createBiquadFilter();
		this.treble.type = "highshelf";
		this.treble.frequency.value = TREBLE_FREQ;
		this.compressor = this.ctx.createDynamicsCompressor();
		this.compressor.threshold.value = -6;
		this.compressor.knee.value = 12;
		this.compressor.ratio.value = 2.5;
		this.compressor.attack.value = .01;
		this.compressor.release.value = .18;
		this.analyser = this.ctx.createAnalyser();
		this.analyser.fftSize = 2048;
		this.analyser.smoothingTimeConstant = .82;
		this.spectrum = new Uint8Array(this.analyser.frequencyBinCount);
		this.master = this.ctx.createGain();
		this.dry = this.ctx.createGain();
		this.wet = this.ctx.createGain();
		this.dry.gain.value = 0;
		this.wet.gain.value = 1;
		this.source.connect(this.preamp);
		this.preamp.connect(this.eqInput);
		let node = this.eqInput;
		node.connect(this.bass);
		node = this.bass;
		for (const band of this.bands) {
			node.connect(band);
			node = band;
		}
		node.connect(this.treble);
		this.treble.connect(this.compressor);
		this.compressor.connect(this.wet);
		this.preamp.connect(this.dry);
		this.wet.connect(this.analyser);
		this.dry.connect(this.analyser);
		this.analyser.connect(this.master);
		this.master.connect(this.ctx.destination);
	}
	async resume() {
		if (this.ctx.state === "suspended") await this.ctx.resume();
	}
	setEnabled(enabled) {
		const now = this.ctx.currentTime;
		this.wet.gain.setTargetAtTime(enabled ? 1 : 0, now, .04);
		this.dry.gain.setTargetAtTime(enabled ? 0 : 1, now, .04);
	}
	setGains(gains) {
		this.bands.forEach((band, i) => {
			band.gain.setTargetAtTime(gains[i] ?? 0, this.ctx.currentTime, .03);
		});
	}
	setBass(db) {
		this.bass.gain.setTargetAtTime(db, this.ctx.currentTime, .03);
	}
	setTreble(db) {
		this.treble.gain.setTargetAtTime(db, this.ctx.currentTime, .03);
	}
	setPreamp(db) {
		const linear = 10 ** (db / 20);
		this.preamp.gain.setTargetAtTime(linear, this.ctx.currentTime, .03);
	}
	setVolume(value) {
		this.master.gain.setTargetAtTime(value, this.ctx.currentTime, .02);
	}
	async setSink(deviceId) {
		const ctx = this.ctx;
		const sink = deviceId ?? "";
		try {
			if (typeof ctx.setSinkId === "function") {
				await ctx.setSinkId(sink);
				return;
			}
			const media = this.audio;
			if (typeof media.setSinkId === "function") await media.setSinkId(sink);
		} catch {}
	}
	getSpectrum() {
		this.analyser.getByteFrequencyData(this.spectrum);
		return this.spectrum;
	}
	nyquist() {
		return this.ctx.sampleRate / 2;
	}
};
var instance = null;
function getEngine() {
	if (typeof window === "undefined") return null;
	if (!instance) instance = new EqEngine();
	return instance;
}
var LOG_MIN = Math.log10(20);
var LOG_MAX = Math.log10(2e4);
function logspace(count) {
	const freqs = new Float32Array(count);
	for (let i = 0; i < count; i++) {
		const t = i / Math.max(1, count - 1);
		freqs[i] = 10 ** (LOG_MIN + t * (LOG_MAX - LOG_MIN));
	}
	return freqs;
}
function freqToX(freq, width) {
	return (Math.log10(Math.max(20, freq)) - LOG_MIN) / (LOG_MAX - LOG_MIN) * width;
}
function peaking(f0, gainDb, q, fs) {
	const A = 10 ** (gainDb / 40);
	const w0 = 2 * Math.PI * f0 / fs;
	const cos = Math.cos(w0);
	const alpha = Math.sin(w0) / (2 * q);
	const b0 = 1 + alpha * A;
	const b1 = -2 * cos;
	const b2 = 1 - alpha * A;
	const a0 = 1 + alpha / A;
	const a1 = -2 * cos;
	const a2 = 1 - alpha / A;
	return {
		b0: b0 / a0,
		b1: b1 / a0,
		b2: b2 / a0,
		a1: a1 / a0,
		a2: a2 / a0
	};
}
function lowshelf(f0, gainDb, fs) {
	const A = 10 ** (gainDb / 40);
	const w0 = 2 * Math.PI * f0 / fs;
	const cos = Math.cos(w0);
	const alpha = Math.sin(w0) / 2 * Math.sqrt((A + 1 / A) * 0 + 2);
	const twoSqrtA = 2 * Math.sqrt(A) * alpha;
	const b0 = A * (A + 1 - (A - 1) * cos + twoSqrtA);
	const b1 = 2 * A * (A - 1 - (A + 1) * cos);
	const b2 = A * (A + 1 - (A - 1) * cos - twoSqrtA);
	const a0 = A + 1 + (A - 1) * cos + twoSqrtA;
	const a1 = -2 * (A - 1 + (A + 1) * cos);
	const a2 = A + 1 + (A - 1) * cos - twoSqrtA;
	return {
		b0: b0 / a0,
		b1: b1 / a0,
		b2: b2 / a0,
		a1: a1 / a0,
		a2: a2 / a0
	};
}
function highshelf(f0, gainDb, fs) {
	const A = 10 ** (gainDb / 40);
	const w0 = 2 * Math.PI * f0 / fs;
	const cos = Math.cos(w0);
	const alpha = Math.sin(w0) / 2 * Math.sqrt((A + 1 / A) * 0 + 2);
	const twoSqrtA = 2 * Math.sqrt(A) * alpha;
	const b0 = A * (A + 1 + (A - 1) * cos + twoSqrtA);
	const b1 = -2 * A * (A - 1 + (A + 1) * cos);
	const b2 = A * (A + 1 + (A - 1) * cos - twoSqrtA);
	const a0 = A + 1 - (A - 1) * cos + twoSqrtA;
	const a1 = 2 * (A - 1 - (A + 1) * cos);
	const a2 = A + 1 - (A - 1) * cos - twoSqrtA;
	return {
		b0: b0 / a0,
		b1: b1 / a0,
		b2: b2 / a0,
		a1: a1 / a0,
		a2: a2 / a0
	};
}
function magDb(f, c, fs) {
	const w = 2 * Math.PI * f / fs;
	const cos = Math.cos(w);
	const sin = Math.sin(w);
	const cos2 = 2 * cos * cos - 1;
	const sin2 = 2 * sin * cos;
	const numRe = c.b0 + c.b1 * cos + c.b2 * cos2;
	const numIm = -(c.b1 * sin + c.b2 * sin2);
	const denRe = 1 + c.a1 * cos + c.a2 * cos2;
	const denIm = -(c.a1 * sin + c.a2 * sin2);
	const num = numRe * numRe + numIm * numIm;
	const den = denRe * denRe + denIm * denIm;
	return 10 * Math.log10(Math.max(1e-12, num / Math.max(1e-12, den)));
}
function computeResponseDb(gains, bass, treble, frequencies, fs = SAMPLE_RATE) {
	const filters = [
		lowshelf(250, bass, fs),
		...BANDS.map((band, i) => peaking(band.freq, gains[i] ?? 0, BAND_Q, fs)),
		highshelf(TREBLE_FREQ, treble, fs)
	];
	const out = new Float32Array(frequencies.length);
	for (let i = 0; i < frequencies.length; i++) {
		const f = frequencies[i] ?? 20;
		let db = 0;
		for (const filter of filters) db += magDb(f, filter, fs);
		out[i] = db;
	}
	return out;
}
var FREQS = logspace(280);
function EqCanvas({ gains, bass, treble, locked, playing }) {
	const canvasRef = (0, import_react.useRef)(null);
	const responseRef = (0, import_react.useRef)(computeResponseDb(gains, bass, treble, FREQS));
	const gainsRef = (0, import_react.useRef)(gains);
	const lockedRef = (0, import_react.useRef)(locked);
	const playingRef = (0, import_react.useRef)(playing);
	const smoothSpec = (0, import_react.useRef)(new Float32Array(FREQS.length));
	gainsRef.current = gains;
	lockedRef.current = locked;
	playingRef.current = playing;
	(0, import_react.useEffect)(() => {
		responseRef.current = computeResponseDb(gains, bass, treble, FREQS);
	}, [
		gains,
		bass,
		treble
	]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let frame = 0;
		let running = true;
		const draw = () => {
			if (!running) return;
			const parent = canvas.parentElement;
			const width = parent?.clientWidth ?? 640;
			const height = parent?.clientHeight ?? 280;
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
				canvas.width = Math.floor(width * dpr);
				canvas.height = Math.floor(height * dpr);
				canvas.style.width = `${width}px`;
				canvas.style.height = `${height}px`;
			}
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.clearRect(0, 0, width, height);
			const padX = 28;
			const padY = 18;
			const plotW = width - 56;
			const plotH = height - 36;
			const currentGains = gainsRef.current;
			const isLocked = lockedRef.current;
			const yForDb = (db) => {
				const t = (12 - db) / 24;
				return padY + t * plotH;
			};
			ctx.strokeStyle = "rgba(244,244,245,0.06)";
			ctx.lineWidth = 1;
			for (const db of [
				-12,
				-6,
				0,
				6,
				12
			]) {
				const y = yForDb(db);
				ctx.beginPath();
				ctx.setLineDash(db === 0 ? [] : [3, 5]);
				ctx.moveTo(padX, y);
				ctx.lineTo(padX + plotW, y);
				ctx.stroke();
			}
			ctx.setLineDash([]);
			const engine = getEngine();
			const spec = smoothSpec.current;
			if (engine && playingRef.current) {
				const bins = engine.getSpectrum();
				const nyquist = engine.nyquist();
				for (let i = 0; i < FREQS.length; i++) {
					const f = FREQS[i] ?? 20;
					const bin = Math.min(bins.length - 1, f / nyquist * bins.length);
					const i0 = Math.floor(bin);
					const i1 = Math.min(bins.length - 1, i0 + 1);
					const frac = bin - i0;
					const v = ((bins[i0] ?? 0) * (1 - frac) + (bins[i1] ?? 0) * frac) / 255;
					spec[i] = (spec[i] ?? 0) * .72 + v * .28;
				}
				ctx.beginPath();
				for (let i = 0; i < FREQS.length; i++) {
					const x = padX + freqToX(FREQS[i] ?? 20, plotW);
					const mag = spec[i] ?? 0;
					const y = padY + plotH - mag * plotH * .92;
					if (i === 0) ctx.moveTo(x, padY + plotH);
					ctx.lineTo(x, y);
				}
				ctx.lineTo(padX + plotW, padY + plotH);
				ctx.closePath();
				const fill = ctx.createLinearGradient(0, padY, 0, padY + plotH);
				fill.addColorStop(0, "rgba(200,204,212,0.22)");
				fill.addColorStop(1, "rgba(200,204,212,0.02)");
				ctx.fillStyle = fill;
				ctx.fill();
			}
			const response = responseRef.current;
			ctx.beginPath();
			for (let i = 0; i < FREQS.length; i++) {
				const x = padX + freqToX(FREQS[i] ?? 20, plotW);
				const y = yForDb(response[i] ?? 0);
				if (i === 0) ctx.moveTo(x, y);
				else ctx.lineTo(x, y);
			}
			ctx.strokeStyle = isLocked ? "rgba(200,204,212,0.28)" : "rgba(232,233,237,0.92)";
			ctx.lineWidth = 1.8;
			ctx.lineJoin = "round";
			ctx.stroke();
			ctx.fillStyle = isLocked ? "rgba(200,204,212,0.35)" : "rgba(232,233,237,0.95)";
			for (let i = 0; i < BANDS.length; i++) {
				const band = BANDS[i];
				const x = padX + freqToX(band.freq, plotW);
				const y = yForDb(currentGains[i] ?? 0);
				ctx.beginPath();
				ctx.arc(x, y, 3.2, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.fillStyle = "rgba(161,161,170,0.7)";
			ctx.font = "500 10px 'IBM Plex Mono', ui-monospace, monospace";
			ctx.textAlign = "left";
			ctx.fillText("+12", 6, yForDb(12) + 3);
			ctx.fillText("0", 10, yForDb(0) + 3);
			ctx.fillText("-12", 6, yForDb(-12) + 3);
			frame = requestAnimationFrame(draw);
		};
		frame = requestAnimationFrame(draw);
		return () => {
			running = false;
			cancelAnimationFrame(frame);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: "pointer-events-none absolute inset-0 size-full",
		"aria-hidden": "true"
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function EqFaders({ gains, onChange, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative z-10 grid h-full grid-cols-10 gap-1 px-7 pb-1 pt-4 sm:gap-2 sm:px-8",
		children: BANDS.map((band, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
			label: band.label,
			value: gains[index] ?? 0,
			disabled,
			onChange: (value) => onChange(index, value)
		}, band.freq))
	});
}
function Fader({ label, value, onChange, disabled }) {
	const trackRef = (0, import_react.useRef)(null);
	const dragging = (0, import_react.useRef)(false);
	const valueFromY = (0, import_react.useCallback)((clientY) => {
		const track = trackRef.current;
		if (!track) return value;
		const rect = track.getBoundingClientRect();
		const db = 12 - (clientY - rect.top) / rect.height * 24;
		return Math.min(12, Math.max(-12, db));
	}, [value]);
	const t = (12 - value) / 24;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-w-0 flex-col items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: trackRef,
			role: "slider",
			"aria-label": `${label} Hz`,
			"aria-valuemin": -12,
			"aria-valuemax": 12,
			"aria-valuenow": Number(value.toFixed(1)),
			"aria-valuetext": `${formatDb(value)} dB`,
			"aria-disabled": disabled,
			tabIndex: disabled ? -1 : 0,
			className: cn("relative flex min-h-44 w-full flex-1 cursor-ns-resize touch-none items-stretch justify-center outline-none focus-visible:ring-2 focus-visible:ring-ring/70", disabled && "cursor-not-allowed opacity-50"),
			onPointerDown: (event) => {
				if (disabled) return;
				dragging.current = true;
				event.currentTarget.setPointerCapture(event.pointerId);
				onChange(valueFromY(event.clientY));
			},
			onPointerMove: (event) => {
				if (!dragging.current) return;
				onChange(valueFromY(event.clientY));
			},
			onPointerUp: () => {
				dragging.current = false;
			},
			onDoubleClick: () => !disabled && onChange(0),
			onKeyDown: (event) => {
				if (disabled) return;
				if (event.key === "ArrowUp") {
					event.preventDefault();
					onChange(Math.min(12, value + .5));
				}
				if (event.key === "ArrowDown") {
					event.preventDefault();
					onChange(Math.max(-12, value - .5));
				}
				if (event.key === "Home") onChange(0);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative h-full w-1 rounded-full bg-elevated",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-1/2 h-0.5 w-3 -translate-x-1/2 bg-border-strong",
					style: { top: "50%" }
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute left-1/2 h-4 w-7 -translate-x-1/2 -translate-y-1/2 rounded-sm bg-primary shadow-[var(--shadow-border)]",
				style: { top: `${t * 100}%` }
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-3 font-mono text-xs tabular-nums text-subtle",
			children: label
		})]
	});
}
var START = -135;
var SWEEP = 270;
function Knob({ label, value, onChange, disabled }) {
	const id = (0, import_react.useId)();
	const drag = (0, import_react.useRef)(null);
	const angle = START + (value - -12) / 24 * SWEEP;
	const pointerDown = (0, import_react.useCallback)((event) => {
		if (disabled) return;
		event.currentTarget.setPointerCapture(event.pointerId);
		drag.current = {
			y: event.clientY,
			value
		};
	}, [disabled, value]);
	const pointerMove = (0, import_react.useCallback)((event) => {
		if (!drag.current) return;
		const delta = drag.current.y - event.clientY;
		const next = drag.current.value + delta * .08;
		onChange(Math.min(12, Math.max(-12, next)));
	}, [onChange]);
	const pointerUp = (0, import_react.useCallback)(() => {
		drag.current = null;
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-col items-center gap-3", disabled && "opacity-40"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			role: "slider",
			id,
			"aria-label": label,
			"aria-valuemin": -12,
			"aria-valuemax": 12,
			"aria-valuenow": Number(value.toFixed(1)),
			"aria-valuetext": `${formatDb(value)} dB`,
			"aria-disabled": disabled,
			tabIndex: disabled ? -1 : 0,
			className: "relative size-28 touch-none rounded-full outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg",
			onPointerDown: pointerDown,
			onPointerMove: pointerMove,
			onPointerUp: pointerUp,
			onPointerCancel: pointerUp,
			onDoubleClick: () => !disabled && onChange(0),
			onKeyDown: (event) => {
				if (disabled) return;
				if (event.key === "ArrowUp" || event.key === "ArrowRight") {
					event.preventDefault();
					onChange(Math.min(12, value + .5));
				}
				if (event.key === "ArrowDown" || event.key === "ArrowLeft") {
					event.preventDefault();
					onChange(Math.max(-12, value - .5));
				}
				if (event.key === "Home") onChange(0);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 120 120",
				className: "size-full",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: "52",
						fill: "var(--color-elevated)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: "52",
						fill: "none",
						stroke: "color-mix(in oklab, var(--color-fg) 10%, transparent)",
						strokeWidth: "1"
					}),
					Array.from({ length: 19 }, (_, i) => {
						const a = (START + i / 18 * SWEEP) * Math.PI / 180;
						const inner = i % 3 === 0 ? 40 : 44;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: 60 + Math.cos(a) * inner,
							y1: 60 + Math.sin(a) * inner,
							x2: 60 + Math.cos(a) * 48,
							y2: 60 + Math.sin(a) * 48,
							stroke: "color-mix(in oklab, var(--color-fg) 28%, transparent)",
							strokeWidth: i % 3 === 0 ? 1.4 : 1
						}, i);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: "34",
						fill: "var(--color-surface)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: "34",
						fill: "none",
						stroke: "color-mix(in oklab, var(--color-fg) 12%, transparent)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "60",
						y1: "60",
						x2: 60 + Math.cos(angle * Math.PI / 180) * 26,
						y2: 60 + Math.sin(angle * Math.PI / 180) * 26,
						stroke: "var(--color-accent)",
						strokeWidth: "2.5",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: "4",
						fill: "var(--color-accent)"
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-widest text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 font-mono text-sm tabular-nums text-fg",
				children: [formatDb(value), " dB"]
			})]
		})]
	});
}
function LockOverlay({ visible, onChooseWired, onChooseBluetooth }) {
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-3 z-20 flex items-center justify-center rounded-xl bg-bg/80 p-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex size-12 items-center justify-center rounded-full bg-elevated shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, {
						className: "size-5 text-accent",
						strokeWidth: 1.75
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-lg font-medium tracking-tight text-fg",
					children: "Speakers are locked"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "SIGNAL only equalizes wired headphones or Bluetooth devices. Phone and laptop speakers stay flat."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-2 sm:flex-row sm:justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onChooseWired,
						className: "h-11 rounded-md bg-primary px-4 text-sm font-medium text-primary-fg transition-transform duration-150 ease-out hover:opacity-90 active:scale-[0.96]",
						children: "Using wired headphones"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onChooseBluetooth,
						className: "h-11 rounded-md bg-elevated px-4 text-sm font-medium text-fg shadow-[var(--shadow-border)] transition-transform duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]",
						children: "Using Bluetooth"
					})]
				})
			]
		})
	});
}
var ICONS = {
	wired: Headphones,
	bluetooth: Bluetooth,
	speaker: Speaker
};
function OutputModeSwitch({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-3 rounded-full bg-elevated p-1 shadow-[var(--shadow-border)]",
		role: "tablist",
		"aria-label": "Output device",
		children: OUTPUT_MODES.map((mode) => {
			const Icon = ICONS[mode.id];
			const active = mode.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				role: "tab",
				"aria-selected": active,
				title: mode.hint,
				onClick: () => onChange(mode.id),
				className: cn("flex h-10 items-center justify-center gap-2 rounded-full px-2 text-xs font-medium transition-[background-color,color] duration-150 ease-out", active ? "bg-surface text-fg shadow-[var(--shadow-border)]" : "text-muted hover:text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-3.5",
					strokeWidth: 1.75
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: mode.label
				})]
			}, mode.id);
		})
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-elevated text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted hover:bg-elevated hover:text-fg",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-elevated"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-elevated",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-primary shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none" })]
}));
Slider.displayName = Slider$1.displayName;
function Player({ isPlaying, sourceKind, fileName, currentTime, duration, volume, preamp, onPlayPause, onDemo, onFile, onSeek, onVolume, onPreamp }) {
	const inputRef = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "icon",
						onClick: onPlayPause,
						"aria-label": isPlaying ? "Pause" : "Play",
						className: "shrink-0",
						children: isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 translate-x-px" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium text-fg",
							children: sourceKind === "file" ? fileName ?? "Loaded track" : sourceKind === "demo" ? "Demo mix" : "No track loaded"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs tabular-nums text-subtle",
							children: [
								formatTime(currentTime),
								" / ",
								formatTime(duration)
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						size: "sm",
						onClick: onDemo,
						children: "Demo mix"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon",
						"aria-label": "Load audio file",
						onClick: () => inputRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						type: "file",
						accept: "audio/*,.mp3,.wav,.flac,.ogg,.m4a,.aac",
						className: "sr-only",
						onChange: (event) => {
							const file = event.target.files?.[0];
							if (file) onFile(file);
							event.currentTarget.value = "";
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: Math.max(duration, .01),
					step: .01,
					value: [Math.min(currentTime, duration)],
					onValueChange: ([time]) => onSeek(time ?? 0),
					"aria-label": "Seek"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4 shrink-0 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 0,
						max: 1,
						step: .01,
						value: [volume],
						onValueChange: ([v]) => onVolume(v ?? 0),
						"aria-label": "Volume"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-14 shrink-0 text-xs font-medium uppercase tracking-widest text-muted",
							children: "Preamp"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: -12,
							max: 12,
							step: .1,
							value: [preamp],
							onValueChange: ([v]) => onPreamp(v ?? 0),
							"aria-label": "Preamp"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-12 text-right font-mono text-xs tabular-nums text-subtle",
							children: formatDb(preamp)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-3 text-xs text-subtle", sourceKind === "none" && "text-muted"),
				children: "Drop an audio file anywhere on this panel, or start the demo mix to hear the curve."
			})
		]
	});
}
function formatTime(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
	return `${Math.floor(seconds / 60)}:${Math.floor(seconds % 60).toString().padStart(2, "0")}`;
}
function g(values, bass, treble, preamp = 0) {
	if (values.length !== BAND_COUNT) throw new Error("preset must have 10 bands");
	return {
		gains: values,
		bass,
		treble,
		preamp
	};
}
var PRESETS = [
	{
		id: "flat",
		name: "Flat",
		...g(emptyGains(), 0, 0)
	},
	{
		id: "bass",
		name: "Bass",
		...g([
			8,
			7,
			5,
			2,
			0,
			-1,
			-1,
			0,
			1,
			2
		], 6, 0, -3)
	},
	{
		id: "treble",
		name: "Treble",
		...g([
			-1,
			-1,
			0,
			0,
			1,
			2,
			3,
			5,
			6,
			7
		], 0, 5, -2)
	},
	{
		id: "vshape",
		name: "V-Shape",
		...g([
			6,
			5,
			3,
			0,
			-2,
			-2,
			0,
			3,
			5,
			6
		], 4, 4, -3)
	},
	{
		id: "vocal",
		name: "Vocal",
		...g([
			-2,
			-2,
			-1,
			1,
			3,
			5,
			4,
			2,
			0,
			-1
		], -1, 1, -1)
	},
	{
		id: "acoustic",
		name: "Acoustic",
		...g([
			3,
			2,
			1,
			0,
			1,
			2,
			3,
			3,
			2,
			1
		], 1, 2, -1)
	},
	{
		id: "electronic",
		name: "Electronic",
		...g([
			5,
			4,
			2,
			0,
			-1,
			1,
			2,
			3,
			4,
			5
		], 4, 3, -3)
	},
	{
		id: "night",
		name: "Night",
		...g([
			2,
			1,
			0,
			0,
			-1,
			-2,
			-3,
			-4,
			-6,
			-7
		], 1, -5, 1)
	}
];
function matchPreset(gains, bass, treble) {
	return PRESETS.find((preset) => {
		if (preset.bass !== bass || preset.treble !== treble) return false;
		return preset.gains.every((value, i) => Math.abs(value - (gains[i] ?? 0)) < .15);
	})?.id ?? "custom";
}
function PresetsRow({ activeId, onSelect, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "-mx-1 flex gap-2 overflow-x-auto px-1 pb-1",
		children: PRESETS.map((preset) => {
			const active = preset.id === activeId;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled,
				onClick: () => onSelect(preset.id),
				className: cn("h-10 shrink-0 rounded-full px-4 text-sm font-medium transition-[background-color,color,box-shadow,opacity] duration-150 ease-out", active ? "bg-primary text-primary-fg" : "bg-elevated text-muted shadow-[var(--shadow-border)] hover:text-fg", disabled && "opacity-40"),
				children: preset.name
			}, preset.id);
		})
	});
}
function encodeWav(buffer) {
	const channels = buffer.numberOfChannels;
	const sampleRate = buffer.sampleRate;
	const length = buffer.length;
	const blockAlign = channels * 2;
	const dataSize = length * blockAlign;
	const out = new ArrayBuffer(44 + dataSize);
	const view = new DataView(out);
	writeString(view, 0, "RIFF");
	view.setUint32(4, 36 + dataSize, true);
	writeString(view, 8, "WAVE");
	writeString(view, 12, "fmt ");
	view.setUint32(16, 16, true);
	view.setUint16(20, 1, true);
	view.setUint16(22, channels, true);
	view.setUint32(24, sampleRate, true);
	view.setUint32(28, sampleRate * blockAlign, true);
	view.setUint16(32, blockAlign, true);
	view.setUint16(34, 16, true);
	writeString(view, 36, "data");
	view.setUint32(40, dataSize, true);
	const channelData = [];
	for (let c = 0; c < channels; c++) channelData.push(buffer.getChannelData(c));
	let offset = 44;
	for (let i = 0; i < length; i++) for (let c = 0; c < channels; c++) {
		const sample = Math.max(-1, Math.min(1, channelData[c]?.[i] ?? 0));
		view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true);
		offset += 2;
	}
	return new Blob([out], { type: "audio/wav" });
}
function writeString(view, offset, value) {
	for (let i = 0; i < value.length; i++) view.setUint8(offset + i, value.charCodeAt(i));
}
var BPM = 96;
var BARS = 4;
var BEATS_PER_BAR = 4;
var cachedUrl = null;
function demoDuration() {
	return 60 / BPM * BEATS_PER_BAR * BARS;
}
function getDemoUrl() {
	if (cachedUrl) return cachedUrl;
	const sampleRate = 44100;
	const duration = demoDuration();
	const frames = Math.floor(duration * sampleRate);
	const buffer = new OfflineAudioContext(2, frames, sampleRate).createBuffer(2, frames, sampleRate);
	renderDemo(buffer);
	const blob = encodeWav(buffer);
	cachedUrl = URL.createObjectURL(blob);
	return cachedUrl;
}
function renderDemo(buffer) {
	const sr = buffer.sampleRate;
	const left = buffer.getChannelData(0);
	const right = buffer.getChannelData(1);
	const beat = 60 / BPM;
	const frames = left.length;
	const kick = makeKick(sr);
	const snare = makeSnare(sr);
	const hat = makeHat(sr);
	for (let beatIndex = 0; beatIndex < 32; beatIndex++) {
		const t = beatIndex * beat / 2;
		const at = Math.floor(t * sr);
		add(left, right, hat, at, .22, beatIndex % 2 === 0 ? .1 : -.18);
		if (beatIndex % 2 === 0) add(left, right, kick, at, .9, 0);
		if (beatIndex % 4 === 2) add(left, right, snare, at, .55, .05);
	}
	const roots = [
		110,
		87.31,
		130.81,
		98
	];
	for (let bar = 0; bar < BARS; bar++) {
		const start = Math.floor(bar * BEATS_PER_BAR * beat * sr);
		const end = Math.min(frames, Math.floor((bar + 1) * BEATS_PER_BAR * beat * sr));
		const root = roots[bar] ?? 110;
		renderBass(left, right, start, end, sr, root);
		renderPad(left, right, start, end, sr, root);
		renderSparkle(left, right, start, end, sr, root * 4);
	}
	for (let i = 0; i < frames; i++) {
		left[i] = Math.tanh((left[i] ?? 0) * 1.15) * .72;
		right[i] = Math.tanh((right[i] ?? 0) * 1.15) * .72;
	}
}
function add(left, right, sample, at, gain, pan) {
	const lg = gain * (1 - Math.max(0, pan));
	const rg = gain * (1 + Math.min(0, pan));
	for (let i = 0; i < sample.length; i++) {
		const idx = at + i;
		if (idx >= left.length) break;
		const v = sample[i] ?? 0;
		left[idx] = (left[idx] ?? 0) + v * lg;
		right[idx] = (right[idx] ?? 0) + v * rg;
	}
}
function makeKick(sr) {
	const n = Math.floor(sr * .45);
	const out = new Float32Array(n);
	for (let i = 0; i < n; i++) {
		const t = i / sr;
		const env = Math.exp(-t * 7.5);
		const click = Math.exp(-t * 80) * Math.sin(2 * Math.PI * 1800 * t) * .12;
		const freq = 48 + 90 * Math.exp(-t * 18);
		out[i] = Math.sin(2 * Math.PI * freq * t) * env + click;
	}
	return out;
}
function makeSnare(sr) {
	const n = Math.floor(sr * .28);
	const out = new Float32Array(n);
	let noise = 0;
	for (let i = 0; i < n; i++) {
		const t = i / sr;
		noise = noise * .6 + (Math.random() * 2 - 1) * .4;
		const env = Math.exp(-t * 14);
		const body = Math.sin(2 * Math.PI * 190 * t) * Math.exp(-t * 10);
		out[i] = noise * env * .7 + body * .35;
	}
	return out;
}
function makeHat(sr) {
	const n = Math.floor(sr * .08);
	const out = new Float32Array(n);
	let hp = 0;
	for (let i = 0; i < n; i++) {
		const t = i / sr;
		hp = Math.random() * 2 - 1 - hp * .85;
		out[i] = hp * Math.exp(-t * 55);
	}
	return out;
}
function renderBass(left, right, start, end, sr, freq) {
	for (let i = start; i < end; i++) {
		const t = (i - start) / sr;
		const local = t % .3125;
		const env = local < .02 ? local / .02 : Math.exp(-(local - .02) * 4.2);
		const phase = 2 * Math.PI * freq * t;
		const v = (Math.sin(phase) + Math.sin(phase * 2) * .22) * env * .38;
		left[i] = (left[i] ?? 0) + v;
		right[i] = (right[i] ?? 0) + v * .96;
	}
}
function renderPad(left, right, start, end, sr, root) {
	const third = root * (5 / 4);
	const fifth = root * 1.5;
	const len = end - start;
	for (let i = start; i < end; i++) {
		const t = (i - start) / sr;
		const fade = fadeEdges((i - start) / len, .12);
		const a = Math.sin(2 * Math.PI * root * 2 * t + .2);
		const b = Math.sin(2 * Math.PI * third * 2 * t);
		const c = Math.sin(2 * Math.PI * fifth * 2 * t + .4);
		const v = (a + b + c) * .07 * fade;
		left[i] = (left[i] ?? 0) + v;
		right[i] = (right[i] ?? 0) + v * .92 + Math.sin(2 * Math.PI * fifth * 2.003 * t) * .03 * fade;
	}
}
function renderSparkle(left, right, start, end, sr, freq) {
	const step = Math.floor(sr * .15625);
	for (let at = start; at < end; at += step) {
		const f = freq * (Math.floor((at - start) / step) % 2 === 0 ? 1 : 1.25);
		for (let i = 0; i < Math.floor(sr * .12); i++) {
			const idx = at + i;
			if (idx >= end) break;
			const t = i / sr;
			const env = Math.exp(-t * 18);
			const v = Math.sin(2 * Math.PI * f * t) * env * .08;
			left[idx] = (left[idx] ?? 0) + v * .7;
			right[idx] = (right[idx] ?? 0) + v;
		}
	}
}
function fadeEdges(pos, width) {
	if (pos < width) return pos / width;
	if (pos > 1 - width) return (1 - pos) / width;
	return 1;
}
var BT_RE = /bluetooth|airpods|buds|a2dp|galaxy buds|pixel buds|wh-1000|wf-1000|qc[0-9]|momentum|freebuds|sony|jabra|bose|beats/i;
var WIRED_RE = /headphone|headset|earphone|earbud|usb(-|\s)?audio|dac|dongle|lightning|3\.5|aux/i;
var SPEAKER_RE = /speaker|built-?in|macbook|imac|display audio|internal|laptop|phone speaker|default/i;
function isMobileUserAgent(ua = typeof navigator === "undefined" ? "" : navigator.userAgent) {
	return /Mobi|Android|iPhone|iPod/i.test(ua);
}
function classifyLabel(label) {
	const text = label.trim();
	if (!text) return "speaker";
	if (BT_RE.test(text)) return "bluetooth";
	if (WIRED_RE.test(text)) return "wired";
	if (SPEAKER_RE.test(text)) return "speaker";
	return "speaker";
}
async function listOutputDevices() {
	if (typeof navigator === "undefined" || !navigator.mediaDevices?.enumerateDevices) return [];
	try {
		return (await navigator.mediaDevices.enumerateDevices()).filter((device) => device.kind === "audiooutput").map((device, index) => {
			const label = device.label || `Output ${index + 1}`;
			return {
				deviceId: device.deviceId,
				label,
				kind: classifyLabel(label)
			};
		});
	} catch {
		return [];
	}
}
function pickDeviceForMode(devices, mode) {
	return devices.find((device) => device.kind === mode);
}
function preferredModeFromDevices(devices, mobile) {
	if (devices.some((device) => device.kind === "wired")) return "wired";
	if (devices.some((device) => device.kind === "bluetooth")) return "bluetooth";
	if (mobile) return "speaker";
	if (devices.length === 0) return mobile ? "speaker" : "wired";
	return "speaker";
}
var flat = PRESETS[0];
var useEqStore = create()(persist((set, get) => ({
	gains: emptyGains(),
	bass: 0,
	treble: 0,
	preamp: 0,
	volume: .85,
	outputMode: "wired",
	outputLabel: null,
	presetId: "flat",
	isPlaying: false,
	sourceKind: "none",
	fileName: null,
	currentTime: 0,
	duration: 0,
	hydrated: false,
	setGain: (index, value) => {
		if (index < 0 || index >= BAND_COUNT) return;
		const gains = [...get().gains];
		gains[index] = clampGain(value);
		set({
			gains,
			presetId: matchPreset(gains, get().bass, get().treble)
		});
	},
	setBass: (value) => {
		const bass = clampGain(value);
		set({
			bass,
			presetId: matchPreset(get().gains, bass, get().treble)
		});
	},
	setTreble: (value) => {
		const treble = clampGain(value);
		set({
			treble,
			presetId: matchPreset(get().gains, get().bass, treble)
		});
	},
	setPreamp: (value) => set({ preamp: clampGain(value) }),
	setVolume: (value) => set({ volume: Math.min(1, Math.max(0, value)) }),
	setOutputMode: (mode, label = get().outputLabel) => set({
		outputMode: mode,
		outputLabel: label ?? null
	}),
	applyPreset: (preset) => set({
		gains: [...preset.gains],
		bass: preset.bass,
		treble: preset.treble,
		preamp: preset.preamp,
		presetId: preset.id
	}),
	reset: () => {
		if (flat) get().applyPreset(flat);
	},
	setPlayback: (partial) => set(partial),
	markHydrated: () => set({ hydrated: true })
}), {
	name: "signal-eq",
	skipHydration: true,
	partialize: (state) => ({
		gains: state.gains,
		bass: state.bass,
		treble: state.treble,
		preamp: state.preamp,
		volume: state.volume,
		outputMode: state.outputMode,
		presetId: state.presetId
	})
}));
function eqIsLocked(mode) {
	return mode === "speaker";
}
function Studio() {
	const store = useEqStore();
	const locked = eqIsLocked(store.outputMode);
	const fileUrl = (0, import_react.useRef)(null);
	const [dragging, setDragging] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const boot = async () => {
			await useEqStore.persist.rehydrate();
			if (cancelled) return;
			useEqStore.getState().markHydrated();
			const mobile = isMobileUserAgent();
			const devices = await listOutputDevices();
			if (cancelled) return;
			const preferred = preferredModeFromDevices(devices, mobile);
			const current = useEqStore.getState();
			if ((preferred === "wired" || preferred === "bluetooth") && current.outputMode === "speaker") {
				const match = pickDeviceForMode(devices, preferred);
				current.setOutputMode(preferred, match?.label ?? null);
			} else if (mobile && current.outputMode === "wired" && preferred === "speaker") current.setOutputMode("speaker", "Phone speaker");
		};
		boot();
		const onDeviceChange = () => {
			(async () => {
				const devices = await listOutputDevices();
				const preferred = preferredModeFromDevices(devices, isMobileUserAgent());
				if (preferred === "wired" || preferred === "bluetooth") {
					const match = pickDeviceForMode(devices, preferred);
					useEqStore.getState().setOutputMode(preferred, match?.label ?? null);
				}
			})();
		};
		navigator.mediaDevices?.addEventListener?.("devicechange", onDeviceChange);
		return () => {
			cancelled = true;
			navigator.mediaDevices?.removeEventListener?.("devicechange", onDeviceChange);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const engine = getEngine();
		if (!engine) return;
		engine.setEnabled(!locked);
		engine.setGains(store.gains);
		engine.setBass(store.bass);
		engine.setTreble(store.treble);
		engine.setPreamp(store.preamp);
		engine.setVolume(store.volume);
	}, [
		locked,
		store.gains,
		store.bass,
		store.treble,
		store.preamp,
		store.volume
	]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const applySink = async () => {
			const engine = getEngine();
			if (!engine) return;
			const devices = await listOutputDevices();
			if (cancelled) return;
			const match = pickDeviceForMode(devices, store.outputMode);
			await engine.setSink(match?.deviceId ?? "");
		};
		applySink();
		return () => {
			cancelled = true;
		};
	}, [store.outputMode]);
	(0, import_react.useEffect)(() => {
		const engine = getEngine();
		if (!engine) return;
		const audio = engine.audio;
		const onTime = () => useEqStore.getState().setPlayback({
			currentTime: audio.currentTime,
			duration: Number.isFinite(audio.duration) ? audio.duration : 0,
			isPlaying: !audio.paused
		});
		const onEnded = () => useEqStore.getState().setPlayback({ isPlaying: false });
		audio.addEventListener("timeupdate", onTime);
		audio.addEventListener("ended", onEnded);
		audio.addEventListener("play", onTime);
		audio.addEventListener("pause", onTime);
		return () => {
			audio.removeEventListener("timeupdate", onTime);
			audio.removeEventListener("ended", onEnded);
			audio.removeEventListener("play", onTime);
			audio.removeEventListener("pause", onTime);
		};
	}, []);
	const loadSrc = (0, import_react.useCallback)(async (url, kind, name) => {
		const engine = getEngine();
		if (!engine) return;
		await engine.resume();
		engine.audio.src = url;
		engine.audio.loop = true;
		await engine.audio.play();
		useEqStore.getState().setPlayback({
			isPlaying: true,
			sourceKind: kind,
			fileName: name,
			currentTime: 0,
			duration: Number.isFinite(engine.audio.duration) ? engine.audio.duration : 0
		});
	}, []);
	const playDemo = (0, import_react.useCallback)(async () => {
		const url = getDemoUrl();
		await loadSrc(url, "demo", "Demo mix");
	}, [loadSrc]);
	const loadFile = (0, import_react.useCallback)(async (file) => {
		if (fileUrl.current) URL.revokeObjectURL(fileUrl.current);
		const url = URL.createObjectURL(file);
		fileUrl.current = url;
		await loadSrc(url, "file", file.name);
	}, [loadSrc]);
	const playPause = (0, import_react.useCallback)(async () => {
		const engine = getEngine();
		if (!engine) return;
		if (store.sourceKind === "none") {
			await playDemo();
			return;
		}
		await engine.resume();
		if (engine.audio.paused) await engine.audio.play();
		else engine.audio.pause();
	}, [playDemo, store.sourceKind]);
	const seek = (0, import_react.useCallback)((time) => {
		const engine = getEngine();
		if (!engine) return;
		engine.audio.currentTime = time;
		useEqStore.getState().setPlayback({ currentTime: time });
	}, []);
	const setMode = (0, import_react.useCallback)((mode) => {
		store.setOutputMode(mode, null);
	}, [store]);
	const onPreset = (0, import_react.useCallback)((id) => {
		const preset = PRESETS.find((item) => item.id === id);
		if (preset) store.applyPreset(preset);
	}, [store]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-8",
		onDragOver: (event) => {
			event.preventDefault();
			setDragging(true);
		},
		onDragLeave: () => setDragging(false),
		onDrop: (event) => {
			event.preventDefault();
			setDragging(false);
			const file = event.dataTransfer.files[0];
			if (file && file.type.startsWith("audio")) loadFile(file);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-widest text-subtle",
						children: "Graphic equalizer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-4xl font-medium tracking-tight text-fg sm:text-5xl",
						children: "SIGNAL"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-md text-sm text-muted",
						children: "Ten bands, dedicated bass and treble. Live only on wired headphones or Bluetooth — never the phone speaker."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full flex-col items-stretch gap-2 sm:w-80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutputModeSwitch, {
						value: store.outputMode,
						onChange: setMode
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-right font-mono text-xs uppercase tracking-widest text-subtle",
						children: locked ? "Bypassed" : store.outputLabel ?? "EQ live"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-[minmax(16rem,18rem)_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex flex-col gap-5 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)] lg:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-around gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
								label: "Bass",
								value: store.bass,
								onChange: store.setBass,
								disabled: locked
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
								label: "Treble",
								value: store.treble,
								onChange: store.setTreble,
								disabled: locked
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-widest text-muted",
								children: "Curve"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								onClick: store.reset,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), "Flat"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetsRow, {
							activeId: store.presetId === "custom" ? "" : store.presetId,
							onSelect: onPreset,
							disabled: locked
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: cn("relative h-80 overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)] md:h-96", dragging && "ring-2 ring-accent/40"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EqCanvas, {
							gains: store.gains,
							bass: store.bass,
							treble: store.treble,
							locked,
							playing: store.isPlaying
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EqFaders, {
							gains: store.gains,
							onChange: store.setGain,
							disabled: locked
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOverlay, {
							visible: locked,
							onChooseWired: () => setMode("wired"),
							onChooseBluetooth: () => setMode("bluetooth")
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, {
				isPlaying: store.isPlaying,
				sourceKind: store.sourceKind,
				fileName: store.fileName,
				currentTime: store.currentTime,
				duration: store.duration,
				volume: store.volume,
				preamp: store.preamp,
				onPlayPause: () => void playPause(),
				onDemo: () => void playDemo(),
				onFile: (file) => void loadFile(file),
				onSeek: seek,
				onVolume: store.setVolume,
				onPreamp: store.setPreamp
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {})
	});
}
//#endregion
export { Home as component };
