import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Candy, C as FlaskConical, D as Droplets, E as FileSpreadsheet, M as Boxes, N as BookOpen, O as Cuboid, P as Battery, S as Grid2x2, T as Fish, _ as Lightbulb, b as Landmark, c as ShoppingBag, d as PenLine, f as Package, g as ListChecks, h as Mic, i as Users, j as Brush, k as ClipboardList, l as Settings, m as Milk, n as Warehouse, o as SprayCan, p as Notebook, r as Utensils, s as Sparkles, t as Wheat, u as Plus, v as Leaf, w as Flame, x as House, y as Layers } from "../_libs/lucide-react.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Tooltip, i as ResponsiveContainer, n as XAxis, r as Area, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BK4xn5nC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHART = [
	{
		code: "1100",
		name: "صندوق",
		type: "asset"
	},
	{
		code: "1110",
		name: "بانک",
		type: "asset"
	},
	{
		code: "1200",
		name: "حساب‌های دریافتنی",
		type: "asset"
	},
	{
		code: "1300",
		name: "موجودی کالا",
		type: "asset"
	},
	{
		code: "1400",
		name: "مالیات ارزش افزوده خرید",
		type: "asset"
	},
	{
		code: "1500",
		name: "دارایی ثابت",
		type: "asset"
	},
	{
		code: "2100",
		name: "حساب‌های پرداختنی",
		type: "liability"
	},
	{
		code: "2200",
		name: "مالیات ارزش افزوده فروش",
		type: "liability"
	},
	{
		code: "2300",
		name: "استهلاک انباشته",
		type: "liability"
	},
	{
		code: "3100",
		name: "سرمایه",
		type: "equity"
	},
	{
		code: "4100",
		name: "فروش",
		type: "income"
	},
	{
		code: "5100",
		name: "بهای تمام‌شده",
		type: "expense"
	},
	{
		code: "5200",
		name: "هزینه‌های عمومی",
		type: "expense"
	},
	{
		code: "5300",
		name: "هزینه استهلاک",
		type: "expense"
	}
];
function accountName(code) {
	return CHART.find((a) => a.code === code)?.name ?? code;
}
function accountType(code) {
	return CHART.find((a) => a.code === code)?.type ?? "asset";
}
function isDebitNature(code) {
	const t = accountType(code);
	return t === "asset" || t === "expense";
}
var SOURCE_LABEL = {
	opening: "افتتاحیه",
	sale: "فروش",
	purchase: "خرید",
	receipt: "دریافت",
	payment: "پرداخت",
	expense: "هزینه",
	transfer: "انتقال",
	depreciation: "استهلاک",
	production: "تولید",
	adjust: "اصلاح",
	manual: "سند دستی"
};
var GROUPS = [
	"نوشیدنی",
	"خواربار",
	"بهداشت",
	"تنقلات",
	"لوازم‌التحریر",
	"الکتریکی",
	"لبنیات",
	"کنسرو",
	"تولید",
	"سایر"
];
var TODAY = "2026-11-06";
var MONTHS = [
	"فروردین",
	"اردیبهشت",
	"خرداد",
	"تیر",
	"مرداد",
	"شهریور",
	"مهر",
	"آبان",
	"آذر",
	"دی",
	"بهمن",
	"اسفند"
];
function toJalali(gy, gm, gd) {
	const g_d_m = [
		0,
		31,
		59,
		90,
		120,
		151,
		181,
		212,
		243,
		273,
		304,
		334
	];
	let jy = gy <= 1600 ? 0 : 979;
	gy -= gy <= 1600 ? 621 : 1600;
	const gy2 = gm > 2 ? gy + 1 : gy;
	let days = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
	jy += 33 * Math.floor(days / 12053);
	days %= 12053;
	jy += 4 * Math.floor(days / 1461);
	days %= 1461;
	if (days > 365) {
		jy += Math.floor((days - 1) / 365);
		days = (days - 1) % 365;
	}
	const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
	const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
	return {
		jy,
		jm,
		jd
	};
}
function addDays(iso, n) {
	const d = /* @__PURE__ */ new Date(iso + "T12:00:00Z");
	d.setUTCDate(d.getUTCDate() + n);
	return d.toISOString().slice(0, 10);
}
function splitIso(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return toJalali(y, m, d);
}
var nf$1 = new Intl.NumberFormat("fa-IR");
function formatJalali(iso) {
	const j = splitIso(iso);
	return `${nf$1.format(j.jd)} ${MONTHS[j.jm - 1]} ${nf$1.format(j.jy)}`;
}
function formatJalaliShort(iso) {
	const j = splitIso(iso);
	return `${nf$1.format(j.jm)}/${nf$1.format(j.jd)}`;
}
function isToday(iso) {
	return iso === TODAY;
}
function priceDraft(draft, products, settings) {
	const lines = [];
	for (const line of draft.lines) {
		const p = products.find((x) => x.id === line.productId);
		if (!p || line.qty <= 0) continue;
		const price = Math.round(line.price);
		lines.push({
			productId: p.id,
			name: p.name,
			qty: line.qty,
			price,
			cost: p.cost,
			amount: line.qty * price
		});
	}
	const gross = lines.reduce((s, l) => s + l.amount, 0);
	const rawDiscount = draft.discountMode === "percent" ? Math.round(gross * draft.discountValue / 100) : Math.round(draft.discountValue);
	const discount = Math.max(0, Math.min(gross, rawDiscount || 0));
	const net = gross - discount;
	const tax = draft.taxEnabled ? Math.round(net * settings.taxRate / 100) : 0;
	const extras = Math.round(draft.shipping + draft.packing + draft.otherCost);
	return {
		lines,
		gross,
		discount,
		net,
		tax,
		extras,
		total: net + tax + extras,
		cogs: lines.reduce((s, l) => s + l.qty * l.cost, 0)
	};
}
function trialOf(entries) {
	const map = /* @__PURE__ */ new Map();
	for (const e of entries) for (const l of e.lines) {
		const cur = map.get(l.accountCode) ?? {
			debit: 0,
			credit: 0
		};
		cur.debit += l.debit;
		cur.credit += l.credit;
		map.set(l.accountCode, cur);
	}
	const rows = [];
	let debit = 0;
	let credit = 0;
	for (const [code, v] of map) {
		const net = v.debit - v.credit;
		const rowDebit = net > 0 ? net : 0;
		const rowCredit = net < 0 ? -net : 0;
		if (rowDebit === 0 && rowCredit === 0) continue;
		rows.push({
			code,
			name: accountName(code),
			debit: rowDebit,
			credit: rowCredit
		});
		debit += rowDebit;
		credit += rowCredit;
	}
	rows.sort((a, b) => a.code.localeCompare(b.code));
	return {
		rows,
		debit,
		credit,
		ok: debit === credit
	};
}
function accountBalance(entries, code) {
	let debit = 0;
	let credit = 0;
	for (const e of entries) for (const l of e.lines) {
		if (l.accountCode !== code) continue;
		debit += l.debit;
		credit += l.credit;
	}
	const natural = isDebitNature(code) ? debit - credit : credit - debit;
	return {
		debit,
		credit,
		natural
	};
}
function ledgerOf(entries, code) {
	const rows = [];
	let bal = 0;
	const sorted = [...entries].sort((a, b) => a.date.localeCompare(b.date) || a.number.localeCompare(b.number));
	for (const e of sorted) for (const l of e.lines) {
		if (l.accountCode !== code) continue;
		bal += isDebitNature(code) ? l.debit - l.credit : l.credit - l.debit;
		rows.push({
			id: e.id + code + rows.length,
			date: e.date,
			number: e.number,
			desc: l.desc || e.desc,
			debit: l.debit,
			credit: l.credit,
			balance: bal
		});
	}
	return rows;
}
function partyRows(entries, parties) {
	return parties.map((p) => {
		let ar = 0;
		let ap = 0;
		for (const e of entries) for (const l of e.lines) {
			if (l.partyId !== p.id) continue;
			if (l.accountCode === "1200") ar += l.debit - l.credit;
			if (l.accountCode === "2100") ap += l.credit - l.debit;
		}
		const net = ar - ap;
		const label = net > 0 ? "بدهکار به شما" : net < 0 ? "شما بدهکارید" : "تسویه";
		return {
			id: p.id,
			name: p.name,
			phone: p.phone,
			net,
			label
		};
	});
}
function partySummary(rows) {
	const debtors = rows.reduce((s, r) => s + (r.net > 0 ? r.net : 0), 0);
	const creditors = rows.reduce((s, r) => s + (r.net < 0 ? -r.net : 0), 0);
	return {
		debtors,
		creditors,
		balance: creditors - debtors
	};
}
function kpisOf(entries, products, draftCount) {
	const from = "2026-10-23";
	const to = TODAY;
	const inMonth = entries.filter((e) => e.date >= from && e.date <= to);
	const credit = (code) => inMonth.reduce((s, e) => s + e.lines.filter((l) => l.accountCode === code).reduce((a, l) => a + l.credit - l.debit, 0), 0);
	const debit = (code) => inMonth.reduce((s, e) => s + e.lines.filter((l) => l.accountCode === code).reduce((a, l) => a + l.debit - l.credit, 0), 0);
	const sales = Math.max(0, credit("4100"));
	const cogs = Math.max(0, debit("5100"));
	const purchases = inMonth.filter((e) => e.source === "purchase").reduce((s, e) => s + e.lines.filter((l) => l.accountCode === "1300").reduce((a, l) => a + l.debit, 0), 0);
	const receipts = inMonth.filter((e) => e.source === "receipt").reduce((s, e) => s + e.lines.reduce((a, l) => a + l.debit, 0), 0);
	const payments = inMonth.filter((e) => e.source === "payment").reduce((s, e) => s + e.lines.reduce((a, l) => a + l.credit, 0), 0);
	const expenses = Math.max(0, debit("5200") + debit("5300"));
	const tb = trialOf(entries);
	return {
		sales,
		purchases,
		receipts,
		payments,
		cogs,
		profit: sales - cogs,
		expenses,
		low: products.filter((p) => p.qty <= p.minQty).length,
		negative: products.filter((p) => p.qty < 0).length,
		drafts: draftCount,
		docs: entries.length,
		cash: accountBalance(entries, "1100").natural,
		bank: accountBalance(entries, "1110").natural,
		balanced: tb.ok
	};
}
function salesSeries(entries) {
	const days = [];
	for (let i = 13; i >= 0; i--) {
		const date = addDays(TODAY, -i);
		const sales = entries.filter((e) => e.date === date).reduce((s, e) => s + e.lines.filter((l) => l.accountCode === "4100").reduce((a, l) => a + l.credit - l.debit, 0), 0);
		days.push({
			date,
			sales: Math.max(0, sales)
		});
	}
	return days;
}
function kardexValue(products) {
	return products.reduce((s, p) => s + p.qty * p.cost, 0);
}
function moveQty(moves, productId) {
	return moves.filter((m) => m.productId === productId).reduce((s, m) => s + m.qty, 0);
}
function payLabel(draft) {
	if (draft.settlement === "credit") return "نسیه";
	if (draft.settlement === "multi") return "چند روش";
	if (draft.method === "card") return "کارتخوان";
	if (draft.method === "cheque") return "چک";
	if (draft.method === "other") return "سایر";
	return "نقدی";
}
function blendCost(oldQty, oldCost, addQty, addCost) {
	if (addQty <= 0) return oldCost;
	if (oldQty <= 0) return addCost;
	return Math.round((oldQty * oldCost + addQty * addCost) / (oldQty + addQty));
}
var RECIPES = [
	{
		id: "pack-health",
		name: "پک بهداشتی خانواده",
		price: 165e3,
		icon: "package",
		inputs: [
			{
				name: "مایع لباسشویی ۲.۵ لیتری",
				qty: 1
			},
			{
				name: "دستمال کاغذی ۲۰۰ برگ",
				qty: 1
			},
			{
				name: "صابون دستشویی",
				qty: 2
			}
		]
	},
	{
		id: "pack-write",
		name: "پک تحریر دانش‌آموزی",
		price: 145e3,
		icon: "notebook",
		inputs: [{
			name: "بسته خودکار آبی",
			qty: 1
		}, {
			name: "دفتر ۱۰۰ برگ",
			qty: 1
		}]
	},
	{
		id: "pack-tea",
		name: "پک پذیرایی چای",
		price: 185e3,
		icon: "leaf",
		inputs: [{
			name: "چای سیاه ۵۰۰ گرمی",
			qty: 1
		}, {
			name: "قند شکسته ۲ کیلویی",
			qty: 1
		}]
	}
];
var SETTINGS = {
	shopName: "آفیس‌باز",
	phone: "۰۵۱-۳۸۴۴۱۱۰۰",
	address: "مشهد، بلوار وکیل‌آباد",
	economicCode: "۱۴۰۵۸۴۲۱۹۰۰",
	taxRate: 10
};
var CATALOG = [
	{
		id: "p01",
		name: "آب معدنی ۱.۵ لیتری",
		barcode: "626100000001",
		group: "نوشیدنی",
		unit: "عدد",
		icon: "droplets",
		price: 32e3,
		cost: 21e3,
		minQty: 10,
		finalQty: 8
	},
	{
		id: "p02",
		name: "چای سیاه ۵۰۰ گرمی",
		barcode: "626100000002",
		group: "نوشیدنی",
		unit: "عدد",
		icon: "leaf",
		price: 28500,
		cost: 19e3,
		minQty: 20,
		finalQty: 15
	},
	{
		id: "p03",
		name: "برنج ایرانی ۵ کیلویی",
		barcode: "626100000003",
		group: "خواربار",
		unit: "عدد",
		icon: "wheat",
		price: 385e3,
		cost: 31e4,
		minQty: 6,
		finalQty: 22
	},
	{
		id: "p04",
		name: "روغن مایع ۱.۵ لیتری",
		barcode: "626100000004",
		group: "خواربار",
		unit: "عدد",
		icon: "flask",
		price: 42e3,
		cost: 34e3,
		minQty: 8,
		finalQty: 29
	},
	{
		id: "p05",
		name: "رب گوجه‌فرنگی ۸۰۰ گرمی",
		barcode: "626100000005",
		group: "خواربار",
		unit: "عدد",
		icon: "flame",
		price: 45500,
		cost: 3e4,
		minQty: 8,
		finalQty: 36
	},
	{
		id: "p06",
		name: "مایع لباسشویی ۲.۵ لیتری",
		barcode: "626100000006",
		group: "بهداشت",
		unit: "عدد",
		icon: "spray",
		price: 52e3,
		cost: 37e3,
		minQty: 8,
		finalQty: 43
	},
	{
		id: "p07",
		name: "دستمال کاغذی ۲۰۰ برگ",
		barcode: "626100000007",
		group: "بهداشت",
		unit: "عدد",
		icon: "layers",
		price: 59500,
		cost: 4e4,
		minQty: 10,
		finalQty: 50
	},
	{
		id: "p08",
		name: "شکلات تخته‌ای",
		barcode: "626100000008",
		group: "تنقلات",
		unit: "عدد",
		icon: "candy",
		price: 67e3,
		cost: 45e3,
		minQty: 12,
		finalQty: 57
	},
	{
		id: "p09",
		name: "بسته خودکار آبی",
		barcode: "626100000009",
		group: "لوازم‌التحریر",
		unit: "بسته",
		icon: "pen",
		price: 68500,
		cost: 42e3,
		minQty: 10,
		finalQty: 64
	},
	{
		id: "p10",
		name: "مسواک متوسط",
		barcode: "626100000010",
		group: "بهداشت",
		unit: "عدد",
		icon: "brush",
		price: 242e3,
		cost: 15e4,
		minQty: 6,
		finalQty: 40
	},
	{
		id: "p11",
		name: "لامپ LED دوازده وات",
		barcode: "626100000011",
		group: "الکتریکی",
		unit: "عدد",
		icon: "bulb",
		price: 266e3,
		cost: 175e3,
		minQty: 4,
		finalQty: 18
	},
	{
		id: "p12",
		name: "شیر کم‌چرب ۱ لیتری",
		barcode: "626100000012",
		group: "لبنیات",
		unit: "عدد",
		icon: "milk",
		price: 38e3,
		cost: 29e3,
		minQty: 8,
		finalQty: 24
	},
	{
		id: "p13",
		name: "ماکارونی ۷۰۰ گرمی",
		barcode: "626100000013",
		group: "خواربار",
		unit: "عدد",
		icon: "pasta",
		price: 44500,
		cost: 28e3,
		minQty: 8,
		finalQty: 33
	},
	{
		id: "p14",
		name: "تن ماهی ۱۸۰ گرمی",
		barcode: "626100000014",
		group: "کنسرو",
		unit: "عدد",
		icon: "fish",
		price: 89e3,
		cost: 62e3,
		minQty: 8,
		finalQty: 27
	},
	{
		id: "p15",
		name: "قند شکسته ۲ کیلویی",
		barcode: "626100000015",
		group: "خواربار",
		unit: "عدد",
		icon: "cube",
		price: 72e3,
		cost: 54e3,
		minQty: 6,
		finalQty: 16
	},
	{
		id: "p16",
		name: "صابون دستشویی",
		barcode: "626100000016",
		group: "بهداشت",
		unit: "عدد",
		icon: "spark",
		price: 35e3,
		cost: 18e3,
		minQty: 10,
		finalQty: 48
	},
	{
		id: "p17",
		name: "باتری قلمی دو عددی",
		barcode: "626100000017",
		group: "الکتریکی",
		unit: "بسته",
		icon: "battery",
		price: 56e3,
		cost: 34e3,
		minQty: 6,
		finalQty: 21
	},
	{
		id: "p18",
		name: "دفتر ۱۰۰ برگ",
		barcode: "626100000018",
		group: "لوازم‌التحریر",
		unit: "عدد",
		icon: "notebook",
		price: 48e3,
		cost: 27e3,
		minQty: 8,
		finalQty: 30
	}
];
var PARTIES = [
	{
		id: "pa",
		name: "تأمین کالای پارس",
		phone: "09121000010"
	},
	{
		id: "hk",
		name: "حسین کریمی",
		phone: "09122000004"
	},
	{
		id: "ra",
		name: "رضا اکبری",
		phone: "09120000008"
	},
	{
		id: "sa",
		name: "سمیه احمدی",
		phone: "09120000006"
	},
	{
		id: "om",
		name: "سوپرمارکت امید",
		phone: "09123000009"
	},
	{
		id: "se",
		name: "شرکت پخش سپهر",
		phone: "09123000005"
	},
	{
		id: "ar",
		name: "علی رضایی",
		phone: "09123000001"
	},
	{
		id: "ba",
		name: "فروشگاه بهار",
		phone: "09123000003"
	},
	{
		id: "mm",
		name: "مریم محمدی",
		phone: "09120000002"
	},
	{
		id: "ay",
		name: "پخش مواد غذایی آریا",
		phone: "09123000007"
	}
];
var AR = {
	sa: 64e4,
	om: 98e4,
	ar: 85e4,
	ba: 125e4
};
var AP = {
	pa: 1648e3,
	hk: 32e4,
	se: 375e4,
	ay: 2232e3
};
var ASSETS = [{
	id: "as1",
	name: "یخچال ویترینی",
	cost: 85e6,
	months: 60,
	accumulated: 14166670,
	acquired: "2025-11-06"
}, {
	id: "as2",
	name: "صندوق فروشگاهی",
	cost: 24e6,
	months: 36,
	accumulated: 4000002,
	acquired: "2025-08-01"
}];
var TRAINING_NAMES = [
	"شکر یک کیلویی",
	"نمک یددار",
	"ماست پرچرب ۹۰۰ گرمی",
	"پنیر ۴۰۰ گرمی",
	"دوغ گازدار",
	"آبمیوه پرتقال",
	"بیسکویت ساقه",
	"چیپس نمکی",
	"پفک خانواده",
	"کنسرو لوبیا",
	"سرکه سفید",
	"آبلیمو",
	"مربا هویج",
	"عسل ۹۰۰ گرمی",
	"چای کیسه‌ای",
	"قهوه فوری",
	"پودر لباسشویی",
	"مایع ظرفشویی",
	"شامپو خانواده",
	"خمیردندان",
	"پوشک بچه",
	"دستمال توالت",
	"فویل آلومینیومی",
	"کیسه فریزر",
	"لامپ شمعی",
	"شارژر موبایل",
	"کابل USB",
	"دفتر مشق",
	"مداد مشکی",
	"پاک‌کن",
	"چسب ماتیکی",
	"دستکش یکبارمصرف"
];
function trainingProducts() {
	return TRAINING_NAMES.map((name, i) => {
		const price = 18e3 + i * 4700 % 14e4;
		const qty = 12 + i * 5 % 40;
		return {
			id: "t" + String(i + 1).padStart(2, "0"),
			name,
			barcode: "626200000" + String(i + 1).padStart(3, "0"),
			group: i % 5 === 0 ? "بهداشت" : i % 5 === 1 ? "خواربار" : i % 5 === 2 ? "نوشیدنی" : i % 5 === 3 ? "الکتریکی" : "لوازم‌التحریر",
			unit: "عدد",
			icon: "package",
			qty,
			price,
			cost: Math.round(price * .68),
			minQty: 5
		};
	});
}
function mulberry32(seed) {
	let a = seed;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function L(accountCode, debit, credit, desc, partyId) {
	const line = {
		accountCode,
		debit: Math.round(debit),
		credit: Math.round(credit),
		desc
	};
	if (partyId) line.partyId = partyId;
	return line;
}
function buildSeed() {
	const rand = mulberry32(14051106);
	const sold = {};
	const bought = {};
	const days = [];
	const cheap = CATALOG.slice(0, 12);
	for (let ago = 14; ago >= 1; ago--) {
		const date = addDays(TODAY, -ago);
		const count = 1 + Math.floor(rand() * 2);
		const items = [];
		for (let k = 0; k < count; k++) {
			const pool = rand() < .82 ? cheap : CATALOG;
			const p = pool[Math.floor(rand() * pool.length)];
			const qty = 1 + Math.floor(rand() * 2);
			items.push({
				id: p.id,
				qty,
				price: p.price,
				cost: p.cost
			});
			sold[p.id] = (sold[p.id] ?? 0) + qty;
		}
		days.push({
			date,
			items
		});
	}
	const purchaseId = "p07";
	const purchaseQty = 10;
	const purchaseDate = addDays(TODAY, -6);
	bought[purchaseId] = purchaseQty;
	const products = CATALOG.map((p) => {
		const opening = p.finalQty - (bought[p.id] ?? 0) + (sold[p.id] ?? 0);
		return {
			id: p.id,
			name: p.name,
			barcode: p.barcode,
			group: p.group,
			unit: p.unit,
			icon: p.icon,
			qty: p.finalQty,
			price: p.price,
			cost: p.cost,
			minQty: p.minQty,
			...opening < 0 ? {} : {}
		};
	});
	const openingQty = (id) => {
		return CATALOG.find((x) => x.id === id).finalQty - (bought[id] ?? 0) + (sold[id] ?? 0);
	};
	const moves = [];
	let mi = 1;
	const openDate = addDays(TODAY, -21);
	for (const p of CATALOG) {
		const q = openingQty(p.id);
		if (q !== 0) moves.push({
			id: "m" + mi++,
			date: openDate,
			productId: p.id,
			qty: q,
			cost: p.cost,
			ref: "opening",
			kind: "opening"
		});
	}
	const entries = [];
	let ei = 100;
	const push = (date, desc, source, lines, ref) => {
		const debit = lines.reduce((s, l) => s + l.debit, 0);
		const credit = lines.reduce((s, l) => s + l.credit, 0);
		if (debit !== credit) throw new Error(`سند نامتوازن: ${desc} ${debit} / ${credit}`);
		entries.push({
			id: "e" + ei,
			number: String(ei),
			date,
			desc,
			source,
			status: "posted",
			ref,
			lines
		});
		ei += 1;
	};
	const invValue = CATALOG.reduce((s, p) => s + openingQty(p.id) * p.cost, 0);
	const fixed = ASSETS.reduce((s, a) => s + a.cost, 0);
	const accum = ASSETS.reduce((s, a) => s + a.accumulated, 0);
	const cash0 = 185e5;
	const bank0 = 264e5;
	const ar = Object.values(AR).reduce((s, n) => s + n, 0);
	const ap = Object.values(AP).reduce((s, n) => s + n, 0);
	const equity = 449e5 + ar + invValue + fixed - ap - accum;
	const openLines = [
		L("1100", cash0, 0, "موجودی اول دوره صندوق"),
		L("1110", bank0, 0, "موجودی اول دوره بانک"),
		L("1300", invValue, 0, "موجودی اول دوره کالا"),
		L("1500", fixed, 0, "بهای تمام‌شده دارایی ثابت")
	];
	for (const [id, amount] of Object.entries(AR)) {
		const name = PARTIES.find((p) => p.id === id).name;
		openLines.push(L("1200", amount, 0, "مانده اول دوره " + name, id));
	}
	for (const [id, amount] of Object.entries(AP)) {
		const name = PARTIES.find((p) => p.id === id).name;
		openLines.push(L("2100", 0, amount, "مانده اول دوره " + name, id));
	}
	openLines.push(L("2300", 0, accum, "استهلاک انباشته اول دوره"));
	openLines.push(L("3100", 0, equity, "سرمایه اول دوره"));
	push(openDate, "سند افتتاحیه", "opening", openLines, "opening");
	for (const day of days) {
		let net = 0;
		let cogs = 0;
		for (const item of day.items) {
			net += item.qty * item.price;
			cogs += item.qty * item.cost;
			moves.push({
				id: "m" + mi++,
				date: day.date,
				productId: item.id,
				qty: -item.qty,
				cost: item.cost,
				ref: "day-" + day.date,
				kind: "sale"
			});
		}
		const tax = Math.round(net * .1);
		const total = net + tax;
		push(day.date, "فروش نقدی روزانه", "sale", [
			L("1100", total, 0, "دریافت فروش نقدی"),
			L("4100", 0, net, "فروش کالا"),
			L("2200", 0, tax, "مالیات فروش"),
			L("5100", cogs, 0, "بهای تمام‌شده فروش"),
			L("1300", 0, cogs, "خروج موجودی")
		]);
		if (day.date === purchaseDate) {
			const pp = CATALOG.find((p) => p.id === purchaseId);
			const pNet = purchaseQty * pp.cost;
			const pTax = Math.round(pNet * .1);
			moves.push({
				id: "m" + mi++,
				date: purchaseDate,
				productId: purchaseId,
				qty: purchaseQty,
				cost: pp.cost,
				ref: "purchase-seed",
				kind: "purchase"
			});
			push(purchaseDate, "خرید نقدی " + pp.name, "purchase", [
				L("1300", pNet, 0, "ورود کالا"),
				L("1400", pTax, 0, "مالیات خرید"),
				L("1100", 0, pNet + pTax, "پرداخت از صندوق")
			]);
		}
	}
	for (const p of products) {
		const q = moves.filter((m) => m.productId === p.id).reduce((s, m) => s + m.qty, 0);
		if (q !== p.qty) throw new Error(`مغایرت کاردکس ${p.name}: ${q} در برابر ${p.qty}`);
	}
	return {
		settings: SETTINGS,
		products,
		parties: PARTIES,
		entries,
		moves,
		assets: ASSETS.map((a) => ({ ...a })),
		seq: {
			entry: ei,
			invoice: 1
		}
	};
}
var seed = buildSeed();
function emptyDraft() {
	return {
		kind: "sale",
		date: TODAY,
		partyId: null,
		lines: [],
		discountMode: "amount",
		discountValue: 0,
		taxEnabled: true,
		shipping: 0,
		packing: 0,
		otherCost: 0,
		settlement: "full",
		method: "cash",
		splitCash: 0
	};
}
function nid(prefix) {
	return prefix + Math.random().toString(36).slice(2, 9);
}
function balanced(lines) {
	const debit = lines.reduce((s, l) => s + l.debit, 0);
	return debit === lines.reduce((s, l) => s + l.credit, 0) && debit > 0;
}
function pushEntry(state, partial) {
	const entry = {
		...partial,
		id: nid("e"),
		number: String(state.seq.entry),
		status: "posted"
	};
	return {
		entries: [...state.entries, entry],
		seq: {
			...state.seq,
			entry: state.seq.entry + 1
		}
	};
}
var useLedger = create()(persist((set, get) => ({
	...seed,
	invoices: [],
	view: "home",
	draft: emptyDraft(),
	focusInvoiceId: null,
	setView: (view) => set({ view }),
	patchDraft: (patch) => set({ draft: {
		...get().draft,
		...patch
	} }),
	resetDraft: (partyId) => set({ draft: {
		...emptyDraft(),
		partyId: partyId ?? null
	} }),
	addLine: (productId) => {
		const p = get().products.find((x) => x.id === productId);
		if (!p) return;
		const lines = get().draft.lines.slice();
		const hit = lines.find((l) => l.productId === productId);
		if (hit) hit.qty += 1;
		else lines.push({
			productId,
			qty: 1,
			price: p.price
		});
		set({ draft: {
			...get().draft,
			lines
		} });
	},
	setLineQty: (productId, qty) => {
		const lines = get().draft.lines.map((l) => l.productId === productId ? {
			...l,
			qty
		} : l).filter((l) => l.qty > 0);
		set({ draft: {
			...get().draft,
			lines
		} });
	},
	setLinePrice: (productId, price) => {
		const lines = get().draft.lines.map((l) => l.productId === productId ? {
			...l,
			price
		} : l);
		set({ draft: {
			...get().draft,
			lines
		} });
	},
	applyVoiceLines: (partyId, voiced) => {
		const products = get().products;
		const lines = get().draft.lines.slice();
		for (const v of voiced) {
			const p = products.find((x) => x.id === v.productId);
			if (!p) continue;
			const hit = lines.find((l) => l.productId === v.productId);
			if (hit) hit.qty += v.qty;
			else lines.push({
				productId: v.productId,
				qty: v.qty,
				price: p.price
			});
		}
		set({
			draft: {
				...get().draft,
				kind: "sale",
				partyId: partyId ?? get().draft.partyId,
				lines
			},
			view: "invoice"
		});
	},
	postDraft: () => {
		const s = get();
		const priced = priceDraft(s.draft, s.products, s.settings);
		if (!priced.lines.length) return {
			ok: false,
			message: "حداقل یک کالا به فاکتور اضافه کنید."
		};
		if (priced.total <= 0) return {
			ok: false,
			message: "مبلغ فاکتور باید بیشتر از صفر باشد."
		};
		if (s.draft.settlement === "credit" && !s.draft.partyId) return {
			ok: false,
			message: "برای فروش نسیه، مشتری را انتخاب کنید."
		};
		const party = s.parties.find((p) => p.id === s.draft.partyId);
		const number = s.seq.invoice;
		const invoiceId = nid("inv");
		const invoice = {
			id: invoiceId,
			number,
			date: s.draft.date,
			partyName: party?.name ?? "مشتری متفرقه",
			partyPhone: party?.phone ?? "",
			kind: s.draft.kind,
			lines: priced.lines.map((l) => ({
				name: l.name,
				qty: l.qty,
				price: l.price,
				amount: l.amount
			})),
			gross: priced.gross,
			discount: priced.discount,
			tax: priced.tax,
			extras: priced.extras,
			total: priced.total,
			payLabel: s.draft.kind === "proforma" ? "پیش‌فاکتور" : payLabel(s.draft),
			status: s.draft.kind === "proforma" ? "draft" : "posted"
		};
		if (s.draft.kind === "proforma") {
			set({
				invoices: [invoice, ...s.invoices],
				seq: {
					...s.seq,
					invoice: number + 1
				},
				focusInvoiceId: invoiceId
			});
			return {
				ok: true,
				message: "پیش‌فاکتور ذخیره شد و در دفاتر ننشست.",
				invoiceId
			};
		}
		const desc = party ? `فروش به ${party.name}` : "فروش نقدی";
		const lines = [];
		const tag = `فاکتور ${number}`;
		if (s.draft.settlement === "credit") lines.push({
			accountCode: "1200",
			debit: priced.total,
			credit: 0,
			desc: tag,
			partyId: party?.id
		});
		else if (s.draft.settlement === "multi") {
			const cash = Math.max(0, Math.min(Math.round(s.draft.splitCash), priced.total));
			const bank = priced.total - cash;
			if (cash) lines.push({
				accountCode: "1100",
				debit: cash,
				credit: 0,
				desc: tag + " نقد"
			});
			if (bank) lines.push({
				accountCode: "1110",
				debit: bank,
				credit: 0,
				desc: tag + " بانک"
			});
		} else if (s.draft.method === "card") lines.push({
			accountCode: "1110",
			debit: priced.total,
			credit: 0,
			desc: tag
		});
		else lines.push({
			accountCode: "1100",
			debit: priced.total,
			credit: 0,
			desc: tag
		});
		const sales = priced.net + priced.extras;
		if (sales) lines.push({
			accountCode: "4100",
			debit: 0,
			credit: sales,
			desc: tag
		});
		if (priced.tax) lines.push({
			accountCode: "2200",
			debit: 0,
			credit: priced.tax,
			desc: "مالیات " + tag
		});
		if (priced.cogs) {
			lines.push({
				accountCode: "5100",
				debit: priced.cogs,
				credit: 0,
				desc: "بهای " + tag
			});
			lines.push({
				accountCode: "1300",
				debit: 0,
				credit: priced.cogs,
				desc: "خروج " + tag
			});
		}
		if (!balanced(lines)) return {
			ok: false,
			message: "سند نامتوازن شد و ثبت نشد."
		};
		const moved = pushEntry(s, {
			date: s.draft.date,
			desc,
			source: "sale",
			ref: invoiceId,
			lines
		});
		const stock = priced.lines.map((l) => ({
			id: nid("m"),
			date: s.draft.date,
			productId: l.productId,
			qty: -l.qty,
			cost: l.cost,
			ref: invoiceId,
			kind: "sale"
		}));
		const products = s.products.map((p) => {
			const q = priced.lines.filter((l) => l.productId === p.id).reduce((a, l) => a + l.qty, 0);
			return q ? {
				...p,
				qty: p.qty - q
			} : p;
		});
		const negative = products.some((p) => p.qty < 0);
		set({
			products,
			entries: moved.entries,
			moves: [...s.moves, ...stock],
			invoices: [invoice, ...s.invoices],
			seq: {
				...moved.seq,
				invoice: number + 1
			},
			focusInvoiceId: invoiceId,
			draft: emptyDraft()
		});
		return {
			ok: true,
			message: negative ? "فاکتور ثبت شد. موجودی یک کالا منفی شده؛ در کنترل روزانه ببینید." : "فاکتور ثبت و سند دوبل صادر شد.",
			invoiceId
		};
	},
	setFocus: (id) => set({ focusInvoiceId: id }),
	addProduct: (input) => {
		const name = input.name.trim();
		if (!name) return {
			ok: false,
			message: "نام کالا لازم است."
		};
		if (input.price <= 0) return {
			ok: false,
			message: "قیمت فروش را وارد کنید."
		};
		const s = get();
		const product = {
			id: nid("p"),
			name,
			barcode: input.barcode.trim() || "626" + String(Date.now()).slice(-8),
			group: input.group || "سایر",
			unit: input.unit || "عدد",
			icon: "package",
			qty: 0,
			price: Math.round(input.price),
			cost: Math.round(input.cost || Math.round(input.price * .7)),
			minQty: input.minQty || 0
		};
		let products = [...s.products, product];
		let entries = s.entries;
		let moves = s.moves;
		let seq = s.seq;
		if (input.qty > 0) {
			const value = input.qty * product.cost;
			const moved = pushEntry({
				...s,
				seq
			}, {
				date: TODAY,
				desc: "موجودی اولیه " + name,
				source: "adjust",
				lines: [{
					accountCode: "1300",
					debit: value,
					credit: 0,
					desc: "ورود اول دوره"
				}, {
					accountCode: "3100",
					debit: 0,
					credit: value,
					desc: "از محل سرمایه"
				}]
			});
			entries = moved.entries;
			seq = moved.seq;
			products = products.map((p) => p.id === product.id ? {
				...p,
				qty: input.qty
			} : p);
			moves = [...moves, {
				id: nid("m"),
				date: TODAY,
				productId: product.id,
				qty: input.qty,
				cost: product.cost,
				ref: "opening",
				kind: "opening"
			}];
		}
		set({
			products,
			entries,
			moves,
			seq
		});
		return {
			ok: true,
			message: "کالا ثبت شد."
		};
	},
	updateProduct: (id, patch) => {
		set({ products: get().products.map((p) => p.id === id ? {
			...p,
			...patch,
			id: p.id,
			qty: p.qty
		} : p) });
	},
	adjustStock: (productId, counted) => {
		const s = get();
		const p = s.products.find((x) => x.id === productId);
		if (!p) return {
			ok: false,
			message: "کالا پیدا نشد."
		};
		const diff = Math.round(counted) - p.qty;
		if (diff === 0) return {
			ok: false,
			message: "موجودی تغییری نکرده."
		};
		const value = Math.abs(diff) * p.cost;
		const lines = diff > 0 ? [{
			accountCode: "1300",
			debit: value,
			credit: 0,
			desc: "اضافه انبارش " + p.name
		}, {
			accountCode: "3100",
			debit: 0,
			credit: value,
			desc: "اصلاح موجودی"
		}] : [{
			accountCode: "3100",
			debit: value,
			credit: 0,
			desc: "کسری انبارش " + p.name
		}, {
			accountCode: "1300",
			debit: 0,
			credit: value,
			desc: "اصلاح موجودی"
		}];
		const moved = pushEntry(s, {
			date: TODAY,
			desc: "اصلاح موجودی " + p.name,
			source: "adjust",
			lines
		});
		set({
			entries: moved.entries,
			seq: moved.seq,
			products: s.products.map((x) => x.id === p.id ? {
				...x,
				qty: Math.round(counted)
			} : x),
			moves: [...s.moves, {
				id: nid("m"),
				date: TODAY,
				productId: p.id,
				qty: diff,
				cost: p.cost,
				ref: "adjust",
				kind: "adjust"
			}]
		});
		return {
			ok: true,
			message: "موجودی اصلاح و سند صادر شد."
		};
	},
	addParty: (input) => {
		const name = input.name.trim();
		if (name.length < 2) return {
			ok: false,
			message: "نام شخص را کامل‌تر بنویسید."
		};
		set({ parties: [...get().parties, {
			id: nid("c"),
			name,
			phone: input.phone.trim()
		}] });
		return {
			ok: true,
			message: "شخص ثبت شد."
		};
	},
	postPurchase: (input) => {
		const s = get();
		const clean = input.lines.map((l) => ({
			productId: l.productId,
			qty: Math.round(l.qty),
			cost: Math.round(l.cost)
		})).filter((l) => l.productId && l.qty > 0 && l.cost > 0);
		if (!clean.length) return {
			ok: false,
			message: "حداقل یک ردیف خرید با تعداد و بها لازم است."
		};
		if (input.pay === "credit" && !input.partyId) return {
			ok: false,
			message: "برای خرید نسیه، فروشنده را انتخاب کنید."
		};
		const party = s.parties.find((x) => x.id === input.partyId);
		const picked = clean.map((l) => ({
			...l,
			product: s.products.find((p) => p.id === l.productId)
		}));
		if (picked.some((l) => !l.product)) return {
			ok: false,
			message: "یکی از کالاها پیدا نشد."
		};
		const net = picked.reduce((sum, l) => sum + l.qty * l.cost, 0);
		const tax = input.taxed ? Math.round(net * s.settings.taxRate / 100) : 0;
		const total = net + tax;
		const creditAccount = input.pay === "bank" ? "1110" : input.pay === "credit" ? "2100" : "1100";
		const creditDesc = input.pay === "bank" ? "پرداخت از بانک" : input.pay === "credit" ? "خرید نسیه" : "پرداخت از صندوق";
		const lines = [{
			accountCode: "1300",
			debit: net,
			credit: 0,
			desc: "ورود خرید"
		}];
		if (tax) lines.push({
			accountCode: "1400",
			debit: tax,
			credit: 0,
			desc: "مالیات خرید"
		});
		lines.push({
			accountCode: creditAccount,
			debit: 0,
			credit: total,
			desc: creditDesc,
			partyId: input.pay === "credit" ? party?.id : void 0
		});
		if (!balanced(lines)) return {
			ok: false,
			message: "سند خرید نامتوازن است."
		};
		const moved = pushEntry(s, {
			date: input.date,
			desc: "خرید " + picked.map((l) => l.product.name).slice(0, 2).join("، ") + (party ? " از " + party.name : ""),
			source: "purchase",
			lines
		});
		let products = s.products.slice();
		const stock = [];
		for (const line of picked) {
			const current = products.find((p) => p.id === line.productId);
			const cost = blendCost(current.qty, current.cost, line.qty, line.cost);
			products = products.map((p) => p.id === line.productId ? {
				...p,
				qty: p.qty + line.qty,
				cost
			} : p);
			stock.push({
				id: nid("m"),
				date: input.date,
				productId: line.productId,
				qty: line.qty,
				cost: line.cost,
				ref: "purchase",
				kind: "purchase"
			});
		}
		set({
			entries: moved.entries,
			seq: moved.seq,
			products,
			moves: [...s.moves, ...stock]
		});
		return {
			ok: true,
			message: "خرید ثبت شد. موجودی و میانگین بها به‌روز شد."
		};
	},
	postReceipt: (input) => {
		const s = get();
		const party = s.parties.find((p) => p.id === input.partyId);
		if (!party) return {
			ok: false,
			message: "شخص را انتخاب کنید."
		};
		if (input.amount <= 0) return {
			ok: false,
			message: "مبلغ دریافت را وارد کنید."
		};
		const amount = Math.round(input.amount);
		const account = input.toBank ? "1110" : "1100";
		const moved = pushEntry(s, {
			date: input.date,
			desc: "دریافت از " + party.name,
			source: "receipt",
			lines: [{
				accountCode: account,
				debit: amount,
				credit: 0,
				desc: "دریافت"
			}, {
				accountCode: "1200",
				debit: 0,
				credit: amount,
				desc: "تسویه دریافتنی",
				partyId: party.id
			}]
		});
		set({
			entries: moved.entries,
			seq: moved.seq
		});
		return {
			ok: true,
			message: "دریافت ثبت شد."
		};
	},
	postPayment: (input) => {
		const s = get();
		const party = s.parties.find((p) => p.id === input.partyId);
		if (!party) return {
			ok: false,
			message: "شخص را انتخاب کنید."
		};
		if (input.amount <= 0) return {
			ok: false,
			message: "مبلغ پرداخت را وارد کنید."
		};
		const amount = Math.round(input.amount);
		const account = input.fromBank ? "1110" : "1100";
		const moved = pushEntry(s, {
			date: input.date,
			desc: "پرداخت به " + party.name,
			source: "payment",
			lines: [{
				accountCode: "2100",
				debit: amount,
				credit: 0,
				desc: "تسویه پرداختنی",
				partyId: party.id
			}, {
				accountCode: account,
				debit: 0,
				credit: amount,
				desc: "پرداخت"
			}]
		});
		set({
			entries: moved.entries,
			seq: moved.seq
		});
		return {
			ok: true,
			message: "پرداخت ثبت شد."
		};
	},
	postExpense: (input) => {
		const s = get();
		if (input.amount <= 0 || !input.desc.trim()) return {
			ok: false,
			message: "شرح و مبلغ هزینه لازم است."
		};
		const amount = Math.round(input.amount);
		const account = input.fromBank ? "1110" : "1100";
		const moved = pushEntry(s, {
			date: input.date,
			desc: input.desc.trim(),
			source: "expense",
			lines: [{
				accountCode: "5200",
				debit: amount,
				credit: 0,
				desc: input.desc.trim()
			}, {
				accountCode: account,
				debit: 0,
				credit: amount,
				desc: "پرداخت هزینه"
			}]
		});
		set({
			entries: moved.entries,
			seq: moved.seq
		});
		return {
			ok: true,
			message: "هزینه ثبت شد."
		};
	},
	postTransfer: (input) => {
		const s = get();
		if (input.amount <= 0) return {
			ok: false,
			message: "مبلغ انتقال را وارد کنید."
		};
		const amount = Math.round(input.amount);
		const lines = input.toBank ? [{
			accountCode: "1110",
			debit: amount,
			credit: 0,
			desc: "واریز به بانک"
		}, {
			accountCode: "1100",
			debit: 0,
			credit: amount,
			desc: "برداشت از صندوق"
		}] : [{
			accountCode: "1100",
			debit: amount,
			credit: 0,
			desc: "واریز به صندوق"
		}, {
			accountCode: "1110",
			debit: 0,
			credit: amount,
			desc: "برداشت از بانک"
		}];
		const moved = pushEntry(s, {
			date: input.date,
			desc: input.toBank ? "انتقال صندوق به بانک" : "انتقال بانک به صندوق",
			source: "transfer",
			lines
		});
		set({
			entries: moved.entries,
			seq: moved.seq
		});
		return {
			ok: true,
			message: "انتقال ثبت شد."
		};
	},
	postDepreciation: (assetId) => {
		const s = get();
		const asset = s.assets.find((a) => a.id === assetId);
		if (!asset) return {
			ok: false,
			message: "دارایی پیدا نشد."
		};
		const monthly = Math.round(asset.cost / asset.months);
		const remain = asset.cost - asset.accumulated;
		if (remain <= 0) return {
			ok: false,
			message: "این دارایی کاملاً مستهلک شده."
		};
		const amount = Math.min(monthly, remain);
		const moved = pushEntry(s, {
			date: TODAY,
			desc: "استهلاک " + asset.name,
			source: "depreciation",
			lines: [{
				accountCode: "5300",
				debit: amount,
				credit: 0,
				desc: "هزینه استهلاک ماه"
			}, {
				accountCode: "2300",
				debit: 0,
				credit: amount,
				desc: "استهلاک انباشته"
			}]
		});
		set({
			entries: moved.entries,
			seq: moved.seq,
			assets: s.assets.map((a) => a.id === asset.id ? {
				...a,
				accumulated: a.accumulated + amount
			} : a)
		});
		return {
			ok: true,
			message: "استهلاک این ماه ثبت شد."
		};
	},
	postProduction: (recipeId, qty) => {
		const s = get();
		const recipe = RECIPES.find((r) => r.id === recipeId);
		if (!recipe || qty <= 0) return {
			ok: false,
			message: "تعداد تولید را وارد کنید."
		};
		const needs = recipe.inputs.map((inp) => {
			return {
				inp,
				p: s.products.find((x) => x.name === inp.name),
				need: inp.qty * qty
			};
		});
		if (needs.some((n) => !n.p)) return {
			ok: false,
			message: "مواد اولیه در کالاها پیدا نشد."
		};
		const short = needs.find((n) => n.p.qty < n.need);
		if (short) return {
			ok: false,
			message: `موجودی ${short.p.name} برای این تولید کافی نیست.`
		};
		const cost = needs.reduce((sum, n) => sum + n.need * n.p.cost, 0);
		let out = s.products.find((p) => p.name === recipe.name);
		let products = s.products.slice();
		if (!out) {
			out = {
				id: nid("p"),
				name: recipe.name,
				barcode: "626300" + recipe.id.slice(0, 6),
				group: "تولید",
				unit: "عدد",
				icon: recipe.icon,
				qty: 0,
				price: recipe.price,
				cost: Math.round(cost / qty),
				minQty: 2
			};
			products = [...products, out];
		}
		const outId = out.id;
		const unitCost = Math.round(cost / qty);
		const blended = blendCost(out.qty, out.cost, qty, unitCost);
		products = products.map((p) => {
			const need = needs.find((n) => n.p.id === p.id);
			if (need) return {
				...p,
				qty: p.qty - need.need
			};
			if (p.id === outId) return {
				...p,
				qty: p.qty + qty,
				cost: blended
			};
			return p;
		});
		const moves = [...needs.map((n) => ({
			id: nid("m"),
			date: TODAY,
			productId: n.p.id,
			qty: -n.need,
			cost: n.p.cost,
			ref: recipe.id,
			kind: "consume"
		})), {
			id: nid("m"),
			date: TODAY,
			productId: outId,
			qty,
			cost: unitCost,
			ref: recipe.id,
			kind: "produce"
		}];
		const moved = pushEntry(s, {
			date: TODAY,
			desc: "تولید " + recipe.name,
			source: "production",
			lines: [{
				accountCode: "1300",
				debit: cost,
				credit: 0,
				desc: "کالای ساخته‌شده"
			}, {
				accountCode: "1300",
				debit: 0,
				credit: cost,
				desc: "مصرف مواد"
			}]
		});
		set({
			products,
			moves: [...s.moves, ...moves],
			entries: moved.entries,
			seq: moved.seq
		});
		return {
			ok: true,
			message: "تولید ثبت شد. ارزش موجودی جابه‌جا شد و تراز دست نخورد."
		};
	},
	postManual: (input) => {
		const s = get();
		const lines = input.lines.map((l) => ({
			accountCode: l.accountCode,
			debit: Math.round(l.debit || 0),
			credit: Math.round(l.credit || 0),
			desc: input.desc.trim() || "سند دستی"
		})).filter((l) => l.debit > 0 || l.credit > 0);
		if (lines.length < 2) return {
			ok: false,
			message: "حداقل دو ردیف برای سند لازم است."
		};
		if (lines.some((l) => l.debit > 0 && l.credit > 0)) return {
			ok: false,
			message: "در هر ردیف فقط بدهکار یا بستانکار را پر کنید."
		};
		if (!balanced(lines)) return {
			ok: false,
			message: "جمع بدهکار و بستانکار برابر نیست."
		};
		const moved = pushEntry(s, {
			date: input.date,
			desc: input.desc.trim() || "سند دستی",
			source: "manual",
			lines
		});
		set({
			entries: moved.entries,
			seq: moved.seq
		});
		return {
			ok: true,
			message: "سند دستی در دفتر روزنامه نشست."
		};
	},
	importCsv: (text) => get().importRows(parseCsv(text)),
	importRows: (rows) => {
		if (rows.length < 2) return {
			ok: false,
			message: "فایل خالی است یا سطر عنوان ندارد."
		};
		const head = rows[0].map((c) => c.replace(/\s/g, "").toLowerCase());
		const idx = (names) => head.findIndex((h) => names.some((n) => h.includes(n)));
		const iName = idx([
			"نام",
			"name",
			"شرح",
			"کالا"
		]);
		const iQty = idx([
			"موجود",
			"تعداد",
			"qty"
		]);
		const iPrice = idx([
			"قیمت",
			"فروش",
			"price"
		]);
		const iCost = idx([
			"بها",
			"تمام",
			"cost",
			"خرید"
		]);
		const iGroup = idx(["گروه", "group"]);
		const iBarcode = idx([
			"بارکد",
			"barcode",
			"کد"
		]);
		const iUnit = idx(["واحد", "unit"]);
		const iMin = idx(["حداقل", "min"]);
		if (iName < 0) return {
			ok: false,
			message: "ستون «نام» در فایل پیدا نشد."
		};
		const s = get();
		let products = s.products.slice();
		let added = 0;
		let value = 0;
		const newMoves = [];
		for (const row of rows.slice(1)) {
			const name = (row[iName] ?? "").trim();
			if (!name || products.some((p) => p.name === name)) continue;
			const qty = Math.round(Number(String(row[iQty] ?? "0").replace(/[^\d.-]/g, "")) || 0);
			const price = Math.round(Number(String(row[iPrice] ?? "0").replace(/[^\d.-]/g, "")) || 0);
			const cost = (iCost >= 0 ? Math.round(Number(String(row[iCost] ?? "0").replace(/[^\d.-]/g, "")) || 0) : 0) || Math.round(price * .7) || 1e3;
			const product = {
				id: nid("p"),
				name,
				barcode: (iBarcode >= 0 ? row[iBarcode] : "") || "626" + String(8e5 + added),
				group: (iGroup >= 0 ? row[iGroup] : "") || "سایر",
				unit: (iUnit >= 0 ? row[iUnit] : "") || "عدد",
				icon: "package",
				qty: Math.max(0, qty),
				price: price || cost,
				cost,
				minQty: iMin >= 0 ? Math.round(Number(row[iMin]) || 0) : 5
			};
			products = [...products, product];
			if (product.qty > 0) {
				value += product.qty * product.cost;
				newMoves.push({
					id: nid("m"),
					date: TODAY,
					productId: product.id,
					qty: product.qty,
					cost: product.cost,
					ref: "import",
					kind: "opening"
				});
			}
			added += 1;
		}
		if (!added) return {
			ok: false,
			message: "کالای جدیدی در فایل نبود."
		};
		let entries = s.entries;
		let seq = s.seq;
		if (value > 0) {
			const moved = pushEntry({
				...s,
				seq
			}, {
				date: TODAY,
				desc: "ورود موجودی از اکسل",
				source: "adjust",
				lines: [{
					accountCode: "1300",
					debit: value,
					credit: 0,
					desc: "کالاهای فایل"
				}, {
					accountCode: "3100",
					debit: 0,
					credit: value,
					desc: "از محل سرمایه"
				}]
			});
			entries = moved.entries;
			seq = moved.seq;
		}
		set({
			products,
			entries,
			moves: [...s.moves, ...newMoves],
			seq
		});
		return {
			ok: true,
			message: `${added} کالا از فایل وارد شد.`
		};
	},
	loadTraining: () => {
		const s = get();
		const extras = trainingProducts().filter((p) => !s.products.some((x) => x.name === p.name));
		if (!extras.length) return {
			ok: false,
			message: "فایل آموزشی قبلاً وارد شده است."
		};
		const value = extras.reduce((sum, p) => sum + p.qty * p.cost, 0);
		const moved = pushEntry(s, {
			date: TODAY,
			desc: "ورود فایل آموزشی کالا",
			source: "adjust",
			lines: [{
				accountCode: "1300",
				debit: value,
				credit: 0,
				desc: "کالاهای آموزشی"
			}, {
				accountCode: "3100",
				debit: 0,
				credit: value,
				desc: "از محل سرمایه"
			}]
		});
		const moves = extras.map((p) => ({
			id: nid("m"),
			date: TODAY,
			productId: p.id,
			qty: p.qty,
			cost: p.cost,
			ref: "training",
			kind: "opening"
		}));
		set({
			products: [...s.products, ...extras],
			entries: moved.entries,
			seq: moved.seq,
			moves: [...s.moves, ...moves]
		});
		return {
			ok: true,
			message: `فایل آموزشی خوانده شد: ${s.products.length + extras.length} کالا و ${s.parties.length} مشتری.`
		};
	},
	updateSettings: (patch) => set({ settings: {
		...get().settings,
		...patch
	} }),
	resetDemo: () => {
		set({
			...buildSeed(),
			invoices: [],
			view: "home",
			draft: emptyDraft(),
			focusInvoiceId: null
		});
	}
}), {
	name: "kaseba-ledger-v1",
	partialize: (s) => ({
		settings: s.settings,
		products: s.products,
		parties: s.parties,
		entries: s.entries,
		moves: s.moves,
		invoices: s.invoices,
		assets: s.assets,
		seq: s.seq
	}),
	merge: (persisted, current) => {
		if (!persisted || typeof persisted !== "object") return current;
		const p = persisted;
		if (!Array.isArray(p.products) || !Array.isArray(p.entries) || !p.settings || !p.seq) return current;
		return {
			...current,
			...p,
			view: "home",
			draft: emptyDraft(),
			focusInvoiceId: null
		};
	}
}));
function parseCsv(text) {
	const rows = [];
	let row = [];
	let cell = "";
	let quoted = false;
	const src = text.replace(/^\uFEFF/, "");
	for (let i = 0; i < src.length; i++) {
		const ch = src[i];
		if (quoted) {
			if (ch === "\"") {
				if (src[i + 1] === "\"") {
					cell += "\"";
					i += 1;
				} else quoted = false;
			} else cell += ch;
		} else if (ch === "\"") quoted = true;
		else if (ch === "," || ch === ";" || ch === "	") {
			row.push(cell.trim());
			cell = "";
		} else if (ch === "\n") {
			row.push(cell.trim());
			rows.push(row);
			row = [];
			cell = "";
		} else if (ch !== "\r") cell += ch;
	}
	if (cell.length || row.length) {
		row.push(cell.trim());
		rows.push(row);
	}
	return rows.filter((r) => r.some((c) => c));
}
function productsCsv(products) {
	const head = [
		"نام",
		"بارکد",
		"گروه",
		"واحد",
		"موجودی",
		"قیمت",
		"بهای تمام‌شده",
		"حداقل"
	];
	const lines = products.map((p) => [
		p.name,
		p.barcode,
		p.group,
		p.unit,
		p.qty,
		p.price,
		p.cost,
		p.minQty
	].join(","));
	return "﻿" + [head.join(","), ...lines].join("\n");
}
async function rowsFromFile(file) {
	const lower = file.name.toLowerCase();
	if (lower.endsWith(".xlsx") || lower.endsWith(".xls")) {
		const XLSX = await import("../_libs/xlsx.mjs").then((n) => n.t);
		const data = new Uint8Array(await file.arrayBuffer());
		const book = XLSX.read(data, { type: "array" });
		const sheet = book.Sheets[book.SheetNames[0]];
		if (!sheet) return [];
		return XLSX.utils.sheet_to_json(sheet, {
			header: 1,
			raw: false,
			defval: ""
		}).map((row) => (Array.isArray(row) ? row : []).map((cell) => String(cell ?? "").trim())).filter((row) => row.some((cell) => cell));
	}
	return parseCsv(await file.text());
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var nf = new Intl.NumberFormat("fa-IR");
function toman(n) {
	const v = Math.round(n || 0);
	return (v < 0 ? "−" : "") + nf.format(Math.abs(v));
}
function maskPhone(phone) {
	const d = phone.replace(/\s/g, "");
	if (d.length < 8) return d;
	return d.slice(0, 4) + "••••" + d.slice(-2);
}
var NUMS = {
	یک: 1,
	یه: 1,
	دو: 2,
	سه: 3,
	چهار: 4,
	پنج: 5,
	شش: 6,
	هفت: 7,
	هشت: 8,
	نه: 9,
	ده: 10,
	یازده: 11,
	دوازده: 12
};
var CLASSIFIERS = /* @__PURE__ */ new Set([
	"تا",
	"عدد",
	"دونه",
	"دانه",
	"عددِ"
]);
function normFa(input) {
	return input.replace(/[يی]/g, "ی").replace(/ك/g, "ک").replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function bestByName(query, list) {
	const q = normFa(query);
	if (!q) return null;
	let best = null;
	let score = 0;
	for (const item of list) {
		const n = normFa(item.name);
		let s = 0;
		if (n.includes(q) || q.includes(n)) s = Math.min(n.length, q.length) + 2;
		const hit = q.split(" ").filter((w) => w.length > 1).filter((w) => n.includes(w)).length;
		if (hit > 0) s = Math.max(s, hit);
		if (s > score) {
			score = s;
			best = item;
		}
	}
	return score > 0 ? best : null;
}
function parseCommand(raw, products, parties) {
	const t = normFa(raw);
	let intent = "unknown";
	if (/(موجودی|چند تا دارم|چقدر دارم)/.test(t)) intent = "stock";
	else if (t.includes("خرید")) intent = "purchase";
	else if (/(فروش|فاکتور)/.test(t)) intent = "sale";
	let rest = t.replace(/پیش فاکتور|فاکتور|فروش|خرید|موجودی|چند تا دارم|چقدر دارم/g, " ").replace(/\s+/g, " ").trim();
	let party = null;
	const sorted = [...parties].sort((a, b) => b.name.length - a.name.length);
	for (const p of sorted) {
		const pn = normFa(p.name);
		if (pn && rest.includes(pn)) {
			party = p;
			rest = rest.replace(pn, " ");
			break;
		}
	}
	if (!party) for (const p of sorted) {
		const last = normFa(p.name).split(" ").pop() ?? "";
		if (last.length >= 3 && rest.includes(last)) {
			party = p;
			rest = rest.replace(last, " ");
			break;
		}
	}
	rest = rest.replace(/\s+/g, " ").trim();
	const tokens = rest.split(" ").filter((tok) => tok && tok !== "به" && tok !== "برای" && tok !== "از" && tok !== "را");
	const items = [];
	let buf = [];
	const flush = (qty) => {
		const query = buf.join(" ").trim();
		buf = [];
		if (query) items.push({
			query,
			qty
		});
	};
	for (let i = 0; i < tokens.length; i++) {
		const tok = tokens[i];
		const n = NUMS[tok] ?? (/^\d+$/.test(tok) ? Number(tok) : null);
		if (n != null) {
			flush(n);
			if (tokens[i + 1] && CLASSIFIERS.has(tokens[i + 1])) i++;
		} else if (!CLASSIFIERS.has(tok)) buf.push(tok);
	}
	if (buf.length && (intent === "stock" || items.length === 0)) items.push({
		query: buf.join(" "),
		qty: 1
	});
	const matched = [];
	for (const it of items) {
		const product = bestByName(it.query, products);
		if (product) matched.push({
			product,
			qty: it.qty
		});
	}
	return {
		intent,
		party,
		items: matched
	};
}
function Card({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-2xl border border-line bg-surface p-4 shadow-sm", className),
		children
	});
}
function Btn({ variant = "primary", className, type = "button", ...props }) {
	const look = {
		primary: "bg-primary text-on-primary",
		ghost: "border border-line bg-surface text-ink",
		navy: "bg-navy text-on-navy",
		good: "bg-good text-on-primary",
		soft: "bg-primary-soft text-primary",
		danger: "bg-bad-soft text-bad"
	}[variant];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition active:scale-[0.98] disabled:opacity-50", look, className),
		...props
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-xs font-medium text-muted",
			children: label
		}), children]
	});
}
var inputClass = "h-11 w-full rounded-xl border border-line bg-canvas px-3 text-sm text-ink outline-none focus:border-primary";
function Chips({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-2 overflow-x-auto pb-1",
		children: options.map((o) => {
			const on = value === o.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(o.id),
				className: cn("h-9 shrink-0 rounded-full px-3 text-xs font-semibold", on ? "border border-line bg-surface text-ink shadow-sm" : "text-muted"),
				children: o.label
			}, o.id);
		})
	});
}
function Sheet({ open, title, onClose, children }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center md:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-navy/45",
			"aria-label": "بستن",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			className: "relative max-h-[85dvh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-surface p-4 pb-8 shadow-xl md:rounded-3xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-extrabold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "grid size-10 place-items-center rounded-full bg-canvas text-sm text-muted",
					children: "بستن"
				})]
			}), children]
		})]
	});
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid size-10 place-items-center rounded-xl bg-navy text-base font-extrabold text-white ring-1 ring-gold", className),
		children: "ک"
	});
}
function getRecognizer() {
	const w = window;
	const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
	if (!Ctor) return null;
	const rec = new Ctor();
	rec.lang = "fa-IR";
	rec.continuous = true;
	rec.interimResults = true;
	return rec;
}
var SAMPLE = "فروش مسواک دو تا لامپ یه دونه به رضا اکبری";
function AssistantView() {
	const products = useLedger((s) => s.products);
	const parties = useLedger((s) => s.parties);
	const applyVoiceLines = useLedger((s) => s.applyVoiceLines);
	const [text, setText] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const [rec, setRec] = (0, import_react.useState)(null);
	const finish = (raw) => {
		const spoken = raw.trim();
		if (!spoken) {
			toast.error("چیزی شنیده نشد. عبارت را بنویسید یا نمونه را بزنید.");
			return;
		}
		const parsed = parseCommand(spoken, products.map((p) => ({
			id: p.id,
			name: p.name
		})), parties.map((p) => ({
			id: p.id,
			name: p.name
		})));
		if (parsed.intent === "stock") {
			if (!parsed.items.length) {
				setNote("کالا را در جمله بیاورید. مثلاً: از خودکار آبی چند تا دارم");
				return;
			}
			const lines = parsed.items.map((it) => {
				const p = products.find((x) => x.id === it.product.id);
				return p ? `${p.name}: ${p.qty.toLocaleString("fa-IR")} ${p.unit}، فی ${toman(p.price)}` : it.product.name;
			});
			setNote(lines.join("\n"));
			return;
		}
		if (!parsed.items.length) {
			setNote("کالا را نشناختم. نام را نزدیک موجودی انبار بگویید.");
			return;
		}
		applyVoiceLines(parsed.party?.id ?? null, parsed.items.map((it) => ({
			productId: it.product.id,
			qty: it.qty
		})));
		toast.success(parsed.party ? `فاکتور برای ${parsed.party.name} آماده شد.` : "ردیف‌ها روی فاکتور نشست. مشتری را انتخاب کنید.");
	};
	const toggle = () => {
		if (listening && rec) {
			rec.stop();
			setListening(false);
			return;
		}
		const next = getRecognizer();
		if (!next) {
			setNote("میکروفون در این مرورگر نیست. عبارت را بنویسید یا نمونه را بزنید.");
			return;
		}
		next.onresult = (ev) => {
			let said = "";
			for (let i = 0; i < ev.results.length; i++) said += ev.results[i][0].transcript + " ";
			setText(said.trim());
		};
		next.onerror = () => {
			setListening(false);
			setNote("دسترسی میکروفون ممکن نشد. می‌توانید تایپ کنید.");
		};
		next.onend = () => setListening(false);
		try {
			next.start();
			setRec(next);
			setListening(true);
		} catch {
			setNote("میکروفون شروع نشد.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-7 text-muted",
				children: "سلام. درباره موجودی بپرسید یا فروش را دیکته کنید. قبل از ثبت، فاکتور را نشان می‌دهم تا خودتان ببندید. مثلاً «فروش … به …» یا «از خودکار آبی چند تا دارم»."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					setText(SAMPLE);
					setNote("");
				},
				className: "rounded-full bg-primary-soft px-3 py-2 text-xs font-bold text-primary",
				children: SAMPLE
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-line bg-surface px-4 py-8 text-center shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: toggle,
						className: `mx-auto grid size-20 place-items-center rounded-full bg-primary text-on-primary ${listening ? "mic-live" : ""}`,
						"aria-label": listening ? "توقف شنیدن" : "شروع شنیدن",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-8" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-extrabold",
						children: listening ? "بگویید، گوش می‌دهم…" : "برای گفتن، دکمه را بزنید"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "mt-4 min-h-24 w-full rounded-2xl border border-line bg-canvas p-3 text-sm outline-none focus:border-primary",
						placeholder: "یا همین‌جا بنویسید",
						value: text,
						onChange: (e) => setText(e.target.value)
					}),
					note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 whitespace-pre-wrap text-sm font-semibold text-ink",
						children: note
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[5rem_1fr] gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => {
						rec?.stop();
						setListening(false);
						setText("");
						setNote("");
					},
					children: "لغو"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => {
						rec?.stop();
						setListening(false);
						finish(text);
					},
					children: "تمام شد"
				})]
			})
		]
	});
}
function BooksView() {
	const entries = useLedger((s) => s.entries);
	const postManual = useLedger((s) => s.postManual);
	const [tab, setTab] = (0, import_react.useState)("journal");
	const [code, setCode] = (0, import_react.useState)("1100");
	const [manual, setManual] = (0, import_react.useState)(false);
	const trial = (0, import_react.useMemo)(() => trialOf(entries), [entries]);
	const ledger = (0, import_react.useMemo)(() => ledgerOf(entries, code), [entries, code]);
	const journal = (0, import_react.useMemo)(() => [...entries].sort((a, b) => b.date.localeCompare(a.date) || b.number.localeCompare(a.number)), [entries]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
				value: tab,
				onChange: (id) => setTab(id),
				options: [
					{
						id: "journal",
						label: "دفتر روزنامه"
					},
					{
						id: "ledger",
						label: "دفتر کل"
					},
					{
						id: "trial",
						label: "تراز آزمایشی"
					}
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("rounded-2xl px-3 py-2 text-sm font-semibold", trial.ok ? "bg-good-soft text-good" : "bg-bad-soft text-bad"),
				children: [
					trial.ok ? "جمع بدهکار و بستانکار برابر است." : "تراز نامتوازن است.",
					" ",
					toman(trial.debit),
					" تومان"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "ghost",
				onClick: () => setManual(true),
				children: "سند دستی"
			}),
			tab === "journal" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: journal.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-surface p-3 shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-start justify-between gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: e.desc
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								"سند ",
								Number(e.number).toLocaleString("fa-IR"),
								" · ",
								SOURCE_LABEL[e.source],
								" · ",
								formatJalali(e.date)
							]
						})] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1 text-xs",
						children: e.lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid grid-cols-[1fr_auto_auto] gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: accountName(l.accountCode) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-20 text-left",
									children: l.debit ? toman(l.debit) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-20 text-left",
									children: l.credit ? toman(l.credit) : "—"
								})
							]
						}, i))
					})]
				}, e.id))
			}),
			tab === "ledger" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-11 w-full rounded-xl border border-line bg-canvas px-3 text-sm text-ink outline-none focus:border-primary",
					value: code,
					onChange: (e) => setCode(e.target.value),
					children: CHART.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: a.code,
						children: [
							a.code,
							" — ",
							a.name
						]
					}, a.code))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-1",
					children: [ledger.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted",
						children: "گردشی برای این حساب نیست."
					}), ledger.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-line bg-surface px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: l.desc
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: formatJalali(l.date)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								"بدهکار ",
								toman(l.debit),
								" · بستانکار ",
								toman(l.credit),
								" · مانده ",
								toman(l.balance)
							]
						})]
					}, l.id))]
				})]
			}),
			tab === "trial" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-2xl border border-line bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[1fr_auto_auto] gap-2 border-b border-line px-3 py-2 text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "حساب" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بدهکار" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بستانکار" })
						]
					}),
					trial.rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[1fr_auto_auto] gap-2 border-b border-line px-3 py-2 text-sm last:border-b-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [r.code, " "]
							}), r.name] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: r.debit ? toman(r.debit) : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: r.credit ? toman(r.credit) : "—"
							})
						]
					}, r.code)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[1fr_auto_auto] gap-2 bg-canvas px-3 py-2 text-sm font-extrabold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "جمع" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: toman(trial.debit) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: toman(trial.credit) })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManualSheet, {
				open: manual,
				onClose: () => setManual(false),
				onPost: (input) => {
					const res = postManual(input);
					if (res.ok) {
						toast.success(res.message);
						setManual(false);
					} else toast.error(res.message);
				}
			})
		]
	});
}
function ManualSheet({ open, onClose, onPost }) {
	const [desc, setDesc] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([{
		accountCode: "5200",
		debit: "",
		credit: ""
	}, {
		accountCode: "1100",
		debit: "",
		credit: ""
	}]);
	const debit = rows.reduce((s, r) => s + (Number(r.debit) || 0), 0);
	const credit = rows.reduce((s, r) => s + (Number(r.credit) || 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		title: "سند دستی",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "شرح",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: desc,
						onChange: (e) => setDesc(e.target.value)
					})
				}),
				rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: inputClass,
							value: r.accountCode,
							onChange: (e) => setRows(rows.map((x, idx) => idx === i ? {
								...x,
								accountCode: e.target.value
							} : x)),
							children: CHART.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: a.code,
								children: a.name
							}, a.code))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							inputMode: "numeric",
							placeholder: "بدهکار",
							value: r.debit,
							onChange: (e) => setRows(rows.map((x, idx) => idx === i ? {
								...x,
								debit: e.target.value.replace(/[^\d]/g, "")
							} : x))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							inputMode: "numeric",
							placeholder: "بستانکار",
							value: r.credit,
							onChange: (e) => setRows(rows.map((x, idx) => idx === i ? {
								...x,
								credit: e.target.value.replace(/[^\d]/g, "")
							} : x))
						})
					]
				}, i)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm font-bold text-primary",
					onClick: () => setRows([...rows, {
						accountCode: "1100",
						debit: "",
						credit: ""
					}]),
					children: "ردیف تازه"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: cn("text-sm font-bold", debit === credit ? "text-good" : "text-bad"),
					children: [
						"بدهکار ",
						toman(debit),
						" · بستانکار ",
						toman(credit)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "w-full",
					onClick: () => onPost({
						date: TODAY,
						desc,
						lines: rows.map((r) => ({
							accountCode: r.accountCode,
							debit: Number(r.debit) || 0,
							credit: Number(r.credit) || 0
						}))
					}),
					children: "ثبت سند"
				})
			]
		})
	});
}
function Dashboard() {
	const products = useLedger((s) => s.products);
	const entries = useLedger((s) => s.entries);
	const invoices = useLedger((s) => s.invoices);
	const settings = useLedger((s) => s.settings);
	const setView = useLedger((s) => s.setView);
	const drafts = invoices.filter((i) => i.status === "draft").length;
	const kpi = (0, import_react.useMemo)(() => kpisOf(entries, products, drafts), [
		entries,
		products,
		drafts
	]);
	const series = (0, import_react.useMemo)(() => salesSeries(entries).map((d) => ({
		label: formatJalaliShort(d.date),
		sales: d.sales
	})), [entries]);
	const recent = [...entries].reverse().slice(0, 5);
	const lows = products.filter((p) => p.qty <= p.minQty);
	const stockBook = (0, import_react.useMemo)(() => trialOf(entries), [entries]).rows.find((r) => r.code === "1300");
	const stockGap = Math.abs((stockBook?.debit ?? 0) - kardexValue(products));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-extrabold leading-tight",
						children: "کاسبا"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: settings.shopName
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-left text-xs font-semibold text-muted",
					children: formatJalali("2026-11-06")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "فروش آبان",
						value: kpi.sales,
						hint: "پس از تخفیف، پیش از مالیات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "خرید آبان",
						value: kpi.purchases,
						hint: "ورود به موجودی"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "سود ناخالص",
						value: kpi.profit,
						hint: "فروش منهای بهای تمام‌شده"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "اسناد ثبت‌شده",
						value: kpi.docs,
						hint: "دفتر روزنامه",
						plain: true
					})
				]
			}),
			(lows.length > 0 || kpi.negative > 0 || !kpi.balanced) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "border-warn/30 bg-warn-soft",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold text-warn",
						children: "نیاز به پیگیری"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 space-y-1 text-sm text-ink",
						children: [
							lows.slice(0, 3).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								p.name,
								": موجودی ",
								p.qty.toLocaleString("fa-IR"),
								"، حداقل ",
								p.minQty.toLocaleString("fa-IR")
							] }, p.id)),
							kpi.negative > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"موجودی منفی در ",
								kpi.negative.toLocaleString("fa-IR"),
								" کالا"
							] }),
							!kpi.balanced && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "تراز آزمایشی نامتوازن است." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 text-sm font-bold text-warn",
						onClick: () => setView("control"),
						children: "کنترل روزانه"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-extrabold",
					children: "روند فروش ۱۴ روز"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: "تومان"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesChart, { data: series })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "صندوق",
						value: toman(kpi.cash),
						onClick: () => setView("treasury")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "بانک",
						value: toman(kpi.bank),
						onClick: () => setView("treasury")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: kpi.balanced ? "تراز متوازن" : "تراز ناقص",
						value: stockGap < 1e3 ? "کاردکس سالم" : "مغایرت کالا",
						onClick: () => setView("books")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-4 pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-extrabold",
						children: "آخرین عملیات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm font-semibold text-primary",
						onClick: () => setView("ops"),
						children: "همه"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: recent.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 border-t border-line px-4 py-3 first:border-t-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-semibold",
							children: e.desc
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								SOURCE_LABEL[e.source],
								" · ",
								formatJalali(e.date)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 text-sm font-bold",
						children: toman(e.lines.reduce((s, l) => s + l.debit, 0))
					})]
				}, e.id)) })]
			})
		]
	});
}
function Kpi({ label, value, hint, plain }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium text-muted",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xl font-extrabold tracking-tight",
			children: plain ? value.toLocaleString("fa-IR") : toman(value)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-muted",
			children: hint
		})
	] });
}
function Mini({ label, value, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "rounded-2xl border border-line bg-surface px-2 py-3 text-center shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 truncate text-xs font-extrabold",
			children: value
		})]
	});
}
function SalesChart({ data }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 rounded-xl bg-canvas" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data,
				margin: {
					top: 8,
					right: 0,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						tick: {
							fontSize: 10,
							fill: "var(--color-muted)"
						},
						axisLine: false,
						tickLine: false,
						interval: 2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						formatter: (v) => [`${toman(Number(v))} تومان`, "فروش"],
						labelFormatter: (l) => String(l),
						contentStyle: {
							borderRadius: 12,
							borderColor: "var(--color-line)",
							fontFamily: "inherit"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "sales",
						stroke: "var(--color-primary)",
						fill: "var(--color-primary-soft)",
						strokeWidth: 2
					})
				]
			})
		})
	});
}
var ICONS = {
	droplets: Droplets,
	leaf: Leaf,
	wheat: Wheat,
	flask: FlaskConical,
	flame: Flame,
	spray: SprayCan,
	layers: Layers,
	candy: Candy,
	pen: PenLine,
	brush: Brush,
	bulb: Lightbulb,
	milk: Milk,
	pasta: Utensils,
	fish: Fish,
	cube: Cuboid,
	spark: Sparkles,
	battery: Battery,
	notebook: Notebook,
	package: Package
};
function ProductGlyph({ icon, className }) {
	const Icon = ICONS[icon] ?? Package;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		strokeWidth: 1.75
	});
}
function GoodsView() {
	const products = useLedger((s) => s.products);
	const moves = useLedger((s) => s.moves);
	const addProduct = useLedger((s) => s.addProduct);
	const updateProduct = useLedger((s) => s.updateProduct);
	const adjustStock = useLedger((s) => s.adjustStock);
	const addLine = useLedger((s) => s.addLine);
	const resetDraft = useLedger((s) => s.resetDraft);
	const setView = useLedger((s) => s.setView);
	const [q, setQ] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(null);
	const [creating, setCreating] = (0, import_react.useState)(false);
	const lastDate = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const m of moves) {
			const prev = map.get(m.productId);
			if (!prev || m.date > prev) map.set(m.productId, m.date);
		}
		return map;
	}, [moves]);
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim();
		let list = products.filter((p) => !query || p.name.includes(query) || p.barcode.includes(query));
		if (filter === "low") list = list.filter((p) => p.qty <= p.minQty);
		if (filter === "stock") list = list.filter((p) => p.qty > 0);
		if (filter === "recent") list = [...list].sort((a, b) => (lastDate.get(b.id) ?? "").localeCompare(lastDate.get(a.id) ?? ""));
		return list;
	}, [
		products,
		q,
		filter,
		lastDate
	]);
	const counts = {
		all: products.length,
		low: products.filter((p) => p.qty <= p.minQty).length,
		stock: products.filter((p) => p.qty > 0).length
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					placeholder: "جستجوی نام یا بارکد…",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "shrink-0 px-3",
					onClick: () => setCreating(true),
					children: "کالای جدید"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
				value: filter,
				onChange: (id) => setFilter(id),
				options: [
					{
						id: "all",
						label: `همه ${counts.all.toLocaleString("fa-IR")}`
					},
					{
						id: "low",
						label: `کم‌موجود ${counts.low.toLocaleString("fa-IR")}`
					},
					{
						id: "stock",
						label: `موجود ${counts.stock.toLocaleString("fa-IR")}`
					},
					{
						id: "recent",
						label: "اخیر"
					}
				]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border border-dashed border-line bg-surface px-4 py-10 text-center text-sm text-muted",
				children: "هنوز کالایی با این مشخصات نیست."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOpen(p),
					className: "flex w-full items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-3 text-right shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-12 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGlyph, {
							icon: p.icon,
							className: "size-6"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate font-semibold",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 block text-xs text-muted",
							children: [
								toman(p.price),
								" تومان · ",
								p.qty.toLocaleString("fa-IR"),
								" ",
								p.unit,
								p.qty <= p.minQty ? " · کم‌موجود" : ""
							]
						})]
					})]
				}) }, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!open,
				title: open?.name ?? "",
				onClose: () => setOpen(null),
				children: open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductSheet, {
					product: products.find((p) => p.id === open.id) ?? open,
					moves,
					onSave: (patch) => {
						updateProduct(open.id, patch);
						toast.success("کالا به‌روز شد.");
					},
					onAdjust: (qty) => {
						const res = adjustStock(open.id, qty);
						if (res.ok) toast.success(res.message);
						else toast.error(res.message);
					},
					onSell: () => {
						resetDraft(null);
						addLine(open.id);
						setOpen(null);
						setView("invoice");
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: creating,
				title: "کالای جدید",
				onClose: () => setCreating(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewProduct, { onCreate: (input) => {
					const res = addProduct(input);
					if (res.ok) {
						toast.success(res.message);
						setCreating(false);
					} else toast.error(res.message);
				} })
			})
		]
	});
}
function ProductSheet({ product, moves, onSave, onAdjust, onSell }) {
	const [price, setPrice] = (0, import_react.useState)(String(product.price));
	const [minQty, setMinQty] = (0, import_react.useState)(String(product.minQty));
	const [counted, setCounted] = (0, import_react.useState)(String(product.qty));
	const kardex = moves.filter((m) => m.productId === product.id).slice(-6).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"گروه ",
					product.group,
					" · بارکد ",
					product.barcode,
					" · بهای میانگین ",
					toman(product.cost),
					" تومان"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "قیمت فروش",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "numeric",
						value: price,
						onChange: (e) => setPrice(e.target.value.replace(/[^\d]/g, ""))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "حداقل موجودی",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "numeric",
						value: minQty,
						onChange: (e) => setMinQty(e.target.value.replace(/[^\d]/g, ""))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "soft",
				className: "w-full",
				onClick: () => onSave({
					price: Number(price) || product.price,
					minQty: Number(minQty) || 0
				}),
				children: "ذخیره قیمت و حداقل"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "موجودی شمارش‌شده",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					inputMode: "numeric",
					value: counted,
					onChange: (e) => setCounted(e.target.value.replace(/[^\d]/g, ""))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "ghost",
				className: "w-full",
				onClick: () => onAdjust(Number(counted) || 0),
				children: "ثبت اصلاح موجودی"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "w-full",
				onClick: onSell,
				children: "فروش این کالا"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-bold text-muted",
				children: "کاردکس اخیر"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 text-sm",
				children: kardex.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between rounded-xl bg-canvas px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatJalali(m.date) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: m.qty < 0 ? "text-bad" : "text-good",
						children: [m.qty > 0 ? "+" : "", m.qty.toLocaleString("fa-IR")]
					})]
				}, m.date + i))
			})] })
		]
	});
}
function NewProduct({ onCreate }) {
	const [name, setName] = (0, import_react.useState)("");
	const [group, setGroup] = (0, import_react.useState)(GROUPS[0]);
	const [price, setPrice] = (0, import_react.useState)("");
	const [cost, setCost] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)("");
	const [barcode, setBarcode] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-3",
		onSubmit: (e) => {
			e.preventDefault();
			onCreate({
				name,
				group,
				unit: "عدد",
				price: Number(price) || 0,
				cost: Number(cost) || 0,
				qty: Number(qty) || 0,
				minQty: 5,
				barcode
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "نام کالا",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "گروه",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: inputClass,
					value: group,
					onChange: (e) => setGroup(e.target.value),
					children: GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: g }, g))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "قیمت فروش",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "numeric",
						value: price,
						onChange: (e) => setPrice(e.target.value.replace(/[^\d]/g, ""))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "بهای خرید",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "numeric",
						value: cost,
						onChange: (e) => setCost(e.target.value.replace(/[^\d]/g, ""))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "موجودی اولیه",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					inputMode: "numeric",
					value: qty,
					onChange: (e) => setQty(e.target.value.replace(/[^\d]/g, ""))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "بارکد",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: barcode,
					onChange: (e) => setBarcode(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "submit",
				className: "w-full",
				children: "ثبت کالا"
			})
		]
	});
}
var METHODS = [
	{
		id: "cash",
		label: "نقدی"
	},
	{
		id: "card",
		label: "کارت"
	},
	{
		id: "cheque",
		label: "چک"
	},
	{
		id: "other",
		label: "سایر"
	}
];
var SETTLEMENTS = [
	{
		id: "full",
		label: "تسویه کامل"
	},
	{
		id: "multi",
		label: "چند روش"
	},
	{
		id: "credit",
		label: "نسیه / قسطی"
	}
];
function InvoiceView() {
	const draft = useLedger((s) => s.draft);
	const products = useLedger((s) => s.products);
	const parties = useLedger((s) => s.parties);
	const settings = useLedger((s) => s.settings);
	const patchDraft = useLedger((s) => s.patchDraft);
	const addLine = useLedger((s) => s.addLine);
	const setLineQty = useLedger((s) => s.setLineQty);
	const postDraft = useLedger((s) => s.postDraft);
	const setView = useLedger((s) => s.setView);
	const [picker, setPicker] = (0, import_react.useState)(null);
	const [terms, setTerms] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const priced = (0, import_react.useMemo)(() => priceDraft(draft, products, settings), [
		draft,
		products,
		settings
	]);
	const party = parties.find((p) => p.id === draft.partyId);
	const found = products.filter((p) => !query.trim() || p.name.includes(query.trim())).slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 pb-36",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 rounded-2xl bg-canvas p-1",
				children: [["proforma", "پیش‌فاکتور"], ["sale", "فاکتور"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patchDraft({ kind: id }),
					className: cn("h-11 rounded-xl text-sm font-bold", draft.kind === id ? "bg-surface text-ink shadow-sm" : "text-muted"),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setPicker("party"),
					className: "rounded-2xl border border-line bg-surface px-3 py-3 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: "مشتری"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block truncate font-bold",
						children: party?.name ?? "انتخاب"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-surface px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: "تاریخ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 flex items-center justify-between font-bold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "روز قبل",
								onClick: () => patchDraft({ date: addDays(draft.date, -1) }),
								children: "‹"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs",
								children: isToday(draft.date) ? `امروز · ${formatJalali(TODAY)}` : formatJalali(draft.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "روز بعد",
								onClick: () => patchDraft({ date: addDays(draft.date, 1) }),
								children: "›"
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						className: "shrink-0",
						onClick: () => setPicker("goods"),
						children: "انتخاب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "soft",
						className: "shrink-0",
						onClick: () => setView("assistant"),
						children: "صدا"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						placeholder: "جستجو یا گفتن نام کالا…",
						value: query,
						onChange: (e) => setQuery(e.target.value)
					})
				]
			}),
			query.trim() && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "overflow-hidden rounded-2xl border border-line bg-surface",
				children: [found.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-2 px-3 py-2 text-right text-sm",
					onClick: () => {
						addLine(p.id);
						setQuery("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGlyph, {
							icon: p.icon,
							className: "size-4 text-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1",
							children: p.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: toman(p.price)
						})
					]
				}) }, p.id)), found.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-3 py-3 text-sm text-muted",
					children: "کالایی پیدا نشد."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-2xl border border-line bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[2rem_1fr_auto_auto] gap-2 border-b border-line px-3 py-2 text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ردیف" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "شرح" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تعداد" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مبلغ" })
						]
					}),
					priced.lines.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-3 py-8 text-center text-sm text-muted",
						children: "کالایی در فاکتور نیست."
					}),
					priced.lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[2rem_1fr_auto] items-center gap-2 border-b border-line px-3 py-3 last:border-b-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: (i + 1).toLocaleString("fa-IR")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold",
									children: line.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: ["فی ", toman(line.price)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-end gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "grid size-8 place-items-center rounded-full bg-canvas",
											onClick: () => setLineQty(line.productId, line.qty - 1),
											"aria-label": "کم کردن",
											children: "−"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-6 text-center font-bold",
											children: line.qty.toLocaleString("fa-IR")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "grid size-8 place-items-center rounded-full bg-canvas",
											onClick: () => setLineQty(line.productId, line.qty + 1),
											"aria-label": "زیاد کردن",
											children: "+"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm font-bold",
									children: toman(line.amount)
								})]
							})
						]
					}, line.productId))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "fixed inset-x-0 bottom-28 z-30 border-t border-line bg-surface/95 px-4 py-3 backdrop-blur md:sticky md:bottom-0 md:rounded-2xl md:border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-lg font-extrabold",
							children: [toman(priced.total), " تومان"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "text-xs font-semibold text-primary",
							onClick: () => setTerms(true),
							children: [
								payLabel(draft),
								priced.discount ? "" : " · بدون تخفیف",
								draft.taxEnabled ? ` · مالیات ${settings.taxRate.toLocaleString("fa-IR")}٪` : " · بدون مالیات"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "good",
						onClick: () => {
							const res = postDraft();
							if (res.ok) {
								toast.success(res.message);
								setView("home");
							} else toast.error(res.message);
						},
						children: "بستن"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: picker === "party",
				title: "انتخاب مشتری",
				onClose: () => setPicker(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mb-2 w-full rounded-xl bg-canvas px-3 py-3 text-right text-sm",
					onClick: () => {
						patchDraft({ partyId: null });
						setPicker(null);
					},
					children: "مشتری متفرقه"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1",
					children: parties.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "w-full rounded-xl px-3 py-3 text-right text-sm font-semibold hover:bg-canvas",
						onClick: () => {
							patchDraft({ partyId: p.id });
							setPicker(null);
						},
						children: p.name
					}) }, p.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: picker === "goods",
				title: "انتخاب کالا",
				onClose: () => setPicker(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1",
					children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center gap-2 rounded-xl px-2 py-2 text-right",
						onClick: () => addLine(p.id),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-9 place-items-center rounded-lg bg-primary-soft text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGlyph, {
									icon: p.icon,
									className: "size-4"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 text-sm font-semibold",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted",
								children: [
									p.qty.toLocaleString("fa-IR"),
									" · ",
									toman(p.price)
								]
							})
						]
					}) }, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: terms,
				title: "شرایط پرداخت، تخفیف و هزینه‌ها",
				onClose: () => setTerms(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "تسویه"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: SETTLEMENTS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => patchDraft({
									settlement: s.id,
									splitCash: s.id === "multi" ? Math.round(priced.total / 2) : draft.splitCash
								}),
								className: cn("h-11 rounded-xl text-xs font-bold", draft.settlement === s.id ? "bg-navy text-on-navy" : "bg-canvas text-ink"),
								children: s.label
							}, s.id))
						}),
						draft.settlement !== "credit" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "روش"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-4 gap-2",
							children: METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => patchDraft({ method: m.id }),
								className: cn("h-11 rounded-xl text-xs font-bold", draft.method === m.id ? "bg-primary text-on-primary" : "bg-canvas"),
								children: m.label
							}, m.id))
						})] }),
						draft.settlement === "multi" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "بخش نقد از جمع",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-11 w-full rounded-xl border border-line bg-canvas px-3 text-sm text-ink outline-none focus:border-primary",
								inputMode: "numeric",
								value: draft.splitCash ? String(draft.splitCash) : "",
								onChange: (e) => patchDraft({ splitCash: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("h-11 rounded-xl text-sm font-bold", draft.discountMode === "amount" ? "bg-primary text-on-primary" : "bg-canvas"),
								onClick: () => patchDraft({ discountMode: "amount" }),
								children: "تخفیف تومان"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("h-11 rounded-xl text-sm font-bold", draft.discountMode === "percent" ? "bg-primary text-on-primary" : "bg-canvas"),
								onClick: () => patchDraft({ discountMode: "percent" }),
								children: "تخفیف درصد"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							inputMode: "numeric",
							placeholder: draft.discountMode === "percent" ? "درصد" : "مبلغ تخفیف",
							value: draft.discountValue ? String(draft.discountValue) : "",
							onChange: (e) => patchDraft({ discountValue: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center justify-between rounded-xl bg-canvas px-3 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"مالیات ",
								settings.taxRate.toLocaleString("fa-IR"),
								"٪"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: draft.taxEnabled,
								onChange: (e) => patchDraft({ taxEnabled: e.target.checked })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold text-muted",
							children: "هزینه‌های جانبی"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "حمل",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										inputMode: "numeric",
										value: draft.shipping || "",
										onChange: (e) => patchDraft({ shipping: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "بسته‌بندی",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										inputMode: "numeric",
										value: draft.packing || "",
										onChange: (e) => patchDraft({ packing: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "سایر",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										inputMode: "numeric",
										value: draft.otherCost || "",
										onChange: (e) => patchDraft({ otherCost: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-bold",
							children: [
								"قابل پرداخت ",
								toman(priced.total),
								" تومان"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							className: "w-full",
							onClick: () => setTerms(false),
							children: "تأیید"
						})
					]
				})
			})
		]
	});
}
var LINKS = [
	{
		view: "parties",
		title: "مشتری‌ها و فروشنده‌ها",
		hint: "بدهکار، بستانکار، تراز اشخاص",
		icon: Users
	},
	{
		view: "ops",
		title: "عملیات روزانه",
		hint: "همه سندهایی که به دفتر نشسته‌اند",
		icon: ClipboardList
	},
	{
		view: "books",
		title: "دفاتر",
		hint: "روزنامه، کل، تراز آزمایشی",
		icon: BookOpen
	},
	{
		view: "purchase",
		title: "خرید کالا",
		hint: "ورود موجودی و بهای میانگین",
		icon: ShoppingBag
	},
	{
		view: "excel",
		title: "اکسل",
		hint: "خروج و ورود کالا با فایل",
		icon: FileSpreadsheet
	},
	{
		view: "treasury",
		title: "خزانه‌داری",
		hint: "صندوق، بانک، دریافت و هزینه",
		icon: Landmark
	},
	{
		view: "assets",
		title: "دارایی و استهلاک",
		hint: "ثبت استهلاک ماه",
		icon: Warehouse
	},
	{
		view: "production",
		title: "تولید",
		hint: "مصرف مواد و ساخت پک",
		icon: Boxes
	},
	{
		view: "control",
		title: "کنترل روزانه",
		hint: "موجودی منفی، کاردکس، تراز",
		icon: ListChecks
	},
	{
		view: "settings",
		title: "تنظیمات فروشگاه",
		hint: "نام، مالیات، بازنشانی",
		icon: Settings
	}
];
function MoreMenu() {
	const setView = useLedger((s) => s.setView);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		children: LINKS.map((item) => {
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setView(item.view),
				className: "flex items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-3 text-right shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-11 place-items-center rounded-xl bg-primary-soft text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-bold",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted",
					children: item.hint
				})] })]
			}, item.view);
		})
	});
}
function OpsView() {
	const entries = useLedger((s) => s.entries);
	const [src, setSrc] = (0, import_react.useState)("all");
	const list = [...entries].filter((e) => src === "all" || e.source === src).sort((a, b) => b.date.localeCompare(a.date));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2 overflow-x-auto",
			children: [
				"all",
				"sale",
				"purchase",
				"receipt",
				"payment",
				"expense",
				"production",
				"opening"
			].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setSrc(id),
				className: `h-9 shrink-0 rounded-full px-3 text-xs font-bold ${src === id ? "bg-navy text-on-navy" : "bg-surface text-muted"}`,
				children: id === "all" ? "همه" : SOURCE_LABEL[id]
			}, id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: list.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-2xl border border-line bg-surface px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: e.desc
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							SOURCE_LABEL[e.source],
							" · ",
							formatJalali(e.date),
							" · تأییدشده"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-extrabold",
						children: toman(e.lines.reduce((s, l) => s + l.debit, 0))
					})]
				})
			}, e.id))
		})]
	});
}
function ExcelView() {
	const products = useLedger((s) => s.products);
	const parties = useLedger((s) => s.parties);
	const importRows = useLedger((s) => s.importRows);
	const loadTraining = useLedger((s) => s.loadTraining);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [fileName, setFileName] = (0, import_react.useState)("");
	const names = preview ? preview.slice(1, 6).map((row) => row[0]).filter(Boolean) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-extrabold",
				children: "خروج به اکسل"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "کالا و طرف‌حساب در فایل CSV که اکسل باز می‌کند. همان ستون‌ها را برای ورود دوباره بگذارید."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => download("kaseba-goods.csv", productsCsv(products)),
					children: "فایل کالا"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "soft",
					onClick: () => download("kaseba-parties.csv", partiesCsv(parties)),
					children: "فایل اشخاص"
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-extrabold",
				children: "ورود از اکسل"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-6 text-muted",
				children: "فایل xlsx یا csv. ستون‌ها: نام، بارکد، گروه، واحد، موجودی، قیمت، بهای تمام‌شده، حداقل. کالای هم‌نام دوباره ساخته نمی‌شود و موجودی تازه با سند سرمایه می‌نشیند."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 flex h-12 cursor-pointer items-center justify-center rounded-xl bg-primary text-sm font-bold text-on-primary",
				children: ["انتخاب فایل اکسل", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: ".csv,.txt,.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
					className: "sr-only",
					onChange: async (e) => {
						const file = e.target.files?.[0];
						e.target.value = "";
						if (!file) return;
						try {
							const rows = await rowsFromFile(file);
							if (rows.length < 2) {
								toast.error("فایل خالی است یا سطر عنوان ندارد.");
								return;
							}
							setPreview(rows);
							setFileName(file.name);
						} catch {
							toast.error("خواندن فایل ممکن نشد. csv یا xlsx بدهید.");
						}
					}
				})]
			}),
			preview && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-xl bg-canvas p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: fileName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-muted",
						children: [(preview.length - 1).toLocaleString("fa-IR"), " ردیف داده"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1",
						children: names.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: name }, name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => {
								const res = importRows(preview);
								if (res.ok) {
									toast.success(res.message);
									setPreview(null);
								} else toast.error(res.message);
							},
							children: "تأیید ورود"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => setPreview(null),
							children: "انصراف"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 w-full text-center text-sm font-semibold text-primary",
				onClick: () => {
					const res = loadTraining();
					if (res.ok) toast.success(res.message);
					else toast.error(res.message);
				},
				children: "دریافت فایل نمونه آموزشی"
			})
		] })]
	});
}
function partiesCsv(parties) {
	return "﻿" + ["نام,موبایل", ...parties.map((p) => `${p.name},${p.phone}`)].join("\n");
}
function download(name, text) {
	const blob = new Blob([text], { type: "text/csv;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	a.click();
	URL.revokeObjectURL(url);
	toast.success("فایل آماده دانلود است.");
}
function PurchaseView() {
	const products = useLedger((s) => s.products);
	const parties = useLedger((s) => s.parties);
	const taxRate = useLedger((s) => s.settings.taxRate);
	const postPurchase = useLedger((s) => s.postPurchase);
	const [productId, setProductId] = (0, import_react.useState)(products[0]?.id ?? "");
	const [partyId, setPartyId] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)("1");
	const [cost, setCost] = (0, import_react.useState)("");
	const [pay, setPay] = (0, import_react.useState)("cash");
	const [taxed, setTaxed] = (0, import_react.useState)(true);
	const [lines, setLines] = (0, import_react.useState)([]);
	const net = lines.reduce((s, l) => s + l.qty * l.cost, 0);
	const tax = taxed ? Math.round(net * taxRate / 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3",
			onSubmit: (e) => {
				e.preventDefault();
				const product = products.find((p) => p.id === productId);
				const q = Number(qty) || 0;
				const c = Number(cost) || 0;
				if (!product || q <= 0 || c <= 0) {
					toast.error("کالا، تعداد و بهای واحد را کامل کنید.");
					return;
				}
				setLines((prev) => {
					const hit = prev.find((l) => l.productId === product.id && l.cost === c);
					if (hit) return prev.map((l) => l === hit ? {
						...l,
						qty: l.qty + q
					} : l);
					return [...prev, {
						productId: product.id,
						qty: q,
						cost: c
					}];
				});
				setQty("1");
				setCost("");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "کالا",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: inputClass,
						value: productId,
						onChange: (e) => setProductId(e.target.value),
						children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: p.id,
							children: [
								p.name,
								" — موجودی ",
								p.qty.toLocaleString("fa-IR")
							]
						}, p.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تعداد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							inputMode: "numeric",
							value: qty,
							onChange: (e) => setQty(e.target.value.replace(/[^\d]/g, ""))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "بهای واحد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							inputMode: "numeric",
							placeholder: "ریال",
							value: cost,
							onChange: (e) => setCost(e.target.value.replace(/[^\d]/g, ""))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					variant: "soft",
					className: "w-full",
					children: "افزودن به فاکتور خرید"
				})
			]
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-3",
			children: [
				lines.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "هنوز ردیفی نیست."
				}),
				lines.map((line, index) => {
					const product = products.find((p) => p.id === line.productId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: product?.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted",
							children: [
								line.qty.toLocaleString("fa-IR"),
								" × ",
								toman(line.cost)
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-bad",
							onClick: () => setLines((prev) => prev.filter((_, i) => i !== index)),
							children: "حذف"
						})]
					}, `${line.productId}-${index}`);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "فروشنده",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: inputClass,
						value: partyId,
						onChange: (e) => setPartyId(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "بدون شخص"
						}), parties.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.id,
							children: p.name
						}, p.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						["cash", "صندوق"],
						["bank", "بانک"],
						["credit", "نسیه"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPay(id),
						className: `h-10 rounded-xl text-sm font-bold ${pay === id ? "bg-navy text-on-navy" : "bg-canvas text-muted"}`,
						children: label
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مالیات خرید محاسبه شود" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: taxed,
						onChange: (e) => setTaxed(e.target.checked)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "جمع کالا"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: toman(net) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "مالیات"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: toman(tax) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between font-extrabold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "قابل پرداخت" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: toman(net + tax) })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "w-full",
					disabled: !lines.length,
					onClick: () => {
						const res = postPurchase({
							date: TODAY,
							partyId: partyId || null,
							lines,
							taxed,
							pay
						});
						if (res.ok) {
							toast.success(res.message);
							setLines([]);
						} else toast.error(res.message);
					},
					children: "ثبت خرید و صدور سند"
				})
			]
		})]
	});
}
function TreasuryView() {
	const entries = useLedger((s) => s.entries);
	const parties = useLedger((s) => s.parties);
	const postReceipt = useLedger((s) => s.postReceipt);
	const postPayment = useLedger((s) => s.postPayment);
	const postExpense = useLedger((s) => s.postExpense);
	const postTransfer = useLedger((s) => s.postTransfer);
	const rows = (0, import_react.useMemo)(() => partyRows(entries, parties), [entries, parties]);
	const cash = accountBalance(entries, "1100").natural;
	const bank = accountBalance(entries, "1110").natural;
	const [partyId, setPartyId] = (0, import_react.useState)(parties[0]?.id ?? "");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [desc, setDesc] = (0, import_react.useState)("");
	const [viaBank, setViaBank] = (0, import_react.useState)(false);
	const n = Number(amount) || 0;
	const party = rows.find((p) => p.id === partyId);
	const recent = [...entries].filter((e) => e.source === "receipt" || e.source === "payment" || e.source === "expense" || e.source === "transfer").slice(-4).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "صندوق"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-lg font-extrabold",
					children: toman(cash)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "بانک"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-lg font-extrabold",
					children: toman(bank)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-extrabold",
						children: "دریافت و پرداخت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: inputClass,
						value: partyId,
						onChange: (e) => setPartyId(e.target.value),
						children: rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: p.id,
							children: [
								p.name,
								" — ",
								p.label
							]
						}, p.id))
					}),
					party && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"مانده ",
							party.name,
							": ",
							toman(Math.abs(party.net)),
							" · ",
							party.label
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "numeric",
						placeholder: "مبلغ ریال",
						value: amount,
						onChange: (e) => setAmount(e.target.value.replace(/[^\d]/g, ""))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setViaBank(false),
							className: `h-10 rounded-xl text-sm font-bold ${viaBank ? "bg-canvas text-muted" : "bg-navy text-on-navy"}`,
							children: "صندوق"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setViaBank(true),
							className: `h-10 rounded-xl text-sm font-bold ${viaBank ? "bg-navy text-on-navy" : "bg-canvas text-muted"}`,
							children: "بانک"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => {
								toastMsg(postReceipt({
									date: TODAY,
									partyId,
									amount: n,
									toBank: viaBank
								}));
								setAmount("");
							},
							children: "دریافت"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => {
								toastMsg(postPayment({
									date: TODAY,
									partyId,
									amount: n,
									fromBank: viaBank
								}));
								setAmount("");
							},
							children: "پرداخت"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-6 text-muted",
						children: "دریافت، حساب دریافتنی را کم می‌کند. پرداخت، حساب پرداختنی را تسویه می‌کند."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-extrabold",
						children: "هزینه و انتقال"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						placeholder: "شرح هزینه",
						value: desc,
						onChange: (e) => setDesc(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
						variant: "soft",
						className: "w-full",
						onClick: () => toastMsg(postExpense({
							date: TODAY,
							amount: n,
							desc,
							fromBank: viaBank
						})),
						children: ["ثبت هزینه از ", viaBank ? "بانک" : "صندوق"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "navy",
							onClick: () => toastMsg(postTransfer({
								date: TODAY,
								amount: n,
								toBank: true
							})),
							children: "صندوق به بانک"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => toastMsg(postTransfer({
								date: TODAY,
								amount: n,
								toBank: false
							})),
							children: "بانک به صندوق"
						})]
					})
				]
			}),
			recent.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-extrabold",
				children: "آخرین اسناد خزانه"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-2 text-sm",
				children: recent.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.desc }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold",
						children: toman(e.lines.reduce((s, l) => s + l.debit, 0))
					})]
				}, e.id))
			})] })
		]
	});
}
function AssetsView() {
	const assets = useLedger((s) => s.assets);
	const postDepreciation = useLedger((s) => s.postDepreciation);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: assets.map((a) => {
			const monthly = Math.round(a.cost / a.months);
			const remain = a.cost - a.accumulated;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-extrabold",
					children: a.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"بها ",
						toman(a.cost),
						" · انباشته ",
						toman(a.accumulated),
						" · مانده ",
						toman(remain)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						"استهلاک ماهانه ",
						toman(monthly),
						" · تحصیل ",
						formatJalali(a.acquired)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "mt-3 w-full",
					variant: "ghost",
					onClick: () => toastMsg(postDepreciation(a.id)),
					children: "ثبت استهلاک این ماه"
				})
			] }) }, a.id);
		})
	});
}
function ProductionView() {
	const products = useLedger((s) => s.products);
	const postProduction = useLedger((s) => s.postProduction);
	const [qty, setQty] = (0, import_react.useState)({});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-extrabold",
			children: "بهای تمام‌شده تولید"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm leading-6 text-muted",
			children: "مواد از انبار کم می‌شود و محصول ساخته‌شده با میانگین بهای مواد وارد موجودی می‌شود. سند، ارزش موجودی را جابه‌جا می‌کند و تراز را به هم نمی‌زند. بهای فروش جدا از بهای ساخت است."
		})] }), RECIPES.map((recipe) => {
			const count = Number(qty[recipe.id] || "1") || 0;
			const parts = recipe.inputs.map((inp) => {
				const have = products.find((p) => p.name === inp.name);
				const need = inp.qty * count;
				return {
					inp,
					have,
					need,
					cost: (have?.cost ?? 0) * need
				};
			});
			const material = parts.reduce((s, p) => s + p.cost, 0);
			const unit = count > 0 ? Math.round(material / count) : 0;
			const short = parts.some((p) => !p.have || p.have.qty < p.need);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-extrabold",
						children: recipe.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold",
						children: toman(recipe.price)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-1 text-sm text-muted",
					children: parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						part.inp.name,
						" × ",
						part.need.toLocaleString("fa-IR"),
						" — موجودی ",
						part.have ? part.have.qty.toLocaleString("fa-IR") : "ندارد",
						" — ",
						toman(part.cost)
					] }, part.inp.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["بهای واحد ساخت", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-extrabold",
						children: toman(unit)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["حاشیه نسبت به فروش", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-extrabold",
						children: toman(recipe.price - unit)
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "numeric",
						value: qty[recipe.id] ?? "1",
						onChange: (e) => setQty((prev) => ({
							...prev,
							[recipe.id]: e.target.value.replace(/[^\d]/g, "")
						}))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "shrink-0",
						disabled: short || count <= 0,
						onClick: () => toastMsg(postProduction(recipe.id, count)),
						children: "تولید"
					})]
				})
			] }, recipe.id);
		})]
	});
}
function ControlView() {
	const products = useLedger((s) => s.products);
	const moves = useLedger((s) => s.moves);
	const entries = useLedger((s) => s.entries);
	const invoices = useLedger((s) => s.invoices);
	const trial = (0, import_react.useMemo)(() => trialOf(entries), [entries]);
	const kpi = (0, import_react.useMemo)(() => kpisOf(entries, products, invoices.filter((i) => i.status === "draft").length), [
		entries,
		products,
		invoices
	]);
	const mismatches = products.filter((p) => moveQty(moves, p.id) !== p.qty);
	const book = trial.rows.find((r) => r.code === "1300")?.debit ?? 0;
	const kardex = kardexValue(products);
	const gap = Math.abs(book - kardex);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-extrabold",
				children: trial.ok ? "تراز سند دوبل متوازن است" : "تراز نامتوازن است"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"پیش‌نویس ",
					kpi.drafts.toLocaleString("fa-IR"),
					" · کالای زیر حداقل ",
					kpi.low.toLocaleString("fa-IR"),
					" · موجودی منفی ",
					kpi.negative.toLocaleString("fa-IR")
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-extrabold",
					children: gap < 1e3 ? "کاردکس با حساب موجودی هم‌خوان است" : "مغایرت ارزش موجودی"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"دفتر ",
						toman(book),
						" · کاردکس ",
						toman(kardex),
						gap >= 1e3 ? ` · اختلاف ${toman(gap)}` : gap > 0 ? ` · اختلاف گرد کردن ${toman(gap)}` : ""
					]
				}),
				mismatches.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 text-sm text-bad",
					children: mismatches.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						p.name,
						": کارت ",
						moveQty(moves, p.id).toLocaleString("fa-IR"),
						" / کارتکس کالا ",
						p.qty.toLocaleString("fa-IR")
					] }, p.id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-extrabold",
				children: "کالاهای کم‌موجود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-2 space-y-1 text-sm",
				children: [products.filter((p) => p.qty <= p.minQty).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-muted",
					children: "موردی نیست."
				}), products.filter((p) => p.qty <= p.minQty).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					p.name,
					" — ",
					p.qty.toLocaleString("fa-IR"),
					" از حداقل ",
					p.minQty.toLocaleString("fa-IR")
				] }, p.id))]
			})] })
		]
	});
}
function SettingsView() {
	const settings = useLedger((s) => s.settings);
	const updateSettings = useLedger((s) => s.updateSettings);
	const resetDemo = useLedger((s) => s.resetDemo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نام فروشگاه",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: settings.shopName,
						onChange: (e) => updateSettings({ shopName: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "تلفن",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: settings.phone,
						onChange: (e) => updateSettings({ phone: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نشانی",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: settings.address,
						onChange: (e) => updateSettings({ address: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "کد اقتصادی",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: settings.economicCode,
						onChange: (e) => updateSettings({ economicCode: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نرخ مالیات درصد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "numeric",
						value: String(settings.taxRate),
						onChange: (e) => updateSettings({ taxRate: Number(e.target.value.replace(/[^\d]/g, "")) || 0 })
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-7 text-muted",
			children: "فقط عملیات تأییدشده به دفتر روزنامه می‌رود. پیش‌فاکتور سند نمی‌سازد. فروش، هم‌زمان دریافتنی یا صندوق، فروش، مالیات، بهای تمام‌شده و خروج موجودی را ثبت می‌کند."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			variant: "danger",
			className: "mt-3 w-full",
			onClick: () => {
				resetDemo();
				toast.success("داده نمونه از نو بارگذاری شد.");
			},
			children: "بازنشانی داده نمونه"
		})] })]
	});
}
function toastMsg(res) {
	if (res.ok) toast.success(res.message);
	else toast.error(res.message);
}
function PartiesView() {
	const parties = useLedger((s) => s.parties);
	const entries = useLedger((s) => s.entries);
	const addParty = useLedger((s) => s.addParty);
	const resetDraft = useLedger((s) => s.resetDraft);
	const setView = useLedger((s) => s.setView);
	const [q, setQ] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [creating, setCreating] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => partyRows(entries, parties), [entries, parties]);
	const summary = (0, import_react.useMemo)(() => partySummary(rows), [rows]);
	const shown = rows.filter((r) => {
		if (q && !r.name.includes(q.trim()) && !r.phone.includes(q.trim())) return false;
		if (filter === "debtor") return r.net > 0;
		if (filter === "creditor") return r.net < 0;
		return true;
	});
	const debtorCount = rows.filter((r) => r.net > 0).length;
	const creditorCount = rows.filter((r) => r.net < 0).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "تراز",
						value: summary.balance,
						tone: "bad"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "بستانکاران",
						value: summary.creditors,
						tone: "navy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "بدهکاران",
						value: summary.debtors,
						tone: "warn"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					placeholder: "نام یا شماره…",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "shrink-0 px-3",
					onClick: () => setCreating(true),
					children: "شخص جدید"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
				value: filter,
				onChange: (id) => setFilter(id),
				options: [
					{
						id: "all",
						label: `همه ${rows.length.toLocaleString("fa-IR")}`
					},
					{
						id: "creditor",
						label: `بستانکار ${creditorCount.toLocaleString("fa-IR")}`
					},
					{
						id: "debtor",
						label: `بدهکار ${debtorCount.toLocaleString("fa-IR")}`
					}
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-2xl border border-line bg-surface px-3 py-3 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-primary-soft text-sm font-extrabold text-primary",
							children: r.name.trim().slice(0, 1)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-semibold",
								children: r.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								dir: "ltr",
								children: maskPhone(r.phone)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("text-sm font-extrabold", r.net > 0 ? "text-warn" : r.net < 0 ? "text-primary" : "text-good"),
								children: r.net === 0 ? "تسویه" : toman(Math.abs(r.net))
							}), r.net !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: r.label
							})]
						})
					]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: creating,
				title: "شخص جدید",
				onClose: () => setCreating(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-3",
					onSubmit: (e) => {
						e.preventDefault();
						const res = addParty({
							name,
							phone
						});
						if (!res.ok) {
							toast.error(res.message);
							return;
						}
						toast.success(res.message);
						setName("");
						setPhone("");
						setCreating(false);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "نام",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: name,
								onChange: (e) => setName(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "موبایل",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								dir: "ltr",
								value: phone,
								onChange: (e) => setPhone(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							className: "w-full",
							children: "ثبت"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "soft",
				className: "w-full",
				onClick: () => {
					resetDraft(null);
					setView("invoice");
				},
				children: "فاکتور برای مشتری"
			})
		]
	});
}
function Sum({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface px-2 py-3 text-center shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-1 text-sm font-extrabold", tone === "bad" ? "text-bad" : tone === "warn" ? "text-warn" : "text-primary"),
			children: toman(value)
		})]
	});
}
var TEMPLATES = [
	{
		id: "formal",
		title: "رسمی جدول‌دار",
		hint: "جدول کامل با اطلاعات خریدار حقوقی"
	},
	{
		id: "tax",
		title: "رسمی مالیاتی",
		hint: "کد اقتصادی و ردیف مالیات ارزش افزوده"
	},
	{
		id: "letter",
		title: "سربرگ‌دار امروزی",
		hint: "سربرگ رنگی با جمع برجسته"
	},
	{
		id: "clean",
		title: "سربرگ و پاک",
		hint: "حداقل خط، مناسب اشتراک تصویری"
	}
];
function InvoicePaper({ invoice, settings, template }) {
	const band = template === "letter" ? "bg-primary text-on-primary" : template === "clean" ? "border-b-2 border-gold bg-surface text-ink" : "bg-navy text-on-navy";
	const boxed = template === "formal" || template === "tax";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "bg-surface px-4 py-5 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: cn("rounded-xl px-4 py-3", band),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-extrabold",
						children: settings.shopName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("text-xs", template === "clean" ? "text-muted" : "text-on-navy/75"),
						children: ["فاکتور ", invoice.kind === "proforma" ? "پیش‌نویس" : "فروش"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-bold",
							children: ["شماره ", invoice.number.toLocaleString("fa-IR")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("text-xs", template === "clean" ? "text-muted" : "text-on-navy/75"),
							children: formatJalali(invoice.date)
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "خریدار: "
					}), invoice.partyName] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "تسویه: "
					}), invoice.payLabel] }),
					template === "tax" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "کد اقتصادی فروشنده: "
					}), settings.economicCode] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "تلفن: "
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						dir: "ltr",
						children: settings.phone
					})] })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: cn("mt-3 w-full border-collapse text-xs", boxed && "border border-line"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: cn(boxed ? "bg-canvas" : "border-b border-line"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 text-right font-semibold",
							children: "ردیف"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 text-right font-semibold",
							children: "شرح"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 text-center font-semibold",
							children: "تعداد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 text-left font-semibold",
							children: "مبلغ"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: invoice.lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: boxed ? "border-t border-line" : "border-b border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2",
							children: (i + 1).toLocaleString("fa-IR")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-2 py-2",
							children: [line.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block text-muted",
								children: ["فی ", toman(line.price)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 text-center",
							children: line.qty.toLocaleString("fa-IR")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 text-left font-semibold",
							children: toman(line.amount)
						})
					]
				}, line.name + i)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-3 space-y-1 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "جمع کالا"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: toman(invoice.gross) })]
					}),
					invoice.discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "تخفیف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: toman(invoice.discount) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "مالیات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: toman(invoice.tax) })]
					}),
					invoice.extras > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "هزینه جانبی"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: toman(invoice.extras) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-t border-line pt-2 text-sm font-extrabold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "قابل پرداخت" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [toman(invoice.total), " تومان"] })]
					})
				]
			}),
			template === "tax" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: "مالیات بر ارزش افزوده طبق نرخ قانونی در جمع بالا محاسبه شده است."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-6 flex items-end justify-between text-xs text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					settings.address,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					settings.phone
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-left",
					children: ["امضا و مهر فروشنده", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-6 block w-24 border-b border-line" })]
				})]
			})
		]
	});
}
function PrintOverlay() {
	const invoiceId = useLedger((s) => s.focusInvoiceId);
	const invoice = useLedger((s) => s.invoices.find((i) => i.id === invoiceId) ?? null);
	const settings = useLedger((s) => s.settings);
	const setFocus = useLedger((s) => s.setFocus);
	const [template, setTemplate] = (0, import_react.useState)("formal");
	if (!invoice) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 overflow-y-auto bg-navy/55",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print mx-auto flex max-w-lg items-center justify-between px-4 py-3 text-on-navy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center rounded-full bg-on-navy/15",
						onClick: () => setFocus(null),
						children: "×"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-extrabold",
							children: ["فاکتور ", invoice.number.toLocaleString("fa-IR")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-on-navy/75",
							children: [
								invoice.partyName,
								" · ",
								toman(invoice.total),
								" تومان"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-10" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "print-root",
				className: "mx-auto max-w-lg overflow-hidden bg-surface shadow-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoicePaper, {
					invoice,
					settings,
					template
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print mx-auto max-w-lg space-y-3 px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-2",
						children: TEMPLATES.map((tpl) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setTemplate(tpl.id),
							className: cn("rounded-2xl border px-1 py-2 text-center text-xs font-semibold", template === tpl.id ? "border-primary bg-primary text-on-primary" : "border-line bg-surface text-ink"),
							children: tpl.title
						}, tpl.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-on-navy/80",
						children: TEMPLATES.find((t) => t.id === template)?.hint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "w-full",
						onClick: () => window.print(),
						children: "چاپ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => shareInvoice(invoice, "image"),
							children: "اشتراک عکس"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => shareInvoice(invoice, "pdf"),
							children: "اشتراک PDF"
						})]
					})
				]
			})
		]
	});
}
async function shareInvoice(invoice, mode) {
	const text = `${invoice.kind === "proforma" ? "پیش‌فاکتور" : "فاکتور"} ${invoice.number} — ${invoice.partyName}\n${invoice.lines.map((l) => `${l.name} × ${l.qty} = ${toman(l.amount)}`).join("\n")}\nقابل پرداخت: ${toman(invoice.total)} تومان`;
	const nav = navigator;
	if (nav.share) try {
		await nav.share({
			title: `فاکتور ${invoice.number}`,
			text
		});
		return;
	} catch {}
	try {
		await navigator.clipboard.writeText(text);
		const { toast } = await import("../_libs/sonner.mjs").then((n) => n.n);
		toast.success(mode === "pdf" ? "متن فاکتور کپی شد. چاپ را برای PDF انتخاب کنید." : "متن فاکتور برای اشتراک کپی شد.");
	} catch {
		window.print();
	}
}
var TITLES = {
	home: "خانه",
	goods: "کالاها",
	parties: "مشتری‌ها و فروشنده‌ها",
	invoice: "فاکتور فروش جدید",
	assistant: "دستیار کاسبا",
	ops: "عملیات روزانه",
	books: "دفاتر",
	excel: "اکسل",
	treasury: "خزانه‌داری",
	assets: "دارایی و استهلاک",
	production: "تولید",
	purchase: "خرید کالا",
	control: "کنترل روزانه",
	settings: "تنظیمات",
	more: "بیشتر"
};
function backOf(view) {
	if (view === "home" || view === "goods" || view === "assistant" || view === "more") return null;
	if (view === "invoice") return "home";
	return "more";
}
function AppShell() {
	const view = useLedger((s) => s.view);
	const setView = useLedger((s) => s.setView);
	const resetDraft = useLedger((s) => s.resetDraft);
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const back = backOf(view);
	const tab = view === "home" ? "home" : view === "goods" ? "goods" : view === "assistant" ? "assistant" : view === "invoice" ? "" : "more";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-canvas text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid min-h-dvh max-w-6xl md:grid-cols-[16rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "no-print sticky top-0 hidden h-dvh flex-col bg-navy px-4 py-6 text-on-navy md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-extrabold",
								children: "کاسبا"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-on-navy/70",
								children: "دفتر فروش و سند دوبل"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-px bg-gold/70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "mt-4 grid gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
									icon: House,
									label: "خانه",
									on: view === "home",
									onClick: () => setView("home")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
									icon: Package,
									label: "کالاها",
									on: view === "goods",
									onClick: () => setView("goods")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
									icon: Users,
									label: "اشخاص",
									on: view === "parties",
									onClick: () => setView("parties")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
									icon: Plus,
									label: "فاکتور جدید",
									on: view === "invoice",
									onClick: () => {
										resetDraft(null);
										setView("invoice");
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
									icon: Mic,
									label: "دستیار",
									on: view === "assistant",
									onClick: () => setView("assistant")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
									icon: BookOpen,
									label: "دفاتر",
									on: view === "books",
									onClick: () => setView("books")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
									icon: Grid2x2,
									label: "بیشتر",
									on: view === "more",
									onClick: () => setView("more")
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [view !== "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "no-print sticky top-0 z-20 flex items-center gap-2 bg-canvas/95 px-4 py-3 backdrop-blur md:px-6",
						children: [back && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setView(back),
							className: "grid size-10 place-items-center rounded-full bg-surface text-lg",
							"aria-label": "بازگشت",
							children: "›"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-lg font-extrabold",
							children: TITLES[view]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "px-4 pb-32 md:px-6 md:pb-8",
						children: [
							view === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {}),
							view === "goods" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoodsView, {}),
							view === "parties" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartiesView, {}),
							view === "invoice" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceView, {}),
							view === "assistant" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssistantView, {}),
							view === "ops" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpsView, {}),
							view === "books" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BooksView, {}),
							view === "excel" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExcelView, {}),
							view === "treasury" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreasuryView, {}),
							view === "assets" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetsView, {}),
							view === "production" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductionView, {}),
							view === "purchase" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PurchaseView, {}),
							view === "control" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlView, {}),
							view === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}),
							view === "more" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreMenu, {})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "no-print fixed inset-x-0 bottom-0 z-40 px-3 pb-3 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto grid max-w-lg grid-cols-5 items-end rounded-3xl bg-navy px-1 pb-2 pt-3 text-on-navy shadow-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockBtn, {
							label: "خانه",
							on: tab === "home",
							onClick: () => setView("home"),
							icon: House
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockBtn, {
							label: "کالاها",
							on: tab === "goods",
							onClick: () => setView("goods"),
							icon: Package
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockBtn, {
							label: "دستیار",
							on: tab === "assistant",
							onClick: () => setView("assistant"),
							icon: Mic
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockBtn, {
							label: "بیشتر",
							on: tab === "more",
							onClick: () => setView("more"),
							icon: Grid2x2
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "ثبت جدید",
							onClick: () => setCreateOpen(true),
							className: "absolute left-1/2 top-0 grid size-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-primary text-on-primary shadow-md",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-7" })
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: createOpen,
				title: "ثبت تازه",
				onClose: () => setCreateOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnNav, {
							title: "فاکتور فروش",
							onClick: () => {
								resetDraft(null);
								setView("invoice");
								setCreateOpen(false);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnNav, {
							title: "خرید کالا",
							onClick: () => {
								setView("purchase");
								setCreateOpen(false);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnNav, {
							title: "دریافت و خزانه‌داری",
							onClick: () => {
								setView("treasury");
								setCreateOpen(false);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtnNav, {
							title: "تولید و بهای تمام‌شده",
							onClick: () => {
								setView("production");
								setCreateOpen(false);
							}
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintOverlay, {})
		]
	});
}
function SideLink({ icon: Icon, label, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-11 items-center gap-2 rounded-xl px-3 text-sm font-semibold", on ? "bg-on-navy/15 text-on-navy" : "text-on-navy/70"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
function DockBtn({ icon: Icon, label, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex flex-col items-center gap-1 py-1 text-xs", on ? "text-on-navy" : "text-on-navy/60"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), label]
	});
}
function BtnNav({ title, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "h-12 rounded-xl bg-canvas text-sm font-bold",
		children: title
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
