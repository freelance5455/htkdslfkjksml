import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as POST_KINDS, t as HOME_KINDS } from "./model-Ck66RVeO.mjs";
import { t as Shell$1 } from "./shell-DSe4icyb.mjs";
import { n as useMeId, t as FeedView } from "./use-me-id-BM_D2CRi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-jseDbSfE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeFeed, {}) });
}
function HomeFeed() {
	const meId = useMeId();
	const [kind, setKind] = (0, import_react.useState)("all");
	const [scope, setScope] = (0, import_react.useState)("all");
	if (!meId) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-rose",
				children: "الساحة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "ما يُقال للجميع"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: ["all", "following"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setScope(item),
					className: `min-h-11 rounded-full px-4 text-sm ${scope === item ? "bg-ink text-paper" : "bg-paper text-mute shadow-card"}`,
					children: item === "all" ? "الجميع" : "أتابع"
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: kind === "all",
					onClick: () => setKind("all"),
					label: "الكل"
				}), HOME_KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: kind === item,
					onClick: () => setKind(item),
					label: POST_KINDS[item].label
				}, item))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedView, {
				meId,
				query: {
					surface: "home",
					kind: kind === "all" ? void 0 : kind,
					scope
				},
				variant: "feed",
				emptyTitle: "الساحة هادئة",
				emptyBody: "كن أول من ينشر فضفضة أو مسابقة أو معلومة أو نشرة."
			})
		]
	});
}
function FilterChip({ active, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `min-h-11 shrink-0 rounded-full px-4 text-sm ${active ? "bg-rose text-paper" : "bg-paper text-ink shadow-card"}`,
		children: label
	});
}
//#endregion
export { HomePage as component };
