import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, x as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as todayIso, O as useFlock, S as parseBackup, k as useHydrated, l as clampGestation, t as AppShell } from "./store-g4o8WGZx.mjs";
import { t as Input } from "./input-CkkIr1XO.mjs";
import { t as Card } from "./card-DKPDfbAA.mjs";
import { t as Button } from "./button-C77Erh3S.mjs";
import { t as Field } from "./field-DxoiOhiJ.mjs";
import { t as Confirm } from "./confirm-D8Ph184n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-DMF1dbq8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MorePage() {
	const hydrated = useHydrated();
	const herdName = useFlock((s) => s.herdName);
	const gestationDays = useFlock((s) => s.gestationDays);
	const setHerdName = useFlock((s) => s.setHerdName);
	const setGestationDays = useFlock((s) => s.setGestationDays);
	const sheep = useFlock((s) => s.sheep);
	const health = useFlock((s) => s.health);
	const breeding = useFlock((s) => s.breeding);
	const weights = useFlock((s) => s.weights);
	const replaceAll = useFlock((s) => s.replaceAll);
	const clearAll = useFlock((s) => s.clearAll);
	const [draftDays, setDraftDays] = (0, import_react.useState)(String(gestationDays));
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(null);
	const [clearOpen, setClearOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (hydrated) setDraftDays(String(useFlock.getState().gestationDays));
	}, [hydrated]);
	function exportFile() {
		const payload = {
			version: 1,
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			herdName,
			gestationDays,
			sheep,
			health,
			breeding,
			weights
		};
		const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `qatiee-${todayIso()}.json`;
		a.click();
		URL.revokeObjectURL(url);
	}
	function onFile(file) {
		if (!file) return;
		const reader = new FileReader();
		reader.onload = () => {
			try {
				const parsed = parseBackup(JSON.parse(String(reader.result ?? "")));
				if (!parsed) {
					setError("الملف ليس نسخة من قطيعي.");
					return;
				}
				setError(null);
				setPending(parsed);
			} catch {
				setError("تعذّر قراءة الملف.");
			}
		};
		reader.readAsText(file);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "الإعدادات",
		children: [
			!hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "يُفتح السجل…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "اسم القطيع",
							htmlFor: "herd",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "herd",
								value: herdName,
								maxLength: 40,
								onChange: (e) => setHerdName(e.target.value),
								onBlur: () => setHerdName(herdName.trim() || "قطيعي")
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "مدة الحمل بالأيام",
							htmlFor: "gest",
							hint: "الأغنام غالباً حول 147 يوماً. تُستخدم عند تسجيل تلقيح جديد.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "gest",
								inputMode: "numeric",
								value: draftDays,
								onChange: (e) => setDraftDays(e.target.value),
								onBlur: () => {
									const next = clampGestation(Number(draftDays));
									setDraftDays(String(next));
									setGestationDays(next);
								}
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-medium",
								children: "نسخة على الجهاز"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-normal text-muted-foreground",
								children: "السجل محفوظ في هذا المتصفح فقط. صدّر نسخة قبل مسح بيانات المتصفح أو تغيير الهاتف."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: exportFile,
								children: "تصدير النسخة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex h-11 items-center justify-center rounded-lg border border-border text-sm font-medium",
								children: ["استيراد نسخة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "application/json,.json",
									className: "sr-only",
									onChange: (e) => {
										onFile(e.target.files?.[0]);
										e.target.value = "";
									}
								})]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-danger",
								children: error
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium",
						children: "كيف يُدار القطيع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 flex list-disc flex-col gap-2 pr-4 text-sm leading-normal text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "رقم الحلقة هو معرّف الرأس. لا يتكرر." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الصغار من لهم أقل من سنة حسب تاريخ الميلاد." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الحامل تُحسب من تلقيح لم تُسجَّل ولادته بعد." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "تسجيل الولادة ينشئ المواليد ويربطهم بالأم والأب." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "المبيع والنافق يخرجان من التعداد ويبقيان في الأرشيف." })
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						className: "text-danger",
						onClick: () => setClearOpen(true),
						children: "مسح السجل كله"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Confirm, {
				open: pending != null,
				onOpenChange: (open) => !open && setPending(null),
				title: "استبدال السجل؟",
				body: pending ? `ستُستبدل البيانات الحالية بهذه النسخة: ${pending.sheep.length} رأس.` : "",
				confirmLabel: "استبدال",
				destructive: true,
				onConfirm: () => {
					if (pending) replaceAll(pending);
					setPending(null);
					setDraftDays(String(pending?.gestationDays ?? gestationDays));
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Confirm, {
				open: clearOpen,
				onOpenChange: setClearOpen,
				title: "مسح كل السجل؟",
				body: "تُحذف الرؤوس والسجلات من هذا الجهاز. صدّر نسخة أولاً إن كنت تحتاجها.",
				confirmLabel: "مسح",
				destructive: true,
				onConfirm: () => {
					clearAll();
					setDraftDays("147");
					setClearOpen(false);
				}
			})
		]
	});
}
//#endregion
export { MorePage as component };
