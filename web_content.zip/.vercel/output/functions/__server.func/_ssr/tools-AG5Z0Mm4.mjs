import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as THERMAL_TIPS, V as useAppStore, _ as PageHeader, a as Button, h as Notice, i as BACKGROUND_TIPS, j as formatWhen, u as Field, v as Panel, x as THERMAL_CHECKS } from "./ui-CJMJB--P.mjs";
import { n as FpsLogTool, t as CompareTool } from "./fps-tools-C4CmmVU9.mjs";
import { t as RefreshMeasure } from "./refresh-measure-CQ_5yNsN.mjs";
import { n as TUTORIALS } from "./router-DG3Pqbtv.mjs";
import { n as SessionClock, t as DevicePanel } from "./session-clock-Dj1rOmaj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools-AG5Z0Mm4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INDEX = [
	["stopwatch", "Session stopwatch"],
	["fps-log", "Manual FPS log"],
	["refresh-guide", "Refresh-rate guide"],
	["capabilities", "Device checklist"],
	["notes", "Settings notes"],
	["compare", "Comparison log"],
	["thermal", "Thermal guide"],
	["tutorials", "Tutorials"]
];
function ToolsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Tools",
				title: "Toolkit",
				subtitle: "Each tool records something you enter, measures this page, or explains a limit. None of them invent a benchmark."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Tools on this page",
				className: "flex flex-wrap gap-2",
				children: INDEX.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `#${id}`,
					className: "inline-flex min-h-11 items-center rounded-lg bg-surface px-3 text-sm font-semibold shadow-[var(--shadow-ring)]",
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				id: "stopwatch",
				title: "Session stopwatch",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionClock, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				id: "fps-log",
				title: "Manual FPS log",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "Type a frame rate you measured in the game. The chart only plots those rows. The latest 200 are kept."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FpsLogTool, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				id: "refresh-guide",
				title: "Refresh-rate guide",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mb-4 list-disc space-y-2 pl-5 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Refresh rate is the display. A 60 Hz panel can present about 60 frames each second. A 120 Hz panel can present more, if the phone is actually running at that mode." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Rendered FPS is how many frames the game produces. A 120 Hz screen does not make a 30 FPS game into 120." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Interpolated FPS is extra frames created between real ones. Frame generation unavailable in this version." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The measurement below counts animation frames on this page. Chrome may lower it in the background or in a power-saving mode, so it can read under the panel's hardware maximum." })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshMeasure, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				id: "capabilities",
				title: "Device capability checklist",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DevicePanel, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				id: "notes",
				title: "Game settings notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesTool, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				id: "compare",
				title: "Performance comparison log",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "Record manual runs side by side. This is a log, not an automated benchmark."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareTool, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				id: "thermal",
				title: "Thermal management",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm font-semibold",
						children: "Temperature: Not available in this version."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "list-disc space-y-2 pl-5 text-sm text-muted",
						children: THERMAL_TIPS.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tip }, tip))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 font-display text-base font-semibold",
						children: "Also worth doing"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 list-disc space-y-2 pl-5 text-sm text-muted",
						children: BACKGROUND_TIPS.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tip }, tip))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThermalList, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				id: "tutorials",
				title: "Tutorials",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TutorialList, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Need the install steps or the native-app limits? They live in ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/settings",
						hash: "limits",
						className: "font-semibold text-primary",
						children: "Settings"
					}),
					"."
				]
			})
		]
	});
}
function NotesTool() {
	const notes = useAppStore((state) => state.notes);
	const games = useAppStore((state) => state.games);
	const addNote = useAppStore((state) => state.addNote);
	const removeNote = useAppStore((state) => state.removeNote);
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [gameId, setGameId] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Title",
				error,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field-input",
					value: title,
					maxLength: 80,
					onChange: (event) => setTitle(event.target.value),
					placeholder: "Shadows that stayed stable"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Note",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "field-input min-h-28",
					value: body,
					maxLength: 2e3,
					onChange: (event) => setBody(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Linked profile",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field-input",
					value: gameId,
					onChange: (event) => setGameId(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "No specific game"
					}), games.map((game) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: game.id,
						children: game.name
					}, game.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => {
					if (!title.trim()) {
						setError("Add a title.");
						return;
					}
					addNote({
						title,
						body,
						gameId: gameId || null
					});
					setTitle("");
					setBody("");
					setError(null);
				},
				children: "Save note"
			}),
			notes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No notes yet."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-line",
				children: notes.map((note) => {
					const game = games.find((item) => item.id === note.gameId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: note.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-faint",
								children: [formatWhen(note.at), game ? ` · ${game.name}` : ""]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "px-2",
								onClick: () => removeNote(note.id),
								children: "Remove"
							})]
						}), note.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted whitespace-pre-wrap",
							children: note.body
						}) : null]
					}, note.id);
				})
			})
		]
	});
}
function ThermalList() {
	const thermal = useAppStore((state) => state.thermal);
	const toggle = useAppStore((state) => state.toggleThermal);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-sm font-semibold",
				children: "Checklist for this device"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 mb-2 text-sm text-muted",
				children: "Ticks are reminders you set. They are not sensor readings."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "stack",
				children: THERMAL_CHECKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "size-5",
						checked: Boolean(thermal[item.id]),
						onChange: () => toggle(item.id)
					}), item.label]
				}) }, item.id))
			})
		]
	});
}
function TutorialList() {
	const seen = useAppStore((state) => state.tutorialsSeen);
	const mark = useAppStore((state) => state.markTutorial);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [TUTORIALS.map((tutorial) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-lg bg-surface-2 p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-base font-semibold",
						children: tutorial.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: tutorial.summary
					})] }), seen[tutorial.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold tracking-widest text-ok uppercase",
						children: "Read"
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 list-decimal space-y-2 pl-5 text-sm text-muted",
					children: tutorial.steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: step }, step))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					variant: seen[tutorial.id] ? "quiet" : "primary",
					onClick: () => mark(tutorial.id, !seen[tutorial.id]),
					children: seen[tutorial.id] ? "Mark as unread" : "Mark as read"
				})
			]
		}, tutorial.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Marking a tutorial only stores that choice on this device." })]
	});
}
var SplitComponent = ToolsPage;
//#endregion
export { SplitComponent as component };
