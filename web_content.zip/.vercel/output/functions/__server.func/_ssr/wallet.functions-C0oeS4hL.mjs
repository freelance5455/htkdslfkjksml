import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wallet.functions-C0oeS4hL.js
function cleanWallet(input) {
	const data = input ?? {};
	const chain = data.chain;
	const address = String(data.address ?? "").trim();
	if (chain !== "bitcoin" && chain !== "ethereum" && chain !== "solana") throw new Error("Ismeretlen lánc.");
	if (chain === "bitcoin" && !/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{20,80}$/.test(address)) throw new Error("Ez nem tűnik bitcoin-címnek.");
	if (chain === "ethereum" && !/^0x[a-fA-F0-9]{40}$/.test(address)) throw new Error("Ez nem tűnik Ethereum-címnek.");
	if (chain === "solana" && !/^[1-9A-HJ-NP-Za-km-z]{32,48}$/.test(address)) throw new Error("Ez nem tűnik Solana-címnek.");
	return {
		chain,
		address
	};
}
async function readWallet(chain, address) {
	if (chain === "bitcoin") {
		const response = await fetch(`https://mempool.space/api/address/${address}`, { signal: AbortSignal.timeout(12e3) });
		if (!response.ok) throw new Error("A bitcoin-cím most nem kérdezhető le.");
		const data = await response.json();
		const sats = (data.chain_stats?.funded_txo_sum ?? 0) - (data.chain_stats?.spent_txo_sum ?? 0);
		return {
			chain,
			symbol: "BTC",
			quantity: Math.max(0, sats) / 1e8
		};
	}
	if (chain === "ethereum") {
		const response = await fetch("https://ethereum.publicnode.com", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				jsonrpc: "2.0",
				id: 1,
				method: "eth_getBalance",
				params: [address, "latest"]
			}),
			signal: AbortSignal.timeout(12e3)
		});
		if (!response.ok) throw new Error("Az Ethereum-cím most nem kérdezhető le.");
		const data = await response.json();
		if (!data.result) throw new Error(data.error?.message || "Az Ethereum-egyenleg nem jött meg.");
		const wei = BigInt(data.result);
		const whole = wei / 10n ** 18n;
		const frac = wei % 10n ** 18n;
		return {
			chain,
			symbol: "ETH",
			quantity: Number(whole) + Number(frac) / 0xde0b6b3a7640000
		};
	}
	const response = await fetch("https://api.mainnet-beta.solana.com", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({
			jsonrpc: "2.0",
			id: 1,
			method: "getBalance",
			params: [address]
		}),
		signal: AbortSignal.timeout(12e3)
	});
	if (!response.ok) throw new Error("A Solana-cím most nem kérdezhető le.");
	const data = await response.json();
	if (data.result?.value == null) throw new Error(data.error?.message || "A Solana-egyenleg nem jött meg.");
	return {
		chain,
		symbol: "SOL",
		quantity: data.result.value / 1e9
	};
}
var fetchWallet_createServerFn_handler = createServerRpc({
	id: "f10aef7e15e94680c415da06279d97d0fec16a4ff627d5ce9f2f769cc5bdf235",
	name: "fetchWallet",
	filename: "src/lib/wallet.functions.ts"
}, (opts) => fetchWallet.__executeServer(opts));
var fetchWallet = createServerFn({ method: "POST" }).validator(cleanWallet).handler(fetchWallet_createServerFn_handler, async ({ data }) => readWallet(data.chain, data.address));
//#endregion
export { fetchWallet_createServerFn_handler };
