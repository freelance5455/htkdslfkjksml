import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-D3pycy8g.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function ymd(value) {
	if (!/^\d{8}$/.test(value)) throw new Error("bad date");
	return value;
}
var fetchHome_createServerFn_handler = createServerRpc({
	id: "6c8967caee8dacb6068c727131691ee2a88f68ac12f81bed0df35104c9a9a8cd",
	name: "fetchHome",
	filename: "src/lib/football/api.ts"
}, (opts) => fetchHome.__executeServer(opts));
var fetchHome = createServerFn({ method: "GET" }).validator((input) => ({
	today: ymd(input.today),
	tomorrow: ymd(input.tomorrow)
})).handler(fetchHome_createServerFn_handler, async ({ data }) => {
	const { loadHome } = await import("./providers.server-Cwdrc15M.mjs");
	return loadHome(data);
});
var fetchBoard_createServerFn_handler = createServerRpc({
	id: "f638fa8d9d6499f48200f613502584f1e56ce94d494db2e222c17a808a497a28",
	name: "fetchBoard",
	filename: "src/lib/football/api.ts"
}, (opts) => fetchBoard.__executeServer(opts));
var fetchBoard = createServerFn({ method: "GET" }).validator((input) => ({ dates: (input.dates ?? []).filter((d) => /^\d{8}$/.test(d)).slice(0, 7) })).handler(fetchBoard_createServerFn_handler, async ({ data }) => {
	const { loadBoard } = await import("./providers.server-Cwdrc15M.mjs");
	return loadBoard(data.dates);
});
var fetchLeague_createServerFn_handler = createServerRpc({
	id: "e3e0b969a488ee1cedea7aa03dd5fdaf7ba0b665d822113963b27ba6ba8f07c4",
	name: "fetchLeague",
	filename: "src/lib/football/api.ts"
}, (opts) => fetchLeague.__executeServer(opts));
var fetchLeague = createServerFn({ method: "GET" }).validator((id) => {
	if (typeof id !== "string" || id.length < 2 || id.length > 80) throw new Error("bad league");
	return id;
}).handler(fetchLeague_createServerFn_handler, async ({ data }) => {
	const { loadLeague } = await import("./providers.server-Cwdrc15M.mjs");
	return loadLeague(data);
});
var fetchTeam_createServerFn_handler = createServerRpc({
	id: "2dca60edffd6562f7155f4a493d72b02c2f51d9dd0d72ad4b5ddbce1358f824b",
	name: "fetchTeam",
	filename: "src/lib/football/api.ts"
}, (opts) => fetchTeam.__executeServer(opts));
var fetchTeam = createServerFn({ method: "GET" }).validator((input) => input).handler(fetchTeam_createServerFn_handler, async ({ data }) => {
	const { loadTeam } = await import("./providers.server-Cwdrc15M.mjs");
	return loadTeam(data.leagueId, data.teamId);
});
var fetchMatch_createServerFn_handler = createServerRpc({
	id: "cfb23f8752e86a05951b919d613363d22f6e9145a543949954e4f6f35c932ba3",
	name: "fetchMatch",
	filename: "src/lib/football/api.ts"
}, (opts) => fetchMatch.__executeServer(opts));
var fetchMatch = createServerFn({ method: "GET" }).validator((input) => input).handler(fetchMatch_createServerFn_handler, async ({ data }) => {
	const { loadMatch } = await import("./providers.server-Cwdrc15M.mjs");
	return loadMatch(data.leagueId, data.eventId);
});
var fetchPlayer_createServerFn_handler = createServerRpc({
	id: "882985e2bac589c6918fd33f32839b6d309717193107d0822b8e1b75fc1332b8",
	name: "fetchPlayer",
	filename: "src/lib/football/api.ts"
}, (opts) => fetchPlayer.__executeServer(opts));
var fetchPlayer = createServerFn({ method: "GET" }).validator((input) => input).handler(fetchPlayer_createServerFn_handler, async ({ data }) => {
	const { loadPlayer } = await import("./providers.server-Cwdrc15M.mjs");
	return loadPlayer(data.leagueId, data.playerId, data.teamId);
});
var fetchH2H_createServerFn_handler = createServerRpc({
	id: "cb2401235f1aafa4139224ab2d59742643fd34ee2c145239dcebc46d16d7bda4",
	name: "fetchH2H",
	filename: "src/lib/football/api.ts"
}, (opts) => fetchH2H.__executeServer(opts));
var fetchH2H = createServerFn({ method: "GET" }).validator((input) => input).handler(fetchH2H_createServerFn_handler, async ({ data }) => {
	const { loadH2H } = await import("./providers.server-Cwdrc15M.mjs");
	return loadH2H(data.leagueId, data.teamA, data.teamB);
});
var fetchSearch_createServerFn_handler = createServerRpc({
	id: "91f6d7ce87ad61bf23d3b1be24ca8a2ab0ba61f85dddaac04da66546ad4d84dd",
	name: "fetchSearch",
	filename: "src/lib/football/api.ts"
}, (opts) => fetchSearch.__executeServer(opts));
var fetchSearch = createServerFn({ method: "GET" }).validator((q) => String(q ?? "").trim().slice(0, 60)).handler(fetchSearch_createServerFn_handler, async ({ data }) => {
	const { searchAll } = await import("./providers.server-Cwdrc15M.mjs");
	return searchAll(data);
});
var askAssistant_createServerFn_handler = createServerRpc({
	id: "602d2a4cc06895d44cde6d79658eae6430fd2a3d795d46608d88901d2bf1e7cf",
	name: "askAssistant",
	filename: "src/lib/football/api.ts"
}, (opts) => askAssistant.__executeServer(opts));
var askAssistant = createServerFn({ method: "POST" }).validator((input) => ({
	question: String(input.question ?? "").trim().slice(0, 600),
	lang: input.lang === "en" ? "en" : "ar",
	today: /^\d{8}$/.test(input.today ?? "") ? input.today : ""
})).handler(askAssistant_createServerFn_handler, async ({ data }) => {
	if (!data.question) throw new Error("empty");
	const { answerQuestion } = await import("./providers.server-Cwdrc15M.mjs");
	return answerQuestion(data);
});
//#endregion
export { askAssistant_createServerFn_handler, fetchBoard_createServerFn_handler, fetchH2H_createServerFn_handler, fetchHome_createServerFn_handler, fetchLeague_createServerFn_handler, fetchMatch_createServerFn_handler, fetchPlayer_createServerFn_handler, fetchSearch_createServerFn_handler, fetchTeam_createServerFn_handler };
