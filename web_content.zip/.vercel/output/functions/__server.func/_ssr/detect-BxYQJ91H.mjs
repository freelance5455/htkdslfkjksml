//#region node_modules/.nitro/vite/services/ssr/assets/detect-BxYQJ91H.js
var QUALITIES = [
	"1080p",
	"720p",
	"480p"
];
var PLATFORM_LABEL = {
	youtube: "YouTube",
	tiktok: "TikTok",
	instagram: "Instagram"
};
function normalizeUrl(raw) {
	let value = raw.trim();
	if (!value) return "";
	if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
	return value;
}
function detectPlatform(raw) {
	try {
		const hostname = new URL(normalizeUrl(raw)).hostname.replace(/^www\./, "").toLowerCase();
		if (hostname === "youtu.be" || hostname === "youtube.com" || hostname === "m.youtube.com" || hostname === "music.youtube.com" || hostname === "youtube-nocookie.com") return "youtube";
		if (hostname === "tiktok.com" || hostname.endsWith(".tiktok.com")) return "tiktok";
		if (hostname === "instagram.com" || hostname === "instagr.am" || hostname.endsWith(".instagram.com")) return "instagram";
		return null;
	} catch {
		return null;
	}
}
function extractYoutubeId(raw) {
	try {
		const url = new URL(normalizeUrl(raw));
		const host = url.hostname.replace(/^www\./, "").toLowerCase();
		if (host === "youtu.be") {
			const id = url.pathname.split("/").filter(Boolean)[0];
			return id && /^[\w-]{11}$/.test(id) ? id : null;
		}
		if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com" || host === "youtube-nocookie.com") {
			const v = url.searchParams.get("v");
			if (v && /^[\w-]{11}$/.test(v)) return v;
			const parts = url.pathname.split("/").filter(Boolean);
			if (parts[0] && [
				"shorts",
				"embed",
				"live",
				"v"
			].includes(parts[0]) && parts[1] && /^[\w-]{11}$/.test(parts[1])) return parts[1];
		}
		return null;
	} catch {
		return null;
	}
}
function youtubeThumbnail(id) {
	return `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
}
function qualityToCobalt(quality) {
	if (quality === "1080p") return "1080";
	if (quality === "720p") return "720";
	return "480";
}
function mimeFromFilename(filename, audioOnly) {
	const lower = filename.toLowerCase();
	if (lower.endsWith(".mp3")) return "audio/mpeg";
	if (lower.endsWith(".m4a")) return "audio/mp4";
	if (lower.endsWith(".wav")) return "audio/wav";
	if (lower.endsWith(".opus") || lower.endsWith(".ogg")) return "audio/ogg";
	if (lower.endsWith(".webm")) return audioOnly ? "audio/webm" : "video/webm";
	if (lower.endsWith(".mkv")) return "video/x-matroska";
	return audioOnly ? "audio/mpeg" : "video/mp4";
}
function looksLikeUrl(raw) {
	const value = raw.trim();
	if (value.length < 8) return false;
	return /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be|m\.youtube\.com|music\.youtube\.com|tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com|instagram\.com|instagr\.am)\b/i.test(value);
}
//#endregion
export { looksLikeUrl as a, qualityToCobalt as c, extractYoutubeId as i, youtubeThumbnail as l, QUALITIES as n, mimeFromFilename as o, detectPlatform as r, normalizeUrl as s, PLATFORM_LABEL as t };
