import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Heart, c as Search, g as Library, i as Sun, m as Moon, o as Sparkles, v as Headphones, w as BookOpen } from "../_libs/lucide-react.mjs";
import { l as toArabicDigits, t as AppShell, u as useAppStore } from "./app-shell-C4IrQdCN.mjs";
import { u as quranMeta } from "./catalog-CjAfWU9w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dfk2JnHQ.js
var import_jsx_runtime = require_jsx_runtime();
var SECTIONS = [
	{
		to: "/quran",
		title: "القرآن الكريم",
		hint: "المصحف والسور",
		icon: BookOpen
	},
	{
		to: "/adhkar",
		title: "الأذكار والأدعية",
		hint: "حصن المسلم",
		icon: Sparkles
	},
	{
		to: "/library",
		title: "المكتبة الشرعية",
		hint: "حديث · عقيدة · فقه",
		icon: Library
	},
	{
		to: "/listen",
		title: "الاستماع",
		hint: "تلاوة وتحميل دون اتصال",
		icon: Headphones
	},
	{
		to: "/favorites",
		title: "المفضلة",
		hint: "آيات ومواضع محفوظة",
		icon: Heart
	}
];
function greeting() {
	const h = (/* @__PURE__ */ new Date()).getHours();
	if (h < 5) return "أذكار النوم قريبة إن شاء الله";
	if (h < 12) return "آن أذكار الصباح";
	if (h < 16) return "بارك الله وقتك";
	if (h < 19) return "آن أذكار المساء";
	return "آن أذكار المساء والنوم";
}
function Home() {
	const last = useAppStore((s) => s.lastReading);
	const theme = useAppStore((s) => s.settings.theme);
	const setTheme = useAppStore((s) => s.setTheme);
	const surah = last ? quranMeta.surahs.find((x) => x.id === last.surahId) : quranMeta.surahs[0];
	const ayah = last?.ayah ?? 1;
	const isDark = theme === "dark";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ornament-bg pointer-events-none absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative flex items-center justify-between px-5 pb-2 pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/search",
						className: "tap-lg flex size-11 items-center justify-center rounded-full bg-surface text-foreground",
						"aria-label": "بحث",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-[0.3em] text-muted-foreground",
							children: "بسم الله الرحمن الرحيم"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-quran text-3xl text-accent",
							children: "رفيق"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tap-lg flex size-11 items-center justify-center rounded-full bg-surface",
						"aria-label": "الوضع الليلي",
						onClick: () => setTheme(isDark ? "light" : "dark"),
						children: isDark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative mb-5 px-5 text-center text-sm text-muted-foreground",
				children: greeting()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative mx-4 mb-6 rounded-[28px] bg-accent p-5 text-accent-foreground shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs opacity-80",
						children: "موضع القراءة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-quran text-2xl",
						children: surah?.name ?? "سُورَةُ ٱلْفَاتِحَةِ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm opacity-85",
						children: [
							"الآية ",
							toArabicDigits(ayah),
							surah ? ` · ${surah.type}` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/quran/$surahId",
						params: { surahId: String(surah?.id ?? 1) },
						search: { ayah },
						className: "mt-4 flex h-12 items-center justify-center rounded-2xl bg-accent-foreground text-sm font-semibold text-accent",
						children: "متابعة القراءة"
					})
				]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-4 pb-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-2.5",
			children: SECTIONS.map((s) => {
				const Icon = s.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: s.to,
					className: "flex items-center gap-3 rounded-2xl bg-card px-4 py-3.5 shadow-[var(--shadow-border)] transition-transform duration-[var(--motion-quick)] active:scale-[0.99]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-xl bg-surface text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-[15px] font-medium",
							children: s.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: s.hint
						})]
					})]
				}) }, s.to);
			})
		})
	})] });
}
//#endregion
export { Home as component };
