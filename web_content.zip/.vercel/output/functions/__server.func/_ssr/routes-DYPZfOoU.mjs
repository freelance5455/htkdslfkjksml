import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { c as unsupportedReason, s as platformLabel, t as detectPlatform } from "./platforms-Bi_mEui3.mjs";
import { a as string, i as object, t as _enum } from "../_libs/zod.mjs";
import { a as Download, c as Check, i as House, n as Trash2, o as Clock, r as LoaderCircle, s as Clipboard } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DYPZfOoU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[transform,background-color,opacity] duration-150 ease-out select-none touch-manipulation disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg hover:bg-surface",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-surface-2",
			danger: "bg-danger/15 text-danger hover:bg-danger/25"
		},
		size: {
			md: "h-11 rounded-md px-4 text-sm",
			lg: "h-12 rounded-lg px-5 text-sm",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input$1({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-12 w-full rounded-lg bg-surface-2 px-4 text-sm text-fg outline-none", "placeholder:text-subtle shadow-[var(--shadow-border)]", "focus-visible:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_55%,transparent)]", "disabled:opacity-40", className),
		...props
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({
	url: string().trim().min(6).max(2e3),
	mode: _enum(["video", "audio"]),
	quality: _enum([
		"1080",
		"720",
		"480"
	])
});
var resolveMedia = createServerFn({ method: "POST" }).validator(Input).handler(createSsrRpc("3ab971e9f8b5837aadd29b879496cec5defc585c287f0b9fcf3b47102ac038ee"));
var useHistory = create()(persist((set, get) => ({
	items: [],
	remember: (entry) => {
		set({ items: [{
			...entry,
			id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
			savedAt: Date.now()
		}, ...get().items.filter((item) => item.url !== entry.url)].slice(0, 30) });
	},
	remove: (id) => set({ items: get().items.filter((item) => item.id !== id) }),
	clear: () => set({ items: [] })
}), { name: "puro-history" }));
function mediaSrc(item, download = false) {
	const params = new URLSearchParams({ t: item.token });
	if (download) params.set("dl", "1");
	return `/api/media?${params.toString()}`;
}
function formatDuration(seconds) {
	if (!seconds || seconds <= 0) return null;
	return `${Math.floor(seconds / 60)}:${Math.floor(seconds % 60).toString().padStart(2, "0")}`;
}
function PuroApp() {
	const [tab, setTab] = (0, import_react.useState)("home");
	const [url, setUrl] = (0, import_react.useState)("");
	const [quality, setQuality] = (0, import_react.useState)("720");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)(null);
	const [item, setItem] = (0, import_react.useState)(null);
	const [extras, setExtras] = (0, import_react.useState)([]);
	const [saved, setSaved] = (0, import_react.useState)(false);
	const history = useHistory();
	const detected = url.trim() ? detectPlatform(url) : "unknown";
	async function openLink(source = url, mode = "video") {
		const trimmed = source.trim();
		if (!trimmed) {
			setError("Cola o link do vídeo.");
			return;
		}
		const blocked = unsupportedReason(trimmed);
		if (blocked) {
			setError(blocked);
			return;
		}
		setBusy(true);
		setError(null);
		setSaved(false);
		setItem(null);
		setExtras([]);
		try {
			const result = await resolveMedia({ data: {
				url: trimmed,
				mode,
				quality
			} });
			if (!result.ok) {
				setError(result.message);
				return;
			}
			setItem(result.item);
			setExtras(result.extras);
			setUrl(trimmed);
			history.remember({
				url: trimmed,
				title: result.item.title,
				platform: result.item.platform,
				thumbnail: result.item.thumbnail
			});
		} catch {
			setError("Não deu pra abrir esse link agora. Tenta de novo.");
		} finally {
			setBusy(false);
		}
	}
	async function pasteFromClipboard() {
		try {
			const text = await navigator.clipboard.readText();
			if (!text.trim()) {
				toast("A área de transferência está vazia.");
				return;
			}
			setUrl(text.trim());
			setError(null);
		} catch {
			toast("Permite o acesso à área de transferência pra colar.");
		}
	}
	async function saveToGallery(target) {
		setSaving(true);
		setProgress(0);
		setSaved(false);
		try {
			const res = await fetch(mediaSrc(target, true));
			if (!res.ok) throw new Error("fail");
			const total = Number(res.headers.get("content-length") || 0);
			const reader = res.body?.getReader();
			const chunks = [];
			let loaded = 0;
			if (reader) for (;;) {
				const { done, value } = await reader.read();
				if (done) break;
				if (value) {
					chunks.push(value);
					loaded += value.byteLength;
					if (total) setProgress(loaded / total);
				}
			}
			else {
				const buf = new Uint8Array(await res.arrayBuffer());
				chunks.push(buf);
				setProgress(1);
			}
			const blob = new Blob(chunks, { type: target.mime || "video/mp4" });
			const file = new File([blob], target.filename, { type: blob.type || target.mime });
			const nav = navigator;
			if (typeof nav.canShare === "function" && nav.canShare({ files: [file] })) {
				await navigator.share({
					files: [file],
					title: target.title
				});
				setSaved(true);
				return;
			}
			const href = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = href;
			a.download = target.filename;
			document.body.appendChild(a);
			a.click();
			a.remove();
			setTimeout(() => URL.revokeObjectURL(href), 4e3);
			setSaved(true);
		} catch {
			toast("Não consegui salvar. Tenta de novo.");
		} finally {
			setSaving(false);
		}
	}
	function reset() {
		setItem(null);
		setExtras([]);
		setError(null);
		setSaved(false);
		setProgress(0);
		setUrl("");
	}
	function openRecent(entry) {
		setTab("home");
		setUrl(entry.url);
		openLink(entry.url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-stretch justify-center bg-bg md:items-center md:bg-frame md:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("relative flex w-full min-h-dvh flex-col overflow-hidden bg-bg", "md:h-app md:min-h-0 md:w-app md:rounded-device md:shadow-[var(--shadow-device)]"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between px-5 pb-3 pt-[max(1.25rem,env(safe-area-inset-top))]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-semibold tracking-tight",
						children: "Puro"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Sem marca d'água"
					})] }), item ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "md",
						onClick: reset,
						children: "Novo"
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-4",
					children: tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePane, {
						url,
						setUrl,
						quality,
						setQuality,
						detected,
						busy,
						error,
						item,
						extras,
						saving,
						saved,
						progress,
						onPaste: pasteFromClipboard,
						onOpen: () => void openLink(),
						onAudio: () => void openLink(url, "audio"),
						onSave: (target) => void saveToGallery(target)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentsPane, {
						items: history.items,
						onOpen: openRecent,
						onRemove: history.remove,
						onClear: history.clear
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: cn("grid grid-cols-2 gap-1 border-t border-border bg-bg px-3 pt-2", "pb-[max(0.75rem,env(safe-area-inset-bottom))]"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
						active: tab === "home",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
							className: "size-5",
							strokeWidth: 1.75
						}),
						label: "Início",
						onClick: () => setTab("home")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
						active: tab === "recents",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
							className: "size-5",
							strokeWidth: 1.75
						}),
						label: "Recentes",
						onClick: () => setTab("recents")
					})]
				})
			]
		})
	});
}
function TabButton({ active, icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-12 flex-col items-center justify-center gap-0.5 rounded-md text-xs font-medium", active ? "text-fg" : "text-subtle"),
		children: [icon, label]
	});
}
function HomePane({ url, setUrl, quality, setQuality, detected, busy, error, item, extras, saving, saved, progress, onPaste, onOpen, onAudio, onSave }) {
	if (item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultView, {
		item,
		extras,
		saving,
		saved,
		progress,
		onSave,
		onAudio: item.kind === "video" ? onAudio : void 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-3xl font-semibold leading-tight tracking-tight",
					children: [
						"Cola o link.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"Salva na galeria."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-[18rem] text-sm leading-relaxed text-muted",
					children: "YouTube, TikTok e Instagram. O arquivo vai limpo, sem marca da plataforma."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 space-y-3",
				onSubmit: (event) => {
					event.preventDefault();
					onOpen();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input$1, {
							value: url,
							onChange: (event) => setUrl(event.target.value),
							placeholder: "Cola o link do vídeo",
							inputMode: "url",
							autoCapitalize: "off",
							autoCorrect: "off",
							spellCheck: false,
							"aria-label": "Link do vídeo",
							className: "pr-12"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onPaste,
							className: "absolute right-1.5 top-1.5 flex size-9 items-center justify-center rounded-md text-muted hover:text-fg",
							"aria-label": "Colar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clipboard, {
								className: "size-4",
								strokeWidth: 1.75
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-subtle",
							children: detected === "unknown" ? "YouTube · TikTok · Instagram" : platformLabel(detected)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex rounded-md bg-surface-2 p-0.5",
							children: [
								"1080",
								"720",
								"480"
							].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setQuality(value),
								className: cn("h-8 rounded-sm px-2.5 text-xs font-medium", quality === value ? "bg-surface text-fg" : "text-muted"),
								children: value
							}, value))
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-danger",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "lg",
						className: "w-full",
						disabled: busy,
						children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), "Abrindo"] }) : "Abrir vídeo"
					})
				]
			}),
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusySkeleton, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-auto space-y-3 pt-10 text-xs leading-relaxed text-subtle",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "O vídeo precisa ser público." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "No iPhone, escolhe Salvar Vídeo na folha que abrir." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Uso pessoal. Respeita o autor do conteúdo." })
				]
			})
		]
	});
}
function BusySkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 overflow-hidden rounded-xl bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-video animate-pulse bg-surface-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-3/4 rounded-xs bg-surface-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-1/3 rounded-xs bg-surface-2" })]
		})]
	});
}
function ResultView({ item, extras, saving, saved, progress, onSave, onAudio }) {
	const duration = formatDuration(item.duration);
	const all = (0, import_react.useMemo)(() => [item, ...extras], [item, extras]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
				children: [item.kind === "photo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: item.thumbnail || mediaSrc(item),
					alt: "",
					className: "aspect-[3/4] w-full object-cover",
					referrerPolicy: "no-referrer"
				}) : item.kind === "audio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex aspect-video items-center justify-center bg-surface-2 p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
						src: mediaSrc(item),
						controls: true,
						className: "w-full"
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					src: mediaSrc(item),
					poster: item.thumbnail ?? void 0,
					controls: true,
					playsInline: true,
					className: "aspect-video max-h-80 w-full bg-surface-2 object-contain"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-medium uppercase tracking-wide text-subtle",
							children: [platformLabel(item.platform), duration ? ` · ${duration}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium leading-snug",
							children: item.title
						}),
						item.author ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: item.author
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: () => onSave(item),
						disabled: saving,
						children: saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }),
							"Salvando ",
							progress > 0 ? `${Math.round(progress * 100)}%` : ""
						] }) : saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Salvo"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Salvar na galeria"] })
					}),
					onAudio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "lg",
						className: "w-full",
						onClick: onAudio,
						children: "Só o áudio"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 text-center text-xs leading-relaxed text-subtle",
						children: "No iPhone e no Android, a folha de compartilhar deixa salvar direto na galeria."
					})
				]
			}),
			all.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-muted",
					children: "Mais arquivos neste post"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: all.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onSave(entry),
						className: "overflow-hidden rounded-md bg-surface-2",
						children: entry.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: entry.thumbnail,
							alt: "",
							className: "aspect-square w-full object-cover",
							referrerPolicy: "no-referrer"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex aspect-square items-center justify-center text-xs text-muted",
							children: index + 1
						})
					}, `${entry.token}-${index}`))
				})]
			}) : null
		]
	});
}
function RecentsPane({ items, onOpen, onRemove, onClear }) {
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col items-start justify-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-medium",
			children: "Nada ainda"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 max-w-[16rem] text-sm leading-relaxed text-muted",
			children: "Os vídeos que você abrir ficam aqui pra reabrir rápido."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-semibold",
				children: "Recentes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "md",
				onClick: onClear,
				children: "Limpar"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: items.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 rounded-lg bg-surface p-2 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen(entry),
					className: "flex min-w-0 flex-1 items-center gap-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-12 shrink-0 overflow-hidden rounded-sm bg-surface-2",
						children: entry.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: entry.thumbnail,
							alt: "",
							className: "size-full object-cover",
							referrerPolicy: "no-referrer"
						}) : null
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium",
							children: entry.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: platformLabel(entry.platform)
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onRemove(entry.id),
					className: "flex size-10 items-center justify-center text-subtle hover:text-fg",
					"aria-label": "Remover",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
						className: "size-4",
						strokeWidth: 1.75
					})
				})]
			}, entry.id))
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PuroApp, {});
}
//#endregion
export { Home as component };
