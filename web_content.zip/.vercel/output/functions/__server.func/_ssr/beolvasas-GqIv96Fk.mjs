import { i as __toESM } from "../_runtime.mjs";
import { a as findCatalog, o as matchInstrument } from "./catalog-D0BjXlW4.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as createServerFn } from "./ssr.mjs";
import { n as usePortfolio, x as createSsrRpc } from "./router-Ddmv2GI8.mjs";
import { t as Shell } from "./shell-wztA7KjE.mjs";
import { f as formatQty, n as Field, o as Segmented, t as CLASS_LABEL } from "./format-Bbm5TEoT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/beolvasas-GqIv96Fk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CURRENCIES$1 = [
	"EUR",
	"USD",
	"HUF",
	"GBP"
];
var SAMPLE_STATEMENT = `Lightyear account statement
Period 01.09.2026 - 30.09.2026

Equities and ETFs
Vanguard FTSE All-World UCITS ETF USD Acc
IE00BK5BQT80 VWCE 12.5 170.44 EUR 2,130.50 EUR
iShares Core S&P 500 UCITS ETF
IE00B5BMR087 SXR8 3 740.78 EUR 2,222.34 EUR
OTP Bank Nyrt.
HU0000061726 OTP 15 42430 HUF 636450 HUF

Cash balances
EUR 540.20
USD 120.55
HUF 85000
`;
function parseNum(raw) {
	let value = raw.trim().replace(/\s/g, "");
	if (!value || !/[0-9]/.test(value)) return null;
	value = value.replace(/[^\d,.\-]/g, "");
	if (!value || value === "-" || value === "." || value === ",") return null;
	if (value.includes(",") && value.includes(".")) {
		if (value.lastIndexOf(",") > value.lastIndexOf(".")) value = value.replace(/\./g, "").replace(",", ".");
		else value = value.replace(/,/g, "");
	} else if (value.includes(",")) {
		const parts = value.split(",");
		if (parts.length === 2 && parts[1].length <= 2) value = `${parts[0]}.${parts[1]}`;
		else value = value.replace(",", ".");
	}
	const parsed = Number(value);
	return Number.isFinite(parsed) ? parsed : null;
}
function numericTokens(text, isin) {
	const out = [];
	for (const token of text.split(/\s+/)) {
		const clean = token.replace(/[()]/g, "").replace(/,$/, "");
		if (!clean || clean.toUpperCase() === isin) continue;
		if (/^[A-Z]{2}[A-Z0-9]{10}$/i.test(clean)) continue;
		if (/^(EUR|USD|HUF|GBP)$/i.test(clean)) continue;
		if (!/[0-9]/.test(clean)) continue;
		const parsed = parseNum(clean);
		if (parsed != null && parsed >= 0) out.push(parsed);
	}
	return out;
}
function lastCurrency(text) {
	const matches = [...text.toUpperCase().matchAll(/\b(EUR|USD|HUF|GBP)\b/g)];
	if (!matches.length) return null;
	return matches[matches.length - 1][1];
}
function interpret(nums) {
	let best = null;
	if (nums.length >= 3) for (let i = 0; i < nums.length; i += 1) for (let j = i + 1; j < nums.length; j += 1) for (let k = j + 1; k < nums.length; k += 1) {
		const qty = nums[i];
		const price = nums[j];
		const value = nums[k];
		if (qty <= 0 || price <= 0 || value <= 0) continue;
		const err = Math.abs(qty * price - value) / value;
		if (err < .08 && (!best || err < best.err)) best = {
			qty,
			price,
			err
		};
	}
	if (best) return {
		qty: best.qty,
		price: best.price
	};
	if (nums.length >= 2) {
		const price = nums[nums.length - 2];
		const value = nums[nums.length - 1];
		if (price > 0 && value > 0) return {
			qty: value / price,
			price
		};
	}
	if (nums.length === 1 && nums[0] > 0) return {
		qty: nums[0],
		price: 0
	};
	return null;
}
function guessTicker(text, isin) {
	const banned = /* @__PURE__ */ new Set([
		...CURRENCIES$1,
		"UCITS",
		"ETF",
		"USD",
		"ACC",
		"NYRT",
		"PLC"
	]);
	for (const token of text.toUpperCase().split(/[^A-Z0-9]+/)) {
		if (token.length < 2 || token.length > 8) continue;
		if (banned.has(token) || token === isin) continue;
		if (/^\d/.test(token)) continue;
		return token;
	}
	return null;
}
function parseStatement(text) {
	const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
	const rows = [];
	const seen = /* @__PURE__ */ new Set();
	for (let i = 0; i < lines.length; i += 1) {
		const isinMatch = lines[i].toUpperCase().match(/\b([A-Z]{2}[A-Z0-9]{10})\b/);
		if (!isinMatch) continue;
		const isin = isinMatch[1];
		const blob = [
			lines[i - 1],
			lines[i],
			lines[i + 1]
		].filter(Boolean).join(" ");
		const instrument = matchInstrument(isin, blob);
		const numbers = interpret(numericTokens(blob, isin));
		if (!numbers) continue;
		const currency = lastCurrency(blob) ?? instrument?.currency ?? "EUR";
		const symbol = instrument?.symbol ?? guessTicker(blob, isin) ?? isin;
		const name = instrument?.name ?? (lines[i - 1] && !lines[i - 1].toUpperCase().includes(isin) ? lines[i - 1] : symbol);
		const assetClass = instrument?.assetClass ?? "reszveny";
		const key = `${symbol}:${isin}`;
		if (seen.has(key)) continue;
		seen.add(key);
		rows.push({
			key,
			symbol,
			name,
			assetClass,
			currency,
			quantity: numbers.qty,
			price: numbers.price > 0 ? numbers.price : null,
			isin,
			warning: instrument ? void 0 : "Ismeretlen ISIN, nézd meg a szimbólumot."
		});
	}
	for (const line of lines) {
		const match = line.toUpperCase().match(/^(EUR|USD|GBP|HUF)\s+([0-9][0-9\s.,]*)$/);
		if (!match) continue;
		const currency = match[1];
		const amount = parseNum(match[2]);
		if (amount == null || amount < 0) continue;
		const key = `cash:${currency}:${amount}`;
		if (seen.has(`cash:${currency}`)) continue;
		seen.add(`cash:${currency}`);
		rows.push({
			key,
			symbol: currency,
			name: `Készpénz (${currency})`,
			assetClass: "keszpenz",
			currency,
			quantity: amount,
			price: 1
		});
	}
	return rows;
}
var CLASSES = /* @__PURE__ */ new Set([
	"etf",
	"reszveny",
	"kripto",
	"keszpenz"
]);
var CURRENCIES = /* @__PURE__ */ new Set([
	"HUF",
	"USD",
	"EUR",
	"GBP"
]);
function splitCsvLine(line) {
	const cells = [];
	let current = "";
	let quoted = false;
	for (let i = 0; i < line.length; i += 1) {
		const char = line[i];
		if (quoted) {
			if (char === "\"" && line[i + 1] === "\"") {
				current += "\"";
				i += 1;
			} else if (char === "\"") quoted = false;
			else current += char;
		} else if (char === "\"") quoted = true;
		else if (char === ",") {
			cells.push(current.trim());
			current = "";
		} else current += char;
	}
	cells.push(current.trim());
	return cells;
}
function asCurrency(value, fallback) {
	const upper = (value ?? "").toUpperCase();
	return CURRENCIES.has(upper) ? upper : fallback;
}
function asClass(value, fallback) {
	const lower = (value ?? "").toLowerCase();
	if (lower === "stock" || lower === "részvény" || lower === "reszveny") return "reszveny";
	if (lower === "crypto" || lower === "kripto") return "kripto";
	if (lower === "cash" || lower === "készpénz" || lower === "keszpenz") return "keszpenz";
	if (CLASSES.has(lower)) return lower;
	return fallback;
}
function parseIbkr(text) {
	const lines = text.split(/\r?\n/).filter((line) => line.trim());
	let headers = null;
	const rows = [];
	for (const line of lines) {
		const cells = splitCsvLine(line);
		if (cells[0] !== "Positions") continue;
		if (cells[1] === "Header") {
			headers = cells.map((cell) => cell.toLowerCase());
			continue;
		}
		if (cells[1] !== "Data" || !headers) continue;
		const discriminator = cells[2]?.toLowerCase();
		if (discriminator && discriminator !== "summary" && headers[2] === "datadiscriminator") continue;
		const pick = (name) => {
			const index = headers.findIndex((header) => header === name);
			return index >= 0 ? cells[index] : "";
		};
		const symbol = pick("symbol").toUpperCase();
		if (!symbol || symbol === "TOTAL" || symbol.includes("TOTAL")) continue;
		const quantity = parseNum(pick("quantity"));
		if (quantity == null || quantity === 0) continue;
		const currency = asCurrency(pick("currency"), "USD");
		const close = parseNum(pick("close price")) ?? parseNum(pick("market price"));
		const known = findCatalog(symbol);
		rows.push({
			key: `ibkr:${symbol}:${currency}`,
			symbol: known?.symbol ?? symbol,
			name: known?.name ?? symbol,
			assetClass: known?.assetClass ?? (pick("asset class").toLowerCase().includes("cash") ? "keszpenz" : "reszveny"),
			currency: known?.currency ?? currency,
			quantity: Math.abs(quantity),
			price: close,
			warning: known ? void 0 : "A szimbólum nincs a katalógusban."
		});
	}
	return rows;
}
function parseGenericCsv(text) {
	const lines = text.split(/\r?\n/).filter((line) => line.trim());
	if (!lines.length) return [];
	const headers = splitCsvLine(lines[0]).map((cell) => cell.toLowerCase());
	const index = (names) => headers.findIndex((header) => names.includes(header));
	const symbolIndex = index([
		"symbol",
		"szimbólum",
		"szimbolum",
		"ticker"
	]);
	const qtyIndex = index([
		"quantity",
		"qty",
		"mennyiség",
		"mennyiseg",
		"darab"
	]);
	if (symbolIndex < 0 || qtyIndex < 0) return [];
	const nameIndex = index([
		"name",
		"név",
		"nev"
	]);
	const classIndex = index([
		"assetclass",
		"class",
		"osztály",
		"osztaly"
	]);
	const currencyIndex = index([
		"currency",
		"deviza",
		"ccy"
	]);
	const priceIndex = index([
		"price",
		"ár",
		"ar",
		"close",
		"avgcost",
		"avg"
	]);
	const groupIndex = index(["group", "csoport"]);
	const rows = [];
	for (const line of lines.slice(1)) {
		const cells = splitCsvLine(line);
		const symbol = (cells[symbolIndex] ?? "").toUpperCase();
		const quantity = parseNum(cells[qtyIndex] ?? "");
		if (!symbol || quantity == null) continue;
		const known = findCatalog(symbol);
		const currency = asCurrency(cells[currencyIndex], known?.currency ?? "USD");
		rows.push({
			key: `csv:${symbol}:${cells[groupIndex] ?? ""}`,
			symbol,
			name: cells[nameIndex] || known?.name || symbol,
			assetClass: asClass(cells[classIndex], known?.assetClass ?? "reszveny"),
			currency,
			quantity,
			price: priceIndex >= 0 ? parseNum(cells[priceIndex] ?? "") : null,
			warning: cells[groupIndex] ? `Csoport a fájlban: ${cells[groupIndex]}` : void 0
		});
	}
	return rows;
}
function parseImportCsv(text) {
	if (/Positions\s*,\s*Header/i.test(text) || text.includes("\"Positions\"")) {
		const ibkr = parseIbkr(text);
		if (ibkr.length) return ibkr;
	}
	return parseGenericCsv(text);
}
function csvCell(value) {
	const text = String(value);
	if (/[",\n]/.test(text)) return `"${text.replace(/"/g, "\"\"")}"`;
	return text;
}
function holdingsCsv(state) {
	const lines = [[
		"symbol",
		"name",
		"assetClass",
		"currency",
		"group",
		"quantity",
		"avgCost",
		"costFxToHuf"
	].join(",")];
	for (const holding of state.holdings) {
		const group = state.groups.find((item) => item.id === holding.groupId)?.name ?? "";
		lines.push([
			holding.symbol,
			holding.name,
			holding.assetClass,
			holding.currency,
			group,
			holding.quantity,
			holding.avgCost,
			holding.costFxToHuf
		].map(csvCell).join(","));
	}
	return lines.join("\n");
}
function backupJson(state) {
	const { market, ...rest } = state;
	return JSON.stringify({
		app: "szamvetes",
		version: 1,
		state: {
			...rest,
			market: {
				...market,
				history: {},
				fxHistory: []
			}
		}
	}, null, 2);
}
async function extractPdfText(file) {
	if (typeof window === "undefined") throw new Error("A PDF-et csak a böngésző olvassa.");
	const pdfjs = await import("../_libs/pdfjs-dist.mjs").then((n) => n.t);
	const worker = await import("./pdf.worker.min-DMv0gVyV.mjs");
	pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
	const data = new Uint8Array(await file.arrayBuffer());
	const doc = await pdfjs.getDocument({ data }).promise;
	const lines = [];
	const pages = Math.min(doc.numPages, 12);
	for (let pageNumber = 1; pageNumber <= pages; pageNumber += 1) {
		const content = await (await doc.getPage(pageNumber)).getTextContent();
		let line = "";
		let lastY = null;
		for (const item of content.items) {
			if (!item.str) continue;
			const y = Math.round(item.transform?.[5] ?? 0);
			if (lastY != null && Math.abs(y - lastY) > 2) {
				if (line.trim()) lines.push(line.trim());
				line = "";
			}
			lastY = y;
			line = line ? `${line} ${item.str}` : item.str;
		}
		if (line.trim()) lines.push(line.trim());
	}
	return lines.join("\n");
}
function cleanWallet(input) {
	const data = input ?? {};
	const chain = data.chain;
	const address = String(data.address ?? "").trim();
	if (chain !== "bitcoin" && chain !== "ethereum" && chain !== "solana") throw new Error("Ismeretlen lánc.");
	if (chain === "bitcoin" && !/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{20,80}$/.test(address)) throw new Error("Ez nem tűnik bitcoin-címnek.");
	if (chain === "ethereum" && !/^0x[a-fA-F0-9]{40}$/.test(address)) throw new Error("Ez nem tűnik Ethereum-címnek.");
	if (chain === "solana" && !/^[1-9A-HJ-NP-Za-km-z]{32,48}$/.test(address)) throw new Error("Ez nem tűnik Solana-címnek.");
	return {
		chain,
		address
	};
}
var fetchWallet = createServerFn({ method: "POST" }).validator(cleanWallet).handler(createSsrRpc("f10aef7e15e94680c415da06279d97d0fec16a4ff627d5ce9f2f769cc5bdf235"));
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportPage, {}) });
}
function download(filename, content, type) {
	const blob = new Blob([content], { type });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
}
function ImportPage() {
	const { state, importRows, refresh, upsertWallet, importBackup } = usePortfolio();
	const [tab, setTab] = (0, import_react.useState)("lightyear");
	const [text, setText] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([]);
	const [picked, setPicked] = (0, import_react.useState)({});
	const [groups, setGroups] = (0, import_react.useState)({});
	const [mode, setMode] = (0, import_react.useState)("csere");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [chain, setChain] = (0, import_react.useState)("ethereum");
	const [address, setAddress] = (0, import_react.useState)("");
	const [walletGroup, setWalletGroup] = (0, import_react.useState)(state.groups.find((group) => group.kind === "kripto")?.id ?? state.groups[0]?.id ?? "");
	const [walletPreview, setWalletPreview] = (0, import_react.useState)(null);
	const defaultGroup = state.groups[0]?.id ?? "";
	const adopt = (parsed) => {
		setRows(parsed);
		const nextPick = {};
		const nextGroup = {};
		for (const row of parsed) {
			nextPick[row.key] = true;
			nextGroup[row.key] = defaultGroup;
		}
		setPicked(nextPick);
		setGroups(nextGroup);
		setNotice(parsed.length ? `${parsed.length} sor olvasva. Pipáld ki, amit átveszel.` : "Nem találtam állományt. Nézd meg a szöveget, vagy illeszd be kézzel.");
	};
	const readPdf = async (file) => {
		if (!file) return;
		setBusy(true);
		setNotice("");
		try {
			const extracted = await extractPdfText(file);
			setText(extracted);
			adopt(parseStatement(extracted));
		} catch (error) {
			setNotice(error instanceof Error ? `${error.message} Másold ki a szöveget, és illeszd be.` : "A PDF nem olvasható.");
		} finally {
			setBusy(false);
		}
	};
	const commitRows = () => {
		const items = rows.filter((row) => picked[row.key]).map((row) => ({
			row,
			groupId: groups[row.key] || defaultGroup
		}));
		if (!items.length) {
			setNotice("Nincs kijelölt sor.");
			return;
		}
		importRows(items, mode);
		setNotice(`${items.length} sor bekerült. A bekerülési ár új sornál a kivonat ára — írd át, ha tudod a valódit.`);
		refresh();
	};
	const lookupWallet = async () => {
		setBusy(true);
		setWalletPreview(null);
		setNotice("");
		try {
			const result = await fetchWallet({ data: {
				chain,
				address
			} });
			setWalletPreview({
				...result,
				address: address.trim()
			});
			setNotice("Csak a natív egyenleg jön le (BTC, ETH vagy SOL). A tokeneket kézzel vedd fel.");
		} catch (error) {
			setNotice(error instanceof Error ? error.message : "A tárca nem válaszolt.");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-3xl",
			children: "Beolvasás"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 max-w-2xl text-sm text-muted",
			children: "A PDF és a tárcacím a böngészőből indul, a kivonatot nem tároljuk a portfólión kívül. Az IBKR és a saját CSV ugyanide érkezik."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
				label: "Beolvasás típusa",
				value: tab,
				onChange: setTab,
				options: [
					{
						id: "lightyear",
						label: "Lightyear PDF"
					},
					{
						id: "tabla",
						label: "Kriptotárca"
					},
					{
						id: "csv",
						label: "CSV és mentés"
					}
				]
			})
		}),
		notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm",
			children: notice
		}) : null,
		tab === "lightyear" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Béta. A kivonat jelenlegi állományát olvassa, a régi vételeket nem. Válaszd ki a sorokat, és tedd őket csoportba."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "PDF a gépről",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field py-2 file:mr-3 file:rounded-md file:border-0 file:bg-pine file:px-3 file:py-2 file:text-sm file:text-on-pine",
						type: "file",
						accept: "application/pdf",
						onChange: (event) => void readPdf(event.target.files?.[0])
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Vagy a kivonat szövege",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field h-40 py-2",
						value: text,
						onChange: (event) => setText(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						disabled: busy,
						onClick: () => adopt(parseStatement(text)),
						children: "Szöveg olvasása"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => {
							setText(SAMPLE_STATEMENT);
							adopt(parseStatement(SAMPLE_STATEMENT));
						},
						children: "Minta-kivonat"
					})]
				})
			]
		}) : null,
		tab === "tabla" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 grid max-w-xl gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Lánc",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: chain,
						onChange: (event) => setChain(event.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "bitcoin",
								children: "Bitcoin"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "ethereum",
								children: "Ethereum"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "solana",
								children: "Solana"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Cím",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: address,
						onChange: (event) => setAddress(event.target.value),
						placeholder: "0x… vagy bc1…"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Csoport",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: walletGroup,
						onChange: (event) => setWalletGroup(event.target.value),
						children: state.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: group.id,
							children: group.name
						}, group.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary w-fit",
					disabled: busy || address.trim().length < 20,
					onClick: () => void lookupWallet(),
					children: "Egyenleg lekérése"
				}),
				walletPreview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-serif text-2xl tabular-nums",
							children: [
								formatQty(walletPreview.quantity),
								" ",
								walletPreview.symbol
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm break-all text-muted",
							children: walletPreview.address
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary mt-3",
							onClick: () => {
								upsertWallet({
									chain: walletPreview.chain,
									address: walletPreview.address,
									symbol: walletPreview.symbol,
									quantity: walletPreview.quantity,
									groupId: walletGroup
								});
								setNotice("A tárca egyenlege bekerült. A bekerülési ár a mostani ár, ha új sor.");
								refresh();
							},
							children: "Hozzáadom az állományhoz"
						})
					]
				}) : null
			]
		}) : null,
		tab === "csv" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "IBKR pozíció-CSV (Positions,Data sorok) vagy saját fejléc: symbol, quantity, és ha van, name, currency, price. A felhős szinkron helyett fájlt viszel magaddal."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "CSV",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field h-40 py-2",
						value: text,
						onChange: (event) => setText(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary",
							onClick: () => adopt(parseImportCsv(text)),
							children: "CSV olvasása"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => download("szamvetes-eszkozok.csv", holdingsCsv(state), "text/csv"),
							children: "Eszközök CSV-ben"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => download("szamvetes-mentes.json", backupJson(state), "application/json"),
							children: "Teljes mentés"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mentés visszatöltése",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field py-2",
						type: "file",
						accept: "application/json",
						onChange: async (event) => {
							const file = event.target.files?.[0];
							if (!file) return;
							try {
								importBackup(JSON.parse(await file.text()));
								setNotice("A mentés betöltve. Az árgörbét a következő frissítés hozza vissza.");
								refresh();
							} catch {
								setNotice("Ez a fájl nem Számvetés-mentés.");
							}
						}
					})
				})
			]
		}) : null,
		rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Átveendő sorok"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
						label: "Ha már megvan",
						value: mode,
						onChange: setMode,
						options: [{
							id: "csere",
							label: "Darab csere"
						}, {
							id: "hozzaad",
							label: "Hozzáad"
						}]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-line border-t border-line",
					children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-3 py-3 md:grid-cols-[auto_1fr_10rem]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									className: "size-5 accent-pine",
									checked: Boolean(picked[row.key]),
									onChange: (event) => setPicked((current) => ({
										...current,
										[row.key]: event.target.checked
									}))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Kijelölés"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								row.name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted",
									children: row.symbol
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									CLASS_LABEL[row.assetClass],
									" · ",
									formatQty(row.quantity),
									" ",
									row.currency,
									row.price != null ? ` · ár ${row.price}` : "",
									row.warning ? ` · ${row.warning}` : ""
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field",
								value: groups[row.key] ?? defaultGroup,
								onChange: (event) => setGroups((current) => ({
									...current,
									[row.key]: event.target.value
								})),
								children: state.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: group.id,
									children: group.name
								}, group.id))
							})
						]
					}, row.key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary mt-4",
					onClick: commitRows,
					children: "Kijelöltek felvétele"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-8 text-sm text-muted",
			children: [
				"A vételi napló a ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/mozgasok",
					className: "text-pine",
					children: "mozgások"
				}),
				" között van. Az IBKR-aktivitás részletes könyvelése még nincs meg, a pozíciólista igen."
			]
		})
	] });
}
//#endregion
export { Page as component };
