//#region node_modules/.nitro/vite/services/ssr/assets/web-device-D_Jv2ve6.js
function nav() {
	return navigator;
}
async function readBattery() {
	const getBattery = navigator.getBattery;
	if (typeof getBattery !== "function") return {
		percent: -1,
		charging: false,
		statusLabel: "Not available in this browser",
		healthLabel: "Android app shows real battery health",
		chargingTime: Infinity,
		dischargingTime: Infinity,
		source: "unavailable"
	};
	const battery = await getBattery.call(navigator);
	const percent = Math.round(battery.level * 100);
	return {
		percent,
		charging: battery.charging,
		statusLabel: battery.charging ? percent >= 100 ? "Full" : "Charging" : "Not charging",
		healthLabel: "Reported by the browser",
		chargingTime: battery.chargingTime,
		dischargingTime: battery.dischargingTime,
		source: "device"
	};
}
function subscribeBattery(onChange) {
	let battery = null;
	let cancelled = false;
	const handler = () => {
		if (!battery) return;
		const percent = Math.round(battery.level * 100);
		onChange({
			percent,
			charging: battery.charging,
			statusLabel: battery.charging ? percent >= 100 ? "Full" : "Charging" : "Not charging",
			healthLabel: "Reported by the browser",
			chargingTime: battery.chargingTime,
			dischargingTime: battery.dischargingTime,
			source: "device"
		});
	};
	const getBattery = navigator.getBattery;
	if (typeof getBattery === "function") getBattery.call(navigator).then((b) => {
		if (cancelled) return;
		battery = b;
		handler();
		b.addEventListener("chargingchange", handler);
		b.addEventListener("levelchange", handler);
	});
	else readBattery().then(onChange);
	return () => {
		cancelled = true;
		if (battery) {
			battery.removeEventListener("chargingchange", handler);
			battery.removeEventListener("levelchange", handler);
		}
	};
}
async function readStorage() {
	if (!nav().storage?.estimate) return {
		totalBytes: 0,
		usedBytes: 0,
		freeBytes: 0,
		source: "unavailable"
	};
	const estimate = await nav().storage.estimate();
	const total = estimate.quota ?? 0;
	const used = estimate.usage ?? 0;
	return {
		totalBytes: total,
		usedBytes: used,
		freeBytes: Math.max(0, total - used),
		source: "device"
	};
}
function readNetwork() {
	const online = nav().onLine;
	const connection = navigator.connection;
	const type = connection?.type || connection?.effectiveType;
	let typeLabel = "Unknown";
	if (!online) typeLabel = "Offline";
	else if (type === "wifi") typeLabel = "Wi-Fi";
	else if (type === "cellular") typeLabel = "Mobile data";
	else if (type === "ethernet") typeLabel = "Ethernet";
	else if (type === "4g" || type === "3g" || type === "2g" || type === "slow-2g") typeLabel = `Mobile (${type})`;
	else if (online) typeLabel = "Connected";
	const parts = [];
	if (connection?.effectiveType) parts.push(`Effective ${connection.effectiveType}`);
	if (typeof connection?.downlink === "number") parts.push(`${connection.downlink} Mbps`);
	if (connection?.saveData) parts.push("Data saver on");
	return {
		online,
		typeLabel,
		detail: parts.join(" · ") || (online ? "Browser connection is active" : "No network"),
		downlink: typeof connection?.downlink === "number" ? `${connection.downlink} Mbps` : "Not reported"
	};
}
function subscribeNetwork(onChange) {
	const fire = () => onChange(readNetwork());
	window.addEventListener("online", fire);
	window.addEventListener("offline", fire);
	const connection = navigator.connection;
	connection?.addEventListener?.("change", fire);
	fire();
	return () => {
		window.removeEventListener("online", fire);
		window.removeEventListener("offline", fire);
		connection?.removeEventListener?.("change", fire);
	};
}
async function readDevice() {
	const ua = nav().userAgent;
	const uaData = navigator.userAgentData;
	let model = uaData?.model || "";
	let platform = uaData?.platform || nav().platform || "Unknown";
	let platformVersion = uaData?.platformVersion || "";
	if (uaData?.getHighEntropyValues) try {
		const extra = await uaData.getHighEntropyValues([
			"model",
			"platform",
			"platformVersion",
			"architecture"
		]);
		model = extra.model || model;
		platform = extra.platform || platform;
		platformVersion = extra.platformVersion || platformVersion;
	} catch {}
	const androidMatch = ua.match(/Android\s+([\d.]+)/i);
	const androidVersion = androidMatch ? androidMatch[1] : platformVersion || parseGenericOs(ua);
	const sdk = androidMatch ? androidApiFromRelease(androidMatch[1]) : "—";
	if (!model) model = ua.match(/;\s*([^;)]+?)\s+Build\//i)?.[1]?.trim() || guessBrowserName(ua);
	const cores = nav().hardwareConcurrency ? String(nav().hardwareConcurrency) : "—";
	const memory = navigator.deviceMemory ? `${navigator.deviceMemory} GB` : "—";
	return {
		model,
		manufacturer: inferManufacturer(model, ua),
		androidVersion,
		sdk,
		platform,
		cores,
		memory,
		screen: `${window.screen.width} × ${window.screen.height}`
	};
}
function parseGenericOs(ua) {
	if (/Windows NT 10/i.test(ua)) return "Windows 10+";
	if (/Mac OS X/i.test(ua)) return "macOS";
	if (/iPhone|iPad/i.test(ua)) return "iOS";
	if (/Linux/i.test(ua)) return "Linux";
	return "Unknown";
}
function guessBrowserName(ua) {
	if (/Edg\//.test(ua)) return "Edge browser";
	if (/Chrome\//.test(ua)) return "Chrome browser";
	if (/Firefox\//.test(ua)) return "Firefox browser";
	if (/Safari\//.test(ua)) return "Safari browser";
	return "This device";
}
function inferManufacturer(model, ua) {
	const blob = `${model} ${ua}`.toLowerCase();
	if (blob.includes("samsung") || blob.includes("sm-")) return "Samsung";
	if (blob.includes("pixel") || blob.includes("google")) return "Google";
	if (blob.includes("xiaomi") || blob.includes("redmi") || blob.includes("poco")) return "Xiaomi";
	if (blob.includes("oneplus") || blob.includes("oppo") || blob.includes("realme")) return "OPPO / OnePlus";
	if (blob.includes("huawei") || blob.includes("honor")) return "Huawei";
	if (blob.includes("motorola") || blob.includes("moto")) return "Motorola";
	if (blob.includes("iphone") || blob.includes("ipad") || blob.includes("macintosh")) return "Apple";
	if (blob.includes("windows")) return "PC";
	return "Unknown";
}
function androidApiFromRelease(release) {
	const major = Number(release.split(".")[0]);
	const map = {
		8: 26,
		9: 28,
		10: 29,
		11: 30,
		12: 31,
		13: 33,
		14: 34,
		15: 35,
		16: 36
	};
	return map[major] ? String(map[major]) : "—";
}
function formatDuration(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "—";
	if (seconds === Infinity) return "—";
	const h = Math.floor(seconds / 3600);
	const m = Math.floor(seconds % 3600 / 60);
	if (h > 48) return "—";
	if (h > 0) return `${h}h ${m}m`;
	return `${m} min`;
}
//#endregion
export { subscribeNetwork as a, subscribeBattery as i, readDevice as n, readStorage as r, formatDuration as t };
