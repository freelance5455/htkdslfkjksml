import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Smartphone, l as Download, o as FolderOpen, u as ChevronRight } from "../_libs/lucide-react.mjs";
import { n as ScreenBody, t as AppShell } from "./app-shell-BNnfZJ-W.mjs";
import { i as ScreenHeader } from "./screen-header-3v0iR4cd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-DBJczr09.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tree = `VishalTools/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradlew / gradlew.bat
├── gradle/wrapper/
├── README.md
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/vishal/tools/
        │   ├── MainActivity.kt
        │   ├── VishalToolsApp.kt
        │   ├── tools/
        │   └── ui/theme, components, screens
        └── res/`;
function StudioPage() {
	const [files, setFiles] = (0, import_react.useState)([]);
	const [openPath, setOpenPath] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		fetch("/android-source.json").then((r) => r.json()).then((data) => {
			const list = [...data.files].sort((a, b) => a.path.localeCompare(b.path));
			setFiles(list);
			setOpenPath(list.find((f) => f.path.endsWith("MainActivity.kt"))?.path ?? list[0]?.path ?? null);
		}).catch(() => setFiles([]));
	}, []);
	const active = (0, import_react.useMemo)(() => files.find((f) => f.path === openPath) ?? null, [files, openPath]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Build the Android app",
			subtitle: "Download the complete Kotlin project, open it in Android Studio, then install the APK on your phone."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: "/vishal-tools-android.zip",
			download: "VishalTools-android.zip",
			className: "flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-primary px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download VishalTools.zip"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-center text-xs text-muted",
			children: "Complete Android Studio project · Kotlin + Compose"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-card bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center gap-2 text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold uppercase tracking-wider",
					children: "Open in Android Studio"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "list-decimal space-y-3 pl-5 text-sm leading-relaxed text-fg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Install Android Studio from developer.android.com/studio if you do not have it yet." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Unzip ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: "VishalTools-android.zip"
						}),
						". You should see a folder named VishalTools that contains settings.gradle.kts."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In Android Studio choose File → Open… and select that VishalTools folder." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Wait for Gradle Sync. If it asks for a JDK, pick the bundled JBR 17." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "If it offers to upgrade the Android Gradle Plugin, you can accept." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Start an emulator (Device Manager) or plug in a phone with USB debugging." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Press the green Run button." })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-3.5 rounded-card bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center gap-2 text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold uppercase tracking-wider",
						children: "Build the APK"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm leading-relaxed text-fg",
					children: [
						"In Android Studio go to ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Build → Build Bundle(s) / APK(s) → Build APK(s)"
						}),
						". When it finishes, click Locate."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 rounded-xl bg-elevated px-3.5 py-3 font-mono text-xs leading-relaxed text-primary",
					children: "VishalTools/app/build/outputs/apk/debug/app-debug.apk"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: "Copy that file to your phone and open it to install. Android may ask you to allow installing from Files. That debug APK is for you — not for the Play Store."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-fg",
					children: "From the Android Studio Terminal tab you can also run:"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 rounded-xl bg-elevated px-3.5 py-3 font-mono text-xs text-primary",
					children: "./gradlew assembleDebug"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "Windows: gradlew.bat assembleDebug"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-3.5 rounded-card bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold uppercase tracking-wider text-primary",
				children: "What each part does"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "MainActivity.kt"
					}), " — starts the app and loads Compose."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "VishalToolsApp.kt"
					}), " — dark shell and screen navigation."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "tools/"
					}), " — reads battery, storage, device, flashlight, network."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "ui/screens/"
					}), " — one Kotlin file per tool, easier to learn."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "AndroidManifest.xml"
					}), " — only camera + network-state permissions."] })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mt-3.5 overflow-x-auto rounded-card bg-elevated p-4 text-xs leading-relaxed text-muted",
			children: tree
		}),
		files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-3.5 rounded-card bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold uppercase tracking-wider text-primary",
					children: "Project files"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Tap a file to read the complete source."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 max-h-52 overflow-y-auto rounded-xl bg-elevated",
					children: files.map((file) => {
						const selected = file.path === openPath;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setOpenPath(file.path),
							className: `flex w-full items-center gap-2 px-3 py-2.5 text-left text-xs ${selected ? "bg-primary/15 text-primary" : "text-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: `size-3.5 shrink-0 ${selected ? "text-primary" : "text-muted"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate font-mono",
								children: file.path
							})]
						}, file.path);
					})
				}),
				active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 max-h-80 overflow-auto rounded-xl bg-bg p-3 font-mono text-[11px] leading-relaxed text-muted",
					children: active.content
				}) : null
			]
		}) : null
	] }) });
}
//#endregion
export { StudioPage as component };
