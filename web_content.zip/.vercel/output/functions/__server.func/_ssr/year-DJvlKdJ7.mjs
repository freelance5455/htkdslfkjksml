import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { g as ChevronLeft, h as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as format } from "../_libs/date-fns.mjs";
import { C as parseMonth, d as inkOn, i as usePlanner, k as cn, p as monthTone, v as useTodayKey, x as monthKey } from "./router-CQnHyG8o.mjs";
import { n as Card, o as IconButton, r as CardTitle, s as PageHeader } from "./primitives-DM2UCvsE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/year-DJvlKdJ7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function YearView() {
	const today = useTodayKey();
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const active = cursor ?? (today ? today.slice(0, 4) : null);
	if (!active || !today) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		section: "year",
		title: "Year",
		lede: "Opening the year."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(YearPage, {
		yearId: active,
		today,
		onYear: setCursor
	});
}
function YearPage({ yearId, today, onYear }) {
	const year = usePlanner((s) => s.years[yearId]);
	const months = usePlanner((s) => s.months);
	const patchYear = usePlanner((s) => s.patchYear);
	const word = year?.word ?? "";
	const note = year?.note ?? "";
	const quarters = year?.quarters ?? [
		{
			q: 1,
			intention: ""
		},
		{
			q: 2,
			intention: ""
		},
		{
			q: 3,
			intention: ""
		},
		{
			q: 4,
			intention: ""
		}
	];
	const currentYear = today.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			section: "year",
			title: yearId,
			lede: "A word to steer by, and a door for each month.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Previous year",
					onClick: () => onYear(String(Number(yearId) - 1)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
						className: "size-5",
						strokeWidth: 1.6
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Next year",
					onClick: () => onYear(String(Number(yearId) + 1)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
						className: "size-5",
						strokeWidth: 1.6
					})
				})]
			})
		}),
		yearId !== currentYear ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-4 text-sm font-medium text-accent",
			onClick: () => onYear(null),
			children: "This year"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Word of the year" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: word,
						onChange: (event) => patchYear(yearId, (y) => ({
							...y,
							word: event.target.value
						})),
						placeholder: "One word",
						className: "h-14 w-full bg-transparent font-display text-4xl outline-none placeholder:text-muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: note,
						onChange: (event) => patchYear(yearId, (y) => ({
							...y,
							note: event.target.value
						})),
						placeholder: "A short letter to the year ahead.",
						rows: 4,
						className: "mt-2 min-h-24 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: quarters.map((quarter, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: `Quarter ${quarter.q}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: quarter.intention,
						onChange: (event) => patchYear(yearId, (y) => ({
							...y,
							quarters: y.quarters.map((item, i) => i === index ? {
								...item,
								intention: event.target.value
							} : item)
						})),
						placeholder: "What this season is for.",
						rows: 3,
						className: "min-h-20 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
					})] }, quarter.q))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
					children: Array.from({ length: 12 }, (_, index) => {
						const key = monthKey(new Date(Number(yearId), index, 1));
						const log = months[key];
						const tone = monthTone(key, log?.color);
						const fg = inkOn(tone);
						const current = today.slice(0, 7) === key;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/month",
							search: { m: key },
							className: cn("flex min-h-28 flex-col justify-between rounded-3xl p-4", current && "ring-2 ring-ink"),
							style: {
								background: tone,
								color: fg
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: format(parseMonth(key), "MMMM")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-lg leading-snug text-balance",
								children: log?.intention?.trim() || "Open month"
							})]
						}, key);
					})
				})
			]
		})
	] });
}
var SplitComponent = YearView;
//#endregion
export { SplitComponent as component };
