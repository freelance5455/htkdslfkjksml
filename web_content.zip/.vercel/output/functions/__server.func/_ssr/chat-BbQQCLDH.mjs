import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Route$2 } from "./router-DCIqO0dN.mjs";
import { n as ChatOverlay } from "./panels-aiwxz-g9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-BbQQCLDH.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const look = Route$2.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatOverlay, { look });
}
//#endregion
export { Page as component };
