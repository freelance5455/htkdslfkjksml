import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Flower2, i as House, n as Scale, o as CircleDot, r as NotebookPen, s as Check } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-lFIehA1M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GOALS = [
	108,
	500,
	1e3,
	3e3,
	1e4
];
var SIT_MINUTES = [
	5,
	10,
	15,
	20,
	30,
	45
];
var MANTRAS = [
	{
		id: "amitabha",
		name: "南無阿彌陀佛",
		text: "南無阿彌陀佛"
	},
	{
		id: "guanyin",
		name: "南無觀世音菩薩",
		text: "南無觀世音菩薩"
	},
	{
		id: "ksitigarbha",
		name: "南無地藏菩薩",
		text: "南無地藏菩薩"
	},
	{
		id: "mani",
		name: "六字大明咒",
		text: "嗡嘛呢唄咪吽"
	}
];
var MERITS = [
	{
		id: "help",
		label: "助人",
		points: 3,
		hint: "具體幫了別人一個忙"
	},
	{
		id: "give",
		label: "布施",
		points: 5,
		hint: "錢財、時間，或一句好話"
	},
	{
		id: "patience",
		label: "忍辱",
		points: 3,
		hint: "火起來了，沒有發出去"
	},
	{
		id: "family",
		label: "孝親",
		points: 5,
		hint: "照料，或好好聽家人說話"
	},
	{
		id: "honest",
		label: "誠實",
		points: 2,
		hint: "本可以圓過去，但沒有"
	},
	{
		id: "early",
		label: "早起",
		points: 2,
		hint: "比習慣更早起來"
	},
	{
		id: "meal",
		label: "素食",
		points: 2,
		hint: "這一餐沒有傷生"
	},
	{
		id: "read",
		label: "讀經",
		points: 3,
		hint: "讀了一段經或論"
	},
	{
		id: "speech",
		label: "好話",
		points: 2,
		hint: "讚歎、安慰，或止住是非"
	},
	{
		id: "body",
		label: "惜身",
		points: 2,
		hint: "喝水、走動，沒有暴食"
	},
	{
		id: "other-m",
		label: "其他善",
		points: 1,
		hint: "一件小小的善"
	}
];
var FAULTS = [
	{
		id: "lie",
		label: "妄語",
		points: 3,
		hint: "說了不實的話"
	},
	{
		id: "anger",
		label: "嗔心",
		points: 3,
		hint: "對人發怒，或心裡罵人"
	},
	{
		id: "greed",
		label: "貪念",
		points: 2,
		hint: "抓著不放，明知不必"
	},
	{
		id: "sloth",
		label: "懈怠",
		points: 2,
		hint: "該做的事一再拖過"
	},
	{
		id: "waste",
		label: "浪費",
		points: 2,
		hint: "食物、時間或金錢"
	},
	{
		id: "harsh",
		label: "惡口",
		points: 3,
		hint: "話刺傷了人"
	},
	{
		id: "distract",
		label: "散亂",
		points: 1,
		hint: "明明要修，心卻跑掉了"
	},
	{
		id: "other-f",
		label: "其他過",
		points: 1,
		hint: "一件想記得的過失"
	}
];
var VOW_PRESETS = [
	"願我今日身口意清淨，不傷害任何人。",
	"願我看見習氣的時候，先停一下再回應。",
	"願我對身邊的人多一分耐心。",
	"願我好好吃飯、喝水、休息，珍惜這個身體。",
	"願今日做的小事，都能利益眾生。"
];
var DEDICATION_PRESETS = [
	"願此功德，回向一切眾生離苦得樂。",
	"願我的家人平安，煩惱輕一點。",
	"願今天的過失到此為止，明天重新開始。"
];
var LINES = [
	"不必一次改掉一生，先改掉這一念。",
	"早起的發願，是給今天一個方向。",
	"功過不是打分數，是看清自己。",
	"感恩把心從缺乏裡帶回眼前。",
	"靜坐不是清空，是讓念頭自己走過去。",
	"一句佛號，把散掉的心收回來。",
	"做得少沒關係，記得做就有用。",
	"對自己誠實，比看起來精進更要緊。"
];
var EMPTY_GRATITUDE = {
	items: [
		"",
		"",
		""
	],
	reflection: "",
	dedication: "",
	updatedAt: 0
};
var WEEK = [
	"週日",
	"週一",
	"週二",
	"週三",
	"週四",
	"週五",
	"週六"
];
function todayKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function shiftDate(key, delta) {
	const [y, m, d] = key.split("-").map(Number);
	const dt = new Date(y, (m ?? 1) - 1, d ?? 1);
	dt.setDate(dt.getDate() + delta);
	return todayKey(dt);
}
function labelOfKey(key, now = /* @__PURE__ */ new Date()) {
	const [y, m, d] = key.split("-").map(Number);
	const week = WEEK[new Date(y, (m ?? 1) - 1, d ?? 1).getDay()] ?? "";
	if (y !== now.getFullYear()) return `${y}年${m}月${d}日 ${week}`;
	return `${m}月${d}日 ${week}`;
}
function formatChineseDate(d = /* @__PURE__ */ new Date()) {
	return `${d.getMonth() + 1}月${d.getDate()}日 ${WEEK[d.getDay()]}`;
}
function formatClock(ms) {
	const total = Math.max(0, Math.ceil(ms / 1e3));
	const m = Math.floor(total / 60);
	const s = total % 60;
	return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function formatTime(ts) {
	const d = new Date(ts);
	return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function formatMinutes(seconds) {
	const m = Math.max(0, Math.round(seconds / 60));
	if (m < 60) return `${m} 分鐘`;
	const h = Math.floor(m / 60);
	const r = m % 60;
	return r ? `${h} 小時 ${r} 分` : `${h} 小時`;
}
function dayPart(d = /* @__PURE__ */ new Date()) {
	const h = d.getHours();
	if (h < 11) return "morning";
	if (h < 17) return "day";
	return "evening";
}
function greeting(part) {
	if (part === "morning") return {
		title: "早安",
		sub: "先給今天一個方向。"
	};
	if (part === "day") return {
		title: "今日",
		sub: "心放在這一念就好。"
	};
	return {
		title: "晚安",
		sub: "把今天好好放下。"
	};
}
function lineFor(dateKey) {
	const n = Number(dateKey.replaceAll("-", ""));
	return LINES[Number.isFinite(n) ? Math.abs(n) % LINES.length : 0] ?? LINES[0];
}
function dayCounts(map, date) {
	return map[date] ?? {};
}
function sumCounts(counts) {
	return Object.values(counts).reduce((n, v) => n + v, 0);
}
function mantraTotal(map, id) {
	let n = 0;
	for (const day of Object.values(map)) n += day[id] ?? 0;
	return n;
}
function allTotal(map) {
	let n = 0;
	for (const day of Object.values(map)) n += sumCounts(day);
	return n;
}
function lastDays(n, today = todayKey()) {
	const keys = [];
	for (let i = n - 1; i >= 0; i--) keys.push(shiftDate(today, -i));
	return keys;
}
function netOf(entries) {
	return entries.reduce((n, e) => n + (e.kind === "merit" ? e.points : -e.points), 0);
}
function formatNet(n) {
	if (n > 0) return `+${n}`;
	if (n < 0) return `−${Math.abs(n)}`;
	return "0";
}
function gratitudeDone(g) {
	if (!g) return false;
	return g.items.some((item) => item.trim().length > 0);
}
function isPracticed(input, date) {
	if (sumCounts(dayCounts(input.chantByDate, date)) > 0) return true;
	if ((input.vows[date] ?? "").trim()) return true;
	if (gratitudeDone(input.gratitudes[date])) return true;
	if (input.sits.some((sit) => sit.date === date && sit.seconds >= 30)) return true;
	if (input.merits.some((entry) => entry.date === date)) return true;
	return false;
}
function streakOf(input, today = todayKey()) {
	let cursor = isPracticed(input, today) ? today : shiftDate(today, -1);
	let n = 0;
	while (isPracticed(input, cursor)) {
		n += 1;
		cursor = shiftDate(cursor, -1);
		if (n > 5e3) break;
	}
	return n;
}
function clampText(value, max) {
	return [...value].slice(0, max).join("");
}
var memoryStorage = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
var usePractice = create()(persist((set) => ({
	selectedMantra: "amitabha",
	customMantra: "",
	savedMantras: [],
	dailyChantGoal: 108,
	woodOn: true,
	bellOn: true,
	breathGuide: true,
	chantByDate: {},
	merits: [],
	vows: {},
	gratitudes: {},
	sits: [],
	addChant: (mantraId, n) => set((s) => {
		const date = todayKey();
		const day = { ...s.chantByDate[date] ?? {} };
		const next = Math.max(0, (day[mantraId] ?? 0) + n);
		if (next === 0) delete day[mantraId];
		else day[mantraId] = next;
		return { chantByDate: {
			...s.chantByDate,
			[date]: day
		} };
	}),
	setSelectedMantra: (id) => set({ selectedMantra: id }),
	setCustomMantra: (text) => set({ customMantra: clampText(text, 40) }),
	addSavedMantra: (text) => {
		const next = clampText(text.trim(), 40);
		let id = "";
		set((s) => {
			if (!next || s.savedMantras.length >= 4) return s;
			const existing = s.savedMantras.find((item) => item.text === next);
			if (existing) {
				id = existing.id;
				return s;
			}
			id = "c-" + crypto.randomUUID();
			return { savedMantras: [...s.savedMantras, {
				id,
				text: next
			}] };
		});
		return id;
	},
	removeSavedMantra: (id) => set((s) => ({
		savedMantras: s.savedMantras.filter((item) => item.id !== id),
		selectedMantra: s.selectedMantra === id ? "amitabha" : s.selectedMantra
	})),
	setGoal: (n) => set({ dailyChantGoal: n }),
	setWoodOn: (on) => set({ woodOn: on }),
	setBellOn: (on) => set({ bellOn: on }),
	setBreathGuide: (on) => set({ breathGuide: on }),
	addMerit: (input) => set((s) => ({ merits: [{
		id: crypto.randomUUID(),
		date: todayKey(),
		kind: input.kind,
		categoryId: input.categoryId,
		label: input.label,
		points: input.points,
		note: clampText(input.note.trim(), 80),
		at: Date.now()
	}, ...s.merits].slice(0, 400) })),
	removeMerit: (id) => set((s) => ({ merits: s.merits.filter((e) => e.id !== id) })),
	setVow: (date, text) => set((s) => {
		const vows = { ...s.vows };
		const next = clampText(text, 160);
		if (!next.trim()) delete vows[date];
		else vows[date] = next;
		return { vows };
	}),
	setGratitude: (date, patch) => set((s) => {
		const prev = s.gratitudes[date] ?? EMPTY_GRATITUDE;
		const next = {
			items: patch.items ? patch.items.map((item) => clampText(item, 80)) : prev.items,
			reflection: patch.reflection !== void 0 ? clampText(patch.reflection, 240) : prev.reflection,
			dedication: patch.dedication !== void 0 ? clampText(patch.dedication, 80) : prev.dedication,
			updatedAt: Date.now()
		};
		const meaningful = next.items.some((item) => item.trim()) || next.reflection.trim() || next.dedication.trim();
		const gratitudes = { ...s.gratitudes };
		if (!meaningful) delete gratitudes[date];
		else gratitudes[date] = next;
		return { gratitudes };
	}),
	addSit: (input) => set((s) => ({ sits: [{
		id: crypto.randomUUID(),
		date: todayKey(),
		seconds: input.seconds,
		planned: input.planned,
		finished: input.finished,
		at: Date.now()
	}, ...s.sits].slice(0, 400) }))
}), {
	name: "xintian-v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage : localStorage),
	partialize: (s) => ({
		selectedMantra: s.selectedMantra,
		customMantra: s.customMantra,
		savedMantras: s.savedMantras,
		dailyChantGoal: s.dailyChantGoal,
		woodOn: s.woodOn,
		bellOn: s.bellOn,
		breathGuide: s.breathGuide,
		chantByDate: s.chantByDate,
		merits: s.merits,
		vows: s.vows,
		gratitudes: s.gratitudes,
		sits: s.sits
	}),
	version: 1,
	migrate: (persisted) => {
		const state = persisted;
		if (!state.savedMantras) state.savedMantras = [];
		const legacy = state.customMantra?.trim();
		if (legacy && !state.savedMantras.some((item) => item.text === legacy) && state.savedMantras.length < 4) {
			const id = "c-legacy";
			state.savedMantras = [{
				id,
				text: legacy.slice(0, 40)
			}, ...state.savedMantras];
			if (state.selectedMantra === "custom") state.selectedMantra = id;
			if (state.chantByDate) for (const day of Object.values(state.chantByDate)) {
				if (!day.custom) continue;
				day[id] = (day[id] ?? 0) + day.custom;
				delete day.custom;
			}
		}
		return state;
	}
}));
var useSit = create((set, get) => ({
	phase: "idle",
	plannedSec: 600,
	endsAt: null,
	remainMs: 0,
	logged: false,
	elapsedSec: 0,
	start: (minutes) => set({
		phase: "running",
		plannedSec: minutes * 60,
		endsAt: Date.now() + minutes * 60 * 1e3,
		remainMs: minutes * 60 * 1e3,
		logged: false,
		elapsedSec: 0
	}),
	pause: () => {
		const s = get();
		if (s.phase !== "running" || s.endsAt == null) return;
		set({
			phase: "paused",
			remainMs: Math.max(0, s.endsAt - Date.now()),
			endsAt: null
		});
	},
	resume: () => {
		const s = get();
		if (s.phase !== "paused") return;
		set({
			phase: "running",
			endsAt: Date.now() + s.remainMs
		});
	},
	end: (mode) => {
		const s = get();
		if (s.phase === "idle") return;
		if (mode === "discard") {
			set({
				phase: "idle",
				logged: false,
				endsAt: null,
				remainMs: 0,
				elapsedSec: 0
			});
			return;
		}
		if (s.logged && s.phase === "done") return;
		const remain = s.phase === "running" && s.endsAt != null ? Math.max(0, s.endsAt - Date.now()) : s.remainMs;
		const seconds = mode === "complete" ? s.plannedSec : Math.max(0, Math.round((s.plannedSec * 1e3 - remain) / 1e3));
		if (!s.logged && seconds >= 30) usePractice.getState().addSit({
			seconds,
			planned: s.plannedSec,
			finished: mode === "complete"
		});
		set({
			phase: "done",
			logged: seconds >= 30,
			endsAt: null,
			remainMs: 0,
			elapsedSec: seconds
		});
	},
	close: () => set({
		phase: "idle",
		logged: false,
		endsAt: null,
		remainMs: 0,
		elapsedSec: 0
	})
}));
var ctx = null;
function audio() {
	if (typeof window === "undefined") return null;
	if (!ctx) ctx = new AudioContext();
	if (ctx.state === "suspended") ctx.resume();
	return ctx;
}
function woodClick() {
	const c = audio();
	if (!c) return;
	const t = c.currentTime;
	const osc = c.createOscillator();
	const gain = c.createGain();
	const filter = c.createBiquadFilter();
	osc.type = "sine";
	osc.frequency.setValueAtTime(480, t);
	osc.frequency.exponentialRampToValueAtTime(160, t + .05);
	filter.type = "lowpass";
	filter.frequency.setValueAtTime(900, t);
	gain.gain.setValueAtTime(1e-4, t);
	gain.gain.exponentialRampToValueAtTime(.18, t + .006);
	gain.gain.exponentialRampToValueAtTime(1e-4, t + .09);
	osc.connect(filter);
	filter.connect(gain);
	gain.connect(c.destination);
	osc.start(t);
	osc.stop(t + .1);
}
function bowlBell() {
	const c = audio();
	if (!c) return;
	const t = c.currentTime;
	[
		1,
		2,
		2.76,
		5.4
	].forEach((partial, index) => {
		const osc = c.createOscillator();
		const gain = c.createGain();
		osc.type = "sine";
		osc.frequency.value = 196 * partial;
		const amp = .1 / (1 + index);
		gain.gain.setValueAtTime(amp, t);
		gain.gain.exponentialRampToValueAtTime(1e-4, t + 3.4);
		osc.connect(gain);
		gain.connect(c.destination);
		osc.start(t);
		osc.stop(t + 3.5);
	});
}
function tapHaptic() {
	if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") navigator.vibrate(12);
}
var field = "w-full rounded-md border border-line bg-paper px-3 py-3 text-base text-fg outline-none placeholder:text-mute focus:border-cinnabar";
function chip(on) {
	return "min-h-11 rounded-md border px-3 text-sm " + (on ? "border-cinnabar bg-paper-2 text-fg" : "border-line bg-transparent text-mute");
}
var primaryBtn = "inline-flex h-12 items-center justify-center rounded-md bg-cinnabar px-4 font-medium text-ink disabled:opacity-40";
var quietBtn = "inline-flex min-h-11 items-center justify-center rounded-md border border-line bg-transparent px-3 text-sm text-fg disabled:opacity-40";
var PITCH = 58;
var AROUND = 14;
var STEP = Math.PI * 2 / AROUND;
function BeadStrand({ count, onCount }) {
	const stageRef = (0, import_react.useRef)(null);
	const [box, setBox] = (0, import_react.useState)({
		w: 320,
		h: 272
	});
	const [shown, setShown] = (0, import_react.useState)(count);
	const [rest, setRest] = (0, import_react.useState)(0);
	const shownRef = (0, import_react.useRef)(count);
	const restRef = (0, import_react.useRef)(0);
	const dragging = (0, import_react.useRef)(false);
	const lastY = (0, import_react.useRef)(null);
	const moved = (0, import_react.useRef)(0);
	const frame = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		const el = stageRef.current;
		if (!el) return;
		const measure = () => setBox({
			w: el.clientWidth,
			h: el.clientHeight
		});
		measure();
		const observer = new ResizeObserver(measure);
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		if (dragging.current) return;
		shownRef.current = count;
		setShown(count);
	}, [count]);
	(0, import_react.useEffect)(() => () => cancelAnimationFrame(frame.current), []);
	function commitSteps(steps) {
		if (steps <= 0) return;
		shownRef.current += steps;
		setShown(shownRef.current);
		onCount(steps);
	}
	function push(dy) {
		let next = restRef.current + dy;
		let steps = 0;
		while (next >= PITCH) {
			next -= PITCH;
			steps += 1;
		}
		restRef.current = next;
		setRest(next);
		commitSteps(steps);
	}
	function animateTo(target, done) {
		cancelAnimationFrame(frame.current);
		const from = restRef.current;
		const start = performance.now();
		const tick = (now) => {
			const p = Math.min(1, (now - start) / 240);
			const eased = 1 - (1 - p) ** 3;
			const value = from + (target - from) * eased;
			restRef.current = value;
			setRest(value);
			if (p < 1) frame.current = requestAnimationFrame(tick);
			else done?.();
		};
		frame.current = requestAnimationFrame(tick);
	}
	function dropOne() {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			commitSteps(1);
			return;
		}
		animateTo(PITCH, () => {
			restRef.current = 0;
			setRest(0);
			commitSteps(1);
		});
	}
	function onPointerDown(event) {
		cancelAnimationFrame(frame.current);
		dragging.current = true;
		lastY.current = event.clientY;
		moved.current = 0;
		event.currentTarget.setPointerCapture(event.pointerId);
	}
	function onPointerMove(event) {
		if (!dragging.current || lastY.current == null) return;
		const dy = event.clientY - lastY.current;
		lastY.current = event.clientY;
		moved.current += Math.abs(dy);
		if (dy > 0) {
			push(dy);
			return;
		}
		restRef.current = Math.max(-14, restRef.current + dy * .3);
		setRest(restRef.current);
	}
	function onPointerUp() {
		const wasTap = moved.current < 12;
		dragging.current = false;
		lastY.current = null;
		if (wasTap) {
			dropOne();
			return;
		}
		if (restRef.current < 0) animateTo(0);
	}
	const cx = box.w / 2;
	const cy = box.h * .5;
	const rx = Math.min(box.w * .34, 132);
	const ry = box.h * .3;
	const turn = rest / PITCH * STEP;
	const beads = Array.from({ length: AROUND }, (_, i) => shown - 6 + i);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: stageRef,
		role: "button",
		tabIndex: 0,
		"aria-label": `念珠，沿手腕往下撥，或點一下。目前 ${count} 聲`,
		onPointerDown,
		onPointerMove,
		onPointerUp,
		onPointerCancel: onPointerUp,
		onKeyDown: (event) => {
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				dropOne();
			}
		},
		className: "mala-stage",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				className: "pointer-events-none absolute inset-0 size-full",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx,
					cy,
					rx,
					ry,
					fill: "none",
					stroke: "var(--color-line)",
					strokeWidth: "1.5"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mala-wrist",
				style: {
					left: cx,
					top: cy,
					width: rx * 2 - 36,
					height: ry * 2 - 22
				}
			}),
			beads.map((n) => {
				const angle = Math.PI / 2 + (n - shown) * STEP - turn;
				const x = cx + Math.cos(angle) * rx;
				const y = cy + Math.sin(angle) * ry;
				const depth = (y - (cy - ry)) / Math.max(ry * 2, 1);
				const scale = .62 + depth * .7;
				const tone = n !== 0 && n % 27 === 0 ? " mala-bead-marker" : n % 2 ? " mala-bead-alt" : "";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					className: "mala-bead" + tone,
					style: {
						left: x,
						top: y,
						transform: `translate(-50%, -50%) scale(${scale})`,
						opacity: .72 + depth * .28,
						zIndex: 2 + Math.round(depth * 10)
					}
				}, n);
			})
		]
	});
}
function Chant() {
	const today = todayKey();
	const selected = usePractice((s) => s.selectedMantra);
	const saved = usePractice((s) => s.savedMantras);
	const goal = usePractice((s) => s.dailyChantGoal);
	const woodOn = usePractice((s) => s.woodOn);
	const map = usePractice((s) => s.chantByDate);
	const addChant = usePractice((s) => s.addChant);
	const setSelected = usePractice((s) => s.setSelectedMantra);
	const addSaved = usePractice((s) => s.addSavedMantra);
	const removeSaved = usePractice((s) => s.removeSavedMantra);
	const setGoal = usePractice((s) => s.setGoal);
	const setWoodOn = usePractice((s) => s.setWoodOn);
	const [draft, setDraft] = (0, import_react.useState)("");
	const built = MANTRAS.find((item) => item.id === selected);
	const extra = saved.find((item) => item.id === selected);
	const spoken = extra?.text ?? built?.text ?? MANTRAS[0].text;
	const caption = extra ? "" : built && built.text !== built.name ? built.name : "";
	(0, import_react.useEffect)(() => {
		if (!Boolean(built || extra)) setSelected("amitabha");
	}, [
		built,
		extra,
		setSelected
	]);
	const mine = dayCounts(map, today)[selected] ?? 0;
	const totalToday = sumCounts(dayCounts(map, today));
	const round = mine === 0 ? 0 : mine % 108 === 0 ? 108 : mine % 108;
	const lifetime = mantraTotal(map, selected);
	const lifeAll = allTotal(map);
	const weekKeys = Array.from({ length: 7 }, (_, i) => {
		const d = /* @__PURE__ */ new Date();
		d.setDate(d.getDate() - (6 - i));
		return todayKey(d);
	});
	const weekMax = Math.max(1, ...weekKeys.map((key) => sumCounts(dayCounts(map, key))));
	function bump(n) {
		addChant(selected, n);
		if (n > 0 && woodOn) {
			woodClick();
			tapHaptic();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl leading-snug",
						children: spoken
					}),
					caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mute",
						children: caption
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-serif text-lg leading-loose tracking-wide text-mute",
						children: [
							"我們在念佛",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"佛也在念我們"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BeadStrand, {
				count: mine,
				onCount: (steps) => bump(steps)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-mute",
				children: "沿手腕往下撥，或點一下"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-mute tabular-nums",
						children: [
							"這一圈 ",
							round,
							" / ",
							108,
							mine > 0 && mine % 108 === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sage",
								children: "　這一圈圓滿"
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-3 h-1 w-full max-w-xs overflow-hidden rounded-full bg-paper-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-cinnabar",
							style: { width: `${Math.min(100, totalToday / Math.max(goal, 1) * 100)}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm " + (totalToday >= goal ? "text-sage" : "text-mute"),
						children: [
							"今日合計 ",
							totalToday.toLocaleString("zh-Hant"),
							" / ",
							goal.toLocaleString("zh-Hant"),
							totalToday >= goal ? "　目標已滿" : ""
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: quietBtn,
						onClick: () => bump(-10),
						disabled: mine === 0,
						children: "退十聲"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: quietBtn,
						onClick: () => bump(-1),
						disabled: mine === 0,
						children: "退一聲"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: quietBtn,
						onClick: () => bump(10),
						children: "加十聲"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [MANTRAS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(item.id === selected),
					onClick: () => setSelected(item.id),
					children: item.name
				}, item.id)), saved.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(item.id === selected),
					onClick: () => setSelected(item.id),
					children: item.text
				}, item.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "mb-2 text-sm text-mute",
					children: [
						"新增一句 · ",
						saved.length,
						" / ",
						4
					]
				}),
				saved.length < 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex items-center gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						const id = addSaved(draft);
						if (!id) return;
						setSelected(id);
						setDraft("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: draft,
						maxLength: 40,
						placeholder: "打上要念的那一句",
						onChange: (event) => setDraft(event.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						"aria-label": "儲存這一句",
						disabled: !draft.trim(),
						className: primaryBtn + " size-12 shrink-0 px-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-5",
							"aria-hidden": "true"
						})
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mute",
					children: "四句都滿了。拿掉一句，才能再加。"
				}),
				extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: quietBtn + " mt-2",
					onClick: () => removeSaved(extra.id),
					children: "拿掉這一句"
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-sm text-mute",
				children: "每日目標"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: GOALS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(n === goal),
					onClick: () => setGoal(n),
					children: n.toLocaleString("zh-Hant")
				}, n))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				role: "switch",
				"aria-checked": woodOn,
				onClick: () => setWoodOn(!woodOn),
				className: "flex min-h-12 items-center justify-between border-y border-line py-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "木魚聲與震動" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: woodOn ? "text-sage" : "text-mute",
					children: woodOn ? "開" : "關"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-3 text-sm text-mute",
				children: "近七日"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-20 items-end gap-2",
				children: weekKeys.map((key) => {
					const n = sumCounts(dayCounts(map, key));
					const height = n === 0 ? 4 : Math.max(12, Math.round(n / weekMax * 100));
					const label = [
						"日",
						"一",
						"二",
						"三",
						"四",
						"五",
						"六"
					][(/* @__PURE__ */ new Date(key + "T12:00:00")).getDay()];
					const isToday = key === today;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-full flex-1 flex-col items-center justify-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-14 w-full items-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full rounded-sm " + (n > 0 ? "bg-cinnabar" : "bg-line"),
								style: { height: `${height}%` }
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs " + (isToday ? "text-fg" : "text-mute"),
							children: label
						})]
					}, key);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mute",
				children: [
					"這一咒累計 ",
					lifetime.toLocaleString("zh-Hant"),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-2",
						children: "·"
					}),
					"全部 ",
					lifeAll.toLocaleString("zh-Hant")
				]
			})
		]
	});
}
function Journal({ anchor }) {
	const today = todayKey();
	const vow = usePractice((s) => s.vows[today] ?? "");
	const vows = usePractice((s) => s.vows);
	const gratitude = usePractice((s) => s.gratitudes[today] ?? EMPTY_GRATITUDE);
	const gratitudes = usePractice((s) => s.gratitudes);
	const setVow = usePractice((s) => s.setVow);
	const setGratitude = usePractice((s) => s.setGratitude);
	(0, import_react.useEffect)(() => {
		if (!anchor) return;
		document.getElementById(anchor)?.scrollIntoView({ block: "start" });
	}, [anchor]);
	const past = Array.from(/* @__PURE__ */ new Set([...Object.keys(vows), ...Object.keys(gratitudes)])).filter((date) => date !== today).filter((date) => (vows[date] ?? "").trim() || gratitudeDone(gratitudes[date]) || (gratitudes[date]?.dedication ?? "").trim() || (gratitudes[date]?.reflection ?? "").trim()).sort((a, b) => b.localeCompare(a));
	function setItem(index, value) {
		const items = [
			gratitude.items[0],
			gratitude.items[1],
			gratitude.items[2]
		];
		items[index] = value;
		setGratitude(today, { items });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise flex flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-3xl",
				children: "日課"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-mute",
				children: "早上給一句方向，晚上記得三件事。"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "vow",
				className: "flex scroll-mt-6 flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-xl",
						children: "晨願"
					}),
					!vow.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-2",
						children: VOW_PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setVow(today, preset),
							className: "rounded-md border border-line px-3 py-3 text-left text-sm leading-relaxed text-mute",
							children: preset
						}, preset))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: field + " min-h-28 resize-none font-serif text-lg leading-relaxed",
						value: vow,
						maxLength: 160,
						placeholder: "或者，用自己的話寫下一句。",
						onChange: (event) => setVow(today, event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mute",
						children: vow.trim() ? "已留在今天。" : "寫下就留在今天，可以再改。"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "thanks",
				className: "flex scroll-mt-6 flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-xl",
						children: "感恩三事"
					}),
					[
						"一",
						"二",
						"三"
					].map((mark, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-mute",
							children: mark
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							value: gratitude.items[index] ?? "",
							maxLength: 80,
							placeholder: index === 0 ? "今天感謝的一件事" : "還有呢",
							onChange: (event) => setItem(index, event.target.value)
						})]
					}, mark)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-mute",
							children: "多寫一點"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: field + " min-h-24 resize-none",
							value: gratitude.reflection,
							maxLength: 240,
							placeholder: "誰幫過我，或今天哪一刻是好的。",
							onChange: (event) => setGratitude(today, { reflection: event.target.value })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-xl",
						children: "今晚回向"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-col gap-2",
						children: DEDICATION_PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setGratitude(today, { dedication: preset }),
							className: "rounded-md border border-line px-3 py-3 text-left text-sm text-mute",
							children: preset
						}, preset))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: gratitude.dedication,
						maxLength: 80,
						placeholder: "或寫自己的一句",
						onChange: (event) => setGratitude(today, { dedication: event.target.value })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl",
					children: "先前"
				}), past.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mute",
					children: "過去的日子會留在這裡。今天先寫一句就好。"
				}) : past.map((date) => {
					const dayVow = (vows[date] ?? "").trim();
					const g = gratitudes[date];
					const items = g?.items.filter((item) => item.trim()) ?? [];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border-b border-line pb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-mute",
								children: labelOfKey(date)
							}),
							dayVow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-serif text-lg leading-relaxed",
								children: dayVow
							}) : null,
							items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-1 text-sm",
								children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, `${date}-${index}`))
							}) : null,
							g?.reflection.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mute",
								children: g.reflection.trim()
							}) : null,
							g?.dedication.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-sage",
								children: g.dedication.trim()
							}) : null
						]
					}, date);
				})]
			})
		]
	});
}
function Ledger() {
	const today = todayKey();
	const merits = usePractice((s) => s.merits);
	const addMerit = usePractice((s) => s.addMerit);
	const removeMerit = usePractice((s) => s.removeMerit);
	const [kind, setKind] = (0, import_react.useState)("merit");
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)("");
	const [span, setSpan] = (0, import_react.useState)("today");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const list = kind === "merit" ? MERITS : FAULTS;
	const week = lastDays(7, today);
	const todayNet = netOf(merits.filter((entry) => entry.date === today));
	const weekNet = netOf(merits.filter((entry) => week.includes(entry.date)));
	const allNet = netOf(merits);
	const visible = merits.filter((entry) => {
		if (span === "today") return entry.date === today;
		if (span === "week") return week.includes(entry.date);
		return true;
	});
	function save() {
		if (!picked) return;
		addMerit({
			kind,
			categoryId: picked.id,
			label: picked.label,
			points: picked.points,
			note
		});
		setPicked(null);
		setNote("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-3xl",
				children: "功過簿"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-mute",
				children: "看清楚就好，不是跟自己算帳。"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "今日",
						value: todayNet
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "近七日",
						value: weekNet
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "累計",
						value: allNet
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				role: "tablist",
				"aria-label": "記功或記過",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(kind === "merit"),
					onClick: () => {
						setKind("merit");
						setPicked(null);
					},
					children: "記一功"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(kind === "fault"),
					onClick: () => {
						setKind("fault");
						setPicked(null);
					},
					children: "記一過"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: list.map((item) => {
					const on = picked?.id === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setPicked(on ? null : item),
						className: "min-h-14 rounded-md border px-3 py-2 text-left " + (on ? "border-cinnabar bg-paper-2" : "border-line"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block",
							children: item.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm " + (kind === "merit" ? "text-sage" : "text-cinnabar"),
							children: kind === "merit" ? `+${item.points}` : `−${item.points}`
						})]
					}, item.id);
				})
			}),
			picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 rounded-md border border-line bg-paper p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mute",
						children: picked.hint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: note,
						maxLength: 80,
						placeholder: "想補一句也可以，不寫也行",
						onChange: (event) => setNote(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: primaryBtn,
						onClick: save,
						children: ["記下", picked.label]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [
					["today", "今日"],
					["week", "近七日"],
					["all", "全部"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(span === id),
					onClick: () => setSpan(id),
					children: label
				}, id))
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mute",
				children: "還沒有記錄。功與過都只是看清楚，不是審判自己。"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col",
				children: visible.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-line py-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [entry.label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-2 text-sm text-mute",
								children: [
									entry.date === today ? "今天" : labelOfKey(entry.date),
									" ",
									formatTime(entry.at)
								]
							})] }), entry.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-mute",
								children: entry.note
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 flex-col items-end gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: entry.kind === "merit" ? "text-sage" : "text-cinnabar",
								children: entry.kind === "merit" ? `+${entry.points}` : `−${entry.points}`
							}), pendingDelete === entry.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 text-sm text-cinnabar",
								onClick: () => {
									removeMerit(entry.id);
									setPendingDelete(null);
								},
								children: "確定刪除"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 text-sm text-mute",
								onClick: () => setPendingDelete(entry.id),
								children: "刪除"
							})]
						})]
					})
				}, entry.id))
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-line bg-paper px-2 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-mute",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-serif text-2xl tabular-nums " + (value > 0 ? "text-sage" : value < 0 ? "text-cinnabar" : "text-mute"),
			children: formatNet(value)
		})]
	});
}
function useRemain() {
	const phase = useSit((s) => s.phase);
	const endsAt = useSit((s) => s.endsAt);
	const remainMs = useSit((s) => s.remainMs);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		if (phase !== "running") return;
		const id = window.setInterval(() => setNow(Date.now()), 200);
		return () => window.clearInterval(id);
	}, [phase]);
	if (phase === "running" && endsAt != null) return Math.max(0, endsAt - now);
	if (phase === "paused") return remainMs;
	return 0;
}
function useReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => setReduced(mq.matches);
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, []);
	return reduced;
}
function SitOverlay() {
	const phase = useSit((s) => s.phase);
	const plannedSec = useSit((s) => s.plannedSec);
	const elapsedSec = useSit((s) => s.elapsedSec);
	const logged = useSit((s) => s.logged);
	const pause = useSit((s) => s.pause);
	const resume = useSit((s) => s.resume);
	const end = useSit((s) => s.end);
	const close = useSit((s) => s.close);
	const start = useSit((s) => s.start);
	const breathGuide = usePractice((s) => s.breathGuide);
	const bellOn = usePractice((s) => s.bellOn);
	const remain = useRemain();
	const reduced = useReducedMotion();
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const belled = (0, import_react.useRef)(false);
	const dialogRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (phase === "running" && remain <= 0) {
			if (!belled.current) {
				belled.current = true;
				end("complete");
				if (bellOn) bowlBell();
			}
		}
		if (phase === "idle") {
			belled.current = false;
			setConfirming(false);
		}
	}, [
		phase,
		remain,
		end,
		bellOn
	]);
	(0, import_react.useEffect)(() => {
		if (phase !== "idle") dialogRef.current?.focus();
	}, [phase]);
	if (phase === "idle") return null;
	const elapsedMs = phase === "done" ? elapsedSec * 1e3 : plannedSec * 1e3 - remain;
	const cycle = 1e4;
	const t = (elapsedMs % cycle + cycle) % cycle;
	const inhaling = t < 4e3;
	const p = inhaling ? t / 4e3 : (t - 4e3) / 6e3;
	const smooth = p * p * (3 - 2 * p);
	const scale = !breathGuide || reduced || phase !== "running" ? 1 : inhaling ? .92 + .08 * smooth : 1 - .08 * smooth;
	const breathLabel = phase === "paused" ? "暫停" : !breathGuide ? "安住" : inhaling ? "吸氣" : "呼氣";
	const remainSec = Math.ceil(remain / 1e3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: dialogRef,
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "禪定計時",
		tabIndex: -1,
		className: "fixed inset-0 z-50 flex flex-col bg-ink px-6 text-fg outline-none",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex w-full max-w-lg flex-1 flex-col items-center justify-center",
			children: phase === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mute",
						children: logged ? "這一坐留下來了" : "這一段太短，沒有記"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-4xl leading-tight",
						children: logged ? `坐了 ${formatMinutes(elapsedSec)}` : "先坐下，就很好"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xs text-mute",
						children: "靜坐不是清空，是讓念頭自己走過去。"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex w-full max-w-xs flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: primaryBtn,
							onClick: () => start(plannedSec / 60),
							children: "再坐一次"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: quietBtn,
							onClick: close,
							children: "先到這裡"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative grid size-64 place-items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-4 rounded-full border border-line",
							style: { transform: `scale(${scale})` }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-full border border-cinnabar opacity-40" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-6xl tabular-nums",
							children: formatClock(remain)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-lg text-mute",
					children: breathLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-mute",
					children: [Math.round(plannedSec / 60), " 分鐘"]
				}),
				confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex w-full max-w-xs flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-center text-sm text-mute",
							children: "要結束這一坐嗎？"
						}),
						plannedSec - remainSec >= 30 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: primaryBtn,
							onClick: () => end("keep"),
							children: "留下已坐的時間"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: quietBtn,
							onClick: () => end("discard"),
							children: "不記錄"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: quietBtn,
							onClick: () => setConfirming(false),
							children: "繼續坐"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex w-full max-w-xs gap-2",
					children: [phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: primaryBtn + " flex-1",
						onClick: resume,
						children: "繼續"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: quietBtn + " flex-1",
						onClick: pause,
						children: "暫停"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: quietBtn + " flex-1",
						onClick: () => setConfirming(true),
						children: "結束"
					})]
				})
			] })
		})
	});
}
function SitPage() {
	const [minutes, setMinutes] = (0, import_react.useState)(10);
	const start = useSit((s) => s.start);
	const sits = usePractice((s) => s.sits);
	const breathGuide = usePractice((s) => s.breathGuide);
	const bellOn = usePractice((s) => s.bellOn);
	const setBreath = usePractice((s) => s.setBreathGuide);
	const setBell = usePractice((s) => s.setBellOn);
	const today = todayKey();
	const week = lastDays(7, today);
	const weekSeconds = sits.filter((sit) => week.includes(sit.date)).reduce((n, sit) => n + sit.seconds, 0);
	const weekCount = sits.filter((sit) => week.includes(sit.date)).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-3xl",
				children: "禪定"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-mute",
				children: "坐下，比坐得久更要緊。"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mute",
				children: [
					"本週 ",
					weekCount,
					" 坐",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-2",
						children: "·"
					}),
					formatMinutes(weekSeconds)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: SIT_MINUTES.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: chip(n === minutes),
					onClick: () => setMinutes(n),
					children: [n, " 分鐘"]
				}, n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				role: "switch",
				"aria-checked": breathGuide,
				onClick: () => setBreath(!breathGuide),
				className: "flex min-h-12 items-center justify-between border-y border-line py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["呼吸引導", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-sm text-mute",
					children: "吸氣四秒，呼氣六秒"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: breathGuide ? "text-sage" : "text-mute",
					children: breathGuide ? "開" : "關"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				role: "switch",
				"aria-checked": bellOn,
				onClick: () => setBell(!bellOn),
				className: "flex min-h-12 items-center justify-between border-b border-line py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "結束時敲磬" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: bellOn ? "text-sage" : "text-mute",
					children: bellOn ? "開" : "關"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: primaryBtn,
				onClick: () => start(minutes),
				children: "開始靜坐"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 font-serif text-lg",
				children: "最近"
			}), sits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mute",
				children: "還沒有坐過。五分鐘也算。"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: sits.slice(0, 8).map((sit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-baseline justify-between border-b border-line py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					sit.date === today ? "今天" : labelOfKey(sit.date),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-mute",
						children: formatTime(sit.at)
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: sit.finished ? "text-sage" : "text-mute",
					children: [formatMinutes(sit.seconds), sit.finished ? "　圓滿" : ""]
				})]
			}, sit.id)) })] })
		]
	});
}
var ROWS = [
	{
		id: "journal",
		anchor: "vow",
		title: "晨願",
		line: "給今天一個方向"
	},
	{
		id: "chant",
		title: "念佛",
		line: "把散掉的心收回來"
	},
	{
		id: "ledger",
		title: "功過",
		line: "看清今天的心"
	},
	{
		id: "journal",
		anchor: "thanks",
		title: "感恩",
		line: "記得被給過的"
	},
	{
		id: "sit",
		title: "禪定",
		line: "坐下來一會兒"
	}
];
function Today({ onGo }) {
	const today = todayKey();
	const part = dayPart();
	const greet = greeting(part);
	const chantByDate = usePractice((s) => s.chantByDate);
	const goal = usePractice((s) => s.dailyChantGoal);
	const vows = usePractice((s) => s.vows);
	const gratitudes = usePractice((s) => s.gratitudes);
	const sits = usePractice((s) => s.sits);
	const merits = usePractice((s) => s.merits);
	const vow = (vows[today] ?? "").trim();
	const thanked = gratitudeDone(gratitudes[today]);
	const chant = sumCounts(chantByDate[today] ?? {});
	const sitSeconds = sits.filter((sit) => sit.date === today).reduce((n, sit) => n + sit.seconds, 0);
	const todayMerits = merits.filter((entry) => entry.date === today);
	const streak = streakOf({
		chantByDate,
		vows,
		gratitudes,
		sits,
		merits
	}, today);
	const week = lastDays(7, today);
	const weekChant = week.reduce((n, key) => n + sumCounts(chantByDate[key] ?? {}), 0);
	const weekSit = sits.filter((sit) => week.includes(sit.date)).reduce((n, sit) => n + sit.seconds, 0);
	const weekNet = netOf(merits.filter((entry) => week.includes(entry.date)));
	const status = {
		晨願: {
			done: Boolean(vow),
			label: vow ? "已發願" : part === "morning" ? "現在寫" : "未發願"
		},
		念佛: {
			done: chant > 0,
			label: chant > 0 ? `${chant.toLocaleString("zh-Hant")} / ${goal.toLocaleString("zh-Hant")}` : "未念"
		},
		功過: {
			done: todayMerits.length > 0,
			label: todayMerits.length > 0 ? formatNet(netOf(todayMerits)) : "未記"
		},
		感恩: {
			done: thanked,
			label: thanked ? "已寫" : part === "evening" ? "今晚寫" : "未寫"
		},
		禪定: {
			done: sitSeconds >= 30,
			label: sitSeconds >= 30 ? formatMinutes(sitSeconds) : "未坐"
		}
	};
	const doneCount = Object.values(status).filter((item) => item.done).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise flex flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl leading-tight",
					children: greet.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-mute",
					children: greet.sub
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-3xl leading-none text-cinnabar tabular-nums",
						children: streak
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-mute",
						children: streak > 0 ? "連續天數" : "從今天起"
					})]
				})]
			}),
			vow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "border-l-2 border-cinnabar pl-4 font-serif text-lg leading-relaxed",
				children: vow
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-lg",
					children: "今日五事"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-mute tabular-nums",
					children: [doneCount, " / 5"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: ROWS.map((row) => {
				const item = status[row.title];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onGo(row.id, row.anchor),
						className: "flex min-h-16 w-full items-center gap-3 py-3 text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-2.5 shrink-0 rounded-full " + (item?.done ? "bg-sage" : "border border-mute"),
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block",
									children: row.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-mute",
									children: row.line
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-sm " + (item?.done ? "text-sage" : "text-mute"),
								children: item?.label
							})
						]
					})
				}, row.title);
			}) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mute",
				children: [
					"本週念佛 ",
					weekChant.toLocaleString("zh-Hant"),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-2 text-line",
						children: "·"
					}),
					"靜坐 ",
					formatMinutes(weekSit),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-2 text-line",
						children: "·"
					}),
					"功過 ",
					formatNet(weekNet)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-serif text-lg leading-relaxed text-fg",
				children: lineFor(today)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mute",
				children: [labelOfKey(today), "的記錄留在這支手機裡，不會上傳。"]
			})
		]
	});
}
var TABS = [
	{
		id: "today",
		label: "今日",
		icon: House
	},
	{
		id: "chant",
		label: "念佛",
		icon: CircleDot
	},
	{
		id: "ledger",
		label: "功過",
		icon: Scale
	},
	{
		id: "journal",
		label: "日課",
		icon: NotebookPen
	},
	{
		id: "sit",
		label: "禪定",
		icon: Flower2
	}
];
function useHydrated() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let alive = true;
		const finish = () => {
			if (alive) setReady(true);
		};
		if (usePractice.persist.hasHydrated()) finish();
		const unsub = usePractice.persist.onFinishHydration(finish);
		Promise.resolve(usePractice.persist.rehydrate()).then(finish, finish);
		return () => {
			alive = false;
			unsub();
		};
	}, []);
	return ready;
}
function PracticeApp() {
	const ready = useHydrated();
	const [tab, setTab] = (0, import_react.useState)("today");
	const [anchor, setAnchor] = (0, import_react.useState)(null);
	const sitting = useSit((s) => s.phase !== "idle");
	function open(next, focus) {
		setTab(next);
		setAnchor(focus ?? null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden bg-ink text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-lg flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-end justify-between px-5 pt-6 pb-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-8 place-items-center bg-cinnabar font-serif text-sm text-ink",
							children: "心"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-serif text-2xl tracking-wide",
							children: "心田"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mute",
						children: "日日耕心"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-right text-sm text-mute",
						children: ready ? formatChineseDate() : "　"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					inert: sitting,
					className: "flex-1 px-5 pb-28",
					children: ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						tab === "today" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Today, { onGo: open }) : null,
						tab === "chant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chant, {}) : null,
						tab === "ledger" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ledger, {}) : null,
						tab === "journal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Journal, { anchor }) : null,
						tab === "sit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SitPage, {}) : null
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 pt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-24 rounded-sm bg-paper-2" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-48 rounded-sm bg-paper" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-px bg-line" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-mute",
								children: "正在打開今天的功課。"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					inert: sitting,
					className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-ink",
					"aria-label": "功課",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid max-w-lg grid-cols-5",
						children: TABS.map((item) => {
							const active = tab === item.id;
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-current": active ? "page" : void 0,
								onClick: () => open(item.id),
								className: "relative flex h-16 flex-col items-center justify-center gap-1 text-xs " + (active ? "text-fg" : "text-mute"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute top-0 h-0.5 w-4 " + (active ? "bg-cinnabar" : "bg-transparent"),
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										size: 20,
										strokeWidth: 1.75,
										"aria-hidden": "true"
									}),
									item.label
								]
							}, item.id);
						})
					})
				})
			]
		}), ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SitOverlay, {}) : null]
	});
}
var SplitComponent = PracticeApp;
//#endregion
export { SplitComponent as component };
