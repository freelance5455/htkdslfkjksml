import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as Download, p as ChevronLeft, u as Flame } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-buLXhEze.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var useForge = create()(persist((set) => ({
	campaigns: [],
	upsert: (campaign) => set((state) => {
		return { campaigns: state.campaigns.some((item) => item.id === campaign.id) ? state.campaigns.map((item) => item.id === campaign.id ? campaign : item) : [campaign, ...state.campaigns] };
	}),
	remove: (id) => set((state) => ({ campaigns: state.campaigns.filter((item) => item.id !== id) }))
}), {
	name: "roleforge.v1",
	version: 1
}));
function useHydrated() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (useForge.persist.hasHydrated()) {
			setReady(true);
			return;
		}
		return useForge.persist.onFinishHydration(() => setReady(true));
	}, []);
	return ready;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Wordmark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "font-serif text-2xl tracking-tight text-parchment",
		children: ["Role", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-ember",
			children: "forge"
		})]
	});
}
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-medium transition-colors duration-150", variant === "primary" && "bg-ember text-ink hover:bg-ember-deep", variant === "quiet" && "rf-ring bg-panel-2 text-parchment", variant === "ghost" && "bg-transparent text-parchment hover:bg-panel-2", variant === "danger" && "bg-transparent text-ember hover:bg-panel-2", className),
		...props
	});
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium text-parchment",
				children: label
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-mist",
				children: hint
			}) : null,
			children
		]
	});
}
function Segmented({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium text-parchment",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-1 rounded-xl bg-soot p-1",
			role: "group",
			"aria-label": label,
			children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": value === option.id,
				onClick: () => onChange(option.id),
				className: cn("min-h-11 rounded-lg px-2 text-sm", value === option.id ? "bg-panel-2 text-parchment" : "text-mist"),
				children: option.label
			}, option.id))
		})]
	});
}
function PageHeader({ back, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center justify-between gap-3 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 items-center gap-2",
			children: [back ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: back.to,
				className: "inline-flex min-h-11 items-center gap-1 text-sm text-mist",
				"aria-label": back.label,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: "size-5",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: back.label
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
				className: "size-5 text-ember",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})]
		}), action]
	});
}
function InstallHint() {
	const [prompt, setPrompt] = (0, import_react.useState)(null);
	const [hidden, setHidden] = (0, import_react.useState)(false);
	const [ios, setIos] = (0, import_react.useState)(false);
	const [installed, setInstalled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const nav = navigator;
		if (window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true) {
			setInstalled(true);
			return;
		}
		const ua = navigator.userAgent;
		setIos(/iphone|ipad|ipod/i.test(ua));
		const onPrompt = (event) => {
			event.preventDefault();
			setPrompt(event);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		return () => window.removeEventListener("beforeinstallprompt", onPrompt);
	}, []);
	if (installed || hidden) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rf-card flex flex-col gap-3 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
				className: "mt-0.5 size-5 shrink-0 text-ember",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: "Llévala en el teléfono"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: "Se instala en la pantalla de inicio y se abre como una aplicación. En Android el navegador la añade directamente; un APK de tienda exige un empaquetado aparte que Roleforge no finge descargar."
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				prompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						prompt.prompt();
						setHidden(true);
					},
					children: "Instalar"
				}) : null,
				ios ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: "En Safari: Compartir, luego Añadir a pantalla de inicio."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setHidden(true),
					children: "Ahora no"
				})
			]
		})]
	});
}
//#endregion
export { Segmented as a, PageHeader as i, Field as n, useForge as o, InstallHint as r, useHydrated as s, Button as t };
