import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, a as AccordionTrigger, g as require_jsx_runtime, i as AccordionItem, n as AccordionContent, r as AccordionHeader, t as Accordion } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { x as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as privilegeLabel, E as utcTodayIso, S as partStatus, T as useMinistry, a as Field, c as SKILL_META, g as formatShort, h as formatLong, i as Card, l as StatusPill, m as fieldClass, p as cn, r as Button, s as PageIntro, v as fullName } from "./shell-CGpvgZIy.mjs";
import { t as SKILL_IDS } from "./types-djekE3oG.mjs";
import { n as SwitchThumb, t as Switch } from "../_libs/@radix-ui/react-switch+[...].mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk-pages-BQQTtJ_U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HistoryPage() {
	const members = useMinistry((state) => state.members);
	const meetings = useMinistry((state) => state.meetings);
	const assignments = useMinistry((state) => state.assignments);
	const [memberId, setMemberId] = (0, import_react.useState)("all");
	const [section, setSection] = (0, import_react.useState)("all");
	const today = utcTodayIso();
	const byId = new Map(members.map((member) => [member.id, member]));
	const rows = meetings.slice().reverse().map((meeting) => ({
		meeting,
		parts: assignments.filter((assignment) => assignment.meetingId === meeting.id).filter((assignment) => section === "all" ? true : assignment.section === section).filter((assignment) => memberId === "all" ? true : assignment.assigneeId === memberId || assignment.assistantId === memberId).sort((a, b) => a.order - b.order)
	})).filter((group) => group.parts.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Record",
			title: "Assignment history",
			lede: "Every part already given, and the ones still waiting for the meeting."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Publisher",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: fieldClass,
					value: memberId,
					onChange: (event) => setMemberId(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "Everyone"
					}), members.slice().sort((a, b) => a.lastName.localeCompare(b.lastName)).map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: member.id,
						children: fullName(member)
					}, member.id))]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Section",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: fieldClass,
					value: section,
					onChange: (event) => setSection(event.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All sections"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "opening",
							children: "Opening"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "treasures",
							children: "Treasures"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "ministry",
							children: "Ministry"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "living",
							children: "Living as Christians"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "closing",
							children: "Closing"
						})
					]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-8 text-sm text-muted",
				children: "Nothing in the record matches those filters."
			}) : null, rows.map(({ meeting, parts }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: meeting.theme
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: formatLong(meeting.date)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: parts.map((part) => {
						const assignee = part.assigneeId ? byId.get(part.assigneeId) : void 0;
						const assistant = part.assistantId ? byId.get(part.assistantId) : void 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: part.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-sm text-muted",
									children: [
										assignee ? fullName(assignee) : "Unassigned",
										part.needsAssistant ? ` · Assistant ${assistant ? fullName(assistant) : "open"}` : "",
										` · ${part.durationMin} min`
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: partStatus(meeting.date, part.assigneeId, today) })]
						}, part.id);
					})
				})
			] }, meeting.id))]
		})
	] });
}
function AvailabilityPage() {
	const members = useMinistry((state) => state.members);
	const meetings = useMinistry((state) => state.meetings);
	const toggleAway = useMinistry((state) => state.toggleAway);
	const today = utcTodayIso();
	const future = meetings.filter((meeting) => meeting.date >= today);
	const [date, setDate] = (0, import_react.useState)(future[0]?.date ?? "");
	const meeting = future.find((item) => item.date === date) ?? future[0];
	const sorted = [...members].sort((a, b) => a.lastName.localeCompare(b.lastName));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Schedule",
			title: "Availability",
			lede: "Mark who cannot accept a part on a given week. Away publishers are skipped by the arranger."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: future.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setDate(item.date),
				className: cn("tap h-11 rounded-full px-4 text-sm font-semibold", meeting?.date === item.date ? "bg-sidebar text-on-navy" : "bg-card text-ink"),
				children: formatShort(item.date)
			}, item.id))
		}),
		meeting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "divide-y divide-line",
			children: sorted.map((member) => {
				const traveling = member.availability === "away";
				const away = traveling || member.awayDates.includes(meeting.date);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-semibold",
							children: fullName(member)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs text-muted",
							children: [privilegeLabel(member.privilege), traveling ? " · Away for now" : member.availability === "limited" ? " · Limited" : ""]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: traveling,
						onClick: () => {
							toggleAway(member.id, meeting.date);
							toast.success(away ? "Marked available" : "Marked away", { description: fullName(member) });
						},
						className: cn("tap h-11 shrink-0 rounded-full px-4 text-sm font-semibold", away ? "bg-warn-soft text-warn" : "bg-good-soft text-good", traveling && "opacity-70"),
						children: away ? "Away" : "Available"
					})]
				}, member.id);
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "p-8 text-sm text-muted",
			children: "No upcoming meetings."
		})
	] });
}
function ReportsPage() {
	const members = useMinistry((state) => state.members);
	const assignments = useMinistry((state) => state.assignments);
	const data = (0, import_react.useMemo)(() => members.map((member) => ({
		name: member.firstName,
		parts: assignments.filter((assignment) => assignment.assigneeId === member.id || assignment.assistantId === member.id).length
	})).filter((row) => row.parts > 0).sort((a, b) => b.parts - a.parts).slice(0, 8), [members, assignments]);
	const busiest = data[0];
	const quiet = [...members].sort((a, b) => {
		const load = (id) => assignments.filter((assignment) => assignment.assigneeId === id || assignment.assistantId === id).length;
		return load(a.id) - load(b.id);
	})[0];
	const coverage = SKILL_IDS.map((skill) => {
		const qualified = members.filter((member) => (member.skills[skill] ?? 0) >= 70).length;
		return {
			skill,
			label: SKILL_META[skill].label,
			qualified
		};
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Balance",
			title: "Reports",
			lede: "A calm look at who has been used, and where the congregation is thin."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Busiest on record"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-3xl",
							children: busiest?.name ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted tabular-nums",
							children: busiest ? `${busiest.parts} parts` : "No parts yet"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Lightest load"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-3xl",
							children: quiet ? quiet.firstName : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "A good person to consider next."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Parts on record"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-3xl tabular-nums",
							children: assignments.filter((assignment) => assignment.assigneeId).length
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Primary assignments with a name."
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4 p-4 sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Parts per publisher"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm text-muted",
					children: "Primary parts and assists, top of the roster."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-72",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data,
							layout: "vertical",
							margin: {
								left: 8,
								right: 8,
								top: 8,
								bottom: 8
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									type: "number",
									allowDecimals: false,
									hide: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									type: "category",
									dataKey: "name",
									width: 72,
									axisLine: false,
									tickLine: false,
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: { fill: "var(--color-soft)" },
									contentStyle: {
										background: "var(--color-card)",
										border: "1px solid var(--color-line)",
										borderRadius: 16,
										color: "var(--color-ink)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "parts",
									fill: "var(--color-royal)",
									radius: [
										0,
										8,
										8,
										0
									],
									barSize: 14
								})
							]
						})
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-3 sm:grid-cols-2",
			children: coverage.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted tabular-nums",
						children: [item.qualified, " ready"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-2 overflow-hidden rounded-full bg-soft",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-cyan",
						style: { width: `${Math.min(100, item.qualified * 18)}%` }
					})
				})]
			}, item.skill))
		})
	] });
}
var HELP = [
	{
		q: "What does Arrange with AI actually do?",
		a: "It reads who is free, which parts they can handle, and how often they have already been used. You get a full programme you can edit. Nothing is announced until you are satisfied."
	},
	{
		q: "Who can receive which part?",
		a: "Chairman, prayer, treasures talks, spiritual gems, Living as Christians talks, and the Congregation Bible study are offered to brothers. Elders are preferred for chairman, gems, and the Bible study. Student parts and householder roles can be brothers or sisters. Unbaptized publishers are kept to the Bible reading and student parts."
	},
	{
		q: "Why was someone left unassigned?",
		a: "They may be marked away, already used in the same meeting, or rated below 45 for that part. Use Replace or Edit to choose someone else, or raise the skill if it is out of date."
	},
	{
		q: "Can I undo an arrangement?",
		a: "Yes. The confirmation that appears after arranging has Undo, and it restores the programme from just before that run."
	},
	{
		q: "Where is this data kept?",
		a: "In this browser only. It is a working sample for Northside Congregation. Reset it any time from Settings. There is no shared congregation account in this version."
	},
	{
		q: "Does the assistant replace the overseer?",
		a: "No. MinistryFlow prepares a balanced suggestion. The brother arranging the meeting still makes the final decision."
	}
];
function HelpPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		eyebrow: "Help Centre",
		title: "How the desk works",
		lede: "A short guide for the brother or sister who prepares the midweek meeting."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
		type: "single",
		collapsible: true,
		className: "space-y-2",
		children: HELP.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
			value: item.q,
			className: "overflow-hidden rounded-3xl border border-line bg-card shadow-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionTrigger, {
				className: "group tap flex w-full items-center justify-between gap-3 px-4 py-4 text-left text-sm font-semibold",
				children: [item.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 shrink-0 text-muted transition-transform group-data-[state=open]:rotate-180" })]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
				className: "px-4 pb-4 text-sm text-muted",
				children: item.a
			})]
		}, item.q))
	})] });
}
function SettingsPage() {
	const congregation = useMinistry((state) => state.congregation);
	const meetingTime = useMinistry((state) => state.meetingTime);
	const meetingWeekday = useMinistry((state) => state.meetingWeekday);
	const theme = useMinistry((state) => state.theme);
	const setTheme = useMinistry((state) => state.setTheme);
	const updateSettings = useMinistry((state) => state.updateSettings);
	const resetDemo = useMinistry((state) => state.resetDemo);
	const [name, setName] = (0, import_react.useState)(congregation);
	const [time, setTime] = (0, import_react.useState)(meetingTime);
	(0, import_react.useEffect)(() => {
		setName(congregation);
		setTime(meetingTime);
	}, [congregation, meetingTime]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Settings",
			title: "Congregation",
			lede: "The name on the desk, when you meet, and how the interface looks."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-5 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Congregation name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: name,
						onChange: (event) => setName(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Meeting time",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						type: "time",
						value: time,
						onChange: (event) => setTime(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Sample weeks are prepared for ",
						meetingWeekday,
						". Changing the time updates the clock on the planner."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						updateSettings({
							congregation: name,
							meetingTime: time
						});
						toast.success("Settings saved");
					},
					children: "Save details"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4 flex items-center justify-between gap-4 p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-sans text-lg font-semibold tracking-normal",
				children: "Dark mode"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "A navy desk for evening preparation. The choice stays in this browser."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				checked: theme === "dark",
				onCheckedChange: (checked) => {
					setTheme(checked ? "dark" : "light");
					toast.success(checked ? "Dark mode on" : "Light mode on");
				},
				className: "relative h-8 w-14 shrink-0 rounded-full bg-line transition-colors data-[state=checked]:bg-royal",
				"aria-label": "Dark mode",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-6 translate-x-1 rounded-full bg-card shadow transition-transform data-[state=checked]:translate-x-7" })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-sans text-lg font-semibold tracking-normal",
					children: "Sample congregation"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Restore the original Northside roster, meetings, and assignment history. Your dark mode choice is kept."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					className: "mt-4",
					onClick: () => {
						resetDemo();
						setName("Northside Congregation");
						setTime("19:00");
						toast.success("Sample data restored");
					},
					children: "Reset sample data"
				})
			]
		})
	] });
}
//#endregion
export { SettingsPage as a, ReportsPage as i, HelpPage as n, HistoryPage as r, AvailabilityPage as t };
