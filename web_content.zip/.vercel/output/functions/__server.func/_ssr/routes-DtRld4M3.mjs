import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as BatteryMedium, a as Search, c as Monitor, d as Hand, f as Download, g as CircuitBoard, h as Copy, i as Share2, l as Languages, m as Cpu, n as Thermometer, o as ScanLine, p as Crosshair, r as Smartphone, s as RefreshCw, u as HardDrive } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as TIER_LABEL, i as searchCatalog, n as useCaliber, o as classifySoc, r as CATALOG, s as formatSettingsText } from "./router-DEyW4zoq.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DtRld4M3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg shadow-sm hover:opacity-90",
			secondary: "bg-surface text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted hover:text-fg hover:bg-surface",
			outline: "text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] bg-transparent",
			accent: "bg-accent text-accent-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4 text-sm",
			sm: "h-9 px-3 text-sm rounded-sm",
			lg: "h-12 px-5 text-base rounded-lg",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	className: cn(buttonVariants({
		variant,
		size,
		className
	})),
	ref,
	...props
}));
Button.displayName = "Button";
function DevicePicker({ featured }) {
	const { dict, lang, pickDevice, pickerOpen, setPickerOpen } = useCaliber();
	const [q, setQ] = (0, import_react.useState)("");
	const list = (0, import_react.useMemo)(() => featured && !q ? CATALOG.slice(0, 6) : searchCatalog(q), [q, featured]);
	if (featured) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-xs uppercase tracking-[0.16em] text-subtle",
			children: dict.featured
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: CATALOG.filter((d) => [
				"samsung-a55",
				"poco-x6-pro",
				"redmi-13c",
				"samsung-s24",
				"infinix-hot-40",
				"poco-f6"
			].includes(d.id)).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => pickDevice(d),
				className: "rounded-lg bg-surface p-3 text-start shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] uppercase tracking-wider text-subtle",
						children: d.brand
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-sm font-semibold leading-tight",
						children: d.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 truncate text-[11px] text-muted",
						children: d.soc
					})
				]
			}, d.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			className: "mt-2 w-full",
			onClick: () => setPickerOpen(true),
			children: dict.pickPhone
		}),
		pickerOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickerModal, {
			q,
			setQ,
			list
		}) : null
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "secondary",
		onClick: () => setPickerOpen(true),
		children: dict.pickPhone
	}), pickerOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickerModal, {
		q,
		setQ,
		list
	}) : null] });
}
function PickerModal({ q, setQ, list }) {
	const { dict, lang, pickDevice, setPickerOpen } = useCaliber();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 grid place-items-end sm:place-items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-bg/70",
			"aria-label": "Close",
			onClick: () => setPickerOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 flex max-h-[82dvh] w-full max-w-lg flex-col rounded-t-2xl bg-surface p-4 shadow-[var(--shadow-border)] sm:rounded-2xl sm:p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: dict.searchPhone,
					className: "h-11 w-full rounded-md bg-bg ps-10 pe-3 text-sm text-fg placeholder:text-subtle shadow-[var(--shadow-border)] focus:outline-none focus:ring-2 focus:ring-ring"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 space-y-1 overflow-y-auto",
				children: list.map((d) => {
					const tier = classifySoc(d.soc).tier;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => pickDevice(d),
						className: cn("flex w-full items-center justify-between gap-3 rounded-md px-3 py-2.5 text-start hover:bg-bg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block font-display text-sm font-semibold",
							children: [
								d.brand,
								" ",
								d.name
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-[11px] text-muted",
							children: [
								d.soc,
								" · ",
								d.typicalRamGb,
								" GB · ",
								Math.max(...d.refreshRates),
								" Hz"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-[10px] uppercase tracking-wider text-primary",
							children: TIER_LABEL[tier][lang]
						})]
					}, d.id);
				})
			})]
		})]
	});
}
function HomeScreen() {
	const { dict, toggleLang, runScan, scanError } = useCaliber();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto flex min-h-dvh w-full max-w-6xl flex-col px-5 pb-10 pt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-lg font-semibold tracking-[0.22em] text-primary",
				children: "CALIBER"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: toggleLang,
				"aria-label": dict.language,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, { className: "size-4" }), dict.language]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid flex-1 items-center gap-10 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.2em] text-accent",
					children: dict.homeKicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-5xl font-semibold leading-[0.95] tracking-tight text-fg sm:text-6xl",
					children: dict.tagline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-prose text-sm leading-relaxed text-muted",
					children: dict.homeLead
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto mt-8 h-40 w-40 lg:mx-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-full shadow-[var(--shadow-border)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 160 160",
						className: "absolute inset-0 size-full",
						"aria-hidden": true,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "80",
								cy: "80",
								r: "62",
								fill: "none",
								stroke: "currentColor",
								className: "text-surface-2",
								strokeWidth: "1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "80",
								cy: "80",
								r: "42",
								fill: "none",
								stroke: "currentColor",
								className: "text-surface-2",
								strokeWidth: "1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
								className: "radar-sweep text-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M80 80 L80 18 A62 62 0 0 1 128 48 Z",
									fill: "currentColor",
									opacity: "0.18"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "80",
									y1: "80",
									x2: "80",
									y2: "18",
									stroke: "currentColor",
									strokeWidth: "2"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "80",
								cy: "80",
								r: "4",
								fill: "currentColor",
								className: "text-accent"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					className: "mt-6 w-full font-display text-lg tracking-wide sm:w-auto sm:px-10",
					onClick: () => void runScan(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, { className: "size-5" }), dict.scanCta]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-subtle sm:text-start text-center",
					children: dict.scanSub
				}),
				scanError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					children: scanError
				}) : null
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DevicePicker, { featured: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold",
						children: dict.buildGuide
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs leading-relaxed text-muted",
						children: dict.buildBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "/caliber-android.zip",
						download: true,
						className: "mt-3 inline-flex h-11 items-center gap-2 text-sm text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), dict.downloadApk]
					})
				]
			})] })]
		})]
	});
}
function ScoreRing({ score }) {
	const { dict } = useCaliber();
	const r = 54;
	const c = 2 * Math.PI * r;
	const offset = c - score / 100 * c;
	const tone = score >= 75 ? "text-ok" : score >= 50 ? "text-accent" : "text-primary";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto grid size-36 place-items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pulse-ring absolute inset-3 rounded-full bg-primary/20",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 128 128",
				className: "size-36 -rotate-90",
				"aria-hidden": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "64",
					cy: "64",
					r,
					fill: "none",
					stroke: "currentColor",
					className: "text-surface-2",
					strokeWidth: "8"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "64",
					cy: "64",
					r,
					fill: "none",
					stroke: "currentColor",
					className: tone,
					strokeWidth: "8",
					strokeLinecap: "round",
					strokeDasharray: c,
					strokeDashoffset: offset
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 grid place-items-center text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `font-display text-4xl font-semibold leading-none tabular-nums ${tone}`,
					children: score
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-[10px] uppercase tracking-[0.18em] text-muted",
					children: dict.score
				})] })
			})
		]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-primary/15 text-primary",
		accent: "bg-accent/15 text-accent",
		mute: "bg-surface-2/60 text-muted",
		ok: "bg-ok/15 text-ok"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl bg-surface p-4 text-fg shadow-[var(--shadow-border)]", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: cn("font-display text-base font-semibold tracking-wide", className),
		...props
	});
}
function CardMeta({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-xs text-muted", className),
		...props
	});
}
function ProgressBar({ value, max = 200, className, delayMs = 0 }) {
	const pct = Math.max(0, Math.min(100, value / max * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-2 w-full overflow-hidden rounded-full bg-surface-2/80", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "bar-fill h-full rounded-full bg-primary",
			style: {
				width: `${pct}%`,
				animationDelay: `${delayMs}ms`
			}
		})
	});
}
function SettingsView() {
	const { dict, lang, hardware, settings } = useCaliber();
	if (!hardware || !settings) return null;
	const items = [
		{
			label: dict.general,
			value: settings.sensitivity.general
		},
		{
			label: dict.redDot,
			value: settings.sensitivity.redDot
		},
		{
			label: dict.scope2x,
			value: settings.sensitivity.scope2x
		},
		{
			label: dict.scope4x,
			value: settings.sensitivity.scope4x
		},
		{
			label: dict.awm,
			value: settings.sensitivity.awm
		},
		{
			label: dict.freeLook,
			value: settings.sensitivity.freeLook
		}
	];
	const b = settings.scoreBreakdown;
	const mix = [
		{
			k: dict.cpu,
			v: b.cpu,
			m: 28
		},
		{
			k: dict.ram,
			v: b.ram + b.ramType,
			m: 24
		},
		{
			k: dict.gpu,
			v: b.gpu,
			m: 18
		},
		{
			k: dict.refresh,
			v: b.refresh,
			m: 14
		},
		{
			k: dict.touchRate,
			v: b.touch,
			m: 10
		},
		{
			k: dict.thermal,
			v: b.thermal,
			m: 6
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, { score: settings.performanceScore }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-display text-lg font-semibold",
						children: [
							hardware.manufacturer,
							" ",
							hardware.model
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							hardware.socName,
							" · ",
							TIER_LABEL[hardware.cpuTier][lang]
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-xs uppercase tracking-[0.16em] text-subtle",
				children: dict.breakdown
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: mix.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-md bg-bg px-2.5 py-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between text-[11px] text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.k }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-fg",
							children: [
								row.v,
								"/",
								row.m
							]
						})]
					})
				}, row.k))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "mb-3",
				children: dict.sensitivity
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1 flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-lg font-semibold tabular-nums text-fg",
						children: [item.value, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-normal text-subtle",
							children: [" ", dict.of200]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, {
					value: item.value,
					delayMs: idx * 70
				})] }, item.label))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "border-0 p-4 shadow-[0_0_0_1px_rgb(249_115_22_/_0.45)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardMeta, {
							className: "uppercase tracking-[0.16em]",
							children: dict.dpi
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 font-display text-4xl font-semibold tabular-nums text-primary",
							children: settings.dpi.recommended
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs leading-relaxed text-muted",
							children: dict.dpiWarn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-subtle",
							children: [
								dict.originalDpi,
								": ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-fg",
									children: settings.dpi.originalDpi
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "border-0 p-4 shadow-[0_0_0_1px_rgb(234_179_8_/_0.4)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardMeta, {
							className: "uppercase tracking-[0.16em]",
							children: dict.fireBtn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 font-display text-4xl font-semibold tabular-nums text-accent",
							children: [settings.fireButtonPercent, "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted",
							children: [
								hardware.displayInches,
								"\" · ",
								hardware.ramGb,
								" GB RAM"
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-sm",
					children: dict.howToApply
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-2 list-decimal space-y-1 ps-4 text-xs leading-relaxed text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: dict.stepAdb }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						dict.stepManual,
						" (",
						settings.dpi.smallestWidth,
						")"
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 overflow-x-auto rounded-md bg-bg px-3 py-2 font-mono text-[11px] text-accent",
					children: settings.dpi.adbSet
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-2 overflow-x-auto rounded-md bg-bg px-3 py-2 font-mono text-[11px] text-muted",
					children: settings.dpi.adbReset
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "mute",
							children: [
								dict.graphics,
								": ",
								settings.graphics.preset
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "accent",
							children: [
								dict.fps,
								": ",
								settings.graphics.fpsOption
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: settings.graphics.highFps ? "ok" : "mute",
							children: [
								dict.highFps,
								": ",
								settings.graphics.highFps ? dict.on : dict.off
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "mt-4 text-sm",
					children: dict.tips
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-1.5 text-xs leading-relaxed text-muted",
					children: settings.graphics.extras.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tip }, tip))
				})
			] })
		]
	});
}
function fmtUnavailable(value, fallback) {
	if (value === null || value === void 0 || value === "" || value === "Unavailable") return fallback;
	return String(value);
}
function mhzList(khz) {
	if (!khz.length) return "";
	return [...new Set(khz.map((k) => Math.round(k / 1e3)))].sort((a, b) => b - a).map((m) => `${m} MHz`).join(" · ");
}
function SpecsView() {
	const { dict, lang, hardware } = useCaliber();
	if (!hardware) return null;
	const h = hardware;
	const fallback = dict.unavailable;
	const rows = [
		{
			icon: Cpu,
			title: dict.cpu,
			body: h.socName,
			meta: `${h.cpuCores} ${dict.cores}${h.cpuMaxFreqKhz.length ? ` · ${mhzList(h.cpuMaxFreqKhz)}` : ` · ${dict.freq}: ${fallback}`}`,
			badge: TIER_LABEL[h.cpuTier][lang]
		},
		{
			icon: CircuitBoard,
			title: dict.gpu,
			body: h.gpuName,
			meta: `${h.abi === "Unavailable" ? fallback : h.abi}`,
			badge: TIER_LABEL[h.gpuTier][lang]
		},
		{
			icon: CircuitBoard,
			title: dict.ram,
			body: `${h.ramGb} GB${h.ramTypeEstimated ? ` · ${h.ramType} (${dict.estimated})` : ` · ${h.ramType}`}`,
			meta: `${h.ramAvailableGb.toFixed(1)} GB ${dict.available}`
		},
		{
			icon: HardDrive,
			title: dict.storage,
			body: h.storageGb ? `${h.storageGb} GB · ${h.storageType}` : `${h.storageType}${h.storageTypeEstimated ? ` · ${dict.estimated}` : ""}`,
			meta: h.storageTypeEstimated ? dict.estimated : h.storageType
		},
		{
			icon: Monitor,
			title: dict.display,
			body: `${h.displayWidth}×${h.displayHeight} · ${h.displayInches} ${dict.inches}${h.displayInchesEstimated ? ` · ${dict.estimated}` : ""}`,
			meta: `${h.refreshRate} Hz · ${dict.touchRate} ${h.touchSamplingHz} Hz${h.touchSamplingEstimated ? ` (${dict.estimated})` : ""} · ${h.densityDpi} dpi`
		},
		{
			icon: BatteryMedium,
			title: dict.battery,
			body: h.batteryLevel === null ? fallback : `${h.batteryLevel}%`,
			meta: h.batteryTempC === null ? dict.thermal + ": " + fallback : `${h.batteryTempC}°C`
		},
		{
			icon: Thermometer,
			title: dict.thermal,
			body: h.thermalStatus === "unavailable" ? fallback : h.thermalStatus,
			meta: dict.android
		},
		{
			icon: Smartphone,
			title: dict.android,
			body: `${h.manufacturer} ${h.model}`,
			meta: `Android ${fmtUnavailable(h.androidVersion, fallback)} · ${dict.patch}: ${fmtUnavailable(h.securityPatch, fallback)}`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: dict.catalogHint
			}),
			rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rise flex items-start gap-3 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-10 shrink-0 place-items-center rounded-md bg-bg text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(row.icon, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
								className: "text-xs uppercase tracking-[0.14em] text-subtle",
								children: row.title
							}), row.badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: row.badge }) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 truncate text-sm text-fg",
							children: row.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardMeta, {
							className: "truncate",
							children: row.meta
						})
					]
				})]
			}, row.title)),
			h.notes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 px-1 text-[11px] leading-relaxed text-subtle",
				children: h.notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n }, n))
			}) : null
		]
	});
}
var SAMPLE_MS = 4e3;
function TouchTestView() {
	const { dict, hardware, setTouchHz, setTab } = useCaliber();
	const [hz, setHz] = (0, import_react.useState)(null);
	const [active, setActive] = (0, import_react.useState)(false);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const stamps = (0, import_react.useRef)([]);
	const start = (0, import_react.useRef)(0);
	const raf = (0, import_react.useRef)(0);
	const finish = () => {
		setActive(false);
		const deltas = [];
		const s = stamps.current;
		for (let i = 1; i < s.length; i++) deltas.push(s[i] - s[i - 1]);
		if (deltas.length < 8) {
			setHz(null);
			return;
		}
		const sorted = [...deltas].sort((a, b) => a - b);
		const cut = sorted.slice(Math.floor(sorted.length * .15), Math.ceil(sorted.length * .85));
		const median = cut[Math.floor(cut.length / 2)] || sorted[Math.floor(sorted.length / 2)];
		const raw = 1e3 / Math.max(median, 2);
		const common = [
			60,
			90,
			120,
			180,
			240,
			360,
			480,
			720
		];
		let best = common[0];
		for (const c of common) if (Math.abs(c - raw) < Math.abs(best - raw)) best = c;
		setHz(Math.abs(best - raw) < 40 ? best : Math.round(raw));
	};
	const onPointerDown = (e) => {
		e.currentTarget.setPointerCapture(e.pointerId);
		stamps.current = [];
		start.current = performance.now();
		setActive(true);
		setHz(null);
		setElapsed(0);
		const loop = () => {
			setElapsed(performance.now() - start.current);
			raf.current = requestAnimationFrame(loop);
		};
		raf.current = requestAnimationFrame(loop);
	};
	const onPointerMove = (e) => {
		if (!active) return;
		stamps.current.push(performance.now());
		if (performance.now() - start.current >= SAMPLE_MS) {
			cancelAnimationFrame(raf.current);
			finish();
		}
		e.preventDefault();
	};
	const onPointerUp = () => {
		cancelAnimationFrame(raf.current);
		if (active) finish();
	};
	const progress = Math.min(1, elapsed / SAMPLE_MS);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: dict.touchHint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onPointerDown,
				onPointerMove,
				onPointerUp,
				onPointerCancel: onPointerUp,
				className: "relative flex h-64 w-full touch-none flex-col items-center justify-center overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)] select-none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-x-0 bottom-0 bg-primary/20",
						style: { height: `${progress * 100}%` }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, { className: `relative size-8 ${active ? "text-primary" : "text-muted"}` }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "relative mt-3 font-display text-lg font-semibold",
						children: active ? dict.measuring : dict.touchStart
					}),
					hardware ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "relative mt-1 text-[11px] text-subtle",
						children: [
							dict.touchRate,
							": ",
							hardware.touchSamplingHz,
							" Hz",
							hardware.touchSamplingEstimated ? ` (${dict.estimated})` : ""
						]
					}) : null
				]
			}),
			hz !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.16em] text-subtle",
					children: dict.touchResult
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "font-display text-3xl font-semibold tabular-nums text-accent",
					children: [hz, " Hz"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						setTouchHz(hz);
						setTab("settings");
					},
					children: dict.applyTouch
				})]
			}) : null
		]
	});
}
function ResultsShell() {
	const { dict, lang, tab, setTab, reset, toggleLang, hardware, settings } = useCaliber();
	const tabs = [
		{
			id: "specs",
			label: dict.specs
		},
		{
			id: "settings",
			label: dict.settings
		},
		{
			id: "touch",
			label: dict.touch
		}
	];
	const text = hardware && settings ? formatSettingsText(hardware, settings, lang) : "";
	const onCopy = async () => {
		try {
			await navigator.clipboard.writeText(text);
			toast.success(dict.copied);
		} catch {
			toast.error(dict.unavailable);
		}
	};
	const onShare = async () => {
		try {
			if (navigator.share) {
				await navigator.share({
					title: dict.shareTitle,
					text
				});
				return;
			}
			await navigator.clipboard.writeText(text);
			toast.message(dict.noShare);
		} catch {
			try {
				await navigator.clipboard.writeText(text);
				toast.message(dict.noShare);
			} catch {
				toast.error(dict.unavailable);
			}
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 pb-28 pt-4 sm:max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-sm font-semibold tracking-[0.22em] text-primary",
					children: "CALIBER"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-muted",
					children: hardware ? `${hardware.manufacturer} ${hardware.model}` : dict.app
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: toggleLang,
						"aria-label": dict.language,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: dict.language
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: reset,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), dict.rescan]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 grid grid-cols-3 gap-1 rounded-lg bg-surface p-1 shadow-[var(--shadow-border)]",
				children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(t.id),
					className: cn("flex h-10 items-center justify-center gap-1.5 rounded-md text-xs font-medium transition-colors duration-150", tab === t.id ? "bg-bg text-fg" : "text-muted hover:text-fg"),
					children: [
						t.id === "specs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-3.5" }) : null,
						t.id === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "size-3.5" }) : null,
						t.id === "touch" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, { className: "size-3.5" }) : null,
						t.label
					]
				}, t.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DevicePicker, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "/caliber-android.zip",
					download: true,
					className: "inline-flex h-11 items-center gap-2 rounded-md px-3 text-sm text-muted hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), dict.downloadApk]
				})]
			}),
			tab === "specs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecsView, {}) : null,
			tab === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}) : null,
			tab === "touch" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchTestView, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 px-4 py-3 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-lg grid-cols-2 gap-2 sm:max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void onCopy(),
						disabled: !text,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), dict.copy]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: () => void onShare(),
						disabled: !text,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), dict.share]
					})]
				})
			})
		]
	});
}
var STEPS_EN = [
	"CPU / SoC",
	"GPU renderer",
	"Memory map",
	"Display modes",
	"Battery + thermal",
	"Scoring engine"
];
var STEPS_AR = [
	"المعالج",
	"المعالج الرسومي",
	"خريطة الذاكرة",
	"أوضاع الشاشة",
	"البطارية والحرارة",
	"محرك التقييم"
];
function ScanOverlay() {
	const { dict, lang } = useCaliber();
	const steps = lang === "ar" ? STEPS_AR : STEPS_EN;
	const [i, setI] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setI((n) => Math.min(n + 1, steps.length - 1)), 380);
		return () => window.clearInterval(id);
	}, [steps.length]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col items-center justify-center px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-64 w-40 overflow-hidden rounded-[28px] bg-surface shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-8 top-3 h-4 rounded-full bg-bg" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan-line absolute inset-x-0 h-24" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-6 top-10 space-y-2",
						children: steps.map((step, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-[11px] uppercase tracking-[0.14em]",
							style: { opacity: idx <= i ? 1 : .28 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-1.5 rounded-full ${idx <= i ? "bg-primary" : "bg-subtle"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: idx <= i ? "text-fg" : "text-subtle",
								children: step
							})]
						}, step))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 font-display text-2xl font-semibold tracking-wide text-primary",
				children: dict.scanning
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: steps[i]
			})
		]
	});
}
function Home() {
	const phase = useCaliber((s) => s.phase);
	if (phase === "scanning") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanOverlay, {});
	if (phase === "results") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsShell, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {});
}
//#endregion
export { Home as component };
