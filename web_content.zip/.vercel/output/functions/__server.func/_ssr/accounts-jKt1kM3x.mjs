import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { m as useBootstrap, o as getLedger, r as createAccount, v as useInvalidateBooks } from "./use-books-BtZpLk9U.mjs";
import { h as todayIso, l as formatRial, n as GROUP_LABELS, s as formatJalali } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, n as Card, t as Badge } from "./card-Bb_-PO54.mjs";
import { t as Button } from "./button-BiViDDnZ.mjs";
import { n as Input, t as Field } from "./input-CAg20-g-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/accounts-jKt1kM3x.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AccountsPage() {
	const boot = useBootstrap();
	const invalidate = useInvalidateBooks();
	const accounts = boot.data?.accounts ?? [];
	const [code, setCode] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [parentCode, setParentCode] = (0, import_react.useState)("6111");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [ledgerId, setLedgerId] = (0, import_react.useState)(null);
	const [ledger, setLedger] = (0, import_react.useState)(null);
	async function save() {
		try {
			const parent = accounts.find((a) => a.code === parentCode);
			await createAccount({ data: {
				code,
				name,
				parentCode,
				nature: parent?.nature ?? "debit",
				groupCode: parent?.groupCode ?? "expense"
			} });
			toast.success("حساب ایجاد شد");
			setOpen(false);
			invalidate();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "خطا");
		}
	}
	async function openLedger(id) {
		setLedgerId(id);
		const data = await getLedger({ data: {
			accountId: id,
			from: "2026-03-21",
			to: todayIso()
		} });
		setLedger(data);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "کدینگ حساب‌ها",
			description: "چهار سطح: گروه، کل، معین، تفصیلی. ساختار پویا است و حساب جدید به سال مالی آسیب نمی‌زند.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "gold",
				onClick: () => setOpen(true),
				children: "حساب جدید"
			})
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mb-5 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "کد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: code,
						onChange: (e) => setCode(e.target.value),
						dir: "ltr"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نام",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "والد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: parentCode,
						onChange: (e) => setParentCode(e.target.value),
						className: "h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm",
						children: accounts.filter((a) => a.level < 4).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: a.code,
							children: [
								a.code,
								" ",
								a.name
							]
						}, a.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sm:col-span-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						children: "ثبت"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => setOpen(false),
						children: "انصراف"
					})]
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-[24px] border border-line bg-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[640px] text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-xs text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right",
							children: "کد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right",
							children: "نام"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right",
							children: "سطح"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right",
							children: "گروه"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right",
							children: "ماهیت"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2 font-medium",
							style: { paddingRight: 16 + (a.level - 1) * 12 },
							children: a.isPostable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-navy underline-offset-2 hover:underline",
								onClick: () => openLedger(a.id),
								children: a.code
							}) : a.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2",
							children: a.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2",
							children: a.level
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2",
							children: GROUP_LABELS[a.groupCode] ?? a.groupCode
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: a.nature === "debit" ? "default" : "gold",
								children: a.nature === "debit" ? "بدهکار" : "بستانکار"
							})
						})
					]
				}, a.id)) })]
			})
		}),
		ledger && ledgerId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-sm font-medium text-navy",
						children: [
							"دفتر کل ",
							ledger.account.code,
							" — ",
							ledger.account.name
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs text-muted",
						onClick: () => setLedger(null),
						children: "بستن"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 text-xs text-muted",
					children: ["مانده اول دوره: ", formatRial(ledger.opening)]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right",
								children: "تاریخ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right",
								children: "سند"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right",
								children: "شرح"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-left",
								children: "بدهکار"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-left",
								children: "بستانکار"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-left",
								children: "مانده"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: ledger.lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2",
								children: formatJalali(l.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2",
								children: l.number
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2",
								children: l.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-left",
								children: l.debit ? formatRial(l.debit) : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-left",
								children: l.credit ? formatRial(l.credit) : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-left",
								children: formatRial(l.balance)
							})
						]
					}, i)) })]
				})
			]
		}) : null
	] });
}
//#endregion
export { AccountsPage as component };
