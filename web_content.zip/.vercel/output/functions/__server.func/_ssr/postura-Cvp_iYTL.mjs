import { i as __toESM } from "../_runtime.mjs";
import { T as require_react, w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as useAppStore, E as toDateKey } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { t as Card } from "./card-ML3_y2lP.mjs";
import { d as Pencil, l as Play } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as Button } from "./router-0AvkMag6.mjs";
import { t as Textarea } from "./textarea-CwJtXt2R.mjs";
import { a as DialogHeader, c as WorkoutEditor, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as LiveExerciseCard, t as Dialog } from "./dialog-DZVhkm8j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/postura-Cvp_iYTL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PosturaPage() {
	const posture = useAppStore((s) => s.posture);
	const active = useAppStore((s) => s.activeSession);
	const startSession = useAppStore((s) => s.startSession);
	const completeSet = useAppStore((s) => s.completeSet);
	const undoSet = useAppStore((s) => s.undoSet);
	const updateLiveExercise = useAppStore((s) => s.updateLiveExercise);
	const finishSession = useAppStore((s) => s.finishSession);
	const abandonSession = useAppStore((s) => s.abandonSession);
	const setSessionNotes = useAppStore((s) => s.setSessionNotes);
	const updatePostureExercise = useAppStore((s) => s.updatePostureExercise);
	const addPostureExercise = useAppStore((s) => s.addPostureExercise);
	const removePostureExercise = useAppStore((s) => s.removePostureExercise);
	const duplicatePostureExercise = useAppStore((s) => s.duplicatePostureExercise);
	const movePostureExercise = useAppStore((s) => s.movePostureExercise);
	const restorePosture = useAppStore((s) => s.restorePosture);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [finishOpen, setFinishOpen] = (0, import_react.useState)(false);
	const live = active?.type === "postura" ? active : null;
	function start() {
		if (active && active.type !== "postura") {
			toast.error("Finalize a sessão em andamento antes de começar outra.");
			return;
		}
		startSession({
			date: toDateKey(/* @__PURE__ */ new Date()),
			dayKey: "postura",
			exercises: posture,
			type: "postura",
			title: "Rotina de postura"
		});
		setEditing(false);
		toast.success("Rotina iniciada");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Mobilidade",
				title: "Postura & Mobilidade",
				subtitle: "Rotina própria — não entra no treino de terça ou quinta.",
				action: live ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: editing ? "secondary" : "outline",
					size: "sm",
					onClick: () => setEditing((v) => !v),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}),
						" ",
						editing ? "Fechar" : "Editar"
					]
				})
			}),
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mb-4 flex items-center justify-between gap-3 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Rotina em andamento"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-lg font-semibold tabular-nums",
					children: [
						live.exercises.reduce((a, e) => a + e.completedSets, 0),
						"/",
						live.exercises.reduce((a, e) => a + e.sets, 0),
						" séries"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: abandonSession,
						children: "Descartar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => setFinishOpen(true),
						children: "Finalizar"
					})]
				})]
			}) : editing ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mb-4 w-full",
				size: "lg",
				onClick: start,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), " Iniciar rotina de postura"]
			}),
			editing && !live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkoutEditor, {
				exercises: posture,
				handlers: {
					onUpdate: (id, patch) => updatePostureExercise(id, patch),
					onAdd: () => addPostureExercise(),
					onRemove: (id) => removePostureExercise(id),
					onDuplicate: (id) => duplicatePostureExercise(id),
					onMove: (id, dir) => movePostureExercise(id, dir),
					onRestore: () => restorePosture()
				}
			}) : live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: live.exercises.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveExerciseCard, {
					exercise: ex,
					onCompleteSet: () => completeSet(ex.id),
					onUndoSet: () => undoSet(ex.id),
					onPatch: (patch) => updateLiveExercise(ex.id, patch)
				}, ex.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: posture.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display font-semibold",
							children: ex.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								ex.sets,
								" × ",
								ex.reps,
								" · descanso ",
								ex.restSec,
								"s"
							]
						}),
						ex.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted-foreground",
							children: ex.notes
						}) : null
					]
				}, ex.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: finishOpen,
				onOpenChange: setFinishOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Finalizar rotina" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Salva como sessão de postura." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: live?.notes ?? "",
						onChange: (e) => setSessionNotes(e.target.value),
						placeholder: "Observações"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setFinishOpen(false),
						children: "Voltar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							finishSession();
							setFinishOpen(false);
							toast.success("Sessão salva");
						},
						children: "Salvar"
					})] })
				] })
			})
		]
	});
}
//#endregion
export { PosturaPage as component };
