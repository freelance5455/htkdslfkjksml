import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as uid, V as useAppStore, _ as PageHeader, a as Button, h as Notice, u as Field, v as Panel } from "./ui-CJMJB--P.mjs";
import { a as startClicker, c as validateClicker, i as resumeClicker, o as stopClicker, r as pauseClicker, s as useClickerRuntime } from "./router-DG3Pqbtv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/clicker-DzdZlJJB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClickerPage() {
	const config = useAppStore((state) => state.clicker);
	const presets = useAppStore((state) => state.clickPresets);
	const setClicker = useAppStore((state) => state.setClicker);
	const setPoints = useAppStore((state) => state.setClickerPoints);
	const savePreset = useAppStore((state) => state.saveClickPreset);
	const removePreset = useAppStore((state) => state.removeClickPreset);
	const phase = useClickerRuntime((state) => state.phase);
	const taps = useClickerRuntime((state) => state.taps);
	const cycles = useClickerRuntime((state) => state.cycles);
	const pulse = useClickerRuntime((state) => state.pulse);
	const activePointId = useClickerRuntime((state) => state.activePointId);
	const nextFireAt = useClickerRuntime((state) => state.nextFireAt);
	const error = useClickerRuntime((state) => state.error);
	const lastSummary = useClickerRuntime((state) => state.lastSummary);
	const [presetName, setPresetName] = (0, import_react.useState)("");
	const [presetError, setPresetError] = (0, import_react.useState)(null);
	const [now, setNow] = (0, import_react.useState)(null);
	const locked = phase !== "stopped";
	(0, import_react.useEffect)(() => {
		if (!locked || nextFireAt == null) return;
		setNow(Date.now());
		const id = window.setInterval(() => setNow(Date.now()), 100);
		return () => window.clearInterval(id);
	}, [locked, nextFireAt]);
	const waitMs = nextFireAt != null && now != null ? Math.max(0, nextFireAt - now) : null;
	const validation = validateClicker(config);
	const unlimited = config.repeat === 0 && config.durationSec === 0;
	function place(x, y) {
		if (locked) return;
		if (config.mode === "single") {
			const current = config.points[0] ?? {
				id: uid(),
				label: "Point 1",
				x: 50,
				y: 50,
				delayMs: config.intervalMs
			};
			setPoints([{
				...current,
				x,
				y
			}]);
			return;
		}
		if (config.points.length >= 12) {
			setPresetError("This sequence is limited to 12 points.");
			return;
		}
		const point = {
			id: uid(),
			label: `Point ${config.points.length + 1}`,
			x,
			y,
			delayMs: config.intervalMs
		};
		setPoints([...config.points, point]);
		setPresetError(null);
	}
	function updatePoint(id, patch) {
		setPoints(config.points.map((point) => point.id === id ? {
			...point,
			...patch
		} : point));
	}
	function movePoint(index, direction) {
		const next = index + direction;
		if (next < 0 || next >= config.points.length) return;
		const points = [...config.points];
		const [item] = points.splice(index, 1);
		points.splice(next, 0, item);
		setPoints(points);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Practice only",
				title: "Auto Clicker",
				subtitle: "Taps stay on this pad. Cross-app execution is unavailable. This page will not click other apps, games, ads, or purchases."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: "Cross-app execution: unavailable"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "A browser page cannot inject clicks into other Android apps. System-wide automation needs a separate native app and an accessibility service you explicitly turn on. This app never enables that, never hides automation, and never bypasses anti-cheat."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Status",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-semibold",
						role: "status",
						children: phase === "running" ? "Running inside this practice pad" : phase === "paused" ? "Paused" : phase === "preview" ? "Previewing one cycle" : "Stopped"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm tabular-nums text-muted",
						children: [
							taps,
							" practice taps · ",
							cycles,
							" cycles",
							waitMs != null && (phase === "running" || phase === "preview") ? ` · next in ${Math.ceil(waitMs / 100) / 10}s` : ""
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
							tone: "warn",
							children: error
						})
					}) : null,
					!error && lastSummary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: lastSummary })
					}) : null,
					unlimited ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-primary",
						children: "No repeat or duration limit. It runs until you press Stop."
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Practice pad",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: config.mode === "single" ? "Tap the pad to place the single point. Drag the point to move it." : "Tap empty space to add a point. Drag a point to move it."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative h-64 w-full overflow-hidden rounded-xl bg-bg shadow-[var(--shadow-ring)]",
						onPointerDown: (event) => {
							if (event.target !== event.currentTarget) return;
							const rect = event.currentTarget.getBoundingClientRect();
							place(clampPercent((event.clientX - rect.left) / rect.width), clampPercent((event.clientY - rect.top) / rect.height));
						},
						children: [config.points.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PointMarker, {
							point,
							index,
							active: activePointId === point.id,
							pulse,
							locked,
							onMove: (x, y) => updatePoint(point.id, {
								x,
								y
							})
						}, point.id)), config.points.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pointer-events-none absolute inset-0 grid place-items-center text-sm text-faint",
							children: "Tap to add a point"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-faint",
						children: "If this browser tab is in the background, timing can drift. That still does not click outside this page."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: resumeClicker,
						children: "Resume"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => startClicker("run"),
						disabled: locked || Boolean(validation),
						children: "Start"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: pauseClicker,
						disabled: phase !== "running" && phase !== "preview",
						children: "Pause"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => startClicker("preview"),
						disabled: locked || Boolean(validation),
						children: "Preview one cycle"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => stopClicker("Stopped."),
						disabled: !locked,
						children: "Stop"
					})
				]
			}),
			validation && !locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				tone: "warn",
				children: validation
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Timing",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stack",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							role: "group",
							"aria-label": "Click mode",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								pressed: config.mode === "single",
								disabled: locked,
								onClick: () => setClicker({ mode: "single" }),
								children: "Single point"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								pressed: config.mode === "sequence",
								disabled: locked,
								onClick: () => setClicker({ mode: "sequence" }),
								children: "Sequence"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberCommit, {
							label: "Interval (ms)",
							hint: "Gap between taps in single mode, and between cycles in a sequence. Minimum 50 ms.",
							value: config.intervalMs,
							min: 50,
							max: 6e4,
							disabled: locked,
							onCommit: (intervalMs) => setClicker({ intervalMs })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								100,
								250,
								500,
								1e3
							].map((interval) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Chip, {
								pressed: config.intervalMs === interval,
								disabled: locked,
								onClick: () => setClicker({ intervalMs: interval }),
								children: [interval, " ms"]
							}, interval))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberCommit, {
							label: "Repetitions",
							hint: "Cycles to run. 0 means no count limit.",
							value: config.repeat,
							min: 0,
							max: 9999,
							disabled: locked,
							onCommit: (repeat) => setClicker({ repeat })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									pressed: config.repeat === 1,
									disabled: locked,
									onClick: () => setClicker({ repeat: 1 }),
									children: "Once"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									pressed: config.repeat === 10,
									disabled: locked,
									onClick: () => setClicker({ repeat: 10 }),
									children: "10 times"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									pressed: config.repeat === 0,
									disabled: locked,
									onClick: () => setClicker({ repeat: 0 }),
									children: "No count limit"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberCommit, {
							label: "Duration (seconds)",
							hint: "0 means no time limit. Pause does not count toward the duration.",
							value: config.durationSec,
							min: 0,
							max: 86400,
							disabled: locked,
							onCommit: (durationSec) => setClicker({ durationSec })
						}),
						locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Stop the practice run to edit timing." }) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Points",
				children: [config.points.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No points yet."
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "stack",
					children: config.points.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg bg-surface-2 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: config.mode === "single" ? "Single point" : `Step ${index + 1}`
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											className: "px-2",
											disabled: locked || index === 0,
											onClick: () => movePoint(index, -1),
											children: "Up"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											className: "px-2",
											disabled: locked || index === config.points.length - 1,
											onClick: () => movePoint(index, 1),
											children: "Down"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											className: "px-2",
											disabled: locked,
											onClick: () => setPoints(config.points.filter((item) => item.id !== point.id)),
											children: "Remove"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input",
									"aria-label": `Label for point ${index + 1}`,
									value: point.label,
									maxLength: 40,
									disabled: locked,
									onChange: (event) => updatePoint(point.id, { label: event.target.value })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field-input tabular-nums",
									"aria-label": `Delay before point ${index + 1} in milliseconds`,
									inputMode: "numeric",
									disabled: locked,
									value: point.delayMs,
									onChange: (event) => updatePoint(point.id, { delayMs: clampDelay(Number(event.target.value)) })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-faint tabular-nums",
								children: [
									"x ",
									point.x.toFixed(0),
									" · y ",
									point.y.toFixed(0),
									" · delay before tap"
								]
							})
						]
					}, point.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				id: "presets",
				title: "Presets",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Preset name",
						error: presetError,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field-input",
							value: presetName,
							maxLength: 40,
							onChange: (event) => setPresetName(event.target.value),
							placeholder: "Warm-up sequence"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						variant: "quiet",
						onClick: () => {
							if (!savePreset(presetName)) {
								setPresetError("Name the preset before saving.");
								return;
							}
							setPresetName("");
							setPresetError(null);
						},
						children: "Save current setup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-line",
						children: presets.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold",
									children: preset.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-faint",
									children: [
										preset.mode === "single" ? "Single" : `${preset.points.length} points`,
										" · ",
										preset.intervalMs,
										" ms · ",
										preset.repeat || "no",
										" repeats"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex shrink-0 gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "quiet",
									onClick: () => {
										if (locked) stopClicker("Stopped to load a preset.");
										setClicker({
											intervalMs: preset.intervalMs,
											repeat: preset.repeat,
											durationSec: preset.durationSec,
											mode: preset.mode
										});
										setPoints(preset.points.map((point) => ({ ...point })));
									},
									children: "Load"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: () => removePreset(preset.id),
									children: "Delete"
								})]
							})]
						}, preset.id))
					}),
					presets.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No presets saved yet."
					}) : null
				]
			})
		]
	});
}
function PointMarker({ point, index, active, pulse, locked, onMove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-label": point.label,
		className: "absolute z-10 grid size-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-primary text-sm font-semibold text-primary-fg",
		style: {
			left: `${point.x}%`,
			top: `${point.y}%`
		},
		onPointerDown: (event) => {
			if (locked) return;
			event.stopPropagation();
			const pad = event.currentTarget.parentElement;
			if (!pad) return;
			const id = event.pointerId;
			const move = (ev) => {
				if (ev.pointerId !== id) return;
				const rect = pad.getBoundingClientRect();
				onMove(clampPercent((ev.clientX - rect.left) / rect.width), clampPercent((ev.clientY - rect.top) / rect.height));
			};
			const up = (ev) => {
				if (ev.pointerId !== id) return;
				window.removeEventListener("pointermove", move);
				window.removeEventListener("pointerup", up);
			};
			window.addEventListener("pointermove", move);
			window.addEventListener("pointerup", up);
		},
		children: [active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tap-pulse pointer-events-none absolute left-1/2 top-1/2 size-11 rounded-full bg-primary" }, pulse) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative",
			children: index + 1
		})]
	});
}
function Chip({ pressed, disabled, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		disabled,
		onClick,
		className: `min-h-11 rounded-lg px-3 text-sm font-semibold disabled:opacity-50 ${pressed ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`,
		children
	});
}
function NumberCommit({ label, hint, value, min, max, disabled, onCommit }) {
	const [text, setText] = (0, import_react.useState)(String(value));
	(0, import_react.useEffect)(() => setText(String(value)), [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		hint,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field-input tabular-nums",
			inputMode: "numeric",
			disabled,
			value: text,
			onChange: (event) => setText(event.target.value),
			onBlur: () => {
				const next = Number(text);
				if (!Number.isFinite(next)) {
					setText(String(value));
					return;
				}
				const clamped = Math.min(max, Math.max(min, Math.round(next)));
				onCommit(clamped);
				setText(String(clamped));
			}
		})
	});
}
function clampPercent(value) {
	if (!Number.isFinite(value)) return 50;
	return Math.min(96, Math.max(4, Math.round(value * 10) / 10));
}
function clampDelay(value) {
	if (!Number.isFinite(value)) return 500;
	return Math.min(6e4, Math.max(50, Math.round(value)));
}
var SplitComponent = ClickerPage;
//#endregion
export { SplitComponent as component };
