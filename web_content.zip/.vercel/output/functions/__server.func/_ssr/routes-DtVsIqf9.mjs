import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, i as RotateCcw, n as Volume2, o as Pause, s as House, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DtVsIqf9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var noise = null;
function context() {
	if (typeof window === "undefined") return null;
	const AC = window.AudioContext;
	if (!AC) return null;
	if (!ctx) ctx = new AC();
	return ctx;
}
function noiseBuffer(ac) {
	if (noise && noise.sampleRate === ac.sampleRate) return noise;
	const length = Math.floor(ac.sampleRate * .4);
	const buffer = ac.createBuffer(1, length, ac.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
	noise = buffer;
	return buffer;
}
function unlockAudio() {
	const ac = context();
	if (ac && ac.state === "suspended") ac.resume();
}
function tone(ac, freq, dur, type, gain, slide = 0) {
	const osc = ac.createOscillator();
	const g = ac.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, ac.currentTime);
	if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), ac.currentTime + dur);
	g.gain.setValueAtTime(gain, ac.currentTime);
	g.gain.exponentialRampToValueAtTime(1e-4, ac.currentTime + dur);
	osc.connect(g);
	g.connect(ac.destination);
	osc.start();
	osc.stop(ac.currentTime + dur + .02);
}
function burst$1(ac, dur, gain) {
	const src = ac.createBufferSource();
	src.buffer = noiseBuffer(ac);
	const filter = ac.createBiquadFilter();
	filter.type = "highpass";
	filter.frequency.value = 800;
	const g = ac.createGain();
	g.gain.setValueAtTime(gain, ac.currentTime);
	g.gain.exponentialRampToValueAtTime(1e-4, ac.currentTime + dur);
	src.connect(filter);
	filter.connect(g);
	g.connect(ac.destination);
	src.start();
	src.stop(ac.currentTime + dur);
}
function playSfx(name) {
	const ac = context();
	if (!ac || ac.state !== "running") return;
	switch (name) {
		case "shoot":
			tone(ac, 880, .045, "square", .025, 220);
			break;
		case "hit":
			tone(ac, 240, .05, "square", .02, -80);
			break;
		case "explode":
			burst$1(ac, .18, .05);
			tone(ac, 180, .16, "sawtooth", .03, -120);
			break;
		case "hurt":
			burst$1(ac, .22, .06);
			tone(ac, 110, .24, "sawtooth", .04, -70);
			break;
		case "pickup":
			tone(ac, 660, .07, "square", .03);
			tone(ac, 880, .08, "square", .028);
			tone(ac, 1180, .1, "square", .026);
			break;
		case "wave":
			tone(ac, 440, .12, "triangle", .03, 220);
			break;
		case "boss":
			tone(ac, 98, .35, "sawtooth", .04, -40);
			tone(ac, 196, .28, "square", .02, 80);
	}
}
var INK = "#07080f";
var FG = "#e8eef8";
var MUTED = "#8b93a7";
var CYAN = "#3ee0ff";
var AMBER = "#ffb020";
var THREAT = "#ff3d7a";
function bannerAlpha(remaining, total = 1.05) {
	const age = total - remaining;
	return Math.max(0, Math.min(1, age / .16, remaining / .28));
}
function draw(ctx, sim, sprites) {
	const canvas = ctx.canvas;
	const mag = sim.shake;
	const sx = Math.sin(sim.clock * 48) * mag;
	const sy = Math.cos(sim.clock * 57) * mag;
	ctx.setTransform(1, 0, 0, 1, 0, 0);
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	const scaleX = canvas.width / 420;
	const scaleY = canvas.height / 760;
	ctx.setTransform(scaleX, 0, 0, scaleY, sx * scaleX, sy * scaleY);
	ctx.imageSmoothingEnabled = true;
	ctx.fillStyle = INK;
	ctx.fillRect(-30, -30, 480, 820);
	wash(ctx, sim.clock);
	for (const star of sim.stars) {
		if (star.layer !== 0) continue;
		ctx.globalAlpha = star.a * .55;
		ctx.fillStyle = "#9bb0d0";
		ctx.fillRect(star.x, star.y, star.r, star.r);
	}
	ctx.globalAlpha = 1;
	for (const star of sim.stars) {
		if (star.layer !== 1) continue;
		ctx.globalAlpha = star.a * .8;
		ctx.fillStyle = FG;
		ctx.beginPath();
		ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
	for (const star of sim.stars) {
		if (star.layer !== 2) continue;
		ctx.globalAlpha = star.a;
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(star.x, star.y, star.r, star.r * 2.4);
	}
	ctx.globalAlpha = 1;
	for (const p of sim.particles) {
		if (!p.alive) continue;
		ctx.globalAlpha = Math.max(0, p.life / p.max);
		ctx.fillStyle = p.color;
		ctx.beginPath();
		ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
	for (const item of sim.pickups) {
		if (!item.alive) continue;
		drawPickup(ctx, sim, sprites, item.kind, item.x, item.y + Math.sin(sim.clock * 4 + item.x) * 3);
	}
	for (const b of sim.bullets) {
		if (!b.alive || b.friendly) continue;
		drawEnemyShot(ctx, b.x, b.y);
	}
	for (const e of sim.enemies) {
		if (!e.alive) continue;
		drawEnemy(ctx, sim, sprites, e);
	}
	for (const b of sim.bullets) {
		if (!b.alive || !b.friendly) continue;
		drawPlayerShot(ctx, b.x, b.y, b.vx, b.vy);
	}
	ctx.save();
	ctx.globalCompositeOperation = "lighter";
	for (const f of sim.flashes) {
		if (!f.alive) continue;
		const k = f.life / f.max;
		const rad = 18 * k;
		const g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, rad);
		g.addColorStop(0, `rgba(255,255,255,${.95 * k})`);
		g.addColorStop(.35, `rgba(62,224,255,${.75 * k})`);
		g.addColorStop(1, "rgba(62,224,255,0)");
		ctx.fillStyle = g;
		ctx.beginPath();
		ctx.arc(f.x, f.y, rad, 0, Math.PI * 2);
		ctx.fill();
		ctx.save();
		ctx.translate(f.x, f.y);
		ctx.rotate(f.angle);
		ctx.fillStyle = `rgba(255,236,200,${.85 * k})`;
		ctx.fillRect(-2.2, -16 * k, 4.4, 20 * k);
		ctx.restore();
	}
	ctx.restore();
	if (sim.phase === "title") drawPlayerSprite(ctx, sprites, 210, 760 * .78 + Math.sin(sim.clock * 1.5) * 7, Math.sin(sim.clock * .8) * .08, 1);
	else if (sim.player.alive && sim.phase !== "over") {
		const p = sim.player;
		if (!(p.iframes > 0 && Math.floor(sim.clock * 16) % 2 === 0)) {
			const bank = Math.max(-.4, Math.min(.4, p.vx / 320));
			drawPlayerSprite(ctx, sprites, p.x, p.y, bank, 1);
		}
		if (p.shield > 0) {
			ctx.save();
			ctx.translate(p.x, p.y);
			ctx.rotate(sim.clock * 2.2);
			ctx.strokeStyle = CYAN;
			ctx.globalAlpha = p.shield < 2 ? .45 + Math.sin(sim.clock * 18) * .35 : .85;
			ctx.lineWidth = 2;
			ctx.setLineDash([7, 5]);
			ctx.beginPath();
			ctx.arc(0, 0, 26, 0, Math.PI * 2);
			ctx.stroke();
			ctx.restore();
			ctx.setLineDash([]);
			ctx.globalAlpha = 1;
		}
	} else if (!sim.player.alive) drawPlayerSprite(ctx, sprites, sim.player.x, sim.player.y, 0, .25);
	for (const f of sim.floats) {
		if (!f.alive) continue;
		ctx.globalAlpha = Math.max(0, f.life / f.max);
		ctx.fillStyle = f.color;
		ctx.font = "700 14px Exo 2, sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(f.text, f.x, f.y);
	}
	ctx.globalAlpha = 1;
	if (sim.phase !== "title") drawHud(ctx, sim);
	if (sim.waveState === "banner" && sim.phase === "playing") {
		ctx.globalAlpha = bannerAlpha(sim.waveTimer);
		ctx.fillStyle = FG;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.font = "700 28px Exo 2, sans-serif";
		ctx.fillText(sim.banner, 210, 760 * .34);
		ctx.globalAlpha = 1;
	}
	if (sim.phase === "playing" && sim.runTime < 4.2) {
		ctx.globalAlpha = sim.runTime < 3 ? .9 : Math.max(0, .9 * (1 - (sim.runTime - 3) / 1.2));
		ctx.fillStyle = FG;
		ctx.font = "600 13px Sora, sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText("WASD or drag  ·  guns are live", 210, 682);
		ctx.globalAlpha = 1;
	}
	if (sim.hurtFlash > 0) {
		ctx.fillStyle = `rgba(255,61,122,${sim.hurtFlash * .28})`;
		ctx.fillRect(-20, -20, 460, 800);
	}
	if (sim.phase === "paused" || sim.phase === "over") {
		ctx.fillStyle = "rgba(7,8,15,0.5)";
		ctx.fillRect(-20, -20, 460, 800);
	}
}
function wash(ctx, t) {
	ctx.save();
	ctx.globalAlpha = .55;
	const a = ctx.createRadialGradient(210, 114, 20, 210, 152, 280);
	a.addColorStop(0, "rgba(62,224,255,0.09)");
	a.addColorStop(1, "rgba(62,224,255,0)");
	ctx.fillStyle = a;
	ctx.fillRect(0, 0, 420, 760);
	const b = ctx.createRadialGradient(420 * (.2 + Math.sin(t * .15) * .05), 532, 10, 126, 570, 220);
	b.addColorStop(0, "rgba(255,176,32,0.06)");
	b.addColorStop(1, "rgba(255,176,32,0)");
	ctx.fillStyle = b;
	ctx.fillRect(0, 0, 420, 760);
	ctx.restore();
}
function drawPlayerSprite(ctx, sprites, x, y, rot, alpha) {
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(rot);
	ctx.globalAlpha = alpha;
	const img = sprites.player;
	if (img) ctx.drawImage(img, -40, -40, 80, 80);
	else drawVectorPlayer(ctx);
	ctx.restore();
}
function drawVectorPlayer(ctx) {
	const g = ctx.createLinearGradient(0, -30, 0, 28);
	g.addColorStop(0, "#f4fbff");
	g.addColorStop(.45, CYAN);
	g.addColorStop(1, "#12343f");
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.moveTo(0, -32);
	ctx.lineTo(16, 10);
	ctx.lineTo(7, 6);
	ctx.lineTo(11, 26);
	ctx.lineTo(0, 16);
	ctx.lineTo(-11, 26);
	ctx.lineTo(-7, 6);
	ctx.lineTo(-16, 10);
	ctx.closePath();
	ctx.fill();
	ctx.fillStyle = AMBER;
	ctx.fillRect(-6, 16, 4, 8);
	ctx.fillRect(2, 16, 4, 8);
}
function enemyRotation(e) {
	if (e.kind === "boss") return Math.PI + Math.max(-.22, Math.min(.22, e.vx / 500));
	if (e.kind === "gunner" && e.pattern !== "swoop") return Math.PI + Math.max(-.18, Math.min(.18, e.vx / 220));
	return Math.atan2(e.vy, e.vx) + Math.PI / 2;
}
function drawEnemy(ctx, sim, sprites, e) {
	const rot = enemyRotation(e);
	ctx.save();
	ctx.translate(e.x, e.y);
	ctx.rotate(rot);
	if (e.flash > 0) ctx.filter = "brightness(2.4)";
	const img = sprites[e.kind];
	if (img) {
		const s = e.r * 3.1;
		ctx.drawImage(img, -s / 2, -s / 2, s, s);
	} else if (e.kind === "dart") drawDart(ctx, e.r);
	else if (e.kind === "weaver") drawWeaver(ctx, e.r);
	else if (e.kind === "gunner") drawGunner(ctx, e.r);
	else drawBoss(ctx, e.r, sim.clock);
	ctx.filter = "none";
	ctx.restore();
	if (e.kind === "gunner" || e.kind === "boss") {
		const bw = e.kind === "boss" ? 92 : 32;
		const y = e.y - e.r - 14;
		ctx.fillStyle = "rgba(0,0,0,0.45)";
		ctx.fillRect(e.x - bw / 2, y, bw, 4);
		ctx.fillStyle = e.kind === "boss" ? AMBER : THREAT;
		ctx.fillRect(e.x - bw / 2, y, bw * Math.max(0, e.hp / e.maxHp), 4);
	}
	if ((e.kind === "gunner" || e.kind === "boss") && e.shoot < .32 && e.shoot > 0 && e.y > 20) {
		ctx.save();
		ctx.translate(e.x, e.y + e.r * .85);
		ctx.rotate(Math.PI / 4);
		ctx.fillStyle = THREAT;
		ctx.globalAlpha = .85;
		ctx.fillRect(-4, -4, 8, 8);
		ctx.restore();
		ctx.globalAlpha = 1;
	}
}
function drawDart(ctx, r) {
	const g = ctx.createLinearGradient(0, -r * 1.5, 0, r);
	g.addColorStop(0, "#ffd0dc");
	g.addColorStop(.4, THREAT);
	g.addColorStop(1, "#3a0d18");
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.moveTo(0, -r * 1.55);
	ctx.lineTo(r * .78, r * .95);
	ctx.lineTo(0, r * .45);
	ctx.lineTo(-r * .78, r * .95);
	ctx.closePath();
	ctx.fill();
	ctx.fillStyle = AMBER;
	ctx.beginPath();
	ctx.arc(0, r * .72, r * .18, 0, Math.PI * 2);
	ctx.fill();
}
function drawWeaver(ctx, r) {
	ctx.fillStyle = "#0e3d36";
	ctx.beginPath();
	ctx.ellipse(0, 2, r * 1.35, r * .62, 0, 0, Math.PI * 2);
	ctx.fill();
	const g = ctx.createLinearGradient(-r, 0, r, 0);
	g.addColorStop(0, "#06352e");
	g.addColorStop(.5, "#1aa88a");
	g.addColorStop(1, "#06352e");
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.moveTo(-r * 1.45, r * .15);
	ctx.quadraticCurveTo(0, -r * 1.35, r * 1.45, r * .15);
	ctx.quadraticCurveTo(0, r * .15, -r * 1.45, r * .15);
	ctx.fill();
	ctx.fillStyle = "#d8fff6";
	ctx.beginPath();
	ctx.arc(0, -r * .05, r * .28, 0, Math.PI * 2);
	ctx.fill();
}
function drawGunner(ctx, r) {
	ctx.fillStyle = "#243044";
	ctx.beginPath();
	ctx.roundRect(-r * .95, -r * .85, r * 1.9, r * 1.7, 8);
	ctx.fill();
	const g = ctx.createLinearGradient(0, -r, 0, r);
	g.addColorStop(0, "#d5e2f2");
	g.addColorStop(.5, "#7f97b8");
	g.addColorStop(1, "#1c2838");
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.roundRect(-r * .72, -r * .7, r * 1.44, r * 1.45, 6);
	ctx.fill();
	ctx.fillStyle = "#c47a3a";
	ctx.fillRect(-r * .12, -r * 1.35, r * .24, r * .7);
	ctx.fillStyle = AMBER;
	ctx.fillRect(-r * .55, r * .45, r * .28, r * .22);
	ctx.fillRect(r * .27, r * .45, r * .28, r * .22);
}
function drawBoss(ctx, r, t) {
	ctx.fillStyle = "#14110e";
	ctx.beginPath();
	ctx.moveTo(0, -r * 1.15);
	ctx.lineTo(r * 1.35, -r * .2);
	ctx.lineTo(r * 1.15, r * .85);
	ctx.lineTo(0, r * .55);
	ctx.lineTo(-r * 1.15, r * .85);
	ctx.lineTo(-r * 1.35, -r * .2);
	ctx.closePath();
	ctx.fill();
	const g = ctx.createLinearGradient(0, -r, 0, r);
	g.addColorStop(0, "#4a3b28");
	g.addColorStop(.4, "#2a241c");
	g.addColorStop(1, "#0e0c0a");
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.moveTo(0, -r * .95);
	ctx.lineTo(r * 1.05, -r * .15);
	ctx.lineTo(r * .9, r * .62);
	ctx.lineTo(0, r * .38);
	ctx.lineTo(-r * .9, r * .62);
	ctx.lineTo(-r * 1.05, -r * .15);
	ctx.closePath();
	ctx.fill();
	ctx.fillStyle = AMBER;
	for (const x of [
		-r * .38,
		0,
		r * .38
	]) ctx.fillRect(x - 3, -r * 1.2, 6, r * .38);
	ctx.fillStyle = CYAN;
	ctx.globalAlpha = .75 + Math.sin(t * 6) * .25;
	ctx.fillRect(-r * .45, -r * .15, r * .9, 3);
	ctx.globalAlpha = 1;
	ctx.fillStyle = "#ff7a1a";
	ctx.fillRect(-r * .7, r * .48, r * .28, r * .16);
	ctx.fillRect(r * .42, r * .48, r * .28, r * .16);
}
function drawPickup(ctx, sim, sprites, kind, x, y) {
	const img = sprites[kind];
	ctx.save();
	ctx.translate(x, y);
	const pulse = 1 + Math.sin(sim.clock * 5) * .06;
	ctx.scale(pulse, pulse);
	if (img && kind !== "speed") ctx.drawImage(img, -16, -16, 32, 32);
	else if (kind === "multi") {
		ctx.fillStyle = CYAN;
		ctx.beginPath();
		ctx.roundRect(-11, -11, 22, 22, 6);
		ctx.fill();
		ctx.fillStyle = INK;
		ctx.fillRect(-5, -7, 2, 10);
		ctx.fillRect(-1, -7, 2, 10);
		ctx.fillRect(3, -7, 2, 10);
	} else if (kind === "shield") {
		ctx.strokeStyle = CYAN;
		ctx.lineWidth = 2.5;
		ctx.beginPath();
		ctx.moveTo(0, -12);
		ctx.lineTo(11, -4);
		ctx.lineTo(8, 10);
		ctx.lineTo(0, 14);
		ctx.lineTo(-8, 10);
		ctx.lineTo(-11, -4);
		ctx.closePath();
		ctx.stroke();
	} else {
		ctx.fillStyle = AMBER;
		ctx.beginPath();
		ctx.moveTo(0, -13);
		ctx.lineTo(11, 2);
		ctx.lineTo(3, 2);
		ctx.lineTo(6, 13);
		ctx.lineTo(-8, 0);
		ctx.lineTo(1, 0);
		ctx.closePath();
		ctx.fill();
	}
	ctx.restore();
}
function drawPlayerShot(ctx, x, y, vx, vy) {
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(Math.atan2(vy, vx) + Math.PI / 2);
	const g = ctx.createLinearGradient(0, -12, 0, 8);
	g.addColorStop(0, "#ffffff");
	g.addColorStop(.4, CYAN);
	g.addColorStop(1, "rgba(62,224,255,0)");
	ctx.fillStyle = g;
	ctx.fillRect(-1.6, -12, 3.2, 16);
	ctx.restore();
}
function drawEnemyShot(ctx, x, y) {
	ctx.fillStyle = THREAT;
	ctx.beginPath();
	ctx.arc(x, y, 4.2, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = "#ffd0dc";
	ctx.beginPath();
	ctx.arc(x, y, 1.7, 0, Math.PI * 2);
	ctx.fill();
}
function drawHud(ctx, sim) {
	ctx.textAlign = "left";
	ctx.textBaseline = "top";
	ctx.fillStyle = MUTED;
	ctx.font = "600 11px Exo 2, sans-serif";
	ctx.fillText("SCORE", 16, 16);
	ctx.fillStyle = FG;
	ctx.font = "700 22px Exo 2, sans-serif";
	ctx.fillText(sim.score.toLocaleString("en-US"), 16, 30);
	ctx.fillStyle = MUTED;
	ctx.font = "600 11px Exo 2, sans-serif";
	ctx.fillText("LIVES", 16, 60);
	for (let i = 0; i < sim.lives; i++) {
		ctx.fillStyle = CYAN;
		ctx.beginPath();
		ctx.moveTo(62 + i * 14, 64);
		ctx.lineTo(68 + i * 14, 74);
		ctx.lineTo(56 + i * 14, 74);
		ctx.closePath();
		ctx.fill();
	}
	ctx.textAlign = "center";
	ctx.fillStyle = CYAN;
	ctx.font = "600 13px Exo 2, sans-serif";
	const boss = sim.enemies.find((e) => e.alive && e.kind === "boss");
	ctx.fillText(boss ? "DREADNOUGHT" : `WAVE ${sim.wave}`, 210, 16);
	if (boss) {
		const bw = 140;
		ctx.fillStyle = "rgba(255,255,255,0.12)";
		ctx.fillRect(210 - bw / 2, 36, bw, 5);
		ctx.fillStyle = AMBER;
		ctx.fillRect(210 - bw / 2, 36, bw * Math.max(0, boss.hp / boss.maxHp), 5);
	}
	const chips = [];
	if (sim.player.multi > 0) chips.push({
		label: `SPREAD ${sim.player.multi}`,
		value: 1,
		max: 1,
		color: CYAN
	});
	if (sim.player.shield > 0) chips.push({
		label: "SHIELD",
		value: sim.player.shield,
		max: 9,
		color: CYAN
	});
	if (sim.player.speedT > 0) chips.push({
		label: "BOOST",
		value: sim.player.speedT,
		max: 8,
		color: AMBER
	});
	if (chips.length) {
		const gap = 8;
		const w = 78;
		let x = 210 - (chips.length * w + (chips.length - 1) * gap) / 2;
		for (const chip of chips) {
			ctx.fillStyle = "rgba(18,23,34,0.8)";
			ctx.beginPath();
			ctx.roundRect(x, 702, w, 28, 8);
			ctx.fill();
			ctx.strokeStyle = chip.color;
			ctx.lineWidth = 1;
			ctx.stroke();
			ctx.fillStyle = FG;
			ctx.font = "600 10px Exo 2, sans-serif";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(chip.label, x + w / 2, 710);
			if (chip.max > 1) {
				ctx.fillStyle = "rgba(255,255,255,0.15)";
				ctx.fillRect(x + 8, 722, 62, 3);
				ctx.fillStyle = chip.color;
				ctx.fillRect(x + 8, 722, 62 * Math.max(0, Math.min(1, chip.value / chip.max)), 3);
			}
			x += 86;
		}
	}
}
var KEY = "lumen-raid-scores-v1";
var MUTE_KEY = "lumen-raid-muted-v1";
function read() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return {
			version: 1,
			entries: []
		};
		const parsed = JSON.parse(raw);
		if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.entries)) return {
			version: 1,
			entries: []
		};
		return {
			version: 1,
			entries: parsed.entries.filter((e) => e && typeof e.name === "string" && typeof e.score === "number" && typeof e.wave === "number").slice(0, 10)
		};
	} catch {
		return {
			version: 1,
			entries: []
		};
	}
}
function write(entries) {
	try {
		const payload = {
			version: 1,
			entries
		};
		localStorage.setItem(KEY, JSON.stringify(payload));
	} catch {}
}
function loadScores() {
	return read().entries;
}
function qualifies(score, entries) {
	if (score <= 0) return false;
	if (entries.length < 10) return true;
	const last = entries[entries.length - 1];
	return last ? score > last.score : true;
}
function saveScore(name, score, wave) {
	const clean = name.trim().slice(0, 16) || "PILOT";
	const entries = read().entries;
	entries.push({
		name: clean,
		score,
		wave,
		at: Date.now()
	});
	entries.sort((a, b) => b.score - a.score || a.at - b.at);
	const top = entries.slice(0, 10);
	write(top);
	return top;
}
function loadMuted() {
	try {
		return localStorage.getItem(MUTE_KEY) === "1";
	} catch {
		return false;
	}
}
function saveMuted(muted) {
	try {
		localStorage.setItem(MUTE_KEY, muted ? "1" : "0");
	} catch {}
}
var MAX_PLAYER_BULLETS = 72;
var MAX_ENEMY_BULLETS = 96;
var MAX_PARTICLES = 180;
function freshPlayer() {
	return {
		x: 210,
		y: 610,
		vx: 0,
		vy: 0,
		r: 12,
		iframes: 0,
		fireCd: .2,
		multi: 0,
		shield: 0,
		speedT: 0,
		exhaust: 0,
		alive: true
	};
}
function makeStars() {
	const stars = [];
	for (let i = 0; i < 120; i++) {
		const layer = i < 55 ? 0 : i < 95 ? 1 : 2;
		stars.push({
			x: Math.random() * 420,
			y: Math.random() * 760,
			layer,
			r: layer === 0 ? .7 : layer === 1 ? 1.15 : 1.8,
			a: .35 + Math.random() * .6
		});
	}
	return stars;
}
function createSim(reduceMotion = false) {
	return {
		phase: "title",
		clock: 0,
		runTime: 0,
		score: 0,
		lives: 3,
		wave: 0,
		waveState: "banner",
		waveTimer: 0,
		banner: "",
		queue: [],
		player: freshPlayer(),
		bullets: [],
		enemies: [],
		pickups: [],
		particles: [],
		floats: [],
		flashes: [],
		stars: makeStars(),
		shake: 0,
		hitStop: 0,
		hurtFlash: 0,
		combo: 0,
		comboTimer: 0,
		reduceMotion,
		sfx: () => {},
		onChange: () => {}
	};
}
function setPhase(sim, phase) {
	if (sim.phase === phase) return;
	sim.phase = phase;
	queueMicrotask(() => sim.onChange());
}
function startRun(sim) {
	sim.score = 0;
	sim.lives = 3;
	sim.wave = 0;
	sim.runTime = 0;
	sim.combo = 0;
	sim.comboTimer = 0;
	sim.player = freshPlayer();
	sim.bullets = [];
	sim.enemies = [];
	sim.pickups = [];
	sim.particles = [];
	sim.floats = [];
	sim.flashes = [];
	sim.shake = 0;
	sim.hitStop = 0;
	sim.hurtFlash = 0;
	sim.queue = [];
	beginWave(sim);
	setPhase(sim, "playing");
}
function pauseRun(sim) {
	if (sim.phase === "playing") setPhase(sim, "paused");
}
function resumeRun(sim) {
	if (sim.phase === "paused") setPhase(sim, "playing");
}
function togglePause(sim) {
	if (sim.phase === "playing") pauseRun(sim);
	else if (sim.phase === "paused") resumeRun(sim);
}
function toTitle(sim) {
	setPhase(sim, "title");
}
function beginWave(sim) {
	sim.wave += 1;
	sim.waveState = "banner";
	sim.waveTimer = 1.05;
	sim.banner = sim.wave % 5 === 0 ? `BOSS  ${sim.wave}` : `WAVE  ${sim.wave}`;
	sim.queue = buildQueue(sim.wave);
	sim.sfx(sim.wave % 5 === 0 ? "boss" : "wave");
}
function buildQueue(wave) {
	const out = [];
	if (wave % 5 === 0) {
		out.push({
			t: .2,
			kind: "boss",
			x: 210,
			y: -100,
			pattern: "boss",
			amp: 0
		});
		const escorts = Math.min(6, 2 + Math.floor(wave / 5));
		for (let i = 0; i < escorts; i++) out.push({
			t: 1.5 + i * .42,
			kind: "dart",
			x: 48 + i % 6 * 60,
			y: -36,
			pattern: "down",
			amp: 0
		});
		return out;
	}
	const slot = wave % 5;
	if (slot === 1) {
		const count = Math.min(11, 5 + Math.floor(wave / 2));
		for (let i = 0; i < count; i++) {
			const col = i % 5;
			out.push({
				t: .1 + i * .18,
				kind: "dart",
				x: 46 + col * 82,
				y: -28 - Math.floor(i / 5) * 34,
				pattern: "down",
				amp: 0
			});
		}
	} else if (slot === 2) {
		const count = Math.min(8, 4 + Math.floor(wave / 2));
		for (let i = 0; i < count; i++) out.push({
			t: i * .3,
			kind: "weaver",
			x: i % 2 === 0 ? 100 : 320,
			y: -40,
			pattern: "sine",
			amp: 72 + i % 3 * 20
		});
	} else if (slot === 3) {
		const guns = Math.min(4, 1 + Math.floor(wave / 3));
		for (let i = 0; i < guns; i++) out.push({
			t: .15 + i * .65,
			kind: "gunner",
			x: 420 * (.22 + i % 3 * .28),
			y: -70,
			pattern: "down",
			amp: 0
		});
		const n = Math.min(8, 3 + Math.floor(wave / 2));
		for (let i = 0; i < n; i++) out.push({
			t: .35 + i * .16,
			kind: "dart",
			x: 36 + i * 97 % 348,
			y: -24,
			pattern: "down",
			amp: 0
		});
	} else {
		for (let i = 0; i < 8; i++) {
			const left = i < 4;
			out.push({
				t: i * .15,
				kind: i % 4 === 0 ? "weaver" : "dart",
				x: left ? -28 : 448,
				y: 80 + i % 4 * 52,
				pattern: "swoop",
				amp: left ? 1 : -1
			});
		}
		const guns = Math.min(3, 1 + Math.floor(wave / 4));
		for (let i = 0; i < guns; i++) out.push({
			t: .4 + i * .55,
			kind: "gunner",
			x: 420 * (.3 + i * .2),
			y: -60,
			pattern: "down",
			amp: 0
		});
	}
	return out;
}
function stats(kind, wave) {
	if (kind === "dart") return {
		hp: 1 + Math.floor(wave / 8),
		r: 15,
		score: 100
	};
	if (kind === "weaver") return {
		hp: 2 + Math.floor(wave / 6),
		r: 18,
		score: 160
	};
	if (kind === "gunner") return {
		hp: 5 + Math.floor(wave / 4),
		r: 24,
		score: 280
	};
	return {
		hp: 78 + wave * 8,
		r: 52,
		score: 2500
	};
}
function spawnEnemy(sim, s) {
	const st = stats(s.kind, sim.wave);
	const enemy = {
		kind: s.kind,
		pattern: s.pattern,
		x: s.x,
		y: s.y,
		vx: 0,
		vy: 0,
		hp: st.hp,
		maxHp: st.hp,
		r: st.r,
		age: 0,
		shoot: s.kind === "boss" ? 3.3 : s.kind === "gunner" ? 1.2 : 1.6,
		originX: s.x,
		amp: s.amp,
		phase: Math.random() * Math.PI * 2,
		flash: 0,
		score: st.score,
		bossShot: 0,
		alive: true
	};
	sim.enemies.push(enemy);
}
function countBullets(sim, friendly) {
	let n = 0;
	for (const b of sim.bullets) if (b.alive && b.friendly === friendly) n++;
	return n;
}
function pushBullet(sim, x, y, vx, vy, friendly, r) {
	if (countBullets(sim, friendly) >= (friendly ? MAX_PLAYER_BULLETS : MAX_ENEMY_BULLETS)) return;
	const bullet = {
		x,
		y,
		vx,
		vy,
		r,
		friendly,
		life: friendly ? 1.6 : 4,
		alive: true
	};
	sim.bullets.push(bullet);
}
var SPREAD = [
	[0],
	[
		-.18,
		0,
		.18
	],
	[
		-.34,
		-.15,
		0,
		.15,
		.34
	],
	[
		-.42,
		-.2,
		0,
		.2,
		.42
	]
];
function firePlayer(sim) {
	const p = sim.player;
	const angles = SPREAD[Math.min(3, p.multi)] ?? SPREAD[0];
	const speed = 760;
	for (const a of angles) {
		pushBullet(sim, p.x, p.y - 30, Math.sin(a) * speed, -Math.cos(a) * speed, true, 3.5);
		sim.flashes.push({
			x: p.x + Math.sin(a) * 10,
			y: p.y - 32,
			life: .06,
			max: .06,
			angle: a,
			alive: true
		});
	}
	sim.sfx("shoot");
}
function fireAimed(sim, e, speed, spread) {
	if (e.y < 8) return;
	const p = sim.player;
	const ang = Math.atan2(p.y - e.y, p.x - e.x) + (Math.random() - .5) * spread;
	pushBullet(sim, e.x, e.y + e.r * .4, Math.cos(ang) * speed, Math.sin(ang) * speed, false, 5);
}
function fireDown(sim, e, speed) {
	if (e.y < 8) return;
	pushBullet(sim, e.x, e.y + e.r, (Math.random() - .5) * 30, speed, false, 4.5);
}
function fireBoss(sim, e) {
	if (e.y < 70) return;
	e.bossShot += 1;
	if (e.bossShot % 2 === 0) {
		const gap = sim.runTime * .9;
		const n = 11;
		for (let i = 0; i < n; i++) {
			const a = gap + i / n * Math.PI * 2;
			pushBullet(sim, e.x, e.y, Math.cos(a) * 150, Math.sin(a) * 150, false, 5);
		}
	} else {
		const p = sim.player;
		const base = Math.atan2(p.y - e.y, p.x - e.x);
		for (const off of [
			-.22,
			0,
			.22
		]) {
			const a = base + off;
			pushBullet(sim, e.x, e.y + 20, Math.cos(a) * 250, Math.sin(a) * 250, false, 5.5);
		}
	}
}
function floatText(sim, x, y, text, color) {
	const item = {
		x,
		y,
		text,
		life: .8,
		max: .8,
		color,
		alive: true
	};
	sim.floats.push(item);
}
function burst(sim, x, y, color, n, speed = 180) {
	const count = sim.reduceMotion ? Math.ceil(n * .35) : n;
	for (let i = 0; i < count; i++) {
		if (sim.particles.length >= MAX_PARTICLES) break;
		const a = i / count * Math.PI * 2 + Math.random() * .2;
		const sp = speed * (.35 + Math.random() * .75);
		const particle = {
			x,
			y,
			vx: Math.cos(a) * sp,
			vy: Math.sin(a) * sp,
			life: .35 + Math.random() * .35,
			max: .7,
			size: 1.5 + Math.random() * 2.4,
			color,
			alive: true
		};
		sim.particles.push(particle);
	}
}
function dropChance(kind) {
	if (kind === "boss") return 1;
	if (kind === "gunner") return .45;
	if (kind === "weaver") return .22;
	return .14;
}
function rollKind(sim) {
	if (sim.player.multi < 2 && Math.random() < .46) return "multi";
	if (Math.random() < .55) return "shield";
	return "speed";
}
function spawnPickup(sim, x, y, kind) {
	const pickup = {
		kind,
		x,
		y,
		vy: 40,
		r: 14,
		life: 9,
		alive: true
	};
	sim.pickups.push(pickup);
}
function killEnemy(sim, e) {
	if (!e.alive) return;
	e.alive = false;
	sim.combo = sim.comboTimer > 0 ? sim.combo + 1 : 1;
	sim.comboTimer = 1.35;
	const mult = Math.min(4, 1 + (sim.combo - 1) * .5);
	const gained = Math.round(e.score * mult);
	sim.score += gained;
	floatText(sim, e.x, e.y, sim.combo >= 2 ? `+${gained}  x${sim.combo}` : `+${gained}`, "#ffb020");
	burst(sim, e.x, e.y, e.kind === "weaver" ? "#7dffe4" : e.kind === "dart" ? "#ff8aa8" : "#ffb020", e.kind === "boss" ? 28 : 12, e.kind === "boss" ? 260 : 160);
	if (!sim.reduceMotion) sim.shake = Math.min(16, sim.shake + (e.kind === "boss" ? 12 : 4));
	sim.hitStop = e.kind === "boss" ? .07 : .03;
	sim.sfx("explode");
	if (Math.random() < dropChance(e.kind)) spawnPickup(sim, e.x, e.y, rollKind(sim));
}
function clearEnemyBullets(sim) {
	for (const b of sim.bullets) if (!b.friendly) b.alive = false;
}
function hurtPlayer(sim) {
	const p = sim.player;
	if (!p.alive || p.iframes > 0) return;
	if (p.shield > 0) {
		p.shield = Math.max(0, p.shield - 1.5);
		if (!sim.reduceMotion) sim.shake = Math.min(10, sim.shake + 4);
		sim.sfx("hit");
		return;
	}
	sim.lives -= 1;
	p.iframes = 2;
	p.multi = Math.max(0, p.multi - 1);
	sim.hurtFlash = .4;
	if (!sim.reduceMotion) sim.shake = Math.min(16, sim.shake + 11);
	clearEnemyBullets(sim);
	burst(sim, p.x, p.y, "#ff3d7a", 18, 220);
	sim.sfx("hurt");
	if (sim.lives <= 0) {
		p.alive = false;
		sim.sfx("explode");
		setPhase(sim, "over");
	}
}
function collect(sim, kind) {
	const p = sim.player;
	if (kind === "multi") {
		p.multi = Math.min(3, p.multi + 1);
		floatText(sim, p.x, p.y - 28, "SPREAD", "#3ee0ff");
	} else if (kind === "shield") {
		p.shield = Math.min(12, p.shield + 9);
		floatText(sim, p.x, p.y - 28, "SHIELD", "#3ee0ff");
	} else {
		p.speedT = Math.min(14, p.speedT + 8);
		floatText(sim, p.x, p.y - 28, "BOOST", "#ffb020");
	}
	sim.sfx("pickup");
}
function grantWaveReward(sim) {
	const bonus = 120 * sim.wave;
	sim.score += bonus;
	floatText(sim, 210, 288.8, `CLEAR  +${bonus}`, "#e8eef8");
	const kind = sim.wave % 3 === 1 ? "multi" : sim.wave % 3 === 2 ? "shield" : "speed";
	spawnPickup(sim, 210 + (Math.random() * 80 - 40), 70, kind);
}
function stepStars(sim, dt, factor) {
	const speeds = [
		24,
		58,
		128
	];
	for (const s of sim.stars) {
		s.y += speeds[s.layer] * factor * dt;
		s.x += (s.layer - 1) * 6 * factor * dt;
		if (s.y > 760) {
			s.y = 0;
			s.x = Math.random() * 420;
		}
		if (s.x < 0) s.x += 420;
		if (s.x > 420) s.x -= 420;
	}
}
function decayVisuals(sim, dt) {
	sim.shake = Math.max(0, sim.shake - dt * 26);
	sim.hurtFlash = Math.max(0, sim.hurtFlash - dt);
	for (const f of sim.flashes) {
		f.life -= dt;
		if (f.life <= 0) f.alive = false;
	}
	for (const p of sim.particles) {
		p.life -= dt;
		p.x += p.vx * dt;
		p.y += p.vy * dt;
		p.vy += 40 * dt;
		if (p.life <= 0) p.alive = false;
	}
	for (const f of sim.floats) {
		f.life -= dt;
		f.y -= 36 * dt;
		if (f.life <= 0) f.alive = false;
	}
}
function compact(arr) {
	let w = 0;
	for (let i = 0; i < arr.length; i++) {
		const item = arr[i];
		if (item && item.alive) arr[w++] = item;
	}
	arr.length = w;
}
function stepPlayer(sim, dt, input) {
	const p = sim.player;
	if (!p.alive) return;
	const max = p.speedT > 0 ? 440 : 292;
	if (input.mode === "keys") {
		let ix = 0;
		let iy = 0;
		if (input.left) ix -= 1;
		if (input.right) ix += 1;
		if (input.up) iy -= 1;
		if (input.down) iy += 1;
		const len = Math.hypot(ix, iy);
		if (len > 0) {
			ix /= len;
			iy /= len;
			p.vx += ix * 2700 * dt;
			p.vy += iy * 2700 * dt;
			const sp = Math.hypot(p.vx, p.vy);
			if (sp > max) {
				p.vx = p.vx / sp * max;
				p.vy = p.vy / sp * max;
			}
		} else {
			const d = Math.exp(-10 * dt);
			p.vx *= d;
			p.vy *= d;
		}
	} else if (input.mode === "pointer") {
		const tx = input.px;
		let ty = input.py;
		if (input.touch) ty -= 78;
		const dx = tx - p.x;
		const dy = ty - p.y;
		const dist = Math.hypot(dx, dy);
		if (dist > 3) {
			const want = Math.min(max, dist * 8.5);
			const tvx = dx / dist * want;
			const tvy = dy / dist * want;
			const k = 1 - Math.exp(-12 * dt);
			p.vx += (tvx - p.vx) * k;
			p.vy += (tvy - p.vy) * k;
		} else {
			const d = Math.exp(-14 * dt);
			p.vx *= d;
			p.vy *= d;
		}
	} else {
		const d = Math.exp(-9 * dt);
		p.vx *= d;
		p.vy *= d;
	}
	p.x += p.vx * dt;
	p.y += p.vy * dt;
	const m = 26;
	if (p.x < m) {
		p.x = m;
		p.vx = 0;
	}
	if (p.x > 394) {
		p.x = 394;
		p.vx = 0;
	}
	if (p.y < 56) {
		p.y = 56;
		p.vy = 0;
	}
	if (p.y > 720) {
		p.y = 720;
		p.vy = 0;
	}
	if (p.iframes > 0) p.iframes -= dt;
	if (p.shield > 0) p.shield = Math.max(0, p.shield - dt);
	if (p.speedT > 0) p.speedT = Math.max(0, p.speedT - dt);
	p.fireCd -= dt;
	const rate = p.multi >= 3 ? .1 : .145;
	if (p.fireCd <= 0) {
		p.fireCd += rate;
		firePlayer(sim);
	}
	p.exhaust += dt;
	const exhaustRate = Math.hypot(p.vx, p.vy) > 40 ? .02 : .045;
	if (p.exhaust > exhaustRate && sim.particles.length < MAX_PARTICLES) {
		p.exhaust = 0;
		const particle = {
			x: p.x + (Math.random() - .5) * 8,
			y: p.y + 26,
			vx: (Math.random() - .5) * 20,
			vy: 80 + Math.random() * 70,
			life: .28,
			max: .28,
			size: 2 + Math.random() * 2,
			color: Math.random() > .45 ? "#ffb020" : "#3ee0ff",
			alive: true
		};
		sim.particles.push(particle);
	}
}
function stepEnemy(sim, e, dt) {
	e.age += dt;
	e.flash = Math.max(0, e.flash - dt * 6);
	const wave = sim.wave;
	if (e.pattern === "boss") {
		const targetY = 132;
		if (e.y < targetY) {
			e.vy = 72;
			e.vx = 0;
			e.y += e.vy * dt;
		} else {
			e.y = targetY;
			e.vy = 0;
			const span = 420 * .28;
			e.x = 210 + Math.sin(e.age * .7) * span;
			e.vx = Math.cos(e.age * .7) * span * .7;
		}
	} else if (e.pattern === "sine") {
		e.vy = 80 + wave * 3;
		e.y += e.vy * dt;
		const w = 2.05;
		e.x = e.originX + Math.sin(e.age * w + e.phase) * e.amp;
		e.vx = Math.cos(e.age * w + e.phase) * e.amp * w;
	} else if (e.pattern === "swoop") {
		const dir = e.amp >= 0 ? 1 : -1;
		e.vx = dir * ((dir > 0 ? e.x > 260.4 : e.x < 159.6) ? 48 : 160 + wave * 3);
		e.vy = 96 + wave * 4;
		e.x += e.vx * dt;
		e.y += e.vy * dt;
	} else {
		e.vx = Math.max(-80, Math.min(80, (sim.player.x - e.x) * .45));
		e.vy = (e.kind === "gunner" ? 58 : 124) + wave * (e.kind === "gunner" ? 2 : 6);
		if (e.kind === "gunner" && e.y > 160 && e.y < 300) e.vy = 26 + wave;
		e.x += e.vx * dt;
		e.y += e.vy * dt;
	}
	if (e.kind === "boss" || e.kind === "gunner" || e.kind === "dart" && wave >= 6) {
		e.shoot -= dt;
		if (e.shoot <= 0) {
			if (e.kind === "boss") fireBoss(sim, e);
			else if (e.kind === "gunner") fireAimed(sim, e, 200 + wave * 4, .06);
			else fireDown(sim, e, 230);
			e.shoot = e.kind === "boss" ? .92 : e.kind === "gunner" ? 1.4 : 1.7;
		}
	}
	if (e.kind !== "boss" && (e.y > 840 || e.x < -150 || e.x > 570)) e.alive = false;
}
function separate(sim) {
	const list = sim.enemies;
	for (let i = 0; i < list.length; i++) {
		const a = list[i];
		if (!a?.alive || a.kind === "boss") continue;
		for (let j = i + 1; j < list.length; j++) {
			const b = list[j];
			if (!b?.alive || b.kind === "boss") continue;
			const dx = b.x - a.x;
			const dy = b.y - a.y;
			const d = Math.hypot(dx, dy) || .001;
			const min = (a.r + b.r) * .85;
			if (d < min) {
				const push = (min - d) * .5;
				const nx = dx / d;
				const ny = dy / d;
				a.x -= nx * push;
				a.y -= ny * push;
				b.x += nx * push;
				b.y += ny * push;
			}
		}
	}
}
function overlaps(ax, ay, ar, bx, by, br) {
	const dx = ax - bx;
	const dy = ay - by;
	const rr = ar + br;
	return dx * dx + dy * dy <= rr * rr;
}
function stepWorld(sim, dt, input) {
	sim.runTime += dt;
	if (sim.comboTimer > 0) {
		sim.comboTimer -= dt;
		if (sim.comboTimer <= 0) sim.combo = 0;
	}
	stepPlayer(sim, dt, input);
	if (sim.waveState === "banner") {
		sim.waveTimer -= dt;
		if (sim.waveTimer <= 0) sim.waveState = "fight";
	} else if (sim.waveState === "fight") {
		for (const s of sim.queue) s.t -= dt;
		const ready = [];
		const waiting = [];
		for (const s of sim.queue) (s.t <= 0 ? ready : waiting).push(s);
		sim.queue = waiting;
		for (const s of ready) spawnEnemy(sim, s);
		if (sim.queue.length === 0 && sim.enemies.every((e) => !e.alive)) {
			sim.waveState = "clear";
			sim.waveTimer = 1.2;
			grantWaveReward(sim);
		}
	} else {
		sim.waveTimer -= dt;
		if (sim.waveTimer <= 0) beginWave(sim);
	}
	for (const e of sim.enemies) if (e.alive) stepEnemy(sim, e, dt);
	separate(sim);
	for (const b of sim.bullets) {
		if (!b.alive) continue;
		b.x += b.vx * dt;
		b.y += b.vy * dt;
		b.life -= dt;
		if (b.life <= 0 || b.y < -40 || b.y > 810 || b.x < -40 || b.x > 460) b.alive = false;
	}
	const p = sim.player;
	let hurt = false;
	const tryHurt = () => {
		if (hurt || !p.alive) return;
		hurt = true;
		hurtPlayer(sim);
	};
	for (const b of sim.bullets) {
		if (!b.alive || !b.friendly) continue;
		for (const e of sim.enemies) {
			if (!e.alive) continue;
			if (!overlaps(b.x, b.y, b.r, e.x, e.y, e.r)) continue;
			b.alive = false;
			e.hp -= 1;
			e.flash = 1;
			if (e.hp <= 0) killEnemy(sim, e);
			else sim.sfx("hit");
			break;
		}
	}
	if (p.alive) {
		for (const b of sim.bullets) {
			if (!b.alive || b.friendly) continue;
			if (overlaps(b.x, b.y, b.r, p.x, p.y, p.r)) {
				b.alive = false;
				tryHurt();
			}
		}
		for (const e of sim.enemies) {
			if (!e.alive) continue;
			if (!overlaps(e.x, e.y, e.r * .72, p.x, p.y, p.r)) continue;
			tryHurt();
			if (e.kind !== "boss" && p.shield > 0) killEnemy(sim, e);
		}
		for (const item of sim.pickups) {
			if (!item.alive) continue;
			item.life -= dt;
			item.vy = Math.min(120, item.vy + 18 * dt);
			item.y += item.vy * dt;
			const dx = p.x - item.x;
			const dy = p.y - item.y;
			const dist = Math.hypot(dx, dy);
			if (dist < 120 && dist > .01) {
				item.x += dx / dist * 120 * dt;
				item.y += dy / dist * 120 * dt;
			}
			if (dist < p.r + item.r + 6) {
				item.alive = false;
				collect(sim, item.kind);
			} else if (item.y > 800 || item.life <= 0) item.alive = false;
		}
	}
	if (sim.phase !== "playing") return;
	compact(sim.bullets);
	compact(sim.enemies);
	compact(sim.pickups);
	compact(sim.particles);
	compact(sim.floats);
	compact(sim.flashes);
}
function step(sim, dt, input) {
	const capped = Math.min(.05, dt);
	sim.clock += capped;
	if (sim.phase === "title") {
		stepStars(sim, capped, 1);
		decayVisuals(sim, capped);
		return;
	}
	if (sim.phase === "over") {
		stepStars(sim, capped, .35);
		decayVisuals(sim, capped);
		return;
	}
	if (sim.phase === "paused") return;
	if (sim.hitStop > 0) {
		sim.hitStop -= capped;
		stepStars(sim, capped, .15);
		decayVisuals(sim, capped);
		return;
	}
	stepStars(sim, capped, 1);
	stepWorld(sim, capped, input);
	decayVisuals(sim, capped);
	if (sim.phase === "playing") {
		compact(sim.bullets);
		compact(sim.enemies);
		compact(sim.pickups);
		compact(sim.particles);
		compact(sim.floats);
		compact(sim.flashes);
	}
}
function fmt(n) {
	return n.toLocaleString("en-US");
}
function Game() {
	const canvasRef = (0, import_react.useRef)(null);
	const frameRef = (0, import_react.useRef)(null);
	const simRef = (0, import_react.useRef)(null);
	const keysRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const injectedRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const pointerRef = (0, import_react.useRef)({
		hovering: false,
		touch: false,
		px: 210,
		py: 610
	});
	const spritesRef = (0, import_react.useRef)({});
	const mutedRef = (0, import_react.useRef)(false);
	const nameRef = (0, import_react.useRef)(null);
	const [phase, setPhase] = (0, import_react.useState)("title");
	const [snap, setSnap] = (0, import_react.useState)({
		score: 0,
		wave: 1
	});
	const [scores, setScores] = (0, import_react.useState)([]);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)(false);
	const [boardOpen, setBoardOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setScores(loadScores());
		const m = loadMuted();
		setMuted(m);
		mutedRef.current = m;
	}, []);
	(0, import_react.useEffect)(() => {
		if (phase === "over") nameRef.current?.focus();
	}, [phase]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const frame = frameRef.current;
		if (!canvas || !frame) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const sim = createSim(reduce);
		simRef.current = sim;
		sim.sfx = (name) => {
			if (!mutedRef.current) playSfx(name);
		};
		sim.onChange = () => {
			setPhase(sim.phase);
			setSnap({
				score: sim.score,
				wave: sim.wave
			});
			if (sim.phase === "over") {
				setSaved(false);
				setName("");
				setBoardOpen(false);
			}
		};
		const sprites = {};
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => {
			sprites.player = img;
			spritesRef.current = { ...sprites };
		};
		img.src = "/sprites/player.png";
		const resize = () => {
			const rect = canvas.getBoundingClientRect();
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			canvas.width = Math.max(1, Math.round(rect.width * dpr));
			canvas.height = Math.max(1, Math.round(rect.height * dpr));
		};
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(canvas);
		const toWorld = (clientX, clientY) => {
			const rect = canvas.getBoundingClientRect();
			return {
				x: (clientX - rect.left) / rect.width * 420,
				y: (clientY - rect.top) / rect.height * 760
			};
		};
		const menuTarget = (target) => target instanceof Element && !!target.closest("button, input, a, textarea, .overlay");
		const onPointerDown = (e) => {
			if (menuTarget(e.target)) {
				pointerRef.current.hovering = false;
				return;
			}
			unlockAudio();
			const p = toWorld(e.clientX, e.clientY);
			pointerRef.current.hovering = true;
			pointerRef.current.touch = e.pointerType !== "mouse";
			pointerRef.current.px = p.x;
			pointerRef.current.py = p.y;
		};
		const onPointerMove = (e) => {
			if (menuTarget(e.target)) return;
			if (e.pointerType === "touch" && e.buttons === 0) return;
			const p = toWorld(e.clientX, e.clientY);
			pointerRef.current.hovering = true;
			pointerRef.current.touch = e.pointerType !== "mouse";
			pointerRef.current.px = p.x;
			pointerRef.current.py = p.y;
		};
		const onPointerUp = (e) => {
			if (e.pointerType !== "mouse") pointerRef.current.hovering = false;
		};
		const onPointerLeave = (e) => {
			if (e.pointerType === "mouse") pointerRef.current.hovering = false;
		};
		const typing = (target) => target instanceof HTMLElement && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
		const onKeyDown = (e) => {
			if (e.repeat) return;
			if (typing(e.target)) return;
			if ([
				"ArrowUp",
				"ArrowDown",
				"ArrowLeft",
				"ArrowRight",
				"Space"
			].includes(e.code)) e.preventDefault();
			keysRef.current.add(e.code);
			if (e.code === "Enter" && sim.phase === "title") {
				unlockAudio();
				startRun(sim);
			}
			if ((e.code === "Escape" || e.code === "KeyP") && (sim.phase === "playing" || sim.phase === "paused")) {
				e.preventDefault();
				togglePause(sim);
			}
		};
		const onKeyUp = (e) => {
			keysRef.current.delete(e.code);
		};
		const onBlur = () => {
			keysRef.current.clear();
		};
		const onVis = () => {
			if (document.hidden && sim.phase === "playing") pauseRun(sim);
			if (!document.hidden) unlockAudio();
		};
		frame.addEventListener("pointerdown", onPointerDown);
		frame.addEventListener("pointermove", onPointerMove);
		frame.addEventListener("pointerup", onPointerUp);
		frame.addEventListener("pointercancel", onPointerUp);
		frame.addEventListener("pointerleave", onPointerLeave);
		window.addEventListener("keydown", onKeyDown);
		window.addEventListener("keyup", onKeyUp);
		window.addEventListener("blur", onBlur);
		document.addEventListener("visibilitychange", onVis);
		window.__controlsTest = {
			getYaw: () => -Math.PI / 2,
			getSpeed: () => Math.hypot(sim.player.vx, sim.player.vy),
			getX: () => sim.player.x,
			getY: () => sim.player.y,
			setKeys: (codes) => {
				injectedRef.current = new Set(codes);
			}
		};
		window.__game = {
			getPhase: () => sim.phase,
			getScore: () => sim.score,
			getLives: () => sim.lives,
			getWave: () => sim.wave,
			getMulti: () => sim.player.multi,
			getShield: () => sim.player.shield,
			getSpeedT: () => sim.player.speedT
		};
		let raf = 0;
		let last = performance.now();
		let acc = 0;
		const loop = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			acc += dt;
			let guard = 0;
			while (acc >= 1 / 60 && guard++ < 5) {
				step(sim, 1 / 60, readInput(keysRef.current, injectedRef.current, pointerRef.current));
				acc -= 1 / 60;
			}
			const ctx = canvas.getContext("2d");
			if (ctx) draw(ctx, sim, spritesRef.current);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
			frame.removeEventListener("pointerdown", onPointerDown);
			frame.removeEventListener("pointermove", onPointerMove);
			frame.removeEventListener("pointerup", onPointerUp);
			frame.removeEventListener("pointercancel", onPointerUp);
			frame.removeEventListener("pointerleave", onPointerLeave);
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("keyup", onKeyUp);
			window.removeEventListener("blur", onBlur);
			document.removeEventListener("visibilitychange", onVis);
			delete window.__controlsTest;
			delete window.__game;
		};
	}, []);
	const sim = () => simRef.current;
	const start = () => {
		unlockAudio();
		const s = sim();
		if (s) startRun(s);
	};
	const pause = () => {
		const s = sim();
		if (s) pauseRun(s);
	};
	const resume = () => {
		const s = sim();
		if (s) resumeRun(s);
	};
	const restart = () => {
		unlockAudio();
		const s = sim();
		if (s) startRun(s);
	};
	const title = () => {
		const s = sim();
		if (s) toTitle(s);
	};
	const toggleMute = () => {
		setMuted((m) => {
			const next = !m;
			mutedRef.current = next;
			saveMuted(next);
			return next;
		});
	};
	const submit = () => {
		if (saved) return;
		const next = saveScore(name, snap.score, snap.wave);
		setScores(next);
		setSaved(true);
	};
	const onBoard = qualifies(snap.score, scores) && !saved;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rail",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Arcade sortie"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "wordmark",
						children: "Lumen Raid"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Hold the lane. Waves roll down the starfield — spread fire, a shield, and a speed boost are the only favors out here."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "legend",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "swatch swatch-dart" }), " Darts dive in packs"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "swatch swatch-weaver" }), " Weavers drift on a sine"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "swatch swatch-gun" }), " Gunships track and fire"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "swatch swatch-boss" }), " A dreadnought every fifth wave"] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "help",
						children: "WASD or arrows to fly. Move the pointer to take the stick — a direction key grabs it back. Weapons fire on their own. P or Esc pauses."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stage",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "frame",
					ref: frameRef,
					role: "application",
					"aria-label": "Lumen Raid playfield",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: canvasRef,
							"aria-hidden": "true"
						}),
						phase === "playing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-btn pause-btn",
							onClick: pause,
							"aria-label": "Pause",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { size: 18 })
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-btn mute-btn",
							onClick: toggleMute,
							"aria-label": muted ? "Unmute" : "Mute",
							"aria-pressed": muted,
							children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { size: 18 })
						}),
						phase === "title" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overlay",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "kicker",
										children: "Sortie ready"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Lumen Raid" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "help",
										children: "Top-down waves, three lives, and pods for spread shot, shield, and speed. Your best runs stay on this device."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "btn btn-primary btn-block",
										onClick: start,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 16 }), " Start"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "help",
										children: "Keys: WASD or arrows. Pointer: drag, or just move it. Guns fire automatically."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-board",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "kicker",
												children: "High scores"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, { entries: scores.slice(0, boardOpen ? 10 : 3) }),
											scores.length > 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "btn",
												onClick: () => setBoardOpen((v) => !v),
												children: boardOpen ? "Top three" : "Full board"
											}) : null
										]
									})
								]
							})
						}) : null,
						phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overlay",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "kicker",
										children: "Holding"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Paused" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "help",
										children: [
											"Wave ",
											snap.wave,
											" · ",
											fmt(snap.score)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "actions",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "btn btn-primary",
												onClick: resume,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 16 }), " Resume"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "btn",
												onClick: restart,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 16 }), " Restart"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "btn",
												onClick: title,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { size: 16 }), " Title"]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "kicker",
										children: "High scores"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, { entries: scores }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "help",
										children: "Esc or P resumes."
									})
								]
							})
						}) : null,
						phase === "over" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overlay",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "kicker",
										children: snap.score > 0 && snap.score >= (scores[0]?.score ?? 0) ? "New record" : "Shot down"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Run over" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "score-hero",
										children: fmt(snap.score)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "help",
										children: ["Reached wave ", snap.wave]
									}),
									onBoard ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										className: "form-row",
										onSubmit: (e) => {
											e.preventDefault();
											submit();
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "visually-hidden",
												htmlFor: "pilot-name",
												children: "Pilot name"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "pilot-name",
												ref: nameRef,
												className: "field",
												value: name,
												maxLength: 16,
												placeholder: "Pilot name",
												autoComplete: "off",
												spellCheck: false,
												onChange: (e) => setName(e.target.value)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "submit",
												className: "btn btn-primary",
												children: "Save"
											})
										]
									}) : saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "help",
										children: "Logged on the board."
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "help",
										children: snap.score <= 0 ? "No score to log." : "Outside the top ten."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "actions",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "btn btn-primary",
											onClick: restart,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 16 }), " Again"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "btn",
											onClick: title,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { size: 16 }), " Title"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "kicker",
										children: "High scores"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, { entries: scores })
								]
							})
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rail rail-right",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "High scores"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "wordmark",
						children: "Board"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, { entries: scores }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Ten pilots. This browser only — no account, no cloud."
					})
				]
			})
		]
	});
}
function Board({ entries }) {
	if (!entries.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "empty",
		children: "No pilots logged yet."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "board",
		children: entries.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rank",
				children: i + 1
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "who",
				children: [e.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rank",
					children: [" · W", e.wave]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pts",
				children: fmt(e.score)
			})
		] }, `${e.at}-${e.name}-${i}`))
	});
}
function readInput(keys, injected, pointer) {
	const has = (code) => keys.has(code) || injected.has(code);
	const left = has("KeyA") || has("ArrowLeft");
	const right = has("KeyD") || has("ArrowRight");
	const up = has("KeyW") || has("ArrowUp");
	const down = has("KeyS") || has("ArrowDown");
	return {
		mode: left || right || up || down ? "keys" : pointer.hovering ? "pointer" : "idle",
		left,
		right,
		up,
		down,
		px: pointer.px,
		py: pointer.py,
		touch: pointer.touch
	};
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Game, {});
}
//#endregion
export { Home as component };
