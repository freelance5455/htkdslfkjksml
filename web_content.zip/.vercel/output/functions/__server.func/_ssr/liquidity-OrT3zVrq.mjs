import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as useDashboard, h as useChecks } from "./use-books-BtZpLk9U.mjs";
import { s as formatJalali, t as CHECK_STATUS } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, n as Card, o as StatCard, r as Money } from "./card-Bb_-PO54.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/liquidity-OrT3zVrq.js
var import_jsx_runtime = require_jsx_runtime();
function LiquidityPage() {
	const { data } = useDashboard();
	const checks = useChecks();
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-[24px] bg-secondary" });
	const rec = (checks.data ?? []).filter((c) => c.kind === "receivable" && ["in_hand", "deposited"].includes(c.status));
	const pay = (checks.data ?? []).filter((c) => c.kind === "payable" && ["issued"].includes(c.status));
	const recSum = rec.reduce((s, c) => s + c.amount, 0);
	const paySum = pay.reduce((s, c) => s + c.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "نقدینگی",
			description: "وضعیت امروز، هفته و ماه بر اساس مانده منابع مالی، چک‌ها و تعهدات."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					gold: true,
					label: "نقد و بانک",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.liquid,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "صندوق",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.cash,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "بانک‌ها",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.bank,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "تنخواه",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.petty,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "خالص جریان امروز",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.netCashToday,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "چک‌های دریافتی",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: recSum,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "چک‌های پرداختی",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: paySum,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "تعهدات + بدهی",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: data.ap + paySum,
						compact: true
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-navy",
					children: "پیش‌بینی ۷ تا ۳۰ روز"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "نقد فعلی به‌علاوه چک‌های دریافتنی سررسیدنشده، منهای چک‌های پرداختنی و بدهی‌های باز."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "افق ۷ روز" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
							value: data.liquid + recSum * .3 - paySum * .2,
							compact: true
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "افق ۳۰ روز" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
							value: data.liquid + recSum - paySum - data.ap * .25,
							compact: true
						})]
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-navy",
				children: "چک‌های باز"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2 text-sm",
				children: (checks.data ?? []).slice(0, 8).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						c.number,
						" · ",
						c.party_name,
						" · ",
						CHECK_STATUS[c.status] ?? c.status,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted",
							children: c.due_date ? formatJalali(c.due_date) : ""
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: c.amount,
						compact: true
					})]
				}, c.id))
			})] })]
		})
	] });
}
//#endregion
export { LiquidityPage as component };
