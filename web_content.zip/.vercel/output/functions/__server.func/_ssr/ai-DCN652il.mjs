import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { t as AI_MAX_CODE_CHARS } from "./limits-CuuT0Tt_.mjs";
import { a as string, i as object, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-DCN652il.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var inputSchema = object({
	task: _enum([
		"explain",
		"fix",
		"optimize",
		"convert",
		"generate"
	]),
	code: string().max(AI_MAX_CODE_CHARS),
	language: string().max(40),
	prompt: string().max(500).optional()
});
var SYSTEM = `You are the NIJO MOBILE coding assistant by Bouzidi Softworks.
Help people write and understand code on a phone. Be concise, accurate, and practical.
If you change code, return a fenced block with the full updated file when it is short, otherwise a focused patch.
Never invent runtime output. If you are unsure, say so.`;
function userMessage(data) {
	return `${data.prompt?.trim() || {
		explain: "Explain this code clearly.",
		fix: "Find and fix errors in this code.",
		optimize: "Optimize this code and explain the changes briefly.",
		convert: "Convert this code as requested, or to JavaScript if no target is given.",
		generate: "Generate the requested code."
	}[data.task]}\n\nLanguage: ${data.language}\n\nCode:\n\`\`\`\n${data.code}\n\`\`\``;
}
var askNijoAssistant_createServerFn_handler = createServerRpc({
	id: "adefec2d702eba7f709f00486945ad277e874c50ae02c50fb3195f0d6195fc17",
	name: "askNijoAssistant",
	filename: "src/lib/nijo/ai.ts"
}, (opts) => askNijoAssistant.__executeServer(opts));
var askNijoAssistant = createServerFn({ method: "POST" }).validator(inputSchema).handler(askNijoAssistant_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI assistant is not available in this environment."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 700,
			messages: [{
				role: "system",
				content: SYSTEM
			}, {
				role: "user",
				content: userMessage(data)
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: "The assistant could not complete that request."
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "The assistant returned an empty reply."
	};
	return {
		ok: true,
		text
	};
});
//#endregion
export { askNijoAssistant_createServerFn_handler };
