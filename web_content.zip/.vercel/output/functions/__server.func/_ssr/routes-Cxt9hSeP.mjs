import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as ArrowLeftRight, i as Shield, l as Activity, n as Trophy, o as Building2, r as TriangleAlert, s as Ban, t as Users } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cxt9hSeP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TR_MONTHS = [
	"Oca",
	"Şub",
	"Mar",
	"Nis",
	"May",
	"Haz",
	"Tem",
	"Ağu",
	"Eyl",
	"Eki",
	"Kas",
	"Ara"
];
function money(n) {
	const sign = n < 0 ? "-" : "";
	const v = Math.abs(n);
	if (v >= 1e9) return `${sign}€${(v / 1e9).toFixed(2)}Mr`;
	if (v >= 1e6) return `${sign}€${(v / 1e6).toFixed(1)}M`;
	if (v >= 1e3) return `${sign}€${(v / 1e3).toFixed(0)}B`;
	return `${sign}€${Math.round(v)}`;
}
function clamp(n, a, b) {
	return Math.max(a, Math.min(b, n));
}
function seasonDate(season, week) {
	const start = new Date(Date.UTC(season, 7, 10));
	start.setUTCDate(start.getUTCDate() + (week - 1) * 7);
	return `${start.getUTCDate()} ${TR_MONTHS[start.getUTCMonth()]} ${start.getUTCFullYear()}`;
}
function ovrTone(ovr) {
	if (ovr >= 86) return "text-ok";
	if (ovr >= 78) return "text-fg";
	if (ovr >= 70) return "text-muted";
	return "text-faint";
}
function confTone(n) {
	if (n >= 70) return "text-ok";
	if (n >= 40) return "text-warn";
	return "text-danger";
}
function leagueName(id) {
	return {
		ENG1: "Premier League",
		ESP1: "La Liga",
		ITA1: "Serie A",
		GER1: "Bundesliga",
		FRA1: "Ligue 1",
		POR1: "Primeira Liga",
		TUR1: "Süper Lig",
		TUR2: "TFF 1. Lig"
	}[id] ?? id;
}
function compLabel(comp) {
	if (comp === "UCL") return "Şampiyonlar Ligi";
	if (comp === "UEL") return "Avrupa Ligi";
	if (comp === "UECL") return "Konferans Ligi";
	return "Lig";
}
function objectiveLabel(o) {
	return {
		title: "Şampiyonluk",
		top4: "İlk 4 / Şampiyonlar Ligi",
		europe: "Avrupa kupası",
		mid: "Orta sıra",
		survive: "Küme düşmemek",
		promote: "Üst lige çıkmak"
	}[o] ?? o;
}
var NAMES = {
	TUR: {
		first: [
			"Mehmet",
			"Ahmet",
			"Mustafa",
			"Emre",
			"Burak",
			"Yusuf",
			"Ozan",
			"Kerem",
			"Arda",
			"Cenk",
			"Hakan",
			"Serdar",
			"Uğur",
			"Caner",
			"Barış",
			"Mert",
			"Enes",
			"Oğuzhan",
			"İrfan",
			"Tayyip",
			"Doruk",
			"Kaan",
			"Eren",
			"Berkay",
			"Onur",
			"Tolga",
			"Volkan",
			"İsmail",
			"Ömer",
			"Salih"
		],
		last: [
			"Yılmaz",
			"Kaya",
			"Demir",
			"Şahin",
			"Çelik",
			"Yıldız",
			"Aydın",
			"Öztürk",
			"Arslan",
			"Doğan",
			"Kilic",
			"Aslan",
			"Koç",
			"Polat",
			"Aksoy",
			"Erdoğan",
			"Çetin",
			"Acar",
			"Kurt",
			"Özdemir",
			"Güneş",
			"Karaca",
			"Bulut",
			"Yavuz",
			"Tekin",
			"Sarı",
			"Uçar",
			"Ekinci",
			"Bozkurt",
			"Güler"
		]
	},
	ENG: {
		first: [
			"Jack",
			"Harry",
			"James",
			"Oliver",
			"George",
			"Charlie",
			"Thomas",
			"Callum",
			"Mason",
			"Ryan",
			"Luke",
			"Adam",
			"Ben",
			"Jake",
			"Nathan",
			"Sam",
			"Joe",
			"Alex",
			"Daniel",
			"Matthew",
			"Lewis",
			"Owen",
			"Finley",
			"Reece",
			"Harvey"
		],
		last: [
			"Smith",
			"Jones",
			"Taylor",
			"Brown",
			"Wilson",
			"Wright",
			"Johnson",
			"Walker",
			"Robinson",
			"Thompson",
			"White",
			"Hall",
			"Green",
			"Harris",
			"Clarke",
			"Edwards",
			"Cooper",
			"Harrison",
			"Ward",
			"Baker",
			"Shaw",
			"Brooks",
			"Reed",
			"Foster",
			"Bennett"
		]
	},
	ESP: {
		first: [
			"Carlos",
			"Diego",
			"Pablo",
			"Sergio",
			"Javier",
			"Álvaro",
			"Mario",
			"Hugo",
			"Adrián",
			"Iván",
			"Raúl",
			"Iker",
			"Marc",
			"Unai",
			"Aitor",
			"Ander",
			"Pedri",
			"Nico",
			"Dani",
			"Álex",
			"Jordi",
			"Ferran",
			"Rodri",
			"Lamine",
			"Pau"
		],
		last: [
			"García",
			"Rodríguez",
			"González",
			"Fernández",
			"López",
			"Martínez",
			"Sánchez",
			"Pérez",
			"Gómez",
			"Ruiz",
			"Díaz",
			"Álvarez",
			"Moreno",
			"Muñoz",
			"Alonso",
			"Gutiérrez",
			"Romero",
			"Navarro",
			"Torres",
			"Domínguez",
			"Vazquez",
			"Ramos",
			"Gil",
			"Serrano",
			"Blanco"
		]
	},
	ITA: {
		first: [
			"Marco",
			"Luca",
			"Andrea",
			"Matteo",
			"Francesco",
			"Alessandro",
			"Giovanni",
			"Lorenzo",
			"Davide",
			"Simone",
			"Federico",
			"Riccardo",
			"Nicola",
			"Stefano",
			"Paolo",
			"Gianluca",
			"Daniele",
			"Fabio",
			"Roberto",
			"Antonio",
			"Manuel",
			"Samuele",
			"Tommaso",
			"Edoardo",
			"Filippo"
		],
		last: [
			"Rossi",
			"Russo",
			"Ferrari",
			"Esposito",
			"Bianchi",
			"Romano",
			"Colombo",
			"Ricci",
			"Marino",
			"Greco",
			"Bruno",
			"Gallo",
			"Conti",
			"De Luca",
			"Mancini",
			"Costa",
			"Giordano",
			"Rizzo",
			"Lombardi",
			"Moretti",
			"Barbieri",
			"Fontana",
			"Santoro",
			"Mariani",
			"Rinaldi"
		]
	},
	GER: {
		first: [
			"Leon",
			"Lukas",
			"Paul",
			"Jonas",
			"Finn",
			"Noah",
			"Felix",
			"Maximilian",
			"Tim",
			"Jan",
			"Niklas",
			"Tobias",
			"Florian",
			"Julian",
			"David",
			"Erik",
			"Simon",
			"Philipp",
			"Kevin",
			"Mario",
			"Sven",
			"Lars",
			"Nico",
			"Fabian",
			"Dennis"
		],
		last: [
			"Müller",
			"Schmidt",
			"Schneider",
			"Fischer",
			"Weber",
			"Meyer",
			"Wagner",
			"Becker",
			"Hoffmann",
			"Schäfer",
			"Koch",
			"Bauer",
			"Richter",
			"Klein",
			"Wolf",
			"Schröder",
			"Neumann",
			"Schwarz",
			"Zimmermann",
			"Braun",
			"Krüger",
			"Hofmann",
			"Hartmann",
			"Lange",
			"Werner"
		]
	},
	FRA: {
		first: [
			"Hugo",
			"Louis",
			"Gabriel",
			"Arthur",
			"Lucas",
			"Jules",
			"Léo",
			"Adam",
			"Raphaël",
			"Maël",
			"Nathan",
			"Théo",
			"Paul",
			"Nolan",
			"Tom",
			"Enzo",
			"Mathis",
			"Clément",
			"Antoine",
			"Maxime",
			"Kylian",
			"Karim",
			"Amine",
			"Yanis",
			"Sacha"
		],
		last: [
			"Martin",
			"Bernard",
			"Thomas",
			"Petit",
			"Robert",
			"Richard",
			"Durand",
			"Dubois",
			"Moreau",
			"Laurent",
			"Simon",
			"Michel",
			"Lefebvre",
			"Leroy",
			"Roux",
			"David",
			"Bertrand",
			"Morel",
			"Fournier",
			"Girard",
			"Bonnet",
			"Dupont",
			"Lambert",
			"Fontaine",
			"Rousseau"
		]
	},
	POR: {
		first: [
			"João",
			"Miguel",
			"Rafael",
			"Diogo",
			"Gonçalo",
			"Tiago",
			"André",
			"Pedro",
			"Bruno",
			"Ricardo",
			"Nuno",
			"Fábio",
			"Rúben",
			"Bernardo",
			"Francisco",
			"Afonso",
			"Daniel",
			"Eduardo",
			"Sérgio",
			"Paulo",
			"Luis",
			"Gustavo",
			"Renato",
			"Cristiano",
			"Vítor"
		],
		last: [
			"Silva",
			"Santos",
			"Ferreira",
			"Pereira",
			"Oliveira",
			"Costa",
			"Rodrigues",
			"Martins",
			"Jesus",
			"Sousa",
			"Fernandes",
			"Gonçalves",
			"Gomes",
			"Lopes",
			"Marques",
			"Almeida",
			"Alves",
			"Ribeiro",
			"Pinto",
			"Carvalho",
			"Teixeira",
			"Moreira",
			"Correia",
			"Mendes",
			"Nunes"
		]
	},
	BRA: {
		first: [
			"Lucas",
			"Gabriel",
			"Matheus",
			"Pedro",
			"João",
			"Rafael",
			"Felipe",
			"Bruno",
			"Gustavo",
			"Thiago",
			"André",
			"Diego",
			"Caio",
			"Vinicius",
			"Rodrygo",
			"Marcos",
			"Paulo",
			"Daniel",
			"Eduardo",
			"Leonardo",
			"Igor",
			"Alex",
			"Renato",
			"Danilo",
			"Everton"
		],
		last: [
			"Silva",
			"Santos",
			"Oliveira",
			"Souza",
			"Rodrigues",
			"Ferreira",
			"Alves",
			"Pereira",
			"Lima",
			"Gomes",
			"Costa",
			"Ribeiro",
			"Martins",
			"Carvalho",
			"Almeida",
			"Lopes",
			"Soares",
			"Fernandes",
			"Vieira",
			"Barbosa",
			"Rocha",
			"Dias",
			"Nascimento",
			"Moreira",
			"Mendes"
		]
	},
	ARG: {
		first: [
			"Santiago",
			"Mateo",
			"Juan",
			"Nicolás",
			"Franco",
			"Lautaro",
			"Julián",
			"Facundo",
			"Gonzalo",
			"Leandro",
			"Ángel",
			"Exequiel",
			"Rodrigo",
			"Paulo",
			"Emiliano",
			"Lisandro",
			"Nahuel",
			"Enzo",
			"Thiago",
			"Valentín",
			"Agustín",
			"Maximiliano",
			"Cristian",
			"Lucas",
			"Guido"
		],
		last: [
			"González",
			"Rodríguez",
			"Fernández",
			"López",
			"Martínez",
			"García",
			"Pérez",
			"Romero",
			"Sánchez",
			"Díaz",
			"Álvarez",
			"Torres",
			"Ruiz",
			"Ramírez",
			"Flores",
			"Acosta",
			"Benítez",
			"Herrera",
			"Medina",
			"Castro",
			"Vargas",
			"Morales",
			"Ortiz",
			"Rojas",
			"Silva"
		]
	},
	NED: {
		first: [
			"Daan",
			"Sem",
			"Luuk",
			"Lars",
			"Bram",
			"Finn",
			"Jesse",
			"Milan",
			"Noah",
			"Thijs",
			"Sven",
			"Jordy",
			"Dirk",
			"Memphis",
			"Cody",
			"Xavi",
			"Ryan",
			"Steven",
			"Daley",
			"Virgil",
			"Matthijs",
			"Frenkie",
			"Donny",
			"Wout",
			"Teun"
		],
		last: [
			"de Jong",
			"de Boer",
			"van Dijk",
			"van Persie",
			"Janssen",
			"Bakker",
			"Visser",
			"Smit",
			"de Vries",
			"Meijer",
			"Mulder",
			"Bos",
			"Vos",
			"Hendriks",
			"Dekker",
			"Brouwer",
			"Prins",
			"Willems",
			"Koster",
			"Peters",
			"Gerritsen",
			"Hermans",
			"Kuipers",
			"Schouten",
			"Berghuis"
		]
	},
	BEL: {
		first: [
			"Noah",
			"Liam",
			"Arthur",
			"Louis",
			"Lucas",
			"Adam",
			"Victor",
			"Jules",
			"Finn",
			"Leon",
			"Thibaut",
			"Eden",
			"Kevin",
			"Romelu",
			"Youri",
			"Axel",
			"Leander",
			"Hans",
			"Dries",
			"Michy",
			"Loïs",
			"Amadou",
			"Charles",
			"Orel",
			"Alexis"
		],
		last: [
			"Peeters",
			"Janssens",
			"Maes",
			"Jacobs",
			"Mertens",
			"Willems",
			"Claes",
			"Goossens",
			"Wouters",
			"De Smet",
			"Vermeulen",
			"Pauwels",
			"Lambert",
			"Dumont",
			"Leclercq",
			"Simon",
			"Martin",
			"Dubois",
			"Laurent",
			"Petit",
			"Witsel",
			"Hazard",
			"De Bruyne",
			"Courtois",
			"Lukaku"
		]
	},
	CRO: {
		first: [
			"Luka",
			"Ivan",
			"Marko",
			"Josip",
			"Mateo",
			"Filip",
			"Ante",
			"Domagoj",
			"Mario",
			"Nikola",
			"Duje",
			"Borna",
			"Marin",
			"Karlo",
			"Toni",
			"Andrej",
			"Bruno",
			"Dario",
			"Stipe",
			"Vedran",
			"Igor",
			"Zvonimir",
			"Darijo",
			"Milan",
			"Dino"
		],
		last: [
			"Horvat",
			"Kovačević",
			"Babić",
			"Marić",
			"Jurić",
			"Novak",
			"Kovačić",
			"Perić",
			"Šimić",
			"Božić",
			"Marković",
			"Petrović",
			"Tomić",
			"Jukić",
			"Vidović",
			"Barišić",
			"Pavić",
			"Vuković",
			"Kralj",
			"Matić",
			"Kovač",
			"Brozović",
			"Modrić",
			"Rakitić",
			"Lovren"
		]
	}
};
var FALLBACK_NATIONS = [
	"BRA",
	"ARG",
	"CRO",
	"NED",
	"BEL"
];
function pickNationForClub(clubCountry, rngNext) {
	if (rngNext() < .62) return clubCountry;
	if (rngNext() < .5) return FALLBACK_NATIONS[Math.floor(rngNext() * FALLBACK_NATIONS.length)];
	const keys = Object.keys(NAMES);
	return keys[Math.floor(rngNext() * keys.length)];
}
function playerValue(ovr, age, pot) {
	const ageMod = age < 23 ? 1.25 : age > 32 ? .42 : 1 - Math.max(0, age - 27) * .045;
	const potMod = 1 + Math.max(0, pot - ovr) / 40;
	return Math.max(8e4, Math.round((ovr - 52) ** 2 * 85e3 * ageMod * potMod));
}
function playerWage(ovr, age) {
	const base = Math.max(800, Math.round((ovr - 40) ** 2 * 14));
	return age > 32 ? Math.round(base * .85) : base;
}
function makePlayer(rng, clubId, clubCountry, pos, ovr, ageBias, id) {
	let age = rng.int(19, 32);
	if (ageBias === "youth") age = rng.int(16, 21);
	if (ageBias === "vet") age = rng.int(31, 37);
	if (ageBias === "prime") age = rng.int(24, 29);
	ovr = clamp(Math.round(ovr + rng.int(-2, 2)), 46, 94);
	let pot = ovr + rng.int(0, age < 23 ? 14 : age < 28 ? 6 : 2);
	if (age >= 30) pot = ovr;
	pot = clamp(pot, ovr, 95);
	const nation = pickNationForClub(clubCountry, () => rng.next());
	const pool = NAMES[nation] ?? NAMES.ENG;
	const name = `${rng.pick(pool.first)} ${rng.pick(pool.last)}`;
	const growth = Number((.35 + rng.float(0, .55) + (age < 21 ? .2 : 0)).toFixed(2));
	return {
		id: id ?? "",
		clubId,
		name,
		nation,
		age,
		pos,
		ovr,
		pot,
		growth,
		energy: rng.int(86, 100),
		morale: rng.int(62, 88),
		value: playerValue(ovr, age, pot),
		wage: playerWage(ovr, age),
		yellows: 0,
		matchYellows: 0,
		ban: 0,
		inj: null,
		form: rng.int(48, 72),
		goals: 0,
		assists: 0,
		apps: 0,
		ratingSum: 0,
		listed: false,
		askingPrice: 0,
		regen: false
	};
}
var SQUAD_SHAPE = [
	[
		"GK",
		1,
		"prime",
		2
	],
	[
		"GK",
		1,
		"youth",
		-8
	],
	[
		"CB",
		2,
		"prime",
		0
	],
	[
		"CB",
		1,
		"vet",
		-4
	],
	[
		"CB",
		1,
		"youth",
		-9
	],
	[
		"LB",
		1,
		"prime",
		-1
	],
	[
		"LB",
		1,
		"youth",
		-8
	],
	[
		"RB",
		1,
		"prime",
		-1
	],
	[
		"RB",
		1,
		"youth",
		-8
	],
	[
		"CDM",
		1,
		"prime",
		-1
	],
	[
		"CM",
		2,
		"prime",
		0
	],
	[
		"CM",
		1,
		"youth",
		-8
	],
	[
		"CAM",
		1,
		"prime",
		-1
	],
	[
		"LM",
		1,
		void 0,
		-3
	],
	[
		"RM",
		1,
		void 0,
		-3
	],
	[
		"LW",
		1,
		"prime",
		-1
	],
	[
		"RW",
		1,
		"prime",
		-1
	],
	[
		"ST",
		2,
		"prime",
		1
	],
	[
		"ST",
		1,
		"youth",
		-7
	]
];
function generateSquad(rng, clubId, country, rep, nextId) {
	const out = [];
	const used = /* @__PURE__ */ new Set();
	for (const [pos, count, bias, delta] of SQUAD_SHAPE) for (let i = 0; i < count; i++) {
		const p = makePlayer(rng, clubId, country, pos, rep + delta, bias, nextId());
		let guard = 0;
		while (used.has(p.name) && guard++ < 12) {
			const pool = NAMES[p.nation] ?? NAMES.ENG;
			p.name = `${rng.pick(pool.first)} ${rng.pick(pool.last)}`;
		}
		used.add(p.name);
		p.value = playerValue(p.ovr, p.age, p.pot);
		p.wage = playerWage(p.ovr, p.age);
		out.push(p);
	}
	return out;
}
function applyXp(p, matchPts) {
	if (p.ovr >= p.pot) return;
	if (p.age >= 30) return;
	const gain = matchPts * p.growth * (1 + (p.pot - p.ovr) / 20) * (p.age < 23 ? 1.5 : 1) / 28;
	if (gain >= 1) {
		p.ovr = Math.min(p.pot, p.ovr + Math.floor(gain));
		p.value = playerValue(p.ovr, p.age, p.pot);
		p.wage = playerWage(p.ovr, p.age);
	} else if (Math.random() < gain) {
		p.ovr = Math.min(p.pot, p.ovr + 1);
		p.value = playerValue(p.ovr, p.age, p.pot);
		p.wage = playerWage(p.ovr, p.age);
	}
}
function seasonDecay(p, rng) {
	p.age += 1;
	if (p.age >= 30) {
		const drop = p.age >= 34 ? rng.int(2, 4) : rng.int(1, 2);
		p.ovr = Math.max(48, p.ovr - drop);
		p.pot = Math.max(p.ovr, p.pot - drop);
		p.value = playerValue(p.ovr, p.age, p.pot);
		p.wage = playerWage(p.ovr, p.age);
	}
	p.yellows = 0;
	p.goals = 0;
	p.assists = 0;
	p.apps = 0;
	p.ratingSum = 0;
	p.form = 55;
	p.energy = 100;
}
var POS$1 = [
	"GK",
	"CB",
	"LB",
	"RB",
	"CDM",
	"CM",
	"CAM",
	"LW",
	"RW",
	"ST"
];
var YouthAcademy = class {
	intake(state, rng, club) {
		const n = club.academy >= 5 ? 3 : club.academy >= 3 ? 2 : 1;
		const born = [];
		for (let i = 0; i < n; i++) {
			const pos = rng.pick(POS$1);
			const ovr = 48 + club.academy * 3 + rng.int(0, 6);
			const p = makePlayer(rng, club.id, club.country, pos, ovr, "youth", `p_${state.uid++}`);
			p.regen = true;
			p.pot = Math.min(93, ovr + 8 + club.academy * 3 + rng.int(0, 6));
			p.value = playerValue(p.ovr, p.age, p.pot);
			p.wage = playerWage(p.ovr, p.age);
			p.name = p.name + " Jr.";
			state.players[p.id] = p;
			born.push(p);
		}
		return born;
	}
};
var LEAGUES = [
	{
		id: "ENG1",
		name: "Premier League",
		country: "ENG",
		tier: 1,
		size: 20
	},
	{
		id: "ESP1",
		name: "La Liga",
		country: "ESP",
		tier: 1,
		size: 20
	},
	{
		id: "ITA1",
		name: "Serie A",
		country: "ITA",
		tier: 1,
		size: 20
	},
	{
		id: "GER1",
		name: "Bundesliga",
		country: "GER",
		tier: 1,
		size: 18
	},
	{
		id: "FRA1",
		name: "Ligue 1",
		country: "FRA",
		tier: 1,
		size: 18
	},
	{
		id: "POR1",
		name: "Primeira Liga",
		country: "POR",
		tier: 1,
		size: 18
	},
	{
		id: "TUR1",
		name: "Süper Lig",
		country: "TUR",
		tier: 1,
		size: 18
	},
	{
		id: "TUR2",
		name: "TFF 1. Lig",
		country: "TUR",
		tier: 2,
		size: 18
	}
];
var CLUB_RAW = {
	ENG1: [
		[
			"Manchester City",
			"MCI",
			"Etihad Stadium",
			92,
			"#6CABDD",
			"#1C2C5B"
		],
		[
			"Arsenal",
			"ARS",
			"Emirates Stadium",
			90,
			"#EF0107",
			"#FFFFFF"
		],
		[
			"Liverpool",
			"LIV",
			"Anfield",
			90,
			"#C8102E",
			"#00B2A9"
		],
		[
			"Chelsea",
			"CHE",
			"Stamford Bridge",
			86,
			"#034694",
			"#FFFFFF"
		],
		[
			"Manchester United",
			"MUN",
			"Old Trafford",
			84,
			"#DA291C",
			"#FBE122"
		],
		[
			"Tottenham",
			"TOT",
			"Tottenham Stadium",
			83,
			"#132257",
			"#FFFFFF"
		],
		[
			"Newcastle",
			"NEW",
			"St James' Park",
			82,
			"#241F20",
			"#FFFFFF"
		],
		[
			"Aston Villa",
			"AVL",
			"Villa Park",
			81,
			"#95BFE5",
			"#670E36"
		],
		[
			"Brighton",
			"BHA",
			"Amex Stadium",
			78,
			"#0057B8",
			"#FFFFFF"
		],
		[
			"West Ham",
			"WHU",
			"London Stadium",
			77,
			"#7A263A",
			"#1BB1E7"
		],
		[
			"Crystal Palace",
			"CRY",
			"Selhurst Park",
			76,
			"#1B458F",
			"#C4122E"
		],
		[
			"Fulham",
			"FUL",
			"Craven Cottage",
			75,
			"#FFFFFF",
			"#000000"
		],
		[
			"Brentford",
			"BRE",
			"Gtech Community",
			74,
			"#E30613",
			"#FBB800"
		],
		[
			"Wolves",
			"WOL",
			"Molineux",
			74,
			"#FDB913",
			"#231F20"
		],
		[
			"Everton",
			"EVE",
			"Goodison Park",
			73,
			"#003399",
			"#FFFFFF"
		],
		[
			"Nottingham Forest",
			"NFO",
			"City Ground",
			76,
			"#DD0000",
			"#FFFFFF"
		],
		[
			"Bournemouth",
			"BOU",
			"Vitality Stadium",
			74,
			"#DA291C",
			"#000000"
		],
		[
			"Leicester",
			"LEI",
			"King Power",
			72,
			"#003090",
			"#FDBE11"
		],
		[
			"Ipswich",
			"IPS",
			"Portman Road",
			70,
			"#003399",
			"#FFFFFF"
		],
		[
			"Southampton",
			"SOU",
			"St Mary's",
			70,
			"#D71920",
			"#FFFFFF"
		]
	],
	ESP1: [
		[
			"Real Madrid",
			"RMA",
			"Santiago Bernabéu",
			93,
			"#FFFFFF",
			"#FEBE10"
		],
		[
			"Barcelona",
			"BAR",
			"Spotify Camp Nou",
			90,
			"#A50044",
			"#004D98"
		],
		[
			"Atlético Madrid",
			"ATM",
			"Cívitas Metropolitano",
			86,
			"#CE3524",
			"#FFFFFF"
		],
		[
			"Athletic Club",
			"ATH",
			"San Mamés",
			82,
			"#EE2523",
			"#FFFFFF"
		],
		[
			"Real Sociedad",
			"RSO",
			"Reale Arena",
			80,
			"#0067B1",
			"#FFFFFF"
		],
		[
			"Villarreal",
			"VIL",
			"Estadio de la Cerámica",
			81,
			"#FFE667",
			"#005187"
		],
		[
			"Real Betis",
			"BET",
			"Benito Villamarín",
			80,
			"#00954C",
			"#FFFFFF"
		],
		[
			"Valencia",
			"VAL",
			"Mestalla",
			76,
			"#FFFFFF",
			"#EE3524"
		],
		[
			"Sevilla",
			"SEV",
			"Ramón Sánchez-Pizjuán",
			77,
			"#FFFFFF",
			"#D10514"
		],
		[
			"Girona",
			"GIR",
			"Montilivi",
			78,
			"#CD2534",
			"#FFFFFF"
		],
		[
			"Osasuna",
			"OSA",
			"El Sadar",
			74,
			"#D91A2A",
			"#002B5C"
		],
		[
			"Celta Vigo",
			"CEL",
			"Balaídos",
			74,
			"#8AC3EE",
			"#FFFFFF"
		],
		[
			"Mallorca",
			"MLL",
			"Son Moix",
			73,
			"#E20613",
			"#000000"
		],
		[
			"Rayo Vallecano",
			"RAY",
			"Vallecas",
			73,
			"#FFFFFF",
			"#E20613"
		],
		[
			"Getafe",
			"GET",
			"Coliseum",
			72,
			"#004294",
			"#FFFFFF"
		],
		[
			"Alavés",
			"ALA",
			"Mendizorrotza",
			71,
			"#004FA3",
			"#FFFFFF"
		],
		[
			"Espanyol",
			"ESP",
			"Stage Front Stadium",
			72,
			"#007FC8",
			"#FFFFFF"
		],
		[
			"Las Palmas",
			"LPA",
			"Gran Canaria",
			70,
			"#FFD100",
			"#0077C8"
		],
		[
			"Valladolid",
			"VLL",
			"José Zorrilla",
			69,
			"#7B2D8E",
			"#FFFFFF"
		],
		[
			"Leganés",
			"LEG",
			"Butarque",
			68,
			"#FFFFFF",
			"#0067B1"
		]
	],
	ITA1: [
		[
			"Inter",
			"INT",
			"San Siro",
			90,
			"#010E80",
			"#000000"
		],
		[
			"Juventus",
			"JUV",
			"Allianz Stadium",
			86,
			"#000000",
			"#FFFFFF"
		],
		[
			"Milan",
			"MIL",
			"San Siro",
			85,
			"#FB090B",
			"#000000"
		],
		[
			"Napoli",
			"NAP",
			"Diego Armando Maradona",
			84,
			"#12A0C4",
			"#FFFFFF"
		],
		[
			"Roma",
			"ROM",
			"Olimpico",
			82,
			"#8E1F2F",
			"#F0BC42"
		],
		[
			"Lazio",
			"LAZ",
			"Olimpico",
			80,
			"#87D8F7",
			"#FFFFFF"
		],
		[
			"Atalanta",
			"ATA",
			"Gewiss Stadium",
			83,
			"#1E71B8",
			"#000000"
		],
		[
			"Fiorentina",
			"FIO",
			"Artemio Franchi",
			79,
			"#482E92",
			"#FFFFFF"
		],
		[
			"Bologna",
			"BOL",
			"Renato Dall'Ara",
			78,
			"#A52A2A",
			"#0033A0"
		],
		[
			"Torino",
			"TOR",
			"Olimpico Grande Torino",
			76,
			"#8B1A1A",
			"#FFFFFF"
		],
		[
			"Udinese",
			"UDI",
			"Bluenergy Stadium",
			74,
			"#000000",
			"#FFFFFF"
		],
		[
			"Monza",
			"MON",
			"U-Power Stadium",
			73,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Sassuolo",
			"SAS",
			"Mapei Stadium",
			73,
			"#00A651",
			"#000000"
		],
		[
			"Empoli",
			"EMP",
			"Carlo Castellani",
			71,
			"#0055A4",
			"#FFFFFF"
		],
		[
			"Cagliari",
			"CAG",
			"Unipol Domus",
			72,
			"#AD1919",
			"#003DA5"
		],
		[
			"Genoa",
			"GEN",
			"Luigi Ferraris",
			72,
			"#C8102E",
			"#003DA5"
		],
		[
			"Lecce",
			"LEC",
			"Via del Mare",
			71,
			"#FFED00",
			"#E30613"
		],
		[
			"Hellas Verona",
			"VER",
			"Marcantonio Bentegodi",
			70,
			"#002B5C",
			"#FFED00"
		],
		[
			"Parma",
			"PAR",
			"Ennio Tardini",
			72,
			"#FFE14D",
			"#0054A6"
		],
		[
			"Como",
			"COM",
			"Giuseppe Sinigaglia",
			71,
			"#003399",
			"#FFFFFF"
		]
	],
	GER1: [
		[
			"Bayern Münih",
			"BAY",
			"Allianz Arena",
			93,
			"#DC052D",
			"#0066B2"
		],
		[
			"Borussia Dortmund",
			"BVB",
			"Signal Iduna Park",
			86,
			"#FDE100",
			"#000000"
		],
		[
			"Bayer Leverkusen",
			"B04",
			"BayArena",
			85,
			"#E32221",
			"#000000"
		],
		[
			"RB Leipzig",
			"RBL",
			"Red Bull Arena",
			83,
			"#DD0741",
			"#FFFFFF"
		],
		[
			"Eintracht Frankfurt",
			"SGE",
			"Deutsche Bank Park",
			80,
			"#E1000F",
			"#000000"
		],
		[
			"Stuttgart",
			"VFB",
			"MHP Arena",
			79,
			"#FFFFFF",
			"#E32219"
		],
		[
			"Wolfsburg",
			"WOB",
			"Volkswagen Arena",
			77,
			"#65B32E",
			"#FFFFFF"
		],
		[
			"Mönchengladbach",
			"BMG",
			"Borussia-Park",
			76,
			"#000000",
			"#FFFFFF"
		],
		[
			"Freiburg",
			"SCF",
			"Europa-Park Stadion",
			77,
			"#000000",
			"#E30613"
		],
		[
			"Hoffenheim",
			"TSG",
			"PreZero Arena",
			75,
			"#1C63B7",
			"#FFFFFF"
		],
		[
			"Werder Bremen",
			"SVW",
			"Weserstadion",
			74,
			"#1D9053",
			"#FFFFFF"
		],
		[
			"Union Berlin",
			"UNB",
			"Stadion An der Alten Försterei",
			74,
			"#EB1923",
			"#FFFFFF"
		],
		[
			"Augsburg",
			"FCA",
			"WWK Arena",
			72,
			"#BA3733",
			"#0168B3"
		],
		[
			"Mainz",
			"M05",
			"MEWA Arena",
			73,
			"#C3102E",
			"#FFFFFF"
		],
		[
			"Heidenheim",
			"FCH",
			"Voith-Arena",
			71,
			"#E2001A",
			"#003DA5"
		],
		[
			"Bochum",
			"BOC",
			"Vonovia Ruhrstadion",
			70,
			"#005CA9",
			"#FFFFFF"
		],
		[
			"St. Pauli",
			"STP",
			"Millerntor-Stadion",
			72,
			"#634B2C",
			"#FFFFFF"
		],
		[
			"Holstein Kiel",
			"KIE",
			"Holstein-Stadion",
			68,
			"#005CA9",
			"#E30613"
		]
	],
	FRA1: [
		[
			"Paris Saint-Germain",
			"PSG",
			"Parc des Princes",
			93,
			"#004170",
			"#DA291C"
		],
		[
			"Monaco",
			"ASM",
			"Stade Louis II",
			82,
			"#E31B23",
			"#FFFFFF"
		],
		[
			"Marseille",
			"OM",
			"Orange Vélodrome",
			80,
			"#2FAEEA",
			"#FFFFFF"
		],
		[
			"Lille",
			"LIL",
			"Pierre Mauroy",
			80,
			"#E01E13",
			"#FFFFFF"
		],
		[
			"Lyon",
			"OL",
			"Groupama Stadium",
			79,
			"#00205B",
			"#E4002B"
		],
		[
			"Nice",
			"NIC",
			"Allianz Riviera",
			78,
			"#D9230F",
			"#000000"
		],
		[
			"Lens",
			"RCL",
			"Bollaert-Delelis",
			77,
			"#E32219",
			"#FFD100"
		],
		[
			"Rennes",
			"REN",
			"Roazhon Park",
			76,
			"#E30613",
			"#000000"
		],
		[
			"Strasbourg",
			"RCSA",
			"La Meinau",
			74,
			"#009FE3",
			"#FFFFFF"
		],
		[
			"Toulouse",
			"TFC",
			"Stadium de Toulouse",
			73,
			"#51284F",
			"#FFFFFF"
		],
		[
			"Reims",
			"SDR",
			"Stade Auguste-Delaune",
			72,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Nantes",
			"FCN",
			"La Beaujoire",
			72,
			"#FFE200",
			"#007A33"
		],
		[
			"Brest",
			"SB29",
			"Francis-Le Blé",
			73,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Montpellier",
			"MHSC",
			"Stade de la Mosson",
			71,
			"#FF6B00",
			"#003DA5"
		],
		[
			"Nice Côte",
			"AUX",
			"Abbé-Deschamps",
			70,
			"#FFFFFF",
			"#E30613"
		],
		[
			"Le Havre",
			"HAC",
			"Stade Océane",
			70,
			"#51B5E0",
			"#003DA5"
		],
		[
			"Angers",
			"SCO",
			"Raymond-Kopa",
			69,
			"#FFFFFF",
			"#000000"
		],
		[
			"Saint-Étienne",
			"ASSE",
			"Geoffroy-Guichard",
			71,
			"#009A44",
			"#FFFFFF"
		]
	],
	POR1: [
		[
			"Sporting",
			"SCP",
			"José Alvalade",
			84,
			"#008057",
			"#FFFFFF"
		],
		[
			"Benfica",
			"SLB",
			"Estádio da Luz",
			84,
			"#E32636",
			"#FFFFFF"
		],
		[
			"Porto",
			"FCP",
			"Estádio do Dragão",
			83,
			"#003E7E",
			"#FFFFFF"
		],
		[
			"Braga",
			"SCB",
			"Estádio Municipal de Braga",
			78,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Vitória Guimarães",
			"VSC",
			"D. Afonso Henriques",
			74,
			"#FFFFFF",
			"#000000"
		],
		[
			"Famalicão",
			"FAM",
			"Municipal 22 de Junho",
			71,
			"#003DA5",
			"#FFFFFF"
		],
		[
			"Moreirense",
			"MOR",
			"Comendador Joaquim de Almeida",
			70,
			"#007A33",
			"#FFFFFF"
		],
		[
			"Gil Vicente",
			"GIL",
			"Cidade de Barcelos",
			69,
			"#E30613",
			"#003DA5"
		],
		[
			"Boavista",
			"BOA",
			"Estádio do Bessa",
			69,
			"#000000",
			"#FFFFFF"
		],
		[
			"Estoril",
			"EST",
			"António Coimbra da Mota",
			68,
			"#FFD100",
			"#000000"
		],
		[
			"Casa Pia",
			"CAS",
			"Pina Manique",
			67,
			"#000000",
			"#FFFFFF"
		],
		[
			"Rio Ave",
			"RAV",
			"Dos Arcos",
			67,
			"#007A33",
			"#FFFFFF"
		],
		[
			"Arouca",
			"ARO",
			"Municipal de Arouca",
			66,
			"#FFD100",
			"#003DA5"
		],
		[
			"Farense",
			"FAR",
			"São Luís",
			65,
			"#000000",
			"#FFFFFF"
		],
		[
			"Nacional",
			"NAC",
			"Estádio da Madeira",
			65,
			"#000000",
			"#FFFFFF"
		],
		[
			"Santa Clara",
			"SCL",
			"São Miguel",
			66,
			"#E30613",
			"#FFFFFF"
		],
		[
			"AVS",
			"AVS",
			"Cidade de Vila das Aves",
			64,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Estrela Amadora",
			"ESTA",
			"José Gomes",
			64,
			"#E30613",
			"#007A33"
		]
	],
	TUR1: [
		[
			"Galatasaray",
			"GS",
			"RAMS Park",
			86,
			"#FDB913",
			"#A90432"
		],
		[
			"Fenerbahçe",
			"FB",
			"Ülker Stadyumu",
			85,
			"#002F6C",
			"#FFED00"
		],
		[
			"Beşiktaş",
			"BJK",
			"Tüpraş Stadyumu",
			78,
			"#000000",
			"#FFFFFF"
		],
		[
			"Trabzonspor",
			"TS",
			"Papara Park",
			74,
			"#6CABDD",
			"#8B1A4A"
		],
		[
			"Başakşehir",
			"IBFK",
			"Başakşehir Fatih Terim",
			70,
			"#F26522",
			"#003DA5"
		],
		[
			"Samsunspor",
			"SAM",
			"Samsun 19 Mayıs",
			66,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Eyüpspor",
			"EYP",
			"Eyüp Stadyumu",
			62,
			"#7AC143",
			"#FFED00"
		],
		[
			"Göztepe",
			"GOZ",
			"Gürsel Aksel",
			64,
			"#FFD100",
			"#E30613"
		],
		[
			"Kasımpaşa",
			"KAS",
			"Recep Tayyip Erdoğan",
			63,
			"#003DA5",
			"#FFFFFF"
		],
		[
			"Alanyaspor",
			"ALA",
			"Bahçeşehir Okulları",
			62,
			"#FF6600",
			"#007A33"
		],
		[
			"Antalyaspor",
			"ANT",
			"Corendon Stadyumu",
			63,
			"#FFFFFF",
			"#E30613"
		],
		[
			"Konyaspor",
			"KON",
			"Konya Büyükşehir",
			61,
			"#007A33",
			"#FFFFFF"
		],
		[
			"Rizespor",
			"RIZ",
			"Çaykur Didi",
			60,
			"#007A33",
			"#003DA5"
		],
		[
			"Kayserispor",
			"KAY",
			"Kadir Has",
			59,
			"#E30613",
			"#FFED00"
		],
		[
			"Sivasspor",
			"SIV",
			"Yeni 4 Eylül",
			60,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Gaziantep FK",
			"GFK",
			"Kalyon Stadyumu",
			58,
			"#E30613",
			"#000000"
		],
		[
			"Hatayspor",
			"HAT",
			"Yeni Hatay",
			55,
			"#6CABDD",
			"#E30613"
		],
		[
			"Bodrum FK",
			"BOD",
			"Bodrum İlçe",
			54,
			"#003DA5",
			"#FFFFFF"
		]
	],
	TUR2: [
		[
			"Adana Demirspor",
			"ADS",
			"Yeni Adana",
			64,
			"#003DA5",
			"#87CEEB"
		],
		[
			"Ankaragücü",
			"ANK",
			"Eryaman Stadyumu",
			63,
			"#FFED00",
			"#003DA5"
		],
		[
			"Gençlerbirliği",
			"GEN",
			"Eryaman Stadyumu",
			61,
			"#E30613",
			"#000000"
		],
		[
			"Fatih Karagümrük",
			"FKG",
			"Atatürk Olimpiyat",
			60,
			"#E30613",
			"#000000"
		],
		[
			"Pendikspor",
			"PEN",
			"Pendik Stadyumu",
			58,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Bandırmaspor",
			"BAN",
			"17 Eylül",
			57,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Boluspor",
			"BOL",
			"Bolu Atatürk",
			56,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Erzurumspor",
			"ERZ",
			"Kazım Karabekir",
			56,
			"#003DA5",
			"#FFFFFF"
		],
		[
			"Amedspor",
			"AMD",
			"Diyarbakır Stadyumu",
			58,
			"#007A33",
			"#E30613"
		],
		[
			"Sakaryaspor",
			"SAK",
			"Yeni Sakarya",
			57,
			"#007A33",
			"#000000"
		],
		[
			"İstanbulspor",
			"IST",
			"Esenyurt",
			55,
			"#FFED00",
			"#000000"
		],
		[
			"Manisa FK",
			"MAN",
			"Mümin Özkasap",
			55,
			"#000000",
			"#FFFFFF"
		],
		[
			"Ümraniyespor",
			"UMR",
			"Ümraniye Belediyesi",
			54,
			"#E30613",
			"#FFFFFF"
		],
		[
			"Çorum FK",
			"COR",
			"Çorum Şehir",
			54,
			"#E30613",
			"#000000"
		],
		[
			"Esenler Erokspor",
			"ERO",
			"Esenler",
			53,
			"#FFED00",
			"#000000"
		],
		[
			"Iğdır FK",
			"IGD",
			"Iğdır Şehir",
			52,
			"#007A33",
			"#FFFFFF"
		],
		[
			"Keçiörengücü",
			"KEC",
			"Aktepe",
			52,
			"#7AC143",
			"#FFFFFF"
		],
		[
			"Şanlıurfaspor",
			"SAN",
			"11 Nisan",
			51,
			"#007A33",
			"#FFED00"
		]
	]
};
var NPC_CLUBS = [
	[
		"Ajax",
		"AJA",
		"NED",
		"Johan Cruijff Arena",
		82,
		"#D2122E",
		"#FFFFFF"
	],
	[
		"PSV",
		"PSV",
		"NED",
		"Philips Stadion",
		81,
		"#E03A3E",
		"#FFFFFF"
	],
	[
		"Feyenoord",
		"FEY",
		"NED",
		"De Kuip",
		80,
		"#E03A3E",
		"#FFFFFF"
	],
	[
		"Club Brugge",
		"BRU",
		"BEL",
		"Jan Breydel",
		78,
		"#003DA5",
		"#000000"
	],
	[
		"Anderlecht",
		"AND",
		"BEL",
		"Lotto Park",
		76,
		"#7A263A",
		"#FFFFFF"
	],
	[
		"Genk",
		"GNK",
		"BEL",
		"Cegeka Arena",
		75,
		"#003DA5",
		"#FFFFFF"
	],
	[
		"Celtic",
		"CEL",
		"SCO",
		"Celtic Park",
		78,
		"#018749",
		"#FFFFFF"
	],
	[
		"Rangers",
		"RAN",
		"SCO",
		"Ibrox",
		77,
		"#003DA5",
		"#FFFFFF"
	],
	[
		"Salzburg",
		"RBS",
		"AUT",
		"Red Bull Arena",
		79,
		"#E30613",
		"#FFFFFF"
	],
	[
		"Young Boys",
		"YB",
		"SUI",
		"Wankdorf",
		74,
		"#FFED00",
		"#000000"
	],
	[
		"Olympiacos",
		"OLY",
		"GRE",
		"Georgios Karaiskakis",
		76,
		"#E30613",
		"#FFFFFF"
	],
	[
		"PAOK",
		"PAOK",
		"GRE",
		"Toumba",
		74,
		"#000000",
		"#FFFFFF"
	],
	[
		"AEK Athens",
		"AEK",
		"GRE",
		"OPAP Arena",
		73,
		"#FFED00",
		"#000000"
	],
	[
		"Sparta Praha",
		"SPP",
		"CZE",
		"Letná",
		75,
		"#8B1A1A",
		"#FFFFFF"
	],
	[
		"Slavia Praha",
		"SLP",
		"CZE",
		"Eden Arena",
		74,
		"#E30613",
		"#FFFFFF"
	],
	[
		"Kopenhag",
		"FCK",
		"DEN",
		"Parken",
		76,
		"#FFFFFF",
		"#003DA5"
	],
	[
		"Dinamo Zagreb",
		"DZG",
		"CRO",
		"Maksimir",
		75,
		"#003DA5",
		"#FFFFFF"
	],
	[
		"Kızılyıldız",
		"CZV",
		"SRB",
		"Rajko Mitić",
		76,
		"#E30613",
		"#FFFFFF"
	],
	[
		"Partizan",
		"PAR",
		"SRB",
		"Partizan Stadionu",
		73,
		"#000000",
		"#FFFFFF"
	],
	[
		"Shakhtar",
		"SHK",
		"UKR",
		"Arena Lviv",
		78,
		"#F26522",
		"#000000"
	]
];
var COUNTRY_SEED = [
	[
		"ENG",
		"İngiltere",
		[
			18.6,
			23,
			17.4,
			20.8,
			21.2
		]
	],
	[
		"ESP",
		"İspanya",
		[
			18.4,
			16.3,
			21.9,
			16,
			16.8
		]
	],
	[
		"ITA",
		"İtalya",
		[
			15.7,
			17.2,
			19.2,
			18.9,
			15.2
		]
	],
	[
		"GER",
		"Almanya",
		[
			16.2,
			17.1,
			17.4,
			15.6,
			15.6
		]
	],
	[
		"FRA",
		"Fransa",
		[
			12.2,
			11.8,
			16,
			13.2,
			13.1
		]
	],
	[
		"NED",
		"Hollanda",
		[
			13.5,
			13.4,
			10,
			10.3,
			13.9
		]
	],
	[
		"POR",
		"Portekiz",
		[
			12.5,
			11.2,
			11,
			10.9,
			13.8
		]
	],
	[
		"BEL",
		"Belçika",
		[
			8.6,
			11.2,
			14.2,
			8.6,
			12.2
		]
	],
	[
		"TUR",
		"Türkiye",
		[
			6.7,
			11.8,
			9.9,
			7,
			7.2
		]
	],
	[
		"SCO",
		"İskoçya",
		[
			7.6,
			8.8,
			5.8,
			7.1,
			6.8
		]
	],
	[
		"AUT",
		"Avusturya",
		[
			6.8,
			7.4,
			6.8,
			6.2,
			6.8
		]
	],
	[
		"SUI",
		"İsviçre",
		[
			6.2,
			8.5,
			5.2,
			5.9,
			6.9
		]
	],
	[
		"GRE",
		"Yunanistan",
		[
			5.2,
			6.4,
			5.8,
			6.1,
			7
		]
	],
	[
		"CZE",
		"Çekya",
		[
			6.7,
			5.5,
			6,
			5.8,
			6.2
		]
	],
	[
		"DEN",
		"Danimarka",
		[
			5.4,
			5.9,
			6.8,
			5.4,
			6.3
		]
	],
	[
		"CRO",
		"Hırvatistan",
		[
			5.4,
			4.8,
			5.9,
			5.4,
			5.9
		]
	],
	[
		"SRB",
		"Sırbistan",
		[
			5,
			4.5,
			5.2,
			5.8,
			6.4
		]
	],
	[
		"UKR",
		"Ukrayna",
		[
			5.6,
			4.2,
			5,
			4.8,
			5.5
		]
	]
];
var FORMATIONS = {
	"4-3-3": {
		slots: [
			"GK",
			"RB",
			"CB",
			"CB",
			"LB",
			"CM",
			"CM",
			"CM",
			"RW",
			"ST",
			"LW"
		],
		rows: [
			[
				8,
				9,
				10
			],
			[
				5,
				6,
				7
			],
			[
				1,
				2,
				3,
				4
			],
			[0]
		]
	},
	"4-4-2": {
		slots: [
			"GK",
			"RB",
			"CB",
			"CB",
			"LB",
			"RM",
			"CM",
			"CM",
			"LM",
			"ST",
			"ST"
		],
		rows: [
			[9, 10],
			[
				5,
				6,
				7,
				8
			],
			[
				1,
				2,
				3,
				4
			],
			[0]
		]
	},
	"4-2-3-1": {
		slots: [
			"GK",
			"RB",
			"CB",
			"CB",
			"LB",
			"CDM",
			"CDM",
			"RW",
			"CAM",
			"LW",
			"ST"
		],
		rows: [
			[10],
			[
				7,
				8,
				9
			],
			[5, 6],
			[
				1,
				2,
				3,
				4
			],
			[0]
		]
	},
	"3-5-2": {
		slots: [
			"GK",
			"CB",
			"CB",
			"CB",
			"RM",
			"CM",
			"CM",
			"CM",
			"LM",
			"ST",
			"ST"
		],
		rows: [
			[9, 10],
			[
				4,
				5,
				6,
				7,
				8
			],
			[
				1,
				2,
				3
			],
			[0]
		]
	},
	"3-4-3": {
		slots: [
			"GK",
			"CB",
			"CB",
			"CB",
			"RM",
			"CM",
			"CM",
			"LM",
			"RW",
			"ST",
			"LW"
		],
		rows: [
			[
				8,
				9,
				10
			],
			[
				4,
				5,
				6,
				7
			],
			[
				1,
				2,
				3
			],
			[0]
		]
	},
	"5-3-2": {
		slots: [
			"GK",
			"RWB",
			"CB",
			"CB",
			"CB",
			"LWB",
			"CM",
			"CM",
			"CM",
			"ST",
			"ST"
		],
		rows: [
			[9, 10],
			[
				6,
				7,
				8
			],
			[
				1,
				2,
				3,
				4,
				5
			],
			[0]
		]
	},
	"4-1-4-1": {
		slots: [
			"GK",
			"RB",
			"CB",
			"CB",
			"LB",
			"CDM",
			"RM",
			"CM",
			"CM",
			"LM",
			"ST"
		],
		rows: [
			[10],
			[
				6,
				7,
				8,
				9
			],
			[5],
			[
				1,
				2,
				3,
				4
			],
			[0]
		]
	}
};
var DEFAULT_TACTICS = {
	formation: "4-3-3",
	style: "short",
	press: "mid",
	mentality: "balanced"
};
var SPONSORS = [
	{
		id: "none",
		name: "Sponsorsuz",
		weekly: 0,
		winBonus: 0
	},
	{
		id: "local",
		name: "Yerel Holding",
		weekly: 4e4,
		winBonus: 15e3
	},
	{
		id: "bank",
		name: "Ulusal Banka",
		weekly: 9e4,
		winBonus: 35e3
	},
	{
		id: "airline",
		name: "Havayolu",
		weekly: 16e4,
		winBonus: 55e3
	},
	{
		id: "tech",
		name: "Teknoloji Devi",
		weekly: 28e4,
		winBonus: 9e4
	}
];
var INJURY_TABLE = {
	muscle: {
		label: "Hafif Kas Zorlanması",
		minW: 1,
		maxW: 2,
		weight: 48
	},
	ankle: {
		label: "Bilek Burkulması",
		minW: 3,
		maxW: 5,
		weight: 28
	},
	hamstring: {
		label: "Arka Adale Yırtılması",
		minW: 6,
		maxW: 8,
		weight: 18
	},
	acl: {
		label: "Çapraz Bağ Kopması",
		minW: 16,
		maxW: 26,
		weight: 6
	}
};
var STYLE_LABEL = {
	short: "Kısa Pas",
	counter: "Kontra Atak",
	long: "Uzun Top"
};
var PRESS_LABEL = {
	low: "Düşük Blok",
	mid: "Orta Pres",
	high: "Yüksek Pres"
};
var MENT_LABEL = {
	defensive: "Savunma",
	balanced: "Dengeli",
	attacking: "Hücum"
};
var MEDICAL_REDUCTION = [
	0,
	0,
	.1,
	.18,
	.26,
	.35
];
var InjuryManager = class {
	pickKind(rng) {
		const total = Object.values(INJURY_TABLE).reduce((s, x) => s + x.weight, 0);
		let roll = rng.float(0, total);
		for (const [kind, row] of Object.entries(INJURY_TABLE)) {
			roll -= row.weight;
			if (roll <= 0) return kind;
		}
		return "muscle";
	}
	rollDuringMatch(player, rng) {
		let p = .00115;
		if (player.energy < 70) p *= 1 + (70 - player.energy) / 16;
		if (player.energy < 50) p *= 1.85;
		if (player.age >= 33) p *= 1.25;
		if (!rng.chance(p)) return null;
		return this.create(this.pickKind(rng), rng, 1);
	}
	create(kind, rng, medicalLevel) {
		const row = INJURY_TABLE[kind];
		const base = rng.int(row.minW, row.maxW);
		const red = MEDICAL_REDUCTION[medicalLevel] ?? 0;
		const weeks = Math.max(1, Math.round(base * (1 - red)));
		return {
			kind,
			label: row.label,
			weeksLeft: weeks,
			originalWeeks: weeks
		};
	}
	tickWeek(players, medicalLevel) {
		const recovered = [];
		const red = MEDICAL_REDUCTION[medicalLevel] ?? 0;
		for (const p of players) {
			if (!p.inj) continue;
			const extra = red > 0 && Math.random() < red * .35 ? 1 : 0;
			p.inj.weeksLeft -= 1 + extra;
			if (p.inj.weeksLeft <= 0) {
				p.inj = null;
				p.energy = Math.min(100, p.energy + 18);
				recovered.push(p);
			}
		}
		return recovered;
	}
};
function autoPickXI(players, formation) {
	const slots = FORMATIONS[formation]?.slots ?? FORMATIONS["4-3-3"].slots;
	const pool = players.filter((p) => p.ban <= 0 && !p.inj).slice().sort((a, b) => b.ovr - a.ovr);
	const used = /* @__PURE__ */ new Set();
	const xi = [];
	const takeFor = (slot) => {
		const exact = pool.find((p) => !used.has(p.id) && p.pos === slot);
		if (exact) return exact;
		const prefs = {
			GK: ["GK"],
			CB: ["CB", "CDM"],
			LB: [
				"LB",
				"LWB",
				"LM",
				"LW"
			],
			RB: [
				"RB",
				"RWB",
				"RM",
				"RW"
			],
			LWB: [
				"LWB",
				"LB",
				"LM"
			],
			RWB: [
				"RWB",
				"RB",
				"RM"
			],
			CDM: [
				"CDM",
				"CM",
				"CB"
			],
			CM: [
				"CM",
				"CDM",
				"CAM"
			],
			CAM: [
				"CAM",
				"CM",
				"ST"
			],
			LM: [
				"LM",
				"LW",
				"LWB",
				"CM"
			],
			RM: [
				"RM",
				"RW",
				"RWB",
				"CM"
			],
			LW: [
				"LW",
				"LM",
				"ST"
			],
			RW: [
				"RW",
				"RM",
				"ST"
			],
			ST: [
				"ST",
				"CAM",
				"LW",
				"RW"
			]
		}[slot] ?? [slot];
		for (const pos of prefs) {
			const hit = pool.find((p) => !used.has(p.id) && p.pos === pos);
			if (hit) return hit;
		}
		return pool.find((p) => !used.has(p.id) && p.pos !== "GK");
	};
	for (const slot of slots) {
		const p = takeFor(slot);
		if (p) {
			used.add(p.id);
			xi.push(p.id);
		}
	}
	return {
		xi,
		bench: pool.filter((p) => !used.has(p.id)).slice(0, 7).map((p) => p.id)
	};
}
function chemistry(club, players) {
	const slots = FORMATIONS[club.tactics.formation]?.slots ?? FORMATIONS["4-3-3"].slots;
	let fit = 0;
	club.xi.forEach((id, i) => {
		const p = players[id];
		if (p && p.pos === slots[i]) fit += 1;
	});
	return fit / 11;
}
function emptyStats() {
	return {
		shots: 0,
		onTarget: 0,
		possession: 50,
		fouls: 0,
		corners: 0,
		yellows: 0,
		reds: 0,
		xg: 0
	};
}
function tacticMod(a, b) {
	let m = 1;
	if (a.style === "counter" && b.press === "high") m += .07;
	if (a.style === "short" && b.press === "low") m += .05;
	if (a.style === "long" && b.press === "mid") m += .03;
	if (a.press === "high" && b.style === "short") m += .04;
	if (a.mentality === "attacking") m += .04;
	if (a.mentality === "defensive") m -= .03;
	if (a.press === "high") m += .02;
	return m;
}
function sideStrength(club, players, xi, opp, home) {
	const slots = FORMATIONS[club.tactics.formation]?.slots ?? FORMATIONS["4-3-3"].slots;
	let sum = 0;
	let n = 0;
	xi.forEach((id, i) => {
		const p = players[id];
		if (!p || p.inj || p.ban > 0) return;
		let r = p.ovr;
		if (p.pos !== slots[i]) r *= .8;
		r *= .74 + p.energy / 250;
		r *= .9 + p.form / 500;
		r *= .92 + p.morale / 600;
		sum += r;
		n += 1;
	});
	let avg = n ? sum / n : 55;
	avg *= .94 + chemistry(club, players) * .08;
	avg *= .96 + club.morale / 1400;
	avg *= tacticMod(club.tactics, opp);
	if (home) avg *= 1.07;
	return avg;
}
var BUILD = [
	"orta sahada topu çeviriyor.",
	"sağ kanattan bindirme yaptı.",
	"derinlemesine bir pas denedi.",
	"presle topu kazandı.",
	"korner kazandı.",
	"ceza sahası yayında toplandı."
];
var MISS = [
	"şut! Kaleci kurtardı.",
	"kafa vuruşu auta gidiyor.",
	"uzak mesafeden denedi, dışarı.",
	"kaçan fırsat! Kaleciye takıldı.",
	"direkten döndü!",
	"son anda savundu."
];
var MatchEngine = class {
	injuries = new InjuryManager();
	createLive(state, fixtureId, rng) {
		const fx = state.fixtures.find((f) => f.id === fixtureId);
		const home = state.clubs[fx.homeId];
		const away = state.clubs[fx.awayId];
		return {
			fixtureId,
			homeId: home.id,
			awayId: away.id,
			minute: 0,
			stoppage: rng.int(1, 4),
			homeGoals: 0,
			awayGoals: 0,
			events: [{
				minute: 0,
				kind: "text",
				text: `Hakem düdüğü çaldı. ${home.name} — ${away.name} başlıyor.`
			}],
			stats: {
				home: emptyStats(),
				away: emptyStats()
			},
			phase: "first",
			homeXI: home.xi.slice(),
			awayXI: away.xi.slice(),
			homeBench: home.bench.slice(),
			awayBench: away.bench.slice(),
			subsUsed: 0,
			comp: fx.comp,
			round: fx.round,
			scorers: []
		};
	}
	push(live, ev) {
		live.events.unshift(ev);
		if (live.events.length > 80) live.events.length = 80;
	}
	onField(live, side) {
		return side === "home" ? live.homeXI : live.awayXI;
	}
	pickAttacker(state, ids, rng) {
		const atk = ids.map((id) => state.players[id]).filter((p) => !!p && !p.inj);
		const fw = atk.filter((p) => [
			"ST",
			"LW",
			"RW",
			"CAM"
		].includes(p.pos));
		const pool = fw.length ? fw : atk;
		if (!pool.length) return void 0;
		const w = pool.map((p) => p.ovr * p.ovr);
		let t = w.reduce((s, x) => s + x, 0);
		let r = rng.float(0, t);
		for (let i = 0; i < pool.length; i++) {
			r -= w[i];
			if (r <= 0) return pool[i];
		}
		return pool[0];
	}
	stepMinute(state, live, rng) {
		if (live.phase === "ht" || live.phase === "ft") return;
		live.minute += 1;
		const end = live.phase === "first" ? 45 : 90 + live.stoppage;
		if (live.phase === "first" && live.minute === 45) {
			this.push(live, {
				minute: 45,
				kind: "ht",
				text: `İlk yarı sona erdi. ${this.scoreLine(state, live)}`
			});
			live.phase = "ht";
			return;
		}
		if (live.phase === "second" && live.minute >= end) {
			this.finish(state, live, rng);
			return;
		}
		const home = state.clubs[live.homeId];
		const away = state.clubs[live.awayId];
		const hs = sideStrength(home, state.players, live.homeXI, away.tactics, true);
		const as = sideStrength(away, state.players, live.awayXI, home.tactics, false);
		const tot = hs + as;
		live.stats.home.possession = Math.round(hs / tot * 100);
		live.stats.away.possession = 100 - live.stats.home.possession;
		this.drain(state, live);
		if (rng.chance(.07)) {
			const side = rng.chance(hs / tot) ? "home" : "away";
			const club = side === "home" ? home : away;
			this.push(live, {
				minute: live.minute,
				kind: "text",
				side,
				text: `${live.minute}' ${club.name} ${rng.pick(BUILD)}`
			});
		}
		if (rng.chance(.105)) {
			const attackHome = rng.chance(hs / tot);
			this.resolveChance(state, live, rng, attackHome ? "home" : "away", hs, as);
		}
		if (rng.chance(.028)) this.resolveFoul(state, live, rng);
		this.resolveInjury(state, live, rng);
	}
	resolveChance(state, live, rng, side, hs, as) {
		const atk = side === "home" ? hs : as;
		const def = side === "home" ? as : hs;
		const stats = side === "home" ? live.stats.home : live.stats.away;
		const club = state.clubs[side === "home" ? live.homeId : live.awayId];
		const p = this.pickAttacker(state, this.onField(live, side), rng);
		stats.shots += 1;
		const xg = clamp(.06 + (atk - def) / 220 + rng.float(0, .12), .04, .42);
		stats.xg += xg;
		const onT = rng.chance(.38 + xg);
		if (onT) stats.onTarget += 1;
		if (rng.chance(.22)) stats.corners += 1;
		if (onT && rng.chance(xg * 1.35)) {
			if (side === "home") live.homeGoals += 1;
			else live.awayGoals += 1;
			if (p) {
				p.goals += 1;
				p.form = clamp(p.form + 6, 0, 100);
				p.morale = clamp(p.morale + 4, 0, 100);
			}
			live.scorers.push({
				minute: live.minute,
				name: p?.name ?? club.short,
				side
			});
			this.push(live, {
				minute: live.minute,
				kind: "goal",
				side,
				playerId: p?.id,
				playerName: p?.name,
				text: `${live.minute}' GOL! ${p?.name ?? club.name} ağları havalandırdı. ${this.scoreLine(state, live)}`
			});
		} else this.push(live, {
			minute: live.minute,
			kind: "chance",
			side,
			playerId: p?.id,
			playerName: p?.name,
			text: `${live.minute}' ${p?.name ?? club.name} ${rng.pick(MISS)}`
		});
	}
	resolveFoul(state, live, rng) {
		const side = rng.chance(.5) ? "home" : "away";
		const p = this.onField(live, side).map((id) => state.players[id]).filter((x) => !!x && !x.inj);
		if (!p.length) return;
		const pl = rng.pick(p);
		const stats = side === "home" ? live.stats.home : live.stats.away;
		stats.fouls += 1;
		const already = pl.matchYellows > 0;
		if (rng.chance(already ? .22 : .08) || rng.chance(.035)) {
			const secondYellow = already && rng.chance(.55);
			const straightRed = !secondYellow && rng.chance(.18);
			if (straightRed || secondYellow) {
				pl.matchYellows = 0;
				pl.ban = straightRed ? 2 : 1;
				if (live.comp === "league") pl.yellows = 0;
				stats.reds += 1;
				this.sendOff(live, side, pl.id);
				this.push(live, {
					minute: live.minute,
					kind: "red",
					side,
					playerId: pl.id,
					playerName: pl.name,
					text: `${live.minute}' KIRMIZI! ${pl.name} ${secondYellow ? "ikinci sarıdan" : "doğrudan"} oyun dışı. ${straightRed ? "2" : "1"} maç ceza.`
				});
			} else {
				pl.matchYellows += 1;
				if (live.comp === "league") {
					pl.yellows += 1;
					if (pl.yellows >= 4) {
						pl.ban = Math.max(pl.ban, 1);
						pl.yellows = 0;
					}
				}
				stats.yellows += 1;
				this.push(live, {
					minute: live.minute,
					kind: "yellow",
					side,
					playerId: pl.id,
					playerName: pl.name,
					text: `${live.minute}' Sarı kart. ${pl.name} defterine yazıldı.${pl.ban ? " 4 sarı — 1 maç ceza." : ""}`
				});
			}
		}
	}
	sendOff(live, side, id) {
		const xi = this.onField(live, side);
		const i = xi.indexOf(id);
		if (i >= 0) xi.splice(i, 1);
	}
	resolveInjury(state, live, rng) {
		const userId = state.clubId;
		for (const side of ["home", "away"]) {
			const clubId = side === "home" ? live.homeId : live.awayId;
			state.clubs[clubId];
			const ids = this.onField(live, side).slice();
			for (const id of ids) {
				const p = state.players[id];
				if (!p) continue;
				const inj = this.injuries.rollDuringMatch(p, rng);
				if (!inj) continue;
				p.inj = inj;
				p.energy = Math.max(10, p.energy - 25);
				const bench = side === "home" ? live.homeBench : live.awayBench;
				const sub = bench.map((bid) => state.players[bid]).filter((x) => !!x && !x.inj && x.ban <= 0).sort((a, b) => b.ovr - a.ovr)[0];
				let extra = `${inj.label} (${inj.weeksLeft} hf).`;
				if (sub && live.subsUsed < 5) {
					const xi = this.onField(live, side);
					const idx = xi.indexOf(id);
					if (idx >= 0) xi[idx] = sub.id;
					const bi = bench.indexOf(sub.id);
					if (bi >= 0) bench.splice(bi, 1);
					if (clubId === userId) live.subsUsed += 1;
					extra += ` ${sub.name} oyuna giriyor.`;
				} else {
					this.sendOff(live, side, id);
					extra += " Yerine kimse giremedi.";
				}
				this.push(live, {
					minute: live.minute,
					kind: "injury",
					side,
					playerId: p.id,
					playerName: p.name,
					text: `${live.minute}' Sakatlık! ${p.name} yerde kaldı. ${extra}`
				});
				return;
			}
		}
	}
	drain(state, live) {
		for (const id of [...live.homeXI, ...live.awayXI]) {
			const p = state.players[id];
			if (p) p.energy = Math.max(12, p.energy - (p.age >= 33 ? .28 : .2));
		}
	}
	scoreLine(state, live) {
		const h = state.clubs[live.homeId].short;
		const a = state.clubs[live.awayId].short;
		return `${h} ${live.homeGoals}–${live.awayGoals} ${a}`;
	}
	startSecondHalf(live) {
		if (live.phase !== "ht") return;
		live.phase = "second";
		live.stoppage = 2 + Math.floor(Math.random() * 4);
		this.push(live, {
			minute: 45,
			kind: "text",
			text: "İkinci yarı başladı."
		});
	}
	sub(state, live, outId, inId) {
		if (live.phase === "ft") return "Maç bitti.";
		const userIsHome = live.homeId === state.clubId;
		const xi = userIsHome ? live.homeXI : live.awayXI;
		const bench = userIsHome ? live.homeBench : live.awayBench;
		if (live.subsUsed >= 5) return "Beş değişiklik hakkınız doldu.";
		const oi = xi.indexOf(outId);
		const ii = bench.indexOf(inId);
		if (oi < 0 || ii < 0) return "Geçersiz değişiklik.";
		const outP = state.players[outId];
		const inP = state.players[inId];
		if (!inP || inP.inj || inP.ban > 0) return "Oyuncu maça çıkamaz.";
		xi[oi] = inId;
		bench[ii] = outId;
		live.subsUsed += 1;
		this.push(live, {
			minute: live.minute,
			kind: "sub",
			side: userIsHome ? "home" : "away",
			text: `${live.minute}' Değişiklik: ${outP?.name} çıkıyor, ${inP.name} giriyor.`
		});
		return null;
	}
	finish(state, live, rng) {
		live.phase = "ft";
		this.push(live, {
			minute: live.minute,
			kind: "ft",
			text: `Maç bitti. ${this.scoreLine(state, live)}`
		});
		this.applyResult(state, live, rng, true);
	}
	applyResult(state, live, rng, userMatch) {
		const fx = state.fixtures.find((f) => f.id === live.fixtureId);
		if (fx) {
			fx.played = true;
			fx.homeGoals = live.homeGoals;
			fx.awayGoals = live.awayGoals;
		}
		const home = state.clubs[live.homeId];
		const away = state.clubs[live.awayId];
		this.table(home, away, live.homeGoals, live.awayGoals, live.comp);
		this.postPlayers(state, live, rng, "home", userMatch);
		this.postPlayers(state, live, rng, "away", userMatch);
		this.morale(home, away, live.homeGoals, live.awayGoals);
	}
	table(home, away, hg, ag, comp) {
		if (comp !== "league") return;
		home.pld += 1;
		away.pld += 1;
		home.gf += hg;
		home.ga += ag;
		away.gf += ag;
		away.ga += hg;
		if (hg > ag) {
			home.w += 1;
			home.pts += 3;
			away.l += 1;
		} else if (ag > hg) {
			away.w += 1;
			away.pts += 3;
			home.l += 1;
		} else {
			home.d += 1;
			away.d += 1;
			home.pts += 1;
			away.pts += 1;
		}
	}
	morale(home, away, hg, ag) {
		if (hg > ag) {
			home.morale = clamp(home.morale + 6, 20, 100);
			away.morale = clamp(away.morale - 5, 20, 100);
		} else if (ag > hg) {
			away.morale = clamp(away.morale + 6, 20, 100);
			home.morale = clamp(home.morale - 5, 20, 100);
		} else {
			home.morale = clamp(home.morale + 1, 20, 100);
			away.morale = clamp(away.morale + 1, 20, 100);
		}
	}
	postPlayers(state, live, rng, side, userMatch) {
		const ids = this.onField(live, side);
		const hg = live.homeGoals;
		const ag = live.awayGoals;
		const won = side === "home" && hg > ag || side === "away" && ag > hg;
		const draw = hg === ag;
		const matchPts = won ? 3 : draw ? 1 : 0;
		for (const id of ids) {
			const p = state.players[id];
			if (!p) continue;
			p.apps += 1;
			p.matchYellows = 0;
			const rating = clamp(6.2 + (won ? .6 : draw ? .2 : -.2) + rng.float(-.4, .8), 5.2, 9.4);
			p.ratingSum += rating;
			p.form = clamp(p.form + (won ? 3 : draw ? 0 : -2), 20, 100);
			p.morale = clamp(p.morale + (won ? 2 : draw ? 0 : -2), 20, 100);
			p.energy = clamp(p.energy - rng.int(8, 16), 12, 100);
			if (userMatch || p.clubId === state.clubId) applyXp(p, matchPts + rating / 8);
		}
	}
	simQuiet(state, fixtureId, rng) {
		const fx = state.fixtures.find((f) => f.id === fixtureId);
		if (!fx || fx.played) return;
		const home = state.clubs[fx.homeId];
		const away = state.clubs[fx.awayId];
		const hs = sideStrength(home, state.players, home.xi, away.tactics, true);
		const as = sideStrength(away, state.players, away.xi, home.tactics, false);
		const hg = this.poisson(rng, clamp(1.05 + (hs - as) / 28, .25, 3.6));
		const ag = this.poisson(rng, clamp(.9 + (as - hs) / 30, .2, 3.2));
		const live = {
			fixtureId,
			homeId: home.id,
			awayId: away.id,
			minute: 90,
			stoppage: 3,
			homeGoals: hg,
			awayGoals: ag,
			events: [],
			stats: {
				home: emptyStats(),
				away: emptyStats()
			},
			phase: "ft",
			homeXI: home.xi.slice(),
			awayXI: away.xi.slice(),
			homeBench: home.bench.slice(),
			awayBench: away.bench.slice(),
			subsUsed: 0,
			comp: fx.comp,
			round: fx.round,
			scorers: []
		};
		this.maybeQuietCards(state, live, rng);
		this.applyResult(state, live, rng, false);
	}
	maybeQuietCards(state, live, rng) {
		for (const id of [...live.homeXI, ...live.awayXI]) {
			const p = state.players[id];
			if (!p) continue;
			if (live.comp === "league" && rng.chance(.12)) {
				p.yellows += 1;
				if (p.yellows >= 4) {
					p.ban = Math.max(p.ban, 1);
					p.yellows = 0;
				}
			}
			if (rng.chance(.012)) p.ban = Math.max(p.ban, 2);
			const inj = this.injuries.rollDuringMatch(p, rng);
			if (inj) p.inj = inj;
		}
	}
	poisson(rng, lambda) {
		const L = Math.exp(-lambda);
		let k = 0;
		let p = 1;
		do {
			k += 1;
			p *= rng.next();
		} while (p > L && k < 10);
		return k - 1;
	}
};
var RNG = class {
	seed;
	constructor(seed) {
		this.seed = seed >>> 0 || 1;
	}
	next() {
		this.seed = Math.imul(1664525, this.seed) + 1013904223 >>> 0;
		return this.seed / 4294967296;
	}
	int(min, max) {
		return min + Math.floor(this.next() * (max - min + 1));
	}
	float(min, max) {
		return min + this.next() * (max - min);
	}
	pick(arr) {
		return arr[Math.floor(this.next() * arr.length)];
	}
	chance(p) {
		return this.next() < p;
	}
	shuffle(arr) {
		const a = arr.slice();
		for (let i = a.length - 1; i > 0; i--) {
			const j = Math.floor(this.next() * (i + 1));
			[a[i], a[j]] = [a[j], a[i]];
		}
		return a;
	}
};
var SAVE_KEY = "onbir-save-v1";
var SAVE_BACKUP_KEY = "onbir-save-v1-bak";
function persist(state) {
	try {
		const prev = localStorage.getItem(SAVE_KEY);
		if (prev) localStorage.setItem(SAVE_BACKUP_KEY, prev);
		localStorage.setItem(SAVE_KEY, JSON.stringify(state));
		return true;
	} catch {
		return false;
	}
}
function readSave() {
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed !== "object") return null;
		if (parsed.version !== 1) return migrate(parsed);
		return parsed;
	} catch {
		try {
			const bak = localStorage.getItem(SAVE_BACKUP_KEY);
			if (!bak) return null;
			return JSON.parse(bak);
		} catch {
			return null;
		}
	}
}
function clearSave() {
	try {
		localStorage.removeItem(SAVE_KEY);
	} catch {}
}
function migrate(s) {
	s.version = 1;
	return s;
}
function hasSave() {
	try {
		return !!localStorage.getItem(SAVE_KEY);
	} catch {
		return false;
	}
}
var TransferMarket = class {
	list(state) {
		const out = [];
		for (const p of Object.values(state.players)) {
			if (p.clubId === state.clubId) continue;
			const club = state.clubs[p.clubId];
			if (!club || club.npc) continue;
			if (p.listed || p.ovr >= 78 || p.age >= 32 || p.age <= 21) out.push(p);
		}
		return out.sort((a, b) => b.ovr - a.ovr);
	}
	bid(state, rng, playerId, amount, wage) {
		const p = state.players[playerId];
		if (!p) return {
			ok: false,
			message: "Oyuncu bulunamadı."
		};
		if (p.clubId === state.clubId) return {
			ok: false,
			message: "Kendi oyuncunuz."
		};
		const user = state.clubs[state.clubId];
		if (!state.transferOpen) return {
			ok: false,
			message: "Transfer dönemi kapalı."
		};
		if (amount > user.balance) return {
			ok: false,
			message: "Bütçe yetersiz."
		};
		const want = p.value * (p.ovr >= 82 || p.age < 23 && p.pot >= 84 ? 1.22 : 1);
		const wageOk = wage >= playerWage(p.ovr, p.age) * .9;
		const accept = amount >= want * .92 && wageOk && rng.chance(.72 + Math.min(.25, (amount - want) / Math.max(1, want)));
		const offer = {
			id: `t_${state.uid++}`,
			playerId,
			fromId: p.clubId,
			toId: state.clubId,
			amount,
			wage,
			status: accept ? "accepted" : "rejected"
		};
		state.transfers.unshift(offer);
		if (state.transfers.length > 40) state.transfers.length = 40;
		if (!accept) return {
			ok: false,
			message: amount < want * .8 ? `${p.name} için teklif çok düşük.` : "Kulüp teklifi reddetti."
		};
		user.balance -= amount;
		const from = state.clubs[p.clubId];
		if (from) from.balance += amount;
		p.clubId = user.id;
		p.wage = wage;
		p.listed = false;
		p.morale = Math.min(100, p.morale + 8);
		this.repairSquad(state, from?.id);
		this.repairSquad(state, user.id);
		return {
			ok: true,
			message: `${p.name} kadroya katıldı.`
		};
	}
	sell(state, rng, playerId) {
		const p = state.players[playerId];
		const user = state.clubs[state.clubId];
		if (!p || p.clubId !== user.id) return {
			ok: false,
			message: "Oyuncu sizde değil.",
			amount: 0
		};
		if (Object.values(state.players).filter((x) => x.clubId === user.id).length <= 18) return {
			ok: false,
			message: "Kadro 18'in altına inemez.",
			amount: 0
		};
		const amount = Math.round(p.value * rng.float(.78, 1.05));
		const buyers = Object.values(state.clubs).filter((c) => c.id !== user.id && !c.npc && c.league.endsWith("1"));
		const buyer = rng.pick(buyers);
		user.balance += amount;
		p.clubId = buyer.id;
		p.listed = false;
		this.repairSquad(state, user.id);
		this.repairSquad(state, buyer.id);
		return {
			ok: true,
			message: `${p.name} ${buyer.name} takımına gitti.`,
			amount
		};
	}
	listPlayer(state, playerId, price) {
		const p = state.players[playerId];
		if (!p || p.clubId !== state.clubId) return;
		p.listed = true;
		p.askingPrice = price;
	}
	cpuWindow(state, rng) {
		const listed = Object.values(state.players).filter((p) => p.listed && p.clubId === state.clubId);
		for (const p of listed) {
			if (!rng.chance(.28)) continue;
			const offer = Math.round((p.askingPrice || p.value) * rng.float(.9, 1.08));
			const user = state.clubs[state.clubId];
			const buyers = Object.values(state.clubs).filter((c) => c.id !== user.id && !c.npc);
			if (!buyers.length) continue;
			const buyer = rng.pick(buyers);
			user.balance += offer;
			p.clubId = buyer.id;
			p.listed = false;
			state.news.unshift({
				id: `n_${state.uid++}`,
				week: state.week,
				title: "Satış tamam",
				body: `${p.name} ${buyer.name} kulübüne ${offer.toLocaleString("tr-TR")} € bedelle transfer oldu.`,
				tone: "good"
			});
			this.repairSquad(state, user.id);
		}
	}
	repairSquad(state, clubId) {
		if (!clubId) return;
		const club = state.clubs[clubId];
		if (!club) return;
		const pick = autoPickXI(Object.values(state.players).filter((p) => p.clubId === clubId), club.tactics.formation);
		club.xi = pick.xi;
		club.bench = pick.bench;
	}
};
var UEFARankingSystem = class {
	ranked(countries) {
		return countries.slice().sort((a, b) => this.total(b) - this.total(a) || b.seasonPts - a.seasonPts);
	}
	total(c) {
		return c.fiveYear.reduce((s, x) => s + x, 0);
	}
	seasonCoeff(c) {
		if (c.seasonMatches <= 0) return 0;
		return c.seasonPts / c.seasonMatches;
	}
	band(rank) {
		if (rank <= 4) return "top4";
		if (rank <= 6) return "mid";
		if (rank <= 10) return "seven";
		return "low";
	}
	quota(rank) {
		const b = this.band(rank);
		if (b === "top4") return {
			uclD: 4,
			uclQ: 0,
			uel: 2,
			uecl: 1
		};
		if (b === "mid") return {
			uclD: 2,
			uclQ: 1,
			uel: 2,
			uecl: 1
		};
		if (b === "seven") return {
			uclD: 0,
			uclQ: 2,
			uel: 1,
			uecl: 2
		};
		return {
			uclD: 0,
			uclQ: 1,
			uel: 1,
			uecl: 2
		};
	}
	addResult(countries, country, pts, matches = 1) {
		const c = countries.find((x) => x.code === country);
		if (!c) return;
		c.seasonPts += pts;
		c.seasonMatches += matches;
	}
	rollYear(countries) {
		for (const c of countries) {
			const sc = Number(this.seasonCoeff(c).toFixed(3));
			c.fiveYear = [...c.fiveYear.slice(1), sc];
			c.seasonPts = 0;
			c.seasonMatches = 0;
		}
	}
};
function groupTable(group, fixtures, clubs) {
	const rows = group.clubIds.map((id) => ({
		id,
		name: clubs[id]?.name ?? id,
		pld: 0,
		w: 0,
		d: 0,
		l: 0,
		gf: 0,
		ga: 0,
		pts: 0
	}));
	const map = new Map(rows.map((r) => [r.id, r]));
	for (const f of fixtures) {
		if (!f.played || f.comp !== group.comp || f.group !== group.name) continue;
		if (f.homeGoals == null || f.awayGoals == null) continue;
		const h = map.get(f.homeId);
		const a = map.get(f.awayId);
		if (!h || !a) continue;
		h.pld += 1;
		a.pld += 1;
		h.gf += f.homeGoals;
		h.ga += f.awayGoals;
		a.gf += f.awayGoals;
		a.ga += f.homeGoals;
		if (f.homeGoals > f.awayGoals) {
			h.w += 1;
			h.pts += 3;
			a.l += 1;
		} else if (f.awayGoals > f.homeGoals) {
			a.w += 1;
			a.pts += 3;
			h.l += 1;
		} else {
			h.d += 1;
			a.d += 1;
			h.pts += 1;
			a.pts += 1;
		}
	}
	return rows.sort((a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga) || b.gf - a.gf);
}
var UPGRADE_COST = [
	0,
	0,
	2e6,
	55e5,
	13e6,
	28e6
];
function slugId(short, used) {
	const base = "c_" + short.toLowerCase().replace(/[^a-z0-9]/g, "");
	let id = base;
	let n = 2;
	while (used.has(id)) {
		id = `${base}${n}`;
		n += 1;
	}
	used.add(id);
	return id;
}
function capFromRep(rep) {
	return Math.round((16e3 + (rep - 48) * 1100) / 500) * 500;
}
function roundRobin(ids) {
	const teams = ids.slice();
	if (teams.length % 2 === 1) teams.push("BYE");
	const n = teams.length;
	const rounds = n - 1;
	const half = n / 2;
	const days = [];
	const arr = teams.slice();
	for (let r = 0; r < rounds; r++) {
		const pairs = [];
		for (let i = 0; i < half; i++) {
			const t1 = arr[i];
			const t2 = arr[n - 1 - i];
			if (t1 !== "BYE" && t2 !== "BYE") pairs.push(r % 2 === 0 ? [t1, t2] : [t2, t1]);
		}
		days.push(pairs);
		const last = arr.pop();
		arr.splice(1, 0, last);
	}
	const second = days.map((day) => day.map(([h, a]) => [a, h]));
	return days.concat(second);
}
function objectiveFor(club) {
	if (club.league === "TUR2") return "promote";
	if (club.rep >= 88) return "title";
	if (club.rep >= 82) return "top4";
	if (club.rep >= 74) return "europe";
	if (club.rep >= 64) return "mid";
	return "survive";
}
var Game = class Game {
	state;
	rng;
	match = new MatchEngine();
	injuries = new InjuryManager();
	uefa = new UEFARankingSystem();
	market = new TransferMarket();
	academy = new YouthAcademy();
	constructor(state) {
		this.state = state;
		this.rng = new RNG(state.seed);
	}
	static fromSave() {
		const s = readSave();
		if (!s) return null;
		return new Game(s);
	}
	static newCareer(clubName, manager) {
		return Game.build({
			clubName,
			manager
		});
	}
	static createClub(input) {
		return Game.build({
			created: input,
			manager: input.manager
		});
	}
	static build(opts) {
		const rng = new RNG((Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0);
		let uid = 1;
		const nextId = () => `p_${uid++}`;
		const used = /* @__PURE__ */ new Set();
		const clubs = {};
		const players = {};
		const makeClub = (name, short, league, country, rep, colors, stadium, npc) => {
			const id = slugId(short, used);
			const club = {
				id,
				name,
				short,
				league,
				country,
				rep,
				colors,
				stadium,
				cap: capFromRep(rep),
				balance: Math.round(rep * (npc ? .4 : league === "TUR2" ? .28 : 1.05) * 1e6),
				tactics: { ...DEFAULT_TACTICS },
				xi: [],
				bench: [],
				morale: rng.int(58, 78),
				pts: 0,
				pld: 0,
				w: 0,
				d: 0,
				l: 0,
				gf: 0,
				ga: 0,
				medical: league.startsWith("TUR") ? 2 : 3,
				academy: Math.max(1, Math.round((rep - 50) / 12)),
				training: Math.max(1, Math.round((rep - 48) / 14)),
				sponsorId: rep >= 88 ? "tech" : rep >= 80 ? "airline" : rep >= 70 ? "bank" : "local",
				european: null,
				europeSeed: 0,
				npc
			};
			clubs[id] = club;
			const squad = generateSquad(rng, id, country, rep, nextId);
			for (const p of squad) players[p.id] = p;
			const pick = autoPickXI(squad, club.tactics.formation);
			club.xi = pick.xi;
			club.bench = pick.bench;
			return club;
		};
		for (const league of LEAGUES) for (const raw of CLUB_RAW[league.id] ?? []) makeClub(raw[0], raw[1], league.id, league.country, raw[3], [raw[4], raw[5]], raw[2], false);
		for (const n of NPC_CLUBS) makeClub(n[0], n[1], `NPC_${n[2]}`, n[2], n[4], [n[5], n[6]], n[3], true);
		let userId = "";
		if (opts.clubName) userId = Object.values(clubs).find((c) => c.name === opts.clubName)?.id ?? "";
		if (opts.created) {
			const weakest = Object.values(clubs).filter((c) => c.league === "TUR2").sort((a, b) => a.rep - b.rep)[0];
			if (weakest) {
				weakest.name = opts.created.name;
				weakest.short = opts.created.short.slice(0, 4).toUpperCase();
				weakest.stadium = opts.created.stadium;
				weakest.colors = [opts.created.primary, opts.created.secondary];
				weakest.balance = opts.created.budget;
				weakest.rep = 52;
				weakest.medical = 1;
				weakest.academy = 1;
				weakest.training = 1;
				weakest.sponsorId = "local";
				weakest.cap = 12e3;
				userId = weakest.id;
			}
		}
		if (!userId) userId = Object.values(clubs).find((c) => c.name === "Galatasaray")?.id ?? Object.values(clubs)[0].id;
		const countries = COUNTRY_SEED.map(([code, name, five]) => ({
			code,
			name,
			fiveYear: five.slice(),
			seasonPts: 0,
			seasonMatches: 0
		}));
		const state = {
			version: 1,
			season: 2026,
			week: 1,
			maxWeek: 42,
			manager: opts.manager || "Teknik Direktör",
			clubId: userId,
			created: !!opts.created,
			board: 64,
			objective: "mid",
			sacked: false,
			clubs,
			players,
			fixtures: [],
			live: null,
			transfers: [],
			news: [],
			countries,
			groups: [],
			uid,
			seed: rng.seed,
			transferOpen: true,
			seasonOver: false,
			inboxCount: 0
		};
		const game = new Game(state);
		const user = game.user();
		game.state.board = user.rep >= 84 ? 58 : 70;
		game.state.objective = objectiveFor(user);
		game.buildSeason();
		game.pushNews("Sezon açıldı", `${user.name} teknik direktörlüğüne hoş geldiniz. Hedef: ${game.objectiveText()}.`, "neutral");
		game.save();
		return game;
	}
	user() {
		return this.state.clubs[this.state.clubId];
	}
	userPlayers() {
		return Object.values(this.state.players).filter((p) => p.clubId === this.state.clubId).sort((a, b) => b.ovr - a.ovr);
	}
	save() {
		this.state.seed = this.rng.seed;
		persist(this.state);
	}
	pushNews(title, body, tone) {
		this.state.news.unshift({
			id: `n_${this.state.uid++}`,
			week: this.state.week,
			title,
			body,
			tone
		});
		if (this.state.news.length > 50) this.state.news.length = 50;
		this.state.inboxCount += 1;
	}
	objectiveText() {
		return {
			title: "Şampiyonluk",
			top4: "İlk 4",
			europe: "Avrupa kupası",
			mid: "Lig ortası",
			survive: "Kümede kalmak",
			promote: "Süper Lig'e çıkmak"
		}[this.state.objective] ?? "";
	}
	leagueTable(leagueId) {
		return Object.values(this.state.clubs).filter((c) => c.league === leagueId).sort((a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga) || b.gf - a.gf);
	}
	nextUserFixture() {
		return this.state.fixtures.filter((f) => !f.played && (f.homeId === this.state.clubId || f.awayId === this.state.clubId)).sort((a, b) => a.week - b.week || a.id.localeCompare(b.id))[0];
	}
	weekFixtures(week = this.state.week) {
		return this.state.fixtures.filter((f) => f.week === week);
	}
	setTactics(t) {
		const club = this.user();
		club.tactics = {
			...club.tactics,
			...t
		};
		if (t.formation) {
			const pick = autoPickXI(this.userPlayers(), t.formation);
			club.xi = pick.xi;
			club.bench = pick.bench;
		}
		this.syncLiveTactics();
		this.save();
	}
	syncLiveTactics() {
		const live = this.state.live;
		if (!live || live.phase === "ft") return;
		if (live.homeId === this.state.clubId) live.homeXI = this.user().xi.slice();
		else live.awayXI = this.user().xi.slice();
	}
	setSlot(index, playerId) {
		const club = this.user();
		const p = this.state.players[playerId];
		if (!p || p.clubId !== club.id) return;
		if (p.inj || p.ban > 0) return;
		const cur = club.xi[index];
		const inXi = club.xi.indexOf(playerId);
		const inBench = club.bench.indexOf(playerId);
		if (inXi >= 0) {
			club.xi[inXi] = cur ?? playerId;
			club.xi[index] = playerId;
		} else {
			club.xi[index] = playerId;
			if (inBench >= 0) {
				if (cur) club.bench[inBench] = cur;
				else club.bench.splice(inBench, 1);
			} else if (cur) {
				club.bench.unshift(cur);
				if (club.bench.length > 7) club.bench.length = 7;
			}
		}
		this.save();
	}
	swap(aId, bId) {
		const club = this.user();
		const ia = club.xi.indexOf(aId);
		const ib = club.xi.indexOf(bId);
		const ba = club.bench.indexOf(aId);
		const bb = club.bench.indexOf(bId);
		if (ia >= 0 && ib >= 0) {
			club.xi[ia] = bId;
			club.xi[ib] = aId;
		} else if (ia >= 0 && bb >= 0) {
			club.xi[ia] = bId;
			club.bench[bb] = aId;
		} else if (ib >= 0 && ba >= 0) {
			club.xi[ib] = aId;
			club.bench[ba] = bId;
		}
		this.save();
	}
	startMatch(fixtureId) {
		const fx = fixtureId ? this.state.fixtures.find((f) => f.id === fixtureId) : this.nextUserFixture();
		if (!fx) return "Oynanacak maç yok.";
		if (fx.played) return "Bu maç oynandı.";
		if (fx.week > this.state.week) return "Bu maç henüz gelmedi.";
		const user = this.user();
		const pick = autoPickXI(this.userPlayers(), user.tactics.formation);
		if (user.xi.length < 11) {
			user.xi = pick.xi;
			user.bench = pick.bench;
		}
		user.xi = user.xi.filter((id) => {
			const p = this.state.players[id];
			return p && !p.inj && p.ban <= 0;
		});
		if (user.xi.length < 11) {
			const filled = autoPickXI(this.userPlayers(), user.tactics.formation);
			user.xi = filled.xi;
			user.bench = filled.bench;
		}
		if (user.xi.length < 8) return "Yeterli sağlıklı oyuncu yok.";
		this.state.live = this.match.createLive(this.state, fx.id, this.rng);
		this.save();
		return null;
	}
	stepMinute() {
		const live = this.state.live;
		if (!live) return;
		this.match.stepMinute(this.state, live, this.rng);
		if (live.phase === "ft") this.onFullTime();
		this.save();
	}
	continueSecondHalf() {
		const live = this.state.live;
		if (!live) return;
		this.match.startSecondHalf(live);
		this.save();
	}
	skipMatch() {
		if (!this.state.live) {
			const err = this.startMatch();
			if (err) return err;
		}
		const l = this.state.live;
		let guard = 0;
		while (l.phase !== "ft" && guard++ < 200) {
			if (l.phase === "ht") this.match.startSecondHalf(l);
			this.match.stepMinute(this.state, l, this.rng);
		}
		this.onFullTime();
		this.save();
		return null;
	}
	sub(outId, inId) {
		const live = this.state.live;
		if (!live) return "Maç yok.";
		const err = this.match.sub(this.state, live, outId, inId);
		this.save();
		return err;
	}
	onFullTime() {
		const live = this.state.live;
		if (!live) return;
		const user = this.user();
		const hg = live.homeGoals;
		const ag = live.awayGoals;
		const userHome = live.homeId === user.id;
		const userGoals = userHome ? hg : ag;
		const oppGoals = userHome ? ag : hg;
		const won = userGoals > oppGoals;
		const draw = userGoals === oppGoals;
		const gdFav = user.rep - (this.state.clubs[userHome ? live.awayId : live.homeId]?.rep ?? 70);
		if (won) this.state.board = clamp(this.state.board + (gdFav < -8 ? 8 : 4), 0, 100);
		else if (draw) this.state.board = clamp(this.state.board + (gdFav > 10 ? -3 : 1), 0, 100);
		else this.state.board = clamp(this.state.board - (gdFav > 8 ? 9 : 5), 0, 100);
		const sponsor = SPONSORS.find((s) => s.id === user.sponsorId);
		if (won && sponsor) user.balance += sponsor.winBonus;
		const gate = Math.round(user.cap * .72 * (18 + user.rep / 8));
		user.balance += gate;
		this.addEuropePoints(live);
		if (this.state.board < 12) {
			this.state.sacked = true;
			this.pushNews("Görevine son", "Yönetim kurulu güvenoyunu geri çekti.", "bad");
		}
	}
	addEuropePoints(live) {
		if (live.comp === "league") return;
		const home = this.state.clubs[live.homeId];
		const away = this.state.clubs[live.awayId];
		const resultPts = (g, o) => g > o ? 2 : g === o ? 1 : 0;
		this.uefa.addResult(this.state.countries, home.country, resultPts(live.homeGoals, live.awayGoals), 1);
		this.uefa.addResult(this.state.countries, away.country, resultPts(live.awayGoals, live.homeGoals), 1);
	}
	creditEurope(f) {
		if (f.comp === "league" || !f.played || f.homeGoals == null || f.awayGoals == null) return;
		this.addEuropePoints({
			comp: f.comp,
			homeId: f.homeId,
			awayId: f.awayId,
			homeGoals: f.homeGoals,
			awayGoals: f.awayGoals
		});
	}
	closeMatchAndAdvance() {
		this.state.live = null;
		this.resolveWeekIfDone();
		this.save();
	}
	resolveWeekIfDone() {
		if (this.state.fixtures.filter((f) => f.week === this.state.week && !f.played && (f.homeId === this.state.clubId || f.awayId === this.state.clubId)).length) return;
		for (const f of this.state.fixtures) if (f.week === this.state.week && !f.played) {
			this.match.simQuiet(this.state, f.id, this.rng);
			const done = this.state.fixtures.find((x) => x.id === f.id);
			if (done) this.creditEurope(done);
		}
		this.tickWeek();
	}
	simRestOfWeek() {
		for (const f of this.state.fixtures) {
			if (f.week !== this.state.week || f.played) continue;
			if (f.homeId === this.state.clubId || f.awayId === this.state.clubId) {
				const live = this.match.createLive(this.state, f.id, this.rng);
				this.state.live = live;
				this.skipMatch();
				this.state.live = null;
			} else {
				this.match.simQuiet(this.state, f.id, this.rng);
				const done = this.state.fixtures.find((x) => x.id === f.id);
				if (done) this.creditEurope(done);
			}
		}
		this.tickWeek();
		this.save();
	}
	tickWeek() {
		const user = this.user();
		const squad = this.userPlayers();
		const rec = this.injuries.tickWeek(squad, user.medical);
		for (const p of rec) this.pushNews("Revir", `${p.name} antrenmanlara döndü.`, "good");
		for (const p of Object.values(this.state.players)) {
			if (p.ban > 0) p.ban -= 1;
			const recov = 9 + (this.state.clubs[p.clubId]?.training ?? 1) * 2 + 6;
			p.energy = clamp(p.energy + recov, 12, 100);
		}
		user.balance -= squad.reduce((s, p) => s + p.wage, 0);
		const sp = SPONSORS.find((s) => s.id === user.sponsorId);
		if (sp) user.balance += sp.weekly;
		user.balance += Math.round(user.rep * 4e3);
		if (this.state.transferOpen) this.market.cpuWindow(this.state, this.rng);
		this.maybeKnockoutDraw();
		this.advanceKnockouts();
		this.state.week += 1;
		this.state.transferOpen = this.state.week <= 4 || this.state.week >= 20 && this.state.week <= 23;
		if (this.state.week > this.state.maxWeek) this.endSeason();
		else {
			const next = this.nextUserFixture();
			if (next) {
				const opp = this.state.clubs[next.homeId === user.id ? next.awayId : next.homeId];
				this.pushNews("Sıradaki maç", `${next.round}: ${opp?.name ?? "Rakip"}`, "neutral");
			}
		}
	}
	maybeKnockoutDraw() {
		if (this.state.week !== 12) return;
		for (const comp of [
			"UCL",
			"UEL",
			"UECL"
		]) {
			const groups = this.state.groups.filter((g) => g.comp === comp);
			const first = [];
			const second = [];
			for (const g of groups) {
				const t = groupTable(g, this.state.fixtures, this.state.clubs);
				if (t[0]) first.push(t[0].id);
				if (t[1]) second.push(t[1].id);
			}
			const r16 = comp === "UCL" ? [...first, ...second] : comp === "UEL" ? [...first, ...this.thirdOf("UCL")] : [...first, ...this.thirdOf("UEL")];
			const unique = [...new Set(r16)].slice(0, 16);
			while (unique.length < 16 && second.length) unique.push(second.pop());
			const shuffled = this.rng.shuffle(unique);
			for (let i = 0; i < 8; i++) {
				const a = shuffled[i * 2];
				const b = shuffled[i * 2 + 1];
				if (!a || !b) continue;
				this.state.fixtures.push({
					id: `fx_${this.state.uid++}`,
					week: 16,
					comp,
					round: "Son 16",
					homeId: a,
					awayId: b,
					homeGoals: null,
					awayGoals: null,
					played: false
				});
			}
			this.pushNews(`${comp} kuraları`, "Gruplar bitti. 3. olanlar alt kupa R16'ya düştü.", "neutral");
		}
	}
	thirdOf(comp) {
		const groups = this.state.groups.filter((g) => g.comp === comp);
		const third = [];
		for (const g of groups) {
			const t = groupTable(g, this.state.fixtures, this.state.clubs);
			if (t[2]) third.push(t[2].id);
		}
		return third;
	}
	advanceKnockouts() {
		const rounds = [
			{
				from: "Son 16",
				to: "Çeyrek final",
				week: 20
			},
			{
				from: "Çeyrek final",
				to: "Yarı final",
				week: 24
			},
			{
				from: "Yarı final",
				to: "Final",
				week: 28
			}
		];
		for (const comp of [
			"UCL",
			"UEL",
			"UECL"
		]) for (const r of rounds) {
			const played = this.state.fixtures.filter((f) => f.comp === comp && f.round === r.from && f.played);
			if (this.state.fixtures.some((f) => f.comp === comp && f.round === r.to) || played.length < 2) continue;
			if (played.some((f) => f.week >= this.state.week)) continue;
			const winners = played.map((f) => {
				if ((f.homeGoals ?? 0) > (f.awayGoals ?? 0)) return f.homeId;
				if ((f.awayGoals ?? 0) > (f.homeGoals ?? 0)) return f.awayId;
				return this.rng.chance(.5) ? f.homeId : f.awayId;
			}).filter(Boolean);
			if (winners.length < 2) continue;
			if (winners.length % 2 === 1) winners.pop();
			for (let i = 0; i < winners.length; i += 2) this.state.fixtures.push({
				id: `fx_${this.state.uid++}`,
				week: r.week,
				comp,
				round: r.to,
				homeId: winners[i],
				awayId: winners[i + 1],
				homeGoals: null,
				awayGoals: null,
				played: false
			});
		}
	}
	bid(playerId, amount, wage) {
		const r = this.market.bid(this.state, this.rng, playerId, amount, wage);
		if (r.ok) this.pushNews("Transfer", r.message, "good");
		this.save();
		return r;
	}
	sell(playerId) {
		const r = this.market.sell(this.state, this.rng, playerId);
		if (r.ok) this.pushNews("Satış", r.message, "neutral");
		this.save();
		return r;
	}
	listPlayer(id, price) {
		this.market.listPlayer(this.state, id, price);
		this.save();
	}
	upgrade(kind) {
		const c = this.user();
		if (kind === "stadium") {
			const cost = Math.round(c.cap * 420);
			if (c.balance < cost) return "Bütçe yetersiz.";
			c.balance -= cost;
			c.cap += 4e3;
			this.pushNews("Tesis", `Stadyum kapasitesi ${c.cap.toLocaleString("tr-TR")} oldu.`, "good");
			this.save();
			return null;
		}
		const lvl = c[kind];
		if (lvl >= 5) return "Maksimum seviye.";
		const cost = UPGRADE_COST[lvl + 1] ?? 3e7;
		if (c.balance < cost) return "Bütçe yetersiz.";
		c.balance -= cost;
		c[kind] = lvl + 1;
		this.pushNews("Tesis", `${kind} seviyesi ${c[kind]} oldu.`, "good");
		this.save();
		return null;
	}
	setSponsor(id) {
		if (!SPONSORS.find((s) => s.id === id)) return "Sponsor yok.";
		const c = this.user();
		const need = {
			none: 0,
			local: 0,
			bank: 68,
			airline: 76,
			tech: 86
		}[id] ?? 0;
		if (c.rep < need && id !== "local" && id !== "none") return "İtibar yetersiz.";
		c.sponsorId = id;
		this.save();
		return null;
	}
	buildSeason() {
		this.state.fixtures = [];
		this.state.groups = [];
		for (const c of Object.values(this.state.clubs)) {
			if (c.npc) continue;
			c.pts = c.pld = c.w = c.d = c.l = c.gf = c.ga = 0;
			c.european = null;
		}
		for (const league of LEAGUES) roundRobin(Object.values(this.state.clubs).filter((c) => c.league === league.id).map((c) => c.id)).forEach((pairs, i) => {
			const week = Math.min(1 + i, 38);
			for (const [h, a] of pairs) this.state.fixtures.push({
				id: `fx_${this.state.uid++}`,
				week,
				comp: "league",
				round: `${week}. Hafta`,
				homeId: h,
				awayId: a,
				homeGoals: null,
				awayGoals: null,
				played: false
			});
		});
		this.seedEurope();
		this.state.maxWeek = 42;
	}
	seedEurope() {
		const ranked = this.uefa.ranked(this.state.countries);
		const taken = /* @__PURE__ */ new Set();
		const ucl = [];
		const uel = [];
		const uecl = [];
		const domestic = (code) => Object.values(this.state.clubs).filter((c) => c.country === code && !c.npc && c.league.endsWith("1")).sort((a, b) => b.rep - a.rep);
		const npcOf = (code) => Object.values(this.state.clubs).filter((c) => c.country === code && c.npc).sort((a, b) => b.rep - a.rep);
		ranked.forEach((country, idx) => {
			const q = this.uefa.quota(idx + 1);
			const pool = [...domestic(country.code), ...npcOf(country.code)].filter((c) => !taken.has(c.id));
			const take = (n, bucket, comp) => {
				let k = 0;
				for (const c of pool) {
					if (k >= n) break;
					if (taken.has(c.id)) continue;
					taken.add(c.id);
					bucket.push(c.id);
					c.european = comp;
					k += 1;
				}
			};
			take(q.uclD + q.uclQ, ucl, "UCL");
			take(q.uel, uel, "UEL");
			take(q.uecl, uecl, "UECL");
		});
		const fill = (bucket, comp, n) => {
			const extras = Object.values(this.state.clubs).filter((c) => !taken.has(c.id) && (c.npc || c.league.endsWith("1"))).sort((a, b) => b.rep - a.rep);
			for (const c of extras) {
				if (bucket.length >= n) break;
				taken.add(c.id);
				bucket.push(c.id);
				c.european = comp;
			}
		};
		fill(ucl, "UCL", 32);
		fill(uel, "UEL", 32);
		fill(uecl, "UECL", 32);
		this.makeGroups("UCL", ucl.slice(0, 32), [
			6,
			7,
			8,
			9,
			10,
			11
		]);
		this.makeGroups("UEL", uel.slice(0, 32), [
			6,
			7,
			8,
			9,
			10,
			11
		]);
		this.makeGroups("UECL", uecl.slice(0, 32), [
			6,
			7,
			8,
			9,
			10,
			11
		]);
	}
	makeGroups(comp, ids, weeks) {
		const seeded = ids.map((id) => this.state.clubs[id]).filter(Boolean).sort((a, b) => b.rep - a.rep);
		const groups = Array.from({ length: 8 }, () => []);
		seeded.forEach((c, i) => {
			const g = i % 8;
			groups[g].push(c.id);
			c.europeSeed = i + 1;
		});
		const names = "ABCDEFGH";
		groups.forEach((clubIds, gi) => {
			const name = names[gi];
			this.state.groups.push({
				comp,
				name,
				clubIds
			});
			roundRobin(clubIds).slice(0, 6).forEach((pairs, di) => {
				const week = weeks[di] ?? 11;
				for (const [h, a] of pairs) this.state.fixtures.push({
					id: `fx_${this.state.uid++}`,
					week,
					comp,
					round: `Grup ${name}`,
					homeId: h,
					awayId: a,
					homeGoals: null,
					awayGoals: null,
					played: false,
					group: name
				});
			});
		});
	}
	endSeason() {
		const user = this.user();
		const table = this.leagueTable(user.league);
		const pos = table.findIndex((c) => c.id === user.id) + 1;
		let ok = false;
		switch (this.state.objective) {
			case "title":
				ok = pos === 1;
				break;
			case "top4":
				ok = pos <= 4;
				break;
			case "europe":
				ok = pos <= 7;
				break;
			case "mid":
				ok = pos <= 12;
				break;
			case "survive":
				ok = pos <= table.length - 3;
				break;
			case "promote": ok = pos <= 3;
		}
		this.state.board = clamp(this.state.board + (ok ? 12 : -22), 0, 100);
		this.pushNews("Sezon bitti", `${user.name} ligi ${pos}. sırada bitirdi. Hedef ${ok ? "tutturuldu" : "tutturulamadı"}.`, ok ? "good" : "bad");
		if (this.state.board < 18) {
			this.state.sacked = true;
			this.pushNews("Kovuldunuz", "Yönetim yeni bir isimle devam edecek.", "bad");
		}
		this.promoteRelegate();
		for (const p of Object.values(this.state.players)) seasonDecay(p, this.rng);
		const kids = this.academy.intake(this.state, this.rng, user);
		if (kids.length) this.pushNews("Akademi", kids.map((k) => `${k.name} (${k.pos} ${k.ovr}/${k.pot})`).join(", ") + " A takıma çıktı.", "good");
		this.uefa.rollYear(this.state.countries);
		this.state.season += 1;
		this.state.week = 1;
		this.state.seasonOver = false;
		this.state.objective = objectiveFor(user);
		const pick = autoPickXI(this.userPlayers(), user.tactics.formation);
		user.xi = pick.xi;
		user.bench = pick.bench;
		this.buildSeason();
		this.save();
	}
	promoteRelegate() {
		const tur1 = this.leagueTable("TUR1");
		const tur2 = this.leagueTable("TUR2");
		const down = tur1.slice(-3);
		const up = tur2.slice(0, 3);
		for (const c of down) c.league = "TUR2";
		for (const c of up) c.league = "TUR1";
		if (down.some((c) => c.id === this.state.clubId)) {
			this.pushNews("Küme düşme", "Süper Lig'e veda.", "bad");
			this.state.objective = "promote";
		}
		if (up.some((c) => c.id === this.state.clubId)) {
			this.pushNews("Tebrikler", "Süper Lig'e yükseldiniz.", "good");
			this.state.objective = "survive";
		}
	}
	takeJob(clubId) {
		const c = this.state.clubs[clubId];
		if (!c || c.npc) return;
		this.state.clubId = clubId;
		this.state.sacked = false;
		this.state.board = 62;
		this.state.objective = objectiveFor(c);
		const pick = autoPickXI(Object.values(this.state.players).filter((p) => p.clubId === clubId), c.tactics.formation);
		c.xi = pick.xi;
		c.bench = pick.bench;
		this.pushNews("Yeni görev", `${c.name} ile anlaştınız.`, "good");
		this.save();
	}
	availableJobs() {
		return Object.values(this.state.clubs).filter((c) => !c.npc && c.id !== this.state.clubId && c.rep < 88).sort((a, b) => b.rep - a.rep).slice(0, 8);
	}
};
var useGame = create((set, get) => ({
	ready: false,
	hasSave: false,
	game: null,
	screen: "match",
	tick: 0,
	selectedId: null,
	swapFrom: null,
	toast: null,
	speed: 1,
	bidPlayer: null,
	hydrate: () => {
		set({
			ready: true,
			hasSave: hasSave(),
			game: Game.fromSave()
		});
	},
	bump: () => set({
		tick: get().tick + 1,
		game: get().game
	}),
	flash: (msg) => {
		set({ toast: msg });
		window.setTimeout(() => {
			if (get().toast === msg) set({ toast: null });
		}, 2400);
	},
	startClub: (name, manager) => {
		set({
			game: Game.newCareer(name, manager),
			screen: "match",
			hasSave: true,
			tick: get().tick + 1
		});
	},
	createClub: (input) => {
		set({
			game: Game.createClub(input),
			screen: "match",
			hasSave: true,
			tick: get().tick + 1
		});
	},
	continueSave: () => {
		const game = Game.fromSave();
		if (game) set({
			game,
			screen: "match",
			hasSave: true
		});
	},
	newGame: () => {
		clearSave();
		set({
			game: null,
			hasSave: false,
			screen: "match"
		});
	},
	setScreen: (screen) => set({
		screen,
		selectedId: null,
		swapFrom: null
	}),
	setSelected: (selectedId) => set({ selectedId }),
	setSwapFrom: (swapFrom) => set({ swapFrom }),
	setSpeed: (speed) => set({ speed }),
	setBidPlayer: (bidPlayer) => set({ bidPlayer })
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Btn({ variant = "primary", className, ...props }) {
	const styles = {
		primary: "bg-accent text-accent-fg hover:brightness-110",
		ghost: "bg-transparent text-fg hover:bg-elevated",
		soft: "bg-elevated text-fg hover:bg-border/40 border border-border",
		danger: "bg-danger text-accent-fg hover:brightness-110",
		warn: "bg-warn text-bg hover:brightness-110"
	}[variant];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-sm px-3.5 text-sm font-medium transition-opacity duration-150 disabled:cursor-not-allowed disabled:opacity-40", styles, className),
		...props
	});
}
function Panel({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-lg border border-border bg-surface shadow-panel", className),
		children
	});
}
function Crest({ club, size = 36 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex shrink-0 items-center justify-center rounded-sm text-[10px] font-semibold tracking-wider",
		style: {
			width: size,
			height: size,
			background: club.colors[0],
			color: club.colors[1],
			boxShadow: `inset 0 0 0 2px ${club.colors[1]}`
		},
		children: club.short.slice(0, 3)
	});
}
function Ovr({ n }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("tabular inline-flex h-6 min-w-6 items-center justify-center rounded-xs px-1 text-[11px] font-semibold", n >= 86 ? "bg-ok text-accent-fg" : n >= 76 ? "bg-elevated text-fg" : "bg-bg text-muted"),
		children: n
	});
}
function StatusIcons({ p }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1",
		children: [
			p.inj ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
				className: "size-3.5 text-danger",
				"aria-label": "Sakat"
			}) : null,
			p.ban > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, {
				className: "size-3.5 text-card-red",
				"aria-label": "Cezalı"
			}) : null,
			p.yellows >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "size-2.5 rounded-[2px] bg-card-yellow",
				title: "Sarı kartlar"
			}) : null
		]
	});
}
function Meter({ value, tone = "accent" }) {
	const map = {
		accent: "bg-accent",
		ok: "bg-ok",
		warn: "bg-warn",
		danger: "bg-danger"
	};
	const bar = tone === "accent" ? map[value >= 70 ? "ok" : value >= 40 ? "warn" : "danger"] : map[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("h-full rounded-full", bar),
			style: { width: `${Math.max(0, Math.min(100, value))}%` }
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1.5 text-xs text-muted",
		children: [label, children]
	});
}
var inputClass = "min-h-11 rounded-sm border border-border bg-bg px-3 text-sm text-fg outline-none focus:border-accent";
var COST$1 = [
	0,
	0,
	2e6,
	55e5,
	13e6,
	28e6
];
function ClubView() {
	const game = useGame((s) => s.game);
	const bump = useGame((s) => s.bump);
	const flash = useGame((s) => s.flash);
	const newGame = useGame((s) => s.newGame);
	useGame((s) => s.tick);
	const user = game.user();
	const wages = game.userPlayers().reduce((s, p) => s + p.wage, 0);
	const sp = SPONSORS.find((s) => s.id === user.sponsorId);
	function up(kind) {
		const err = game.upgrade(kind);
		flash(err ?? "Tesis yükseltildi");
		bump();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-5xl gap-3 p-3 md:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
							club: user,
							size: 52
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: user.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								user.stadium,
								" · ",
								user.cap.toLocaleString("tr-TR"),
								" kapasite"
							]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-2 gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Kasa",
								v: money(user.balance)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Haftalık ücret",
								v: money(wages)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "İtibar",
								v: String(user.rep)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Hedef",
								v: objectiveLabel(game.state.objective)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "Yönetim güveni"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular",
									children: [game.state.board, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, { value: game.state.board }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[11px] text-muted",
								children: "%12’nin altına düşerseniz görevden alınabilirsiniz."
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: "Tesisler"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fac, {
						title: "Gençlik akademisi",
						lvl: user.academy,
						onUp: () => up("academy")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fac, {
						title: "Antrenman sahası",
						lvl: user.training,
						onUp: () => up("training")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center justify-between border-t border-border pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: "Stadyum"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [user.cap.toLocaleString("tr-TR"), " · +4000 koltuk"]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "soft",
							onClick: () => up("stadium"),
							children: money(Math.round(user.cap * 420))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: "Sponsorluk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-3 text-xs text-muted",
						children: [
							"Aktif: ",
							sp?.name,
							" · haftalık ",
							money(sp?.weekly ?? 0)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2",
						children: SPONSORS.filter((s) => s.id !== "none").map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm",
								children: [s.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-2 text-xs text-muted",
									children: [money(s.weekly), "/hf"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: user.sponsorId === s.id ? "primary" : "soft",
								className: "min-h-9 px-2 text-xs",
								onClick: () => {
									const err = game.setSponsor(s.id);
									flash(err ?? "Sponsor güncellendi");
									bump();
								},
								children: user.sponsorId === s.id ? "Aktif" : "Seç"
							})]
						}, s.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: "Haberler"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "max-h-56 space-y-2 overflow-auto",
						children: game.state.news.slice(0, 12).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-b border-border pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: n.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: n.body
							})]
						}, n.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						className: "mt-4 w-full",
						onClick: newGame,
						children: "Yeni kariyer"
					})
				]
			})
		]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-[11px] uppercase tracking-wide text-muted",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "tabular font-medium",
		children: v
	})] });
}
function Fac({ title, lvl, onUp }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted",
			children: [
				"Seviye ",
				lvl,
				"/5"
			]
		})] }), lvl < 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			variant: "soft",
			className: "min-h-9 text-xs",
			onClick: onUp,
			children: money(COST$1[lvl + 1] ?? 0)
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-ok",
			children: "Max"
		})]
	});
}
function EuropeView() {
	const game = useGame((s) => s.game);
	useGame((s) => s.tick);
	const [tab, setTab] = (0, import_react.useState)("rank");
	const user = game.user();
	const ranked = game.uefa.ranked(game.state.countries);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col gap-3 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: [
					["rank", "Ülke puanı"],
					["table", "Lig"],
					["fix", "Fikstür"],
					["UCL", "UCL"],
					["UEL", "UEL"],
					["UECL", "UECL"]
				].map(([id, lab]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(id),
					className: cn("rounded-sm px-3 py-2 text-xs font-medium", tab === id ? "bg-accent text-accent-fg" : "bg-elevated text-muted"),
					children: lab
				}, id))
			}),
			tab === "rank" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "min-h-0 flex-1 overflow-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "sticky top-0 bg-surface text-[11px] uppercase tracking-wide text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "#"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Ülke" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "5 yıl" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Sezon" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Kontenjan" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: ranked.map((c, i) => {
						const q = game.uefa.quota(i + 1);
						const total = game.uefa.total(c);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: cn("border-t border-border", c.code === user.country && "bg-elevated"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-2",
									children: i + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: c.name }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular",
									children: total.toFixed(1)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular",
									children: c.seasonMatches ? (c.seasonPts / c.seasonMatches).toFixed(2) : "0.00"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "pr-3 text-xs text-muted",
									children: [
										q.uclD,
										"+",
										q.uclQ,
										" UCL · ",
										q.uel,
										" UEL · ",
										q.uecl,
										" UECL"
									]
								})
							]
						}, c.code);
					}) })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-3 text-[11px] text-muted",
					children: "1–4: 4 UCL direkt. 5–6: 3 UCL (2 direkt, 1 ön eleme). 7–10: 2 UCL ön elemeli, 1 UEL, 2 UECL. Grup 3.leri alt kupaya düşer."
				})]
			}) : null,
			tab === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "min-h-0 flex-1 overflow-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "px-3 py-2 text-sm font-semibold",
					children: leagueName(user.league)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
					clubs: game.leagueTable(user.league),
					userId: user.id
				})]
			}) : null,
			tab === "fix" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				className: "min-h-0 flex-1 overflow-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: game.state.fixtures.filter((f) => f.homeId === user.id || f.awayId === user.id).slice(0, 24).map((f) => {
					const opp = game.state.clubs[f.homeId === user.id ? f.awayId : f.homeId];
					const home = f.homeId === user.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2 border-b border-border px-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-16 text-[11px] text-muted",
								children: f.round
							}),
							opp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
								club: opp,
								size: 24
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex-1 truncate",
								children: [
									home ? "vs" : "@",
									" ",
									opp?.name
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted",
								children: compLabel(f.comp)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular text-xs",
								children: f.played ? `${f.homeGoals}–${f.awayGoals}` : `Hf ${f.week}`
							})
						]
					}, f.id);
				}) })
			}) : null,
			tab === "UCL" || tab === "UEL" || tab === "UECL" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid min-h-0 flex-1 grid-cols-1 gap-2 overflow-auto md:grid-cols-2",
				children: game.state.groups.filter((g) => g.comp === tab).map((g) => {
					const rows = groupTable(g, game.state.fixtures, game.state.clubs);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: "p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "px-2 py-1 text-xs font-semibold",
							children: [
								compLabel(tab),
								" · Grup ",
								g.name
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							clubs: rows.map((r) => ({
								id: r.id,
								name: r.name,
								short: game.state.clubs[r.id]?.short ?? "",
								colors: game.state.clubs[r.id]?.colors ?? ["#333", "#fff"],
								pld: r.pld,
								w: r.w,
								d: r.d,
								l: r.l,
								gf: r.gf,
								ga: r.ga,
								pts: r.pts
							})),
							userId: user.id,
							dropThird: true
						})]
					}, g.comp + g.name);
				})
			}) : null
		]
	});
}
function Table({ clubs, userId, dropThird }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
		className: "w-full text-left text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
			className: "text-[10px] uppercase tracking-wide text-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "px-2 py-1",
					children: "#"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Takım" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "O" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Av" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "P" })
			] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: clubs.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: cn("border-t border-border", c.id === userId && "bg-elevated", dropThird && i === 2 && "text-warn", dropThird && i >= 3 && "text-faint"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "tabular px-2 py-1.5",
					children: i + 1
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					className: "flex items-center gap-2 py-1.5",
					children: [c.colors && c.short ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
						club: {
							short: c.short,
							colors: c.colors
						},
						size: 18
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: c.name
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "tabular",
					children: c.pld
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "tabular",
					children: c.gf - c.ga
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "tabular font-semibold",
					children: c.pts
				})
			]
		}, c.id)) })]
	});
}
function MatchView() {
	const game = useGame((s) => s.game);
	const bump = useGame((s) => s.bump);
	const speed = useGame((s) => s.speed);
	const setSpeed = useGame((s) => s.setSpeed);
	const flash = useGame((s) => s.flash);
	useGame((s) => s.tick);
	const live = game.state.live;
	const next = game.nextUserFixture();
	if (live) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Live, {
		speed,
		setSpeed,
		bump
	});
	if (!next) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col items-center justify-center gap-3 p-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Bu hafta sizin için maç yok."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			onClick: () => {
				game.simRestOfWeek();
				bump();
			},
			children: "Haftayı simüle et"
		})]
	});
	const user = game.user();
	const home = game.state.clubs[next.homeId];
	const away = game.state.clubs[next.awayId];
	const userHome = next.homeId === user.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-2xl flex-col gap-4 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-center text-[11px] uppercase tracking-[0.18em] text-muted",
					children: [
						compLabel(next.comp),
						" · ",
						next.round,
						" · Hafta ",
						next.week
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Side, {
							club: home,
							align: "left",
							you: userHome
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-2xl font-semibold text-muted",
							children: "vs"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Side, {
							club: away,
							align: "right",
							you: !userHome
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid grid-cols-1 gap-2 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => {
								const err = game.startMatch(next.id);
								if (err) flash(err);
								bump();
							},
							children: "Maçı başlat"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "soft",
							onClick: () => {
								const err = game.startMatch(next.id);
								if (err) {
									flash(err);
									return;
								}
								game.skipMatch();
								bump();
							},
							children: "Anında sonuç"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							onClick: () => {
								game.simRestOfWeek();
								bump();
							},
							children: "Haftayı simüle et"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-sm font-semibold",
				children: "Son haberler"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: game.state.news.slice(0, 5).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: n.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [" — ", n.body]
					})]
				}, n.id))
			})]
		})]
	});
}
function Side({ club, align, you }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-1 items-center gap-2", align === "right" && "flex-row-reverse"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
			club,
			size: 48
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: align === "right" ? "text-right" : "",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: club.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] text-muted",
				children: [
					you ? "Siz" : "Rakip",
					" · ",
					club.rep
				]
			})]
		})]
	});
}
function Live({ speed, setSpeed, bump }) {
	const game = useGame((s) => s.game);
	const live = game.state.live;
	const home = game.state.clubs[live.homeId];
	const away = game.state.clubs[live.awayId];
	const phase = live.phase;
	const running = phase === "first" || phase === "second";
	const feedRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		let raf = 0;
		let acc = 0;
		let last = performance.now();
		const loop = (now) => {
			const dt = Math.min(.1, (now - last) / 1e3);
			last = now;
			const sp = useGame.getState().speed;
			acc += dt * sp;
			const step = .34;
			const g = useGame.getState().game;
			const l = g?.state.live;
			while (acc >= step && l && (l.phase === "first" || l.phase === "second")) {
				acc -= step;
				g.stepMinute();
				useGame.getState().bump();
			}
			if (g?.state.live && (g.state.live.phase === "first" || g.state.live.phase === "second")) raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [running, live.fixtureId]);
	(0, import_react.useEffect)(() => {
		feedRef.current?.scrollTo({ top: 0 });
	}, [live.events[0]?.text, live.minute]);
	const userIsHome = live.homeId === game.state.clubId;
	const xi = userIsHome ? live.homeXI : live.awayXI;
	const bench = userIsHome ? live.homeBench : live.awayBench;
	const slots = FORMATIONS[game.user().tactics.formation]?.slots ?? FORMATIONS["4-3-3"].slots;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid h-full grid-cols-1 gap-3 p-3 lg:grid-cols-[minmax(0,1fr)_280px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-[11px] uppercase tracking-wider text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							compLabel(live.comp),
							" · ",
							live.round
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular text-lg font-semibold text-fg",
							children: live.phase === "ht" ? "Devre" : live.phase === "ft" ? "90+" : `${live.minute}'`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center justify-between gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
									club: home,
									size: 40
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-semibold",
									children: home.short
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "tabular text-4xl font-semibold tracking-tight",
								children: [
									live.homeGoals,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mx-1 text-muted",
										children: "–"
									}),
									live.awayGoals
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-semibold",
									children: away.short
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
									club: away,
									size: 40
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: speed === 1 ? "primary" : "soft",
								className: "min-h-9 px-3 text-xs",
								onClick: () => setSpeed(1),
								children: "1x"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: speed === 2 ? "primary" : "soft",
								className: "min-h-9 px-3 text-xs",
								onClick: () => setSpeed(2),
								children: "2x"
							}),
							phase === "ht" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								className: "min-h-9 px-3 text-xs",
								onClick: () => {
									game.continueSecondHalf();
									bump();
								},
								children: "İkinci yarı"
							}) : null,
							phase === "ft" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								className: "min-h-9 px-3 text-xs",
								onClick: () => {
									game.closeMatchAndAdvance();
									bump();
								},
								children: "Devam"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								className: "min-h-9 px-3 text-xs",
								onClick: () => {
									game.skipMatch();
									bump();
								},
								children: "Anında bitir"
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				className: "min-h-0 flex-1 overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: feedRef,
					className: "h-full max-h-[42vh] space-y-2 overflow-auto p-3 lg:max-h-none",
					children: live.events.map((ev, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventLine, { ev }, i))
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-2 text-xs font-semibold uppercase tracking-wide text-muted",
						children: "İstatistik"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: "Şut",
						a: live.stats.home.shots,
						b: live.stats.away.shots
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: "İsabet",
						a: live.stats.home.onTarget,
						b: live.stats.away.onTarget
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: "xG",
						a: Number(live.stats.home.xg.toFixed(1)),
						b: Number(live.stats.away.xg.toFixed(1))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: "Topla oynama",
						a: live.stats.home.possession,
						b: live.stats.away.possession
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: "Sarı / Kırmızı",
						a: live.stats.home.yellows,
						b: live.stats.away.yellows
					})
				]
			}), phase !== "ft" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "max-h-64 overflow-auto p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "mb-2 text-xs font-semibold uppercase tracking-wide text-muted",
						children: [
							"Değişiklik (",
							live.subsUsed,
							"/5)"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-[11px] text-muted",
						children: "Sahadakine dokun, yedekten seç."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubPanel, {
						xi,
						bench,
						slots
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-xs font-semibold uppercase tracking-wide text-muted",
					children: "Goller"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "text-sm",
					children: [live.scorers.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "tabular text-muted",
						children: [
							s.minute,
							"' ",
							s.name
						]
					}, i)), live.scorers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-muted",
						children: "Golsüz."
					}) : null]
				})]
			})]
		})]
	});
}
function EventLine({ ev }) {
	const tone = ev.kind === "goal" ? "text-ok" : ev.kind === "red" || ev.kind === "injury" ? "text-danger" : ev.kind === "yellow" ? "text-warn" : "text-fg";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-sm leading-snug", tone),
		children: ev.text
	});
}
function StatRow({ label, a, b }) {
	const tot = a + b || 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-0.5 flex justify-between text-[11px] text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular text-fg",
					children: a
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular text-fg",
					children: b
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-1.5 overflow-hidden rounded-full bg-bg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-fg/80",
				style: { width: `${a / tot * 100}%` }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-muted/50",
				style: { width: `${b / tot * 100}%` }
			})]
		})]
	});
}
function SubPanel({ xi, bench, slots }) {
	const game = useGame((s) => s.game);
	const bump = useGame((s) => s.bump);
	const selectedId = useGame((s) => s.selectedId);
	const setSelected = useGame((s) => s.setSelected);
	const flash = useGame((s) => s.flash);
	function tap(id, from) {
		if (!selectedId) {
			setSelected(id);
			return;
		}
		const selFromXi = xi.includes(selectedId);
		if (from === "bench" && selFromXi) {
			const err = game.sub(selectedId, id);
			if (err) flash(err);
			setSelected(null);
			bump();
			return;
		}
		if (from === "xi" && bench.includes(selectedId)) {
			const err = game.sub(id, selectedId);
			if (err) flash(err);
			setSelected(null);
			bump();
			return;
		}
		setSelected(id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mb-2",
			children: xi.map((id, i) => {
				const p = game.state.players[id];
				if (!p) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => tap(id, "xi"),
					className: cn("flex w-full items-center gap-2 rounded-xs px-1 py-1 text-left text-xs", selectedId === id && "bg-elevated"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-7 text-muted",
							children: slots[i]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 truncate",
							children: p.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular text-muted",
							children: [Math.round(p.energy), "%"]
						})
					]
				}) }, id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 text-[10px] uppercase tracking-wide text-muted",
			children: "Yedek"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: bench.map((id) => {
			const p = game.state.players[id];
			if (!p) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => tap(id, "bench"),
				className: cn("flex w-full items-center gap-2 rounded-xs px-1 py-1 text-left text-xs", selectedId === id && "bg-elevated"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-7 text-muted",
					children: p.pos
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex-1 truncate",
					children: p.name
				})]
			}) }, id);
		}) })
	] });
}
var COST = [
	0,
	0,
	2e6,
	55e5,
	13e6,
	28e6
];
var RED = [
	0,
	0,
	10,
	18,
	26,
	35
];
function MedicalView() {
	const game = useGame((s) => s.game);
	const bump = useGame((s) => s.bump);
	const flash = useGame((s) => s.flash);
	useGame((s) => s.tick);
	const user = game.user();
	const squad = game.userPlayers();
	const injured = squad.filter((p) => p.inj);
	const banned = squad.filter((p) => p.ban > 0);
	const tired = squad.filter((p) => p.energy < 70 && !p.inj);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-5xl gap-3 p-3 lg:grid-cols-[1fr_280px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4 text-danger" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Sakat kadro"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted",
								children: [injured.length, " oyuncu"]
							})
						]
					}), injured.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Revir boş. Kondisyonu düşük oyuncuları dinlendirin."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-border",
						children: injured.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ovr, { n: p.ovr }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-sm",
										children: [
											p.name,
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusIcons, { p })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-muted",
										children: [
											p.inj?.label,
											" · ",
											p.inj?.weeksLeft,
											" hafta kaldı"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
										value: p.inj ? (p.inj.originalWeeks - p.inj.weeksLeft) / p.inj.originalWeeks * 100 : 0,
										tone: "danger"
									})
								]
							})]
						}, p.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: "Cezalılar ve kartlar"
					}), banned.length === 0 && squad.every((p) => p.yellows === 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Aktif ceza yok. 4 sarı = 1 maç, kırmızı = 2 maç."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-border",
						children: squad.filter((p) => p.ban > 0 || p.yellows > 0).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								p.name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted",
									children: [p.yellows, " sarı"]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-danger",
								children: p.ban > 0 ? `${p.ban} maç ceza` : ""
							})]
						}, p.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: "Düşük kondisyon (sakatlık riski)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "divide-y divide-border",
						children: [tired.slice(0, 8).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-28 truncate text-sm",
									children: p.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, { value: p.energy })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular text-xs text-muted",
									children: [Math.round(p.energy), "%"]
								})
							]
						}, p.id)), tired.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "Kondisyonlar yerinde."
						}) : null]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "h-fit p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Sağlık ekibi"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-3xl font-semibold tabular",
					children: ["Sv ", user.medical]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-muted",
					children: [
						"İyileşme süresi ",
						RED[user.medical],
						"% daha kısa. Seviye 5’te %35."
					]
				}),
				user.medical < 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
					className: "mt-4 w-full",
					onClick: () => {
						const err = game.upgrade("medical");
						flash(err ?? `Sağlık ekibi seviye ${user.medical}`);
						bump();
					},
					children: ["Yükselt · ", money(COST[user.medical + 1] ?? 0)]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-ok",
					children: "Maksimum seviye"
				})
			]
		})]
	});
}
var NAV = [
	{
		id: "squad",
		label: "Kadro",
		icon: Users
	},
	{
		id: "tactics",
		label: "Taktik",
		icon: Shield
	},
	{
		id: "transfer",
		label: "Transfer",
		icon: ArrowLeftRight
	},
	{
		id: "europe",
		label: "Avrupa",
		icon: Trophy
	},
	{
		id: "medical",
		label: "Revir",
		icon: Activity
	},
	{
		id: "club",
		label: "Kulüp",
		icon: Building2
	},
	{
		id: "match",
		label: "Maç",
		icon: Play
	}
];
function Shell({ children }) {
	const game = useGame((s) => s.game);
	const screen = useGame((s) => s.screen);
	const setScreen = useGame((s) => s.setScreen);
	useGame((s) => s.tick);
	const user = game.user();
	const pos = game.leagueTable(user.league).findIndex((c) => c.id === user.id) + 1;
	const next = game.nextUserFixture();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3 border-b border-border bg-panel px-3 py-2 sm:px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
						club: user,
						size: 40
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate text-sm font-semibold sm:text-base",
								children: user.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "hidden text-xs text-muted sm:inline",
								children: [
									leagueName(user.league),
									" · ",
									pos,
									". sıra"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-0.5 flex items-center gap-3 text-[11px] text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular",
									children: seasonDate(game.state.season, game.state.week)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular text-fg",
									children: money(user.balance)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: objectiveLabel(game.state.objective)
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-24 shrink-0 sm:w-32",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between text-[10px] uppercase tracking-wide",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Yönetim"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("tabular font-medium", confTone(game.state.board)),
								children: [game.state.board, "%"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, { value: game.state.board })]
					}),
					next && screen !== "match" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setScreen("match"),
						className: "hidden min-h-11 rounded-sm bg-accent px-3 text-xs font-medium text-accent-fg sm:inline-flex sm:items-center",
						children: "Sıradaki maç"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-h-0 flex-1 overflow-auto",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "grid grid-cols-7 border-t border-border bg-panel pb-[env(safe-area-inset-bottom)]",
				children: NAV.map((n) => {
					const Icon = n.icon;
					const on = screen === n.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setScreen(n.id),
						className: cn("flex min-h-12 flex-col items-center justify-center gap-0.5 text-[10px]", on ? "text-fg" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: cn("size-4", on ? "text-accent" : ""),
							strokeWidth: 1.75
						}), n.label]
					}, n.id);
				})
			})
		]
	});
}
function SquadView() {
	const game = useGame((s) => s.game);
	useGame((s) => s.tick);
	const selectedId = useGame((s) => s.selectedId);
	const setSelected = useGame((s) => s.setSelected);
	const bump = useGame((s) => s.bump);
	const user = game.user();
	const players = game.userPlayers();
	const form = FORMATIONS[user.tactics.formation] ?? FORMATIONS["4-3-3"];
	const byId = (id) => game.state.players[id];
	function tapPlayer(id) {
		if (!selectedId) {
			setSelected(id);
			return;
		}
		if (selectedId === id) {
			setSelected(null);
			return;
		}
		game.swap(selectedId, id);
		setSelected(null);
		bump();
	}
	function tapSlot(index) {
		if (selectedId) {
			game.setSlot(index, selectedId);
			setSelected(null);
			bump();
			return;
		}
		const id = user.xi[index];
		if (id) tapPlayer(id);
	}
	const xiSet = new Set(user.xi);
	const benchSet = new Set(user.bench);
	const rest = players.filter((p) => !xiSet.has(p.id) && !benchSet.has(p.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid h-full grid-cols-1 gap-3 p-3 lg:grid-cols-[minmax(0,1fr)_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "flex flex-col overflow-hidden p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-sm font-semibold",
					children: ["İlk 11 · ", user.tactics.formation]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Oyuncu seç, yuvaya yerleştir"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pitch-grid relative flex min-h-[320px] flex-1 flex-col justify-between rounded-md p-3",
				children: form.rows.map((row, ri) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-evenly",
					children: row.map((si) => {
						const id = user.xi[si];
						const p = id ? byId(id) : void 0;
						const slot = form.slots[si];
						const mismatch = p && p.pos !== slot;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => tapSlot(si),
							className: cn("flex w-[72px] flex-col items-center rounded-sm border bg-bg/80 px-1 py-1.5 backdrop-blur-sm", selectedId && p?.id === selectedId ? "border-accent" : "border-border"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] uppercase tracking-wide text-muted",
								children: slot
							}), p ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("tabular text-sm font-semibold", ovrTone(p.ovr)),
									children: mismatch ? Math.round(p.ovr * .8) : p.ovr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-full truncate text-[10px]",
									children: p.name.split(" ").slice(-1)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusIcons, { p })
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-faint",
								children: "Boş"
							})]
						}, si);
					})
				}, ri))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerBlock, {
				title: "Yedekler",
				list: user.bench.map((id) => byId(id)).filter((p) => !!p),
				selectedId,
				onTap: tapPlayer
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerBlock, {
				title: "Rezerv",
				list: rest,
				selectedId,
				onTap: tapPlayer
			})]
		})]
	});
}
function PlayerBlock({ title, list, selectedId, onTap }) {
	const user = useGame((s) => s.game).user();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "min-h-0 flex-1 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border px-3 py-2 text-xs font-medium uppercase tracking-wide text-muted",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "max-h-64 overflow-auto lg:max-h-none",
				children: [list.map((p) => {
					const locked = !!p.inj || p.ban > 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => !locked && onTap(p.id),
						disabled: locked,
						className: cn("flex w-full items-center gap-2 px-3 py-2 text-left hover:bg-elevated", selectedId === p.id && "bg-elevated", locked && "opacity-50"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ovr, { n: p.ovr }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-8 text-[11px] text-muted",
								children: p.pos
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate text-sm",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusIcons, { p }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, { value: p.energy })
							})
						]
					}) }, p.id);
				}), list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-3 py-4 text-xs text-muted",
					children: "Liste boş"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
					club: user,
					size: 16
				})
			})
		]
	});
}
var FEATURED = [
	"Galatasaray",
	"Fenerbahçe",
	"Beşiktaş",
	"Real Madrid",
	"Manchester City",
	"Bayern Münih",
	"Barcelona",
	"Liverpool",
	"Paris Saint-Germain",
	"Inter"
];
function StartScreen() {
	const startClub = useGame((s) => s.startClub);
	const createClub = useGame((s) => s.createClub);
	const continueSave = useGame((s) => s.continueSave);
	const [tab, setTab] = (0, import_react.useState)(hasSave() ? "pick" : "pick");
	const [q, setQ] = (0, import_react.useState)("");
	const [league, setLeague] = (0, import_react.useState)("TUR1");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [manager, setManager] = (0, import_react.useState)("Teknik Direktör");
	const [form, setForm] = (0, import_react.useState)({
		name: "Mavi Kartal",
		short: "MKA",
		stadium: "Yeni Şehir Stadyumu",
		primary: "#1f4e79",
		secondary: "#d9e2e8",
		budget: 12e6,
		manager: "Teknik Direktör"
	});
	const clubs = (0, import_react.useMemo)(() => {
		const rows = [];
		for (const L of LEAGUES) for (const r of CLUB_RAW[L.id] ?? []) rows.push({
			league: L.id,
			leagueName: L.name,
			name: r[0],
			short: r[1],
			stadium: r[2],
			colors: [r[4], r[5]],
			rep: r[3]
		});
		return rows;
	}, []);
	const filtered = clubs.filter((c) => {
		if (league !== "ALL" && c.league !== league) return false;
		if (!q.trim()) return true;
		const s = q.toLowerCase();
		return c.name.toLowerCase().includes(s) || c.short.toLowerCase().includes(s);
	});
	const featured = clubs.filter((c) => FEATURED.includes(c.name));
	function goPick(name) {
		setBusy(true);
		window.setTimeout(() => startClub(name, manager || "Teknik Direktör"), 40);
	}
	function goCreate() {
		setBusy(true);
		window.setTimeout(() => createClub({
			...form,
			short: form.short.slice(0, 4).toUpperCase(),
			manager: form.manager || manager
		}), 40);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-4 px-5 pb-3 pt-6 sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-muted",
					children: "Teknik Direktör Simülasyonu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-sans text-4xl font-semibold tracking-tight text-fg sm:text-5xl",
					children: "Onbir"
				})] }), hasSave() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: continueSave,
					className: "shrink-0",
					children: "Kayda devam"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1 px-5 sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tab, {
					active: tab === "pick",
					onClick: () => setTab("pick"),
					children: "Hazır takım"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tab, {
					active: tab === "create",
					onClick: () => setTab("create"),
					children: "Sıfırdan kulüp"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-auto px-5 py-4 sm:px-8",
				children: tab === "pick" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Menajer adı",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: manager,
								onChange: (e) => setManager(e.target.value),
								maxLength: 24
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs uppercase tracking-wider text-muted",
							children: "Öne çıkanlar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2 sm:grid-cols-5",
							children: featured.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => goPick(c.name),
								className: "flex items-center gap-2 rounded-md border border-border bg-surface px-2.5 py-2 text-left hover:border-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
									club: c,
									size: 32
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-sm font-medium",
									children: c.name
								})]
							}, c.name))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: inputClass,
								value: league,
								onChange: (e) => setLeague(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ALL",
									children: "Tüm ligler"
								}), LEAGUES.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: l.id,
									children: l.name
								}, l.id))]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: cnGrow(),
								placeholder: "Takım ara",
								value: q,
								onChange: (e) => setQ(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 gap-1.5 sm:grid-cols-2 lg:grid-cols-3",
							children: filtered.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => goPick(c.name),
								className: "flex items-center gap-3 rounded-md border border-border bg-surface px-3 py-2.5 text-left hover:border-accent",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, { club: c }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-sm font-medium",
											children: c.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs text-muted",
											children: [
												c.leagueName,
												" · ",
												c.stadium
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular text-xs text-muted",
										children: c.rep
									})
								]
							}, c.league + c.name))
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "mx-auto max-w-xl p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-4 text-lg font-semibold",
							children: "Kulüp kur"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-5 text-sm text-muted",
							children: "1. Lig’den başlarsınız. Bütçe, forma renkleri ve stadyum sizin."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Kulüp adı",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										value: form.name,
										onChange: (e) => setForm({
											...form,
											name: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Kısaltma",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										value: form.short,
										maxLength: 4,
										onChange: (e) => setForm({
											...form,
											short: e.target.value.toUpperCase()
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Stadyum",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										value: form.stadium,
										onChange: (e) => setForm({
											...form,
											stadium: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Menajer",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										value: form.manager,
										onChange: (e) => setForm({
											...form,
											manager: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Ana renk",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "color",
										className: "h-11 w-full rounded-sm border border-border bg-bg",
										value: form.primary,
										onChange: (e) => setForm({
											...form,
											primary: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "İkinci renk",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "color",
										className: "h-11 w-full rounded-sm border border-border bg-bg",
										value: form.secondary,
										onChange: (e) => setForm({
											...form,
											secondary: e.target.value
										})
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs text-muted",
								children: "Başlangıç bütçesi"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									[8e6, "Düşük"],
									[12e6, "Orta"],
									[22e6, "Yüksek"]
								].map(([v, lab]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setForm({
										...form,
										budget: v
									}),
									className: `rounded-sm border px-2 py-3 text-sm ${form.budget === v ? "border-accent bg-accent/20 text-fg" : "border-border bg-bg text-muted"}`,
									children: [lab, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-1 block text-xs",
										children: [
											"€",
											v / 1e6,
											"M"
										]
									})]
								}, String(v)))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crest, {
								club: {
									short: form.short || "FC",
									colors: [form.primary, form.secondary]
								},
								size: 48
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: goCreate,
								className: "flex-1",
								children: "1. Lig’den başla"
							})]
						})
					]
				})
			}),
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-center justify-center bg-bg/80",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "px-8 py-6 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Ligler kuruluyor"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "Kadrolar ve fikstür hazırlanıyor…"
					})]
				})
			}) : null
		]
	});
}
function Tab({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick,
		className: `rounded-sm px-4 py-2 text-sm font-medium ${active ? "bg-surface text-fg" : "text-muted hover:text-fg"}`,
		children
	});
}
function cnGrow() {
	return inputClass + " flex-1 min-w-[160px]";
}
function TacticsView() {
	const game = useGame((s) => s.game);
	const bump = useGame((s) => s.bump);
	useGame((s) => s.tick);
	const t = game.user().tactics;
	const chem = Math.round(chemistry(game.user(), game.state.players) * 100);
	function set(key, value) {
		game.setTactics({ [key]: value });
		bump();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-4xl gap-3 p-3 md:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: "Diziliş"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
						children: Object.keys(FORMATIONS).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: t.formation === f ? "primary" : "soft",
							onClick: () => set("formation", f),
							children: f
						}, f))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs text-muted",
						children: [
							"Mevki uyumu ",
							chem,
							"%. Doğal mevki dışında reyting %20 düşer."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-sm font-semibold",
						children: "Oyun stili"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						options: STYLE_LABEL,
						value: t.style,
						onChange: (v) => set("style", v)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 mt-5 text-sm font-semibold",
						children: "Pres çizgisi"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						options: PRESS_LABEL,
						value: t.press,
						onChange: (v) => set("press", v)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 mt-5 text-sm font-semibold",
						children: "Mentolite"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						options: MENT_LABEL,
						value: t.mentality,
						onChange: (v) => set("mentality", v)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4 md:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-sm font-semibold",
					children: "Eşleşme notu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "grid gap-2 text-sm text-muted sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Kontra, yüksek prese karşı avantajlıdır." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Kısa pas, düşük bloğu açmakta iyidir." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Yüksek pres yorar; sakatlık riski artar." })
					]
				})]
			})
		]
	});
}
function Row({ options, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-3 gap-2",
		children: Object.entries(options).map(([k, lab]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			variant: value === k ? "primary" : "soft",
			onClick: () => onChange(k),
			children: lab
		}, k))
	});
}
var POS = [
	"GK",
	"CB",
	"LB",
	"RB",
	"CDM",
	"CM",
	"CAM",
	"LW",
	"RW",
	"ST"
];
function TransferView() {
	const game = useGame((s) => s.game);
	const bump = useGame((s) => s.bump);
	const flash = useGame((s) => s.flash);
	const bidPlayer = useGame((s) => s.bidPlayer);
	const setBidPlayer = useGame((s) => s.setBidPlayer);
	useGame((s) => s.tick);
	const [q, setQ] = (0, import_react.useState)("");
	const [pos, setPos] = (0, import_react.useState)("ALL");
	const [tab, setTab] = (0, import_react.useState)("market");
	const list = (0, import_react.useMemo)(() => game.market.list(game.state), [
		game,
		game.state.uid,
		game.state.week
	]).filter((p) => {
		if (pos !== "ALL" && p.pos !== pos) return false;
		if (q && !p.name.toLowerCase().includes(q.toLowerCase())) return false;
		return true;
	});
	const target = bidPlayer ? game.state.players[bidPlayer] : void 0;
	const [amount, setAmount] = (0, import_react.useState)(0);
	const [wage, setWage] = (0, import_react.useState)(0);
	function openBid(p) {
		setBidPlayer(p.id);
		setAmount(Math.round(p.value * 1.05));
		setWage(Math.round(playerWage(p.ovr, p.age) * 1.05));
	}
	function confirmBid() {
		if (!target) return;
		const r = game.bid(target.id, amount, wage);
		flash(r.message);
		if (r.ok) setBidPlayer(null);
		bump();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col gap-3 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: tab === "market" ? "primary" : "soft",
						onClick: () => setTab("market"),
						children: "Pazar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: tab === "squad" ? "primary" : "soft",
						onClick: () => setTab("squad"),
						children: "Satış"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: game.state.transferOpen ? "Pencere açık" : "Pencere kapalı"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass + " ml-auto w-40",
						placeholder: "İsim ara",
						value: q,
						onChange: (e) => setQ(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: inputClass,
						value: pos,
						onChange: (e) => setPos(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "ALL",
							children: "Mevki"
						}), POS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: p }, p))]
					})
				]
			}),
			tab === "market" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				className: "min-h-0 flex-1 overflow-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "sticky top-0 bg-surface text-[11px] uppercase tracking-wide text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Oyuncu"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Kulüp" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Yaş" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Değer" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: list.slice(0, 80).map((p) => {
						const club = game.state.clubs[p.clubId];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ovr, { n: p.ovr }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [p.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 text-[11px] text-muted",
											children: p.pos
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "text-muted",
									children: club?.short
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular",
									children: p.age
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular",
									children: money(p.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "pr-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										className: "min-h-9 px-2 text-xs",
										disabled: !game.state.transferOpen,
										onClick: () => openBid(p),
										children: "Teklif"
									})
								})
							]
						}, p.id);
					}) })]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				className: "min-h-0 flex-1 overflow-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: game.userPlayers().map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 border-b border-border px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ovr, { n: p.ovr }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 text-[11px] text-muted",
							children: p.pos
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1 truncate text-sm",
							children: [
								p.name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: money(p.value)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusIcons, { p }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "soft",
							className: "min-h-9 px-2 text-xs",
							onClick: () => {
								const r = game.sell(p.id);
								flash(r.message);
								bump();
							},
							children: "Sat"
						})
					]
				}, p.id)) })
			}),
			target ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 flex items-end justify-center bg-bg/70 p-4 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "w-full max-w-md p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-semibold",
							children: target.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-4 text-xs text-muted",
							children: [
								target.pos,
								" · ",
								target.age,
								" · ",
								money(target.value)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Transfer bedeli",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									className: inputClass,
									value: amount,
									onChange: (e) => setAmount(Number(e.target.value))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Haftalık ücret",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									className: inputClass,
									value: wage,
									onChange: (e) => setWage(Number(e.target.value))
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								className: "flex-1",
								onClick: () => setBidPlayer(null),
								children: "Vazgeç"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								className: "flex-1",
								onClick: confirmBid,
								children: "Gönder"
							})]
						})
					]
				})
			}) : null
		]
	});
}
function GameApp() {
	const hydrate = useGame((s) => s.hydrate);
	const ready = useGame((s) => s.ready);
	const game = useGame((s) => s.game);
	const screen = useGame((s) => s.screen);
	const toast = useGame((s) => s.toast);
	const bump = useGame((s) => s.bump);
	useGame((s) => s.tick);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const onHide = () => useGame.getState().game?.save();
		document.addEventListener("visibilitychange", onHide);
		window.addEventListener("pagehide", onHide);
		return () => {
			document.removeEventListener("visibilitychange", onHide);
			window.removeEventListener("pagehide", onHide);
		};
	}, [game]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-muted",
		children: "Yükleniyor"
	});
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: screen === "squad" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquadView, {}) : screen === "tactics" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TacticsView, {}) : screen === "transfer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransferView, {}) : screen === "europe" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuropeView, {}) : screen === "medical" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MedicalView, {}) : screen === "club" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubView, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchView, {}) }),
		toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none fixed bottom-16 left-1/2 z-40 -translate-x-1/2 rounded-sm bg-elevated px-4 py-2 text-sm shadow-panel",
			children: toast
		}) : null,
		game.state.sacked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SackedModal, { bump }) : null
	] });
}
function SackedModal({ bump }) {
	const game = useGame((s) => s.game);
	const newGame = useGame((s) => s.newGame);
	const jobs = game.availableJobs();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-bg/80 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "w-full max-w-md p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Görevden alındınız"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Yönetim kurulu güveni tükendi. Yeni bir kulüp seçebilir veya kariyeri sıfırlayabilirsiniz."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 max-h-48 space-y-1 overflow-auto",
					children: jobs.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
						variant: "soft",
						className: "w-full justify-between",
						onClick: () => {
							game.takeJob(c.id);
							bump();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: c.short
						})]
					}) }, c.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "mt-3 w-full",
					onClick: newGame,
					children: "Yeni kariyer"
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
