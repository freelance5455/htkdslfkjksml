import { i as __toESM } from "../_runtime.mjs";
import { d as require_react, u as require_jsx_runtime } from "../_libs/@react-three/fiber+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B4eWnarM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Boot() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid h-dvh place-items-center bg-sky px-6 text-center text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-extrabold tracking-widest text-hedge uppercase",
				children: "A pocket maze"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-3 text-4xl leading-none",
				children: "Lantern Grove"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Trimming the hedges…"
			})
		] })
	});
}
function Home() {
	const [View, setView] = (0, import_react.useState)(null);
	const [touch, setTouch] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let drop = () => {};
		let cancelled = false;
		const coarse = window.matchMedia("(pointer: coarse)").matches;
		setTouch(coarse);
		import("./Game-BA2sin1g.mjs").then((mod) => {
			if (cancelled) return;
			return import("./session-C7yNCexP.mjs").then((live) => {
				if (cancelled) return;
				live.session.touch = coarse;
				live.session.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
				drop = mod.mountInput();
				setView(() => mod.Game);
			});
		});
		return () => {
			cancelled = true;
			drop();
		};
	}, []);
	if (!View) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boot, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, { touch });
}
//#endregion
export { Home as component };
