import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/ticket-CPjBzwvG.js
var SECRET = "puro-media-ticket-v1";
function key() {
	return createHash("sha256").update(SECRET).digest();
}
function sealTicket(input, ttlMs = 12e5) {
	const payload = {
		...input,
		exp: Date.now() + ttlMs
	};
	const iv = randomBytes(12);
	const cipher = createCipheriv("aes-256-gcm", key(), iv);
	const enc = Buffer.concat([cipher.update(JSON.stringify(payload), "utf8"), cipher.final()]);
	const tag = cipher.getAuthTag();
	return Buffer.concat([
		iv,
		tag,
		enc
	]).toString("base64url");
}
function openTicket(token) {
	try {
		const buf = Buffer.from(token, "base64url");
		if (buf.length < 29) return null;
		const iv = buf.subarray(0, 12);
		const tag = buf.subarray(12, 28);
		const enc = buf.subarray(28);
		const decipher = createDecipheriv("aes-256-gcm", key(), iv);
		decipher.setAuthTag(tag);
		const json = Buffer.concat([decipher.update(enc), decipher.final()]).toString("utf8");
		const ticket = JSON.parse(json);
		if (!ticket?.url || ticket.exp < Date.now()) return null;
		if (!/^https?:\/\//i.test(ticket.url)) return null;
		return ticket;
	} catch {
		return null;
	}
}
function isBlockedHost(raw) {
	let u;
	try {
		u = new URL(raw);
	} catch {
		return true;
	}
	if (u.protocol !== "https:" && u.protocol !== "http:") return true;
	const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
	if (host === "localhost" || host.endsWith(".local") || host === "0.0.0.0" || host === "::1" || host === "metadata.google.internal") return true;
	if (/^(127\.|10\.|192\.168\.|169\.254\.|0\.)/.test(host)) return true;
	const m = host.match(/^172\.(\d+)\./);
	if (m) {
		const n = Number(m[1]);
		if (n >= 16 && n <= 31) return true;
	}
	return false;
}
//#endregion
export { openTicket as n, sealTicket as r, isBlockedHost as t };
