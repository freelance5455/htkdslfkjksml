import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useStudy } from "./router-C-xQh0iG.mjs";
import { t as CHAPTERS } from "./curriculum-BHBVcVfN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/manuale-DWD55Mvq.js
var import_jsx_runtime = require_jsx_runtime();
function Manuale() {
	const read = useStudy((s) => s.read);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-primary",
				children: "Il programma"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold",
				children: "المنهج"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-muted",
				children: "خمسة وعشرون فصلًا كما تُقسَّم نظرية الامتحان. النص الإيطالي فوق، والعربي في الإطار الأخضر. أي كلمة إيطالية تُضغط."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-2",
			children: CHAPTERS.map((ch) => {
				const done = read.includes(ch.slug);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/manuale/$slug",
					params: { slug: ch.slug },
					className: "flex items-start gap-3 rounded-2xl border border-line bg-surface px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-full text-sm font-semibold ${done ? "bg-primary text-primary-fg" : "bg-soft text-primary"}`,
						children: ch.n
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								dir: "ltr",
								lang: "it",
								className: "block text-left text-sm text-muted",
								children: ch.titleIt
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-lg font-semibold leading-snug",
								children: ch.titleAr
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm text-muted",
								children: ch.summaryAr
							})
						]
					})]
				}) }, ch.slug);
			})
		})]
	});
}
//#endregion
export { Manuale as component };
