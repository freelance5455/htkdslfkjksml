import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { s as num, t as CONFIG } from "./math-DEeAY6PY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-CKPW6Fo1.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var FOTMOB_TEAM_LOGO = (id) => `https://images.fotmob.com/image_resources/logo/teamlogo/${id}.png`;
function pairNum(stats) {
	if (!Array.isArray(stats) || stats.length < 2) return [0, 0];
	return [num(stats[0]), num(stats[1])];
}
function parseLiveTime(status) {
	const finished = Boolean(status.finished);
	const started = Boolean(status.started);
	const ongoing = Boolean(status.ongoing);
	if (!started) return {
		minute: 0,
		display: "—",
		period: "ns"
	};
	if (finished) return {
		minute: 90,
		display: "FT",
		period: "ft"
	};
	const halves = status.halfs || {};
	if (halves.firstHalfEnded && !halves.secondHalfStarted) return {
		minute: 45,
		display: "INT",
		period: "ht"
	};
	const live = status.liveTime || {};
	const long = String(live.long || "");
	const minsFromLong = parseInt(long.split(":")[0] || "", 10);
	const short = String(live.short || "").replace(/[^\d+]/g, "");
	let minute = Number.isFinite(minsFromLong) ? minsFromLong : parseInt(short, 10) || 0;
	minute = Math.min(120, Math.max(1, minute));
	if (live.maxTime && live.addedTime && live.addedTime > 0) return {
		minute: live.maxTime + live.addedTime,
		display: `${live.maxTime}+${live.addedTime}`,
		period: minute <= 45 ? "1h" : "2h"
	};
	if (short.includes("+")) return {
		minute,
		display: short.replace("+", "+"),
		period: minute <= 45 ? "1h" : "2h"
	};
	const period = minute <= 45 ? "1h" : halves.secondHalfStarted ? "2h" : "1h";
	if (!ongoing && started && !finished) return {
		minute: 45,
		display: "INT",
		period: "ht"
	};
	return {
		minute,
		display: String(minute),
		period
	};
}
function parseMatchList(payload) {
	const leagues = payload?.leagues || [];
	const out = [];
	for (const lg of leagues) {
		const leagueName = String(lg.name || "Liga");
		const country = String(lg.ccode || "");
		const leagueId = typeof lg.id === "number" ? lg.id : void 0;
		const matches = lg.matches || [];
		for (const m of matches) {
			const st = m.status || {};
			if (!st.started || st.finished || st.cancelled) continue;
			if (!st.ongoing && !st.started) continue;
			const home = m.home || {};
			const away = m.away || {};
			const clock = parseLiveTime(st);
			if (clock.period === "ns" || clock.period === "ft") continue;
			const id = String(m.id ?? "");
			if (!id) continue;
			out.push({
				id,
				eventId: id,
				homeTeam: {
					id: home.id,
					name: home.name || "Casa",
					logo: home.id ? FOTMOB_TEAM_LOGO(home.id) : void 0
				},
				awayTeam: {
					id: away.id,
					name: away.name || "Fora",
					logo: away.id ? FOTMOB_TEAM_LOGO(away.id) : void 0
				},
				score: { fullTime: {
					home: num(home.score),
					away: num(away.score)
				} },
				htScore: {
					home: null,
					away: null
				},
				minute: clock.minute,
				minuteDisplay: clock.display,
				league: leagueName,
				leagueId,
				country,
				period: clock.period,
				source: "fotmob",
				events: []
			});
		}
	}
	return out;
}
var STAT_MAP = {
	expected_goals: ["xgH", "xgA"],
	expected_goals_on_target: ["xgotH", "xgotA"],
	total_shots: ["shotsH", "shotsA"],
	ShotsOnTarget: ["sotH", "sotA"],
	corners: ["cornersH", "cornersA"],
	fouls: ["foulsH", "foulsA"],
	big_chance: ["bcH", "bcA"],
	BallPossesion: ["possH", "possA"],
	keeper_saves: ["savesH", "savesA"],
	shots_woodwork: ["woodH", "woodA"],
	blocked_shots: ["blockedH", "blockedA"],
	Offsides: ["offH", "offA"],
	yellow_cards: ["yelH", "yelA"],
	red_cards: ["redH", "redA"],
	shots_inside_box: ["shotsInH", "shotsInA"],
	shots_outside_box: ["shotsOutH", "shotsOutA"],
	touches_opp_box: ["touchesBoxH", "touchesBoxA"],
	accurate_crosses: ["crossesH", "crossesA"],
	clearances: ["clearancesH", "clearancesA"],
	duel_won: ["duelsH", "duelsA"],
	passes: ["passesH", "passesA"],
	accurate_passes: ["accuratePassesH", "accuratePassesA"],
	interceptions: ["interceptionsH", "interceptionsA"]
};
function blankStats() {
	return {
		xgH: 0,
		xgA: 0,
		xgotH: 0,
		xgotA: 0,
		xaH: 0,
		xaA: 0,
		shotsH: 0,
		shotsA: 0,
		sotH: 0,
		sotA: 0,
		cornersH: 0,
		cornersA: 0,
		foulsH: 0,
		foulsA: 0,
		bcH: 0,
		bcA: 0,
		possH: 50,
		possA: 50,
		savesH: 0,
		savesA: 0,
		woodH: 0,
		woodA: 0,
		blockedH: 0,
		blockedA: 0,
		offH: 0,
		offA: 0,
		yelH: 0,
		yelA: 0,
		redH: 0,
		redA: 0,
		shotsInH: 0,
		shotsInA: 0,
		shotsOutH: 0,
		shotsOutA: 0,
		attacksH: 0,
		attacksA: 0,
		dangerousH: 0,
		dangerousA: 0,
		touchesBoxH: 0,
		touchesBoxA: 0,
		crossesH: 0,
		crossesA: 0,
		clearancesH: 0,
		clearancesA: 0,
		duelsH: 0,
		duelsA: 0,
		passesH: 0,
		passesA: 0,
		accuratePassesH: 0,
		accuratePassesA: 0,
		tacklesH: 0,
		tacklesA: 0,
		interceptionsH: 0,
		interceptionsA: 0,
		sourceVerified: false,
		source: "fotmob",
		dataCompleteness: 0,
		half2: null
	};
}
function applyPeriod(target, period) {
	const groups = period?.stats || [];
	for (const g of groups) for (const it of g.stats || []) {
		const key = String(it.key || "");
		const mapped = STAT_MAP[key];
		if (!mapped) {
			if (key === "matchstats.headers.tackles") {
				const [h, a] = pairNum(it.stats);
				target.tacklesH = h;
				target.tacklesA = a;
			}
			continue;
		}
		const [hKey, aKey] = mapped;
		const [h, a] = pairNum(it.stats);
		if (h === 0 && a === 0 && target[hKey] > 0) continue;
		target[hKey] = h;
		target[aKey] = a;
	}
}
function parseMatchStats(details) {
	const s = blankStats();
	const periods = details?.content?.stats?.Periods || {};
	applyPeriod(s, periods.All);
	if (periods.SecondHalf) {
		const h2 = blankStats();
		applyPeriod(h2, periods.SecondHalf);
		s.half2 = h2;
	}
	if (!s.dangerousH && !s.dangerousA) {
		s.dangerousH = s.touchesBoxH;
		s.dangerousA = s.touchesBoxA;
	}
	if (!s.attacksH && !s.attacksA) {
		s.attacksH = s.shotsH * 2 + s.cornersH + s.touchesBoxH;
		s.attacksA = s.shotsA * 2 + s.cornersA + s.touchesBoxA;
	}
	const vals = Object.values(s).filter((v) => typeof v === "number" && Number.isFinite(v));
	s.dataCompleteness = Math.round(vals.filter((v) => v !== 0).length / Math.max(1, vals.length) * 100);
	s.sourceVerified = s.shotsH + s.shotsA + s.xgH + s.xgA + s.sotH + s.sotA > 0;
	return s;
}
function parseMomentum(details) {
	return (details?.content?.momentum?.main?.data || []).map((p) => ({
		minute: num(p.minute),
		value: num(p.value)
	})).filter((p) => Number.isFinite(p.minute));
}
function parseEvents(details) {
	const raw = details?.content?.matchFacts?.events?.events || [];
	const events = [];
	for (const e of raw) {
		const type = String(e.type || "");
		const minute = num(e.time) + num(e.overloadTime);
		const side = e.isHome ? "home" : "away";
		if (type === "Goal") events.push({
			minute,
			side,
			kind: "goal"
		});
		else if (type === "Card") {
			if (String(e.card || "").toLowerCase().includes("red")) events.push({
				minute,
				side,
				kind: "red"
			});
			else events.push({
				minute,
				side,
				kind: "yellow"
			});
		}
	}
	events.sort((a, b) => a.minute - b.minute);
	return events;
}
function htScoreFromEvents(events, current) {
	let home = 0;
	let away = 0;
	for (const e of events) {
		if (e.kind !== "goal") continue;
		if (e.minute > 45) break;
		if (e.side === "home") home += 1;
		else away += 1;
	}
	if (home + away === 0 && current.home + current.away === 0) return {
		home: 0,
		away: 0
	};
	if (home + away > current.home + current.away) return {
		home: current.home,
		away: current.away
	};
	return {
		home,
		away
	};
}
function parseHeaderClock(details) {
	const st = details?.header?.status;
	if (!st) return null;
	return parseLiveTime(st);
}
function parseHeaderScore(details) {
	const teams = details?.header?.teams;
	if (!teams || teams.length < 2) return null;
	return {
		home: num(teams[0].score),
		away: num(teams[1].score)
	};
}
var FOTMOB = "https://www.fotmob.com/api/data";
var UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
async function fotmobGet(path, timeoutMs = 1e4) {
	const ctrl = new AbortController();
	const t = setTimeout(() => ctrl.abort(), timeoutMs);
	try {
		const r = await fetch(`${FOTMOB}${path}`, {
			headers: {
				Accept: "application/json",
				"User-Agent": UA,
				Referer: "https://www.fotmob.com/",
				Origin: "https://www.fotmob.com"
			},
			signal: ctrl.signal
		});
		if (!r.ok) throw new Error(`FotMob ${r.status}`);
		return await r.json();
	} finally {
		clearTimeout(t);
	}
}
async function poolMap(items, limit, fn) {
	const out = new Array(items.length);
	let cursor = 0;
	async function worker() {
		while (true) {
			const i = cursor++;
			if (i >= items.length) return;
			out[i] = await fn(items[i], i);
		}
	}
	await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
	return out;
}
var getLiveFeed_createServerFn_handler = createServerRpc({
	id: "03680a4bc38a14268985ffe4b039daa8cdcd066f7c024322c3c45abd44d863b1",
	name: "getLiveFeed",
	filename: "src/lib/fotmob/api.ts"
}, (opts) => getLiveFeed.__executeServer(opts));
var getLiveFeed = createServerFn({ method: "POST" }).handler(getLiveFeed_createServerFn_handler, async () => {
	try {
		let matches = parseMatchList(await fotmobGet("/matches?ccode3=PRT", 12e3));
		matches = matches.slice(0, CONFIG.MAX_LIVE);
		if (!matches.length) return {
			ok: true,
			source: "fotmob",
			items: [],
			fetchedAt: Date.now()
		};
		return {
			ok: true,
			source: "fotmob",
			items: await poolMap(matches, CONFIG.STATS_CONCURRENCY, async (match) => {
				try {
					const details = await fotmobGet(`/matchDetails?matchId=${match.id}`, 9e3);
					const stats = parseMatchStats(details);
					const graph = parseMomentum(details);
					const events = parseEvents(details);
					const clock = parseHeaderClock(details);
					const score = parseHeaderScore(details);
					if (clock) {
						match.minute = clock.minute;
						match.minuteDisplay = clock.display;
						match.period = clock.period;
					}
					if (score) match.score.fullTime = score;
					match.events = events;
					match.htScore = htScoreFromEvents(events, match.score.fullTime);
					return {
						match,
						stats: stats.sourceVerified ? stats : stats.dataCompleteness > 8 ? stats : null,
						graph: graph.length ? graph : null
					};
				} catch {
					return {
						match,
						stats: null,
						graph: null
					};
				}
			}),
			fetchedAt: Date.now()
		};
	} catch (err) {
		return {
			ok: false,
			source: "none",
			items: [],
			error: err instanceof Error ? err.message : "Falha ao obter jogos ao vivo",
			fetchedAt: Date.now()
		};
	}
});
//#endregion
export { getLiveFeed_createServerFn_handler };
