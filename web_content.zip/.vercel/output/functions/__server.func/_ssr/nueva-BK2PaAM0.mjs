import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as sameName, s as uid } from "./text-CqN-AAxZ.mjs";
import { a as Segmented, i as PageHeader, n as Field, o as useForge, t as Button } from "./ui-buLXhEze.mjs";
import { a as createCampaign, i as blankCharacter, l as suggestCast, r as applyNarration, s as narrateTurn, t as DEFAULT_BOUNDARIES } from "./narrate-Dlb48ySq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nueva-BK2PaAM0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TONES = [
	"Íntimo y contenido, con silencios que pesan.",
	"Aventura en la que cada favor cobra un precio.",
	"Intriga: nadie dice de primeras lo que quiere."
];
var PROSE = [
	{
		id: "breve",
		label: "Breve"
	},
	{
		id: "equilibrada",
		label: "Media"
	},
	{
		id: "literaria",
		label: "Literaria"
	}
];
var AUTONOMY = [
	{
		id: "contenida",
		label: "Contenida"
	},
	{
		id: "viva",
		label: "Viva"
	},
	{
		id: "impredecible",
		label: "Abierta"
	}
];
function emptyDraft() {
	return {
		title: "",
		universe: "",
		premise: "",
		tone: "",
		rules: "",
		boundaries: DEFAULT_BOUNDARIES,
		prose: "equilibrada",
		autonomy: "viva",
		oc: {
			name: "",
			pronouns: "",
			appearance: "",
			voice: "",
			background: "",
			goal: "",
			trait: ""
		},
		places: [{
			id: "lugar-inicial",
			name: "",
			note: ""
		}],
		cast: [],
		opening: ""
	};
}
function Forge() {
	const navigate = useNavigate();
	const upsert = useForge((state) => state.upsert);
	const [step, setStep] = (0, import_react.useState)(0);
	const [draft, setDraft] = (0, import_react.useState)(emptyDraft);
	const [pending, setPending] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [savedId, setSavedId] = (0, import_react.useState)(null);
	const [confirmCast, setConfirmCast] = (0, import_react.useState)(false);
	const lock = (0, import_react.useRef)(false);
	const patch = (partial) => setDraft((current) => ({
		...current,
		...partial
	}));
	async function forgeCast(force = false) {
		if (!force && draft.cast.some((character) => character.name.trim())) {
			setConfirmCast(true);
			return;
		}
		if (lock.current) return;
		lock.current = true;
		setPending("reparto");
		setError(null);
		setConfirmCast(false);
		try {
			const response = await suggestCast({ data: {
				universe: draft.universe,
				premise: draft.premise,
				tone: draft.tone,
				rules: draft.rules,
				ocName: draft.oc.name,
				boundaries: draft.boundaries
			} });
			if (!response.ok) {
				setError(response.error);
				return;
			}
			applySuggestion(response.suggestion);
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo forjar el reparto.");
		} finally {
			lock.current = false;
			setPending(null);
		}
	}
	function applySuggestion(suggestion) {
		if (suggestion.reparto.length === 0 && suggestion.lugares.length === 0) return;
		const places = suggestion.lugares.length > 0 ? suggestion.lugares.map((place) => ({
			id: uid(),
			name: place.nombre,
			note: place.nota
		})) : draft.places;
		const cast = suggestion.reparto.filter((person) => !sameName(person.nombre, draft.oc.name)).map((person) => blankCharacter({
			name: person.nombre,
			role: person.rol,
			appearance: person.apariencia,
			personality: person.personalidad,
			voice: person.voz,
			knowledge: person.conocimientos,
			motivations: person.motivaciones,
			limits: person.limites,
			goal: person.objetivo,
			secret: person.secreto,
			place: person.lugar,
			agenda: "Sigue el objetivo de su ficha."
		}));
		patch({
			places,
			cast,
			title: draft.title.trim() || suggestion.titulo
		});
	}
	function validate(index) {
		if (index === 0 && draft.premise.trim().length < 12 && draft.universe.trim().length < 2) return "Escribe el universo o una premisa de al menos una frase.";
		if (index === 1 && draft.oc.name.trim().length < 2) return "Tu personaje necesita un nombre.";
		return null;
	}
	async function ignite() {
		if (lock.current) return;
		const problem = validate(0) || validate(1);
		if (problem) {
			setError(problem);
			return;
		}
		lock.current = true;
		const existing = savedId ? useForge.getState().campaigns.find((item) => item.id === savedId) : void 0;
		const fresh = createCampaign(draft);
		const campaign = existing ? {
			...fresh,
			id: existing.id,
			createdAt: existing.createdAt,
			entries: existing.entries,
			memories: existing.memories,
			chronicle: existing.chronicle,
			undo: null
		} : fresh;
		upsert(campaign);
		setSavedId(campaign.id);
		setPending("escena");
		setError(null);
		try {
			const response = await narrateTurn({ data: {
				mode: "apertura",
				playerText: draft.opening.trim(),
				campaign: {
					...campaign,
					undo: null
				}
			} });
			if (!response.ok) {
				setError(response.error);
				return;
			}
			const next = applyNarration(campaign, response.result, {
				mode: "apertura",
				playerText: draft.opening.trim()
			});
			upsert(next);
			await navigate({
				to: "/partida/$id",
				params: { id: campaign.id }
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo encender la escena.");
		} finally {
			lock.current = false;
			setPending(null);
		}
	}
	async function saveOnly() {
		if (lock.current) return;
		const problem = validate(0) || validate(1);
		if (problem) {
			setError(problem);
			return;
		}
		lock.current = true;
		const existing = savedId ? useForge.getState().campaigns.find((item) => item.id === savedId) : void 0;
		const fresh = createCampaign(draft);
		const campaign = existing ? {
			...fresh,
			id: existing.id,
			createdAt: existing.createdAt,
			undo: null
		} : fresh;
		upsert(campaign);
		try {
			await navigate({
				to: "/partida/$id",
				params: { id: campaign.id }
			});
		} finally {
			lock.current = false;
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-2xl flex-col gap-5 px-4 py-2 pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { back: {
				to: "/",
				label: "Biblioteca"
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-ember",
					children: [
						"Paso ",
						step + 1,
						" de 4"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl",
					children: step === 0 ? "El mundo" : step === 1 ? "Tu personaje" : step === 2 ? "Quiénes lo habitan" : "Cómo se cuenta"
				})]
			}),
			step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Título de la partida",
						hint: "Puede quedar vacío: se usa el universo.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rf-field",
							value: draft.title,
							onChange: (event) => patch({ title: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Universo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rf-field",
							value: draft.universe,
							placeholder: "Una ciudad portuaria sin mapas fiables",
							onChange: (event) => patch({ universe: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Premisa",
						hint: "Dónde empieza la presión. No es la escena todavía.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "rf-field",
							value: draft.premise,
							onChange: (event) => patch({ premise: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tono",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "rf-field",
							value: draft.tone,
							onChange: (event) => patch({ tone: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: TONES.map((tone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-full bg-panel px-3 text-left text-sm text-mist",
							onClick: () => patch({ tone }),
							children: tone
						}, tone))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Reglas",
						hint: "Qué es posible, qué cuesta caro, qué no existe.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "rf-field",
							value: draft.rules,
							onChange: (event) => patch({ rules: event.target.value })
						})
					})
				]
			}) : null,
			step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nombre",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rf-field",
							value: draft.oc.name,
							onChange: (event) => patch({ oc: {
								...draft.oc,
								name: event.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Pronombres",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rf-field",
							value: draft.oc.pronouns,
							onChange: (event) => patch({ oc: {
								...draft.oc,
								pronouns: event.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Apariencia",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "rf-field",
							value: draft.oc.appearance,
							onChange: (event) => patch({ oc: {
								...draft.oc,
								appearance: event.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Manera de hablar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rf-field",
							value: draft.oc.voice,
							onChange: (event) => patch({ oc: {
								...draft.oc,
								voice: event.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "De dónde viene",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "rf-field",
							value: draft.oc.background,
							onChange: (event) => patch({ oc: {
								...draft.oc,
								background: event.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Qué quiere ahora",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "rf-field",
							value: draft.oc.goal,
							onChange: (event) => patch({ oc: {
								...draft.oc,
								goal: event.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Un rasgo que no negocia",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rf-field",
							value: draft.oc.trait,
							onChange: (event) => patch({ oc: {
								...draft.oc,
								trait: event.target.value
							} })
						})
					})
				]
			}) : null,
			step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mist",
						children: "Puedes dejar el reparto vacío y que alguien surja en la escena, o forjarlo desde la premisa. Eso llama al narrador una vez y puedes editarlo antes de empezar."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							disabled: pending !== null || draft.premise.trim().length < 12,
							onClick: () => void forgeCast(false),
							children: pending === "reparto" ? "Forjando…" : "Forjar reparto"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => patch({ cast: [...draft.cast, blankCharacter({ place: draft.places[0]?.name ?? "" })] }),
							children: "Añadir a mano"
						})]
					}),
					confirmCast ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rf-card grid gap-2 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: "Ya hay nombres escritos. Forjar de nuevo los sustituye."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									forgeCast(true);
								},
								children: "Sustituir"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setConfirmCast(false),
								children: "Conservar"
							})]
						})]
					}) : null,
					draft.places.map((place, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: index === 0 ? "Lugar" : `Lugar ${index + 1}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "rf-field",
								value: place.name,
								onChange: (event) => patch({ places: draft.places.map((item) => item.id === place.id ? {
									...item,
									name: event.target.value
								} : item) })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rf-field",
							"aria-label": "Nota del lugar",
							placeholder: "Qué se nota al entrar",
							value: place.note,
							onChange: (event) => patch({ places: draft.places.map((item) => item.id === place.id ? {
								...item,
								note: event.target.value
							} : item) })
						})]
					}, place.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "w-fit",
						onClick: () => patch({ places: [...draft.places, {
							id: uid(),
							name: "",
							note: ""
						}] }),
						children: "Otro lugar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-3",
						children: draft.cast.map((character) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rf-card grid gap-3 p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Nombre",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "rf-field",
										value: character.name,
										onChange: (event) => updateCast(draft, patch, character.id, { name: event.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Rol",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "rf-field",
										value: character.role,
										onChange: (event) => updateCast(draft, patch, character.id, { role: event.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Quiere",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										className: "rf-field",
										value: character.goal,
										onChange: (event) => updateCast(draft, patch, character.id, { goal: event.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Secreto",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										className: "rf-field",
										value: character.secret,
										onChange: (event) => updateCast(draft, patch, character.id, { secret: event.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Dónde está",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "rf-field",
										value: character.place,
										onChange: (event) => updateCast(draft, patch, character.id, { place: event.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									className: "w-fit",
									onClick: () => patch({ cast: draft.cast.filter((item) => item.id !== character.id) }),
									children: "Quitar"
								})
							]
						}, character.id))
					})
				]
			}) : null,
			step === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Límites de la mesa",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "rf-field",
							value: draft.boundaries,
							onChange: (event) => patch({ boundaries: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
						label: "Prosa",
						value: draft.prose,
						options: PROSE,
						onChange: (prose) => patch({ prose })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
						label: "Autonomía del mundo",
						value: draft.autonomy,
						options: AUTONOMY,
						onChange: (autonomy) => patch({ autonomy })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Primer gesto, si quieres darlo ya",
						hint: "Opcional. El narrador no añadirá palabras a tu personaje.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "rf-field",
							maxLength: 2e3,
							value: draft.opening,
							onChange: (event) => patch({ opening: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mist",
						children: "Encender llama al narrador una vez. Si falla, la partida queda guardada para reintentar."
					})
				]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ember",
				role: "alert",
				children: error
			}) : null,
			savedId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 text-left text-sm text-ember",
				onClick: () => void navigate({
					to: "/partida/$id",
					params: { id: savedId }
				}),
				children: "Ir a la partida y reintentar"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					disabled: pending !== null,
					onClick: () => setStep((value) => value - 1),
					children: "Atrás"
				}) : null, step < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: pending !== null,
					onClick: () => {
						const problem = validate(step);
						if (problem) {
							setError(problem);
							return;
						}
						setError(null);
						setStep((value) => value + 1);
					},
					children: "Seguir"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: pending !== null,
					onClick: () => void ignite(),
					children: pending === "escena" ? "Encendiendo…" : "Encender la historia"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					disabled: pending !== null,
					onClick: () => void saveOnly(),
					children: "Solo guardar"
				})] })]
			})
		]
	});
}
function updateCast(draft, patch, id, partial) {
	patch({ cast: draft.cast.map((character) => character.id === id ? {
		...character,
		...partial
	} : character) });
}
var SplitComponent = Forge;
//#endregion
export { SplitComponent as component };
