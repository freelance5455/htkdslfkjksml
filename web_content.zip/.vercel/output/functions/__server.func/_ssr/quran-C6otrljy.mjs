import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Search } from "../_libs/lucide-react.mjs";
import { t as BackButton } from "./back-button-DImimZOp.mjs";
import { c as normalizeArabic, l as toArabicDigits, r as TopBar, t as AppShell } from "./app-shell-C4IrQdCN.mjs";
import { u as quranMeta } from "./catalog-CjAfWU9w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quran-C6otrljy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuranIndex() {
	const [q, setQ] = (0, import_react.useState)("");
	const list = (0, import_react.useMemo)(() => {
		const n = normalizeArabic(q);
		if (!n) return quranMeta.surahs;
		return quranMeta.surahs.filter((s) => normalizeArabic(s.name).includes(n) || normalizeArabic(s.shortName).includes(n) || s.englishName.toLowerCase().includes(q.toLowerCase()) || String(s.id) === q);
	}, [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: "القرآن الكريم",
			back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 rounded-2xl bg-card px-3 py-2 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "ابحث عن سورة",
					className: "h-10 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 divide-y divide-border px-2 pb-6",
			children: list.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/quran/$surahId",
				params: { surahId: String(s.id) },
				className: "flex items-center gap-3 px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-10 items-center justify-center rounded-lg border border-border font-quran text-sm text-accent",
					children: toArabicDigits(s.id)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-quran text-lg leading-none",
						children: s.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-[11px] text-muted-foreground",
						children: [
							s.type,
							" · ",
							toArabicDigits(s.count),
							" آية · ص ",
							toArabicDigits(s.page)
						]
					})]
				})]
			}) }, s.id))
		})
	] });
}
//#endregion
export { QuranIndex as component };
