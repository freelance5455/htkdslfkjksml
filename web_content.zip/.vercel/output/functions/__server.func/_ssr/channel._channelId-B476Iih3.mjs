import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as require_jsx_runtime, n as useQuery, t as useInfiniteQuery } from "../_libs/react+tanstack__react-query.mjs";
import { i as Button, n as Route, o as formatCount, r as ErrorBoundary } from "./router-D8sFVTug.mjs";
import { h as ArrowLeft, u as LoaderCircle } from "../_libs/lucide-react.mjs";
import { a as POST_SORTS, c as PostCard, d as SubscribeButton, h as getChannelPostsFn, l as PostCardSkeleton, m as getChannelFn, o as POST_TYPES, p as TYPE_FILTER, r as ChipBar, s as PageFrame, t as Badge, u as PullToRefresh, v as sortPosts, y as useSentinel } from "./topics-Bb1SXlXD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/channel._channelId-B476Iih3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChannelPage() {
	const { channelId } = Route.useParams();
	const [sort, setSort] = (0, import_react.useState)("newest");
	const [type, setType] = (0, import_react.useState)("all");
	const channelQuery = useQuery({
		queryKey: ["channel", channelId],
		queryFn: () => getChannelFn({ data: { id: channelId } }),
		retry: 1
	});
	const postsQuery = useInfiniteQuery({
		queryKey: ["channel-posts", channelId],
		initialPageParam: null,
		queryFn: async ({ pageParam }) => getChannelPostsFn({ data: {
			channelId,
			continuation: pageParam
		} }),
		getNextPageParam: (last, pages) => {
			const token = last.continuation ?? void 0;
			if (!token) return void 0;
			if (pages.some((p, i) => i < pages.length - 1 && p.continuation === token)) return;
			return token;
		},
		retry: 1
	});
	const channel = channelQuery.data ?? postsQuery.data?.pages[0]?.channel ?? null;
	const posts = (0, import_react.useMemo)(() => {
		const seen = /* @__PURE__ */ new Set();
		const list = [];
		for (const page of postsQuery.data?.pages ?? []) for (const post of page.posts) {
			if (seen.has(post.id)) continue;
			seen.add(post.id);
			list.push(post);
		}
		const kind = type === "all" ? void 0 : TYPE_FILTER[type];
		const typed = kind ? list.filter((p) => p.kind === kind) : list;
		return sortPosts(typed, sort);
	}, [
		postsQuery.data,
		sort,
		type
	]);
	const hasPostsTab = postsQuery.data?.pages[0]?.hasPostsTab ?? channel?.hasPostsTab ?? posts.length > 0;
	const sentinel = (0, import_react.useRef)(null);
	const { hasNextPage, isFetchingNextPage, isFetching, fetchNextPage, isLoading: postsLoading, refetch: refetchPosts } = postsQuery;
	const loadMore = (0, import_react.useCallback)(() => {
		if (hasNextPage && !isFetchingNextPage && !isFetching) fetchNextPage();
	}, [
		fetchNextPage,
		hasNextPage,
		isFetching,
		isFetchingNextPage
	]);
	useSentinel(sentinel, Boolean(hasNextPage && !isFetchingNextPage), loadMore);
	const summary = channel ? {
		id: channel.id,
		title: channel.title,
		handle: channel.handle,
		description: channel.description,
		thumbnail: channel.thumbnail,
		subscriberCount: channel.subscriberCount,
		subscriberText: channel.subscriberText,
		videoCount: channel.videoCount,
		videoText: channel.videoText,
		verified: channel.verified,
		hasPostsTab
	} : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 min-w-0 flex-1 flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "icon",
						variant: "ghost",
						"aria-label": "Back",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-display text-base font-semibold",
							children: channel?.title ?? "Channel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: "Community"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipBar, {
					ariaLabel: "Post type",
					items: POST_TYPES,
					value: type,
					onChange: setType
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipBar, {
					ariaLabel: "Sort posts",
					items: POST_SORTS,
					value: sort,
					onChange: setSort
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PullToRefresh, {
			onRefresh: async () => {
				await Promise.all([channelQuery.refetch(), refetchPosts()]);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-2xl px-4 pb-24 pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ErrorBoundary, { children: [
					channelQuery.isLoading && !channel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-5 rounded-2xl border border-border bg-card p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-16 animate-pulse rounded-full bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 space-y-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-40 animate-pulse rounded bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-28 animate-pulse rounded bg-muted" })]
							})]
						})
					}) : summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-5 rounded-2xl border border-border bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [summary.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: summary.thumbnail,
									alt: "",
									className: "size-16 rounded-full object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-16 items-center justify-center rounded-full bg-muted text-xl font-medium",
									children: summary.title.slice(0, 1)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
												className: "font-display text-lg font-semibold leading-tight",
												children: summary.title
											}), summary.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Verified" }) : null]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-0.5 text-sm text-muted-foreground",
											children: [summary.handle ? `${summary.handle} · ` : "", summary.subscriberText || `${formatCount(summary.subscriberCount)} subscribers`]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubscribeButton, {
												channel: summary,
												size: "default"
											})
										})
									]
								})]
							}),
							summary.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 line-clamp-4 text-sm leading-relaxed text-muted-foreground",
								children: summary.description
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-1.5",
								children: [hasPostsTab ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Community tab" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: "No Community tab"
								}), summary.subscriberCount === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: "0 subscribers"
								}) : null]
							})
						]
					}) : channelQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5 rounded-2xl border border-border bg-card px-5 py-8 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "Channel not found"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Try searching by @handle or paste a channel URL."
						})]
					}) : null,
					postsLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCardSkeleton, {}, i))
					}) : posts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card px-6 py-12 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-lg font-semibold",
							children: hasPostsTab ? "No Community posts yet" : "This channel has no Community tab"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-2 max-w-sm text-sm text-muted-foreground",
							children: "You can still subscribe. If they start posting, their updates will show here."
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, { post }, post.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: sentinel,
						className: "h-10"
					}),
					isFetchingNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-center py-6 text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" })
					}) : null
				] })
			})
		})]
	}) });
}
//#endregion
export { ChannelPage as component };
