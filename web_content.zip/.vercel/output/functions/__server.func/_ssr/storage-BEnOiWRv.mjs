import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as HardDrive } from "../_libs/lucide-react.mjs";
import { n as ScreenBody, t as AppShell } from "./app-shell-BNnfZJ-W.mjs";
import { i as ScreenHeader, n as InfoRow, r as Panel, t as IconBadge } from "./screen-header-3v0iR4cd.mjs";
import { r as readStorage } from "./web-device-D_Jv2ve6.mjs";
import { n as formatBytes } from "./utils-Cfx5sVK6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/storage-BEnOiWRv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StoragePage() {
	const [storage, setStorage] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		readStorage().then(setStorage);
	}, []);
	const fraction = storage && storage.totalBytes > 0 ? storage.usedBytes / storage.totalBytes : 0;
	const usedPct = Math.round(fraction * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Storage Info",
			subtitle: "This preview shows browser storage. The Android app shows real phone storage."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBadge, {
				className: "bg-sky/15 text-sky",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-4xl font-bold tabular-nums tracking-tight text-fg",
				children: storage ? `${usedPct}% used` : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: storage ? `${formatBytes(storage.freeBytes)} free` : "Reading storage…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 h-2.5 overflow-hidden rounded-full bg-primary/15",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full rounded-full bg-primary transition-[width] duration-300 ease-out",
					style: { width: `${usedPct}%` }
				})
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3.5 flex flex-col gap-2.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Total storage",
					value: storage ? formatBytes(storage.totalBytes) : "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Used storage",
					value: storage ? formatBytes(storage.usedBytes) : "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Free storage",
					value: storage ? formatBytes(storage.freeBytes) : "..."
				})
			]
		})
	] }) });
}
//#endregion
export { StoragePage as component };
