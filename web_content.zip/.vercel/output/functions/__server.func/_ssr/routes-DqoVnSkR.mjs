import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SlidersHorizontal, c as Settings, d as Minus, f as MessageCircle, h as ArrowUp, l as Search, m as Heart, n as UserRound, o as ShoppingBag, p as House, r as Truck, s as ShieldCheck, t as X, u as Plus } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DqoVnSkR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT_UI = {
	c1: "#0b6b4a",
	c2: "#c9a24b",
	rad: 18,
	splash: true,
	dur: 2,
	hero: true,
	bar: true,
	cols: 168
};
var STATUSES = [
	"pending",
	"confirmed",
	"processing",
	"shipped",
	"delivered",
	"cancelled"
];
var BN_DIGITS = "০১২৩৪৫৬৭৮৯";
var SEED_CATEGORIES = [
	{
		id: "grocery",
		emoji: "🛒",
		en: "Grocery & Daily Essentials",
		bn: "মুদি ও নিত্যপ্রয়োজনীয়"
	},
	{
		id: "medicine",
		emoji: "💊",
		en: "Medicine & Healthcare",
		bn: "ঔষধ ও স্বাস্থ্য"
	},
	{
		id: "beauty",
		emoji: "💄",
		en: "Cosmetics & Beauty",
		bn: "কসমেটিক্স ও বিউটি"
	},
	{
		id: "baby",
		emoji: "🍼",
		en: "Baby Care & Diapers",
		bn: "বেবি কেয়ার ও ডায়াপার"
	},
	{
		id: "personal",
		emoji: "🧴",
		en: "Personal Care",
		bn: "ব্যক্তিগত যত্ন"
	},
	{
		id: "home",
		emoji: "🧽",
		en: "Home Care",
		bn: "হোম কেয়ার"
	}
];
var SEED_ROWS = [
	[
		"Basmati Rice 5kg",
		"বাসমতি চাল ৫কেজি",
		"grocery",
		"🍚",
		850,
		790,
		40
	],
	[
		"Soybean Oil 5L",
		"সয়াবিন তেল ৫লি.",
		"grocery",
		"🛢️",
		920,
		0,
		30
	],
	[
		"Napa Extra (OTC)",
		"নাপা এক্সট্রা (OTC)",
		"medicine",
		"💊",
		30,
		0,
		200
	],
	[
		"Saline Sachet",
		"স্যালাইন",
		"medicine",
		"🧂",
		10,
		0,
		300
	],
	[
		"Rose Face Cream",
		"রোজ ফেস ক্রিম",
		"beauty",
		"🌹",
		450,
		390,
		25
	],
	[
		"Lipstick Matte",
		"ম্যাট লিপস্টিক",
		"beauty",
		"💄",
		350,
		0,
		18
	],
	[
		"Diapers M 40pc",
		"ডায়াপার M ৪০পিস",
		"baby",
		"🍼",
		1150,
		1050,
		22
	],
	[
		"Baby Lotion",
		"বেবি লোশন",
		"baby",
		"🧴",
		380,
		0,
		35
	],
	[
		"Shampoo 400ml",
		"শ্যাম্পু ৪০০মিলি",
		"personal",
		"🧴",
		420,
		370,
		50
	],
	[
		"Toothpaste",
		"টুথপেস্ট",
		"personal",
		"🪥",
		120,
		0,
		80
	],
	[
		"Floor Cleaner 1L",
		"ফ্লোর ক্লিনার ১লি.",
		"home",
		"🧽",
		280,
		0,
		45
	],
	[
		"Dish Wash 750ml",
		"ডিশ ওয়াশ ৭৫০মিলি",
		"home",
		"🍽️",
		190,
		170,
		5
	]
];
function seedProducts() {
	return SEED_ROWS.map((r, i) => ({
		id: i + 1,
		en: r[0],
		bn: r[1],
		cat: r[2],
		img: r[3],
		price: r[4],
		disc: r[5],
		stock: r[6],
		feat: i === 0 || i === 6,
		photos: [],
		desc: ""
	}));
}
function defaultSettings() {
	return {
		brand: "FAMILY CARE BD",
		wa: "8801834923134",
		announce: "Free delivery over ৳1500 · Madaripur",
		fee: 60,
		free: 1500,
		addr: "Madaripur, Bangladesh",
		tag: "Shop Smart · Live Better",
		about: "",
		delv: "",
		priv: "",
		terms: "",
		foot: "",
		ui: { ...DEFAULT_UI }
	};
}
function seedCoupons() {
	return [{
		code: "CARE10",
		type: "percent",
		value: 10,
		min: 500,
		max: 150,
		limit: 0,
		exp: "",
		active: true,
		used: 0
	}];
}
var DICT = {
	en: {
		shop: "Shop",
		acct: "Account",
		admin: "Admin",
		cart: "Cart",
		all: "All",
		search: "Search products…",
		add: "Add",
		empty: "Nothing here yet",
		total: "Total",
		sub: "Subtotal",
		del: "Delivery",
		name: "Name",
		phone: "Mobile (01XXXXXXXXX)",
		addr: "Full address",
		pay: "Payment",
		place: "Place order & open WhatsApp",
		coins: "Coins",
		use: "Use 1000 coins (−৳10)",
		orders: "Orders",
		products: "Products",
		site: "Site",
		dash: "Dashboard",
		rev: "Revenue",
		pend: "Pending",
		cust: "Customers",
		low: "Low stock",
		save: "Save",
		login: "Login",
		logout: "Log out",
		stock: "Stock",
		out: "Out of stock",
		guest: "Guest session on this device. Orders are sent to the shop on WhatsApp.",
		status: "Status",
		newp: "New product",
		price: "Price",
		disc: "Discount price",
		cat: "Category",
		feat: "Featured",
		langBtn: "বাংলা",
		guestlogin: "Continue as guest",
		theme: "Theme",
		cats: "Categories",
		cpn: "Coupons",
		sort: "Sort",
		pa: "Price low to high",
		pd: "Price high to low",
		big: "Biggest discount",
		fast: "Fast delivery",
		genuine: "Genuine products",
		wa: "WhatsApp support",
		our: "Our products",
		byCat: "Shop by category",
		recent: "Recently viewed",
		related: "Related",
		inStock: "In stock",
		coupon: "Coupon code",
		apply: "Apply",
		couponOk: "Coupon applied",
		couponBad: "Invalid coupon",
		viewCart: "View cart",
		item: "item",
		items: "items",
		added: "Added",
		check: "Check name, phone and address",
		blocked: "Account blocked",
		savedOrder: "Order saved",
		openWa: "Open WhatsApp",
		waHint: "Order saved on this device. Tap to send it on WhatsApp.",
		unpaid: "bKash and Nagad stay unpaid until the shop confirms.",
		about: "About us",
		delivery: "Delivery",
		privacy: "Privacy policy",
		terms: "Terms & conditions",
		designed: "Designed & developed by",
		only: "Only",
		left: "left",
		tryCoupon: "Try CARE10",
		clear: "Clear filters",
		noMatch: "No products match",
		signIn: "Admin sign-in",
		user: "Username",
		password: "Password",
		defaultPw: "Default password (admin / admin) is still active. Change it in Site.",
		tooMany: "Too many attempts",
		badLogin: "Invalid login",
		changePw: "Change password",
		saved: "Saved",
		resetLook: "Reset look",
		resetData: "Reset all data",
		exportCsv: "Export orders CSV",
		backup: "Backup JSON",
		restore: "Restore",
		removeSamples: "Remove sample products",
		markPaid: "Mark paid",
		unmarkPaid: "Unmark paid",
		completed: "Completed",
		cancelled: "Cancelled",
		look: "Look",
		brand: "Brand",
		announce: "Announcement",
		tagline: "Tagline",
		logo: "Logo",
		banner: "Homepage banner",
		footer: "Footer text",
		waNum: "WhatsApp (country code, no +)",
		fee: "Delivery fee",
		freeOver: "Free delivery over",
		min6: "At least 6 characters, and both fields must match",
		photos: "Photos (up to 6)",
		emoji: "Emoji if there is no photo",
		desc: "Description",
		enName: "English name",
		bnName: "বাংলা নাম",
		active: "Active",
		code: "Code",
		type: "Type",
		value: "Value",
		minOrder: "Minimum order ৳",
		maxDisc: "Max discount ৳ (percent only, 0 = none)",
		limit: "Usage limit (0 = unlimited)",
		used: "Used so far",
		expiry: "Expiry date",
		enable: "Enable",
		disable: "Disable",
		copy: "Copy",
		resetUsed: "Reset uses",
		delete: "Delete",
		reason: "Reason",
		amount: "Coins +/−",
		block: "Block",
		unblock: "Unblock",
		live: "Live",
		print: "Print",
		off: "Off",
		expired: "Expired",
		limitHit: "Limit reached",
		percent: "Percent %",
		fixed: "Fixed ৳",
		onDevice: "Catalog, orders and the admin password stay in this browser. Checkout still messages the shop on WhatsApp.",
		coinHint: "1 coin per ৳100 delivered. 1000 coins = ৳10 off.",
		addrPh: "House, road, area",
		close: "Close",
		backTop: "Back to top",
		wish: "Saved",
		itemsWord: "items",
		paid: "Paid",
		unpaidWord: "Unpaid",
		newCat: "New category",
		edit: "Edit",
		useDefault: "Use default logo",
		splash: "Loading screen",
		splashTime: "Loading time",
		showHero: "Show hero",
		showBar: "Show announcement",
		mainColor: "Main color",
		accent: "Accent color",
		radius: "Corner roundness",
		cardW: "Product card width",
		pwNew: "New password",
		pwAgain: "Repeat password",
		confirmReset: "Reset all shop data on this device?",
		confirmDel: "Delete this?",
		confirmSamples: "Remove the 12 sample products?",
		confirmUsed: "Reset used count to 0?",
		nameNeed: "Enter a product name",
		priceNeed: "Regular price must be more than 0",
		discNeed: "Discount must be lower than the regular price",
		stockNeed: "Enter a valid stock count",
		codeNeed: "Code needs at least 3 letters or numbers",
		codeDup: "That code already exists",
		valueNeed: "Enter a discount value",
		pctMax: "Percent cannot be over 100",
		coinNeed: "Amount and reason are required",
		coinLow: "Balance would go below zero",
		catBusy: "That category still has products",
		imgBad: "Use a JPG or PNG photo",
		storage: "Storage is full — use fewer or smaller photos",
		restored: "Backup restored",
		badBackup: "That backup file could not be read",
		pwChanged: "Password changed",
		freeYes: "Free delivery unlocked",
		moreFree: "more for free delivery",
		addWord: "Add",
		qty: "Quantity"
	},
	bn: {
		shop: "শপ",
		acct: "অ্যাকাউন্ট",
		admin: "অ্যাডমিন",
		cart: "কার্ট",
		all: "সব",
		search: "পণ্য খুঁজুন…",
		add: "যোগ",
		empty: "এখানে কিছু নেই",
		total: "মোট",
		sub: "সাবটোটাল",
		del: "ডেলিভারি",
		name: "নাম",
		phone: "মোবাইল (01XXXXXXXXX)",
		addr: "পূর্ণ ঠিকানা",
		pay: "পেমেন্ট",
		place: "অর্ডার করুন ও হোয়াটসঅ্যাপ খুলুন",
		coins: "কয়েন",
		use: "১০০০ কয়েন ব্যবহার (−৳১০)",
		orders: "অর্ডার",
		products: "পণ্য",
		site: "সাইট",
		dash: "ড্যাশবোর্ড",
		rev: "আয়",
		pend: "অপেক্ষমাণ",
		cust: "গ্রাহক",
		low: "কম স্টক",
		save: "সেভ",
		login: "লগইন",
		logout: "লগআউট",
		stock: "স্টক",
		out: "স্টক নেই",
		guest: "এই ডিভাইসে গেস্ট সেশন। অর্ডার দোকানের হোয়াটসঅ্যাপে যায়।",
		status: "স্ট্যাটাস",
		newp: "নতুন পণ্য",
		price: "দাম",
		disc: "ছাড়ের দাম",
		cat: "ক্যাটাগরি",
		feat: "ফিচার্ড",
		langBtn: "English",
		guestlogin: "গেস্ট হিসেবে চলুন",
		theme: "থিম",
		cats: "ক্যাটাগরি",
		cpn: "কুপন",
		sort: "সাজান",
		pa: "দাম কম থেকে বেশি",
		pd: "দাম বেশি থেকে কম",
		big: "বেশি ছাড়",
		fast: "দ্রুত ডেলিভারি",
		genuine: "আসল পণ্য",
		wa: "হোয়াটসঅ্যাপ সাপোর্ট",
		our: "আমাদের পণ্য",
		byCat: "ক্যাটাগরি",
		recent: "সম্প্রতি দেখা",
		related: "সম্পর্কিত পণ্য",
		inStock: "স্টকে আছে",
		coupon: "কুপন কোড",
		apply: "প্রয়োগ",
		couponOk: "কুপন প্রয়োগ হয়েছে",
		couponBad: "কুপন সঠিক নয়",
		viewCart: "কার্ট দেখুন",
		item: "টি পণ্য",
		items: "টি পণ্য",
		added: "যোগ হয়েছে",
		check: "নাম, ফোন ও ঠিকানা চেক করুন",
		blocked: "অ্যাকাউন্ট ব্লক",
		savedOrder: "অর্ডার সংরক্ষিত",
		openWa: "হোয়াটসঅ্যাপ খুলুন",
		waHint: "অর্ডার এই ডিভাইসে সংরক্ষিত। হোয়াটসঅ্যাপে পাঠাতে ট্যাপ করুন।",
		unpaid: "বিকাশ/নগদ অ্যাডমিন নিশ্চিত না করা পর্যন্ত অপরিশোধিত থাকবে।",
		about: "আমাদের সম্পর্কে",
		delivery: "ডেলিভারি",
		privacy: "গোপনীয়তা নীতি",
		terms: "শর্তাবলি",
		designed: "ডিজাইন ও ডেভেলপ করেছেন",
		only: "মাত্র",
		left: "বাকি",
		tryCoupon: "CARE10 ব্যবহার করুন",
		clear: "ফিল্টার মুছুন",
		noMatch: "কোনো পণ্য মেলেনি",
		signIn: "অ্যাডমিন সাইন-ইন",
		user: "ইউজারনেম",
		password: "পাসওয়ার্ড",
		defaultPw: "ডিফল্ট পাসওয়ার্ড (admin / admin) এখনও চালু। সাইট ট্যাবে বদলান।",
		tooMany: "অনেকবার চেষ্টা হয়েছে",
		badLogin: "লগইন সঠিক নয়",
		changePw: "পাসওয়ার্ড বদলান",
		saved: "সেভ হয়েছে",
		resetLook: "লুক রিসেট",
		resetData: "সব ডেটা রিসেট",
		exportCsv: "অর্ডার CSV",
		backup: "ব্যাকআপ JSON",
		restore: "রিস্টোর",
		removeSamples: "নমুনা পণ্য সরান",
		markPaid: "পেইড মার্ক",
		unmarkPaid: "পেইড তুলুন",
		completed: "সম্পন্ন",
		cancelled: "বাতিল",
		look: "চেহারা",
		brand: "ব্র্যান্ড",
		announce: "ঘোষণা",
		tagline: "ট্যাগলাইন",
		logo: "লোগো",
		banner: "হোম ব্যানার",
		footer: "ফুটার লেখা",
		waNum: "হোয়াটসঅ্যাপ (কান্ট্রি কোড, + ছাড়া)",
		fee: "ডেলিভারি ফি",
		freeOver: "এর বেশি হলে ফ্রি ডেলিভারি",
		min6: "কমপক্ষে ৬ অক্ষর, দুটি ঘর মিলতে হবে",
		photos: "ছবি (সর্বোচ্চ ৬)",
		emoji: "ছবি না থাকলে ইমোজি",
		desc: "বিবরণ",
		enName: "ইংরেজি নাম",
		bnName: "বাংলা নাম",
		active: "সক্রিয়",
		code: "কোড",
		type: "ধরন",
		value: "মান",
		minOrder: "ন্যূনতম অর্ডার ৳",
		maxDisc: "সর্বোচ্চ ছাড় ৳ (শতকরা, ০ = নেই)",
		limit: "ব্যবহার সীমা (০ = অসীম)",
		used: "এ পর্যন্ত ব্যবহৃত",
		expiry: "মেয়াদ",
		enable: "চালু",
		disable: "বন্ধ",
		copy: "কপি",
		resetUsed: "গণনা রিসেট",
		delete: "মুছুন",
		reason: "কারণ",
		amount: "কয়েন +/−",
		block: "ব্লক",
		unblock: "আনব্লক",
		live: "সচল",
		print: "প্রিন্ট",
		off: "বন্ধ",
		expired: "মেয়াদোত্তীর্ণ",
		limitHit: "লিমিট শেষ",
		percent: "শতকরা %",
		fixed: "ফিক্সড ৳",
		onDevice: "ক্যাটালগ, অর্ডার ও অ্যাডমিন পাসওয়ার্ড এই ব্রাউজারে থাকে। চেকআউট দোকানের হোয়াটসঅ্যাপে যায়।",
		coinHint: "ডেলিভারি হওয়া প্রতি ৳১০০ এ ১ কয়েন। ১০০০ কয়েন = ৳১০ ছাড়।",
		addrPh: "বাড়ি, রোড, এলাকা",
		close: "বন্ধ",
		backTop: "উপরে",
		wish: "সেভ",
		itemsWord: "পণ্য",
		paid: "পরিশোধিত",
		unpaidWord: "অপরিশোধিত",
		newCat: "নতুন ক্যাটাগরি",
		edit: "এডিট",
		useDefault: "ডিফল্ট লোগো",
		splash: "লোডিং স্ক্রিন",
		splashTime: "লোডিং সময়",
		showHero: "হিরো দেখান",
		showBar: "ঘোষণা বার",
		mainColor: "মূল রং",
		accent: "অ্যাকসেন্ট রং",
		radius: "কোণার গোলত্ব",
		cardW: "কার্ডের প্রস্থ",
		pwNew: "নতুন পাসওয়ার্ড",
		pwAgain: "আবার পাসওয়ার্ড",
		confirmReset: "এই ডিভাইসের সব শপ ডেটা মুছে ফেলবেন?",
		confirmDel: "মুছে ফেলবেন?",
		confirmSamples: "১২টি নমুনা পণ্য সরাবেন?",
		confirmUsed: "ব্যবহার গণনা ০ করবেন?",
		nameNeed: "পণ্যের নাম দিন",
		priceNeed: "নিয়মিত দাম ০-এর বেশি হতে হবে",
		discNeed: "ছাড়ের দাম নিয়মিত দামের চেয়ে কম হতে হবে",
		stockNeed: "স্টক সঠিক দিন",
		codeNeed: "কোড কমপক্ষে ৩ অক্ষর",
		codeDup: "এই কোড আগে থেকে আছে",
		valueNeed: "ছাড়ের মান দিন",
		pctMax: "শতকরা ১০০-এর বেশি নয়",
		coinNeed: "পরিমাণ ও কারণ লাগবে",
		coinLow: "ব্যালেন্স শূন্যের নিচে যাবে",
		catBusy: "এই ক্যাটাগরিতে পণ্য আছে",
		imgBad: "JPG বা PNG ব্যবহার করুন",
		storage: "স্টোরেজ পূর্ণ — ছোট ছবি ব্যবহার করুন",
		restored: "ব্যাকআপ ফিরে এসেছে",
		badBackup: "ব্যাকআপ ফাইল পড়া যায়নি",
		pwChanged: "পাসওয়ার্ড বদলেছে",
		freeYes: "ফ্রি ডেলিভারি আনলক",
		moreFree: "কিনলে ডেলিভারি ফ্রি",
		addWord: "আর",
		qty: "পরিমাণ"
	}
};
function t(lang, key) {
	return DICT[lang][key] ?? DICT.en[key];
}
var STATUS_BN = {
	pending: "অপেক্ষমাণ",
	confirmed: "নিশ্চিত",
	processing: "প্রস্তুত হচ্ছে",
	shipped: "পাঠানো হয়েছে",
	delivered: "পৌঁছেছে",
	cancelled: "বাতিল"
};
function statusLabel(status, lang) {
	if (lang === "bn") return STATUS_BN[status];
	return status.charAt(0).toUpperCase() + status.slice(1);
}
function toEnDigits(s) {
	return s.replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
}
function num(s) {
	const n = parseFloat(toEnDigits(String(s)).replace(/,/g, ""));
	return Number.isFinite(n) ? n : 0;
}
function normalizePhone(s) {
	return toEnDigits(s).replace(/\D/g, "");
}
function isBdMobile(p) {
	return /^01[3-9]\d{8}$/.test(p);
}
function fmt(n, lang) {
	const rounded = Math.round(n);
	try {
		return "৳" + rounded.toLocaleString(lang === "bn" ? "bn-BD" : "en-US");
	} catch {
		return "৳" + rounded.toLocaleString("en-US");
	}
}
function unitPrice(p) {
	return p.disc > 0 ? p.disc : p.price;
}
function discountPct(p) {
	if (!(p.disc > 0) || !(p.price > 0)) return 0;
	return Math.round((1 - p.disc / p.price) * 100);
}
function productName(p, lang) {
	return lang === "bn" ? p.bn || p.en : p.en || p.bn;
}
function catName(c, lang) {
	return lang === "bn" ? c.bn || c.en : c.en || c.bn;
}
function dhakaNow() {
	return new Date((/* @__PURE__ */ new Date()).toLocaleString("en-US", { timeZone: "Asia/Dhaka" }));
}
function resolvedTheme(mode) {
	if (mode !== "auto") return mode;
	const h = dhakaNow().getHours();
	return h >= 6 && h < 18 ? "light" : "dark";
}
function orderId() {
	const d = dhakaNow();
	return `FC${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}-${String(Math.floor(Math.random() * 900) + 100)}`;
}
function cartLines(products, cart) {
	return Object.entries(cart).map(([id, q]) => ({
		p: products.find((x) => String(x.id) === String(id)),
		q: Number(q) || 0
	})).filter((l) => Boolean(l.p) && l.q > 0);
}
function subtotal(lines) {
	return lines.reduce((a, l) => a + unitPrice(l.p) * l.q, 0);
}
function couponProblem(c, sub, lang) {
	if (!c.active) return t(lang, "off");
	if (c.exp && /* @__PURE__ */ new Date(`${c.exp}T23:59:59+06:00`) < /* @__PURE__ */ new Date()) return t(lang, "expired");
	if (c.limit > 0 && (c.used || 0) >= c.limit) return t(lang, "limitHit");
	if (sub < (c.min || 0)) return lang === "bn" ? `ন্যূনতম অর্ডার ${fmt(c.min || 0, lang)}` : `Minimum order ${fmt(c.min || 0, lang)}`;
	return "";
}
function couponOff(c, sub) {
	if (!c || couponProblem(c, sub, "en")) return 0;
	let d = c.type === "percent" ? sub * c.value / 100 : c.value;
	if (c.type === "percent" && c.max > 0) d = Math.min(d, c.max);
	return Math.min(Math.round(d), sub);
}
function totals(sub, fee, free, redeem, cd) {
	const delivery = sub === 0 || sub >= free ? 0 : Number(fee) || 0;
	const d = redeem ? 10 : 0;
	return {
		sub,
		fee: delivery,
		d,
		cd,
		tot: Math.max(0, sub + delivery - d - cd)
	};
}
function visibleProducts(products, opts) {
	const q = opts.q.trim().toLowerCase();
	let list = products.filter((p) => {
		if (opts.cat !== "all" && p.cat !== opts.cat) return false;
		if (opts.favOnly && !opts.wishlist.includes(p.id)) return false;
		if (!q) return true;
		return `${productName(p, opts.lang)} ${p.en} ${p.bn}`.toLowerCase().includes(q);
	});
	list = [...list];
	if (opts.sort === "pa") list.sort((a, b) => unitPrice(a) - unitPrice(b));
	if (opts.sort === "pd") list.sort((a, b) => unitPrice(b) - unitPrice(a));
	if (opts.sort === "d") list.sort((a, b) => discountPct(b) - discountPct(a));
	return list;
}
function waLink(phone, text) {
	return `https://wa.me/${phone.replace(/\D/g, "")}?text=${encodeURIComponent(text)}`;
}
function waBody(brand, o) {
	const lines = o.items.map((i) => `• ${i.en} x${i.q} = ৳${i.pr * i.q}`).join("\n");
	return `*${brand} – Order ${o.id}*\nName: ${o.name}\nPhone: ${o.phone}\nAddress: ${o.addr}\nPayment: ${o.pm}\n${lines}\nDelivery: ৳${o.fee}\nCoupon: -৳${o.cd || 0}${o.coupon ? ` (${o.coupon})` : ""}\nCoin discount: -৳${o.disc}\n*Total: ৳${o.total}*`;
}
function freeDeliveryCopy(lang, sub, free) {
	if (!(free > 0)) return "";
	const left = free - sub;
	if (left <= 0) return t(lang, "freeYes");
	return lang === "bn" ? `${t(lang, "addWord")} ${fmt(left, lang)} ${t(lang, "moreFree")}` : `${t(lang, "addWord")} ${fmt(left, lang)} ${t(lang, "moreFree")}`;
}
function normalizeProduct(raw) {
	if (!raw || typeof raw !== "object") return null;
	const p = raw;
	if (p.id == null || !p.en && !p.bn) return null;
	return {
		id: Number(p.id),
		en: String(p.en || p.bn || ""),
		bn: String(p.bn || p.en || ""),
		cat: String(p.cat || "grocery"),
		img: String(p.img || "📦"),
		price: Number(p.price) || 0,
		disc: Number(p.disc) || 0,
		stock: Math.max(0, Math.floor(Number(p.stock) || 0)),
		feat: Boolean(p.feat),
		photos: Array.isArray(p.photos) ? p.photos.filter((x) => typeof x === "string").slice(0, 6) : [],
		desc: String(p.desc || "")
	};
}
function normalizeCategory(raw) {
	if (Array.isArray(raw) && raw.length >= 4) return {
		id: String(raw[0]),
		emoji: String(raw[1] || "📦"),
		en: String(raw[2]),
		bn: String(raw[3])
	};
	if (raw && typeof raw === "object" && "id" in raw) {
		const c = raw;
		if (!c.id) return null;
		return {
			id: String(c.id),
			emoji: String(c.emoji || "📦"),
			en: String(c.en || c.id),
			bn: String(c.bn || c.en || c.id)
		};
	}
	return null;
}
function mergeSettings(base, raw) {
	const s = raw && typeof raw === "object" ? raw : {};
	const uiRaw = s.ui && typeof s.ui === "object" ? s.ui : {};
	return {
		...base,
		...s,
		brand: String(s.brand || base.brand),
		wa: String(s.wa || base.wa).replace(/\D/g, "") || base.wa,
		announce: s.announce != null ? String(s.announce) : base.announce,
		fee: Number(s.fee ?? base.fee) || 0,
		free: Number(s.free ?? base.free) || 0,
		addr: s.addr != null ? String(s.addr) : base.addr,
		tag: s.tag != null ? String(s.tag) : base.tag,
		about: String(s.about || ""),
		delv: String(s.delv || ""),
		priv: String(s.priv || ""),
		terms: String(s.terms || ""),
		foot: String(s.foot || ""),
		logo: typeof s.logo === "string" ? s.logo : base.logo,
		banner: typeof s.banner === "string" ? s.banner : base.banner,
		ui: {
			...DEFAULT_UI,
			...base.ui,
			...uiRaw
		}
	};
}
function legacyToPersisted(raw) {
	if (!raw || typeof raw !== "object") return null;
	const d = raw;
	if (d.state && typeof d.state === "object") return null;
	if (!Array.isArray(d.products)) return null;
	const products = d.products.map(normalizeProduct).filter((p) => Boolean(p));
	const categories = Array.isArray(d.cats) ? d.cats.map(normalizeCategory).filter((c) => Boolean(c)) : SEED_CATEGORIES;
	return {
		lang: "en",
		mode: "auto",
		me: null,
		wishlist: [],
		cart: {},
		recently: [],
		ship: null,
		products,
		categories: categories.length ? categories : SEED_CATEGORIES.map((c) => ({ ...c })),
		orders: Array.isArray(d.orders) ? d.orders : [],
		customers: d.customers && typeof d.customers === "object" ? d.customers : {},
		coupons: Array.isArray(d.coupons) ? d.coupons : [],
		settings: mergeSettings(defaultSettings(), d.settings)
	};
}
function ordersCsv(orders) {
	return [[
		"id",
		"name",
		"phone",
		"total",
		"status",
		"payment",
		"coupon",
		"address"
	], ...orders.map((o) => [
		o.id,
		o.name,
		o.phone,
		o.total,
		o.status,
		o.pm,
		o.coupon || "",
		o.addr
	])].map((row) => row.map((c) => `"${String(c).replace(/"/g, "\"\"")}"`).join(",")).join("\n");
}
function downloadText(name, data, mime = "text/plain") {
	const blob = new Blob([data], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	a.click();
	URL.revokeObjectURL(url);
}
function compressImage(file, max) {
	return new Promise((resolve, reject) => {
		if (file.type && !file.type.startsWith("image/") && !/\.(jpe?g|png|webp|gif|bmp)$/i.test(file.name || "")) {
			reject(/* @__PURE__ */ new Error("type"));
			return;
		}
		const fr = new FileReader();
		fr.onerror = () => reject(/* @__PURE__ */ new Error("read"));
		fr.onload = () => {
			const im = new Image();
			im.onload = () => {
				try {
					const w = im.naturalWidth || im.width;
					const h = im.naturalHeight || im.height;
					const k = Math.min(1, max / Math.max(w, h));
					const c = document.createElement("canvas");
					c.width = Math.max(1, Math.round(w * k));
					c.height = Math.max(1, Math.round(h * k));
					const x = c.getContext("2d");
					if (!x) {
						reject(/* @__PURE__ */ new Error("canvas"));
						return;
					}
					x.fillStyle = "#ffffff";
					x.fillRect(0, 0, c.width, c.height);
					x.drawImage(im, 0, 0, c.width, c.height);
					resolve(c.toDataURL("image/jpeg", .68));
				} catch {
					reject(/* @__PURE__ */ new Error("canvas"));
				}
			};
			im.onerror = () => reject(/* @__PURE__ */ new Error("image"));
			im.src = String(fr.result || "");
		};
		fr.readAsDataURL(file);
	});
}
async function digestPassword(pw) {
	const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`fcbd:${pw}`));
	return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
}
var PW_KEY = "fcbda";
async function passwordOk(user, pw) {
	if (user.trim() !== "admin") return false;
	const h = localStorage.getItem(PW_KEY);
	if (!h) return pw === "admin";
	return await digestPassword(pw) === h;
}
async function savePassword(pw) {
	localStorage.setItem(PW_KEY, await digestPassword(pw));
}
function customPasswordSet() {
	try {
		return Boolean(localStorage.getItem(PW_KEY));
	} catch {
		return false;
	}
}
var memory = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
var browserStorage = {
	getItem: (name) => {
		try {
			const cur = localStorage.getItem(name);
			if (cur) return cur;
			const legacy = localStorage.getItem("fcbd");
			if (!legacy) return null;
			const state = legacyToPersisted(JSON.parse(legacy));
			if (!state) return null;
			return JSON.stringify({
				state,
				version: 1
			});
		} catch {
			return null;
		}
	},
	setItem: (name, value) => {
		try {
			localStorage.setItem(name, value);
		} catch {
			queueMicrotask(() => {
				const s = useShop.getState();
				s.showToast(t(s.lang, "storage"));
			});
		}
	},
	removeItem: (name) => {
		try {
			localStorage.removeItem(name);
		} catch {}
	}
};
function initialData() {
	return {
		lang: "en",
		mode: "auto",
		me: null,
		wishlist: [],
		cart: {},
		recently: [],
		ship: null,
		products: seedProducts(),
		categories: SEED_CATEGORIES.map((c) => ({ ...c })),
		orders: [],
		customers: {},
		coupons: seedCoupons(),
		settings: defaultSettings()
	};
}
function cloneCustomer(c) {
	return {
		...c,
		ledger: c.ledger.map((e) => ({ ...e }))
	};
}
var useShop = create()(persist((set, get) => ({
	...initialData(),
	view: "shop",
	cat: "all",
	q: "",
	sort: "",
	favOnly: false,
	drawer: false,
	productId: null,
	qty: 1,
	photoIdx: 0,
	coupon: null,
	admin: false,
	unlocked: false,
	tab: "dash",
	toast: null,
	wa: null,
	showToast: (text) => set({ toast: {
		n: Date.now(),
		text
	} }),
	clearToast: () => set({ toast: null }),
	setLang: (lang) => set({ lang }),
	toggleLang: () => set({ lang: get().lang === "en" ? "bn" : "en" }),
	setMode: (mode) => set({ mode }),
	setView: (view) => set({
		view,
		drawer: false,
		productId: null
	}),
	setCat: (cat) => set({ cat }),
	setQuery: (q) => set({ q }),
	setSort: (sort) => set({ sort }),
	toggleFavOnly: () => set({ favOnly: !get().favOnly }),
	toggleWish: (id) => {
		const wl = get().wishlist;
		set({ wishlist: wl.includes(id) ? wl.filter((x) => x !== id) : [...wl, id] });
	},
	openProduct: (id) => {
		set({
			productId: id,
			qty: 1,
			photoIdx: 0,
			recently: [id, ...get().recently.filter((x) => x !== id)].slice(0, 8),
			drawer: false
		});
	},
	closeProduct: () => set({ productId: null }),
	setQty: (qty) => set({ qty }),
	bumpQty: (delta) => {
		const p = get().products.find((x) => x.id === get().productId);
		const max = Math.max(1, p?.stock || 1);
		set({ qty: Math.max(1, Math.min(max, get().qty + delta)) });
	},
	openCart: () => set({
		drawer: true,
		productId: null
	}),
	closeCart: () => set({ drawer: false }),
	addToCart: (id, qty = 1) => {
		const s = get();
		const p = s.products.find((x) => x.id === id);
		if (!p) return false;
		const key = String(id);
		const next = (s.cart[key] || 0) + qty;
		if (next > p.stock) {
			s.showToast(t(s.lang, "out"));
			return false;
		}
		set({ cart: {
			...s.cart,
			[key]: next
		} });
		return true;
	},
	changeQty: (id, delta) => {
		const s = get();
		const p = s.products.find((x) => x.id === id);
		if (!p) return;
		const key = String(id);
		const next = (s.cart[key] || 0) + delta;
		const cart = { ...s.cart };
		if (next <= 0) delete cart[key];
		else if (next > p.stock) {
			s.showToast(t(s.lang, "out"));
			return;
		} else cart[key] = next;
		set({ cart });
	},
	applyCoupon: (code, sub) => {
		const s = get();
		const clean = code.trim().toUpperCase();
		if (!clean) {
			set({ coupon: null });
			return;
		}
		const c = s.coupons.find((x) => x.code === clean);
		if (!c) {
			s.showToast(t(s.lang, "couponBad"));
			return;
		}
		const err = couponProblem(c, sub, s.lang);
		if (err) {
			s.showToast(err);
			return;
		}
		set({
			coupon: clean,
			toast: {
				n: Date.now(),
				text: t(s.lang, "couponOk")
			}
		});
	},
	clearCoupon: () => set({ coupon: null }),
	placeOrder: (input) => {
		const s = get();
		const name = input.name.trim();
		const phone = normalizePhone(input.phone);
		const addr = input.addr.trim();
		if (name.length < 2 || !isBdMobile(phone) || addr.length < 8) {
			s.showToast(t(s.lang, "check"));
			return false;
		}
		const lines = cartLines(s.products, s.cart);
		if (!lines.length) {
			s.showToast(t(s.lang, "empty"));
			return false;
		}
		for (const line of lines) if (line.q > line.p.stock) {
			s.showToast(`${t(s.lang, "out")}: ${line.p.en}`);
			return false;
		}
		const customers = { ...s.customers };
		const existing = customers[phone];
		const cu = existing ? cloneCustomer(existing) : {
			name,
			phone,
			coins: 0,
			ledger: [],
			blocked: false
		};
		if (cu.blocked) {
			s.showToast(t(s.lang, "blocked"));
			return false;
		}
		cu.name = name;
		const sub = subtotal(lines);
		let couponCode = s.coupon;
		const found = couponCode ? s.coupons.find((x) => x.code === couponCode) : void 0;
		if (couponCode && (!found || couponProblem(found, sub, s.lang))) {
			s.showToast(found ? couponProblem(found, sub, s.lang) : t(s.lang, "couponBad"));
			set({ coupon: null });
			return false;
		}
		const redeem = input.useCoins && cu.coins >= 1e3;
		const cd = couponOff(found, sub);
		const tt = totals(sub, s.settings.fee, s.settings.free, redeem, cd);
		if (redeem) {
			cu.coins -= 1e3;
			cu.ledger.push({
				t: Date.now(),
				n: -1e3,
				why: "Redeemed"
			});
		}
		const products = s.products.map((p) => {
			const line = lines.find((l) => l.p.id === p.id);
			return line ? {
				...p,
				stock: p.stock - line.q
			} : p;
		});
		const coupons = s.coupons.map((c) => ({ ...c }));
		if (couponCode) {
			const cc = coupons.find((x) => x.code === couponCode);
			if (cc) cc.used = (cc.used || 0) + 1;
		}
		const id = orderId();
		const order = {
			id,
			phone,
			name,
			addr,
			pm: input.pm,
			paid: false,
			status: "pending",
			items: lines.map((l) => ({
				id: l.p.id,
				en: l.p.en,
				q: l.q,
				pr: unitPrice(l.p)
			})),
			sub: tt.sub,
			fee: tt.fee,
			disc: tt.d,
			cd: tt.cd,
			coupon: tt.cd > 0 && couponCode ? couponCode : "",
			total: tt.tot,
			redeemed: redeem,
			awarded: 0,
			t: Date.now()
		};
		customers[phone] = cu;
		const ship = {
			name,
			phone,
			addr
		};
		const url = waLink(s.settings.wa, waBody(s.settings.brand, order));
		set({
			products,
			coupons,
			customers,
			orders: [order, ...s.orders],
			cart: {},
			coupon: null,
			drawer: false,
			productId: null,
			me: {
				name,
				phone
			},
			ship,
			wa: {
				id,
				url
			},
			toast: {
				n: Date.now(),
				text: `${t(s.lang, "savedOrder")}: ${id}`
			}
		});
		return true;
	},
	dismissWa: () => set({ wa: null }),
	guestLogin: (name, phoneRaw) => {
		const s = get();
		const n = name.trim();
		const phone = normalizePhone(phoneRaw);
		if (n.length < 2 || !isBdMobile(phone)) {
			s.showToast(t(s.lang, "check"));
			return false;
		}
		const customers = { ...s.customers };
		const existing = customers[phone];
		if (existing?.blocked) {
			s.showToast(t(s.lang, "blocked"));
			return false;
		}
		customers[phone] = existing ? {
			...cloneCustomer(existing),
			name: n
		} : {
			name: n,
			phone,
			coins: 0,
			ledger: [],
			blocked: false
		};
		set({
			customers,
			me: {
				name: n,
				phone
			},
			toast: {
				n: Date.now(),
				text: t(s.lang, "saved")
			}
		});
		return true;
	},
	logout: () => set({ me: null }),
	unlock: () => set({
		unlocked: true,
		toast: {
			n: Date.now(),
			text: "Admin"
		}
	}),
	adminIn: () => set({
		admin: true,
		view: "admin"
	}),
	adminOut: () => set({
		admin: false,
		view: "shop"
	}),
	setTab: (tab) => set({ tab }),
	saveProduct: (draft) => {
		const s = get();
		const en = draft.en.trim() || draft.bn.trim();
		const bn = draft.bn.trim() || draft.en.trim();
		if (!en) {
			s.showToast(t(s.lang, "nameNeed"));
			return false;
		}
		if (!(draft.price > 0)) {
			s.showToast(t(s.lang, "priceNeed"));
			return false;
		}
		if (draft.disc < 0 || draft.disc > 0 && draft.disc >= draft.price) {
			s.showToast(t(s.lang, "discNeed"));
			return false;
		}
		if (!(draft.stock >= 0)) {
			s.showToast(t(s.lang, "stockNeed"));
			return false;
		}
		const product = {
			...draft,
			id: draft.id || Date.now(),
			en,
			bn,
			img: draft.img.trim() || "📦",
			stock: Math.floor(draft.stock),
			photos: (draft.photos || []).slice(0, 6),
			desc: draft.desc.trim()
		};
		const idx = s.products.findIndex((x) => x.id === draft.id);
		set({
			products: idx >= 0 ? s.products.map((p, i) => i === idx ? product : p) : [...s.products, product],
			toast: {
				n: Date.now(),
				text: t(s.lang, "saved")
			}
		});
		return true;
	},
	deleteProduct: (id) => {
		const cart = { ...get().cart };
		delete cart[String(id)];
		set({
			products: get().products.filter((p) => p.id !== id),
			cart,
			wishlist: get().wishlist.filter((x) => x !== id),
			recently: get().recently.filter((x) => x !== id)
		});
	},
	updateCategory: (index, patch) => {
		set({ categories: get().categories.map((c, i) => i === index ? {
			...c,
			...patch
		} : c) });
	},
	moveCategory: (index, dir) => {
		const categories = [...get().categories];
		const j = index + dir;
		if (j < 0 || j >= categories.length) return;
		const tmp = categories[index];
		const swap = categories[j];
		if (!tmp || !swap) return;
		categories[index] = swap;
		categories[j] = tmp;
		set({ categories });
	},
	deleteCategory: (index) => {
		const s = get();
		const c = s.categories[index];
		if (!c) return;
		if (s.products.some((p) => p.cat === c.id)) {
			s.showToast(t(s.lang, "catBusy"));
			return;
		}
		set({ categories: s.categories.filter((_, i) => i !== index) });
	},
	addCategory: () => {
		const id = `c${Date.now()}`;
		set({ categories: [...get().categories, {
			id,
			emoji: "📦",
			en: "New category",
			bn: "নতুন ক্যাটাগরি"
		}] });
	},
	saveCoupon: (draft, orig) => {
		const s = get();
		const code = draft.code.toUpperCase().replace(/[^A-Z0-9_-]/g, "");
		if (code.length < 3) {
			s.showToast(t(s.lang, "codeNeed"));
			return false;
		}
		if (!(draft.value > 0)) {
			s.showToast(t(s.lang, "valueNeed"));
			return false;
		}
		if (draft.type === "percent" && draft.value > 100) {
			s.showToast(t(s.lang, "pctMax"));
			return false;
		}
		const coupon = {
			code,
			type: draft.type,
			value: draft.value,
			min: Math.max(0, draft.min || 0),
			max: draft.type === "fixed" ? 0 : Math.max(0, draft.max || 0),
			limit: Math.max(0, Math.floor(draft.limit || 0)),
			exp: draft.exp || "",
			active: draft.active,
			used: Math.max(0, Math.floor(draft.used || 0))
		};
		const coupons = s.coupons.map((c) => ({ ...c }));
		const oi = orig ? coupons.findIndex((x) => x.code === orig) : -1;
		const di = coupons.findIndex((x) => x.code === code);
		if (di >= 0 && di !== oi) {
			s.showToast(t(s.lang, "codeDup"));
			return false;
		}
		if (oi >= 0) coupons[oi] = coupon;
		else coupons.push(coupon);
		let couponCode = s.coupon;
		const orders = s.orders.map((o) => {
			if (orig && o.coupon === orig) return {
				...o,
				coupon: code
			};
			return o;
		});
		if (orig && couponCode === orig) couponCode = code;
		set({
			coupons,
			orders,
			coupon: couponCode,
			toast: {
				n: Date.now(),
				text: t(s.lang, "saved")
			}
		});
		return true;
	},
	toggleCoupon: (index) => {
		set({ coupons: get().coupons.map((c, i) => i === index ? {
			...c,
			active: !c.active
		} : c) });
	},
	resetCouponUse: (index) => {
		set({ coupons: get().coupons.map((c, i) => i === index ? {
			...c,
			used: 0
		} : c) });
	},
	deleteCoupon: (index) => {
		set({ coupons: get().coupons.filter((_, i) => i !== index) });
	},
	setOrderStatus: (id, status) => {
		const s = get();
		const current = s.orders.find((o) => o.id === id);
		if (!current || current.status === status) return;
		const was = current.status;
		const order = {
			...current,
			items: current.items.map((i) => ({ ...i })),
			status
		};
		const products = s.products.map((p) => ({ ...p }));
		const coupons = s.coupons.map((c) => ({ ...c }));
		const customers = { ...s.customers };
		const base = customers[order.phone];
		const cu = base ? cloneCustomer(base) : void 0;
		const take = (sign) => {
			order.items.forEach((item) => {
				const p = products.find((x) => x.id === item.id);
				if (p) p.stock = Math.max(0, p.stock + sign * item.q);
			});
		};
		if (was === "cancelled" && status !== "cancelled") {
			take(-1);
			if (order.coupon) {
				const cc = coupons.find((x) => x.code === order.coupon);
				if (cc) cc.used = (cc.used || 0) + 1;
			}
			if (order.redeemed && cu && cu.coins >= 1e3) {
				cu.coins -= 1e3;
				cu.ledger.push({
					t: Date.now(),
					n: -1e3,
					why: `Reinstated ${id}`
				});
			}
		}
		if (status === "cancelled" && was !== "cancelled") {
			take(1);
			if (order.coupon) {
				const cc = coupons.find((x) => x.code === order.coupon);
				if (cc && cc.used > 0) cc.used -= 1;
			}
			if (order.redeemed && cu) {
				cu.coins += 1e3;
				cu.ledger.push({
					t: Date.now(),
					n: 1e3,
					why: `Refund ${id}`
				});
			}
			if (order.awarded && cu) {
				cu.coins -= order.awarded;
				cu.ledger.push({
					t: Date.now(),
					n: -order.awarded,
					why: `Reverse ${id}`
				});
				order.awarded = 0;
			}
		}
		if (status === "delivered" && !order.awarded && cu) {
			const coins = Math.floor(order.sub / 100);
			order.awarded = coins;
			cu.coins += coins;
			cu.ledger.push({
				t: Date.now(),
				n: coins,
				why: `Order ${id}`
			});
		}
		if (cu) customers[order.phone] = cu;
		set({
			products,
			coupons,
			customers,
			orders: s.orders.map((o) => o.id === id ? order : o)
		});
	},
	togglePaid: (id) => {
		set({ orders: get().orders.map((o) => o.id === id ? {
			...o,
			paid: !o.paid
		} : o) });
	},
	adjustCoins: (phone, amount, reason) => {
		const s = get();
		const c = s.customers[phone];
		if (!c || !amount || !reason.trim()) {
			s.showToast(t(s.lang, "coinNeed"));
			return false;
		}
		if (c.coins + amount < 0) {
			s.showToast(t(s.lang, "coinLow"));
			return false;
		}
		const next = cloneCustomer(c);
		next.coins += amount;
		next.ledger.push({
			t: Date.now(),
			n: amount,
			why: `Admin: ${reason.trim()}`
		});
		set({
			customers: {
				...s.customers,
				[phone]: next
			},
			toast: {
				n: Date.now(),
				text: t(s.lang, "saved")
			}
		});
		return true;
	},
	toggleBlock: (phone) => {
		const c = get().customers[phone];
		if (!c) return;
		const next = cloneCustomer(c);
		next.blocked = !next.blocked;
		set({ customers: {
			...get().customers,
			[phone]: next
		} });
	},
	saveSettings: (settings) => {
		set({
			settings: mergeSettings(defaultSettings(), {
				...settings,
				wa: settings.wa.replace(/\D/g, "")
			}),
			toast: {
				n: Date.now(),
				text: t(get().lang, "saved")
			}
		});
	},
	resetLook: () => {
		set({
			settings: {
				...get().settings,
				ui: { ...defaultSettings().ui }
			},
			toast: {
				n: Date.now(),
				text: t(get().lang, "saved")
			}
		});
	},
	removeSamples: () => {
		set({ products: get().products.filter((p) => p.id > 12) });
	},
	importData: (raw) => {
		const s = get();
		if (!raw || typeof raw !== "object") {
			s.showToast(t(s.lang, "badBackup"));
			return false;
		}
		const d = raw;
		if (!Array.isArray(d.products)) {
			s.showToast(t(s.lang, "badBackup"));
			return false;
		}
		const products = d.products.map(normalizeProduct).filter((p) => Boolean(p));
		const categories = Array.isArray(d.categories) ? d.categories.map(normalizeCategory).filter((c) => Boolean(c)) : Array.isArray(d.cats) ? d.cats.map(normalizeCategory).filter((c) => Boolean(c)) : s.categories;
		set({
			products,
			categories: categories.length ? categories : s.categories,
			settings: d.settings ? mergeSettings(s.settings, d.settings) : s.settings,
			coupons: Array.isArray(d.coupons) ? d.coupons : s.coupons,
			orders: Array.isArray(d.orders) ? d.orders : s.orders,
			customers: d.customers && typeof d.customers === "object" ? d.customers : s.customers,
			toast: {
				n: Date.now(),
				text: t(s.lang, "restored")
			}
		});
		return true;
	},
	resetAll: () => {
		try {
			localStorage.removeItem("family-care-bd");
			localStorage.removeItem("fcbd");
			localStorage.removeItem(PW_KEY);
		} catch {}
		location.reload();
	}
}), {
	name: "family-care-bd",
	version: 1,
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memory : browserStorage),
	partialize: (s) => ({
		lang: s.lang,
		mode: s.mode,
		me: s.me,
		wishlist: s.wishlist,
		cart: s.cart,
		recently: s.recently,
		ship: s.ship,
		products: s.products,
		categories: s.categories,
		orders: s.orders,
		customers: s.customers,
		coupons: s.coupons,
		settings: s.settings
	}),
	merge: (persisted, current) => {
		const p = persisted ?? {};
		const products = Array.isArray(p.products) ? p.products.map(normalizeProduct).filter((x) => Boolean(x)) : current.products;
		const categories = Array.isArray(p.categories) ? p.categories.map(normalizeCategory).filter((x) => Boolean(x)) : [];
		return {
			...current,
			lang: p.lang === "bn" ? "bn" : "en",
			mode: p.mode === "light" || p.mode === "dark" || p.mode === "auto" ? p.mode : "auto",
			me: p.me && p.me.phone ? p.me : null,
			wishlist: Array.isArray(p.wishlist) ? p.wishlist.map(Number) : [],
			cart: p.cart && typeof p.cart === "object" ? p.cart : {},
			recently: Array.isArray(p.recently) ? p.recently.map(Number) : [],
			ship: p.ship && typeof p.ship === "object" ? p.ship : null,
			products: products.length || Array.isArray(p.products) ? products : current.products,
			categories: categories.length ? categories : current.categories,
			orders: Array.isArray(p.orders) ? p.orders : [],
			customers: p.customers && typeof p.customers === "object" ? p.customers : {},
			coupons: Array.isArray(p.coupons) ? p.coupons : current.coupons,
			settings: mergeSettings(current.settings, p.settings ?? current.settings)
		};
	}
}));
function Track({ order }) {
	const lang = useShop((s) => s.lang);
	if (order.status === "cancelled") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-danger",
		children: statusLabel("cancelled", lang)
	});
	const flow = STATUSES.filter((s) => s !== "cancelled");
	const at = flow.indexOf(order.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "trk",
		"aria-hidden": true,
		children: flow.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
			className: i <= at ? "on" : "",
			title: statusLabel(s, lang)
		}, s))
	});
}
function Account() {
	const lang = useShop((s) => s.lang);
	const me = useShop((s) => s.me);
	const customers = useShop((s) => s.customers);
	const orders = useShop((s) => s.orders);
	const guestLogin = useShop((s) => s.guestLogin);
	const logout = useShop((s) => s.logout);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const customer = me ? customers[me.phone] : void 0;
	if (!me || !customer) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 pt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-xl font-extrabold",
			children: t(lang, "acct")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "box mt-3",
			onSubmit: (e) => {
				e.preventDefault();
				guestLogin(name, phone);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-mut",
					children: t(lang, "guest")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "name") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: name,
						onChange: (e) => setName(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "phone") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						inputMode: "tel",
						value: phone,
						onChange: (e) => setPhone(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-pri btn-block",
					children: t(lang, "guestlogin")
				})
			]
		})]
	});
	const mine = orders.filter((o) => o.phone === customer.phone);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "text-xl font-extrabold",
				children: [
					customer.name,
					" · ",
					customer.phone
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "box mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-lg font-extrabold text-em",
						children: [
							t(lang, "coins"),
							": ",
							customer.coins
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mut",
						children: t(lang, "coinHint")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mut",
						children: t(lang, "guest")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 font-extrabold",
				children: t(lang, "orders")
			}),
			mine.length ? mine.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "box",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: o.id }),
					" · ",
					statusLabel(o.status, lang),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Track, { order: o }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						fmt(o.total, lang),
						" · ",
						new Date(o.t).toLocaleString(lang === "bn" ? "bn-BD" : "en-GB")
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mut",
						children: o.paid ? t(lang, "paid") : t(lang, "unpaidWord")
					})
				]
			}, o.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-mut",
				children: t(lang, "empty")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn mt-2",
				onClick: logout,
				children: t(lang, "logout")
			})
		]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function blankProduct(cat) {
	return {
		id: 0,
		en: "",
		bn: "",
		cat,
		img: "📦",
		price: 0,
		disc: 0,
		stock: 0,
		feat: false,
		photos: [],
		desc: ""
	};
}
function Admin() {
	if (!useShop((s) => s.admin)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Login, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {});
}
function Login() {
	const lang = useShop((s) => s.lang);
	const adminIn = useShop((s) => s.adminIn);
	const showToast = useShop((s) => s.showToast);
	const tries = (0, import_react.useRef)(0);
	const [user, setUser] = (0, import_react.useState)("");
	const [pw, setPw] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 pt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-xl font-extrabold",
			children: t(lang, "admin")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "box mt-3",
			onSubmit: async (e) => {
				e.preventDefault();
				if (tries.current >= 5) {
					showToast(t(lang, "tooMany"));
					return;
				}
				if (await passwordOk(user, pw)) adminIn();
				else {
					tries.current += 1;
					showToast(t(lang, "badLogin"));
				}
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-mut",
					children: t(lang, "signIn")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "user") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: user,
						onChange: (e) => setUser(e.target.value),
						autoComplete: "username"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "password") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "password",
						value: pw,
						onChange: (e) => setPw(e.target.value),
						autoComplete: "current-password"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-pri btn-block",
					children: t(lang, "login")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-mut",
					children: "admin / admin"
				})
			]
		})]
	});
}
function Panel() {
	const lang = useShop((s) => s.lang);
	const tab = useShop((s) => s.tab);
	const setTab = useShop((s) => s.setTab);
	const adminOut = useShop((s) => s.adminOut);
	const [customPw, setCustomPw] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		setCustomPw(customPasswordSet());
	}, [tab]);
	const tabs = [
		["dash", t(lang, "dash")],
		["products", t(lang, "products")],
		["cats", t(lang, "cats")],
		["orders", t(lang, "orders")],
		["cpn", t(lang, "cpn")],
		["cust", t(lang, "cust")],
		["site", t(lang, "site")]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		!customPw ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "box warn mx-3 mt-3 text-sm font-semibold",
			children: t(lang, "defaultPw")
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "tabs",
			children: [tabs.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("chip", tab === id && "on"),
				onClick: () => setTab(id),
				children: label
			}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "chip",
				onClick: adminOut,
				children: t(lang, "logout")
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-3 pb-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-mut",
					children: t(lang, "onDevice")
				}),
				tab === "dash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dash, {}) : null,
				tab === "products" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Products, {}) : null,
				tab === "cats" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cats, {}) : null,
				tab === "orders" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orders, {}) : null,
				tab === "cpn" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coupons, {}) : null,
				tab === "cust" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Customers, {}) : null,
				tab === "site" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Site, { onPassword: () => setCustomPw(true) }) : null
			]
		})
	] });
}
function Dash() {
	const lang = useShop((s) => s.lang);
	const orders = useShop((s) => s.orders);
	const products = useShop((s) => s.products);
	const customers = useShop((s) => s.customers);
	const done = orders.filter((o) => o.status === "delivered");
	const cells = [
		[fmt(done.reduce((a, o) => a + o.total, 0), lang), t(lang, "rev")],
		[String(orders.length), t(lang, "orders")],
		[String(orders.filter((o) => o.status === "pending").length), t(lang, "pend")],
		[String(done.length), t(lang, "completed")],
		[String(orders.filter((o) => o.status === "cancelled").length), t(lang, "cancelled")],
		[String(Object.keys(customers).length), t(lang, "cust")],
		[String(products.length), t(lang, "products")],
		[String(products.filter((p) => p.stock <= 10).length), t(lang, "low")]
	];
	const low = products.filter((p) => p.stock <= 10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "stats",
		children: cells.map(([n, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "box",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: n }), label]
		}, label))
	}), low.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "box",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: t(lang, "low") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 text-sm",
			children: low.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				p.en,
				" · ",
				p.stock
			] }, p.id))
		})]
	}) : null] });
}
function Products() {
	const lang = useShop((s) => s.lang);
	const products = useShop((s) => s.products);
	const categories = useShop((s) => s.categories);
	const del = useShop((s) => s.deleteProduct);
	const [edit, setEdit] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "btn btn-gold mb-3",
			onClick: () => setEdit(blankProduct(categories[0]?.id || "grocery")),
			children: ["+ ", t(lang, "newp")]
		}),
		edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductForm, {
			initial: edit,
			onClose: () => setEdit(null)
		}, edit.id || "new") : null,
		products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "box flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-2xl",
					"aria-hidden": true,
					children: p.photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: p.photos[0],
						alt: "",
						style: {
							width: 44,
							height: 44,
							objectFit: "cover",
							borderRadius: 8
						}
					}) : p.img
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "clamp",
						children: p.en
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm text-mut",
						children: [
							fmt(unitPrice(p), lang),
							" · ",
							t(lang, "stock"),
							" ",
							p.stock
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => setEdit({
						...p,
						photos: [...p.photos]
					}),
					children: t(lang, "edit")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-danger",
					onClick: () => {
						if (confirm(t(lang, "confirmDel"))) del(p.id);
					},
					children: t(lang, "delete")
				})
			]
		}, p.id))
	] });
}
function ProductForm({ initial, onClose }) {
	const lang = useShop((s) => s.lang);
	const categories = useShop((s) => s.categories);
	const saveProduct = useShop((s) => s.saveProduct);
	const showToast = useShop((s) => s.showToast);
	const [p, setP] = (0, import_react.useState)(initial);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "box",
		onSubmit: (e) => {
			e.preventDefault();
			if (saveProduct(p)) onClose();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "enName") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					value: p.en,
					onChange: (e) => setP({
						...p,
						en: e.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "bnName") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					value: p.bn,
					onChange: (e) => setP({
						...p,
						bn: e.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "desc") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "inp",
					rows: 3,
					value: p.desc,
					onChange: (e) => setP({
						...p,
						desc: e.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "cat") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "inp",
					value: p.cat,
					onChange: (e) => setP({
						...p,
						cat: e.target.value
					}),
					children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: c.id,
						children: c.en
					}, c.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "photos") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "file",
						accept: "image/*",
						multiple: true,
						onChange: async (e) => {
							const files = [...e.target.files || []].slice(0, 6 - p.photos.length);
							const photos = [...p.photos];
							for (const f of files) try {
								photos.push(await compressImage(f, 640));
							} catch {
								showToast(t(lang, "imgBad"));
							}
							setP({
								...p,
								photos
							});
							e.target.value = "";
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: p.photos.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src,
								alt: "",
								style: {
									width: 64,
									height: 64,
									objectFit: "cover",
									borderRadius: 8
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-danger",
								style: {
									position: "absolute",
									top: 0,
									right: 0,
									minHeight: 28,
									padding: "0 6px"
								},
								onClick: () => setP({
									...p,
									photos: p.photos.filter((_, j) => j !== i)
								}),
								children: "×"
							})]
						}, i))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "emoji") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					value: p.img,
					onChange: (e) => setP({
						...p,
						img: e.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "price") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					inputMode: "decimal",
					value: p.price || "",
					onChange: (e) => setP({
						...p,
						price: num(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "disc") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					inputMode: "decimal",
					value: p.disc || "",
					onChange: (e) => setP({
						...p,
						disc: num(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "stock") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					inputMode: "numeric",
					value: String(p.stock),
					onChange: (e) => setP({
						...p,
						stock: Math.floor(num(e.target.value))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 flex items-center gap-2 font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: p.feat,
					onChange: (e) => setP({
						...p,
						feat: e.target.checked
					})
				}), t(lang, "feat")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-pri",
					children: t(lang, "save")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: onClose,
					children: t(lang, "close")
				})]
			})
		]
	});
}
function Cats() {
	const lang = useShop((s) => s.lang);
	const categories = useShop((s) => s.categories);
	const update = useShop((s) => s.updateCategory);
	const move = useShop((s) => s.moveCategory);
	const remove = useShop((s) => s.deleteCategory);
	const add = useShop((s) => s.addCategory);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [categories.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "box",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "inp mb-2",
				value: c.emoji,
				onChange: (e) => update(i, { emoji: e.target.value }),
				"aria-label": "Emoji"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "inp mb-2",
				value: c.en,
				onChange: (e) => update(i, { en: e.target.value }),
				"aria-label": "English"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "inp mb-2",
				value: c.bn,
				onChange: (e) => update(i, { bn: e.target.value }),
				"aria-label": "বাংলা"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => move(i, -1),
						children: "↑"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => move(i, 1),
						children: "↓"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-danger",
						onClick: () => remove(i),
						children: t(lang, "delete")
					})
				]
			})
		]
	}, c.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "btn btn-gold",
		onClick: add,
		children: ["+ ", t(lang, "newCat")]
	})] });
}
function Orders() {
	const lang = useShop((s) => s.lang);
	const orders = useShop((s) => s.orders);
	const setStatus = useShop((s) => s.setOrderStatus);
	const togglePaid = useShop((s) => s.togglePaid);
	const brand = useShop((s) => s.settings.brand);
	if (!orders.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-mut",
		children: t(lang, "empty")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: orders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "box text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: o.id }),
			" · ",
			o.name,
			" · ",
			o.phone,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-mut",
				children: [
					o.addr,
					" · ",
					o.pm,
					" · ",
					o.paid ? t(lang, "paid") : t(lang, "unpaidWord")
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: o.items.map((i) => `${i.en} ×${i.q}`).join(", ") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmt(o.total, lang) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "inp",
						style: { width: "auto" },
						value: o.status,
						onChange: (e) => setStatus(o.id, e.target.value),
						children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: statusLabel(s, lang)
						}, s))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => togglePaid(o.id),
						children: o.paid ? t(lang, "unmarkPaid") : t(lang, "markPaid")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => printOrder(o, brand),
						children: t(lang, "print")
					})
				]
			})
		]
	}, o.id)) });
}
function printOrder(o, brand) {
	const w = window.open("", "_blank", "noopener,noreferrer");
	if (!w) return;
	const esc = (s) => s.replace(/[&<>]/g, (c) => ({
		"&": "&",
		"<": "<",
		">": ">"
	})[c] || c);
	const rows = o.items.map((i) => `<tr><td>${esc(i.en)}</td><td>${i.q}</td><td>৳${i.pr * i.q}</td></tr>`).join("");
	w.document.write(`<!doctype html><meta charset="utf-8"><title>${esc(o.id)}</title><body style="font-family:sans-serif;padding:24px"><h1>${esc(brand)}</h1><p><b>${esc(o.id)}</b><br>${esc(o.name)} · ${esc(o.phone)}<br>${esc(o.addr)}</p><table cellpadding="6">${rows}</table><p>Delivery ৳${o.fee}<br><b>Total ৳${o.total}</b></p><script>print()<\/script></body>`);
	w.document.close();
}
function Coupons() {
	const lang = useShop((s) => s.lang);
	const coupons = useShop((s) => s.coupons);
	const toggle = useShop((s) => s.toggleCoupon);
	const resetUse = useShop((s) => s.resetCouponUse);
	const remove = useShop((s) => s.deleteCoupon);
	const [edit, setEdit] = (0, import_react.useState)(null);
	const fresh = () => ({
		code: "",
		type: "percent",
		value: 10,
		min: 0,
		max: 0,
		limit: 0,
		exp: "",
		active: true,
		used: 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "btn btn-gold mb-3",
			onClick: () => setEdit({ coupon: fresh() }),
			children: ["+ ", t(lang, "cpn")]
		}),
		edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CouponForm, {
			initial: edit.coupon,
			orig: edit.orig,
			onClose: () => setEdit(null)
		}, edit.orig || "new") : null,
		coupons.map((c, i) => {
			const dead = !c.active || c.exp && /* @__PURE__ */ new Date(`${c.exp}T23:59:59+06:00`) < /* @__PURE__ */ new Date() || c.limit > 0 && c.used >= c.limit;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "box",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "flex-1",
							children: c.code
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-mut",
							children: dead ? t(lang, "off") : t(lang, "live")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-mut",
						children: [
							c.type === "percent" ? `${c.value}%` : fmt(c.value, lang),
							" · min ",
							fmt(c.min || 0, lang),
							c.max ? ` · cap ${fmt(c.max, lang)}` : "",
							" · ",
							c.used || 0,
							c.limit ? `/${c.limit}` : "",
							c.exp ? ` · ${c.exp}` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn",
								onClick: () => setEdit({
									coupon: { ...c },
									orig: c.code
								}),
								children: t(lang, "edit")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn",
								onClick: () => toggle(i),
								children: c.active ? t(lang, "disable") : t(lang, "enable")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn",
								onClick: () => {
									let n = `${c.code}-COPY`;
									let k = 2;
									while (coupons.some((x) => x.code === n)) {
										n = `${c.code}-COPY${k}`;
										k += 1;
									}
									setEdit({ coupon: {
										...c,
										code: n,
										used: 0
									} });
								},
								children: t(lang, "copy")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn",
								onClick: () => {
									if (confirm(t(lang, "confirmUsed"))) resetUse(i);
								},
								children: t(lang, "resetUsed")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-danger",
								onClick: () => {
									if (confirm(t(lang, "confirmDel"))) remove(i);
								},
								children: t(lang, "delete")
							})
						]
					})
				]
			}, c.code);
		})
	] });
}
function CouponForm({ initial, orig, onClose }) {
	const lang = useShop((s) => s.lang);
	const save = useShop((s) => s.saveCoupon);
	const [c, setC] = (0, import_react.useState)(initial);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "box",
		onSubmit: (e) => {
			e.preventDefault();
			if (save(c, orig)) onClose();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "code") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					value: c.code,
					onChange: (e) => setC({
						...c,
						code: e.target.value.toUpperCase()
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "type") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "inp",
					value: c.type,
					onChange: (e) => setC({
						...c,
						type: e.target.value
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "percent",
						children: t(lang, "percent")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "fixed",
						children: t(lang, "fixed")
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "value") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					inputMode: "decimal",
					value: c.value || "",
					onChange: (e) => setC({
						...c,
						value: num(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "minOrder") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					inputMode: "decimal",
					value: c.min || "",
					onChange: (e) => setC({
						...c,
						min: num(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "maxDisc") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					inputMode: "decimal",
					value: c.max || "",
					onChange: (e) => setC({
						...c,
						max: num(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "limit") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					inputMode: "numeric",
					value: c.limit || "",
					onChange: (e) => setC({
						...c,
						limit: Math.floor(num(e.target.value))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "used") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					inputMode: "numeric",
					value: String(c.used || 0),
					onChange: (e) => setC({
						...c,
						used: Math.floor(num(e.target.value))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "field",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "expiry") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					type: "date",
					value: c.exp,
					onChange: (e) => setC({
						...c,
						exp: e.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 flex items-center gap-2 font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: c.active,
					onChange: (e) => setC({
						...c,
						active: e.target.checked
					})
				}), t(lang, "active")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-pri",
					children: t(lang, "save")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: onClose,
					children: t(lang, "close")
				})]
			})
		]
	});
}
function Customers() {
	const customers = useShop((s) => s.customers);
	const phones = Object.keys(customers);
	if (!phones.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-mut",
		children: useShop.getState().lang === "bn" ? "এখানে কিছু নেই" : "Nothing here yet"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: phones.map((phone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomerRow, { phone }, phone)) });
}
function CustomerRow({ phone }) {
	const lang = useShop((s) => s.lang);
	const c = useShop((s) => s.customers[phone]);
	const orders = useShop((s) => s.orders);
	const adjust = useShop((s) => s.adjustCoins);
	const block = useShop((s) => s.toggleBlock);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [reason, setReason] = (0, import_react.useState)("");
	if (!c) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "box",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
				c.name,
				" · ",
				c.phone,
				" ",
				c.blocked ? "· blocked" : ""
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-sm text-mut",
				children: [
					t(lang, "coins"),
					" ",
					c.coins,
					" · ",
					orders.filter((o) => o.phone === phone).length,
					" ",
					t(lang, "orders")
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						style: { width: 110 },
						inputMode: "numeric",
						placeholder: "+/-",
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						"aria-label": t(lang, "amount")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						style: {
							flex: 1,
							minWidth: 120
						},
						placeholder: t(lang, "reason"),
						value: reason,
						onChange: (e) => setReason(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => {
							if (adjust(phone, Math.floor(num(amount)), reason)) {
								setAmount("");
								setReason("");
							}
						},
						children: "OK"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => block(phone),
						children: c.blocked ? t(lang, "unblock") : t(lang, "block")
					})
				]
			})
		]
	});
}
function Site({ onPassword }) {
	const lang = useShop((s) => s.lang);
	const saveSettings = useShop((s) => s.saveSettings);
	const resetLook = useShop((s) => s.resetLook);
	const removeSamples = useShop((s) => s.removeSamples);
	const importData = useShop((s) => s.importData);
	const resetAll = useShop((s) => s.resetAll);
	const showToast = useShop((s) => s.showToast);
	const [form, setForm] = (0, import_react.useState)(() => structuredClone(useShop.getState().settings));
	const [pw1, setPw1] = (0, import_react.useState)("");
	const [pw2, setPw2] = (0, import_react.useState)("");
	const setUi = (patch) => setForm((f) => ({
		...f,
		ui: {
			...f.ui,
			...patch
		}
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "box",
			onSubmit: (e) => {
				e.preventDefault();
				saveSettings(form);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: t(lang, "look") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field mt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "mainColor") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "color",
						value: form.ui.c1,
						onChange: (e) => setUi({ c1: e.target.value })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "accent") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "color",
						value: form.ui.c2,
						onChange: (e) => setUi({ c2: e.target.value })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						t(lang, "radius"),
						": ",
						form.ui.rad,
						"px"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "range",
						min: 0,
						max: 28,
						value: form.ui.rad,
						onChange: (e) => setUi({ rad: Number(e.target.value) })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						t(lang, "cardW"),
						": ",
						form.ui.cols,
						"px"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "range",
						min: 120,
						max: 240,
						step: 10,
						value: form.ui.cols,
						onChange: (e) => setUi({ cols: Number(e.target.value) })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mb-2 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: form.ui.splash,
						onChange: (e) => setUi({ splash: e.target.checked })
					}), t(lang, "splash")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						t(lang, "splashTime"),
						": ",
						form.ui.dur,
						"s"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "range",
						min: 1,
						max: 5,
						value: form.ui.dur,
						onChange: (e) => setUi({ dur: Number(e.target.value) })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mb-2 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: form.ui.hero,
						onChange: (e) => setUi({ hero: e.target.checked })
					}), t(lang, "showHero")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mb-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: form.ui.bar,
						onChange: (e) => setUi({ bar: e.target.checked })
					}), t(lang, "showBar")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn btn-pri",
						children: t(lang, "save")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => {
							resetLook();
							setForm((f) => ({
								...f,
								ui: { ...defaultSettings().ui }
							}));
						},
						children: t(lang, "resetLook")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "brand") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: form.brand,
						onChange: (e) => setForm({
							...form,
							brand: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "announce") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: form.announce,
						onChange: (e) => setForm({
							...form,
							announce: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "tagline") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: form.tag,
						onChange: (e) => setForm({
							...form,
							tag: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "logo") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "inp",
							type: "file",
							accept: "image/*",
							onChange: async (e) => {
								const f = e.target.files?.[0];
								if (!f) return;
								try {
									setForm({
										...form,
										logo: await compressImage(f, 320)
									});
								} catch {
									showToast(t(lang, "imgBad"));
								}
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn mt-2",
							onClick: () => setForm({
								...form,
								logo: void 0
							}),
							children: t(lang, "useDefault")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "banner") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "file",
						accept: "image/*",
						onChange: async (e) => {
							const f = e.target.files?.[0];
							if (!f) return;
							try {
								setForm({
									...form,
									banner: await compressImage(f, 900)
								});
							} catch {
								showToast(t(lang, "imgBad"));
							}
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "addr") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: form.addr,
						onChange: (e) => setForm({
							...form,
							addr: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "about") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "inp",
						rows: 3,
						value: form.about,
						onChange: (e) => setForm({
							...form,
							about: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "delivery") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "inp",
						rows: 3,
						value: form.delv,
						onChange: (e) => setForm({
							...form,
							delv: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "privacy") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "inp",
						rows: 3,
						value: form.priv,
						onChange: (e) => setForm({
							...form,
							priv: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "terms") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "inp",
						rows: 3,
						value: form.terms,
						onChange: (e) => setForm({
							...form,
							terms: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "footer") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: form.foot,
						onChange: (e) => setForm({
							...form,
							foot: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "waNum") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: form.wa,
						onChange: (e) => setForm({
							...form,
							wa: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "fee") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "number",
						value: form.fee,
						onChange: (e) => setForm({
							...form,
							fee: num(e.target.value)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "freeOver") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						type: "number",
						value: form.free,
						onChange: (e) => setForm({
							...form,
							free: num(e.target.value)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-pri",
					children: t(lang, "save")
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "box flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => downloadText("orders.csv", ordersCsv(useShop.getState().orders), "text/csv"),
					children: t(lang, "exportCsv")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => {
						const s = useShop.getState();
						downloadText("familycarebd-backup.json", JSON.stringify({
							products: s.products,
							categories: s.categories,
							settings: s.settings,
							coupons: s.coupons,
							orders: s.orders,
							customers: s.customers
						}), "application/json");
					},
					children: t(lang, "backup")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "btn",
					children: [t(lang, "restore"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						hidden: true,
						type: "file",
						accept: "application/json",
						onChange: (e) => {
							const f = e.target.files?.[0];
							if (!f) return;
							const r = new FileReader();
							r.onload = () => {
								try {
									importData(JSON.parse(String(r.result)));
								} catch {
									showToast(t(lang, "badBackup"));
								}
							};
							r.readAsText(f);
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => {
						if (confirm(t(lang, "confirmSamples"))) removeSamples();
					},
					children: t(lang, "removeSamples")
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "box",
			onSubmit: async (e) => {
				e.preventDefault();
				if (pw1.length < 6 || pw1 !== pw2) {
					showToast(t(lang, "min6"));
					return;
				}
				await savePassword(pw1);
				setPw1("");
				setPw2("");
				onPassword();
				showToast(t(lang, "pwChanged"));
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: t(lang, "changePw") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp mt-2",
					type: "password",
					placeholder: t(lang, "pwNew"),
					value: pw1,
					onChange: (e) => setPw1(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp mt-2",
					type: "password",
					placeholder: t(lang, "pwAgain"),
					value: pw2,
					onChange: (e) => setPw2(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-pri mt-3",
					children: t(lang, "changePw")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-danger mt-3 ml-2",
					onClick: () => {
						if (confirm(t(lang, "confirmReset"))) resetAll();
					},
					children: t(lang, "resetData")
				})
			]
		})
	] });
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "7",
				fill: "#0b6b4a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#c9a24b",
				d: "M16 5.4c.35 0 7.4 6.1 7.4 13.8 0 4.5-3.15 7.9-7.4 7.9s-7.4-3.4-7.4-7.9C8.6 11.5 15.65 5.4 16 5.4z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 10.2v12.2",
				fill: "none",
				stroke: "#0b6b4a",
				strokeWidth: "1.45",
				strokeLinecap: "round"
			})
		]
	});
}
function Logo({ src, className }) {
	if (src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		className
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className });
}
function Home$2() {
	const lang = useShop((s) => s.lang);
	const settings = useShop((s) => s.settings);
	const products = useShop((s) => s.products);
	const categories = useShop((s) => s.categories);
	const cat = useShop((s) => s.cat);
	const q = useShop((s) => s.q);
	const sort = useShop((s) => s.sort);
	const favOnly = useShop((s) => s.favOnly);
	const wishlist = useShop((s) => s.wishlist);
	const recently = useShop((s) => s.recently);
	const setCat = useShop((s) => s.setCat);
	const setQuery = useShop((s) => s.setQuery);
	const setSort = useShop((s) => s.setSort);
	const toggleFavOnly = useShop((s) => s.toggleFavOnly);
	const openProduct = useShop((s) => s.openProduct);
	const list = visibleProducts(products, {
		cat,
		q,
		favOnly,
		wishlist,
		sort,
		lang
	});
	const showTiles = cat === "all" && !q && !favOnly && categories.length > 0;
	const recent = recently.map((id) => products.find((p) => p.id === id)).filter((p) => Boolean(p));
	const featured = products.filter((p) => p.feat);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		settings.ui.bar && settings.announce ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "marquee-wrap",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "marquee",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: settings.announce }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: settings.announce })]
			})
		}) : null,
		settings.ui.hero ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: cn("hero", settings.banner && "has-banner"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: settings.brand }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: settings.tag || t(lang, "tagline") })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mark",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { src: settings.logo })
				})]
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "trust",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, {
						size: 16,
						"aria-hidden": true
					}),
					" ",
					t(lang, "fast")
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
						size: 16,
						"aria-hidden": true
					}),
					" ",
					t(lang, "genuine")
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
						size: 16,
						"aria-hidden": true
					}),
					" ",
					t(lang, "wa")
				] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-3 pt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "relative block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					size: 18,
					className: "pointer-events-none absolute top-3.5 left-3 text-mut",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "inp",
					style: {
						paddingLeft: 40,
						borderRadius: 999
					},
					placeholder: t(lang, "search"),
					value: q,
					onChange: (e) => setQuery(e.target.value),
					"aria-label": t(lang, "search")
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 px-3 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
					size: 16,
					className: "text-mut",
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "inp",
					style: {
						width: "auto",
						flex: 1
					},
					"aria-label": t(lang, "sort"),
					value: sort,
					onChange: (e) => setSort(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: t(lang, "sort")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "pa",
							children: t(lang, "pa")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "pd",
							children: t(lang, "pd")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "d",
							children: t(lang, "big")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: cn("btn", favOnly && "btn-pri"),
					onClick: toggleFavOnly,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
							size: 16,
							fill: favOnly ? "currentColor" : "none",
							"aria-hidden": true
						}),
						" ",
						wishlist.length
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "chips mt-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("chip", cat === "all" && "on"),
				onClick: () => setCat("all"),
				children: t(lang, "all")
			}), categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: cn("chip", cat === c.id && "on"),
				onClick: () => setCat(c.id),
				children: [
					c.emoji,
					" ",
					catName(c, lang)
				]
			}, c.id))]
		}),
		showTiles ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "sec",
			children: t(lang, "byCat")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "tiles",
			children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "tile",
				onClick: () => {
					setCat(c.id);
					requestAnimationFrame(() => {
						document.getElementById("catalog")?.scrollIntoView({
							behavior: "smooth",
							block: "start"
						});
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "emo",
						"aria-hidden": true,
						children: c.emoji
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: catName(c, lang) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
						products.filter((p) => p.cat === c.id).length,
						" ",
						t(lang, "itemsWord")
					] })
				]
			}, c.id))
		})] }) : null,
		showTiles && featured.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "sec",
			children: lang === "bn" ? "ফিচার্ড" : "Featured"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "chips",
			children: featured.slice(0, 8).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "chip",
				onClick: () => openProduct(p.id),
				children: [
					p.img,
					" ",
					productName(p, lang)
				]
			}, p.id))
		})] }) : null,
		recent.length && !q ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "sec",
			children: t(lang, "recent")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "chips",
			children: recent.map((p) => p ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "chip",
				onClick: () => openProduct(p.id),
				children: [
					p.photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: p.photos[0],
						alt: "",
						style: {
							width: 22,
							height: 22,
							borderRadius: 6,
							objectFit: "cover",
							verticalAlign: "middle"
						}
					}) : p.img,
					" ",
					productName(p, lang)
				]
			}, p.id) : null)
		})] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "sec",
			id: "catalog",
			children: t(lang, "our")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid-products",
			children: list.length ? list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { id: p.id }, p.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "box",
				style: { gridColumn: "1 / -1" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mut",
					children: q || favOnly || cat !== "all" ? t(lang, "noMatch") : t(lang, "empty")
				}), q || favOnly || cat !== "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn mt-2",
					onClick: () => {
						setQuery("");
						setCat("all");
						if (favOnly) toggleFavOnly();
					},
					children: t(lang, "clear")
				}) : null]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
	] });
}
function ProductCard({ id }) {
	const lang = useShop((s) => s.lang);
	const p = useShop((s) => s.products.find((x) => x.id === id));
	const wished = useShop((s) => s.wishlist.includes(id));
	const openProduct = useShop((s) => s.openProduct);
	const toggleWish = useShop((s) => s.toggleWish);
	const addToCart = useShop((s) => s.addToCart);
	const [ok, setOk] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!ok) return;
		const timer = window.setTimeout(() => setOk(false), 1100);
		return () => window.clearTimeout(timer);
	}, [ok]);
	if (!p) return null;
	const off = discountPct(p);
	const price = unitPrice(p);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "pcard",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "pimg",
				onClick: () => openProduct(p.id),
				"aria-label": productName(p, lang),
				children: [off > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "off",
					children: [
						"−",
						off,
						"%"
					]
				}) : null, p.photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: p.photos[0],
					alt: ""
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					children: p.img
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "heart",
				style: { position: "absolute" },
				"aria-label": t(lang, "wish"),
				"aria-pressed": wished,
				onClick: () => toggleWish(p.id),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
					size: 16,
					fill: wished ? "currentColor" : "none"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "text-left",
				onClick: () => openProduct(p.id),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "clamp",
						children: productName(p, lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1",
						children: [p.disc > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "old",
							children: fmt(p.price, lang)
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "price",
							children: fmt(price, lang)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
						className: "text-mut",
						children: p.stock > 0 ? p.stock <= 5 ? `${t(lang, "only")} ${p.stock} ${t(lang, "left")}` : `${t(lang, "stock")}: ${p.stock}` : t(lang, "out")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("btn btn-pri btn-block", ok && "ok"),
				disabled: p.stock < 1,
				onClick: () => {
					if (addToCart(p.id, 1)) {
						setOk(true);
						try {
							navigator.vibrate?.(12);
						} catch {}
					}
				},
				children: ok ? `✓ ${t(lang, "added")}` : `+ ${t(lang, "add")}`
			})
		]
	});
}
function Footer() {
	const lang = useShop((s) => s.lang);
	const s = useShop((s) => s.settings);
	const blocks = [
		[t(lang, "about"), s.about],
		[t(lang, "delivery"), s.delv],
		[t(lang, "privacy"), s.priv],
		[t(lang, "terms"), s.terms]
	].filter((b) => b[1]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "px-3 pt-2 pb-4",
		children: [
			blocks.map(([label, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "box",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: body })]
			}, label)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-sm text-mut",
				children: [
					s.addr,
					" · WhatsApp +",
					s.wa,
					s.foot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}), s.foot] }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-center text-sm text-mut",
				children: [
					t(lang, "designed"),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Saikoth Rahman" })
				]
			})
		]
	});
}
function Meter({ sub, light }) {
	const lang = useShop((s) => s.lang);
	const free = useShop((s) => s.settings.free);
	if (!(free > 0) || sub <= 0) return null;
	const pct = Math.max(0, Math.min(100, sub / free * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: light ? "meter" : "meter ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: freeDeliveryCopy(lang, sub, free) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { style: { width: `${pct}%` } }) })]
	});
}
function ProductSheet() {
	const lang = useShop((s) => s.lang);
	const id = useShop((s) => s.productId);
	const p = useShop((s) => s.products.find((x) => x.id === id));
	const categories = useShop((s) => s.categories);
	const products = useShop((s) => s.products);
	const qty = useShop((s) => s.qty);
	const photoIdx = useShop((s) => s.photoIdx);
	const close = useShop((s) => s.closeProduct);
	const bump = useShop((s) => s.bumpQty);
	const add = useShop((s) => s.addToCart);
	const open = useShop((s) => s.openProduct);
	if (!p) return null;
	const cat = categories.find((c) => c.id === p.cat);
	const photos = p.photos || [];
	const off = discountPct(p);
	const price = unitPrice(p);
	const related = products.filter((x) => x.cat === p.cat && x.id !== p.id).slice(0, 6);
	const big = photos[photoIdx] || photos[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "scrim",
		style: {
			alignItems: "flex-end",
			justifyContent: "center"
		},
		onClick: close,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet sheet-bottom",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": productName(p, lang),
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "flex-1 text-mut",
						children: cat ? `${cat.emoji} ${catName(cat, lang)}` : ""
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn iconbtn",
						onClick: close,
						"aria-label": t(lang, "close"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}),
				big ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: big,
					alt: productName(p, lang),
					style: {
						width: "100%",
						height: 240,
						objectFit: "cover",
						borderRadius: 16
					}
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pimg",
					style: {
						height: 200,
						fontSize: 72
					},
					children: p.img
				}),
				photos.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex gap-2 overflow-x-auto",
					children: photos.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => useShop.setState({ photoIdx: i }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src,
							alt: "",
							style: {
								width: 56,
								height: 56,
								objectFit: "cover",
								borderRadius: 10,
								border: `2px solid ${i === (photoIdx || 0) ? "var(--em)" : "var(--bd)"}`
							}
						})
					}, src.slice(0, 32) + i))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 text-2xl font-extrabold tracking-tight",
					children: productName(p, lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1",
					children: [p.disc > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "old",
							children: fmt(p.price, lang)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "off",
							style: { position: "static" },
							children: [
								"−",
								off,
								"%"
							]
						}),
						" "
					] }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "price text-xl",
						children: fmt(price, lang)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mut",
					children: p.stock > 0 ? `${t(lang, "inStock")}: ${p.stock}` : t(lang, "out")
				}),
				p.desc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-wrap",
					children: p.desc
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn iconbtn",
							onClick: () => bump(-1),
							"aria-label": "-",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "min-w-8 text-center text-lg",
							children: qty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn iconbtn",
							onClick: () => bump(1),
							"aria-label": "+",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-pri flex-1",
							disabled: p.stock < 1,
							onClick: () => {
								if (add(p.id, qty)) close();
							},
							children: [
								"+ ",
								t(lang, "add"),
								" · ",
								fmt(price * qty, lang)
							]
						})
					]
				}),
				related.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "sec",
					children: t(lang, "related")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid-products",
					style: { paddingInline: 0 },
					children: related.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "pcard",
						onClick: () => open(r.id),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pimg",
								children: r.photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: r.photos[0],
									alt: ""
								}) : r.img
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "clamp",
								children: productName(r, lang)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "price",
								children: fmt(unitPrice(r), lang)
							})
						]
					}, r.id))
				})] }) : null
			]
		})
	});
}
function CartSheet() {
	const lang = useShop((s) => s.lang);
	const products = useShop((s) => s.products);
	const cart = useShop((s) => s.cart);
	const coupons = useShop((s) => s.coupons);
	const coupon = useShop((s) => s.coupon);
	const settings = useShop((s) => s.settings);
	const customers = useShop((s) => s.customers);
	const me = useShop((s) => s.me);
	const ship = useShop((s) => s.ship);
	const close = useShop((s) => s.closeCart);
	const changeQty = useShop((s) => s.changeQty);
	const applyCoupon = useShop((s) => s.applyCoupon);
	const placeOrder = useShop((s) => s.placeOrder);
	const lines = cartLines(products, cart);
	const sub = subtotal(lines);
	const cd = couponOff(coupon ? coupons.find((c) => c.code === coupon) : void 0, sub);
	totals(sub, settings.fee, settings.free, false, cd);
	const [name, setName] = (0, import_react.useState)(ship?.name || me?.name || "");
	const [phone, setPhone] = (0, import_react.useState)(ship?.phone || me?.phone || "");
	const [addr, setAddr] = (0, import_react.useState)(ship?.addr || "");
	const [pm, setPm] = (0, import_react.useState)("COD");
	const [code, setCode] = (0, import_react.useState)(coupon || "");
	const [useCoins, setUseCoins] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const coins = customers[normalizePhone(phone)]?.coins ?? 0;
	const preview = totals(sub, settings.fee, settings.free, useCoins && coins >= 1e3, cd);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "scrim",
		onClick: close,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": t(lang, "cart"),
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "flex-1 text-xl font-extrabold",
						children: t(lang, "cart")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn iconbtn",
						onClick: close,
						"aria-label": t(lang, "close"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}),
				lines.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, { sub }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mut",
					children: t(lang, "empty")
				}),
				lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "box flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-2xl",
							"aria-hidden": true,
							children: l.p.photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: l.p.photos[0],
								alt: "",
								style: {
									width: 44,
									height: 44,
									objectFit: "cover",
									borderRadius: 10
								}
							}) : l.p.img
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "clamp",
								children: productName(l.p, lang)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm text-mut",
								children: fmt(unitPrice(l.p), lang)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn iconbtn",
							onClick: () => changeQty(l.p.id, -1),
							"aria-label": "-",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 16 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: l.q }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn iconbtn",
							onClick: () => changeQty(l.p.id, 1),
							"aria-label": "+",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 })
						})
					]
				}, l.p.id)),
				lines.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (e) => {
						e.preventDefault();
						if (busy) return;
						setBusy(true);
						const ok = placeOrder({
							name,
							phone,
							addr,
							pm,
							useCoins
						});
						setBusy(false);
						if (!ok) return;
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "box text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "sub") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmt(preview.sub, lang) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "del") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmt(preview.fee, lang) })]
								}),
								preview.cd > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["🎟 ", coupon] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["−", fmt(preview.cd, lang)] })]
								}) : null,
								preview.d > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "coins") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["−", fmt(preview.d, lang)] })]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex justify-between text-base font-extrabold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "total") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmt(preview.tot, lang) })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "inp",
								placeholder: t(lang, "coupon"),
								value: code,
								onChange: (e) => setCode(e.target.value.toUpperCase()),
								"aria-label": t(lang, "coupon")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn",
								onClick: () => applyCoupon(code, sub),
								children: t(lang, "apply")
							})]
						}),
						!coupon && coupons.some((c) => c.code === "CARE10" && c.active) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-mut",
							children: t(lang, "tryCoupon")
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "name") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "inp",
								value: name,
								onChange: (e) => setName(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "phone") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "inp",
								inputMode: "tel",
								value: phone,
								onChange: (e) => setPhone(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "addr") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "inp",
								rows: 2,
								value: addr,
								onChange: (e) => setAddr(e.target.value),
								placeholder: t(lang, "addrPh"),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "pay") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "inp",
								value: pm,
								onChange: (e) => setPm(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "COD",
										children: "Cash on Delivery"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "bKash",
										children: "bKash"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Nagad",
										children: "Nagad"
									})
								]
							})]
						}),
						coins >= 1e3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mb-3 flex items-center gap-2 text-sm font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: useCoins,
								onChange: (e) => setUseCoins(e.target.checked)
							}), t(lang, "use")]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "btn btn-pri btn-block",
							disabled: busy,
							children: t(lang, "place")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-mut",
							children: t(lang, "unpaid")
						})
					]
				}) : null
			]
		})
	});
}
function WaSheet() {
	const lang = useShop((s) => s.lang);
	const wa = useShop((s) => s.wa);
	const dismiss = useShop((s) => s.dismissWa);
	if (!wa) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "scrim",
		style: {
			alignItems: "center",
			justifyContent: "center"
		},
		onClick: dismiss,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet modal",
			role: "dialog",
			"aria-modal": "true",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-2 grid h-16 w-16 place-items-center rounded-full",
					style: {
						background: "#25D366",
						color: "white"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 52 52",
						width: "36",
						height: "36",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M14 27l8 8 16-18",
							fill: "none",
							stroke: "white",
							strokeWidth: "4",
							strokeLinecap: "round",
							strokeLinejoin: "round"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-xl font-extrabold",
					children: wa.id
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mut",
					children: t(lang, "waHint")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn btn-pri btn-block mt-3",
					style: { background: "#128C7E" },
					href: wa.url,
					target: "_blank",
					rel: "noreferrer",
					onClick: () => setTimeout(dismiss, 400),
					children: t(lang, "openWa")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn mt-2",
					onClick: dismiss,
					children: t(lang, "close")
				})
			]
		})
	});
}
function applyLook() {
	const s = useShop.getState();
	const root = document.documentElement;
	root.dataset.theme = resolvedTheme(s.mode);
	root.lang = s.lang === "bn" ? "bn" : "en";
	const ui = s.settings.ui;
	root.style.setProperty("--em", ui.c1);
	root.style.setProperty("--gold", ui.c2);
	root.style.setProperty("--radius", `${ui.rad}px`);
	root.style.setProperty("--gc", `${ui.cols}px`);
	root.style.setProperty("--sd", `${ui.dur}s`);
	if (s.settings.banner) root.style.setProperty("--banner", `url("${s.settings.banner}")`);
	else root.style.removeProperty("--banner");
}
function ShopApp() {
	const [phase, setPhase] = (0, import_react.useState)("splash");
	const skip = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		let timer = 0;
		let dead = false;
		(async () => {
			try {
				await useShop.persist.rehydrate();
			} catch {}
			if (dead || skip.current) return;
			applyLook();
			if (location.hash === "#admin") useShop.getState().unlock();
			const ui = useShop.getState().settings.ui;
			if (!ui.splash) {
				setPhase("app");
				return;
			}
			timer = window.setTimeout(() => setPhase("app"), Math.max(.6, ui.dur) * 1e3);
		})();
		const onHash = () => {
			if (location.hash === "#admin") useShop.getState().unlock();
		};
		window.addEventListener("hashchange", onHash);
		return () => {
			dead = true;
			window.clearTimeout(timer);
			window.removeEventListener("hashchange", onHash);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (phase !== "app") return;
		applyLook();
		const unsub = useShop.subscribe(() => applyLook());
		const clock = window.setInterval(applyLook, 6e4);
		const onKey = (e) => {
			if (e.key !== "Escape") return;
			const s = useShop.getState();
			if (s.wa) s.dismissWa();
			else if (s.productId) s.closeProduct();
			else if (s.drawer) s.closeCart();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			unsub();
			window.clearInterval(clock);
			window.removeEventListener("keydown", onKey);
		};
	}, [phase]);
	const drawer = useShop((s) => s.drawer);
	const productId = useShop((s) => s.productId);
	const wa = useShop((s) => s.wa);
	(0, import_react.useEffect)(() => {
		document.body.classList.toggle("lock", Boolean(drawer || productId || wa));
	}, [
		drawer,
		productId,
		wa
	]);
	if (phase === "splash") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, { onSkip: () => {
		skip.current = true;
		setPhase("app");
	} });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollProgress, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Topbar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "page",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, {})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dock, {}),
		drawer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartSheet, {}) : null,
		productId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductSheet, {}) : null,
		wa ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaSheet, {}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackTop, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {})
	] });
}
function View() {
	const view = useShop((s) => s.view);
	if (view === "acct") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Account, {});
	if (view === "admin") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Admin, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$2, {});
}
function Splash({ onSkip }) {
	const brand = useShop((s) => s.settings.brand);
	const tag = useShop((s) => s.settings.tag);
	const logo = useShop((s) => s.settings.logo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "splash",
		onClick: onSkip,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ring",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mark",
					style: {
						width: "100%",
						height: "100%"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { src: logo })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: brand }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "tag",
				children: tag || "Shop Smart · Live Better"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pb",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "credit",
				children: ["Created by ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					style: { color: "#f0d58a" },
					children: "Saikoth Rahman"
				})]
			})
		]
	});
}
function Topbar() {
	const lang = useShop((s) => s.lang);
	const mode = useShop((s) => s.mode);
	const brand = useShop((s) => s.settings.brand);
	const logo = useShop((s) => s.settings.logo);
	const toggleLang = useShop((s) => s.toggleLang);
	const setMode = useShop((s) => s.setMode);
	const setView = useShop((s) => s.setView);
	const unlock = useShop((s) => s.unlock);
	const taps = (0, import_react.useRef)(0);
	const timer = (0, import_react.useRef)(0);
	const [clock, setClock] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const tick = () => {
			setClock((/* @__PURE__ */ new Date()).toLocaleString(lang === "bn" ? "bn-BD" : "en-GB", {
				timeZone: "Asia/Dhaka",
				dateStyle: "medium",
				timeStyle: "short"
			}));
		};
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, [lang]);
	const parts = brand.split(" ");
	const head = parts.slice(0, 2).join(" ");
	const tail = parts.slice(2).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "topbar",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-w-0 flex-1 items-center gap-2 text-left",
					onClick: () => {
						taps.current += 1;
						window.clearTimeout(timer.current);
						timer.current = window.setTimeout(() => {
							taps.current = 0;
						}, 1800);
						if (taps.current >= 5) {
							taps.current = 0;
							unlock();
							setView("admin");
						} else setView("shop");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mark",
						style: {
							width: 36,
							height: 36
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { src: logo })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "truncate text-lg font-extrabold tracking-tight text-em",
						children: [
							head,
							" ",
							tail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gold",
								children: tail
							}) : null
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: toggleLang,
					children: t(lang, "langBtn")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "inp",
					style: { width: "auto" },
					"aria-label": t(lang, "theme"),
					value: mode,
					onChange: (e) => setMode(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "auto",
							children: "auto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "light",
							children: "light"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "dark",
							children: "dark"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs text-mut",
			children: [clock, " · Asia/Dhaka"]
		})]
	});
}
function Dock() {
	const lang = useShop((s) => s.lang);
	const view = useShop((s) => s.view);
	const cart = useShop((s) => s.cart);
	const unlocked = useShop((s) => s.unlocked);
	const setView = useShop((s) => s.setView);
	const openCart = useShop((s) => s.openCart);
	const n = Object.values(cart).reduce((a, b) => a + (Number(b) || 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "dock",
		"aria-label": "Primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: view === "shop" ? "on" : "",
				onClick: () => setView("shop"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
					size: 18,
					"aria-hidden": true
				}), t(lang, "shop")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: openCart,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
						size: 18,
						"aria-hidden": true
					}),
					t(lang, "cart"),
					n > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "badge",
						children: n
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: view === "acct" ? "on" : "",
				onClick: () => setView("acct"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
					size: 18,
					"aria-hidden": true
				}), t(lang, "acct")]
			}),
			unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: view === "admin" ? "on" : "",
				onClick: () => setView("admin"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
					size: 18,
					"aria-hidden": true
				}), t(lang, "admin")]
			}) : null
		]
	});
}
function CartBar() {
	const lang = useShop((s) => s.lang);
	const view = useShop((s) => s.view);
	const drawer = useShop((s) => s.drawer);
	const productId = useShop((s) => s.productId);
	const cart = useShop((s) => s.cart);
	const products = useShop((s) => s.products);
	const settings = useShop((s) => s.settings);
	const coupon = useShop((s) => s.coupon);
	const coupons = useShop((s) => s.coupons);
	const openCart = useShop((s) => s.openCart);
	if (view !== "shop" || drawer || productId) return null;
	const lines = cartLines(products, cart);
	const n = lines.reduce((a, l) => a + l.q, 0);
	if (!n) return null;
	const sub = subtotal(lines);
	const found = coupon ? coupons.find((c) => c.code === coupon) : void 0;
	const tt = totals(sub, settings.fee, settings.free, false, couponOff(found, sub));
	const word = n > 1 ? t(lang, "items") : t(lang, "item");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "cartbar",
		onClick: openCart,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center gap-2 font-semibold",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
					size: 18,
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex-1 text-left",
					children: [
						n,
						" ",
						word
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmt(tt.tot, lang) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full px-2 py-1 text-xs",
					style: { background: "#ffffff26" },
					children: t(lang, "viewCart")
				})
			]
		}), settings.free > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "meter",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: sub >= settings.free ? t(lang, "freeYes") : `${t(lang, "addWord")} ${fmt(settings.free - sub, lang)} ${t(lang, "moreFree")}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { style: { width: `${Math.max(0, Math.min(100, sub / settings.free * 100))}%` } }) })]
		}) : null]
	});
}
function BackTop() {
	const lang = useShop((s) => s.lang);
	const [on, setOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const tick = () => setOn(window.scrollY > 480);
		tick();
		window.addEventListener("scroll", tick, { passive: true });
		return () => window.removeEventListener("scroll", tick);
	}, []);
	if (!on) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "btt",
		"aria-label": t(lang, "backTop"),
		onClick: () => window.scrollTo({
			top: 0,
			behavior: "smooth"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { size: 18 })
	});
}
function ScrollProgress() {
	const bar = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const h = document.documentElement;
			const p = Math.min(1, window.scrollY / Math.max(1, h.scrollHeight - window.innerHeight));
			if (bar.current) bar.current.style.transform = `scaleX(${p})`;
		};
		tick();
		window.addEventListener("scroll", tick, { passive: true });
		return () => window.removeEventListener("scroll", tick);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: bar,
		className: "scp",
		style: { transform: "scaleX(0)" }
	});
}
function Toaster() {
	const toast = useShop((s) => s.toast);
	const clear = useShop((s) => s.clearToast);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const id = window.setTimeout(clear, 2400);
		return () => window.clearTimeout(id);
	}, [toast, clear]);
	if (!toast) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "toast",
		role: "status",
		children: toast.text
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopApp, {});
}
//#endregion
export { Home as component };
