import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { d as inkOn, i as usePlanner, k as cn, l as VISION_SWATCHES, m as safeHttpUrl } from "./router-CQnHyG8o.mjs";
import { a as EmptyCopy, n as Card, s as PageHeader } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
import { t as SortableList } from "./sortable-DqnUMi7n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vision-CbScHso-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AREAS = [
	"Sanctuary",
	"Craft",
	"Body",
	"Kin",
	"Wander",
	"Inner"
];
function VisionView() {
	const dream = usePlanner((s) => s.dream);
	const visions = usePlanner((s) => s.visions);
	const setDream = usePlanner((s) => s.setDream);
	const addVision = usePlanner((s) => s.addVision);
	usePlanner((s) => s.updateVision);
	const setVisions = usePlanner((s) => s.setVisions);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			section: "vision",
			title: "Vision",
			lede: "The life you are building toward."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: "Dream life"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: dream,
					onChange: (event) => setDream(event.target.value),
					placeholder: "Write the life in a few plain sentences.",
					rows: 4,
					className: "min-h-28 w-full resize-none bg-transparent font-display text-2xl leading-snug outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
				})]
			})
		}),
		visions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCopy, {
			title: "An open board",
			body: "Add a card for a place, a feeling, or a way of living."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableList, {
			className: "gap-3 sm:grid-cols-2",
			items: visions,
			getId: (card) => card.id,
			onReorder: setVisions,
			render: (card, grip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisionTile, {
				card,
				grip,
				all: visions
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-4 h-11 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg",
			onClick: () => addVision({
				id: uid(),
				title: "",
				caption: "",
				area: "Inner",
				tone: VISION_SWATCHES[visions.length % VISION_SWATCHES.length] ?? "#f3e4e1",
				imageUrl: ""
			}),
			children: "Add a card"
		})
	] });
}
function VisionTile({ card, grip, all }) {
	const updateVision = usePlanner((s) => s.updateVision);
	const setVisions = usePlanner((s) => s.setVisions);
	const fg = inkOn(card.tone);
	const src = safeHttpUrl(card.imageUrl);
	const [broken, setBroken] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "overflow-hidden rounded-3xl",
		style: {
			background: card.tone,
			color: fg
		},
		children: [src && !broken ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "h-36 w-full object-cover",
			onError: () => setBroken(true)
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1",
						children: AREAS.map((area) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": card.area === area,
							onClick: () => updateVision(card.id, { area }),
							className: cn("h-8 rounded-full px-2 text-xs", card.area === area ? "bg-card/70" : "opacity-70"),
							children: area
						}, area))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-current",
						children: grip
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: card.title,
					"aria-label": "Dream title",
					placeholder: "A title",
					onChange: (event) => updateVision(card.id, { title: event.target.value }),
					className: "h-11 w-full bg-transparent font-display text-2xl outline-none placeholder:opacity-60"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: card.caption,
					"aria-label": "Caption",
					placeholder: "What it feels like.",
					rows: 3,
					onChange: (event) => updateVision(card.id, { caption: event.target.value }),
					className: "min-h-20 w-full resize-none bg-transparent text-base outline-none placeholder:opacity-60"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: card.imageUrl,
					"aria-label": "Image link",
					placeholder: "Image link, optional",
					onChange: (event) => {
						setBroken(false);
						updateVision(card.id, { imageUrl: event.target.value });
					},
					className: "mt-2 h-11 w-full bg-transparent text-sm outline-none placeholder:opacity-60"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-1",
						children: [VISION_SWATCHES.map((tone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `Tone ${tone}`,
							onClick: () => updateVision(card.id, { tone }),
							className: "grid size-8 place-items-center rounded-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("size-4 rounded-full border", card.tone === tone && "border-current"),
								style: { background: tone }
							})
						}, tone)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "color",
							"aria-label": "Custom tone",
							value: /^#[0-9a-fA-F]{6}$/.test(card.tone) ? card.tone : "#f3e4e1",
							onChange: (event) => updateVision(card.id, { tone: event.target.value }),
							className: "color-dot"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 text-sm",
						onClick: () => {
							const prev = all;
							setVisions(all.filter((item) => item.id !== card.id));
							toast("Card removed", { action: {
								label: "Undo",
								onClick: () => setVisions(prev)
							} });
						},
						children: "Remove"
					})]
				})
			]
		})]
	});
}
var SplitComponent = VisionView;
//#endregion
export { SplitComponent as component };
