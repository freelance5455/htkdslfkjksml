import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useVespera, r as Route$1 } from "./router-D7Hr81ml.mjs";
import { _ as toAltAz, a as formatCivil, c as formatLat, d as localHour, f as localMonth, g as skyInstant, i as formatAlt, l as formatLon, m as monthName, n as compass, o as formatDec, p as lstHours, r as eclipticSamples, t as bodiesAt, u as formatRa, v as twilight } from "./astro-2CYvScwN.mjs";
import { t as drawMoonDisk } from "./moon-draw-cL1uJINO.mjs";
import { n as btnGhost, r as btnGold } from "./ui-B4w5JSuo.mjs";
import { a as useNow, i as STARS, n as LINES, r as PLACES, t as CONSTELLATIONS } from "./use-now-CFRJohYF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sky-CSC-nJZs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INK = "#0b0f14";
var WELL = "#10161d";
var LINE = "#2c3a48";
var GOLD = "#e2b15a";
var FG = "#efe7d6";
var MUTED = "#a7b0bd";
var TINT = {
	blue: "#d5e4ff",
	white: "#f7f4ec",
	gold: "#ffe3a6",
	amber: "#ffc58a",
	rose: "#ffb1a4"
};
function project(alt, az, cx, cy, R) {
	const dist = (90 - alt) / 90 * R;
	const a = az * Math.PI / 180;
	return {
		x: cx + dist * Math.sin(a),
		y: cy - dist * Math.cos(a),
		dist
	};
}
function starLit(id, focus) {
	if (!focus) return true;
	if (STARS.find((s) => s.id === id)?.con === focus) return true;
	return LINES.some((l) => !l.guide && l.con === focus && (l.a === id || l.b === id));
}
function SkyChart({ when, lat, lon, lines, guides, names, ecliptic, focus, selected, onSelect }) {
	const wrapRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const hits = (0, import_react.useRef)([]);
	(0, import_react.useEffect)(() => {
		const wrap = wrapRef.current;
		const canvas = canvasRef.current;
		if (!wrap || !canvas) return;
		let cancelled = false;
		const draw = () => {
			if (cancelled) return;
			const cssW = wrap.clientWidth;
			const cssH = wrap.clientHeight;
			if (cssW < 8 || cssH < 8) return;
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			canvas.width = Math.round(cssW * dpr);
			canvas.height = Math.round(cssH * dpr);
			canvas.style.width = `${cssW}px`;
			canvas.style.height = `${cssH}px`;
			const ctx = canvas.getContext("2d");
			if (!ctx) return;
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.fillStyle = INK;
			ctx.fillRect(0, 0, cssW, cssH);
			const cx = cssW / 2;
			const cy = cssH / 2;
			const R = Math.min(cssW, cssH) / 2 - 26;
			const lst = lstHours(when, lon);
			const bodies = bodiesAt(when);
			const nextHits = [];
			ctx.beginPath();
			ctx.arc(cx, cy, R, 0, Math.PI * 2);
			ctx.fillStyle = WELL;
			ctx.fill();
			ctx.strokeStyle = LINE;
			ctx.lineWidth = 1;
			ctx.stroke();
			ctx.save();
			ctx.beginPath();
			ctx.arc(cx, cy, R, 0, Math.PI * 2);
			ctx.clip();
			for (const ring of [30, 60]) {
				const rr = (90 - ring) / 90 * R;
				ctx.beginPath();
				ctx.arc(cx, cy, rr, 0, Math.PI * 2);
				ctx.strokeStyle = LINE;
				ctx.stroke();
			}
			ctx.strokeStyle = LINE;
			ctx.beginPath();
			ctx.moveTo(cx - R, cy);
			ctx.lineTo(cx + R, cy);
			ctx.moveTo(cx, cy - R);
			ctx.lineTo(cx, cy + R);
			ctx.stroke();
			const at = (ra, dec) => {
				const { alt, az } = toAltAz(ra, dec, lat, lst);
				return {
					alt,
					...project(alt, az, cx, cy, R)
				};
			};
			if (ecliptic) {
				const pts = eclipticSamples().map((p) => at(p.ra, p.dec));
				ctx.beginPath();
				let pen = false;
				for (const p of pts) {
					if (p.alt <= 0) {
						pen = false;
						continue;
					}
					if (!pen) ctx.moveTo(p.x, p.y);
					else ctx.lineTo(p.x, p.y);
					pen = true;
				}
				ctx.strokeStyle = "rgba(226,177,90,0.45)";
				ctx.setLineDash([4, 6]);
				ctx.stroke();
				ctx.setLineDash([]);
			}
			const byId = new Map(STARS.map((s) => [s.id, s]));
			for (const line of LINES) {
				if (line.guide && !guides) continue;
				if (!line.guide && !lines) continue;
				const a = byId.get(line.a);
				const b = byId.get(line.b);
				if (!a || !b) continue;
				const pa = at(a.ra, a.dec);
				const pb = at(b.ra, b.dec);
				const hot = !focus || line.con === focus || line.guide && (starLit(a.id, focus) || starLit(b.id, focus));
				ctx.beginPath();
				ctx.moveTo(pa.x, pa.y);
				ctx.lineTo(pb.x, pb.y);
				ctx.strokeStyle = line.guide ? "rgba(226,177,90,0.55)" : "rgba(167,176,189,0.75)";
				ctx.globalAlpha = hot ? .9 : .12;
				ctx.setLineDash(line.guide ? [3, 5] : []);
				ctx.lineWidth = line.guide ? 1 : 1.25;
				ctx.stroke();
				ctx.setLineDash([]);
				ctx.globalAlpha = 1;
			}
			const placed = [];
			const labelIt = (x, y, text, fill, bold = false) => {
				if (placed.some((p) => Math.hypot(p.x - x, p.y - y) < 14)) return;
				placed.push({
					x,
					y
				});
				ctx.font = `${bold ? 600 : 500} 12px Outfit, sans-serif`;
				ctx.fillStyle = fill;
				ctx.fillText(text, x + 8, y - 6);
			};
			for (const star of STARS) {
				const p = at(star.ra, star.dec);
				if (p.alt <= 0) continue;
				const hot = starLit(star.id, focus);
				const radius = Math.max(.8, (3.4 - star.mag) * 1.25);
				ctx.globalAlpha = hot ? 1 : .28;
				ctx.beginPath();
				ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
				ctx.fillStyle = TINT[star.tint];
				ctx.fill();
				if (selected === star.id) {
					ctx.strokeStyle = GOLD;
					ctx.lineWidth = 1.5;
					ctx.beginPath();
					ctx.arc(p.x, p.y, radius + 5, 0, Math.PI * 2);
					ctx.stroke();
				}
				if (selected === star.id || (focus ? hot && star.mag < 3.2 : names ? star.mag < 2.6 : star.mag < .9)) labelIt(p.x, p.y, star.name, hot ? FG : MUTED, selected === star.id);
				ctx.globalAlpha = 1;
				nextHits.push({
					id: star.id,
					x: p.x,
					y: p.y,
					r: Math.max(radius + 8, 16)
				});
			}
			for (const body of bodies) {
				const p = at(body.ra, body.dec);
				if (p.alt <= -2) continue;
				ctx.globalAlpha = p.alt > 0 ? 1 : .35;
				if (body.kind === "moon") drawMoonDisk(ctx, p.x, p.y, 8, body.elongation, lat < 0);
				else if (body.kind === "sun") {
					ctx.beginPath();
					ctx.arc(p.x, p.y, 9, 0, Math.PI * 2);
					ctx.fillStyle = GOLD;
					ctx.fill();
				} else {
					ctx.beginPath();
					ctx.arc(p.x, p.y, 4.5, 0, Math.PI * 2);
					ctx.fillStyle = body.id === "mars" ? "#ffb1a4" : GOLD;
					ctx.fill();
					ctx.strokeStyle = FG;
					ctx.lineWidth = 1;
					ctx.stroke();
				}
				if (selected === body.id) {
					ctx.strokeStyle = GOLD;
					ctx.lineWidth = 1.5;
					ctx.beginPath();
					ctx.arc(p.x, p.y, 14, 0, Math.PI * 2);
					ctx.stroke();
				}
				labelIt(p.x, p.y, body.name, GOLD, true);
				ctx.globalAlpha = 1;
				nextHits.push({
					id: body.id,
					x: p.x,
					y: p.y,
					r: 18
				});
			}
			ctx.restore();
			ctx.fillStyle = MUTED;
			ctx.font = "500 12px Outfit, sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("N", cx, cy - R - 8);
			ctx.fillText("S", cx, cy + R + 16);
			ctx.textAlign = "left";
			ctx.fillText("E", cx + R + 8, cy + 4);
			ctx.textAlign = "right";
			ctx.fillText("W", cx - R - 8, cy + 4);
			ctx.textAlign = "start";
			if (focus && CONSTELLATIONS[focus]) {
				ctx.fillStyle = GOLD;
				ctx.font = "600 13px Fraunces, serif";
				ctx.fillText(CONSTELLATIONS[focus].name, 12, 22);
			}
			hits.current = nextHits;
		};
		draw();
		document.fonts?.ready.then(() => {
			if (!cancelled) draw();
		});
		const ro = new ResizeObserver(draw);
		ro.observe(wrap);
		return () => {
			cancelled = true;
			ro.disconnect();
		};
	}, [
		when,
		lat,
		lon,
		lines,
		guides,
		names,
		ecliptic,
		focus,
		selected
	]);
	function pick(clientX, clientY) {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const x = clientX - rect.left;
		const y = clientY - rect.top;
		let best = null;
		let bestD = 1e9;
		for (const h of hits.current) {
			const d = Math.hypot(h.x - x, h.y - y);
			if (d < h.r && d < bestD) {
				best = h;
				bestD = d;
			}
		}
		onSelect(best ? best.id : null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className: "aspect-square w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "h-full w-full touch-manipulation",
			onClick: (e) => pick(e.clientX, e.clientY)
		})
	});
}
function visibleObjects(when, lat, lon) {
	const lst = lstHours(when, lon);
	return {
		stars: STARS.map((s) => ({
			...s,
			...toAltAz(s.ra, s.dec, lat, lst)
		})).filter((s) => s.alt > 0).sort((a, b) => a.mag - b.mag),
		bodies: bodiesAt(when).map((b) => ({
			...b,
			...toAltAz(b.ra, b.dec, lat, lst)
		})).filter((b) => b.alt > 0).sort((a, b) => b.alt - a.alt)
	};
}
function formatClock(hour) {
	const h24 = (Math.floor(hour) % 24 + 24) % 24;
	const m = Math.min(59, Math.round((hour - Math.floor(hour)) * 60));
	const ampm = h24 >= 12 ? "pm" : "am";
	return `${h24 % 12 === 0 ? 12 : h24 % 12}:${String(m).padStart(2, "0")} ${ampm}`;
}
function SkyPage() {
	const search = Route$1.useSearch();
	const now = useNow();
	const lat = useVespera((s) => s.lat);
	const lon = useVespera((s) => s.lon);
	const custom = useVespera((s) => s.custom);
	const placeId = useVespera((s) => s.placeId);
	const ready = useVespera((s) => s.ready);
	const setPlace = useVespera((s) => s.setPlace);
	const setLat = useVespera((s) => s.setLat);
	const setCustom = useVespera((s) => s.setCustom);
	const clearCustom = useVespera((s) => s.clearCustom);
	const [lines, setLines] = (0, import_react.useState)(true);
	const [guides, setGuides] = (0, import_react.useState)(true);
	const [names, setNames] = (0, import_react.useState)(true);
	const [ecliptic, setEcliptic] = (0, import_react.useState)(true);
	const [focus, setFocus] = (0, import_react.useState)(search.con ?? null);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [play, setPlay] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setFocus(search.con ?? null);
	}, [search.con]);
	(0, import_react.useEffect)(() => {
		if (!play) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			const s = useVespera.getState();
			const hour = (s.custom?.hour ?? localHour(/* @__PURE__ */ new Date(), s.lon)) + 1;
			const month = s.custom?.month ?? localMonth(/* @__PURE__ */ new Date(), s.lon);
			s.setCustom(month, hour >= 24 ? hour - 24 : hour, true);
			setPlay(false);
			return;
		}
		let frame = 0;
		let last = performance.now();
		const loop = (t) => {
			const dt = Math.min(.05, (t - last) / 1e3);
			last = t;
			const s = useVespera.getState();
			const month = s.custom?.month ?? localMonth(/* @__PURE__ */ new Date(), s.lon);
			let hour = (s.custom?.hour ?? localHour(/* @__PURE__ */ new Date(), s.lon)) + dt * 1.15;
			if (hour >= 24) hour -= 24;
			s.setCustom(month, hour, false);
			frame = requestAnimationFrame(loop);
		};
		frame = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(frame);
	}, [play]);
	if (!now || !ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Setting the chart to your clock."
	});
	const when = skyInstant(lon, custom, now);
	const month = custom?.month ?? localMonth(when, lon);
	const hour = custom?.hour ?? localHour(when, lon);
	const { stars, bodies } = visibleObjects(when, lat, lon);
	const lst = lstHours(when, lon);
	const sun = bodiesAt(when)[0];
	const sunPos = toAltAz(sun.ra, sun.dec, lat, lst);
	const skyNote = twilight(sunPos.alt);
	const star = STARS.find((s) => s.id === selected);
	const body = bodiesAt(when).find((b) => b.id === selected);
	const pickedAlt = star ? toAltAz(star.ra, star.dec, lat, lst) : body ? toAltAz(body.ra, body.dec, lat, lst) : null;
	const figures = /* @__PURE__ */ new Map();
	for (const s of stars) if (s.alt > 15) figures.set(s.con, Math.max(figures.get(s.con) ?? -90, s.alt));
	const figureList = [...figures.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
	function stopPlay(save) {
		if (!play) return;
		setPlay(false);
		if (save) {
			const s = useVespera.getState();
			if (s.custom) s.setCustom(s.custom.month, s.custom.hour, true);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-widest text-gold",
			children: "Horizon chart"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 text-4xl text-fg md:text-5xl",
			children: "The sky you can actually learn."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-sm text-sm text-muted",
			children: "Looking up. North is at the top, east is to the right — the view facing north. Bright stars only."
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-line bg-bg-raised p-3 sm:p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkyChart, {
					when,
					lat,
					lon,
					lines,
					guides,
					names,
					ecliptic,
					focus,
					selected,
					onSelect: setSelected
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: lines,
						set: setLines,
						label: "Figures"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: guides,
						set: setGuides,
						label: "Pointers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: names,
						set: setNames,
						label: "Names"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: ecliptic,
						set: setEcliptic,
						label: "Ecliptic"
					}),
					focus && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex h-11 items-center justify-center rounded-full px-3 text-sm text-muted transition-colors duration-200 hover:text-fg",
						onClick: () => setFocus(null),
						children: ["Clear ", CONSTELLATIONS[focus]?.name ?? "focus"]
					})
				]
			}),
			skyNote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: skyNote
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl text-fg",
							children: formatCivil(when, lon)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-faint",
							children: [
								formatLat(lat),
								" · ",
								formatLon(lon),
								placeId === "guess" ? " · longitude from your timezone" : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnGhost,
								onClick: () => {
									stopPlay(false);
									const offset = -(/* @__PURE__ */ new Date()).getTimezoneOffset() / 60;
									setPlace("guess", 40, Math.max(-180, Math.min(180, offset * 15)));
									clearCustom();
								},
								children: "Right now"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: play ? btnGold : btnGhost,
								onClick: () => {
									if (play) stopPlay(true);
									else setPlay(true);
								},
								children: play ? "Pause the night" : "Play the night"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex justify-between",
								children: ["Hour ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-fg tabular-nums",
									children: formatClock(hour)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mt-2 w-full",
								type: "range",
								min: 0,
								max: 24,
								step: .25,
								value: hour,
								onChange: (e) => {
									stopPlay(false);
									setCustom(month, Number(e.target.value));
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex justify-between",
								children: ["Month ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-fg",
									children: monthName(month)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mt-2 w-full",
								type: "range",
								min: 1,
								max: 12,
								step: 1,
								value: month,
								onChange: (e) => {
									stopPlay(false);
									setCustom(Number(e.target.value), hour);
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex justify-between",
								children: ["Latitude ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-fg tabular-nums",
									children: formatLat(lat)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mt-2 w-full",
								type: "range",
								min: -60,
								max: 70,
								step: .5,
								value: lat,
								onChange: (e) => {
									setLat(Number(e.target.value));
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: PLACES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPlace(p.id, p.lat, p.lon),
								className: `h-9 rounded-full border px-3 text-sm ${placeId === p.id ? "border-gold text-gold" : "border-line text-muted"}`,
								children: p.name
							}, p.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "rounded-2xl border border-line bg-surface p-4",
					children: star && pickedAlt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
						kicker: CONSTELLATIONS[star.con]?.name ?? "Star",
						title: star.name,
						lines: [
							`Magnitude ${star.mag.toFixed(2)} · ${star.ly < 100 ? star.ly.toFixed(1) : Math.round(star.ly)} light-years`,
							`${formatAlt(pickedAlt.alt)} altitude · ${compass(pickedAlt.az)}`,
							`RA ${formatRa(star.ra)} · Dec ${formatDec(star.dec)}`
						],
						body: star.fact,
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: btnGhost,
							onClick: () => setFocus(star.con),
							children: ["Trace ", CONSTELLATIONS[star.con]?.name ?? "it"]
						})
					}) : body && pickedAlt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
						kicker: body.kind === "planet" ? "Planet" : body.kind === "moon" ? "Moon" : "Sun",
						title: body.name,
						lines: [`${formatAlt(pickedAlt.alt)} altitude · ${compass(pickedAlt.az)}`, `RA ${formatRa(body.ra)} · Dec ${formatDec(body.dec)}`],
						body: body.note
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-gold",
						children: "Tap a point"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Stars are colored by temperature: blue is hot, gold is sun-like, amber and rose are cool giants. Planets wear a ring. The dashed gold curve is the ecliptic — planets stay near it."
					})] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm uppercase tracking-widest text-faint",
						children: "Up now"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 divide-y divide-line border-y border-line",
						children: [bodies.filter((b) => b.kind !== "sun" || b.alt > 0).slice(0, 4).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-baseline justify-between gap-3 py-2.5 text-left",
							onClick: () => setSelected(b.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: b.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-faint tabular-nums",
								children: [
									b.alt.toFixed(0),
									"° ",
									compass(b.az)
								]
							})]
						}) }, b.id)), stars.slice(0, 6).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-baseline justify-between gap-3 py-2.5 text-left",
							onClick: () => setSelected(s.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: s.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-faint tabular-nums",
								children: [
									s.alt.toFixed(0),
									"° ",
									compass(s.az)
								]
							})]
						}) }, s.id))]
					}),
					figureList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: figureList.map(([id]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setFocus(focus === id ? null : id),
							className: `h-9 rounded-full border px-3 text-sm ${focus === id ? "border-gold text-gold" : "border-line text-muted"}`,
							children: CONSTELLATIONS[id]?.name ?? id
						}, id))
					})
				] })
			]
		})]
	})] });
}
function Toggle({ on, set, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick: () => set(!on),
		className: `h-10 rounded-full border px-4 text-sm ${on ? "border-gold text-gold" : "border-line text-faint"}`,
		children: label
	});
}
function Detail({ kicker, title, lines, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-widest text-gold",
			children: kicker
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-1 text-3xl text-fg",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-1 text-sm text-muted tabular-nums",
			children: lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: l }, l))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-fg",
			children: body
		}),
		action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: action
		})
	] });
}
//#endregion
export { SkyPage as component };
