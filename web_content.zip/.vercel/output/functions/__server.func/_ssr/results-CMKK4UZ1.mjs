import { o as __toESM } from "../_runtime.mjs";
import { i as fullName, r as formatScore } from "./calc-DDlXNlj6.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Card } from "./card-n_ZyUc_C.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as listResults, l as listSchools, t as Skeleton, u as listStreams } from "./server-BRpT2GPU.mjs";
import { n as MentionBadge, t as DecisionBadge } from "./mention-badge-kWeo3_az.mjs";
import { a as Search } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as SelectTrigger, c as TableBody, d as TableHeader, f as TableRow, i as SelectItem, l as TableCell, n as Select, o as SelectValue, r as SelectContent, s as Table, t as Input, u as TableHead } from "./table-DKHBmBA9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/results-CMKK4UZ1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResultsPage() {
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	const [streamId, setStreamId] = (0, import_react.useState)("all");
	const [schoolId, setSchoolId] = (0, import_react.useState)("all");
	const [decision, setDecision] = (0, import_react.useState)("all");
	const filters = {
		q: q.trim() || void 0,
		streamId: streamId === "all" ? void 0 : Number(streamId),
		schoolId: schoolId === "all" ? void 0 : Number(schoolId),
		decision: decision === "all" ? void 0 : decision
	};
	const resultsQuery = useQuery({
		queryKey: ["results", filters],
		queryFn: () => listResults({ data: filters })
	});
	const streamsQuery = useQuery({
		queryKey: ["streams"],
		queryFn: () => listStreams()
	});
	const schoolsQuery = useQuery({
		queryKey: ["schools"],
		queryFn: () => listSchools()
	});
	const rows = resultsQuery.data ?? [];
	const passed = rows.filter((r) => r.decision === "ناجح").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "نتائج الدورة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "المعدلات المحسومة بعد إدخال كل علامات الشعبة. اضغط صفاً لفتح الملف أو الشهادة."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-2 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "pr-9",
								placeholder: "بحث",
								value: q,
								onChange: (e) => setQ(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: streamId,
							onValueChange: setStreamId,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "الشعبة" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "كل الشعب"
							}), streamsQuery.data?.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: String(s.id),
								children: s.nameAr
							}, s.id))] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: schoolId,
							onValueChange: setSchoolId,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "الثانوية" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "كل الثانويات"
							}), schoolsQuery.data?.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: String(s.id),
								children: s.name
							}, s.id))] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: decision,
							onValueChange: setDecision,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "الحسم" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "all",
									children: "ناجح وراسب"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "ناجح",
									children: "ناجح فقط"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "راسب",
									children: "راسب فقط"
								})
							] })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: [
						"المعروض ",
						rows.length,
						" نتيجة · منها ",
						passed,
						" ناجح"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-hidden p-0",
				children: resultsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2 p-4",
					children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12" }, i))
				}) : !rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-8 text-center text-sm text-muted",
					children: "لا توجد نتائج محسومة بعد."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "الترتيب" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "رقم التسجيل" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "المترشح" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "الشعبة" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "المعدل" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "التقدير" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "الحسم" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "رقم الشهادة" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
					className: "cursor-pointer",
					onClick: () => void navigate({
						to: "/students/$id",
						params: { id: String(row.id) }
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "tabular-nums",
							children: index + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "tabular-nums",
							children: row.examNumber
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: fullName(row.lastName, row.firstName) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: row.streamName }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium tabular-nums",
							children: formatScore(row.average)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MentionBadge, {
							mention: row.mention,
							decision: row.decision
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionBadge, { decision: row.decision }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "tabular-nums text-muted",
							children: row.certificateNumber ?? "—"
						})
					]
				}, row.id)) })] })
			})
		]
	});
}
//#endregion
export { ResultsPage as component };
