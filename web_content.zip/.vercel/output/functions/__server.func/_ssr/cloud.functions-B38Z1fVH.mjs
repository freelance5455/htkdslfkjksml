import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cloud.functions-B38Z1fVH.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var KINDS = /* @__PURE__ */ new Set([
	"clear",
	"flame",
	"smoke",
	"smoking"
]);
var stamps = [];
function allowCall() {
	const now = Date.now();
	stamps = stamps.filter((stamp) => now - stamp < 6e5);
	const last = stamps[stamps.length - 1] ?? 0;
	if (stamps.length >= 8 || last && now - last < 15e3) return false;
	stamps.push(now);
	return true;
}
function parseVerdict(text) {
	const start = text.indexOf("{");
	const end = text.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		const raw = JSON.parse(text.slice(start, end + 1));
		if (!raw.kind || !KINDS.has(raw.kind)) return null;
		const confidence = Number(raw.confidence);
		return {
			kind: raw.kind,
			confidence: Number.isFinite(confidence) ? Math.min(1, Math.max(0, confidence)) : .5,
			note: String(raw.note ?? "").slice(0, 180)
		};
	} catch {
		return null;
	}
}
var confirmThreat_createServerFn_handler = createServerRpc({
	id: "4ce10131cf00d94a88323bf8acd07852f96b9badcf9e15ce3b998bb055755e6c",
	name: "confirmThreat",
	filename: "src/lib/dera/cloud.functions.ts"
}, (opts) => confirmThreat.__executeServer(opts));
var confirmThreat = createServerFn({ method: "POST" }).validator((input) => input).handler(confirmThreat_createServerFn_handler, async ({ data }) => {
	if (!data?.image?.startsWith("data:image/") || data.image.length > 18e4) return {
		ok: false,
		error: "اللقطة غير صالحة للتأكيد"
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "التأكيد السحابي غير متاح في هذه البيئة"
	};
	if (!allowCall()) return {
		ok: false,
		error: "تم بلوغ حد التأكيد السحابي. التحليل المحلي مستمر."
	};
	const hint = String(data.hint ?? "").slice(0, 32);
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			signal: AbortSignal.timeout(2e4),
			body: JSON.stringify({
				model: "grok-4.5",
				max_tokens: 120,
				messages: [{
					role: "user",
					content: [{
						type: "text",
						text: `صنّف لقطة مراقبة واحدة للسلامة. الأنواع: flame لهب، smoke دخان بلا لهب واضح، smoking تدخين أو جمرة سيجارة، clear لا خطر. تلميح المحلل المحلي: ${hint}. أجب JSON فقط بهذا الشكل {"kind":"flame|smoke|smoking|clear","confidence":0.0,"note":"جملة عربية قصيرة"}`
					}, {
						type: "image_url",
						image_url: {
							url: data.image,
							detail: "low"
						}
					}]
				}]
			})
		});
		if (!res.ok) return {
			ok: false,
			error: "تعذّر التأكيد السحابي. التحليل المحلي مستمر."
		};
		const content = (await res.json()).choices?.[0]?.message?.content;
		const verdict = parseVerdict(Array.isArray(content) ? content.map((part) => part.text ?? "").join("") : content ?? "");
		if (!verdict) return {
			ok: false,
			error: "وصل رد غير مفهوم من السحابة. التحليل المحلي مستمر."
		};
		return {
			ok: true,
			...verdict
		};
	} catch {
		return {
			ok: false,
			error: "انقطع التأكيد السحابي. التحليل المحلي مستمر."
		};
	}
});
//#endregion
export { confirmThreat_createServerFn_handler };
