import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { g as ChevronLeft, h as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as format } from "../_libs/date-fns.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { D as streakEnding, O as weekDays, S as parseDay, T as shiftDay, i as usePlanner, k as cn, v as useTodayKey, y as dayKey } from "./router-CQnHyG8o.mjs";
import { a as EmptyCopy, d as fieldClass, i as ColorDot, o as IconButton, s as PageHeader } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
import { t as SortableList } from "./sortable-DqnUMi7n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/habits-0E0DAuHB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HabitsView() {
	const today = useTodayKey();
	const habits = usePlanner((s) => s.habits);
	const addHabit = usePlanner((s) => s.addHabit);
	const updateHabit = usePlanner((s) => s.updateHabit);
	const toggleHabit = usePlanner((s) => s.toggleHabit);
	const setHabits = usePlanner((s) => s.setHabits);
	const accent = usePlanner((s) => s.theme.accent);
	const [cursor, setCursor] = (0, import_react.useState)(null);
	if (!today) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		section: "habits",
		title: "Habits",
		lede: "Opening the week."
	});
	const anchor = cursor ?? today;
	const days = weekDays(parseDay(anchor));
	const weekStart = dayKey(days[0] ?? parseDay(anchor));
	const thisWeek = dayKey(weekDays(parseDay(today))[0] ?? parseDay(today));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			section: "habits",
			title: "Habits",
			lede: "Small repeats, kept honestly.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Previous week",
					onClick: () => setCursor(shiftDay(weekStart, -7)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
						className: "size-5",
						strokeWidth: 1.6
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Next week",
					onClick: () => setCursor(shiftDay(weekStart, 7)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
						className: "size-5",
						strokeWidth: 1.6
					})
				})]
			})
		}),
		weekStart !== thisWeek ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-4 text-sm font-medium text-accent",
			onClick: () => setCursor(null),
			children: "This week"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-4 text-sm text-muted",
			children: [
				format(days[0] ?? parseDay(anchor), "d MMM"),
				" – ",
				format(days[6] ?? parseDay(anchor), "d MMM")
			]
		}),
		habits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCopy, {
			title: "No habits yet",
			body: "Start with one you can keep on a tired day."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableList, {
			items: habits,
			getId: (habit) => habit.id,
			onReorder: setHabits,
			render: (habit, grip) => {
				const streak = streakEnding(habit.checks, parseDay(today));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-line bg-card p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							grip,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDot, {
								label: `${habit.name} color`,
								value: habit.color,
								onChange: (color) => updateHabit(habit.id, { color })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: habit.name,
								"aria-label": "Habit name",
								onChange: (event) => updateHabit(habit.id, { name: event.target.value }),
								className: "h-11 min-w-0 flex-1 bg-transparent text-base outline-none"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "shrink-0 text-sm tabular-nums text-muted",
								children: [streak, "d"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 px-2 text-sm text-muted",
								onClick: () => {
									const prev = habits;
									setHabits(habits.filter((item) => item.id !== habit.id));
									toast("Habit removed", { action: {
										label: "Undo",
										onClick: () => setHabits(prev)
									} });
								},
								children: "Remove"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 grid grid-cols-7 gap-1",
						children: days.map((day) => {
							const key = dayKey(day);
							const on = !!habit.checks[key];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": on,
								"aria-label": `${habit.name} ${format(day, "EEEE d")}`,
								onClick: () => toggleHabit(habit.id, key),
								className: "flex h-14 flex-col items-center justify-center gap-1 rounded-lg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("text-xs", key === today ? "text-ink" : "text-muted"),
									children: format(day, "EEEEE")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-4 rounded-full border-2",
									style: {
										borderColor: habit.color,
										background: on ? habit.color : "transparent"
									}
								})]
							}, key);
						})
					})]
				});
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 flex gap-2",
			onSubmit: (event) => {
				event.preventDefault();
				const data = new FormData(event.currentTarget);
				const name = String(data.get("name") ?? "").trim();
				if (!name) return;
				addHabit({
					id: uid(),
					name,
					color: accent,
					checks: {}
				});
				event.currentTarget.reset();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				name: "name",
				placeholder: "New habit",
				"aria-label": "New habit",
				className: fieldClass
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "h-11 shrink-0 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg",
				children: "Add"
			})]
		})
	] });
}
var SplitComponent = HabitsView;
//#endregion
export { SplitComponent as component };
