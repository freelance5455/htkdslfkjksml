import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as fundirHistorico, c as processar, i as formatarDataHora, l as statsHistorico, n as estadoVisual, o as nomeLiga, r as filtrarJogos, s as numPt, t as FONTE_EVENTOS } from "./mercado-D-r3mUkE.mjs";
import { a as RefreshCw, c as Clock, i as Search, o as Radio, r as ShieldCheck, s as History, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C6XvGPNo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var obterEventos = createServerFn({ method: "GET" }).handler(createSsrRpc("7a13a978ebe2a53a89112bdbfa61ed9e4a5275d9219fecb789c9a77eb8855a72"));
var CACHE_EVENTOS = "vision-master-eventos-v2";
var CACHE_HIST = "vision-master-historico-v2";
var COOLDOWN_MS = 15e3;
var MAX_CARTOES = 90;
var CAMPO = "h-11 w-full rounded-xl border border-line bg-surface-2 px-3 text-sm text-fg outline-none";
function lerCache() {
	try {
		const t = localStorage.getItem(CACHE_EVENTOS);
		if (!t) return null;
		const o = JSON.parse(t);
		if (o && typeof o === "object" && "dados" in o) return o;
		return null;
	} catch {
		return null;
	}
}
function guardarCache(dados) {
	try {
		localStorage.setItem(CACHE_EVENTOS, JSON.stringify({
			guardadoEm: Date.now(),
			dados
		}));
	} catch {}
}
function lerHistorico() {
	try {
		const raw = localStorage.getItem(CACHE_HIST);
		const arr = raw ? JSON.parse(raw) : [];
		return Array.isArray(arr) ? arr : [];
	} catch {
		return [];
	}
}
function guardarHistorico(itens) {
	try {
		localStorage.setItem(CACHE_HIST, JSON.stringify(itens));
	} catch {}
}
function mensagemErro(erro) {
	if (erro instanceof Error && erro.message) return erro.message;
	return "sem resposta do servidor";
}
async function buscarEventos() {
	try {
		return await obterEventos();
	} catch (erroServidor) {
		try {
			const resposta = await fetch(FONTE_EVENTOS, { cache: "no-store" });
			if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);
			return await resposta.json();
		} catch (erroRede) {
			throw new Error(`${mensagemErro(erroServidor)} · ${mensagemErro(erroRede)}`);
		}
	}
}
function iniciais(nome) {
	const partes = nome.trim().split(/\s+/).filter(Boolean);
	if (partes.length > 1) return ((partes[0]?.[0] ?? "") + (partes[1]?.[0] ?? "")).toUpperCase();
	return (partes[0] || "?").slice(0, 2).toUpperCase();
}
function matiz(nome) {
	let h = 0;
	for (const c of nome) h = (h * 31 + (c.codePointAt(0) ?? 0)) % 360;
	return h;
}
function Painel() {
	const [bruto, setBruto] = (0, import_react.useState)(null);
	const [carregado, setCarregado] = (0, import_react.useState)(false);
	const [carregando, setCarregando] = (0, import_react.useState)(false);
	const [erro, setErro] = (0, import_react.useState)("");
	const [usandoCache, setUsandoCache] = (0, import_react.useState)(false);
	const [cacheEm, setCacheEm] = (0, import_react.useState)(null);
	const [historico, setHistorico] = (0, import_react.useState)([]);
	const [modo, setModo] = (0, import_react.useState)("blindado");
	const [termo, setTermo] = (0, import_react.useState)("");
	const [desporto, setDesporto] = (0, import_react.useState)("");
	const [liga, setLiga] = (0, import_react.useState)("");
	const [data, setData] = (0, import_react.useState)("");
	const [ordem, setOrdem] = (0, import_react.useState)("seguro");
	const [tick, setTick] = (0, import_react.useState)(0);
	const [aberto, setAberto] = (0, import_react.useState)(false);
	const [cooldownAte, setCooldownAte] = (0, import_react.useState)(0);
	const [relogio, setRelogio] = (0, import_react.useState)(0);
	const histRef = (0, import_react.useRef)([]);
	const temDados = (0, import_react.useRef)(false);
	const carregandoRef = (0, import_react.useRef)(false);
	const ultimoRef = (0, import_react.useRef)(0);
	const rel = (0, import_react.useMemo)(() => processar(bruto, Date.now()), [bruto, tick]);
	function aplicar(dados, cache, quando) {
		temDados.current = true;
		setBruto(dados);
		setUsandoCache(cache);
		setCacheEm(quando);
		setErro("");
		setCarregado(true);
		if (!cache) guardarCache(dados);
		const proximo = fundirHistorico(processar(dados, Date.now()), histRef.current);
		histRef.current = proximo;
		guardarHistorico(proximo);
		setHistorico(proximo);
	}
	async function carregar(manual = false) {
		if (carregandoRef.current) return;
		if (manual && Date.now() - ultimoRef.current < COOLDOWN_MS) return;
		carregandoRef.current = true;
		setCarregando(true);
		try {
			aplicar(await buscarEventos(), false, null);
			ultimoRef.current = Date.now();
			setCooldownAte(Date.now() + COOLDOWN_MS);
		} catch (falha) {
			if (!temDados.current) {
				const cache = lerCache();
				if (cache) aplicar(cache.dados, true, cache.guardadoEm);
				else setErro(mensagemErro(falha));
			} else setErro(mensagemErro(falha));
		} finally {
			carregandoRef.current = false;
			setCarregando(false);
		}
	}
	(0, import_react.useEffect)(() => {
		const inicial = lerHistorico();
		histRef.current = inicial;
		setHistorico(inicial);
		carregar();
		const id = setInterval(() => void carregar(), 6e4);
		const pulso = setInterval(() => setTick((n) => n + 1), 3e4);
		return () => {
			clearInterval(id);
			clearInterval(pulso);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (cooldownAte <= Date.now()) return;
		const id = setInterval(() => setRelogio((n) => n + 1), 1e3);
		return () => clearInterval(id);
	}, [cooldownAte]);
	(0, import_react.useEffect)(() => {
		if (!aberto) return;
		const anterior = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = anterior;
		};
	}, [aberto]);
	(0, import_react.useEffect)(() => {
		function noEscape(e) {
			if (e.key === "Escape") setAberto(false);
		}
		document.addEventListener("keydown", noEscape);
		return () => document.removeEventListener("keydown", noEscape);
	}, []);
	const filtros = {
		modo,
		termo,
		desporto,
		liga,
		data,
		ordem
	};
	const base = (0, import_react.useMemo)(() => filtrarJogos(rel.jogos, {
		...filtros,
		modo: "todos"
	}, Date.now()), [
		rel,
		termo,
		desporto,
		liga,
		data,
		ordem,
		tick
	]);
	const visiveis = (0, import_react.useMemo)(() => filtrarJogos(rel.jogos, filtros, Date.now()).slice(0, MAX_CARTOES), [
		rel,
		modo,
		termo,
		desporto,
		liga,
		data,
		ordem,
		tick
	]);
	const nBlind = base.filter((j) => j.sinal.nivel === "blindado").length;
	const nFirme = base.filter((j) => j.sinal.nivel !== "lista").length;
	const selosGlobais = rel.jogos.filter((j) => j.sinal.nivel === "blindado").length;
	const taxa = statsHistorico(historico, true);
	const ligas = [...new Set(rel.jogos.map((j) => j.liga))].sort((a, b) => nomeLiga(a).localeCompare(nomeLiga(b), "pt"));
	const restante = Math.max(0, cooldownAte - Date.now());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-canvas text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-line-soft bg-elevated/95 px-4 backdrop-blur-md md:h-20 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 shrink-0 place-items-center rounded-xl bg-primary text-lg font-extrabold text-canvas",
						children: "V"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-sm font-extrabold tracking-wide md:text-base",
							children: "VISION MASTER"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold tracking-widest text-muted",
							children: "PAINEL DE PREVISÕES"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-label": "Histórico",
						className: "inline-flex h-11 items-center gap-2 rounded-xl border border-line bg-surface px-3 text-sm font-semibold text-fg",
						onClick: () => setAberto(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, {
							className: "size-4",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Histórico"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex h-11 items-center gap-2 rounded-xl border border-primary bg-primary-deep px-3 text-sm font-semibold text-fg disabled:opacity-50",
						onClick: () => void carregar(true),
						disabled: carregando || restante > 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
							className: `size-4 ${carregando ? "animate-spin motion-reduce:animate-none" : ""}`,
							"aria-hidden": true
						}), carregando ? "A atualizar" : restante > 0 ? `${Math.ceil(restante / 1e3)}s` : "Atualizar"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 py-6 pb-16 md:px-6 md:py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5 max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs font-bold tracking-widest text-primary",
								children: "MOTOR DE BLINDAGEM"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-3xl font-extrabold tracking-tight md:text-4xl",
								children: "Jogos que não podem falhar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: "Só aparecem eventos com odds completas. O selo Blindado fica para o favorito em que o mercado concorda de forma rara: probabilidade alta, folga larga sobre o 2.º resultado e margem da casa saudável. Sem odd, o jogo nem entra."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-4 grid grid-cols-3 gap-2 md:gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Com odds",
								valor: carregado ? String(rel.jogos.length) : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Blindados",
								valor: carregado ? String(selosGlobais) : "—",
								tom: "win"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Taxa do selo",
								valor: taxa.taxa == null ? "—" : `${taxa.taxa}%`,
								tom: taxa.taxa == null ? "neutro" : taxa.taxa >= 60 ? "win" : taxa.taxa >= 40 ? "warn" : "loss",
								nota: taxa.resolvidos ? `${taxa.resolvidos} resolvidos` : "ainda sem fechos"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "mb-4 rounded-2xl border border-line bg-surface-2 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
								className: "text-sm font-semibold",
								children: "Como o selo escolhe o que não falha"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: "Nenhum palpite é garantia. O Blindado só passa quando as cinco fecham ao mesmo tempo. O índice ordena os que passam: quanto maior, mais o mercado trata o favorito como quase certo."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 grid gap-2 text-sm text-fg md:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Regra, { texto: "Probabilidade implícita de pelo menos 76%, já sem a margem da casa." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Regra, { texto: "Folga de pelo menos 52 pontos para o segundo resultado." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Regra, { texto: "Odd do favorito entre 1,12 e 1,38 — nem preço partido, nem odd longa." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Regra, { texto: "Margem da casa entre 2% e 14%. Fora disto, a odd é suspeita." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Regra, { texto: "No futebol, o empate não pode passar de 16%. Empate favorito nunca leva selo." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Regra, { texto: "Basquete e tênis entram na mesma régua, mas só se tiverem as duas odds." })
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 grid grid-cols-3 gap-2",
						role: "tablist",
						"aria-label": "Nível de confiança",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModoBtn, {
								ativo: modo === "blindado",
								onClick: () => setModo("blindado"),
								nome: "Blindados",
								n: nBlind
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModoBtn, {
								ativo: modo === "firme",
								onClick: () => setModo("firme"),
								nome: "Alta confiança",
								n: nFirme
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModoBtn, {
								ativo: modo === "todos",
								onClick: () => setModo("todos"),
								nome: "Com odds",
								n: base.length
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 grid gap-2 md:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "relative md:col-span-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Buscar equipa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
										className: "pointer-events-none absolute top-3.5 left-3 size-4 text-faint",
										"aria-hidden": true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: `${CAMPO} pl-10`,
										type: "search",
										placeholder: "Buscar equipa ou competição",
										value: termo,
										onChange: (e) => setTermo(e.target.value),
										autoComplete: "off"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: CAMPO,
								value: desporto,
								onChange: (e) => setDesporto(e.target.value),
								"aria-label": "Desporto",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Todos os desportos"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "futebol",
										children: "Futebol"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "basquete",
										children: "Basquete"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "tenis",
										children: "Tênis"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: CAMPO,
								value: ligas.includes(liga) ? liga : "",
								onChange: (e) => setLiga(e.target.value),
								"aria-label": "Competição",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Todas as competições"
								}), ligas.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c,
									children: nomeLiga(c)
								}, c))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: CAMPO,
								value: data,
								onChange: (e) => setData(e.target.value),
								"aria-label": "Data",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Todas as datas"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "hoje",
										children: "Hoje"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "amanha",
										children: "Amanhã"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "semana",
										children: "Próximos 7 dias"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: CAMPO,
								value: ordem,
								onChange: (e) => setOrdem(e.target.value),
								"aria-label": "Ordenação",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "seguro",
									children: "Mais seguros"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "cedo",
									children: "Mais cedo"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBar, {
						rel,
						mostrados: visiveis.length,
						totalFiltrado: filtrarJogos(rel.jogos, filtros, Date.now()).length,
						usandoCache,
						cacheEm,
						erro: erro && carregado ? erro : ""
					}),
					!carregado && !erro ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 md:grid-cols-2 xl:grid-cols-3",
						children: [[
							0,
							1,
							2
						].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72 animate-pulse rounded-2xl border border-line bg-surface motion-reduce:animate-none" }, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted md:col-span-2 xl:col-span-3",
							children: "A carregar só jogos que têm odds…"
						})]
					}) : erro && !rel.jogos.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-dashed border-line px-6 py-12 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold",
								children: "Não foi possível carregar os jogos."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: erro
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-4 inline-flex h-11 items-center rounded-xl bg-primary-deep px-4 text-sm font-semibold",
								onClick: () => void carregar(true),
								children: "Tentar outra vez"
							})
						]
					}) : visiveis.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vazio, {
						modo,
						onFirme: () => setModo("firme"),
						onTodos: () => setModo("todos"),
						temFirme: nFirme > 0,
						temOdds: base.length > 0
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 md:grid-cols-2 xl:grid-cols-3",
						children: visiveis.map((jogo, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
							jogo,
							i
						}, jogo.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-center text-xs tracking-widest text-faint",
						children: "VISION MASTER · SÓ ENTRA QUEM TEM ODD · SELO BLINDADO"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Historico, {
				aberto,
				onFechar: () => setAberto(false),
				historico,
				estados: rel.estados
			})
		]
	});
}
function Stat({ label, valor, tom = "neutro", nota }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface px-3 py-3 md:px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-semibold tracking-wide text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-1 text-2xl font-extrabold tracking-tight ${tom === "win" ? "text-win" : tom === "warn" ? "text-warn" : tom === "loss" ? "text-loss" : "text-fg"}`,
				children: valor
			}),
			nota ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-xs text-faint",
				children: nota
			}) : null
		]
	});
}
function Regra({ texto }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
			className: "mt-0.5 size-4 shrink-0 text-win",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: texto })]
	});
}
function ModoBtn({ ativo, onClick, nome, n }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "tab",
		"aria-selected": ativo,
		onClick,
		className: `flex min-h-16 flex-col items-center justify-center gap-1 rounded-xl border px-1 py-2 text-xs font-bold sm:text-sm ${ativo ? "border-primary bg-primary-deep text-fg" : "border-line bg-surface-2 text-muted"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "leading-none",
			children: nome
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `text-xs font-semibold ${ativo ? "text-fg" : "text-faint"}`,
			children: n
		})]
	});
}
function StatusBar({ rel, mostrados, totalFiltrado, usandoCache, cacheEm, erro }) {
	if (!rel.recebidos && !erro) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 flex flex-wrap gap-2 text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, { children: "Proteção ativa" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
				tom: "ok",
				children: [rel.jogos.length, " com odds à frente"]
			}),
			rel.semOdds > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
				tom: "warn",
				children: [rel.semOdds, " sem odds, ocultos"]
			}) : null,
			rel.margemInvalida > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
				tom: "warn",
				children: [rel.margemInvalida, " com margem suspeita"]
			}) : null,
			usandoCache ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
				tom: "warn",
				children: ["Cópia local", cacheEm ? ` de ${formatarDataHora(new Date(cacheEm))}` : ""]
			}) : null,
			erro ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
				tom: "err",
				children: "Última ligação falhou"
			}) : null,
			mostrados < totalFiltrado ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, { children: [
				"A mostrar ",
				mostrados,
				" de ",
				totalFiltrado
			] }) : null
		]
	});
}
function Pill({ children, tom }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex items-center rounded-lg border px-2.5 py-1.5 ${tom === "ok" ? "border-win bg-win-dim text-win" : tom === "warn" ? "border-warn bg-warn-dim text-warn" : tom === "err" ? "border-loss bg-loss-dim text-loss" : "border-line bg-elevated text-muted"}`,
		children
	});
}
function Vazio({ modo, onFirme, onTodos, temFirme, temOdds }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-dashed border-line px-6 py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: modo === "blindado" ? "Nenhum jogo passa o selo Blindado com estes filtros." : modo === "firme" ? "Nenhum favorito de alta confiança com estes filtros." : "Nenhum jogo com odds corresponde aos filtros."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-md text-sm text-muted",
				children: modo === "blindado" ? "O mercado não está a oferecer um favorito assim tão claro. Isso é o filtro a trabalhar, não um erro." : "Alarga a data, a competição ou a busca."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap justify-center gap-2",
				children: [modo === "blindado" && temFirme ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-xl bg-primary-deep px-4 text-sm font-semibold",
					onClick: onFirme,
					children: "Ver alta confiança"
				}) : null, modo !== "todos" && temOdds ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-xl border border-line px-4 text-sm font-semibold",
					onClick: onTodos,
					children: "Ver todos com odds"
				}) : null]
			})
		]
	});
}
function Cartao({ jogo, i }) {
	const s = jogo.sinal;
	const linha = s.nivel === "blindado" ? "via-win" : s.nivel === "firme" ? "via-primary" : "via-faint";
	const atraso = `${Math.min(i, 12) * 40}ms`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "cartao-in relative overflow-hidden rounded-2xl border border-line bg-surface p-4",
		style: { animationDelay: atraso },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `pointer-events-none absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent ${linha} to-transparent` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
						className: "size-3.5 text-primary",
						"aria-hidden": true
					}), formatarDataHora(new Date(jogo.inicioMs))]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-md border border-primary bg-primary-dim px-2 py-1 text-xs font-bold tracking-wide text-primary",
					children: jogo.desportoLabel
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[1fr_auto_1fr] items-start gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Equipa, { nome: jogo.equipaCasa }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid size-7 place-items-center rounded-full border border-line text-xs font-bold text-faint",
						children: "VS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Equipa, { nome: jogo.equipaFora })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `mt-3 grid gap-1.5 ${s.odds.empate == null ? "grid-cols-2" : "grid-cols-3"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Odd, {
						tag: "1 · Casa",
						odd: s.odds.casa,
						fav: s.lado === "casa"
					}),
					s.odds.empate != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Odd, {
						tag: "X · Empate",
						odd: s.odds.empate,
						fav: s.lado === "empate"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Odd, {
						tag: "2 · Fora",
						odd: s.odds.fora,
						fav: s.lado === "fora"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2 border-t border-line-soft pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-xl border px-3 py-2 ${s.nivel === "lista" ? "border-line bg-surface-2" : "border-win bg-win-dim"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold tracking-wide text-muted uppercase",
							children: s.nivel === "blindado" ? "Blindado" : s.nivel === "firme" ? "Firme" : "Com odds"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm font-extrabold text-win",
							children: s.nome
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 text-xs text-muted",
							children: [
								"odd ",
								numPt(s.odd),
								" · ",
								s.prob,
								"% · índice ",
								s.score
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-1.5 overflow-hidden rounded-full bg-line",
							"aria-hidden": true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-full rounded-full ${s.nivel === "blindado" ? "bg-win" : s.nivel === "firme" ? "bg-primary" : "bg-muted"}`,
								style: { width: `${Math.max(0, Math.min(100, s.prob))}%` }
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-line bg-surface-2 px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold tracking-wide text-muted uppercase",
							children: "Competição"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm font-bold",
							children: jogo.tipoJogo
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 text-xs text-muted",
							children: [
								"2.º ",
								s.segundoNome,
								" · ",
								s.segundoProb,
								"%"
							]
						}),
						jogo.categoria ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-xs text-faint",
							children: jogo.categoria
						}) : null
					]
				})]
			}),
			s.nivel === "lista" && s.falhas[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-warn",
				children: ["Fora do selo: ", s.falhas[0]]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-1.5",
				children: s.motivos.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-2 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
						className: "mt-0.5 size-3.5 shrink-0 text-win",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: m })]
				}, m))
			})
		]
	});
}
function Equipa({ nome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col items-center gap-2 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "avatar-equipa grid size-12 place-items-center rounded-xl text-sm font-extrabold",
			style: { "--h": String(matiz(nome)) },
			children: iniciais(nome)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-bold break-words",
			children: nome
		})]
	});
}
function Odd({ tag, odd, fav }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border px-1 py-2 text-center ${fav ? "border-win bg-win-dim" : "border-line bg-surface-2"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-bold tracking-wide text-faint",
				children: tag
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `text-sm font-extrabold ${fav ? "text-win" : "text-fg"}`,
				children: numPt(odd)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-faint",
				children: fav ? "favorito" : ""
			})
		]
	});
}
function Historico({ aberto, onFechar, historico, estados }) {
	const sh = statsHistorico(historico);
	const itens = historico.map((h) => ({
		h,
		v: estadoVisual(h, estados[h.id])
	}));
	const ordenados = [...itens.filter((x) => x.v.tipo === "live"), ...itens.filter((x) => x.v.tipo !== "live")].slice(0, 60);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": "Fechar histórico",
		className: `fixed inset-0 z-40 bg-canvas/70 ${aberto ? "opacity-100" : "pointer-events-none opacity-0"}`,
		onClick: onFechar
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: `fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col border-l border-line-soft bg-elevated transition-transform duration-200 motion-reduce:transition-none ${aberto ? "translate-x-0" : "translate-x-full"}`,
		"aria-hidden": !aberto,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-line-soft px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-extrabold",
					children: "Histórico do selo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-xl border border-line",
					onClick: onFechar,
					"aria-label": "Fechar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2 border-b border-line-soft px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Total",
						valor: sh.total
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Ganhou",
						valor: sh.won,
						tom: "win"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Perdeu",
						valor: sh.lost,
						tom: "loss"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Pendente",
						valor: sh.pend,
						tom: "warn"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto px-4 py-3",
				children: ordenados.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 py-10 text-center text-sm text-muted",
					children: "Ainda sem selos registados. Quando um jogo passar a Blindado ou a alta confiança, fica aqui para ser avaliado no fim."
				}) : ordenados.map(({ h, v }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `mb-2 rounded-xl border px-3 py-3 ${v.tipo === "live" ? "border-loss bg-loss-dim" : "border-line bg-surface"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-extrabold",
							children: [
								h.equipaCasa,
								" vs ",
								h.equipaFora
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 text-xs text-muted",
							children: [
								h.tipoJogo,
								" · ",
								h.palpiteNome,
								" · odd ",
								numPt(h.oddUsada),
								" · ",
								h.nivel === "blindado" ? "Blindado" : "Firme"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-semibold text-fg",
								children: [
									v.placar ? `${v.placar.casa}–${v.placar.fora} · ` : "",
									h.prob,
									"%"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Selo, {
								tipo: v.tipo,
								minuto: v.minuto
							})]
						})
					]
				}, h.id))
			})
		]
	})] });
}
function Mini({ label, valor, tom }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface py-2 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `text-base font-extrabold ${tom === "win" ? "text-win" : tom === "loss" ? "text-loss" : tom === "warn" ? "text-warn" : "text-fg"}`,
			children: valor
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-bold tracking-wide text-faint uppercase",
			children: label
		})]
	});
}
function Selo({ tipo, minuto }) {
	if (tipo === "won") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "selo-ganho rounded-md border-2 border-fg bg-win px-2 py-1 text-xs font-extrabold tracking-widest text-win-ink",
		children: "GANHOU"
	});
	if (tipo === "lost") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-md border border-loss bg-loss-dim px-2 py-1 text-xs font-extrabold text-loss",
		children: "PERDEU"
	});
	if (tipo === "push") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-md border border-line px-2 py-1 text-xs font-extrabold text-muted",
		children: "ANULADO"
	});
	if (tipo === "live") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5 rounded-md border border-loss bg-loss-dim px-2 py-1 text-xs font-extrabold text-loss",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
				className: "ao-vivo-dot size-3",
				"aria-hidden": true
			}),
			"Live",
			minuto ? ` · ${minuto}` : ""
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-md border border-warn bg-warn-dim px-2 py-1 text-xs font-extrabold text-warn",
		children: "PENDENTE"
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Painel, {});
}
//#endregion
export { Home as component };
