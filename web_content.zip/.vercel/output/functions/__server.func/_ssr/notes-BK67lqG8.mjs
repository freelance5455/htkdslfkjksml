import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { l as Pin } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as usePlanner, k as cn } from "./router-CQnHyG8o.mjs";
import { a as EmptyCopy, d as fieldClass, n as Card, s as PageHeader, u as areaClass } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notes-BK67lqG8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NotesView() {
	const notes = usePlanner((s) => s.notes);
	const addNote = usePlanner((s) => s.addNote);
	const updateNote = usePlanner((s) => s.updateNote);
	const deleteNote = usePlanner((s) => s.deleteNote);
	const [query, setQuery] = (0, import_react.useState)("");
	const q = query.trim().toLowerCase();
	const shown = notes.filter((note) => !q || note.title.toLowerCase().includes(q) || note.body.toLowerCase().includes(q)).slice().sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updated - a.updated);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			section: "notes",
			title: "Notes",
			lede: "Loose thoughts, kept."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: query,
			onChange: (event) => setQuery(event.target.value),
			placeholder: "Search notes",
			"aria-label": "Search notes",
			className: cn(fieldClass, "mb-4")
		}),
		shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCopy, {
			title: q ? "Nothing under that name" : "A blank margin",
			body: "Write the thing before it leaves."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: shown.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: note.title,
						"aria-label": "Note title",
						onChange: (event) => updateNote(note.id, {
							title: event.target.value,
							updated: Date.now()
						}),
						placeholder: "Title",
						className: "h-11 min-w-0 flex-1 bg-transparent font-display text-xl outline-none"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": note.pinned,
						"aria-label": note.pinned ? "Unpin note" : "Pin note",
						onClick: () => updateNote(note.id, {
							pinned: !note.pinned,
							updated: Date.now()
						}),
						className: cn("grid size-11 place-items-center rounded-full", note.pinned ? "text-accent" : "text-muted"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, {
							className: "size-4",
							strokeWidth: 1.6,
							fill: note.pinned ? "currentColor" : "none"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: note.body,
					"aria-label": "Note",
					onChange: (event) => updateNote(note.id, {
						body: event.target.value,
						updated: Date.now()
					}),
					placeholder: "Write freely.",
					className: areaClass
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-2 h-11 text-sm text-muted",
					onClick: () => {
						const prev = notes;
						deleteNote(note.id);
						toast("Note removed", { action: {
							label: "Undo",
							onClick: () => usePlanner.setState({ notes: prev })
						} });
					},
					children: "Remove"
				})
			] }, note.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-4 h-11 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg",
			onClick: () => addNote({
				id: uid(),
				title: "",
				body: "",
				pinned: false,
				updated: Date.now()
			}),
			children: "New note"
		})
	] });
}
var SplitComponent = NotesView;
//#endregion
export { SplitComponent as component };
