import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { M as Download, N as Compass, k as FolderOpen, m as Play } from "../_libs/lucide-react.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as continueWatching, D as itemsForTab, I as PUBLIC_STREAMS, M as APP_TAGLINE, P as Button, S as usePlayer, c as AddMediaButton, k as useLibrary } from "./router-5I6roosF.mjs";
import { n as MediaRail } from "./media-card-BeFpTEuT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CKJhEafy.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const items = useLibrary((s) => s.items);
	const ready = useLibrary((s) => s.ready);
	const addUrl = useLibrary((s) => s.addUrl);
	const open = usePlayer((s) => s.open);
	const navigate = useNavigate();
	const watching = continueWatching(items);
	const recent = itemsForTab(items, "recent").slice(0, 12);
	const videos = items.filter((i) => i.kind === "video").slice(0, 12);
	const music = itemsForTab(items, "music").slice(0, 12);
	const favs = itemsForTab(items, "favourites").slice(0, 12);
	const empty = ready && items.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-primary",
						children: "UPLAY.IND"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl font-semibold tracking-tight md:text-5xl",
						children: "Your library. Your pace."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-muted",
						children: APP_TAGLINE
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddMediaButton, {})
				})]
			}),
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] sm:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-semibold",
						children: "Nothing here yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-lg text-sm text-muted",
						children: "Add files from this device, or play a direct media URL. Scanning stays on-device — nothing is uploaded."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddMediaButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/browser",
								children: "Open browser"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium text-muted",
							children: "Try a public-domain stream"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 grid gap-2 sm:grid-cols-3",
							children: PUBLIC_STREAMS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex w-full items-center gap-3 rounded-lg bg-elevated p-3 text-left shadow-[var(--shadow-border)] transition-colors hover:bg-secondary",
								onClick: () => {
									const item = addUrl(s.name, s.url, s.kind);
									open(item);
									navigate({
										to: "/player/$id",
										params: { id: item.id }
									});
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-10 items-center justify-center rounded-md bg-primary/15 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-medium",
									children: s.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: s.note
								})] })]
							}) }, s.id))
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaRail, {
					title: "Continue watching",
					items: watching
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaRail, {
					title: "Recently played",
					items: recent
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaRail, {
					title: "Videos",
					items: videos
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaRail, {
					title: "Music",
					items: music
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaRail, {
					title: "Favourites",
					items: favs
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/library",
						icon: FolderOpen,
						title: "Library",
						copy: "Videos, movies, music, folders"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/downloads",
						icon: Download,
						title: "Downloads",
						copy: "Direct media URLs only"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/browser",
						icon: Compass,
						title: "Browser",
						copy: "Look up pages, then play direct links"
					})
				]
			})
		]
	});
}
function Quick({ to, icon: Icon, title, copy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] transition-colors hover:bg-elevated",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: copy
			})
		]
	});
}
//#endregion
export { Home as component };
