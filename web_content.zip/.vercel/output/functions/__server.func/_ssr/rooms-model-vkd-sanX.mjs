import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms-model-vkd-sanX.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-B40BzJxt.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-CrEe0iON.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
function toNumber(value) {
	const n = Number(value);
	return Number.isFinite(n) ? n : 0;
}
function computeOwnerCommission(room) {
	const rent = toNumber(room.rent);
	const val = toNumber(room.commissionValue);
	if (room.commissionType === "fixed") return val;
	return Math.round(rent * val / 100 * 100) / 100;
}
function computeRenterCommission(room) {
	const rent = toNumber(room.rent);
	const val = toNumber(room.renterCommissionValue);
	if (room.renterCommissionType === "fixed") return val;
	return Math.round(rent * val / 100 * 100) / 100;
}
function computeCommission(room) {
	return Math.round((computeOwnerCommission(room) + computeRenterCommission(room)) * 100) / 100;
}
function fmtMoney(amount, currency) {
	const n = toNumber(amount);
	const val = n % 1 === 0 ? n.toString() : n.toFixed(2);
	return currency ? `${currency} ${val}` : val;
}
function hashArea(s) {
	let h = 0;
	for (let i = 0; i < s.length; i += 1) h = Math.imul(h, 31) + s.charCodeAt(i) >>> 0;
	return h;
}
function areaPin(area) {
	return {
		x: 40 + hashArea(`${area}x`) % 520,
		y: 40 + hashArea(`${area}y`) % 240
	};
}
function telHref(phone) {
	return `tel:${String(phone || "").replace(/[^\d+]/g, "")}`;
}
function waHref(number, text) {
	return `https://wa.me/${String(number || "").replace(/[^\d]/g, "")}${text ? `?text=${encodeURIComponent(text)}` : ""}`;
}
function gmapsHref(location) {
	return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location || "")}`;
}
function safeFileName(s) {
	return String(s || "listing").replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "listing";
}
var REF_KEY = "rd_ref";
var REF_ROOM_KEY = "rd_ref_room";
function captureReferral(ref, room) {
	if (typeof window === "undefined") return;
	try {
		if (ref) sessionStorage.setItem(REF_KEY, ref);
		if (room) sessionStorage.setItem(REF_ROOM_KEY, room);
	} catch {}
}
function getStoredReferral() {
	if (typeof window === "undefined") return {
		ref: null,
		room: null
	};
	try {
		return {
			ref: sessionStorage.getItem(REF_KEY),
			room: sessionStorage.getItem(REF_ROOM_KEY)
		};
	} catch {
		return {
			ref: null,
			room: null
		};
	}
}
function downloadTextFile(filename, data) {
	const blob = new Blob([data], { type: "text/plain;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
//#endregion
export { computeOwnerCommission as a, fmtMoney as c, safeFileName as d, telHref as f, computeCommission as i, getStoredReferral as l, waHref as m, authMiddleware as n, computeRenterCommission as o, toNumber as p, captureReferral as r, downloadTextFile as s, areaPin as t, gmapsHref as u };
