import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Scale, c as Plus, i as ShoppingCart, l as Menu, o as Save, r as Trash2, s as Printer, t as X } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dfsnnm_U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function num(v) {
	if (v === null || v === void 0 || v === "") return 0;
	const n = parseFloat(String(v).replace(/,/g, ".").replace(/\s/g, ""));
	return Number.isFinite(n) ? n : 0;
}
function ymd(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function formatNow(d = /* @__PURE__ */ new Date()) {
	return d.toLocaleString("ar-DZ-u-nu-latn", {
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function money(n, digits = 2) {
	return new Intl.NumberFormat("ar-DZ-u-nu-latn", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	}).format(Number.isFinite(n) ? n : 0);
}
function formatQty(n) {
	if (!Number.isFinite(n) || n === 0) return "";
	const r = Math.round(n * 1e3) / 1e3;
	return String(r);
}
function priceOf(c, mode) {
	if (mode === "visitor") return c.priceVisitor || 0;
	if (mode === "sales") return c.priceSale || 0;
	return c.priceDealer || 0;
}
function unitPrice(it) {
	return num(it.pricePerKg) || num(it.priceDefault) || 0;
}
function lineTotal(it) {
	const price = unitPrice(it);
	if (it.byCount) return num(it.quantity) * price;
	return num(it.weight) * price;
}
function emptyStages() {
	return [{
		value: "",
		targetId: "",
		sides: []
	}, {
		value: "",
		targetId: "",
		sides: []
	}];
}
function stageGross(stages, i) {
	if (i < 1) return 0;
	return Math.max(0, num(stages[i - 1]?.value) - num(stages[i]?.value));
}
function totalGross(stages) {
	let t = 0;
	for (let i = 1; i < stages.length; i++) t += stageGross(stages, i);
	return t;
}
function sideWeight(items, sideId) {
	const it = items.find((x) => x.id === sideId);
	return it ? num(it.weight) : 0;
}
function makeLine(c, mode) {
	return {
		id: c.id,
		name: c.name,
		emoji: c.emoji || "",
		weight: "",
		quantity: "",
		byCount: !!c.byCount,
		pricePerKg: "",
		priceDefault: priceOf(c, mode),
		fromStage: false,
		manualWeight: false
	};
}
function recomputeTargets(session, mode, commodities, respectManual) {
	const items = session.items.map((it) => ({ ...it }));
	const add = {};
	for (let i = 1; i < session.stages.length; i++) {
		const st = session.stages[i];
		const gross = stageGross(session.stages, i);
		const sideW = st.sides.reduce((sum, side) => sum + sideWeight(items, side.id), 0);
		const net = Math.max(0, gross - sideW);
		const tid = Number(st.targetId);
		if (tid && net > 0) add[tid] = (add[tid] || 0) + net;
	}
	for (const [idStr, weight] of Object.entries(add)) {
		const id = Number(idStr);
		const idx = items.findIndex((x) => x.id === id);
		const w = formatQty(weight);
		if (idx === -1) {
			const c = commodities.find((x) => x.id === id);
			if (!c) continue;
			const line = makeLine(c, mode);
			line.weight = w;
			line.fromStage = true;
			items.push(line);
		} else if (respectManual && items[idx].manualWeight) items[idx] = {
			...items[idx],
			fromStage: false
		};
		else items[idx] = {
			...items[idx],
			weight: w,
			fromStage: true,
			manualWeight: false
		};
	}
	for (let i = 0; i < items.length; i++) {
		const it = items[i];
		if (it.fromStage && !it.manualWeight && add[it.id] == null) items[i] = {
			...it,
			weight: "",
			fromStage: false
		};
	}
	return {
		...session,
		items
	};
}
function keptItems(items) {
	return items.filter((it) => it.byCount ? num(it.quantity) > 0 || num(it.weight) > 0 : num(it.weight) > 0);
}
function toSaved(it) {
	const price = unitPrice(it);
	return {
		id: it.id,
		name: it.name,
		emoji: it.emoji,
		weight: num(it.weight),
		quantity: num(it.quantity),
		byCount: !!it.byCount,
		pricePerKg: price,
		total: lineTotal(it)
	};
}
function qtyLabel(it) {
	if (it.byCount && it.quantity > 0) {
		const extra = it.weight > 0 ? ` · ${money(it.weight, 2)} كغ` : "";
		return `${money(it.quantity, it.quantity % 1 ? 2 : 0)} قطعة${extra}`;
	}
	return `${money(it.weight, 2)} كغ`;
}
function weekRange(ym, day) {
	const [y, m] = ym.split("-").map(Number);
	const last = new Date(y || 2e3, m || 1, 0).getDate();
	const start = Math.floor((Math.max(1, day) - 1) / 7) * 7 + 1;
	const end = Math.min(start + 6, last);
	const pad = (n) => String(n).padStart(2, "0");
	return {
		start,
		end,
		from: `${ym}-${pad(start)}`,
		to: `${ym}-${pad(end)}`
	};
}
function inPeriod(dk, period, day, month) {
	if (!dk) return period === "all";
	if (period === "today") return dk === day;
	if (period === "month") return dk.slice(0, 7) === month;
	if (period === "week") {
		const dom = Number(day.slice(8, 10)) || 1;
		const w = weekRange(month || day.slice(0, 7), dom);
		return dk >= w.from && dk <= w.to;
	}
	return true;
}
function calcStock(history, period, modes, day, month) {
	const map = /* @__PURE__ */ new Map();
	for (const tx of history) {
		if (!modes.includes(tx.mode)) continue;
		if (!inPeriod(tx.dateKey, period, day, month)) continue;
		for (const it of tx.items) {
			const key = it.name || `#${it.id}`;
			let row = map.get(key);
			if (!row) {
				row = {
					name: key,
					emoji: it.emoji || "",
					weight: 0,
					qty: 0,
					cost: 0,
					byPrice: [],
					buckets: /* @__PURE__ */ new Map()
				};
				map.set(key, row);
			}
			const price = num(it.pricePerKg);
			const cost = num(it.total) || (it.byCount ? num(it.quantity) * price : num(it.weight) * price);
			row.weight += num(it.weight);
			row.qty += num(it.quantity);
			row.cost += cost;
			if (it.emoji) row.emoji = it.emoji;
			const pk = String(price);
			let bucket = row.buckets.get(pk);
			if (!bucket) {
				bucket = {
					price,
					weight: 0,
					qty: 0,
					cost: 0
				};
				row.buckets.set(pk, bucket);
			}
			bucket.weight += num(it.weight);
			bucket.qty += num(it.quantity);
			bucket.cost += cost;
		}
	}
	return [...map.values()].map((row) => ({
		name: row.name,
		emoji: row.emoji,
		weight: row.weight,
		qty: row.qty,
		cost: row.cost,
		byPrice: [...row.buckets.values()].sort((a, b) => b.price - a.price)
	})).sort((a, b) => b.weight - a.weight || b.cost - a.cost);
}
function daysBetween(start, end) {
	if (!start || !end) return 0;
	const a = /* @__PURE__ */ new Date(`${start}T00:00:00`);
	const b = /* @__PURE__ */ new Date(`${end}T00:00:00`);
	if (Number.isNaN(a.getTime()) || Number.isNaN(b.getTime()) || b < a) return 0;
	return Math.floor((b.getTime() - a.getTime()) / 864e5) + 1;
}
function workerMath(input) {
	const autoDays = daysBetween(input.start, input.end);
	const days = input.daysRaw.trim() === "" ? autoDays : num(input.daysRaw);
	const expense = input.expenses.reduce((a, x) => a + num(x.amount), 0);
	const effective = Math.max(0, days - num(input.absent) + num(input.half) * .5);
	const gross = effective * num(input.wage);
	return {
		days,
		autoDays,
		expense,
		effective,
		gross,
		net: gross - expense - num(input.mobile)
	};
}
var DIGIT_AR = "٠١٢٣٤٥٦٧٨٩";
var DIGIT_FA = "۰۱۲۳۴۵۶۷۸۹";
function normalizeDigits(str) {
	return String(str || "").replace(/[٠-٩]/g, (c) => String(DIGIT_AR.indexOf(c))).replace(/[۰-۹]/g, (c) => String(DIGIT_FA.indexOf(c)));
}
function localYmdFromDate(d) {
	if (Number.isNaN(d.getTime())) return "";
	return ymd(d);
}
function deriveDateKey(tx) {
	if (tx.dateKey && /^\d{4}-\d{2}-\d{2}$/.test(tx.dateKey)) return tx.dateKey;
	const id = Number(tx.id);
	if (id > 1e11 && id < 0x5af3107a4000) {
		const fromId = localYmdFromDate(new Date(id));
		if (fromId) return fromId;
	}
	if (!tx.datetime) return "";
	const s = normalizeDigits(tx.datetime);
	let m = s.match(/(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})/);
	if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
	m = s.match(/(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})/);
	if (m) return `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
	const d = new Date(s);
	if (!Number.isNaN(d.getTime())) return localYmdFromDate(d);
	return "";
}
function escapeHtml(s) {
	return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function periodBounds(kind, now = /* @__PURE__ */ new Date()) {
	const today = ymd(now);
	if (kind === "day") return {
		from: today,
		to: today,
		label: `يومي — ${today}`
	};
	if (kind === "week") {
		const w = weekRange(today.slice(0, 7), Number(today.slice(8, 10)));
		return {
			from: w.from,
			to: w.to,
			label: `أسبوعي ${w.from} → ${w.to}`
		};
	}
	if (kind === "month") {
		const ym = today.slice(0, 7);
		const [y, m] = ym.split("-").map(Number);
		const last = new Date(y, m, 0).getDate();
		return {
			from: `${ym}-01`,
			to: `${ym}-${String(last).padStart(2, "0")}`,
			label: `شهري — ${ym}`
		};
	}
	return {
		from: "",
		to: "",
		label: "شامل (كل البيانات)"
	};
}
function txsInRange(history, from, to) {
	return history.filter((tx) => {
		const dk = tx.dateKey;
		if ((from || to) && !dk) return false;
		if (from && dk < from) return false;
		if (to && dk > to) return false;
		return true;
	}).sort((a, b) => b.id - a.id);
}
function stockSummaryText(history, from, to) {
	const buy = /* @__PURE__ */ new Map();
	const sale = /* @__PURE__ */ new Map();
	const add = (map, it) => {
		const k = it.name || "?";
		const row = map.get(k) || {
			w: 0,
			c: 0
		};
		row.w += num(it.weight);
		row.c += num(it.total) || num(it.weight) * num(it.pricePerKg);
		map.set(k, row);
	};
	for (const tx of history) {
		const dk = tx.dateKey;
		if (from && dk && dk < from) continue;
		if (to && dk && dk > to) continue;
		for (const it of tx.items) if (tx.mode === "sales") add(sale, it);
		else add(buy, it);
	}
	const names = /* @__PURE__ */ new Set([...buy.keys(), ...sale.keys()]);
	const lines = [];
	for (const n of names) {
		const b = buy.get(n) || {
			w: 0,
			c: 0
		};
		const s = sale.get(n) || {
			w: 0,
			c: 0
		};
		lines.push(`${n}: شراء ${b.w.toFixed(2)} كغ / بيع ${s.w.toFixed(2)} كغ / صافي ${(b.w - s.w).toFixed(2)} كغ`);
	}
	return lines.join("\n") || "لا بيانات مخزن";
}
var MODE_LABEL = {
	visitor: "زائر",
	dealer: "متعامل",
	special: "خاص",
	sales: "مبيعات"
};
function buildReportHtml(history, kind, shop, pays) {
	const range = periodBounds(kind);
	const list = txsInRange(history, range.from, range.to);
	const buyTotal = list.filter((t) => t.mode !== "sales").reduce((a, t) => a + num(t.grandTotal), 0);
	const saleTotal = list.filter((t) => t.mode === "sales").reduce((a, t) => a + num(t.grandTotal), 0);
	const creditCount = list.filter((t) => t.isCredit).length;
	const rows = list.map((tx) => {
		const items = tx.items.map((it) => `${escapeHtml(it.emoji)} ${escapeHtml(it.name)}: ${escapeHtml(qtyLabel(it))} = ${money(it.total)} دج`).join("<br>");
		return `<tr>
        <td>${escapeHtml(tx.datetime || tx.dateKey)}</td>
        <td>${escapeHtml(tx.name)}</td>
        <td>${MODE_LABEL[tx.mode]}</td>
        <td>${tx.isCredit ? "بالدين" : "نقدي"}</td>
        <td>${items}</td>
        <td>${money(tx.grandTotal)}</td>
      </tr>`;
	}).join("");
	const payRows = pays.filter((p) => {
		const dk = p.dateKey;
		if ((range.from || range.to) && !dk) return false;
		if (range.from && dk < range.from) return false;
		if (range.to && dk > range.to) return false;
		return true;
	}).map((p) => `<tr><td>${escapeHtml(p.dateKey)}</td><td>${escapeHtml(p.name)}</td><td>${money(p.net)}</td><td>${p.paid ? "مدفوع" : "غير مدفوع"}</td></tr>`).join("");
	return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>تقرير ${escapeHtml(range.label)}</title>
<style>body{font-family:Tahoma,Arial,sans-serif;padding:16px;color:#0f172a}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border:1px solid #cbd5e1;padding:6px;text-align:right}th{background:#e2e8f0}h1,h2{color:#0f766e}</style>
</head><body>
<h1>${escapeHtml(shop || "نظام الوزن والبيع")}</h1>
<h2>تقرير ${escapeHtml(range.label)}</h2>
<p>العمليات: ${list.length} | مشتريات: ${money(buyTotal)} دج | مبيعات: ${money(saleTotal)} دج | بالدين: ${creditCount}</p>
<h2>المخزن</h2>
<pre style="white-space:pre-wrap;background:#f8fafc;padding:12px;border-radius:8px;">${escapeHtml(stockSummaryText(history, range.from, range.to))}</pre>
<h2>العمليات</h2>
<table><thead><tr><th>التاريخ</th><th>الاسم</th><th>النوع</th><th>الدفع</th><th>التفاصيل</th><th>المجموع</th></tr></thead>
<tbody>${rows || "<tr><td colspan=\"6\">لا عمليات</td></tr>"}</tbody></table>
<h2>محاسبة العمال</h2>
<table><thead><tr><th>التاريخ</th><th>العامل</th><th>الصافي</th><th>الحالة</th></tr></thead>
<tbody>${payRows || "<tr><td colspan=\"4\">لا سجلات</td></tr>"}</tbody></table>
</body></html>`;
}
function buildReportText(history, kind) {
	const range = periodBounds(kind);
	const list = txsInRange(history, range.from, range.to);
	const buyTotal = list.filter((t) => t.mode !== "sales").reduce((a, t) => a + num(t.grandTotal), 0);
	const saleTotal = list.filter((t) => t.mode === "sales").reduce((a, t) => a + num(t.grandTotal), 0);
	return `تقرير ${range.label}
العمليات: ${list.length}
المشتريات: ${money(buyTotal)} دج
المبيعات: ${money(saleTotal)} دج
بالدين: ${list.filter((t) => t.isCredit).length}
---
${stockSummaryText(history, range.from, range.to).slice(0, 1500)}`;
}
function downloadText(fileName, content, type = "text/html;charset=utf-8") {
	const blob = new Blob([content], { type });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = fileName;
	document.body.appendChild(a);
	a.click();
	setTimeout(() => {
		a.remove();
		URL.revokeObjectURL(url);
	}, 400);
}
var seq = 0;
function uid() {
	seq = (seq + 1) % 1e3;
	return Date.now() * 1e3 + seq;
}
var MODES = [
	"visitor",
	"dealer",
	"special",
	"sales"
];
var MODE_META = {
	visitor: {
		label: "زائر",
		title: "الزائر",
		price: "سعر الزائر"
	},
	dealer: {
		label: "متعامل",
		title: "المتعامل",
		price: "سعر المتعامل"
	},
	special: {
		label: "خاص",
		title: "خاص",
		price: "سعر المتعامل"
	},
	sales: {
		label: "مبيعات",
		title: "المبيعات",
		price: "سعر البيع"
	}
};
var defaultCommodities = [
	{
		id: 1,
		name: "الحديد",
		emoji: "⚙️",
		priceVisitor: 45,
		priceDealer: 40,
		priceSale: 55,
		byCount: false
	},
	{
		id: 2,
		name: "البلاستك",
		emoji: "🧴",
		priceVisitor: 25,
		priceDealer: 20,
		priceSale: 32,
		byCount: false
	},
	{
		id: 3,
		name: "الكرسي",
		emoji: "🪑",
		priceVisitor: 30,
		priceDealer: 25,
		priceSale: 38,
		byCount: false
	},
	{
		id: 4,
		name: "Pvc",
		emoji: "🔩",
		priceVisitor: 35,
		priceDealer: 30,
		priceSale: 42,
		byCount: false
	},
	{
		id: 5,
		name: "ڨوثا",
		emoji: "📦",
		priceVisitor: 20,
		priceDealer: 15,
		priceSale: 25,
		byCount: false
	},
	{
		id: 6,
		name: "باش",
		emoji: "🗑️",
		priceVisitor: 15,
		priceDealer: 12,
		priceSale: 20,
		byCount: false
	},
	{
		id: 7,
		name: "Pet",
		emoji: "♻️",
		priceVisitor: 28,
		priceDealer: 22,
		priceSale: 35,
		byCount: false
	},
	{
		id: 8,
		name: "حمرة",
		emoji: "🔴",
		priceVisitor: 50,
		priceDealer: 45,
		priceSale: 60,
		byCount: false
	},
	{
		id: 9,
		name: "صفرة",
		emoji: "🟡",
		priceVisitor: 55,
		priceDealer: 50,
		priceSale: 65,
		byCount: false
	},
	{
		id: 10,
		name: "صافي",
		emoji: "✨",
		priceVisitor: 60,
		priceDealer: 55,
		priceSale: 70,
		byCount: false
	},
	{
		id: 11,
		name: "موسخ",
		emoji: "🟤",
		priceVisitor: 35,
		priceDealer: 30,
		priceSale: 42,
		byCount: false
	},
	{
		id: 12,
		name: "بوبيناج",
		emoji: "🔌",
		priceVisitor: 70,
		priceDealer: 65,
		priceSale: 85,
		byCount: false
	},
	{
		id: 13,
		name: "باطري",
		emoji: "🔋",
		priceVisitor: 80,
		priceDealer: 70,
		priceSale: 95,
		byCount: false
	},
	{
		id: 14,
		name: "R فروة",
		emoji: "🧥",
		priceVisitor: 40,
		priceDealer: 35,
		priceSale: 50,
		byCount: false
	},
	{
		id: 15,
		name: "R بيضة",
		emoji: "⚪",
		priceVisitor: 42,
		priceDealer: 37,
		priceSale: 52,
		byCount: false
	},
	{
		id: 16,
		name: "ڨاجو نوار",
		emoji: "⚫",
		priceVisitor: 48,
		priceDealer: 43,
		priceSale: 58,
		byCount: false
	},
	{
		id: 17,
		name: "ڨاجو كولار",
		emoji: "🎨",
		priceVisitor: 52,
		priceDealer: 47,
		priceSale: 62,
		byCount: false
	},
	{
		id: 18,
		name: "خفيف",
		emoji: "🪶",
		priceVisitor: 18,
		priceDealer: 15,
		priceSale: 24,
		byCount: false
	},
	{
		id: 19,
		name: "فيثرينا",
		emoji: "🪟",
		priceVisitor: 25,
		priceDealer: 20,
		priceSale: 32,
		byCount: false
	},
	{
		id: 20,
		name: "تلفاز",
		emoji: "📺",
		priceVisitor: 35,
		priceDealer: 30,
		priceSale: 45,
		byCount: true
	},
	{
		id: 21,
		name: "موتور",
		emoji: "⚙️",
		priceVisitor: 65,
		priceDealer: 58,
		priceSale: 78,
		byCount: true
	},
	{
		id: 22,
		name: "كانيط",
		emoji: "🥫",
		priceVisitor: 22,
		priceDealer: 18,
		priceSale: 28,
		byCount: false
	},
	{
		id: 23,
		name: "مارجي",
		emoji: "📊",
		priceVisitor: 30,
		priceDealer: 25,
		priceSale: 38,
		byCount: false
	}
];
var emptyReport = () => ({
	email: "",
	email2: "",
	shop: "",
	ejPublic: "",
	ejService: "",
	ejTemplate: ""
});
function blankSession(id) {
	return {
		id,
		name: "",
		isCredit: false,
		items: [],
		stages: emptyStages()
	};
}
function initialSessions() {
	return {
		visitor: [blankSession(1)],
		dealer: [blankSession(2)],
		special: [blankSession(3)],
		sales: [blankSession(4)]
	};
}
function initialActive() {
	return {
		visitor: 1,
		dealer: 2,
		special: 3,
		sales: 4
	};
}
function sessionOf(state, mode) {
	const list = state.sessions[mode];
	return list.find((s) => s.id === state.activeId[mode]) ?? list[0];
}
function writeSession(state, mode, session) {
	return {
		sessions: {
			...state.sessions,
			[mode]: state.sessions[mode].map((s) => s.id === session.id ? session : s)
		},
		updatedAt: Date.now()
	};
}
function asStr(v) {
	if (v === null || v === void 0) return "";
	if (typeof v === "number") {
		if (!Number.isFinite(v) || v === 0) return "";
		return String(v);
	}
	return String(v);
}
function coerceLine(raw) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	const id = Number(o.id);
	if (!id) return null;
	return {
		id,
		name: String(o.name || ""),
		emoji: String(o.emoji || ""),
		weight: asStr(o.weight),
		quantity: asStr(o.quantity),
		byCount: !!o.byCount,
		pricePerKg: asStr(o.pricePerKg),
		priceDefault: num(o.priceDefault),
		fromStage: !!o.fromStage,
		manualWeight: !!o.manualWeight
	};
}
function coerceStage(raw) {
	if (!raw || typeof raw !== "object") return {
		value: "",
		targetId: "",
		sides: []
	};
	const o = raw;
	const sides = (Array.isArray(o.sides) ? o.sides : []).map((s) => {
		if (!s || typeof s !== "object") return null;
		const id = Number(s.id);
		return id ? { id } : null;
	}).filter((s) => !!s);
	return {
		value: asStr(o.value),
		targetId: o.targetId ? String(o.targetId) : "",
		sides
	};
}
function coerceSession(raw, fallbackId) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	const id = Number(o.id) || fallbackId;
	const stagesRaw = Array.isArray(o.stages) ? o.stages.map(coerceStage) : [];
	const stages = stagesRaw.length >= 2 ? stagesRaw : emptyStages();
	const items = (Array.isArray(o.items) ? o.items : []).map(coerceLine).filter((x) => !!x);
	return {
		id,
		name: String(o.name || ""),
		isCredit: !!o.isCredit,
		items,
		stages
	};
}
function isMode$1(v) {
	return v === "visitor" || v === "dealer" || v === "special" || v === "sales";
}
function coerceSavedItem(raw) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	const price = num(o.pricePerKg);
	const weight = num(o.weight);
	const quantity = num(o.quantity);
	const byCount = !!o.byCount;
	const total = num(o.total) || (byCount ? quantity * price : weight * price);
	return {
		id: Number(o.id) || 0,
		name: String(o.name || ""),
		emoji: String(o.emoji || ""),
		weight,
		quantity,
		byCount,
		pricePerKg: price,
		total
	};
}
function coerceTx(raw, mode) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	const items = (Array.isArray(o.items) ? o.items : []).map(coerceSavedItem).filter((x) => !!x);
	const id = Number(o.id) || uid();
	const dateKey = deriveDateKey({
		dateKey: typeof o.dateKey === "string" ? o.dateKey : "",
		id: Number(o.id) || void 0,
		datetime: typeof o.datetime === "string" ? o.datetime : ""
	});
	return {
		id,
		mode: isMode$1(o.mode) ? o.mode : mode,
		name: String(o.name || ""),
		isCredit: !!o.isCredit,
		dateKey: dateKey || ymd(),
		datetime: String(o.datetime || dateKey || ""),
		items,
		grandTotal: num(o.grandTotal) || items.reduce((a, it) => a + it.total, 0)
	};
}
function coerceCommodity(raw) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	const name = String(o.name || "").trim();
	if (!name) return null;
	const id = Number(o.id) || uid();
	let byCount = !!o.byCount;
	if (o.byCount === void 0 && (name === "تلفاز" || name === "موتور")) byCount = true;
	return {
		id,
		name,
		emoji: String(o.emoji || "📦"),
		priceVisitor: num(o.priceVisitor),
		priceDealer: num(o.priceDealer),
		priceSale: o.priceSale === void 0 ? Math.round(num(o.priceVisitor) * 1.2) : num(o.priceSale),
		byCount
	};
}
function coerceWorker(raw) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	const name = String(o.name || "").trim();
	if (!name) return null;
	return {
		id: Number(o.id) || uid(),
		name,
		wage: num(o.wage),
		start: String(o.start || "")
	};
}
function coercePay(raw) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	const name = String(o.name || "").trim();
	if (!name) return null;
	const expenses = (Array.isArray(o.expenses) ? o.expenses : []).map((e, i) => {
		if (!e || typeof e !== "object") return null;
		const x = e;
		return {
			id: Number(x.id) || i + 1,
			date: String(x.date || ""),
			amount: num(x.amount),
			note: String(x.note || "")
		};
	}).filter((e) => !!e);
	const id = Number(o.id) || uid();
	return {
		id,
		name,
		start: String(o.start || ""),
		end: String(o.end || ""),
		days: num(o.days),
		absent: num(o.absent),
		half: num(o.half),
		wage: num(o.wage),
		expense: num(o.expense),
		expenses,
		mobile: num(o.mobile),
		effective: num(o.effective),
		gross: num(o.gross),
		net: num(o.net),
		paid: !!o.paid,
		paidAt: o.paidAt ? String(o.paidAt) : void 0,
		datetime: String(o.datetime || ""),
		dateKey: deriveDateKey({
			dateKey: typeof o.dateKey === "string" ? o.dateKey : "",
			id,
			datetime: typeof o.datetime === "string" ? o.datetime : ""
		})
	};
}
function normalizePersisted(raw, base) {
	const o = raw && typeof raw === "object" ? raw : {};
	const commodities = Array.isArray(o.commodities) ? o.commodities.map(coerceCommodity).filter((c) => !!c) : base.commodities;
	let history = base.history;
	if (Array.isArray(o.history)) history = o.history.map((tx) => coerceTx(tx, "visitor")).filter((t) => !!t);
	else if (o.history && typeof o.history === "object") {
		const bag = o.history;
		history = [];
		for (const mode of MODES) {
			const list = bag[mode];
			if (!Array.isArray(list)) continue;
			for (const tx of list) {
				const row = coerceTx(tx, mode);
				if (row) history.push(row);
			}
		}
	}
	const sessions = { ...initialSessions() };
	const activeId = { ...initialActive() };
	if (o.sessions && typeof o.sessions === "object") {
		const bag = o.sessions;
		for (const mode of MODES) {
			const list = Array.isArray(bag[mode]) ? bag[mode].map((s, i) => coerceSession(s, i + 1)).filter((s) => !!s) : [];
			if (list.length) sessions[mode] = list;
		}
	}
	if (o.activeId && typeof o.activeId === "object") {
		const bag = o.activeId;
		for (const mode of MODES) {
			const id = Number(bag[mode]);
			if (sessions[mode].some((s) => s.id === id)) activeId[mode] = id;
			else activeId[mode] = sessions[mode][0].id;
		}
	} else for (const mode of MODES) activeId[mode] = sessions[mode][0].id;
	const workers = Array.isArray(o.workers) ? o.workers.map(coerceWorker).filter((w) => !!w) : Array.isArray(o.workerRoster) ? o.workerRoster.map(coerceWorker).filter((w) => !!w) : base.workers;
	const pays = Array.isArray(o.pays) ? o.pays.map(coercePay).filter((p) => !!p) : Array.isArray(o.workerPays) ? o.workerPays.map(coercePay).filter((p) => !!p) : base.pays;
	const reportRaw = o.report && typeof o.report === "object" ? o.report : {};
	const report = {
		email: String(reportRaw.email || ""),
		email2: String(reportRaw.email2 || ""),
		shop: String(reportRaw.shop || ""),
		ejPublic: String(reportRaw.ejPublic || ""),
		ejService: String(reportRaw.ejService || ""),
		ejTemplate: String(reportRaw.ejTemplate || "")
	};
	return {
		commodities: commodities.length ? commodities : base.commodities,
		history,
		sessions,
		activeId,
		workers,
		pays,
		report,
		updatedAt: Number(o.updatedAt) || base.updatedAt || 0
	};
}
function seed() {
	return {
		commodities: defaultCommodities.map((c) => ({ ...c })),
		history: [],
		sessions: initialSessions(),
		activeId: initialActive(),
		workers: [],
		pays: [],
		report: emptyReport(),
		updatedAt: 0
	};
}
var useWeigh = create()(persist((set, get) => ({
	...seed(),
	hydrated: false,
	setHydrated: () => set({ hydrated: true }),
	updateSession: (mode, patch) => {
		const state = get();
		set(writeSession(state, mode, {
			...sessionOf(state, mode),
			...patch
		}));
	},
	patchStage: (mode, index, patch) => {
		const state = get();
		const current = sessionOf(state, mode);
		const stages = current.stages.map((st, i) => i === index ? {
			...st,
			...patch
		} : st);
		set(writeSession(state, mode, recomputeTargets({
			...current,
			stages
		}, mode, state.commodities, false)));
	},
	addStage: (mode) => {
		const state = get();
		const current = sessionOf(state, mode);
		const stages = [...current.stages, {
			value: "",
			targetId: "",
			sides: []
		}];
		set(writeSession(state, mode, recomputeTargets({
			...current,
			stages
		}, mode, state.commodities, false)));
	},
	removeStage: (mode, index) => {
		const state = get();
		const current = sessionOf(state, mode);
		if (current.stages.length <= 2 || index < 2) return;
		const stages = current.stages.filter((_, i) => i !== index);
		set(writeSession(state, mode, recomputeTargets({
			...current,
			stages
		}, mode, state.commodities, false)));
	},
	addSides: (mode, stageIndex, ids) => {
		const state = get();
		const current = sessionOf(state, mode);
		const stages = current.stages.map((st) => ({
			...st,
			sides: [...st.sides]
		}));
		const st = stages[stageIndex];
		if (!st) return;
		let items = [...current.items];
		for (const id of ids) {
			if (String(st.targetId) === String(id)) continue;
			if (st.sides.some((s) => s.id === id)) continue;
			st.sides.push({ id });
			if (!items.some((it) => it.id === id)) {
				const c = state.commodities.find((x) => x.id === id);
				if (c) items.push(makeLine(c, mode));
			}
		}
		set(writeSession(state, mode, recomputeTargets({
			...current,
			stages,
			items
		}, mode, state.commodities, true)));
	},
	removeSide: (mode, stageIndex, sideId) => {
		const state = get();
		const current = sessionOf(state, mode);
		const stages = current.stages.map((st, i) => i === stageIndex ? {
			...st,
			sides: st.sides.filter((s) => s.id !== sideId)
		} : st);
		set(writeSession(state, mode, recomputeTargets({
			...current,
			stages
		}, mode, state.commodities, true)));
	},
	addItem: (mode, commodityId) => {
		const state = get();
		const current = sessionOf(state, mode);
		if (current.items.some((it) => it.id === commodityId)) return;
		const c = state.commodities.find((x) => x.id === commodityId);
		if (!c) return;
		const items = [...current.items, makeLine(c, mode)];
		set(writeSession(state, mode, {
			...current,
			items
		}));
	},
	updateItem: (mode, itemId, field, value) => {
		const state = get();
		const current = sessionOf(state, mode);
		const items = current.items.map((it) => {
			if (it.id !== itemId) return it;
			if (field === "weight") return {
				...it,
				weight: value,
				manualWeight: true,
				fromStage: false
			};
			return {
				...it,
				[field]: value
			};
		});
		set(writeSession(state, mode, field === "weight" ? recomputeTargets({
			...current,
			items
		}, mode, state.commodities, true) : {
			...current,
			items
		}));
	},
	removeItem: (mode, itemId) => {
		const state = get();
		const current = sessionOf(state, mode);
		const items = current.items.filter((it) => it.id !== itemId);
		const stages = current.stages.map((st) => ({
			...st,
			targetId: String(st.targetId) === String(itemId) ? "" : st.targetId,
			sides: st.sides.filter((s) => s.id !== itemId)
		}));
		set(writeSession(state, mode, recomputeTargets({
			...current,
			items,
			stages
		}, mode, state.commodities, true)));
	},
	clearList: (mode) => {
		const state = get();
		set(writeSession(state, mode, {
			...sessionOf(state, mode),
			items: [],
			stages: emptyStages()
		}));
	},
	newSession: (mode) => {
		const state = get();
		const session = blankSession(uid());
		set({
			sessions: {
				...state.sessions,
				[mode]: [...state.sessions[mode], session]
			},
			activeId: {
				...state.activeId,
				[mode]: session.id
			},
			updatedAt: Date.now()
		});
	},
	switchSession: (mode, id) => {
		const state = get();
		if (!state.sessions[mode].some((s) => s.id === id)) return;
		set({
			activeId: {
				...state.activeId,
				[mode]: id
			},
			updatedAt: state.updatedAt
		});
	},
	closeSession: (mode, id) => {
		const state = get();
		const list = state.sessions[mode];
		if (list.length <= 1) return;
		const rest = list.filter((s) => s.id !== id);
		const active = state.activeId[mode] === id ? rest[0].id : state.activeId[mode];
		set({
			sessions: {
				...state.sessions,
				[mode]: rest
			},
			activeId: {
				...state.activeId,
				[mode]: active
			},
			updatedAt: Date.now()
		});
	},
	saveTx: (mode) => {
		const state = get();
		const current = sessionOf(state, mode);
		const name = current.name.trim();
		if (!name) return {
			ok: false,
			error: "أدخل الاسم"
		};
		const items = keptItems(current.items);
		if (!items.length) return {
			ok: false,
			error: "أضف سلعة بوزن أو عدد"
		};
		const saved = items.map(toSaved);
		const tx = {
			id: uid(),
			mode,
			name,
			isCredit: current.isCredit,
			dateKey: ymd(),
			datetime: formatNow(),
			items: saved,
			grandTotal: saved.reduce((a, it) => a + it.total, 0)
		};
		set({
			history: [tx, ...state.history],
			...writeSession(state, mode, {
				...current,
				name: "",
				isCredit: false,
				items: [],
				stages: emptyStages()
			})
		});
		return {
			ok: true,
			tx
		};
	},
	deleteTx: (id) => {
		set({
			history: get().history.filter((t) => t.id !== id),
			updatedAt: Date.now()
		});
	},
	saveCommodity: (data, editId) => {
		const state = get();
		if (editId) {
			set({
				commodities: state.commodities.map((c) => c.id === editId ? {
					...c,
					...data,
					id: c.id
				} : c),
				updatedAt: Date.now()
			});
			return;
		}
		set({
			commodities: [...state.commodities, {
				...data,
				id: uid()
			}],
			updatedAt: Date.now()
		});
	},
	toggleByCount: (id) => {
		set({
			commodities: get().commodities.map((c) => c.id === id ? {
				...c,
				byCount: !c.byCount
			} : c),
			updatedAt: Date.now()
		});
	},
	deleteCommodity: (id) => {
		set({
			commodities: get().commodities.filter((c) => c.id !== id),
			updatedAt: Date.now()
		});
	},
	addWorker: (worker) => {
		const state = get();
		const name = worker.name.trim();
		if (!name) return {
			ok: false,
			error: "أدخل اسم العامل"
		};
		if (state.workers.some((w) => w.name === name)) return {
			ok: false,
			error: "هذا العامل موجود"
		};
		set({
			workers: [...state.workers, {
				...worker,
				name,
				id: uid()
			}],
			updatedAt: Date.now()
		});
		return { ok: true };
	},
	deleteWorker: (id) => {
		set({
			workers: get().workers.filter((w) => w.id !== id),
			updatedAt: Date.now()
		});
	},
	savePay: (pay) => {
		const state = get();
		const idx = state.pays.findIndex((p) => p.id === pay.id);
		const pays = [...state.pays];
		if (idx >= 0) pays[idx] = pay;
		else pays.unshift(pay);
		let workers = state.workers;
		if (!workers.some((w) => w.name === pay.name)) workers = [...workers, {
			id: uid(),
			name: pay.name,
			wage: pay.wage,
			start: pay.start || ymd()
		}];
		set({
			pays,
			workers,
			updatedAt: Date.now()
		});
	},
	markPaid: (id, paid) => {
		set({
			pays: get().pays.map((p) => p.id === id ? {
				...p,
				paid,
				paidAt: paid ? formatNow() : void 0
			} : p),
			updatedAt: Date.now()
		});
	},
	deletePay: (id) => {
		set({
			pays: get().pays.filter((p) => p.id !== id),
			updatedAt: Date.now()
		});
	},
	setReport: (patch) => {
		set({
			report: {
				...get().report,
				...patch
			},
			updatedAt: Date.now()
		});
	},
	exportPayload: () => {
		const s = get();
		return JSON.stringify({
			version: 1,
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			commodities: s.commodities,
			history: s.history,
			sessions: s.sessions,
			activeId: s.activeId,
			workers: s.workers,
			pays: s.pays,
			report: s.report,
			updatedAt: s.updatedAt
		}, null, 2);
	},
	importPayload: (raw) => {
		try {
			const state = get();
			if (!raw || typeof raw !== "object") return {
				ok: false,
				error: "ملف غير صالح"
			};
			const o = raw;
			if (!Array.isArray(o.commodities) && !o.history && !o.workerPays && !o.pays && !o.workerRoster && !o.workers) return {
				ok: false,
				error: "الملف لا يحتوي بيانات"
			};
			const next = normalizePersisted(raw, {
				...seed(),
				report: state.report,
				sessions: state.sessions,
				activeId: state.activeId
			});
			set({
				...next,
				updatedAt: Date.now()
			});
			return {
				ok: true,
				count: next.history.length
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "فشل الاستيراد"
			};
		}
	}
}), {
	name: "mizan-dz-v1",
	skipHydration: true,
	partialize: (s) => ({
		commodities: s.commodities,
		history: s.history,
		sessions: s.sessions,
		activeId: s.activeId,
		workers: s.workers,
		pays: s.pays,
		report: s.report,
		updatedAt: s.updatedAt
	}),
	merge: (persisted, current) => {
		const data = normalizePersisted(persisted, current);
		return {
			...current,
			...data
		};
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var inputClass = "h-12 w-full rounded-xl border border-line bg-bg px-3 text-base text-fg outline-none";
var btnClass = "inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition-opacity disabled:opacity-50";
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("block min-w-0", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-xs font-medium text-muted",
			children: label
		}), children]
	});
}
function Card({ title, children, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-3 rounded-2xl border border-line bg-surface p-4",
		children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold text-primary",
				children: title
			}), action]
		}) : null, children]
	});
}
function Modal({ title, onClose, children }) {
	(0, import_react.useEffect)(() => {
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = prev;
			window.removeEventListener("keydown", onKey);
		};
	}, [onClose]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-3 sm:items-center",
		onMouseDown: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "max-h-[88vh] w-full max-w-lg overflow-auto rounded-2xl border border-line bg-surface p-4",
			onMouseDown: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg font-bold text-primary",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					"aria-label": "إغلاق",
					className: "flex size-11 items-center justify-center rounded-full bg-surface-2 text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})
	});
}
function ArchiveView({ onPrint }) {
	const history = useWeigh((s) => s.history);
	const shop = useWeigh((s) => s.report.shop);
	const deleteTx = useWeigh((s) => s.deleteTx);
	const [name, setName] = (0, import_react.useState)("");
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("all");
	const rows = (0, import_react.useMemo)(() => {
		const q = name.trim().toLowerCase();
		return history.filter((tx) => {
			if (type !== "all" && tx.mode !== type) return false;
			if (q && !tx.name.toLowerCase().includes(q)) return false;
			if (from && tx.dateKey && tx.dateKey < from) return false;
			if (to && tx.dateKey && tx.dateKey > to) return false;
			return true;
		}).sort((a, b) => b.id - a.id);
	}, [
		history,
		name,
		from,
		to,
		type
	]);
	const sum = rows.reduce((a, tx) => a + tx.grandTotal, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "سجل العمليات",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "بحث بالاسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: name,
							placeholder: "اسم...",
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "النوع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: inputClass,
							value: type,
							onChange: (e) => setType(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "الكل"
							}), MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: m,
								children: MODE_META[m].label
							}, m))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "من تاريخ",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: inputClass,
							value: from,
							onChange: (e) => setFrom(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "إلى تاريخ",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: inputClass,
							value: to,
							onChange: (e) => setTo(e.target.value)
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: [
					rows.length,
					" عملية · ",
					money(sum),
					" دج"
				]
			})]
		}),
		rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-6 text-center text-sm text-muted",
			children: "لا نتائج. العمليات المحفوظة تبقى على هذا الجهاز."
		}) }) : null,
		rows.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex flex-wrap items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-bold",
					children: tx.name || "—"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex flex-wrap gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-primary/15 px-2 py-1 text-primary",
						children: MODE_META[tx.mode].label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: tx.isCredit ? "rounded-full bg-accent/20 px-2 py-1 text-accent" : "rounded-full bg-primary/10 px-2 py-1 text-primary",
						children: tx.isCredit ? "بالدين" : "نقدي"
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted",
					children: tx.datetime || tx.dateKey
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 text-sm",
				children: tx.items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3 border-b border-line/70 py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						it.emoji,
						" ",
						it.name,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [" · ", qtyLabel(it)]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-accent",
						children: money(it.total)
					})]
				}, `${it.id}-${i}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [money(tx.grandTotal), " دج"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "طباعة السند",
						className: "flex size-11 items-center justify-center rounded-xl bg-accent text-accent-fg",
						onClick: () => onPrint({
							kind: "sale",
							bonNum: tx.id,
							name: tx.name,
							datetime: tx.datetime,
							isCredit: tx.isCredit,
							mode: tx.mode,
							items: tx.items,
							grand: tx.grandTotal,
							shop
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "حذف العملية",
						className: "flex size-11 items-center justify-center rounded-xl bg-danger text-danger-fg",
						onClick: () => {
							if (!window.confirm("حذف العملية؟ لا يمكن التراجع.")) return;
							deleteTx(tx.id);
							toast.success("حُذفت العملية");
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				})]
			})
		] }, tx.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "px-1 text-center text-xs text-muted",
			children: ["اليوم ", ymd()]
		})
	] });
}
function DealView({ mode, onPrint }) {
	const session = useWeigh((s) => s.sessions[mode].find((x) => x.id === s.activeId[mode]) ?? s.sessions[mode][0]);
	const sessions = useWeigh((s) => s.sessions[mode]);
	const commodities = useWeigh((s) => s.commodities);
	const shop = useWeigh((s) => s.report.shop);
	const updateSession = useWeigh((s) => s.updateSession);
	const patchStage = useWeigh((s) => s.patchStage);
	const addStage = useWeigh((s) => s.addStage);
	const removeStage = useWeigh((s) => s.removeStage);
	const addSides = useWeigh((s) => s.addSides);
	const removeSide = useWeigh((s) => s.removeSide);
	const addItem = useWeigh((s) => s.addItem);
	const updateItem = useWeigh((s) => s.updateItem);
	const removeItem = useWeigh((s) => s.removeItem);
	const clearList = useWeigh((s) => s.clearList);
	const newSession = useWeigh((s) => s.newSession);
	const switchSession = useWeigh((s) => s.switchSession);
	const closeSession = useWeigh((s) => s.closeSession);
	const saveTx = useWeigh((s) => s.saveTx);
	const [clock, setClock] = (0, import_react.useState)(formatNow);
	const [goodsOpen, setGoodsOpen] = (0, import_react.useState)(false);
	const [sideStage, setSideStage] = (0, import_react.useState)(null);
	const [picked, setPicked] = (0, import_react.useState)([]);
	const armFocus = (0, import_react.useRef)(false);
	const meta = MODE_META[mode];
	(0, import_react.useEffect)(() => {
		const t = setInterval(() => setClock(formatNow()), 3e4);
		return () => clearInterval(t);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!armFocus.current || !session) return;
		armFocus.current = false;
		document.getElementById(`w-${mode}-${session.stages.length - 1}`)?.focus();
	}, [session, mode]);
	if (!session) return null;
	const grand = session.items.reduce((a, it) => a + lineTotal(it), 0);
	const gross = totalGross(session.stages);
	function focusSibling(el) {
		const root = el.closest("[data-fields]");
		if (!root) return;
		const inputs = [...root.querySelectorAll("input, select")];
		const next = inputs[inputs.indexOf(el) + 1];
		if (next) {
			next.focus();
			if (next instanceof HTMLInputElement) next.select();
		}
	}
	function onEnter(e) {
		if (e.key !== "Enter") return;
		e.preventDefault();
		focusSibling(e.currentTarget);
	}
	function buildSlip() {
		const name = session.name.trim();
		if (!name) {
			toast.error("أدخل الاسم");
			return null;
		}
		const items = keptItems(session.items).map(toSaved);
		if (!items.length) {
			toast.error("أضف سلعة بوزن أو عدد");
			return null;
		}
		return {
			kind: "sale",
			bonNum: uid(),
			name,
			datetime: clock,
			isCredit: session.isCredit,
			mode,
			items,
			grand: items.reduce((a, it) => a + it.total, 0),
			shop
		};
	}
	function onSave() {
		const res = saveTx(mode);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		toast.success("تم حفظ المعاملة");
		onPrint({
			kind: "sale",
			bonNum: res.tx.id,
			name: res.tx.name,
			datetime: res.tx.datetime,
			isCredit: res.tx.isCredit,
			mode: res.tx.mode,
			items: res.tx.items,
			grand: res.tx.grandTotal,
			shop
		});
	}
	const stageBox = sideStage != null ? session.stages[sideStage] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: meta.title,
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: `${btnClass} bg-primary text-primary-fg`,
				onClick: () => newSession(mode),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "معاملة جديدة"]
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-xs text-muted",
				children: [meta.price, " · تُحفظ المسودة تلقائياً"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: sessions.map((s, i) => {
					const active = s.id === session.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex h-10 shrink-0 items-center rounded-full border pe-1 ps-3", active ? "border-primary bg-primary/15" : "border-line bg-surface-2"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "max-w-40 truncate text-sm font-medium",
							onClick: () => switchSession(mode, s.id),
							children: s.name || `معاملة ${i + 1}`
						}), sessions.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "إغلاق المعاملة",
							className: "flex size-8 items-center justify-center text-danger",
							onClick: () => closeSession(mode, s.id),
							children: "×"
						}) : null]
					}, s.id);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "البيانات والأوزان",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					"data-fields": true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الاسم",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "tx-name",
								className: inputClass,
								value: session.name,
								placeholder: "اسم الزبون",
								onChange: (e) => updateSession(mode, { name: e.target.value }),
								onKeyDown: onEnter
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "نوع الدفع",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: inputClass,
								value: session.isCredit ? "1" : "0",
								onChange: (e) => updateSession(mode, { isCredit: e.target.value === "1" }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "0",
									children: "نقدي"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "1",
									children: "بالدين"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "التاريخ والوقت",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								readOnly: true,
								value: clock
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted",
					children: "الفرق بين وزنين هو قوس السلعة. السلع الجانبية تُنقص من القوس ويُكتب وزنها في القائمة."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 space-y-3",
					children: session.stages.map((st, i) => {
						if (i === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-xl border border-line bg-bg/50 p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الوزن 1 (كغ)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: `w-${mode}-0`,
									inputMode: "decimal",
									className: inputClass,
									placeholder: "وزن الميزان",
									value: st.value,
									onChange: (e) => patchStage(mode, 0, { value: e.target.value }),
									onFocus: (e) => e.target.select(),
									onKeyDown: (e) => {
										if (e.key !== "Enter") return;
										e.preventDefault();
										const n = document.getElementById(`w-${mode}-1`);
										n?.focus();
										n?.select();
									}
								})
							})
						}, i);
						const g = stageGross(session.stages, i);
						const ss = st.sides.reduce((a, side) => a + sideWeight(session.items, side.id), 0);
						const net = Math.max(0, g - ss);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-line bg-bg/50 p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: `الوزن ${i + 1} — قوس ${i}−${i + 1}`,
										className: "flex-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: `w-${mode}-${i}`,
											inputMode: "decimal",
											className: inputClass,
											placeholder: "وزن",
											value: st.value,
											onChange: (e) => patchStage(mode, i, { value: e.target.value }),
											onFocus: (e) => e.target.select(),
											onKeyDown: (e) => {
												if (e.key !== "Enter") return;
												e.preventDefault();
												const n = document.getElementById(`w-${mode}-${i + 1}`);
												if (n) {
													n.focus();
													n.select();
												}
											}
										})
									}), i >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "حذف الوزن",
										className: `${btnClass} bg-danger text-danger-fg`,
										onClick: () => removeStage(mode, i),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid gap-3 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl border border-primary/40 bg-primary/10 px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted",
											children: "صافي القوس"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-lg font-bold text-primary",
											children: [money(g), " كغ"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "السلعة المستهدفة",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											className: inputClass,
											value: st.targetId,
											onChange: (e) => patchStage(mode, i, { targetId: e.target.value }),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "— بدون —"
											}), commodities.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: c.id,
												children: [
													c.emoji,
													" ",
													c.name
												]
											}, c.id))]
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 rounded-xl bg-surface-2 p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mb-2 text-sm font-semibold text-accent",
											children: "سلع جانبية"
										}),
										st.sides.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: "لا توجد"
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-2",
											children: st.sides.map((side) => {
												const c = commodities.find((x) => x.id === side.id);
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-center justify-between gap-2 text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [c ? `${c.emoji} ${c.name}` : side.id, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-muted",
														children: [
															" · ",
															money(sideWeight(session.items, side.id)),
															" كغ"
														]
													})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														"aria-label": "إزالة سلعة جانبية",
														className: "text-danger",
														onClick: () => removeSide(mode, i, side.id),
														children: "×"
													})]
												}, side.id);
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: `${btnClass} mt-2 bg-accent text-accent-fg`,
											onClick: () => {
												setPicked([]);
												setSideStage(i);
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "size-4" }), "إضافة سلع جانبية"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex justify-between text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												"جانبية: ",
												money(ss),
												" كغ"
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-primary",
												children: [
													"للمستهدفة: ",
													money(net),
													" كغ"
												]
											})]
										})
									]
								}),
								i === session.stages.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `${btnClass} mt-3 w-full bg-accent text-accent-fg`,
									onClick: () => {
										armFocus.current = true;
										addStage(mode);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "إضافة الوزن التالي"]
								}) : null
							]
						}, i);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: ["إجمالي الأقواس: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
						className: "text-primary",
						children: [money(gross), " كغ"]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "السلع",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `${btnClass} bg-primary text-primary-fg`,
					onClick: () => setGoodsOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "size-4" }), "فتح قائمة السلع"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2",
					"data-fields": true,
					children: [session.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-4 text-center text-sm text-muted",
						children: "لم تُضف سلع بعد"
					}) : null, session.items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line bg-bg/40 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-semibold",
									children: [
										it.emoji,
										" ",
										it.name,
										it.byCount ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ms-2 text-xs font-normal text-muted",
											children: "بالقطعة"
										}) : null,
										it.fromStage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ms-2 text-xs font-normal text-primary",
											children: "من القوس"
										}) : null
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `حذف ${it.name}`,
									className: "text-danger",
									onClick: () => removeItem(mode, it.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("grid gap-2", it.byCount ? "sm:grid-cols-3" : "sm:grid-cols-2"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "الوزن (كغ)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											inputMode: "decimal",
											className: inputClass,
											placeholder: "0",
											value: it.weight,
											onChange: (e) => updateItem(mode, it.id, "weight", e.target.value),
											onFocus: (e) => e.target.select(),
											onKeyDown: onEnter
										})
									}),
									it.byCount ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "العدد",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											inputMode: "decimal",
											className: inputClass,
											placeholder: "0",
											value: it.quantity,
											onChange: (e) => updateItem(mode, it.id, "quantity", e.target.value),
											onFocus: (e) => e.target.select(),
											onKeyDown: onEnter
										})
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "السعر (دج)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											inputMode: "decimal",
											className: inputClass,
											placeholder: String(it.priceDefault || "سعر"),
											value: it.pricePerKg,
											onChange: (e) => updateItem(mode, it.id, "pricePerKg", e.target.value),
											onFocus: (e) => e.target.select(),
											onKeyDown: onEnter
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-end text-sm font-bold text-accent",
								children: [money(lineTotal(it)), " دج"]
							})
						]
					}, it.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-between rounded-xl bg-primary/15 px-4 py-3 text-lg font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المجموع" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-accent",
						children: [money(grand), " دج"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `${btnClass} col-span-2 h-12 bg-primary text-base text-primary-fg`,
							onClick: onSave,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "حفظ المعاملة"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `${btnClass} bg-accent text-accent-fg`,
							onClick: () => {
								const slip = buildSlip();
								if (slip) onPrint(slip);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "سند تسليم"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `${btnClass} bg-danger text-danger-fg`,
							onClick: () => {
								if (session.items.length && !window.confirm("مسح القائمة والأوزان؟")) return;
								clearList(mode);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "مسح"]
						})
					]
				})
			]
		}),
		goodsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: `اختيار السلع — ${meta.label}`,
			onClose: () => setGoodsOpen(false),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: "اضغط لإضافة السلعة إلى القائمة. يمكنك اختيار أكثر من واحدة."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2 sm:grid-cols-4",
				children: commodities.map((c) => {
					const inList = session.items.some((it) => it.id === c.id);
					const price = mode === "visitor" ? c.priceVisitor : mode === "sales" ? c.priceSale : c.priceDealer;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => addItem(mode, c.id),
						className: cn("min-h-20 rounded-xl border px-1 py-2 text-center", inList ? "border-primary bg-primary/15" : "border-line bg-bg"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl",
								children: c.emoji || "•"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-xs font-semibold",
								children: c.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-accent",
								children: [
									money(price, 0),
									" ",
									c.byCount ? "دج/ق" : "دج/كغ"
								]
							})
						]
					}, c.id);
				})
			})]
		}) : null,
		sideStage != null && stageBox ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: `سلع جانبية — قوس ${sideStage}−${sideStage + 1}`,
			onClose: () => setSideStage(null),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "حدد السلع ثم أضفها. وزنها يُنقص من القوس."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: commodities.map((c) => {
						const taken = stageBox.sides.some((s) => s.id === c.id) || String(stageBox.targetId) === String(c.id);
						const on = picked.includes(c.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: taken,
							onClick: () => setPicked((p) => p.includes(c.id) ? p.filter((x) => x !== c.id) : [...p, c.id]),
							className: cn("min-h-20 rounded-xl border px-1 py-2 text-center disabled:opacity-40", on ? "border-primary bg-primary/20" : "border-line bg-bg"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xl",
									children: c.emoji || "•"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 text-xs font-semibold",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted",
									children: taken ? String(stageBox.targetId) === String(c.id) ? "مستهدفة" : "موجودة" : on ? "محددة" : "تحديد"
								})
							]
						}, c.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btnClass} mt-4 w-full bg-primary text-primary-fg`,
					onClick: () => {
						if (!picked.length) {
							toast.error("حدد سلعة واحدة أو أكثر");
							return;
						}
						addSides(mode, sideStage, picked);
						setSideStage(null);
					},
					children: "إضافة المحددة"
				})
			]
		}) : null
	] });
}
function GoodsView() {
	const commodities = useWeigh((s) => s.commodities);
	const saveCommodity = useWeigh((s) => s.saveCommodity);
	const toggleByCount = useWeigh((s) => s.toggleByCount);
	const deleteCommodity = useWeigh((s) => s.deleteCommodity);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [emoji, setEmoji] = (0, import_react.useState)("");
	const [pv, setPv] = (0, import_react.useState)("");
	const [pd, setPd] = (0, import_react.useState)("");
	const [ps, setPs] = (0, import_react.useState)("");
	const [byCount, setByCount] = (0, import_react.useState)(false);
	function reset() {
		setEditId(null);
		setName("");
		setEmoji("");
		setPv("");
		setPd("");
		setPs("");
		setByCount(false);
	}
	function onSave() {
		if (!name.trim()) {
			toast.error("أدخل الاسم");
			return;
		}
		saveCommodity({
			name: name.trim(),
			emoji: emoji.trim() || "📦",
			priceVisitor: num(pv),
			priceDealer: num(pd),
			priceSale: num(ps),
			byCount
		}, editId ?? void 0);
		toast.success(editId ? "تم تعديل السلعة" : "تم حفظ السلعة");
		reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "إدارة السلع",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الاسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: name,
							placeholder: "اسم السلعة",
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "رمز",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: emoji,
							placeholder: "رمز قصير",
							onChange: (e) => setEmoji(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "سعر زائر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							inputMode: "decimal",
							className: inputClass,
							value: pv,
							placeholder: "0",
							onChange: (e) => setPv(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "سعر متعامل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							inputMode: "decimal",
							className: inputClass,
							value: pd,
							placeholder: "0",
							onChange: (e) => setPd(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "سعر بيع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							inputMode: "decimal",
							className: inputClass,
							value: ps,
							placeholder: "0",
							onChange: (e) => setPs(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "طريقة التسعير",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: inputClass,
							value: byCount ? "1" : "0",
							onChange: (e) => setByCount(e.target.value === "1"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "0",
								children: "بالوزن (كغ)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "1",
								children: "بالقطعة (عدد)"
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: "بالقطعة: الثمن من العدد، والوزن يبقى لإنقاصه من قوس الميزان."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btnClass} bg-primary text-primary-fg`,
					onClick: onSave,
					children: editId ? "حفظ التعديل" : "حفظ السلعة"
				}), editId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btnClass} bg-surface-2 text-fg`,
					onClick: reset,
					children: "إلغاء"
				}) : null]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2",
		children: commodities.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl border border-line bg-surface p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "font-bold",
					children: [
						c.emoji,
						" ",
						c.name
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"زائر ",
						money(c.priceVisitor, 0),
						" · متعامل ",
						money(c.priceDealer, 0),
						" · بيع ",
						money(c.priceSale, 0)
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btnClass} ${c.byCount ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg"}`,
					onClick: () => toggleByCount(c.id),
					children: c.byCount ? "بالقطعة" : "بالوزن"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btnClass} bg-surface-2 text-fg`,
					onClick: () => {
						setEditId(c.id);
						setName(c.name);
						setEmoji(c.emoji);
						setPv(String(c.priceVisitor));
						setPd(String(c.priceDealer));
						setPs(String(c.priceSale));
						setByCount(c.byCount);
						window.scrollTo({
							top: 0,
							behavior: "smooth"
						});
					},
					children: "تعديل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btnClass} bg-danger text-danger-fg`,
					onClick: () => {
						if (!window.confirm("حذف السلعة؟")) return;
						deleteCommodity(c.id);
						if (editId === c.id) reset();
					},
					children: "حذف"
				})]
			})]
		}, c.id))
	})] });
}
function ReportsView() {
	const history = useWeigh((s) => s.history);
	const pays = useWeigh((s) => s.pays);
	const report = useWeigh((s) => s.report);
	const setReport = useWeigh((s) => s.setReport);
	const exportPayload = useWeigh((s) => s.exportPayload);
	const importPayload = useWeigh((s) => s.importPayload);
	const updatedAt = useWeigh((s) => s.updatedAt);
	const fileRef = (0, import_react.useRef)(null);
	const [status, setStatus] = (0, import_react.useState)("");
	async function send(kind) {
		const html = buildReportHtml(history, kind, report.shop, pays);
		const text = buildReportText(history, kind);
		const label = periodBounds(kind).label;
		downloadText(`تقرير-${kind}-${ymd()}.html`, html);
		const to = report.email.trim();
		if (report.ejPublic && report.ejService && report.ejTemplate && to) try {
			const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					service_id: report.ejService,
					template_id: report.ejTemplate,
					user_id: report.ejPublic,
					template_params: {
						to_email: to,
						cc_email: report.email2,
						subject: `تقرير ${label}`,
						message: text,
						html_message: html
					}
				})
			});
			if (!res.ok) throw new Error(await res.text());
			setStatus(`أُرسل التقرير إلى ${to} ونُزّل الملف`);
			toast.success("تم إرسال التقرير");
			return;
		} catch (e) {
			const msg = e instanceof Error ? e.message : "فشل الإرسال";
			setStatus(`تعذر البريد (${msg}). نُزّل الملف.`);
		}
		if (to) {
			const subject = encodeURIComponent(`تقرير ${label}`);
			const body = encodeURIComponent(`${text}\n\nأرفق ملف HTML الذي نُزّل على الجهاز.`);
			const cc = report.email2 ? `&cc=${encodeURIComponent(report.email2)}` : "";
			window.location.href = `mailto:${encodeURIComponent(to)}?subject=${subject}&body=${body}${cc}`;
			setStatus("نُزّل الملف وفُتح البريد إن كان متاحاً");
		} else {
			setStatus("نُزّل ملف التقرير على الجهاز");
			toast.success("نُزّل التقرير");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "الحفظ على هذا الجهاز",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["كل معاملة وسلعة وعامل تُحفظ تلقائياً هنا وتبقى بعد إغلاق الصفحة.", updatedAt ? ` آخر حفظ: ${new Date(updatedAt).toLocaleString("ar-DZ-u-nu-latn")}.` : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "للانتقال إلى هاتف آخر أو أخذ نسخة، صدّر الملف ثم استورده هناك."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-primary text-primary-fg`,
							onClick: () => {
								downloadText(`نسخة-احتياطية-${ymd()}.json`, exportPayload(), "application/json");
								toast.success("تم تنزيل النسخة الاحتياطية");
							},
							children: "تصدير نسخة احتياطية"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-surface-2 text-fg`,
							onClick: () => fileRef.current?.click(),
							children: "استيراد نسخة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json,.json",
							className: "hidden",
							onChange: (ev) => {
								const file = ev.target.files?.[0];
								ev.target.value = "";
								if (!file) return;
								const reader = new FileReader();
								reader.onload = () => {
									try {
										const data = JSON.parse(String(reader.result));
										if (!window.confirm("استيراد النسخة واستبدال البيانات الحالية على هذا الجهاز؟")) return;
										const res = importPayload(data);
										if (!res.ok) {
											toast.error(res.error);
											return;
										}
										toast.success(`تم الاستيراد · ${res.count} عملية`);
									} catch {
										toast.error("الملف غير صالح");
									}
								};
								reader.readAsText(file);
							}
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "التقارير",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "اسم المحل (يظهر في السند)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: report.shop,
								placeholder: "اسم المحل",
								onChange: (e) => setReport({ shop: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "بريد الاستلام",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								className: inputClass,
								value: report.email,
								placeholder: "name@example.com",
								onChange: (e) => setReport({ email: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "بريد إضافي",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								className: inputClass,
								value: report.email2,
								placeholder: "اختياري",
								onChange: (e) => setReport({ email2: e.target.value })
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-accent text-accent-fg`,
							onClick: () => void send("day"),
							children: "تقرير يومي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-accent text-accent-fg`,
							onClick: () => void send("week"),
							children: "تقرير أسبوعي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-accent text-accent-fg`,
							onClick: () => void send("month"),
							children: "تقرير شهري"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-primary text-primary-fg`,
							onClick: () => void send("all"),
							children: "تقرير شامل"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "يُنزَّل ملف التقرير دائماً. إن ضبطت بريداً يُفتح تطبيق البريد مع الملخص."
				}),
				status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-primary",
					children: status
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "إرسال مباشر (EmailJS)",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs text-muted",
				children: "اختياري. من emailjs.com انسخ المفاتيح إن أردت الإرسال دون فتح تطبيق البريد."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Public Key",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: report.ejPublic,
							onChange: (e) => setReport({ ejPublic: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Service ID",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: report.ejService,
							onChange: (e) => setReport({ ejService: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Template ID",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: report.ejTemplate,
							onChange: (e) => setReport({ ejTemplate: e.target.value })
						})
					})
				]
			})]
		})
	] });
}
function SheetFrame({ children, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 overflow-auto bg-bg/80 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `${btnClass} bg-primary text-primary-fg`,
					onClick: () => window.print(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "طباعة"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `${btnClass} bg-surface-2 text-fg`,
					onClick: onClose,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), "إغلاق"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				id: "print-sheet",
				className: "rounded-xl bg-paper p-5 text-ink",
				children
			})]
		})
	});
}
function SlipModal({ slip, onClose }) {
	if (slip.kind === "worker") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkerSheet, {
		slip,
		onClose
	});
	const pay = slip.isCredit ? "بالدين" : "نقدي";
	const num = String(slip.bonNum).slice(-6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetFrame, {
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm font-semibold",
				children: slip.shop || "نظام الوزن والبيع"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "my-3 text-center text-xl font-bold",
				children: ["سند تسليم رقم ", num]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
				className: "w-full border-collapse text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "border border-ink/30 p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "مسلم إلى" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: slip.name })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "border border-ink/30 p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "التاريخ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: slip.datetime })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "border border-ink/30 p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "النوع" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							MODE_META[slip.mode].label,
							" · ",
							pay
						] })]
					})
				] }) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "mt-3 w-full border-collapse text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "border border-ink/30 p-2 text-start",
						children: "التعيين"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "border border-ink/30 p-2",
						children: "الكمية"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "border border-ink/30 p-2",
						children: "السعر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "border border-ink/30 p-2",
						children: "المجموع"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: slip.items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "border border-ink/30 p-2 text-start",
						children: [
							it.emoji,
							" ",
							it.name
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "border border-ink/30 p-2 text-center",
						children: qtyLabel(it)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "border border-ink/30 p-2 text-center",
						children: money(it.pricePerKg)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "border border-ink/30 p-2 text-center",
						children: money(it.total)
					})
				] }, `${it.id}-${i}`)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-lg font-bold",
				children: [
					"المجموع الكلي: ",
					money(slip.grand),
					" دج · ",
					pay
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-2/5 border-t border-ink pt-2 text-center",
					children: "إمضاء المستلم"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-2/5 border-t border-ink pt-2 text-center",
					children: "إمضاء المسؤول"
				})]
			})
		]
	});
}
function WorkerSheet({ slip, onClose }) {
	const x = slip.pay;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetFrame, {
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm font-semibold",
				children: slip.shop || "نظام الوزن والبيع"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "my-3 text-center text-xl font-bold",
				children: "وصل تسليم — محاسبة عامل"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
				className: "w-full border-collapse text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [[
					["اسم العامل", x.name],
					["من", x.start || "—"],
					["إلى", x.end || "—"],
					["أيام العمل", String(x.days)],
					["الغياب", String(x.absent)],
					["أنصاف الأيام", String(x.half)],
					["الأيام الفعلية", x.effective.toFixed(2)],
					["أجر اليوم", `${money(x.wage)} دج`],
					["قبل الخصم", `${money(x.gross)} دج`],
					["المصروف", `${money(x.expense)} دج`],
					["المحمول", `${money(x.mobile)} دج`],
					["الصافي", `${money(x.net)} دج`],
					["الدفع", x.paid ? `تم الدفع${x.paidAt ? ` — ${x.paidAt}` : ""}` : "غير مدفوع"]
				].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "border border-ink/30 p-2 font-semibold",
					children: k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "border border-ink/30 p-2",
					children: v
				})] }, k)), x.expenses.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					className: "border border-ink/30 p-2 ps-6",
					children: [
						e.date,
						" ",
						e.note ? `· ${e.note}` : ""
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					className: "border border-ink/30 p-2",
					children: [money(e.amount), " دج"]
				})] }, `${e.date}-${i}`))] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-2/5 border-t border-ink pt-2 text-center",
					children: "إمضاء العامل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-2/5 border-t border-ink pt-2 text-center",
					children: "إمضاء المسؤول"
				})]
			})
		]
	});
}
var VIEW_LABEL = {
	buy: "المشتريات",
	sale: "المبيعات",
	net: "صافي المخزون"
};
function StockView() {
	const history = useWeigh((s) => s.history);
	const today = ymd();
	const [view, setView] = (0, import_react.useState)("buy");
	const [period, setPeriod] = (0, import_react.useState)("today");
	const [day, setDay] = (0, import_react.useState)(today);
	const [month, setMonth] = (0, import_react.useState)(today.slice(0, 7));
	const title = (0, import_react.useMemo)(() => {
		const ym = month || day.slice(0, 7);
		const wk = weekRange(ym, Number((day || today).slice(8, 10)) || 1);
		return `${period === "today" ? `يومي — ${day || today}` : period === "week" ? `أسبوعي ${ym} من ${wk.start} إلى ${wk.end}` : period === "month" ? `شهري — ${ym}` : "الإجمالي"} · ${VIEW_LABEL[view]}`;
	}, [
		view,
		period,
		day,
		month,
		today
	]);
	const buyModes = [
		"visitor",
		"dealer",
		"special"
	];
	let body;
	if (view === "net") {
		const buys = calcStock(history, period, buyModes, day, month);
		const sales = calcStock(history, period, ["sales"], day, month);
		const list = [.../* @__PURE__ */ new Set([...buys.map((b) => b.name), ...sales.map((s) => s.name)])].map((name) => {
			const b = buys.find((x) => x.name === name);
			const s = sales.find((x) => x.name === name);
			return {
				name,
				emoji: b?.emoji || s?.emoji || "",
				buy: b?.weight || 0,
				sale: s?.weight || 0,
				net: (b?.weight || 0) - (s?.weight || 0)
			};
		}).sort((a, b) => b.net - a.net);
		body = list.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: list.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-bg/40 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
						n.emoji,
						" ",
						n.name
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
						className: n.net >= 0 ? "text-primary" : "text-danger",
						children: [
							"صافي ",
							n.net.toFixed(2),
							" كغ"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"شراء ",
						n.buy.toFixed(2),
						" كغ · بيع ",
						n.sale.toFixed(2),
						" كغ"
					]
				})]
			}, n.name))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { count: history.length });
	} else {
		const stock = calcStock(history, period, view === "sale" ? ["sales"] : buyModes, day, month);
		const sumW = stock.reduce((a, s) => a + s.weight, 0);
		const sumC = stock.reduce((a, s) => a + s.cost, 0);
		body = stock.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between rounded-xl bg-primary/15 px-4 py-3 font-bold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الإجمالي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				sumW.toFixed(2),
				" كغ · ",
				money(sumC),
				" دج"
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: stock.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockCard, { row: s }, s.name))
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { count: history.length });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "المخزن",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "العرض",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: inputClass,
							value: view,
							onChange: (e) => setView(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "buy",
									children: "المشتريات"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "sale",
									children: "المبيعات"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "net",
									children: "صافي المخزون"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الفترة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: inputClass,
							value: period,
							onChange: (e) => setPeriod(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "today",
									children: "اليوم"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "week",
									children: "أسبوعي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "month",
									children: "شهري"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "الإجمالي"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اليوم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: inputClass,
							value: day,
							onChange: (e) => {
								setDay(e.target.value);
								if (e.target.value) setMonth(e.target.value.slice(0, 7));
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الشهر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "month",
							className: inputClass,
							value: month,
							onChange: (e) => setMonth(e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs text-muted",
				children: "الأسبوعي يقسّم الشهر كل 7 أيام: 1–7 ثم 8–14 ثم 15–21."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 font-bold text-primary",
				children: title
			}),
			body
		]
	});
}
function StockCard({ row }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-bg/40 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex flex-wrap items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
				className: "text-primary",
				children: [
					row.emoji,
					" ",
					row.name
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				row.weight.toFixed(2),
				" كغ · ",
				money(row.cost),
				" دج"
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-1 text-start font-medium",
							children: "السعر"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-1 text-start font-medium",
							children: "الكمية"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "p-1 text-start font-medium",
							children: "المبلغ"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: row.byPrice.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-1",
							children: money(p.price, 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "p-1",
							children: [
								p.weight.toFixed(2),
								" كغ",
								p.qty ? ` / ${p.qty} ق` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-1",
							children: money(p.cost)
						})
					]
				}, p.price)) })]
			})
		})]
	});
}
function Empty({ count }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "py-6 text-center text-sm text-muted",
		children: [
			"لا بيانات لهذه الفترة.",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
			"العمليات المحفوظة: ",
			count,
			". جرّب «الإجمالي»."
		]
	});
}
function WorkersView({ onPrint }) {
	const workers = useWeigh((s) => s.workers);
	const pays = useWeigh((s) => s.pays);
	const shop = useWeigh((s) => s.report.shop);
	const addWorker = useWeigh((s) => s.addWorker);
	const deleteWorker = useWeigh((s) => s.deleteWorker);
	const savePay = useWeigh((s) => s.savePay);
	const markPaid = useWeigh((s) => s.markPaid);
	const deletePay = useWeigh((s) => s.deletePay);
	const today = ymd();
	const [rName, setRName] = (0, import_react.useState)("");
	const [rWage, setRWage] = (0, import_react.useState)("");
	const [rStart, setRStart] = (0, import_react.useState)(today);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [pick, setPick] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [start, setStart] = (0, import_react.useState)(today);
	const [end, setEnd] = (0, import_react.useState)(today);
	const [daysRaw, setDaysRaw] = (0, import_react.useState)("");
	const [absent, setAbsent] = (0, import_react.useState)("");
	const [half, setHalf] = (0, import_react.useState)("");
	const [wage, setWage] = (0, import_react.useState)("");
	const [mobile, setMobile] = (0, import_react.useState)("");
	const [expenses, setExpenses] = (0, import_react.useState)([]);
	const [expDate, setExpDate] = (0, import_react.useState)(today);
	const [expAmount, setExpAmount] = (0, import_react.useState)("");
	const [expNote, setExpNote] = (0, import_react.useState)("");
	const [q, setQ] = (0, import_react.useState)("");
	const [paidFilter, setPaidFilter] = (0, import_react.useState)("all");
	const math = (0, import_react.useMemo)(() => workerMath({
		start,
		end,
		daysRaw,
		absent: num(absent),
		half: num(half),
		wage: num(wage),
		mobile: num(mobile),
		expenses
	}), [
		start,
		end,
		daysRaw,
		absent,
		half,
		wage,
		mobile,
		expenses
	]);
	const ledger = pays.filter((p) => {
		if (q && !p.name.toLowerCase().includes(q.trim().toLowerCase())) return false;
		if (paidFilter === "1" && !p.paid) return false;
		if (paidFilter === "0" && p.paid) return false;
		return true;
	});
	function clearForm() {
		setEditId(null);
		setPick("");
		setName("");
		setStart(today);
		setEnd(today);
		setDaysRaw("");
		setAbsent("");
		setHalf("");
		setWage("");
		setMobile("");
		setExpenses([]);
		setExpAmount("");
		setExpNote("");
		setExpDate(today);
	}
	function loadWorker(id) {
		setPick(id);
		const w = workers.find((x) => String(x.id) === id);
		if (!w) return;
		setName(w.name);
		if (w.start) setStart(w.start);
		if (w.wage) setWage(String(w.wage));
	}
	function buildPay() {
		if (!name.trim()) {
			toast.error("أدخل اسم العامل أو اختره من القائمة");
			return null;
		}
		if (num(wage) <= 0) {
			toast.error("أدخل أجر اليوم");
			return null;
		}
		const prev = editId ? pays.find((p) => p.id === editId) : void 0;
		return {
			id: editId ?? uid(),
			name: name.trim(),
			start,
			end,
			days: math.days,
			absent: num(absent),
			half: num(half),
			wage: num(wage),
			expense: math.expense,
			expenses: expenses.map((e) => ({ ...e })),
			mobile: num(mobile),
			effective: math.effective,
			gross: math.gross,
			net: math.net,
			paid: prev?.paid ?? false,
			paidAt: prev?.paidAt,
			datetime: prev?.datetime || formatNow(),
			dateKey: prev?.dateKey || today
		};
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "قائمة العمال",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "أضف العمال مرة واحدة، ثم احسب لكل واحد. القائمة تُحفظ تلقائياً."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "اسم العامل",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: rName,
								placeholder: "الاسم",
								onChange: (e) => setRName(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "أجر اليوم الافتراضي",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								className: inputClass,
								value: rWage,
								placeholder: "0",
								onChange: (e) => setRWage(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "تاريخ بدء العمل",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								className: inputClass,
								value: rStart,
								onChange: (e) => setRStart(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btnClass} mt-3 bg-primary text-primary-fg`,
					onClick: () => {
						const res = addWorker({
							name: rName,
							wage: num(rWage),
							start: rStart || today
						});
						if (!res.ok) {
							toast.error(res.error);
							return;
						}
						setRName("");
						setRWage("");
						toast.success("أُضيف العامل");
					},
					children: "إضافة عامل"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2",
					children: [workers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "لا عمال بعد"
					}) : null, workers.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-semibold",
							children: w.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted",
							children: [
								money(w.wage, 0),
								" دج/يوم · من ",
								w.start || "—"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `${btnClass} bg-primary text-primary-fg`,
								onClick: () => loadWorker(String(w.id)),
								children: "محاسبة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `حذف ${w.name}`,
								className: `${btnClass} bg-danger text-danger-fg`,
								onClick: () => {
									if (!window.confirm("حذف العامل من القائمة؟ السجلات السابقة تبقى.")) return;
									deleteWorker(w.id);
								},
								children: "×"
							})]
						})]
					}, w.id))]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "محاسبة عامل",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "أيام العمل − الغياب + أنصاف الأيام × أجر اليوم − المصروف − المحمول = الصافي"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "اختر العامل",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: inputClass,
								value: pick,
								onChange: (e) => loadWorker(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "— اختر عاملاً —"
								}), workers.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: w.id,
									children: w.name
								}, w.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "اسم العامل",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "worker-name",
								className: inputClass,
								value: name,
								placeholder: "الاسم",
								onChange: (e) => setName(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "تاريخ البدء",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								className: inputClass,
								value: start,
								onChange: (e) => setStart(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "يوم المحاسبة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								className: inputClass,
								value: end,
								onChange: (e) => setEnd(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "أيام العمل (فارغ = تلقائي)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								className: inputClass,
								value: daysRaw,
								placeholder: String(math.autoDays || 0),
								onChange: (e) => setDaysRaw(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "أيام الغياب",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								className: inputClass,
								value: absent,
								placeholder: "0",
								onChange: (e) => setAbsent(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "أنصاف يوم",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								className: inputClass,
								value: half,
								placeholder: "0",
								onChange: (e) => setHalf(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "أجر اليوم (دج)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								className: inputClass,
								value: wage,
								placeholder: "0",
								onChange: (e) => setWage(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "المحمول (دج)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								className: inputClass,
								value: mobile,
								placeholder: "0",
								onChange: (e) => setMobile(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-xl border border-line bg-bg/40 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-accent",
							children: "المصروف"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid gap-2 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "التاريخ",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "date",
										className: inputClass,
										value: expDate,
										onChange: (e) => setExpDate(e.target.value)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "المبلغ",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										inputMode: "decimal",
										className: inputClass,
										value: expAmount,
										placeholder: "0",
										onChange: (e) => setExpAmount(e.target.value)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "ملاحظة",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputClass,
										value: expNote,
										placeholder: "اختياري",
										onChange: (e) => setExpNote(e.target.value)
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} mt-2 bg-accent text-accent-fg`,
							onClick: () => {
								if (num(expAmount) <= 0) {
									toast.error("أدخل مبلغ المصروف");
									return;
								}
								setExpenses((list) => [...list, {
									id: uid(),
									date: expDate || today,
									amount: num(expAmount),
									note: expNote.trim()
								}]);
								setExpAmount("");
								setExpNote("");
							},
							children: "إضافة مصروف"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-2 space-y-1 text-sm",
							children: [expenses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-muted",
								children: "لا مصاريف"
							}) : null, expenses.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									e.date,
									" — ",
									money(e.amount),
									" دج ",
									e.note ? `· ${e.note}` : ""
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-danger",
									onClick: () => setExpenses((list) => list.filter((x) => x.id !== e.id)),
									children: "×"
								})]
							}, e.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 font-bold",
							children: [
								"مجموع المصروف: ",
								money(math.expense),
								" دج"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-between rounded-xl bg-primary/15 px-4 py-3 font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["أيام فعلية ", math.effective.toFixed(2)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: math.net < 0 ? "text-danger" : "text-accent",
						children: [money(math.net), " دج"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-primary text-primary-fg`,
							onClick: () => {
								const pay = buildPay();
								if (!pay) return;
								savePay(pay);
								toast.success(`تم حفظ محاسبة ${pay.name}`);
								clearForm();
							},
							children: "حفظ في السجل"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-accent text-accent-fg`,
							onClick: () => {
								const pay = buildPay();
								if (!pay) return;
								savePay(pay);
								onPrint({
									kind: "worker",
									pay,
									shop
								});
								clearForm();
							},
							children: "حفظ + وصل"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnClass} bg-surface-2 text-fg`,
							onClick: clearForm,
							children: "مسح النموذج"
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "سجل محاسبة العمال",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "بحث بالاسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: q,
							placeholder: "اسم العامل",
							onChange: (e) => setQ(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: inputClass,
							value: paidFilter,
							onChange: (e) => setPaidFilter(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "الكل"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "0",
									children: "غير مدفوع"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "1",
									children: "تم الدفع"
								})
							]
						})
					})]
				}),
				ledger.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-4 text-center text-sm text-muted",
					children: "لا سجلات بعد"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: ledger.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-primary",
									children: x.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: x.paid ? "text-xs text-primary" : "text-xs text-accent",
									children: x.paid ? "تم الدفع" : "غير مدفوع"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									"من ",
									x.start || "—",
									" إلى ",
									x.end || "—",
									" · أيام ",
									x.days,
									" · غياب ",
									x.absent,
									" · نصف ",
									x.half,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"صافي ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-accent",
										children: [money(x.net), " دج"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: `${btnClass} bg-primary text-primary-fg`,
										onClick: () => markPaid(x.id, !x.paid),
										children: x.paid ? "إلغاء الدفع" : "تم الدفع"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: `${btnClass} bg-accent text-accent-fg`,
										onClick: () => onPrint({
											kind: "worker",
											pay: x,
											shop
										}),
										children: "وصل"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: `${btnClass} bg-surface-2 text-fg`,
										onClick: () => {
											setEditId(x.id);
											setName(x.name);
											setStart(x.start);
											setEnd(x.end);
											setDaysRaw(String(x.days));
											setAbsent(x.absent ? String(x.absent) : "");
											setHalf(x.half ? String(x.half) : "");
											setWage(String(x.wage));
											setMobile(x.mobile ? String(x.mobile) : "");
											setExpenses(x.expenses.map((e) => ({ ...e })));
											const w = workers.find((wr) => wr.name === x.name);
											setPick(w ? String(w.id) : "");
											document.getElementById("worker-name")?.scrollIntoView({
												behavior: "smooth",
												block: "center"
											});
										},
										children: "تعديل"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: `${btnClass} bg-danger text-danger-fg`,
										onClick: () => {
											if (!window.confirm("حذف هذا السجل؟")) return;
											deletePay(x.id);
										},
										children: "حذف"
									})
								]
							})
						]
					}, x.id))
				})
			]
		})
	] });
}
var TABS = [
	{
		id: "visitor",
		label: "الزائر"
	},
	{
		id: "dealer",
		label: "المتعامل"
	},
	{
		id: "special",
		label: "خاص"
	},
	{
		id: "sales",
		label: "المبيعات"
	},
	{
		id: "archive",
		label: "السجل"
	},
	{
		id: "stock",
		label: "المخزن"
	},
	{
		id: "goods",
		label: "السلع"
	},
	{
		id: "workers",
		label: "العمال"
	},
	{
		id: "reports",
		label: "النسخ والتقارير"
	}
];
function isMode(tab) {
	return MODES.includes(tab);
}
/** Pull a one-time copy from the old single-file version if this device still has it. */
function adoptLegacy() {
	const state = useWeigh.getState();
	if (state.history.length || state.workers.length || state.pays.length || state.updatedAt > 0) return;
	try {
		const read = (key) => {
			const raw = localStorage.getItem(key);
			return raw ? JSON.parse(raw) : void 0;
		};
		const payload = {
			commodities: read("dz_commodities"),
			history: read("dz_history"),
			workerPays: read("dz_worker_pays"),
			workerRoster: read("dz_worker_roster")
		};
		if (!payload.commodities && !payload.history && !payload.workerPays && !payload.workerRoster) return;
		useWeigh.getState().importPayload(payload);
	} catch {}
}
function WeighApp() {
	const [tab, setTab] = (0, import_react.useState)("visitor");
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [slip, setSlip] = (0, import_react.useState)(null);
	const updatedAt = useWeigh((s) => s.updatedAt);
	const count = useWeigh((s) => s.history.length);
	const active = TABS.find((t) => t.id === tab) ?? TABS[0];
	(0, import_react.useEffect)(() => {
		let alive = true;
		const unsub = useWeigh.persist.onFinishHydration(() => {
			if (!alive) return;
			adoptLegacy();
			useWeigh.getState().setHydrated();
			setReady(true);
		});
		useWeigh.persist.rehydrate();
		return () => {
			alive = false;
			unsub();
		};
	}, []);
	function go(id) {
		setTab(id);
		setMenu(false);
	}
	const savedLabel = updatedAt ? `محفوظ · ${count} عملية` : "الحفظ تلقائي على هذا الجهاز";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-40 border-b border-line bg-bg/95 backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center justify-between gap-3 px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-fg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-bold text-primary",
								children: "نظام الوزن والبيع"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-xs text-muted",
								children: ready ? savedLabel : "جاري فتح السجل…"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full bg-surface-2 text-fg",
						"aria-expanded": menu,
						"aria-label": menu ? "إغلاق القائمة" : "القائمة",
						onClick: () => setMenu((v) => !v),
						children: menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})]
				}), menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mx-auto flex max-w-3xl flex-wrap gap-2 px-3 pb-3",
					"aria-label": "أقسام التطبيق",
					children: TABS.map((item) => {
						const on = item.id === tab;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => go(item.id),
							className: on ? "h-11 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg" : "h-11 rounded-full bg-surface-2 px-4 text-sm font-semibold text-fg",
							children: item.label
						}, item.id);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-3xl px-3 pb-2 text-xs text-muted",
					children: active.label
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-3xl px-3 py-4",
				children: !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-16 text-center text-sm text-muted",
					children: "جاري فتح السجل المحفوظ…"
				}) : isMode(tab) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DealView, {
					mode: tab,
					onPrint: setSlip
				}, tab) : tab === "archive" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchiveView, { onPrint: setSlip }) : tab === "stock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockView, {}) : tab === "goods" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoodsView, {}) : tab === "workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkersView, { onPrint: setSlip }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportsView, {})
			}),
			slip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipModal, {
				slip,
				onClose: () => setSlip(null)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				theme: "dark",
				dir: "rtl"
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeighApp, {});
}
//#endregion
export { Home as component };
