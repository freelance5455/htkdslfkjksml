import { i as __toESM } from "../_runtime.mjs";
import { M as isRedirect, R as require_react, _ as useRouter, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, c as House, d as Camera, i as ScanFace, l as Clock3, o as Layers, r as Trash2, s as ImagePlus, t as X, u as ChevronRight } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as formatPsl, n as TIER_ORDER, r as confidenceLabel, t as TIER_META } from "./psl-Dm-iLy6f.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CKqcGuk3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("tap inline-flex items-center justify-center gap-2 font-medium select-none disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg",
			ghost: "bg-surface text-fg border border-border",
			quiet: "bg-transparent text-muted",
			danger: "bg-danger text-fg"
		},
		size: {
			md: "h-11 px-5 text-sm rounded-lg",
			lg: "h-12 px-6 text-sm rounded-xl",
			xl: "h-14 px-7 text-base rounded-xl",
			icon: "size-11 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var SIZE = {
	sm: {
		px: 96,
		stroke: 7,
		num: "text-xl",
		cap: "text-2xs"
	},
	md: {
		px: 168,
		stroke: 9,
		num: "text-3xl",
		cap: "text-xs"
	},
	lg: {
		px: 200,
		stroke: 10,
		num: "text-4xl",
		cap: "text-xs"
	}
};
function ScoreRing({ value, size = "md", caption = "PSL", className }) {
	const cfg = SIZE[size];
	const r = (cfg.px - cfg.stroke) / 2 - 4;
	const c = 2 * Math.PI * r;
	const offset = c * (1 - Math.max(0, Math.min(10, value)) / 10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative grid place-items-center", className),
		style: {
			width: cfg.px,
			height: cfg.px
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: cfg.px,
			height: cfg.px,
			viewBox: `0 0 ${cfg.px} ${cfg.px}`,
			className: "score-ring",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: cfg.px / 2,
				cy: cfg.px / 2,
				r,
				fill: "none",
				stroke: "var(--color-surface-2)",
				strokeWidth: cfg.stroke
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				className: "score-ring-progress",
				cx: cfg.px / 2,
				cy: cfg.px / 2,
				r,
				fill: "none",
				stroke: "var(--color-accent)",
				strokeWidth: cfg.stroke,
				strokeLinecap: "round",
				strokeDasharray: c,
				strokeDashoffset: offset
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 grid place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("font-display font-bold tabular-nums leading-none text-fg", cfg.num),
					children: formatPsl(value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("mt-1 tracking-label uppercase text-muted", cfg.cap),
					children: caption
				})]
			})
		})]
	});
}
var MAX_EDGE = 1024;
var JPEG_QUALITY = .86;
async function fileToDataUrl(file) {
	return bitmapToJpeg(await decodeFile(file));
}
async function videoToDataUrl(video) {
	const { dw, dh } = fit(video.videoWidth || 720, video.videoHeight || 960, MAX_EDGE);
	const canvas = document.createElement("canvas");
	canvas.width = dw;
	canvas.height = dh;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas không khả dụng");
	ctx.drawImage(video, 0, 0, dw, dh);
	return canvas.toDataURL("image/jpeg", JPEG_QUALITY);
}
async function makeThumbnail(dataUrl, edge = 240) {
	const img = await loadImage(dataUrl);
	const { dw, dh } = fit(img.width, img.height, edge);
	const canvas = document.createElement("canvas");
	canvas.width = dw;
	canvas.height = dh;
	const ctx = canvas.getContext("2d");
	if (!ctx) return dataUrl;
	ctx.drawImage(img, 0, 0, dw, dh);
	return canvas.toDataURL("image/jpeg", .7);
}
async function decodeFile(file) {
	try {
		return await createImageBitmap(file);
	} catch {
		const url = URL.createObjectURL(file);
		try {
			const img = await loadImage(url);
			const canvas = document.createElement("canvas");
			canvas.width = img.width;
			canvas.height = img.height;
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("Không đọc được ảnh");
			ctx.drawImage(img, 0, 0);
			return await createImageBitmap(canvas);
		} finally {
			URL.revokeObjectURL(url);
		}
	}
}
function bitmapToJpeg(bitmap) {
	const { dw, dh } = fit(bitmap.width, bitmap.height, MAX_EDGE);
	const canvas = document.createElement("canvas");
	canvas.width = dw;
	canvas.height = dh;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas không khả dụng");
	ctx.drawImage(bitmap, 0, 0, dw, dh);
	bitmap.close?.();
	return canvas.toDataURL("image/jpeg", JPEG_QUALITY);
}
function fit(w, h, max) {
	const scale = Math.min(1, max / Math.max(w, h));
	return {
		dw: Math.max(1, Math.round(w * scale)),
		dh: Math.max(1, Math.round(h * scale))
	};
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Không đọc được ảnh"));
		img.src = src;
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var MAX_B64 = 18e5;
var scorePsl = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("INVALID");
	const imageBase64 = input.imageBase64;
	if (typeof imageBase64 !== "string" || imageBase64.length < 32) throw new Error("INVALID");
	if (imageBase64.length > MAX_B64) throw new Error("INVALID");
	return { imageBase64 };
}).handler(createSsrRpc("b38f1a296fbcb56253d2cd7f8562e90041c38beccff3d28b12dee38f26eba5c5"));
var MAX_HISTORY = 12;
var useAppStore = create()(persist((set) => ({
	screen: "home",
	tab: "home",
	photo: null,
	result: null,
	error: null,
	history: [],
	analyzingLabel: "Đang đọc khuôn mặt",
	go: (screen) => set((s) => ({
		screen,
		tab: tabFor(screen),
		error: screen === "scan" ? null : s.error
	})),
	setPhoto: (photo) => set({ photo }),
	setAnalyzingLabel: (analyzingLabel) => set({ analyzingLabel }),
	setError: (error) => set({ error }),
	setResult: (result, item) => set((s) => ({
		result,
		photo: result.photo,
		screen: "result",
		tab: "scan",
		error: null,
		history: [item, ...s.history.filter((h) => h.id !== item.id)].slice(0, MAX_HISTORY)
	})),
	clearResult: () => set({
		result: null,
		photo: null,
		error: null
	}),
	removeHistory: (id) => set((s) => ({ history: s.history.filter((h) => h.id !== id) }))
}), {
	name: "lume-psl",
	partialize: (s) => ({ history: s.history })
}));
function tabFor(screen) {
	if (screen === "history") return "history";
	if (screen === "scale") return "scale";
	if (screen === "home") return "home";
	return "scan";
}
var SCAN_STEPS = [
	"Đọc 468 điểm landmark",
	"Harmony — tỷ lệ & đối xứng",
	"Dimorphism — nét nam/nữ",
	"Angularity — góc hàm & gò má",
	"Miscellaneous — mắt, da, tóc",
	"Xếp rank trên thang PSL"
];
function ScanFlow() {
	const screen = useAppStore((s) => s.screen);
	if (screen === "result") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultStage, {});
	if (screen === "analyzing") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalyzingStage, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaptureStage, {});
}
function CaptureStage() {
	const fileRef = (0, import_react.useRef)(null);
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const [cameraOn, setCameraOn] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const error = useAppStore((s) => s.error);
	const setError = useAppStore((s) => s.setError);
	const go = useAppStore((s) => s.go);
	const scoreFn = useServerFn(scorePsl);
	(0, import_react.useEffect)(() => {
		return () => stopCamera();
	}, []);
	function stopCamera() {
		streamRef.current?.getTracks().forEach((t) => t.stop());
		streamRef.current = null;
		setCameraOn(false);
	}
	async function startCamera() {
		setError(null);
		try {
			const stream = await navigator.mediaDevices.getUserMedia({
				video: {
					facingMode: "user",
					width: { ideal: 1080 },
					height: { ideal: 1440 }
				},
				audio: false
			});
			streamRef.current = stream;
			setCameraOn(true);
			requestAnimationFrame(() => {
				if (videoRef.current) {
					videoRef.current.srcObject = stream;
					videoRef.current.play();
				}
			});
		} catch {
			setError("Không mở được camera. Hãy tải ảnh lên từ thư viện.");
			fileRef.current?.click();
		}
	}
	async function capture() {
		if (!videoRef.current) return;
		setBusy(true);
		try {
			const dataUrl = await videoToDataUrl(videoRef.current);
			stopCamera();
			await runScore(dataUrl, scoreFn);
		} catch {
			setError("Không chụp được ảnh. Thử tải ảnh lên.");
			setBusy(false);
		}
	}
	async function onFile(file) {
		if (!file) return;
		setBusy(true);
		setError(null);
		try {
			await runScore(await fileToDataUrl(file), scoreFn);
		} catch {
			setError("Không đọc được ảnh. Dùng JPEG hoặc PNG, mặt nhìn rõ.");
			useAppStore.getState().go("scan");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-5 pt-4 pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tap text-sm text-muted",
						onClick: () => {
							stopCamera();
							go("home");
						},
						children: "Đóng"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold tracking-wide",
						children: "Quét mặt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-10" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-5 overflow-hidden rounded-2xl bg-surface aspect-portrait",
				children: cameraOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					ref: videoRef,
					className: "absolute inset-0 size-full object-cover mirror-x",
					playsInline: true,
					muted: true,
					autoPlay: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-0 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan-oval scan-guide border border-accent/50" })
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 grid place-items-center px-8 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto mb-4 grid size-14 place-items-center rounded-xl bg-surface-2 text-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
								className: "size-6",
								strokeWidth: 1.6
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-semibold",
							children: "Chính diện, đủ sáng"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Ngang tầm mắt, không kính, không filter. Ảnh gửi sang công cụ PSL để chấm rank."
						})
					] })
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-5 mt-3 rounded-lg border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-fg",
				children: error
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mx-5 mt-3 grid grid-cols-3 gap-2 text-center text-2xs uppercase tracking-wider text-subtle",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-surface px-2 py-2",
						children: "Chính diện"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-surface px-2 py-2",
						children: "Ánh sáng đều"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-surface px-2 py-2",
						children: "Không filter"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto flex flex-col gap-3 px-5 pb-4 pt-5",
				children: [cameraOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "flex-1",
						onClick: stopCamera,
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), "Hủy camera"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "flex-1",
						onClick: () => void capture(),
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }), "Chụp"]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "xl",
					onClick: () => void startCamera(),
					disabled: busy,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-5" }), "Mở camera"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "lg",
					onClick: () => fileRef.current?.click(),
					disabled: busy,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), "Tải ảnh lên"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: fileRef,
					type: "file",
					accept: "image/*",
					className: "hidden",
					onChange: (e) => void onFile(e.target.files?.[0])
				})]
			})
		]
	});
}
async function runScore(photo, scoreFn) {
	const store = useAppStore.getState();
	store.setPhoto(photo);
	store.setError(null);
	store.go("analyzing");
	store.setAnalyzingLabel(SCAN_STEPS[0]);
	let step = 0;
	const tick = window.setInterval(() => {
		step = Math.min(step + 1, SCAN_STEPS.length - 1);
		useAppStore.getState().setAnalyzingLabel(SCAN_STEPS[step]);
	}, 700);
	try {
		const res = await scoreFn({ data: { imageBase64: photo } });
		window.clearInterval(tick);
		if (!res.ok) {
			store.setError(res.message);
			store.go("scan");
			return;
		}
		const result = {
			...res,
			photo
		};
		const thumbnail = await makeThumbnail(photo);
		const item = {
			id: `${Date.now()}`,
			createdAt: Date.now(),
			thumbnail,
			tier: result.tier,
			rank: result.rank,
			psl: result.psl,
			mogScore: result.mogScore,
			confidence: result.confidence,
			markers: result.markers
		};
		store.setResult(result, item);
	} catch {
		window.clearInterval(tick);
		store.setError("Không chấm được điểm. Thử lại.");
		store.go("scan");
	}
}
function AnalyzingStage() {
	const photo = useAppStore((s) => s.photo);
	const label = useAppStore((s) => s.analyzingLabel);
	const [pct, setPct] = (0, import_react.useState)(8);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			setPct((p) => p >= 94 ? p : Math.min(94, p + (p < 30 ? 2.4 : p > 70 ? .6 : 1.2)));
		}, 90);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col px-5 pt-4 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-center font-display text-sm font-semibold tracking-wide",
				children: "Đang chấm PSL"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-2xl bg-surface aspect-portrait",
				children: [
					photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: photo,
						alt: "Đang phân tích",
						className: "absolute inset-0 size-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-surface-2" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-bg/35" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan-sweep pointer-events-none absolute inset-x-0 h-1/5 bg-gradient-to-b from-transparent via-accent/35 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-6 border border-accent/25 rounded-xl" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-muted",
							children: [Math.round(pct), "%"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bar-fill h-full rounded-full bg-accent",
							style: { width: `${pct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-subtle",
						children: "Điểm và rank lấy từ công cụ PSL Score trên moggedupapp.com — không lưu ảnh phía LUME."
					})
				]
			})
		]
	});
}
function ResultStage() {
	const result = useAppStore((s) => s.result);
	const go = useAppStore((s) => s.go);
	const clearResult = useAppStore((s) => s.clearResult);
	if (!result) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-6 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm font-semibold tracking-wide",
					children: "Kết quả PSL"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tap text-sm text-muted",
					onClick: () => {
						clearResult();
						go("home");
					},
					children: "Xong"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "enter-up relative overflow-hidden rounded-2xl bg-surface p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-20 shrink-0 overflow-hidden rounded-xl bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: result.photo,
							alt: "Ảnh đã chấm",
							className: "size-full object-cover"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xs uppercase tracking-label text-subtle",
								children: "Rank"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl font-bold leading-tight",
								children: result.rank
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: result.rarity
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "enter-up enter-up-d1 mt-5 grid place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, {
					value: result.psl,
					size: "lg"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "enter-up enter-up-d2 mt-6 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "PSL",
						value: formatPsl(result.psl)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Khoảng",
						value: `${formatPsl(result.pslMin)}–${formatPsl(result.pslMax)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Tin cậy",
						value: confidenceLabel(result.confidence)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "enter-up enter-up-d3 mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xs uppercase tracking-label text-subtle",
					children: "Marker từ web"
				}), result.markers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Không có marker chi tiết cho lần quét này."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-wrap gap-2",
					children: result.markers.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-full border border-border bg-surface px-3 py-1.5 text-sm text-fg",
						children: m
					}, m))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "enter-up enter-up-d4 mt-6 text-xs leading-relaxed text-subtle",
				children: "Rank và điểm PSL được lấy từ kết quả công cụ PSL Score (moggedupapp.com/tools/psl-score). Đây là ước lượng thẩm mỹ cộng đồng, không phải đánh giá y khoa."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					onClick: () => {
						clearResult();
						go("scan");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Quét lại"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "lg",
					onClick: () => go("history"),
					children: "Xem lịch sử"
				})]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-2xs uppercase tracking-label text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: cn("mt-1 font-display text-base font-semibold tabular-nums"),
			children: value
		})]
	});
}
function HomeScreen() {
	const history = useAppStore((s) => s.history);
	const go = useAppStore((s) => s.go);
	const latest = history[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-4 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-2xs uppercase tracking-hero text-subtle",
				children: "PSL Score"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-bold tracking-tight",
				children: "LUME"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xs text-sm leading-relaxed text-muted",
				children: "Chụp selfie, nhận rank và điểm PSL từ thang chính thức — GigaChad đến Sub3."
			}),
			latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => go("history"),
				className: "tap mt-8 w-full rounded-2xl bg-surface p-5 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xs uppercase tracking-label text-subtle",
						children: "Lần quét gần nhất"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-subtle" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, {
						value: latest.psl,
						size: "sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl font-semibold",
							children: latest.rank
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								"PSL ",
								formatPsl(latest.psl),
								" · ",
								TIER_META[latest.tier].rarity
							]
						})]
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-2xl bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-12 place-items-center rounded-lg bg-surface-2 text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanFace, {
							className: "size-6",
							strokeWidth: 1.6
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-lg font-semibold",
						children: "Chưa có điểm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Một ảnh chính diện là đủ để lấy rank và điểm PSL."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "xl",
				className: "mt-6 w-full",
				onClick: () => go("scan"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-5" }), "Quét khuôn mặt"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xs uppercase tracking-label text-subtle",
						children: "Thang PSL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tap text-sm text-accent",
						onClick: () => go("scale"),
						children: "Xem đủ"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "divide-y divide-border overflow-hidden rounded-2xl bg-surface",
					children: TIER_ORDER.slice(0, 4).map((id) => {
						const t = TIER_META[id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-fg",
								children: t.rank
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm tabular-nums text-muted",
								children: [
									formatPsl(t.pslMin),
									"–",
									formatPsl(t.pslMax)
								]
							})]
						}, id);
					})
				})]
			})
		]
	});
}
function HistoryScreen() {
	const history = useAppStore((s) => s.history);
	const removeHistory = useAppStore((s) => s.removeHistory);
	const go = useAppStore((s) => s.go);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-4 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-2xs uppercase tracking-hero text-subtle",
				children: "Lịch sử"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-bold",
				children: "Các lần quét"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Lưu trên thiết bị này. Ảnh gốc không được giữ trên server."
			}),
			history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 rounded-2xl bg-surface p-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "mx-auto size-8 text-subtle" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display font-semibold",
						children: "Chưa có lịch sử"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Quét lần đầu để thấy rank và điểm PSL ở đây."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-5",
						onClick: () => go("scan"),
						children: "Quét ngay"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-3",
				children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3 rounded-2xl bg-surface p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: item.thumbnail,
							alt: "",
							className: "size-16 shrink-0 rounded-lg object-cover bg-surface-2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display font-semibold leading-tight",
									children: item.rank
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm tabular-nums text-muted",
									children: [
										"PSL ",
										formatPsl(item.psl),
										" · ",
										confidenceLabel(item.confidence)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-2xs text-subtle",
									children: new Date(item.createdAt).toLocaleString("vi-VN", {
										day: "2-digit",
										month: "short",
										hour: "2-digit",
										minute: "2-digit"
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "tap grid size-10 place-items-center rounded-lg text-subtle",
							onClick: () => removeHistory(item.id),
							"aria-label": "Xóa",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				}, item.id))
			})
		]
	});
}
function ScaleScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-4 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-2xs uppercase tracking-hero text-subtle",
				children: "Thang đo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-bold",
				children: "PSL Scale"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Bốn trục: Harmony, Dimorphism, Angularity, Miscellaneous. Rank dưới đây khớp công cụ PSL Score trên moggedupapp.com."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-6 space-y-3",
				children: TIER_ORDER.map((id) => {
					const t = TIER_META[id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-semibold",
									children: t.rank
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm tabular-nums text-accent",
									children: [
										formatPsl(t.pslMin),
										"–",
										formatPsl(t.pslMax)
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-2xs uppercase tracking-wider text-subtle",
								children: t.rarity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: t.blurb
							})
						]
					}, id);
				})
			})
		]
	});
}
var TABS = [
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "scan",
		label: "Quét",
		icon: ScanFace
	},
	{
		id: "history",
		label: "Lịch sử",
		icon: Clock3
	},
	{
		id: "scale",
		label: "Thang",
		icon: Layers
	}
];
function AppShell() {
	const screen = useAppStore((s) => s.screen);
	const tab = useAppStore((s) => s.tab);
	const go = useAppStore((s) => s.go);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-dvh w-full max-w-md flex-col bg-bg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-x-0 top-0 h-48",
					style: { background: "linear-gradient(180deg, rgb(232 220 200 / 6%) 0%, transparent 100%)" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex min-h-0 flex-1 flex-col safe-top",
					children: [
						screen === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {}),
						(screen === "scan" || screen === "analyzing" || screen === "result") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanFlow, {}),
						screen === "history" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryScreen, {}),
						screen === "scale" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScaleScreen, {})
					]
				}),
				!(screen === "analyzing") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "relative z-10 border-t border-border bg-bg/95 px-4 pt-2 nav-pad",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid grid-cols-4 items-end",
						children: TABS.map((item) => {
							const active = tab === item.id;
							const Icon = item.icon;
							const isScan = item.id === "scan";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => go(item.id === "scan" ? "scan" : item.id),
									className: cn("tap flex flex-col items-center gap-1 text-2xs tracking-wide", active ? "text-accent" : "text-subtle"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("grid place-items-center", isScan ? "size-12 -mt-5 rounded-full bg-accent text-accent-fg shadow-soft" : "size-8"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: isScan ? "size-5" : "size-5",
											strokeWidth: 1.7
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
								})
							}, item.id);
						})
					})
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
