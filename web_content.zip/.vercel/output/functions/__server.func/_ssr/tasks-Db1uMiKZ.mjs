import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as usePlanner, k as cn } from "./router-CQnHyG8o.mjs";
import { a as EmptyCopy, d as fieldClass, i as ColorDot, s as PageHeader } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
import { t as SortableList } from "./sortable-DqnUMi7n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tasks-Db1uMiKZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NEXT = {
	low: "medium",
	medium: "high",
	high: "low"
};
var LABEL = {
	low: "Low",
	medium: "Medium",
	high: "High"
};
function TasksView() {
	const lists = usePlanner((s) => s.lists);
	const tasks = usePlanner((s) => s.tasks);
	const addList = usePlanner((s) => s.addList);
	const updateList = usePlanner((s) => s.updateList);
	const deleteList = usePlanner((s) => s.deleteList);
	const addTask = usePlanner((s) => s.addTask);
	const updateTask = usePlanner((s) => s.updateTask);
	const setTasks = usePlanner((s) => s.setTasks);
	const accent = usePlanner((s) => s.theme.accent);
	const [listId, setListId] = (0, import_react.useState)(lists[0]?.id ?? "");
	(0, import_react.useEffect)(() => {
		if (!lists.some((list) => list.id === listId)) setListId(lists[0]?.id ?? "");
	}, [lists, listId]);
	const current = lists.find((list) => list.id === listId);
	const mine = tasks.filter((task) => task.listId === listId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			section: "tasks",
			title: "Tasks",
			lede: "What to do, without the noise."
		}),
		lists.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex gap-2 overflow-x-auto",
			children: lists.map((list) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": list.id === listId,
				onClick: () => setListId(list.id),
				className: cn("flex h-11 shrink-0 items-center gap-2 rounded-full px-3 text-sm font-medium", list.id === listId ? "bg-blush text-ink" : "border border-line text-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "size-2 rounded-full",
					style: { background: list.color }
				}), list.name]
			}, list.id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCopy, {
			title: "No lists yet",
			body: "Make a list for today, home, or anything that keeps spilling."
		}),
		current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDot, {
					label: "List color",
					value: current.color,
					onChange: (color) => updateList(current.id, { color })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: current.name,
					"aria-label": "List name",
					onChange: (event) => updateList(current.id, { name: event.target.value }),
					className: "h-11 min-w-0 flex-1 bg-transparent font-display text-2xl outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 px-2 text-sm text-muted",
					onClick: () => {
						const prevLists = lists;
						const prevTasks = tasks;
						deleteList(current.id);
						toast("List removed", { action: {
							label: "Undo",
							onClick: () => usePlanner.setState({
								lists: prevLists,
								tasks: prevTasks
							})
						} });
					},
					children: "Remove"
				})
			]
		}) : null,
		current && mine.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm text-muted",
			children: "This list is clear."
		}) : null,
		current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableList, {
			items: mine,
			getId: (task) => task.id,
			onReorder: (next) => {
				const rest = tasks.filter((task) => task.listId !== listId);
				setTasks([...rest, ...next]);
			},
			render: (task, grip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-line bg-card p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						grip,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "grid size-11 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: task.done,
								"aria-label": task.text || "Task",
								onChange: () => updateTask(task.id, { done: !task.done }),
								className: "size-5 accent-accent"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: task.text,
							"aria-label": "Task",
							onChange: (event) => updateTask(task.id, { text: event.target.value }),
							className: cn("h-11 min-w-0 flex-1 bg-transparent text-base outline-none", task.done && "text-muted line-through")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 px-2 text-sm text-muted",
							onClick: () => {
								const prev = tasks;
								setTasks(tasks.filter((item) => item.id !== task.id));
								toast("Task removed", { action: {
									label: "Undo",
									onClick: () => setTasks(prev)
								} });
							},
							children: "Remove"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex flex-wrap items-center gap-2 pl-11",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => updateTask(task.id, { priority: NEXT[task.priority] }),
						className: "h-10 rounded-full bg-paper px-3 text-sm",
						children: LABEL[task.priority]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: task.due,
						"aria-label": "Due date",
						onChange: (event) => updateTask(task.id, { due: event.target.value }),
						className: "h-10 min-w-0 rounded-lg border border-line bg-paper px-2 text-sm"
					})]
				})]
			})
		}) : null,
		current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 flex gap-2",
			onSubmit: (event) => {
				event.preventDefault();
				const data = new FormData(event.currentTarget);
				const text = String(data.get("text") ?? "").trim();
				if (!text) return;
				addTask({
					id: uid(),
					listId: current.id,
					text,
					done: false,
					priority: "medium",
					due: ""
				});
				event.currentTarget.reset();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				name: "text",
				placeholder: "Add a task",
				"aria-label": "Add a task",
				className: fieldClass
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "h-11 shrink-0 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg",
				children: "Add"
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-6 flex gap-2",
			onSubmit: (event) => {
				event.preventDefault();
				const data = new FormData(event.currentTarget);
				const name = String(data.get("name") ?? "").trim();
				if (!name) return;
				const id = uid();
				addList({
					id,
					name,
					color: accent
				});
				setListId(id);
				event.currentTarget.reset();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				name: "name",
				placeholder: "New list",
				"aria-label": "New list",
				className: fieldClass
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "h-11 shrink-0 rounded-full bg-blush px-4 text-sm font-medium",
				children: "List"
			})]
		})
	] });
}
var SplitComponent = TasksView;
//#endregion
export { SplitComponent as component };
