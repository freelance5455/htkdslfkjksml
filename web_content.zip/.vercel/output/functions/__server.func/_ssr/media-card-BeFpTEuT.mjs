import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { E as Heart, j as Ellipsis, m as Play } from "../_libs/lucide-react.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { K as formatDuration, P as Button, S as usePlayer, V as cn, W as formatBytes, d as DropdownMenuContent, f as DropdownMenuItem, h as DropdownMenuTrigger, k as useLibrary, m as DropdownMenuSeparator, u as DropdownMenu } from "./router-5I6roosF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/media-card-BeFpTEuT.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-primary/15 text-primary",
		muted: "bg-secondary text-muted",
		outline: "shadow-[var(--shadow-border)] text-muted"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function MediaPoster({ item, thumb, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative overflow-hidden rounded-md bg-secondary", item.kind === "audio" ? "aspect-square" : "aspect-video", className),
		children: [
			thumb ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: thumb,
				alt: "",
				className: "size-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-full items-center justify-center bg-[radial-gradient(circle_at_30%_20%,rgb(30_224_194_/_0.18),transparent_55%)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-2xl font-semibold text-primary/80",
					children: item.name.slice(0, 1).toUpperCase()
				})
			}),
			item.duration > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute bottom-1.5 right-1.5 rounded-sm bg-black/70 px-1.5 py-0.5 text-[10px] tabular-nums text-white",
				children: formatDuration(item.duration)
			}) : null,
			item.kind === "video" && item.position > 3 && item.duration > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-x-0 bottom-0 h-0.5 bg-black/40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block h-full bg-primary",
					style: { width: `${Math.min(100, item.position / item.duration * 100)}%` }
				})
			}) : null
		]
	});
}
function MediaCard({ item, queue, layout = "grid" }) {
	const thumb = useLibrary((s) => s.thumbs[item.id]);
	const toggleFavourite = useLibrary((s) => s.toggleFavourite);
	const open = usePlayer((s) => s.open);
	const navigate = useNavigate();
	const play = () => {
		open(item, queue);
		navigate({
			to: "/player/$id",
			params: { id: item.id }
		});
	};
	if (layout === "list") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex items-center gap-3 rounded-xl bg-surface p-2 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: play,
				className: "relative w-28 shrink-0 overflow-hidden rounded-lg",
				"aria-label": `Play ${item.name}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaPoster, {
					item,
					thumb
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "truncate font-medium",
						children: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 truncate text-xs text-muted",
						children: [
							item.folder,
							" · ",
							formatBytes(item.size),
							item.width && item.height ? ` · ${item.width}×${item.height}` : ""
						]
					}),
					!item.playable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-destructive",
						children: item.unsupportedReason
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemMenu, { item }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon",
				variant: "ghost",
				onClick: () => toggleFavourite(item.id),
				"aria-label": "Favourite",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-4", item.favourite && "fill-primary text-primary") })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon",
				onClick: play,
				"aria-label": `Play ${item.name}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current" })
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group relative",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: play,
				className: "block w-full text-left",
				"aria-label": `Play ${item.name}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaPoster, {
					item,
					thumb,
					className: "rounded-lg"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-start gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "truncate text-sm font-medium",
						children: item.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted",
						children: item.folder
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemMenu, { item })]
			}),
			!item.linked && item.source === "local" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "muted",
				className: "mt-1",
				children: "Relink file"
			}) : null
		]
	});
}
function ItemMenu({ item }) {
	const toggleFavourite = useLibrary((s) => s.toggleFavourite);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "icon-sm",
			variant: "ghost",
			"aria-label": `More for ${item.name}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/library",
					search: { inspect: item.id },
					children: "File information"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => toggleFavourite(item.id),
				children: item.favourite ? "Remove favourite" : "Add to favourites"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/library",
					search: {
						inspect: item.id,
						action: "rename"
					},
					children: "Rename"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/library",
					search: {
						inspect: item.id,
						action: "delete"
					},
					children: "Delete"
				})
			})
		]
	})] });
}
function MediaRail({ title, items }) {
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-end justify-between",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-semibold",
				children: title
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rail-scroll -mx-1 flex gap-3 overflow-x-auto px-1 pb-2",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-40 shrink-0 sm:w-48",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaCard, {
					item,
					queue: items,
					layout: "rail"
				})
			}, item.id))
		})]
	});
}
//#endregion
export { MediaRail as n, MediaCard as t };
