import { i as __toESM } from "../_runtime.mjs";
import { a as cellOf, attachInput, attachProbe, detachInput, formatTime, frameSim, getSnap, groveCode, i as WALL_T, lockLook, n as CELL$1, nudgeLook, playAgain, r as WALL_H, resumePlay, session, startFromMenu, subscribe, t as unlockAudio, toggleMute } from "./session-C7yNCexP.mjs";
import { a as BufferAttribute, c as Object3D, d as require_react, l as PointsMaterial, n as useFrame, o as BufferGeometry, r as useThree, s as Color, t as Canvas, u as require_jsx_runtime } from "../_libs/@react-three/fiber+[...].mjs";
import { a as Gem, i as Timer, n as Volume2, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Game-BA2sin1g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function roundRect(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.roundRect(x, y, w, h, r);
}
function drawMinimap(canvas) {
	const ctx = canvas.getContext("2d");
	if (!ctx || !session.cells?.length) return;
	const dpr = Math.min(window.devicePixelRatio || 1, 2);
	const size = canvas.clientWidth;
	if (size < 2) return;
	const px = Math.floor(size * dpr);
	if (canvas.width !== px) {
		canvas.width = px;
		canvas.height = px;
	}
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.clearRect(0, 0, size, size);
	roundRect(ctx, 0, 0, size, size, 18);
	ctx.fillStyle = "#f6f1e6";
	ctx.fill();
	ctx.save();
	roundRect(ctx, 0, 0, size, size, 18);
	ctx.clip();
	const pad = 12;
	const scale = (size - 24) / (11 * CELL$1);
	const seen = (c, r) => c >= 0 && r >= 0 && c < 11 && r < 11 && session.explored[r * 11 + c] === 1;
	for (let r = 0; r < 11; r++) for (let c = 0; c < 11; c++) {
		ctx.fillStyle = seen(c, r) ? "#f3e4c4" : "#243028";
		ctx.fillRect(pad + c * CELL$1 * scale, pad + r * CELL$1 * scale, CELL$1 * scale, CELL$1 * scale);
	}
	ctx.strokeStyle = "#1f6a48";
	ctx.lineWidth = Math.max(3, WALL_T * scale);
	ctx.lineCap = "square";
	ctx.beginPath();
	for (let r = 0; r < 11; r++) for (let c = 0; c < 11; c++) {
		const cell = session.cells[r * 11 + c];
		const x0 = pad + c * CELL$1 * scale;
		const y0 = pad + r * CELL$1 * scale;
		const x1 = x0 + CELL$1 * scale;
		const y1 = y0 + CELL$1 * scale;
		const here = seen(c, r);
		if (cell.n && (here || seen(c, r - 1))) {
			ctx.moveTo(x0, y0);
			ctx.lineTo(x1, y0);
		}
		if (cell.w && (here || seen(c - 1, r))) {
			ctx.moveTo(x0, y0);
			ctx.lineTo(x0, y1);
		}
		if (r === 10 && cell.s && here) {
			ctx.moveTo(x0, y1);
			ctx.lineTo(x1, y1);
		}
		if (c === 10 && cell.e && here) {
			ctx.moveTo(x1, y0);
			ctx.lineTo(x1, y1);
		}
	}
	ctx.stroke();
	if (seen(session.exitC, session.exitR)) {
		const ex = pad + session.exitX * scale;
		const ey = pad + session.exitZ * scale;
		ctx.fillStyle = "#e39b2b";
		ctx.beginPath();
		ctx.moveTo(ex, ey - 5.5);
		ctx.lineTo(ex + 4.5, ey);
		ctx.lineTo(ex, ey + 5.5);
		ctx.lineTo(ex - 4.5, ey);
		ctx.closePath();
		ctx.fill();
	}
	for (let i = 0; i < session.gems.length; i++) {
		if (session.got[i]) continue;
		const g = session.gems[i];
		const cell = cellOf(g.x, g.z);
		if (!seen(cell.c, cell.r)) continue;
		ctx.fillStyle = "#e36b4a";
		ctx.beginPath();
		ctx.arc(pad + g.x * scale, pad + g.z * scale, 2.6, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.save();
	ctx.translate(pad + session.x * scale, pad + session.z * scale);
	ctx.rotate(-session.yaw);
	ctx.fillStyle = "#e36b4a";
	ctx.beginPath();
	ctx.moveTo(0, -7.5);
	ctx.lineTo(5, 6);
	ctx.lineTo(0, 3);
	ctx.lineTo(-5, 6);
	ctx.closePath();
	ctx.fill();
	ctx.restore();
	ctx.restore();
}
function Minimap() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let frame = 0;
		const loop = () => {
			frame = requestAnimationFrame(loop);
			if (ref.current) drawMinimap(ref.current);
		};
		frame = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(frame);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none w-28 sm:w-44",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref,
			"aria-label": "Explored paths",
			className: "aspect-square w-full rounded-3xl shadow-lg"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-1 w-fit rounded-full bg-cream px-2 py-0.5 text-xs font-extrabold tracking-widest text-ink uppercase",
			children: "Explored"
		})]
	});
}
function useClock(phase) {
	const [ms, setMs] = (0, import_react.useState)(() => session.timeMs);
	(0, import_react.useEffect)(() => {
		setMs(session.timeMs);
		if (phase !== "play") return;
		const id = window.setInterval(() => setMs(session.timeMs), 80);
		return () => window.clearInterval(id);
	}, [phase]);
	return ms;
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-ink",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-3.5 w-3.5 rotate-45 rounded-sm bg-gold" })
	});
}
function SoundButton() {
	const snap = (0, import_react.useSyncExternalStore)(subscribe, getSnap, getSnap);
	const Icon = snap.muted ? VolumeX : Volume2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": snap.muted ? "Unmute" : "Mute",
		className: "grid h-11 w-11 place-items-center rounded-full bg-cream text-ink shadow-lg",
		onClick: () => {
			unlockAudio();
			toggleMute();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
	});
}
function StartCard({ touch }) {
	const snap = (0, import_react.useSyncExternalStore)(subscribe, getSnap, getSnap);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise pointer-events-auto w-full max-w-md rounded-3xl bg-cream px-6 py-7 text-ink shadow-2xl sm:px-8 sm:py-9",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-extrabold tracking-widest text-hedge uppercase",
					children: ["Grove ", groveCode(snap.seed)]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-4 text-4xl leading-none sm:text-5xl",
				children: "Lantern Grove"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base leading-relaxed text-muted",
				children: "A sunlit hedge maze. Walk the paths, pocket every sunberry, and find the lantern at the end."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-5 grid gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 rounded-2xl bg-line px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-extrabold",
							children: "Move"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: touch ? "Left stick" : "WASD or arrows"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 rounded-2xl bg-line px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-extrabold",
							children: "Look"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: touch ? "Drag the right side" : "Mouse"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 rounded-2xl bg-line px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-extrabold",
							children: "Hurry"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: touch ? "Run button" : "Hold Shift"
						})]
					})
				]
			}),
			snap.bestMs != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm font-bold text-muted",
				children: ["Best lantern ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-ink",
					children: formatTime(snap.bestMs)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-5 h-12 w-full rounded-full bg-ink text-base font-extrabold text-cream",
				onClick: () => {
					unlockAudio();
					startFromMenu();
					lockLook();
				},
				children: "Start"
			})
		]
	});
}
function WinCard() {
	const snap = (0, import_react.useSyncExternalStore)(subscribe, getSnap, getSnap);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise pointer-events-auto w-full max-w-md rounded-3xl bg-cream px-6 py-7 text-ink shadow-2xl sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-extrabold tracking-widest text-hedge uppercase",
					children: ["Grove ", groveCode(snap.seed)]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display mt-4 text-4xl leading-none",
				children: "Lantern found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base leading-relaxed text-muted",
				children: "The hedges kept every turn. The grove is yours."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display mt-5 text-5xl leading-none tabular-nums",
				children: formatTime(snap.timeMs)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center gap-2 text-sm font-extrabold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full bg-line px-3 py-1.5 text-ink",
					children: [
						snap.collected,
						"/",
						snap.total,
						" sunberries"
					]
				}), snap.isNewBest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-ink px-3 py-1.5 text-gold",
					children: "New best"
				}) : snap.bestMs != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full bg-line px-3 py-1.5 text-muted",
					children: ["Best ", formatTime(snap.bestMs)]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-6 h-12 w-full rounded-full bg-ink text-base font-extrabold text-cream",
				onClick: () => {
					unlockAudio();
					playAgain();
					lockLook();
				},
				children: "New maze"
			})
		]
	});
}
function PauseCard({ touch }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise pointer-events-auto w-full max-w-sm rounded-3xl bg-cream px-6 py-7 text-ink shadow-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl leading-none",
				children: "Paused"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: touch ? "The grove waits. Resume when you are ready." : "Click resume, then look around with the mouse."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-12 rounded-full bg-ink text-base font-extrabold text-cream",
					onClick: () => {
						unlockAudio();
						resumePlay();
						lockLook();
					},
					children: "Resume"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-12 rounded-full bg-line text-base font-extrabold text-ink",
					onClick: () => {
						unlockAudio();
						playAgain();
						lockLook();
					},
					children: "New maze"
				})]
			})
		]
	});
}
function ClockPill() {
	const snap = (0, import_react.useSyncExternalStore)(subscribe, getSnap, getSnap);
	const ms = useClock(snap.phase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none flex items-center gap-2 rounded-full bg-cream px-3 py-2 text-ink shadow-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, {
				className: "size-4 text-hedge",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-base leading-none tabular-nums sm:text-lg",
				children: formatTime(snap.phase === "play" ? ms : snap.timeMs)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-1 h-4 w-px bg-line",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, {
				className: "size-4 text-coral",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "gem-pop text-sm font-extrabold tabular-nums",
				children: [
					snap.collected,
					"/",
					snap.total
				]
			}, snap.collected)
		]
	});
}
function Hint() {
	const [show, setShow] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const id = window.setTimeout(() => setShow(false), 8e3);
		return () => window.clearTimeout(id);
	}, []);
	if (!show) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "pointer-events-none absolute bottom-5 left-1/2 -translate-x-1/2 rounded-full bg-cream/90 px-4 py-2 text-xs font-extrabold text-muted",
		children: "WASD move · mouse look · Shift hurry · Esc pause"
	});
}
function Stick() {
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const origin = (0, import_react.useRef)(null);
	const end = () => {
		origin.current = null;
		setKnob({
			x: 0,
			y: 0
		});
		session.touchStrafe = 0;
		session.touchForward = 0;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-auto absolute bottom-5 left-4 z-10 h-36 w-36 rounded-full border border-ink/15 bg-cream/50",
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			origin.current = {
				x: e.clientX,
				y: e.clientY
			};
		},
		onPointerMove: (e) => {
			if (!origin.current) return;
			const dx = e.clientX - origin.current.x;
			const dy = e.clientY - origin.current.y;
			const max = 52;
			const mag = Math.hypot(dx, dy) || 1;
			const k = mag > max ? max / mag : 1;
			const x = dx * k;
			const y = dy * k;
			setKnob({
				x,
				y
			});
			session.touchStrafe = x / max;
			session.touchForward = -y / max;
		},
		onPointerUp: end,
		onPointerCancel: end,
		"aria-label": "Move",
		role: "application",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute top-1/2 left-1/2 h-14 w-14 rounded-full bg-ink shadow-lg",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		})
	});
}
function LookPad() {
	const last = (0, import_react.useRef)(null);
	const end = () => {
		last.current = null;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-auto absolute inset-y-0 right-0 z-0 w-1/2",
		"aria-label": "Look",
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			last.current = {
				x: e.clientX,
				y: e.clientY
			};
		},
		onPointerMove: (e) => {
			if (!last.current || session.phase !== "play") return;
			const dx = e.clientX - last.current.x;
			const dy = e.clientY - last.current.y;
			last.current = {
				x: e.clientX,
				y: e.clientY
			};
			nudgeLook(dx, dy, .0048);
		},
		onPointerUp: end,
		onPointerCancel: end
	});
}
function Hud({ touch }) {
	const snap = (0, import_react.useSyncExternalStore)(subscribe, getSnap, getSnap);
	const playing = snap.phase === "play" || snap.phase === "pause" || snap.phase === "won";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hud-safe pointer-events-none absolute inset-0 z-10",
		children: [
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockPill, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SoundButton, {})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimap, {})]
			}),
			snap.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute top-1/2 left-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-ink/80 bg-cream/70" }),
			snap.phase === "play" && !touch && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {}),
			touch && snap.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LookPad, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "pointer-events-auto absolute right-4 bottom-6 z-10 h-14 min-w-14 rounded-full bg-ink px-4 text-sm font-extrabold text-cream",
					onPointerDown: (e) => {
						e.currentTarget.setPointerCapture(e.pointerId);
						session.touchSprint = true;
					},
					onPointerUp: () => {
						session.touchSprint = false;
					},
					onPointerCancel: () => {
						session.touchSprint = false;
					},
					children: "Run"
				})
			] }),
			snap.phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute inset-0 flex items-center justify-center overflow-y-auto bg-ink/35 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-4 right-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SoundButton, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartCard, { touch })]
			}),
			snap.phase === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-0 flex items-center justify-center overflow-y-auto bg-ink/40 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseCard, { touch })
			}),
			snap.phase === "won" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-0 flex items-center justify-center overflow-y-auto bg-ink/40 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WinCard, {})
			})
		]
	});
}
var GEM_COLORS = [
	"#e36b4a",
	"#e39b2b",
	"#f08a5d"
];
var FLOWER = [
	"#e36b4a",
	"#e39b2b",
	"#f6f1e6"
];
function hash(n) {
	const s = Math.sin(n * 127.1) * 43758.5453;
	return s - Math.floor(s);
}
function updateCamera(camera, t) {
	if (session.phase === "menu") {
		const cx = 11 * CELL$1 / 2;
		const cz = 11 * CELL$1 / 2;
		const ang = session.reduce ? .7 : t * .15;
		const rad = 11 * CELL$1 * .82;
		camera.position.set(cx + Math.sin(ang) * rad, 16.2, cz + Math.cos(ang) * rad);
		camera.lookAt(cx, .2, cz);
		return;
	}
	const shake = session.reduce ? 0 : session.trauma * session.trauma;
	const sx = (hash(t * 23.1) - .5) * .14 * shake;
	const sy = (hash(t * 19.4) - .5) * .09 * shake;
	camera.position.set(session.x + sx, 1.55 + session.bob + sy, session.z);
	camera.rotation.order = "YXZ";
	camera.rotation.y = session.yaw;
	camera.rotation.x = session.pitch;
	camera.rotation.z = (hash(t * 11.2) - .5) * .025 * shake;
}
function Systems() {
	const camera = useThree((s) => s.camera);
	useFrame((state, delta) => {
		frameSim(delta);
		updateCamera(camera, state.clock.elapsedTime);
	});
	return null;
}
function Sun() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useLayoutEffect)(() => {
		const light = ref.current;
		if (!light) return;
		light.target.position.set(11 * CELL$1 / 2, 0, 11 * CELL$1 / 2);
		light.parent?.add(light.target);
	}, []);
	const cx = 11 * CELL$1 / 2;
	const cz = 11 * CELL$1 / 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
		ref,
		position: [
			cx + 14,
			24,
			cz + 8
		],
		intensity: 2.35,
		color: "#fff6e4",
		castShadow: true,
		"shadow-mapSize-width": 1024,
		"shadow-mapSize-height": 1024,
		"shadow-camera-near": 1,
		"shadow-camera-far": 70,
		"shadow-camera-left": -26,
		"shadow-camera-right": 26,
		"shadow-camera-top": 26,
		"shadow-camera-bottom": -26,
		"shadow-bias": -6e-4,
		"shadow-normalBias": .045
	});
}
function Hedges() {
	const body = (0, import_react.useRef)(null);
	const lip = (0, import_react.useRef)(null);
	const walls = session.walls;
	(0, import_react.useLayoutEffect)(() => {
		const dummy = new Object3D();
		const color = new Color();
		const b = body.current;
		const l = lip.current;
		if (!b || !l) return;
		const greens = [
			"#27684c",
			"#2f7a58",
			"#347f5c",
			"#245e44"
		];
		const lips = [
			"#59b084",
			"#6dbe96",
			"#48a078",
			"#7ec8a4"
		];
		walls.forEach((w, i) => {
			const sx = w.maxX - w.minX;
			const sz = w.maxZ - w.minZ;
			const x = (w.minX + w.maxX) / 2;
			const z = (w.minZ + w.maxZ) / 2;
			dummy.rotation.set(0, 0, 0);
			dummy.position.set(x, WALL_H / 2, z);
			dummy.scale.set(sx, WALL_H, sz);
			dummy.updateMatrix();
			b.setMatrixAt(i, dummy.matrix);
			color.set(greens[i % greens.length]);
			b.setColorAt(i, color);
			dummy.position.set(x, WALL_H - .08, z);
			dummy.scale.set(sx + .05, .22, sz + .05);
			dummy.updateMatrix();
			l.setMatrixAt(i, dummy.matrix);
			color.set(lips[i % lips.length]);
			l.setColorAt(i, color);
		});
		b.instanceMatrix.needsUpdate = true;
		l.instanceMatrix.needsUpdate = true;
		if (b.instanceColor) b.instanceColor.needsUpdate = true;
		if (l.instanceColor) l.instanceColor.needsUpdate = true;
	}, [walls]);
	if (!walls.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref: body,
		args: [
			void 0,
			void 0,
			walls.length
		],
		castShadow: true,
		receiveShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			1,
			1,
			1
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			roughness: .94,
			metalness: 0,
			flatShading: true
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref: lip,
		args: [
			void 0,
			void 0,
			walls.length
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			1,
			1,
			1
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			roughness: .86,
			metalness: 0,
			flatShading: true
		})]
	})] });
}
function Floors() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useLayoutEffect)(() => {
		const dummy = new Object3D();
		const color = new Color();
		const mesh = ref.current;
		if (!mesh) return;
		const tile = CELL$1 - WALL_T - .2;
		const colors = [
			"#f4e7ce",
			"#ead8b2",
			"#f8efe0",
			"#e4cfa4"
		];
		let i = 0;
		for (let r = 0; r < 11; r++) for (let c = 0; c < 11; c++) {
			dummy.rotation.set(0, 0, 0);
			dummy.position.set((c + .5) * CELL$1, .03, (r + .5) * CELL$1);
			dummy.scale.set(tile, .06, tile);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
			color.set(colors[(c * 3 + r * 5) % colors.length]);
			mesh.setColorAt(i, color);
			i += 1;
		}
		mesh.instanceMatrix.needsUpdate = true;
		if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref,
		args: [
			void 0,
			void 0,
			121
		],
		receiveShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			1,
			1,
			1
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			roughness: 1,
			metalness: 0
		})]
	});
}
function Trees() {
	const trunks = (0, import_react.useRef)(null);
	const tops = (0, import_react.useRef)(null);
	(0, import_react.useLayoutEffect)(() => {
		const dummy = new Object3D();
		const trunk = trunks.current;
		const top = tops.current;
		if (!trunk || !top) return;
		session.trees.forEach((t, i) => {
			dummy.rotation.set(0, 0, 0);
			dummy.position.set(t.x, t.h * .22, t.z);
			dummy.scale.set(1, t.h * .46, 1);
			dummy.updateMatrix();
			trunk.setMatrixAt(i, dummy.matrix);
			dummy.position.set(t.x, t.h * .78, t.z);
			dummy.scale.set(t.r, t.h * .72, t.r);
			dummy.updateMatrix();
			top.setMatrixAt(i, dummy.matrix);
		});
		trunk.instanceMatrix.needsUpdate = true;
		top.instanceMatrix.needsUpdate = true;
	}, []);
	const n = session.trees.length;
	if (!n) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref: trunks,
		args: [
			void 0,
			void 0,
			n
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
			.11,
			.16,
			1,
			5
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#6b422c",
			roughness: .92,
			flatShading: true
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref: tops,
		args: [
			void 0,
			void 0,
			n
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("coneGeometry", { args: [
			1,
			1,
			6
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#2f7a58",
			roughness: .88,
			flatShading: true
		})]
	})] });
}
function Flowers() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", { children: session.flowers.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			f.x,
			0,
			f.z
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.16,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.025,
				.04,
				.32,
				5
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#2c6b4c",
				roughness: .9,
				flatShading: true
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.36,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("coneGeometry", { args: [
				.15,
				.22,
				5
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: FLOWER[f.kind] ?? "#e36b4a",
				emissive: FLOWER[f.kind] ?? "#e36b4a",
				emissiveIntensity: .12,
				roughness: .55,
				flatShading: true
			})]
		})]
	}, i)) });
}
function Gems() {
	const refs = (0, import_react.useRef)([]);
	useFrame(({ clock }) => {
		const t = clock.elapsedTime;
		for (let i = 0; i < session.gems.length; i++) {
			const mesh = refs.current[i];
			if (!mesh) continue;
			const live = !session.got[i];
			mesh.visible = live;
			if (!live) continue;
			mesh.position.y = session.reduce ? .82 : .8 + Math.sin(t * 2 + i * .7) * .1;
			mesh.rotation.y = session.reduce ? .6 : t * 1.2 + i;
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", { children: session.gems.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		ref: (el) => {
			refs.current[i] = el;
		},
		position: [
			g.x,
			.82,
			g.z
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("octahedronGeometry", { args: [.26, 0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: GEM_COLORS[i % GEM_COLORS.length],
			emissive: GEM_COLORS[i % GEM_COLORS.length],
			emissiveIntensity: .62,
			roughness: .28,
			flatShading: true
		})]
	}, `${session.seed}-${i}`)) });
}
function Lantern() {
	const gem = (0, import_react.useRef)(null);
	useFrame(({ clock }) => {
		if (!gem.current || session.reduce) return;
		const t = clock.elapsedTime;
		gem.current.position.y = 1.62 + Math.sin(t * 1.8) * .07;
		gem.current.rotation.y = t * .7;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			session.exitX,
			0,
			session.exitZ
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					-.62,
					.72,
					0
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.12,
					1.44,
					.12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#6b422c",
					roughness: .86,
					flatShading: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.62,
					.72,
					0
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.12,
					1.44,
					.12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#6b422c",
					roughness: .86,
					flatShading: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.46,
					0
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					1.4,
					.1,
					.12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#6b422c",
					roughness: .86,
					flatShading: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				ref: gem,
				position: [
					0,
					1.62,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("octahedronGeometry", { args: [.24, 0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#ffe7a8",
					emissive: "#e39b2b",
					emissiveIntensity: 1.35,
					roughness: .22,
					flatShading: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				"rotation-x": -Math.PI / 2,
				position: [
					0,
					.05,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
					.42,
					.62,
					6
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#e39b2b",
					emissive: "#e39b2b",
					emissiveIntensity: .45,
					roughness: .45
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
				position: [
					0,
					1.7,
					0
				],
				color: "#ffc14d",
				intensity: 16,
				distance: 9,
				decay: 2
			})
		]
	});
}
function Fireflies() {
	const positions = (0, import_react.useMemo)(() => new Float32Array(session.flies.length * 3), []);
	const geo = (0, import_react.useMemo)(() => {
		const g = new BufferGeometry();
		g.setAttribute("position", new BufferAttribute(positions, 3));
		return g;
	}, [positions]);
	(0, import_react.useEffect)(() => () => geo.dispose(), [geo]);
	const mat = (0, import_react.useMemo)(() => {
		return new PointsMaterial({
			color: "#ffe08a",
			size: 7,
			sizeAttenuation: false,
			transparent: true,
			opacity: .9,
			depthWrite: false
		});
	}, []);
	(0, import_react.useEffect)(() => () => mat.dispose(), [mat]);
	useFrame(({ clock }) => {
		const t = clock.elapsedTime;
		session.flies.forEach((f, i) => {
			positions[i * 3] = f.x + Math.cos(t * .6 + f.phase) * .22;
			positions[i * 3 + 1] = f.y + (session.reduce ? 0 : Math.sin(t * 1.5 + f.phase) * .16);
			positions[i * 3 + 2] = f.z + Math.sin(t * .45 + f.phase) * .22;
		});
		const attr = geo.getAttribute("position");
		attr.needsUpdate = true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("points", {
		geometry: geo,
		material: mat
	});
}
function Bursts() {
	const mesh = (0, import_react.useRef)(null);
	const dummy = (0, import_react.useMemo)(() => new Object3D(), []);
	const color = (0, import_react.useMemo)(() => new Color(), []);
	useFrame(() => {
		const m = mesh.current;
		if (!m) return;
		const list = session.particles;
		for (let i = 0; i < 72; i++) {
			const p = list[i];
			if (p) {
				dummy.position.set(p.x, p.y, p.z);
				const s = Math.max(.04, p.life / p.max * .16);
				dummy.scale.setScalar(s);
				dummy.rotation.set(0, 0, 0);
				color.setHex(p.color);
			} else {
				dummy.position.set(0, -8, 0);
				dummy.scale.setScalar(.001);
				color.setHex(14916395);
			}
			dummy.updateMatrix();
			m.setMatrixAt(i, dummy.matrix);
			m.setColorAt(i, color);
		}
		m.instanceMatrix.needsUpdate = true;
		if (m.instanceColor) m.instanceColor.needsUpdate = true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref: mesh,
		args: [
			void 0,
			void 0,
			72
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("octahedronGeometry", { args: [1, 0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			emissive: "#e39b2b",
			emissiveIntensity: .9,
			roughness: .35,
			flatShading: true
		})]
	});
}
function World() {
	const span = Math.max(11, 11) * CELL$1 + 16;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#f6d8b0"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("fog", {
			attach: "fog",
			args: [
				"#f6d8b0",
				18,
				52
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#fff1dc",
			"#87b56e",
			.72
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", {
			intensity: .28,
			color: "#fff8ee"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			"rotation-x": -Math.PI / 2,
			position: [
				11 * CELL$1 / 2,
				-.04,
				11 * CELL$1 / 2
			],
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [span, span] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#a9cf96",
				roughness: 1
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Floors, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hedges, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trees, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flowers, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gems, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lantern, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fireflies, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bursts, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Systems, {})
	] });
}
function Game({ touch }) {
	const snap = (0, import_react.useSyncExternalStore)(subscribe, getSnap, getSnap);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "game-root relative h-dvh w-full touch-none overflow-hidden bg-sky text-ink",
		onPointerDown: (e) => {
			if (touch || session.phase !== "play") return;
			if (e.target.closest("button")) return;
			if (document.pointerLockElement === session.canvas) return;
			lockLook();
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
			className: "absolute inset-0 h-full w-full",
			shadows: true,
			dpr: [1, 1.7],
			camera: {
				fov: 74,
				near: .08,
				far: 90,
				position: [
					18,
					16,
					30
				]
			},
			gl: {
				antialias: true,
				alpha: false,
				powerPreference: "high-performance"
			},
			onCreated: ({ gl }) => {
				gl.setClearColor("#f6d8b0");
				gl.toneMapping = 4;
				gl.toneMappingExposure = 1.06;
				session.canvas = gl.domElement;
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(World, {}, snap.seed)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, { touch })]
	});
}
function mountInput() {
	attachInput();
	attachProbe();
	return () => detachInput();
}
//#endregion
export { Game, mountInput };
