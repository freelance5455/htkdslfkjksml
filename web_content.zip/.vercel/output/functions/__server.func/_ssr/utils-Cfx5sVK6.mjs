import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-Cfx5sVK6.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatBytes(bytes) {
	if (!Number.isFinite(bytes) || bytes < 0) return "—";
	const kb = 1024;
	const mb = kb * 1024;
	const gb = mb * 1024;
	if (bytes >= gb) return `${(bytes / gb).toFixed(2)} GB`;
	if (bytes >= mb) return `${(bytes / mb).toFixed(2)} MB`;
	if (bytes >= kb) return `${(bytes / kb).toFixed(1)} KB`;
	return `${Math.round(bytes)} B`;
}
//#endregion
export { formatBytes as n, cn as t };
