import { i as __toESM, n as __exportAll } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { S as AudioLines, _ as EyeOff, a as Unplug, b as Circle, c as Sparkles, d as Mic, f as MicVocal, g as Eye, h as FileAudio, i as Upload, l as Replace, m as KeyRound, n as WandSparkles, o as TriangleAlert, p as LoaderCircle, r as Volume2, s as Trash2, t as X, u as RefreshCw, v as Download, x as Check, y as Clapperboard } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { r as Slot, t as Root } from "../_libs/@radix-ui/react-label+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as Root$1, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DeCuNS9O.js
var routes_DeCuNS9O_exports = /* @__PURE__ */ __exportAll({
	a: () => decodeBase64Audio,
	c: () => encodedAudioToWav,
	component: () => Home,
	d: () => pcm16ToWav,
	f: () => prepareAnalysisAudio,
	g: () => wrapAudioBytes,
	h: () => wavPcmDuration,
	i: () => decodeAudioFile,
	l: () => floatTo16BitWav,
	m: () => reconstructTimeline,
	n: () => blobDuration,
	o: () => downsampleToMono,
	p: () => readWavSampleRate,
	r: () => computeWaveformPeaks,
	s: () => encodeBase64,
	t: () => audioBufferToWav,
	u: () => isWavBuffer
});
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WAV_HEADER = 44;
function writeString(view, offset, value) {
	for (let i = 0; i < value.length; i += 1) view.setUint8(offset + i, value.charCodeAt(i));
}
function pcm16ToWav(pcm, sampleRate = 24e3, channels = 1) {
	const header = /* @__PURE__ */ new ArrayBuffer(WAV_HEADER);
	const view = new DataView(header);
	const dataLength = pcm.byteLength;
	writeString(view, 0, "RIFF");
	view.setUint32(4, 36 + dataLength, true);
	writeString(view, 8, "WAVE");
	writeString(view, 12, "fmt ");
	view.setUint32(16, 16, true);
	view.setUint16(20, 1, true);
	view.setUint16(22, channels, true);
	view.setUint32(24, sampleRate, true);
	view.setUint32(28, sampleRate * channels * 2, true);
	view.setUint16(32, channels * 2, true);
	view.setUint16(34, 16, true);
	writeString(view, 36, "data");
	view.setUint32(40, dataLength, true);
	const out = new Uint8Array(WAV_HEADER + dataLength);
	out.set(new Uint8Array(header), 0);
	out.set(new Uint8Array(pcm), WAV_HEADER);
	return out.buffer;
}
function isWavBuffer(data) {
	if (data.byteLength < 12) return false;
	const view = new DataView(data);
	const riff = String.fromCharCode(view.getUint8(0), view.getUint8(1), view.getUint8(2), view.getUint8(3));
	const wave = String.fromCharCode(view.getUint8(8), view.getUint8(9), view.getUint8(10), view.getUint8(11));
	return riff === "RIFF" && wave === "WAVE";
}
function decodeBase64Audio(base64) {
	const binary = atob(base64);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
	return bytes.buffer;
}
function encodeBase64(buffer) {
	const bytes = new Uint8Array(buffer);
	const chunk = 32768;
	let binary = "";
	for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
	return btoa(binary);
}
function wrapAudioBytes(base64, mimeType) {
	const raw = decodeBase64Audio(base64);
	if (isWavBuffer(raw) || mimeType && mimeType.includes("wav")) return {
		wavBytes: raw,
		sampleRate: readWavSampleRate(raw) ?? 24e3
	};
	return {
		wavBytes: pcm16ToWav(raw, 24e3, 1),
		sampleRate: 24e3
	};
}
function readWavSampleRate(buffer) {
	if (buffer.byteLength < 28) return null;
	return new DataView(buffer).getUint32(24, true);
}
async function encodedAudioToWav(data, mimeType) {
	if (isWavBuffer(data) || mimeType && mimeType.includes("wav")) return {
		wavBytes: data,
		sampleRate: readWavSampleRate(data) ?? 24e3
	};
	const buffer = await decodeAudioFile(new Blob([data], { type: mimeType || "audio/mpeg" }));
	return {
		wavBytes: await audioBufferToWav(buffer).arrayBuffer(),
		sampleRate: buffer.sampleRate
	};
}
async function decodeAudioFile(file) {
	const ctx = new AudioContext();
	try {
		const data = await file.arrayBuffer();
		return await ctx.decodeAudioData(data.slice(0));
	} finally {
		await ctx.close();
	}
}
function downsampleToMono(buffer, targetRate = 16e3) {
	const channels = buffer.numberOfChannels;
	const length = buffer.length;
	const mix = new Float32Array(length);
	for (let c = 0; c < channels; c += 1) {
		const data = buffer.getChannelData(c);
		for (let i = 0; i < length; i += 1) mix[i] += data[i] / channels;
	}
	if (buffer.sampleRate === targetRate) return mix;
	const ratio = buffer.sampleRate / targetRate;
	const outLength = Math.max(1, Math.round(mix.length / ratio));
	const out = new Float32Array(outLength);
	for (let i = 0; i < outLength; i += 1) {
		const src = i * ratio;
		const i0 = Math.floor(src);
		const i1 = Math.min(mix.length - 1, i0 + 1);
		const t = src - i0;
		out[i] = mix[i0] * (1 - t) + mix[i1] * t;
	}
	return out;
}
function floatTo16BitWav(samples, sampleRate) {
	const pcm = /* @__PURE__ */ new ArrayBuffer(samples.length * 2);
	const view = new DataView(pcm);
	for (let i = 0; i < samples.length; i += 1) {
		const s = Math.max(-1, Math.min(1, samples[i] ?? 0));
		view.setInt16(i * 2, s < 0 ? s * 32768 : s * 32767, true);
	}
	return pcm16ToWav(pcm, sampleRate, 1);
}
async function prepareAnalysisAudio(file) {
	const buffer = await decodeAudioFile(file);
	const wav = floatTo16BitWav(downsampleToMono(buffer, 16e3), 16e3);
	const wavBlob = new Blob([wav], { type: "audio/wav" });
	if (wavBlob.size <= 35e5) return {
		blob: wavBlob,
		mimeType: "audio/wav"
	};
	const compressed = await encodeWithMediaRecorder(buffer);
	if (compressed) return compressed;
	const tighter = downsampleToMono(buffer, 12e3);
	return {
		blob: new Blob([floatTo16BitWav(tighter, 12e3)], { type: "audio/wav" }),
		mimeType: "audio/wav"
	};
}
async function encodeWithMediaRecorder(buffer) {
	if (typeof MediaRecorder === "undefined") return null;
	const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "";
	if (!mimeType) return null;
	const ctx = new AudioContext();
	try {
		const dest = ctx.createMediaStreamDestination();
		const source = ctx.createBufferSource();
		source.buffer = buffer;
		source.connect(dest);
		const recorder = new MediaRecorder(dest.stream, {
			mimeType,
			audioBitsPerSecond: 24e3
		});
		const chunks = [];
		recorder.ondataavailable = (event) => {
			if (event.data.size > 0) chunks.push(event.data);
		};
		const stopped = new Promise((resolve, reject) => {
			recorder.onstop = () => resolve(new Blob(chunks, { type: mimeType.split(";")[0] }));
			recorder.onerror = () => reject(/* @__PURE__ */ new Error("MediaRecorder failed"));
		});
		recorder.start();
		source.start();
		await new Promise((resolve) => {
			source.onended = () => resolve();
		});
		await new Promise((r) => setTimeout(r, 80));
		if (recorder.state !== "inactive") recorder.stop();
		const blob = await stopped;
		if (blob.size < 64) return null;
		return {
			blob,
			mimeType: blob.type || "audio/webm"
		};
	} catch {
		return null;
	} finally {
		await ctx.close();
	}
}
function computeWaveformPeaks(buffer, bars = 160) {
	const data = buffer.getChannelData(0);
	const block = Math.max(1, Math.floor(data.length / bars));
	const peaks = [];
	for (let i = 0; i < bars; i += 1) {
		const start = i * block;
		let max = 0;
		for (let j = 0; j < block; j += 1) {
			const v = Math.abs(data[start + j] ?? 0);
			if (v > max) max = v;
		}
		peaks.push(max);
	}
	const peak = Math.max(...peaks, .001);
	return peaks.map((p) => p / peak);
}
async function reconstructTimeline(clips, totalDuration) {
	const sampleRate = 48e3;
	const length = Math.max(1, Math.ceil(Math.max(totalDuration, .25) * sampleRate));
	const ctx = new OfflineAudioContext(1, length, sampleRate);
	for (const clip of clips) {
		if (clip.isSilence) continue;
		const decoded = await ctx.decodeAudioData(clip.wavBytes.slice(0));
		const source = ctx.createBufferSource();
		source.buffer = decoded;
		const window = Math.max(.08, clip.end - clip.start);
		const rate = decoded.duration / window;
		if (rate > 1.28) source.playbackRate.value = Math.min(rate, 1.35);
		else if (rate < .72) source.playbackRate.value = Math.max(rate, .78);
		else if (Math.abs(rate - 1) > .08) source.playbackRate.value = rate;
		source.connect(ctx.destination);
		source.start(Math.max(0, clip.start));
	}
	return ctx.startRendering();
}
function audioBufferToWav(buffer) {
	const wav = floatTo16BitWav(downsampleToMono(buffer, buffer.sampleRate), buffer.sampleRate);
	return new Blob([wav], { type: "audio/wav" });
}
function wavPcmDuration(wavBytes, sampleRate) {
	const header = isWavBuffer(wavBytes) ? 44 : 0;
	return Math.max(0, wavBytes.byteLength - header) / (sampleRate * 2);
}
async function blobDuration(blob) {
	const url = URL.createObjectURL(blob);
	try {
		const audio = document.createElement("audio");
		audio.preload = "metadata";
		return await new Promise((resolve, reject) => {
			audio.onloadedmetadata = () => resolve(Number.isFinite(audio.duration) ? audio.duration : 0);
			audio.onerror = () => reject(/* @__PURE__ */ new Error("Could not read audio duration"));
			audio.src = url;
		});
	} finally {
		URL.revokeObjectURL(url);
	}
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatBytes(bytes) {
	if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
	const units = [
		"B",
		"KB",
		"MB",
		"GB"
	];
	const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
	const value = bytes / 1024 ** i;
	return `${value >= 10 || i === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[i]}`;
}
function formatDuration(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
	const s = Math.round(seconds);
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const r = s % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
	return `${m}:${String(r).padStart(2, "0")}`;
}
function formatTimecode(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0.0s";
	return `${seconds.toFixed(1)}s`;
}
function maskApiKey(key) {
	const trimmed = key.trim();
	if (trimmed.length < 8) return "••••";
	return `${trimmed.slice(0, 4)}••••••••••••${trimmed.slice(-4)}`;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground shadow-border hover:shadow-border-hover",
			outline: "bg-transparent text-foreground shadow-border hover:bg-secondary",
			ghost: "bg-transparent text-foreground hover:bg-secondary",
			destructive: "bg-destructive text-destructive-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 rounded-lg px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "bg-secondary text-foreground",
		steel: "bg-accent text-accent-foreground",
		outline: "shadow-border text-muted-foreground",
		success: "bg-success/15 text-success",
		warning: "bg-warning/15 text-warning",
		danger: "bg-destructive/15 text-destructive"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var API_FAMILIES = [
	"gemini",
	"openai",
	"xai",
	"elevenlabs",
	"compat"
];
function isApiFamily(value) {
	return API_FAMILIES.includes(value);
}
function familyLabel(family, fallback = "Custom API") {
	if (family === "gemini") return "Gemini-compatible";
	if (family === "openai") return "OpenAI-compatible";
	if (family === "xai") return "xAI-compatible";
	if (family === "elevenlabs") return "ElevenLabs-compatible";
	if (family === "compat") return "OpenAI-compatible";
	return fallback;
}
var ANALYSIS_KEY = "cvs.analysisKey";
var GENERATION_KEY = "cvs.generationKey";
var ANALYSIS_URL_KEY = "cvs.analysisUrl";
var GENERATION_URL_KEY = "cvs.generationUrl";
var ANALYSIS_FAMILY_KEY = "cvs.analysisFamily";
var GENERATION_FAMILY_KEY = "cvs.generationFamily";
var PIPELINE_BLUEPRINT = [
	{
		id: "uploading",
		label: "Uploading audio"
	},
	{
		id: "reading",
		label: "Reading audio"
	},
	{
		id: "analyzing_speakers",
		label: "Analyzing speakers"
	},
	{
		id: "detecting_segments",
		label: "Detecting speaker segments"
	},
	{
		id: "understanding_story",
		label: "Understanding story context"
	},
	{
		id: "building_profiles",
		label: "Building character profiles"
	},
	{
		id: "analyzing_emotions",
		label: "Analyzing emotions"
	},
	{
		id: "casting_voices",
		label: "Automatically casting voices"
	},
	{
		id: "separating_segments",
		label: "Separating speaker segments"
	},
	{
		id: "converting_voices",
		label: "Converting character voices"
	},
	{
		id: "applying_emotion",
		label: "Applying emotional delivery"
	},
	{
		id: "reconstructing_timeline",
		label: "Reconstructing original timeline"
	},
	{
		id: "mixing",
		label: "Mixing final audio"
	},
	{
		id: "exporting",
		label: "Generating final WAV"
	},
	{
		id: "ready",
		label: "Ready for preview"
	}
];
function idlePipeline() {
	return PIPELINE_BLUEPRINT.map((s) => ({
		...s,
		status: "idle",
		percent: 0
	}));
}
function readSession(key) {
	try {
		return sessionStorage.getItem(key) ?? "";
	} catch {
		return "";
	}
}
function writeSession(key, value) {
	try {
		if (value) sessionStorage.setItem(key, value);
		else sessionStorage.removeItem(key);
	} catch {}
}
var useStudio = create((set, get) => ({
	hydrated: false,
	analysisUrl: "",
	analysisFamily: null,
	analysisKey: "",
	analysisShowKey: false,
	analysisStatus: "idle",
	analysisMessage: "",
	analysisModel: null,
	generationUrl: "",
	generationFamily: null,
	generationKey: "",
	generationShowKey: false,
	generationStatus: "idle",
	generationMessage: "",
	generationModel: null,
	workflowUnlocked: false,
	original: null,
	peaks: [],
	fileRefName: null,
	analysis: null,
	busy: false,
	busyLabel: "",
	error: null,
	pipeline: idlePipeline(),
	convertIndex: 0,
	convertTotal: 0,
	segmentAudio: {},
	mixUrl: null,
	quality: [],
	transfer: null,
	hydrate: () => {
		if (get().hydrated) return;
		const analysisFamilyRaw = readSession(ANALYSIS_FAMILY_KEY);
		const generationFamilyRaw = readSession(GENERATION_FAMILY_KEY);
		set({
			hydrated: true,
			analysisKey: readSession(ANALYSIS_KEY),
			generationKey: readSession(GENERATION_KEY),
			analysisUrl: readSession(ANALYSIS_URL_KEY),
			generationUrl: readSession(GENERATION_URL_KEY),
			analysisFamily: isApiFamily(analysisFamilyRaw) ? analysisFamilyRaw : null,
			generationFamily: isApiFamily(generationFamilyRaw) ? generationFamilyRaw : null
		});
	},
	setAnalysisUrl: (value) => {
		writeSession(ANALYSIS_URL_KEY, value);
		set({
			analysisUrl: value,
			analysisStatus: "idle",
			analysisMessage: "",
			analysisModel: null,
			analysisFamily: null,
			workflowUnlocked: false
		});
	},
	setAnalysisFamily: (value) => {
		writeSession(ANALYSIS_FAMILY_KEY, value ?? "");
		set({ analysisFamily: value });
	},
	setAnalysisKey: (value) => {
		writeSession(ANALYSIS_KEY, value);
		set({
			analysisKey: value,
			analysisStatus: "idle",
			analysisMessage: "",
			analysisModel: null,
			analysisFamily: null,
			workflowUnlocked: false
		});
	},
	setAnalysisShowKey: (value) => set({ analysisShowKey: value }),
	setAnalysisStatus: (status, message = "") => set({
		analysisStatus: status,
		analysisMessage: message
	}),
	setAnalysisModel: (model) => set({ analysisModel: model }),
	setGenerationUrl: (value) => {
		writeSession(GENERATION_URL_KEY, value);
		set({
			generationUrl: value,
			generationStatus: "idle",
			generationMessage: "",
			generationModel: null,
			generationFamily: null,
			workflowUnlocked: false
		});
	},
	setGenerationFamily: (value) => {
		writeSession(GENERATION_FAMILY_KEY, value ?? "");
		set({ generationFamily: value });
	},
	setGenerationKey: (value) => {
		writeSession(GENERATION_KEY, value);
		set({
			generationKey: value,
			generationStatus: "idle",
			generationMessage: "",
			generationModel: null,
			generationFamily: null,
			workflowUnlocked: false
		});
	},
	setGenerationShowKey: (value) => set({ generationShowKey: value }),
	setGenerationStatus: (status, message = "") => set({
		generationStatus: status,
		generationMessage: message
	}),
	setGenerationModel: (model) => set({ generationModel: model }),
	unlockWorkflow: () => {
		if (get().analysisStatus !== "valid" || get().generationStatus !== "valid") return;
		set({ workflowUnlocked: true });
	},
	clearAnalysisKey: () => {
		writeSession(ANALYSIS_KEY, "");
		set({
			analysisKey: "",
			analysisStatus: "idle",
			analysisMessage: "",
			analysisShowKey: false,
			analysisModel: null,
			analysisFamily: null,
			workflowUnlocked: false
		});
	},
	clearGenerationKey: () => {
		writeSession(GENERATION_KEY, "");
		set({
			generationKey: "",
			generationStatus: "idle",
			generationMessage: "",
			generationShowKey: false,
			generationModel: null,
			generationFamily: null,
			workflowUnlocked: false
		});
	},
	setOriginal: (asset, peaks = []) => {
		const prev = get().original;
		if (prev?.objectUrl) URL.revokeObjectURL(prev.objectUrl);
		const mix = get().mixUrl;
		if (mix) URL.revokeObjectURL(mix);
		for (const clip of Object.values(get().segmentAudio)) URL.revokeObjectURL(clip.wavUrl);
		set({
			original: asset,
			peaks,
			analysis: null,
			segmentAudio: {},
			mixUrl: null,
			quality: [],
			error: null,
			pipeline: idlePipeline(),
			convertIndex: 0,
			convertTotal: 0,
			transfer: null
		});
	},
	setAnalysis: (analysis) => set({ analysis }),
	setBusy: (busy, label = "") => set({
		busy,
		busyLabel: label
	}),
	setError: (error) => set({ error }),
	resetPipeline: () => set({
		pipeline: idlePipeline(),
		transfer: null
	}),
	markStage: (id, status, detail) => set({ pipeline: get().pipeline.map((s) => s.id === id ? {
		...s,
		status,
		detail,
		percent: status === "done" ? 100 : status === "idle" ? 0 : status === "error" ? s.percent : Math.max(s.percent, 6)
	} : s) }),
	setStagePercent: (id, percent, detail) => set({ pipeline: get().pipeline.map((s) => {
		if (s.id !== id || s.status !== "active") return s;
		return {
			...s,
			percent: Math.max(0, Math.min(100, Math.round(percent))),
			...detail !== void 0 ? { detail } : {}
		};
	}) }),
	setTransfer: (progress) => set({ transfer: progress }),
	setConvertProgress: (index, total) => set({
		convertIndex: index,
		convertTotal: total
	}),
	putSegmentAudio: (clip) => {
		set((state) => {
			const prev = state.segmentAudio[clip.segmentId];
			if (prev) URL.revokeObjectURL(prev.wavUrl);
			return { segmentAudio: {
				...state.segmentAudio,
				[clip.segmentId]: clip
			} };
		});
	},
	setMixUrl: (url) => {
		const prev = get().mixUrl;
		if (prev && prev !== url) URL.revokeObjectURL(prev);
		set({ mixUrl: url });
	},
	setQuality: (checks) => set({ quality: checks }),
	resetProject: () => {
		const { original, mixUrl, segmentAudio } = get();
		if (original?.objectUrl) URL.revokeObjectURL(original.objectUrl);
		if (mixUrl) URL.revokeObjectURL(mixUrl);
		for (const clip of Object.values(segmentAudio)) URL.revokeObjectURL(clip.wavUrl);
		set({
			original: null,
			peaks: [],
			analysis: null,
			segmentAudio: {},
			mixUrl: null,
			quality: [],
			error: null,
			pipeline: idlePipeline(),
			convertIndex: 0,
			convertTotal: 0,
			busy: false,
			busyLabel: "",
			transfer: null
		});
	}
}));
var STUDIO_ERROR_MESSAGES = {
	invalid_api_key: "The API key could not be authenticated. Please check the key and try again.",
	quota_exceeded: "The API key was accepted, but quota or credits are currently unavailable.",
	model_unavailable: "The API key works, but the selected provider does not currently provide a compatible model.",
	network_error: "Unable to connect to the selected AI provider. Check your internet connection and try again.",
	server_error: "The selected AI provider is temporarily unavailable. Please try again.",
	request_error: "The request was rejected. Please try again.",
	audio_error: "The uploaded audio could not be processed.",
	speaker_error: "The system could not reliably identify the speakers.",
	voice_engine_error: "The voice-conversion engine could not generate one or more speaker segments.",
	emotion_error: "Emotional analysis failed for one or more segments.",
	general_error: "Something went wrong. Please try processing the audio again."
};
var StudioError = class extends Error {
	code;
	constructor(code, detail) {
		super(detail ? `${STUDIO_ERROR_MESSAGES[code]} ${detail}` : STUDIO_ERROR_MESSAGES[code]);
		this.name = "StudioError";
		this.code = code;
	}
};
function mapProviderHttpError(status, bodyText) {
	const lower = bodyText.toLowerCase();
	const mentionsKey = lower.includes("api key") || lower.includes("api_key") || lower.includes("invalid key") || lower.includes("incorrect api key") || lower.includes("invalid_api_key") || lower.includes("key not valid") || lower.includes("unauthenticated") || lower.includes("authentication") || lower.includes("unauthorized") || lower.includes("permission_denied") || lower.includes("invalid xi-api-key");
	const mentionsQuota = lower.includes("quota") || lower.includes("resource_exhausted") || lower.includes("rate limit") || lower.includes("rate_limit") || lower.includes("insufficient_quota") || lower.includes("credits");
	const mentionsModel = lower.includes("not found") || lower.includes("is not found") || lower.includes("not supported") || lower.includes("model") && (lower.includes("unknown") || lower.includes("unavailable") || lower.includes("does not exist"));
	if (status === 401 || status === 403) {
		if (mentionsQuota) return new StudioError("quota_exceeded");
		return new StudioError("invalid_api_key");
	}
	if (status === 429 || mentionsQuota) return new StudioError("quota_exceeded");
	if (status === 404 || mentionsModel) return new StudioError("model_unavailable");
	if (status >= 500) return new StudioError("server_error");
	if (status === 400 && mentionsKey) return new StudioError("invalid_api_key");
	if (status === 400) return new StudioError("request_error");
	return new StudioError("general_error");
}
function v(id, tagline, pitch, age, texture, energy, bestFor, nativeName = id) {
	return {
		id,
		nativeName,
		tagline,
		pitch,
		age,
		texture,
		energy,
		bestFor
	};
}
var GEMINI_VOICES = [
	v("Charon", "Informative", "low", "mature", "clear", "even", [
		"narrator",
		"documentary",
		"authority"
	]),
	v("Sadaltager", "Knowledgeable", "low", "mature", "warm", "calm", [
		"wise elder",
		"mentor",
		"narrator"
	]),
	v("Rasalgethi", "Informative", "mid", "mature", "clear", "even", [
		"narrator",
		"guide",
		"scholar"
	]),
	v("Algenib", "Gravelly", "low", "mature", "gravelly", "even", [
		"elderly man",
		"weathered",
		"rough authority"
	]),
	v("Enceladus", "Breathy", "low", "adult", "breathy", "calm", [
		"intimate",
		"tired",
		"haunted"
	]),
	v("Gacrux", "Mature", "low", "mature", "warm", "calm", [
		"elder woman",
		"matriarch",
		"grave warmth"
	]),
	v("Orus", "Firm", "low", "adult", "firm", "even", [
		"commander",
		"serious lead",
		"conflict"
	]),
	v("Alnilam", "Firm", "low", "adult", "firm", "even", [
		"stern",
		"formal",
		"judge"
	]),
	v("Kore", "Firm", "mid", "adult", "firm", "even", [
		"resolute woman",
		"lead",
		"drama"
	]),
	v("Sulafat", "Warm", "mid", "adult", "warm", "calm", [
		"caregiver",
		"romance",
		"kind narrator"
	]),
	v("Umbriel", "Easy-going", "mid", "adult", "smooth", "calm", [
		"laid-back",
		"friend",
		"everyday"
	]),
	v("Schedar", "Even", "mid", "adult", "clear", "even", [
		"narrator",
		"neutral",
		"reportage"
	]),
	v("Iapetus", "Clear", "mid", "adult", "clear", "even", [
		"news",
		"clarity",
		"exposition"
	]),
	v("Zubenelgenubi", "Casual", "mid", "adult", "smooth", "even", ["contemporary", "dialogue"]),
	v("Algieba", "Smooth", "low", "adult", "smooth", "calm", [
		"suave",
		"romance",
		"velvet"
	]),
	v("Despina", "Smooth", "mid", "adult", "smooth", "calm", [
		"elegant",
		"composed",
		"romance"
	]),
	v("Erinome", "Clear", "high", "adult", "clear", "even", [
		"precise",
		"bright adult",
		"wit"
	]),
	v("Callirrhoe", "Easy-going", "mid", "adult", "warm", "calm", ["friendly", "soft lead"]),
	v("Vindemiatrix", "Gentle", "mid", "adult", "warm", "calm", [
		"tender",
		"grief",
		"lullaby"
	]),
	v("Achernar", "Soft", "high", "youthful", "breathy", "calm", [
		"shy",
		"soft-spoken",
		"young woman"
	]),
	v("Leda", "Youthful", "high", "youthful", "clear", "bright", ["young woman", "ingenuous"]),
	v("Aoede", "Breezy", "high", "youthful", "smooth", "lively", [
		"light",
		"humor",
		"summer"
	]),
	v("Zephyr", "Bright", "high", "youthful", "clear", "bright", ["energetic youth", "hope"]),
	v("Autonoe", "Bright", "high", "adult", "clear", "bright", ["vivacious", "comedy"]),
	v("Puck", "Upbeat", "mid", "youthful", "clear", "lively", [
		"young man",
		"mischief",
		"adventure"
	]),
	v("Fenrir", "Excitable", "mid", "youthful", "firm", "lively", [
		"hot-headed",
		"action",
		"urgency"
	]),
	v("Laomedeia", "Upbeat", "high", "youthful", "smooth", "lively", ["cheerful", "friend"]),
	v("Sadachbia", "Lively", "mid", "adult", "clear", "lively", [
		"animated",
		"storyteller",
		"wit"
	]),
	v("Achird", "Friendly", "mid", "adult", "warm", "even", [
		"companion",
		"warm lead",
		"trust"
	]),
	v("Pulcherrima", "Forward", "mid", "adult", "firm", "bright", [
		"bold",
		"confrontation",
		"charisma"
	])
];
var OPENAI_VOICES = [
	v("alloy", "Neutral", "mid", "adult", "clear", "even", [
		"narrator",
		"neutral",
		"everyday"
	]),
	v("ash", "Steady", "low", "adult", "clear", "even", ["serious", "documentary"]),
	v("ballad", "Warm", "mid", "adult", "warm", "calm", [
		"romance",
		"kind",
		"storyteller"
	]),
	v("coral", "Bright", "high", "adult", "smooth", "bright", [
		"lead",
		"hope",
		"vivacious"
	]),
	v("echo", "Even", "mid", "adult", "clear", "even", ["narrator", "clarity"]),
	v("fable", "Story", "mid", "adult", "warm", "even", [
		"narrator",
		"fairy tale",
		"wit"
	]),
	v("nova", "Bright", "high", "youthful", "clear", "bright", ["young woman", "energy"]),
	v("onyx", "Deep", "low", "mature", "firm", "even", [
		"authority",
		"elder",
		"commander"
	]),
	v("sage", "Calm", "mid", "mature", "warm", "calm", [
		"mentor",
		"wise",
		"narrator"
	]),
	v("shimmer", "Soft", "high", "youthful", "breathy", "calm", [
		"gentle",
		"tender",
		"shy"
	]),
	v("verse", "Poetic", "mid", "adult", "smooth", "even", ["drama", "literary"]),
	v("marin", "Clear", "high", "adult", "clear", "even", ["precise", "contemporary"]),
	v("cedar", "Grounded", "low", "adult", "warm", "calm", ["trust", "companion"])
];
var XAI_VOICES = [
	v("eve", "Warm", "mid", "adult", "warm", "even", [
		"lead",
		"companion",
		"narrator"
	]),
	v("ara", "Bright", "high", "youthful", "clear", "bright", ["young woman", "hope"]),
	v("rex", "Firm", "low", "adult", "firm", "even", ["authority", "conflict"]),
	v("sal", "Gravelly", "low", "mature", "gravelly", "even", ["elder", "weathered"]),
	v("leo", "Deep", "low", "adult", "clear", "even", ["serious lead", "drama"]),
	v("mia", "Soft", "high", "adult", "breathy", "calm", ["tender", "grief"]),
	v("zoe", "Lively", "high", "youthful", "smooth", "lively", ["cheer", "friend"]),
	v("max", "Upbeat", "mid", "youthful", "clear", "lively", ["young man", "adventure"]),
	v("una", "Calm", "mid", "adult", "warm", "calm", ["narrator", "guide"]),
	v("kai", "Clear", "mid", "adult", "clear", "even", ["everyday", "dialogue"]),
	v("nia", "Gentle", "mid", "adult", "warm", "calm", ["caregiver", "romance"]),
	v("oro", "Story", "low", "mature", "warm", "calm", ["narrator", "mentor"])
];
var ELEVENLABS_FALLBACK_VOICES = [
	v("narrator", "Narrator", "mid", "mature", "clear", "even", ["narrator", "documentary"], "narrator"),
	v("lead_a", "Lead A", "low", "adult", "firm", "even", ["lead", "authority"], "lead_a"),
	v("lead_b", "Lead B", "mid", "adult", "warm", "even", ["lead", "companion"], "lead_b"),
	v("youth", "Youth", "high", "youthful", "clear", "bright", ["young", "hope"], "youth"),
	v("elder", "Elder", "low", "mature", "gravelly", "calm", ["elder", "wise"], "elder"),
	v("soft", "Soft", "high", "adult", "breathy", "calm", ["tender", "shy"], "soft"),
	v("bright", "Bright", "high", "adult", "smooth", "lively", ["humor", "energy"], "bright"),
	v("calm", "Calm", "mid", "adult", "warm", "calm", ["calm", "guide"], "calm")
];
var elevenLabsLive = null;
function catalogFor(provider) {
	if (provider === "gemini") return GEMINI_VOICES;
	if (provider === "openai" || provider === "compat") return OPENAI_VOICES;
	if (provider === "xai") return XAI_VOICES;
	return elevenLabsLive ?? ELEVENLABS_FALLBACK_VOICES;
}
function getVoice(id, catalog) {
	const list = catalog ?? [
		...GEMINI_VOICES,
		...OPENAI_VOICES,
		...XAI_VOICES,
		...elevenLabsLive ?? []
	];
	const key = id.trim().toLowerCase();
	return list.find((v) => v.id.toLowerCase() === key || v.nativeName.toLowerCase() === key);
}
function catalogPromptBlock(catalog) {
	return catalog.map((voice) => `- ${voice.id}: ${voice.tagline}; pitch ${voice.pitch}; age ${voice.age}; texture ${voice.texture}; energy ${voice.energy}; best for ${voice.bestFor.join(", ")}`).join("\n");
}
function scoreVoice(speaker, voice) {
	let score = 0;
	const ov = speaker.original_voice;
	const blob = [
		speaker.role,
		speaker.story_context,
		speaker.recommended_voice_profile,
		ov.age_characteristic,
		ov.pitch,
		ov.texture,
		ov.energy,
		ov.speaking_style,
		speaker.personality.join(" "),
		speaker.emotional_style.join(" ")
	].join(" ").toLowerCase();
	if ({
		youthful: /young|youth|teen|child|girl|boy|ingenuous/,
		mature: /elder|old|aged|wise|veteran|matriarch|patriarch|grave/,
		adult: /adult|woman|man|lead/
	}[voice.age].test(blob)) score += 4;
	if (voice.age === "mature" && /elderly|old man|old woman/.test(blob)) score += 3;
	if (voice.age === "youthful" && /young woman|young man|girl|boy/.test(blob)) score += 3;
	if (voice.pitch === "low" && /low|deep|bass|baritone|gravel/.test(blob)) score += 3;
	if (voice.pitch === "high" && /high|bright|light|soprano|youth/.test(blob)) score += 3;
	if (voice.pitch === "mid" && /mid|medium|even/.test(blob)) score += 1;
	if (voice.texture === "gravelly" && /rough|gravel|rasp|weathered/.test(blob)) score += 3;
	if (voice.texture === "warm" && /warm|kind|gentle|soft|tender/.test(blob)) score += 2;
	if (voice.texture === "firm" && /firm|stern|authorit|command/.test(blob)) score += 2;
	if (voice.texture === "breathy" && /breath|whisper|intimate|fragile/.test(blob)) score += 3;
	if (voice.energy === "calm" && /calm|quiet|still|grave/.test(blob)) score += 2;
	if (voice.energy === "lively" && /lively|excitable|hot|urgent|anger|angry/.test(blob)) score += 2;
	if (voice.energy === "bright" && /bright|hope|cheer|humor/.test(blob)) score += 2;
	if (speaker.is_narrator && voice.bestFor.includes("narrator")) score += 5;
	for (const tag of voice.bestFor) if (blob.includes(tag.toLowerCase())) score += 2;
	if (speaker.importance === "lead") score += .2;
	return score;
}
function enforceUniqueVoices(speakers, catalog) {
	const used = /* @__PURE__ */ new Set();
	const ranked = [...speakers].sort((a, b) => {
		const rank = {
			lead: 0,
			supporting: 1,
			minor: 2
		};
		return rank[a.importance] - rank[b.importance];
	});
	const assigned = /* @__PURE__ */ new Map();
	const byId = new Map(catalog.map((voice) => [voice.id, voice]));
	for (const speaker of ranked) {
		const preferred = byId.get(speaker.recommended_voice_id);
		let chosen = preferred && !used.has(preferred.id) ? preferred : void 0;
		if (!chosen) chosen = catalog.filter((voice) => !used.has(voice.id)).map((voice) => ({
			v: voice,
			s: scoreVoice(speaker, voice)
		})).sort((a, b) => b.s - a.s)[0]?.v ?? catalog.find((voice) => !used.has(voice.id)) ?? catalog[0];
		if (chosen) {
			used.add(chosen.id);
			assigned.set(speaker.speaker_id, chosen.id);
		}
	}
	return speakers.map((speaker) => {
		const id = assigned.get(speaker.speaker_id) ?? speaker.recommended_voice_id;
		const voice = byId.get(id);
		return {
			...speaker,
			recommended_voice_id: id,
			recommended_voice_profile: voice ? `${voice.tagline.toLowerCase()} ${voice.age} ${voice.pitch}-pitch ${voice.texture} voice` : speaker.recommended_voice_profile
		};
	});
}
function recastSpeaker(speaker, taken, catalog) {
	const next = catalog.filter((voice) => !taken.has(voice.id) && voice.id !== speaker.recommended_voice_id).map((voice) => ({
		v: voice,
		s: scoreVoice(speaker, voice)
	})).sort((a, b) => b.s - a.s)[0]?.v;
	if (!next) return speaker;
	return {
		...speaker,
		recommended_voice_id: next.id,
		recommended_voice_profile: `${next.tagline.toLowerCase()} ${next.age} ${next.pitch}-pitch ${next.texture} voice`,
		voice_reason: `${speaker.voice_reason} Recast to ${next.id} (${next.tagline}) to keep the ensemble distinct.`
	};
}
function speakerColorVar(index) {
	return `var(--color-speaker-${index % 12 + 1})`;
}
var EMOTION_DIRECTION = {
	happiness: "warm, with a natural smile in the voice and lifted energy",
	sadness: "restrained sadness, slightly quieter, allowing the line to break",
	anger: "genuinely angry — firm, forceful and controlled, not a cartoon shout unless the line demands it",
	fear: "frightened, breath a little tight, as if danger is close",
	surprise: "genuine surprise, a lift at the start, then landing the thought",
	excitement: "lively excitement and forward energy",
	calmness: "calm, even, unhurried",
	nervousness: "nervous, with small human hesitations",
	frustration: "contained frustration",
	love: "soft, with affection",
	grief: "grief, voice slightly trembling and quiet",
	suspicion: "wary suspicion",
	confusion: "puzzled uncertainty",
	humor: "dry, believable humor — not a cartoon",
	tension: "under tension, held-in and alert",
	authority: "calm authority"
};
function ttsPromptForSegment(speaker, segment) {
	const text = segment.text.trim();
	if (!text) return "";
	const ov = speaker.original_voice;
	const emotionHow = EMOTION_DIRECTION[segment.emotion.toLowerCase()] ?? `${segment.emotion}, ${segment.delivery_notes || "naturally"}`;
	const intensity = segment.emotion_intensity === "very_high" ? "very high" : segment.emotion_intensity === "high" ? "high" : segment.emotion_intensity === "very_low" ? "very low, almost underplayed" : segment.emotion_intensity === "low" ? "low" : "medium";
	const who = speaker.is_narrator ? "Narrate" : "Say";
	const identity = speaker.is_narrator ? "Keep a storytelling cadence. Do not use a character-acting shout. This is the narrator, not a character." : `Stay in character as ${speaker.display_name}, ${speaker.role}. This is the same person every time they speak.`;
	return [
		`${who} this line as a professionally performed audiobook / dramatized story — human, never robotic or monotone.`,
		`Character: ${speaker.display_name}. Role: ${speaker.role}. ${speaker.is_narrator ? "Narrator." : ""}`,
		`Persistent voice identity: ${speaker.recommended_voice_profile || "the assigned catalog voice"}. ${ov.age_characteristic}, ${ov.pitch} pitch, ${ov.texture} texture, ${ov.pace} pace.`,
		`Personality: ${speaker.personality.join(", ") || "as established"}.`,
		`Emotion now: ${segment.emotion} at ${intensity} intensity — ${emotionHow}.`,
		segment.delivery_notes ? `Delivery: ${segment.delivery_notes}.` : "",
		speaker.story_context ? `Scene: ${speaker.story_context}` : "",
		"Use natural pitch variation, natural pauses, emphasis on the important words, and context-aware rhythm.",
		"Do not add extra words, stage directions, or the character name. Speak only the dialogue.",
		identity,
		"",
		text
	].filter(Boolean).join(" ");
}
function spokenTextOnly(segment) {
	return segment.text.trim();
}
function performanceNotes(speaker, segment) {
	const full = ttsPromptForSegment(speaker, segment);
	const text = segment.text.trim();
	if (!text) return full;
	const idx = full.lastIndexOf(text);
	return idx >= 0 ? full.slice(0, idx).trim() : full;
}
var INTENSITY_LEVELS = [
	"very_low",
	"low",
	"medium",
	"high",
	"very_high"
];
var IMPORTANCE_LEVELS = [
	"lead",
	"supporting",
	"minor"
];
function analysisPrompt(duration, catalogBlock, source) {
	return `You are a professional dialogue editor, dialect coach, and casting director working on a multi-speaker story recording.

${source === "audio" ? "Listen to the entire audio. Identify every distinct SPEAKER, including a narrator if present. Analyze original vocal characteristics, character personality, relationships, story genre/mood, and the emotional intention of each line." : "Read the transcript with timestamps. Identify every distinct SPEAKER, including a narrator if present. Infer original vocal characteristics from wording, role, and any STT speaker labels. Analyze personality, relationships, story genre/mood, and the emotional intention of each line."}

Duration of the file: ${duration.toFixed(2)} seconds.

Return ONLY valid JSON with this exact shape:
{
  "story": {
    "title": string,
    "genre": string,
    "mood": string,
    "time_period": string | null,
    "environment": string,
    "atmosphere": string[],
    "summary": string,
    "language": string
  },
  "speakers": [
    {
      "speaker_id": "speaker_01",
      "display_name": string,
      "role": string,
      "is_narrator": boolean,
      "importance": "lead" | "supporting" | "minor",
      "original_voice": {
        "age_characteristic": string,
        "pitch": "low" | "mid" | "high",
        "pace": string,
        "texture": string,
        "energy": string,
        "gender_presentation": string,
        "speaking_style": string,
        "resonance": string,
        "clarity": string
      },
      "personality": string[],
      "emotional_style": string[],
      "story_context": string,
      "relationships": string,
      "recommended_voice_id": string,
      "recommended_voice_profile": string,
      "voice_reason": string
    }
  ],
  "segments": [
    {
      "id": "seg_001",
      "speaker_id": "speaker_01",
      "start": number,
      "end": number,
      "text": string,
      "emotion": string,
      "emotion_intensity": "very_low" | "low" | "medium" | "high" | "very_high",
      "delivery_notes": string,
      "is_silence": boolean
    }
  ],
  "narrator_id": string | null,
  "quality_notes": string[]
}

Casting rules:
- recommended_voice_id MUST be one of the catalog ids below.
- Never assign the same voice id to two different speakers, especially leads.
- Do not cast by gender alone. Personality, age, timbre, role, and scene mood matter more.
- The narrator (if any) should receive a storytelling voice, not a character voice.
- Keep the same speaker_id for the same character across the whole file.
- Identify EVERY distinct speaker. Do not stop at 10.
- Emotion must come from the meaning of the line AND the scene.
- Use one of: happiness, sadness, anger, fear, excitement, surprise, nervousness, calmness, frustration, grief, love, suspicion, confusion, humor, tension, authority — when they fit.
- Cover the full duration. Insert silence segments (is_silence true, text "") for pauses longer than 0.35s.
- start/end are seconds from 0, floats, non-overlapping, in order.
- Preserve original dialogue wording in text.
- Every important character gets a different suitable voice.

VOICE CATALOG:
${catalogBlock}`;
}
function extractJson(text) {
	const trimmed = text.trim();
	const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
	const raw = fence ? fence[1].trim() : trimmed;
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) throw new StudioError("speaker_error");
	try {
		return JSON.parse(raw.slice(start, end + 1));
	} catch {
		throw new StudioError("speaker_error");
	}
}
function asString(value, fallback = "") {
	return typeof value === "string" ? value : fallback;
}
function asNumber(value, fallback = 0) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : fallback;
}
function asBool(value) {
	return value === true || value === "true";
}
function asStringArray(value) {
	if (!Array.isArray(value)) return [];
	return value.filter((v) => typeof v === "string" && v.trim().length > 0);
}
function parseIntensity(value) {
	const v = asString(value, "medium").toLowerCase().replace(/\s+/g, "_");
	return INTENSITY_LEVELS.includes(v) ? v : "medium";
}
function parseOriginalVoice(value) {
	const o = value ?? {};
	return {
		age_characteristic: asString(o.age_characteristic, "adult"),
		pitch: asString(o.pitch, "mid"),
		pace: asString(o.pace, "moderate"),
		texture: asString(o.texture, "clear"),
		energy: asString(o.energy, "moderate"),
		gender_presentation: asString(o.gender_presentation, "unspecified"),
		speaking_style: asString(o.speaking_style, "natural"),
		resonance: asString(o.resonance, "balanced"),
		clarity: asString(o.clarity, "clear")
	};
}
function normalizeAnalysis(raw, duration, catalog) {
	const fallbackId = catalog[0]?.id ?? "voice_01";
	const byId = new Map(catalog.map((v) => [v.id.toLowerCase(), v]));
	const byNative = new Map(catalog.map((v) => [v.nativeName.toLowerCase(), v]));
	function resolveVoice(id) {
		const key = id.trim().toLowerCase();
		return byId.get(key) ?? byNative.get(key);
	}
	const obj = raw ?? {};
	const storyRaw = obj.story ?? {};
	const story = {
		title: asString(storyRaw.title, "Untitled story"),
		genre: asString(storyRaw.genre, "drama"),
		mood: asString(storyRaw.mood, "serious"),
		time_period: storyRaw.time_period == null ? null : asString(storyRaw.time_period),
		environment: asString(storyRaw.environment, "unspecified"),
		atmosphere: asStringArray(storyRaw.atmosphere),
		summary: asString(storyRaw.summary, ""),
		language: asString(storyRaw.language, "en-US") || "en-US"
	};
	const speakers = (Array.isArray(obj.speakers) ? obj.speakers : []).map((item, index) => {
		const s = item ?? {};
		const importanceRaw = asString(s.importance, "supporting");
		const importance = IMPORTANCE_LEVELS.includes(importanceRaw) ? importanceRaw : "supporting";
		const speakerId = asString(s.speaker_id, `speaker_${String(index + 1).padStart(2, "0")}`);
		const voiceId = asString(s.recommended_voice_id, fallbackId);
		return {
			speaker_id: speakerId,
			display_name: asString(s.display_name, `Character ${index + 1}`),
			role: asString(s.role, "Character"),
			is_narrator: asBool(s.is_narrator),
			importance,
			original_voice: parseOriginalVoice(s.original_voice),
			personality: asStringArray(s.personality),
			emotional_style: asStringArray(s.emotional_style),
			story_context: asString(s.story_context, ""),
			relationships: asString(s.relationships, ""),
			recommended_voice_id: resolveVoice(voiceId)?.id ?? fallbackId,
			recommended_voice_profile: asString(s.recommended_voice_profile, ""),
			voice_reason: asString(s.voice_reason, "Selected to fit role, age, and scene mood.")
		};
	});
	if (speakers.length === 0) throw new StudioError("speaker_error");
	const known = new Set(speakers.map((s) => s.speaker_id));
	let segments = (Array.isArray(obj.segments) ? obj.segments : []).map((item, index) => {
		const s = item ?? {};
		const speakerId = asString(s.speaker_id, speakers[0]?.speaker_id ?? "speaker_01");
		let start = Math.max(0, asNumber(s.start, 0));
		let end = Math.max(start, asNumber(s.end, start + .4));
		if (duration > 0) {
			start = Math.min(start, duration);
			end = Math.min(end, duration);
		}
		return {
			id: asString(s.id, `seg_${String(index + 1).padStart(3, "0")}`),
			speaker_id: known.has(speakerId) ? speakerId : speakers[0]?.speaker_id ?? speakerId,
			start,
			end,
			text: asString(s.text, ""),
			emotion: asString(s.emotion, "calmness").toLowerCase(),
			emotion_intensity: parseIntensity(s.emotion_intensity),
			delivery_notes: asString(s.delivery_notes, ""),
			is_silence: asBool(s.is_silence) || asString(s.text).trim().length === 0
		};
	});
	segments = segments.filter((s) => s.end > s.start).sort((a, b) => a.start - b.start);
	if (segments.length === 0) throw new StudioError("speaker_error");
	const last = segments[segments.length - 1];
	if (last && duration > 0 && last.end < duration - .4) segments.push({
		id: "seg_tail_silence",
		speaker_id: speakers[0].speaker_id,
		start: last.end,
		end: duration,
		text: "",
		emotion: "calmness",
		emotion_intensity: "very_low",
		delivery_notes: "",
		is_silence: true
	});
	const uniqueSpeakers = enforceUniqueVoices(speakers, catalog);
	const narrator = uniqueSpeakers.find((s) => s.is_narrator)?.speaker_id ?? (typeof obj.narrator_id === "string" && known.has(obj.narrator_id) ? obj.narrator_id : null);
	return {
		story,
		speakers: uniqueSpeakers,
		segments,
		narrator_id: narrator,
		quality_notes: asStringArray(obj.quality_notes)
	};
}
var GEMINI_API_BASE = "https://generativelanguage.googleapis.com";
var GEMINI_ANALYSIS_MODELS = [
	"gemini-2.5-flash",
	"gemini-3.8-flash",
	"gemini-2.0-flash",
	"gemini-2.5-pro",
	"gemini-2.0-flash-001",
	"gemini-1.5-flash"
];
var GEMINI_TTS_MODELS = [
	"gemini-3.1-flash-tts-preview",
	"gemini-2.5-flash-preview-tts",
	"gemini-2.5-pro-preview-tts"
];
var OPENAI_CHAT_MODELS = [
	"gpt-4.1",
	"gpt-4o",
	"gpt-4o-mini",
	"o4-mini",
	"gpt-4.1-mini"
];
var OPENAI_STT_MODELS = [
	"gpt-4o-transcribe",
	"gpt-4o-mini-transcribe",
	"whisper-1"
];
var OPENAI_TTS_MODELS = [
	"gpt-4o-mini-tts",
	"gpt-4o-tts",
	"tts-1-hd",
	"tts-1"
];
var XAI_CHAT_MODELS = [
	"grok-4.6",
	"grok-4",
	"grok-3",
	"grok-2"
];
function sleep$1(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function readError(res) {
	let text = "";
	try {
		text = await res.text();
	} catch {
		text = "";
	}
	return mapProviderHttpError(res.status, text);
}
async function forward(url, init) {
	const headers = new Headers(init.headers);
	headers.set("x-studio-target", url);
	headers.set("x-studio-method", init.method ?? "GET");
	return fetch("/api/studio/forward", {
		method: "POST",
		headers,
		body: init.body
	});
}
async function providerFetch(url, init, retries = 1) {
	let last = null;
	for (let i = 0; i <= retries; i += 1) {
		let res;
		try {
			try {
				res = await fetch(url, init);
			} catch {
				res = await forward(url, init);
			}
		} catch {
			last = new StudioError("network_error");
			if (i < retries) {
				await sleep$1(400 * (i + 1));
				continue;
			}
			throw last;
		}
		if (res.ok) return res;
		const err = await readError(res);
		last = err;
		if (err.code === "invalid_api_key") throw err;
		if (err.code === "network_error") throw err;
		if (err.code === "quota_exceeded" && i < retries) {
			await sleep$1(800 * (i + 1));
			continue;
		}
		if (res.status >= 500 && i < retries) {
			await sleep$1(400 * (i + 1));
			continue;
		}
		throw err;
	}
	throw last ?? new StudioError("general_error");
}
function pickPreferred(available, preferred) {
	for (const name of preferred) {
		const hit = available.find((m) => m === name || m.startsWith(name) || m.includes(name));
		if (hit) return hit;
	}
}
async function xhrUpload(url, hdrs, body, onProgress) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		xhr.open("POST", url);
		for (const [key, value] of Object.entries(hdrs)) xhr.setRequestHeader(key, value);
		xhr.upload.onprogress = (event) => {
			if (!onProgress) return;
			const total = event.lengthComputable ? event.total : body.size;
			onProgress(event.loaded, total || body.size);
		};
		xhr.onload = () => resolve({
			status: xhr.status,
			text: xhr.responseText
		});
		xhr.onerror = () => {
			(async () => {
				try {
					const res = await forward(url, {
						method: "POST",
						headers: hdrs,
						body
					});
					resolve({
						status: res.status,
						text: await res.text()
					});
				} catch {
					reject(new StudioError("audio_error", "Upload was interrupted."));
				}
			})();
		};
		xhr.send(body);
	});
}
var cache$2 = {};
var geminiOrigin = GEMINI_API_BASE;
function useGeminiBase(baseUrl) {
	if (!baseUrl) {
		geminiOrigin = GEMINI_API_BASE;
		return;
	}
	try {
		geminiOrigin = new URL(baseUrl).origin;
	} catch {
		geminiOrigin = GEMINI_API_BASE;
	}
}
function headers(apiKey, extra) {
	return {
		"x-goog-api-key": apiKey.trim(),
		...extra
	};
}
async function geminiFetch(apiKey, url, init, retries = 2) {
	return providerFetch(url, {
		...init,
		headers: {
			...headers(apiKey),
			...init.headers ?? {}
		}
	}, retries);
}
async function uploadGeminiFile(apiKey, file, mimeType, displayName, onProgress) {
	const start = await geminiFetch(apiKey, `${geminiOrigin}/upload/v1beta/files`, {
		method: "POST",
		headers: {
			"X-Goog-Upload-Protocol": "resumable",
			"X-Goog-Upload-Command": "start",
			"X-Goog-Upload-Header-Content-Length": String(file.size),
			"X-Goog-Upload-Header-Content-Type": mimeType,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({ file: { display_name: displayName } })
	});
	const uploadUrl = start.headers.get("x-goog-upload-url") ?? start.headers.get("X-Goog-Upload-URL");
	if (!uploadUrl) {
		const maybe = await start.json().catch(() => null);
		if (maybe?.file?.uri) {
			onProgress?.(file.size, file.size);
			return {
				uri: maybe.file.uri,
				mimeType: maybe.file.mimeType ?? mimeType,
				name: maybe.file.name ?? displayName
			};
		}
		throw new StudioError("audio_error", "Upload session could not be created.");
	}
	const uploadHeaders = {
		"x-goog-api-key": apiKey,
		"X-Goog-Upload-Offset": "0",
		"X-Goog-Upload-Command": "upload, finalize"
	};
	let text;
	let status;
	if (typeof XMLHttpRequest !== "undefined") {
		const posted = await xhrUpload(uploadUrl, uploadHeaders, file, onProgress);
		status = posted.status;
		text = posted.text;
	} else {
		const upload = await providerFetch(uploadUrl, {
			method: "POST",
			headers: {
				...uploadHeaders,
				"Content-Length": String(file.size)
			},
			body: file
		});
		status = upload.status;
		text = await upload.text();
	}
	if (status < 200 || status >= 300) throw mapProviderHttpError(status, text);
	let json;
	try {
		json = JSON.parse(text || "{}");
	} catch {
		throw new StudioError("audio_error", "Upload did not return a file URI.");
	}
	const uri = json.file?.uri;
	if (!uri) throw new StudioError("audio_error", "Upload did not return a file URI.");
	onProgress?.(file.size, file.size);
	return {
		uri,
		mimeType: json.file?.mimeType ?? mimeType,
		name: json.file?.name ?? displayName
	};
}
async function deleteGeminiFile(apiKey, nameOrUri) {
	const name = nameOrUri.includes("/files/") ? nameOrUri.slice(nameOrUri.indexOf("files/")) : nameOrUri.startsWith("files/") ? nameOrUri : `files/${nameOrUri}`;
	try {
		await geminiFetch(apiKey, `${geminiOrigin}/v1beta/${name}`, { method: "DELETE" }, 0);
	} catch {}
}
async function generateContent(apiKey, model, body) {
	return await (await geminiFetch(apiKey, `${geminiOrigin}/v1beta/models/${model}:generateContent`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(body)
	})).json();
}
function textFromResponse(json) {
	return (json.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? "").join("").trim();
}
function audioFromResponse(json) {
	const parts = json.candidates?.[0]?.content?.parts ?? [];
	for (const part of parts) {
		const inline = part.inlineData ?? part.inline_data;
		if (!inline?.data) continue;
		const mimeType = "mimeType" in inline ? inline.mimeType : "mime_type" in inline ? inline.mime_type : void 0;
		return {
			data: inline.data,
			mimeType
		};
	}
	throw new StudioError("voice_engine_error");
}
async function withModels(apiKey, preferred, list, run, cacheKey) {
	const models = [preferred, ...list].filter((m, i, arr) => !!m && arr.indexOf(m) === i);
	let last;
	for (const model of models) try {
		const result = await run(model);
		cache$2[cacheKey] = model;
		return result;
	} catch (err) {
		last = err;
		if (err instanceof StudioError && err.code === "invalid_api_key") throw err;
		if (err instanceof StudioError && err.code === "quota_exceeded") throw err;
	}
	throw last instanceof StudioError ? last : new StudioError("general_error");
}
async function analyzeStoryAudio(options) {
	const { apiKey, duration, catalog } = options;
	const prompt = analysisPrompt(duration, catalogPromptBlock(catalog), "audio");
	const audioPart = options.file ? { file_data: {
		file_uri: options.file.uri,
		mime_type: options.file.mimeType
	} } : options.inlineBase64 ? { inline_data: {
		mime_type: options.inlineMimeType ?? "audio/wav",
		data: options.inlineBase64
	} } : null;
	if (!audioPart) throw new StudioError("audio_error");
	const text = textFromResponse(await withModels(apiKey, cache$2.analysisModel, GEMINI_ANALYSIS_MODELS, async (model) => generateContent(apiKey, model, {
		contents: [{
			role: "user",
			parts: [{ text: prompt }, audioPart]
		}],
		generationConfig: {
			temperature: .2,
			responseMimeType: "application/json",
			maxOutputTokens: 65536
		}
	}), "analysisModel"));
	if (!text) throw new StudioError("speaker_error");
	return normalizeAnalysis(extractJson(text), duration, catalog);
}
async function analyzeWithGemini(options) {
	useGeminiBase(options.baseUrl);
	let fileName = null;
	try {
		const uploaded = await uploadGeminiFile(options.apiKey, options.blob, options.mimeType, options.displayName || "story-audio", options.onProgress);
		fileName = uploaded.name;
		return await analyzeStoryAudio({
			apiKey: options.apiKey,
			duration: options.duration,
			catalog: options.catalog,
			file: uploaded
		});
	} catch (err) {
		if (err instanceof StudioError && err.code === "invalid_api_key") throw err;
		if (options.blob.size > 38e5) throw err;
		const { encodeBase64 } = await import("./audio-E9mWk4ew.mjs");
		return analyzeStoryAudio({
			apiKey: options.apiKey,
			duration: options.duration,
			catalog: options.catalog,
			inlineBase64: encodeBase64(await options.blob.arrayBuffer()),
			inlineMimeType: options.mimeType
		});
	} finally {
		if (fileName) await deleteGeminiFile(options.apiKey, fileName);
	}
}
async function synthesizeSpeech(options) {
	useGeminiBase(options.baseUrl);
	const { apiKey, text, voiceName, languageCode } = options;
	if (!text.trim()) throw new StudioError("voice_engine_error");
	const audio = audioFromResponse(await withModels(apiKey, cache$2.ttsModel, GEMINI_TTS_MODELS, async (model) => generateContent(apiKey, model, {
		contents: [{
			role: "user",
			parts: [{ text }]
		}],
		generationConfig: {
			responseModalities: ["AUDIO"],
			speechConfig: {
				voiceConfig: { prebuiltVoiceConfig: { voiceName } },
				...languageCode ? { languageCode } : {}
			}
		}
	}), "ttsModel"));
	return {
		...wrapAudioBytes(audio.data, audio.mimeType),
		mimeType: "audio/wav"
	};
}
var ANALYSIS_MODEL = /whisper|transcribe|speech-to-text|gpt-4o|gpt-4\.|gpt-4-|o4-|grok|claude|gemini(?!.*tts)|audio/i;
var GENERATION_MODEL = /tts|text-to-speech|speech|eleven|voice/i;
var CHAT_MODEL = /gpt|grok|claude|gemini|command|llama|mistral|qwen|deepseek|chat/i;
function normalizeApiUrl(raw) {
	const trimmed = raw.trim();
	if (!trimmed) throw new StudioError("request_error", "Enter the API website URL.");
	const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
	let url;
	try {
		url = new URL(withProto);
	} catch {
		throw new StudioError("request_error", "That API website URL is not valid.");
	}
	if (url.protocol !== "https:") throw new StudioError("request_error", "Use an https:// API address.");
	if (url.username || url.password) throw new StudioError("request_error", "Do not put the API key in the URL.");
	url.searchParams.delete("key");
	url.searchParams.delete("api_key");
	url.searchParams.delete("apiKey");
	url.hash = "";
	return url.toString().replace(/\/+$/, "");
}
function hostOf(baseUrl) {
	try {
		return new URL(baseUrl).hostname.toLowerCase();
	} catch {
		return "";
	}
}
function guessFamily(host, models) {
	if (host.includes("googleapis") || host.includes("generativelanguage") || models.some((m) => m.startsWith("gemini"))) return "gemini";
	if (host.includes("elevenlabs")) return "elevenlabs";
	if (host.includes("x.ai") || models.some((m) => m.toLowerCase().includes("grok"))) return "xai";
	if (host.includes("openai.com")) return "openai";
	return "compat";
}
function authHeaders(style, apiKey) {
	const key = apiKey.trim();
	if (style === "goog") return { "x-goog-api-key": key };
	if (style === "xi") return { "xi-api-key": key };
	if (style === "x-api-key") return { "x-api-key": key };
	return { Authorization: `Bearer ${key}` };
}
function stylesForHost(host) {
	if (host.includes("googleapis") || host.includes("generativelanguage")) return [
		"goog",
		"bearer",
		"x-api-key"
	];
	if (host.includes("elevenlabs")) return [
		"xi",
		"bearer",
		"x-api-key"
	];
	return [
		"bearer",
		"x-api-key",
		"xi",
		"goog"
	];
}
function candidateUrls(base) {
	const url = new URL(base);
	const origin = url.origin;
	const path = url.pathname.replace(/\/+$/, "");
	const out = /* @__PURE__ */ new Set();
	const add = (value) => out.add(value.replace(/\/+$/, ""));
	add(base);
	if (!/\/models$/i.test(path)) {
		add(`${base}/models`);
		add(`${base}/v1beta/models`);
		add(`${base}/v1/models`);
	}
	add(`${origin}/v1/models`);
	add(`${origin}/v1beta/models`);
	add(`${origin}/models`);
	add(`${origin}/v1/voices`);
	add(`${origin}/v1/voices/settings`);
	add(`${base}/voices`);
	add(`${origin}/v1beta/openai/models`);
	return [...out];
}
function parseModels(json) {
	if (!json || typeof json !== "object") return [];
	const obj = json;
	const names = [];
	const push = (value) => {
		if (typeof value === "string" && value.trim()) names.push(value.replace(/^models\//, ""));
	};
	if (Array.isArray(obj.data)) {
		for (const item of obj.data) if (item && typeof item === "object" && "id" in item) push(item.id);
	}
	if (Array.isArray(obj.models)) {
		for (const item of obj.models) if (typeof item === "string") push(item);
		else if (item && typeof item === "object" && "name" in item) push(item.name);
	}
	if (Array.isArray(obj.voices)) {
		for (const item of obj.voices) if (item && typeof item === "object") {
			const v = item;
			push(v.voice_id ?? v.name);
		}
	}
	return [...new Set(names)];
}
async function tryGet(url, style, apiKey) {
	try {
		const res = await providerFetch(url, {
			method: "GET",
			headers: authHeaders(style, apiKey)
		}, 0);
		const json = await res.json().catch(() => null);
		const models = parseModels(json);
		if (res.ok) return {
			url,
			style,
			models,
			json
		};
		return "skip";
	} catch (err) {
		if (err instanceof StudioError && err.code === "invalid_api_key") return "invalid";
		if (err instanceof StudioError && err.code === "quota_exceeded") throw err;
		return "skip";
	}
}
function analysisUseful(family, models, hitUrl) {
	if (family === "elevenlabs") return false;
	if (family === "gemini") return models.some((m) => !/tts/i.test(m) && /gemini|flash|pro|audio/i.test(m));
	if (models.some((m) => ANALYSIS_MODEL.test(m))) return true;
	if (models.some((m) => /whisper|transcribe/i.test(m))) return true;
	if (family === "xai" && models.some((m) => /grok/i.test(m))) return true;
	if (models.some((m) => CHAT_MODEL.test(m)) && /audio|transcri/i.test(hitUrl)) return true;
	return false;
}
function generationUseful(family, models) {
	if (family === "elevenlabs") return models.length > 0;
	if (family === "gemini") return models.some((m) => /tts/i.test(m));
	if (models.some((m) => GENERATION_MODEL.test(m))) return true;
	if (family === "xai") return true;
	return false;
}
function pickAnalysisModel(family, models) {
	if (family === "gemini") return pickPreferred(models, GEMINI_ANALYSIS_MODELS) ?? models.find((m) => /gemini/i.test(m) && !/tts/i.test(m));
	if (family === "xai") return pickPreferred(models, XAI_CHAT_MODELS) ?? models.find((m) => /grok/i.test(m));
	const stt = pickPreferred(models, OPENAI_STT_MODELS) ?? models.find((m) => /whisper|transcribe/i.test(m));
	const chat = pickPreferred(models, OPENAI_CHAT_MODELS) ?? models.find((m) => CHAT_MODEL.test(m));
	if (stt && chat) return `${stt} · ${chat}`;
	return chat ?? stt ?? models[0];
}
function pickGenerationModel(family, models) {
	if (family === "gemini") return pickPreferred(models, GEMINI_TTS_MODELS) ?? models.find((m) => /tts/i.test(m));
	if (family === "elevenlabs") return models.length ? `${models.length} voices` : void 0;
	if (family === "xai") return "xai-tts";
	return pickPreferred(models, OPENAI_TTS_MODELS) ?? models.find((m) => GENERATION_MODEL.test(m)) ?? models[0];
}
function endpointBase(hitUrl, family) {
	const url = new URL(hitUrl);
	if (family === "gemini") return url.origin;
	let path = url.pathname.replace(/\/+$/, "");
	path = path.replace(/\/(models|voices)(\/.*)?$/i, "");
	if (path === "/v1beta") return url.origin;
	return `${url.origin}${path}`.replace(/\/+$/, "") || url.origin;
}
async function probeApi(options) {
	const key = options.apiKey.trim();
	if (key.length < 8) throw new StudioError("invalid_api_key");
	const base = normalizeApiUrl(options.url);
	const host = hostOf(base);
	const styles = stylesForHost(host);
	const urls = candidateUrls(base);
	let sawInvalid = false;
	let hit = null;
	for (const style of styles) {
		for (const url of urls) {
			const result = await tryGet(url, style, key);
			if (result === "invalid") {
				sawInvalid = true;
				continue;
			}
			if (result === "skip") continue;
			if (result.models.length > 0 || result.json && typeof result.json === "object") {
				hit = result;
				break;
			}
		}
		if (hit) break;
	}
	if (!hit) {
		if (sawInvalid) throw new StudioError("invalid_api_key");
		throw new StudioError("network_error");
	}
	const family = guessFamily(host, hit.models);
	const resolvedBase = endpointBase(hit.url, family);
	const usefulA = analysisUseful(family, hit.models, hit.url);
	const usefulG = generationUseful(family, hit.models);
	const analysisModel = pickAnalysisModel(family, hit.models);
	const generationModel = pickGenerationModel(family, hit.models);
	if (options.purpose === "analysis" && !usefulA) throw new StudioError("model_unavailable", "This API key works, but the website is not useful for analyzing multi-speaker audio.");
	if (options.purpose === "generation" && !usefulG) throw new StudioError("model_unavailable", "This API key works, but the website is not useful for generating character voices.");
	return {
		family,
		baseUrl: resolvedBase,
		authStyle: hit.style,
		models: hit.models,
		analysisUseful: usefulA,
		generationUseful: usefulG,
		analysisModel,
		generationModel,
		label: host || family
	};
}
var cache$1 = {};
function root$2(baseUrl) {
	return (baseUrl || "https://api.openai.com/v1").replace(/\/+$/, "");
}
function bucket(baseUrl) {
	const key = root$2(baseUrl);
	cache$1[key] ??= {};
	return cache$1[key];
}
function auth$2(apiKey) {
	return { Authorization: `Bearer ${apiKey.trim()}` };
}
async function transcribe$1(apiKey, blob, baseUrl, onProgress) {
	onProgress?.(1, blob.size);
	const form = new FormData();
	form.append("file", blob, "story-audio.wav");
	form.append("model", bucket(baseUrl).stt ?? "whisper-1");
	form.append("response_format", "verbose_json");
	form.append("timestamp_granularities[]", "segment");
	const res = await providerFetch(`${root$2(baseUrl)}/audio/transcriptions`, {
		method: "POST",
		headers: auth$2(apiKey),
		body: form
	});
	onProgress?.(blob.size, blob.size);
	return await res.json();
}
async function analyzeWithOpenAi(options) {
	const transcript = await transcribe$1(options.apiKey, options.blob, options.baseUrl, options.onProgress);
	const lines = transcript.segments?.map((s) => `[${Number(s.start ?? 0).toFixed(2)}–${Number(s.end ?? 0).toFixed(2)}] ${s.text ?? ""}`).join("\n") ?? transcript.text ?? "";
	if (!lines.trim()) throw new StudioError("speaker_error");
	const model = bucket(options.baseUrl).chat ?? "gpt-4o";
	const text = (await (await providerFetch(`${root$2(options.baseUrl)}/chat/completions`, {
		method: "POST",
		headers: {
			...auth$2(options.apiKey),
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			model,
			temperature: .2,
			response_format: { type: "json_object" },
			messages: [{
				role: "system",
				content: analysisPrompt(options.duration, catalogPromptBlock(options.catalog), "transcript")
			}, {
				role: "user",
				content: `Transcript with timestamps:\n${lines}`
			}]
		})
	})).json()).choices?.[0]?.message?.content ?? "";
	if (!text) throw new StudioError("speaker_error");
	return normalizeAnalysis(extractJson(text), options.duration, options.catalog);
}
async function synthesizeOpenAi(options) {
	const model = bucket(options.baseUrl).tts ?? "gpt-4o-mini-tts";
	const usesInstructions = model.includes("gpt-4o");
	const body = {
		model,
		voice: options.voiceName,
		input: usesInstructions ? options.text : `${options.instructions}\n\n${options.text}`,
		response_format: "wav"
	};
	if (usesInstructions) body.instructions = options.instructions;
	const res = await providerFetch(`${root$2(options.baseUrl)}/audio/speech`, {
		method: "POST",
		headers: {
			...auth$2(options.apiKey),
			"Content-Type": "application/json"
		},
		body: JSON.stringify(body)
	});
	return encodedAudioToWav(await res.arrayBuffer(), res.headers.get("content-type") ?? "audio/wav");
}
var cache = {};
function root$1(baseUrl) {
	return (baseUrl || "https://api.x.ai/v1").replace(/\/+$/, "");
}
function auth$1(apiKey) {
	return { Authorization: `Bearer ${apiKey.trim()}` };
}
async function transcribe(apiKey, blob, baseUrl, onProgress) {
	onProgress?.(1, blob.size);
	const form = new FormData();
	form.append("file", blob, "story-audio.wav");
	form.append("model", "grok-4");
	const endpoints = [`${root$1(baseUrl)}/audio/transcriptions`, `${root$1(baseUrl)}/stt`];
	let last;
	for (const url of endpoints) try {
		const res = await providerFetch(url, {
			method: "POST",
			headers: auth$1(apiKey),
			body: form
		});
		onProgress?.(blob.size, blob.size);
		return await res.json();
	} catch (err) {
		last = err;
	}
	throw last instanceof StudioError ? last : new StudioError("audio_error");
}
function formatTranscript(raw) {
	if (raw.segments?.length) return raw.segments.map((s) => `[${Number(s.start ?? 0).toFixed(2)}–${Number(s.end ?? 0).toFixed(2)}] ${s.speaker ? s.speaker + ": " : ""}${s.text ?? ""}`).join("\n");
	if (raw.words?.length) return raw.words.map((w) => `${w.speaker_id ?? "spk"}:${w.word ?? ""}`).join(" ");
	return raw.text ?? raw.transcript ?? "";
}
async function analyzeWithXai(options) {
	const lines = formatTranscript(await transcribe(options.apiKey, options.blob, options.baseUrl, options.onProgress));
	if (!lines.trim()) throw new StudioError("speaker_error");
	const model = cache.chat ?? "grok-4";
	const text = (await (await providerFetch(`${root$1(options.baseUrl)}/chat/completions`, {
		method: "POST",
		headers: {
			...auth$1(options.apiKey),
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			model,
			temperature: .2,
			messages: [{
				role: "system",
				content: analysisPrompt(options.duration, catalogPromptBlock(options.catalog), "transcript")
			}, {
				role: "user",
				content: `Transcript with timestamps:\n${lines}`
			}]
		})
	})).json()).choices?.[0]?.message?.content ?? "";
	if (!text) throw new StudioError("speaker_error");
	return normalizeAnalysis(extractJson(text), options.duration, options.catalog);
}
async function synthesizeXai(options) {
	const res = await providerFetch(`${root$1(options.baseUrl)}/tts`, {
		method: "POST",
		headers: {
			...auth$1(options.apiKey),
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			text: options.text,
			voice_id: options.voiceName,
			language: options.languageCode ?? "en"
		})
	});
	return encodedAudioToWav(await res.arrayBuffer(), res.headers.get("content-type") ?? "audio/mpeg");
}
function root(baseUrl) {
	const raw = (baseUrl || "https://api.elevenlabs.io/v1").replace(/\/+$/, "");
	if (/\/v1$/i.test(raw)) return raw;
	try {
		const url = new URL(raw);
		if (url.pathname === "" || url.pathname === "/") return `${url.origin}/v1`;
	} catch {}
	return raw;
}
function auth(apiKey) {
	return { "xi-api-key": apiKey.trim() };
}
async function synthesizeElevenLabs(options) {
	const res = await providerFetch(`${root(options.baseUrl)}/text-to-speech/${encodeURIComponent(options.voiceName)}?output_format=pcm_24000`, {
		method: "POST",
		headers: {
			...auth(options.apiKey),
			"Content-Type": "application/json",
			Accept: "audio/mpeg"
		},
		body: JSON.stringify({
			text: options.text,
			model_id: "eleven_multilingual_v2",
			voice_settings: {
				stability: .4,
				similarity_boost: .75,
				style: .45,
				use_speaker_boost: true
			}
		})
	});
	const data = await res.arrayBuffer();
	const type = res.headers.get("content-type") ?? "audio/mpeg";
	if (type.includes("pcm") || type.includes("octet")) {
		const { pcm16ToWav } = await import("./audio-E9mWk4ew.mjs");
		return {
			wavBytes: pcm16ToWav(data, 24e3, 1),
			sampleRate: 24e3
		};
	}
	return encodedAudioToWav(data, type);
}
async function validateAnalysisKey(url, apiKey) {
	return probeApi({
		url,
		apiKey,
		purpose: "analysis"
	});
}
async function validateGenerationKey(url, apiKey) {
	return probeApi({
		url,
		apiKey,
		purpose: "generation"
	});
}
async function analyzeAudio(options) {
	const { family, baseUrl } = options;
	if (family === "gemini") return analyzeWithGemini({
		...options,
		baseUrl
	});
	if (family === "xai") return analyzeWithXai({
		...options,
		baseUrl
	});
	if (family === "elevenlabs") throw new StudioError("model_unavailable", "This API is not useful for analyzing multi-speaker audio.");
	return analyzeWithOpenAi({
		...options,
		baseUrl
	});
}
async function synthesizeVoice(options) {
	const spoken = options.text.trim();
	if (!spoken) throw new StudioError("voice_engine_error");
	if (options.family === "gemini") return synthesizeSpeech({
		apiKey: options.apiKey,
		text: `${options.instructions} ${spoken}`.trim(),
		voiceName: options.voiceName,
		languageCode: options.languageCode,
		baseUrl: options.baseUrl
	});
	if (options.family === "openai" || options.family === "compat") return synthesizeOpenAi({
		apiKey: options.apiKey,
		text: spoken,
		instructions: options.instructions,
		voiceName: options.voiceName,
		baseUrl: options.baseUrl
	});
	if (options.family === "xai") return synthesizeXai({
		apiKey: options.apiKey,
		text: spoken,
		voiceName: options.voiceName,
		languageCode: options.languageCode,
		baseUrl: options.baseUrl
	});
	return synthesizeElevenLabs({
		apiKey: options.apiKey,
		text: spoken,
		instructions: options.instructions,
		voiceName: options.voiceName,
		baseUrl: options.baseUrl
	});
}
function generationCatalog(family) {
	return catalogFor(family);
}
var SAMPLE_SCENE = [
	{
		speaker: "narrator",
		voice: "Charon",
		text: "The rain had not stopped for three days. In the doorway of the old house, two people who once shared a life now shared only the weather.",
		direction: "Narrate calmly, warm and descriptive, with a quiet storytelling cadence:"
	},
	{
		speaker: "old_man",
		voice: "Algenib",
		text: "You shouldn't have come back here.",
		direction: "Say angrily, forceful but still human:"
	},
	{
		speaker: "young_woman",
		voice: "Leda",
		text: "I had no choice. The letter said you were dying.",
		direction: "Say with restrained sadness, slightly quieter:"
	},
	{
		speaker: "old_man",
		voice: "Algenib",
		text: "Dying? I wanted to see if you would still listen.",
		direction: "Say more calmly, tired and thoughtful:"
	},
	{
		speaker: "young_woman",
		voice: "Leda",
		text: "Then look at me. I'm here.",
		direction: "Say with fragile hope, voice almost breaking:"
	},
	{
		speaker: "narrator",
		voice: "Charon",
		text: "Neither of them spoke for a long while. The rain kept the time.",
		direction: "Narrate quietly, leaving space around the words:"
	}
];
function runQualityChecks(analysis, clips, mixDuration) {
	const spoken = analysis.segments.filter((s) => !s.is_silence && s.text.trim());
	const voices = new Set(analysis.speakers.map((s) => s.recommended_voice_id));
	const missing = spoken.filter((s) => !clips[s.id]);
	const empty = spoken.filter((s) => (clips[s.id]?.duration ?? 0) < .05);
	const durationDelta = Math.abs(mixDuration - (analysis.segments.at(-1)?.end ?? mixDuration));
	return [
		{
			id: "voices",
			label: "Each speaker has a distinct assigned voice",
			passed: voices.size === analysis.speakers.length && analysis.speakers.length > 0,
			detail: voices.size === analysis.speakers.length ? `${voices.size} unique voices for ${analysis.speakers.length} speakers` : "Two characters share a voice — recast before export"
		},
		{
			id: "consistency",
			label: "Character voices stay consistent",
			passed: true,
			detail: "The same speaker keeps the same catalog voice across every scene"
		},
		{
			id: "coverage",
			label: "No missing dialogue",
			passed: missing.length === 0,
			detail: missing.length === 0 ? "All spoken segments were generated" : `${missing.length} segment(s) failed`
		},
		{
			id: "emotion",
			label: "Emotional delivery present",
			passed: spoken.every((s) => s.emotion && s.emotion.toLowerCase() !== "neutral" || s.delivery_notes.length > 0) || spoken.length === 0,
			detail: "Each line carries an emotion and a performance note from the analysis"
		},
		{
			id: "robotic",
			label: "No empty or collapsed takes",
			passed: empty.length === 0,
			detail: empty.length === 0 ? "Every take has audible length" : `${empty.length} take(s) are too short — retry those segments`
		},
		{
			id: "timeline",
			label: "Timeline stays in original order",
			passed: durationDelta < 1.5,
			detail: `Mix length ${mixDuration.toFixed(1)}s vs story ${(analysis.segments.at(-1)?.end ?? 0).toFixed(1)}s`
		}
	];
}
var MAX_AUDIO_BYTES = 52428800;
function formatMegabytes(bytes) {
	const mb = Math.max(0, bytes) / 1048576;
	if (mb === 0) return "0 MB";
	if (mb < .1) return `${mb.toFixed(2)} MB`;
	if (mb < 10) return `${mb.toFixed(2)} MB`;
	return `${mb.toFixed(1)} MB`;
}
function transferPercent(loaded, total) {
	if (!Number.isFinite(loaded) || !Number.isFinite(total) || total <= 0) return 0;
	return Math.max(0, Math.min(100, Math.round(loaded / total * 100)));
}
var stageTicker = null;
function stopStageTicker() {
	if (stageTicker) {
		clearInterval(stageTicker);
		stageTicker = null;
	}
}
function startStageTicker(id, detail) {
	stopStageTicker();
	const started = Date.now();
	const { setStagePercent, markStage } = useStudio.getState();
	markStage(id, "active", detail);
	setStagePercent(id, 6, detail);
	stageTicker = setInterval(() => {
		const stage = useStudio.getState().pipeline.find((s) => s.id === id);
		if (!stage || stage.status !== "active") {
			stopStageTicker();
			return;
		}
		const elapsed = Date.now() - started;
		const percent = Math.min(92, 6 + Math.round(86 * (1 - Math.exp(-elapsed / 7e3))));
		useStudio.getState().setStagePercent(id, percent, detail);
	}, 180);
}
function reportTransfer(loaded, total, label) {
	const size = total > 0 ? total : MAX_AUDIO_BYTES;
	useStudio.getState().setTransfer({
		loaded,
		total: size,
		percent: transferPercent(loaded, size),
		label
	});
}
function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
async function finishStageWalk(ids) {
	for (const id of ids) {
		startStageTicker(id);
		await sleep(220);
		stopStageTicker();
		useStudio.getState().markStage(id, "done");
	}
}
function readBlobProgress(blob, onProgress) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		onProgress(0, blob.size);
		reader.onprogress = (event) => {
			const total = event.lengthComputable ? event.total : blob.size;
			onProgress(event.loaded, total);
		};
		reader.onload = () => {
			onProgress(blob.size, blob.size);
			resolve(reader.result);
		};
		reader.onerror = () => reject(new StudioError("audio_error"));
		reader.readAsArrayBuffer(blob);
	});
}
async function mapPool(items, limit, worker) {
	const out = new Array(items.length);
	let cursor = 0;
	async function run() {
		while (cursor < items.length) {
			const i = cursor;
			cursor += 1;
			const item = items[i];
			if (item === void 0) continue;
			out[i] = await worker(item, i);
		}
	}
	const n = Math.min(limit, items.length);
	await Promise.all(Array.from({ length: n }, () => run()));
	return out;
}
function classifyKeyError(err) {
	if (!(err instanceof StudioError)) return {
		status: "network_error",
		message: "⚠ Unable to connect to the selected AI provider."
	};
	if (err.code === "quota_exceeded") return {
		status: "quota",
		message: err.message
	};
	if (err.code === "model_unavailable") return {
		status: "model_error",
		message: err.message
	};
	if (err.code === "network_error") return {
		status: "network_error",
		message: err.message
	};
	if (err.code === "server_error") return {
		status: "server_error",
		message: err.message
	};
	if (err.code === "invalid_api_key") return {
		status: "invalid",
		message: err.message
	};
	if (err.code === "request_error") return {
		status: "invalid",
		message: err.message
	};
	return {
		status: "server_error",
		message: err.message
	};
}
async function verifyAnalysisKey() {
	const { analysisKey, analysisUrl, setAnalysisStatus, setAnalysisModel, setAnalysisFamily } = useStudio.getState();
	if (!analysisKey.trim() || !analysisUrl.trim() || useStudio.getState().analysisStatus === "testing") return;
	setAnalysisStatus("testing", "Validating…");
	try {
		const result = await validateAnalysisKey(analysisUrl, analysisKey);
		setAnalysisFamily(result.family);
		setAnalysisModel(result.analysisModel ?? result.label);
		setAnalysisStatus("valid", "This API is valid and useful for audio analysis.");
	} catch (err) {
		setAnalysisModel(null);
		setAnalysisFamily(null);
		const mapped = classifyKeyError(err);
		if (mapped.status === "invalid") {
			setAnalysisStatus("invalid", mapped.message.includes("URL") ? mapped.message : "The audio analysis API key could not be authenticated.");
			return;
		}
		if (mapped.status === "quota") {
			setAnalysisStatus("quota", "⚠ Analysis API quota is unavailable.");
			return;
		}
		if (mapped.status === "model_error") {
			setAnalysisStatus("model_error", "⚠ This API is valid, but it is not useful for analyzing multi-speaker audio.");
			return;
		}
		if (mapped.status === "network_error") {
			setAnalysisStatus("network_error", "⚠ Unable to connect to the selected AI provider.");
			return;
		}
		setAnalysisStatus("server_error", "⚠ The selected AI provider is temporarily unavailable.");
	}
}
async function verifyGenerationKey() {
	const { generationKey, generationUrl, setGenerationStatus, setGenerationModel, setGenerationFamily } = useStudio.getState();
	if (!generationKey.trim() || !generationUrl.trim() || useStudio.getState().generationStatus === "testing") return;
	setGenerationStatus("testing", "Validating…");
	try {
		const result = await validateGenerationKey(generationUrl, generationKey);
		setGenerationFamily(result.family);
		setGenerationModel(result.generationModel ?? result.label);
		setGenerationStatus("valid", "This API is valid and useful for character voice generation.");
	} catch (err) {
		setGenerationModel(null);
		setGenerationFamily(null);
		const mapped = classifyKeyError(err);
		if (mapped.status === "invalid") {
			setGenerationStatus("invalid", mapped.message.includes("URL") ? mapped.message : "The audio generation API key could not be authenticated.");
			return;
		}
		if (mapped.status === "quota") {
			setGenerationStatus("quota", "⚠ Audio Generation API quota is unavailable.");
			return;
		}
		if (mapped.status === "model_error") {
			setGenerationStatus("model_error", "⚠ This API is valid, but it is not useful for generating character voices.");
			return;
		}
		if (mapped.status === "network_error") {
			setGenerationStatus("network_error", "⚠ Unable to connect to the selected AI provider.");
			return;
		}
		setGenerationStatus("server_error", "⚠ The selected AI provider is temporarily unavailable.");
	}
}
function keysReady() {
	const s = useStudio.getState();
	return s.analysisStatus === "valid" && s.generationStatus === "valid" && s.analysisKey.trim().length > 0 && s.generationKey.trim().length > 0 && s.analysisUrl.trim().length > 0 && s.generationUrl.trim().length > 0 && !!s.analysisFamily && !!s.generationFamily;
}
async function runAnalysis() {
	const { analysisFamily, analysisUrl, analysisKey, generationFamily, original, setBusy, setError, resetPipeline, markStage, setAnalysis, setTransfer, analysisModel } = useStudio.getState();
	if (!original) throw new StudioError("audio_error");
	if (!keysReady() || !analysisFamily || !generationFamily) throw new StudioError("invalid_api_key");
	const analysisLabel = familyLabel(analysisFamily, "your analysis API");
	setBusy(true, "Analyzing speakers, characters, and story…");
	setError(null);
	resetPipeline();
	try {
		markStage("reading", "active");
		startStageTicker("reading", "Reading the recording…");
		reportTransfer(0, original.size, "Reading audio");
		const prepared = await prepareAnalysisAudio(await fetch(original.objectUrl).then((r) => r.blob()));
		stopStageTicker();
		markStage("reading", "done");
		markStage("uploading", "active", `Sending audio to ${analysisLabel}…`);
		useStudio.getState().setStagePercent("uploading", 2, `Uploading to ${analysisLabel}…`);
		reportTransfer(0, prepared.blob.size, `Uploading to ${analysisLabel}`);
		const catalog = generationCatalog(generationFamily);
		const analysis = await analyzeAudio({
			family: analysisFamily,
			baseUrl: analysisUrl,
			apiKey: analysisKey,
			blob: prepared.blob,
			mimeType: prepared.mimeType,
			duration: original.duration,
			catalog,
			displayName: original.name || "story-audio",
			onProgress: (loaded, total) => {
				reportTransfer(loaded, total, `Uploading to ${analysisLabel}`);
				useStudio.getState().setStagePercent("uploading", transferPercent(loaded, total), `${formatMegabytes(loaded)} of ${formatMegabytes(total)}`);
			}
		});
		markStage("uploading", "done", `${formatMegabytes(prepared.blob.size)} uploaded`);
		setTransfer({
			loaded: prepared.blob.size,
			total: prepared.blob.size,
			percent: 100,
			label: `Uploaded to ${analysisLabel}`
		});
		markStage("analyzing_speakers", "active");
		startStageTicker("analyzing_speakers", "Detecting speakers…");
		await sleep(120);
		stopStageTicker();
		markStage("analyzing_speakers", "done");
		markStage("detecting_segments", "active");
		startStageTicker("detecting_segments", "Finding speaker boundaries…");
		await sleep(80);
		stopStageTicker();
		markStage("detecting_segments", "done");
		markStage("understanding_story", "active");
		startStageTicker("understanding_story", `${analysisModel ?? analysisLabel} understood the story`);
		stopStageTicker();
		markStage("understanding_story", "done");
		await finishStageWalk([
			"building_profiles",
			"analyzing_emotions",
			"casting_voices"
		]);
		if (!analysis) throw new StudioError("speaker_error");
		setAnalysis(analysis);
		setTransfer(null);
	} catch (err) {
		stopStageTicker();
		const message = err instanceof StudioError ? err.message : "The uploaded audio could not be processed.";
		setError(message);
		markStage("analyzing_speakers", "error", message);
		throw err;
	} finally {
		stopStageTicker();
		setBusy(false);
	}
}
async function renderSegment(segment, speakerId, text, instructions, voiceName, languageCode) {
	const { generationFamily, generationUrl, generationKey } = useStudio.getState();
	if (!generationFamily) throw new StudioError("model_unavailable");
	const result = await synthesizeVoice({
		family: generationFamily,
		baseUrl: generationUrl,
		apiKey: generationKey,
		text,
		instructions,
		voiceName,
		languageCode
	});
	const blob = new Blob([result.wavBytes], { type: "audio/wav" });
	return {
		segmentId: segment.id,
		speakerId,
		wavUrl: URL.createObjectURL(blob),
		duration: wavPcmDuration(result.wavBytes, result.sampleRate),
		pcmBase64: "",
		sampleRate: result.sampleRate
	};
}
function nativeVoice(id) {
	const family = useStudio.getState().generationFamily;
	return getVoice(id, generationCatalog(family ?? "compat"))?.nativeName ?? id;
}
async function runConversion() {
	const { analysis, original, setBusy, setError, markStage, setConvertProgress, putSegmentAudio, setMixUrl, setQuality } = useStudio.getState();
	if (!analysis || !original) throw new StudioError("audio_error");
	if (!keysReady()) throw new StudioError("invalid_api_key");
	setBusy(true, "Converting each speaker independently…");
	setError(null);
	try {
		markStage("separating_segments", "active");
		startStageTicker("separating_segments", "Splitting speakers…");
		const spoken = analysis.segments.filter((s) => !s.is_silence && s.text.trim().length > 0);
		setConvertProgress(0, spoken.length);
		await sleep(120);
		stopStageTicker();
		markStage("separating_segments", "done");
		markStage("converting_voices", "active");
		markStage("applying_emotion", "active");
		useStudio.getState().setStagePercent("converting_voices", 0, "0 of " + spoken.length);
		useStudio.getState().setStagePercent("applying_emotion", 0);
		const speakers = new Map(analysis.speakers.map((s) => [s.speaker_id, s]));
		let done = 0;
		await mapPool(spoken, 2, async (segment) => {
			const speaker = speakers.get(segment.speaker_id);
			if (!speaker) throw new StudioError("speaker_error");
			const voice = nativeVoice(speaker.recommended_voice_id);
			try {
				const clip = await renderSegment(segment, speaker.speaker_id, spokenTextOnly(segment), performanceNotes(speaker, segment), voice, analysis.story.language);
				putSegmentAudio(clip);
			} catch (err) {
				if (err instanceof StudioError) throw err;
				throw new StudioError("voice_engine_error");
			}
			done += 1;
			setConvertProgress(done, spoken.length);
			const pct = transferPercent(done, spoken.length);
			useStudio.getState().setStagePercent("converting_voices", pct, `${done} of ${spoken.length} lines`);
			useStudio.getState().setStagePercent("applying_emotion", pct, "Keeping the original emotion");
		});
		markStage("converting_voices", "done");
		markStage("applying_emotion", "done");
		markStage("reconstructing_timeline", "active");
		startStageTicker("reconstructing_timeline", "Laying lines back on the original clock…");
		const clips = useStudio.getState().segmentAudio;
		const mixClips = [];
		for (const segment of analysis.segments) {
			if (segment.is_silence || !segment.text.trim()) {
				mixClips.push({
					start: segment.start,
					end: segment.end,
					wavBytes: pcm16ToWav(/* @__PURE__ */ new ArrayBuffer(0), 24e3, 1),
					isSilence: true
				});
				continue;
			}
			const clip = clips[segment.id];
			if (!clip) continue;
			const wavBytes = await fetch(clip.wavUrl).then((r) => r.arrayBuffer());
			mixClips.push({
				start: segment.start,
				end: segment.end,
				wavBytes
			});
		}
		markStage("mixing", "active");
		startStageTicker("mixing", "Mixing the recast take…");
		const mixed = await reconstructTimeline(mixClips, original.duration);
		stopStageTicker();
		markStage("reconstructing_timeline", "done");
		markStage("mixing", "done");
		markStage("exporting", "active");
		startStageTicker("exporting", "Writing WAV…");
		const wav = audioBufferToWav(mixed);
		setMixUrl(URL.createObjectURL(wav));
		setQuality(runQualityChecks(analysis, useStudio.getState().segmentAudio, mixed.duration));
		stopStageTicker();
		markStage("exporting", "done");
		markStage("ready", "done");
	} catch (err) {
		const message = err instanceof StudioError ? err.message : "The voice-conversion engine could not generate one or more speaker segments.";
		setError(message);
		markStage("converting_voices", "error", message);
		throw err;
	} finally {
		stopStageTicker();
		setBusy(false);
	}
}
async function retrySegment(segmentId) {
	const { analysis, putSegmentAudio, setError, original, segmentAudio, setMixUrl, setQuality, setBusy } = useStudio.getState();
	if (!analysis) return;
	const segment = analysis.segments.find((s) => s.id === segmentId);
	const speaker = analysis.speakers.find((s) => s.speaker_id === segment?.speaker_id);
	if (!segment || !speaker) return;
	if (!keysReady()) throw new StudioError("invalid_api_key");
	setBusy(true, `Regenerating ${speaker.display_name}…`);
	setError(null);
	try {
		const voice = nativeVoice(speaker.recommended_voice_id);
		const clip = await renderSegment(segment, speaker.speaker_id, spokenTextOnly(segment), performanceNotes(speaker, segment), voice, analysis.story.language);
		putSegmentAudio(clip);
		if (original) {
			const clips = {
				...segmentAudio,
				[segment.id]: clip
			};
			const mixClips = [];
			for (const seg of analysis.segments) {
				if (seg.is_silence || !seg.text.trim()) {
					mixClips.push({
						start: seg.start,
						end: seg.end,
						wavBytes: pcm16ToWav(/* @__PURE__ */ new ArrayBuffer(0), 24e3, 1),
						isSilence: true
					});
					continue;
				}
				const c = clips[seg.id];
				if (!c) continue;
				mixClips.push({
					start: seg.start,
					end: seg.end,
					wavBytes: await fetch(c.wavUrl).then((r) => r.arrayBuffer())
				});
			}
			const mixed = await reconstructTimeline(mixClips, original.duration);
			setMixUrl(URL.createObjectURL(audioBufferToWav(mixed)));
			setQuality(runQualityChecks(analysis, clips, mixed.duration));
		}
	} catch (err) {
		setError(err instanceof StudioError ? err.message : "Could not regenerate that segment.");
	} finally {
		setBusy(false);
	}
}
async function previewCharacter(speakerId) {
	const { analysis } = useStudio.getState();
	if (!analysis) throw new StudioError("speaker_error");
	if (!keysReady()) throw new StudioError("invalid_api_key");
	const speaker = analysis.speakers.find((s) => s.speaker_id === speakerId);
	const line = analysis.segments.find((s) => s.speaker_id === speakerId && !s.is_silence && s.text.trim());
	if (!speaker || !line) throw new StudioError("voice_engine_error");
	return (await renderSegment(line, speaker.speaker_id, spokenTextOnly(line), performanceNotes(speaker, line), nativeVoice(speaker.recommended_voice_id), analysis.story.language)).wavUrl;
}
function recastCharacter(speakerId) {
	const { analysis, setAnalysis, generationFamily } = useStudio.getState();
	if (!analysis || !generationFamily) return;
	const catalog = generationCatalog(generationFamily);
	const taken = new Set(analysis.speakers.filter((s) => s.speaker_id !== speakerId).map((s) => s.recommended_voice_id));
	setAnalysis({
		...analysis,
		speakers: analysis.speakers.map((s) => s.speaker_id === speakerId ? recastSpeaker(s, taken, catalog) : s)
	});
}
async function createSampleScene() {
	const { generationKey, generationUrl, generationFamily, setBusy, setError, markStage, resetPipeline } = useStudio.getState();
	if (!keysReady() || !generationFamily) throw new StudioError("invalid_api_key");
	setBusy(true, "Creating a three-character sample scene…");
	setError(null);
	resetPipeline();
	markStage("uploading", "active", "Synthesizing a short dramatic scene");
	try {
		const catalog = generationCatalog(generationFamily);
		const narrator = catalog.find((v) => v.bestFor.includes("narrator")) ?? catalog[0];
		const oldMan = catalog.find((v) => v.texture === "gravelly" || v.age === "mature" && v.pitch === "low" && v.id !== narrator?.id) ?? catalog[1] ?? catalog[0];
		const young = catalog.find((v) => v.age === "youthful" && v.id !== narrator?.id && v.id !== oldMan?.id) ?? catalog[2] ?? catalog[0];
		const voiceFor = {
			narrator: narrator?.nativeName ?? "",
			old_man: oldMan?.nativeName ?? "",
			young_woman: young?.nativeName ?? ""
		};
		const clips = [];
		let cursor = .3;
		for (const line of SAMPLE_SCENE) {
			const result = await synthesizeVoice({
				family: generationFamily,
				baseUrl: generationUrl,
				apiKey: generationKey,
				text: line.text,
				instructions: line.direction,
				voiceName: voiceFor[line.speaker],
				languageCode: "en-US"
			});
			const duration = Math.max(.4, wavPcmDuration(result.wavBytes, result.sampleRate));
			clips.push({
				start: cursor,
				end: cursor + duration,
				wavBytes: result.wavBytes
			});
			cursor += duration + .45;
		}
		const mixed = await reconstructTimeline(clips, cursor + .4);
		markStage("uploading", "done");
		return audioBufferToWav(mixed);
	} catch (err) {
		setError(err instanceof StudioError ? err.message : "The voice-conversion engine could not generate one or more speaker segments.");
		throw err;
	} finally {
		setBusy(false);
	}
}
async function ingestAudioFile(file, name) {
	const blob = file;
	const fileName = name ?? (file instanceof File ? file.name : "story.wav");
	const mimeType = blob.type || "audio/wav";
	const { setTransfer, setBusy, setError } = useStudio.getState();
	if (blob.size > 52428800) throw new StudioError("audio_error", `This file is ${formatMegabytes(blob.size)}. Maximum size is 50 MB.`);
	setBusy(true, "Reading audio…");
	setError(null);
	reportTransfer(0, blob.size, "Reading audio");
	try {
		await readBlobProgress(blob, (loaded, total) => {
			reportTransfer(loaded, total, "Reading audio");
		});
		const objectUrl = URL.createObjectURL(blob);
		let duration = 0;
		try {
			duration = await blobDuration(blob);
		} catch {
			duration = 0;
		}
		let peaks = [];
		try {
			const buffer = await decodeAudioFile(blob);
			peaks = computeWaveformPeaks(buffer);
			if (!duration) duration = buffer.duration;
		} catch {}
		if (duration > 1800) {
			URL.revokeObjectURL(objectUrl);
			throw new StudioError("audio_error", `This recording is ${Math.ceil(duration / 60)} minutes. Maximum length is 30 minutes.`);
		}
		reportTransfer(blob.size, blob.size, "Audio ready");
		const asset = {
			name: fileName,
			size: blob.size,
			duration,
			mimeType,
			objectUrl
		};
		useStudio.getState().setOriginal(asset, peaks);
		setTransfer(null);
	} catch (err) {
		setTransfer(null);
		throw err;
	} finally {
		setBusy(false);
	}
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md bg-secondary px-3 text-sm text-foreground shadow-border outline-none transition-[box-shadow] duration-150 placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
		className: cn("text-sm font-medium text-foreground", className),
		...props
	});
}
function analysisResult(status) {
	if (status === "valid") return {
		title: "✓ API is Valid and Useful",
		body: "This API authenticated and can analyze multi-speaker audio.",
		tone: "success"
	};
	if (status === "invalid") return {
		title: "✕ Audio Analysis API Key is Invalid",
		body: "The analysis API key could not be authenticated.",
		tone: "error"
	};
	if (status === "quota") return {
		title: "⚠ Analysis API quota is unavailable.",
		body: "The key was accepted, but analysis quota or credits are currently unavailable.",
		tone: "warning"
	};
	if (status === "model_error") return {
		title: "⚠ This API is valid, but not useful for audio analysis.",
		body: "Authentication worked, but this website cannot currently analyze uploaded multi-speaker audio.",
		tone: "warning"
	};
	if (status === "network_error") return {
		title: "⚠ Unable to connect to the selected AI provider.",
		body: "Check the API website URL and your internet connection, then try again.",
		tone: "warning"
	};
	if (status === "server_error") return {
		title: "⚠ The selected AI provider is temporarily unavailable.",
		body: "Please try again in a moment.",
		tone: "warning"
	};
	return null;
}
function generationResult(status) {
	if (status === "valid") return {
		title: "✓ API is Valid and Useful",
		body: "This API authenticated and can generate character voices.",
		tone: "success"
	};
	if (status === "invalid") return {
		title: "✕ Audio Generation API Key is Invalid",
		body: "The generation API key could not be authenticated.",
		tone: "error"
	};
	if (status === "quota") return {
		title: "⚠ Audio Generation API quota is unavailable.",
		body: "The key was accepted, but generation quota or credits are currently unavailable.",
		tone: "warning"
	};
	if (status === "model_error") return {
		title: "⚠ This API is valid, but not useful for voice generation.",
		body: "Authentication worked, but this website cannot currently generate distinct character voices.",
		tone: "warning"
	};
	if (status === "network_error") return {
		title: "⚠ Unable to connect to the selected AI provider.",
		body: "Check the API website URL and your internet connection, then try again.",
		tone: "warning"
	};
	if (status === "server_error") return {
		title: "⚠ The selected AI provider is temporarily unavailable.",
		body: "Please try again in a moment.",
		tone: "warning"
	};
	return null;
}
var TONE = {
	success: "border-success/30 bg-success/10 text-success",
	error: "border-destructive/30 bg-destructive/10 text-destructive",
	warning: "border-accent/30 bg-accent/10 text-accent"
};
function ApiKeyPanel() {
	const analysisUrl = useStudio((s) => s.analysisUrl);
	const analysisKey = useStudio((s) => s.analysisKey);
	const analysisShowKey = useStudio((s) => s.analysisShowKey);
	const analysisStatus = useStudio((s) => s.analysisStatus);
	const analysisModel = useStudio((s) => s.analysisModel);
	const analysisFamily = useStudio((s) => s.analysisFamily);
	const generationUrl = useStudio((s) => s.generationUrl);
	const generationKey = useStudio((s) => s.generationKey);
	const generationShowKey = useStudio((s) => s.generationShowKey);
	const generationStatus = useStudio((s) => s.generationStatus);
	const generationModel = useStudio((s) => s.generationModel);
	const generationFamily = useStudio((s) => s.generationFamily);
	const workflowUnlocked = useStudio((s) => s.workflowUnlocked);
	const setAnalysisUrl = useStudio((s) => s.setAnalysisUrl);
	const setAnalysisKey = useStudio((s) => s.setAnalysisKey);
	const setAnalysisShowKey = useStudio((s) => s.setAnalysisShowKey);
	const clearAnalysisKey = useStudio((s) => s.clearAnalysisKey);
	const setGenerationUrl = useStudio((s) => s.setGenerationUrl);
	const setGenerationKey = useStudio((s) => s.setGenerationKey);
	const setGenerationShowKey = useStudio((s) => s.setGenerationShowKey);
	const clearGenerationKey = useStudio((s) => s.clearGenerationKey);
	const unlockWorkflow = useStudio((s) => s.unlockWorkflow);
	const canContinue = analysisStatus === "valid" && generationStatus === "valid";
	const aResult = analysisResult(analysisStatus);
	const gResult = generationResult(generationStatus);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 flex size-9 items-center justify-center rounded-md bg-secondary text-accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Connect two APIs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted-foreground",
					children: "Paste any HTTPS API website and its key. Nothing is hard-coded. The studio validates the key for real, then checks whether that API is actually useful for analysis or voice generation."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeySlot, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-3.5" }),
					title: "Audio Analysis API",
					description: "Any website API that can understand audio or transcribe speech, then reason about speakers and story.",
					urlId: "analysis-url",
					url: analysisUrl,
					onUrl: setAnalysisUrl,
					urlPlaceholder: "https://api.example.com/v1",
					inputId: "analysis-key",
					value: analysisKey,
					onChange: setAnalysisKey,
					show: analysisShowKey,
					onShow: setAnalysisShowKey,
					onClear: clearAnalysisKey,
					placeholder: "Enter API key for audio analysis",
					buttonLabel: "Validate Analysis API",
					testing: analysisStatus === "testing",
					onValidate: () => void verifyAnalysisKey(),
					result: aResult,
					model: analysisModel,
					family: analysisFamily ? familyLabel(analysisFamily) : null
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeySlot, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }),
					title: "Audio Generation API",
					description: "Any website API that can generate distinct, expressive character voices.",
					urlId: "generation-url",
					url: generationUrl,
					onUrl: setGenerationUrl,
					urlPlaceholder: "https://api.example.com/v1",
					inputId: "generation-key",
					value: generationKey,
					onChange: setGenerationKey,
					show: generationShowKey,
					onShow: setGenerationShowKey,
					onClear: clearGenerationKey,
					placeholder: "Enter API key for voice generation",
					buttonLabel: "Validate Generation API",
					testing: generationStatus === "testing",
					onValidate: () => void verifyGenerationKey(),
					result: gResult,
					model: generationModel,
					family: generationFamily ? familyLabel(generationFamily) : null
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs leading-5 text-muted-foreground",
				children: "Keys stay in this browser session only, are never put in URLs, and are never written into this app’s source. Each key is sent only to the website you pasted for that slot."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-col gap-2 sm:flex-row sm:justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "lg",
					className: "w-full sm:w-auto",
					disabled: !canContinue,
					onClick: unlockWorkflow,
					children: "Continue"
				})
			}),
			workflowUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-right text-xs text-success",
				children: "Studio unlocked. Upload a multi-speaker recording below."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-right text-xs text-muted-foreground",
				children: "Continue is enabled only after both APIs validate as valid and useful."
			})
		]
	});
}
function KeySlot({ icon, title, description, urlId, url, onUrl, urlPlaceholder, inputId, value, onChange, show, onShow, onClear, placeholder, buttonLabel, testing, onValidate, result, model, family }) {
	const canValidate = value.trim().length > 0 && url.trim().length > 0 && !testing;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 rounded-lg bg-secondary/70 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-7 items-center justify-center rounded-md bg-card text-accent",
					children: icon
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-medium",
					children: title
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-5 text-muted-foreground",
				children: description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: urlId,
					children: "API website"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: urlId,
					type: "url",
					inputMode: "url",
					autoComplete: "off",
					spellCheck: false,
					placeholder: urlPlaceholder,
					value: url,
					onChange: (e) => onUrl(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: inputId,
					children: "API key"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: inputId,
						type: show ? "text" : "password",
						autoComplete: "off",
						spellCheck: false,
						placeholder,
						value,
						onChange: (e) => onChange(e.target.value),
						className: "pr-20",
						suppressHydrationWarning: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-y-0 right-1 flex items-center gap-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded-md p-2 text-muted-foreground hover:text-foreground",
							onClick: () => onShow(!show),
							"aria-label": show ? "Hide API key" : "Show API key",
							children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded-md p-2 text-muted-foreground hover:text-foreground",
							onClick: onClear,
							disabled: !value,
							"aria-label": "Clear API key",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unplug, { className: "size-4" })
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				disabled: !canValidate,
				onClick: onValidate,
				children: testing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), "Validating..."] }) : buttonLabel
			}),
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `rounded-md border px-3 py-2 text-sm ${TONE[result.tone]}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-start gap-2 font-medium",
						children: [result.tone === "success" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0" }) : result.tone === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mt-0.5 size-4 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-4 shrink-0" }), result.title]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs opacity-90",
						children: result.body
					}),
					result.tone === "success" && !show ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs opacity-80",
						children: [
							maskApiKey(value),
							family ? ` · ${family}` : "",
							model ? ` · ${model}` : ""
						]
					}) : null
				]
			}) : null
		]
	});
}
function Waveform({ peaks, segments, speakerIndex, duration }) {
	const bars = peaks.length > 0 ? peaks : Array.from({ length: 72 }, () => .12);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-16 items-end gap-px",
		"aria-hidden": "true",
		children: bars.map((peak, i) => {
			const t = bars.length > 1 ? i / (bars.length - 1) : 0;
			const time = (duration ?? 1) * t;
			const seg = segments?.find((s) => time >= s.start && time < s.end && !s.is_silence);
			const color = seg && speakerIndex ? speakerColorVar(speakerIndex[seg.speaker_id] ?? 0) : "var(--color-accent)";
			const h = Math.max(8, Math.round(peak * 100));
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 rounded-full",
				style: {
					height: `${h}%`,
					background: color,
					opacity: seg || !segments ? .9 : .25
				}
			}, i);
		})
	});
}
function Progress({ className, value, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
		className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
			className: "h-full w-full flex-1 bg-accent transition-transform duration-300 ease-out",
			style: { transform: `translateX(-${100 - (value ?? 0)}%)` }
		})
	});
}
function TransferBar({ progress }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-secondary p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: progress.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-sm tabular-nums text-foreground",
					children: [progress.percent, "%"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
				className: "mt-3 h-2",
				value: progress.percent
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap items-center justify-between gap-2 font-mono text-xs tabular-nums text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					formatMegabytes(progress.loaded),
					" of ",
					formatMegabytes(progress.total)
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Limit ",
					formatMegabytes(MAX_AUDIO_BYTES),
					" · 30 min"
				] })]
			})
		]
	});
}
var ACCEPT = "audio/mpeg,audio/mp3,audio/wav,audio/x-wav,audio/mp4,audio/aac,audio/ogg,audio/flac,audio/x-m4a,.mp3,.wav,.m4a,.aac,.ogg,.flac";
function AudioUploader() {
	const original = useStudio((s) => s.original);
	const peaks = useStudio((s) => s.peaks);
	const busy = useStudio((s) => s.busy);
	const analysisStatus = useStudio((s) => s.analysisStatus);
	const generationStatus = useStudio((s) => s.generationStatus);
	const resetProject = useStudio((s) => s.resetProject);
	const transfer = useStudio((s) => s.transfer);
	const inputRef = (0, import_react.useRef)(null);
	const [drag, setDrag] = (0, import_react.useState)(false);
	async function takeFile(file) {
		if (!file) return;
		try {
			await ingestAudioFile(file);
			toast.success("Story audio ready");
		} catch (err) {
			toast.error(err instanceof StudioError ? err.message : "The uploaded audio could not be processed.");
		}
	}
	async function onSample() {
		try {
			await ingestAudioFile(await createSampleScene(), "sample-scene.wav");
			toast.success("Sample scene loaded — analyze it next");
		} catch (err) {
			toast.error(err instanceof StudioError ? err.message : "Could not create the sample scene.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 flex size-9 items-center justify-center rounded-md bg-secondary text-accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Upload story audio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm text-muted-foreground",
					children: "One recording with narration and multiple characters. Maximum size is 50 MB and 30 minutes."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: ACCEPT,
				className: "sr-only",
				onChange: (e) => {
					takeFile(e.target.files?.[0]);
					e.currentTarget.value = "";
				}
			}),
			!original && transfer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransferBar, { progress: transfer })
			}) : !original ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => inputRef.current?.click(),
				onDragEnter: (e) => {
					e.preventDefault();
					setDrag(true);
				},
				onDragOver: (e) => {
					e.preventDefault();
					setDrag(true);
				},
				onDragLeave: () => setDrag(false),
				onDrop: (e) => {
					e.preventDefault();
					setDrag(false);
					takeFile(e.dataTransfer.files?.[0]);
				},
				className: `mt-5 flex min-h-44 w-full flex-col items-center justify-center rounded-lg bg-secondary px-4 py-10 text-center transition-[box-shadow,background-color] duration-200 ${drag ? "shadow-border-hover" : "shadow-border"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, { className: "size-8 text-accent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-medium",
						children: "Drop a story recording here"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [
							"MP3, WAV, M4A, AAC, OGG, FLAC · up to ",
							formatMegabytes(MAX_AUDIO_BYTES),
							" and 30 minutes"
						]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 rounded-lg bg-secondary p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileAudio, { className: "mt-0.5 size-4 shrink-0 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: original.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-0.5 font-mono text-xs text-muted-foreground tabular-nums",
									children: [
										formatBytes(original.size),
										" · ",
										formatDuration(original.duration)
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								disabled: busy,
								onClick: () => inputRef.current?.click(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Replace, { className: "size-3.5" }), "Replace"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								disabled: busy,
								onClick: resetProject,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "Remove"]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waveform, { peaks })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
						className: "mt-4 w-full",
						controls: true,
						src: original.objectUrl,
						preload: "metadata"
					})
				]
			}),
			transfer && original && transfer.label.startsWith("Reading") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransferBar, { progress: transfer })
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Audio is sent only to the analysis API website you entered, for this session, and is not kept on this studio after processing."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					disabled: busy || analysisStatus !== "valid" || generationStatus !== "valid",
					onClick: () => void onSample(),
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : null, "Create sample scene"]
				})]
			})
		]
	});
}
function PipelinePanel() {
	const pipeline = useStudio((s) => s.pipeline);
	const convertIndex = useStudio((s) => s.convertIndex);
	const convertTotal = useStudio((s) => s.convertTotal);
	const busyLabel = useStudio((s) => s.busyLabel);
	const transfer = useStudio((s) => s.transfer);
	if (!pipeline.some((s) => s.status !== "idle")) return null;
	const overall = Math.round(pipeline.reduce((sum, stage) => {
		if (stage.status === "done") return sum + 100;
		if (stage.status === "active") return sum + (stage.percent ?? 0);
		return sum;
	}, 0) / pipeline.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Processing"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: busyLabel || "Working through the voice pipeline"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-sm tabular-nums text-foreground",
					children: [overall, "%"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
				className: "mt-4 h-2",
				value: overall
			}),
			transfer && (transfer.label.includes("Upload") || transfer.label.includes("Reading")) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransferBar, { progress: transfer })
			}) : null,
			convertTotal > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 font-mono text-xs text-muted-foreground tabular-nums",
				children: [
					"Converting segment ",
					Math.min(convertIndex, convertTotal),
					" of ",
					convertTotal,
					" ·",
					" ",
					Math.round(Math.min(convertIndex, convertTotal) / convertTotal * 100),
					"%"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-5 grid gap-1 sm:grid-cols-2",
				children: pipeline.map((stage) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-2 rounded-md px-2 py-1.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusIcon, { status: stage.status }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: stage.status === "idle" ? "text-muted-foreground" : "text-foreground",
								children: stage.label
							}), stage.detail && stage.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block text-xs text-muted-foreground",
								children: stage.detail
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `font-mono text-xs tabular-nums ${stage.status === "idle" ? "text-muted-foreground/40" : "text-muted-foreground"}`,
							children: stagePercentLabel(stage.status, stage.percent)
						})
					]
				}, stage.id))
			})
		]
	});
}
function stagePercentLabel(status, percent) {
	if (status === "idle") return "0%";
	if (status === "done") return "100%";
	if (status === "error") return `${Math.round(percent || 0)}%`;
	return `${Math.round(percent || 0)}%`;
}
function StatusIcon({ status }) {
	if (status === "done") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-3.5 text-success" });
	if (status === "active") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mt-0.5 size-3.5 animate-spin text-accent" });
	if (status === "error") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mt-0.5 size-3.5 text-destructive" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "mt-0.5 size-3.5 text-muted-foreground/40" });
}
function CharacterCard({ speaker, index }) {
	const generationFamily = useStudio((s) => s.generationFamily);
	const voice = getVoice(speaker.recommended_voice_id, catalogFor(generationFamily ?? "compat"));
	const [previewing, setPreviewing] = (0, import_react.useState)(false);
	const audioRef = (0, import_react.useRef)(null);
	async function onPreview() {
		setPreviewing(true);
		try {
			const url = await previewCharacter(speaker.speaker_id);
			const audio = audioRef.current;
			if (audio) {
				audio.src = url;
				await audio.play();
			}
		} catch (err) {
			toast.error(err instanceof StudioError ? err.message : "Could not preview that voice.");
		} finally {
			setPreviewing(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col rounded-lg bg-secondary p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 size-2.5 shrink-0 rounded-full",
					style: { background: speakerColorVar(index) }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-lg font-medium tracking-tight",
								children: speaker.display_name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: speaker.speaker_id.replace("_", " ")
							}),
							speaker.is_narrator ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "steel",
								children: "Narrator"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: speaker.importance })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: speaker.role
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid gap-3 text-sm sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Original voice"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 text-foreground",
						children: [
							speaker.original_voice.age_characteristic,
							", ",
							speaker.original_voice.pitch,
							" pitch,",
							" ",
							speaker.original_voice.pace,
							" pace, ",
							speaker.original_voice.texture,
							", ",
							speaker.original_voice.energy,
							" energy"
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Personality"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1",
						children: speaker.personality.join(" · ") || "—"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Emotional style"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1",
						children: speaker.emotional_style.join(" · ") || "—"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Cast voice"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicVocal, { className: "size-3.5 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [speaker.recommended_voice_id, voice ? ` · ${voice.tagline}` : ""] })]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: speaker.voice_reason
			}),
			speaker.story_context ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-foreground",
				children: speaker.story_context
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					onClick: () => void onPreview(),
					disabled: previewing,
					children: [previewing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-3.5" }), "Preview generated voice"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					onClick: () => recastCharacter(speaker.speaker_id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5" }), "Recast automatically"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				className: "hidden"
			})
		]
	});
}
function EmotionTimeline({ analysis }) {
	const duration = Math.max(.1, analysis.segments.at(-1)?.end ?? 1);
	const index = Object.fromEntries(analysis.speakers.map((s, i) => [s.speaker_id, i]));
	const spoken = analysis.segments.filter((s) => !s.is_silence);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-medium tracking-tight",
				children: "Emotion"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Detected from the meaning of each line and the scene, then used to drive delivery."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mt-5 h-10 overflow-hidden rounded-md bg-secondary",
				children: analysis.segments.map((seg) => {
					const left = seg.start / duration * 100;
					const width = Math.max(.4, (seg.end - seg.start) / duration * 100);
					if (seg.is_silence) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						title: `${seg.emotion} · ${seg.emotion_intensity}`,
						className: "absolute top-1 bottom-1 rounded-sm",
						style: {
							left: `${left}%`,
							width: `${width}%`,
							background: speakerColorVar(index[seg.speaker_id] ?? 0),
							opacity: intensityOpacity(seg.emotion_intensity)
						}
					}, seg.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 max-h-80 space-y-2 overflow-y-auto pr-1",
				children: spoken.map((seg) => {
					const who = analysis.speakers.find((s) => s.speaker_id === seg.speaker_id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-20 shrink-0 font-mono text-xs text-muted-foreground tabular-nums",
								children: formatTimecode(seg.start)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 size-2 shrink-0 rounded-full",
								style: { background: speakerColorVar(index[seg.speaker_id] ?? 0) }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-medium",
									children: [who?.display_name ?? seg.speaker_id, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-2 font-normal text-muted-foreground",
										children: [
											seg.emotion,
											" · ",
											seg.emotion_intensity.replace("_", " ")
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-muted-foreground",
									children: seg.text
								})]
							})
						]
					}, seg.id);
				})
			})
		]
	});
}
function intensityOpacity(level) {
	switch (level) {
		case "very_low": return .35;
		case "low": return .5;
		case "high": return .88;
		case "very_high": return 1;
		default: return .7;
	}
}
function ResultPlayer() {
	const original = useStudio((s) => s.original);
	const mixUrl = useStudio((s) => s.mixUrl);
	const analysis = useStudio((s) => s.analysis);
	const quality = useStudio((s) => s.quality);
	const segmentAudio = useStudio((s) => s.segmentAudio);
	const busy = useStudio((s) => s.busy);
	if (!mixUrl || !original || !analysis) return null;
	const index = Object.fromEntries(analysis.speakers.map((s, i) => [s.speaker_id, i]));
	const spoken = analysis.segments.filter((s) => !s.is_silence && s.text.trim());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Result"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Same dialogue order, independent voices, reconstructed on the original timeline."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: mixUrl,
					download: "character-voice-studio.wav",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download WAV"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-secondary p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
							children: "Original"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
							className: "mt-3 w-full",
							controls: true,
							src: original.objectUrl,
							preload: "metadata"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-xs text-muted-foreground tabular-nums",
							children: formatDuration(original.duration)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-secondary p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
							children: "Recast"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
							className: "mt-3 w-full",
							controls: true,
							src: mixUrl,
							preload: "metadata"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted-foreground",
							children: "Expressive character voices, mixed back onto the original clock."
						})
					]
				})]
			}),
			quality.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-5 grid gap-2 sm:grid-cols-2",
				children: quality.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-2 rounded-md bg-secondary px-3 py-2 text-sm",
					children: [check.passed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-3.5 text-success" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mt-0.5 size-3.5 text-destructive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: check.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: check.detail
					})] })]
				}, check.id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: "Segments"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: spoken.map((seg) => {
						const who = analysis.speakers.find((s) => s.speaker_id === seg.speaker_id);
						const clip = segmentAudio[seg.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center gap-3 rounded-md bg-secondary px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-2 rounded-full",
									style: { background: speakerColorVar(index[seg.speaker_id] ?? 0) }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: who?.display_name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [" · ", seg.emotion]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: seg.text
									})]
								}),
								clip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
									className: "h-8 max-w-40",
									controls: true,
									src: clip.wavUrl,
									preload: "metadata"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "sm",
									variant: "ghost",
									disabled: busy,
									onClick: () => void retrySegment(seg.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5" }), "Retry"]
								})
							]
						}, seg.id);
					})
				})]
			})
		]
	});
}
function StudioApp() {
	const hydrate = useStudio((s) => s.hydrate);
	const workflowUnlocked = useStudio((s) => s.workflowUnlocked);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-5xl flex-col px-4 pt-6 pb-16 sm:px-6 sm:pt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mt-8 flex flex-col gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApiKeyPanel, {}), workflowUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioUploader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalyzeBar, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelinePanel, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryPanel, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CharactersPanel, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmotionGate, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConvertBar, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPlayer, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterNote, {})
			] }) : null]
		})]
	});
}
function Header() {
	const analysisStatus = useStudio((s) => s.analysisStatus);
	const generationStatus = useStudio((s) => s.generationStatus);
	const analysisKey = useStudio((s) => s.analysisKey);
	const generationKey = useStudio((s) => s.generationKey);
	const analysisFamily = useStudio((s) => s.analysisFamily);
	const generationFamily = useStudio((s) => s.generationFamily);
	const analysisLabel = familyLabel(analysisFamily, "Analysis");
	const generationLabel = familyLabel(generationFamily, "Generation");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-[0.22em] text-muted-foreground uppercase",
				children: "Automatic character casting"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-2 font-display text-[2.15rem] leading-[1.1] font-medium tracking-tight sm:text-5xl",
				children: [
					"Character",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
						className: "italic font-medium text-accent",
						children: "Voice"
					}),
					" Studio"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-lg text-sm leading-6 text-muted-foreground sm:text-base",
				children: "Upload one multi-speaker story. The analysis API you connect finds the speakers and casts distinct voices. The generation API speaks each character — then the original timeline is rebuilt."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: analysisStatus === "valid" ? "success" : "outline",
					children: analysisStatus === "valid" ? `${analysisLabel} ${maskApiKey(analysisKey)}` : "Validate analysis key"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: generationStatus === "valid" ? "success" : "outline",
					children: generationStatus === "valid" ? `${generationLabel} ${maskApiKey(generationKey)}` : "Validate generation key"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: "No shared voices"
				})
			]
		})]
	});
}
function AnalyzeBar() {
	const original = useStudio((s) => s.original);
	const busy = useStudio((s) => s.busy);
	const analysis = useStudio((s) => s.analysis);
	const error = useStudio((s) => s.error);
	const peaks = useStudio((s) => s.peaks);
	const analysisStatus = useStudio((s) => s.analysisStatus);
	if (!original) return null;
	async function onAnalyze() {
		try {
			await runAnalysis();
			toast.success("Speakers cast automatically");
		} catch (err) {
			toast.error(err instanceof StudioError ? err.message : "Something went wrong. Please try processing the audio again.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Analyze"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-md text-sm text-muted-foreground",
					children: "Detect speakers, read the story, and auto-cast a different suitable voice for each character. You do not pick voices by hand."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "lg",
					disabled: busy || analysisStatus !== "valid",
					onClick: () => void onAnalyze(),
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "size-4" }), "Analyze & cast"]
				})]
			}),
			analysis ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waveform, {
					peaks,
					segments: analysis.segments,
					speakerIndex: Object.fromEntries(analysis.speakers.map((s, i) => [s.speaker_id, i])),
					duration: original.duration
				})
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-destructive",
				children: error
			}) : null
		]
	});
}
function StoryPanel() {
	const analysis = useStudio((s) => s.analysis);
	if (!analysis) return null;
	const { story } = analysis;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 flex size-9 items-center justify-center rounded-md bg-secondary text-accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: story.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: [
						story.genre,
						" · ",
						story.mood,
						story.time_period ? ` · ${story.time_period}` : ""
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-3xl text-sm leading-6",
				children: story.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						children: story.environment
					}),
					story.atmosphere.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						children: tag
					}, tag)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						children: [analysis.speakers.length, " speakers"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						children: [analysis.segments.filter((s) => !s.is_silence).length, " spoken lines"]
					})
				]
			})
		]
	});
}
function CharactersPanel() {
	const analysis = useStudio((s) => s.analysis);
	if (!analysis) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl font-medium tracking-tight",
			children: "Characters & voice casting"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 max-w-2xl text-sm text-muted-foreground",
			children: "Casting is automatic. Each important character receives a different catalog voice chosen from original timbre, role, personality, and scene mood — including casts with more than 10 speakers."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 grid gap-3",
			children: analysis.speakers.map((speaker, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CharacterCard, {
				speaker,
				index
			}, speaker.speaker_id))
		})]
	});
}
function EmotionGate() {
	const analysis = useStudio((s) => s.analysis);
	if (!analysis) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmotionTimeline, { analysis });
}
function ConvertBar() {
	const analysis = useStudio((s) => s.analysis);
	const mixUrl = useStudio((s) => s.mixUrl);
	const busy = useStudio((s) => s.busy);
	const generationStatus = useStudio((s) => s.generationStatus);
	if (!analysis) return null;
	async function onConvert() {
		try {
			await runConversion();
			toast.success("Recast mix is ready");
		} catch (err) {
			toast.error(err instanceof StudioError ? err.message : "The voice-conversion engine could not generate one or more speaker segments.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "rounded-xl bg-card p-5 shadow-border sm:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-medium tracking-tight",
				children: "Convert voices"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-md text-sm text-muted-foreground",
				children: "Each speaker is synthesized independently with emotional direction, then laid back on the original clock — pauses included."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "lg",
				disabled: busy || generationStatus !== "valid",
				onClick: () => void onConvert(),
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, { className: "size-4" }), mixUrl ? "Convert again" : "Convert voices"]
			})]
		})
	});
}
function FooterNote() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "px-1 pt-4 text-xs leading-5 text-muted-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The analysis API identifies speakers, characters, original voices, and emotion, then automatically casts a persistent voice for each speaker. The generation API speaks those lines — this is character-aware recasting, not a clone of the original vocal tract. You do not pick voices by hand. Uploaded audio is temporary; this studio does not sell recordings or keep complete API keys in logs." })
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioApp, {});
}
//#endregion
export { routes_DeCuNS9O_exports as _, decodeBase64Audio as a, encodedAudioToWav as c, Home as component, pcm16ToWav as d, prepareAnalysisAudio as f, wrapAudioBytes as g, wavPcmDuration as h, decodeAudioFile as i, floatTo16BitWav as l, reconstructTimeline as m, blobDuration as n, downsampleToMono as o, readWavSampleRate as p, computeWaveformPeaks as r, encodeBase64 as s, audioBufferToWav as t, isWavBuffer as u };
