import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { E as FolderOpen, N as CodeXml, P as ClipboardPaste, c as Smartphone, k as Eye, p as Rocket } from "../_libs/lucide-react.mjs";
import { n as NijoMark, t as Button } from "./button-ryli-Zjw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dm-XxcsB.js
var import_jsx_runtime = require_jsx_runtime();
var FEATURES = [
	{
		icon: Smartphone,
		title: "Mobile first",
		text: "Built for thumbs, keyboards, and small screens — not a shrunk desktop IDE."
	},
	{
		icon: Eye,
		title: "Live preview",
		text: "HTML, CSS, and JavaScript render in a sandboxed frame you can rotate between devices."
	},
	{
		icon: CodeXml,
		title: "Multiple languages",
		text: "Syntax highlighting and auto-detect for web, mobile, and general-purpose languages."
	},
	{
		icon: FolderOpen,
		title: "Open files",
		text: "Load a single file or unzip a whole project from your phone storage."
	},
	{
		icon: ClipboardPaste,
		title: "Paste and run",
		text: "Drop in a snippet, tap Run, and read the result without a laptop."
	},
	{
		icon: Rocket,
		title: "Code anywhere",
		text: "Install NIJO to your home screen and keep editing when the network drops."
	}
];
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 top-0 h-64 nijo-hero-wash" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative mx-auto flex max-w-5xl items-center justify-between px-5 pb-4 pt-[max(1.25rem,env(safe-area-inset-top))]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NijoMark, { className: "size-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-tight",
						children: "NIJO MOBILE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Bouzidi Softworks"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					size: "sm",
					variant: "secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/workspace",
						children: "Open"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative mx-auto max-w-5xl px-5 pb-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "stagger-in max-w-xl pt-6 md:pt-16",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-[0.18em] text-primary",
								children: "NIJO MOBILE"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "mt-3 text-4xl font-medium tracking-tight md:text-6xl",
								children: [
									"Code Anywhere.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Build Anywhere."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-md text-base leading-relaxed text-muted",
								children: "A powerful mobile coding workspace that lets you write, paste, upload, preview and test your code directly from your phone."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-7 flex flex-col gap-3 sm:flex-row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										className: "w-full sm:w-auto",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/workspace",
											children: "Start coding"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										variant: "secondary",
										className: "w-full sm:w-auto",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/workspace",
											search: { intent: "open" },
											children: "Open file"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										variant: "outline",
										className: "w-full sm:w-auto",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/workspace",
											search: { intent: "paste" },
											children: "Paste code"
										})
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "mt-12 overflow-hidden rounded-xl bg-elevated p-4 shadow-nijo md:mt-16 md:p-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-bg px-3 py-3 font-mono text-xs leading-relaxed text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-3 flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-danger/80" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-warning/80" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-success/80" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 text-xs uppercase tracking-[0.14em]",
											children: "index.html"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "overflow-x-auto text-xs text-fg",
									children: `<h1>Hello World</h1>
<button>Run a line of JS</button>`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-xs text-success",
									children: "Preview ready · Total: 150"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "mt-12 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: FEATURES.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl bg-elevated p-4 shadow-nijo",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(feature.icon, { className: "size-5 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-base font-medium tracking-tight",
									children: feature.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-relaxed text-muted",
									children: feature.text
								})
							]
						}, feature.title))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-border px-5 py-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Developed by Bouzidi Softworks"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-subtle",
					children: "NIJO MOBILE · Code Anywhere. Build Anywhere."
				})]
			})
		]
	});
}
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
