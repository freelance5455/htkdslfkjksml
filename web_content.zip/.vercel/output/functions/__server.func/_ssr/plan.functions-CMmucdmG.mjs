import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { n as clampRecipe } from "./recipe-CSjsxg-s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plan.functions-CMmucdmG.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SYSTEM = `You plan a single-clip video finish for an app called OneCut.
Return one JSON object and nothing else. The user has one video; you cannot add shots, reverse playback, or generate new footage.
Schema:
{
  "summary": string,
  "title": string,
  "subtitle": string,
  "grade": "neutral"|"cinematic"|"warm"|"cool"|"mono"|"bleach"|"noir"|"vivid"|"fade"|"teal",
  "speed": number,
  "trimStart": number,
  "trimEnd": number,
  "trimStartSec": number|null,
  "trimEndSec": number|null,
  "brightness": number,
  "contrast": number,
  "saturation": number,
  "vignette": number,
  "grain": number,
  "letterbox": boolean,
  "zoom": number,
  "fadeIn": number,
  "fadeOut": number,
  "titleStart": number,
  "titleEnd": number,
  "captions": [{"text": string, "start": number, "end": number}],
  "music": "none"|"pulse"|"air"|"drift"|"keys",
  "musicGain": number,
  "sourceGain": number,
  "blur": number
}
Numbers: speed 0.5–2, trims are fractions of the clip (0–1) unless trimStartSec/trimEndSec are seconds, vignette/grain 0–0.7, zoom 1–1.18, fades in seconds, musicGain 0–0.2, sourceGain 0–1.
Use a short summary, one sentence, no emoji. Empty title if they did not ask for words on screen. At most 4 short captions. Tasteful defaults. If they want it cinematic, use letterbox, a little grain, and drift.`;
function asText(content) {
	if (typeof content === "string") return content;
	if (Array.isArray(content)) return content.map((part) => {
		if (typeof part === "string") return part;
		if (part && typeof part === "object" && "text" in part) return String(part.text ?? "");
		return "";
	}).join("");
	return "";
}
function parseRecipe(raw) {
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) throw new Error("no json");
	return clampRecipe(JSON.parse(raw.slice(start, end + 1)));
}
async function complete(apiKey, prompt, jsonMode) {
	const body = {
		model: "grok-4.5",
		temperature: .3,
		max_tokens: 700,
		messages: [{
			role: "system",
			content: SYSTEM
		}, {
			role: "user",
			content: prompt
		}]
	};
	if (jsonMode) body.response_format = { type: "json_object" };
	return fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify(body),
		signal: AbortSignal.timeout(25e3)
	});
}
var planEdit_createServerFn_handler = createServerRpc({
	id: "e894b5314c69f756b79c6ed414f4e9ace06da5fd20791cfbf237fd483483ec6b",
	name: "planEdit",
	filename: "src/lib/plan.functions.ts"
}, (opts) => planEdit.__executeServer(opts));
var planEdit = createServerFn({ method: "POST" }).validator((input) => {
	const prompt = String(input?.prompt ?? "").trim();
	if (prompt.length < 2 || prompt.length > 500) throw new Error("Write a short prompt (2–500 characters).");
	return { prompt };
}).handler(planEdit_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		via: "device",
		reason: "unavailable"
	};
	let response;
	try {
		response = await complete(apiKey, data.prompt, true);
		if (response.status === 400) response = await complete(apiKey, data.prompt, false);
		else if (response.status === 429 || response.status >= 500) response = await complete(apiKey, data.prompt, true);
	} catch {
		return {
			ok: false,
			via: "device",
			reason: "unreachable"
		};
	}
	if (!response.ok) return {
		ok: false,
		via: "device",
		reason: "unavailable"
	};
	try {
		const recipe = parseRecipe(asText((await response.json()).choices?.[0]?.message?.content));
		if (!recipe.summary) recipe.summary = "Cut planned from your prompt.";
		return {
			ok: true,
			recipe,
			via: "grok"
		};
	} catch {
		return {
			ok: false,
			via: "device",
			reason: "unreadable"
		};
	}
});
//#endregion
export { planEdit_createServerFn_handler };
