import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as BatteryCharging } from "../_libs/lucide-react.mjs";
import { n as ScreenBody, t as AppShell } from "./app-shell-BNnfZJ-W.mjs";
import { i as ScreenHeader, n as InfoRow, r as Panel, t as IconBadge } from "./screen-header-3v0iR4cd.mjs";
import { i as subscribeBattery, t as formatDuration } from "./web-device-D_Jv2ve6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/battery-Cq5kBP-l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BatteryPage() {
	const [battery, setBattery] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => subscribeBattery(setBattery), []);
	const percent = battery && battery.percent >= 0 ? battery.percent : null;
	const progress = percent === null ? 0 : percent / 100;
	const charging = battery?.charging ?? false;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Battery Info",
			subtitle: "Live reading from this device. Nothing is stored or sent."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBadge, {
				className: charging ? "bg-warning/15 text-warning" : "bg-primary/15 text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatteryCharging, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-4xl font-bold tabular-nums tracking-tight text-fg",
				children: percent === null ? "—" : `${percent}%`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-sm ${charging ? "text-warning" : "text-muted"}`,
				children: battery?.statusLabel ?? "Reading battery…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 h-2.5 overflow-hidden rounded-full bg-primary/15",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `h-full rounded-full transition-[width] duration-300 ease-out ${charging ? "bg-warning" : "bg-primary"}`,
					style: { width: `${Math.round(progress * 100)}%` }
				})
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3.5 flex flex-col gap-2.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Status",
					value: battery?.statusLabel ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Power source",
					value: charging ? "Plugged in / charging" : "On battery"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Health",
					value: battery?.healthLabel ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Time to full",
					value: formatDuration(battery?.chargingTime ?? Infinity)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Time remaining",
					value: formatDuration(battery?.dischargingTime ?? Infinity)
				})
			]
		}),
		battery?.source === "unavailable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm leading-relaxed text-muted",
			children: "This browser does not expose battery APIs. The Android app reads the real battery on your phone, including health when the system provides it."
		}) : null
	] }) });
}
//#endregion
export { BatteryPage as component };
