import { i as __toESM } from "../_runtime.mjs";
import { T as require_react, w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as useAppStore, a as SESSION_TYPE_LABEL, b as formatShortDate, f as cn, g as formatDuration } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { t as Card } from "./card-ML3_y2lP.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-Ct6gxEJd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sessoes-CWj8OOno.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "Todos"
	},
	{
		id: "muay-thai",
		label: "Muay Thai"
	},
	{
		id: "superior",
		label: "Superior"
	},
	{
		id: "inferior",
		label: "Inferior + Core"
	},
	{
		id: "postura",
		label: "Postura"
	},
	{
		id: "recuperacao",
		label: "Recuperação"
	}
];
function SessionsPage() {
	const sessions = useAppStore((s) => s.sessions);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const list = (0, import_react.useMemo)(() => sessions.filter((s) => filter === "all" ? true : s.type === filter), [sessions, filter]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Histórico",
				title: "Sessões",
				subtitle: "Treinos e rotinas de postura já salvos."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-1",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(f.id),
					className: cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium", filter === f.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"),
					children: f.label
				}, f.id))
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-6 text-sm text-muted-foreground",
				children: "Nenhuma sessão neste filtro. Inicie um treino para registrar."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: list.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sessoes/$id",
					params: { id: s.id },
					className: "block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex items-center gap-3 p-4 transition-colors hover:border-primary/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: formatShortDate(s.date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display font-semibold",
										children: SESSION_TYPE_LABEL[s.type]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [
											formatDuration(s.durationSec),
											" ·",
											" ",
											s.exercises.reduce((a, e) => a + e.completedSets, 0),
											" séries"
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "success",
								children: "Concluído"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted-foreground" })
						]
					})
				}, s.id))
			})
		]
	});
}
//#endregion
export { SessionsPage as component };
