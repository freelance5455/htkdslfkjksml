import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { k as cn } from "./router-CQnHyG8o.mjs";
import { t as AddRow } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
import { t as SortableList } from "./sortable-DqnUMi7n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/check-list-Bim0RNJK.js
var import_jsx_runtime = require_jsx_runtime();
function CheckList({ items, onChange, placeholder }) {
	function update(id, patch) {
		onChange(items.map((item) => item.id === id ? {
			...item,
			...patch
		} : item));
	}
	function remove(id) {
		const prev = items;
		onChange(items.filter((item) => item.id !== id));
		toast("Removed", { action: {
			label: "Undo",
			onClick: () => onChange(prev)
		} });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableList, {
		items,
		getId: (item) => item.id,
		onReorder: onChange,
		render: (item, grip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1 rounded-lg border border-line bg-card pr-1",
			children: [
				grip,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "grid size-11 shrink-0 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: item.done,
						onChange: () => update(item.id, { done: !item.done }),
						"aria-label": item.text ? `Mark “${item.text}”` : "Mark item",
						className: "size-5 accent-accent"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: item.text,
					onChange: (event) => update(item.id, { text: event.target.value }),
					"aria-label": "Item",
					className: cn("h-11 min-w-0 flex-1 bg-transparent text-base outline-none", item.done && "text-muted line-through")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Remove item",
					onClick: () => remove(item.id),
					className: "grid size-11 shrink-0 place-items-center rounded-lg text-muted hover:text-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
						className: "size-4",
						strokeWidth: 1.6
					})
				})
			]
		})
	}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddRow, {
		placeholder,
		onAdd: (text) => onChange([...items, {
			id: uid(),
			text,
			done: false
		}])
	})] });
}
//#endregion
export { CheckList as t };
