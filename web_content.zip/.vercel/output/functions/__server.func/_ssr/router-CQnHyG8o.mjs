import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as Calendar, a as SunMedium, c as Repeat, d as Menu, f as ListChecks, i as Target, n as TriangleAlert, o as StickyNote, p as Images, s as SlidersHorizontal, t as X, u as NotebookPen, v as CalendarRange, y as CalendarDays } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { a as endOfMonth, c as addDays, i as eachDayOfInterval, n as endOfWeek, o as startOfWeek, r as startOfMonth, s as addMonths, t as format } from "../_libs/date-fns.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CQnHyG8o.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
/** Geometric five-petal mark. A motif, not an illustration. */
function Bloom({ size = 28 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 32 32",
		fill: "none",
		"aria-hidden": "true",
		children: [[
			0,
			72,
			144,
			216,
			288
		].map((deg) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
			cx: "16",
			cy: "7.6",
			rx: "2.3",
			ry: "5",
			stroke: "currentColor",
			strokeWidth: "1.2",
			transform: `rotate(${deg} 16 16)`
		}, deg)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "16",
			r: "1.8",
			fill: "currentColor"
		})]
	});
}
/** Bottom sheet on a phone, centered panel on a wider screen. */
function Modal({ open, onOpenChange, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "overlay fixed inset-0 z-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sheet-pop sheet-panel fixed inset-x-0 bottom-0 z-50 rounded-t-3xl border border-line bg-card p-4 outline-none md:inset-x-auto md:bottom-auto md:left-1/2 md:top-1/2 md:w-full md:max-w-md md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-3xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "font-display text-2xl font-medium text-balance text-ink",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: description ? "mt-1 text-sm text-pretty text-muted" : "sr-only",
						children: description ?? title
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "grid size-11 shrink-0 place-items-center rounded-full text-ink hover:bg-blush focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
						className: "size-5",
						strokeWidth: 1.6
					})
				})]
			}), children]
		})] })
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
/** Local calendar key. Never `toISOString`, which shifts the day in timezones behind UTC. */
function dayKey(d) {
	return format(d, "yyyy-MM-dd");
}
function monthKey(d) {
	return format(d, "yyyy-MM");
}
function parseDay(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y || 1970, (m || 1) - 1, d || 1);
}
function parseMonth(key) {
	const [y, m] = key.split("-").map(Number);
	return new Date(y || 1970, (m || 1) - 1, 1);
}
function shiftDay(key, delta) {
	return dayKey(addDays(parseDay(key), delta));
}
function shiftMonth(key, delta) {
	return monthKey(addMonths(parseMonth(key), delta));
}
var WEEK_OPTS = { weekStartsOn: 1 };
function weekDays(anchor) {
	const start = startOfWeek(anchor, WEEK_OPTS);
	return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}
function monthCells(anchor) {
	const start = startOfWeek(startOfMonth(anchor), WEEK_OPTS);
	const end = endOfWeek(endOfMonth(anchor), WEEK_OPTS);
	return eachDayOfInterval({
		start,
		end
	});
}
function streakEnding(checks, today) {
	let d = new Date(today.getFullYear(), today.getMonth(), today.getDate());
	if (!checks[dayKey(d)]) d = addDays(d, -1);
	let n = 0;
	while (checks[dayKey(d)]) {
		n += 1;
		d = addDays(d, -1);
		if (n > 4e3) break;
	}
	return n;
}
function sameMonth(a, b) {
	return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth();
}
function subscribe(onStoreChange) {
	const id = window.setInterval(onStoreChange, 6e4);
	return () => window.clearInterval(id);
}
/** Null during SSR so the date never mismatches hydration. */
function useTodayKey() {
	return (0, import_react.useSyncExternalStore)(subscribe, () => dayKey(/* @__PURE__ */ new Date()), () => "") || null;
}
function useDayPart() {
	const part = (0, import_react.useSyncExternalStore)(subscribe, () => {
		const hour = (/* @__PURE__ */ new Date()).getHours();
		if (hour < 12) return "morning";
		if (hour < 17) return "afternoon";
		return "evening";
	}, () => "");
	if (part === "morning" || part === "afternoon" || part === "evening") return part;
	return null;
}
function greetingFor(part, name) {
	const who = name.trim();
	const hello = part === "morning" ? "Good morning" : part === "afternoon" ? "Good afternoon" : part === "evening" ? "Good evening" : "Hello";
	return who ? `${hello}, ${who}` : hello;
}
/** Domain model for Solenne. All of it lives in localStorage — no accounts. */
var SECTIONS = [
	{
		id: "today",
		label: "Today",
		href: "/",
		group: "Plan"
	},
	{
		id: "week",
		label: "Week",
		href: "/week",
		group: "Plan"
	},
	{
		id: "month",
		label: "Month",
		href: "/month",
		group: "Plan"
	},
	{
		id: "year",
		label: "Year",
		href: "/year",
		group: "Plan"
	},
	{
		id: "goals",
		label: "Goals",
		href: "/goals",
		group: "Practice"
	},
	{
		id: "habits",
		label: "Habits",
		href: "/habits",
		group: "Practice"
	},
	{
		id: "tasks",
		label: "Tasks",
		href: "/tasks",
		group: "Practice"
	},
	{
		id: "notes",
		label: "Notes",
		href: "/notes",
		group: "Reflect"
	},
	{
		id: "notebook",
		label: "Notebook",
		href: "/notebook",
		group: "Reflect"
	},
	{
		id: "vision",
		label: "Vision",
		href: "/vision",
		group: "Reflect"
	}
];
/** Dusty, paper-friendly defaults for month ribbons and the "vary tabs" action. */
var MONTH_TONES = [
	"#a85d68",
	"#5f7a5c",
	"#b08968",
	"#8d6e78"
];
var TAB_HARMONY = {
	today: "#a85d68",
	week: "#5f7a5c",
	month: "#b08968",
	year: "#8d6e78",
	goals: "#9a5c56",
	habits: "#5f7a5c",
	tasks: "#8a6a4f",
	notes: "#7d6a78",
	notebook: "#6d7c84",
	vision: "#a86b7a"
};
var VISION_SWATCHES = [
	"#f3e4e1",
	"#e5eee2",
	"#f6ebe3",
	"#efe6e4",
	"#e7eef2",
	"#f3efe6"
];
var MOODS = [
	{
		label: "Still",
		hint: "Heavy, slow"
	},
	{
		label: "Soft",
		hint: "A little low"
	},
	{
		label: "Even",
		hint: "Steady"
	},
	{
		label: "Light",
		hint: "Open"
	},
	{
		label: "Full",
		hint: "Bright"
	}
];
var CSS_VARS = [
	["paper", "--color-paper"],
	["card", "--color-card"],
	["ink", "--color-ink"],
	["muted", "--color-muted"],
	["line", "--color-line"],
	["accent", "--color-accent"],
	["accentFg", "--color-accent-fg"],
	["blush", "--color-blush"],
	["sage", "--color-sage"],
	["sageSoft", "--color-sage-soft"]
];
function rgb(hex) {
	const h = hex.replace("#", "");
	const n = Number.parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
	return [
		n >> 16 & 255,
		n >> 8 & 255,
		n & 255
	];
}
function hex(channels) {
	return `#${channels.map((c) => Math.max(0, Math.min(255, Math.round(c))).toString(16).padStart(2, "0")).join("")}`;
}
function channel(c) {
	const s = c / 255;
	return s <= .04045 ? s / 12.92 : ((s + .055) / 1.055) ** 2.4;
}
function luminance(color) {
	const [r, g, b] = rgb(color);
	return .2126 * channel(r) + .7152 * channel(g) + .0722 * channel(b);
}
/** `t` is how far to walk from `a` toward `b`. */
function mix(a, b, t) {
	const A = rgb(a);
	const B = rgb(b);
	return hex(A.map((v, i) => v + ((B[i] ?? v) - v) * t));
}
function contrastFg(bg) {
	return luminance(bg) > .45 ? "#2c2420" : "#fffaf7";
}
/** Text color that stays readable on a user-chosen swatch. */
function inkOn(bg) {
	return luminance(bg) > .62 ? "#3c332e" : "#fffaf7";
}
function isHex(value) {
	return /^#[0-9a-fA-F]{6}$/.test(value);
}
function derive(paper, accent) {
	const dark = luminance(paper) < .42;
	const ink = dark ? "#f6f1ea" : "#3c332e";
	return {
		paper,
		card: mix(paper, "#ffffff", dark ? .08 : .62),
		ink,
		muted: mix(ink, paper, dark ? .38 : .42),
		line: mix(ink, paper, dark ? .78 : .86),
		accent,
		accentFg: contrastFg(accent),
		blush: mix(accent, paper, dark ? .74 : .86),
		sage: dark ? "#b7c7ae" : "#5f7a5c",
		sageSoft: mix(dark ? "#b7c7ae" : "#5f7a5c", paper, dark ? .78 : .88)
	};
}
var PALETTES = {
	petal: {
		name: "Petal",
		hint: "Warm ivory, dusty rose",
		colors: {
			paper: "#f4efe8",
			card: "#fffcf8",
			ink: "#3c332e",
			muted: "#74655d",
			line: "#e4d6cc",
			accent: "#a85d68",
			accentFg: "#fffaf7",
			blush: "#f4e3e0",
			sage: "#5f7a5c",
			sageSoft: "#e5eee2"
		}
	},
	linen: {
		name: "Linen",
		hint: "Pale olive paper",
		colors: {
			paper: "#eef1e8",
			card: "#fbfcf7",
			ink: "#2e3428",
			muted: "#5e6858",
			line: "#d5decc",
			accent: "#5f7a52",
			accentFg: "#f7faf4",
			blush: "#e3eadb",
			sage: "#3f5c45",
			sageSoft: "#e4eedc"
		}
	},
	dusk: {
		name: "Dusk",
		hint: "Evening brown, blush type",
		colors: {
			paper: "#241c1a",
			card: "#2e2522",
			ink: "#f6f0ea",
			muted: "#cbb9b0",
			line: "#433833",
			accent: "#e0a8a4",
			accentFg: "#2a1c1a",
			blush: "#3a2c2a",
			sage: "#b7c7ae",
			sageSoft: "#2c332b"
		}
	},
	porcelain: {
		name: "Porcelain",
		hint: "Cool white, clay accent",
		colors: {
			paper: "#f7f5f2",
			card: "#ffffff",
			ink: "#2c2a28",
			muted: "#6f6a64",
			line: "#e6e1da",
			accent: "#9a5c56",
			accentFg: "#fffaf8",
			blush: "#f3e6e3",
			sage: "#617566",
			sageSoft: "#e6eee8"
		}
	}
};
function defaultTabs(accent) {
	return SECTIONS.reduce((acc, section) => {
		acc[section.id] = accent;
		return acc;
	}, {});
}
function defaultTheme() {
	return {
		paletteId: "petal",
		...PALETTES.petal.colors,
		floral: "soft",
		tabs: defaultTabs(PALETTES.petal.colors.accent)
	};
}
function monthTone(key, saved) {
	if (saved && isHex(saved)) return saved;
	const month = Number(key.slice(5, 7)) || 1;
	const year = Number(key.slice(0, 4)) || 0;
	return MONTH_TONES[(month - 1 + year) % MONTH_TONES.length] ?? MONTH_TONES[0];
}
/** Paint CSS variables. Called after hydration and whenever the studio changes. */
function applyTheme(theme) {
	const root = document.documentElement;
	for (const [key, name] of CSS_VARS) root.style.setProperty(name, theme[key]);
	root.dataset.floral = theme.floral;
	root.style.colorScheme = luminance(theme.paper) < .42 ? "dark" : "light";
	document.querySelector("meta[name=\"theme-color\"]")?.setAttribute("content", theme.paper);
}
function safeHttpUrl(value) {
	const trimmed = value.trim();
	if (!trimmed) return "";
	try {
		const url = new URL(trimmed);
		if (url.protocol === "https:" || url.protocol === "http:") return url.toString();
	} catch {
		return "";
	}
	return "";
}
/** Runs before paint so a saved palette does not flash ivory. */
var THEME_BOOT = `(function(){try{var raw=localStorage.getItem("solenne");if(!raw)return;var t=JSON.parse(raw).state.theme;if(!t||typeof t.paper!=="string")return;var s=document.documentElement.style;var m={paper:"--color-paper",card:"--color-card",ink:"--color-ink",muted:"--color-muted",line:"--color-line",accent:"--color-accent",accentFg:"--color-accent-fg",blush:"--color-blush",sage:"--color-sage",sageSoft:"--color-sage-soft"};Object.keys(m).forEach(function(k){if(typeof t[k]==="string")s.setProperty(m[k],t[k]);});if(t.floral)document.documentElement.dataset.floral=t.floral;var meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.setAttribute("content",t.paper);}catch(e){}})();`;
var FLORAL_OPTIONS = [
	{
		value: "off",
		label: "Off"
	},
	{
		value: "soft",
		label: "Soft"
	},
	{
		value: "bloom",
		label: "Bloom"
	}
];
function blankDay() {
	return {
		intention: "",
		gratitude: [
			"",
			"",
			""
		],
		priorities: [],
		schedule: [],
		mood: null,
		water: 0,
		journal: "",
		affirmation: ""
	};
}
function readDay(days, id) {
	const found = days[id];
	if (!found) return blankDay();
	const g = found.gratitude ?? [
		"",
		"",
		""
	];
	return {
		...blankDay(),
		...found,
		gratitude: [
			g[0] ?? "",
			g[1] ?? "",
			g[2] ?? ""
		],
		priorities: found.priorities ?? [],
		schedule: found.schedule ?? []
	};
}
function blankWeek() {
	return {
		focus: "",
		priorities: [],
		dayNotes: {},
		worked: "",
		carry: ""
	};
}
function readWeek(weeks, id) {
	const found = weeks[id];
	if (!found) return blankWeek();
	return {
		...blankWeek(),
		...found,
		dayNotes: found.dayNotes ?? {},
		priorities: found.priorities ?? []
	};
}
function blankMonth(key) {
	return {
		intention: "",
		color: monthTone(key),
		events: []
	};
}
function readMonth(months, id) {
	const found = months[id];
	if (!found) return blankMonth(id);
	return {
		...blankMonth(id),
		...found,
		events: found.events ?? [],
		color: found.color || monthTone(id)
	};
}
function blankYear() {
	return {
		word: "",
		note: "",
		quarters: [
			{
				q: 1,
				intention: ""
			},
			{
				q: 2,
				intention: ""
			},
			{
				q: 3,
				intention: ""
			},
			{
				q: 4,
				intention: ""
			}
		]
	};
}
function readYear(years, id) {
	const found = years[id];
	if (!found) return blankYear();
	const base = blankYear();
	return {
		...base,
		...found,
		quarters: base.quarters.map((q, i) => found.quarters?.[i] ?? q)
	};
}
var emptyCollections = {
	days: {},
	weeks: {},
	months: {},
	years: {},
	goals: [],
	habits: [],
	lists: [],
	tasks: [],
	notes: [],
	notebooks: [],
	pages: [],
	visions: [],
	dream: ""
};
function emptyContent() {
	return {
		samplesOn: false,
		...emptyCollections
	};
}
/** Stable ids so server and client render the same first page. */
function sampleContent() {
	return {
		samplesOn: true,
		days: {},
		weeks: {},
		months: {},
		years: {},
		dream: "More light in the mornings. Work that feels like mine. Evenings that actually end.",
		goals: [{
			id: "goal-1",
			title: "Finish the writing course",
			area: "Craft",
			why: "A finished piece, not another abandoned notebook.",
			progress: 35,
			deadline: "",
			status: "active",
			milestones: [
				{
					id: "ms-1",
					text: "Module three",
					done: true
				},
				{
					id: "ms-2",
					text: "Draft the final essay",
					done: false
				},
				{
					id: "ms-3",
					text: "Read it aloud once",
					done: false
				}
			]
		}, {
			id: "goal-2",
			title: "A calmer evening",
			area: "Body",
			why: "The day should have an ending.",
			progress: 20,
			deadline: "",
			status: "active",
			milestones: [{
				id: "ms-4",
				text: "Phone in another room after nine",
				done: false
			}, {
				id: "ms-5",
				text: "A lamp, not the overhead light",
				done: true
			}]
		}],
		habits: [
			{
				id: "habit-1",
				name: "Morning pages",
				color: "#a85d68",
				checks: {}
			},
			{
				id: "habit-2",
				name: "Move gently",
				color: "#5f7a5c",
				checks: {}
			},
			{
				id: "habit-3",
				name: "A real lunch",
				color: "#b08968",
				checks: {}
			},
			{
				id: "habit-4",
				name: "Lights down",
				color: "#8d6e78",
				checks: {}
			}
		],
		lists: [
			{
				id: "list-today",
				name: "Today",
				color: "#a85d68"
			},
			{
				id: "list-home",
				name: "Home",
				color: "#5f7a5c"
			},
			{
				id: "list-soon",
				name: "Soon",
				color: "#b08968"
			}
		],
		tasks: [
			{
				id: "task-1",
				listId: "list-today",
				text: "Write the morning pages",
				done: false,
				priority: "high",
				due: ""
			},
			{
				id: "task-2",
				listId: "list-today",
				text: "Step outside before noon",
				done: false,
				priority: "medium",
				due: ""
			},
			{
				id: "task-3",
				listId: "list-home",
				text: "Water the jasmine",
				done: false,
				priority: "low",
				due: ""
			},
			{
				id: "task-4",
				listId: "list-soon",
				text: "Plan a slow Sunday",
				done: false,
				priority: "low",
				due: ""
			}
		],
		notes: [{
			id: "note-1",
			title: "Market",
			body: "Figs\nGood bread\nTulips, if they look awake",
			pinned: true,
			updated: 2
		}, {
			id: "note-2",
			title: "Sentences I liked",
			body: "She kept the afternoon open on purpose.",
			pinned: false,
			updated: 1
		}],
		notebooks: [{
			id: "book-1",
			title: "Field notes",
			color: "#a85d68"
		}, {
			id: "book-2",
			title: "Letters",
			color: "#5f7a5c"
		}],
		pages: [
			{
				id: "page-1",
				notebookId: "book-1",
				title: "Begin",
				style: "dotted",
				content: "Write in the margin of the day.\n\nWhat are you unwilling to rush?",
				updated: 2
			},
			{
				id: "page-2",
				notebookId: "book-1",
				title: "Lists",
				style: "lined",
				content: "",
				updated: 1
			},
			{
				id: "page-3",
				notebookId: "book-2",
				title: "Unsent",
				style: "grid",
				content: "",
				updated: 1
			}
		],
		visions: [
			{
				id: "vis-1",
				title: "A sunlit desk",
				caption: "A chair that fits. A window. One beautiful pen.",
				area: "Craft",
				tone: "#f3e4e1",
				imageUrl: ""
			},
			{
				id: "vis-2",
				title: "Weekends without rushing",
				caption: "Bread, a long walk, nowhere to be by ten.",
				area: "Inner",
				tone: "#e5eee2",
				imageUrl: ""
			},
			{
				id: "vis-3",
				title: "Strength that feels like ease",
				caption: "Strong enough for the ordinary days.",
				area: "Body",
				tone: "#f6ebe3",
				imageUrl: ""
			},
			{
				id: "vis-4",
				title: "A trip with no itinerary",
				caption: "One city, slow trains, a book I finish.",
				area: "Wander",
				tone: "#e7eef2",
				imageUrl: ""
			}
		]
	};
}
function initialData() {
	return {
		name: "",
		theme: defaultTheme(),
		...sampleContent()
	};
}
function mapById(items, id, patch) {
	return items.map((item) => item.id === id ? {
		...item,
		...patch
	} : item);
}
var usePlanner = create()(persist((set) => ({
	...initialData(),
	setName: (name) => set({ name }),
	dismissSamples: () => set({ samplesOn: false }),
	setTheme: (patch) => set((s) => ({ theme: {
		...s.theme,
		...patch
	} })),
	applyPalette: (id) => set((s) => ({ theme: {
		...s.theme,
		...PALETTES[id].colors,
		paletteId: id
	} })),
	setPaper: (paper) => set((s) => {
		if (!isHex(paper)) return s;
		return { theme: {
			...s.theme,
			...derive(paper, s.theme.accent),
			paletteId: "custom",
			floral: s.theme.floral,
			tabs: s.theme.tabs
		} };
	}),
	setAccent: (accent) => set((s) => {
		if (!isHex(accent)) return s;
		const next = derive(s.theme.paper, accent);
		return { theme: {
			...s.theme,
			accent: next.accent,
			accentFg: next.accentFg,
			blush: next.blush,
			paletteId: "custom"
		} };
	}),
	setTabColor: (id, color) => set((s) => {
		if (!isHex(color)) return s;
		return { theme: {
			...s.theme,
			tabs: {
				...s.theme.tabs,
				[id]: color
			}
		} };
	}),
	unifyTabs: () => set((s) => ({ theme: {
		...s.theme,
		tabs: defaultTabs(s.theme.accent)
	} })),
	varyTabs: () => set((s) => ({ theme: {
		...s.theme,
		tabs: { ...TAB_HARMONY }
	} })),
	patchDay: (id, recipe) => set((s) => ({ days: {
		...s.days,
		[id]: recipe(readDay(s.days, id))
	} })),
	patchWeek: (id, recipe) => set((s) => ({ weeks: {
		...s.weeks,
		[id]: recipe(readWeek(s.weeks, id))
	} })),
	patchMonth: (id, recipe) => set((s) => ({ months: {
		...s.months,
		[id]: recipe(readMonth(s.months, id))
	} })),
	patchYear: (id, recipe) => set((s) => ({ years: {
		...s.years,
		[id]: recipe(readYear(s.years, id))
	} })),
	addGoal: (goal) => set((s) => ({ goals: [goal, ...s.goals] })),
	updateGoal: (id, patch) => set((s) => ({ goals: mapById(s.goals, id, patch) })),
	setGoals: (goals) => set({ goals }),
	addHabit: (habit) => set((s) => ({ habits: [...s.habits, habit] })),
	updateHabit: (id, patch) => set((s) => ({ habits: mapById(s.habits, id, patch) })),
	toggleHabit: (id, date) => set((s) => ({ habits: s.habits.map((habit) => habit.id === id ? {
		...habit,
		checks: {
			...habit.checks,
			[date]: !habit.checks[date]
		}
	} : habit) })),
	setHabits: (habits) => set({ habits }),
	addList: (list) => set((s) => ({ lists: [...s.lists, list] })),
	updateList: (id, patch) => set((s) => ({ lists: mapById(s.lists, id, patch) })),
	deleteList: (id) => set((s) => ({
		lists: s.lists.filter((list) => list.id !== id),
		tasks: s.tasks.filter((task) => task.listId !== id)
	})),
	addTask: (task) => set((s) => ({ tasks: [...s.tasks, task] })),
	updateTask: (id, patch) => set((s) => ({ tasks: mapById(s.tasks, id, patch) })),
	setTasks: (tasks) => set({ tasks }),
	addNote: (note) => set((s) => ({ notes: [note, ...s.notes] })),
	updateNote: (id, patch) => set((s) => ({ notes: mapById(s.notes, id, patch) })),
	deleteNote: (id) => set((s) => ({ notes: s.notes.filter((note) => note.id !== id) })),
	addNotebook: (book) => set((s) => ({ notebooks: [...s.notebooks, book] })),
	updateNotebook: (id, patch) => set((s) => ({ notebooks: mapById(s.notebooks, id, patch) })),
	deleteNotebook: (id) => set((s) => ({
		notebooks: s.notebooks.filter((book) => book.id !== id),
		pages: s.pages.filter((page) => page.notebookId !== id)
	})),
	addPage: (page) => set((s) => ({ pages: [...s.pages, page] })),
	updatePage: (id, patch) => set((s) => ({ pages: mapById(s.pages, id, patch) })),
	deletePage: (id) => set((s) => ({ pages: s.pages.filter((page) => page.id !== id) })),
	setPages: (pages) => set({ pages }),
	setDream: (dream) => set({ dream }),
	addVision: (card) => set((s) => ({ visions: [card, ...s.visions] })),
	updateVision: (id, patch) => set((s) => ({ visions: mapById(s.visions, id, patch) })),
	deleteVision: (id) => set((s) => ({ visions: s.visions.filter((card) => card.id !== id) })),
	setVisions: (visions) => set({ visions }),
	clearContent: () => set((s) => ({
		...emptyContent(),
		name: s.name,
		theme: s.theme
	})),
	restoreSamples: () => set((s) => ({
		...sampleContent(),
		name: s.name,
		theme: s.theme
	})),
	replaceData: (data) => set(data)
}), {
	name: "solenne",
	version: 1,
	skipHydration: true
}));
function snapshot() {
	const s = usePlanner.getState();
	return {
		name: s.name,
		samplesOn: s.samplesOn,
		theme: s.theme,
		days: s.days,
		weeks: s.weeks,
		months: s.months,
		years: s.years,
		goals: s.goals,
		habits: s.habits,
		lists: s.lists,
		tasks: s.tasks,
		notes: s.notes,
		notebooks: s.notebooks,
		pages: s.pages,
		visions: s.visions,
		dream: s.dream
	};
}
var ICONS = {
	today: SunMedium,
	week: CalendarDays,
	month: Calendar,
	year: CalendarRange,
	goals: Target,
	habits: Repeat,
	tasks: ListChecks,
	notes: StickyNote,
	notebook: NotebookPen,
	vision: Images,
	studio: SlidersHorizontal
};
var DOCK = [
	"today",
	"week",
	"tasks",
	"vision"
];
var MORE = /* @__PURE__ */ new Set([
	"/month",
	"/year",
	"/goals",
	"/habits",
	"/notes",
	"/notebook",
	"/studio"
]);
function activePath(href, path) {
	return href === "/" ? path === "/" : path === href;
}
function Shell({ children }) {
	const path = useRouterState({ select: (s) => s.location.pathname });
	const name = usePlanner((s) => s.name);
	const tabs = usePlanner((s) => s.theme.tabs);
	const today = useTodayKey();
	const [more, setMore] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let unsubscribe = () => {};
		Promise.resolve(usePlanner.persist.rehydrate()).then(() => {
			applyTheme(usePlanner.getState().theme);
			unsubscribe = usePlanner.subscribe((state, prev) => {
				if (state.theme !== prev.theme) applyTheme(state.theme);
			});
		});
		return () => unsubscribe();
	}, []);
	(0, import_react.useEffect)(() => {
		window.scrollTo(0, 0);
		setMore(false);
	}, [path]);
	const moreActive = MORE.has(path);
	const dateLabel = today ? format(parseDay(today), "EEEE d MMMM") : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "floral-layer pointer-events-none fixed inset-0 z-0",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "floral-mark pointer-events-none fixed z-0 text-accent",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bloom, { size: 280 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto flex min-h-dvh w-full max-w-6xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-line px-3 py-6 md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 flex items-center gap-3 px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bloom, { size: 32 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-display text-2xl leading-none font-medium text-ink",
									children: name.trim() || "Solenne"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 truncate text-sm text-muted",
									children: name.trim() ? "Solenne" : "A quiet planner"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							"aria-label": "Sections",
							className: "grid content-start gap-1",
							children: SECTIONS.map((section, index) => {
								const prev = SECTIONS[index - 1];
								const showGroup = !prev || prev.group !== section.group;
								const Icon = ICONS[section.id];
								const on = activePath(section.href, path);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [showGroup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("mb-1 px-3 text-xs font-medium tracking-wide text-muted", index > 0 && "mt-4"),
									children: section.group
								}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: section.href,
									className: cn("flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium", on ? "bg-blush text-ink" : "text-ink hover:bg-blush"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-2 shrink-0 rounded-full",
											style: { background: tabs[section.id] }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-4 text-muted",
											strokeWidth: 1.6
										}),
										section.label
									]
								})] }, section.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/studio",
							className: cn("mt-auto flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium", path === "/studio" ? "bg-blush" : "hover:bg-blush"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
								className: "size-4",
								strokeWidth: 1.6
							}), "Studio"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
						className: "pt-safe sticky top-0 z-20 border-b border-line bg-paper md:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-14 items-center justify-between px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-accent",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bloom, { size: 26 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-display text-xl leading-none font-medium",
										children: name.trim() || "Solenne"
									}), dateLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted",
										children: dateLabel
									}) : null]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/studio",
								"aria-label": "Studio",
								className: "grid size-11 place-items-center rounded-full hover:bg-blush",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
									className: "size-5",
									strokeWidth: 1.6
								})
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "mx-auto w-full max-w-3xl flex-1 px-4 pt-5 pb-dock md:px-8 md:pt-8 md:pb-16",
						children
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Primary",
				className: "dock fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-lg",
					children: [DOCK.map((id) => {
						const section = SECTIONS.find((item) => item.id === id);
						if (!section) return null;
						const Icon = ICONS[id];
						const on = activePath(section.href, path);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: section.href,
							className: cn("flex h-16 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium", on ? "text-ink" : "text-muted"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-0.5 h-0.5 w-4 rounded-full",
									style: { background: on ? tabs[id] : "transparent" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									strokeWidth: 1.6
								}),
								section.label
							]
						}, id);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-expanded": more,
						onClick: () => setMore(true),
						className: cn("flex h-16 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium", moreActive ? "text-ink" : "text-muted"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-0.5 h-0.5 w-4 rounded-full",
								style: { background: moreActive ? "var(--color-accent)" : "transparent" }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
								className: "size-5",
								strokeWidth: 1.6
							}),
							"More"
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: more,
				onOpenChange: setMore,
				title: "Sections",
				description: "The rest of the planner.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "grid gap-1",
					children: [SECTIONS.filter((section) => !DOCK.includes(section.id)).map((section) => {
						const Icon = ICONS[section.id];
						const on = activePath(section.href, path);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: section.href,
							className: cn("flex h-12 items-center gap-3 rounded-lg px-2 text-base", on && "bg-blush"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-2.5 rounded-full",
									style: { background: tabs[section.id] }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4 text-muted",
									strokeWidth: 1.6
								}),
								section.label
							]
						}, section.id);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/studio",
						className: cn("flex h-12 items-center gap-3 rounded-lg px-2 text-base", path === "/studio" && "bg-blush"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
							className: "size-4",
							strokeWidth: 1.6
						}), "Studio"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "top-center" })
		]
	});
}
var styles_default = "/assets/styles-BSP6y1Xe.css";
var Route$11 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Solenne" },
			{
				name: "description",
				content: "Solenne is a quiet life planner for days, habits, goals, notes, and the life you are growing."
			},
			{
				name: "theme-color",
				content: "#f4efe8"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: THEME_BOOT } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-paper font-sans text-ink antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$10 = () => import("./routes-dGCSNnUT.mjs");
var Route$10 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./goals-CX31odND.mjs");
var Route$9 = createFileRoute("/goals")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./habits-0E0DAuHB.mjs");
var Route$8 = createFileRoute("/habits")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./month-tH2MiuDx.mjs");
var Route$7 = createFileRoute("/month")({
	validateSearch: (search) => ({ m: typeof search.m === "string" && /^\d{4}-\d{2}$/.test(search.m) ? search.m : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./notebook-B7-cEJ2F.mjs");
var Route$6 = createFileRoute("/notebook")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./notes-BK67lqG8.mjs");
var Route$5 = createFileRoute("/notes")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./studio-DQ1dv3IT.mjs");
var Route$4 = createFileRoute("/studio")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./tasks-Db1uMiKZ.mjs");
var Route$3 = createFileRoute("/tasks")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./vision-CbScHso-.mjs");
var Route$2 = createFileRoute("/vision")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./week-BfSpNrwa.mjs");
var Route$1 = createFileRoute("/week")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./year-DJvlKdJ7.mjs");
var Route = createFileRoute("/year")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$10.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$11
	}),
	GoalsRoute: Route$9.update({
		id: "/goals",
		path: "/goals",
		getParentRoute: () => Route$11
	}),
	HabitsRoute: Route$8.update({
		id: "/habits",
		path: "/habits",
		getParentRoute: () => Route$11
	}),
	MonthRoute: Route$7.update({
		id: "/month",
		path: "/month",
		getParentRoute: () => Route$11
	}),
	NotebookRoute: Route$6.update({
		id: "/notebook",
		path: "/notebook",
		getParentRoute: () => Route$11
	}),
	NotesRoute: Route$5.update({
		id: "/notes",
		path: "/notes",
		getParentRoute: () => Route$11
	}),
	StudioRoute: Route$4.update({
		id: "/studio",
		path: "/studio",
		getParentRoute: () => Route$11
	}),
	TasksRoute: Route$3.update({
		id: "/tasks",
		path: "/tasks",
		getParentRoute: () => Route$11
	}),
	VisionRoute: Route$2.update({
		id: "/vision",
		path: "/vision",
		getParentRoute: () => Route$11
	}),
	WeekRoute: Route$1.update({
		id: "/week",
		path: "/week",
		getParentRoute: () => Route$11
	}),
	YearRoute: Route.update({
		id: "/year",
		path: "/year",
		getParentRoute: () => Route$11
	})
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Modal as A, parseMonth as C, streakEnding as D, shiftMonth as E, weekDays as O, parseDay as S, shiftDay as T, useDayPart as _, FLORAL_OPTIONS as a, monthCells as b, PALETTES as c, inkOn as d, isHex as f, greetingFor as g, SECTIONS as h, usePlanner as i, cn as k, VISION_SWATCHES as l, safeHttpUrl as m, Route$7 as n, MONTH_TONES as o, monthTone as p, snapshot as r, MOODS as s, router_exports as t, defaultTheme as u, useTodayKey as v, sameMonth as w, monthKey as x, dayKey as y };
