import { t as createServerFn } from "./ssr.mjs";
import { a as GoogleDriveTools, i as GoogleCalendarTools, r as ConnectorType } from "./types-D3FEuKtl.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { a as subtitleOf, i as stringifyToolData, n as classifyCallToolError, o as titleOf, r as idOf, t as asRecordArray } from "./normalize-6SyGCqa5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-CrRvgI9M.js
var MODEL = "grok-4.5";
var MAX_ROUNDS = 3;
var MAX_TOKENS = 1400;
var TOOLS = [
	{
		grokName: "search_files",
		description: "Search the user's Google Drive for files, docs, sheets, and folders. Use Drive query syntax when helpful (name contains, mimeType, modifiedTime).",
		parameters: {
			type: "object",
			properties: { query: {
				type: "string",
				description: "Search query, e.g. name contains 'budget' or full text terms."
			} },
			required: ["query"]
		},
		connectorType: ConnectorType.GoogleDrive,
		toolName: GoogleDriveTools.search,
		kind: "drive",
		mapArgs: (raw) => ({ q: String(raw.query ?? raw.q ?? "") })
	},
	{
		grokName: "read_file",
		description: "Read the contents of a Google Drive file by its file id.",
		parameters: {
			type: "object",
			properties: { file_id: {
				type: "string",
				description: "Google Drive file id"
			} },
			required: ["file_id"]
		},
		connectorType: ConnectorType.GoogleDrive,
		toolName: GoogleDriveTools.readFile,
		kind: "drive",
		mapArgs: (raw) => ({ file_id: String(raw.file_id ?? raw.fileId ?? raw.id ?? "") })
	},
	{
		grokName: "list_folder",
		description: "List files in a Google Drive folder. Omit folder_id to list the user's Drive root.",
		parameters: {
			type: "object",
			properties: { folder_id: {
				type: "string",
				description: "Folder id, optional"
			} }
		},
		connectorType: ConnectorType.GoogleDrive,
		toolName: GoogleDriveTools.listFolder,
		kind: "drive",
		mapArgs: (raw) => {
			const id = raw.folder_id ?? raw.folderId;
			return id ? { folder_id: String(id) } : {};
		}
	},
	{
		grokName: "search_mail",
		description: "Search the user's Gmail. Supports Gmail operators such as from:, to:, subject:, newer_than:, has:attachment, is:unread.",
		parameters: {
			type: "object",
			properties: { query: {
				type: "string",
				description: "Gmail search query"
			} },
			required: ["query"]
		},
		connectorType: ConnectorType.Gmail,
		toolName: "gmail_search",
		kind: "gmail",
		mapArgs: (raw) => ({ query: String(raw.query ?? raw.q ?? "") })
	},
	{
		grokName: "read_mail",
		description: "Read a full Gmail message by id.",
		parameters: {
			type: "object",
			properties: { message_id: { type: "string" } },
			required: ["message_id"]
		},
		connectorType: ConnectorType.Gmail,
		toolName: "gmail_read_message",
		kind: "gmail",
		mapArgs: (raw) => ({ message_id: String(raw.message_id ?? raw.messageId ?? raw.id ?? "") })
	},
	{
		grokName: "search_calendar",
		description: "Search Google Calendar events in a time window. Use ISO timestamps for time_min and time_max.",
		parameters: {
			type: "object",
			properties: {
				query: { type: "string" },
				time_min: { type: "string" },
				time_max: { type: "string" }
			}
		},
		connectorType: ConnectorType.GoogleCalendar,
		toolName: GoogleCalendarTools.search,
		kind: "calendar",
		mapArgs: (raw) => {
			const args = {};
			const q = raw.query ?? raw.q;
			if (q) args.query = String(q);
			if (raw.time_min ?? raw.timeMin) args.time_min = String(raw.time_min ?? raw.timeMin);
			if (raw.time_max ?? raw.timeMax) args.time_max = String(raw.time_max ?? raw.timeMax);
			return args;
		}
	},
	{
		grokName: "get_event",
		description: "Get a single Google Calendar event by id.",
		parameters: {
			type: "object",
			properties: { event_id: { type: "string" } },
			required: ["event_id"]
		},
		connectorType: ConnectorType.GoogleCalendar,
		toolName: GoogleCalendarTools.getEvent,
		kind: "calendar",
		mapArgs: (raw) => ({ event_id: String(raw.event_id ?? raw.eventId ?? raw.id ?? "") })
	},
	{
		grokName: "check_availability",
		description: "Check free/busy availability on Google Calendar between two ISO times.",
		parameters: {
			type: "object",
			properties: {
				time_min: { type: "string" },
				time_max: { type: "string" }
			},
			required: ["time_min", "time_max"]
		},
		connectorType: ConnectorType.GoogleCalendar,
		toolName: GoogleCalendarTools.availability,
		kind: "calendar",
		mapArgs: (raw) => ({
			time_min: String(raw.time_min ?? raw.timeMin ?? ""),
			time_max: String(raw.time_max ?? raw.timeMax ?? "")
		})
	}
];
var grokTools = TOOLS.map((tool) => ({
	type: "function",
	function: {
		name: tool.grokName,
		description: tool.description,
		parameters: tool.parameters
	}
}));
function sourcesFromResult(kind, data) {
	return asRecordArray(data).slice(0, 6).map((item) => ({
		kind,
		title: titleOf(item),
		subtitle: subtitleOf(item),
		id: idOf(item)
	}));
}
function formatToolResult(result) {
	if (result.pending) return JSON.stringify({
		status: "pending",
		message: "Connector token is still arriving. Ask the user to retry in a moment."
	});
	const classified = classifyCallToolError(result);
	if (classified) return JSON.stringify({
		status: classified.kind,
		message: classified.message,
		detail: classified.detail
	});
	return stringifyToolData(result.data);
}
function systemPrompt(input) {
	return `You are Mira, a calm personal assistant. You help the user with their own files, mail, calendar, and the notes they share.

Current time: ${input.nowISO ?? (/* @__PURE__ */ new Date()).toISOString()} (${input.timeZone ?? "UTC"}).

You can call tools to search Google Drive, read Drive files, search Gmail, and inspect Google Calendar — but only when the user has connected those sources in Grok. If a tool returns not_connected, login, pending, or an error, tell the user plainly. Direct them to connect the service in Grok (grok.com/connectors). Never invent emails, files, events, or quotes.

This is a web app. You cannot silently read a phone's contacts, SMS, photos, or full storage. You only see:
- Cloud data returned by tools
- Files, photos, location, or contacts the user attached to this message
- Conversation history

Be concise, specific, and useful. Prefer short sections over long essays. When you use a source, mention it by title. If the question is general knowledge and does not need their data, answer directly without tools.`;
}
function buildUserContent(input) {
	const parts = [input.messages.filter((m) => m.role === "user").at(-1)?.content ?? ""];
	if (input.attachments?.length) {
		parts.push("\n\nAttached from this device:");
		for (const file of input.attachments) if (file.text) parts.push(`\n\n--- ${file.name} (${file.mime}) ---\n${file.text.slice(0, 12e3)}`);
		else if (file.dataUrl) parts.push(`\n\n[Image attached: ${file.name}]`);
		else parts.push(`\n\n[File attached: ${file.name} (${file.mime}) — contents not readable as text]`);
	}
	if (input.location) parts.push(`\n\nShared device location: ${input.location.lat.toFixed(5)}, ${input.location.lng.toFixed(5)}`);
	if (input.contacts?.length) {
		const lines = input.contacts.map((c) => [
			c.name,
			c.email,
			c.tel
		].filter(Boolean).join(" · ")).join("\n");
		parts.push(`\n\nShared contacts:\n${lines}`);
	}
	const images = (input.attachments ?? []).map((a) => a.dataUrl).filter((url) => Boolean(url)).slice(0, 2);
	return {
		text: parts.join(""),
		images
	};
}
async function grokChat(apiKey, messages, withTools) {
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: MODEL,
			messages,
			max_tokens: MAX_TOKENS,
			temperature: .4,
			...withTools ? {
				tools: grokTools,
				tool_choice: "auto"
			} : {}
		})
	});
	const body = await res.json();
	if (!res.ok) {
		const msg = body.error?.message ?? `xAI API error ${res.status}`;
		throw new Error(msg);
	}
	return body;
}
var askMira_createServerFn_handler = createServerRpc({
	id: "aec57251f15771aaec0c20a3ce45c971e4681551268e15917ccf6d6f7b7e1c20",
	name: "askMira",
	filename: "src/lib/assistant/chat.ts"
}, (opts) => askMira.__executeServer(opts));
var askMira = createServerFn({ method: "POST" }).validator((input) => input).handler(askMira_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		text: "",
		sources: [],
		error: "AI is not available in this environment."
	};
	const history = data.messages.slice(-12);
	const { text, images } = buildUserContent(data);
	const userContent = images.length > 0 ? [{
		type: "text",
		text
	}, ...images.map((url) => ({
		type: "image_url",
		image_url: { url }
	}))] : text;
	const messages = [
		{
			role: "system",
			content: systemPrompt(data)
		},
		...history.slice(0, -1).map((m) => ({
			role: m.role,
			content: m.content
		})),
		{
			role: "user",
			content: userContent
		}
	];
	const sources = [];
	let pending = false;
	let loginRequired = false;
	let loginUrl;
	const { callTool } = await import("./client.server-CA4VLIeU.mjs");
	try {
		for (let round = 0; round < MAX_ROUNDS; round += 1) {
			const choice = (await grokChat(apiKey, messages, true)).choices?.[0]?.message;
			const toolCalls = choice?.tool_calls ?? [];
			if (!toolCalls.length) return {
				ok: true,
				text: (choice?.content ?? "").trim() || "I did not have anything to add. Try a more specific question about your files, mail, or calendar.",
				sources,
				pending: pending || void 0,
				loginRequired: loginRequired || void 0,
				loginUrl
			};
			messages.push({
				role: "assistant",
				content: choice?.content ?? null,
				tool_calls: toolCalls
			});
			for (const call of toolCalls.slice(0, 4)) {
				const spec = TOOLS.find((t) => t.grokName === call.function.name);
				let parsed = {};
				try {
					parsed = JSON.parse(call.function.arguments || "{}");
				} catch {
					parsed = {};
				}
				if (!spec) {
					messages.push({
						role: "tool",
						tool_call_id: call.id,
						content: JSON.stringify({ error: "Unknown tool" })
					});
					continue;
				}
				const result = await callTool(spec.toolName, spec.mapArgs(parsed), { connectorType: spec.connectorType });
				if (result.pending) pending = true;
				if (result.loginRequired) {
					loginRequired = true;
					loginUrl = result.loginUrl ?? loginUrl;
				}
				if (result.ok) sources.push(...sourcesFromResult(spec.kind, result.data));
				messages.push({
					role: "tool",
					tool_call_id: call.id,
					content: formatToolResult(result)
				});
			}
		}
		return {
			ok: true,
			text: ((await grokChat(apiKey, messages, false)).choices?.[0]?.message?.content ?? "").trim() || "I reached my lookup limit. Ask me to focus on one source.",
			sources,
			pending: pending || void 0,
			loginRequired: loginRequired || void 0,
			loginUrl
		};
	} catch (error) {
		return {
			ok: false,
			text: "",
			sources,
			error: error instanceof Error ? error.message : "Something went wrong.",
			pending: pending || void 0,
			loginRequired: loginRequired || void 0,
			loginUrl
		};
	}
});
//#endregion
export { askMira_createServerFn_handler };
