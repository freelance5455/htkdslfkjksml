import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Repeat, c as LayoutDashboard, i as Target, l as Landmark, n as Wallet, s as Menu } from "../_libs/lucide-react.mjs";
import { n as usePortfolio } from "./router-Ddmv2GI8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-wztA7KjE.js
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		to: "/",
		label: "Áttekintés",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/eszkozok",
		label: "Eszközök",
		icon: Wallet,
		exact: false
	},
	{
		to: "/mozgasok",
		label: "Mozgások",
		icon: Landmark,
		exact: false
	},
	{
		to: "/celok",
		label: "Célok",
		icon: Target,
		exact: false
	},
	{
		to: "/dijak",
		label: "Előfizetések",
		icon: Repeat,
		exact: false
	},
	{
		to: "/beolvasas",
		label: "Beolvasás",
		icon: Menu,
		exact: false
	}
];
var MOBILE = [
	{
		to: "/",
		label: "Áttekintés",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/eszkozok",
		label: "Eszközök",
		icon: Wallet,
		exact: false
	},
	{
		to: "/celok",
		label: "Célok",
		icon: Target,
		exact: false
	},
	{
		to: "/dijak",
		label: "Díjak",
		icon: Repeat,
		exact: false
	},
	{
		to: "/meg",
		label: "Még",
		icon: Menu,
		exact: false
	}
];
function Item({ to, label, icon: Icon, exact, compact }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const on = exact ? pathname === to : pathname === to;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		"aria-current": on ? "page" : void 0,
		className: `flex items-center gap-3 rounded-lg text-sm ${compact ? "h-14 flex-col justify-center gap-1 px-1 text-xs" : "h-11 px-3"} ${on ? "bg-on-pine/15 text-on-pine" : "text-on-pine/80 hover:bg-on-pine/10"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4",
			"aria-hidden": "true"
		}), label]
	});
}
function Shell({ children }) {
	const { state, dismissSample, clearAll } = usePortfolio();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#tartalom",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-lg focus:bg-surface focus:px-3 focus:py-2",
				children: "Ugrás a tartalomhoz"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-30 hidden w-60 flex-col bg-pine text-on-pine md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-5 pt-7 pb-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-9 place-items-center rounded-lg bg-on-pine font-serif text-lg text-pine",
								children: "Sz"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-xl leading-none",
								children: "Számvetés"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-on-pine/70",
								children: "TBSZ, kripto, célok"
							})] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-1 px-3",
						"aria-label": "Főmenü",
						children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, { ...link }, link.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-5 pb-6 text-xs text-on-pine/60",
						children: "A számok a böngészőben maradnak."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:pl-60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center gap-3 bg-pine px-4 py-3 text-on-pine md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-lg bg-on-pine font-serif text-lg text-pine",
						children: "Sz"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-xl",
						children: "Számvetés"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					id: "tartalom",
					className: "mx-auto w-full max-w-6xl px-4 pt-6 pb-24 md:px-8 md:pt-10 md:pb-12",
					children: [
						state.sample ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 flex flex-col gap-3 rounded-2xl border border-line bg-surface px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: "Mintaállomány, hogy látni lehessen a szerkezetet. Amit beírsz, csak ezen a gépen marad."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									onClick: dismissSample,
									children: "Megtartom"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-primary",
									onClick: clearAll,
									children: "Üres lap"
								})]
							})]
						}) : null,
						children,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-16 text-xs text-muted",
							children: "Nem befektetési tanács, és TBSZ-adót nem számol. Az árak késhetnek. A Lightyear-kivonat a böngészőben bomlik szöveggé, nem töltjük fel."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 bg-pine px-1 pb-1 text-on-pine md:hidden",
				"aria-label": "Mobilmenü",
				children: MOBILE.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
					...link,
					compact: true
				}, link.to))
			})
		]
	});
}
//#endregion
export { Shell as t };
