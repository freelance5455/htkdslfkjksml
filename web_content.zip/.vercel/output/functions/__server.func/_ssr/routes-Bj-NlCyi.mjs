import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Save, c as House, d as ChartColumn, f as Bike, i as Skull, l as History, n as Trophy, o as Plus, s as PersonStanding, t as X, u as Dumbbell } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bj-NlCyi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GROUPS = {
	Pernas: [
		"Leg Press 45",
		"Hack Squat",
		"Cadeira Extensora",
		"Cadeira Flexora",
		"Abdutora",
		"Adutora",
		"Panturrilha na cadeira",
		"Panturrilha em pé",
		"Panturrilha sentado"
	],
	Peito: [
		"Supino reto máquina",
		"Supino inclinado máquina",
		"Supino máquina",
		"Supino reto com halteres",
		"Supino inclinado com halteres",
		"Crucifixo com halteres",
		"Crucifixo na máquina",
		"Fly na máquina"
	],
	Ombros: [
		"Desenvolvimento máquina",
		"Elevação lateral polia",
		"Posterior fly",
		"Desenvolvimento halteres",
		"Elevação lateral halteres"
	],
	Costas: [
		"Puxada alta máquina",
		"Puxada alta barra aberta",
		"Puxada triângulo",
		"Remada baixa",
		"Remada unilateral",
		"Remada unilateral na máquina",
		"Remada baixa polia",
		"Serrote com halteres",
		"Remada curvada na máquina",
		"Remada cavalinho"
	],
	Bíceps: [
		"Bíceps Scott máquina",
		"Rosca alternada",
		"Bíceps polia barra reta",
		"Rosca direta na polia",
		"Rosca martelo",
		"Rosca direta barra W",
		"Rosca Bayesian"
	],
	Tríceps: [
		"Tríceps máquina",
		"Tríceps polia",
		"Tríceps polia corda",
		"Tríceps francês"
	],
	Cardio: ["Esteira", "Bicicleta"]
};
var GROUP_ORDER = Object.keys(GROUPS);
var SEED_PRS = {
	"Leg Press 45|Academia": {
		w: 250,
		r: 9
	},
	"Hack Squat|Academia": {
		w: 70,
		r: 7
	},
	"Cadeira Extensora|Academia": {
		w: 100,
		r: 0
	},
	"Cadeira Flexora|Academia": {
		w: 80,
		r: 0
	},
	"Abdutora|Academia": {
		w: 100,
		r: 0
	},
	"Adutora|Academia": {
		w: 60,
		r: 0
	},
	"Panturrilha na cadeira|Academia": {
		w: 55,
		r: 10
	},
	"Panturrilha em pé|Academia": {
		w: 40,
		r: 0
	},
	"Crucifixo|Academia": {
		w: 60,
		r: 7
	},
	"Supino máquina|Academia": {
		w: 100,
		r: 10
	},
	"Supino reto máquina|Academia": {
		w: 55,
		r: 6
	},
	"Supino inclinado máquina|Academia": {
		w: 45,
		r: 7
	},
	"Desenvolvimento máquina|Academia": {
		w: 80,
		r: 7
	},
	"Elevação lateral polia|Academia": {
		w: 15,
		r: 9
	},
	"Posterior fly|Academia": {
		w: 35,
		r: 9
	},
	"Puxada alta máquina|Academia": {
		w: 55,
		r: 7
	},
	"Remada unilateral|Academia": {
		w: 55,
		r: 7
	},
	"Remada baixa|Academia": {
		w: 70,
		r: 7
	},
	"Bíceps Scott máquina|Academia": {
		w: 45,
		r: 7
	},
	"Rosca alternada|Academia": {
		w: 14,
		r: 7
	},
	"Tríceps máquina|Academia": {
		w: 80,
		r: 0
	},
	"Tríceps polia|Academia": {
		w: 50,
		r: 0
	},
	"Supino reto halteres|Casa": {
		w: 24,
		r: 7
	},
	"Supino inclinado halteres|Casa": {
		w: 24,
		r: 7
	},
	"Puxada alta barra aberta|Casa": {
		w: 49,
		r: 9
	},
	"Puxada triângulo|Casa": {
		w: 49,
		r: 9
	},
	"Remada baixa polia|Casa": {
		w: 49,
		r: 9
	},
	"Bíceps polia barra reta|Casa": {
		w: 35,
		r: 7
	},
	"Rosca martelo|Casa": {
		w: 13,
		r: 0
	},
	"Rosca direta barra W|Casa": {
		w: 36,
		r: 0
	},
	"Rosca Bayesian|Casa": {
		w: 13,
		r: 7
	},
	"Tríceps polia corda|Casa": {
		w: 28,
		r: 0
	},
	"Tríceps francês|Casa": {
		w: 16,
		r: 7
	}
};
var THUMB_FILE = {
	"Hack Squat": "hack-squat.jpg",
	"Leg Press 45": "leg-press-45.jpg",
	"Cadeira Extensora": "cadeira-extensora.jpg",
	"Cadeira Flexora": "cadeira-flexora.jpg",
	Abdutora: "abdutora.jpg",
	Adutora: "adutora.jpg",
	"Panturrilha em pé": "panturrilha-em-pe.jpg",
	"Panturrilha na cadeira": "panturrilha-na-cadeira.jpg",
	"Panturrilha sentado": "panturrilha-sentado.jpg",
	"Puxada alta máquina": "puxada-alta-maquina.jpg",
	"Puxada alta barra aberta": "puxada-alta-barra-aberta.jpg",
	"Puxada triângulo": "puxada-triangulo.jpg",
	"Remada baixa": "remada-baixa.jpg",
	"Remada baixa polia": "remada-baixa-polia.jpg",
	"Remada unilateral": "remada-unilateral.jpg",
	"Remada unilateral na máquina": "remada-unilateral.jpg",
	"Serrote com halteres": "remada-unilateral.jpg",
	"Remada curvada na máquina": "remada-baixa.jpg",
	"Remada cavalinho": "remada-baixa.jpg",
	"Supino reto máquina": "supino-reto-maquina.jpg",
	"Supino inclinado máquina": "supino-inclinado-maquina.jpg",
	"Supino máquina": "supino-maquina.jpg",
	"Supino reto halteres": "supino-reto-halteres.jpg",
	"Supino reto com halteres": "supino-reto-halteres.jpg",
	"Supino inclinado halteres": "supino-inclinado-halteres.jpg",
	"Supino inclinado com halteres": "supino-inclinado-halteres.jpg",
	Crucifixo: "crucifixo.jpg",
	"Crucifixo com halteres": "crucifixo.jpg",
	"Crucifixo na máquina": "crucifixo.jpg",
	"Fly na máquina": "crucifixo.jpg",
	"Desenvolvimento máquina": "desenvolvimento-maquina.jpg",
	"Desenvolvimento halteres": "desenvolvimento-halteres.jpg",
	"Elevação lateral polia": "elevacao-lateral-polia.jpg",
	"Elevação lateral halteres": "elevacao-lateral-halteres.jpg",
	"Posterior fly": "posterior-fly.jpg",
	"Bíceps Scott máquina": "biceps-scott-maquina.jpg",
	"Rosca alternada": "rosca-alternada.jpg",
	"Bíceps polia barra reta": "biceps-polia-barra-reta.jpg",
	"Rosca martelo": "rosca-martelo.jpg",
	"Rosca direta barra W": "rosca-direta-barra-w.jpg",
	"Rosca direta na polia": "rosca-direta-barra-w.jpg",
	"Rosca Bayesian": "rosca-bayesian.jpg",
	"Tríceps máquina": "triceps-maquina.jpg",
	"Tríceps polia": "triceps-polia.jpg",
	"Tríceps polia corda": "triceps-polia-corda.jpg",
	"Tríceps francês": "triceps-frances.jpg"
};
function thumbSrc(name) {
	const file = THUMB_FILE[name];
	return file ? `/exercises/${file}` : null;
}
function groupOf(name) {
	for (const [group, list] of Object.entries(GROUPS)) if (list.includes(name)) return group;
	return "Outros";
}
var STORAGE_KEY = "treino-lucas-v1";
function emptyDb() {
	return {
		sessions: [],
		prs: { ...SEED_PRS }
	};
}
function isPr(value) {
	if (!value || typeof value !== "object") return false;
	const pr = value;
	return Number.isFinite(Number(pr.w)) && Number.isFinite(Number(pr.r));
}
function isSession(value) {
	if (!value || typeof value !== "object") return false;
	const session = value;
	return typeof session.date === "string" && Array.isArray(session.exercises);
}
function normalizeDb(raw) {
	if (!raw || typeof raw !== "object") return null;
	const data = raw;
	if (!Array.isArray(data.sessions) || !data.prs || typeof data.prs !== "object") return null;
	const sessions = data.sessions.filter(isSession).map((session) => ({
		...session,
		id: Number(session.id) || Date.now(),
		place: session.place || "Academia",
		duration: Number(session.duration) || 0,
		water: Number(session.water) || 0,
		exercises: session.exercises || []
	}));
	const prs = {};
	for (const [key, value] of Object.entries(data.prs)) if (isPr(value)) prs[key] = {
		w: Number(value.w),
		r: Number(value.r),
		date: value.date
	};
	return {
		sessions,
		prs: {
			...SEED_PRS,
			...prs
		}
	};
}
function loadDb() {
	if (typeof window === "undefined") return emptyDb();
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return emptyDb();
		return normalizeDb(JSON.parse(raw)) ?? emptyDb();
	} catch {
		return emptyDb();
	}
}
function persistDb(db) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("block", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-xs font-medium text-muted",
			children: label
		}), children]
	});
}
var controlClass = "min-h-11 w-full rounded-xl border border-line bg-inset px-3 text-base text-fg outline-none transition placeholder:text-muted focus:border-fg";
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-2xl border border-line bg-surface p-4", className),
		children
	});
}
function Backup({ db, onImport }) {
	const payload = JSON.stringify(db);
	const [override, setOverride] = (0, import_react.useState)(null);
	const text = override ?? payload;
	async function copy() {
		const next = JSON.stringify(db);
		setOverride(next);
		try {
			await navigator.clipboard.writeText(next);
			toast.success("Progresso copiado.");
		} catch {
			toast.error("Selecione o texto e copie manualmente.");
		}
	}
	function download() {
		const blob = new Blob([JSON.stringify(db)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "treino-lucas-progresso.json";
		document.body.appendChild(a);
		a.click();
		a.remove();
		URL.revokeObjectURL(url);
	}
	function loadText() {
		try {
			const data = normalizeDb(JSON.parse(text));
			if (!data) throw new Error("invalido");
			onImport(data);
			setOverride(null);
			toast.success("Progresso carregado.");
		} catch {
			toast.error("Texto inválido.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Salvar progresso" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "O treino fica neste aparelho. Copie o texto ou baixe o arquivo pra não perder. Pra recuperar, cole aqui ou escolha o arquivo."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-4 min-h-12 w-full rounded-xl bg-fg font-bold text-ink",
				onClick: copy,
				children: "Copiar progresso"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-2 min-h-12 w-full rounded-xl border border-line font-semibold",
				onClick: download,
				children: "Baixar arquivo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-xs text-muted",
				children: ["Cole aqui pra recuperar", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${controlClass} mt-1 min-h-36 py-3`,
					rows: 6,
					placeholder: "Cole o progresso salvo",
					value: text,
					onChange: (e) => setOverride(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 min-h-12 w-full rounded-xl bg-fg font-bold text-ink",
				onClick: loadText,
				children: "Carregar texto"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-xs text-muted",
				children: ["Ou escolha o arquivo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: `${controlClass} mt-1 py-2`,
					type: "file",
					accept: "application/json,.json",
					onChange: (ev) => {
						const file = ev.target.files?.[0];
						if (!file) return;
						const reader = new FileReader();
						reader.onload = () => {
							try {
								const data = normalizeDb(JSON.parse(String(reader.result)));
								if (!data) throw new Error("arquivo inválido");
								onImport(data);
								setOverride(null);
								toast.success("Progresso carregado.");
							} catch {
								toast.error("Não consegui ler esse arquivo.");
							}
						};
						reader.readAsText(file);
					}
				})]
			})
		]
	});
}
function num(value) {
	const n = Number(value);
	return Number.isFinite(n) ? n : 0;
}
function todayLocal() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function formatDate(ymd) {
	const [y, m, d] = ymd.split("-");
	if (!y || !m || !d) return ymd;
	return `${d}/${m}/${y}`;
}
function dayTitle(session) {
	const groups = [...new Set((session.exercises || []).map((e) => e.group))];
	if (groups.includes("Pernas") && groups.length === 1) return "LEG DAY";
	if (groups.includes("Costas") && !groups.includes("Peito")) return "PULL DAY";
	if (groups.includes("Peito") && !groups.includes("Costas")) return "PUSH DAY";
	if (groups.length === 1) return (groups[0] || "TREINO").toUpperCase();
	return "UPPER DAY";
}
function volumeOf(session) {
	return (session.exercises || []).reduce((sum, exercise) => sum + (exercise.sets || []).reduce((acc, set) => acc + num(set.kg) * num(set.reps), 0), 0);
}
function seriesOf(session) {
	return (session.exercises || []).reduce((n, exercise) => n + (exercise.group === "Cardio" ? 1 : (exercise.sets || []).length), 0);
}
function formatKg(value) {
	return value.toLocaleString("pt-BR");
}
function formatDuration(mins) {
	if (!mins) return "—";
	return `${Math.floor(mins / 60)}h ${mins % 60}min`;
}
function exerciseLine(exercise) {
	if (exercise.group === "Cardio") return `${num(exercise.minutes)} min · ${num(exercise.kcal)} kcal`;
	return (exercise.sets || []).map((set, i) => `S${i + 1} ${num(set.kg)}kg x ${num(set.reps)}`).join(" · ");
}
function weekBounds(d) {
	const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
	const day = date.getDay();
	const monday = new Date(date);
	monday.setDate(date.getDate() - (day + 6) % 7);
	const sunday = new Date(monday);
	sunday.setDate(monday.getDate() + 6);
	return {
		monday,
		sunday
	};
}
function ymd(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function maxFor(group) {
	if (group === "Pernas") return 22;
	if (group === "Bíceps" || group === "Tríceps") return 9;
	return 14;
}
function toneFor(n, max, group) {
	if (group === "Ombros" || group === "Bíceps" || group === "Tríceps") {
		if (n < 6) return "danger";
		if (n === 6) return "warn";
		return "blue";
	}
	if (n <= max / 3) return "danger";
	if (n <= max * 2 / 3) return "warn";
	return "blue";
}
function workedGroups(session) {
	return new Set((session.exercises || []).map((e) => e.group));
}
function mark(on) {
	return on ? "var(--color-blue)" : "var(--color-story-muted)";
}
function BodyArt({ session }) {
	const groups = workedGroups(session);
	const torso = mark(groups.has("Peito") || groups.has("Costas") || groups.has("Ombros"));
	const arms = mark(groups.has("Bíceps") || groups.has("Tríceps") || groups.has("Ombros"));
	const legs = mark(groups.has("Pernas"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 80 150",
		className: "h-36 w-20",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "40",
				cy: "16",
				r: "10",
				fill: "#d7dde6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M28 30 h24 l6 28 h-36z",
				fill: torso
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M22 34 h8 l2 24 h-8z",
				fill: arms
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M50 34 h8 l-2 24 h-8z",
				fill: arms
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M30 60 h8 l2 42 h-10z",
				fill: legs
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M42 60 h8 l0 42 h-10z",
				fill: legs
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "58",
				rx: "8",
				ry: "5",
				fill: legs
			})
		]
	});
}
function MoodFace({ times }) {
	const mood = times >= 3 ? "happy" : times === 2 ? "neutral" : "angry";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 96 96",
		className: "size-20 shrink-0",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "48",
				cy: "70",
				rx: "22",
				ry: "10",
				fill: "#1b1b1b"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 46 q2-28 30-30 q28-2 32 30 q2 24-10 34 q-12 8-22 8 q-16 0-24-10 q-8-10-6-32z",
				fill: "#2b2b2b"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M24 42 q10-24 28-22 q16 2 20 16 q-8-8-20-6 q-14 1-20 12z",
				fill: "#3a3a3a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "48",
				cy: "52",
				rx: "20",
				ry: "22",
				fill: "#f3d2c3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "54",
				rx: "6",
				ry: "7",
				fill: "#fff"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "56",
				cy: "54",
				rx: "6",
				ry: "7",
				fill: "#fff"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "41",
				cy: "55",
				rx: "3",
				ry: "3.4",
				fill: "#5b4636"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "57",
				cy: "55",
				rx: "3",
				ry: "3.4",
				fill: "#5b4636"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "42",
				cy: "54",
				r: "1",
				fill: "#fff"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "58",
				cy: "54",
				r: "1",
				fill: "#fff"
			}),
			mood === "angry" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M34 40 l10 4",
					stroke: "#3a2a2a",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M62 40 l-10 4",
					stroke: "#3a2a2a",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M40 64 q8-7 16 0",
					stroke: "#c45b6a",
					fill: "none",
					strokeWidth: "1.6"
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M34 40 q6-4 12 0",
					stroke: "#3a2a2a",
					fill: "none",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M50 40 q6-4 12 0",
					stroke: "#3a2a2a",
					fill: "none",
					strokeWidth: "1.5"
				}),
				mood === "happy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M40 58 q8 8 16 0",
					stroke: "#c45b6a",
					fill: "#e7a0ad",
					fillOpacity: "0.45",
					strokeWidth: "1.6"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M42 60 h12",
					stroke: "#c45b6a",
					strokeWidth: "1.6"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "32",
				cy: "60",
				rx: "3",
				ry: "1.6",
				fill: "#f0a0a8",
				opacity: "0.7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "64",
				cy: "60",
				rx: "3",
				ry: "1.6",
				fill: "#f0a0a8",
				opacity: "0.7"
			})
		]
	});
}
function ShareCard({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "w-10/12 shrink-0 snap-center rounded-3xl bg-story px-4 py-5 text-fg",
		children
	});
}
function CardTitle({ title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
		className: "mb-3 flex items-center gap-2 font-display text-3xl font-semibold tracking-wide",
		children: [title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skull, {
			className: "size-6 text-blue",
			"aria-hidden": true
		})]
	});
}
function Foot({ right }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-5 flex items-end justify-between text-sm text-story-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "font-display text-base tracking-widest text-fg",
			children: "LVCXS"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: right ?? "@lvcxs777" })]
	});
}
function HistoryView({ sessions, onDelete }) {
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const open = sessions.find((session) => session.id === openId);
	if (!sessions.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-2xl border border-line bg-surface p-4 text-sm text-muted",
		children: "Nenhum treino salvo ainda."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Deslize o card. Toque pra abrir o treino."
			}),
			sessions.map((session) => {
				const title = dayTitle(session);
				const vol = formatKg(volumeOf(session));
				const series = seriesOf(session);
				const mins = formatDuration(session.duration || 0);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full snap-x snap-mandatory gap-3 overflow-x-auto pb-1 text-left",
					onClick: () => {
						setOpenId(session.id);
						setConfirm(false);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ShareCard, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { title }),
							(session.exercises || []).map((exercise, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "my-1.5 flex gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-8 shrink-0 font-extrabold text-blue",
									children: exercise.group === "Cardio" ? `${exercise.minutes || 0}m` : `${(exercise.sets || []).length}x`
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: exercise.name })]
							}, `${exercise.name}-${index}`)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ShareCard, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mb-2 flex items-center justify-center gap-2 text-center font-display text-3xl font-semibold tracking-wide",
								children: [title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skull, {
									className: "size-6 text-blue",
									"aria-hidden": true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyArt, { session }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyArt, { session })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid grid-cols-2 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: mins,
										label: "Duração"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: `${vol} kg`,
										label: "Volume"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: String(series),
										label: "Séries"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ShareCard, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { title }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: mins,
										label: "Duração",
										flip: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: `${vol} kg`,
										label: "Volume",
										flip: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: String((session.exercises || []).length),
										label: "Exercícios",
										flip: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: String(series),
										label: "Séries",
										flip: true
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, { right: `${formatDate(session.date)} · ${session.place}` })
						] })
					]
				}, session.id);
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 overflow-auto bg-bg/95 p-4 pb-nav",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
								dayTitle(open),
								" · ",
								formatDate(open.date)
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center",
								"aria-label": "Fechar",
								onClick: () => setOpenId(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-3 text-sm text-muted",
							children: [
								open.place,
								" · ",
								open.duration || 0,
								" min · ",
								open.water || 0,
								" L · volume ",
								formatKg(volumeOf(open)),
								" kg"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: (open.exercises || []).map((exercise, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-line bg-surface p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: exercise.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 whitespace-pre-line text-sm text-muted",
									children: exercise.group === "Cardio" ? `${exercise.minutes || 0} min · ${exercise.kcal || 0} kcal` : (exercise.sets || []).map((set, i) => `Série ${i + 1}: ${set.kg} kg x ${set.reps}`).join("\n")
								})]
							}, `${exercise.name}-${index}`))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-4 min-h-11 rounded-full border border-line px-4 text-sm text-danger",
							onClick: () => {
								if (!confirm) {
									setConfirm(true);
									return;
								}
								onDelete(open.id);
								setOpenId(null);
							},
							children: confirm ? "Confirmar exclusão" : "Apagar treino"
						})
					]
				})
			})
		]
	});
}
function Stat({ value, label, flip }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: flip ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
		className: "block font-display text-2xl font-semibold",
		children: value
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-sm text-story-muted",
		children: label
	})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-sm text-story-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
		className: "block font-display text-2xl font-semibold",
		children: value
	})] }) });
}
function ExerciseThumb({ name, group, className }) {
	const src = thumbSrc(name);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid h-16 w-20 shrink-0 place-items-center overflow-hidden rounded-lg bg-fg text-ink", className),
		children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "h-full w-full object-cover"
		}) : group === "Cardio" && name === "Bicicleta" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bike, {
			className: "size-7",
			"aria-hidden": true
		}) : group === "Cardio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonStanding, {
			className: "size-7",
			"aria-hidden": true
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, {
			className: "size-6",
			"aria-hidden": true
		})
	});
}
function blankSets(place) {
	const count = place === "Casa" ? 2 : 3;
	return Array.from({ length: count }, () => ({
		kg: "",
		reps: ""
	}));
}
function NewWorkout({ draft, onChange, onSave }) {
	const [date, setDate] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setDate((current) => current || todayLocal());
	}, []);
	const [place, setPlace] = (0, import_react.useState)("Academia");
	const [duration, setDuration] = (0, import_react.useState)("");
	const [water, setWater] = (0, import_react.useState)("");
	const [group, setGroup] = (0, import_react.useState)(GROUP_ORDER[0] ?? "Pernas");
	const [name, setName] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [sets, setSets] = (0, import_react.useState)(() => blankSets("Academia"));
	const [cardioType, setCardioType] = (0, import_react.useState)("Esteira");
	const [cardioMin, setCardioMin] = (0, import_react.useState)("");
	const [cardioKcal, setCardioKcal] = (0, import_react.useState)("");
	const cardio = group === "Cardio";
	const suggestions = (0, import_react.useMemo)(() => {
		const q = name.trim().toLowerCase();
		return (GROUPS[group] || []).filter((item) => !q || item.toLowerCase().includes(q)).slice(0, 8);
	}, [group, name]);
	function changePlace(next) {
		setPlace(next);
		if (next !== place) setSets(blankSets(next));
	}
	function changeKg(index, value) {
		setSets((prev) => prev.map((set, i) => i >= index ? {
			...set,
			kg: value
		} : set));
	}
	function addExercise() {
		if (cardio) {
			const minutes = Number(cardioMin || 0);
			const kcal = Number(cardioKcal || 0);
			if (!minutes && !kcal) {
				toast.error("Informe tempo ou calorias.");
				return;
			}
			onChange([...draft, {
				group: "Cardio",
				name: cardioType,
				minutes,
				kcal,
				sets: []
			}]);
			setCardioMin("");
			setCardioKcal("");
			return;
		}
		const exercise = name.trim();
		if (!exercise) {
			toast.error("Informe o exercício.");
			return;
		}
		const parsed = sets.map((set) => ({
			kg: Number(set.kg || 0),
			reps: Number(set.reps || 0)
		})).filter((set) => set.kg || set.reps);
		if (!parsed.length) {
			toast.error("Adicione ao menos uma série.");
			return;
		}
		onChange([...draft, {
			group,
			name: exercise,
			sets: parsed
		}]);
		setName("");
		setSets(blankSets(place));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Data",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs font-medium text-muted",
						children: "Local"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [["Academia", Dumbbell], ["Casa", House]].map(([label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => changePlace(label),
							className: cn("flex min-h-11 items-center justify-center gap-1 rounded-xl border text-sm", place === label ? "border-fg bg-fg font-semibold text-ink" : "border-line bg-inset text-fg"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-4",
								"aria-hidden": true
							}), label]
						}, label))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Duração (min)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							inputMode: "numeric",
							type: "number",
							placeholder: "70",
							value: duration,
							onChange: (e) => setDuration(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Água (L)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: controlClass,
							inputMode: "decimal",
							type: "number",
							step: "0.1",
							placeholder: "2",
							value: water,
							onChange: (e) => setWater(e.target.value)
						})
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Grupo muscular",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: controlClass,
						value: group,
						onChange: (e) => {
							setGroup(e.target.value);
							setName("");
							setOpen(false);
						},
						children: GROUP_ORDER.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
					})
				}),
				cardio ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tipo de cardio",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: controlClass,
							value: cardioType,
							onChange: (e) => setCardioType(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Esteira" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Bicicleta" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tempo (min)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								type: "number",
								placeholder: "15",
								value: cardioMin,
								onChange: (e) => setCardioMin(e.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Calorias",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								type: "number",
								placeholder: "95",
								value: cardioKcal,
								onChange: (e) => setCardioKcal(e.target.value)
							})
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Exercício",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: controlClass,
								autoComplete: "off",
								placeholder: "Comece a digitar o exercício",
								value: name,
								onChange: (e) => {
									setName(e.target.value);
									setOpen(true);
								},
								onFocus: () => setOpen(true),
								onBlur: () => setOpen(false)
							})
						}), open && suggestions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-0 top-full z-20 mt-1 max-h-72 overflow-auto rounded-2xl border border-line bg-inset shadow-xl",
							children: suggestions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex w-full items-center gap-3 border-b border-line px-2 py-2 text-left last:border-b-0",
								onMouseDown: (e) => {
									e.preventDefault();
									setName(item);
									setOpen(false);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExerciseThumb, {
									name: item,
									group
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-semibold",
									children: item
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: group
								})] })]
							}, item))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 space-y-2",
						children: sets.map((set, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "w-16 shrink-0 text-sm text-muted",
									children: ["Série ", index + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: controlClass,
									type: "number",
									step: "0.5",
									inputMode: "decimal",
									placeholder: "kg",
									value: set.kg,
									onChange: (e) => changeKg(index, e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: controlClass,
									type: "number",
									inputMode: "numeric",
									placeholder: "reps",
									value: set.reps,
									onChange: (e) => setSets((prev) => prev.map((row, i) => i === index ? {
										...row,
										reps: e.target.value
									} : row))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "grid size-11 shrink-0 place-items-center text-xl text-danger",
									"aria-label": `Remover série ${index + 1}`,
									onClick: () => setSets((prev) => prev.filter((_, i) => i !== index)),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
								})
							]
						}, index))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "mt-3 inline-flex min-h-11 items-center gap-1 rounded-full border border-line px-4 text-sm",
						onClick: () => setSets((prev) => [...prev, {
							kg: prev.at(-1)?.kg ?? "",
							reps: ""
						}]),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " série"]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-4 min-h-12 w-full rounded-xl bg-fg text-base font-bold text-ink",
					onClick: addExercise,
					children: "Adicionar exercício"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Exercícios deste treino" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: draft.length === 1 ? "1 exercício" : `${draft.length} exercícios`
					})]
				}),
				draft.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Nenhum exercício ainda."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: draft.map((exercise, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 border-t border-line py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExerciseThumb, {
							name: exercise.name,
							group: exercise.group
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "block truncate",
								children: exercise.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: exercise.group === "Cardio" ? exerciseLine(exercise) : `${exercise.group} · ${exerciseLine(exercise)}`
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center text-danger",
							"aria-label": `Remover ${exercise.name}`,
							onClick: () => onChange(draft.filter((_, i) => i !== index)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})
					]
				}, `${exercise.name}-${index}`)) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 min-h-12 w-full rounded-xl bg-fg text-base font-bold text-ink",
					onClick: () => {
						if (!draft.length) {
							toast.error("Adicione exercícios antes de salvar.");
							return;
						}
						if (!date) {
							toast.error("Informe a data.");
							return;
						}
						onSave({
							date,
							place,
							duration: Number(duration || 0),
							water: Number(water || 0)
						});
					},
					children: "Salvar treino"
				})
			] })
		]
	});
}
var TONE_TEXT = {
	danger: "text-danger",
	warn: "text-warn",
	blue: "text-blue"
};
var TONE_BG = {
	danger: "bg-danger",
	warn: "bg-warn",
	blue: "bg-blue"
};
function Progress({ sessions }) {
	const { monday, sunday } = weekBounds(/* @__PURE__ */ new Date());
	const start = ymd(monday);
	const end = ymd(sunday);
	const counts = {};
	Object.keys(GROUPS).forEach((group) => {
		counts[group] = 0;
	});
	const trained = {};
	const repSum = {};
	const repN = {};
	const byEx = {};
	sessions.forEach((session) => {
		if (session.date < start || session.date > end) return;
		trained[session.date] = true;
		(session.exercises || []).forEach((exercise) => {
			const group = exercise.group && counts[exercise.group] !== void 0 ? exercise.group : "Outros";
			if (counts[group] === void 0) counts[group] = 0;
			counts[group] += (exercise.sets || []).length;
			if (exercise.group === "Cardio") return;
			(exercise.sets || []).forEach((set) => {
				repSum[exercise.group] = (repSum[exercise.group] || 0) + num(set.reps);
				repN[exercise.group] = (repN[exercise.group] || 0) + 1;
				const key = `${exercise.group}|${exercise.name}`;
				byEx[key] = byEx[key] || {
					group: exercise.group,
					name: exercise.name,
					reps: 0,
					n: 0
				};
				byEx[key].reps += num(set.reps);
				byEx[key].n += 1;
			});
		});
	});
	const labels = [
		"Dom",
		"Seg",
		"Ter",
		"Qua",
		"Qui",
		"Sex",
		"Sáb"
	];
	const sundayStart = new Date(monday);
	sundayStart.setDate(monday.getDate() - 1);
	const days = labels.map((lab, i) => {
		const d = new Date(sundayStart);
		d.setDate(sundayStart.getDate() + i);
		return {
			lab,
			date: d.getDate(),
			on: !!trained[ymd(d)]
		};
	});
	const bars = Object.keys(GROUPS).filter((group) => group !== "Cardio").map((group) => {
		const max = maxFor(group);
		const raw = counts[group] || 0;
		return {
			group,
			raw,
			pct: Math.round(Math.min(raw, max) / max * 100),
			tone: toneFor(raw, max, group),
			avg: repN[group] ? Math.round(repSum[group] / repN[group]) : 0,
			max,
			lines: Object.values(byEx).filter((item) => item.group === group)
		};
	});
	const cardio = sessions.filter((session) => session.date >= start && session.date <= end).flatMap((session) => (session.exercises || []).filter((exercise) => exercise.group === "Cardio"));
	const waters = sessions.filter((session) => session.date >= start && session.date <= end && session.water).map((session) => num(session.water));
	const waterAvg = waters.length ? waters.reduce((a, b) => a + b, 0) / waters.length : 0;
	const waterPct = Math.max(0, Math.min(100, (waterAvg - 1) / 2 * 100));
	const times = Object.keys(trained).length;
	const mood = times >= 3 ? "Semana boa" : times === 2 ? "Na média" : "Bora treinar";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Semana ",
							start.split("-").reverse().join("/"),
							" a ",
							end.split("-").reverse().join("/"),
							" · zera na segunda"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-7 gap-1.5",
						children: days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("rounded-xl border px-1 py-2 text-center", day.on ? "border-blue bg-blue text-fg" : "border-line bg-inset text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "block text-xs",
								children: day.lab
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: day.date
							})]
						}, day.lab))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoodFace, { times }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: mood }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [times, " treino(s) nesta semana"]
						})] })]
					})
				]
			}),
			bars.map((bar) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: bar.group }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("font-bold", TONE_TEXT[bar.tone]),
							children: [bar.raw, " séries"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-2.5 overflow-hidden rounded-full bg-inset",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("h-full rounded-full", TONE_BG[bar.tone]),
							style: { width: `${bar.pct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"Meta ",
							bar.max,
							" · média ",
							bar.avg,
							" reps por série"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: bar.lines.length ? bar.lines.map((line) => `${line.name}: ${Math.round(line.reps / line.n)} reps/série`).join(" · ") : "Sem séries nesta semana"
					})
				]
			}, bar.group)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Água por treino" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-bold text-blue",
							children: [waterAvg ? waterAvg.toFixed(1) : "0", " L"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-2.5 overflow-hidden rounded-full bg-inset",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-blue",
							style: { width: `${waterPct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Média da semana · escala de 1 a 3 litros"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Cardio" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-sm text-muted",
					children: cardio.length ? cardio.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						item.name,
						": ",
						item.minutes || 0,
						" min · ",
						item.kcal || 0,
						" kcal"
					] }, `${item.name}-${index}`)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nenhum cardio nesta semana" })
				})]
			})
		]
	});
}
function Prs({ prs }) {
	const [filter, setFilter] = (0, import_react.useState)("Academia");
	const by = {};
	Object.entries(prs).forEach(([key, value]) => {
		const split = key.lastIndexOf("|");
		const name = split >= 0 ? key.slice(0, split) : key;
		const place = split >= 0 ? key.slice(split + 1) : "";
		if (filter !== "Todos" && place !== filter) return;
		const group = groupOf(name);
		(by[group] ||= []).push({
			name,
			place,
			group,
			w: value.w,
			r: value.r
		});
	});
	const groups = [...GROUP_ORDER, "Outros"].filter((group) => by[group]?.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2",
			children: [
				"Academia",
				"Casa",
				"Todos"
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("min-h-11 rounded-full border px-4 text-sm", filter === item ? "border-fg bg-fg font-semibold text-ink" : "border-line bg-surface text-fg"),
				onClick: () => setFilter(item),
				children: item
			}, item))
		}), groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-2xl border border-line bg-surface p-4 text-sm text-muted",
			children: "Nenhum PR nesse filtro."
		}) : groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-2 font-display text-lg tracking-wide text-fg",
			children: group
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: by[group].map((pr) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "flex items-center gap-3 rounded-2xl border border-line bg-surface p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExerciseThumb, {
					name: pr.name,
					group: pr.group
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "block",
							children: pr.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 inline-block rounded-full bg-inset px-2 py-0.5 text-xs",
							children: pr.place
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-bold text-ok",
							children: [
								pr.w,
								" kg",
								pr.r ? ` × ${pr.r}` : ""
							]
						})
					]
				})]
			}, `${pr.name}|${pr.place}`))
		})] }, group))]
	});
}
var TABS = [
	{
		id: "novo",
		label: "Treino",
		icon: Dumbbell
	},
	{
		id: "hist",
		label: "Histórico",
		icon: History
	},
	{
		id: "prog",
		label: "Semana",
		icon: ChartColumn
	},
	{
		id: "prs",
		label: "PRs",
		icon: Trophy
	},
	{
		id: "backup",
		label: "Salvar",
		icon: Save
	}
];
function Shell() {
	const [tab, setTab] = (0, import_react.useState)("novo");
	const [db, setDb] = (0, import_react.useState)(emptyDb);
	const [draft, setDraft] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setDb(loadDb());
	}, []);
	function commit(next) {
		setDb(next);
		persistDb(next);
	}
	function saveWorkout(meta) {
		const session = {
			id: Date.now(),
			date: meta.date,
			place: meta.place,
			duration: meta.duration,
			water: meta.water,
			exercises: draft
		};
		const prs = { ...db.prs };
		session.exercises.forEach((item) => {
			if (!item.sets?.length) return;
			const best = Math.max(...item.sets.map((set) => Number(set.kg) || 0));
			const reps = item.sets.find((set) => set.kg === best)?.reps || 0;
			const key = `${item.name}|${session.place}`;
			const old = prs[key];
			if (!old || best > old.w) prs[key] = {
				w: best,
				r: reps,
				date: session.date
			};
		});
		commit({
			sessions: [session, ...db.sessions],
			prs
		});
		setDraft([]);
		toast.success("Treino salvo.");
		setTab("hist");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-10 border-b border-line bg-bg/90 px-4 py-4 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-3xl leading-none tracking-wide",
						children: ["LVCXS ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-blue",
							children: "GRINDAS"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Academia e casa · o progresso fica neste aparelho"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-lg px-4 pt-4 pb-nav",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: tab === "novo" ? "" : "hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewWorkout, {
							draft,
							onChange: setDraft,
							onSave: saveWorkout
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: tab === "hist" ? "" : "hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryView, {
							sessions: db.sessions,
							onDelete: (id) => commit({
								...db,
								sessions: db.sessions.filter((session) => session.id !== id)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: tab === "prog" ? "" : "hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { sessions: db.sessions })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: tab === "prs" ? "" : "hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prs, { prs: db.prs })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: tab === "backup" ? "" : "hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Backup, {
							db,
							onImport: commit
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "nav-safe fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-lg grid-cols-5",
					children: TABS.map((item) => {
						const Icon = item.icon;
						const active = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: cn("flex min-h-16 flex-col items-center justify-center gap-1 text-xs", active ? "font-bold text-fg" : "text-muted"),
							onClick: () => setTab(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: cn("size-5", active && "text-blue"),
								"aria-hidden": true
							}), item.label]
						}, item.id);
					})
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
//#endregion
export { Home as component };
