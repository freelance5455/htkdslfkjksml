import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as Minus, d as ChevronLeft, f as Check, i as Stethoscope, l as Copy, n as Trash2, o as Pencil, r as Sun, s as Moon, u as ChevronRight } from "../_libs/lucide-react.mjs";
import { n as toGregorian, r as toJalaali, t as jalaaliMonthLength } from "../_libs/jalaali-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-L5ckeueV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MONTHS = [
	"فروردین",
	"اردیبهشت",
	"خرداد",
	"تیر",
	"مرداد",
	"شهریور",
	"مهر",
	"آبان",
	"آذر",
	"دی",
	"بهمن",
	"اسفند"
];
var WEEKDAYS = [
	"یکشنبه",
	"دوشنبه",
	"سه‌شنبه",
	"چهارشنبه",
	"پنجشنبه",
	"جمعه",
	"شنبه"
];
var BASE_HOURS = {
	morning: 9,
	evening: 8
};
var KIND_LABEL = {
	morning: "صبح",
	evening: "عصر"
};
var DEFAULT_FX = "905.52";
var STORAGE_KEY = "nobat-ledger-v1";
var fmtQty = new Intl.NumberFormat("fa-IR", {
	maximumFractionDigits: 2,
	useGrouping: false
});
var fmtInt = new Intl.NumberFormat("fa-IR", {
	maximumFractionDigits: 0,
	useGrouping: false
});
var fmtMoney = new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 2 });
var fmtRial = new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 });
function formatQty(n) {
	return fmtQty.format(round2(n));
}
function formatInt(n) {
	return fmtInt.format(Math.round(n));
}
function formatMoney(n) {
	return fmtMoney.format(round2(n));
}
function formatRial(n) {
	return fmtRial.format(Math.round(n));
}
function round2(n) {
	return Math.round(n * 100) / 100;
}
function normalizeDigits(input) {
	const persian = "۰۱۲۳۴۵۶۷۸۹";
	const arabic = "٠١٢٣٤٥٦٧٨٩";
	let value = input.replace(/[۰-۹]/g, (ch) => String(persian.indexOf(ch))).replace(/[٠-٩]/g, (ch) => String(arabic.indexOf(ch))).replace(/\s/g, "").replace(/٫/g, ".");
	if (value.includes(",") && !value.includes(".")) value = value.replace(",", ".");
	return value.replace(/[,٬]/g, "");
}
function parseAmount(input) {
	const cleaned = normalizeDigits(input);
	if (!/^\d+(\.\d*)?$/.test(cleaned)) return null;
	const n = Number(cleaned.endsWith(".") ? cleaned.slice(0, -1) : cleaned);
	if (!Number.isFinite(n)) return null;
	return n;
}
function todayIso() {
	const now = /* @__PURE__ */ new Date();
	return padIso(now.getFullYear(), now.getMonth() + 1, now.getDate());
}
function padIso(y, m, d) {
	return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}
function toJalaliParts(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return toJalaali(y, m, d);
}
function isoFromJalali(jy, jm, jd) {
	const { gy, gm, gd } = toGregorian(jy, jm, jd);
	return padIso(gy, gm, gd);
}
function weekdayName(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()] ?? "";
}
function formatJalaliDate(iso) {
	const { jy, jm, jd } = toJalaliParts(iso);
	return `${weekdayName(iso)} ${formatInt(jd)} ${MONTHS[jm - 1]} ${formatInt(jy)}`;
}
function shiftMonth(jy, jm, delta) {
	let index = jm - 1 + delta;
	let year = jy;
	while (index < 0) {
		index += 12;
		year -= 1;
	}
	while (index > 11) {
		index -= 12;
		year += 1;
	}
	return {
		jy: year,
		jm: index + 1
	};
}
function monthLength(jy, jm) {
	return jalaaliMonthLength(jy, jm);
}
function entryHours(entry) {
	return BASE_HOURS[entry.kind] + entry.overtime;
}
function summarize(entries) {
	let morningCount = 0;
	let eveningCount = 0;
	let overtime = 0;
	for (const entry of entries) {
		if (entry.kind === "morning") morningCount += 1;
		else eveningCount += 1;
		overtime += entry.overtime;
	}
	const morningHours = morningCount * BASE_HOURS.morning;
	const eveningHours = eveningCount * BASE_HOURS.evening;
	return {
		morningCount,
		eveningCount,
		morningHours,
		eveningHours,
		overtime: round2(overtime),
		totalHours: round2(morningHours + eveningHours + overtime),
		count: entries.length
	};
}
function income(totalHours, hourly, fx) {
	const iqd = totalHours * hourly;
	const irr = iqd * fx;
	return {
		iqd,
		irr,
		toman: irr / 10
	};
}
function inMonth(iso, jy, jm) {
	const j = toJalaliParts(iso);
	return j.jy === jy && j.jm === jm;
}
function isKind(value) {
	return value === "morning" || value === "evening";
}
function isEntry(value) {
	if (!value || typeof value !== "object") return false;
	const entry = value;
	return typeof entry.id === "string" && typeof entry.iso === "string" && /^\d{4}-\d{2}-\d{2}$/.test(entry.iso) && isKind(entry.kind) && typeof entry.overtime === "number" && Number.isFinite(entry.overtime) && entry.overtime >= 0 && typeof entry.note === "string";
}
function loadModel() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return {
			entries: [],
			hourlyRate: "4.5",
			fxRate: DEFAULT_FX
		};
		const parsed = JSON.parse(raw);
		return {
			entries: Array.isArray(parsed.entries) ? parsed.entries.filter(isEntry) : [],
			hourlyRate: typeof parsed.hourlyRate === "string" ? parsed.hourlyRate : "4.5",
			fxRate: typeof parsed.fxRate === "string" ? parsed.fxRate : DEFAULT_FX
		};
	} catch {
		return {
			entries: [],
			hourlyRate: "4.5",
			fxRate: DEFAULT_FX
		};
	}
}
function saveModel(model) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(model));
}
function summaryText(input) {
	const lines = [
		`خلاصه کارکرد ${input.title}`,
		`شیفت صبح: ${formatInt(input.morningCount)} × ${formatInt(BASE_HOURS.morning)} = ${formatQty(input.morningHours)} ساعت`,
		`شیفت عصر: ${formatInt(input.eveningCount)} × ${formatInt(BASE_HOURS.evening)} = ${formatQty(input.eveningHours)} ساعت`,
		`اضافه‌کاری: ${formatQty(input.overtime)} ساعت`,
		`ساعت کل کارکرد: ${formatQty(input.totalHours)}`
	];
	if (input.hourly != null && input.iqd != null) lines.push(`درآمد: ${formatQty(input.totalHours)} × ${formatQty(input.hourly)} = ${formatMoney(input.iqd)} دینار عراق`);
	if (input.fx != null && input.irr != null) {
		lines.push(`ریال ایران: ${formatRial(input.irr)} (هر دینار = ${formatMoney(input.fx)} ریال)`);
		lines.push(`معادل تومان: ${formatRial(input.irr / 10)}`);
	}
	return lines.join("\n");
}
var OT_CHIPS = [
	"0",
	"0.5",
	"1",
	"1.5",
	"2",
	"3",
	"4"
];
function blankDraft(iso, kind = "morning") {
	const j = toJalaliParts(iso);
	return {
		jy: j.jy,
		jm: j.jm,
		jd: j.jd,
		kind,
		overtime: "0",
		note: ""
	};
}
function LedgerApp() {
	const [model, setModel] = (0, import_react.useState)({
		entries: [],
		hourlyRate: "4.5",
		fxRate: DEFAULT_FX
	});
	const [view, setView] = (0, import_react.useState)(() => {
		const today = toJalaliParts(todayIso());
		return {
			jy: today.jy,
			jm: today.jm
		};
	});
	const [scope, setScope] = (0, import_react.useState)("month");
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const loaded = loadModel();
		setModel(loaded);
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (hydrated) saveModel(model);
	}, [model, hydrated]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ledger, {
		model,
		setModel,
		view,
		setView,
		scope,
		setScope
	});
}
function Ledger({ model, setModel, view, setView, scope, setScope }) {
	const yearAnchor = toJalaliParts(todayIso()).jy;
	const [draft, setDraft] = (0, import_react.useState)(() => blankDraft(todayIso()));
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [formError, setFormError] = (0, import_react.useState)(null);
	const [flash, setFlash] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const [confirmClear, setConfirmClear] = (0, import_react.useState)(false);
	const visible = (0, import_react.useMemo)(() => {
		return model.entries.filter((entry) => scope === "all" ? true : inMonth(entry.iso, view.jy, view.jm)).sort((a, b) => b.iso.localeCompare(a.iso) || b.id.localeCompare(a.id));
	}, [
		model.entries,
		scope,
		view
	]);
	const stats = summarize(visible);
	const hourly = parseAmount(model.hourlyRate);
	const fx = parseAmount(model.fxRate);
	const pay = hourly != null && fx != null ? income(stats.totalHours, hourly, fx) : null;
	const periodTitle = scope === "all" ? "همه شیفت‌ها" : `${MONTHS[view.jm - 1]} ${formatInt(view.jy)}`;
	const years = (0, import_react.useMemo)(() => {
		const list = /* @__PURE__ */ new Set();
		for (let y = yearAnchor - 5; y <= yearAnchor + 1; y += 1) list.add(y);
		list.add(draft.jy);
		return [...list].sort((a, b) => a - b);
	}, [draft.jy, yearAnchor]);
	const days = monthLength(draft.jy, draft.jm);
	const overtimeValue = parseAmount(draft.overtime);
	const shiftTotal = overtimeValue == null ? null : BASE_HOURS[draft.kind] + overtimeValue;
	function updateDraft(partial) {
		setDraft((current) => {
			const next = {
				...current,
				...partial
			};
			const len = monthLength(next.jy, next.jm);
			if (next.jd > len) next.jd = len;
			return next;
		});
		setFormError(null);
		setFlash(null);
	}
	function onSubmit(event) {
		event.preventDefault();
		const overtime = parseAmount(draft.overtime);
		if (overtime == null || overtime > 24) {
			setFormError("ساعت اضافه‌کاری را بین ۰ تا ۲۴ وارد کنید.");
			return;
		}
		const iso = isoFromJalali(draft.jy, draft.jm, draft.jd);
		const nextEntry = {
			id: editingId ?? crypto.randomUUID(),
			iso,
			kind: draft.kind,
			overtime: Math.round(overtime * 100) / 100,
			note: draft.note.trim().slice(0, 80)
		};
		setModel((current) => {
			const entries = editingId ? current.entries.map((entry) => entry.id === editingId ? nextEntry : entry) : [nextEntry, ...current.entries];
			return {
				...current,
				entries
			};
		});
		setFormError(null);
		setFlash(editingId ? "شیفت ویرایش شد" : "شیفت ثبت شد");
		if (scope === "month") {
			const saved = toJalaliParts(iso);
			setView({
				jy: saved.jy,
				jm: saved.jm
			});
		}
		setDraft((current) => ({
			...current,
			overtime: "0",
			note: ""
		}));
		if (editingId) setEditingId(null);
	}
	function startEdit(entry) {
		const j = toJalaliParts(entry.iso);
		setEditingId(entry.id);
		setDraft({
			jy: j.jy,
			jm: j.jm,
			jd: j.jd,
			kind: entry.kind,
			overtime: String(entry.overtime),
			note: entry.note
		});
		setFormError(null);
		setFlash(null);
		document.getElementById("shift-form")?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}
	function cancelEdit() {
		setEditingId(null);
		setDraft(blankDraft(todayIso()));
		setFormError(null);
	}
	async function copySummary() {
		const text = summaryText({
			title: periodTitle,
			...stats,
			hourly,
			fx,
			iqd: pay?.iqd ?? null,
			irr: pay?.irr ?? null
		});
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1800);
		} catch {
			setFlash("کپی انجام نشد");
		}
	}
	function bumpOvertime(delta) {
		const current = parseAmount(draft.overtime) ?? 0;
		const next = Math.min(24, Math.max(0, Math.round((current + delta) * 2) / 2));
		updateDraft({ overtime: String(next) });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-xl px-4 py-6 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-primary",
						children: "کادر درمان"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-extrabold text-balance",
						children: "دفتر شیفت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty text-muted",
						children: "شیفت صبح ۹ ساعت است و شیفت عصر ۸ ساعت. اگر بیشتر از شیفت مانده‌اید، فقط همان ساعت اضافه را بنویسید."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-12 shrink-0 place-items-center rounded-2xl bg-primary text-on-primary",
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stethoscope, {
						size: 22,
						strokeWidth: 1.75
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-full border border-line bg-surface text-ink disabled:opacity-40",
							"aria-label": "ماه قبل",
							disabled: scope === "all",
							onClick: () => setView(shiftMonth(view.jy, view.jm, -1)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 20 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-36 text-center text-lg font-bold",
							children: periodTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-full border border-line bg-surface text-ink disabled:opacity-40",
							"aria-label": "ماه بعد",
							disabled: scope === "all",
							onClick: () => setView(shiftMonth(view.jy, view.jm, 1)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { size: 20 })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid h-14 grid-cols-2 rounded-full border border-line bg-surface p-1",
					role: "tablist",
					"aria-label": "بازه محاسبه",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": scope === "month",
						className: scope === "month" ? "rounded-full bg-primary font-semibold text-on-primary" : "rounded-full text-muted",
						onClick: () => setScope("month"),
						children: "این ماه"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": scope === "all",
						className: scope === "all" ? "rounded-full bg-primary font-semibold text-on-primary" : "rounded-full text-muted",
						onClick: () => setScope("all"),
						children: "همه"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "payslip mb-5 rounded-card px-5 py-5 ps-8 shadow-card sm:px-6 sm:ps-10",
				"aria-live": "polite",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-bold",
							children: "فیش کارکرد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: periodTitle
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: copySummary,
							className: "inline-flex h-11 items-center gap-2 rounded-full border border-line bg-bg px-3 text-sm font-medium text-ink",
							children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { size: 16 }), copied ? "کپی شد" : "کپی خلاصه"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-line py-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-sm text-muted",
										children: "ساعت کل کارکرد"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
										className: "num mt-1 text-4xl font-extrabold leading-none",
										children: [formatQty(stats.totalHours), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ms-2 text-lg font-semibold text-muted",
											children: "ساعت"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-sm text-muted",
										children: [
											formatInt(stats.morningCount),
											" صبح (",
											formatQty(stats.morningHours),
											")",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-1.5",
												children: "·"
											}),
											formatInt(stats.eveningCount),
											" عصر (",
											formatQty(stats.eveningHours),
											")",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-1.5",
												children: "·"
											}),
											"اضافه‌کار ",
											formatQty(stats.overtime)
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-line py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
									className: "text-sm text-muted",
									children: [
										"ساعت کل × ",
										hourly == null ? "—" : formatQty(hourly),
										" دینار عراق"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "num mt-1 text-3xl font-bold leading-tight",
									children: [pay ? formatMoney(pay.iqd) : "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ms-2 text-base font-semibold text-muted",
										children: "دینار"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-line py-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-sm text-muted",
										children: "ارزش درآمد کل به ریال ایران"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
										className: "num mt-1 text-3xl font-extrabold leading-tight text-primary",
										children: [pay ? formatRial(pay.irr) : "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ms-2 text-base font-semibold text-muted",
											children: "ریال"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted",
										children: pay ? `معادل ${formatRial(pay.toman)} تومان` : "نرخ ساعت یا نرخ تبدیل نامعتبر است"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 border-t border-line pt-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "نرخ هر ساعت (دینار)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								value: model.hourlyRate,
								onChange: (event) => setModel((current) => ({
									...current,
									hourlyRate: event.target.value
								})),
								className: "mt-1 h-12 w-full rounded-xl border border-line bg-bg px-3 text-base text-ink"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "هر دینار چند ریال"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								value: model.fxRate,
								onChange: (event) => setModel((current) => ({
									...current,
									fxRate: event.target.value
								})),
								className: "mt-1 h-12 w-full rounded-xl border border-line bg-bg px-3 text-base text-ink"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-pretty text-muted",
						children: "پیش‌فرض نرخ ساعت ۴٫۵ دینار است. تبدیل پیش‌فرض، نرخ میان‌بازار ۱۸ آبان ۱۴۰۵ است: هر دینار ≈ ۹۰۵٫۵۲ ریال. تومان برابر ریال تقسیم بر ۱۰ است. هر دو عدد را می‌توانید عوض کنید."
					}),
					(model.hourlyRate !== "4.5" || model.fxRate !== "905.52") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-2 text-sm font-semibold text-primary",
						onClick: () => setModel((current) => ({
							...current,
							hourlyRate: "4.5",
							fxRate: "905.52"
						})),
						children: "بازگشت به نرخ پیش‌فرض"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				id: "shift-form",
				onSubmit,
				className: "mb-5 rounded-card bg-surface p-4 shadow-card sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-bold",
							children: editingId ? "ویرایش شیفت" : "ثبت شیفت"
						}), editingId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: cancelEdit,
							className: "text-sm font-semibold text-muted",
							children: "انصراف"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-2 text-sm font-medium",
						children: "تاریخ شمسی"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								label: "روز",
								value: draft.jd,
								onChange: (jd) => updateDraft({ jd }),
								options: Array.from({ length: days }, (_, i) => i + 1)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								label: "ماه",
								value: draft.jm,
								onChange: (jm) => updateDraft({ jm }),
								options: MONTHS.map((name, index) => ({
									value: index + 1,
									label: name
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								label: "سال",
								value: draft.jy,
								onChange: (jy) => updateDraft({ jy }),
								options: years
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "mb-2 text-sm font-medium",
							children: "نوع شیفت"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							role: "radiogroup",
							"aria-label": "نوع شیفت",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindButton, {
								active: draft.kind === "morning",
								onClick: () => updateDraft({ kind: "morning" }),
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { size: 18 }),
								title: "صبح",
								detail: "۹ ساعت"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindButton, {
								active: draft.kind === "evening",
								onClick: () => updateDraft({ kind: "evening" }),
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { size: 18 }),
								title: "عصر",
								detail: "۸ ساعت",
								tone: "accent"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "overtime",
								className: "text-sm font-medium",
								children: "ساعت اضافه‌کاری"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-sm text-muted",
								children: "فقط ساعت‌های بیشتر از طول شیفت. اگر اضافه نمانده‌اید، صفر بگذارید."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "کم کردن اضافه‌کاری",
										onClick: () => bumpOvertime(-.5),
										className: "grid size-12 place-items-center rounded-xl border border-line bg-bg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 18 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "overtime",
										inputMode: "decimal",
										value: draft.overtime,
										onChange: (event) => updateDraft({ overtime: event.target.value }),
										className: "num h-12 min-w-0 flex-1 rounded-xl border border-line bg-bg px-3 text-center text-lg font-bold"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "افزودن اضافه‌کاری",
										onClick: () => bumpOvertime(.5),
										className: "grid size-12 place-items-center rounded-xl border border-line bg-bg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: OT_CHIPS.map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => updateDraft({ overtime: chip }),
									className: draft.overtime === chip ? "h-11 rounded-full bg-primary px-3 text-sm font-semibold text-on-primary" : "h-11 rounded-full border border-line bg-bg px-3 text-sm text-ink",
									children: formatQty(Number(chip))
								}, chip))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 block text-sm font-medium",
						htmlFor: "note",
						children: ["توضیح (اختیاری)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "note",
							value: draft.note,
							maxLength: 80,
							onChange: (event) => updateDraft({ note: event.target.value }),
							placeholder: "مثلاً اورژانس یا بخش داخلی",
							className: "mt-2 h-12 w-full rounded-xl border border-line bg-bg px-3 text-base font-normal placeholder:text-muted"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 rounded-xl bg-primary-soft px-3 py-3 text-sm text-primary",
						children: shiftTotal == null ? "ساعت اضافه‌کاری نامعتبر است." : `این نوبت: ${formatQty(BASE_HOURS[draft.kind])} ساعت ${KIND_LABEL[draft.kind]} + ${formatQty(overtimeValue ?? 0)} اضافه‌کار = ${formatQty(shiftTotal)} ساعت`
					}),
					formError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm font-medium text-accent",
						children: formError
					}),
					flash && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm font-medium text-primary",
						role: "status",
						children: flash
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "mt-4 h-12 w-full rounded-xl bg-primary text-base font-bold text-on-primary transition-colors duration-200 hover:bg-primary/90",
						children: editingId ? "ذخیره ویرایش" : "ثبت شیفت"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mb-3 text-lg font-bold",
				children: ["شیفت‌ها", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "ms-2 text-sm font-medium text-muted",
					children: [formatInt(visible.length), " مورد"]
				})]
			}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-card border border-dashed border-line bg-surface px-4 py-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "هنوز شیفتی در این بازه نیست"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "اولین صبح یا عصر را ثبت کنید تا فیش بالا پر شود."
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: visible.map((entry) => {
					const j = toJalaliParts(entry.iso);
					const confirming = pendingDelete === entry.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-card border border-line bg-surface px-3 py-3 sm:px-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: entry.kind === "morning" ? "grid size-12 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary" : "grid size-12 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "num text-lg font-extrabold leading-none",
										children: formatInt(j.jd)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: entry.kind === "morning" ? "rounded-full bg-primary-soft px-2 py-0.5 text-xs font-bold text-primary" : "rounded-full bg-accent-soft px-2 py-0.5 text-xs font-bold text-accent",
												children: KIND_LABEL[entry.kind]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-sm text-muted",
												children: [
													weekdayName(entry.iso),
													" ",
													MONTHS[j.jm - 1]
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "num mt-1 font-semibold",
											children: entry.overtime > 0 ? `${formatQty(BASE_HOURS[entry.kind])} + ${formatQty(entry.overtime)} اضافه‌کار = ${formatQty(entryHours(entry))} ساعت` : `${formatQty(BASE_HOURS[entry.kind])} ساعت شیفت`
										}),
										entry.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm text-muted",
											children: entry.note
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0 gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": `ویرایش شیفت ${formatJalaliDate(entry.iso)}`,
										onClick: () => startEdit(entry),
										className: "grid size-11 place-items-center rounded-xl text-ink",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { size: 18 })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": `حذف شیفت ${formatJalaliDate(entry.iso)}`,
										onClick: () => setPendingDelete(confirming ? null : entry.id),
										className: "grid size-11 place-items-center rounded-xl text-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 18 })
									})]
								})
							]
						}), confirming && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center justify-between gap-2 rounded-xl bg-accent-soft px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-accent",
								children: "این شیفت حذف شود؟"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-10 rounded-lg px-3 text-sm font-semibold text-muted",
									onClick: () => setPendingDelete(null),
									children: "خیر"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-10 rounded-lg bg-accent px-3 text-sm font-semibold text-on-primary",
									onClick: () => {
										setModel((current) => ({
											...current,
											entries: current.entries.filter((item) => item.id !== entry.id)
										}));
										if (editingId === entry.id) cancelEdit();
										setPendingDelete(null);
									},
									children: "بله، حذف"
								})]
							})]
						})]
					}, entry.id);
				})
			})] }),
			model.entries.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 border-t border-line pt-4",
				children: [confirmClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "همه شیفت‌های ذخیره‌شده پاک شوند؟"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-10 rounded-lg px-3 text-sm font-semibold text-muted",
							onClick: () => setConfirmClear(false),
							children: "انصراف"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-10 rounded-lg bg-accent px-3 text-sm font-semibold text-on-primary",
							onClick: () => {
								setModel((current) => ({
									...current,
									entries: []
								}));
								setConfirmClear(false);
								setEditingId(null);
							},
							children: "پاک کردن همه"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setConfirmClear(true),
					className: "text-sm font-medium text-muted",
					children: "پاک کردن همه شیفت‌ها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "شیفت‌ها فقط روی همین دستگاه می‌مانند."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "apk-link mt-8 text-sm text-pretty text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "font-semibold text-primary",
					href: "/daftar-shift.apk",
					download: "daftar-shift.apk",
					children: "دانلود برنامه اندروید"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block",
					children: "فایل را روی گوشی باز کنید. اگر اندروید پرسید، نصب از این منبع را اجازه دهید. برنامه بدون اینترنت کار می‌کند و شیفت‌ها داخل خود گوشی می‌مانند."
				})]
			})
		]
	});
}
function Select({ label, value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs text-muted",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			value,
			onChange: (event) => onChange(Number(event.target.value)),
			className: "mt-1 h-12 w-full rounded-xl border border-line bg-bg px-2 text-base font-semibold text-ink",
			children: options.map((option) => {
				const item = typeof option === "number" ? {
					value: option,
					label: formatInt(option)
				} : option;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: item.value,
					children: item.label
				}, item.value);
			})
		})]
	});
}
function KindButton({ active, onClick, icon, title, detail, tone = "primary" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "radio",
		"aria-checked": active,
		onClick,
		className: `flex h-16 items-center justify-center gap-2 rounded-xl border text-base font-bold ${active ? tone === "accent" ? "border-accent bg-accent-soft text-accent" : "border-primary bg-primary-soft text-primary" : "border-line bg-bg text-ink"}`,
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 block text-xs font-medium",
			children: detail
		})] })]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerApp, {});
}
//#endregion
export { Home as component };
