import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as isFpsTarget, I as presetLabel, U as useSelectedGame, V as useAppStore, a as Button, h as Notice, j as formatWhen, u as Field } from "./ui-CJMJB--P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fps-tools-C4CmmVU9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tooltipStyle = {
	background: "var(--color-surface)",
	border: "1px solid var(--color-line)",
	borderRadius: 12,
	color: "var(--color-fg)",
	fontSize: 12
};
function FpsChart({ data }) {
	const [mod, setMod] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("../_libs/recharts+[...].mjs").then((n) => n.t).then((loaded) => {
			if (live) setMod(loaded);
		});
		return () => {
			live = false;
		};
	}, []);
	if (!mod) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-52 place-items-center text-sm text-muted",
		children: "Chart loading…"
	});
	const { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } = mod;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-52 w-full min-w-0 text-primary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-line)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						tick: {
							fill: "var(--color-faint)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tick: {
							fill: "var(--color-faint)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						width: 32
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "measured",
						name: "Measured",
						stroke: "currentColor",
						strokeWidth: 2,
						dot: false,
						isAnimationActive: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "target",
						name: "Target",
						stroke: "var(--color-faint)",
						strokeDasharray: "4 4",
						dot: false,
						isAnimationActive: false
					})
				]
			})
		})
	});
}
function CompareChart({ data }) {
	const [mod, setMod] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("../_libs/recharts+[...].mjs").then((n) => n.t).then((loaded) => {
			if (live) setMod(loaded);
		});
		return () => {
			live = false;
		};
	}, []);
	if (!mod) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-52 place-items-center text-sm text-muted",
		children: "Chart loading…"
	});
	const { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } = mod;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-52 w-full min-w-0 text-primary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-line)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						tick: {
							fill: "var(--color-faint)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						interval: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tick: {
							fill: "var(--color-faint)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						width: 32
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "measured",
						name: "Measured FPS",
						fill: "currentColor",
						radius: [
							6,
							6,
							0,
							0
						],
						isAnimationActive: false
					})
				]
			})
		})
	});
}
function FpsLogTool({ compact = false }) {
	const game = useSelectedGame();
	const logs = useAppStore((state) => state.fpsLogs);
	const refresh = useAppStore((state) => state.refreshSample);
	const addFpsLog = useAppStore((state) => state.addFpsLog);
	const removeFpsLog = useAppStore((state) => state.removeFpsLog);
	const [measured, setMeasured] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [saved, setSaved] = (0, import_react.useState)(false);
	const visible = (game ? logs.filter((entry) => entry.gameId === game.id) : logs).slice(0, compact ? 8 : 20);
	const chart = [...visible].reverse().map((entry) => ({
		label: formatWhen(entry.at),
		measured: entry.measuredFps,
		target: entry.targetFps
	}));
	function save() {
		const value = Number(measured);
		if (!Number.isFinite(value) || value < 1 || value > 1e3) {
			setError("Enter a measured FPS from 1 to 1000.");
			setSaved(false);
			return;
		}
		const target = game && isFpsTarget(game.fpsTarget) ? game.fpsTarget : 60;
		if (!addFpsLog({
			gameId: game?.id ?? null,
			measuredFps: value,
			targetFps: target,
			refreshHz: refresh?.displayHz ?? null,
			note: note.trim()
		})) {
			setError("That measurement was not saved.");
			setSaved(false);
			return;
		}
		setMeasured("");
		setNote("");
		setError(null);
		setSaved(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Measured FPS",
				hint: game ? `Saved against ${game.name}. Target stored with the row: ${game.fpsTarget}.` : "No profile selected. The row is still saved.",
				error,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field-input tabular-nums",
					inputMode: "decimal",
					value: measured,
					onChange: (event) => setMeasured(event.target.value),
					placeholder: "What you measured"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Note",
				hint: "Optional. Where the number came from.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field-input",
					value: note,
					maxLength: 200,
					onChange: (event) => setNote(event.target.value),
					placeholder: "In-game counter, 30 second count…"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				children: "Save measurement"
			}),
			saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				tone: "ok",
				children: "Saved in the manual log on this device."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: "These points are numbers you entered. The chart does not read the game."
			}),
			chart.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FpsChart, { data: chart }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No measurements yet."
			}),
			visible.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-line",
				children: visible.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start justify-between gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-semibold tabular-nums",
						children: [
							entry.measuredFps,
							" measured · target ",
							entry.targetFps
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-faint",
						children: [
							formatWhen(entry.at),
							entry.refreshHz != null ? ` · refresh sample ${entry.refreshHz} Hz` : "",
							entry.note ? ` · ${entry.note}` : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "shrink-0 px-2",
						onClick: () => removeFpsLog(entry.id),
						children: "Remove"
					})]
				}, entry.id))
			}) : null
		]
	});
}
function CompareTool() {
	const game = useSelectedGame();
	const compares = useAppStore((state) => state.compares);
	const addCompare = useAppStore((state) => state.addCompare);
	const removeCompare = useAppStore((state) => state.removeCompare);
	const [label, setLabel] = (0, import_react.useState)("");
	const [measured, setMeasured] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	function save() {
		const value = Number(measured);
		if (!Number.isFinite(value) || value < 1 || value > 1e3) {
			setError("Enter the measured FPS for this run.");
			return;
		}
		if (!addCompare({
			label,
			gameId: game?.id ?? null,
			preset: game ? presetLabel(game.preset) : "No profile",
			measuredFps: value,
			targetFps: game?.fpsTarget ?? 60,
			note: note.trim()
		})) {
			setError("That comparison was not saved.");
			return;
		}
		setLabel("");
		setMeasured("");
		setNote("");
		setError(null);
	}
	const chart = [...compares].slice(0, 8).reverse().map((entry) => ({
		label: entry.label.slice(0, 12),
		measured: entry.measuredFps
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Run label",
				error,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field-input",
					value: label,
					maxLength: 60,
					onChange: (event) => setLabel(event.target.value),
					placeholder: "Balanced, shadows low"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Measured FPS",
				hint: "Type the FPS you observed. This is not a benchmark runner.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field-input tabular-nums",
					inputMode: "decimal",
					value: measured,
					onChange: (event) => setMeasured(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Note",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field-input",
					value: note,
					maxLength: 200,
					onChange: (event) => setNote(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				children: "Add to comparison log"
			}),
			chart.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareChart, { data: chart }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Add two or more runs to compare them."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-line",
				children: compares.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start justify-between gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: entry.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted tabular-nums",
							children: [
								entry.measuredFps,
								" measured · target ",
								entry.targetFps,
								" · ",
								entry.preset
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-faint",
							children: [formatWhen(entry.at), entry.note ? ` · ${entry.note}` : ""]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "shrink-0 px-2",
						onClick: () => removeCompare(entry.id),
						children: "Remove"
					})]
				}, entry.id))
			})
		]
	});
}
//#endregion
export { FpsLogTool as n, CompareTool as t };
