import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.functions-rB4Yw27V.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asPicks(value) {
	if (!value || typeof value !== "object") return [];
	const picks = value.picks;
	if (!Array.isArray(picks)) return [];
	return picks.flatMap((item) => {
		if (!item || typeof item !== "object") return [];
		const row = item;
		if (typeof row.partId !== "string" || typeof row.assignee !== "string") return [];
		const assistant = typeof row.assistant === "string" && row.assistant.trim() && row.assistant !== "null" ? row.assistant : null;
		return [{
			partId: row.partId,
			assignee: row.assignee,
			assistant,
			reason: typeof row.reason === "string" ? row.reason.slice(0, 280) : ""
		}];
	});
}
var arrangeWithGrok_createServerFn_handler = createServerRpc({
	id: "ab91f07c010894d1dde65bfcd19126cca80625b1ae1581aec1e2c3fdaa6a4a62",
	name: "arrangeWithGrok",
	filename: "src/lib/ministry/ai.functions.ts"
}, (opts) => arrangeWithGrok.__executeServer(opts));
var arrangeWithGrok = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input.brief !== "string" || input.brief.length < 20 || input.brief.length > 14e3) throw new Error("Invalid arrangement request");
	return { brief: input.brief };
}).handler(arrangeWithGrok_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available"
	};
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .2,
				max_tokens: 1400,
				response_format: { type: "json_object" },
				messages: [{
					role: "system",
					content: "You assist a congregation overseer with the midweek meeting. Use only people in the roster. Respect who may receive each part: brothers only when who is brother, no unbaptized publishers on chairman, prayer, treasures, gems, living talks, or conducting the Bible study. Prefer elders for chairman, spiritual gems, and the Congregation Bible study. Do not assign anyone marked away. Do not use the same person twice in one meeting, including as an assistant. Balance recentParts so the load is fair. Return JSON only with keys summary and picks. picks is an array of {partId, assignee, assistant, reason}. assistant is a full name or null. reason is one calm sentence."
				}, {
					role: "user",
					content: data.brief
				}]
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `xAI API error ${res.status}`
		};
		const text = (await res.json()).choices?.[0]?.message?.content ?? "";
		const parsed = JSON.parse(text);
		const picks = asPicks(parsed);
		if (!picks.length) return {
			ok: false,
			error: "Empty arrangement"
		};
		return {
			ok: true,
			summary: typeof parsed.summary === "string" && parsed.summary.trim() ? parsed.summary.trim().slice(0, 400) : "A balanced arrangement is ready for the overseer to review.",
			picks
		};
	} catch {
		return {
			ok: false,
			error: "AI could not complete the arrangement"
		};
	}
});
//#endregion
export { arrangeWithGrok_createServerFn_handler };
