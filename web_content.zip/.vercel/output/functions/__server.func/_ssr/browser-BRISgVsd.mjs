import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as ExternalLink, I as ArrowRight, L as ArrowLeft, T as House, c as ShieldAlert, d as RefreshCw, p as Plus, t as X } from "../_libs/lucide-react.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as Input, L as SEARCH_ENGINES, P as Button, S as usePlayer, V as cn, a as useBrowser, i as useDownloads, k as useLibrary, o as useSettings } from "./router-5I6roosF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/browser-BRISgVsd.js
var import_jsx_runtime = require_jsx_runtime();
var DIRECT = /\.(mp4|webm|ogg|ogv|mp3|wav|m4a|aac|flac|opus|mov|m4v)(\?|$)/i;
function BrowserPage() {
	const tabs = useBrowser((s) => s.tabs);
	const activeId = useBrowser((s) => s.activeId);
	const address = useBrowser((s) => s.address);
	const history = useBrowser((s) => s.history);
	const setAddress = useBrowser((s) => s.setAddress);
	const navigateTab = useBrowser((s) => s.navigate);
	const back = useBrowser((s) => s.back);
	const forward = useBrowser((s) => s.forward);
	const reload = useBrowser((s) => s.reload);
	const home = useBrowser((s) => s.home);
	const newTab = useBrowser((s) => s.newTab);
	const closeTab = useBrowser((s) => s.closeTab);
	const activate = useBrowser((s) => s.activate);
	const setTabMeta = useBrowser((s) => s.setTabMeta);
	const homepage = useSettings((s) => s.homepage);
	const engine = useSettings((s) => s.searchEngine);
	const remember = useSettings((s) => s.rememberHistory);
	const enqueue = useDownloads((s) => s.enqueue);
	const addUrl = useLibrary((s) => s.addUrl);
	const openPlayer = usePlayer((s) => s.open);
	const nav = useNavigate();
	const active = tabs.find((t) => t.id === activeId) ?? tabs[0];
	const prefix = SEARCH_ENGINES[engine].url;
	const go = (raw = address) => navigateTab(raw, prefix, remember);
	const playIfDirect = () => {
		if (!active) return;
		if (!DIRECT.test(active.url)) {
			toast.error("Not a direct media file. UPLAY.IND does not rip media from web pages.");
			return;
		}
		const item = addUrl(active.title || active.url, active.url, /\.(mp3|wav|m4a|aac|flac|opus)(\?|$)/i.test(active.url) ? "audio" : "video");
		openPlayer(item);
		nav({
			to: "/player/$id",
			params: { id: item.id }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[70vh] flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Browser"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "A sandboxed page view. Camera, mic, and location are blocked. Many sites refuse to embed — open those externally."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1 overflow-x-auto",
				children: [tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => activate(t.id),
					className: cn("flex h-9 max-w-[10rem] items-center gap-1 rounded-lg px-2 text-xs", t.id === activeId ? "bg-secondary text-fg" : "text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: t.title || t.url
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						role: "button",
						tabIndex: 0,
						className: "rounded p-0.5 hover:bg-elevated",
						onClick: (e) => {
							e.stopPropagation();
							closeTab(t.id);
						},
						onKeyDown: (e) => {
							if (e.key === "Enter") closeTab(t.id);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
					})]
				}, t.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon-sm",
					variant: "ghost",
					onClick: newTab,
					"aria-label": "New tab",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						onClick: back,
						"aria-label": "Back",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						onClick: forward,
						"aria-label": "Forward",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						onClick: reload,
						"aria-label": "Reload",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						onClick: () => home(homepage),
						"aria-label": "Home",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
						className: "min-w-0 flex-1",
						onSubmit: (e) => {
							e.preventDefault();
							go();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: address,
							onChange: (e) => setAddress(e.target.value),
							"aria-label": "Address or search",
							placeholder: "Search or enter a URL"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: playIfDirect,
						children: "Play URL"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => {
							if (!active) return;
							enqueue(active.url);
							toast.message("Queued if this is a direct media file.");
						},
						children: "Download"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": "Open externally",
						onClick: () => active && window.open(active.url, "_blank", "noopener,noreferrer"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-[55vh] overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
				children: [active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title: active.title || "Browser tab",
					src: active.url,
					className: "size-full min-h-[55vh] bg-white",
					sandbox: "allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads",
					referrerPolicy: "no-referrer",
					allow: "",
					onLoad: () => setTabMeta(active.id, {
						loading: false,
						title: active.url
					}),
					onError: () => setTabMeta(active.id, {
						blocked: true,
						loading: false
					})
				}, active.url + String(active.loading)) : null, active?.blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-0 flex flex-col items-center justify-center gap-2 bg-surface p-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-8 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "This page cannot be embedded"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => window.open(active.url, "_blank", "noopener,noreferrer"),
							children: "Open externally"
						})
					]
				}) : null]
			}),
			remember && history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-muted",
				children: "History on this device"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 divide-y divide-border rounded-xl bg-surface",
				children: history.slice(0, 12).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex w-full truncate px-3 py-2 text-left text-sm hover:bg-secondary",
					onClick: () => go(h.url),
					children: h.url
				}) }, h.id))
			})] }) : null
		]
	});
}
//#endregion
export { BrowserPage as component };
