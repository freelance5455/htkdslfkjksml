import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChartColumn, a as Settings, c as Plus, d as House, f as History, g as ChevronLeft, h as Compass, i as Shield, l as Newspaper, m as Crown, o as ScanSearch, p as Grid2x2, r as Sparkles, s as Radar, t as Zap, u as MessageCircle, v as CalendarDays, y as Archive } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-4TGaMBwj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** 197 official draws, real N1–N5 order preserved. */
var SEED_DRAWS = [
	{
		date: "2026-01-02",
		day: "vendredi",
		numbers: [
			46,
			48,
			44,
			1,
			73
		]
	},
	{
		date: "2026-01-03",
		day: "samedi",
		numbers: [
			10,
			38,
			37,
			25,
			27
		]
	},
	{
		date: "2026-01-05",
		day: "lundi",
		numbers: [
			25,
			20,
			40,
			79,
			43
		]
	},
	{
		date: "2026-01-06",
		day: "mardi",
		numbers: [
			85,
			7,
			5,
			81,
			56
		]
	},
	{
		date: "2026-01-07",
		day: "mercredi",
		numbers: [
			18,
			37,
			60,
			49,
			46
		]
	},
	{
		date: "2026-01-08",
		day: "jeudi",
		numbers: [
			38,
			5,
			64,
			88,
			41
		]
	},
	{
		date: "2026-01-10",
		day: "samedi",
		numbers: [
			74,
			44,
			58,
			16,
			42
		]
	},
	{
		date: "2026-01-12",
		day: "lundi",
		numbers: [
			12,
			26,
			40,
			47,
			44
		]
	},
	{
		date: "2026-01-13",
		day: "mardi",
		numbers: [
			31,
			3,
			70,
			43,
			58
		]
	},
	{
		date: "2026-01-14",
		day: "mercredi",
		numbers: [
			76,
			10,
			51,
			45,
			63
		]
	},
	{
		date: "2026-01-15",
		day: "jeudi",
		numbers: [
			69,
			53,
			7,
			58,
			88
		]
	},
	{
		date: "2026-01-16",
		day: "vendredi",
		numbers: [
			15,
			49,
			7,
			70,
			66
		]
	},
	{
		date: "2026-01-17",
		day: "samedi",
		numbers: [
			42,
			81,
			27,
			31,
			23
		]
	},
	{
		date: "2026-01-19",
		day: "lundi",
		numbers: [
			86,
			74,
			57,
			60,
			8
		]
	},
	{
		date: "2026-01-20",
		day: "mardi",
		numbers: [
			21,
			17,
			11,
			76,
			86
		]
	},
	{
		date: "2026-01-21",
		day: "mercredi",
		numbers: [
			43,
			71,
			59,
			2,
			9
		]
	},
	{
		date: "2026-01-22",
		day: "jeudi",
		numbers: [
			60,
			82,
			89,
			80,
			84
		]
	},
	{
		date: "2026-01-23",
		day: "vendredi",
		numbers: [
			8,
			4,
			54,
			48,
			1
		]
	},
	{
		date: "2026-01-24",
		day: "samedi",
		numbers: [
			44,
			78,
			52,
			57,
			7
		]
	},
	{
		date: "2026-01-26",
		day: "lundi",
		numbers: [
			46,
			66,
			7,
			2,
			73
		]
	},
	{
		date: "2026-01-27",
		day: "mardi",
		numbers: [
			14,
			87,
			13,
			64,
			33
		]
	},
	{
		date: "2026-01-28",
		day: "mercredi",
		numbers: [
			20,
			40,
			36,
			48,
			56
		]
	},
	{
		date: "2026-01-29",
		day: "jeudi",
		numbers: [
			75,
			10,
			34,
			41,
			13
		]
	},
	{
		date: "2026-01-30",
		day: "vendredi",
		numbers: [
			9,
			40,
			34,
			26,
			7
		]
	},
	{
		date: "2026-01-31",
		day: "samedi",
		numbers: [
			6,
			39,
			71,
			48,
			70
		]
	},
	{
		date: "2026-02-02",
		day: "lundi",
		numbers: [
			43,
			51,
			25,
			4,
			35
		]
	},
	{
		date: "2026-02-03",
		day: "mardi",
		numbers: [
			23,
			75,
			63,
			43,
			37
		]
	},
	{
		date: "2026-02-04",
		day: "mercredi",
		numbers: [
			68,
			51,
			59,
			86,
			13
		]
	},
	{
		date: "2026-02-05",
		day: "jeudi",
		numbers: [
			47,
			5,
			45,
			66,
			15
		]
	},
	{
		date: "2026-02-06",
		day: "vendredi",
		numbers: [
			87,
			22,
			7,
			16,
			41
		]
	},
	{
		date: "2026-02-07",
		day: "samedi",
		numbers: [
			47,
			55,
			31,
			25,
			48
		]
	},
	{
		date: "2026-02-09",
		day: "lundi",
		numbers: [
			74,
			62,
			20,
			7,
			71
		]
	},
	{
		date: "2026-02-10",
		day: "mardi",
		numbers: [
			74,
			57,
			3,
			75,
			60
		]
	},
	{
		date: "2026-02-11",
		day: "mercredi",
		numbers: [
			68,
			79,
			82,
			7,
			73
		]
	},
	{
		date: "2026-02-12",
		day: "jeudi",
		numbers: [
			86,
			35,
			70,
			34,
			77
		]
	},
	{
		date: "2026-02-13",
		day: "vendredi",
		numbers: [
			77,
			55,
			60,
			85,
			1
		]
	},
	{
		date: "2026-02-14",
		day: "samedi",
		numbers: [
			13,
			16,
			15,
			11,
			71
		]
	},
	{
		date: "2026-02-16",
		day: "lundi",
		numbers: [
			34,
			5,
			22,
			69,
			72
		]
	},
	{
		date: "2026-02-17",
		day: "mardi",
		numbers: [
			61,
			64,
			48,
			59,
			79
		]
	},
	{
		date: "2026-02-18",
		day: "mercredi",
		numbers: [
			1,
			80,
			75,
			79,
			13
		]
	},
	{
		date: "2026-02-19",
		day: "jeudi",
		numbers: [
			75,
			4,
			46,
			12,
			2
		]
	},
	{
		date: "2026-02-20",
		day: "vendredi",
		numbers: [
			42,
			82,
			11,
			25,
			55
		]
	},
	{
		date: "2026-02-21",
		day: "samedi",
		numbers: [
			5,
			14,
			29,
			56,
			51
		]
	},
	{
		date: "2026-02-23",
		day: "lundi",
		numbers: [
			6,
			87,
			20,
			39,
			80
		]
	},
	{
		date: "2026-02-24",
		day: "mardi",
		numbers: [
			40,
			7,
			88,
			75,
			53
		]
	},
	{
		date: "2026-02-25",
		day: "mercredi",
		numbers: [
			15,
			39,
			11,
			3,
			44
		]
	},
	{
		date: "2026-02-26",
		day: "jeudi",
		numbers: [
			54,
			73,
			63,
			26,
			37
		]
	},
	{
		date: "2026-02-27",
		day: "vendredi",
		numbers: [
			12,
			46,
			8,
			84,
			15
		]
	},
	{
		date: "2026-02-28",
		day: "samedi",
		numbers: [
			90,
			73,
			53,
			84,
			77
		]
	},
	{
		date: "2026-03-02",
		day: "lundi",
		numbers: [
			86,
			58,
			49,
			45,
			55
		]
	},
	{
		date: "2026-03-03",
		day: "mardi",
		numbers: [
			55,
			26,
			36,
			72,
			14
		]
	},
	{
		date: "2026-03-04",
		day: "mercredi",
		numbers: [
			24,
			59,
			3,
			54,
			6
		]
	},
	{
		date: "2026-03-05",
		day: "jeudi",
		numbers: [
			22,
			13,
			86,
			53,
			57
		]
	},
	{
		date: "2026-03-07",
		day: "samedi",
		numbers: [
			50,
			9,
			34,
			33,
			25
		]
	},
	{
		date: "2026-03-09",
		day: "lundi",
		numbers: [
			67,
			6,
			34,
			17,
			28
		]
	},
	{
		date: "2026-03-10",
		day: "mardi",
		numbers: [
			14,
			48,
			27,
			64,
			15
		]
	},
	{
		date: "2026-03-11",
		day: "mercredi",
		numbers: [
			36,
			65,
			32,
			80,
			46
		]
	},
	{
		date: "2026-03-12",
		day: "jeudi",
		numbers: [
			29,
			40,
			44,
			22,
			84
		]
	},
	{
		date: "2026-03-13",
		day: "vendredi",
		numbers: [
			18,
			77,
			83,
			17,
			21
		]
	},
	{
		date: "2026-03-14",
		day: "samedi",
		numbers: [
			1,
			42,
			12,
			20,
			64
		]
	},
	{
		date: "2026-03-16",
		day: "lundi",
		numbers: [
			23,
			30,
			17,
			85,
			22
		]
	},
	{
		date: "2026-03-17",
		day: "mardi",
		numbers: [
			62,
			25,
			8,
			10,
			34
		]
	},
	{
		date: "2026-03-18",
		day: "mercredi",
		numbers: [
			60,
			37,
			65,
			90,
			9
		]
	},
	{
		date: "2026-03-19",
		day: "jeudi",
		numbers: [
			49,
			77,
			80,
			81,
			65
		]
	},
	{
		date: "2026-03-21",
		day: "samedi",
		numbers: [
			9,
			75,
			8,
			86,
			24
		]
	},
	{
		date: "2026-03-24",
		day: "mardi",
		numbers: [
			58,
			70,
			52,
			87,
			16
		]
	},
	{
		date: "2026-03-25",
		day: "mercredi",
		numbers: [
			24,
			19,
			7,
			56,
			29
		]
	},
	{
		date: "2026-03-26",
		day: "jeudi",
		numbers: [
			62,
			82,
			55,
			26,
			35
		]
	},
	{
		date: "2026-03-27",
		day: "vendredi",
		numbers: [
			43,
			33,
			23,
			11,
			9
		]
	},
	{
		date: "2026-03-28",
		day: "samedi",
		numbers: [
			32,
			66,
			17,
			47,
			24
		]
	},
	{
		date: "2026-03-30",
		day: "lundi",
		numbers: [
			80,
			23,
			66,
			12,
			34
		]
	},
	{
		date: "2026-03-31",
		day: "mardi",
		numbers: [
			53,
			69,
			35,
			18,
			3
		]
	},
	{
		date: "2026-04-01",
		day: "mercredi",
		numbers: [
			3,
			18,
			38,
			29,
			10
		]
	},
	{
		date: "2026-04-02",
		day: "jeudi",
		numbers: [
			14,
			63,
			4,
			30,
			19
		]
	},
	{
		date: "2026-04-04",
		day: "samedi",
		numbers: [
			82,
			16,
			44,
			50,
			47
		]
	},
	{
		date: "2026-04-07",
		day: "mardi",
		numbers: [
			4,
			71,
			25,
			55,
			12
		]
	},
	{
		date: "2026-04-08",
		day: "mercredi",
		numbers: [
			25,
			54,
			33,
			29,
			69
		]
	},
	{
		date: "2026-04-09",
		day: "jeudi",
		numbers: [
			71,
			50,
			27,
			39,
			20
		]
	},
	{
		date: "2026-04-10",
		day: "vendredi",
		numbers: [
			16,
			40,
			37,
			6,
			4
		]
	},
	{
		date: "2026-04-11",
		day: "samedi",
		numbers: [
			13,
			67,
			71,
			72,
			63
		]
	},
	{
		date: "2026-04-13",
		day: "lundi",
		numbers: [
			52,
			1,
			26,
			66,
			72
		]
	},
	{
		date: "2026-04-14",
		day: "mardi",
		numbers: [
			18,
			55,
			81,
			14,
			82
		]
	},
	{
		date: "2026-04-15",
		day: "mercredi",
		numbers: [
			76,
			87,
			60,
			56,
			30
		]
	},
	{
		date: "2026-04-16",
		day: "jeudi",
		numbers: [
			8,
			72,
			1,
			41,
			19
		]
	},
	{
		date: "2026-04-17",
		day: "vendredi",
		numbers: [
			41,
			65,
			87,
			85,
			6
		]
	},
	{
		date: "2026-04-18",
		day: "samedi",
		numbers: [
			71,
			72,
			60,
			41,
			79
		]
	},
	{
		date: "2026-04-20",
		day: "lundi",
		numbers: [
			13,
			4,
			28,
			27,
			51
		]
	},
	{
		date: "2026-04-21",
		day: "mardi",
		numbers: [
			21,
			31,
			85,
			28,
			35
		]
	},
	{
		date: "2026-04-22",
		day: "mercredi",
		numbers: [
			6,
			76,
			85,
			37,
			33
		]
	},
	{
		date: "2026-04-23",
		day: "jeudi",
		numbers: [
			18,
			27,
			6,
			24,
			55
		]
	},
	{
		date: "2026-04-24",
		day: "vendredi",
		numbers: [
			52,
			39,
			30,
			50,
			88
		]
	},
	{
		date: "2026-04-25",
		day: "samedi",
		numbers: [
			39,
			1,
			30,
			80,
			48
		]
	},
	{
		date: "2026-04-27",
		day: "lundi",
		numbers: [
			69,
			74,
			1,
			31,
			2
		]
	},
	{
		date: "2026-04-28",
		day: "mardi",
		numbers: [
			73,
			22,
			52,
			5,
			62
		]
	},
	{
		date: "2026-04-29",
		day: "mercredi",
		numbers: [
			71,
			39,
			76,
			58,
			32
		]
	},
	{
		date: "2026-04-30",
		day: "jeudi",
		numbers: [
			63,
			25,
			61,
			22,
			28
		]
	},
	{
		date: "2026-05-02",
		day: "samedi",
		numbers: [
			84,
			10,
			43,
			5,
			13
		]
	},
	{
		date: "2026-05-04",
		day: "lundi",
		numbers: [
			68,
			14,
			37,
			78,
			10
		]
	},
	{
		date: "2026-05-05",
		day: "mardi",
		numbers: [
			11,
			68,
			38,
			22,
			14
		]
	},
	{
		date: "2026-05-06",
		day: "mercredi",
		numbers: [
			73,
			69,
			7,
			9,
			82
		]
	},
	{
		date: "2026-05-07",
		day: "jeudi",
		numbers: [
			36,
			3,
			65,
			84,
			15
		]
	},
	{
		date: "2026-05-08",
		day: "vendredi",
		numbers: [
			3,
			71,
			69,
			32,
			2
		]
	},
	{
		date: "2026-05-09",
		day: "samedi",
		numbers: [
			80,
			74,
			56,
			10,
			3
		]
	},
	{
		date: "2026-05-11",
		day: "lundi",
		numbers: [
			50,
			86,
			1,
			33,
			56
		]
	},
	{
		date: "2026-05-12",
		day: "mardi",
		numbers: [
			77,
			64,
			17,
			67,
			63
		]
	},
	{
		date: "2026-05-13",
		day: "mercredi",
		numbers: [
			59,
			37,
			58,
			44,
			51
		]
	},
	{
		date: "2026-05-14",
		day: "jeudi",
		numbers: [
			33,
			78,
			47,
			28,
			24
		]
	},
	{
		date: "2026-05-15",
		day: "vendredi",
		numbers: [
			50,
			35,
			75,
			41,
			76
		]
	},
	{
		date: "2026-05-16",
		day: "samedi",
		numbers: [
			21,
			84,
			2,
			62,
			83
		]
	},
	{
		date: "2026-05-18",
		day: "lundi",
		numbers: [
			87,
			90,
			19,
			15,
			18
		]
	},
	{
		date: "2026-05-19",
		day: "mardi",
		numbers: [
			3,
			64,
			63,
			90,
			73
		]
	},
	{
		date: "2026-05-20",
		day: "mercredi",
		numbers: [
			80,
			5,
			66,
			40,
			35
		]
	},
	{
		date: "2026-05-21",
		day: "jeudi",
		numbers: [
			3,
			17,
			19,
			11,
			77
		]
	},
	{
		date: "2026-05-22",
		day: "vendredi",
		numbers: [
			23,
			69,
			63,
			13,
			31
		]
	},
	{
		date: "2026-05-23",
		day: "samedi",
		numbers: [
			86,
			24,
			14,
			19,
			40
		]
	},
	{
		date: "2026-05-25",
		day: "lundi",
		numbers: [
			86,
			4,
			24,
			32,
			60
		]
	},
	{
		date: "2026-05-26",
		day: "mardi",
		numbers: [
			12,
			32,
			1,
			45,
			11
		]
	},
	{
		date: "2026-05-28",
		day: "jeudi",
		numbers: [
			71,
			5,
			29,
			51,
			70
		]
	},
	{
		date: "2026-05-29",
		day: "vendredi",
		numbers: [
			33,
			79,
			35,
			58,
			68
		]
	},
	{
		date: "2026-05-30",
		day: "samedi",
		numbers: [
			81,
			64,
			15,
			74,
			88
		]
	},
	{
		date: "2026-06-01",
		day: "lundi",
		numbers: [
			87,
			55,
			41,
			24,
			21
		]
	},
	{
		date: "2026-06-02",
		day: "mardi",
		numbers: [
			41,
			53,
			28,
			20,
			48
		]
	},
	{
		date: "2026-06-03",
		day: "mercredi",
		numbers: [
			90,
			53,
			49,
			88,
			68
		]
	},
	{
		date: "2026-06-04",
		day: "jeudi",
		numbers: [
			4,
			86,
			27,
			64,
			56
		]
	},
	{
		date: "2026-06-05",
		day: "vendredi",
		numbers: [
			40,
			27,
			58,
			7,
			51
		]
	},
	{
		date: "2026-06-06",
		day: "samedi",
		numbers: [
			27,
			77,
			16,
			82,
			51
		]
	},
	{
		date: "2026-06-08",
		day: "lundi",
		numbers: [
			14,
			24,
			53,
			65,
			12
		]
	},
	{
		date: "2026-06-09",
		day: "mardi",
		numbers: [
			30,
			72,
			78,
			71,
			15
		]
	},
	{
		date: "2026-06-10",
		day: "mercredi",
		numbers: [
			8,
			35,
			33,
			87,
			74
		]
	},
	{
		date: "2026-06-11",
		day: "jeudi",
		numbers: [
			14,
			1,
			85,
			83,
			87
		]
	},
	{
		date: "2026-06-12",
		day: "vendredi",
		numbers: [
			5,
			24,
			85,
			52,
			74
		]
	},
	{
		date: "2026-06-13",
		day: "samedi",
		numbers: [
			37,
			22,
			61,
			74,
			69
		]
	},
	{
		date: "2026-06-15",
		day: "lundi",
		numbers: [
			89,
			27,
			51,
			70,
			83
		]
	},
	{
		date: "2026-06-16",
		day: "mardi",
		numbers: [
			79,
			69,
			41,
			58,
			80
		]
	},
	{
		date: "2026-06-17",
		day: "mercredi",
		numbers: [
			76,
			66,
			89,
			85,
			87
		]
	},
	{
		date: "2026-06-18",
		day: "jeudi",
		numbers: [
			12,
			71,
			82,
			86,
			67
		]
	},
	{
		date: "2026-06-19",
		day: "vendredi",
		numbers: [
			31,
			42,
			65,
			21,
			46
		]
	},
	{
		date: "2026-06-20",
		day: "samedi",
		numbers: [
			21,
			41,
			80,
			66,
			81
		]
	},
	{
		date: "2026-06-22",
		day: "lundi",
		numbers: [
			43,
			32,
			45,
			77,
			11
		]
	},
	{
		date: "2026-06-23",
		day: "mardi",
		numbers: [
			2,
			6,
			79,
			35,
			13
		]
	},
	{
		date: "2026-06-24",
		day: "mercredi",
		numbers: [
			2,
			77,
			21,
			76,
			67
		]
	},
	{
		date: "2026-06-25",
		day: "jeudi",
		numbers: [
			17,
			70,
			16,
			85,
			47
		]
	},
	{
		date: "2026-06-26",
		day: "vendredi",
		numbers: [
			3,
			4,
			6,
			43,
			2
		]
	},
	{
		date: "2026-06-27",
		day: "samedi",
		numbers: [
			39,
			29,
			8,
			23,
			22
		]
	},
	{
		date: "2026-06-29",
		day: "lundi",
		numbers: [
			25,
			20,
			46,
			9,
			76
		]
	},
	{
		date: "2026-06-30",
		day: "mardi",
		numbers: [
			58,
			44,
			4,
			73,
			87
		]
	},
	{
		date: "2026-07-01",
		day: "mercredi",
		numbers: [
			83,
			52,
			25,
			56,
			12
		]
	},
	{
		date: "2026-07-02",
		day: "jeudi",
		numbers: [
			68,
			41,
			44,
			19,
			9
		]
	},
	{
		date: "2026-07-04",
		day: "samedi",
		numbers: [
			28,
			82,
			6,
			64,
			5
		]
	},
	{
		date: "2026-07-06",
		day: "lundi",
		numbers: [
			6,
			81,
			44,
			67,
			73
		]
	},
	{
		date: "2026-07-07",
		day: "mardi",
		numbers: [
			85,
			21,
			15,
			32,
			58
		]
	},
	{
		date: "2026-07-08",
		day: "mercredi",
		numbers: [
			22,
			71,
			69,
			16,
			38
		]
	},
	{
		date: "2026-07-09",
		day: "jeudi",
		numbers: [
			55,
			90,
			63,
			43,
			78
		]
	},
	{
		date: "2026-07-10",
		day: "vendredi",
		numbers: [
			22,
			30,
			40,
			72,
			65
		]
	},
	{
		date: "2026-07-11",
		day: "samedi",
		numbers: [
			48,
			90,
			61,
			45,
			6
		]
	},
	{
		date: "2026-07-13",
		day: "lundi",
		numbers: [
			21,
			11,
			74,
			6,
			39
		]
	},
	{
		date: "2026-07-14",
		day: "mardi",
		numbers: [
			39,
			43,
			61,
			45,
			81
		]
	},
	{
		date: "2026-07-15",
		day: "mercredi",
		numbers: [
			53,
			32,
			62,
			90,
			36
		]
	},
	{
		date: "2026-07-16",
		day: "jeudi",
		numbers: [
			36,
			6,
			16,
			27,
			81
		]
	},
	{
		date: "2026-07-17",
		day: "vendredi",
		numbers: [
			89,
			20,
			74,
			13,
			18
		]
	},
	{
		date: "2026-07-18",
		day: "samedi",
		numbers: [
			59,
			77,
			76,
			47,
			23
		]
	},
	{
		date: "2026-07-20",
		day: "lundi",
		numbers: [
			57,
			6,
			86,
			42,
			7
		]
	},
	{
		date: "2026-07-21",
		day: "mardi",
		numbers: [
			80,
			23,
			31,
			65,
			82
		]
	},
	{
		date: "2026-07-22",
		day: "mercredi",
		numbers: [
			16,
			6,
			44,
			26,
			17
		]
	},
	{
		date: "2026-07-23",
		day: "jeudi",
		numbers: [
			21,
			69,
			28,
			89,
			41
		]
	},
	{
		date: "2026-07-24",
		day: "vendredi",
		numbers: [
			77,
			84,
			79,
			19,
			44
		]
	},
	{
		date: "2026-07-25",
		day: "samedi",
		numbers: [
			33,
			65,
			72,
			13,
			1
		]
	},
	{
		date: "2026-07-27",
		day: "lundi",
		numbers: [
			10,
			15,
			27,
			47,
			36
		]
	},
	{
		date: "2026-07-28",
		day: "mardi",
		numbers: [
			58,
			10,
			60,
			1,
			62
		]
	},
	{
		date: "2026-07-29",
		day: "mercredi",
		numbers: [
			84,
			51,
			70,
			20,
			35
		]
	},
	{
		date: "2026-07-30",
		day: "jeudi",
		numbers: [
			14,
			49,
			2,
			3,
			51
		]
	},
	{
		date: "2026-07-31",
		day: "vendredi",
		numbers: [
			68,
			88,
			31,
			86,
			66
		]
	},
	{
		date: "2026-08-01",
		day: "samedi",
		numbers: [
			63,
			12,
			34,
			41,
			82
		]
	},
	{
		date: "2026-08-03",
		day: "lundi",
		numbers: [
			29,
			37,
			66,
			21,
			72
		]
	},
	{
		date: "2026-08-04",
		day: "mardi",
		numbers: [
			80,
			62,
			23,
			29,
			16
		]
	},
	{
		date: "2026-08-05",
		day: "mercredi",
		numbers: [
			75,
			59,
			23,
			36,
			55
		]
	},
	{
		date: "2026-08-06",
		day: "jeudi",
		numbers: [
			85,
			1,
			36,
			65,
			34
		]
	},
	{
		date: "2026-08-07",
		day: "vendredi",
		numbers: [
			43,
			66,
			20,
			48,
			52
		]
	},
	{
		date: "2026-08-08",
		day: "samedi",
		numbers: [
			26,
			57,
			18,
			53,
			21
		]
	},
	{
		date: "2026-08-10",
		day: "lundi",
		numbers: [
			42,
			24,
			33,
			21,
			62
		]
	},
	{
		date: "2026-08-11",
		day: "mardi",
		numbers: [
			39,
			1,
			10,
			49,
			89
		]
	},
	{
		date: "2026-08-12",
		day: "mercredi",
		numbers: [
			12,
			27,
			41,
			36,
			2
		]
	},
	{
		date: "2026-08-13",
		day: "jeudi",
		numbers: [
			68,
			46,
			24,
			85,
			63
		]
	},
	{
		date: "2026-08-14",
		day: "vendredi",
		numbers: [
			39,
			7,
			45,
			87,
			1
		]
	},
	{
		date: "2026-08-15",
		day: "samedi",
		numbers: [
			29,
			84,
			70,
			49,
			17
		]
	},
	{
		date: "2026-08-17",
		day: "lundi",
		numbers: [
			36,
			50,
			57,
			42,
			61
		]
	},
	{
		date: "2026-08-18",
		day: "mardi",
		numbers: [
			77,
			88,
			23,
			13,
			67
		]
	},
	{
		date: "2026-08-19",
		day: "mercredi",
		numbers: [
			18,
			54,
			70,
			32,
			60
		]
	},
	{
		date: "2026-08-20",
		day: "jeudi",
		numbers: [
			47,
			80,
			88,
			81,
			78
		]
	},
	{
		date: "2026-08-21",
		day: "vendredi",
		numbers: [
			28,
			1,
			26,
			22,
			77
		]
	},
	{
		date: "2026-08-22",
		day: "samedi",
		numbers: [
			31,
			18,
			89,
			49,
			40
		]
	},
	{
		date: "2026-08-24",
		day: "lundi",
		numbers: [
			17,
			47,
			3,
			21,
			20
		]
	},
	{
		date: "2026-08-25",
		day: "mardi",
		numbers: [
			58,
			73,
			84,
			52,
			53
		]
	},
	{
		date: "2026-08-26",
		day: "mercredi",
		numbers: [
			48,
			71,
			47,
			9,
			50
		]
	},
	{
		date: "2026-08-27",
		day: "jeudi",
		numbers: [
			3,
			10,
			8,
			37,
			81
		]
	},
	{
		date: "2026-08-28",
		day: "vendredi",
		numbers: [
			85,
			42,
			45,
			23,
			15
		]
	},
	{
		date: "2026-08-29",
		day: "samedi",
		numbers: [
			52,
			53,
			12,
			1,
			17
		]
	}
];
var WEEKDAYS = [
	"lundi",
	"mardi",
	"mercredi",
	"jeudi",
	"vendredi",
	"samedi"
];
var JS_DAY_TO_FR = [
	"dimanche",
	"lundi",
	"mardi",
	"mercredi",
	"jeudi",
	"vendredi",
	"samedi"
];
function weekdayFromDate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return JS_DAY_TO_FR[new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
}
function isWeekday(d) {
	return WEEKDAYS.includes(d);
}
function nextDrawDate(fromIso) {
	const [y, m, d] = fromIso.split("-").map(Number);
	const dt = new Date(Date.UTC(y, m - 1, d));
	for (let i = 0; i < 8; i++) {
		dt.setUTCDate(dt.getUTCDate() + 1);
		const name = JS_DAY_TO_FR[dt.getUTCDay()];
		if (name !== "dimanche") return {
			date: dt.toISOString().slice(0, 10),
			day: name
		};
	}
	return {
		date: fromIso,
		day: "lundi"
	};
}
function pairKey(a, b) {
	return a < b ? `${a}-${b}` : `${b}-${a}`;
}
function parsePairQuery(raw) {
	const m = raw.trim().replace(/[–—]/g, "-").match(/^(\d{1,2})\s*[+\-xX/ ]\s*(\d{1,2})$/);
	if (!m) return null;
	const a = Number(m[1]);
	const b = Number(m[2]);
	if (a < 1 || a > 90 || b < 1 || b > 90 || a === b) return null;
	return a < b ? {
		a,
		b
	} : {
		a: b,
		b: a
	};
}
function unorderedPairs(numbers) {
	const n = [...numbers];
	const out = [];
	for (let i = 0; i < n.length; i++) for (let j = i + 1; j < n.length; j++) {
		const a = n[i];
		const b = n[j];
		out.push(a < b ? [a, b] : [b, a]);
	}
	return out;
}
function validateNumbers(nums) {
	if (nums.length !== 5) return false;
	if (new Set(nums).size !== 5) return false;
	return nums.every((n) => Number.isInteger(n) && n >= 1 && n <= 90);
}
function emptyDayCounts() {
	return {
		lundi: 0,
		mardi: 0,
		mercredi: 0,
		jeudi: 0,
		vendredi: 0,
		samedi: 0
	};
}
function mergeDraws(state) {
	const extraByDate = new Map(state.extras.map((d) => [d.date, d]));
	const extraDates = new Set(extraByDate.keys());
	const removed = new Set(state.removedDates);
	const combined = [];
	for (const s of SEED_DRAWS) {
		if (removed.has(s.date)) continue;
		const overlay = extraByDate.get(s.date);
		if (overlay) {
			combined.push(overlay);
			extraByDate.delete(s.date);
		} else combined.push(s);
	}
	for (const extra of extraByDate.values()) combined.push(extra);
	combined.sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
	return combined.map((d, index) => ({
		...d,
		index,
		id: d.date,
		source: extraDates.has(d.date) ? "manual" : "seed"
	}));
}
function formatDateFr(iso) {
	const [y, m, d] = iso.split("-");
	return `${d}/${m}/${y}`;
}
function mean(xs) {
	if (!xs.length) return 0;
	return xs.reduce((a, b) => a + b, 0) / xs.length;
}
function clamp(n, lo, hi) {
	return Math.min(hi, Math.max(lo, n));
}
function familyStatus(f) {
	if (f.count >= 3 && f.avgCycle > 0 && f.delay > f.avgCycle * 1.25) return "late";
	if (f.last12 >= 2 && f.recentRate > f.historicalRate * 1.2) return "active";
	return "stable";
}
function pairStatus(count, delay, avgCycle) {
	if (count === 0) return "never";
	if (avgCycle > 0 && delay > avgCycle * 1.2) return "waiting";
	return "seen";
}
function buildContext(draws) {
	const n = draws.length;
	const last = n ? draws[n - 1] : null;
	const next = last ? nextDrawDate(last.date) : null;
	const numbers = Array.from({ length: 91 }, (_, nVal) => ({
		n: nVal,
		count: 0,
		lastIndex: -1,
		delay: n,
		gaps: [],
		avgCycle: 0,
		dates: [],
		byDay: emptyDayCounts(),
		byPosition: [
			0,
			0,
			0,
			0,
			0
		],
		last30: 0,
		last10: 0,
		trend: 0,
		score: 0
	}));
	const pairs = /* @__PURE__ */ new Map();
	const ensurePair = (a, b) => {
		const k = pairKey(a, b);
		let p = pairs.get(k);
		if (!p) {
			p = {
				a,
				b,
				sum: a + b,
				gap: b - a,
				count: 0,
				lastIndex: -1,
				delay: n,
				avgCycle: 0,
				last30: 0,
				dates: [],
				dayCounts: emptyDayCounts(),
				status: "never",
				trend: 0
			};
			pairs.set(k, p);
		}
		return p;
	};
	const orderedN1N2 = /* @__PURE__ */ new Map();
	const positionFreq = Array.from({ length: 5 }, () => Array(91).fill(0));
	const dayTotals = emptyDayCounts();
	const dayNumbers = {
		lundi: Array(91).fill(0),
		mardi: Array(91).fill(0),
		mercredi: Array(91).fill(0),
		jeudi: Array(91).fill(0),
		vendredi: Array(91).fill(0),
		samedi: Array(91).fill(0)
	};
	const sumBuckets = /* @__PURE__ */ new Map();
	const gapBuckets = /* @__PURE__ */ new Map();
	draws.forEach((draw, idx) => {
		dayTotals[draw.day] += 1;
		const recent30 = idx >= n - 30;
		const recent10 = idx >= n - 10;
		const recent12 = idx >= n - 12;
		draw.numbers.forEach((num, pos) => {
			const st = numbers[num];
			if (st.lastIndex >= 0) st.gaps.push(idx - st.lastIndex);
			st.count += 1;
			st.lastIndex = idx;
			st.dates.push({
				date: draw.date,
				day: draw.day,
				index: idx,
				numbers: draw.numbers,
				positions: [pos + 1]
			});
			st.byDay[draw.day] += 1;
			st.byPosition[pos] += 1;
			if (recent30) st.last30 += 1;
			if (recent10) st.last10 += 1;
			positionFreq[pos][num] += 1;
			dayNumbers[draw.day][num] += 1;
		});
		const ordKey = `${draw.numbers[0]}>${draw.numbers[1]}`;
		const ord = orderedN1N2.get(ordKey) ?? {
			count: 0,
			lastIndex: -1,
			dates: []
		};
		ord.count += 1;
		ord.lastIndex = idx;
		ord.dates.push(draw.date);
		orderedN1N2.set(ordKey, ord);
		for (const [a, b] of unorderedPairs(draw.numbers)) {
			const p = ensurePair(a, b);
			const app = {
				date: draw.date,
				day: draw.day,
				index: idx,
				numbers: draw.numbers,
				positions: [draw.numbers.indexOf(a) + 1, draw.numbers.indexOf(b) + 1]
			};
			p.count += 1;
			p.lastIndex = idx;
			p.dates.push(app);
			p.dayCounts[draw.day] += 1;
			if (recent30) p.last30 += 1;
			const sList = sumBuckets.get(a + b) ?? [];
			sList.push(idx);
			sumBuckets.set(a + b, sList);
			const gList = gapBuckets.get(b - a) ?? [];
			gList.push(idx);
			gapBuckets.set(b - a, gList);
			if (recent12) {}
		}
	});
	for (let v = 1; v <= 90; v++) {
		const st = numbers[v];
		st.delay = st.lastIndex < 0 ? n : n - 1 - st.lastIndex;
		st.avgCycle = st.gaps.length ? mean(st.gaps) : n > 0 ? n : 0;
		const earlier = Math.max(0, st.count - st.last30);
		const earlierWindow = Math.max(1, n - 30);
		st.trend = st.last30 / 30 - earlier / earlierWindow;
	}
	for (const p of pairs.values()) {
		const gaps = [];
		for (let i = 1; i < p.dates.length; i++) gaps.push(p.dates[i].index - p.dates[i - 1].index);
		p.avgCycle = gaps.length ? mean(gaps) : n;
		p.delay = p.lastIndex < 0 ? n : n - 1 - p.lastIndex;
		p.status = pairStatus(p.count, p.delay, p.avgCycle);
		const earlier = Math.max(0, p.count - p.last30);
		p.trend = p.last30 / 30 - earlier / Math.max(1, n - 30);
	}
	function toFamily(value, hits) {
		const uniqueDraws = [...new Set(hits)].sort((a, b) => a - b);
		const gaps = [];
		for (let i = 1; i < uniqueDraws.length; i++) gaps.push(uniqueDraws[i] - uniqueDraws[i - 1]);
		const lastIndex = uniqueDraws.length ? uniqueDraws[uniqueDraws.length - 1] : -1;
		const last12 = uniqueDraws.filter((i) => i >= n - 12).length;
		const count = uniqueDraws.length;
		const base = {
			value,
			count,
			lastIndex,
			delay: lastIndex < 0 ? n : n - 1 - lastIndex,
			avgCycle: gaps.length ? mean(gaps) : n,
			last12,
			historicalRate: n ? count / n : 0,
			recentRate: n ? last12 / Math.min(12, n) : 0
		};
		return {
			...base,
			status: familyStatus(base)
		};
	}
	const sumHist = /* @__PURE__ */ new Map();
	const gapHist = /* @__PURE__ */ new Map();
	for (let s = 3; s <= 179; s++) sumHist.set(s, toFamily(s, sumBuckets.get(s) ?? []));
	for (let g = 1; g <= 89; g++) gapHist.set(g, toFamily(g, gapBuckets.get(g) ?? []));
	return {
		draws,
		n,
		last,
		next,
		numbers,
		pairs,
		orderedN1N2,
		sumHist,
		gapHist,
		positionFreq,
		dayTotals,
		dayNumbers
	};
}
function getPair(ctx, a, b) {
	const [x, y] = a < b ? [a, b] : [b, a];
	return ctx.pairs.get(pairKey(x, y)) ?? {
		a: x,
		b: y,
		sum: x + y,
		gap: y - x,
		count: 0,
		lastIndex: -1,
		delay: ctx.n,
		avgCycle: ctx.n,
		last30: 0,
		dates: [],
		dayCounts: emptyDayCounts(),
		status: "never",
		trend: 0
	};
}
function coherence(score, max = 100) {
	return Math.round(clamp(score / max * 100, 4, 92));
}
function scoreNumbers(ctx, day) {
	const { n, numbers } = ctx;
	const out = [];
	const meanCount = n ? n * 5 / 90 : 0;
	for (let v = 1; v <= 90; v++) {
		const st = numbers[v];
		const freq = meanCount ? (st.count - meanCount) / Math.max(1, Math.sqrt(meanCount)) : 0;
		const due = st.avgCycle > 0 ? clamp((st.delay - st.avgCycle) / Math.max(1, st.avgCycle), -1.5, 2.5) : 0;
		const rec = st.last10 * 2.2 + st.last30 * .6;
		const dayAff = day && ctx.dayTotals[day] ? st.byDay[day] / ctx.dayTotals[day] * 40 : 0;
		const trend = st.trend * 80;
		const posLead = Math.max(...st.byPosition) * .35;
		const parts = {
			freq: freq * 6,
			due: due * 14,
			rec,
			day: dayAff,
			trend,
			pos: posLead
		};
		const score = Object.values(parts).reduce((a, b) => a + b, 0);
		numbers[v].score = score;
		out.push({
			n: v,
			score,
			parts
		});
	}
	out.sort((a, b) => b.score - a.score);
	return out;
}
function runGold(ctx) {
	const day = ctx.next?.day ?? ctx.last?.day ?? null;
	const ranked = scoreNumbers(ctx, day);
	const top = ranked[0];
	const st = ctx.numbers[top.n];
	const factors = [
		{
			key: "freq",
			labelFr: `Fréquence ${st.count} / ${ctx.n} tirages`,
			labelEn: `Frequency ${st.count} / ${ctx.n} draws`,
			weight: top.parts.freq
		},
		{
			key: "due",
			labelFr: `Retard ${st.delay} (cycle ${st.avgCycle.toFixed(1)})`,
			labelEn: `Delay ${st.delay} (cycle ${st.avgCycle.toFixed(1)})`,
			weight: top.parts.due
		},
		{
			key: "day",
			labelFr: day ? `Affinité ${day}` : "Sans jour cible",
			labelEn: day ? `${day} affinity` : "No target weekday",
			weight: top.parts.day
		},
		{
			key: "rec",
			labelFr: `Fenêtre récente ${st.last10} / 10 · ${st.last30} / 30`,
			labelEn: `Recent window ${st.last10} / 10 · ${st.last30} / 30`,
			weight: top.parts.rec
		},
		{
			key: "trend",
			labelFr: st.trend >= 0 ? "Dynamique ascendante" : "Dynamique descendante",
			labelEn: st.trend >= 0 ? "Rising dynamic" : "Falling dynamic",
			weight: top.parts.trend
		}
	].sort((a, b) => Math.abs(b.weight) - Math.abs(a.weight));
	return {
		number: top.n,
		score: Math.round(top.score * 10) / 10,
		coherence: coherence(top.score, 90),
		factors,
		alternatives: ranked.slice(1, 4).map((r) => ({
			number: r.n,
			score: Math.round(r.score * 10) / 10,
			coherence: coherence(r.score, 90)
		}))
	};
}
function runSimilarities(ctx) {
	if (!ctx.last) return {
		matches: [],
		convergentNumbers: [],
		convergentPairs: []
	};
	const lastSet = new Set(ctx.last.numbers);
	const lastSum = ctx.last.numbers.reduce((a, b) => a + b, 0);
	const matches = [];
	for (let i = 0; i < ctx.n - 1; i++) {
		const d = ctx.draws[i];
		const shared = d.numbers.filter((x) => lastSet.has(x));
		const sum = d.numbers.reduce((a, b) => a + b, 0);
		const score = shared.length * 3 + (d.day === ctx.last.day ? 1.2 : 0) + (Math.abs(sum - lastSum) <= 15 ? .8 : 0) + (d.numbers[0] === ctx.last.numbers[0] ? .7 : 0);
		if (shared.length >= 2 || score >= 5) matches.push({
			draw: d,
			shared,
			score
		});
	}
	matches.sort((a, b) => b.score - a.score);
	const top = matches.slice(0, 12);
	const numHits = /* @__PURE__ */ new Map();
	const pairHits = /* @__PURE__ */ new Map();
	for (const m of top) {
		for (const v of m.draw.numbers) {
			if (lastSet.has(v)) continue;
			numHits.set(v, (numHits.get(v) ?? 0) + 1);
		}
		for (const [a, b] of unorderedPairs(m.draw.numbers)) {
			const k = pairKey(a, b);
			const cur = pairHits.get(k) ?? {
				a,
				b,
				hits: 0
			};
			cur.hits += 1;
			pairHits.set(k, cur);
		}
	}
	return {
		matches: top,
		convergentNumbers: [...numHits.entries()].map(([n, hits]) => ({
			n,
			hits
		})).sort((a, b) => b.hits - a.hits).slice(0, 12),
		convergentPairs: [...pairHits.values()].sort((a, b) => b.hits - a.hits).slice(0, 12)
	};
}
function runDates(ctx) {
	const target = ctx.next;
	if (!target) return [];
	const day = target.day;
	const dom = Number(target.date.slice(8, 10));
	const month = Number(target.date.slice(5, 7));
	const scores = [];
	for (let v = 1; v <= 90; v++) {
		const st = ctx.numbers[v];
		const sameDom = st.dates.filter((d) => Number(d.date.slice(8, 10)) === dom).length;
		const sameMonth = st.dates.filter((d) => Number(d.date.slice(5, 7)) === month).length;
		const sameDay = st.byDay[day];
		const cycleAlign = st.avgCycle > 0 ? clamp(1 - Math.abs(st.delay - st.avgCycle) / st.avgCycle, 0, 1) : 0;
		const parts = [
			{
				key: "dom",
				value: sameDom * 8,
				labelFr: `${sameDom} sortie(s) le ${dom} du mois`,
				labelEn: `${sameDom} hit(s) on day ${dom}`
			},
			{
				key: "month",
				value: sameMonth * 2.2,
				labelFr: `${sameMonth} en mois ${month}`,
				labelEn: `${sameMonth} in month ${month}`
			},
			{
				key: "day",
				value: sameDay * 4,
				labelFr: `${sameDay} un ${day}`,
				labelEn: `${sameDay} on ${day}`
			},
			{
				key: "cycle",
				value: cycleAlign * 18,
				labelFr: `Alignement de cycle (retard ${st.delay})`,
				labelEn: `Cycle alignment (delay ${st.delay})`
			},
			{
				key: "due",
				value: st.delay > st.avgCycle ? 10 : 2,
				labelFr: st.delay > st.avgCycle ? "Retard au-dessus du cycle" : "Dans son cycle",
				labelEn: st.delay > st.avgCycle ? "Delay above cycle" : "Inside cycle"
			}
		];
		const score = parts.reduce((a, p) => a + p.value, 0);
		scores.push({
			n: v,
			score,
			coherence: coherence(score, 70),
			parts
		});
	}
	scores.sort((a, b) => b.score - a.score);
	return scores;
}
function runTurbo2(ctx) {
	const day = ctx.next?.day ?? ctx.last?.day ?? "lundi";
	const n1Scores = /* @__PURE__ */ new Map();
	const n2Scores = /* @__PURE__ */ new Map();
	const n1Reasons = {};
	const addR = (n, fr, en) => {
		const b = n1Reasons[n] ?? {
			fr: [],
			en: []
		};
		b.fr.push(fr);
		b.en.push(en);
		n1Reasons[n] = b;
	};
	for (let v = 1; v <= 90; v++) {
		const p1 = ctx.positionFreq[0][v];
		const p2 = ctx.positionFreq[1][v];
		n1Scores.set(v, p1 * 3 + (ctx.dayNumbers[day][v] ?? 0) * .8);
		n2Scores.set(v, p2 * 3);
		if (p1 > 0) addR(v, `N1 historique ×${p1}`, `Historical N1 ×${p1}`);
	}
	if (ctx.last) {
		const prevN1 = ctx.last.numbers[0];
		const follow = /* @__PURE__ */ new Map();
		for (let i = 0; i < ctx.n - 1; i++) if (ctx.draws[i].numbers[0] === prevN1) {
			const nxt = ctx.draws[i + 1].numbers[0];
			follow.set(nxt, (follow.get(nxt) ?? 0) + 1);
		}
		for (const [v, c] of follow) {
			n1Scores.set(v, (n1Scores.get(v) ?? 0) + c * 6);
			addR(v, `Transition après N1=${prevN1} (×${c})`, `Transition after N1=${prevN1} (×${c})`);
		}
		if (ctx.numbers[prevN1]) n1Scores.set(prevN1, (n1Scores.get(prevN1) ?? 0) - 4);
	}
	const n1Rank = [...n1Scores.entries()].sort((a, b) => b[1] - a[1]);
	const n1 = n1Rank[0]?.[0] ?? 1;
	const cond = /* @__PURE__ */ new Map();
	for (const d of ctx.draws) if (d.numbers[0] === n1) cond.set(d.numbers[1], (cond.get(d.numbers[1]) ?? 0) + 5);
	for (let v = 1; v <= 90; v++) {
		if (v === n1) continue;
		const pair = getPair(ctx, n1, v);
		const dayAff = pair.dayCounts[day] * 2;
		n2Scores.set(v, (n2Scores.get(v) ?? 0) + (cond.get(v) ?? 0) + pair.last30 * 1.5 + dayAff);
	}
	const n2 = [...n2Scores.entries()].filter(([v]) => v !== n1).sort((a, b) => b[1] - a[1])[0]?.[0] ?? (n1 === 1 ? 2 : 1);
	const alternatives = [];
	for (let i = 0; i < 3; i++) {
		const a = n1Rank[i]?.[0];
		if (!a) continue;
		const bCand = [...n2Scores.entries()].filter(([v]) => v !== a).sort((x, y) => y[1] - x[1])[0];
		if (!bCand) continue;
		if (a === n1 && bCand[0] === n2) continue;
		alternatives.push({
			n1: a,
			n2: bCand[0],
			score: n1Rank[i][1] + bCand[1]
		});
	}
	const n2ReasonsFr = [`N2 positionnel ×${ctx.positionFreq[1][n2]}`, `Paire ordonnée ${n1}→${n2} observée ${ctx.orderedN1N2.get(`${n1}>${n2}`)?.count ?? 0} fois`];
	const n2ReasonsEn = [`Positional N2 ×${ctx.positionFreq[1][n2]}`, `Ordered pair ${n1}→${n2} seen ${ctx.orderedN1N2.get(`${n1}>${n2}`)?.count ?? 0} times`];
	const topN1 = [...n1Scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([v]) => v);
	const topN2 = [...n2Scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([v]) => v);
	return {
		n1,
		n2,
		alternatives: alternatives.slice(0, 3),
		n1ReasonsFr: n1Reasons[n1]?.fr.slice(0, 4) ?? [`N1 positionnel dominant`],
		n1ReasonsEn: n1Reasons[n1]?.en.slice(0, 4) ?? [`Dominant positional N1`],
		n2ReasonsFr,
		n2ReasonsEn,
		posFreq: {
			n1: topN1,
			n2: topN2
		}
	};
}
function pickFamilyPair(ctx, kind, familyValue, day, exclude) {
	const cands = [];
	for (const p of ctx.pairs.values()) {
		if ((kind === "sum" ? p.sum : p.gap) !== familyValue) continue;
		if (exclude.has(pairKey(p.a, p.b))) continue;
		cands.push(p);
	}
	if (!cands.length) for (let a = 1; a <= 90; a++) for (let b = a + 1; b <= 90; b++) {
		if (kind === "sum" ? a + b !== familyValue : b - a !== familyValue) continue;
		const p = getPair(ctx, a, b);
		cands.push(p);
	}
	cands.sort((a, b) => {
		const sa = a.dayCounts[day] * 4 + a.last30 * 3 + (a.status === "waiting" ? 6 : 0) + (a.count > 0 ? 2 : 0) - (a.delay < 3 && a.count > 0 ? 5 : 0);
		return b.dayCounts[day] * 4 + b.last30 * 3 + (b.status === "waiting" ? 6 : 0) + (b.count > 0 ? 2 : 0) - (b.delay < 3 && b.count > 0 ? 5 : 0) - sa;
	});
	return cands[0] ?? getPair(ctx, 1, 2);
}
function runTwoSure(ctx) {
	const day = ctx.next?.day ?? ctx.last?.day ?? "lundi";
	const lastPairs = new Set(ctx.last ? unorderedPairs(ctx.last.numbers).map(([a, b]) => pairKey(a, b)) : []);
	const sums = [...ctx.sumHist.values()].filter((f) => f.count >= 2);
	sums.sort((a, b) => {
		const da = a.avgCycle ? a.delay / a.avgCycle : 0;
		return (b.avgCycle ? b.delay / b.avgCycle : 0) + (b.last12 - a.last12) * .15 - (da + 0);
	});
	const dueSum = [...sums].sort((a, b) => {
		const ra = a.avgCycle ? a.delay / a.avgCycle : 0;
		return (b.avgCycle ? b.delay / b.avgCycle : 0) - ra;
	})[0] ?? ctx.sumHist.get(91);
	const dueGap = [...[...ctx.gapHist.values()].filter((f) => f.count >= 2)].sort((a, b) => {
		const ra = a.avgCycle ? a.delay / a.avgCycle : 0;
		return (b.avgCycle ? b.delay / b.avgCycle : 0) - ra;
	})[0] ?? ctx.gapHist.get(12);
	const sumPair = pickFamilyPair(ctx, "sum", dueSum.value, day, lastPairs);
	const gapPair = pickFamilyPair(ctx, "gap", dueGap.value, day, /* @__PURE__ */ new Set([...lastPairs, pairKey(sumPair.a, sumPair.b)]));
	return {
		sumPair,
		gapPair,
		sumExplainFr: `Famille somme ${dueSum.value} — retard ${dueSum.delay} vs cycle ${dueSum.avgCycle.toFixed(1)}. Paire ${sumPair.a}+${sumPair.b} (${sumPair.count} fois, retard ${sumPair.delay}).`,
		sumExplainEn: `Sum family ${dueSum.value} — delay ${dueSum.delay} vs cycle ${dueSum.avgCycle.toFixed(1)}. Pair ${sumPair.a}+${sumPair.b} (${sumPair.count} hits, delay ${sumPair.delay}).`,
		gapExplainFr: `Famille écart ${dueGap.value} — retard ${dueGap.delay} vs cycle ${dueGap.avgCycle.toFixed(1)}. Paire ${gapPair.a}–${gapPair.b} (${gapPair.count} fois, retard ${gapPair.delay}).`,
		gapExplainEn: `Gap family ${dueGap.value} — delay ${dueGap.delay} vs cycle ${dueGap.avgCycle.toFixed(1)}. Pair ${gapPair.a}–${gapPair.b} (${gapPair.count} hits, delay ${gapPair.delay}).`
	};
}
function runRadar(ctx) {
	const gold = runGold(ctx);
	const dates = runDates(ctx);
	const sim = runSimilarities(ctx);
	const turbo = runTurbo2(ctx);
	const two = runTwoSure(ctx);
	const votes = /* @__PURE__ */ new Map();
	const add = (n, src, w = 1) => {
		const cur = votes.get(n) ?? {
			n,
			votes: 0,
			sources: []
		};
		cur.votes += w;
		if (!cur.sources.includes(src)) cur.sources.push(src);
		votes.set(n, cur);
	};
	add(gold.number, "gold", 3);
	gold.alternatives.forEach((a, i) => add(a.number, "gold", 2 - i * .4));
	dates.slice(0, 8).forEach((d, i) => add(d.n, "dates", 2.2 - i * .15));
	sim.convergentNumbers.slice(0, 8).forEach((c) => add(c.n, "similar", 1.4 + c.hits * .3));
	add(turbo.n1, "turbo2", 2.4);
	add(turbo.n2, "turbo2", 2.1);
	add(two.sumPair.a, "twosure", 1.5);
	add(two.sumPair.b, "twosure", 1.5);
	add(two.gapPair.a, "twosure", 1.5);
	add(two.gapPair.b, "twosure", 1.5);
	const ranked = [...votes.values()].sort((a, b) => b.votes - a.votes);
	let pair = {
		a: ranked[0]?.n ?? 1,
		b: ranked[1]?.n ?? 2
	};
	if (pair.a > pair.b) pair = {
		a: pair.b,
		b: pair.a
	};
	let best = -1;
	for (let i = 0; i < Math.min(8, ranked.length); i++) for (let j = i + 1; j < Math.min(8, ranked.length); j++) {
		const a = Math.min(ranked[i].n, ranked[j].n);
		const b = Math.max(ranked[i].n, ranked[j].n);
		const p = getPair(ctx, a, b);
		const s = ranked[i].votes + ranked[j].votes + p.last30 * .8 + (p.count > 0 ? 1 : 0);
		if (s > best) {
			best = s;
			pair = {
				a,
				b
			};
		}
	}
	const intensity = clamp(Math.round((ranked[0]?.votes ?? 0) * 8 + (getPair(ctx, pair.a, pair.b).count > 0 ? 8 : 0)), 8, 98);
	return {
		pair,
		intensity,
		numbers: ranked.slice(0, 10),
		explainFr: `Convergence de ${ranked[0]?.sources.length ?? 0} sources sur ${ranked[0]?.n ?? "—"}. Paire radar ${pair.a}·${pair.b}.`,
		explainEn: `Convergence of ${ranked[0]?.sources.length ?? 0} sources on ${ranked[0]?.n ?? "—"}. Radar pair ${pair.a}·${pair.b}.`
	};
}
function matrixRows(ctx) {
	const mk = (kind) => {
		const fams = [...(kind === "sum" ? ctx.sumHist : ctx.gapHist).values()].filter((f) => f.count > 0);
		const recent = [...fams].sort((a, b) => b.recentRate - a.recentRate || b.last12 - a.last12)[0];
		const historical = [...fams].sort((a, b) => b.count - a.count)[0];
		const watch = [...fams].filter((f) => f.count >= 3).sort((a, b) => {
			const ra = a.avgCycle ? a.delay / a.avgCycle : 0;
			return (b.avgCycle ? b.delay / b.avgCycle : 0) - ra;
		})[0];
		const sampleFor = (value) => {
			let best = null;
			for (const p of ctx.pairs.values()) {
				if ((kind === "sum" ? p.sum : p.gap) !== value) continue;
				if (!best || p.count > best.count) best = p;
			}
			return best ? {
				a: best.a,
				b: best.b
			} : null;
		};
		const row = (role, f, fr, en) => ({
			role,
			kind,
			value: f?.value ?? 0,
			sample: f ? sampleFor(f.value) : null,
			status: f?.status ?? "stable",
			explainFr: fr,
			explainEn: en
		});
		return [
			row("recent", recent, recent ? `Rythme récent ${recent.last12}/12 vs base ${(recent.historicalRate * 12).toFixed(1)}` : "—", recent ? `Recent pace ${recent.last12}/12 vs base ${(recent.historicalRate * 12).toFixed(1)}` : "—"),
			row("historical", historical, historical ? `${historical.count} apparitions · cycle ${historical.avgCycle.toFixed(1)}` : "—", historical ? `${historical.count} hits · cycle ${historical.avgCycle.toFixed(1)}` : "—"),
			row("watch", watch, watch ? `Retard ${watch.delay} (cycle ${watch.avgCycle.toFixed(1)}) — ${watch.status === "late" ? "en retard" : watch.status === "active" ? "actif" : "stable"}` : "—", watch ? `Delay ${watch.delay} (cycle ${watch.avgCycle.toFixed(1)}) — ${watch.status}` : "—")
		];
	};
	return {
		sums: mk("sum"),
		gaps: mk("gap")
	};
}
function runPrediction(ctx) {
	const gold = runGold(ctx);
	const dates = runDates(ctx);
	const radar = runRadar(ctx);
	const turbo = runTurbo2(ctx);
	const two = runTwoSure(ctx);
	const ranked = scoreNumbers(ctx, ctx.next?.day ?? null);
	const picked = [];
	const push = (n) => {
		if (n >= 1 && n <= 90 && !picked.includes(n)) picked.push(n);
	};
	push(gold.number);
	push(turbo.n1);
	push(turbo.n2);
	push(radar.pair.a);
	push(radar.pair.b);
	push(two.sumPair.a);
	push(two.sumPair.b);
	dates.slice(0, 6).forEach((d) => push(d.n));
	ranked.forEach((r) => push(r.n));
	const combo = picked.slice(0, 5);
	const whyFor = (n) => {
		const st = ctx.numbers[n];
		return {
			whyFr: `Score ${st.score.toFixed(1)} · ${st.count} sorties · retard ${st.delay}`,
			whyEn: `Score ${st.score.toFixed(1)} · ${st.count} hits · delay ${st.delay}`
		};
	};
	return {
		top3: picked.slice(0, 3).map((n) => ({
			n,
			coherence: coherence(ctx.numbers[n].score, 90),
			...whyFor(n)
		})),
		gold,
		combo,
		pairs: [
			{
				a: radar.pair.a,
				b: radar.pair.b,
				whyFr: "Paire radar (convergence)",
				whyEn: "Radar pair (convergence)"
			},
			{
				a: two.sumPair.a,
				b: two.sumPair.b,
				whyFr: `Somme ${two.sumPair.sum}`,
				whyEn: `Sum ${two.sumPair.sum}`
			},
			{
				a: two.gapPair.a,
				b: two.gapPair.b,
				whyFr: `Écart ${two.gapPair.gap}`,
				whyEn: `Gap ${two.gapPair.gap}`
			},
			{
				a: turbo.n1,
				b: turbo.n2,
				whyFr: "Turbo 2 N1→N2",
				whyEn: "Turbo 2 N1→N2"
			}
		]
	};
}
function hitsIn(actual, guessed) {
	const set = new Set(actual);
	return guessed.filter((n) => set.has(n)).length;
}
function reliability(draws) {
	const start = Math.max(90, draws.length - 40);
	const acc = {
		gold: {
			tests: 0,
			hits: 0
		},
		dates: {
			tests: 0,
			hits: 0
		},
		similar: {
			tests: 0,
			hits: 0
		},
		radar: {
			tests: 0,
			hits: 0
		},
		turbo2: {
			tests: 0,
			hits: 0
		},
		twosure: {
			tests: 0,
			hits: 0
		}
	};
	const step = 5;
	for (let i = start; i < draws.length; i += step) {
		const past = draws.slice(0, i).map((d, idx) => ({
			...d,
			index: idx
		}));
		const actual = draws[i].numbers;
		const ctx = buildContext(past);
		const g = runGold(ctx);
		acc.gold.tests += 1;
		acc.gold.hits += actual.includes(g.number) ? 1 : 0;
		const d = runDates(ctx).slice(0, 3).map((x) => x.n);
		acc.dates.tests += 1;
		acc.dates.hits += hitsIn(actual, d) > 0 ? 1 : 0;
		const s = runSimilarities(ctx).convergentNumbers.slice(0, 5).map((x) => x.n);
		acc.similar.tests += 1;
		acc.similar.hits += hitsIn(actual, s) > 0 ? 1 : 0;
		const r = runRadar(ctx);
		acc.radar.tests += 1;
		acc.radar.hits += hitsIn(actual, r.numbers.slice(0, 5).map((x) => x.n)) > 0 ? 1 : 0;
		const t = runTurbo2(ctx);
		acc.turbo2.tests += 1;
		acc.turbo2.hits += actual[0] === t.n1 || actual[1] === t.n2 ? 1 : 0;
		const two = runTwoSure(ctx);
		acc.twosure.tests += 1;
		acc.twosure.hits += hitsIn(actual, [
			two.sumPair.a,
			two.sumPair.b,
			two.gapPair.a,
			two.gapPair.b
		]) >= 1 ? 1 : 0;
	}
	return Object.entries(acc).map(([source, v]) => ({
		source,
		tests: v.tests,
		hits: v.hits,
		rate: v.tests ? v.hits / v.tests : 0
	}));
}
function newsPlus(ctx) {
	const firsts = [];
	if (ctx.last) for (const [a, b] of unorderedPairs(ctx.last.numbers)) {
		const p = getPair(ctx, a, b);
		if (p.count === 1 && p.lastIndex === ctx.n - 1) {
			firsts.push({
				kind: "sum",
				pair: {
					a,
					b
				},
				value: a + b,
				firstDate: ctx.last.date
			});
			firsts.push({
				kind: "gap",
				pair: {
					a,
					b
				},
				value: b - a,
				firstDate: ctx.last.date
			});
		}
	}
	const day = ctx.next?.day ?? ctx.last?.day ?? "lundi";
	const dueSum = [...ctx.sumHist.values()].sort((a, b) => b.delay - a.delay)[0]?.value ?? 90;
	const dueGap = [...ctx.gapHist.values()].sort((a, b) => b.delay - a.delay)[0]?.value ?? 11;
	let suggestSum = getPair(ctx, 1, 2);
	let suggestGap = getPair(ctx, 1, 3);
	let bestS = -1;
	let bestG = -1;
	const ranked = scoreNumbers(ctx, day);
	const rankOf = new Map(ranked.map((r, i) => [r.n, i]));
	for (let a = 1; a <= 90; a++) for (let b = a + 1; b <= 90; b++) {
		const p = getPair(ctx, a, b);
		if (p.count > 0) continue;
		const closeness = 200 - (rankOf.get(a) ?? 90) - (rankOf.get(b) ?? 90);
		if (a + b === dueSum || Math.abs(a + b - dueSum) <= 4) {
			const s = closeness + (a + b === dueSum ? 20 : 0);
			if (s > bestS) {
				bestS = s;
				suggestSum = p;
			}
		}
		if (b - a === dueGap || Math.abs(b - a - dueGap) <= 2) {
			const s = closeness + (b - a === dueGap ? 20 : 0);
			if (s > bestG) {
				bestG = s;
				suggestGap = p;
			}
		}
	}
	return {
		firsts,
		suggestSum,
		suggestGap
	};
}
function neverDrawnByDay(ctx) {
	const days = [
		"lundi",
		"mardi",
		"mercredi",
		"jeudi",
		"vendredi",
		"samedi"
	];
	const out = {};
	for (const d of days) {
		const missing = [];
		for (let v = 1; v <= 90; v++) if ((ctx.dayNumbers[d][v] ?? 0) === 0) missing.push(v);
		out[d] = missing;
	}
	return out;
}
function drawsKey(draws) {
	const last = draws[draws.length - 1];
	const manuals = draws.filter((d) => d.source === "manual").length;
	return `${draws.length}|${last?.date ?? ""}|${last?.numbers.join(",") ?? ""}|${manuals}`;
}
var cache = /* @__PURE__ */ new Map();
var relCache = null;
function analyze(draws, withReliability = true) {
	const key = drawsKey(draws) + (withReliability ? "|r" : "");
	const hit = cache.get(key);
	if (hit) return hit;
	const ctx = buildContext(draws);
	const gold = runGold(ctx);
	const similar = runSimilarities(ctx);
	const dates = runDates(ctx);
	const turbo2 = runTurbo2(ctx);
	const twoSure = runTwoSure(ctx);
	const radar = runRadar(ctx);
	const prediction = runPrediction(ctx);
	const matrix = matrixRows(ctx);
	const news = newsPlus(ctx);
	const neverByDay = neverDrawnByDay(ctx);
	const hot = [...ctx.numbers.slice(1)].sort((a, b) => b.count - a.count).slice(0, 10).map((s) => s.n);
	const cold = [...ctx.numbers.slice(1)].sort((a, b) => b.delay - a.delay || a.count - b.count).slice(0, 10).map((s) => s.n);
	const longestDelay = [...ctx.numbers.slice(1)].sort((a, b) => b.delay - a.delay).slice(0, 12).map((s) => ({
		n: s.n,
		delay: s.delay
	}));
	let rel = [];
	if (withReliability) {
		if (relCache?.key === drawsKey(draws)) rel = relCache.value;
		else {
			rel = reliability(draws);
			relCache = {
				key: drawsKey(draws),
				value: rel
			};
		}
	}
	const result = {
		ctx,
		gold,
		similar,
		dates,
		radar,
		turbo2,
		twoSure,
		prediction,
		matrix,
		news,
		neverByDay,
		hot,
		cold,
		longestDelay,
		reliability: rel
	};
	cache.clear();
	cache.set(key, result);
	return result;
}
function invalidateAnalysis() {
	cache.clear();
	relCache = null;
}
function listPairs(ctx, kind, filter, family) {
	const out = [];
	for (let a = 1; a <= 90; a++) for (let b = a + 1; b <= 90; b++) {
		if (family != null) {
			if (kind === "sum" && a + b !== family) continue;
			if (kind === "gap" && b - a !== family) continue;
		}
		const p = getPair(ctx, a, b);
		if (filter === "seen" && p.status === "never") continue;
		if (filter === "waiting" && p.status !== "waiting") continue;
		if (filter === "never" && p.status !== "never") continue;
		out.push(p);
	}
	out.sort((a, b) => b.count - a.count || a.delay - b.delay || a.a - b.a || a.b - b.b);
	return out;
}
function scoreArchive(snap, actual) {
	const set = new Set(actual);
	const count = (xs) => xs.filter((n) => set.has(n)).length;
	return {
		...snap,
		pending: false,
		actual,
		scoredAt: (/* @__PURE__ */ new Date()).toISOString(),
		hits: {
			gold: count(snap.sources.gold),
			dates: count(snap.sources.dates),
			similar: count(snap.sources.similar),
			radar: count(snap.sources.radar),
			turbo2: count(snap.sources.turbo2),
			combo: count(snap.sources.combo),
			top3: count(snap.sources.top3),
			sumPair: count(snap.sources.sumPair),
			gapPair: count(snap.sources.gapPair)
		}
	};
}
function makeSnapshot(analysis) {
	const { ctx, prediction, gold, dates, similar, radar, turbo2, twoSure } = analysis;
	const next = ctx.next ?? {
		date: ctx.last?.date ?? "",
		day: ctx.last?.day ?? "lundi"
	};
	return {
		id: `snap-${Date.now()}`,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		forDate: next.date,
		forDay: next.day,
		pending: true,
		sources: {
			gold: [gold.number, ...gold.alternatives.map((a) => a.number)].slice(0, 4),
			dates: dates.slice(0, 5).map((d) => d.n),
			similar: similar.convergentNumbers.slice(0, 6).map((c) => c.n),
			radar: radar.numbers.slice(0, 6).map((n) => n.n),
			turbo2: [turbo2.n1, turbo2.n2],
			combo: [...prediction.combo],
			top3: prediction.top3.map((t) => t.n),
			sumPair: [twoSure.sumPair.a, twoSure.sumPair.b],
			gapPair: [twoSure.gapPair.a, twoSure.gapPair.b]
		}
	};
}
function archiveStats(snaps) {
	const scored = snaps.filter((s) => !s.pending && s.hits);
	const bySource = [
		"gold",
		"dates",
		"similar",
		"radar",
		"turbo2",
		"combo",
		"top3"
	].map((k) => {
		const tests = scored.length;
		const hits = scored.reduce((a, s) => a + (s.hits?.[k] ?? 0), 0);
		const atLeastOne = scored.filter((s) => (s.hits?.[k] ?? 0) > 0).length;
		return {
			source: k,
			tests,
			hits,
			atLeastOne,
			rate: tests ? atLeastOne / tests : 0
		};
	});
	return {
		scored: scored.length,
		pending: snaps.filter((s) => s.pending).length,
		bySource
	};
}
var dict = {
	fr: {
		appName: "π√8",
		appSub: "Analyse 5 parmi 90",
		unlock: "Déverrouiller",
		password: "Mot de passe",
		badPassword: "Code incorrect",
		lockHint: "Saisissez le code d’ouverture",
		tabDash: "Accueil",
		tabHist: "Historique",
		tabGrids: "Grilles",
		tabStats: "Stats",
		tabPred: "Prédiction",
		tabAsst: "Assistant",
		lastDraw: "Dernier tirage",
		draws: "tirages",
		replay: "Rejouer le tirage",
		addDraw: "Saisir un tirage",
		matrix: "Matrice vivante · Sommes & Écarts",
		sums: "Sommes",
		gaps: "Écarts",
		recent: "Mouvement récent",
		historical: "Référence historique",
		watch: "Famille à surveiller",
		active: "ACTIF",
		stable: "STABLE",
		late: "EN RETARD",
		gold: "Numéro en OR",
		similar: "Vérité sur les similitudes",
		dates: "Numéros par dates",
		radar: "Radar de Convergence",
		turbo2: "Turbo 2",
		twoSure: "Two Sûre",
		sumPairs: "Paires de Sommes",
		gapPairs: "Paires d’Écarts",
		archive: "Archive des prédictions",
		settings: "Paramètres",
		news: "News +",
		engines: "Moteurs",
		seen: "Apparues",
		waiting: "En attente",
		never: "Jamais",
		all: "Toutes",
		searchPair: "42+62, 42-62 ou 42 62",
		top3: "Top 3 du jour",
		combo: "Combinaison unique",
		goldNum: "Numéro en OR",
		probablePairs: "Paires convergentes",
		coherence: "Cohérence historique",
		snapshot: "Archiver avant tirage",
		snapDone: "Instantané enregistré",
		exportCsv: "Exporter CSV",
		exportPdf: "Exporter PDF",
		exportJson: "Exporter JSON",
		importFile: "Importer un fichier",
		language: "Langue",
		lockBack: "Verrouiller au retour",
		lockBackHint: "Redemande le code quand l’app revient au premier plan",
		bio: "Protection locale",
		bioHint: "Code d’ouverture + verrouillage au premier plan (biométrie selon l’appareil)",
		hot: "Chauds",
		cold: "Froids",
		delays: "Plus grands retards",
		freq: "Fréquence",
		delay: "Retard",
		cycle: "Cycle moyen",
		positions: "Positions N1–N5",
		neverDay: "Jamais sortis ce jour",
		indices: "Indices de sortie",
		monday: "Lundi",
		tuesday: "Mardi",
		wednesday: "Mercredi",
		thursday: "Jeudi",
		friday: "Vendredi",
		saturday: "Samedi",
		save: "Enregistrer",
		cancel: "Annuler",
		delete: "Supprimer",
		confirm: "Confirmer",
		saved: "Tirage enregistré",
		deleted: "Tirage retiré",
		invalid: "Saisie invalide — 5 numéros distincts de 1 à 90",
		duplicateDate: "Un tirage existe déjà à cette date",
		date: "Date",
		day: "Jour",
		orderHint: "L’ordre saisi est l’ordre réel N1 → N5",
		back: "Retour",
		reliability: "Indice de fiabilité (contrôle historique)",
		noPromise: "Aucune source ne garantit un résultat.",
		pending: "En attente du résultat",
		scored: "Scoré",
		found: "trouvés",
		filter: "Filtrer",
		appearances: "apparitions",
		firstTime: "Première apparition",
		suggestNever: "Paire inédite proposée",
		assistantLead: "Lecture des signaux — uniquement à partir de la base fusionnée.",
		nextDraw: "Prochain tirage",
		total: "Total",
		alternatives: "Alternatives",
		factors: "Facteurs",
		close: "Fermer",
		edit: "Corriger",
		manual: "manuel",
		seed: "intégré",
		source: "Source",
		hits: "touches",
		emptyArchive: "Aucun instantané. Archivez une prédiction avant le prochain tirage.",
		imported: "Import terminé",
		pairDetail: "Fiche de paire",
		waitingStatus: "Paire en attente — déjà vue, cycle dépassé",
		neverStatus: "Paire jamais observée dans la base",
		seenStatus: "Paire déjà sortie",
		clock: "Horloge",
		trend: "Tendance",
		last30: "30 derniers",
		byDay: "Par jour",
		histTitle: "Tous les tirages",
		pickNumbers: "Choisir N1 à N5",
		resetManual: "Effacer les saisies manuelles",
		resetDone: "Saisies manuelles effacées",
		share: "Partager",
		pdfReady: "PDF prêt",
		csvReady: "CSV prêt",
		jsonReady: "JSON prêt",
		scoreExplain: "Pourcentage de cohérence historique, pas une probabilité.",
		n1n2: "Paire ordonnée N1 → N2",
		sumPair: "Paire de somme",
		gapPair: "Paire d’écart",
		intensity: "Intensité",
		similarDraws: "Tirages proches",
		convergent: "Numéros convergents",
		archivesStats: "Statistiques par source",
		sundaySkip: "Pas de tirage le dimanche",
		footerNote: "Les boules conservent l’ordre réel de sortie."
	},
	en: {
		appName: "π√8",
		appSub: "5-from-90 analysis",
		unlock: "Unlock",
		password: "Password",
		badPassword: "Wrong code",
		lockHint: "Enter the opening code",
		tabDash: "Home",
		tabHist: "History",
		tabGrids: "Grids",
		tabStats: "Stats",
		tabPred: "Prediction",
		tabAsst: "Assistant",
		lastDraw: "Latest draw",
		draws: "draws",
		replay: "Replay draw",
		addDraw: "Enter a draw",
		matrix: "Live matrix · Sums & Gaps",
		sums: "Sums",
		gaps: "Gaps",
		recent: "Recent move",
		historical: "Historical baseline",
		watch: "Family to watch",
		active: "ACTIVE",
		stable: "STABLE",
		late: "LATE",
		gold: "Gold number",
		similar: "Truth on similarities",
		dates: "Numbers by dates",
		radar: "Convergence radar",
		turbo2: "Turbo 2",
		twoSure: "Two Sure",
		sumPairs: "Sum pairs",
		gapPairs: "Gap pairs",
		archive: "Prediction archive",
		settings: "Settings",
		news: "News +",
		engines: "Engines",
		seen: "Seen",
		waiting: "Waiting",
		never: "Never",
		all: "All",
		searchPair: "42+62, 42-62 or 42 62",
		top3: "Today’s top 3",
		combo: "Unique combination",
		goldNum: "Gold number",
		probablePairs: "Convergent pairs",
		coherence: "Historical coherence",
		snapshot: "Archive before draw",
		snapDone: "Snapshot saved",
		exportCsv: "Export CSV",
		exportPdf: "Export PDF",
		exportJson: "Export JSON",
		importFile: "Import a file",
		language: "Language",
		lockBack: "Lock on return",
		lockBackHint: "Ask for the code when the app comes back to the foreground",
		bio: "Local protection",
		bioHint: "Opening code + lock on foreground (device biometrics when available)",
		hot: "Hot",
		cold: "Cold",
		delays: "Longest delays",
		freq: "Frequency",
		delay: "Delay",
		cycle: "Mean cycle",
		positions: "Positions N1–N5",
		neverDay: "Never drawn this weekday",
		indices: "Exit cues",
		monday: "Monday",
		tuesday: "Tuesday",
		wednesday: "Wednesday",
		thursday: "Thursday",
		friday: "Friday",
		saturday: "Saturday",
		save: "Save",
		cancel: "Cancel",
		delete: "Delete",
		confirm: "Confirm",
		saved: "Draw saved",
		deleted: "Draw removed",
		invalid: "Invalid entry — 5 distinct numbers from 1 to 90",
		duplicateDate: "A draw already exists on this date",
		date: "Date",
		day: "Weekday",
		orderHint: "Entered order is the real N1 → N5 order",
		back: "Back",
		reliability: "Reliability index (historical check)",
		noPromise: "No source promises a result.",
		pending: "Waiting for the result",
		scored: "Scored",
		found: "found",
		filter: "Filter",
		appearances: "hits",
		firstTime: "First appearance",
		suggestNever: "Unseen pair suggested",
		assistantLead: "Signal reading — from the merged base only.",
		nextDraw: "Next draw",
		total: "Total",
		alternatives: "Alternatives",
		factors: "Factors",
		close: "Close",
		edit: "Edit",
		manual: "manual",
		seed: "built-in",
		source: "Source",
		hits: "hits",
		emptyArchive: "No snapshot yet. Archive a prediction before the next draw.",
		imported: "Import complete",
		pairDetail: "Pair file",
		waitingStatus: "Waiting pair — seen before, cycle exceeded",
		neverStatus: "Pair never observed in the base",
		seenStatus: "Pair already drawn",
		clock: "Clock",
		trend: "Trend",
		last30: "Last 30",
		byDay: "By weekday",
		histTitle: "All draws",
		pickNumbers: "Pick N1 to N5",
		resetManual: "Clear manual entries",
		resetDone: "Manual entries cleared",
		share: "Share",
		pdfReady: "PDF ready",
		csvReady: "CSV ready",
		jsonReady: "JSON ready",
		scoreExplain: "Historical coherence percentage, not a guaranteed probability.",
		n1n2: "Ordered pair N1 → N2",
		sumPair: "Sum pair",
		gapPair: "Gap pair",
		intensity: "Intensity",
		similarDraws: "Nearby draws",
		convergent: "Convergent numbers",
		archivesStats: "Stats by source",
		sundaySkip: "No draw on Sunday",
		footerNote: "Balls keep their real draw order."
	}
};
var STORAGE = "pv8-v1";
var SESSION = "pv8-unlocked";
function loadPersisted() {
	const fallback = {
		extras: [],
		removedDates: [],
		lang: "fr",
		lockOnBlur: true,
		archive: []
	};
	if (typeof localStorage === "undefined") return fallback;
	try {
		const raw = localStorage.getItem(STORAGE);
		if (!raw) return fallback;
		return {
			...fallback,
			...JSON.parse(raw)
		};
	} catch {
		return fallback;
	}
}
function persist(p) {
	try {
		localStorage.setItem(STORAGE, JSON.stringify(p));
	} catch {}
}
function recompute(extras, removedDates) {
	invalidateAnalysis();
	const draws = mergeDraws({
		extras,
		removedDates
	});
	return {
		draws,
		analysis: analyze(draws, false)
	};
}
var useApp = create((set, get) => ({
	extras: [],
	removedDates: [],
	lang: "fr",
	lockOnBlur: true,
	archive: [],
	unlocked: false,
	ready: false,
	stack: [{ id: "dashboard" }],
	toast: null,
	draws: [],
	analysis: null,
	hydrate: () => {
		const p = loadPersisted();
		const { draws, analysis } = recompute(p.extras, p.removedDates);
		let archive = p.archive;
		draws[draws.length - 1];
		archive = archive.map((s) => {
			if (!s.pending || !s.actual) return s;
			return s;
		});
		const unlocked = typeof sessionStorage !== "undefined" && sessionStorage.getItem(SESSION) === "1";
		set({
			...p,
			archive,
			draws,
			analysis,
			ready: true,
			unlocked
		});
		queueMicrotask(() => {
			set({ analysis: analyze(draws, true) });
		});
	},
	t: (k) => dict[get().lang][k],
	unlock: (code) => {
		if (code !== "skiab888") return false;
		try {
			sessionStorage.setItem(SESSION, "1");
		} catch {}
		set({ unlocked: true });
		return true;
	},
	lock: () => {
		try {
			sessionStorage.removeItem(SESSION);
		} catch {}
		set({ unlocked: false });
	},
	go: (s) => set({ stack: [...get().stack, s] }),
	back: () => set({ stack: get().stack.length > 1 ? get().stack.slice(0, -1) : [{ id: "dashboard" }] }),
	tab: (id) => set({ stack: [{ id }] }),
	setLang: (lang) => {
		const next = {
			...slicePersist(get()),
			lang
		};
		persist(next);
		set(next);
	},
	setLockOnBlur: (lockOnBlur) => {
		const next = {
			...slicePersist(get()),
			lockOnBlur
		};
		persist(next);
		set(next);
	},
	addDraw: (d) => {
		const day = weekdayFromDate(d.date);
		if (day === "dimanche") return get().t("sundaySkip");
		const draw = {
			...d,
			day
		};
		const { extras, removedDates, draws } = get();
		const exists = draws.some((x) => x.date === draw.date);
		let nextExtras = extras.filter((e) => e.date !== draw.date).concat(draw);
		let nextRemoved = removedDates.filter((x) => x !== draw.date);
		if (exists && !extras.some((e) => e.date === draw.date)) nextExtras = extras.concat(draw);
		const computed = recompute(nextExtras, nextRemoved);
		const persistable = {
			...slicePersist(get()),
			extras: nextExtras,
			removedDates: nextRemoved
		};
		persist(persistable);
		set({
			...persistable,
			...computed
		});
		get().scorePending(draw.date, draw.numbers);
		queueMicrotask(() => set({ analysis: analyze(computed.draws, true) }));
		return null;
	},
	removeDraw: (date) => {
		const extras = get().extras.filter((e) => e.date !== date);
		const removedDates = get().draws.some((d) => d.date === date && d.source === "seed") ? Array.from(/* @__PURE__ */ new Set([...get().removedDates, date])) : get().removedDates;
		const persistable = {
			...slicePersist(get()),
			extras,
			removedDates
		};
		persist(persistable);
		const computed = recompute(extras, removedDates);
		set({
			...persistable,
			...computed
		});
	},
	resetManual: () => {
		const persistable = {
			...slicePersist(get()),
			extras: [],
			removedDates: []
		};
		persist(persistable);
		const computed = recompute([], []);
		set({
			...persistable,
			...computed
		});
	},
	importDraws: (rows) => {
		let extras = [...get().extras];
		let removedDates = [...get().removedDates];
		for (const r of rows) {
			const day = weekdayFromDate(r.date);
			if (day === "dimanche") continue;
			extras = extras.filter((e) => e.date !== r.date).concat({
				...r,
				day
			});
			removedDates = removedDates.filter((d) => d !== r.date);
		}
		const persistable = {
			...slicePersist(get()),
			extras,
			removedDates
		};
		persist(persistable);
		const computed = recompute(extras, removedDates);
		set({
			...persistable,
			...computed
		});
		return rows.length;
	},
	archiveNow: () => {
		const a = get().analysis;
		if (!a) return;
		const snap = makeSnapshot(a);
		const archive = [snap, ...get().archive.filter((s) => s.forDate !== snap.forDate || !s.pending)];
		persist({
			...slicePersist(get()),
			archive
		});
		set({ archive });
	},
	scorePending: (date, numbers) => {
		const archive = get().archive.map((s) => s.pending && (s.forDate === date || s.forDate === "") ? scoreArchive(s, numbers) : s);
		persist({
			...slicePersist(get()),
			archive
		});
		set({ archive });
	},
	setToast: (toast) => set({ toast })
}));
function slicePersist(s) {
	return {
		extras: s.extras,
		removedDates: s.removedDates,
		lang: s.lang,
		lockOnBlur: s.lockOnBlur,
		archive: s.archive
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function haptic(ms = 12) {
	try {
		navigator.vibrate?.(ms);
	} catch {}
}
function downloadBlob(filename, blob) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.rel = "noopener";
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 1500);
}
var TONE = [
	"bg-[#e8e0d0] text-[#1a1712]",
	"bg-[#3e6b86] text-[#f3ece0]",
	"bg-[#3f6e58] text-[#f3ece0]",
	"bg-[#8b5340] text-[#f3ece0]",
	"bg-[#8a7040] text-[#f3ece0]",
	"bg-[#4a5560] text-[#f3ece0]",
	"bg-[#6a3d42] text-[#f3ece0]",
	"bg-[#355e62] text-[#f3ece0]",
	"bg-[#2c2c34] text-gold-2"
];
function ballTone(n) {
	return TONE[Math.min(8, Math.floor((n - 1) / 10))];
}
function Ball({ n, size = "md", highlight = false, dim = false, delay = 0, drop = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center justify-center rounded-full font-semibold tabular-nums", "shadow-[inset_0_1px_0_rgba(255,255,255,0.28),0_2px_6px_rgba(0,0,0,0.35)]", size === "lg" ? "h-14 w-14 text-[18px]" : size === "sm" ? "h-8 w-8 text-[12px]" : "h-11 w-11 text-[15px]", ballTone(n), highlight && "ring-2 ring-gold ring-offset-2 ring-offset-bg", dim && "opacity-45", drop && "ball-drop"),
		style: drop ? { animationDelay: `${delay}ms` } : void 0,
		children: n
	});
}
function BallRow({ numbers, highlight, size = "md", drop = false }) {
	const hi = new Set(highlight ?? []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center gap-2",
		children: numbers.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
			n,
			size,
			highlight: hi.has(n),
			drop,
			delay: i * 140
		}, `${n}-${i}`))
	});
}
function Logo({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative flex items-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
					n: 5,
					size: compact ? "sm" : "md"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "-ml-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
						n: 90,
						size: compact ? "sm" : "md"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					className: "absolute -bottom-1 left-1 h-3 w-14 text-gold/70",
					viewBox: "0 0 56 8",
					"aria-hidden": true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "1",
							y: "5",
							width: "4",
							height: "3",
							fill: "currentColor",
							opacity: "0.4"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "8",
							y: "3",
							width: "4",
							height: "5",
							fill: "currentColor",
							opacity: "0.7"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "15",
							y: "1",
							width: "4",
							height: "7",
							fill: "currentColor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "22",
							y: "4",
							width: "4",
							height: "4",
							fill: "currentColor",
							opacity: "0.55"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "29",
							y: "2",
							width: "4",
							height: "6",
							fill: "currentColor",
							opacity: "0.85"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "36",
							y: "5",
							width: "4",
							height: "3",
							fill: "currentColor",
							opacity: "0.4"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "43",
							y: "3",
							width: "4",
							height: "5",
							fill: "currentColor",
							opacity: "0.6"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-[28px] font-semibold leading-none tracking-tight text-ivory",
			children: "π√8"
		}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-[11px] tracking-[0.16em] text-muted uppercase",
			children: "5 parmi 90"
		})] })]
	});
}
function Card({ className, accent, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-[20px] bg-surface p-4", accent === "teal" ? "shadow-[0_0_0_1px_rgba(106,143,138,0.45)]" : accent === "ok" ? "shadow-[0_0_0_1px_rgba(125,155,115,0.4)]" : accent === "warn" ? "shadow-[0_0_0_1px_rgba(196,160,90,0.45)]" : accent === "line" ? "shadow-[0_0_0_1px_rgba(255,255,255,0.08)]" : "shadow-[0_0_0_1px_rgba(198,161,91,0.28)]", className),
		...props
	});
}
function Btn({ className, variant = "primary", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("press inline-flex min-h-11 items-center justify-center gap-2 rounded-[12px] px-4 text-[15px] font-medium", "disabled:opacity-40", variant === "ghost" ? "bg-surface-2 text-ivory" : variant === "danger" ? "bg-danger text-ivory" : variant === "gold" ? "bg-gold text-bg" : "bg-ivory text-bg", className),
		...props
	});
}
function Badge({ status, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("rounded-full px-2 py-0.5 text-[10px] font-semibold tracking-[0.12em]", status === "active" ? "bg-ok/20 text-ok" : status === "late" ? "bg-warn/20 text-warn" : status === "stable" ? "bg-white/8 text-muted" : "bg-white/8 text-muted"),
		children
	});
}
function BootScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-5 bg-bg text-ivory",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1 w-24 overflow-hidden rounded-full bg-surface-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-1/2 animate-pulse bg-gold" })
		})]
	});
}
function LockScreen() {
	const unlock = useApp((s) => s.unlock);
	const t = useApp((s) => s.t);
	const [code, setCode] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(false);
	const submit = () => {
		haptic(16);
		if (!unlock(code.trim())) {
			setErr(true);
			setCode("");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-col bg-bg px-6 pt-16 text-ivory",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger-in mx-auto w-full max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm text-muted",
					children: t("lockHint")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					inputMode: "text",
					autoComplete: "off",
					value: code,
					onChange: (e) => {
						setCode(e.target.value);
						setErr(false);
					},
					onKeyDown: (e) => e.key === "Enter" && submit(),
					placeholder: t("password"),
					className: "mt-4 h-12 w-full rounded-[14px] bg-surface px-4 text-ivory outline-none shadow-[0_0_0_1px_rgba(198,161,91,0.35)]"
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					children: t("badPassword")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "mt-5 w-full",
					variant: "gold",
					onClick: submit,
					children: t("unlock")
				})
			]
		})
	});
}
function Clock() {
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => clearInterval(id);
	}, []);
	const hh = now.toLocaleTimeString(void 0, {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
	const dd = now.toLocaleDateString(void 0, {
		weekday: "long",
		day: "numeric",
		month: "long"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[20px] bg-surface px-4 py-3 shadow-[0_0_0_1px_rgba(198,161,91,0.22)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-[28px] tabular-nums leading-none text-gold-2",
			children: hh
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-[12px] capitalize text-muted",
			children: dd
		})]
	});
}
function TopBar({ title, back }) {
	const goBack = useApp((s) => s.back);
	const t = useApp((s) => s.t);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-20 flex items-center gap-2 bg-bg/95 px-3 py-3 backdrop-blur",
		children: [back ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "press flex h-11 w-11 items-center justify-center rounded-[12px] bg-surface-2",
			onClick: () => {
				haptic();
				goBack();
			},
			"aria-label": t("back"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-[20px] font-semibold tracking-tight",
			children: title
		})]
	});
}
var TABS = [
	{
		id: "dashboard",
		icon: House,
		label: "tabDash"
	},
	{
		id: "history",
		icon: History,
		label: "tabHist"
	},
	{
		id: "grids",
		icon: Grid2x2,
		label: "tabGrids"
	},
	{
		id: "stats",
		icon: ChartColumn,
		label: "tabStats"
	},
	{
		id: "prediction",
		icon: Compass,
		label: "tabPred"
	},
	{
		id: "assistant",
		icon: MessageCircle,
		label: "tabAsst"
	}
];
function TabBar() {
	const tab = useApp((s) => s.tab);
	const stack = useApp((s) => s.stack);
	const t = useApp((s) => s.t);
	const current = stack[0]?.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "tab-bar sticky bottom-0 z-20 grid grid-cols-6 border-t border-line bg-bg-elev/95 px-1 pt-2 backdrop-blur",
		children: TABS.map((tb) => {
			const on = current === tb.id && stack.length === 1;
			const Icon = tb.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "press flex min-h-12 flex-col items-center justify-center gap-0.5",
				onClick: () => {
					haptic();
					tab(tb.id);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: on ? "h-[18px] w-[18px] text-gold" : "h-[18px] w-[18px] text-dim" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: on ? "text-[9px] font-medium text-gold-2" : "text-[9px] text-dim",
					children: t(tb.label)
				})]
			}, tb.id);
		})
	});
}
function ToastHost() {
	const toast = useApp((s) => s.toast);
	const setToast = useApp((s) => s.setToast);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const id = setTimeout(() => setToast(null), 2200);
		return () => clearTimeout(id);
	}, [toast, setToast]);
	if (!toast) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed top-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-gold px-4 py-2 text-sm font-medium text-bg shadow-lg",
		children: toast
	});
}
function statusUi(s) {
	return s;
}
function DashboardScreen() {
	const t = useApp((s) => s.t);
	const a = useApp((s) => s.analysis);
	const go = useApp((s) => s.go);
	const [dropKey, setDropKey] = (0, import_react.useState)(0);
	const last = a?.ctx.last;
	const n = a?.ctx.n ?? 0;
	const engines = (0, import_react.useMemo)(() => [
		{
			id: "gold",
			label: t("gold"),
			icon: Crown,
			tint: "gold"
		},
		{
			id: "similar",
			label: t("similar"),
			icon: ScanSearch,
			tint: "teal"
		},
		{
			id: "dates",
			label: t("dates"),
			icon: CalendarDays,
			tint: "line"
		},
		{
			id: "radar",
			label: t("radar"),
			icon: Radar,
			tint: "teal"
		},
		{
			id: "turbo2",
			label: t("turbo2"),
			icon: Zap,
			tint: "warn"
		},
		{
			id: "twosure",
			label: t("twoSure"),
			icon: Shield,
			tint: "ok"
		}
	], [t]);
	if (!a || !last) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4",
			children: "Aucune base."
		})]
	});
	const openFamily = (row) => {
		haptic();
		go(row.kind === "sum" ? {
			id: "sum-pairs",
			family: row.value
		} : {
			id: "gap-pairs",
			family: row.value
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-4 px-4 pb-8 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "press flex h-11 w-11 items-center justify-center rounded-[12px] bg-surface",
					onClick: () => {
						haptic();
						go({ id: "settings" });
					},
					"aria-label": t("settings"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-5 w-5 text-muted" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "py-3 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-2xl tabular-nums text-gold-2",
						children: n
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] text-muted",
						children: t("draws")
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "col-span-2 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.14em] text-muted",
						children: t("lastDraw")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 text-sm capitalize",
						children: [
							last.day,
							" · ",
							formatDateFr(last.date)
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: t("lastDraw")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-dim",
						children: t("footerNote")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BallRow, {
					numbers: last.numbers,
					size: "lg",
					drop: true
				}, dropKey),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "press mt-4 text-sm text-gold",
					onClick: () => {
						haptic();
						setDropKey((k) => k + 1);
					},
					children: t("replay")
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				className: "w-full",
				variant: "gold",
				onClick: () => {
					haptic();
					go({ id: "add" });
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), t("addDraw")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 flex items-center justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg",
					children: t("matrix")
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 text-[11px] uppercase tracking-[0.14em] text-gold",
					children: t("sums")
				}), a.matrix.sums.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "press mb-2 w-full rounded-[14px] bg-surface-2 p-3 text-left",
					onClick: () => openFamily(row),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xl tabular-nums",
								children: row.value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								status: statusUi(row.status),
								children: row.status === "active" ? t("active") : row.status === "late" ? t("late") : t("stable")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-[11px] text-muted",
							children: row.role === "recent" ? t("recent") : row.role === "historical" ? t("historical") : t("watch")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[12px] text-ivory/80",
							children: useApp.getState().lang === "en" ? row.explainEn : row.explainFr
						})
					]
				}, row.role))] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 text-[11px] uppercase tracking-[0.14em] text-teal",
					children: t("gaps")
				}), a.matrix.gaps.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "press mb-2 w-full rounded-[14px] bg-surface-2 p-3 text-left",
					onClick: () => openFamily(row),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xl tabular-nums",
								children: row.value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								status: statusUi(row.status),
								children: row.status === "active" ? t("active") : row.status === "late" ? t("late") : t("stable")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-[11px] text-muted",
							children: row.role === "recent" ? t("recent") : row.role === "historical" ? t("historical") : t("watch")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[12px] text-ivory/80",
							children: useApp.getState().lang === "en" ? row.explainEn : row.explainFr
						})
					]
				}, row.role))] })]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg",
				children: t("engines")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: engines.map((e) => {
					const Icon = e.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]",
						onClick: () => {
							haptic();
							go({ id: e.id });
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-sm font-medium",
							children: e.label
						})]
					}, e.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]",
						onClick: () => {
							haptic();
							go({ id: "sum-pairs" });
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-sm",
							children: t("sumPairs")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]",
						onClick: () => {
							haptic();
							go({ id: "gap-pairs" });
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5 text-teal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-sm",
							children: t("gapPairs")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]",
						onClick: () => {
							haptic();
							go({ id: "news" });
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newspaper, { className: "h-5 w-5 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-sm",
							children: t("news")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]",
						onClick: () => {
							haptic();
							go({ id: "archive" });
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "h-5 w-5 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-sm",
							children: t("archive")
						})]
					})
				]
			})
		]
	});
}
function VirtualList({ items, rowHeight, render, className, overscan = 8 }) {
	const ref = (0, import_react.useRef)(null);
	const [scroll, setScroll] = (0, import_react.useState)(0);
	const [h, setH] = (0, import_react.useState)(560);
	const start = Math.max(0, Math.floor(scroll / rowHeight) - overscan);
	const visible = Math.ceil(h / rowHeight) + overscan * 2;
	const end = Math.min(items.length, start + visible);
	const slice = (0, import_react.useMemo)(() => items.slice(start, end), [
		items,
		start,
		end
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className,
		onScroll: (e) => {
			const el = e.currentTarget;
			setScroll(el.scrollTop);
			setH(el.clientHeight);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				height: items.length * rowHeight,
				position: "relative"
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					position: "absolute",
					top: start * rowHeight,
					left: 0,
					right: 0
				},
				children: slice.map((item, i) => render(item, start + i))
			})
		})
	});
}
var DAY_I18N = {
	lundi: "monday",
	mardi: "tuesday",
	mercredi: "wednesday",
	jeudi: "thursday",
	vendredi: "friday",
	samedi: "saturday"
};
function HistoryScreen() {
	const t = useApp((s) => s.t);
	const draws = useApp((s) => s.draws);
	const go = useApp((s) => s.go);
	const [day, setDay] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const items = (0, import_react.useMemo)(() => {
		return [...draws].reverse().filter((d) => {
			if (day !== "all" && d.day !== day) return false;
			if (!q.trim()) return true;
			return d.numbers.join(" ").includes(q.trim()) || d.date.includes(q.trim());
		});
	}, [
		draws,
		day,
		q
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { title: t("histTitle") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1 overflow-x-auto px-3 pb-2 scrollbar-none",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: day === "all",
					onClick: () => setDay("all"),
					children: t("all")
				}), WEEKDAYS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: day === d,
					onClick: () => setDay(d),
					children: t(DAY_I18N[d])
				}, d))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "N° ou date",
				className: "mx-3 mb-2 h-11 rounded-[12px] bg-surface px-3 text-sm outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VirtualList, {
				className: "min-h-0 flex-1 overflow-auto px-3",
				items,
				rowHeight: 92,
				render: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 rounded-[16px] bg-surface p-3 shadow-[0_0_0_1px_rgba(198,161,91,0.16)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between text-[12px] text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "capitalize",
							children: [
								"#",
								d.index + 1,
								" · ",
								d.day,
								" · ",
								formatDateFr(d.date)
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase",
							children: d.source === "manual" ? t("manual") : t("seed")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1.5",
						children: d.numbers.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								haptic();
								go({
									id: "number",
									n
								});
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
								n,
								size: "sm"
							})
						}, `${d.id}-${i}`))
					})]
				})
			})
		]
	});
}
function Chip({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick,
		className: on ? "h-9 shrink-0 rounded-full bg-gold px-3 text-[12px] font-medium text-bg" : "h-9 shrink-0 rounded-full bg-surface px-3 text-[12px] text-muted",
		children
	});
}
function GridsScreen() {
	const t = useApp((s) => s.t);
	const a = useApp((s) => s.analysis);
	const go = useApp((s) => s.go);
	const [day, setDay] = (0, import_react.useState)("lundi");
	if (!a) return null;
	const total = a.ctx.dayTotals[day];
	const freq = a.ctx.numbers.slice(1).map((st) => ({
		n: st.n,
		c: st.byDay[day],
		delay: st.delay,
		cycle: st.avgCycle
	})).sort((x, y) => y.c - x.c);
	const missing = a.neverByDay[day];
	const cues = freq.filter((x) => x.c > 0 && x.delay >= x.cycle).slice(0, 12);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { title: t("tabGrids") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto px-3 pb-3 scrollbar-none",
				children: WEEKDAYS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: day === d,
					onClick: () => setDay(d),
					children: t(DAY_I18N[d])
				}, d))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[12px] text-muted",
						children: [
							total,
							" ",
							t("draws")
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-6 gap-2",
						children: freq.slice(0, 18).map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "flex flex-col items-center",
							onClick: () => {
								haptic();
								go({
									id: "number",
									n: x.n
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
								n: x.n,
								size: "sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 text-[10px] tabular-nums text-muted",
								children: x.c
							})]
						}, x.n))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-2 text-sm font-medium",
						children: t("neverDay")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-1.5",
						children: [missing.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								haptic();
								go({
									id: "number",
									n
								});
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
								n,
								size: "sm"
							})
						}, n)), missing.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "—"
						})]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-2 text-sm font-medium",
						children: t("indices")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: cues.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "flex w-full items-center justify-between",
							onClick: () => {
								haptic();
								go({
									id: "number",
									n: x.n
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
								n: x.n,
								size: "sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[12px] text-muted",
								children: [
									t("delay"),
									" ",
									x.delay,
									" · ",
									t("cycle"),
									" ",
									x.cycle.toFixed(1)
								]
							})]
						}, x.n))
					})] })
				]
			})
		]
	});
}
function StatsScreen() {
	const t = useApp((s) => s.t);
	const a = useApp((s) => s.analysis);
	const go = useApp((s) => s.go);
	if (!a) return null;
	const max = Math.max(...a.ctx.numbers.slice(1).map((s) => s.count), 1);
	const decade = Array.from({ length: 9 }, (_, i) => {
		const lo = i * 10 + 1;
		const hi = i === 8 ? 90 : (i + 1) * 10;
		let c = 0;
		for (let n = lo; n <= hi; n++) c += a.ctx.numbers[n].count;
		return {
			name: `${lo}-${hi}`,
			c
		};
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { title: t("tabStats") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-3 text-sm",
					children: t("freq")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-44",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: decade,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "name",
									tick: {
										fill: "#9a9488",
										fontSize: 10
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "#17171c",
									border: "1px solid #2a2a32",
									borderRadius: 12
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "c",
									fill: "#c6a15b",
									radius: [
										4,
										4,
										0,
										0
									]
								})
							]
						})
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-3 text-sm",
					children: "1 – 90"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-10 gap-1",
					children: Array.from({ length: 90 }, (_, i) => i + 1).map((n) => {
						const st = a.ctx.numbers[n];
						const op = .25 + st.count / max * .75;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								haptic();
								go({
									id: "number",
									n
								});
							},
							className: "flex h-8 items-center justify-center rounded-[8px] text-[10px] tabular-nums text-bg",
							style: { background: `rgba(198,161,91,${op})` },
							title: `${n}: ${st.count}`,
							children: n
						}, n);
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("hot")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: a.hot.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => go({
							id: "number",
							n
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n })
					}, n))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("cold")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: a.cold.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => go({
							id: "number",
							n
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n })
					}, n))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("delays")
				}), a.longestDelay.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "mb-2 flex w-full items-center justify-between",
					onClick: () => go({
						id: "number",
						n: x.n
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: x.n,
							size: "sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1.5 flex-1 mx-3 overflow-hidden rounded-full bg-surface-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-warn",
								style: { width: `${Math.min(100, x.delay * 2)}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 text-right text-sm tabular-nums",
							children: x.delay
						})
					]
				}, x.n))] })
			]
		})]
	});
}
function RelBar() {
	const t = useApp((s) => s.t);
	const rel = useApp((s) => s.analysis?.reliability ?? []);
	if (!rel.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm",
				children: t("reliability")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[11px] text-muted",
				children: t("noPromise")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 space-y-2",
				children: [...rel].sort((a, b) => b.rate - a.rate).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-[12px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "capitalize",
						children: r.source
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-muted",
						children: [
							Math.round(r.rate * 100),
							"% · ",
							r.hits,
							"/",
							r.tests
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 h-1.5 overflow-hidden rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-gold",
						style: { width: `${Math.round(r.rate * 100)}%` }
					})
				})] }, r.source))
			})
		]
	});
}
function GoldScreen() {
	const t = useApp((s) => s.t);
	const gold = useApp((s) => s.analysis?.gold);
	const go = useApp((s) => s.go);
	const lang = useApp((s) => s.lang);
	if (!gold) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("gold"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.16em] text-muted",
						children: t("goldNum")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "mx-auto mt-3",
						onClick: () => go({
							id: "number",
							n: gold.number
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: gold.number,
							size: "lg",
							highlight: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-display text-3xl tabular-nums text-gold-2",
						children: [gold.coherence, "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-muted",
						children: t("scoreExplain")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("factors")
				}), gold.factors.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-[13px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "en" ? f.labelEn : f.labelFr }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-muted",
							children: f.weight.toFixed(1)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 h-1.5 overflow-hidden rounded-full bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: f.weight >= 0 ? "h-full bg-ok" : "h-full bg-warn",
							style: { width: `${Math.min(100, Math.abs(f.weight) * 4)}%` }
						})
					})]
				}, f.key))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("alternatives")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-3",
					children: gold.alternatives.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "flex flex-col items-center",
						onClick: () => go({
							id: "number",
							n: x.number
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n: x.number }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 text-[11px] tabular-nums text-muted",
							children: [x.coherence, "%"]
						})]
					}, x.number))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelBar, {})
		]
	});
}
function SimilarScreen() {
	const t = useApp((s) => s.t);
	const sim = useApp((s) => s.analysis?.similar);
	const go = useApp((s) => s.go);
	if (!sim) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("similar"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-sm",
				children: t("convergent")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: sim.convergentNumbers.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => go({
						id: "number",
						n: c.n
					}),
					className: "flex flex-col items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n: c.n }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[10px] text-muted",
						children: ["×", c.hits]
					})]
				}, c.n))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("probablePairs")
				}), sim.convergentPairs.slice(0, 8).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "mb-2 flex w-full items-center justify-between",
					onClick: () => {
						haptic();
						go({
							id: "pair",
							a: p.a,
							b: p.b
						});
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: p.a,
							size: "sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: p.b,
							size: "sm"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[12px] text-muted",
						children: ["×", p.hits]
					})]
				}, `${p.a}-${p.b}`))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 mb-2 text-sm",
				children: t("similarDraws")
			}),
			sim.matches.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 text-[12px] capitalize text-muted",
					children: [
						m.draw.day,
						" · ",
						formatDateFr(m.draw.date),
						" · ",
						m.shared.length,
						" ",
						t("hits")
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BallRow, {
					numbers: m.draw.numbers,
					highlight: m.shared,
					size: "sm"
				})]
			}, m.draw.date))
		]
	});
}
function DatesScreen() {
	const t = useApp((s) => s.t);
	const dates = useApp((s) => s.analysis?.dates ?? []);
	const next = useApp((s) => s.analysis?.ctx.next);
	const go = useApp((s) => s.go);
	const lang = useApp((s) => s.lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("dates"),
				back: true
			}),
			next && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm text-muted",
				children: [
					t("nextDraw"),
					" · ",
					next.day,
					" ",
					formatDateFr(next.date)
				]
			}),
			dates.slice(0, 20).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "mb-2 flex w-full items-start gap-3 rounded-[16px] bg-surface p-3 text-left",
				onClick: () => go({
					id: "number",
					n: d.n
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n: d.n }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium",
							children: t("coherence")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-gold-2",
							children: [d.coherence, "%"]
						})]
					}), d.parts.slice(0, 3).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted",
						children: lang === "en" ? p.labelEn : p.labelFr
					}, p.key))]
				})]
			}, d.n))
		]
	});
}
function RadarScreen() {
	const t = useApp((s) => s.t);
	const radar = useApp((s) => s.analysis?.radar);
	const go = useApp((s) => s.go);
	const lang = useApp((s) => s.lang);
	if (!radar) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("radar"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.14em] text-muted",
						children: t("intensity")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl text-gold-2",
						children: radar.intensity
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex justify-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => go({
								id: "pair",
								a: radar.pair.a,
								b: radar.pair.b
							}),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
									n: radar.pair.a,
									highlight: true
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
									n: radar.pair.b,
									highlight: true
								})]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: lang === "en" ? radar.explainEn : radar.explainFr
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mt-3",
				children: radar.numbers.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "mb-2 flex w-full items-center justify-between",
					onClick: () => go({
						id: "number",
						n: n.n
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: n.n,
							size: "sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] text-muted",
							children: n.sources.join(" · ")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-sm",
						children: n.votes.toFixed(1)
					})]
				}, n.n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelBar, {})
		]
	});
}
function TurboScreen() {
	const t = useApp((s) => s.t);
	const turbo = useApp((s) => s.analysis?.turbo2);
	const lang = useApp((s) => s.lang);
	const go = useApp((s) => s.go);
	if (!turbo) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("turbo2"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.14em] text-muted",
					children: t("n1n2")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex justify-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => go({
							id: "number",
							n: turbo.n1
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-muted",
							children: "N1"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: turbo.n1,
							size: "lg"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => go({
							id: "number",
							n: turbo.n2
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-muted",
							children: "N2"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: turbo.n2,
							size: "lg"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [(lang === "en" ? turbo.n1ReasonsEn : turbo.n1ReasonsFr).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: r
				}, r)), (lang === "en" ? turbo.n2ReasonsEn : turbo.n2ReasonsFr).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: r
				}, r))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("alternatives")
				}), turbo.alternatives.map((al) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: al.n1,
							size: "sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "→"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: al.n2,
							size: "sm"
						})
					]
				}, `${al.n1}-${al.n2}`))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelBar, {})
		]
	});
}
function TwoSureScreen() {
	const t = useApp((s) => s.t);
	const two = useApp((s) => s.analysis?.twoSure);
	const lang = useApp((s) => s.lang);
	const go = useApp((s) => s.go);
	if (!two) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("twoSure"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm",
					children: t("sumPair")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "mt-2 flex gap-2",
					onClick: () => go({
						id: "pair",
						a: two.sumPair.a,
						b: two.sumPair.b
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
						n: two.sumPair.a,
						highlight: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
						n: two.sumPair.b,
						highlight: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[13px] text-muted",
					children: lang === "en" ? two.sumExplainEn : two.sumExplainFr
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm",
						children: t("gapPair")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "mt-2 flex gap-2",
						onClick: () => go({
							id: "pair",
							a: two.gapPair.a,
							b: two.gapPair.b
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: two.gapPair.a,
							highlight: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: two.gapPair.b,
							highlight: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[13px] text-muted",
						children: lang === "en" ? two.gapExplainEn : two.gapExplainFr
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelBar, {})
		]
	});
}
function statusLabel(s, t) {
	return s === "waiting" ? t("waiting") : s === "never" ? t("never") : t("seen");
}
function PairListScreen({ kind }) {
	const t = useApp((s) => s.t);
	const ctx = useApp((s) => s.analysis?.ctx);
	const stack = useApp((s) => s.stack);
	const go = useApp((s) => s.go);
	const top = stack[stack.length - 1];
	const family = top && "family" in top ? top.family : void 0;
	const [filter, setFilter] = (0, import_react.useState)("seen");
	const [q, setQ] = (0, import_react.useState)("");
	const items = (0, import_react.useMemo)(() => {
		if (!ctx) return [];
		let list = listPairs(ctx, kind, filter, family);
		const parsed = parsePairQuery(q);
		if (parsed) list = list.filter((p) => p.a === parsed.a && p.b === parsed.b);
		else if (q.trim()) {
			const n = Number(q.trim());
			if (n) list = list.filter((p) => p.a === n || p.b === n || p.sum === n || p.gap === n);
		}
		return list;
	}, [
		ctx,
		kind,
		filter,
		family,
		q
	]);
	if (!ctx) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: kind === "sum" ? t("sumPairs") : t("gapPairs"),
				back: true
			}),
			family != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "px-4 pb-1 text-sm text-gold",
				children: [
					kind === "sum" ? t("sums") : t("gaps"),
					" ",
					family
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t("searchPair"),
				className: "mx-3 mb-2 h-11 rounded-[12px] bg-surface px-3 text-sm outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 flex gap-1 px-3",
				children: [
					"all",
					"seen",
					"waiting",
					"never"
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setFilter(f),
					className: filter === f ? "h-8 rounded-full bg-gold px-3 text-[11px] text-bg" : "h-8 rounded-full bg-surface px-3 text-[11px] text-muted",
					children: t(f)
				}, f))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VirtualList, {
				className: "min-h-0 flex-1 overflow-auto px-3",
				items,
				rowHeight: 76,
				render: (p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairRow, {
					p,
					kind,
					onOpen: () => go({
						id: "pair",
						a: p.a,
						b: p.b
					})
				})
			})
		]
	});
}
function PairRow({ p, kind, onOpen }) {
	const t = useApp((s) => s.t);
	const up = p.trend >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: () => {
			haptic();
			onOpen();
		},
		className: "mb-2 flex w-full items-center gap-3 rounded-[16px] bg-surface p-3 text-left",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
				n: p.a,
				size: "sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
				n: p.b,
				size: "sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[12px] tabular-nums text-muted",
						children: kind === "sum" ? `${t("sums")} ${p.sum}` : `${t("gaps")} ${p.gap}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						status: p.status === "waiting" ? "late" : p.status === "never" ? "neutral" : "stable",
						children: statusLabel(p.status, t)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 h-1.5 overflow-hidden rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: up ? "h-full bg-ok" : "h-full bg-warn",
						style: { width: `${Math.min(100, 30 + Math.abs(p.trend) * 120 + p.count * 4)}%` }
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm tabular-nums",
				children: p.count
			})
		]
	});
}
function PairDetailScreen({ a, b }) {
	const t = useApp((s) => s.t);
	const ctx = useApp((s) => s.analysis?.ctx);
	if (!ctx) return null;
	const p = getPair(ctx, a, b);
	const st = p.status === "never" ? t("neverStatus") : p.status === "waiting" ? t("waitingStatus") : t("seenStatus");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("pairDetail"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: p.a,
							size: "lg",
							highlight: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: p.b,
							size: "lg",
							highlight: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: st
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-[12px] text-muted",
						children: [
							t("sums"),
							" ",
							p.sum,
							" · ",
							t("gaps"),
							" ",
							p.gap,
							" · ",
							p.count,
							" ",
							t("appearances"),
							" · ",
							t("delay"),
							" ",
							p.delay,
							" · ",
							t("cycle"),
							" ",
							p.avgCycle.toFixed(1),
							" · ",
							t("last30"),
							" ",
							p.last30
						]
					})
				]
			}),
			p.dates.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: t("neverStatus")
				})
			}),
			p.dates.slice().reverse().map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 text-[12px] capitalize text-muted",
					children: [
						"#",
						d.index + 1,
						" · ",
						d.day,
						" · ",
						formatDateFr(d.date)
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BallRow, {
					numbers: d.numbers,
					highlight: [p.a, p.b],
					size: "sm"
				})]
			}, d.date + d.index))
		]
	});
}
function NumberScreen({ n }) {
	const t = useApp((s) => s.t);
	const st = useApp((s) => s.analysis?.ctx.numbers[n]);
	const go = useApp((s) => s.go);
	if (!st) return null;
	const up = st.trend >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: `N° ${n}`,
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
						n,
						size: "lg"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-3 gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-xl tabular-nums",
								children: st.count
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted",
								children: t("appearances")
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-xl tabular-nums",
								children: st.delay
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted",
								children: t("delay")
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-xl tabular-nums",
								children: st.avgCycle.toFixed(1)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted",
								children: t("cycle")
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-2 overflow-hidden rounded-full bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: up ? "h-full bg-ok" : "h-full bg-warn",
							style: { width: `${Math.min(100, 40 + st.last10 * 8)}%` }
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("positions")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-between text-[12px]",
					children: st.byPosition.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"N",
						i + 1,
						" ",
						c
					] }, i))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("byDay")
				}), Object.entries(st.byDay).map(([d, c]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-[13px] capitalize",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: c
					})]
				}, d))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 mb-2 text-sm",
				children: t("histTitle")
			}),
			st.dates.slice().reverse().map((d, i, arr) => {
				const prev = arr[i + 1];
				const gap = prev ? d.index - prev.index : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "mb-2 w-full rounded-[16px] bg-surface p-3 text-left",
					onClick: () => {
						const others = d.numbers.filter((x) => x !== n);
						if (others[0]) go({
							id: "pair",
							a: Math.min(n, others[0]),
							b: Math.max(n, others[0])
						});
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex justify-between text-[12px] text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "capitalize",
							children: [
								"#",
								d.index + 1,
								" · ",
								d.day,
								" · ",
								formatDateFr(d.date)
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"N",
							d.positions[0],
							gap != null ? ` · écart ${gap}` : ""
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BallRow, {
						numbers: d.numbers,
						highlight: [n],
						size: "sm"
					})]
				}, d.date);
			})
		]
	});
}
function drawsToCsv(draws) {
	return ["Jour,Date,N1,N2,N3,N4,N5,Source", ...draws.map((d) => `${d.day},${d.date},${d.numbers.join(",")},${d.source}`)].join("\n");
}
function drawsToJson(draws) {
	return JSON.stringify(draws.map((d) => ({
		jour: d.day,
		date: d.date,
		N1: d.numbers[0],
		N2: d.numbers[1],
		N3: d.numbers[2],
		N4: d.numbers[3],
		N5: d.numbers[4],
		source: d.source
	})), null, 2);
}
function parseDay(raw, date) {
	const v = raw.trim().toLowerCase();
	if (isWeekday(v)) return v;
	const fromDate = weekdayFromDate(date);
	return fromDate === "dimanche" ? "lundi" : fromDate;
}
function parseImported(text) {
	const errors = [];
	const ok = [];
	const trimmed = text.trim();
	if (!trimmed) return {
		ok,
		errors: ["Fichier vide"]
	};
	if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
		try {
			const data = JSON.parse(trimmed);
			(Array.isArray(data) ? data : [data]).forEach((row, i) => {
				const r = row;
				const date = String(r.date ?? r.Date ?? "");
				const list = Array.isArray(r.numbers) ? r.numbers : Array.isArray(r.n) ? r.n : [];
				const nums = [
					Number(r.N1 ?? r.n1 ?? list[0]),
					Number(r.N2 ?? r.n2 ?? list[1]),
					Number(r.N3 ?? r.n3 ?? list[2]),
					Number(r.N4 ?? r.n4 ?? list[3]),
					Number(r.N5 ?? r.n5 ?? list[4])
				];
				if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !validateNumbers(nums)) {
					errors.push(`Ligne JSON ${i + 1} invalide`);
					return;
				}
				const day = parseDay(String(r.jour ?? r.day ?? r.Jour ?? ""), date);
				ok.push({
					date,
					day,
					numbers: nums
				});
			});
		} catch {
			errors.push("JSON illisible");
		}
		return {
			ok,
			errors
		};
	}
	const lines = trimmed.split(/\r?\n/).filter((l) => l.trim());
	const start = /jour|date|n1/i.test(lines[0] ?? "") ? 1 : 0;
	for (let i = start; i < lines.length; i++) {
		const cols = lines[i].split(/[;,\t]/).map((c) => c.trim());
		if (cols.length < 6) {
			errors.push(`Ligne ${i + 1}: colonnes insuffisantes`);
			continue;
		}
		let dayRaw = "";
		let date = "";
		let nums = [];
		if (/^\d{4}-\d{2}-\d{2}$/.test(cols[0])) {
			date = cols[0];
			nums = cols.slice(1, 6).map(Number);
		} else if (/^\d{4}-\d{2}-\d{2}$/.test(cols[1])) {
			dayRaw = cols[0];
			date = cols[1];
			nums = cols.slice(2, 7).map(Number);
		} else if (/^\d{2}\/\d{2}\/\d{4}$/.test(cols[1])) {
			const [dd, mm, yy] = cols[1].split("/");
			date = `${yy}-${mm}-${dd}`;
			dayRaw = cols[0];
			nums = cols.slice(2, 7).map(Number);
		} else {
			errors.push(`Ligne ${i + 1}: date inconnue`);
			continue;
		}
		if (!validateNumbers(nums)) {
			errors.push(`Ligne ${i + 1}: numéros invalides`);
			continue;
		}
		const day = parseDay(dayRaw, date);
		ok.push({
			date,
			day,
			numbers: nums
		});
	}
	return {
		ok,
		errors
	};
}
function archiveToCsv(snaps) {
	return ["Date cible,Créée,Statut,Combo,OR,Turbo2,Radar,Résultat,Touches combo,Touches OR", ...snaps.map((s) => [
		s.forDate,
		s.createdAt.slice(0, 10),
		s.pending ? "en attente" : "scoré",
		s.sources.combo.join("-"),
		s.sources.gold.join("-"),
		s.sources.turbo2.join("-"),
		s.sources.radar.join("-"),
		s.actual?.join("-") ?? "",
		s.hits?.combo ?? "",
		s.hits?.gold ?? ""
	].join(","))].join("\n");
}
/** Minimal single-page PDF (WinAnsi) for archive sharing. */
function archiveToPdf(snaps) {
	const lines = ["pi-racine 8  —  Archive des predictions", ""];
	for (const s of snaps.slice(0, 40)) {
		const status = s.pending ? "pending" : `hits combo=${s.hits?.combo ?? 0} or=${s.hits?.gold ?? 0}`;
		lines.push(`${s.forDate}  ${status}`);
		lines.push(`  combo ${s.sources.combo.join(" ")}   OR ${s.sources.gold.join(" ")}`);
		if (s.actual) lines.push(`  result ${s.actual.join(" ")}`);
		lines.push("");
	}
	const escaped = (t) => t.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
	let y = 800;
	const content = ["BT /F1 11 Tf"];
	for (const line of lines) {
		content.push(`1 0 0 1 40 ${y} Tm (${escaped(line)}) Tj`);
		y -= 16;
		if (y < 40) break;
	}
	content.push("ET");
	const stream = content.join("\n");
	const objects = [
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
		`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
		"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"
	];
	let pdf = "%PDF-1.4\n";
	const offsets = [0];
	objects.forEach((obj, i) => {
		offsets.push(pdf.length);
		pdf += `${i + 1} 0 obj\n${obj}\nendobj\n`;
	});
	const xref = pdf.length;
	pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
	for (let i = 1; i <= objects.length; i++) pdf += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
	pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
	return pdf;
}
function PredictionScreen() {
	const t = useApp((s) => s.t);
	const a = useApp((s) => s.analysis);
	const archiveNow = useApp((s) => s.archiveNow);
	const setToast = useApp((s) => s.setToast);
	const go = useApp((s) => s.go);
	if (!a) return null;
	const p = a.prediction;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { title: t("tabPred") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-[12px] text-muted",
				children: t("scoreExplain")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm",
				children: t("top3")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex justify-around",
				children: p.top3.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "flex flex-col items-center",
					onClick: () => go({
						id: "number",
						n: x.n
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
						n: x.n,
						size: "lg"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 text-sm tabular-nums text-gold-2",
						children: [x.coherence, "%"]
					})]
				}, x.n))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm",
						children: t("goldNum")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "mt-2",
						onClick: () => go({
							id: "number",
							n: p.gold.number
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: p.gold.number,
							size: "lg",
							highlight: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-gold-2",
						children: [p.gold.coherence, "%"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-3 text-sm",
					children: t("combo")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BallRow, {
					numbers: p.combo,
					size: "lg"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm",
					children: t("probablePairs")
				}), p.pairs.map((pair, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "mb-2 flex w-full items-center justify-between",
					onClick: () => go({
						id: "pair",
						a: Math.min(pair.a, pair.b),
						b: Math.max(pair.a, pair.b)
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: pair.a,
							size: "sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: pair.b,
							size: "sm"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted",
						children: useApp.getState().lang === "en" ? pair.whyEn : pair.whyFr
					})]
				}, i))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-4 w-full",
				onClick: () => {
					haptic();
					archiveNow();
					setToast(t("snapDone"));
				},
				children: t("snapshot")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "mt-3 w-full text-sm text-gold",
				onClick: () => go({ id: "archive" }),
				children: t("archive")
			})
		]
	});
}
function AssistantScreen() {
	const t = useApp((s) => s.t);
	const a = useApp((s) => s.analysis);
	const lang = useApp((s) => s.lang);
	if (!a || !a.ctx.last) return null;
	const last = a.ctx.last;
	const lines = lang === "en" ? [
		`Merged base: ${a.ctx.n} draws. Last: ${last.day} ${formatDateFr(last.date)} → ${last.numbers.join(" · ")} (real N1–N5 order).`,
		`Gold number ${a.gold.number} (coherence ${a.gold.coherence}%). ${a.gold.factors[0]?.labelEn ?? ""}`,
		`Live matrix — sums recent ${a.matrix.sums[0].value} (${a.matrix.sums[0].status}), watch ${a.matrix.sums[2].value}. Gaps recent ${a.matrix.gaps[0].value}, watch ${a.matrix.gaps[2].value}.`,
		`Radar pair ${a.radar.pair.a}·${a.radar.pair.b}, intensity ${a.radar.intensity}.`,
		`Turbo 2 ordered ${a.turbo2.n1} → ${a.turbo2.n2}. Two Sure sum ${a.twoSure.sumPair.a}+${a.twoSure.sumPair.b}, gap ${a.twoSure.gapPair.a}–${a.twoSure.gapPair.b}.`,
		a.news.firsts.length ? `News+: ${a.news.firsts.length} first-time pair signals on the last draw.` : `News+: no first-time exact pair on the last draw.`,
		`Longest delay: ${a.longestDelay[0]?.n} (${a.longestDelay[0]?.delay} draws).`
	] : [
		`Base fusionnée : ${a.ctx.n} tirages. Dernier : ${last.day} ${formatDateFr(last.date)} → ${last.numbers.join(" · ")} (ordre réel N1–N5).`,
		`Numéro en OR ${a.gold.number} (cohérence ${a.gold.coherence} %). ${a.gold.factors[0]?.labelFr ?? ""}`,
		`Matrice vivante — sommes récentes ${a.matrix.sums[0].value} (${a.matrix.sums[0].status}), à surveiller ${a.matrix.sums[2].value}. Écarts récents ${a.matrix.gaps[0].value}, à surveiller ${a.matrix.gaps[2].value}.`,
		`Paire radar ${a.radar.pair.a}·${a.radar.pair.b}, intensité ${a.radar.intensity}.`,
		`Turbo 2 ordonné ${a.turbo2.n1} → ${a.turbo2.n2}. Two Sûre somme ${a.twoSure.sumPair.a}+${a.twoSure.sumPair.b}, écart ${a.twoSure.gapPair.a}–${a.twoSure.gapPair.b}.`,
		a.news.firsts.length ? `News+ : ${a.news.firsts.length} signaux de paires inédites sur le dernier tirage.` : `News+ : aucune paire exacte inédite sur le dernier tirage.`,
		`Plus grand retard : ${a.longestDelay[0]?.n} (${a.longestDelay[0]?.delay} tirages).`
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { title: t("tabAsst") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: t("assistantLead")
			}),
			lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mb-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[14px] leading-relaxed",
					children: l
				})
			}, l))
		]
	});
}
function NewsScreen() {
	const t = useApp((s) => s.t);
	const news = useApp((s) => s.analysis?.news);
	const go = useApp((s) => s.go);
	if (!news) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("news"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm",
					children: t("firstTime")
				}),
				news.firsts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "—"
				}),
				news.firsts.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "mt-2 flex w-full items-center justify-between",
					onClick: () => go({
						id: "pair",
						a: f.pair.a,
						b: f.pair.b
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: f.pair.a,
							size: "sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
							n: f.pair.b,
							size: "sm"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[12px] text-muted",
						children: [
							f.kind === "sum" ? t("sums") : t("gaps"),
							" ",
							f.value
						]
					})]
				}, i))
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm",
						children: t("suggestNever")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[12px] text-muted",
						children: t("sumPair")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "mt-2 flex gap-2",
						onClick: () => go({
							id: "pair",
							a: news.suggestSum.a,
							b: news.suggestSum.b
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n: news.suggestSum.a }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n: news.suggestSum.b })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-[12px] text-muted",
						children: t("gapPair")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "mt-2 flex gap-2",
						onClick: () => go({
							id: "pair",
							a: news.suggestGap.a,
							b: news.suggestGap.b
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n: news.suggestGap.a }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n: news.suggestGap.b })]
					})
				]
			})
		]
	});
}
function ArchiveScreen() {
	const t = useApp((s) => s.t);
	const archive = useApp((s) => s.archive);
	const stats = archiveStats(archive);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("archive"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm",
					children: t("archivesStats")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[12px] text-muted",
					children: [
						stats.scored,
						" ",
						t("scored"),
						" · ",
						stats.pending,
						" ",
						t("pending")
					]
				}),
				stats.bySource.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-between text-[13px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "capitalize",
						children: s.source
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-muted",
						children: [
							Math.round(s.rate * 100),
							"% · ",
							s.atLeastOne,
							"/",
							s.tests
						]
					})]
				}, s.source))
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => {
						downloadBlob("archive-pv8.csv", new Blob([archiveToCsv(archive)], { type: "text/csv" }));
						useApp.getState().setToast(t("csvReady"));
					},
					children: t("exportCsv")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					onClick: () => {
						downloadBlob("archive-pv8.pdf", new Blob([archiveToPdf(archive)], { type: "application/pdf" }));
						useApp.getState().setToast(t("pdfReady"));
					},
					children: t("exportPdf")
				})]
			}),
			archive.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: t("emptyArchive")
			}),
			archive.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-[12px] text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							s.forDay,
							" · ",
							formatDateFr(s.forDate)
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.pending ? t("pending") : t("scored") })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BallRow, {
							numbers: s.sources.combo,
							size: "sm"
						})
					}),
					s.actual && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted",
							children: "Résultat"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BallRow, {
							numbers: s.actual,
							size: "sm",
							highlight: s.sources.combo
						})]
					}),
					s.hits && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[12px] text-muted",
						children: [
							"combo ",
							s.hits.combo,
							" · OR ",
							s.hits.gold,
							" · radar ",
							s.hits.radar,
							" · turbo ",
							s.hits.turbo2
						]
					})
				]
			}, s.id))
		]
	});
}
function SettingsScreen() {
	const t = useApp((s) => s.t);
	const lang = useApp((s) => s.lang);
	const setLang = useApp((s) => s.setLang);
	const lockOnBlur = useApp((s) => s.lockOnBlur);
	const setLockOnBlur = useApp((s) => s.setLockOnBlur);
	const draws = useApp((s) => s.draws);
	const resetManual = useApp((s) => s.resetManual);
	const importDraws = useApp((s) => s.importDraws);
	const setToast = useApp((s) => s.setToast);
	const lock = useApp((s) => s.lock);
	const fileRef = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("settings"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm",
				children: t("language")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: lang === "fr" ? "gold" : "ghost",
					onClick: () => setLang("fr"),
					children: "Français"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: lang === "en" ? "gold" : "ghost",
					onClick: () => setLang("en"),
					children: "English"
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm",
						children: t("bio")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[12px] text-muted",
						children: t("bioHint")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 flex min-h-11 items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: t("lockBack")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: lockOnBlur,
							onChange: (e) => setLockOnBlur(e.target.checked),
							className: "h-5 w-5 accent-[#c6a15b]"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted",
						children: t("lockBackHint")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "mt-3 w-full",
						variant: "ghost",
						onClick: () => lock(),
						children: lang === "en" ? "Lock now" : "Verrouiller maintenant"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "w-full",
						variant: "ghost",
						onClick: () => {
							downloadBlob("tirages-pv8.json", new Blob([drawsToJson(draws)], { type: "application/json" }));
							setToast(t("jsonReady"));
						},
						children: t("exportJson")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "w-full",
						variant: "ghost",
						onClick: () => {
							downloadBlob("tirages-pv8.csv", new Blob([drawsToCsv(draws)], { type: "text/csv" }));
							setToast(t("csvReady"));
						},
						children: t("exportCsv")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "w-full",
						variant: "ghost",
						onClick: () => fileRef.current?.click(),
						children: t("importFile")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: ".json,.csv,text/csv,application/json",
						className: "hidden",
						onChange: async (e) => {
							const f = e.target.files?.[0];
							if (!f) return;
							const { ok, errors } = parseImported(await f.text());
							if (ok.length) {
								importDraws(ok);
								setToast(`${t("imported")} (${ok.length})`);
							} else setToast(errors[0] ?? t("invalid"));
							e.target.value = "";
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "w-full",
						variant: "danger",
						onClick: () => {
							resetManual();
							setToast(t("resetDone"));
						},
						children: t("resetManual")
					})
				]
			})
		]
	});
}
function AddDrawScreen({ editDate }) {
	const t = useApp((s) => s.t);
	const draws = useApp((s) => s.draws);
	const addDraw = useApp((s) => s.addDraw);
	const removeDraw = useApp((s) => s.removeDraw);
	const setToast = useApp((s) => s.setToast);
	const back = useApp((s) => s.back);
	const last = draws[draws.length - 1];
	const suggested = last ? nextDrawDate(last.date).date : "2026-08-31";
	const existing = editDate ? draws.find((d) => d.date === editDate) : void 0;
	const [date, setDate] = (0, import_react.useState)(existing?.date ?? suggested);
	const [picked, setPicked] = (0, import_react.useState)(existing ? [...existing.numbers] : []);
	const [flash, setFlash] = (0, import_react.useState)(false);
	const dayRaw = weekdayFromDate(date);
	const day = dayRaw === "dimanche" ? null : dayRaw;
	const toggle = (n) => {
		haptic(8);
		setPicked((p) => {
			if (p.includes(n)) return p.filter((x) => x !== n);
			if (p.length >= 5) return p;
			return [...p, n];
		});
	};
	const save = () => {
		if (!day) {
			setToast(t("sundaySkip"));
			return;
		}
		if (!validateNumbers(picked)) {
			setToast(t("invalid"));
			return;
		}
		const err = addDraw({
			date,
			day,
			numbers: picked
		});
		if (err) {
			setToast(err);
			return;
		}
		haptic(20);
		setFlash(true);
		setToast(t("saved"));
		setTimeout(() => {
			setFlash(false);
			back();
		}, 900);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("addDraw"),
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-[12px] text-muted",
					children: t("date")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value),
					className: "mt-1 h-11 w-full rounded-[12px] bg-surface-2 px-3 text-ivory outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm capitalize text-gold",
					children: [
						t("day"),
						": ",
						day ? useApp.getState().lang === "en" ? t(DAY_I18N[day]) : day : t("sundaySkip")
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[12px] text-muted",
					children: t("orderHint")
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm",
						children: t("pickNumbers")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-3 flex min-h-12 items-center gap-2",
						children: picked.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BallRow, { numbers: picked }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: "N1 → N5"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-10 gap-1",
						children: Array.from({ length: 90 }, (_, i) => i + 1).map((n) => {
							const on = picked.includes(n);
							const idx = picked.indexOf(n);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => toggle(n),
								className: on ? "h-8 rounded-[8px] bg-gold text-[11px] font-semibold text-bg" : "h-8 rounded-[8px] bg-surface-2 text-[11px] text-ivory",
								children: on ? `${n}·${idx + 1}` : n
							}, n);
						})
					})
				]
			}),
			flash && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 rounded-[16px] bg-ok/20 p-4 text-center text-ok",
				children: t("saved")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-4 w-full",
				variant: "gold",
				onClick: save,
				children: t("save")
			}),
			existing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-2 w-full",
				variant: "danger",
				onClick: () => {
					removeDraw(existing.date);
					setToast(t("deleted"));
					back();
				},
				children: t("delete")
			})
		]
	});
}
function ScreenBody({ screen }) {
	switch (screen.id) {
		case "dashboard": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardScreen, {});
		case "history": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryScreen, {});
		case "grids": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridsScreen, {});
		case "stats": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsScreen, {});
		case "prediction": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PredictionScreen, {});
		case "assistant": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssistantScreen, {});
		case "gold": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldScreen, {});
		case "similar": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimilarScreen, {});
		case "dates": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatesScreen, {});
		case "radar": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadarScreen, {});
		case "turbo2": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TurboScreen, {});
		case "twosure": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TwoSureScreen, {});
		case "sum-pairs": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairListScreen, { kind: "sum" });
		case "gap-pairs": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairListScreen, { kind: "gap" });
		case "pair": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairDetailScreen, {
			a: screen.a,
			b: screen.b
		});
		case "number": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberScreen, { n: screen.n });
		case "archive": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchiveScreen, {});
		case "settings": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {});
		case "news": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewsScreen, {});
		case "add": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddDrawScreen, { editDate: screen.editDate });
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardScreen, {});
	}
}
var TAB_IDS = /* @__PURE__ */ new Set([
	"dashboard",
	"history",
	"grids",
	"stats",
	"prediction",
	"assistant"
]);
function AppMain() {
	const ready = useApp((s) => s.ready);
	const unlocked = useApp((s) => s.unlocked);
	const hydrate = useApp((s) => s.hydrate);
	const stack = useApp((s) => s.stack);
	const lockOnBlur = useApp((s) => s.lockOnBlur);
	const lock = useApp((s) => s.lock);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const onVis = () => {
			if (document.visibilityState === "visible" && lockOnBlur && useApp.getState().unlocked) lock();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => document.removeEventListener("visibilitychange", onVis);
	}, [lockOnBlur, lock]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	if (!unlocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockScreen, {});
	const top = stack[stack.length - 1] ?? { id: "dashboard" };
	const showTabs = stack.length === 1 && TAB_IDS.has(top.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "phone-shell text-ivory",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "phone-frame mx-auto flex min-h-dvh max-w-[430px] flex-col bg-bg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 overflow-y-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenBody, { screen: top })
				}),
				showTabs && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBar, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToastHost, {})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppMain, {});
}
//#endregion
export { Home as component };
