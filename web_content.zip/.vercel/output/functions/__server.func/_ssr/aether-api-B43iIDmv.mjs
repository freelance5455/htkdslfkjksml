import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aether-api-B43iIDmv.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var UA = "AetherConsole/1.0 (tablet multimedia screen)";
var PIPED = ["https://api.piped.private.coffee"];
function asNumber(value) {
	const number = typeof value === "number" ? value : Number(value);
	return Number.isFinite(number) ? number : null;
}
function clampQuery(value) {
	if (typeof value !== "string") throw new Error("Consulta inválida");
	const query = value.trim().slice(0, 100);
	if (query.length < 2) throw new Error("Escribe al menos 2 caracteres");
	return query;
}
function coord(value, min, max) {
	const number = asNumber(value);
	if (number == null || number < min || number > max) throw new Error("Coordenadas inválidas");
	return number;
}
async function getJson(url) {
	const response = await fetch(url, {
		headers: {
			Accept: "application/json",
			"User-Agent": UA
		},
		signal: AbortSignal.timeout(9e3)
	});
	if (!response.ok) throw new Error(String(response.status));
	return response.json();
}
var searchPlaces_createServerFn_handler = createServerRpc({
	id: "6399acd62efc069988915670a8f3ca832658085ec5ba1a1479798927de2fe001",
	name: "searchPlaces",
	filename: "src/lib/aether-api.ts"
}, (opts) => searchPlaces.__executeServer(opts));
var searchPlaces = createServerFn({ method: "GET" }).validator((data) => ({ q: clampQuery(data?.q) })).handler(searchPlaces_createServerFn_handler, async ({ data }) => {
	try {
		const json = await getJson(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&q=${encodeURIComponent(data.q)}`);
		if (!Array.isArray(json)) return {
			ok: true,
			hits: []
		};
		const hits = [];
		for (const row of json) {
			if (!row || typeof row !== "object") continue;
			const record = row;
			const lat = asNumber(record.lat);
			const lon = asNumber(record.lon);
			const label = typeof record.display_name === "string" ? record.display_name : "";
			if (lat == null || lon == null || !label) continue;
			hits.push({
				id: String(record.place_id ?? `${lat},${lon}`),
				label: label.split(",").slice(0, 3).join(",").trim(),
				lat,
				lon
			});
		}
		return {
			ok: true,
			hits
		};
	} catch {
		return {
			ok: false,
			error: "No se pudo buscar el lugar. Inténtalo de nuevo."
		};
	}
});
var reversePlace_createServerFn_handler = createServerRpc({
	id: "c2eec810bc64097638182a3fc43fb67692b29ad33d6eaf3445d2f2bb37c557ed",
	name: "reversePlace",
	filename: "src/lib/aether-api.ts"
}, (opts) => reversePlace.__executeServer(opts));
var reversePlace = createServerFn({ method: "GET" }).validator((data) => ({
	lat: coord(data?.lat, -90, 90),
	lon: coord(data?.lon, -180, 180)
})).handler(reversePlace_createServerFn_handler, async ({ data }) => {
	try {
		const json = await getJson(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=14&addressdetails=1&lat=${data.lat}&lon=${data.lon}`);
		if (!json || typeof json !== "object") return {
			ok: false,
			error: "sin lugar"
		};
		const record = json;
		const address = record.address && typeof record.address === "object" ? record.address : {};
		const parts = [
			address.suburb,
			address.neighbourhood,
			address.city,
			address.town,
			address.village,
			address.state
		].filter((part) => typeof part === "string" && part.length > 0);
		return {
			ok: true,
			label: [...new Set(parts)].slice(0, 2).join(", ") || (typeof record.name === "string" ? record.name : "Tu zona")
		};
	} catch {
		return {
			ok: false,
			error: "sin lugar"
		};
	}
});
var routeDrive_createServerFn_handler = createServerRpc({
	id: "0106403ebabf39fa4c382f9f718e68065eb5053ecec5c4238c85495977e17b0f",
	name: "routeDrive",
	filename: "src/lib/aether-api.ts"
}, (opts) => routeDrive.__executeServer(opts));
var routeDrive = createServerFn({ method: "GET" }).validator((data) => ({
	fromLat: coord(data?.fromLat, -90, 90),
	fromLon: coord(data?.fromLon, -180, 180),
	toLat: coord(data?.toLat, -90, 90),
	toLon: coord(data?.toLon, -180, 180)
})).handler(routeDrive_createServerFn_handler, async ({ data }) => {
	try {
		const route = (await getJson(`https://router.project-osrm.org/route/v1/driving/${data.fromLon},${data.fromLat};${data.toLon},${data.toLat}?overview=full&geometries=geojson`)).routes?.[0];
		if (!route?.geometry || route.geometry.type !== "LineString" || !Array.isArray(route.geometry.coordinates)) return {
			ok: false,
			error: "No hay ruta en coche entre estos puntos."
		};
		return {
			ok: true,
			route: {
				distanceM: route.distance ?? 0,
				durationS: route.duration ?? 0,
				geometry: route.geometry
			}
		};
	} catch {
		return {
			ok: false,
			error: "El cálculo de ruta no respondió."
		};
	}
});
var searchTracks_createServerFn_handler = createServerRpc({
	id: "0ad72f5bddc25d137ded1e9e691f78a500bca26251501e2d6524f75a21895c67",
	name: "searchTracks",
	filename: "src/lib/aether-api.ts"
}, (opts) => searchTracks.__executeServer(opts));
var searchTracks = createServerFn({ method: "GET" }).validator((data) => ({ q: clampQuery(data?.q) })).handler(searchTracks_createServerFn_handler, async ({ data }) => {
	for (const host of PIPED) try {
		const json = await getJson(`${host}/search?q=${encodeURIComponent(data.q)}&filter=music_songs`);
		if (!Array.isArray(json.items)) continue;
		const tracks = [];
		for (const item of json.items) {
			if (!item || typeof item !== "object") continue;
			const record = item;
			if (record.type !== "stream" || typeof record.url !== "string" || typeof record.title !== "string") continue;
			const id = new URL(record.url, "https://example.com").searchParams.get("v");
			if (!id) continue;
			tracks.push({
				id,
				title: record.title,
				author: typeof record.uploaderName === "string" ? record.uploaderName : "YouTube",
				duration: typeof record.duration === "number" ? record.duration : 0
			});
			if (tracks.length >= 12) break;
		}
		if (tracks.length > 0) return {
			ok: true,
			tracks
		};
	} catch {
		continue;
	}
	return {
		ok: false,
		error: "YouTube Music no respondió. Prueba de nuevo o abre el enlace directo."
	};
});
//#endregion
export { reversePlace_createServerFn_handler, routeDrive_createServerFn_handler, searchPlaces_createServerFn_handler, searchTracks_createServerFn_handler };
