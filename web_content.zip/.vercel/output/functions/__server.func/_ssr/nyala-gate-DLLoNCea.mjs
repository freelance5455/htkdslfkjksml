import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { B as string, I as number, L as object, O as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { a as hasGateSessionMarker, t as GROK_PROVIDERS } from "./server-CbrWqPG3.mjs";
import { _ as Flower2, a as Swords, b as ArrowLeft, c as Send, d as Pin, f as MonitorUp, g as Gift, h as Heart, l as Rocket, m as MicOff, n as VideoOff, o as SwitchCamera, p as Mic, r as Users, s as Sparkles, t as Video, u as Radio, v as Flame, y as Crown } from "../_libs/lucide-react.mjs";
import { i as signOut, r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
import { c as makePeerId, i as authMiddleware, n as GIFTS, r as TOPICS, t as FILTERS } from "./ids-CYIMMUy6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nyala-gate-DLLoNCea.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
function friendly(message, fallback) {
	const text = message ?? "";
	if (/already exists/i.test(text)) return "Email ini sudah terdaftar. Masuk saja.";
	if (/invalid email/i.test(text)) return "Email tidak valid.";
	if (/too short|password/i.test(text)) return "Kata sandi minimal 8 karakter.";
	if (/invalid email or password|invalid credentials/i.test(text)) return "Email atau kata sandi salah.";
	return text || fallback;
}
function AuthPanel({ next }) {
	const [mode, setMode] = (0, import_react.useState)("daftar");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setError("");
		if (password.length < 8) {
			setError("Kata sandi minimal 8 karakter.");
			return;
		}
		setBusy(true);
		try {
			if (mode === "daftar") {
				if (name.trim().length < 2) {
					setError("Nama minimal 2 huruf.");
					setBusy(false);
					return;
				}
				const result = await authClient.signUp.email({
					email: email.trim(),
					password,
					name: name.trim()
				});
				if (result.error) setError(friendly(result.error.message, "Daftar gagal."));
			} else {
				const result = await authClient.signIn.email({
					email: email.trim(),
					password
				});
				if (result.error) setError(friendly(result.error.message, "Masuk gagal."));
			}
		} catch {
			setError("Server masuk sedang tidak menjawab.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-sm rounded-3xl border border-line bg-stage p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 rounded-full bg-ink p-1",
				children: ["daftar", "masuk"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setMode(item);
						setError("");
					},
					className: mode === item ? "h-11 rounded-full bg-cream text-sm font-semibold text-ink" : "h-11 rounded-full text-sm font-semibold text-mute",
					children: item === "daftar" ? "Daftar" : "Masuk"
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (event) => void submit(event),
				className: "mt-4 space-y-3",
				children: [
					mode === "daftar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-mute",
						children: ["Nama panggung", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (event) => setName(event.target.value),
							autoComplete: "nickname",
							maxLength: 32,
							className: "mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none focus-visible:outline-2 focus-visible:outline-brass"
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-mute",
						children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							value: email,
							onChange: (event) => setEmail(event.target.value),
							autoComplete: "email",
							required: true,
							className: "mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none focus-visible:outline-2 focus-visible:outline-brass"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-mute",
						children: ["Kata sandi", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							value: password,
							onChange: (event) => setPassword(event.target.value),
							autoComplete: mode === "daftar" ? "new-password" : "current-password",
							required: true,
							minLength: 8,
							className: "mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none focus-visible:outline-2 focus-visible:outline-brass"
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ember",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: busy,
						className: "h-12 w-full rounded-full bg-ember text-sm font-semibold text-cream disabled:opacity-60",
						children: busy ? "Sebentar…" : mode === "daftar" ? "Buat akun & masuk" : "Masuk"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "my-4 text-center text-xs tracking-wide text-mute",
				children: "atau lanjut dengan"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => signIn(provider.providerId, { callbackURL: next }),
					className: "h-12 w-full rounded-full border border-line bg-panel text-sm font-semibold text-cream",
					children: ["Lanjut dengan ", provider.label]
				}, provider.providerId))
			})
		]
	});
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var peerIdSchema = string().regex(/^[a-zA-Z0-9_-]{1,64}$/);
var hintSchema = object({ displayName: string().max(80).optional() });
var lobbyState = createServerFn({ method: "POST" }).validator((input) => hintSchema.parse(input ?? {})).middleware([authMiddleware]).handler(createSsrRpc("1857cf39fef8195636a677f3ed98c904fe4346da275e6b4405e9d15003bcca32"));
var profileSchema = object({
	displayName: string().max(80),
	bio: string().max(400)
});
var saveProfile = createServerFn({ method: "POST" }).validator((input) => profileSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("ea1fe0e18872284f64518730be508cc99827dd456e333b29feb280cf42b511cd"));
var claimDaily = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("c8e0806ce9b2a948a9cff2134d37f03e7475379d6a93896f087464b23abb1220"));
var cashOut = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("58f789622eba1ff4fc719a7e2f9ac07c55b0ee859f6c7f332a790050e8a54dc6"));
var createSchema = object({
	title: string().max(200),
	topic: string().max(40),
	mode: _enum(["video", "voice"])
});
var createRoom = createServerFn({ method: "POST" }).validator((input) => createSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("81050f335a97708ab78d0c5ea575590a9d81a5be60d8be495c4f4b94efb02635"));
var roomSchema = object({ roomId: string().regex(/^[a-z0-9]{4,12}$/) });
var endRoom = createServerFn({ method: "POST" }).validator((input) => roomSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("08a0d39ec48d97ae1898f6d9562facded7a78a24eb72ae8bf86accb0ae844ff9"));
var pulseSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	afterId: number().int().min(0).max(1e9),
	peerId: peerIdSchema,
	displayName: string().max(80).optional()
});
var pulseRoom = createServerFn({ method: "POST" }).validator((input) => pulseSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("bdc354fee66346cc9cd17f1992b90a6574de9cc043c9e12a06d7768f98c95214"));
var chatSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	body: string().max(500)
});
var sendChat = createServerFn({ method: "POST" }).validator((input) => chatSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("41a6dfb39dd82316e96658b150eb945629f275d86aeb7b4df7ac271379ab982f"));
var pinSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	text: string().max(300)
});
var pinNote = createServerFn({ method: "POST" }).validator((input) => pinSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("478ff23a04d4f595517fa6bdf6b34cd0c9ceb95dede77cdc6a348b7739e1f532"));
var heartSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	count: number().int().min(1).max(20)
});
var addHearts = createServerFn({ method: "POST" }).validator((input) => heartSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("43eff0ba91e333764e74cefd481849fac6c9406107fec0b77ec99d05cb6783ba"));
var giftSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	giftId: string().max(24)
});
var sendGift = createServerFn({ method: "POST" }).validator((input) => giftSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("c0353ff57305e06427917b0f4473c5eb1cc89e91a8c2d1476987cfe96e4cc329"));
var followSchema = object({ hostId: string().min(1).max(80) });
var toggleFollow = createServerFn({ method: "POST" }).validator((input) => followSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("257901b049235494144122b1eb988d48d5f5a52615858b2f70117d62dae264c3"));
var startBattle = createServerFn({ method: "POST" }).validator((input) => roomSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("3b9ab1cc033ef4ac947607d47d147afd120e53d7bbd78ed1d5632a7c62073910"));
var joinBattleSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	code: string().max(12)
});
var joinBattle = createServerFn({ method: "POST" }).validator((input) => joinBattleSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("ecdd288ba5812d34e1b04b88ddc4e71030bc304615f4b8c81c3dec1bf9567aa1"));
function RoomGrid({ rooms, mine, empty, onOpen }) {
	if (!rooms.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border border-dashed border-line px-4 py-8 text-center text-sm text-mute",
		children: empty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-3 sm:grid-cols-2",
		children: rooms.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onOpen(room.id),
			className: "w-full rounded-2xl border border-line bg-stage p-4 text-left",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2 text-xs font-semibold tracking-wide text-ember",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "live-dot size-2 rounded-full bg-ember",
							"aria-hidden": "true"
						}), "LANGSUNG"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-mute",
						children: room.mode === "voice" ? "Suara" : "Video"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display text-2xl leading-tight",
					children: room.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-cream",
					children: [room.hostName, room.hostId === mine ? " · panggungmu" : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 flex flex-wrap gap-3 text-xs text-mute",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: room.topic }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 tabular-nums",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), room.viewers]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 tabular-nums",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), room.hearts]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-brass",
							children: [room.giftsValue, " koin"]
						})
					]
				})
			]
		}) }, room.id))
	});
}
function Lobby({ userId, hintName }) {
	const navigate = useNavigate();
	const [tab, setTab] = (0, import_react.useState)("siaran");
	const [data, setData] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [composer, setComposer] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	const [topic, setTopic] = (0, import_react.useState)("Ngobrol");
	const [mode, setMode] = (0, import_react.useState)("video");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [profileOpen, setProfileOpen] = (0, import_react.useState)(false);
	const [draftName, setDraftName] = (0, import_react.useState)("");
	const [draftBio, setDraftBio] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let stop = false;
		const load = async () => {
			try {
				const result = await lobbyState({ data: { displayName: hintName } });
				if (stop || !result.ok) return;
				setData(result.data);
				setError("");
			} catch {
				if (!stop) setError("Server awan belum menjawab. Coba lagi sebentar.");
			}
		};
		load();
		const timer = setInterval(() => void load(), 4e3);
		return () => {
			stop = true;
			clearInterval(timer);
		};
	}, [hintName]);
	function openProfile() {
		setDraftName(data?.me.displayName ?? "");
		setDraftBio(data?.me.bio ?? "");
		setProfileOpen(true);
	}
	async function goLive() {
		setBusy(true);
		setError("");
		try {
			const result = await createRoom({ data: {
				title,
				topic,
				mode
			} });
			if (!result.ok) {
				setError(result.error);
				setBusy(false);
				return;
			}
			await navigate({
				to: "/s/$roomId",
				params: { roomId: result.data.id }
			});
		} catch {
			setError("Gagal membuka siaran.");
			setBusy(false);
		}
	}
	async function runWallet(action) {
		const result = await action();
		if (!result.ok) {
			setError(result.error);
			return;
		}
		setData((current) => current ? {
			...current,
			me: result.data
		} : current);
		setError("");
	}
	const rooms = tab === "ikuti" ? data?.following ?? [] : tab === "papan" ? data?.board ?? [] : data?.live ?? [];
	const empty = tab === "ikuti" ? "Belum ada yang kamu ikuti sedang siaran." : tab === "papan" ? "Papan masih sepi. Hadiah di panggung yang mengisi urutan ini." : "Belum ada siaran. Jadilah yang pertama menyalakan panggung.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh bg-ink text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl leading-none",
					children: "NYALA"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-mute",
					children: "Server awan aktif · data bukan di perangkat ini"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: openProfile,
						className: "h-11 rounded-full bg-panel px-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-mute",
							children: "Koin"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-semibold tabular-nums text-brass",
							children: data?.me.coins ?? "…"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-full bg-cream px-2 py-1 text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 pb-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: [
								["siaran", "Siaran"],
								["ikuti", "Diikuti"],
								["papan", "Terpanas"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setTab(id),
								className: tab === id ? "h-11 rounded-full bg-cream px-4 text-sm font-semibold text-ink" : "h-11 rounded-full px-4 text-sm font-semibold text-mute",
								children: label
							}, id))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setComposer(true),
							className: "inline-flex h-12 items-center gap-2 rounded-full bg-ember px-5 text-sm font-semibold text-cream",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Mulai siaran"]
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-ember",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomGrid, {
							rooms,
							mine: userId,
							empty,
							onOpen: (id) => void navigate({
								to: "/s/$roomId",
								params: { roomId: id }
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-mute",
							children: "Mengambil daftar siaran dari server…"
						})
					})
				]
			}),
			composer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-20 grid place-items-end bg-ink/80 p-4 sm:place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-3xl border border-line bg-stage p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: "Nyalakan panggung"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-mute",
							children: "Kamera diminta setelah ruang tercipta di server."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-sm text-mute",
							children: ["Judul", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: title,
								onChange: (event) => setTitle(event.target.value),
								maxLength: 60,
								placeholder: "Ngobrol santai malam ini",
								className: "mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: TOPICS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setTopic(item),
								className: topic === item ? "h-10 rounded-full bg-brass px-3 text-sm font-semibold text-ink" : "h-10 rounded-full border border-line px-3 text-sm text-cream",
								children: item
							}, item))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid grid-cols-2 gap-2",
							children: ["video", "voice"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMode(item),
								className: mode === item ? "h-11 rounded-2xl bg-cream text-sm font-semibold text-ink" : "h-11 rounded-2xl border border-line text-sm text-mute",
								children: item === "video" ? "Video" : "Suara saja"
							}, item))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setComposer(false),
								className: "h-12 flex-1 rounded-full border border-line text-sm",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy,
								onClick: () => void goLive(),
								className: "h-12 flex-1 rounded-full bg-ember text-sm font-semibold text-cream disabled:opacity-60",
								children: busy ? "Membuka…" : "Siaran sekarang"
							})]
						})
					]
				})
			}) : null,
			profileOpen && data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-20 grid place-items-end bg-ink/80 p-4 sm:place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-3xl border border-line bg-stage p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: "Profil"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm tabular-nums text-mute",
							children: [
								data.me.followers,
								" pengikut · ",
								data.me.following,
								" mengikuti · hasil ",
								data.me.earned
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-sm text-mute",
							children: ["Nama", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draftName,
								onChange: (event) => setDraftName(event.target.value),
								maxLength: 32,
								className: "mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-sm text-mute",
							children: ["Bio", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: draftBio,
								onChange: (event) => setDraftBio(event.target.value),
								maxLength: 140,
								rows: 3,
								className: "mt-1 w-full rounded-2xl border border-line bg-ink px-3 py-2 text-base text-cream outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => void runWallet(async () => {
										return await saveProfile({ data: {
											displayName: draftName,
											bio: draftBio
										} });
									}),
									className: "h-11 rounded-full bg-cream text-sm font-semibold text-ink",
									children: "Simpan profil"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: data.me.claimedToday,
									onClick: () => void runWallet(() => claimDaily()),
									className: "h-11 rounded-full border border-line text-sm font-semibold disabled:opacity-50",
									children: data.me.claimedToday ? "Koin harian sudah diambil" : "Ambil 120 koin harian"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: data.me.earned <= 0,
									onClick: () => void runWallet(() => cashOut()),
									className: "h-11 rounded-full border border-brass text-sm font-semibold text-brass disabled:opacity-50",
									children: "Tukar hasil ke koin"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setProfileOpen(false),
									className: "h-11 text-sm text-mute",
									children: "Tutup"
								})
							]
						})
					]
				})
			}) : null
		]
	});
}
function defaultIceServers() {
	return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
}
/**
* Star WebRTC: the host offers camera/mic to each viewer. Chat and gifts do
* not travel here — they go through the cloud database so they still work
* when a network blocks peer video.
*/
var StageLink = class {
	opts;
	peers = /* @__PURE__ */ new Map();
	cursor = 0;
	closed = false;
	timer = null;
	local;
	constructor(opts) {
		this.opts = opts;
		this.local = opts.localStream;
	}
	setName(name) {
		this.opts.name = name.slice(0, 64);
	}
	async start() {
		await this.poll();
	}
	stop() {
		this.closed = true;
		if (this.timer) clearTimeout(this.timer);
		for (const slot of this.peers.values()) slot.pc.close();
		this.peers.clear();
		fetch("/api/rtc", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "leave",
				room: this.opts.room,
				peer: this.opts.selfId
			}),
			keepalive: true
		}).catch(() => {});
	}
	replaceStream(stream) {
		this.local = stream;
		for (const slot of this.peers.values()) this.attachLocal(slot.pc, stream);
	}
	attachLocal(pc, stream) {
		for (const track of stream.getTracks()) {
			const sender = pc.getSenders().find((item) => item.track?.kind === track.kind);
			if (sender) sender.replaceTrack(track);
			else pc.addTrack(track, stream);
		}
	}
	emit() {
		let connected = 0;
		for (const slot of this.peers.values()) if (slot.pc.connectionState === "connected") connected += 1;
		const state = connected > 0 ? "connected" : this.peers.size > 0 ? "connecting" : "idle";
		this.opts.onState(state);
	}
	schedule(ms) {
		if (this.closed) return;
		if (this.timer) clearTimeout(this.timer);
		this.timer = setTimeout(() => void this.poll(), ms);
	}
	async poll() {
		if (this.closed) return;
		let hurry = false;
		try {
			const params = new URLSearchParams({
				room: this.opts.room,
				peer: this.opts.selfId,
				name: this.opts.name.slice(0, 64),
				since: String(this.cursor)
			});
			const res = await fetch(`/api/rtc?${params.toString()}`);
			if (!res.ok) throw new Error(String(res.status));
			const body = await res.json();
			if (this.closed) return;
			const alive = new Set(body.peers.map((peer) => peer.id));
			if (this.opts.role === "host") {
				let offered = 0;
				for (const peer of body.peers) {
					if (peer.id === this.opts.selfId) continue;
					offered += 1;
					if (offered > 8) break;
					if (!this.peers.has(peer.id)) this.dial(peer.id, true);
				}
			}
			for (const [id, slot] of this.peers) if (!alive.has(id)) {
				slot.pc.close();
				this.peers.delete(id);
				if (this.opts.role === "viewer") this.opts.onRemote(null);
			}
			for (const signal of body.signals) {
				this.cursor = Math.max(this.cursor, signal.id);
				await this.onSignal(signal.from, signal.kind, signal.payload);
				if (this.closed) return;
			}
			this.emit();
			hurry = [...this.peers.values()].some((slot) => slot.pc.connectionState !== "connected");
		} catch {
			hurry = true;
		}
		this.schedule(hurry ? 400 : 1600);
	}
	dial(peerId, initiator) {
		if (this.peers.has(peerId) || this.closed) return;
		const pc = new RTCPeerConnection({ iceServers: defaultIceServers() });
		const slot = {
			pc,
			pending: [],
			remoteSet: false,
			making: false
		};
		this.peers.set(peerId, slot);
		pc.onicecandidate = (event) => {
			if (event.candidate) this.signal(peerId, "ice", event.candidate.toJSON());
		};
		pc.onconnectionstatechange = () => {
			this.emit();
			if (pc.connectionState === "failed") pc.restartIce();
		};
		pc.ontrack = (event) => {
			if (this.opts.role !== "viewer") return;
			const stream = event.streams[0] ?? new MediaStream([event.track]);
			this.opts.onRemote(stream);
		};
		pc.onnegotiationneeded = () => {
			if (!initiator) return;
			this.offer(peerId, slot);
		};
		if (this.local) this.attachLocal(pc, this.local);
		else if (initiator) pc.createDataChannel("meta");
	}
	async offer(peerId, slot) {
		try {
			slot.making = true;
			const desc = await slot.pc.createOffer();
			if (this.closed) return;
			await slot.pc.setLocalDescription(desc);
			await this.signal(peerId, "offer", slot.pc.localDescription?.toJSON());
		} catch {} finally {
			slot.making = false;
		}
	}
	async onSignal(from, kind, payload) {
		if (from === this.opts.selfId) return;
		if (this.opts.role === "viewer" && from !== this.opts.hostPeer) return;
		if (!this.peers.has(from)) this.dial(from, false);
		const slot = this.peers.get(from);
		if (!slot) return;
		if (kind === "ice") {
			const candidate = payload;
			if (!candidate || typeof candidate !== "object") return;
			if (!slot.remoteSet) slot.pending.push(candidate);
			else try {
				await slot.pc.addIceCandidate(candidate);
			} catch {}
			return;
		}
		const desc = payload;
		if (!desc || typeof desc !== "object" || typeof desc.type !== "string") return;
		if (kind === "offer") {
			if (slot.making) return;
			await slot.pc.setRemoteDescription(desc);
			slot.remoteSet = true;
			await this.flush(slot);
			const answer = await slot.pc.createAnswer();
			await slot.pc.setLocalDescription(answer);
			await this.signal(from, "answer", slot.pc.localDescription?.toJSON());
			return;
		}
		await slot.pc.setRemoteDescription(desc);
		slot.remoteSet = true;
		await this.flush(slot);
	}
	async flush(slot) {
		while (slot.pending.length > 0) {
			const candidate = slot.pending.shift();
			if (!candidate) break;
			try {
				await slot.pc.addIceCandidate(candidate);
			} catch {}
		}
	}
	async signal(to, kind, payload) {
		if (!payload) return;
		await fetch("/api/rtc", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "signal",
				room: this.opts.room,
				from: this.opts.selfId,
				to,
				kind,
				payload
			})
		}).catch(() => {});
	}
};
function ink() {
	if (typeof document === "undefined") return "#14110f";
	return getComputedStyle(document.documentElement).getPropertyValue("--color-ink").trim() || "#14110f";
}
function useLens(opts) {
	const videoRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const onStream = (0, import_react.useRef)(opts.onStream);
	const filterRef = (0, import_react.useRef)(opts.filterId);
	const facingRef = (0, import_react.useRef)(opts.facing);
	const screenRef = (0, import_react.useRef)(opts.screenStream);
	onStream.current = opts.onStream;
	filterRef.current = opts.filterId;
	facingRef.current = opts.facing;
	screenRef.current = opts.screenStream;
	const paintedRef = (0, import_react.useRef)(null);
	const [cam, setCam] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!opts.enabled) return;
		let dead = false;
		let stream = null;
		setError(null);
		navigator.mediaDevices.getUserMedia({
			audio: {
				echoCancellation: true,
				noiseSuppression: true
			},
			video: {
				facingMode: opts.facing,
				width: { ideal: 1280 },
				height: { ideal: 720 }
			}
		}).then((next) => {
			if (dead) {
				next.getTracks().forEach((track) => track.stop());
				return;
			}
			stream = next;
			setCam(next);
		}).catch(() => {
			if (!dead) setError("Kamera atau mikrofon ditolak. Izinkan akses, lalu coba lagi.");
		});
		return () => {
			dead = true;
			stream?.getTracks().forEach((track) => track.stop());
			setCam(null);
		};
	}, [
		opts.enabled,
		opts.facing,
		opts.nonce
	]);
	(0, import_react.useEffect)(() => {
		if (!cam || !opts.enabled) return;
		const video = videoRef.current;
		const canvas = canvasRef.current;
		if (!video || !canvas) return;
		video.srcObject = cam;
		video.play().catch(() => {});
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		const draw = () => {
			const w = 640;
			const h = 480;
			if (canvas.width !== w) canvas.width = w;
			if (canvas.height !== h) canvas.height = h;
			ctx.save();
			ctx.filter = "none";
			ctx.fillStyle = ink();
			ctx.fillRect(0, 0, w, h);
			const track = cam.getVideoTracks()[0];
			if (!screenRef.current && track?.enabled && video.readyState >= 2) {
				const filter = FILTERS.find((item) => item.id === filterRef.current)?.css ?? "none";
				ctx.filter = filter;
				if (facingRef.current === "user") {
					ctx.translate(w, 0);
					ctx.scale(-1, 1);
				}
				ctx.drawImage(video, 0, 0, w, h);
			}
			ctx.restore();
			raf = requestAnimationFrame(draw);
		};
		draw();
		const painted = canvas.captureStream(24);
		paintedRef.current = painted;
		const audio = cam.getAudioTracks()[0];
		if (audio) painted.addTrack(audio);
		if (!screenRef.current) onStream.current(painted);
		return () => {
			cancelAnimationFrame(raf);
			painted.getVideoTracks().forEach((track) => track.stop());
		};
	}, [cam, opts.enabled]);
	(0, import_react.useEffect)(() => {
		if (!opts.enabled) return;
		if (!opts.screenStream) {
			if (paintedRef.current) onStream.current(paintedRef.current);
			return;
		}
		const mixed = new MediaStream();
		const video = opts.screenStream.getVideoTracks()[0];
		if (video) mixed.addTrack(video);
		const audio = cam?.getAudioTracks()[0];
		if (audio) mixed.addTrack(audio);
		onStream.current(mixed);
	}, [
		opts.screenStream,
		opts.enabled,
		cam
	]);
	return {
		videoRef,
		canvasRef,
		cam,
		error
	};
}
var GIFT_ICONS = {
	flame: Flame,
	flower: Flower2,
	crown: Crown,
	rocket: Rocket,
	spark: Sparkles
};
function mergeLines(prev, incoming) {
	const map = new Map(prev.map((line) => [line.id, line]));
	for (const line of incoming) map.set(line.id, line);
	return [...map.values()].sort((a, b) => a.id - b.id).slice(-80);
}
function Wave({ stream }) {
	const [levels, setLevels] = (0, import_react.useState)(() => Array.from({ length: 12 }, () => 8));
	(0, import_react.useEffect)(() => {
		const audio = stream?.getAudioTracks()[0];
		if (!stream || !audio) return;
		const ctx = new AudioContext();
		const source = ctx.createMediaStreamSource(stream);
		const analyser = ctx.createAnalyser();
		analyser.fftSize = 64;
		source.connect(analyser);
		const bins = new Uint8Array(analyser.frequencyBinCount);
		let raf = 0;
		const tick = () => {
			analyser.getByteFrequencyData(bins);
			setLevels(Array.from(bins.slice(2, 14), (value) => Math.max(8, Math.round(value / 255 * 100))));
			raf = requestAnimationFrame(tick);
		};
		ctx.resume().then(tick).catch(() => {});
		return () => {
			cancelAnimationFrame(raf);
			ctx.close();
		};
	}, [stream]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-36 items-end justify-center gap-1.5",
		"aria-hidden": "true",
		children: levels.map((level, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "w-2 rounded-full bg-brass",
			style: { height: `${level}%` }
		}, index))
	});
}
function Stage({ roomId, userId, hintName }) {
	const navigate = useNavigate();
	const peerId = (0, import_react.useMemo)(() => makePeerId(), []);
	const linkRef = (0, import_react.useRef)(null);
	const afterRef = (0, import_react.useRef)(0);
	const sentHearts = (0, import_react.useRef)(0);
	const heartSeen = (0, import_react.useRef)(null);
	const heartQueue = (0, import_react.useRef)(0);
	const scroller = (0, import_react.useRef)(null);
	const [room, setRoom] = (0, import_react.useState)(null);
	const [missing, setMissing] = (0, import_react.useState)(false);
	const [wallet, setWallet] = (0, import_react.useState)(null);
	const [following, setFollowing] = (0, import_react.useState)(false);
	const [lines, setLines] = (0, import_react.useState)([]);
	const [battle, setBattle] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [hearts, setHearts] = (0, import_react.useState)([]);
	const [giftPop, setGiftPop] = (0, import_react.useState)(null);
	const [linkState, setLinkState] = (0, import_react.useState)("idle");
	const [blocked, setBlocked] = (0, import_react.useState)(false);
	const [remote, setRemote] = (0, import_react.useState)(null);
	const [needTap, setNeedTap] = (0, import_react.useState)(false);
	const [facing, setFacing] = (0, import_react.useState)("user");
	const [filterId, setFilterId] = (0, import_react.useState)("jernih");
	const [nonce, setNonce] = (0, import_react.useState)(0);
	const [screenStream, setScreenStream] = (0, import_react.useState)(null);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [camOff, setCamOff] = (0, import_react.useState)(false);
	const [voice, setVoice] = (0, import_react.useState)(null);
	const [duelCode, setDuelCode] = (0, import_react.useState)("");
	const remoteRef = (0, import_react.useRef)(null);
	const seenGifts = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const isHost = room?.hostId === userId;
	const live = Boolean(room?.live);
	const videoHost = Boolean(isHost && live && room?.mode === "video");
	const publish = (stream) => {
		const name = wallet?.displayName || hintName || "Nyala";
		if (!linkRef.current) {
			const link = new StageLink({
				room: roomId,
				selfId: peerId,
				name,
				role: "host",
				hostPeer: peerId,
				localStream: stream,
				onRemote: () => {},
				onState: setLinkState
			});
			linkRef.current = link;
			link.start();
		} else linkRef.current.replaceStream(stream);
	};
	const publishRef = (0, import_react.useRef)(publish);
	publishRef.current = publish;
	const lens = useLens({
		enabled: videoHost,
		facing,
		filterId,
		nonce,
		screenStream,
		onStream: (stream) => publishRef.current(stream)
	});
	(0, import_react.useEffect)(() => {
		const timer = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		let stop = false;
		const tick = async () => {
			try {
				const result = await pulseRoom({ data: {
					roomId,
					afterId: afterRef.current,
					peerId,
					displayName: hintName
				} });
				if (stop || !result.ok) return;
				setWallet(result.data.me);
				setFollowing(result.data.following);
				setBattle(result.data.battle);
				if (!result.data.room) {
					setMissing(true);
					setRoom(null);
					return;
				}
				setMissing(false);
				setRoom(result.data.room);
				if (result.data.messages.length) {
					afterRef.current = result.data.messages[result.data.messages.length - 1]?.id ?? afterRef.current;
					setLines((prev) => mergeLines(prev, result.data.messages));
				}
				setError("");
			} catch {
				if (!stop) setError("Putus dari server awan. Mencoba lagi…");
			}
		};
		tick();
		const timer = setInterval(() => void tick(), 2e3);
		return () => {
			stop = true;
			clearInterval(timer);
		};
	}, [
		roomId,
		peerId,
		hintName
	]);
	(0, import_react.useEffect)(() => {
		if (!room || isHost || !live || !room.hostPeer) return;
		const link = new StageLink({
			room: roomId,
			selfId: peerId,
			name: wallet?.displayName || hintName || "Penonton",
			role: "viewer",
			hostPeer: room.hostPeer,
			localStream: null,
			onRemote: setRemote,
			onState: setLinkState
		});
		linkRef.current = link;
		link.start();
		return () => {
			link.stop();
			if (linkRef.current === link) linkRef.current = null;
			setRemote(null);
		};
	}, [
		isHost,
		live,
		room?.hostPeer,
		roomId,
		peerId,
		hintName
	]);
	(0, import_react.useEffect)(() => {
		if (!isHost || room?.mode !== "voice" || !live) return;
		let dead = false;
		let stream = null;
		navigator.mediaDevices.getUserMedia({
			audio: {
				echoCancellation: true,
				noiseSuppression: true
			},
			video: false
		}).then((next) => {
			if (dead) {
				next.getTracks().forEach((track) => track.stop());
				return;
			}
			stream = next;
			setVoice(next);
			publishRef.current(next);
		}).catch(() => setError("Mikrofon ditolak."));
		return () => {
			dead = true;
			stream?.getTracks().forEach((track) => track.stop());
			setVoice(null);
		};
	}, [
		isHost,
		room?.mode,
		live
	]);
	(0, import_react.useEffect)(() => {
		return () => {
			linkRef.current?.stop();
			screenStream?.getTracks().forEach((track) => track.stop());
		};
	}, []);
	(0, import_react.useEffect)(() => {
		linkRef.current?.setName(wallet?.displayName || hintName || "Nyala");
	}, [wallet?.displayName, hintName]);
	(0, import_react.useEffect)(() => {
		const audio = lens.cam?.getAudioTracks()[0];
		if (audio) audio.enabled = !muted;
		const mic = voice?.getAudioTracks()[0];
		if (mic) mic.enabled = !muted;
	}, [
		muted,
		lens.cam,
		voice
	]);
	(0, import_react.useEffect)(() => {
		const video = lens.cam?.getVideoTracks()[0];
		if (video) video.enabled = !camOff;
	}, [camOff, lens.cam]);
	(0, import_react.useEffect)(() => {
		const el = remoteRef.current;
		if (!el) return;
		el.srcObject = remote;
		if (!remote) return;
		el.play().then(() => setNeedTap(false)).catch(() => setNeedTap(true));
	}, [remote]);
	(0, import_react.useEffect)(() => {
		const node = scroller.current;
		if (node) node.scrollTop = node.scrollHeight;
	}, [lines.length]);
	(0, import_react.useEffect)(() => {
		const fresh = lines.filter((line) => line.kind === "gift" && !seenGifts.current.has(line.id));
		if (!fresh.length) return;
		const last = fresh[fresh.length - 1];
		if (!last) return;
		for (const line of fresh) seenGifts.current.add(line.id);
		const gift = GIFTS.find((item) => item.id === last.giftId);
		setGiftPop({
			id: last.id,
			name: last.body,
			from: last.name,
			icon: gift?.icon ?? "spark"
		});
		const timer = setTimeout(() => setGiftPop(null), 2400);
		return () => clearTimeout(timer);
	}, [lines]);
	(0, import_react.useEffect)(() => {
		if (!room) return;
		const delta = room.hearts;
		const mine = sentHearts.current;
		sentHearts.current = 0;
		const others = Math.max(0, delta - (heartSeen.current ?? delta) - mine);
		heartSeen.current = delta;
		if (others > 0) spawnHearts(Math.min(4, others));
	}, [room?.hearts]);
	function spawnHearts(count) {
		setHearts((prev) => {
			const next = [...prev];
			for (let i = 0; i < count; i += 1) next.push({
				id: Date.now() + i + Math.random(),
				x: 18 + Math.random() * 64
			});
			return next.slice(-14);
		});
	}
	function tapHeart() {
		if (!live) return;
		spawnHearts(1);
		heartQueue.current += 1;
		window.setTimeout(() => {
			const count = heartQueue.current;
			if (!count) return;
			heartQueue.current = 0;
			addHearts({ data: {
				roomId,
				count
			} }).then((result) => {
				if (result.ok) sentHearts.current += count;
			}).catch(() => {});
		}, 500);
	}
	async function submitChat() {
		const body = draft.trim();
		if (!body) return;
		setDraft("");
		try {
			const result = await sendChat({ data: {
				roomId,
				body
			} });
			if (!result.ok) {
				setError(result.error);
				setDraft(body);
				return;
			}
			afterRef.current = Math.max(afterRef.current, result.data.id);
			setLines((prev) => mergeLines(prev, [result.data]));
		} catch {
			setError("Pesan gagal terkirim.");
			setDraft(body);
		}
	}
	async function give(giftId) {
		try {
			const result = await sendGift({ data: {
				roomId,
				giftId
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setWallet(result.data.me);
			afterRef.current = Math.max(afterRef.current, result.data.message.id);
			setLines((prev) => mergeLines(prev, [result.data.message]));
			setError("");
		} catch {
			setError("Hadiah gagal terkirim.");
		}
	}
	async function shareScreen() {
		try {
			const next = await navigator.mediaDevices.getDisplayMedia({
				video: true,
				audio: false
			});
			next.getVideoTracks()[0]?.addEventListener("ended", () => setScreenStream(null), { once: true });
			setScreenStream((current) => {
				current?.getTracks().forEach((item) => item.stop());
				return next;
			});
		} catch {
			setError("Berbagi layar dibatalkan.");
		}
	}
	async function stopShow() {
		try {
			await endRoom({ data: { roomId } });
		} catch {}
		linkRef.current?.stop();
		await navigate({ to: "/" });
	}
	(0, import_react.useEffect)(() => {
		if (isHost || linkState === "connected" || !room?.hostPeer) {
			setBlocked(false);
			return;
		}
		const timer = setTimeout(() => setBlocked(true), 14e3);
		return () => clearTimeout(timer);
	}, [
		isHost,
		linkState,
		room?.hostPeer
	]);
	if (!room && !missing && !error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, { label: "Membuka panggung…" });
	if (missing || !room) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-ink px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Ruang tidak ada"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-mute",
				children: error || "Kode siaran ini tidak ditemukan di server."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void navigate({ to: "/" }),
				className: "mt-6 h-12 rounded-full bg-cream px-5 text-sm font-semibold text-ink",
				children: "Ke lobi"
			})
		] })
	});
	const PopIcon = giftPop ? GIFT_ICONS[giftPop.icon] : Sparkles;
	const remain = battle ? Math.max(0, battle.endsAt * 1e3 - now) : 0;
	const totalScore = (battle?.scoreA ?? 0) + (battle?.scoreB ?? 0);
	const leftPct = totalScore === 0 ? 50 : Math.round((battle?.scoreA ?? 0) / totalScore * 100);
	const status = !live ? "Siaran selesai" : isHost ? linkState === "connected" ? "Penonton tersambung langsung" : "Kamu sedang siaran" : linkState === "connected" ? room.mode === "voice" ? "Suara langsung tersambung" : "Gambar langsung tersambung" : blocked ? "Video tidak tembus dari jaringan ini. Obrolan dan hadiah tetap lewat server." : room.hostPeer ? "Menyambungkan siaran langsung…" : "Menunggu kreator menyalakan perangkat…";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-dvh flex-col bg-ink text-cream md:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-0 flex-1 bg-stage",
			children: [
				videoHost ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					ref: lens.videoRef,
					playsInline: true,
					muted: true,
					autoPlay: true,
					className: "pointer-events-none absolute size-px opacity-0"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: lens.canvasRef,
					className: "absolute inset-0 h-full w-full object-cover"
				})] }) : null,
				!isHost && room.mode === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					ref: remoteRef,
					playsInline: true,
					autoPlay: true,
					className: "absolute inset-0 h-full w-full object-cover"
				}) : null,
				room.mode === "voice" || !isHost && !remote && room.mode === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 grid place-items-center px-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-sm text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl",
							children: room.hostName.slice(0, 1).toUpperCase()
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wave, { stream: isHost ? voice : remote })
						})]
					})
				}) : null,
				screenStream && videoHost ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "absolute bottom-4 left-4 rounded-full bg-ink/80 px-3 py-1 text-xs",
					children: "Layar dibagikan"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "absolute inset-x-0 top-0 flex items-start justify-between gap-3 bg-gradient-to-b from-ink/80 to-transparent p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void navigate({ to: "/" }),
								className: "inline-flex h-11 items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Lobi"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate font-display text-2xl",
								children: room.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-sm text-cream",
								children: [room.hostName, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-mute",
									children: [" · ", room.topic]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 flex-col items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex h-9 items-center gap-2 rounded-full bg-ink/70 px-3 text-xs tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
									className: "size-3.5",
									"aria-hidden": "true"
								}),
								room.viewerCount,
								live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot size-2 rounded-full bg-ember" }) : null
							]
						}), !isHost && live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void toggleFollow({ data: { hostId: room.hostId } }).then((result) => {
								if (result.ok) setFollowing(result.data.following);
								else setError(result.error);
							}),
							className: "h-10 rounded-full bg-cream px-3 text-sm font-semibold text-ink",
							children: following ? "Mengikuti" : "Ikuti"
						}) : null]
					})]
				}),
				room.pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "absolute inset-x-3 top-28 flex items-start gap-2 rounded-2xl bg-ink/75 px-3 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, {
						className: "mt-0.5 size-4 shrink-0 text-brass",
						"aria-hidden": "true"
					}), room.pinned]
				}) : null,
				battle && remain > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-3 bottom-16 rounded-2xl bg-ink/80 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: battle.nameA }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums text-brass",
									children: [Math.ceil(remain / 1e3), " dtk"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: battle.nameB ?? "Menunggu lawan" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex h-2 overflow-hidden rounded-full bg-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "bg-ember",
								style: { width: `${leftPct}%` }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1 bg-brass" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-center text-xs tabular-nums",
							children: [
								battle.scoreA,
								" — ",
								battle.scoreB,
								isHost && !battle.roomB ? ` · kode ${battle.id}` : ""
							]
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "absolute inset-x-3 bottom-3 text-xs text-cream/90",
					children: lens.error || status
				}),
				hearts.map((heart) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "heart-float pointer-events-none absolute bottom-24 text-ember",
					style: { left: `${heart.x}%` },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
						className: "size-7 fill-ember",
						"aria-hidden": "true"
					})
				}, heart.id)),
				giftPop ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "gift-pop pointer-events-none absolute inset-0 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl bg-ink/85 px-6 py-5 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopIcon, {
								className: "mx-auto size-10 text-brass",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-3xl",
								children: giftPop.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-mute",
								children: giftPop.from
							})
						]
					})
				}) : null,
				needTap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void remoteRef.current?.play().then(() => setNeedTap(false)).catch(() => {}),
					className: "absolute bottom-16 left-1/2 h-11 -translate-x-1/2 rounded-full bg-cream px-4 text-sm font-semibold text-ink",
					children: "Ketuk untuk dengar"
				}) : null,
				live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: tapHeart,
					"aria-label": "Kirim hati",
					className: "absolute bottom-12 right-3 grid size-14 place-items-center rounded-full bg-ember text-cream",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-6 fill-cream" })
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "flex max-h-[48dvh] min-h-0 w-full flex-col border-line bg-ink md:h-dvh md:max-h-none md:w-96 md:border-l",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: scroller,
					role: "log",
					"aria-label": "Obrolan",
					className: "min-h-0 flex-1 space-y-2 overflow-y-auto px-3 py-3",
					children: lines.map((line) => line.kind === "system" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-mute",
						children: line.body
					}, line.id) : line.kind === "gift" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-brass",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: line.name
							}),
							" mengirim ",
							line.body
						]
					}, line.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-brass",
								children: line.name
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-cream",
								children: line.body
							})
						]
					}, line.id))
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 text-xs text-ember",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => {
						event.preventDefault();
						submitChat();
					},
					className: "flex gap-2 px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: draft,
						onChange: (event) => setDraft(event.target.value),
						disabled: !live,
						maxLength: 200,
						placeholder: live ? "Tulis pesan…" : "Siaran selesai",
						className: "h-12 min-w-0 flex-1 rounded-full border border-line bg-stage px-4 text-base outline-none"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: !live,
						"aria-label": "Kirim",
						className: "grid size-12 place-items-center rounded-full bg-cream text-ink disabled:opacity-40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex gap-2 overflow-x-auto px-3 pb-2",
					children: GIFTS.map((gift) => {
						const Icon = GIFT_ICONS[gift.icon];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !live,
							onClick: () => void give(gift.id),
							className: "flex h-16 w-24 shrink-0 flex-col items-center justify-center rounded-2xl border border-line bg-stage text-xs disabled:opacity-40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4 text-brass",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1",
									children: gift.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-mute",
									children: gift.coins
								})
							]
						}, gift.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 px-3 pb-2 text-xs text-mute",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								"Koin ",
								wallet?.coins ?? "…",
								" · hasil ",
								wallet?.earned ?? 0
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !wallet || wallet.earned <= 0,
							onClick: () => void cashOut().then((result) => {
								if (result.ok) setWallet(result.data);
								else setError(result.error);
							}),
							className: "h-8 rounded-full px-2 text-brass disabled:opacity-40",
							children: "Tukar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								navigator.clipboard.writeText(window.location.href).then(() => setCopied(true), () => setCopied(false));
							},
							className: "h-8 rounded-full px-2",
							children: copied ? "Tautan disalin" : "Salin tautan"
						})
					]
				}),
				isHost && live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 border-t border-line px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMuted((value) => !value),
									className: "grid size-11 place-items-center rounded-full bg-panel",
									"aria-label": muted ? "Hidupkan mic" : "Bisukan mic",
									children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
								}),
								room.mode === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setCamOff((value) => !value),
										className: "grid size-11 place-items-center rounded-full bg-panel",
										"aria-label": "Kamera",
										children: camOff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setFacing((value) => value === "user" ? "environment" : "user"),
										className: "grid size-11 place-items-center rounded-full bg-panel",
										"aria-label": "Balik kamera",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchCamera, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void shareScreen(),
										className: "grid size-11 place-items-center rounded-full bg-panel",
										"aria-label": "Bagikan layar",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonitorUp, { className: "size-4" })
									})
								] }) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => void stopShow(),
									className: "h-11 rounded-full bg-ember px-4 text-sm font-semibold",
									children: "Akhiri"
								})
							]
						}),
						room.mode === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 overflow-x-auto",
							children: [FILTERS.map((filter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setFilterId(filter.id),
								className: filterId === filter.id ? "h-9 shrink-0 rounded-full bg-brass px-3 text-xs font-semibold text-ink" : "h-9 shrink-0 rounded-full border border-line px-3 text-xs",
								children: filter.label
							}, filter.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setNonce((value) => value + 1),
								className: "h-9 shrink-0 rounded-full border border-line px-3 text-xs",
								children: "Ulangi kamera"
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => void startBattle({ data: { roomId } }).then((result) => {
										if (!result.ok) setError(result.error);
									}),
									className: "inline-flex h-10 items-center gap-1 rounded-full border border-line px-3 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swords, {
										className: "size-3.5",
										"aria-hidden": "true"
									}), "Duel 90 dtk"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: duelCode,
									onChange: (event) => setDuelCode(event.target.value),
									placeholder: "Kode lawan",
									className: "h-10 min-w-0 flex-1 rounded-full border border-line bg-stage px-3 text-sm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => void joinBattle({ data: {
										roomId,
										code: duelCode
									} }).then((result) => {
										if (!result.ok) setError(result.error);
									}),
									className: "h-10 rounded-full bg-panel px-3 text-xs",
									children: "Gabung"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "flex gap-2",
							onSubmit: (event) => {
								event.preventDefault();
								pinNote({ data: {
									roomId,
									text: note
								} }).then((result) => {
									if (!result.ok) setError(result.error);
									else setRoom((current) => current ? {
										...current,
										pinned: result.data.pinned
									} : current);
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: note,
								onChange: (event) => setNote(event.target.value),
								placeholder: "Sematkan pengumuman",
								maxLength: 120,
								className: "h-10 min-w-0 flex-1 rounded-full border border-line bg-stage px-3 text-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "h-10 rounded-full px-3 text-xs text-brass",
								children: "Sematkan"
							})]
						})
					]
				}) : null,
				!live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void navigate({ to: "/" }),
					className: "m-3 h-12 rounded-full bg-cream text-sm font-semibold text-ink",
					children: "Kembali ke lobi"
				}) : null
			]
		})]
	});
}
var FEATURES = [
	{
		icon: Radio,
		title: "Kamera langsung",
		body: "Depan, belakang, atau bagikan layar. Filter terlihat ke penonton."
	},
	{
		icon: Mic,
		title: "Ruang suara",
		body: "Siaran audio dengan gelombang dari mikrofonmu yang asli."
	},
	{
		icon: Heart,
		title: "Hati & obrolan",
		body: "Pesan dan hati tersimpan di server awan, bukan cuma di layar ini."
	},
	{
		icon: Gift,
		title: "Hadiah & koin",
		body: "Kirim hadiah, koin berkurang, hasil kreator bertambah, lalu bisa ditukar."
	},
	{
		icon: Swords,
		title: "Duel 90 detik",
		body: "Buka kode duel. Skor naik dari hadiah sungguhan, bukan angka palsu."
	},
	{
		icon: MonitorUp,
		title: "Penonton jarak jauh",
		body: "Gambar antar perangkat lewat sambungan langsung. Obrolan tetap lewat server."
	}
];
function Splash({ label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-ink px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-5xl text-cream",
				children: "NYALA"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-mute",
				children: label
			})]
		})
	});
}
function NyalaGate({ roomId }) {
	const { user, isPending } = useCurrentUserState();
	const next = roomId ? `/s/${roomId}` : "/";
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, { label: "Menyalakan panggung…" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-dvh bg-ink text-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-5xl gap-10 px-5 py-10 md:grid-cols-[1.1fr_0.9fr] md:items-center md:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.22em] text-brass",
					children: "SIARAN LANGSUNG"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-5xl leading-none text-cream md:text-6xl",
					children: "NYALA"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-lg text-cream",
					children: "Panggung yang benar-benar hidup. Kamera, suara, obrolan, hadiah, dan duel."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-md text-sm text-mute",
					children: "Koin, pesan, dan daftar siaran disimpan di server awan — bukan di komputer kamu. Gambar penonton mengalir langsung antar perangkat."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 grid gap-3 sm:grid-cols-2",
					children: FEATURES.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-line bg-stage p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(feature.icon, {
								className: "size-5 text-brass",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-semibold",
								children: feature.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-mute",
								children: feature.body
							})
						]
					}, feature.title))
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "md:justify-self-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPanel, { next })
			})]
		})
	});
	if (roomId) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stage, {
		roomId,
		userId: user.id,
		hintName: user.displayName ?? ""
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lobby, {
		userId: user.id,
		hintName: user.displayName ?? ""
	});
}
//#endregion
export { useCurrentUserState as i, NyalaGate as n, Splash as r, AuthPanel as t };
