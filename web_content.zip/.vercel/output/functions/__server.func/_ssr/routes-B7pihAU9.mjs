import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as Menu, i as Square, l as ArrowUp, n as Volume2, o as Mic, s as MicOff, t as X } from "../_libs/lucide-react.mjs";
import { n as previewPathPrefix } from "./router-dQtX0wis.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B7pihAU9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Preview hosts serve the app under a path prefix. Absolute fetches must keep it. */
function apiUrl(path) {
	if (typeof window === "undefined") return path;
	return `${previewPathPrefix(window.location.hostname, window.location.pathname) ?? ""}${path}`;
}
var WAKE = /\bcharlie\b/i;
var SILENCE_MS = 1100;
var MAX_HEARING_MS = 12e3;
function speechCtor() {
	if (typeof window === "undefined") return null;
	const host = window;
	return host.SpeechRecognition ?? host.webkitSpeechRecognition ?? null;
}
/** Words after the wake name. Empty when they only said "Charlie" or never said it. */
function commandAfterWake(text) {
	const match = WAKE.exec(text);
	if (!match || match.index === void 0) return "";
	const after = text.slice(match.index + match[0].length).replace(/^[\s,.;:!?-]+/, "").trim();
	const before = text.slice(0, match.index).replace(/(?:^|\s)(?:hey|ok|okay|hi)\s*$/i, "").replace(/[\s,.;:!?-]+$/, "").trim();
	const chosen = after.length >= 2 ? after : before;
	return chosen.length >= 2 ? chosen : "";
}
function transcriptOf(event) {
	let text = "";
	for (let i = 0; i < event.results.length; i++) text += `${event.results[i]?.[0]?.transcript ?? ""} `;
	return text.replace(/\s+/g, " ").trim();
}
async function transcribeBlob(blob) {
	const body = new FormData();
	body.append("file", blob, "speech.webm");
	const res = await fetch(apiUrl("/api/hear"), {
		method: "POST",
		body
	});
	if (!res.ok) return "";
	return (await res.json().catch(() => null))?.text?.trim() ?? "";
}
var WakeEar = class {
	onCommand;
	onEar;
	onDenied;
	gen = 0;
	timer = 0;
	running = false;
	vadStop = null;
	rec = null;
	constructor(onCommand, onEar, onDenied) {
		this.onCommand = onCommand;
		this.onEar = onEar;
		this.onDenied = onDenied;
	}
	arm(gesture) {
		if (this.running) return;
		this.running = true;
		const gen = this.gen;
		this.onEar("armed");
		if (this.beginSpeech(gen, gesture)) return;
		this.beginVad(gen, gesture);
	}
	stop() {
		this.running = false;
		this.gen += 1;
		if (this.timer) window.clearTimeout(this.timer);
		this.timer = 0;
		try {
			this.rec?.abort();
		} catch {}
		this.rec = null;
		this.vadStop?.();
		this.vadStop = null;
		this.onEar("off");
	}
	beginSpeech(gen, gesture) {
		const Ctor = speechCtor();
		if (!Ctor) return false;
		const rec = new Ctor();
		rec.continuous = true;
		rec.interimResults = true;
		rec.lang = "en-US";
		this.rec = rec;
		let latest = "";
		let heardName = false;
		let heardAt = 0;
		let delivered = false;
		const finish = () => {
			if (delivered || this.gen !== gen) return;
			const command = commandAfterWake(latest);
			latest = "";
			heardName = false;
			if (!command) {
				this.onEar("armed");
				try {
					rec.abort();
				} catch {}
				return;
			}
			delivered = true;
			this.onEar("off");
			try {
				rec.abort();
			} catch {}
			this.onCommand(command);
		};
		rec.onresult = (event) => {
			if (this.gen !== gen || delivered) return;
			const next = transcriptOf(event);
			if (!next || next === latest) return;
			latest = next;
			if (!WAKE.test(latest)) {
				heardName = false;
				this.onEar("armed");
				if (latest.length > 90) {
					latest = "";
					try {
						rec.abort();
					} catch {}
				}
				return;
			}
			if (!heardName) {
				heardName = true;
				heardAt = performance.now();
			}
			this.onEar("hearing");
			if (this.timer) window.clearTimeout(this.timer);
			const delay = performance.now() - heardAt > MAX_HEARING_MS ? 0 : SILENCE_MS;
			this.timer = window.setTimeout(finish, delay);
		};
		rec.onerror = (event) => {
			const code = event.error ?? "";
			if (code === "no-speech" || code === "aborted") return;
			if (code === "not-allowed") {
				this.gen += 1;
				this.running = false;
				this.rec = null;
				this.onEar("off");
				if (gesture) this.onDenied();
				try {
					rec.abort();
				} catch {}
				return;
			}
			if (code === "service-not-allowed" || code === "language-not-supported") {
				this.gen += 1;
				this.rec = null;
				try {
					rec.abort();
				} catch {}
				this.beginVad(this.gen, gesture);
			}
		};
		rec.onend = () => {
			if (this.gen !== gen || delivered || !this.rec) return;
			window.setTimeout(() => {
				if (this.gen !== gen || delivered) return;
				try {
					rec.start();
					this.onEar(heardName ? "hearing" : "armed");
				} catch {}
			}, 250);
		};
		try {
			rec.start();
			return true;
		} catch {
			this.rec = null;
			return false;
		}
	}
	async beginVad(gen, gesture) {
		if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
			if (this.gen === gen) {
				this.running = false;
				this.onEar("off");
				if (gesture) this.onDenied();
			}
			return;
		}
		let stream;
		try {
			stream = await navigator.mediaDevices.getUserMedia({ audio: {
				echoCancellation: true,
				noiseSuppression: true,
				autoGainControl: true
			} });
		} catch {
			if (this.gen === gen) {
				this.running = false;
				this.onEar("off");
				if (gesture) this.onDenied();
			}
			return;
		}
		if (this.gen !== gen) {
			stream.getTracks().forEach((track) => track.stop());
			return;
		}
		const ctx = new AudioContext();
		if (ctx.state === "suspended") ctx.resume();
		const analyser = ctx.createAnalyser();
		analyser.fftSize = 2048;
		ctx.createMediaStreamSource(stream).connect(analyser);
		const bins = new Float32Array(analyser.fftSize);
		let recorder = null;
		let chunks = [];
		let hotSince = 0;
		let quietSince = 0;
		let busy = false;
		let raf = 0;
		const closeRecorder = () => new Promise((resolve) => {
			if (!recorder || recorder.state === "inactive") {
				resolve(null);
				return;
			}
			const current = recorder;
			current.onstop = () => {
				const blob = new Blob(chunks, { type: current.mimeType || "audio/webm" });
				chunks = [];
				recorder = null;
				resolve(blob.size > 2500 ? blob : null);
			};
			current.stop();
		});
		const loop = () => {
			if (this.gen !== gen) return;
			analyser.getFloatTimeDomainData(bins);
			let sum = 0;
			for (let i = 0; i < bins.length; i++) sum += bins[i] * bins[i];
			const rms = Math.sqrt(sum / bins.length);
			const now = performance.now();
			if (!recorder && !busy) {
				if (rms > .02) {
					if (!hotSince) hotSince = now;
					if (now - hotSince > 220) {
						chunks = [];
						quietSince = 0;
						recorder = new MediaRecorder(stream);
						recorder.ondataavailable = (event) => {
							if (event.data.size) chunks.push(event.data);
						};
						recorder.start();
					}
				} else hotSince = 0;
			} else if (recorder) {
				if (rms > .015) quietSince = 0;
				else if (!quietSince) quietSince = now;
				const quietLongEnough = quietSince > 0 && now - quietSince > 900;
				const tooLong = hotSince > 0 && now - hotSince > MAX_HEARING_MS;
				if (quietLongEnough || tooLong) {
					hotSince = 0;
					quietSince = 0;
					busy = true;
					closeRecorder().then(async (blob) => {
						busy = false;
						if (!blob || this.gen !== gen) return;
						const text = await transcribeBlob(blob);
						if (this.gen !== gen) return;
						const command = commandAfterWake(text);
						if (command) this.onCommand(command);
					});
				}
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		this.vadStop = () => {
			cancelAnimationFrame(raf);
			if (recorder && recorder.state !== "inactive") recorder.stop();
			stream.getTracks().forEach((track) => track.stop());
			ctx.close();
		};
	}
};
function parseBlocks(source) {
	const lines = source.replace(/\r\n/g, "\n").split("\n");
	const blocks = [];
	let paragraph = [];
	let list = null;
	let code = null;
	const flushParagraph = () => {
		if (!paragraph.length) return;
		blocks.push({
			kind: "p",
			text: paragraph.join(" ")
		});
		paragraph = [];
	};
	const flushList = () => {
		if (!list) return;
		blocks.push(list.ordered ? {
			kind: "ol",
			items: list.items
		} : {
			kind: "ul",
			items: list.items
		});
		list = null;
	};
	for (const line of lines) {
		if (code) {
			if (line.trim().startsWith("```")) {
				blocks.push({
					kind: "code",
					text: code.join("\n")
				});
				code = null;
			} else code.push(line);
			continue;
		}
		if (line.trim().startsWith("```")) {
			flushParagraph();
			flushList();
			code = [];
			continue;
		}
		const heading = /^(#{1,3})\s+(.+)$/.exec(line.trim());
		if (heading) {
			flushParagraph();
			flushList();
			blocks.push({
				kind: "h",
				text: heading[2]
			});
			continue;
		}
		const bullet = /^[-*]\s+(.+)$/.exec(line.trim());
		const ordered = /^\d+[.)]\s+(.+)$/.exec(line.trim());
		if (bullet || ordered) {
			flushParagraph();
			const item = (bullet ?? ordered)[1];
			const isOrdered = Boolean(ordered);
			if (!list || list.ordered !== isOrdered) {
				flushList();
				list = {
					ordered: isOrdered,
					items: [item]
				};
			} else list.items.push(item);
			continue;
		}
		if (!line.trim()) {
			flushParagraph();
			flushList();
			continue;
		}
		flushList();
		paragraph.push(line.trim());
	}
	if (code) blocks.push({
		kind: "code",
		text: code.join("\n")
	});
	flushParagraph();
	flushList();
	return blocks;
}
function inline(text, key) {
	const re = /\[\[(\d+)\]\]\((https?:\/\/[^)\s]+)\)|\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)|\*\*([^*]+)\*\*|`([^`]+)`|\*([^*]+)\*/g;
	const nodes = [];
	let last = 0;
	let match;
	let i = 0;
	while (match = re.exec(text)) {
		if (match.index > last) nodes.push(text.slice(last, match.index));
		const id = `${key}-${i++}`;
		if (match[1] && match[2]) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: match[2],
			target: "_blank",
			rel: "noreferrer",
			className: "text-muted underline underline-offset-2",
			children: match[1]
		}, id));
		else if (match[3] && match[4]) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: match[4],
			target: "_blank",
			rel: "noreferrer",
			className: "underline underline-offset-2",
			children: match[3]
		}, id));
		else if (match[5]) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-medium",
			children: match[5]
		}, id));
		else if (match[6]) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "rounded-sm bg-wash px-1 font-mono text-sm",
			children: match[6]
		}, id));
		else if (match[7]) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
			className: "italic",
			children: match[7]
		}, id));
		last = match.index + match[0].length;
	}
	if (last < text.length) nodes.push(text.slice(last));
	return nodes;
}
function MessageBody({ text }) {
	const blocks = parseBlocks(text);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3 text-pretty",
		children: blocks.map((block, index) => {
			const key = `b${index}`;
			if (block.kind === "h") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-lg font-medium tracking-tight text-balance",
				children: inline(block.text, key)
			}, key);
			if (block.kind === "ul" || block.kind === "ol") {
				const Tag = block.kind === "ol" ? "ol" : "ul";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
					className: block.kind === "ol" ? "list-decimal space-y-1 pl-5" : "list-disc space-y-1 pl-5",
					children: block.items.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: inline(item, `${key}-${itemIndex}`) }, `${key}-${itemIndex}`))
				}, key);
			}
			if (block.kind === "code") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "overflow-x-auto rounded-lg bg-wash p-3 text-sm text-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: block.text })
			}, key);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: inline(block.text, key) }, key);
		})
	});
}
function SourceList({ citations }) {
	if (!citations.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3 flex flex-wrap gap-2",
		children: citations.map((citation) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: citation.url,
			target: "_blank",
			rel: "noreferrer",
			className: "inline-flex min-h-11 max-w-full items-center rounded-lg border border-line px-3 text-sm text-muted hover:text-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: citation.label
			})
		}) }, citation.url))
	});
}
var VOICES = [
	{
		id: "eve",
		label: "Eve",
		hint: "Warm and steady"
	},
	{
		id: "leo",
		label: "Leo",
		hint: "Easy and close"
	},
	{
		id: "ara",
		label: "Ara",
		hint: "Bright and quick"
	},
	{
		id: "orion",
		label: "Orion",
		hint: "Low and calm"
	}
];
var DEFAULT_PROFILE = {
	name: "",
	notes: "",
	speak: true,
	handsFree: true,
	voiceId: "leo"
};
var THREAD_CAP = 24;
function blankThread() {
	const now = Date.now();
	return {
		id: crypto.randomUUID(),
		title: "New chat",
		messages: [],
		updatedAt: now
	};
}
function titleFrom(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (clean.length <= 42) return clean || "New chat";
	return `${clean.slice(0, 41).trimEnd()}…`;
}
var useCharlie = create()(persist((set, get) => ({
	profile: DEFAULT_PROFILE,
	threads: [],
	activeId: "",
	phase: "idle",
	error: null,
	setProfile: (patch) => set((s) => ({ profile: {
		...s.profile,
		...patch
	} })),
	ensure: () => {
		const current = get();
		if (current.activeId && current.threads.some((t) => t.id === current.activeId)) return current.activeId;
		const thread = blankThread();
		set({
			threads: [thread, ...current.threads].slice(0, THREAD_CAP),
			activeId: thread.id
		});
		return thread.id;
	},
	newThread: () => {
		const thread = blankThread();
		set((s) => ({
			threads: [thread, ...s.threads].slice(0, THREAD_CAP),
			activeId: thread.id,
			error: null
		}));
	},
	selectThread: (id) => set({
		activeId: id,
		error: null
	}),
	deleteThread: (id) => set((s) => {
		const threads = s.threads.filter((t) => t.id !== id);
		if (threads.length === 0) {
			const thread = blankThread();
			return {
				threads: [thread],
				activeId: thread.id
			};
		}
		return {
			threads,
			activeId: s.activeId === id ? threads[0].id : s.activeId
		};
	}),
	pushMessages: (threadId, messages) => set((s) => ({ threads: s.threads.map((thread) => {
		if (thread.id !== threadId) return thread;
		const next = [...thread.messages, ...messages].slice(-80);
		const firstUser = next.find((m) => m.role === "user");
		const title = thread.title === "New chat" && firstUser ? titleFrom(firstUser.content) : thread.title;
		return {
			...thread,
			messages: next,
			title,
			updatedAt: Date.now()
		};
	}) })),
	patchMessage: (threadId, messageId, content, citations) => set((s) => ({ threads: s.threads.map((thread) => {
		if (thread.id !== threadId) return thread;
		return {
			...thread,
			updatedAt: Date.now(),
			messages: thread.messages.map((message) => message.id === messageId ? {
				...message,
				content,
				citations: citations ?? message.citations
			} : message)
		};
	}) })),
	dropMessage: (threadId, messageId) => set((s) => ({ threads: s.threads.map((thread) => thread.id === threadId ? {
		...thread,
		messages: thread.messages.filter((m) => m.id !== messageId)
	} : thread) })),
	setPhase: (phase) => set({ phase }),
	setError: (error) => set({ error })
}), {
	name: "charlie-v1",
	version: 2,
	skipHydration: true,
	migrate: (persisted) => {
		const saved = persisted ?? {};
		return {
			profile: {
				...DEFAULT_PROFILE,
				...saved.profile,
				speak: true,
				handsFree: true
			},
			threads: saved.threads ?? [],
			activeId: saved.activeId ?? ""
		};
	},
	partialize: (s) => ({
		profile: s.profile,
		threads: s.threads,
		activeId: s.activeId
	})
}));
var STARTERS = [
	{
		title: "Catch me up",
		text: "Catch me up on today's news like a friend would — a few things that actually matter."
	},
	{
		title: "Help me decide",
		text: "Help me think something through. Start by asking what I'm stuck on."
	},
	{
		title: "Worth knowing",
		text: "What's one thing worth knowing right now?"
	},
	{
		title: "Know me",
		text: "I want you to know me. Ask one good question."
	}
];
function greeting(date = /* @__PURE__ */ new Date()) {
	const hour = date.getHours();
	if (hour < 5) return "Still up";
	if (hour < 12) return "Good morning";
	if (hour < 17) return "Good afternoon";
	return "Good evening";
}
function speakable(text) {
	return text.replace(/\[\[\d+\]\]\([^)]+\)/g, "").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/[*_`#>]/g, "").replace(/\s+/g, " ").trim().slice(0, 700);
}
function CharlieFrame() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col bg-canvas text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center gap-3 border-b border-line px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl leading-none",
				children: "Charlie"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Best friend. Live web."
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-2xl flex-1 flex-col justify-center px-5 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Charlie"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl font-medium tracking-tight text-balance",
					children: "A friend who looks things up."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-md text-muted",
					children: "Ask anything. If it lives on the internet, Charlie will go find it."
				})
			]
		})]
	});
}
function Mark({ live = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative grid size-11 shrink-0 place-items-center",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute inset-0 rounded-full border border-line ${live ? "presence-ring presence-live" : "presence-ring"}` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-1.5 rounded-full border border-line" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg leading-none",
				children: "C"
			})
		]
	});
}
function CharlieApp() {
	const profile = useCharlie((s) => s.profile);
	const threads = useCharlie((s) => s.threads);
	const activeId = useCharlie((s) => s.activeId);
	const phase = useCharlie((s) => s.phase);
	const error = useCharlie((s) => s.error);
	const setProfile = useCharlie((s) => s.setProfile);
	const newThread = useCharlie((s) => s.newThread);
	const selectThread = useCharlie((s) => s.selectThread);
	const deleteThread = useCharlie((s) => s.deleteThread);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [ear, setEar] = (0, import_react.useState)("off");
	const [confirmForget, setConfirmForget] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	const abortRef = (0, import_react.useRef)(null);
	const audioRef = (0, import_react.useRef)(null);
	const audioUrl = (0, import_react.useRef)(null);
	const earRef = (0, import_react.useRef)(null);
	const askRef = (0, import_react.useRef)(async () => {});
	const thread = threads.find((item) => item.id === activeId) ?? threads[0];
	(0, import_react.useEffect)(() => {
		useCharlie.getState().ensure();
		const saved = useCharlie.getState().profile;
		if (!VOICES.some((voice) => voice.id === saved.voiceId)) useCharlie.getState().setProfile({ voiceId: "leo" });
	}, []);
	(0, import_react.useEffect)(() => {
		const node = scroller.current;
		if (!node) return;
		node.scrollTop = node.scrollHeight;
	}, [thread?.messages, phase]);
	(0, import_react.useEffect)(() => {
		return () => {
			abortRef.current?.abort();
			audioRef.current?.pause();
			if (audioUrl.current) URL.revokeObjectURL(audioUrl.current);
			earRef.current?.stop();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const earEngine = new WakeEar((text) => void askRef.current(text), setEar, () => useCharlie.getState().setError("Allow the microphone, then tap the mic so Charlie can wait for its name."));
		earRef.current = earEngine;
		return () => {
			earEngine.stop();
			earRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const engine = earRef.current;
		if (!engine) return;
		if (profile.handsFree && phase === "idle") engine.arm(false);
		else engine.stop();
	}, [profile.handsFree, phase]);
	(0, import_react.useEffect)(() => {
		if (!menu) return;
		const onKey = (event) => {
			if (event.key === "Escape") setMenu(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [menu]);
	async function speak(text) {
		const clean = speakable(text);
		if (!clean) return;
		const voiceId = useCharlie.getState().profile.voiceId;
		const res = await fetch(apiUrl("/api/speak"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				text: clean,
				voiceId
			})
		});
		if (!res.ok) {
			useCharlie.getState().setError("Charlie couldn't speak just now.");
			return;
		}
		const blob = await res.blob();
		if (audioUrl.current) URL.revokeObjectURL(audioUrl.current);
		const url = URL.createObjectURL(blob);
		audioUrl.current = url;
		audioRef.current?.pause();
		const audio = new Audio(url);
		audioRef.current = audio;
		await new Promise((resolve) => {
			audio.onended = () => resolve();
			audio.onerror = () => resolve();
			audio.play().catch(() => {
				useCharlie.getState().setError("Tap hear on the reply if the browser blocked the voice.");
				resolve();
			});
		});
	}
	async function ask(raw) {
		const text = raw.trim();
		const state = useCharlie.getState();
		if (!text || state.phase !== "idle") return;
		earRef.current?.stop();
		setDraft("");
		state.setError(null);
		const threadId = state.ensure();
		const history = [...(useCharlie.getState().threads.find((item) => item.id === threadId)?.messages ?? []).slice(-11), {
			role: "user",
			content: text
		}];
		const userId = crypto.randomUUID();
		const assistantId = crypto.randomUUID();
		const now = Date.now();
		state.pushMessages(threadId, [{
			id: userId,
			role: "user",
			content: text,
			createdAt: now
		}, {
			id: assistantId,
			role: "assistant",
			content: "",
			createdAt: now
		}]);
		state.setPhase("thinking");
		const controller = new AbortController();
		abortRef.current = controller;
		let full = "";
		let citations = [];
		let raf = 0;
		const paint = (next, nextCitations) => {
			cancelAnimationFrame(raf);
			useCharlie.getState().patchMessage(threadId, assistantId, next, nextCitations);
		};
		try {
			const profileNow = useCharlie.getState().profile;
			const res = await fetch(apiUrl("/api/chat"), {
				method: "POST",
				signal: controller.signal,
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					conversationId: threadId,
					profile: {
						name: profileNow.name,
						notes: profileNow.notes
					},
					messages: history
				})
			});
			const type = res.headers.get("content-type") ?? "";
			if (!res.ok || !res.body || !type.includes("text/event-stream")) {
				const body = await res.json().catch(() => null);
				throw new Error(body?.error || "Charlie couldn't answer.");
			}
			const reader = res.body.getReader();
			const decoder = new TextDecoder();
			let buffer = "";
			while (true) {
				const { done, value } = await reader.read();
				if (done) break;
				buffer += decoder.decode(value, { stream: true });
				const blocks = buffer.split(/\r?\n\r?\n/);
				buffer = blocks.pop() ?? "";
				for (const block of blocks) {
					let event = "message";
					const data = [];
					for (const line of block.split(/\r?\n/)) if (line.startsWith("event:")) event = line.slice(6).trim();
					else if (line.startsWith("data:")) data.push(line.slice(5).trim());
					if (!data.length) continue;
					const payload = JSON.parse(data.join("\n"));
					if (event === "status" && (payload.phase === "thinking" || payload.phase === "searching")) useCharlie.getState().setPhase(payload.phase);
					else if (event === "delta" && payload.text) {
						full += payload.text;
						const snapshot = full;
						if (!raf) raf = requestAnimationFrame(() => {
							raf = 0;
							paint(snapshot);
						});
					} else if (event === "error" && payload.message) useCharlie.getState().setError(payload.message);
					else if (event === "done") {
						if (typeof payload.text === "string" && payload.text) full = payload.text;
						citations = payload.citations ?? [];
					}
				}
			}
			cancelAnimationFrame(raf);
			if (!full.trim()) {
				useCharlie.getState().dropMessage(threadId, assistantId);
				useCharlie.getState().setError("Charlie didn't have an answer. Try once more.");
			} else {
				paint(full, citations);
				if (useCharlie.getState().profile.speak) await speak(full);
			}
		} catch (err) {
			cancelAnimationFrame(raf);
			if (err instanceof DOMException && err.name === "AbortError") {
				if (!full.trim()) useCharlie.getState().dropMessage(threadId, assistantId);
				else paint(full, citations);
			} else {
				if (!full.trim()) useCharlie.getState().dropMessage(threadId, assistantId);
				else paint(full, citations);
				useCharlie.getState().setError(err instanceof Error ? err.message : "Charlie couldn't answer.");
			}
		} finally {
			useCharlie.getState().setPhase("idle");
			abortRef.current = null;
		}
	}
	askRef.current = ask;
	function stop() {
		abortRef.current?.abort();
		earRef.current?.stop();
	}
	function toggleVoice() {
		if (profile.handsFree && ear !== "off") {
			setProfile({ handsFree: false });
			earRef.current?.stop();
			return;
		}
		setProfile({
			handsFree: true,
			speak: true
		});
		earRef.current?.arm(true);
	}
	function forget() {
		if (!confirmForget) {
			setConfirmForget(true);
			return;
		}
		useCharlie.setState({
			profile: DEFAULT_PROFILE,
			threads: [],
			activeId: "",
			error: null,
			phase: "idle"
		});
		useCharlie.getState().ensure();
		setConfirmForget(false);
		setMenu(false);
	}
	const busy = phase !== "idle";
	const hearing = ear === "hearing";
	const voiceLive = profile.handsFree && ear !== "off";
	const hello = profile.name.trim() ? `${greeting()}, ${profile.name.trim()}.` : `${greeting()}.`;
	const status = phase === "searching" ? "Looking that up" : phase === "thinking" ? "Thinking" : hearing ? "Listening" : profile.handsFree ? "Say Charlie" : "Here";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-canvas text-foreground",
		children: [
			menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-20 bg-canvas/80 lg:hidden",
				"aria-label": "Close menu",
				onClick: () => setMenu(false)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `fixed inset-y-0 left-0 z-30 flex w-full max-w-80 flex-col border-r border-line bg-panel motion-safe:transition-transform motion-safe:duration-300 ${menu ? "translate-x-0" : "-translate-x-full"} lg:static lg:z-auto lg:translate-x-0`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-4 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { live: busy || hearing }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl leading-none",
									children: "Charlie"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: "Best friend. Live web."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center rounded-lg text-muted lg:hidden",
								"aria-label": "Close menu",
								onClick: () => setMenu(false),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								if (!busy) newThread();
								setMenu(false);
							},
							className: "flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-accent px-3 text-sm font-medium text-accent-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New chat"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 min-h-0 flex-1 overflow-y-auto px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 pb-2 text-sm text-faint",
							children: "Chats"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1",
							children: threads.map((item) => {
								const selected = item.id === thread?.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										selectThread(item.id);
										setMenu(false);
									},
									className: `flex min-h-11 w-full items-center rounded-lg px-3 text-left text-sm ${selected ? "bg-wash text-foreground" : "text-muted hover:bg-wash hover:text-foreground"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: item.title
									})
								}) }, item.id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 border-t border-line p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm text-muted",
								htmlFor: "charlie-name",
								children: ["What should Charlie call you?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "charlie-name",
									value: profile.name,
									maxLength: 80,
									onChange: (event) => setProfile({ name: event.target.value }),
									placeholder: "Your name",
									className: "mt-1 min-h-11 w-full rounded-lg border border-line bg-canvas px-3 text-foreground placeholder:text-faint"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm text-muted",
								htmlFor: "charlie-notes",
								children: ["Remember this", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "charlie-notes",
									value: profile.notes,
									maxLength: 1200,
									rows: 3,
									onChange: (event) => setProfile({ notes: event.target.value }),
									placeholder: "The small stuff. The big stuff.",
									className: "mt-1 w-full resize-none rounded-lg border border-line bg-canvas px-3 py-2 text-foreground placeholder:text-faint"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Voice"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: VOICES.map((voice) => {
									const on = profile.voiceId === voice.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-pressed": on,
										onClick: () => setProfile({ voiceId: voice.id }),
										className: `min-h-11 rounded-lg border px-2 text-left ${on ? "border-accent bg-wash text-foreground" : "border-line text-muted"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-medium",
											children: voice.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm text-faint",
											children: voice.hint
										})]
									}, voice.id);
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": profile.speak,
								onClick: () => setProfile({ speak: !profile.speak }),
								className: `flex min-h-11 w-full items-center justify-between rounded-lg border px-3 text-sm ${profile.speak ? "border-accent bg-accent text-accent-ink" : "border-line text-muted"}`,
								children: ["Speak replies", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: profile.speak ? "On" : "Off" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => thread && deleteThread(thread.id),
									className: "min-h-11 flex-1 rounded-lg border border-line px-2 text-sm text-muted",
									children: "Delete chat"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: forget,
									className: "min-h-11 flex-1 rounded-lg border border-line px-2 text-sm text-danger",
									children: confirmForget ? "Yes, forget" : "Forget me"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-faint",
								children: "Kept on this device only."
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-center gap-3 border-b border-line px-3 py-2 lg:px-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center rounded-lg lg:hidden",
								"aria-label": "Open menu",
								onClick: () => setMenu(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-display text-xl leading-none",
									children: thread?.title ?? "Charlie"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									"aria-live": "polite",
									children: busy || hearing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "shimmer-text",
										children: status
									}) : status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden lg:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { live: busy || hearing })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scroller,
						className: "min-h-0 flex-1 overflow-y-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 py-8",
							children: !thread?.messages.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "py-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "Charlie"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "mt-2 font-display text-4xl font-medium tracking-tight text-balance",
										children: hello
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 max-w-md text-pretty text-muted",
										children: "Say Charlie, then talk. It answers out loud and stops when you go quiet."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-8 grid gap-2 sm:grid-cols-2",
										children: STARTERS.map((starter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: busy,
											onClick: () => void ask(starter.text),
											className: "min-h-11 rounded-xl border border-line bg-panel px-4 py-3 text-left text-sm hover:bg-wash disabled:opacity-50",
											children: starter.title
										}, starter.title))
									})
								]
							}) : thread.messages.map((message) => message.role === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex justify-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-xl rounded-xl bg-wash px-4 py-3 text-pretty",
									children: message.content
								})
							}, message.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "max-w-2xl",
								children: [
									message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBody, { text: message.content }) : busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "shimmer-text text-sm",
										children: status
									}) : null,
									message.citations ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceList, { citations: message.citations }) : null,
									message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => void speak(message.content),
										className: "mt-3 inline-flex min-h-11 items-center gap-2 rounded-lg px-2 text-sm text-muted hover:text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }), "Hear this"]
									}) : null
								]
							}, message.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-line px-3 py-3 lg:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto w-full max-w-2xl",
							children: [
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-start justify-between gap-3 rounded-lg border border-line bg-panel px-3 py-2 text-sm text-danger",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-h-11 shrink-0 text-muted",
										onClick: () => useCharlie.getState().setError(null),
										children: "Dismiss"
									})]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									className: "flex items-end gap-2 rounded-xl border border-line bg-panel p-2",
									onSubmit: (event) => {
										event.preventDefault();
										ask(draft);
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "sr-only",
											htmlFor: "charlie-draft",
											children: "Message Charlie"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											id: "charlie-draft",
											value: draft,
											rows: 1,
											maxLength: 4e3,
											disabled: hearing,
											placeholder: hearing ? "Listening…" : profile.handsFree ? "Say Charlie, or type" : "Talk to Charlie",
											onChange: (event) => setDraft(event.target.value),
											onKeyDown: (event) => {
												if (event.key === "Enter" && !event.shiftKey) {
													event.preventDefault();
													ask(draft);
												}
											},
											className: "max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2 text-foreground placeholder:text-faint"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: toggleVoice,
											"aria-pressed": voiceLive,
											"aria-label": voiceLive ? "Mute voice" : "Turn voice on",
											className: `grid size-11 shrink-0 place-items-center rounded-lg border border-line ${voiceLive ? "bg-accent text-accent-ink" : "text-muted"}`,
											children: voiceLive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "size-5" })
										}),
										busy && !hearing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: stop,
											"aria-label": "Stop",
											className: "grid size-11 shrink-0 place-items-center rounded-lg bg-accent text-accent-ink",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" })
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "submit",
											disabled: !draft.trim() || hearing,
											"aria-label": "Send",
											className: "grid size-11 shrink-0 place-items-center rounded-lg bg-accent text-accent-ink disabled:opacity-40",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-5" })
										})
									]
								}),
								profile.handsFree ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-faint",
									children: voiceLive ? "Say Charlie, then talk. It stops when you go quiet." : "Tap the mic once so Charlie can wait for its name."
								}) : null
							]
						})
					})
				]
			})
		]
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		Promise.resolve(useCharlie.persist.rehydrate()).then(() => {
			if (!cancel) setReady(true);
		});
		return () => {
			cancel = true;
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CharlieFrame, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CharlieApp, {});
}
//#endregion
export { Home as component };
