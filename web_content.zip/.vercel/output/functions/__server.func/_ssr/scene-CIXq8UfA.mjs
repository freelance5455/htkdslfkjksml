import { i as __toESM } from "../_runtime.mjs";
import { _ as Vector3, a as Canvas, b as require_jsx_runtime, c as BufferAttribute, d as Color, f as Line$1, g as ShaderMaterial, h as SRGBColorSpace, l as BufferGeometry, m as Object3D, n as Billboard, o as useFrame, p as LineBasicMaterial, r as Html, s as useThree, t as Line, u as CanvasTexture, x as require_react } from "../_libs/@react-three/drei+[...].mjs";
import { a as BODIES, c as ORBIT_LINE, d as orbitOmega, i as BELT_COLOR, l as SCENE_BG, n as useSolar, o as BODY_MAP, r as ACCENT, u as SUN_LIGHT } from "./routes-Ce1Fv78C.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scene-CIXq8UfA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function hash(ix, iy) {
	const s = Math.sin(ix * 127.1 + iy * 311.7) * 43758.5453123;
	return s - Math.floor(s);
}
function noise(x, y) {
	const xi = Math.floor(x);
	const yi = Math.floor(y);
	const xf = x - xi;
	const yf = y - yi;
	const u = xf * xf * (3 - 2 * xf);
	const v = yf * yf * (3 - 2 * yf);
	const a = hash(xi, yi);
	const b = hash(xi + 1, yi);
	const c = hash(xi, yi + 1);
	const d = hash(xi + 1, yi + 1);
	return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x, y) {
	let value = 0;
	let amplitude = .5;
	let frequency = 1;
	for (let i = 0; i < 5; i += 1) {
		value += amplitude * noise(x * frequency, y * frequency);
		frequency *= 2;
		amplitude *= .5;
	}
	return value;
}
function clamp01(n) {
	return Math.min(1, Math.max(0, n));
}
function mix(a, b, t) {
	const k = clamp01(t);
	return [
		a[0] + (b[0] - a[0]) * k,
		a[1] + (b[1] - a[1]) * k,
		a[2] + (b[2] - a[2]) * k
	];
}
function write(data, index, rgb, alpha = 255) {
	data[index] = rgb[0];
	data[index + 1] = rgb[1];
	data[index + 2] = rgb[2];
	data[index + 3] = alpha;
}
function makeTexture(width, height, paint) {
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Não foi possível criar a textura.");
	const image = ctx.createImageData(width, height);
	paint(image.data, width, height);
	ctx.putImageData(image, 0, 0);
	const texture = new CanvasTexture(canvas);
	texture.colorSpace = SRGBColorSpace;
	texture.anisotropy = 4;
	texture.needsUpdate = true;
	return texture;
}
function paintRocky(data, w, h, low, high, crater = 0) {
	for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
		const n = fbm(x * .02, y * .035);
		const n2 = fbm(x * .06 + 4, y * .06);
		let rgb = mix(low, high, n * .75 + n2 * .25);
		if (crater > 0) {
			const c = noise(x * .18, y * .18);
			if (c > .72) rgb = mix(rgb, [
				70,
				68,
				64
			], (c - .72) * 2.2);
		}
		write(data, (y * w + x) * 4, rgb);
	}
}
function continent(lon, lat) {
	const spots = [
		[
			20,
			6,
			26,
			34
		],
		[
			14,
			48,
			18,
			14
		],
		[
			78,
			42,
			48,
			24
		],
		[
			105,
			62,
			28,
			14
		],
		[
			-102,
			46,
			30,
			22
		],
		[
			-62,
			-18,
			16,
			30
		],
		[
			134,
			-25,
			16,
			12
		],
		[
			-42,
			72,
			14,
			8
		]
	];
	let mask = 0;
	for (const [lo, la, slo, sla] of spots) {
		const dx = (lon - lo) / slo;
		const dy = (lat - la) / sla;
		mask += Math.exp(-(dx * dx + dy * dy));
	}
	return mask;
}
function paintEarth(data, w, h) {
	const oceanA = [
		18,
		62,
		112
	];
	const oceanB = [
		36,
		104,
		150
	];
	const landA = [
		62,
		102,
		58
	];
	const landB = [
		150,
		132,
		86
	];
	const ice = [
		226,
		232,
		236
	];
	for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
		const lon = x / w * 360 - 180;
		const lat = 90 - y / h * 180;
		const n = fbm(x * .03, y * .03);
		const land = continent(lon, lat) * .9 + (n - .48) * .55;
		let rgb;
		if (Math.abs(lat) > 70) rgb = mix(land > .4 ? landA : oceanA, ice, clamp01((Math.abs(lat) - 70) / 14));
		else if (land > .42) {
			rgb = mix(landA, landB, n);
			if (Math.abs(lat) < 10 && n > .55) rgb = mix(rgb, [
				46,
				110,
				62
			], .45);
		} else rgb = mix(oceanA, oceanB, n);
		write(data, (y * w + x) * 4, rgb);
	}
}
function paintVenus(data, w, h) {
	const a = [
		186,
		164,
		118
	];
	const b = [
		232,
		214,
		176
	];
	for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
		const n = fbm(x * .02, y * .045);
		const swirl = fbm(x * .05 + n * 2, y * .02);
		write(data, (y * w + x) * 4, mix(a, b, swirl * .7 + n * .3));
	}
}
function paintMars(data, w, h) {
	const low = [
		112,
		48,
		32
	];
	const high = [
		186,
		96,
		58
	];
	const dust = [
		210,
		150,
		110
	];
	const ice = [
		230,
		226,
		220
	];
	for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
		const lat = Math.abs(90 - y / h * 180);
		const n = fbm(x * .028, y * .04);
		let rgb = mix(low, high, n);
		if (n > .62) rgb = mix(rgb, dust, (n - .62) * 1.6);
		if (lat > 72) rgb = mix(rgb, ice, clamp01((lat - 72) / 12));
		write(data, (y * w + x) * 4, rgb);
	}
}
function paintBands(data, w, h, palette, bands, spot) {
	for (let y = 0; y < h; y += 1) {
		const lat = y / h;
		const warp = fbm(.4, lat * 6);
		for (let x = 0; x < w; x += 1) {
			const streak = fbm(x * .01, lat * 4);
			const t = Math.sin((lat * bands + warp * .35 + streak * .15) * Math.PI * 2) * .5 + .5;
			const index = Math.min(palette.length - 2, Math.floor(t * (palette.length - 1)));
			const local = t * (palette.length - 1) - index;
			let rgb = mix(palette[index], palette[index + 1], local);
			if (spot) {
				const dx = (x - spot.x * w) / spot.rx;
				const dy = (y - spot.y * h) / spot.ry;
				const d = dx * dx + dy * dy;
				if (d < 1) rgb = mix(rgb, spot.color, 1 - d);
			}
			write(data, (y * w + x) * 4, rgb);
		}
	}
}
function paintClouds(data, w, h) {
	for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
		const n = fbm(x * .03 + 2, y * .05);
		const alpha = n > .52 ? Math.floor((n - .52) * 520) : 0;
		write(data, (y * w + x) * 4, [
			244,
			246,
			248
		], Math.min(170, alpha));
	}
}
function makeGlow() {
	const size = 256;
	const canvas = document.createElement("canvas");
	canvas.width = size;
	canvas.height = size;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Não foi possível criar o brilho.");
	const gradient = ctx.createRadialGradient(128, 128, 8, 128, 128, 128);
	gradient.addColorStop(0, "rgba(255, 246, 230, 0.95)");
	gradient.addColorStop(.16, "rgba(255, 214, 150, 0.55)");
	gradient.addColorStop(.38, "rgba(255, 170, 80, 0.16)");
	gradient.addColorStop(1, "rgba(255, 140, 40, 0)");
	ctx.fillStyle = gradient;
	ctx.fillRect(0, 0, size, size);
	const texture = new CanvasTexture(canvas);
	texture.colorSpace = SRGBColorSpace;
	texture.needsUpdate = true;
	return texture;
}
var cache = null;
function getSolarTextures() {
	if (cache) return cache;
	const w = 512;
	const h = 256;
	cache = {
		mercury: makeTexture(w, h, (data, width, height) => paintRocky(data, width, height, [
			92,
			90,
			86
		], [
			168,
			164,
			156
		], 1)),
		venus: makeTexture(w, h, paintVenus),
		earth: makeTexture(w, h, paintEarth),
		mars: makeTexture(w, h, paintMars),
		jupiter: makeTexture(w, h, (data, width, height) => paintBands(data, width, height, [
			[
				116,
				74,
				48
			],
			[
				214,
				176,
				124
			],
			[
				168,
				116,
				72
			],
			[
				232,
				214,
				186
			],
			[
				140,
				86,
				52
			]
		], 7, {
			x: .64,
			y: .62,
			rx: 34,
			ry: 18,
			color: [
				176,
				72,
				48
			]
		})),
		saturn: makeTexture(w, h, (data, width, height) => paintBands(data, width, height, [
			[
				196,
				170,
				130
			],
			[
				230,
				214,
				180
			],
			[
				176,
				150,
				112
			],
			[
				236,
				224,
				198
			]
		], 6)),
		uranus: makeTexture(w, h, (data, width, height) => paintBands(data, width, height, [
			[
				150,
				196,
				192
			],
			[
				196,
				224,
				220
			],
			[
				168,
				208,
				204
			]
		], 3)),
		neptune: makeTexture(w, h, (data, width, height) => paintBands(data, width, height, [
			[
				24,
				52,
				128
			],
			[
				48,
				86,
				176
			],
			[
				30,
				64,
				148
			],
			[
				70,
				112,
				196
			]
		], 4, {
			x: .42,
			y: .38,
			rx: 22,
			ry: 14,
			color: [
				120,
				168,
				210
			]
		})),
		clouds: makeTexture(w, h, paintClouds),
		glow: makeGlow()
	};
	return cache;
}
var HOME = {
	r: 62,
	theta: .58,
	phi: 1.08
};
var TRAIL = 200;
var BELT_COUNT = 380;
var clock = { t: 0 };
var worldPos = {
	sun: new Vector3(),
	mercury: new Vector3(),
	venus: new Vector3(),
	earth: new Vector3(),
	mars: new Vector3(),
	jupiter: new Vector3(),
	saturn: new Vector3(),
	uranus: new Vector3(),
	neptune: new Vector3()
};
var moonPos = new Vector3();
var ORIGIN = new Vector3();
function placeOnOrbit(angle, radius, inclination, target) {
	const x = Math.cos(angle) * radius;
	const z = Math.sin(angle) * radius;
	target.set(x, -z * Math.sin(inclination), z * Math.cos(inclination));
	return target;
}
function sphericalToVec(r, theta, phi, target) {
	const sinPhi = Math.sin(phi);
	target.set(r * sinPhi * Math.sin(theta), r * Math.cos(phi), r * sinPhi * Math.cos(theta));
	return target;
}
function lerpAngle(a, b, t) {
	return a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * t;
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
var SUN_VERT = `
  varying vec3 vPos;
  varying vec3 vNormal;
  void main() {
    vPos = position;
    vNormal = normalize(normalMatrix * normal);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
var SUN_FRAG = `
  varying vec3 vPos;
  varying vec3 vNormal;
  uniform float uTime;
  void main() {
    vec3 n = normalize(vPos);
    float bands = sin(n.y * 9.0 + uTime * 0.55) * 0.5 + 0.5;
    float cells = sin(n.x * 7.0 + uTime * 0.35) * sin(n.z * 6.0 - uTime * 0.28);
    float hot = clamp(0.42 + bands * 0.38 + cells * 0.18, 0.0, 1.0);
    vec3 deep = vec3(0.72, 0.28, 0.08);
    vec3 mid = vec3(1.0, 0.62, 0.24);
    vec3 high = vec3(1.0, 0.94, 0.82);
    vec3 col = mix(deep, mid, hot);
    col = mix(col, high, smoothstep(0.62, 1.0, hot));
    vec3 viewDir = normalize(cameraPosition - (modelMatrix * vec4(vPos, 1.0)).xyz);
    float fres = pow(1.0 - max(dot(normalize(vNormal), viewDir), 0.0), 2.4);
    col += vec3(1.0, 0.78, 0.5) * fres * 0.28;
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;
var ATMOS_VERT = `
  varying vec3 vNormal;
  varying vec3 vWorld;
  void main() {
    vNormal = normalize(normalMatrix * normal);
    vec4 world = modelMatrix * vec4(position, 1.0);
    vWorld = world.xyz;
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`;
var ATMOS_FRAG = `
  varying vec3 vNormal;
  varying vec3 vWorld;
  uniform vec3 uColor;
  void main() {
    vec3 viewDir = normalize(cameraPosition - vWorld);
    float rim = pow(1.0 - max(dot(normalize(vNormal), viewDir), 0.0), 2.6);
    gl_FragColor = vec4(uColor, rim * 0.42);
    #include <colorspace_fragment>
  }
`;
var RING_VERT = `
  varying vec3 vLocal;
  void main() {
    vLocal = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
var RING_FRAG = `
  varying vec3 vLocal;
  uniform float uInner;
  uniform float uOuter;
  uniform vec3 uColor;
  uniform float uStrength;
  void main() {
    float r = length(vLocal.xy);
    float t = clamp((r - uInner) / (uOuter - uInner), 0.0, 1.0);
    float bands = 0.35 + 0.65 * smoothstep(0.2, 0.8, abs(sin(t * 34.0)));
    float gap = smoothstep(0.018, 0.0, abs(t - 0.46));
    float edge = smoothstep(0.0, 0.04, t) * smoothstep(1.0, 0.9, t);
    float alpha = bands * (1.0 - gap * 0.85) * edge * uStrength;
    if (alpha < 0.03) discard;
    vec3 col = mix(uColor * 0.72, uColor, bands);
    gl_FragColor = vec4(col, alpha);
    #include <colorspace_fragment>
  }
`;
var STAR_VERT = `
  attribute float size;
  varying vec3 vColor;
  uniform float uTime;
  void main() {
    float twinkle = 0.78 + 0.22 * sin(uTime * 0.7 + position.x * 0.15);
    vColor = color * twinkle;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = size * (170.0 / max(1.0, -mv.z));
    gl_Position = projectionMatrix * mv;
  }
`;
var STAR_FRAG = `
  varying vec3 vColor;
  void main() {
    float d = length(gl_PointCoord - vec2(0.5));
    float alpha = smoothstep(0.5, 0.12, d);
    if (alpha < 0.02) discard;
    gl_FragColor = vec4(vColor, alpha);
    #include <colorspace_fragment>
  }
`;
function mulberry32(seed) {
	let a = seed;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function Simulator() {
	useFrame((_, delta) => {
		const step = Math.min(delta, .1);
		const { paused, speed } = useSolar.getState();
		if (!paused) clock.t += step * speed;
	}, -1);
	return null;
}
function Starfield() {
	const geometry = (0, import_react.useMemo)(() => {
		const count = 1500;
		const positions = new Float32Array(count * 3);
		const colors = new Float32Array(count * 3);
		const sizes = new Float32Array(count);
		const rnd = mulberry32(11);
		for (let i = 0; i < count; i += 1) {
			const radius = 80 + rnd() * 70;
			const theta = rnd() * Math.PI * 2;
			const phi = Math.acos(2 * rnd() - 1);
			positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
			positions[i * 3 + 1] = radius * Math.cos(phi) * .75;
			positions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
			const light = .62 + rnd() * .38;
			colors[i * 3] = light;
			colors[i * 3 + 1] = light;
			colors[i * 3 + 2] = light * (.94 + rnd() * .06);
			sizes[i] = .7 + rnd() * 1.7;
		}
		const geom = new BufferGeometry();
		geom.setAttribute("position", new BufferAttribute(positions, 3));
		geom.setAttribute("color", new BufferAttribute(colors, 3));
		geom.setAttribute("size", new BufferAttribute(sizes, 1));
		return geom;
	}, []);
	const material = (0, import_react.useMemo)(() => new ShaderMaterial({
		uniforms: { uTime: { value: 0 } },
		vertexShader: STAR_VERT,
		fragmentShader: STAR_FRAG,
		transparent: true,
		depthWrite: false,
		blending: 2,
		vertexColors: true
	}), []);
	useFrame((state) => {
		material.uniforms.uTime.value = state.clock.elapsedTime;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("points", {
		geometry,
		material,
		frustumCulled: false
	});
}
function OrbitPath({ radius, inclination }) {
	const points = (0, import_react.useMemo)(() => {
		const pts = [];
		const steps = 180;
		for (let i = 0; i <= steps; i += 1) {
			const angle = i / steps * Math.PI * 2;
			pts.push(new Vector3(Math.cos(angle) * radius, 0, Math.sin(angle) * radius));
		}
		return pts;
	}, [radius]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		rotation: [
			inclination,
			0,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
			points,
			color: ORBIT_LINE,
			transparent: true,
			opacity: .42,
			lineWidth: 1,
			depthWrite: false
		})
	});
}
function MotionTrail({ color, position }) {
	const geometry = (0, import_react.useMemo)(() => {
		const geom = new BufferGeometry();
		geom.setAttribute("position", new BufferAttribute(/* @__PURE__ */ new Float32Array(600), 3));
		geom.setAttribute("color", new BufferAttribute(/* @__PURE__ */ new Float32Array(600), 3));
		geom.setDrawRange(0, 0);
		return geom;
	}, []);
	const history = (0, import_react.useMemo)(() => Array.from({ length: TRAIL }, () => new Vector3()), []);
	const head = (0, import_react.useRef)(0);
	const count = (0, import_react.useRef)(0);
	const base = (0, import_react.useMemo)(() => new Color(color), [color]);
	const material = (0, import_react.useMemo)(() => new LineBasicMaterial({
		vertexColors: true,
		transparent: true,
		opacity: .95,
		depthWrite: false
	}), []);
	const line = (0, import_react.useMemo)(() => {
		const object = new Line$1(geometry, material);
		object.frustumCulled = false;
		return object;
	}, [geometry, material]);
	useFrame(() => {
		const current = position.current;
		if (!current) return;
		if (!useSolar.getState().paused) {
			const previous = history[(head.current - 1 + TRAIL) % TRAIL];
			if (count.current === 0 || previous.distanceToSquared(current) > 8e-4) {
				history[head.current].copy(current);
				head.current = (head.current + 1) % TRAIL;
				count.current = Math.min(TRAIL, count.current + 1);
			}
		}
		const n = count.current;
		const posAttr = geometry.getAttribute("position");
		const colAttr = geometry.getAttribute("color");
		const pos = posAttr.array;
		const col = colAttr.array;
		const start = (head.current - n + TRAIL) % TRAIL;
		for (let i = 0; i < n; i += 1) {
			const point = history[(start + i) % TRAIL];
			pos[i * 3] = point.x;
			pos[i * 3 + 1] = point.y;
			pos[i * 3 + 2] = point.z;
			const fade = n <= 1 ? 1 : (i / (n - 1)) ** 1.6;
			col[i * 3] = base.r * fade;
			col[i * 3 + 1] = base.g * fade;
			col[i * 3 + 2] = base.b * fade;
		}
		posAttr.needsUpdate = true;
		colAttr.needsUpdate = true;
		geometry.setDrawRange(0, Math.max(0, n));
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("primitive", { object: line });
}
function AsteroidBelt() {
	const mesh = (0, import_react.useRef)(null);
	const dummy = (0, import_react.useMemo)(() => new Object3D(), []);
	const seeds = (0, import_react.useMemo)(() => {
		const rnd = mulberry32(23);
		return Array.from({ length: BELT_COUNT }, () => ({
			base: rnd() * Math.PI * 2,
			radius: 13.35 + rnd() * 1.55,
			y: (rnd() - .5) * .42,
			scale: .025 + rnd() * .055,
			speed: .035 + rnd() * .03,
			tilt: rnd() * Math.PI
		}));
	}, []);
	useLayoutSeed(mesh, seeds, dummy);
	useFrame(() => {
		const inst = mesh.current;
		if (!inst) return;
		const time = clock.t;
		for (let i = 0; i < seeds.length; i += 1) {
			const seed = seeds[i];
			const angle = seed.base + time * seed.speed;
			dummy.position.set(Math.cos(angle) * seed.radius, seed.y, Math.sin(angle) * seed.radius);
			dummy.scale.setScalar(seed.scale);
			dummy.rotation.set(seed.tilt, angle, seed.tilt * .3);
			dummy.updateMatrix();
			inst.setMatrixAt(i, dummy.matrix);
		}
		inst.instanceMatrix.needsUpdate = true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref: mesh,
		args: [
			void 0,
			void 0,
			BELT_COUNT
		],
		frustumCulled: false,
		raycast: () => null,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dodecahedronGeometry", { args: [1, 0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: BELT_COLOR,
			roughness: .92,
			metalness: .04
		})]
	});
}
function useLayoutSeed(mesh, seeds, dummy) {
	(0, import_react.useEffect)(() => {
		const inst = mesh.current;
		if (!inst) return;
		for (let i = 0; i < seeds.length; i += 1) {
			const seed = seeds[i];
			dummy.position.set(Math.cos(seed.base) * seed.radius, seed.y, Math.sin(seed.base) * seed.radius);
			dummy.scale.setScalar(seed.scale);
			dummy.rotation.set(seed.tilt, seed.base, 0);
			dummy.updateMatrix();
			inst.setMatrixAt(i, dummy.matrix);
		}
		inst.instanceMatrix.needsUpdate = true;
	}, [
		dummy,
		mesh,
		seeds
	]);
}
function PlanetRings({ inner, outer, color, strength }) {
	const uniforms = (0, import_react.useMemo)(() => ({
		uInner: { value: inner },
		uOuter: { value: outer },
		uColor: { value: new Color(color) },
		uStrength: { value: strength }
	}), [
		color,
		inner,
		outer,
		strength
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		rotation: [
			Math.PI / 2,
			0,
			0
		],
		raycast: () => null,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
			inner,
			outer,
			96
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("shaderMaterial", {
			uniforms,
			vertexShader: RING_VERT,
			fragmentShader: RING_FRAG,
			transparent: true,
			depthWrite: false,
			side: 2,
			toneMapped: false
		})]
	});
}
function Atmosphere({ radius, color }) {
	const uniforms = (0, import_react.useMemo)(() => ({ uColor: { value: new Color(color) } }), [color]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		raycast: () => null,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			radius * 1.08,
			40,
			32
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("shaderMaterial", {
			uniforms,
			vertexShader: ATMOS_VERT,
			fragmentShader: ATMOS_FRAG,
			transparent: true,
			depthWrite: false,
			side: 0
		})]
	});
}
function SelectionRing({ radius }) {
	const material = (0, import_react.useRef)(null);
	const reduced = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		reduced.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	}, []);
	useFrame((state) => {
		if (!material.current || reduced.current) return;
		material.current.opacity = .45 + Math.sin(state.clock.elapsedTime * 2.1) * .22;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Billboard, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		raycast: () => null,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
			radius * 1.42,
			radius * 1.56,
			64
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
			ref: material,
			color: ACCENT,
			transparent: true,
			opacity: .7,
			depthWrite: false,
			side: 2
		})]
	}) });
}
function Body({ body, textures }) {
	const anchor = (0, import_react.useRef)(null);
	const spin = (0, import_react.useRef)(null);
	const clouds = (0, import_react.useRef)(null);
	const moon = (0, import_react.useRef)(null);
	const pos = (0, import_react.useRef)(worldPos[body.id]);
	const selected = useSolar((state) => state.selected === body.id);
	const omega = body.orbitDays > 0 ? orbitOmega(body.orbitDays) : 0;
	const map = body.id === "sun" ? null : textures[body.id];
	useFrame(() => {
		if (body.orbit > 0) placeOnOrbit(body.phase + clock.t * omega, body.orbit, body.inclination, pos.current);
		else pos.current.set(0, 0, 0);
		anchor.current?.position.copy(pos.current);
		if (spin.current) spin.current.rotation.y = clock.t * body.spin;
		if (clouds.current) clouds.current.rotation.y = clock.t * body.spin * .78;
		if (moon.current && body.moon) {
			const angle = clock.t * 1.35;
			moonPos.set(pos.current.x + Math.cos(angle) * .78, pos.current.y + Math.sin(angle * .35) * .06, pos.current.z + Math.sin(angle) * .78);
			moon.current.position.copy(moonPos);
		}
	});
	const select = (event) => {
		event.stopPropagation();
		useSolar.getState().select(body.id);
	};
	const setCursor = (value) => {
		document.body.style.cursor = value;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		body.orbit > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitPath, {
			radius: body.orbit,
			inclination: body.inclination
		}),
		body.orbit > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MotionTrail, {
			color: body.color,
			position: pos
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			ref: anchor,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
					rotation: [
						0,
						0,
						body.tilt
					],
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
							ref: spin,
							children: body.id === "sun" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunSurface, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
								raycast: () => null,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
									body.radius,
									body.radius > .6 ? 56 : 40,
									body.radius > .6 ? 40 : 28
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
									map,
									emissiveMap: map,
									emissive: "white",
									emissiveIntensity: .38,
									roughness: body.kind.startsWith("Gigante") ? .62 : .88,
									metalness: .02
								})]
							})
						}),
						body.clouds && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
							ref: clouds,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
								raycast: () => null,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
									body.radius * 1.025,
									40,
									28
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
									map: textures.clouds,
									transparent: true,
									opacity: .55,
									depthWrite: false,
									roughness: 1
								})]
							})
						}),
						body.atmosphere && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Atmosphere, {
							radius: body.radius,
							color: body.atmosphere
						}),
						body.ring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanetRings, {
							inner: body.ring.inner,
							outer: body.ring.outer,
							color: body.color,
							strength: body.id === "uranus" ? .45 : .82
						})
					]
				}),
				selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectionRing, { radius: body.id === "sun" ? body.radius * 1.35 : Math.max(body.radius, .28) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
					position: [
						0,
						body.radius * (body.id === "sun" ? 1.9 : 1.75),
						0
					],
					center: true,
					wrapperClass: "label-root",
					pointerEvents: "none",
					zIndexRange: [8, 0],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: selected ? "planet-label is-on" : "planet-label",
						children: body.name
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					onClick: select,
					onPointerOver: (event) => {
						event.stopPropagation();
						setCursor("pointer");
					},
					onPointerOut: () => setCursor(""),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
						Math.max(body.radius * 1.55, body.id === "sun" ? body.radius : .52),
						16,
						12
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
						transparent: true,
						opacity: 0,
						depthWrite: false
					})]
				})
			]
		}),
		body.moon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			ref: moon,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				raycast: () => null,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.09,
					20,
					16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#c8c4bb",
					roughness: .95,
					emissive: "#c8c4bb",
					emissiveIntensity: .2
				})]
			})
		})
	] });
}
function SunSurface() {
	const material = (0, import_react.useRef)(null);
	const uniforms = (0, import_react.useMemo)(() => ({ uTime: { value: 0 } }), []);
	useFrame((state) => {
		if (material.current) material.current.uniforms.uTime.value = state.clock.elapsedTime;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		raycast: () => null,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			BODY_MAP.sun.radius,
			64,
			48
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("shaderMaterial", {
			ref: material,
			uniforms,
			vertexShader: SUN_VERT,
			fragmentShader: SUN_FRAG,
			toneMapped: false
		})]
	});
}
function SunGlow({ texture }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sprite", {
		scale: [
			8.2,
			8.2,
			1
		],
		raycast: () => null,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("spriteMaterial", {
			map: texture,
			transparent: true,
			depthWrite: false,
			blending: 2,
			toneMapped: false,
			opacity: .85
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
		color: SUN_LIGHT,
		intensity: 160,
		distance: 90,
		decay: 2
	})] });
}
function CameraRig() {
	const { camera, gl } = useThree();
	const focus = (0, import_react.useRef)(new Vector3());
	const offset = (0, import_react.useRef)(new Vector3());
	const spherical = (0, import_react.useRef)({ ...HOME });
	const goal = (0, import_react.useRef)({ ...HOME });
	const applied = (0, import_react.useRef)(-1);
	const idle = (0, import_react.useRef)(0);
	const reduced = (0, import_react.useRef)(false);
	const pointers = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const drag = (0, import_react.useRef)(null);
	const pinch = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		reduced.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const element = gl.domElement;
		const minRadius = () => {
			const selected = useSolar.getState().selected;
			if (!selected) return 16;
			return Math.max(.85, BODY_MAP[selected].view * .42);
		};
		const onDown = (event) => {
			pointers.current.set(event.pointerId, {
				x: event.clientX,
				y: event.clientY
			});
			idle.current = 0;
			if (pointers.current.size === 1) drag.current = {
				x: event.clientX,
				y: event.clientY,
				active: false
			};
		};
		const onMove = (event) => {
			if (!pointers.current.has(event.pointerId)) return;
			pointers.current.set(event.pointerId, {
				x: event.clientX,
				y: event.clientY
			});
			idle.current = 0;
			if (pointers.current.size >= 2) {
				const pts = [...pointers.current.values()];
				const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
				if (pinch.current && dist > 0) {
					const next = clamp(goal.current.r * (pinch.current / dist), minRadius(), 120);
					goal.current.r = next;
					spherical.current.r = next;
				}
				pinch.current = dist;
				return;
			}
			pinch.current = null;
			if (!drag.current) return;
			const dx = event.clientX - drag.current.x;
			const dy = event.clientY - drag.current.y;
			if (!drag.current.active) {
				if (Math.hypot(dx, dy) < 5) return;
				drag.current.active = true;
			}
			drag.current.x = event.clientX;
			drag.current.y = event.clientY;
			spherical.current.theta -= dx * .005;
			spherical.current.phi = clamp(spherical.current.phi - dy * .004, .24, Math.PI - .24);
			goal.current.theta = spherical.current.theta;
			goal.current.phi = spherical.current.phi;
		};
		const onUp = (event) => {
			pointers.current.delete(event.pointerId);
			if (pointers.current.size < 2) pinch.current = null;
			if (pointers.current.size === 0) drag.current = null;
		};
		const onWheel = (event) => {
			event.preventDefault();
			idle.current = 0;
			goal.current.r = clamp(goal.current.r * Math.exp(event.deltaY * .0011), minRadius(), 120);
		};
		const onKey = (event) => {
			if (event.code === "ArrowLeft") {
				event.preventDefault();
				goal.current.theta += .08;
			} else if (event.code === "ArrowRight") {
				event.preventDefault();
				goal.current.theta -= .08;
			} else if (event.code === "ArrowUp") {
				event.preventDefault();
				goal.current.phi = clamp(goal.current.phi - .06, .24, Math.PI - .24);
			} else if (event.code === "ArrowDown") {
				event.preventDefault();
				goal.current.phi = clamp(goal.current.phi + .06, .24, Math.PI - .24);
			}
		};
		element.addEventListener("pointerdown", onDown);
		window.addEventListener("pointermove", onMove);
		window.addEventListener("pointerup", onUp);
		window.addEventListener("pointercancel", onUp);
		element.addEventListener("wheel", onWheel, { passive: false });
		window.addEventListener("keydown", onKey);
		return () => {
			element.removeEventListener("pointerdown", onDown);
			window.removeEventListener("pointermove", onMove);
			window.removeEventListener("pointerup", onUp);
			window.removeEventListener("pointercancel", onUp);
			element.removeEventListener("wheel", onWheel);
			window.removeEventListener("keydown", onKey);
			document.body.style.cursor = "";
		};
	}, [gl]);
	useFrame((_, delta) => {
		const step = Math.min(delta, .1);
		const state = useSolar.getState();
		if (state.focusTick !== applied.current) {
			applied.current = state.focusTick;
			const body = state.selected ? BODY_MAP[state.selected] : null;
			goal.current.r = body ? body.view : HOME.r;
			if (!body) {
				goal.current.theta = HOME.theta;
				goal.current.phi = HOME.phi;
			}
		}
		idle.current += step;
		if (!(drag.current?.active || pointers.current.size > 0) && idle.current > 2.4 && !state.selected && !reduced.current && !state.paused) {
			const drift = step * .045 * Math.min(state.speed, 2);
			spherical.current.theta += drift;
			goal.current.theta += drift;
		}
		const response = reduced.current ? 16 : 3.1;
		const k = 1 - Math.exp(-response * step);
		const s = spherical.current;
		const g = goal.current;
		s.r += (g.r - s.r) * k;
		s.theta = lerpAngle(s.theta, g.theta, k);
		s.phi += (g.phi - s.phi) * k;
		const target = state.selected ? worldPos[state.selected] : ORIGIN;
		const follow = 1 - Math.exp(-(reduced.current ? 14 : 5.5) * step);
		focus.current.lerp(target, follow);
		sphericalToVec(s.r, s.theta, s.phi, offset.current);
		camera.position.copy(focus.current).add(offset.current);
		camera.lookAt(focus.current);
	});
	return null;
}
function Lights() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .16 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
		"#c5ccd8",
		"#14161c",
		.28
	] })] });
}
function SolarScene() {
	const textures = (0, import_react.useMemo)(() => getSolarTextures(), []);
	const home = (0, import_react.useMemo)(() => sphericalToVec(HOME.r, HOME.theta, HOME.phi, new Vector3()), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
		className: "stage-canvas",
		camera: {
			fov: 42,
			near: .08,
			far: 260,
			position: [
				home.x,
				home.y,
				home.z
			]
		},
		dpr: [1, 1.6],
		gl: {
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		},
		onCreated: ({ camera, gl }) => {
			camera.lookAt(0, 0, 0);
			gl.setClearColor(SCENE_BG);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
				attach: "background",
				args: [SCENE_BG]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Simulator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lights, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunGlow, { texture: textures.glow }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AsteroidBelt, {}),
			BODIES.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Body, {
				body,
				textures
			}, body.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraRig, {})
		]
	});
}
//#endregion
export { SolarScene };
