import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as ChartColumn, a as Trash2, c as Search, d as Pencil, f as LogOut, g as Film, h as FolderOpen, l as RefreshCw, m as LayoutDashboard, n as Users, o as Shield, p as Link2, r as Upload, s as Settings, t as X, u as Plus } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay$1, c as Slot, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as initializeApp } from "../_libs/@firebase/app+[...].mjs";
import "../_libs/firebase.mjs";
import { a as ref, c as update, i as push, n as getDatabase, o as remove, r as onValue, s as set, t as get } from "../_libs/@firebase/database+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-VSKd-lJ0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatNum(n) {
	const v = Number(n) || 0;
	if (v >= 1e6) return (v / 1e6).toFixed(1).replace(/\.0$/, "") + "M";
	if (v >= 1e3) return (v / 1e3).toFixed(1).replace(/\.0$/, "") + "K";
	return String(v);
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-medium transition-[opacity,transform,background-color,color,border-color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-45 active:scale-[0.98] [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-elevated text-fg border border-border hover:bg-hover",
			ghost: "text-muted hover:bg-hover hover:text-fg",
			danger: "bg-danger-soft text-danger border border-danger/30 hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs rounded-lg",
			icon: "size-11",
			"icon-sm": "size-9 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/60 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 grid w-[min(100%-1.5rem,440px)] max-h-[min(88dvh,720px)] -translate-x-1/2 -translate-y-1/2 gap-4 overflow-y-auto rounded-3xl border border-border bg-surface p-5 shadow-xl duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-3 top-3 flex size-9 items-center justify-center rounded-xl text-muted hover:bg-hover hover:text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1 pr-8", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-lg font-semibold tracking-tight text-fg", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted", className),
		...props
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-11 w-full rounded-xl border border-border bg-elevated px-3.5 text-sm text-fg shadow-none transition-colors placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50", className),
	ref,
	...props
}));
Input.displayName = "Input";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	className: cn("flex min-h-24 w-full rounded-xl border border-border bg-elevated px-3.5 py-3 text-sm text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
	ref,
	...props
}));
Textarea.displayName = "Textarea";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
	ref,
	className: cn("text-xs font-medium text-muted", className),
	...props
}));
Label.displayName = "Label";
var firebaseConfig = {
	apiKey: "AIzaSyAXQOOwUInl8H6ZHvu5kFW1lmEMaSGStBM",
	authDomain: "money-zone-76cad.firebaseapp.com",
	databaseURL: "https://money-zone-76cad-default-rtdb.firebaseio.com",
	projectId: "money-zone-76cad",
	storageBucket: "money-zone-76cad.firebasestorage.app",
	messagingSenderId: "963068060615",
	appId: "1:963068060615:web:8812a83c3f71e89824afe2",
	measurementId: "G-11B7D50J6Y"
};
var app = null;
var db = null;
function getDb() {
	if (typeof window === "undefined") throw new Error("Firebase is browser-only");
	if (!app) app = initializeApp(firebaseConfig);
	if (!db) db = getDatabase(app);
	return db;
}
var AUTH_KEY = "vz_admin_auth_v1";
var IMGBB_API_KEY = "a1d04ab683bb57945ac6c98999b8b6ba";
var IMGBB_UPLOAD_URL = "https://api.imgbb.com/1/upload";
function isLoggedIn() {
	if (typeof window === "undefined") return false;
	try {
		return window.localStorage.getItem(AUTH_KEY) === "1";
	} catch {
		return false;
	}
}
function setLoggedIn(v) {
	try {
		if (v) window.localStorage.setItem(AUTH_KEY, "1");
		else window.localStorage.removeItem(AUTH_KEY);
	} catch {}
}
var NAV = [
	{
		id: "home",
		label: "হোম",
		icon: LayoutDashboard
	},
	{
		id: "videos",
		label: "ভিডিও",
		icon: Film
	},
	{
		id: "links",
		label: "লিংক",
		icon: Link2
	},
	{
		id: "users",
		label: "ইউজার",
		icon: Users
	},
	{
		id: "settings",
		label: "সেটিংস",
		icon: Settings
	}
];
var TITLES = {
	home: {
		title: "ড্যাশবোর্ড",
		sub: "লাইভ স্ট্যাটাস"
	},
	videos: {
		title: "ভিডিও",
		sub: "কন্টেন্ট ও ক্যাটাগরি"
	},
	links: {
		title: "লিংক / টাস্ক",
		sub: "আনলক লিংক ম্যানেজ"
	},
	users: {
		title: "ইউজার",
		sub: "ক্রেডিট ও রেফার"
	},
	settings: {
		title: "সেটিংস",
		sub: "অ্যাডস, পাসওয়ার্ড, অ্যাপ"
	}
};
function AdminApp() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [authed, setAuthed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setAuthed(isLoggedIn());
		setReady(true);
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (!authed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, { onOk: () => setAuthed(true) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { onLogout: () => {
		setLoggedIn(false);
		setAuthed(false);
	} });
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Viral Zone"
			})]
		})
	});
}
function Mark({ size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex items-center justify-center rounded-2xl bg-accent font-display font-semibold text-accent-fg", size === "md" ? "size-14 text-xl" : "size-9 text-sm rounded-xl"),
		children: "VZ"
	});
}
function LoginScreen({ onOk }) {
	const [pass, setPass] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(e) {
		e.preventDefault();
		setErr("");
		setBusy(true);
		try {
			const real = ((await get(ref(getDb(), "settings"))).val() || {}).admin_password || "admin123";
			if (pass === real) {
				setLoggedIn(true);
				onOk();
			} else setErr("পাসওয়ার্ড ভুল।");
		} catch {
			setErr("সার্ভারে কানেক্ট করা যায়নি।");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "w-full max-w-[400px] rounded-3xl border border-border bg-surface p-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex flex-col items-center text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-display text-xl font-semibold tracking-tight",
							children: "Viral Zone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "অ্যাডমিন প্যানেল"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 rounded-2xl bg-elevated px-3.5 py-3 text-xs leading-relaxed text-muted",
					children: "একবার লগইন করলে এই ফোনে সেভ থাকবে। ফোন লক করলেও অ্যাপ আবার পাসওয়ার্ড চাইবে না।"
				}),
				err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-danger",
					children: err
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "adminPass",
					children: "অ্যাডমিন পাসওয়ার্ড"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "adminPass",
					type: "password",
					autoComplete: "current-password",
					value: pass,
					onChange: (e) => setPass(e.target.value),
					className: "mt-1.5",
					placeholder: "পাসওয়ার্ড লিখুন"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "mt-4 w-full",
					disabled: busy,
					children: busy ? "চেক হচ্ছে…" : "লগইন"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-center text-xs text-subtle",
					children: ["ডিফল্ট পাসওয়ার্ড ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "admin123"
					})]
				})
			]
		})
	});
}
function Shell({ onLogout }) {
	const [page, setPage] = (0, import_react.useState)("home");
	const [videoTab, setVideoTab] = (0, import_react.useState)("list");
	const [settings, setSettings] = (0, import_react.useState)({});
	const [videos, setVideos] = (0, import_react.useState)({});
	const [filters, setFilters] = (0, import_react.useState)({});
	const [links, setLinks] = (0, import_react.useState)({});
	const [users, setUsers] = (0, import_react.useState)({});
	const [connected, setConnected] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const db = getDb();
		const unsubs = [
			onValue(ref(db, "settings"), (s) => {
				setSettings(s.val() || {});
				setConnected(true);
			}),
			onValue(ref(db, "videos"), (s) => setVideos(s.val() || {})),
			onValue(ref(db, "filters"), (s) => setFilters(s.val() || {})),
			onValue(ref(db, "links"), (s) => setLinks(s.val() || {})),
			onValue(ref(db, "users"), (s) => setUsers(s.val() || {}))
		];
		return () => unsubs.forEach((u) => u());
	}, []);
	const meta = TITLES[page];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden w-[220px] shrink-0 flex-col border-r border-border bg-surface md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5 px-4 py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { size: "sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-sm font-semibold leading-none",
							children: "Viral Zone"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-[11px] text-muted",
							children: "Admin"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-0.5 px-2",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							item,
							active: page === item.id,
							onClick: () => setPage(item.id)
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-border p-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onLogout,
							className: "flex h-11 w-full items-center gap-2.5 rounded-xl px-3 text-sm text-muted hover:bg-hover hover:text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "লগআউট"]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 backdrop-blur-sm md:h-16 md:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate font-display text-base font-semibold tracking-tight md:text-lg",
							children: meta.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-xs text-muted md:block",
							children: meta.sub
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("hidden rounded-full px-2 py-0.5 text-[10px] font-medium md:inline", connected ? "bg-ok-soft text-ok" : "bg-hover text-muted"),
							children: connected ? "লাইভ" : "কানেক্ট…"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "রিফ্রেশ",
							onClick: () => toast("ডেটা আপডেট হচ্ছে"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" })
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 px-4 pb-[calc(5.5rem+env(safe-area-inset-bottom))] pt-5 md:px-6 md:pb-10",
					children: [
						page === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {
							videos,
							users,
							filters,
							links,
							settings,
							go: setPage
						}),
						page === "videos" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideosPage, {
							tab: videoTab,
							setTab: setVideoTab,
							videos,
							filters
						}),
						page === "links" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinksPage, { links }),
						page === "users" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersPage, { users }),
						page === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, {
							settings,
							onLogout
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-5",
					children: NAV.map((item) => {
						const Icon = item.icon;
						const active = page === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setPage(item.id),
							className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] font-medium", active ? "text-accent" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.2 : 1.8
							}), item.label]
						}, item.id);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-center",
				toastOptions: { className: "!bg-elevated !text-fg !border-border !font-[Hind_Siliguri]" }
			})
		]
	});
}
function NavBtn({ item, active, onClick }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-11 items-center gap-2.5 rounded-xl px-3 text-sm font-medium", active ? "bg-accent text-accent-fg" : "text-muted hover:bg-hover hover:text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-display text-2xl font-semibold tabular-nums tracking-tight",
			children: value
		})]
	});
}
function Dashboard({ videos, users, filters, links, settings, go }) {
	const vidList = Object.entries(videos);
	const userList = Object.entries(users);
	const totalViews = vidList.reduce((a, [, v]) => a + (Number(v.view_count) || 0), 0);
	const totalRefers = userList.reduce((a, [, u]) => a + (Number(u.total_refers) || 0), 0);
	const appId = String(settings.bengal_ads_app_id || "");
	const fmtId = String(settings.bengal_ads_format_id || "");
	const adsOk = /^tma_[a-f0-9]{40}$/.test(appId) && /^int_[a-f0-9]{40}$/.test(fmtId);
	const top = vidList.map(([id, v]) => ({
		id,
		...v
	})).sort((a, b) => (Number(b.view_count) || 0) - (Number(a.view_count) || 0)).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "ভিডিও",
						value: vidList.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "ইউজার",
						value: userList.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "ক্যাটাগরি",
						value: Object.keys(filters).length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "লিংক",
						value: Object.keys(links).length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "মোট ভিউ",
						value: formatNum(totalViews)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "রেফার",
						value: formatNum(totalRefers)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "BengalAds"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => go("settings"),
						children: "সেটিংস"
					})]
				}), adsOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ok",
					children: "কনফিগারড · অ্যাপ ও ফরম্যাট আইডি সেট আছে"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: "এখনো সেট করা হয়নি"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "টপ ভিউড"
					})]
				}), top.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "কোনো ভিডিও নেই" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border",
					children: top.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 py-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-6 text-xs tabular-nums text-subtle",
								children: i + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate text-sm",
								children: v.name || v.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tabular-nums text-muted",
								children: formatNum(v.view_count || 0)
							})
						]
					}, v.id))
				})]
			})
		]
	});
}
function Empty({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-10 text-center text-sm text-muted",
		children: text
	});
}
function VideosPage({ tab, setTab, videos, filters }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [catOpen, setCatOpen] = (0, import_react.useState)(false);
	const [catEdit, setCatEdit] = (0, import_react.useState)(null);
	const list = (0, import_react.useMemo)(() => {
		const qq = q.toLowerCase();
		return Object.entries(videos).map(([id, v]) => ({
			id,
			...v
		})).filter((v) => !qq || String(v.name || "").toLowerCase().includes(qq)).sort((a, b) => (Number(b.created_at) || 0) - (Number(a.created_at) || 0));
	}, [videos, q]);
	const catName = (0, import_react.useCallback)((cid) => {
		if (!cid) return "—";
		return Object.values(filters).find((x) => (x.id || "") === cid)?.name || cid;
	}, [filters]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center gap-1 rounded-2xl bg-elevated p-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab("list"),
				className: cn("h-9 flex-1 rounded-xl text-sm font-medium", tab === "list" ? "bg-surface text-fg shadow-sm" : "text-muted"),
				children: "ভিডিও"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab("cats"),
				className: cn("h-9 flex-1 rounded-xl text-sm font-medium", tab === "cats" ? "bg-surface text-fg shadow-sm" : "text-muted"),
				children: "ক্যাটাগরি"
			})]
		}), tab === "list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "ভিডিও সার্চ…",
						className: "pl-9"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						setEditId(null);
						setOpen(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "নতুন"]
				})]
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "কোনো ভিডিও নেই" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: list.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-2xl border border-border bg-surface p-3",
					children: [
						v.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: v.image_url,
							alt: "",
							className: "size-14 rounded-xl object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-14 items-center justify-center rounded-xl bg-elevated text-subtle",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-medium",
								children: v.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-0.5 flex flex-wrap gap-2 text-[11px] text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: catName(v.category) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"· ",
										v.ad_watches_required || 1,
										" ধাপ"
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums",
										children: [
											"· ",
											formatNum(v.view_count || 0),
											" ভিউ"
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								"aria-label": "এডিট",
								onClick: () => {
									setEditId(v.id);
									setOpen(true);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								"aria-label": "ডিলিট",
								onClick: async () => {
									if (!window.confirm("এই ভিডিও ডিলিট করবেন?")) return;
									try {
										await remove(ref(getDb(), "videos/" + v.id));
										toast("ডিলিট হয়েছে");
									} catch {
										toast.error("ডিলিট ব্যর্থ");
									}
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})]
						})
					]
				}, v.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoDialog, {
				open,
				onOpenChange: setOpen,
				editId,
				videos,
				filters
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						setCatEdit(null);
						setCatOpen(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "ক্যাটাগরি"]
				})
			}),
			Object.keys(filters).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "কোনো ক্যাটাগরি নেই" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: Object.entries(filters).map(([key, f]) => {
					const fid = f.id || key;
					const count = Object.values(videos).filter((v) => v.category === fid).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 rounded-2xl border border-border bg-surface px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-4 text-muted" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: f.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-muted",
									children: [
										fid,
										" · ",
										count,
										" ভিডিও"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								onClick: () => {
									setCatEdit(key);
									setCatOpen(true);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								onClick: async () => {
									if (!window.confirm("ক্যাটাগরি ডিলিট?")) return;
									try {
										await remove(ref(getDb(), "filters/" + key));
										toast("ডিলিট");
									} catch {
										toast.error("ব্যর্থ");
									}
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})
						]
					}, key);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryDialog, {
				open: catOpen,
				onOpenChange: setCatOpen,
				editKey: catEdit,
				filters
			})
		] })]
	});
}
function VideoDialog({ open, onOpenChange, editId, videos, filters }) {
	const [name, setName] = (0, import_react.useState)("");
	const [image, setImage] = (0, import_react.useState)("");
	const [download, setDownload] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	const [adReq, setAdReq] = (0, import_react.useState)("1");
	const [duration, setDuration] = (0, import_react.useState)("");
	const [views, setViews] = (0, import_react.useState)("0");
	const [uploading, setUploading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const v = editId ? videos[editId] : void 0;
		setName(v?.name || "");
		setImage(v?.image_url || "");
		setDownload(v?.download_link || "");
		setCategory(v?.category || "");
		setAdReq(String(v?.ad_watches_required || 1));
		setDuration(String(v?.duration ?? v?.duration_sec ?? ""));
		setViews(String(v?.view_count || 0));
	}, [
		open,
		editId,
		videos
	]);
	async function onFile(file) {
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			toast.error("শুধু ইমেজ");
			return;
		}
		setUploading(true);
		try {
			const fd = new FormData();
			fd.append("key", IMGBB_API_KEY);
			fd.append("image", file);
			const json = await (await fetch(IMGBB_UPLOAD_URL, {
				method: "POST",
				body: fd
			})).json();
			if (json.success && json.data?.url) {
				setImage(json.data.url);
				toast("থাম্বনেইল আপলোড হয়েছে");
			} else throw new Error(json.error?.message || "fail");
		} catch {
			toast.error("আপলোড ব্যর্থ");
		} finally {
			setUploading(false);
		}
	}
	async function save() {
		if (!name.trim() || !image.trim() || !download.trim()) {
			toast.error("নাম, ইমেজ ও ডাউনলোড লিংক আবশ্যক");
			return;
		}
		const data = {
			name: name.trim(),
			image_url: image.trim(),
			download_link: download.trim(),
			category: category || "",
			ad_watches_required: Math.max(1, parseInt(adReq, 10) || 1),
			duration: duration.trim(),
			view_count: Math.max(0, parseInt(views, 10) || 0)
		};
		try {
			if (editId) {
				const prev = videos[editId] || {};
				await update(ref(getDb(), "videos/" + editId), {
					...data,
					created_at: prev.created_at || Date.now()
				});
				toast("ভিডিও আপডেট হয়েছে");
			} else {
				await push(ref(getDb(), "videos"), {
					...data,
					created_at: Date.now()
				});
				toast("নতুন ভিডিও যোগ হয়েছে");
			}
			onOpenChange(false);
		} catch {
			toast.error("সেভ ব্যর্থ");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editId ? "ভিডিও এডিট" : "নতুন ভিডিও" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "থাম্বনেইল আপলোড বা URL দিন।" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "নাম",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "থাম্বনেইল URL",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: image,
						onChange: (e) => setImage(e.target.value)
					})
				}),
				image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: image,
					alt: "",
					className: "h-28 w-full rounded-xl object-cover"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-11 cursor-pointer items-center justify-center gap-2 rounded-xl border border-border bg-elevated text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }),
						uploading ? "আপলোড হচ্ছে…" : "ছবি আপলোড",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: "hidden",
							onChange: (e) => onFile(e.target.files?.[0])
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "ডাউনলোড লিংক",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: download,
						onChange: (e) => setDownload(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "ক্যাটাগরি",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: category,
						onChange: (e) => setCategory(e.target.value),
						className: "flex h-11 w-full rounded-xl border border-border bg-elevated px-3.5 text-sm text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "— সিলেক্ট —"
						}), Object.entries(filters).map(([key, f]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: f.id || key,
							children: f.name || f.id || key
						}, key))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "ধাপ",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								max: 20,
								value: adReq,
								onChange: (e) => setAdReq(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "দৈর্ঘ্য",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: duration,
								onChange: (e) => setDuration(e.target.value),
								placeholder: "3:45"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "ভিউ",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 0,
								value: views,
								onChange: (e) => setViews(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: save,
					className: "mt-1",
					children: "সেভ করুন"
				})
			]
		})] })
	});
}
function CategoryDialog({ open, onOpenChange, editKey, filters }) {
	const [id, setId] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const f = editKey ? filters[editKey] : void 0;
		setId(f?.id || editKey || "");
		setName(f?.name || "");
	}, [
		open,
		editKey,
		filters
	]);
	async function save() {
		const nid = id.trim().replace(/\s+/g, "_").toLowerCase();
		const nname = name.trim();
		if (!nid || !nname) {
			toast.error("আইডি ও নাম আবশ্যক");
			return;
		}
		try {
			if (editKey) await update(ref(getDb(), "filters/" + editKey), {
				id: nid,
				name: nname
			});
			else await push(ref(getDb(), "filters"), {
				id: nid,
				name: nname
			});
			toast("সেভ হয়েছে");
			onOpenChange(false);
		} catch {
			toast.error("সেভ ব্যর্থ");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editKey ? "ক্যাটাগরি এডিট" : "নতুন ক্যাটাগরি" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "আইডি",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: id,
					onChange: (e) => setId(e.target.value),
					disabled: !!editKey
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "ডিসপ্লে নাম",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					onChange: (e) => setName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				children: "সেভ"
			})
		] })
	});
}
function LinksPage({ links }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editKey, setEditKey] = (0, import_react.useState)(null);
	const [title, setTitle] = (0, import_react.useState)("");
	const [url, setUrl] = (0, import_react.useState)("");
	function start(key) {
		const l = key ? links[key] : void 0;
		setEditKey(key);
		setTitle(l?.title || "");
		setUrl(l?.url || "");
		setOpen(true);
	}
	async function save() {
		if (!title.trim() || !url.trim()) {
			toast.error("টাইটেল ও URL আবশ্যক");
			return;
		}
		try {
			if (editKey) await update(ref(getDb(), "links/" + editKey), {
				title: title.trim(),
				url: url.trim()
			});
			else await push(ref(getDb(), "links"), {
				title: title.trim(),
				url: url.trim()
			});
			toast("সেভ হয়েছে");
			setOpen(false);
		} catch {
			toast.error("সেভ ব্যর্থ");
		}
	}
	const list = Object.entries(links);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => start(null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "নতুন লিংক"]
				})
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "কোনো লিংক নেই" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: list.map(([key, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-2xl border border-border bg-surface px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: l.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate font-mono text-[11px] text-muted",
								children: l.url
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							onClick: () => start(key),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							onClick: async () => {
								if (!window.confirm("লিংক ডিলিট?")) return;
								try {
									await remove(ref(getDb(), "links/" + key));
									toast("ডিলিট");
								} catch {
									toast.error("ব্যর্থ");
								}
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				}, key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editKey ? "লিংক এডিট" : "নতুন লিংক" }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "টাইটেল",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: title,
							onChange: (e) => setTitle(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "URL",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: url,
							onChange: (e) => setUrl(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						children: "সেভ"
					})
				] })
			})
		]
	});
}
function UsersPage({ users }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [credits, setCredits] = (0, import_react.useState)("0");
	const list = (0, import_react.useMemo)(() => {
		const qq = q.toLowerCase();
		return Object.entries(users).map(([id, u]) => ({
			id,
			...u
		})).filter((u) => !qq || String(u.first_name || "").toLowerCase().includes(qq) || String(u.id).includes(qq)).sort((a, b) => (Number(b.total_refers) || 0) - (Number(a.total_refers) || 0)).slice(0, 200);
	}, [users, q]);
	async function saveCredits() {
		if (!editId) return;
		const n = parseInt(credits, 10);
		if (isNaN(n) || n < 0) {
			toast.error("সঠিক সংখ্যা দিন");
			return;
		}
		try {
			await update(ref(getDb(), "users/" + editId), { unlock_credits: n });
			toast("ক্রেডিট আপডেট: " + n);
			setEditId(null);
		} catch {
			toast.error("ব্যর্থ");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "নাম বা ID…",
					className: "pl-9"
				})]
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "কোনো ইউজার নেই" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: list.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-2xl border border-border bg-surface px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: u.first_name || "User"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate font-mono text-[11px] text-muted",
								children: u.id
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold tabular-nums text-accent",
								children: Number(u.unlock_credits) || 0
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-muted",
								children: [
									Number(u.total_refers) || 0,
									" রেফার · ",
									Number(u.total_unlocked) || 0,
									" আনলক"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => {
								setEditId(String(u.id));
								setCredits(String(Number(u.unlock_credits) || 0));
							},
							children: "ক্রেডিট"
						})
					]
				}, u.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!editId,
				onOpenChange: (v) => !v && setEditId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "ক্রেডিট আপডেট" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "font-mono",
						children: editId
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "নতুন ক্রেডিট",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							value: credits,
							onChange: (e) => setCredits(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: saveCredits,
						children: "সেভ"
					})
				] })
			})
		]
	});
}
function SettingsPage({ settings, onLogout }) {
	const [appId, setAppId] = (0, import_react.useState)("");
	const [formatId, setFormatId] = (0, import_react.useState)("");
	const [adsLimit, setAdsLimit] = (0, import_react.useState)("20");
	const [bot, setBot] = (0, import_react.useState)("");
	const [tutorial, setTutorial] = (0, import_react.useState)("");
	const [p1, setP1] = (0, import_react.useState)("");
	const [p2, setP2] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setAppId(String(settings.bengal_ads_app_id || ""));
		setFormatId(String(settings.bengal_ads_format_id || ""));
		setAdsLimit(String(settings.ads_limit ?? 20));
		setBot(String(settings.bot_app_link || ""));
		setTutorial(String(settings.tutorial_id || ""));
	}, [settings]);
	async function save() {
		if (appId && !/^tma_[a-f0-9]{40}$/.test(appId)) {
			toast.error("App ID ফরম্যাট ভুল");
			return;
		}
		if (formatId && !/^int_[a-f0-9]{40}$/.test(formatId)) {
			toast.error("Format ID ফরম্যাট ভুল");
			return;
		}
		if (p1 || p2) {
			if (p1 !== p2) {
				toast.error("পাসওয়ার্ড মিলছে না");
				return;
			}
			if (p1.length < 4) {
				toast.error("কমপক্ষে ৪ অক্ষর");
				return;
			}
		}
		const payload = {
			...settings,
			bengal_ads_app_id: appId.trim(),
			bengal_ads_format_id: formatId.trim(),
			ads_limit: Math.max(1, parseInt(adsLimit, 10) || 20),
			bot_app_link: bot.trim(),
			tutorial_id: tutorial.trim()
		};
		if (p1) payload.admin_password = p1;
		try {
			await set(ref(getDb(), "settings"), payload);
			await set(ref(getDb(), "ads_config"), {
				bengal_ads_app_id: appId.trim(),
				bengal_ads_format_id: formatId.trim()
			});
			toast("সেটিংস সেভ হয়েছে");
			setP1("");
			setP2("");
		} catch {
			toast.error("সেভ ব্যর্থ");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "সেশন"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: "লগইন এই ফোনে সেভ থাকে। ফোন লক বা অ্যাপ বন্ধ করে আবার খুললে পাসওয়ার্ড চাইবে না — শুধু লগআউট করলেই নতুন করে লগইন লাগবে।"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-4 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "BengalAds"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "bengal_ads_app_id",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: appId,
							onChange: (e) => setAppId(e.target.value),
							className: "font-mono text-xs"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "bengal_ads_format_id",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: formatId,
							onChange: (e) => setFormatId(e.target.value),
							className: "font-mono text-xs"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-4 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "অ্যাপ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "দৈনিক অ্যাড লিমিট",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 1,
							max: 200,
							value: adsLimit,
							onChange: (e) => setAdsLimit(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "বট অ্যাপ লিংক",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: bot,
							onChange: (e) => setBot(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "টিউটোরিয়াল Embed URL",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: tutorial,
							onChange: (e) => setTutorial(e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-4 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "অ্যাডমিন পাসওয়ার্ড"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "নতুন পাসওয়ার্ড",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							value: p1,
							onChange: (e) => setP1(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "কনফার্ম",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							value: p2,
							onChange: (e) => setP2(e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				className: "w-full",
				children: "সব সেটিংস সেভ"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "danger",
				className: "w-full",
				onClick: onLogout,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "লগআউট"]
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminApp, {});
}
//#endregion
export { Home as component };
