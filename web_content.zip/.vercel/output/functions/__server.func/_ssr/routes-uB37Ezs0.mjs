import { b as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as useFlock, _ as herdStats, f as daysFromToday, g as formatKg, h as formatInt, k as useHydrated, m as formatDate, p as daysLabel, t as AppShell, u as cn, w as sheepName } from "./store-g4o8WGZx.mjs";
import { t as Card } from "./card-DKPDfbAA.mjs";
import { n as buttonVariants } from "./button-C77Erh3S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-uB37Ezs0.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const hydrated = useHydrated();
	const herdName = useFlock((s) => s.herdName);
	const sheep = useFlock((s) => s.sheep);
	const breeding = useFlock((s) => s.breeding);
	const health = useFlock((s) => s.health);
	const weights = useFlock((s) => s.weights);
	const loadSample = useFlock((s) => s.loadSample);
	const stats = herdStats(sheep, breeding);
	const due = breeding.filter((b) => b.result === "pending").map((b) => ({
		b,
		ewe: sheep.find((s) => s.id === b.eweId)
	})).filter((row) => row.ewe).sort((a, b) => a.b.expectedDate.localeCompare(b.b.expectedDate));
	const activity = [
		...health.map((h) => ({
			id: h.id,
			date: h.date,
			title: h.title,
			meta: sheepName(sheep.find((s) => s.id === h.sheepId)),
			href: h.sheepId ? h.sheepId : null
		})),
		...breeding.map((b) => ({
			id: b.id,
			date: b.closedDate || b.matingDate,
			title: b.result === "pending" ? "تلقيح" : b.result === "lambed" ? `ولادة · ${formatInt(b.lambCount ?? 0)}` : "حمل مفقود",
			meta: sheepName(sheep.find((s) => s.id === b.eweId), "نعجة"),
			href: b.eweId
		})),
		...weights.map((w) => ({
			id: w.id,
			date: w.date,
			title: `وزن ${formatKg(w.kg)}`,
			meta: sheepName(sheep.find((s) => s.id === w.sheepId), "رأس"),
			href: w.sheepId
		}))
	].sort((a, b) => a.date < b.date ? 1 : -1).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: hydrated ? herdName : "قطيعي",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/sheep/new",
			className: "text-sm font-medium",
			children: "إضافة"
		}),
		children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "يُفتح السجل…"
		}) : sheep.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "لا رؤوس في السجل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-normal text-muted-foreground",
					children: "ابدأ برقم الحلقة. السجل يبقى على هذا الجهاز، ويمكنك تصدير نسخة من الإعدادات."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sheep/new",
					className: cn(buttonVariants(), "w-full"),
					children: "أضف رأساً"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: loadSample,
					className: "h-11 text-sm text-muted-foreground",
					children: "تعبئة قطيع مثال"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "في الحظيرة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-5xl font-semibold tabular-nums tracking-tight",
						children: formatInt(stats.total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: [
							"خارجها ",
							formatInt(stats.archive),
							stats.avg != null ? ` · متوسط الوزن ${formatKg(stats.avg)}` : ""
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "grid grid-cols-2 gap-x-4 gap-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "كباش",
							value: stats.rams,
							to: "/flock",
							search: { f: "ram" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "نعاج",
							value: stats.ewes,
							to: "/flock",
							search: { f: "ewe" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "صغار",
							value: stats.lambs,
							to: "/flock",
							search: { f: "lamb" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "حوامل",
							value: stats.pregnant,
							to: "/flock",
							search: { f: "pregnant" }
						})
					]
				}),
				stats.sick > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/flock",
					search: { f: "sick" },
					className: "flex items-center justify-between rounded-2xl border border-border px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-danger",
						children: "مرضى في القطيع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium tabular-nums",
						children: formatInt(stats.sick)
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium text-muted-foreground",
						children: "أقرب الولادات"
					}), due.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "لا حمل قائم. سجّل تلقيحاً من السجلات أو من بطاقة النعجة."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "px-4 py-1",
						children: due.slice(0, 5).map(({ b, ewe }) => {
							const days = daysFromToday(b.expectedDate);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/sheep/$id",
								params: { id: ewe.id },
								className: "flex items-center justify-between gap-3 border-b border-border py-3 last:border-b-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium tabular-nums",
									children: ewe.tag
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: formatDate(b.expectedDate)
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("text-sm tabular-nums", days < 0 && "text-danger"),
									children: daysLabel(days)
								})]
							}, b.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-muted-foreground",
							children: "آخر ما سُجّل"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/log",
							className: "text-sm text-muted-foreground",
							children: "السجلات"
						})]
					}), activity.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "لا سجلات بعد. الوزن والعلاج والتلقيح تظهر هنا."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "px-4 py-1",
						children: activity.map((item) => {
							const row = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-medium",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: item.meta
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-sm text-muted-foreground tabular-nums",
								children: formatDate(item.date)
							})] });
							const className = "flex items-center justify-between gap-3 border-b border-border py-3 last:border-b-0";
							return item.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/sheep/$id",
								params: { id: item.href },
								className,
								children: row
							}, item.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className,
								children: row
							}, item.id);
						})
					})]
				})
			]
		})
	});
}
function Stat({ label, value, to, search }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		search,
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-2xl font-semibold tabular-nums",
			children: formatInt(value)
		})]
	});
}
//#endregion
export { Home as component };
