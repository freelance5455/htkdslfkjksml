import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LoaderCircle, i as RotateCcw, o as Copy, r as Trash2, s as Check, t as Volume2 } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ACHg9OCX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var translateMessage = createServerFn({ method: "POST" }).validator((input) => ({ text: typeof input?.text === "string" ? input.text : "" })).handler(createSsrRpc("2d8ccda29d54bae8673efff69d6f26db8a1803f79d1dd69a9ed2e7ecc7c81ef2"));
var SEEDS = [
	{
		id: "seed-maya",
		sender: "Maya",
		original: "Running ten minutes late. Grab me a coffee if you're already there?",
		arabic: "سأتأخر عشر دقائق. أحضر لي قهوة إن كنت هناك قبلي.",
		language: "الإنجليزية",
		timeLabel: "٢:٤٤ م",
		status: "ready",
		sample: true,
		unchanged: false
	},
	{
		id: "seed-luc",
		sender: "Luc",
		original: "Le colis est arrivé. Tu peux passer le récupérer ce soir après 19h ?",
		arabic: "وصل الطرد. هل يمكنك المرور لأخذه الليلة بعد السابعة؟",
		language: "الفرنسية",
		timeLabel: "١:١٥ م",
		status: "ready",
		sample: true,
		unchanged: false
	},
	{
		id: "seed-jonas",
		sender: "Jonas",
		original: "Der Termin wurde auf morgen 9:30 verschoben. Bitte kurz bestätigen.",
		arabic: "تم تأجيل الموعد إلى الغد الساعة ٩:٣٠. أكّد باختصار من فضلك.",
		language: "الألمانية",
		timeLabel: "١١:٠٢ ص",
		status: "ready",
		sample: true,
		unchanged: false
	}
];
var LIVE_DEMOS = [
	{
		sender: "Sofia",
		text: "¡Feliz cumpleaños! Te esperamos a las ocho en casa. No traigas nada."
	},
	{
		sender: "Aylin",
		text: "Toplantı on beş dakika gecikecek. Sen başla, ben yetişirim."
	},
	{
		sender: "Yuki",
		text: "今日の夜、駅前で会える？少し遅れそう。"
	},
	{
		sender: "Noah",
		text: "Can you send me the address again? I'm outside and I don't see the building."
	}
];
var MAX_MESSAGES = 30;
var useInbox = create()(persist((set) => ({
	messages: SEEDS,
	activeId: SEEDS[0]?.id ?? "",
	add: (message) => set((state) => ({
		messages: [message, ...state.messages].slice(0, MAX_MESSAGES),
		activeId: message.id
	})),
	patch: (id, partial) => set((state) => ({ messages: state.messages.map((message) => message.id === id ? {
		...message,
		...partial
	} : message) })),
	remove: (id) => set((state) => {
		const messages = state.messages.filter((message) => message.id !== id);
		return {
			messages,
			activeId: state.activeId === id ? messages[0]?.id ?? "" : state.activeId
		};
	}),
	clear: () => set({
		messages: [],
		activeId: ""
	}),
	setActive: (id) => set({ activeId: id })
}), {
	name: "warid-inbox-v1",
	skipHydration: true,
	partialize: (state) => ({
		messages: state.messages,
		activeId: state.activeId
	})
}));
var MAX_CHARS = 4e3;
function timeLabel() {
	return new Intl.DateTimeFormat("ar", {
		hour: "numeric",
		minute: "2-digit",
		numberingSystem: "arab"
	}).format(/* @__PURE__ */ new Date());
}
async function translateInto(id, text) {
	try {
		const result = await translateMessage({ data: { text } });
		if (!result.ok) {
			useInbox.getState().patch(id, {
				status: "error",
				error: result.error
			});
			return;
		}
		useInbox.getState().patch(id, {
			status: "ready",
			arabic: result.arabic,
			language: result.language,
			unchanged: result.unchanged,
			error: void 0
		});
	} catch {
		useInbox.getState().patch(id, {
			status: "error",
			error: "تعذّرت الترجمة. حاول مرة أخرى."
		});
	}
}
async function enqueueIncoming(text, sender) {
	const clean = text.replace(/\r\n/g, "\n").trim();
	if (!clean) return;
	const message = {
		id: crypto.randomUUID(),
		sender: sender?.trim() || "غير معروف",
		original: clean.slice(0, MAX_CHARS),
		arabic: "",
		language: "",
		timeLabel: timeLabel(),
		status: "translating",
		sample: false,
		unchanged: false
	};
	if (clean.length > MAX_CHARS) {
		useInbox.getState().add({
			...message,
			status: "error",
			error: "الرسالة طويلة. الحد ٤٠٠٠ حرف."
		});
		return;
	}
	useInbox.getState().add(message);
	await translateInto(message.id, clean);
}
async function retryIncoming(id) {
	const message = useInbox.getState().messages.find((item) => item.id === id);
	if (!message || message.status === "translating") return;
	useInbox.getState().patch(id, {
		status: "translating",
		error: void 0
	});
	await translateInto(id, message.original);
}
function Home() {
	const messages = useInbox((state) => state.messages);
	const activeId = useInbox((state) => state.activeId);
	const setActive = useInbox((state) => state.setActive);
	const remove = useInbox((state) => state.remove);
	const clear = useInbox((state) => state.clear);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [sender, setSender] = (0, import_react.useState)("");
	const [copiedId, setCopiedId] = (0, import_react.useState)(null);
	const [armClear, setArmClear] = (0, import_react.useState)(false);
	const demoCursor = (0, import_react.useRef)(0);
	const lastSubmit = (0, import_react.useRef)({
		text: "",
		at: 0
	});
	const active = messages.find((message) => message.id === activeId) ?? null;
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			await useInbox.persist.rehydrate();
			if (cancelled) return;
			const params = new URLSearchParams(window.location.search);
			const text = params.get("text")?.trim();
			if (!text) return;
			const from = params.get("from")?.trim() ?? "";
			const url = new URL(window.location.href);
			url.searchParams.delete("text");
			url.searchParams.delete("from");
			window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
			if (from) setSender(from);
			await enqueueIncoming(text, from);
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!armClear) return;
		const timer = window.setTimeout(() => setArmClear(false), 3e3);
		return () => window.clearTimeout(timer);
	}, [armClear]);
	function submit(text, from = sender) {
		const clean = text.trim();
		const now = Date.now();
		if (!clean) return;
		if (lastSubmit.current.text === clean && now - lastSubmit.current.at < 800) return;
		lastSubmit.current = {
			text: clean,
			at: now
		};
		setDraft("");
		enqueueIncoming(clean, from);
	}
	function insertDemo() {
		const demo = LIVE_DEMOS[demoCursor.current % LIVE_DEMOS.length];
		if (!demo) return;
		demoCursor.current += 1;
		setSender(demo.sender);
		submit(demo.text, demo.sender);
	}
	async function copyArabic(message) {
		if (!message.arabic) return;
		try {
			await navigator.clipboard.writeText(message.arabic);
			setCopiedId(message.id);
			window.setTimeout(() => {
				setCopiedId((current) => current === message.id ? null : current);
			}, 1600);
		} catch {
			setCopiedId(null);
		}
	}
	function speak(text) {
		if (!text || typeof window === "undefined" || !window.speechSynthesis) return;
		const utterance = new SpeechSynthesisUtterance(text);
		utterance.lang = "ar-SA";
		utterance.rate = .95;
		window.speechSynthesis.cancel();
		window.speechSynthesis.speak(utterance);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 sm:py-8 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-14 shrink-0 place-items-center rounded-card bg-ink font-display text-3xl leading-none text-paper",
					children: "و"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl leading-none",
						children: "وارد"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm leading-6 text-ink/70 sm:text-base",
						children: "الصق أي رسالة تصلك — نصية أو واتساب أو بريد — لتراها بالعربية فوراً."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "contents lg:col-span-1 lg:grid lg:gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "order-1 grid gap-3 rounded-card border border-ink/10 bg-paper p-4 shadow-lift lg:order-none",
						onSubmit: (event) => {
							event.preventDefault();
							submit(draft);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "incoming",
									className: "text-sm font-semibold",
									children: "رسالة واردة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "incoming",
									value: draft,
									dir: "auto",
									rows: 4,
									maxLength: 4e3,
									placeholder: "الصق هنا الرسالة كما وصلتك…",
									onChange: (event) => setDraft(event.target.value),
									onPaste: (event) => {
										const text = event.clipboardData.getData("text").trim();
										if (!text) return;
										event.preventDefault();
										submit(text);
									},
									className: "min-h-24 w-full resize-y rounded-control border border-ink/15 bg-sand px-3 py-3 text-base leading-7 outline-none placeholder:text-ink/50 focus-visible:ring-2 focus-visible:ring-accent"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "sender",
										className: "text-sm font-semibold",
										children: "المرسل"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "sender",
										value: sender,
										dir: "auto",
										maxLength: 40,
										placeholder: "اختياري",
										onChange: (event) => setSender(event.target.value),
										className: "min-h-11 w-full rounded-control border border-ink/15 bg-sand px-3 text-base outline-none placeholder:text-ink/50 focus-visible:ring-2 focus-visible:ring-accent"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: !draft.trim(),
									className: "inline-flex min-h-11 items-center justify-center rounded-control bg-accent px-5 text-base font-semibold text-paper transition-opacity disabled:opacity-40",
									children: "ترجم الآن"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-ink/60",
									children: "تُترجم فور اللصق، ومن أي لغة."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: insertDemo,
									className: "inline-flex min-h-11 items-center rounded-control border border-ink/15 px-3 text-sm font-medium",
									children: "جرّب رسالة واردة"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "order-3 grid gap-3 lg:order-none",
						"aria-label": "الوارد",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 px-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-base font-semibold",
									children: "الوارد"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-ink/60 tabular-nums",
									children: messages.length
								})]
							}),
							messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-card border border-dashed border-ink/20 px-4 py-8 text-center text-sm text-ink/70",
								children: "صندوقك فارغ. الصق أول رسالة لتبدأ."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid gap-2 lg:max-h-96 lg:overflow-y-auto lg:pe-1",
								children: messages.map((message) => {
									const selected = message.id === activeId;
									const preview = message.status === "ready" ? message.arabic : message.status === "error" ? "تعذّرت الترجمة" : "تُترجم الآن…";
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `flex items-start gap-2 rounded-card border bg-paper p-3 ${selected ? "border-accent shadow-lift" : "border-ink/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setActive(message.id),
											className: "flex min-w-0 flex-1 items-start gap-3 text-start",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "grid size-11 shrink-0 place-items-center rounded-control bg-ink font-display text-xl leading-none text-paper",
												children: monogram(message.sender)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "min-w-0",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															dir: "auto",
															className: "truncate font-semibold",
															children: message.sender
														}), message.status === "translating" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
															className: "size-4 shrink-0 motion-safe:animate-spin",
															"aria-hidden": true
														}) : null]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "mt-1 line-clamp-2 block text-sm leading-6",
														children: preview
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														dir: "auto",
														className: "mt-1 line-clamp-1 block text-sm text-ink/60",
														children: message.original
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "mt-1 block text-sm text-ink/60",
														children: [
															message.sample ? "مثال" : message.language || "جديد",
															" · ",
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "tabular-nums",
																children: message.timeLabel
															})
														]
													})
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": `حذف رسالة ${message.sender}`,
											onClick: () => remove(message.id),
											className: "grid size-11 shrink-0 place-items-center rounded-control text-ink/70 hover:bg-sand",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
										})]
									}) }, message.id);
								})
							}),
							messages.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									if (!armClear) {
										setArmClear(true);
										return;
									}
									clear();
									setArmClear(false);
								},
								className: "min-h-11 justify-self-start px-1 text-sm text-ink/70",
								children: armClear ? "تأكيد مسح السجل" : "مسح السجل"
							}) : null
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
					className: "order-2 grid content-start gap-5 rounded-card border border-ink/10 bg-paper p-5 shadow-lift lg:order-none lg:col-span-2 lg:sticky lg:top-6 lg:min-h-96 lg:p-7",
					"aria-live": "polite",
					children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reading, {
						message: active,
						copied: copiedId === active.id,
						onCopy: () => void copyArabic(active),
						onSpeak: () => speak(active.arabic),
						onRetry: () => void retryIncoming(active.id)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid content-center gap-2 py-10 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: "بانتظار رسالة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-6 text-ink/70",
							children: "الصق نصاً وارداً، أو جرّب رسالة جاهزة، وتظهر الترجمة هنا."
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm leading-6 text-ink/60",
				children: "الترجمة آلية وقد تُخطئ في العامية والأسماء. راجع ما يهم قبل أن ترد."
			})
		]
	});
}
function Reading({ message, copied, onCopy, onSpeak, onRetry }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-ink/60",
					children: [message.sample ? "مثال محفوظ" : "الترجمة", message.language ? ` · ${message.language}` : ""]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					dir: "auto",
					className: "mt-1 truncate text-2xl font-semibold",
					children: message.sender
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "shrink-0 pt-1 text-sm text-ink/60 tabular-nums",
				children: message.timeLabel
			})]
		}),
		message.status === "translating" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 py-2",
			"aria-label": "تُترجم الآن",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "تُترجم الآن"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-4/5 rounded-full bg-ink/10 motion-safe:animate-pulse" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full rounded-full bg-ink/10 motion-safe:animate-pulse" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-2/3 rounded-full bg-ink/10 motion-safe:animate-pulse" })
			]
		}) : null,
		message.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-base font-medium",
				children: message.error
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onRetry,
				className: "inline-flex min-h-11 w-fit items-center gap-2 rounded-control bg-accent px-4 text-sm font-semibold text-paper",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "إعادة المحاولة"]
			})]
		}) : null,
		message.status === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl leading-relaxed sm:text-4xl",
				children: message.arabic
			}),
			message.unchanged ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink/70",
				children: "الرسالة بالعربية أصلاً، أبقينا نصها كما هو."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onCopy,
					className: "inline-flex min-h-11 items-center gap-2 rounded-control bg-accent px-4 text-sm font-semibold text-paper",
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "تم النسخ" : "نسخ الترجمة"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onSpeak,
					className: "inline-flex min-h-11 items-center gap-2 rounded-control border border-ink/15 px-4 text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }), "استماع"]
				})]
			})
		] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-control bg-sand p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-ink/60",
				children: "النص الأصلي"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				dir: "auto",
				className: "mt-2 text-base leading-7 break-words",
				children: message.original
			})]
		})
	] });
}
function monogram(sender) {
	const letter = sender.trim().charAt(0);
	return letter ? letter.toLocaleUpperCase() : "؟";
}
//#endregion
export { Home as component };
