import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Route$1 } from "./router-DCIqO0dN.mjs";
import { r as GoalOverlay } from "./panels-aiwxz-g9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/goal-Biku7ymE.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const search = Route$1.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalOverlay, {
		look: search,
		metric: search.metric,
		goal: search.goal
	});
}
//#endregion
export { Page as component };
