import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Car, a as Trash2, b as Baby, c as Shirt, d as House, f as HeartHandshake, g as ChefHat, h as ClipboardList, l as ShieldCheck, m as Download, n as UtensilsCrossed, o as Star, p as Droplets, r as UserRound, s as Sparkles, t as X, u as MapPin, v as Briefcase, y as BadgeCheck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dgzfdw4u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SERVICES = [
	{
		id: "cleaning",
		en: "Cleaning",
		hi: "झाड़ू-पोछा",
		rate: 149
	},
	{
		id: "cooking",
		en: "Cooking",
		hi: "खाना बनाना",
		rate: 199
	},
	{
		id: "dishes",
		en: "Dishes",
		hi: "बर्तन",
		rate: 99
	},
	{
		id: "laundry",
		en: "Laundry",
		hi: "कपड़े",
		rate: 119
	},
	{
		id: "babysitter",
		en: "Child care",
		hi: "बच्चे की देखभाल",
		rate: 179
	},
	{
		id: "elder",
		en: "Elder care",
		hi: "बुज़ुर्ग देखभाल",
		rate: 219
	},
	{
		id: "deep",
		en: "Deep clean",
		hi: "डीप क्लीन",
		rate: 349
	},
	{
		id: "driver",
		en: "Driver",
		hi: "ड्राइवर",
		rate: 249
	}
];
var HELPERS = [
	{
		name: "Sunita Devi",
		skills: "Cleaning, Dishes",
		rating: 4.9,
		jobs: 312,
		distance: "0.8 km",
		initials: "SD"
	},
	{
		name: "Ramesh Kumar",
		skills: "Driver, Cleaning",
		rating: 4.8,
		jobs: 201,
		distance: "1.2 km",
		initials: "RK"
	},
	{
		name: "Lakshmi Bai",
		skills: "Cooking, Elder care",
		rating: 4.9,
		jobs: 268,
		distance: "1.5 km",
		initials: "LB"
	},
	{
		name: "Anita Verma",
		skills: "Deep clean, Cooking",
		rating: 4.8,
		jobs: 189,
		distance: "2.4 km",
		initials: "AV"
	}
];
var COPY = {
	en: {
		home: "Home",
		bookings: "Bookings",
		partner: "Partner",
		profile: "Profile",
		hero: "Verified house help in 30 minutes",
		sub: "Police-checked professionals, clear pricing, and a booking you can track.",
		bookNow: "Book now",
		services: "Services",
		nearby: "Verified nearby",
		when: "When",
		instant: "Instant · about 30 min",
		schedule: "Pick a time",
		hours: "Duration",
		address: "Service address",
		addressPh: "Flat, landmark, area",
		addressErr: "Enter a complete address.",
		anyPro: "Any verified pro",
		base: "Service",
		gst: "GST 18%",
		total: "Total",
		pay: "Continue to payment",
		confirm: "Confirm booking",
		demo: "Demo checkout on this phone. No real charge is made.",
		method: "Method",
		upi: "UPI",
		card: "Card",
		net: "Netbanking",
		none: "No bookings yet.",
		bookFirst: "Book a service",
		del: "Delete account",
		delTitle: "Delete everything on this phone?",
		delBody: "Bookings, payment notes, and your profile are erased from this device. This cannot be undone.",
		delYes: "Delete",
		keep: "Keep account",
		erased: "Account data on this phone was erased.",
		earn: "Earn up to ₹35,000 a month",
		earnSub: "No commission for the first 30 days. Daily payouts once live.",
		register: "Register as a partner",
		partnerName: "Full name",
		partnerPhone: "Phone",
		city: "City",
		yourServices: "Services you offer",
		submitPartner: "Submit application",
		partnerOk: "Application saved",
		partnerOkBody: "Stored on this phone. A coordinator would call when live onboarding opens.",
		name: "Name",
		phone: "Phone",
		legal: "Legal",
		privacy: "Privacy",
		terms: "Terms",
		install: "Install",
		installTitle: "Add Sahyog to your home screen",
		installBody: "Opens full screen, like an app, and comes back even on a weak connection.",
		installAction: "Install Sahyog",
		installed: "Sahyog is installed on this device.",
		dismiss: "Not now",
		embedded: "If no install prompt appears, open this page in Chrome or Safari. In-app browsers hide Add to Home Screen.",
		ios1: "Open Sahyog in Safari.",
		ios2: "Tap the Share button.",
		ios3: "Tap Add to Home Screen, then Add.",
		and1: "Open Sahyog in Chrome.",
		and2: "Tap the browser menu.",
		and3: "Tap Install app or Add to Home screen.",
		desk1: "Open Sahyog in Chrome or Edge.",
		desk2: "Use the install icon in the address bar.",
		desk3: "Confirm Install. It then opens in its own window.",
		cancel: "Cancel booking",
		steps: [
			"Accepted",
			"Assigned",
			"On the way",
			"Completed"
		],
		cancelled: "Cancelled",
		onDevice: "Bookings stay on this device.",
		privacyBody: "Your name, phone, bookings, and partner application are stored only in this browser. This version does not send them to a server. Delete account erases that local data. A live payment provider would handle cards and UPI; Sahyog would not store full card numbers.",
		termsBody: "Sahyog lists independent helpers for home services. The price is the hourly rate times hours, plus 18% GST. Checkout here confirms a booking on this device and does not charge a real payment method. You can cancel until the visit is marked completed.",
		close: "Close",
		jobs: "jobs",
		hr: "hr",
		railTitle: "Help at home, without the guesswork.",
		railBody: "Cleaning, cooking, care, and a driver — police-checked, priced before you book.",
		trust1: "Police-checked",
		trust2: "Price before you pay",
		trust3: "Track the visit",
		verified: "Police-checked"
	},
	hi: {
		home: "होम",
		bookings: "बुकिंग",
		partner: "पार्टनर",
		profile: "प्रोफ़ाइल",
		hero: "30 मिनट में वेरिफ़ाइड हाउस हेल्प",
		sub: "पुलिस वेरिफ़ाइड प्रोफेशनल, साफ़ कीमत, और बुकिंग जिसे आप ट्रैक कर सकते हैं।",
		bookNow: "अभी बुक करें",
		services: "सेवाएं",
		nearby: "आस-पास के वेरिफ़ाइड हेल्पर",
		when: "कब",
		instant: "तुरंत · लगभग 30 मिनट",
		schedule: "समय चुनें",
		hours: "घंटे",
		address: "काम का पता",
		addressPh: "मकान नं., लैंडमार्क, इलाका",
		addressErr: "पूरा पता लिखें।",
		anyPro: "कोई भी वेरिफ़ाइड",
		base: "सेवा",
		gst: "GST 18%",
		total: "कुल राशि",
		pay: "पेमेंट पर जाएँ",
		confirm: "बुकिंग कन्फ़र्म करें",
		demo: "यह डेमो चेकआउट है। असली पेमेंट नहीं कटेगा।",
		method: "तरीका",
		upi: "UPI",
		card: "कार्ड",
		net: "नेट बैंकिंग",
		none: "अभी कोई बुकिंग नहीं।",
		bookFirst: "सेवा बुक करें",
		del: "अकाउंट डिलीट करें",
		delTitle: "इस फ़ोन का सारा डेटा मिटाएँ?",
		delBody: "बुकिंग, पेमेंट नोट और प्रोफ़ाइल इस डिवाइस से मिट जाएँगे। इसे वापस नहीं लाया जा सकता।",
		delYes: "डिलीट करें",
		keep: "रहने दें",
		erased: "इस फ़ोन का अकाउंट डेटा मिट गया।",
		earn: "महीने में ₹35,000 तक कमाएँ",
		earnSub: "पहले 30 दिन शून्य कमीशन। लाइव होने पर रोज़ाना पेमेंट।",
		register: "सर्विस पार्टनर बनें",
		partnerName: "पूरा नाम",
		partnerPhone: "फ़ोन",
		city: "शहर",
		yourServices: "आपकी सेवाएं",
		submitPartner: "आवेदन भेजें",
		partnerOk: "आवेदन सेव हो गया",
		partnerOkBody: "इसी फ़ोन पर सेव है। लाइव ऑनबोर्डिंग खुलने पर कोऑर्डिनेटर कॉल करेगा।",
		name: "नाम",
		phone: "फ़ोन नंबर",
		legal: "नियम और गोपनीयता",
		privacy: "गोपनीयता",
		terms: "शर्तें",
		install: "इंस्टॉल",
		installTitle: "सहयोग को होम स्क्रीन पर जोड़ें",
		installBody: "पूरी स्क्रीन पर खुलता है, ऐप की तरह, और कमज़ोर नेट पर भी वापस आ जाता है।",
		installAction: "सहयोग इंस्टॉल करें",
		installed: "सहयोग इस डिवाइस पर इंस्टॉल है।",
		dismiss: "अभी नहीं",
		embedded: "अगर इंस्टॉल प्रॉम्प्ट न दिखे, तो यह पेज Chrome या Safari में खोलें। इन-ऐप ब्राउज़र होम स्क्रीन छिपा देते हैं।",
		ios1: "सहयोग को Safari में खोलें।",
		ios2: "Share बटन दबाएँ।",
		ios3: "Add to Home Screen, फिर Add दबाएँ।",
		and1: "सहयोग को Chrome में खोलें।",
		and2: "ब्राउज़र मेनू खोलें।",
		and3: "Install app या Add to Home screen दबाएँ।",
		desk1: "सहयोग को Chrome या Edge में खोलें।",
		desk2: "एड्रेस बार का इंस्टॉल आइकन इस्तेमाल करें।",
		desk3: "Install कन्फ़र्म करें। फिर यह अपनी विंडो में खुलेगा।",
		cancel: "बुकिंग रद्द करें",
		steps: [
			"स्वीकार",
			"हेल्पर तय",
			"रास्ते में",
			"पूरा हुआ"
		],
		cancelled: "रद्द",
		onDevice: "बुकिंग इसी डिवाइस पर रहती है।",
		privacyBody: "नाम, फ़ोन, बुकिंग और पार्टनर आवेदन सिर्फ़ इस ब्राउज़र में सेव होते हैं। यह वर्शन उन्हें सर्वर पर नहीं भेजता। अकाउंट डिलीट करने से यह लोकल डेटा मिट जाता है। लाइव पेमेंट प्रोवाइडर कार्ड और UPI संभालेगा; सहयोग पूरा कार्ड नंबर नहीं रखेगा।",
		termsBody: "सहयोग घर के काम के लिए स्वतंत्र हेल्पर दिखाता है। कीमत घंटे की दर गुणा घंटे, और 18% GST है। यहाँ चेकआउट इस डिवाइस पर बुकिंग कन्फ़र्म करता है और असली पेमेंट नहीं काटता। विज़िट पूरा होने से पहले आप रद्द कर सकते हैं।",
		close: "बंद करें",
		jobs: "काम",
		hr: "घंटा",
		railTitle: "घर का सहारा, बिना अंदाज़े के।",
		railBody: "सफ़ाई, खाना, देखभाल और ड्राइवर — पुलिस वेरिफ़ाइड, कीमत पहले से साफ़।",
		trust1: "पुलिस वेरिफ़ाइड",
		trust2: "पेमेंट से पहले कीमत",
		trust3: "विज़िट ट्रैक करें",
		verified: "पुलिस वेरिफ़ाइड"
	}
};
var DEFAULT_USER = {
	name: "Aditi Sharma",
	phone: "+91 98765 43210"
};
var STORAGE_KEY = "sahyog_data";
function serviceById(id) {
	return SERVICES.find((service) => service.id === id) ?? SERVICES[0];
}
function serviceName(service, lang) {
	return lang === "hi" ? service.hi : service.en;
}
function quote(rate, hours) {
	const base = rate * hours;
	const gst = Math.round(base * .18);
	return {
		base,
		gst,
		total: base + gst
	};
}
var inrFormat = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	maximumFractionDigits: 0
});
function inr(amount) {
	return inrFormat.format(amount);
}
function statusIndex(booking, now) {
	if (booking.cancelled) return -1;
	const elapsed = now - booking.createdAt;
	if (elapsed >= 36e3) return 3;
	if (elapsed >= 22e3) return 2;
	if (elapsed >= 1e4) return 1;
	return 0;
}
function loadState() {
	if (typeof localStorage === "undefined") return null;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		return parsed && typeof parsed === "object" ? parsed : null;
	} catch {
		return null;
	}
}
function saveState(data) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
	} catch {}
}
function clearState() {
	try {
		localStorage.removeItem(STORAGE_KEY);
	} catch {}
}
function nextMorningSlot() {
	const date = /* @__PURE__ */ new Date();
	date.setDate(date.getDate() + 1);
	date.setHours(9, 0, 0, 0);
	const pad = (value) => String(value).padStart(2, "0");
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function formatSlot(slot, lang) {
	const date = new Date(slot);
	if (Number.isNaN(date.getTime())) return slot;
	return new Intl.DateTimeFormat(lang === "hi" ? "hi-IN" : "en-IN", {
		day: "numeric",
		month: "short",
		hour: "numeric",
		minute: "2-digit"
	}).format(date);
}
function helpersFor(service) {
	const needle = service.en.split(" ")[0].toLowerCase();
	const matches = HELPERS.filter((helper) => helper.skills.toLowerCase().includes(needle));
	return matches.length ? matches : HELPERS;
}
var ICONS = {
	cleaning: Sparkles,
	cooking: ChefHat,
	dishes: UtensilsCrossed,
	laundry: Shirt,
	babysitter: Baby,
	elder: HeartHandshake,
	deep: Droplets,
	driver: Car
};
var fieldClass = "h-12 w-full min-w-0 rounded-control border border-line bg-bg px-3 text-base text-ink outline-none focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent/30";
function HouseMark({ className = "size-9" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: `${className} text-accent`,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "9",
			fill: "currentColor"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			className: "fill-accent-ink",
			d: "M16 6.4 26.4 15h-2.6v9.6H8.2V15H5.6L16 6.4z"
		})]
	});
}
function preferAppInstallLinks() {
	document.querySelectorAll("link[rel=\"manifest\"]").forEach((el) => {
		if ((el.getAttribute("href") || "").includes("/__grok/")) el.remove();
	});
	document.querySelectorAll("link[rel=\"apple-touch-icon\"]").forEach((el) => {
		if ((el.getAttribute("href") || "").includes("/__grok/")) el.remove();
	});
}
function isStandalone() {
	const nav = navigator;
	return window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
}
function platformKind() {
	const ua = navigator.userAgent || "";
	if (/iPhone|iPad|iPod/i.test(ua) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1) return "ios";
	if (/Android/i.test(ua)) return "android";
	return "desktop";
}
function isEmbedded() {
	try {
		return window.self !== window.top;
	} catch {
		return true;
	}
}
function SahyogApp() {
	const [tab, setTab] = (0, import_react.useState)("home");
	const [lang, setLang] = (0, import_react.useState)("en");
	const [bookings, setBookings] = (0, import_react.useState)([]);
	const [user, setUser] = (0, import_react.useState)(DEFAULT_USER);
	const [partner, setPartner] = (0, import_react.useState)(null);
	const [installDismissed, setInstallDismissed] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [paying, setPaying] = (0, import_react.useState)(false);
	const [installOpen, setInstallOpen] = (0, import_react.useState)(false);
	const [installed, setInstalled] = (0, import_react.useState)(false);
	const [canPrompt, setCanPrompt] = (0, import_react.useState)(false);
	const [legal, setLegal] = (0, import_react.useState)(null);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const promptRef = (0, import_react.useRef)(null);
	const t = COPY[lang];
	(0, import_react.useEffect)(() => {
		const saved = loadState();
		if (saved) {
			if (saved.lang === "en" || saved.lang === "hi") setLang(saved.lang);
			if (Array.isArray(saved.bookings)) setBookings(saved.bookings);
			if (saved.user?.name) setUser({
				name: saved.user.name,
				phone: saved.user.phone || DEFAULT_USER.phone
			});
			if (saved.partner) setPartner(saved.partner);
			if (saved.installDismissed) setInstallDismissed(true);
		}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		saveState({
			lang,
			bookings,
			user,
			partner,
			installDismissed
		});
	}, [
		ready,
		lang,
		bookings,
		user,
		partner,
		installDismissed
	]);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang === "hi" ? "hi" : "en";
	}, [lang]);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		preferAppInstallLinks();
		setInstalled(isStandalone());
		const onPrompt = (event) => {
			event.preventDefault();
			promptRef.current = event;
			setCanPrompt(true);
		};
		const onInstalled = () => {
			setInstalled(true);
			setCanPrompt(false);
			promptRef.current = null;
			setInstallOpen(false);
		};
		const onMode = () => setInstalled(isStandalone());
		window.addEventListener("beforeinstallprompt", onPrompt);
		window.addEventListener("appinstalled", onInstalled);
		const mq = window.matchMedia("(display-mode: standalone)");
		mq.addEventListener("change", onMode);
		if ("serviceWorker" in navigator && !isEmbedded()) navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {});
		if (new URLSearchParams(window.location.search).get("book") === "1") setDraft(openDraft(SERVICES[0]));
		return () => {
			window.removeEventListener("beforeinstallprompt", onPrompt);
			window.removeEventListener("appinstalled", onInstalled);
			mq.removeEventListener("change", onMode);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!draft && !installOpen && !legal && !confirmDelete) return;
		const onKey = (event) => {
			if (event.key !== "Escape") return;
			setDraft(null);
			setInstallOpen(false);
			setLegal(null);
			setConfirmDelete(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		draft,
		installOpen,
		legal,
		confirmDelete
	]);
	(0, import_react.useEffect)(() => {
		if (!notice) return;
		const timer = window.setTimeout(() => setNotice(null), 3200);
		return () => window.clearTimeout(timer);
	}, [notice]);
	const openBooking = (service, instant = false) => {
		setDraft(openDraft(service, instant));
	};
	const runInstall = async () => {
		const event = promptRef.current;
		if (!event) {
			setInstallOpen(true);
			return;
		}
		try {
			await event.prompt();
			const choice = await event.userChoice;
			promptRef.current = null;
			setCanPrompt(false);
			if (choice.outcome === "accepted") {
				setInstalled(true);
				setInstallOpen(false);
			}
		} catch {
			setInstallOpen(true);
		}
	};
	const confirmPay = () => {
		if (!draft || paying) return;
		setPaying(true);
		window.setTimeout(() => {
			const priced = quote(draft.service.rate, draft.hours);
			const booking = {
				id: crypto.randomUUID(),
				serviceId: draft.service.id,
				hours: draft.hours,
				when: draft.when,
				slot: draft.slot,
				address: draft.address.trim(),
				total: priced.total,
				paymentId: `pay_${crypto.randomUUID().slice(0, 8)}`,
				createdAt: Date.now(),
				cancelled: false,
				helper: draft.helper
			};
			setBookings((current) => [booking, ...current]);
			setDraft(null);
			setPaying(false);
			setTab("bookings");
		}, 450);
	};
	const deleteAccount = () => {
		clearState();
		setBookings([]);
		setUser({
			name: "",
			phone: ""
		});
		setPartner(null);
		setLang("en");
		setInstallDismissed(false);
		setConfirmDelete(false);
		setTab("home");
		setNotice(t.erased);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh justify-center bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-dvh w-full max-w-[880px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "hidden h-dvh w-[380px] shrink-0 flex-col justify-between overflow-y-auto border-r border-line bg-bg-deep px-8 py-8 lg:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseMark, { className: "size-11" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl leading-none font-semibold tracking-tight",
								children: "Sahyog"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Ghar ka Sahara"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-10 font-display text-4xl leading-tight font-semibold tracking-tight text-balance",
							children: t.railTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-sm text-base text-muted",
							children: t.railBody
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 space-y-3",
							children: [
								[ShieldCheck, t.trust1],
								[BadgeCheck, t.trust2],
								[MapPin, t.trust3]
							].map(([Icon, label]) => {
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-3 text-sm font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-9 place-items-center rounded-control bg-card text-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-4",
											"aria-hidden": "true"
										})
									}), label]
								}, String(label));
							})
						})
					] }), !installed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => canPrompt ? void runInstall() : setInstallOpen(true),
						className: "mt-8 flex h-12 items-center justify-center gap-2 rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-4",
							"aria-hidden": "true"
						}), t.installAction]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-sm text-muted",
						children: t.installed
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-dvh min-w-0 flex-1 flex-col border-line lg:max-w-[480px] lg:border-r",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "flex items-center justify-between gap-2 px-4 pt-[max(12px,env(safe-area-inset-top))] pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl leading-none font-semibold tracking-tight",
										children: "Sahyog"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted",
										children: "Ghar ka Sahara"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex shrink-0 items-center gap-2",
								children: [!installed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setInstallOpen(true),
									className: "inline-flex h-10 items-center gap-1.5 rounded-full border border-line bg-card px-3 text-sm font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
										className: "size-4 text-accent",
										"aria-hidden": "true"
									}), t.install]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setLang((current) => current === "en" ? "hi" : "en"),
									className: "inline-flex h-10 items-center rounded-full border border-line bg-card px-3 text-sm font-semibold",
									children: lang === "en" ? "हिंदी" : "English"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
							className: "min-h-0 flex-1 overflow-y-auto px-4 pb-4",
							children: [
								tab === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {
									lang,
									installed,
									installDismissed,
									onBook: openBooking,
									onInstall: () => setInstallOpen(true),
									onDismissInstall: () => setInstallDismissed(true)
								}),
								tab === "bookings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingsView, {
									lang,
									bookings,
									now,
									onBook: () => {
										setTab("home");
									},
									onCancel: (id) => setBookings((current) => current.map((booking) => booking.id === id ? {
										...booking,
										cancelled: true
									} : booking))
								}),
								tab === "partner" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartnerView, {
									lang,
									partner,
									onSave: (next) => {
										setPartner(next);
										setNotice(COPY[lang].partnerOk);
									}
								}),
								tab === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileView, {
									lang,
									user,
									installed,
									onName: (name) => setUser((current) => ({
										...current,
										name
									})),
									onInstall: () => setInstallOpen(true),
									onLegal: setLegal,
									onDelete: () => setConfirmDelete(true)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "grid shrink-0 grid-cols-4 border-t border-line bg-card pb-[env(safe-area-inset-bottom)]",
							"aria-label": "Primary",
							children: [
								[
									"home",
									House,
									t.home
								],
								[
									"bookings",
									ClipboardList,
									t.bookings
								],
								[
									"partner",
									Briefcase,
									t.partner
								],
								[
									"profile",
									UserRound,
									t.profile
								]
							].map(([id, Icon, label]) => {
								const on = tab === id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-current": on ? "page" : void 0,
									onClick: () => setTab(id),
									className: `flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs font-medium ${on ? "text-accent" : "text-muted"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5",
										strokeWidth: on ? 2.25 : 1.75,
										"aria-hidden": "true"
									}), label]
								}, id);
							})
						})
					]
				})]
			}),
			draft && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: serviceName(draft.service, lang),
				onClose: () => setDraft(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingSheet, {
					lang,
					draft,
					paying,
					onChange: setDraft,
					onPay: confirmPay
				})
			}),
			installOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: t.installTitle,
				onClose: () => setInstallOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallSheet, {
					lang,
					installed,
					canPrompt,
					onInstall: () => void runInstall()
				})
			}),
			legal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: legal === "privacy" ? t.privacy : t.terms,
				onClose: () => setLegal(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-ink",
					children: legal === "privacy" ? t.privacyBody : t.termsBody
				})
			}),
			confirmDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: t.delTitle,
				onClose: () => setConfirmDelete(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: t.delBody
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setConfirmDelete(false),
						className: "h-12 rounded-control border border-line bg-card text-sm font-semibold",
						children: t.keep
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: deleteAccount,
						className: "h-12 rounded-control bg-danger text-sm font-semibold text-on-danger",
						children: t.delYes
					})]
				})]
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in pointer-events-none fixed inset-x-0 bottom-24 z-30 flex justify-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm rounded-control bg-ink px-4 py-3 text-center text-sm font-medium text-bg shadow-card",
					children: notice
				})
			})
		]
	});
}
function openDraft(service, instant = false) {
	return {
		service,
		hours: 2,
		when: instant ? "instant" : "instant",
		slot: nextMorningSlot(),
		address: "",
		helper: null,
		step: "details",
		method: "upi",
		addressError: false
	};
}
function Sheet({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fade-in fixed inset-0 z-20 flex items-end justify-center bg-scrim sm:items-center",
		onMouseDown: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			onMouseDown: (event) => event.stopPropagation(),
			className: "sheet-in max-h-[min(92dvh,760px)] w-full max-w-[480px] overflow-y-auto rounded-t-card bg-bg px-4 pt-4 pb-[max(20px,env(safe-area-inset-bottom))] sm:rounded-card sm:p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl leading-tight font-semibold tracking-tight",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "grid size-10 shrink-0 place-items-center rounded-full border border-line bg-card",
					"aria-label": COPY.en.close,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
						className: "size-4",
						"aria-hidden": "true"
					})
				})]
			}), children]
		})
	});
}
function HomeView({ lang, installed, installDismissed, onBook, onInstall, onDismissInstall }) {
	const t = COPY[lang];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card bg-accent px-5 py-5 text-accent-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold",
						children: t.verified
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl leading-tight font-semibold tracking-tight text-balance",
						children: t.hero
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed opacity-90",
						children: t.sub
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onBook(SERVICES[0], true),
						className: "mt-4 inline-flex h-11 items-center rounded-control bg-accent-ink px-4 text-sm font-semibold text-accent",
						children: t.bookNow
					})
				]
			}),
			!installed && !installDismissed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-card border border-line bg-card p-4 shadow-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 shrink-0 place-items-center rounded-control bg-tint text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-5",
							"aria-hidden": "true"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base font-semibold",
								children: t.installTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: t.installBody
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: onInstall,
									className: "h-10 rounded-control bg-accent px-3 text-sm font-semibold text-accent-ink",
									children: t.install
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: onDismissInstall,
									className: "h-10 px-2 text-sm font-medium text-muted",
									children: t.dismiss
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-xl font-semibold tracking-tight",
				children: t.services
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2",
				children: SERVICES.map((service) => {
					const Icon = ICONS[service.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onBook(service),
						className: "flex min-h-24 flex-col items-center justify-center rounded-control border border-line bg-card px-1 py-2 text-center shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5 text-accent",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 px-0.5 text-xs leading-tight font-semibold break-words",
								children: serviceName(service, lang)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 text-xs text-muted tabular-nums",
								children: [
									inr(service.rate),
									"/",
									t.hr
								]
							})
						]
					}, service.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-xl font-semibold tracking-tight",
				children: t.nearby
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: HELPERS.map((helper) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						const skill = helper.skills.split(",")[0].trim().toLowerCase();
						onBook(SERVICES.find((item) => item.en.toLowerCase().includes(skill) || skill.includes(item.en.toLowerCase())) ?? SERVICES[0]);
					},
					className: "flex w-full items-center gap-3 rounded-card border border-line bg-card p-3 text-left shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-tint text-sm font-semibold text-accent",
							children: helper.initials
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: helper.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block truncate text-sm text-muted",
								children: [
									helper.skills,
									" · ",
									helper.distance
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 text-sm font-semibold tabular-nums",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
								className: "size-3.5 fill-accent text-accent",
								"aria-hidden": "true"
							}), helper.rating]
						})
					]
				}) }, helper.name))
			})] })
		]
	});
}
function BookingsView({ lang, bookings, now, onCancel, onBook }) {
	const t = COPY[lang];
	if (!bookings.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-semibold tracking-tight",
			children: t.bookings
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-card border border-line bg-card p-5 shadow-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t.none
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBook,
				className: "mt-4 h-11 rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink",
				children: t.bookFirst
			})]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-semibold tracking-tight",
			children: t.bookings
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: t.onDevice
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 space-y-3",
			children: bookings.map((booking) => {
				const service = serviceById(booking.serviceId);
				const Icon = ICONS[service.id];
				const step = statusIndex(booking, now);
				const done = step === 3;
				const label = step < 0 ? t.cancelled : t.steps[step];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-card border border-line bg-card p-4 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5 shrink-0 text-accent",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold",
									children: serviceName(service, lang)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${done ? "bg-ok-tint text-ok" : step < 0 ? "bg-danger-tint text-danger" : "bg-tint text-accent"}`,
								children: label
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								booking.when === "instant" ? t.instant : formatSlot(booking.slot, lang),
								" · ",
								booking.hours,
								" ",
								t.hr,
								" ·",
								" ",
								booking.address
							]
						}),
						booking.helper && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: booking.helper
						}),
						step >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1.5 overflow-hidden rounded-full bg-line",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-ok",
								style: { width: `${(step + 1) / 4 * 100}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted tabular-nums",
								children: booking.paymentId
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold tabular-nums",
								children: inr(booking.total)
							})]
						}),
						step >= 0 && step < 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onCancel(booking.id),
							className: "mt-3 text-sm font-medium text-danger",
							children: t.cancel
						})
					]
				}, booking.id);
			})
		})
	] });
}
function PartnerView({ lang, partner, onSave }) {
	const t = COPY[lang];
	const [name, setName] = (0, import_react.useState)(partner?.name ?? "");
	const [phone, setPhone] = (0, import_react.useState)(partner?.phone ?? "");
	const [city, setCity] = (0, import_react.useState)(partner?.city ?? "");
	const [services, setServices] = (0, import_react.useState)(partner?.services ?? []);
	const [error, setError] = (0, import_react.useState)(false);
	const toggle = (id) => {
		setServices((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-semibold tracking-tight",
			children: t.partner
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 rounded-card bg-accent p-5 text-accent-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-2xl leading-tight font-semibold",
				children: t.earn
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm opacity-90",
				children: t.earnSub
			})]
		}),
		partner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 rounded-card border border-line bg-card p-4 shadow-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: t.partnerOk
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: t.partnerOkBody
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm",
					children: [
						partner.name,
						" · ",
						partner.city
					]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 space-y-3 rounded-card border border-line bg-card p-4 shadow-card",
			onSubmit: (event) => {
				event.preventDefault();
				if (name.trim().length < 2 || phone.trim().length < 8 || city.trim().length < 2 || !services.length) {
					setError(true);
					return;
				}
				onSave({
					name: name.trim(),
					phone: phone.trim(),
					city: city.trim(),
					services
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t.partnerName,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: name,
						onChange: (event) => setName(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t.partnerPhone,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "tel",
						value: phone,
						onChange: (event) => setPhone(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t.city,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: city,
						onChange: (event) => setCity(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "mb-2 text-sm font-medium text-muted",
					children: t.yourServices
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: SERVICES.map((service) => {
						const on = services.includes(service.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": on,
							onClick: () => toggle(service.id),
							className: `h-10 rounded-full border px-3 text-sm font-medium ${on ? "border-accent bg-accent text-accent-ink" : "border-line bg-bg"}`,
							children: serviceName(service, lang)
						}, service.id);
					})
				})] }),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: lang === "hi" ? "नाम, फ़ोन, शहर और एक सेवा चुनें।" : "Add your name, phone, city, and at least one service."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-12 w-full rounded-control bg-accent text-sm font-semibold text-accent-ink",
					children: t.submitPartner
				})
			]
		})
	] });
}
function ProfileView({ lang, user, installed, onName, onInstall, onLegal, onDelete }) {
	const t = COPY[lang];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-2xl font-semibold tracking-tight",
		children: t.profile
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-card border border-line bg-card p-4 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t.name,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: user.name,
						onChange: (event) => onName(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t.phone,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: `${fieldClass} opacity-70`,
						value: user.phone,
						disabled: true
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-card p-4 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-semibold",
						children: installed ? t.installed : t.installTitle
					}),
					!installed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: t.installBody
					}),
					!installed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onInstall,
						className: "mt-3 inline-flex h-11 items-center gap-2 rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-4",
							"aria-hidden": "true"
						}), t.installAction]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-card p-4 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: t.legal
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onLegal("privacy"),
						className: "h-10 rounded-control border border-line px-3 text-sm font-semibold",
						children: t.privacy
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onLegal("terms"),
						className: "h-10 rounded-control border border-line px-3 text-sm font-semibold",
						children: t.terms
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onDelete,
				className: "flex h-12 w-full items-center justify-center gap-2 rounded-control bg-danger text-sm font-semibold text-on-danger",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
					className: "size-4",
					"aria-hidden": "true"
				}), t.del]
			})
		]
	})] });
}
function BookingSheet({ lang, draft, paying, onChange, onPay }) {
	const t = COPY[lang];
	const priced = (0, import_react.useMemo)(() => quote(draft.service.rate, draft.hours), [draft.service.rate, draft.hours]);
	const pros = helpersFor(draft.service);
	if (draft.step === "pay") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: t.demo
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 font-display text-4xl font-semibold tabular-nums",
			children: inr(priced.total)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm font-medium text-muted",
			children: t.method
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid grid-cols-3 gap-2",
			children: [
				["upi", t.upi],
				["card", t.card],
				["net", t.net]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": draft.method === id,
				onClick: () => onChange({
					...draft,
					method: id
				}),
				className: `h-11 rounded-control border text-sm font-semibold ${draft.method === id ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`,
				children: label
			}, id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			disabled: paying,
			onClick: onPay,
			className: "mt-5 h-12 w-full rounded-control bg-accent text-sm font-semibold text-accent-ink disabled:opacity-60",
			children: paying ? "…" : `${t.confirm} · ${inr(priced.total)}`
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: t.when
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 grid grid-cols-2 gap-2",
					children: ["instant", "scheduled"].map((when) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": draft.when === when,
						onClick: () => onChange({
							...draft,
							when
						}),
						className: `h-11 rounded-control border px-2 text-sm font-semibold ${draft.when === when ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`,
						children: when === "instant" ? t.instant : t.schedule
					}, when))
				}),
				draft.when === "scheduled" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "datetime-local",
					className: `${fieldClass} mt-2`,
					value: draft.slot,
					onChange: (event) => onChange({
						...draft,
						slot: event.target.value
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted",
				children: t.hours
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid grid-cols-4 gap-2",
				children: [
					1,
					2,
					3,
					4
				].map((hours) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": draft.hours === hours,
					onClick: () => onChange({
						...draft,
						hours
					}),
					className: `h-11 rounded-control border text-sm font-semibold tabular-nums ${draft.hours === hours ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`,
					children: [
						hours,
						" ",
						t.hr
					]
				}, hours))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: t.address,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					placeholder: t.addressPh,
					autoComplete: "street-address",
					value: draft.address,
					onChange: (event) => onChange({
						...draft,
						address: event.target.value,
						addressError: false
					})
				}), draft.addressError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-danger",
					children: t.addressErr
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted",
				children: t.anyPro
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": draft.helper === null,
					onClick: () => onChange({
						...draft,
						helper: null
					}),
					className: `h-10 shrink-0 rounded-full border px-3 text-sm font-medium ${draft.helper === null ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`,
					children: t.anyPro
				}), pros.map((helper) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": draft.helper === helper.name,
					onClick: () => onChange({
						...draft,
						helper: helper.name
					}),
					className: `h-10 shrink-0 rounded-full border px-3 text-sm font-medium ${draft.helper === helper.name ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`,
					children: helper.name
				}, helper.name))]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-control border border-line bg-card p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: `${t.base} · ${draft.hours} ${t.hr}`,
						value: inr(priced.base)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t.gst,
						value: inr(priced.gst),
						muted: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center justify-between border-t border-line pt-2 text-base font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.total }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: inr(priced.total)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					if (draft.address.trim().length < 5) {
						onChange({
							...draft,
							addressError: true
						});
						return;
					}
					onChange({
						...draft,
						step: "pay",
						addressError: false
					});
				},
				className: "h-12 w-full rounded-control bg-accent text-sm font-semibold text-accent-ink",
				children: t.pay
			})
		]
	});
}
function InstallSheet({ lang, installed, canPrompt, onInstall }) {
	const t = COPY[lang];
	const kind = typeof navigator === "undefined" ? "desktop" : platformKind();
	const steps = kind === "ios" ? [
		t.ios1,
		t.ios2,
		t.ios3
	] : kind === "android" ? [
		t.and1,
		t.and2,
		t.and3
	] : [
		t.desk1,
		t.desk2,
		t.desk3
	];
	if (installed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: t.installed
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: t.installBody
		}),
		canPrompt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onInstall,
			className: "mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-control bg-accent text-sm font-semibold text-accent-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
				className: "size-4",
				"aria-hidden": "true"
			}), t.installAction]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm leading-relaxed text-muted",
			children: t.embedded
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-3 space-y-2",
			children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-6 shrink-0 place-items-center rounded-full bg-tint text-xs font-semibold text-accent",
					children: index + 1
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pt-0.5",
					children: step
				})]
			}, step))
		})
	] });
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-sm font-medium text-muted",
			children: label
		}), children]
	});
}
function Row({ label, value, muted = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center justify-between gap-3 ${muted ? "text-muted" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SahyogApp, {});
}
//#endregion
export { Home as component };
