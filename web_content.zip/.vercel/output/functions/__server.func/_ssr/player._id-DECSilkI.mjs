import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as Gauge, F as Captions, P as ChevronLeft, S as ListMusic, _ as Minimize, b as LockOpen, f as Ratio, g as Pause, h as PictureInPicture2, m as Play, n as VolumeX, o as SkipForward, r as Volume2, s as SkipBack, v as Maximize, y as Lock } from "../_libs/lucide-react.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as clamp, E as getObjectUrl, F as EQ_FREQUENCIES, H as decoderDescription, K as formatDuration, P as Button, R as SPEED_PRESETS, S as usePlayer, T as getFile, U as decoderHelp, V as cn, d as DropdownMenuContent, f as DropdownMenuItem, h as DropdownMenuTrigger, k as useLibrary, m as DropdownMenuSeparator, n as Route, o as useSettings, p as DropdownMenuLabel, u as DropdownMenu } from "./router-5I6roosF.mjs";
import { t as Slider } from "./slider-VODu9m8l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/player._id-DECSilkI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function parseTimestamp(raw) {
	const cleaned = raw.trim().replace(",", ".");
	const parts = cleaned.split(":");
	if (parts.length < 2) {
		const n = Number.parseFloat(cleaned);
		return Number.isFinite(n) ? n : 0;
	}
	const secParts = (parts[parts.length - 1] ?? "0").split(".");
	const seconds = Number.parseInt(secParts[0] ?? "0", 10) || 0;
	const frac = secParts[1] ? Number.parseFloat(`0.${secParts[1]}`) : 0;
	const minutes = Number.parseInt(parts[parts.length - 2] ?? "0", 10) || 0;
	return (parts.length > 2 ? Number.parseInt(parts[0] ?? "0", 10) || 0 : 0) * 3600 + minutes * 60 + seconds + frac;
}
function splitBlocks(text) {
	return text.replace(/\r/g, "").split(/\n{2,}/);
}
/**
* Parse SRT or VTT into cues. Malformed blocks are skipped, never thrown.
*/
function parseSubtitles(source) {
	if (!source || typeof source !== "string") return [];
	let body = source.replace(/^\uFEFF/, "");
	if (body.slice(0, 6).toUpperCase() === "WEBVTT") {
		const headerEnd = body.indexOf("\n");
		body = headerEnd >= 0 ? body.slice(headerEnd + 1) : "";
		body = body.replace(/^(NOTE|STYLE|REGION)[\s\S]*?(?=\n\n|$)/gm, "");
	}
	const cues = [];
	for (const block of splitBlocks(body)) {
		const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);
		if (lines.length === 0) continue;
		let idx = 0;
		if (lines[0] && !lines[0].includes("-->") && /^[\w-]+$/.test(lines[0])) idx = 1;
		const timing = lines[idx];
		if (!timing || !timing.includes("-->")) continue;
		const [startRaw, endRaw] = timing.split("-->").map((s) => s.trim().split(" ")[0]);
		if (!startRaw || !endRaw) continue;
		const start = parseTimestamp(startRaw);
		const end = parseTimestamp(endRaw);
		if (!(end > start)) continue;
		const text = lines.slice(idx + 1).join("\n").replace(/<[^>]+>/g, "").trim();
		if (!text) continue;
		cues.push({
			start,
			end,
			text
		});
	}
	return cues.sort((a, b) => a.start - b.start);
}
function shiftCues(cues, delaySec) {
	if (!delaySec) return cues;
	return cues.map((c) => ({
		...c,
		start: Math.max(0, c.start + delaySec),
		end: Math.max(0, c.end + delaySec)
	}));
}
function activeCue(cues, time) {
	if (!cues.length) return void 0;
	let lo = 0;
	let hi = cues.length - 1;
	while (lo <= hi) {
		const mid = lo + hi >> 1;
		const c = cues[mid];
		if (time < c.start) hi = mid - 1;
		else if (time > c.end) lo = mid + 1;
		else return c;
	}
}
async function readSubtitleFile(file) {
	try {
		return parseSubtitles(await file.text());
	} catch {
		return [];
	}
}
var graphs = /* @__PURE__ */ new WeakMap();
async function ensureCtx(graph) {
	if (graph.ctx.state === "suspended") try {
		await graph.ctx.resume();
	} catch {}
}
function attachEqualizer(el) {
	const existing = graphs.get(el);
	if (existing) return existing;
	try {
		const AudioCtx = window.AudioContext || window.webkitAudioContext;
		if (!AudioCtx) return null;
		const ctx = new AudioCtx();
		const source = ctx.createMediaElementSource(el);
		const filters = EQ_FREQUENCIES.map((freq, i) => {
			const f = ctx.createBiquadFilter();
			f.type = i === 0 ? "lowshelf" : i === EQ_FREQUENCIES.length - 1 ? "highshelf" : "peaking";
			f.frequency.value = freq;
			f.Q.value = .9;
			f.gain.value = 0;
			return f;
		});
		const bass = ctx.createBiquadFilter();
		bass.type = "lowshelf";
		bass.frequency.value = 120;
		bass.gain.value = 0;
		const splitter = ctx.createChannelSplitter(2);
		const merger = ctx.createChannelMerger(2);
		const gain = ctx.createGain();
		gain.gain.value = 1;
		const compressor = ctx.createDynamicsCompressor();
		compressor.threshold.value = 0;
		compressor.knee.value = 0;
		compressor.ratio.value = 1;
		const analyser = ctx.createAnalyser();
		analyser.fftSize = 256;
		analyser.smoothingTimeConstant = .8;
		let node = source;
		for (const f of filters) {
			node.connect(f);
			node = f;
		}
		node.connect(bass);
		bass.connect(gain);
		gain.connect(compressor);
		compressor.connect(analyser);
		analyser.connect(ctx.destination);
		const graph = {
			ctx,
			source,
			filters,
			bass,
			splitter,
			merger,
			gain,
			compressor,
			analyser,
			stereo: true,
			connected: true
		};
		graphs.set(el, graph);
		return graph;
	} catch {
		return null;
	}
}
async function applyEq(el, bands, bassBoost, normalize, stereo) {
	const graph = attachEqualizer(el);
	if (!graph) return;
	await ensureCtx(graph);
	graph.filters.forEach((f, i) => {
		const db = clamp(bands[i] ?? 0, -12, 12);
		try {
			f.gain.value = db;
		} catch {}
	});
	try {
		graph.bass.gain.value = clamp(bassBoost, 0, 12);
	} catch {}
	try {
		if (normalize) {
			graph.compressor.threshold.value = -24;
			graph.compressor.knee.value = 12;
			graph.compressor.ratio.value = 4;
		} else {
			graph.compressor.threshold.value = 0;
			graph.compressor.knee.value = 0;
			graph.compressor.ratio.value = 1;
		}
	} catch {}
	if (stereo !== graph.stereo) try {
		graph.gain.disconnect();
		graph.splitter.disconnect();
		graph.merger.disconnect();
		if (stereo) graph.gain.connect(graph.compressor);
		else {
			graph.gain.connect(graph.splitter);
			graph.splitter.connect(graph.merger, 0, 0);
			graph.splitter.connect(graph.merger, 0, 1);
			graph.merger.connect(graph.compressor);
		}
		graph.stereo = stereo;
	} catch {}
}
function eqSpectrum(el, buckets = 16) {
	const graph = graphs.get(el);
	if (!graph) return Array.from({ length: buckets }, () => 0);
	const arr = new Uint8Array(graph.analyser.frequencyBinCount);
	graph.analyser.getByteFrequencyData(arr);
	const out = [];
	const step = Math.max(1, Math.floor(arr.length / buckets));
	for (let i = 0; i < buckets; i++) {
		let sum = 0;
		for (let j = 0; j < step; j++) sum += arr[i * step + j] ?? 0;
		out.push(sum / step / 255);
	}
	return out;
}
function mediaSrc(item) {
	if (item.source === "url" || item.source === "download") return item.url;
	return getObjectUrl(item.id) ?? (getFile(item.id) ? getObjectUrl(item.id) : item.url);
}
function usePlayerEngine(item, mediaRef) {
	const rememberPlay = useLibrary((s) => s.rememberPlay);
	const setError = usePlayer((s) => s.setError);
	const setPlaying = usePlayer((s) => s.setPlaying);
	const settings = useSettings();
	const [currentTime, setCurrentTime] = (0, import_react.useState)(0);
	const [duration, setDuration] = (0, import_react.useState)(item?.duration ?? 0);
	const [buffered, setBuffered] = (0, import_react.useState)(0);
	const [volume, setVolume] = (0, import_react.useState)(1);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [speed, setSpeed] = (0, import_react.useState)(settings.defaultSpeed);
	const [brightness, setBrightness] = (0, import_react.useState)(1);
	const [aspect, setAspect] = (0, import_react.useState)(settings.aspect);
	const [waiting, setWaiting] = (0, import_react.useState)(false);
	const saveTimer = (0, import_react.useRef)(null);
	const src = item ? mediaSrc(item) : void 0;
	(0, import_react.useEffect)(() => {
		const el = mediaRef.current;
		if (!el || !item) return;
		el.playbackRate = speed;
		el.volume = volume;
		el.muted = muted;
	}, [
		mediaRef,
		item,
		speed,
		volume,
		muted
	]);
	(0, import_react.useEffect)(() => {
		const el = mediaRef.current;
		if (!el || !item) return;
		if (!settings.eqEnabled) return;
		applyEq(el, settings.eqBands, settings.bassBoost, settings.normalize, settings.stereo);
	}, [
		mediaRef,
		item,
		settings.eqEnabled,
		settings.eqBands,
		settings.bassBoost,
		settings.normalize,
		settings.stereo
	]);
	(0, import_react.useEffect)(() => {
		const el = mediaRef.current;
		if (!el || !item || !src) return;
		const onMeta = () => {
			setDuration(el.duration || 0);
			if (settings.resumePlayback && item.position > 3 && item.position < (el.duration || Infinity) - 2) try {
				el.currentTime = item.position;
			} catch {}
		};
		const onTime = () => {
			setCurrentTime(el.currentTime);
			if (el.buffered.length) setBuffered(el.buffered.end(el.buffered.length - 1));
			if (saveTimer.current) window.clearTimeout(saveTimer.current);
			saveTimer.current = window.setTimeout(() => {
				rememberPlay(item.id, el.currentTime, el.duration);
			}, 800);
		};
		const onWait = () => setWaiting(true);
		const onPlay = () => {
			setWaiting(false);
			setPlaying(true);
		};
		const onPause = () => setPlaying(false);
		const onErr = () => {
			const err = el.error;
			setError({
				1: "Playback aborted.",
				2: "Network error while loading media.",
				3: "This file is corrupt or uses an unsupported codec.",
				4: "This media type is not supported in this browser."
			}[err?.code ?? 0] ?? "Playback failed.");
		};
		const onEnd = () => {
			rememberPlay(item.id, el.duration || item.position, el.duration);
			setPlaying(false);
		};
		el.addEventListener("loadedmetadata", onMeta);
		el.addEventListener("timeupdate", onTime);
		el.addEventListener("waiting", onWait);
		el.addEventListener("playing", onPlay);
		el.addEventListener("play", onPlay);
		el.addEventListener("pause", onPause);
		el.addEventListener("error", onErr);
		el.addEventListener("ended", onEnd);
		const play = el.play();
		if (play) play.catch(() => setPlaying(false));
		return () => {
			el.removeEventListener("loadedmetadata", onMeta);
			el.removeEventListener("timeupdate", onTime);
			el.removeEventListener("waiting", onWait);
			el.removeEventListener("playing", onPlay);
			el.removeEventListener("play", onPlay);
			el.removeEventListener("pause", onPause);
			el.removeEventListener("error", onErr);
			el.removeEventListener("ended", onEnd);
			if (saveTimer.current) window.clearTimeout(saveTimer.current);
			rememberPlay(item.id, el.currentTime, el.duration);
		};
	}, [
		item?.id,
		src,
		mediaRef,
		rememberPlay,
		setError,
		setPlaying,
		settings.resumePlayback
	]);
	(0, import_react.useEffect)(() => {
		if (!item || typeof navigator === "undefined" || !navigator.mediaSession) return;
		navigator.mediaSession.metadata = new MediaMetadata({
			title: item.name,
			artist: "UPLAY.IND",
			album: item.folder
		});
		const el = mediaRef.current;
		navigator.mediaSession.setActionHandler("play", () => void el?.play());
		navigator.mediaSession.setActionHandler("pause", () => el?.pause());
		navigator.mediaSession.setActionHandler("seekbackward", () => {
			if (el) el.currentTime = Math.max(0, el.currentTime - settings.doubleTapSeek);
		});
		navigator.mediaSession.setActionHandler("seekforward", () => {
			if (el) el.currentTime = Math.min(el.duration || 0, el.currentTime + settings.doubleTapSeek);
		});
		return () => {
			navigator.mediaSession.setActionHandler("play", null);
			navigator.mediaSession.setActionHandler("pause", null);
			navigator.mediaSession.setActionHandler("seekbackward", null);
			navigator.mediaSession.setActionHandler("seekforward", null);
		};
	}, [
		item,
		mediaRef,
		settings.doubleTapSeek
	]);
	const seek = (0, import_react.useCallback)((time) => {
		const el = mediaRef.current;
		if (!el) return;
		el.currentTime = clamp(time, 0, el.duration || 0);
		setCurrentTime(el.currentTime);
	}, [mediaRef]);
	return {
		src,
		currentTime,
		duration,
		buffered,
		volume,
		setVolume,
		muted,
		setMuted,
		speed,
		setSpeed,
		brightness,
		setBrightness,
		aspect,
		setAspect,
		waiting,
		seek,
		skip: (0, import_react.useCallback)((delta) => {
			const el = mediaRef.current;
			if (!el) return;
			seek(el.currentTime + delta);
		}, [mediaRef, seek]),
		toggle: (0, import_react.useCallback)(() => {
			const el = mediaRef.current;
			if (!el) return;
			if (el.paused) el.play();
			else el.pause();
		}, [mediaRef])
	};
}
var ASPECTS = [
	{
		id: "contain",
		label: "Fit"
	},
	{
		id: "cover",
		label: "Crop"
	},
	{
		id: "fill",
		label: "Stretch"
	}
];
function PlayerScreen({ item }) {
	const navigate = useNavigate();
	const items = useLibrary((s) => s.items);
	const mediaRef = (0, import_react.useRef)(null);
	const rootRef = (0, import_react.useRef)(null);
	const fileInput = (0, import_react.useRef)(null);
	const engine = usePlayerEngine(item, mediaRef);
	const locked = usePlayer((s) => s.locked);
	const setLocked = usePlayer((s) => s.setLocked);
	const error = usePlayer((s) => s.error);
	const playing = usePlayer((s) => s.playing);
	const cues = usePlayer((s) => s.cues);
	const subtitleName = usePlayer((s) => s.subtitleName);
	const setCues = usePlayer((s) => s.setCues);
	const nextId = usePlayer((s) => s.nextId);
	const prevId = usePlayer((s) => s.prevId);
	const open = usePlayer((s) => s.open);
	const settings = useSettings();
	const [show, setShow] = (0, import_react.useState)(true);
	const hideTimer = (0, import_react.useRef)(null);
	const [fs, setFs] = (0, import_react.useState)(false);
	const [gestureHint, setGestureHint] = (0, import_react.useState)(null);
	const [bars, setBars] = (0, import_react.useState)(() => Array.from({ length: 16 }, () => .2));
	const cue = (0, import_react.useMemo)(() => activeCue(shiftCues(cues, settings.subtitleDelay), engine.currentTime), [
		cues,
		engine.currentTime,
		settings.subtitleDelay
	]);
	const bumpUi = (0, import_react.useCallback)(() => {
		if (locked) return;
		setShow(true);
		if (hideTimer.current) window.clearTimeout(hideTimer.current);
		hideTimer.current = window.setTimeout(() => {
			if (usePlayer.getState().playing) setShow(false);
		}, settings.autoHideControlsMs);
	}, [locked, settings.autoHideControlsMs]);
	(0, import_react.useEffect)(() => {
		bumpUi();
		return () => {
			if (hideTimer.current) window.clearTimeout(hideTimer.current);
		};
	}, [bumpUi, item.id]);
	(0, import_react.useEffect)(() => {
		const el = mediaRef.current;
		if (!el || item.kind !== "audio") return;
		let raf = 0;
		const tick = () => {
			setBars(eqSpectrum(el, 16));
			raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [item.id, item.kind]);
	const go = (id) => {
		if (!id) return;
		const next = items.find((i) => i.id === id);
		if (!next) return;
		open(next, items.filter((i) => i.kind === next.kind));
		navigate({
			to: "/player/$id",
			params: { id: next.id }
		});
	};
	const toggleFs = async () => {
		const root = rootRef.current;
		if (!root) return;
		try {
			if (!document.fullscreenElement) {
				await root.requestFullscreen();
				setFs(true);
			} else {
				await document.exitFullscreen();
				setFs(false);
			}
		} catch {
			toast.error("Fullscreen is not available.");
		}
	};
	const togglePip = async () => {
		const el = mediaRef.current;
		if (!el || item.kind !== "video") return;
		try {
			if (document.pictureInPictureElement) await document.exitPictureInPicture();
			else if ("requestPictureInPicture" in el) await el.requestPictureInPicture();
		} catch {
			toast.error("Picture-in-picture is not available on this device.");
		}
	};
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
			if (locked && e.key !== "Escape") return;
			bumpUi();
			switch (e.key) {
				case " ":
				case "k":
					e.preventDefault();
					engine.toggle();
					break;
				case "ArrowLeft":
					engine.skip(e.shiftKey ? -settings.doubleTapSeek : -5);
					break;
				case "ArrowRight":
					engine.skip(e.shiftKey ? settings.doubleTapSeek : 5);
					break;
				case "ArrowUp":
					e.preventDefault();
					engine.setVolume(Math.min(1, engine.volume + .05));
					break;
				case "ArrowDown":
					e.preventDefault();
					engine.setVolume(Math.max(0, engine.volume - .05));
					break;
				case "f":
					toggleFs();
					break;
				case "m":
					engine.setMuted(!engine.muted);
					break;
				case "n":
					go(nextId());
					break;
				case "p":
					go(prevId());
					break;
				case "Escape": if (document.fullscreenElement) document.exitFullscreen();
				else navigate({ to: "/" });
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	const src = engine.src;
	const missing = item.source === "local" && !src;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: rootRef,
		className: "player-root relative flex h-dvh flex-col overflow-hidden bg-black text-white",
		style: {
			"--player-brightness": String(engine.brightness),
			"--subtitle-size": `${settings.subtitleSize}rem`,
			"--subtitle-color": settings.subtitleColor,
			"--subtitle-offset": `${settings.subtitlePosition}%`
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileInput,
				type: "file",
				accept: ".srt,.vtt,text/vtt,application/x-subrip",
				className: "sr-only",
				onChange: async (e) => {
					const file = e.target.files?.[0];
					e.target.value = "";
					if (!file) return;
					const parsed = await readSubtitleFile(file);
					if (!parsed.length) {
						toast.error("Could not read that subtitle file.");
						return;
					}
					setCues(parsed, file.name);
					toast.success(`Loaded ${file.name}`);
				}
			}),
			item.kind === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: (n) => {
					mediaRef.current = n;
				},
				src,
				className: cn("player-video absolute inset-0 size-full bg-black", engine.aspect === "contain" && "object-contain", engine.aspect === "cover" && "object-cover", engine.aspect === "fill" && "object-fill"),
				playsInline: true,
				controls: false,
				onClick: (e) => e.preventDefault()
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: (n) => {
					mediaRef.current = n;
				},
				src,
				className: "hidden"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 flex flex-col items-center justify-center gap-8 bg-[radial-gradient(circle_at_50%_30%,rgb(30_224_194_/_0.12),transparent_55%)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl font-semibold",
					children: item.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-24 items-end gap-1",
					children: bars.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-2 origin-bottom rounded-full bg-primary",
						style: { height: `${Math.max(8, v * 96)}px` }
					}, i))
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GestureLayer, {
				enabled: settings.gestures && !locked,
				brightnessEnabled: settings.brightnessGesture,
				seekSeconds: settings.doubleTapSeek,
				duration: engine.duration,
				currentTime: engine.currentTime,
				volume: engine.volume,
				brightness: engine.brightness,
				onToggle: () => {
					if (show) engine.toggle();
					else bumpUi();
				},
				onSeek: (t) => engine.seek(t),
				onSkip: (d) => engine.skip(d),
				onVolume: (v) => engine.setVolume(v),
				onBrightness: (b) => engine.setBrightness(b),
				onHint: setGestureHint,
				onPointer: () => bumpUi()
			}),
			settings.subtitleEnabled && cue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "subtitle-cue pointer-events-none absolute inset-x-8 z-20 mx-auto max-w-3xl rounded-md px-3 py-1.5 text-center font-medium leading-snug",
				children: cue.text
			}) : null,
			gestureHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute left-1/2 top-1/3 z-30 -translate-x-1/2 rounded-lg bg-black/70 px-4 py-2 text-sm tabular-nums",
				children: gestureHint
			}) : null,
			engine.waiting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-20 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 animate-spin rounded-full border-2 border-white/20 border-t-primary" })
			}) : null,
			missing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-black/80 p-6 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl",
					children: "File is not linked"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm text-white/70",
					children: "Local files are not stored in the cloud. Choose the original file to continue."
				})]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-black/80 p-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl",
						children: "Can’t play this"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm text-white/70",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-xs text-white/50",
						children: decoderHelp()
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("absolute inset-0 z-40 flex flex-col justify-between bg-gradient-to-b from-black/70 via-transparent to-black/80 p-3 transition-opacity duration-200 sm:p-5", show && !locked ? "pointer-events-none opacity-100" : "pointer-events-none opacity-0"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex items-start gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "text-white hover:bg-white/10",
							onClick: () => void navigate({ to: "/" }),
							"aria-label": "Back",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate font-display text-base font-semibold",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-white/60",
								children: [
									decoderDescription(),
									" · ",
									item.mime || item.ext.toUpperCase(),
									item.width && item.height ? ` · ${item.width}×${item.height}` : ""
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "text-white hover:bg-white/10",
							onClick: () => setLocked(true),
							"aria-label": "Lock controls",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, {})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-12 text-xs tabular-nums text-white/70",
								children: formatDuration(engine.currentTime)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 0,
								max: Math.max(engine.duration, .1),
								step: .1,
								value: [engine.currentTime],
								onValueChange: ([v]) => engine.seek(v ?? 0),
								"aria-label": "Seek"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-12 text-right text-xs tabular-nums text-white/70",
								children: formatDuration(engine.duration)
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									className: "text-white hover:bg-white/10",
									onClick: () => engine.setMuted(!engine.muted),
									"aria-label": engine.muted ? "Unmute" : "Mute",
									children: engine.muted || engine.volume === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden w-24 sm:block",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
										min: 0,
										max: 1,
										step: .01,
										value: [engine.muted ? 0 : engine.volume],
										onValueChange: ([v]) => {
											engine.setMuted(false);
											engine.setVolume(v ?? 0);
										},
										"aria-label": "Volume"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										className: "text-white hover:bg-white/10",
										onClick: () => engine.skip(-settings.doubleTapSeek),
										"aria-label": "Rewind",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										className: "size-12 rounded-full",
										onClick: engine.toggle,
										"aria-label": playing ? "Pause" : "Play",
										children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "fill-current" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										className: "text-white hover:bg-white/10",
										onClick: () => engine.skip(settings.doubleTapSeek),
										"aria-label": "Forward",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, {})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											className: "text-white hover:bg-white/10",
											"aria-label": "Speed",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {})
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Playback speed" }), SPEED_PRESETS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
										onSelect: () => engine.setSpeed(s),
										children: [
											s === engine.speed ? "• " : "",
											s,
											"×"
										]
									}, s))] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											className: "text-white hover:bg-white/10",
											"aria-label": "Aspect",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {})
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, { children: ASPECTS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
										onSelect: () => engine.setAspect(a.id),
										children: a.label
									}, a.id)) })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											className: "text-white hover:bg-white/10",
											"aria-label": "Tracks",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Captions, {})
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Subtitles" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
											onSelect: () => useSettings.getState().set("subtitleEnabled", !settings.subtitleEnabled),
											children: settings.subtitleEnabled ? "Disable" : "Enable"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
											onSelect: () => fileInput.current?.click(),
											children: "Load SRT / VTT"
										}),
										subtitleName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
											disabled: true,
											children: subtitleName
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Audio" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioTracks, { mediaRef })
									] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											className: "text-white hover:bg-white/10",
											"aria-label": "Queue",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListMusic, {})
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
										onSelect: () => go(prevId()),
										children: "Previous"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
										onSelect: () => go(nextId()),
										children: "Next"
									})] })] }),
									item.kind === "video" && settings.pipEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										className: "text-white hover:bg-white/10",
										onClick: () => void togglePip(),
										"aria-label": "Picture in picture",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PictureInPicture2, {})
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										className: "text-white hover:bg-white/10",
										onClick: () => void toggleFs(),
										"aria-label": "Fullscreen",
										children: fs ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, {})
									})
								]
							})
						]
					})]
				})]
			}),
			locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "absolute right-4 top-4 z-50 rounded-full bg-black/60 p-3 text-white",
				onClick: () => setLocked(false),
				"aria-label": "Unlock controls",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5" })
			}) : null
		]
	});
}
function AudioTracks({ mediaRef }) {
	const el = mediaRef.current;
	const tracks = el?.audioTracks ? Array.from(el.audioTracks) : [];
	const setLabel = usePlayer((s) => s.setAudioTrackLabel);
	if (!tracks.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
		disabled: true,
		children: "Default (this browser exposes one mix)"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: tracks.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
		onSelect: () => {
			for (let j = 0; j < tracks.length; j++) {
				const track = tracks[j];
				track.enabled = j === i;
			}
			setLabel(t.label || t.language || `Track ${i + 1}`);
		},
		children: t.label || t.language || `Track ${i + 1}`
	}, i)) });
}
function GestureLayer({ enabled, brightnessEnabled, seekSeconds, duration, currentTime, volume, brightness, onToggle, onSeek, onSkip, onVolume, onBrightness, onHint, onPointer }) {
	const start = (0, import_react.useRef)(null);
	const lastTap = (0, import_react.useRef)(0);
	const pendingToggle = (0, import_react.useRef)(null);
	const down = (e) => {
		if (!enabled) {
			onPointer();
			return;
		}
		onPointer();
		const rect = e.currentTarget.getBoundingClientRect();
		const x = e.clientX - rect.left;
		const zone = x < rect.width * .33 ? "l" : x > rect.width * .66 ? "r" : "c";
		start.current = {
			x: e.clientX,
			y: e.clientY,
			t: Date.now(),
			vol: volume,
			bri: brightness,
			time: currentTime,
			zone,
			mode: "none"
		};
	};
	const move = (e) => {
		const s = start.current;
		if (!s) return;
		const dx = e.clientX - s.x;
		const dy = e.clientY - s.y;
		if (s.mode === "none") {
			if (Math.abs(dx) > 18 && Math.abs(dx) > Math.abs(dy)) s.mode = "seek";
			else if (Math.abs(dy) > 18) s.mode = s.zone === "l" && brightnessEnabled ? "bri" : "vol";
		}
		if (s.mode === "seek") {
			const delta = dx / 280 * Math.min(120, duration || 120);
			const next = Math.max(0, Math.min(duration, s.time + delta));
			onSeek(next);
			onHint(formatDuration(next));
		} else if (s.mode === "vol") {
			const next = Math.max(0, Math.min(1, s.vol - dy / 220));
			onVolume(next);
			onHint(`Volume ${Math.round(next * 100)}%`);
		} else if (s.mode === "bri") {
			const next = Math.max(.3, Math.min(1.6, s.bri - dy / 260));
			onBrightness(next);
			onHint(`Brightness ${Math.round(next * 100)}%`);
		}
	};
	const up = (e) => {
		const s = start.current;
		start.current = null;
		onHint(null);
		if (!s) return;
		const dist = Math.hypot(e.clientX - s.x, e.clientY - s.y);
		if (s.mode !== "none") return;
		if (dist > 12) return;
		const now = Date.now();
		if (now - lastTap.current < 280) {
			if (pendingToggle.current) {
				window.clearTimeout(pendingToggle.current);
				pendingToggle.current = null;
			}
			lastTap.current = 0;
			if (s.zone === "l") onSkip(-seekSeconds);
			else if (s.zone === "r") onSkip(seekSeconds);
			else onToggle();
			return;
		}
		lastTap.current = now;
		pendingToggle.current = window.setTimeout(() => {
			pendingToggle.current = null;
			onToggle();
		}, 280);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-10",
		onPointerDown: down,
		onPointerMove: move,
		onPointerUp: up,
		onPointerCancel: () => {
			start.current = null;
			onHint(null);
		}
	});
}
function PlayerRoute() {
	const { id } = Route.useParams();
	const ready = useLibrary((s) => s.ready);
	const item = useLibrary((s) => s.items.find((i) => i.id === id));
	const currentId = usePlayer((s) => s.currentId);
	const open = usePlayer((s) => s.open);
	const items = useLibrary((s) => s.items);
	(0, import_react.useEffect)(() => {
		if (item && currentId !== item.id) open(item, items.filter((i) => i.kind === item.kind));
	}, [
		item,
		currentId,
		open,
		items
	]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-dvh items-center justify-center bg-black text-white",
		children: "Loading player…"
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col items-center justify-center gap-3 bg-black p-6 text-center text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Media not in library"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-sm text-white/70",
				children: "This item was removed or never saved on this device."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Back home"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerScreen, { item });
}
//#endregion
export { PlayerRoute as component };
