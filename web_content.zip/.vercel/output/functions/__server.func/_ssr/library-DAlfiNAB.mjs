import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime, a as Overlay2, c as Title2, i as Description2, n as Cancel, o as Portal2, r as Content2, s as Root2, t as Action } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { u as Search, w as LayoutGrid, x as List } from "../_libs/lucide-react.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as Input, D as itemsForTab, G as formatClock, H as decoderDescription, K as formatDuration, O as sortItems, P as Button, T as getFile, V as cn, W as formatBytes, _ as DialogContent, b as DialogHeader, g as Dialog, k as useLibrary, l as Label, o as useSettings, r as Route$2, v as DialogDescription, w as folderGroups, x as DialogTitle, y as DialogFooter, z as buttonVariants } from "./router-5I6roosF.mjs";
import { t as MediaCard } from "./media-card-BeFpTEuT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-DAlfiNAB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	className: cn("fixed inset-0 z-50 bg-black/70", className),
	...props,
	ref
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 grid w-[min(100%-1.5rem,26rem)] -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-elevated p-5 text-fg shadow-[var(--shadow-float)]", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("font-display text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
function FileInspector({ item, action, onClose }) {
	const rename = useLibrary((s) => s.rename);
	const remove = useLibrary((s) => s.remove);
	const relink = useLibrary((s) => s.relink);
	const [name, setName] = (0, import_react.useState)(item?.name ?? "");
	const fileRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setName(item?.name ?? "");
	}, [item?.id, item?.name]);
	if (!item) return null;
	const share = async () => {
		const file = getFile(item.id);
		try {
			if (file && navigator.share) {
				await navigator.share({
					files: [file],
					title: item.name
				});
				return;
			}
			if (item.url && navigator.share) {
				await navigator.share({
					url: item.url,
					title: item.name
				});
				return;
			}
			const text = item.url || item.name;
			await navigator.clipboard.writeText(text);
			toast.success("Copied to clipboard");
		} catch (err) {
			if (err instanceof DOMException && err.name === "AbortError") return;
			toast.error("Sharing is not available in this browser.");
		}
	};
	const openWith = () => {
		const file = getFile(item.id);
		const href = file ? URL.createObjectURL(file) : item.url;
		if (!href) {
			toast.error("This file is not available. Relink it first.");
			return;
		}
		window.open(href, "_blank", "noopener,noreferrer");
	};
	const copyFile = async () => {
		const file = getFile(item.id);
		if (!file) {
			toast.error("Nothing to copy until the file is linked.");
			return;
		}
		const a = document.createElement("a");
		a.href = URL.createObjectURL(file);
		a.download = item.name;
		a.click();
		window.setTimeout(() => URL.revokeObjectURL(a.href), 4e3);
	};
	const infoOpen = !action || action === "info" || action === "rename";
	const deleteOpen = action === "delete";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: fileRef,
			type: "file",
			className: "sr-only",
			onChange: (e) => {
				const file = e.target.files?.[0];
				if (file) relink(item.id, file);
				e.target.value = "";
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: infoOpen,
			onOpenChange: (o) => !o && onClose(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "File information" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: item.relativePath || item.url || item.name })] }),
				action === "rename" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "rename-file",
						children: "Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "rename-file",
						value: name,
						onChange: (e) => setName(e.target.value)
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid grid-cols-2 gap-x-3 gap-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Duration",
							value: formatDuration(item.duration)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Size",
							value: formatBytes(item.size)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Resolution",
							value: item.width && item.height ? `${item.width}×${item.height}` : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Type",
							value: item.mime || item.ext || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Folder",
							value: item.folder
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Decoder",
							value: decoderDescription()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Added",
							value: formatClock(item.addedAt)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							label: "Last played",
							value: item.lastPlayedAt ? formatClock(item.lastPlayedAt) : "Never"
						})
					]
				}),
				!item.linked && item.source === "local" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "The original file is not linked in this session. Relink to play it."
				}) : null,
				item.unsupportedReason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-destructive",
					children: item.unsupportedReason
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, {
					className: "flex-wrap",
					children: action === "rename" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							rename(item.id, name);
							onClose();
						},
						children: "Save name"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => fileRef.current?.click(),
							children: "Relink"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => void share(),
							children: "Share"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: copyFile,
							children: "Copy / save"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: openWith,
							children: "Open with"
						})
					] })
				})
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
			open: deleteOpen,
			onOpenChange: (o) => !o && onClose(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Remove from library?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
				"This removes “",
				item.name,
				"” from UPLAY.IND. The original file on disk is not deleted unless this browser granted file-handle access."
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
				className: "bg-destructive text-destructive-fg",
				onClick: () => {
					remove(item.id);
					toast.success("Removed from library");
					onClose();
				},
				children: "Remove"
			})] })] })
		})
	] });
}
function Info({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "tabular-nums",
		children: value
	})] });
}
var TABS = [
	{
		id: "videos",
		label: "Videos"
	},
	{
		id: "movies",
		label: "Movies"
	},
	{
		id: "music",
		label: "Music"
	},
	{
		id: "recent",
		label: "Recent"
	},
	{
		id: "favourites",
		label: "Favourites"
	},
	{
		id: "folders",
		label: "Folders"
	},
	{
		id: "downloads",
		label: "Downloads"
	}
];
function LibraryPage() {
	const search = Route$2.useSearch();
	const navigate = useNavigate();
	const items = useLibrary((s) => s.items);
	const ready = useLibrary((s) => s.ready);
	const sort = useSettings((s) => s.sort);
	const view = useSettings((s) => s.view);
	const setSetting = useSettings((s) => s.set);
	const [q, setQ] = (0, import_react.useState)(search.q ?? "");
	const tab = search.tab ?? "videos";
	const folders = folderGroups(items);
	const list = (0, import_react.useMemo)(() => {
		let next = itemsForTab(items, tab);
		if (search.folder) next = next.filter((i) => i.folder === search.folder);
		const query = q.trim().toLowerCase();
		if (query) next = next.filter((i) => i.name.toLowerCase().includes(query) || i.folder.toLowerCase().includes(query) || i.relativePath.toLowerCase().includes(query));
		return sortItems(next, sort);
	}, [
		items,
		tab,
		search.folder,
		q,
		sort
	]);
	const inspectItem = items.find((i) => i.id === search.inspect);
	const setTab = (id) => {
		navigate({
			to: "/library",
			search: {
				tab: id,
				q: q || void 0
			}
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold",
					children: "Library"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [items.length, " items on this device"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: view === "grid" ? "secondary" : "ghost",
						"aria-label": "Grid view",
						onClick: () => setSetting("view", "grid"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: view === "list" ? "secondary" : "ghost",
						"aria-label": "List view",
						onClick: () => setSetting("view", "list"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search titles and folders",
					className: "pl-10",
					"aria-label": "Search library"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rail-scroll flex gap-2 overflow-x-auto pb-1",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(t.id),
					className: cn("h-10 shrink-0 rounded-full px-4 text-sm font-medium", tab === t.id ? "bg-primary text-primary-fg" : "bg-secondary text-muted"),
					children: t.label
				}, t.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"name",
					"date",
					"duration",
					"size"
				].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSetting("sort", key),
					className: cn("h-8 rounded-full px-3 text-xs font-medium capitalize", sort === key ? "bg-elevated text-fg shadow-[var(--shadow-border)]" : "text-muted"),
					children: key
				}, key))
			}),
			tab === "folders" && !search.folder ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: [folders.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "w-full rounded-xl bg-surface p-4 text-left shadow-[var(--shadow-border)]",
					onClick: () => void navigate({
						to: "/library",
						search: {
							tab: "folders",
							folder: f.name
						}
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: f.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							f.count,
							" files · ",
							f.videos,
							" video · ",
							f.audio,
							" audio"
						]
					})]
				}) }, f.name)), folders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { ready }) : null]
			}) : list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { ready }) : view === "list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaCard, {
					item,
					queue: list,
					layout: "list"
				}) }, item.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5",
				children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaCard, {
					item,
					queue: list
				}) }, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileInspector, {
				item: inspectItem,
				action: search.action,
				onClose: () => void navigate({
					to: "/library",
					search: {
						tab: search.tab,
						folder: search.folder,
						q: search.q
					}
				})
			})
		]
	});
}
function Empty({ ready }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-6 py-16 text-center shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl font-semibold",
			children: ready ? "No matching files" : "Loading library"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: ready ? "Add media or clear filters." : "Reading on-device index…"
		})]
	});
}
//#endregion
export { LibraryPage as component };
