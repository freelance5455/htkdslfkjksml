import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, i as RotateCcw, n as Volume2, o as Pause, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DEvK_Kd8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var master = null;
function context() {
	if (typeof window === "undefined") return null;
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return null;
	if (!ctx) {
		ctx = new AC();
		master = ctx.createGain();
		master.gain.value = .2;
		master.connect(ctx.destination);
	}
	return ctx;
}
function unlockAudio() {
	const audio = context();
	if (audio && audio.state === "suspended") audio.resume();
}
function setMuted(muted) {
	if (!master) context();
	if (master) master.gain.value = muted ? 0 : .2;
}
function tone(freq, dur, type, gain, delay = 0, slideTo) {
	const audio = context();
	if (!audio || !master) return;
	const osc = audio.createOscillator();
	const amp = audio.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, audio.currentTime + delay);
	if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), audio.currentTime + delay + dur);
	amp.gain.setValueAtTime(gain, audio.currentTime + delay);
	amp.gain.exponentialRampToValueAtTime(1e-4, audio.currentTime + delay + dur);
	osc.connect(amp);
	amp.connect(master);
	osc.start(audio.currentTime + delay);
	osc.stop(audio.currentTime + delay + dur + .02);
}
function noise(dur, gain) {
	const audio = context();
	if (!audio || !master) return;
	const length = Math.floor(audio.sampleRate * dur);
	const buffer = audio.createBuffer(1, length, audio.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
	const src = audio.createBufferSource();
	src.buffer = buffer;
	const amp = audio.createGain();
	const filter = audio.createBiquadFilter();
	filter.type = "highpass";
	filter.frequency.value = 900;
	amp.gain.value = gain;
	src.connect(filter);
	filter.connect(amp);
	amp.connect(master);
	src.start();
}
function playSfx(name) {
	if (!context()) return;
	const wobble = .94 + Math.random() * .12;
	switch (name) {
		case "shoot":
			noise(.06, .15);
			tone(520 * wobble, .09, "triangle", .18, 0, 240);
			break;
		case "pop":
			tone(660 * wobble, .12, "sine", .22, 0, 880);
			tone(990 * wobble, .08, "triangle", .08);
			break;
		case "pop-big":
			tone(520, .14, "triangle", .22, 0, 1040);
			tone(780, .16, "sine", .16, .04, 1240);
			break;
		case "fall":
			tone(420, .18, "sine", .12, 0, 180);
			break;
		case "drop":
			tone(180, .16, "sine", .2, 0, 90);
			break;
		case "stick":
			tone(300, .05, "sine", .08);
			break;
		case "swap":
			tone(540, .06, "sine", .1);
			break;
		case "win":
			tone(523, .12, "triangle", .18, 0);
			tone(659, .12, "triangle", .18, .1);
			tone(784, .22, "triangle", .2, .2);
			break;
		case "lose":
			tone(392, .18, "sine", .16, 0, 262);
			tone(220, .28, "triangle", .14, .12);
	}
}
var ROW_H = Math.sqrt(3) * 18;
var PALETTE = [
	{
		core: "#ff4b6a",
		light: "#ffd5de",
		dark: "#c81e45"
	},
	{
		core: "#ff9f1c",
		light: "#ffe3b8",
		dark: "#e06a00"
	},
	{
		core: "#ffe14a",
		light: "#fff6c2",
		dark: "#e0b400"
	},
	{
		core: "#2ec27e",
		light: "#c9f6e0",
		dark: "#128a52"
	},
	{
		core: "#4c8dff",
		light: "#d6e6ff",
		dark: "#1d4ed8"
	},
	{
		core: "#b06bff",
		light: "#ead9ff",
		dark: "#7c3aed"
	}
];
var SAVE_KEY = "bubble-pop-v1";
var EVEN_NB = [
	[0, -1],
	[0, 1],
	[-1, -1],
	[-1, 0],
	[1, -1],
	[1, 0]
];
var ODD_NB = [
	[0, -1],
	[0, 1],
	[-1, 0],
	[-1, 1],
	[1, 0],
	[1, 1]
];
function parity(row) {
	return (row % 2 + 2) % 2;
}
function colsFor(row) {
	return parity(row) === 0 ? 11 : 10;
}
function key(row, col) {
	return row + "," + col;
}
function cellPos(row, col, minRow) {
	const vis = row - minRow;
	return {
		x: (parity(row) === 1 ? 36 : 18) + col * 2 * 18,
		y: 18 + vis * ROW_H
	};
}
function neighborCells(row, col) {
	const deltas = parity(row) === 1 ? ODD_NB : EVEN_NB;
	const out = [];
	for (const [dr, dc] of deltas) out.push({
		row: row + dr,
		col: col + dc
	});
	return out;
}
function clampAngle(angle) {
	const min = -Math.PI + .16;
	const max = -.16;
	if (angle < min) return min;
	if (angle > max) return max;
	return angle;
}
function levelPlan(level) {
	return {
		colors: Math.min(6, 4 + Math.floor((level - 1) / 3)),
		rows: Math.min(12, 8 + Math.floor((level - 1) / 2)),
		shots: Math.max(5, 8 - Math.floor((level - 1) / 3))
	};
}
function freshState() {
	return {
		phase: "menu",
		bubbles: [],
		minRow: 0,
		current: 0,
		next: 1,
		angle: -Math.PI / 2,
		flying: null,
		particles: [],
		falling: [],
		popping: [],
		texts: [],
		score: 0,
		best: 0,
		level: 1,
		shotsLeft: 8,
		shotsMax: 8,
		lock: 0,
		hitstop: 0,
		shake: 0,
		dropSlide: 0,
		hint: true,
		rev: 0,
		events: [],
		time: 0,
		reduced: false
	};
}
function loadSave() {
	if (typeof localStorage === "undefined") return {
		best: 0,
		mute: false
	};
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return {
			best: 0,
			mute: false
		};
		const parsed = JSON.parse(raw);
		return {
			best: typeof parsed.best === "number" && parsed.best > 0 ? parsed.best : 0,
			mute: parsed.mute === true
		};
	} catch {
		return {
			best: 0,
			mute: false
		};
	}
}
function persist(best, mute) {
	if (typeof localStorage === "undefined") return;
	try {
		localStorage.setItem(SAVE_KEY, JSON.stringify({
			version: 1,
			best,
			mute
		}));
	} catch {}
}
function persistBest(best) {
	persist(best, loadSave().mute);
}
function pushEvent(state, name) {
	state.events.push(name);
	if (state.events.length > 24) state.events.shift();
}
function drainEvents(state) {
	const ev = state.events;
	state.events = [];
	return ev;
}
function pick(colors) {
	return colors[Math.floor(Math.random() * colors.length)] ?? 0;
}
function colorsOnBoard(state) {
	const set = /* @__PURE__ */ new Set();
	for (const b of state.bubbles) set.add(b.color);
	return [...set].sort((a, b) => a - b);
}
function ensureColors(state) {
	const colors = colorsOnBoard(state);
	if (!colors.length) return;
	if (!colors.includes(state.current)) state.current = pick(colors);
	if (!colors.includes(state.next)) state.next = pick(colors);
}
function anchoredSet(state) {
	const present = new Set(state.bubbles.map((b) => key(b.row, b.col)));
	const seen = /* @__PURE__ */ new Set();
	const queue = [];
	for (const b of state.bubbles) {
		if (b.row !== state.minRow) continue;
		const k = key(b.row, b.col);
		if (seen.has(k)) continue;
		seen.add(k);
		queue.push(k);
	}
	while (queue.length) {
		const cur = queue.pop();
		const comma = cur.indexOf(",");
		const row = Number(cur.slice(0, comma));
		const col = Number(cur.slice(comma + 1));
		for (const nb of neighborCells(row, col)) {
			if (nb.col < 0 || nb.col >= colsFor(nb.row)) continue;
			const k = key(nb.row, nb.col);
			if (seen.has(k) || !present.has(k)) continue;
			seen.add(k);
			queue.push(k);
		}
	}
	return seen;
}
function makeBoard(level) {
	const { colors, rows } = levelPlan(level);
	for (let attempt = 0; attempt < 8; attempt++) {
		const map = /* @__PURE__ */ new Map();
		for (let row = 0; row < rows; row++) {
			const n = colsFor(row);
			for (let col = 0; col < n; col++) {
				if (row === rows - 1 && col % 4 === 3) continue;
				let color = row === 0 ? col % colors : Math.floor(Math.random() * colors);
				if (row !== 0) {
					const friends = [];
					for (const nb of neighborCells(row, col)) {
						const v = map.get(key(nb.row, nb.col));
						if (v !== void 0) friends.push(v);
					}
					if (friends.length && Math.random() < .48) color = friends[Math.floor(Math.random() * friends.length)];
					let guard = 0;
					while (guard < 6 && horizontalRun(map, row, col, color) >= 5) {
						color = (color + 1 + Math.floor(Math.random() * (colors - 1))) % colors;
						guard++;
					}
				}
				map.set(key(row, col), color);
			}
		}
		let bubbles = [];
		for (const [k, color] of map) {
			const comma = k.indexOf(",");
			bubbles.push({
				row: Number(k.slice(0, comma)),
				col: Number(k.slice(comma + 1)),
				color
			});
		}
		const probe = freshState();
		probe.bubbles = bubbles;
		probe.minRow = 0;
		const keep = anchoredSet(probe);
		bubbles = bubbles.filter((b) => keep.has(key(b.row, b.col)));
		if (bubbles.length >= rows * 7) return bubbles;
	}
	const fallback = [];
	const plan = levelPlan(level);
	for (let row = 0; row < plan.rows; row++) {
		const n = colsFor(row);
		for (let col = 0; col < n; col++) fallback.push({
			row,
			col,
			color: (row + col) % plan.colors
		});
	}
	return fallback;
}
function horizontalRun(map, row, col, color) {
	let run = 1;
	for (let c = col - 1; c >= 0; c--) {
		if (map.get(key(row, c)) !== color) break;
		run++;
	}
	return run;
}
function bump(state) {
	state.rev++;
}
function createMatch() {
	const saved = loadSave();
	const state = freshState();
	state.best = saved.best;
	state.bubbles = makeBoard(1);
	const colors = colorsOnBoard(state);
	state.current = pick(colors);
	state.next = pick(colors);
	const plan = levelPlan(1);
	state.shotsLeft = plan.shots;
	state.shotsMax = plan.shots;
	return state;
}
function startLevel(state, mode) {
	if (mode === "new") {
		state.score = 0;
		state.level = 1;
	} else state.level += 1;
	const plan = levelPlan(state.level);
	state.minRow = 0;
	state.bubbles = makeBoard(state.level);
	state.shotsLeft = plan.shots;
	state.shotsMax = plan.shots;
	state.flying = null;
	state.particles = [];
	state.falling = [];
	state.popping = [];
	state.texts = [];
	state.lock = 0;
	state.hitstop = 0;
	state.shake = 0;
	state.dropSlide = 0;
	state.angle = -Math.PI / 2;
	state.hint = mode === "new";
	const colors = colorsOnBoard(state);
	state.current = pick(colors);
	state.next = pick(colors);
	state.phase = "playing";
	bump(state);
}
function togglePause(state) {
	if (state.phase === "playing") state.phase = "paused";
	else if (state.phase === "paused") state.phase = "playing";
	bump(state);
}
function canShoot(state) {
	return state.phase === "playing" && !state.flying && state.lock <= 0;
}
function shoot(state) {
	if (!canShoot(state)) return false;
	const ang = state.angle;
	state.flying = {
		x: 198,
		y: 634,
		vx: Math.cos(ang) * 940,
		vy: Math.sin(ang) * 940,
		color: state.current
	};
	const colors = colorsOnBoard(state);
	state.current = state.next;
	state.next = colors.length ? pick(colors) : state.next;
	state.hint = false;
	pushEvent(state, "shoot");
	bump(state);
	return true;
}
function swapBalls(state) {
	if (!canShoot(state)) return;
	const tmp = state.current;
	state.current = state.next;
	state.next = tmp;
	pushEvent(state, "swap");
	bump(state);
}
function aimAt(state, x, y) {
	if (state.phase !== "playing" && state.phase !== "paused") return;
	const dx = x - 198;
	const dy = y - 634;
	if (dx * dx + dy * dy < 324) return;
	state.angle = clampAngle(Math.atan2(dy, dx));
}
function colliding(bubbles, minRow, x, y) {
	const limit = 1207.5625;
	for (const b of bubbles) {
		const p = cellPos(b.row, b.col, minRow);
		if (Math.abs(p.y - y) > 36) continue;
		const dx = p.x - x;
		const dy = p.y - y;
		if (dx * dx + dy * dy <= limit) return true;
	}
	return false;
}
function snapCell(bubbles, minRow, impactX, impactY, fromX, fromY) {
	const occupied = new Set(bubbles.map((b) => key(b.row, b.col)));
	let hitRow = 0;
	let hitCol = 0;
	let hitD = Infinity;
	for (const b of bubbles) {
		const p = cellPos(b.row, b.col, minRow);
		const d = (p.x - impactX) ** 2 + (p.y - impactY) ** 2;
		if (d < hitD) {
			hitD = d;
			hitRow = b.row;
			hitCol = b.col;
		}
	}
	if (!(bubbles.length > 0 && hitD <= 1296)) {
		let best = null;
		let bestD = Infinity;
		const n = colsFor(minRow);
		for (let col = 0; col < n; col++) {
			if (occupied.has(key(minRow, col))) continue;
			const p = cellPos(minRow, col, minRow);
			const d = (p.x - fromX) ** 2 + (p.y - fromY) ** 2;
			if (d < bestD) {
				bestD = d;
				best = {
					row: minRow,
					col
				};
			}
		}
		return best;
	}
	let best = null;
	let bestD = Infinity;
	for (const nb of neighborCells(hitRow, hitCol)) {
		if (nb.row < minRow) continue;
		if (nb.col < 0 || nb.col >= colsFor(nb.row)) continue;
		if (occupied.has(key(nb.row, nb.col))) continue;
		const p = cellPos(nb.row, nb.col, minRow);
		const d = (p.x - fromX) ** 2 + (p.y - fromY) ** 2;
		if (d < bestD) {
			bestD = d;
			best = nb;
		}
	}
	return best;
}
function aimPath(state) {
	const points = [];
	let x = 198;
	let y = 634;
	let vx = Math.cos(state.angle);
	let vy = Math.sin(state.angle);
	const step = 9;
	let bounced = 0;
	let since = 0;
	for (let i = 0; i < 460; i++) {
		x += vx * step;
		y += vy * step;
		since += step;
		if (x < 18) {
			x = 18;
			vx = Math.abs(vx);
			bounced++;
		} else if (x > 378) {
			x = 378;
			vx = -Math.abs(vx);
			bounced++;
		}
		if (since >= 20) {
			points.push({
				x,
				y
			});
			since = 0;
		}
		if (bounced > 5) break;
		if (y <= 18 || colliding(state.bubbles, state.minRow, x, y)) {
			const spd = Math.hypot(vx, vy) || 1;
			return {
				points,
				ghost: snapCell(state.bubbles, state.minRow, x, y, x - vx / spd * 18, y - vy / spd * 18)
			};
		}
		if (y > 680) break;
	}
	return {
		points,
		ghost: null
	};
}
function burst(state, x, y, color, count) {
	const swatch = PALETTE[color] ?? PALETTE[0];
	for (let i = 0; i < count; i++) {
		const ang = Math.random() * Math.PI * 2;
		const spd = 70 + Math.random() * 220;
		state.particles.push({
			x,
			y,
			vx: Math.cos(ang) * spd,
			vy: Math.sin(ang) * spd - 40,
			life: .35 + Math.random() * .35,
			max: .7,
			color: Math.random() < .35 ? swatch.light : swatch.core,
			r: 2 + Math.random() * 3.2
		});
	}
	if (state.particles.length > 240) state.particles.splice(0, state.particles.length - 240);
}
function spawnPop(state, bubble) {
	const p = cellPos(bubble.row, bubble.col, state.minRow);
	state.popping.push({
		x: p.x,
		y: p.y - state.dropSlide,
		color: bubble.color,
		life: .2,
		max: .2
	});
	burst(state, p.x, p.y - state.dropSlide, bubble.color, 8);
}
function spawnFall(state, bubble) {
	const p = cellPos(bubble.row, bubble.col, state.minRow);
	state.falling.push({
		x: p.x,
		y: p.y - state.dropSlide,
		vx: (Math.random() - .5) * 80,
		vy: 30 + Math.random() * 40,
		color: bubble.color,
		life: 1.4
	});
}
function floatText(state, x, y, text) {
	state.texts.push({
		x,
		y,
		text,
		life: .9,
		max: .9
	});
}
function lowestY(state) {
	let max = 0;
	for (const b of state.bubbles) {
		const y = cellPos(b.row, b.col, state.minRow).y;
		if (y > max) max = y;
	}
	return max;
}
function flood(state, row, col, color) {
	const map = /* @__PURE__ */ new Map();
	for (const b of state.bubbles) map.set(key(b.row, b.col), b.color);
	const start = key(row, col);
	if (map.get(start) !== color) return [];
	const seen = /* @__PURE__ */ new Set([start]);
	const queue = [start];
	const out = [start];
	while (queue.length) {
		const cur = queue.pop();
		const comma = cur.indexOf(",");
		const r = Number(cur.slice(0, comma));
		const c = Number(cur.slice(comma + 1));
		for (const nb of neighborCells(r, c)) {
			if (nb.col < 0 || nb.col >= colsFor(nb.row)) continue;
			const k = key(nb.row, nb.col);
			if (seen.has(k) || map.get(k) !== color) continue;
			seen.add(k);
			queue.push(k);
			out.push(k);
		}
	}
	return out;
}
function dropCeiling(state) {
	const row = state.minRow - 1;
	const colors = colorsOnBoard(state);
	const palette = colors.length ? colors : [
		0,
		1,
		2,
		3
	];
	const n = colsFor(row);
	for (let col = 0; col < n; col++) {
		let color = pick(palette);
		for (const nb of neighborCells(row, col)) {
			const found = state.bubbles.find((b) => b.row === nb.row && b.col === nb.col);
			if (found && Math.random() < .45) {
				color = found.color;
				break;
			}
		}
		state.bubbles.push({
			row,
			col,
			color
		});
	}
	state.minRow = row;
	state.dropSlide = ROW_H;
	state.lock = Math.max(state.lock, .26);
	pushEvent(state, "drop");
}
function missShot(state) {
	state.shotsLeft -= 1;
	if (state.shotsLeft <= 0) {
		dropCeiling(state);
		const plan = levelPlan(state.level);
		state.shotsLeft = plan.shots;
		state.shotsMax = plan.shots;
		ensureColors(state);
	}
	if (lowestY(state) > 552) {
		state.phase = "over";
		pushEvent(state, "lose");
		if (state.score > state.best) state.best = state.score;
		persistBest(state.best);
	}
	bump(state);
}
function settle(state, row, col, color) {
	state.bubbles.push({
		row,
		col,
		color
	});
	const group = flood(state, row, col, color);
	let popped = 0;
	if (group.length >= 3) {
		const doomed = new Set(group);
		const stay = [];
		for (const b of state.bubbles) if (doomed.has(key(b.row, b.col))) {
			spawnPop(state, b);
			popped++;
		} else stay.push(b);
		state.bubbles = stay;
	}
	const keep = anchoredSet(state);
	const stay = [];
	const fallers = [];
	for (const b of state.bubbles) if (keep.has(key(b.row, b.col))) stay.push(b);
	else fallers.push(b);
	state.bubbles = stay;
	for (const b of fallers) spawnFall(state, b);
	let gained = 0;
	if (popped >= 3) gained += popped * 10;
	gained += fallers.length * 25;
	if (popped >= 6) gained += 60;
	if (popped + fallers.length >= 10) gained += 120;
	state.score += gained;
	if (gained > 0) {
		const spot = cellPos(row, col, state.minRow);
		floatText(state, spot.x, spot.y - state.dropSlide, "+" + gained);
		const word = popped + fallers.length >= 10 ? "Amazing!" : popped >= 6 || fallers.length >= 4 ? "Super!" : popped >= 3 ? "Pop!" : "";
		if (word) floatText(state, spot.x, spot.y - state.dropSlide - 26, word);
	}
	if (popped >= 3) {
		state.shake = state.reduced ? 0 : Math.min(1, .28 + popped * .05);
		state.hitstop = state.reduced ? 0 : Math.min(.07, .02 + popped * .006);
		state.lock = Math.max(state.lock, .16);
		pushEvent(state, popped >= 6 ? "pop-big" : "pop");
	} else if (fallers.length) {
		state.shake = state.reduced ? 0 : .22;
		state.lock = Math.max(state.lock, .12);
		pushEvent(state, "fall");
	} else {
		state.lock = Math.max(state.lock, .05);
		pushEvent(state, "stick");
	}
	if (state.score > state.best) {
		state.best = state.score;
		persistBest(state.best);
	}
	ensureColors(state);
	if (state.bubbles.length === 0) {
		const bonus = 400 * state.level;
		state.score += bonus;
		if (state.score > state.best) state.best = state.score;
		persistBest(state.best);
		floatText(state, 198, 680 * .42, "+" + bonus);
		burst(state, 198, 680 * .35, color, 36);
		state.phase = "cleared";
		pushEvent(state, "win");
		bump(state);
		return;
	}
	state.shotsLeft -= 1;
	if (state.shotsLeft <= 0) {
		dropCeiling(state);
		const plan = levelPlan(state.level);
		state.shotsLeft = plan.shots;
		state.shotsMax = plan.shots;
		ensureColors(state);
	}
	if (lowestY(state) > 552) {
		state.phase = "over";
		pushEvent(state, "lose");
		persistBest(state.best);
	}
	bump(state);
}
function advanceFlying(state, dt) {
	const flyer = state.flying;
	if (!flyer) return;
	let left = dt;
	const maxStep = 6 / 940;
	while (left > 0 && state.flying) {
		const h = Math.min(left, maxStep);
		left -= h;
		flyer.x += flyer.vx * h;
		flyer.y += flyer.vy * h;
		if (flyer.x < 18) {
			flyer.x = 18;
			flyer.vx = Math.abs(flyer.vx);
		} else if (flyer.x > 378) {
			flyer.x = 378;
			flyer.vx = -Math.abs(flyer.vx);
		}
		if (flyer.y <= 18 || colliding(state.bubbles, state.minRow, flyer.x, flyer.y)) {
			const spd = Math.hypot(flyer.vx, flyer.vy) || 1;
			const cell = snapCell(state.bubbles, state.minRow, flyer.x, flyer.y, flyer.x - flyer.vx / spd * 18, flyer.y - flyer.vy / spd * 18);
			const color = flyer.color;
			state.flying = null;
			if (cell) settle(state, cell.row, cell.col, color);
			else missShot(state);
			return;
		}
		if (flyer.y > 710) {
			state.flying = null;
			missShot(state);
			return;
		}
	}
}
function tick(state, dt) {
	const step = Math.min(dt, .05);
	state.time += step;
	if (state.phase === "paused" || state.phase === "menu") return;
	for (const p of state.particles) {
		p.life -= step;
		p.vy += 420 * step;
		p.x += p.vx * step;
		p.y += p.vy * step;
	}
	state.particles = state.particles.filter((p) => p.life > 0);
	for (const f of state.falling) {
		f.life -= step;
		f.vy += 1300 * step;
		f.x += f.vx * step;
		f.y += f.vy * step;
	}
	state.falling = state.falling.filter((f) => f.life > 0 && f.y < 720);
	for (const p of state.popping) p.life -= step;
	state.popping = state.popping.filter((p) => p.life > 0);
	for (const t of state.texts) {
		t.life -= step;
		t.y -= 36 * step;
	}
	state.texts = state.texts.filter((t) => t.life > 0);
	if (state.dropSlide > 0) state.dropSlide = Math.max(0, state.dropSlide - step * ROW_H * 5);
	if (state.hitstop > 0) {
		state.hitstop -= step;
		return;
	}
	if (state.lock > 0) state.lock = Math.max(0, state.lock - step);
	if (state.shake > 0) state.shake = Math.max(0, state.shake - step * 1.7);
	if (state.phase === "playing") advanceFlying(state, step);
}
function lowestBubbleY(state) {
	return lowestY(state);
}
function bubble(ctx, x, y, radius, color, alpha) {
	const swatch = PALETTE[color] ?? PALETTE[0];
	ctx.save();
	ctx.globalAlpha = alpha;
	ctx.beginPath();
	ctx.arc(x, y + radius * .08, radius * .92, 0, Math.PI * 2);
	ctx.fillStyle = "rgba(70, 40, 110, 0.16)";
	ctx.fill();
	const grad = ctx.createRadialGradient(x - radius * .35, y - radius * .4, radius * .15, x, y + radius * .1, radius);
	grad.addColorStop(0, swatch.light);
	grad.addColorStop(.42, swatch.core);
	grad.addColorStop(1, swatch.dark);
	ctx.beginPath();
	ctx.arc(x, y, radius, 0, Math.PI * 2);
	ctx.fillStyle = grad;
	ctx.fill();
	ctx.lineWidth = 1.25;
	ctx.strokeStyle = "rgba(50, 24, 80, 0.28)";
	ctx.stroke();
	ctx.beginPath();
	ctx.ellipse(x - radius * .28, y - radius * .34, radius * .28, radius * .15, -.6, 0, Math.PI * 2);
	ctx.fillStyle = "rgba(255,255,255,0.78)";
	ctx.fill();
	ctx.restore();
}
function drawBubbleGrid(ctx, state) {
	const slide = state.dropSlide;
	for (const b of state.bubbles) {
		const p = cellPos(b.row, b.col, state.minRow);
		bubble(ctx, p.x, p.y - slide, 17.28, b.color, 1);
	}
}
function render(ctx, state) {
	ctx.clearRect(0, 0, 396, 680);
	const sky = ctx.createLinearGradient(0, 0, 0, 680);
	sky.addColorStop(0, "#f7f4ff");
	sky.addColorStop(.5, "#e7dcfc");
	sky.addColorStop(1, "#cbb6f2");
	ctx.fillStyle = sky;
	ctx.fillRect(0, 0, 396, 680);
	ctx.save();
	if (!state.reduced && state.shake > 0) {
		const mag = state.shake * state.shake * 8;
		ctx.translate(Math.sin(state.time * 46) * mag, Math.cos(state.time * 39) * mag * .65);
	}
	if (state.phase !== "menu") {
		const danger = state.bubbles.reduce((max, b) => {
			const y = cellPos(b.row, b.col, state.minRow).y;
			return y > max ? y : max;
		}, 0) > 474;
		ctx.save();
		ctx.setLineDash([7, 7]);
		ctx.lineWidth = 2;
		ctx.strokeStyle = danger ? "rgba(212, 51, 90, 0.9)" : "rgba(90, 62, 140, 0.28)";
		ctx.beginPath();
		ctx.moveTo(14, 552);
		ctx.lineTo(382, 552);
		ctx.stroke();
		ctx.restore();
		if (danger && state.phase === "playing") {
			ctx.font = "800 13px Nunito, ui-rounded, sans-serif";
			ctx.fillStyle = "#d4335a";
			ctx.textAlign = "center";
			ctx.fillText("Watch the line", 198, 544);
		}
	}
	drawBubbleGrid(ctx, state);
	for (const pop of state.popping) {
		const t = 1 - pop.life / pop.max;
		const scale = t < .35 ? 1 + t * .8 : 1.28 * (1 - (t - .35) / .65);
		bubble(ctx, pop.x, pop.y, 17.28 * Math.max(.05, scale), pop.color, 1 - t);
	}
	for (const fall of state.falling) bubble(ctx, fall.x, fall.y, 17.28, fall.color, Math.max(0, Math.min(1, fall.life)));
	if (state.phase === "playing" && !state.flying) {
		const path = aimPath(state);
		ctx.fillStyle = (PALETTE[state.current] ?? PALETTE[0]).core;
		for (let i = 0; i < path.points.length; i++) {
			const p = path.points[i];
			if (!p) continue;
			ctx.globalAlpha = .9 - i / path.points.length * .55;
			ctx.beginPath();
			ctx.arc(p.x, p.y, i % 3 === 0 ? 3.4 : 2.5, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.globalAlpha = 1;
		if (path.ghost) {
			const g = cellPos(path.ghost.row, path.ghost.col, state.minRow);
			const losing = g.y > 552;
			bubble(ctx, g.x, g.y - state.dropSlide, 17.28, state.current, losing ? .28 : .4);
			if (losing) {
				ctx.beginPath();
				ctx.arc(g.x, g.y - state.dropSlide, 12.6, 0, Math.PI * 2);
				ctx.strokeStyle = "rgba(212, 51, 90, 0.9)";
				ctx.lineWidth = 2;
				ctx.stroke();
			}
		}
	}
	if (state.flying) {
		const f = state.flying;
		const ang = Math.atan2(f.vy, f.vx);
		ctx.save();
		ctx.translate(f.x, f.y);
		ctx.rotate(ang);
		ctx.scale(1.08, .93);
		bubble(ctx, 0, 0, 17.28, f.color, 1);
		ctx.restore();
	}
	ctx.beginPath();
	ctx.ellipse(198, 649.3, 12.6, 18 * .28, 0, 0, Math.PI * 2);
	ctx.fillStyle = "rgba(70, 40, 110, 0.18)";
	ctx.fill();
	ctx.beginPath();
	ctx.arc(198, 634, 23, 0, Math.PI * 2);
	ctx.strokeStyle = "rgba(255,255,255,0.92)";
	ctx.lineWidth = 3;
	ctx.stroke();
	ctx.beginPath();
	ctx.arc(198, 634, 23, 0, Math.PI * 2);
	ctx.strokeStyle = "rgba(80, 50, 130, 0.35)";
	ctx.lineWidth = 1;
	ctx.stroke();
	if (!state.flying || state.phase === "menu") bubble(ctx, 198, 634, 17.28, state.current, 1);
	else bubble(ctx, 198, 634, 17.28, state.current, 1);
	for (const bit of state.particles) {
		ctx.globalAlpha = Math.max(0, bit.life / bit.max);
		ctx.fillStyle = bit.color;
		ctx.beginPath();
		ctx.arc(bit.x, bit.y, bit.r, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
	ctx.textAlign = "center";
	ctx.lineJoin = "round";
	for (const text of state.texts) {
		ctx.globalAlpha = Math.max(0, text.life / text.max);
		ctx.font = text.text.startsWith("+") ? "800 20px Nunito, ui-rounded, sans-serif" : "800 18px Nunito, ui-rounded, sans-serif";
		ctx.lineWidth = 4;
		ctx.strokeStyle = "rgba(255,255,255,0.92)";
		ctx.strokeText(text.text, text.x, text.y);
		ctx.fillStyle = "#2a2142";
		ctx.fillText(text.text, text.x, text.y);
	}
	ctx.globalAlpha = 1;
	ctx.restore();
}
function snapshot(state) {
	const low = lowestBubbleY(state);
	return {
		phase: state.phase,
		score: state.score,
		best: state.best,
		level: state.level,
		shotsLeft: state.shotsLeft,
		shotsMax: state.shotsMax,
		current: state.current,
		next: state.next,
		left: state.bubbles.length,
		danger: state.phase === "playing" && low > 474,
		hint: state.hint,
		rev: state.rev
	};
}
function BubblePop() {
	const canvasRef = (0, import_react.useRef)(null);
	const stateRef = (0, import_react.useRef)(null);
	const layoutRef = (0, import_react.useRef)({
		scale: 1,
		ox: 0,
		oy: 0
	});
	const muteRef = (0, import_react.useRef)(false);
	const armedRef = (0, import_react.useRef)(false);
	const [hud, setHud] = (0, import_react.useState)(null);
	const [mute, setMute] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const state = createMatch();
		state.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const savedMute = window.localStorage.getItem("bubble-pop-v1");
		if (savedMute) try {
			const parsed = JSON.parse(savedMute);
			muteRef.current = parsed.mute === true;
		} catch {
			muteRef.current = false;
		}
		stateRef.current = state;
		setMute(muteRef.current);
		setMuted(muteRef.current);
		setHud(snapshot(state));
		const keys = /* @__PURE__ */ new Set();
		let frame = 0;
		let last = performance.now();
		let seen = state.rev;
		let alive = true;
		const onKeyDown = (event) => {
			if (event.repeat) return;
			keys.add(event.code);
			const current = stateRef.current;
			if (!current) return;
			if ([
				"Space",
				"ArrowUp",
				"ArrowLeft",
				"ArrowRight",
				"Enter"
			].includes(event.code)) event.preventDefault();
			if (event.code === "KeyM") {
				flipMute();
				return;
			}
			if (event.code === "KeyP") {
				togglePause(current);
				return;
			}
			if (event.code === "KeyS") {
				unlockAudio();
				swapBalls(current);
				return;
			}
			if (event.code === "Space" || event.code === "Enter" || event.code === "ArrowUp") {
				unlockAudio();
				if (current.phase === "menu" || current.phase === "over") startLevel(current, "new");
				else if (current.phase === "cleared") startLevel(current, "next");
				else if (current.phase === "paused") togglePause(current);
				else shoot(current);
			}
		};
		const onKeyUp = (event) => {
			keys.delete(event.code);
		};
		const loop = (now) => {
			if (!alive) return;
			const current = stateRef.current;
			const canvas = canvasRef.current;
			if (!current || !canvas) {
				frame = requestAnimationFrame(loop);
				return;
			}
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			if (current.phase === "playing" && canShoot(current)) {
				if (keys.has("ArrowLeft") || keys.has("KeyA")) current.angle = Math.max(-Math.PI + .16, current.angle - 1.8 * dt);
				if (keys.has("ArrowRight") || keys.has("KeyD")) current.angle = Math.min(-.16, current.angle + 1.8 * dt);
			}
			tick(current, dt);
			for (const name of drainEvents(current)) playSfx(name);
			paint(canvas, current);
			if (current.rev !== seen) {
				seen = current.rev;
				setHud(snapshot(current));
			}
			frame = requestAnimationFrame(loop);
		};
		frame = requestAnimationFrame(loop);
		window.addEventListener("keydown", onKeyDown);
		window.addEventListener("keyup", onKeyUp);
		window.__bubble = {
			start: () => {
				const current = stateRef.current;
				if (current) startLevel(current, "new");
			},
			shoot: (degFromUp) => {
				const current = stateRef.current;
				if (!current) return false;
				if (current.phase !== "playing") startLevel(current, "new");
				current.angle = -Math.PI / 2 + degFromUp * Math.PI / 180;
				return shoot(current);
			},
			tick: (dt) => {
				const current = stateRef.current;
				if (current) tick(current, dt);
			},
			get: () => {
				const current = stateRef.current;
				if (!current) return null;
				return {
					phase: current.phase,
					score: current.score,
					bubbles: current.bubbles.length,
					level: current.level,
					shotsLeft: current.shotsLeft,
					flying: Boolean(current.flying)
				};
			}
		};
		return () => {
			alive = false;
			cancelAnimationFrame(frame);
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("keyup", onKeyUp);
		};
	}, []);
	function flipMute() {
		muteRef.current = !muteRef.current;
		setMute(muteRef.current);
		setMuted(muteRef.current);
		const current = stateRef.current;
		if (current) persist(current.best, muteRef.current);
	}
	function paint(canvas, state) {
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		const cssW = canvas.clientWidth;
		const cssH = canvas.clientHeight;
		if (cssW < 2 || cssH < 2) return;
		const nextW = Math.round(cssW * dpr);
		const nextH = Math.round(cssH * dpr);
		if (canvas.width !== nextW || canvas.height !== nextH) {
			canvas.width = nextW;
			canvas.height = nextH;
		}
		const scale = Math.min(cssW / 396, cssH / 680);
		const ox = (cssW - 396 * scale) / 2;
		const oy = (cssH - 680 * scale) / 2;
		layoutRef.current = {
			scale,
			ox,
			oy
		};
		ctx.setTransform(dpr * scale, 0, 0, dpr * scale, dpr * ox, dpr * oy);
		render(ctx, state);
	}
	function point(event) {
		const canvas = canvasRef.current;
		const layout = layoutRef.current;
		if (!canvas || layout.scale <= 0) return null;
		const rect = canvas.getBoundingClientRect();
		return {
			x: (event.clientX - rect.left - layout.ox) / layout.scale,
			y: (event.clientY - rect.top - layout.oy) / layout.scale
		};
	}
	function onPointerDown(event) {
		if (event.button !== 0) return;
		const state = stateRef.current;
		const at = point(event);
		if (!state || !at) return;
		unlockAudio();
		if (state.phase === "menu") return;
		if (state.phase === "paused") return;
		armedRef.current = true;
		aimAt(state, at.x, at.y);
		event.currentTarget.setPointerCapture(event.pointerId);
	}
	function onPointerMove(event) {
		const state = stateRef.current;
		const at = point(event);
		if (!state || !at) return;
		if (state.phase !== "playing") return;
		aimAt(state, at.x, at.y);
	}
	function onPointerUp(event) {
		const state = stateRef.current;
		const at = point(event);
		if (!state || !at) return;
		if (armedRef.current && state.phase === "playing") {
			aimAt(state, at.x, at.y);
			shoot(state);
		}
		armedRef.current = false;
	}
	const phase = hud?.phase ?? "menu";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page flex h-full justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-full w-full max-w-md flex-col bg-panel sm:my-3 sm:h-[calc(100%-1.5rem)] sm:overflow-hidden sm:rounded-3xl sm:shadow-xl sm:ring-1 sm:ring-line",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mark",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-lg leading-none font-extrabold",
							children: "Bubble Pop"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-bold text-muted",
							children: [
								"Level ",
								hud?.level ?? 1,
								hud && (phase === "playing" || phase === "paused") ? ` · ${hud.left} left` : ""
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl leading-none font-extrabold tabular-nums",
							"aria-live": "polite",
							children: hud?.score ?? 0
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-bold text-muted",
							children: ["Best ", hud?.best ?? 0]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-h-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: canvasRef,
							className: "h-full w-full touch-none",
							"aria-label": "Bubble board. Aim and release to shoot.",
							onPointerDown,
							onPointerMove,
							onPointerUp,
							onPointerCancel: () => {
								armedRef.current = false;
							}
						}),
						hud?.hint && phase === "playing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pointer-events-none absolute inset-x-0 top-3 text-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-panel px-3 py-1 text-sm font-extrabold text-ink shadow-sm ring-1 ring-line",
								children: "Aim, then release to shoot"
							})
						}),
						phase !== "playing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 flex items-center justify-center bg-ink/25 p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full max-w-sm rounded-3xl bg-panel p-5 shadow-lg ring-1 ring-line",
								children: [
									phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-2xl font-extrabold",
											children: "Bubble Pop"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed font-bold text-muted",
											children: "Aim, shoot, and match 3 or more of the same color. Clear the board before the bubbles reach the line."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed font-bold text-ink",
											children: "तीन एक जैसे रंग मिलाओ — गुब्बारे फूट जाएँगे!"
										}),
										(hud?.best ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-3 text-sm font-extrabold text-accent",
											children: ["Best score ", hud?.best]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent font-extrabold text-accent-ink",
											onClick: () => {
												unlockAudio();
												const state = stateRef.current;
												if (state) startLevel(state, "new");
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
												className: "size-5",
												"aria-hidden": "true"
											}), "Play"]
										})
									] }),
									phase === "paused" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-2xl font-extrabold",
											children: "Paused"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-2 text-sm font-bold text-muted",
											children: ["Score ", hud?.score ?? 0]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent font-extrabold text-accent-ink",
											onClick: () => {
												const state = stateRef.current;
												if (state) togglePause(state);
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
												className: "size-5",
												"aria-hidden": "true"
											}), "Resume"]
										})
									] }),
									phase === "cleared" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-2xl font-extrabold text-good",
											children: "Level clear!"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-2 text-sm font-bold text-muted",
											children: [
												"Score ",
												hud?.score ?? 0,
												". Bonus added for a clear board."
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent font-extrabold text-accent-ink",
											onClick: () => {
												unlockAudio();
												const state = stateRef.current;
												if (state) startLevel(state, "next");
											},
											children: "Next level"
										})
									] }),
									phase === "over" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-2xl font-extrabold",
											children: "Board filled up"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-2 text-sm font-bold text-muted",
											children: [
												"The bubbles reached the line. Score ",
												hud?.score ?? 0,
												"."
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent font-extrabold text-accent-ink",
											onClick: () => {
												unlockAudio();
												const state = stateRef.current;
												if (state) startLevel(state, "new");
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
												className: "size-5",
												"aria-hidden": "true"
											}), "Play again"]
										})
									] })
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "flex items-center justify-between gap-2 px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "swatch shrink-0",
							"data-color": hud?.next ?? 1,
							"aria-label": "Swap with the next bubble",
							onClick: () => {
								unlockAudio();
								const state = stateRef.current;
								if (state) swapBalls(state);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 flex-col items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-extrabold text-muted",
								children: ["Ceiling in ", hud?.shotsLeft ?? 8]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap justify-center gap-1",
								"aria-hidden": "true",
								children: Array.from({ length: hud?.shotsMax ?? 8 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: index < (hud?.shotsLeft ?? 0) ? "pip on" : "pip" }, index))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "flex size-11 items-center justify-center rounded-full bg-bg text-ink",
									"aria-label": phase === "paused" ? "Resume" : "Pause",
									onClick: () => {
										const state = stateRef.current;
										if (!state) return;
										if (state.phase === "menu") return;
										if (state.phase === "cleared" || state.phase === "over") return;
										togglePause(state);
									},
									children: phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
										className: "size-5",
										"aria-hidden": "true"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
										className: "size-5",
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "flex size-11 items-center justify-center rounded-full bg-bg text-ink",
									"aria-label": mute ? "Unmute" : "Mute",
									onClick: () => {
										unlockAudio();
										flipMute();
									},
									children: mute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
										className: "size-5",
										"aria-hidden": "true"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
										className: "size-5",
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "flex size-11 items-center justify-center rounded-full bg-bg text-ink",
									"aria-label": "Restart",
									onClick: () => {
										unlockAudio();
										const state = stateRef.current;
										if (state) startLevel(state, "new");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
										className: "size-5",
										"aria-hidden": "true"
									})
								})
							]
						})
					]
				})
			]
		})
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page fixed inset-0 text-ink",
		children: ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BubblePop, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-full items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-extrabold",
				children: "Bubble Pop"
			})
		})
	});
}
//#endregion
export { Home as component };
