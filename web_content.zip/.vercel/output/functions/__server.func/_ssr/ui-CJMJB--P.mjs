import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-CJMJB--P.js
var import_jsx_runtime = require_jsx_runtime();
var FPS_TARGETS = [
	30,
	45,
	60,
	72,
	90,
	120,
	140
];
var PRESETS = [
	"battery",
	"balanced",
	"performance",
	"custom"
];
var GRAPHICS = [
	"low",
	"medium",
	"high",
	"ultra",
	"custom"
];
var SCALE = [
	"native",
	"0.75",
	"0.5"
];
var DETAIL = [
	"off",
	"low",
	"medium",
	"high"
];
var AA = [
	"off",
	"fxaa",
	"taa"
];
var THEMES = [
	"dark",
	"light",
	"system"
];
var ACCENTS = [
	{
		id: "crimson",
		label: "Crimson"
	},
	{
		id: "copper",
		label: "Copper"
	},
	{
		id: "steel",
		label: "Steel"
	},
	{
		id: "wine",
		label: "Wine"
	}
];
var BACKGROUNDS = [
	{
		id: "graphite",
		label: "Graphite"
	},
	{
		id: "carbon",
		label: "Carbon"
	},
	{
		id: "warm",
		label: "Warm"
	}
];
var DENSITIES = ["comfortable", "compact"];
var MOTIONS = [
	"off",
	"subtle",
	"full"
];
var CARD_STYLES = ["poster", "row"];
var WIDGETS = [
	{
		id: "quick",
		label: "Quick actions",
		detail: "Optimize, library, clicker, tutorials, customize"
	},
	{
		id: "session",
		label: "Session timer",
		detail: "Shared clock for this play session"
	},
	{
		id: "profile",
		label: "Selected game",
		detail: "Active profile and target"
	},
	{
		id: "status",
		label: "Performance status",
		detail: "Preset, target, last manual FPS, battery"
	},
	{
		id: "refresh",
		label: "Display refresh",
		detail: "Estimate from this page only"
	},
	{
		id: "capabilities",
		label: "Device and browser",
		detail: "Signals this browser can actually report"
	}
];
var THERMAL_CHECKS = [
	{
		id: "brightness",
		label: "Lowered screen brightness"
	},
	{
		id: "apps",
		label: "Closed apps I am not using"
	},
	{
		id: "case",
		label: "Removed a thick case or moved out of direct heat"
	},
	{
		id: "effects",
		label: "Lowered in-game shadows and effects"
	},
	{
		id: "break",
		label: "Paused play so the phone can cool down"
	}
];
var BACKGROUND_TIPS = [
	"Swipe away apps you are not using from the Android recents screen. This app cannot close them for you.",
	"Lower brightness. A bright panel adds heat, and heat makes frame time worse.",
	"On Samsung phones, Game Launcher and Game Booster are system settings you turn on yourself. This page cannot toggle them.",
	"Pause screen recorders, floating chats, and extra browsers while you play.",
	"Android Settings, then Battery, is where battery saver and background limits actually live."
];
var THERMAL_TIPS = [
	"Phones slow the CPU and GPU when they get hot. That is thermal throttling. Frame time gets worse even if your settings did not change.",
	"This browser cannot read skin or battery temperature. If the phone feels hot to your hand, treat that as the signal.",
	"First response: drop shadows and effects, lower brightness, and take the case off if it traps heat.",
	"Charging while playing adds heat. If the session is already warm, play on battery or take a break.",
	"A higher FPS target produces more heat. It does not bypass the phone's thermal limit."
];
var WORKS_NOW = [
	"Add games yourself, with an icon, notes, a launch link, and a separate saved profile for each one.",
	"Pick FPS targets and graphics presets. They are saved as recommendations you apply inside the game.",
	"Log FPS you measured yourself, compare sessions, and see charts of those entries.",
	"Estimate this page's refresh rate from animation frames. It is not the game's FPS.",
	"Read browser signals when they exist: CPU core count, a coarse memory class, WebGL GPU name, battery, network hints, and storage.",
	"Run a session timer. Optionally keep the screen awake with the Screen Wake Lock API while the timer runs.",
	"Plan click sequences and practice them on the pad inside this app. Start, pause, resume, and stop.",
	"Customize theme, accent, density, motion, and home widgets. Export or import a JSON backup. Reset local data."
];
var NEEDS_NATIVE = [
	"Scanning every installed Android package. A normal web app cannot see your app list.",
	"Opening an installed game unless you provide a normal link or app link.",
	"Changing CPU or GPU clocks, resolution, or another app's graphics settings.",
	"Forcing a game to 120 or 140 FPS, or unlocking a cap the game or phone does not expose.",
	"Frame generation. Interpolated frames cannot be injected into other apps from this page.",
	"A real performance overlay drawn on top of games.",
	"System-wide auto click. That needs a native app and an accessibility service you explicitly allow. This app will not request it.",
	"Live CPU load, GPU load, and device temperature. Browsers do not provide those sensors.",
	"Closing background apps or editing system battery restrictions for you."
];
var PRESET_LABEL = {
	battery: "Battery Saver",
	balanced: "Balanced",
	performance: "Performance",
	custom: "Custom"
};
var GRAPHICS_LABEL = {
	low: "Low",
	medium: "Medium",
	high: "High",
	ultra: "Ultra",
	custom: "Custom"
};
var DETAIL_LABEL = {
	off: "Off",
	low: "Low",
	medium: "Medium",
	high: "High"
};
var SCALE_LABEL = {
	native: "Native",
	"0.75": "75%",
	"0.5": "50%"
};
var AA_LABEL = {
	off: "Off",
	fxaa: "FXAA",
	taa: "TAA"
};
function presetLabel(value) {
	return PRESET_LABEL[value];
}
function graphicsLabel(value) {
	return GRAPHICS_LABEL[value];
}
function detailLabel(value) {
	return DETAIL_LABEL[value];
}
function scaleLabel(value) {
	return SCALE_LABEL[value];
}
function aaLabel(value) {
	return AA_LABEL[value];
}
function isFpsTarget(value) {
	return FPS_TARGETS.includes(value);
}
function visualsForPreset(preset, currentTarget) {
	if (preset === "battery") return {
		graphics: "low",
		fpsTarget: 30,
		resolutionScale: "0.5",
		shadows: "off",
		effects: "off",
		aa: "off",
		vsync: "on"
	};
	if (preset === "balanced") return {
		graphics: "medium",
		fpsTarget: 60,
		resolutionScale: "native",
		shadows: "low",
		effects: "low",
		aa: "fxaa",
		vsync: "on"
	};
	return {
		graphics: "medium",
		fpsTarget: currentTarget,
		resolutionScale: "native",
		shadows: "low",
		effects: "medium",
		aa: "fxaa",
		vsync: "off"
	};
}
function visualsForGraphics(level) {
	if (level === "low") return {
		graphics: "low",
		resolutionScale: "0.5",
		shadows: "off",
		effects: "off",
		aa: "off",
		vsync: "on"
	};
	if (level === "medium") return {
		graphics: "medium",
		resolutionScale: "native",
		shadows: "low",
		effects: "low",
		aa: "fxaa",
		vsync: "on"
	};
	if (level === "high") return {
		graphics: "high",
		resolutionScale: "native",
		shadows: "medium",
		effects: "medium",
		aa: "fxaa",
		vsync: "on"
	};
	return {
		graphics: "ultra",
		resolutionScale: "native",
		shadows: "high",
		effects: "high",
		aa: "taa",
		vsync: "on"
	};
}
function guidanceFor(game) {
	const lines = [
		`In the game, set the frame limit to ${game.fpsTarget} only if that option exists. The number in FrameForge is a target, not a cap this app can enforce.`,
		`Resolution scale to use in the game: ${scaleLabel(game.resolutionScale)}. Shadows: ${detailLabel(game.shadows)}. Effects: ${detailLabel(game.effects)}. Anti-aliasing: ${aaLabel(game.aa)}.`,
		game.vsync === "on" ? "Leave VSync on inside the game unless you specifically want lower latency and can accept tearing." : "VSync off can reduce latency and can also tear. If the image tears, turn VSync back on in the game."
	];
	if (game.fpsTarget >= 90) lines.push("90, 120, and 140 are targets only. This app cannot unlock them. The game and the phone both have to offer that rate.");
	if (/where winds meet/i.test(game.name)) lines.push("Where Winds Meet on a mid-range phone such as a Galaxy A55: start at the 60 target with low shadows. If the phone warms up, drop effects and pause. Saving this profile does not change the game.");
	return lines;
}
function safeLaunchUrl(raw) {
	const value = raw.trim();
	if (!value || value.length > 500) return null;
	let url;
	try {
		url = new URL(value);
	} catch {
		return null;
	}
	const protocol = url.protocol.toLowerCase();
	if (protocol === "javascript:" || protocol === "data:" || protocol === "file:" || protocol === "blob:") return null;
	if (protocol === "http:" || protocol === "https:") return url.toString();
	if (!/^[a-z][a-z0-9+.-]*:$/.test(protocol)) return null;
	return value;
}
function uid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function formatDuration(ms) {
	const total = Math.max(0, Math.floor(ms / 1e3));
	return [
		Math.floor(total / 3600),
		Math.floor(total % 3600 / 60),
		total % 60
	].map((n) => String(n).padStart(2, "0")).join(":");
}
function formatWhen(at) {
	return new Intl.DateTimeFormat(void 0, {
		month: "short",
		day: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	}).format(at);
}
function formatBytes(n) {
	if (n < 1024) return `${Math.round(n)} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(1)} MB`;
}
function sessionElapsed(session, now) {
	if (!session.running || session.startedAt == null || now == null) return session.accumulatedMs;
	return session.accumulatedMs + Math.max(0, now - session.startedAt);
}
function defaultClicker() {
	return {
		intervalMs: 500,
		repeat: 10,
		durationSec: 0,
		mode: "single",
		points: [{
			id: "pt-default",
			label: "Point 1",
			x: 50,
			y: 48,
			delayMs: 500
		}]
	};
}
function seedGames() {
	return [{
		id: "where-winds-meet",
		name: "Where Winds Meet",
		launchUrl: "",
		notes: "Mid-range starting point: 60 FPS target, low shadows, low effects. Drop effects first if the phone gets warm. This profile only stores your preferences.",
		image: null,
		preset: "balanced",
		graphics: "medium",
		fpsTarget: 60,
		resolutionScale: "native",
		shadows: "low",
		effects: "low",
		aa: "fxaa",
		vsync: "on"
	}, {
		id: "template-arena",
		name: "Arena template",
		launchUrl: "",
		notes: "Rename this for a competitive game, paste your own launch link, and pick a target the game actually offers. Nothing here is applied automatically.",
		image: null,
		preset: "performance",
		graphics: "medium",
		fpsTarget: 60,
		resolutionScale: "native",
		shadows: "low",
		effects: "medium",
		aa: "fxaa",
		vsync: "off"
	}];
}
function freshState() {
	return {
		theme: "dark",
		accent: "crimson",
		background: "graphite",
		density: "comfortable",
		motion: "subtle",
		cardStyle: "poster",
		keepAwake: false,
		widgets: WIDGETS.map((widget) => ({
			id: widget.id,
			visible: true
		})),
		selectedGameId: "where-winds-meet",
		games: seedGames(),
		session: {
			running: false,
			startedAt: null,
			accumulatedMs: 0
		},
		fpsLogs: [],
		compares: [],
		notes: [],
		clicker: defaultClicker(),
		clickPresets: [{
			id: "preset-two-point",
			name: "Two-point demo",
			intervalMs: 400,
			repeat: 4,
			durationSec: 0,
			mode: "sequence",
			points: [{
				id: "pt-left",
				label: "Left",
				x: 32,
				y: 58,
				delayMs: 400
			}, {
				id: "pt-right",
				label: "Right",
				x: 68,
				y: 58,
				delayMs: 400
			}]
		}],
		refreshSample: null,
		thermal: {},
		tutorialsSeen: {}
	};
}
function makeGame(name) {
	return {
		id: uid(),
		name: name.trim().slice(0, 60) || "New game",
		launchUrl: "",
		notes: "",
		image: null,
		preset: "balanced",
		...visualsForPreset("balanced", 60)
	};
}
var useRuntime = create((set) => ({
	storageMode: "unknown",
	wake: "off",
	setStorageMode: (storageMode) => set({ storageMode }),
	setWake: (wake) => set({ wake })
}));
var memory = /* @__PURE__ */ new Map();
var storageProblem = null;
var safeStorage = {
	getItem: (name) => {
		if (typeof window === "undefined") return null;
		try {
			return localStorage.getItem(name);
		} catch {
			storageProblem = "memory";
			return memory.get(name) ?? null;
		}
	},
	setItem: (name, value) => {
		if (typeof window === "undefined") return;
		try {
			localStorage.setItem(name, value);
			storageProblem = null;
			if (useRuntime.getState().storageMode === "memory") useRuntime.getState().setStorageMode("local");
		} catch {
			storageProblem = "memory";
			memory.set(name, value);
			useRuntime.getState().setStorageMode("memory");
		}
	},
	removeItem: (name) => {
		if (typeof window === "undefined") return;
		try {
			localStorage.removeItem(name);
		} catch {
			memory.delete(name);
		}
	}
};
function clampInt(value, min, max) {
	if (!Number.isFinite(value)) return min;
	return Math.min(max, Math.max(min, Math.round(value)));
}
var useAppStore = create()(persist((set, get) => ({
	...freshState(),
	setTheme: (theme) => set({ theme }),
	setAccent: (accent) => set({ accent }),
	setBackground: (background) => set({ background }),
	setDensity: (density) => set({ density }),
	setMotion: (motion) => set({ motion }),
	setCardStyle: (cardStyle) => set({ cardStyle }),
	setKeepAwake: (keepAwake) => set({ keepAwake }),
	setWidgetVisible: (id, visible) => set({ widgets: get().widgets.map((widget) => widget.id === id ? {
		...widget,
		visible
	} : widget) }),
	moveWidget: (id, direction) => {
		const widgets = [...get().widgets];
		const index = widgets.findIndex((widget) => widget.id === id);
		const next = index + direction;
		if (index < 0 || next < 0 || next >= widgets.length) return;
		const [item] = widgets.splice(index, 1);
		widgets.splice(next, 0, item);
		set({ widgets });
	},
	selectGame: (id) => set({ selectedGameId: id }),
	addGame: (name) => {
		const game = makeGame(name ?? "New game");
		set({
			games: [game, ...get().games],
			selectedGameId: game.id
		});
		return game.id;
	},
	updateGame: (id, patch) => set({ games: get().games.map((game) => game.id === id ? {
		...game,
		...patch,
		id: game.id
	} : game) }),
	removeGame: (id) => {
		const games = get().games.filter((game) => game.id !== id);
		set({
			games,
			selectedGameId: get().selectedGameId === id ? games[0]?.id ?? null : get().selectedGameId,
			notes: get().notes.map((note) => note.gameId === id ? {
				...note,
				gameId: null
			} : note)
		});
	},
	startSession: () => {
		const session = get().session;
		if (session.running) return;
		set({ session: {
			...session,
			running: true,
			startedAt: Date.now()
		} });
	},
	pauseSession: () => {
		const session = get().session;
		if (!session.running || session.startedAt == null) return;
		set({ session: {
			running: false,
			startedAt: null,
			accumulatedMs: session.accumulatedMs + Math.max(0, Date.now() - session.startedAt)
		} });
	},
	resetSession: () => set({ session: {
		running: false,
		startedAt: null,
		accumulatedMs: 0
	} }),
	addFpsLog: (input) => {
		const measuredFps = Math.round(input.measuredFps);
		if (!Number.isFinite(measuredFps) || measuredFps < 1 || measuredFps > 1e3) return false;
		set({ fpsLogs: [{
			...input,
			measuredFps,
			note: input.note.slice(0, 200),
			id: uid(),
			at: Date.now()
		}, ...get().fpsLogs].slice(0, 200) });
		return true;
	},
	removeFpsLog: (id) => set({ fpsLogs: get().fpsLogs.filter((entry) => entry.id !== id) }),
	addCompare: (input) => {
		const measuredFps = Math.round(input.measuredFps);
		if (!Number.isFinite(measuredFps) || measuredFps < 1 || measuredFps > 1e3) return false;
		set({ compares: [{
			...input,
			measuredFps,
			label: input.label.trim().slice(0, 60) || "Untitled run",
			note: input.note.slice(0, 200),
			id: uid(),
			at: Date.now()
		}, ...get().compares].slice(0, 100) });
		return true;
	},
	removeCompare: (id) => set({ compares: get().compares.filter((entry) => entry.id !== id) }),
	addNote: (input) => {
		const title = input.title.trim().slice(0, 80);
		if (!title) return;
		set({ notes: [{
			id: uid(),
			title,
			body: input.body.slice(0, 2e3),
			gameId: input.gameId,
			at: Date.now()
		}, ...get().notes].slice(0, 100) });
	},
	updateNote: (id, patch) => set({ notes: get().notes.map((note) => note.id === id ? {
		...note,
		...patch,
		title: (patch.title ?? note.title).trim().slice(0, 80) || note.title,
		body: (patch.body ?? note.body).slice(0, 2e3)
	} : note) }),
	removeNote: (id) => set({ notes: get().notes.filter((note) => note.id !== id) }),
	setClicker: (patch) => {
		const current = get().clicker;
		set({ clicker: {
			...current,
			...patch,
			intervalMs: patch.intervalMs == null ? current.intervalMs : clampInt(patch.intervalMs, 50, 6e4),
			repeat: patch.repeat == null ? current.repeat : clampInt(patch.repeat, 0, 9999),
			durationSec: patch.durationSec == null ? current.durationSec : clampInt(patch.durationSec, 0, 86400)
		} });
	},
	setClickerPoints: (points) => set({ clicker: {
		...get().clicker,
		points: points.slice(0, 12)
	} }),
	saveClickPreset: (name) => {
		const trimmed = name.trim().slice(0, 40);
		if (!trimmed) return null;
		const preset = {
			id: uid(),
			name: trimmed,
			...get().clicker,
			points: get().clicker.points.map((p) => ({ ...p }))
		};
		set({ clickPresets: [preset, ...get().clickPresets].slice(0, 30) });
		return preset.id;
	},
	removeClickPreset: (id) => set({ clickPresets: get().clickPresets.filter((preset) => preset.id !== id) }),
	setRefresh: (refreshSample) => set({ refreshSample }),
	toggleThermal: (id) => set({ thermal: {
		...get().thermal,
		[id]: !get().thermal[id]
	} }),
	markTutorial: (id, seen) => set({ tutorialsSeen: {
		...get().tutorialsSeen,
		[id]: seen
	} }),
	replaceState: (data) => set({ ...data }),
	restoreDefaults: () => {
		const base = freshState();
		set({
			theme: base.theme,
			accent: base.accent,
			background: base.background,
			density: base.density,
			motion: base.motion,
			cardStyle: base.cardStyle,
			keepAwake: base.keepAwake,
			widgets: base.widgets,
			clicker: base.clicker
		});
	},
	resetAll: () => set({ ...freshState() })
}), {
	name: "frameforge-booyah",
	version: 1,
	skipHydration: true,
	storage: createJSONStorage(() => safeStorage),
	partialize: (state) => ({
		theme: state.theme,
		accent: state.accent,
		background: state.background,
		density: state.density,
		motion: state.motion,
		cardStyle: state.cardStyle,
		keepAwake: state.keepAwake,
		widgets: state.widgets,
		selectedGameId: state.selectedGameId,
		games: state.games,
		session: state.session,
		fpsLogs: state.fpsLogs,
		compares: state.compares,
		notes: state.notes,
		clicker: state.clicker,
		clickPresets: state.clickPresets,
		refreshSample: state.refreshSample,
		thermal: state.thermal,
		tutorialsSeen: state.tutorialsSeen
	}),
	onRehydrateStorage: () => (_state, error) => {
		if (error) useRuntime.getState().setStorageMode("unreadable");
		else if (storageProblem === "memory") useRuntime.getState().setStorageMode("memory");
		else useRuntime.getState().setStorageMode("local");
	}
}));
function useSelectedGame() {
	return useAppStore((state) => state.games.find((game) => game.id === state.selectedGameId) ?? null);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var VARIANTS = {
	primary: "bg-primary text-primary-fg",
	quiet: "bg-surface-2 text-fg",
	ghost: "bg-transparent text-fg",
	ok: "bg-ok text-ok-fg"
};
function buttonClass(variant = "primary", className) {
	return cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-4 text-center text-sm font-semibold transition-colors", VARIANTS[variant], "disabled:opacity-50", className);
}
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: buttonClass(variant, className),
		...props
	});
}
function PageHeader({ kicker, title, subtitle, id }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		id,
		children: [
			kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-primary uppercase",
				children: kicker
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: title
			}),
			subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-prose text-muted",
				children: subtitle
			}) : null
		]
	});
}
function Panel({ title, action, children, id, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id,
		className: cn("panel", className),
		children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-3 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-semibold",
				children: title
			}), action]
		}) : null, children]
	});
}
function Field({ label, hint, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1 block text-sm font-semibold",
				children: label
			}),
			children,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				role: "alert",
				className: "mt-1 block text-sm text-primary",
				children: error
			}) : hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-sm text-faint",
				children: hint
			}) : null
		]
	});
}
function MetricRow({ label, value, source, unavailable = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-line py-3 last:border-b-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-sm text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: "max-w-[60%] text-right text-sm font-semibold text-pretty tabular-nums",
				children: unavailable ? "Not available in this version." : value
			})]
		}), source ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-faint",
			children: source
		}) : null]
	});
}
function Notice({ tone = "neutral", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: tone === "warn" ? "alert" : "status",
		className: cn("text-sm", tone === "ok" ? "text-ok" : tone === "warn" ? "text-primary" : "text-muted"),
		children
	});
}
//#endregion
export { formatDuration as A, uid as B, WIDGETS as C, cn as D, buttonClass as E, isFpsTarget as F, visualsForPreset as G, useRuntime as H, presetLabel as I, safeLaunchUrl as L, freshState as M, graphicsLabel as N, detailLabel as O, guidanceFor as P, scaleLabel as R, THERMAL_TIPS as S, aaLabel as T, useSelectedGame as U, useAppStore as V, visualsForGraphics as W, PageHeader as _, Button as a, THEMES as b, DETAIL as c, GRAPHICS as d, MOTIONS as f, PRESETS as g, Notice as h, BACKGROUND_TIPS as i, formatWhen as j, formatBytes as k, FPS_TARGETS as l, NEEDS_NATIVE as m, ACCENTS as n, CARD_STYLES as o, MetricRow as p, BACKGROUNDS as r, DENSITIES as s, AA as t, Field as u, Panel as v, WORKS_NOW as w, THERMAL_CHECKS as x, SCALE as y, sessionElapsed as z };
