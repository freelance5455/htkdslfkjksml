import { t as createServerFn } from "./ssr.mjs";
import { a as GoogleDriveTools, i as GoogleCalendarTools, r as ConnectorType } from "./types-D3FEuKtl.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { n as classifyCallToolError, s as toLibraryItem, t as asRecordArray } from "./normalize-6SyGCqa5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/briefing-MqPeG4Kk.js
function pack(result) {
	const error = classifyCallToolError(result);
	return {
		ok: result.ok,
		pending: result.pending === true,
		loginRequired: result.loginRequired === true,
		loginUrl: result.loginUrl,
		error,
		items: result.ok ? asRecordArray(result.data).slice(0, 12).map(toLibraryItem) : []
	};
}
function startOfLocalDay(now) {
	const d = new Date(now);
	d.setHours(0, 0, 0, 0);
	return d;
}
function addDays(now, days) {
	const d = new Date(now);
	d.setDate(d.getDate() + days);
	return d;
}
var getBriefing_createServerFn_handler = createServerRpc({
	id: "16a5e8b6887b4e937f4d464f4d1d31bab72680bba822362be6c8750d53762ea9",
	name: "getBriefing",
	filename: "src/lib/assistant/briefing.ts"
}, (opts) => getBriefing.__executeServer(opts));
var getBriefing = createServerFn({ method: "POST" }).validator((input) => input ?? {}).handler(getBriefing_createServerFn_handler, async ({ data }) => {
	const { callTool } = await import("./client.server-CA4VLIeU.mjs");
	const now = data.nowISO ? new Date(data.nowISO) : /* @__PURE__ */ new Date();
	const dayStart = startOfLocalDay(now).toISOString();
	const weekEnd = addDays(now, 7).toISOString();
	const yesterday = addDays(now, -2).toISOString();
	const [calendar, drive, mail] = await Promise.all([
		callTool(GoogleCalendarTools.search, {
			time_min: dayStart,
			time_max: weekEnd,
			query: ""
		}, { connectorType: ConnectorType.GoogleCalendar }),
		callTool(GoogleDriveTools.search, { q: `modifiedTime > '${yesterday}' and trashed = false` }, { connectorType: ConnectorType.GoogleDrive }),
		callTool("gmail_search", { query: "newer_than:3d" }, { connectorType: ConnectorType.Gmail })
	]);
	return {
		generatedAt: now.toISOString(),
		calendar: pack(calendar),
		drive: pack(drive),
		mail: pack(mail)
	};
});
var searchDrive_createServerFn_handler = createServerRpc({
	id: "27ee31456390aef78aa73bd415071afea4376c89006407e34289e17cb04a8c96",
	name: "searchDrive",
	filename: "src/lib/assistant/briefing.ts"
}, (opts) => searchDrive.__executeServer(opts));
var searchDrive = createServerFn({ method: "POST" }).validator((input) => input).handler(searchDrive_createServerFn_handler, async ({ data }) => {
	const { callTool } = await import("./client.server-CA4VLIeU.mjs");
	return pack(await callTool(GoogleDriveTools.search, { q: data.query || "trashed = false" }, { connectorType: ConnectorType.GoogleDrive }));
});
var listDriveFolder_createServerFn_handler = createServerRpc({
	id: "ed18be3040306256ea0d137744126fa190e9574d1b90e77b372dc0063c2f0ba9",
	name: "listDriveFolder",
	filename: "src/lib/assistant/briefing.ts"
}, (opts) => listDriveFolder.__executeServer(opts));
var listDriveFolder = createServerFn({ method: "POST" }).validator((input) => input ?? {}).handler(listDriveFolder_createServerFn_handler, async ({ data }) => {
	const { callTool } = await import("./client.server-CA4VLIeU.mjs");
	const args = {};
	if (data.folderId) args.folder_id = data.folderId;
	return pack(await callTool(GoogleDriveTools.listFolder, args, { connectorType: ConnectorType.GoogleDrive }));
});
//#endregion
export { getBriefing_createServerFn_handler, listDriveFolder_createServerFn_handler, searchDrive_createServerFn_handler };
