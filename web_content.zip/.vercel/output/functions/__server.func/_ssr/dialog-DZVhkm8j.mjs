import "../_runtime.mjs";
import { T as require_react, d as DialogClose, f as DialogContent$1, g as DialogTitle$1, h as DialogPortal$1, m as DialogOverlay$1, p as DialogDescription$1, u as Dialog$1, w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { f as cn, i as REST_PRESETS } from "./store-CuJQmbYj.mjs";
import { t as Card } from "./card-ML3_y2lP.mjs";
import { E as ArrowDown, c as Plus, i as Trash2, n as Undo2, s as RotateCcw, t as X, v as Copy, w as ArrowUp, x as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as Button } from "./router-0AvkMag6.mjs";
import { t as Input } from "./input-Y7CKgdfM.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function LiveExerciseCard({ exercise, onCompleteSet, onUndoSet, onPatch }) {
	const done = exercise.completedSets >= exercise.sets;
	const pct = exercise.sets > 0 ? exercise.completedSets / exercise.sets : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: cn("p-4 transition-colors", done && "border-success/40 bg-success/5"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-base font-semibold leading-snug",
						children: exercise.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-sm text-muted-foreground",
						children: [
							exercise.sets,
							" × ",
							exercise.reps,
							exercise.load ? ` · ${exercise.load}` : ""
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: cn("shrink-0 rounded-full px-2.5 py-1 text-xs font-medium tabular-nums", done ? "bg-success/15 text-success" : "bg-primary/15 text-primary"),
					children: [
						exercise.completedSets,
						"/",
						exercise.sets,
						" séries"
					]
				})]
			}),
			exercise.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs leading-relaxed text-muted-foreground",
				children: exercise.notes
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1",
				children: Array.from({ length: exercise.sets }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("h-1.5 flex-1 rounded-full", i < exercise.completedSets ? "bg-primary" : "bg-muted"),
					style: { opacity: i < exercise.completedSets ? .4 + pct * .6 : 1 }
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted-foreground",
						children: "Carga"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: exercise.load,
						onChange: (e) => onPatch({ load: e.target.value }),
						placeholder: "kg / mochila"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted-foreground",
						children: "Descanso (s)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 0,
						step: 5,
						value: exercise.restSec,
						onChange: (e) => onPatch({ restSec: Math.max(0, Number(e.target.value) || 0) })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-1.5",
				children: REST_PRESETS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPatch({ restSec: s }),
					className: cn("h-8 rounded-full px-2.5 text-[11px] font-medium", exercise.restSec === s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"),
					children: [s, "s"]
				}, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "flex-1",
					disabled: done,
					onClick: () => {
						onCompleteSet();
						toast.success("Série concluída");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}),
						" ",
						done ? "Exercício concluído" : "Concluir série"
					]
				}), exercise.completedSets > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					size: "icon",
					onClick: onUndoSet,
					"aria-label": "Desfazer série",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {})
				}) : null]
			})
		]
	});
}
function WorkoutEditor({ exercises, handlers }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: handlers.onAdd,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Adicionar exercício"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => {
						handlers.onRestore();
						toast.success("Treino original restaurado");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), " Restaurar original"]
				})]
			}),
			exercises.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-6 text-sm text-muted-foreground",
				children: "Nenhum exercício. Adicione o primeiro."
			}) : null,
			exercises.map((ex, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: ex.name,
								onChange: (e) => handlers.onUpdate(ex.id, { name: e.target.value }),
								className: "font-medium"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								disabled: i === 0,
								onClick: () => handlers.onMove(ex.id, -1),
								"aria-label": "Subir",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								disabled: i === exercises.length - 1,
								onClick: () => handlers.onMove(ex.id, 1),
								"aria-label": "Descer",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground",
									children: "Séries"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 1,
									value: ex.sets,
									onChange: (e) => handlers.onUpdate(ex.id, { sets: Math.max(1, Number(e.target.value) || 1) })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground",
									children: "Reps / tempo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: ex.reps,
									onChange: (e) => handlers.onUpdate(ex.id, { reps: e.target.value })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground",
									children: "Carga"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: ex.load,
									onChange: (e) => handlers.onUpdate(ex.id, { load: e.target.value })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground",
									children: "Descanso (s)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									step: 5,
									value: ex.restSec,
									onChange: (e) => handlers.onUpdate(ex.id, { restSec: Math.max(0, Number(e.target.value) || 0) })
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: REST_PRESETS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => handlers.onUpdate(ex.id, { restSec: s }),
							className: `h-8 rounded-full px-2.5 text-[11px] font-medium ${ex.restSec === s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`,
							children: [s, "s"]
						}, s))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] text-muted-foreground",
							children: "Instrução"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: ex.notes,
							onChange: (e) => handlers.onUpdate(ex.id, { notes: e.target.value }),
							placeholder: "Opcional"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => {
								handlers.onDuplicate(ex.id);
								toast.success("Exercício duplicado");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Duplicar"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => handlers.onRemove(ex.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Remover"]
						})]
					})
				]
			}, ex.id))
		]
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-black/70 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-border bg-popover p-5 text-popover-foreground shadow-xl data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-3 right-3 rounded-md p-1 text-muted-foreground hover:bg-accent hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Fechar"
			})]
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 space-y-1 pr-6", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-lg font-semibold tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
//#endregion
export { DialogHeader as a, WorkoutEditor as c, DialogFooter as i, DialogContent as n, DialogTitle as o, DialogDescription as r, LiveExerciseCard as s, Dialog as t };
