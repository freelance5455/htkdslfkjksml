import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as WifiOff, t as Wifi } from "../_libs/lucide-react.mjs";
import { n as ScreenBody, t as AppShell } from "./app-shell-BNnfZJ-W.mjs";
import { i as ScreenHeader, n as InfoRow, r as Panel, t as IconBadge } from "./screen-header-3v0iR4cd.mjs";
import { a as subscribeNetwork } from "./web-device-D_Jv2ve6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/network-Xtff0p3R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NetworkPage() {
	const [network, setNetwork] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => subscribeNetwork(setNetwork), []);
	const online = network?.online ?? false;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Network Info",
			subtitle: "Connection type only. No personal data is collected."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBadge, {
				className: online ? "bg-primary/15 text-primary" : "bg-danger/15 text-danger",
				children: online ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-4xl font-bold tracking-tight text-fg",
				children: network ? online ? "Connected" : "Offline" : "…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-sm ${online ? "text-primary" : "text-muted"}`,
				children: network?.typeLabel ?? "Reading…"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3.5 flex flex-col gap-2.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Status",
					value: network ? online ? "Online" : "Offline" : "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Connection type",
					value: network?.typeLabel ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Details",
					value: network?.detail ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Downlink",
					value: network?.downlink ?? "..."
				})
			]
		})
	] }) });
}
//#endregion
export { NetworkPage as component };
