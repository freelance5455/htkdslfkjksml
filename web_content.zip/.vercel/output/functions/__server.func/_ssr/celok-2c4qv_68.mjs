import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as viewsOf, b as inflationLossPct, c as goalCurrentHuf, h as toHuf, l as goalTargetHuf, m as sumViews, n as usePortfolio, p as subscriptionTotals, r as addMonthsIso, v as yearsToTarget, y as inflationFactor } from "./router-Ddmv2GI8.mjs";
import { t as Shell } from "./shell-wztA7KjE.mjs";
import { c as formatDay, g as uid, h as todayIso, i as Modal, l as formatMoney, n as Field, u as formatNumber } from "./format-Bbm5TEoT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/celok-2c4qv_68.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Goals, {}) });
}
function Goals() {
	const { state, saveGoal, deleteGoal, setPlan, setFire, setInflationBase } = usePortfolio();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const today = todayIso();
	const totals = sumViews(viewsOf(state));
	const subs = subscriptionTotals(state.subscriptions, state.market.fx);
	const annualSpend = subs.annual + state.fire.extraAnnualHuf;
	const fiHuf = state.fire.swrPct > 0 ? annualSpend / (state.fire.swrPct / 100) : 0;
	const fiUsd = state.market.fx.usdHuf ? fiHuf / state.market.fx.usdHuf : 0;
	const years = yearsToTarget(totals.huf, state.capitalPlan.monthlyHuf, fiHuf, state.fire.realReturnPct);
	const progress = fiHuf > 0 ? Math.min(100, totals.huf / fiHuf * 100) : 0;
	const base = state.inflationBase || state.capitalPlan.startDate;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl",
				children: "Célok és FIRE"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-xl text-sm text-muted",
				children: "A cél a választott csoportok mai forintértékéhez méri magát. A reálcél az inflációval együtt nő."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => setEditing({
					id: uid(),
					name: "",
					target: 1e6,
					currency: "HUF",
					deadline: "",
					groupIds: [],
					real: false,
					note: ""
				}),
				children: "Új cél"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-8 divide-y divide-line border-t border-line",
			children: [state.goals.map((goal) => {
				const current = goalCurrentHuf(goal, state);
				const target = goalTargetHuf(goal, state, today);
				const pct = target > 0 ? current / target * 100 : 0;
				const usd = state.market.fx.usdHuf ? current / state.market.fx.usdHuf : 0;
				const targetUsd = state.market.fx.usdHuf ? target / state.market.fx.usdHuf : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "py-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: goal.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted tabular-nums",
								children: [formatNumber(Math.min(999, pct), 0), "%"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								goal.groupIds.length ? state.groups.filter((group) => goal.groupIds.includes(group.id)).map((group) => group.name).join(", ") : "Teljes vagyon",
								goal.deadline ? ` · határidő ${formatDay(goal.deadline)}` : "",
								goal.real ? " · reálcél" : " · nominális cél"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-2 rounded-full bg-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 rounded-full bg-pine",
								style: { width: `${Math.min(100, Math.max(0, pct))}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-2 text-sm tabular-nums sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								"Most ",
								formatMoney(current, "HUF"),
								" · ",
								formatMoney(usd, "USD")
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "sm:text-right",
								children: [
									"Cél ",
									formatMoney(target, "HUF"),
									" · ",
									formatMoney(targetUsd, "USD")
								]
							})]
						}),
						goal.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: goal.note
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-quiet",
								onClick: () => setEditing(goal),
								children: "Módosít"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-quiet text-clay",
								onClick: () => deleteGoal(goal.id),
								children: "Töröl"
							})]
						})
					]
				}, goal.id);
			}), state.goals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "py-8 text-sm text-muted",
				children: "Még nincs cél."
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-12 grid gap-10 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "FIRE"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Éves költés = előfizetések (",
						formatMoney(subs.annual, "HUF"),
						") + a lent megadott egyéb. A szám ",
						state.fire.swrPct,
						"% -os kivétből indul."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-serif text-4xl tabular-nums leading-tight",
					children: formatMoney(fiHuf, "HUF")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted tabular-nums",
					children: [formatMoney(fiUsd, "USD"), " a függetlenséghez"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-2 rounded-full bg-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 rounded-full bg-pine",
						style: { width: `${progress}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm",
					children: years == null ? "Ezzel a befizetéssel és hozammal a cél nem jön ki." : years === 0 ? "A mai vagyon már eléri a számot." : `Kb. ${formatNumber(years, 1)} év, ${formatDay(addMonthsIso(today, years * 12))} körül, ha a havi befizetés és a reálhozam tartja magát.`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `Egyéb éves költés, előfizetésen felül (${formatMoney(state.fire.extraAnnualHuf, "HUF")})`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field tabular-nums",
								inputMode: "numeric",
								value: state.fire.extraAnnualHuf,
								onChange: (event) => setFire({
									...state.fire,
									extraAnnualHuf: Number(event.target.value) || 0
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `Kivét, százalék (${state.fire.swrPct})`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 2.5,
								max: 5,
								step: .1,
								value: state.fire.swrPct,
								className: "w-full accent-pine",
								onChange: (event) => setFire({
									...state.fire,
									swrPct: Number(event.target.value)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `Várt reálhozam, százalék (${state.fire.realReturnPct})`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 10,
								step: .5,
								value: state.fire.realReturnPct,
								className: "w-full accent-pine",
								onChange: (event) => setFire({
									...state.fire,
									realReturnPct: Number(event.target.value)
								})
							})
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Befizetési ütem"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Ebből rajzolódik a kezdőlap tőkevonalja, és ezt használja a FIRE-év is."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Kezdőnap",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								type: "date",
								value: state.capitalPlan.startDate,
								onChange: (event) => setPlan({
									...state.capitalPlan,
									startDate: event.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Induló összeg, Ft",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field tabular-nums",
								inputMode: "numeric",
								value: state.capitalPlan.initialHuf,
								onChange: (event) => setPlan({
									...state.capitalPlan,
									initialHuf: Number(event.target.value) || 0
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Havi befizetés, Ft",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field tabular-nums",
								inputMode: "numeric",
								value: state.capitalPlan.monthlyHuf,
								onChange: (event) => setPlan({
									...state.capitalPlan,
									monthlyHuf: Number(event.target.value) || 0
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Inflációs bázis",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								type: "date",
								value: base,
								onChange: (event) => setInflationBase(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								base,
								" óta a fogyasztói árak ",
								formatNumber(inflationLossPct(base, today), 1),
								"%-kal magasabbak (szorzó ",
								formatNumber(inflationFactor(base, today), 2),
								"). A 2026-os év előzetes."
							]
						})
					]
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalDialog, {
			goal: editing,
			onClose: () => setEditing(null),
			onSave: (goal) => {
				saveGoal(goal);
				setEditing(null);
			}
		})
	] });
}
function GoalDialog({ goal, onClose, onSave }) {
	const { state } = usePortfolio();
	const [draft, setDraft] = (0, import_react.useState)(goal);
	(0, import_react.useEffect)(() => setDraft(goal), [goal]);
	if (!draft) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open: false,
		title: "Cél",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {})
	});
	const toggle = (id) => {
		const has = draft.groupIds.includes(id);
		setDraft({
			...draft,
			groupIds: has ? draft.groupIds.filter((item) => item !== id) : [...draft.groupIds, id]
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open: Boolean(goal),
		title: "Megtakarítási cél",
		onClose,
		description: "Üres csoportlista az egész vagyont méri.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Név",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: draft.name,
						onChange: (event) => setDraft({
							...draft,
							name: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Összeg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "decimal",
							value: draft.target,
							onChange: (event) => setDraft({
								...draft,
								target: Number(event.target.value.replace(",", ".")) || 0
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Deviza",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: draft.currency,
							onChange: (event) => setDraft({
								...draft,
								currency: event.target.value
							}),
							children: [
								"HUF",
								"USD",
								"EUR",
								"GBP"
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Határidő, üresen hagyható",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "date",
						value: draft.deadline,
						onChange: (event) => setDraft({
							...draft,
							deadline: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "mb-1 text-sm text-muted",
					children: "Melyik csoport számít bele"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-1",
					children: state.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "size-5 accent-pine",
							checked: draft.groupIds.includes(group.id),
							onChange: () => toggle(group.id)
						}), group.name]
					}, group.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "size-5 accent-pine",
						checked: draft.real,
						onChange: (event) => setDraft({
							...draft,
							real: event.target.checked
						})
					}), "A cél inflációval korrigálva nőjön"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Megjegyzés",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: draft.note,
						onChange: (event) => setDraft({
							...draft,
							note: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						"Mai forintban a nominális cél ",
						formatMoney(toHuf(draft.target, draft.currency, state.market.fx), "HUF"),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: onClose,
						children: "Mégse"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						disabled: !draft.name.trim(),
						onClick: () => onSave({
							...draft,
							name: draft.name.trim()
						}),
						children: "Mentés"
					})]
				})
			]
		})
	});
}
//#endregion
export { Page as component };
