import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as HardDrive, d as Calculator, f as BatteryCharging, i as Smartphone, l as Download, s as Flashlight, t as Wifi } from "../_libs/lucide-react.mjs";
import { n as ScreenBody, t as AppShell } from "./app-shell-BNnfZJ-W.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DhSaxkeC.js
var import_jsx_runtime = require_jsx_runtime();
var tools = [
	{
		to: "/battery",
		title: "Battery Info",
		subtitle: "Level, charging, health",
		icon: BatteryCharging,
		tint: "text-primary bg-primary/15"
	},
	{
		to: "/storage",
		title: "Storage Info",
		subtitle: "Used, free, and total",
		icon: HardDrive,
		tint: "text-sky bg-sky/15"
	},
	{
		to: "/device",
		title: "Device Info",
		subtitle: "Model, Android, SDK",
		icon: Smartphone,
		tint: "text-primary bg-primary/15"
	},
	{
		to: "/calculator",
		title: "Calculator",
		subtitle: "Add, subtract, multiply, divide",
		icon: Calculator,
		tint: "text-warning bg-warning/15"
	},
	{
		to: "/flashlight",
		title: "Flashlight",
		subtitle: "Turn the torch on or off",
		icon: Flashlight,
		tint: "text-warning bg-warning/15"
	},
	{
		to: "/network",
		title: "Network Info",
		subtitle: "Wi-Fi or mobile status",
		icon: Wifi,
		tint: "text-primary bg-primary/15"
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		peek: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-in",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium uppercase tracking-widest text-primary",
						children: "Offline utilities"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-4xl font-bold leading-tight tracking-tight text-fg",
						children: "Vishal Tools"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: "Offline utilities for your phone. Nothing is uploaded."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid grid-cols-2 gap-3",
				children: tools.map((tool) => {
					const Icon = tool.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: tool.to,
						className: "stagger-in flex min-h-44 flex-col rounded-card bg-surface p-5 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `inline-flex w-fit rounded-2xl p-3 ${tool.tint}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-4 text-sm font-semibold text-fg",
								children: tool.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 text-xs leading-snug text-muted",
								children: tool.subtitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-auto pt-3 text-sm font-semibold text-primary",
								children: "Open"
							})
						]
					}, tool.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/studio",
				className: "stagger-in mt-4 flex min-h-14 items-center justify-between gap-3 rounded-card bg-elevated px-4 py-3 shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.96] lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-semibold text-fg",
					children: "Android Studio project"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: "Download Kotlin source and build an APK"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-5 text-primary" })]
			})
		] })
	});
}
//#endregion
export { Home as component };
