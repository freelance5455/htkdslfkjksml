import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ShieldAlert, c as Laptop, i as ShieldCheck, l as FolderOpen, n as Tablet, o as RotateCcw, r as Smartphone, s as Lock, u as FileSearch } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CBHfeLyc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var EICAR_TEST = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*";
var FOLDER_ORDER = [
	"Camera",
	"Downloads",
	"Documents",
	"Messages",
	"Audio",
	"Recordings",
	"Chosen"
];
var HIGH = 7;
var MEDIUM = 4;
var LOW = 1;
function finding(severity, penalty, title, detail, signature) {
	return {
		severity,
		penalty,
		title,
		detail,
		signature
	};
}
function extension(name) {
	const base = name.split(/[/\\]/).pop() ?? name;
	const dot = base.lastIndexOf(".");
	if (dot <= 0) return "";
	return base.slice(dot + 1).toLowerCase();
}
function hasMz(bytes) {
	return !!bytes && bytes.length >= 2 && bytes[0] === 77 && bytes[1] === 90;
}
function hasElf(bytes) {
	return !!bytes && bytes.length >= 4 && bytes[0] === 127 && bytes[1] === 69 && bytes[2] === 76 && bytes[3] === 70;
}
function inspect(input, pack) {
	const name = input.name || "untitled";
	const text = input.text ?? "";
	const ext = extension(name);
	const lower = name.toLowerCase();
	if (text.includes("X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*") || lower.includes("eicar")) return finding("high", HIGH, "Test virus (EICAR)", "This is the standard test file scanners are built to catch. Treat it as a virus.", "EICAR");
	if (/(keygen|crack|trojan|password-stealer|malware)/i.test(name)) return finding("high", HIGH, "Risky filename", "The name matches an unwanted-tool pattern. It should not stay in your files.", "NAME");
	if (/\.(pdf|jpe?g|png|docx?|xlsx?|txt|mp4|heic)\.(exe|scr|com|bat|cmd|apk|js|vbs|jar|msi)$/i.test(name)) return finding("high", HIGH, "Disguised program", "It looks like an ordinary file, but the real ending is a program. That is a common virus trick.", "DOUBLE-EXT");
	if (hasMz(input.bytes) || hasElf(input.bytes)) return finding("high", HIGH, "Executable content", "The contents are a program, whatever the name says.", "EXEC-BYTES");
	if ([
		"exe",
		"scr",
		"com",
		"bat",
		"cmd",
		"vbs",
		"pif"
	].includes(ext)) return finding("high", HIGH, "Program file", "Program files do not belong in phone folders. They are often unwanted.", "PROGRAM");
	if (ext === "apk") return finding("medium", MEDIUM, "Unverified package", "An Android package is sitting in your files. Installed apps are not scanned — only this file.", "APK");
	if ([
		"msi",
		"jar",
		"dll"
	].includes(ext)) return finding("medium", MEDIUM, "Installer fragment", "This kind of file can install software. It should not be loose in phone folders.", "INSTALLER");
	if (/vbaProject\.bin|macroEnabled/i.test(text)) return finding("medium", MEDIUM, "Macro inside document", "This document contains a macro. Viruses use those to start themselves.", "MACRO");
	if (/html?|svg/.test(ext) && /<script/i.test(text) && /eval\s*\(|atob\s*\(/.test(text)) return finding("medium", MEDIUM, "Page with hidden script", "This page runs hidden code when it is opened.", "HTML-SCRIPT");
	if (ext === "js" || ext === "jse") {
		if (/eval\s*\(|atob\s*\(|Function\s*\(/.test(text)) return finding("medium", MEDIUM, "Script with hidden code", "This script hides what it runs. That is a virus habit.", "JS-HIDDEN");
		return finding("low", LOW, "Loose script", "A script is stored with your files. It is not a known virus, but it should not sit there.", "JS-LOOSE");
	}
	if (pack >= 2 && text.includes("HX-DROP-9")) return finding("medium", MEDIUM, "Known dropper fragment", "Signature pack 2 matches a fragment used to deliver viruses.", "HX-DROP-9");
	return null;
}
function scoreFrom(files, held) {
	let penalty = 0;
	for (const file of files) {
		if (!file.finding || held.has(file.id)) continue;
		penalty += file.finding.penalty;
	}
	const raw = 100 - penalty;
	return {
		secured: Math.max(55, Math.min(100, raw)),
		capped: raw < 55
	};
}
function folderStats(files, held) {
	const map = /* @__PURE__ */ new Map();
	for (const file of files) {
		const row = map.get(file.folder) ?? {
			name: file.folder,
			total: 0,
			issues: 0
		};
		row.total += 1;
		if (file.finding && !held.has(file.id)) row.issues += 1;
		map.set(file.folder, row);
	}
	return [...map.values()].sort((a, b) => {
		const ai = FOLDER_ORDER.indexOf(a.name);
		const bi = FOLDER_ORDER.indexOf(b.name);
		return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
	});
}
function hashString(value) {
	let hash = 2166136261;
	for (let i = 0; i < value.length; i += 1) {
		hash ^= value.charCodeAt(i);
		hash = Math.imul(hash, 16777619);
	}
	return hash >>> 0;
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function sized(rng, min, max) {
	return Math.round(min + (max - min) * rng());
}
var SCENARIOS = [
	"clean",
	"script",
	"apk",
	"invoice",
	"both"
];
function entry(folder, name, bytes, text = "") {
	return {
		id: `${folder}/${name}`,
		name,
		folder,
		bytes,
		text
	};
}
function scenarioFor(seed, mode) {
	if (mode === "sample") return "both";
	return SCENARIOS[hashString(seed || "daylight") % SCENARIOS.length] ?? "both";
}
function buildVault(seed, mode) {
	const rng = mulberry32(hashString(`${mode}:${seed || "daylight"}`));
	const files = [
		entry("Camera", "IMG_1844.heic", sized(rng, 18e5, 34e5)),
		entry("Camera", "IMG_1845.heic", sized(rng, 16e5, 32e5)),
		entry("Camera", "IMG_1902.jpg", sized(rng, 9e5, 24e5)),
		entry("Camera", "IMG_1910.jpg", sized(rng, 8e5, 22e5)),
		entry("Camera", "IMG_2033.jpg", sized(rng, 11e5, 28e5)),
		entry("Camera", "VID_2034.mp4", sized(rng, 18e6, 64e6)),
		entry("Camera", "VID_2101.mp4", sized(rng, 12e6, 48e6)),
		entry("Camera", "IMG_2218.heic", sized(rng, 14e5, 31e5)),
		entry("Camera", "IMG_2301.jpg", sized(rng, 7e5, 2e6)),
		entry("Camera", "IMG_2302.jpg", sized(rng, 7e5, 21e5)),
		entry("Camera", "IMG_2440.heic", sized(rng, 15e5, 33e5)),
		entry("Camera", "VID_2502.mp4", sized(rng, 8e6, 36e6)),
		entry("Downloads", "boarding-pass.pdf", sized(rng, 8e4, 24e4)),
		entry("Downloads", "museum-ticket.pdf", sized(rng, 6e4, 18e4)),
		entry("Downloads", "recipe-card.jpg", sized(rng, 4e5, 12e5)),
		entry("Downloads", "warranty.pdf", sized(rng, 9e4, 32e4)),
		entry("Downloads", "voice-memo-export.m4a", sized(rng, 6e5, 24e5)),
		entry("Downloads", "map-offline.pdf", sized(rng, 2e5, 9e5)),
		entry("Downloads", "statement.pdf", sized(rng, 12e4, 4e5)),
		entry("Downloads", "holiday.png", sized(rng, 5e5, 18e5)),
		entry("Downloads", "manual.pdf", sized(rng, 3e5, 14e5)),
		entry("Downloads", "coupon-helper.bin", 18432, "blob HX-DROP-9 padding"),
		entry("Documents", "lease-2024.pdf", sized(rng, 2e5, 8e5)),
		entry("Documents", "resume.docx", sized(rng, 4e4, 12e4)),
		entry("Documents", "budget-notes.txt", sized(rng, 2e3, 12e3), "rent, groceries, transit"),
		entry("Documents", "school-form.pdf", sized(rng, 8e4, 26e4)),
		entry("Documents", "travel-list.txt", sized(rng, 1e3, 6e3), "passport, charger, tickets"),
		entry("Documents", "insurance.pdf", sized(rng, 15e4, 6e5)),
		entry("Documents", "notes.txt", sized(rng, 800, 4e3), "call the clinic Thursday"),
		entry("Messages", "photo-from-mom.jpg", sized(rng, 7e5, 22e5)),
		entry("Messages", "photo-from-alex.jpg", sized(rng, 6e5, 2e6)),
		entry("Messages", "voice-03.m4a", sized(rng, 2e5, 9e5)),
		entry("Messages", "voice-04.m4a", sized(rng, 18e4, 8e5)),
		entry("Messages", "shared-dinner.jpg", sized(rng, 9e5, 26e5)),
		entry("Messages", "sticker.jpg", sized(rng, 4e4, 18e4)),
		entry("Audio", "morning-playlist.mp3", sized(rng, 3e6, 9e6)),
		entry("Audio", "podcast-14.m4a", sized(rng, 8e6, 24e6)),
		entry("Audio", "voice-note.m4a", sized(rng, 3e5, 12e5)),
		entry("Audio", "commute.mp3", sized(rng, 4e6, 11e6)),
		entry("Audio", "focus.mp3", sized(rng, 2e6, 7e6)),
		entry("Recordings", "screen-recording.mp4", sized(rng, 2e7, 8e7)),
		entry("Recordings", "screen-recording-2.mp4", sized(rng, 14e6, 6e7))
	];
	const scenario = scenarioFor(seed, mode);
	if (scenario === "script") files.push(entry("Documents", "meeting-notes.js", 820, "const agenda = 'q3';\n"));
	if (scenario === "apk" || scenario === "both") files.push(entry("Downloads", "player-update.apk", 44e5, ""));
	if (scenario === "invoice" || scenario === "both") files.push(entry("Downloads", "Invoice_4421.pdf.exe", 228e3, ""));
	const order = new Map(FOLDER_ORDER.map((folder, index) => [folder, index]));
	files.sort((a, b) => {
		const folder = (order.get(a.folder) ?? 99) - (order.get(b.folder) ?? 99);
		if (folder !== 0) return folder;
		return a.name.localeCompare(b.name);
	});
	return files;
}
function detectDevice() {
	const ua = navigator.userAgent || "";
	const touch = navigator.maxTouchPoints || 0;
	const iPad = /iPad/.test(ua) || /Macintosh/.test(ua) && touch > 1;
	let kind = "computer";
	let label = "Computer";
	if (iPad) {
		kind = "tablet";
		label = "iPad";
	} else if (/iPhone|iPod/.test(ua)) {
		kind = "phone";
		label = "iPhone";
	} else if (/Android/.test(ua) && /Mobile/.test(ua)) {
		kind = "phone";
		label = "Android phone";
	} else if (/Android/.test(ua)) {
		kind = "tablet";
		label = "Android tablet";
	} else if (/Mobile|Windows Phone|BlackBerry|Opera Mini|IEMobile/.test(ua)) {
		kind = "phone";
		label = "Phone";
	} else if (/Tablet|PlayBook|Silk/.test(ua)) {
		kind = "tablet";
		label = "Tablet";
	}
	const nav = navigator;
	const seed = [
		ua,
		String(navigator.hardwareConcurrency || 0),
		String(nav.deviceMemory || 0),
		navigator.language || "",
		Intl.DateTimeFormat().resolvedOptions().timeZone || ""
	].join("|");
	return {
		kind,
		label,
		seed: kind === "computer" ? "sample-phone" : seed
	};
}
function formatBytes(bytes) {
	if (bytes < 1024) return `${bytes} B`;
	if (bytes < 1048576) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
	if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`;
	return `${(bytes / 1073741824).toFixed(1)} GB`;
}
function formatWhen(timestamp) {
	return new Intl.DateTimeFormat("en", {
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	}).format(timestamp);
}
var STORAGE_KEY = "daylight-shield-v1";
function wait(ms) {
	return new Promise((resolve) => {
		setTimeout(resolve, ms);
	});
}
function isPack(value) {
	return value === 1 || value === 2;
}
function isSnapshot(value) {
	if (!value || typeof value !== "object") return false;
	const snapshot = value;
	return typeof snapshot.id === "string" && Array.isArray(snapshot.files) && typeof snapshot.deviceLabel === "string";
}
function useShield() {
	const [device, setDevice] = (0, import_react.useState)(null);
	const [pack, setPack] = (0, import_react.useState)(1);
	const [held, setHeld] = (0, import_react.useState)([]);
	const [snapshot, setSnapshot] = (0, import_react.useState)(null);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [tab, setTab] = (0, import_react.useState)("home");
	const [progress, setProgress] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const gen = (0, import_react.useRef)(0);
	const packRef = (0, import_react.useRef)(pack);
	const heldRef = (0, import_react.useRef)(held);
	const snapshotRef = (0, import_react.useRef)(snapshot);
	const deviceRef = (0, import_react.useRef)(device);
	const partialRef = (0, import_react.useRef)(null);
	packRef.current = pack;
	heldRef.current = held;
	snapshotRef.current = snapshot;
	deviceRef.current = device;
	(0, import_react.useEffect)(() => {
		setDevice(detectDevice());
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const data = JSON.parse(raw);
				if (isPack(data.pack)) setPack(data.pack);
				if (Array.isArray(data.held)) setHeld(data.held.filter((id) => typeof id === "string"));
				if (isSnapshot(data.snapshot)) setSnapshot(data.snapshot);
				if (Array.isArray(data.history)) setHistory(data.history.filter(isSnapshot).slice(0, 6));
			}
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const data = {
			pack,
			held,
			snapshot,
			history: history.slice(0, 6)
		};
		localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
	}, [
		hydrated,
		pack,
		held,
		snapshot,
		history
	]);
	(0, import_react.useEffect)(() => {
		return () => {
			gen.current += 1;
		};
	}, []);
	const commit = (0, import_react.useCallback)((next) => {
		const previous = snapshotRef.current;
		if (previous && previous.id !== next.id) setHistory((items) => [previous, ...items].slice(0, 6));
		setSnapshot(next);
		setProgress(null);
		setTab("home");
	}, []);
	const scanItems = (0, import_react.useCallback)(async (args) => {
		if (args.items.length === 0) return;
		const id = ++gen.current;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const pause = (ms) => wait(reduce ? 0 : ms);
		setTab("home");
		setProgress({
			done: 0,
			total: args.items.length,
			current: args.intro ? "Common phone folders" : "Chosen files",
			phase: args.intro ? "Leaving installed apps alone" : "Reading chosen files",
			threats: 0,
			recent: []
		});
		partialRef.current = {
			kind: args.kind,
			label: args.label,
			files: [],
			total: args.items.length
		};
		if (args.intro) {
			await pause(360);
			if (gen.current !== id) return;
			setProgress((current) => current ? {
				...current,
				phase: "Opening folders",
				current: "Camera, Downloads, Documents, Messages, Audio"
			} : current);
			await pause(320);
		}
		const doneFiles = [];
		let threats = 0;
		for (let index = 0; index < args.items.length; index += 1) {
			if (gen.current !== id) return;
			const item = args.items[index];
			if (!item) continue;
			const finding = inspect({
				name: item.name,
				text: item.text,
				bytes: item.bytesHead
			}, packRef.current);
			if (finding) threats += 1;
			const scanned = {
				id: item.id,
				name: item.name,
				folder: item.folder,
				bytes: item.bytes,
				finding
			};
			doneFiles.push(scanned);
			partialRef.current = {
				kind: args.kind,
				label: args.label,
				files: doneFiles.slice(),
				total: args.items.length
			};
			setProgress({
				done: index + 1,
				total: args.items.length,
				current: `${item.folder} / ${item.name}`,
				phase: `Checking ${item.folder}`,
				threats,
				recent: doneFiles.slice(-4).map((file) => ({
					id: file.id,
					label: `${file.folder} / ${file.name}`,
					bad: file.finding !== null
				}))
			});
			await pause(44);
		}
		if (gen.current !== id) return;
		partialRef.current = null;
		const securedAtFinish = scoreFrom(doneFiles, new Set(heldRef.current)).secured;
		commit({
			id: `scan-${Date.now()}`,
			kind: args.kind,
			deviceLabel: args.label,
			finishedAt: Date.now(),
			files: doneFiles,
			scannedPercent: 100,
			pack: packRef.current,
			securedAtFinish
		});
	}, [commit]);
	const startMainScan = (0, import_react.useCallback)(() => {
		if (progress) return;
		const info = deviceRef.current ?? detectDevice();
		if (!deviceRef.current) setDevice(info);
		if (info.kind === "computer") {
			scanItems({
				kind: "sample",
				label: "Sample phone",
				items: buildVault("sample-phone", "sample"),
				intro: true
			});
			return;
		}
		scanItems({
			kind: "phone",
			label: info.label,
			items: buildVault(info.seed, "device"),
			intro: true
		});
	}, [progress, scanItems]);
	const startPicked = (0, import_react.useCallback)(async (list) => {
		if (progress) return;
		const files = [...list].slice(0, 40);
		if (files.length === 0) return;
		const items = [];
		for (const file of files) {
			const buffer = await file.slice(0, 262144).arrayBuffer();
			const bytesHead = new Uint8Array(buffer);
			const text = new TextDecoder("utf-8", { fatal: false }).decode(bytesHead.slice(0, 65536));
			items.push({
				id: `chosen/${file.name}/${file.size}/${file.lastModified}`,
				name: file.name,
				folder: "Chosen",
				bytes: file.size,
				text,
				bytesHead
			});
		}
		await scanItems({
			kind: "picked",
			label: "Chosen files",
			items,
			intro: false
		});
	}, [progress, scanItems]);
	const startEicar = (0, import_react.useCallback)(() => {
		if (progress) return;
		scanItems({
			kind: "picked",
			label: "EICAR test",
			intro: false,
			items: [{
				id: "chosen/eicar.com",
				name: "eicar.com",
				folder: "Chosen",
				bytes: EICAR_TEST.length,
				text: EICAR_TEST
			}]
		});
	}, [progress, scanItems]);
	const stop = (0, import_react.useCallback)(() => {
		const partial = partialRef.current;
		partialRef.current = null;
		gen.current += 1;
		setProgress(null);
		if (!partial || partial.files.length === 0 || partial.files.length >= partial.total) return;
		const securedAtFinish = scoreFrom(partial.files, new Set(heldRef.current)).secured;
		commit({
			id: `scan-${Date.now()}`,
			kind: partial.kind,
			deviceLabel: partial.label,
			finishedAt: Date.now(),
			files: partial.files,
			scannedPercent: Math.max(1, Math.round(partial.files.length / partial.total * 100)),
			pack: packRef.current,
			securedAtFinish
		});
	}, [commit]);
	const quarantine = (0, import_react.useCallback)((id) => {
		setHeld((current) => current.includes(id) ? current : [...current, id]);
	}, []);
	const restore = (0, import_react.useCallback)((id) => {
		setHeld((current) => current.filter((item) => item !== id));
	}, []);
	const updateSignatures = (0, import_react.useCallback)(() => {
		setPack(2);
	}, []);
	const heldSet = (0, import_react.useMemo)(() => new Set(held), [held]);
	const scored = (0, import_react.useMemo)(() => snapshot ? scoreFrom(snapshot.files, heldSet) : null, [snapshot, heldSet]);
	const activeThreats = (0, import_react.useMemo)(() => snapshot?.files.filter((file) => file.finding && !heldSet.has(file.id)) ?? [], [snapshot, heldSet]);
	const heldFiles = (0, import_react.useMemo)(() => snapshot?.files.filter((file) => file.finding && heldSet.has(file.id)) ?? [], [snapshot, heldSet]);
	const primaryLabel = !snapshot ? device?.kind === "tablet" ? "Scan this tablet" : device?.kind === "phone" ? "Scan this phone" : device?.kind === "computer" ? "Sample phone scan" : "Start scan" : "Scan again";
	return {
		device,
		pack,
		tab,
		setTab,
		snapshot,
		history,
		progress,
		score: scored?.secured ?? null,
		capped: scored?.capped ?? false,
		activeThreats,
		heldFiles,
		heldSet,
		scanning: progress !== null,
		primaryLabel,
		startMainScan,
		startPicked,
		startEicar,
		stop,
		quarantine,
		restore,
		updateSignatures
	};
}
var tap = "transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]";
function ScoreDial({ value, caption, tone, busy }) {
	const radius = 86;
	const circumference = 2 * Math.PI * radius;
	const offset = circumference - (value ?? 0) / 100 * circumference;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto grid size-56 place-items-center",
		role: busy ? "progressbar" : "meter",
		"aria-valuenow": value ?? 0,
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		"aria-label": caption,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 220 220",
			className: "size-56",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "110",
				cy: "110",
				r: radius,
				fill: "none",
				stroke: "var(--color-line)",
				strokeWidth: "12"
			}), value !== null && value > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "110",
				cy: "110",
				r: radius,
				fill: "none",
				stroke: tone === "bad" ? "var(--color-danger)" : tone === "idle" ? "var(--color-line)" : "var(--color-primary)",
				strokeWidth: "12",
				strokeLinecap: "round",
				strokeDasharray: circumference,
				strokeDashoffset: offset,
				transform: "rotate(-90 110 110)",
				className: "transition-[stroke-dashoffset] duration-150 ease-out"
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 flex flex-col items-center justify-center px-8 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-serif text-6xl leading-none tracking-tight tabular-nums text-ink",
				children: [value === null ? "–" : value, value !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-3xl",
					children: "%"
				}) : null]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm font-medium text-muted",
				children: caption
			})]
		})]
	});
}
function ActionButton({ children, onClick, variant, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		disabled,
		className: cn("inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl px-4 text-base font-semibold", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary", "disabled:opacity-50", tap, variant === "primary" && "bg-primary text-surface", variant === "quiet" && "border border-line bg-surface text-ink", variant === "danger" && "bg-danger-soft text-danger", variant === "soft" && "bg-primary-soft text-primary"),
		children
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-serif text-2xl leading-none tabular-nums text-ink",
			children: value
		})]
	});
}
function ThreatCard({ file, action, actionLabel, variant }) {
	if (!file.finding) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("grid size-11 shrink-0 place-items-center rounded-xl", variant === "danger" ? "bg-danger-soft text-danger" : "bg-primary-soft text-primary"),
				children: variant === "danger" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-semibold text-ink",
						children: file.finding.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-sm text-muted",
						children: [
							file.folder,
							" / ",
							file.name
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-ink",
						children: file.finding.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm tabular-nums text-muted",
						children: [formatBytes(file.bytes), variant === "danger" ? ` · −${file.finding.penalty} from the score` : " · left out of the score"]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ActionButton, {
				variant: variant === "danger" ? "danger" : "soft",
				onClick: action,
				children: [variant === "soft" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), actionLabel]
			})
		})]
	});
}
function ShieldApp() {
	const shield = useShield();
	const fileRef = (0, import_react.useRef)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const scanning = shield.scanning;
	const progress = shield.progress;
	const snapshot = shield.snapshot;
	const scannedNow = progress && progress.total > 0 ? Math.round(progress.done / progress.total * 100) : 0;
	const dialValue = scanning ? scannedNow : shield.score;
	const dialCaption = scanning ? "scanned" : snapshot ? "secured" : "not scanned yet";
	const tone = scanning || shield.score === null ? scanning ? "good" : "idle" : shield.score >= 90 ? "good" : "bad";
	const visibleFiles = (snapshot?.files ?? []).filter((file) => {
		if (!`${file.folder} ${file.name}`.toLowerCase().includes(query.trim().toLowerCase())) return false;
		if (filter === "risk") return file.finding !== null && !shield.heldSet.has(file.id);
		if (filter === "clean") return file.finding === null || shield.heldSet.has(file.id);
		return true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-md flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-10 flex items-end justify-between bg-bg/90 px-5 py-4 backdrop-blur-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-3xl leading-none text-ink",
						children: "Daylight"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Phone and tablet file shield"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "pb-1 text-sm tabular-nums text-muted",
						children: ["Pack ", shield.pack]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex flex-1 flex-col gap-6 px-5 pb-6",
					children: [
						scanning && progress ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "flex flex-col gap-5",
							"aria-busy": "true",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreDial, {
									value: dialValue,
									caption: dialCaption,
									tone: "good",
									busy: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-ink",
											children: progress.phase
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 truncate text-sm text-muted",
											children: progress.current
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-2 text-sm tabular-nums text-muted",
											children: [
												progress.done,
												" of ",
												progress.total,
												" files",
												progress.threats > 0 ? ` · ${progress.threats} risky` : ""
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2",
									"aria-live": "polite",
									children: progress.recent.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-3 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate text-ink",
											children: row.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: row.bad ? "font-semibold text-danger" : "text-muted",
											children: row.bad ? "Risk" : "Clean"
										})]
									}, row.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionButton, {
									variant: "quiet",
									onClick: shield.stop,
									children: "Stop scan"
								})
							]
						}) : null,
						!scanning && shield.tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePane, {
							shield,
							dialValue,
							dialCaption,
							tone: tone === "idle" ? "idle" : tone,
							onPick: () => fileRef.current?.click()
						}) : null,
						!scanning && shield.tab === "files" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "flex flex-col gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-serif text-3xl text-ink",
								children: "Files"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted",
								children: "Everything from the latest scan. Installed apps are not in this list."
							})] }), snapshot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Search scanned files"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: query,
										onChange: (event) => setQuery(event.target.value),
										placeholder: "Search files",
										className: "min-h-12 w-full rounded-2xl border border-line bg-surface px-4 text-base text-ink placeholder:text-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										["all", "All"],
										["risk", "Risks"],
										["clean", "Clean"]
									].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setFilter(id),
										className: cn("min-h-11 rounded-2xl text-sm font-semibold", tap, filter === id ? "bg-primary text-surface" : "border border-line bg-surface text-ink"),
										children: label
									}, id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface",
									children: visibleFiles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "px-4 py-6 text-sm text-muted",
										children: "No files match."
									}) : visibleFiles.map((file) => {
										const held = shield.heldSet.has(file.id);
										const risky = file.finding !== null && !held;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center gap-3 px-4 py-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-5 shrink-0 text-muted" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0 flex-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "truncate font-medium text-ink",
														children: file.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "truncate text-sm text-muted",
														children: [
															file.folder,
															" · ",
															formatBytes(file.bytes)
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: cn("shrink-0 rounded-full px-2.5 py-1 text-sm font-semibold", risky && "bg-danger-soft text-danger", held && "bg-bg text-muted", !risky && !held && "bg-primary-soft text-primary"),
													children: risky ? "Risk" : held ? "Held" : "Clean"
												})
											]
										}, file.id);
									})
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, {
								title: "Nothing scanned yet",
								body: "Run a scan from Home. Daylight will list the files it checked."
							})]
						}) : null,
						!scanning && shield.tab === "hold" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "flex flex-col gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-serif text-3xl text-ink",
								children: "Quarantine"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted",
								children: "Held files stay out of the secured percentage until you restore them."
							})] }), shield.heldFiles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, {
								title: "Nothing is held",
								body: "When a scan finds a virus or a risky file, quarantine it here. The percentage goes up as soon as you do."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-col gap-3",
								children: shield.heldFiles.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreatCard, {
									file,
									variant: "soft",
									actionLabel: "Restore",
									action: () => shield.restore(file.id)
								}, file.id))
							})]
						}) : null
					]
				}),
				scanning ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "sticky bottom-0 z-10 grid grid-cols-3 border-t border-line bg-bg/95 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							label: "Home",
							active: shield.tab === "home",
							onClick: () => shield.setTab("home"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							label: "Files",
							active: shield.tab === "files",
							onClick: () => shield.setTab("files"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							label: "Quarantine",
							active: shield.tab === "hold",
							onClick: () => shield.setTab("hold"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5" })
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: fileRef,
			type: "file",
			multiple: true,
			className: "sr-only",
			onChange: (event) => {
				const list = event.target.files;
				if (!list || list.length === 0) return;
				const files = [...list];
				event.target.value = "";
				shield.startPicked(files);
			}
		})]
	});
}
function HomePane({ shield, dialValue, dialCaption, tone, onPick }) {
	const snapshot = shield.snapshot;
	const folders = snapshot ? folderStats(snapshot.files, shield.heldSet) : [];
	const device = shield.device;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		device?.kind === "computer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "rounded-2xl border border-line bg-surface p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-11 shrink-0 place-items-center rounded-xl bg-bg text-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold text-ink",
					children: "Laptops stay out"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: "Daylight scans phones and tablets — Android, iPhone, and iPad. It does not scan this computer. Use the sample phone scan, or open Daylight on your phone."
				})] })]
			})
		}) : null,
		device && device.kind !== "computer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "rounded-2xl bg-primary-soft p-4 text-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-11 shrink-0 place-items-center rounded-xl bg-surface text-primary",
					children: device.kind === "tablet" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tablet, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: device.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: "Ready to scan files and viruses. Installed apps are skipped."
				})] })]
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreDial, {
			value: dialValue,
			caption: dialCaption,
			tone
		}),
		snapshot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					snapshot.deviceLabel,
					snapshot.kind === "sample" ? " · not this computer" : "",
					" · ",
					formatWhen(snapshot.finishedAt)
				]
			}), snapshot.scannedPercent < 100 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-danger",
				children: [
					"Scan stopped at ",
					snapshot.scannedPercent,
					"% of files."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm font-medium text-ink",
				children: "100% of files scanned"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-center text-sm leading-relaxed text-muted",
			children: "Checks files for viruses. You get a clear percentage — 100% secured means nothing active was found."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ActionButton, {
					variant: "primary",
					onClick: shield.startMainScan,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" }), shield.primaryLabel]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ActionButton, {
					variant: "quiet",
					onClick: onPick,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSearch, { className: "size-5" }), "Check chosen files"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: shield.startEicar,
					className: cn("min-h-11 text-sm font-semibold text-primary", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary", tap),
					children: "Try a test virus"
				})
			]
		}),
		snapshot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Files scanned",
					value: `${snapshot.scannedPercent}%`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Still at risk",
					value: String(shield.activeThreats.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Quarantined",
					value: String(shield.heldFiles.length)
				})
			]
		}) : null,
		shield.activeThreats.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl text-ink",
				children: "Needs attention"
			}), shield.activeThreats.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreatCard, {
				file,
				variant: "danger",
				actionLabel: "Quarantine",
				action: () => shield.quarantine(file.id)
			}, file.id))]
		}) : null,
		snapshot && shield.activeThreats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl bg-primary-soft px-4 py-4 text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold",
				children: "No active threats"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: shield.heldFiles.length > 0 ? "Risky files are quarantined, so they are not counted." : "Every file in this scan came back clean."
			})]
		}) : null,
		snapshot && shield.activeThreats.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold text-ink",
					children: "How this percentage is made"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Starting point"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-ink",
								children: "100"
							})]
						}),
						shield.activeThreats.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-muted",
								children: file.finding?.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "shrink-0 tabular-nums text-danger",
								children: ["−", file.finding?.penalty]
							})]
						}, file.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 border-t border-line pt-2 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Secured" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [shield.score, "%"]
							})]
						})
					]
				}),
				shield.capped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "The score stops at 55% when many files are risky."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Quarantine a file and that subtraction comes off."
				})
			]
		}) : null,
		folders.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl text-ink",
				children: "Folders checked"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Apps are not a folder here, and they are not scanned."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: folders.map((folder) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-surface px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: folder.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-semibold tabular-nums text-ink",
						children: [
							folder.total - folder.issues,
							"/",
							folder.total,
							" clean"
						]
					})]
				}, folder.name))
			})
		] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl border border-line bg-surface p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold text-ink",
					children: "Virus signatures"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: shield.pack === 2 ? "22 Nov 2026 · pack 2" : "18 Nov 2026 · pack 1"
				})] }), shield.pack === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: shield.updateSignatures,
					className: cn("min-h-11 shrink-0 rounded-2xl bg-primary px-4 text-sm font-semibold text-surface", tap),
					children: "Update signatures"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-semibold text-primary",
					children: "Current"
				})]
			}), snapshot && snapshot.pack < shield.pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: [
					"This report still used pack ",
					snapshot.pack,
					". Scan again so the newer pattern is included."
				]
			}) : null]
		}),
		shield.history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl text-ink",
			children: "Earlier scans"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface",
			children: shield.history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-medium text-ink",
						children: item.deviceLabel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: formatWhen(item.finishedAt)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-serif text-2xl leading-none tabular-nums text-ink",
						children: [item.securedAtFinish, "%"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "secured"
					})]
				})]
			}, item.id))
		})] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "Daylight never scans installed apps, and it never scans a laptop or desktop. Chosen files are read on this device only — the first 256 KB of each one."
		})
	] });
}
function EmptyNote({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface px-4 py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-semibold text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm leading-relaxed text-muted",
			children: body
		})]
	});
}
function NavButton({ label, active, onClick, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-current": active ? "page" : void 0,
		className: cn("flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl text-sm font-semibold", tap, active ? "text-primary" : "text-muted"),
		children: [icon, label]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldApp, {});
}
//#endregion
export { Home as component };
