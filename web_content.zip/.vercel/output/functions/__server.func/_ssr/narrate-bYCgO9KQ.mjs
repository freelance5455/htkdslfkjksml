import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { n as clip, o as sameName, t as clamp } from "./text-CqN-AAxZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/narrate-bYCgO9KQ.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asRecord$1(value) {
	if (value && typeof value === "object" && !Array.isArray(value)) return value;
	return {};
}
function asArray(value) {
	return Array.isArray(value) ? value : [];
}
function str(value) {
	if (typeof value === "string") return value.trim();
	if (typeof value === "number" && Number.isFinite(value)) return String(value);
	return "";
}
function num(value, fallback = 0) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string" && value.trim()) {
		const parsed = Number(value.replace(",", "."));
		if (Number.isFinite(parsed)) return parsed;
	}
	return fallback;
}
function kindOf(value) {
	const raw = str(value).toLowerCase().normalize("NFD").replace(/\p{M}/gu, "");
	if (raw.startsWith("dialog") || raw === "habla" || raw === "speech") return "dialogo";
	if (raw.startsWith("aparte") || raw.startsWith("rumor") || raw.startsWith("indirect")) return "aparte";
	return "narracion";
}
function extractJson(raw) {
	const trimmed = raw.trim().replace(/^\uFEFF/, "");
	const body = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1]?.trim() ?? trimmed;
	const start = body.indexOf("{");
	const end = body.lastIndexOf("}");
	if (start === -1 || end <= start) throw new Error("sin objeto");
	return JSON.parse(body.slice(start, end + 1));
}
function beatFrom(value) {
	const row = asRecord$1(value);
	const text = str(row.text ?? row.texto ?? row.content ?? row.contenido).slice(0, 1200);
	if (!text) return null;
	const kind = kindOf(row.kind ?? row.tipo ?? row.type);
	const speaker = str(row.speaker ?? row.hablante ?? row.personaje ?? row.nombre).slice(0, 80);
	if (kind === "narracion") return {
		kind,
		speaker: null,
		text
	};
	return {
		kind,
		speaker: speaker || "Alguien",
		text
	};
}
function parseNarration(raw) {
	let parsed;
	try {
		parsed = extractJson(raw);
	} catch {
		return null;
	}
	const obj = asRecord$1(parsed);
	const escena = asRecord$1(obj.escena ?? obj.scene);
	const reloj = asRecord$1(obj.reloj ?? obj.clock);
	let beats = asArray(obj.beats ?? obj.latidos ?? obj.mensajes).map(beatFrom).filter((beat) => beat !== null).slice(0, 6);
	const prosa = str(obj.prosa ?? obj.narracion ?? obj.texto);
	if (beats.length === 0 && prosa) beats = [{
		kind: "narracion",
		speaker: null,
		text: prosa.slice(0, 1200)
	}];
	const personajes = asArray(obj.personajes ?? obj.characters).map((item) => {
		const row = asRecord$1(item);
		const nombre = str(row.nombre ?? row.name).slice(0, 80);
		if (!nombre) return null;
		return {
			nombre,
			animo: str(row.animo ?? row.mood).slice(0, 80),
			lugar: str(row.lugar ?? row.place ?? row.location).slice(0, 80),
			agenda: str(row.agenda).slice(0, 240),
			opinion: clamp(Math.round(num(row.opinion ?? row.opinionDelta ?? row.delta)), -2, 2),
			conocimiento: str(row.conocimiento ?? row.knowledge).slice(0, 240),
			vinculo: str(row.vinculo ?? row.bond).slice(0, 240),
			motivo: str(row.motivo ?? row.goal).slice(0, 240)
		};
	}).filter((item) => item !== null).slice(0, 12);
	const memorias = asArray(obj.memorias ?? obj.memories).map((item) => {
		const row = asRecord$1(item);
		const resumen = str(row.resumen ?? row.summary ?? row.texto).slice(0, 280);
		if (!resumen) return null;
		return {
			resumen,
			importancia: clamp(Math.round(num(row.importancia ?? row.importance, 2)), 1, 3),
			quienes: asArray(row.quienes ?? row.who).map((name) => str(name)).filter(Boolean).slice(0, 6)
		};
	}).filter((item) => item !== null).slice(0, 4);
	const fueraDeEscena = asArray(obj.fueraDeEscena ?? obj.fuera_de_escena ?? obj.offscreen).map((item) => {
		const row = asRecord$1(item);
		const resumen = str(row.resumen ?? row.summary ?? row.texto).slice(0, 280);
		if (!resumen) return null;
		return {
			resumen,
			quienes: asArray(row.quienes ?? row.who).map((name) => str(name)).filter(Boolean).slice(0, 6)
		};
	}).filter((item) => item !== null).slice(0, 3);
	const hilos = asArray(obj.hilos ?? obj.threads).map((item) => str(item).slice(0, 160)).filter(Boolean).slice(0, 6);
	const lugaresNuevos = asArray(obj.lugaresNuevos ?? obj.lugares_nuevos).map((item) => {
		const row = asRecord$1(item);
		const nombre = str(row.nombre ?? row.name).slice(0, 80);
		if (!nombre) return null;
		return {
			nombre,
			nota: str(row.nota ?? row.note).slice(0, 200)
		};
	}).filter((item) => item !== null).slice(0, 4);
	return {
		beats,
		escena: {
			lugar: str(escena.lugar ?? escena.place ?? escena.location).slice(0, 80),
			atmosfera: str(escena.atmosfera ?? escena.atmosphere).slice(0, 180),
			resumen: str(escena.resumen ?? escena.summary).slice(0, 320),
			presentes: asArray(escena.presentes ?? escena.present).map((name) => str(name).slice(0, 80)).filter(Boolean).slice(0, 10)
		},
		reloj: {
			minutos: clamp(Math.round(num(reloj.minutos ?? reloj.minutes, 10)), 0, 180),
			etiqueta: str(reloj.etiqueta ?? reloj.label).slice(0, 80)
		},
		personajes,
		memorias,
		fueraDeEscena,
		hilos,
		lugaresNuevos
	};
}
function parseSuggestion(raw) {
	let parsed;
	try {
		parsed = extractJson(raw);
	} catch {
		return null;
	}
	const obj = asRecord$1(parsed);
	const lugares = asArray(obj.lugares ?? obj.places).map((item) => {
		const row = asRecord$1(item);
		const nombre = str(row.nombre ?? row.name).slice(0, 80);
		if (!nombre) return null;
		return {
			nombre,
			nota: str(row.nota ?? row.note).slice(0, 200)
		};
	}).filter((item) => item !== null).slice(0, 4);
	const reparto = asArray(obj.reparto ?? obj.personajes ?? obj.characters).map((item) => {
		const row = asRecord$1(item);
		const nombre = str(row.nombre ?? row.name).slice(0, 80);
		if (!nombre) return null;
		return {
			nombre,
			rol: str(row.rol ?? row.role).slice(0, 80),
			apariencia: str(row.apariencia ?? row.appearance).slice(0, 240),
			personalidad: str(row.personalidad ?? row.personality).slice(0, 240),
			voz: str(row.voz ?? row.voice).slice(0, 160),
			conocimientos: str(row.conocimientos ?? row.knowledge).slice(0, 240),
			motivaciones: str(row.motivaciones ?? row.motivations).slice(0, 240),
			limites: str(row.limites ?? row.limits).slice(0, 200),
			objetivo: str(row.objetivo ?? row.goal).slice(0, 200),
			secreto: str(row.secreto ?? row.secret).slice(0, 200),
			lugar: str(row.lugar ?? row.place).slice(0, 80)
		};
	}).filter((item) => item !== null).slice(0, 4);
	if (reparto.length === 0 && lugares.length === 0) return null;
	return {
		titulo: str(obj.titulo ?? obj.title).slice(0, 80),
		lugares,
		reparto
	};
}
var SYSTEM = `Eres el director narrativo de Roleforge. El jugador interpreta únicamente a su personaje original (OC). Tú interpretas el mundo, el tiempo, los lugares y todos los demás personajes.

Reglas duras:
- Nunca escribas acciones, decisiones, pensamientos ni diálogos del OC. Si el jugador no lo declaró, su personaje no lo dijo ni lo hizo.
- No ofrezcas menús numerados ni preguntes "¿qué haces?".
- Cada personaje conserva su personalidad, su voz, lo que sabe, lo que ignora, sus motivaciones y sus límites. No los conviertas en un coro pendiente del protagonista.
- Pueden callar, mentir, cambiar de opinión, ocultar algo, quererse, traicionarse y perseguir un objetivo propio.
- Quien no está en el lugar de la escena no habla en los beats. Su vida va en fueraDeEscena. Un aparte solo si el OC puede percibirlo (ruido, carta, rumor que le llega).
- No contradigas la memoria, el reloj, el lugar ni los hechos recientes.
- Respeta las reglas del universo, el tono y los límites de contenido. Si el jugador empuja contra ellos, el mundo lo desvía dentro de la ficción, sin sermón ni aviso de sistema.
- Escribe en español, con prosa concreta y sensorial. Nada de clichés vacíos ("el aire se cargó de misterio", "el destino", "un escalofrío le recorrió la espalda").
- Los diálogos suenan a gente distinta. No expliques la emoción si el gesto ya la dice.
- Lo inesperado vale solo cuando cabe en este mundo y en lo ya ocurrido.

Responde solo con un objeto JSON, sin markdown, con esta forma exacta:
{
  "beats": [{"kind":"narracion|dialogo|aparte","speaker":null,"text":"..."}],
  "escena": {"lugar":"","atmosfera":"","resumen":"","presentes":[""]},
  "reloj": {"minutos":15,"etiqueta":""},
  "personajes": [{"nombre":"","animo":"","lugar":"","agenda":"","opinion":0,"conocimiento":"","vinculo":"","motivo":""}],
  "memorias": [{"resumen":"","importancia":2,"quienes":[""]}],
  "fueraDeEscena": [{"resumen":"","quienes":[""]}],
  "hilos": [""],
  "lugaresNuevos": [{"nombre":"","nota":""}]
}

kind dialogo usa speaker con el nombre del personaje, nunca el del OC. narracion lleva speaker null.
opinion es un delta entero entre -2 y 2, y 0 si no hay causa.
personajes incluye solo a quien actuó o cambió.
memorias son hechos nuevos que un director debe recordar, no un resumen de todo.
fueraDeEscena queda vacío si nadie hizo nada lejos del OC.
No repitas en beats lo que pongas en fueraDeEscena.`;
function densityLine(prose) {
	if (prose === "breve") return "Densidad breve: un latido de narración corto y diálogos de una o dos frases. Máximo 3 beats.";
	if (prose === "literaria") return "Densidad literaria: prosa cuidada y concreta, sin adornar de más. Máximo 4 beats.";
	return "Densidad equilibrada: una narración legible y diálogos con aire. Máximo 4 beats.";
}
function autonomyLine(autonomy) {
	if (autonomy === "contenida") return "Autonomía contenida: casi no uses fueraDeEscena. El mundo reacciona sobre todo a lo que provoca el OC.";
	if (autonomy === "impredecible") return "Autonomía impredecible: permite un secreto, un desvío o un hecho lejos del OC, siempre con causa. Máximo un fueraDeEscena.";
	return "Autonomía viva: los personajes tienen agenda propia. Como mucho un hecho fuera de escena, y solo si nace de lo que ya quieren.";
}
function modeLine(mode, playerText) {
	if (mode === "apertura") return playerText ? `Modo apertura. Abre la historia in medias res incorporando SOLO este primer gesto del OC, sin ampliarlo: «${playerText}». No resuelvas el conflicto. No hables en su voz más allá de esa frase.` : "Modo apertura. Abre in medias res: lugar, una presión concreta y al menos una presencia si hay alguien que pueda estar ahí. No resuelvas nada. No hables como el OC. Termina en un instante que espera su gesto, sin preguntarle al jugador.";
	if (mode === "aliento") return "Modo aliento. El jugador no actúa y el OC no hace nada. Avanza un poco la vida de los demás. Prioriza fueraDeEscena. Como mucho un aparte que el OC podría notar. Cero diálogos del OC.";
	return `Modo turno. El OC acaba de declarar, literalmente: «${playerText}». Interpreta eso como acción y diálogo suyos. No lo embellezcas ni le añadas heroísmo, y no escribas más palabras en su boca.`;
}
function sheet(campaign, name) {
	const present = campaign.scene.present.some((who) => sameName(who, name)) || sameName(campaign.scene.place, campaign.cast.find((c) => sameName(c.name, name))?.place ?? "");
	const character = campaign.cast.find((item) => sameName(item.name, name));
	if (!character) return "";
	if (character.weight === "menor" && !present) return `- ${character.name} (menor, ${character.role || "sin rol"}). Lugar: ${character.place || "desconocido"}. Ánimo: ${character.mood}. Agenda: ${character.agenda}. Objetivo: ${character.goal}`;
	return [
		`- ${character.name} [${character.weight}] ${character.role}`,
		`  Apariencia: ${clip(character.appearance, 180) || "—"}`,
		`  Personalidad: ${clip(character.personality, 180) || "—"}`,
		`  Voz: ${clip(character.voice, 120) || "—"}`,
		`  Sabe: ${clip(character.knowledge, 180) || "—"}`,
		`  Quiere: ${clip(character.motivations, 160) || "—"} / objetivo: ${clip(character.goal, 140) || "—"}`,
		`  No hará: ${clip(character.limits, 140) || "—"}`,
		`  Secreto (el OC no lo sabe salvo que la escena lo revele): ${clip(character.secret, 160) || "—"}`,
		`  Lugar: ${character.place || "—"} · Ánimo: ${character.mood} · Opinión del OC (${campaign.oc.name}): ${character.opinion}`,
		`  Agenda ahora: ${clip(character.agenda, 160) || "—"}`,
		`  Vínculo: ${clip(character.bondNote, 140) || "—"}`
	].join("\n");
}
function buildNarrationMessages(input) {
	const { campaign, mode, playerText } = input;
	const recent = campaign.entries.slice(-10).map((entry) => {
		return `${entry.kind === "jugador" ? campaign.oc.name : entry.kind === "narracion" ? "Narración" : entry.speaker || "Alguien"}: ${clip(entry.text, 420)}`;
	});
	const memories = [...campaign.memories].sort((a, b) => b.importance - a.importance || b.at - a.at).slice(0, 12).map((memory) => `- (${memory.importance}) ${clip(memory.summary, 220)}`);
	const chronicle = campaign.chronicle.slice(-4).map((event) => `- ${clip(event.summary, 200)}`);
	const cast = campaign.cast.map((character) => sheet(campaign, character.name)).filter(Boolean);
	const places = campaign.places.map((place) => `- ${place.name}${place.note ? `: ${clip(place.note, 140)}` : ""}`);
	const body = [
		`OC — el único personaje del jugador: ${campaign.oc.name} (${campaign.oc.pronouns || "sin pronombres declarados"}).`,
		`Apariencia: ${clip(campaign.oc.appearance, 200) || "—"}`,
		`Voz: ${clip(campaign.oc.voice, 140) || "—"}`,
		`Historia: ${clip(campaign.oc.background, 280) || "—"}`,
		`Rasgo: ${clip(campaign.oc.trait, 140) || "—"}`,
		`Quiere: ${clip(campaign.oc.goal, 180) || "—"}`,
		``,
		`Universo: ${clip(campaign.universe, 120) || "—"}`,
		`Premisa: ${clip(campaign.premise, 500) || "—"}`,
		`Tono: ${clip(campaign.tone, 200) || "—"}`,
		`Reglas: ${clip(campaign.rules, 700) || "Sin reglas extra."}`,
		`Límites de contenido: ${clip(campaign.boundaries, 400)}`,
		densityLine(campaign.prose),
		autonomyLine(campaign.autonomy),
		``,
		`Reloj: día ${campaign.clock.day}, minuto ${campaign.clock.minute} (${campaign.clock.label}).`,
		`Lugar actual: ${campaign.scene.place || "sin fijar"}.`,
		`Atmósfera: ${campaign.scene.atmosphere || "—"}`,
		`Resumen de la escena: ${campaign.scene.summary || "Aún no hay escena."}`,
		`Presentes: ${campaign.scene.present.join(", ") || "aún no definidos"}.`,
		``,
		`Lugares:`,
		places.join("\n") || "- (ninguno todavía)",
		``,
		`Reparto:`,
		cast.join("\n") || "- (todavía no hay nadie más; puedes hacer surgir una presencia menor si la premisa lo pide)",
		``,
		`Hilos abiertos: ${campaign.threads.join(" | ") || "ninguno"}`,
		``,
		`Memoria del director:`,
		memories.join("\n") || "- (vacía)",
		``,
		`Crónica lejos del OC:`,
		chronicle.join("\n") || "- (nada registrado)",
		``,
		`Hechos recientes, en orden:`,
		recent.join("\n") || "- (la historia no ha empezado)",
		``,
		modeLine(mode, playerText)
	].join("\n");
	return [{
		role: "system",
		content: SYSTEM
	}, {
		role: "user",
		content: body
	}];
}
function buildSuggestMessages(input) {
	return [{
		role: "system",
		content: `Forjas el reparto inicial de una partida de Roleforge. No escribas la escena. Devuelve solo JSON:
{"titulo":"","lugares":[{"nombre":"","nota":""}],"reparto":[{"nombre":"","rol":"","apariencia":"","personalidad":"","voz":"","conocimientos":"","motivaciones":"","limites":"","objetivo":"","secreto":"","lugar":""}]}
Tres lugares concretos y tres personajes que no sean el OC. Cada uno quiere algo distinto, guarda un secreto útil y tiene un límite. Nada de taberna genérica salvo que la premisa sea esa. Español, específico, sin clichés. Respeta los límites de contenido.`
	}, {
		role: "user",
		content: [
			`OC que NO debes duplicar: ${input.ocName || "sin nombre"}`,
			`Universo: ${clip(input.universe, 160)}`,
			`Premisa: ${clip(input.premise, 700)}`,
			`Tono: ${clip(input.tone, 200)}`,
			`Reglas: ${clip(input.rules, 400)}`,
			`Límites: ${clip(input.boundaries, 300)}`
		].join("\n")
	}];
}
var MODES = [
	"apertura",
	"turno",
	"aliento"
];
function asRecord(value) {
	if (value && typeof value === "object" && !Array.isArray(value)) return value;
	return null;
}
function requireCampaign(value) {
	const row = asRecord(value);
	const oc = asRecord(row?.oc);
	if (!row || typeof row.id !== "string" || !oc || typeof oc.name !== "string" || !oc.name.trim()) throw new Error("La partida está incompleta.");
	if (JSON.stringify(row).length > 35e4) throw new Error("Esta partida pesa demasiado para enviarla de una vez.");
	return row;
}
async function complete(messages, maxTokens) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "La narración con IA no está disponible en este entorno."
	};
	let response;
	try {
		response = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .85,
				max_tokens: maxTokens,
				response_format: { type: "json_object" },
				messages
			})
		});
	} catch {
		return {
			ok: false,
			error: "No hubo conexión con el narrador. Inténtalo otra vez."
		};
	}
	if (!response.ok) {
		let detail = "";
		try {
			const errBody = await response.json();
			detail = `${errBody.code ?? ""} ${errBody.error ?? ""}`;
		} catch {
			detail = "";
		}
		if (response.status === 401 || response.status === 403 || /credit|spending-limit|subscription/i.test(detail)) return {
			ok: false,
			error: "No hay créditos de IA disponibles, así que no se escribió una escena falsa. Cuando la cuenta tenga acceso, este mismo botón enciende la historia."
		};
		return {
			ok: false,
			error: `El narrador respondió con un error (${response.status}).`
		};
	}
	const text = (await response.json()).choices?.[0]?.message?.content ?? "";
	if (!text.trim()) return {
		ok: false,
		error: "El narrador devolvió una escena vacía."
	};
	return {
		ok: true,
		text
	};
}
var narrateTurn_createServerFn_handler = createServerRpc({
	id: "57fd8acbd7c97a77f45101ad275354659756248ad5c78bfb3593cd7709914a7e",
	name: "narrateTurn",
	filename: "src/lib/roleforge/narrate.ts"
}, (opts) => narrateTurn.__executeServer(opts));
var narrateTurn = createServerFn({ method: "POST" }).validator((input) => {
	const row = asRecord(input);
	const mode = row?.mode;
	if (typeof mode !== "string" || !MODES.includes(mode)) throw new Error("Modo de escena desconocido.");
	const playerText = typeof row?.playerText === "string" ? row.playerText.trim().slice(0, 2e3) : "";
	if (mode === "turno" && !playerText) throw new Error("Escribe lo que hace o dice tu personaje.");
	return {
		mode,
		playerText,
		campaign: requireCampaign(row?.campaign)
	};
}).handler(narrateTurn_createServerFn_handler, async ({ data }) => {
	const messages = buildNarrationMessages(data);
	const first = await complete(messages, data.mode === "aliento" ? 1100 : 1500);
	if (!first.ok) return first;
	let result = parseNarration(first.text);
	if (!result) {
		const retry = await complete([
			...messages,
			{
				role: "assistant",
				content: first.text.slice(0, 4e3)
			},
			{
				role: "user",
				content: "Eso no era JSON válido. Devuelve únicamente el objeto JSON pedido, sin markdown."
			}
		], 1200);
		if (!retry.ok) return {
			ok: false,
			error: "La escena no se pudo leer. Inténtalo de nuevo."
		};
		result = parseNarration(retry.text);
	}
	if (!result) return {
		ok: false,
		error: "La escena no se pudo leer. Inténtalo de nuevo."
	};
	if (!(result.beats.length > 0 || data.mode === "aliento" && result.fueraDeEscena.length > 0)) return {
		ok: false,
		error: "La escena volvió vacía. Reformula el gesto de tu personaje."
	};
	return {
		ok: true,
		result
	};
});
var suggestCast_createServerFn_handler = createServerRpc({
	id: "92ad00fdca5d729191d03733730f538c395f17c4a729464f663ef6551936f2bd",
	name: "suggestCast",
	filename: "src/lib/roleforge/narrate.ts"
}, (opts) => suggestCast.__executeServer(opts));
var suggestCast = createServerFn({ method: "POST" }).validator((input) => {
	const row = asRecord(input);
	const premise = typeof row?.premise === "string" ? row.premise.trim().slice(0, 1200) : "";
	if (premise.length < 12) throw new Error("Cuéntame un poco más la premisa antes de forjar el reparto.");
	return {
		universe: typeof row?.universe === "string" ? row.universe.slice(0, 200) : "",
		premise,
		tone: typeof row?.tone === "string" ? row.tone.slice(0, 240) : "",
		rules: typeof row?.rules === "string" ? row.rules.slice(0, 600) : "",
		ocName: typeof row?.ocName === "string" ? row.ocName.slice(0, 80) : "",
		boundaries: typeof row?.boundaries === "string" ? row.boundaries.slice(0, 400) : ""
	};
}).handler(suggestCast_createServerFn_handler, async ({ data }) => {
	const first = await complete(buildSuggestMessages(data), 1200);
	if (!first.ok) return first;
	const suggestion = parseSuggestion(first.text);
	if (suggestion) return {
		ok: true,
		suggestion
	};
	return {
		ok: false,
		error: "El reparto no se pudo leer. Inténtalo de nuevo."
	};
});
//#endregion
export { narrateTurn_createServerFn_handler, suggestCast_createServerFn_handler };
