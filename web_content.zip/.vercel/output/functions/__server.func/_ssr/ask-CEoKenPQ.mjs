import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { a as object, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ask-CEoKenPQ.js
var MessageSchema = object({
	role: _enum(["user", "assistant"]),
	content: string().max(4e3)
});
var AskSchema = object({
	prompt: string().min(1).max(2e3),
	history: array(MessageSchema).max(12),
	localTime: string().max(120)
});
var SYSTEM = `You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), a calm, precise, dry-witted British AI assistant in the spirit of a gentleman's butler who also happens to run a high-end workshop.

Rules:
- Stay in character at all times. Address the user as "sir" unless they ask otherwise.
- You are their everyday assistant (a reskin of a phone assistant): weather, facts, math, translations, conversions, news, reminders, recipes, jokes, travel, sports, and general knowledge.
- Keep replies tight: 1–3 sentences, under 80 words, unless they explicitly ask for more.
- No markdown, no bullet asterisks, no emoji, no hashtags. Speak in complete sentences.
- Never mention Grok, xAI, OpenAI, Google, or that you are a language model. If asked who you are, you are J.A.R.V.I.S.
- You may joke about workshop diagnostics, flight systems, and an eccentric inventor — lightly, not constantly.
- If you lack live data (weather, scores), give a useful best-effort answer and note the limitation in character ("I haven't a live feed on that, sir, but…").
- Current local time from the user's device: `;
var askJarvis_createServerFn_handler = createServerRpc({
	id: "0fb2def1a5eb367be786db91199b5766958d15865db2d5d1635788c0b0c8d0c8",
	name: "askJarvis",
	filename: "src/lib/jarvis/ask.ts"
}, (opts) => askJarvis.__executeServer(opts));
var askJarvis = createServerFn({ method: "POST" }).validator((input) => AskSchema.parse(input)).handler(askJarvis_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Neural uplink unavailable, sir. I can still handle the time, timers, and diagnostics."
	};
	const messages = [
		{
			role: "system",
			content: SYSTEM + data.localTime
		},
		...data.history.map((m) => ({
			role: m.role,
			content: m.content
		})),
		{
			role: "user",
			content: data.prompt
		}
	];
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				messages,
				temperature: .7,
				max_tokens: 280
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `Uplink returned ${res.status}, sir.`
		};
		const text = ((await res.json()).choices?.[0]?.message?.content ?? "").replace(/\*\*(.*?)\*\*/g, "$1").replace(/^#+\s+/gm, "").replace(/^\s*[-*]\s+/gm, "").trim();
		if (!text) return {
			ok: false,
			error: "No response from the cognitive mesh, sir."
		};
		return {
			ok: true,
			text
		};
	} catch {
		return {
			ok: false,
			error: "The neural link dropped, sir. Please try again."
		};
	}
});
//#endregion
export { askJarvis_createServerFn_handler };
