//#region node_modules/.nitro/vite/services/ssr/assets/engine-DpqNPzjs.js
var CHART = [
	{
		code: "1",
		name: "دارایی‌ها",
		level: 1,
		group: "asset",
		nature: "debit"
	},
	{
		code: "11",
		name: "دارایی‌های جاری",
		level: 2,
		parent: "1",
		group: "asset",
		nature: "debit"
	},
	{
		code: "1101",
		name: "صندوق",
		level: 3,
		parent: "11",
		group: "asset",
		nature: "debit"
	},
	{
		code: "110101",
		name: "صندوق اصلی",
		level: 4,
		parent: "1101",
		group: "asset",
		nature: "debit",
		postable: true
	},
	{
		code: "1102",
		name: "بانک‌ها",
		level: 3,
		parent: "11",
		group: "asset",
		nature: "debit"
	},
	{
		code: "110201",
		name: "بانک ملی — جاری",
		level: 4,
		parent: "1102",
		group: "asset",
		nature: "debit",
		postable: true,
		floating: "bank"
	},
	{
		code: "110202",
		name: "بانک ملت — جاری",
		level: 4,
		parent: "1102",
		group: "asset",
		nature: "debit",
		postable: true,
		floating: "bank"
	},
	{
		code: "1103",
		name: "تنخواه",
		level: 3,
		parent: "11",
		group: "asset",
		nature: "debit"
	},
	{
		code: "110301",
		name: "تنخواه گردان",
		level: 4,
		parent: "1103",
		group: "asset",
		nature: "debit",
		postable: true
	},
	{
		code: "1104",
		name: "حساب‌های دریافتنی",
		level: 3,
		parent: "11",
		group: "asset",
		nature: "debit"
	},
	{
		code: "110401",
		name: "مشتریان",
		level: 4,
		parent: "1104",
		group: "asset",
		nature: "debit",
		postable: true,
		floating: "party"
	},
	{
		code: "1105",
		name: "اسناد دریافتنی",
		level: 3,
		parent: "11",
		group: "asset",
		nature: "debit"
	},
	{
		code: "110501",
		name: "چک‌های دریافتنی",
		level: 4,
		parent: "1105",
		group: "asset",
		nature: "debit",
		postable: true
	},
	{
		code: "1106",
		name: "موجودی کالا",
		level: 3,
		parent: "11",
		group: "asset",
		nature: "debit"
	},
	{
		code: "110601",
		name: "کالای آماده فروش",
		level: 4,
		parent: "1106",
		group: "asset",
		nature: "debit",
		postable: true
	},
	{
		code: "1107",
		name: "پیش‌پرداخت‌ها",
		level: 3,
		parent: "11",
		group: "asset",
		nature: "debit"
	},
	{
		code: "110701",
		name: "پیش‌پرداخت خرید",
		level: 4,
		parent: "1107",
		group: "asset",
		nature: "debit",
		postable: true,
		floating: "party"
	},
	{
		code: "1108",
		name: "سپرده‌ها",
		level: 3,
		parent: "11",
		group: "asset",
		nature: "debit"
	},
	{
		code: "110801",
		name: "سپرده‌های بانکی",
		level: 4,
		parent: "1108",
		group: "asset",
		nature: "debit",
		postable: true
	},
	{
		code: "12",
		name: "دارایی‌های غیرجاری",
		level: 2,
		parent: "1",
		group: "asset",
		nature: "debit"
	},
	{
		code: "1201",
		name: "اموال، ماشین‌آلات و تجهیزات",
		level: 3,
		parent: "12",
		group: "asset",
		nature: "debit"
	},
	{
		code: "120101",
		name: "اثاثه و منصوبات",
		level: 4,
		parent: "1201",
		group: "asset",
		nature: "debit",
		postable: true
	},
	{
		code: "1202",
		name: "استهلاک انباشته",
		level: 3,
		parent: "12",
		group: "contra",
		nature: "credit"
	},
	{
		code: "120201",
		name: "استهلاک انباشته اثاثه",
		level: 4,
		parent: "1202",
		group: "contra",
		nature: "credit",
		postable: true
	},
	{
		code: "2",
		name: "بدهی‌ها",
		level: 1,
		group: "liability",
		nature: "credit"
	},
	{
		code: "21",
		name: "بدهی‌های جاری",
		level: 2,
		parent: "2",
		group: "liability",
		nature: "credit"
	},
	{
		code: "2101",
		name: "حساب‌های پرداختنی",
		level: 3,
		parent: "21",
		group: "liability",
		nature: "credit"
	},
	{
		code: "210101",
		name: "تأمین‌کنندگان",
		level: 4,
		parent: "2101",
		group: "liability",
		nature: "credit",
		postable: true,
		floating: "party"
	},
	{
		code: "2102",
		name: "اسناد پرداختنی",
		level: 3,
		parent: "21",
		group: "liability",
		nature: "credit"
	},
	{
		code: "210201",
		name: "چک‌های پرداختنی",
		level: 4,
		parent: "2102",
		group: "liability",
		nature: "credit",
		postable: true
	},
	{
		code: "2103",
		name: "مالیات پرداختنی",
		level: 3,
		parent: "21",
		group: "liability",
		nature: "credit"
	},
	{
		code: "210301",
		name: "مالیات ارزش افزوده",
		level: 4,
		parent: "2103",
		group: "liability",
		nature: "credit",
		postable: true
	},
	{
		code: "2104",
		name: "بیمه پرداختنی",
		level: 3,
		parent: "21",
		group: "liability",
		nature: "credit"
	},
	{
		code: "210401",
		name: "حق بیمه سهم کارفرما",
		level: 4,
		parent: "2104",
		group: "liability",
		nature: "credit",
		postable: true
	},
	{
		code: "2105",
		name: "حقوق پرداختنی",
		level: 3,
		parent: "21",
		group: "liability",
		nature: "credit"
	},
	{
		code: "210501",
		name: "حقوق و دستمزد پرداختنی",
		level: 4,
		parent: "2105",
		group: "liability",
		nature: "credit",
		postable: true
	},
	{
		code: "2106",
		name: "پیش‌دریافت‌ها",
		level: 3,
		parent: "21",
		group: "liability",
		nature: "credit"
	},
	{
		code: "210601",
		name: "پیش‌دریافت از مشتریان",
		level: 4,
		parent: "2106",
		group: "liability",
		nature: "credit",
		postable: true,
		floating: "party"
	},
	{
		code: "2107",
		name: "سایر بدهی‌ها",
		level: 3,
		parent: "21",
		group: "liability",
		nature: "credit"
	},
	{
		code: "210701",
		name: "بدهی‌های متفرقه",
		level: 4,
		parent: "2107",
		group: "liability",
		nature: "credit",
		postable: true
	},
	{
		code: "3",
		name: "سرمایه",
		level: 1,
		group: "equity",
		nature: "credit"
	},
	{
		code: "31",
		name: "حقوق صاحبان سرمایه",
		level: 2,
		parent: "3",
		group: "equity",
		nature: "credit"
	},
	{
		code: "3101",
		name: "سرمایه",
		level: 3,
		parent: "31",
		group: "equity",
		nature: "credit"
	},
	{
		code: "310101",
		name: "سرمایه پرداخت‌شده",
		level: 4,
		parent: "3101",
		group: "equity",
		nature: "credit",
		postable: true
	},
	{
		code: "3102",
		name: "برداشت",
		level: 3,
		parent: "31",
		group: "equity",
		nature: "debit"
	},
	{
		code: "310201",
		name: "برداشت شرکا",
		level: 4,
		parent: "3102",
		group: "equity",
		nature: "debit",
		postable: true,
		floating: "party"
	},
	{
		code: "3103",
		name: "سود و زیان",
		level: 3,
		parent: "31",
		group: "equity",
		nature: "credit"
	},
	{
		code: "310301",
		name: "سود و زیان انباشته",
		level: 4,
		parent: "3103",
		group: "equity",
		nature: "credit",
		postable: true
	},
	{
		code: "310302",
		name: "سود و زیان جاری",
		level: 4,
		parent: "3103",
		group: "equity",
		nature: "credit",
		postable: true
	},
	{
		code: "4",
		name: "درآمدها",
		level: 1,
		group: "income",
		nature: "credit"
	},
	{
		code: "41",
		name: "درآمد عملیاتی",
		level: 2,
		parent: "4",
		group: "income",
		nature: "credit"
	},
	{
		code: "4101",
		name: "فروش",
		level: 3,
		parent: "41",
		group: "income",
		nature: "credit"
	},
	{
		code: "410101",
		name: "فروش کالا",
		level: 4,
		parent: "4101",
		group: "income",
		nature: "credit",
		postable: true
	},
	{
		code: "4102",
		name: "درآمد خدمات",
		level: 3,
		parent: "41",
		group: "income",
		nature: "credit"
	},
	{
		code: "410201",
		name: "درآمد ارائه خدمات",
		level: 4,
		parent: "4102",
		group: "income",
		nature: "credit",
		postable: true
	},
	{
		code: "4103",
		name: "سایر درآمدها",
		level: 3,
		parent: "41",
		group: "income",
		nature: "credit"
	},
	{
		code: "410301",
		name: "درآمدهای متفرقه",
		level: 4,
		parent: "4103",
		group: "income",
		nature: "credit",
		postable: true
	},
	{
		code: "4104",
		name: "برگشت از فروش و تخفیفات",
		level: 3,
		parent: "41",
		group: "income",
		nature: "debit"
	},
	{
		code: "410401",
		name: "برگشت از فروش",
		level: 4,
		parent: "4104",
		group: "income",
		nature: "debit",
		postable: true
	},
	{
		code: "410501",
		name: "تخفیفات فروش",
		level: 4,
		parent: "4104",
		group: "income",
		nature: "debit",
		postable: true
	},
	{
		code: "5",
		name: "بهای تمام‌شده",
		level: 1,
		group: "cogs",
		nature: "debit"
	},
	{
		code: "51",
		name: "بهای تمام‌شده کالای فروش‌رفته",
		level: 2,
		parent: "5",
		group: "cogs",
		nature: "debit"
	},
	{
		code: "5101",
		name: "بهای کالا",
		level: 3,
		parent: "51",
		group: "cogs",
		nature: "debit"
	},
	{
		code: "510101",
		name: "بهای تمام‌شده کالای فروش‌رفته",
		level: 4,
		parent: "5101",
		group: "cogs",
		nature: "debit",
		postable: true
	},
	{
		code: "5102",
		name: "بهای خدمات",
		level: 3,
		parent: "51",
		group: "cogs",
		nature: "debit"
	},
	{
		code: "510201",
		name: "بهای خدمات ارائه‌شده",
		level: 4,
		parent: "5102",
		group: "cogs",
		nature: "debit",
		postable: true
	},
	{
		code: "6",
		name: "هزینه‌ها",
		level: 1,
		group: "expense",
		nature: "debit"
	},
	{
		code: "61",
		name: "هزینه‌های عملیاتی",
		level: 2,
		parent: "6",
		group: "expense",
		nature: "debit"
	},
	{
		code: "6101",
		name: "حقوق و دستمزد",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610101",
		name: "حقوق و دستمزد پرسنل",
		level: 4,
		parent: "6101",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6102",
		name: "اجاره",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610201",
		name: "اجاره محل",
		level: 4,
		parent: "6102",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6103",
		name: "آب و برق و گاز",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610301",
		name: "هزینه انرژی و ارتباطات",
		level: 4,
		parent: "6103",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6104",
		name: "حمل",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610401",
		name: "هزینه حمل و نقل",
		level: 4,
		parent: "6104",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6105",
		name: "بازاریابی",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610501",
		name: "هزینه بازاریابی",
		level: 4,
		parent: "6105",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6106",
		name: "تبلیغات",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610601",
		name: "هزینه تبلیغات",
		level: 4,
		parent: "6106",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6107",
		name: "تعمیرات",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610701",
		name: "تعمیر و نگهداری",
		level: 4,
		parent: "6107",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6108",
		name: "استهلاک",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610801",
		name: "هزینه استهلاک",
		level: 4,
		parent: "6108",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6109",
		name: "هزینه بانکی",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "610901",
		name: "کارمزد و هزینه بانکی",
		level: 4,
		parent: "6109",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6110",
		name: "هزینه مالی",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "611001",
		name: "هزینه‌های مالی",
		level: 4,
		parent: "6110",
		group: "expense",
		nature: "debit",
		postable: true
	},
	{
		code: "6111",
		name: "سایر هزینه‌ها",
		level: 3,
		parent: "61",
		group: "expense",
		nature: "debit"
	},
	{
		code: "611101",
		name: "هزینه‌های متفرقه",
		level: 4,
		parent: "6111",
		group: "expense",
		nature: "debit",
		postable: true
	}
];
var CODES = {
	CASH: "110101",
	BANK_MELI: "110201",
	BANK_MELLAT: "110202",
	PETTY: "110301",
	AR: "110401",
	NOTES_REC: "110501",
	INVENTORY: "110601",
	PREPAID: "110701",
	AP: "210101",
	NOTES_PAY: "210201",
	VAT: "210301",
	WAGES_PAY: "210501",
	UNEARNED: "210601",
	CAPITAL: "310101",
	DRAWINGS: "310201",
	RETAINED: "310301",
	CURRENT_PL: "310302",
	SALES: "410101",
	SERVICES: "410201",
	OTHER_INCOME: "410301",
	SALES_RETURN: "410401",
	SALES_DISCOUNT: "410501",
	COGS: "510101",
	WAGES: "610101",
	RENT: "610201",
	UTILITIES: "610301",
	FREIGHT: "610401",
	MARKETING: "610501",
	BANK_FEE: "610901",
	OTHER_EXP: "611101"
};
var AccountingError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "AccountingError";
	}
};
function acc(books, code) {
	const a = books.accountsByCode.get(code);
	if (!a) throw new AccountingError(`حساب ${code} در کدینگ یافت نشد.`);
	if (!a.isActive) throw new AccountingError(`حساب ${a.name} غیرفعال است.`);
	return a;
}
function cashAcc(books, cashId) {
	if (!cashId) throw new AccountingError("منبع مالی انتخاب نشده است.");
	const c = books.cashById.get(cashId);
	if (!c || !c.isActive) throw new AccountingError("منبع مالی نامعتبر است.");
	const a = books.accountsById.get(c.accountId);
	if (!a) throw new AccountingError("حساب منبع مالی در کدینگ نیست.");
	return {
		cash: c,
		account: a
	};
}
function line(account, debit, credit, extra) {
	return {
		accountId: account.id,
		accountCode: account.code,
		accountName: account.name,
		debit: Math.round(debit),
		credit: Math.round(credit),
		partyId: extra?.partyId ?? null,
		cashAccountId: extra?.cashAccountId ?? null,
		description: extra?.description
	};
}
function assertBalanced(lines) {
	const d = lines.reduce((s, l) => s + l.debit, 0);
	const c = lines.reduce((s, l) => s + l.credit, 0);
	if (d !== c) throw new AccountingError(`سند نامتوازن است. بدهکار ${d.toLocaleString("en-US")} ≠ بستانکار ${c.toLocaleString("en-US")}`);
	if (d === 0) throw new AccountingError("مبلغ سند نمی‌تواند صفر باشد.");
	for (const l of lines) {
		if (l.debit < 0 || l.credit < 0) throw new AccountingError("مبلغ منفی غیرمجاز است.");
		if (l.debit > 0 && l.credit > 0) throw new AccountingError("یک ردیف نمی‌تواند همزمان بدهکار و بستانکار باشد.");
		if (!l.accountId) throw new AccountingError("حساب نامعتبر در ردیف سند.");
	}
}
function buildJournalLines(input, books) {
	if (input.opType !== "manual" && input.opType !== "adjustment") {
		if (!input.amount || input.amount <= 0) throw new AccountingError("مبلغ باید بزرگ‌تر از صفر باشد.");
	}
	const amt = Math.round(input.amount || 0);
	const desc = input.description?.trim() || void 0;
	let lines = [];
	const cash = () => cashAcc(books, input.cashAccountId);
	const dest = () => cashAcc(books, input.destCashAccountId);
	switch (input.opType) {
		case "receipt": {
			const { account, cash: ca } = cash();
			if (!input.partyId) throw new AccountingError("شخص (مشتری) الزامی است.");
			lines = [line(account, amt, 0, {
				cashAccountId: ca.id,
				description: desc
			}), line(acc(books, CODES.AR), 0, amt, {
				partyId: input.partyId,
				description: desc
			})];
			break;
		}
		case "receipt_other": {
			const { account, cash: ca } = cash();
			const income = input.incomeAccountId ? books.accountsById.get(input.incomeAccountId) ?? acc(books, CODES.OTHER_INCOME) : acc(books, CODES.OTHER_INCOME);
			lines = [line(account, amt, 0, {
				cashAccountId: ca.id,
				description: desc
			}), line(income, 0, amt, {
				partyId: input.partyId,
				description: desc
			})];
			break;
		}
		case "payment": {
			const { account, cash: ca } = cash();
			if (!input.partyId) throw new AccountingError("شخص (تأمین‌کننده) الزامی است.");
			lines = [line(acc(books, CODES.AP), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(account, 0, amt, {
				cashAccountId: ca.id,
				description: desc
			})];
			break;
		}
		case "payment_other": {
			const { account, cash: ca } = cash();
			lines = [line(input.expenseAccountId ? books.accountsById.get(input.expenseAccountId) ?? acc(books, CODES.OTHER_EXP) : acc(books, CODES.OTHER_EXP), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(account, 0, amt, {
				cashAccountId: ca.id,
				description: desc
			})];
			break;
		}
		case "transfer": {
			const from = cash();
			const to = dest();
			if (from.cash.id === to.cash.id) throw new AccountingError("مبدأ و مقصد انتقال یکسان است.");
			lines = [line(to.account, amt, 0, {
				cashAccountId: to.cash.id,
				description: desc
			}), line(from.account, 0, amt, {
				cashAccountId: from.cash.id,
				description: desc
			})];
			break;
		}
		case "sale_cash": {
			const { account, cash: ca } = cash();
			lines = [line(account, amt, 0, {
				cashAccountId: ca.id,
				partyId: input.partyId,
				description: desc
			}), line(acc(books, CODES.SALES), 0, amt, {
				partyId: input.partyId,
				description: desc
			})];
			break;
		}
		case "sale_credit":
			if (!input.partyId) throw new AccountingError("مشتری برای فروش نسیه الزامی است.");
			lines = [line(acc(books, CODES.AR), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(acc(books, CODES.SALES), 0, amt, {
				partyId: input.partyId,
				description: desc
			})];
			break;
		case "sale_mixed": {
			if (!input.partyId) throw new AccountingError("مشتری برای فروش ترکیبی الزامی است.");
			const cashAmt = Math.round(input.cashPortion ?? 0);
			const creditAmt = amt - cashAmt;
			if (cashAmt < 0 || creditAmt < 0) throw new AccountingError("سهم نقدی نامعتبر است.");
			if (cashAmt === 0 && creditAmt === 0) throw new AccountingError("مبلغ فروش صفر است.");
			if (cashAmt > 0) {
				const { account, cash: ca } = cash();
				lines.push(line(account, cashAmt, 0, {
					cashAccountId: ca.id,
					partyId: input.partyId
				}));
			}
			if (creditAmt > 0) lines.push(line(acc(books, CODES.AR), creditAmt, 0, { partyId: input.partyId }));
			lines.push(line(acc(books, CODES.SALES), 0, amt, {
				partyId: input.partyId,
				description: desc
			}));
			break;
		}
		case "sale_return":
			if (input.cashAccountId) {
				const { account, cash: ca } = cash();
				lines = [line(acc(books, CODES.SALES_RETURN), amt, 0, {
					partyId: input.partyId,
					description: desc
				}), line(account, 0, amt, {
					cashAccountId: ca.id,
					partyId: input.partyId
				})];
			} else {
				if (!input.partyId) throw new AccountingError("مشتری برای برگشت نسیه الزامی است.");
				lines = [line(acc(books, CODES.SALES_RETURN), amt, 0, {
					partyId: input.partyId,
					description: desc
				}), line(acc(books, CODES.AR), 0, amt, { partyId: input.partyId })];
			}
			break;
		case "purchase_cash": {
			const { account, cash: ca } = cash();
			lines = [line(input.inventoryAccountId ? books.accountsById.get(input.inventoryAccountId) ?? acc(books, CODES.INVENTORY) : acc(books, CODES.INVENTORY), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(account, 0, amt, { cashAccountId: ca.id })];
			break;
		}
		case "purchase_credit":
			if (!input.partyId) throw new AccountingError("تأمین‌کننده برای خرید نسیه الزامی است.");
			lines = [line(input.inventoryAccountId ? books.accountsById.get(input.inventoryAccountId) ?? acc(books, CODES.INVENTORY) : acc(books, CODES.INVENTORY), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(acc(books, CODES.AP), 0, amt, { partyId: input.partyId })];
			break;
		case "purchase_return":
			if (input.cashAccountId) {
				const { account, cash: ca } = cash();
				lines = [line(account, amt, 0, { cashAccountId: ca.id }), line(acc(books, CODES.INVENTORY), 0, amt, {
					partyId: input.partyId,
					description: desc
				})];
			} else {
				if (!input.partyId) throw new AccountingError("تأمین‌کننده الزامی است.");
				lines = [line(acc(books, CODES.AP), amt, 0, { partyId: input.partyId }), line(acc(books, CODES.INVENTORY), 0, amt, {
					partyId: input.partyId,
					description: desc
				})];
			}
			break;
		case "sale_discount":
			if (!input.partyId) throw new AccountingError("مشتری الزامی است.");
			lines = [line(acc(books, CODES.SALES_DISCOUNT), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(acc(books, CODES.AR), 0, amt, { partyId: input.partyId })];
			break;
		case "purchase_discount":
			if (!input.partyId) throw new AccountingError("تأمین‌کننده الزامی است.");
			lines = [line(acc(books, CODES.AP), amt, 0, { partyId: input.partyId }), line(acc(books, CODES.OTHER_INCOME), 0, amt, {
				partyId: input.partyId,
				description: desc
			})];
			break;
		case "expense_cash": {
			const { account, cash: ca } = cash();
			const exp = input.expenseAccountId ? books.accountsById.get(input.expenseAccountId) : acc(books, CODES.OTHER_EXP);
			if (!exp) throw new AccountingError("حساب هزینه نامعتبر است.");
			lines = [line(exp, amt, 0, { description: desc }), line(account, 0, amt, { cashAccountId: ca.id })];
			break;
		}
		case "expense_payable": {
			const exp = input.expenseAccountId ? books.accountsById.get(input.expenseAccountId) : acc(books, CODES.OTHER_EXP);
			if (!exp) throw new AccountingError("حساب هزینه نامعتبر است.");
			lines = [line(exp, amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(acc(books, CODES.AP), 0, amt, { partyId: input.partyId })];
			break;
		}
		case "income": {
			const { account, cash: ca } = cash();
			const inc = input.incomeAccountId ? books.accountsById.get(input.incomeAccountId) : acc(books, CODES.OTHER_INCOME);
			if (!inc) throw new AccountingError("حساب درآمد نامعتبر است.");
			lines = [line(account, amt, 0, {
				cashAccountId: ca.id,
				partyId: input.partyId
			}), line(inc, 0, amt, {
				partyId: input.partyId,
				description: desc
			})];
			break;
		}
		case "check_receive":
			if (!input.partyId) throw new AccountingError("شخص برای دریافت چک الزامی است.");
			lines = [line(acc(books, CODES.NOTES_REC), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(acc(books, CODES.AR), 0, amt, { partyId: input.partyId })];
			break;
		case "check_pay":
			if (!input.partyId) throw new AccountingError("شخص برای پرداخت چک الزامی است.");
			lines = [line(acc(books, CODES.AP), amt, 0, { partyId: input.partyId }), line(acc(books, CODES.NOTES_PAY), 0, amt, {
				partyId: input.partyId,
				description: desc
			})];
			break;
		case "check_collect": {
			const { account, cash: ca } = cash();
			lines = [line(account, amt, 0, {
				cashAccountId: ca.id,
				description: desc
			}), line(acc(books, CODES.NOTES_REC), 0, amt, { partyId: input.partyId })];
			break;
		}
		case "check_return":
			if (!input.partyId) throw new AccountingError("شخص برای برگشت چک الزامی است.");
			lines = [line(acc(books, CODES.AR), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(acc(books, CODES.NOTES_REC), 0, amt, { partyId: input.partyId })];
			break;
		case "capital_in": {
			const { account, cash: ca } = cash();
			lines = [line(account, amt, 0, {
				cashAccountId: ca.id,
				description: desc
			}), line(acc(books, CODES.CAPITAL), 0, amt, { partyId: input.partyId })];
			break;
		}
		case "draw": {
			const { account, cash: ca } = cash();
			lines = [line(acc(books, CODES.DRAWINGS), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(account, 0, amt, { cashAccountId: ca.id })];
			break;
		}
		case "petty_fund": {
			const from = cash();
			const petty = books.accountsByCode.get(CODES.PETTY);
			if (!petty) throw new AccountingError("حساب تنخواه یافت نشد.");
			lines = [line(petty, amt, 0, { description: desc }), line(from.account, 0, amt, { cashAccountId: from.cash.id })];
			break;
		}
		case "petty_settle": {
			const exp = input.expenseAccountId ? books.accountsById.get(input.expenseAccountId) : acc(books, CODES.OTHER_EXP);
			if (!exp) throw new AccountingError("حساب هزینه نامعتبر است.");
			lines = [line(exp, amt, 0, { description: desc }), line(acc(books, CODES.PETTY), 0, amt)];
			break;
		}
		case "prepay": {
			const { account, cash: ca } = cash();
			lines = [line(acc(books, CODES.PREPAID), amt, 0, {
				partyId: input.partyId,
				description: desc
			}), line(account, 0, amt, { cashAccountId: ca.id })];
			break;
		}
		case "advance": {
			const { account, cash: ca } = cash();
			lines = [line(account, amt, 0, {
				cashAccountId: ca.id,
				partyId: input.partyId
			}), line(acc(books, CODES.UNEARNED), 0, amt, {
				partyId: input.partyId,
				description: desc
			})];
			break;
		}
		case "payroll": {
			const { account, cash: ca } = cash();
			lines = [line(acc(books, CODES.WAGES), amt, 0, { description: desc }), line(account, 0, amt, { cashAccountId: ca.id })];
			break;
		}
		case "manual":
		case "adjustment":
			if (!input.lines?.length) throw new AccountingError("ردیف‌های سند دستی الزامی است.");
			lines = input.lines.map((l) => {
				const a = books.accountsById.get(l.accountId);
				if (!a || !a.isPostable) throw new AccountingError("حساب ردیف سند نامعتبر است.");
				return line(a, l.debit, l.credit, {
					partyId: l.partyId,
					cashAccountId: l.cashAccountId,
					description: l.description ?? desc
				});
			});
			break;
		case "reversal":
			if (!input.lines?.length) throw new AccountingError("سند برگشتی بدون ردیف است.");
			lines = input.lines.map((l) => {
				const a = books.accountsById.get(l.accountId);
				if (!a) throw new AccountingError("حساب سند اصلی نامعتبر است.");
				return line(a, l.credit, l.debit, {
					partyId: l.partyId,
					cashAccountId: l.cashAccountId,
					description: l.description ?? desc
				});
			});
			break;
		case "opening":
		case "closing":
			if (!input.lines?.length) throw new AccountingError("ردیف‌های سند افتتاحیه/اختتامیه الزامی است.");
			lines = input.lines.map((l) => {
				const a = books.accountsById.get(l.accountId);
				if (!a) throw new AccountingError("حساب نامعتبر.");
				return line(a, l.debit, l.credit, {
					partyId: l.partyId,
					description: l.description ?? desc
				});
			});
			break;
		default: throw new AccountingError("نوع عملیات پشتیبانی نمی‌شود.");
	}
	if (input.freightAmount && input.freightAmount > 0) {
		const fr = Math.round(input.freightAmount);
		if (input.opType.startsWith("purchase")) {
			lines.push(line(acc(books, CODES.FREIGHT), fr, 0, { description: "هزینه حمل" }));
			if (input.cashAccountId) {
				const { account, cash: ca } = cash();
				lines.push(line(account, 0, fr, { cashAccountId: ca.id }));
			} else lines.push(line(acc(books, CODES.AP), 0, fr, { partyId: input.partyId }));
		}
	}
	if (input.cogsAmount && input.cogsAmount > 0 && input.opType.startsWith("sale") && input.opType !== "sale_return") {
		const cogs = Math.round(input.cogsAmount);
		lines.push(line(acc(books, CODES.COGS), cogs, 0, { description: "بهای تمام‌شده" }));
		lines.push(line(acc(books, CODES.INVENTORY), 0, cogs));
	}
	if (input.cogsAmount && input.cogsAmount > 0 && input.opType === "sale_return") {
		const cogs = Math.round(input.cogsAmount);
		lines.push(line(acc(books, CODES.INVENTORY), cogs, 0));
		lines.push(line(acc(books, CODES.COGS), 0, cogs, { description: "برگشت بهای تمام‌شده" }));
	}
	assertBalanced(lines);
	return lines;
}
function splitBalance(nature, raw) {
	if (nature === "debit") return raw >= 0 ? {
		debit: raw,
		credit: 0
	} : {
		debit: 0,
		credit: Math.abs(raw)
	};
	return raw >= 0 ? {
		debit: 0,
		credit: raw
	} : {
		debit: Math.abs(raw),
		credit: 0
	};
}
//#endregion
export { splitBalance as a, buildJournalLines as i, CHART as n, CODES as r, AccountingError as t };
