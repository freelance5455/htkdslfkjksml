import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { p as ArrowLeft } from "../_libs/lucide-react.mjs";
import { c as useVault, d as Button, o as useStarMedia, r as INBOX_SLUG, s as useStars } from "./router-CboP5aV-.mjs";
import { a as DialogHeader, i as DialogDescription, n as Dialog, o as DialogTitle, r as DialogContent, s as Input, t as AppShell } from "./app-shell-Dk04OjoX.mjs";
import { n as MediaViewer, t as MediaGrid } from "./media-viewer-DrIWtDkp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inbox-DAZ_hf4j.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InboxPage() {
	const items = useStarMedia(INBOX_SLUG);
	const stars = useStars();
	const assignMedia = useVault((s) => s.assignMedia);
	const removeMedia = useVault((s) => s.removeMedia);
	const [open, setOpen] = (0, import_react.useState)(null);
	const [assigning, setAssigning] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)("");
	const suggestions = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return (query ? stars.filter((s) => s.name.toLowerCase().includes(query)) : stars.slice(0, 20)).slice(0, 24);
	}, [q, stars]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-4 pb-20 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						asChild: true,
						"aria-label": "Back",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Unsorted"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-medium tracking-tight",
					children: "Inbox"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted-foreground",
					children: "Files whose names did not match a performer land here. Assign them, or import again with the star in the filename — like angela.white.mp4."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaGrid, {
						items,
						onOpen: setOpen,
						onAssign: setAssigning,
						onDelete: (item) => void removeMedia(item.id),
						emptyTitle: "Inbox is clear",
						emptyBody: "Import files from the plus menu. Matched names file themselves; the rest wait here."
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaViewer, {
			item: open,
			onClose: () => setOpen(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(assigning),
			onOpenChange: (o) => !o && setAssigning(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "File to a profile" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: assigning?.name })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search roster"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 max-h-64 overflow-y-auto",
					children: suggestions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex h-11 w-full items-center rounded-md px-3 text-left text-sm hover:bg-secondary",
						onClick: async () => {
							if (!assigning) return;
							await assignMedia(assigning.id, s.slug);
							setAssigning(null);
							setQ("");
						},
						children: s.name
					}) }, s.slug))
				})
			] })
		})
	] });
}
//#endregion
export { InboxPage as component };
