import { i as __toESM } from "../_runtime.mjs";
import { c as require_react, r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Repeat, c as Pause, d as ChevronRight, f as ChevronLeft, i as Square, l as GripVertical, o as Plus, r as Trash2, s as Play, t as Volume2, u as Copy } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-De3Cz6qA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var WHITE = [
	0,
	2,
	4,
	5,
	7,
	9,
	11
];
var START = 48;
var END = 72;
function isWhite(pc) {
	return WHITE.includes(pc);
}
function PianoStrip({ activePcs, className }) {
	const whites = [];
	const blacks = [];
	for (let m = START; m <= END; m++) if (isWhite(m % 12)) whites.push(m);
	const whiteWidth = 100 / whites.length;
	let wIndex = 0;
	for (let m = START; m <= END; m++) {
		if (isWhite(m % 12)) {
			wIndex += 1;
			continue;
		}
		blacks.push({
			midi: m,
			left: (wIndex - .32) * whiteWidth
		});
	}
	const active = new Set(activePcs.map((n) => (n % 12 + 12) % 12));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative h-14 w-full", className),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 flex",
			children: whites.map((midi) => {
				const on = active.has(midi % 12);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-full flex-1 border-r border-background last:border-r-0", on ? "bg-primary" : "bg-foreground/90") }, midi);
			})
		}), blacks.map(({ midi, left }) => {
			const on = active.has(midi % 12);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("absolute top-0 h-[58%] w-[4.2%] rounded-b-sm", on ? "bg-primary-foreground/80" : "bg-background"),
				style: { left: `${left}%` }
			}, midi);
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[background-color,color,box-shadow,opacity,transform] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			outline: "shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] bg-transparent",
			ghost: "hover:bg-secondary text-foreground",
			destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-14 px-6 text-base",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var PATTERNS = [
	{
		id: "block",
		name: "Block",
		hint: "All notes together"
	},
	{
		id: "strum",
		name: "Strum",
		hint: "Downstrum each bar"
	},
	{
		id: "folk",
		name: "Folk",
		hint: "Down–up down–up"
	},
	{
		id: "arp-up",
		name: "Arp up",
		hint: "Rising eighths"
	},
	{
		id: "arp-down",
		name: "Arp down",
		hint: "Falling eighths"
	},
	{
		id: "arp-alberti",
		name: "Alberti",
		hint: "Low–high–mid–high"
	},
	{
		id: "waltz",
		name: "Waltz",
		hint: "Bass, chord, chord"
	},
	{
		id: "boom-chick",
		name: "Boom-chick",
		hint: "Bass on 1 & 3"
	}
];
function clampIndex(i, len) {
	if (len <= 0) return 0;
	return (i % len + len) % len;
}
function patternEvents(pattern, beats, bpm, voiceLen) {
	const beat = 60 / bpm;
	const total = beats * beat;
	const eighth = beat / 2;
	const n = Math.max(1, voiceLen);
	if (pattern === "block") return [{
		time: 0,
		duration: total * .92,
		indices: range(n),
		velocity: .86,
		stagger: .006
	}];
	if (pattern === "strum") {
		const events = [{
			time: 0,
			duration: total * .7,
			indices: range(n),
			velocity: .9,
			stagger: .014
		}];
		if (beats >= 4) events.push({
			time: total * .5,
			duration: total * .42,
			indices: range(n).reverse(),
			velocity: .62,
			stagger: .01
		});
		return events;
	}
	if (pattern === "folk") {
		const hits = [];
		const steps = beats * 2;
		for (let i = 0; i < steps; i++) {
			const down = i % 2 === 0;
			hits.push({
				time: i * eighth,
				duration: eighth * .92,
				indices: down ? range(n) : range(n).reverse(),
				velocity: down ? .88 : .55,
				stagger: down ? .012 : .008
			});
		}
		return hits;
	}
	if (pattern === "arp-up" || pattern === "arp-down") {
		const count = Math.max(1, Math.round(total / eighth));
		const events = [];
		for (let i = 0; i < count; i++) {
			const idx = pattern === "arp-up" ? i % n : n - 1 - i % n;
			events.push({
				time: i * eighth,
				duration: eighth * .9,
				indices: [idx],
				velocity: i % 4 === 0 ? .88 : .7,
				stagger: 0
			});
		}
		return events;
	}
	if (pattern === "arp-alberti") {
		const seq = n === 1 ? [0] : n === 2 ? [
			0,
			1,
			0,
			1
		] : [
			0,
			n - 1,
			clampIndex(1, n),
			n - 1
		];
		const count = Math.max(1, Math.round(total / eighth));
		const events = [];
		for (let i = 0; i < count; i++) events.push({
			time: i * eighth,
			duration: eighth * .9,
			indices: [seq[i % seq.length]],
			velocity: i % 4 === 0 ? .86 : .68,
			stagger: 0
		});
		return events;
	}
	if (pattern === "waltz") {
		const events = [];
		const pulse = beats === 3 ? beat : beat;
		const cycles = beats === 3 ? 1 : Math.max(1, Math.round(beats / 3));
		const unit = beats === 3 ? beat : total / (cycles * 3);
		for (let c = 0; c < cycles; c++) {
			const t0 = c * unit * 3;
			events.push({
				time: t0,
				duration: pulse * .9,
				indices: [0],
				velocity: .92,
				stagger: 0
			});
			events.push({
				time: t0 + unit,
				duration: pulse * .85,
				indices: range(n).slice(1),
				velocity: .7,
				stagger: .006
			});
			events.push({
				time: t0 + unit * 2,
				duration: pulse * .85,
				indices: range(n).slice(1),
				velocity: .64,
				stagger: .006
			});
		}
		return events;
	}
	const events = [];
	for (let b = 0; b < beats; b++) {
		const t = b * beat;
		if (b % 2 === 0) events.push({
			time: t,
			duration: beat * .9,
			indices: [0],
			velocity: .92,
			stagger: 0
		});
		else events.push({
			time: t,
			duration: beat * .8,
			indices: range(n).slice(1),
			velocity: .72,
			stagger: .008
		});
	}
	return events;
}
function range(n) {
	return Array.from({ length: n }, (_, i) => i);
}
function makeImpulse(ctx, duration = 1.6, decay = 2.1) {
	const length = Math.floor(ctx.sampleRate * duration);
	const impulse = ctx.createBuffer(2, length, ctx.sampleRate);
	for (let c = 0; c < 2; c++) {
		const ch = impulse.getChannelData(c);
		for (let i = 0; i < length; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
	}
	return impulse;
}
var AudioEngine = class {
	ctx = null;
	master = null;
	dry = null;
	wet = null;
	compressor = null;
	playing = false;
	timer = null;
	raf = 0;
	nextTime = 0;
	index = 0;
	uiQueue = [];
	getter = () => ({
		chords: [],
		bpm: 96,
		pattern: "strum",
		instrument: "keys",
		loop: true,
		volume: .72,
		metronome: false
	});
	callbacks = {
		onChord: () => {},
		onStop: () => {}
	};
	setGetter(fn) {
		this.getter = fn;
	}
	setCallbacks(cb) {
		this.callbacks = cb;
	}
	get isPlaying() {
		return this.playing;
	}
	ensure() {
		if (this.ctx) return;
		const ctx = new AudioContext();
		const master = ctx.createGain();
		master.gain.value = .7;
		const compressor = ctx.createDynamicsCompressor();
		compressor.threshold.value = -18;
		compressor.knee.value = 10;
		compressor.ratio.value = 3.2;
		compressor.attack.value = .01;
		compressor.release.value = .16;
		const hipass = ctx.createBiquadFilter();
		hipass.type = "highpass";
		hipass.frequency.value = 55;
		const dry = ctx.createGain();
		dry.gain.value = .82;
		const wet = ctx.createGain();
		wet.gain.value = .22;
		const conv = ctx.createConvolver();
		conv.buffer = makeImpulse(ctx);
		dry.connect(hipass);
		wet.connect(hipass);
		conv.connect(wet);
		hipass.connect(compressor);
		compressor.connect(master);
		master.connect(ctx.destination);
		const split = ctx.createGain();
		split.connect(dry);
		split.connect(conv);
		this.ctx = ctx;
		this.master = master;
		this.dry = split;
		this.wet = wet;
		this.compressor = compressor;
	}
	async resume() {
		this.ensure();
		if (this.ctx?.state === "suspended") await this.ctx.resume();
	}
	setVolume(v) {
		if (!this.master || !this.ctx) return;
		this.master.gain.setTargetAtTime(Math.max(0, Math.min(1, v)) * .85, this.ctx.currentTime, .04);
	}
	start(fromIndex = 0) {
		this.ensure();
		if (!this.ctx || !this.dry) return;
		const snap = this.getter();
		if (snap.chords.length === 0) return;
		this.stopVoices(.04);
		this.playing = true;
		this.index = Math.max(0, Math.min(fromIndex, snap.chords.length - 1));
		this.nextTime = this.ctx.currentTime + .06;
		this.uiQueue = [];
		this.setVolume(snap.volume);
		this.armScheduler();
		this.armUi();
	}
	stop() {
		this.playing = false;
		if (this.timer != null) {
			window.clearInterval(this.timer);
			this.timer = null;
		}
		if (this.raf) cancelAnimationFrame(this.raf);
		this.uiQueue = [];
		this.stopVoices(.08);
	}
	preview(chord, pattern, bpm, instrument) {
		this.ensure();
		if (!this.ctx || !this.dry) return;
		const now = this.ctx.currentTime + .02;
		this.playChordAt(chord, pattern, bpm, instrument, now, false);
	}
	stopVoices(release) {
		if (!this.master || !this.ctx) return;
		const now = this.ctx.currentTime;
		const g = this.master.gain;
		g.cancelScheduledValues(now);
		g.setValueAtTime(g.value, now);
		g.exponentialRampToValueAtTime(.001, now + release);
		g.setValueAtTime(this.getter().volume * .85, now + release + .02);
	}
	armScheduler() {
		if (this.timer != null) window.clearInterval(this.timer);
		this.scheduleAhead();
		this.timer = window.setInterval(() => this.scheduleAhead(), 25);
	}
	armUi() {
		if (this.raf) cancelAnimationFrame(this.raf);
		const tick = () => {
			if (!this.playing || !this.ctx) return;
			const now = this.ctx.currentTime;
			while (this.uiQueue.length && this.uiQueue[0].time <= now) {
				const ev = this.uiQueue.shift();
				if (ev) this.callbacks.onChord(ev.index);
			}
			this.raf = requestAnimationFrame(tick);
		};
		this.raf = requestAnimationFrame(tick);
	}
	scheduleAhead() {
		if (!this.playing || !this.ctx) return;
		const horizon = this.ctx.currentTime + .12;
		while (this.playing && this.nextTime < horizon) {
			const snap = this.getter();
			if (snap.chords.length === 0) {
				this.playing = false;
				this.callbacks.onStop();
				return;
			}
			if (this.index >= snap.chords.length) {
				if (snap.loop) this.index = 0;
				else {
					this.playing = false;
					this.callbacks.onStop();
					return;
				}
			}
			const chord = snap.chords[this.index];
			const dur = chord.beats * (60 / snap.bpm);
			this.uiQueue.push({
				time: this.nextTime,
				index: this.index
			});
			this.playChordAt(chord, snap.pattern, snap.bpm, snap.instrument, this.nextTime, snap.metronome);
			this.nextTime += dur;
			this.index += 1;
		}
	}
	playChordAt(chord, pattern, bpm, instrument, when, metronome) {
		if (!this.ctx || !this.dry) return;
		const events = patternEvents(pattern, chord.beats, bpm, chord.midi.length);
		for (const ev of events) (ev.indices.length ? ev.indices : [0]).forEach((idx, i) => {
			const midi = chord.midi[idx];
			if (midi == null) return;
			const t = when + ev.time + i * ev.stagger;
			this.playNote(midi, t, ev.duration, ev.velocity, instrument);
		});
		if (metronome) {
			const beat = 60 / bpm;
			for (let b = 0; b < chord.beats; b++) this.tick(when + b * beat, b === 0);
		}
	}
	tick(when, accent) {
		if (!this.ctx || !this.dry) return;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = accent ? 1260 : 880;
		gain.gain.setValueAtTime(1e-4, when);
		gain.gain.exponentialRampToValueAtTime(accent ? .09 : .045, when + .004);
		gain.gain.exponentialRampToValueAtTime(1e-4, when + .05);
		osc.connect(gain);
		gain.connect(this.dry);
		osc.start(when);
		osc.stop(when + .06);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
		};
	}
	playNote(midi, when, duration, velocity, instrument) {
		if (!this.ctx || !this.dry) return;
		const freq = 440 * Math.pow(2, (midi - 69) / 12);
		const ctx = this.ctx;
		const dest = this.dry;
		const vel = Math.max(.05, Math.min(1, velocity));
		if (instrument === "nylon") {
			this.pluck(freq, when, duration, vel, midi);
			return;
		}
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		const cutoff = 900 + vel * 2200 + (midi - 48) * 18;
		filter.frequency.setValueAtTime(cutoff, when);
		filter.frequency.exponentialRampToValueAtTime(Math.max(420, cutoff * .45), when + duration * .7);
		filter.Q.value = .7;
		const gain = ctx.createGain();
		const peak = .11 * vel;
		gain.gain.setValueAtTime(1e-4, when);
		gain.gain.exponentialRampToValueAtTime(peak, when + .01);
		gain.gain.exponentialRampToValueAtTime(peak * .32, when + .28);
		gain.gain.setValueAtTime(peak * .32, when + Math.max(.3, duration * .7));
		gain.gain.exponentialRampToValueAtTime(1e-4, when + duration + .35);
		const osc1 = ctx.createOscillator();
		osc1.type = "triangle";
		osc1.frequency.value = freq;
		const osc2 = ctx.createOscillator();
		osc2.type = "sine";
		osc2.frequency.value = freq * 2;
		const g2 = ctx.createGain();
		g2.gain.value = .16;
		const osc3 = ctx.createOscillator();
		osc3.type = "sine";
		osc3.frequency.value = freq * .5;
		const g3 = ctx.createGain();
		g3.gain.value = .14;
		osc1.connect(filter);
		osc2.connect(g2);
		g2.connect(filter);
		osc3.connect(g3);
		g3.connect(filter);
		filter.connect(gain);
		gain.connect(dest);
		osc1.start(when);
		osc2.start(when);
		osc3.start(when);
		const stopAt = when + duration + .4;
		osc1.stop(stopAt);
		osc2.stop(stopAt);
		osc3.stop(stopAt);
		osc1.onended = () => {
			osc1.disconnect();
			osc2.disconnect();
			osc3.disconnect();
			g2.disconnect();
			g3.disconnect();
			filter.disconnect();
			gain.disconnect();
		};
	}
	pluck(freq, when, duration, vel, midi) {
		if (!this.ctx || !this.dry) return;
		const ctx = this.ctx;
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 1400 + vel * 1600;
		filter.Q.value = 1.1;
		const band = ctx.createBiquadFilter();
		band.type = "bandpass";
		band.frequency.value = Math.min(2400, freq * 2.4);
		band.Q.value = .9;
		const gain = ctx.createGain();
		const peak = .13 * vel * (midi < 50 ? 1.08 : .92);
		gain.gain.setValueAtTime(1e-4, when);
		gain.gain.exponentialRampToValueAtTime(peak, when + .006);
		gain.gain.exponentialRampToValueAtTime(peak * .18, when + .22);
		gain.gain.exponentialRampToValueAtTime(1e-4, when + duration + .28);
		const osc = ctx.createOscillator();
		osc.type = "sawtooth";
		osc.frequency.value = freq;
		const osc2 = ctx.createOscillator();
		osc2.type = "triangle";
		osc2.frequency.value = freq * 2.003;
		const g2 = ctx.createGain();
		g2.gain.value = .22;
		const noiseBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * .03), ctx.sampleRate);
		const data = noiseBuf.getChannelData(0);
		for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
		const noise = ctx.createBufferSource();
		noise.buffer = noiseBuf;
		const ng = ctx.createGain();
		ng.gain.setValueAtTime(.16 * vel, when);
		ng.gain.exponentialRampToValueAtTime(1e-4, when + .03);
		osc.connect(filter);
		osc2.connect(g2);
		g2.connect(filter);
		noise.connect(ng);
		ng.connect(band);
		band.connect(filter);
		filter.connect(gain);
		gain.connect(this.dry);
		osc.start(when);
		osc2.start(when);
		noise.start(when);
		const stopAt = when + duration + .32;
		osc.stop(stopAt);
		osc2.stop(stopAt);
		noise.stop(when + .04);
		osc.onended = () => {
			osc.disconnect();
			osc2.disconnect();
			g2.disconnect();
			filter.disconnect();
			band.disconnect();
			gain.disconnect();
			ng.disconnect();
		};
	}
};
var engine = null;
function getAudioEngine() {
	if (typeof window === "undefined") return new AudioEngine();
	if (!engine) engine = new AudioEngine();
	return engine;
}
var CHROMATIC_KEYS = [
	{
		pc: 0,
		id: "C",
		label: "C"
	},
	{
		pc: 1,
		id: "Db",
		label: "D♭"
	},
	{
		pc: 2,
		id: "D",
		label: "D"
	},
	{
		pc: 3,
		id: "Eb",
		label: "E♭"
	},
	{
		pc: 4,
		id: "E",
		label: "E"
	},
	{
		pc: 5,
		id: "F",
		label: "F"
	},
	{
		pc: 6,
		id: "F#",
		label: "F♯"
	},
	{
		pc: 7,
		id: "G",
		label: "G"
	},
	{
		pc: 8,
		id: "Ab",
		label: "A♭"
	},
	{
		pc: 9,
		id: "A",
		label: "A"
	},
	{
		pc: 10,
		id: "Bb",
		label: "B♭"
	},
	{
		pc: 11,
		id: "B",
		label: "B"
	}
];
var SCALES = [
	{
		id: "major",
		name: "Major",
		intervals: [
			0,
			2,
			4,
			5,
			7,
			9,
			11
		]
	},
	{
		id: "minor",
		name: "Minor",
		intervals: [
			0,
			2,
			3,
			5,
			7,
			8,
			10
		]
	},
	{
		id: "dorian",
		name: "Dorian",
		intervals: [
			0,
			2,
			3,
			5,
			7,
			9,
			10
		]
	},
	{
		id: "mixolydian",
		name: "Mixolydian",
		intervals: [
			0,
			2,
			4,
			5,
			7,
			9,
			10
		]
	},
	{
		id: "harmonic-minor",
		name: "Harmonic minor",
		intervals: [
			0,
			2,
			3,
			5,
			7,
			8,
			11
		]
	}
];
var SCALE_NUMERALS = {
	major: [
		"I",
		"ii",
		"iii",
		"IV",
		"V",
		"vi",
		"vii°"
	],
	minor: [
		"i",
		"ii°",
		"III",
		"iv",
		"v",
		"VI",
		"VII"
	],
	dorian: [
		"i",
		"ii",
		"III",
		"IV",
		"v",
		"vi°",
		"VII"
	],
	mixolydian: [
		"I",
		"ii",
		"iii°",
		"IV",
		"v",
		"vi",
		"VII"
	],
	"harmonic-minor": [
		"i",
		"ii°",
		"III+",
		"iv",
		"V",
		"VI",
		"vii°"
	]
};
var QUALITY_INTERVALS = {
	maj: [
		0,
		4,
		7
	],
	min: [
		0,
		3,
		7
	],
	dim: [
		0,
		3,
		6
	],
	aug: [
		0,
		4,
		8
	],
	"7": [
		0,
		4,
		7,
		10
	],
	maj7: [
		0,
		4,
		7,
		11
	],
	m7: [
		0,
		3,
		7,
		10
	],
	m7b5: [
		0,
		3,
		6,
		10
	],
	dim7: [
		0,
		3,
		6,
		9
	],
	sus2: [
		0,
		2,
		7
	],
	sus4: [
		0,
		5,
		7
	],
	add9: [
		0,
		4,
		7,
		14
	],
	"6": [
		0,
		4,
		7,
		9
	],
	m6: [
		0,
		3,
		7,
		9
	]
};
var SHARP_NAMES = [
	"C",
	"C♯",
	"D",
	"D♯",
	"E",
	"F",
	"F♯",
	"G",
	"G♯",
	"A",
	"A♯",
	"B"
];
var FLAT_NAMES = [
	"C",
	"D♭",
	"D",
	"E♭",
	"E",
	"F",
	"G♭",
	"G",
	"A♭",
	"A",
	"B♭",
	"B"
];
var FLAT_KEYS = /* @__PURE__ */ new Set([
	1,
	3,
	5,
	8,
	10
]);
function prefersFlats(keyPc) {
	return FLAT_KEYS.has(keyPc);
}
function signatureTonic(tonic, scale) {
	switch (scale) {
		case "minor":
		case "harmonic-minor": return (tonic + 3) % 12;
		case "dorian": return (tonic + 10) % 12;
		case "mixolydian": return (tonic + 5) % 12;
		default: return tonic;
	}
}
function spellPc(pc, keyPc, force) {
	const n = (pc % 12 + 12) % 12;
	if (force === "flat" || !force && prefersFlats(keyPc)) return FLAT_NAMES[n];
	return SHARP_NAMES[n];
}
function scalePitchClasses(tonic, scale) {
	return (SCALES.find((s) => s.id === scale)?.intervals ?? SCALES[0].intervals).map((i) => (tonic + i) % 12);
}
var SUFFIX_QUALITY = [
	{
		suffix: "m7b5",
		quality: "m7b5"
	},
	{
		suffix: "maj7",
		quality: "maj7"
	},
	{
		suffix: "add9",
		quality: "add9"
	},
	{
		suffix: "dim7",
		quality: "dim7"
	},
	{
		suffix: "sus4",
		quality: "sus4"
	},
	{
		suffix: "sus2",
		quality: "sus2"
	},
	{
		suffix: "m7",
		quality: "m7"
	},
	{
		suffix: "ø7",
		quality: "m7b5"
	},
	{
		suffix: "ø",
		quality: "m7b5"
	},
	{
		suffix: "°7",
		quality: "dim7"
	},
	{
		suffix: "dim",
		quality: "dim"
	},
	{
		suffix: "aug",
		quality: "aug"
	},
	{
		suffix: "+",
		quality: "aug"
	},
	{
		suffix: "°",
		quality: "dim"
	},
	{
		suffix: "6",
		quality: "6"
	},
	{
		suffix: "9",
		quality: "add9"
	},
	{
		suffix: "7",
		quality: "7"
	}
];
var ROMAN_RE = /^(b|#)?(III|II|IV|VII|VI|V|I)(.*)$/i;
var DEGREE_FROM_ROMAN = {
	I: 0,
	II: 1,
	III: 2,
	IV: 3,
	V: 4,
	VI: 5,
	VII: 6
};
function parseNumeral(raw) {
	const match = raw.trim().match(ROMAN_RE);
	if (!match) return null;
	const accidental = match[1] === "b" ? -1 : match[1] === "#" ? 1 : 0;
	const roman = match[2];
	const isUpper = roman === roman.toUpperCase();
	let rest = match[3] ?? "";
	let qualityHint = null;
	if (rest.startsWith("°") || rest.startsWith("o")) {
		qualityHint = rest.includes("7") ? "dim7" : "dim";
		rest = rest.replace(/^°|^o/, "");
	}
	if (rest.startsWith("+")) {
		qualityHint = "aug";
		rest = rest.slice(1);
	}
	let suffix = rest;
	if (!qualityHint && suffix) {
		const found = SUFFIX_QUALITY.find((s) => suffix.toLowerCase() === s.suffix.toLowerCase());
		if (found) qualityHint = found.quality;
	}
	return {
		accidental,
		degree: DEGREE_FROM_ROMAN[roman.toUpperCase()] ?? 0,
		roman,
		isUpper,
		suffix,
		qualityHint
	};
}
function classifyDiatonic(tonic, scale, degree, sevenths) {
	const pcs = scalePitchClasses(tonic, scale);
	const root = pcs[degree];
	const third = pcs[(degree + 2) % 7];
	const fifth = pcs[(degree + 4) % 7];
	const seventh = pcs[(degree + 6) % 7];
	const i3 = (third - root + 12) % 12;
	const i5 = (fifth - root + 12) % 12;
	const i7 = (seventh - root + 12) % 12;
	if (sevenths) {
		if (i3 === 4 && i5 === 7 && i7 === 11) return "maj7";
		if (i3 === 4 && i5 === 7 && i7 === 10) return "7";
		if (i3 === 3 && i5 === 7 && i7 === 10) return "m7";
		if (i3 === 3 && i5 === 6 && i7 === 10) return "m7b5";
		if (i3 === 3 && i5 === 6 && i7 === 9) return "dim7";
		if (i3 === 4 && i5 === 8) return "aug";
	}
	if (i3 === 4 && i5 === 8) return "aug";
	if (i3 === 3 && i5 === 6) return "dim";
	if (i3 === 3) return "min";
	return "maj";
}
function qualityFromNumeral(parsed, tonic, scale, sevenths) {
	if (parsed.qualityHint && parsed.suffix) return parsed.qualityHint;
	if (parsed.qualityHint && !parsed.suffix) {
		if (sevenths) {
			if (parsed.qualityHint === "dim") return "m7b5";
			if (parsed.qualityHint === "aug") return "aug";
		}
		return parsed.qualityHint;
	}
	const diatonic = classifyDiatonic(tonic, scale, parsed.degree, sevenths);
	const triad = classifyDiatonic(tonic, scale, parsed.degree, false);
	if (parsed.isUpper && (triad === "min" || triad === "dim")) return sevenths ? "7" : "maj";
	if (!parsed.isUpper && (triad === "maj" || triad === "aug")) return sevenths ? "m7" : "min";
	return diatonic;
}
function qualitySuffix(quality) {
	switch (quality) {
		case "maj": return "";
		case "min": return "m";
		case "dim": return "dim";
		case "aug": return "aug";
		case "7": return "7";
		case "maj7": return "maj7";
		case "m7": return "m7";
		case "m7b5": return "ø7";
		case "dim7": return "dim7";
		case "sus2": return "sus2";
		case "sus4": return "sus4";
		case "add9": return "add9";
		case "6": return "6";
		case "m6": return "m6";
	}
}
function formatSymbol(rootPc, quality, keyPc, force) {
	return `${spellPc(rootPc, keyPc, force)}${qualitySuffix(quality)}`;
}
function spellingFromParsed(parsed) {
	if (!parsed) return void 0;
	if (parsed.accidental < 0) return "flat";
	if (parsed.accidental > 0) return "sharp";
}
function bassForInstrument(rootPc, instrument) {
	const min = instrument === "nylon" ? 40 : 48;
	const max = instrument === "nylon" ? 52 : 60;
	let midi = rootPc;
	while (midi < min) midi += 12;
	while (midi > max) midi -= 12;
	return midi;
}
function voiceChord(rootPc, quality, instrument) {
	const intervals = QUALITY_INTERVALS[quality] ?? QUALITY_INTERVALS.maj;
	const bass = bassForInstrument(rootPc, instrument);
	const core = intervals.map((i) => bass + i);
	if (instrument === "nylon") {
		const extra = [bass + 12, bass + (intervals[1] ?? 4) + 12];
		const all = [...core, ...extra];
		return [...new Set(all)].sort((a, b) => a - b);
	}
	const doubled = [...core];
	if (core.length <= 3) doubled.push(bass + 12);
	return [...new Set(doubled)].sort((a, b) => a - b);
}
function resolveSlot(slot, tonic, scale, sevenths, instrument) {
	const parsed = parseNumeral(slot.numeral);
	const pcs = scalePitchClasses(tonic, scale);
	const degree = parsed?.degree ?? 0;
	const accidental = parsed?.accidental ?? 0;
	const rootPc = (pcs[degree] + accidental + 12) % 12;
	const quality = parsed ? qualityFromNumeral(parsed, tonic, scale, sevenths) : "maj";
	const midi = voiceChord(rootPc, quality, instrument);
	const force = spellingFromParsed(parsed);
	const spellKey = signatureTonic(tonic, scale);
	return {
		id: slot.id,
		numeral: slot.numeral,
		symbol: formatSymbol(rootPc, quality, spellKey, force),
		quality,
		rootPc,
		midi,
		noteNames: midi.map((m) => spellPc(m, spellKey, force)),
		beats: slot.beats
	};
}
function resolveProgression(slots, tonic, scale, sevenths, instrument) {
	return slots.map((slot) => resolveSlot(slot, tonic, scale, sevenths, instrument));
}
function diatonicPalette(tonic, scale, sevenths) {
	return SCALE_NUMERALS[scale].map((numeral) => {
		const parsed = parseNumeral(numeral);
		const pcs = scalePitchClasses(tonic, scale);
		const rootPc = parsed ? (pcs[parsed.degree] + parsed.accidental + 12) % 12 : tonic;
		const quality = parsed ? qualityFromNumeral(parsed, tonic, scale, sevenths) : "maj";
		return {
			numeral,
			symbol: formatSymbol(rootPc, quality, signatureTonic(tonic, scale), spellingFromParsed(parsed)),
			quality,
			rootPc
		};
	});
}
var BORROWED_BY_SCALE = {
	major: [
		"bVII",
		"bVI",
		"bIII",
		"iv",
		"II",
		"III"
	],
	minor: [
		"V",
		"iv",
		"II",
		"bII"
	],
	dorian: [
		"I",
		"bVII",
		"iv"
	],
	mixolydian: [
		"vi",
		"bVII",
		"IV"
	],
	"harmonic-minor": [
		"v",
		"VII",
		"iv"
	]
};
function borrowedPalette(tonic, scale, sevenths) {
	return BORROWED_BY_SCALE[scale].map((numeral) => {
		const parsed = parseNumeral(numeral);
		const pcs = scalePitchClasses(tonic, scale);
		const rootPc = parsed ? (pcs[parsed.degree] + parsed.accidental + 12) % 12 : tonic;
		const quality = parsed ? qualityFromNumeral(parsed, tonic, scale, sevenths) : "maj";
		return {
			numeral,
			symbol: formatSymbol(rootPc, quality, signatureTonic(tonic, scale), spellingFromParsed(parsed)),
			quality,
			rootPc
		};
	});
}
var PRESETS = [
	{
		id: "pop",
		name: "Pop",
		hint: "I–V–vi–IV",
		scale: "major",
		numerals: [
			"I",
			"V",
			"vi",
			"IV"
		]
	},
	{
		id: "axis",
		name: "Axis",
		hint: "vi–IV–I–V",
		scale: "major",
		numerals: [
			"vi",
			"IV",
			"I",
			"V"
		]
	},
	{
		id: "fifties",
		name: "50s",
		hint: "I–vi–IV–V",
		scale: "major",
		numerals: [
			"I",
			"vi",
			"IV",
			"V"
		]
	},
	{
		id: "classic",
		name: "Classic",
		hint: "I–IV–V–I",
		scale: "major",
		numerals: [
			"I",
			"IV",
			"V",
			"I"
		]
	},
	{
		id: "canon",
		name: "Canon",
		hint: "Pachelbel",
		scale: "major",
		numerals: [
			"I",
			"V",
			"vi",
			"iii",
			"IV",
			"I",
			"IV",
			"V"
		]
	},
	{
		id: "jazz",
		name: "Jazz",
		hint: "ii–V–I–vi",
		scale: "major",
		numerals: [
			"ii",
			"V7",
			"Imaj7",
			"vi"
		]
	},
	{
		id: "doowop",
		name: "Doo-wop",
		hint: "I–vi–ii–V",
		scale: "major",
		numerals: [
			"I",
			"vi",
			"ii",
			"V"
		]
	},
	{
		id: "creep",
		name: "Creep",
		hint: "I–III–IV–iv",
		scale: "major",
		numerals: [
			"I",
			"III",
			"IV",
			"iv"
		]
	},
	{
		id: "rock",
		name: "Rock",
		hint: "I–VII–IV",
		scale: "mixolydian",
		numerals: [
			"I",
			"VII",
			"IV"
		]
	},
	{
		id: "epic",
		name: "Epic",
		hint: "i–VI–III–VII",
		scale: "minor",
		numerals: [
			"i",
			"VI",
			"III",
			"VII"
		]
	},
	{
		id: "aeolian",
		name: "Aeolian",
		hint: "i–VII–VI–VII",
		scale: "minor",
		numerals: [
			"i",
			"VII",
			"VI",
			"VII"
		]
	},
	{
		id: "andalusian",
		name: "Andalusian",
		hint: "i–VII–VI–V",
		scale: "harmonic-minor",
		numerals: [
			"i",
			"VII",
			"VI",
			"V"
		]
	},
	{
		id: "ballad",
		name: "Ballad",
		hint: "i–VI–iv–V",
		scale: "harmonic-minor",
		numerals: [
			"i",
			"VI",
			"iv",
			"V"
		]
	},
	{
		id: "folk-min",
		name: "Folk minor",
		hint: "i–iv–VII–III",
		scale: "minor",
		numerals: [
			"i",
			"iv",
			"VII",
			"III"
		]
	},
	{
		id: "blues",
		name: "12-bar",
		hint: "I7–IV7–V7",
		scale: "major",
		numerals: [
			"I7",
			"I7",
			"I7",
			"I7",
			"IV7",
			"IV7",
			"I7",
			"I7",
			"V7",
			"IV7",
			"I7",
			"V7"
		]
	},
	{
		id: "amen",
		name: "Amen",
		hint: "IV–I",
		scale: "major",
		numerals: ["IV", "I"]
	}
];
function slotsFromNumerals(numerals, beats = 4) {
	return numerals.map((numeral, i) => ({
		id: `slot-${i}-${numeral}`,
		numeral,
		beats
	}));
}
function keyLabel(pc) {
	return CHROMATIC_KEYS.find((k) => k.pc === pc)?.label ?? "C";
}
function scaleName(id) {
	return SCALES.find((s) => s.id === id)?.name ?? "Major";
}
function newSlotId() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `slot-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}
var DEFAULT_SLOTS = [
	{
		id: "s1",
		numeral: "I",
		beats: 4
	},
	{
		id: "s2",
		numeral: "V",
		beats: 4
	},
	{
		id: "s3",
		numeral: "vi",
		beats: 4
	},
	{
		id: "s4",
		numeral: "IV",
		beats: 4
	}
];
var STORAGE_KEY = "cadence-player-v1";
function persist(state) {
	if (typeof window === "undefined" || !state.hydrated) return;
	const data = {
		keyPc: state.keyPc,
		scale: state.scale,
		slots: state.slots,
		sevenths: state.sevenths,
		instrument: state.instrument,
		pattern: state.pattern,
		bpm: state.bpm,
		loop: state.loop,
		volume: state.volume,
		metronome: state.metronome
	};
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
	} catch {}
}
var usePlayerStore = create((set, get) => ({
	hydrated: false,
	keyPc: 0,
	scale: "major",
	slots: DEFAULT_SLOTS,
	sevenths: false,
	instrument: "keys",
	pattern: "strum",
	bpm: 96,
	loop: true,
	volume: .72,
	metronome: false,
	playing: false,
	activeIndex: 0,
	selectedIndex: 0,
	playGen: 0,
	hydrate: () => {
		if (typeof window === "undefined") return;
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const data = JSON.parse(raw);
				set({
					keyPc: typeof data.keyPc === "number" ? data.keyPc : 0,
					scale: data.scale ?? "major",
					slots: Array.isArray(data.slots) && data.slots.length > 0 ? data.slots : DEFAULT_SLOTS,
					sevenths: Boolean(data.sevenths),
					instrument: data.instrument === "nylon" ? "nylon" : "keys",
					pattern: data.pattern ?? "strum",
					bpm: typeof data.bpm === "number" ? Math.min(180, Math.max(60, data.bpm)) : 96,
					loop: data.loop !== false,
					volume: typeof data.volume === "number" ? data.volume : .72,
					metronome: Boolean(data.metronome),
					hydrated: true
				});
				return;
			}
		} catch {}
		set({ hydrated: true });
	},
	persistable: () => {
		const s = get();
		return {
			keyPc: s.keyPc,
			scale: s.scale,
			slots: s.slots,
			sevenths: s.sevenths,
			instrument: s.instrument,
			pattern: s.pattern,
			bpm: s.bpm,
			loop: s.loop,
			volume: s.volume,
			metronome: s.metronome
		};
	},
	resolved: () => {
		const s = get();
		return resolveProgression(s.slots, s.keyPc, s.scale, s.sevenths, s.instrument);
	},
	setKey: (pc) => set({ keyPc: pc }),
	setScale: (scale) => set({ scale }),
	setPattern: (pattern) => set({ pattern }),
	setInstrument: (instrument) => set({ instrument }),
	setBpm: (bpm) => set({ bpm: Math.min(180, Math.max(60, Math.round(bpm))) }),
	setVolume: (volume) => set({ volume: Math.min(1, Math.max(0, volume)) }),
	setLoop: (loop) => set({ loop }),
	setMetronome: (metronome) => set({ metronome }),
	setSevenths: (sevenths) => set({ sevenths }),
	setPlaying: (playing) => set({
		playing,
		playGen: playing ? get().playGen + 1 : get().playGen
	}),
	setActiveIndex: (index) => set({ activeIndex: index }),
	selectIndex: (index) => set({ selectedIndex: index }),
	advanceTo: (index) => set({
		activeIndex: index,
		playGen: get().playGen + 1
	}),
	bumpPlay: () => set({ playGen: get().playGen + 1 }),
	applyPreset: (id) => {
		const preset = PRESETS.find((p) => p.id === id);
		if (!preset) return;
		set({
			scale: preset.scale,
			slots: slotsFromNumerals(preset.numerals, 4),
			selectedIndex: 0,
			activeIndex: 0
		});
	},
	addChord: (numeral) => {
		const s = get();
		const beats = s.slots[s.selectedIndex]?.beats ?? 4;
		const next = [...s.slots, {
			id: newSlotId(),
			numeral,
			beats
		}];
		set({
			slots: next,
			selectedIndex: next.length - 1
		});
	},
	setSlotNumeral: (index, numeral) => {
		set({ slots: get().slots.map((slot, i) => i === index ? {
			...slot,
			numeral
		} : slot) });
	},
	setSlotBeats: (index, beats) => {
		set({ slots: get().slots.map((slot, i) => i === index ? {
			...slot,
			beats
		} : slot) });
	},
	removeSlot: (index) => {
		const slots = get().slots.filter((_, i) => i !== index);
		if (slots.length === 0) {
			set({
				slots: [{
					id: newSlotId(),
					numeral: "I",
					beats: 4
				}],
				selectedIndex: 0,
				activeIndex: 0
			});
			return;
		}
		set({
			slots,
			selectedIndex: Math.min(get().selectedIndex, slots.length - 1),
			activeIndex: Math.min(get().activeIndex, slots.length - 1)
		});
	},
	moveSlot: (from, to) => {
		const slots = [...get().slots];
		if (from < 0 || to < 0 || from >= slots.length || to >= slots.length) return;
		const [item] = slots.splice(from, 1);
		slots.splice(to, 0, item);
		set({
			slots,
			selectedIndex: to
		});
	},
	duplicateSlot: (index) => {
		const slots = [...get().slots];
		const src = slots[index];
		if (!src) return;
		slots.splice(index + 1, 0, {
			...src,
			id: newSlotId()
		});
		set({
			slots,
			selectedIndex: index + 1
		});
	},
	setDefaultBeats: (beats) => {
		set({ slots: get().slots.map((s) => ({
			...s,
			beats
		})) });
	}
}));
if (typeof window !== "undefined") {
	let last = "";
	usePlayerStore.subscribe((state) => {
		const next = JSON.stringify(state.persistable());
		if (next === last) return;
		last = next;
		persist(state);
	});
}
function ChordStage({ chords, bpm, pattern, instrument }) {
	const playing = usePlayerStore((s) => s.playing);
	const activeIndex = usePlayerStore((s) => s.activeIndex);
	const selectedIndex = usePlayerStore((s) => s.selectedIndex);
	const playGen = usePlayerStore((s) => s.playGen);
	const selectIndex = usePlayerStore((s) => s.selectIndex);
	const moveSlot = usePlayerStore((s) => s.moveSlot);
	const removeSlot = usePlayerStore((s) => s.removeSlot);
	const duplicateSlot = usePlayerStore((s) => s.duplicateSlot);
	const scroller = (0, import_react.useRef)(null);
	const [dragFrom, setDragFrom] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		(scroller.current?.querySelector(`[data-chord="${activeIndex}"]`))?.scrollIntoView({
			behavior: "smooth",
			inline: "center",
			block: "nearest"
		});
	}, [activeIndex]);
	const current = chords[playing ? activeIndex : selectedIndex] ?? chords[0];
	function onChordClick(index) {
		selectIndex(index);
		if (!playing) {
			const chord = chords[index];
			if (chord) getAudioEngine().resume().then(() => {
				getAudioEngine().preview(chord, pattern, bpm, instrument);
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "min-w-0 rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Progression"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-2xl leading-tight italic text-foreground sm:text-3xl",
					children: current ? current.symbol : "—"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground tabular-nums",
					children: [
						chords.length,
						" bar",
						chords.length === 1 ? "" : "s"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scroller,
				className: "staff-lines -mx-1 flex max-w-full snap-x snap-mandatory gap-2 overflow-x-auto px-1 py-2 pb-3 [scrollbar-width:thin]",
				children: chords.map((chord, index) => {
					const active = index === activeIndex && playing;
					const selected = index === selectedIndex;
					const duration = chord.beats * 60 / bpm;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"data-chord": index,
						draggable: true,
						onDragStart: () => setDragFrom(index),
						onDragOver: (e) => e.preventDefault(),
						onDrop: () => {
							if (dragFrom != null) moveSlot(dragFrom, index);
							setDragFrom(null);
						},
						onClick: () => onChordClick(index),
						className: cn("relative w-28 shrink-0 snap-start overflow-hidden rounded-md bg-surface-2 p-3 text-left transition-[box-shadow,background-color,transform] duration-150 ease-out sm:w-32", "shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]", selected && "ring-1 ring-foreground/25", active && "bg-secondary ring-1 ring-primary"),
						children: [
							active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "animate-playhead pointer-events-none absolute inset-0 origin-left bg-primary/20",
								style: { animationDuration: `${duration}s` }
							}, playGen),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-serif text-2xl leading-none italic sm:text-3xl",
									children: chord.numeral
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "size-3.5 text-subtle opacity-50" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "relative mt-2 block text-sm text-muted-foreground",
								children: chord.symbol
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "relative mt-3 flex gap-1",
								children: Array.from({ length: chord.beats }).map((_, b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1 w-3 rounded-full", active ? "bg-primary" : "bg-foreground/20") }, b))
							})
						]
					}, chord.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PianoStrip, {
				activePcs: current?.midi ?? [],
				className: "mt-1 overflow-hidden rounded-md"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: () => moveSlot(selectedIndex, Math.max(0, selectedIndex - 1)),
						disabled: selectedIndex <= 0,
						"aria-label": "Move chord earlier",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: () => moveSlot(selectedIndex, Math.min(chords.length - 1, selectedIndex + 1)),
						disabled: selectedIndex >= chords.length - 1,
						"aria-label": "Move chord later",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						onClick: () => duplicateSlot(selectedIndex),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Duplicate"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						onClick: () => removeSlot(selectedIndex),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Remove"]
					})
				]
			})
		]
	});
}
function Chip({ active, onClick, children, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		title,
		onClick,
		className: cn("h-10 min-w-10 rounded-full px-3 text-sm font-medium transition-[background-color,color] duration-150", active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"),
		children
	});
}
function StudioControls({ keyPc, scale, sevenths, presetHint, onKey, onScale, onSevenths, onPreset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: "Key"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: CHROMATIC_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: k.pc === keyPc,
					onClick: () => onKey(k.pc),
					children: k.label
				}, k.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: "Scale"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5",
				children: [SCALES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: s.id === scale,
					onClick: () => onScale(s.id),
					children: s.name
				}, s.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: sevenths,
					onClick: () => onSevenths(!sevenths),
					children: "7ths"
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Presets"
				}), presetHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: presetHint
				}) : null]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: false,
					title: p.hint,
					onClick: () => onPreset(p.id),
					children: p.name
				}, p.id))
			})] })
		]
	});
}
function ChordPalette({ diatonic, borrowed, onAdd, onReplace }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Add or replace"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: "Tap a chord to swap the selected bar"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7",
				children: diatonic.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaletteButton, {
					chord: c,
					onAdd,
					onReplace
				}, c.numeral))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: "Borrowed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: borrowed.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaletteButton, {
					chord: c,
					onAdd,
					onReplace,
					compact: true
				}, c.numeral))
			})
		]
	});
}
function PaletteButton({ chord, onAdd, onReplace, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative min-w-0 rounded-md bg-surface-2 shadow-[var(--shadow-border)]", compact && "min-w-20"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onReplace(chord.numeral),
			className: cn("w-full px-3 py-2 pr-10 text-left hover:bg-secondary", compact ? "min-h-11" : "min-h-16"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-serif text-lg leading-none italic",
				children: chord.numeral
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs text-muted-foreground",
				children: chord.symbol
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onAdd(chord.numeral),
			className: "absolute top-1 right-1 flex size-8 items-center justify-center rounded-sm text-muted-foreground hover:bg-secondary hover:text-foreground",
			"aria-label": `Add ${chord.symbol}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
		})]
	});
}
function BeatsEditor({ beats, onChange, onApplyAll }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
			children: "Beats for selected chord"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-1.5",
			children: [[
				1,
				2,
				3,
				4,
				8
			].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				active: beats === n,
				onClick: () => onChange(n),
				children: n
			}, n)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onApplyAll(beats),
				className: "h-10 rounded-full px-3 text-xs font-medium text-muted-foreground hover:text-foreground",
				children: "Apply to all"
			})]
		})]
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-secondary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-primary shadow-[var(--shadow-border)] ring-offset-background transition-[box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70" })]
	});
}
function Transport({ playing, loop, bpm, volume, metronome, pattern, instrument, onTogglePlay, onStop, onLoop, onBpm, onVolume, onMetronome, onPattern, onInstrument }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "fixed inset-x-0 bottom-0 z-20 overflow-x-hidden border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full min-w-0 max-w-6xl flex-col gap-3 px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-2 overflow-x-auto [scrollbar-width:none]",
				children: PATTERNS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onPattern(p.id),
					className: cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium transition-[background-color,color] duration-150", pattern === p.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"),
					children: p.name
				}, p.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "lg",
								onClick: onTogglePlay,
								className: "min-w-24",
								"aria-label": playing ? "Pause" : "Play",
								children: [playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 ml-0.5" }), playing ? "Pause" : "Play"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "secondary",
								size: "icon",
								onClick: onStop,
								"aria-label": "Stop",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4 fill-current" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: loop ? "default" : "secondary",
								size: "icon",
								onClick: () => onLoop(!loop),
								"aria-label": loop ? "Disable loop" : "Enable loop",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, {})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "w-14 shrink-0 text-xs font-medium text-muted-foreground tabular-nums",
							children: [bpm, " BPM"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							value: [bpm],
							min: 60,
							max: 180,
							step: 1,
							onValueChange: (v) => onBpm(v[0] ?? bpm)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden min-w-0 items-center gap-2 sm:flex sm:w-36",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4 shrink-0 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							value: [Math.round(volume * 100)],
							min: 0,
							max: 100,
							step: 1,
							onValueChange: (v) => onVolume((v[0] ?? 72) / 100)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-1 sm:ml-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onInstrument("keys"),
								className: cn("h-9 rounded-full px-3 text-xs font-medium", instrument === "keys" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
								children: "Keys"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onInstrument("nylon"),
								className: cn("h-9 rounded-full px-3 text-xs font-medium", instrument === "nylon" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
								children: "Nylon"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onMetronome(!metronome),
								className: cn("h-9 rounded-full px-3 text-xs font-medium", metronome ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
								children: "Click"
							})
						]
					})
				]
			})]
		})
	});
}
var TooltipProvider = Provider;
function CadenceApp() {
	const hydrate = usePlayerStore((s) => s.hydrate);
	const keyPc = usePlayerStore((s) => s.keyPc);
	const scale = usePlayerStore((s) => s.scale);
	const slots = usePlayerStore((s) => s.slots);
	const sevenths = usePlayerStore((s) => s.sevenths);
	const instrument = usePlayerStore((s) => s.instrument);
	const pattern = usePlayerStore((s) => s.pattern);
	const bpm = usePlayerStore((s) => s.bpm);
	const loop = usePlayerStore((s) => s.loop);
	const volume = usePlayerStore((s) => s.volume);
	const metronome = usePlayerStore((s) => s.metronome);
	const playing = usePlayerStore((s) => s.playing);
	const selectedIndex = usePlayerStore((s) => s.selectedIndex);
	const activeIndex = usePlayerStore((s) => s.activeIndex);
	const setKey = usePlayerStore((s) => s.setKey);
	const setScale = usePlayerStore((s) => s.setScale);
	const setSevenths = usePlayerStore((s) => s.setSevenths);
	const applyPreset = usePlayerStore((s) => s.applyPreset);
	const addChord = usePlayerStore((s) => s.addChord);
	const setSlotNumeral = usePlayerStore((s) => s.setSlotNumeral);
	const setSlotBeats = usePlayerStore((s) => s.setSlotBeats);
	const setDefaultBeats = usePlayerStore((s) => s.setDefaultBeats);
	const setPattern = usePlayerStore((s) => s.setPattern);
	const setInstrument = usePlayerStore((s) => s.setInstrument);
	const setBpm = usePlayerStore((s) => s.setBpm);
	const setVolume = usePlayerStore((s) => s.setVolume);
	const setLoop = usePlayerStore((s) => s.setLoop);
	const setMetronome = usePlayerStore((s) => s.setMetronome);
	const setPlaying = usePlayerStore((s) => s.setPlaying);
	const advanceTo = usePlayerStore((s) => s.advanceTo);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const engine = getAudioEngine();
		engine.setGetter(() => {
			const s = usePlayerStore.getState();
			return {
				chords: resolveProgression(s.slots, s.keyPc, s.scale, s.sevenths, s.instrument),
				bpm: s.bpm,
				pattern: s.pattern,
				instrument: s.instrument,
				loop: s.loop,
				volume: s.volume,
				metronome: s.metronome
			};
		});
		engine.setCallbacks({
			onChord: (index) => advanceTo(index),
			onStop: () => setPlaying(false)
		});
	}, [advanceTo, setPlaying]);
	(0, import_react.useEffect)(() => {
		getAudioEngine().setVolume(volume);
	}, [volume]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			const el = e.target;
			if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable)) return;
			if (e.code === "Space") {
				e.preventDefault();
				const engine = getAudioEngine();
				const s = usePlayerStore.getState();
				if (s.playing) {
					engine.stop();
					s.setPlaying(false);
					return;
				}
				engine.resume().then(() => {
					const next = usePlayerStore.getState();
					next.setPlaying(true);
					engine.start(next.activeIndex);
				});
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const chords = resolveProgression(slots, keyPc, scale, sevenths, instrument);
	const diatonic = diatonicPalette(keyPc, scale, sevenths);
	const borrowed = borrowedPalette(keyPc, scale, sevenths);
	const selected = slots[selectedIndex] ?? slots[0];
	const presetHint = PRESETS.find((p) => p.scale === scale && p.numerals.join() === slots.map((s) => s.numeral).join())?.hint ?? null;
	async function togglePlay() {
		const engine = getAudioEngine();
		const s = usePlayerStore.getState();
		if (s.playing) {
			engine.stop();
			s.setPlaying(false);
			return;
		}
		await engine.resume();
		s.setPlaying(true);
		engine.start(s.activeIndex);
	}
	function stop() {
		getAudioEngine().stop();
		const s = usePlayerStore.getState();
		s.setPlaying(false);
		s.setActiveIndex(0);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 250,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-dvh overflow-x-hidden bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 pt-6 pb-4 sm:pt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-[0.18em] text-muted-foreground uppercase",
							children: "Studio"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-serif text-4xl leading-none italic sm:text-5xl",
							children: "Cadence"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-serif text-lg italic sm:text-2xl",
								children: [
									keyLabel(keyPc),
									" ",
									scaleName(scale)
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground tabular-nums",
								children: [
									bpm,
									" BPM · ",
									playing ? `bar ${activeIndex + 1}` : "ready"
								]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-md text-sm text-muted-foreground text-pretty",
						children: "Hear the changes. Loop a progression, swap voicings, and write the next song."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto grid w-full min-w-0 max-w-6xl gap-4 px-4 pb-44 lg:grid-cols-[minmax(0,280px)_minmax(0,1fr)] lg:gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "order-2 rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-4 lg:order-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioControls, {
							keyPc,
							scale,
							sevenths,
							presetHint,
							onKey: setKey,
							onScale: setScale,
							onSevenths: setSevenths,
							onPreset: applyPreset
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "order-1 space-y-4 lg:order-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChordStage, {
								chords,
								bpm,
								pattern,
								instrument
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChordPalette, {
								diatonic,
								borrowed,
								onAdd: addChord,
								onReplace: (numeral) => setSlotNumeral(selectedIndex, numeral)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BeatsEditor, {
								beats: selected?.beats ?? 4,
								onChange: (beats) => setSlotBeats(selectedIndex, beats),
								onApplyAll: setDefaultBeats
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transport, {
					playing,
					loop,
					bpm,
					volume,
					metronome,
					pattern,
					instrument,
					onTogglePlay: () => void togglePlay(),
					onStop: stop,
					onLoop: setLoop,
					onBpm: setBpm,
					onVolume: setVolume,
					onMetronome: setMetronome,
					onPattern: setPattern,
					onInstrument: setInstrument
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CadenceApp, {});
}
//#endregion
export { Home as component };
