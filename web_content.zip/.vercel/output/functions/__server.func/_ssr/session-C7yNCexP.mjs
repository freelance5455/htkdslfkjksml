//#region node_modules/.nitro/vite/services/ssr/assets/session-C7yNCexP.js
var CELL$1 = 3.05;
var WALL_T = .52;
var WALL_H = 2.48;
var PLAYER_R = .32;
var YAW = {
	n: 0,
	e: -Math.PI / 2,
	s: Math.PI,
	w: Math.PI / 2
};
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function shuffle(arr, rand) {
	for (let i = arr.length - 1; i > 0; i--) {
		const j = rand() * (i + 1) | 0;
		const tmp = arr[i];
		arr[i] = arr[j];
		arr[j] = tmp;
	}
	return arr;
}
function idx(c, r) {
	return r * 11 + c;
}
function openBetween(cells, i, j, dir) {
	const a = cells[i];
	const b = cells[j];
	if (dir === "n") {
		a.n = false;
		b.s = false;
	} else if (dir === "s") {
		a.s = false;
		b.n = false;
	} else if (dir === "e") {
		a.e = false;
		b.w = false;
	} else {
		a.w = false;
		b.e = false;
	}
}
function passageLength(cells, index, dir) {
	let len = 0;
	let i = index;
	while (len < 40) {
		const c = i % 11;
		const r = Math.floor(i / 11);
		const cell = cells[i];
		if (dir === "n") {
			if (cell.n || r === 0) break;
			i -= 11;
		} else if (dir === "s") {
			if (cell.s || r === 10) break;
			i += 11;
		} else if (dir === "w") {
			if (cell.w || c === 0) break;
			i -= 1;
		} else {
			if (cell.e || c === 10) break;
			i += 1;
		}
		len++;
	}
	return len;
}
function farthest(cells, start) {
	const dist = new Int16Array(cells.length).fill(-1);
	const q = [start];
	dist[start] = 0;
	let far = start;
	let qi = 0;
	while (qi < q.length) {
		const i = q[qi++];
		if (dist[i] > dist[far]) far = i;
		const c = i % 11;
		const r = Math.floor(i / 11);
		const cell = cells[i];
		const step = (ni) => {
			if (dist[ni] !== -1) return;
			dist[ni] = dist[i] + 1;
			q.push(ni);
		};
		if (!cell.n && r > 0) step(i - 11);
		if (!cell.s && r < 10) step(i + 11);
		if (!cell.w && c > 0) step(i - 1);
		if (!cell.e && c < 10) step(i + 1);
	}
	return {
		far,
		dist
	};
}
function horizontalWall(cells, c, edge) {
	if (edge === 0) return cells[c].n;
	if (edge === 11) return cells[110 + c].s;
	return cells[edge * 11 + c].n;
}
function verticalWall(cells, edge, r) {
	if (edge === 0) return cells[r * 11].w;
	if (edge === 11) return cells[r * 11 + 11 - 1].e;
	return cells[r * 11 + edge].w;
}
function pushBox(walls, cx, cz, sx, sz) {
	walls.push({
		minX: cx - sx / 2,
		maxX: cx + sx / 2,
		minZ: cz - sz / 2,
		maxZ: cz + sz / 2
	});
}
function buildWalls(cells) {
	const walls = [];
	for (let edge = 0; edge <= 11; edge++) {
		let c = 0;
		while (c < 11) {
			if (!horizontalWall(cells, c, edge)) {
				c++;
				continue;
			}
			let end = c;
			while (end + 1 < 11 && horizontalWall(cells, end + 1, edge)) end++;
			const x0 = c * CELL$1;
			const x1 = (end + 1) * CELL$1;
			pushBox(walls, (x0 + x1) / 2, edge * CELL$1, x1 - x0, WALL_T);
			c = end + 1;
		}
	}
	for (let edge = 0; edge <= 11; edge++) {
		let r = 0;
		while (r < 11) {
			if (!verticalWall(cells, edge, r)) {
				r++;
				continue;
			}
			let end = r;
			while (end + 1 < 11 && verticalWall(cells, edge, end + 1)) end++;
			const z0 = r * CELL$1;
			const z1 = (end + 1) * CELL$1;
			pushBox(walls, edge * CELL$1, (z0 + z1) / 2, WALL_T, z1 - z0);
			r = end + 1;
		}
	}
	return walls;
}
function centerOf(i) {
	const c = i % 11;
	const r = Math.floor(i / 11);
	return {
		c,
		r,
		x: (c + .5) * CELL$1,
		z: (r + .5) * CELL$1
	};
}
function wallCount(cell) {
	return Number(cell.n) + Number(cell.e) + Number(cell.s) + Number(cell.w);
}
function generateMaze(seed) {
	const rand = mulberry32(seed || 1);
	const cells = Array.from({ length: 121 }, () => ({
		n: true,
		e: true,
		s: true,
		w: true
	}));
	const seen = new Uint8Array(cells.length);
	const stack = [0];
	seen[0] = 1;
	while (stack.length) {
		const i = stack[stack.length - 1];
		const c = i % 11;
		const r = Math.floor(i / 11);
		const neigh = [];
		if (r > 0 && !seen[i - 11]) neigh.push({
			i: i - 11,
			dir: "n"
		});
		if (r < 10 && !seen[i + 11]) neigh.push({
			i: i + 11,
			dir: "s"
		});
		if (c > 0 && !seen[i - 1]) neigh.push({
			i: i - 1,
			dir: "w"
		});
		if (c < 10 && !seen[i + 1]) neigh.push({
			i: i + 1,
			dir: "e"
		});
		if (!neigh.length) {
			stack.pop();
			continue;
		}
		const pick = neigh[rand() * neigh.length | 0];
		openBetween(cells, i, pick.i, pick.dir);
		seen[pick.i] = 1;
		stack.push(pick.i);
	}
	for (let r = 0; r < 11; r++) for (let c = 0; c < 11; c++) {
		const i = idx(c, r);
		if (c < 10 && cells[i].e && rand() < .14) openBetween(cells, i, i + 1, "e");
		if (r < 10 && cells[i].s && rand() < .14) openBetween(cells, i, i + 11, "s");
	}
	let bestI = 0;
	let bestDir = "s";
	let bestLen = -1;
	const dirs = [
		"n",
		"e",
		"s",
		"w"
	];
	for (let i = 0; i < cells.length; i++) for (const dir of dirs) {
		const len = passageLength(cells, i, dir);
		if (len > bestLen) {
			bestLen = len;
			bestI = i;
			bestDir = dir;
		}
	}
	const start = centerOf(bestI);
	const { far, dist } = farthest(cells, bestI);
	const exit = centerOf(far);
	const dead = [];
	const other = [];
	for (let i = 0; i < cells.length; i++) {
		if (i === bestI || i === far) continue;
		if (dist[i] < 2) continue;
		if (wallCount(cells[i]) >= 3) dead.push(i);
		else if (dist[i] >= 4) other.push(i);
	}
	shuffle(dead, rand);
	shuffle(other, rand);
	const gemIdx = [...dead, ...other].slice(0, 9);
	const gems = gemIdx.map((i) => {
		const p = centerOf(i);
		return {
			x: p.x,
			z: p.z
		};
	});
	const taken = /* @__PURE__ */ new Set([
		bestI,
		far,
		...gemIdx
	]);
	const flowers = [];
	for (let i = 0; i < cells.length && flowers.length < 8; i++) {
		if (taken.has(i) || rand() > .22) continue;
		const cell = cells[i];
		const p = centerOf(i);
		const options = [];
		const d = .92;
		if (cell.n) options.push([0, -.92]);
		if (cell.s) options.push([0, d]);
		if (cell.w) options.push([-.92, 0]);
		if (cell.e) options.push([d, 0]);
		if (!options.length) continue;
		const off = options[rand() * options.length | 0];
		flowers.push({
			x: p.x + off[0],
			z: p.z + off[1],
			kind: rand() * 3 | 0
		});
		taken.add(i);
	}
	const trees = [];
	const W = 11 * CELL$1;
	const H = 11 * CELL$1;
	for (let k = 0; k < 14; k++) {
		const side = k % 4;
		const t = rand();
		let x = 0;
		let z = 0;
		const out = 2.15 + rand() * 1.7;
		if (side === 0) {
			x = -out;
			z = t * H;
		} else if (side === 1) {
			x = W + out;
			z = t * H;
		} else if (side === 2) {
			x = t * W;
			z = -out;
		} else {
			x = t * W;
			z = H + out;
		}
		trees.push({
			x,
			z,
			h: 1.5 + rand() * 1.5,
			r: .55 + rand() * .4
		});
	}
	const flies = [];
	for (let n = 0; n < 16; n++) {
		const p = centerOf(rand() * cells.length | 0);
		flies.push({
			x: p.x + (rand() - .5) * .8,
			y: 1.15 + rand() * .9,
			z: p.z + (rand() - .5) * .8,
			phase: rand() * Math.PI * 2
		});
	}
	return {
		cells,
		walls: buildWalls(cells),
		gems,
		flowers,
		trees,
		flies,
		startX: start.x,
		startZ: start.z,
		yaw: YAW[bestDir],
		exitX: exit.x,
		exitZ: exit.z,
		exitC: exit.c,
		exitR: exit.r
	};
}
var SKIN = .018;
function resolveCircle(x, z, r, walls) {
	let px = x;
	let pz = z;
	for (let pass = 0; pass < 4; pass++) for (const b of walls) {
		if (px > b.maxX + r || px < b.minX - r || pz > b.maxZ + r || pz < b.minZ - r) continue;
		const cx = Math.min(Math.max(px, b.minX), b.maxX);
		const cz = Math.min(Math.max(pz, b.minZ), b.maxZ);
		let dx = px - cx;
		let dz = pz - cz;
		const d2 = dx * dx + dz * dz;
		if (d2 >= r * r) continue;
		if (d2 > 1e-10) {
			const d = Math.sqrt(d2);
			const push = r - d + SKIN;
			px += dx / d * push;
			pz += dz / d * push;
		} else {
			const left = px - b.minX;
			const right = b.maxX - px;
			const north = pz - b.minZ;
			const south = b.maxZ - pz;
			const m = Math.min(left, right, north, south);
			if (m === left) px = b.minX - r - SKIN;
			else if (m === right) px = b.maxX + r + SKIN;
			else if (m === north) pz = b.minZ - r - SKIN;
			else pz = b.maxZ + r + SKIN;
		}
	}
	return {
		x: px,
		z: pz
	};
}
function circleHits(x, z, r, walls) {
	const pad = r - .001;
	for (const b of walls) {
		if (x > b.maxX + pad || x < b.minX - pad || z > b.maxZ + pad || z < b.minZ - pad) continue;
		const cx = Math.min(Math.max(x, b.minX), b.maxX);
		const cz = Math.min(Math.max(z, b.minZ), b.maxZ);
		const dx = x - cx;
		const dz = z - cz;
		if (dx * dx + dz * dz < pad * pad) return true;
	}
	return false;
}
function cellOf(x, z) {
	return {
		c: Math.min(10, Math.max(0, Math.floor(x / CELL$1))),
		r: Math.min(10, Math.max(0, Math.floor(z / CELL$1)))
	};
}
/** Basis: yaw 0 looks toward world −Z. +yaw is CCW about +Y. */
function basis(yaw) {
	return {
		fx: -Math.sin(yaw),
		fz: -Math.cos(yaw),
		rx: Math.cos(yaw),
		rz: -Math.sin(yaw)
	};
}
var ctx = null;
var muted = false;
var stepBuf = null;
function unlockAudio() {
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return;
	if (!ctx) ctx = new AC();
	if (ctx.state === "suspended") ctx.resume();
}
function tone(freq, when, dur, type, gain) {
	if (!ctx || muted) return;
	const o = ctx.createOscillator();
	const g = ctx.createGain();
	o.type = type;
	o.frequency.setValueAtTime(freq, when);
	g.gain.setValueAtTime(1e-4, when);
	g.gain.exponentialRampToValueAtTime(gain, when + .015);
	g.gain.exponentialRampToValueAtTime(1e-4, when + dur);
	o.connect(g);
	g.connect(ctx.destination);
	o.start(when);
	o.stop(when + dur + .02);
}
function playCollect() {
	if (!ctx || muted) return;
	const now = ctx.currentTime;
	tone(784, now, .12, "triangle", .06);
	tone(1046, now + .06, .14, "triangle", .05);
	tone(1568, now + .12, .18, "sine", .04);
}
function playWin() {
	if (!ctx || muted) return;
	const now = ctx.currentTime;
	[
		523,
		659,
		784,
		1046
	].forEach((freq, i) => {
		tone(freq, now + i * .09, .28, "triangle", .07);
	});
	tone(784, now + .42, .4, "sine", .05);
}
function playStep() {
	if (!ctx || muted) return;
	if (!stepBuf) {
		stepBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * .045), ctx.sampleRate);
		const data = stepBuf.getChannelData(0);
		for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
	}
	const src = ctx.createBufferSource();
	src.buffer = stepBuf;
	const filter = ctx.createBiquadFilter();
	filter.type = "lowpass";
	filter.frequency.value = 420 + Math.random() * 180;
	const g = ctx.createGain();
	g.gain.value = .035;
	src.connect(filter);
	filter.connect(g);
	g.connect(ctx.destination);
	src.start();
	src.playbackRate.value = .9 + Math.random() * .25;
}
var BEST_KEY = "lantern-grove-best-ms";
var STEP = 1 / 60;
var WALK = 4.35;
var SPRINT = 6.7;
function readBest() {
	try {
		const raw = localStorage.getItem(BEST_KEY);
		if (!raw) return null;
		const n = Number(raw);
		return Number.isFinite(n) ? n : null;
	} catch {
		return null;
	}
}
function writeBest(ms) {
	try {
		localStorage.setItem(BEST_KEY, String(Math.round(ms)));
	} catch {}
}
var session = {
	phase: "menu",
	realKeys: /* @__PURE__ */ new Set(),
	forced: null,
	particles: [],
	got: [],
	explored: /* @__PURE__ */ new Uint8Array(121)
};
var snap = {
	version: 0,
	phase: "menu",
	seed: 0,
	collected: 0,
	total: 0,
	timeMs: 0,
	bestMs: null,
	isNewBest: false,
	exploreGen: 0,
	muted: false
};
var listeners = /* @__PURE__ */ new Set();
var queued = false;
function publish() {
	session.version += 1;
	snap = {
		version: session.version,
		phase: session.phase,
		seed: session.seed,
		collected: session.collected,
		total: session.gems.length,
		timeMs: session.timeMs,
		bestMs: session.bestMs,
		isNewBest: session.isNewBest,
		exploreGen: session.exploreGen,
		muted: session.muted
	};
	if (queued) return;
	queued = true;
	queueMicrotask(() => {
		queued = false;
		for (const fn of listeners) fn();
	});
}
function subscribe(fn) {
	listeners.add(fn);
	return () => listeners.delete(fn);
}
function getSnap() {
	return snap;
}
function randomSeed() {
	return Math.random() * 2147483647 | 0;
}
function reveal(c, r) {
	if (c < 0 || r < 0 || c >= 11 || r >= 11) return false;
	const i = r * 11 + c;
	if (session.explored[i]) return false;
	session.explored[i] = 1;
	return true;
}
function revealVisible(c, r) {
	let changed = reveal(c, r);
	if (c < 0 || r < 0 || c >= 11 || r >= 11) return changed;
	const cell = session.cells[r * 11 + c];
	if (!cell) return changed;
	if (!cell.n) changed = reveal(c, r - 1) || changed;
	if (!cell.s) changed = reveal(c, r + 1) || changed;
	if (!cell.w) changed = reveal(c - 1, r) || changed;
	if (!cell.e) changed = reveal(c + 1, r) || changed;
	return changed;
}
function loadRun(seed) {
	const world = generateMaze(seed);
	session.seed = seed;
	session.cells = world.cells;
	session.walls = world.walls;
	session.gems = world.gems;
	session.flowers = world.flowers;
	session.trees = world.trees;
	session.flies = world.flies;
	session.startX = world.startX;
	session.startZ = world.startZ;
	session.exitX = world.exitX;
	session.exitZ = world.exitZ;
	session.exitC = world.exitC;
	session.exitR = world.exitR;
	session.x = world.startX;
	session.z = world.startZ;
	session.yaw = world.yaw;
	session.pitch = -.06;
	session.vx = 0;
	session.vz = 0;
	session.got = world.gems.map(() => false);
	session.collected = 0;
	session.explored = /* @__PURE__ */ new Uint8Array(121);
	session.exploreGen = 0;
	session.timeMs = 0;
	session.bestMs = readBest();
	session.isNewBest = false;
	session.bob = 0;
	session.bobPhase = 0;
	session.stepMark = 0;
	session.trauma = 0;
	session.particles = [];
	session.realKeys.clear();
	session.forced = null;
	session.touchForward = 0;
	session.touchStrafe = 0;
	session.touchSprint = false;
	session.phase = "menu";
	session.acc = 0;
	const sc = cellOf(world.startX, world.startZ);
	revealVisible(sc.c, sc.r);
	session.exploreGen += 1;
}
function spawnBurst(x, z, count = 12) {
	if (session.reduce) return;
	for (let i = 0; i < count; i++) {
		const a = i / count * Math.PI * 2;
		const sp = 1.3 + Math.random() * 1.5;
		session.particles.push({
			x,
			y: .85,
			z,
			vx: Math.cos(a) * sp,
			vy: 1.6 + Math.random() * 1.8,
			vz: Math.sin(a) * sp,
			life: .5 + Math.random() * .25,
			max: .75,
			color: i % 2 === 0 ? 14904138 : 14916395
		});
	}
	if (session.particles.length > 72) session.particles.splice(0, session.particles.length - 72);
}
function tickParticles(dt) {
	const list = session.particles;
	for (let i = list.length - 1; i >= 0; i--) {
		const p = list[i];
		p.life -= dt;
		if (p.life <= 0) {
			list.splice(i, 1);
			continue;
		}
		p.vy -= 7.2 * dt;
		p.x += p.vx * dt;
		p.y += p.vy * dt;
		p.z += p.vz * dt;
	}
}
function isDown(code) {
	if (session.realKeys.has(code)) return true;
	return session.forced?.includes(code) ?? false;
}
function win() {
	if (session.phase !== "play") return;
	session.phase = "won";
	session.vx = 0;
	session.vz = 0;
	const best = readBest();
	if (best == null || session.timeMs < best) {
		session.isNewBest = true;
		session.bestMs = session.timeMs;
		writeBest(session.timeMs);
	} else {
		session.isNewBest = false;
		session.bestMs = best;
	}
	session.trauma = Math.min(1, session.trauma + .85);
	spawnBurst(session.exitX, session.exitZ, 22);
	playWin();
	document.exitPointerLock?.();
	publish();
}
function simStep(dt) {
	if (session.phase !== "play") return;
	let f = 0;
	let s = 0;
	if (isDown("KeyW") || isDown("ArrowUp")) f += 1;
	if (isDown("KeyS") || isDown("ArrowDown")) f -= 1;
	if (isDown("KeyD") || isDown("ArrowRight")) s += 1;
	if (isDown("KeyA") || isDown("ArrowLeft")) s -= 1;
	f += session.touchForward;
	s += session.touchStrafe;
	const len = Math.hypot(f, s);
	if (len > 1) {
		f /= len;
		s /= len;
	}
	const { fx, fz, rx, rz } = basis(session.yaw);
	const wishX = fx * f + rx * s;
	const wishZ = fz * f + rz * s;
	const speed = isDown("ShiftLeft") || isDown("ShiftRight") || session.touchSprint ? SPRINT : WALK;
	const k = 1 - Math.exp(-16 * dt);
	session.vx += (wishX * speed - session.vx) * k;
	session.vz += (wishZ * speed - session.vz) * k;
	const attemptX = session.vx * dt;
	const attemptZ = session.vz * dt;
	const resolved = resolveCircle(session.x + attemptX, session.z + attemptZ, PLAYER_R, session.walls);
	const movedX = resolved.x - session.x;
	const movedZ = resolved.z - session.z;
	if (Math.abs(attemptX) > 1e-5 && Math.abs(movedX) < Math.abs(attemptX) * .35) session.vx = 0;
	if (Math.abs(attemptZ) > 1e-5 && Math.abs(movedZ) < Math.abs(attemptZ) * .35) session.vz = 0;
	const inner = WALL_T / 2 + PLAYER_R + .01;
	const maxX = 11 * CELL - inner;
	const maxZ = 11 * CELL - inner;
	session.x = Math.min(maxX, Math.max(inner, resolved.x));
	session.z = Math.min(maxZ, Math.max(inner, resolved.z));
	const sp = Math.hypot(session.vx, session.vz);
	if (!session.reduce && sp > .45) session.bobPhase += sp * dt * 2.35;
	const targetBob = !session.reduce && sp > .45 ? Math.sin(session.bobPhase) * .042 : 0;
	session.bob += (targetBob - session.bob) * (1 - Math.exp(-10 * dt));
	if (sp > 1.15 && !session.reduce) {
		const mark = Math.floor(session.bobPhase / Math.PI);
		if (mark !== session.stepMark) {
			session.stepMark = mark;
			playStep();
		}
	}
	const here = cellOf(session.x, session.z);
	if (revealVisible(here.c, here.r)) {
		session.exploreGen += 1;
		publish();
	}
	let picked = false;
	for (let i = 0; i < session.gems.length; i++) {
		if (session.got[i]) continue;
		const g = session.gems[i];
		const dx = g.x - session.x;
		const dz = g.z - session.z;
		if (dx * dx + dz * dz > .6084) continue;
		session.got[i] = true;
		session.collected += 1;
		session.trauma = Math.min(1, session.trauma + .38);
		spawnBurst(g.x, g.z, 14);
		playCollect();
		picked = true;
	}
	if (picked) publish();
	const ex = session.exitX - session.x;
	const ez = session.exitZ - session.z;
	if (ex * ex + ez * ez < 1.1025) win();
	session.timeMs += dt * 1e3;
	if (session.trauma > 0) session.trauma = Math.max(0, session.trauma - dt * 1.7);
}
function frameSim(delta) {
	const dt = Math.min(delta, .1);
	tickParticles(dt);
	if (session.phase !== "play") {
		session.acc = 0;
		return;
	}
	session.acc += dt;
	let guard = 0;
	while (session.acc >= STEP && guard < 5) {
		simStep(STEP);
		session.acc -= STEP;
		guard += 1;
	}
}
function clampPitch() {
	const limit = Math.PI / 2 - .08;
	if (session.pitch > limit) session.pitch = limit;
	if (session.pitch < -limit) session.pitch = -limit;
}
function nudgeLook(dx, dy, sens) {
	session.yaw -= dx * sens;
	session.pitch -= dy * sens;
	clampPitch();
}
function toggleMute() {
	session.muted = !session.muted;
	publish();
}
function startFromMenu() {
	if (session.phase !== "menu") return;
	session.phase = "play";
	session.hadLock = false;
	session.timeMs = 0;
	publish();
}
function resumePlay() {
	if (session.phase !== "pause") return;
	session.phase = "play";
	publish();
}
function pausePlay() {
	if (session.phase !== "play") return;
	session.phase = "pause";
	session.vx = 0;
	session.vz = 0;
	session.touchForward = 0;
	session.touchStrafe = 0;
	session.touchSprint = false;
	publish();
}
function playAgain() {
	loadRun(randomSeed());
	session.phase = "play";
	session.hadLock = false;
	publish();
}
function lockLook() {
	const canvas = session.canvas;
	if (!canvas || session.touch) return;
	const el = canvas;
	try {
		const pending = el.requestPointerLock?.({ unadjustedMovement: true });
		Promise.resolve(pending).catch(() => {
			try {
				canvas.requestPointerLock();
			} catch {}
		});
	} catch {
		try {
			canvas.requestPointerLock();
		} catch {}
	}
}
function onKeyDown(e) {
	session.realKeys.add(e.code);
	if (e.code.startsWith("Arrow")) e.preventDefault();
	if (e.code === "Escape") pausePlay();
	if (e.code === "KeyM") toggleMute();
}
function onKeyUp(e) {
	session.realKeys.delete(e.code);
}
function onMouse(e) {
	if (session.phase !== "play") return;
	if (document.pointerLockElement !== session.canvas) return;
	nudgeLook(e.movementX, e.movementY, .00215);
}
function onLockChange() {
	if (document.pointerLockElement === session.canvas) session.hadLock = true;
	else if (session.hadLock && session.phase === "play") pausePlay();
}
function onBlur() {
	session.realKeys.clear();
	session.touchForward = 0;
	session.touchStrafe = 0;
	session.touchSprint = false;
}
function onVis() {
	if (document.hidden) pausePlay();
}
function attachInput() {
	window.addEventListener("keydown", onKeyDown);
	window.addEventListener("keyup", onKeyUp);
	window.addEventListener("mousemove", onMouse);
	window.addEventListener("blur", onBlur);
	document.addEventListener("pointerlockchange", onLockChange);
	document.addEventListener("visibilitychange", onVis);
}
function detachInput() {
	window.removeEventListener("keydown", onKeyDown);
	window.removeEventListener("keyup", onKeyUp);
	window.removeEventListener("mousemove", onMouse);
	window.removeEventListener("blur", onBlur);
	document.removeEventListener("pointerlockchange", onLockChange);
	document.removeEventListener("visibilitychange", onVis);
}
function attachProbe() {
	window.__controlsTest = {
		getYaw: () => session.yaw,
		getSpeed: () => Math.hypot(session.vx, session.vz),
		getPos: () => ({
			x: session.x,
			z: session.z
		}),
		setKeys: (codes) => {
			session.forced = codes;
		},
		setSteer: () => {},
		placeAt: (x, z) => {
			const p = resolveCircle(x, z, PLAYER_R, session.walls);
			session.x = p.x;
			session.z = p.z;
			session.vx = 0;
			session.vz = 0;
		},
		getPhase: () => session.phase,
		getCollected: () => session.collected,
		getExit: () => ({
			x: session.exitX,
			z: session.exitZ
		}),
		getGems: () => session.gems.filter((_, i) => !session.got[i]),
		insideWall: () => solidHere()
	};
}
loadRun(randomSeed());
publish();
function solidHere() {
	return circleHits(session.x, session.z, PLAYER_R * .96, session.walls);
}
function formatTime(ms) {
	const clamped = Math.max(0, ms);
	const total = Math.floor(clamped / 1e3);
	const m = Math.floor(total / 60);
	const s = total % 60;
	const tenth = Math.floor(clamped % 1e3 / 100);
	return `${m}:${s.toString().padStart(2, "0")}.${tenth}`;
}
function groveCode(seed) {
	return seed.toString(36).toUpperCase().padStart(4, "0");
}
//#endregion
export { cellOf as a, attachInput, attachProbe, detachInput, formatTime, frameSim, getSnap, groveCode, WALL_T as i, lockLook, CELL$1 as n, nudgeLook, playAgain, WALL_H as r, resumePlay, session, startFromMenu, subscribe, unlockAudio as t, toggleMute };
