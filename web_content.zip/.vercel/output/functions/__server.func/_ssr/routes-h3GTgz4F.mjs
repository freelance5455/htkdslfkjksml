import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Menu, c as BookOpen, i as RotateCcw, o as Library, r as Search, s as Check, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-h3GTgz4F.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var unit1_exports = /* @__PURE__ */ __exportAll({
	default: () => unit1_default,
	id: () => "u1",
	learn: () => learn$6,
	lessons: () => lessons$6,
	number: () => 1,
	title: () => title$6,
	vocab: () => vocab$6
});
var title$6 = "Friendship and Cooperation";
var learn$6 = [
	{
		"skill": "Reading",
		"points": [
			"Use pre-reading strategies to predict the content of a text by using prior knowledge and asking questions",
			"Skim a text to have a general idea of it",
			"Deduce the meaning of difficult words from context",
			"Scan to answer short questions",
			"Use critical thinking to respond to the text",
			"Use intensive reading strategies"
		]
	},
	{
		"skill": "Speaking",
		"points": ["Use functional language to make plans"]
	},
	{
		"skill": "Language Practice",
		"points": ["Illustrate the use of “used to” for past habits and routines", "Illustrate the use of prepositions of position"]
	},
	{
		"skill": "Writing",
		"points": [
			"Write a descriptive unified paragraph on a given topic",
			"Write a clear topic sentence",
			"Add adequate supporting details",
			"Write a concluding sentence"
		]
	},
	{
		"skill": "Study Skills",
		"points": ["Prepare an outline for an oral presentation"]
	},
	{
		"skill": "Fun",
		"points": ["Practise tongue twisters to become a more fluent speaker"]
	}
];
var lessons$6 = [
	{
		"id": "1.1",
		"code": "1.1",
		"title": "Reading Comprehension",
		"subtitle": "Friends in Trouble",
		"kind": "reading",
		"blocks": [
			{
				"type": "h",
				"text": "Pre-Reading"
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"How many friends do you have?",
					"Are all friends that we have good and helpful?",
					"In what ways do friends help each other?",
					"Make a list of good qualities that you think a good or an ideal friend should have.",
					"Share your list with your partner."
				]
			},
			{
				"type": "note",
				"text": "Discuss the questions, share your list with a partner, then read the story silently and do Exercise 1."
			},
			{
				"type": "h",
				"text": "Reading Text"
			},
			{
				"type": "p",
				"text": "There lived two close friends, Basit and Raheel, in a village near Hyderabad. In school, they studied together and in the evening both friends enjoyed playing cricket together. On weekends, they usually went to the nearby canal for fishing. Often, they also went on long walks in the nearby forest because they liked listening to the birds chirping, watching the animals at play, and looking at the beautiful flowers. They always enjoyed each other's company. They laughed, joked and had a great time the whole day."
			},
			{
				"type": "p",
				"text": "Basit was a kind and helpful boy by nature. Moreover, his parents had always taught him to be a kind, sympathetic, helpful and sincere person. He behaved very nicely with all his friends, but he had a special place in his heart for Raheel. Basit always helped Raheel with his homework. He was always willing to guide and help him whenever he faced any difficulty or problem. He also happily gave one of his fish to Raheel when he failed to catch any because, luckily, Basit often managed to catch more fish than Raheel. Although Basit was very active and very intelligent, he was not good at climbing trees. Raheel, on the other hand, was very good at climbing trees, as he had a tall tree in his house, which he had been climbing from an early age."
			},
			{
				"type": "p",
				"text": "One day, Raheel and Basit decided to go to the nearby forest to enjoy the natural beauty. Being nature lovers, they kept walking along the path of the forest, all the time talking and enjoying the natural beauty all around them. They were so curious about everything that they just kept on following whatever caught their attention, not realizing that they had wandered deep into the forest. Suddenly, they realized that they had lost their way; they became very worried because their parents and the villagers had often told them about the dangerous beasts living in the forest. However, they decided to remain calm and promised not to leave each other in case of danger."
			},
			{
				"type": "p",
				"text": "They kept walking through the forest, trying to find their way back home. But all their efforts were in vain. All of a sudden, they saw a huge, black bear coming towards them. They got frightened. This is where Raheel showed his selfish nature and said, “Look Basit, we are in great trouble. As I see it, we have only two choices, either we climb on a tree and save ourselves or we start running. Since I am good at climbing, I'm going to climb a tree. As you do not know how to climb, it would be a good idea for you to run as quickly as you can to save your life.”"
			},
			{
				"type": "p",
				"text": "Basit was extremely shocked to hear this. He had never expected that his friend would abandon him like this because he loved and trusted his friend sincerely. As the bear came nearer, Basit was paralyzed with fear. Finding no other way, he quickly lay flat on the ground, stopped breathing, and pretended to be dead. When the bear reached him, it smelt his body, probably thought he was dead, and did not touch him. Soon the bear just walked away."
			},
			{
				"type": "p",
				"text": "After a while, Basit heard his friend coming down the tree and guessed that the bear had gone away. He stood up and looked at Raheel angrily. But Raheel, instead of feeling ashamed or apologising to his friend for having abandoned him, just asked excitedly, “Basit, what did the bear whisper in your ear?” From his position high up in the tree, he had seen that the bear had brought its face close to Basit's head and thought that the bear had said something to his friend."
			},
			{
				"type": "p",
				"text": "Basit looked at his friend angrily and replied, “He advised me not to trust a friend who leaves his friend at the time of danger.” Hearing this, Raheel felt embarrassed. He did not know what to say and started to walk away. Basit followed him silently. Since Raheel had seen the way out from the top of the tree, both friends quickly got out of the forest and reached their homes."
			},
			{
				"type": "h",
				"text": "While Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "If you are asked to select another topic for the story from the following list, which one would you choose?",
				"items": [{
					"kind": "mcq",
					"q": "Which title best fits the story?",
					"options": [
						"Beautiful friends are a blessing",
						"A beautiful forest",
						"A friend in need is a friend indeed",
						"A kind bear"
					],
					"answer": 2
				}]
			},
			{
				"type": "h",
				"text": "Vocabulary"
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Match each word with its meaning. One has been done in the book: sympathetic → kind to someone who is sad or hurt.",
				"items": [{
					"kind": "match",
					"pairs": [
						{
							"left": "sympathetic",
							"right": "kind to someone who is sad or hurt"
						},
						{
							"left": "nature lovers",
							"right": "those who enjoy nature"
						},
						{
							"left": "curious",
							"right": "wanted to know"
						},
						{
							"left": "wandered",
							"right": "walked around without any purpose"
						},
						{
							"left": "dense",
							"right": "thick"
						},
						{
							"left": "in vain",
							"right": "without any success"
						},
						{
							"left": "abandon",
							"right": "leave someone because it is dangerous to stay"
						},
						{
							"left": "paralyzed",
							"right": "unable to move"
						},
						{
							"left": "apologising",
							"right": "saying sorry"
						},
						{
							"left": "whisper",
							"right": "speak very softly"
						},
						{
							"left": "embarrassed",
							"right": "ashamed"
						}
					]
				}]
			},
			{
				"type": "h",
				"text": "Post Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "True or false? The book marks the first one as true.",
				"items": [
					{
						"kind": "tf",
						"q": "Basit and Raheel studied in the same school.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "They loved playing inside the house.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Basit never helped Raheel.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Raheel was good at climbing trees.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "They went to the forest because they enjoyed nature.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "They were attacked by a bear.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Both Basit and Raheel climbed up a tree when they saw a bear.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "The bear did not hurt Basit.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Raheel saved his friend from the bear.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Basit and Raheel reached their homes safely.",
						"answer": true
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Read the questions carefully and choose the right answer.",
				"items": [
					{
						"kind": "mcq",
						"q": "What did both the friends do on the nearby canal on weekends?",
						"options": [
							"laughed",
							"joked",
							"swam",
							"fished"
						],
						"answer": 3
					},
					{
						"kind": "mcq",
						"q": "What kind of a place was the forest that they visited?",
						"options": [
							"safe",
							"dangerous",
							"very small",
							"too dark"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "How did they feel when they visited the forest?",
						"options": [
							"spellbound",
							"unhappy",
							"curious",
							"depressed"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Why did Basit not climb the tree?",
						"options": [
							"because he avoided climbing trees",
							"because he did not know how to climb a tree",
							"because he was not afraid of animals",
							"none of these"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "What frightened them in the jungle?",
						"options": [
							"lion",
							"jackal",
							"bear",
							"tiger"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "How did Basit feel when he saw the bear coming towards him?",
						"options": [
							"happy",
							"sad",
							"upset",
							"frightened"
						],
						"answer": 3
					},
					{
						"kind": "mcq",
						"q": "What did Basit say that the animal had whispered in his ear?",
						"options": [
							"It advised him to trust a friend who leaves his friend at the time of danger.",
							"It advised him to be honest with a friend who leaves his friend at the time of danger.",
							"It advised him not to trust a friend who leaves his friend at the time of danger.",
							"None of these."
						],
						"answer": 2
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "Complete the sentences. Type the missing idea, then check. More than one correct wording is accepted.",
				"items": [
					{
						"kind": "fill",
						"q": "Raheel and Basit went for long walks in the forest because ______.",
						"answers": [
							"they liked listening to the birds",
							"they liked the birds and flowers",
							"they enjoyed nature",
							"they liked listening to the birds chirping"
						],
						"hint": "Think of birds, animals and flowers."
					},
					{
						"kind": "fill",
						"q": "Basit was a kind and helpful boy because ______.",
						"answers": [
							"his parents had taught him",
							"by nature",
							"his parents taught him to be kind"
						],
						"hint": "His nature, and what his parents taught him."
					},
					{
						"kind": "fill",
						"q": "Basit sometimes gave fish to Raheel because ______.",
						"answers": [
							"Raheel failed to catch any",
							"Basit caught more fish",
							"Raheel did not catch any fish"
						],
						"hint": "Who caught more fish?"
					},
					{
						"kind": "fill",
						"q": "Raheel was good at climbing trees because ______.",
						"answers": [
							"he had a tall tree in his house",
							"he had been climbing from an early age",
							"there was a tall tree at his house"
						],
						"hint": "A tree at his house."
					},
					{
						"kind": "fill",
						"q": "They lost their way in the forest because ______.",
						"answers": [
							"they were curious",
							"they followed whatever caught their attention",
							"they wandered deep into the forest"
						],
						"hint": "They kept following things that caught their attention."
					},
					{
						"kind": "fill",
						"q": "When they realized that they were lost, they were worried because ______.",
						"answers": [
							"dangerous beasts",
							"their parents had told them about dangerous beasts",
							"beasts living in the forest"
						],
						"hint": "What had the villagers warned them about?"
					},
					{
						"kind": "fill",
						"q": "When they saw the bear coming, Raheel told Basit to run because ______.",
						"answers": [
							"Basit did not know how to climb",
							"Basit could not climb a tree",
							"he himself was going to climb"
						],
						"hint": "Basit could not climb."
					},
					{
						"kind": "fill",
						"q": "Basit was shocked when his friend said he would climb the tree because ______.",
						"answers": [
							"he would abandon him",
							"Raheel was leaving him",
							"he never expected his friend to leave him"
						],
						"hint": "A true friend does not leave you in danger."
					},
					{
						"kind": "fill",
						"q": "Basit lay down on the ground and stopped breathing because ______.",
						"answers": [
							"he pretended to be dead",
							"so the bear would think he was dead",
							"he wanted the bear to think he was dead"
						],
						"hint": "What did he pretend?"
					},
					{
						"kind": "fill",
						"q": "They were finally able to get out of the forest quickly because ______.",
						"answers": [
							"Raheel had seen the way out",
							"Raheel saw the way from the top of the tree",
							"from the top of the tree"
						],
						"hint": "What could Raheel see from the tree?"
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "Discuss with a partner, then compare your idea with the model answer.",
				"items": [
					{
						"kind": "open",
						"q": "What do you think is the main idea of the story?",
						"model": "A real friend stands by you in danger. Raheel saved only himself, so Basit learnt not to trust a friend who runs away when trouble comes."
					},
					{
						"kind": "open",
						"q": "What did Raheel do at the time of danger?",
						"model": "He climbed a tree to save himself and told Basit to run, because Basit could not climb."
					},
					{
						"kind": "open",
						"q": "What did Raheel think the bear had done?",
						"model": "From high in the tree he saw the bear bring its face close to Basit's head, so he thought the bear had whispered something in Basit's ear."
					},
					{
						"kind": "open",
						"q": "Do you think that the bear actually said something to Basit? Why, or why not?",
						"model": "No. Bears do not whisper advice. Basit invented the words to teach Raheel a lesson: do not trust a friend who leaves you in danger."
					},
					{
						"kind": "open",
						"q": "What would you do if you were Basit?",
						"model": "Answers will differ. A strong answer says you would still try to stay calm, and afterwards tell your friend, honestly, that leaving someone in danger is not friendship."
					},
					{
						"kind": "open",
						"q": "What would you do if you were Raheel?",
						"model": "A better choice would be to help Basit hide or climb, or to face the danger together, instead of saving only yourself."
					},
					{
						"kind": "open",
						"q": "What do you think happened after this incident?",
						"model": "Raheel felt ashamed. Their friendship may have become weaker until Raheel apologised and proved he could be trusted again."
					}
				]
			}
		]
	},
	{
		"id": "1.2",
		"code": "1.2",
		"title": "Speaking",
		"subtitle": "Making Plans",
		"kind": "speaking",
		"blocks": [
			{
				"type": "p",
				"text": "Use functional language to make plans. Work in groups of three and practise the dialogue at least three times. Change roles every time."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Soomar",
						"text": "Hurrah! The final exams are over. How about visiting the Miani forest?"
					},
					{
						"who": "Jannat",
						"text": "Oh! It's a great idea! I was also thinking about it."
					},
					{
						"who": "Ayaz",
						"text": "Why not go to a beach?"
					},
					{
						"who": "Soomar",
						"text": "A visit to Miani will not only be fun but it will also help us in writing the report for our next year's project work."
					},
					{
						"who": "Ayaz",
						"text": "Oh yes! I remember, the teacher told us about it last week."
					},
					{
						"who": "Jannat",
						"text": "I think going to the Miani forest is a great idea."
					}
				]
			},
			{
				"type": "callout",
				"title": "Language you can reuse",
				"text": "How about…? Why not…? It's a great idea. I was also thinking about it. It will not only be fun but it will also help us…. Oh yes, I remember…. I think … is a great idea."
			},
			{
				"type": "exercise",
				"title": "Your turn",
				"instruction": "Write a dialogue in which three friends plan a visit to the museum. Then practise it three times, changing roles.",
				"items": [{
					"kind": "open",
					"q": "Write at least six lines. Use the same planning language as Soomar, Jannat and Ayaz.",
					"model": "Hina: Hurrah! The project week is over. How about visiting the city museum?\nSana: Oh! It's a great idea! I was also thinking about it.\nBilal: Why not go to the park?\nHina: A visit to the museum will not only be fun but it will also help us write our history report.\nBilal: Oh yes! I remember, the teacher told us about the coin gallery last week.\nSana: I think going to the museum on Saturday morning is a great idea."
				}]
			},
			{
				"type": "note",
				"text": "You can plan a picnic, party, mela, exhibition, sports day, annual day, Eid Milan or cultural day, and present the plan as a role play."
			}
		]
	},
	{
		"id": "1.3",
		"code": "1.3",
		"title": "Language Practice",
		"subtitle": "Used to, and Prepositions of Position",
		"kind": "language",
		"blocks": [
			{
				"type": "h",
				"text": "Use of “used to” for past habits and routines"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "We use used to with a verb for a past habit or routine: something we regularly did in the past but do not do any more. Example: Seema used to get up early, but she never used to brush her teeth. She often used to fall sick. Now she brushes her teeth and remains healthy."
			},
			{
				"type": "p",
				"text": "Seema used to get up early in the morning but she never used to brush her teeth. She used to have breakfast without brushing her teeth. She often used to fall sick. Her mother used to take her to the doctor. One day the doctor asked her if she brushed her teeth. Seema felt ashamed and started to brush her teeth. Now she remains healthy."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "The beginnings and endings are in the right order. Choose the verb that fits. The first is done: When I was a child I used to ride a bicycle.",
				"items": [{
					"kind": "match",
					"q": "Match the person with the correct ending. The verb is already inside the ending.",
					"pairs": [
						{
							"left": "When I was a child I used to",
							"right": "ride a bicycle."
						},
						{
							"left": "Essa used to",
							"right": "love mangoes."
						},
						{
							"left": "Seema used to",
							"right": "get up early in the morning."
						},
						{
							"left": "When I was a child my father used to",
							"right": "take care of me."
						},
						{
							"left": "They used to",
							"right": "visit historical places."
						},
						{
							"left": "Our pet dog used to",
							"right": "bite our guests."
						},
						{
							"left": "My grandfather used to",
							"right": "tease everyone in the family."
						},
						{
							"left": "His brother used to",
							"right": "play with the children."
						}
					]
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Make a used to sentence with each verb. Example: Her brother used to open his shop early in the morning.",
				"items": [{
					"kind": "open",
					"q": "Use these verbs in your own used to sentences: open, drive, make, give, sell, call, send, receive.",
					"model": "Her brother used to open his shop early. My uncle used to drive a bus. Mother used to make parathas on Fridays. Grandfather used to give us stories at night. She used to sell bangles. He used to call his cousin every Sunday. We used to send letters by post. I used to receive a prize every year."
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "List good and bad habits you had in primary school, then write used to sentences. These must not be habits you still have.",
				"items": [{
					"kind": "open",
					"q": "Write four sentences. Example: When I was in class five I used to eat food slowly.",
					"model": "When I was in class five I used to eat food slowly. I used to do my work on time. I also used to throw my wet towel on the bed. I used to tease my younger sister."
				}]
			},
			{
				"type": "h",
				"text": "Prepositions of position"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "A preposition shows a relationship between a noun or pronoun and another word. Prepositions of position include: in, inside, outside, on, under, at, by, beside, near, above, below, behind, among, between. Example: The coin was under the sofa (position). The coin rolled under the sofa (movement)."
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Choose the preposition that fits.",
				"items": [
					{
						"kind": "mcq",
						"q": "Please put this book ___ the table.",
						"options": [
							"inside",
							"at",
							"on",
							"in"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Her shoes are ___ the bed.",
						"options": [
							"in",
							"on",
							"under",
							"before"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "My teacher is ___ the class.",
						"options": [
							"in",
							"at",
							"above",
							"below"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "A huge crowd is waiting ___ the stadium.",
						"options": [
							"on",
							"above",
							"outside",
							"under"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Their house is ___ their school.",
						"options": [
							"at",
							"near",
							"in",
							"below"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "I have put the baby ___ the cot.",
						"options": [
							"in",
							"at",
							"before",
							"behind"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "The train is ___ the station.",
						"options": [
							"in",
							"at",
							"under",
							"above"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Murree is about 7000 ft. ___ the sea level.",
						"options": [
							"below",
							"behind",
							"on",
							"above"
						],
						"answer": 3
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "Fill in a preposition of position. More than one answer may be accepted.",
				"items": [
					{
						"kind": "fill",
						"q": "The boys fell _____ the pond yesterday.",
						"answers": ["into", "in"]
					},
					{
						"kind": "fill",
						"q": "Let's go _____ as it is going to rain.",
						"answers": ["inside", "in"]
					},
					{
						"kind": "fill",
						"q": "Many minerals were found _____ the surface of the earth.",
						"answers": [
							"under",
							"below",
							"beneath"
						]
					},
					{
						"kind": "fill",
						"q": "We can get most of the things that we need _____ our house.",
						"answers": ["in", "inside"]
					},
					{
						"kind": "fill",
						"q": "The old man is resting _____ the tree as it is very hot.",
						"answers": [
							"under",
							"beneath",
							"below"
						]
					},
					{
						"kind": "fill",
						"q": "I always keep my mobile phone _____ the top shelf.",
						"answers": ["on"]
					},
					{
						"kind": "fill",
						"q": "Please go and see who is _____ the door.",
						"answers": ["at", "behind"]
					},
					{
						"kind": "fill",
						"q": "The mouse is _____ the log in the corner.",
						"answers": [
							"behind",
							"under",
							"beneath"
						]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "Use at least seven prepositions from the list in your own sentences.",
				"items": [{
					"kind": "open",
					"q": "Write seven sentences using in, on, under, at, near, above, behind (or others from the list).",
					"model": "The cat is in the basket. My book is on the desk. Shoes are under the bed. We meet at the gate. The shop is near our house. The clock is above the door. The bicycle is behind the wall."
				}]
			}
		]
	},
	{
		"id": "1.4",
		"code": "1.4",
		"title": "Writing",
		"subtitle": "A Paragraph",
		"kind": "writing",
		"blocks": [
			{
				"type": "p",
				"text": "A descriptive paragraph has three parts: a topic sentence, supporting sentences, and a concluding sentence that says the main idea again in different words."
			},
			{
				"type": "callout",
				"title": "Topic sentence",
				"text": "My favourite place is my neighbourhood park. I like it for many reasons."
			},
			{
				"type": "p",
				"text": "Words that can help you: above, under, nearby, opposite to, near, across, below, to the right, to the left, similarly, among, also. You do not have to use all of them."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Write a descriptive paragraph on My Favourite Place. Add three supporting details and a concluding sentence.",
				"items": [{
					"kind": "open",
					"q": "Finish the paragraph that begins “My favourite place is my neighbourhood park.”",
					"model": "My favourite place is my neighbourhood park. I like it for many reasons. The grass is soft, and tall trees stand on the left of the path. Children play near the swings, and a small pond lies across the walking track. In the evening my friends and I sit under the neem tree. It is a quiet, green corner, and that is why the park is the place I like best."
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "With a partner, make a mind map, then write a paragraph on each topic. Exchange notebooks and read each other's work.",
				"items": [{
					"kind": "open",
					"q": "Write a short paragraph on My School, with a topic sentence, two or three details, and a concluding sentence.",
					"model": "My school is the place where I learn and meet my friends. The classrooms are bright, and the library sits to the right of the office. We play cricket on the ground behind the building. I am proud of my school because it helps me grow."
				}, {
					"kind": "open",
					"q": "Write a short paragraph on Our Hospital.",
					"model": "Our hospital is a useful place in the town. It stands near the main road, opposite the post office. Doctors and nurses look after the sick with care. We are lucky to have a hospital so close to our homes."
				}]
			}
		]
	},
	{
		"id": "1.5",
		"code": "1.5",
		"title": "Study Skills",
		"subtitle": "Outlining for Oral Presentations",
		"kind": "study",
		"blocks": [
			{
				"type": "p",
				"text": "Outlining helps you note ideas and organise them in a logical pattern before you speak."
			},
			{
				"type": "table",
				"caption": "Sample outline",
				"headers": ["Part", "What to do"],
				"rows": [
					["Beginning", "Make sure people are paying attention and greet the audience. Introduce your topic and state the main idea."],
					["Middle", "Support the main idea with details, reasons and examples. Link them back to the main idea."],
					["End", "Rephrase the main idea."]
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Sort each sentence into Beginning, Middle or End. This builds an outline on why studying matters.",
				"items": [{
					"kind": "classify",
					"q": "Where does each sentence belong?",
					"buckets": [
						"Beginning",
						"Middle",
						"End"
					],
					"cards": [
						{
							"text": "Greeting.",
							"bucket": 0
						},
						{
							"text": "Studying or getting an education is important for a number of reasons.",
							"bucket": 0
						},
						{
							"text": "To begin with, studying is an exercise for the mind.",
							"bucket": 1
						},
						{
							"text": "In addition, it can bring a change in your life.",
							"bucket": 1
						},
						{
							"text": "Finally, studying and getting educated will help in national development.",
							"bucket": 1
						},
						{
							"text": "In other words, I believe that studying is very important for everyone.",
							"bucket": 2
						}
					]
				}]
			},
			{
				"type": "p",
				"text": "After you have written the sentences, read them a few times as if you were giving a presentation. Then present to a partner. You may look at your outline, but do not read it word for word."
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Fill an outline with the title “Why do people study?” You will present it to a small group.",
				"items": [{
					"kind": "open",
					"q": "Write a Beginning, a Middle and an End for “Why do people study?”",
					"model": "Beginning: Greeting. People study for several important reasons.\nMiddle: To begin with, study trains the mind. In addition, it opens up work and a better life. Finally, educated people help the country grow.\nEnd: In other words, study matters for each of us and for Pakistan."
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Choose one title and build an outline you could present to the class: Why is sunshine important? Why is rain important? Why is school important?",
				"items": [{
					"kind": "open",
					"q": "Write a three-part outline for one of the three titles.",
					"model": "Title: Why is rain important?\nBeginning: Greeting. Rain is important for life.\nMiddle: It fills rivers and wells. It helps crops grow. It cools the hot months.\nEnd: In other words, without rain our land and our people would suffer."
				}]
			}
		]
	},
	{
		"id": "1.6",
		"code": "1.6",
		"title": "Fun",
		"subtitle": "Tongue Twisters",
		"kind": "fun",
		"blocks": [
			{
				"type": "p",
				"text": "Recite the following tongue twisters as fast as you can. Then play in two teams. One team is Quaid-e-Azam and the other is Allama Iqbal. A correct, fast recitation scores one mark."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Six swans swam swiftly southwards.",
					"I scream, you scream, we all scream for ice cream.",
					"Four furious friends fought for the phone.",
					"Never trouble trouble till trouble troubles you.",
					"Sheena leads, Sheila needs.",
					"Double bubble gum bubbles double.",
					"The queen in green screamed.",
					"Silly sheep weep and sleep."
				]
			},
			{
				"type": "exercise",
				"title": "Quick check",
				"instruction": "Which tongue twister is which? Listen for the sounds.",
				"items": [{
					"kind": "mcq",
					"q": "Which line repeats the sound “s” at the start of almost every word?",
					"options": [
						"Six swans swam swiftly southwards.",
						"Double bubble gum bubbles double.",
						"The queen in green screamed.",
						"Four furious friends fought for the phone."
					],
					"answer": 0
				}, {
					"kind": "mcq",
					"q": "Which line is built on the “b” sound?",
					"options": [
						"Silly sheep weep and sleep.",
						"Double bubble gum bubbles double.",
						"I scream, you scream, we all scream for ice cream.",
						"Sheena leads, Sheila needs."
					],
					"answer": 1
				}]
			}
		]
	}
];
var vocab$6 = [
	{
		"word": "sympathetic",
		"pos": "adjective",
		"meaning": "Kind and understanding towards someone who is sad, hurt or in trouble.",
		"urdu": "ہمدرد",
		"synonyms": [
			"compassionate",
			"kind",
			"caring"
		],
		"antonyms": [
			"unsympathetic",
			"cruel",
			"harsh"
		],
		"sentences": ["Basit's parents taught him to be a sympathetic friend who helps people in trouble."]
	},
	{
		"word": "nature lovers",
		"pos": "noun",
		"meaning": "People who enjoy the beauty of the natural world.",
		"urdu": "فطرت کے عاشق",
		"synonyms": ["nature enthusiasts", "outdoor lovers"],
		"antonyms": ["no direct antonym"],
		"sentences": ["Being nature lovers, Basit and Raheel walked through the forest looking at flowers and birds."]
	},
	{
		"word": "curious",
		"pos": "adjective",
		"meaning": "Eager to know or learn about something.",
		"urdu": "متجسس",
		"synonyms": [
			"inquisitive",
			"interested",
			"eager"
		],
		"antonyms": ["uninterested", "indifferent"],
		"sentences": ["They were so curious about everything that they followed whatever caught their attention."]
	},
	{
		"word": "wandered",
		"pos": "verb",
		"meaning": "Walked around without a clear plan or purpose.",
		"urdu": "بے مقصد گھومتے رہے",
		"synonyms": [
			"roamed",
			"strayed",
			"rambled"
		],
		"antonyms": ["stayed", "remained"],
		"sentences": ["The two friends wandered deep into the forest and lost their way."]
	},
	{
		"word": "dense",
		"pos": "adjective",
		"meaning": "Thick and crowded, with little space between things.",
		"urdu": "گنجان، گھنا",
		"synonyms": [
			"thick",
			"crowded",
			"packed"
		],
		"antonyms": [
			"thin",
			"sparse",
			"open"
		],
		"sentences": ["It is easy to lose the path in a dense forest where the trees stand close together."]
	},
	{
		"word": "in vain",
		"pos": "phrase",
		"meaning": "Without any success; with no useful result.",
		"urdu": "بے سود، رائیگاں",
		"synonyms": [
			"uselessly",
			"fruitlessly",
			"without success"
		],
		"antonyms": ["successfully", "fruitfully"],
		"sentences": ["They tried to find the way home, but all their efforts were in vain."]
	},
	{
		"word": "abandon",
		"pos": "verb",
		"meaning": "To leave someone, especially when it is dangerous for them if you go.",
		"urdu": "چھوڑ دینا، بے یار و مددگار چھوڑنا",
		"synonyms": [
			"desert",
			"leave",
			"forsake"
		],
		"antonyms": [
			"stay",
			"support",
			"help"
		],
		"sentences": ["Basit never expected that his friend would abandon him when the bear came."]
	},
	{
		"word": "paralyzed",
		"pos": "adjective",
		"meaning": "Unable to move, here because of fear.",
		"urdu": "مفلوج، خوف سے بے حس",
		"synonyms": [
			"frozen",
			"immobilized",
			"numb"
		],
		"antonyms": ["active", "mobile"],
		"sentences": ["As the bear came nearer, Basit was paralyzed with fear."]
	},
	{
		"word": "apologising",
		"pos": "verb",
		"meaning": "Saying sorry for something you have done wrong.",
		"urdu": "معافی مانگنا",
		"synonyms": ["saying sorry", "expressing regret"],
		"antonyms": ["blaming", "accusing"],
		"sentences": ["Raheel walked away without apologising for having left his friend."]
	},
	{
		"word": "whisper",
		"pos": "verb",
		"meaning": "To speak very softly, so that only a person nearby can hear.",
		"urdu": "سرگوشی کرنا",
		"synonyms": ["murmur", "speak softly"],
		"antonyms": ["shout", "yell"],
		"sentences": ["Raheel asked, “What did the bear whisper in your ear?”"]
	},
	{
		"word": "embarrassed",
		"pos": "adjective",
		"meaning": "Ashamed and uncomfortable because of something you did.",
		"urdu": "شرمندہ",
		"synonyms": [
			"ashamed",
			"uncomfortable",
			"sheepish"
		],
		"antonyms": ["proud", "confident"],
		"sentences": ["Hearing Basit's answer, Raheel felt embarrassed and did not know what to say."]
	},
	{
		"word": "sincere",
		"pos": "adjective",
		"meaning": "Honest and true in your feelings; not pretending.",
		"urdu": "مخلص",
		"synonyms": [
			"genuine",
			"honest",
			"true"
		],
		"antonyms": [
			"insincere",
			"false",
			"dishonest"
		],
		"sentences": ["Basit loved and trusted his friend sincerely, so the betrayal shocked him."]
	},
	{
		"word": "frightened",
		"pos": "adjective",
		"meaning": "Afraid; filled with fear.",
		"urdu": "خوفزدہ",
		"synonyms": [
			"afraid",
			"scared",
			"terrified"
		],
		"antonyms": [
			"brave",
			"fearless",
			"calm"
		],
		"sentences": ["When they saw a huge black bear, they got frightened."]
	},
	{
		"word": "selfish",
		"pos": "adjective",
		"meaning": "Caring only about yourself, not about others.",
		"urdu": "خود غرض",
		"synonyms": ["self-centred", "greedy"],
		"antonyms": [
			"unselfish",
			"generous",
			"kind"
		],
		"sentences": ["Raheel showed his selfish nature when he climbed the tree and left Basit behind."]
	},
	{
		"word": "shocked",
		"pos": "adjective",
		"meaning": "Very surprised and upset by something unexpected.",
		"urdu": "ششدر، سخت حیران",
		"synonyms": [
			"stunned",
			"astonished",
			"appalled"
		],
		"antonyms": ["calm", "unsurprised"],
		"sentences": ["Basit was extremely shocked to hear that his friend would not stay with him."]
	},
	{
		"word": "pretended",
		"pos": "verb",
		"meaning": "Behaved as if something was true when it was not.",
		"urdu": "بہانہ کیا، دکھاوا کیا",
		"synonyms": [
			"feigned",
			"acted",
			"made believe"
		],
		"antonyms": ["revealed", "admitted"],
		"sentences": ["Basit lay flat, stopped breathing, and pretended to be dead."]
	},
	{
		"word": "beasts",
		"pos": "noun",
		"meaning": "Wild, dangerous animals.",
		"urdu": "درندے",
		"synonyms": ["wild animals", "brutes"],
		"antonyms": ["pets"],
		"sentences": ["The villagers had often told them about the dangerous beasts living in the forest."]
	},
	{
		"word": "chirping",
		"pos": "verb",
		"meaning": "The short, high sound that birds make.",
		"urdu": "چہچہانا",
		"synonyms": ["twittering", "singing"],
		"antonyms": ["no direct antonym"],
		"sentences": ["They liked listening to the birds chirping on their long walks."]
	},
	{
		"word": "company",
		"pos": "noun",
		"meaning": "The state of being with someone and enjoying their presence.",
		"urdu": "ساتھ، رفاقت",
		"synonyms": [
			"companionship",
			"presence",
			"fellowship"
		],
		"antonyms": ["loneliness", "isolation"],
		"sentences": ["They always enjoyed each other's company."]
	},
	{
		"word": "used to",
		"pos": "verb pattern",
		"meaning": "Shows a habit or routine in the past that is not true now.",
		"urdu": "کیا کرتا تھا، عادت تھی",
		"synonyms": ["formerly", "once habitually"],
		"antonyms": ["now", "still"],
		"sentences": ["When I was a child I used to ride a bicycle."]
	}
];
var unit1_default = {
	id: "u1",
	number: 1,
	title: title$6,
	learn: learn$6,
	lessons: lessons$6,
	vocab: vocab$6
};
var unit2_exports = /* @__PURE__ */ __exportAll({
	default: () => unit2_default,
	id: () => "u2",
	learn: () => learn$5,
	lessons: () => lessons$5,
	number: () => 2,
	title: () => title$5,
	vocab: () => vocab$5
});
var title$5 = "Natural Beauty of Pakistan";
var learn$5 = [
	{
		"skill": "Reading",
		"points": [
			"Use pre-reading strategies to predict the content of a poem from its title",
			"Read a poem to get the main idea",
			"Deduce the meanings of difficult words from context",
			"Scan to answer short questions",
			"Read a poem to understand the theme and its development",
			"Summarize the poem",
			"Give a personal response with justification"
		]
	},
	{
		"skill": "Speaking",
		"points": ["Use functional language to agree or disagree politely"]
	},
	{
		"skill": "Language Practice",
		"points": ["Illustrate the use of the past perfect tense", "Illustrate the use of prepositions of movement"]
	},
	{
		"skill": "Writing",
		"points": ["Write applications to people in the extended environment"]
	},
	{
		"skill": "Study Skills",
		"points": ["Prepare a study-habit checklist"]
	},
	{
		"skill": "Fun",
		"points": ["Develop posters and comment on them"]
	}
];
var lessons$5 = [
	{
		"id": "2.1",
		"code": "2.1",
		"title": "Reading Comprehension",
		"subtitle": "My Blessed Beautiful Land",
		"kind": "reading",
		"blocks": [
			{
				"type": "h",
				"text": "Pre-Reading"
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Can you name some of the beautiful places of Pakistan?",
					"Have you visited any beautiful place in Pakistan?",
					"Which place would you like to visit? Why?"
				]
			},
			{
				"type": "exercise",
				"title": "Predict from the title",
				"instruction": "The title of the poem is “My Blessed Beautiful Land”. Which of these are you going to read about?",
				"items": [{
					"kind": "mcq",
					"q": "Which topic matches the title?",
					"options": [
						"The crops that we grow in Pakistan",
						"The beautiful clothes of Pakistan",
						"The natural beauty of Pakistan",
						"The beautiful flowers of Pakistan"
					],
					"answer": 2
				}]
			},
			{
				"type": "h",
				"text": "Reading Text"
			},
			{
				"type": "poem",
				"lines": [
					"In the North spellbinding scenes that astound",
					"Mighty Karakoram that's snow-crowned",
					"With Hindukush beauty all around",
					"Where warm and brave people are found",
					"Oh my Lord, keep them all safe and sound.",
					"",
					"The sands of the Kharan desert browned",
					"Lofty mountains with precious stones found",
					"And mines full of minerals underground",
					"My land, where fearless people abound",
					"Oh my Lord, keep them all safe and sound.",
					"",
					"Fertile plains, fields of grain all around",
					"Where meet five mighty rivers renowned",
					"A land of tales and legends profound",
					"Where simple people work the year round",
					"Oh my Lord, keep them all safe and sound.",
					"",
					"The Indus delta spread all around",
					"Far from the Mohen-jo-Daro mound",
					"Where echoes of ancient times resound",
					"And sincere and resourceful people abound",
					"Oh my Lord, keep them all safe and sound."
				]
			},
			{
				"type": "h",
				"text": "While Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Which stanza matches each picture in the book? Choose the stanza.",
				"items": [
					{
						"kind": "mcq",
						"q": "Snow-covered mountains and the Hindukush",
						"options": [
							"Stanza 1",
							"Stanza 2",
							"Stanza 3",
							"Stanza 4"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "A brown desert and minerals under the ground",
						"options": [
							"Stanza 1",
							"Stanza 2",
							"Stanza 3",
							"Stanza 4"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Five rivers and fields of grain",
						"options": [
							"Stanza 1",
							"Stanza 2",
							"Stanza 3",
							"Stanza 4"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "The Indus delta and Mohen-jo-Daro",
						"options": [
							"Stanza 1",
							"Stanza 2",
							"Stanza 3",
							"Stanza 4"
						],
						"answer": 3
					}
				]
			},
			{
				"type": "h",
				"text": "Vocabulary"
			},
			{
				"type": "exercise",
				"title": "Exercise 2 — Stanza 1",
				"instruction": "Type the word from stanza 1 that matches the meaning.",
				"items": [
					{
						"kind": "fill",
						"q": "Holding one's attention completely",
						"answers": ["spellbinding"]
					},
					{
						"kind": "fill",
						"q": "Surprise a lot",
						"answers": ["astound"]
					},
					{
						"kind": "fill",
						"q": "Very high and powerful",
						"answers": ["mighty"]
					},
					{
						"kind": "fill",
						"q": "Peaks covered with snow",
						"answers": ["snow-crowned", "snow crowned"]
					},
					{
						"kind": "fill",
						"q": "In good condition; unhurt",
						"answers": ["safe and sound"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2 — Stanza 2",
				"instruction": "Type the word from stanza 2.",
				"items": [
					{
						"kind": "fill",
						"q": "Turned brown in colour",
						"answers": ["browned"]
					},
					{
						"kind": "fill",
						"q": "Very high",
						"answers": ["lofty"]
					},
					{
						"kind": "fill",
						"q": "Valuable",
						"answers": ["precious"]
					},
					{
						"kind": "fill",
						"q": "Brave",
						"answers": ["fearless"]
					},
					{
						"kind": "fill",
						"q": "Found in large numbers",
						"answers": ["abound"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2 — Stanza 3",
				"instruction": "Type the word from stanza 3.",
				"items": [
					{
						"kind": "fill",
						"q": "Soil or land in which crops grow well",
						"answers": ["fertile"]
					},
					{
						"kind": "fill",
						"q": "A large area of flat land",
						"answers": ["plains"]
					},
					{
						"kind": "fill",
						"q": "Famous",
						"answers": ["renowned"]
					},
					{
						"kind": "fill",
						"q": "Exciting stories",
						"answers": ["tales"]
					},
					{
						"kind": "fill",
						"q": "Old stories that may or may not be true",
						"answers": ["legends"]
					},
					{
						"kind": "fill",
						"q": "Having a great effect",
						"answers": ["profound"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2 — Stanza 4",
				"instruction": "Type the word from stanza 4.",
				"items": [
					{
						"kind": "fill",
						"q": "The mouth of a river where it spreads out before entering the sea",
						"answers": ["delta"]
					},
					{
						"kind": "fill",
						"q": "A small hill",
						"answers": ["mound"]
					},
					{
						"kind": "fill",
						"q": "Very old",
						"answers": ["ancient"]
					},
					{
						"kind": "fill",
						"q": "Repeated sounds",
						"answers": ["echoes"]
					},
					{
						"kind": "fill",
						"q": "To give a loud, deep sound",
						"answers": ["resound"]
					},
					{
						"kind": "fill",
						"q": "Someone who is good at finding new ways to do things",
						"answers": ["resourceful"]
					}
				]
			},
			{
				"type": "h",
				"text": "Post Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Answer from the poem.",
				"items": [
					{
						"kind": "fill",
						"q": "Which two mountain ranges are mentioned in stanza 1?",
						"answers": [
							"karakoram and hindukush",
							"hindukush and karakoram",
							"karakoram, hindukush"
						]
					},
					{
						"kind": "fill",
						"q": "Name the desert mentioned in the poem.",
						"answers": [
							"kharan",
							"kharan desert",
							"the kharan desert"
						]
					},
					{
						"kind": "fill",
						"q": "Which ancient site is mentioned in the poem?",
						"answers": [
							"mohen-jo-daro",
							"mohenjo-daro",
							"mohen jo daro"
						]
					},
					{
						"kind": "fill",
						"q": "Which prayer is repeated in each stanza?",
						"answers": ["oh my lord keep them all safe and sound", "keep them all safe and sound"]
					},
					{
						"kind": "open",
						"q": "How many qualities of the people of Pakistan are mentioned? List them.",
						"model": "The poem mentions warm, brave, fearless, simple, sincere and resourceful people. That is six qualities."
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Each stanza describes a region. Match the stanza to the place and its people.",
				"items": [{
					"kind": "match",
					"pairs": [
						{
							"left": "Stanza 1",
							"right": "Khyber Pakhtunkhwa and Gilgit-Baltistan — snow-covered mountains; warm and brave people"
						},
						{
							"left": "Stanza 2",
							"right": "Balochistan — Kharan desert and minerals; fearless people"
						},
						{
							"left": "Stanza 3",
							"right": "Punjab — five rivers and fertile plains; simple, hard-working people"
						},
						{
							"left": "Stanza 4",
							"right": "Sindh — Indus delta and Mohen-jo-Daro; sincere and resourceful people"
						}
					]
				}]
			},
			{
				"type": "callout",
				"title": "Summary starter",
				"text": "In the poem “My Blessed Beautiful Land”, the poet describes the beauty of the various provinces of Pakistan. In stanza 1, the poet describes the North and its spellbinding scenes. He or she mentions the snow-capped mountains of the Karakoram and the beautiful scenes of the Hindukush. The people of this area are warm and brave."
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "Finish the summary in your notebook, then compare it with the model.",
				"items": [{
					"kind": "open",
					"q": "Write the summary of stanzas 2, 3 and 4, and the poet's closing thought.",
					"model": "In stanza 2, the poet describes Balochistan: the brown sands of the Kharan desert, lofty mountains, precious stones and mines. The people are fearless. In stanza 3, the poet describes Punjab, where five famous rivers meet fertile plains of grain. It is a land of tales and legends, and the people are simple and hard-working. In stanza 4, the poet describes Sindh: the Indus delta and the ancient mound of Mohen-jo-Daro, where echoes of old times resound. The people are sincere and resourceful. The poet thinks Pakistan is both beautiful and blessed, and prays to Allah to keep the country and its people safe and sound."
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "Discuss, then check a model answer.",
				"items": [
					{
						"kind": "open",
						"q": "Is the poet proud of his or her country? How do we know?",
						"model": "Yes. The poet calls it “my blessed beautiful land”, lists its mountains, rivers, desert and history, and praises its people in every stanza."
					},
					{
						"kind": "open",
						"q": "What do we learn about the people of Pakistan? Add two qualities that are not in the poem.",
						"model": "They are warm, brave, fearless, simple, sincere and resourceful. Two more qualities could be hospitable and hard-working."
					},
					{
						"kind": "open",
						"q": "Write a short paragraph about your own province, using the poem and two points of your own.",
						"model": "Answers will differ by province. A Sindh answer might mention the Indus, Mohen-jo-Daro, the sea, and the people's hospitality. A Punjab answer might mention the five rivers, wheat fields, and lively cities."
					}
				]
			}
		]
	},
	{
		"id": "2.2",
		"code": "2.2",
		"title": "Speaking",
		"subtitle": "Agree or Disagree Politely",
		"kind": "speaking",
		"blocks": [
			{
				"type": "p",
				"text": "Work in groups of three. Read the examples. Notice the polite words used to agree or disagree. Practise each dialogue three times, taking a different role each time."
			},
			{
				"type": "h",
				"text": "Example 1 — disagreeing politely"
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Student A",
						"text": "Javed Miandad was the best player of the last century."
					},
					{
						"who": "Student B",
						"text": "No, I don't think so. I think Zaheer Abbas was better."
					},
					{
						"who": "Student C",
						"text": "I'm afraid I disagree with both of you. Actually both were fantastic players."
					}
				]
			},
			{
				"type": "h",
				"text": "Example 2 — agreeing politely"
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Student A",
						"text": "Travelling by train is great fun."
					},
					{
						"who": "Student B",
						"text": "I agree with you. One can relax and enjoy the scenery."
					},
					{
						"who": "Student C",
						"text": "That's right! One can also walk about and lie down and sleep properly."
					},
					{
						"who": "Student A",
						"text": "Exactly! We can also go to the dining car and have our meals there."
					}
				]
			},
			{
				"type": "h",
				"text": "Example 3 — agree and disagree"
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Student A",
						"text": "Books are a thing of the past. The future is in online books."
					},
					{
						"who": "Student B",
						"text": "I beg to differ. A lot of people still prefer to have a book in their hands rather than reading one on a screen."
					},
					{
						"who": "Student C",
						"text": "You are right. But I agree with A. I think young people like everything that is on a screen."
					}
				]
			},
			{
				"type": "callout",
				"title": "Polite language",
				"text": "To disagree: No, I don't think so. I'm afraid I disagree. I beg to differ. Actually… To agree: I agree with you. That's right. Exactly. You are right."
			},
			{
				"type": "exercise",
				"title": "Spot the polite words",
				"instruction": "Which line is a polite disagreement?",
				"items": [{
					"kind": "mcq",
					"q": "Choose the polite way to disagree.",
					"options": [
						"You are wrong and silly.",
						"I'm afraid I disagree.",
						"Shut up.",
						"That is a stupid idea."
					],
					"answer": 1
				}, {
					"kind": "mcq",
					"q": "Choose the polite way to agree.",
					"options": [
						"Whatever.",
						"I agree with you.",
						"You copied my idea.",
						"No."
					],
					"answer": 1
				}]
			},
			{
				"type": "exercise",
				"title": "Your turn",
				"instruction": "In a group of three, one student makes a statement, one agrees, and one disagrees. Topics: today's weather; the best food; a beautiful place in Pakistan; your favourite fruit or sweet.",
				"items": [{
					"kind": "open",
					"q": "Write a three-line dialogue about a beautiful place in Pakistan. One student agrees and one disagrees politely.",
					"model": "A: Hunza is the most beautiful place in Pakistan.\nB: I agree with you. The mountains and the orchards are wonderful.\nC: I beg to differ. I think the Keenjhar Lake is just as beautiful, and it is easier for us to visit."
				}]
			}
		]
	},
	{
		"id": "2.3",
		"code": "2.3",
		"title": "Language Practice",
		"subtitle": "Past Perfect Tense and Prepositions of Movement",
		"kind": "language",
		"blocks": [
			{
				"type": "h",
				"text": "Past Perfect Tense"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "When we talk about an action that happened before another past event, we often use the past perfect: had + past participle. The earlier action takes the past perfect. The later action usually stays in the simple past. Examples: When I got home yesterday, my father had already cooked dinner. I didn't want to go to the cinema because I had seen the film already. Past participles: see → seen, run → run, eat → eaten."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Which action happened first?",
				"items": [
					{
						"kind": "mcq",
						"q": "I studied Japanese before I went to study in Japan. Which happened first?",
						"options": ["studied Japanese", "went to Japan"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "We had trouble at the airport because we lost our passports. Which happened first?",
						"options": ["having trouble", "losing the passports"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "After we watched TV for a while, we went to sleep. Which happened first?",
						"options": ["watching TV", "going to sleep"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "Sachal knew many people at the office because he worked there years ago. Which happened first?",
						"options": ["knowing many people that day", "working there years ago"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Farah enjoyed the movie because she read the book. Which happened first?",
						"options": ["enjoying the movie", "reading the book"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "My father was in Syria before the problems started. Which happened first?",
						"options": ["his visit to Syria", "the problems starting"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "I played cricket after I finished my homework. Which happened first?",
						"options": ["playing cricket", "finishing the homework"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "When I came to your house last night, you went to bed. Which happened first?",
						"options": ["I came", "you went to bed"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "The train left the station when we reached, because we were late. Which happened first?",
						"options": ["the train left", "we reached"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "We went out for a walk after it stopped raining. Which happened first?",
						"options": ["we went out", "the rain stopped"],
						"answer": 1
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Write the sentence. Use the simple past for the later action and the past perfect for the earlier one.",
				"items": [
					{
						"kind": "fill",
						"q": "I _____ Japanese before I _____ to study in Japan.",
						"answers": ["had studied, went", "had studied japanese before i went"]
					},
					{
						"kind": "fill",
						"q": "We _____ a lot of trouble at the airport because we _____ our passports.",
						"answers": ["had, had lost", "had a lot of trouble because we had lost"]
					},
					{
						"kind": "fill",
						"q": "After we _____ TV for a while we _____ to sleep.",
						"answers": ["had watched, went"]
					},
					{
						"kind": "fill",
						"q": "Sachal _____ many people at the office because he _____ there some years ago.",
						"answers": ["knew, had worked"]
					},
					{
						"kind": "fill",
						"q": "Farah _____ the movie because she _____ the book.",
						"answers": ["enjoyed, had read"]
					},
					{
						"kind": "fill",
						"q": "My father _____ to Syria before the problems _____ in that country.",
						"answers": ["had been, started"]
					},
					{
						"kind": "fill",
						"q": "I _____ cricket after I _____ my homework.",
						"answers": ["played, had finished"]
					},
					{
						"kind": "fill",
						"q": "When I _____ to your house last night you _____ to bed.",
						"answers": ["came, had gone"]
					},
					{
						"kind": "fill",
						"q": "The train _____ the station when we _____ because we were late.",
						"answers": ["had left, reached"]
					},
					{
						"kind": "fill",
						"q": "We _____ out for a walk after it _____ raining.",
						"answers": ["went, had stopped"]
					}
				]
			},
			{
				"type": "h",
				"text": "Exercise 3 — the race"
			},
			{
				"type": "p",
				"text": "Eight small girls were participating in a race. Fill each blank with the past or the past perfect of a suitable verb: stand, tell, blow, hear, run, stop, turn, see, fall, go, cry."
			},
			{
				"type": "exercise",
				"title": "Paragraph 1",
				"instruction": "One blank at a time, in order.",
				"items": [
					{
						"kind": "fill",
						"q": "They all _____ at the starting line, waiting for the whistle to blow.",
						"answers": ["stood"]
					},
					{
						"kind": "fill",
						"q": "Their teacher _____ them not to run until she blew the whistle.",
						"answers": ["told", "had told"]
					},
					{
						"kind": "fill",
						"q": "Their teacher told them not to run until she _____ the whistle.",
						"answers": ["blew", "had blown"]
					},
					{
						"kind": "fill",
						"q": "When they _____ the whistle, they all ran.",
						"answers": ["heard"]
					},
					{
						"kind": "fill",
						"q": "When they heard the whistle, they all _____.",
						"answers": ["ran"]
					},
					{
						"kind": "fill",
						"q": "Suddenly, they _____; one of their friends was crying.",
						"answers": ["stopped"]
					},
					{
						"kind": "fill",
						"q": "They all _____ around and saw that their friend had fallen down.",
						"answers": ["turned"]
					},
					{
						"kind": "fill",
						"q": "They all turned around and _____ that their friend had fallen down.",
						"answers": ["saw"]
					},
					{
						"kind": "fill",
						"q": "They saw that their friend _____ down.",
						"answers": ["had fallen"]
					},
					{
						"kind": "fill",
						"q": "They all _____ back because she cried for help.",
						"answers": ["went", "ran"]
					},
					{
						"kind": "fill",
						"q": "They went back because she _____ for help.",
						"answers": [
							"cried",
							"was crying",
							"had cried"
						]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Paragraphs 2 and 3",
				"instruction": "Verbs: reach, see, injure, hurt, need, tell, come, pick, wait, steady, hold, clap, teach, show, is.",
				"items": [
					{
						"kind": "fill",
						"q": "When they _____ her, they saw that she had hurt herself.",
						"answers": ["reached"]
					},
					{
						"kind": "fill",
						"q": "When they reached her, they _____ that she had injured herself.",
						"answers": ["saw"]
					},
					{
						"kind": "fill",
						"q": "She _____ her knee and she needed their help.",
						"answers": ["had hurt", "hurt"]
					},
					{
						"kind": "fill",
						"q": "She had hurt her knee and she _____ their help.",
						"answers": ["needed"]
					},
					{
						"kind": "fill",
						"q": "They _____ her not to cry as they had come to help her.",
						"answers": ["told"]
					},
					{
						"kind": "fill",
						"q": "Two of the girls _____ her up and waited till she steadied herself.",
						"answers": ["picked"]
					},
					{
						"kind": "fill",
						"q": "Two of the girls picked her up and _____ till she steadied herself.",
						"answers": ["waited"]
					},
					{
						"kind": "fill",
						"q": "Then they all _____ hands and ran to the finishing line together.",
						"answers": ["held"]
					},
					{
						"kind": "fill",
						"q": "Everyone _____ for them.",
						"answers": ["clapped"]
					},
					{
						"kind": "fill",
						"q": "They _____ everyone a very powerful lesson.",
						"answers": ["taught"]
					},
					{
						"kind": "fill",
						"q": "They _____ everyone that helping others _____ as important as winning.",
						"answers": [
							"showed, is",
							"showed is",
							"showed that helping others is"
						]
					}
				]
			},
			{
				"type": "h",
				"text": "Prepositions of movement"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "Some prepositions show movement: towards, from, to, up, down, across, through, along, around, into. Examples: The man was walking along the road. The toy car rolled around the sofa."
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Use each preposition only once: across, along, up, to, around, from, into, towards, through, down.",
				"items": [
					{
						"kind": "fill",
						"q": "The boy looked left and right before running _____ the road.",
						"answers": ["across"]
					},
					{
						"kind": "fill",
						"q": "Many trees have been planted all _____ the street.",
						"answers": ["along"]
					},
					{
						"kind": "fill",
						"q": "The fireman climbed _____ the ladder to rescue the old lady.",
						"answers": ["up"]
					},
					{
						"kind": "fill",
						"q": "My brother is going _____ Gilgit next week.",
						"answers": ["to"]
					},
					{
						"kind": "fill",
						"q": "The boy turned _____ the corner and stopped.",
						"answers": ["around"]
					},
					{
						"kind": "fill",
						"q": "Saleha's aunt has come _____ Quetta to visit them.",
						"answers": ["from"]
					},
					{
						"kind": "fill",
						"q": "The swimmer dived _____ the water from a height of 100 ft.",
						"answers": ["into"]
					},
					{
						"kind": "fill",
						"q": "I was walking _____ my friend when I slipped and fell.",
						"answers": ["towards"]
					},
					{
						"kind": "fill",
						"q": "Walk _____ this tunnel to get to the other side.",
						"answers": ["through"]
					},
					{
						"kind": "fill",
						"q": "Rustam fell _____ the stairs and broke his leg.",
						"answers": ["down"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "The same prepositions, each used once, tell this story.",
				"items": [
					{
						"kind": "fill",
						"q": "As I was walking home _____ my office, I saw a man.",
						"answers": ["from"]
					},
					{
						"kind": "fill",
						"q": "I saw a man coming _____ me from the other side.",
						"answers": ["towards"]
					},
					{
						"kind": "fill",
						"q": "I looked _____ and down the road. (the first of the pair)",
						"answers": ["up"]
					},
					{
						"kind": "fill",
						"q": "I looked up and _____ the road.",
						"answers": ["down"]
					},
					{
						"kind": "fill",
						"q": "I saw him walking _____ the door.",
						"answers": ["through"]
					},
					{
						"kind": "fill",
						"q": "I walked _____ the row of shelves.",
						"answers": ["along"]
					},
					{
						"kind": "fill",
						"q": "I stepped _____ the lift and went to the second floor.",
						"answers": ["into"]
					},
					{
						"kind": "fill",
						"q": "I went _____ the manager's room and told him the story.",
						"answers": ["to"]
					}
				]
			},
			{
				"type": "p",
				"text": "The ending of the story: the manager called the police, who caught the man. To the narrator's embarrassment, he was an uncle who had come from Dubai after ten years."
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"items": [{
					"kind": "open",
					"q": "Write a short narrative using at least six prepositions of movement.",
					"model": "I walked from my house towards the canal. I went along the path, climbed up the bank, and looked down at the water. Then I ran across the bridge, through the market, and into my uncle's shop."
				}]
			}
		]
	},
	{
		"id": "2.4",
		"code": "2.4",
		"title": "Writing",
		"subtitle": "Application",
		"kind": "writing",
		"blocks": [
			{
				"type": "h",
				"text": "Sample 1 — leave because of sickness"
			},
			{
				"type": "p",
				"text": "November 12, 2017. The Principal, Govt. High School, Jamshoro. Respected Sir / Madam, With due respect I, a student of class VIII, would like to inform you that I was not able to come to school on 8-04-2017 as I was sick. I would, therefore, like to request you to kindly grant me leave for that day and oblige. I hope that you will consider my request favourably and grant me leave as I am a very regular student. I shall be very grateful to you. Thanking you in anticipation. Yours sincerely, Sana Iqbal, Class VIII."
			},
			{
				"type": "h",
				"text": "Sample 2 — permission for a picnic"
			},
			{
				"type": "p",
				"text": "March 25, 2017. The Principal, XYZ School, Karachi. Subject: Request for allowing the Class VIII students to go for a picnic. Respected Madam / Sir, This is to state that since our final exams are over, we, the students of class VIII, would like to go to Keenjhar Lake for a picnic. We would like to go on Monday, April 2, at 8 a.m. and will return by 5 p.m. We will follow all the school rules. Four of our teachers have agreed to go with us, if you allow. We request you to please allow us to go and enjoy ourselves before the new term begins. We shall be very thankful to you if you give us permission. Thanking you in anticipation. Yours obediently, Students of Class VIII."
			},
			{
				"type": "table",
				"caption": "Phrases you may use",
				"headers": ["Part", "Phrases"],
				"rows": [
					["Greeting", "Respected Madam / Sir; Dear Sir / Madam"],
					["Opening", "This is to state that…; With due respect…; It is to request you…; This is to inform you that…"],
					["Closure", "I shall be much obliged to you. Thanking you in anticipation. Looking forward to your kind consideration."],
					["Signature", "Yours obediently; Yours sincerely; Yours faithfully"]
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Write an application for two days' leave because your brother or sister is getting married.",
				"items": [{
					"kind": "open",
					"q": "Write the full application.",
					"model": "The Principal,\nGovt. High School, Jamshoro.\nRespected Sir / Madam,\nWith due respect I, Ayesha, a student of class VIII, would like to inform you that my sister is getting married. I request you to kindly grant me leave for two days, 20 and 21 April. I shall complete any work I miss. I shall be very thankful to you.\nThanking you in anticipation.\nYours sincerely,\nAyesha\nClass VIII"
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Write an application asking permission for a study tour.",
				"items": [{
					"kind": "open",
					"q": "Follow sample 2. Choose a real place.",
					"model": "The Principal,\nSubject: Request for a study tour.\nRespected Madam / Sir,\nThis is to state that we, the students of class VIII, would like to go on a study tour to the Sindh Museum. We would like to go on Friday at 9 a.m. and return by 1 p.m. Two teachers have agreed to go with us. We request you to please allow us. We shall be very thankful to you.\nThanking you in anticipation.\nYours obediently,\nStudents of Class VIII"
				}]
			}
		]
	},
	{
		"id": "2.5",
		"code": "2.5",
		"title": "Study Skills",
		"subtitle": "Checklist",
		"kind": "study",
		"blocks": [
			{
				"type": "p",
				"text": "What kind of study habits do you have? Read the list and notice which things you do most of the time. Then, with a partner, list the habits you should start, and number them in the order you will change them."
			},
			{
				"type": "list",
				"items": [
					"I always sit in one place to study or to do my homework.",
					"I have a special place to study that is comfortable and quiet.",
					"I keep all my study materials in one place, including paper, pencils, pens and a dictionary.",
					"I study at about the same time every day, and I know that this is the best time for me.",
					"When I sit down to study, I first decide what I will do and in which order.",
					"I also decide whether I will do all the work at one time or some now and some later.",
					"I usually have enough time to finish my homework.",
					"I can contact at least one person in my class if I have a question about an assignment.",
					"I always do some reading for fun and enjoyment.",
					"I check my bag every night to see that I have all my books for the next day."
				]
			},
			{
				"type": "exercise",
				"title": "Plan the change",
				"items": [{
					"kind": "open",
					"q": "Name three habits from the list that you do not do yet, in the order you will start them.",
					"model": "1. I will check my bag every night. 2. I will keep my books and pens in one place. 3. I will study at the same time each day."
				}]
			}
		]
	},
	{
		"id": "2.6",
		"code": "2.6",
		"title": "Fun",
		"subtitle": "Plans for a poster exhibition",
		"kind": "fun",
		"blocks": [
			{
				"type": "p",
				"text": "Plan to hold an exhibition in your class. Prepare colourful posters showing what your village, town or city looks like."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Work in groups of three.",
					"Decide what the poster will show, and keep it nice and colourful.",
					"Collect pencils, colours, pictures and other materials.",
					"Decide who will draw, who will write, and who will colour.",
					"Display the posters in the class.",
					"Pin a blank sheet of paper to each poster.",
					"Visit every poster and find something to appreciate.",
					"Write an appreciative comment on the blank sheet."
				]
			},
			{
				"type": "exercise",
				"title": "A kind comment",
				"items": [{
					"kind": "open",
					"q": "Write one appreciative sentence you could pin on a classmate's poster of your city.",
					"model": "I like the bright boats on the river. They make the city look alive and welcoming."
				}]
			}
		]
	}
];
var vocab$5 = [
	{
		"word": "spellbinding",
		"pos": "adjective",
		"meaning": "So beautiful or interesting that it holds your attention completely.",
		"urdu": "دل موہ لینے والا",
		"synonyms": [
			"fascinating",
			"captivating",
			"enchanting"
		],
		"antonyms": ["boring", "dull"],
		"sentences": ["In the North there are spellbinding scenes that hold every traveller's eye."]
	},
	{
		"word": "astound",
		"pos": "verb",
		"meaning": "To surprise someone very much.",
		"urdu": "حیران کر دینا",
		"synonyms": [
			"amaze",
			"astonish",
			"stun"
		],
		"antonyms": ["bore", "expect"],
		"sentences": ["The snow-covered peaks astound anyone who sees them for the first time."]
	},
	{
		"word": "mighty",
		"pos": "adjective",
		"meaning": "Very great in size, strength or importance.",
		"urdu": "عظیم، زبردست",
		"synonyms": [
			"powerful",
			"huge",
			"great"
		],
		"antonyms": ["weak", "small"],
		"sentences": ["Mighty Karakoram rises, snow-crowned, in the north of Pakistan."]
	},
	{
		"word": "snow-crowned",
		"pos": "adjective",
		"meaning": "Having peaks covered with snow, as if wearing a crown of snow.",
		"urdu": "برف سے ڈھکی چوٹیوں والا",
		"synonyms": ["snow-capped", "snow-covered"],
		"antonyms": ["bare"],
		"sentences": ["The poem calls the Karakoram snow-crowned."]
	},
	{
		"word": "lofty",
		"pos": "adjective",
		"meaning": "Very high.",
		"urdu": "بلند",
		"synonyms": [
			"high",
			"towering",
			"tall"
		],
		"antonyms": ["low", "short"],
		"sentences": ["Lofty mountains hide precious stones in Balochistan."]
	},
	{
		"word": "precious",
		"pos": "adjective",
		"meaning": "Very valuable.",
		"urdu": "قیمتی",
		"synonyms": [
			"valuable",
			"costly",
			"priceless"
		],
		"antonyms": ["worthless", "cheap"],
		"sentences": ["Lofty mountains with precious stones are found in the poem's second stanza."]
	},
	{
		"word": "fearless",
		"pos": "adjective",
		"meaning": "Brave; without fear.",
		"urdu": "نڈر",
		"synonyms": [
			"brave",
			"bold",
			"courageous"
		],
		"antonyms": ["fearful", "cowardly"],
		"sentences": ["The poet says fearless people abound in that land."]
	},
	{
		"word": "abound",
		"pos": "verb",
		"meaning": "To exist in large numbers.",
		"urdu": "بکثرت ہونا",
		"synonyms": [
			"flourish",
			"teem",
			"overflow"
		],
		"antonyms": ["lack", "vanish"],
		"sentences": ["Sincere and resourceful people abound in the Indus delta."]
	},
	{
		"word": "fertile",
		"pos": "adjective",
		"meaning": "Good for growing crops; rich soil.",
		"urdu": "زرخیز",
		"synonyms": [
			"fruitful",
			"productive",
			"rich"
		],
		"antonyms": ["barren", "infertile"],
		"sentences": ["Fertile plains and fields of grain spread where the five rivers meet."]
	},
	{
		"word": "plains",
		"pos": "noun",
		"meaning": "Large areas of flat land.",
		"urdu": "میدان",
		"synonyms": ["flatlands", "lowlands"],
		"antonyms": ["mountains", "hills"],
		"sentences": ["The fertile plains of Punjab are famous for grain."]
	},
	{
		"word": "renowned",
		"pos": "adjective",
		"meaning": "Famous and well known.",
		"urdu": "مشہور",
		"synonyms": [
			"famous",
			"celebrated",
			"well-known"
		],
		"antonyms": ["unknown", "obscure"],
		"sentences": ["Five mighty rivers renowned for their meeting water the plains."]
	},
	{
		"word": "tales",
		"pos": "noun",
		"meaning": "Exciting stories.",
		"urdu": "کہانیاں",
		"synonyms": ["stories", "narratives"],
		"antonyms": ["facts", "silence"],
		"sentences": ["Pakistan is a land of tales and legends profound."]
	},
	{
		"word": "legends",
		"pos": "noun",
		"meaning": "Old stories that may or may not be true, passed down over time.",
		"urdu": "داستان، لوک کہانیاں",
		"synonyms": [
			"myths",
			"folktales",
			"sagas"
		],
		"antonyms": ["records", "facts"],
		"sentences": ["The plains are a land of tales and legends."]
	},
	{
		"word": "profound",
		"pos": "adjective",
		"meaning": "Deep, serious, and having a great effect.",
		"urdu": "گہرا، اثر انگیز",
		"synonyms": [
			"deep",
			"intense",
			"meaningful"
		],
		"antonyms": ["shallow", "slight"],
		"sentences": ["The poet calls it a land of tales and legends profound."]
	},
	{
		"word": "delta",
		"pos": "noun",
		"meaning": "The mouth of a river, where it spreads out before entering the sea.",
		"urdu": "دہانہ، ڈیلٹا",
		"synonyms": ["river mouth", "estuary"],
		"antonyms": ["source"],
		"sentences": ["The Indus delta is spread all around in the south."]
	},
	{
		"word": "mound",
		"pos": "noun",
		"meaning": "A small hill, here the raised ruins of an old city.",
		"urdu": "ٹیلہ",
		"synonyms": [
			"hillock",
			"heap",
			"knoll"
		],
		"antonyms": ["valley", "pit"],
		"sentences": ["Mohen-jo-Daro is remembered as an ancient mound."]
	},
	{
		"word": "ancient",
		"pos": "adjective",
		"meaning": "Very old; belonging to a time long ago.",
		"urdu": "قدیم",
		"synonyms": [
			"old",
			"antique",
			"age-old"
		],
		"antonyms": ["modern", "new"],
		"sentences": ["Echoes of ancient times resound near Mohen-jo-Daro."]
	},
	{
		"word": "echoes",
		"pos": "noun",
		"meaning": "Sounds that are heard again after they bounce back.",
		"urdu": "گونج",
		"synonyms": ["reverberations", "reflections"],
		"antonyms": ["silence"],
		"sentences": ["Echoes of ancient times still seem to sound across the delta."]
	},
	{
		"word": "resound",
		"pos": "verb",
		"meaning": "To fill a place with a loud, deep sound.",
		"urdu": "گونجنا",
		"synonyms": [
			"echo",
			"ring",
			"boom"
		],
		"antonyms": ["whisper", "fade"],
		"sentences": ["Echoes of ancient times resound far from the mound."]
	},
	{
		"word": "resourceful",
		"pos": "adjective",
		"meaning": "Good at finding new ways to solve problems.",
		"urdu": "وسائل مند، ہنر مند",
		"synonyms": [
			"clever",
			"inventive",
			"capable"
		],
		"antonyms": ["helpless", "unimaginative"],
		"sentences": ["The poet praises sincere and resourceful people."]
	},
	{
		"word": "browned",
		"pos": "adjective",
		"meaning": "Turned brown in colour.",
		"urdu": "بھورا پڑا ہوا",
		"synonyms": ["tanned", "sun-baked"],
		"antonyms": ["pale", "green"],
		"sentences": ["The sands of the Kharan desert are browned by the sun."]
	},
	{
		"word": "safe and sound",
		"pos": "phrase",
		"meaning": "Unhurt and in good condition.",
		"urdu": "سلامت و محفوظ",
		"synonyms": ["unharmed", "secure"],
		"antonyms": ["hurt", "in danger"],
		"sentences": ["The poet prays, “Keep them all safe and sound.”"]
	}
];
var unit2_default = {
	id: "u2",
	number: 2,
	title: title$5,
	learn: learn$5,
	lessons: lessons$5,
	vocab: vocab$5
};
var unit3_exports = /* @__PURE__ */ __exportAll({
	default: () => unit3_default,
	id: () => "u3",
	learn: () => learn$4,
	lessons: () => lessons$4,
	number: () => 3,
	title: () => title$4,
	vocab: () => vocab$4
});
var title$4 = "Traffic Education";
var learn$4 = [
	{
		"skill": "Reading",
		"points": [
			"Use pre-reading strategies to predict the content of a text from the topic, picture and title by using prior knowledge and asking questions",
			"Skim the text to get a general idea of the text",
			"Deduce the meaning of difficult words from context",
			"Apply critical thinking to interact with the text",
			"Make simple inferences using the context of the text and prior knowledge",
			"Use summary skills to summarize the text",
			"Apply world knowledge and own feelings / opinions to the text read"
		]
	},
	{
		"skill": "Speaking",
		"points": ["Using functional language for asking ideas and opinions"]
	},
	{
		"skill": "Language Practice",
		"points": ["Recognise and demonstrate the use of modal verbs learnt earlier; 'must' and 'mustn't'", "Make imperative sentences"]
	},
	{
		"skill": "Writing",
		"points": ["Write formal emails explaining or giving reasons"]
	},
	{
		"skill": "Study Skills",
		"points": ["Preparing extended outlines for oral and written presentations"]
	},
	{
		"skill": "Fun",
		"points": ["Reading the news and recording specific details"]
	}
];
var lessons$4 = [
	{
		"id": "3.1",
		"code": "3.1",
		"title": "Reading Comprehension",
		"subtitle": "Better Be Safe Than Sorry",
		"kind": "reading",
		"blocks": [
			{
				"type": "h",
				"text": "Pre-Reading"
			},
			{
				"type": "p",
				"text": "Look at the picture given below. It shows a busy road. Circle the following items in the picture."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"An over loaded bus",
					"A child riding a bicycle",
					"A man hanging on the footboard of a bus",
					"A motorcyclist"
				]
			},
			{
				"type": "p",
				"text": "Now use the picture above and orally discuss the following questions."
			},
			{
				"type": "exercise",
				"title": "Pre-Reading Discussion",
				"instruction": "Discuss the questions, then write a short answer for each one.",
				"items": [
					{
						"kind": "open",
						"q": "Who is in danger on this busy street? Identify 3–5 individuals.",
						"model": "The child riding a bicycle, the man hanging on the footboard, the passengers of the overloaded bus, and the motorcyclist are in danger. A pedestrian who is not using a crossing would also be in danger."
					},
					{
						"kind": "open",
						"q": "Work in groups of three and try to find the reasons why the people you identified above are in danger.",
						"model": "The child may not be able to control a bicycle among fast vehicles. The man on the footboard can fall off a moving bus. An overloaded bus is difficult to stop and passengers may be hurt. A motorcyclist can be badly injured if he rides fast or does not wear a helmet."
					},
					{
						"kind": "open",
						"q": "The title of the text you are about to read is Better Be Safe Than Sorry. What do you think the text is about?",
						"model": "I think the text is about road safety. It will explain why accidents happen when people ignore the rules, and it will tell drivers, cyclists, pedestrians and passengers how to stay safe so that they do not have to be sorry later."
					}
				]
			},
			{
				"type": "h",
				"text": "Reading Text"
			},
			{
				"type": "p",
				"text": "Better Be Safe Than Sorry"
			},
			{
				"type": "p",
				"text": "Do you know anyone who died or was seriously injured in a road accident? Most of us know of someone who has been involved in a road accident in one way or the other. Why do you think accidents happen? It is mainly because most people do not follow the road safety rules. Roads are built to make travel easy for us. We must, therefore, use them carefully so that they become safe for us to travel on. Citizens must understand that undisciplined users cause traffic accidents; and accidents sometimes result in people losing some part of their body or even their lives."
			},
			{
				"type": "p",
				"text": "According to information available, all types of road users, including truck and bus drivers, and even pedestrians, are responsible for accidents. Many accidents happen because of careless pedestrians, who cross roads without checking for safety. They also walk on the road instead of using the footpaths. Another major reason why accidents occur is because many motorcyclists ride too fast and do not use helmets to protect their heads. Worst of all, they perform dangerous stunts. Some other causes of accidents are children playing in the streets, beggars dodging traffic, and people selling flowers and other things on the road."
			},
			{
				"type": "p",
				"text": "Road users need to be made aware of safety factors that can make roads safe for use. A number of strategies can be adopted for this purpose. The media, both radio and television, can give people road safety instructions through appealing programmes. Schools can contact their local police stations to request traffic education for their students. The traffic police need to teach traffic rules to the people who apply for driving licenses."
			},
			{
				"type": "p",
				"text": "Parents also have a big responsibility. They must understand that safe roads will keep their families safe and protect them from the grief and harm that road accidents cause. They need to advise their children on road safety. Sometimes, children who are under-age, drive cars as well as motorcycles that they borrow or rent. They often drive too fast and carelessly. Here, the parents' role is very important. They must not allow their children to drive without a driving license. Moreover, they should teach them, from an early age, not to play on the roads and how to cross the road safely."
			},
			{
				"type": "p",
				"text": "All sources should be used to create safe roads. Textbooks are a good source that can be used to impart traffic education. For example, the \"Green Cross Code\" can be taught to the children through lessons in textbooks. It is a simple code that people can use while crossing roads. The steps in this code are: stop, look, listen, think and cross. Beside this code, other safety rules can also be taught. For example, pedestrians should be made aware that they should walk on the footpaths, where available. If there are no footpaths, and they have to use the road, then they should use the edge of the road."
			},
			{
				"type": "p",
				"text": "Understanding and following traffic rules can help prevent many accidents. Hence, all citizens, especially children, can benefit a lot from being aware about them. Some common safety tips are discussed in the table below."
			},
			{
				"type": "h",
				"text": "A. Safety Rules for Cyclists"
			},
			{
				"type": "table",
				"caption": "Safety Rules for Cyclists",
				"headers": ["Do's", "Don'ts"],
				"rows": [
					["Try to stay on the extreme left of the road", "Ride without a horn or bell to warn pedestrians"],
					["Check your brakes and make sure that they are working properly", "Perform stunts"],
					["Have lights or reflectors on your bike if you ride at night", "Weave in and out of traffic"]
				]
			},
			{
				"type": "h",
				"text": "B. Safety Rules for Pedestrians"
			},
			{
				"type": "table",
				"caption": "Safety Rules for Pedestrians",
				"headers": ["Do's", "Don'ts"],
				"rows": [
					["Use zebra crossings", "Run across the road"],
					["Wait patiently for the right time to cross the road", "Allow young children to cross the road by themselves"],
					["Use the Green Cross Code", "Cross when the traffic light is green"]
				]
			},
			{
				"type": "h",
				"text": "C. Safety Rules While Using School and Public Transport"
			},
			{
				"type": "table",
				"caption": "Safety Rules While Using School and Public Transport",
				"headers": ["Do's", "Don'ts"],
				"rows": [
					["Always hold on to a support if you are standing.", "Ride on the footboard or on the roof"],
					["Remain seated until it is safe to leave your seat", "Get off before the vehicle stops"],
					["Get on to the bus without pushing people", "Lean out of windows of moving vehicles"]
				]
			},
			{
				"type": "h",
				"text": "D. Safety Rules for Motorcycle Pillion Riders"
			},
			{
				"type": "table",
				"caption": "Safety Rules for Motorcycle Pillion Riders",
				"headers": ["Do's", "Don'ts"],
				"rows": [
					["Wear a helmet", "Ask the driver to drive fast"],
					["Take care of your clothes so that they are not caught in the wheels", "Dangle your feet"],
					["Hold on to something to keep your balance", "Distract the driver"]
				]
			},
			{
				"type": "h",
				"text": "While Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Skim the text and the tables, then fill each blank.",
				"items": [
					{
						"kind": "fill",
						"q": "The text has ____ paragraphs.",
						"answers": ["6", "six"],
						"hint": "Count the indented paragraphs of Better Be Safe Than Sorry, before the tables."
					},
					{
						"kind": "fill",
						"q": "The table gives safety tips for ____ types of road users.",
						"answers": ["4", "four"],
						"hint": "Cyclists, pedestrians, school and public transport users, and motorcycle pillion riders."
					},
					{
						"kind": "fill",
						"q": "The table has a total of ____ tips for each type of road user.",
						"answers": ["6", "six"]
					},
					{
						"kind": "fill",
						"q": "For each type of road user, the table lists ____ things that they must do.",
						"answers": ["3", "three"]
					},
					{
						"kind": "fill",
						"q": "For each type of road user, the table lists ____ things that they should not do.",
						"answers": ["3", "three"]
					}
				]
			},
			{
				"type": "h",
				"text": "Vocabulary"
			},
			{
				"type": "words",
				"intro": "These words are used in the text. You will meet them again in the exercises.",
				"words": [
					"undisciplined",
					"pedestrians",
					"stunts",
					"dodging",
					"strategies",
					"appealing",
					"under-age",
					"impart",
					"reflectors",
					"pillion riders",
					"dangle",
					"distract"
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Words given in bold in these sentences have been taken from the text. Choose the correct meaning. The first one has been done as an example.",
				"items": [
					{
						"kind": "mcq",
						"q": "People who display undisciplined behaviour usually",
						"options": [
							"make rules",
							"break rules",
							"maintain rules"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Pedestrians are people who use the road for",
						"options": [
							"driving",
							"walking",
							"car racing"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Stunts are actions that are often",
						"options": [
							"foolish",
							"safe",
							"dangerous"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Beggars who can be seen dodging traffic are the ones who",
						"options": [
							"stop the traffic",
							"walk when the traffic stops",
							"walk in and out of moving traffic"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Different strategies can be used means that we can use different",
						"options": [
							"programmes",
							"ways of doing things",
							"thoughts"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Appealing programmes are the programmes that people",
						"options": [
							"always like to watch",
							"do not watch",
							"watch sometimes"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "For driving a car, under-age children are those who are less than",
						"options": [
							"10 years old",
							"14 years old",
							"18 years old"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Teachers impart education to the children means that they",
						"options": [
							"provide education",
							"support education",
							"stop education"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "At night, traffic police often wear jackets with reflectors because when light falls on them they",
						"options": [
							"shine",
							"turn black",
							"show the way"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "Pillion riders are those people on a cycle or motorbike who",
						"options": [
							"sit behind the driver",
							"stand and drive",
							"sit on the driver's seat"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "People who dangle their feet",
						"options": [
							"put them on the wheel",
							"hang them in the air",
							"keep them on the seat"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Passengers who distract the drivers",
						"options": [
							"warn them",
							"guide them",
							"take away their attention"
						],
						"answer": 2
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Work in pairs and complete the sentences with one of the words from Exercise 2. You can use one word only once.",
				"items": [
					{
						"kind": "fill",
						"q": "Parents must not allow ____ children to drive.",
						"answers": ["under-age", "underage"]
					},
					{
						"kind": "fill",
						"q": "Teachers use a number of ____ to help students learn well.",
						"answers": ["strategies"]
					},
					{
						"kind": "fill",
						"q": "If passengers ____ the driver there can be an accident.",
						"answers": ["distract"]
					},
					{
						"kind": "fill",
						"q": "The principal was upset with the ____ behaviour of the students.",
						"answers": ["undisciplined"]
					},
					{
						"kind": "fill",
						"q": "____ should not ask the drivers to drive fast.",
						"answers": ["Pillion riders", "pillion riders"]
					},
					{
						"kind": "fill",
						"q": "The ____ should not walk in the middle of the road.",
						"answers": ["pedestrians", "Pedestrians"]
					},
					{
						"kind": "fill",
						"q": "The motorcyclist was performing ____ when he had an accident.",
						"answers": ["stunts"]
					},
					{
						"kind": "fill",
						"q": "People sitting on a moving motorcycle should not ____ their feet.",
						"answers": ["dangle"]
					},
					{
						"kind": "fill",
						"q": "Companies try to make ____ advertisements to make people buy their products.",
						"answers": ["appealing"]
					},
					{
						"kind": "fill",
						"q": "Our teachers ____ education by telling us interesting stories during the morning assembly, once a week.",
						"answers": ["impart"]
					},
					{
						"kind": "fill",
						"q": "Crossing busy roads by ____ the traffic is dangerous.",
						"answers": ["dodging"]
					},
					{
						"kind": "fill",
						"q": "My brother has put ____ on his bicycle so that drivers of other vehicles can see him at night.",
						"answers": ["reflectors"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Quickly review the paragraphs and match them with the main ideas. One has been done as an example: \"Road accidents happen because people do not follow traffic rules\" is paragraph 1.",
				"items": [{
					"kind": "match",
					"pairs": [
						{
							"left": "The role of the media, school and traffic police",
							"right": "Paragraph 3"
						},
						{
							"left": "Textbooks and road safety",
							"right": "Paragraph 5"
						},
						{
							"left": "The role of parents in road safety",
							"right": "Paragraph 4"
						},
						{
							"left": "Road accidents happen because people do not follow traffic rules",
							"right": "Paragraph 1"
						},
						{
							"left": "Safety tips for road users",
							"right": "Paragraph 6"
						},
						{
							"left": "Three types of people are responsible for most accidents",
							"right": "Paragraph 2"
						}
					]
				}]
			},
			{
				"type": "h",
				"text": "Post Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "Read the following statements. Mark True or False. The first one has been done for you.",
				"items": [
					{
						"kind": "tf",
						"q": "If we follow the traffic rules, we can prevent deaths and injuries on the road.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Pedestrians are responsible for many of the recorded road accidents.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Most motorcyclists are very careful and drive slowly.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Awareness is possible only if we make traffic laws.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "The media can teach people about road safety only through news.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Both parents and schools have a duty to teach about road safety.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Stop, look, listen, think and cross is called the Green Cross Code.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Cyclists do not have to follow any rules.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Bus users must also follow rules.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Zebra crossings are safe points for crossing roads.",
						"answer": true
					}
				]
			},
			{
				"type": "words",
				"intro": "Exercise 6 word bank. Use each word only once. Paragraph 1: helmets, beggars, follow, accidents, carelessly, footpaths, play. Paragraph 2: motorcycles, education, interesting, cross, under-age, side, think, television, look, safety, different, walking. Paragraph 3: patiently, across, vehicles, extreme, citizens.",
				"words": [
					"helmets",
					"beggars",
					"follow",
					"accidents",
					"carelessly",
					"footpaths",
					"play",
					"motorcycles",
					"education",
					"interesting",
					"cross",
					"under-age",
					"side",
					"think",
					"television",
					"look",
					"safety",
					"different",
					"walking",
					"patiently",
					"across",
					"vehicles",
					"extreme",
					"citizens"
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "Work in pairs and complete the summary. Use one word from the bank only once. Then write the complete summary in your notebook.",
				"items": [
					{
						"kind": "fill",
						"q": "Many people die or are injured in road ____.",
						"answers": ["accidents"]
					},
					{
						"kind": "fill",
						"q": "This is because people do not ____ the road safety rules.",
						"answers": ["follow"]
					},
					{
						"kind": "fill",
						"q": "Pedestrians cross roads ____ and do not use the footpaths.",
						"answers": ["carelessly"]
					},
					{
						"kind": "fill",
						"q": "Pedestrians cross roads carelessly and do not use the ____.",
						"answers": ["footpaths"]
					},
					{
						"kind": "fill",
						"q": "Motorcyclists drive fast and do not wear ____.",
						"answers": ["helmets"]
					},
					{
						"kind": "fill",
						"q": "Children ____ in the streets, and beggars and people selling different things walk on the roads.",
						"answers": ["play"]
					},
					{
						"kind": "fill",
						"q": "Children play in the streets and ____ and people selling different things walk on the roads.",
						"answers": ["beggars"]
					},
					{
						"kind": "fill",
						"q": "People should be taught road ____ rules.",
						"answers": ["safety"]
					},
					{
						"kind": "fill",
						"q": "This can be done in ____ ways.",
						"answers": ["different"]
					},
					{
						"kind": "fill",
						"q": "Radio and ____ can teach road safety rules through interesting programmes.",
						"answers": ["television"]
					},
					{
						"kind": "fill",
						"q": "Radio and television can teach road safety rules through ____ programmes.",
						"answers": ["interesting"]
					},
					{
						"kind": "fill",
						"q": "Schools can have traffic ____ programmes.",
						"answers": ["education"]
					},
					{
						"kind": "fill",
						"q": "Parents should not allow ____ children to drive cars or motorcycles.",
						"answers": ["under-age", "underage"]
					},
					{
						"kind": "fill",
						"q": "Parents should not allow under-age children to drive cars or ____.",
						"answers": ["motorcycles"]
					},
					{
						"kind": "fill",
						"q": "Lessons in textbooks can teach simple rules like the \"Green ____ code\".",
						"answers": ["cross", "Cross"]
					},
					{
						"kind": "fill",
						"q": "The Green Cross code is stop, ____, listen, think and cross.",
						"answers": ["look"]
					},
					{
						"kind": "fill",
						"q": "The Green Cross code is stop, look, listen, ____ and cross.",
						"answers": ["think"]
					},
					{
						"kind": "fill",
						"q": "They can also teach rules about ____ on the footpath or the side of the road.",
						"answers": ["walking"]
					},
					{
						"kind": "fill",
						"q": "They can also teach rules about walking on the footpath or the ____ of the road if there is no footpath.",
						"answers": ["side"]
					},
					{
						"kind": "fill",
						"q": "All ____ can remain safe on the roads if they follow rules.",
						"answers": ["citizens"]
					},
					{
						"kind": "fill",
						"q": "Cyclists should stay on the ____ left of the road.",
						"answers": ["extreme"]
					},
					{
						"kind": "fill",
						"q": "Pedestrians should not run ____ the road.",
						"answers": ["across"]
					},
					{
						"kind": "fill",
						"q": "They should wait ____ and cross when it is safe.",
						"answers": ["patiently"]
					},
					{
						"kind": "fill",
						"q": "People should not get off moving ____.",
						"answers": ["vehicles"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 7",
				"instruction": "Work in pairs and discuss the questions. After the oral discussion, write the answers.",
				"items": [
					{
						"kind": "open",
						"q": "Which category of road user do you belong to? You can choose as many categories as you want from the four categories given in the table.",
						"model": "I am a pedestrian because I walk to school, and I am also a passenger because I sometimes use the school bus. The four categories are cyclists, pedestrians, users of school and public transport, and motorcycle pillion riders."
					},
					{
						"kind": "open",
						"q": "Are any of the rules from the category that you belong to new for you? Which one(s)?",
						"model": "Yes. I already knew that I should use a zebra crossing, but I had not learned the full Green Cross Code: stop, look, listen, think and cross. I also did not know that I must not cross when the traffic light for vehicles is green."
					},
					{
						"kind": "open",
						"q": "Many people do not follow all the rules that they already know. Why do you think this happens?",
						"model": "People are often in a hurry, or they think an accident will not happen to them. Some have never been taught the rules properly, and some copy the careless behaviour of others."
					},
					{
						"kind": "open",
						"q": "As a pillion rider, what two pieces of advice will you give to a motorcyclist?",
						"model": "Please wear a helmet, and do not drive fast or perform stunts. I will also hold on properly and I will not distract you."
					},
					{
						"kind": "open",
						"q": "Your brother usually walks home from work. Give him one suggestion that he can easily follow to remain safe from traffic accidents.",
						"model": "Use the footpath, and cross only at a zebra crossing by following the Green Cross Code: stop, look, listen, think and cross. Do not run across the road."
					}
				]
			}
		]
	},
	{
		"id": "3.2",
		"code": "3.2",
		"title": "Speaking",
		"subtitle": "Expressing Opinion",
		"kind": "speaking",
		"blocks": [
			{
				"type": "h",
				"text": "Asking for and Expressing Opinions"
			},
			{
				"type": "p",
				"text": "Read the following dialogues carefully. The bold words are used for asking opinions and the words in bold and italics are for expressing opinions."
			},
			{
				"type": "p",
				"text": "Practice these dialogues in groups of three. Practise this dialogue at least three times, each student taking turns to play each role."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Ahmed",
						"text": "What do you think about working part-time after school?"
					},
					{
						"who": "Sameer",
						"text": "It's a good idea! What do you say, Nadeem?"
					},
					{
						"who": "Nadeem",
						"text": "I like it, but I think our first responsibility is our education."
					},
					{
						"who": "Sameer",
						"text": "What is your opinion, Ahmed?"
					},
					{
						"who": "Ahmed",
						"text": "Well, I think it is indeed a good way to support our parents. But, yes, we must do it in a way that our studies are not affected."
					},
					{
						"who": "Nadeem",
						"text": "Yes, That's right. I agree with you."
					}
				]
			},
			{
				"type": "callout",
				"title": "Useful expressions",
				"text": "Asking for an opinion: What do you think about ...? What do you say, ...? What is your opinion, ...? Expressing an opinion: It's a good idea! I like it, but I think ... I think it is indeed ... But, yes, ... Yes, that's right. I agree with you."
			},
			{
				"type": "p",
				"text": "Now work in groups of three again and use the expressions given in the above situations to write short dialogues on any one of the following situations. After you have written the dialogue, practise this conversation in groups of three. Practise this dialogue at least three times, with each student taking turns to play each role."
			},
			{
				"type": "exercise",
				"title": "Practice Dialogues",
				"instruction": "Write a short dialogue of three friends. Use the expressions for asking and expressing opinions.",
				"items": [{
					"kind": "open",
					"q": "Three friends asking each other's opinion about taking tuitions to pass the exams.",
					"model": "Ahmed: What do you think about taking tuitions to pass the exams?\nSameer: It's a good idea! What do you say, Nadeem?\nNadeem: I like it, but I think our first responsibility is to pay attention in class.\nSameer: What is your opinion, Ahmed?\nAhmed: Well, I think tuitions are a good way to get help in a weak subject. But, yes, we must still do our school work ourselves.\nNadeem: Yes, that's right. I agree with you."
				}, {
					"kind": "open",
					"q": "Three friends asking each other's opinion about the use of mobile phones in schools.",
					"model": "Ahmed: What do you think about the use of mobile phones in schools?\nSameer: It's a good idea for finding information! What do you say, Nadeem?\nNadeem: I like it, but I think phones distract students during lessons.\nSameer: What is your opinion, Ahmed?\nAhmed: Well, I think a phone can help us in an emergency. But, yes, we must keep it silent in class so that our studies are not affected.\nNadeem: Yes, that's right. I agree with you."
				}]
			}
		]
	},
	{
		"id": "3.3",
		"code": "3.3",
		"title": "Language Practice",
		"subtitle": "Must, Must Not, and Imperative Sentences",
		"kind": "language",
		"blocks": [
			{
				"type": "h",
				"text": "Modal Verbs 'Must' and 'Mustn't'"
			},
			{
				"type": "callout",
				"title": "Rule: must and mustn't",
				"text": "The modal 'must' is usually used to show that doing something is very necessary; it has to be done. Whereas, 'mustn't' is used when we need to be careful not to do something because it is wrong, bad, or dangerous. Examples: We must wash our hands before our meals. The students mustn't be late for school."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Here is a list of ten things. Students must do five of these and mustn't do five. Choose the correct column for each one.",
				"items": [
					{
						"kind": "mcq",
						"q": "exercise regularly",
						"options": ["Must do", "Mustn't do"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "behave rudely",
						"options": ["Must do", "Mustn't do"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "shout in class",
						"options": ["Must do", "Mustn't do"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "study hard",
						"options": ["Must do", "Mustn't do"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "obey their teachers",
						"options": ["Must do", "Mustn't do"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "follow the school rules",
						"options": ["Must do", "Mustn't do"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "break the school furniture",
						"options": ["Must do", "Mustn't do"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "miss their classes",
						"options": ["Must do", "Mustn't do"],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "do their homework",
						"options": ["Must do", "Mustn't do"],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "write on the school wall or furniture",
						"options": ["Must do", "Mustn't do"],
						"answer": 1
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Work with a partner and discuss the statements. Then complete each one. More than one good ending is possible.",
				"items": [
					{
						"kind": "fill",
						"q": "A good friend must ____.",
						"answers": [
							"help you when you are in trouble",
							"stand by you in difficult times",
							"tell you the truth kindly",
							"help you in your studies"
						]
					},
					{
						"kind": "fill",
						"q": "A good friend mustn't ____.",
						"answers": [
							"break your trust",
							"laugh at you when you fail",
							"tell your secrets to others",
							"leave you when you need help"
						]
					},
					{
						"kind": "fill",
						"q": "A good teacher must ____.",
						"answers": [
							"explain the lesson clearly",
							"treat every student fairly",
							"help students who find the work difficult"
						]
					},
					{
						"kind": "fill",
						"q": "A good teacher mustn't ____.",
						"answers": [
							"insult the students",
							"ignore a student who needs help",
							"punish the whole class without a reason"
						]
					},
					{
						"kind": "fill",
						"q": "A good classmate must ____.",
						"answers": [
							"share notes when a friend is absent",
							"respect other students",
							"help others learn without making a noise"
						]
					},
					{
						"kind": "fill",
						"q": "A good classmate mustn't ____.",
						"answers": [
							"disturb the class",
							"make fun of a classmate",
							"copy someone else's homework and pretend it is his own"
						]
					},
					{
						"kind": "fill",
						"q": "A good brother or sister must ____.",
						"answers": [
							"help the younger ones",
							"share things fairly",
							"take care of brothers and sisters"
						]
					},
					{
						"kind": "fill",
						"q": "A good brother or sister mustn't ____.",
						"answers": [
							"quarrel all the time",
							"bully a younger brother or sister",
							"tell lies about each other"
						]
					},
					{
						"kind": "fill",
						"q": "A good parent must ____.",
						"answers": [
							"keep the children safe",
							"teach children road safety",
							"listen to the children"
						]
					},
					{
						"kind": "fill",
						"q": "A good parent mustn't ____.",
						"answers": [
							"allow under-age children to drive",
							"ignore the children's safety",
							"let children play on the road"
						]
					},
					{
						"kind": "fill",
						"q": "A good son or daughter must ____.",
						"answers": [
							"respect parents",
							"help with household work",
							"study hard and obey parents"
						]
					},
					{
						"kind": "fill",
						"q": "A good son or daughter mustn't ____.",
						"answers": [
							"answer parents rudely",
							"hide important things from parents",
							"neglect studies"
						]
					},
					{
						"kind": "fill",
						"q": "A good neighbour must ____.",
						"answers": [
							"help in times of need",
							"keep the street clean",
							"be polite and helpful"
						]
					},
					{
						"kind": "fill",
						"q": "A good neighbour mustn't ____.",
						"answers": [
							"throw garbage near another house",
							"make loud noise late at night",
							"quarrel over small matters"
						]
					},
					{
						"kind": "fill",
						"q": "A good citizen must ____.",
						"answers": [
							"follow traffic rules",
							"obey the law",
							"keep public places clean"
						]
					},
					{
						"kind": "fill",
						"q": "A good citizen mustn't ____.",
						"answers": [
							"break traffic signals",
							"damage public property",
							"throw rubbish on the road"
						]
					}
				]
			},
			{
				"type": "p",
				"text": "Work in groups of four. Identify at least three problems in your environment. Next, discuss at least two things that you must do and two things you mustn't do with respect to each problem. The first problem has been done as an example."
			},
			{
				"type": "table",
				"caption": "Problem No. 1: Garbage around the house",
				"headers": ["Must Do", "Mustn't Do"],
				"rows": [["Talk to the people to find a solution", "Throw garbage around the house"]]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Fill the table for two more problems. After the discussion, write what you must do and mustn't do. Then prepare a short speech for your classmates.",
				"items": [
					{
						"kind": "open",
						"q": "Problem No. 2: Write the problem, two things you must do, and two things you mustn't do.",
						"model": "Problem: Stagnant water near the street. Must do: 1. Tell the neighbours and ask the local office to drain the water. 2. Cover water pots so that mosquitoes cannot breed. Mustn't do: 1. Leave broken pots full of rainwater. 2. Throw rubbish into the standing water."
					},
					{
						"kind": "open",
						"q": "Problem No. 3: Write the problem, two things you must do, and two things you mustn't do.",
						"model": "Problem: Children playing on the road. Must do: 1. Ask them to play in a safe ground or park. 2. Teach them how to cross the road. Mustn't do: 1. Let young children play in the street. 2. Ignore fast traffic near the houses."
					},
					{
						"kind": "open",
						"q": "Prepare a short speech telling your classmates what problems your group identified and what you plan to do about them.",
						"model": "Assalam-o-Alaikum. Our group found three problems: garbage around the houses, stagnant water in the street, and children playing on the road. We must talk to people and find a solution, and we mustn't throw garbage around the house. We must cover water pots and ask the authorities to drain the street, and we mustn't leave rainwater in broken pots. We must teach children to play in a safe place, and we mustn't let them play on the road. In this way we can help our neighbours and make the street safer."
					}
				]
			},
			{
				"type": "h",
				"text": "Imperative Sentences"
			},
			{
				"type": "callout",
				"title": "Rule: imperative sentences",
				"text": "One kind of sentence in English is the imperative. Imperative sentences begin with a verb. Read the following sentences: Come here. Give me your pen. Pass the salt. Imperatives are used to make informal requests, as in the sentences above. Imperatives are also used to provide instructions, to give directions and to state rules. For example: Print on both sides of the sheet. Turn right at the traffic signal. Fasten seat belts."
			},
			{
				"type": "note",
				"text": "Start each instruction or class rule with a verb. Do not begin with \"You should\"."
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Your mother is sick, so you offer to wash the dishes. Complete her instructions with these verbs. Use each verb only once: scrub, wash, dry, separate, keep, apply, take, rinse. The first one has been done as an example.",
				"items": [
					{
						"kind": "fill",
						"q": "____ all the utensils, glasses, dishes etc. to the washing area.",
						"answers": ["Take", "take"]
					},
					{
						"kind": "fill",
						"q": "____ them into different piles.",
						"answers": ["Separate", "separate"]
					},
					{
						"kind": "fill",
						"q": "____ the small things, like spoons, bowls and things made of glass first.",
						"answers": ["Wash", "wash"]
					},
					{
						"kind": "fill",
						"q": "____ soap to all the things mentioned above and then rinse them with water.",
						"answers": ["Apply", "apply"]
					},
					{
						"kind": "fill",
						"q": "____ all the other utensils properly using the washing powder and soap.",
						"answers": ["Scrub", "scrub"]
					},
					{
						"kind": "fill",
						"q": "____ all the scrubbed utensils one by one.",
						"answers": ["Rinse", "rinse"]
					},
					{
						"kind": "fill",
						"q": "____ them with a clean towel.",
						"answers": ["Dry", "dry"]
					},
					{
						"kind": "fill",
						"q": "____ them in their proper place.",
						"answers": ["Keep", "keep"]
					}
				]
			},
			{
				"type": "h",
				"text": "Exercise 5 — Making and Serving Tea"
			},
			{
				"type": "p",
				"text": "Look at the pictures and write appropriate sentences to instruct your younger brother or sister on how to make tea and serve it to the guests. Take only the words you need from Groups 1 and 2. Use all the words in Group 3. Begin every instruction with a verb."
			},
			{
				"type": "table",
				"caption": "Word Bank",
				"headers": ["Group", "Words"],
				"rows": [
					["Group 1: things you will need", "plate, pan, kettle, cup, mug, spoon, tray, stove"],
					["Group 2: things for making and serving tea", "biscuits, water, sugar, tea leaves, tea bags, milk"],
					["Group 3: action words (use all of these)", "boil, pour, stir, add, take, heat, put, serve, fill"]
				]
			},
			{
				"type": "p",
				"text": "The seven pictures show these steps: (1) water is poured from a kettle into a pan; (2) tea leaves are added with a spoon; (3) milk is poured in; (4) the tea is stirred on the stove for three minutes; (5) the tea is poured into a cup; (6) cups and a teapot are placed on a tray; (7) tea and biscuits are ready to serve."
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "Complete the instructions. Each blank is one verb from Group 3, and every Group 3 verb is used once.",
				"items": [
					{
						"kind": "fill",
						"q": "____ a pan, a kettle, cups, a spoon, a tray, tea leaves, milk, sugar and biscuits.",
						"answers": ["Take", "take"]
					},
					{
						"kind": "fill",
						"q": "____ the kettle with water.",
						"answers": ["Fill", "fill"]
					},
					{
						"kind": "fill",
						"q": "____ the pan on the stove.",
						"answers": ["Put", "put"]
					},
					{
						"kind": "fill",
						"q": "____ the water on the stove.",
						"answers": ["Heat", "heat"]
					},
					{
						"kind": "fill",
						"q": "____ the water.",
						"answers": ["Boil", "boil"]
					},
					{
						"kind": "fill",
						"q": "____ tea leaves, milk and sugar.",
						"answers": ["Add", "add"]
					},
					{
						"kind": "fill",
						"q": "____ the tea for three minutes.",
						"answers": ["Stir", "stir"]
					},
					{
						"kind": "fill",
						"q": "____ the tea into the cups.",
						"answers": ["Pour", "pour"]
					},
					{
						"kind": "fill",
						"q": "____ the tea and biscuits to the guests.",
						"answers": ["Serve", "serve"]
					}
				]
			},
			{
				"type": "p",
				"text": "Imagine your class has a new teacher. He or she wants the class to help make some rules that all the students must follow. Work in groups of three and prepare a list of 4–6 rules. One example has been given: Wear neat and clean uniforms."
			},
			{
				"type": "list",
				"ordered": false,
				"items": ["Wear neat and clean uniforms."]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "Write four to six classroom rules. Start each rule with a verb.",
				"items": [{
					"kind": "open",
					"q": "Write 4–6 rules that students must follow in class. Begin each rule with a verb. You may keep the given example.",
					"model": "1. Wear neat and clean uniforms.\n2. Reach school on time.\n3. Listen to the teacher carefully.\n4. Keep the classroom clean.\n5. Raise your hand before you speak.\n6. Do your homework every day."
				}]
			}
		]
	},
	{
		"id": "3.4",
		"code": "3.4",
		"title": "Writing",
		"subtitle": "A Formal Email",
		"kind": "writing",
		"blocks": [
			{
				"type": "h",
				"text": "Writing a Formal Email"
			},
			{
				"type": "p",
				"text": "Read the given sample of email and notice these points."
			},
			{
				"type": "list",
				"ordered": false,
				"items": [
					"An email has certain sections at the top: To, cc, subject.",
					"Both you and the person to whom you send an email have an email address. For example, bilawal.nadeem@yahoo.com OR chairman@uc.dadu.com.",
					"In the 'To' column you write the email address of the person to whom you are writing the email.",
					"If you want to send a copy to other people you write their email address in the 'cc' column. For example, samnal88@gmail.com.",
					"Write the salutation.",
					"Come straight to the point.",
					"State who you are, what you want and why.",
					"Formally request for the same.",
					"Write the concluding remarks.",
					"End appropriately.",
					"Write your full name."
				]
			},
			{
				"type": "h",
				"text": "Sample Email"
			},
			{
				"type": "p",
				"text": "To: chairman@uc.dadu.com"
			},
			{
				"type": "p",
				"text": "Cc: samnal88@gmail.com"
			},
			{
				"type": "p",
				"text": "Subject: request for Residence Certificate"
			},
			{
				"type": "p",
				"text": "Dear Sir,"
			},
			{
				"type": "p",
				"text": "I am a resident of Muslimabad, Muhalla Mehar, District Dadu. I have been living here since the last ten years. I want to appear for an entry test at the Liaquat University of Medical and Health Sciences (LUMHS), Jamshoro. For this purpose I have to submit a Residence Certificate along with the form."
			},
			{
				"type": "p",
				"text": "In this regard, I would like to request you to kindly issue me a Residence Certificate so that I can submit my entry form within the given time."
			},
			{
				"type": "p",
				"text": "Looking forward to your kind consideration."
			},
			{
				"type": "p",
				"text": "Yours Sincerely,"
			},
			{
				"type": "p",
				"text": "Bilawal Nadeem"
			},
			{
				"type": "table",
				"caption": "Words you can use in a formal email",
				"headers": ["Section of email", "Some words that can be used"],
				"rows": [
					["Begin with a salutation", "Dear Madam or Sir; Dear Ms/Mr … (if you know the name)"],
					["State your purpose", "I am writing to ask you …; I would like to request you …; I would like to inform you …; I would appreciate if you …; With reference to our telephonic conversation; I am writing in reference to …"],
					["Conclusion", "Thank you for your cooperation.; Thank you for your kind consideration.; I look forward to hearing from you."],
					["Close, before your name", "Yours sincerely; Yours faithfully; Respectfully"]
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Work in pairs and write a formal email to the traffic department to arrange a road safety awareness programme in your school. Follow all the steps explained earlier. After you have written, exchange your email with another pair and read their email.",
				"items": [{
					"kind": "open",
					"q": "Write a formal email to the traffic department asking them to arrange a road safety awareness programme in your school.",
					"model": "To: traffic.department@sindh.gov.pk\nCc: principal@ourschool.edu.pk\nSubject: Request for a road safety awareness programme\n\nDear Madam or Sir,\n\nI am a student of Class 8. I am writing to request you to arrange a road safety awareness programme in our school. Many of us walk, cycle, or travel by bus and motorcycle. We need to learn the rules so that we can prevent accidents.\n\nI would appreciate it if your officers could visit our school and teach the rules for pedestrians, cyclists, passengers and pillion riders.\n\nThank you for your kind consideration. I look forward to hearing from you.\n\nYours faithfully,\nAyesha Khan"
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Work individually and write a formal email to any one of the following. Follow all the steps. Use the words in the table above. After you have written, exchange your email with your partner.",
				"items": [{
					"kind": "open",
					"q": "Write to the Nazim of the city or town, asking him or her to ensure that people know the Traffic Safety rules before they are given a driving licence.",
					"model": "To: nazim@city.gov.pk\nCc: traffic.police@city.gov.pk\nSubject: Request to teach traffic rules before issuing a driving licence\n\nDear Madam or Sir,\n\nI am a resident of this city and a student of Class 8. I am writing to request you to make sure that people know the traffic safety rules before they are given a driving licence. Many accidents happen because drivers, motorcyclists and pedestrians do not follow the rules.\n\nI would appreciate it if every applicant were given a short lesson on road safety, including the use of helmets and the duty not to drive without a licence.\n\nThank you for your cooperation. I look forward to hearing from you.\n\nYours sincerely,\nBilal Ahmed"
				}, {
					"kind": "open",
					"q": "Write to a news channel, asking it to produce some entertaining TV programmes on traffic safety.",
					"model": "To: editor@news-channel.com\nSubject: Request for entertaining programmes on traffic safety\n\nDear Madam or Sir,\n\nI am a Class 8 student. I am writing to request you to produce some entertaining television programmes on traffic safety. Appealing programmes can teach pedestrians, cyclists and drivers the rules in a way that people like to watch.\n\nI would like to suggest short stories about helmets, zebra crossings and the Green Cross Code: stop, look, listen, think and cross.\n\nThank you for your kind consideration.\n\nYours faithfully,\nHina Noor"
				}]
			}
		]
	},
	{
		"id": "3.5",
		"code": "3.5",
		"title": "Study Skills",
		"subtitle": "Delivering a Presentation",
		"kind": "study",
		"blocks": [
			{
				"type": "h",
				"text": "Extended Outline"
			},
			{
				"type": "p",
				"text": "You have learned in Unit 1 how to prepare a basic outline. Now it is time to practise extended outlines. Such outlines will help you add the appropriate details that you require to express your ideas."
			},
			{
				"type": "p",
				"text": "Here is a sample of how an outline is formatted."
			},
			{
				"type": "list",
				"ordered": false,
				"items": [
					"Title",
					"Introduction",
					"A. Greeting",
					"B. Introductory statements",
					"C. The objective or purpose of the presentation",
					"First main point",
					"A. Supporting point 1 + details, if any",
					"B. Supporting point 2 + details, if any",
					"C. Supporting point 3 + details, if any",
					"Second main point",
					"A. Supporting point 1 + details, if any",
					"B. Supporting point 2 + details, if any",
					"C. Supporting point 3 + details, if any",
					"Conclusion",
					"A. Concluding words (In the end, Finally, To sum up, etc.)",
					"B. Summary of main points",
					"C. Suggestions / ideas / recommendations",
					"Note: You can have any number of points and any number of supporting points and details."
				]
			},
			{
				"type": "note",
				"text": "In conclusion point C you have a choice: give a suggestion, an idea, or a recommendation. Every member of the group should speak in the presentation."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Work in groups of three. Prepare a presentation outline on one of the topics. Then give a group presentation. Steps: brainstorm; select the main points; decide the supporting points; choose details such as examples, reasons, facts, a short story, an incident or a small joke; follow the outline format; check the language; ask your teacher for help. After the outline is ready, decide who will present which part and practise the handover.",
				"items": [{
					"kind": "open",
					"q": "Prepare an extended presentation outline on one of these topics: (1) The Importance of Reading (2) Three Places in Pakistan that Students Should Visit (3) Why Should We Learn English.",
					"model": "Title: The Importance of Reading\n\nIntroduction\nA. Greeting: Assalam-o-Alaikum. Good morning, respected teacher and dear classmates.\nB. Introductory statements: We see words on signs, in books and in the news, yet many of us do not read to learn.\nC. Purpose: Today we will explain why reading is important for students.\n\nFirst main point: Reading builds knowledge\nA. Books and newspapers tell us about the world. A news item, for example, can teach us about a road accident and how to avoid one.\nB. Lessons become easier when we read them again at home.\nC. A textbook can even teach the Green Cross Code and keep us safe.\n\nSecond main point: Reading builds language and character\nA. It adds new words and improves spelling.\nB. Stories help us understand other people's feelings.\nC. A student who reads can speak more confidently in a class presentation.\n\nConclusion\nA. To sum up,\nB. Reading gives knowledge, strengthens language and shapes character.\nC. Suggestion: Let us read for twenty minutes every day and share one new idea with the class each week."
				}]
			}
		]
	},
	{
		"id": "3.6",
		"code": "3.6",
		"title": "Fun",
		"subtitle": "Reading the News",
		"kind": "fun",
		"blocks": [
			{
				"type": "h",
				"text": "Reading the News"
			},
			{
				"type": "p",
				"text": "Work in pairs. Read the given news items and fill the details in the table, as required. The pair that finishes first and fills all columns correctly will win."
			},
			{
				"type": "h",
				"text": "News 1: Express News"
			},
			{
				"type": "p",
				"text": "Hyderabad, Dec 5: At least five people, including two children, were killed in a car-motorcycle collision during rain in Shahdadkot, in Sindh."
			},
			{
				"type": "h",
				"text": "News 2: DAWN"
			},
			{
				"type": "p",
				"text": "Rawalpindi, Jan 21: For the first time, women's transport service has been launched between the twin cities of Rawalpindi and Islamabad. Women will now be able to travel using comfortable, safe and affordable transportation facilities from Monday, February 4, 2014."
			},
			{
				"type": "h",
				"text": "News 3: The Nation"
			},
			{
				"type": "p",
				"text": "Karachi, Aug 5: The Karachi Traffic police authorities have announced that people breaking some of the traffic rules will now be put in prison for up to two years. The punishment will apply to those who break traffic signals, disobey one-way traffic signs, and travel on the rooftop of buses and coaches."
			},
			{
				"type": "exercise",
				"title": "News Details",
				"instruction": "Fill each column from the news items. The city is the place named in the dateline, before the date. The accident or event may be in another town.",
				"items": [
					{
						"kind": "fill",
						"q": "News 1 — Name of newspaper: ____",
						"answers": ["Express News", "express news"]
					},
					{
						"kind": "fill",
						"q": "News 1 — City from where reported: ____",
						"answers": ["Hyderabad"],
						"hint": "The dateline is Hyderabad, Dec 5. Shahdadkot is where the collision happened."
					},
					{
						"kind": "fill",
						"q": "News 1 — Date of reporting: ____",
						"answers": [
							"Dec 5",
							"December 5",
							"5 December",
							"Dec. 5"
						]
					},
					{
						"kind": "fill",
						"q": "News 1 — Who is mentioned? ____",
						"answers": [
							"at least five people, including two children",
							"five people, including two children",
							"At least five people, including two children"
						]
					},
					{
						"kind": "fill",
						"q": "News 1 — What has been reported? ____",
						"answers": [
							"They were killed in a car-motorcycle collision during rain in Shahdadkot, Sindh.",
							"Five people were killed in a car-motorcycle collision in Shahdadkot.",
							"A car-motorcycle collision in the rain killed at least five people in Shahdadkot."
						]
					},
					{
						"kind": "fill",
						"q": "News 2 — Name of newspaper: ____",
						"answers": [
							"DAWN",
							"Dawn",
							"dawn"
						]
					},
					{
						"kind": "fill",
						"q": "News 2 — City from where reported: ____",
						"answers": ["Rawalpindi"]
					},
					{
						"kind": "fill",
						"q": "News 2 — Date of reporting: ____",
						"answers": [
							"Jan 21",
							"January 21",
							"21 January",
							"Jan. 21"
						]
					},
					{
						"kind": "fill",
						"q": "News 2 — Who is mentioned? ____",
						"answers": ["women", "Women"]
					},
					{
						"kind": "fill",
						"q": "News 2 — What has been reported? ____",
						"answers": [
							"A women's transport service has been launched between Rawalpindi and Islamabad.",
							"Women's transport will run between the twin cities from 4 February 2014.",
							"For the first time, a safe and affordable women's transport service has started between Rawalpindi and Islamabad."
						]
					},
					{
						"kind": "fill",
						"q": "News 3 — Name of newspaper: ____",
						"answers": ["The Nation", "the nation"]
					},
					{
						"kind": "fill",
						"q": "News 3 — City from where reported: ____",
						"answers": ["Karachi"]
					},
					{
						"kind": "fill",
						"q": "News 3 — Date of reporting: ____",
						"answers": [
							"Aug 5",
							"August 5",
							"5 August",
							"Aug. 5"
						]
					},
					{
						"kind": "fill",
						"q": "News 3 — Who is mentioned? ____",
						"answers": [
							"Karachi Traffic police authorities and people who break traffic rules",
							"the Karachi Traffic police and rule-breakers",
							"Karachi Traffic police authorities"
						]
					},
					{
						"kind": "fill",
						"q": "News 3 — What has been reported? ____",
						"answers": [
							"People who break some traffic rules may be put in prison for up to two years.",
							"Breaking signals, disobeying one-way signs, or riding on bus rooftops can bring up to two years in prison.",
							"The traffic police announced prison of up to two years for some traffic offences."
						]
					}
				]
			}
		]
	}
];
var vocab$4 = [
	{
		"word": "undisciplined",
		"pos": "adjective",
		"meaning": "Not willing to obey rules, so behaviour becomes disorderly and unsafe.",
		"urdu": "بے ترتیب؛ قواعد نہ ماننے والا",
		"synonyms": [
			"unruly",
			"disorderly",
			"disobedient"
		],
		"antonyms": [
			"disciplined",
			"obedient",
			"orderly"
		],
		"sentences": ["Undisciplined road users cause traffic accidents and put other people in danger."]
	},
	{
		"word": "pedestrian",
		"pos": "noun",
		"meaning": "A person who walks along or across a road instead of travelling in a vehicle.",
		"urdu": "پیدل چلنے والا",
		"synonyms": ["walker", "person on foot"],
		"antonyms": ["driver", "motorist"],
		"sentences": ["Pedestrians should walk on the footpath and use a zebra crossing."]
	},
	{
		"word": "stunt",
		"pos": "noun",
		"meaning": "A dangerous action performed to show skill or to attract attention.",
		"urdu": "خطرناک کرتب",
		"synonyms": [
			"trick",
			"dangerous feat",
			"dare"
		],
		"antonyms": ["safe action", "careful behaviour"],
		"sentences": ["The motorcyclist was performing a stunt when he had an accident."]
	},
	{
		"word": "dodge",
		"pos": "verb",
		"meaning": "To move quickly in and out of the way, especially through moving traffic.",
		"urdu": "چلتی ٹریفک کے بیچ سے ادھر ادھر نکلنا",
		"synonyms": [
			"evade",
			"sidestep",
			"duck"
		],
		"antonyms": ["meet head-on", "stay still"],
		"sentences": ["Crossing a busy road by dodging the traffic is dangerous."]
	},
	{
		"word": "strategy",
		"pos": "noun",
		"meaning": "A planned way of doing something in order to reach a goal.",
		"urdu": "طریقہ کار؛ حکمتِ عملی",
		"synonyms": [
			"method",
			"plan",
			"approach"
		],
		"antonyms": ["aimlessness", "guesswork"],
		"sentences": ["Teachers use a number of strategies to help students learn well."]
	},
	{
		"word": "appealing",
		"pos": "adjective",
		"meaning": "Attractive and pleasant, so that people like to watch or notice it.",
		"urdu": "دل کش؛ پسند آنے والا",
		"synonyms": [
			"attractive",
			"pleasing",
			"engaging"
		],
		"antonyms": [
			"dull",
			"unattractive",
			"boring"
		],
		"sentences": ["The media can teach road safety through appealing programmes."]
	},
	{
		"word": "under-age",
		"pos": "adjective",
		"meaning": "Younger than the legal age required for something, such as driving a vehicle.",
		"urdu": "کم عمر؛ قانونی عمر سے چھوٹا",
		"synonyms": [
			"underage",
			"too young",
			"minor"
		],
		"antonyms": [
			"of age",
			"adult",
			"old enough"
		],
		"sentences": ["Parents must not allow under-age children to drive a car or a motorcycle."]
	},
	{
		"word": "impart",
		"pos": "verb",
		"meaning": "To give knowledge, information or a skill to someone else.",
		"urdu": "دینا؛ منتقل کرنا",
		"synonyms": [
			"give",
			"convey",
			"pass on"
		],
		"antonyms": ["withhold", "conceal"],
		"sentences": ["Textbooks can impart traffic education through simple lessons such as the Green Cross Code."]
	},
	{
		"word": "reflector",
		"pos": "noun",
		"meaning": "A bright device that shines when light falls on it, so that others can see it in the dark.",
		"urdu": "عکاس؛ روشنی لوٹانے والی چیز",
		"synonyms": ["reflecting strip", "shining marker"],
		"antonyms": ["dark covering", "non-reflective surface"],
		"sentences": ["Have lights or reflectors on your bicycle if you ride at night."]
	},
	{
		"word": "pillion",
		"pos": "noun",
		"meaning": "The seat behind the rider of a motorcycle or bicycle, used by a passenger.",
		"urdu": "موٹر سائیکل کی پچھلی سیٹ",
		"synonyms": ["rear seat", "passenger seat"],
		"antonyms": ["driver's seat", "front seat"],
		"sentences": ["A pillion rider should wear a helmet and should not ask the driver to go fast."]
	},
	{
		"word": "dangle",
		"pos": "verb",
		"meaning": "To hang or swing something loosely in the air, especially one's feet.",
		"urdu": "لٹکانا",
		"synonyms": [
			"hang",
			"swing",
			"suspend"
		],
		"antonyms": ["hold still", "keep steady"],
		"sentences": ["People sitting on a moving motorcycle should not dangle their feet."]
	},
	{
		"word": "distract",
		"pos": "verb",
		"meaning": "To take someone's attention away from what that person should be doing.",
		"urdu": "توجہ ہٹانا",
		"synonyms": [
			"divert",
			"disturb",
			"sidetrack"
		],
		"antonyms": ["focus", "concentrate"],
		"sentences": ["If passengers distract the driver, there can be an accident."]
	},
	{
		"word": "injured",
		"pos": "adjective",
		"meaning": "Physically hurt, as a person is hurt in a road accident.",
		"urdu": "زخمی",
		"synonyms": [
			"hurt",
			"wounded",
			"harmed"
		],
		"antonyms": [
			"unhurt",
			"safe",
			"unharmed"
		],
		"sentences": ["Many people die or are seriously injured because they do not follow road safety rules."]
	},
	{
		"word": "footpath",
		"pos": "noun",
		"meaning": "A path at the side of a road meant for people who are walking.",
		"urdu": "فٹ پاتھ؛ پیدل راستہ",
		"synonyms": ["pavement", "sidewalk"],
		"antonyms": ["roadway", "carriageway"],
		"sentences": ["If a footpath is available, pedestrians should walk on it and not on the road."]
	},
	{
		"word": "grief",
		"pos": "noun",
		"meaning": "Deep sadness, such as the sorrow a family feels after a serious accident.",
		"urdu": "غم؛ رنج",
		"synonyms": [
			"sorrow",
			"sadness",
			"heartache"
		],
		"antonyms": [
			"joy",
			"happiness",
			"relief"
		],
		"sentences": ["Safe roads protect families from the grief and harm that accidents cause."]
	},
	{
		"word": "licence",
		"pos": "noun",
		"meaning": "An official paper that allows a person to drive a vehicle.",
		"urdu": "لائسنس؛ ڈرائیونگ کا اجازت نامہ",
		"synonyms": [
			"permit",
			"driving permit",
			"authorization"
		],
		"antonyms": ["ban", "prohibition"],
		"sentences": ["They must not allow their children to drive without a driving licence."]
	},
	{
		"word": "aware",
		"pos": "adjective",
		"meaning": "Knowing about something and understanding why it is important.",
		"urdu": "آگاہ؛ واقف",
		"synonyms": [
			"informed",
			"conscious",
			"alert"
		],
		"antonyms": [
			"unaware",
			"ignorant",
			"heedless"
		],
		"sentences": ["Citizens, especially children, benefit from being aware of traffic rules."]
	},
	{
		"word": "media",
		"pos": "noun",
		"meaning": "Radio, television and other means of giving information to a large number of people.",
		"urdu": "ذرائعِ ابلاغ",
		"synonyms": [
			"press",
			"broadcasting",
			"mass media"
		],
		"antonyms": ["silence", "secrecy"],
		"sentences": ["The media, both radio and television, can give people road safety instructions."]
	},
	{
		"word": "prevent",
		"pos": "verb",
		"meaning": "To stop something bad from happening.",
		"urdu": "روکنا؛ وقوع سے بچانا",
		"synonyms": [
			"stop",
			"avert",
			"avoid"
		],
		"antonyms": [
			"allow",
			"cause",
			"permit"
		],
		"sentences": ["Following traffic rules can help prevent many deaths and injuries on the road."]
	},
	{
		"word": "citizen",
		"pos": "noun",
		"meaning": "A member of a country or community who shares its duties, including the duty to use roads safely.",
		"urdu": "شہری",
		"synonyms": [
			"resident",
			"national",
			"member of the public"
		],
		"antonyms": ["outsider", "foreigner"],
		"sentences": ["All citizens can remain safer if they follow the rules for their kind of road use."]
	},
	{
		"word": "weave",
		"pos": "verb",
		"meaning": "To move in and out of traffic instead of keeping a straight, safe line.",
		"urdu": "ٹریفک کے بیچ سے سرکنا",
		"synonyms": [
			"zigzag",
			"thread through",
			"wind"
		],
		"antonyms": ["go straight", "stay in line"],
		"sentences": ["Cyclists must not weave in and out of traffic."]
	},
	{
		"word": "footboard",
		"pos": "noun",
		"meaning": "The narrow step at the door of a bus, where it is dangerous to stand while the bus is moving.",
		"urdu": "بس کا پاؤں رکھنے والا تختہ",
		"synonyms": ["running board", "door step"],
		"antonyms": ["no direct antonym"],
		"sentences": ["A man hanging on the footboard of a bus can fall and be badly hurt."]
	},
	{
		"word": "collision",
		"pos": "noun",
		"meaning": "A crash in which moving vehicles hit each other.",
		"urdu": "ٹکر؛ تصادم",
		"synonyms": [
			"crash",
			"smash",
			"impact"
		],
		"antonyms": ["near miss", "safe passing"],
		"sentences": ["Five people were killed in a car-motorcycle collision during rain in Shahdadkot."]
	},
	{
		"word": "overloaded",
		"pos": "adjective",
		"meaning": "Carrying more passengers or goods than is safe or allowed.",
		"urdu": "حد سے زیادہ بھری ہوئی",
		"synonyms": [
			"overcrowded",
			"overfilled",
			"overburdened"
		],
		"antonyms": [
			"empty",
			"light",
			"underloaded"
		],
		"sentences": ["An overloaded bus is hard to control and is dangerous for everyone on the road."]
	},
	{
		"word": "responsible",
		"pos": "adjective",
		"meaning": "Being a cause of something, or having a duty to look after it.",
		"urdu": "ذمہ دار",
		"synonyms": [
			"accountable",
			"liable",
			"answerable"
		],
		"antonyms": ["blameless", "uninvolved"],
		"sentences": ["Truck drivers, bus drivers and even pedestrians are responsible for some accidents."]
	},
	{
		"word": "benefit",
		"pos": "verb",
		"meaning": "To receive something good from an action or from knowledge.",
		"urdu": "فائدہ اٹھانا",
		"synonyms": [
			"gain",
			"profit",
			"be helped"
		],
		"antonyms": [
			"suffer",
			"lose",
			"be harmed"
		],
		"sentences": ["Children can benefit a lot from learning how to cross the road safely."]
	},
	{
		"word": "affordable",
		"pos": "adjective",
		"meaning": "Cheap enough for ordinary people to be able to pay for it.",
		"urdu": "سستا؛ جیب پر آسان",
		"synonyms": [
			"inexpensive",
			"low-cost",
			"reasonable"
		],
		"antonyms": [
			"expensive",
			"costly",
			"unaffordable"
		],
		"sentences": ["The new service gives women comfortable, safe and affordable transport."]
	},
	{
		"word": "authority",
		"pos": "noun",
		"meaning": "A person or office that has the official power to make and enforce rules.",
		"urdu": "حکام؛ بااختیار ادارہ",
		"synonyms": ["officials", "administration"],
		"antonyms": ["no direct antonym"],
		"sentences": ["The traffic police authorities announced that some rule-breakers may be sent to prison."]
	},
	{
		"word": "punishment",
		"pos": "noun",
		"meaning": "A penalty given to a person who breaks a law or a rule.",
		"urdu": "سزا",
		"synonyms": [
			"penalty",
			"sentence",
			"sanction"
		],
		"antonyms": ["reward", "pardon"],
		"sentences": ["The punishment for breaking a traffic signal may be prison for up to two years."]
	},
	{
		"word": "launch",
		"pos": "verb",
		"meaning": "To start something new and make it available to the public.",
		"urdu": "شروع کرنا؛ جاری کرنا",
		"synonyms": [
			"start",
			"begin",
			"introduce"
		],
		"antonyms": [
			"end",
			"stop",
			"close"
		],
		"sentences": ["A women's transport service has been launched between Rawalpindi and Islamabad."]
	},
	{
		"word": "salutation",
		"pos": "noun",
		"meaning": "The greeting that opens a letter or an email, such as Dear Sir.",
		"urdu": "سلام؛ خط یا ای میل کا آغاز",
		"synonyms": ["greeting", "opening"],
		"antonyms": ["closing", "ending"],
		"sentences": ["Write the salutation before you come to the point of a formal email."]
	},
	{
		"word": "consideration",
		"pos": "noun",
		"meaning": "Careful and kind attention given to a request.",
		"urdu": "غور؛ توجہ",
		"synonyms": [
			"attention",
			"regard",
			"thought"
		],
		"antonyms": ["neglect", "disregard"],
		"sentences": ["The writer ended the email by looking forward to the chairman's kind consideration."]
	},
	{
		"word": "carelessly",
		"pos": "adverb",
		"meaning": "In a way that shows little attention to safety or to the result of one's actions.",
		"urdu": "لاپرواہی سے",
		"synonyms": [
			"recklessly",
			"thoughtlessly",
			"heedlessly"
		],
		"antonyms": [
			"carefully",
			"cautiously",
			"safely"
		],
		"sentences": ["Under-age drivers often drive too fast and carelessly."]
	},
	{
		"word": "adopt",
		"pos": "verb",
		"meaning": "To choose a plan or method and begin to use it.",
		"urdu": "اختیار کرنا",
		"synonyms": [
			"take up",
			"choose",
			"accept"
		],
		"antonyms": [
			"reject",
			"abandon",
			"drop"
		],
		"sentences": ["A number of strategies can be adopted to make road users aware of safety."]
	},
	{
		"word": "zebra crossing",
		"pos": "noun",
		"meaning": "A marked place on a road, with broad stripes, where people should cross.",
		"urdu": "زیبرا کراسنگ؛ سڑک پار کرنے کی نشان زدہ جگہ",
		"synonyms": ["pedestrian crossing", "crossing"],
		"antonyms": ["no direct antonym"],
		"sentences": ["Pedestrians should use zebra crossings and wait for a safe time to cross."]
	}
];
var unit3_default = {
	id: "u3",
	number: 3,
	title: title$4,
	learn: learn$4,
	lessons: lessons$4,
	vocab: vocab$4
};
var unit4_exports = /* @__PURE__ */ __exportAll({
	default: () => unit4_default,
	id: () => "u4",
	learn: () => learn$3,
	lessons: () => lessons$3,
	number: () => 4,
	title: () => title$3,
	vocab: () => vocab$3
});
var title$3 = "Exploring Educational Opportunities";
var learn$3 = [
	{
		"skill": "Reading",
		"points": [
			"Use pre-reading strategies to predict the content of a text by using prior knowledge and asking questions",
			"Infer the theme/ main idea",
			"Scan to answer short questions",
			"Make simple inferences using the context of the text and prior knowledge",
			"Deduce the meanings of difficult words from context",
			"Read silently with comprehension and extract main idea and supporting details.",
			"Apply world knowledge and own feelings / opinions to the text read."
		]
	},
	{
		"skill": "Speaking",
		"points": ["Use the conventions and dynamics of group discussion and interaction to identify problems, propose solutions"]
	},
	{
		"skill": "Language Practice",
		"points": ["Recognize the rules of, and change the narration of statements", "Adverbs of Manner"]
	},
	{
		"skill": "Writing",
		"points": ["Write a simple unified narrative paragraph on a given topic", "Use chronological/sequential/ spatial order of arranging details"]
	},
	{
		"skill": "Study Skills",
		"points": ["Learning language by designing and writing flyers"]
	},
	{
		"skill": "Fun",
		"points": ["Reciting a poem in groups."]
	}
];
var lessons$3 = [
	{
		"id": "4.1",
		"code": "4.1",
		"title": "Reading Comprehension",
		"subtitle": "Educational Exhibition",
		"kind": "reading",
		"blocks": [
			{
				"type": "h",
				"text": "Pre-Reading"
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Work in pairs and write down any five professions that you can think of.",
					"Choose one profession that you would like to take up in the future.",
					"Tell your partner why you want to take up that profession.",
					"We are going to read a text titled EDUCATIONAL EXHIBITION. Guess what the text is about."
				]
			},
			{
				"type": "exercise",
				"title": "Before you read",
				"items": [
					{
						"kind": "open",
						"q": "Write any five professions you can think of.",
						"model": "Doctor, teacher, farmer, engineer and bank manager."
					},
					{
						"kind": "open",
						"q": "Which profession would you like to take up, and why?",
						"model": "I would like to become an engineer because I enjoy finding out how machines work, and engineering has a good scope in Pakistan."
					},
					{
						"kind": "open",
						"q": "What do you think a text titled Educational Exhibition will be about?",
						"model": "It will be about a school exhibition where students and parents visit stalls and learn about different studies and future jobs."
					}
				],
				"instruction": "Share your ideas with a partner, then compare them with the play."
			},
			{
				"type": "note",
				"text": "This text is a play with five scenes. Read it aloud in roles. One student should read the parts in italics (the narration and the words in brackets). Use a suitable tone, pause in the right places, then read silently and do Exercise 1."
			},
			{
				"type": "h",
				"text": "Reading Text"
			},
			{
				"type": "h",
				"text": "Educational Exhibition"
			},
			{
				"type": "h",
				"text": "Scene 1: Agriculture Stall"
			},
			{
				"type": "p",
				"text": "The management of the Government High School No.2 Shikarpur has organized an educational exhibition in the school playground. Students and their parents have been invited to the exhibition to enable them explore various available educational opportunities that the students can think about."
			},
			{
				"type": "p",
				"text": "Educational stalls, cultural stalls, along with various food stalls have been set up nicely, with wonderful cultural music playing in the background to make the environment lively. Students with their parents are walking around and visiting various stalls."
			},
			{
				"type": "p",
				"text": "Juma sees Anum, Rehmat and Majid entering the school gate. He quickly gets up from the bench and starts walking towards them. They are all excited about seeing the variety of stalls in the school. They decide to visit the agriculture stall first."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Juma",
						"text": "(in a welcoming way) Assalam o Alaikum. Welcome to our school."
					},
					{
						"who": "Agricultural Expert",
						"text": "Walekum-Assalam. Welcome to the agriculture stall."
					},
					{
						"who": "Juma",
						"text": "Sir, can you please tell me about the scope of agriculture in Pakistan?"
					},
					{
						"who": "Agricultural Expert",
						"text": "Well! I am glad to know that you are interested in this profession, my child. You know that Pakistan is an agricultural country and there are many opportunities in this field."
					},
					{
						"who": "Anum",
						"text": "(intervening) What opportunities? Can I also avail these opportunities, being a girl?"
					},
					{
						"who": "Agricultural Expert",
						"text": "(replying enthusiastically) Yes, why not? There are a number of universities in Pakistan where boys and girls are researching on soil, seeds, water, environment, etc., as agricultural experts. One of you can become an expert if you study agriculture."
					},
					{
						"who": "Rehmat",
						"text": "Wow! Great, I didn't know about this earlier. For me, agriculture is only about growing crops, as a farmer."
					},
					{
						"who": "Agricultural Expert",
						"text": "No, that's a myth. There are many branches of agriculture, but the major ones are: Agronomy, Horticulture, Agricultural Engineering, Agricultural Economics and Animal Science."
					},
					{
						"who": "Majid",
						"text": "This is really interesting! Could you please explain these specialized branches of agriculture?"
					},
					{
						"who": "Agricultural Expert",
						"text": "Sure! Your motivation reflects your interest in agriculture. (Turning towards the well displayed models elaborating the branches of agriculture). Agronomy deals with soil management and the growing of crops. Horticulture deals with the cultivation of fruits, vegetables and flowers. Agricultural engineering involves knowledge of farm machines and equipment. It also deals with developing new systems and practices to address problems facing agriculture. Agricultural Economics deals with the business side of farming. Animal Science is basically the breeding and caring of animals for specific purposes, such as for their meat, milk and fur."
					}
				]
			},
			{
				"type": "p",
				"text": "The students thank the expert and move towards the next stall."
			},
			{
				"type": "p",
				"text": "The stall is well equipped with a multimedia and banners of popular banks. A well-dressed man, who is the manager of a bank, is guiding people about the field of Commerce. Rehmat sees Sonia, her class fellow, waiting for her turn. The group of students joins Sonia at the Commerce stall."
			},
			{
				"type": "h",
				"text": "Scene II: Commerce Stall"
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Sonia",
						"text": "Good morning, Sir! I'm here to get some information about the commerce field. Can you please guide me about this field and its benefits?"
					},
					{
						"who": "Manager",
						"text": "(cheerfully) Sure! I'm glad to see your curiosity in commerce. Well, the activity of buying and selling, especially on a large scale, is commerce. Through commerce education, a student is exposed to the environment of the business world. It is helpful for preparing students for employment in the commerce, finance and business fields and for establishing their own business."
					},
					{
						"who": "Rehmat",
						"text": "I think this field will help me in setting up my own business anywhere in the world. Is there any other advantage?"
					},
					{
						"who": "Manager",
						"text": "(in an optimistic way) Yes! Besides this, it also prepares students to meet the global business challenges and compete in the international market. It can guide young graduates become successful business people of tomorrow, in the fast changing business world."
					},
					{
						"who": "Majid",
						"text": "Well, if I'm interested in a job, what departments will offer me jobs after completing commerce education?"
					},
					{
						"who": "Manager",
						"text": "(happily) This is really a good question. There are various departments, like banking and finance, business and trade, economics, and so on."
					}
				]
			},
			{
				"type": "p",
				"text": "The students thank the manager and walk to the next stall."
			},
			{
				"type": "p",
				"text": "Rehmat points at the computers in the computer stall. The children are amazed to see the well-equipped, high tech, new generation computers. Many other students are also standing at the stall."
			},
			{
				"type": "h",
				"text": "Scene III: Computer Sciences Stall"
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Sonia",
						"text": "Wow! Computers in our school! Let's see what we can learn from this stall."
					},
					{
						"who": "IT Expert",
						"text": "(in a welcoming manner) Welcome to the computer science stall. Here we have valuable information about your possible future profession in computers."
					},
					{
						"who": "Sudheer",
						"text": "(overjoyed) Sir, How can computer science help our future career development?"
					},
					{
						"who": "IT Expert",
						"text": "(eagerly) Dear students, the world is progressing rapidly due to IT and almost all the things are controlled with computers."
					},
					{
						"who": "Zainab",
						"text": "(in an inquisitive way) How is this possible?"
					},
					{
						"who": "IT Expert",
						"text": "Anything can be done by the computers. One can communicate with anybody across the world. All our official and unofficial work can be done through computers. Moreover, computers have brought a dramatic change in education."
					},
					{
						"who": "Majid",
						"text": "(interrupting) What about fun in computers?"
					},
					{
						"who": "IT Expert",
						"text": "Oh! I'm sorry I didn't tell you about that. Well, you can play games on the computers. You can watch animated movies, as if you are a part of the movies, through 3D films."
					}
				]
			},
			{
				"type": "note",
				"text": "3D films: films that one watches by wearing special glasses; they make one feel a part of the film."
			},
			{
				"type": "p",
				"text": "The students are very excited to hear all this. They thank the IT Expert and head towards the next stall."
			},
			{
				"type": "p",
				"text": "This stall looks like it is for doctors and engineers. So, the friends decide to go there and gather information about these noble professions. The doctor is briefing a group of children about his field."
			},
			{
				"type": "h",
				"text": "Scene IV: Medical and Engineering Stall"
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Doctor",
						"text": "Well, doctors are the backbone of a society. Whether you want to be a doctor, a dentist, or a nurse you will be curing diseases and solving physical problems, thereby serving humanity."
					},
					{
						"who": "Fehmida",
						"text": "Sir, people generally give importance to doctors; why not nurses?"
					},
					{
						"who": "Doctor",
						"text": "That's really a wonderful question. Nursing is one of the noblest professions because nurses look after the patients with love and care. More people should take up nursing as a career."
					},
					{
						"who": "Anum",
						"text": "My father is a doctor but I want to be an engineer. So, what is the scope of engineering in Pakistan?"
					},
					{
						"who": "Majid",
						"text": "(joining in) I also want to be an engineer."
					},
					{
						"who": "Engineer",
						"text": "Well, my child, there are many fields, like Mechanical, Electrical, Civil, Electronics, etc. Many students are confused about which field of engineering to study. All fields have almost the same growth and scope. However, one should choose a field according to the present and future conditions. In Pakistan, currently, the job scope is better in electrical and electronics engineering; but civil engineers are often paid more than electrical and electronics engineers."
					}
				]
			},
			{
				"type": "p",
				"text": "The children and their parents leave the stall after thanking the doctors and engineers. The students are now beginning to feel tired so they head towards the food stalls."
			},
			{
				"type": "p",
				"text": "While enjoying delicious food they discuss their possible future field."
			},
			{
				"type": "h",
				"text": "Scene V: Food Stalls"
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Juma",
						"text": "This was an amazing experience, learning about these professions. I have planned to become a civil engineer. What about you, Majid?"
					},
					{
						"who": "Majid",
						"text": "I'd prefer to be an agricultural engineer because my father is a farmer and I would like to help him in this field."
					},
					{
						"who": "Zainab",
						"text": "My parents want me to become a bank manager. What about you, Sudheer?"
					},
					{
						"who": "Sudheer",
						"text": "I love serving human beings so I want to be a male nurse."
					},
					{
						"who": "Juma",
						"text": "But your parents may not agree with you."
					},
					{
						"who": "Sudheer",
						"text": "I will try to convince them."
					},
					{
						"who": "Anum",
						"text": "That's great, Sudheer. But I want to be an electronics engineer. My parents prefer this profession the most."
					},
					{
						"who": "Sonia",
						"text": "Many of my family members are suffering from dental problems. So, I think it would be a good idea for me to do Bachelors in Dental Surgery (BDS). Rehmat, what is your future plan?"
					},
					{
						"who": "Rehmat",
						"text": "I have no plans as yet. I will think and discuss with my parents."
					}
				]
			},
			{
				"type": "p",
				"text": "At 5:00 pm, after enjoying the food at the food stalls, with cultural songs playing in the background, and having talked to different educational experts, the students, along with their parents leave the school playground with great optimism. The exhibition had served its purpose."
			},
			{
				"type": "h",
				"text": "While Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"items": [
					{
						"kind": "fill",
						"q": "There are __________ scenes in the text.",
						"answers": [
							"five",
							"5",
							"There are five scenes in the text.",
							"There are 5 scenes in the text."
						]
					},
					{
						"kind": "fill",
						"q": "List the stalls in the order in which the students visited them.",
						"answers": [
							"Agriculture stall, Commerce stall, Computer Sciences stall, Medical and Engineering stall, Food stalls",
							"agriculture, commerce, computer sciences, medical and engineering, food stalls",
							"1. Agriculture stall 2. Commerce stall 3. Computer Sciences stall 4. Medical and Engineering stall 5. Food stalls"
						]
					},
					{
						"kind": "fill",
						"q": "Write the names of all the students mentioned in the text.",
						"answers": ["Juma, Anum, Rehmat, Majid, Sonia, Sudheer, Zainab and Fehmida", "Juma, Anum, Rehmat, Majid, Sonia, Sudheer, Zainab, Fehmida"]
					}
				],
				"instruction": "Read the text and do the following exercise in your notebook."
			},
			{
				"type": "h",
				"text": "Vocabulary"
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"items": [
					{
						"kind": "match",
						"q": "Scene I",
						"pairs": [
							{
								"left": "scope",
								"right": "range of choices"
							},
							{
								"left": "opportunities",
								"right": "chances"
							},
							{
								"left": "myth",
								"right": "stories that many people believe but are not true"
							},
							{
								"left": "reflects",
								"right": "shows"
							},
							{
								"left": "breeding",
								"right": "increasing the number of animals through birth"
							}
						]
					},
					{
						"kind": "match",
						"q": "Scene II",
						"pairs": [
							{
								"left": "curiosity",
								"right": "wanting to know about everything"
							},
							{
								"left": "exposed",
								"right": "shown what something is like"
							},
							{
								"left": "global",
								"right": "at the world level"
							},
							{
								"left": "challenges",
								"right": "possible problems and issues"
							}
						]
					},
					{
						"kind": "match",
						"q": "Scene III",
						"pairs": [
							{
								"left": "valuable",
								"right": "useful or important"
							},
							{
								"left": "rapidly",
								"right": "quickly"
							},
							{
								"left": "communicate",
								"right": "get in touch with or talk to"
							},
							{
								"left": "dramatic",
								"right": "sudden and great"
							},
							{
								"left": "animated",
								"right": "pictures that move"
							}
						]
					},
					{
						"kind": "match",
						"q": "Scene IV and V",
						"pairs": [
							{
								"left": "backbone",
								"right": "the most important part"
							},
							{
								"left": "currently",
								"right": "at present"
							},
							{
								"left": "amazing",
								"right": "pleasurable"
							},
							{
								"left": "convince",
								"right": "try and make someone accept something"
							},
							{
								"left": "dental",
								"right": "related to the teeth"
							},
							{
								"left": "optimism",
								"right": "a feeling that good things will happen"
							}
						]
					}
				],
				"instruction": "Match the words with their meanings. One example is given in the book: scope means range of choices. Include that pair."
			},
			{
				"type": "h",
				"text": "Post Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"items": [{
					"kind": "match",
					"pairs": [
						{
							"left": "Agronomy",
							"right": "It deals with soil management and the growing of crops."
						},
						{
							"left": "Horticulture",
							"right": "It deals with the cultivation of fruits, vegetables and flowers."
						},
						{
							"left": "Agricultural Engineering",
							"right": "It involves knowledge of farm machines and equipment. It also deals with developing new systems and practices to address problems facing agriculture."
						},
						{
							"left": "Agricultural Economics",
							"right": "It deals with the business end of farming."
						},
						{
							"left": "Animal Science",
							"right": "It is basically the breeding and caring of animals for specific purposes, such as for their meat, milk and fur."
						}
					]
				}],
				"instruction": "Match the following branches of agriculture with their description. One has been done as an example: Agronomy — it deals with soil management and the growing of crops."
			},
			{
				"type": "note",
				"text": "The expert names five major branches. There are other fields related to agriculture too, such as food science, forestry and fisheries. Can you name one more?"
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"items": [
					{
						"kind": "tf",
						"q": "Scene I: Agriculture is a field for boys.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene I: Four branches of agriculture are mentioned in the text.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene I: Horticulture is the field of agriculture which deals with animal sciences.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene I: Agricultural engineering is the study related to the mechanical side of agriculture.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Scene II: Scene two is about a medical stall.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene II: Commerce is a field related to business.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Scene II: Rehmat was interested in establishing business in Lahore.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene II: Studying commerce means learning about making money.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene III: The stalls were fully equipped with modern technology.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Scene III: Communication is easily possible within and outside a country.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Scene III: IT is slowing down the work in offices.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene III: Computer science is only about having fun.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene IV: Doctors serve humanity.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Scene IV: Anum's father was a doctor.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Scene IV: Anum wanted to be an engineer.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Scene IV: Mechanical engineers are paid highly.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene V: Juma planned to be a doctor.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene V: Majid's father was a farmer.",
						"answer": true
					},
					{
						"kind": "tf",
						"q": "Scene V: Sudheer wanted to be an architect.",
						"answer": false
					},
					{
						"kind": "tf",
						"q": "Scene V: Rehmat planned to be a mechanical engineer.",
						"answer": false
					}
				],
				"instruction": "The following statements have been taken from each scene of the play. Read the text and mark them true or false."
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"items": [
					{
						"kind": "open",
						"q": "What benefits can students get from commerce education, as mentioned in scene II?",
						"model": "Commerce education exposes a student to the business world. It prepares students for employment in commerce, finance and business, and for establishing their own business. It also prepares them to meet global business challenges and compete in the international market, so young graduates can become successful business people. Jobs may be found in banking and finance, business and trade, and economics."
					},
					{
						"kind": "open",
						"q": "Why were the students excited about the computer stall in scene III?",
						"model": "They were amazed to see well-equipped, high-tech, new-generation computers in their own school. Sonia wanted to find out what they could learn there, and many other students were standing at the stall."
					},
					{
						"kind": "open",
						"q": "What importance of computer science in the modern world is mentioned in scene III?",
						"model": "The world is progressing rapidly because of IT, and almost everything is controlled by computers. People can communicate with anybody across the world. Official and unofficial work can be done through computers, and computers have brought a dramatic change in education. Students can also play games and watch animated movies and 3D films."
					},
					{
						"kind": "open",
						"q": "Make a list of the fields in engineering, as discussed in scene IV.",
						"model": "Mechanical, Electrical, Civil and Electronics. All of them have almost the same growth and scope. In Pakistan, the job scope is currently better in electrical and electronics engineering, but civil engineers are often paid more than electrical and electronics engineers."
					},
					{
						"kind": "open",
						"q": "Write down the medical fields mentioned in scene IV.",
						"model": "Doctor, dentist and nurse. The doctor says that all three cure diseases, solve physical problems and serve humanity. Nursing is called one of the noblest professions because nurses look after patients with love and care. Sonia later plans to do Bachelors in Dental Surgery (BDS)."
					}
				],
				"instruction": "Read the text and answer the following questions. Once you have written all the answers, discuss them with your partner."
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"items": [{
					"kind": "open",
					"q": "Collect first names under Agriculture, Commerce, Computer Science, Engineering, Medical Science, and Any Other. Then write the total for each column.",
					"model": "Sample only — use your own class. Agriculture: Ali, Sara (2). Commerce: Hina (1). Computer Science: Bilal, Zara, Omar (3). Engineering: Majid, Anum, Juma (3). Medical Science: Sonia, Fehmida (2). Any Other: Sudheer, if he chooses nursing and you place it under Medical Science, leave Any Other for a field that is not on the list, such as teaching. If a classmate names a field that is not in the list, write that name under Any Other."
				}],
				"instruction": "Carry out a survey to find out the most popular and the least popular professional field among your class fellows. Ask all your classmates which field they would like to take and write only their first names."
			},
			{
				"type": "table",
				"caption": "Survey card — write first names only",
				"headers": [
					"Professional Field",
					"Name of Student",
					"Total"
				],
				"rows": [
					[
						"Agriculture",
						"",
						""
					],
					[
						"Commerce",
						"",
						""
					],
					[
						"Computer Science",
						"",
						""
					],
					[
						"Engineering",
						"",
						""
					],
					[
						"Medical Science",
						"",
						""
					],
					[
						"Any Other",
						"",
						""
					]
				]
			},
			{
				"type": "note",
				"text": "If a classmate names a field that is not in the list, write that student's name under Any Other. Move about the class and speak softly."
			},
			{
				"type": "exercise",
				"title": "Exercise 7",
				"items": [
					{
						"kind": "open",
						"q": "The most popular professional field in my class is ______________.",
						"model": "Sample: The most popular professional field in my class is Engineering."
					},
					{
						"kind": "open",
						"q": "The least popular professional field is ______________.",
						"model": "Sample: The least popular professional field is Commerce."
					},
					{
						"kind": "open",
						"q": "_____ students are interested in Agriculture.",
						"model": "Sample: Four students are interested in Agriculture."
					},
					{
						"kind": "open",
						"q": "_____ students want to take Commerce.",
						"model": "Sample: Two students want to take Commerce."
					},
					{
						"kind": "open",
						"q": "The number of students interested in Computer Science is _____.",
						"model": "Sample: The number of students interested in Computer Science is six."
					},
					{
						"kind": "open",
						"q": "_____ students are interested in Medical Science.",
						"model": "Sample: Five students are interested in Medical Science."
					},
					{
						"kind": "open",
						"q": "_____ students want to study Engineering.",
						"model": "Sample: Eight students want to study Engineering."
					},
					{
						"kind": "open",
						"q": "While _____ students are interested in other fields.",
						"model": "Sample: While three students are interested in other fields."
					}
				],
				"instruction": "After collecting the data, analyse it by completing these sentences. Use your own survey totals. The model below is only a sample."
			},
			{
				"type": "exercise",
				"title": "Exercise 8",
				"items": [{
					"kind": "open",
					"q": "Which field would you choose for your future, and why?",
					"model": "I would choose agricultural engineering. Pakistan is an agricultural country, and this field deals with farm machines and new ways to solve farming problems. Like Majid, I could use that knowledge to help my family and my community."
				}],
				"instruction": "Which field would you choose for your future and why? Write the answer in your notebook. After you have written your answer, share your future plans with your partner."
			}
		]
	},
	{
		"id": "4.2",
		"code": "4.2",
		"title": "Speaking",
		"subtitle": "Solving Problems",
		"kind": "speaking",
		"blocks": [
			{
				"type": "p",
				"text": "Use the conventions and dynamics of group discussion and interaction to identify problems and propose solutions."
			},
			{
				"type": "p",
				"text": "Work in groups of four and rehearse the following dialogue at least three times. You should take a different role each time."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Waheed",
						"text": "Why do you seem cross today?"
					},
					{
						"who": "Hamid",
						"text": "On the way to school, I saw many children wandering around the streets and playing."
					},
					{
						"who": "Waheed",
						"text": "Oh! That's very sad. They should come to school."
					},
					{
						"who": "Hamid",
						"text": "But, what can we do in this regard?"
					},
					{
						"who": "Noman",
						"text": "We can meet their parents and ask them to send their children to school."
					},
					{
						"who": "Zahid",
						"text": "Yes. We should meet the elders of the village and ask them to take some steps in this regard."
					},
					{
						"who": "Waheed",
						"text": "Perfect! This is an excellent idea. Let's meet them this evening."
					}
				]
			},
			{
				"type": "p",
				"text": "After practising the above dialogues, work in groups of four and speak to each other on the situations given below."
			},
			{
				"type": "callout",
				"title": "How to solve a problem in a group",
				"text": "Name the problem. Say why it matters. Suggest what you can do. Agree on one step, and say when you will do it. Useful lines: Why do you seem cross today? That's very sad. But what can we do in this regard? We can… We should… Perfect! This is an excellent idea. Let's… this evening."
			},
			{
				"type": "exercise",
				"title": "Situations",
				"items": [
					{
						"kind": "open",
						"q": "Children suffering from Malaria",
						"model": "A: Why do you seem worried today?\nB: On the way to school I saw many children sick with malaria. They had fever and were too weak to play.\nA: Oh! That's very sad. They should be treated, and the mosquitoes should be stopped.\nC: We can tell their parents to use nets and to take the children to the clinic.\nD: Yes. We should also ask the elders to drain the stagnant water near the street.\nA: Perfect! This is an excellent idea. Let's meet them this evening."
					},
					{
						"kind": "open",
						"q": "Lack of public transport",
						"model": "A: Why do you seem cross today?\nB: The bus did not come, so many of us walked a long way and arrived late.\nA: Oh! That's very sad. Students should have a safe way to reach school.\nC: We can write a request to the transport office and ask for a bus at school time.\nD: Yes. We should also meet the elders and ask them to speak to the union council.\nA: Perfect! Let's meet them this evening and draft the request together."
					},
					{
						"kind": "open",
						"q": "Cleanliness",
						"model": "A: Why do you seem upset today?\nB: The lane outside the school is full of litter, and it smells bad.\nA: Oh! That's very sad. A dirty place spreads disease.\nC: We can organise a clean-up and put a bin at the gate.\nD: Yes. We should ask the elders to arrange a sweeper and to tell people not to throw rubbish.\nA: Perfect! This is an excellent idea. Let's start with our own street this evening."
					}
				],
				"instruction": "In a group of four, identify the problem and propose a solution. Take a different role each time you practise."
			}
		]
	},
	{
		"id": "4.3",
		"code": "4.3",
		"title": "Language Practice",
		"subtitle": "Direct and Indirect Speech, Adverbs of Manner",
		"kind": "language",
		"blocks": [
			{
				"type": "h",
				"text": "Direct and Indirect Speech"
			},
			{
				"type": "callout",
				"title": "Rules for Indirect Speech",
				"text": "When a statement is changed from direct speech to indirect speech, we remove the quotation marks, usually add that, and change the tense, the pronouns, and some words of time and place. Present simple tense is changed into past simple. Past simple tense is changed into past perfect. Present continuous tense is changed into past continuous. Past continuous tense is changed into past perfect continuous. Present perfect tense is changed into past perfect tense. Present perfect continuous tense is changed into past perfect continuous. Past perfect tense and past perfect continuous tense remain the same. Examples: He said, “I work in a factory.” (Direct speech) He said that he worked in a factory. (Indirect speech) They said, “We are going to the cinema.” (Direct speech) They said that they were going to the cinema. (Indirect speech) Pronouns change according to the speaker: I may become he or she, we may become they, and you changes to match the person spoken to. These words also change: will becomes would, shall becomes should, may becomes might, can becomes could, now becomes then, here becomes there, this becomes that, these becomes those, today becomes that day, tonight becomes that night, last night becomes the previous night, yesterday becomes the previous day, and tomorrow becomes the next day. Next week or next year is often changed to the following week or the following year, as in the exercises below."
			},
			{
				"type": "table",
				"caption": "Words that change from direct to indirect speech",
				"headers": ["Direct speech", "Indirect speech"],
				"rows": [
					["will", "would"],
					["shall", "should"],
					["may", "might"],
					["can", "could"],
					["now", "then"],
					["here", "there"],
					["this", "that"],
					["these", "those"],
					["today", "that day"],
					["tonight", "that night"],
					["last night", "the previous night"],
					["yesterday", "the previous day"],
					["tomorrow", "the next day"]
				]
			},
			{
				"type": "note",
				"text": "Remember the tense and word-change rules you learnt in class 7 as well as these. Say each sentence aloud before you write it."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"items": [
					{
						"kind": "fill",
						"q": "Mujeeb said to him, “I cannot meet you after school today.” Write: Mujeeb said to him that he ___________ him after school _________.",
						"answers": ["Mujeeb said to him that he could not meet him after school that day.", "Mujeeb said to him that he couldn't meet him after school that day."]
					},
					{
						"kind": "fill",
						"q": "Seema said, “The food is very tasty here.” Write: Seema said that the food ___________ very tasty ______.",
						"answers": ["Seema said that the food was very tasty there.", "Seema said that the food was very tasty there"]
					},
					{
						"kind": "fill",
						"q": "I said to Murad, “I am going to ride my bike to work from tomorrow.” Write: I said to Murad that I ________________ my bike to work from the _______.",
						"answers": ["I said to Murad that I was going to ride my bike to work from the next day.", "I said to Murad that I was going to ride my bike to work from the following day."]
					},
					{
						"kind": "fill",
						"q": "My parents said, “We have been to Lahore several times.” Write: My parents said that they _____________ to Lahore several times.",
						"answers": ["My parents said that they had been to Lahore several times.", "My parents said that they had been to Lahore several times"]
					},
					{
						"kind": "fill",
						"q": "Hania said to her, “I forgot to call my mother this evening.” Write: Hania said to her that she ______________ to call her mother ________.",
						"answers": ["Hania said to her that she had forgotten to call her mother that evening.", "Hania said to her that she'd forgotten to call her mother that evening."]
					},
					{
						"kind": "fill",
						"q": "We said to the teacher, “We will complete our work by next week.” Write: We said to our teacher that we _______________ our work by _________.",
						"answers": ["We said to our teacher that we would complete our work by the following week.", "We said to our teacher that we would complete our work by the next week."]
					},
					{
						"kind": "fill",
						"q": "Manmohan said, “I will visit Quetta next year.” Write: Manmohan said that he ___________ Quetta the following year.",
						"answers": ["Manmohan said that he would visit Quetta the following year.", "Manmohan said that he'd visit Quetta the following year."]
					},
					{
						"kind": "fill",
						"q": "Fahim's boss said to his employees, “The meeting will start at 2:00 pm today.” Write: Fahim's boss said to his employees that the meeting _____________ at 2:00 pm ___________.",
						"answers": ["Fahim's boss said to his employees that the meeting would start at 2:00 pm that day.", "Fahim's boss said to his employees that the meeting would start at 2 pm that day."]
					},
					{
						"kind": "fill",
						"q": "All the mechanics said to us, “We cannot fix your car.” Write: All the mechanics said to us that they ___________ our car.",
						"answers": ["All the mechanics said to us that they could not fix our car.", "All the mechanics said to us that they couldn't fix our car."]
					},
					{
						"kind": "fill",
						"q": "My brother said to him, “I've already seen this movie.” Write: My brother said to him that he _____ already ________ that movie.",
						"answers": ["My brother said to him that he had already seen that movie.", "My brother said to him that he'd already seen that movie."]
					}
				],
				"instruction": "Work in pairs and complete the following sentences in the indirect speech. Do the exercise orally at first and then write all the sentences in your notebook. Type the full indirect sentence."
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"items": [
					{
						"kind": "fill",
						"q": "Shah said, “I don't like seafood.”",
						"answers": ["Shah said that he did not like seafood.", "Shah said that he didn't like seafood."]
					},
					{
						"kind": "fill",
						"q": "I said, “I was sleeping when you came last night.”",
						"answers": [
							"I said that I had been sleeping when you had come the previous night.",
							"I said that I had been sleeping when he had come the previous night.",
							"I said that I had been sleeping when you came the previous night."
						],
						"hint": "Past continuous becomes past perfect continuous. Past simple becomes past perfect. Last night becomes the previous night."
					},
					{
						"kind": "fill",
						"q": "Mariam said, “I am planning to go to Turkey next summer.”",
						"answers": ["Mariam said that she was planning to go to Turkey the following summer.", "Mariam said that she was planning to go to Turkey the next summer."]
					},
					{
						"kind": "fill",
						"q": "Deeba said, “We visited our grandmother last summer.”",
						"answers": ["Deeba said that they had visited their grandmother the previous summer.", "Deeba said that they had visited their grandmother the summer before."]
					},
					{
						"kind": "fill",
						"q": "Rashid said, “We're going to visit my aunt this evening.”",
						"answers": ["Rashid said that they were going to visit his aunt that evening.", "Rashid said that they were going to visit his aunt that evening"]
					},
					{
						"kind": "fill",
						"q": "My sister said, “I have to finish my report by tonight.”",
						"answers": ["My sister said that she had to finish her report by that night.", "My sister said that she had to finish her report by that night"]
					},
					{
						"kind": "fill",
						"q": "The little girl said, “I can't read Farsi.”",
						"answers": ["The little girl said that she could not read Farsi.", "The little girl said that she couldn't read Farsi."]
					},
					{
						"kind": "fill",
						"q": "My classmates said, “We will come to the presentation tomorrow.”",
						"answers": ["My classmates said that they would come to the presentation the next day.", "My classmates said that they would come to the presentation the following day."]
					},
					{
						"kind": "fill",
						"q": "Safdar said to me, “I can meet you today at noon.”",
						"answers": ["Safdar said to me that he could meet me that day at noon.", "Safdar told me that he could meet me that day at noon."]
					},
					{
						"kind": "fill",
						"q": "All of us said, “We will be in college next year.”",
						"answers": ["All of us said that we would be in college the following year.", "All of us said that we would be in college the next year."]
					}
				],
				"instruction": "Change the sentences below from direct speech into indirect speech. Write the full indirect sentence."
			},
			{
				"type": "h",
				"text": "Exercise 3 — the dialogue"
			},
			{
				"type": "p",
				"text": "Work with a partner and change the following dialogue into indirect speech. Write this in your notebook. You may begin like this: Zeenat said that her sister was getting married the next day. Najma replied that..."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Zeenat",
						"text": "My sister is getting married tomorrow."
					},
					{
						"who": "Najma",
						"text": "I know. My mother told me yesterday."
					},
					{
						"who": "Zeenat",
						"text": "I will wear a blue shalwar kameez and my mother will wear a yellow dress."
					},
					{
						"who": "Mahnoor",
						"text": "This is why you were absent last week."
					},
					{
						"who": "Zeenat",
						"text": "I had to go and invite people for the wedding."
					},
					{
						"who": "Najma",
						"text": "Last night my mother told me that we had been invited to the wedding."
					},
					{
						"who": "Mahnoor",
						"text": "My sister also told me that we will go to the wedding."
					},
					{
						"who": "Zeenat",
						"text": "We have invited all our friends and family to the wedding. It will be great fun."
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"items": [
					{
						"kind": "fill",
						"q": "Zeenat: “My sister is getting married tomorrow.”",
						"answers": ["Zeenat said that her sister was getting married the next day.", "Zeenat said that her sister was getting married the following day."]
					},
					{
						"kind": "fill",
						"q": "Najma: “I know. My mother told me yesterday.”",
						"answers": ["Najma replied that she knew and that her mother had told her the previous day.", "Najma said that she knew. Her mother had told her the previous day."]
					},
					{
						"kind": "fill",
						"q": "Zeenat: “I will wear a blue shalwar kameez and my mother will wear a yellow dress.”",
						"answers": ["Zeenat said that she would wear a blue shalwar kameez and that her mother would wear a yellow dress.", "Zeenat said that she would wear a blue shalwar kameez and her mother would wear a yellow dress."]
					},
					{
						"kind": "fill",
						"q": "Mahnoor: “This is why you were absent last week.”",
						"answers": ["Mahnoor said that that was why she had been absent the previous week.", "Mahnoor said that that was why Zeenat had been absent the previous week."]
					},
					{
						"kind": "fill",
						"q": "Zeenat: “I had to go and invite people for the wedding.”",
						"answers": ["Zeenat said that she had had to go and invite people for the wedding.", "Zeenat said that she had to go and invite people for the wedding."]
					},
					{
						"kind": "fill",
						"q": "Najma: “Last night my mother told me that we had been invited to the wedding.”",
						"answers": ["Najma said that the previous night her mother had told her that they had been invited to the wedding.", "Najma said that the night before, her mother had told her that they had been invited to the wedding."]
					},
					{
						"kind": "fill",
						"q": "Mahnoor: “My sister also told me that we will go to the wedding.”",
						"answers": ["Mahnoor said that her sister had also told her that they would go to the wedding.", "Mahnoor said that her sister had also told her that they would go to the wedding"]
					},
					{
						"kind": "fill",
						"q": "Zeenat: “We have invited all our friends and family to the wedding. It will be great fun.”",
						"answers": ["Zeenat said that they had invited all their friends and family to the wedding and that it would be great fun.", "Zeenat said that they had invited all their friends and family to the wedding. It would be great fun."]
					}
				],
				"instruction": "Change each line into indirect speech. Keep the speakers' names."
			},
			{
				"type": "h",
				"text": "Adverbs of Manner"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "Adverbs of manner tell us about how an action was carried out. Most, though not all, adverbs end in ly. Adverbs of manner are usually in end position, but sometimes they are in the mid position. Examples: My sister left the room quickly. The policeman easily caught the thief. Adverbs can be formed from adjectives by adding ly. However, there are some rules to follow. Some adverbs are formed by just adding ly to the adjectives. Example: proud, proudly. In adjectives ending in y the y is usually dropped and ily is added. Example: lucky, luckily. In adjectives ending in le, the e is usually dropped and y is added. Example: noble, nobly. A few adjectives ending in e drop the e before ly: true becomes truly, not truely."
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"items": [
					{
						"kind": "fill",
						"q": "glad → ____",
						"answers": ["gladly"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "clever → ____",
						"answers": ["cleverly"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "poor → ____",
						"answers": ["poorly"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "sudden → ____",
						"answers": ["suddenly"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "quick → ____",
						"answers": ["quickly"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "cheap → ____",
						"answers": ["cheaply"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "patient → ____",
						"answers": ["patiently"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "real → ____",
						"answers": ["really"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "proper → ____",
						"answers": ["properly"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "hungry → ____",
						"answers": ["hungrily"],
						"hint": "The y is dropped and ily is added."
					},
					{
						"kind": "fill",
						"q": "lazy → ____",
						"answers": ["lazily"],
						"hint": "The y is dropped and ily is added."
					},
					{
						"kind": "fill",
						"q": "noisy → ____",
						"answers": ["noisily"],
						"hint": "The y is dropped and ily is added."
					},
					{
						"kind": "fill",
						"q": "easy → ____",
						"answers": ["easily"],
						"hint": "The y is dropped and ily is added."
					},
					{
						"kind": "fill",
						"q": "angry → ____",
						"answers": ["angrily"],
						"hint": "The y is dropped and ily is added."
					},
					{
						"kind": "fill",
						"q": "heavy → ____",
						"answers": ["heavily"],
						"hint": "The y is dropped and ily is added."
					},
					{
						"kind": "fill",
						"q": "true → ____",
						"answers": ["truly"],
						"hint": "Drop the e, then add ly. The spelling is truly, not truely."
					},
					{
						"kind": "fill",
						"q": "simple → ____",
						"answers": ["simply"],
						"hint": "The adjective ends in le. Drop the e and add y."
					},
					{
						"kind": "fill",
						"q": "gentle → ____",
						"answers": ["gently"],
						"hint": "The adjective ends in le. Drop the e and add y."
					},
					{
						"kind": "fill",
						"q": "possible → ____",
						"answers": ["possibly"],
						"hint": "The adjective ends in le. Drop the e and add y."
					},
					{
						"kind": "fill",
						"q": "idle → ____",
						"answers": ["idly"],
						"hint": "The adjective ends in le. Drop the e and add y."
					},
					{
						"kind": "fill",
						"q": "hopeful → ____",
						"answers": ["hopefully"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "thankful → ____",
						"answers": ["thankfully"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "grateful → ____",
						"answers": ["gratefully"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "careful → ____",
						"answers": ["carefully"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "peaceful → ____",
						"answers": ["peacefully"],
						"hint": "Add ly."
					},
					{
						"kind": "fill",
						"q": "comfortable → ____",
						"answers": ["comfortably"],
						"hint": "The adjective ends in le. Drop the e and add y."
					}
				],
				"instruction": "Follow the rules above and change each adjective into an adverb of manner. Do it in your notebook."
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"items": [
					{
						"kind": "fill",
						"q": "They were sitting _______ and talking when they heard a loud noise.",
						"answers": [
							"comfortably",
							"peacefully",
							"lazily"
						]
					},
					{
						"kind": "fill",
						"q": "The lights went off _______ so the program had to end.",
						"answers": ["suddenly"]
					},
					{
						"kind": "fill",
						"q": "All the students were able to do the math paper _______.",
						"answers": ["easily"]
					},
					{
						"kind": "fill",
						"q": "We should all live _______ with our neighbours.",
						"answers": ["peacefully", "comfortably"]
					},
					{
						"kind": "fill",
						"q": "The chairman left the meeting ______ because his wife was sick.",
						"answers": ["quickly", "suddenly"]
					},
					{
						"kind": "fill",
						"q": "The people had not had food for two days so they ate _______.",
						"answers": ["hungrily"]
					},
					{
						"kind": "fill",
						"q": "The nurse lifted the baby _______ and changed her clothes.",
						"answers": ["gently", "carefully"]
					},
					{
						"kind": "fill",
						"q": "The office clerk ______ took the money that his boss gave him.",
						"answers": [
							"gratefully",
							"thankfully",
							"gladly"
						]
					}
				],
				"instruction": "Complete the following sentences by adding one adverb. You can use any adverb from the table above, but you can use one adverb only once. A strong choice is shown first; another suitable adverb from the table is also accepted."
			},
			{
				"type": "p",
				"text": "Work in pairs and complete the following dialogue. Discuss it orally at first and then write the complete dialogue in your notebooks."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Kamran",
						"text": "Why did Mariam leave the room ______?"
					},
					{
						"who": "Saba",
						"text": "She was upset because although she had done her work ______ she had made a big mistake."
					},
					{
						"who": "Kamran",
						"text": "But she could have ______ explained to us and we would have understood."
					},
					{
						"who": "Saba",
						"text": "I know. ______ she will be alright by lunch time."
					},
					{
						"who": "Bano",
						"text": "Do you ______ believe so?"
					},
					{
						"who": "Saba",
						"text": "I think if we ______ wait until she feels alright there will be no problem."
					},
					{
						"who": "Kamran",
						"text": "I ______ don't understand how could a clever girl like Mariam make such a mistake?"
					},
					{
						"who": "Saba",
						"text": "People who always do their work ______ get upset when things go wrong."
					},
					{
						"who": "Bano",
						"text": "______, her mood will get better by lunch time. She is such a jolly person, I don't want her to be sad."
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"items": [
					{
						"kind": "fill",
						"q": "Why did Mariam leave the room ______?",
						"answers": [
							"angrily",
							"suddenly",
							"quickly"
						]
					},
					{
						"kind": "fill",
						"q": "She was upset because although she had done her work ______ she had made a big mistake.",
						"answers": ["carefully", "properly"]
					},
					{
						"kind": "fill",
						"q": "But she could have ______ explained to us and we would have understood.",
						"answers": [
							"easily",
							"simply",
							"patiently"
						]
					},
					{
						"kind": "fill",
						"q": "I know. ______ she will be alright by lunch time.",
						"answers": ["Hopefully", "hopefully"]
					},
					{
						"kind": "fill",
						"q": "Do you ______ believe so?",
						"answers": ["really", "truly"]
					},
					{
						"kind": "fill",
						"q": "I think if we ______ wait until she feels alright there will be no problem.",
						"answers": ["patiently"]
					},
					{
						"kind": "fill",
						"q": "I ______ don't understand how could a clever girl like Mariam make such a mistake?",
						"answers": [
							"simply",
							"really",
							"truly"
						]
					},
					{
						"kind": "fill",
						"q": "People who always do their work ______ get upset when things go wrong.",
						"answers": ["properly", "carefully"]
					},
					{
						"kind": "fill",
						"q": "______, her mood will get better by lunch time.",
						"answers": [
							"Luckily",
							"luckily",
							"Hopefully",
							"hopefully",
							"Truly",
							"truly"
						]
					}
				],
				"instruction": "Fill each blank with a suitable adverb. Use a different adverb in each blank. Say the dialogue, then write it."
			},
			{
				"type": "note",
				"text": "After you have completed the dialogue, some of you may role-play it in front of the class."
			}
		]
	},
	{
		"id": "4.4",
		"code": "4.4",
		"title": "Writing",
		"subtitle": "A Paragraph",
		"kind": "writing",
		"blocks": [
			{
				"type": "p",
				"text": "Use words like first, next, then, after that and finally to show the order in which things happened."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"items": [
					{
						"kind": "fill",
						"q": "The Government _____ organized an educational exhibition.",
						"answers": [
							"High School No. 2 Shikarpur",
							"High School No.2 Shikarpur",
							"Government High School No. 2 Shikarpur"
						]
					},
					{
						"kind": "fill",
						"q": "It was an ___________ exhibition.",
						"answers": ["educational"]
					},
					{
						"kind": "fill",
						"q": "All the children and their ________ visited the stalls.",
						"answers": ["parents"]
					},
					{
						"kind": "fill",
						"q": "Majid first visited the ___________ stall.",
						"answers": ["agriculture", "agricultural"]
					},
					{
						"kind": "fill",
						"q": "He asked the ___________ expert about the scope and branches of agriculture.",
						"answers": ["agricultural"]
					},
					{
						"kind": "fill",
						"q": "Next, he _____________________.",
						"answers": [
							"visited the commerce stall",
							"went to the commerce stall",
							"Next, he visited the commerce stall."
						]
					},
					{
						"kind": "fill",
						"q": "He asked ___________________________.",
						"answers": [
							"which departments would offer him jobs after commerce education",
							"the manager about jobs after commerce education",
							"which departments would offer jobs"
						]
					},
					{
						"kind": "fill",
						"q": "Then, he _________________.",
						"answers": [
							"visited the computer sciences stall",
							"went to the computer science stall",
							"visited the computer stall"
						]
					},
					{
						"kind": "fill",
						"q": "Finally, _______________________.",
						"answers": ["he visited the medical and engineering stall", "he went to the medical and engineering stall"]
					},
					{
						"kind": "fill",
						"q": "After visiting all the stalls he decided to become ___________________.",
						"answers": ["an agricultural engineer", "agricultural engineer"]
					},
					{
						"kind": "fill",
						"q": "He decided this so that he could ________________________________.",
						"answers": [
							"help his father, who is a farmer",
							"help his father in farming",
							"help his father in this field"
						]
					},
					{
						"kind": "open",
						"q": "Now write the complete paragraph in your notebook.",
						"model": "The Government High School No. 2 Shikarpur organized an educational exhibition. All the children and their parents visited the stalls. Majid first visited the agriculture stall. He asked the agricultural expert about the scope and the branches of agriculture. Next, he visited the commerce stall. He asked which departments would offer him jobs after completing commerce education. Then, he visited the computer sciences stall. He asked about the fun one can have on computers. Finally, he visited the medical and engineering stall. He said that he also wanted to be an engineer. After visiting all the stalls he decided to become an agricultural engineer so that he could help his father, who is a farmer."
					}
				],
				"instruction": "Read the text in section 4.1 again. Majid visited all the stalls. Write a paragraph to show the order in which he visited them. You can begin like this: The Government ___________________________________ organized an ___________ exhibition. All the children and their ________ visited the stalls. Majid first visited the ___________ stall. He asked the ___________ expert about ______________________. Next, he _____________________. He asked ___________________________. Then, he _________________. He ______________________________. Finally, _______________________. He __________________________. After visiting all the stalls he decided to become ___________________ so that he could________________________________."
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"items": [{
					"kind": "open",
					"q": "Complete the paragraph: Today, when I reached near the school gate...",
					"model": "Today, when I reached near the school gate, I saw a little boy crying loudly beside his bicycle. First, I walked quickly towards him and asked what had happened. Next, he told me sadly that his bag had fallen into a muddy puddle. Then, I carefully picked up the wet bag and helped him wipe his books. After that, his elder brother arrived and thanked me warmly. Finally, I went into the class feeling glad that I had helped someone."
				}],
				"instruction": "Work in pairs and complete the following by writing a short narrative paragraph. Use the past tense, adjectives and adverbs, and transitional words such as first, next, then, after that and finally."
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"items": [{
					"kind": "open",
					"q": "Write one incident from your own life as a short narrative paragraph.",
					"model": "Last summer I lost my way in the crowded Sunday bazaar. First, I stood quietly near a fruit stall and looked for my uncle. Next, a kind shopkeeper asked me gently where I lived. Then, I told him my uncle's name and the colour of his stall. After that, he walked with me past the noisy cloth shops until I saw my uncle waving. Finally, I held my uncle's hand tightly and promised to stay close."
				}],
				"instruction": "Write an incident from your life. Use the past tense. Use adjectives and adverbs in order to give details. Use appropriate transitional words to show the order of events."
			}
		]
	},
	{
		"id": "4.5",
		"code": "4.5",
		"title": "Study Skills",
		"subtitle": "Exhibition",
		"kind": "study",
		"blocks": [
			{
				"type": "p",
				"text": "Look at the flyer. Observe all the details about the event."
			},
			{
				"type": "h",
				"text": "Educational Opportunities for Students"
			},
			{
				"type": "p",
				"text": "Learning and Fun for Elders"
			},
			{
				"type": "p",
				"text": "Shikarpur. Grow With Tradition."
			},
			{
				"type": "p",
				"text": "Join us for an EXHIBITION at Government High School 2."
			},
			{
				"type": "p",
				"text": "December 17, 2017, at 2 P.M. Venue: Playground, Government High School 2, Shikarpur."
			},
			{
				"type": "list",
				"ordered": false,
				"items": [
					"Enjoy plenty of kids' activities",
					"Sample some tasty food",
					"Educational Opportunities Stall",
					"Talk with Experts",
					"And much more!"
				]
			},
			{
				"type": "p",
				"text": "Admin of Government High School 2, Shikarpur."
			},
			{
				"type": "table",
				"caption": "What a flyer usually shows",
				"headers": ["Part of the flyer", "What this flyer says"],
				"rows": [
					["Event title", "Educational Opportunities for Students / Exhibition — Grow With Tradition"],
					["Place named at the top", "Shikarpur"],
					["Host", "Government High School 2"],
					["Date", "December 17, 2017"],
					["Time", "2 P.M."],
					["Venue", "Playground, Government High School 2, Shikarpur"],
					["Who invites you", "Admin of Government High School 2, Shikarpur"]
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"items": [
					{
						"kind": "fill",
						"q": "Event Title: ________________________________________________",
						"answers": [
							"Educational Opportunities for Students",
							"Exhibition",
							"Grow With Tradition",
							"Educational Opportunities for Students — Learning and Fun for Elders"
						]
					},
					{
						"kind": "fill",
						"q": "Date: _____________________________________________________",
						"answers": [
							"December 17, 2017",
							"17 December 2017",
							"December 17 2017"
						]
					},
					{
						"kind": "fill",
						"q": "Day: ______________________________________________________",
						"answers": ["Sunday"],
						"hint": "The flyer prints the date. December 17, 2017 was a Sunday."
					},
					{
						"kind": "fill",
						"q": "Timing: ___________________________________________________",
						"answers": [
							"2 P.M.",
							"2 p.m.",
							"2 PM",
							"2:00 p.m."
						]
					},
					{
						"kind": "fill",
						"q": "Venue: ____________________________________________________",
						"answers": [
							"Playground, Government High School 2, Shikarpur",
							"Playground Govt: High School 2 Shikarpur",
							"Playground, Govt. High School 2, Shikarpur"
						]
					},
					{
						"kind": "fill",
						"q": "Activities: _________________________________________________",
						"answers": ["Enjoy plenty of kids' activities; sample some tasty food; educational opportunities stall; talk with experts; and much more", "kids' activities, tasty food, educational opportunities stall, talk with experts, and much more"]
					}
				],
				"instruction": "Now fill the information given in the flyer in the following card."
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"items": [{
					"kind": "open",
					"q": "Fill an information card for your own event, then say what you would put on the flyer.",
					"model": "Event Title: Town Book Fair\nDate: 14 August 2026\nDay: Friday\nTiming: 10 a.m. to 4 p.m.\nVenue: Municipal Library lawn, Shikarpur\nActivities: book stalls, a story hour for children, a chance to meet writers, and refreshments.\nThe flyer would say: Join us for a Book Fair. Grow with books. Enjoy story time, talk with writers, and much more. Admin of the Municipal Library."
				}],
				"instruction": "Choose any event like Eid Mela, Food Festival, Cultural Day, Book Fair, etc. and design a flyer on a paper. First, fill an information card like the one given above. Then develop a colourful flyer."
			}
		]
	},
	{
		"id": "4.6",
		"code": "4.6",
		"title": "Fun",
		"subtitle": "Fun with Nouns",
		"kind": "fun",
		"blocks": [
			{
				"type": "h",
				"text": "Fun with Nouns"
			},
			{
				"type": "p",
				"text": "The whole class should split up into four groups. The groups should be numbered 1, 2, 3, and 4. Group 1 should read the first line of each verse, Group 2 the second line, Group 3 the third line, and Group 4 the fourth line. Recite the poem loudly in groups."
			},
			{
				"type": "poem",
				"lines": [
					"We'll begin with a box, and the plural is boxes,",
					"Should the plural of ox be oxes not oxen.",
					"One fowl is a goose, but two are called geese,",
					"Yet the plural of moose should never be meese.",
					"",
					"You may find a lone mouse or a nest full of mice,",
					"But the plural of house is houses, not hice.",
					"If the plural of man is always called men,",
					"Why shouldn't the plural of pan be called pen?",
					"",
					"If I spoke of my foot and showed you my feet,",
					"When I give you a boot, would a pair be called beet?",
					"If one is a tooth and a whole set are teeth,",
					"Why shouldn't the plural of booth be called beeth?",
					"",
					"If the singular is this, and the plural is these,",
					"Why shouldn't the plural of miss be messe?",
					"Then one may be that, and three would be those,",
					"Yet the plural of hat would never be hose.",
					"",
					"We speak of a brother and also of brethren,",
					"But for more than one mother is it methren?",
					"So plurals in English, I think you'll agree,",
					"Are indeed very tricky singularly."
				]
			},
			{
				"type": "note",
				"text": "Work in pairs. First write all the singular nouns mentioned in the poem. Then write their correct plurals. Some of the plurals in the poem are real; the others are jokes. The first pair to finish fully and correctly wins."
			},
			{
				"type": "exercise",
				"title": "Correct or made up?",
				"items": [{
					"kind": "classify",
					"q": "Is this a real plural used correctly in the poem, or a made-up joke plural?",
					"buckets": ["Real plural", "Made-up joke"],
					"cards": [
						{
							"text": "boxes (plural of box)",
							"bucket": 0
						},
						{
							"text": "oxes (suggested for ox)",
							"bucket": 1
						},
						{
							"text": "oxen (plural of ox)",
							"bucket": 0
						},
						{
							"text": "geese (plural of goose)",
							"bucket": 0
						},
						{
							"text": "meese (suggested for moose)",
							"bucket": 1
						},
						{
							"text": "mice (plural of mouse)",
							"bucket": 0
						},
						{
							"text": "hice (suggested for house)",
							"bucket": 1
						},
						{
							"text": "houses (plural of house)",
							"bucket": 0
						},
						{
							"text": "men (plural of man)",
							"bucket": 0
						},
						{
							"text": "pen (suggested for pan)",
							"bucket": 1
						},
						{
							"text": "feet (plural of foot)",
							"bucket": 0
						},
						{
							"text": "beet (suggested for boot)",
							"bucket": 1
						},
						{
							"text": "teeth (plural of tooth)",
							"bucket": 0
						},
						{
							"text": "beeth (suggested for booth)",
							"bucket": 1
						},
						{
							"text": "these (plural of this)",
							"bucket": 0
						},
						{
							"text": "messe (suggested for miss)",
							"bucket": 1
						},
						{
							"text": "those (plural of that)",
							"bucket": 0
						},
						{
							"text": "hose (suggested for hat)",
							"bucket": 1
						},
						{
							"text": "brethren (old plural of brother)",
							"bucket": 0
						},
						{
							"text": "methren (suggested for mother)",
							"bucket": 1
						}
					]
				}],
				"instruction": "The poem mixes real plural forms with forms that only look like plurals. Sort each one."
			},
			{
				"type": "exercise",
				"title": "Write the real plural",
				"items": [
					{
						"kind": "fill",
						"q": "The plural of box is ____.",
						"answers": ["boxes"]
					},
					{
						"kind": "fill",
						"q": "The plural of ox is ____.",
						"answers": ["oxen"],
						"hint": "Do not use the made-up form from the poem."
					},
					{
						"kind": "fill",
						"q": "The plural of goose is ____.",
						"answers": ["geese"]
					},
					{
						"kind": "fill",
						"q": "The plural of fowl is ____.",
						"answers": ["fowl", "fowls"]
					},
					{
						"kind": "fill",
						"q": "The plural of moose is ____.",
						"answers": ["moose"],
						"hint": "Do not use the made-up form from the poem."
					},
					{
						"kind": "fill",
						"q": "The plural of mouse is ____.",
						"answers": ["mice"]
					},
					{
						"kind": "fill",
						"q": "The plural of house is ____.",
						"answers": ["houses"],
						"hint": "Do not use the made-up form from the poem."
					},
					{
						"kind": "fill",
						"q": "The plural of man is ____.",
						"answers": ["men"]
					},
					{
						"kind": "fill",
						"q": "The plural of pan is ____.",
						"answers": ["pans"],
						"hint": "Do not use the made-up form from the poem."
					},
					{
						"kind": "fill",
						"q": "The plural of foot is ____.",
						"answers": ["feet"]
					},
					{
						"kind": "fill",
						"q": "The plural of boot is ____.",
						"answers": ["boots"],
						"hint": "Do not use the made-up form from the poem."
					},
					{
						"kind": "fill",
						"q": "The plural of tooth is ____.",
						"answers": ["teeth"]
					},
					{
						"kind": "fill",
						"q": "The plural of booth is ____.",
						"answers": ["booths"],
						"hint": "Do not use the made-up form from the poem."
					},
					{
						"kind": "fill",
						"q": "The plural of this is ____.",
						"answers": ["these"]
					},
					{
						"kind": "fill",
						"q": "The plural of miss is ____.",
						"answers": ["misses"],
						"hint": "Do not use the made-up form from the poem."
					},
					{
						"kind": "fill",
						"q": "The plural of that is ____.",
						"answers": ["those"]
					},
					{
						"kind": "fill",
						"q": "The plural of hat is ____.",
						"answers": ["hats"],
						"hint": "Do not use the made-up form from the poem."
					},
					{
						"kind": "fill",
						"q": "The plural of brother is ____.",
						"answers": ["brothers", "brethren"]
					},
					{
						"kind": "fill",
						"q": "The plural of mother is ____.",
						"answers": ["mothers"],
						"hint": "Do not use the made-up form from the poem."
					}
				],
				"instruction": "Write the correct plural of each singular noun from the poem. Do not copy the joke forms."
			}
		]
	}
];
var vocab$3 = [
	{
		"word": "scope",
		"pos": "noun",
		"meaning": "The range of choices and opportunities open in a field.",
		"urdu": "دائرۂ کار، گنجائش",
		"synonyms": [
			"range",
			"extent",
			"reach"
		],
		"antonyms": ["limitation", "restriction"],
		"sentences": ["Juma asked the expert about the scope of agriculture in Pakistan."]
	},
	{
		"word": "opportunities",
		"pos": "noun",
		"meaning": "Chances to do or achieve something useful.",
		"urdu": "مواقع",
		"synonyms": [
			"chances",
			"openings",
			"prospects"
		],
		"antonyms": ["obstacles", "barriers"],
		"sentences": ["The expert said there are many opportunities in agriculture for both boys and girls."]
	},
	{
		"word": "myth",
		"pos": "noun",
		"meaning": "A belief that many people hold but that is not true.",
		"urdu": "غلط عام خیال",
		"synonyms": [
			"misconception",
			"fallacy",
			"false belief"
		],
		"antonyms": ["fact", "truth"],
		"sentences": ["It is a myth that agriculture is only about growing crops as a farmer."]
	},
	{
		"word": "reflects",
		"pos": "verb",
		"meaning": "Shows or makes something clear.",
		"urdu": "ظاہر کرتا ہے",
		"synonyms": [
			"shows",
			"indicates",
			"expresses"
		],
		"antonyms": ["hides", "conceals"],
		"sentences": ["The expert said that Majid's motivation reflects his interest in agriculture."]
	},
	{
		"word": "breeding",
		"pos": "noun",
		"meaning": "Producing young animals and increasing their number by birth.",
		"urdu": "افزائشِ نسل",
		"synonyms": [
			"raising",
			"reproduction",
			"rearing"
		],
		"antonyms": ["neglect", "extinction"],
		"sentences": ["Animal Science is the breeding and caring of animals for meat, milk and fur."]
	},
	{
		"word": "curiosity",
		"pos": "noun",
		"meaning": "A strong wish to know or learn about something.",
		"urdu": "تجسس",
		"synonyms": [
			"inquisitiveness",
			"interest",
			"eagerness"
		],
		"antonyms": ["indifference", "apathy"],
		"sentences": ["The manager was glad to see Sonia's curiosity in commerce."]
	},
	{
		"word": "exposed",
		"pos": "verb",
		"meaning": "Introduced to something and shown what it is like.",
		"urdu": "روشناس کرایا جانا",
		"synonyms": [
			"introduced",
			"familiarised",
			"shown"
		],
		"antonyms": ["sheltered", "hidden"],
		"sentences": ["Through commerce education, a student is exposed to the environment of the business world."]
	},
	{
		"word": "global",
		"pos": "adjective",
		"meaning": "Relating to the whole world, not just one country.",
		"urdu": "عالمی",
		"synonyms": [
			"worldwide",
			"international",
			"universal"
		],
		"antonyms": ["local", "national"],
		"sentences": ["Commerce studies prepare students to meet global business challenges."]
	},
	{
		"word": "challenges",
		"pos": "noun",
		"meaning": "Difficult problems or issues that people must face.",
		"urdu": "مشکلات، چیلنجز",
		"synonyms": [
			"difficulties",
			"problems",
			"obstacles"
		],
		"antonyms": ["advantages", "solutions"],
		"sentences": ["The course prepares young people to meet global business challenges."]
	},
	{
		"word": "valuable",
		"pos": "adjective",
		"meaning": "Useful or important.",
		"urdu": "قیمتی، کارآمد",
		"synonyms": [
			"useful",
			"important",
			"precious"
		],
		"antonyms": ["worthless", "useless"],
		"sentences": ["The computer stall has valuable information about a future profession in computers."]
	},
	{
		"word": "rapidly",
		"pos": "adverb",
		"meaning": "Quickly; at great speed.",
		"urdu": "تیزی سے",
		"synonyms": [
			"quickly",
			"swiftly",
			"fast"
		],
		"antonyms": ["slowly", "gradually"],
		"sentences": ["The IT expert said the world is progressing rapidly because of information technology."]
	},
	{
		"word": "communicate",
		"pos": "verb",
		"meaning": "To get in touch with someone or talk to them.",
		"urdu": "رابطہ کرنا، بات چیت کرنا",
		"synonyms": [
			"talk",
			"contact",
			"converse"
		],
		"antonyms": ["ignore", "withhold"],
		"sentences": ["With a computer, one can communicate with anybody across the world."]
	},
	{
		"word": "dramatic",
		"pos": "adjective",
		"meaning": "Sudden, great and striking.",
		"urdu": "اچانک اور بہت بڑی",
		"synonyms": [
			"striking",
			"sudden",
			"remarkable"
		],
		"antonyms": ["slight", "gradual"],
		"sentences": ["Computers have brought a dramatic change in education."]
	},
	{
		"word": "animated",
		"pos": "adjective",
		"meaning": "Made of pictures that move, as in a cartoon film.",
		"urdu": "متحرک، اینیمیٹڈ",
		"synonyms": [
			"moving",
			"lively",
			"cartoon"
		],
		"antonyms": ["still", "lifeless"],
		"sentences": ["You can watch animated movies on the computer, and even feel part of a 3D film."]
	},
	{
		"word": "backbone",
		"pos": "noun",
		"meaning": "The most important part that supports the rest.",
		"urdu": "مرکزی سہارا، ریڑھ کی ہڈی",
		"synonyms": [
			"mainstay",
			"foundation",
			"support"
		],
		"antonyms": ["burden", "weakness"],
		"sentences": ["The doctor said that doctors are the backbone of a society."]
	},
	{
		"word": "currently",
		"pos": "adverb",
		"meaning": "At the present time.",
		"urdu": "اس وقت، فی الحال",
		"synonyms": [
			"presently",
			"now",
			"nowadays"
		],
		"antonyms": ["formerly", "previously"],
		"sentences": ["Currently, the job scope in Pakistan is better in electrical and electronics engineering."]
	},
	{
		"word": "amazing",
		"pos": "adjective",
		"meaning": "Wonderful and pleasing; causing surprise and delight.",
		"urdu": "حیرت انگیز",
		"synonyms": [
			"wonderful",
			"astonishing",
			"pleasurable"
		],
		"antonyms": ["ordinary", "dull"],
		"sentences": ["Juma said the exhibition was an amazing experience of learning about professions."]
	},
	{
		"word": "convince",
		"pos": "verb",
		"meaning": "To try to make someone accept an idea.",
		"urdu": "قائل کرنا",
		"synonyms": [
			"persuade",
			"satisfy",
			"assure"
		],
		"antonyms": ["dissuade", "discourage"],
		"sentences": ["Sudheer said he would try to convince his parents to let him become a male nurse."]
	},
	{
		"word": "dental",
		"pos": "adjective",
		"meaning": "Related to the teeth.",
		"urdu": "دانتوں سے متعلق",
		"synonyms": ["oral", "tooth-related"],
		"antonyms": ["no direct antonym"],
		"sentences": ["Sonia wants to study dental surgery because many people in her family have dental problems."]
	},
	{
		"word": "optimism",
		"pos": "noun",
		"meaning": "A feeling that good things will happen.",
		"urdu": "رجائیت، خوش امیدی",
		"synonyms": [
			"hopefulness",
			"confidence",
			"positivity"
		],
		"antonyms": ["pessimism", "despair"],
		"sentences": ["The students left the playground with great optimism after the exhibition."]
	},
	{
		"word": "exhibition",
		"pos": "noun",
		"meaning": "A public show where things are displayed so that people can look and learn.",
		"urdu": "نمائش",
		"synonyms": [
			"display",
			"show",
			"fair"
		],
		"antonyms": ["concealment", "hiding"],
		"sentences": ["Government High School No. 2 Shikarpur organized an educational exhibition in the playground."]
	},
	{
		"word": "profession",
		"pos": "noun",
		"meaning": "A job that needs special education and training.",
		"urdu": "پیشہ",
		"synonyms": [
			"career",
			"occupation",
			"vocation"
		],
		"antonyms": ["hobby", "pastime"],
		"sentences": ["Anum asked whether a girl could also take up agriculture as a profession."]
	},
	{
		"word": "agronomy",
		"pos": "noun",
		"meaning": "The branch of agriculture that deals with soil management and growing crops.",
		"urdu": "علمِ کاشتِ فصل",
		"synonyms": ["crop science", "soil management"],
		"antonyms": ["no direct antonym"],
		"sentences": ["Agronomy deals with soil management and the growing of crops."]
	},
	{
		"word": "horticulture",
		"pos": "noun",
		"meaning": "The growing of fruits, vegetables and flowers.",
		"urdu": "باغبانی",
		"synonyms": [
			"gardening",
			"cultivation",
			"floriculture"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["Horticulture deals with the cultivation of fruits, vegetables and flowers."]
	},
	{
		"word": "cultivation",
		"pos": "noun",
		"meaning": "The work of growing and caring for plants.",
		"urdu": "کاشت",
		"synonyms": [
			"growing",
			"farming",
			"raising"
		],
		"antonyms": ["neglect", "destruction"],
		"sentences": ["Horticulture is the cultivation of fruits, vegetables and flowers."]
	},
	{
		"word": "commerce",
		"pos": "noun",
		"meaning": "The activity of buying and selling, especially on a large scale.",
		"urdu": "تجارت",
		"synonyms": ["trade", "business"],
		"antonyms": ["no direct antonym"],
		"sentences": ["The manager explained that the activity of buying and selling, especially on a large scale, is commerce."]
	},
	{
		"word": "employment",
		"pos": "noun",
		"meaning": "Paid work; having a job.",
		"urdu": "ملازمت، روزگار",
		"synonyms": [
			"job",
			"work",
			"occupation"
		],
		"antonyms": ["unemployment", "idleness"],
		"sentences": ["Commerce education helps prepare students for employment in finance and business."]
	},
	{
		"word": "noble",
		"pos": "adjective",
		"meaning": "Morally good and worthy of honour.",
		"urdu": "معزز، نیک",
		"synonyms": [
			"honourable",
			"worthy",
			"dignified"
		],
		"antonyms": ["ignoble", "shameful"],
		"sentences": ["The friends went to learn about the noble professions of medicine and engineering."]
	},
	{
		"word": "inquisitive",
		"pos": "adjective",
		"meaning": "Wanting to find out more; full of questions.",
		"urdu": "متجسس",
		"synonyms": [
			"curious",
			"questioning",
			"inquiring"
		],
		"antonyms": ["uninterested", "indifferent"],
		"sentences": ["Zainab asked in an inquisitive way how computers could do all those things."]
	},
	{
		"word": "enthusiastically",
		"pos": "adverb",
		"meaning": "In a way that shows strong interest and eagerness.",
		"urdu": "جوش سے",
		"synonyms": [
			"eagerly",
			"excitedly",
			"keenly"
		],
		"antonyms": ["unwillingly", "half-heartedly"],
		"sentences": ["The agricultural expert replied enthusiastically that girls could also study agriculture."]
	},
	{
		"word": "equipment",
		"pos": "noun",
		"meaning": "The tools and machines needed for a particular job.",
		"urdu": "آلات، سامان",
		"synonyms": [
			"tools",
			"machines",
			"apparatus"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["Agricultural engineering involves knowledge of farm machines and equipment."]
	},
	{
		"word": "avail",
		"pos": "verb",
		"meaning": "To make use of a chance that is offered.",
		"urdu": "فائدہ اٹھانا",
		"synonyms": [
			"use",
			"utilize",
			"benefit from"
		],
		"antonyms": ["waste", "miss"],
		"sentences": ["Anum asked if a girl could also avail the opportunities in agriculture."]
	},
	{
		"word": "specialized",
		"pos": "adjective",
		"meaning": "Designed or trained for one particular branch of a subject.",
		"urdu": "خصوصی، مخصوص",
		"synonyms": [
			"particular",
			"expert",
			"specific"
		],
		"antonyms": ["general", "unspecialized"],
		"sentences": ["Majid asked the expert to explain the specialized branches of agriculture."]
	},
	{
		"word": "graduates",
		"pos": "noun",
		"meaning": "People who have completed a course of study.",
		"urdu": "فارغ التحصیل طلبہ",
		"synonyms": ["degree-holders", "alumni"],
		"antonyms": ["dropouts", "undergraduates"],
		"sentences": ["Commerce education can guide young graduates to become successful business people."]
	},
	{
		"word": "narration",
		"pos": "noun",
		"meaning": "The way of reporting what someone said, either in their own words or in indirect speech.",
		"urdu": "بیان، نقلِ کلام",
		"synonyms": ["reporting", "recounting"],
		"antonyms": ["no direct antonym"],
		"sentences": ["In this unit we recognize the rules of narration and change direct statements into indirect speech."]
	},
	{
		"word": "adverb",
		"pos": "noun",
		"meaning": "A word that tells us more about a verb, often how an action was done.",
		"urdu": "متعلق فعل",
		"synonyms": ["modifier", "describing word"],
		"antonyms": ["no direct antonym"],
		"sentences": ["An adverb of manner, such as quickly or gently, tells us how an action was carried out."]
	}
];
var unit4_default = {
	id: "u4",
	number: 4,
	title: title$3,
	learn: learn$3,
	lessons: lessons$3,
	vocab: vocab$3
};
var unit5_exports = /* @__PURE__ */ __exportAll({
	default: () => unit5_default,
	id: () => "u5",
	learn: () => learn$2,
	lessons: () => lessons$2,
	number: () => 5,
	title: () => title$2,
	vocab: () => vocab$2
});
var title$2 = "Humanism";
var learn$2 = [
	{
		"skill": "Reading",
		"points": [
			"Use pre-reading strategies to predict the content of a text from the picture and title by using prior knowledge and asking questions",
			"Skim text to get a general idea of the text",
			"Deduce the meanings of difficult words from the context",
			"Scan to locate an opinion",
			"Scan to answer short questions",
			"Make simple inferences using the context of the text and prior knowledge",
			"Apply world knowledge and own feelings / opinions to the text read"
		]
	},
	{
		"skill": "Speaking",
		"points": ["Express needs and requirements by giving reasons"]
	},
	{
		"skill": "Language Practice",
		"points": ["Converting statements into questions by adding question tags", "Review of linking words: and, but, because"]
	},
	{
		"skill": "Writing",
		"points": ["Write a cause and effect paragraph"]
	},
	{
		"skill": "Study Skills",
		"points": ["Making a weekly schedule"]
	},
	{
		"skill": "Fun",
		"points": ["Creating a personal flag"]
	}
];
var lessons$2 = [
	{
		"id": "5.1",
		"code": "5.1",
		"title": "Reading Comprehension",
		"subtitle": "What Shaped Edhi's Life",
		"kind": "reading",
		"blocks": [
			{
				"type": "h",
				"text": "Pre-Reading"
			},
			{
				"type": "p",
				"text": "Before you read, think about the people who help others. Discuss these questions with a partner."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Are there more good people in the world or bad people?",
					"Why do you think so?",
					"Do you know someone who always helps people?",
					"What does he/she do?",
					"What do you do to help people?"
				]
			},
			{
				"type": "exercise",
				"title": "Pre-Reading Discussion",
				"instruction": "Discuss the questions orally, then write a short answer. The title of the text is What Shaped Edhi's Life? Predict what you will read, then read the text and do Exercise 1 as you read.",
				"items": [
					{
						"kind": "open",
						"q": "Are there more good people in the world or bad people?",
						"model": "I think there are more good people. Many people help others quietly, even when nobody praises them."
					},
					{
						"kind": "open",
						"q": "Why do you think so?",
						"model": "I think so because I see teachers, doctors, neighbours and family members helping people who are poor, sick or in trouble."
					},
					{
						"kind": "open",
						"q": "Do you know someone who always helps people? What does he or she do?",
						"model": "Yes. My aunt helps people. She cooks extra food and gives it to poor families, and she visits sick neighbours."
					},
					{
						"kind": "open",
						"q": "What do you do to help people?",
						"model": "I share my lunch, help classmates with their work, and speak kindly to anyone who is being teased."
					},
					{
						"kind": "open",
						"q": "The title is What Shaped Edhi's Life? What do you think you will read in the text?",
						"model": "I think I will read about Abdul Sattar Edhi's childhood and the people, especially his mother, who taught him to serve humanity."
					}
				]
			},
			{
				"type": "h",
				"text": "Reading Text"
			},
			{
				"type": "p",
				"text": "What Shaped Edhi's Life?"
			},
			{
				"type": "p",
				"text": "Abdul Sattar Edhi, the “Angel of Mercy” as people called him, started his humanitarian work in 1951 by establishing a very small dispensary in Mithadar, Karachi, Pakistan. From this humble beginning, he, single-handedly, went on to create Pakistan's largest charitable organization, based entirely on private donations. Today, the Edhi Foundation employs more than 7,000 people, both paid and voluntary workers, to manage its huge network. In Pakistan, it operates about 1500 ambulances that offer a 24-hour service, from more than 350 Edhi centres. Additionally, there are more than seventeen Edhi homes and 330 welfare centres across Pakistan. They provide shelter for an estimated 85,000 people, including senior citizens, special children, needy children, infants and babies, and they operate food kitchens, clinics and rehabilitation centres for drug addicts and the mentally ill. Even animals have been provided a home in an animal shelter."
			},
			{
				"type": "p",
				"text": "Edhi was born in early 1928, in Bantva, Gujrat, British India. His father, Haji Abdul Shakoor worked as a dry fruit commission agent in Bombay. Since his father was mostly away from home, he was mainly brought up by his mother who, according to Edhi, had a great influence on his life. But other members of his family also contributed in shaping his life, including his father and grandfather. He used to fondly recall that his grandfather, Haji Rehmatullah, was a simple, content, and patient person, who did not believe in surpluses, and even disapproved of having extra food at home. Moreover, he had a reputation in the community for resolving conflicts and settling disputes."
			},
			{
				"type": "p",
				"text": "Thinking back, Abdul Sattar Edhi once said about his father, “My father had very high moral standards for himself. To him, simplicity was the only tolerable way of life. When we migrated to Pakistan, we got into serious financial trouble. However, he never complained; and throughout these times, he was never dishonest in his business. Despite the fact that life in Pakistan was very difficult at that time, my father was a truly optimistic person and always had a positive attitude.”"
			},
			{
				"type": "p",
				"text": "In Bantva, Abdul Sattar Edhi was known among his friends as Roti. As Edhi explained: “Every time my father came back home from one of his trips, he shaved my head. Once, when I asked him why he does it he explained that it is simply the most effective way to curb pride and prevent arrogance. It makes you work better because appearance is a distraction. When you don't think about the way you look, you develop humility and truth. I think it was the best lesson I was ever taught.”"
			},
			{
				"type": "p",
				"text": "However, the person who apparently made Abdul Sattar Edhi the man he became was his mother. Edhi said of his mother that she was a very gentle, sensitive and quiet person. She guided Edhi in such a manner that he grew up to be a very kind and sensitive person. He was particularly caring where the old, handicapped or mentally challenged people were concerned. If ever he saw some mean kids making fun of the mentally challenged, he would stop them. His mother always appreciated such acts by saying, “You have given a voice to those who do not have it. These people are as innocent as babies; they know nothing of the world and yet they have to live as adults.”"
			},
			{
				"type": "p",
				"text": "According to Abdul Sattar Edhi, he learnt about love and care from his mother. She would always distribute cashew nuts, pistachios, ginger and other food items that her husband sent her from Bombay, amongst the poorer families in her neighbourhood. She would ask young Edhi to distribute these packets to families who were less fortunate than they were. One story that Edhi liked to share about his mother was about his school days. He said that when he was in school, his mother used to give him two paisas: one to buy something to eat for himself and the other to buy whatever he was eating for a poor boy watching him eat, but who had no money to buy it for himself. Often, when she asked him about the two paisas, he confessed that he had spent both the paisas on buying things for himself. Hearing this she would tell him that he had eaten poor people's money. These poor people were mazlooms (disadvantaged). She told him to fear Allah as He never helps those who do not look after the mazlooms, who do not fulfill Huquq-ul-Ibaad (the rights of other human beings), as this was the first priority in Islam."
			},
			{
				"type": "p",
				"text": "Edhi also talked of the way his mother ensured that he did not waste his time. She would ask him to bring raw cotton to their home. She would then clean it and ask him to take it back to the shop in order to earn some money. She was of the view that no one should sit at home idly; everyone should work to earn a living."
			},
			{
				"type": "p",
				"text": "Edhi often fondly recalled that it was his mother who planted the seed of social welfare and charitable work in him. She not only nurtured it but taught him how to control his desire for material things and to overcome personal greed. Edhi often said that although his mother's whole life was a struggle, she was always positive and kind to others. She was the one who taught him love for humanity when he was a child. So, after her death, he decided to dedicate his whole life to the service of humanity."
			},
			{
				"type": "p",
				"text": "After his mother passed away, Edhi bought an old wagon, with donation from a friend, and converted it into an ambulance. This was the first ambulance service for the poor people and he called it the “Poor People's Van”. He did not charge for the ambulance service. But when people insisted on paying for it they were told to drop money in a box outside the dispensary. Soon he was able to increase the reach of his services and because of the ambulance more and more people got to know about Edhi's organization and services."
			},
			{
				"type": "p",
				"text": "He even started a funeral service which picked up human bodies found in the sea, in rivers, in gutters or at the roadside. He would even pick up these bodies, himself, when the family members refused to touch them. He would bring these bodies to Mithadar, wash them and provide a proper burial service. According to an observer of the Edhi foundation, the ambulance service and the funeral services provided Edhi foundation an excellent opportunity to grow all over Pakistan, since there was no other organisation doing this; not even the government."
			},
			{
				"type": "p",
				"text": "An old associate of Edhi said about him, “Edhi's self transformation was for a social mission and not for himself; he changed his life style for his mission. People do change, but mostly for themselves; Edhi changed for others.” Hence, no matter how insurmountable the difficulties and how challenging the times, he never lost his positive attitude and confident outlook. Moreover, he made a commitment to himself that he would never give anybody reason to challenge his integrity or his lifestyle; that he would never spend extra time or money on himself or his family. He had only three pairs of clothes, one pair of plastic Chappal, one Jinnah Cap, and he slept on the wooden bench in his dispensary, so that people could see how he was living."
			},
			{
				"type": "p",
				"text": "Abdul Sattar Edhi died on July 8, 2016, in Karachi, Pakistan, due to kidney failure. The man is gone but the mission will continue. His mission was to serve humanity, regardless of religion, race, and background. He adopted a life style that would help him achieve this mission. It was this simplicity of life and this humanitarian vision, which had been inculcated in him by his parents, mainly his mother, that made him the Abdul Sattar Edhi that he became; the first common citizen of Pakistan, in nearly seventy years of its history, to receive a state funeral."
			},
			{
				"type": "h",
				"text": "While Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Read the text and answer the following questions by ticking the correct answer.",
				"items": [{
					"kind": "mcq",
					"q": "Who had the most influence in shaping Edhi's life?",
					"options": [
						"his grandfather",
						"his father",
						"his mother",
						"his friends"
					],
					"answer": 2
				}, {
					"kind": "mcq",
					"q": "Why did he choose to help people instead of earning money for himself?",
					"options": [
						"His father told him to do so.",
						"His mother taught him to be kind and charitable.",
						"He had a lot of money so he did not need to work.",
						"He was a lazy person."
					],
					"answer": 1
				}]
			},
			{
				"type": "h",
				"text": "Vocabulary"
			},
			{
				"type": "p",
				"text": "The meanings below are in the same order as the words appear in the text, but the words in the book are jumbled. First underline all the given words in the text. Then match each word with its meaning. One example in the book is network, meaning a group of organizations working together."
			},
			{
				"type": "note",
				"text": "The printed book labels the box with curb, arrogance, humility, distraction, handicapped, mentally challenged, mean and appreciated as “Paragraphs 11 & 12”. Those words are in paragraphs 4 and 5. The later box about associate, integrity and the state funeral really is paragraphs 11 and 12."
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Match each word with its meaning. Work in the order the words appear in the text.",
				"items": [
					{
						"kind": "match",
						"q": "Paragraph 1",
						"pairs": [
							{
								"left": "humanitarian work",
								"right": "work that helps in making people's lives better"
							},
							{
								"left": "humble",
								"right": "low"
							},
							{
								"left": "single-handedly",
								"right": "all by himself"
							},
							{
								"left": "charitable",
								"right": "helping people who are poor or in need"
							},
							{
								"left": "voluntary",
								"right": "work done by people who are not paid"
							},
							{
								"left": "network",
								"right": "a group of organizations working together"
							},
							{
								"left": "operate",
								"right": "work in a particular way"
							},
							{
								"left": "rehabilitation centres",
								"right": "a place where people learn to live a useful life once again"
							},
							{
								"left": "drug-addicts",
								"right": "people who regularly use harmful drugs"
							}
						]
					},
					{
						"kind": "match",
						"q": "Paragraphs 2 and 3",
						"pairs": [
							{
								"left": "fondly",
								"right": "in a loving way"
							},
							{
								"left": "recalls",
								"right": "think back about something"
							},
							{
								"left": "content",
								"right": "satisfied"
							},
							{
								"left": "surpluses",
								"right": "extra things"
							},
							{
								"left": "conflicts",
								"right": "disagreements"
							},
							{
								"left": "moral standards",
								"right": "levels of right and wrong behaviour"
							},
							{
								"left": "optimistic",
								"right": "always expecting good things to happen"
							},
							{
								"left": "disputes",
								"right": "fights"
							}
						]
					},
					{
						"kind": "match",
						"q": "Paragraphs 4 and 5 (Roti and his mother)",
						"pairs": [
							{
								"left": "curb",
								"right": "control"
							},
							{
								"left": "arrogance",
								"right": "proud behaviour"
							},
							{
								"left": "distraction",
								"right": "something that takes away your attention"
							},
							{
								"left": "humility",
								"right": "considering oneself as someone very small"
							},
							{
								"left": "handicapped",
								"right": "not able to use a particular part of the body"
							},
							{
								"left": "mentally challenged",
								"right": "not able to use their mind properly"
							},
							{
								"left": "mean",
								"right": "selfish"
							},
							{
								"left": "appreciated",
								"right": "recognise something good"
							}
						]
					},
					{
						"kind": "match",
						"q": "Paragraphs 6, 7 and 8",
						"pairs": [
							{
								"left": "fortunate",
								"right": "lucky"
							},
							{
								"left": "confessed",
								"right": "admit having done something wrong"
							},
							{
								"left": "disadvantaged",
								"right": "not having things that one needs for a proper living"
							},
							{
								"left": "priority",
								"right": "something that is more important than the other"
							},
							{
								"left": "ensured",
								"right": "made sure"
							},
							{
								"left": "idly",
								"right": "doing nothing"
							},
							{
								"left": "nurtured",
								"right": "developed"
							}
						]
					},
					{
						"kind": "match",
						"q": "Paragraphs 11 and 12",
						"pairs": [
							{
								"left": "associate",
								"right": "a person whom you work with or spend time with"
							},
							{
								"left": "transformation",
								"right": "complete change"
							},
							{
								"left": "insurmountable",
								"right": "something that cannot be overcome"
							},
							{
								"left": "challenging",
								"right": "difficult"
							},
							{
								"left": "outlook",
								"right": "the way one looks at something"
							},
							{
								"left": "integrity",
								"right": "honesty"
							},
							{
								"left": "vision",
								"right": "ability to think about the future in an intelligent way"
							},
							{
								"left": "regardless",
								"right": "not to give importance to something"
							},
							{
								"left": "state funeral",
								"right": "a burial with honour given to the head of a state"
							}
						]
					}
				]
			},
			{
				"type": "h",
				"text": "Reading for Details"
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Work in pairs, read the text and fill in this basic information about Abdul Sattar Edhi.",
				"items": [
					{
						"kind": "fill",
						"q": "Name: ____",
						"answers": ["Abdul Sattar Edhi"]
					},
					{
						"kind": "fill",
						"q": "Father's name: ____",
						"answers": ["Haji Abdul Shakoor", "Abdul Shakoor"]
					},
					{
						"kind": "fill",
						"q": "Father's profession: ____",
						"answers": [
							"dry fruit commission agent",
							"a dry fruit commission agent in Bombay",
							"He worked as a dry fruit commission agent in Bombay."
						]
					},
					{
						"kind": "fill",
						"q": "Grandfather's name: ____",
						"answers": ["Haji Rehmatullah"]
					},
					{
						"kind": "fill",
						"q": "Reasons for grandfather's fame: ____",
						"answers": [
							"He had a reputation for resolving conflicts and settling disputes.",
							"He resolved conflicts and settled disputes.",
							"People knew him for resolving conflicts and settling disputes."
						]
					},
					{
						"kind": "fill",
						"q": "Year of birth: ____",
						"answers": ["early 1928", "1928"]
					},
					{
						"kind": "fill",
						"q": "Place of birth: ____",
						"answers": [
							"Bantva, Gujrat, British India",
							"Bantva, Gujarat, British India",
							"Bantva"
						]
					},
					{
						"kind": "fill",
						"q": "Title given by people: ____",
						"answers": [
							"Angel of Mercy",
							"the Angel of Mercy",
							"“Angel of Mercy”"
						]
					},
					{
						"kind": "fill",
						"q": "Two services that made him famous: ____",
						"answers": [
							"the ambulance service and the funeral service",
							"ambulance and funeral services",
							"his ambulance service and his funeral service"
						]
					},
					{
						"kind": "fill",
						"q": "Name of first ambulance service: ____",
						"answers": [
							"Poor People's Van",
							"the Poor People's Van",
							"“Poor People's Van”"
						]
					},
					{
						"kind": "fill",
						"q": "Charges for the first ambulance service: ____",
						"answers": [
							"He did not charge.",
							"no charge",
							"free",
							"He did not charge any money."
						]
					},
					{
						"kind": "fill",
						"q": "Date of death: ____",
						"answers": [
							"July 8, 2016",
							"8 July 2016",
							"8th July 2016"
						]
					},
					{
						"kind": "fill",
						"q": "Place of death: ____",
						"answers": ["Karachi, Pakistan", "Karachi"]
					},
					{
						"kind": "fill",
						"q": "Historical honour: ____",
						"answers": [
							"He was the first common citizen of Pakistan to receive a state funeral.",
							"the first common citizen of Pakistan, in nearly seventy years, to receive a state funeral",
							"a state funeral"
						]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "There are 12 paragraphs in the text. Each statement gives the main idea of one paragraph, but they are jumbled. Match each main idea with the number of the paragraph it represents. The book gives the first one: shaving of Edhi's head is paragraph 4.",
				"items": [{
					"kind": "match",
					"q": "Match the main idea with its paragraph number.",
					"pairs": [
						{
							"left": "Shaving of Edhi's head by his father",
							"right": "4"
						},
						{
							"left": "His commitment to an honest and simple life",
							"right": "11"
						},
						{
							"left": "Edhi's first ambulance",
							"right": "9"
						},
						{
							"left": "His mother's role and her appreciation of his good deeds",
							"right": "5"
						},
						{
							"left": "The death of a truly national hero",
							"right": "12"
						},
						{
							"left": "Edhi's birth and family",
							"right": "2"
						},
						{
							"left": "Some information about the funeral service",
							"right": "10"
						},
						{
							"left": "Growth of Edhi Foundation activities",
							"right": "1"
						},
						{
							"left": "The loving and caring nature of his mother",
							"right": "6"
						},
						{
							"left": "The reason why Edhi decided to dedicate his life to serve others",
							"right": "8"
						},
						{
							"left": "Some information about his father",
							"right": "3"
						},
						{
							"left": "His mother's views regarding use of time",
							"right": "7"
						}
					]
				}, {
					"kind": "classify",
					"q": "Place each event in the stage of Edhi's life it belongs to.",
					"buckets": [
						"Early life and family",
						"His mother's lessons",
						"Service, simplicity and death"
					],
					"cards": [
						{
							"text": "The work of his life grows into about 1500 ambulances, many homes and care for about 85,000 people.",
							"bucket": 2
						},
						{
							"text": "Edhi is born in Bantva and is shaped by his grandfather, father and mother.",
							"bucket": 0
						},
						{
							"text": "His father keeps high moral standards and stays optimistic in poverty.",
							"bucket": 0
						},
						{
							"text": "His father shaves his head to curb pride, and friends call him Roti.",
							"bucket": 0
						},
						{
							"text": "His mother praises him for defending the mentally challenged.",
							"bucket": 1
						},
						{
							"text": "She teaches him to share with the mazlooms and to fear Allah.",
							"bucket": 1
						},
						{
							"text": "She makes sure he does not sit idly and teaches him to earn a living.",
							"bucket": 1
						},
						{
							"text": "After her death he dedicates his life to humanity.",
							"bucket": 1
						},
						{
							"text": "He starts the Poor People's Van and a funeral service.",
							"bucket": 2
						},
						{
							"text": "He lives with three pairs of clothes and sleeps on a wooden bench.",
							"bucket": 2
						},
						{
							"text": "He dies in Karachi in 2016 and receives a state funeral.",
							"bucket": 2
						}
					]
				}]
			},
			{
				"type": "h",
				"text": "Post Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "Complete the sentences from the text. The first one has been done as an example.",
				"items": [
					{
						"kind": "fill",
						"q": "Edhi was mainly brought up by his mother because ____.",
						"answers": ["his father was mostly away from home", "his father was mostly away from home."]
					},
					{
						"kind": "fill",
						"q": "In Bantva, Edhi was known as Roti because ____.",
						"answers": [
							"his father used to shave his head",
							"his father shaved his head whenever he came home",
							"his head was kept shaved",
							"his father shaved his head"
						]
					},
					{
						"kind": "fill",
						"q": "His father shaved his head because ____.",
						"answers": [
							"it was the most effective way to curb pride and prevent arrogance",
							"he wanted to curb pride and prevent arrogance",
							"appearance is a distraction and a shaved head develops humility",
							"shaving curbed pride and prevented arrogance"
						]
					},
					{
						"kind": "fill",
						"q": "Edhi grew up to be a kind and sensitive person because ____.",
						"answers": [
							"his mother guided him to be kind and sensitive",
							"his mother was gentle and guided him in that way",
							"his mother guided him so that he became kind and sensitive"
						]
					},
					{
						"kind": "fill",
						"q": "His mother told him to fear Allah because ____.",
						"answers": [
							"Allah never helps those who do not look after the mazlooms",
							"he had spent poor people's money on himself",
							"those who do not fulfill Huquq-ul-Ibaad are not helped by Allah",
							"he did not look after the disadvantaged"
						]
					},
					{
						"kind": "fill",
						"q": "Edhi dedicated his whole life to the service of humanity after his mother's death because ____.",
						"answers": [
							"she had taught him love for humanity",
							"she planted the seed of social welfare in him",
							"his mother had taught him to serve humanity and he wanted to continue that work",
							"she nurtured charitable work in him"
						]
					},
					{
						"kind": "fill",
						"q": "More and more people came to know about Edhi's organization and services because of ____.",
						"answers": [
							"the ambulance",
							"the ambulance service",
							"his ambulance",
							"the Poor People's Van"
						]
					},
					{
						"kind": "fill",
						"q": "He often picked up bodies himself because ____.",
						"answers": [
							"the family members refused to touch them",
							"families refused to touch the bodies",
							"the relatives would not touch the bodies"
						]
					},
					{
						"kind": "fill",
						"q": "Edhi's ambulance and funeral services allowed the foundation to grow all over Pakistan because ____.",
						"answers": [
							"no other organisation was doing this work, not even the government",
							"there was no other organisation doing this",
							"nobody else, not even the government, provided these services"
						]
					},
					{
						"kind": "fill",
						"q": "He never spent extra time or money on himself or his family because ____.",
						"answers": [
							"he did not want anybody to challenge his integrity or his lifestyle",
							"he had promised himself to live a simple and honest life",
							"he wanted nobody to doubt his honesty"
						]
					},
					{
						"kind": "fill",
						"q": "He slept on a wooden bench in his dispensary because ____.",
						"answers": [
							"he wanted people to see how he was living",
							"so that people could see how simply he lived",
							"people could see his simple life"
						]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "All the following sentences give wrong information. Read the text and write the correct information.",
				"items": [
					{
						"kind": "fill",
						"q": "Wrong: Edhi started his humanitarian work in 1977 by establishing an ambulance service. Correct: ____",
						"answers": [
							"Edhi started his humanitarian work in 1951 by establishing a very small dispensary in Mithadar, Karachi.",
							"He started in 1951 with a small dispensary, not an ambulance service in 1977.",
							"In 1951 he established a very small dispensary in Mithadar."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: Today, the Edhi Foundation has less than 300 people working for its small network. Correct: ____",
						"answers": [
							"The Edhi Foundation employs more than 7,000 people to manage its huge network.",
							"More than 7,000 paid and voluntary workers manage its huge network.",
							"It has a huge network run by more than 7,000 people."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: His grandfather was a wealthy, rude and unkind person. Correct: ____",
						"answers": [
							"His grandfather, Haji Rehmatullah, was a simple, content and patient person.",
							"Haji Rehmatullah was simple, content and patient, and he settled disputes.",
							"His grandfather was simple, content and patient, not wealthy or unkind."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: When Edhi's family migrated to Pakistan, they had a lot of money. Correct: ____",
						"answers": [
							"When they migrated to Pakistan, they got into serious financial trouble.",
							"They were in serious financial trouble after migrating to Pakistan.",
							"Life in Pakistan was very difficult and they had little money."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: His father was a very pessimistic person who always had a negative attitude. Correct: ____",
						"answers": [
							"His father was a truly optimistic person and always had a positive attitude.",
							"His father was optimistic and never complained.",
							"He was optimistic, honest and positive even in hard times."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: As a boy, when Edhi saw older people making fun of mentally challenged people he would join them. Correct: ____",
						"answers": [
							"When he saw mean kids making fun of the mentally challenged, he would stop them.",
							"He stopped children who made fun of mentally challenged people.",
							"He defended the mentally challenged instead of joining the teasing."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: His mother told him that fulfilling one's own needs was the first priority in Islam. Correct: ____",
						"answers": [
							"She said that fulfilling Huquq-ul-Ibaad, the rights of other human beings, was the first priority in Islam.",
							"Looking after the mazlooms and fulfilling the rights of others was the first priority in Islam.",
							"The first priority in Islam was the rights of other people, not only one's own needs."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: When he started his ambulance service he charged people a lot of money. Correct: ____",
						"answers": [
							"He did not charge for the ambulance service.",
							"The Poor People's Van was free.",
							"He did not charge; people who insisted could drop money in a box."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: He had many sets of clothes, dozens of shoes and beautiful caps. Correct: ____",
						"answers": [
							"He had only three pairs of clothes, one pair of plastic chappal and one Jinnah cap.",
							"He owned three pairs of clothes, one pair of plastic Chappal and one Jinnah Cap.",
							"He lived with only three pairs of clothes, one pair of chappals and one Jinnah cap."
						]
					},
					{
						"kind": "fill",
						"q": "Wrong: Many common citizens of Pakistan have received a state funeral. Correct: ____",
						"answers": [
							"He was the first common citizen of Pakistan, in nearly seventy years, to receive a state funeral.",
							"Edhi was the first ordinary citizen of Pakistan to be given a state funeral.",
							"In nearly seventy years he was the first common citizen to receive a state funeral."
						]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 7",
				"instruction": "Answer these questions in your own words. Use ideas from the text.",
				"items": [
					{
						"kind": "open",
						"q": "What are some of the things that Edhi's mother taught him?",
						"model": "She taught him love, care and kindness. She taught him to share food with poorer families, to give one of his two paisas to a poor boy, to fear Allah, and to look after the mazlooms by fulfilling Huquq-ul-Ibaad. She also taught him not to waste time, to work for a living, to control greed, and to love humanity."
					},
					{
						"kind": "open",
						"q": "What was Edhi's mission in life?",
						"model": "His mission was to serve humanity, regardless of religion, race and background. He wanted to help the poor, the sick, the abandoned and even the dead who had nobody to bury them."
					},
					{
						"kind": "open",
						"q": "Why was Abdul Sattar Edhi given a state funeral?",
						"model": "He was given a state funeral because of his lifelong service to humanity and his simple, honest life. He was the first common citizen of Pakistan, in nearly seventy years of its history, to receive this honour."
					},
					{
						"kind": "open",
						"q": "In your opinion, what shaped Edhi's life?",
						"model": "His family shaped his life, especially his mother. Her kindness, charity and lessons about the rights of others planted social work in him. His father's honesty and simplicity, and his grandfather's contentment, also taught him to live for others rather than for money."
					},
					{
						"kind": "open",
						"q": "What are some of the things that you would like to do to help people?",
						"model": "I would like to share food with poor families, help younger children with their studies, visit sick people, and never laugh at anyone who is handicapped or mentally challenged. I can also give a little of my pocket money and some of my time."
					}
				]
			}
		]
	},
	{
		"id": "5.2",
		"code": "5.2",
		"title": "Speaking",
		"subtitle": "Expressing Needs and Requirements by Giving Reasons",
		"kind": "speaking",
		"blocks": [
			{
				"type": "h",
				"text": "Expressing Needs and Requirements by Giving Reasons"
			},
			{
				"type": "p",
				"text": "When you ask for something, do not only say what you want. Give a clear reason. Work in pairs and complete the dialogue between two siblings. Then practise it orally. Change roles and practise again."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Brother",
						"text": "Can I borrow your bag today?"
					},
					{
						"who": "Sister",
						"text": "No, I won't give you my bag. It's a gift from my friend and you will tear it."
					},
					{
						"who": "Brother",
						"text": "I promise you I'll take good care of it. I need it because ____."
					},
					{
						"who": "Sister",
						"text": "Ok, you can take it but ____."
					},
					{
						"who": "Brother",
						"text": "Thank you. I'll ____."
					}
				]
			},
			{
				"type": "exercise",
				"title": "Complete the dialogue",
				"instruction": "Fill the gaps by giving a reason, a condition and a promise. Then say the dialogue aloud.",
				"items": [
					{
						"kind": "fill",
						"q": "I need it because ____.",
						"answers": [
							"I have to carry my project to school and my own bag is torn",
							"I need to take my books to a friend's house for group study",
							"my bag is broken and I have to take my homework safely"
						]
					},
					{
						"kind": "fill",
						"q": "Ok, you can take it but ____.",
						"answers": [
							"bring it back today in the same condition",
							"you must not tear it and return it this evening",
							"do not overfill it and bring it back clean"
						]
					},
					{
						"kind": "fill",
						"q": "Thank you. I'll ____.",
						"answers": [
							"take good care of it and return it as soon as I come home",
							"keep it clean and bring it back this evening",
							"use it carefully and return it today"
						]
					}
				]
			},
			{
				"type": "h",
				"text": "Three situations"
			},
			{
				"type": "p",
				"text": "Now discuss the following three situations orally. Give reasons for what you need. You may note a few key words, but practise speaking rather than reading a script."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Dialogue between a teacher and a student: A student wants three days' leave for a wedding in the family and explains why taking the leave is important.",
					"Dialogue between a father and son: The son wants to buy a bicycle and he gives reasons to his father why he needs it.",
					"Dialogue between two neighbours: One neighbour wants the other to look after his or her house while the family is away and gives reasons why he or she wants help."
				]
			},
			{
				"type": "note",
				"text": "In each dialogue, say what you need and add because. Listen to your partner's condition, then promise what you will do."
			},
			{
				"type": "exercise",
				"title": "Role-play",
				"instruction": "Practise each situation with a partner. Use the model only after you have tried your own reasons.",
				"items": [
					{
						"kind": "open",
						"q": "Teacher and student: ask for three days' leave for a family wedding and give reasons.",
						"model": "Student: Sir, may I have three days' leave? My cousin is getting married in another city and my parents need my help with the guests. I need the leave because this is an important family event and we have to travel. Teacher: How will you cover the lessons? Student: I will copy the notes and finish my homework as soon as I return on Thursday. Teacher: Bring a note from your father, and you may go."
					},
					{
						"kind": "open",
						"q": "Father and son: ask for a bicycle and give reasons.",
						"model": "Son: Father, may I buy a bicycle? I need it because the school is far and I reach home too late to study. A bicycle will also let me do small errands for you. Father: Bicycles cost money. Will you look after it? Son: Yes. I will lock it every day, and the time I save will go into my studies. Father: If your marks stay good, we will buy a simple one."
					},
					{
						"kind": "open",
						"q": "Two neighbours: ask someone to look after your house while you are away, and give reasons.",
						"model": "Neighbour: We are going to our village for a week. Could you please watch our house? I need your help because the house will be empty and I am afraid of theft. You live next door, so you will notice if a stranger comes. I will leave a key with you for an emergency. Neighbour: All right. I will keep an eye on the gate and water the plants."
					}
				]
			}
		]
	},
	{
		"id": "5.3",
		"code": "5.3",
		"title": "Language Practice",
		"subtitle": "Tag Questions and Linking Words (and, but, because)",
		"kind": "language",
		"blocks": [
			{
				"type": "h",
				"text": "Converting Statements into Questions by Adding Question Tags"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "Quite often we ask a question by adding a question tag to a statement. A negative tag is used with a positive statement and a positive tag is used with a negative statement. Examples: Sahir is a nice boy, isn't he? This is a difficult task, isn't it? They aren't very busy, are they? The bird isn't flying very high, is it? Verbs commonly used for question tags are be, do, have, can, will and shall. Further examples: The cat drinks milk, doesn't it? The children ate the mangoes, didn't they? You have done your homework, haven't you? I can get good marks, can't I? The policeman will catch the thief, won't he? Rules: where the verb be is used in the statement, it is also used in the tag; where the verb is in the simple present or simple past, do or did is used in the tag; where a helping verb such as can, have or will is used in the statement, the same helping verb is used in the tag; will becomes won't in the negative tag; a noun in the statement is replaced by a suitable pronoun in the tag."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Add the appropriate question tag. A positive statement takes a negative tag, and a negative statement takes a positive tag. Check the rules before you begin, then compare with your partner.",
				"items": [
					{
						"kind": "fill",
						"q": "My bag isn't under the table, ____",
						"answers": ["is it?", "is it"],
						"hint": "Negative statement: positive tag with be."
					},
					{
						"kind": "fill",
						"q": "The children are really enjoying themselves, ____",
						"answers": ["aren't they?", "aren't they"]
					},
					{
						"kind": "fill",
						"q": "The old man looks very tired, ____",
						"answers": ["doesn't he?", "doesn't he"],
						"hint": "looks is simple present, so use does."
					},
					{
						"kind": "fill",
						"q": "You can't open this lock with your key, ____",
						"answers": ["can you?", "can you"]
					},
					{
						"kind": "fill",
						"q": "The goats are busy grazing grass, ____",
						"answers": ["aren't they?", "aren't they"]
					},
					{
						"kind": "fill",
						"q": "The team has practised a lot today, ____",
						"answers": [
							"hasn't it?",
							"hasn't it",
							"haven't they?",
							"haven't they"
						]
					},
					{
						"kind": "fill",
						"q": "The teacher won't take the test today, ____",
						"answers": [
							"will he?",
							"will she?",
							"will he",
							"will she"
						]
					},
					{
						"kind": "fill",
						"q": "This man isn't your uncle, ____",
						"answers": ["is he?", "is he"]
					},
					{
						"kind": "fill",
						"q": "Your tea is getting cold, ____",
						"answers": ["isn't it?", "isn't it"]
					},
					{
						"kind": "fill",
						"q": "We haven't paid our electric bill, ____",
						"answers": ["have we?", "have we"]
					},
					{
						"kind": "fill",
						"q": "My mother cleans the house every day, ____",
						"answers": ["doesn't she?", "doesn't she"]
					},
					{
						"kind": "fill",
						"q": "I don't know how to drive a car, ____",
						"answers": ["do I?", "do I"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Rewrite each statement as a question by adding the appropriate question tag. Write the tag in the blank.",
				"items": [
					{
						"kind": "fill",
						"q": "The train is late today, ____",
						"answers": ["isn't it?", "isn't it"]
					},
					{
						"kind": "fill",
						"q": "You aren't going to see the match tomorrow, ____",
						"answers": ["are you?", "are you"]
					},
					{
						"kind": "fill",
						"q": "They finished their work on time, ____",
						"answers": ["didn't they?", "didn't they"]
					},
					{
						"kind": "fill",
						"q": "The school is far from their house, ____",
						"answers": ["isn't it?", "isn't it"]
					},
					{
						"kind": "fill",
						"q": "The students should obey the school rules, ____",
						"answers": ["shouldn't they?", "shouldn't they"]
					},
					{
						"kind": "fill",
						"q": "The mountain climbers have reached the top, ____",
						"answers": ["haven't they?", "haven't they"]
					},
					{
						"kind": "fill",
						"q": "Our football team can win this match, ____",
						"answers": [
							"can't it?",
							"can't they?",
							"can't it",
							"can't they"
						]
					},
					{
						"kind": "fill",
						"q": "The child is not crossing the road properly, ____",
						"answers": [
							"is he?",
							"is she?",
							"is he",
							"is she"
						]
					},
					{
						"kind": "fill",
						"q": "My sister exercises every day, ____",
						"answers": ["doesn't she?", "doesn't she"]
					},
					{
						"kind": "fill",
						"q": "I will get good grades in my exams, ____",
						"answers": ["won't I?", "won't I"]
					},
					{
						"kind": "fill",
						"q": "Last night, their dog barked the whole night, ____",
						"answers": ["didn't it?", "didn't it"]
					},
					{
						"kind": "fill",
						"q": "They shouldn't talk so loudly when everyone is sleeping, ____",
						"answers": ["should they?", "should they"]
					}
				]
			},
			{
				"type": "h",
				"text": "Exercise 3"
			},
			{
				"type": "p",
				"text": "Work in pairs and orally complete the dialogue with question tags. Then write the complete dialogue."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Zaman",
						"text": "We are going on a field trip this Saturday, ____?"
					},
					{
						"who": "Hamza",
						"text": "Yes. And we'll leave at six o'clock, ____?"
					},
					{
						"who": "Shoaib",
						"text": "Mr. Qureshi is also coming with us, ____?"
					},
					{
						"who": "Zaman",
						"text": "But Mr. Mirza won't come, ____?"
					},
					{
						"who": "Hamza",
						"text": "I'm sure it will be great fun, ____?"
					},
					{
						"who": "Shoaib",
						"text": "If we are allowed to swim it will be fun, otherwise we will get bored, ____?"
					},
					{
						"who": "Zaman",
						"text": "Depends. Hamza and I will enjoy playing cricket, ____, Hamza?"
					},
					{
						"who": "Hamza",
						"text": "Sure. Abid and Haseeb will also play with us, ____?"
					},
					{
						"who": "Shoaib",
						"text": "The school management will provide us the bats and balls, ____?"
					},
					{
						"who": "Zaman",
						"text": "I think they will, ____?"
					},
					{
						"who": "Hamza",
						"text": "Well, last time they did and we had a great time, ____?"
					},
					{
						"who": "Shoaib",
						"text": "We can always catch up on our sleep if there is nothing else to do, ____?"
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Write the question tag for each line. For “I think they will”, the natural tag asks about what they will do.",
				"items": [
					{
						"kind": "fill",
						"q": "Zaman: We are going on a field trip this Saturday, ____",
						"answers": ["aren't we?", "aren't we"]
					},
					{
						"kind": "fill",
						"q": "Hamza: And we'll leave at six o'clock, ____",
						"answers": ["won't we?", "won't we"]
					},
					{
						"kind": "fill",
						"q": "Shoaib: Mr. Qureshi is also coming with us, ____",
						"answers": ["isn't he?", "isn't he"]
					},
					{
						"kind": "fill",
						"q": "Zaman: But Mr. Mirza won't come, ____",
						"answers": ["will he?", "will he"]
					},
					{
						"kind": "fill",
						"q": "Hamza: I'm sure it will be great fun, ____",
						"answers": ["won't it?", "won't it"]
					},
					{
						"kind": "fill",
						"q": "Shoaib: If we are allowed to swim it will be fun, otherwise we will get bored, ____",
						"answers": ["won't we?", "won't we"]
					},
					{
						"kind": "fill",
						"q": "Zaman: Hamza and I will enjoy playing cricket, ____, Hamza?",
						"answers": ["won't we?", "won't we"]
					},
					{
						"kind": "fill",
						"q": "Hamza: Abid and Haseeb will also play with us, ____",
						"answers": ["won't they?", "won't they"]
					},
					{
						"kind": "fill",
						"q": "Shoaib: The school management will provide us the bats and balls, ____",
						"answers": [
							"won't they?",
							"won't it?",
							"won't they"
						]
					},
					{
						"kind": "fill",
						"q": "Zaman: I think they will, ____",
						"answers": [
							"won't they?",
							"don't I?",
							"won't they"
						]
					},
					{
						"kind": "fill",
						"q": "Hamza: Well, last time they did and we had a great time, ____",
						"answers": [
							"didn't we?",
							"didn't they?",
							"didn't we"
						]
					},
					{
						"kind": "fill",
						"q": "Shoaib: We can always catch up on our sleep if there is nothing else to do, ____",
						"answers": ["can't we?", "can't we"]
					}
				]
			},
			{
				"type": "h",
				"text": "Linking Words: and, but, because"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "We often use linking words to join sentences. Here we review three. Use and to show addition or similarity. Use but to show a contrast or difference. Use because to give a reason. Examples: I like reading. I also like painting. → I like reading and painting. Sanam loves gardening. She does not enjoy cooking. → Sanam loves gardening but she does not enjoy cooking. He likes swimming. Swimming keeps him fit. → He likes swimming because it keeps him fit."
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Join each pair with and, but, or because. Compare your answers with your partner.",
				"items": [
					{
						"kind": "fill",
						"q": "The colour of this dress is nice. I like the colour of the dress that you bought. ____",
						"answers": [
							"The colour of this dress is nice but I like the colour of the dress that you bought.",
							"The colour of this dress is nice, but I like the colour of the dress that you bought.",
							"The colour of this dress is nice and I like the colour of the dress that you bought."
						]
					},
					{
						"kind": "fill",
						"q": "Our house is big. It has a nice view of the river. ____",
						"answers": ["Our house is big and it has a nice view of the river.", "Our house is big and has a nice view of the river."]
					},
					{
						"kind": "fill",
						"q": "My sister wants to go to university. She wants to become an engineer. ____",
						"answers": [
							"My sister wants to go to university because she wants to become an engineer.",
							"My sister wants to go to university and become an engineer.",
							"My sister wants to go to university and she wants to become an engineer."
						]
					},
					{
						"kind": "fill",
						"q": "His older brother is a pilot. His younger brother also wants to become a pilot. ____",
						"answers": ["His older brother is a pilot and his younger brother also wants to become a pilot.", "His older brother is a pilot, and his younger brother also wants to become a pilot."]
					},
					{
						"kind": "fill",
						"q": "We can reach Gilgit faster by air. Travelling by road is much fun. ____",
						"answers": ["We can reach Gilgit faster by air but travelling by road is much fun.", "We can reach Gilgit faster by air, but travelling by road is much fun."]
					},
					{
						"kind": "fill",
						"q": "Growing vegetables at home is good. We can have fresh vegetables to eat. ____",
						"answers": ["Growing vegetables at home is good because we can have fresh vegetables to eat.", "Growing vegetables at home is good, because we can have fresh vegetables to eat."]
					},
					{
						"kind": "fill",
						"q": "Playing games is good. Playing all the time and not studying is not good. ____",
						"answers": ["Playing games is good but playing all the time and not studying is not good.", "Playing games is good, but playing all the time and not studying is not good."]
					},
					{
						"kind": "fill",
						"q": "People give money to those who need it. They also give voluntary time. ____",
						"answers": ["People give money to those who need it and they also give voluntary time.", "People give money and voluntary time to those who need it."]
					},
					{
						"kind": "fill",
						"q": "We should protect ourselves from mosquitoes. Mosquito bites can cause malaria. ____",
						"answers": ["We should protect ourselves from mosquitoes because mosquito bites can cause malaria.", "We should protect ourselves from mosquitoes, because mosquito bites can cause malaria."]
					},
					{
						"kind": "fill",
						"q": "Our school gets over at twelve. I reach home at two o'clock. ____",
						"answers": [
							"Our school gets over at twelve but I reach home at two o'clock.",
							"Our school gets over at twelve, but I reach home at two o'clock.",
							"Our school gets over at twelve and I reach home at two o'clock."
						]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "Column B is jumbled. Match each sentence in Column A with the sentence in Column B, then join the pair with and, but, or because. Example: I decided to have an early dinner because I wanted to sleep early. (1 matches e.)",
				"items": [
					{
						"kind": "match",
						"q": "Match Column A with Column B.",
						"pairs": [
							{
								"left": "1. I decided to have an early dinner",
								"right": "e. I wanted to sleep early."
							},
							{
								"left": "2. They wanted to return the bag to the shopkeeper",
								"right": "h. they forgot the bag at home."
							},
							{
								"left": "3. They left home early to catch the train",
								"right": "j. they missed their train due to a traffic jam."
							},
							{
								"left": "4. She bought a new dress for Eid",
								"right": "b. she also bought a new pair of sandals."
							},
							{
								"left": "5. Our neighbours sold their old house",
								"right": "i. they wanted to buy a new one."
							},
							{
								"left": "6. Many people go to the park on holidays",
								"right": "c. many people go to the seaside to have fun."
							},
							{
								"left": "7. His parents took his baby sister to the doctor",
								"right": "a. she had high fever."
							},
							{
								"left": "8. The player tried his best to catch the ball",
								"right": "d. the ball went to the boundary for four runs."
							},
							{
								"left": "9. My uncle is a lawyer",
								"right": "f. his son is also studying to become a lawyer."
							},
							{
								"left": "10. The food in this restaurant is good",
								"right": "g. the food in the restaurant across the street is better."
							}
						]
					},
					{
						"kind": "fill",
						"q": "1. Join: I decided to have an early dinner + I wanted to sleep early. ____",
						"answers": ["I decided to have an early dinner because I wanted to sleep early."]
					},
					{
						"kind": "fill",
						"q": "2. Join: They wanted to return the bag to the shopkeeper + they forgot the bag at home. ____",
						"answers": ["They wanted to return the bag to the shopkeeper but they forgot the bag at home.", "They wanted to return the bag to the shopkeeper, but they forgot the bag at home."]
					},
					{
						"kind": "fill",
						"q": "3. Join: They left home early to catch the train + they missed their train due to a traffic jam. ____",
						"answers": ["They left home early to catch the train but they missed their train due to a traffic jam.", "They left home early to catch the train, but they missed their train due to a traffic jam."]
					},
					{
						"kind": "fill",
						"q": "4. Join: She bought a new dress for Eid + she also bought a new pair of sandals. ____",
						"answers": ["She bought a new dress for Eid and she also bought a new pair of sandals.", "She bought a new dress for Eid and a new pair of sandals."]
					},
					{
						"kind": "fill",
						"q": "5. Join: Our neighbours sold their old house + they wanted to buy a new one. ____",
						"answers": ["Our neighbours sold their old house because they wanted to buy a new one."]
					},
					{
						"kind": "fill",
						"q": "6. Join: Many people go to the park on holidays + many people go to the seaside to have fun. ____",
						"answers": ["Many people go to the park on holidays and many people go to the seaside to have fun.", "Many people go to the park on holidays, and many people go to the seaside to have fun."]
					},
					{
						"kind": "fill",
						"q": "7. Join: His parents took his baby sister to the doctor + she had high fever. ____",
						"answers": ["His parents took his baby sister to the doctor because she had high fever.", "His parents took his baby sister to the doctor because she had a high fever."]
					},
					{
						"kind": "fill",
						"q": "8. Join: The player tried his best to catch the ball + the ball went to the boundary for four runs. ____",
						"answers": ["The player tried his best to catch the ball but the ball went to the boundary for four runs.", "The player tried his best to catch the ball, but it went to the boundary for four runs."]
					},
					{
						"kind": "fill",
						"q": "9. Join: My uncle is a lawyer + his son is also studying to become a lawyer. ____",
						"answers": ["My uncle is a lawyer and his son is also studying to become a lawyer."]
					},
					{
						"kind": "fill",
						"q": "10. Join: The food in this restaurant is good + the food in the restaurant across the street is better. ____",
						"answers": ["The food in this restaurant is good but the food in the restaurant across the street is better.", "The food in this restaurant is good, but the food across the street is better."]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "Work with a partner and complete the sentences with your own words. Use and, but, or because as the sentence requires.",
				"items": [
					{
						"kind": "open",
						"q": "My friend wants to travel to ____ and ____.",
						"model": "My friend wants to travel to Murree and Gilgit."
					},
					{
						"kind": "open",
						"q": "He decided to wash the dishes because ____.",
						"model": "He decided to wash the dishes because his mother was tired after work."
					},
					{
						"kind": "open",
						"q": "Our exams were scheduled for Monday but ____.",
						"model": "Our exams were scheduled for Monday but they were postponed because the school was closed."
					},
					{
						"kind": "open",
						"q": "Their father gave them some money because ____.",
						"model": "Their father gave them some money because they needed to buy their textbooks."
					},
					{
						"kind": "open",
						"q": "The farmers grew some ____ and ____.",
						"model": "The farmers grew some wheat and vegetables."
					},
					{
						"kind": "open",
						"q": "My mother told me that the purse was in the cupboard but ____.",
						"model": "My mother told me that the purse was in the cupboard but I could not find it there."
					},
					{
						"kind": "open",
						"q": "The soup is getting cold but ____.",
						"model": "The soup is getting cold but the children are still playing outside."
					},
					{
						"kind": "open",
						"q": "The little girl is crying because ____.",
						"model": "The little girl is crying because she has lost her doll."
					},
					{
						"kind": "open",
						"q": "His father is going to ____ and ____.",
						"model": "His father is going to the market and the mosque."
					},
					{
						"kind": "open",
						"q": "The bus is heavily loaded because ____.",
						"model": "The bus is heavily loaded because too many passengers are travelling on it."
					}
				]
			}
		]
	},
	{
		"id": "5.4",
		"code": "5.4",
		"title": "Writing",
		"subtitle": "A Paragraph",
		"kind": "writing",
		"blocks": [
			{
				"type": "h",
				"text": "A Cause and Effect Paragraph"
			},
			{
				"type": "p",
				"text": "Everything that we do or don't do has an effect on something else. Work with a partner and discuss what will happen if we carry out, or do not carry out, the actions below."
			},
			{
				"type": "callout",
				"title": "Reminder",
				"text": "A cause and effect paragraph explains what happens because of an action. You can use If sentences: If we don't wash our hands before eating, we will fall sick. Give the cause first, then the effect, and end with one sentence that states why the action matters."
			},
			{
				"type": "table",
				"caption": "Action and effect. The first effect is given in the book.",
				"headers": [
					"S. No.",
					"Action",
					"Effect"
				],
				"rows": [
					[
						"1",
						"If we don't wash our hands before eating",
						"we will fall sick."
					],
					[
						"2",
						"If students do not follow the school rules",
						""
					],
					[
						"3",
						"If we keep our village/city clean",
						""
					],
					[
						"4",
						"If students do not study properly",
						""
					],
					[
						"5",
						"If people break the traffic rules",
						""
					],
					[
						"6",
						"If children do not obey their parents",
						""
					],
					[
						"7",
						"If we do protect ourselves from mosquitoes",
						""
					],
					[
						"8",
						"If we do drink clean water",
						""
					],
					[
						"9",
						"If people work honestly",
						""
					]
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Write a likely effect for each action. The first one is the example from the book.",
				"items": [
					{
						"kind": "fill",
						"q": "If we don't wash our hands before eating, ____",
						"answers": [
							"we will fall sick.",
							"we will fall sick",
							"we may fall ill."
						]
					},
					{
						"kind": "fill",
						"q": "If students do not follow the school rules, ____",
						"answers": [
							"the school will not run smoothly and they may be punished.",
							"they will be punished and learning will suffer.",
							"they may be punished and disturb the class."
						]
					},
					{
						"kind": "fill",
						"q": "If we keep our village/city clean, ____",
						"answers": [
							"we will stay healthy and the place will look pleasant.",
							"diseases will decrease and people will live more safely.",
							"we will not fall sick from dirt and the city will look beautiful."
						]
					},
					{
						"kind": "fill",
						"q": "If students do not study properly, ____",
						"answers": [
							"they will get poor marks and may fail.",
							"they will not learn and their results will be weak.",
							"they will fail their exams."
						]
					},
					{
						"kind": "fill",
						"q": "If people break the traffic rules, ____",
						"answers": [
							"accidents will happen and people may be injured.",
							"there will be more accidents.",
							"people will get hurt in accidents."
						]
					},
					{
						"kind": "fill",
						"q": "If children do not obey their parents, ____",
						"answers": [
							"they may get into trouble and hurt their parents.",
							"they will make mistakes and their parents will be unhappy.",
							"they can fall into bad habits."
						]
					},
					{
						"kind": "fill",
						"q": "If we do protect ourselves from mosquitoes, ____",
						"answers": [
							"we will not get malaria and other mosquito-borne diseases.",
							"we will stay safe from malaria.",
							"we will not fall sick from mosquito bites."
						]
					},
					{
						"kind": "fill",
						"q": "If we do drink clean water, ____",
						"answers": [
							"we will stay healthy and avoid many stomach diseases.",
							"we will not fall sick from dirty water.",
							"we will remain healthy."
						]
					},
					{
						"kind": "fill",
						"q": "If people work honestly, ____",
						"answers": [
							"society will trust them and the country will progress.",
							"people will trust one another and work will improve.",
							"the country will become fairer and stronger."
						]
					}
				]
			},
			{
				"type": "h",
				"text": "Exercise 2"
			},
			{
				"type": "p",
				"text": "Work in groups of three and develop a mind map on each topic. For every point, write the action and its effect. Then write a paragraph on one of the topics. You may each choose a different topic, or pick one by drawing lots."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Population growth and its impact on different things",
					"Misuse of natural resources and its impact on future generations",
					"Pollution and its impact on the health of people"
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Note causes and effects, then write one cause-and-effect paragraph on the topic you picked.",
				"items": [
					{
						"kind": "open",
						"q": "Mind map: population growth and its impact.",
						"model": "Cause: more people are born than a town can support. Effects: schools become crowded, there are fewer jobs, houses and clean water run short, and hospitals cannot treat everyone. If families and the government plan for schools, jobs and housing, the pressure will be less."
					},
					{
						"kind": "open",
						"q": "Mind map: misuse of natural resources and future generations.",
						"model": "Cause: people cut forests, waste water and burn too much fuel. Effects: soil becomes poor, rivers dry up, animals lose their homes, and children of the future will have less clean air, water and food. If we reuse, plant trees and save water, later generations can still live well."
					},
					{
						"kind": "open",
						"q": "Mind map: pollution and people's health.",
						"model": "Cause: smoke, dirty water, plastic and loud noise. Effects: people get asthma, stomach disease, stress and dirty neighbourhoods. If factories control smoke and we do not throw waste into rivers, fewer people will fall ill."
					},
					{
						"kind": "open",
						"q": "Write a cause and effect paragraph on one of the three topics.",
						"model": "Pollution is already harming people's health in our cities. Factories and vehicles send smoke into the air, so children cough and many people develop asthma. Dirty water from drains flows into rivers and drinking supplies, and families fall sick with stomach diseases. Piles of plastic block drains, and mosquitoes breed there, which spreads malaria. Noise from traffic also stops people from resting. If we plant trees, use less plastic, and keep factories from releasing smoke into the air, the air and water will become cleaner. Then fewer people will fall ill, and the city will be a safer place to live."
					}
				]
			}
		]
	},
	{
		"id": "5.5",
		"code": "5.5",
		"title": "Study Skills",
		"subtitle": "Weekly Planner",
		"kind": "study",
		"blocks": [
			{
				"type": "h",
				"text": "Making a Weekly Schedule"
			},
			{
				"type": "p",
				"text": "Plan your week to be an effective student. Make a weekly planner. Ali fills his weekly planner in order to be more organized and disciplined. Today he is sharing his planner with you in order to help you maintain your weekly planner. Empty morning hours mean he is still at school."
			},
			{
				"type": "table",
				"caption": "Ali's weekly planner",
				"headers": [
					"Time",
					"Monday",
					"Tuesday",
					"Wednesday",
					"Thursday",
					"Friday",
					"Saturday"
				],
				"rows": [
					[
						"5:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"6:00 a.m.",
						"Wake up",
						"Wake up",
						"Wake up",
						"Wake up",
						"Wake up",
						"Wake up"
					],
					[
						"7:00 a.m.",
						"Breakfast",
						"Breakfast",
						"Breakfast",
						"Breakfast",
						"Breakfast",
						"Breakfast"
					],
					[
						"8:00 a.m.",
						"School",
						"School",
						"School",
						"School",
						"School",
						"School"
					],
					[
						"9:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"10:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"11:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"12:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"1:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"2:00 p.m.",
						"Go home",
						"School Club",
						"Go home",
						"Go home",
						"Go home",
						"Go home"
					],
					[
						"3:00 p.m.",
						"Practice",
						"Study",
						"Practice",
						"Study",
						"Study",
						"Study"
					],
					[
						"4:00 p.m.",
						"Sports/Music",
						"Study",
						"Practice",
						"Study",
						"Study",
						"Study"
					],
					[
						"5:00 p.m.",
						"Study",
						"Chores",
						"Study",
						"Chores",
						"Study",
						"Study"
					],
					[
						"6:00 p.m.",
						"Dinner",
						"Dinner",
						"Dinner",
						"Dinner",
						"Dinner",
						"Dinner"
					],
					[
						"7:00 p.m.",
						"Study",
						"Free time",
						"Study",
						"Study",
						"Free time",
						"Free time"
					],
					[
						"8:00 p.m.",
						"Free time",
						"Free time",
						"Free time",
						"Free time",
						"Free time",
						"Free time"
					]
				]
			},
			{
				"type": "h",
				"text": "Your weekly planner"
			},
			{
				"type": "p",
				"text": "Make a weekly schedule for yourself."
			},
			{
				"type": "list",
				"ordered": false,
				"items": [
					"Determine when you are in class, playing, doing chores, watching television, and so on.",
					"Plan the best time each day for study and homework and write it on the planner.",
					"Allow at least 2–3 hours per day for study and homework.",
					"Look at all the free time you still have.",
					"Do a lot of studying during the week and free up your weekends to have fun with your friends and family!"
				]
			},
			{
				"type": "table",
				"caption": "My weekly planner — fill every slot that you use. The book leaves the rows blank for you.",
				"headers": [
					"Time",
					"Monday",
					"Tuesday",
					"Wednesday",
					"Thursday",
					"Friday",
					"Saturday"
				],
				"rows": [
					[
						"5:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"6:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"7:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"8:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"9:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"10:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"11:00 a.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"12:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"1:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"2:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"3:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"4:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"5:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"6:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"7:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					],
					[
						"8:00 p.m.",
						"",
						"",
						"",
						"",
						"",
						""
					]
				]
			},
			{
				"type": "exercise",
				"title": "My planner",
				"instruction": "Complete your own weekly planner. Keep at least two or three hours a day for study, and leave weekend time for family and friends.",
				"items": [{
					"kind": "open",
					"q": "Write your own weekly plan for Monday to Saturday. Say when you wake up, go to school, study, do chores, and take free time.",
					"model": "Monday to Saturday I wake up at 6:00 a.m. and have breakfast at 7:00. School is from 8:00 a.m. to 1:30 p.m. I reach home, rest for a short time, and study from 3:00 to 5:00 p.m. After chores or a game, I study again from 7:00 to 8:00 p.m., which gives me about three hours of study. Dinner is at 8:00 and then I have free time. On Friday evening and Saturday after homework I keep longer free time for my family. I do not leave all my study for the weekend."
				}]
			}
		]
	},
	{
		"id": "5.6",
		"code": "5.6",
		"title": "Fun",
		"subtitle": "Creating a Personal Flag",
		"kind": "fun",
		"blocks": [
			{
				"type": "h",
				"text": "Creating a Personal Flag"
			},
			{
				"type": "p",
				"text": "Here is an interesting activity for you: creating a flag. All of you must follow these steps."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Take a sheet of paper and some colour pencils, paint or pictures.",
					"On the sheet of paper, draw a personal flag that describes you.",
					"The flag must have 4–6 sections, and in each section there should be a drawing or symbol that shows something about you.",
					"For example, one section can contain a picture of your favourite food. Another section could show your hobby, favourite animal, favourite game, and so on.",
					"You can draw, colour, paint or stick small pictures on the flag.",
					"Choose the background colour that you want.",
					"You have 20 minutes to draw your personal flag. When you finish, show your flag to your classmates and explain what you have drawn and why."
				]
			},
			{
				"type": "note",
				"text": "Bring paper, colours, small pictures, a stick and glue. Be ready to show every section and say why you chose it. You may wave your flag while your friends talk about theirs."
			},
			{
				"type": "exercise",
				"title": "My flag",
				"instruction": "Plan the sections of your personal flag, then explain them to the class.",
				"items": [{
					"kind": "open",
					"q": "List 4 to 6 sections of your personal flag and explain what each symbol shows about you.",
					"model": "My flag has a green background because green is the colour of our flag and of growing things. Section 1 shows a cricket bat, because cricket is my favourite game. Section 2 shows a book, because I like reading stories. Section 3 shows a plate of biryani, my favourite food. Section 4 shows a cat, the animal I love. Section 5 shows two hands sharing bread, because I want to help people as Edhi did. Section 6 shows a small ambulance, to remind me that one kind act can grow into a big service."
				}]
			}
		]
	}
];
var vocab$2 = [
	{
		"word": "humanitarian work",
		"pos": "noun",
		"meaning": "Work done to make the lives of suffering people better.",
		"urdu": "انسان دوستی کا کام",
		"synonyms": [
			"charity",
			"relief work",
			"social service"
		],
		"antonyms": [
			"cruelty",
			"harm",
			"selfishness"
		],
		"sentences": ["Edhi started his humanitarian work in 1951 with a very small dispensary in Mithadar."]
	},
	{
		"word": "humble",
		"pos": "adjective",
		"meaning": "Simple and lowly, not grand or proud.",
		"urdu": "سادہ، عاجز",
		"synonyms": [
			"modest",
			"simple",
			"lowly"
		],
		"antonyms": [
			"proud",
			"grand",
			"arrogant"
		],
		"sentences": ["From this humble beginning he created Pakistan's largest charity."]
	},
	{
		"word": "single-handedly",
		"pos": "adverb",
		"meaning": "Done completely by one person, with no one else to share the work.",
		"urdu": "تن تنہا",
		"synonyms": [
			"alone",
			"unaided",
			"by oneself"
		],
		"antonyms": [
			"jointly",
			"together",
			"with help"
		],
		"sentences": ["He single-handedly went on to create Pakistan's largest charitable organization."]
	},
	{
		"word": "charitable",
		"pos": "adjective",
		"meaning": "Ready to help people who are poor or in need.",
		"urdu": "خیراتی، سخی",
		"synonyms": [
			"generous",
			"kind",
			"benevolent"
		],
		"antonyms": [
			"selfish",
			"mean",
			"stingy"
		],
		"sentences": ["His mother taught him to be kind and charitable towards poorer families."]
	},
	{
		"word": "voluntary",
		"pos": "adjective",
		"meaning": "Done by people who choose to work and are not paid.",
		"urdu": "رضاکارانہ",
		"synonyms": [
			"unpaid",
			"willing",
			"optional"
		],
		"antonyms": [
			"paid",
			"compulsory",
			"forced"
		],
		"sentences": ["The Edhi Foundation is run by both paid and voluntary workers."]
	},
	{
		"word": "network",
		"pos": "noun",
		"meaning": "A group of centres and organizations working together as one system.",
		"urdu": "جڑا ہوا نظام",
		"synonyms": [
			"system",
			"web",
			"organization"
		],
		"antonyms": ["isolation", "separation"],
		"sentences": ["Thousands of workers manage the huge network of Edhi centres."]
	},
	{
		"word": "operate",
		"pos": "verb",
		"meaning": "To run or work in a particular way.",
		"urdu": "چلانا",
		"synonyms": [
			"run",
			"manage",
			"function"
		],
		"antonyms": [
			"stop",
			"close",
			"shut down"
		],
		"sentences": ["In Pakistan the foundation operates about 1500 ambulances day and night."]
	},
	{
		"word": "rehabilitation centres",
		"pos": "noun",
		"meaning": "Places where people learn to live a useful life again after illness or addiction.",
		"urdu": "بحالی مراکز",
		"synonyms": [
			"recovery centres",
			"treatment homes",
			"rehab centres"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["The Edhi homes operate rehabilitation centres for drug addicts and the mentally ill."]
	},
	{
		"word": "drug-addicts",
		"pos": "noun",
		"meaning": "People who regularly use harmful drugs and cannot easily stop.",
		"urdu": "نشے کے عادی",
		"synonyms": ["addicts", "substance abusers"],
		"antonyms": ["non-users", "sober people"],
		"sentences": ["Rehabilitation centres help drug-addicts learn how to live a useful life again."]
	},
	{
		"word": "fondly",
		"pos": "adverb",
		"meaning": "In a loving and warm way.",
		"urdu": "پیار سے",
		"synonyms": [
			"lovingly",
			"affectionately",
			"warmly"
		],
		"antonyms": [
			"coldly",
			"harshly",
			"bitterly"
		],
		"sentences": ["Edhi used to fondly recall his simple and patient grandfather."]
	},
	{
		"word": "recalls",
		"pos": "verb",
		"meaning": "Thinks back about something that happened earlier.",
		"urdu": "یاد کرتا ہے",
		"synonyms": [
			"remembers",
			"recollects",
			"thinks back"
		],
		"antonyms": ["forgets", "ignores"],
		"sentences": ["He often recalls how his mother planted the seed of charity in him."]
	},
	{
		"word": "content",
		"pos": "adjective",
		"meaning": "Satisfied with what one has, and not wanting more.",
		"urdu": "قانع، مطمئن",
		"synonyms": [
			"satisfied",
			"pleased",
			"fulfilled"
		],
		"antonyms": [
			"discontented",
			"greedy",
			"dissatisfied"
		],
		"sentences": ["Haji Rehmatullah was a simple, content and patient man who disliked extra food at home."]
	},
	{
		"word": "surpluses",
		"pos": "noun",
		"meaning": "Extra things, more than what is needed.",
		"urdu": "فاضل چیزیں، اضافی سامان",
		"synonyms": [
			"extras",
			"excess",
			"leftovers"
		],
		"antonyms": [
			"shortages",
			"scarcity",
			"lack"
		],
		"sentences": ["His grandfather did not believe in surpluses and disapproved of keeping extra food."]
	},
	{
		"word": "conflicts",
		"pos": "noun",
		"meaning": "Serious disagreements between people.",
		"urdu": "تنازعات",
		"synonyms": [
			"disagreements",
			"clashes",
			"quarrels"
		],
		"antonyms": [
			"peace",
			"agreement",
			"harmony"
		],
		"sentences": ["Haji Rehmatullah had a reputation for resolving conflicts in the community."]
	},
	{
		"word": "moral standards",
		"pos": "noun",
		"meaning": "A person's rules about what is right and wrong behaviour.",
		"urdu": "اخلاقی معیار",
		"synonyms": [
			"principles",
			"ethics",
			"values"
		],
		"antonyms": [
			"immorality",
			"dishonesty",
			"vice"
		],
		"sentences": ["Edhi's father had very high moral standards and was never dishonest in business."]
	},
	{
		"word": "optimistic",
		"pos": "adjective",
		"meaning": "Always expecting good things to happen.",
		"urdu": "پرامید",
		"synonyms": [
			"hopeful",
			"positive",
			"confident"
		],
		"antonyms": [
			"pessimistic",
			"negative",
			"hopeless"
		],
		"sentences": ["Even in hard times his father was a truly optimistic person."]
	},
	{
		"word": "disputes",
		"pos": "noun",
		"meaning": "Fights or quarrels that need to be settled.",
		"urdu": "جھگڑے",
		"synonyms": [
			"quarrels",
			"arguments",
			"fights"
		],
		"antonyms": [
			"settlements",
			"agreements",
			"peace"
		],
		"sentences": ["The grandfather was known for settling disputes among people."]
	},
	{
		"word": "curb",
		"pos": "verb",
		"meaning": "To control or hold something back, such as pride.",
		"urdu": "قابو کرنا، روکنا",
		"synonyms": [
			"control",
			"restrain",
			"check"
		],
		"antonyms": [
			"encourage",
			"increase",
			"release"
		],
		"sentences": ["His father said shaving the head was the best way to curb pride."]
	},
	{
		"word": "arrogance",
		"pos": "noun",
		"meaning": "Proud behaviour that makes a person look down on others.",
		"urdu": "تکبر، گھمنڈ",
		"synonyms": [
			"pride",
			"conceit",
			"haughtiness"
		],
		"antonyms": [
			"humility",
			"modesty",
			"meekness"
		],
		"sentences": ["A shaved head, his father said, helped prevent arrogance."]
	},
	{
		"word": "distraction",
		"pos": "noun",
		"meaning": "Something that takes your attention away from what matters.",
		"urdu": "توجہ ہٹانے والی چیز",
		"synonyms": [
			"diversion",
			"interruption",
			"disturbance"
		],
		"antonyms": [
			"focus",
			"concentration",
			"attention"
		],
		"sentences": ["Edhi's father believed that appearance is a distraction from real work."]
	},
	{
		"word": "humility",
		"pos": "noun",
		"meaning": "The habit of considering oneself small and not showing off.",
		"urdu": "عاجزی، انکساری",
		"synonyms": [
			"modesty",
			"meekness",
			"humbleness"
		],
		"antonyms": [
			"arrogance",
			"pride",
			"vanity"
		],
		"sentences": ["When you stop thinking about how you look, you develop humility and truth."]
	},
	{
		"word": "handicapped",
		"pos": "adjective",
		"meaning": "Not able to use a particular part of the body properly.",
		"urdu": "معذور",
		"synonyms": [
			"disabled",
			"impaired",
			"physically challenged"
		],
		"antonyms": [
			"able-bodied",
			"fit",
			"unimpaired"
		],
		"sentences": ["Young Edhi was especially caring towards old or handicapped people."]
	},
	{
		"word": "mentally challenged",
		"pos": "adjective",
		"meaning": "Not able to use the mind in the ordinary way.",
		"urdu": "ذہنی طور پر معذور",
		"synonyms": ["intellectually disabled", "learning-disabled"],
		"antonyms": ["mentally able", "quick-witted"],
		"sentences": ["If mean children made fun of the mentally challenged, Edhi would stop them."]
	},
	{
		"word": "mean",
		"pos": "adjective",
		"meaning": "Selfish and unkind, here used for children who tease the weak.",
		"urdu": "خود غرض، کنجوس",
		"synonyms": [
			"selfish",
			"unkind",
			"cruel"
		],
		"antonyms": [
			"kind",
			"generous",
			"caring"
		],
		"sentences": ["He would not let mean kids make fun of people who could not defend themselves."]
	},
	{
		"word": "appreciated",
		"pos": "verb",
		"meaning": "Recognised that something was good and showed approval.",
		"urdu": "سراہا",
		"synonyms": [
			"praised",
			"valued",
			"admired"
		],
		"antonyms": [
			"criticised",
			"ignored",
			"scolded"
		],
		"sentences": ["His mother always appreciated his act of giving a voice to the weak."]
	},
	{
		"word": "fortunate",
		"pos": "adjective",
		"meaning": "Lucky, having more of what is needed than others do.",
		"urdu": "خوش نصیب",
		"synonyms": [
			"lucky",
			"blessed",
			"privileged"
		],
		"antonyms": [
			"unfortunate",
			"unlucky",
			"wretched"
		],
		"sentences": ["She asked Edhi to take food to families who were less fortunate than they were."]
	},
	{
		"word": "confessed",
		"pos": "verb",
		"meaning": "Admitted that one had done something wrong.",
		"urdu": "اعتراف کیا",
		"synonyms": [
			"admitted",
			"owned up",
			"acknowledged"
		],
		"antonyms": [
			"denied",
			"hid",
			"concealed"
		],
		"sentences": ["He confessed that he had spent both paisas on himself."]
	},
	{
		"word": "disadvantaged",
		"pos": "adjective",
		"meaning": "Not having the things needed for a proper life; the book equates this with mazloom.",
		"urdu": "محروم، مظلوم",
		"synonyms": [
			"deprived",
			"needy",
			"underprivileged"
		],
		"antonyms": [
			"privileged",
			"advantaged",
			"wealthy"
		],
		"sentences": ["His mother called the poor mazlooms, people who were disadvantaged."]
	},
	{
		"word": "priority",
		"pos": "noun",
		"meaning": "Something that is more important than other things and must come first.",
		"urdu": "ترجیح",
		"synonyms": [
			"first concern",
			"preference",
			"main aim"
		],
		"antonyms": ["afterthought", "low priority"],
		"sentences": ["She said that Huquq-ul-Ibaad, the rights of other people, was the first priority in Islam."]
	},
	{
		"word": "ensured",
		"pos": "verb",
		"meaning": "Made sure that something really happened.",
		"urdu": "یقینی بنایا",
		"synonyms": [
			"made sure",
			"guaranteed",
			"saw to it"
		],
		"antonyms": [
			"neglected",
			"ignored",
			"risked"
		],
		"sentences": ["His mother ensured that he did not waste his time sitting at home."]
	},
	{
		"word": "idly",
		"pos": "adverb",
		"meaning": "Doing nothing useful; sitting without work.",
		"urdu": "بے کار، سستی سے",
		"synonyms": [
			"lazily",
			"inactively",
			"without work"
		],
		"antonyms": [
			"busily",
			"actively",
			"productively"
		],
		"sentences": ["She believed that no one should sit at home idly."]
	},
	{
		"word": "nurtured",
		"pos": "verb",
		"meaning": "Developed and looked after something so that it could grow.",
		"urdu": "پروان چڑھایا",
		"synonyms": [
			"developed",
			"fostered",
			"cultivated"
		],
		"antonyms": [
			"neglected",
			"starved",
			"abandoned"
		],
		"sentences": ["She not only planted charity in him but nurtured it all her life."]
	},
	{
		"word": "associate",
		"pos": "noun",
		"meaning": "A person you work with or spend time with.",
		"urdu": "ساتھی، رفیق کار",
		"synonyms": [
			"colleague",
			"companion",
			"partner"
		],
		"antonyms": [
			"stranger",
			"opponent",
			"enemy"
		],
		"sentences": ["An old associate said that Edhi changed his life for others, not for himself."]
	},
	{
		"word": "transformation",
		"pos": "noun",
		"meaning": "A complete change in the way a person lives.",
		"urdu": "مکمل تبدیلی",
		"synonyms": [
			"change",
			"conversion",
			"shift"
		],
		"antonyms": ["sameness", "stagnation"],
		"sentences": ["Edhi's self transformation was for a social mission, not for his own comfort."]
	},
	{
		"word": "insurmountable",
		"pos": "adjective",
		"meaning": "So difficult that it seems impossible to overcome.",
		"urdu": "ناقابلِ عبور",
		"synonyms": [
			"unbeatable",
			"overwhelming",
			"hopeless"
		],
		"antonyms": [
			"manageable",
			"easy",
			"surmountable"
		],
		"sentences": ["No matter how insurmountable the difficulties, he never lost his positive attitude."]
	},
	{
		"word": "challenging",
		"pos": "adjective",
		"meaning": "Difficult and demanding effort or courage.",
		"urdu": "دشوار، چیلنج بھرا",
		"synonyms": [
			"difficult",
			"demanding",
			"tough"
		],
		"antonyms": [
			"easy",
			"simple",
			"effortless"
		],
		"sentences": ["However challenging the times, Edhi kept a confident outlook."]
	},
	{
		"word": "outlook",
		"pos": "noun",
		"meaning": "The way a person looks at life or at a situation.",
		"urdu": "نقطۂ نظر، رویہ",
		"synonyms": [
			"attitude",
			"viewpoint",
			"perspective"
		],
		"antonyms": ["indifference", "blindness"],
		"sentences": ["He never lost his positive attitude and confident outlook."]
	},
	{
		"word": "integrity",
		"pos": "noun",
		"meaning": "Honesty and the strength to live by what is right.",
		"urdu": "دیانت، ایمانداری",
		"synonyms": [
			"honesty",
			"uprightness",
			"probity"
		],
		"antonyms": [
			"dishonesty",
			"corruption",
			"deceit"
		],
		"sentences": ["He promised himself that nobody would have reason to challenge his integrity."]
	},
	{
		"word": "vision",
		"pos": "noun",
		"meaning": "The ability to think about the future in a wise, far-seeing way.",
		"urdu": "بصیرت، دور اندیشی",
		"synonyms": [
			"foresight",
			"insight",
			"dream"
		],
		"antonyms": ["short-sightedness", "blindness"],
		"sentences": ["His humanitarian vision, taught mainly by his mother, made him the man he became."]
	},
	{
		"word": "regardless",
		"pos": "adverb",
		"meaning": "Without giving importance to something, or in spite of it.",
		"urdu": "قطع نظر، بلا لحاظ",
		"synonyms": [
			"irrespective",
			"despite",
			"anyway"
		],
		"antonyms": [
			"depending on",
			"because of",
			"considering"
		],
		"sentences": ["His mission was to serve humanity regardless of religion, race and background."]
	},
	{
		"word": "state funeral",
		"pos": "noun",
		"meaning": "A burial with the honour normally given to the head of a state.",
		"urdu": "سرکاری جنازہ",
		"synonyms": ["national funeral", "ceremonial burial"],
		"antonyms": ["private burial", "ordinary funeral"],
		"sentences": ["He was the first common citizen of Pakistan in nearly seventy years to receive a state funeral."]
	},
	{
		"word": "dispensary",
		"pos": "noun",
		"meaning": "A small place where simple medicines and treatment are given.",
		"urdu": "ڈسپنسری، دوا خانہ",
		"synonyms": [
			"clinic",
			"pharmacy",
			"aid post"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["In 1951 Edhi opened a very small dispensary in Mithadar, Karachi."]
	},
	{
		"word": "mazlooms",
		"pos": "noun",
		"meaning": "Disadvantaged, oppressed people who cannot defend their own rights.",
		"urdu": "مظلوم",
		"synonyms": [
			"the oppressed",
			"the wronged",
			"the disadvantaged"
		],
		"antonyms": ["oppressors", "the powerful"],
		"sentences": ["His mother said Allah does not help those who do not look after the mazlooms."]
	},
	{
		"word": "inculcated",
		"pos": "verb",
		"meaning": "Planted an idea or habit firmly in someone's mind by teaching.",
		"urdu": "ذہن نشین کرایا",
		"synonyms": [
			"instilled",
			"taught",
			"implanted"
		],
		"antonyms": [
			"removed",
			"erased",
			"discouraged"
		],
		"sentences": ["Simplicity and a humanitarian vision had been inculcated in him by his parents."]
	}
];
var unit5_default = {
	id: "u5",
	number: 5,
	title: title$2,
	learn: learn$2,
	lessons: lessons$2,
	vocab: vocab$2
};
var unit6_exports = /* @__PURE__ */ __exportAll({
	default: () => unit6_default,
	id: () => "u6",
	learn: () => learn$1,
	lessons: () => lessons$1,
	number: () => 6,
	title: () => title$1,
	vocab: () => vocab$1
});
var title$1 = "Sportsmanship";
var learn$1 = [
	{
		"skill": "Reading",
		"points": [
			"Use pre-reading strategies to predict the content of a text from its title and picture by using prior knowledge and asking questions",
			"Skim text to have a general idea of the text",
			"Infer theme/main idea",
			"Apply critical thinking to interact with the text, and use intensive reading strategies",
			"Scan to answer short questions",
			"Deduce the meaning of difficult words from context",
			"Read silently with comprehension and extract the main idea and supporting details",
			"Make simple inferences using the context of the text and prior knowledge"
		]
	},
	{
		"skill": "Speaking",
		"points": ["Use polite forms to negotiate and reach consensus"]
	},
	{
		"skill": "Language Practice",
		"points": [
			"Use degrees of adjectives with “the”",
			"Use comparative adjectives with than",
			"Demonstrate the use of the relative pronouns who, that and which"
		]
	},
	{
		"skill": "Writing",
		"points": ["Write formal letters to people in the extended social and academic environment for various purposes, using the conventions of formal letter writing"]
	},
	{
		"skill": "Study Skills",
		"points": ["Enhance vocabulary with words related to professions", "Form analogies of the pattern “one who … is called a …”"]
	},
	{
		"skill": "Fun",
		"points": ["Play a game by flicking a coin in order to use conditional type 2"]
	}
];
var lessons$1 = [
	{
		"id": "6.1",
		"code": "6.1",
		"title": "Reading Comprehension",
		"subtitle": "Sportsmanship",
		"kind": "reading",
		"blocks": [
			{
				"type": "h",
				"text": "Pre-Reading"
			},
			{
				"type": "p",
				"text": "1. Look at the picture. What is it about?"
			},
			{
				"type": "p",
				"text": "2. What do you think the text is about?"
			},
			{
				"type": "p",
				"text": "3. Discuss with your partner and decide what your answer is."
			},
			{
				"type": "note",
				"text": "The picture shows a cricket match: a Pakistan batsman in green is playing a shot, and an Australian wicketkeeper in yellow is crouched behind the stumps."
			},
			{
				"type": "exercise",
				"title": "Pre-Reading",
				"instruction": "Use the title Sportsmanship and the picture. Discuss with a partner, then write your ideas.",
				"items": [
					{
						"kind": "open",
						"q": "Look at the picture. What is it about?",
						"model": "It is about a cricket match. A Pakistani batsman in a green uniform is playing a shot while an Australian wicketkeeper in yellow waits behind the stumps."
					},
					{
						"kind": "open",
						"q": "What do you think the text is about?",
						"model": "I think the text is about cricket and fair play. The title Sportsmanship suggests it is about generous, polite behaviour in sport, not only about winning."
					},
					{
						"kind": "open",
						"q": "Discuss with your partner and decide what your answer is.",
						"model": "We agree that the lesson will tell the story of a cricketer who must learn that real greatness depends on sportsmanship."
					}
				]
			},
			{
				"type": "h",
				"text": "Reading Text"
			},
			{
				"type": "h",
				"text": "Sportsmanship"
			},
			{
				"type": "p",
				"text": "The stadium broke into applause when Rajoo hit a huge six that earned the team a place in the finals of the inter district tournament."
			},
			{
				"type": "p",
				"text": "Rajoo was a district player from Ranikot. His performance soon led to his selection on the under-nineteen Pakistan cricket team. Before long, he became a superstar of the cricket world. But, unfortunately, all this success went to his head. He became very rude and arrogant. This worried the coach and the manager of the team because his attitude was not only annoying the local players but was also irritating the international players. They often counselled him, but to no avail."
			},
			{
				"type": "p",
				"text": "Soon the team went on a tour of Australia where it won the series. When the team returned home they received a resounding welcome. After their return, all the players went to their home towns."
			},
			{
				"type": "p",
				"text": "In Ranikot, Nabeel, Rajoo's best friend since childhood, was anxiously waiting for his friend's return. He was going to see his friend after a long time and he was very excited about it. He was soon going to meet his friend who was a cricket superstar."
			},
			{
				"type": "p",
				"text": "A luxurious car stopped in front of the house. A well-suited, handsome man stepped out of the car. “It's Rajoo,” Nabeel muttered. He came forward to greet his old buddy, but Rajoo just ignored him and continued walking. Nabeel was shocked! He had not expected such behaviour from his old friend and it made him sad. He just did not know what to do."
			},
			{
				"type": "p",
				"text": "The next day, Rajoo had been invited by the town people at the town house. They wanted to honour their hero and to hear the stories of his victories. Nabeel was among the group of people who had gathered at the town hall. When Rajoo arrived, he just ignored most of the people and arrogantly walked up the stage and sat there. When he was asked to share his stories, he only talked about himself and his performance. The town people listened to his stories in awe, but Nabeel could not understand why his best friend was behaving so arrogantly; such behaviour did not suit a world renowned player."
			},
			{
				"type": "p",
				"text": "A couple of days later, Rajoo was practising in the nearby ground where he used to play in his childhood. Many old childhood memories came to his mind and, suddenly, he remembered his old buddy, Nabeel. Nabeel used to be his best friend and he recalled that on several occasions; Nabeel had counselled him and helped him."
			},
			{
				"type": "p",
				"text": "While he was thinking about his friend, suddenly, somebody patted his shoulder. He turned quickly and couldn't hide his happiness when he saw that it was Nabeel. Rajoo hugged his friend tightly and tears started flowing from his eyes. He apologised to Nabeel for his arrogant behaviour and asked him to forgive him."
			},
			{
				"type": "p",
				"text": "Nabeel was extremely happy. He was grateful to Allah that his friend had not forgotten him. Together, both friends walked towards Nabeel's house, laughing and chatting all the way home. They talked about many childhood memories, the pranks they had played, and the fights they had had, and how each time they had forgiven each other and become friends again. Nabeel showed his friend a scrap book which he had made for him. After spending a couple of hours together, Rajoo left for home but he promised Nabeel that he would look at and read the whole scrap book that he had given him."
			},
			{
				"type": "p",
				"text": "A few days later, Rajoo went back to join his team. His performance, as usual, was excellent, but, his insolent behaviour was also the same. When things became intolerable, the team management decided to counsel him once again. The manager called him to his office, but he refused to go. The decision was thus taken to ban him from the team. This shocked Rajoo. He had never thought that his behaviour would lead to this; that he would not be allowed to play for Pakistan again!"
			},
			{
				"type": "p",
				"text": "He started walking up and down in his room. His eyes fell on the scrap book that his friend had given him; idly, he started turning the pages. The scrap book was full of wonderful stories of players and their sportsmanship:"
			},
			{
				"type": "h",
				"text": "(1)"
			},
			{
				"type": "p",
				"text": "During the Australia Vs. Pakistan match in 1998, the Australian captain Mark Taylor's score was 334 not out at the end of the second day, equalling the best test score of the Australian legend Don Bradman, set in 1930. Media fans, and even the circumstances, urged him to not only break Sir Don Bradman's score, but also Brian Lara's world record of 375. Instead, he chose the Captain's way; that is team's good over personal glory. As a gesture of great sportsmanship, he let go of his ego, and individual success, for Australia's win but the game came to a draw at the end."
			},
			{
				"type": "h",
				"text": "(2)"
			},
			{
				"type": "p",
				"text": "New Zealand player, Daniel Vettori, was given the ICC Spirit of Cricket award in 2012 for his gesture in a hard-fought tie against Zimbabwe. Vettori accidentally collided with non-striker, Malcolm Waller, during his follow-through that stopped Waller from taking a single but by that time the batsman at the crease, Regis Chakabva, had come too far down the track to get back. The Kiwi wicket keeper, Reece Young, whipped the bails but Vettori immediately withdrew the dismissal, saying that it was his collision which had caused the confusion in the middle."
			},
			{
				"type": "h",
				"text": "(3)"
			},
			{
				"type": "p",
				"text": "During the match between Sri Lanka and Australia, when Australia was batting, Andrew Symonds got a huge inside edge on to the pads, i.e. his ball hit the pad after hitting the bat, but a very loud appeal from the Sri Lankans, that he was out was upheld by the umpire. However, when he had walked about two-thirds of the way back to the pavilion, a very surprised Symonds was called back by the Sri Lankan skipper, Marvan Atapattu, who realized that the decision was not right."
			},
			{
				"type": "h",
				"text": "(4)"
			},
			{
				"type": "p",
				"text": "At Lahore, the captain of the visiting cricket team had to face a strong Pakistani bowling attack, which included the likes of Waqar Younis and Aaqib Javed. After a number of play and misses, Waqar finally had him trapped right in front of the wickets and the umpire declared him out. The captain was very upset by the decision and clearly showed his feelings that the decision was wrong. The captain of the Pakistan team, in what was an historic move, quickly called him back and allowed him to bat again; he was dismissed by Waqar again on the very next delivery."
			},
			{
				"type": "h",
				"text": "(5)"
			},
			{
				"type": "p",
				"text": "During the 1987 World Cup in Lahore, Courtney Walsh chose to lose the match over running a batsman out in the most unforgiving manner. When two runs were needed off the final ball for Pakistan to win, Walsh stopped, backed out in his delivery stride but didn't run out the non-striker, even though he had backed up a little too much. Next ball, the striker Abdul Qadir did eventually get the desired runs and Pakistan scored a win by one wicket; all thanks to the grace of Walsh."
			},
			{
				"type": "p",
				"text": "After reading a few pages Rajoo realized that greatness did not lie in achievements only; in fact, it had a great deal to do with sportsmanship. Having realized his mistake, he decided to apologise. The next morning he called a press conference and apologised to everyone in front of the media. The cricket world warmly welcomed him back."
			},
			{
				"type": "h",
				"text": "While reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "What is the main idea of the text?",
				"items": [{
					"kind": "mcq",
					"q": "What is the main idea of the text?",
					"options": [
						"It's never too late to change",
						"Good players are always arrogant",
						"All cricketers are liked by the people",
						"A great Pakistani cricketer is born"
					],
					"answer": 0
				}]
			},
			{
				"type": "h",
				"text": "Vocabulary"
			},
			{
				"type": "words",
				"intro": "These words and phrases are in a jumbled order. Match each one with the meaning that follows the order of the text.",
				"words": [
					"broke into applause",
					"went to his head",
					"rude",
					"arrogant",
					"irritating",
					"counselled",
					"to no avail",
					"resounding",
					"well-suited",
					"awe",
					"renowned",
					"chatting",
					"pranks",
					"scrap-book",
					"intolerable",
					"sportsmanship"
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "The meanings are in the same order as the words in the text. The first one has been done: Broke into applause means clapped very loudly. Renowned, the next word in the story, means famous.",
				"items": [{
					"kind": "match",
					"pairs": [
						{
							"left": "broke into applause",
							"right": "clapped very loudly"
						},
						{
							"left": "went to his head",
							"right": "made him very proud"
						},
						{
							"left": "rude",
							"right": "not show/have respect"
						},
						{
							"left": "arrogant",
							"right": "behave in a proud manner"
						},
						{
							"left": "irritating",
							"right": "something that makes people a little angry"
						},
						{
							"left": "counselled",
							"right": "advised"
						},
						{
							"left": "to no avail",
							"right": "it did not have any effect"
						},
						{
							"left": "resounding",
							"right": "very great"
						},
						{
							"left": "well-suited",
							"right": "well dressed"
						},
						{
							"left": "awe",
							"right": "feeling of respect"
						},
						{
							"left": "renowned",
							"right": "famous; known by many people"
						},
						{
							"left": "chatting",
							"right": "talking in a friendly way"
						},
						{
							"left": "pranks",
							"right": "tricks played on someone as a joke"
						},
						{
							"left": "scrap-book",
							"right": "a book in which one sticks pictures or newspaper articles"
						},
						{
							"left": "intolerable",
							"right": "unacceptable"
						},
						{
							"left": "sportsmanship",
							"right": "fair, generous and polite behaviour"
						}
					]
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Rajoo read five articles from the scrap book. Read those articles and write the number of the article that matches each title.",
				"items": [
					{
						"kind": "fill",
						"q": "One captain gave another captain a second chance. Article ____.",
						"answers": [
							"4",
							"article 4",
							"4."
						],
						"hint": "A captain called another captain back to bat."
					},
					{
						"kind": "fill",
						"q": "Chose team interest over self interest. Article ____.",
						"answers": ["1", "article 1"],
						"hint": "He let go of a personal record for the team."
					},
					{
						"kind": "fill",
						"q": "Saved the opposite team's player and lost the match. Article ____.",
						"answers": ["5", "article 5"],
						"hint": "He did not run the non-striker out."
					},
					{
						"kind": "fill",
						"q": "Accepted fault in the other player's failure. Article ____.",
						"answers": ["2", "article 2"],
						"hint": "He said his own collision caused the confusion."
					},
					{
						"kind": "fill",
						"q": "Surprised the player by calling him back. Article ____.",
						"answers": ["3", "article 3"],
						"hint": "A surprised batsman was called back from the pavilion."
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Match the statements from column A and column B. The first one has been done in the book: 1 matches g (Rajoo was a great player who played for the Ranikot district).",
				"items": [{
					"kind": "match",
					"pairs": [
						{
							"left": "Rajoo was a great player",
							"right": "who played for the Ranikot district."
						},
						{
							"left": "His attitude was not liked",
							"right": "by both national and international players."
						},
						{
							"left": "The team received a resounding welcome",
							"right": "when they came back after winning in Australia."
						},
						{
							"left": "Nabeel was very excited",
							"right": "when Rajoo came to Ranikot after he returned from Australia."
						},
						{
							"left": "Nabeel was shocked by his friend's behaviour",
							"right": "because Rajoo refused to recognize him."
						},
						{
							"left": "Rajoo was invited to the town hall",
							"right": "because the people wanted to hear the stories of his victories."
						},
						{
							"left": "Rajoo was happy to see his friend in the playground",
							"right": "because he remembered how he had counselled and helped him."
						},
						{
							"left": "When Rajoo went back to his team",
							"right": "he took the book with him that his friend had given."
						},
						{
							"left": "Due to his rude attitude",
							"right": "the board decided to ban Rajoo from the team."
						},
						{
							"left": "When Rajoo read the scrapbook",
							"right": "he realised that greatness lay in sportsmanship."
						},
						{
							"left": "At a press conference",
							"right": "he apologized publicly for his rude behaviour."
						},
						{
							"left": "The cricket board took him back on the team",
							"right": "because he was a great player."
						}
					]
				}]
			},
			{
				"type": "h",
				"text": "Post Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "The following are incomplete statements about each item in the scrapbook. Read the text and complete each statement. Discuss your answers with your partner.",
				"items": [
					{
						"kind": "fill",
						"q": "Article 1 a. Don Bradman had scored ____ runs in ____.",
						"answers": [
							"334, 1930",
							"334 runs in 1930",
							"334 in 1930",
							"334 not out in 1930"
						],
						"hint": "Taylor equalled this score."
					},
					{
						"kind": "fill",
						"q": "Article 1 b. The world record of ____ runs was held by ____.",
						"answers": [
							"375, Brian Lara",
							"375 runs, Brian Lara",
							"375 by Brian Lara",
							"375 Brian Lara"
						]
					},
					{
						"kind": "fill",
						"q": "Article 1 c. The Australian captain, ____, wanted his ____ to win the match against ____.",
						"answers": [
							"Mark Taylor, team, Pakistan",
							"Mark Taylor, his team, Pakistan",
							"Mark Taylor team Pakistan"
						]
					},
					{
						"kind": "fill",
						"q": "Article 2 a. Daniel Vettori received an award in ____, in New Zealand's match against ____.",
						"answers": [
							"2012, Zimbabwe",
							"2012 against Zimbabwe",
							"2012 Zimbabwe"
						]
					},
					{
						"kind": "fill",
						"q": "Article 2 b. Vettori accidentally collided with ____ because of which ____ got out.",
						"answers": [
							"Malcolm Waller, Regis Chakabva",
							"Malcolm Waller because of which Regis Chakabva",
							"Waller, Chakabva"
						]
					},
					{
						"kind": "fill",
						"q": "Article 2 c. Vettori ____ the umpire's decision.",
						"answers": [
							"withdrew",
							"did not accept",
							"rejected",
							"overturned",
							"cancelled",
							"withdrew the dismissal"
						],
						"hint": "He withdrew the dismissal."
					},
					{
						"kind": "fill",
						"q": "Article 3 a. During the match between ____ and ____ Andrew Symonds was actually not out.",
						"answers": [
							"Sri Lanka, Australia",
							"Sri Lanka and Australia",
							"Australia and Sri Lanka",
							"Australia, Sri Lanka"
						]
					},
					{
						"kind": "fill",
						"q": "Article 3 b. The ____ gave a wrong decision because the ____ shouted loudly.",
						"answers": [
							"umpire, Sri Lankans",
							"umpire, the Sri Lankans",
							"umpire Sri Lankans"
						]
					},
					{
						"kind": "fill",
						"q": "Article 3 c. When he was walking back to the ____, he was called back by ____.",
						"answers": [
							"pavilion, Marvan Atapattu",
							"pavilion, the Sri Lankan skipper",
							"pavilion Marvan Atapattu",
							"pavilion, Atapattu"
						]
					},
					{
						"kind": "fill",
						"q": "Article 4 a. ____, the visiting cricket team had to face a strong ____ attack.",
						"answers": [
							"At Lahore, bowling",
							"At Lahore, Pakistani bowling",
							"Lahore, bowling",
							"In Lahore, bowling"
						]
					},
					{
						"kind": "fill",
						"q": "Article 4 b. Pakistan had great bowlers like ____ and ____.",
						"answers": [
							"Waqar Younis, Aaqib Javed",
							"Waqar Younis and Aaqib Javed",
							"Aaqib Javed and Waqar Younis"
						]
					},
					{
						"kind": "fill",
						"q": "Article 4 c. The ____ was called back after he was given out but ____ got him out on the next ball.",
						"answers": [
							"captain, Waqar",
							"visiting captain, Waqar",
							"captain, Waqar Younis",
							"visiting captain, Waqar Younis"
						]
					},
					{
						"kind": "fill",
						"q": "Article 5 a. During the ____ World Cup in ____ Courtney Walsh showed great sportsmanship.",
						"answers": [
							"1987, Lahore",
							"1987 World Cup in Lahore",
							"1987 Lahore"
						]
					},
					{
						"kind": "fill",
						"q": "Article 5 b. ____ runs were needed by Pakistan and only ____ ball was left.",
						"answers": [
							"Two, one",
							"2, 1",
							"Two, the final",
							"two runs, one"
						]
					},
					{
						"kind": "fill",
						"q": "Article 5 c. ____ scored the needed runs and Pakistan won, thanks to ____.",
						"answers": [
							"Abdul Qadir, Courtney Walsh",
							"Abdul Qadir, Walsh",
							"Abdul Qadir and Walsh"
						]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "Work in pairs and discuss the following questions by reading the text. After you have discussed them, write the answers in your notebook.",
				"items": [
					{
						"kind": "open",
						"q": "Rajoo was a great player but people did not like him. Why?",
						"model": "Success went to his head. He became rude and arrogant, and his attitude annoyed both the local players and the international players."
					},
					{
						"kind": "open",
						"q": "How did the people of Ranikot treat Rajoo when he came back home after the team returned from Australia?",
						"model": "They invited him to the town hall to honour their hero and to hear the stories of his victories. They listened in awe, even though he ignored most of them and talked only about himself."
					},
					{
						"kind": "open",
						"q": "What was in the scrapbook that Nabeel gave to Rajoo?",
						"model": "It was full of wonderful stories of players and their sportsmanship, including five true articles about fair play in cricket."
					},
					{
						"kind": "open",
						"q": "What brought about a good change in Rajoo?",
						"model": "Reading the scrapbook brought the change. He realised that greatness has a great deal to do with sportsmanship, so he apologised at a press conference."
					},
					{
						"kind": "open",
						"q": "What advice would you have given to Rajoo if he were your friend?",
						"model": "I would have told him to stay humble, to respect Nabeel and his teammates, and to remember that a great player is also a good sportsman. It is never too late to change."
					}
				]
			}
		]
	},
	{
		"id": "6.2",
		"code": "6.2",
		"title": "Speaking",
		"subtitle": "Use Polite Forms to Negotiate and Reach Consensus",
		"kind": "speaking",
		"blocks": [
			{
				"type": "h",
				"text": "Use polite forms to negotiate and reach consensus"
			},
			{
				"type": "p",
				"text": "Work in groups of three and practise the following dialogue. You will have to practise the dialogue three times, each time taking the role of another student."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Student A",
						"text": "I think we should invite all our friends and relatives to the wedding."
					},
					{
						"who": "Student B",
						"text": "I agree, but we have so many relatives and friends and we have a limited amount of money."
					},
					{
						"who": "Student C",
						"text": "So what? Everyone invites a lot of people to weddings."
					},
					{
						"who": "Student A",
						"text": "We can invite a lot of people if we serve only two dishes."
					},
					{
						"who": "Student B",
						"text": "No, it's not only the number of dishes. If we invite many people we will need a big tent, for which we will need plenty of space and a lot of money."
					},
					{
						"who": "Student C",
						"text": "A wedding is fun only when we have a lot of people and a variety of food items."
					},
					{
						"who": "Student A",
						"text": "But, we should also be careful not to spend too much money."
					},
					{
						"who": "Student B",
						"text": "Let's make a list to see who we want to invite. Then we can decide how many people to invite and who to invite."
					},
					{
						"who": "Student C",
						"text": "Yes, once we know for sure how many people we are inviting we can then decide what food to serve."
					}
				]
			},
			{
				"type": "p",
				"text": "After you have practised the above dialogue, work in the same groups of three and develop a dialogue on one of the following topics and then roleplay as above."
			},
			{
				"type": "list",
				"ordered": true,
				"items": ["Having a class picnic (discuss and agree on where you will go, who will go, only students and teachers or family members also, how much money will you charge, etc.)", "Organising the annual function at school (discuss and agree what will be done, when will the programme be, how long will it be, who will be invited/ be the chief guest, etc.)"]
			},
			{
				"type": "note",
				"text": "Take turns so that each student plays A, B and C. Use polite forms such as I think, I agree, but, let's, and yes once we know. End only when the group has reached one decision."
			},
			{
				"type": "exercise",
				"title": "Role-play",
				"instruction": "Choose one topic. Write a short dialogue in which the three students disagree at first and then reach consensus.",
				"items": [{
					"kind": "open",
					"q": "Having a class picnic: agree on where you will go, who will go, and how much money you will charge.",
					"model": "Student A: I think we should go to the beach for the class picnic.\nStudent B: I agree it would be fun, but the bus fare is high and we have limited money.\nStudent C: We could go to the park near the school. Then we need less money.\nStudent A: Let's invite only students and teachers, not the whole family.\nStudent B: We can charge two hundred rupees each for the bus and lunch.\nStudent C: Yes. Once we know that only the class and the teachers are going, two hundred rupees is enough."
				}, {
					"kind": "open",
					"q": "Organising the annual function: agree on what will be done, when it will be, how long it will be, and who the chief guest will be.",
					"model": "Student A: I think the annual function should have a play, a song and a prize-giving.\nStudent B: I agree, but if it is too long the guests will get tired.\nStudent C: Let's keep it to one and a half hours, on the last Friday of the month, in the school hall.\nStudent A: We should invite parents, and the head teacher can be the chief guest.\nStudent B: Yes. Once we know the programme and the time, we can write the invitations.\nStudent C: Then we are agreed: a short programme, parents invited, and the head teacher as chief guest."
				}]
			}
		]
	},
	{
		"id": "6.3",
		"code": "6.3",
		"title": "Language Practice",
		"subtitle": "Comparative Adjectives and Relative Pronouns",
		"kind": "language",
		"blocks": [
			{
				"type": "h",
				"text": "Comparative Adjectives with ‘the’"
			},
			{
				"type": "callout",
				"title": "Rule: than, and the + comparative",
				"text": "In Unit 5.3, we discussed comparative adjectives with the use of than. With than we compare two people or things. A short adjective takes -er or -ier: Rajoo became ruder than he used to be. A longer adjective takes more: He was more arrogant than his teammates. Irregular forms include good → better and bad → worse. Another way to use comparatives is to put two of them together. When two comparatives are used together, the is used before both of them. The nicer a person, the more popular she or he is likely to be. The cooler it gets, the better one feels. Short adjectives still take -er or -ier (fast → faster, easy → easier, thin → thinner). Longer adjectives take more (careful → more careful, difficult → more difficult). Less is already a comparative."
			},
			{
				"type": "p",
				"text": "Example: The nicer a person the more popular she or he is likely to be."
			},
			{
				"type": "p",
				"text": "Example: The cooler it gets the better one feels."
			},
			{
				"type": "note",
				"text": "Some words take the -er or -ier ending, while others take more. Use the before each comparative."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Use the comparative form of the adjectives given in the brackets to complete the following sentences. Write the complete sentences in your notebook.",
				"items": [
					{
						"kind": "fill",
						"q": "____ the train, ____ we will reach. (fast, soon)",
						"answers": [
							"The faster, the sooner",
							"The faster the train, the sooner we will reach.",
							"the faster, the sooner"
						]
					},
					{
						"kind": "fill",
						"q": "____ the children, ____ they learn a new language. (young, quick)",
						"answers": [
							"The younger, the quicker",
							"The younger the children, the quicker they learn a new language.",
							"the younger, the quicker"
						]
					},
					{
						"kind": "fill",
						"q": "____ you are, ____ it is to run. (thin, easy)",
						"answers": [
							"The thinner, the easier",
							"The thinner you are, the easier it is to run.",
							"the thinner, the easier"
						]
					},
					{
						"kind": "fill",
						"q": "____ your eating habits, ____ your health. (healthy, good)",
						"answers": [
							"The healthier, the better",
							"The healthier your eating habits, the better your health.",
							"the healthier, the better"
						]
					},
					{
						"kind": "fill",
						"q": "____ a driver, ____ the journey. (careful, safe)",
						"answers": [
							"The more careful, the safer",
							"The more careful a driver, the safer the journey.",
							"the more careful, the safer"
						]
					},
					{
						"kind": "fill",
						"q": "____ one lives, ____ ones' life. (simple, easy)",
						"answers": [
							"The simpler, the easier",
							"The simpler one lives, the easier one's life.",
							"The more simply one lives, the easier one's life.",
							"the simpler, the easier",
							"The more simply, the easier"
						]
					},
					{
						"kind": "fill",
						"q": "____ a country, ____ its people. (clean, healthy)",
						"answers": [
							"The cleaner, the healthier",
							"The cleaner a country, the healthier its people.",
							"the cleaner, the healthier"
						]
					},
					{
						"kind": "fill",
						"q": "____ the days, ____ the nights. (long, short)",
						"answers": [
							"The longer, the shorter",
							"The longer the days, the shorter the nights.",
							"the longer, the shorter"
						]
					},
					{
						"kind": "fill",
						"q": "____ the nut ____ it is to break it. (hard, difficult)",
						"answers": [
							"The harder, the more difficult",
							"The harder the nut, the more difficult it is to break it.",
							"the harder, the more difficult"
						]
					},
					{
						"kind": "fill",
						"q": "____ one gets ____ the time one has for oneself. (busy, less)",
						"answers": [
							"The busier, the less",
							"The busier one gets, the less the time one has for oneself.",
							"The busier one gets, the less time one has for oneself.",
							"the busier, the less"
						]
					}
				]
			},
			{
				"type": "words",
				"intro": "Exercise 2 pairs, in jumbled order. Use each pair once, in the comparative form with the.",
				"words": [
					"shady / cool",
					"dark / comfortable",
					"good / high",
					"plain / easy",
					"old / expensive",
					"hot / nice"
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Use the pairs of adjectives below to complete the sentences. The pairs are jumbled. Select the pair that fits. Write the complete sentences.",
				"items": [
					{
						"kind": "fill",
						"q": "____ the quality of the material ____ the cost.",
						"answers": [
							"The better, the higher",
							"The better the quality of the material, the higher the cost.",
							"the better, the higher"
						],
						"hint": "good / high"
					},
					{
						"kind": "fill",
						"q": "____ the wood ____ expensive the furniture will be.",
						"answers": [
							"The older, the more",
							"The older the wood, the more expensive the furniture will be.",
							"the older, the more"
						],
						"hint": "old / expensive. The word expensive is already printed."
					},
					{
						"kind": "fill",
						"q": "____ the place ____ it will be for resting.",
						"answers": [
							"The shadier, the cooler",
							"The shadier the place, the cooler it will be for resting.",
							"the shadier, the cooler"
						],
						"hint": "shady / cool"
					},
					{
						"kind": "fill",
						"q": "____ the water ____ the tea.",
						"answers": [
							"The hotter, the nicer",
							"The hotter the water, the nicer the tea.",
							"the hotter, the nicer"
						],
						"hint": "hot / nice"
					},
					{
						"kind": "fill",
						"q": "____ one's style of living ____ one's life becomes.",
						"answers": [
							"The plainer, the easier",
							"The plainer one's style of living, the easier one's life becomes.",
							"the plainer, the easier"
						],
						"hint": "plain / easy"
					},
					{
						"kind": "fill",
						"q": "____ the room ____ I feel.",
						"answers": [
							"The darker, the more comfortable",
							"The darker the room, the more comfortable I feel.",
							"the darker, the more comfortable"
						],
						"hint": "dark / comfortable"
					}
				]
			},
			{
				"type": "h",
				"text": "Exercise 3"
			},
			{
				"type": "h",
				"text": "Mountain Climbers' Trip"
			},
			{
				"type": "p",
				"text": "Read one of the mountain climber's notes below and fill in the blanks with the pair of words provided. The pairs are jumbled. Select the correct pair. Remember to use the comparative form of the adjectives and the before each adjective."
			},
			{
				"type": "p",
				"text": "Paragraph 1 pairs: near / bright; organized / unorganized; much / less; close / excited; quick / late."
			},
			{
				"type": "p",
				"text": "Paragraph 2 pairs: quick / slow; steep / quiet; cool / fresh; near / far; high / difficult."
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Fill each blank in Mountain Climbers' Trip. Use the comparative form and put the before each comparative.",
				"items": [
					{
						"kind": "fill",
						"q": "We were very excited about the trip to the Northern Areas of Pakistan. We were going to climb a mountain for the first time in our lives. ____ the day of our climbing came ____ we got.",
						"answers": [
							"The closer, the more excited",
							"The closer the day of our climbing came, the more excited we got.",
							"the closer, the more excited",
							"closer, more excited"
						],
						"hint": "Paragraph 1: close / excited"
					},
					{
						"kind": "fill",
						"q": "Soon the day came. We all got up very early; however, ____ we tried to leave ____ we seemed to get. Our fingers seemed to have turned into toes.",
						"answers": [
							"The quicker, the later",
							"The quicker we tried to leave, the later we seemed to get.",
							"the quicker, the later",
							"quicker, later"
						],
						"hint": "Paragraph 1: quick / late"
					},
					{
						"kind": "fill",
						"q": "The van was waiting outside. ____ we thought we were ____ it seemed we were.",
						"answers": [
							"The more organized, the more unorganized",
							"The more organized we thought we were, the more unorganized it seemed we were.",
							"the more organized, the more unorganized"
						],
						"hint": "Paragraph 1: organized / unorganized"
					},
					{
						"kind": "fill",
						"q": "Finally, we all piled into the van. ____ the van drew to the mountain ____ the look in everyone's eyes.",
						"answers": [
							"The nearer, the brighter",
							"The nearer the van drew to the mountain, the brighter the look in everyone's eyes.",
							"the nearer, the brighter",
							"nearer, brighter"
						],
						"hint": "Paragraph 1: near / bright"
					},
					{
						"kind": "fill",
						"q": "The minute the van stopped, everyone jumped out. Our guide started to give us last minute instructions. ____ he guided us ____ we seemed to understand. All we heard was 'let's go'.",
						"answers": [
							"The more, the less",
							"The more he guided us, the less we seemed to understand.",
							"the more, the less",
							"more, less"
						],
						"hint": "Paragraph 1: much / less"
					},
					{
						"kind": "fill",
						"q": "At first it was great fun. ____ the mountain air got ____ we felt.",
						"answers": [
							"The cooler, the fresher",
							"The cooler the mountain air got, the fresher we felt.",
							"the cooler, the fresher",
							"cooler, fresher"
						],
						"hint": "Paragraph 2: cool / fresh"
					},
					{
						"kind": "fill",
						"q": "But, as we started climbing, ____ we got ____ it was for us to breathe.",
						"answers": [
							"The higher, the more difficult",
							"The higher we got, the more difficult it was for us to breathe.",
							"the higher, the more difficult",
							"higher, more difficult"
						],
						"hint": "Paragraph 2: high / difficult"
					},
					{
						"kind": "fill",
						"q": "Although the scenery was beautiful, we were feeling too tired to look around. We were just climbing. ____ we tried to climb ____ we became.",
						"answers": [
							"The steeper, the quieter",
							"The steeper we tried to climb, the quieter we became.",
							"the steeper, the quieter",
							"steeper, quieter"
						],
						"hint": "Paragraph 2: steep / quiet"
					},
					{
						"kind": "fill",
						"q": "And ____ we climbed ____ our speed became.",
						"answers": [
							"The quicker, the slower",
							"The quicker we climbed, the slower our speed became.",
							"the quicker, the slower",
							"quicker, slower"
						],
						"hint": "Paragraph 2: quick / slow"
					},
					{
						"kind": "fill",
						"q": "In fact, ____ the end of the journey ____ it seemed. Suddenly, one of our group members shouted 'Hurrah! Pakistan Zindabad!' It was then that we all looked up. We had reached the top and the scene around us was breathtaking.",
						"answers": [
							"The nearer, the farther",
							"The nearer the end of the journey, the farther it seemed.",
							"the nearer, the farther",
							"The nearer, the further",
							"nearer, farther"
						],
						"hint": "Paragraph 2: near / far"
					}
				]
			},
			{
				"type": "h",
				"text": "Relative Pronouns: Who, That, Which"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "The relative pronouns who, that, and which show a relationship between the main and relative clause. All these relative pronouns are placed after the noun. Who refers only to people. Example: She has a sister who is very helpful. That refers mostly to things, though a particular group of persons is also sometimes referred to by this pronoun. Example: The book that I bought is very good. Which, like that, refers to things; it is usually used to refer to one particular thing among others. Example: The car which has a flat tyre is mine."
			},
			{
				"type": "note",
				"text": "Who is used with people, that mainly with things (and sometimes with groups of people), and which is used to refer to one particular thing."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Part A has the first part of a sentence and part B has the other part, but these are all jumbled up. Form complete sentences.",
				"items": [{
					"kind": "match",
					"pairs": [
						{
							"left": "The farmer found the goat",
							"right": "which had been stolen from his farm."
						},
						{
							"left": "One of our neighbours",
							"right": "who used to live with us now lives with my uncle."
						},
						{
							"left": "I want to eat an egg",
							"right": "that has two yolks."
						},
						{
							"left": "They sold the house",
							"right": "that they had bought last year."
						},
						{
							"left": "Their new teacher,",
							"right": "who sings beautifully, is absent today."
						},
						{
							"left": "Zameer owns the shop",
							"right": "which has five doors."
						},
						{
							"left": "My grandfather",
							"right": "who travels a lot has gone to Canada."
						},
						{
							"left": "It was our class team",
							"right": "that won the volley ball match."
						}
					]
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Fill the blanks with who, that, or which, as appropriate. Write the complete sentences.",
				"items": [
					{
						"kind": "fill",
						"q": "I know the maid ____ broke the new tray.",
						"answers": ["who", "I know the maid who broke the new tray."],
						"hint": "A person."
					},
					{
						"kind": "fill",
						"q": "The book ____ has a yellow sticker belongs to Asad.",
						"answers": [
							"which",
							"that",
							"The book which has a yellow sticker belongs to Asad."
						],
						"hint": "One particular book."
					},
					{
						"kind": "fill",
						"q": "My friend painted the house ____ we sold yesterday.",
						"answers": [
							"that",
							"which",
							"My friend painted the house that we sold yesterday."
						]
					},
					{
						"kind": "fill",
						"q": "A gold medal was given to the player ____ scored the most runs.",
						"answers": ["who", "A gold medal was given to the player who scored the most runs."],
						"hint": "A person."
					},
					{
						"kind": "fill",
						"q": "The woman ____ is wearing a blue shawl is my sister.",
						"answers": ["who", "The woman who is wearing a blue shawl is my sister."],
						"hint": "A person."
					},
					{
						"kind": "fill",
						"q": "The computer I like the best is the one ____ is very old.",
						"answers": [
							"that",
							"which",
							"The computer I like the best is the one that is very old."
						]
					},
					{
						"kind": "fill",
						"q": "You will find the captain at the table ____ is near the window.",
						"answers": [
							"which",
							"that",
							"You will find the captain at the table which is near the window."
						],
						"hint": "One particular table."
					},
					{
						"kind": "fill",
						"q": "Many birds used to nest in the tree ____ they cut.",
						"answers": [
							"that",
							"which",
							"Many birds used to nest in the tree that they cut."
						]
					},
					{
						"kind": "fill",
						"q": "The ice-cream ____ is in this tub is better.",
						"answers": [
							"which",
							"that",
							"The ice-cream which is in this tub is better."
						],
						"hint": "One particular ice-cream."
					},
					{
						"kind": "fill",
						"q": "The child ____ was running slipped and fell.",
						"answers": ["who", "The child who was running slipped and fell."],
						"hint": "A person."
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Work in pairs and orally complete the dialogue by adding who, that, and which. After this, write the completed dialogue in your notebooks.",
				"items": [
					{
						"kind": "fill",
						"q": "Father: Tomorrow is a public holiday. Let's go and visit uncle Jamal ____ is ill.",
						"answers": ["who", "Let's go and visit uncle Jamal who is ill."]
					},
					{
						"kind": "fill",
						"q": "Areeb: Yes! Let's go there and then go to the park ____ is near his house.",
						"answers": [
							"which",
							"that",
							"the park which is near his house"
						]
					},
					{
						"kind": "fill",
						"q": "Maira: Can we take my friend ____ lives next door with us?",
						"answers": ["who", "my friend who lives next door"]
					},
					{
						"kind": "fill",
						"q": "Father: Sure. We can then have dinner at any small hotel ____ serves good food.",
						"answers": [
							"that",
							"which",
							"any small hotel that serves good food"
						]
					},
					{
						"kind": "fill",
						"q": "Areeb: Or we can buy bun kebab and fries from the hawker ____ stands outside the park and then have ice cream from a shop ____ sells cone ice cream.",
						"answers": [
							"who, that",
							"who, which",
							"who that",
							"who which",
							"who; which"
						],
						"hint": "Person, then thing."
					},
					{
						"kind": "fill",
						"q": "Maira: I want to have the ice cream ____ has chocolate pieces in it.",
						"answers": [
							"which",
							"that",
							"the ice cream which has chocolate pieces"
						]
					},
					{
						"kind": "fill",
						"q": "Areeb: Great! The plan that we visit uncle, Jamil ____ is ill and have ice cream later, is superb!",
						"answers": ["who", "Jamil who is ill"],
						"hint": "The book prints Jamil here."
					},
					{
						"kind": "fill",
						"q": "Maira: Let's ask mother, ____ is busy in the kitchen, what she thinks of our plan.",
						"answers": ["who", "mother, who is busy in the kitchen"]
					},
					{
						"kind": "fill",
						"q": "Father: I've already asked her. She loved the idea ____ we visit uncle Jamal.",
						"answers": ["that", "the idea that we visit uncle Jamal"]
					},
					{
						"kind": "fill",
						"q": "Maira: I must go and tell my friend. She loves the bun kebab ____ is sold near the park.",
						"answers": [
							"that",
							"which",
							"the bun kebab that is sold near the park"
						]
					}
				]
			}
		]
	},
	{
		"id": "6.4",
		"code": "6.4",
		"title": "Writing",
		"subtitle": "A Letter",
		"kind": "writing",
		"blocks": [
			{
				"type": "p",
				"text": "As you have learnt in the previous classes, there are two kinds of letters: formal and informal. You write informal letters to friends and family and formal letters to other people to whom you want to say something or ask for something."
			},
			{
				"type": "p",
				"text": "Work in pairs and write a letter to the Minister of Sports informing him/her about the need of a playground in your area."
			},
			{
				"type": "p",
				"text": "When you start writing the letter follow these steps:"
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Brainstorm what you are going to write.",
					"Develop a brief mind map.",
					"Decide the order in which you will write the points.",
					"Write the date at the top, followed by the designation of the person, the name of the ministry, federal/provincial government, and the name of the city.",
					"Address the person.",
					"Begin the letter by stating who you are and the purpose of writing the letter in the first paragraph.",
					"State what needs to be done and why in the second paragraph.",
					"End by repeating your request and asking for quick action.",
					"Thank the person.",
					"Put the signature at the end.",
					"Edit the completed letter to see that you have covered points 4–9 given above.",
					"Also check your work for correct grammar, spellings, punctuation and capitalization."
				]
			},
			{
				"type": "h",
				"text": "Sample letter"
			},
			{
				"type": "p",
				"text": "Read this model letter. It follows every step above. Then write your own."
			},
			{
				"type": "p",
				"text": "15 March 2026"
			},
			{
				"type": "p",
				"text": "The Minister of Sports\nMinistry of Sports\nGovernment of Sindh\nKarachi"
			},
			{
				"type": "p",
				"text": "Dear Sir/Madam,"
			},
			{
				"type": "p",
				"text": "I am a student of Class 8 in a government school in Karachi. I am writing to inform you that the children of our area do not have a playground."
			},
			{
				"type": "p",
				"text": "Our streets are narrow and full of traffic, so they are not a safe place for games. A public playground would give us room to play cricket and other sports, keep us healthy, and teach us sportsmanship. Please have a playground built in our area, with a boundary wall, a pitch, and a few bats and balls."
			},
			{
				"type": "p",
				"text": "I repeat my request and ask you to take quick action so that we can start playing before the summer holidays."
			},
			{
				"type": "p",
				"text": "Thank you."
			},
			{
				"type": "p",
				"text": "Yours faithfully,\nAreeb Ahmed\nClass 8"
			},
			{
				"type": "exercise",
				"title": "Writing task",
				"instruction": "Work in pairs and write a letter to the Minister of Sports informing him or her about the need of a playground in your area. Follow steps 4 to 10, then edit.",
				"items": [{
					"kind": "open",
					"q": "Write a formal letter to the Minister of Sports about the need for a playground in your area.",
					"model": "15 March 2026\n\nThe Minister of Sports\nMinistry of Sports\nGovernment of Sindh\nKarachi\n\nDear Sir/Madam,\n\nI am a student of Class 8 in a government school in Karachi. I am writing to inform you that the children of our area do not have a playground.\n\nOur streets are narrow and full of traffic, so they are not a safe place for games. A public playground would give us room to play cricket and other sports, keep us healthy, and teach us sportsmanship. Please have a playground built in our area, with a boundary wall, a pitch, and a few bats and balls.\n\nI repeat my request and ask you to take quick action so that we can start playing before the summer holidays.\n\nThank you.\n\nYours faithfully,\nAreeb Ahmed\nClass 8"
				}]
			}
		]
	},
	{
		"id": "6.5",
		"code": "6.5",
		"title": "Study Skills",
		"subtitle": "Analogies",
		"kind": "study",
		"blocks": [
			{
				"type": "p",
				"text": "New words are often formed by making small changes in the existing words. Let us look at some of the words here in which people get their names based on what they do."
			},
			{
				"type": "p",
				"text": "Example: One who carries something is called a carrier."
			},
			{
				"type": "p",
				"text": "Example: One who studies is called a student."
			},
			{
				"type": "p",
				"text": "Complete the following exercise. The one who finishes first will be the winner."
			},
			{
				"type": "note",
				"text": "These are analogies of the form “one who does this is called…”. Most add -er, but watch the spelling: actor, inventor, cyclist, beggar, tourist."
			},
			{
				"type": "exercise",
				"title": "Exercise",
				"instruction": "Write the name of the person. The one who finishes first is the winner. You may add more actions and their doers afterwards.",
				"items": [
					{
						"kind": "fill",
						"q": "One who sings is called a ____.",
						"answers": ["singer"],
						"hint": "sing + er"
					},
					{
						"kind": "fill",
						"q": "One who paints is called a ____.",
						"answers": ["painter"],
						"hint": "paint + er"
					},
					{
						"kind": "fill",
						"q": "One who acts is called an ____.",
						"answers": ["actor"],
						"hint": "act → actor, not acter"
					},
					{
						"kind": "fill",
						"q": "One who travels is called a ____.",
						"answers": ["traveller", "traveler"]
					},
					{
						"kind": "fill",
						"q": "One who runs is called a ____.",
						"answers": ["runner"]
					},
					{
						"kind": "fill",
						"q": "One who cleans is called a ____.",
						"answers": ["cleaner"]
					},
					{
						"kind": "fill",
						"q": "One who tours is called a ____.",
						"answers": ["tourist", "tourer"]
					},
					{
						"kind": "fill",
						"q": "One who manages is called a ____.",
						"answers": ["manager"]
					},
					{
						"kind": "fill",
						"q": "One who kidnaps is called a ____.",
						"answers": ["kidnapper"]
					},
					{
						"kind": "fill",
						"q": "One who invents is called an ____.",
						"answers": ["inventor"]
					},
					{
						"kind": "fill",
						"q": "One who climbs is called a ____.",
						"answers": ["climber"]
					},
					{
						"kind": "fill",
						"q": "One who writes is called a ____.",
						"answers": ["writer"]
					},
					{
						"kind": "fill",
						"q": "One who cycles is called a ____.",
						"answers": ["cyclist"],
						"hint": "cycle → cyclist"
					},
					{
						"kind": "fill",
						"q": "One who trains is called a ____.",
						"answers": ["trainer"]
					},
					{
						"kind": "fill",
						"q": "One who swims is called a ____.",
						"answers": ["swimmer"]
					},
					{
						"kind": "fill",
						"q": "One who creates is called a ____.",
						"answers": ["creator"]
					},
					{
						"kind": "fill",
						"q": "One who begs is called a ____.",
						"answers": ["beggar"],
						"hint": "beg → beggar"
					},
					{
						"kind": "fill",
						"q": "One who trades is called a ____.",
						"answers": ["trader"]
					},
					{
						"kind": "fill",
						"q": "One who supplies is called a ____.",
						"answers": ["supplier"]
					},
					{
						"kind": "fill",
						"q": "One who drives is called a ____.",
						"answers": ["driver"]
					}
				]
			}
		]
	},
	{
		"id": "6.6",
		"code": "6.6",
		"title": "Fun",
		"subtitle": "Playing Games",
		"kind": "fun",
		"blocks": [
			{
				"type": "h",
				"text": "Playing Games"
			},
			{
				"type": "p",
				"text": "Play the following game in groups of three. You will need a coin. The sentences use conditional type 2: If I + past simple, I would + base verb."
			},
			{
				"type": "callout",
				"title": "Examples from the book",
				"text": "If I were an astronaut I would go to the moon for a holiday. If I could sing I would be a famous TV star. In this game, use were with I: If I were rich, I would…"
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Sit in a group of three. Number yourselves Player 1, Player 2 and Player 3. You need one coin and the grid of boxes.",
					"Player 2 asks Player 1 to choose heads or tails, then flicks the coin.",
					"If Player 1 wins the toss, Player 1 chooses one box that has not been crossed and says a sentence beginning with If I, using the words in that box. Example: If I were rich, I would build a playground for the children of my street.",
					"If Player 1 loses the toss, the player who flicked the coin (Player 2) chooses the box, and the loser (Player 1) must say the If I… sentence for that box.",
					"Put a cross over the box that has been used so that it is not chosen again.",
					"Next turn: Player 3 flicks the coin and Player 2 calls heads or tails and says the sentence (or, if Player 2 loses, says the sentence for the box Player 3 chooses).",
					"Then Player 1 flicks and Player 3 says the sentence. Continue in this order until every box has been crossed.",
					"There is no score and no winner. The game is finished when all the boxes are covered and everyone has practised conditional type 2."
				]
			},
			{
				"type": "table",
				"caption": "Boxes. Cross out a box after its sentence has been said.",
				"headers": [
					"A",
					"B",
					"C",
					"D"
				],
				"rows": [
					[
						"were rich",
						"saw a ghost",
						"caught a thief",
						"were a genius"
					],
					[
						"went to China",
						"could fly",
						"failed in my exams",
						"were 7 ft tall"
					],
					[
						"could see in the dark",
						"found a bag full of money",
						"were the Prime Minister of Pakistan",
						"got the top position in my exams"
					],
					[
						"could study any subject I wanted",
						"got selected for the Olympic games",
						"could read people's minds",
						"could see with my eyes closed"
					],
					[
						"could be invisible",
						"could drive a car",
						"were poor",
						"received Rs.5000"
					],
					[
						"could eat whatever I wanted",
						"were the principal of my school",
						"could be a clown",
						"could be really handsome/beautiful"
					]
				]
			},
			{
				"type": "note",
				"text": "Do not award points. A useful sentence is enough. Help a classmate who is stuck, then cross the box."
			},
			{
				"type": "exercise",
				"title": "Practise one sentence",
				"instruction": "This is practice, not a score for the game. Say a conditional type 2 sentence for any one box.",
				"items": [{
					"kind": "open",
					"q": "Choose one box and say a sentence beginning with If I…",
					"model": "If I were rich, I would build a playground for the children of my area."
				}]
			}
		]
	}
];
var vocab$1 = [
	{
		"word": "broke into applause",
		"pos": "phrase",
		"meaning": "Broke into applause means the crowd suddenly started clapping very loudly.",
		"urdu": "یک دم زور سے تالیاں بجانا",
		"synonyms": [
			"clapped loudly",
			"cheered",
			"applauded"
		],
		"antonyms": ["booed", "stayed silent"],
		"sentences": ["The stadium broke into applause when Rajoo hit a huge six."]
	},
	{
		"word": "went to his head",
		"pos": "phrase",
		"meaning": "Went to his head means the success made him too proud.",
		"urdu": "سر پر چڑھ جانا؛ اسے غرور میں مبتلا کر دینا",
		"synonyms": [
			"made him proud",
			"made him conceited",
			"puffed him up"
		],
		"antonyms": ["kept him humble", "made him modest"],
		"sentences": ["All this success went to his head and he became rude."]
	},
	{
		"word": "rude",
		"pos": "adjective",
		"meaning": "Rude means not showing respect or good manners.",
		"urdu": "بدتمیز",
		"synonyms": [
			"impolite",
			"discourteous",
			"ill-mannered"
		],
		"antonyms": [
			"polite",
			"respectful",
			"courteous"
		],
		"sentences": ["He became very rude and arrogant after he became famous."]
	},
	{
		"word": "arrogant",
		"pos": "adjective",
		"meaning": "Arrogant means behaving as if one is better and more important than other people.",
		"urdu": "متکبر",
		"synonyms": [
			"proud",
			"haughty",
			"conceited"
		],
		"antonyms": [
			"humble",
			"modest",
			"meek"
		],
		"sentences": ["Nabeel could not understand why his best friend was behaving so arrogantly."]
	},
	{
		"word": "irritating",
		"pos": "adjective",
		"meaning": "Irritating describes something that makes people a little angry.",
		"urdu": "چڑانے والا؛ پریشان کن",
		"synonyms": [
			"annoying",
			"bothersome",
			"exasperating"
		],
		"antonyms": [
			"pleasing",
			"soothing",
			"calming"
		],
		"sentences": ["His attitude was irritating the international players."]
	},
	{
		"word": "counselled",
		"pos": "verb",
		"meaning": "Counselled means advised someone about what they should do.",
		"urdu": "نصیحت کی",
		"synonyms": [
			"advised",
			"guided",
			"recommended"
		],
		"antonyms": [
			"misled",
			"ignored",
			"neglected"
		],
		"sentences": ["They often counselled him, but to no avail."]
	},
	{
		"word": "to no avail",
		"pos": "phrase",
		"meaning": "To no avail means the effort had no useful result.",
		"urdu": "بے سود؛ کوئی فائدہ نہ ہوا",
		"synonyms": [
			"in vain",
			"without success",
			"uselessly"
		],
		"antonyms": [
			"successfully",
			"effectively",
			"with success"
		],
		"sentences": ["The coach and the manager counselled Rajoo, but to no avail."]
	},
	{
		"word": "resounding",
		"pos": "adjective",
		"meaning": "Resounding here means very great and wholehearted.",
		"urdu": "زبردست",
		"synonyms": [
			"tremendous",
			"huge",
			"thunderous"
		],
		"antonyms": [
			"weak",
			"faint",
			"slight"
		],
		"sentences": ["When the team returned home they received a resounding welcome."]
	},
	{
		"word": "well-suited",
		"pos": "adjective",
		"meaning": "Well-suited here means dressed neatly in a smart suit.",
		"urdu": "اچھے سوٹ میں ملبوس",
		"synonyms": [
			"well-dressed",
			"smartly dressed",
			"elegant"
		],
		"antonyms": [
			"shabby",
			"untidy",
			"poorly dressed"
		],
		"sentences": ["A well-suited, handsome man stepped out of the car."]
	},
	{
		"word": "awe",
		"pos": "noun",
		"meaning": "Awe is a feeling of deep respect, often mixed with wonder.",
		"urdu": "رعب؛ احترام سے حیرت",
		"synonyms": [
			"wonder",
			"admiration",
			"reverence"
		],
		"antonyms": [
			"contempt",
			"scorn",
			"indifference"
		],
		"sentences": ["The town people listened to his stories in awe."]
	},
	{
		"word": "renowned",
		"pos": "adjective",
		"meaning": "Renowned means famous and respected by many people.",
		"urdu": "نامور",
		"synonyms": [
			"famous",
			"celebrated",
			"well-known"
		],
		"antonyms": [
			"unknown",
			"obscure",
			"nameless"
		],
		"sentences": ["Such behaviour did not suit a world renowned player."]
	},
	{
		"word": "chatting",
		"pos": "verb",
		"meaning": "Chatting means talking in a friendly, easy way.",
		"urdu": "گپ شپ کرنا",
		"synonyms": [
			"talking",
			"conversing",
			"chattering"
		],
		"antonyms": [
			"ignoring",
			"quarrelling",
			"staying silent"
		],
		"sentences": ["Both friends walked home, laughing and chatting all the way."]
	},
	{
		"word": "pranks",
		"pos": "noun",
		"meaning": "Pranks are tricks played on someone as a joke.",
		"urdu": "مذاقاً شرارتیں",
		"synonyms": [
			"tricks",
			"practical jokes",
			"mischief"
		],
		"antonyms": [
			"kindnesses",
			"good deeds",
			"serious acts"
		],
		"sentences": ["They talked about the pranks they had played in childhood."]
	},
	{
		"word": "scrap-book",
		"pos": "noun",
		"meaning": "A scrap-book is a book in which one sticks pictures or newspaper articles.",
		"urdu": "تصویریں اور اخباری کترنیں چسپاں کرنے والی کتاب",
		"synonyms": [
			"album",
			"memory book",
			"cuttings book"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["Nabeel showed his friend a scrap book which he had made for him."]
	},
	{
		"word": "intolerable",
		"pos": "adjective",
		"meaning": "Intolerable means so bad that it cannot be accepted.",
		"urdu": "ناقابلِ برداشت",
		"synonyms": [
			"unbearable",
			"unacceptable",
			"insufferable"
		],
		"antonyms": [
			"tolerable",
			"acceptable",
			"bearable"
		],
		"sentences": ["When things became intolerable, the team decided to ban him."]
	},
	{
		"word": "sportsmanship",
		"pos": "noun",
		"meaning": "Sportsmanship is fair, generous and polite behaviour in sport.",
		"urdu": "کھیل کا اچھا جذبہ",
		"synonyms": [
			"fair play",
			"generosity",
			"graciousness"
		],
		"antonyms": [
			"cheating",
			"unfairness",
			"unsporting behaviour"
		],
		"sentences": ["Rajoo realised that greatness has a great deal to do with sportsmanship."]
	},
	{
		"word": "insolent",
		"pos": "adjective",
		"meaning": "Insolent means boldly rude and disrespectful.",
		"urdu": "گستاخ",
		"synonyms": [
			"rude",
			"impudent",
			"disrespectful"
		],
		"antonyms": [
			"respectful",
			"polite",
			"courteous"
		],
		"sentences": ["His performance was excellent, but his insolent behaviour was the same."]
	},
	{
		"word": "luxurious",
		"pos": "adjective",
		"meaning": "Luxurious means very comfortable, grand and expensive.",
		"urdu": "آلیشان",
		"synonyms": [
			"lavish",
			"grand",
			"splendid"
		],
		"antonyms": [
			"plain",
			"simple",
			"poor"
		],
		"sentences": ["A luxurious car stopped in front of the house."]
	},
	{
		"word": "muttered",
		"pos": "verb",
		"meaning": "Muttered means spoke in a low voice that was hard to hear.",
		"urdu": "بڑبڑایا",
		"synonyms": [
			"mumbled",
			"murmured",
			"whispered"
		],
		"antonyms": [
			"shouted",
			"announced",
			"yelled"
		],
		"sentences": ["“It's Rajoo,” Nabeel muttered."]
	},
	{
		"word": "anxiously",
		"pos": "adverb",
		"meaning": "Anxiously means in a worried and eager way.",
		"urdu": "بے چینی سے",
		"synonyms": [
			"nervously",
			"eagerly",
			"worriedly"
		],
		"antonyms": [
			"calmly",
			"patiently",
			"peacefully"
		],
		"sentences": ["Nabeel was anxiously waiting for his friend's return."]
	},
	{
		"word": "gesture",
		"pos": "noun",
		"meaning": "A gesture is an action that shows a feeling or a generous attitude.",
		"urdu": "جذبے کا اظہار؛ نیک اشارہ",
		"synonyms": [
			"act",
			"sign",
			"deed"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["As a gesture of great sportsmanship, Mark Taylor let go of his ego."]
	},
	{
		"word": "ego",
		"pos": "noun",
		"meaning": "Ego is a person's sense of self-importance.",
		"urdu": "انا",
		"synonyms": [
			"pride",
			"self-importance",
			"vanity"
		],
		"antonyms": [
			"humility",
			"modesty",
			"selflessness"
		],
		"sentences": ["He let go of his ego and individual success for Australia's win."]
	},
	{
		"word": "dismissal",
		"pos": "noun",
		"meaning": "In cricket, a dismissal is the sending of a batsman out.",
		"urdu": "بلے باز کا آؤٹ ہونا",
		"synonyms": [
			"wicket",
			"getting out",
			"being given out"
		],
		"antonyms": [
			"not out",
			"staying in",
			"survival"
		],
		"sentences": ["Vettori immediately withdrew the dismissal."]
	},
	{
		"word": "pavilion",
		"pos": "noun",
		"meaning": "The pavilion is the building at a cricket ground where the players sit.",
		"urdu": "پویلین؛ کھلاڑیوں کی عمارت",
		"synonyms": [
			"dressing room",
			"players' building",
			"clubhouse"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["Symonds had walked two-thirds of the way back to the pavilion."]
	},
	{
		"word": "skipper",
		"pos": "noun",
		"meaning": "The skipper is the captain of a sports team.",
		"urdu": "کپتان",
		"synonyms": [
			"captain",
			"leader",
			"team captain"
		],
		"antonyms": [
			"follower",
			"teammate",
			"player"
		],
		"sentences": ["The Sri Lankan skipper, Marvan Atapattu, called Symonds back."]
	},
	{
		"word": "upheld",
		"pos": "verb",
		"meaning": "Upheld means kept a decision and treated it as correct.",
		"urdu": "برقرار رکھا",
		"synonyms": [
			"confirmed",
			"supported",
			"maintained"
		],
		"antonyms": [
			"overturned",
			"rejected",
			"cancelled"
		],
		"sentences": ["A very loud appeal that he was out was upheld by the umpire."]
	},
	{
		"word": "idly",
		"pos": "adverb",
		"meaning": "Idly means without a serious purpose or close attention.",
		"urdu": "بے خیالی سے",
		"synonyms": [
			"casually",
			"aimlessly",
			"lazily"
		],
		"antonyms": [
			"carefully",
			"attentively",
			"purposefully"
		],
		"sentences": ["Idly, he started turning the pages of the scrap book."]
	},
	{
		"word": "collision",
		"pos": "noun",
		"meaning": "A collision is a crash when two people or things hit each other.",
		"urdu": "ٹکر",
		"synonyms": [
			"crash",
			"impact",
			"bump"
		],
		"antonyms": [
			"miss",
			"avoidance",
			"separation"
		],
		"sentences": ["Vettori said that it was his collision which had caused the confusion."]
	},
	{
		"word": "ban",
		"pos": "verb",
		"meaning": "To ban someone is to officially forbid them from taking part.",
		"urdu": "پابندی لگانا",
		"synonyms": [
			"forbid",
			"bar",
			"prohibit"
		],
		"antonyms": [
			"allow",
			"permit",
			"welcome"
		],
		"sentences": ["The decision was taken to ban him from the team."]
	},
	{
		"word": "superstar",
		"pos": "noun",
		"meaning": "A superstar is a very famous and successful performer.",
		"urdu": "بہت بڑا ستارہ",
		"synonyms": [
			"celebrity",
			"star",
			"idol"
		],
		"antonyms": [
			"unknown",
			"nobody",
			"beginner"
		],
		"sentences": ["Before long, he became a superstar of the cricket world."]
	},
	{
		"word": "buddy",
		"pos": "noun",
		"meaning": "A buddy is a close friend.",
		"urdu": "گہرا دوست",
		"synonyms": [
			"friend",
			"pal",
			"companion"
		],
		"antonyms": [
			"enemy",
			"stranger",
			"foe"
		],
		"sentences": ["He came forward to greet his old buddy, but Rajoo ignored him."]
	},
	{
		"word": "appeal",
		"pos": "noun",
		"meaning": "In cricket, an appeal is a loud shout asking the umpire to give a batsman out.",
		"urdu": "امپائر سے آؤٹ کا مطالبہ",
		"synonyms": [
			"shout for out",
			"claim",
			"call"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["A very loud appeal from the Sri Lankans was upheld by the umpire."]
	},
	{
		"word": "non-striker",
		"pos": "noun",
		"meaning": "The non-striker is the batsman standing at the bowler's end, not facing the ball.",
		"urdu": "نان اسٹرائیکر؛ گیند کا سامنا نہ کرنے والا بلے باز",
		"synonyms": [
			"batsman at the other end",
			"partner batsman",
			"runner"
		],
		"antonyms": ["striker", "facing batsman"],
		"sentences": ["Vettori collided with the non-striker, Malcolm Waller."]
	},
	{
		"word": "bails",
		"pos": "noun",
		"meaning": "The bails are the two small pieces of wood that rest on top of the stumps.",
		"urdu": "وکٹ کے اوپر کی چھوٹی لکڑیاں",
		"synonyms": [
			"stump tops",
			"wicket pieces",
			"small stumps"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["The wicket keeper whipped the bails, but Vettori withdrew the dismissal."]
	}
];
var unit6_default = {
	id: "u6",
	number: 6,
	title: title$1,
	learn: learn$1,
	lessons: lessons$1,
	vocab: vocab$1
};
var unit7_exports = /* @__PURE__ */ __exportAll({
	default: () => unit7_default,
	id: () => "u7",
	learn: () => learn,
	lessons: () => lessons,
	number: () => 7,
	title: () => title,
	vocab: () => vocab
});
var title = "The Multiple Roles that Women Play";
var learn = [
	{
		"skill": "Reading",
		"points": [
			"Use pre-reading strategies to predict the content of a text from pictures",
			"Skim text to obtain a general idea of the text",
			"Deduce the meaning of difficult words from context",
			"Apply critical thinking to interact with text",
			"Scan text to answer short questions",
			"Make simple inferences using context of the text and prior knowledge",
			"Respond orally or in writing",
			"Apply world knowledge and own feelings/opinion to the text read"
		]
	},
	{
		"skill": "Speaking",
		"points": ["Use conventions of interaction to present and explain one's point of view clearly"]
	},
	{
		"skill": "Language Practice",
		"points": ["Change and use degrees of adjectives with reference to 'than'", "Recognize the function of, and use emphatic pronouns"]
	},
	{
		"skill": "Writing",
		"points": ["Write an essay of at least four paragraphs: i) Introductory paragraph, ii) body paragraphs and iii) concluding paragraph"]
	},
	{
		"skill": "Study Skills",
		"points": ["Abbreviations"]
	},
	{
		"skill": "Fun",
		"points": ["Complete the crossword puzzle", "Act as one of the characters in the puzzle"]
	}
];
var lessons = [
	{
		"id": "7.1",
		"code": "7.1",
		"title": "Reading Comprehension",
		"subtitle": "The Multiple Roles that Women Play",
		"kind": "reading",
		"blocks": [
			{
				"type": "h",
				"text": "Pre-Reading"
			},
			{
				"type": "h",
				"text": "Predict"
			},
			{
				"type": "p",
				"text": "Look at the picture. What do you think the text is about? Write your answers in the space provided below."
			},
			{
				"type": "p",
				"text": "The text will describe:"
			},
			{
				"type": "list",
				"ordered": false,
				"items": [
					"a. _______________________",
					"b. _______________________",
					"c. _______________________"
				]
			},
			{
				"type": "p",
				"text": "Work with a partner. Compare your answers."
			},
			{
				"type": "exercise",
				"title": "Pre-Reading",
				"instruction": "Before you read, predict what the text will describe. After reading, check how close your prediction was.",
				"items": [{
					"kind": "open",
					"q": "The text will describe: a. ________  b. ________  c. ________. Compare your ideas with a partner.",
					"model": "a. The many kinds of work women do, sometimes all at the same time. b. How women earn money at home, in the fields, and in cities. c. Why girls should be educated so that women can help the family and the country progress."
				}]
			},
			{
				"type": "note",
				"text": "Read the dialogue in pairs. One student takes Arshad's role and the other takes Noman's. Read softly, then do Exercise 1."
			},
			{
				"type": "h",
				"text": "Reading Text"
			},
			{
				"type": "h",
				"text": "The Multiple Roles that Women Play"
			},
			{
				"type": "p",
				"text": "Noman's father, Arshad Sikander, works in the development sector. Over the last many months he has been touring the province to gather information for a report he is writing. Noman is hovering around his father asking questions."
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Noman",
						"text": "(laughing) Daddy! What a funny picture! Where did you find it?"
					},
					{
						"who": "Arshad",
						"text": "I found it on the internet. I think it's an interesting picture. It shows the kinds of work women do, sometimes all at the same time."
					},
					{
						"who": "Noman",
						"text": "(looking at the picture again) Yes, I can see what you mean."
					},
					{
						"who": "Arshad",
						"text": "You see, I have to present a report at the seminar to be held in Hyderabad next month, on the multiple roles that women play in our society."
					},
					{
						"who": "Noman",
						"text": "What's a seminar, Daddy?"
					},
					{
						"who": "Arshad",
						"text": "(taking off his glasses) Well, a seminar is like a big meeting where people from different areas, provinces and countries meet together and present reports. In this seminar, experts from different countries will be describing the kind of work that women do in their countries."
					},
					{
						"who": "Noman",
						"text": "Tell me more, please."
					},
					{
						"who": "Arshad",
						"text": "Well, people have always believed that women stay at home and take care of the house while the man works and provides food and other things for the family. Do you agree?"
					},
					{
						"who": "Noman",
						"text": "Yes, that's what Mummy does."
					},
					{
						"who": "Arshad",
						"text": "Agreed. But is that an easy job? Take a look at this picture. What is the woman doing? Can you identify the different kinds of household chores she's doing?"
					},
					{
						"who": "Noman",
						"text": "Ah, yes. I see what you mean."
					},
					{
						"who": "Arshad",
						"text": "Look closer, how many hands does she have?"
					},
					{
						"who": "Noman",
						"text": "She has many hands. Do some women actually have so many hands, Daddy?"
					},
					{
						"who": "Arshad",
						"text": "(laughing) No, son. This is just to show that women do a lot of things at the same time or simultaneously. This is called multi-tasking."
					},
					{
						"who": "Noman",
						"text": "Oh, that's a nice word: multi-tasking."
					},
					{
						"who": "Arshad",
						"text": "Ok, now tell me what are the tasks that women do to earn money?"
					},
					{
						"who": "Noman",
						"text": "They work as teachers, doctors, or nurses."
					},
					{
						"who": "Arshad",
						"text": "You are right! And this is the point that we all need to understand; no family, no society, and no nation can progress unless women participate in economic activity."
					},
					{
						"who": "Noman",
						"text": "What is economic activity, Daddy?"
					},
					{
						"who": "Arshad",
						"text": "It means doing work to earn money."
					},
					{
						"who": "Noman",
						"text": "But Mummy doesn't do that."
					},
					{
						"who": "Arshad",
						"text": "Son, do you see that weaving loom? Your mother is just one of the many women in this region who hand weave cloth that is sent to the city where clothes are made and sold to customers. And that's not all. Look at your grandmother. What's she doing?"
					},
					{
						"who": "Noman",
						"text": "Oh, that's her favourite pastime. She likes to do embroidery. She's always at it."
					},
					{
						"who": "Arshad",
						"text": "True. But do you know that she takes orders and sells the work she does? This work is also taken to the city to be sold at large stores."
					},
					{
						"who": "Noman",
						"text": "I've never thought of that, Daddy. What else do women do to earn money?"
					},
					{
						"who": "Arshad",
						"text": "Look around you. The more educated ones work as doctors and teachers. But many of them work in the fields and indirectly earn money for the family. Have you seen how many women pick cotton, while others pluck roses, and yet others cut the crops? They are agricultural workers who are often not paid money but their work brings in money for the family."
					},
					{
						"who": "Noman",
						"text": "Yes, I see women doing all kinds of work in the fields. They also milk the cows and buffalos to sell the milk. And they keep hens and sell their eggs. Wow! They participate in a lot of economic activity. I never thought about it."
					},
					{
						"who": "Arshad",
						"text": "In the cities, women work in banks, offices and stores. In fact, many of them work in factories."
					},
					{
						"who": "Noman",
						"text": "Women work in factories!! That's surprising."
					},
					{
						"who": "Arshad",
						"text": "(takes out a picture) Here, look at this picture. Can you see what the women are doing?"
					},
					{
						"who": "Noman",
						"text": "Now I get it. Actually women are very active but we just think that they don't do anything."
					},
					{
						"who": "Arshad",
						"text": "Right. Women are playing a very active role in development. Now the governments have begun to realize that a country cannot really make progress unless women actively contribute in the economy."
					},
					{
						"who": "Noman",
						"text": "This is very interesting."
					},
					{
						"who": "Arshad",
						"text": "What is even more interesting is that when women earn money they usually spend it more on the health care and education of their children."
					},
					{
						"who": "Noman",
						"text": "So we can say that women are playing a major role in the progress and development of our country."
					},
					{
						"who": "Arshad",
						"text": "Exactly. Hence, women must be encouraged to acquire education so that they can become more productive members of the society."
					},
					{
						"who": "Noman",
						"text": "What you are saying is that we must encourage our girls to study and adopt different professions, if they want to do so."
					},
					{
						"who": "Arshad",
						"text": "(patting his son on the shoulder) Exactly. Now run along and think about this while I work on my report."
					},
					{
						"who": "Noman",
						"text": "One last question, Daddy."
					},
					{
						"who": "Arshad",
						"text": "Yes?"
					},
					{
						"who": "Noman",
						"text": "Can I go to the seminar with you? I want to hear more about women and how they contribute to nation-building."
					},
					{
						"who": "Arshad",
						"text": "I will have to ask for permission from the organisers so I can't promise; but I will definitely try to take you along."
					}
				]
			},
			{
				"type": "h",
				"text": "While Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Which of the following statements best describes the main idea? Select the best statement.",
				"items": [{
					"kind": "mcq",
					"q": "Which statement best describes the main idea of the text?",
					"options": [
						"Women are useful members of their homes",
						"Women are brave and intelligent.",
						"Women are productive members of a society",
						"Women stay at home, cook and clean"
					],
					"answer": 2
				}]
			},
			{
				"type": "h",
				"text": "Vocabulary"
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Most of the following words appear in the text. They are in a jumbled up order. Re-read the text and find them. There are four extra words in the list. Mark the four words that you cannot find in the text. Then match each meaning with the correct word from the text. Check your answers with your partner.",
				"items": [{
					"kind": "classify",
					"q": "Place each word in the right group. Four words are not in the reading text.",
					"buckets": ["In the reading text", "Extra word (not in the text)"],
					"cards": [
						{
							"text": "economic activity",
							"bucket": 0
						},
						{
							"text": "nation-building",
							"bucket": 0
						},
						{
							"text": "present",
							"bucket": 0
						},
						{
							"text": "conference",
							"bucket": 1
						},
						{
							"text": "weave",
							"bucket": 0
						},
						{
							"text": "hovering",
							"bucket": 0
						},
						{
							"text": "discussion",
							"bucket": 1
						},
						{
							"text": "development sector",
							"bucket": 0
						},
						{
							"text": "pastime",
							"bucket": 0
						},
						{
							"text": "multi-tasking",
							"bucket": 0
						},
						{
							"text": "community",
							"bucket": 1
						},
						{
							"text": "simultaneously",
							"bucket": 0
						},
						{
							"text": "chores",
							"bucket": 0
						},
						{
							"text": "issue",
							"bucket": 1
						},
						{
							"text": "seminar",
							"bucket": 0
						}
					]
				}, {
					"kind": "match",
					"q": "Write the correct word from the text against each meaning.",
					"pairs": [
						{
							"left": "a field in which progress and improvement is studied",
							"right": "development sector"
						},
						{
							"left": "doing two or more things at the same time",
							"right": "multi-tasking"
						},
						{
							"left": "work that is done to earn some money",
							"right": "economic activity"
						},
						{
							"left": "make cloth with thread",
							"right": "weave"
						},
						{
							"left": "a thing done for enjoyment",
							"right": "pastime"
						},
						{
							"left": "developing the country",
							"right": "nation-building"
						},
						{
							"left": "stand or move about near someone without any purpose",
							"right": "hovering"
						},
						{
							"left": "a gathering of people for exchanging ideas and discussing",
							"right": "seminar"
						},
						{
							"left": "to share information and thought",
							"right": "present"
						},
						{
							"left": "everyday work",
							"right": "chores"
						},
						{
							"left": "at the same time",
							"right": "simultaneously"
						}
					]
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Select True if the statement is true, False if the statement is not true, or Not stated if the information is not stated in the text.",
				"items": [
					{
						"kind": "mcq",
						"q": "Arshad has done a lot of travelling over the last several months.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "Arshad spent a lot of time in Tharparkar.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Arshad is writing poetry to present at the seminar.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Noman's mother and grandmother are both economically active.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "Education will help women become better cooks.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Women have the ability to do a number of things at the same time.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "Women are as important as men for the progress and development of a country.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 0
					},
					{
						"kind": "mcq",
						"q": "In cities, women work only in offices.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 1
					},
					{
						"kind": "mcq",
						"q": "Pakistan has many female doctors.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 2
					},
					{
						"kind": "mcq",
						"q": "Arshad feels that education is not important for women.",
						"options": [
							"True",
							"False",
							"Not stated"
						],
						"answer": 1
					}
				]
			},
			{
				"type": "h",
				"text": "Post Reading"
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Read the text and, in pairs, discuss and make a list of all types of work mentioned in the text that women do. Sort each kind of work into the right column. After you have listed all the things mentioned in the text, you can add other areas of work that you can think of.",
				"items": [{
					"kind": "classify",
					"q": "Place each kind of work mentioned in the text in the right column.",
					"buckets": [
						"Household chores",
						"Family income chores at home or in the field",
						"Work outside the home"
					],
					"cards": [
						{
							"text": "taking care of the house",
							"bucket": 0
						},
						{
							"text": "hand weaving cloth that is sold in the city",
							"bucket": 1
						},
						{
							"text": "doing embroidery, taking orders, and selling it",
							"bucket": 1
						},
						{
							"text": "picking cotton",
							"bucket": 1
						},
						{
							"text": "plucking roses",
							"bucket": 1
						},
						{
							"text": "cutting the crops",
							"bucket": 1
						},
						{
							"text": "milking cows and buffalos and selling the milk",
							"bucket": 1
						},
						{
							"text": "keeping hens and selling their eggs",
							"bucket": 1
						},
						{
							"text": "working as a teacher",
							"bucket": 2
						},
						{
							"text": "working as a doctor",
							"bucket": 2
						},
						{
							"text": "working as a nurse",
							"bucket": 2
						},
						{
							"text": "working in banks",
							"bucket": 2
						},
						{
							"text": "working in offices",
							"bucket": 2
						},
						{
							"text": "working in stores",
							"bucket": 2
						},
						{
							"text": "working in factories",
							"bucket": 2
						}
					]
				}, {
					"kind": "open",
					"q": "Add other areas of work, not named in the text, that women can do. Write at least four.",
					"model": "Women can also work as engineers, lawyers, pilots, journalists, scientists, police officers, software developers, and business owners. They can run shops, design clothes, or teach skills to other women in the community."
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "Work in pairs. Read the text and complete the following sentences. First discuss all the statements orally and then write them. Remember to use the past tense. Write the words that complete each sentence.",
				"items": [
					{
						"kind": "fill",
						"q": "Arshad toured the province because ____.",
						"answers": [
							"he wanted to gather information for a report he was writing",
							"he was gathering information for a report",
							"he had to collect information for the report he was writing"
						],
						"hint": "Think about why he had been travelling."
					},
					{
						"kind": "fill",
						"q": "He thought that the picture was interesting because ____.",
						"answers": [
							"it showed the kinds of work women do, sometimes all at the same time",
							"it showed the many kinds of work women did at the same time",
							"it showed women doing several jobs together"
						],
						"hint": "Look at what Arshad says about the picture."
					},
					{
						"kind": "fill",
						"q": "The picture showed a woman with many hands because ____.",
						"answers": [
							"it showed that women do many things at the same time",
							"it was meant to show multi-tasking",
							"women do a lot of things simultaneously"
						],
						"hint": "Women do not really have many hands."
					},
					{
						"kind": "fill",
						"q": "Noman's mother and grandmother were economically active because ____.",
						"answers": [
							"his mother hand wove cloth that was sold and his grandmother sold her embroidery",
							"his mother wove cloth for sale and his grandmother took orders for her embroidery",
							"both of them did work that brought in money"
						],
						"hint": "Economic activity means work done to earn money."
					},
					{
						"kind": "fill",
						"q": "Noman thought his grandmother did embroidery because ____.",
						"answers": [
							"he thought it was only her favourite pastime",
							"he believed she did it only for enjoyment",
							"he thought she liked it and did not know she sold it"
						],
						"hint": "He calls it her favourite pastime."
					},
					{
						"kind": "fill",
						"q": "Arshad believed that women must acquire education because ____.",
						"answers": [
							"it would help them become more productive members of society",
							"education would make them more productive",
							"they could then contribute more to society"
						],
						"hint": "Look at Arshad's words near the end of the talk."
					},
					{
						"kind": "fill",
						"q": "Noman stated that girls should be encouraged to study because ____.",
						"answers": [
							"they could adopt different professions if they wanted to",
							"they might then choose different professions",
							"studying would let them take up professions they wanted"
						],
						"hint": "Noman repeats his father's idea in his own words."
					},
					{
						"kind": "fill",
						"q": "After the discussion Arshad asked Noman to go away because ____.",
						"answers": [
							"he wanted to work on his report",
							"he had to finish his report",
							"he told Noman to think about the talk while he worked on his report"
						],
						"hint": "Arshad says, 'Now run along'."
					},
					{
						"kind": "fill",
						"q": "Noman wanted to go to the seminar with his father because ____.",
						"answers": [
							"he wanted to hear more about how women contribute to nation-building",
							"he wanted to learn more about women's work",
							"he wanted to hear more about women and nation-building"
						],
						"hint": "Read Noman's last question."
					},
					{
						"kind": "fill",
						"q": "His father did not promise to take him because ____.",
						"answers": [
							"he had to ask the organisers for permission",
							"he could not promise until the organisers allowed it",
							"he needed permission from the organisers"
						],
						"hint": "Arshad says he cannot promise."
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 6",
				"instruction": "Work in groups of three and make a mind map about the role that women can play in society to improve the quality of life of their families and to raise the level of development in the country. You can use these points or write your own: economic activity at home; importance of education; economic activity outside; helping other family members to earn more. Put 'The multiple roles of women' in the centre.",
				"items": [{
					"kind": "open",
					"q": "Write a short mind map, in words, on the multiple roles of women. Use the four points given in the book, and add a detail from the text under each point.",
					"model": "Centre: The multiple roles of women. Branch 1, economic activity at home: women weave cloth, do embroidery for sale, milk cows and buffalos, and sell eggs. Branch 2, economic activity outside: they work as teachers, doctors, and nurses, and in banks, offices, stores, factories, and fields, where they pick cotton, pluck roses, and cut crops. Branch 3, importance of education: educated women become more productive and can choose professions, so girls should be encouraged to study. Branch 4, helping the family earn more: when women earn, they usually spend more on their children's health and education, which improves family life and helps the country develop."
				}]
			}
		]
	},
	{
		"id": "7.2",
		"code": "7.2",
		"title": "Speaking",
		"subtitle": "Persuading Maleeha to study",
		"kind": "speaking",
		"blocks": [
			{
				"type": "p",
				"text": "Use conventions and dynamics of interaction to present and explain one's point of view clearly."
			},
			{
				"type": "p",
				"text": "Fillers are words used in natural speech. Some such fillers are given below. You can use some of these while speaking or writing dialogues."
			},
			{
				"type": "list",
				"ordered": false,
				"items": [
					"you know",
					"like",
					"ok",
					"well",
					"basically",
					"literally",
					"actually",
					"oh",
					"really",
					"to tell you the truth",
					"you see"
				]
			},
			{
				"type": "p",
				"text": "Work in pairs and prepare a dialogue between Noman and his sister, Maleeha. The scene is that Noman's sister, Maleeha, who is 10 years old, plays with her friends the whole day. She hardly ever does her homework and never studies. Very often she doesn't go to school. She gets bad grades but she doesn't care. Noman is trying to persuade her to take her studies more seriously so that in the future she can play an important and productive role in society. You may begin like this:"
			},
			{
				"type": "dialogue",
				"lines": [
					{
						"who": "Noman",
						"text": "Maleeha, where have you been? It's almost sunset."
					},
					{
						"who": "Maleeha",
						"text": "Oh, I was at Seema's house."
					},
					{
						"who": "Noman",
						"text": "………………………….."
					},
					{
						"who": "Maleeha",
						"text": "……………………………"
					}
				]
			},
			{
				"type": "p",
				"text": "Once you have written the dialogue, practise it with your partner. First, one student should take the role of Noman and the other of Maleeha. Then change roles and practise the dialogue again."
			},
			{
				"type": "exercise",
				"title": "Dialogue",
				"instruction": "Write a complete dialogue. Keep the two starter lines, continue the conversation, and use some of the fillers. Then practise both roles.",
				"items": [{
					"kind": "open",
					"q": "Write the dialogue in which Noman persuades his ten-year-old sister Maleeha to take her studies seriously so that she can play a productive role in society.",
					"model": "Noman: Maleeha, where have you been? It's almost sunset.\nMaleeha: Oh, I was at Seema's house.\nNoman: Again? You know, you were there yesterday too. Have you finished your homework?\nMaleeha: No. We were playing. Homework is boring.\nNoman: Well, to tell you the truth, I am worried. You hardly ever study, and very often you don't even go to school.\nMaleeha: So what? I still get through, like, somehow. Bad grades don't bother me.\nNoman: Actually, they should. Daddy said that if girls study, they can become doctors, teachers, or other productive members of society.\nMaleeha: Oh, really? I just want to play with my friends.\nNoman: You see, playing is fine, but you basically need to learn as well. If you miss school now, many professions will be closed to you later.\nMaleeha: Ok. What do you want me to do?\nNoman: Come inside, open your books, and finish today's work. I will sit with you. From tomorrow, go to school every day.\nMaleeha: All right. I will try. I don't want to be left behind while other girls build the country."
				}]
			}
		]
	},
	{
		"id": "7.3",
		"code": "7.3",
		"title": "Language Practice",
		"subtitle": "Adjectives with reference to 'than', and Emphatic Pronouns",
		"kind": "language",
		"blocks": [
			{
				"type": "h",
				"text": "Adjectives With Reference to 'Than'"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "Adjectives are used to describe a person, animal, place, or object. For example: a tall girl; a noisy animal; a beautiful valley; a nice bag. The comparative form of the adjective is used to compare two persons, animals, places, or objects. For example: a taller girl; a noisier animal; a more beautiful valley; a nicer bag. Sometimes, 'than' is used after a comparative adjective to clearly show the difference between two things. In such cases, 'than' is used after the comparative adjective and is often followed by a phrase. Examples: The book that you gave me today is better than the book you gave me last week. Their dog is noisier than our dog. This valley is more beautiful than the one we saw yesterday. My friend's bag is nicer than my bag."
			},
			{
				"type": "note",
				"text": "Short adjectives usually add -er (tall, taller; busy, busier; pretty, prettier). Longer adjectives usually take more (beautiful, more beautiful; intelligent, more intelligent). A few are irregular: good becomes better, and bad becomes worse."
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Fill the blanks in the following sentences using the comparative form of the adjective given followed by 'than'. Write the complete sentences in your notebook. Discuss your answers with your partner. Example: Today the weather was ____ it was yesterday. (cool) Today the weather was cooler than it was yesterday.",
				"items": [
					{
						"kind": "fill",
						"q": "Our new neighbours are ____ the older ones. (good)",
						"answers": ["better than"],
						"hint": "good is irregular"
					},
					{
						"kind": "fill",
						"q": "His boss is ____ our boss. (kind)",
						"answers": ["kinder than", "more kind than"]
					},
					{
						"kind": "fill",
						"q": "Travelling by train is ____ travelling by air. (cheap)",
						"answers": ["cheaper than"]
					},
					{
						"kind": "fill",
						"q": "Your dress is ____ your friend's dress. (pretty)",
						"answers": ["prettier than"]
					},
					{
						"kind": "fill",
						"q": "Some of the students in this class are ____ the others. (intelligent)",
						"answers": ["more intelligent than"]
					},
					{
						"kind": "fill",
						"q": "This hospital is ____ the hospital near our house. (clean)",
						"answers": ["cleaner than"]
					},
					{
						"kind": "fill",
						"q": "The stars in the village seem ____ the stars in the city. (bright)",
						"answers": ["brighter than"]
					},
					{
						"kind": "fill",
						"q": "Today the patient's condition is ____ yesterday. (bad)",
						"answers": ["worse than"],
						"hint": "bad is irregular"
					},
					{
						"kind": "fill",
						"q": "The bag lying downstairs is ____ the one lying upstairs. (useful)",
						"answers": ["more useful than"]
					},
					{
						"kind": "fill",
						"q": "This week has been ____ last week. (busy)",
						"answers": ["busier than"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "The pictures are given in pairs: 1 and 2 form one pair, 3 and 4 form another pair, and so on. The adjectives above the pictures are: 1 expensive, 2 cheap, 3 big, 4 small, 5 cold, 6 warm, 7 old, 8 new, 9 sweet, 10 sour, 11 ugly, 12 beautiful, 13 young, 14 old, 15 slow, 16 fast. For each pair, write two sentences using 'than' along with the adjectives. The pictures are not printed in this text, so use any two suitable things. Follow the example: The bag is more expensive than the purse. The purse is cheaper than the bag.",
				"items": [{
					"kind": "open",
					"q": "Write two comparative sentences with 'than' for each pair: expensive/cheap (the example), big/small, cold/warm, old/new, sweet/sour, ugly/beautiful, young/old, and slow/fast.",
					"model": "Expensive/cheap: The bag is more expensive than the purse. The purse is cheaper than the bag. Big/small: The elephant is bigger than the mouse. The mouse is smaller than the elephant. Cold/warm: The ice is colder than the tea. The tea is warmer than the ice. Old/new: The brown bicycle is older than the red bicycle. The red bicycle is newer than the brown bicycle. Sweet/sour: The mango is sweeter than the lemon. The lemon is more sour than the mango. Ugly/beautiful: The broken chair is uglier than the painted chair. The painted chair is more beautiful than the broken chair. Young/old: The boy is younger than his grandfather. The grandfather is older than the boy. Slow/fast: The tortoise is slower than the horse. The horse is faster than the tortoise."
				}]
			},
			{
				"type": "h",
				"text": "Exercise 3"
			},
			{
				"type": "p",
				"text": "Look at the information given below about two families. Write two paragraphs, each paragraph describing one family by comparing it with the other, using the comparative form of the adjective followed by than. Some adjectives that can be used for comparison are given below. You can use other adjectives also."
			},
			{
				"type": "list",
				"ordered": false,
				"items": [
					"big, small",
					"more, less",
					"tall, short",
					"old, young",
					"large, small",
					"old, new",
					"dull, bright",
					"rich, poor"
				]
			},
			{
				"type": "table",
				"caption": "Timbo family and Chucky family",
				"headers": [
					"Particulars",
					"Timbo Family",
					"Chucky Family"
				],
				"rows": [
					[
						"Family size",
						"4",
						"6"
					],
					[
						"Males",
						"2",
						"3"
					],
					[
						"Females",
						"2",
						"3"
					],
					[
						"Height and age",
						"Mr Timbo: 5 ft 8 in, 30 years. Mrs Timbo: 5 ft 8 in, 27 years.",
						"Mr Chucky: 6 ft 4 in, 45 years. Mrs Chucky: 5 ft 2 in, 40 years."
					],
					[
						"Number of children",
						"2",
						"4"
					],
					[
						"House size, year built and colour",
						"2 bedrooms, 1 living room and a small kitchen. Built in 1978. Colour brown.",
						"4 bedrooms, 1 dining room, 1 living room and a very large kitchen. Built in 1995. Colour orange and green."
					],
					[
						"Family income",
						"Rs 20,000 per month",
						"Rs 80,000 per month"
					]
				]
			},
			{
				"type": "p",
				"text": "Paragraph 1. You can begin like this: The Timbo family is smaller than the Chucky family. There are ____ males in the Timbo family than in the Chucky family. There are also ____ females in the Timbo family ____ in the Chucky family."
			},
			{
				"type": "p",
				"text": "Paragraph 2. You can begin like this: The Chucky family is bigger than the Timbo family. There are ____ males in the Chucky family than in the Timbo family. There are also ____ females in the Chucky family than in the Timbo family."
			},
			{
				"type": "exercise",
				"title": "Exercise 3",
				"instruction": "Write one comparative paragraph about each family. Use the comparative form of the adjective followed by than. Use the facts in the table.",
				"items": [{
					"kind": "open",
					"q": "Paragraph 1: Describe the Timbo family by comparing it with the Chucky family.",
					"model": "The Timbo family is smaller than the Chucky family. There are fewer males in the Timbo family than in the Chucky family. There are also fewer females in the Timbo family than in the Chucky family. Mr Timbo is shorter than Mr Chucky, and he is younger than Mr Chucky. Mrs Timbo is taller than Mrs Chucky, and she is younger than Mrs Chucky. The Timbos have fewer children than the Chuckys. Their house is smaller than the Chucky house, and it is older because it was built in 1978, while the Chucky house was built in 1995. The brown Timbo house is duller than the bright orange and green Chucky house. The Timbo kitchen is smaller than the Chucky kitchen. The Timbo family is poorer than the Chucky family because they earn less money every month."
				}, {
					"kind": "open",
					"q": "Paragraph 2: Describe the Chucky family by comparing it with the Timbo family.",
					"model": "The Chucky family is bigger than the Timbo family. There are more males in the Chucky family than in the Timbo family. There are also more females in the Chucky family than in the Timbo family. Mr Chucky is taller and older than Mr Timbo. Mrs Chucky is shorter than Mrs Timbo, but she is older than Mrs Timbo. The Chuckys have more children than the Timbos. Their house is larger and newer than the Timbo house. It has more bedrooms, a dining room, and a very large kitchen. The Chucky house is brighter than the brown Timbo house. The Chucky family is richer than the Timbo family because their income is higher."
				}]
			},
			{
				"type": "h",
				"text": "Emphatic Pronouns"
			},
			{
				"type": "callout",
				"title": "Rule",
				"text": "An emphatic pronoun refers back to another noun (or pronoun) in the sentence to emphasize it. The emphatic pronouns are myself, yourself, himself, herself, itself, ourselves, yourselves, and themselves. Examples: Laila did not borrow money from her friends. She earned it herself. We have many servants in our house. But we clean our rooms ourselves."
			},
			{
				"type": "note",
				"text": "If a self/selves pronoun is the object of the verb, it is reflexive: She hurt herself. An emphatic pronoun is not needed as the object; it only adds emphasis: She herself cooked the meal, or She cooked the meal herself."
			},
			{
				"type": "exercise",
				"title": "Exercise 4",
				"instruction": "Add the correct pronouns and the emphatic pronouns in the second sentence, as shown in the example. Where there are two blanks, write the two words separated by a comma. Do this in your notebook, then discuss your answers with your partner.",
				"items": [
					{
						"kind": "fill",
						"q": "Our neighbours love gardening. ____ look after their plants ____.",
						"answers": [
							"They, themselves",
							"they, themselves",
							"They themselves"
						],
						"hint": "neighbours = they"
					},
					{
						"kind": "fill",
						"q": "The principal of our school, Mr. Samad, is a nice man. ____ guides all the teachers.",
						"answers": ["He himself", "he himself"],
						"hint": "Put the pronoun and the emphatic pronoun together."
					},
					{
						"kind": "fill",
						"q": "My friend gets good marks in all the tests. ____ does not take tuitions but studies hard ____.",
						"answers": [
							"He, himself",
							"he, himself",
							"She, herself",
							"she, herself"
						],
						"hint": "The friend may be he or she."
					},
					{
						"kind": "fill",
						"q": "Our house is always neat and clean. ____ clean it ____.",
						"answers": [
							"We, ourselves",
							"we, ourselves",
							"We ourselves"
						]
					},
					{
						"kind": "fill",
						"q": "All of you are loved by your teachers. This is because ____ are good students.",
						"answers": ["you yourselves", "you yourself"]
					},
					{
						"kind": "fill",
						"q": "Train your dog well then ____ will then take care of your house ____.",
						"answers": [
							"it, itself",
							"It, itself",
							"it itself"
						]
					},
					{
						"kind": "fill",
						"q": "No one is responsible for your actions. Only ____ are responsible for them.",
						"answers": ["you yourself", "you yourselves"]
					}
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 5",
				"instruction": "The class was going on a field trip. Everyone was very excited. They were all shouting loudly so nobody could hear each other properly. Fill the gaps with the correct pronouns or emphatic pronouns. Work in groups, with each student taking one role. Do the exercise orally first and then write the complete dialogue. After you have written it, role-play it.",
				"items": [
					{
						"kind": "fill",
						"q": "Fatima: I spoke to her last night and ____ told me that she was coming.",
						"answers": ["she"],
						"hint": "Sabiha"
					},
					{
						"kind": "fill",
						"q": "Amna: Can ____ try and contact her ____ to see why she is late?",
						"answers": [
							"you, yourself",
							"You, yourself",
							"I, myself"
						]
					},
					{
						"kind": "fill",
						"q": "Shirin: Remember, the teacher told us that ____ will be responsible for all our things?",
						"answers": ["we ourselves", "we"]
					},
					{
						"kind": "fill",
						"q": "Sabah: Yes, I know. ____ typed up all the instructions of our teacher.",
						"answers": ["I myself", "I"]
					},
					{
						"kind": "fill",
						"q": "Fatima: Mr. Zameer has arranged for the food. ____ will pick it up from the cook and bring it here.",
						"answers": ["He himself", "He"]
					},
					{
						"kind": "fill",
						"q": "Amna: Can all of ____ please check if your bags have been put in the van?",
						"answers": ["you"]
					},
					{
						"kind": "fill",
						"q": "Shirin: Those of you who will not check ____ will be responsible if their bags are left behind.",
						"answers": ["yourselves", "themselves"]
					},
					{
						"kind": "fill",
						"q": "Fatima: Hurrah! My bag is a genius. ____ went inside the van.",
						"answers": ["It itself", "It"]
					}
				]
			}
		]
	},
	{
		"id": "7.4",
		"code": "7.4",
		"title": "Writing",
		"subtitle": "An article for the school magazine",
		"kind": "writing",
		"blocks": [
			{
				"type": "p",
				"text": "Work in groups of three and write an article for your school magazine. Provide a title. Describe your views on how women play an important role in the development of a society and nation. You may use the mind map that you developed in section 5.1, exercise 6."
			},
			{
				"type": "note",
				"text": "The mind map is Exercise 6 of lesson 7.1. The book calls it section 5.1 by mistake."
			},
			{
				"type": "p",
				"text": "Here are some points to remember:"
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Write the topic.",
					"Do the brainstorming.",
					"Develop a mind map.",
					"Select the points that you want to include in your article.",
					"Decide the order in which you will write your points in the article.",
					"Write paragraph number one. Remember, this is your introductory paragraph; it introduces the topic.",
					"Now write the body paragraphs. There should be at least two paragraphs. You can write more. These paragraphs should explain your viewpoint.",
					"Make sure that each body paragraph has a topic sentence and the supporting details.",
					"Conclude your article with a concluding paragraph. Your paragraph should begin with a concluding word or phrase, summarise the key points in your article and end on a strong note, giving an idea, suggestion or recommendation."
				]
			},
			{
				"type": "p",
				"text": "After you have written down the article, all of you must proofread and edit it. Check for the following:"
			},
			{
				"type": "list",
				"ordered": false,
				"items": [
					"a) The introductory paragraph properly introduces the topic.",
					"b) The body paragraphs have clear topic sentences and all the other sentences are related to the respective topic sentence.",
					"c) The concluding paragraph begins with a closing word or phrase, gives a summary of points and ends on a strong note.",
					"d) Correct grammar structures and tenses.",
					"e) Correct punctuation and capitalization."
				]
			},
			{
				"type": "exercise",
				"title": "Article",
				"instruction": "Write an article of about four paragraphs for the school magazine on the role of women in the development of a society and a nation. Give it a title.",
				"items": [{
					"kind": "open",
					"q": "Write the article. Include an introductory paragraph, at least two body paragraphs, and a concluding paragraph that begins with a closing word or phrase.",
					"model": "Women: Partners in Building the Nation\n\nWomen play many roles at home, in the fields, and at work. No family or nation can really progress unless women take part in economic activity.\n\nAt home, women care for children and do several chores at the same time. Many also earn by weaving cloth or doing embroidery that is sold in the city. In the fields they pick cotton, cut crops, and sell milk and eggs. This work brings money to the family.\n\nOutside the home, women work as teachers, doctors, and nurses, and in banks, offices, stores, and factories. When they earn, they usually spend more on their children's health and education. That spending improves family life and helps the country develop.\n\nTherefore, girls should be encouraged to study and to choose useful professions. Educated women become more productive members of society and play a major role in nation-building."
				}]
			}
		]
	},
	{
		"id": "7.5",
		"code": "7.5",
		"title": "Study Skills",
		"subtitle": "Abbreviations",
		"kind": "study",
		"blocks": [
			{
				"type": "p",
				"text": "Below is a list of some commonly used abbreviations. In pairs, study these abbreviations and see how many of these you know."
			},
			{
				"type": "table",
				"caption": "Common abbreviations",
				"headers": [
					"S. No.",
					"Abbreviation",
					"Full form / explanation"
				],
				"rows": [
					[
						"1",
						"ASAP",
						"As Soon as Possible"
					],
					[
						"2",
						"FYI",
						"For Your Information"
					],
					[
						"3",
						"FAQ",
						"Frequently Asked Questions"
					],
					[
						"4",
						"ATM",
						"Automated Teller Machine"
					],
					[
						"5",
						"PS",
						"Post Script, usually written at the end of letters"
					],
					[
						"6",
						"DIY",
						"Do it Yourself"
					],
					[
						"7",
						"ID",
						"Identification"
					],
					[
						"8",
						"CNIC",
						"Computerised National Identity Card"
					],
					[
						"9",
						"IQ",
						"Intelligence Quotient (as measured by intelligence tests)"
					],
					[
						"10",
						"PC",
						"Personal Computer"
					],
					[
						"11",
						"PR",
						"Public Relations"
					],
					[
						"12",
						"SOS",
						"Save Our Souls (written to get help in an emergency)"
					],
					[
						"13",
						"AD",
						"Latin word Anno Domini (past the year 0, like 2016 AD)"
					],
					[
						"14",
						"CE",
						"Common Era (means the same as AD, 2016 CE). Used in modern English"
					],
					[
						"15",
						"BC",
						"Before Christ (before the year 0, like 3000 BC)"
					],
					[
						"16",
						"BCE",
						"Before Common Era (means the same as BC, 3000 BCE). Used in modern English"
					],
					[
						"17",
						"HR",
						"Human Resources"
					]
				]
			},
			{
				"type": "exercise",
				"title": "Exercise 1",
				"instruction": "Study the table with a partner. Match every abbreviation with its full form.",
				"items": [{
					"kind": "match",
					"pairs": [
						{
							"left": "ASAP",
							"right": "As Soon as Possible"
						},
						{
							"left": "FYI",
							"right": "For Your Information"
						},
						{
							"left": "FAQ",
							"right": "Frequently Asked Questions"
						},
						{
							"left": "ATM",
							"right": "Automated Teller Machine"
						},
						{
							"left": "PS",
							"right": "Post Script, usually written at the end of letters"
						},
						{
							"left": "DIY",
							"right": "Do it Yourself"
						},
						{
							"left": "ID",
							"right": "Identification"
						},
						{
							"left": "CNIC",
							"right": "Computerised National Identity Card"
						},
						{
							"left": "IQ",
							"right": "Intelligence Quotient"
						},
						{
							"left": "PC",
							"right": "Personal Computer"
						},
						{
							"left": "PR",
							"right": "Public Relations"
						},
						{
							"left": "SOS",
							"right": "Save Our Souls"
						},
						{
							"left": "AD",
							"right": "Anno Domini"
						},
						{
							"left": "CE",
							"right": "Common Era"
						},
						{
							"left": "BC",
							"right": "Before Christ"
						},
						{
							"left": "BCE",
							"right": "Before Common Era"
						},
						{
							"left": "HR",
							"right": "Human Resources"
						}
					]
				}]
			},
			{
				"type": "exercise",
				"title": "Exercise 2",
				"instruction": "Use the table to write the full form of the abbreviation in each sentence. After you have completed the exercise, compare your answers with your partner.",
				"items": [
					{
						"kind": "fill",
						"q": "What was your score on the IQ test? IQ means ____.",
						"answers": ["Intelligence Quotient", "intelligence quotient"]
					},
					{
						"kind": "fill",
						"q": "The brochure that we got in class today answers all the FAQs. FAQs means ____.",
						"answers": ["Frequently Asked Questions", "frequently asked questions"]
					},
					{
						"kind": "fill",
						"q": "The HR department asked for detailed information about all the employees. HR means ____.",
						"answers": ["Human Resources", "human resources"]
					},
					{
						"kind": "fill",
						"q": "When the ship began to sink it sent out an SOS signal. SOS means ____.",
						"answers": ["Save Our Souls", "save our souls"]
					},
					{
						"kind": "fill",
						"q": "My friend asked his father to send the money ASAP as he wanted to pay his fees. ASAP means ____.",
						"answers": ["As Soon as Possible", "as soon as possible"]
					},
					{
						"kind": "fill",
						"q": "This PC has a problem; I cannot access my emails on it. PC means ____.",
						"answers": ["Personal Computer", "personal computer"]
					},
					{
						"kind": "fill",
						"q": "The principal asked all students to bring a copy of their father's CNIC. CNIC means ____.",
						"answers": [
							"Computerised National Identity Card",
							"computerised national identity card",
							"Computerized National Identity Card"
						]
					},
					{
						"kind": "fill",
						"q": "My uncle brought a DIY house painting kit for me from London. DIY means ____.",
						"answers": [
							"Do it Yourself",
							"Do It Yourself",
							"do it yourself"
						]
					},
					{
						"kind": "fill",
						"q": "People often write FYI on papers and in emails when they want to share some information. FYI means ____.",
						"answers": ["For Your Information", "for your information"]
					},
					{
						"kind": "fill",
						"q": "When they need money they use their ATM card to get it. ATM means ____.",
						"answers": ["Automated Teller Machine", "automated teller machine"]
					}
				]
			},
			{
				"type": "h",
				"text": "Exercise 3"
			},
			{
				"type": "p",
				"text": "Play a game with abbreviations. But, before playing the game, all the students should memorise all the abbreviations given above."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Once the students have memorised all the words, the teacher divides the class into two groups.",
					"Each group is numbered from one to fifteen, twenty, or twenty-two, depending on the number of students in the class.",
					"The teacher writes these numbers on small chits and folds them. The teacher also writes all the abbreviations on small chits, folds them, and keeps them separately.",
					"The teacher draws two columns on the blackboard and asks each group to suggest a name, selecting any one national hero. That name is written at the top of the group's column.",
					"The teacher picks up a number from the number chits, and the students with that number from both groups come out.",
					"The teacher then picks an abbreviation chit and asks one student to say the full form. If the student answers correctly, the team gets a point. If not, the student from the other team gets a chance to answer and win an extra point.",
					"If the first student answers correctly, the teacher picks another abbreviation chit and asks the second student. If that student does not answer correctly, the first student gets a chance to win an extra point for his or her team.",
					"The game continues until all the abbreviation chits are finished. The team with the most points wins."
				]
			}
		]
	},
	{
		"id": "7.6",
		"code": "7.6",
		"title": "Fun",
		"subtitle": "Professions word search",
		"kind": "fun",
		"blocks": [
			{
				"type": "p",
				"text": "Work individually and see how many professionals from the list below you can find in the puzzle. The words are arranged either right to left, left to right (backwards), up to down, down to up, and diagonally forward and backwards."
			},
			{
				"type": "note",
				"text": "The unit opener calls this a crossword, but the page is a word-search of professions. The letter grid is a picture in the book and is not printed here, so use the list of professions below."
			},
			{
				"type": "words",
				"intro": "Find these professionals in the word-search.",
				"words": [
					"electrician",
					"pilot",
					"teacher",
					"butcher",
					"lawyer",
					"doctor",
					"nurse",
					"tailor",
					"mechanic",
					"firefighter",
					"singer",
					"artist",
					"actor",
					"busdriver",
					"writer",
					"chef",
					"dyer",
					"welder",
					"carpenter",
					"farmer",
					"gardener",
					"weaver",
					"potter",
					"poet",
					"baker"
				]
			},
			{
				"type": "h",
				"text": "Act it out"
			},
			{
				"type": "p",
				"text": "After you have found the professions, play this game."
			},
			{
				"type": "list",
				"ordered": true,
				"items": [
					"Divide the class into two teams.",
					"Each team gets a turn to select a profession from the list and act it out without speaking.",
					"If the other team guesses the profession correctly, that team gets a point.",
					"Keep the score on the blackboard.",
					"The team that scores the most points is the winner."
				]
			}
		]
	}
];
var vocab = [
	{
		"word": "hovering",
		"pos": "verb",
		"meaning": "Hovering here means standing or moving about near someone without any clear purpose.",
		"urdu": "بے مقصد کسی کے آس پاس گھومنا",
		"synonyms": [
			"lingering",
			"hanging around",
			"loitering"
		],
		"antonyms": [
			"leaving",
			"departing",
			"staying away"
		],
		"sentences": ["Noman is hovering around his father and asking questions about the picture."]
	},
	{
		"word": "seminar",
		"pos": "noun",
		"meaning": "A seminar is a large meeting where people from different places present reports and exchange ideas.",
		"urdu": "سیمینار؛ خیالات کے تبادلے کا بڑا اجلاس",
		"synonyms": [
			"conference",
			"symposium",
			"meeting"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["Arshad will present a report at a seminar in Hyderabad on the roles women play."]
	},
	{
		"word": "chores",
		"pos": "noun",
		"meaning": "Chores are the ordinary everyday jobs done at home.",
		"urdu": "روزمرہ کے گھریلو کام",
		"synonyms": [
			"tasks",
			"housework",
			"duties"
		],
		"antonyms": [
			"leisure",
			"rest",
			"play"
		],
		"sentences": ["The picture shows the different household chores the woman is doing at one time."]
	},
	{
		"word": "simultaneously",
		"pos": "adverb",
		"meaning": "Simultaneously means at the same time.",
		"urdu": "بیک وقت؛ ایک ہی وقت میں",
		"synonyms": [
			"concurrently",
			"together",
			"at once"
		],
		"antonyms": [
			"separately",
			"one by one",
			"successively"
		],
		"sentences": ["Women often do many tasks simultaneously, which is why the picture gives the woman many hands."]
	},
	{
		"word": "multi-tasking",
		"pos": "noun",
		"meaning": "Multi-tasking is doing two or more jobs at the same time.",
		"urdu": "ایک ساتھ کئی کام کرنا",
		"synonyms": [
			"juggling tasks",
			"doing several things at once",
			"multitasking"
		],
		"antonyms": ["single-tasking", "doing one thing at a time"],
		"sentences": ["Arshad explains that the many hands in the picture are a sign of multi-tasking."]
	},
	{
		"word": "economic activity",
		"pos": "noun",
		"meaning": "Economic activity is work done in order to earn money.",
		"urdu": "معاشی سرگرمی؛ پیسے کمانے کا کام",
		"synonyms": [
			"earning",
			"paid work",
			"income-generating work"
		],
		"antonyms": ["idleness", "unpaid leisure"],
		"sentences": ["No nation can progress unless women take part in economic activity."]
	},
	{
		"word": "weave",
		"pos": "verb",
		"meaning": "To weave is to make cloth by crossing threads, often on a loom.",
		"urdu": "کپڑا بُننا",
		"synonyms": [
			"interweave",
			"plait",
			"make cloth"
		],
		"antonyms": [
			"unravel",
			"unpick",
			"undo"
		],
		"sentences": ["Many women in the region hand weave cloth that is later sold in the city."]
	},
	{
		"word": "pastime",
		"pos": "noun",
		"meaning": "A pastime is something a person does for enjoyment in free time.",
		"urdu": "مشغلہ؛ تفریح کے لیے کیا جانے والا کام",
		"synonyms": [
			"hobby",
			"recreation",
			"amusement"
		],
		"antonyms": [
			"chore",
			"duty",
			"labour"
		],
		"sentences": ["Noman thought embroidery was only his grandmother's favourite pastime."]
	},
	{
		"word": "embroidery",
		"pos": "noun",
		"meaning": "Embroidery is decoration sewn onto cloth with a needle and thread.",
		"urdu": "کڑھائی",
		"synonyms": [
			"needlework",
			"stitching",
			"ornamental sewing"
		],
		"antonyms": ["plain cloth", "undecorated fabric"],
		"sentences": ["Noman's grandmother likes to do embroidery and also sells the work she finishes."]
	},
	{
		"word": "agricultural",
		"pos": "adjective",
		"meaning": "Agricultural describes work or workers connected with farming and crops.",
		"urdu": "زرعی؛ کھیتی باڑی سے متعلق",
		"synonyms": [
			"farming",
			"agrarian",
			"rural"
		],
		"antonyms": [
			"industrial",
			"urban",
			"non-farming"
		],
		"sentences": ["Women who pick cotton and cut crops are agricultural workers."]
	},
	{
		"word": "indirectly",
		"pos": "adverb",
		"meaning": "Indirectly means not in a direct way; here, the women's work brings money to the family even when they are not paid a wage.",
		"urdu": "بالواسطہ؛ سیدھے طریقے سے نہیں",
		"synonyms": [
			"not directly",
			"through others",
			"secondarily"
		],
		"antonyms": [
			"directly",
			"straight",
			"openly"
		],
		"sentences": ["Many women working in the fields indirectly earn money for the family."]
	},
	{
		"word": "pluck",
		"pos": "verb",
		"meaning": "To pluck is to pick flowers or fruit by pulling them off the plant.",
		"urdu": "توڑنا؛ چننا",
		"synonyms": [
			"pick",
			"gather",
			"pull off"
		],
		"antonyms": [
			"plant",
			"sow",
			"leave"
		],
		"sentences": ["Some women pluck roses while others pick cotton in the fields."]
	},
	{
		"word": "contribute",
		"pos": "verb",
		"meaning": "To contribute is to give one's share of work or help towards a result.",
		"urdu": "حصہ ڈالنا",
		"synonyms": [
			"give",
			"add",
			"take part"
		],
		"antonyms": [
			"withhold",
			"refuse",
			"take away"
		],
		"sentences": ["Noman wants to learn how women contribute to nation-building."]
	},
	{
		"word": "productive",
		"pos": "adjective",
		"meaning": "A productive person does useful work that helps the family or the country move forward.",
		"urdu": "کارآمد؛ مفید کام کرنے والا",
		"synonyms": [
			"useful",
			"efficient",
			"fruitful"
		],
		"antonyms": [
			"unproductive",
			"useless",
			"idle"
		],
		"sentences": ["Education helps women become more productive members of society."]
	},
	{
		"word": "acquire",
		"pos": "verb",
		"meaning": "To acquire something, such as education, is to gain it through effort.",
		"urdu": "حاصل کرنا",
		"synonyms": [
			"gain",
			"obtain",
			"get"
		],
		"antonyms": [
			"lose",
			"give up",
			"forfeit"
		],
		"sentences": ["Arshad says women must be encouraged to acquire education."]
	},
	{
		"word": "nation-building",
		"pos": "noun",
		"meaning": "Nation-building is the work of developing and strengthening a country.",
		"urdu": "قوم کی تعمیر",
		"synonyms": [
			"national development",
			"state-building",
			"country-building"
		],
		"antonyms": ["national decline", "destruction"],
		"sentences": ["Women who work and educate their children take part in nation-building."]
	},
	{
		"word": "organisers",
		"pos": "noun",
		"meaning": "Organisers are the people who plan and run an event such as a seminar.",
		"urdu": "منتظمین",
		"synonyms": [
			"planners",
			"coordinators",
			"hosts"
		],
		"antonyms": [
			"guests",
			"spectators",
			"audience"
		],
		"sentences": ["Arshad must ask the organisers before he can promise to take Noman to the seminar."]
	},
	{
		"word": "development sector",
		"pos": "noun",
		"meaning": "The development sector is the field of work that studies and supports progress and improvement in society.",
		"urdu": "ترقی کا شعبہ",
		"synonyms": [
			"development field",
			"social-development work",
			"progress sector"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["Arshad Sikander works in the development sector and is writing a report on women's roles."]
	},
	{
		"word": "present",
		"pos": "verb",
		"meaning": "To present a report is to share information and ideas formally with other people.",
		"urdu": "پیش کرنا",
		"synonyms": [
			"deliver",
			"show",
			"put forward"
		],
		"antonyms": [
			"withhold",
			"hide",
			"conceal"
		],
		"sentences": ["Arshad has to present a report on women's roles at the seminar in Hyderabad."]
	},
	{
		"word": "conference",
		"pos": "noun",
		"meaning": "A conference is a formal meeting for exchanging ideas; this word is in the exercise list but does not appear in the reading text.",
		"urdu": "کانفرنس؛ بڑا رسمی اجلاس",
		"synonyms": [
			"meeting",
			"convention",
			"summit"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["A conference, like the seminar in the story, is a gathering where experts discuss their work."]
	},
	{
		"word": "discussion",
		"pos": "noun",
		"meaning": "A discussion is a talk in which people exchange ideas; the word is in the vocabulary list but not in the reading text.",
		"urdu": "بحث؛ تبادلۂ خیال",
		"synonyms": [
			"debate",
			"conversation",
			"talk"
		],
		"antonyms": ["silence", "monologue"],
		"sentences": ["After their discussion, Arshad asked Noman to go away and think while he worked on his report."]
	},
	{
		"word": "community",
		"pos": "noun",
		"meaning": "A community is a group of people who live or work together; the word is listed in the exercise but is not used in the reading text.",
		"urdu": "برادری؛ کمیونٹی",
		"synonyms": [
			"society",
			"neighbourhood",
			"group"
		],
		"antonyms": ["individual", "isolation"],
		"sentences": ["Women's work supports not only one family but the whole community."]
	},
	{
		"word": "issue",
		"pos": "noun",
		"meaning": "An issue is a subject or problem people need to think about; it is one of the extra words not used in the reading text.",
		"urdu": "مسئلہ؛ موضوع",
		"synonyms": [
			"problem",
			"matter",
			"question"
		],
		"antonyms": [
			"solution",
			"answer",
			"resolution"
		],
		"sentences": ["The seminar will take up the issue of the many roles that women play."]
	},
	{
		"word": "experts",
		"pos": "noun",
		"meaning": "Experts are people who have special knowledge of a subject.",
		"urdu": "ماہرین",
		"synonyms": [
			"specialists",
			"professionals",
			"authorities"
		],
		"antonyms": [
			"beginners",
			"amateurs",
			"novices"
		],
		"sentences": ["Experts from different countries will describe the work that women do in their countries."]
	},
	{
		"word": "province",
		"pos": "noun",
		"meaning": "A province is a large official region of a country.",
		"urdu": "صوبہ",
		"synonyms": [
			"region",
			"state",
			"territory"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["Arshad has been touring the province to gather information for his report."]
	},
	{
		"word": "participate",
		"pos": "verb",
		"meaning": "To participate is to take part in an activity.",
		"urdu": "حصہ لینا؛ شرکت کرنا",
		"synonyms": [
			"join",
			"take part",
			"engage"
		],
		"antonyms": [
			"withdraw",
			"abstain",
			"avoid"
		],
		"sentences": ["Noman realises that women participate in a great deal of economic activity."]
	},
	{
		"word": "loom",
		"pos": "noun",
		"meaning": "A loom is a frame or machine used for weaving cloth.",
		"urdu": "کپڑا بُننے کا کھڈا",
		"synonyms": [
			"weaving frame",
			"handloom",
			"weaving machine"
		],
		"antonyms": ["no direct antonym"],
		"sentences": ["Arshad points to the weaving loom and explains how Noman's mother weaves cloth."]
	},
	{
		"word": "progress",
		"pos": "noun",
		"meaning": "Progress is movement forward towards a better and more developed condition.",
		"urdu": "ترقی",
		"synonyms": [
			"development",
			"advancement",
			"improvement"
		],
		"antonyms": [
			"decline",
			"regression",
			"stagnation"
		],
		"sentences": ["A country cannot make real progress unless women actively contribute."]
	},
	{
		"word": "encourage",
		"pos": "verb",
		"meaning": "To encourage someone is to give support and confidence so that the person will do something.",
		"urdu": "حوصلہ افزائی کرنا",
		"synonyms": [
			"urge",
			"support",
			"inspire"
		],
		"antonyms": [
			"discourage",
			"dishearten",
			"deter"
		],
		"sentences": ["Arshad says families must encourage girls to study and adopt professions."]
	},
	{
		"word": "realize",
		"pos": "verb",
		"meaning": "To realize is to begin to understand something clearly.",
		"urdu": "سمجھ جانا؛ احساس ہونا",
		"synonyms": [
			"understand",
			"recognise",
			"grasp"
		],
		"antonyms": [
			"misunderstand",
			"ignore",
			"overlook"
		],
		"sentences": ["Governments have begun to realize that a country needs women's contribution."]
	},
	{
		"word": "household",
		"pos": "adjective",
		"meaning": "Household describes things that belong to the home and the daily life of a family.",
		"urdu": "گھریلو",
		"synonyms": [
			"domestic",
			"home",
			"family"
		],
		"antonyms": [
			"public",
			"outdoor",
			"official"
		],
		"sentences": ["Taking care of the house includes many different household chores."]
	},
	{
		"word": "customers",
		"pos": "noun",
		"meaning": "Customers are people who buy goods or services.",
		"urdu": "گاہک",
		"synonyms": [
			"buyers",
			"purchasers",
			"clients"
		],
		"antonyms": [
			"sellers",
			"vendors",
			"suppliers"
		],
		"sentences": ["Cloth that women weave is made into clothes and sold to customers in the city."]
	}
];
var unit7_default = {
	id: "u7",
	number: 7,
	title,
	learn,
	lessons,
	vocab
};
var modules = /* #__PURE__ */ Object.assign({
	"./units/unit1.json": unit1_exports,
	"./units/unit2.json": unit2_exports,
	"./units/unit3.json": unit3_exports,
	"./units/unit4.json": unit4_exports,
	"./units/unit5.json": unit5_exports,
	"./units/unit6.json": unit6_exports,
	"./units/unit7.json": unit7_exports
});
function clean(raw) {
	return {
		id: raw.id,
		number: raw.number,
		title: raw.title,
		learn: raw.learn ?? [],
		lessons: (raw.lessons ?? []).map((lesson) => ({
			...lesson,
			blocks: lesson.blocks ?? []
		})),
		vocab: (raw.vocab ?? []).filter((v) => v && v.word).map((v) => ({
			word: v.word,
			pos: v.pos,
			meaning: v.meaning ?? "",
			urdu: v.urdu ?? "",
			synonyms: v.synonyms ?? [],
			antonyms: v.antonyms ?? [],
			sentences: v.sentences ?? []
		}))
	};
}
var units = Object.values(modules).map((m) => clean(m.default)).filter((u) => u && u.number && u.title).sort((a, b) => a.number - b.number);
function allVocab() {
	const rows = [];
	for (const unit of units) for (const vocab of unit.vocab) rows.push({
		unit,
		vocab
	});
	return rows;
}
function overlaps(ranges, i, j) {
	return ranges.some((r) => i < r.j && j > r.i);
}
function segmentText(text, vocab) {
	const ranges = [];
	const lower = text.toLowerCase();
	const sorted = [...vocab].sort((a, b) => b.word.length - a.word.length);
	for (const entry of sorted) {
		const needle = entry.word.toLowerCase();
		if (needle.length < 2) continue;
		let from = 0;
		while (from < lower.length) {
			const i = lower.indexOf(needle, from);
			if (i < 0) break;
			const j = i + needle.length;
			const beforeOk = i === 0 || !/[A-Za-z0-9]/.test(text[i - 1] ?? "");
			const afterOk = j >= text.length || !/[A-Za-z0-9]/.test(text[j] ?? "");
			if (beforeOk && afterOk && !overlaps(ranges, i, j)) ranges.push({
				i,
				j,
				vocab: entry
			});
			from = i + Math.max(1, needle.length);
		}
	}
	ranges.sort((a, b) => a.i - b.i);
	const out = [];
	let cursor = 0;
	for (const range of ranges) {
		if (range.i > cursor) out.push({
			type: "text",
			text: text.slice(cursor, range.i)
		});
		out.push({
			type: "word",
			text: text.slice(range.i, range.j),
			vocab: range.vocab
		});
		cursor = range.j;
	}
	if (cursor < text.length) out.push({
		type: "text",
		text: text.slice(cursor)
	});
	return out;
}
function highlight(text, query) {
	const q = query.trim();
	if (q.length < 2) return text;
	const lower = text.toLowerCase();
	const needle = q.toLowerCase();
	const bits = [];
	let from = 0;
	while (from < text.length) {
		const i = lower.indexOf(needle, from);
		if (i < 0) {
			bits.push({
				text: text.slice(from),
				hit: false
			});
			break;
		}
		if (i > from) bits.push({
			text: text.slice(from, i),
			hit: false
		});
		bits.push({
			text: text.slice(i, i + needle.length),
			hit: true
		});
		from = i + needle.length;
	}
	return bits.map((bit, idx) => bit.hit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mark", {
		className: "bg-mark text-ink rounded-sm px-0.5",
		children: bit.text
	}, idx) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: bit.text }, idx));
}
function RichText({ text, vocab, query, onWord, className }) {
	const parts = segmentText(text, vocab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className,
		children: parts.map((part, i) => part.type === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: highlight(part.text, query) }, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "text-banner underline decoration-banner/40 decoration-1 underline-offset-[3px] hover:decoration-banner focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-banner",
			onClick: () => onWord(part.vocab),
			"aria-haspopup": "dialog",
			children: highlight(part.text, query)
		}, i))
	});
}
function norm(value) {
	return value.toLowerCase().replace(/[“”"‘’'.?,!;:]/g, "").replace(/\s+/g, " ").trim();
}
function fillMatches(input, answers) {
	const n = norm(input);
	if (!n) return false;
	return answers.some((answer) => {
		const an = norm(answer);
		if (!an) return false;
		if (n === an) return true;
		if (an.length >= 4 && n.includes(an)) return true;
		if (n.length >= 8 && an.includes(n)) return true;
		return false;
	});
}
function shuffle(items, seed) {
	const copy = [...items];
	let h = 2166136261;
	for (const ch of seed) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
	for (let i = copy.length - 1; i > 0; i--) {
		h = Math.imul(h ^ h >>> 16, 2246822519);
		const j = Math.abs(h) % (i + 1);
		const tmp = copy[i];
		copy[i] = copy[j];
		copy[j] = tmp;
	}
	return copy;
}
function ExerciseBlock({ title, instruction, items, seed }) {
	const [resetKey, setResetKey] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 rounded-card border border-line bg-card px-4 py-4 sm:px-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "font-ui text-sm font-bold tracking-wide text-maroon uppercase",
				children: title
			}), instruction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-body mt-1 text-[1.02rem] leading-relaxed text-ink",
				children: instruction
			}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setResetKey((n) => n + 1),
				className: "font-ui inline-flex min-h-11 shrink-0 items-center gap-1 rounded-full px-3 text-sm text-muted hover:bg-chip",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), "Reset"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex flex-col gap-4",
			children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "border-t border-line pt-3 first:border-t-0 first:pt-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionView, {
					item,
					index,
					seed: `${seed}-${index}`
				})
			}, index))
		}, resetKey)]
	});
}
function QuestionView({ item, index, seed }) {
	if (item.kind === "mcq") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mcq, {
		item,
		index
	});
	if (item.kind === "tf") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tf, {
		item,
		index
	});
	if (item.kind === "fill") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fill, {
		item,
		index
	});
	if (item.kind === "match") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, {
		item,
		seed
	});
	if (item.kind === "classify") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Classify, { item });
	if (item.kind === "open") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Open, {
		item,
		index
	});
	return null;
}
function Mcq({ item, index }) {
	const [picked, setPicked] = (0, import_react.useState)(null);
	const letters = "abcdefghijklmnopqrstuvwxyz";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "font-body text-[1.02rem] leading-relaxed",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-ui mr-2 text-sm font-semibold text-muted",
			children: [index + 1, "."]
		}), item.q]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 grid gap-2",
		children: item.options.map((option, optionIndex) => {
			const chosen = picked === optionIndex;
			const show = picked !== null;
			const correct = optionIndex === item.answer;
			let tone = "border-line bg-paper text-ink hover:border-banner";
			if (show && correct) tone = "border-ok bg-ok-soft text-ok";
			else if (show && chosen && !correct) tone = "border-bad bg-bad-soft text-bad";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: picked !== null,
				onClick: () => setPicked(optionIndex),
				className: `font-ui min-h-11 rounded-xl border px-3 py-2 text-left text-[0.98rem] ${tone}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mr-2 font-semibold",
					children: [letters[optionIndex] ?? optionIndex + 1, "."]
				}), option]
			}, option);
		})
	})] });
}
function Tf({ item, index }) {
	const [picked, setPicked] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "font-body text-[1.02rem] leading-relaxed",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-ui mr-2 text-sm font-semibold text-muted",
			children: [index + 1, "."]
		}), item.q]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 flex gap-2",
		children: [true, false].map((value) => {
			const label = value ? "True" : "False";
			const chosen = picked === value;
			const show = picked !== null;
			const correct = value === item.answer;
			let tone = "border-line bg-paper text-ink hover:border-banner";
			if (show && correct) tone = "border-ok bg-ok-soft text-ok";
			else if (show && chosen && !correct) tone = "border-bad bg-bad-soft text-bad";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: picked !== null,
				onClick: () => setPicked(value),
				className: `font-ui min-h-11 min-w-24 rounded-full border px-4 text-sm font-semibold ${tone}`,
				children: label
			}, label);
		})
	})] });
}
function Fill({ item, index }) {
	const [value, setValue] = (0, import_react.useState)("");
	const [verdict, setVerdict] = (0, import_react.useState)("idle");
	const good = verdict === "ok";
	const bad = verdict === "bad";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "font-body block text-[1.02rem] leading-relaxed",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-ui mr-2 text-sm font-semibold text-muted",
				children: [index + 1, "."]
			}), item.q]
		}),
		item.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-ui mt-1 text-sm text-muted",
			children: ["Hint: ", item.hint]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex flex-col gap-2 sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value,
				onChange: (event) => {
					setValue(event.target.value);
					setVerdict("idle");
				},
				className: "font-ui min-h-11 w-full rounded-xl border bg-paper px-3 text-ink outline-none " + (good ? "border-ok bg-ok-soft" : bad ? "border-bad bg-bad-soft" : "border-line"),
				placeholder: "Type your answer"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setVerdict(fillMatches(value, item.answers) ? "ok" : "bad"),
				className: "font-ui inline-flex min-h-11 items-center justify-center gap-1 rounded-full bg-banner px-4 text-sm font-semibold text-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Check"]
			})]
		}),
		bad ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-ui mt-2 text-sm text-bad",
			children: ["Not quite. A correct answer: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold",
				children: item.answers[0]
			})]
		}) : null,
		good ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-ui mt-2 text-sm font-semibold text-ok",
			children: "Correct."
		}) : null
	] });
}
function Match({ item, seed }) {
	const options = (0, import_react.useMemo)(() => shuffle(item.pairs.map((pair) => pair.right), seed), [item.pairs, seed]);
	const [picks, setPicks] = (0, import_react.useState)({});
	const [checked, setChecked] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		item.q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-body mb-2 text-[1.02rem]",
			children: item.q
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-2",
			children: item.pairs.map((pair, index) => {
				const pick = picks[index] ?? "";
				const show = checked && pick !== "";
				const correct = pick === pair.right;
				let border = "border-line";
				if (show && correct) border = "border-ok bg-ok-soft";
				else if (show && !correct) border = "border-bad bg-bad-soft";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 sm:grid-cols-[1fr_1.2fr] sm:items-center sm:gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-ui text-[0.98rem] font-semibold text-ink",
						children: pair.left
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: pick,
						onChange: (event) => {
							setPicks((prev) => ({
								...prev,
								[index]: event.target.value
							}));
							setChecked(false);
						},
						className: `font-ui min-h-11 rounded-xl border bg-paper px-2 text-sm text-ink ${border}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Choose a meaning"
						}), options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: option,
							children: option
						}, option))]
					})]
				}, pair.left);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setChecked(true),
			className: "font-ui mt-3 inline-flex min-h-11 items-center gap-1 rounded-full bg-banner px-4 text-sm font-semibold text-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Check matches"]
		}),
		checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-ui mt-2 text-sm text-muted",
			children: [
				item.pairs.filter((pair, index) => picks[index] === pair.right).length,
				" of ",
				item.pairs.length,
				" correct. Green is right, red is wrong."
			]
		}) : null
	] });
}
function Classify({ item }) {
	const [picks, setPicks] = (0, import_react.useState)({});
	const [checked, setChecked] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-body text-[1.02rem] leading-relaxed",
			children: item.q
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-col gap-3",
			children: item.cards.map((card, index) => {
				const pick = picks[index];
				const show = checked && pick !== void 0 && pick !== null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-line bg-paper p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-body text-[1.02rem]",
						children: card.text
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: item.buckets.map((bucket, bucketIndex) => {
							const chosen = pick === bucketIndex;
							const correct = bucketIndex === card.bucket;
							let tone = "border-line bg-card text-ink";
							if (show && correct) tone = "border-ok bg-ok-soft text-ok";
							else if (show && chosen && !correct) tone = "border-bad bg-bad-soft text-bad";
							else if (chosen) tone = "border-banner bg-banner-soft text-banner";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setPicks((prev) => ({
										...prev,
										[index]: bucketIndex
									}));
									setChecked(false);
								},
								className: `font-ui min-h-11 rounded-full border px-3 text-sm font-semibold ${tone}`,
								children: bucket
							}, bucket);
						})
					})]
				}, card.text);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setChecked(true),
			className: "font-ui mt-3 inline-flex min-h-11 items-center gap-1 rounded-full bg-banner px-4 text-sm font-semibold text-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Check"]
		})
	] });
}
function Open({ item, index }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "font-body text-[1.02rem] leading-relaxed",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-ui mr-2 text-sm font-semibold text-muted",
			children: [index + 1, "."]
		}), item.q]
	}), item.model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => setOpen((value) => !value),
		className: "font-ui mt-2 inline-flex min-h-11 items-center rounded-full border border-line px-3 text-sm font-semibold text-banner",
		children: open ? "Hide model answer" : "Show model answer"
	}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-body mt-2 rounded-xl bg-banner-soft px-3 py-3 text-[1.02rem] leading-relaxed whitespace-pre-wrap text-ink",
		children: item.model
	}) : null] }) : null] });
}
var kindLabel = {
	reading: "Reading",
	speaking: "Speaking",
	language: "Language",
	writing: "Writing",
	study: "Study skills",
	fun: "Fun"
};
function UnitView({ unit, query, onWord }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "overflow-hidden rounded-card bg-banner text-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-6 sm:px-8 sm:py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-ui text-xs font-semibold tracking-[0.18em] uppercase text-card/80",
					children: ["Unit ", unit.number]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-1 text-3xl leading-tight sm:text-5xl",
					children: unit.title
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-5 rounded-card border border-line bg-card px-5 py-5 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-2xl text-maroon",
				children: "What will I learn?"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-4",
				children: unit.learn.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-ui text-xs font-bold tracking-[0.16em] text-banner uppercase",
					children: group.skill
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1 list-disc pl-5",
					children: group.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "font-body text-[1.02rem] leading-relaxed",
						children: point
					}, point))
				})] }, group.skill))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 flex flex-col gap-10",
			children: unit.lessons.map((lesson) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonView, {
				lesson,
				vocab: unit.vocab,
				query,
				onWord
			}, lesson.id))
		})
	] });
}
function LessonView({ lesson, vocab, query, onWord }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: `lesson-${lesson.id}`,
		className: "scroll-mt-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-line pb-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-ui text-xs font-bold tracking-[0.16em] text-banner uppercase",
					children: [
						lesson.code,
						" · ",
						kindLabel[lesson.kind] ?? lesson.kind
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-2xl text-ink sm:text-3xl",
					children: lesson.title
				}),
				lesson.subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg text-maroon italic",
					children: lesson.subtitle
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: lesson.blocks.map((block, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockView, {
				block,
				vocab,
				query,
				onWord,
				seed: `${lesson.id}-${index}`
			}, index))
		})]
	});
}
function BlockView({ block, vocab, query, onWord, seed }) {
	if (block.type === "h") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
		className: "font-display mt-6 text-xl text-banner first:mt-0",
		children: block.text
	});
	if (block.type === "p") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-body mt-3 text-[1.08rem] leading-[1.7] text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
			text: block.text,
			vocab,
			query,
			onWord
		})
	});
	if (block.type === "poem") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 rounded-card border border-line bg-card px-5 py-4",
		children: block.lines.map((line, index) => line.trim() === "" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4" }, index) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-body text-[1.06rem] leading-relaxed italic",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
				text: line,
				vocab,
				query,
				onWord
			})
		}, index))
	});
	if (block.type === "list") {
		const ListTag = block.ordered ? "ol" : "ul";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListTag, {
			className: "mt-3 space-y-1 pl-6 " + (block.ordered ? "list-decimal" : "list-disc"),
			children: block.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "font-body text-[1.05rem] leading-relaxed",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
					text: item,
					vocab,
					query,
					onWord
				})
			}, item))
		});
	}
	if (block.type === "note") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-ui mt-3 rounded-xl bg-banner-soft px-3 py-2 text-sm leading-relaxed text-banner",
		children: block.text
	});
	if (block.type === "dialogue") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 flex flex-col gap-2",
		children: block.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "grid grid-cols-[6.5rem_1fr] gap-2 sm:grid-cols-[8rem_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-ui text-sm font-bold text-maroon",
				children: line.who
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-body text-[1.05rem] leading-relaxed",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
					text: line.text,
					vocab,
					query,
					onWord
				})
			})]
		}, index))
	});
	if (block.type === "callout") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "mt-4 rounded-card border border-maroon/20 bg-maroon-soft px-4 py-3",
		children: [block.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-ui text-xs font-bold tracking-[0.14em] text-maroon uppercase",
			children: block.title
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-body mt-1 text-[1.05rem] leading-relaxed whitespace-pre-wrap",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
				text: block.text,
				vocab,
				query,
				onWord
			})
		})]
	});
	if (block.type === "table") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 overflow-x-auto rounded-card border border-line",
		children: [block.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-ui bg-chip px-3 py-2 text-sm font-semibold text-ink",
			children: block.caption
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[28rem] border-collapse text-left",
			children: [block.headers?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "bg-banner text-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: block.headers.map((header) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "font-ui px-3 py-2 text-sm font-semibold",
					children: header
				}, header)) })
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: (block.rows ?? []).map((row, rowIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: rowIndex % 2 ? "bg-paper" : "bg-card",
				children: row.map((cell, cellIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "font-body border-t border-line px-3 py-2 text-[0.98rem] leading-relaxed",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
						text: String(cell ?? ""),
						vocab,
						query,
						onWord
					})
				}, cellIndex))
			}, rowIndex)) })]
		})]
	});
	if (block.type === "exercise") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExerciseBlock, {
		title: block.title,
		instruction: block.instruction,
		items: block.items ?? [],
		seed
	});
	if (block.type === "words") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 rounded-card border border-line bg-card px-4 py-4",
		children: [block.intro ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-body text-[1.05rem]",
			children: block.intro
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: block.words.map((word) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-ui rounded-full bg-banner-soft px-3 py-1.5 text-sm font-semibold text-banner",
				children: word
			}, word))
		})]
	});
	return null;
}
function VocabBody({ vocab }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-ui text-xs font-semibold uppercase tracking-[0.16em] text-maroon",
				children: vocab.pos || "Word"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-3xl leading-tight text-ink sm:text-4xl",
				children: vocab.word
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-ui text-base leading-relaxed text-ink",
				children: vocab.meaning
			}),
			vocab.urdu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-urdu text-right text-2xl leading-[2.1] text-banner sm:text-3xl",
				dir: "rtl",
				lang: "ur",
				children: vocab.urdu
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipList, {
					label: "Synonyms",
					items: vocab.synonyms,
					tone: "banner"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipList, {
					label: "Antonyms",
					items: vocab.antonyms,
					tone: "maroon"
				})]
			}),
			vocab.sentences.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-card bg-example-soft px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-ui mb-1 text-xs font-semibold uppercase tracking-[0.14em] text-example",
					children: "In a sentence"
				}), vocab.sentences.map((sentence) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-body text-[1.05rem] leading-relaxed font-medium text-example italic",
					children: sentence
				}, sentence))]
			}) : null
		]
	});
}
function ChipList({ label, items, tone }) {
	const clean = items.filter((item) => item && item !== "—" && item !== "-");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-ui mb-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1.5",
		children: clean.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-ui text-sm text-muted",
			children: "—"
		}) : clean.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-ui rounded-full px-2.5 py-1 text-sm " + (tone === "banner" ? "bg-banner-soft text-banner" : "bg-maroon-soft text-maroon"),
			children: item
		}, item))
	})] });
}
function VocabDialog({ vocab, onClose }) {
	if (!vocab) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Close word card",
			className: "absolute inset-0 bg-ink/40",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "vocab-word",
			className: "relative z-10 m-3 max-h-[86vh] w-full max-w-lg overflow-y-auto rounded-card border border-line bg-card p-5 shadow-[0_18px_50px_rgba(28,24,20,0.18)] sm:p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				className: "font-ui absolute top-3 right-3 inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-chip",
				"aria-label": "Close",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "vocab-word",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VocabBody, { vocab })
			})]
		})]
	});
}
function BookShell() {
	const [view, setView] = (0, import_react.useState)("contents");
	const [unitId, setUnitId] = (0, import_react.useState)(units[0]?.id ?? "");
	const [query, setQuery] = (0, import_react.useState)("");
	const [searchOpen, setSearchOpen] = (0, import_react.useState)(false);
	const [navOpen, setNavOpen] = (0, import_react.useState)(false);
	const [vocab, setVocab] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(null);
	const [glossaryQuery, setGlossaryQuery] = (0, import_react.useState)("");
	const unit = units.find((item) => item.id === unitId) ?? units[0];
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key === "Escape") {
				setVocab(null);
				setSearchOpen(false);
				setNavOpen(false);
			}
			if (event.key === "/" && !(event.target instanceof HTMLInputElement)) {
				event.preventDefault();
				document.getElementById("book-search")?.focus();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!pending || view !== "unit") return;
		const node = document.getElementById(`lesson-${pending}`);
		if (!node) return;
		node.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
		setPending(null);
	}, [
		pending,
		view,
		unitId
	]);
	const hits = (0, import_react.useMemo)(() => searchHits(query), [query]);
	function openLesson(nextUnit, lessonId) {
		setUnitId(nextUnit);
		setView("unit");
		setPending(lessonId);
		setNavOpen(false);
		setSearchOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-paper/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center gap-2 px-3 py-2 sm:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-full hover:bg-chip lg:hidden",
							onClick: () => setNavOpen(true),
							"aria-label": "Open contents",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setView("contents"),
							className: "font-display hidden text-left text-lg leading-none sm:block",
							children: "My English 8"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "sr-only",
									htmlFor: "book-search",
									children: "Search units, lessons, and words"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "book-search",
									value: query,
									onChange: (event) => {
										setQuery(event.target.value);
										setSearchOpen(true);
									},
									onFocus: () => setSearchOpen(true),
									placeholder: "Search a unit, lesson, or word",
									className: "font-ui min-h-11 w-full rounded-full border border-line bg-card pr-3 pl-9 text-sm outline-none placeholder:text-muted focus:border-banner"
								}),
								searchOpen && query.trim().length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-12 right-0 left-0 z-40 max-h-80 overflow-y-auto rounded-card border border-line bg-card shadow-[0_12px_30px_rgba(28,24,20,0.12)]",
									children: hits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-ui px-3 py-3 text-sm text-muted",
										children: "No matches in the book."
									}) : hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "font-ui block w-full px-3 py-2.5 text-left hover:bg-banner-soft",
										onClick: () => {
											if (hit.vocab) {
												setVocab(hit.vocab);
												if (hit.unitId && hit.lessonId) openLesson(hit.unitId, hit.lessonId);
												setSearchOpen(false);
												return;
											}
											if (hit.unitId && hit.lessonId) openLesson(hit.unitId, hit.lessonId);
											else if (hit.unitId) {
												setUnitId(hit.unitId);
												setView("unit");
												setNavOpen(false);
												setSearchOpen(false);
											}
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-semibold text-ink",
											children: hit.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs text-muted",
											children: hit.detail
										})]
									}, hit.id))
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setView(view === "glossary" ? "contents" : "glossary"),
							className: "font-ui inline-flex min-h-11 items-center gap-1 rounded-full px-3 text-sm font-semibold text-banner hover:bg-banner-soft",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Glossary"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl lg:grid-cols-[17.5rem_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "hidden border-r border-line lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticky top-16 max-h-[calc(100vh-4rem)] overflow-y-auto px-4 py-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contents, {
							activeUnit: unit?.id,
							activeView: view,
							onContents: () => setView("contents"),
							onLesson: openLesson,
							onGlossary: () => setView("glossary")
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "min-w-0 px-4 py-6 sm:px-8 sm:py-8",
					children: [
						view === "contents" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentsPage, {
							onLesson: openLesson,
							onUnit: (id) => {
								setUnitId(id);
								setView("unit");
							}
						}) : null,
						view === "unit" && unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitView, {
							unit,
							query,
							onWord: setVocab
						}) : null,
						view === "glossary" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glossary, {
							query: glossaryQuery,
							onQuery: setGlossaryQuery,
							onOpen: (item) => setVocab(item)
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
							className: "font-ui mt-12 border-t border-line pt-4 text-xs leading-relaxed text-muted",
							children: "Study edition of My English Book 8, Sindh Textbook Board, Jamshoro, for Class VIII. Difficult words in the lessons are underlined. Click a word for its meaning in this lesson, the Urdu, synonyms, antonyms, and an example sentence."
						})
					]
				})]
			}),
			navOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close contents",
					className: "absolute inset-0 bg-ink/40",
					onClick: () => setNavOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute top-0 bottom-0 left-0 w-[min(100%,20rem)] overflow-y-auto bg-paper px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: "Contents"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-full hover:bg-chip",
							onClick: () => setNavOpen(false),
							"aria-label": "Close",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contents, {
						activeUnit: unit?.id,
						activeView: view,
						onContents: () => {
							setView("contents");
							setNavOpen(false);
						},
						onLesson: openLesson,
						onGlossary: () => {
							setView("glossary");
							setNavOpen(false);
						}
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VocabDialog, {
				vocab,
				onClose: () => setVocab(null)
			})
		]
	});
}
function Contents({ activeUnit, activeView, onContents, onLesson, onGlossary }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": "Table of contents",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onContents,
				className: "font-ui mb-2 flex min-h-11 w-full items-center gap-2 rounded-xl px-2 text-left text-sm font-semibold " + (activeView === "contents" ? "bg-banner text-card" : "hover:bg-chip"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" }), "Table of contents"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onGlossary,
				className: "font-ui mb-4 flex min-h-11 w-full items-center gap-2 rounded-xl px-2 text-left text-sm font-semibold " + (activeView === "glossary" ? "bg-banner text-card" : "hover:bg-chip"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, { className: "size-4" }), "Glossary"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-4",
				children: units.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-ui text-xs font-bold tracking-[0.14em] uppercase " + (activeUnit === unit.id && activeView === "unit" ? "text-banner" : "text-maroon"),
						children: ["Unit ", unit.number]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-base leading-snug",
						children: unit.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1",
						children: unit.lessons.map((lesson) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onLesson(unit.id, lesson.id),
							className: "font-ui min-h-10 w-full rounded-lg px-2 py-1.5 text-left text-sm text-ink hover:bg-banner-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: lesson.code
								}),
								" ",
								lesson.subtitle || lesson.title
							]
						}) }, lesson.id))
					})
				] }, unit.id))
			})
		]
	});
}
function ContentsPage({ onLesson, onUnit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "overflow-hidden rounded-card border border-line bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-banner px-6 py-8 text-card sm:px-10 sm:py-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-ui text-xs font-semibold tracking-[0.2em] uppercase text-card/80",
						children: "Sindh Textbook Board · Class VIII"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-2 text-5xl leading-none sm:text-7xl",
						children: "My English"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-2 text-3xl text-mark sm:text-4xl",
						children: "Book 8"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-ui mt-4 max-w-xl text-base leading-relaxed text-card/90",
						children: "A searchable study book. Jump to any unit or lesson, click a difficult word for its meaning and Urdu, and check exercises as you go."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-px bg-line sm:grid-cols-3",
				children: [
					["Search", "Type a unit, a lesson, or a word."],
					["Words", "Underlined words open a meaning card."],
					["Exercises", "A right choice turns green. A wrong one turns red."]
				].map(([title, copy]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-ui text-sm font-bold text-banner",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-body mt-1 text-[1.02rem] leading-relaxed",
						children: copy
					})]
				}, title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display mt-8 text-3xl",
			children: "Contents"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-4 flex flex-col gap-4",
			children: units.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-card border border-line bg-card px-4 py-4 sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onUnit(unit.id),
					className: "text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-ui text-xs font-bold tracking-[0.16em] text-banner uppercase",
						children: ["Unit ", unit.number]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl leading-tight",
						children: unit.title
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 grid gap-1 sm:grid-cols-2",
					children: unit.lessons.map((lesson) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onLesson(unit.id, lesson.id),
						className: "font-ui min-h-11 w-full rounded-lg px-2 text-left text-sm hover:bg-banner-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-maroon",
								children: lesson.code
							}),
							" ",
							lesson.subtitle || lesson.title
						]
					}) }, lesson.id))
				})]
			}, unit.id))
		})
	] });
}
function Glossary({ query, onQuery, onOpen }) {
	const rows = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return allVocab().filter(({ vocab, unit }) => {
			if (!q) return true;
			return vocab.word.toLowerCase().includes(q) || vocab.meaning.toLowerCase().includes(q) || vocab.urdu.includes(query.trim()) || unit.title.toLowerCase().includes(q);
		}).sort((a, b) => a.vocab.word.localeCompare(b.vocab.word));
	}, [query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-4xl",
			children: "Glossary"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-body mt-2 max-w-2xl text-[1.05rem] leading-relaxed text-muted",
			children: "Every difficult word from the lessons. The headword and the definition use different type. Example sentences are in italics and light blue. Urdu is set in Nastaliq."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: query,
			onChange: (event) => onQuery(event.target.value),
			placeholder: "Filter words",
			className: "font-ui mt-4 min-h-11 w-full max-w-md rounded-full border border-line bg-card px-4 text-sm outline-none focus:border-banner"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-ui mt-3 text-sm text-muted",
			children: [rows.length, " words"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-4",
			children: rows.map(({ unit, vocab }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-card border border-line bg-card px-4 py-4 sm:px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-ui mb-2 text-xs font-semibold tracking-wide text-muted uppercase",
						children: [
							"Unit ",
							unit.number,
							" · ",
							unit.title
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VocabBody, { vocab }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpen(vocab),
						className: "font-ui mt-3 min-h-11 text-sm font-semibold text-banner",
						children: "Open as pop-up"
					})
				]
			}, `${unit.id}-${vocab.word}`))
		})
	] });
}
function blockText(block) {
	if (block.type === "p" || block.type === "h" || block.type === "note") return block.text;
	if (block.type === "callout") return `${block.title ?? ""} ${block.text}`;
	if (block.type === "poem") return block.lines.join(" ");
	if (block.type === "list") return block.items.join(" ");
	if (block.type === "dialogue") return block.lines.map((line) => `${line.who} ${line.text}`).join(" ");
	if (block.type === "exercise") return `${block.title} ${block.instruction ?? ""}`;
	return "";
}
function searchHits(query) {
	const q = query.trim().toLowerCase();
	if (q.length < 2) return [];
	const hits = [];
	const seen = /* @__PURE__ */ new Set();
	const push = (hit) => {
		if (seen.has(hit.id) || hits.length >= 18) return;
		seen.add(hit.id);
		hits.push(hit);
	};
	for (const unit of units) {
		if (unit.title.toLowerCase().includes(q) || `unit ${unit.number}`.includes(q)) push({
			id: `u-${unit.id}`,
			label: `Unit ${unit.number}: ${unit.title}`,
			detail: "Unit",
			unitId: unit.id,
			lessonId: unit.lessons[0]?.id
		});
		for (const lesson of unit.lessons) {
			if (`${lesson.code} ${lesson.title} ${lesson.subtitle ?? ""}`.toLowerCase().includes(q)) push({
				id: `l-${lesson.id}`,
				label: `${lesson.code} ${lesson.subtitle || lesson.title}`,
				detail: `Unit ${unit.number} · ${unit.title}`,
				unitId: unit.id,
				lessonId: lesson.id
			});
			const body = lesson.blocks.map(blockText).join(" ").toLowerCase();
			if (body.includes(q)) {
				const idx = body.indexOf(q);
				const snippet = body.slice(Math.max(0, idx - 40), idx + q.length + 50).trim();
				push({
					id: `t-${lesson.id}`,
					label: `${lesson.code} ${lesson.subtitle || lesson.title}`,
					detail: snippet,
					unitId: unit.id,
					lessonId: lesson.id
				});
			}
		}
		for (const word of unit.vocab) if (word.word.toLowerCase().includes(q) || word.meaning.toLowerCase().includes(q) || word.urdu.includes(query.trim())) push({
			id: `v-${unit.id}-${word.word}`,
			label: word.word,
			detail: `Word · Unit ${unit.number} · ${word.urdu}`,
			unitId: unit.id,
			lessonId: unit.lessons[0]?.id,
			vocab: word
		});
	}
	return hits;
}
var SplitComponent = BookShell;
//#endregion
export { SplitComponent as component };
