import { Et as array, Ft as string, Mt as object, jt as number, kt as literal, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BmVBojIc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-books-BtZpLk9U.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var postingSchema = object({
	opType: string(),
	date: string(),
	amount: number().optional().default(0),
	description: string().optional().default(""),
	partyId: string().optional(),
	cashAccountId: string().optional(),
	destCashAccountId: string().optional(),
	expenseAccountId: string().optional(),
	incomeAccountId: string().optional(),
	cogsAmount: number().optional(),
	cashPortion: number().optional(),
	discountAmount: number().optional(),
	freightAmount: number().optional(),
	checkNumber: string().optional(),
	checkDueDate: string().optional(),
	checkBankName: string().optional(),
	originalId: string().optional(),
	reason: string().optional(),
	lines: array(object({
		accountId: string(),
		debit: number(),
		credit: number(),
		partyId: string().nullable().optional(),
		cashAccountId: string().nullable().optional(),
		description: string().optional()
	})).optional()
});
var bootstrapCompany = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("b17171d118c03f345380aefb6192cba4fc956da4ddacd432fd5ffc061e66d9d8"));
var postOperation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => postingSchema.parse(raw)).handler(createSsrRpc("2f40991a98b10c634c64ed969a544af2daf6495ab91d8b7102c2ed699ccdaff9"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => postingSchema.parse(raw)).handler(createSsrRpc("4f7a1315656d533e400176f69b676894af00f45e108949573d18ccfe09d41a56"));
var listOperations = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	from: string().optional(),
	to: string().optional(),
	opType: string().optional(),
	status: string().optional(),
	q: string().optional()
}).parse(raw ?? {})).handler(createSsrRpc("afc7e31cde469331850f487d32b31e6f375d1d96b512112a2706d452d0931087"));
var softDeleteOperation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	id: string(),
	reason: string().min(2)
}).parse(raw)).handler(createSsrRpc("c7abc9a404128450aed6bc278d0f8101071be4baed60436d3ab188474c70114e"));
var reverseOperation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	id: string(),
	reason: string().min(2)
}).parse(raw)).handler(createSsrRpc("767044ebf1177a667f0886068fb30316d1aece19b8f3ea59575fd5330fdba654"));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("6f3789d99d7c3c8ec8c34c7ac8b95ff3740fd585d26eebab0fcb516633690a81"));
var getTrialBalance = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	from: string(),
	to: string()
}).parse(raw ?? {
	from: "1900-01-01",
	to: "2100-01-01"
})).handler(createSsrRpc("4176684392e6c0dc152c73a603699c26cc688bde4f9e7a22a76dc0d8efccad1c"));
var getStatements = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	from: string(),
	to: string()
}).parse(raw)).handler(createSsrRpc("d3ccb8c08da24132f8d986950a25b1b05fdcfc1dceb076f71ba68d0a94d4065c"));
var getJournalBook = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	from: string(),
	to: string(),
	accountId: string().optional()
}).parse(raw)).handler(createSsrRpc("65d6920c01932e71a936b1ce1e587c3f087b0275360337293cc85d0fe2ae67ba"));
var getLedger = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	accountId: string(),
	from: string(),
	to: string(),
	partyId: string().optional()
}).parse(raw)).handler(createSsrRpc("9dfea3d1ac26375e364b9e3a9da5b2ea214ed03ca5070706cb8ee8feb0876598"));
var getPartyCard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d718e69966ba6e3609a08c87f1ea4a822452b158dcdaef57c063d2dee71b4095"));
var createParty = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	name: string().min(2),
	kind: string(),
	phone: string().optional(),
	address: string().optional()
}).parse(raw)).handler(createSsrRpc("17b5f43257ceabf2a3d1f74a5ed48d1ff5ab937bcf29d87881517237de559e16"));
var createAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	code: string().min(1),
	name: string().min(2),
	parentCode: string(),
	nature: _enum(["debit", "credit"]),
	groupCode: string(),
	floatingType: string().optional()
}).parse(raw)).handler(createSsrRpc("b710651212a1e2007e74cb393707a0e91886be772dec3e5f2bad672acc4cc6f9"));
var listChecks = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("dbfdfed2b201cac2d05b3b62e58f34517cb35b10967b22956f1e8ce7365eb1d5"));
var updateCheckStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	id: string(),
	status: string()
}).parse(raw)).handler(createSsrRpc("b78b167ed15dac59c6ca6063c92a58c828edf05041ca38992cc1e6588bc5d7a0"));
var closeDay = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	date: string(),
	confirm: literal(true)
}).parse(raw)).handler(createSsrRpc("057ce5c93319c547649a994043cadf333d3ce4cd40afca7446294531306c1f75"));
var requestReopenDay = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	date: string(),
	phrase: string()
}).parse(raw)).handler(createSsrRpc("cc3f002a9d1d889f4203156090b31890050a4150e75fd72523535c322d0efc0a"));
var exportBackup = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("f02e4fb688ea8253870c9f61b3e4703f28ac6c12ed0b113be33614675c003444"));
var listAudit = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("a473d9b520b2e50d5e82e73094726c709ba8d9bcfe5fca899574b53ecdbb2c4e"));
var getHealth = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7c64d01489f987a27055d573a33cdb93a677f94c502bc9b986733041af1c142a"));
var searchBooks = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({ q: string() }).parse(raw)).handler(createSsrRpc("89a1fa688e5f88be1087b8efe2596b904628ece0f2e9ef689896d61c87f4b4ee"));
function useBootstrap() {
	return useQuery({
		queryKey: ["bootstrap"],
		queryFn: () => bootstrapCompany()
	});
}
function booksFromBootstrap(data) {
	const accountsById = /* @__PURE__ */ new Map();
	const accountsByCode = /* @__PURE__ */ new Map();
	for (const a of data.accounts) {
		const row = {
			id: a.id,
			code: a.code,
			name: a.name,
			level: a.level,
			parentId: null,
			groupCode: a.groupCode,
			nature: a.nature,
			isPostable: a.isPostable,
			isActive: true,
			floatingType: a.floatingType
		};
		accountsById.set(row.id, row);
		accountsByCode.set(row.code, row);
	}
	const cashById = /* @__PURE__ */ new Map();
	for (const c of data.cashAccounts) cashById.set(c.id, {
		...c,
		isActive: true
	});
	return {
		accountsById,
		accountsByCode,
		cashById
	};
}
function useDashboard() {
	return useQuery({
		queryKey: ["dashboard"],
		queryFn: () => getDashboard()
	});
}
function useOperations(filters) {
	return useQuery({
		queryKey: ["operations", filters],
		queryFn: () => listOperations({ data: filters })
	});
}
function useTrial(from, to) {
	return useQuery({
		queryKey: [
			"trial",
			from,
			to
		],
		queryFn: () => getTrialBalance({ data: {
			from,
			to
		} })
	});
}
function useStatements(from, to) {
	return useQuery({
		queryKey: [
			"statements",
			from,
			to
		],
		queryFn: () => getStatements({ data: {
			from,
			to
		} })
	});
}
function useJournalBook(from, to) {
	return useQuery({
		queryKey: [
			"journal-book",
			from,
			to
		],
		queryFn: () => getJournalBook({ data: {
			from,
			to
		} })
	});
}
function useParties() {
	return useQuery({
		queryKey: ["parties"],
		queryFn: () => getPartyCard()
	});
}
function useChecks() {
	return useQuery({
		queryKey: ["checks"],
		queryFn: () => listChecks()
	});
}
function useAudit() {
	return useQuery({
		queryKey: ["audit"],
		queryFn: () => listAudit()
	});
}
function useHealth() {
	return useQuery({
		queryKey: ["health"],
		queryFn: () => getHealth()
	});
}
function useInvalidateBooks() {
	const qc = useQueryClient();
	return () => qc.invalidateQueries({ predicate: (q) => true });
}
//#endregion
export { useTrial as C, useStatements as S, useHealth as _, exportBackup as a, useOperations as b, requestReopenDay as c, softDeleteOperation as d, updateCheckStatus as f, useDashboard as g, useChecks as h, createParty as i, reverseOperation as l, useBootstrap as m, closeDay as n, getLedger as o, useAudit as p, createAccount as r, postOperation as s, booksFromBootstrap as t, searchBooks as u, useInvalidateBooks as v, useParties as x, useJournalBook as y };
