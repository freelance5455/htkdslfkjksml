import { i as __toESM } from "../_runtime.mjs";
import { _ as lazyRouteComponent, b as useRouter, f as Scripts, g as Outlet, h as createRouter, p as HeadContent, q as require_react, v as createFileRoute, x as require_jsx_runtime, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DEyW4zoq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var TIER_RANK = {
	flagship: 4,
	"upper-mid": 3,
	mid: 2,
	"low-end": 1
};
function clamp(n, lo, hi) {
	return Math.min(hi, Math.max(lo, n));
}
function round(n) {
	return Math.round(n);
}
function scoreCpu(tier) {
	switch (tier) {
		case "flagship": return 28;
		case "upper-mid": return 21;
		case "mid": return 14;
		case "low-end": return 6;
	}
}
function scoreRamGb(ramGb) {
	if (ramGb >= 12) return 18;
	if (ramGb >= 8) return 16;
	if (ramGb >= 6) return 13;
	if (ramGb >= 4) return 9;
	if (ramGb >= 3) return 5;
	return 3;
}
function scoreRamType(ramType) {
	const t = ramType.toUpperCase();
	if (t.includes("LPDDR5X") || t.includes("LPDDR5T")) return 6;
	if (t.includes("LPDDR5")) return 6;
	if (t.includes("LPDDR4X")) return 4;
	if (t.includes("LPDDR4")) return 3;
	return 4;
}
function scoreGpu(tier) {
	switch (tier) {
		case "flagship": return 18;
		case "upper-mid": return 13;
		case "mid": return 9;
		case "low-end": return 4;
	}
}
function scoreRefresh(hz) {
	if (hz >= 144) return 14;
	if (hz >= 120) return 12;
	if (hz >= 90) return 9;
	return 5;
}
function scoreTouch(hz) {
	if (hz >= 240) return 10;
	if (hz >= 180) return 8;
	if (hz >= 120) return 6;
	if (hz >= 90) return 4;
	return 2;
}
function scoreThermal(status) {
	switch (status) {
		case "none":
		case "unavailable": return 6;
		case "light": return 5;
		case "moderate": return 4;
		case "severe": return 2;
		case "critical":
		case "emergency":
		case "shutdown": return 0;
	}
}
function computeScore(hw) {
	const breakdown = {
		cpu: scoreCpu(hw.cpuTier),
		ram: scoreRamGb(hw.ramGb),
		ramType: scoreRamType(hw.ramType),
		gpu: scoreGpu(hw.gpuTier),
		refresh: scoreRefresh(hw.refreshRate),
		touch: scoreTouch(hw.touchSamplingHz),
		thermal: scoreThermal(hw.thermalStatus)
	};
	return {
		total: clamp(breakdown.cpu + breakdown.ram + breakdown.ramType + breakdown.gpu + breakdown.refresh + breakdown.touch + breakdown.thermal, 0, 100),
		breakdown
	};
}
function baseGeneral(hw) {
	const strongChip = hw.cpuTier === "flagship" || hw.cpuTier === "upper-mid";
	if (hw.refreshRate >= 90 && strongChip) {
		if (hw.cpuTier === "flagship" && hw.refreshRate >= 120) return 168;
		if (hw.cpuTier === "flagship") return 171;
		if (hw.refreshRate >= 120) return 173;
		return 175;
	}
	if (hw.ramGb <= 3 || hw.cpuTier === "low-end") return 195;
	if (hw.ramGb <= 4 || hw.refreshRate <= 60) return 190;
	return 188;
}
function screenSensAdj(inches) {
	return clamp(round((6.4 - inches) * 2), -4, 4);
}
function touchSensAdj(hz) {
	if (hz >= 240) return -3;
	if (hz >= 180) return -2;
	if (hz >= 120) return -1;
	if (hz < 90) return 3;
	return 0;
}
function computeSensitivity(hw) {
	const general = clamp(baseGeneral(hw) + screenSensAdj(hw.displayInches) + touchSensAdj(hw.touchSamplingHz), 140, 200);
	const scale = (ratio) => clamp(round(general * ratio), 0, 200);
	return {
		general,
		redDot: scale(.95),
		scope2x: scale(.88),
		scope4x: scale(.78),
		awm: scale(.62),
		freeLook: scale(.72)
	};
}
function baseDpi(hw) {
	if (hw.ramGb <= 3) return 420;
	if (hw.ramGb <= 4) return 480;
	if (hw.ramGb <= 6) return 520;
	return hw.refreshRate >= 90 ? 560 : 600;
}
function tierDpiAdj(tier) {
	switch (tier) {
		case "flagship": return 16;
		case "upper-mid": return 8;
		case "mid": return 0;
		case "low-end": return -16;
	}
}
function gpuDpiAdj(tier) {
	switch (tier) {
		case "flagship": return 12;
		case "upper-mid": return 4;
		case "mid": return 0;
		case "low-end": return -12;
	}
}
function computeDpi(hw) {
	const recommended = clamp(baseDpi(hw) + tierDpiAdj(hw.cpuTier) + gpuDpiAdj(hw.gpuTier), 360, 640);
	return {
		recommended,
		smallestWidth: round((Math.min(hw.displayWidth, hw.displayHeight) || 1080) * 160 / recommended),
		originalDpi: hw.defaultDpi || hw.densityDpi || 480,
		adbSet: `adb shell wm density ${recommended}`,
		adbReset: "adb shell wm density reset"
	};
}
function computeFireButton(hw) {
	let size = 50;
	if (hw.ramGb <= 3) size = 52;
	else if (hw.ramGb <= 4) size = 50;
	else if (hw.ramGb <= 6) size = 48;
	else size = 46;
	if (hw.displayInches >= 6.8) size += 2;
	else if (hw.displayInches <= 5.8) size -= 1;
	return clamp(size, 40, 60);
}
function computeGraphics(hw, score) {
	const extras = [];
	const hot = hw.thermalStatus === "severe" || hw.thermalStatus === "critical" || hw.thermalStatus === "emergency" || hw.thermalStatus === "shutdown";
	let preset = "Smooth";
	let fpsOption = "60";
	let highFps = false;
	if (hw.cpuTier === "flagship" && hw.ramGb >= 8 && hw.refreshRate >= 90 && score >= 78 && !hot) {
		preset = "Smooth";
		fpsOption = hw.refreshRate >= 120 ? "Ultra" : "High";
		highFps = true;
		extras.push("Keep Shadows off — they hide enemies in smoke and cost GPU time.");
		extras.push("High resolution: off. Sharpness comes from DPI, not the in-game scaler.");
	} else if ((hw.cpuTier === "flagship" || hw.cpuTier === "upper-mid") && hw.refreshRate >= 90 && !hot) {
		preset = "Smooth";
		fpsOption = "High";
		highFps = true;
		extras.push("If the phone heats past ~42°C, drop to 60 FPS for the rest of the session.");
	} else if (hw.cpuTier === "mid" && hw.ramGb >= 6) {
		preset = "Smooth";
		fpsOption = hw.refreshRate >= 90 ? "High" : "60";
		highFps = hw.refreshRate >= 90 && score >= 55 && !hot;
		extras.push("Disable Effects and Shadows. Leave Auto-adjust off so the game cannot drop you to 30.");
	} else {
		preset = "Smooth";
		fpsOption = hw.ramGb <= 3 || hw.cpuTier === "low-end" ? "30" : "60";
		highFps = false;
		extras.push("High FPS stays off — this silicon cannot hold it in late-game fights.");
		extras.push("Close background apps before queueing. 3–4 GB devices hitch when Chrome is alive.");
	}
	if (hot) {
		highFps = false;
		fpsOption = "30";
		extras.unshift("Device is thermally throttled. Cool it down before ranked.");
	}
	if (TIER_RANK[hw.cpuTier] <= 2) extras.push("Play ranked on Wi-Fi or a stable 4G cell. Frame time already spends the budget.");
	extras.push("Lock HUD scale to default after applying DPI, then set the fire button percent above.");
	return {
		preset,
		fpsOption,
		highFps,
		extras
	};
}
function generateSettings(hw) {
	const { total, breakdown } = computeScore(hw);
	return {
		performanceScore: total,
		scoreBreakdown: breakdown,
		sensitivity: computeSensitivity(hw),
		dpi: computeDpi(hw),
		fireButtonPercent: computeFireButton(hw),
		graphics: computeGraphics(hw, total)
	};
}
function formatSettingsText(hw, settings, lang) {
	const s = settings.sensitivity;
	if (lang === "ar") return [
		`كاليبر — إعدادات فري فاير`,
		`الجهاز: ${hw.manufacturer} ${hw.model}`,
		`المعالج: ${hw.socName} (${hw.cpuTier})`,
		`درجة الأداء: ${settings.performanceScore}/100`,
		``,
		`الحساسية (0–200)`,
		`عام: ${s.general}`,
		`النقطة الحمراء: ${s.redDot}`,
		`سكوب 2x: ${s.scope2x}`,
		`سكوب 4x: ${s.scope4x}`,
		`سكوب AWM: ${s.awm}`,
		`النظر الحر: ${s.freeLook}`,
		``,
		`DPI الموصى به: ${settings.dpi.recommended}`,
		`العرض الأصغر: ${settings.dpi.smallestWidth}`,
		`DPI الأصلي: ${settings.dpi.originalDpi}`,
		settings.dpi.adbSet,
		`الاستعادة: ${settings.dpi.adbReset}`,
		``,
		`حجم زر الإطلاق: ${settings.fireButtonPercent}%`,
		`الجرافيك: ${settings.graphics.preset}`,
		`معدل الإطارات: ${settings.graphics.fpsOption}`,
		`High FPS: ${settings.graphics.highFps ? "تشغيل" : "إيقاف"}`,
		``,
		...settings.graphics.extras
	].join("\n");
	return [
		`CALIBER — Free Fire settings`,
		`Device: ${hw.manufacturer} ${hw.model}`,
		`SoC: ${hw.socName} (${hw.cpuTier})`,
		`Performance score: ${settings.performanceScore}/100`,
		``,
		`Sensitivity (0–200)`,
		`General: ${s.general}`,
		`Red Dot: ${s.redDot}`,
		`2x Scope: ${s.scope2x}`,
		`4x Scope: ${s.scope4x}`,
		`AWM Scope: ${s.awm}`,
		`Free Look: ${s.freeLook}`,
		``,
		`Recommended DPI: ${settings.dpi.recommended}`,
		`Smallest width: ${settings.dpi.smallestWidth}`,
		`Original DPI (restore this): ${settings.dpi.originalDpi}`,
		settings.dpi.adbSet,
		`Restore: ${settings.dpi.adbReset}`,
		`Path: Settings → Developer options → Smallest width → ${settings.dpi.smallestWidth}`,
		``,
		`Fire button size: ${settings.fireButtonPercent}%`,
		`Graphics: ${settings.graphics.preset}`,
		`FPS: ${settings.graphics.fpsOption}`,
		`High FPS: ${settings.graphics.highFps ? "ON" : "OFF"}`,
		``,
		...settings.graphics.extras
	].join("\n");
}
var FLAGSHIP = "flagship";
var UPPER = "upper-mid";
var MID = "mid";
var LOW = "low-end";
function pick(name, patterns) {
	for (const [re, tier] of patterns) if (re.test(name)) return tier;
	return null;
}
/**
* Classify a chip from any free-form name: Build.SOC_MODEL, /proc/cpuinfo Hardware,
* marketing strings ("Snapdragon 8 Gen 2"), or WebGL renderer ("Adreno (TM) 740").
*
* Patterns are ordered most-specific first so "8 Gen 2" does not match a bare "8".
*/
function classifySoc(raw) {
	const name = (raw || "").replace(/\s+/g, " ").trim();
	const n = name.toLowerCase();
	if (!n || n === "unavailable" || n === "unknown") return {
		family: "unknown",
		tier: MID,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		label: "Unknown"
	};
	if (/a1[7-9]|a2\d|m[1-4](\s|pro|max|ultra)?/.test(n) && /apple|iphone|ipad/.test(n) || /^a1[7-9]/.test(n) || /apple gpu/.test(n)) {
		/a1[5-6]/.test(n);
		if (/a1[4-9]|a2\d|apple gpu/.test(n)) return wrap("apple", /a14|a15/.test(n) ? UPPER : FLAGSHIP, name);
	}
	if (/\b(a17|a18|a16|a15|a14)\b/.test(n)) return wrap("apple", /\b(a17|a18)\b/.test(n) ? FLAGSHIP : UPPER, name);
	if (/tensor/.test(n) || /google tensor/.test(n) || /\bg[1-5]\s*tensor/.test(n)) return wrap("tensor", pick(n, [
		[/g[345]|tensor g[345]/, FLAGSHIP],
		[/g2|tensor g2/, UPPER],
		[/g1|tensor g1/, MID]
	]) ?? FLAGSHIP, name);
	if (/snapdragon|qualcomm|\bsd\s?\d|\bsm\d{4}|adreno/.test(n) || /\b8\s*(gen|elite|\+)/.test(n) || /\b7\s*(\+|gen)/.test(n)) {
		const tier = pick(n, [
			[/8\s*elite|8\s*gen\s*[3-9]|8\+|sm8[56]\d{2}|sm8750|sm8650|sm8550|adreno\s*\(?\s*tm\s*\)?\s*8[23]\d|adreno\s*\(?\s*tm\s*\)?\s*75\d|adreno\s*\(?\s*tm\s*\)?\s*740/, FLAGSHIP],
			[/8\s*gen\s*[12]|888|8cx|865|870|sm84\d{2}|sm8475|sm8450|adreno\s*\(?\s*tm\s*\)?\s*(730|660|650)/, FLAGSHIP],
			[/8s\s*gen|7\+\s*gen|7\s*gen\s*[1-4]|7s\s*gen|778g|780g|782g|7c|855|860|sm74\d{2}|sm73\d{2}|adreno\s*\(?\s*tm\s*\)?\s*(735|725|720|710|644|642)/, UPPER],
			[/6\s*gen|6s|695|4\s*gen|732g|730|720g|680|685|4s|sm6[0-4]\d{2}|sm4[3-9]\d{2}|adreno\s*\(?\s*tm\s*\)?\s*(619|616|613|610)/, MID],
			[/4[0-6]\d|215|662|460|480|665|439|450|adreno\s*\(?\s*tm\s*\)?\s*(508|509|512|505|504|308)/, LOW]
		]);
		if (tier) return wrap("snapdragon", tier, prettySnap(name));
	}
	if (/dimensity|mediatek\s*mt6|mt6[89]|immortalis|mali-g[6-9]|mali-g1/.test(n) || /dimensity/.test(n)) {
		const tier = pick(n, [
			[/9[2-9]\d{2}|9400|9300|9200|9000|immortalis/, FLAGSHIP],
			[/8[2-4]\d{2}|8100|8000|7350|7300|7200|mali-g615|mali-g72[0-9]/, UPPER],
			[/7[0-1]\d{2}|7050|7030|7020|6100|6300|6080|1200|1300|1080|1050|930|mali-g610|mali-g68/, MID],
			[/610|700|800u|900\b|6020|6000|800\b|mali-g57|mali-g52/, LOW]
		]);
		if (tier) return wrap("dimensity", tier, name);
	}
	if (/helio/.test(n)) return wrap("helio", pick(n, [[/g9[0-9]|g99|g96|g95|g90/, MID], [/g8[0-9]|g7[0-9]|g3[0-9]|p\d+|g25|g35|g37/, LOW]]) ?? LOW, name);
	if (/exynos|xclipse|samsung\s*s5e/.test(n)) return wrap("exynos", pick(n, [
		[/2[2-5]00|2100|990|9820|xclipse\s*9[2-4]0/, FLAGSHIP],
		[/1[45]80|1580|2200|xclipse\s*530|xclipse\s*920/, UPPER],
		[/1380|1280|1080|1330|980|880|850/, MID],
		[/7884|7904|9611|850|9609|7870/, LOW]
	]) ?? MID, name);
	if (/unisoc|spreadtrum|t[6-8]\d{2}|sc9/.test(n)) return wrap("unisoc", pick(n, [[/t820|t760|t750/, MID], [/t616|t612|t610|t606|t700|t310|t573|t606/, LOW]]) ?? LOW, name);
	const gpuOnly = classifyGpuRenderer(name);
	if (gpuOnly) return gpuOnly;
	return {
		family: "unknown",
		tier: MID,
		ramType: "LPDDR4X",
		storageType: "UFS 2.1",
		label: name || "Unknown"
	};
}
function classifyGpuRenderer(raw) {
	const n = raw.toLowerCase();
	if (/adreno/.test(n)) return wrap("snapdragon", pick(n, [
		[/\b(8[2-3]\d|75\d|740|730|660|650)\b/, FLAGSHIP],
		[/\b(735|725|720|710|644|642)\b/, UPPER],
		[/\b(619|616|613|612|610|618)\b/, MID],
		[/\b(508|509|512|505|504|308|306)\b/, LOW]
	]) ?? MID, raw);
	if (/immortalis/.test(n)) return wrap("dimensity", FLAGSHIP, raw);
	if (/mali-g715|mali-g720|mali-g925/.test(n)) return wrap("dimensity", FLAGSHIP, raw);
	if (/mali-g615/.test(n)) return wrap("dimensity", UPPER, raw);
	if (/mali-g610|mali-g68/.test(n)) return wrap("dimensity", MID, raw);
	if (/mali-g57/.test(n)) return wrap("helio", MID, raw);
	if (/mali-g52|mali-g51|mali-g31/.test(n)) return wrap("helio", LOW, raw);
	if (/xclipse\s*9/.test(n)) return wrap("exynos", FLAGSHIP, raw);
	if (/xclipse/.test(n)) return wrap("exynos", UPPER, raw);
	if (/apple gpu|apple m/.test(n)) return wrap("apple", FLAGSHIP, raw);
	if (/powervr/.test(n)) return wrap("unknown", LOW, raw);
	return null;
}
function wrap(family, tier, label) {
	return {
		family,
		tier,
		ramType: ramTypeFor(family, tier),
		storageType: storageFor(family, tier),
		label: label.replace(/\s+/g, " ").trim()
	};
}
/** DRAM generation is rarely readable from userspace; estimate from silicon class. */
function ramTypeFor(family, tier) {
	if (tier === FLAGSHIP) return family === "apple" ? "LPDDR5X" : "LPDDR5";
	if (tier === UPPER) return "LPDDR5";
	if (tier === MID) return "LPDDR4X";
	return "LPDDR4X";
}
function storageFor(_family, tier) {
	if (tier === FLAGSHIP) return "UFS 4.0";
	if (tier === UPPER) return "UFS 3.1";
	if (tier === MID) return "UFS 2.2";
	return "eMMC 5.1";
}
function prettySnap(name) {
	if (/snapdragon|qualcomm|sm\d/i.test(name)) return name;
	return name;
}
var TIER_LABEL = {
	flagship: {
		en: "Flagship",
		ar: "فئة عليا"
	},
	"upper-mid": {
		en: "Upper-mid",
		ar: "فوق المتوسط"
	},
	mid: {
		en: "Mid",
		ar: "متوسط"
	},
	"low-end": {
		en: "Low-end",
		ar: "فئة اقتصادية"
	}
};
function d(partial) {
	return partial;
}
/** Popular Free Fire phones across MENA, LATAM, SEA, and South Asia. */
var CATALOG = [
	d({
		id: "samsung-s25",
		brand: "Samsung",
		name: "Galaxy S25",
		aliases: [
			"SM-S931",
			"S25",
			"Galaxy S25"
		],
		soc: "Snapdragon 8 Elite",
		gpu: "Adreno 830",
		cores: 8,
		maxFreqKhz: [
			432e4,
			359e4,
			359e4,
			256e4,
			256e4,
			256e4,
			256e4,
			256e4
		],
		ramOptionsGb: [12],
		typicalRamGb: 12,
		ramType: "LPDDR5X",
		storageType: "UFS 4.0",
		typicalStorageGb: 256,
		inches: 6.2,
		resolution: [1080, 2340],
		refreshRates: [60, 120],
		defaultDpi: 480,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "15"
	}),
	d({
		id: "samsung-s24",
		brand: "Samsung",
		name: "Galaxy S24",
		aliases: [
			"SM-S921",
			"S24",
			"Galaxy S24"
		],
		soc: "Snapdragon 8 Gen 3",
		gpu: "Adreno 750",
		cores: 8,
		maxFreqKhz: [
			33e5,
			315e4,
			315e4,
			227e4,
			227e4,
			227e4,
			227e4,
			227e4
		],
		ramOptionsGb: [8, 12],
		typicalRamGb: 8,
		ramType: "LPDDR5X",
		storageType: "UFS 4.0",
		typicalStorageGb: 256,
		inches: 6.2,
		resolution: [1080, 2340],
		refreshRates: [60, 120],
		defaultDpi: 480,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "samsung-s23",
		brand: "Samsung",
		name: "Galaxy S23",
		aliases: [
			"SM-S911",
			"S23",
			"Galaxy S23"
		],
		soc: "Snapdragon 8 Gen 2",
		gpu: "Adreno 740",
		cores: 8,
		maxFreqKhz: [
			336e4,
			28e5,
			28e5,
			28e5,
			201e4,
			201e4,
			201e4,
			201e4
		],
		ramOptionsGb: [8],
		typicalRamGb: 8,
		ramType: "LPDDR5X",
		storageType: "UFS 4.0",
		typicalStorageGb: 128,
		inches: 6.1,
		resolution: [1080, 2340],
		refreshRates: [60, 120],
		defaultDpi: 480,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "samsung-a55",
		brand: "Samsung",
		name: "Galaxy A55 5G",
		aliases: [
			"SM-A556",
			"A55",
			"Galaxy A55"
		],
		soc: "Exynos 1480",
		gpu: "Xclipse 530",
		cores: 8,
		maxFreqKhz: [
			28e5,
			28e5,
			28e5,
			28e5,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [8, 12],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 3.1",
		typicalStorageGb: 128,
		inches: 6.6,
		resolution: [1080, 2340],
		refreshRates: [60, 120],
		defaultDpi: 450,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "samsung-a54",
		brand: "Samsung",
		name: "Galaxy A54 5G",
		aliases: [
			"SM-A546",
			"A54",
			"Galaxy A54"
		],
		soc: "Exynos 1380",
		gpu: "Mali-G68 MP5",
		cores: 8,
		maxFreqKhz: [
			24e5,
			24e5,
			24e5,
			24e5,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [6, 8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 3.1",
		typicalStorageGb: 128,
		inches: 6.4,
		resolution: [1080, 2340],
		refreshRates: [60, 120],
		defaultDpi: 450,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "samsung-a35",
		brand: "Samsung",
		name: "Galaxy A35 5G",
		aliases: [
			"SM-A356",
			"A35",
			"Galaxy A35"
		],
		soc: "Exynos 1380",
		gpu: "Mali-G68 MP5",
		cores: 8,
		maxFreqKhz: [
			24e5,
			24e5,
			24e5,
			24e5,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [6, 8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.6,
		resolution: [1080, 2340],
		refreshRates: [60, 120],
		defaultDpi: 450,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "samsung-a15",
		brand: "Samsung",
		name: "Galaxy A15",
		aliases: [
			"SM-A155",
			"SM-A156",
			"A15",
			"Galaxy A15"
		],
		soc: "Mediatek Helio G99",
		gpu: "Mali-G57 MC2",
		cores: 8,
		maxFreqKhz: [
			22e5,
			22e5,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [
			4,
			6,
			8
		],
		typicalRamGb: 6,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.5,
		resolution: [1080, 2340],
		refreshRates: [60, 90],
		defaultDpi: 401,
		touchHz: 180,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "samsung-a14",
		brand: "Samsung",
		name: "Galaxy A14",
		aliases: [
			"SM-A145",
			"SM-A146",
			"A14",
			"Galaxy A14"
		],
		soc: "Exynos 1330",
		gpu: "Mali-G68 MP2",
		cores: 8,
		maxFreqKhz: [
			24e5,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [4, 6],
		typicalRamGb: 4,
		ramType: "LPDDR4X",
		storageType: "eMMC 5.1",
		typicalStorageGb: 64,
		inches: 6.6,
		resolution: [1080, 2408],
		refreshRates: [60, 90],
		defaultDpi: 401,
		touchHz: 120,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "samsung-a05s",
		brand: "Samsung",
		name: "Galaxy A05s",
		aliases: [
			"SM-A057",
			"A05s",
			"Galaxy A05s"
		],
		soc: "Snapdragon 680",
		gpu: "Adreno 610",
		cores: 8,
		maxFreqKhz: [
			24e5,
			24e5,
			24e5,
			24e5,
			19e5,
			19e5,
			19e5,
			19e5
		],
		ramOptionsGb: [4, 6],
		typicalRamGb: 4,
		ramType: "LPDDR4X",
		storageType: "eMMC 5.1",
		typicalStorageGb: 64,
		inches: 6.7,
		resolution: [1080, 2400],
		refreshRates: [60, 90],
		defaultDpi: 394,
		touchHz: 120,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "redmi-13c",
		brand: "Xiaomi",
		name: "Redmi 13C",
		aliases: [
			"23100RN82L",
			"13C",
			"Redmi 13C"
		],
		soc: "Mediatek Helio G85",
		gpu: "Mali-G52 MC2",
		cores: 8,
		maxFreqKhz: [
			2e6,
			2e6,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5
		],
		ramOptionsGb: [
			4,
			6,
			8
		],
		typicalRamGb: 6,
		ramType: "LPDDR4X",
		storageType: "eMMC 5.1",
		typicalStorageGb: 128,
		inches: 6.74,
		resolution: [720, 1600],
		refreshRates: [60, 90],
		defaultDpi: 269,
		touchHz: 180,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "redmi-note-13",
		brand: "Xiaomi",
		name: "Redmi Note 13",
		aliases: [
			"23129RN51X",
			"Note 13",
			"Redmi Note 13"
		],
		soc: "Snapdragon 685",
		gpu: "Adreno 610",
		cores: 8,
		maxFreqKhz: [
			28e5,
			24e5,
			24e5,
			24e5,
			19e5,
			19e5,
			19e5,
			19e5
		],
		ramOptionsGb: [6, 8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.67,
		resolution: [1080, 2400],
		refreshRates: [60, 120],
		defaultDpi: 395,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "redmi-note-13-pro",
		brand: "Xiaomi",
		name: "Redmi Note 13 Pro",
		aliases: ["23117RA68G", "Note 13 Pro"],
		soc: "Dimensity 7200 Ultra",
		gpu: "Mali-G610 MC4",
		cores: 8,
		maxFreqKhz: [
			28e5,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [8, 12],
		typicalRamGb: 8,
		ramType: "LPDDR5",
		storageType: "UFS 3.1",
		typicalStorageGb: 256,
		inches: 6.67,
		resolution: [1220, 2712],
		refreshRates: [60, 120],
		defaultDpi: 446,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "redmi-note-12",
		brand: "Xiaomi",
		name: "Redmi Note 12",
		aliases: [
			"22101316G",
			"Note 12",
			"Redmi Note 12"
		],
		soc: "Snapdragon 4 Gen 1",
		gpu: "Adreno 619",
		cores: 8,
		maxFreqKhz: [
			22e5,
			22e5,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5
		],
		ramOptionsGb: [
			4,
			6,
			8
		],
		typicalRamGb: 6,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.67,
		resolution: [1080, 2400],
		refreshRates: [60, 120],
		defaultDpi: 395,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "13"
	}),
	d({
		id: "poco-x6-pro",
		brand: "Poco",
		name: "Poco X6 Pro",
		aliases: [
			"23122PCD1G",
			"X6 Pro",
			"Poco X6 Pro"
		],
		soc: "Dimensity 8300 Ultra",
		gpu: "Mali-G615 MC6",
		cores: 8,
		maxFreqKhz: [
			335e4,
			335e4,
			335e4,
			24e5,
			22e5,
			22e5,
			22e5,
			22e5
		],
		ramOptionsGb: [8, 12],
		typicalRamGb: 8,
		ramType: "LPDDR5X",
		storageType: "UFS 4.0",
		typicalStorageGb: 256,
		inches: 6.67,
		resolution: [1220, 2712],
		refreshRates: [60, 120],
		defaultDpi: 446,
		touchHz: 480,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "poco-x6",
		brand: "Poco",
		name: "Poco X6",
		aliases: [
			"23122PCD2G",
			"X6",
			"Poco X6"
		],
		soc: "Snapdragon 7s Gen 2",
		gpu: "Adreno 710",
		cores: 8,
		maxFreqKhz: [
			27e5,
			24e5,
			24e5,
			24e5,
			18e5,
			18e5,
			18e5,
			18e5
		],
		ramOptionsGb: [8, 12],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 3.1",
		typicalStorageGb: 256,
		inches: 6.67,
		resolution: [1220, 2712],
		refreshRates: [60, 120],
		defaultDpi: 446,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "poco-x5-pro",
		brand: "Poco",
		name: "Poco X5 Pro",
		aliases: ["22101320G", "X5 Pro"],
		soc: "Snapdragon 778G",
		gpu: "Adreno 642L",
		cores: 8,
		maxFreqKhz: [
			24e5,
			24e5,
			24e5,
			24e5,
			19e5,
			19e5,
			19e5,
			19e5
		],
		ramOptionsGb: [6, 8],
		typicalRamGb: 8,
		ramType: "LPDDR5",
		storageType: "UFS 3.1",
		typicalStorageGb: 128,
		inches: 6.67,
		resolution: [1080, 2400],
		refreshRates: [60, 120],
		defaultDpi: 395,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "13"
	}),
	d({
		id: "poco-f6",
		brand: "Poco",
		name: "Poco F6",
		aliases: [
			"24069PC21G",
			"F6",
			"Poco F6"
		],
		soc: "Snapdragon 8s Gen 3",
		gpu: "Adreno 735",
		cores: 8,
		maxFreqKhz: [
			3e6,
			274e4,
			274e4,
			274e4,
			196e4,
			196e4,
			196e4,
			196e4
		],
		ramOptionsGb: [8, 12],
		typicalRamGb: 12,
		ramType: "LPDDR5X",
		storageType: "UFS 4.0",
		typicalStorageGb: 256,
		inches: 6.67,
		resolution: [1220, 2712],
		refreshRates: [60, 120],
		defaultDpi: 446,
		touchHz: 480,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "poco-f5",
		brand: "Poco",
		name: "Poco F5",
		aliases: [
			"23049PCD8G",
			"F5",
			"Poco F5"
		],
		soc: "Snapdragon 7+ Gen 2",
		gpu: "Adreno 725",
		cores: 8,
		maxFreqKhz: [
			291e4,
			241e4,
			241e4,
			241e4,
			18e5,
			18e5,
			18e5,
			18e5
		],
		ramOptionsGb: [8, 12],
		typicalRamGb: 8,
		ramType: "LPDDR5",
		storageType: "UFS 3.1",
		typicalStorageGb: 256,
		inches: 6.67,
		resolution: [1080, 2400],
		refreshRates: [60, 120],
		defaultDpi: 395,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "poco-m6",
		brand: "Poco",
		name: "Poco M6",
		aliases: [
			"2404APC5FG",
			"M6",
			"Poco M6"
		],
		soc: "Mediatek Helio G99 Ultra",
		gpu: "Mali-G57 MC2",
		cores: 8,
		maxFreqKhz: [
			22e5,
			22e5,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [6, 8],
		typicalRamGb: 6,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.79,
		resolution: [1080, 2460],
		refreshRates: [60, 90],
		defaultDpi: 392,
		touchHz: 180,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "infinix-hot-40",
		brand: "Infinix",
		name: "Hot 40",
		aliases: ["X6836", "Hot 40"],
		soc: "Mediatek Helio G88",
		gpu: "Mali-G52 MC2",
		cores: 8,
		maxFreqKhz: [
			2e6,
			2e6,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5
		],
		ramOptionsGb: [8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 256,
		inches: 6.78,
		resolution: [1080, 2460],
		refreshRates: [60, 90],
		defaultDpi: 396,
		touchHz: 180,
		abi: "arm64-v8a",
		androidVersion: "13"
	}),
	d({
		id: "infinix-note-40",
		brand: "Infinix",
		name: "Note 40",
		aliases: ["X6853", "Note 40"],
		soc: "Dimensity 7020",
		gpu: "IMG BXM-8-256",
		cores: 8,
		maxFreqKhz: [
			22e5,
			22e5,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 256,
		inches: 6.78,
		resolution: [1080, 2436],
		refreshRates: [60, 120],
		defaultDpi: 396,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "infinix-gt20-pro",
		brand: "Infinix",
		name: "GT 20 Pro",
		aliases: ["X6871", "GT 20 Pro"],
		soc: "Dimensity 8200 Ultimate",
		gpu: "Mali-G610 MC6",
		cores: 8,
		maxFreqKhz: [
			31e5,
			31e5,
			31e5,
			31e5,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [8, 12],
		typicalRamGb: 8,
		ramType: "LPDDR5",
		storageType: "UFS 3.1",
		typicalStorageGb: 256,
		inches: 6.78,
		resolution: [1080, 2436],
		refreshRates: [60, 144],
		defaultDpi: 396,
		touchHz: 360,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "tecno-spark-20",
		brand: "Tecno",
		name: "Spark 20",
		aliases: ["KJ5", "Spark 20"],
		soc: "Mediatek Helio G85",
		gpu: "Mali-G52 MC2",
		cores: 8,
		maxFreqKhz: [
			2e6,
			2e6,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5
		],
		ramOptionsGb: [8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.6,
		resolution: [720, 1612],
		refreshRates: [60, 90],
		defaultDpi: 266,
		touchHz: 180,
		abi: "arm64-v8a",
		androidVersion: "13"
	}),
	d({
		id: "tecno-pova-6",
		brand: "Tecno",
		name: "Pova 6",
		aliases: ["LJ7", "Pova 6"],
		soc: "Dimensity 6080",
		gpu: "Mali-G57 MC2",
		cores: 8,
		maxFreqKhz: [
			24e5,
			22e5,
			22e5,
			22e5,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 256,
		inches: 6.78,
		resolution: [1080, 2436],
		refreshRates: [60, 120],
		defaultDpi: 396,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "realme-c67",
		brand: "Realme",
		name: "C67",
		aliases: [
			"RMX3092",
			"C67",
			"realme C67"
		],
		soc: "Snapdragon 685",
		gpu: "Adreno 610",
		cores: 8,
		maxFreqKhz: [
			28e5,
			24e5,
			24e5,
			24e5,
			19e5,
			19e5,
			19e5,
			19e5
		],
		ramOptionsGb: [6, 8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.72,
		resolution: [1080, 2400],
		refreshRates: [60, 120],
		defaultDpi: 391,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "realme-c55",
		brand: "Realme",
		name: "C55",
		aliases: ["RMX3710", "C55"],
		soc: "Mediatek Helio G88",
		gpu: "Mali-G52 MC2",
		cores: 8,
		maxFreqKhz: [
			2e6,
			2e6,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5,
			18e5
		],
		ramOptionsGb: [6, 8],
		typicalRamGb: 6,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.72,
		resolution: [1080, 2400],
		refreshRates: [60, 90],
		defaultDpi: 391,
		touchHz: 180,
		abi: "arm64-v8a",
		androidVersion: "13"
	}),
	d({
		id: "oppo-a78",
		brand: "Oppo",
		name: "A78",
		aliases: ["CPH2565", "A78"],
		soc: "Dimensity 700",
		gpu: "Mali-G57 MC2",
		cores: 8,
		maxFreqKhz: [
			22e5,
			22e5,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6,
			2e6
		],
		ramOptionsGb: [8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.43,
		resolution: [1080, 2400],
		refreshRates: [60, 90],
		defaultDpi: 409,
		touchHz: 180,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "vivo-y36",
		brand: "Vivo",
		name: "Y36",
		aliases: ["V2247", "Y36"],
		soc: "Snapdragon 680",
		gpu: "Adreno 610",
		cores: 8,
		maxFreqKhz: [
			24e5,
			24e5,
			24e5,
			24e5,
			19e5,
			19e5,
			19e5,
			19e5
		],
		ramOptionsGb: [8],
		typicalRamGb: 8,
		ramType: "LPDDR4X",
		storageType: "UFS 2.2",
		typicalStorageGb: 128,
		inches: 6.64,
		resolution: [1080, 2388],
		refreshRates: [60, 90],
		defaultDpi: 395,
		touchHz: 180,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "oneplus-12r",
		brand: "OnePlus",
		name: "12R",
		aliases: [
			"CPH2585",
			"12R",
			"OnePlus 12R"
		],
		soc: "Snapdragon 8 Gen 2",
		gpu: "Adreno 740",
		cores: 8,
		maxFreqKhz: [
			318e4,
			272e4,
			272e4,
			272e4,
			201e4,
			201e4,
			201e4,
			201e4
		],
		ramOptionsGb: [8, 16],
		typicalRamGb: 16,
		ramType: "LPDDR5X",
		storageType: "UFS 3.1",
		typicalStorageGb: 256,
		inches: 6.78,
		resolution: [1264, 2780],
		refreshRates: [60, 120],
		defaultDpi: 450,
		touchHz: 720,
		abi: "arm64-v8a",
		androidVersion: "14"
	}),
	d({
		id: "pixel-8",
		brand: "Google",
		name: "Pixel 8",
		aliases: ["Pixel 8", "shiba"],
		soc: "Google Tensor G3",
		gpu: "Mali-G715 MP7",
		cores: 9,
		maxFreqKhz: [
			291e4,
			291e4,
			24e5,
			24e5,
			24e5,
			24e5,
			17e5,
			17e5,
			17e5
		],
		ramOptionsGb: [8],
		typicalRamGb: 8,
		ramType: "LPDDR5X",
		storageType: "UFS 3.1",
		typicalStorageGb: 128,
		inches: 6.2,
		resolution: [1080, 2400],
		refreshRates: [60, 120],
		defaultDpi: 428,
		touchHz: 240,
		abi: "arm64-v8a",
		androidVersion: "15"
	}),
	d({
		id: "iphone-15",
		brand: "Apple",
		name: "iPhone 15",
		aliases: ["iPhone15,4", "iPhone 15"],
		soc: "Apple A16",
		gpu: "Apple GPU (5-core)",
		cores: 6,
		maxFreqKhz: [
			346e4,
			346e4,
			202e4,
			202e4,
			202e4,
			202e4
		],
		ramOptionsGb: [6],
		typicalRamGb: 6,
		ramType: "LPDDR5",
		storageType: "NVMe",
		typicalStorageGb: 128,
		inches: 6.1,
		resolution: [1179, 2556],
		refreshRates: [60],
		defaultDpi: 460,
		touchHz: 120,
		abi: "arm64-v8a",
		androidVersion: "iOS"
	})
];
function findCatalogDevice(query) {
	const q = query.toLowerCase().replace(/\s+/g, " ").trim();
	if (!q) return null;
	let best = null;
	let bestScore = 0;
	for (const device of CATALOG) {
		const hay = [
			device.id,
			device.brand,
			device.name,
			...device.aliases
		].join(" ").toLowerCase();
		if (hay === q || device.aliases.some((a) => a.toLowerCase() === q)) return device;
		if (hay.includes(q) || q.includes(device.name.toLowerCase())) {
			const score = device.name.length;
			if (score > bestScore) {
				best = device;
				bestScore = score;
			}
		}
	}
	return best;
}
function searchCatalog(query) {
	const q = query.toLowerCase().trim();
	if (!q) return CATALOG;
	return CATALOG.filter((d) => [
		d.brand,
		d.name,
		d.soc,
		...d.aliases
	].join(" ").toLowerCase().includes(q));
}
function safe(fn, fallback) {
	try {
		return fn();
	} catch {
		return fallback;
	}
}
async function safeAsync(fn, fallback) {
	try {
		return await fn();
	} catch {
		return fallback;
	}
}
function snapHz(raw) {
	const common = [
		60,
		90,
		120,
		144,
		165,
		180,
		240
	];
	let best = common[0];
	for (const c of common) if (Math.abs(c - raw) < Math.abs(best - raw)) best = c;
	return Math.abs(best - raw) < 18 ? best : Math.max(30, Math.round(raw));
}
async function measureRefreshRate() {
	if (typeof window === "undefined") return 60;
	const hinted = window.screen.refreshRate;
	if (hinted && hinted >= 30) return snapHz(hinted);
	return new Promise((resolve) => {
		const deltas = [];
		let last = 0;
		let frames = 0;
		const start = performance.now();
		const tick = (t) => {
			if (last > 0) deltas.push(t - last);
			last = t;
			frames += 1;
			if (frames < 70 && performance.now() - start < 1400) requestAnimationFrame(tick);
			else {
				if (deltas.length < 10) {
					resolve(60);
					return;
				}
				const sorted = [...deltas].sort((a, b) => a - b);
				resolve(snapHz(1e3 / (sorted[Math.floor(sorted.length / 2)] || 16.67)));
			}
		};
		requestAnimationFrame(tick);
	});
}
function readGpu() {
	return safe(() => {
		const canvas = document.createElement("canvas");
		const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
		if (!gl) return "Unavailable";
		const ext = gl.getExtension("WEBGL_debug_renderer_info");
		if (ext) return gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || "Unavailable";
		return gl.getParameter(gl.RENDERER) || "Unavailable";
	}, "Unavailable");
}
async function readUaHints() {
	const nav = navigator;
	const fallback = {
		model: "",
		platform: navigator.platform || "",
		platformVersion: "",
		architecture: "",
		bitness: "",
		brands: ""
	};
	if (!nav.userAgentData?.getHighEntropyValues) return fallback;
	const values = await safeAsync(() => nav.userAgentData.getHighEntropyValues([
		"model",
		"platform",
		"platformVersion",
		"architecture",
		"bitness",
		"fullVersionList"
	]), {});
	return {
		model: String(values.model ?? ""),
		platform: String(values.platform ?? fallback.platform),
		platformVersion: String(values.platformVersion ?? ""),
		architecture: String(values.architecture ?? ""),
		bitness: String(values.bitness ?? ""),
		brands: Array.isArray(values.fullVersionList) ? values.fullVersionList.map((b) => `${b.brand} ${b.version}`).join(", ") : ""
	};
}
function parseAndroidVersion(ua, platformVersion) {
	if (platformVersion && /^\d+/.test(platformVersion)) {
		const major = platformVersion.split(".")[0];
		const sdk = Number(major);
		if (sdk >= 21 && sdk <= 40) return {
			34: "14",
			35: "15",
			36: "16",
			33: "13",
			32: "12",
			31: "12",
			30: "11",
			29: "10"
		}[sdk] ?? String(sdk);
		return platformVersion;
	}
	const m = ua.match(/Android\s([\d.]+)/i);
	if (m) return m[1];
	const ios = ua.match(/OS\s([\d_]+)\s+like\sMac/i);
	if (ios) return `iOS ${ios[1].replace(/_/g, ".")}`;
	return "Unavailable";
}
function parseModelFromUa(ua) {
	const android = ua.match(/Android.*;\s*([^)]+)\)/i);
	if (android) {
		const token = android[1].replace(/\s+Build\/.*$/, "").trim();
		return {
			manufacturer: token.split(" ")[0] || "Unknown",
			model: token
		};
	}
	const iphone = ua.match(/iPhone|iPad/);
	if (iphone) return {
		manufacturer: "Apple",
		model: iphone[0]
	};
	return {
		manufacturer: "Unknown",
		model: "This device"
	};
}
async function readBattery() {
	const nav = navigator;
	if (!nav.getBattery) return {
		level: null,
		temp: null
	};
	const bat = await safeAsync(() => nav.getBattery(), null);
	if (!bat) return {
		level: null,
		temp: null
	};
	return {
		level: Math.round(bat.level * 100),
		temp: null
	};
}
function estimateInches(widthPx, heightPx, dpi) {
	const d = Math.hypot(widthPx, heightPx) / Math.max(dpi, 120);
	return {
		inches: Math.round(d * 10) / 10,
		estimated: true
	};
}
function profileFromCatalog(device, live, source) {
	const soc = classifySoc(device.soc);
	const gpuClass = classifySoc(device.gpu);
	const width = live.displayWidth || device.resolution[0];
	const height = live.displayHeight || device.resolution[1];
	const ramGb = live.ramGb && device.ramOptionsGb.includes(Math.round(live.ramGb)) ? Math.round(live.ramGb) : device.typicalRamGb;
	return {
		manufacturer: device.brand,
		model: device.name,
		androidVersion: live.androidVersion || device.androidVersion,
		securityPatch: live.securityPatch || "Unavailable",
		socName: device.soc,
		socFamily: soc.family,
		cpuTier: soc.tier,
		cpuCores: device.cores,
		cpuMaxFreqKhz: device.maxFreqKhz,
		abi: device.abi,
		gpuName: device.gpu,
		gpuTier: gpuClass.tier,
		ramGb,
		ramAvailableGb: live.ramAvailableGb ?? Math.max(1, ramGb - 1.4),
		ramType: device.ramType,
		ramTypeEstimated: false,
		storageGb: device.typicalStorageGb,
		storageType: device.storageType,
		storageTypeEstimated: false,
		displayWidth: width,
		displayHeight: height,
		displayInches: device.inches,
		displayInchesEstimated: false,
		refreshRate: live.refreshRate && device.refreshRates.includes(live.refreshRate) ? live.refreshRate : Math.max(...device.refreshRates),
		supportedRefreshRates: device.refreshRates,
		densityDpi: live.densityDpi || device.defaultDpi,
		defaultDpi: device.defaultDpi,
		touchSamplingHz: live.touchSamplingHz && !live.touchSamplingEstimated ? live.touchSamplingHz : device.touchHz,
		touchSamplingEstimated: !(live.touchSamplingHz && !live.touchSamplingEstimated),
		batteryLevel: live.batteryLevel ?? null,
		batteryTempC: live.batteryTempC ?? null,
		thermalStatus: live.thermalStatus ?? "unavailable",
		source,
		catalogId: device.id,
		notes: live.notes ?? []
	};
}
async function scanThisDevice() {
	const notes = [];
	const ua = safe(() => navigator.userAgent, "");
	const hints = await readUaHints();
	const gpu = readGpu();
	const cores = safe(() => navigator.hardwareConcurrency || 0, 0);
	const deviceMemory = safe(() => {
		return navigator.deviceMemory ?? 0;
	}, 0);
	const dpr = safe(() => window.devicePixelRatio || 1, 1);
	const cssW = safe(() => window.screen.width || window.innerWidth, 390);
	const cssH = safe(() => window.screen.height || window.innerHeight, 844);
	const widthPx = Math.round(cssW * dpr);
	const heightPx = Math.round(cssH * dpr);
	const densityDpi = Math.round(160 * dpr);
	const { inches, estimated: inchesEstimated } = estimateInches(widthPx, heightPx, densityDpi);
	const refreshRate = await measureRefreshRate();
	const battery = await readBattery();
	const androidVersion = parseAndroidVersion(ua, hints.platformVersion);
	const parsed = parseModelFromUa(ua);
	const manufacturer = hints.model ? parsed.manufacturer : parsed.manufacturer;
	const model = hints.model || parsed.model;
	const matchQuery = [
		hints.model,
		model,
		parsed.model,
		ua
	].filter(Boolean).join(" ");
	let catalog = null;
	if (hints.model) catalog = findCatalogDevice(hints.model);
	if (!catalog) catalog = findCatalogDevice(model);
	if (!catalog) {
		for (const device of CATALOG) if (device.aliases.some((a) => matchQuery.toLowerCase().includes(a.toLowerCase()))) {
			catalog = device;
			break;
		}
	}
	const gpuClass = classifyGpuRenderer(gpu) ?? classifySoc(gpu);
	const socClass = catalog ? classifySoc(catalog.soc) : gpuClass;
	let ramGb = deviceMemory || 0;
	if (!ramGb) {
		ramGb = socClass.tier === "flagship" ? 8 : socClass.tier === "upper-mid" ? 8 : socClass.tier === "mid" ? 6 : 4;
		notes.push("RAM estimated from SoC tier — navigator.deviceMemory is unavailable.");
	}
	const touchEstimate = refreshRate >= 144 ? 360 : refreshRate >= 120 ? 240 : refreshRate >= 90 ? 180 : 120;
	if (!catalog) notes.push("SoC name is inferred from the GPU renderer. Pick your phone from the catalog for exact silicon, UFS vs eMMC, and core clocks.");
	if (gpu === "Unavailable") notes.push("GPU renderer blocked by this browser.");
	notes.push("Thermal status and per-core clocks need the native Android build.");
	const live = {
		androidVersion,
		displayWidth: widthPx,
		displayHeight: heightPx,
		densityDpi,
		refreshRate,
		ramGb,
		ramAvailableGb: deviceMemory ? Math.max(.8, deviceMemory * .55) : ramGb * .55,
		batteryLevel: battery.level,
		batteryTempC: battery.temp,
		thermalStatus: "unavailable",
		touchSamplingHz: touchEstimate,
		touchSamplingEstimated: true,
		notes
	};
	if (catalog) {
		const merged = profileFromCatalog(catalog, live, "hybrid");
		merged.gpuName = gpu !== "Unavailable" ? gpu : catalog.gpu;
		merged.notes = notes;
		if (cores) merged.cpuCores = cores;
		return merged;
	}
	const abi = hints.architecture ? hints.bitness === "64" || hints.architecture.includes("arm") ? "arm64-v8a" : hints.architecture : /aarch64|arm64|win64|x86_64/.test(ua + hints.architecture) ? "arm64-v8a" : "Unavailable";
	const isDesktop = !/android|iphone|ipad|mobile/i.test(ua) && !hints.model;
	return {
		manufacturer: isDesktop ? "Desktop browser" : manufacturer || "Unknown",
		model: isDesktop ? "Unknown phone — pick one below" : model || "Unknown",
		androidVersion,
		securityPatch: "Unavailable",
		socName: socClass.label || gpu || "Unavailable",
		socFamily: socClass.family,
		cpuTier: socClass.tier,
		cpuCores: cores || 8,
		cpuMaxFreqKhz: [],
		abi,
		gpuName: gpu,
		gpuTier: gpuClass.tier,
		ramGb,
		ramAvailableGb: live.ramAvailableGb ?? ramGb * .55,
		ramType: socClass.ramType,
		ramTypeEstimated: true,
		storageGb: null,
		storageType: socClass.storageType,
		storageTypeEstimated: true,
		displayWidth: widthPx,
		displayHeight: heightPx,
		displayInches: inches,
		displayInchesEstimated: inchesEstimated,
		refreshRate,
		supportedRefreshRates: [refreshRate],
		densityDpi,
		defaultDpi: densityDpi,
		touchSamplingHz: touchEstimate,
		touchSamplingEstimated: true,
		batteryLevel: battery.level,
		batteryTempC: battery.temp,
		thermalStatus: "unavailable",
		source: "scan",
		catalogId: null,
		notes
	};
}
function applyCatalogDevice(device, previous) {
	return profileFromCatalog(device, {
		androidVersion: previous?.androidVersion,
		displayWidth: previous?.displayWidth,
		displayHeight: previous?.displayHeight,
		densityDpi: previous?.densityDpi,
		refreshRate: previous?.refreshRate,
		ramGb: previous?.source === "scan" ? void 0 : previous?.ramGb,
		ramAvailableGb: previous?.ramAvailableGb,
		batteryLevel: previous?.batteryLevel ?? null,
		batteryTempC: previous?.batteryTempC ?? null,
		thermalStatus: previous?.thermalStatus,
		touchSamplingHz: previous?.touchSamplingEstimated ? void 0 : previous?.touchSamplingHz,
		touchSamplingEstimated: previous?.touchSamplingEstimated,
		notes: ["Catalog profile applied. Battery and live refresh still come from this session where available."]
	}, previous ? "hybrid" : "catalog");
}
function applyTouchHz(profile, hz) {
	return {
		...profile,
		touchSamplingHz: snapHz(hz),
		touchSamplingEstimated: false
	};
}
var STRINGS = {
	en: {
		app: "Caliber",
		tagline: "Hardware-tuned Free Fire settings",
		scanCta: "Scan this device",
		pickPhone: "Pick your phone",
		scanning: "Probing hardware",
		specs: "Device specs",
		settings: "FF settings",
		touch: "Touch test",
		copy: "Copy all settings",
		copied: "Copied",
		share: "Share",
		rescan: "Re-scan",
		score: "Performance score",
		general: "General",
		redDot: "Red Dot",
		scope2x: "2x Scope",
		scope4x: "4x Scope",
		awm: "AWM Scope",
		freeLook: "Free Look",
		dpi: "Recommended DPI",
		fireBtn: "Fire button size",
		originalDpi: "Note the original DPI so you can restore it",
		adb: "ADB command",
		restore: "Restore",
		smallestWidth: "Developer options → Smallest width",
		graphics: "Graphics preset",
		fps: "FPS option",
		highFps: "High FPS",
		on: "ON",
		off: "OFF",
		tips: "Tips",
		cpu: "CPU",
		gpu: "GPU",
		ram: "RAM",
		storage: "Storage",
		display: "Display",
		battery: "Battery",
		thermal: "Thermal",
		android: "System",
		cores: "cores",
		estimated: "estimated",
		unavailable: "Unavailable",
		searchPhone: "Search brand or model",
		touchHint: "Drag a finger across this pad for 4 seconds. We measure the interval between motion events.",
		touchStart: "Hold and drag here",
		touchResult: "Measured sampling rate",
		applyTouch: "Use this rate",
		measuring: "Measuring…",
		downloadApk: "Android Studio project",
		sensitivity: "Sensitivity",
		of200: "/ 200",
		catalogHint: "Browser APIs cannot read /proc/cpuinfo. Pick the exact phone for core clocks, UFS vs eMMC, and DRAM type.",
		dpiWarn: "Write down your current DPI before applying. Too-high density shrinks every tap target. Restore with the reset command if the UI looks wrong.",
		howToApply: "How to apply DPI",
		stepAdb: "From a computer with USB debugging: run the ADB command below.",
		stepManual: "On the phone: Settings → Developer options → Smallest width → paste the number.",
		language: "العربية",
		homeKicker: "Free Fire optimizer",
		homeLead: "Read the silicon. Get sensitivity, DPI, and fire-button size that match this panel — not a YouTuber’s phone.",
		featured: "Jump in with a common phone",
		scanSub: "CPU · GPU · RAM · display · battery",
		patch: "Security patch",
		abi: "ABI",
		freq: "Max clocks",
		available: "available",
		sourceScan: "Live scan",
		sourceCatalog: "Phone catalog",
		sourceHybrid: "Scan + catalog",
		breakdown: "Score mix",
		shareTitle: "My Caliber Free Fire settings",
		noShare: "Sharing is blocked here — settings are on the clipboard instead.",
		ramType: "DRAM",
		refresh: "Refresh",
		touchRate: "Touch rate",
		inches: "in",
		buildGuide: "Build the APK",
		buildBody: "The live app here uses browser hardware APIs plus a phone catalog. The native Kotlin project (Compose, minSdk 24, no INTERNET permission) reads Build.*, /proc/cpuinfo, sysfs clocks, OpenGL, MemoryInfo, and thermal status on a real device."
	},
	ar: {
		app: "كاليبر",
		tagline: "إعدادات فري فاير حسب عتاد جهازك",
		scanCta: "افحص هذا الجهاز",
		pickPhone: "اختر هاتفك",
		scanning: "جاري فحص العتاد",
		specs: "المواصفات",
		settings: "إعدادات فري فاير",
		touch: "اختبار اللمس",
		copy: "نسخ كل الإعدادات",
		copied: "تم النسخ",
		share: "مشاركة",
		rescan: "إعادة الفحص",
		score: "درجة الأداء",
		general: "عام",
		redDot: "النقطة الحمراء",
		scope2x: "سكوب 2x",
		scope4x: "سكوب 4x",
		awm: "سكوب AWM",
		freeLook: "النظر الحر",
		dpi: "DPI الموصى به",
		fireBtn: "حجم زر الإطلاق",
		originalDpi: "احفظ قيمة DPI الأصلية لتعيدها لاحقاً",
		adb: "أمر ADB",
		restore: "استعادة",
		smallestWidth: "خيارات المطوّر ← أصغر عرض",
		graphics: "إعداد الجرافيك",
		fps: "معدل الإطارات",
		highFps: "High FPS",
		on: "تشغيل",
		off: "إيقاف",
		tips: "نصائح",
		cpu: "المعالج",
		gpu: "المعالج الرسومي",
		ram: "الذاكرة",
		storage: "التخزين",
		display: "الشاشة",
		battery: "البطارية",
		thermal: "الحرارة",
		android: "النظام",
		cores: "أنوية",
		estimated: "تقديري",
		unavailable: "غير متاح",
		searchPhone: "ابحث بالشركة أو الموديل",
		touchHint: "اسحب إصبعك على اللوحة لمدة 4 ثوان. نقيس الفاصل بين أحداث الحركة.",
		touchStart: "اضغط واسحب هنا",
		touchResult: "معدل اللمس المقاس",
		applyTouch: "استخدم هذا المعدل",
		measuring: "جاري القياس…",
		downloadApk: "مشروع أندرويد ستوديو",
		sensitivity: "الحساسية",
		of200: "/ 200",
		catalogHint: "المتصفح لا يقرأ /proc/cpuinfo. اختر هاتفك بدقة لساعات الأنوية ونوع التخزين والذاكرة.",
		dpiWarn: "سجّل DPI الحالي قبل التغيير. الكثافة العالية تصغّر كل الأزرار. استخدم أمر الاستعادة إذا اختل شكل الواجهة.",
		howToApply: "طريقة تطبيق DPI",
		stepAdb: "من الكمبيوتر مع تصحيح USB: نفّذ أمر ADB أدناه.",
		stepManual: "على الهاتف: الإعدادات ← خيارات المطوّر ← أصغر عرض ← ألصق الرقم.",
		language: "English",
		homeKicker: "محسّن فري فاير",
		homeLead: "نقرأ العتاد ونخرج حساسية وDPI وحجم زر إطلاق يناسب شاشتك — لا هاتف صانع المحتوى.",
		featured: "ابدأ بهاتف شائع",
		scanSub: "معالج · رسوميات · ذاكرة · شاشة · بطارية",
		patch: "تصحيح الأمان",
		abi: "ABI",
		freq: "أقصى تردد",
		available: "متاح",
		sourceScan: "فحص مباشر",
		sourceCatalog: "كتالوج الهواتف",
		sourceHybrid: "فحص + كتالوج",
		breakdown: "توزيع الدرجة",
		shareTitle: "إعدادات كاليبر لفري فاير",
		noShare: "المشاركة غير متاحة هنا — نُسخت الإعدادات للحافظة.",
		ramType: "نوع الذاكرة",
		refresh: "التحديث",
		touchRate: "معدل اللمس",
		inches: "بوصة",
		buildGuide: "بناء ملف APK",
		buildBody: "النسخة هنا تستخدم واجهات المتصفح وكتالوج الهواتف. مشروع كوتلن الأصلي (Compose، minSdk 24، بدون صلاحية إنترنت) يقرأ Build وcpuinfo وتردد sysfs وOpenGL والذاكرة والحالة الحرارية على جهاز حقيقي."
	}
};
var LANG_KEY = "caliber-lang";
function commitHardware(hardware) {
	return {
		hardware,
		settings: generateSettings(hardware),
		scanError: null
	};
}
var useCaliber = create((set, get) => ({
	lang: "en",
	dict: STRINGS.en,
	phase: "home",
	tab: "specs",
	hardware: null,
	settings: null,
	scanError: null,
	pickerOpen: false,
	toggleLang: () => {
		const next = get().lang === "en" ? "ar" : "en";
		if (typeof window !== "undefined") window.localStorage.setItem(LANG_KEY, next);
		set({
			lang: next,
			dict: STRINGS[next]
		});
	},
	hydrateLang: () => {
		if (typeof window === "undefined") return;
		const saved = window.localStorage.getItem(LANG_KEY);
		const next = saved === "ar" || saved === "en" ? saved : navigator.language?.toLowerCase().startsWith("ar") ? "ar" : "en";
		if (next !== get().lang) set({
			lang: next,
			dict: STRINGS[next]
		});
	},
	setPhase: (phase) => set({ phase }),
	setTab: (tab) => set({ tab }),
	setPickerOpen: (pickerOpen) => set({ pickerOpen }),
	runScan: async () => {
		set({
			phase: "scanning",
			scanError: null
		});
		const started = Date.now();
		try {
			const hardware = await scanThisDevice();
			const wait = Math.max(0, 2400 - (Date.now() - started));
			if (wait) await new Promise((r) => setTimeout(r, wait));
			set({
				phase: "results",
				tab: "specs",
				...commitHardware(hardware)
			});
		} catch (err) {
			const wait = Math.max(0, 1800 - (Date.now() - started));
			if (wait) await new Promise((r) => setTimeout(r, wait));
			set({
				phase: "home",
				scanError: err instanceof Error ? err.message : "Scan failed"
			});
		}
	},
	pickDevice: (device) => {
		set({
			phase: "results",
			tab: "specs",
			pickerOpen: false,
			...commitHardware(applyCatalogDevice(device, get().hardware))
		});
	},
	setTouchHz: (hz) => {
		const current = get().hardware;
		if (!current) return;
		set(commitHardware(applyTouchHz(current, hz)));
	},
	reset: () => set({
		phase: "home",
		hardware: null,
		settings: null,
		tab: "specs",
		pickerOpen: false
	})
}));
var styles_default = "/assets/styles-CDd51LPZ.css";
var APP_NAME = "Caliber";
function LanguageDirSync() {
	const lang = useCaliber((s) => s.lang);
	const hydrateLang = useCaliber((s) => s.hydrateLang);
	(0, import_react.useEffect)(() => {
		hydrateLang();
	}, [hydrateLang]);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
		document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
	}, [lang]);
	return null;
}
var Route$1 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Hardware-tuned Free Fire sensitivity, DPI, and fire-button settings."
			},
			{
				name: "theme-color",
				content: "#0f172a"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Rajdhani:wght@500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "hex-grid antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageDirSync, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
						theme: "dark",
						position: "bottom-center"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter = () => import("./routes-DtRld4M3.mjs");
var rootRouteChildren = { IndexRoute: createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") }).update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$1
}) };
var routeTree = Route$1._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { TIER_LABEL as a, searchCatalog as i, useCaliber as n, classifySoc as o, CATALOG as r, formatSettingsText as s, router_exports as t };
