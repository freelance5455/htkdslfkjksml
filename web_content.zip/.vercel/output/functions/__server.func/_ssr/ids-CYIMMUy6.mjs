import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ids-CYIMMUy6.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-1vAx-gM_.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-DrjwcqIT.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var TOPICS = [
	"Ngobrol",
	"Musik",
	"Masak",
	"Game",
	"Belajar",
	"Gaya"
];
var GIFTS = [
	{
		id: "api",
		name: "Api",
		coins: 10,
		icon: "flame"
	},
	{
		id: "kuncup",
		name: "Kuncup",
		coins: 30,
		icon: "flower"
	},
	{
		id: "mahkota",
		name: "Mahkota",
		coins: 120,
		icon: "crown"
	},
	{
		id: "roket",
		name: "Roket",
		coins: 400,
		icon: "rocket"
	},
	{
		id: "panggung",
		name: "Panggung",
		coins: 1200,
		icon: "spark"
	}
];
function giftById(id) {
	return GIFTS.find((gift) => gift.id === id) ?? null;
}
var FILTERS = [
	{
		id: "jernih",
		label: "Jernih",
		css: "none"
	},
	{
		id: "hangat",
		label: "Hangat",
		css: "saturate(1.25) contrast(1.05) sepia(0.18)"
	},
	{
		id: "adem",
		label: "Adem",
		css: "saturate(0.85) contrast(1.08) hue-rotate(12deg)"
	},
	{
		id: "lembut",
		label: "Lembut",
		css: "contrast(0.92) brightness(1.08) saturate(0.9)"
	},
	{
		id: "tegas",
		label: "Tegas",
		css: "contrast(1.2) saturate(1.15)"
	},
	{
		id: "film",
		label: "Film",
		css: "grayscale(0.85) contrast(1.1)"
	}
];
var ROOM_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789";
function makeCode(len) {
	const bytes = new Uint8Array(len);
	crypto.getRandomValues(bytes);
	let out = "";
	for (const b of bytes) out += ROOM_ALPHABET[b % 31];
	return out;
}
function makePeerId() {
	const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
	const bytes = /* @__PURE__ */ new Uint8Array(12);
	crypto.getRandomValues(bytes);
	let out = "p";
	for (const b of bytes) out += alphabet[b % 36];
	return out;
}
function clip(value, max) {
	return value.replace(/\s+/g, " ").trim().slice(0, max);
}
//#endregion
export { clip as a, makePeerId as c, authMiddleware as i, GIFTS as n, giftById as o, TOPICS as r, makeCode as s, FILTERS as t };
