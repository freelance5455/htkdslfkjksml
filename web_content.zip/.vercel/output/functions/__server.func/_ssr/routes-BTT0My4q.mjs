import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, t as array } from "../_libs/zod.mjs";
import { a as RefreshCw, c as ArrowLeftRight, i as TrendingUp, n as Wallet, o as ChartPie, s as ChartLine, t as X } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as Line, c as Cell, i as XAxis, l as ResponsiveContainer, n as LineChart, o as CartesianGrid, r as YAxis, s as Pie, t as PieChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BTT0My4q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				fill: "var(--color-fg)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "9",
				fill: "none",
				stroke: "var(--color-bg)",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "3.5",
				fill: "var(--color-primary)"
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-xs text-muted",
			children: label
		}), children]
	});
}
function Segment({ value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid rounded-lg bg-surface-2 p-1",
		style: { gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` },
		children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-pressed": value === option.id,
			className: cn("h-11 rounded-md text-sm", value === option.id ? "bg-surface font-medium text-fg" : "text-muted"),
			onClick: () => onChange(option.id),
			children: option.label
		}, option.id))
	});
}
function Sheet({ open, title, onClose, children }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-fg/40",
			"aria-label": "닫기",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet-panel relative z-10 flex w-full max-w-lg flex-col overflow-hidden rounded-t-xl bg-surface sm:rounded-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center text-muted",
					onClick: onClose,
					"aria-label": "닫기",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-y-auto px-4 py-4",
				children
			})]
		})]
	});
}
function PnlText({ value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("tabular-nums", value > 0 ? "text-up" : value < 0 ? "text-down" : "text-muted"),
		children
	});
}
function formatKrw(n) {
	return `${(Number.isFinite(n) ? Math.round(n) : 0).toLocaleString("ko-KR")}원`;
}
function formatMan(n) {
	const sign = n < 0 ? "-" : "";
	const abs = Math.abs(n);
	if (!Number.isFinite(abs)) return "0원";
	if (abs >= 1e8) {
		const eok = abs / 1e8;
		const digits = eok >= 100 ? 0 : eok >= 10 ? 1 : 2;
		return `${sign}${eok.toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d*?)0+$/, "$1")}억`;
	}
	if (abs >= 1e4) return `${sign}${Math.round(abs / 1e4).toLocaleString("ko-KR")}만`;
	return `${sign}${Math.round(abs).toLocaleString("ko-KR")}원`;
}
function formatPct(n, digits = 1) {
	if (!Number.isFinite(n)) return "-";
	return `${n > 0 ? "+" : ""}${n.toFixed(digits)}%`;
}
function formatQty(n) {
	if (!Number.isFinite(n)) return "0";
	if (Math.abs(n - Math.round(n)) < 1e-6) return Math.round(n).toLocaleString("ko-KR");
	return n.toLocaleString("ko-KR", { maximumFractionDigits: 4 });
}
function formatPrice(n, currency, precise = false) {
	if (!Number.isFinite(n)) return "-";
	if (currency === "USD") return `$${n.toLocaleString("en-US", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	})}`;
	if (precise || Math.abs(n) < 1e3) return `${n.toLocaleString("ko-KR", { maximumFractionDigits: 2 })}원`;
	return `${Math.round(n).toLocaleString("ko-KR")}원`;
}
function formatIndex(n) {
	if (!Number.isFinite(n)) return "-";
	return n.toLocaleString("ko-KR", { maximumFractionDigits: 2 });
}
function ym(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function today(d = /* @__PURE__ */ new Date()) {
	return `${ym(d)}-${String(d.getDate()).padStart(2, "0")}`;
}
function shortMonth(month) {
	if (month.length < 7) return month;
	return `${month.slice(2, 4)}.${month.slice(5, 7)}`;
}
function parseNum(raw) {
	const t = raw.replace(/,/g, "").trim();
	if (!t) return null;
	const n = Number(t);
	return Number.isFinite(n) ? n : null;
}
function uid(prefix) {
	return `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
}
function monthsBack(count, end = /* @__PURE__ */ new Date()) {
	const out = [];
	const start = new Date(end.getFullYear(), end.getMonth(), 1);
	for (let i = count - 1; i >= 0; i -= 1) {
		const d = new Date(start.getFullYear(), start.getMonth() - i, 1);
		out.push(ym(d));
	}
	return out;
}
var ALIAS = {
	삼성전자: "005930.KS",
	삼성전자우: "005935.KS",
	SK하이닉스: "000660.KS",
	하이닉스: "000660.KS",
	KODEX200: "069500.KS",
	코덱스200: "069500.KS",
	맥쿼리인프라: "088980.KS"
};
function cleanSymbol(raw) {
	const trimmed = raw.trim();
	if (!trimmed) return "";
	const compact = trimmed.replace(/\s+/g, "");
	const alias = ALIAS[trimmed] ?? ALIAS[compact] ?? ALIAS[compact.toUpperCase()];
	if (alias) return alias;
	const upper = trimmed.toUpperCase();
	if (/^\d{6}$/.test(upper)) return `${upper}.KS`;
	return upper;
}
function isSafeSymbol(symbol) {
	return /^[A-Z0-9.^=-]{1,20}$/.test(symbol);
}
var CLASS_COLORS = [
	"var(--color-c1)",
	"var(--color-c2)",
	"var(--color-c3)",
	"var(--color-c4)",
	"var(--color-c5)",
	"var(--color-c6)",
	"var(--color-c7)",
	"var(--color-c8)",
	"var(--color-c9)",
	"var(--color-c10)",
	"var(--color-c11)",
	"var(--color-c12)"
];
var SHAPE = [
	.68,
	.7,
	.69,
	.72,
	.74,
	.73,
	.76,
	.79,
	.77,
	.81,
	.83,
	.82,
	.85,
	.87,
	.86,
	.89,
	.91,
	.9,
	.93,
	.95,
	.94,
	.97,
	.985,
	1
];
function fxMult(currency, fx) {
	return currency === "USD" ? fx : 1;
}
function holdingValue(h, fx) {
	if (h.quantity <= 0) return 0;
	return h.quantity * h.currentPrice * fxMult(h.currency, fx);
}
function holdingCost(h, fx) {
	if (h.quantity <= 0) return 0;
	return h.quantity * h.avgPrice * fxMult(h.currency, fx);
}
function portfolioValue(holdings, fx) {
	return holdings.reduce((sum, h) => sum + holdingValue(h, fx), 0);
}
function portfolioCost(holdings, fx) {
	return holdings.reduce((sum, h) => sum + holdingCost(h, fx), 0);
}
function allocation(holdings, classes, fx) {
	const total = portfolioValue(holdings, fx);
	return classes.map((c) => {
		const value = holdings.filter((h) => h.classId === c.id).reduce((sum, h) => sum + holdingValue(h, fx), 0);
		const pct = total > 0 ? value / total * 100 : 0;
		const gapPct = c.target - pct;
		return {
			id: c.id,
			name: c.name,
			color: c.color,
			target: c.target,
			expectedReturn: c.expectedReturn,
			value,
			pct,
			gapPct,
			gapKrw: gapPct / 100 * total
		};
	});
}
function weightedExpectedReturn(rows) {
	const total = rows.reduce((sum, row) => sum + row.value, 0);
	if (total > 0) return rows.reduce((sum, row) => sum + row.expectedReturn * row.value, 0) / total;
	const targetSum = rows.reduce((sum, row) => sum + row.target, 0);
	if (targetSum <= 0) return 0;
	return rows.reduce((sum, row) => sum + row.expectedReturn * row.target, 0) / targetSum;
}
function resolveRates(computed, settings) {
	const average = settings.average ?? computed;
	return {
		average,
		pessimistic: settings.pessimistic ?? average - 4,
		optimistic: settings.optimistic ?? average + 3,
		averageAuto: settings.average == null,
		pessimisticAuto: settings.pessimistic == null,
		optimisticAuto: settings.optimistic == null
	};
}
function futureValue(pv, annualPct, monthly, years) {
	const n = Math.max(0, Math.round(years * 12));
	const r = annualPct / 100 / 12;
	if (n === 0) return pv;
	if (Math.abs(r) < 1e-8) return pv + monthly * n;
	const growth = (1 + r) ** n;
	return pv * growth + monthly * ((growth - 1) / r);
}
function round4(n) {
	return Math.round(n * 1e4) / 1e4;
}
function upsertSnapshot(snapshots, month, value) {
	const nextValue = Math.round(value);
	const idx = snapshots.findIndex((item) => item.month === month);
	if (idx === -1) return [...snapshots, {
		month,
		value: nextValue
	}].sort((a, b) => a.month.localeCompare(b.month));
	if (snapshots[idx]?.value === nextValue) return snapshots;
	const next = snapshots.slice();
	next[idx] = {
		month,
		value: nextValue
	};
	return next;
}
function buildSnapshots(total, end = /* @__PURE__ */ new Date()) {
	return monthsBack(SHAPE.length, end).map((month, index) => ({
		month,
		value: Math.round(total * (SHAPE[index] ?? 1))
	}));
}
function nextColor(classes) {
	return CLASS_COLORS[classes.length % CLASS_COLORS.length] ?? CLASS_COLORS[0];
}
var FX = 1336.33;
function holding(input) {
	return input;
}
function trade(input) {
	const mult = input.currency === "USD" ? FX : 1;
	const amountKrw = Math.round(input.quantity * input.price * mult);
	const realizedKrw = input.kind === "sell" ? Math.round((input.price - (input.avgPrice ?? input.price)) * input.quantity * mult) : 0;
	return {
		id: input.id,
		date: input.date,
		kind: input.kind,
		accountId: input.accountId,
		holdingId: input.holdingId,
		classId: input.classId,
		name: input.name,
		quantity: input.quantity,
		price: input.price,
		currency: input.currency,
		fx: FX,
		amountKrw,
		realizedKrw
	};
}
function dividend(input) {
	const mult = input.currency === "USD" ? FX : 1;
	return {
		id: input.id,
		date: input.date,
		kind: "dividend",
		accountId: input.accountId,
		holdingId: input.holdingId,
		classId: input.classId,
		name: input.name,
		quantity: input.quantity,
		price: input.amount,
		currency: input.currency,
		fx: FX,
		amountKrw: Math.round(input.amount * mult),
		realizedKrw: 0
	};
}
function seedHistory() {
	const months = monthsBack(24);
	const last = Math.max(1, months.length - 1);
	return months.map((month, index) => {
		const t = index / last;
		const wave = Math.sin(index * .85);
		return {
			month,
			fx: Math.round(FX * (.9 + .1 * t + wave * .012) * 100) / 100,
			sp500: Math.round(7743.98 * (.58 + .42 * t + wave * .018) * 100) / 100,
			nasdaq: Math.round(29813.16 * (.5 + .5 * t + wave * .024) * 100) / 100
		};
	});
}
function createSample() {
	const classes = [
		{
			id: "us-growth",
			name: "미국주식",
			target: 25,
			expectedReturn: 8,
			color: "var(--color-c1)"
		},
		{
			id: "us-div",
			name: "미국배당",
			target: 15,
			expectedReturn: 6,
			color: "var(--color-c2)"
		},
		{
			id: "kr-growth",
			name: "국내주식",
			target: 15,
			expectedReturn: 7,
			color: "var(--color-c3)"
		},
		{
			id: "kr-div",
			name: "국내배당",
			target: 8,
			expectedReturn: 5.5,
			color: "var(--color-c4)"
		},
		{
			id: "bond",
			name: "채권",
			target: 12,
			expectedReturn: 3.5,
			color: "var(--color-c5)"
		},
		{
			id: "reit",
			name: "리츠",
			target: 7,
			expectedReturn: 5,
			color: "var(--color-c6)"
		},
		{
			id: "gold",
			name: "금",
			target: 6,
			expectedReturn: 4,
			color: "var(--color-c7)"
		},
		{
			id: "usd",
			name: "달러",
			target: 5,
			expectedReturn: 2,
			color: "var(--color-c8)"
		},
		{
			id: "cash",
			name: "현금성자산",
			target: 7,
			expectedReturn: 3,
			color: "var(--color-c9)"
		}
	];
	const accounts = [
		{
			id: "mirae",
			name: "미래에셋증권"
		},
		{
			id: "kis",
			name: "한국투자증권"
		},
		{
			id: "toss",
			name: "토스뱅크"
		},
		{
			id: "kb",
			name: "KB국민은행"
		}
	];
	const holdings = [
		holding({
			id: "h-voo",
			accountId: "mirae",
			classId: "us-growth",
			name: "VOO",
			symbol: "VOO",
			currency: "USD",
			priceMode: "auto",
			quantity: 20,
			avgPrice: 620,
			currentPrice: 709.9
		}),
		holding({
			id: "h-qqq",
			accountId: "kis",
			classId: "us-growth",
			name: "QQQ",
			symbol: "QQQ",
			currency: "USD",
			priceMode: "auto",
			quantity: 8,
			avgPrice: 610,
			currentPrice: 725.61
		}),
		holding({
			id: "h-ima",
			accountId: "mirae",
			classId: "us-growth",
			name: "미래에셋 IMA",
			symbol: "",
			currency: "KRW",
			priceMode: "manual",
			quantity: 1,
			avgPrice: 7e6,
			currentPrice: 84e5
		}),
		holding({
			id: "h-schd",
			accountId: "mirae",
			classId: "us-div",
			name: "SCHD",
			symbol: "SCHD",
			currency: "USD",
			priceMode: "auto",
			quantity: 150,
			avgPrice: 31,
			currentPrice: 35.09
		}),
		holding({
			id: "h-jepi",
			accountId: "kis",
			classId: "us-div",
			name: "JEPI",
			symbol: "JEPI",
			currency: "USD",
			priceMode: "auto",
			quantity: 80,
			avgPrice: 54,
			currentPrice: 57.45
		}),
		holding({
			id: "h-sec",
			accountId: "kis",
			classId: "kr-growth",
			name: "삼성전자",
			symbol: "005930.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 40,
			avgPrice: 185e3,
			currentPrice: 231e3
		}),
		holding({
			id: "h-hynix",
			accountId: "kis",
			classId: "kr-growth",
			name: "SK하이닉스",
			symbol: "000660.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 5,
			avgPrice: 112e4,
			currentPrice: 1532e3
		}),
		holding({
			id: "h-kodex",
			accountId: "mirae",
			classId: "kr-growth",
			name: "KODEX 200",
			symbol: "069500.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 50,
			avgPrice: 82e3,
			currentPrice: 94330
		}),
		holding({
			id: "h-pref",
			accountId: "kis",
			classId: "kr-div",
			name: "삼성전자우",
			symbol: "005935.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 30,
			avgPrice: 155e3,
			currentPrice: 184300
		}),
		holding({
			id: "h-hdiv",
			accountId: "kis",
			classId: "kr-div",
			name: "PLUS 고배당",
			symbol: "161510.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 200,
			avgPrice: 19800,
			currentPrice: 22305
		}),
		holding({
			id: "h-bond",
			accountId: "kis",
			classId: "bond",
			name: "KODEX 국고채3년",
			symbol: "114260.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 120,
			avgPrice: 60500,
			currentPrice: 62385
		}),
		holding({
			id: "h-fund",
			accountId: "kb",
			classId: "bond",
			name: "KB 채권형 펀드",
			symbol: "",
			currency: "KRW",
			priceMode: "manual",
			quantity: 1,
			avgPrice: 58e5,
			currentPrice: 615e4
		}),
		holding({
			id: "h-mkif",
			accountId: "kis",
			classId: "reit",
			name: "맥쿼리인프라",
			symbol: "088980.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 400,
			avgPrice: 11200,
			currentPrice: 9440
		}),
		holding({
			id: "h-reit",
			accountId: "kis",
			classId: "reit",
			name: "TIGER 리츠부동산인프라",
			symbol: "329200.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 800,
			avgPrice: 4300,
			currentPrice: 3935
		}),
		holding({
			id: "h-gold",
			accountId: "mirae",
			classId: "gold",
			name: "ACE KRX금현물",
			symbol: "411060.KS",
			currency: "KRW",
			priceMode: "auto",
			quantity: 250,
			avgPrice: 18600,
			currentPrice: 24150
		}),
		holding({
			id: "h-usd",
			accountId: "mirae",
			classId: "usd",
			name: "달러 예금",
			symbol: "",
			currency: "KRW",
			priceMode: "fx",
			quantity: 4e3,
			avgPrice: 1280,
			currentPrice: FX
		}),
		holding({
			id: "h-park",
			accountId: "toss",
			classId: "cash",
			name: "토스 파킹통장",
			symbol: "",
			currency: "KRW",
			priceMode: "manual",
			quantity: 1,
			avgPrice: 8e6,
			currentPrice: 812e4
		}),
		holding({
			id: "h-save",
			accountId: "kb",
			classId: "cash",
			name: "KB 자유적금",
			symbol: "",
			currency: "KRW",
			priceMode: "manual",
			quantity: 1,
			avgPrice: 48e5,
			currentPrice: 492e4
		})
	];
	const txs = [
		trade({
			id: "t0a",
			date: "2024-06-12",
			kind: "buy",
			accountId: "mirae",
			holdingId: "h-voo",
			classId: "us-growth",
			name: "VOO",
			quantity: 8,
			price: 480,
			currency: "USD"
		}),
		dividend({
			id: "t0b",
			date: "2024-12-18",
			accountId: "mirae",
			holdingId: "h-schd",
			classId: "us-div",
			name: "SCHD",
			quantity: 130,
			amount: 34.2,
			currency: "USD"
		}),
		trade({
			id: "t0c",
			date: "2025-03-10",
			kind: "buy",
			accountId: "kis",
			holdingId: "h-sec",
			classId: "kr-growth",
			name: "삼성전자",
			quantity: 15,
			price: 168e3,
			currency: "KRW"
		}),
		trade({
			id: "t0d",
			date: "2025-09-04",
			kind: "buy",
			accountId: "mirae",
			holdingId: "h-gold",
			classId: "gold",
			name: "ACE KRX금현물",
			quantity: 80,
			price: 21400,
			currency: "KRW"
		}),
		dividend({
			id: "t0e",
			date: "2025-12-17",
			accountId: "mirae",
			holdingId: "h-schd",
			classId: "us-div",
			name: "SCHD",
			quantity: 150,
			amount: 37.4,
			currency: "USD"
		}),
		trade({
			id: "t1",
			date: "2026-01-15",
			kind: "buy",
			accountId: "mirae",
			holdingId: "h-voo",
			classId: "us-growth",
			name: "VOO",
			quantity: 2,
			price: 680,
			currency: "USD"
		}),
		dividend({
			id: "t2",
			date: "2026-01-20",
			accountId: "kis",
			holdingId: "h-hdiv",
			classId: "kr-div",
			name: "PLUS 고배당",
			quantity: 200,
			amount: 32e3,
			currency: "KRW"
		}),
		dividend({
			id: "t3",
			date: "2026-02-03",
			accountId: "kis",
			holdingId: "h-jepi",
			classId: "us-div",
			name: "JEPI",
			quantity: 80,
			amount: 29.6,
			currency: "USD"
		}),
		trade({
			id: "t4",
			date: "2026-03-03",
			kind: "buy",
			accountId: "kis",
			holdingId: "h-sec",
			classId: "kr-growth",
			name: "삼성전자",
			quantity: 5,
			price: 21e4,
			currency: "KRW"
		}),
		dividend({
			id: "t5",
			date: "2026-03-26",
			accountId: "mirae",
			holdingId: "h-schd",
			classId: "us-div",
			name: "SCHD",
			quantity: 150,
			amount: 39.15,
			currency: "USD"
		}),
		dividend({
			id: "t6",
			date: "2026-04-17",
			accountId: "kis",
			holdingId: "h-sec",
			classId: "kr-growth",
			name: "삼성전자",
			quantity: 40,
			amount: 1e5,
			currency: "KRW"
		}),
		dividend({
			id: "t7",
			date: "2026-04-20",
			accountId: "kis",
			holdingId: "h-hdiv",
			classId: "kr-div",
			name: "PLUS 고배당",
			quantity: 200,
			amount: 32e3,
			currency: "KRW"
		}),
		dividend({
			id: "t8",
			date: "2026-05-05",
			accountId: "kis",
			holdingId: "h-jepi",
			classId: "us-div",
			name: "JEPI",
			quantity: 80,
			amount: 29.6,
			currency: "USD"
		}),
		trade({
			id: "t9",
			date: "2026-05-20",
			kind: "buy",
			accountId: "mirae",
			holdingId: "h-schd",
			classId: "us-div",
			name: "SCHD",
			quantity: 20,
			price: 33,
			currency: "USD"
		}),
		trade({
			id: "t10",
			date: "2026-06-18",
			kind: "sell",
			accountId: "mirae",
			holdingId: "h-kodex",
			classId: "kr-growth",
			name: "KODEX 200",
			quantity: 10,
			price: 91e3,
			currency: "KRW",
			avgPrice: 82e3
		}),
		dividend({
			id: "t11",
			date: "2026-06-25",
			accountId: "mirae",
			holdingId: "h-schd",
			classId: "us-div",
			name: "SCHD",
			quantity: 150,
			amount: 39.15,
			currency: "USD"
		}),
		dividend({
			id: "t12",
			date: "2026-06-30",
			accountId: "kis",
			holdingId: "h-mkif",
			classId: "reit",
			name: "맥쿼리인프라",
			quantity: 400,
			amount: 6e4,
			currency: "KRW"
		}),
		dividend({
			id: "t13",
			date: "2026-07-20",
			accountId: "kis",
			holdingId: "h-hdiv",
			classId: "kr-div",
			name: "PLUS 고배당",
			quantity: 200,
			amount: 32e3,
			currency: "KRW"
		}),
		trade({
			id: "t14",
			date: "2026-08-12",
			kind: "buy",
			accountId: "kis",
			holdingId: "h-bond",
			classId: "bond",
			name: "KODEX 국고채3년",
			quantity: 20,
			price: 61500,
			currency: "KRW"
		}),
		dividend({
			id: "t15",
			date: "2026-08-04",
			accountId: "kis",
			holdingId: "h-jepi",
			classId: "us-div",
			name: "JEPI",
			quantity: 80,
			amount: 29.6,
			currency: "USD"
		}),
		dividend({
			id: "t16",
			date: "2026-09-24",
			accountId: "mirae",
			holdingId: "h-schd",
			classId: "us-div",
			name: "SCHD",
			quantity: 150,
			amount: 39.15,
			currency: "USD"
		}),
		dividend({
			id: "t17",
			date: "2026-10-02",
			accountId: "kis",
			holdingId: "h-jepi",
			classId: "us-div",
			name: "JEPI",
			quantity: 80,
			amount: 29.6,
			currency: "USD"
		}),
		dividend({
			id: "t18",
			date: "2026-10-20",
			accountId: "kis",
			holdingId: "h-hdiv",
			classId: "kr-div",
			name: "PLUS 고배당",
			quantity: 200,
			amount: 32e3,
			currency: "KRW"
		})
	].sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
	const fx = FX;
	return {
		isSample: true,
		accounts,
		classes,
		holdings,
		txs,
		snapshots: buildSnapshots(holdings.reduce((sum, item) => {
			if (item.quantity <= 0) return sum;
			const mult = item.currency === "USD" ? fx : 1;
			return sum + item.quantity * item.currentPrice * mult;
		}, 0)),
		market: {
			fx,
			sp500: 7743.98,
			nasdaq: 29813.16,
			updatedAt: null,
			history: seedHistory()
		},
		settings: {
			contribution: 1e6,
			years: 10,
			pessimistic: null,
			average: null,
			optimistic: null
		}
	};
}
function snapshot(holdings, fx, snapshots) {
	return upsertSnapshot(snapshots, ym(/* @__PURE__ */ new Date()), portfolioValue(holdings, fx));
}
function attachAccount(accounts, accountId, newAccountName) {
	if (accountId && accounts.some((account) => account.id === accountId)) return {
		accounts,
		accountId
	};
	const name = newAccountName?.trim() ?? "";
	if (!name) return { error: "계좌를 선택하거나 새 계좌 이름을 입력하세요." };
	const id = uid("a");
	return {
		accounts: [...accounts, {
			id,
			name
		}],
		accountId: id
	};
}
function makeTx(input) {
	return {
		...input,
		id: uid("t")
	};
}
var usePortfolio = create()(persist((set, get) => ({
	...createSample(),
	addAccount: (name) => {
		const trimmed = name.trim();
		if (!trimmed) return "계좌 이름을 입력하세요.";
		set((state) => ({
			isSample: false,
			accounts: [...state.accounts, {
				id: uid("a"),
				name: trimmed
			}]
		}));
		return null;
	},
	renameAccount: (id, name) => {
		const trimmed = name.trim();
		if (!trimmed) return;
		set((state) => ({
			isSample: false,
			accounts: state.accounts.map((account) => account.id === id ? {
				...account,
				name: trimmed
			} : account)
		}));
	},
	removeAccount: (id) => {
		if (get().holdings.some((holding) => holding.accountId === id && holding.quantity > 0)) return "종목이 있는 계좌는 지울 수 없습니다.";
		set((state) => ({
			isSample: false,
			accounts: state.accounts.filter((account) => account.id !== id)
		}));
		return null;
	},
	addClass: (name) => {
		const trimmed = name.trim() || "새 자산군";
		set((state) => ({
			isSample: false,
			classes: [...state.classes, {
				id: uid("c"),
				name: trimmed,
				target: 0,
				expectedReturn: 4,
				color: nextColor(state.classes)
			}]
		}));
	},
	updateClass: (id, patch) => {
		set((state) => ({
			isSample: false,
			classes: state.classes.map((item) => item.id === id ? {
				...item,
				...patch
			} : item)
		}));
	},
	removeClass: (id) => {
		const state = get();
		if (state.classes.length <= 1) return "자산군은 하나 이상 남겨 두세요.";
		if (state.holdings.some((holding) => holding.classId === id && holding.quantity > 0)) return "이 자산군을 쓰는 종목이 있어 지울 수 없습니다.";
		set({
			isSample: false,
			classes: state.classes.filter((item) => item.id !== id),
			holdings: state.holdings.map((holding) => holding.classId === id ? {
				...holding,
				classId: state.classes.find((item) => item.id !== id)?.id ?? id
			} : holding)
		});
		return null;
	},
	addHolding: (input) => {
		const state = get();
		const account = attachAccount(state.accounts, input.accountId, input.newAccountName);
		if ("error" in account) return account.error;
		if (!input.name.trim()) return "종목 이름을 입력하세요.";
		if (!(input.quantity > 0)) return "수량을 입력하세요.";
		if (!(input.currentPrice > 0) || !(input.avgPrice > 0)) return "평단과 현재가를 입력하세요.";
		const holding = {
			id: uid("h"),
			accountId: account.accountId,
			classId: input.classId,
			name: input.name.trim(),
			symbol: input.priceMode === "fx" ? "" : cleanSymbol(input.symbol),
			currency: input.priceMode === "fx" ? "KRW" : input.currency,
			priceMode: input.priceMode,
			quantity: input.quantity,
			avgPrice: input.avgPrice,
			currentPrice: input.priceMode === "fx" ? state.market.fx : input.currentPrice
		};
		const holdings = [...state.holdings, holding];
		set({
			isSample: false,
			accounts: account.accounts,
			holdings,
			snapshots: snapshot(holdings, state.market.fx, state.snapshots)
		});
		return null;
	},
	updateHolding: (id, patch) => {
		const state = get();
		const holdings = state.holdings.map((holding) => {
			if (holding.id !== id) return holding;
			const next = {
				...holding,
				...patch
			};
			if (patch.symbol != null) next.symbol = cleanSymbol(patch.symbol);
			if (next.priceMode === "fx") {
				next.currency = "KRW";
				next.symbol = "";
			}
			return next;
		});
		set({
			isSample: false,
			holdings,
			snapshots: snapshot(holdings, state.market.fx, state.snapshots)
		});
	},
	removeHolding: (id) => {
		const state = get();
		const holdings = state.holdings.filter((holding) => holding.id !== id);
		set({
			isSample: false,
			holdings,
			snapshots: snapshot(holdings, state.market.fx, state.snapshots)
		});
	},
	buyExisting: ({ holdingId, quantity, price, date }) => {
		const state = get();
		const current = state.holdings.find((holding) => holding.id === holdingId);
		if (!current) return "종목을 찾지 못했습니다.";
		if (!(quantity > 0) || !(price > 0)) return "가격과 수량을 입력하세요.";
		const nextQty = current.quantity + quantity;
		const nextAvg = (current.quantity * current.avgPrice + quantity * price) / nextQty;
		const holdings = state.holdings.map((holding) => holding.id === holdingId ? {
			...holding,
			quantity: round4(nextQty),
			avgPrice: round4(nextAvg),
			currentPrice: holding.priceMode === "manual" ? price : holding.currentPrice
		} : holding);
		const fx = state.market.fx;
		set({
			isSample: false,
			holdings,
			txs: [makeTx({
				date,
				kind: "buy",
				accountId: current.accountId,
				holdingId: current.id,
				classId: current.classId,
				name: current.name,
				quantity,
				price,
				currency: current.currency,
				fx,
				amountKrw: Math.round(quantity * price * (current.currency === "USD" ? fx : 1)),
				realizedKrw: 0
			}), ...state.txs],
			snapshots: snapshot(holdings, fx, state.snapshots)
		});
		return null;
	},
	buyNew: (input) => {
		const state = get();
		const account = attachAccount(state.accounts, input.accountId, input.newAccountName);
		if ("error" in account) return account.error;
		if (!input.name.trim()) return "종목 이름을 입력하세요.";
		if (!(input.quantity > 0) || !(input.price > 0)) return "가격과 수량을 입력하세요.";
		const currency = input.priceMode === "fx" ? "KRW" : input.currency;
		const currentPrice = input.priceMode === "fx" ? state.market.fx : input.currentPrice > 0 ? input.currentPrice : input.price;
		const holding = {
			id: uid("h"),
			accountId: account.accountId,
			classId: input.classId,
			name: input.name.trim(),
			symbol: input.priceMode === "fx" ? "" : cleanSymbol(input.symbol),
			currency,
			priceMode: input.priceMode,
			quantity: input.quantity,
			avgPrice: input.price,
			currentPrice
		};
		const holdings = [...state.holdings, holding];
		const fx = state.market.fx;
		const tx = makeTx({
			date: input.date,
			kind: "buy",
			accountId: account.accountId,
			holdingId: holding.id,
			classId: holding.classId,
			name: holding.name,
			quantity: input.quantity,
			price: input.price,
			currency,
			fx,
			amountKrw: Math.round(input.quantity * input.price * (currency === "USD" ? fx : 1)),
			realizedKrw: 0
		});
		set({
			isSample: false,
			accounts: account.accounts,
			holdings,
			txs: [tx, ...state.txs],
			snapshots: snapshot(holdings, fx, state.snapshots)
		});
		return null;
	},
	sell: ({ holdingId, quantity, price, date }) => {
		const state = get();
		const current = state.holdings.find((holding) => holding.id === holdingId);
		if (!current) return "종목을 찾지 못했습니다.";
		if (!(quantity > 0) || !(price > 0)) return "가격과 수량을 입력하세요.";
		if (quantity > current.quantity + 1e-8) return "보유 수량보다 많이 팔 수 없습니다.";
		const nextQty = round4(Math.max(0, current.quantity - quantity));
		const holdings = state.holdings.map((holding) => holding.id === holdingId ? {
			...holding,
			quantity: nextQty,
			currentPrice: holding.priceMode === "manual" ? price : holding.currentPrice
		} : holding);
		const fx = state.market.fx;
		const mult = current.currency === "USD" ? fx : 1;
		set({
			isSample: false,
			holdings,
			txs: [makeTx({
				date,
				kind: "sell",
				accountId: current.accountId,
				holdingId: current.id,
				classId: current.classId,
				name: current.name,
				quantity,
				price,
				currency: current.currency,
				fx,
				amountKrw: Math.round(quantity * price * mult),
				realizedKrw: Math.round((price - current.avgPrice) * quantity * mult)
			}), ...state.txs],
			snapshots: snapshot(holdings, fx, state.snapshots)
		});
		return null;
	},
	addDividend: ({ holdingId, amount, currency, date }) => {
		const state = get();
		const current = state.holdings.find((holding) => holding.id === holdingId);
		if (!current) return "종목을 찾지 못했습니다.";
		if (!(amount > 0)) return "배당 금액을 입력하세요.";
		const fx = state.market.fx;
		set({
			isSample: false,
			txs: [makeTx({
				date,
				kind: "dividend",
				accountId: current.accountId,
				holdingId: current.id,
				classId: current.classId,
				name: current.name,
				quantity: current.quantity,
				price: amount,
				currency,
				fx,
				amountKrw: Math.round(amount * (currency === "USD" ? fx : 1)),
				realizedKrw: 0
			}), ...state.txs]
		});
		return null;
	},
	removeTx: (id) => set((state) => ({
		isSample: false,
		txs: state.txs.filter((tx) => tx.id !== id)
	})),
	applyMarket: (payload) => {
		set((state) => {
			const quoteOf = new Map(payload.quotes.map((quote) => [quote.symbol, quote]));
			const holdings = state.holdings.map((holding) => {
				if (holding.priceMode === "fx") return {
					...holding,
					currentPrice: payload.fx,
					currency: "KRW"
				};
				if (holding.priceMode !== "auto" || !holding.symbol) return holding;
				const quote = quoteOf.get(cleanSymbol(holding.symbol));
				if (!quote || !(quote.price > 0)) return holding;
				const currency = quote.currency.toUpperCase();
				if (holding.currency === "USD" && currency !== "USD") return holding;
				if (holding.currency === "KRW" && currency !== "KRW") return holding;
				return {
					...holding,
					currentPrice: quote.price
				};
			});
			const fx = payload.fx > 0 ? payload.fx : state.market.fx;
			return {
				holdings,
				market: {
					fx,
					sp500: payload.sp500 > 0 ? payload.sp500 : state.market.sp500,
					nasdaq: payload.nasdaq > 0 ? payload.nasdaq : state.market.nasdaq,
					updatedAt: payload.fetchedAt,
					history: payload.history.length > 0 ? payload.history : state.market.history
				},
				snapshots: snapshot(holdings, fx, state.snapshots)
			};
		});
	},
	updateSettings: (patch) => set((state) => ({ settings: {
		...state.settings,
		...patch
	} })),
	resetSample: () => set(createSample()),
	startFresh: () => {
		set({
			isSample: false,
			accounts: [],
			classes: createSample().classes.map((item) => ({
				...item,
				target: item.target
			})),
			holdings: [],
			txs: [],
			snapshots: [],
			settings: {
				contribution: 1e6,
				years: 10,
				pessimistic: null,
				average: null,
				optimistic: null
			}
		});
	}
}), {
	name: "hannun.v1",
	skipHydration: true,
	partialize: (state) => ({
		isSample: state.isSample,
		accounts: state.accounts,
		classes: state.classes,
		holdings: state.holdings,
		txs: state.txs,
		snapshots: state.snapshots,
		market: state.market,
		settings: state.settings
	})
}));
function holdingPnl(holding, fx) {
	const value = holdingValue(holding, fx);
	const cost = holding.quantity > 0 ? holding.quantity * holding.avgPrice * (holding.currency === "USD" ? fx : 1) : 0;
	const pnl = value - cost;
	return {
		value,
		cost,
		pnl,
		pct: cost > 0 ? pnl / cost * 100 : 0
	};
}
function AssetsView({ onTrade }) {
	const data = usePortfolio();
	const [group, setGroup] = (0, import_react.useState)("account");
	const [query, setQuery] = (0, import_react.useState)("");
	const [editor, setEditor] = (0, import_react.useState)(null);
	const [accountsOpen, setAccountsOpen] = (0, import_react.useState)(false);
	const fx = data.market.fx;
	const q = query.trim().toLowerCase();
	const visible = data.holdings.filter((holding) => {
		if (!q) return true;
		return `${holding.name} ${holding.symbol}`.toLowerCase().includes(q);
	});
	const open = visible.filter((holding) => holding.quantity > 1e-8);
	const closed = visible.filter((holding) => holding.quantity <= 1e-8);
	const groups = (0, import_react.useMemo)(() => {
		return (group === "account" ? data.accounts.map((item) => ({
			id: item.id,
			name: item.name
		})) : data.classes.map((item) => ({
			id: item.id,
			name: item.name,
			color: item.color
		}))).map((item) => {
			const items = open.filter((holding) => group === "account" ? holding.accountId === item.id : holding.classId === item.id).sort((a, b) => holdingPnl(b, fx).value - holdingPnl(a, fx).value);
			const value = items.reduce((sum, holding) => sum + holdingPnl(holding, fx).value, 0);
			return {
				...item,
				items,
				value
			};
		}).filter((item) => group === "class" || item.items.length > 0 || data.accounts.some((account) => account.id === item.id)).sort((a, b) => b.value - a.value);
	}, [
		data.accounts,
		data.classes,
		group,
		open,
		fx
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold",
					children: "보유 자산"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 px-2 text-sm text-muted",
						onClick: () => setAccountsOpen(true),
						children: "계좌"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-lg bg-primary px-3 text-sm font-medium text-primary-fg",
						onClick: () => setEditor("new"),
						children: "자산 추가"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
				value: group,
				onChange: setGroup,
				options: [{
					id: "account",
					label: "계좌별"
				}, {
					id: "class",
					label: "자산군별"
				}]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: "종목 검색",
				value: query,
				onChange: (event) => setQuery(event.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "달러 손익은 현재 환율로 환산합니다. 적금·파킹은 수량을 1, 평단을 원금, 현재가를 잔액으로 두면 됩니다."
			}),
			groups.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "flex min-w-0 items-center gap-2 text-sm font-semibold",
							children: ["color" in item && typeof item.color === "string" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-2 shrink-0 rounded-full",
								style: { background: item.color }
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: item.name
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-sm tabular-nums",
							children: formatKrw(item.value)
						})]
					}),
					item.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 py-3 text-sm text-muted",
						children: "없음"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: item.items.map((holding) => {
						const pnl = holdingPnl(holding, fx);
						const account = data.accounts.find((entry) => entry.id === holding.accountId);
						const assetClass = data.classes.find((entry) => entry.id === holding.classId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-line first:border-t-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex w-full items-center gap-3 px-4 py-3 text-left",
								onClick: () => setEditor(holding),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm font-medium",
										children: holding.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block truncate text-xs text-muted",
										children: [
											group === "account" ? assetClass?.name : account?.name,
											" ·",
											" ",
											holding.priceMode === "fx" ? `${formatQty(holding.quantity)}달러` : `${formatQty(holding.quantity)} × ${formatPrice(holding.currentPrice, holding.currency)}`
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm tabular-nums",
										children: formatKrw(pnl.value)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PnlText, {
										value: pnl.pnl,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs",
											children: formatPct(pnl.pct)
										})
									})]
								})]
							})
						}, holding.id);
					}) })
				]
			}, item.id)),
			closed.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "수량이 0인 종목"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-2",
					children: closed.map((holding) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm text-muted",
						onClick: () => setEditor(holding),
						children: holding.name
					}) }, holding.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoldingSheet, {
				mode: editor,
				onClose: () => setEditor(null),
				onTrade: (kind, id) => {
					setEditor(null);
					onTrade(kind, id);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountSheet, {
				open: accountsOpen,
				onClose: () => setAccountsOpen(false)
			})
		]
	});
}
function HoldingSheet({ mode, onClose, onTrade }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: mode != null,
		title: mode === "new" ? "자산 추가" : "자산 수정",
		onClose,
		children: mode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoldingForm, {
			mode,
			onClose,
			onTrade
		}, mode === "new" ? "new" : mode.id) : null
	});
}
function HoldingForm({ mode, onClose, onTrade }) {
	const data = usePortfolio();
	const initial = mode === "new" ? null : mode;
	const [name, setName] = (0, import_react.useState)(initial?.name ?? "");
	const [symbol, setSymbol] = (0, import_react.useState)(initial?.symbol ?? "");
	const [accountId, setAccountId] = (0, import_react.useState)(initial?.accountId ?? data.accounts[0]?.id ?? "");
	const [newAccount, setNewAccount] = (0, import_react.useState)("");
	const [classId, setClassId] = (0, import_react.useState)(initial?.classId ?? data.classes[0]?.id ?? "");
	const [currency, setCurrency] = (0, import_react.useState)(initial?.currency ?? "KRW");
	const [priceMode, setPriceMode] = (0, import_react.useState)(initial?.priceMode ?? "auto");
	const [quantity, setQuantity] = (0, import_react.useState)(initial ? String(initial.quantity) : "");
	const [avgPrice, setAvgPrice] = (0, import_react.useState)(initial ? String(initial.avgPrice) : "");
	const [currentPrice, setCurrentPrice] = (0, import_react.useState)(initial ? String(initial.currentPrice) : "");
	const [error, setError] = (0, import_react.useState)(null);
	function submit(event) {
		event.preventDefault();
		const qty = parseNum(quantity);
		const avg = parseNum(avgPrice);
		const current = parseNum(currentPrice);
		if (priceMode === "auto" && !cleanSymbol(symbol)) {
			setError("자동 시세는 티커가 필요합니다. 예: VOO, 005930");
			return;
		}
		const payload = {
			accountId: newAccount.trim() ? "" : accountId,
			newAccountName: newAccount,
			classId,
			name,
			symbol,
			currency,
			priceMode,
			quantity: qty ?? 0,
			avgPrice: avg ?? 0,
			currentPrice: priceMode === "fx" ? data.market.fx : current ?? 0
		};
		const message = initial ? null : data.addHolding(payload);
		if (initial) {
			if (!name.trim() || !(qty && qty > 0) || !(avg && avg > 0) || !(payload.currentPrice > 0)) {
				setError("이름, 수량, 평단, 현재가를 확인해 주세요.");
				return;
			}
			data.updateHolding(initial.id, {
				...payload,
				accountId: newAccount.trim() ? initial.accountId : accountId
			});
			if (newAccount.trim()) {
				const created = data.addAccount(newAccount);
				if (created) {
					setError(created);
					return;
				}
				const newest = usePortfolio.getState().accounts.at(-1);
				if (newest) data.updateHolding(initial.id, { accountId: newest.id });
			}
			onClose();
			return;
		}
		if (message) {
			setError(message);
			return;
		}
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-3",
		onSubmit: submit,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "이름",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: name,
					placeholder: "삼성전자, 토스 파킹통장",
					onChange: (event) => setName(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "티커 (자동 시세)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: symbol,
					placeholder: "VOO, 005930, 삼성전자",
					onChange: (event) => setSymbol(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "계좌",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field",
					value: accountId,
					onChange: (event) => setAccountId(event.target.value),
					children: [data.accounts.map((account) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: account.id,
						children: account.name
					}, account.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "새 계좌"
					})]
				})
			}),
			accountId === "" || newAccount ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "새 계좌 이름",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: newAccount,
					placeholder: "미래에셋증권",
					onChange: (event) => setNewAccount(event.target.value)
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "자산군",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field",
					value: classId,
					onChange: (event) => setClassId(event.target.value),
					children: data.classes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.name
					}, item.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "시세",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field",
					value: priceMode,
					onChange: (event) => {
						const next = event.target.value;
						setPriceMode(next);
						if (next === "fx") setCurrentPrice(String(data.market.fx));
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "auto",
							children: "티커로 자동"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "manual",
							children: "직접 입력"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "fx",
							children: "달러 잔액 · 환율 연동"
						})
					]
				})
			}),
			priceMode === "fx" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "수량은 달러 금액, 평단은 샀을 때 환율, 현재가는 오늘 환율로 바뀝니다."
			}) : null,
			priceMode !== "fx" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "통화",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field",
					value: currency,
					onChange: (event) => setCurrency(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "KRW",
						children: "원화"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "USD",
						children: "달러"
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: priceMode === "fx" ? "달러 수량" : "수량",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field tabular-nums",
						inputMode: "decimal",
						value: quantity,
						onChange: (event) => setQuantity(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: priceMode === "fx" ? "매수 환율" : "평단",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field tabular-nums",
						inputMode: "decimal",
						value: avgPrice,
						onChange: (event) => setAvgPrice(event.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: priceMode === "fx" ? "현재 환율" : "현재가",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field tabular-nums",
					inputMode: "decimal",
					value: currentPrice,
					onChange: (event) => setCurrentPrice(event.target.value)
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-down",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "h-11 w-full rounded-lg bg-primary text-sm font-medium text-primary-fg",
				children: "저장"
			}),
			initial ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-lg bg-surface-2 text-sm",
						onClick: () => onTrade("buy", initial.id),
						children: "매수"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-lg bg-surface-2 text-sm",
						onClick: () => onTrade("sell", initial.id),
						children: "매도"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-lg bg-surface-2 text-sm",
						onClick: () => onTrade("dividend", initial.id),
						children: "배당"
					})
				]
			}) : null,
			initial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 w-full text-sm text-down",
				onClick: () => {
					data.removeHolding(initial.id);
					onClose();
				},
				children: "이 종목 삭제"
			}) : null
		]
	});
}
function AccountSheet({ open, onClose }) {
	const accounts = usePortfolio((state) => state.accounts);
	const addAccount = usePortfolio((state) => state.addAccount);
	const renameAccount = usePortfolio((state) => state.renameAccount);
	const removeAccount = usePortfolio((state) => state.removeAccount);
	const [name, setName] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		title: "계좌",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: accounts.map((account) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: account.name,
						"aria-label": "계좌 이름",
						onChange: (event) => renameAccount(account.id, event.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 shrink-0 px-2 text-sm text-down",
						onClick: () => setError(removeAccount(account.id)),
						children: "삭제"
					})]
				}, account.id))
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-down",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					setError(addAccount(name));
					if (name.trim()) setName("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					placeholder: "새 계좌",
					value: name,
					onChange: (event) => setName(event.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-11 shrink-0 rounded-lg bg-primary px-4 text-sm font-medium text-primary-fg",
					children: "추가"
				})]
			})
		]
	});
}
function useMounted() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	return mounted;
}
function useReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setReduced(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
	}, []);
	return reduced;
}
var tooltipStyle = {
	background: "var(--color-surface)",
	border: "1px solid var(--color-line)",
	borderRadius: 12,
	fontSize: 12,
	color: "var(--color-fg)"
};
function Donut({ data }) {
	const mounted = useMounted();
	const reduced = useReducedMotion();
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-56" });
	if (data.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-56 place-items-center text-sm text-muted",
		children: "표시할 자산이 없습니다"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-56",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
				data,
				dataKey: "value",
				nameKey: "name",
				innerRadius: "68%",
				outerRadius: "92%",
				paddingAngle: 1.5,
				stroke: "none",
				isAnimationActive: !reduced,
				children: data.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: entry.color }, entry.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
				formatter: (value) => formatKrw(Number(value ?? 0)),
				contentStyle: tooltipStyle
			})] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: "평가액"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-semibold tabular-nums",
				children: formatMan(data.reduce((sum, item) => sum + item.value, 0))
			})]
		})]
	});
}
function TrendChart({ rows }) {
	const mounted = useMounted();
	const reduced = useReducedMotion();
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64" });
	if (rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-64 place-items-center text-sm text-muted",
		children: "시세를 불러오면 차트가 그려집니다"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-64",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data: rows,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-line)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						minTickGap: 28,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						width: 36,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						domain: ["auto", "auto"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						contentStyle: tooltipStyle,
						formatter: (value, name) => {
							const n = Number(value ?? NaN);
							return [Number.isFinite(n) ? n.toFixed(1) : "-", String(name)];
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "portfolio",
						name: "내 자산",
						stroke: "var(--color-c1)",
						strokeWidth: 2.25,
						dot: false,
						connectNulls: true,
						isAnimationActive: !reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "sp500",
						name: "S&P500",
						stroke: "var(--color-c8)",
						strokeWidth: 1.75,
						dot: false,
						connectNulls: true,
						isAnimationActive: !reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "nasdaq",
						name: "나스닥100",
						stroke: "var(--color-c3)",
						strokeWidth: 1.75,
						dot: false,
						connectNulls: true,
						isAnimationActive: !reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "fx",
						name: "환율",
						stroke: "var(--color-c5)",
						strokeWidth: 1.75,
						dot: false,
						connectNulls: true,
						isAnimationActive: !reduced
					})
				]
			})
		})
	});
}
function OutlookChart({ rows }) {
	const mounted = useMounted();
	const reduced = useReducedMotion();
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-64",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data: rows,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-line)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						minTickGap: 24,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						width: 48,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						tickFormatter: (value) => formatMan(Number(value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						contentStyle: tooltipStyle,
						formatter: (value, name) => [formatKrw(Number(value ?? 0)), String(name)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "low",
						name: "비관",
						stroke: "var(--color-c5)",
						strokeWidth: 1.75,
						dot: false,
						isAnimationActive: !reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "mid",
						name: "평균",
						stroke: "var(--color-c1)",
						strokeWidth: 2.25,
						dot: false,
						isAnimationActive: !reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "high",
						name: "낙관",
						stroke: "var(--color-c3)",
						strokeWidth: 1.75,
						dot: false,
						isAnimationActive: !reduced
					})
				]
			})
		})
	});
}
function HomeView({ onNavigate, onTrade }) {
	const data = usePortfolio();
	const [targetsOpen, setTargetsOpen] = (0, import_react.useState)(false);
	const [resetAsk, setResetAsk] = (0, import_react.useState)(false);
	const fx = data.market.fx;
	const total = portfolioValue(data.holdings, fx);
	const cost = portfolioCost(data.holdings, fx);
	const pnl = total - cost;
	const pnlPct = cost > 0 ? pnl / cost * 100 : 0;
	const rows = (0, import_react.useMemo)(() => allocation(data.holdings, data.classes, fx), [
		data.holdings,
		data.classes,
		fx
	]);
	const slices = rows.filter((row) => row.value > 0);
	const rates = resolveRates(weightedExpectedReturn(rows), data.settings);
	const years = data.settings.years;
	const monthly = data.settings.contribution;
	const targetSum = data.classes.reduce((sum, item) => sum + item.target, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			data.isSample ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface-2 px-3 py-3 text-sm text-muted",
				children: ["예시 포트폴리오입니다. 종목을 고치거나 비우고 내 계좌로 바꾸세요.", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-md bg-surface px-3 text-sm font-medium text-fg",
						onClick: () => onNavigate("assets"),
						children: "자산 고치기"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-md px-3 text-sm text-fg",
						onClick: () => data.startFresh(),
						children: "비우고 시작"
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "총 평가액"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-3xl font-semibold tracking-tight tabular-nums",
						children: formatKrw(total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PnlText, {
							value: pnl,
							children: [
								pnl >= 0 ? "평가이익" : "평가손실",
								" ",
								formatKrw(Math.abs(pnl)),
								" (",
								formatPct(pnlPct),
								")"
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							"달러 자산은 현재 환율 ",
							formatKrw(fx).replace("원", ""),
							"원으로 환산"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-3 gap-2",
						children: [
							"buy",
							"sell",
							"dividend"
						].map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 rounded-lg bg-surface-2 text-sm font-medium",
							onClick: () => onTrade(kind),
							children: kind === "buy" ? "매수" : kind === "sell" ? "매도" : "배당"
						}, kind))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold",
						children: "자산군 비중"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 px-2 text-sm text-primary",
						onClick: () => setTargetsOpen(true),
						children: "목표 조정"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-center gap-3 md:grid-cols-[16rem_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Donut, { data: slices.map((row) => ({
						id: row.id,
						name: row.name,
						value: row.value,
						color: row.color
					})) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5",
						children: rows.filter((row) => row.value > 0).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex min-w-0 items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-2 shrink-0 rounded-full",
									style: { background: row.color }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate text-sm",
									children: row.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-sm tabular-nums",
									children: formatMan(row.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "w-12 shrink-0 text-right text-xs tabular-nums text-muted",
									children: [row.pct.toFixed(1), "%"]
								})
							]
						}, row.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold",
							children: "목표보다 어디가 부족한지"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: targetSum === 100 ? "text-xs text-muted" : "text-xs text-down",
							children: [
								"목표 합계 ",
								targetSum.toFixed(0),
								"%"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs text-muted",
						children: "막대는 현재 비중, 눈금은 목표입니다. 부족 금액은 지금 평가액 기준입니다."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3",
						children: rows.map((row) => {
							const short = row.gapPct > .2;
							const over = row.gapPct < -.2;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-medium",
										children: row.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs tabular-nums text-muted",
										children: [
											row.pct.toFixed(1),
											"% / 목표 ",
											row.target.toFixed(1),
											"%"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `shrink-0 text-right text-sm tabular-nums ${short ? "text-down" : "text-muted"}`,
									children: short ? `부족 ${formatKrw(row.gapKrw)}` : over ? `초과 ${formatKrw(-row.gapKrw)}` : "거의 일치"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mt-2 h-2 rounded-full bg-surface-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full",
									style: {
										width: `${Math.min(100, Math.max(0, row.pct))}%`,
										background: row.color
									}
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-1/2 h-3.5 w-0.5 -translate-y-1/2 bg-fg",
									style: { left: `${Math.min(100, Math.max(0, row.target))}%` }
								})]
							})] }, row.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "card w-full p-4 text-left",
				onClick: () => onNavigate("outlook"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-base font-semibold",
						children: [
							"이대로 ",
							years,
							"년"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							"매달 ",
							formatMan(monthly),
							" 추가 · 평균 ",
							rates.average.toFixed(1),
							"%는 보유 자산 기대수익의 가중평균"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-3 gap-2 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
								label: "비관",
								value: futureValue(total, rates.pessimistic, monthly, years)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
								label: "평균",
								value: futureValue(total, rates.average, monthly, years)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
								label: "낙관",
								value: futureValue(total, rates.optimistic, monthly, years)
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2 pb-2",
				children: resetAsk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "w-full text-xs text-muted",
						children: "예시로 되돌리면 지금 입력한 자산과 기록이 지워집니다."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-lg bg-fg px-3 text-sm text-bg",
						onClick: () => {
							data.resetSample();
							setResetAsk(false);
						},
						children: "예시로 되돌리기"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 px-3 text-sm",
						onClick: () => setResetAsk(false),
						children: "취소"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 px-1 text-sm text-muted",
					onClick: () => setResetAsk(true),
					children: "예시 포트폴리오로 되돌리기"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetSheet, {
				open: targetsOpen,
				onClose: () => setTargetsOpen(false)
			})
		]
	});
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface-2 px-2 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold tabular-nums",
			children: formatMan(value)
		})]
	});
}
function TargetSheet({ open, onClose }) {
	const classes = usePortfolio((state) => state.classes);
	const updateClass = usePortfolio((state) => state.updateClass);
	const addClass = usePortfolio((state) => state.addClass);
	const removeClass = usePortfolio((state) => state.removeClass);
	const [error, setError] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const sum = classes.reduce((total, item) => total + item.target, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		title: "목표 비중",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: "기본 9개 자산군입니다. 이름을 바꾸고, 목표를 맞추고, 없는 자산군은 추가하세요."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: `mb-3 text-sm tabular-nums ${Math.abs(sum - 100) < .05 ? "text-muted" : "text-down"}`,
				children: [
					"합계 ",
					sum.toFixed(1),
					"%"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: classes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[auto_minmax(0,1fr)_4.5rem_auto] items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-2.5 rounded-full",
							style: { background: item.color }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field min-w-0",
							value: item.name,
							"aria-label": `${item.name} 이름`,
							onChange: (event) => updateClass(item.id, { name: event.target.value })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field text-right tabular-nums",
							inputMode: "decimal",
							"aria-label": `${item.name} 목표 비중`,
							value: String(item.target),
							onChange: (event) => {
								const next = parseNum(event.target.value);
								updateClass(item.id, { target: next == null ? 0 : Math.max(0, next) });
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 px-2 text-sm text-down",
							onClick: () => {
								const message = removeClass(item.id);
								setError(message);
							},
							children: "삭제"
						})
					]
				}, item.id))
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-down",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 space-y-2",
				onSubmit: (event) => {
					event.preventDefault();
					addClass(name);
					setName("");
					setError(null);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "자산군 추가",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: name,
						placeholder: "예: 원자재",
						onChange: (event) => setName(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-11 w-full rounded-lg bg-primary text-sm font-medium text-primary-fg",
					children: "추가"
				})]
			})
		]
	});
}
function LedgerView({ request }) {
	const txs = usePortfolio((state) => state.txs);
	const accounts = usePortfolio((state) => state.accounts);
	const removeTx = usePortfolio((state) => state.removeTx);
	const [kindFilter, setKindFilter] = (0, import_react.useState)("all");
	const [year, setYear] = (0, import_react.useState)("all");
	const [month, setMonth] = (0, import_react.useState)("all");
	const [accountId, setAccountId] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!request) return;
		setDraft(request);
		setOpen(true);
	}, [request]);
	const years = (0, import_react.useMemo)(() => {
		const set = new Set(txs.map((tx) => tx.date.slice(0, 4)));
		set.add(String((/* @__PURE__ */ new Date()).getFullYear()));
		return [...set].sort((a, b) => b.localeCompare(a));
	}, [txs]);
	const filtered = txs.filter((tx) => {
		if (kindFilter !== "all" && tx.kind !== kindFilter) return false;
		if (accountId !== "all" && tx.accountId !== accountId) return false;
		if (year !== "all" && !tx.date.startsWith(year)) return false;
		if (month !== "all" && tx.date.slice(5, 7) !== month) return false;
		return true;
	});
	const sums = {
		buy: filtered.filter((tx) => tx.kind === "buy").reduce((sum, tx) => sum + tx.amountKrw, 0),
		sell: filtered.filter((tx) => tx.kind === "sell").reduce((sum, tx) => sum + tx.amountKrw, 0),
		dividend: filtered.filter((tx) => tx.kind === "dividend").reduce((sum, tx) => sum + tx.amountKrw, 0)
	};
	const yearRollup = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const tx of filtered) {
			const key = tx.date.slice(0, 4);
			const row = map.get(key) ?? {
				buy: 0,
				sell: 0,
				dividend: 0
			};
			row[tx.kind] += tx.amountKrw;
			map.set(key, row);
		}
		return [...map.entries()].sort((a, b) => b[0].localeCompare(a[0]));
	}, [filtered]);
	const groups = [];
	for (const tx of filtered) {
		const key = tx.date.slice(0, 7);
		const last = groups[groups.length - 1];
		if (!last || last.month !== key) groups.push({
			month: key,
			items: [tx]
		});
		else last.items.push(tx);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold",
					children: "매매·배당 기록"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-lg bg-primary px-3 text-sm font-medium text-primary-fg",
					onClick: () => {
						setDraft({
							nonce: Date.now(),
							kind: "buy",
							holdingId: null
						});
						setOpen(true);
					},
					children: "기록하기"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
				value: kindFilter,
				onChange: setKindFilter,
				options: [
					{
						id: "all",
						label: "전체"
					},
					{
						id: "buy",
						label: "매수"
					},
					{
						id: "sell",
						label: "매도"
					},
					{
						id: "dividend",
						label: "배당"
					}
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						"aria-label": "연도",
						value: year,
						onChange: (event) => setYear(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "모든 해"
						}), years.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item,
							children: [item, "년"]
						}, item))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						"aria-label": "월",
						value: month,
						onChange: (event) => setMonth(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "모든 달"
						}), Array.from({ length: 12 }, (_, index) => String(index + 1).padStart(2, "0")).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item,
							children: [Number(item), "월"]
						}, item))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						"aria-label": "계좌",
						value: accountId,
						onChange: (event) => setAccountId(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "모든 계좌"
						}), accounts.map((account) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: account.id,
							children: account.name
						}, account.id))]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "매수",
						value: sums.buy
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "매도",
						value: sums.sell
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sum, {
						label: "배당",
						value: sums.dividend
					})
				]
			}),
			year === "all" && yearRollup.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "border-b border-line px-4 py-3 text-sm font-semibold",
					children: "연도별"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: yearRollup.map(([itemYear, row]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-t border-line px-4 py-3 first:border-t-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tabular-nums",
						children: itemYear
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs tabular-nums text-muted",
						children: [
							"매수 ",
							formatMan(row.buy),
							" · 매도 ",
							formatMan(row.sell),
							" · 배당 ",
							formatMan(row.dividend)
						]
					})]
				}, itemYear)) })]
			}) : null,
			groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "이 조건의 기록이 없습니다."
			}) : null,
			groups.map((group) => {
				const monthBuy = group.items.filter((tx) => tx.kind === "buy").reduce((sum, tx) => sum + tx.amountKrw, 0);
				const monthSell = group.items.filter((tx) => tx.kind === "sell").reduce((sum, tx) => sum + tx.amountKrw, 0);
				const monthDiv = group.items.filter((tx) => tx.kind === "dividend").reduce((sum, tx) => sum + tx.amountKrw, 0);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "border-b border-line px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold tabular-nums",
							children: group.month.replace("-", ".")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tabular-nums text-muted",
							children: [
								"매수 ",
								formatMan(monthBuy),
								" · 매도 ",
								formatMan(monthSell),
								" · 배당 ",
								formatMan(monthDiv)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: group.items.map((tx) => {
						const account = accounts.find((item) => item.id === tx.accountId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-line px-4 py-3 first:border-t-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "truncate text-sm font-medium",
											children: [
												labelOf(tx.kind),
												" · ",
												tx.name
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "truncate text-xs text-muted",
											children: [
												tx.date,
												" · ",
												account?.name ?? "계좌 없음",
												tx.kind === "dividend" ? ` · ${tx.currency === "USD" ? formatPrice(tx.price, "USD") : formatKrw(tx.price)}` : ` · ${formatQty(tx.quantity)} × ${formatPrice(tx.price, tx.currency)}`
											]
										}),
										tx.kind === "sell" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PnlText, {
												value: tx.realizedKrw,
												children: ["실현 ", formatKrw(tx.realizedKrw)]
											})
										}) : null
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "shrink-0 text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm font-medium tabular-nums",
										children: formatKrw(tx.amountKrw)
									}), pendingDelete === tx.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-1 flex justify-end gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-11 px-2 text-xs text-down",
											onClick: () => {
												removeTx(tx.id);
												setPendingDelete(null);
											},
											children: "삭제"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-11 px-2 text-xs",
											onClick: () => setPendingDelete(null),
											children: "취소"
										})]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-11 text-xs text-muted",
										onClick: () => setPendingDelete(tx.id),
										children: "삭제"
									})]
								})]
							})
						}, tx.id);
					}) })]
				}, group.month);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open,
				title: "기록하기",
				onClose: () => setOpen(false),
				children: draft && open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeForm, {
					request: draft,
					onClose: () => setOpen(false)
				}, draft.nonce) : null
			})
		]
	});
}
function Sum({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold tabular-nums",
			children: formatKrw(value)
		})]
	});
}
function labelOf(kind) {
	if (kind === "buy") return "매수";
	if (kind === "sell") return "매도";
	return "배당";
}
function TradeForm({ request, onClose }) {
	const data = usePortfolio();
	const [kind, setKind] = (0, import_react.useState)(request.kind);
	const [mode, setMode] = (0, import_react.useState)(request.holdingId || request.kind !== "buy" ? "existing" : "existing");
	const [holdingId, setHoldingId] = (0, import_react.useState)(request.holdingId ?? data.holdings.find((item) => item.quantity > 0)?.id ?? "");
	const [date, setDate] = (0, import_react.useState)(today());
	const [price, setPrice] = (0, import_react.useState)("");
	const [quantity, setQuantity] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [currency, setCurrency] = (0, import_react.useState)("KRW");
	const [name, setName] = (0, import_react.useState)("");
	const [symbol, setSymbol] = (0, import_react.useState)("");
	const [accountId, setAccountId] = (0, import_react.useState)(data.accounts[0]?.id ?? "");
	const [newAccount, setNewAccount] = (0, import_react.useState)("");
	const [classId, setClassId] = (0, import_react.useState)(data.classes[0]?.id ?? "");
	const [priceMode, setPriceMode] = (0, import_react.useState)("auto");
	const [error, setError] = (0, import_react.useState)(null);
	const [done, setDone] = (0, import_react.useState)(null);
	const holding = data.holdings.find((item) => item.id === holdingId) ?? null;
	const openHoldings = data.holdings.filter((item) => item.quantity > 0 || item.id === request.holdingId);
	(0, import_react.useEffect)(() => {
		if (holding && kind === "dividend") setCurrency(holding.currency);
	}, [holding, kind]);
	function submit(event) {
		event.preventDefault();
		const qty = parseNum(quantity);
		const px = parseNum(price);
		const cash = parseNum(amount);
		let message = "입력값을 확인해 주세요.";
		if (kind === "dividend") {
			if (!holding) message = "종목을 선택하세요.";
			else message = data.addDividend({
				holdingId: holding.id,
				amount: cash ?? 0,
				currency,
				date
			});
		} else if (kind === "sell") {
			if (!holding) message = "종목을 선택하세요.";
			else message = data.sell({
				holdingId: holding.id,
				quantity: qty ?? 0,
				price: px ?? 0,
				date
			});
		} else if (mode === "existing") {
			if (!holding) message = "종목을 선택하세요.";
			else message = data.buyExisting({
				holdingId: holding.id,
				quantity: qty ?? 0,
				price: px ?? 0,
				date
			});
		} else {
			if (priceMode === "auto" && !cleanSymbol(symbol)) {
				setError("자동 시세는 티커가 필요합니다.");
				return;
			}
			message = data.buyNew({
				accountId: newAccount.trim() ? "" : accountId,
				newAccountName: newAccount,
				classId,
				name,
				symbol,
				currency,
				priceMode,
				quantity: qty ?? 0,
				avgPrice: px ?? 0,
				currentPrice: priceMode === "fx" ? data.market.fx : px ?? 0,
				date,
				price: px ?? 0
			});
		}
		if (message) {
			setError(message);
			setDone(null);
			return;
		}
		setError(null);
		setDone("반영했습니다.");
		setPrice("");
		setQuantity("");
		setAmount("");
	}
	const sellQty = parseNum(quantity);
	const sellPx = parseNum(price);
	const preview = kind === "sell" && holding && sellQty && sellPx ? (sellPx - holding.avgPrice) * sellQty * (holding.currency === "USD" ? data.market.fx : 1) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-3",
		onSubmit: submit,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
				value: kind,
				onChange: setKind,
				options: [
					{
						id: "buy",
						label: "매수"
					},
					{
						id: "sell",
						label: "매도"
					},
					{
						id: "dividend",
						label: "배당"
					}
				]
			}),
			kind === "buy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
				value: mode,
				onChange: setMode,
				options: [{
					id: "existing",
					label: "보유 종목"
				}, {
					id: "new",
					label: "새 종목"
				}]
			}) : null,
			kind !== "buy" || mode === "existing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "종목",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field",
					value: holdingId,
					onChange: (event) => setHoldingId(event.target.value),
					children: openHoldings.map((item) => {
						const account = data.accounts.find((entry) => entry.id === item.accountId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item.id,
							children: [
								item.name,
								" · ",
								account?.name,
								" · ",
								formatQty(item.quantity)
							]
						}, item.id);
					})
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "이름",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: name,
						onChange: (event) => setName(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "티커",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: symbol,
						placeholder: "VOO, 005930",
						onChange: (event) => setSymbol(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "계좌",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: accountId,
						onChange: (event) => setAccountId(event.target.value),
						children: [data.accounts.map((account) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: account.id,
							children: account.name
						}, account.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "새 계좌"
						})]
					})
				}),
				accountId === "" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "새 계좌 이름",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: newAccount,
						onChange: (event) => setNewAccount(event.target.value)
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "자산군",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: classId,
						onChange: (event) => setClassId(event.target.value),
						children: data.classes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.name
						}, item.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "통화",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: currency,
							onChange: (event) => setCurrency(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "KRW",
								children: "원화"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "USD",
								children: "달러"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "시세",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: priceMode,
							onChange: (event) => setPriceMode(event.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "auto",
									children: "자동"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "manual",
									children: "직접"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "fx",
									children: "환율 연동"
								})
							]
						})
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "날짜",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					type: "date",
					value: date,
					onChange: (event) => setDate(event.target.value)
				})
			}),
			kind === "dividend" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "배당 총액",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field tabular-nums",
					inputMode: "decimal",
					value: amount,
					onChange: (event) => setAmount(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "통화",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field",
					value: currency,
					onChange: (event) => setCurrency(event.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "KRW",
						children: "원화"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "USD",
						children: "달러"
					})]
				})
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "가격",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field tabular-nums",
						inputMode: "decimal",
						value: price,
						onChange: (event) => setPrice(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "수량",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field tabular-nums",
						inputMode: "decimal",
						value: quantity,
						onChange: (event) => setQuantity(event.target.value)
					})
				})]
			}),
			kind === "sell" && holding ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: ["보유 ", formatQty(holding.quantity)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 px-2",
					onClick: () => setQuantity(String(holding.quantity)),
					children: "전량"
				})]
			}) : null,
			preview != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: ["예상 실현손익 ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PnlText, {
					value: preview,
					children: formatKrw(preview)
				})]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-down",
				children: error
			}) : null,
			done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-up",
				children: done
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "h-11 w-full rounded-lg bg-primary text-sm font-medium text-primary-fg",
				children: "반영"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 w-full text-sm text-muted",
				onClick: onClose,
				children: "닫기"
			})
		]
	});
}
function rebase(value, base) {
	if (value == null || base == null || base === 0) return null;
	return value / base * 100;
}
function yearEnd(points, snapshots) {
	const months = /* @__PURE__ */ new Map();
	for (const point of points) months.set(point.month, {
		fx: point.fx,
		sp500: point.sp500,
		nasdaq: point.nasdaq,
		portfolio: null
	});
	for (const snap of snapshots) {
		const current = months.get(snap.month) ?? {
			fx: NaN,
			sp500: NaN,
			nasdaq: NaN,
			portfolio: null
		};
		current.portfolio = snap.value;
		months.set(snap.month, current);
	}
	const yearly = /* @__PURE__ */ new Map();
	for (const month of [...months.keys()].sort()) {
		const row = months.get(month);
		if (!row) continue;
		yearly.set(month.slice(0, 4), {
			month,
			...row
		});
	}
	return [...yearly.entries()].map(([year, row]) => ({
		year,
		...row
	}));
}
function changeOver(series) {
	if (series.length < 2) return null;
	const last = series[series.length - 1];
	const prev = series[Math.max(0, series.length - 13)];
	if (last == null || prev == null || prev === 0) return null;
	return (last - prev) / prev * 100;
}
function MarketView() {
	const market = usePortfolio((state) => state.market);
	const snapshots = usePortfolio((state) => state.snapshots);
	const holdings = usePortfolio((state) => state.holdings);
	const [mode, setMode] = (0, import_react.useState)("month");
	const total = portfolioValue(holdings, market.fx);
	const rows = (0, import_react.useMemo)(() => buildRows(market.history, snapshots, mode), [
		market.history,
		snapshots,
		mode
	]);
	const fxSeries = market.history.map((point) => point.fx);
	const spSeries = market.history.map((point) => point.sp500);
	const nqSeries = market.history.map((point) => point.nasdaq);
	const mineSeries = snapshots.map((point) => point.value);
	const yearly = yearEnd(market.history, snapshots);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold",
				children: "시장과 내 자산"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					market.updatedAt ? "최신 시세가 반영되어 있습니다." : "지금은 예시 시세입니다. 오른쪽 위 새로고침으로 환율, S&P500, 나스닥100, 보유 티커를 가져옵니다.",
					" ",
					"비교 차트는 시작을 100으로 맞춥니다."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "환율",
						value: `${formatIndex(market.fx)}원`,
						change: changeOver(fxSeries)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "S&P500",
						value: formatIndex(market.sp500),
						change: changeOver(spSeries)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "나스닥100",
						value: formatIndex(market.nasdaq),
						change: changeOver(nqSeries)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "내 자산",
						value: formatKrw(total),
						change: changeOver(mineSeries)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
				value: mode,
				onChange: setMode,
				options: [{
					id: "month",
					label: "월별"
				}, {
					id: "year",
					label: "연도별"
				}]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex flex-wrap gap-3 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
								color: "var(--color-c1)",
								label: "내 자산"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
								color: "var(--color-c8)",
								label: "S&P500"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
								color: "var(--color-c3)",
								label: "나스닥100"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
								color: "var(--color-c5)",
								label: "환율"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendChart, { rows }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: "겹치는 구간만 비교합니다. 내 자산은 매매·시세 갱신 때 그달 평가액을 남깁니다."
					})
				]
			}),
			mode === "year" && yearly.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm font-semibold",
					children: "연도 말 기준"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-3",
					children: yearly.map((row, index) => {
						const prev = yearly[index - 1];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: row.year
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tabular-nums text-muted",
							children: [
								"환율 ",
								fmtDelta(row.fx, prev?.fx),
								" · S&P ",
								fmtDelta(row.sp500, prev?.sp500),
								" · 나스닥 ",
								fmtDelta(row.nasdaq, prev?.nasdaq),
								row.portfolio != null ? ` · 내 자산 ${fmtDelta(row.portfolio, prev?.portfolio ?? null)}` : ""
							]
						})] }, row.year);
					})
				})]
			}) : null
		]
	});
}
function buildRows(history, snapshots, mode) {
	const snapMap = new Map(snapshots.map((item) => [item.month, item.value]));
	const sortedSnaps = snapshots.map((item) => item.month).sort();
	const start = sortedSnaps[0];
	const end = sortedSnaps[sortedSnaps.length - 1];
	let source = history;
	if (start && end) source = history.filter((point) => point.month >= start && point.month <= end);
	if (source.length === 0) {
		const base = snapshots[0]?.value ?? null;
		const monthly = snapshots.map((item) => ({
			label: shortMonth(item.month),
			key: item.month,
			fx: null,
			sp500: null,
			nasdaq: null,
			portfolio: rebase(item.value, base)
		}));
		if (mode === "month") return monthly;
		const byYear = /* @__PURE__ */ new Map();
		monthly.forEach((row) => byYear.set(row.key.slice(0, 4), row));
		return [...byYear.values()].map((row) => ({
			...row,
			label: row.key.slice(0, 4)
		}));
	}
	const first = source[0];
	const firstPortfolio = source.map((point) => snapMap.get(point.month)).find((value) => value != null) ?? null;
	const monthly = source.map((point) => ({
		label: shortMonth(point.month),
		key: point.month,
		fx: rebase(point.fx, first?.fx ?? null),
		sp500: rebase(point.sp500, first?.sp500 ?? null),
		nasdaq: rebase(point.nasdaq, first?.nasdaq ?? null),
		portfolio: rebase(snapMap.get(point.month) ?? null, firstPortfolio)
	}));
	if (mode === "month") return monthly;
	const byYear = /* @__PURE__ */ new Map();
	monthly.forEach((row) => byYear.set(row.key.slice(0, 4), row));
	return [...byYear.entries()].map(([year, row]) => ({
		...row,
		label: year
	}));
}
function Stat({ label, value, change }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm font-semibold tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-xs tabular-nums ${change == null ? "text-muted" : change >= 0 ? "text-up" : "text-down"}`,
				children: change == null ? "1년 비교 없음" : `1년 ${formatPct(change)}`
			})
		]
	});
}
function Legend({ color, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "h-0.5 w-4",
			style: { background: color }
		}), label]
	});
}
function fmtDelta(value, prev) {
	if (!Number.isFinite(value)) return "-";
	if (prev == null || !Number.isFinite(prev) || prev === 0) return formatIndex(value);
	return formatPct((value - prev) / prev * 100);
}
function OutlookView() {
	const data = usePortfolio();
	const total = portfolioValue(data.holdings, data.market.fx);
	const computed = weightedExpectedReturn(allocation(data.holdings, data.classes, data.market.fx));
	const rates = resolveRates(computed, data.settings);
	const monthly = data.settings.contribution;
	const years = data.settings.years;
	const chart = Array.from({ length: years + 1 }, (_, year) => ({
		label: year === 0 ? "지금" : `${year}년`,
		low: futureValue(total, rates.pessimistic, monthly, year),
		mid: futureValue(total, rates.average, monthly, year),
		high: futureValue(total, rates.optimistic, monthly, year)
	}));
	const contributed = monthly * years * 12;
	const principal = total + contributed;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold",
				children: "앞으로의 자산"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "평균 수익률은 자산군 기대수익을 지금 비중으로 가중평균한 값입니다. 세 숫자 모두 직접 바꿀 수 있습니다."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"보유 기준 평균 ",
							computed.toFixed(1),
							"%"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateField, {
								label: "비관",
								value: rates.pessimistic,
								auto: rates.pessimisticAuto,
								onAuto: () => data.updateSettings({ pessimistic: null }),
								onChange: (value) => data.updateSettings({ pessimistic: value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateField, {
								label: "평균",
								value: rates.average,
								auto: rates.averageAuto,
								onAuto: () => data.updateSettings({ average: null }),
								onChange: (value) => data.updateSettings({ average: value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateField, {
								label: "낙관",
								value: rates.optimistic,
								auto: rates.optimisticAuto,
								onAuto: () => data.updateSettings({ optimistic: null }),
								onChange: (value) => data.updateSettings({ optimistic: value })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: "자동이면 비관은 평균보다 4%p 낮고, 낙관은 3%p 높습니다."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyField, {
							label: "매달 추가 투자",
							value: monthly,
							onChange: (value) => data.updateSettings({ contribution: Math.max(0, Math.round(value)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "기간",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "size-11 rounded-lg bg-surface-2 text-lg",
										onClick: () => data.updateSettings({ years: Math.max(1, years - 1) }),
										children: "−"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "w-16 text-center text-sm font-medium tabular-nums",
										children: [years, "년"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "size-11 rounded-lg bg-surface-2 text-lg",
										onClick: () => data.updateSettings({ years: Math.min(30, years + 1) }),
										children: "+"
									})
								]
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex flex-wrap gap-3 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "비관"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "평균"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: { color: "var(--color-c3)" },
								children: "낙관"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutlookChart, { rows: chart }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-3 gap-2 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(End, {
								label: "비관",
								value: chart[chart.length - 1]?.low ?? total,
								principal
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(End, {
								label: "평균",
								value: chart[chart.length - 1]?.mid ?? total,
								principal
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(End, {
								label: "낙관",
								value: chart[chart.length - 1]?.high ?? total,
								principal
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs text-muted",
						children: [
							"원금은 지금 평가액 ",
							formatMan(total),
							"에 앞으로 넣을 ",
							formatMan(contributed),
							"을 더한 값입니다. 세금, 수수료, 환율 변동은 넣지 않았습니다."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold",
						children: "자산군 기대수익률"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 mb-3 text-xs text-muted",
						children: "이 값이 평균 시나리오의 재료입니다. 비중은 현황의 목표 조정에서 바꿉니다."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: data.classes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-2 shrink-0 rounded-full",
									style: { background: item.color }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate text-sm",
									children: item.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field w-24 text-right tabular-nums",
									inputMode: "decimal",
									"aria-label": `${item.name} 기대수익률`,
									defaultValue: String(item.expectedReturn),
									onBlur: (event) => {
										const next = parseNum(event.target.value);
										if (next == null) return;
										data.updateClass(item.id, { expectedReturn: Math.min(40, Math.max(-20, next)) });
									}
								}, `${item.id}-${item.expectedReturn}`),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted",
									children: "%"
								})
							]
						}, item.id))
					})
				]
			})
		]
	});
}
function End({ label, value, principal }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface-2 px-2 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold tabular-nums",
				children: formatMan(value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs tabular-nums text-muted",
				children: ["수익 ", formatMan(value - principal)]
			})
		]
	});
}
function RateField({ label, value, auto, onChange, onAuto }) {
	const [text, setText] = (0, import_react.useState)(value.toFixed(1));
	const [focus, setFocus] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!focus) setText(value.toFixed(1));
	}, [value, focus]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: `${label} 연수익률`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field tabular-nums",
				inputMode: "decimal",
				value: text,
				onFocus: () => setFocus(true),
				onBlur: () => {
					setFocus(false);
					const next = parseNum(text);
					if (next == null) {
						setText(value.toFixed(1));
						return;
					}
					onChange(Math.min(25, Math.max(-15, next)));
				},
				onChange: (event) => setText(event.target.value)
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-0 h-11 shrink-0 px-2 text-sm text-primary",
			onClick: onAuto,
			children: auto ? "자동" : "자동으로"
		})]
	});
}
function MoneyField({ label, value, onChange }) {
	const [text, setText] = (0, import_react.useState)(String(value));
	const [focus, setFocus] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!focus) setText(String(value));
	}, [value, focus]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field tabular-nums",
			inputMode: "numeric",
			value: text,
			onFocus: () => setFocus(true),
			onBlur: () => {
				setFocus(false);
				const next = parseNum(text);
				if (next == null) {
					setText(String(value));
					return;
				}
				onChange(Math.min(1e8, Math.max(0, next)));
			},
			onChange: (event) => setText(event.target.value)
		})
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({ symbols: array(string().min(1).max(20)).max(40) });
var fetchMarket = createServerFn({ method: "POST" }).validator(Input).handler(createSsrRpc("a6eda8ba56e67e5554ad9d89a791655f45c97cbd7c37c474b0f994145e7ab731"));
var TABS = [
	{
		id: "home",
		label: "현황",
		icon: ChartPie
	},
	{
		id: "assets",
		label: "자산",
		icon: Wallet
	},
	{
		id: "ledger",
		label: "거래",
		icon: ArrowLeftRight
	},
	{
		id: "market",
		label: "시장",
		icon: ChartLine
	},
	{
		id: "outlook",
		label: "전망",
		icon: TrendingUp
	}
];
function App() {
	const [tab, setTab] = (0, import_react.useState)("home");
	const [request, setRequest] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const lock = (0, import_react.useRef)(false);
	const holdings = usePortfolio((state) => state.holdings);
	const market = usePortfolio((state) => state.market);
	const applyMarket = usePortfolio((state) => state.applyMarket);
	const total = portfolioValue(holdings, market.fx);
	const cost = portfolioCost(holdings, market.fx);
	const pnlPct = cost > 0 ? (total - cost) / cost * 100 : 0;
	async function refresh(manual = false) {
		if (lock.current) return;
		lock.current = true;
		setLoading(true);
		if (manual) setError(null);
		try {
			const result = await fetchMarket({ data: { symbols: [...new Set(usePortfolio.getState().holdings.filter((holding) => holding.priceMode === "auto" && holding.symbol).map((holding) => cleanSymbol(holding.symbol)).filter(isSafeSymbol))] } });
			if (!result.ok) {
				if (manual) setError(result.message);
			} else {
				applyMarket(result);
				setError(null);
			}
		} catch {
			if (manual) setError("시세를 가져오지 못했습니다. 잠시 후 다시 눌러 주세요.");
		} finally {
			lock.current = false;
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		let live = true;
		(async () => {
			try {
				await usePortfolio.persist.rehydrate();
			} catch {}
			if (!live) return;
			const updatedAt = usePortfolio.getState().market.updatedAt;
			if (!updatedAt || Date.now() - Date.parse(updatedAt) > 216e5) refresh();
		})();
		return () => {
			live = false;
		};
	}, []);
	function openTrade(kind, holdingId = null) {
		setTab("ledger");
		setRequest({
			nonce: Date.now(),
			kind,
			holdingId
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-bg/95",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center justify-between px-4 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base font-semibold leading-tight",
								children: "한눈"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs tabular-nums text-muted",
								children: [
									formatMan(total),
									" · ",
									formatPct(pnlPct)
								]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-lg text-fg",
						onClick: () => void refresh(true),
						"aria-label": "시세 새로고침",
						"aria-busy": loading,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: cn("size-5", loading && "animate-spin") })
					})]
				}), error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto max-w-5xl px-4 pb-2 text-xs text-down",
					children: error
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-5xl px-4 pt-4 pb-28",
				children: [
					tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {
						onNavigate: setTab,
						onTrade: (kind) => openTrade(kind)
					}) : null,
					tab === "assets" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetsView, { onTrade: (kind, id) => openTrade(kind, id) }) : null,
					tab === "ledger" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerView, { request }) : null,
					tab === "market" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketView, {}) : null,
					tab === "outlook" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutlookView, {}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface",
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-5xl grid-cols-5",
					children: TABS.map((item) => {
						const Icon = item.icon;
						const active = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: cn("flex h-16 flex-col items-center justify-center gap-1 text-xs", active ? "text-primary" : "text-muted"),
							"aria-current": active ? "page" : void 0,
							onClick: () => setTab(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.25 : 1.75
							}), item.label]
						}, item.id);
					})
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {});
}
//#endregion
export { Home as component };
