import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as Plus, s as Search } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as privilegeLabel, E as utcTodayIso, T as useMinistry, a as Field, c as SKILL_META, f as blankMember, i as Card, m as fieldClass, n as Avatar, o as Modal, p as cn, r as Button, s as PageIntro, t as AppShell, v as fullName } from "./shell-CGpvgZIy.mjs";
import { t as SKILL_IDS } from "./types-djekE3oG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/members-CfdCIdN-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	"All",
	"Elders",
	"Servants",
	"Publishers",
	"Brothers",
	"Sisters",
	"Away"
];
function MembersPage() {
	const members = useMinistry((state) => state.members);
	const assignments = useMinistry((state) => state.assignments);
	const meetings = useMinistry((state) => state.meetings);
	const saveMember = useMinistry((state) => state.saveMember);
	const removeMember = useMinistry((state) => state.removeMember);
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const today = utcTodayIso();
	const visible = (0, import_react.useMemo)(() => {
		return members.filter((member) => {
			const hay = `${member.firstName} ${member.lastName} ${member.note}`.toLowerCase();
			if (query && !hay.includes(query.toLowerCase())) return false;
			if (filter === "Elders") return member.privilege === "elder";
			if (filter === "Servants") return member.privilege === "servant";
			if (filter === "Publishers") return member.privilege === "publisher" || member.privilege === "unbaptized";
			if (filter === "Brothers") return member.gender === "brother";
			if (filter === "Sisters") return member.gender === "sister";
			if (filter === "Away") return member.availability === "away" || member.awayDates.some((date) => date >= today);
			return true;
		}).sort((a, b) => a.lastName.localeCompare(b.lastName) || a.firstName.localeCompare(b.firstName));
	}, [
		members,
		query,
		filter,
		today
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Congregation",
			title: "Members",
			lede: "Profiles, abilities, and who can be approached for the next meeting.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => {
					setDraft(blankMember());
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add member"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-col gap-3 sm:flex-row sm:items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Search by name",
					className: cn(fieldClass, "pl-10"),
					"aria-label": "Search members"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex flex-wrap gap-2",
			children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(item),
				className: cn("tap h-10 rounded-full px-3 text-sm font-semibold", filter === item ? "bg-sidebar text-on-navy" : "bg-card text-muted"),
				children: item
			}, item))
		}),
		visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "p-8 text-center text-sm text-muted",
			children: "No one matches that search."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
			children: visible.map((member) => {
				const history = assignments.filter((assignment) => assignment.assigneeId === member.id || assignment.assistantId === member.id).length;
				const topSkills = SKILL_IDS.filter((skill) => (member.skills[skill] ?? 0) >= 70).slice(0, 3).map((skill) => SKILL_META[skill].label);
				const away = member.availability === "away" || member.awayDates.some((date) => date >= today);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setDraft(member),
					className: "tap rounded-3xl border border-line bg-card p-4 text-left shadow-card hover:border-royal/30",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { member }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold",
									children: fullName(member)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-sm text-muted",
									children: [
										privilegeLabel(member.privilege),
										" · ",
										member.gender === "brother" ? "Brother" : "Sister"
									]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap gap-1.5",
							children: (topSkills.length ? topSkills : ["Developing"]).map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-soft px-2.5 py-1 text-xs font-medium text-ink",
								children: skill
							}, skill))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("font-semibold", away ? "text-warn" : "text-good"),
								children: away ? "Away or limited dates" : member.availability === "limited" ? "Limited" : "Available"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [history, " parts on record"]
							})]
						})
					]
				}, member.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberDialog, {
			member: draft,
			meetings: meetings.map((meeting) => meeting.date),
			onOpenChange: (open) => {
				if (!open) setDraft(null);
			},
			onSave: (member) => {
				if (!member.firstName.trim() || !member.lastName.trim()) {
					toast("Add a first and last name.");
					return;
				}
				saveMember({
					...member,
					firstName: member.firstName.trim(),
					lastName: member.lastName.trim()
				});
				setDraft(null);
				toast.success("Member saved");
			},
			onRemove: (id) => setConfirmId(id)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open: Boolean(confirmId),
			onOpenChange: (open) => {
				if (!open) setConfirmId(null);
			},
			title: "Remove this publisher?",
			description: "Their name will come off future parts. Past meetings stay in the record without that assignment.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "soft",
					onClick: () => setConfirmId(null),
					children: "Keep"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => {
						if (confirmId) removeMember(confirmId);
						setConfirmId(null);
						setDraft(null);
						toast.success("Member removed");
					},
					children: "Remove"
				})]
			})
		})
	] });
}
function MemberDialog({ member, meetings, onOpenChange, onSave, onRemove }) {
	const [draft, setDraft] = (0, import_react.useState)(member);
	const isNew = member ? !useMinistry.getState().members.some((item) => item.id === member.id) : false;
	(0, import_react.useEffect)(() => {
		setDraft(member);
	}, [member]);
	if (!draft) return null;
	const patch = (partial) => setDraft({
		...draft,
		...partial
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open: true,
		onOpenChange,
		title: isNew ? "Add a member" : fullName(draft),
		description: "Skills from 0 to 100. The arranger only uses a part when the rating is at least 45.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				onSave(draft);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "First name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: draft.firstName,
							onChange: (event) => patch({ firstName: event.target.value })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Last name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: draft.lastName,
							onChange: (event) => patch({ lastName: event.target.value })
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Brother or sister",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: draft.gender,
							onChange: (event) => patch({ gender: event.target.value }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "brother",
								children: "Brother"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "sister",
								children: "Sister"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Privilege",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: draft.privilege,
							onChange: (event) => patch({ privilege: event.target.value }),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "elder",
									children: "Elder"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "servant",
									children: "Ministerial servant"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "publisher",
									children: "Publisher"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "unbaptized",
									children: "Unbaptized publisher"
								})
							]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Availability",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: draft.availability,
						onChange: (event) => patch({ availability: event.target.value }),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "available",
								children: "Available"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "limited",
								children: "Limited"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "away",
								children: "Away for now"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Phone",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: draft.phone,
						onChange: (event) => patch({ phone: event.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Note",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: cn(fieldClass, "h-20 py-2"),
						value: draft.note,
						onChange: (event) => patch({ note: event.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: SKILL_IDS.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillSlider, {
						skill,
						value: draft.skills[skill] ?? 0,
						onChange: (value) => patch({ skills: {
							...draft.skills,
							[skill]: value
						} })
					}, skill))
				}),
				meetings.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Per-week away dates are set on the Availability page."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-between gap-2 pt-2",
					children: [isNew ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => onRemove(draft.id),
						children: "Remove"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "soft",
							onClick: () => onOpenChange(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Save"
						})]
					})]
				})
			]
		})
	});
}
function SkillSlider({ skill, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center justify-between text-xs font-medium text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: SKILL_META[skill].label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-ink",
				children: value
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: 0,
			max: 100,
			value,
			onChange: (event) => onChange(Number(event.target.value)),
			className: "mt-1 w-full accent-royal"
		})]
	});
}
var SplitComponent = function MembersRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MembersPage, {}) });
};
//#endregion
export { SplitComponent as component };
