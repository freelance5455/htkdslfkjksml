import { Y as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as buttonClass, G as visualsForPreset, I as presetLabel, P as guidanceFor, S as THERMAL_TIPS, U as useSelectedGame, V as useAppStore, _ as PageHeader, g as PRESETS, i as BACKGROUND_TIPS, j as formatWhen, l as FPS_TARGETS, v as Panel } from "./ui-CJMJB--P.mjs";
import { n as FpsLogTool } from "./fps-tools-C4CmmVU9.mjs";
import { t as RefreshMeasure } from "./refresh-measure-CQ_5yNsN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/boost-BaZSHFEi.js
var import_jsx_runtime = require_jsx_runtime();
function BoostPage() {
	const game = useSelectedGame();
	const games = useAppStore((state) => state.games);
	const selectGame = useAppStore((state) => state.selectGame);
	const updateGame = useAppStore((state) => state.updateGame);
	const logs = useAppStore((state) => state.fpsLogs);
	const sample = useAppStore((state) => state.refreshSample);
	const last = logs.find((entry) => game ? entry.gameId === game.id : true);
	function apply(preset) {
		if (!game || preset === "custom") {
			if (game && preset === "custom") updateGame(game.id, { preset: "custom" });
			return;
		}
		updateGame(game.id, {
			preset,
			...visualsForPreset(preset, game.fpsTarget)
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Optimizer",
				title: "FPS targets",
				subtitle: "Pick a target and a preset. FrameForge saves the recommendation. It does not change clocks, inject frames, or unlock a game's FPS."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Three different numbers",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Target",
							value: game ? String(game.fpsTarget) : "—",
							hint: "Your goal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Measured",
							value: last ? String(last.measuredFps) : "—",
							hint: last ? "Manual log" : "None yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Refresh",
							value: sample ? String(sample.displayHz) : "—",
							hint: "This page"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Display refresh is how often the panel can present frames. Rendered FPS is what the game draws. Interpolated FPS would be extra frames invented between those. This app can only estimate the first, and only for this page."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Profile",
				children: games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Add a game in the ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/games",
							className: "font-semibold text-primary",
							children: "library"
						}),
						" first."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Selected game"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field-input",
						value: game?.id ?? "",
						onChange: (event) => selectGame(event.target.value || null),
						children: games.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.name
						}, item.id))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Target FPS",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "These are targets, not guaranteed results."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					role: "group",
					"aria-label": "Target FPS",
					children: FPS_TARGETS.map((target) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !game,
						"aria-pressed": game?.fpsTarget === target,
						className: `min-h-11 min-w-14 rounded-lg px-3 text-sm font-semibold tabular-nums disabled:opacity-50 ${game?.fpsTarget === target ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`,
						onClick: () => game && updateGame(game.id, { fpsTarget: target }),
						children: target
					}, target))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Preset",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !game,
						"aria-pressed": game?.preset === preset,
						className: `min-h-16 rounded-lg px-3 text-sm font-semibold disabled:opacity-50 ${game?.preset === preset ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`,
						onClick: () => apply(preset),
						children: presetLabel(preset)
					}, preset))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Battery Saver suggests 30. Balanced suggests 60. Performance keeps your current target and lightens a few effects. None of them raise a hidden FPS cap."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "In-game settings to try",
				children: [game ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "list-disc space-y-2 pl-5 text-sm text-muted",
					children: guidanceFor(game).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Select a profile to see recommendations."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/games",
					className: buttonClass("quiet", "mt-4"),
					children: "Edit the full profile"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Background activity",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "list-disc space-y-2 pl-5 text-sm text-muted",
					children: BACKGROUND_TIPS.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tip }, tip))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Heat",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "list-disc space-y-2 pl-5 text-sm text-muted",
					children: THERMAL_TIPS.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tip }, tip))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm font-semibold",
					children: "Temperature: Not available in this version."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Frame generation",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Frame generation unavailable in this version."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "There is no frame interpolation running, and no counter pretending there is. A native capture or scaling tool would be a different app, with its own permissions. This page does not inject frames into games."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Refresh estimate",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshMeasure, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Log a measured FPS",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FpsLogTool, { compact: true }),
					last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-faint",
						children: [
							"Latest entry ",
							formatWhen(last.at),
							"."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tools",
						hash: "fps-log",
						className: "text-sm font-semibold text-primary",
						children: "Open the full log"
					})
				]
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface-2 px-2 py-3 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-faint uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl font-semibold tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: hint
			})
		]
	});
}
var SplitComponent = BoostPage;
//#endregion
export { SplitComponent as component };
