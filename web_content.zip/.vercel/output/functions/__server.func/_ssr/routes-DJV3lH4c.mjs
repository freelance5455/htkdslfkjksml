import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Timer, c as Pause, d as Flame, f as CircleHelp, h as BookOpen, i as Trash2, l as NotebookPen, m as ChartColumn, n as Volume2, o as RotateCcw, p as ChevronLeft, s as Play, t as VolumeX, u as House } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as Tooltip, i as ResponsiveContainer, n as XAxis, r as Bar, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DJV3lH4c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var dict = {
	hi: {
		tagline: "स्मार्ट पढ़ाई",
		splashHint: "विषय · टाइमर · क्विज़",
		primaryNav: "मुख्य मेनू",
		home: "होम",
		subjects: "विषय",
		timer: "टाइमर",
		notes: "नोट्स",
		quiz: "क्विज़",
		progress: "प्रगति",
		greetingMorning: "सुप्रभात",
		greetingAfternoon: "नमस्ते",
		greetingEvening: "शुभ संध्या",
		addName: "नाम जोड़ें",
		namePlaceholder: "आपका नाम",
		todayStudy: "आज की पढ़ाई",
		dailyGoal: "दैनिक लक्ष्य",
		goalMet: "आज का लक्ष्य पूरा",
		goalDown: "लक्ष्य घटाएँ",
		goalUp: "लक्ष्य बढ़ाएँ",
		streak: "लगातार दिन",
		startFocus: "फोकस शुरू करें",
		viewTimer: "टाइमर देखें",
		resumeFocus: "जारी रखें",
		openTasks: "अधूरी चेकलिस्ट",
		allDone: "सारी चेकलिस्ट पूरी है। विषय में नया काम जोड़ें।",
		week: "इस हफ़्ते",
		weekTotal: "हफ़्ते का कुल",
		addSubject: "विषय जोड़ें",
		subjectHi: "नाम (हिंदी)",
		subjectEn: "Name (English, optional)",
		save: "सहेजें",
		cancel: "रद्द",
		delete: "हटाएँ",
		confirmDelete: "पक्का हटाएँ?",
		tasks: "चेकलिस्ट",
		addTask: "काम जोड़ें",
		taskPlaceholder: "जैसे, अभ्यास 3 पूरा करें",
		noTasks: "अभी कोई काम नहीं। एक जोड़ें।",
		noSubjects: "कोई विषय नहीं। पहला विषय जोड़ें।",
		focus: "फोकस",
		shortBreak: "छोटा ब्रेक",
		longBreak: "लंबा ब्रेक",
		start: "शुरू",
		pause: "रोकें",
		resume: "जारी",
		reset: "रीसेट",
		saveStop: "समय सहेज कर रोकें",
		doneTitle: "सत्र पूरा",
		doneFocus: "शाबाश। यह फोकस प्रगति में जुड़ गया।",
		doneBreak: "ब्रेक खत्म। वापस पढ़ाई पर चलें।",
		focusDone: "फोकस पूरा — देखें",
		breakDone: "ब्रेक पूरा — देखें",
		startBreak: "ब्रेक शुरू",
		again: "दोबारा फोकस",
		pickSubject: "विषय चुनें",
		noneSubject: "बिना विषय",
		soundOn: "ध्वनि बंद करें",
		soundOff: "ध्वनि चालू करें",
		shorter: "कम समय",
		longer: "ज़्यादा समय",
		newNote: "नया नोट",
		noteTitle: "शीर्षक",
		noteBody: "यहाँ लिखें… याद रखने लायक बातें, सूत्र, उदाहरण।",
		searchNotes: "नोट खोजें",
		noNotes: "कोई नोट नहीं मिला।",
		allSubjects: "सभी",
		pickNote: "बाएँ से नोट चुनें, या नया लिखें।",
		back: "वापस",
		startQuiz: "क्विज़ शुरू",
		question: "प्रश्न",
		next: "आगे",
		seeResult: "परिणाम देखें",
		check: "जाँचें",
		correct: "सही",
		wrong: "गलत",
		retry: "फिर से",
		addQuestion: "प्रश्न जोड़ें",
		prompt: "प्रश्न लिखें",
		option: "विकल्प",
		markCorrect: "सही उत्तर चुनें",
		noQuestions: "इस विषय में अभी प्रश्न नहीं।",
		resultTitle: "परिणाम",
		totalFocus: "कुल फोकस",
		quizAvg: "क्विज़ औसत",
		tasksDone: "काम पूरे",
		perSubject: "विषय के हिसाब से",
		recentQuizzes: "हाल के क्विज़",
		noQuizzes: "अभी कोई प्रयास नहीं। क्विज़ से शुरुआत करें।",
		noMinutes: "टाइमर पूरा करें — चार्ट यहीं भरेगा।",
		restore: "शुरुआती डेटा लौटाएँ",
		confirmRestore: "नमूना डेटा वापस लाएँ?",
		yes: "हाँ",
		great: "बहुत बढ़िया",
		good: "अच्छा प्रयास",
		againSoon: "दोहराएँ, हो जाएगा",
		lastScore: "पिछला स्कोर",
		questionsN: "प्रश्न",
		rename: "नाम बदलें",
		close: "बंद करें",
		minutesWord: "मिनट",
		langHi: "हिंदी",
		langEn: "English",
		switchLang: "भाषा बदलें"
	},
	en: {
		tagline: "Smart study",
		splashHint: "Subjects · Timer · Quiz",
		primaryNav: "Primary",
		home: "Home",
		subjects: "Subjects",
		timer: "Timer",
		notes: "Notes",
		quiz: "Quiz",
		progress: "Progress",
		greetingMorning: "Good morning",
		greetingAfternoon: "Good afternoon",
		greetingEvening: "Good evening",
		addName: "Add your name",
		namePlaceholder: "Your name",
		todayStudy: "Studied today",
		dailyGoal: "Daily goal",
		goalMet: "Today's goal is done",
		goalDown: "Lower goal",
		goalUp: "Raise goal",
		streak: "Day streak",
		startFocus: "Start focus",
		viewTimer: "View timer",
		resumeFocus: "Resume",
		openTasks: "Open checklist",
		allDone: "Every checklist item is done. Add a new task in a subject.",
		week: "This week",
		weekTotal: "Week total",
		addSubject: "Add subject",
		subjectHi: "Name (Hindi)",
		subjectEn: "Name (English, optional)",
		save: "Save",
		cancel: "Cancel",
		delete: "Delete",
		confirmDelete: "Delete for sure?",
		tasks: "Checklist",
		addTask: "Add task",
		taskPlaceholder: "e.g. Finish exercise 3",
		noTasks: "No tasks yet. Add one.",
		noSubjects: "No subjects yet. Add the first one.",
		focus: "Focus",
		shortBreak: "Short break",
		longBreak: "Long break",
		start: "Start",
		pause: "Pause",
		resume: "Resume",
		reset: "Reset",
		saveStop: "Save time and stop",
		doneTitle: "Session complete",
		doneFocus: "Nice. This focus block is on your progress.",
		doneBreak: "Break over. Back to study.",
		focusDone: "Focus done — view",
		breakDone: "Break done — view",
		startBreak: "Start break",
		again: "Focus again",
		pickSubject: "Pick a subject",
		noneSubject: "No subject",
		soundOn: "Turn sound off",
		soundOff: "Turn sound on",
		shorter: "Shorter",
		longer: "Longer",
		newNote: "New note",
		noteTitle: "Title",
		noteBody: "Write here — formulas, examples, things to remember.",
		searchNotes: "Search notes",
		noNotes: "No notes found.",
		allSubjects: "All",
		pickNote: "Pick a note, or write a new one.",
		back: "Back",
		startQuiz: "Start quiz",
		question: "Question",
		next: "Next",
		seeResult: "See result",
		check: "Check",
		correct: "Correct",
		wrong: "Wrong",
		retry: "Try again",
		addQuestion: "Add question",
		prompt: "Write the question",
		option: "Option",
		markCorrect: "Mark the right answer",
		noQuestions: "No questions in this subject yet.",
		resultTitle: "Result",
		totalFocus: "Total focus",
		quizAvg: "Quiz average",
		tasksDone: "Tasks done",
		perSubject: "By subject",
		recentQuizzes: "Recent quizzes",
		noQuizzes: "No attempts yet. Start a quiz.",
		noMinutes: "Finish a timer — the chart fills in here.",
		restore: "Restore starter data",
		confirmRestore: "Bring the sample data back?",
		yes: "Yes",
		great: "Excellent",
		good: "Solid effort",
		againSoon: "Review it — you'll get it",
		lastScore: "Last score",
		questionsN: "questions",
		rename: "Rename",
		close: "Close",
		minutesWord: "min",
		langHi: "हिंदी",
		langEn: "English",
		switchLang: "Change language"
	}
};
function greetingKey(hour) {
	if (hour < 12) return "greetingMorning";
	if (hour < 17) return "greetingAfternoon";
	return "greetingEvening";
}
function uid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function subjectName(subject, lang) {
	if (lang === "en") return subject.nameEn || subject.nameHi;
	return subject.nameHi || subject.nameEn;
}
function durationFor(mode, focusMin) {
	if (mode === "short") return 300;
	if (mode === "long") return 900;
	return focusMin * 60;
}
var DAYS_HI = [
	"रवि",
	"सोम",
	"मंगल",
	"बुध",
	"गुरु",
	"शुक्र",
	"शनि"
];
var DAYS_EN = [
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat"
];
function startOfDay(ts) {
	const d = new Date(ts);
	d.setHours(0, 0, 0, 0);
	return d.getTime();
}
function weekSeries(sessions, lang) {
	const rows = [];
	for (let i = 6; i >= 0; i--) {
		const d = /* @__PURE__ */ new Date();
		d.setHours(12, 0, 0, 0);
		d.setDate(d.getDate() - i);
		const key = startOfDay(d.getTime());
		const minutes = sessions.filter((s) => startOfDay(s.at) === key).reduce((sum, s) => sum + s.minutes, 0);
		rows.push({
			label: (lang === "hi" ? DAYS_HI : DAYS_EN)[d.getDay()] ?? "",
			minutes
		});
	}
	return rows;
}
function todayMinutes(sessions) {
	const key = startOfDay(Date.now());
	return sessions.filter((s) => startOfDay(s.at) === key).reduce((sum, s) => sum + s.minutes, 0);
}
function streakCount(sessions) {
	const days = new Set(sessions.map((s) => startOfDay(s.at)));
	let cursor = startOfDay(Date.now());
	if (!days.has(cursor)) cursor -= 864e5;
	let n = 0;
	while (days.has(cursor)) {
		n += 1;
		cursor -= 864e5;
	}
	return n;
}
function formatSpan(total, lang) {
	const h = Math.floor(total / 60);
	const m = total % 60;
	if (lang === "hi") {
		if (h <= 0) return `${m} मि`;
		if (m === 0) return `${h} घं`;
		return `${h} घं ${m} मि`;
	}
	if (h <= 0) return `${m} min`;
	if (m === 0) return `${h} hr`;
	return `${h} hr ${m} min`;
}
function formatClock(sec) {
	const safe = Math.max(0, sec);
	const m = Math.floor(safe / 60);
	const s = safe % 60;
	return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function taskProgress(tasks, subjectId) {
	const list = subjectId ? tasks.filter((t) => t.subjectId === subjectId) : tasks;
	const done = list.filter((t) => t.done).length;
	return {
		total: list.length,
		done,
		pct: list.length ? Math.round(done / list.length * 100) : 0
	};
}
function atDaysAgo(days, hour) {
	const d = /* @__PURE__ */ new Date();
	d.setDate(d.getDate() - days);
	d.setHours(hour, 12, 0, 0);
	return d.getTime();
}
var seedSubjects = [
	{
		id: "s-math",
		nameHi: "गणित",
		nameEn: "Mathematics",
		mark: "sage"
	},
	{
		id: "s-sci",
		nameHi: "विज्ञान",
		nameEn: "Science",
		mark: "gold"
	},
	{
		id: "s-hin",
		nameHi: "हिंदी",
		nameEn: "Hindi",
		mark: "sage"
	},
	{
		id: "s-eng",
		nameHi: "अंग्रेज़ी",
		nameEn: "English",
		mark: "gold"
	},
	{
		id: "s-his",
		nameHi: "इतिहास",
		nameEn: "History",
		mark: "sage"
	},
	{
		id: "s-gk",
		nameHi: "सामान्य ज्ञान",
		nameEn: "General knowledge",
		mark: "gold"
	}
];
var seedTasks = [
	{
		id: "t1",
		subjectId: "s-math",
		title: "सूत्र नोटबुक में लिखें",
		done: true
	},
	{
		id: "t2",
		subjectId: "s-math",
		title: "अभ्यास 4.2 के 10 प्रश्न हल करें",
		done: false
	},
	{
		id: "t3",
		subjectId: "s-math",
		title: "गलत हुए प्रश्न दोबारा करें",
		done: false
	},
	{
		id: "t4",
		subjectId: "s-sci",
		title: "प्रकाश संश्लेषण का डायग्राम बनाएँ",
		done: true
	},
	{
		id: "t5",
		subjectId: "s-sci",
		title: "अध्याय-सार एक पेज में लिखें",
		done: false
	},
	{
		id: "t6",
		subjectId: "s-hin",
		title: "तुलसीदास पर 8 पंक्तियाँ लिखें",
		done: false
	},
	{
		id: "t7",
		subjectId: "s-hin",
		title: "20 विलोम दोहराएँ",
		done: true
	},
	{
		id: "t8",
		subjectId: "s-eng",
		title: "My City पर एक पैराग्राफ लिखें",
		done: false
	},
	{
		id: "t9",
		subjectId: "s-eng",
		title: "15 irregular verbs दोहराएँ",
		done: true
	},
	{
		id: "t10",
		subjectId: "s-his",
		title: "1857 की टाइमलाइन बनाएँ",
		done: false
	},
	{
		id: "t11",
		subjectId: "s-his",
		title: "संविधान की तारीखें याद करें",
		done: true
	},
	{
		id: "t12",
		subjectId: "s-gk",
		title: "बिहार के 5 ज़िले और एक-एक तथ्य",
		done: false
	},
	{
		id: "t13",
		subjectId: "s-gk",
		title: "राष्ट्रीय प्रतीक दोहराएँ",
		done: true
	}
];
var seedNotes = [
	{
		id: "n1",
		subjectId: "s-math",
		title: "ज़रूरी सूत्र",
		body: "(a+b)² = a² + 2ab + b²\n(a−b)² = a² − 2ab + b²\nसरल ब्याज = (P × R × T) / 100\nत्रिभुज के कोणों का योग = 180°",
		updatedAt: atDaysAgo(1, 20)
	},
	{
		id: "n2",
		subjectId: "s-sci",
		title: "प्रकाश संश्लेषण",
		body: "पौधे सूर्य के प्रकाश में कार्बन डाइऑक्साइड और पानी से भोजन बनाते हैं।\nइस प्रक्रिया में ऑक्सीजन निकलती है।\nक्लोरोफिल हरी पत्तियों में होता है।",
		updatedAt: atDaysAgo(0, 8)
	},
	{
		id: "n3",
		subjectId: "s-eng",
		title: "Irregular verbs",
		body: "go → went → gone\nsee → saw → seen\nwrite → wrote → written\nteach → taught → taught\ncome → came → come",
		updatedAt: atDaysAgo(2, 19)
	},
	{
		id: "n4",
		subjectId: "s-his",
		title: "तारीखें जो याद रहें",
		body: "1526 — पानीपत का प्रथम युद्ध (बाबर और इब्राहिम लोदी)\n1857 — प्रथम स्वतंत्रता संग्राम\n26 जनवरी 1950 — संविधान लागू",
		updatedAt: atDaysAgo(3, 21)
	}
];
var seedQuestions = [
	{
		id: "q1",
		subjectId: "s-math",
		prompt: "240 का 15% कितना है?",
		options: [
			"36",
			"24",
			"32",
			"40"
		],
		answer: 0
	},
	{
		id: "q2",
		subjectId: "s-math",
		prompt: "(a+b)² का सही विस्तार कौन-सा है?",
		options: [
			"a² + 2ab + b²",
			"a² + b²",
			"a² − 2ab + b²",
			"2a + 2b"
		],
		answer: 0
	},
	{
		id: "q3",
		subjectId: "s-math",
		prompt: "√169 का मान क्या है?",
		options: [
			"11",
			"13",
			"15",
			"17"
		],
		answer: 1
	},
	{
		id: "q4",
		subjectId: "s-math",
		prompt: "त्रिभुज के तीनों कोणों का योग कितना होता है?",
		options: [
			"90°",
			"180°",
			"270°",
			"360°"
		],
		answer: 1
	},
	{
		id: "q5",
		subjectId: "s-sci",
		prompt: "पानी का रासायनिक सूत्र क्या है?",
		options: [
			"H₂O",
			"CO₂",
			"NaCl",
			"O₂"
		],
		answer: 0
	},
	{
		id: "q6",
		subjectId: "s-sci",
		prompt: "प्रकाश संश्लेषण में कौन-सी गैस निकलती है?",
		options: [
			"नाइट्रोजन",
			"ऑक्सीजन",
			"हाइड्रोजन",
			"क्लोरीन"
		],
		answer: 1
	},
	{
		id: "q7",
		subjectId: "s-sci",
		prompt: "गुरुत्वाकर्षण का नियम किसने दिया?",
		options: [
			"न्यूटन",
			"डार्विन",
			"मैंडल",
			"बोर"
		],
		answer: 0
	},
	{
		id: "q8",
		subjectId: "s-sci",
		prompt: "मानव हृदय में कितने कक्ष होते हैं?",
		options: [
			"2",
			"3",
			"4",
			"5"
		],
		answer: 2
	},
	{
		id: "q9",
		subjectId: "s-hin",
		prompt: "रामचरितमानस के कवि कौन हैं?",
		options: [
			"कबीर",
			"तुलसीदास",
			"सूरदास",
			"रहीम"
		],
		answer: 1
	},
	{
		id: "q10",
		subjectId: "s-hin",
		prompt: "‘उदय’ का विलोम क्या है?",
		options: [
			"सुबह",
			"अस्त",
			"प्रकाश",
			"चंद्र"
		],
		answer: 1
	},
	{
		id: "q11",
		subjectId: "s-hin",
		prompt: "किसी व्यक्ति, वस्तु या स्थान के नाम को क्या कहते हैं?",
		options: [
			"संज्ञा",
			"क्रिया",
			"विशेषण",
			"सर्वनाम"
		],
		answer: 0
	},
	{
		id: "q12",
		subjectId: "s-hin",
		prompt: "मुहावरा ‘आँखों का तारा’ का अर्थ क्या है?",
		options: [
			"बहुत प्यारा",
			"बहुत गुस्सा",
			"थकान",
			"अंधेरा"
		],
		answer: 0
	},
	{
		id: "q13",
		subjectId: "s-eng",
		prompt: "What is the past tense of “go”?",
		options: [
			"goed",
			"went",
			"gone",
			"going"
		],
		answer: 1
	},
	{
		id: "q14",
		subjectId: "s-eng",
		prompt: "Which word is a synonym of “happy”?",
		options: [
			"sad",
			"joyful",
			"late",
			"heavy"
		],
		answer: 1
	},
	{
		id: "q15",
		subjectId: "s-eng",
		prompt: "Choose the correct article: ___ hour.",
		options: [
			"a",
			"an",
			"no article",
			"these"
		],
		answer: 1
	},
	{
		id: "q16",
		subjectId: "s-eng",
		prompt: "What is the plural of “child”?",
		options: [
			"childs",
			"children",
			"childes",
			"child"
		],
		answer: 1
	},
	{
		id: "q17",
		subjectId: "s-his",
		prompt: "भारत का संविधान कब लागू हुआ?",
		options: [
			"15 अगस्त 1947",
			"26 जनवरी 1950",
			"26 नवंबर 1949",
			"2 अक्टूबर 1869"
		],
		answer: 1
	},
	{
		id: "q18",
		subjectId: "s-his",
		prompt: "1526 के पानीपत युद्ध में बाबर का सामना किससे हुआ?",
		options: [
			"इब्राहिम लोदी",
			"अकबर",
			"शिवाजी",
			"टीपू सुल्तान"
		],
		answer: 0
	},
	{
		id: "q19",
		subjectId: "s-his",
		prompt: "सम्राट अशोक किस वंश से थे?",
		options: [
			"गुप्त",
			"मौर्य",
			"मुगल",
			"चोल"
		],
		answer: 1
	},
	{
		id: "q20",
		subjectId: "s-his",
		prompt: "1857 के विद्रोह को अक्सर क्या कहा जाता है?",
		options: [
			"प्रथम स्वतंत्रता संग्राम",
			"जलियाँवाला बाग",
			"असहयोग आंदोलन",
			"भारत छोड़ो"
		],
		answer: 0
	},
	{
		id: "q21",
		subjectId: "s-gk",
		prompt: "बिहार की राजधानी कौन-सी है?",
		options: [
			"गया",
			"पटना",
			"मुजफ्फरपुर",
			"भागलपुर"
		],
		answer: 1
	},
	{
		id: "q22",
		subjectId: "s-gk",
		prompt: "भारत का राष्ट्रीय पक्षी कौन-सा है?",
		options: [
			"मोर",
			"तोता",
			"कबूतर",
			"मैना"
		],
		answer: 0
	},
	{
		id: "q23",
		subjectId: "s-gk",
		prompt: "भारत की राजधानी कहाँ है?",
		options: [
			"मुंबई",
			"कोलकाता",
			"नई दिल्ली",
			"चेन्नई"
		],
		answer: 2
	},
	{
		id: "q24",
		subjectId: "s-gk",
		prompt: "ओलंपिक झंडे में कितने छल्ले होते हैं?",
		options: [
			"4",
			"5",
			"6",
			"7"
		],
		answer: 1
	}
];
var seedAttempts = [
	{
		id: "a1",
		subjectId: "s-math",
		score: 3,
		total: 4,
		at: atDaysAgo(1, 21)
	},
	{
		id: "a2",
		subjectId: "s-sci",
		score: 4,
		total: 4,
		at: atDaysAgo(2, 18)
	},
	{
		id: "a3",
		subjectId: "s-gk",
		score: 2,
		total: 4,
		at: atDaysAgo(0, 7)
	}
];
var seedSessions = [
	{
		id: "ss1",
		subjectId: "s-math",
		minutes: 25,
		at: atDaysAgo(0, 7)
	},
	{
		id: "ss2",
		subjectId: "s-sci",
		minutes: 25,
		at: atDaysAgo(0, 9)
	},
	{
		id: "ss3",
		subjectId: "s-eng",
		minutes: 25,
		at: atDaysAgo(1, 19)
	},
	{
		id: "ss4",
		subjectId: "s-hin",
		minutes: 25,
		at: atDaysAgo(1, 20)
	},
	{
		id: "ss5",
		subjectId: "s-math",
		minutes: 25,
		at: atDaysAgo(2, 18)
	},
	{
		id: "ss6",
		subjectId: "s-his",
		minutes: 50,
		at: atDaysAgo(3, 17)
	},
	{
		id: "ss7",
		subjectId: "s-gk",
		minutes: 25,
		at: atDaysAgo(3, 21)
	},
	{
		id: "ss8",
		subjectId: "s-sci",
		minutes: 25,
		at: atDaysAgo(4, 16)
	},
	{
		id: "ss9",
		subjectId: "s-math",
		minutes: 50,
		at: atDaysAgo(6, 19)
	}
];
function freshTimer(subjectId) {
	const focusMin = 25;
	const durationSec = durationFor("focus", focusMin);
	return {
		status: "idle",
		mode: "focus",
		focusMin,
		durationSec,
		remainingSec: durationSec,
		subjectId,
		endsAt: null
	};
}
function logFocus(sessions, timer, minutes) {
	if (timer.mode !== "focus" || minutes <= 0) return sessions;
	return [...sessions, {
		id: uid(),
		subjectId: timer.subjectId,
		minutes,
		at: Date.now()
	}];
}
function finishFrom(state) {
	const timer = state.timer;
	if (timer.status === "done") return {
		sessions: state.sessions,
		timer
	};
	const minutes = Math.round(timer.durationSec / 60);
	return {
		sessions: logFocus(state.sessions, timer, minutes),
		timer: {
			...timer,
			status: "done",
			remainingSec: 0,
			endsAt: null
		}
	};
}
var seedSlice = () => ({
	subjects: seedSubjects,
	tasks: seedTasks,
	notes: seedNotes,
	questions: seedQuestions,
	attempts: seedAttempts,
	sessions: seedSessions,
	timer: freshTimer("s-math")
});
var useStudy = create()(persist((set, get) => ({
	lang: "hi",
	view: "home",
	name: "",
	dailyGoalMin: 60,
	sound: true,
	...seedSlice(),
	setLang: (lang) => set({ lang }),
	setView: (view) => set({ view }),
	setName: (name) => set({ name }),
	nudgeGoal: (delta) => set((s) => ({ dailyGoalMin: Math.min(180, Math.max(15, s.dailyGoalMin + delta)) })),
	toggleSound: () => set((s) => ({ sound: !s.sound })),
	addSubject: (nameHi, nameEn) => set((s) => {
		const hiName = nameHi.trim() || nameEn.trim();
		const enName = nameEn.trim() || nameHi.trim();
		if (!hiName) return s;
		const subject = {
			id: uid(),
			nameHi: hiName,
			nameEn: enName,
			mark: s.subjects.length % 2 === 0 ? "sage" : "gold"
		};
		return { subjects: [...s.subjects, subject] };
	}),
	renameSubject: (id, nameHi, nameEn) => set((s) => ({ subjects: s.subjects.map((sub) => sub.id === id ? {
		...sub,
		nameHi: nameHi.trim() || sub.nameHi,
		nameEn: nameEn.trim() || nameHi.trim() || sub.nameEn
	} : sub) })),
	removeSubject: (id) => set((s) => ({
		subjects: s.subjects.filter((sub) => sub.id !== id),
		tasks: s.tasks.filter((t) => t.subjectId !== id),
		notes: s.notes.filter((n) => n.subjectId !== id),
		questions: s.questions.filter((q) => q.subjectId !== id),
		timer: s.timer.subjectId === id ? {
			...s.timer,
			subjectId: s.subjects.find((sub) => sub.id !== id)?.id ?? null
		} : s.timer
	})),
	addTask: (subjectId, title) => set((s) => {
		const text = title.trim();
		if (!text) return s;
		return { tasks: [...s.tasks, {
			id: uid(),
			subjectId,
			title: text,
			done: false
		}] };
	}),
	toggleTask: (id) => set((s) => ({ tasks: s.tasks.map((t) => t.id === id ? {
		...t,
		done: !t.done
	} : t) })),
	removeTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),
	addNote: (subjectId) => {
		const id = uid();
		set((s) => ({ notes: [{
			id,
			subjectId,
			title: s.lang === "hi" ? "बिना शीर्षक" : "Untitled",
			body: "",
			updatedAt: Date.now()
		}, ...s.notes] }));
		return id;
	},
	updateNote: (id, patch) => set((s) => ({ notes: s.notes.map((n) => n.id === id ? {
		...n,
		...patch,
		updatedAt: Date.now()
	} : n) })),
	removeNote: (id) => set((s) => ({ notes: s.notes.filter((n) => n.id !== id) })),
	addQuestion: (q) => set((s) => {
		const prompt = q.prompt.trim();
		const options = q.options.map((o) => o.trim());
		if (!prompt || options.some((o) => !o) || options.length < 2) return s;
		return { questions: [...s.questions, {
			...q,
			id: uid(),
			prompt,
			options,
			custom: true
		}] };
	}),
	removeQuestion: (id) => set((s) => ({ questions: s.questions.filter((q) => q.id !== id) })),
	recordAttempt: (subjectId, score, total) => set((s) => ({ attempts: [...s.attempts, {
		id: uid(),
		subjectId,
		score,
		total,
		at: Date.now()
	}] })),
	setTimerSubject: (subjectId) => set((s) => ({ timer: {
		...s.timer,
		subjectId
	} })),
	setMode: (mode) => set((s) => {
		if (s.timer.status === "running") return s;
		const durationSec = durationFor(mode, s.timer.focusMin);
		return { timer: {
			...s.timer,
			mode,
			durationSec,
			remainingSec: durationSec,
			status: "idle",
			endsAt: null
		} };
	}),
	nudgeFocus: (delta) => set((s) => {
		if (s.timer.status === "running" || s.timer.mode !== "focus") return s;
		const focusMin = Math.min(60, Math.max(15, s.timer.focusMin + delta));
		const durationSec = focusMin * 60;
		return { timer: {
			...s.timer,
			focusMin,
			durationSec,
			remainingSec: durationSec,
			status: "idle",
			endsAt: null
		} };
	}),
	startTimer: () => set((s) => {
		const t = s.timer;
		const remaining = t.status === "paused" ? t.remainingSec : t.durationSec;
		return { timer: {
			...t,
			status: "running",
			remainingSec: remaining,
			endsAt: Date.now() + remaining * 1e3
		} };
	}),
	pauseTimer: () => set((s) => {
		const t = s.timer;
		if (t.status !== "running" || !t.endsAt) return s;
		const left = Math.max(0, Math.round((t.endsAt - Date.now()) / 1e3));
		return { timer: {
			...t,
			status: "paused",
			remainingSec: left,
			endsAt: null
		} };
	}),
	resetTimer: () => set((s) => ({ timer: {
		...s.timer,
		status: "idle",
		remainingSec: s.timer.durationSec,
		endsAt: null
	} })),
	stopAndSave: () => set((s) => {
		const t = s.timer;
		const left = t.status === "running" && t.endsAt ? Math.max(0, Math.round((t.endsAt - Date.now()) / 1e3)) : t.remainingSec;
		const elapsedMin = Math.round((t.durationSec - left) / 60);
		return {
			sessions: logFocus(s.sessions, t, elapsedMin),
			timer: {
				...t,
				status: "idle",
				remainingSec: t.durationSec,
				endsAt: null
			}
		};
	}),
	finishTimer: () => set((s) => s.timer.status === "running" ? finishFrom(s) : s),
	reconcileTimer: () => set((s) => {
		const t = s.timer;
		if (t.status !== "running" || !t.endsAt) return s;
		const left = Math.max(0, Math.round((t.endsAt - Date.now()) / 1e3));
		if (left > 0) {
			if (left === t.remainingSec) return s;
			return { timer: {
				...t,
				remainingSec: left
			} };
		}
		return finishFrom(s);
	}),
	beginFocus: () => {
		const s = get();
		if (s.timer.status === "running") {
			set({ view: "timer" });
			return;
		}
		if (s.timer.status === "paused" && s.timer.mode === "focus") {
			get().startTimer();
			set({ view: "timer" });
			return;
		}
		const subjectId = s.timer.subjectId ?? s.subjects[0]?.id ?? null;
		const durationSec = s.timer.focusMin * 60;
		set({
			view: "timer",
			timer: {
				...s.timer,
				mode: "focus",
				subjectId,
				durationSec,
				remainingSec: durationSec,
				status: "running",
				endsAt: Date.now() + durationSec * 1e3
			}
		});
	},
	restoreDemo: () => set((s) => ({
		...seedSlice(),
		lang: s.lang,
		name: s.name,
		sound: s.sound,
		dailyGoalMin: s.dailyGoalMin,
		view: "home"
	}))
}), {
	name: "studyflow",
	partialize: (s) => ({
		lang: s.lang,
		view: s.view,
		name: s.name,
		dailyGoalMin: s.dailyGoalMin,
		sound: s.sound,
		subjects: s.subjects,
		tasks: s.tasks,
		notes: s.notes,
		questions: s.questions,
		attempts: s.attempts,
		sessions: s.sessions,
		timer: s.timer
	})
}));
function useCopy() {
	const lang = useStudy((s) => s.lang);
	return {
		lang,
		t: (key) => dict[lang][key]
	};
}
var fieldClass = "w-full rounded-md border border-border bg-bg px-3 py-3 text-base text-fg outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-primary";
var variants = {
	primary: "bg-primary text-primary-fg hover:opacity-90",
	accent: "bg-accent text-accent-fg hover:opacity-90",
	surface: "border border-border bg-surface text-fg hover:bg-surface-2",
	ghost: "bg-transparent text-fg hover:bg-surface-2"
};
function Button({ variant = "primary", className = "", type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: `inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition-opacity disabled:cursor-not-allowed disabled:opacity-40 ${variants[variant]} ${className}`,
		...props
	});
}
function Monogram({ name, mark }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `grid h-11 w-11 shrink-0 place-items-center rounded-md text-lg font-semibold ${mark === "gold" ? "bg-accent text-accent-fg" : "bg-primary text-primary-fg"}`,
		children: name.slice(0, 1) || "·"
	});
}
function Meter({ pct }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full rounded-full bg-primary",
			style: { width: `${Math.min(100, Math.max(0, pct))}%` }
		})
	});
}
function IconButton({ className = "", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: `grid h-11 w-11 place-items-center rounded-md text-fg hover:bg-surface-2 disabled:opacity-40 ${className}`,
		...props
	});
}
function WeekChart({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-48 w-full text-primary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data,
				margin: {
					top: 12,
					right: 4,
					left: 4,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						axisLine: false,
						tickLine: false,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						cursor: { fill: "var(--color-surface-2)" },
						contentStyle: {
							background: "var(--color-surface)",
							border: "1px solid var(--color-border)",
							borderRadius: 12,
							color: "var(--color-fg)"
						},
						formatter: (value) => [`${Number(value) || 0}`, "min"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "minutes",
						fill: "currentColor",
						radius: [
							8,
							8,
							0,
							0
						],
						maxBarSize: 32
					})
				]
			})
		})
	});
}
function HomeView() {
	const { lang, t } = useCopy();
	const name = useStudy((s) => s.name);
	const setName = useStudy((s) => s.setName);
	const subjects = useStudy((s) => s.subjects);
	const tasks = useStudy((s) => s.tasks);
	const sessions = useStudy((s) => s.sessions);
	const timer = useStudy((s) => s.timer);
	const goal = useStudy((s) => s.dailyGoalMin);
	const nudgeGoal = useStudy((s) => s.nudgeGoal);
	const beginFocus = useStudy((s) => s.beginFocus);
	const toggleTask = useStudy((s) => s.toggleTask);
	const setView = useStudy((s) => s.setView);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const today = todayMinutes(sessions);
	const streak = streakCount(sessions);
	const week = weekSeries(sessions, lang);
	const weekSum = week.reduce((sum, row) => sum + row.minutes, 0);
	const pct = Math.min(100, Math.round(today / goal * 100));
	const open = tasks.filter((task) => !task.done).slice(0, 5);
	const hello = t(greetingKey((/* @__PURE__ */ new Date()).getHours()));
	const subject = subjects.find((item) => item.id === (timer.subjectId ?? subjects[0]?.id));
	const cta = timer.status === "running" ? t("viewTimer") : timer.status === "paused" && timer.mode === "focus" ? t("resumeFocus") : t("startFocus");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl font-semibold",
				children: [hello, name ? `, ${name}` : ""]
			}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-3 flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					setEditing(false);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "min-h-11 flex-1 rounded-md border border-border bg-surface px-3 text-base outline-none focus-visible:ring-2 focus-visible:ring-primary",
					value: name,
					autoFocus: true,
					placeholder: t("namePlaceholder"),
					onChange: (event) => setName(event.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: t("save")
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-1 text-sm text-muted underline-offset-2 hover:text-fg hover:underline",
				onClick: () => setEditing(true),
				children: name ? t("rename") : t("addName")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-28 w-28 shrink-0 place-items-center rounded-full",
							style: { background: `conic-gradient(var(--color-primary) ${pct * 3.6}deg, var(--color-surface-2) 0deg)` },
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid h-20 w-20 place-items-center rounded-full bg-surface text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-2xl font-semibold tabular-nums leading-none",
									children: today
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: t("minutesWord")
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t("todayStudy")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-lg font-semibold",
									children: today >= goal ? t("goalMet") : `${today} / ${goal}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "grid h-11 w-11 place-items-center rounded-md border border-border text-lg",
											"aria-label": t("goalDown"),
											onClick: () => nudgeGoal(-15),
											children: "−"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-sm text-muted",
											children: [
												t("dailyGoal"),
												" ",
												goal
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "grid h-11 w-11 place-items-center rounded-md border border-border text-lg",
											"aria-label": t("goalUp"),
											onClick: () => nudgeGoal(15),
											children: "+"
										})
									]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
									className: "size-4 text-accent",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold tabular-nums",
									children: streak
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: t("streak")
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: beginFocus,
							children: cta
						})]
					}),
					subject ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 truncate text-sm text-muted",
						children: subjectName(subject, lang)
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: t("openTasks")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm text-primary",
					onClick: () => setView("subjects"),
					children: t("subjects")
				})]
			}), open.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-border bg-surface px-4 py-5 text-sm text-muted",
				children: t("allDone")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "overflow-hidden rounded-lg border border-border bg-surface",
				children: open.map((task) => {
					const sub = subjects.find((item) => item.id === task.subjectId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-b border-border last:border-b-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-12 items-center gap-3 px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "size-5 accent-primary",
								checked: task.done,
								onChange: () => toggleTask(task.id)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate",
									children: task.title
								}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-xs text-muted",
									children: subjectName(sub, lang)
								}) : null]
							})]
						})
					}, task.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: t("week")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm text-primary",
							onClick: () => setView("progress"),
							children: t("progress")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-2 text-sm text-muted",
						children: [
							t("weekTotal"),
							": ",
							formatSpan(weekSum, lang)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekChart, { data: week }),
					weekSum === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t("noMinutes")
					}) : null
				]
			}),
			subjects.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid grid-cols-2 gap-3",
				children: subjects.slice(0, 4).map((sub) => {
					const prog = taskProgress(tasks, sub.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "rounded-lg border border-border bg-surface p-3 text-left",
						onClick: () => setView("subjects"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monogram, {
								name: subjectName(sub, lang),
								mark: sub.mark
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 truncate font-semibold",
								children: subjectName(sub, lang)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted tabular-nums",
								children: [
									prog.done,
									"/",
									prog.total
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, { pct: prog.pct })
							})
						]
					}, sub.id);
				})
			}) : null
		]
	});
}
function NotesView() {
	const { lang, t } = useCopy();
	const subjects = useStudy((s) => s.subjects);
	const notes = useStudy((s) => s.notes);
	const addNote = useStudy((s) => s.addNote);
	const updateNote = useStudy((s) => s.updateNote);
	const removeNote = useStudy((s) => s.removeNote);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [query, setQuery] = (0, import_react.useState)("");
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const visible = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return [...notes].filter((note) => filter === "all" ? true : note.subjectId === filter).filter((note) => {
			if (!q) return true;
			return `${note.title} ${note.body}`.toLowerCase().includes(q);
		}).sort((a, b) => b.updatedAt - a.updatedAt);
	}, [
		notes,
		filter,
		query
	]);
	const active = notes.find((note) => note.id === activeId) ?? null;
	function create() {
		const subjectId = filter !== "all" ? filter : subjects[0]?.id;
		if (!subjectId) return;
		const id = addNote(subjectId);
		setActiveId(id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 md:grid md:grid-cols-[16rem_minmax(0,1fr)] md:items-start md:gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: active ? "hidden md:block" : "",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl font-semibold",
						children: t("notes")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: create,
						disabled: subjects.length === 0,
						children: t("newNote")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: query,
					placeholder: t("searchNotes"),
					onChange: (e) => setQuery(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2 overflow-x-auto pb-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						active: filter === "all",
						onClick: () => setFilter("all"),
						children: t("allSubjects")
					}), subjects.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						active: filter === sub.id,
						onClick: () => setFilter(sub.id),
						children: subjectName(sub, lang)
					}, sub.id))]
				}),
				visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: t("noNotes")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-2",
					children: visible.map((note) => {
						const sub = subjects.find((item) => item.id === note.subjectId);
						const on = note.id === activeId;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `w-full rounded-lg border px-3 py-3 text-left ${on ? "border-primary bg-surface-2" : "border-border bg-surface"}`,
							onClick: () => setActiveId(note.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-semibold",
								children: note.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 block truncate text-sm text-muted",
								children: [
									sub ? subjectName(sub, lang) : "",
									" ·",
									" ",
									new Date(note.updatedAt).toLocaleDateString(lang === "hi" ? "hi-IN" : "en-IN", {
										day: "numeric",
										month: "short"
									})
								]
							})]
						}) }, note.id);
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: !active ? "hidden md:block" : "",
			children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 md:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							"aria-label": t("back"),
							onClick: () => setActiveId(null),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: t("notes")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: active.title,
						"aria-label": t("noteTitle"),
						onChange: (e) => updateNote(active.id, { title: e.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: active.subjectId,
						"aria-label": t("subjects"),
						onChange: (e) => updateNote(active.id, { subjectId: e.target.value }),
						children: subjects.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: sub.id,
							children: subjectName(sub, lang)
						}, sub.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} min-h-64 resize-y leading-relaxed`,
						value: active.body,
						placeholder: t("noteBody"),
						onChange: (e) => updateNote(active.id, { body: e.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: () => {
							removeNote(active.id);
							setActiveId(null);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), t("delete")]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden rounded-lg border border-border bg-surface px-4 py-10 text-center text-sm text-muted md:block",
				children: t("pickNote")
			})
		})]
	});
}
function FilterChip({ active, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: `min-h-11 shrink-0 rounded-full border px-3 text-sm ${active ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface text-fg"}`,
		onClick,
		children
	});
}
function ProgressView() {
	const { lang, t } = useCopy();
	const subjects = useStudy((s) => s.subjects);
	const tasks = useStudy((s) => s.tasks);
	const sessions = useStudy((s) => s.sessions);
	const attempts = useStudy((s) => s.attempts);
	const restoreDemo = useStudy((s) => s.restoreDemo);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const week = weekSeries(sessions, lang);
	const weekSum = week.reduce((sum, row) => sum + row.minutes, 0);
	const totalMin = sessions.reduce((sum, session) => sum + session.minutes, 0);
	const streak = streakCount(sessions);
	const tasksStat = taskProgress(tasks);
	const avg = attempts.length ? Math.round(attempts.reduce((sum, attempt) => sum + (attempt.total ? attempt.score / attempt.total * 100 : 0), 0) / attempts.length) : 0;
	const bySubject = subjects.map((sub) => ({
		id: sub.id,
		name: subjectName(sub, lang),
		minutes: sessions.filter((session) => session.subjectId === sub.id).reduce((sum, session) => sum + session.minutes, 0)
	})).sort((a, b) => b.minutes - a.minutes);
	const maxMin = Math.max(1, ...bySubject.map((row) => row.minutes));
	const recent = [...attempts].reverse().slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold",
				children: t("progress")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t("totalFocus"),
						value: formatSpan(totalMin, lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t("streak"),
						value: String(streak)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t("quizAvg"),
						value: `${avg}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t("tasksDone"),
						value: `${tasksStat.done}/${tasksStat.total}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-baseline justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: t("week")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted tabular-nums",
							children: formatSpan(weekSum, lang)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekChart, { data: week }),
					weekSum === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t("noMinutes")
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-lg font-semibold",
					children: t("perSubject")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-3",
					children: bySubject.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-baseline justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-medium",
							children: row.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 tabular-nums text-muted",
							children: formatSpan(row.minutes, lang)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `h-full rounded-full ${index === 0 && row.minutes > 0 ? "bg-accent" : "bg-primary"}`,
							style: { width: `${row.minutes / maxMin * 100}%` }
						})
					})] }, row.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-lg font-semibold",
				children: t("recentQuizzes")
			}), recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("noQuizzes")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "overflow-hidden rounded-lg border border-border bg-surface",
				children: recent.map((attempt) => {
					const sub = subjects.find((item) => item.id === attempt.subjectId);
					const pct = attempt.total ? Math.round(attempt.score / attempt.total * 100) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 border-b border-border px-3 py-3 last:border-b-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-medium",
								children: sub ? subjectName(sub, lang) : t("quiz")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: new Date(attempt.at).toLocaleDateString(lang === "hi" ? "hi-IN" : "en-IN", {
									day: "numeric",
									month: "short"
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold tabular-nums",
							children: [
								attempt.score,
								"/",
								attempt.total,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-2 text-sm text-muted",
									children: [pct, "%"]
								})
							]
						})]
					}, attempt.id);
				})
			})] }),
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: t("confirmRestore")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "accent",
						onClick: restoreDemo,
						children: t("yes")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						onClick: () => setConfirm(false),
						children: t("cancel")
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: () => setConfirm(true),
				children: t("restore")
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-surface px-3 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-2xl font-semibold tabular-nums",
			children: value
		})]
	});
}
function QuizView() {
	const { lang, t } = useCopy();
	const subjects = useStudy((s) => s.subjects);
	const questions = useStudy((s) => s.questions);
	const attempts = useStudy((s) => s.attempts);
	const addQuestion = useStudy((s) => s.addQuestion);
	const removeQuestion = useStudy((s) => s.removeQuestion);
	const recordAttempt = useStudy((s) => s.recordAttempt);
	const [phase, setPhase] = (0, import_react.useState)("pick");
	const [subjectId, setSubjectId] = (0, import_react.useState)(null);
	const [order, setOrder] = (0, import_react.useState)([]);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [checked, setChecked] = (0, import_react.useState)(false);
	const [score, setScore] = (0, import_react.useState)(0);
	const [adding, setAdding] = (0, import_react.useState)(false);
	const bank = questions.filter((q) => q.subjectId === subjectId);
	const current = questions.find((q) => q.id === order[index]);
	const custom = questions.filter((q) => q.custom && q.subjectId === subjectId);
	function start(id) {
		const ids = questions.filter((q) => q.subjectId === id).map((q) => q.id);
		if (ids.length === 0) {
			setSubjectId(id);
			return;
		}
		const next = [...ids];
		for (let i = next.length - 1; i > 0; i--) {
			const j = Math.floor(Math.random() * (i + 1));
			const swap = next[i] ?? "";
			next[i] = next[j] ?? "";
			next[j] = swap;
		}
		setSubjectId(id);
		setOrder(next);
		setIndex(0);
		setPicked(null);
		setChecked(false);
		setScore(0);
		setPhase("play");
	}
	function resetPick() {
		setPhase("pick");
		setOrder([]);
		setIndex(0);
		setPicked(null);
		setChecked(false);
	}
	if (phase === "result") {
		const total = order.length || 1;
		const pct = Math.round(score / total * 100);
		const message = pct >= 80 ? t("great") : pct >= 50 ? t("good") : t("againSoon");
		const sub = subjects.find((item) => item.id === subjectId);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-md flex-col items-center gap-4 py-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: sub ? subjectName(sub, lang) : t("resultTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-6xl font-semibold tabular-nums",
					children: [score, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-2xl text-muted",
						children: ["/", order.length]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted tabular-nums",
					children: [pct, "%"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							if (subjectId) start(subjectId);
						},
						children: t("retry")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						onClick: resetPick,
						children: t("back")
					})]
				})
			]
		});
	}
	if (phase === "play" && current) {
		const last = index === order.length - 1;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						t("question"),
						" ",
						index + 1,
						"/",
						order.length
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 text-fg",
						onClick: resetPick,
						children: t("back")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-primary",
						style: { width: `${(index + (checked ? 1 : 0)) / order.length * 100}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold leading-snug",
					children: current.prompt
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: current.options.map((option, optionIndex) => {
						const isAnswer = optionIndex === current.answer;
						const isPicked = optionIndex === picked;
						let tone = "border-border bg-surface";
						if (checked && isAnswer) tone = "border-primary bg-primary text-primary-fg";
						else if (checked && isPicked) tone = "border-accent bg-surface text-accent";
						else if (isPicked) tone = "border-primary bg-surface-2";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: checked,
							className: `min-h-12 rounded-md border px-3 py-3 text-left text-base disabled:cursor-default ${tone}`,
							onClick: () => setPicked(optionIndex),
							children: option
						}, `${current.id}-${optionIndex}`);
					})
				}),
				checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `text-sm font-semibold ${picked === current.answer ? "text-primary" : "text-accent"}`,
					children: picked === current.answer ? t("correct") : t("wrong")
				}) : null,
				!checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: picked === null,
					onClick: () => {
						setChecked(true);
						if (picked === current.answer) setScore((value) => value + 1);
					},
					children: t("check")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						if (last) {
							if (subjectId) recordAttempt(subjectId, score, order.length);
							setPhase("result");
							return;
						}
						setIndex((value) => value + 1);
						setPicked(null);
						setChecked(false);
					},
					children: last ? t("seeResult") : t("next")
				})
			]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: t("quiz")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "surface",
					onClick: () => setAdding((value) => !value),
					children: adding ? t("close") : t("addQuestion")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: subjects.map((sub) => {
					const count = questions.filter((q) => q.subjectId === sub.id).length;
					const last = [...attempts].reverse().find((a) => a.subjectId === sub.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center justify-between gap-3 rounded-lg border border-border bg-surface px-4 py-3 text-left",
						onClick: () => start(sub.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: subjectName(sub, lang)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-muted",
							children: [
								count,
								" ",
								t("questionsN"),
								last ? ` · ${t("lastScore")} ${last.score}/${last.total}` : ""
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold text-primary",
							children: count ? t("startQuiz") : t("addQuestion")
						})]
					}) }, sub.id);
				})
			}),
			subjectId && bank.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("noQuestions")
			}) : null,
			adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddQuestion, {
				subjectId: subjectId ?? subjects[0]?.id ?? "",
				subjects: subjects.map((sub) => ({
					id: sub.id,
					name: subjectName(sub, lang)
				})),
				onSave: (draft) => {
					addQuestion(draft);
					setSubjectId(draft.subjectId);
				}
			}) : null,
			custom.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: custom.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 rounded-md border border-border px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-sm",
						children: q.prompt
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 shrink-0 text-sm text-accent",
						onClick: () => removeQuestion(q.id),
						children: t("delete")
					})]
				}, q.id))
			}) : null
		]
	});
}
function AddQuestion({ subjectId, subjects, onSave }) {
	const { t } = useCopy();
	const [sid, setSid] = (0, import_react.useState)(subjectId);
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [options, setOptions] = (0, import_react.useState)([
		"",
		"",
		"",
		""
	]);
	const [answer, setAnswer] = (0, import_react.useState)(0);
	const ready = prompt.trim().length > 0 && options.every((option) => option.trim().length > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-col gap-3 rounded-lg border border-border bg-surface p-4",
		onSubmit: (event) => {
			event.preventDefault();
			if (!ready || !sid) return;
			onSave({
				subjectId: sid,
				prompt,
				options,
				answer
			});
			setPrompt("");
			setOptions([
				"",
				"",
				"",
				""
			]);
			setAnswer(0);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-sm text-muted",
				children: [t("subjects"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: fieldClass,
					value: sid,
					onChange: (e) => setSid(e.target.value),
					children: subjects.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: sub.id,
						children: sub.name
					}, sub.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-sm text-muted",
				children: [t("prompt"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${fieldClass} min-h-20`,
					value: prompt,
					onChange: (e) => setPrompt(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "mb-1 text-sm text-muted",
					children: t("markCorrect")
				}), options.map((option, optionIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "radio",
						className: "size-5 accent-primary",
						name: "correct-option",
						checked: answer === optionIndex,
						onChange: () => setAnswer(optionIndex)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						placeholder: `${t("option")} ${optionIndex + 1}`,
						value: option,
						onChange: (e) => setOptions((current) => current.map((item, i) => i === optionIndex ? e.target.value : item))
					})]
				}, optionIndex))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: !ready,
				children: t("save")
			})
		]
	});
}
function SubjectsView() {
	const { lang, t } = useCopy();
	const subjects = useStudy((s) => s.subjects);
	const tasks = useStudy((s) => s.tasks);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [nameHi, setNameHi] = (0, import_react.useState)("");
	const [nameEn, setNameEn] = (0, import_react.useState)("");
	const addSubject = useStudy((s) => s.addSubject);
	const open = subjects.find((sub) => sub.id === openId);
	if (open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubjectDetail, {
		id: open.id,
		onBack: () => setOpenId(null)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: t("subjects")
				}), !adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setAdding(true),
					children: t("addSubject")
				}) : null]
			}),
			adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3 rounded-lg border border-border bg-surface p-4",
				onSubmit: (event) => {
					event.preventDefault();
					addSubject(nameHi, nameEn);
					setNameHi("");
					setNameEn("");
					setAdding(false);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-1 text-sm text-muted",
						children: [t("subjectHi"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: nameHi,
							onChange: (e) => setNameHi(e.target.value),
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-1 text-sm text-muted",
						children: [t("subjectEn"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: nameEn,
							onChange: (e) => setNameEn(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: t("save")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "surface",
							onClick: () => setAdding(false),
							children: t("cancel")
						})]
					})
				]
			}) : null,
			subjects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-border bg-surface px-4 py-8 text-center text-sm text-muted",
				children: t("noSubjects")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: subjects.map((sub) => {
					const prog = taskProgress(tasks, sub.id);
					const label = subjectName(sub, lang);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center gap-3 rounded-lg border border-border bg-surface p-3 text-left",
						onClick: () => setOpenId(sub.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monogram, {
							name: label,
							mark: sub.mark
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-semibold",
									children: label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 block text-xs text-muted tabular-nums",
									children: [
										prog.done,
										"/",
										prog.total,
										" · ",
										prog.pct,
										"%"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, { pct: prog.pct })
								})
							]
						})]
					}) }, sub.id);
				})
			})
		]
	});
}
function SubjectDetail({ id, onBack }) {
	const { lang, t } = useCopy();
	const subject = useStudy((s) => s.subjects.find((item) => item.id === id));
	const allTasks = useStudy((s) => s.tasks);
	const tasks = (0, import_react.useMemo)(() => allTasks.filter((task) => task.subjectId === id), [allTasks, id]);
	const toggleTask = useStudy((s) => s.toggleTask);
	const addTask = useStudy((s) => s.addTask);
	const removeTask = useStudy((s) => s.removeTask);
	const removeSubject = useStudy((s) => s.removeSubject);
	const renameSubject = useStudy((s) => s.renameSubject);
	const [title, setTitle] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [renaming, setRenaming] = (0, import_react.useState)(false);
	const [nameHi, setNameHi] = (0, import_react.useState)(subject?.nameHi ?? "");
	const [nameEn, setNameEn] = (0, import_react.useState)(subject?.nameEn ?? "");
	if (!subject) return null;
	const prog = taskProgress(tasks);
	const label = subjectName(subject, lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					"aria-label": t("back"),
					onClick: onBack,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "min-w-0 flex-1 truncate text-2xl font-semibold",
					children: label
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t("tasks")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold tabular-nums",
						children: [
							prog.done,
							"/",
							prog.total
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, { pct: prog.pct })
				})]
			}),
			renaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3 rounded-lg border border-border bg-surface p-4",
				onSubmit: (event) => {
					event.preventDefault();
					renameSubject(id, nameHi, nameEn);
					setRenaming(false);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: nameHi,
						onChange: (e) => setNameHi(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: nameEn,
						onChange: (e) => setNameEn(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: t("save")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "surface",
							onClick: () => setRenaming(false),
							children: t("cancel")
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "surface",
				onClick: () => setRenaming(true),
				children: t("rename")
			}),
			tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("noTasks")
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "overflow-hidden rounded-lg border border-border bg-surface",
				children: tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-1 border-b border-border last:border-b-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-12 min-w-0 flex-1 items-center gap-3 px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "size-5 accent-primary",
							checked: task.done,
							onChange: () => toggleTask(task.id)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: task.done ? "truncate text-muted line-through" : "truncate",
							children: task.title
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
						"aria-label": t("delete"),
						onClick: () => removeTask(task.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-muted" })
					})]
				}, task.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					addTask(id, title);
					setTitle("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: title,
					placeholder: t("taskPlaceholder"),
					onChange: (e) => setTitle(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: t("addTask")
				})]
			}),
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: t("confirmDelete")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "accent",
						onClick: () => {
							removeSubject(id);
							onBack();
						},
						children: t("yes")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						onClick: () => setConfirm(false),
						children: t("cancel")
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: () => setConfirm(true),
				children: t("delete")
			})
		]
	});
}
function chime() {
	const Ctx = window.AudioContext;
	if (!Ctx) return;
	const ctx = new Ctx();
	const now = ctx.currentTime;
	[
		523.25,
		659.25,
		783.99
	].forEach((freq, i) => {
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = freq;
		const start = now + i * .08;
		gain.gain.setValueAtTime(1e-4, start);
		gain.gain.exponentialRampToValueAtTime(.05, start + .03);
		gain.gain.exponentialRampToValueAtTime(1e-4, start + .38);
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start(start);
		osc.stop(start + .4);
	});
	window.setTimeout(() => void ctx.close(), 1400);
}
var MODES = [
	"focus",
	"short",
	"long"
];
function TimerView() {
	const { lang, t } = useCopy();
	const subjects = useStudy((s) => s.subjects);
	const sessions = useStudy((s) => s.sessions);
	const timer = useStudy((s) => s.timer);
	const sound = useStudy((s) => s.sound);
	const toggleSound = useStudy((s) => s.toggleSound);
	const setTimerSubject = useStudy((s) => s.setTimerSubject);
	const setMode = useStudy((s) => s.setMode);
	const nudgeFocus = useStudy((s) => s.nudgeFocus);
	const startTimer = useStudy((s) => s.startTimer);
	const pauseTimer = useStudy((s) => s.pauseTimer);
	const resetTimer = useStudy((s) => s.resetTimer);
	const stopAndSave = useStudy((s) => s.stopAndSave);
	const ratio = timer.durationSec === 0 ? 0 : timer.remainingSec / timer.durationSec;
	const radius = 52;
	const circ = 2 * Math.PI * radius;
	const locked = timer.status === "running";
	const elapsed = timer.durationSec - timer.remainingSec;
	const modeLabel = timer.mode === "focus" ? t("focus") : timer.mode === "short" ? t("shortBreak") : t("longBreak");
	const ring = timer.mode === "focus" ? "stroke-primary" : "stroke-accent";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: t("timer")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid h-11 w-11 place-items-center rounded-md hover:bg-surface-2",
					"aria-label": sound ? t("soundOn") : t("soundOff"),
					onClick: () => {
						toggleSound();
						if (!sound) chime();
					},
					children: sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5 text-muted" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: subjects.map((sub) => {
					const active = timer.subjectId === sub.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `min-h-11 shrink-0 rounded-full border px-4 text-sm font-medium ${active ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface text-fg"}`,
						onClick: () => setTimerSubject(sub.id),
						children: subjectName(sub, lang)
					}, sub.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: MODES.map((mode) => {
					const active = timer.mode === mode;
					const label = mode === "focus" ? t("focus") : mode === "short" ? t("shortBreak") : t("longBreak");
					const mins = Math.round(durationFor(mode, timer.focusMin) / 60);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: locked,
						className: `min-h-11 rounded-md border px-2 text-sm font-medium disabled:opacity-50 ${active ? "border-primary bg-surface-2 text-fg" : "border-border bg-surface text-muted"}`,
						onClick: () => setMode(mode),
						children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-xs tabular-nums opacity-80",
							children: mins
						})]
					}, mode);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto grid h-64 w-64 place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 120 120",
					className: "h-64 w-64",
					"aria-hidden": "true",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: radius,
						className: "stroke-surface-2",
						strokeWidth: "8",
						fill: "none"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: radius,
						className: ring,
						strokeWidth: "8",
						fill: "none",
						strokeLinecap: "round",
						strokeDasharray: circ,
						strokeDashoffset: circ * (1 - ratio),
						transform: "rotate(-90 60 60)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 grid place-items-center text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-6xl font-semibold tabular-nums tracking-tight",
						children: formatClock(timer.remainingSec)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: modeLabel
					})] })
				})]
			}),
			timer.mode === "focus" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid h-11 w-11 place-items-center rounded-md border border-border disabled:opacity-40",
						"aria-label": t("shorter"),
						disabled: locked,
						onClick: () => nudgeFocus(-5),
						children: "−"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-24 text-center text-sm tabular-nums",
						children: [
							timer.focusMin,
							" ",
							t("minutesWord")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid h-11 w-11 place-items-center rounded-md border border-border disabled:opacity-40",
						"aria-label": t("longer"),
						disabled: locked,
						onClick: () => nudgeFocus(5),
						children: "+"
					})
				]
			}) : null,
			timer.status === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-surface px-4 py-4 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-semibold",
						children: t("doneTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: timer.mode === "focus" ? t("doneFocus") : t("doneBreak")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap justify-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								setMode("focus");
								startTimer();
							},
							children: t("again")
						}), timer.mode === "focus" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "surface",
							onClick: () => {
								setMode("short");
								startTimer();
							},
							children: t("startBreak")
						}) : null]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-center gap-2",
				children: [timer.status === "running" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: pauseTimer,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }), t("pause")]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: startTimer,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), timer.status === "paused" ? t("resume") : t("start")]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "surface",
					onClick: resetTimer,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), t("reset")]
				})]
			}),
			timer.mode === "focus" && elapsed >= 60 && timer.status !== "idle" && timer.status !== "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-center text-sm text-primary",
				onClick: stopAndSave,
				children: t("saveStop")
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-sm text-muted",
				children: [
					t("todayStudy"),
					": ",
					todayMinutes(sessions),
					" ",
					t("minutesWord")
				]
			})
		]
	});
}
var NAV = [
	{
		view: "home",
		key: "home",
		icon: House
	},
	{
		view: "subjects",
		key: "subjects",
		icon: BookOpen
	},
	{
		view: "timer",
		key: "timer",
		icon: Timer
	},
	{
		view: "notes",
		key: "notes",
		icon: NotebookPen
	},
	{
		view: "quiz",
		key: "quiz",
		icon: CircleHelp
	},
	{
		view: "progress",
		key: "progress",
		icon: ChartColumn
	}
];
function StudyApp() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const persisted = useStudy.persist;
		if (persisted.hasHydrated()) setReady(true);
		return persisted.onFinishHydration(() => setReady(true));
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerEngine, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {})] });
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-bg px-6 text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-primary",
					children: "STUDYFLOW"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-semibold",
					children: "स्मार्ट पढ़ाई"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "विषय · टाइमर · क्विज़"
				})
			]
		})
	});
}
function TimerEngine() {
	const status = useStudy((s) => s.timer.status);
	const sound = useStudy((s) => s.sound);
	const prev = (0, import_react.useRef)(status);
	(0, import_react.useEffect)(() => {
		useStudy.getState().reconcileTimer();
		const id = window.setInterval(() => useStudy.getState().reconcileTimer(), 250);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		if (prev.current === "running" && status === "done" && useStudy.getState().sound) chime();
		prev.current = status;
	}, [status, sound]);
	return null;
}
function Shell() {
	const { lang, t } = useCopy();
	const view = useStudy((s) => s.view);
	const setView = useStudy((s) => s.setView);
	const setLang = useStudy((s) => s.setLang);
	const timer = useStudy((s) => s.timer);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang === "hi" ? "hi" : "en";
	}, [lang]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-5xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-border px-4 py-6 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-primary",
						children: "STUDYFLOW"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: t("tagline")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 flex flex-col gap-1",
						"aria-label": t("primaryNav"),
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							item,
							active: view === item.view,
							onClick: () => setView(item.view),
							rail: true
						}, item.view))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur md:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-widest text-primary",
									children: "STUDYFLOW"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t("tagline")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden text-sm text-muted md:block",
								children: t("tagline")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex rounded-full border border-border p-1",
								role: "group",
								"aria-label": t("switchLang"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangButton, {
									active: lang === "hi",
									onClick: () => setLang("hi"),
									children: t("langHi")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangButton, {
									active: lang === "en",
									onClick: () => setLang("en"),
									children: t("langEn")
								})]
							})
						]
					}),
					timer.status === "done" && view !== "timer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mx-4 mt-3 min-h-11 rounded-md border border-primary bg-surface px-3 text-sm font-medium text-primary md:mx-8",
						onClick: () => setView("timer"),
						children: timer.mode === "focus" ? t("focusDone") : t("breakDone")
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "flex-1 px-4 pb-24 pt-4 md:px-8 md:pb-10",
						"data-view": view,
						children: [
							view === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {}) : null,
							view === "subjects" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubjectsView, {}) : null,
							view === "timer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerView, {}) : null,
							view === "notes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesView, {}) : null,
							view === "quiz" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizView, {}) : null,
							view === "progress" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressView, {}) : null
						]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 backdrop-blur md:hidden",
			"aria-label": t("primaryNav"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-lg grid-cols-6 px-1 pb-2 pt-1",
				children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
					item,
					active: view === item.view,
					onClick: () => setView(item.view)
				}, item.view))
			})
		})]
	});
}
function NavButton({ item, active, onClick, rail = false }) {
	const { t } = useCopy();
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-current": active ? "page" : void 0,
		className: rail ? `flex min-h-11 items-center gap-3 rounded-md px-3 text-sm font-medium ${active ? "bg-surface text-fg" : "text-muted hover:bg-surface-2 hover:text-fg"}` : `flex min-h-12 min-w-0 flex-col items-center justify-center gap-1 rounded-md px-0.5 text-xs ${active ? "text-primary" : "text-muted"}`,
		onClick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: rail ? "size-4" : "size-5",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: rail ? "" : "max-w-full truncate",
			children: t(item.key)
		})]
	});
}
function LangButton({ active, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: `min-h-11 rounded-full px-3 text-sm font-medium ${active ? "bg-primary text-primary-fg" : "text-muted"}`,
		"aria-pressed": active,
		onClick,
		children
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudyApp, {});
}
//#endregion
export { Home as component };
