import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay$1, d as Slot, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { a as Settings, c as Pause, d as Crosshair, f as Bell, i as Target, l as MessageSquare, o as ScanSearch, r as Timer, s as Play, t as X, u as Globe } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CqIcKSJ1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return crypto.randomUUID();
}
function istParts(date = /* @__PURE__ */ new Date()) {
	const parts = new Intl.DateTimeFormat("en-GB", {
		timeZone: "Asia/Kolkata",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hourCycle: "h23",
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		weekday: "short"
	}).formatToParts(date);
	const get = (type) => parts.find((p) => p.type === type)?.value ?? "";
	return {
		hour: get("hour"),
		minute: get("minute"),
		second: get("second"),
		year: get("year"),
		month: get("month"),
		day: get("day"),
		weekday: get("weekday"),
		hhmm: `${get("hour")}:${get("minute")}`,
		dateKey: `${get("year")}-${get("month")}-${get("day")}`
	};
}
function formatIstClock(lang, date = /* @__PURE__ */ new Date()) {
	return new Intl.DateTimeFormat(lang === "mr" ? "mr-IN" : "en-IN", {
		timeZone: "Asia/Kolkata",
		weekday: "long",
		day: "numeric",
		month: "short",
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23"
	}).format(date);
}
function formatRelative(ts, lang) {
	const diff = Date.now() - ts;
	const min = Math.round(diff / 6e4);
	if (min < 1) return lang === "mr" ? "आत्ताच" : "just now";
	if (min < 60) return lang === "mr" ? `${min} मिना पूर्वी` : `${min}m ago`;
	const hr = Math.round(min / 60);
	if (hr < 24) return lang === "mr" ? `${hr} तास पूर्वी` : `${hr}h ago`;
	const d = Math.round(hr / 24);
	return lang === "mr" ? `${d} दिवस पूर्वी` : `${d}d ago`;
}
function normalizeUrl(raw) {
	const trimmed = raw.trim();
	if (!trimmed) return "";
	if (/^https?:\/\//i.test(trimmed)) return trimmed;
	return `https://${trimmed}`;
}
function extractUrl(text) {
	const match = text.match(/https?:\/\/[^\s]+/i) ?? text.match(/\b(?:www\.)[^\s]+/i);
	return match ? normalizeUrl(match[0]) : "";
}
function smsHref(phone, body) {
	return `sms:${phone.replace(/[^\d+]/g, "")}${typeof navigator !== "undefined" && /iPhone|iPad|iPod/i.test(navigator.userAgent) ? "&" : "?"}body=${encodeURIComponent(body)}`;
}
function playSignal() {
	try {
		const ctx = new (window.AudioContext || window.webkitAudioContext)();
		const beep = (freq, start, dur) => {
			const osc = ctx.createOscillator();
			const gain = ctx.createGain();
			osc.type = "sine";
			osc.frequency.value = freq;
			gain.gain.setValueAtTime(1e-4, start);
			gain.gain.exponentialRampToValueAtTime(.05, start + .02);
			gain.gain.exponentialRampToValueAtTime(1e-4, start + dur);
			osc.connect(gain);
			gain.connect(ctx.destination);
			osc.start(start);
			osc.stop(start + dur + .02);
		};
		const t = ctx.currentTime;
		beep(880, t, .11);
		beep(660, t + .14, .16);
		ctx.resume();
	} catch {}
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg border border-border hover:bg-surface",
			ghost: "text-fg hover:bg-surface-2",
			outline: "border border-border bg-transparent text-fg hover:bg-surface-2",
			destructive: "bg-alert text-fg hover:opacity-90",
			link: "text-fg underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-bg/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg max-h-[min(90dvh,720px)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-xl border border-border bg-surface p-5 shadow-lg duration-[var(--motion-fast)] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-3 right-3 rounded-md p-2 text-muted hover:bg-surface-2 hover:text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1 pr-8", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-4 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-xl leading-snug text-fg", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-11 w-full rounded-md border border-border bg-surface-2 px-3 text-sm text-fg shadow-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-xs font-medium text-muted", className),
	...props
}));
Label.displayName = Root.displayName;
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border border-border transition-colors duration-[var(--motion-quick)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-surface-2", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block size-5 rounded-full bg-fg shadow-sm ring-0 transition-transform duration-[var(--motion-quick)] data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0.5 data-[state=checked]:bg-primary-fg") })
}));
Switch.displayName = Switch$1.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	className: cn("flex min-h-24 w-full rounded-lg border border-border bg-surface-2 px-3 py-3 text-sm text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Textarea.displayName = "Textarea";
var copy = {
	mr: {
		app: "लक्ष",
		appLatin: "Laksha",
		tagline: "२४ तास जागे. वेळीच इशारा.",
		live: "लाईव्ह",
		hub: "केंद्र",
		alerts: "इशारे",
		sms: "SMS",
		settings: "सेटिंग्ज",
		ask: "काय बघायचं आहे?",
		placeholder: "उदा. साइट पडली तर सांग, सकाळी ८ वाजता गोळी, भाव ७२००० खाली गेला तर SMS…",
		watchIt: "लक्ष लावा",
		watching: "सक्रिय लक्ष",
		primary: "मुख्य लक्ष",
		empty: "अजून काहीच नाही. वर लिहा — २४ तास लक्ष ठेवतो.",
		emptyAlerts: "अजून इशारा नाही. लक्ष लावा, किंवा टेस्ट दाबा.",
		emptySms: "SMS इथे दिसतील. फोन नंबर सेटिंग्जमध्ये टाका.",
		kindSite: "संकेतस्थळ",
		kindReminder: "आठवण",
		kindTarget: "लक्ष्य",
		kindKeyword: "शब्द",
		kindCustom: "इतर",
		url: "लिंक / URL",
		urlHint: "https://…",
		keyword: "बघायचा शब्द",
		targetValue: "लक्ष्य आकडा",
		currentValue: "आत्ताचा आकडा",
		above: "वर गेल्यावर",
		below: "खाली आल्यावर",
		reminderMode: "कधी?",
		daily: "दररोज",
		every5: "दर ५ मि",
		everyHour: "दर १ तास",
		every6h: "दर ६ तास",
		atTime: "वेळ",
		channels: "इशारा कसा?",
		notif: "नोटिफिकेशन",
		smsChannel: "SMS",
		title: "नाव",
		note: "तुम्ही सांगितलं",
		save: "लागू करा",
		cancel: "रद्द",
		delete: "काढून टाका",
		checkNow: "आता तपासा",
		testAlert: "टेस्ट अलर्ट",
		markSeen: "घडलं",
		pin: "मुख्य करा",
		unpin: "मुख्य काढा",
		paused: "थांबवले",
		pause: "थांबवा",
		resume: "पुन्हा चालू",
		up: "चालू आहे",
		down: "पडली",
		unknown: "तपासतोय",
		recovered: "परत चालू",
		watchingFor: "लक्ष",
		alertsToday: "आजचे इशारे",
		smsOut: "SMS",
		since: "पासून जागे",
		settingsTitle: "सेटिंग्ज",
		language: "भाषा",
		marathi: "मराठी",
		english: "English",
		phone: "तुमचा फोन नंबर",
		phoneHint: "SMS या नंबरवर जाईल",
		notifyPerm: "ब्राउझर नोटिफिकेशन",
		enableNotify: "परवानगी द्या",
		notifyOn: "सुरू आहे",
		notifyDenied: "बंद आहे — ब्राउझर सेटिंग बदला",
		sound: "आवाज",
		quiet: "शांत तास",
		quietHint: "या वेळेत आवाज/नोटिफिकेशन नाही, SMS लॉग होईल",
		quietFrom: "पासून",
		quietTo: "पर्यंत",
		openSms: "फोनच्या SMS अॅपमध्ये उघडा",
		fromLaksha: "लक्ष २४/७",
		refine: "तपशील",
		requiredUrl: "संकेतस्थळासाठी लिंक हवी",
		addPhone: "आधी फोन नंबर टाका",
		siteDown: "साइट प्रतिसाद देत नाही",
		siteUp: "साइट चालू आहे",
		reminderFire: "आठवणीची वेळ झाली",
		targetHit: "लक्ष्य गाठलं",
		keywordHit: "शब्द दिसला",
		customFire: "लक्षात आणून देतो",
		testBody: "टेस्ट इशारा — लक्ष २४ तास जागे आहे.",
		seen: "वाचले",
		unread: "नवे",
		latency: "प्रतिसाद",
		lastCheck: "शेवटची तपासणी",
		noUrl: "लिंक नाही",
		valueNow: "आत्ता",
		crosses: "ओलांडलं की इशारा",
		keywordScan: "हा शब्द दिसला",
		composerHint: "एक वाक्य पुरे. प्रकार आपोआप ओळखेल.",
		footer: "टॅब उघडा ठेवा — लक्ष तपासत राहील.",
		wipe: "सगळं पुसा",
		wipeConfirm: "सगळी लक्ष आणि इशारे जातील.",
		ok: "ठीक",
		statusOk: "ठीक",
		statusAlert: "इशारा",
		channelBoth: "नोटिफिकेशन + SMS",
		delivered: "पाठवला",
		inbox: "इनबॉक्स",
		typeHere: "नवीन लक्ष लिहा…",
		close: "बंद",
		checking: "तपासतोय…",
		failedCheck: "तपासणी अयशस्वी",
		hoursWatch: "तास लक्ष"
	},
	en: {
		app: "Laksha",
		appLatin: "Laksha",
		tagline: "Awake all day. Alert on time.",
		live: "LIVE",
		hub: "Hub",
		alerts: "Alerts",
		sms: "SMS",
		settings: "Settings",
		ask: "What should I watch?",
		placeholder: "e.g. ping me if the site is down, 8am medicine, SMS if price drops below 72000…",
		watchIt: "Watch this",
		watching: "Active watches",
		primary: "Primary watch",
		empty: "Nothing yet. Tell it what to watch — it stays on 24/7.",
		emptyAlerts: "No alerts yet. Add a watch, or send a test.",
		emptySms: "SMS will land here. Add your number in Settings.",
		kindSite: "Website",
		kindReminder: "Reminder",
		kindTarget: "Target",
		kindKeyword: "Keyword",
		kindCustom: "Other",
		url: "Link / URL",
		urlHint: "https://…",
		keyword: "Keyword to watch",
		targetValue: "Target number",
		currentValue: "Current number",
		above: "When it goes above",
		below: "When it goes below",
		reminderMode: "When?",
		daily: "Daily",
		every5: "Every 5 min",
		everyHour: "Every hour",
		every6h: "Every 6 hours",
		atTime: "Time",
		channels: "How to alert?",
		notif: "Notification",
		smsChannel: "SMS",
		title: "Name",
		note: "What you said",
		save: "Save",
		cancel: "Cancel",
		delete: "Remove",
		checkNow: "Check now",
		testAlert: "Test alert",
		markSeen: "It happened",
		pin: "Make primary",
		unpin: "Unpin",
		paused: "Paused",
		pause: "Pause",
		resume: "Resume",
		up: "Up",
		down: "Down",
		unknown: "Checking",
		recovered: "Back up",
		watchingFor: "Watching",
		alertsToday: "Alerts today",
		smsOut: "SMS",
		since: "awake since",
		settingsTitle: "Settings",
		language: "Language",
		marathi: "मराठी",
		english: "English",
		phone: "Your phone number",
		phoneHint: "SMS alerts go to this number",
		notifyPerm: "Browser notifications",
		enableNotify: "Allow",
		notifyOn: "On",
		notifyDenied: "Blocked — change browser settings",
		sound: "Sound",
		quiet: "Quiet hours",
		quietHint: "No sound/notification in this window. SMS still logs.",
		quietFrom: "From",
		quietTo: "Until",
		openSms: "Open in phone SMS app",
		fromLaksha: "Laksha 24/7",
		refine: "Details",
		requiredUrl: "A link is needed for website watches",
		addPhone: "Add a phone number first",
		siteDown: "Site is not responding",
		siteUp: "Site is up",
		reminderFire: "Reminder time",
		keywordHit: "Keyword seen",
		targetHit: "Target reached",
		customFire: "Bringing this back to you",
		testBody: "Test ping — Laksha is awake 24/7.",
		seen: "Read",
		unread: "New",
		latency: "Latency",
		lastCheck: "Last check",
		noUrl: "No link",
		valueNow: "Now",
		crosses: "Alert when it crosses",
		keywordScan: "I saw this word",
		composerHint: "One sentence is enough. The type is detected.",
		footer: "Keep this tab open — Laksha keeps checking.",
		wipe: "Clear everything",
		wipeConfirm: "All watches and alerts will be removed.",
		ok: "OK",
		statusOk: "OK",
		statusAlert: "Alert",
		channelBoth: "Notification + SMS",
		delivered: "Sent",
		inbox: "Inbox",
		typeHere: "Write a new watch…",
		close: "Close",
		checking: "Checking…",
		failedCheck: "Check failed",
		hoursWatch: "hours on watch"
	}
};
var SEED_START = Date.now() - 396e5;
var SEED_WATCHES = [
	{
		id: "w-wiki",
		title: "विकिपीडिया",
		note: "साइट पडली तर लगेच सांग — २४ तास लक्ष.",
		kind: "site",
		url: "https://www.wikipedia.org",
		channels: {
			notification: true,
			sms: true
		},
		enabled: true,
		pinned: true,
		lastStatus: "unknown",
		createdAt: SEED_START,
		triggeredCount: 0
	},
	{
		id: "w-gold",
		title: "सोन्याचा भाव",
		note: "२२ कॅरेट भाव ७२००० च्या खाली गेला तर SMS.",
		kind: "target",
		targetValue: 72e3,
		currentValue: 73850,
		targetDirection: "below",
		channels: {
			notification: true,
			sms: true
		},
		enabled: true,
		pinned: false,
		lastStatus: "ok",
		createdAt: SEED_START + 12e4,
		triggeredCount: 0
	},
	{
		id: "w-med",
		title: "गोड्याच्या गोळ्या",
		note: "सकाळी ८ वाजता गोळी घ्यायची आठवण.",
		kind: "reminder",
		reminderMode: "daily",
		reminderAt: "08:00",
		channels: {
			notification: true,
			sms: true
		},
		enabled: true,
		pinned: false,
		lastStatus: "ok",
		lastFiredDate: "",
		createdAt: SEED_START + 24e4,
		triggeredCount: 1
	},
	{
		id: "w-result",
		title: "परीक्षा निकाल",
		note: "निकाल जाहीर झाला की लगेच खबर.",
		kind: "keyword",
		keyword: "निकाल जाहीर",
		channels: {
			notification: true,
			sms: true
		},
		enabled: true,
		pinned: false,
		lastStatus: "ok",
		createdAt: SEED_START + 36e4,
		triggeredCount: 0
	}
];
var seedAlertId = "a-med-1";
var SEED_ALERTS = [{
	id: seedAlertId,
	watchId: "w-med",
	title: "गोड्याच्या गोळ्या",
	body: "सकाळी ८:०० — गोळी घ्यायची वेळ झाली.",
	kind: "reminder",
	sms: true,
	notification: true,
	createdAt: SEED_START + 288e5,
	read: true
}];
var SEED_SMS = [{
	id: "s-med-1",
	alertId: seedAlertId,
	body: "लक्ष: गोड्याच्या गोळ्या — सकाळी ८:००, गोळी घ्यायची वेळ झाली.",
	createdAt: SEED_START + 288e5
}];
function emptyDraft(note = "") {
	return {
		title: "",
		note,
		kind: detectKind(note),
		url: "",
		keyword: "",
		targetValue: "",
		currentValue: "",
		targetDirection: "below",
		reminderMode: "daily",
		reminderAt: "09:00",
		notification: true,
		sms: true
	};
}
function detectKind(text) {
	const t = text.toLowerCase();
	if (/https?:\/\/|www\.|\.co\.|\.in\b|\.com\b|साइट|साईट|वेबसाइट|website|url/.test(t)) return "site";
	if (/₹|किंमत|भाव|रुपये|target|सोने|gold|price|\d{4,}/.test(t)) return "target";
	if (/रोज|सकाळ|रात्री|वाजता|आठवण|reminder|गोळी|medicine|बिल|तास/.test(t)) return "reminder";
	if (/शब्द|keyword|निकाल|result|जाहीर/.test(t)) return "keyword";
	return "custom";
}
function intervalMs(mode) {
	if (mode === "every5") return 3e5;
	if (mode === "everyHour") return 36e5;
	if (mode === "every6h") return 216e5;
	return 0;
}
function titleFromDraft(d) {
	if (d.title.trim()) return d.title.trim();
	const n = d.note.trim();
	if (n.length <= 28) return n || "लक्ष";
	return `${n.slice(0, 26)}…`;
}
var useLaksha = create()(persist((set, get) => ({
	hasSeeded: true,
	startedAt: SEED_START,
	lang: "mr",
	phone: "",
	sound: true,
	quietOn: false,
	quietFrom: "22:00",
	quietTo: "07:00",
	primaryId: "w-wiki",
	watches: SEED_WATCHES,
	alerts: SEED_ALERTS,
	sms: SEED_SMS,
	setLang: (lang) => set({ lang }),
	setPhone: (phone) => set({ phone }),
	setSound: (sound) => set({ sound }),
	setQuiet: (quietOn, quietFrom, quietTo) => set({
		quietOn,
		quietFrom: quietFrom ?? get().quietFrom,
		quietTo: quietTo ?? get().quietTo
	}),
	addWatch: (draft) => {
		const id = uid();
		const watch = {
			id,
			title: titleFromDraft(draft),
			note: draft.note.trim(),
			kind: draft.kind,
			url: draft.url.trim() || void 0,
			keyword: draft.keyword.trim() || void 0,
			targetValue: draft.targetValue ? Number(draft.targetValue) : void 0,
			currentValue: draft.currentValue ? Number(draft.currentValue) : void 0,
			targetDirection: draft.targetDirection,
			reminderMode: draft.reminderMode,
			reminderAt: draft.reminderAt,
			channels: {
				notification: draft.notification,
				sms: draft.sms
			},
			enabled: true,
			pinned: get().watches.length === 0,
			lastStatus: "unknown",
			lastFiredAt: Date.now(),
			createdAt: Date.now(),
			triggeredCount: 0
		};
		set((s) => ({
			watches: [watch, ...s.watches],
			primaryId: s.primaryId ?? id
		}));
		return id;
	},
	updateWatch: (id, patch) => set((s) => ({ watches: s.watches.map((w) => w.id === id ? {
		...w,
		...patch
	} : w) })),
	removeWatch: (id) => set((s) => ({
		watches: s.watches.filter((w) => w.id !== id),
		primaryId: s.primaryId === id ? s.watches.find((w) => w.id !== id)?.id ?? null : s.primaryId
	})),
	pinWatch: (id) => set((s) => ({
		primaryId: id,
		watches: s.watches.map((w) => ({
			...w,
			pinned: w.id === id
		}))
	})),
	recordCheck: (id, patch) => set((s) => ({ watches: s.watches.map((w) => w.id === id ? {
		...w,
		...patch
	} : w) })),
	fireAlert: ({ watch, body, force, status }) => {
		const now = Date.now();
		if (!force && watch.lastFiredAt && now - watch.lastFiredAt < 9e4) return null;
		const alert = {
			id: uid(),
			watchId: watch.id,
			title: watch.title,
			body,
			kind: watch.kind,
			sms: watch.channels.sms,
			notification: watch.channels.notification,
			createdAt: now,
			read: false
		};
		const smsItem = watch.channels.sms ? {
			id: uid(),
			alertId: alert.id,
			body: `लक्ष: ${watch.title} — ${body}`,
			createdAt: now
		} : null;
		const dateKey = istParts().dateKey;
		set((s) => ({
			alerts: [alert, ...s.alerts].slice(0, 200),
			sms: smsItem ? [smsItem, ...s.sms].slice(0, 200) : s.sms,
			watches: s.watches.map((w) => w.id === watch.id ? {
				...w,
				lastFiredAt: now,
				lastFiredDate: dateKey,
				lastMessage: body,
				triggeredCount: w.triggeredCount + 1,
				lastStatus: status ?? "alert"
			} : w)
		}));
		return alert;
	},
	markAlertsRead: () => set((s) => ({ alerts: s.alerts.map((a) => a.read ? a : {
		...a,
		read: true
	}) })),
	wipe: () => set({
		watches: [],
		alerts: [],
		sms: [],
		primaryId: null,
		startedAt: Date.now()
	})
}), {
	name: "laksha-v1",
	skipHydration: true
}));
function inQuietHours(state) {
	if (!state.quietOn) return false;
	const { hhmm } = istParts();
	const cur = hhmm;
	const from = state.quietFrom;
	const to = state.quietTo;
	if (from <= to) return cur >= from && cur < to;
	return cur >= from || cur < to;
}
var KINDS = [
	"site",
	"reminder",
	"target",
	"keyword",
	"custom"
];
var MODES = [
	"daily",
	"every5",
	"everyHour",
	"every6h"
];
function AddWatchDialog({ open, note, onOpenChange }) {
	const lang = useLaksha((s) => s.lang);
	const addWatch = useLaksha((s) => s.addWatch);
	const t = copy[lang];
	const [draft, setDraft] = (0, import_react.useState)(() => emptyDraft(note));
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const next = emptyDraft(note);
		const url = extractUrl(note);
		if (url) {
			next.kind = "site";
			next.url = url;
		}
		setDraft(next);
		setError("");
	}, [open, note]);
	const kindLabel = {
		site: t.kindSite,
		reminder: t.kindReminder,
		target: t.kindTarget,
		keyword: t.kindKeyword,
		custom: t.kindCustom
	};
	const modeLabel = {
		daily: t.daily,
		every5: t.every5,
		everyHour: t.everyHour,
		every6h: t.every6h
	};
	function save() {
		if (draft.kind === "site" && !draft.url.trim()) {
			setError(t.requiredUrl);
			return;
		}
		addWatch(draft);
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t.refine }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t.composerHint })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "note",
							children: t.note
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "note",
							value: draft.note,
							onChange: (e) => setDraft((d) => ({
								...d,
								note: e.target.value
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "title",
							children: t.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "title",
							value: draft.title,
							placeholder: t.title,
							onChange: (e) => setDraft((d) => ({
								...d,
								title: e.target.value
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t.refine }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDraft((d) => ({
									...d,
									kind: k
								})),
								className: cn("h-9 rounded-full border px-3 text-xs font-medium", draft.kind === k ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface-2 text-muted"),
								children: kindLabel[k]
							}, k))
						})]
					}),
					draft.kind === "site" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "url",
							children: t.url
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "url",
							value: draft.url,
							placeholder: t.urlHint,
							onChange: (e) => setDraft((d) => ({
								...d,
								url: e.target.value
							}))
						})]
					}),
					draft.kind === "keyword" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "kw",
							children: t.keyword
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "kw",
							value: draft.keyword,
							onChange: (e) => setDraft((d) => ({
								...d,
								keyword: e.target.value
							}))
						})]
					}),
					draft.kind === "target" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "tgt",
									children: t.targetValue
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "tgt",
									inputMode: "decimal",
									value: draft.targetValue,
									onChange: (e) => setDraft((d) => ({
										...d,
										targetValue: e.target.value
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "cur",
									children: t.currentValue
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "cur",
									inputMode: "decimal",
									value: draft.currentValue,
									onChange: (e) => setDraft((d) => ({
										...d,
										currentValue: e.target.value
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-2 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: cn("h-9 flex-1 rounded-full border text-xs font-medium", draft.targetDirection === "below" ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface-2 text-muted"),
									onClick: () => setDraft((d) => ({
										...d,
										targetDirection: "below"
									})),
									children: t.below
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: cn("h-9 flex-1 rounded-full border text-xs font-medium", draft.targetDirection === "above" ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface-2 text-muted"),
									onClick: () => setDraft((d) => ({
										...d,
										targetDirection: "above"
									})),
									children: t.above
								})]
							})
						]
					}),
					draft.kind === "reminder" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDraft((d) => ({
									...d,
									reminderMode: m
								})),
								className: cn("h-9 rounded-full border px-3 text-xs font-medium", draft.reminderMode === m ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface-2 text-muted"),
								children: modeLabel[m]
							}, m))
						}), draft.reminderMode === "daily" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "time",
								children: t.atTime
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "time",
								type: "time",
								value: draft.reminderAt,
								onChange: (e) => setDraft((d) => ({
									...d,
									reminderAt: e.target.value
								}))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 rounded-lg border border-border bg-surface-2 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t.channels }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: t.notif
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: draft.notification,
									onCheckedChange: (v) => setDraft((d) => ({
										...d,
										notification: v
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: t.smsChannel
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: draft.sms,
									onCheckedChange: (v) => setDraft((d) => ({
										...d,
										sms: v
									}))
								})]
							})
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-alert",
						children: error
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => onOpenChange(false),
				children: t.cancel
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				children: t.save
			})] })
		] })
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var checkUrlHealth = createServerFn({ method: "POST" }).validator(object({ url: string().min(1).max(2e3) })).handler(createSsrRpc("4c4eb8872214c81e1a792ddd5c3b8ae4ea56b02a8894d5be3588ea1e9c714cf8"));
function deliver(watch, body, force = false, status) {
	if (!useLaksha.getState().fireAlert({
		watch,
		body,
		force,
		status
	})) return;
	const state = useLaksha.getState();
	const quiet = inQuietHours(state);
	const c = copy[state.lang];
	if (watch.channels.notification && !quiet) {
		try {
			if (typeof Notification !== "undefined" && Notification.permission === "granted") new Notification(`${c.app}: ${watch.title}`, {
				body,
				tag: watch.id
			});
		} catch {}
		toast(watch.title, { description: body });
	} else toast(watch.title, { description: body });
	if (state.sound && !quiet) playSignal();
	try {
		navigator.vibrate?.(160);
	} catch {}
}
async function runSiteCheck(watch, force) {
	if (!watch.url) return;
	const c = copy[useLaksha.getState().lang];
	useLaksha.getState().recordCheck(watch.id, {
		lastCheckedAt: Date.now(),
		lastStatus: watch.lastStatus,
		lastMessage: c.checking
	});
	try {
		const res = await checkUrlHealth({ data: { url: watch.url } });
		const prev = useLaksha.getState().watches.find((w) => w.id === watch.id);
		if (!prev) return;
		if (res.ok) {
			useLaksha.getState().recordCheck(watch.id, {
				lastCheckedAt: res.checkedAt,
				lastStatus: "ok",
				lastLatencyMs: res.ms,
				lastMessage: `${c.siteUp} · ${res.status} · ${res.ms}ms`
			});
			if (prev.lastStatus === "alert") deliver({
				...prev,
				lastStatus: "ok"
			}, `${c.recovered} — ${watch.url}`, true, "ok");
		} else {
			useLaksha.getState().recordCheck(watch.id, {
				lastCheckedAt: res.checkedAt,
				lastStatus: "alert",
				lastLatencyMs: res.ms,
				lastMessage: `${c.siteDown} · ${res.status || "—"}`
			});
			if (force || prev.lastStatus !== "alert") deliver(prev, `${c.siteDown}${watch.url ? ` — ${watch.url}` : ""}`, force);
		}
	} catch {
		useLaksha.getState().recordCheck(watch.id, {
			lastCheckedAt: Date.now(),
			lastStatus: "alert",
			lastMessage: c.failedCheck
		});
	}
}
function tickReminders() {
	const { watches, lang } = useLaksha.getState();
	const c = copy[lang];
	const parts = istParts();
	for (const watch of watches) {
		if (!watch.enabled || watch.kind !== "reminder") continue;
		const mode = watch.reminderMode ?? "daily";
		if (mode === "daily") {
			if (watch.reminderAt === parts.hhmm && watch.lastFiredDate !== parts.dateKey) deliver(watch, `${c.reminderFire} · ${watch.reminderAt} — ${watch.note || watch.title}`);
		} else {
			const gap = intervalMs(mode);
			if (gap && Date.now() - (watch.lastFiredAt ?? watch.createdAt) >= gap) deliver(watch, `${c.reminderFire} — ${watch.note || watch.title}`);
		}
	}
}
function useEngine() {
	const checking = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const remind = window.setInterval(tickReminders, 1e3);
		const sites = window.setInterval(async () => {
			if (checking.current) return;
			const due = useLaksha.getState().watches.filter((w) => w.enabled && w.kind === "site" && w.url).filter((w) => !w.lastCheckedAt || Date.now() - w.lastCheckedAt > 45e3);
			if (due.length === 0) return;
			checking.current = true;
			try {
				await Promise.all(due.slice(0, 3).map((w) => runSiteCheck(w, false)));
			} finally {
				checking.current = false;
			}
		}, 4e3);
		const first = useLaksha.getState().watches.find((w) => w.enabled && w.kind === "site" && w.url);
		if (first) runSiteCheck(first, false);
		return () => {
			window.clearInterval(remind);
			window.clearInterval(sites);
		};
	}, []);
}
function checkWatchNow(watch) {
	if (watch.kind === "site") {
		runSiteCheck(watch, true);
		return;
	}
	const c = copy[useLaksha.getState().lang];
	if (watch.kind === "target") {
		deliver(watch, crossesTarget(watch) ? `${c.targetHit} — ${watch.currentValue} / ${watch.targetValue}` : `${c.valueNow} ${watch.currentValue ?? "—"}`, true);
		return;
	}
	if (watch.kind === "keyword") {
		deliver(watch, `${c.keywordHit}: ${watch.keyword ?? watch.note}`, true);
		return;
	}
	deliver(watch, watch.note || c.testBody, true);
}
function crossesTarget(watch) {
	if (watch.currentValue == null || watch.targetValue == null) return false;
	if (watch.targetDirection === "above") return watch.currentValue >= watch.targetValue;
	return watch.currentValue <= watch.targetValue;
}
function sendTestAlert(watch) {
	const c = copy[useLaksha.getState().lang];
	const status = watch.lastStatus === "unknown" ? "ok" : watch.lastStatus;
	deliver(watch, c.testBody, true, status);
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "border-border bg-surface-2 text-muted",
		live: "border-signal/30 bg-signal/10 text-signal",
		alert: "border-alert/30 bg-alert/10 text-alert",
		ok: "border-signal/30 bg-signal/10 text-signal",
		solid: "border-transparent bg-primary text-primary-fg"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var KIND_ICON = {
	site: Globe,
	reminder: Timer,
	target: Crosshair,
	keyword: ScanSearch,
	custom: Bell
};
function WatchCard({ watch, featured = false }) {
	const lang = useLaksha((s) => s.lang);
	const primaryId = useLaksha((s) => s.primaryId);
	const updateWatch = useLaksha((s) => s.updateWatch);
	const removeWatch = useLaksha((s) => s.removeWatch);
	const pinWatch = useLaksha((s) => s.pinWatch);
	const t = copy[lang];
	const Icon = KIND_ICON[watch.kind];
	const kindLabel = {
		site: t.kindSite,
		reminder: t.kindReminder,
		target: t.kindTarget,
		keyword: t.kindKeyword,
		custom: t.kindCustom
	};
	const statusVariant = !watch.enabled ? "default" : watch.lastStatus === "alert" ? "alert" : watch.lastStatus === "ok" ? "ok" : "live";
	const statusText = !watch.enabled ? t.paused : watch.lastStatus === "alert" ? t.statusAlert : watch.lastStatus === "ok" ? t.statusOk : t.unknown;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("flex flex-col gap-3 border border-border bg-surface p-4", featured ? "rounded-xl p-5" : "rounded-lg"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md border border-border bg-surface-2 text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "truncate font-display text-lg leading-snug text-fg",
								children: watch.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: statusVariant,
								children: statusText
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs text-muted",
							children: kindLabel[watch.kind]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 text-muted",
					children: [watch.channels.notification ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-3.5" }) : null, watch.channels.sms ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "size-3.5" }) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-normal text-fg/90",
				children: watch.note
			}),
			watch.kind === "site" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate font-mono text-xs text-muted",
				children: watch.url ?? t.noUrl
			}),
			watch.kind === "target" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-sm tabular-nums text-fg",
						children: [
							t.valueNow,
							" ",
							watch.currentValue ?? "—"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted",
						children: [
							"/ ",
							watch.targetValue,
							" (",
							watch.targetDirection === "below" ? t.below : t.above,
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => {
								const next = (watch.currentValue ?? 0) - 250;
								updateWatch(watch.id, { currentValue: next });
								const updated = {
									...watch,
									currentValue: next
								};
								if (crossesTarget(updated)) checkWatchNow(updated);
							},
							children: "−250"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => {
								const next = (watch.currentValue ?? 0) + 250;
								updateWatch(watch.id, { currentValue: next });
							},
							children: "+250"
						})]
					})
				]
			}),
			watch.kind === "keyword" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					t.keyword,
					": ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg",
						children: watch.keyword
					})
				]
			}),
			watch.kind === "reminder" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: watch.reminderMode === "daily" ? `${t.daily} ${watch.reminderAt}` : watch.reminderMode === "every5" ? t.every5 : watch.reminderMode === "everyHour" ? t.everyHour : t.every6h
			}),
			watch.lastMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					watch.lastCheckedAt ? `${formatRelative(watch.lastCheckedAt, lang)} · ` : null,
					watch.lastMessage,
					watch.lastLatencyMs != null ? ` · ${watch.lastLatencyMs}ms` : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => checkWatchNow(watch),
						children: watch.kind === "keyword" ? t.markSeen : t.checkNow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => sendTestAlert(watch),
						children: t.testAlert
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						className: "size-9",
						"aria-label": watch.enabled ? t.pause : t.resume,
						onClick: () => updateWatch(watch.id, { enabled: !watch.enabled }),
						children: watch.enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5" })
					}),
					primaryId !== watch.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => pinWatch(watch.id),
						children: t.pin
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => removeWatch(watch.id),
						children: t.delete
					})
				]
			})
		]
	});
}
function LakshaApp() {
	const [tab, setTab] = (0, import_react.useState)("hub");
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [note, setNote] = (0, import_react.useState)("");
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const [notifyState, setNotifyState] = (0, import_react.useState)("default");
	const lang = useLaksha((s) => s.lang);
	const watches = useLaksha((s) => s.watches);
	const alerts = useLaksha((s) => s.alerts);
	const sms = useLaksha((s) => s.sms);
	const primaryId = useLaksha((s) => s.primaryId);
	const startedAt = useLaksha((s) => s.startedAt);
	const markAlertsRead = useLaksha((s) => s.markAlertsRead);
	useEngine();
	(0, import_react.useEffect)(() => {
		useLaksha.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof Notification === "undefined") {
			setNotifyState("unsupported");
			return;
		}
		setNotifyState(Notification.permission);
	}, []);
	(0, import_react.useEffect)(() => {
		if (tab === "alerts") markAlertsRead();
	}, [tab, markAlertsRead]);
	const t = copy[lang];
	const unread = alerts.filter((a) => !a.read).length;
	const todayKey = (0, import_react.useMemo)(() => {
		return new Intl.DateTimeFormat("en-GB", {
			timeZone: "Asia/Kolkata",
			year: "numeric",
			month: "2-digit",
			day: "2-digit"
		}).format(now);
	}, [now]);
	const alertsToday = alerts.filter((a) => {
		return new Intl.DateTimeFormat("en-GB", {
			timeZone: "Asia/Kolkata",
			year: "numeric",
			month: "2-digit",
			day: "2-digit"
		}).format(new Date(a.createdAt)) === todayKey;
	}).length;
	const hoursOn = Math.max(1, Math.round((Date.now() - startedAt) / 36e5));
	const primary = watches.find((w) => w.id === primaryId) ?? watches[0];
	const rest = watches.filter((w) => w.id !== primary?.id);
	const liveCount = watches.filter((w) => w.enabled).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { classNames: {
					toast: "bg-surface text-fg border-border",
					title: "text-fg",
					description: "text-muted"
				} }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-dvh max-w-6xl md:grid md:grid-cols-[220px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "hidden border-r border-border md:flex md:flex-col md:gap-6 md:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {
							hoursOn,
							live: liveCount > 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "flex flex-col gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
									id: "hub",
									tab,
									setTab,
									label: t.hub,
									icon: Target
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
									id: "alerts",
									tab,
									setTab,
									label: t.alerts,
									icon: Bell,
									badge: unread
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
									id: "sms",
									tab,
									setTab,
									label: t.sms,
									icon: MessageSquare,
									badge: sms.length
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
									id: "settings",
									tab,
									setTab,
									label: t.settings,
									icon: Settings
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-auto text-xs leading-normal text-subtle",
							children: t.footer
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col pb-24 md:pb-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/95 px-4 py-3 md:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-3 md:hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Iris, { live: liveCount > 0 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl leading-tight",
										children: t.app
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted",
										children: t.tagline
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden font-mono text-sm tabular-nums text-muted md:block",
								children: formatIstClock(lang, now)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "ml-auto flex items-center gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 rounded-full border border-signal/30 bg-signal/10 px-2.5 py-1 text-xs font-medium text-signal",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-signal" }), t.live]
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "flex-1 px-4 py-5 md:px-8 md:py-8",
						children: [
							tab === "hub" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hub, {
								note,
								setNote,
								onAdd: () => setDialogOpen(true),
								primary,
								rest,
								liveCount,
								alertsToday,
								smsCount: sms.length,
								hoursOn
							}),
							tab === "alerts" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertsView, {}),
							tab === "sms" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmsView, {}),
							tab === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {
								notifyState,
								setNotifyState
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBtn, {
							id: "hub",
							tab,
							setTab,
							label: t.hub,
							icon: Target
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBtn, {
							id: "alerts",
							tab,
							setTab,
							label: t.alerts,
							icon: Bell,
							badge: unread
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBtn, {
							id: "sms",
							tab,
							setTab,
							label: t.sms,
							icon: MessageSquare
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBtn, {
							id: "settings",
							tab,
							setTab,
							label: t.settings,
							icon: Settings
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddWatchDialog, {
				open: dialogOpen,
				note,
				onOpenChange: (o) => {
					setDialogOpen(o);
					if (!o) setNote("");
				}
			})
		]
	});
}
function Brand({ hoursOn, live }) {
	const t = copy[useLaksha((s) => s.lang)];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Iris, { live }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl leading-tight",
			children: t.app
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted",
			children: [
				hoursOn,
				" ",
				t.hoursWatch
			]
		})] })]
	});
}
function Iris({ live }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "iris",
		"aria-hidden": "true",
		children: [
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "iris-sweep" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "iris-ring" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "iris-ring-mid" }),
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "iris-pulse" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "iris-pip" })
		]
	});
}
function NavBtn({ id, tab, setTab, label, icon: Icon, badge }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setTab(id),
		className: cn("flex h-11 items-center gap-3 rounded-md px-3 text-sm", tab === id ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 text-left",
				children: label
			}),
			badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-alert/20 px-1.5 font-mono text-xs tabular-nums text-alert",
				children: badge
			}) : null
		]
	});
}
function TabBtn({ id, tab, setTab, label, icon: Icon, badge }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setTab(id),
		className: cn("relative flex min-h-14 flex-col items-center justify-center gap-1 text-xs", tab === id ? "text-fg" : "text-muted"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }),
			label,
			badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 right-1/4 size-1.5 rounded-full bg-alert" }) : null
		]
	});
}
function Hub({ note, setNote, onAdd, primary, rest, liveCount, alertsToday, smsCount, hoursOn }) {
	const t = copy[useLaksha((s) => s.lang)];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2 md:gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t.watchingFor,
						value: String(liveCount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t.alertsToday,
						value: String(alertsToday)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t.smsOut,
						value: String(smsCount)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-surface p-4 md:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "composer",
						className: "text-sm text-fg",
						children: t.ask
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: t.composerHint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "composer",
						className: "mt-3 min-h-28 rounded-lg",
						placeholder: t.placeholder,
						value: note,
						onChange: (e) => setNote(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-subtle",
							children: [
								hoursOn,
								" ",
								t.hoursWatch
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: onAdd,
							disabled: !note.trim(),
							children: t.watchIt
						})]
					})
				]
			}),
			primary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: t.primary
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WatchCard, {
					watch: primary,
					featured: true
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-dashed border-border px-4 py-8 text-center text-sm text-muted",
				children: t.empty
			}),
			rest.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: t.watching
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: rest.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WatchCard, { watch: w }, w.id))
				})]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-2xl tabular-nums leading-none text-fg",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: label
		})]
	});
}
function AlertsView() {
	const lang = useLaksha((s) => s.lang);
	const alerts = useLaksha((s) => s.alerts);
	const t = copy[lang];
	if (alerts.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: t.emptyAlerts
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "flex flex-col gap-3",
		children: alerts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-lg border border-border bg-surface p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-fg",
					children: a.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-normal text-muted",
					children: a.body
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
					className: "shrink-0 font-mono text-xs tabular-nums text-subtle",
					children: formatRelative(a.createdAt, lang)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-subtle",
				children: a.notification && a.sms ? t.channelBoth : a.sms ? t.sms : t.notif
			})]
		}, a.id))
	});
}
function SmsView() {
	const lang = useLaksha((s) => s.lang);
	const phone = useLaksha((s) => s.phone);
	const sms = useLaksha((s) => s.sms);
	const t = copy[lang];
	const latest = sms[0];
	if (sms.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: t.emptySms
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-md flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-xl border border-border bg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-9 items-center justify-center rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-4 text-muted" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: t.fromLaksha
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs text-muted",
					children: phone || "—"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex max-h-[60dvh] flex-col gap-3 overflow-y-auto bg-bg px-4 py-4",
				children: [...sms].reverse().map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-[85%] rounded-lg rounded-tl-xs bg-surface-2 px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-normal text-fg",
						children: m.body
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-xs tabular-nums text-subtle",
						children: [
							formatRelative(m.createdAt, lang),
							" · ",
							t.delivered
						]
					})]
				}, m.id))
			})]
		}), latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "secondary",
			disabled: !phone,
			onClick: () => {
				if (!phone) return;
				window.location.href = smsHref(phone, latest.body);
			},
			children: phone ? t.openSms : t.addPhone
		}) : null]
	});
}
function SettingsView({ notifyState, setNotifyState }) {
	const lang = useLaksha((s) => s.lang);
	const phone = useLaksha((s) => s.phone);
	const sound = useLaksha((s) => s.sound);
	const quietOn = useLaksha((s) => s.quietOn);
	const quietFrom = useLaksha((s) => s.quietFrom);
	const quietTo = useLaksha((s) => s.quietTo);
	const setLang = useLaksha((s) => s.setLang);
	const setPhone = useLaksha((s) => s.setPhone);
	const setSound = useLaksha((s) => s.setSound);
	const setQuiet = useLaksha((s) => s.setQuiet);
	const wipe = useLaksha((s) => s.wipe);
	const t = copy[lang];
	async function enableNotify() {
		if (typeof Notification === "undefined") {
			setNotifyState("unsupported");
			return;
		}
		setNotifyState(await Notification.requestPermission());
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-lg flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t.language }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: lang === "mr" ? "default" : "secondary",
						onClick: () => setLang("mr"),
						children: t.marathi
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: lang === "en" ? "default" : "secondary",
						onClick: () => setLang("en"),
						children: t.english
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2 rounded-lg border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "phone",
						children: t.phone
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: t.phoneHint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "phone",
						inputMode: "tel",
						placeholder: "+91 98765 43210",
						value: phone,
						onChange: (e) => setPhone(e.target.value)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex items-center justify-between gap-3 rounded-lg border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: t.notifyPerm
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: notifyState === "granted" ? t.notifyOn : notifyState === "denied" ? t.notifyDenied : t.enableNotify
				})] }), notifyState !== "granted" && notifyState !== "unsupported" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => void enableNotify(),
					children: t.enableNotify
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex items-center justify-between rounded-lg border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: t.sound
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: sound,
					onCheckedChange: setSound
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3 rounded-lg border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: t.quiet
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: t.quietHint
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: quietOn,
						onCheckedChange: (v) => setQuiet(v)
					})]
				}), quietOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "qf",
							children: t.quietFrom
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "qf",
							type: "time",
							value: quietFrom,
							onChange: (e) => setQuiet(true, e.target.value, quietTo)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "qt",
							children: t.quietTo
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "qt",
							type: "time",
							value: quietTo,
							onChange: (e) => setQuiet(true, quietFrom, e.target.value)
						})]
					})]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => {
					if (window.confirm(t.wipeConfirm)) wipe();
				},
				children: t.wipe
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LakshaApp, {});
}
//#endregion
export { Home as component };
