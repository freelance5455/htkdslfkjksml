import { c as qualityToCobalt, i as extractYoutubeId, l as youtubeThumbnail, o as mimeFromFilename, r as detectPlatform, s as normalizeUrl } from "./detect-BxYQJ91H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cobalt.server-C5E8xqjA.js
var COBALT_MESSAGES = {
	"error.api.fetch.empty": "Não foi possível ler este link. Confira se o post é público e tente de novo.",
	"error.api.fetch.fail": "A plataforma recusou o acesso. Tente outro link ou tente de novo em instantes.",
	"error.api.fetch.critical": "Falha ao buscar o vídeo. Tente novamente daqui a pouco.",
	"error.api.youtube.login": "O YouTube bloqueou esta tentativa. Espere um instante e tente de novo.",
	"error.api.youtube.disabled_main_instance": "YouTube está indisponível neste momento. Tente de novo em instantes.",
	"error.api.rate_exceeded": "Muita gente baixando agora. Espere alguns segundos e tente de novo.",
	"error.api.service.unsupported": "Este tipo de link ainda não é suportado.",
	"error.api.service.disabled": "Este serviço está temporariamente desligado.",
	"error.api.link.invalid": "Este link não parece válido.",
	"error.api.link.unsupported": "Cole um link do YouTube, TikTok ou Instagram.",
	"error.api.content.video.unavailable": "Este vídeo não está disponível para download.",
	"error.api.content.post.unavailable": "Este post não está disponível. Pode ser privado ou ter sido apagado.",
	"error.api.content.too_long": "Este vídeo é longo demais para processar agora.",
	"error.api.auth.jwt.missing": "Instância ocupada. Tentando outra rota…",
	"error.api.auth.key.invalid": "Instância ocupada. Tentando outra rota…"
};
function messageForCobaltCode(code) {
	if (!code) return "Não foi possível preparar o download. Tente de novo.";
	return COBALT_MESSAGES[code] ?? "Não foi possível preparar o download. Tente outro link ou tente de novo.";
}
function messageForUnknownLink() {
	return "Cole um link do YouTube, TikTok ou Instagram.";
}
var INSTANCE_CANDIDATES = ["https://rue-cobalt.xenon.zone", "https://cobaltapi.cjs.nz"];
var USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";
var AUTH_CODES = /* @__PURE__ */ new Set([
	"error.api.auth.jwt.missing",
	"error.api.auth.jwt.invalid",
	"error.api.auth.key.invalid",
	"error.api.auth.turnstile.missing",
	"error.api.auth.turnstile.invalid"
]);
function stripSlash(url) {
	return url.replace(/\/+$/, "");
}
async function readJson(response) {
	const text = await response.text();
	if (!text) return null;
	try {
		return JSON.parse(text);
	} catch {
		return null;
	}
}
async function cobaltPost(instance, body, timeoutMs) {
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), timeoutMs);
	try {
		const json = await readJson(await fetch(`${stripSlash(instance)}/`, {
			method: "POST",
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
				"User-Agent": USER_AGENT
			},
			body: JSON.stringify(body),
			signal: controller.signal
		}));
		if (!json || typeof json !== "object") return {
			status: "error",
			error: { code: "error.api.fetch.fail" }
		};
		return json;
	} finally {
		clearTimeout(timer);
	}
}
function isAllowedTunnel(url) {
	try {
		const parsed = new URL(url);
		if (parsed.protocol !== "https:") return false;
		if (!INSTANCE_CANDIDATES.some((instance) => {
			const host = new URL(instance).hostname;
			return parsed.hostname === host;
		})) return false;
		return parsed.pathname === "/tunnel" || parsed.pathname.startsWith("/tunnel");
	} catch {
		return false;
	}
}
function isAllowedRedirect(url) {
	try {
		return new URL(url).protocol === "https:";
	} catch {
		return false;
	}
}
function defaultFilename(platform, audioOnly, quality) {
	return `puro-${platform}-${audioOnly ? "audio" : quality}.${audioOnly ? "mp3" : "mp4"}`;
}
async function fetchOembed(url) {
	const platform = detectPlatform(url);
	let endpoint = null;
	if (platform === "youtube") endpoint = `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`;
	else if (platform === "tiktok") endpoint = `https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`;
	if (!endpoint) return {};
	try {
		const response = await fetch(endpoint, {
			headers: {
				"User-Agent": USER_AGENT,
				Accept: "application/json"
			},
			signal: AbortSignal.timeout(6e3)
		});
		if (!response.ok) return {};
		const json = await response.json();
		return {
			title: json.title,
			author: json.author_name,
			thumbnail: json.thumbnail_url
		};
	} catch {
		return {};
	}
}
function fallbackPreview(url, platform) {
	if (platform === "youtube") {
		const id = extractYoutubeId(url);
		return {
			title: "Vídeo do YouTube",
			thumbnail: id ? youtubeThumbnail(id) : void 0
		};
	}
	if (platform === "tiktok") return { title: "Vídeo do TikTok" };
	return { title: "Vídeo do Instagram" };
}
async function previewMedia(rawUrl) {
	const url = normalizeUrl(rawUrl);
	const platform = detectPlatform(url);
	if (!platform) return {
		ok: false,
		message: messageForUnknownLink()
	};
	const meta = await fetchOembed(url);
	const fallback = fallbackPreview(url, platform);
	return {
		ok: true,
		platform,
		title: meta.title || fallback.title,
		author: meta.author,
		thumbnail: meta.thumbnail || fallback.thumbnail
	};
}
async function prepareMedia(input) {
	const url = normalizeUrl(input.url);
	const platform = detectPlatform(url);
	if (!platform) return {
		ok: false,
		message: messageForUnknownLink()
	};
	const body = input.audioOnly ? {
		url,
		downloadMode: "audio",
		audioFormat: "mp3",
		audioBitrate: "128",
		filenameStyle: "pretty",
		alwaysProxy: true
	} : {
		url,
		downloadMode: "auto",
		videoQuality: qualityToCobalt(input.quality),
		filenameStyle: "pretty",
		youtubeVideoCodec: "h264",
		youtubeVideoContainer: "mp4",
		alwaysProxy: true
	};
	let lastCode;
	let lastMessage;
	for (const instance of INSTANCE_CANDIDATES) {
		let result;
		try {
			result = await cobaltPost(instance, body, 18e3);
		} catch {
			lastMessage = "Falha de conexão. Tentando outra rota…";
			continue;
		}
		if (result.status === "error") {
			const code = result.error?.code;
			lastCode = code;
			lastMessage = messageForCobaltCode(code);
			if (code && AUTH_CODES.has(code)) continue;
			if (code === "error.api.youtube.login") continue;
			if (code === "error.api.rate_exceeded") continue;
			continue;
		}
		let fileUrl;
		let filename;
		if (result.status === "tunnel" || result.status === "redirect") {
			const ok = result;
			fileUrl = ok.url;
			filename = ok.filename;
		} else if (result.status === "picker") {
			const picker = result;
			const video = picker.picker?.find((item) => item.type === "video" && item.url);
			const first = picker.picker?.find((item) => item.url);
			const chosen = video ?? first;
			fileUrl = chosen?.url ?? picker.audio;
			filename = chosen?.filename;
			if (!fileUrl) {
				lastMessage = "Este post não tem um vídeo para baixar.";
				continue;
			}
		} else {
			lastMessage = "Resposta inesperada do servidor de mídia.";
			continue;
		}
		if (!fileUrl) {
			lastMessage = "Não veio um arquivo para baixar.";
			continue;
		}
		if (!(result.status === "tunnel" ? isAllowedTunnel(fileUrl) : isAllowedRedirect(fileUrl))) {
			lastMessage = "Origem do arquivo não reconhecida.";
			continue;
		}
		const meta = await fetchOembed(url);
		const fallback = fallbackPreview(url, platform);
		const safeName = filename?.replace(/[/\\?%*:|"<>]/g, "-") || defaultFilename(platform, input.audioOnly, input.quality);
		return {
			ok: true,
			platform,
			title: meta.title || fallback.title,
			author: meta.author,
			thumbnail: meta.thumbnail || fallback.thumbnail,
			filename: safeName,
			downloadUrl: fileUrl,
			mime: mimeFromFilename(safeName, input.audioOnly),
			audioOnly: input.audioOnly,
			quality: input.quality
		};
	}
	return {
		ok: false,
		message: lastMessage || "Não foi possível preparar o download agora. Tente de novo em instantes.",
		code: lastCode
	};
}
//#endregion
export { prepareMedia, previewMedia };
