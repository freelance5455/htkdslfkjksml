import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as useRouter, Y as require_jsx_runtime, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useNavigate, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as create } from "../_libs/zustand.mjs";
import { D as cn, H as useRuntime, V as useAppStore } from "./ui-CJMJB--P.mjs";
import { a as Search, i as Settings, l as House, n as TriangleAlert, o as MousePointerClick, s as Library, t as Wrench, u as Gauge } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DG3Pqbtv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function resolveTheme(theme) {
	if (theme !== "system") return theme;
	if (typeof window === "undefined") return "dark";
	return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function applyAppearance(input) {
	if (typeof document === "undefined") return;
	const root = document.documentElement;
	const resolved = resolveTheme(input.theme);
	root.dataset.theme = resolved;
	root.dataset.accent = input.accent;
	root.dataset.bg = input.background;
	root.dataset.density = input.density;
	root.dataset.motion = input.motion;
	const meta = document.querySelector("meta[name=\"theme-color\"]");
	if (meta) meta.setAttribute("content", resolved === "light" ? "#f3efe8" : "#0c0d0f");
}
var useClickerRuntime = create(() => ({
	phase: "stopped",
	taps: 0,
	cycles: 0,
	pulse: 0,
	activePointId: null,
	startedAt: null,
	accumulatedMs: 0,
	nextFireAt: null,
	remainingMs: 0,
	error: null,
	lastSummary: null
}));
var timer = null;
var step = 0;
var runKind = "run";
function clearTimer() {
	if (timer != null) {
		clearTimeout(timer);
		timer = null;
	}
}
function elapsedNow() {
	const state = useClickerRuntime.getState();
	if (state.startedAt == null) return state.accumulatedMs;
	return state.accumulatedMs + Math.max(0, Date.now() - state.startedAt);
}
function validateClicker(config) {
	if (config.intervalMs < 50 || config.intervalMs > 6e4) return "Interval must be between 50 and 60000 ms.";
	if (config.repeat < 0 || config.repeat > 9999) return "Repetition count must be between 0 and 9999.";
	if (config.durationSec < 0 || config.durationSec > 86400) return "Duration must be between 0 and 86400 seconds.";
	if (config.mode === "sequence" && config.points.length === 0) return "Add at least one point, or switch to single point.";
	if (config.points.some((point) => point.delayMs < 50 || point.delayMs > 6e4)) return "Each point delay must be between 50 and 60000 ms.";
	return null;
}
function pointsFor(config) {
	if (config.mode === "single") return [config.points[0] ?? {
		id: "center",
		label: "Center",
		x: 50,
		y: 48,
		delayMs: config.intervalMs
	}];
	return config.points;
}
function stopWith(reason) {
	clearTimer();
	const state = useClickerRuntime.getState();
	const summary = state.taps > 0 ? `${state.taps} practice taps · ${state.cycles} cycles. ${reason}` : reason;
	step = 0;
	useClickerRuntime.setState({
		phase: "stopped",
		activePointId: null,
		startedAt: null,
		accumulatedMs: 0,
		nextFireAt: null,
		remainingMs: 0,
		error: null,
		lastSummary: summary
	});
}
function schedule(delay) {
	const config = useAppStore.getState().clicker;
	let wait = Math.max(40, delay);
	if (runKind === "run" && config.durationSec > 0) {
		const left = config.durationSec * 1e3 - elapsedNow();
		if (left <= 0) {
			stopWith("Stopped: duration reached.");
			return;
		}
		if (left < wait) {
			useClickerRuntime.setState({ nextFireAt: Date.now() + left });
			clearTimer();
			timer = setTimeout(() => stopWith("Stopped: duration reached."), left);
			return;
		}
	}
	useClickerRuntime.setState({ nextFireAt: Date.now() + wait });
	clearTimer();
	timer = setTimeout(fire, wait);
}
function fire() {
	const runtime = useClickerRuntime.getState();
	if (runtime.phase !== "running" && runtime.phase !== "preview") return;
	const config = useAppStore.getState().clicker;
	if (runKind === "run" && config.durationSec > 0 && elapsedNow() >= config.durationSec * 1e3) {
		stopWith("Stopped: duration reached.");
		return;
	}
	const points = pointsFor(config);
	if (points.length === 0) {
		stopWith("Add a point on the practice pad.");
		return;
	}
	const index = step % points.length;
	const point = points[index];
	const endCycle = index === points.length - 1;
	const cycles = runtime.cycles + (endCycle ? 1 : 0);
	step += 1;
	useClickerRuntime.setState({
		taps: runtime.taps + 1,
		cycles,
		pulse: runtime.pulse + 1,
		activePointId: point.id
	});
	if (runtime.phase === "preview" && endCycle) {
		stopWith("Preview finished.");
		return;
	}
	if (runKind === "run" && config.repeat > 0 && endCycle && cycles >= config.repeat) {
		stopWith("Stopped: repetition count reached.");
		return;
	}
	const next = points[step % points.length];
	schedule(config.mode === "single" ? config.intervalMs : endCycle ? Math.max(config.intervalMs, next.delayMs) : next.delayMs);
}
function startClicker(kind) {
	const phase = useClickerRuntime.getState().phase;
	if (phase === "running" || phase === "paused" || phase === "preview") return;
	const config = useAppStore.getState().clicker;
	const error = validateClicker(config);
	if (error) {
		useClickerRuntime.setState({
			error,
			lastSummary: null
		});
		return;
	}
	if (kind === "run" && config.repeat === 0 && config.durationSec === 0) useClickerRuntime.setState({ error: null });
	clearTimer();
	step = 0;
	runKind = kind;
	const points = pointsFor(config);
	const firstDelay = config.mode === "single" ? 40 : Math.max(40, points[0]?.delayMs ?? config.intervalMs);
	useClickerRuntime.setState({
		phase: kind === "preview" ? "preview" : "running",
		taps: 0,
		cycles: 0,
		activePointId: null,
		startedAt: Date.now(),
		accumulatedMs: 0,
		error: null,
		lastSummary: null
	});
	schedule(firstDelay);
}
function pauseClicker() {
	const runtime = useClickerRuntime.getState();
	if (runtime.phase !== "running" && runtime.phase !== "preview") return;
	const remaining = runtime.nextFireAt == null ? 40 : Math.max(0, runtime.nextFireAt - Date.now());
	clearTimer();
	const extra = runtime.startedAt == null ? 0 : Math.max(0, Date.now() - runtime.startedAt);
	useClickerRuntime.setState({
		phase: "paused",
		startedAt: null,
		accumulatedMs: runtime.accumulatedMs + extra,
		nextFireAt: null,
		remainingMs: remaining,
		activePointId: null
	});
}
function resumeClicker() {
	const runtime = useClickerRuntime.getState();
	if (runtime.phase !== "paused") return;
	useClickerRuntime.setState({
		phase: runKind === "preview" ? "preview" : "running",
		startedAt: Date.now()
	});
	schedule(runtime.remainingMs || 40);
}
function stopClicker(reason = "Stopped.") {
	if (useClickerRuntime.getState().phase === "stopped") {
		if (reason) useClickerRuntime.setState({
			lastSummary: reason,
			error: null,
			activePointId: null
		});
		return;
	}
	stopWith(reason);
}
var TUTORIALS = [
	{
		id: "home",
		title: "Home dashboard",
		summary: "What the dashboard is allowed to claim.",
		steps: [
			"Widgets show either a saved preference, a number you logged, or a browser API result.",
			"If a sensor does not exist, the row says “Not available in this version.” That is intentional.",
			"Reorder or hide widgets in Settings. Quick actions jump to Optimize, your library, the clicker, tutorials, and customize.",
			"The session clock is the same timer as the one in Tools."
		]
	},
	{
		id: "games",
		title: "Game library",
		summary: "Profiles you maintain by hand.",
		steps: [
			"Add a game by name. FrameForge cannot scan installed Android packages.",
			"Optional: add an icon from your photos, and paste an http(s) link or an app link you already have.",
			"Each game keeps its own target, preset, and graphics notes. Selecting a card makes it the active profile.",
			"Open link only works when the link is valid. It opens in the browser. It is not a package launcher."
		]
	},
	{
		id: "boost",
		title: "FPS targets",
		summary: "Targets and advice, not a system tuner.",
		steps: [
			"30 through 140 are targets. Saving 120 does not make the game render 120.",
			"Battery Saver, Balanced, and Performance write a recommended graphics bundle onto the selected profile.",
			"You still change those options inside the game. This app cannot push settings into another app.",
			"Log FPS only after you measure it, with the game's counter or a manual count. The chart plots those entries.",
			"Frame generation stays unavailable. Refresh rate, rendered FPS, and interpolated FPS are three different things."
		]
	},
	{
		id: "clicker",
		title: "Auto Clicker",
		summary: "A planner and an in-app practice pad.",
		steps: [
			"Single point taps one spot on the pad. Sequence plays the points you placed, in order.",
			"Interval is the gap between taps in single mode. In a sequence, each point has its own delay.",
			"Start, pause, resume, and stop affect only this page. Leaving the sequence running does not click other apps.",
			"Use the large Stop control whenever you want it to end immediately.",
			"Cross-app clicking needs a native Android app and an accessibility service you turn on yourself. This version does not do that, and it will not automate purchases, ads, or rewards."
		]
	},
	{
		id: "tools",
		title: "Tools",
		summary: "Every tool writes or explains something real.",
		steps: [
			"The stopwatch is the shared session timer.",
			"The FPS log and comparison log store numbers you type. Remove a row if it was a mistake.",
			"Measure refresh while this tab is in the foreground. The result is an estimate for this page.",
			"The capability checklist is filled from this browser, not from a spec sheet.",
			"Notes, the thermal checklist, and tutorials stay on this device."
		]
	},
	{
		id: "settings",
		title: "Customize and data",
		summary: "Look, layout, and the local save file.",
		steps: [
			"Theme, background, accent, density, and motion apply immediately and are saved in this browser.",
			"The performance overlay is a preview of your target and your last manual log. It is not drawn over other apps.",
			"Export writes a JSON file. Import replaces games, logs, clicker presets, and appearance on this device.",
			"Restore defaults resets appearance and the clicker setup. Reset all data also clears games and logs.",
			"Nothing is uploaded. There is no account."
		]
	}
];
var STATIC = [
	{
		id: "home",
		title: "Home",
		hint: "Dashboard and quick actions",
		group: "Screens",
		to: "/",
		keywords: "dashboard widgets session status"
	},
	{
		id: "games",
		title: "Game library",
		hint: "Profiles, icons, and launch links",
		group: "Screens",
		to: "/games",
		keywords: "games profiles where winds meet add game"
	},
	{
		id: "boost",
		title: "Boost",
		hint: "FPS targets and recommended settings",
		group: "Screens",
		to: "/boost",
		keywords: "optimize fps preset battery performance frame generation"
	},
	{
		id: "clicker",
		title: "Auto Clicker",
		hint: "Practice pad and sequences",
		group: "Screens",
		to: "/clicker",
		keywords: "clicker tap interval autoclicker"
	},
	{
		id: "tools",
		title: "Tools",
		hint: "Logs, guides, and tutorials",
		group: "Screens",
		to: "/tools",
		keywords: "tools hub"
	},
	{
		id: "settings",
		title: "Settings",
		hint: "Theme, data, and limits",
		group: "Screens",
		to: "/settings",
		keywords: "settings customize appearance"
	},
	{
		id: "tool-stopwatch",
		title: "Session stopwatch",
		hint: "Start, pause, and reset",
		group: "Tools",
		to: "/tools",
		hash: "stopwatch",
		keywords: "timer clock session"
	},
	{
		id: "tool-fps",
		title: "Manual FPS log",
		hint: "Record a measured frame rate",
		group: "Tools",
		to: "/tools",
		hash: "fps-log",
		keywords: "fps chart measured"
	},
	{
		id: "tool-refresh",
		title: "Refresh-rate guide",
		hint: "Estimate this page and read the difference",
		group: "Tools",
		to: "/tools",
		hash: "refresh-guide",
		keywords: "hz display refresh rate"
	},
	{
		id: "tool-caps",
		title: "Device capability checklist",
		hint: "What this browser can report",
		group: "Tools",
		to: "/tools",
		hash: "capabilities",
		keywords: "cpu gpu ram battery webgl"
	},
	{
		id: "tool-notes",
		title: "Game settings notes",
		hint: "Write notes per game",
		group: "Tools",
		to: "/tools",
		hash: "notes",
		keywords: "notes notebook"
	},
	{
		id: "tool-compare",
		title: "Performance comparison log",
		hint: "Compare manual runs",
		group: "Tools",
		to: "/tools",
		hash: "compare",
		keywords: "compare benchmark log"
	},
	{
		id: "tool-thermal",
		title: "Thermal management guide",
		hint: "Heat, throttling, and a checklist",
		group: "Tools",
		to: "/tools",
		hash: "thermal",
		keywords: "heat temperature throttle"
	},
	{
		id: "tool-tutorials",
		title: "Tutorials",
		hint: "Short guides for every main feature",
		group: "Tools",
		to: "/tools",
		hash: "tutorials",
		keywords: "help how to learn"
	},
	{
		id: "set-appearance",
		title: "Appearance",
		hint: "Theme, accent, background, density, motion",
		group: "Settings",
		to: "/settings",
		hash: "customize",
		keywords: "dark light color density animation"
	},
	{
		id: "set-widgets",
		title: "Home widgets",
		hint: "Show, hide, and reorder dashboard cards",
		group: "Settings",
		to: "/settings",
		hash: "widgets",
		keywords: "widgets customize home"
	},
	{
		id: "set-overlay",
		title: "Overlay preview",
		hint: "A labelled mockup, not a system overlay",
		group: "Settings",
		to: "/settings",
		hash: "overlay",
		keywords: "overlay hud preview"
	},
	{
		id: "set-data",
		title: "Export, import, and reset",
		hint: "JSON backup and local data",
		group: "Settings",
		to: "/settings",
		hash: "data",
		keywords: "backup json reset defaults storage privacy"
	},
	{
		id: "set-install",
		title: "Add to home screen",
		hint: "Install instructions for Android Chrome",
		group: "Settings",
		to: "/settings",
		hash: "install",
		keywords: "pwa install android chrome homescreen"
	},
	{
		id: "set-limits",
		title: "What works and what needs a native app",
		hint: "Honest capability list",
		group: "Settings",
		to: "/settings",
		hash: "limits",
		keywords: "native apk limitations accessibility fps unlock"
	},
	{
		id: "set-awake",
		title: "Keep screen awake",
		hint: "Screen Wake Lock during a session",
		group: "Settings",
		to: "/settings",
		hash: "customize",
		keywords: "wake lock screen on"
	}
];
function buildSearchItems(games, presets, notes) {
	const gameItems = games.map((game) => ({
		id: `game-${game.id}`,
		title: game.name,
		hint: `${game.fpsTarget} FPS target · ${game.preset}`,
		group: "Games",
		to: "/games",
		hash: `g-${game.id}`,
		keywords: `${game.notes} profile launch`
	}));
	const presetItems = presets.map((preset) => ({
		id: `preset-${preset.id}`,
		title: preset.name,
		hint: preset.mode === "single" ? "Single-point preset" : "Sequence preset",
		group: "Presets",
		to: "/clicker",
		hash: "presets",
		keywords: "clicker preset sequence"
	}));
	const noteItems = notes.map((note) => ({
		id: `note-${note.id}`,
		title: note.title,
		hint: "Game settings note",
		group: "Notes",
		to: "/tools",
		hash: "notes",
		keywords: note.body
	}));
	const tutorialItems = TUTORIALS.map((tutorial) => ({
		id: `tutorial-${tutorial.id}`,
		title: tutorial.title,
		hint: "Tutorial",
		group: "Tools",
		to: "/tools",
		hash: "tutorials",
		keywords: `${tutorial.summary} ${tutorial.steps.join(" ")}`
	}));
	return [
		...STATIC,
		...gameItems,
		...presetItems,
		...noteItems,
		...tutorialItems
	];
}
function searchItems(query, items) {
	const q = query.trim().toLowerCase();
	if (!q) return [];
	return items.filter((item) => `${item.title} ${item.hint} ${item.keywords} ${item.group}`.toLowerCase().includes(q)).slice(0, 20);
}
function SearchBar() {
	const navigate = useNavigate();
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const games = useAppStore((state) => state.games);
	const presets = useAppStore((state) => state.clickPresets);
	const notes = useAppStore((state) => state.notes);
	const [query, setQuery] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)(0);
	const inputRef = (0, import_react.useRef)(null);
	const items = (0, import_react.useMemo)(() => buildSearchItems(games, presets, notes), [
		games,
		presets,
		notes
	]);
	const results = (0, import_react.useMemo)(() => searchItems(query, items), [query, items]);
	(0, import_react.useEffect)(() => {
		setQuery("");
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		setActive(0);
	}, [query]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			const target = event.target;
			const typing = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement;
			if (event.key === "/" && !typing) {
				event.preventDefault();
				inputRef.current?.focus();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	function go(index) {
		const item = results[index];
		if (!item) return;
		setOpen(false);
		setQuery("");
		navigate({
			to: item.to,
			hash: item.hash
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-w-0 flex-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-faint",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "search",
				value: query,
				"aria-label": "Search screens, games, tools, and settings",
				placeholder: "Search",
				className: "field-input pl-9",
				onChange: (event) => {
					setQuery(event.target.value);
					setOpen(true);
				},
				onFocus: () => setOpen(true),
				onKeyDown: (event) => {
					if (event.key === "ArrowDown") {
						event.preventDefault();
						setActive((index) => Math.min(index + 1, Math.max(results.length - 1, 0)));
					} else if (event.key === "ArrowUp") {
						event.preventDefault();
						setActive((index) => Math.max(index - 1, 0));
					} else if (event.key === "Enter") {
						event.preventDefault();
						go(active);
					} else if (event.key === "Escape") setOpen(false);
				}
			}),
			open && query.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "surface absolute top-full right-0 left-0 z-30 mt-2 max-h-80 overflow-auto p-1",
				role: "listbox",
				children: results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-3 py-3 text-sm text-muted",
					children: "No matches."
				}) : results.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "option",
					"aria-selected": index === active,
					className: `flex w-full min-h-11 flex-col items-start rounded-lg px-3 py-2 text-left ${index === active ? "bg-surface-2" : ""}`,
					onMouseEnter: () => setActive(index),
					onClick: () => go(index),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-semibold",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-faint",
						children: [
							item.group,
							" · ",
							item.hint
						]
					})]
				}) }, item.id))
			}) : null
		]
	});
}
function SessionWake() {
	const running = useAppStore((state) => state.session.running);
	const keepAwake = useAppStore((state) => state.keepAwake);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		let lock = null;
		async function sync() {
			if (!(useAppStore.getState().session.running && useAppStore.getState().keepAwake && document.visibilityState === "visible")) {
				try {
					await lock?.release();
				} catch {}
				lock = null;
				if (!("wakeLock" in navigator) && useAppStore.getState().keepAwake) useRuntime.getState().setWake("unsupported");
				else if (useRuntime.getState().wake !== "denied") useRuntime.getState().setWake("off");
				return;
			}
			if (!("wakeLock" in navigator)) {
				useRuntime.getState().setWake("unsupported");
				return;
			}
			try {
				const next = await navigator.wakeLock.request("screen");
				if (cancelled) {
					await next.release();
					return;
				}
				lock = next;
				useRuntime.getState().setWake("on");
				next.addEventListener("release", () => {
					if (lock === next) lock = null;
				});
			} catch {
				if (!cancelled) useRuntime.getState().setWake("denied");
			}
		}
		sync();
		const onVisible = () => void sync();
		document.addEventListener("visibilitychange", onVisible);
		return () => {
			cancelled = true;
			document.removeEventListener("visibilitychange", onVisible);
			lock?.release().catch(() => void 0);
		};
	}, [running, keepAwake]);
	return null;
}
var NAV = [
	{
		to: "/",
		label: "Home",
		icon: House,
		exact: true
	},
	{
		to: "/games",
		label: "Games",
		icon: Library,
		exact: false
	},
	{
		to: "/boost",
		label: "Boost",
		icon: Gauge,
		exact: false
	},
	{
		to: "/clicker",
		label: "Clicker",
		long: "Auto Clicker",
		icon: MousePointerClick,
		exact: false
	},
	{
		to: "/tools",
		label: "Tools",
		icon: Wrench,
		exact: false
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings,
		exact: false
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const hash = useRouterState({ select: (state) => state.location.hash });
	const theme = useAppStore((state) => state.theme);
	const accent = useAppStore((state) => state.accent);
	const background = useAppStore((state) => state.background);
	const density = useAppStore((state) => state.density);
	const motion = useAppStore((state) => state.motion);
	const phase = useClickerRuntime((state) => state.phase);
	const taps = useClickerRuntime((state) => state.taps);
	const storageMode = useRuntime((state) => state.storageMode);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const unsub = useAppStore.persist.onFinishHydration(() => {
			document.documentElement.dataset.ffReady = "1";
			setReady(true);
		});
		if (useAppStore.persist.hasHydrated()) {
			document.documentElement.dataset.ffReady = "1";
			setReady(true);
		} else useAppStore.persist.rehydrate();
		return unsub;
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		applyAppearance({
			theme,
			accent,
			background,
			density,
			motion
		});
		if (!(theme === "system")) return;
		const media = window.matchMedia("(prefers-color-scheme: dark)");
		const onChange = () => applyAppearance({
			theme,
			accent,
			background,
			density,
			motion
		});
		media.addEventListener("change", onChange);
		return () => media.removeEventListener("change", onChange);
	}, [
		ready,
		theme,
		accent,
		background,
		density,
		motion
	]);
	(0, import_react.useEffect)(() => {
		if (!hash) return;
		const id = decodeURIComponent(hash.replace(/^#/, ""));
		if (!id || id.startsWith("g-")) return;
		document.getElementById(id)?.scrollIntoView({ block: "start" });
	}, [hash, pathname]);
	const live = phase !== "stopped";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "skip-link",
			href: "#content",
			children: "Skip to content"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionWake, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-30 border-b border-line bg-bg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "shrink-0 rounded-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-sm font-semibold tracking-widest",
						children: "FRAMEFORGE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs font-semibold tracking-widest text-primary",
						children: "BOOYAH"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBar, {})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			id: "content",
			className: cn("app-main stack", live && "is-live"),
			children: [
				storageMode === "memory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "status",
					className: "panel text-sm text-primary",
					children: "This browser refused local storage. Changes stay in this tab only and will be lost on refresh."
				}) : null,
				storageMode === "unreadable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "panel text-sm text-primary",
					children: "Saved data could not be read. You are seeing defaults until the next successful save."
				}) : null,
				children
			]
		}),
		live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed right-3 left-3 z-50",
			style: { bottom: "calc(4.6rem + env(safe-area-inset-bottom))" },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex min-h-14 w-full items-center justify-between rounded-xl bg-primary px-4 text-primary-fg",
				onClick: () => stopClicker("Stopped from the emergency control."),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs font-semibold tracking-widest uppercase",
						children: phase === "paused" ? "Paused" : phase === "preview" ? "Previewing" : "Running in this app"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-sm tabular-nums",
						children: [taps, " practice taps"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-lg font-semibold",
					children: "Stop"
				})]
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "app-dock fixed inset-x-0 bottom-0 z-40",
			"aria-label": "Primary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mx-auto flex w-full max-w-3xl",
				children: NAV.map((item) => {
					const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "min-w-0 flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							"aria-current": active ? "page" : void 0,
							"aria-label": "long" in item ? item.long : item.label,
							className: cn("flex min-h-14 flex-col items-center justify-center gap-0.5 px-0.5 text-xs font-semibold", active ? "text-primary" : "text-faint"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: 1.75,
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "max-w-full truncate",
								children: item.label
							})]
						})
					}, item.to);
				})
			})
		})
	] });
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Page not found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "That screen is not part of FrameForge."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "text-sm font-semibold text-primary",
				children: "Go home"
			})
		]
	});
}
var styles_default = "/assets/styles-sfYvc60I.css";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: "FrameForge BOOYAH" },
			{
				name: "theme-color",
				content: "#0c0d0f"
			},
			{
				name: "description",
				content: "A quiet gaming companion for targets, profiles, and honest device limits."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootComponent,
	notFoundComponent: NotFound
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$5 = () => import("./routes-CibK77tK.mjs");
var Route$5 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Home · FrameForge BOOYAH" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./boost-BaZSHFEi.mjs");
var Route$4 = createFileRoute("/boost")({
	head: () => ({ meta: [{ title: "Boost · FrameForge BOOYAH" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./clicker-DzdZlJJB.mjs");
var Route$3 = createFileRoute("/clicker")({
	head: () => ({ meta: [{ title: "Auto Clicker · FrameForge BOOYAH" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./games-DzKK9ZEE.mjs");
var Route$2 = createFileRoute("/games")({
	head: () => ({ meta: [{ title: "Games · FrameForge BOOYAH" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./settings-DhPOPaRT.mjs");
var Route$1 = createFileRoute("/settings")({
	head: () => ({ meta: [{ title: "Settings · FrameForge BOOYAH" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./tools-AG5Z0Mm4.mjs");
var Route = createFileRoute("/tools")({
	head: () => ({ meta: [{ title: "Tools · FrameForge BOOYAH" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$5.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$6
	}),
	BoostRoute: Route$4.update({
		id: "/boost",
		path: "/boost",
		getParentRoute: () => Route$6
	}),
	ClickerRoute: Route$3.update({
		id: "/clicker",
		path: "/clicker",
		getParentRoute: () => Route$6
	}),
	GamesRoute: Route$2.update({
		id: "/games",
		path: "/games",
		getParentRoute: () => Route$6
	}),
	SettingsRoute: Route$1.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$6
	}),
	ToolsRoute: Route.update({
		id: "/tools",
		path: "/tools",
		getParentRoute: () => Route$6
	})
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { startClicker as a, validateClicker as c, resumeClicker as i, TUTORIALS as n, stopClicker as o, pauseClicker as r, useClickerRuntime as s, router_exports as t };
