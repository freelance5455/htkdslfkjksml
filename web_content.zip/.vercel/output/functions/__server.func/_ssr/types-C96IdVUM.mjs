import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ChevronDown } from "../_libs/lucide-react.mjs";
import { i as cn } from "./router-BlmjsFDF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/types-C96IdVUM.js
var import_jsx_runtime = require_jsx_runtime();
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm leading-snug text-muted",
				children: hint
			}) : null
		]
	});
}
var control = "min-h-11 w-full rounded-md border border-line bg-bg px-3 text-base text-ink placeholder:text-faint";
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(control, props.className)
	});
}
function TextArea(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn(control, "min-h-28 py-3", props.className)
	});
}
function SelectInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			...props,
			className: cn(control, "appearance-none pr-10", props.className)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-muted" })]
	});
}
var SCENE_COUNTS = [
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10
];
//#endregion
export { TextInput as a, TextArea as i, SCENE_COUNTS as n, SelectInput as r, Field as t };
